/**
 * Generated bundle index. Do not edit.
 */
/// <amd-module name="gias-ui-kit" />
export * from './public-api';
