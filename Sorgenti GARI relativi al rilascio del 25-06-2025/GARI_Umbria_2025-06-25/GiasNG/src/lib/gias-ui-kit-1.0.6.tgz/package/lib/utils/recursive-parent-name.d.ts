import { AbstractControl } from "@angular/forms";
export declare function recursiveParentName(c: AbstractControl): string;
