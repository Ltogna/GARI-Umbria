export declare function getListOfPropertyInArrayObject(input_array: Array<any>, property: string): Array<any>;
