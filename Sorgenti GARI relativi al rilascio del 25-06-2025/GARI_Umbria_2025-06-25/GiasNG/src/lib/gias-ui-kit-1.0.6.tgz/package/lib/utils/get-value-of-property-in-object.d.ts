export declare function getValueOfPropertyInObject(input: any, property: string): any;
