import { Observable, Subject } from 'rxjs';
import { IGiasApiService } from './gias-api.service';
import { CodiciNazioniISO3166, Comune, Provincia } from './models';
import * as i0 from "@angular/core";
export declare class GiasIstatService {
    private apiService;
    Provincie: Provincia[];
    ComunixProv: Map<string, Comune[]>;
    Stati: CodiciNazioniISO3166[];
    statiObs: Subject<CodiciNazioniISO3166[]>;
    provinciObs: Subject<Provincia[]>;
    constructor(apiService: IGiasApiService);
    getProvincie(): Provincia[];
    getStati(): CodiciNazioniISO3166[];
    leggiProvincie(Stato_Cod: string, regione?: string): Promise<Provincia[]>;
    readRegioni(cod_stato: string): Observable<any[]>;
    readRegionsByProvince(prov: string): Observable<any>;
    leggiComuni(Prov: string): Promise<Comune[]>;
    leggiStati(): Promise<CodiciNazioniISO3166[]>;
    leggiCAP(Prov: string, Com: string): Promise<string>;
    static ɵfac: i0.ɵɵFactoryDeclaration<GiasIstatService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<GiasIstatService>;
}
