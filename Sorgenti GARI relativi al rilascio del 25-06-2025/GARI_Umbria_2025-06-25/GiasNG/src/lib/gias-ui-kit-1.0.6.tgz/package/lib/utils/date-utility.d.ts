export declare namespace DateUtility {
    const MILLISECONDS_PER_SECOND = 1000;
    const SECONDS_PER_MINUTE = 60;
    const MINUTES_PER_HOUR = 60;
    const HOURS_PER_DAY = 24;
    const DAYS_PER_WEEK = 7;
    const MONTHS_PER_YEAR = 12;
    const SECOND = 1000;
    const MINUTE: number;
    const HOUR: number;
    const DAY: number;
    const WEEK: number;
    const YEAR: number;
    const NORMAL_YEAR: number;
    const LEAP_YEAR: number;
    enum months {
        JANUARY = 0,
        FEBUARY = 1,
        MARCH = 2,
        APRIL = 3,
        MAY = 4,
        JUNE = 5,
        JULY = 6,
        AUGUST = 7,
        SEPTEMBER = 8,
        OCTOBER = 9,
        NOVEMBER = 10,
        DECEMBER = 11
    }
    function getCurrentYear(): number;
}
