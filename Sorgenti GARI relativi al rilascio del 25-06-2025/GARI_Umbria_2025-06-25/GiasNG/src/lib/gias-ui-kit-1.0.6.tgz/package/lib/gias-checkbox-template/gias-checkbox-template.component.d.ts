import { EventEmitter, OnInit } from '@angular/core';
import { IGiasMasterService } from '../utils/gias-master.service';
import { enum_InputType } from '../utils/models';
import * as i0 from "@angular/core";
export declare class GiasCheckboxTemplateComponent implements OnInit {
    private giasMasterService;
    name: string;
    value: boolean;
    isDisabled: boolean;
    giasFormControlName: string;
    valueChange: EventEmitter<boolean>;
    inputType: enum_InputType;
    constructor(giasMasterService: IGiasMasterService);
    ngOnInit(): void;
    changeValue(newValue: Event): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<GiasCheckboxTemplateComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GiasCheckboxTemplateComponent, "gias-checkbox-template", never, { "name": { "alias": "name"; "required": false; }; "value": { "alias": "value"; "required": false; }; "isDisabled": { "alias": "isDisabled"; "required": false; }; "giasFormControlName": { "alias": "giasFormControlName"; "required": false; }; }, { "valueChange": "valueChange"; }, never, never, false, never>;
}
