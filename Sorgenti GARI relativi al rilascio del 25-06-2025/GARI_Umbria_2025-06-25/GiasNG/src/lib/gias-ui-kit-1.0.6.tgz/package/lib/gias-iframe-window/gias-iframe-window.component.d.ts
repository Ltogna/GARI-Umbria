import { ElementRef, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import * as i0 from "@angular/core";
export declare class GiasIFrameWindowComponent implements OnInit {
    private elementRef;
    url: string;
    urlObs: Observable<string>;
    constructor(elementRef: ElementRef);
    ngOnInit(): void;
    postMessageToParent(message: any): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<GiasIFrameWindowComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GiasIFrameWindowComponent, "gias-iframe-window", never, { "url": { "alias": "url"; "required": false; }; }, {}, never, never, false, never>;
}
