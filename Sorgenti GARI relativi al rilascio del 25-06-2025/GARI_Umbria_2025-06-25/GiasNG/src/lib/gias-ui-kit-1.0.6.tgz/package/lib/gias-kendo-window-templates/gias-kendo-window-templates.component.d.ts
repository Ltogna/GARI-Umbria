import { AfterViewInit, TemplateRef } from '@angular/core';
import { GiasIFrameWindowService } from '../gias-iframe-window/gias-iframe-window.service';
import * as i0 from "@angular/core";
export declare class GiasKendoWindowTemplates implements AfterViewInit {
    private GiasIFrameWindowService;
    windowTitleBar: TemplateRef<any>;
    showMinimize: boolean;
    showMaximize: boolean;
    showRestore: boolean;
    showClose: boolean;
    title: string;
    constructor(GiasIFrameWindowService: GiasIFrameWindowService);
    ngAfterViewInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<GiasKendoWindowTemplates, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GiasKendoWindowTemplates, "gias-kendo-window-templates", never, {}, {}, never, never, false, never>;
}
