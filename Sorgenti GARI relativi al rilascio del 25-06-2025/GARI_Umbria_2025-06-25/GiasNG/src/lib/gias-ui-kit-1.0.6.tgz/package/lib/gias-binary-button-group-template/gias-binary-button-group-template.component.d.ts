import { EventEmitter, OnDestroy, OnInit } from '@angular/core';
import { ControlContainer, FormControl } from '@angular/forms';
import { Subject } from 'rxjs';
import * as i0 from "@angular/core";
export declare class GiasBinaryButtonGroupTemplateComponent implements OnInit, OnDestroy {
    controlContainer: ControlContainer;
    value: boolean;
    giasFormControlName: string;
    disabledsibutton: boolean;
    disablednobutton: boolean;
    silabel: string;
    nolabel: string;
    valueChange: EventEmitter<boolean>;
    fc: FormControl;
    signal$: Subject<void>;
    private subscription;
    private form;
    constructor(controlContainer: ControlContainer);
    ngOnInit(): void;
    change(val: boolean): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<GiasBinaryButtonGroupTemplateComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GiasBinaryButtonGroupTemplateComponent, "gias-binary-button-group-template", never, { "value": { "alias": "value"; "required": false; }; "giasFormControlName": { "alias": "giasFormControlName"; "required": false; }; "disabledsibutton": { "alias": "disabledsibutton"; "required": false; }; "disablednobutton": { "alias": "disablednobutton"; "required": false; }; "silabel": { "alias": "silabel"; "required": false; }; "nolabel": { "alias": "nolabel"; "required": false; }; }, { "valueChange": "valueChange"; }, never, never, false, never>;
}
