import { IntlService } from '@progress/kendo-angular-intl';
import { IGiasMasterService } from './gias-master.service';
import * as i0 from "@angular/core";
export declare class ConversionService {
    private intlService;
    private giasMasterService;
    private dtRegex1;
    private dtRegex2;
    private dtRegex3;
    private dtRegex4;
    private MappedData;
    private serverTimeZone;
    private clientTimeZone;
    constructor(intlService: IntlService, giasMasterService: IGiasMasterService);
    ConversionDateInObject<T>(object: T): T;
    ConversionDateInObjectNew<T>(object: T): T;
    private ConversioneStringaData;
    verifyMyDate(d: any): boolean;
    ConversionDateInObject_Array<T>(object: T[]): T[];
    private returnDateObjectField;
    convertStringToDate(inputVal: string): Date;
    remove__type<T>(object: T): T;
    ConversionStrDateInStrDateTimeToServer<T>(object: T): T;
    handleAGRODATAINIZIOToServer(date: Date): Date;
    handleAGRODATAINIZIOFromServer(date: Date): Date;
    isIsoDate(str: any): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<ConversionService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ConversionService>;
}
