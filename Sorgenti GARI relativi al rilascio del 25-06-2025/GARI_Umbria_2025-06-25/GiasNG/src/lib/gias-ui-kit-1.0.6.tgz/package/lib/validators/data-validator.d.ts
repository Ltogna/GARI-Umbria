import { AbstractControl, ValidationErrors, Validator } from '@angular/forms';
export declare class DataValidator implements Validator {
    private MINDATE;
    private MAXDATE;
    constructor(MINDATE?: Date, MAXDATE?: Date);
    validate(control: AbstractControl): ValidationErrors;
}
