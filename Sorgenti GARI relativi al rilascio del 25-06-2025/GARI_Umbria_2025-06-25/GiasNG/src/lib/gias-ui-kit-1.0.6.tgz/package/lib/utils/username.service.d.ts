import { Utente } from "./models";
export declare const GIAS_USERNAME_TOKEN = "GIAS_USERNAME_TOKEN";
export interface IUsernameService {
    getCurrentUser(): Utente;
}
