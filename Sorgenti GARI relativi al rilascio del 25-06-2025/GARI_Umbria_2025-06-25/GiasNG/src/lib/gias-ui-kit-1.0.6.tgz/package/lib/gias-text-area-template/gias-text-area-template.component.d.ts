import { EventEmitter, OnInit } from '@angular/core';
import { FormGroup, FormGroupDirective } from '@angular/forms';
import { TextAreaResize } from '@progress/kendo-angular-inputs';
import { Subscription } from 'rxjs';
import { IGiasMasterService } from '../utils/gias-master.service';
import { enum_InputType } from '../utils/models';
import * as i0 from "@angular/core";
export declare class GiasTextAreaTemplateComponent implements OnInit {
    private masterService;
    private rootFormGroup;
    name: string;
    value: string;
    placeholder: string;
    obligatory: boolean;
    isDisabled: boolean;
    giasFormControlName: string;
    parentGroup: FormGroup;
    resizable: TextAreaResize;
    valueChange: EventEmitter<string>;
    Subs: Subscription;
    inputType: enum_InputType;
    constructor(masterService: IGiasMasterService, rootFormGroup: FormGroupDirective);
    ngOnInit(): void;
    changeValue(newValue: string): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<GiasTextAreaTemplateComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GiasTextAreaTemplateComponent, "gias-text-area-template", never, { "name": { "alias": "name"; "required": false; }; "value": { "alias": "value"; "required": false; }; "placeholder": { "alias": "placeholder"; "required": false; }; "obligatory": { "alias": "obligatory"; "required": false; }; "isDisabled": { "alias": "isDisabled"; "required": false; }; "giasFormControlName": { "alias": "giasFormControlName"; "required": false; }; "parentGroup": { "alias": "parentGroup"; "required": false; }; "resizable": { "alias": "resizable"; "required": false; }; }, { "valueChange": "valueChange"; }, never, never, false, never>;
}
