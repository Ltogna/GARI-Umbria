import { Observable } from "rxjs";
import { Enum_DBTypeOperation } from "./models";
export declare enum Tipo_Attivita {
    QuadernoDiCampagna = 1,
    Ricetta = 2
}
export declare enum enum_Tipo_Operazione_Agenda_Target {
    Reale = 1,
    Planning = 2
}
export declare enum Tipo_Ricetta {
    Standard = 0,
    Costi = 1,
    PUA = 2,
    Budget_Globale = 3,
    Budget_Utente = 4,
    Standard_Destinazioni = 5,
    PianoDistribuzioneConcimi = 6,
    ControlloDiGestione = 7,
    Standard_Destinazioni_Planning = 8,
    PianoDistribuzionePua = 9,
    RichiestaUMA = 10
}
export declare enum Stati {
    Da_Eseguire = 300,
    Eseguita = 301
}
export declare class ObjParametriAgenda {
    TipoOperazioneDB: Enum_DBTypeOperation;
    Piva: string;
    Sa_Cod?: number;
    Fabbricato?: number;
    Campo_Cod?: number;
    Appezza?: number;
    Id_Reg?: number;
    Progetto_Cod?: number;
    Validita_Inizio: Date;
    Validita_Fine: Date;
    Veg_Cod?: number;
    Veg_Des?: string;
    Id_Cod?: number;
    Id_Des?: string;
    Cau_Mov?: number;
    Mac_Cod?: number;
    Lav_Cod?: number;
    Lav_Des: string;
    SaNome: string;
    RagSoc: string;
    Pagina_Provenienza?: number;
    Pagina_Provenienza_AltroSito?: number;
    Pagina_Richiesta?: number;
    Data: Date;
    Cod_Contatto: string;
    QueryStringFiltrino: string;
    Impianti: ImpiantiAgendaNG[];
    Id_Agenda: number;
    TipoOperazioneAgenda: Tipo_Attivita;
    TipoRicetta: Tipo_Ricetta;
    Stato: Stati | 0;
    Ricetta_Operazione_Cod: number;
    Ricetta_Cod: number;
    TargetOperazione: enum_Tipo_Operazione_Agenda_Target | 0;
    Programmazione_Cod: number;
    GenericObj_string: string;
    RedirectUrl: string;
    IdSezione: number;
    Chiave: string;
    Sito_Provenienza: number;
    Regolamento_Cod: number;
    Tipo_Regolamento: number;
    constructor();
    isAgendaSelected(): boolean;
    isCentroSelected(): boolean;
}
export declare class ImpiantiAgendaNG {
    Piva: string;
    Sa_Cod: number;
    Appezza: number;
    Id_Reg: number;
    Progetto_Cod: number;
    Veg_Cod: number;
    Id_Cod: number;
    Sup_Imp: number;
    Sup_Imp_help: number;
    Sup_Riduzione_BufferZone: number;
    Perc_Riduzione_Deriva: number;
}
export declare const GIAS_PARAMETRI_AGENDA_TOKEN = "GIAS_PARAMETRI_AGENDA_TOKEN";
export interface IObjParametriAgendaService {
    getObjParamValue(): ObjParametriAgenda;
    currentObjParametriAgenda: Observable<ObjParametriAgenda>;
}
