import { TemplateRef, ViewContainerRef } from '@angular/core';
import { Messages, WindowRef, WindowState } from '@progress/kendo-angular-dialog';
import { BehaviorSubject } from 'rxjs';
import { GiasWindowsService } from './gias-windows.service';
import * as i0 from "@angular/core";
export declare class ButtonSettings {
    showMinimize: boolean;
    showMaximize: boolean;
    showRestore: boolean;
    showClose: boolean;
}
export declare class GiasIFrameWindowService {
    private giasWindowsService;
    titleSub: BehaviorSubject<string>;
    showMinimizeSub: BehaviorSubject<boolean>;
    showMaximaizeSub: BehaviorSubject<boolean>;
    showRestoreSub: BehaviorSubject<boolean>;
    showCloseSub: BehaviorSubject<boolean>;
    /**
     * @usageNotes Evento scaturito dal codice <code>window.parent.postMessage(objPostMessage, '*')</code>.
     * Per passaggio dati filtrone, esempio in Filtrone_Nuovo.js
     */
    postMessageContextResult: BehaviorSubject<any>;
    window: WindowRef;
    private templateRef;
    private functionMessageEventListener;
    constructor(giasWindowsService: GiasWindowsService);
    open(settings: IFrameWindowSettings, FunctionToCallAfterClose?: () => void, buttonSettings?: ButtonSettings): WindowRef;
    close(messaggio: string): void;
    setTemplateRef(t: TemplateRef<any>): void;
    private gestisciContestoPostMessage;
    static ɵfac: i0.ɵɵFactoryDeclaration<GiasIFrameWindowService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<GiasIFrameWindowService>;
}
export declare class IFrameWindowSettings {
    /**
     * Defines a predicate that verifies if the closing of the Window should be prevented.
     * It applies to clicking the **Close** button of the title bar, pressing the **Esc** key or calling the `close` method.
     * Returning true from the predicate prevents the Window from closing.
     * If the **Close** button of the title bar is clicked or **Esc** is pressed, a [WindowCloseResult]({% slug api_dialog_windowcloseresult %}) instance is passed.
     * @param {any} ev
     * @param {WindowRef} [windowRef] - provided only when the window is created using a component.
     * @returns
     */
    preventClose?: (ev: any, windowRef?: WindowRef) => boolean;
    /**
     * Sets the title of the Window.
     */
    title?: string;
    /**
     * Defines the content of the Window.
     */
    content?: string;
    /**
     * Defines the content of the title bar.
     */
    titleBarContent?: TemplateRef<any>;
    /**
     * Defines the text of the labels that are shown within the Window.
     * Used primarily for localization.
     */
    messages?: Messages;
    /**
     * Specifies if the content of the Window is persisted in the DOM
     * when the Window is minimized.
     */
    keepContent?: boolean;
    /**
     * Specifies the width of the Window.
     */
    width?: number;
    /**
     * Specifies the minimum width of the Window.
     */
    minWidth?: number;
    /**
     * Specifies the height of the Window.
     */
    height?: number;
    /**
     * Specifies the minimum height of the Window.
     */
    minHeight?: number;
    /**
     * Specifies the left offset of the Window.
     */
    left?: number;
    /**
     * Specifies the top offset of the Window.
     */
    top?: number;
    /**
     * Specifies is the Window is draggable.
     */
    draggable?: boolean;
    /**
     * Sets the custom CSS classes that will be rendered on the Window wrapper element.
     * Supports the union type of values that NgClass accepts [ngClass]({{ site.data.urls.angular['ngclassapi'] }}).
     */
    cssClass?: any;
    /**
     * Sets the HTML attributes of the Window wrapper element.
     * The property accepts string key-value based pairs.
     */
    htmlAttributes?: {
        [key: string]: string;
    };
    /**
     * Specifies if the Window is resizable.
     */
    resizable?: boolean;
    /**
     * Specifies the initial state of the Window.
     */
    state?: WindowState;
    /**
     * Defines the container in which the Window will be inserted.
     * Specifying this option changes the place in the page hierarchy where the Window will be inserted.
     */
    appendTo?: ViewContainerRef;
    /**
     * Sets the focused element query selector.
     */
    autoFocusedElement?: string;
}
