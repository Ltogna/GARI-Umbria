import { EventEmitter, OnInit, AfterViewChecked } from '@angular/core';
import { ControlContainer } from '@angular/forms';
import { ButtonGroupSelection } from '@progress/kendo-angular-buttons';
import * as i0 from "@angular/core";
export declare class GiasButtonGroupTemplateComponent implements OnInit, AfterViewChecked {
    controlContainer: ControlContainer;
    name: string;
    value: any;
    giasFormControlName: string;
    isdisabled: boolean;
    listItems: Array<any>;
    textField: string;
    valueField: string;
    valuePrimitive: boolean;
    multiple: boolean;
    valueChange: EventEmitter<any>;
    selection: ButtonGroupSelection;
    disable: boolean;
    obligatory: boolean;
    private form;
    private fc;
    constructor(controlContainer: ControlContainer);
    ngOnInit(): void;
    ngAfterViewChecked(): void;
    change(val: any): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<GiasButtonGroupTemplateComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GiasButtonGroupTemplateComponent, "gias-button-group-template", never, { "name": { "alias": "name"; "required": false; }; "value": { "alias": "value"; "required": false; }; "giasFormControlName": { "alias": "giasFormControlName"; "required": false; }; "isdisabled": { "alias": "isdisabled"; "required": false; }; "listItems": { "alias": "listItems"; "required": false; }; "textField": { "alias": "textField"; "required": false; }; "valueField": { "alias": "valueField"; "required": false; }; "valuePrimitive": { "alias": "valuePrimitive"; "required": false; }; "multiple": { "alias": "multiple"; "required": false; }; }, { "valueChange": "valueChange"; }, never, never, false, never>;
}
