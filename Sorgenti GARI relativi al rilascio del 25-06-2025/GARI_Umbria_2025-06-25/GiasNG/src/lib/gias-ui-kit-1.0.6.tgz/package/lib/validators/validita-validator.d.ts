import { AbstractControl, ValidationErrors, Validator } from '@angular/forms';
export declare class ValiditaValidator implements Validator {
    validate(control: AbstractControl): ValidationErrors;
}
