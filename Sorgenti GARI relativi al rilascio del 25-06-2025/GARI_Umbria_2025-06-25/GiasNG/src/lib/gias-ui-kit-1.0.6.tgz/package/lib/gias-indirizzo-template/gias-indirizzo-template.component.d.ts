import { OnInit } from '@angular/core';
import { ControlValueAccessor, FormGroup } from '@angular/forms';
import { GiasIstatService } from '../utils/gias-istat.service';
import { Provincia, Comune, CodiciNazioniISO3166 } from '../utils/models';
import * as i0 from "@angular/core";
export declare class GiasIndirizzoTemplateComponent implements OnInit, ControlValueAccessor {
    private istatService;
    form: FormGroup;
    giasFormGroupName: string;
    indirizzoFormValue: string;
    frazioneLabel: string;
    frazioneObbligatorio: boolean;
    Provincie: Provincia[];
    Comuni: Comune[];
    Stati: CodiciNazioniISO3166[];
    indirizzoForm: FormGroup;
    onTouched: () => void;
    constructor(istatService: GiasIstatService);
    writeValue(val: any): void;
    registerOnChange(fn: any): void;
    registerOnTouched(fn: any): void;
    setDisabledState?(isDisabled: boolean): void;
    ngOnInit(): Promise<void>;
    ComuneChange(): Promise<void>;
    ProvinciaChange(): Promise<void>;
    StatoChange(): Promise<void>;
    static ɵfac: i0.ɵɵFactoryDeclaration<GiasIndirizzoTemplateComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GiasIndirizzoTemplateComponent, "gias-indirizzo-template", never, { "form": { "alias": "indirizzo"; "required": false; }; "giasFormGroupName": { "alias": "giasFormGroupName"; "required": false; }; }, {}, never, never, false, never>;
}
