import { OnDestroy, OnInit, TemplateRef } from '@angular/core';
import { DrawerComponent } from "@progress/kendo-angular-layout";
import { Subject } from "rxjs";
import { FormControl, FormGroup } from "@angular/forms";
import { enum_TipoControllo } from '../utils/models';
import * as i0 from "@angular/core";
export interface giasGenericFormControl<T> {
    label: FormControl<String>;
    value: FormControl<T | T[]>;
    listItems: FormControl<T[]>;
    fieldType: FormControl<enum_TipoControllo>;
    tooltip: FormControl<String>;
}
export declare class FilterFieldFormGroupFactory {
    constructor();
    create<T>(label?: string, value?: T | Array<T>, filedType?: enum_TipoControllo, listItems?: Array<T>, tooltip?: string): FormGroup<giasGenericFormControl<T>>;
}
/**
 *
 * @UsageNotes
 * To correctly render the component, please add the sequent style
 * ```
 * { position: absolute; z-index: 1000; right: 0px !important; }
 * ```
 */
export declare class GiasSideFiltersTemplateComponent implements OnInit, OnDestroy {
    drawer: DrawerComponent;
    /**
     * Template containing the elements to show inside the side page. Must be passed as a `<ng-template>`.
     * @Example
     * In the parent component's html:
     * ```
     *  <app-side-filters-template [filtersTemplate]="filtersForm"></app-side-filters-template>
     *  ...
     *  <ng-template #filtersForm>
     *    ...
     *  </ng-template>
     * ```
     */
    filtersTemplate: TemplateRef<any> | null;
    /**
     * FormGroup containing the controls to show in the side page.
     * The controls should be of type {@link giasGenericFormControl} and can be created with the class
     * {@link FilterFieldFormGroupFactory}.
     * This method is still a bit unstable. The use of `filtersTemplate` is advised.
     * @beta
     */
    filtersFormGroup: FormGroup | null;
    /**
     * Emits when clicking on the search button.
     */
    search: Subject<void>;
    /**
     * Defines if the filters should be applied on the press of the search button.
     */
    shouldApply: boolean;
    protected drawerWidth: number;
    protected displayButton: boolean;
    protected signal: Subject<void>;
    protected faSearch: import("@fortawesome/fontawesome-common-types").IconDefinition;
    protected faClose: import("@fortawesome/fontawesome-common-types").IconDefinition;
    protected faFilters: import("@fortawesome/fontawesome-common-types").IconDefinition;
    constructor();
    ngOnInit(): void;
    ngOnDestroy(): void;
    getFiltersFields(): any[];
    onOpenFilters(): void;
    onCancel(): void;
    applyFilters(): void;
    centerVisual(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<GiasSideFiltersTemplateComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GiasSideFiltersTemplateComponent, "gias-side-filters-template", never, { "filtersTemplate": { "alias": "filtersTemplate"; "required": false; }; "filtersFormGroup": { "alias": "filtersFormGroup"; "required": false; }; }, { "search": "search"; }, never, never, false, never>;
}
