export declare function getOrigins(): string;
