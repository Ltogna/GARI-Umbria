import { OperatorFunction } from "rxjs";
import { rispostaStandard } from "./models";
export declare function as<R>(): OperatorFunction<unknown, R>;
export declare function asStandard<R>(): OperatorFunction<unknown, rispostaStandard<R>>;
