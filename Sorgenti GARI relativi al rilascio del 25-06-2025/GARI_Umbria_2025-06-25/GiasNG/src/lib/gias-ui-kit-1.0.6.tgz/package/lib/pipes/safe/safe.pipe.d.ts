import { PipeTransform } from '@angular/core';
import { DomSanitizer, SafeResourceUrl } from '@angular/platform-browser';
import * as i0 from "@angular/core";
export declare class GiasSafePipe implements PipeTransform {
    private sanitizer;
    constructor(sanitizer: DomSanitizer);
    transform(url: string): SafeResourceUrl;
    static ɵfac: i0.ɵɵFactoryDeclaration<GiasSafePipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<GiasSafePipe, "safe", false>;
}
