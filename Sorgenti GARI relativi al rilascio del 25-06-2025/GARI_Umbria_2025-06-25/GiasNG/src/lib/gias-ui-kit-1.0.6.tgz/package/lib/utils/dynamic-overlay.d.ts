import { Overlay, OverlayKeyboardDispatcher, OverlayPositionBuilder, ScrollStrategyOptions, OverlayRef, OverlayOutsideClickDispatcher } from '@angular/cdk/overlay';
import { ComponentFactoryResolver, Injector, NgZone, RendererFactory2 } from '@angular/core';
import { DynamicOverlayContainer } from './dynamic-overlay-container.service';
import { Directionality } from '@angular/cdk/bidi';
import { Location as Location_2 } from '@angular/common';
import * as i0 from "@angular/core";
export declare class DynamicOverlay extends Overlay {
    private readonly _dynamicOverlayContainer;
    private renderer;
    constructor(scrollStrategies: ScrollStrategyOptions, _overlayContainer: DynamicOverlayContainer, _componentFactoryResolver: ComponentFactoryResolver, _positionBuilder: OverlayPositionBuilder, _keyboardDispatcher: OverlayKeyboardDispatcher, _injector: Injector, _ngZone: NgZone, _document: any, _directionality: Directionality, rendererFactory: RendererFactory2, _location: Location_2, _outsideClickDispatcher: OverlayOutsideClickDispatcher);
    private setContainerElement;
    createWithDefaultConfig(containerElement: HTMLElement): OverlayRef;
    static ɵfac: i0.ɵɵFactoryDeclaration<DynamicOverlay, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<DynamicOverlay>;
}
