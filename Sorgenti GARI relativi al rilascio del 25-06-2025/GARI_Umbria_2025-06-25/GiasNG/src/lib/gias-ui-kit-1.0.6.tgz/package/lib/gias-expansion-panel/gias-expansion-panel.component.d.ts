import { EventEmitter, OnDestroy, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ExpansionPanelActionEvent } from '@progress/kendo-angular-layout';
import { GiasExpansionPanelService, IPanelCookie } from './gias-expansion-panel.service';
import { IUsernameService } from '../utils/username.service';
import * as i0 from "@angular/core";
export declare class GiasExpansionPanelComponent implements IPanelCookie, OnInit, OnDestroy {
    private userService;
    private service;
    private router;
    /**
   * Per impostare il header occore utilizzare il selettore CSS 'headerContent'
   * come nel esempio. Queste righe di codice saranno utilizzate dentro
   * kendoExpansionPanelTitleDirective.
   * <div headerContent class="header-content">
   *   <span><strong> Titolo </strong></span>
   * </div>
   */
    id: string;
    disabled: boolean;
    isExpanded: boolean;
    willStoreCookies: boolean;
    action: EventEmitter<ExpansionPanelActionEvent>;
    constructor(userService: IUsernameService, service: GiasExpansionPanelService, router: Router);
    ngOnInit(): Promise<void>;
    private applyCookies;
    private getCookieToken;
    ngOnDestroy(): Promise<void>;
    onAction(event: ExpansionPanelActionEvent): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<GiasExpansionPanelComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GiasExpansionPanelComponent, "gias-expansionpanel", never, { "id": { "alias": "id"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "isExpanded": { "alias": "isExpanded"; "required": false; }; "willStoreCookies": { "alias": "willStoreCookies"; "required": false; }; }, { "action": "action"; }, never, ["[headerContent]", "*"], false, never>;
}
