import { TemplateRef } from '@angular/core';
import { TranslocoService } from '@jsverse/transloco';
import { DialogAction, DialogCloseResult, DialogRef, DialogResult, DialogService } from '@progress/kendo-angular-dialog';
import { Observable } from 'rxjs';
import * as i0 from "@angular/core";
export declare class Actions extends DialogAction {
    returnObj: Object;
    primary?: boolean;
    constructor(text: string, retObject: Object, isPrimary?: boolean);
}
export declare class DialogBooleanResult extends DialogCloseResult {
    returnObj: boolean;
}
export declare enum Dialog_Type {
    error = 1,
    warning = 2,
    info = 3,
    success = 4
}
export declare class GiasDialogService {
    private dialogService;
    private translocoService;
    private get onlyOk();
    private get confirmAndCancel();
    constructor(dialogService: DialogService, translocoService: TranslocoService);
    /**
     *
     * @param title
     * @param content
     * @param actions i pulsanti che definiscono le opzioni possibili. Se non specificate verranno visualizzati i pulsanti 'Conferma' e 'Annulla'.
     * @param width
     * @param height
     * @param preventAction
     * @param dialog_type
     * @param maxHeight
     * @param maxWidth
     */
    dialogMessageObs_Result(title: string, content: string | TemplateRef<any> | Function, actions?: Array<Actions>, width?: number | string, height?: number | string, preventAction?: (p: DialogBooleanResult) => boolean, dialog_type?: number, maxHeight?: string | number, maxWidth?: string | number): Observable<DialogResult>;
    dialogMessageRef(title: string, content: string | TemplateRef<any> | Function, actions?: Array<Actions>, width?: number | string, height?: number | string, preventAction?: (p: DialogBooleanResult | DialogAction, i?: DialogRef) => boolean, dialog_type?: number, maxHeight?: string | number, maxWidth?: string | number): DialogRef;
    alertMessage(content: string | TemplateRef<any>, preventAction?: (p: DialogResult) => boolean, dialog_type?: number | Dialog_Type, maxHeight?: string | number, maxWidth?: string | number): Observable<DialogResult>;
    /**
     * @param title titolo finestra di dialogo
     * @param content messaggio di errore
     * @param transloco usare transloco? (Default: true)
     */
    baseError(title: string, content: string | TemplateRef<any>, transloco?: boolean): void;
    /**
     * @param title titolo finestra di dialogo
     * @param content messaggio di errore
     * @param transloco usare transloco? (Default: true)
     * @return promessa che si adempie alla chiusura del dialog
     */
    errorPromise(title: string, content: string | TemplateRef<any>, transloco?: boolean): Promise<DialogResult>;
    /**
     * Mostra un messaggio di avviso con pulsanti di scelta Annulla/Conferma.
     * @param title titolo finestra di dialogo
     * @param content richiesta interazione utente
     * @param transloco usare transloco? (Default: true)
     * @param preventAction a predicate that verifies if the pressed dialog action should be prevented
     * @return promessa contenente l'azione selezionata
     * @usageNotes Per controllare che l'utente ha cliccato su conferma controllare il campo <code>returnObj</code> dell'oggetto restituito.
     */
    baseWarning(title: string, content: string | TemplateRef<any>, transloco?: boolean, preventAction?: (p: DialogBooleanResult) => boolean): Promise<DialogResult>;
    /**
     * Mostra un messaggio di avviso con pulsanti di scelta Annulla/Conferma.
     * @param title titolo finestra di dialogo
     * @param content richiesta interazione utente
     * @param transloco usare transloco? (Default: true)
     * @param preventAction a predicate that verifies if the pressed dialog action should be prevented
     * @param mapToBoolean se impostato a true, ritorna `true` in caso l'utente abbia cliccato su Conferma, `false` altrimenti.
     * @return observable contenente l'azione selezionata
     */
    warningObs(title: string, content: string | TemplateRef<any>, transloco?: boolean, preventAction?: (p: DialogBooleanResult) => boolean, mapToBoolean?: boolean): Observable<DialogResult | boolean>;
    /**
     * Mostra un messaggio di avviso con pulsanti di scelta Annulla/Conferma.
     * Esegue le azioni specificate in base alla scelta dell'utente.
     * @param title titolo finestra di dialogo
     * @param content richiesta interazione utente
     * @param transloco usare transloco? (Default: true)
     * @param ifConfirm funzione da eseguire in caso di scelta tasto 'Conferma'
     * @param ifCancel funzione da eseguire in caso di scelta tasto 'Annulla'
     * @param preventAction a predicate that verifies if the pressed dialog action should be prevented
     */
    warningThen(title: string, content: string | TemplateRef<any>, transloco?: boolean, ifConfirm?: () => void, ifCancel?: () => void, preventAction?: (p: DialogBooleanResult) => boolean): void;
    /**
     * @param title titolo finestra di dialogo
     * @param content messaggio di errore
     * @param transloco usare transloco? (Default: true)
     */
    baseInfo(title: string, content: string | TemplateRef<any>, transloco?: boolean): DialogRef;
    /**
     * @param title titolo finestra di dialogo
     * @param content messaggio di errore
     * @param transloco usare transloco? (Default: true)
     */
    baseSuccess(title: string, content: string | TemplateRef<any>, transloco?: boolean, timeout?: boolean): Promise<DialogResult>;
    salvataggioOk(extraText?: string): Promise<DialogResult>;
    private extractContent;
    static ɵfac: i0.ɵɵFactoryDeclaration<GiasDialogService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<GiasDialogService>;
}
