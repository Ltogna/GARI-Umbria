import { InjectionToken } from "@angular/core";
import { DynamicOverlay } from "./dynamic-overlay";
import { Observable } from "rxjs";
import { LoadingComponentObject } from "./models";
import * as i0 from "@angular/core";
export declare const LOADING_TOKEN: InjectionToken<LoadingService>;
export declare class LoadingService {
    private dynamicOverlay;
    private timeout;
    private loadingObject;
    private isLoadingSource;
    currentIsLoading: Observable<LoadingComponentObject>;
    private overlayComponentRef;
    private isAlreadyLoading;
    constructor(dynamicOverlay: DynamicOverlay);
    private handleLoading;
    private handleShowLoading;
    private handleHideLoading;
    set_isLoading(loadingObject: LoadingComponentObject): void;
    get_isLoading(): LoadingComponentObject;
    static ɵfac: i0.ɵɵFactoryDeclaration<LoadingService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<LoadingService>;
}
