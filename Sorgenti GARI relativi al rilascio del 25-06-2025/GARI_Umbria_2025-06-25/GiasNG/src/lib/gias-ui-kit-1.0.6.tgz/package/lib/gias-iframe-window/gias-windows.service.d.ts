import { WindowService, WindowSettings } from "@progress/kendo-angular-dialog";
import { IGiasMasterService } from '../utils/gias-master.service';
import * as i0 from "@angular/core";
export declare class GiasWindowsService {
    private windowService;
    private masterService;
    private templateRef;
    functionMessageEventListener: any;
    constructor(windowService: WindowService, masterService: IGiasMasterService);
    open(settings: WindowSettings, messageEventListener?: boolean): import("@progress/kendo-angular-dialog").WindowRef;
    static ɵfac: i0.ɵɵFactoryDeclaration<GiasWindowsService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<GiasWindowsService>;
}
