import { DecimalPipe } from '@angular/common';
import { PipeTransform } from '@angular/core';
import * as i0 from "@angular/core";
export declare class GiasJoinPipe implements PipeTransform {
    private decimalpipe;
    private locale_id;
    constructor(decimalpipe: DecimalPipe, locale_id: string);
    transform(input: Array<any>, sep?: string, field?: string, formatNumbertolocal?: boolean, digitsInfo?: string): string;
    private convertNumberValueColumnCombobox;
    static ɵfac: i0.ɵɵFactoryDeclaration<GiasJoinPipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<GiasJoinPipe, "join", false>;
}
