import { Observable } from 'rxjs';
import * as i0 from "@angular/core";
export declare class GiasMultiSelectTemplateService {
    private MultiSelectValueObject;
    private MultiSelectValueObjectSource;
    currentMultiSelectValueObject: Observable<MultiSelectFormItem>;
    setMultiSelectValue(MultiSelectValueObject: MultiSelectFormItem): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<GiasMultiSelectTemplateService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<GiasMultiSelectTemplateService>;
}
export declare class MultiSelectFormItem {
    FormControlName: string;
    Values: Array<any>;
    newValue: any;
}
