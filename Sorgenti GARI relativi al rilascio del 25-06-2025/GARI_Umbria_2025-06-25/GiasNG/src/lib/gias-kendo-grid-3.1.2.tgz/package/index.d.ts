/**
 * Generated bundle index. Do not edit.
 */
/// <amd-module name="gias-kendo-grid" />
export * from './public-api';
