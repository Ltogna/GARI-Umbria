import * as i0 from '@angular/core';
import { InjectionToken, Component, Injectable, Optional, Inject, EventEmitter, Input, Output, ViewChild, ViewEncapsulation, ChangeDetectionStrategy, ViewContainerRef, Pipe, ElementRef, ContentChildren, ContentChild, Directive, SecurityContext, NgModule, forwardRef } from '@angular/core';
import * as i3 from '@angular/common';
import { NgStyle, DatePipe, CommonModule, DOCUMENT } from '@angular/common';
import * as i15 from '@progress/kendo-angular-dateinputs';
import { DateInputsModule, DateRangeModule } from '@progress/kendo-angular-dateinputs';
import { LayoutModule } from '@progress/kendo-angular-layout';
import * as i14 from '@progress/kendo-angular-inputs';
import { InputsModule } from '@progress/kendo-angular-inputs';
import * as i13 from '@progress/kendo-angular-buttons';
import { ButtonsModule } from '@progress/kendo-angular-buttons';
import * as i5 from '@progress/kendo-angular-label';
import { LabelModule } from '@progress/kendo-angular-label';
import * as i6$1 from '@progress/kendo-angular-dropdowns';
import { DropDownsModule } from '@progress/kendo-angular-dropdowns';
import * as i11 from '@progress/kendo-angular-grid';
import { ColumnBase, ColumnComponent, CommandColumnComponent, CheckboxColumnComponent, GridModule, PDFModule, ExcelModule } from '@progress/kendo-angular-grid';
import * as i2$2 from '@angular/forms';
import { FormControl, FormGroupDirective, ControlContainer, FormGroup, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { A11yModule } from '@angular/cdk/a11y';
import { ClipboardModule } from '@angular/cdk/clipboard';
import { DragDropModule } from '@angular/cdk/drag-drop';
import { PortalModule } from '@angular/cdk/portal';
import * as i5$1 from '@angular/cdk/scrolling';
import { ScrollingModule } from '@angular/cdk/scrolling';
import { CdkStepperModule } from '@angular/cdk/stepper';
import { CdkTableModule } from '@angular/cdk/table';
import { CdkTreeModule } from '@angular/cdk/tree';
import { faUser, faEdit, faTrashAlt, faCog, faAlignJustify, faSave, faTrash, faInfo, faTimes, faPlusSquare, faCopy, faCheckCircle, faCaretDown, faEllipsis, faTrashCan, faClose } from '@fortawesome/free-solid-svg-icons';
import * as i1$1 from '@jsverse/transloco';
import { TranslocoService, toNumber, TranslocoModule } from '@jsverse/transloco';
import * as i7$1 from '@progress/kendo-angular-tooltip';
import { TooltipDirective, TooltipModule } from '@progress/kendo-angular-tooltip';
import { process, filterBy, distinct, aggregateBy } from '@progress/kendo-data-query';
import { Subject, BehaviorSubject, Observable, takeUntil as takeUntil$1, from, ReplaySubject, take, onErrorResumeNext, EMPTY, zip, lastValueFrom, map as map$1, filter as filter$1, fromEvent, of, tap as tap$1 } from 'rxjs';
import * as i2$1 from 'gias-ui-kit';
import { CELL_TYPES, Dialog_Type, LOADING_TOKEN, GIAS_PARAMETRI_AGENDA_TOKEN, Enum_DBTypeOperation, DropdownEventType, GIAS_USERNAME_TOKEN, GIAS_API_SERVICE_TOKEN, GiasDialogService, GiasUikitModule, enum_ErroreGias_Tipo, ErroreGias_Severity, GIAS_MASTER_SERVICE_TOKEN, LoadingService } from 'gias-ui-kit';
import { skip, takeUntil, tap, map, concatAll, catchError, filter, take as take$1 } from 'rxjs/operators';
import { cloneDeep, isBoolean, isNumber, isString } from 'lodash';
import * as i1 from '@progress/kendo-angular-notification';
import * as i2 from 'ngx-cookie-service';
import '@progress/kendo-angular-intl/locales/fr/calendar';
import '@progress/kendo-angular-intl/locales/pt/calendar';
import * as i4 from '@progress/kendo-angular-intl';
import * as i6 from 'ngx-webstorage';
import * as i9 from '@angular/router';
import { RouterModule, ActivatedRoute } from '@angular/router';
import * as i2$3 from '@progress/kendo-angular-dialog';
import { DialogCloseResult } from '@progress/kendo-angular-dialog';
import * as i7 from '@fortawesome/angular-fontawesome';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import * as i6$2 from '@angular/cdk-experimental/scrolling';
import { ScrollingModule as ScrollingModule$1 } from '@angular/cdk-experimental/scrolling';
import * as i2$4 from '@progress/kendo-angular-menu';
import { MenusModule } from '@progress/kendo-angular-menu';
import { NavigationModule } from '@progress/kendo-angular-navigation';
import * as i1$3 from '@angular/common/http';
import { HttpClientModule, HttpClientJsonpModule, HttpHeaders } from '@angular/common/http';
import { TreeViewModule } from '@progress/kendo-angular-treeview';
import * as i1$2 from '@angular/platform-browser';
import * as i4$1 from '@progress/kendo-angular-listview';
import { ListViewModule } from '@progress/kendo-angular-listview';
import { inflate } from 'pako';
import * as i1$4 from '@angular/cdk/overlay';
import { OverlayContainer, Overlay } from '@angular/cdk/overlay';
import * as i3$1 from '@angular/cdk/bidi';

const PIVASUPERUSER_COLDIRETTI = "05644051004";
const AGRODATAINIZIO = new Date(1900, 0, 1, 0, 0, 0, 0);
const AGRODATAFINE = new Date(2100, 11, 31, 0, 0, 0, 0);
var AGRODATAINIZIO_SERVER_STR = "1899-12-31T23:00:00";
var AGRODATAFINE_SERVER_STR = "2100-12-30T23:00:00";
const LOCALIZATION_LANGUAGES = ['it', 'en', 'fr', 'pt'];
// Tipo fabbricati destinazioni Tabella 'Mov_Destinazioni'
const TIPO_DESTINAZIONE_IMPIANTO = 0;
const TIPO_DESTINAZIONE_MAGAZZINO = 20;
const TIPO_DESTINAZIONE_VASCA = 13;
const MAGAZZINO = 20;
const STALLA = 15;
const CONSISTENZA = 18;
const VASCA_ENOLOGICA = 13;
const CELLA_FRIGORIFERA = 16;
const SILOS = 17;
const TIPO_DESTINAZIONE_RAGGRUPPAMENTO_STALLA = 21;
const ESSICCATOIO = 222;
const TIPO_DESTINAZIONE_ANIMALE = 1;
// CATEGORIE MAGAZZINO
const RIGA_DESCRIZIONE_LIBERA = 502;
const RIGA_DESCRIZIONE_LIBERA_DES = 'Riga Descrizione Libera';
const ALTRI_BENI_AMMORTIZZABILI = 500;
const ALTRI_BENI = 501;
const ALTRI_BENI_DES = 'Altri Beni Strumentali';
const SERVIZI = 555;
const SERVIZI_DES = 'Servizi';
const CORPI_ESTRANEI = -50;
const CALI_LAVORAZIONE = -1;
const ELEMCOD_MANODOPERA = 0;
const MACCHINE = 1;
const CARBURANTI = 2;
const RIFIUTI = 4;
const FERTILIZZANTI = 3;
const FORMULATI = 191;
const COADIUVANTI = 195;
const INSETTI = 196;
const TRAPPOLE = 197;
const INNESCHI = 198;
const SEMENTI = 10;
const ALTRE_MATERIE = 200;
const ZOO_CONSISTENZA = 300;
const SEMILAVORATI_VEGETALI = 201;
const MATERIE_VEGETALI = 204;
const BENI_CONFEZ_VEGETALE = 205;
const TRASFORMATI_VEGETALI = 210;
const SEMILAVORATI_ANIMALI = 301;
const MATERIE_ANIMALI = 304;
const BENI_CONFEZ_ANIMALE = 305;
const TRASFORMATI_ANIMALI = 310;
const MANGIMI = 306;
const FARMACI = 307;
const CONFEZIONI_PRODOTTI = 400;
const RICAMBI = 401;
const RIGA_DESCRIZIONE = 502;
const CAT_MAG_SERVIZI_PROFESSIONALI = 700;
// =====================================================================================================
//Elenco dei Cod_Rapporto (codici dei rapporti contabili di base)
// Esiste anche Enum <see cref="TipiEnumerativi.enum_Rapporti_Contabili_Standard"/>
const COD_LEGALE = -1;
const COD_CLIENTE = -2;
const COD_FORNITORE = -3;
const COD_CLIENTE_FORNITORE = -23; //fittizio, usato come raggruppamento nel gias online
const COD_DIPENDENTE = -4;
const COD_TERZISTA = -5;
const COD_DIPENDENTE_TERZISTA = -45; //fittizio, usato come raggruppamento nel gias online
const COD_TECNICO = -6;
const COD_CENTRO_MACCHINE = -7;
const COD_LAB_ANALISI = -8;
//creati x fruttagel ma mai usati
//export const COD_SOCIO_CONFERENTE = -1001
//export const COD_COOP_CONFERENTE = -1002
//export const COD_PRODUTTORE_ASSOCIATO_COOP = -1003
//export const COD_PRODUTTORE_INDIVIDUALE = -1004
const COD_SOCIO = -9; // socio della ditta, titolare
const COD_TRASPORTATORE = -10;
const COD_CLIENTEFORNITORE = -11;
const COD_CLIENTE_FORNITORE_BolleAccett = -11; //utilizzato nelle bolle di accettazione, ad esempio da fruttagel
const COD_TECNICORESPONSABILE = -12;
const COD_AGENTE = -13;
const COD_REFERENTEAZIENDALE = -14;
const COD_CONSULENTE = -15;
const COD_SPEDIZIONIERE = -16;
const COD_VIVAIO = -17;
const COD_CONFERENTE = -18;
const COD_LAB_CQ = -19;
const COD_CAPO_AREA = -20;
const COD_AVVENTIZIO = -21;
const COD_SMALTITORE = -22;
const COD_FORNITORE_ORTOFRUTTA = -24;
const COD_ORGANISMO_REFERENTE = -25;
const COD_RAPPRESENTANTE_FISCALE = -26;
const COD_COADIUVANTE_FAMILIARE = -27;
const COD_ORGANISMO_CONTROLLO = -28;
const COD_RIFERIMENTO_TRASFERIMENTO_DATI = -29;
//=====================================================================================================
// =====================================================================================================
const LAVCOD_ALIMENTAZIONE_DISTRIBUZIONE_MANUALE_FORAGGI = 3020;
const LAVCOD_ALIMENTAZIONE_DISTRIBUZIONE_MECCANICA_FORAGGI = 3021;
const LAVCOD_ALIMENTAZIONE_DISTRIBUZIONE_MANUALE_MANGIMI = 3022;
const LAVCOD_ALIMENTAZIONE_DISTRIBUZIONE_MECCANICA_MANGIMI = 3023;
const LAVCOD_CONCIA_SEME = 13;
const LAVCOD_DISERBO = 18;
const LAVCOD_TRATTAMENTO_ANTIPARASSITARIO = 74;
const LAVCOD_TRATTAMENTO_FITOREGOLATORE = 103;
const LAVCOD_DISTRIBUZIONE_INSETTI = 116;
const LAVCOD_CONFUSIONE_SESSUALE = 118;
const LAVCOD_DISORIENTAMENTO_SESSUALE = 121;
const LAVCOD_GEODISINFESTAZIONE = 155;
const LAVCOD_DISSECCAMENTO = 158;
const LAVCOD_CATTURE_MASSA = 122;
const LAVCOD_TRATTAMENTO_POST_RACCOLTA = 163;
const LAVCOD_INSTALLAZIONE_TRAPPOLE = 107;
const LAVCOD_REINNESCO_TRAPPOLE = 150;
const LAVCOD_ARATURA = 8;
const LAVCOD_ANDANAMENTO = 9;
const LAVCOD_FERTIRRIGAZIONE = 26;
const LAVCOD_DISTRIBUZIONE_CONCIME = 14;
const LAVCOD_CONCIMAZIONE_FOGLIARE = 123;
const LAVCOD_DISTRIBUZIONE_AMMENDANTI = 124;
const LAVCOD_SARCHIATURA_CONCIMAZIONE = 156;
const LAVCOD_TRATTAMENTO_ANTIBUTTERATURA = 106;
const LAVCOD_ASPORTAZIONE_ORGANI_INFETTI = 120;
const LAVCOD_ASSOLCATURA = 10;
const LAVCOD_CARICO_MANUALE_FRUTTA = 78;
const LAVCOD_CIMATURA = 12;
const LAVCOD_DIRADAMENTO_MANUALE = 17;
const LAVCOD_DISSODAMENTO = 19;
const LAVCOD_ERPICATURA = 21;
const LAVCOD_ERPICATURA_ROTANTE = 157;
const LAVCOD_ESPIANTO = 81;
const LAVCOD_ESTIRPATURA = 22;
const LAVCOD_FALCIACONDIZIONATURA = 23;
const LAVCOD_FALCIATURA_ERBAI = 25;
const LAVCOD_FORMAZIONE_ARGINELLI = 27;
const LAVCOD_FRANGIZOLLATURA = 31;
const LAVCOD_FRESATURA = 32;
const LAVCOD_GEBIATURA = 152;
const LAVCOD_IMBALLO_FIENO_ROTOLI = 33;
const LAVCOD_INTERRAMENTO_PAGLIE = 34;
const LAVCOD_INTERVENTO_ANTIBRINA = 161;
const LAVCOD_LAVORAZIONE_CONBINATA = 154;
const LAVCOD_LAVORAZIONE_TRA_FILA = 82;
const LAVCOD_LAVORAZIONE_SU_FILA = 83;
const LAVCOD_LEGATURA = 84;
const LAVCOD_LIVELLAMENTO = 40;
const LAVCOD_MANUTENZIONE_ARGINI = 41;
const LAVCOD_MESSA_DIMORA_PIANTE = 85;
const LAVCOD_MIETITREBBIATURA = 46;
const LAVCOD_MINIMUM_TILLAGE = 47;
const LAVCOD_PACCIAMATURA = 48;
const LAVCOD_POTATURA_SECCA = 87;
const LAVCOD_POTATURA_VERDE = 88;
const LAVCOD_PRESSATURA = 49;
const LAVCOD__RACCOLTA_LEGNA_POTATURA = 90;
const LAVCOD_RANGHINATURA = 53;
const LAVCOD_RINCALZATURA = 55;
const LAVCOD_RIPPATURA = 115;
const LAVCOD_RIPUNTATURA = 56;
const LAVCOD_RIVOLTAMENTO_FORAGGIO = 57;
const LAVCOD_ROMPICROSTA = 153;
const LAVCOD_RULLATURA = 58;
const LAVCOD_SARCHIATURA = 59;
const LAVCOD_SCARIFICATURA = 62;
const LAVCOD_SCASSO = 63;
const LAVCOD_TRINCIATURA = 75;
const LAVCOD_VANGATURA = 76;
const LAVCOD_ZAPPATURA = 77;
const LAVCOD_RACCOLTA_MANUALE = 91;
const LAVCOD_RACCOLTA_MECCANICA = 92;
const LAVCOD_RILIEVO_PRODUZIONE_E_DATA_RACCOLTA = 125;
const LAVCOD_STRIGLIATURA = 167;
const LAVCOD_PIRODISERBO = 168;
const LAVCOD_ALTRE_OPERAZIONI = 162;
const LAVCOD_ABBATTIMENTOIMPIANTI = 170;
const LAVCOD_CONFUSIONE_DISORIENTAMENTO_SESSUALE = 172;
const SMARTPHONE_WIDTH = 1000;
const NessunDpiNessunaEtichetta = "-999";
const NessunDpi = "0";
const DpiBio = "-2";
//VISIBILITA'
const SACOD_NOFILTRO = -99;
const PRIVATO = 0;
const PUBBLICO = -1;
const LinkQdCAngular = "/QdC/";
const LinkVisiteEditAngular = "/QdC/Visite-Edit";
//Valore standard per escludere le microgiacenze
const QTA_GiancenzeVisualizzate = 0.00009;
const Qta_Ha_Distribuibile_Prodotto = 1000000;
const Qta_Ha_Distribuibile_Prodotto_Ricette = 1000000;
const timeZones = {
    "Dateline Standard Time": "",
    "UTC-11": "",
    "Hawaiian Standard Time": "",
    "Aleutian Standard Time": "",
    "Marquesas Standard Time": "",
    "Alaskan Standard Time": "",
    "UTC-09": "",
    "Pacific Standard Time (Mexico)": "",
    "UTC-08": "",
    "Pacific Standard Time": "",
    "US Mountain Standard Time": "",
    "Mountain Standard Time": "",
    "Mountain Standard Time (Mexico)": "",
    "Yukon Standard Time": "",
    "Central America Standard Time": "",
    "Central Standard Time": "",
    "Central Standard Time (Mexico)": "",
    "Easter Island Standard Time": "",
    "Canada Central Standard Time": "",
    "SA Pacific Standard Time": "",
    "Eastern Standard Time (Mexico)": "",
    "Eastern Standard Time": "",
    "Haiti Standard Time": "",
    "US Eastern Standard Time": "",
    "Cuba Standard Time": "",
    "Turks And Caicos Standard Time": "",
    "Paraguay Standard Time": "",
    "Venezuela Standard Time": "",
    "Central Brazilian Standard Time": "",
    "SA Western Standard Time": "",
    "Atlantic Standard Time": "",
    "Pacific SA Standard Time": "",
    "Newfoundland Standard Time": "",
    "Tocantins Standard Time": "",
    "E. South America Standard Time": "",
    "Argentina Standard Time": "",
    "SA Eastern Standard Time": "",
    "Greenland Standard Time": "",
    "Montevideo Standard Time": "",
    "Magallanes Standard Time": "",
    "Saint Pierre Standard Time": "",
    "Bahia Standard Time": "",
    "UTC-02": "",
    "Mid-Atlantic Standard Time": "",
    "Azores Standard Time": "",
    "Cape Verde Standard Time": "",
    "UTC": "",
    "GMT Standard Time": "",
    "Greenwich Standard Time": "",
    "Sao Tome Standard Time": "",
    "Morocco Standard Time": "",
    "W. Europe Standard Time": "Europe/Rome",
    "Central Europe Standard Time": "",
    "Romance Standard Time": "",
    "W. Central Africa Standard Time": "",
    "Central European Standard Time": "",
    "GTB Standard Time": "",
    "Middle East Standard Time": "",
    "Egypt Standard Time": "",
    "E. Europe Standard Time": "",
    "Syria Standard Time": "",
    "West Bank Standard Time": "",
    "Israel Standard Time": "",
    "South Africa Standard Time": "",
    "FLE Standard Time": "",
    "South Sudan Standard Time": "",
    "Kaliningrad Standard Time": "",
    "Sudan Standard Time": "",
    "Libya Standard Time": "",
    "Namibia Standard Time": "",
    "Jordan Standard Time": "",
    "Arabic Standard Time": "",
    "Turkey Standard Time": "",
    "Arab Standard Time": "",
    "Belarus Standard Time": "",
    "Russian Standard Time": "",
    "E. Africa Standard Time": "",
    "Volgograd Standard Time": "",
    "Iran Standard Time": "",
    "Arabian Standard Time": "",
    "Astrakhan Standard Time": "",
    "Azerbaijan Standard Time": "",
    "Russia Time Zone 3": "",
    "Mauritius Standard Time": "",
    "Saratov Standard Time": "",
    "Georgian Standard Time": "",
    "Caucasus Standard Time": "",
    "Afghanistan Standard Time": "",
    "West Asia Standard Time": "",
    "Ekaterinburg Standard Time": "",
    "Pakistan Standard Time": "",
    "Qyzylorda Standard Time": "",
    "India Standard Time": "",
    "Sri Lanka Standard Time": "",
    "Nepal Standard Time": "",
    "Central Asia Standard Time": "",
    "Bangladesh Standard Time": "",
    "Omsk Standard Time": "",
    "Myanmar Standard Time": "",
    "SE Asia Standard Time": "",
    "Altai Standard Time": "",
    "W. Mongolia Standard Time": "",
    "North Asia Standard Time": "",
    "N. Central Asia Standard Time": "",
    "Tomsk Standard Time": "",
    "North Asia East Standard Time": "",
    "Singapore Standard Time": "",
    "China Standard Time": "",
    "W. Australia Standard Time": "",
    "Taipei Standard Time": "",
    "Ulaanbaatar Standard Time": "",
    "Aus Central W. Standard Time": "",
    "Transbaikal Standard Time": "",
    "Tokyo Standard Time": "",
    "North Korea Standard Time": "",
    "Korea Standard Time": "",
    "Yakutsk Standard Time": "",
    "Cen. Australia Standard Time": "",
    "AUS Central Standard Time": "",
    "E. Australia Standard Time": "",
    "AUS Eastern Standard Time": "",
    "West Pacific Standard Time": "",
    "Tasmania Standard Time": "",
    "Vladivostok Standard Time": "",
    "Lord Howe Standard Time": "",
    "Bougainville Standard Time": "",
    "Russia Time Zone 10": "",
    "Central Pacific Standard Time": "",
    "Magadan Standard Time": "",
    "Norfolk Standard Time": "",
    "Sakhalin Standard Time": "",
    "Russia Time Zone 11": "",
    "New Zealand Standard Time": "",
    "UTC+12": "",
    "Fiji Standard Time": "",
    "Kamchatka Standard Time": "",
    "Chatham Islands Standard Time": "",
    "UTC+13": "",
    "Tonga Standard Time": "",
    "Samoa Standard Time": "",
    "Line Islands Standard Time": ""
};
const FORBIDDEN_CHARS_FOR_NAMES = ['/', '.', '\'', ':', '*', '?', '"', '<', '>', '|'];

/* eslint-disable */
const GRID_HTTP_TOKEN = new InjectionToken('app.grid.http');
class GridParentComponent extends Component {
}
/**
 * Modello Colonne KendoGridColumn
 * N.B. Se si deve aggiungere una nuova proprietà in questa classe che non è compresa tra quelle
 * standard di kendo(ColumnSettings) ricordarsi di aggiungere la nuova proprietà da memorizzare nelle viste della Griglia anche
 * nella funzione GridCustomizationsService.manageCellTypes (prendere come esempio showHTMLAsString).
 */
class KendoGridColumn {
    class = null;
    ddl = null;
    numeric = null;
    boolean = null;
    date = null;
    string = null;
    validators = [];
    editable = null;
    resizable = null;
    sticky = true;
    field = null;
    title = null;
    width = null;
    hidden = null;
    disabledRule;
    filter;
    filterOrdering;
    format = null;
    filterable = null;
    orderIndex = null;
    leafIndex = null;
    includeInChooser = null;
    showHTMLAsString = null;
    media = null;
    customParent = null;
    customFooter;
    style = null;
    footerStyle = null;
    component;
    constructor(required, optional) {
        this.class = optional?.class || null;
        this.ddl = optional?.ddl || null;
        this.numeric = optional?.numeric || null;
        this.boolean = optional?.boolean || null;
        this.date = optional?.date || null;
        this.string = optional?.string || null;
        this.validators = optional?.validators || null;
        this.editable = optional?.editable ?? true;
        this.resizable = optional?.resizable ?? true;
        this.field = required.field;
        this.title = required.title;
        this.width = optional?.width; // || 180;
        this.hidden = optional?.hidden ?? false;
        this.filter = optional?.filter || 'text';
        this.format = optional?.format || null;
        this.filterable = optional?.filterable ?? true;
        this.orderIndex = optional?.orderIndex || 0;
        this.leafIndex = optional?.leafIndex || 0;
        this.includeInChooser = optional?.includeInChooser ?? true;
        this.showHTMLAsString = optional?.showHTMLAsString ?? false;
        this.component = optional?.component ?? null;
        this.media = optional?.media ?? null;
        this.sticky = optional?.sticky ?? false;
        this.style = optional?.style || null;
        this.customParent = optional?.customParent || null;
        this.customFooter = optional?.customFooter || null;
        this.disabledRule = optional?.disabledRule || (() => false);
        this.filterOrdering = optional?.filterOrdering;
    }
}
class KendoGridModel {
}
class ModelEntry {
    type;
    editable;
    format;
    validators;
    editor;
    constructor(type, editable, format, validators, editor) {
        this.type = type;
        this.editable = editable;
        this.format = format;
        this.validators = validators;
        this.editor = editor;
    }
}
class KendoServerResult {
    model;
    columns;
    rows;
    constructor(model, columns, rows) {
        this.model = model;
        this.columns = columns;
        this.rows = rows;
        const newModel = this.model;
        for (const prop in newModel) {
            if (Object.prototype.hasOwnProperty.call(newModel, prop)) {
                if (!newModel[prop]) {
                    continue;
                }
                if (typeof (newModel[prop]?.type) === 'string') {
                    continue;
                }
                switch (newModel[prop].type) {
                    case 'date':
                        newModel[prop].type = CELL_TYPES.DATE;
                        break;
                    case 'datetime':
                        newModel[prop].type = CELL_TYPES.DATETIME;
                        break;
                    case 'number':
                        newModel[prop].type = CELL_TYPES.NUMBER;
                        break;
                    case 'dropdownlist':
                        newModel[prop].type = CELL_TYPES.DROPDOWNLIST;
                        break;
                    case 'string':
                        newModel[prop].type = CELL_TYPES.STRING;
                        break;
                    default:
                        alert('Operation type not yet implemented (value: ' + newModel[prop].type + ')');
                }
            }
        }
        this.model = newModel;
    }
}
class KendoServerResultImpl extends KendoServerResult {
    constructor(model, columns, rows) {
        super(model, columns, rows);
    }
}
class ServerResult {
    kendo_rows;
    kendo_columns;
    kendo_model;
}
class GridInfoCommandEvent {
    action;
    dataItem;
    isNew;
    rowIndex;
    sender;
}
class NumericSettings {
    defaultValue;
    min;
    max;
    format;
    autoCorrect;
    decimals;
    step;
    multiCheckFiltering;
    constructor(settings) {
        this.defaultValue = settings?.defaultValue || 0;
        this.min = settings?.min || 0;
        this.max = settings?.max || Number.MAX_VALUE;
        this.format = settings?.format || 'n2';
        this.autoCorrect = settings?.autoCorrect ?? false;
        this.decimals = settings?.decimals || null;
        this.step = settings?.step || null;
        this.multiCheckFiltering = settings?.multiCheckFiltering || false;
    }
}
class DateSettings {
    defaultValue;
    min;
    max;
    format;
    placeholder;
    constructor(opts) {
        this.defaultValue = opts?.defaultValue || new Date();
        this.min = opts?.min || AGRODATAINIZIO;
        this.max = opts?.max || AGRODATAFINE;
        this.format = opts?.format || 'dd/MM/yyyy';
        this.placeholder = opts?.placeholder || '';
    }
}
class DateTimeSettings {
    defaultValue;
    min;
    max;
    format;
    placeholder;
    constructor(opts) {
        this.defaultValue = opts?.defaultValue || new Date();
        this.min = opts?.min || AGRODATAINIZIO;
        this.max = opts?.max || AGRODATAFINE;
        this.format = opts?.format || 'dd/MM/yyyy HH:mm:ss';
        this.placeholder = opts?.placeholder || '';
    }
}
class StringSettings {
    defaultValue;
    constructor(settings) {
        this.defaultValue = settings?.defaultValue || '';
    }
}
class BooleanSettings {
    defaultValue;
    /** Used together with rightLable to define the labels next to the switch component. */
    leftLabel = "";
    /** Used together with leftLable to define the labels next to the switch component. */
    rightLabel = "";
    constructor(settings) {
        this.defaultValue = settings?.defaultValue || false;
    }
}
class GridCustomizations {
    enabled;
    isSaveDisabledOnDefaultView;
    constructor(options) {
        this.enabled = options?.enabled || false;
        this.isSaveDisabledOnDefaultView = options?.isSaveDisabledOnDefaultView || false;
    }
}
class DropdownList {
    id;
    data;
    defaultValue;
    defaultOpen;
    textField = 'name';
    valueField = 'id';
    valuePrimitive = true;
    loadOnEdit = false;
    descriptionField = '';
    loadFunction;
    itemDisabledFn = () => false;
    loading = false;
    constructor(id, data, defaultValue, defaultOpen) {
        this.id = id;
        this.data = data;
        this.defaultValue = defaultValue;
        this.defaultOpen = defaultOpen;
        // this.data.unshift(new DropdownListItem("-1", "Predefinito"));
    }
}
/**
 * Una dropdown list usata dentro la kendo griglia.
 * @param id - Codice che identifica la dropdown in modo univoco nella pagina.
 * @param formControlName - il nome del campo creato nel formGroup corrispondente a una riga.
 * Ripresenta il codice che identifica univocamente ogni voce della dropdown.
 * @param formControlValue - la descrizione che compare nella cella della dropdown list.
 */
class DropdownListWithForm extends DropdownList {
    formControlName;
    formControlValue;
    reload;
    constructor(id, formControlName, formControlValue, data, defaultValue, defaultOpen, reload = new Subject()) {
        super(id, data, defaultValue, defaultOpen);
        this.formControlName = formControlName;
        this.formControlValue = formControlValue;
        this.reload = reload;
        reload.next(false);
    }
}
class DropdownListItem {
    id;
    name;
    data;
    constructor(id, name, data) {
        this.id = id;
        this.name = name;
        this.data = data;
    }
}
class KendoGridRow {
}
class GridEvent {
    event;
    index;
    constructor(event, index) {
        this.event = event;
        this.index = index;
    }
}
var EditingMode;
(function (EditingMode) {
    EditingMode["IN_LINE"] = "in-line";
    EditingMode["IN_CELL"] = "in-cell";
    EditingMode["IN_PAGE"] = "in-page";
    EditingMode["IN_LINE_BATCH"] = "in-line-batch";
    EditingMode["IN_CELL_BATCH"] = "in-cell-batch";
})(EditingMode || (EditingMode = {}));
var LoaderType;
(function (LoaderType) {
    LoaderType["RESOLVER"] = "resolver";
    LoaderType["HTML"] = "html";
    LoaderType["SERVICE"] = "service";
})(LoaderType || (LoaderType = {}));
class JsonKendoResult {
    kendo_model;
    kendo_rows;
    kendo_columns;
}
class SelectedOpts {
    keys;
    usePartialMatch = false;
    resetPreviousSelection = false;
}
class NextSelection {
    value;
}
class SelectionSettings {
    _setSelected = new BehaviorSubject({ keys: [] });
    getSelectedValue = new BehaviorSubject(null);
    get setSelected() {
        return this._setSelected;
    }
    set setSelected(value) {
        this._setSelected = value;
    }
}
class CustomizedColumnComponent extends ColumnBase {
    applyAutofit;
    field;
}
class RendererGridEvent {
    gridElRef;
    grid;
    event;
}

var enum_logDebugArea;
(function (enum_logDebugArea) {
    enum_logDebugArea[enum_logDebugArea["App"] = 1000] = "App";
    enum_logDebugArea[enum_logDebugArea["Gis"] = 2000] = "Gis";
})(enum_logDebugArea || (enum_logDebugArea = {}));
var enum_logDebugTipo;
(function (enum_logDebugTipo) {
    enum_logDebugTipo[enum_logDebugTipo["SelezioneFeatureNodo"] = 1] = "SelezioneFeatureNodo";
    enum_logDebugTipo[enum_logDebugTipo["LetturaAlbero"] = 2] = "LetturaAlbero";
    enum_logDebugTipo[enum_logDebugTipo["TraceServiceId"] = 3] = "TraceServiceId";
    enum_logDebugTipo[enum_logDebugTipo["TraceSubscribe"] = 4] = "TraceSubscribe";
    enum_logDebugTipo[enum_logDebugTipo["CambioAzienda"] = 5] = "CambioAzienda";
    enum_logDebugTipo[enum_logDebugTipo["LetturaGeoJson"] = 6] = "LetturaGeoJson";
    enum_logDebugTipo[enum_logDebugTipo["TraceComponentId"] = 7] = "TraceComponentId";
})(enum_logDebugTipo || (enum_logDebugTipo = {}));

class UtilsService {
    getPrimitiveValueDDL(value) {
        if (typeof (value) == 'object')
            if (value.hasOwnProperty('id'))
                return value['id'];
            else if (value.hasOwnProperty('codice'))
                return value['codice'];
        return value;
    }
    getPrimitiveValue(obj, field) {
        if (typeof (obj) === 'object')
            return obj[field];
        return obj;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: UtilsService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: UtilsService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: UtilsService, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }] });
const isNullOrUndefined = (obj) => obj == null;
const isUndefined = (obj) => obj === undefined;
const separatoreChiaveAlbero = '§';
const separatoreFiltroAlbero = '<$&§>';
const qualsiasiLogDebug = '*';
function parseServerResult(table) {
    const columns = new Array();
    const model = table.kendo_model;
    table.kendo_columns.forEach(elem => {
        const col = { ...elem };
        col.editable = false;
        if (model[col.field].type === CELL_TYPES.STRING) {
            col.showHTMLAsString = true;
        }
        columns.push(col);
    });
    return {
        columns: columns,
        model: model,
        rows: table.kendo_rows
    };
}
function NumToStr(num) {
    return num + "";
}
function StringToDate(data) {
    var giornoMeseAnno = data.split("/");
    if (giornoMeseAnno[2].includes(' ')) {
        const annoTempo = giornoMeseAnno[2].split(" ");
        const hourMinsSecs = annoTempo[1].split(":");
        return new Date(creaDataConTempo(annoTempo, giornoMeseAnno, hourMinsSecs));
    }
    return new Date(+giornoMeseAnno[2], giornoMeseAnno[1] - 1, +giornoMeseAnno[0]);
}
function DateToString(data) {
    let str = data.toLocaleString();
    let result = str.split(',')[0];
    return result;
}
function creaDataConTempo(annoTempo, giornoMeseAnno, hourMinsSecs) {
    return new Date(+annoTempo[0], giornoMeseAnno[1] - 1, +giornoMeseAnno[0], hourMinsSecs[0], hourMinsSecs[1], hourMinsSecs[2]);
}
function getServiceIdAndLog(nomeServizio, messaggio) {
    const serviceId = Date.now().toString();
    consoleLogDebugParam(enum_logDebugArea.App, enum_logDebugTipo.TraceServiceId, nomeServizio, messaggio, serviceId);
    return serviceId;
}
function getComponentIdAndLog(nomeComponente, messaggio) {
    const componentId = Date.now().toString();
    consoleLogDebugParam(enum_logDebugArea.App, enum_logDebugTipo.TraceComponentId, nomeComponente, messaggio, componentId);
    return componentId;
}
function consoleLogDebug(debugArea, debugTipo, nomeComponenteServizio, messaggio) {
    const tagLogDebug = componiTag(debugArea, debugTipo);
}
function consoleLogDebugParam(debugArea, debugTipo, nomeComponenteServizio, messaggio, param) {
    const tagLogDebug = componiTag(debugArea, debugTipo);
}
function consoleLogDebugMultiParam(debugArea, debugTipo, nomeComponenteServizio, messaggio, param) {
    const tagLogDebug = componiTag(debugArea, debugTipo);
}
function componiTag(debugArea, debugTipo) {
    return (debugArea + debugTipo).toString();
}
//export const TableQdCLink_Old = '/Agenda/MenuBS_WS.asmx/CaricaOperazioni';
const TableQdCLink = 'Agenda/CaricaOperazioni';
class ReadDataFilters {
    filtro;
    piva;
    objP_server;
    objP_utenti;
}
class Filters {
    TipoGriglia;
    xFiltroAggiuntivo_colturali;
    txt_Data1;
    txt_Data2;
    flag_TerrenoNudo;
    sa_cod;
    veg_cod;
    mode;
    ricetta_cod;
    tipoOperazione;
    impianti;
    constructor(params) {
        this.TipoGriglia = params.TipoGriglia;
        this.xFiltroAggiuntivo_colturali = params.xFiltroAggiuntivo_colturali;
        this.txt_Data1 = params.txt_Data1;
        this.txt_Data2 = params.txt_Data2;
        this.flag_TerrenoNudo = params.flag_TerrenoNudo;
        this.sa_cod = params.sa_cod;
        this.veg_cod = params.veg_cod;
        this.mode = params.mode;
        this.ricetta_cod = params.ricetta_cod;
        this.tipoOperazione = params.tipoOperazione;
        this.impianti = params.impianti;
    }
}
class RicetteServerResult extends KendoServerResult {
    constructor(model, columns, rows) {
        super(model, columns, rows);
    }
}
;
class BrogliaccioServerResult extends KendoServerResult {
    constructor(model, columns, rows) {
        super(model, columns, rows);
    }
}
;
function ValidValuesFor(specie, centro) {
    const veg_cod = specie.veg_cod;
    const sa_cod = centro.sa_cod;
    const invalidValues = ['0', ''];
    return invalidValues.includes(veg_cod) && invalidValues.includes(sa_cod);
}
function GetOperazioniParams(objServer) {
    const parametri = {
        objP_server: objServer,
        Flag_OpColturali: true,
        Flag_OpZoo: false,
        Flag_OpMacchine: false,
        Flag_OpContabili: true
    };
    return parametri;
}
function GetCentriParams(obj_server, piva) {
    return {
        'objP_server': obj_server,
        'PrimaRiga_Flag': false,
        'PrimaRiga_Text': '',
        'PrimaRiga_Value': '',
        'Piva': piva,
        'Flag_SoloCentriAttivi': false,
        'Tipo_Value': 2
    };
}
function GetCentriParams_NG(obj_server, piva) {
    return {
        'PrimaRiga_Flag': false,
        'PrimaRiga_Text': '',
        'PrimaRiga_Value': '',
        'Piva': piva,
        'Flag_SoloCentriAttivi': false,
        'Tipo_Value': 2
    };
}
function GetSpeciParams(obj_server, piva) {
    const sa_cod = 0;
    const data_da = new Date('01/01/1900');
    const data_a = new Date('12/31/2100');
    return {
        'PrimaRiga_Flag': false,
        'PrimaRiga_Text': '',
        'PrimaRiga_Value': '',
        'Piva': piva,
        'Sa_Cod': sa_cod,
        'Data_Da': data_da,
        'Data_A': data_a,
        'ConsideraTerrenoNudo': true,
        'leggiAncheBloccati': true
    };
}
/*const links_Old = [
    '/Agenda/Impianti.asmx/LeggiImpianti',
    '/Metaschema/Operazioni.asmx/Leggi_GruppoOperazioni',
    '/AgronicaCoreUtility/CaricaListControl.asmx/LeggiSpecieColtivate',
    '/Anagrafica/CentroAziendale.asmx/LeggiCentriConFiltroUtente'
];*/
const links = [
    'Agenda/LeggiImpianti',
    'MetaschemaNG/Leggi_GruppoOperazioni',
    'Anagrafica/LeggiSpecieVegetaliQdC',
    'AnagraficaNG/LeggiCentriConFiltroUtente'
];
const IMPIANTI_LNK = links[0];
const OPERAZIONI_LNK = links[1];
const SPECI_LNK = links[2];
const CENTRI_LNK = links[3];
// export const lav_cod_non_editabili: number[] = [
//     LAVCOD_ALIMENTAZIONE_DISTRIBUZIONE_MANUALE_FORAGGI, LAVCOD_ALIMENTAZIONE_DISTRIBUZIONE_MECCANICA_FORAGGI,
//     LAVCOD_ALIMENTAZIONE_DISTRIBUZIONE_MANUALE_MANGIMI, LAVCOD_ALIMENTAZIONE_DISTRIBUZIONE_MECCANICA_MANGIMI];
// export const lav_cod_copiabili: number[] = [LAVCOD_CONFUSIONE_SESSUALE, LAVCOD_DISORIENTAMENTO_SESSUALE, LAVCOD_DISTRIBUZIONE_INSETTI,
//     LAVCOD_TRATTAMENTO_ANTIPARASSITARIO, LAVCOD_TRATTAMENTO_FITOREGOLATORE, LAVCOD_CONCIA_SEME, LAVCOD_GEODISINFESTAZIONE, LAVCOD_DISERBO,
//     LAVCOD_DISSECCAMENTO, LAVCOD_TRATTAMENTO_ANTIBUTTERATURA, LAVCOD_CONCIMAZIONE_FOGLIARE, LAVCOD_DISTRIBUZIONE_AMMENDANTI,
//     LAVCOD_DISTRIBUZIONE_CONCIME, LAVCOD_FERTIRRIGAZIONE, LAVCOD_SARCHIATURA_CONCIMAZIONE, LAVCOD_ANDANAMENTO, LAVCOD_ARATURA,
//     LAVCOD_ASPORTAZIONE_ORGANI_INFETTI, LAVCOD_ASSOLCATURA, LAVCOD_CARICO_MANUALE_FRUTTA, LAVCOD_CIMATURA, LAVCOD_DIRADAMENTO_MANUALE,
//     LAVCOD_DISSODAMENTO, LAVCOD_ERPICATURA, LAVCOD_ESTIRPATURA, LAVCOD_ESPIANTO, LAVCOD_FALCIACONDIZIONATURA, LAVCOD_FALCIATURA_ERBAI,
//     LAVCOD_FORMAZIONE_ARGINELLI, LAVCOD_FRANGIZOLLATURA, LAVCOD_FRESATURA, LAVCOD_IMBALLO_FIENO_ROTOLI, LAVCOD_INTERRAMENTO_PAGLIE,
//     LAVCOD_LAVORAZIONE_TRA_FILA, LAVCOD_LAVORAZIONE_SU_FILA, LAVCOD_LEGATURA, LAVCOD_LIVELLAMENTO, LAVCOD_MANUTENZIONE_ARGINI,
//     LAVCOD_MESSA_DIMORA_PIANTE, LAVCOD_MIETITREBBIATURA, LAVCOD_MINIMUM_TILLAGE, LAVCOD_PACCIAMATURA, LAVCOD_POTATURA_SECCA, LAVCOD_POTATURA_VERDE,
//     LAVCOD_PRESSATURA, LAVCOD__RACCOLTA_LEGNA_POTATURA, LAVCOD_RACCOLTA_MANUALE, LAVCOD_RACCOLTA_MECCANICA, LAVCOD_RANGHINATURA, LAVCOD_RINCALZATURA,
//     LAVCOD_RIPPATURA, LAVCOD_RIPUNTATURA, LAVCOD_RIVOLTAMENTO_FORAGGIO, LAVCOD_RULLATURA, LAVCOD_SARCHIATURA, LAVCOD_SCARIFICATURA, LAVCOD_SCASSO,
//     LAVCOD_TRINCIATURA, LAVCOD_VANGATURA, LAVCOD_ZAPPATURA, LAVCOD_GEBIATURA, LAVCOD_ROMPICROSTA, LAVCOD_LAVORAZIONE_CONBINATA,
//     LAVCOD_ERPICATURA_ROTANTE, LAVCOD_INTERVENTO_ANTIBRINA, LAVCOD_ALTRE_OPERAZIONI, LAVCOD_STRIGLIATURA, LAVCOD_PIRODISERBO, LAVCOD_ABBATTIMENTOIMPIANTI];
class RicettaForm {
    dataInizio;
    dataFine;
    numero;
    descrizione;
    nota;
}
class CreateRecipeData {
    lblHtmlRicettaDaCreare;
    piva_ricetta;
    sa_cod;
    id_agenda;
    stesso_vag_cod;
    ErroreSingolaSpecie;
    data_operazione;
    ricettaForm;
    prevent = false;
    constructor() {
        this.ricettaForm = new RicettaForm();
    }
}
class GridMassiveEvent {
    items;
    type;
}
var emun_MassiveEventType;
(function (emun_MassiveEventType) {
    emun_MassiveEventType[emun_MassiveEventType["REMOVE"] = 0] = "REMOVE";
    emun_MassiveEventType[emun_MassiveEventType["LOCK"] = 1] = "LOCK";
})(emun_MassiveEventType || (emun_MassiveEventType = {}));
//export const RicetteNumLink_Old = '/Agenda/MenuBS_WS.asmx/ricetta_numero_default';
const RicetteNumLink = 'Agenda/ricetta_numero_default';
//export const CreateRicettaLink_Old = '/Agenda/MenuBS_WS.asmx/crea_ricetta';
const CreateRicettaLink = 'Agenda/crea_ricetta';
//export const CopiaOperazioneSingola_Old = '/Agenda/MenuBS_WS.asmx/CopiaOperazioneSingola';
const CopiaOperazioneSingola = 'Agenda/CopiaOperazioneSingola';
//export const BloccaAttivitaAgendaLink_Old = '/Agenda/MenuBS_WS.asmx/BloccaAttivitaAgenda';
const BloccaAttivitaAgendaLink = 'Agenda/BloccaAttivitaAgenda';
//export const SbloccaAttivitaAgendaLink_Old = '/Agenda/MenuBS_WS.asmx/SbloccaAttivitaAgenda';
const SbloccaAttivitaAgendaLink = 'Agenda/SbloccaAttivitaAgenda';
class RicettaModalParams {
}
const lav_cod_non_editabili = [
    LAVCOD_ALIMENTAZIONE_DISTRIBUZIONE_MANUALE_FORAGGI, LAVCOD_ALIMENTAZIONE_DISTRIBUZIONE_MECCANICA_FORAGGI,
    LAVCOD_ALIMENTAZIONE_DISTRIBUZIONE_MANUALE_MANGIMI, LAVCOD_ALIMENTAZIONE_DISTRIBUZIONE_MECCANICA_MANGIMI
];
const lav_cod_copiabili = [LAVCOD_CONFUSIONE_SESSUALE, LAVCOD_DISORIENTAMENTO_SESSUALE, LAVCOD_DISTRIBUZIONE_INSETTI,
    LAVCOD_TRATTAMENTO_ANTIPARASSITARIO, LAVCOD_TRATTAMENTO_FITOREGOLATORE, LAVCOD_CONCIA_SEME, LAVCOD_GEODISINFESTAZIONE, LAVCOD_DISERBO,
    LAVCOD_DISSECCAMENTO, LAVCOD_TRATTAMENTO_ANTIBUTTERATURA, LAVCOD_CONCIMAZIONE_FOGLIARE, LAVCOD_DISTRIBUZIONE_AMMENDANTI,
    LAVCOD_DISTRIBUZIONE_CONCIME, LAVCOD_FERTIRRIGAZIONE, LAVCOD_SARCHIATURA_CONCIMAZIONE, LAVCOD_ANDANAMENTO, LAVCOD_ARATURA,
    LAVCOD_ASPORTAZIONE_ORGANI_INFETTI, LAVCOD_ASSOLCATURA, LAVCOD_CARICO_MANUALE_FRUTTA, LAVCOD_CIMATURA, LAVCOD_DIRADAMENTO_MANUALE,
    LAVCOD_DISSODAMENTO, LAVCOD_ERPICATURA, LAVCOD_ESTIRPATURA, LAVCOD_ESPIANTO, LAVCOD_FALCIACONDIZIONATURA, LAVCOD_FALCIATURA_ERBAI,
    LAVCOD_FORMAZIONE_ARGINELLI, LAVCOD_FRANGIZOLLATURA, LAVCOD_FRESATURA, LAVCOD_IMBALLO_FIENO_ROTOLI, LAVCOD_INTERRAMENTO_PAGLIE,
    LAVCOD_LAVORAZIONE_TRA_FILA, LAVCOD_LAVORAZIONE_SU_FILA, LAVCOD_LEGATURA, LAVCOD_LIVELLAMENTO, LAVCOD_MANUTENZIONE_ARGINI,
    LAVCOD_MESSA_DIMORA_PIANTE, LAVCOD_MIETITREBBIATURA, LAVCOD_MINIMUM_TILLAGE, LAVCOD_PACCIAMATURA, LAVCOD_POTATURA_SECCA, LAVCOD_POTATURA_VERDE,
    LAVCOD_PRESSATURA, LAVCOD__RACCOLTA_LEGNA_POTATURA, LAVCOD_RACCOLTA_MANUALE, LAVCOD_RACCOLTA_MECCANICA, LAVCOD_RANGHINATURA, LAVCOD_RINCALZATURA,
    LAVCOD_RIPPATURA, LAVCOD_RIPUNTATURA, LAVCOD_RIVOLTAMENTO_FORAGGIO, LAVCOD_RULLATURA, LAVCOD_SARCHIATURA, LAVCOD_SCARIFICATURA, LAVCOD_SCASSO,
    LAVCOD_TRINCIATURA, LAVCOD_VANGATURA, LAVCOD_ZAPPATURA, LAVCOD_GEBIATURA, LAVCOD_ROMPICROSTA, LAVCOD_LAVORAZIONE_CONBINATA,
    LAVCOD_ERPICATURA_ROTANTE, LAVCOD_INTERVENTO_ANTIBRINA, LAVCOD_ALTRE_OPERAZIONI, LAVCOD_STRIGLIATURA, LAVCOD_PIRODISERBO, LAVCOD_ABBATTIMENTOIMPIANTI,
    LAVCOD_CONFUSIONE_DISORIENTAMENTO_SESSUALE
];
var TabTypes;
(function (TabTypes) {
    TabTypes[TabTypes["QuadernoDiCampagna"] = 0] = "QuadernoDiCampagna";
    TabTypes[TabTypes["Ricette"] = 1] = "Ricette";
    TabTypes[TabTypes["Brogliaccio"] = 2] = "Brogliaccio";
    TabTypes[TabTypes["Initializer"] = null] = "Initializer";
})(TabTypes || (TabTypes = {}));
var RibaltamentoTypes;
(function (RibaltamentoTypes) {
    RibaltamentoTypes[RibaltamentoTypes["Nessuno"] = 0] = "Nessuno";
    RibaltamentoTypes[RibaltamentoTypes["Da_Brogliaccio_ad_Agenda"] = 1] = "Da_Brogliaccio_ad_Agenda";
    RibaltamentoTypes[RibaltamentoTypes["Da_Ricetta_a_Brogliaccio"] = 2] = "Da_Ricetta_a_Brogliaccio";
    RibaltamentoTypes[RibaltamentoTypes["Da_Ricetta_ad_Agenda"] = 3] = "Da_Ricetta_ad_Agenda";
})(RibaltamentoTypes || (RibaltamentoTypes = {}));
class RicettaRow extends KendoGridRow {
    App_Nome;
    APP_Ricetta_Operazione_ID;
    blocco_flag;
    Costi_Macchine;
    Costi_Operatori;
    Descrizione_Unica;
    Dettaglio_Tecnico;
    in_uso;
    Invia_App;
    lav_cod;
    lav_des;
    PermessoModifica;
    piva;
    Ricetta_Cod;
    Ricetta_Des;
    Ricetta_Numero;
    Ricetta_Operazione_Cod;
    Ricetta_Operazione_Data;
    Sa_Cod;
    sa_nome;
    Sup_Trattata;
    Tipo_Ricetta_des;
    Tipo_Ricetta;
    Validita_Fine;
    Validita_Inizio;
    veg_cod_op;
    veg_cod_r;
    veg_des_unificato;
    WAnagraficaStati_Cod;
    WAnagraficaStati_Colore;
}
class QdCRow extends KendoGridRow {
    Appezzamenti_Coinvolti;
    Avversita;
    blocco_flag;
    Centro_Aziendale;
    Centro_Campo;
    chiave_composita;
    contabilizzato;
    Costi_Macchine;
    Costi_Operatori;
    Creatore_Intervento;
    cul_Des;
    Data;
    Data_Ultima_Modifica_Intervento;
    Data2;
    Descrizione_Unica;
    Dettaglio_Tecnico;
    gru_des;
    ID;
    id_agenda;
    id_mov_det;
    Lav_cod;
    Lav_Des;
    LottiImpianto;
    LottiProduzione;
    Note;
    Operazione_DES;
    PermessoModifica;
    Piva;
    Prodotti_Utilizzati;
    Rag_Soc;
    Ricetta_Cod;
    Ricetta_Des;
    sa_cod;
    Specie;
    Specie_Varieta;
    Sup_Trattata;
    tipo;
    Veg_cod;
}
// Errors
const SLIGHTLY_DIFFERENT_CODE_FROM_GIAS2010 = "Manca la gestione di .btnCreaOp. Sembra di essere commentato e non utilizzato in GIAS2010.";
const DA_GESTIRE_PUA = "PUA non gestito";
const DA_GESTIRE_PIANO_DISTRIBUZIONE_CONCIMI = "non gestito";
class ImpostazioniApp {
    ImportaSoloAziendaSelezionata;
    SincroDatiApp;
}
function isQdCRow(x) {
    return !!x.Centro_Aziendale && typeof x.Centro_Aziendale === 'string';
}
function isBrogliaccioRow(x) {
    return !!x.Origine && typeof x.Origine === 'string';
}
class GridZooResult extends KendoServerResult {
    constructor(model, columns, rows) {
        super(model, columns, rows);
    }
}
;
class ZooModel extends KendoGridModel {
}
;
class ZooRow extends KendoGridRow {
    id_mov_det;
    id_agenda;
    Data2;
    Lav_Des;
    Prodotti_Utilizzati;
    Dettaglio_Tecnico;
    Centro_Aziendale;
    chiave_composita;
    tipo;
    Data;
    contabilizzato;
    LottiProduzione;
    Note;
    Costi_Operatori;
    Costi_Macchine;
    Creatore_Intervento;
    ID;
    Lav_cod;
    blocco_flag;
    Piva;
    sa_cod;
    Operazione_DES;
    Prodotti;
    Rag_Soc;
    PermessoModifica;
    Descrizione_Unica;
}
//export const Link_ElimOpMultipla_Old = '/Agenda/MenuBS_WS.asmx/elimina_operazione_multipla';
const Link_ElimOpMultipla = 'Agenda/EliminaOperazioneMultipla';
function construisciChiaviComposite(rows) {
    if (rows.length == 1) {
        let chiave = rows[0].chiave_composita + "_" + rows[0].Piva;
        return chiave;
    }
    else {
        let chiavi = "";
        for (var row of rows) {
            chiavi += row.chiave_composita + "_" + row.Piva + ',';
        }
        if (chiavi !== "") {
            //elimino l'ultima virgola
            chiavi = chiavi.slice(0, -1);
        }
        return chiavi;
    }
}
// grid commands
var enum_menuAgendaGridCommands;
(function (enum_menuAgendaGridCommands) {
    enum_menuAgendaGridCommands[enum_menuAgendaGridCommands["RICERCA_DOCUMENTI"] = 0] = "RICERCA_DOCUMENTI";
    enum_menuAgendaGridCommands[enum_menuAgendaGridCommands["NUOVO_ALLEGATO"] = 1] = "NUOVO_ALLEGATO";
    enum_menuAgendaGridCommands[enum_menuAgendaGridCommands["VAI_AI_COSTI"] = 2] = "VAI_AI_COSTI";
    enum_menuAgendaGridCommands[enum_menuAgendaGridCommands["COPIA"] = 3] = "COPIA";
    enum_menuAgendaGridCommands[enum_menuAgendaGridCommands["AGGIUNGI_RICETTA"] = 4] = "AGGIUNGI_RICETTA";
    enum_menuAgendaGridCommands[enum_menuAgendaGridCommands["STAMPA_RICETTA"] = 5] = "STAMPA_RICETTA";
    enum_menuAgendaGridCommands[enum_menuAgendaGridCommands["STAMPA_ORDINE_LAVORO"] = 6] = "STAMPA_ORDINE_LAVORO";
    enum_menuAgendaGridCommands[enum_menuAgendaGridCommands["BROGLIACCIO"] = 7] = "BROGLIACCIO";
    enum_menuAgendaGridCommands[enum_menuAgendaGridCommands["QUADERNO_DI_CAMPAGNA"] = 8] = "QUADERNO_DI_CAMPAGNA";
    enum_menuAgendaGridCommands[enum_menuAgendaGridCommands["INFO"] = 9] = "INFO";
    enum_menuAgendaGridCommands[enum_menuAgendaGridCommands["MODIFICA"] = 10] = "MODIFICA";
    enum_menuAgendaGridCommands[enum_menuAgendaGridCommands["CANCELLA"] = 11] = "CANCELLA";
    enum_menuAgendaGridCommands[enum_menuAgendaGridCommands["VAI_AL_PIANO_CONCIMAZIONE"] = 12] = "VAI_AL_PIANO_CONCIMAZIONE";
    enum_menuAgendaGridCommands[enum_menuAgendaGridCommands["IMPORTA_NEL_PUA"] = 13] = "IMPORTA_NEL_PUA";
    enum_menuAgendaGridCommands[enum_menuAgendaGridCommands["VAI_ALLA_VISITA"] = 14] = "VAI_ALLA_VISITA";
})(enum_menuAgendaGridCommands || (enum_menuAgendaGridCommands = {}));
class GridCommandItem {
    actionName;
    action;
    iconClass;
    fontawesomeIcon;
    isStatic;
    paramsforTrasloco;
    constructor(actionName, action, iconClass, fontawesomeIcon, isStatic = true, paramsforTrasloco = null) {
        this.actionName = actionName;
        this.action = action;
        this.iconClass = iconClass;
        this.fontawesomeIcon = fontawesomeIcon;
        this.isStatic = isStatic;
        this.paramsforTrasloco = paramsforTrasloco;
    }
}

// pass in property to validate and list of validators to run on it
function validateProperty(property, validators) {
    return (control) => {
        // get the value and assign it to a new form control
        let utilityFns = new UtilsService();
        let propertyVal = null;
        if (control.value != null)
            propertyVal = utilityFns.getPrimitiveValue(control.value, property);
        const newFc = new FormControl(propertyVal);
        // run the validators on the new control and keep the ones that fail
        let failedValidators = null;
        failedValidators = validators.map(v => v(newFc)).filter(v => !!v);
        // if any fail, return the list of failures, else valid
        return failedValidators.length ? { 'invalidProperty': failedValidators } : null;
    };
}
class PropertyValidator {
    property;
    validatorFn;
    row;
    // Bisogna estendere il validatore in modo tale di permettere aggiungere più
    // di un validatore.
    validators = [];
    constructor(property, validatorFn) {
        this.property = property;
        this.validatorFn = validatorFn;
    }
    validate(control) {
        let customValidator = this.validatorFn(this.row);
        if (customValidator.name !== REQUIRED_VALIDATOR_NAME)
            throw Error(`The name of the validator fn must be ${REQUIRED_VALIDATOR_NAME}`);
        if (!this.validators.some(s => s.name === REQUIRED_VALIDATOR_NAME)) {
            this.validators.push(customValidator);
        }
        return validateProperty(this.property, this.validators)(control);
    }
    setCurrentRow(row) {
        this.row = row;
        this.resetValidators();
    }
    resetValidators() {
        this.validators = [];
    }
}
const UNNAMED_FN = '';
class PropertyValidatorFields {
}
const REQUIRED_VALIDATOR_NAME = 'customValidator';

const QryParamsResolver = new InjectionToken('Interface for handling http operations on the grid public service');
function mapDateFilter(descriptor, model, columns) {
    const filters = descriptor.filters || [];
    filters.forEach((filter) => {
        if (filter.filters) {
            mapDateFilter(filter, model, columns);
        }
        else if ((model[filter.field].type === CELL_TYPES.DATE || model[filter.field].type === CELL_TYPES.DATETIME) &&
            findColumn(columns, filter) != null && filter.value &&
            !(filter.value instanceof Date)) {
            filter.value = new Date(filter.value);
        }
    });
}
;
function findColumn(columns, filter) {
    return columns.find(c => c.field === filter.field);
}
const getCircularReplacer$1 = () => {
    const seen = new WeakSet();
    return (key, value) => {
        if (typeof value === 'object' && value !== null) {
            if (seen.has(value)) {
                return;
            }
            seen.add(value);
        }
        return value;
    };
};
function scrollToFirstColumn(parentName) {
    const pattern = '#' + parentName + ' th:first-child';
    document.querySelectorAll(pattern).forEach(item => item.scrollIntoView());
}
function columnAlreadyInView(inCols, curCols) {
    return inCols.some((inCol) => curCols.some(cur => cur === inCol));
}
function findMatchedIndex(key, rows, rowId, opts) {
    let index;
    if (opts.usePartialMatch)
        index = rows.findIndex(s => s[rowId].includes(key));
    else
        index = rows.findIndex(s => s[rowId] === key);
    return index;
}
function resetSelection(rows) {
    rows?.forEach(s => s['Selected'] = false);
}
function _isNull(value) {
    return value == null || Number.isNaN(value);
}

class GridPublicService extends BehaviorSubject {
    qryParamServices;
    /* Section 1 */
    clearGridPublicService() {
        this.formGroup = new BehaviorSubject(null);
        this.multiIndex = null;
        this.gridPrivate = null;
        this.changeDetected = new Subject();
        this.detachedSaveBtn = new Subject();
        this.multiIndex = null;
        this.freeMultiIndex = true;
        this.selection.setSelected = new BehaviorSubject({ keys: [] });
        this.gridElRef = null;
        this.signal$ = null;
    }
    /*
    *@description:
    * Utilizzato nelle grid di tipo Master Detail indica il dataItem della Riga Master che ha generato la griglia di Detail
    * (cambia per ogni griglia di detail)
    * */
    _Current_Grid_Master_RowExpanded;
    get Current_Grid_Master_RowExpanded() {
        return cloneDeep(this._Current_Grid_Master_RowExpanded);
    }
    set Current_Grid_Master_RowExpanded(RowExpanded) {
        this._Current_Grid_Master_RowExpanded = RowExpanded;
    }
    /// Il FormGroup della riga che viene modificata.
    /// Permette di aggiungere validatori e fare verifiche.
    formGroup = new BehaviorSubject(null);
    signal$;
    /** A new value is emitted when pressing a row's commands' dropdown button.
     * @valueEmitted the row's dataItem
     */
    openCommands = new BehaviorSubject(null);
    /** A new value is emitted when pressing a command from the commands'
     * dropdown button.
     * @valueEmitted object containing `command`, `dataItem` and `rowIndex`
     * @usageNotes to select the right command use a `switch` over command.action
     * the base events can be found in the enumeration `CommandsDropDownEvents`.
     * Other events should be declared as constant numbers.
     *
     * @example
     * ```
     * this.gridPublicSerivce.commandEvent.GiasSubscribe(ev => {
            if (!ev) return;
            switch (ev.command.action) {
                case CommandsDropDownEvents.FULL_EDIT:
                    this.onTemplateBtnClick(ev.dataItem);
                    break;
            }
        })
     * ```
     */
    commandEvent = new BehaviorSubject(null);
    // ! End public API
    multiIndex;
    // ! Private API.
    gridPrivate;
    // ! End private API
    gridElRef;
    gridComp;
    giasGridComponent;
    changeDetected = new Subject();
    detachedSaveBtn = new Subject();
    resetChanges$ = new Subject();
    freeMultiIndex = true;
    /** Setter and getter of newly selected values */
    selection = new SelectionSettings();
    currentDataItem;
    /** Contiene gli ultimi filtri applicati alle colonne della griglia.
     * @UsageNotes Possibile ricavare le righe filtrate tramite: <code>process(this.rows, { filter: this.grid.filter }).data;</code>
     */
    filters = new BehaviorSubject(null);
    thereIsAForm = false;
    applyViewFiltroJSON = new BehaviorSubject(null);
    afterSaveView = new BehaviorSubject(null);
    keyViewString = new BehaviorSubject(null);
    filtroJSONstring = '';
    constructor(qryParamServices) {
        super(null);
        this.qryParamServices = qryParamServices;
        this.detachedSaveBtn = new Subject();
    }
    ngOnDestroy() {
        this.formGroup.next(null);
        this.resetChanges$.complete();
    }
    changeFormValue(type, controlName, value) {
        switch (type) {
            case FormValueChange.DropdownItem:
                this.gridPrivate.nextDropdownValue(controlName, value, this.formGroup.value);
                break;
            default:
                break;
        }
    }
    /** Disables the editing of the grid.
     * @usageNotes
     * To be able to use this function, both the field `model` and `columns` of the {@link AbstractGridConfigService}
     * must be valorized with the data used in the grid. You can valorize the fields from the `read()` function in
     * your grid's configuration service.
     */
    disable() {
        this.gridPrivate.disable();
    }
    /** Enables the editing of the grid.
     * @usageNotes
     * To be able to use this function, both the field `model` and `columns` of the {@link AbstractGridConfigService}
     * must be valorized with the data used in the grid. You can valorize the fields from the `read()` function in
     * your grid's configuration service.
     */
    enable() {
        this.gridPrivate.enable();
    }
    refresh(forceRefresh = false, newData = null) {
        if (newData)
            this.next({ data: newData, stopPropagation: false, forceRefresh: forceRefresh });
        else
            this.next({ data: this.value?.data, stopPropagation: false, forceRefresh: forceRefresh });
    }
    init(ctx) {
        this.gridPrivate = ctx;
        this.signal$ = ctx.signal;
        this.gridComp = ctx._gridCtx.grid;
        this.qryParamServices?.forEach((service) => {
            service.init(this.signal$);
        });
    }
    /** Executed after the data has been placed inside the grid. */
    dataBinded = false;
    parseQueryParams() {
        if (this.qryParamServices && !this.dataBinded) {
            this.dataBinded = true;
            this.qryParamServices?.forEach((service) => {
                service.execute(this);
            });
        }
    }
    /**
     * Called inside the ngOnInit() life cycle hook of the grid.
     * @param ctx Grid context. Used for unsubscribing and updating grid
     * properties.
     */
    ngOnInit(ctx) {
        this.initializeSubscriptions(ctx);
    }
    initializeSubscriptions(ctx) {
        this.selection.setSelected.pipe(skip(1), takeUntil(this.signal$))
            .subscribe(data => {
            ctx.setSelectedRows({
                keys: data.keys,
                usePartialMatch: data.usePartialMatch,
                resetPreviousSelection: data.resetPreviousSelection
            });
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: GridPublicService, deps: [{ token: QryParamsResolver, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: GridPublicService });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: GridPublicService, decorators: [{
            type: Injectable
        }], ctorParameters: () => [{ type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [QryParamsResolver]
                }] }] });
var FormValueChange;
(function (FormValueChange) {
    FormValueChange[FormValueChange["DropdownItem"] = 1] = "DropdownItem";
})(FormValueChange || (FormValueChange = {}));

function getTime(date) {
    return date != null ? date.getTime() : 0;
}
const comparer = (a, b) => {
    if (a instanceof Date && b instanceof Date) {
        return getTime(a) - getTime(b);
    }
    if (typeof (a) == 'object' && typeof (b) == 'object') {
        return a.name?.localeCompare(b.name);
    }
    if (typeof (a) == 'number' && typeof (b) == 'number') {
        return a - b;
    }
    return a?.localeCompare(b);
};
const GRID_WORKER_URL = new InjectionToken('GRID_WORKER_URL');
class GridWorkerService {
    grid;
    gridWorkerUrl;
    resultsStore = {};
    workLoad = new Subject();
    workerInst;
    alreadySubed = false;
    constructor(grid, gridWorkerUrl) {
        this.grid = grid;
        this.gridWorkerUrl = gridWorkerUrl;
    }
    // ! Used to refresh worker data once a row modification has been made.
    refreshWorker() {
        if (this.grid.changeDetected) {
            this.grid.changeDetected.pipe(takeUntil(this.grid.signal$))
                .subscribe((event) => {
                this.resultsStore = {}; // < force recalculation.
            });
            this.alreadySubed = true;
        }
    }
    // ! Elimina gli elementi dupplicati arrivati come righe della griglia.
    runTaskDistinct(rows, field, type, col, applyOrder) {
        if (typeof Worker !== 'undefined') {
            if (!this.workerInst) {
                const baseHref = document.getElementsByTagName('base')[0].href;
                this.workerInst = new Worker(new URL(this.gridWorkerUrl, baseHref));
                this.workerInst.onmessage = ({ data }) => {
                    this.resultsStore[data.field] = data.rows;
                    this.workLoad.next();
                };
                this.workerInst.onerror = this.onError;
            }
            const msg = {
                type: type, rows: applyOrder ? rows.sort((a, b) => comparer(a, b)) : rows, field: field,
                col: JSON.parse(JSON.stringify(col, getCircularReplacer()))
            };
            this.workerInst.postMessage(msg);
        }
        else {
            let risp;
            switch (type) {
                case 'string':
                    risp = this.distinctPrimitive(rows);
                    break;
                case 'dropdownlist':
                    risp = this.distinctDropdown(rows, col);
                    break;
                case 'multi_dropdownlist':
                    risp = this.distinctDropdown(rows, col);
                    break;
                case 'date':
                    risp = this.distinctDates(rows);
                    break;
                default:
                    throw Error('Data type not recognized: ' + type);
            }
            this.resultsStore[field] = risp;
        }
    }
    // ! Funzioni che gestiscono il caso in cui il worker non è abilitato.
    distinctPrimitive(rows) {
        const data = [...new Set(rows)];
        return data;
    }
    distinctDropdown(rows, col) {
        const result = [];
        const ddl = col.ddl.data;
        const noSelection = { id: '', name: '' };
        rows.forEach(row => {
            const found = ddl.find(item => item.id === row.id);
            if (found) {
                result.push({ id: found.id, name: found.name });
            }
            else {
                result.push(noSelection);
            }
        });
        // Get unique elements of the result.
        const items = result.map(item => {
            const key = item['id']; // < dato per scontato che esiste 'id'
            return [key, item];
        });
        const map = new Map(items);
        const unique = [...map.values()];
        return unique;
    }
    distinctDates(rows) {
        const data = rows.arr.filter((value, index, self) => index === self.findIndex((t) => (t.place === value.place && t.name === value.name)));
        return data;
    }
    // ! Stampa errore.
    onError(e) {
        const msg = [
            'ERROR: Line ', e.lineno, ' in ', e.filename, ': ', e.message
        ].join('');
        console.log(msg);
    }
    // Usually called due to a new data set being read in the grid.
    resetStore() {
        this.resultsStore = {};
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: GridWorkerService, deps: [{ token: GridPublicService }, { token: GRID_WORKER_URL }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: GridWorkerService });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: GridWorkerService, decorators: [{
            type: Injectable
        }], ctorParameters: () => [{ type: GridPublicService }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [GRID_WORKER_URL]
                }] }] });
const getCircularReplacer = () => {
    const seen = new WeakSet();
    return (key, value) => {
        if (typeof value === "object" && value !== null) {
            if (seen.has(value)) {
                return;
            }
            seen.add(value);
        }
        return value;
    };
};

class CustomMessageService {
    contextString;
    action;
    color;
    customFunction;
    getContextString() {
        return this.contextString;
    }
    getAction() {
        return this.action;
    }
    getColor() {
        return this.color;
    }
    getCustomFunction() {
        return this.customFunction;
    }
    createCustomMessage(contextString, action, color, customFunction) {
        this.contextString = contextString;
        this.action = action;
        this.customFunction = customFunction;
        this.color = color;
    }
    getCustomMessageComponent() {
        return CustomMessageComponent;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: CustomMessageService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: CustomMessageService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: CustomMessageService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }] });
class CustomMessageComponent {
    customMessageService;
    message;
    action;
    color;
    customFunction;
    constructor(customMessageService) {
        this.customMessageService = customMessageService;
        this.message = this.customMessageService.getContextString();
        this.action = this.customMessageService.getAction();
        this.color = this.customMessageService.getColor();
        this.customFunction = this.customMessageService.getCustomFunction();
    }
    onClick() {
        this.customFunction();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: CustomMessageComponent, deps: [{ token: CustomMessageService }], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "19.2.9", type: CustomMessageComponent, isStandalone: true, selector: "gias-custom-message-component", ngImport: i0, template: `
    <div [ngStyle]="{ 'color': color }">
        {{ message }} <span (click)="onClick()">{{ action }}</span>
    </div>
    `, isInline: true, dependencies: [{ kind: "directive", type: NgStyle, selector: "[ngStyle]", inputs: ["ngStyle"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: CustomMessageComponent, decorators: [{
            type: Component,
            args: [{
                    standalone: true,
                    selector: "gias-custom-message-component",
                    template: `
    <div [ngStyle]="{ 'color': color }">
        {{ message }} <span (click)="onClick()">{{ action }}</span>
    </div>
    `,
                    imports: [NgStyle]
                }]
        }], ctorParameters: () => [{ type: CustomMessageService }] });

class GiasMessageService {
    notificationService;
    transloco;
    customMessageService;
    hideAfter;
    errorOpen = false;
    errorsVisible = [];
    customMessageComponent;
    constructor(notificationService, transloco, customMessageService) {
        this.notificationService = notificationService;
        this.transloco = transloco;
        this.customMessageService = customMessageService;
    }
    successMessage(content, closable = false, useTransloco = false, translocoParams = [], hideAfter) {
        return this.showMessage('button-notification', 'success', content, closable, useTransloco, translocoParams, hideAfter);
    }
    infoMessagge(content, closable = false, useTransloco = false, translocoParams = [], hideAfter) {
        return this.showMessage('button-notification', 'info', content, closable, useTransloco, translocoParams, hideAfter);
    }
    errorMessage(content, closable = false, useTransloco = false, translocoParams = [], hideAfter) {
        return this.showMessage('button-notification', 'error', content, closable, useTransloco, translocoParams, hideAfter);
    }
    warningMessage(content, closable = false, useTransloco = false, translocoParams = [], hideAfter) {
        return this.showMessage('button-notification', 'warning', content, closable, useTransloco, translocoParams, hideAfter);
    }
    noneMessage(content, closable = false, useTransloco = false, translocoParams = [], hideAfter) {
        return this.showMessage('button-notification', 'none', content, closable, useTransloco, translocoParams, hideAfter);
    }
    setErrorOpen(status) {
        this.errorOpen = status;
        if (!status) {
            this.errorsVisible.forEach(e => e.hide());
        }
    }
    message(messageType, content, closable = false, useTransloco = false, translocoParams = [], hideAfter) {
        switch (messageType) {
            case Dialog_Type.error:
                return this.errorMessage(content, closable, useTransloco, translocoParams, hideAfter);
            case Dialog_Type.warning:
                return this.warningMessage(content, closable, useTransloco, translocoParams, hideAfter);
            case Dialog_Type.info:
                return this.infoMessagge(content, closable, useTransloco, translocoParams, hideAfter);
            case Dialog_Type.success:
                return this.successMessage(content, closable, useTransloco, translocoParams, hideAfter);
            default:
                return this.noneMessage(content, closable, useTransloco, translocoParams);
        }
    }
    customMessage(contentString, actionString, color, customFunction, closable = true, hideAfter) {
        this.customMessageService.createCustomMessage(contentString, actionString, color, customFunction);
        this.customMessageComponent = this.customMessageService.getCustomMessageComponent();
        const toolbarWidth = document.getElementById('gis-toolbar')?.clientWidth;
        return this.notificationService.show({
            content: this.customMessageComponent,
            closable: true,
            cssClass: closable ? "button-notification-custom" : "button-notification-custom-no-close",
            position: { horizontal: 'center', vertical: 'top' },
            type: { style: "info", icon: false },
            width: toolbarWidth
        });
    }
    showMessage(cssClass, style, content, closable = false, useTransloco = false, translocoParams = [], hideAfter) {
        if (useTransloco)
            content = this.transloco.translate(content, translocoParams);
        return this.notificationService.show({
            content: content,
            cssClass: cssClass,
            animation: { type: 'slide', duration: 400 },
            position: { horizontal: 'right', vertical: 'bottom' },
            type: { style: style },
            hideAfter: (!!hideAfter && hideAfter !== 0) ? hideAfter : this.hideAfter,
            closable: closable,
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: GiasMessageService, deps: [{ token: i1.NotificationService }, { token: i1$1.TranslocoService }, { token: CustomMessageService }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: GiasMessageService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: GiasMessageService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: () => [{ type: i1.NotificationService }, { type: i1$1.TranslocoService }, { type: CustomMessageService }] });

class CustomizeDropdownService extends BehaviorSubject {
    transloco;
    giasMessageService;
    defaultItem;
    sourceItems = [];
    constructor(transloco, giasMessageService) {
        super(null);
        this.transloco = transloco;
        this.giasMessageService = giasMessageService;
        this.defaultItem = new DropdownListItem(this.generateUID(), this.transloco.translate('giasgrid.Base'), { Predefinita: true });
    }
    extractDropdownItems(data) {
        const items = [];
        data.forEach((view) => {
            items.push(new DropdownListItem(view.IdVista, view.NomeVista, { Predefinita: view.Predefinita, NomeUtente: view.NomeUtente, GridId: view.GridId }));
        });
        return items;
    }
    generateDropdownId(GridId) {
        return `${GridId}|dropdown`;
    }
    getItemId(GridId, id, NomeUtente) {
        // return `${GridId}-${NomeUtente}-item-${id}`;
        return `${GridId}-${NomeUtente}`;
    }
    getDefaultItem() {
        return this.defaultItem;
    }
    generateUID() {
        //return Math.random().toString(16).slice(2);
        return window.crypto.getRandomValues(new Uint32Array(1))[0].toString(16);
    }
    nextSelected(dropdown) {
        const data = this.value?.dropdown?.data;
        const next = data.filter(d => d.id !== dropdown.id);
        if (next.length) {
            return next[0];
        }
        return dropdown.defaultValue;
    }
    getNewDDL(input, items) {
        const r = Object.assign({}, input);
        r.data = items.slice();
        return r;
    }
    showMessage(message) {
        let translatedMessage = this.transloco.translate(message, {});
        this.giasMessageService.warningMessage(translatedMessage);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: CustomizeDropdownService, deps: [{ token: i1$1.TranslocoService }, { token: GiasMessageService }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: CustomizeDropdownService });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: CustomizeDropdownService, decorators: [{
            type: Injectable
        }], ctorParameters: () => [{ type: i1$1.TranslocoService }, { type: GiasMessageService }] });

const throwError = (message) => { throw new Error(message); };
class ViewBase {
    IdVista;
    GridId;
    NomeUtente;
    Predefinita;
    NomeVista;
    FiltroJSON;
    FlagPubblica;
    constructor(options) {
        this.IdVista = options?.IdVista;
        this.NomeUtente = options?.NomeUtente || 'null';
        this.Predefinita = options?.Predefinita ?? false;
        this.NomeVista = options?.NomeVista || '';
        this.GridId = options?.GridId ?? throwError('Grid Id è obbligatorio.');
        this.Predefinita = options?.Predefinita ?? false;
        this.FiltroJSON = options?.FiltroJSON || "";
        this.FlagPubblica = options?.FlagPubblica || false;
    }
}
class DropdownChanged {
    dropdown;
    selected;
    constructor(dropdown, selected) {
        this.dropdown = dropdown;
        this.selected = selected;
    }
}
class ServerView extends ViewBase {
    Colonne;
    Stato;
    constructor(options) {
        super(options);
        this.Colonne = options?.Colonne || JSON.stringify({});
        this.Stato = options?.Stato || JSON.stringify({});
    }
}
class SelectionChangeEvent {
    item;
    isNew;
    constructor(options) {
        this.isNew = options?.isNew;
        this.item = options?.item;
    }
}
class InMemoryView extends ViewBase {
    Colonne;
    Stato;
    IsModified;
    IsNew;
    constructor(options) {
        super(options);
        this.Colonne = options?.Colonne || null;
        this.Stato = options?.Stato || null;
        this.IsModified = options?.IsModified;
        this.IsNew = options?.IsNew;
    }
}
class ChiaveVista {
    GridId;
    IdVista;
    NomeUtente;
    constructor(GridId, IdVista, NomeUtente) {
        this.GridId = GridId;
        this.IdVista = IdVista;
        this.NomeUtente = NomeUtente;
    }
}
class SalvaVisteWrapper {
    VisteNuove;
    VisteModificate;
    constructor(options) {
        this.VisteNuove = options.VisteNuove;
        this.VisteModificate = options.VisteModificate;
    }
}
class CustomizationRequest {
    dropdownItem;
    isNewView;
}

function parseJson(str) {
    try {
        return JSON.parse(str);
    }
    catch (e) {
        return null;
    }
}

class AgrSelectableSettings {
    selectable;
    columnSettings;
    preselectedRows;
    shouldShowCheckbox;
    get checkboxIsEnabled() {
        return this.selectable.enabled && this.shouldShowCheckbox;
    }
    constructor(selectable, columnSettings, preselectedRows, shouldShowCheckbox) {
        this.selectable = selectable;
        this.columnSettings = columnSettings;
        this.preselectedRows = preselectedRows;
        this.shouldShowCheckbox = shouldShowCheckbox;
        this.selectable = new SelectableSettings({});
        this.columnSettings = new SelectableColumnSettings();
        this.shouldShowCheckbox = false;
        if (!preselectedRows) {
            this.preselectedRows = new PreselectedRowsSettings();
        }
        this.preselectedRows.isRowSelectedFn = () => false;
        this.preselectedRows.selectionChangeFn = () => {
            let a = 0; //Commento per funzione vuota SonarQube
        };
    }
}
/**
 * Angular Documentation SelectableSettings
 * https://www.telerik.com/kendo-angular-ui/components/grid/api/SelectableSettings/
 */
class SelectableSettings {
    /**
     * cell? boolean (default: false)
     * Determines if cell selection is allowed.
     */
    cell;
    /**
     * checkboxOnly? boolean (default: true)
     * Determines if the selection is performed only through clicking a checkbox.
     * If enabled, clicking the row itself will not select the row.
     * Applicable if at least one checkbox column is present.
     */
    checkboxOnly;
    /**
     * drag? boolean (default: false)
     * Determines if drag selection is allowed.
     */
    drag;
    /**
     * enabled? boolean (default: true)
     * Determines if selection is allowed.
     */
    enabled;
    /**
     * mode? SelectableMode (default: "multiple")
     * The available values are: single, multiple
     */
    mode;
    disableAllcheckbox;
    /**
     * metaKeyMultiSelect? boolean (default: true)
     * Determine whether pressing the `Ctrl` or `Command` keys is required for the selection of multiple rows
     * at the same time.
     * Referring to the method of selection over row, not through checkboxes.
     * The selection must be set to `"multiple"` to use this feature.
     */
    metaKeyMultiSelect;
    constructor(opts) {
        this.cell = opts?.cell ?? false;
        this.checkboxOnly = opts?.checkboxOnly ?? true;
        this.drag = opts?.drag ?? false;
        this.enabled = opts?.enabled ?? false;
        this.mode = opts?.mode ?? 'multiple';
        this.disableAllcheckbox = opts?.disableAllcheckbox ?? false;
        this.metaKeyMultiSelect = opts?.metaKeyMultiSelect ?? true;
    }
}
class PreselectedRowsSettings {
    /** For the following functions to work selectable.enabled must be true. */
    /**
     * Questa funziona viene chiamata per tutte le righe.
     */
    isRowSelectedFn;
    /**
     * Viene richiamata per ogni selezione soltanto una volta.
     */
    selectionChangeFn;
    /**
     * Default selected rows.
     * @deprecated
     */
    selectedRows;
    constructor() {
        this.isRowSelectedFn = () => false;
        this.selectionChangeFn = () => {
            let a = 0; //Commento per funzione vuota SonarQube
        };
        this.selectedRows = [];
    }
}
class SelectableColumnSettings {
    /**
     * Determines whether a select-all checkbox will be displayed in the header.
     */
    showSelectAll;
    /**
     * The title of the column.
     */
    title;
    /**
     * The width of the column.
     */
    width;
    /**
     *   Specifies if the column will be included in the column-chooser list.
     */
    includeInChooser;
    /**
     * Sticky selectable column.
     */
    sticky = true;
}
class ToolbarSettings {
    newItem;
    resetChanges;
    title;
    width;
    title_save_button;
    SaveBtn;
    customToolbar;
    constructor(newItem = false, resetChanges = false, title = 'Azioni', width = 150, title_save_button = '', SaveBtn = true, customToolbar = false) {
        this.newItem = newItem;
        this.resetChanges = resetChanges;
        this.title = title;
        this.width = width;
        this.title_save_button = title_save_button;
        this.SaveBtn = SaveBtn;
        this.customToolbar = customToolbar;
    }
    showToolbar() {
        return this.newItem || this.resetChanges || this.customToolbar;
    }
}
class AggregateSettings {
    enabled;
    descriptors;
    constructor(opts) {
        this.enabled = opts?.enabled ?? false;
        this.descriptors = opts?.descriptors ?? [];
    }
}
class GiasAggregateDescriptor {
    field;
    aggregate;
    format;
}
class GroupSettings {
    translocoService;
    groupable;
    constructor(options, translocoService) {
        this.translocoService = translocoService;
        this.groupable = options?.groupable ?? { enabled: false, showFooter: false, emptyText: this.translocoService.translate('giasgrid.grpEmptyMsg') };
    }
}
class CommandsColumnSettings {
    editBtn;
    removeBtn;
    infoBtn;
    title;
    editBtnTitle;
    showEditBtn;
    onDisableInfoBtn;
    onDisableEditBtn;
    onDisableRemoveBtn;
    width;
    locked;
    media;
    sticky = true;
    constructor(options) {
        this.editBtn = options?.editBtn || false;
        this.removeBtn = options?.removeBtn || false;
        this.infoBtn = options?.infoBtn || false;
        this.title = options?.title || 'Comandi';
        this.editBtnTitle = options?.editBtnTitle || 'Modifica';
        this.showEditBtn = options?.showEditBtn || ((row) => false);
        this.onDisableInfoBtn = options?.onDisableInfoBtn || ((row) => false);
        this.onDisableEditBtn = options?.onDisableEditBtn || ((row) => false);
        this.onDisableRemoveBtn = options?.onDisableRemoveBtn || ((row) => false);
        this.width = options?.width || 0;
        this.locked = options?.locked;
        this.media = options?.media || null;
        this.sticky = options?.sticky ?? true;
        /** L'info button viene gestito in un'altra colonna, quindi non devo
         * verificare nulla qui */
        if (this.width === 0) {
            switch (true) {
                case (this.editBtn && this.removeBtn):
                    this.width = 80;
                    break;
                case this.editBtn:
                case this.removeBtn:
                    this.width = 30;
                    break;
                default:
                    this.width = 60;
            }
        }
    }
    showCmdColumn() {
        return this.editBtn || this.removeBtn;
    }
}
var CommandsDropDownEvents;
(function (CommandsDropDownEvents) {
    CommandsDropDownEvents[CommandsDropDownEvents["INLINE_EDIT"] = 8] = "INLINE_EDIT";
    CommandsDropDownEvents[CommandsDropDownEvents["FULL_EDIT"] = 10] = "FULL_EDIT";
    CommandsDropDownEvents[CommandsDropDownEvents["REMOVE"] = 11] = "REMOVE";
    CommandsDropDownEvents[CommandsDropDownEvents["INFO"] = 9] = "INFO";
    CommandsDropDownEvents[CommandsDropDownEvents["COPY"] = 3] = "COPY";
    CommandsDropDownEvents[CommandsDropDownEvents["USER_BIND"] = 12] = "USER_BIND"; // value chosen for compability with enum_menuAgendaGridCommands
})(CommandsDropDownEvents || (CommandsDropDownEvents = {}));
/**
 * Used to configure the grid commands' drop down button.
 *
 * ---
 * **Public APIs**
 *
 * `addCommand` - Adds an item in the dropdown. Takes as input an instance of
 * GridCommandItem.
 *
 * `removeCommand` - Removes an item from the dropdown. Takes as input the
 * command's action to remove.
 *
 * `resetCommands` - resets the commands to their default (only static are visible).
 *
 * `showCmdDropDown` - return whether the dropdown button is visible or not.
 *
 * ---
 * @usageNotes More commands can be added/removed dynamically on the dropdown's
 * opening by subscribing to `openCommands` from GridPublicService.
 */
class CommandsDropDownSettings {
    sticky = true;
    width;
    title;
    inlineEditBtn;
    fullEditBtn;
    removeBtn;
    infoBtn;
    userBindBtn;
    cmdList;
    _cmdList;
    hidecmdDropDown;
    constructor(options) {
        this.inlineEditBtn = options?.inlineEditBtn || false;
        this.fullEditBtn = options?.fullEditBtn || false;
        this.removeBtn = options?.removeBtn || false;
        this.infoBtn = options?.infoBtn || false;
        this.userBindBtn = options?.userBindBtn || false;
        this.title = options?.title || 'Comandi';
        this.width = options?.width || 30;
        this.sticky = options?.sticky ?? true;
        this.cmdList = options?.cmdList || [];
        this._cmdList = options?.cmdList || [];
        this.hidecmdDropDown = options?.hidecmdDropDown || ((row) => false);
        this.addDefaultButtons();
    }
    addCommand(cmd) {
        this.cmdList.push(cmd);
        if (cmd.isStatic)
            this._cmdList.push(cmd);
    }
    addCommandAt(cmd, index) {
        this.cmdList.splice(index, 0, cmd);
        if (cmd.isStatic)
            this._cmdList.splice(index, 0, cmd);
    }
    /** Only removes non-static buttons */
    removeCommand(cmdAction) {
        let index = this.cmdList.findIndex(x => x.action === cmdAction);
        if (index === -1)
            return;
        this.cmdList.splice(index, 1);
        if (cmdAction === CommandsDropDownEvents.FULL_EDIT)
            this.fullEditBtn = false;
        if (cmdAction === CommandsDropDownEvents.INLINE_EDIT)
            this.inlineEditBtn = false;
        if (cmdAction === CommandsDropDownEvents.REMOVE)
            this.removeBtn = false;
        if (cmdAction === CommandsDropDownEvents.INFO)
            this.infoBtn = false;
    }
    ;
    removeAllCommand() {
        if (this.cmdList.findIndex(v => v.action === CommandsDropDownEvents.FULL_EDIT))
            this.fullEditBtn = false;
        if (this.cmdList.findIndex(v => v.action === CommandsDropDownEvents.INLINE_EDIT))
            this.inlineEditBtn = false;
        if (this.cmdList.findIndex(v => v.action === CommandsDropDownEvents.REMOVE))
            this.removeBtn = false;
        if (this.cmdList.findIndex(v => v.action === CommandsDropDownEvents.INFO))
            this.infoBtn = false;
        this.cmdList = [];
        this._cmdList = [];
    }
    ;
    showCmdDropDown() {
        return this.cmdList.length > 0 || this._cmdList.length > 0;
    }
    resetCommands() {
        this.cmdList = cloneDeep(this._cmdList);
    }
    addDefaultButtons() {
        if (this.userBindBtn) {
            this.addCommand(new GridCommandItem("AssociaUtente", CommandsDropDownEvents.USER_BIND, '', faUser));
        }
        if (this.infoBtn) {
            this.addCommand(new GridCommandItem("Informazioni", CommandsDropDownEvents.INFO, "faInfo"));
        }
        if (this.inlineEditBtn) {
            this.addCommand(new GridCommandItem("Modifica", CommandsDropDownEvents.INLINE_EDIT, '', faEdit));
        }
        if (this.fullEditBtn) {
            this.addCommand(new GridCommandItem("ModificaCompleta", CommandsDropDownEvents.FULL_EDIT, 'faEditFull'));
        }
        if (this.removeBtn) {
            this.addCommand(new GridCommandItem("Cancella", CommandsDropDownEvents.REMOVE, '', faTrashAlt));
        }
    }
}
class DettagliColumnSettings {
    editBtn;
    infoBtn;
    title;
    edit;
    onDisableEditBtn;
    width;
    locked;
    sticky = true;
    constructor(options) {
        this.editBtn = options?.editBtn ?? false;
        this.title = options?.title || 'Dettagli';
        this.edit = options?.edit || ((data) => {
            let a = 0; //Commento per funzione vuota SonarQube
        });
        this.onDisableEditBtn = options?.onDisableEditBtn || ((row) => false);
        this.width = options?.width || 156;
        this.locked = options?.locked;
        this.sticky = options?.sticky ?? true;
        this.infoBtn = options?.infoBtn ?? false;
    }
    computeWidth(isMobileWidth, infoBtn) {
        let width = 0;
        const smallBtnWidth = 45;
        const lgBtnWidth = 80;
        const margin = 25;
        if (isMobileWidth) {
            if (this.editBtn)
                width += smallBtnWidth;
            width += margin;
            if (infoBtn)
                width += smallBtnWidth;
        }
        else {
            if (this.editBtn)
                width += lgBtnWidth;
            width += margin;
            if (infoBtn)
                width += smallBtnWidth;
        }
        return width;
    }
}
class CustomColumnSettings {
    title;
    action;
    onDisableActionBtn;
    width;
    locked;
    sticky = true;
    showColumn;
    btnIcon;
    btnTooltip;
    fontawesomeIcon = null;
    headerStyle;
    includeInChooser;
    useCustomColumnCellTemplate;
    useCustomColumnHeaderTemplate;
    showBtn;
    constructor(options) {
        this.title = options?.title || '';
        this.action = options?.action || ((data) => {
            let a = 0; //Commento per funzione vuota SonarQube
        });
        this.onDisableActionBtn = options?.onDisableActionBtn || ((row) => false);
        this.width = options?.width || 156;
        this.locked = options?.locked;
        this.sticky = options?.sticky ?? true;
        this.showColumn = options?.showColumn;
        this.btnIcon = options?.btnIcon ?? 'faEditFull';
        this.btnTooltip = options?.btnTooltip ?? '';
        this.fontawesomeIcon = options?.fontawesomeIcon ?? null;
        this.headerStyle = options?.headerStyle ?? { 'background-color': '#428BCA', color: 'white' };
        this.includeInChooser = options?.includeInChooser ?? true;
        this.useCustomColumnCellTemplate = options?.useCustomColumnCellTemplate ?? false;
        this.useCustomColumnHeaderTemplate = options?.useCustomColumnHeaderTemplate ?? false;
        this.showBtn = options?.showBtn ?? true;
    }
    computeWidth(isMobileWidth, infoBtn) {
        let width = 0;
        const smallBtnWidth = 45;
        const lgBtnWidth = 80;
        const margin = 25;
        width += smallBtnWidth;
        width += margin;
        if (infoBtn)
            width += smallBtnWidth;
        return width;
    }
}
class ResizableSettings {
    isResizable;
    autoFitColumns;
    // public autoSize: boolean = false NON GESTITA
    constructor(isResizable = true, autoFitColumns = true) {
        this.isResizable = isResizable;
        this.autoFitColumns = autoFitColumns;
        if (!this.isResizable) {
            this.autoFitColumns = false;
        }
    }
}
class GeneralSettings {
    height = 700;
    reordable;
    performOnEdit;
}
/*+
* @description:
* Gestisce il master detail della kendo grid
* https://www.telerik.com/kendo-angular-ui/components/grid/master-detail/
* */
class MasterDetailSettings {
    enable = false;
    flag_grid_master = null;
    flag_grid_detail = null;
    showDetailTemplate;
    /*
    *@description: Da valorizzare con il Template Ref della griglia di detail
    * */
    templateGridDetail = null;
    constructor(enable, optional) {
        this.enable = enable;
        this.templateGridDetail = optional?.templateGridDetail;
        this.flag_grid_master = optional?.flag_grid_master ?? true;
        this.flag_grid_detail = optional?.flag_grid_detail ?? true;
        this.showDetailTemplate = optional?.showDetailTemplate || ((dataitem, rowIndex) => true);
    }
    IsGridMaster() {
        return this.enable && this.flag_grid_master;
    }
    IsGridDetail() {
        return this.enable && this.flag_grid_detail;
    }
}
class SortSettings {
    sortable;
    sort;
    /**
     * @param sortable Set to false to disable sorting.
     */
    constructor(sortable, sort) {
        this.sortable = sortable;
        this.sort = sort;
        this.sortable = sortable ?? { allowUnsort: true, mode: SortMode.SINGLE };
    }
    sortEnabled() {
        return this.sortable ?? false;
    }
}
var ScrollingMode;
(function (ScrollingMode) {
    ScrollingMode["None"] = "none";
    ScrollingMode["Scrollable"] = "scrollable";
    ScrollingMode["Virtual"] = "virtual";
})(ScrollingMode || (ScrollingMode = {}));
class VirtualScrollingOpts {
    rowHeight;
    viewportHeight;
}
class PaginationSettings {
    /**
     * @param gridState Initial grid state. Take is page size.
     */
    gridState;
    /**
     * @param pageable If pagination should be applied.
     */
    pageable;
    /**
     * @param navigable Allows to set keyboard shortcuts for navigating the grid.
     */
    navigable;
    scrollingType = ScrollingMode.Scrollable;
    /**
     * Virtual scrolling options.
     */
    virtualScrolling = new VirtualScrollingOpts();
    /**
     * Sets the number of records shown in one page.
     * To do so, it sets the take property of gridState to the provided value n.
     * If gridState is null or undefined, it initializes gridState with default
     * values including setting take to the provided value n.
     * @param n the number of records shown in one page
     */
    take(n) {
        if (this.gridState) {
            this.gridState.take = n;
        }
        else {
            this.gridState = {
                sort: [],
                skip: 0,
                group: [],
                take: n,
                filter: {
                    logic: 'and',
                    filters: [],
                },
            };
        }
    }
}
var DeletionMode;
(function (DeletionMode) {
    DeletionMode[DeletionMode["HandleSingleRowDeletionOnly"] = 0] = "HandleSingleRowDeletionOnly";
    DeletionMode[DeletionMode["HandleEachRowSeparately"] = 1] = "HandleEachRowSeparately";
    DeletionMode[DeletionMode["HandleAllRowsTogether"] = 2] = "HandleAllRowsTogether";
})(DeletionMode || (DeletionMode = {}));
/**
 * Settings for interacting with functionality not UI related.
 */
class BehaviorSettings {
    createFormGroupFromOutside;
    saveExternalChanges;
    excelSettings;
    pdfSettings;
    showDeletionConfirmation;
    deletionMode;
    constructor(opts) {
        this.createFormGroupFromOutside = opts?.createFormGroupFromOutside ?? false;
        this.saveExternalChanges = opts?.saveExternalChanges ?? false;
        this.excelSettings = opts?.excelSettings ?? new ExcelSettings({ enabled: false });
        this.pdfSettings = opts?.pdfSettings ?? new PDFSettings({ enabled: false });
        this.showDeletionConfirmation = false;
        this.deletionMode = opts?.deletionMode ?? DeletionMode.HandleEachRowSeparately;
    }
}
class ExcelSettings {
    enabled;
    constructor(options) {
        this.enabled = options?.enabled ?? true;
    }
}
class PDFSettings {
    enabled;
    allPages;
    constructor(options) {
        this.enabled = options?.enabled ?? true;
        this.allPages = options?.allPages ?? false;
    }
}
class TemplateSettings {
    createNewColumnWithTemplate;
}
class ColumnMenuSettings {
    /**
     * Abilita la colonna del menu a livello globale.
     */
    columnMenu;
    /**
     * Disabilitala colonna menu per colonne specifiche.
     * Questa funzionalità non ancora funziona.
     */
    disabledColumns;
    /**
     * Filtrable. Deve essere true se column menu è abilitato.
     * Set to true to add a new row allowing to sort the grid.
     * Set to 'menu' to add a dropdown list used for sorting.
     */
    filterable;
    /**
     * Mostrare la Kendo Column Chooser. Fare comparire/scomparire alcune colonne.
     */
    kendoGridColumnChooser;
}
class Sortable {
    allowUnsort;
    mode;
}
var SortMode;
(function (SortMode) {
    SortMode["SINGLE"] = "single";
    SortMode["MULTIPLE"] = "multiple";
})(SortMode || (SortMode = {}));
class RemoveMultipleRowsParams {
    data;
}

class GridErrorService {
    loggingAttivo = false;
    infoBGColor = 'background: #BDE5F8; color: #00529B';
    errBGColor = 'background: #FFD2D2; color: #D8000C';
    /**
   * Expensive operation.
   */
    runInDepthAnalysis = false;
    runDataConsistencyChecks(model, columns, righe) {
        if (!this.runInDepthAnalysis) {
            return;
        }
        columns.forEach((column) => {
            const type = model[column.field].type;
            righe.forEach(riga => {
                const value = riga[column.field];
                switch (type) {
                    case CELL_TYPES.STRING:
                    case CELL_TYPES.BOOLEAN:
                    case CELL_TYPES.DROPDOWNLIST:
                        break;
                    case CELL_TYPES.NUMBER:
                        this.checkValidNumber(value, column);
                        break;
                    case CELL_TYPES.DATE:
                        this.checkValidDate(value, column);
                        break;
                    case CELL_TYPES.DATETIME:
                        this.checkValidDate(value, column);
                        break;
                }
            });
        });
    }
    checkThis(func, ...args) {
        if (!this.loggingAttivo) {
            return;
        }
        return (func.bind(this))(...args);
    }
    checkRequiredFields(model, columns, rows) {
        if (model == null) {
            this.logErr('Il modello non è stato impostato!');
        }
        if (columns == null) {
            this.logErr('Le collone non sono state impostate!');
        }
        for (const col of columns) {
            if (model[col.field] == null) {
                this.logErr('E\' stata trovata una colonna che non compare nel modello: ' + col.field);
            }
        }
        for (const col of columns) {
            const modelField = model[col.field];
            if (!modelField) {
                continue;
            }
            switch (model[col.field].type) {
                case CELL_TYPES.DATE:
                    // Deprecated
                    // this.logErr('Cell type is date but settings not provided. Field:' + col.field);
                    break;
                case CELL_TYPES.DATETIME:
                    // Deprecated
                    // this.logErr('Cell type is date but settings not provided. Field:' + col.field);
                    break;
                case CELL_TYPES.NUMBER:
                    if (!col.numeric) {
                        this.logErr('Cell type is numeric but settings not provided. Field: ' + col.field);
                    }
                    break;
                case CELL_TYPES.DROPDOWNLIST:
                    if (!col.ddl) {
                        this.logErr('Dropdown cell type but settings not provided. Field: ' + col.field);
                    }
                    break;
                case CELL_TYPES.STRING:
                    // Nothing to check.
                    break;
                case CELL_TYPES.CUSTOM:
                    // Nothing to check.
                    break;
                default:
                    alert('Not yet implemented. Field type: ' + model[col.field].type);
            }
        }
        this.runDataConsistencyChecks(model, columns, rows);
    }
    modelEntryExists(entryExists, fieldName) {
        if (!entryExists) {
            this.logErr('Il modello manca una collona chiave per il campo col nome: ' + fieldName);
        }
    }
    logErr(msg) {
        if (!this.loggingAttivo) {
            return;
        }
        console.log('%c' + msg, this.errBGColor);
    }
    logInfo(msg, className = '', fnName = '', ...args) {
        if (!this.loggingAttivo) {
            return;
        }
        console.log('%c' + '[' + className + ':' + fnName + ']' + msg, this.infoBGColor);
    }
    generalErrors(errorType, ...args) {
        if (!this.loggingAttivo) {
            return;
        }
        switch (errorType) {
            case GenericErrors.EditingModeNotFound:
                this.logErr('Was not able to find ' + [...args]);
        }
    }
    checkValidDate(value, column) {
        const min = column.date?.min;
        const max = column.date?.max;
        value = new Date(value);
        if (min > max) {
            this.logErr(`Field: ${column.field}. Inconsistent date value: ${value}.`);
            this.logErr(`Missconfigured date: min (${min}) > max (${max})`);
            return;
        }
        if (value != null && value < min || value > max) {
            this.logErr(`Field: ${column.field}. Inconsistent date value: ${value}.`);
            this.logErr(`min: ${column.date.min}, max: ${column.date.max}`);
        }
    }
    checkValidNumber(value, column) {
        const min = column.numeric?.min;
        const max = column.numeric?.max;
        if (min > max) {
            this.logErr(`Column: ${column.field}. Inconsistent date value: ${value}.`);
            this.logErr(`Missconfigured date: min (${min}) > max (${max})`);
            return;
        }
        if (value < min || value > max) {
            this.logErr(`Field: ${column.field}. Inconsistent numeric value: ${value}.`);
            this.logErr(`min: ${column.numeric.min}, max: ${column.numeric.max}`);
        }
    }
    checkGridMasterDetailConfig(masterDetailService, enable_master_detail) {
        if (enable_master_detail && !masterDetailService) {
            this.logErr(`Per utilizzare la funzione di MasterDetail della kendo grid aggiungere nel generategridProviders() della grid principale il provide al KendoGridMasterDetailService`);
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: GridErrorService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: GridErrorService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: GridErrorService, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }] });
var GenericErrors;
(function (GenericErrors) {
    GenericErrors[GenericErrors["EditingModeNotFound"] = 0] = "EditingModeNotFound";
})(GenericErrors || (GenericErrors = {}));

class CodiciTemplate {
    translocoService;
    selectable;
    toolbar;
    cmdColumn;
    cmdDropDown;
    resizable;
    generalSettings;
    sort;
    pagination;
    columnMenu;
    behavior;
    views;
    aggregates;
    groups;
    dettagliColumn;
    masterdetail;
    customColumn;
    constructor(translocoService) {
        this.translocoService = translocoService;
        this.selectable = this.handleSelectable();
        this.toolbar = this.handleToolbarSettings();
        this.cmdColumn = this.handleCmdColumn();
        this.cmdDropDown = this.handleCmdDropDown();
        this.resizable = this.handleResizable();
        this.generalSettings = this.handleGeneralSettings();
        this.sort = this.handleSort();
        this.pagination = this.handlePagination();
        this.columnMenu = this.handleColumnMenu();
        this.masterdetail = new MasterDetailSettings(false);
        this.behavior = new BehaviorSettings({ createFormGroupFromOutside: false });
        this.aggregates = new AggregateSettings({ enabled: false });
        this.views = new GridCustomizations({ enabled: false });
        this.groups = new GroupSettings({ groupable: { enabled: false, showFooter: false } }, this.translocoService);
        this.dettagliColumn = new DettagliColumnSettings({ sticky: true, title: this.translocoService.translate('giasgrid.Dettagli'), width: 100 });
        this.customColumn = new CustomColumnSettings({ sticky: true, title: '', width: 100 });
    }
    handleToolbarSettings() {
        const result = new ToolbarSettings();
        result.newItem = false;
        result.resetChanges = false;
        result.title = 'Azioni';
        result.width = 150;
        return result;
    }
    handleGeneralSettings() {
        const result = new GeneralSettings();
        result.height = 600;
        return result;
    }
    handleCmdColumn() {
        const result = new CommandsColumnSettings({
            editBtn: false,
            infoBtn: false,
            removeBtn: false
        });
        return result;
    }
    handleCmdDropDown() {
        const result = new CommandsDropDownSettings();
        result.inlineEditBtn = true;
        result.infoBtn = true;
        result.removeBtn = true;
        result.title = 'Comandi';
        return result;
    }
    handleResizable() {
        const result = new ResizableSettings();
        result.isResizable = true;
        result.autoFitColumns = false;
        return result;
    }
    handleSelectable() {
        const result = new AgrSelectableSettings();
        result.selectable.enabled = false;
        result.selectable.checkboxOnly = true;
        result.columnSettings = new SelectableColumnSettings();
        result.columnSettings.showSelectAll = false;
        result.columnSettings.title = 'Checkbox';
        result.columnSettings.width = 30;
        return result;
    }
    handleColumnMenu() {
        const columnMenu = new ColumnMenuSettings();
        columnMenu.columnMenu = true;
        columnMenu.filterable = true;
        columnMenu.disabledColumns = [];
        columnMenu.kendoGridColumnChooser = true;
        return columnMenu;
    }
    handleSort() {
        const result = new SortSettings();
        result.sortable = { allowUnsort: true, mode: SortMode.SINGLE };
        result.sort = [];
        return result;
    }
    handlePagination() {
        const result = new PaginationSettings();
        result.gridState = { sort: [], skip: 0, take: 5 };
        result.pageable = true;
        result.navigable = false;
        return result;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: CodiciTemplate, deps: [{ token: i1$1.TranslocoService }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: CodiciTemplate, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: CodiciTemplate, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }], ctorParameters: () => [{ type: i1$1.TranslocoService }] });

class InCellTemplate {
    translocoService;
    selectable;
    toolbar;
    cmdColumn;
    cmdDropDown;
    resizable;
    generalSettings;
    sort;
    pagination;
    columnMenu;
    behavior;
    views;
    aggregates;
    groups;
    dettagliColumn;
    customColumn;
    masterdetail;
    constructor(translocoService) {
        this.translocoService = translocoService;
        this.selectable = this.handleSelectable();
        this.toolbar = this.handleToolbarSettings();
        this.cmdColumn = this.handleCmdColumn();
        this.cmdDropDown = this.handleCmdDropDown();
        this.resizable = this.handleResizable();
        this.generalSettings = this.handleGeneralSettings();
        this.sort = this.handleSort();
        this.pagination = this.handlePagination();
        this.columnMenu = this.handleColumnMenu();
        this.behavior = new BehaviorSettings({});
        this.behavior.createFormGroupFromOutside = false;
        this.behavior.excelSettings = new ExcelSettings({ enabled: true });
        this.behavior.pdfSettings = new PDFSettings({ enabled: false });
        this.aggregates = new AggregateSettings({ enabled: false });
        this.views = new GridCustomizations({ enabled: false });
        this.groups = new GroupSettings({}, this.translocoService);
        this.dettagliColumn = new DettagliColumnSettings({ sticky: true, title: this.translocoService.translate('giasgrid.Dettagli'), width: 100 });
        this.customColumn = new CustomColumnSettings({ sticky: true, title: '', width: 100 });
        this.masterdetail = new MasterDetailSettings(false);
    }
    handleToolbarSettings() {
        const result = new ToolbarSettings();
        result.newItem = false;
        result.resetChanges = false;
        result.title = 'Azioni';
        result.width = 150;
        return result;
    }
    handleGeneralSettings() {
        const result = new GeneralSettings();
        result.height = 600;
        return result;
    }
    handleCmdColumn() {
        const result = new CommandsColumnSettings({
            editBtn: false,
            infoBtn: false,
            removeBtn: false
        });
        return result;
    }
    handleCmdDropDown() {
        const result = new CommandsDropDownSettings();
        result.inlineEditBtn = true;
        result.infoBtn = true;
        result.removeBtn = true;
        result.title = 'Comandi';
        return result;
    }
    handleResizable() {
        const result = new ResizableSettings();
        result.isResizable = true;
        result.autoFitColumns = false;
        return result;
    }
    handleSelectable() {
        const result = new AgrSelectableSettings();
        result.selectable.enabled = false;
        result.columnSettings = new SelectableColumnSettings();
        result.columnSettings.showSelectAll = false;
        result.columnSettings.title = 'Checkbox';
        result.columnSettings.width = 30;
        result.preselectedRows = new PreselectedRowsSettings();
        return result;
    }
    handleColumnMenu() {
        const columnMenu = new ColumnMenuSettings();
        columnMenu.columnMenu = true;
        columnMenu.filterable = true;
        columnMenu.disabledColumns = [];
        columnMenu.kendoGridColumnChooser = true;
        return columnMenu;
    }
    handleSort() {
        const result = new SortSettings();
        result.sortable = { allowUnsort: true, mode: SortMode.SINGLE };
        result.sort = [];
        return result;
    }
    handlePagination() {
        const result = new PaginationSettings();
        result.gridState = {
            sort: [],
            skip: 0,
            take: 5,
            filter: {
                logic: 'and',
                filters: [],
            },
        };
        result.pageable = true;
        result.navigable = false;
        return result;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: InCellTemplate, deps: [{ token: i1$1.TranslocoService }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: InCellTemplate, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: InCellTemplate, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }], ctorParameters: () => [{ type: i1$1.TranslocoService }] });

class InLineTemplate {
    translocoService;
    selectable;
    toolbar;
    cmdColumn;
    cmdDropDown;
    resizable;
    generalSettings;
    sort;
    pagination;
    columnMenu;
    behavior;
    views;
    aggregates;
    groups;
    dettagliColumn;
    customColumn;
    masterdetail;
    constructor(translocoService) {
        this.translocoService = translocoService;
        this.selectable = this.handleSelectable();
        this.toolbar = this.handleToolbarSettings();
        this.cmdColumn = this.handleCmdColumn();
        this.cmdDropDown = this.handleCmdDropDown();
        this.resizable = this.handleResizable();
        this.generalSettings = this.handleGeneralSettings();
        this.sort = this.handleSort();
        this.pagination = this.handlePagination();
        this.columnMenu = this.handleColumnMenu();
        this.behavior = new BehaviorSettings({});
        this.behavior.createFormGroupFromOutside = false;
        this.behavior.excelSettings = new ExcelSettings({ enabled: true });
        this.behavior.pdfSettings = new PDFSettings({ enabled: false });
        this.aggregates = new AggregateSettings({ enabled: false });
        this.views = new GridCustomizations({ enabled: false });
        this.groups = new GroupSettings({}, this.translocoService);
        this.dettagliColumn = new DettagliColumnSettings({ sticky: true, title: this.translocoService.translate('giasgrid.Dettagli'), width: 100 });
        this.customColumn = new CustomColumnSettings({ sticky: true, title: '', width: 100 });
        this.masterdetail = new MasterDetailSettings(false);
    }
    handleToolbarSettings() {
        const result = new ToolbarSettings();
        result.newItem = false;
        result.resetChanges = false;
        result.title = 'Azioni';
        result.width = 150;
        return result;
    }
    handleGeneralSettings() {
        const result = new GeneralSettings();
        result.height = 600;
        return result;
    }
    handleCmdColumn() {
        const result = new CommandsColumnSettings({
            editBtn: true,
            infoBtn: true,
            removeBtn: true
        });
        return result;
    }
    handleCmdDropDown() {
        const result = new CommandsDropDownSettings();
        result.inlineEditBtn = true;
        result.infoBtn = true;
        result.removeBtn = true;
        result.title = 'Comandi';
        return result;
    }
    handleResizable() {
        const result = new ResizableSettings();
        result.isResizable = true;
        result.autoFitColumns = false;
        return result;
    }
    handleSelectable() {
        const result = new AgrSelectableSettings();
        result.columnSettings = new SelectableColumnSettings();
        result.columnSettings.showSelectAll = false;
        result.columnSettings.title = 'Checkbox';
        result.columnSettings.width = 30;
        result.preselectedRows = new PreselectedRowsSettings();
        return result;
    }
    handleColumnMenu() {
        const columnMenu = new ColumnMenuSettings();
        columnMenu.columnMenu = true;
        columnMenu.filterable = true;
        columnMenu.disabledColumns = [];
        columnMenu.kendoGridColumnChooser = true;
        return columnMenu;
    }
    handleSort() {
        const result = new SortSettings();
        result.sortable = { allowUnsort: true, mode: SortMode.SINGLE };
        result.sort = [];
        return result;
    }
    handlePagination() {
        const result = new PaginationSettings();
        result.gridState = {
            sort: [],
            skip: 0,
            take: 5,
            filter: {
                logic: 'and',
                filters: [],
            },
        };
        result.pageable = true;
        result.navigable = false;
        return result;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: InLineTemplate, deps: [{ token: i1$1.TranslocoService }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: InLineTemplate, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: InLineTemplate, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }], ctorParameters: () => [{ type: i1$1.TranslocoService }] });

class DefaultTemplate {
    translocoService;
    selectable;
    toolbar;
    cmdColumn;
    cmdDropDown;
    resizable;
    generalSettings;
    sort;
    pagination;
    columnMenu;
    behavior;
    views;
    aggregates;
    groups;
    dettagliColumn;
    customColumn;
    masterdetail;
    constructor(translocoService) {
        this.translocoService = translocoService;
        this.selectable = this.handleSelectable();
        this.toolbar = this.handleToolbarSettings();
        this.cmdColumn = this.handleCmdColumn();
        this.cmdDropDown = this.handleCmdDropDown();
        this.resizable = this.handleResizable();
        this.generalSettings = this.handleGeneralSettings();
        this.sort = this.handleSort();
        this.pagination = this.handlePagination();
        this.columnMenu = this.handleColumnMenu();
        this.behavior = new BehaviorSettings({
            createFormGroupFromOutside: false,
            excelSettings: new ExcelSettings({ enabled: true }),
            pdfSettings: new PDFSettings({ enabled: false })
        });
        this.behavior.createFormGroupFromOutside = false;
        this.behavior.excelSettings = new ExcelSettings({ enabled: true });
        this.behavior.pdfSettings = new PDFSettings({ enabled: false });
        const grpMsg = 'Trascina un\'intestazione di colonna e rilasciala qui per raggruppare i dati in base a quella colonna';
        this.groups = new GroupSettings({
            groupable: { enabled: true, showFooter: true, emptyText: grpMsg }
        }, this.translocoService);
        this.aggregates = new AggregateSettings({ enabled: false, descriptors: [] });
        this.views = new GridCustomizations({ enabled: true });
        this.dettagliColumn = new DettagliColumnSettings({ sticky: true, title: this.translocoService.translate('giasgrid.Dettagli'), width: 150 });
        this.customColumn = new CustomColumnSettings({ sticky: true, title: '', width: 150 });
        this.masterdetail = new MasterDetailSettings(false);
    }
    handleToolbarSettings() {
        const result = new ToolbarSettings();
        result.newItem = false;
        result.resetChanges = false;
        result.title = 'Azioni';
        result.width = 150;
        return result;
    }
    handleGeneralSettings() {
        const result = new GeneralSettings();
        result.height = 650;
        result.reordable = true;
        return result;
    }
    handleCmdColumn() {
        const result = new CommandsColumnSettings();
        result.editBtn = true;
        result.infoBtn = true;
        result.removeBtn = true;
        result.title = 'Comandi';
        return result;
    }
    handleCmdDropDown() {
        const result = new CommandsDropDownSettings();
        result.inlineEditBtn = true;
        result.infoBtn = true;
        result.removeBtn = true;
        result.title = 'Comandi';
        return result;
    }
    handleResizable() {
        const result = new ResizableSettings();
        result.isResizable = true;
        result.autoFitColumns = false;
        return result;
    }
    handleSelectable() {
        const result = new AgrSelectableSettings();
        result.selectable = new SelectableSettings({});
        result.columnSettings = new SelectableColumnSettings();
        result.columnSettings.showSelectAll = false;
        result.columnSettings.title = 'Checkbox';
        result.columnSettings.width = 40;
        result.preselectedRows = new PreselectedRowsSettings();
        return result;
    }
    handleColumnMenu() {
        const columnMenu = new ColumnMenuSettings();
        columnMenu.columnMenu = true;
        columnMenu.filterable = FilterMenuType.MENU;
        columnMenu.disabledColumns = [];
        columnMenu.kendoGridColumnChooser = true;
        return columnMenu;
    }
    handleSort() {
        const result = new SortSettings();
        result.sortable = { allowUnsort: true, mode: SortMode.MULTIPLE };
        result.sort = [];
        return result;
    }
    handlePagination() {
        const result = new PaginationSettings();
        result.gridState = {
            sort: [],
            skip: 0,
            group: [],
            take: 5,
            filter: {
                logic: 'and',
                filters: [],
            },
        };
        result.pageable = {
            buttonCount: 4,
            info: true,
            type: 'input',
            pageSizes: this.resizable.autoFitColumns ?
                [5, 7, 10, 25, 50] :
                [5, 7, 10, 25, 50, 100, {
                        text: this.translocoService.translate('giasgrid.Tutti'),
                        value: "all",
                    }]
        };
        result.navigable = false;
        return result;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: DefaultTemplate, deps: [{ token: i1$1.TranslocoService }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: DefaultTemplate });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: DefaultTemplate, decorators: [{
            type: Injectable
        }], ctorParameters: () => [{ type: i1$1.TranslocoService }] });
class FilterMenuType {
    static ROW = true;
    static MENU = 'menu';
}
/**
 * Aggiungendo un nuovo template bisgona soltanto aggiornare le due variabili qui sotto.
 */
const serviceMap = {
    DefaultTemplate: DefaultTemplate,
    CodiciTemplate: CodiciTemplate,
    InLineTemplate: InLineTemplate,
    InCellTemplate: InCellTemplate
};
var ConfigTemplate;
(function (ConfigTemplate) {
    ConfigTemplate["DefaultTemplate"] = "DefaultTemplate";
    ConfigTemplate["CodiciTemplate"] = "CodiciTemplate";
    ConfigTemplate["InLineTemplate"] = "InLineTemplate";
    ConfigTemplate["InCellTemplate"] = "InCellTemplate";
})(ConfigTemplate || (ConfigTemplate = {}));

class AbstractGridConfigService {
    /** Emesso onDestory */
    signal = new Subject();
    applyRendererRules(opts) {
        let a = 0; //Commento per funzione vuota SonarQube
    }
    ;
    onRowClass = null;
    /** Parametri opzionali. */
    selectable;
    toolbar;
    cmdColumn;
    cmdDropDown;
    dettagliColumn;
    customColumn;
    resizable;
    generalSettings;
    sort;
    pagination;
    columnMenu;
    behavior;
    views;
    aggregates;
    groups;
    masterdetailSettings;
    /** Configuration wide settings. */
    logService;
    gridPublicService;
    transloco;
    loadingService;
    /** Private params */
    injector;
    constructor(injector, template = ConfigTemplate.DefaultTemplate) {
        this.injector = injector;
        this.logService = injector.get(GridErrorService);
        this.gridPublicService = injector.get(GridPublicService);
        this.transloco = injector.get(TranslocoService);
        this.loadingService = injector.get(LOADING_TOKEN);
        this.init(template);
    }
    async getRemoveMultipleRowsMessage(opts) {
        if (opts.data.length > 1 || this.behavior.showDeletionConfirmation)
            return this.deletionMessage(opts.data);
        const DO_NOT_SHOW_MODAL = "";
        return DO_NOT_SHOW_MODAL;
    }
    deletionMessage(rows) {
        let prefix = '';
        let alsoBrogliaccio = rows.map(row => row?.Origine && row?.Origine.toLowerCase())
            .some(orig => orig === 'demetra');
        if (alsoBrogliaccio) {
            prefix += this.transloco.translate('giasgrid.MenuAgendaActivityDeletionWBrogliaccio') + ' ';
        }
        if (rows.length > 1)
            return prefix + this.transloco.translate('giasgrid.MultipleDeletionConfirmation', [rows.length]);
        else
            return prefix + this.transloco.translate('giasgrid.SoleDeletionConfirmation');
    }
    ngOnDestroy() {
        this.signal.next();
        this.signal.complete();
    }
    model;
    columns;
    /** Used to define if the grid is editable or not.
     * Both the function `disableGrid` and `makeCellsUneditable` depend on the value of this field.
     */
    gridIsEditable;
    /** Shows the action buttons from the command column and the creation button from the toolbar
     * based on the value of `gridIsEditable`.
     */
    disableGrid() {
        this.cmdColumn.removeBtn = this.gridIsEditable;
        this.cmdColumn.editBtn = this.gridIsEditable;
        this.toolbar.newItem = this.gridIsEditable;
    }
    /** Enables/disables every column based on the value of `gridIsEditable`. */
    makeCellsUneditable() {
        if (this.model == null || this.columns == null)
            throw Error("Please initialize the model and columns before calling this method.");
        Object.keys(this.model).forEach(key => this.model[key].editable = this.gridIsEditable);
        this.columns.forEach(s => s.editable = this.gridIsEditable);
    }
    /**
   * Funzioni da eseguire prima dopo vari eventi.
   */
    onCellClose = null;
    onCellClick = null;
    /** Usato per gestire la prevenzione della modifica di una cella. Di default, non previene l'evento.
     * Possibile riassegnare la lambda.
     */
    preventEdit = () => false;
    onCreateExternalFormGroup = null;
    sayHi() {
        this.logService.logInfo('Loaded grid configuration for ' + this['__proto__'].constructor.name);
        this.logService.logInfo('Loader type: ' + this.loader);
    }
    init(tempType) {
        let that = this;
        this.checkIfGridIsEditable();
        Observable.prototype.GiasSubscribe = function (next) {
            const source = this;
            return source.pipe(takeUntil$1(that.signal)).subscribe(next);
        };
        if (serviceMap.hasOwnProperty(tempType)) {
            const template = GetTemplate(tempType, this.injector);
            Object.keys(template).forEach(key => this[key] = template[key]);
        }
        else {
            this.logService.logErr('La variabile di configurazione non è configurata correttamente');
        }
    }
    checkIfGridIsEditable() {
        let objParametriAgendaService = this.injector.get(GIAS_PARAMETRI_AGENDA_TOKEN);
        let objParametriAgenda = objParametriAgendaService.getObjParamValue();
        this.gridIsEditable = true;
        if (objParametriAgenda.TipoOperazioneDB == Enum_DBTypeOperation.Read) {
            this.gridIsEditable = false;
        }
    }
    isLoading(value) {
        this.loadingService.set_isLoading({ isLoading: value, component: this.gridPublicService.gridElRef });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: AbstractGridConfigService, deps: [{ token: i0.Injector }, { token: ConfigTemplate }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: AbstractGridConfigService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: AbstractGridConfigService, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }], ctorParameters: () => [{ type: i0.Injector }, { type: ConfigTemplate }] });
function GetTemplate(template, injector) {
    switch (template) {
        case ConfigTemplate.DefaultTemplate:
            return new DefaultTemplate(injector.get(TranslocoService));
        case ConfigTemplate.CodiciTemplate:
            return new CodiciTemplate(injector.get(TranslocoService));
        case ConfigTemplate.InCellTemplate:
            return new InCellTemplate(injector.get(TranslocoService));
        case ConfigTemplate.InLineTemplate:
            return new InLineTemplate(injector.get(TranslocoService));
    }
}
class DefaultHttpService extends AbstractGridConfigService {
    gridId = 'DefaultGrid';
    editingMode = EditingMode.IN_LINE;
    loader = LoaderType.SERVICE;
    rowId = 'chiave';
    constructor(injector) {
        super(injector);
    }
    read() {
        this.logService.logInfo('Un servizio http della griglia non è stato selezionato');
        return from([]);
    }
    perform(actionType, items) {
        this.logService.logInfo('Un servizio http della griglia non è stato selezionato');
        return from([]);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: DefaultHttpService, deps: [{ token: i0.Injector }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: DefaultHttpService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: DefaultHttpService, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }], ctorParameters: () => [{ type: i0.Injector }] });
var HttpAction;
(function (HttpAction) {
    HttpAction["CREATE"] = "create";
    HttpAction["UPDATE"] = "update";
    HttpAction["REMOVE"] = "destroy";
    HttpAction["BATCH_SAVE"] = "save";
})(HttpAction || (HttpAction = {}));

class GridDataWithFilter {
    stopPropagation;
    data;
    forceRefresh = false;
    constructor(opts) {
        this.stopPropagation = opts.stopPropagation ?? false;
        this.forceRefresh = opts.forceRefresh ?? false;
        this.data = opts.data;
    }
}

class GridRootHelper {
    nextDropdownValue = new Subject();
    // TODO Razvan. Da inoltrare il valore al Subject dalla griglia
    nextMultiDropdownValue = new Subject();
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: GridRootHelper, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: GridRootHelper, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: GridRootHelper, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }] });

/**
 * Various section:
 * - [Section] Grid state
 */
const itemIndex = (item, data, chiave) => {
    for (let idx = 0; idx < data.length; idx++) {
        if (data[idx][chiave] === item[chiave]) {
            return idx;
        }
    }
    return -1;
};
const itemIndexSimple = (data, chiave, id) => {
    for (let idx = 0; idx < data.length; idx++) {
        if (data[idx][id] === chiave) {
            return idx;
        }
    }
    return -1;
};
const cloneData = (data) => {
    if (!data) {
        return [];
    }
    return data.map((item) => Object.assign({}, item));
};
class KendoGridService extends ReplaySubject {
    multiConfigs;
    transloco;
    pubServices;
    logService;
    intlService;
    gridRootHelper;
    localStorage;
    getLoadFn(controlName) {
        let col = this.kData.columns.find(s => s.field === controlName);
        if (col.ddl == null)
            return null;
        return { loadFn: col.ddl.loadFunction, loadOnEdit: col.ddl.loadOnEdit, col: col };
    }
    nextDropdownValue(controlName, value, formGroup) {
        let lazyLoad = this.getLoadFn(controlName);
        let data = {
            controlName: controlName, value: value,
            loadData: lazyLoad.loadFn, formGroup: formGroup,
            loadOnEdit: lazyLoad.loadOnEdit,
            currentRow: this.pubService.currentDataItem,
            column: lazyLoad.col
        };
        this.gridRootHelper.nextDropdownValue.next(data);
    }
    clearKendoGridService() {
        this._gridCtx = null;
        this.dropdownListSubject = new Subject();
        this.updateDropdownColumn = new Subject();
        this.originalColumns = [];
        this.originalModel = new KendoGridModel();
        this.originalData = [];
        this.createdItems = [];
        this.updatedItems = [];
        this.deletedItems = [];
        this.multiIndex = null;
        this.kData = { rows: [], model: {}, columns: [] };
        this.pubService = null;
        this.freeMultiIndex = true;
        this.multiIndex = null;
        this.conf = null;
        this.customizationRowsSubject = new Subject();
        this.signal = null;
    }
    /** Component context */
    _gridCtx;
    /**
     * Subjects for emitting events
     **/
    dropdownListSubject = new Subject();
    /**
     * Non sottoscrivere a questo subject. Dovrebbe essere usato soltanto nel
     * questo modulo.
     */
    updateDropdownColumn = new Subject();
    /**
     *  In cell editing mode variables
     **/
    originalColumns = [];
    originalModel = new KendoGridModel();
    originalData = [];
    createdItems = [];
    updatedItems = [];
    deletedItems = [];
    clone(obj) {
        return cloneDeep(obj);
    }
    /**
     * In line editing mode
     */
    kData = { rows: [], model: {}, columns: [] };
    pubService;
    freeMultiIndex = true;
    multiIndex;
    conf;
    constructor(multiConfigs, transloco, pubServices, logService, intlService, gridRootHelper, localStorage) {
        super(1);
        this.multiConfigs = multiConfigs;
        this.transloco = transloco;
        this.pubServices = pubServices;
        this.logService = logService;
        this.intlService = intlService;
        this.gridRootHelper = gridRootHelper;
        this.localStorage = localStorage;
        if (!Array.isArray(this.pubServices)) {
            this.pubService = this.pubServices;
            this.conf = this.multiConfigs;
            this.freeMultiIndex = false;
        }
    }
    initProviders(ctx) {
        // Could be of type array when multi: true in the providers array of the
        // container.
        if (Array.isArray(this.pubServices)) {
            this.mapFreePubService();
            this.mapMultiToken(ctx);
            ctx.privateService = this;
            this.freeMultiIndex = false;
            this.multiIndex = this.pubService.multiIndex;
        }
    }
    onCellClick(event) {
        if (typeof this.conf.onCellClick === 'function') {
            this.conf.onCellClick(event);
        }
    }
    preventEdit(event) {
        return this.conf.preventEdit(event.dataItem, event.column);
    }
    onCellClose(event, inputElementRef) {
        if (typeof this.conf.onCellClose === 'function') {
            this.conf.onCellClose(event, inputElementRef);
        }
    }
    onCreateExternalFormGroup(event) {
        let FormGroup = null;
        if (typeof this.conf.onCreateExternalFormGroup === 'function') {
            FormGroup = this.conf.onCreateExternalFormGroup(event);
        }
        return FormGroup;
    }
    ngOnInit(component) {
        this.signal = component.unsubSignal;
        this._gridCtx = component;
        this.pubService.init(this);
        this.registerSubscriptions();
        this.initParams(component);
        if (this.conf.behavior?.excelSettings?.enabled) {
            component.excelData = component.excelData.bind(component);
        }
        this.pubService.ngOnInit(component);
    }
    initParams(c) {
        this._gridCtx = c;
        c.loader = this.conf.loader;
        c.editingMode = this.conf.editingMode;
        c.selectable = this.conf.selectable;
        c.toolbar = this.conf.toolbar;
        c.cmdColumn = this.conf.cmdColumn;
        c.cmdDropDown = this.conf.cmdDropDown;
        c.dettagliColumn = this.conf.dettagliColumn;
        c.customColumn = this.conf.customColumn;
        c.resizable = this.conf.resizable;
        c.generalSettings = this.clone(this.conf.generalSettings);
        if (!this.conf.masterdetailSettings) {
            c.masterdetailSettings = new MasterDetailSettings(false);
        }
        else {
            c.masterdetailSettings = this.conf.masterdetailSettings;
        }
        c.sort = this.conf.sort;
        c.aggregates = this.conf.aggregates;
        c.groups = this.conf.groups;
        c.columnMenu = this.conf.columnMenu;
        c.behavior = this.conf.behavior;
        c.key = this.conf.rowId;
        c.views = this.conf.views;
        c.pagination = this.clone(this.conf.pagination);
    }
    /** Read fresh data from the beginning of the read pipeline. */
    idealRead(refresh, isPerformCallback = false, cols = [], afterEdit = false) {
        this._read(refresh, isPerformCallback, cols, afterEdit);
    }
    _read(forceRefresh = false, isPerformCallback = false, cols = [], afterEdit = false) {
        switch (this.conf.editingMode) {
            case EditingMode.IN_CELL:
            case EditingMode.IN_LINE:
            case EditingMode.IN_PAGE:
            case EditingMode.IN_LINE_BATCH:
            case EditingMode.IN_CELL_BATCH:
                this.allPurposeRead(forceRefresh, isPerformCallback, cols, afterEdit);
                break;
            default:
                this.logService.logErr('Something went wrong, could not resolve editing mode: ' + this.conf.editingMode);
        }
    }
    /**
     * isPerformCallback: è true quando si rileggono i dati appena perform è completato.
     */
    allPurposeRead(forceRefresh, isPerformCallback, cols, afterEdit = false) {
        if (!forceRefresh && this.kData.rows?.length >= 0) {
            if (cols.length > 0) {
                cols.forEach(c => {
                    let index = this.kData.columns.findIndex(x => x.field === c.field);
                    if (index > -1) {
                        Object.keys(c).forEach(p => {
                            this.kData.columns[index][p] = c[p];
                        });
                    }
                });
            }
            return this.next(this.kData);
        }
        // Non necessario fare unsubscribe a una chiamata http
        this.conf.read(this.pubService?.Current_Grid_Master_RowExpanded)
            .pipe(tap((data) => {
            this.logService.checkThis(this.logService.checkRequiredFields, this.kData.model, this.kData.columns, this.kData.rows);
        }))
            .pipe(map((data) => {
            data = this.manageDates(data);
            return data;
        }))
            .subscribe({
            next: (data) => {
                this.storeDefaultColumnOrder(data.columns);
                this.storeDefaultGridState(this.conf.pagination.gridState);
                this._gridCtx.resetMulticheckStore();
                this.kData = data;
                this.originalData = cloneData(data?.rows);
                this.originalColumns = data?.columns;
                Object.assign(this.originalModel, data?.model);
                if (!afterEdit) {
                    let cols1 = this.kData.columns.sort((a, b) => a.orderIndex - b.orderIndex);
                    this.kData.columns = cols1;
                }
                else {
                    this.kData.columns = this.pubService.giasGridComponent.columns;
                }
                // Update the public service with the new values.
                let nextData = new GridDataWithFilter({ data: this.kData, stopPropagation: true });
                this.pubService.next(nextData);
                this.decideNextBehavior(isPerformCallback);
            }
        });
    }
    /**
     * Utilizzato soltanto dalle viste.
     * @param cols Le colonne inizialmente caricate dal backend.
     */
    storeDefaultColumnOrder(cols) {
        if (!this.defaultColumnsOrder) {
            this.defaultColumnsOrder = cloneData(this.sortColumnsByIndex(cols));
        }
    }
    storeDefaultGridState(state) {
        if (!this.defaultGridState)
            this.defaultGridState = state;
    }
    /**
     *
     * @param isPerformCallback utilizzato per gestire il ricaricamento dei dati appena
     * perform è stato eseguito, in modo che le modifiche sono aggiornate nella griglia.
     */
    decideNextBehavior(isPerformCallback) {
        if (!this.conf.views.enabled) {
            this.next(this.kData);
        }
        else {
            if (isPerformCallback)
                this.next(this.kData);
            else {
                this._gridCtx.model = this.kData.model;
                this._gridCtx.columns = this.kData.columns;
                this._gridCtx.customizationService.init(); //
            }
        }
    }
    manageDates(data) {
        if (!data) {
            return null;
        }
        data.columns.forEach((col) => {
            if (data.model[col.field] == undefined) {
                throw Error('il modello non ha il campo: ' + col.field);
            }
        });
        // let columnsDate = data.columns.filter((col) => data.model[col.field].type === CELL_TYPES.DATE);
        // data.rows = data.rows.map(row => {
        //   columnsDate.forEach(c => {
        //     if (typeof row[c.field] == "string"){
        //       row[c.field] = this.intlService.parseDate(row[c.field], '', this.transloco.getActiveLang())
        //         || this.intlService.parseDate(row[c.field]);
        //     }
        //   });
        //   return row;
        // });
        //
        // let columnsDatetime = data.columns.filter((col) => data.model[col.field].type === CELL_TYPES.DATETIME);
        // data.rows = data.rows.map(row => {
        //   columnsDatetime.forEach(c => {
        //     if (typeof row[c.field] == "string"){
        //       row[c.field] = this.intlService.parseDate(row[c.field]);
        //     }
        //   });
        //   return row;
        // });
        //
        // let columns = data.columns.filter((col) => data.model[col.field].type === CELL_TYPES.DROPDOWNLIST);
        // // data.rows = data.rows.map(row => {
        // //     columns.forEach(c => {
        // //         row[c.field] = String(row[c.field]);
        // //     });
        // //     return row;
        // // });
        //
        //Imposto come defaultValue 0 per le colonne numeriche
        let mappedColumns = data.columns.map(c => {
            if (data.model[c.field].type === CELL_TYPES.NUMBER && c.numeric) {
                if (!c.numeric.defaultValue) {
                    c.numeric.defaultValue = 0;
                }
            }
        });
        return data;
    }
    customizationRowsSubject = new Subject();
    defaultColumnsOrder = null;
    defaultGridState = null;
    reReadRows(model, cols, applyServerColumns) {
        // console.log(JSON.stringify(cols));
        let columns;
        if (applyServerColumns) {
            columns = this.sortColumnsByIndex(this.defaultColumnsOrder);
        }
        else {
            columns = this.sortColumnsByIndex(cols);
        }
        if (this.kData.rows) {
            this.pubService.next({
                stopPropagation: false,
                forceRefresh: false,
                data: {
                    model: model,
                    columns: columns,
                    rows: this.kData.rows
                }
            });
            // this.next({ model: model, columns: this.defaultColumnsOrder, rows: this.kData.rows });
        }
    }
    sortColumnsByIndex(columns) {
        return columns.sort((a, b) => a.orderIndex - b.orderIndex);
    }
    identifyRowsToSelect(ids) {
        const result = [];
        ids.forEach((chiave) => {
            const index = itemIndexSimple(this.kData.rows, chiave, this.conf.rowId);
            const valid = index != -1;
            if (valid) {
                result.push(index);
            }
            else {
                //console.log('Qualcosa è andato storto...');
            }
        });
        return result;
    }
    applyDefaultView() {
        this.next({
            rows: this.originalData,
            columns: this.originalColumns,
            model: this.originalModel
        });
    }
    updatePubService() {
        this.pubService.next({
            data: {
                rows: this.kData.rows,
                columns: this.kData.columns,
                model: this.kData.model
            },
            forceRefresh: false
        });
    }
    save(data, id, isNew, rowIndex) {
        if (this.conf.generalSettings.performOnEdit && this.conf.editingMode === EditingMode.IN_CELL) {
            throw Error("Save changes was triggered when changes are saved on cell modification");
        }
        switch (this.conf.editingMode) {
            case EditingMode.IN_LINE:
                return this.inlineSave(data, isNew, rowIndex);
            case EditingMode.IN_CELL:
                return this.incellSaveChanges();
            case EditingMode.IN_PAGE:
            case EditingMode.IN_LINE_BATCH:
            case EditingMode.IN_CELL_BATCH:
                return null;
            default:
                this.logService.logErr('Questa modalità di modifica non esiste (' + this.conf.editingMode + ').');
                return null;
        }
    }
    incellCreate(item) {
        if (this.conf.generalSettings.performOnEdit)
            this.incellCreatePerformOnEdit(item);
        else
            this.incellCreateDefault(item);
        this.updatePubService();
    }
    incellCreatePerformOnEdit(item) {
        this.kData.rows.unshift(item);
        this.next(this.kData);
        this.conf.perform(HttpAction.CREATE, [item]);
        this.updatePubService();
    }
    incellCreateDefault(item) {
        this.createdItems.push(item);
        this.kData.rows.unshift(item);
        this.next(this.kData);
        this.updatePubService();
    }
    inCellUpdate(item) {
        if (this.conf.editingMode == EditingMode.IN_CELL_BATCH)
            this.incellUpdateBatchEdit(item);
        else if (this.conf.generalSettings.performOnEdit)
            this.incellUpdatePerformOnEdit(item);
        else
            this.incellUpdateDefault(item);
        if (this.conf.editingMode != EditingMode.IN_CELL_BATCH) {
            this.updatePubService();
        }
    }
    incellUpdatePerformOnEdit(item) {
        if (!this.isNew(item)) {
            const index = itemIndex(item, this.kData.rows, this.conf.rowId);
            if (index !== -1) {
                this.kData.rows.splice(index, 1, item);
            }
        }
        else {
            const index = this.kData.rows.indexOf(item);
            this.kData.rows.splice(index, 1, item);
        }
        if (!this.isNew(item)) {
            this.conf.perform(HttpAction.UPDATE, [item]).subscribe(() => this._read(true, true), () => this._read(true, true));
        }
        else {
            this.conf.perform(HttpAction.CREATE, [item]);
        }
    }
    incellUpdateDefault(item) {
        if (!this.isNew(item)) {
            const index = itemIndex(item, this.updatedItems, this.conf.rowId);
            if (index !== -1) {
                this.updatedItems.splice(index, 1, item);
            }
            else {
                this.updatedItems.push(item);
            }
        }
        else {
            const index = this.createdItems.indexOf(item);
            this.createdItems.splice(index, 1, item);
        }
    }
    incellUpdateBatchEdit(item) {
        const type = this.isNew(item) ? HttpAction.CREATE : HttpAction.UPDATE;
        const ret = this.conf.perform(type, [item]);
        if (ret)
            ret.pipe(take(1)).subscribe();
    }
    /**
     * @param row the selected rows. If only one row is passed and the deletion mode is different from `HandleSingleRowDeletionOnly`, it tries to reread all the selected rows.
     */
    remove(row) {
        if (this.conf.behavior.deletionMode === DeletionMode.HandleSingleRowDeletionOnly) {
            this.doOneByOneDeletion(Array.isArray(row) ? row : [row]);
        }
        const rows = Array.isArray(row) ? row : this.getAllSelectedRows(row);
        if (this.conf.behavior.deletionMode === DeletionMode.HandleAllRowsTogether) {
            this.doBatchDeletion(rows);
        }
        else if (this.conf.behavior.deletionMode === DeletionMode.HandleEachRowSeparately) {
            this.doOneByOneDeletion(rows);
        }
    }
    getAllSelectedRows(row) {
        let rows = new Array();
        this._gridCtx.rows.forEach(row => {
            if (row['Selected'])
                rows.push(row);
        });
        if (rows.find((r) => r['chiave'] == row['chiave']) == undefined) {
            rows.push(row);
        }
        return rows;
    }
    doBatchDeletion(rows) {
        switch (this.conf.editingMode) {
            case EditingMode.IN_PAGE:
            case EditingMode.IN_LINE:
                this.inlineRemove(rows).subscribe(() => this._read(true, true));
                break;
            case EditingMode.IN_CELL:
            default:
                throw Error("Batch deletion not implemented yet for this editing mode: " + this.conf.editingMode.toString());
        }
    }
    /**
     * @param rows rows to delete
     * @history
     * **(12/03/2024)**: Add flag to reload grid data after deletion. This flag also helps to prevent the refresh of
     * grids with batch editing.
     */
    doOneByOneDeletion(rows) {
        let obs = [];
        let forceRead = true;
        rows.forEach((r) => {
            switch (this.conf.editingMode) {
                case EditingMode.IN_LINE:
                    obs.push(this.inlineRemove(r));
                    break;
                case EditingMode.IN_CELL:
                    if (this.conf.generalSettings.performOnEdit) {
                        this.incellRemovePerformOnEdit(r);
                    }
                    else { // batch editing
                        let elemPendingDeletion = this.highlightRowDeletion(r);
                        this.incellRemoveDefault(r, elemPendingDeletion);
                        forceRead = false;
                    }
                    this.updatePubService();
                    break;
                case EditingMode.IN_PAGE:
                    obs.push(this.inlineRemove(r));
                    break;
                case EditingMode.IN_LINE_BATCH:
                    break;
                case EditingMode.IN_CELL_BATCH:
                    break;
                default:
                    this.logService.logErr('Questa modalità di modifica non esiste (' + this.conf.editingMode + ').');
            }
        });
        (from(onErrorResumeNext(obs)).pipe(concatAll(), catchError((e) => {
            console.log('Error', e);
            return EMPTY;
        }))).subscribe({
            next: null,
            error: (e) => console.log('error', e),
            complete: () => {
                if (forceRead) {
                    this._read(true, true, [], true);
                }
            }
        });
    }
    inlineRemove(row) {
        return this.conf.perform(HttpAction.REMOVE, row);
    }
    incellRemovePerformOnEdit(item) {
        const index = this.kData.rows.indexOf(item);
        this.kData.rows.splice(index, 1);
        this.conf.perform(HttpAction.REMOVE, [item]);
    }
    itemsPreviouslyUpdated = [];
    incellRemoveDefault(item, elemPendingDeletion) {
        let helper = new BatchEditingHelper();
        const prepareElementForDeletion = () => {
            let index;
            if (this.isNew(item)) {
                index = this.createdItems.findIndex(i => i === item);
            }
            else {
                index = itemIndex(item, this.createdItems, this.conf.rowId);
            }
            if (index >= 0) {
                this.createdItems.splice(index, 1);
                // Since the deletion of a newly created item is reflected immediatly after
                // reloading the page, we get rid of the item all together.
                index = itemIndex(item, this.kData.rows, this.conf.rowId);
                this.kData.rows.splice(index, 1);
            }
            else {
                this.deletedItems.push(item);
                index = itemIndex(item, this.updatedItems, this.conf.rowId);
                if (index >= 0) {
                    this.itemsPreviouslyUpdated.push(item);
                    this.updatedItems.splice(index, 1);
                }
            }
        };
        const undoElementDeletion = () => {
            let index = itemIndex(item, this.deletedItems, this.conf.rowId);
            if (index >= 0) {
                this.deletedItems.splice(index, 1);
                // if item was edited previously to being removed, update updatedItems array.
                if ((index = helper.itemWasModifiedPreviouslyToBeingRemoved(item, this.itemsPreviouslyUpdated)) >= 0) {
                    this.itemsPreviouslyUpdated.splice(index, 1);
                    this.updatedItems.push(item);
                }
            }
        };
        if (elemPendingDeletion)
            prepareElementForDeletion();
        else
            undoElementDeletion();
    }
    highlightRowDeletion(row) {
        if (row[this.conf.rowId] == null)
            return true;
        row['pending-deletion-row'] = !row['pending-deletion-row'];
        return row['pending-deletion-row'];
    }
    inlineSave(data, isNew, rowIndex) {
        const action = isNew ? HttpAction.CREATE : HttpAction.UPDATE;
        let oldRow = null;
        if (action === HttpAction.UPDATE) {
            oldRow = this.pubService.getValue().data.rows[rowIndex];
        }
        this.generateNewRowId(data);
        this.reset();
        let obs = this.conf.perform(action, data, oldRow);
        // obs.subscribe(
        //     () => this._read(true, true),
        //     () => this._read(true, true)
        // );
        return obs;
    }
    batchSave(data) {
        return this.conf.perform(HttpAction.BATCH_SAVE, data);
    }
    /*
    * @description:
    * Aggiunge il campo chiave della riga se non è presente
    * */
    generateNewRowId(data) {
        if (data) {
            if (Object.keys(data).findIndex(x => x === this.conf.rowId) === -1) {
                let key_values = this.kData.rows.map(r => r[this.conf.rowId]);
                if (key_values && key_values.length > 0) {
                    if (typeof key_values[0] === "number") {
                        let new_key = Math.max(...key_values) + 1;
                        data[this.conf.rowId] = new_key;
                    }
                    else if (typeof key_values[0] === "string") {
                        let new_key = "";
                        for (let k of key_values) {
                            //new_key =  (Math.random() + 1).toString(36).substring(7);
                            new_key = window.crypto.getRandomValues(new Uint32Array(1))[0].toString(16);
                            if (new_key !== k) {
                                break;
                            }
                        }
                        data[this.conf.rowId] = new_key;
                    }
                }
            }
        }
    }
    /**
     *
     * @param gridGeneralSettings general settings of the grid
     * @history (09/04/2024): If the grid doesn't perform the actions on edit,
     * it creates a single event with all the interested rows. Rows can be sorted as follows:
     *  - toDelete: will have a hidden field (`pending-deletion-row`) valorized as true;
     *  - toCreate: will probably have the field `rowId` not valorized (see: {@link isNew})
     *  - toUpdate: all the others
     */
    incellSaveChanges(gridGeneralSettings) {
        if (!this.incellHasChanges()) {
            return null;
        }
        const completed = [];
        if (gridGeneralSettings && !gridGeneralSettings.performOnEdit) {
            const touchedRows = [...this.deletedItems, ...this.updatedItems, ...this.createdItems];
            completed.push(this.conf.perform(HttpAction.BATCH_SAVE, touchedRows));
        }
        else {
            if (this.deletedItems.length) {
                completed.push(this.conf.perform(HttpAction.REMOVE, this.deletedItems));
            }
            if (this.updatedItems.length) {
                completed.push(this.conf.perform(HttpAction.UPDATE, this.updatedItems));
            }
            if (this.createdItems.length) {
                completed.push(this.conf.perform(HttpAction.CREATE, this.createdItems));
            }
        }
        this.incellReset();
        return zip(...completed);
        //obs.subscribe(() => this._read(false, true));
    }
    cancelChanges() {
        switch (this.conf.editingMode) {
            case EditingMode.IN_LINE:
                this.inlineCancelChanges();
                break;
            case EditingMode.IN_CELL:
                this.incellCancelChanges();
                break;
            case EditingMode.IN_PAGE:
                break;
            case EditingMode.IN_LINE_BATCH:
                this.incellCancelChanges();
                break;
            case EditingMode.IN_CELL_BATCH:
                this.incellCancelChanges();
                break;
            default:
                this.logService.logErr('Questa modalità di modifica non esiste (' + this.conf.editingMode + ').');
        }
    }
    incellCancelChanges() {
        this.incellReset();
        this.originalData.filter(r => r['pending-deletion-row'])
            .forEach(r => r['pending-deletion-row'] = false);
        this.kData.rows = this.originalData;
        this.originalData = cloneData(this.originalData);
        this.next(this.kData);
    }
    inlineCancelChanges() {
        //this.kData.rows = [];
        this.incellReset();
        this.kData.rows = this.originalData;
        this.originalData = cloneData(this.originalData);
        this.next(this.kData);
    }
    reset() {
        switch (this.conf.editingMode) {
            case EditingMode.IN_LINE:
                this.inlineCancelChanges();
                break;
            case EditingMode.IN_CELL:
            case EditingMode.IN_CELL_BATCH:
                this.incellCancelChanges();
                break;
            case EditingMode.IN_PAGE:
                break;
            case EditingMode.IN_LINE_BATCH:
                break;
            default:
                this.logService.logErr('Questa modalità di modifica non esiste (' + this.conf.editingMode + ').');
        }
    }
    inlineReset() {
        this.kData.rows = this.originalData;
        this.next(this.kData);
    }
    incellReset() {
        this.kData.rows = [];
        this.deletedItems = [];
        this.updatedItems = [];
        this.createdItems = [];
    }
    incellHasChanges() {
        return Boolean(this.deletedItems.length ||
            this.updatedItems.length ||
            this.createdItems.length);
    }
    /** Checks if the row is new.
     * @param item the row to check
     * @private
     * @return true if the field specified by `this.conf.rowId` is `null` or `undefined`
     */
    isNew(item) {
        return (item[this.conf.rowId] == null || item[this.conf.rowId] == undefined);
    }
    assignValues(target, source) {
        Object.assign(target, source);
    }
    signal;
    registerSubscriptions() {
        // Trigger the save event using a switch outside of the grid. conf
        this.pubService.detachedSaveBtn.pipe(takeUntil(this.signal))
            .subscribe(() => {
            if (this.conf.generalSettings.performOnEdit && this.conf.editingMode === EditingMode.IN_CELL)
                return;
            this.incellSaveChanges();
        });
        // For updating dropdown lists
        this.dropdownListSubject.pipe(takeUntil(this.signal))
            .subscribe((event) => {
            if (event.type === DropdownEventType.ON_PRE_UPDATE_DROPDOWN) {
                const colToUpdate = this.kData.columns.filter(col => col.ddl?.id === event.id);
                if (colToUpdate.length === 1) {
                    colToUpdate[0].ddl.data = event.data.map(s => new DropdownListItem(s.id, s.name));
                }
                this.updateDropdownColumn.next({
                    type: DropdownEventType.ON_UPDATE_DROPDOWN,
                    id: event.id,
                    data: colToUpdate,
                    listItems: event.listItems
                });
                this.next(this.kData);
            }
        });
        // Listening to the public grid service for new grid source data.
        this.pubService.pipe(takeUntil(this.signal), skip(1), filter(x => !x.stopPropagation))
            .subscribe((kdata) => {
            this.kData = kdata.data ?? { rows: [], model: {}, columns: [] };
            this._read(kdata.forceRefresh, true);
        });
    }
    /**
     * Soon to be deprecated methods
     */
    getEditingMode() {
        return this.conf.editingMode;
    }
    /** Disables the editing of the grid. */
    disable() {
        this.conf.gridIsEditable = false;
        this.conf.disableGrid();
        this.conf.makeCellsUneditable();
    }
    /** Enables the editing of the grid. */
    enable() {
        this.conf.gridIsEditable = true;
        this.conf.disableGrid();
        this.conf.makeCellsUneditable();
    }
    setKendoData(rows, model, cols) {
        if (this.originalData == null) {
            this.originalData = rows;
        }
        this.logService.checkRequiredFields(model, cols, rows);
        this.kData = this.manageDates({ rows: rows, columns: cols, model: model });
        this.next(this.kData);
    }
    getRows() {
        return this.kData.rows.slice();
    }
    getModel() {
        return Object.assign({}, this.kData.model);
    }
    getColumns() {
        return this.kData.columns;
    }
    /**
     * Used for mapping the public grid service of the grid to an unused multi
     * index of the public service.
     */
    mapFreePubService() {
        const found = this.pubServices
            .find((s) => s.freeMultiIndex);
        if (!found) {
            throw new Error('Nessun servizio pubblico disponibile per essere mappato a KendoGridService.');
        }
        this.pubService = found;
        this.pubService.freeMultiIndex = false;
    }
    /**
     * Used for mapping a configuration service to its corresponding service
     * (when multi: true in the providers array).
     */
    mapMultiToken(ctx) {
        const configs = this.multiConfigs;
        const found = configs.find((c) => c.gridId === ctx.gridId);
        if (!found) {
            throw Error(`Non ho riuscito mappare la griglia con l'ID '${ctx.gridId}' a nessun servizio di configurazione.`);
        }
        this.conf = found;
    }
    setDataItem(dataItem) {
        this.pubService.currentDataItem = dataItem;
    }
    /**
     * [Section] Grid state
     */
    /**
     * [Context] Store/restore current page using cookies.
     */
    storeCurrentGridPage(skip) {
        this.localStorage.store(this._lastAccessedPageCookieId(), '' + skip);
    }
    checkCacheForPreviousPage() {
        return this.localStorage.retrieve(this._lastAccessedPageCookieId());
    }
    _lastAccessedPageCookieId() {
        return `${this.conf.gridId}-LastAccessedPage`;
    }
    /** END grid state */
    /** Some fields may be lost as a result of serialization. Here we restore
     * some of these fields (dropdown load functions and rendered custom
     * components).
     */
    restoreLostData(viewColumns) {
        return viewColumns.flatMap((col) => {
            if (!col.field)
                return []; // remove the item
            let result = col;
            if (this.isOfType(col, CELL_TYPES.CUSTOM))
                result = this.mapComponentProp(result);
            if (this.isOfType(col, CELL_TYPES.DROPDOWNLIST) && col.ddl.loadOnEdit ||
                this.isOfType(col, CELL_TYPES.MULTI_DROPDOWNLIST) && col.ddl.loadOnEdit)
                result = this.mapLoadFn(result);
            return result;
        }, this);
    }
    mapComponentProp(col) {
        col.component = this.originalColumns.find(oc => oc.field === col.field).component;
        return col;
    }
    mapLoadFn(col) {
        col.ddl.loadFunction = this.originalColumns.find(oc => oc.field === col.field)?.ddl?.loadFunction;
        return col;
    }
    isOfType(col, type) {
        switch (type) {
            case CELL_TYPES.DROPDOWNLIST:
            case CELL_TYPES.MULTI_DROPDOWNLIST:
                return this.isDdl(col);
            case CELL_TYPES.CUSTOM:
                return this.isCustom(col);
        }
        return null;
    }
    isDdl(col) {
        return this.originalModel[col.field]?.type === CELL_TYPES.DROPDOWNLIST ||
            this.originalModel[col.field]?.type === CELL_TYPES.MULTI_DROPDOWNLIST;
    }
    isCustom(col) {
        return this.originalModel[col.field]?.type === CELL_TYPES.CUSTOM;
    }
    getColumnType(field) {
        const column = this.originalModel[field];
        if (_isNull(column))
            throw new Error("Requested column field was not found in the model");
        return column.type;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: KendoGridService, deps: [{ token: GRID_HTTP_TOKEN }, { token: i1$1.TranslocoService }, { token: GridPublicService }, { token: GridErrorService }, { token: i4.IntlService }, { token: GridRootHelper }, { token: i6.LocalStorageService }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: KendoGridService });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: KendoGridService, decorators: [{
            type: Injectable
        }], ctorParameters: () => [{ type: AbstractGridConfigService, decorators: [{
                    type: Inject,
                    args: [GRID_HTTP_TOKEN]
                }] }, { type: i1$1.TranslocoService }, { type: GridPublicService }, { type: GridErrorService }, { type: i4.IntlService }, { type: GridRootHelper }, { type: i6.LocalStorageService }], propDecorators: { conf: [{
                type: Inject,
                args: [GRID_HTTP_TOKEN]
            }] } });
class BatchEditingHelper {
    itemWasModifiedPreviouslyToBeingRemoved(item, itemsPreviouslyUpdated) {
        return itemsPreviouslyUpdated.indexOf(item);
    }
}

class FiltroJSONService {
    isFirstApplyView = true;
    applyLoadCacheFirstTime = true;
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: FiltroJSONService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: FiltroJSONService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: FiltroJSONService, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }] });

class GridCustomizationsService {
    ajaxAgronicaAPIService;
    dropdownService;
    cookies;
    giasMessageService;
    privateGridService;
    transloco;
    conversionService;
    gridPublicService;
    filtroJSONService;
    conf;
    router;
    defaultViewStoredServerSide() {
        const defaultView = this.inMemoryViews.find(s => s.Predefinita);
        return defaultView ? !defaultView.IsNew : false;
    }
    customizationRequest = new Subject();
    _inMemoryViews = [];
    username;
    permessoPubblica = false;
    switchValue = false;
    selectedDDLItem;
    viewToApply = new Subject();
    defaultStoredOnServer = new Subject();
    constructor(userService, ajaxAgronicaAPIService, dropdownService, cookies, giasMessageService, privateGridService, transloco, conversionService, gridPublicService, filtroJSONService, conf, // GridNoteServerResult
    router) {
        this.ajaxAgronicaAPIService = ajaxAgronicaAPIService;
        this.dropdownService = dropdownService;
        this.cookies = cookies;
        this.giasMessageService = giasMessageService;
        this.privateGridService = privateGridService;
        this.transloco = transloco;
        this.conversionService = conversionService;
        this.gridPublicService = gridPublicService;
        this.filtroJSONService = filtroJSONService;
        this.conf = conf;
        this.router = router;
        this.username = userService.getCurrentUser()?.Username;
        this.gridPublicService.keyViewString.pipe(skip(1)).subscribe((value) => {
            //this.persistView(this.selectedDDLItem);
            this.loadInMemoryViews();
        });
    }
    checkIfThereIsAForm() {
        return this.gridPublicService.thereIsAForm && this.filtroJSONService.isFirstApplyView;
    }
    setFormFields(view) {
        if (this.gridPublicService.thereIsAForm) {
            this.filtroJSONService.isFirstApplyView = false;
            //this.persistView(this.selectedDDLItem);
            this.gridPublicService.applyViewFiltroJSON.next(view);
        }
    }
    get inMemoryViews() {
        return cloneDeep(this._inMemoryViews);
    }
    inMemViewsLoaded = false;
    cacheViewWasApplied = false;
    init() {
        if (!this.inMemViewsLoaded) {
            this.loadInMemoryViews();
        }
    }
    /**
     * Initializes the component (the views and dropdown list).
     * Loads preselected view from the cache.
     */
    /*private loadInMemoryViews_Old() {
        const chiave = new ChiaveVista(this.gridParentName, this.conf.gridId, null, this.username);
  
  
        this.httpService.post('/Shared/VisteGriglia.asmx/CaricaViste', chiave, false, false)
            .pipe(take(1))
            .subscribe((viste: []) => {
                this.mapViews(viste);
                this.handleCacheItem(viste);
                this.checkDefaultViewOnServer();
            });
    }*/
    loadInMemoryViews() {
        const chiave = this.CreateNewKeyView(null, this.username);
        this.ajaxAgronicaAPIService.ajaxAPIPost('Shared/VisteGriglia_CaricaViste', chiave).pipe(map(viste => {
            this.mapViews(viste.RispostaStringa);
            this.handleCacheItem(viste.RispostaStringa);
            this.checkDefaultViewOnServer();
        })).subscribe();
    }
    checkDefaultViewOnServer() {
        const defaultViewOnServer = this.inMemoryViews
            .find(s => s.Predefinita) != null;
        this.defaultStoredOnServer.next(defaultViewOnServer);
    }
    mapViews(views) {
        this._inMemoryViews = views.map((view) => {
            let c = JSON.parse(view['Colonne']);
            let s = JSON.parse(view['Stato']);
            c = this.conversionService.ConversionDateInObject(c);
            s = this.conversionService.ConversionDateInObject(s);
            return new InMemoryView({
                IdVista: view['IdVista'],
                NomeUtente: view['NomeUtente'],
                NomeVista: view['NomeVista'],
                GridId: view['GridId'],
                Predefinita: view['Predefinita'],
                IsModified: false,
                IsNew: false,
                Colonne: c,
                Stato: s,
                FiltroJSON: view['FiltroJSON'],
                FlagPubblica: view['FlagPubblica']
            });
        });
        this.inMemViewsLoaded = true;
    }
    handleCacheItem(viste) {
        const item = this.loadCacheItem(viste);
        const initializer = this.transformData(viste, item);
        this.dropdownService.next(initializer);
        this.cacheViewWasApplied = true;
    }
    loadCacheItem(viste) {
        let cache_view = null;
        //se voglio che venga caricata la vista in cache
        if (this.filtroJSONService.applyLoadCacheFirstTime) {
            cache_view = this.SearchCookie();
            //Se la vista memorizzata nei Cookie non è più presente nell'elenco non la propongo
            if (cache_view) {
                let index = viste.findIndex(v => v.IdVista === cache_view.id);
                if (index === -1)
                    cache_view = null;
            }
        }
        if (!cache_view) {
            cache_view = this.dropdownService.getDefaultItem();
        }
        //Add Additional Info to Item
        if (cache_view && cache_view.data) {
            if (!cache_view.data.NomeUtente || cache_view.data.NomeUtente === "") {
                cache_view.data.NomeUtente = this.username;
            }
            if (!cache_view.data.GridId || cache_view.data.GridId === "") {
                cache_view.data.GridId = this.CreateNewGridIdforView();
            }
        }
        return cache_view;
    }
    findExistingCookie() {
        return this.SearchCookie();
    }
    SearchCookie() {
        const Search = (keyTofind) => {
            const json = this.cookies.getAll();
            for (const key in json) {
                if (key.includes(keyTofind)) {
                    return parseJson(json[key]);
                }
            }
            return null;
        };
        //Prima cerco il cookie con il nuovo GridId (nomeServizioGriglia|PartefinaleURL)
        //Se non lo trovo cerco per il vecchio GridId(nomeServizioGriglia)
        let cookie_value = null;
        // cookie_value = Search(this.CreateNewGridIdforView() + '-'+this.username+ '-item-');
        cookie_value = Search(this.CreateNewGridIdforView() + '-' + this.username);
        if (!cookie_value) {
            cookie_value = Search(this.conf.gridId + '-' + this.username);
        }
        return cookie_value;
    }
    /**
     * Saves all views server side. Used when clicking the save button.
     * @param selectedDDLItem
     */
    /*public saveAllViews_Old() {
        const postData: SalvaVisteWrapper = this.prepareToSaveViews(this.inMemoryViews);
        if(!postData.VisteModificate.length && !postData.VisteNuove.length) {
            return;
        }
  
        this.httpService.post('/Shared/VisteGriglia.asmx/ScriviViste', postData).subscribe((dati) => {
            this.inMemoryViews.forEach((vista) => {
                vista.IsModified = false;
                vista.IsNew = false;
            });
            this.checkDefaultViewOnServer();
            let messaggio = this.transloco.translate('giasgrid.VisteSalvate', { });
            this.giasMessageService.infoMessagge(messaggio);
        });
    }*/
    saveAllViews() {
        const postData = this.prepareToSaveViews(this.inMemoryViews);
        if (!postData.VisteModificate.length && !postData.VisteNuove.length) {
            return;
        }
        this.ajaxAgronicaAPIService.ajaxAPIPost('Shared/VisteGriglia_ScriviViste', postData).subscribe((dati) => {
            this.inMemoryViews.forEach((vista) => {
                vista.IsModified = false;
                vista.IsNew = false;
            });
            this.checkDefaultViewOnServer();
            let messaggio = this.transloco.translate('giasgrid.VisteSalvate', {});
            this.giasMessageService.infoMessagge(messaggio);
        });
    }
    /**
     * Saves the current view server side. Used when clicking 'Add'or the save
     * button.
     * @param ddlViewItem
     */
    /*public saveCurrentView_Old(ddlViewItem) {
        const postData: SalvaVisteWrapper = this.prepareToSaveViews(this.inMemoryViews);
  
        let view = postData.VisteModificate.find(v => v.IdVista === ddlViewItem.id);
        if (view) { // La vista corrente è tra quelle modificate
            postData.VisteNuove = [];
            postData.VisteModificate = [view];
        } else {
            view = postData.VisteNuove.find(v => v.IdVista === ddlViewItem.id);
            if (view) { // La vista corrente è tra quelle nuove
                postData.VisteModificate = [];
                postData.VisteNuove = [view];
            }
        }
  
        if(!postData.VisteModificate.length && !postData.VisteNuove.length) {
            return;
        }
  
        this.httpService.post('/Shared/VisteGriglia.asmx/ScriviViste', postData).subscribe((dati) => {
            let v = this._inMemoryViews.find(v => v.IdVista === view.IdVista);
            v.IsModified = false;
            v.IsNew = false;
  
            this.checkDefaultViewOnServer();
            let messaggio = this.transloco.translate('giasgrid.VisteSalvate', { });
            this.giasMessageService.infoMessagge(messaggio);
        });
    }*/
    saveCurrentView(ddlViewItem) {
        const postData = this.prepareToSaveViews(this.inMemoryViews, ddlViewItem.id);
        let find = false;
        let view = postData.VisteModificate.find(v => v.IdVista === ddlViewItem.id);
        if (view) { // La vista corrente è tra quelle modificate
            postData.VisteNuove = [];
            postData.VisteModificate = [view];
            find = true;
        }
        else {
            view = postData.VisteNuove.find(v => v.IdVista === ddlViewItem.id);
            if (view) { // La vista corrente è tra quelle nuove
                postData.VisteModificate = [];
                postData.VisteNuove = [view];
                find = true;
            }
        }
        if (view && view.FlagPubblica && !this.permessoPubblica) {
            let messaggio = this.transloco.translate('giasgrid.EditVistaPubblicaWarning', {});
            this.giasMessageService.warningMessage(messaggio);
            return;
        }
        if (!postData.VisteModificate.length && !postData.VisteNuove.length) {
            return;
        }
        if (!find) {
            postData.VisteModificate = [];
            postData.VisteNuove = [];
            return;
        }
        let filtroJSON = view.FiltroJSON;
        this.ajaxAgronicaAPIService.ajaxAPIPost('Shared/VisteGriglia_ScriviViste', postData).subscribe((dati) => {
            let v = this._inMemoryViews.find(v => v.IdVista === view.IdVista);
            v.IsModified = false;
            v.IsNew = false;
            this.checkDefaultViewOnServer();
            let messaggio = this.transloco.translate('giasgrid.VisteSalvate', {});
            this.giasMessageService.infoMessagge(messaggio);
            //segnalo il cambiamento alla griglia
            this.gridPublicService.afterSaveView.next(filtroJSON);
        });
    }
    /**
     * Deletes a customization.
     * @param selected the view to remove.
     */
    /*public deleteCustomization_Old(selected: DropdownListItem) {
  
        const view = this.inMemoryViews.filter(s => s.IdVista === selected.id)[0];
        this._inMemoryViews = this.inMemoryViews.filter(v => v.IdVista !== selected.id);
  
        if(!view.IsNew) {
            this.httpService.post('/Shared/VisteGriglia.asmx/CancellaVista', new ChiaveVista(this.gridParentName, this.conf.gridId, view.IdVista, view.NomeUtente ?? 'null'), true)
                .subscribe((risp: RispostaStandard) => {
                    if(risp.RispostaOK) {
                        this.removeInMemoryItem(selected);
                        if(view.Predefinita)
                            this.defaultStoredOnServer.next(false);
  
                        let messaggio = this.transloco.translate('giasgrid.VistaCancellata', { });
                        this.giasMessageService.infoMessagge(messaggio);
                    }
                });
        } else {
            this.removeInMemoryItem(selected);
        }
  
        this.cleanupCookie(selected);
    }*/
    deleteCustomization(selected) {
        const view = this.inMemoryViews.filter(s => s.IdVista === selected.id)[0];
        this._inMemoryViews = this.inMemoryViews.filter(v => v.IdVista !== selected.id);
        if (!view.IsNew) {
            this.ajaxAgronicaAPIService.ajaxAPIPost('Shared/VisteGriglia_CancellaVista', this.CreateNewKeyView(view.IdVista, view.NomeUtente, view.GridId), true)
                .subscribe((risp) => {
                if (risp.RispostaOK) {
                    this.removeInMemoryItem(selected);
                    if (view.Predefinita)
                        this.defaultStoredOnServer.next(false);
                    let messaggio = this.transloco.translate('giasgrid.VistaCancellata', {});
                    this.giasMessageService.infoMessagge(messaggio);
                }
            });
        }
        else {
            this.removeInMemoryItem(selected);
        }
        this.cleanupCookie(selected);
    }
    cleanupCookie(selected) {
        const id = this.dropdownService.getItemId(selected.data.GridId, selected.id, this.username);
        this.cookies.delete(id, '/');
    }
    removeInMemoryItem(selectedItem) {
        const dropdown = this.dropdownService.value.dropdown;
        const position = dropdown.data.findIndex((d) => d.id === selectedItem.id);
        if (position > -1) {
            dropdown.data.splice(position, 1);
            this.dropdownService.next({ dropdown: dropdown, selected: null });
        }
    }
    /**
     * Creates or loads the view to be applied.
     * @param item the selected item of the dropdown.
     * @returns the view to be applied to the grid.
     */
    getView(item, forceUpdateView) {
        const findInMemoryView = (item) => item?.data?.Predefinita ?
            this.inMemoryViews.find(mv => mv.Predefinita) :
            this.inMemoryViews.find(view => view.IdVista === item.id);
        let view = findInMemoryView(item);
        if (!view || forceUpdateView) {
            // calls 'this.mapGridSettingsAndSaveThem'
            this.customizationRequest.next({ dropdownItem: item, isNewView: view ? view.IsNew : true });
            view = this.getView(item, false);
            let cols = [];
            let cols1 = [];
            if (view && view.Colonne) {
                cols = view.Colonne.filter(x => x.field && x.field !== "");
                cols1 = view.Colonne.sort((a, b) => a.orderIndex - b.orderIndex);
                view.Colonne = cols1;
            }
            this.privateGridService.idealRead(false, false, cols1);
        }
        return view;
    }
    mapGridSettingsAndSaveThem(thatGrid, item, isNew) {
        const view = this.saveGridSettings(thatGrid, item, isNew);
        this.saveInMemoryCustomization(view);
    }
    saveGridSettings(that, chiave, isNewView) {
        const columns = that.grid.columns
            .toArray()
            .flatMap(x => 'children' in x ? x.children.toArray() : x);
        const gridConfig = {
            IdVista: chiave.id,
            NomeVista: chiave.name,
            GridId: chiave.data.GridId,
            Predefinita: chiave.data?.Predefinita ?? false,
            NomeUtente: (this.switchValue) ? chiave.data?.NomeUtente : this.username,
            Stato: that.pagination.gridState,
            IsModified: true,
            IsNew: isNewView,
            FiltroJSON: (this.gridPublicService.thereIsAForm) ? this.gridPublicService.filtroJSONstring : '',
            FlagPubblica: this.switchValue,
            Colonne: columns.map(columnComponent => {
                const savedColumn = new KendoGridColumn({ field: '', title: '' });
                Object.keys(savedColumn).forEach((key) => {
                    savedColumn[key] = columnComponent[key];
                    if (!(columnComponent instanceof ColumnComponent))
                        return;
                    if (key === 'filter') {
                        this.manageCellTypes(columnComponent, savedColumn, key, that.columns);
                    }
                });
                return savedColumn;
            })
        };
        return gridConfig;
    }
    /**
     * Save the previously created view in memory, to be displayed to the user.
     * @param gridParentName the name of the component using the the grid.
     * @param customView the view to save.
     */
    saveInMemoryCustomization(customView) {
        this.updateInMemoryView(customView);
    }
    updateInMemoryView(customView) {
        let colMapped = customView.Colonne.map((c) => {
            let c1 = { ...c };
            for (var variableKey in c) {
                if (c.hasOwnProperty(variableKey)) {
                    delete c[variableKey];
                }
            }
            c.width = c1.width;
            c.field = c1.field;
            c.title = c1.title;
            c.hidden = c1.hidden;
            c.orderIndex = c1.orderIndex;
            c.customParent = c1.customParent;
            c.customFooter = c1.customFooter;
            return c;
        });
        const cols = customView.Colonne.sort((a, b) => a.orderIndex - b.orderIndex);
        customView.Colonne = cols;
        const index = this.inMemoryViews.findIndex(s => s.IdVista === customView.IdVista);
        if (index == -1) {
            this._inMemoryViews.push(customView);
        }
        else {
            this._inMemoryViews.splice(index, 1, customView);
        }
    }
    /** Set the column type of the saved column
     * @param columns the columns passed to KendoServerModel.
     * @param savedColumn the column it is being processed.
     * @param columnComponent
     */
    manageCellTypes(columnComponent, savedColumn, key, columns) {
        if (key === 'filter') {
            const attachedColumn = this.findCurrentlyAttachedGridColumn(columnComponent, columns);
            const columnType = this.privateGridService.getColumnType(attachedColumn.field);
            if (attachedColumn) {
                savedColumn.showHTMLAsString = attachedColumn.showHTMLAsString;
                switch (columnType) {
                    case CELL_TYPES.BOOLEAN:
                        savedColumn.boolean = attachedColumn.boolean;
                        break;
                    case CELL_TYPES.DATE:
                        savedColumn.date = attachedColumn.date;
                        break;
                    case CELL_TYPES.DATETIME:
                        savedColumn.date = attachedColumn.date;
                        break;
                    case CELL_TYPES.DROPDOWNLIST:
                        savedColumn.ddl = attachedColumn.ddl;
                        break;
                    case CELL_TYPES.MULTI_DROPDOWNLIST:
                        savedColumn.ddl = attachedColumn.ddl;
                        break;
                    case CELL_TYPES.NUMBER:
                        savedColumn.numeric = attachedColumn.numeric;
                        break;
                    case CELL_TYPES.STRING:
                        savedColumn.string = attachedColumn.string;
                        break;
                    case CELL_TYPES.CUSTOM:
                    case CELL_TYPES.OBJECT:
                        break;
                    default:
                        throw new Error("Column type not yet implemented");
                }
            }
        }
    }
    persistView(selected) {
        if (this.defaultIsSelected(selected)) {
            this.cleanupCookies();
            return;
        }
        // se la vista è nuova, questa non sarà ricavata dal server al caricamento
        // della pagina. Non ha senso memorizzarla in cache.
        if (this.viewIsNew(selected)) {
            return;
        }
        this.cleanupCookies();
        if (this.defaultIsSelected(selected)) {
            return;
        }
        this.storeCurrentViewChoice(selected);
    }
    storeCurrentViewChoice(selected) {
        const id = this.dropdownService.getItemId(selected.data.GridId, selected.id, this.username);
        const json = JSON.stringify(selected);
        this.cookies.set(id, json, { path: '/' });
    }
    defaultIsSelected(selected) {
        return !selected || selected.data?.Predefinita;
    }
    cleanupCookies() {
        let cookieKey = null;
        if (cookieKey = this.findExistingCookie()) {
            this.cookies.delete(cookieKey, '/');
        }
    }
    viewIsNew(item) {
        const view = this.inMemoryViews.find(view => view.IdVista === item?.id);
        return view?.IsNew ?? true;
    }
    transformData(viste, cacheItem) {
        const setDefaultItem = (items) => {
            let defaultItemOnServer = items.find(item => item.data.Predefinita);
            return defaultItemOnServer ?? this.dropdownService.defaultItem;
        };
        const getRidOfPredefinedItem = (items) => items.filter(item => !item.data.Predefinita);
        const items = this.dropdownService.extractDropdownItems(viste);
        const id = this.dropdownService.generateDropdownId(this.CreateNewGridIdforView());
        const ddl = new DropdownList(id, getRidOfPredefinedItem(items), setDefaultItem(items));
        //const shouldApplyView = viste.find(view => view.Predefinita) != null;
        let selectedItem = computeSelectedItem(items, cacheItem);
        return new DropdownChanged(ddl, selectedItem ?? cacheItem);
    }
    prepareToSaveViews(inMemoryViews, idViewOptional = '') {
        let filtroJSON = this.gridPublicService.filtroJSONstring;
        let flagPubblica = this.switchValue;
        if (this.gridPublicService.thereIsAForm) {
            let index = inMemoryViews.findIndex(view => view.IdVista === idViewOptional);
            if (index > -1 && (inMemoryViews[index].FiltroJSON !== filtroJSON || inMemoryViews[index].FlagPubblica !== flagPubblica)) {
                inMemoryViews[index].IsModified = true;
                this._inMemoryViews[index].FiltroJSON = filtroJSON;
                this._inMemoryViews[index].FlagPubblica = flagPubblica;
            }
        }
        const newViews = inMemoryViews.filter(view => view.IsNew)
            .map((view) => new ServerView({
            IdVista: view.IdVista,
            GridId: view.GridId,
            Predefinita: view.Predefinita,
            NomeUtente: view.NomeUtente,
            NomeVista: view.NomeVista,
            Colonne: JSON.stringify(view.Colonne),
            Stato: JSON.stringify(view.Stato),
            FiltroJSON: (!view.Predefinita) ? filtroJSON : '',
            FlagPubblica: flagPubblica
        }));
        const modifiedViews = inMemoryViews.filter(view => !view.IsNew && view.IsModified).map((view) => new ServerView({
            IdVista: view.IdVista,
            GridId: view.GridId,
            Predefinita: view.Predefinita,
            NomeUtente: view.NomeUtente,
            NomeVista: view.NomeVista,
            Colonne: JSON.stringify(view.Colonne),
            Stato: JSON.stringify(view.Stato),
            FiltroJSON: (!view.Predefinita) ? filtroJSON : '',
            FlagPubblica: flagPubblica
        }));
        return new SalvaVisteWrapper({
            VisteNuove: newViews,
            VisteModificate: modifiedViews
        });
    }
    findCurrentlyAttachedGridColumn(columnComponent, attchedColumns) {
        const currentlyAttachedCol = attchedColumns.find(col => {
            if (columnComponent instanceof ColumnComponent) {
                return col.field === columnComponent.field;
            }
            return false;
        });
        if (!currentlyAttachedCol)
            throw Error(`Il campo ${columnComponent.field} non è stato trovato. Lo deve essere impostato un valore.`);
        return currentlyAttachedCol;
    }
    CreateNewKeyView(IdVista, NomeUtente, GridId = "") {
        if (NomeUtente === undefined || NomeUtente === null) {
            NomeUtente = "null";
        }
        if (GridId === "") {
            GridId = this.CreateNewGridIdforView();
        }
        return new ChiaveVista(GridId, IdVista, NomeUtente);
    }
    CreateNewGridIdforView() {
        let GridId = this.conf.gridId;
        if (this.router.url && this.router.url !== "") {
            GridId += "|" + this.router.url.split('/').pop().split('?')[0];
        }
        if (this.gridPublicService.thereIsAForm && this.gridPublicService.keyViewString.getValue())
            GridId += this.gridPublicService.keyViewString.getValue();
        return GridId;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: GridCustomizationsService, deps: [{ token: GIAS_USERNAME_TOKEN }, { token: GIAS_API_SERVICE_TOKEN }, { token: CustomizeDropdownService }, { token: i2.CookieService }, { token: GiasMessageService }, { token: KendoGridService }, { token: i1$1.TranslocoService }, { token: i2$1.ConversionService }, { token: GridPublicService }, { token: FiltroJSONService }, { token: GRID_HTTP_TOKEN }, { token: i9.Router }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: GridCustomizationsService });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: GridCustomizationsService, decorators: [{
            type: Injectable
        }], ctorParameters: () => [{ type: undefined, decorators: [{
                    type: Inject,
                    args: [GIAS_USERNAME_TOKEN]
                }] }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [GIAS_API_SERVICE_TOKEN]
                }] }, { type: CustomizeDropdownService }, { type: i2.CookieService }, { type: GiasMessageService }, { type: KendoGridService }, { type: i1$1.TranslocoService }, { type: i2$1.ConversionService }, { type: GridPublicService }, { type: FiltroJSONService }, { type: AbstractGridConfigService, decorators: [{
                    type: Inject,
                    args: [GRID_HTTP_TOKEN]
                }] }, { type: i9.Router }] });
function computeSelectedItem(items, cacheItem) {
    if (cacheItem.data?.Predefinita)
        return items.find(view => view.data?.Predefinita);
    return null;
}

class GridDropdownService {
    defaultItem = new DropdownListItem('-1', 'Predefinita');
    sourceChange = new BehaviorSubject(null);
    extractDropdownItems(data) {
        const items = [];
        data.forEach((view) => {
            items.push(new DropdownListItem(view.IdVista, view.NomeVista));
        });
        return items;
    }
    getDefaultItem() {
        return this.defaultItem;
    }
    getDefaultItemId() {
        return this.defaultItem.id;
    }
    generateUID() {
        //return Math.random().toString(16).slice(2);
        return window.crypto.getRandomValues(new Uint32Array(1))[0].toString(16);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: GridDropdownService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: GridDropdownService });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: GridDropdownService, decorators: [{
            type: Injectable
        }] });

class DropdownHelper {
    gridCellClosedOuput(col, row) {
        let ddlItems = [];
        if (this.datiSonoStatiCaricatiInAnticipo(col)) {
            let ctrlName = col.ddl.formControlName;
            if (!Array.isArray(row[ctrlName]))
                throw Error(`Value for ${ctrlName} must be an array!`);
            if (col.ddl.valuePrimitive) {
                let values = row[ctrlName];
                ddlItems = col.ddl.data.filter(x => values.includes(x['id']));
            }
            else {
                let values = row[ctrlName];
                if (this.containsDropdownListItems(values))
                    values = values.map(s => s['id']);
                ddlItems = col.ddl.data.filter(x => (values).includes(x['id']));
            }
            return { items: ddlItems, columnDataNeedsUpdate: false };
        }
        else {
            const { computedDdlItems, dataAlreadyLoaded } = this.getCellClosedOutputFromDataItem(row, col, ddlItems);
            return { items: computedDdlItems, columnDataNeedsUpdate: dataAlreadyLoaded };
        }
    }
    containsDropdownListItems(values) {
        return values?.length > 0 && values[0].id != null;
    }
    datiSonoStatiCaricatiInAnticipo(col) {
        return !col.ddl.loadOnEdit;
    }
    getCellClosedOutputFromDataItem(row, col, currentDdlItems) {
        let descriptions = row[col.ddl.descriptionField];
        let codes = row[col.ddl.formControlName];
        if (!Array.isArray(descriptions))
            throw Error(`Value for ${col.ddl.descriptionField} must be an array`);
        let computedDdlItems = currentDdlItems;
        // let dataAlreadyLoaded = true;
        // if (col.ddl.data == null || col.ddl.data.length == 0) {
        codes.forEach((code, index) => {
            let ddlItem = new DropdownListItem(code, descriptions[index]);
            computedDdlItems.push(ddlItem);
        });
        let dataAlreadyLoaded = false;
        // }
        return { computedDdlItems, dataAlreadyLoaded };
    }
    getMultiDropdownCtrlInput(c, row) {
        if (!c.ddl?.valuePrimitive) {
            let ctrlInput = [];
            let codici = row?.[c.ddl.formControlName] || c.ddl?.defaultValue || [];
            if (codici.length > 0 && codici[0] instanceof DropdownListItem)
                return codici;
            let valori = row?.[c.ddl.formControlValue] || c.ddl?.defaultValue || [];
            if (Array.isArray(codici)) {
                let ctrlName = c.ddl?.formControlName;
                let ctrlValue = c.ddl?.formControlValue;
                codici.forEach((codice, index) => {
                    let input = {};
                    input[ctrlName] = codice;
                    input[ctrlValue] = valori[index];
                    ctrlInput.push(input);
                });
            }
            else {
                throw Error(`Value for ${c.ddl.formControlName} must be an array!`);
            }
            c.validators?.forEach(s => {
                if (s instanceof PropertyValidator) {
                    s.setCurrentRow(row);
                }
            });
            return ctrlInput;
        }
        else {
            return row?.[c.ddl.formControlName] || c.ddl?.defaultValue || [];
        }
    }
}
class GridDropdownBase {
    gridPublicService;
    data;
    source;
    constructor(gridPublicService) {
        this.gridPublicService = gridPublicService;
    }
    defaultItem = new DropdownListItem('-1', 'Predefinita');
    extractDropdownItems(data) {
        const items = [];
        data.forEach((view) => {
            items.push(new DropdownListItem(view.IdVista, view.NomeVista));
        });
        return items;
    }
    getDefaultItem() {
        return this.defaultItem;
    }
    getDefaultItemId() {
        return this.defaultItem.id;
    }
    generateUID() {
        //return Math.random().toString(16).slice(2);
        return window.crypto.getRandomValues(new Uint32Array(1))[0].toString(16);
    }
    getData() {
        return this.data;
    }
    getSource() {
        return this.source;
    }
    patchValue(data) {
        let formGrp = data.formGroup;
        let ctrlName = data.controlName;
        let value = data.value;
        let col = data.column;
        let ctrl = formGrp.controls[ctrlName];
        let exists = this.checkIfValueExists(value);
        if (exists)
            ctrl.patchValue(value);
        else {
            lastValueFrom(data.loadData(this.gridPublicService.currentDataItem))
                .then(data => {
                this._patchValue(ctrl, value, data, col);
            });
        }
    }
    _patchValue(ctrl, value, data, column) {
        this.source = data;
        this.data = data;
        let exists2 = this.checkIfValueExists(value);
        if (exists2) {
            column.ddl.data = this.data;
            ctrl.patchValue(value);
        }
        else {
            console.log('You are trying to patch a non existing value');
            if (this.data.length > 0) {
                let item = this.data[0];
                if (!item.hasOwnProperty('id') || !item.hasOwnProperty('name')) {
                    console.log('Read data does not have required fields: "id" and "name"');
                }
            }
        }
    }
    checkIfValueExists(itemId) {
        let exists = false;
        let index = this.data.findIndex(s => s.id == itemId);
        if (index >= 0)
            exists = true;
        return exists;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: GridDropdownBase, deps: [{ token: GridPublicService }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: GridDropdownBase });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: GridDropdownBase, decorators: [{
            type: Injectable
        }], ctorParameters: () => [{ type: GridPublicService }] });
class GridMultiDropdownService {
    defaultItem = new DropdownListItem('-1', 'Predefinita');
    extractDropdownItems(data) {
        const items = [];
        data.forEach((view) => {
            items.push(new DropdownListItem(view.IdVista, view.NomeVista));
        });
        return items;
    }
    getDefaultItem() {
        return this.defaultItem;
    }
    getDefaultItemId() {
        return this.defaultItem.id;
    }
    generateUID() {
        //return Math.random().toString(16).slice(2);
        return window.crypto.getRandomValues(new Uint32Array(1))[0].toString(16);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: GridMultiDropdownService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: GridMultiDropdownService });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: GridMultiDropdownService, decorators: [{
            type: Injectable
        }] });

/**
 * Questa componente è stata creata per la kendo grid.
 * Non dovrebbe essere usata fuori da questo modulo.
 * Usare DropDownTemplateComponent invece.
 * */
class GridMultiDropdownComponent {
    useForm = false;
    id;
    filterable;
    defaultItem;
    textField;
    valueField;
    valuePrimitive;
    controlName;
    formGroup;
    selected;
    ddl;
    valueChange = new EventEmitter();
    open = new EventEmitter();
    reload = new EventEmitter();
    signal = new Subject();
    data;
    multi;
    defaultOpen;
    sourceChange = new EventEmitter();
    source = [];
    ngOnInit() {
        this.data = this.source.slice();
        if (this.ddl?.reload?.subscribe) {
            this.ddl?.reload?.pipe(takeUntil$1(this.signal)).subscribe(val => {
                if (val) {
                    this.reload.emit({
                        id: this.id,
                        type: DropdownEventType.ON_UPDATE_DROPDOWN,
                        data: this,
                        listItems: this.source
                    });
                }
            });
        }
        else {
            console.log(this.controlName + 'subscribe undefined');
        }
        if (!this.defaultOpen)
            this.defaultOpen = false;
        else {
            this.multi.toggle(this.defaultOpen);
            this.onOpen();
        }
        this.formGroup.valueChanges.pipe(takeUntil$1(this.signal)).subscribe(() => this.fixValidationForThisControl());
    }
    changeValue(newValue) {
        this.sourceChange.emit(this.source);
        this.valueChange.emit({
            id: this.id,
            type: DropdownEventType.ON_CHANGE_VALUE,
            data: newValue,
            listItems: this.source
        });
        this.selected = newValue;
    }
    filter;
    handleFilter(value) {
        this.filter = value;
        this.data = this.source.filter((s) => s.name.toLowerCase().indexOf(value.toLowerCase()) !== -1);
    }
    onOpen() {
        this.open.emit({
            id: this.id,
            type: DropdownEventType.ON_OPEN_DROPDOWN,
            data: this,
            listItems: this.source
        });
    }
    ngOnDestroy() {
        this.signal.next();
        this.signal.complete();
    }
    fixValidationForThisControl() {
        if (this.formGroup.get(this.controlName).valid && this.multi?.wrapper?.nativeElement) {
            const domEl = this.multi.wrapper.nativeElement;
            if (domEl.classList.contains('ng-invalid')) {
                domEl.classList.remove("ng-invalid");
            }
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: GridMultiDropdownComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "19.2.9", type: GridMultiDropdownComponent, isStandalone: false, selector: "gias-grid-multi-ddl", inputs: { useForm: "useForm", id: "id", filterable: "filterable", defaultItem: "defaultItem", textField: "textField", valueField: "valueField", valuePrimitive: "valuePrimitive", controlName: "controlName", formGroup: "formGroup", selected: "selected", ddl: "ddl", defaultOpen: "defaultOpen", source: "source" }, outputs: { valueChange: "valueChange", open: "open", reload: "reload", sourceChange: "sourceChange" }, providers: [GridMultiDropdownService], viewQueries: [{ propertyName: "multi", first: true, predicate: ["multi"], descendants: true, static: true }], ngImport: i0, template: "\n\n<kendo-multiselect #multi\n    [data]=\"data\"\n    [textField]=\"textField\"\n    [valueField]=\"valueField\"\n    [valuePrimitive]=\"valuePrimitive\"\n    (ngModelChange)=\"changeValue($event)\"\n    [formGroup]=\"formGroup\"\n    [formControlName]=\"controlName\"\n    [filterable]=\"filterable\"\n    (filterChange)=\"handleFilter($event)\"\n    (open)=\"onOpen()\"\n></kendo-multiselect>\n", styles: ["kendo-multiselect{height:fit-content!important}.ddl100{width:100%}\n"], dependencies: [{ kind: "component", type: i6$1.MultiSelectComponent, selector: "kendo-multiselect", inputs: ["showStickyHeader", "focusableId", "autoClose", "loading", "data", "value", "valueField", "textField", "tabindex", "tabIndex", "size", "rounded", "fillMode", "placeholder", "adaptiveMode", "title", "subtitle", "disabled", "itemDisabled", "checkboxes", "readonly", "filterable", "virtual", "popupSettings", "listHeight", "valuePrimitive", "clearButton", "tagMapper", "allowCustom", "valueNormalizer", "inputAttributes"], outputs: ["filterChange", "valueChange", "open", "opened", "close", "closed", "focus", "blur", "inputFocus", "inputBlur", "removeTag"], exportAs: ["kendoMultiSelect"] }, { kind: "directive", type: i2$2.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i2$2.NgControlStatusGroup, selector: "[formGroupName],[formArrayName],[ngModelGroup],[formGroup],form:not([ngNoForm]),[ngForm]" }, { kind: "directive", type: i2$2.FormGroupDirective, selector: "[formGroup]", inputs: ["formGroup"], outputs: ["ngSubmit"], exportAs: ["ngForm"] }, { kind: "directive", type: i2$2.FormControlName, selector: "[formControlName]", inputs: ["formControlName", "disabled", "ngModel"], outputs: ["ngModelChange"] }], viewProviders: [{ provide: ControlContainer, useExisting: FormGroupDirective }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: GridMultiDropdownComponent, decorators: [{
            type: Component,
            args: [{ standalone: false, selector: 'gias-grid-multi-ddl', viewProviders: [{ provide: ControlContainer, useExisting: FormGroupDirective }], providers: [GridMultiDropdownService], template: "\n\n<kendo-multiselect #multi\n    [data]=\"data\"\n    [textField]=\"textField\"\n    [valueField]=\"valueField\"\n    [valuePrimitive]=\"valuePrimitive\"\n    (ngModelChange)=\"changeValue($event)\"\n    [formGroup]=\"formGroup\"\n    [formControlName]=\"controlName\"\n    [filterable]=\"filterable\"\n    (filterChange)=\"handleFilter($event)\"\n    (open)=\"onOpen()\"\n></kendo-multiselect>\n", styles: ["kendo-multiselect{height:fit-content!important}.ddl100{width:100%}\n"] }]
        }], propDecorators: { useForm: [{
                type: Input
            }], id: [{
                type: Input
            }], filterable: [{
                type: Input
            }], defaultItem: [{
                type: Input
            }], textField: [{
                type: Input
            }], valueField: [{
                type: Input
            }], valuePrimitive: [{
                type: Input
            }], controlName: [{
                type: Input
            }], formGroup: [{
                type: Input
            }], selected: [{
                type: Input
            }], ddl: [{
                type: Input
            }], valueChange: [{
                type: Output
            }], open: [{
                type: Output
            }], reload: [{
                type: Output
            }], multi: [{
                type: ViewChild,
                args: ["multi", { static: true }]
            }], defaultOpen: [{
                type: Input
            }], sourceChange: [{
                type: Output
            }], source: [{
                type: Input
            }] } });

class Shared {
    static changeGridPage(index, pageSize) {
        return Math.floor(index / pageSize) * pageSize;
    }
}

class ScrollableScrollingOpts {
    pagination;
}
class ScrollableScrollingService {
    rowHeight = 0;
    mode = ScrollingMode.Scrollable;
    pagination;
    _totalCount = 0;
    constructor(opts) {
        this.pagination = opts.pagination;
    }
    get pageSize() {
        return this.gridState.take;
    }
    get totalCount() {
        return this._totalCount;
    }
    get gridState() {
        return this.pagination.gridState;
    }
    getRowHeight() {
        return 0;
    }
    isVirtual() {
        return false;
    }
    loadData(data) {
        const result = process(data.rows ?? [], this.computeGridStateBasedOn(data.rows));
        this._totalCount = result.total;
        return result;
    }
    computeGridStateBasedOn(rows) {
        if (this.gridState.skip > rows.length)
            this.gridState.skip = Shared.changeGridPage(0, this.gridState.take);
        return this.gridState;
    }
}

class VirtualScrollingService {
    mode = ScrollingMode.Virtual;
    rowHeight; // will be computed
    _pageSize; // will be computed
    _totalCount = 0; // will be computed
    pagination;
    gridPrivate;
    constructor(opts) {
        this.pagination = opts.pagination;
        this.gridPrivate = opts.gridPrivate;
        this.calculateRequiredFields();
    }
    get pageSize() {
        return this._pageSize;
    }
    get totalCount() {
        return this._totalCount;
    }
    get gridState() {
        return this.pagination.gridState;
    }
    get settings() {
        return this.pagination.virtualScrolling;
    }
    get skip() {
        return this.pagination.gridState.skip;
    }
    set skip(value) {
        // this.skip = value;
        this.pagination.gridState.skip = value;
    }
    isVirtual() {
        return true;
    }
    calculateRequiredFields() {
        if (isNullOrUndefined(this.settings?.viewportHeight) ||
            isNullOrUndefined(this.settings?.rowHeight))
            throw Error('Required settings used to perform calculations were not provided.');
        const gridViewport = Math.ceil(this.settings.viewportHeight);
        this.rowHeight = Math.ceil(this.settings.rowHeight);
        this._pageSize = Math.ceil(3 * (gridViewport / this.rowHeight));
    }
    pageChange(event) {
        this.pagination.gridState.skip = event.skip;
        return this.gridPrivate.pipe(map$1((kdata) => this.loadData(kdata)));
    }
    loadData(data) {
        const state = { ...this.computeGridStateBasedOn(data.rows) };
        state.take = this._pageSize;
        const result = process(data.rows, state);
        this._totalCount = result.total;
        return result;
    }
    computeGridStateBasedOn(rows) {
        if (this.gridState.skip > rows.length)
            this.gridState.skip = Shared.changeGridPage(0, this.gridState.take);
        return this.gridState;
    }
}

class ScrollingFactoryOpts {
    mode;
    componentContext;
}
class ScrollingModeFactory {
    static Create(opts) {
        switch (opts.mode) {
            case ScrollingMode.Scrollable:
                return new ScrollableScrollingService({
                    pagination: opts.componentContext.pagination
                });
            case ScrollingMode.Virtual:
                return new VirtualScrollingService({
                    pagination: opts.componentContext.pagination,
                    generalSettings: opts.componentContext.generalSettings,
                    gridPrivate: opts.componentContext.privateService
                });
        }
        return null;
    }
}

class GridDialogService extends GiasDialogService {
    gridPublicService;
    conf;
    ts;
    constructor(gridPublicService, kendoDialogService, conf, translocoService) {
        super(kendoDialogService, translocoService);
        this.gridPublicService = gridPublicService;
        this.conf = conf;
        this.ts = translocoService;
    }
    async showDialog(callback, row) {
        let msg = await this.conf.getRemoveMultipleRowsMessage(this.getSelectedRows(row));
        if (msg != '' && msg != undefined) {
            const risposta = await lastValueFrom(this.dialogMessageObs_Result('', msg, [
                { text: this.ts.translate('giasgrid.Conferma'), primary: true, returnObj: true },
                { text: this.ts.translate('giasgrid.Annulla'), returnObj: false }
            ], undefined, undefined, e => e instanceof DialogCloseResult, 3));
            if (risposta['returnObj'])
                callback(row);
        }
        else {
            callback(row);
        }
    }
    getSelectedRows(row) {
        let itemsToRemove = new RemoveMultipleRowsParams();
        itemsToRemove.data = new Array();
        if (this.conf.behavior.deletionMode === DeletionMode.HandleSingleRowDeletionOnly) {
            itemsToRemove.data.push(row);
            return itemsToRemove;
        }
        this.gridPublicService.value.data.rows.forEach(row => {
            if (row['Selected']) {
                itemsToRemove.data.push(row);
            }
        });
        if (itemsToRemove.data.find((r) => r['chiave'] == row['chiave']) == undefined) {
            itemsToRemove.data.push(row);
        }
        return itemsToRemove;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: GridDialogService, deps: [{ token: GridPublicService }, { token: i2$3.DialogService }, { token: GRID_HTTP_TOKEN }, { token: i1$1.TranslocoService }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: GridDialogService, providedIn: "root" });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: GridDialogService, decorators: [{
            type: Injectable,
            args: [{ providedIn: "root" }]
        }], ctorParameters: () => [{ type: GridPublicService }, { type: i2$3.DialogService }, { type: AbstractGridConfigService, decorators: [{
                    type: Inject,
                    args: [GRID_HTTP_TOKEN]
                }] }, { type: i1$1.TranslocoService }] });

class KendoGridMasterDetailService {
    /*
    *Memorizzo il KendoGridService (private service della griglia) perchè li ho a disposizione il PublicService e il Servizio che ha creato la griglia
    * dove ci sono le funzioni di read e perform
    * */
    _GridMasterService = null;
    _Array_GridDetail = [];
    _Last_RowExpanded = null;
    _RowIdGridMaster = "";
    get GridMasterService() {
        return cloneDeep(this._GridMasterService);
    }
    set GridMasterService(service) {
        this._GridMasterService = service;
    }
    set GridDetailService(obj) {
        if (this._Last_RowExpanded && this._GridMasterService) {
            if (!obj.GridMasterRowId)
                obj.GridMasterRowId = this._Last_RowExpanded[this._GridMasterService.conf.gridId];
            let index = this._Array_GridDetail.findIndex(d => d.GridMasterRowId === obj.GridMasterRowId);
            if (index > -1)
                this._Array_GridDetail.splice(index, 1);
        }
        this._Array_GridDetail.push(obj);
    }
    get Last_RowExpanded() {
        return cloneDeep(this._Last_RowExpanded);
    }
    set Last_RowExpanded(row) {
        this._Last_RowExpanded = row;
    }
    get GridDataMaster() {
        return cloneDeep(this._GridMasterService?.pubService?.getValue());
    }
    get GridDataDetail() {
        let array_GridDataDetail = [];
        this._Array_GridDetail.forEach(obj => {
            array_GridDataDetail.push({
                GridMasterRowId: obj.GridMasterRowId,
                GridData: obj.Service?.pubService?.getValue()
            });
        });
        return array_GridDataDetail;
    }
    get_GridDetailService(GridMasterRowId) {
        return cloneDeep(this._Array_GridDetail.find(x => x.GridMasterRowId === GridMasterRowId).Service);
    }
    get RowIdGridMaster() {
        return this._RowIdGridMaster;
    }
    set RowIdGridMaster(RowId) {
        this._RowIdGridMaster = RowId;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: KendoGridMasterDetailService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: KendoGridMasterDetailService });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: KendoGridMasterDetailService, decorators: [{
            type: Injectable
        }] });
class GridDetailInfo {
    GridMasterRowId;
    Service;
    constructor(GridMasterRowId, Service) {
        this.GridMasterRowId = GridMasterRowId;
        this.Service = Service;
    }
}
class GridDataDetail {
    GridMasterRowId;
    GridData;
    constructor(GridMasterRowId, GridData) {
        this.GridMasterRowId = GridMasterRowId;
        this.GridData = GridData;
    }
}

class GridBatchHandlerService {
    added = [];
    updated = [];
    deleted = [];
    get hasChanges() {
        return this.added.length > 0 || this.updated.length > 0 || this.deleted.length > 0;
    }
    getData() {
        return {
            added: this.added,
            updated: this.updated,
            deleted: this.deleted
        };
    }
    add(row) {
        // Add is always called on a new row
        this.added.push(row);
    }
    update(row, rowKey) {
        // Edit row that has been added but not saved
        const added = this.added.find(x => x[rowKey] == row[rowKey]);
        if (added != null) {
            this.added = this.added.filter(x => x[rowKey] != row[rowKey]);
            this.added.push(row);
            return;
        }
        // Edit row that has been updated but not saved
        const updated = this.updated.find(x => x[rowKey] == row[rowKey]);
        if (updated != null) {
            this.updated = this.updated.filter(x => x[rowKey] != row[rowKey]);
            this.updated.push(row);
            return;
        }
        this.updated.push(row);
    }
    remove(rows, rowKey) {
        for (const row of rows) {
            const added = this.added.find(x => x[rowKey] == row[rowKey]);
            if (added != null) {
                // Remove row that has just been added but not saved
                this.added = this.added.filter(x => x[rowKey] != row[rowKey]);
                continue;
            }
            const updated = this.updated.find(x => x[rowKey] == row[rowKey]);
            if (updated != null) {
                // Remove row that has just been updated but not saved
                this.updated = this.updated.filter(x => x[rowKey] != row[rowKey]);
            }
            if (!this.deleted.includes(row))
                this.deleted.push(row);
        }
    }
    reset() {
        this.added = [];
        this.updated = [];
        this.deleted = [];
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: GridBatchHandlerService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: GridBatchHandlerService });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: GridBatchHandlerService, decorators: [{
            type: Injectable
        }] });

class GridDropdownListComponent {
    gridService;
    gridRootService;
    gridPublicService;
    dropdownSerivce;
    useForm = false;
    column;
    id;
    filterable;
    defaultItem;
    textField;
    valueField;
    valuePrimitive;
    controlName;
    formGroup;
    selected;
    ddl;
    selectedChange = new EventEmitter();
    valueChange = new EventEmitter();
    open = new EventEmitter();
    reload = new EventEmitter();
    signal = new Subject();
    onNgModelChange(data) {
        this.selectedChange.emit(data);
    }
    sourceChange = new EventEmitter();
    source;
    sourceChangeSub;
    data;
    updateSub;
    addRemoveBorderClass = true;
    constructor(gridService, gridRootService, gridPublicService, dropdownSerivce) {
        this.gridService = gridService;
        this.gridRootService = gridRootService;
        this.gridPublicService = gridPublicService;
        this.dropdownSerivce = dropdownSerivce;
    }
    ngOnInit() {
        this.formGroup.controls[this.column.field].statusChanges.subscribe(state => {
            this.addRemoveBorderClass = state === 'VALID';
        });
        this.gridRootService.nextDropdownValue.pipe(takeUntil$1(this.signal), filter$1(s => s.controlName === this.controlName))
            .subscribe((data) => {
            let formGrp = data.formGroup;
            let ctrlName = data.controlName;
            let value = data.value;
            let col = data.column;
            let ctrl = formGrp.controls[ctrlName];
            let exists = this.checkIfValueExists(value);
            if (exists)
                ctrl.patchValue(value);
            else {
                lastValueFrom(data.loadData(this.gridPublicService.currentDataItem))
                    .then(data => {
                    this.patchValue(ctrl, value, data, col);
                });
            }
        });
        this.sourceChangeSub = this.dropdownSerivce.sourceChange
            .subscribe((ddl) => {
            if (!ddl) {
                return;
            }
            this.data = ddl.data;
            this.source = ddl.data;
            this.defaultItem = ddl.defaultValue;
            this.id = ddl.id;
            this.textField = ddl.textField;
            this.valueField = ddl.valueField;
            this.selected = ddl.defaultValue;
            this.selectedChange.emit(this.selected);
        });
        this.formGroup.controls[this.controlName].valueChanges.pipe(takeUntil$1(this.signal)).subscribe();
        if (!this.source) {
            this.source = [];
        }
        this.data = this.source.slice();
        this.updateSub = this.gridService.updateDropdownColumn.subscribe((event) => {
            if (event.id === this.id) {
                if (event.data.length === 1) {
                    this.source = event.data[0].ddl.data;
                    this.data = this.source.slice();
                }
            }
        });
        if (this.ddl?.reload?.subscribe) {
            this.ddl?.reload?.subscribe(val => {
                if (val) {
                    this.reload.emit({
                        id: this.id,
                        type: DropdownEventType.ON_UPDATE_DROPDOWN,
                        data: this,
                        listItems: this.source
                    });
                }
            });
        }
        else {
            console.log(this.controlName + 'subscribe undefined');
        }
    }
    patchValue(ctrl, value, data, column) {
        this.source = data;
        this.data = data;
        let exists2 = this.checkIfValueExists(value);
        if (exists2) {
            column.ddl.data = this.data;
            ctrl.patchValue(value);
        }
        else {
            console.log('You are trying to patch a non existing value');
            if (this.data.length > 0) {
                let item = this.data[0];
                if (!item.hasOwnProperty('id') || !item.hasOwnProperty('name')) {
                    console.log('Read data does not have required fields: "id" and "name"');
                }
            }
        }
    }
    checkIfValueExists(itemId) {
        let exists = false;
        let index = this.data.findIndex(s => s.id == itemId);
        if (index >= 0)
            exists = true;
        return exists;
    }
    handleFilter(value) {
        this.filter = value;
        this.data = this.source.filter((s) => s.name.toLowerCase().indexOf(value.toLowerCase()) !== -1);
    }
    changeValue(newValue) {
        this.sourceChange.emit(this.source);
        this.valueChange.emit({
            id: this.id,
            type: DropdownEventType.ON_CHANGE_VALUE,
            data: newValue,
            listItems: this.source
        });
        this.selected = newValue;
        this.selectedChange.emit(newValue);
    }
    ngOnDestroy() {
        this.signal.next();
        this.signal.complete();
        this.updateSub.unsubscribe();
        this.sourceChangeSub.unsubscribe();
    }
    filter;
    addNew() {
        this.source.push({
            name: this.filter,
            id: this.dropdownSerivce.generateUID(),
        });
        this.handleFilter(this.filter);
    }
    onOpen() {
        this.open.emit({
            id: this.id,
            type: DropdownEventType.ON_OPEN_DROPDOWN,
            data: this,
            listItems: this.source
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: GridDropdownListComponent, deps: [{ token: KendoGridService }, { token: GridRootHelper }, { token: GridPublicService }, { token: GridDropdownService }], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "19.2.9", type: GridDropdownListComponent, isStandalone: false, selector: "gias-grid-ddl", inputs: { useForm: "useForm", column: "column", id: "id", filterable: "filterable", defaultItem: "defaultItem", textField: "textField", valueField: "valueField", valuePrimitive: "valuePrimitive", controlName: "controlName", formGroup: "formGroup", selected: "selected", ddl: "ddl", source: "source" }, outputs: { selectedChange: "selectedChange", valueChange: "valueChange", open: "open", reload: "reload", sourceChange: "sourceChange" }, providers: [GridDropdownService], ngImport: i0, template: "<kendo-dropdownlist\n  *ngIf=\"!useForm; else useFormGroup\"\n  [data]=\"data\"\n  [itemDisabled]=\"ddl.itemDisabledFn\"\n  [textField]=\"textField\"\n  [valueField]=\"valueField\"\n  [valuePrimitive]=\"valuePrimitive\"\n  (ngModelChange)=\"changeValue($event)\"\n  [ngModel]=\"selected\"\n  [loading]=\"ddl.loading\"\n  [defaultItem]=\"dropdownSerivce.defaultItem\"\n  [ngModelOptions]=\"{standalone: true}\"\n  (open)=\"onOpen()\"\n  [filterable]=\"filterable\"\n  (filterChange)=\"handleFilter($event)\"\n>\n  <ng-template kendoDropDownListNoDataTemplate>\n    <div>\n      {{ 'giasgrid.No_Dati' | transloco }}\n      <!-- <ng-container *ngIf=\"filter\">\n        {{ 'giasgrid.Nuovo_Elemento' | transloco }} \"{{ filter }}\" ?\n      </ng-container> -->\n      <br />\n      <button *ngIf=\"filter\" class=\"k-button\" (click)=\"addNew()\">\n        {{ 'giasgrid.Nuovo_Elemento' | transloco }}\n      </button>\n    </div>\n  </ng-template>\n</kendo-dropdownlist>\n\n<ng-template #useFormGroup>\n  <kendo-dropdownlist\n    [data]=\"data\"\n    [itemDisabled]=\"ddl.itemDisabledFn\"\n    [textField]=\"textField\"\n    [valueField]=\"valueField\"\n    [valuePrimitive]=\"valuePrimitive\"\n    (ngModelChange)=\"changeValue($event)\"\n    [popupSettings]=\"{width: 'auto'}\"\n    [formControlName]=\"controlName\"\n    [loading]=\"ddl.loading\"\n    class=\"ddl100\"\n    [filterable]=\"filterable\"\n    (filterChange)=\"handleFilter($event)\"\n    (open)=\"onOpen()\"\n    [ngClass]=\"{ 'remove-ddl-red-border': addRemoveBorderClass }\"\n  ></kendo-dropdownlist>\n</ng-template>\n", styles: [".ddl100{width:100%}kendo-dropdownlist.ng-invalid.ng-touched.remove-ddl-red-border>span,.k-dropdown.ng-invalid.ng-dirty.remove-ddl-red-border>.k-dropdown-wrap,.k-dropdown.ng-invalid.ng-touched>.k-dropdown-wrap{border:0px!important;box-shadow:0 0!important}\n"], dependencies: [{ kind: "directive", type: i3.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: i3.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: i6$1.NoDataTemplateDirective, selector: "[kendoDropDownListNoDataTemplate],[kendoDropDownTreeNoDataTemplate],[kendoComboBoxNoDataTemplate],[kendoMultiColumnComboBoxNoDataTemplate],[kendoAutoCompleteNoDataTemplate],[kendoMultiSelectNoDataTemplate],[kendoMultiSelectTreeNoDataTemplate]" }, { kind: "component", type: i6$1.DropDownListComponent, selector: "kendo-dropdownlist", inputs: ["customIconClass", "showStickyHeader", "icon", "svgIcon", "loading", "data", "value", "textField", "valueField", "adaptiveMode", "title", "subtitle", "popupSettings", "listHeight", "defaultItem", "disabled", "itemDisabled", "readonly", "filterable", "virtual", "ignoreCase", "delay", "valuePrimitive", "tabindex", "tabIndex", "size", "rounded", "fillMode", "leftRightArrowsNavigation", "id"], outputs: ["valueChange", "filterChange", "selectionChange", "open", "opened", "close", "closed", "focus", "blur"], exportAs: ["kendoDropDownList"] }, { kind: "directive", type: i2$2.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i2$2.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }, { kind: "directive", type: i2$2.FormControlName, selector: "[formControlName]", inputs: ["formControlName", "disabled", "ngModel"], outputs: ["ngModelChange"] }, { kind: "pipe", type: i1$1.TranslocoPipe, name: "transloco" }], viewProviders: [{ provide: ControlContainer, useExisting: FormGroupDirective }], encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: GridDropdownListComponent, decorators: [{
            type: Component,
            args: [{ standalone: false, selector: 'gias-grid-ddl', viewProviders: [{ provide: ControlContainer, useExisting: FormGroupDirective }], providers: [GridDropdownService], encapsulation: ViewEncapsulation.None, template: "<kendo-dropdownlist\n  *ngIf=\"!useForm; else useFormGroup\"\n  [data]=\"data\"\n  [itemDisabled]=\"ddl.itemDisabledFn\"\n  [textField]=\"textField\"\n  [valueField]=\"valueField\"\n  [valuePrimitive]=\"valuePrimitive\"\n  (ngModelChange)=\"changeValue($event)\"\n  [ngModel]=\"selected\"\n  [loading]=\"ddl.loading\"\n  [defaultItem]=\"dropdownSerivce.defaultItem\"\n  [ngModelOptions]=\"{standalone: true}\"\n  (open)=\"onOpen()\"\n  [filterable]=\"filterable\"\n  (filterChange)=\"handleFilter($event)\"\n>\n  <ng-template kendoDropDownListNoDataTemplate>\n    <div>\n      {{ 'giasgrid.No_Dati' | transloco }}\n      <!-- <ng-container *ngIf=\"filter\">\n        {{ 'giasgrid.Nuovo_Elemento' | transloco }} \"{{ filter }}\" ?\n      </ng-container> -->\n      <br />\n      <button *ngIf=\"filter\" class=\"k-button\" (click)=\"addNew()\">\n        {{ 'giasgrid.Nuovo_Elemento' | transloco }}\n      </button>\n    </div>\n  </ng-template>\n</kendo-dropdownlist>\n\n<ng-template #useFormGroup>\n  <kendo-dropdownlist\n    [data]=\"data\"\n    [itemDisabled]=\"ddl.itemDisabledFn\"\n    [textField]=\"textField\"\n    [valueField]=\"valueField\"\n    [valuePrimitive]=\"valuePrimitive\"\n    (ngModelChange)=\"changeValue($event)\"\n    [popupSettings]=\"{width: 'auto'}\"\n    [formControlName]=\"controlName\"\n    [loading]=\"ddl.loading\"\n    class=\"ddl100\"\n    [filterable]=\"filterable\"\n    (filterChange)=\"handleFilter($event)\"\n    (open)=\"onOpen()\"\n    [ngClass]=\"{ 'remove-ddl-red-border': addRemoveBorderClass }\"\n  ></kendo-dropdownlist>\n</ng-template>\n", styles: [".ddl100{width:100%}kendo-dropdownlist.ng-invalid.ng-touched.remove-ddl-red-border>span,.k-dropdown.ng-invalid.ng-dirty.remove-ddl-red-border>.k-dropdown-wrap,.k-dropdown.ng-invalid.ng-touched>.k-dropdown-wrap{border:0px!important;box-shadow:0 0!important}\n"] }]
        }], ctorParameters: () => [{ type: KendoGridService }, { type: GridRootHelper }, { type: GridPublicService }, { type: GridDropdownService }], propDecorators: { useForm: [{
                type: Input
            }], column: [{
                type: Input
            }], id: [{
                type: Input
            }], filterable: [{
                type: Input
            }], defaultItem: [{
                type: Input
            }], textField: [{
                type: Input
            }], valueField: [{
                type: Input
            }], valuePrimitive: [{
                type: Input
            }], controlName: [{
                type: Input
            }], formGroup: [{
                type: Input
            }], selected: [{
                type: Input
            }], ddl: [{
                type: Input
            }], selectedChange: [{
                type: Output
            }], valueChange: [{
                type: Output
            }], open: [{
                type: Output
            }], reload: [{
                type: Output
            }], sourceChange: [{
                type: Output
            }], source: [{
                type: Input
            }] } });

class SharedManager {
    comp;
    SHOWN_THRESHOLD = 50;
    allRows;
    store;
    column;
    field;
    valueField;
    textField;
    values;
    curPageNum = 0;
    shutdownPagination;
    selectAllChecked = false;
    // Per ora gestiamo solo il caso non primitive.
    isPrimitive = true;
    constructor(comp) {
        this.comp = comp;
        this.init({
            textField: comp.textField,
            valueField: comp.valueField,
            currentFilter: comp.currentFilter,
            field: comp.field,
            allRows: comp.grid.value.data.rows,
            store: comp.gridWorker.resultsStore,
            shutdownPagination: comp.shutdownPagination,
            ordering: comp.ordering
        });
    }
    // ! Sincronizza i campi del manager con quelli della componente.
    init(inpt) {
        this.field = inpt.field;
        this.setColumn(this.comp.grid.value.data.columns);
        this.allRows = this.map(inpt.allRows, inpt.ordering);
        this.store = inpt.store;
        this.shutdownPagination = inpt.shutdownPagination;
        this.values = this.mapFilters(inpt.currentFilter);
    }
    getColumn() {
        return this.column;
    }
    dataWasInitialized() {
        return this.shownData.length === 0 && this.allRows.length != 0;
    }
    fetchNewPage() {
        const set = this.findNextDataPacket();
        if (this.dataWasInitialized()) {
            this.shownData = [...this.shownData, ...set];
        }
        else {
            this.shownData = [...set];
        }
        this.curPageNum++;
    }
    transitionToDistinctRows = false;
    // ! Utilizzata per mappare gli elemnenti della paginazione.
    findNextDataPacket() {
        let set = new Set();
        if (!this.transitionToDistinctRows) {
            let rows = this.allRows;
            if (!rows) {
                rows = this.distinctRows;
            }
            let [init, final] = this.getIterationLowerUpperBounds();
            if (final > rows.length) {
                final = rows.length;
                this.shutdownPagination.next();
                if (init > rows.length) {
                    return new Set();
                }
            }
            set = new Set(rows.slice(init, final));
        }
        else { // < used when making the transition between worker data and the data
            // < displayed initially.
            let [init, final] = this.getIterationLowerUpperBounds(1);
            const distinctRows = this.distinctRows;
            if (final > distinctRows.length) {
                final = distinctRows.length;
                this.shutdownPagination.next();
                if (init > distinctRows.length) {
                    return new Set();
                }
            }
            const lastElem = this.shownData[this.shownData.length - 1];
            set = new Set(this.distinctRows.slice(init, final));
            set.delete(lastElem); // < remove item used for making the transition.
            this.transitionToDistinctRows = false;
        }
        return set;
    }
    getIterationLowerUpperBounds(offset = 0) {
        const init = this.curPageNum * this.SHOWN_THRESHOLD - offset;
        const final = this.curPageNum * this.SHOWN_THRESHOLD + this.SHOWN_THRESHOLD;
        return [init, final];
    }
    initDataNoPagination() {
        this.distinctRows = this.store[this.field];
        this.shownData = this.store[this.field];
        if (this.values.length === this.shownData.length)
            this.selectAllChecked = true;
        else
            this.selectAllChecked = false;
    }
    showAllDataIfBelowThreshold() {
        if (this.shownData.length < this.SHOWN_THRESHOLD) {
            this.shownData = this.distinctRows;
            this.shutdownPagination.next();
        }
    }
    distinctRowsLoaded() {
        this.distinctRows = this.store[this.field];
        this.allRows = null; // < no need to use allRows anymore.
        this.transitionToDistinctRows = true;
    }
    onSelectionChange(item, filterService) {
        this.selectOrDeselectItem(item);
        let filters = [];
        filters = this.values.map((value) => {
            if (isNullOrUndefined(value)) {
                return {
                    field: this.field,
                    operator: 'isnull',
                    value
                };
            }
            else if (value !== '' && this['type'] === 'multi') {
                return {
                    field: this.field,
                    operator: 'contains',
                    value
                };
            }
            else if (value !== '') {
                return {
                    field: this.field,
                    operator: 'eq',
                    value
                };
            }
            else {
                return {
                    field: this.field,
                    operator: 'isempty', // < display empty items.
                    value
                };
            }
        });
        filterService.filter({
            filters: filters,
            logic: 'or',
        });
    }
    selectOrDeselectItem(item) {
        if (this.values.some((x) => x === this.parseValue(item))) {
            // item unselected.
            this.values = this.values.filter((x) => x !== item);
        }
        else { // < item selected.
            this.values.push(this.parseValue(item));
        }
    }
    onSelectAllStringDropdown(service) {
        this.updateSelectedValues();
        let filters = [];
        filters = this.values.map((value) => {
            if (value !== '') {
                return {
                    field: this.field,
                    operator: 'eq',
                    value
                };
            }
            else {
                return {
                    field: this.field,
                    operator: 'isempty', // < display empty items.
                    value
                };
            }
        });
        service.filter({
            filters: filters,
            logic: 'or',
        });
    }
    updateSelectedValues() {
        if (!this.selectAllChecked) {
            this.shownData.forEach(s => this.values.push(this.parseValue(s)));
            this.selectAllChecked = true;
        }
        else {
            this.values = [];
            this.selectAllChecked = false;
        }
    }
}

class StringManager extends SharedManager {
    mapFilters(descriptor) {
        return descriptor.filters.map((f) => f.value);
    }
    distinctRows = [];
    shownData = [];
    setColumn(cols) {
        this.column = null;
    }
    map(rows, ordering) {
        return (ordering == null ? rows : ordering(rows)).map(d => d[this.field]);
    }
    textAccessor(dataItem) {
        return this.isPrimitive ? dataItem : dataItem[this.textField];
    }
    valueAccessor(dataItem) {
        return this.isPrimitive ? dataItem : dataItem[this.valueField];
    }
    filter(text) {
        const fillterBy = filterBy(this.distinctRows, {
            operator: 'contains',
            field: this.textField,
            value: text,
        });
        const shownData = this.shownData;
        this.shownData = distinct([
            ...shownData.filter((dataItem) => this.values.some((val) => val === this.valueAccessor(dataItem))),
            ...fillterBy,
        ], this.textField);
    }
    parseValue(item) {
        return item;
    }
    // ! Called from the html template
    isItemSelected(item) {
        return this.values.some((x) => x === this.valueAccessor(item));
    }
    onSelectAll(service) {
        this.onSelectAllStringDropdown(service);
    }
}

class DropdownManager extends SharedManager {
    mapFilters(descriptor) {
        return descriptor.filters.map((f) => f.value);
    }
    shownData = [];
    distinctRows = [];
    constructor(that) {
        super(that);
    }
    setColumn(cols) {
        this.column = cols.find(c => c.field === this.field);
        this.textField = this.column.ddl.textField;
        this.valueField = this.column.ddl.valueField;
    }
    map(rows, ordering) {
        const result = new Array();
        const ddl = this.column.ddl;
        const empty = { id: '', name: '' };
        const nullItem = { id: null, name: null };
        (ordering == null ? rows : ordering(rows)).forEach(r => {
            const rowVal = r[this.field];
            if (rowVal == null) {
                result.push(nullItem);
                return;
            }
            const col = ddl.data.find(item => item.id === this.valueAccessor(rowVal));
            if (rowVal === '') {
                result.push(empty);
            }
            else if (col) {
                result.push(col);
            }
            else {
                result.push(new DropdownListItem(r[ddl.formControlName], r[ddl.descriptionField]));
            }
        });
        return result;
    }
    valueAccessor(value) {
        if (typeof (value) === 'object') {
            let val = value;
            return val.id;
        }
        else {
            return value;
        }
    }
    textAccessor(dataItem) {
        return dataItem.name;
    }
    getColumn() {
        return this.column;
    }
    filter(text) {
        const fillterBy = filterBy(this.distinctRows, {
            operator: 'contains',
            field: this.textField,
            value: text,
        });
        const shownData = this.shownData;
        this.shownData = distinct([
            ...shownData.filter((dataItem) => this.values.some((val) => val === this.valueAccessor(dataItem))),
            ...fillterBy,
        ], this.textField);
    }
    parseValue(item) {
        if ((typeof item === 'string' || item instanceof String) ||
            (typeof item === 'number' || item instanceof Number))
            return item;
        else
            return item?.id;
    }
    // ! Called from the html template
    isItemSelected(item) {
        return this.values.some((x) => x === this.valueAccessor(item));
    }
    onSelectAll(service) {
        this.onSelectAllStringDropdown(service);
    }
}

class MultiDropdownManager extends SharedManager {
    shownData = [];
    distinctRows = [];
    /** Definisce il tipo di Manager. Usato per determinare la modalità
     * di filtro usato nella funzione `onSelectionChange`. */
    type = 'multi';
    constructor(that) {
        super(that);
        this.setColumn(that.grid.value.data.columns);
    }
    mapFilters(descriptor) {
        return descriptor.filters.map((f) => f.value);
    }
    setColumn(cols) {
        this.column = cols.find(c => c.field === this.field);
        this.textField = this.column.ddl.textField;
        this.valueField = this.column.ddl.valueField;
    }
    map(rows, ordering) {
        const result = new Array();
        const ddl = this.column.ddl;
        const empty = { id: '', name: '' };
        const nullItem = { id: null, name: null };
        (ordering == null ? rows : ordering(rows)).forEach(r => {
            const rowVal = r[this.field];
            if (rowVal == null) {
                result.push(nullItem);
                return;
            }
            // Filtro i DropdownListItems con il codice tra quelli scelti
            const col = ddl.data.filter(x => rowVal.includes(x.id));
            if (rowVal === '') {
                result.push(empty);
            }
            else if (col) {
                result.push(...col);
            }
            else {
                result.push(new DropdownListItem(r[ddl.formControlName], r[ddl.descriptionField]));
            }
        });
        return result;
    }
    valueAccessor(value) {
        if (typeof (value) === 'object') {
            let val = value;
            return val.id;
        }
        else {
            return value;
        }
    }
    textAccessor(dataItem) {
        return dataItem.name;
    }
    getColumn() {
        return this.column;
    }
    filter(text) {
        const fillterBy = filterBy(this.distinctRows, {
            operator: 'contains',
            field: this.textField,
            value: text,
        });
        const shownData = this.shownData;
        this.shownData = distinct([
            ...shownData.filter((dataItem) => this.values.some((val) => val === this.valueAccessor(dataItem))),
            ...fillterBy,
        ], this.textField);
    }
    parseValue(item) {
        if ((typeof item === 'string' || item instanceof String) ||
            (typeof item === 'number' || item instanceof Number))
            return item;
        else
            return item?.id;
    }
    // ! Called from the html template
    isItemSelected(item) {
        return this.values.some((x) => x === this.valueAccessor(item));
    }
    onSelectAll(service) {
        this.onSelectAllStringDropdown(service);
    }
}

class DateManager extends SharedManager {
    distinctRows = [];
    shownData = [];
    map(rows, ordering) {
        return (ordering == null ? rows : ordering(rows)).map(d => d[this.field]);
    }
    setColumn(cols) {
        this.column = null;
    }
    textAccessor(dataItem) {
        return this.isPrimitive ?
            dateToStr(dataItem) : dateToStr(dataItem[this.textField]);
    }
    valueAccessor(dataItem) {
        return this.isPrimitive ?
            dataItem : dataItem[this.valueField];
    }
    filter(date) {
        var _filterBy = filterBy(this.distinctRows, date.filterDescriptors);
        const shownData = this.shownData;
        const checkedRows = shownData.filter((dataItem) => this.values.some((val) => val === this.valueAccessor(dataItem)));
        const arr = [...checkedRows, ..._filterBy];
        this.shownData = distinct(arr, this.textField);
    }
    parseValue(item) {
        return item;
    }
    mapFilters(descriptor) {
        return descriptor.filters.map((filter) => {
            return filter.value;
        });
    }
    // ! Called from the html template
    isItemSelected(item) {
        return this.values.some((x) => x.getTime() === this.valueAccessor(item).getTime());
    }
    onSelectAll(service) {
        this.updateSelectedValues();
        const filters = this.values.map((value) => {
            if (value !== '') {
                return {
                    field: this.field,
                    operator: 'eq',
                    value
                };
            }
            return null;
        });
        service.filter({
            filters: filters,
            logic: 'or',
        });
    }
}
function dateToStr(date) {
    if (date instanceof Date)
        return date.toLocaleDateString() + ' - ' + date.toLocaleTimeString();
    else
        return date;
}

class NumberManager extends SharedManager {
    mapFilters(descriptor) {
        return descriptor.filters.map((f) => f.value);
    }
    distinctRows = [];
    shownData = [];
    setColumn(cols) {
        this.column = null;
    }
    map(rows, ordering) {
        return (ordering == null ? rows : ordering(rows)).map(d => d[this.field]);
    }
    textAccessor(dataItem) {
        return this.isPrimitive ? dataItem : dataItem[this.textField];
    }
    valueAccessor(dataItem) {
        return this.isPrimitive ? dataItem : dataItem[this.valueField];
    }
    filter(text) {
        const fillterBy = filterBy(this.distinctRows, {
            operator: 'contains',
            field: this.textField,
            value: text,
        });
        const shownData = this.shownData;
        this.shownData = distinct([
            ...shownData.filter((dataItem) => this.values.some((val) => val === this.valueAccessor(dataItem))),
            ...fillterBy,
        ], this.textField);
    }
    parseValue(item) {
        return item;
    }
    // ! Called from the html template
    isItemSelected(item) {
        return this.values.some((x) => x === this.valueAccessor(item));
    }
    onSelectAll(service) {
        this.onSelectAllStringDropdown(service);
    }
}

class MulticheckInput {
    textField;
    valueField;
    currentFilter;
    allRows;
    store;
    field;
    shutdownPagination;
    ordering;
}
var WorkType;
(function (WorkType) {
    WorkType[WorkType["String"] = 0] = "String";
    WorkType[WorkType["Dropdown"] = 1] = "Dropdown";
})(WorkType || (WorkType = {}));
const operators = [
    { id: 'eq', name: 'Equal to' },
    { id: 'neq', name: 'Not equal to' },
    { id: 'isnull', name: 'Is equal to null' },
    { id: 'isnotnull', name: 'Is not equal to null' },
    { id: 'lt', name: 'Less than' },
    { id: 'lte', name: 'Less than or equal to' },
    { id: 'gt', name: 'Greater than' },
    { id: 'gte', name: 'Greater than or equal to' }
];
const logicalOperators = [
    { id: 'and', name: 'And' },
    { id: 'or', name: 'Or' }
];
class PopupSettingsManager {
    settings = {
        popupClass: 'timepicker-filter'
    };
    filterContainer;
    initializeFilterContainer(element) {
        this.filterContainer = closest(element.nativeElement, node => (String(node.className).indexOf('k-filter-menu-container') >= 0));
    }
}
const closest = (node, predicate) => {
    while (node && !predicate(node)) {
        node = node.parentNode;
    }
    return node;
};

class DateFilters {
    start;
    end;
    filterDescriptors;
}
var FILTER_MODES;
(function (FILTER_MODES) {
    FILTER_MODES[FILTER_MODES["BASIC_FILTERS"] = 0] = "BASIC_FILTERS";
    FILTER_MODES[FILTER_MODES["ADVANCED_FILTERS"] = 1] = "ADVANCED_FILTERS";
})(FILTER_MODES || (FILTER_MODES = {}));
class filtersManager {
    basicFilteringMode = FILTER_MODES.BASIC_FILTERS;
    extendedFilteringMode = FILTER_MODES.ADVANCED_FILTERS;
    activeMode = FILTER_MODES.BASIC_FILTERS;
    advancedModeActive = false;
    faCog = faCog;
    switchColor = '#dc3545';
    changingSettingsMode = false;
    switchActiveMode() {
        this.activeMode = this.activeMode === this.basicFilteringMode ?
            this.extendedFilteringMode : this.basicFilteringMode;
        this.switchColor = this.switchColor === 'cornflowerblue' ?
            '#dc3545' : 'cornflowerblue';
        this.changingSettingsMode = true;
    }
    /**
     * Prevents popup from closing if the filtering mode has been recently
     * changed. Strangely the popup would normally close when the
     * switchActiveMode() method is called. This has to do with the use of
     * the ng-template #settingsFooter in the view.
    */
    preventPopupCloseIfRequired(e) {
        if (this.changingSettingsMode) {
            this.changingSettingsMode = false;
            e.preventDefault();
        }
    }
}
class FormValueManager {
    firstOpDefault = { id: 'gte', name: 'Greater than or equal to' };
    secondOpDefault = { id: 'lte', name: 'Less than or equal to' };
    logicOpDefault = { id: 'and', name: 'And' };
    start;
    end;
    operators;
    logicOperators;
    firstOperator = this.firstOpDefault;
    secondOperator = this.secondOpDefault;
    logicOperator = this.logicOpDefault;
    constructor(transloco) {
        this.operators = this.translateOperators(transloco);
        this.logicOperators = this.translateLogicalOperators(transloco);
    }
    hasFilters() {
        return this.start != null || this.end != null;
    }
    clearFilters() {
        this.start = null;
        this.end = null;
    }
    resetOperators() {
        this.firstOperator = this.firstOpDefault;
        this.secondOperator = this.secondOpDefault;
        this.logicOperator = this.logicOpDefault;
    }
    translateOperators(transloco) {
        let eq = transloco.translate('giasgrid.eq');
        let neq = transloco.translate('giasgrid.neq');
        let isnull = transloco.translate('giasgrid.isnull');
        let isnotnull = transloco.translate('giasgrid.isnotnull');
        let lt = transloco.translate('giasgrid.lt');
        let lte = transloco.translate('giasgrid.lte');
        let gt = transloco.translate('giasgrid.gt');
        let gte = transloco.translate('giasgrid.gte');
        return [
            { id: 'eq', name: eq },
            { id: 'neq', name: neq },
            { id: 'isnull', name: isnull },
            { id: 'isnotnull', name: isnotnull },
            { id: 'lt', name: lt },
            { id: 'lte', name: lte },
            { id: 'gt', name: gt },
            { id: 'gte', name: gte }
        ];
    }
    translateLogicalOperators(transloco) {
        let and = transloco.translate('giasgrid.and');
        let or = transloco.translate('giasgrid.or');
        return [
            { id: 'and', name: and },
            { id: 'or', name: or }
        ];
    }
}

class DateRangeFilterComponent {
    changeDetector;
    element;
    transloco;
    renderer;
    filter;
    filterService;
    manager;
    field;
    filterChange = new EventEmitter();
    // Manages the values of the view
    formValueManager;
    // Manages the two filter operating modes
    filtersManager = new filtersManager();
    // Discards onClose events when the timePicker is selected
    popupManager = new PopupSettingsManager();
    // Used for subscriptions
    signal = new Subject();
    constructor(changeDetector, element, popupService, transloco, renderer) {
        this.changeDetector = changeDetector;
        this.element = element;
        this.transloco = transloco;
        this.renderer = renderer;
        this.formValueManager = new FormValueManager(this.transloco);
        // Prevents the popup from closing when a datepicker date has been
        // clicked.
        popupService.onClose.pipe(takeUntil$1(this.signal)).subscribe((e) => {
            this.filtersManager.preventPopupCloseIfRequired(e);
            if (document.activeElement && closest(document.activeElement, node => node === this.element.nativeElement || (String(node.className).indexOf('timepicker-filter') >= 0))) {
                e.preventDefault();
            }
        });
    }
    get filters() {
        return this.filtersManager;
    }
    get values() {
        return this.formValueManager;
    }
    ngAfterViewInit() {
        this.popupManager.initializeFilterContainer(this.element);
        this.setFilterContainerWidth();
    }
    switchActiveMode() {
        this.filtersManager.switchActiveMode();
        this.values.resetOperators();
        // if(this.filtersManager.activeMode === FILTER_MODES.BASIC_FILTERS) {
        //     this.setFilterContainerWidth();
        // } else {
        //     this.setFilterContainerWidth();
        // }
        this.setFilterContainerWidth();
    }
    clearFilter() {
        this.filterRange(null, null);
    }
    filterRange(start, end) {
        const filters = [];
        const startOp = this.transformOperator(this.values.firstOperator.id, start);
        if (startOp != null) {
            filters.push(startOp);
        }
        const endOp = this.transformOperator(this.values.secondOperator.id, end);
        if (endOp != null) {
            filters.push(endOp);
        }
        const root = this.filter || {
            logic: this.values.logicOperator.id,
            filters: [],
        };
        if (filters.length) {
            root.filters.push(...filters);
        }
        this.filterChange.emit({
            start: start,
            end: end,
            filterDescriptors: root
        });
    }
    transformOperator(operatorType, date) {
        if (operatorType === 'isnull') {
            return {
                operator: 'isnull'
            };
        }
        if (operatorType === 'isnotnull') {
            return {
                operator: 'isnotnull'
            };
        }
        if (date == null) {
            return null;
        }
        if (operatorType === 'eq') {
            return {
                logic: 'and',
                filters: [
                    { operator: 'gte', value: date.setHours(0, 0, 0, 0) },
                    { operator: 'lte', value: date.setHours(23, 59, 59, 0) }
                ]
            };
        }
        if (operatorType === 'neq') {
            return {
                logic: 'or',
                filters: [
                    { operator: 'lt', value: date.setHours(0, 0, 0, 0) },
                    { operator: 'gt', value: date.setHours(23, 59, 59, 0) }
                ]
            };
        }
        return {
            operator: operatorType,
            value: date,
        };
    }
    refreshFilters() {
        this.filterRange(this.values.start, this.values.end);
    }
    onSelectAll() {
        this.manager.onSelectAll(this.filterService);
    }
    ngOnDestroy() {
        this.signal.next();
        this.signal.complete();
    }
    setFilterContainerWidth() {
        if (this.filtersManager.activeMode === FILTER_MODES.BASIC_FILTERS) {
            this.renderer.setStyle(this.popupManager.filterContainer, 'width', '350px');
        }
        else if (this.filtersManager.activeMode === FILTER_MODES.ADVANCED_FILTERS) {
            this.renderer.setStyle(this.popupManager.filterContainer, 'width', '450px');
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: DateRangeFilterComponent, deps: [{ token: i0.ChangeDetectorRef }, { token: i0.ElementRef }, { token: i11.SinglePopupService }, { token: i1$1.TranslocoService }, { token: i0.Renderer2 }], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "19.2.9", type: DateRangeFilterComponent, isStandalone: false, selector: "gias-date-range-filter-cell", inputs: { filter: "filter", filterService: "filterService", manager: "manager", field: "field" }, outputs: { filterChange: "filterChange" }, ngImport: i0, template: "\n<ng-container *ngIf=\"filters.activeMode === filters.basicFilteringMode;\n    then showBasicFilters else showExtendedFilters\">\n</ng-container>\n\n<ng-template #showBasicFilters>\n    <div class=\"row\">\n        <div class=\"col-6\">\n            {{ 'giasgrid.DA' | transloco }}\n        </div>\n        <div class=\"col-6\">\n            {{ 'giasgrid.A' | transloco }}\n        </div>\n    </div>\n    <ng-container *ngTemplateOutlet=\"showDates\"></ng-container>\n    <ng-container *ngTemplateOutlet=\"settingsFooter\"></ng-container>\n</ng-template>\n\n<ng-template #showExtendedFilters>\n    <div class=\"row mb-2\">\n        <div style=\"width: 40%;\">\n            <kendo-dropdownlist\n                class=\"k-widget k-dropdown k-header\"\n                [data]=\"values.operators\"\n                textField=\"name\"\n                valueField=\"id\"\n                [valuePrimitive]=\"false\"\n                [(value)]=\"values.firstOperator\"\n                (valueChange)=\"refreshFilters()\"\n                [popupSettings]=\"{width: 'auto'}\"\n                style=\"width: auto;\"\n            >\n            </kendo-dropdownlist>\n        </div>\n        <div style=\"width: 20%;\">\n            <kendo-dropdownlist\n                class=\"k-widget k-dropdown k-header\"\n                [data]=\"values.logicOperators\"\n                textField=\"name\"\n                valueField=\"id\"\n                [valuePrimitive]=\"false\"\n                [(value)]=\"values.logicOperator\"\n                (valueChange)=\"refreshFilters()\"\n                [popupSettings]=\"{width: 'auto'}\"\n                style=\"width: auto;\"\n            >\n            </kendo-dropdownlist>\n        </div>\n        <div style=\"width: 40%;\">\n            <kendo-dropdownlist\n                class=\"k-widget k-dropdown k-header\"\n                [data]=\"values.operators\"\n                textField=\"name\"\n                valueField=\"id\"\n                [valuePrimitive]=\"false\"\n                [(value)]=\"values.secondOperator\"\n                (valueChange)=\"refreshFilters()\"\n                [popupSettings]=\"{width: 'auto'}\"\n                style=\"width: auto;\"\n            >\n            </kendo-dropdownlist>\n        </div>\n    </div>\n    <ng-container *ngTemplateOutlet=\"showDates\"></ng-container>\n    <ng-container *ngTemplateOutlet=\"settingsFooter\"></ng-container>\n</ng-template>\n\n<ng-template #showDates>\n    <div class=\"row\">\n        <div class=\"col-6\" >\n            <kendo-datepicker *ngIf=\"values.firstOperator.id !== 'isnull' &&\n                                    values.firstOperator.id !== 'isnotnull'\"\n                [popupSettings]=\"popupManager.settings\"\n                class=\"k-widget range-filter\"\n                [(value)]=\"values.start\"\n                (valueChange)=\"filterRange($event, values.end)\"\n                style=\"width:auto;\" calendarType=\"classic\">\n            </kendo-datepicker>\n        </div>\n        <div class=\"col-6\">\n            <kendo-datepicker *ngIf=\"values.secondOperator.id !== 'isnull' &&\n                                     values.secondOperator.id !== 'isnotnull'\"\n                [popupSettings]=\"popupManager.settings\"\n                class=\"k-widget range-filter\"\n                [(value)]=\"values.end\"\n                (valueChange)=\"filterRange(values.start, $event)\"\n                style=\"width:auto;\" calendarType=\"classic\">\n            </kendo-datepicker>\n        </div>\n    </div>\n</ng-template>\n\n<ng-template #settingsFooter>\n    <div style=\"display: flex; align-items: center;\" class=\"mt-1\">\n        <div *ngIf=\"values.hasFilters()\">\n            <div\n            (click)=\"onSelectAll()\"\n            [ngClass]=\"{ 'k-selected': manager.selectAllChecked }\"\n            class=\"multicheck-item multicheck-item-select-all\">\n                <input\n                    type=\"checkbox\"\n                    id=\"chk-selectAll\"\n                    class=\"k-checkbox\"\n                    [checked]=\"manager.selectAllChecked\"\n                />\n                <label\n                    class=\"k-multiselect-checkbox k-checkbox-label\"\n                    for=\"chk-selectAll\"\n                >\n                    {{ 'giasgrid.Select_All' | transloco }}\n                </label>\n            </div>\n        </div>\n        <div style=\"flex: 1 1 auto\" class=\"d-flex justify-content-end\">\n            <div style=\"cursor: pointer;\" class=\"highlightOnHover\" (click)=\"switchActiveMode()\">\n                <fa-icon style=\"padding-right: 5px;\"\n                        [title]=\"'giasgrid.SwitchFilterModes' | transloco\"\n                        [ngStyle]=\"{'color': filters.switchColor}\"\n                        size=\"lg\"\n                        [icon]=\"filters.faCog\"\n                        aria-hidden=\"true\">\n                </fa-icon>\n                <span>{{ filters.activeMode === filters.extendedFilteringMode\n                    ? ('giasgrid.BasicFilters' | transloco): 'giasgrid.ExtendedFilters' | transloco }}\n                </span>\n            </div>\n        </div>\n    </div>\n</ng-template>\n", styles: ["kendo-daterange>kendo-dateinput.range-filter{display:inline-block}.k-button{margin-left:5px}.highlightOnHover:hover{color:#ffc000}\n"], dependencies: [{ kind: "directive", type: i3.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: i3.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: i3.NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "directive", type: i3.NgStyle, selector: "[ngStyle]", inputs: ["ngStyle"] }, { kind: "component", type: i6$1.DropDownListComponent, selector: "kendo-dropdownlist", inputs: ["customIconClass", "showStickyHeader", "icon", "svgIcon", "loading", "data", "value", "textField", "valueField", "adaptiveMode", "title", "subtitle", "popupSettings", "listHeight", "defaultItem", "disabled", "itemDisabled", "readonly", "filterable", "virtual", "ignoreCase", "delay", "valuePrimitive", "tabindex", "tabIndex", "size", "rounded", "fillMode", "leftRightArrowsNavigation", "id"], outputs: ["valueChange", "filterChange", "selectionChange", "open", "opened", "close", "closed", "focus", "blur"], exportAs: ["kendoDropDownList"] }, { kind: "directive", type: i5.LabelDirective, selector: "label[for]", inputs: ["for", "labelClass"] }, { kind: "component", type: i15.DatePickerComponent, selector: "kendo-datepicker", inputs: ["focusableId", "cellTemplate", "clearButton", "inputAttributes", "monthCellTemplate", "yearCellTemplate", "decadeCellTemplate", "centuryCellTemplate", "weekNumberTemplate", "headerTitleTemplate", "headerTemplate", "footerTemplate", "footer", "navigationItemTemplate", "weekDaysFormat", "showOtherMonthDays", "activeView", "bottomView", "topView", "calendarType", "animateCalendarNavigation", "disabled", "readonly", "readOnlyInput", "popupSettings", "navigation", "min", "max", "incompleteDateValidation", "autoCorrectParts", "autoSwitchParts", "autoSwitchKeys", "enableMouseWheel", "allowCaretMode", "autoFill", "focusedDate", "value", "format", "twoDigitYearMax", "formatPlaceholder", "placeholder", "tabindex", "tabIndex", "disabledDates", "title", "subtitle", "rangeValidation", "disabledDatesValidation", "weekNumber", "size", "rounded", "fillMode", "adaptiveMode"], outputs: ["valueChange", "focus", "blur", "open", "close", "escape"], exportAs: ["kendo-datepicker"] }, { kind: "component", type: i7.FaIconComponent, selector: "fa-icon", inputs: ["icon", "title", "animation", "mask", "flip", "size", "pull", "border", "inverse", "symbol", "rotate", "fixedWidth", "transform", "a11yRole"] }, { kind: "pipe", type: i1$1.TranslocoPipe, name: "transloco" }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: DateRangeFilterComponent, decorators: [{
            type: Component,
            args: [{ standalone: false, selector: 'gias-date-range-filter-cell', encapsulation: ViewEncapsulation.Emulated, template: "\n<ng-container *ngIf=\"filters.activeMode === filters.basicFilteringMode;\n    then showBasicFilters else showExtendedFilters\">\n</ng-container>\n\n<ng-template #showBasicFilters>\n    <div class=\"row\">\n        <div class=\"col-6\">\n            {{ 'giasgrid.DA' | transloco }}\n        </div>\n        <div class=\"col-6\">\n            {{ 'giasgrid.A' | transloco }}\n        </div>\n    </div>\n    <ng-container *ngTemplateOutlet=\"showDates\"></ng-container>\n    <ng-container *ngTemplateOutlet=\"settingsFooter\"></ng-container>\n</ng-template>\n\n<ng-template #showExtendedFilters>\n    <div class=\"row mb-2\">\n        <div style=\"width: 40%;\">\n            <kendo-dropdownlist\n                class=\"k-widget k-dropdown k-header\"\n                [data]=\"values.operators\"\n                textField=\"name\"\n                valueField=\"id\"\n                [valuePrimitive]=\"false\"\n                [(value)]=\"values.firstOperator\"\n                (valueChange)=\"refreshFilters()\"\n                [popupSettings]=\"{width: 'auto'}\"\n                style=\"width: auto;\"\n            >\n            </kendo-dropdownlist>\n        </div>\n        <div style=\"width: 20%;\">\n            <kendo-dropdownlist\n                class=\"k-widget k-dropdown k-header\"\n                [data]=\"values.logicOperators\"\n                textField=\"name\"\n                valueField=\"id\"\n                [valuePrimitive]=\"false\"\n                [(value)]=\"values.logicOperator\"\n                (valueChange)=\"refreshFilters()\"\n                [popupSettings]=\"{width: 'auto'}\"\n                style=\"width: auto;\"\n            >\n            </kendo-dropdownlist>\n        </div>\n        <div style=\"width: 40%;\">\n            <kendo-dropdownlist\n                class=\"k-widget k-dropdown k-header\"\n                [data]=\"values.operators\"\n                textField=\"name\"\n                valueField=\"id\"\n                [valuePrimitive]=\"false\"\n                [(value)]=\"values.secondOperator\"\n                (valueChange)=\"refreshFilters()\"\n                [popupSettings]=\"{width: 'auto'}\"\n                style=\"width: auto;\"\n            >\n            </kendo-dropdownlist>\n        </div>\n    </div>\n    <ng-container *ngTemplateOutlet=\"showDates\"></ng-container>\n    <ng-container *ngTemplateOutlet=\"settingsFooter\"></ng-container>\n</ng-template>\n\n<ng-template #showDates>\n    <div class=\"row\">\n        <div class=\"col-6\" >\n            <kendo-datepicker *ngIf=\"values.firstOperator.id !== 'isnull' &&\n                                    values.firstOperator.id !== 'isnotnull'\"\n                [popupSettings]=\"popupManager.settings\"\n                class=\"k-widget range-filter\"\n                [(value)]=\"values.start\"\n                (valueChange)=\"filterRange($event, values.end)\"\n                style=\"width:auto;\" calendarType=\"classic\">\n            </kendo-datepicker>\n        </div>\n        <div class=\"col-6\">\n            <kendo-datepicker *ngIf=\"values.secondOperator.id !== 'isnull' &&\n                                     values.secondOperator.id !== 'isnotnull'\"\n                [popupSettings]=\"popupManager.settings\"\n                class=\"k-widget range-filter\"\n                [(value)]=\"values.end\"\n                (valueChange)=\"filterRange(values.start, $event)\"\n                style=\"width:auto;\" calendarType=\"classic\">\n            </kendo-datepicker>\n        </div>\n    </div>\n</ng-template>\n\n<ng-template #settingsFooter>\n    <div style=\"display: flex; align-items: center;\" class=\"mt-1\">\n        <div *ngIf=\"values.hasFilters()\">\n            <div\n            (click)=\"onSelectAll()\"\n            [ngClass]=\"{ 'k-selected': manager.selectAllChecked }\"\n            class=\"multicheck-item multicheck-item-select-all\">\n                <input\n                    type=\"checkbox\"\n                    id=\"chk-selectAll\"\n                    class=\"k-checkbox\"\n                    [checked]=\"manager.selectAllChecked\"\n                />\n                <label\n                    class=\"k-multiselect-checkbox k-checkbox-label\"\n                    for=\"chk-selectAll\"\n                >\n                    {{ 'giasgrid.Select_All' | transloco }}\n                </label>\n            </div>\n        </div>\n        <div style=\"flex: 1 1 auto\" class=\"d-flex justify-content-end\">\n            <div style=\"cursor: pointer;\" class=\"highlightOnHover\" (click)=\"switchActiveMode()\">\n                <fa-icon style=\"padding-right: 5px;\"\n                        [title]=\"'giasgrid.SwitchFilterModes' | transloco\"\n                        [ngStyle]=\"{'color': filters.switchColor}\"\n                        size=\"lg\"\n                        [icon]=\"filters.faCog\"\n                        aria-hidden=\"true\">\n                </fa-icon>\n                <span>{{ filters.activeMode === filters.extendedFilteringMode\n                    ? ('giasgrid.BasicFilters' | transloco): 'giasgrid.ExtendedFilters' | transloco }}\n                </span>\n            </div>\n        </div>\n    </div>\n</ng-template>\n", styles: ["kendo-daterange>kendo-dateinput.range-filter{display:inline-block}.k-button{margin-left:5px}.highlightOnHover:hover{color:#ffc000}\n"] }]
        }], ctorParameters: () => [{ type: i0.ChangeDetectorRef }, { type: i0.ElementRef }, { type: i11.SinglePopupService }, { type: i1$1.TranslocoService }, { type: i0.Renderer2 }], propDecorators: { filter: [{
                type: Input
            }], filterService: [{
                type: Input
            }], manager: [{
                type: Input
            }], field: [{
                type: Input
            }], filterChange: [{
                type: Output
            }] } });

class MultiCheckFilterComponent {
    changeDetector;
    grids;
    gridWorker;
    type;
    STRING = CELL_TYPES.STRING;
    DATE = CELL_TYPES.DATE;
    DATETIME = CELL_TYPES.DATETIME;
    DROPDOWNLIST = CELL_TYPES.DROPDOWNLIST;
    MULTI_DROPDOWNLIST = CELL_TYPES.MULTI_DROPDOWNLIST;
    NUMBER = CELL_TYPES.NUMBER;
    isPrimitive;
    currentFilter;
    textField;
    valueField;
    filterService;
    field;
    multiIndex;
    showHTMLAsString;
    ordering = null;
    valueChange = new EventEmitter();
    shutdownPagination = new Subject();
    showFilter = true;
    grid;
    filterText = '';
    searchDisabled = true;
    signal = new Subject();
    manager;
    constructor(changeDetector, grids, gridWorker) {
        this.changeDetector = changeDetector;
        this.grids = grids;
        this.gridWorker = gridWorker;
    }
    ngOnInit() {
        if (this.multiIndex != null && Array.isArray(this.grids)) {
            this.grid = this.grids.find(s => s.multiIndex === this.multiIndex);
        }
        else {
            this.grid = this.grids;
        }
        // Setting up the manager.
        if (this.type === CELL_TYPES.STRING) {
            this.manager = new StringManager(this);
        }
        else if (this.type === CELL_TYPES.DROPDOWNLIST) {
            this.manager = new DropdownManager(this);
        }
        else if (this.type === CELL_TYPES.MULTI_DROPDOWNLIST) {
            this.manager = new MultiDropdownManager(this);
        }
        else if (this.type === CELL_TYPES.DATE) {
            this.manager = new DateManager(this);
        }
        else if (this.type === CELL_TYPES.DATETIME) {
            this.manager = new DateManager(this);
        }
        else if (this.type === CELL_TYPES.NUMBER) {
            this.manager = new NumberManager(this);
        }
        if (!this.gridWorker.alreadySubed) {
            this.gridWorker.refreshWorker();
        }
        this.serveWorkerData();
    }
    paginationEnabled = false;
    serveWorkerData() {
        const store = this.manager.store;
        if (store[this.field] == null) {
            // Scatta l'evento quando il worker finisce lavoro.
            this.gridWorker.workLoad.pipe(takeUntil(this.signal))
                .subscribe(_ => {
                this.searchDisabled = false;
                this.manager.distinctRowsLoaded();
                // Nel caso in cui ci sono pocchi risultati, possiamo farli comparire
                // tutti appena sono pronti.
                this.manager.showAllDataIfBelowThreshold();
                this.changeDetector.detectChanges();
            });
            this.gridWorker.runTaskDistinct(this.manager.allRows, this.field, this.type, this.manager.getColumn(), this.ordering == null);
            this.paginationEnabled = true;
        }
        else {
            // Lavoro è stato già compiuto.
            this.searchDisabled = false;
            this.manager.initDataNoPagination();
            this.changeDetector.detectChanges();
        }
    }
    onSelectAll() {
        this.manager.onSelectAll(this.filterService);
    }
    handler(ev) {
        // Smooth transition on loading new items.
    }
    onSelectionChange(item, li) {
        this.manager.onSelectionChange(item, this.filterService);
    }
    onInput(e) {
        // Manage filters.
        this.filterText = e.target.value;
        this.manager.filter(this.filterText);
    }
    filterItems(filters) {
        this.manager.filter(filters);
    }
    ngOnDestroy() {
        this.signal.next();
        this.signal.complete();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: MultiCheckFilterComponent, deps: [{ token: i0.ChangeDetectorRef }, { token: GridPublicService }, { token: GridWorkerService }], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "19.2.9", type: MultiCheckFilterComponent, isStandalone: false, selector: "gias-multicheck-filter", inputs: { type: "type", isPrimitive: "isPrimitive", currentFilter: "currentFilter", textField: "textField", valueField: "valueField", filterService: "filterService", field: "field", multiIndex: "multiIndex", showHTMLAsString: "showHTMLAsString", ordering: "ordering" }, outputs: { valueChange: "valueChange" }, ngImport: i0, template: "<div class=\"container filtersContainer\">\n    <ng-container>\n        <ng-container *ngIf=\"type === STRING || type === DROPDOWNLIST || type === NUMBER || type === MULTI_DROPDOWNLIST\">\n            <div class=\"row\">\n              <ul>\n                <li *ngIf=\"showFilter\">\n                  <input class=\"k-textbox\" (input)=\"onInput($event)\"\n                         [disabled]=\"searchDisabled\"\n                         [placeholder]=\"searchDisabled?\n          ('giasgrid.Caricamento' | transloco): ('giasgrid.Ricerca'| transloco)\"/>\n                </li>\n              </ul>\n                <ng-container *ngIf=\"filterText.length != 0\">\n                    <div\n                        (click)=\"onSelectAll()\"\n                        [ngClass]=\"{ 'k-selected': manager.selectAllChecked }\"\n                        class=\"multicheck-item multicheck-item-select-all\">\n                        <input\n                            type=\"checkbox\"\n                            id=\"chk-selectAll\"\n                            class=\"k-checkbox fixedSize\"\n                            [checked]=\"manager.selectAllChecked\"\n                        />\n                        <label\n                            class=\"k-multiselect-checkbox k-checkbox-label\"\n                            for=\"chk-selectAll\"\n                        >\n                            {{ 'giasgrid.Select_All' | transloco }}\n                        </label>\n                    </div>\n                </ng-container>\n            </div>\n        </ng-container>\n\n        <ng-container *ngIf=\"type === DATE\">\n            <gias-date-range-filter-cell\n                [filterService]=\"filterService\"\n                [manager]=\"manager\"\n                [field]=\"field\"\n                (filterChange)=\"filterItems($event)\"\n            >\n            </gias-date-range-filter-cell>\n        </ng-container>\n\n      <ng-container *ngIf=\"type === DATETIME\">\n          <gias-date-range-filter-cell\n              [filterService]=\"filterService\"\n              [manager]=\"manager\"\n              [field]=\"field\"\n              (filterChange)=\"filterItems($event)\"\n          >\n          </gias-date-range-filter-cell>\n      </ng-container>\n\n        <cdk-virtual-scroll-viewport\n            (scrolledIndexChange)=\"handler($event)\"\n            autosize\n            class=\"multicheck-viewport\">\n            <div\n                #itemElement\n                *cdkVirtualFor=\"let item of manager.shownData; let i = index\"\n                (click)=\"onSelectionChange(manager.valueAccessor(item), itemElement)\"\n                [ngClass]=\"{ 'k-selected': manager.isItemSelected(item) }\"\n                class=\"multicheck-item pb-2\">\n                <div class=\"row\">\n                    <div class=\"col-12 oneline\">\n                        <input\n                            type=\"checkbox\"\n                            id=\"chk-{{ manager.valueAccessor(item) }}\"\n                            class=\"k-checkbox fixedSize\"\n                            [checked]=\"manager.isItemSelected(item)\"\n                        />\n                        <label\n                            class=\"k-multiselect-checkbox k-checkbox-label\"\n                            for=\"chk-{{ manager.valueAccessor(item) }}\"\n                            *ngIf=\"showHTMLAsString\">\n                            <div [innerHtml]=\"manager.textAccessor(item)\"></div>\n                        </label>\n\n                        <label\n                            class=\"k-multiselect-checkbox k-checkbox-label\"\n                            for=\"chk-{{ manager.valueAccessor(item) }}\"\n                            *ngIf=\"!showHTMLAsString\">\n                            {{ manager.textAccessor(item) }}\n                        </label>\n\n                    </div>\n                </div>\n            </div>\n        </cdk-virtual-scroll-viewport>\n    </ng-container>\n</div>\n", styles: [".k-multiselect-checkbox{pointer-events:none}.multicheck-viewport{height:200px;width:100%}.multicheck-item{height:auto;display:flex;align-items:center}.multicheck-item-select-all{padding-top:10px;padding-bottom:10px}.k-checkbox{flex:0 0 auto}.fixedSize{width:1rem;height:1rem}.k-checkbox-label{flex:1 1 auto;margin-top:-3px;margin-left:6px!important}cdk-virtual-scroll-viewport{height:100vh}cdk-virtual-scroll-viewport li{height:100px}cdk-virtual-scroll-viewport::-webkit-scrollbar{width:1em}cdk-virtual-scroll-viewport::-webkit-scrollbar-track{-webkit-box-shadow:inset 0 0 6px rgba(0,0,0,.3);box-shadow:inset}cdk-virtual-scroll-viewport::-webkit-scrollbar-thumb{background-color:#eea94f}.k-filter-menu .k-widget{margin:0}.filtersContainer{padding-right:0;padding-left:0}.oneline{display:flex}\n"], dependencies: [{ kind: "directive", type: i3.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: i3.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: i5.LabelDirective, selector: "label[for]", inputs: ["for", "labelClass"] }, { kind: "directive", type: i5$1.CdkVirtualForOf, selector: "[cdkVirtualFor][cdkVirtualForOf]", inputs: ["cdkVirtualForOf", "cdkVirtualForTrackBy", "cdkVirtualForTemplate", "cdkVirtualForTemplateCacheSize"] }, { kind: "component", type: i5$1.CdkVirtualScrollViewport, selector: "cdk-virtual-scroll-viewport", inputs: ["orientation", "appendOnly"], outputs: ["scrolledIndexChange"] }, { kind: "directive", type: i6$2.CdkAutoSizeVirtualScroll, selector: "cdk-virtual-scroll-viewport[autosize]", inputs: ["minBufferPx", "maxBufferPx"] }, { kind: "component", type: DateRangeFilterComponent, selector: "gias-date-range-filter-cell", inputs: ["filter", "filterService", "manager", "field"], outputs: ["filterChange"] }, { kind: "pipe", type: i1$1.TranslocoPipe, name: "transloco" }], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: MultiCheckFilterComponent, decorators: [{
            type: Component,
            args: [{ standalone: false, selector: 'gias-multicheck-filter', changeDetection: ChangeDetectionStrategy.OnPush, encapsulation: ViewEncapsulation.None, template: "<div class=\"container filtersContainer\">\n    <ng-container>\n        <ng-container *ngIf=\"type === STRING || type === DROPDOWNLIST || type === NUMBER || type === MULTI_DROPDOWNLIST\">\n            <div class=\"row\">\n              <ul>\n                <li *ngIf=\"showFilter\">\n                  <input class=\"k-textbox\" (input)=\"onInput($event)\"\n                         [disabled]=\"searchDisabled\"\n                         [placeholder]=\"searchDisabled?\n          ('giasgrid.Caricamento' | transloco): ('giasgrid.Ricerca'| transloco)\"/>\n                </li>\n              </ul>\n                <ng-container *ngIf=\"filterText.length != 0\">\n                    <div\n                        (click)=\"onSelectAll()\"\n                        [ngClass]=\"{ 'k-selected': manager.selectAllChecked }\"\n                        class=\"multicheck-item multicheck-item-select-all\">\n                        <input\n                            type=\"checkbox\"\n                            id=\"chk-selectAll\"\n                            class=\"k-checkbox fixedSize\"\n                            [checked]=\"manager.selectAllChecked\"\n                        />\n                        <label\n                            class=\"k-multiselect-checkbox k-checkbox-label\"\n                            for=\"chk-selectAll\"\n                        >\n                            {{ 'giasgrid.Select_All' | transloco }}\n                        </label>\n                    </div>\n                </ng-container>\n            </div>\n        </ng-container>\n\n        <ng-container *ngIf=\"type === DATE\">\n            <gias-date-range-filter-cell\n                [filterService]=\"filterService\"\n                [manager]=\"manager\"\n                [field]=\"field\"\n                (filterChange)=\"filterItems($event)\"\n            >\n            </gias-date-range-filter-cell>\n        </ng-container>\n\n      <ng-container *ngIf=\"type === DATETIME\">\n          <gias-date-range-filter-cell\n              [filterService]=\"filterService\"\n              [manager]=\"manager\"\n              [field]=\"field\"\n              (filterChange)=\"filterItems($event)\"\n          >\n          </gias-date-range-filter-cell>\n      </ng-container>\n\n        <cdk-virtual-scroll-viewport\n            (scrolledIndexChange)=\"handler($event)\"\n            autosize\n            class=\"multicheck-viewport\">\n            <div\n                #itemElement\n                *cdkVirtualFor=\"let item of manager.shownData; let i = index\"\n                (click)=\"onSelectionChange(manager.valueAccessor(item), itemElement)\"\n                [ngClass]=\"{ 'k-selected': manager.isItemSelected(item) }\"\n                class=\"multicheck-item pb-2\">\n                <div class=\"row\">\n                    <div class=\"col-12 oneline\">\n                        <input\n                            type=\"checkbox\"\n                            id=\"chk-{{ manager.valueAccessor(item) }}\"\n                            class=\"k-checkbox fixedSize\"\n                            [checked]=\"manager.isItemSelected(item)\"\n                        />\n                        <label\n                            class=\"k-multiselect-checkbox k-checkbox-label\"\n                            for=\"chk-{{ manager.valueAccessor(item) }}\"\n                            *ngIf=\"showHTMLAsString\">\n                            <div [innerHtml]=\"manager.textAccessor(item)\"></div>\n                        </label>\n\n                        <label\n                            class=\"k-multiselect-checkbox k-checkbox-label\"\n                            for=\"chk-{{ manager.valueAccessor(item) }}\"\n                            *ngIf=\"!showHTMLAsString\">\n                            {{ manager.textAccessor(item) }}\n                        </label>\n\n                    </div>\n                </div>\n            </div>\n        </cdk-virtual-scroll-viewport>\n    </ng-container>\n</div>\n", styles: [".k-multiselect-checkbox{pointer-events:none}.multicheck-viewport{height:200px;width:100%}.multicheck-item{height:auto;display:flex;align-items:center}.multicheck-item-select-all{padding-top:10px;padding-bottom:10px}.k-checkbox{flex:0 0 auto}.fixedSize{width:1rem;height:1rem}.k-checkbox-label{flex:1 1 auto;margin-top:-3px;margin-left:6px!important}cdk-virtual-scroll-viewport{height:100vh}cdk-virtual-scroll-viewport li{height:100px}cdk-virtual-scroll-viewport::-webkit-scrollbar{width:1em}cdk-virtual-scroll-viewport::-webkit-scrollbar-track{-webkit-box-shadow:inset 0 0 6px rgba(0,0,0,.3);box-shadow:inset}cdk-virtual-scroll-viewport::-webkit-scrollbar-thumb{background-color:#eea94f}.k-filter-menu .k-widget{margin:0}.filtersContainer{padding-right:0;padding-left:0}.oneline{display:flex}\n"] }]
        }], ctorParameters: () => [{ type: i0.ChangeDetectorRef }, { type: GridPublicService }, { type: GridWorkerService }], propDecorators: { type: [{
                type: Input
            }], isPrimitive: [{
                type: Input
            }], currentFilter: [{
                type: Input
            }], textField: [{
                type: Input
            }], valueField: [{
                type: Input
            }], filterService: [{
                type: Input
            }], field: [{
                type: Input
            }], multiIndex: [{
                type: Input
            }], showHTMLAsString: [{
                type: Input
            }], ordering: [{
                type: Input
            }], valueChange: [{
                type: Output
            }] } });

class CustomizationDropdownComponent {
    service;
    dropdownSerivce;
    gridpublicService;
    filtroJSONService;
    signal$ = new Subject();
    /** Dati */
    dropdown;
    /** Campi di input/output */
    filterable = true;
    selected;
    ;
    selectedChange = new EventEmitter();
    applyView = new EventEmitter();
    applyViewAndJSON = new EventEmitter();
    // Elenco che contiene
    source = [];
    sourceChange = new EventEmitter();
    constructor(service, dropdownSerivce, gridpublicService, filtroJSONService) {
        this.service = service;
        this.dropdownSerivce = dropdownSerivce;
        this.gridpublicService = gridpublicService;
        this.filtroJSONService = filtroJSONService;
        this.selected = this.dropdownSerivce.defaultItem;
    }
    /** Initialization */
    ngOnInit() {
        this.dropdownSerivce.pipe(skip(1), takeUntil(this.signal$))
            .subscribe((ddl) => {
            if (!ddl) {
                // should never happen
            }
            else {
                this.init(ddl);
            }
        });
    }
    init(data) {
        this.dropdown = data.dropdown;
        this.source = data.dropdown.data.slice();
        this.selected = data.selected ?? this.dropdownSerivce.nextSelected(this.dropdown);
        this.selectedChange.emit(this.selected);
        const ev = new SelectionChangeEvent({ item: this.selected, isNew: false });
        this.applyView.emit(ev);
    }
    onNgModelChange(item) {
        this.selected = item;
        this.selectedChange.emit(item);
        const ev = new SelectionChangeEvent({ item: item, isNew: false });
        this.applyView.emit(ev);
    }
    handleFilter(value) {
        this.filter = value;
        this.dropdown.data = this.source.filter((s) => s.name.toLowerCase().indexOf(value.toLowerCase()) !== -1);
    }
    changeValue(newValue) {
        this.selected = newValue;
        this.filtroJSONService.applyLoadCacheFirstTime = true;
        this.selectedChange.emit(this.selected);
        const ev = new SelectionChangeEvent({ item: this.selected, isNew: false });
        if (this.gridpublicService.thereIsAForm && !newValue.data.Predefinita)
            this.applyViewAndJSON.emit(ev);
        else
            this.applyView.emit(ev);
    }
    filter;
    addNew() {
        // if (FORBIDDEN_CHARS_FOR_NAMES.some(char => this.filter.includes(char))) {
        //     this.dropdownSerivce.showMessage('NomeContieneCaratteriNonConsentiti');
        //     return;
        // }
        const item = {
            id: this.dropdownSerivce.generateUID(),
            name: this.filter,
            data: {
                Predefinita: false,
                NomeUtente: this.service.username,
                GridId: this.service.CreateNewGridIdforView()
            }
        };
        const items = this.source.push(item) && this.source;
        const ddl = this.dropdownSerivce.getNewDDL(this.dropdown, items);
        this.selected = item;
        this.selectedChange.emit(this.selected);
        const ev = new SelectionChangeEvent({ item: this.selected, isNew: true });
        this.applyView.emit(ev);
        this.dropdownSerivce.next({ dropdown: ddl, selected: this.selected });
        this.handleFilter(this.filter);
        this.service.saveCurrentView(item);
    }
    ngOnDestroy() {
        this.signal$.next();
        this.signal$.complete();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: CustomizationDropdownComponent, deps: [{ token: GridCustomizationsService }, { token: CustomizeDropdownService }, { token: GridPublicService }, { token: FiltroJSONService }], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "19.2.9", type: CustomizationDropdownComponent, isStandalone: false, selector: "gias-customization-dropdown", inputs: { selected: "selected" }, outputs: { selectedChange: "selectedChange", applyView: "applyView", applyViewAndJSON: "applyViewAndJSON", sourceChange: "sourceChange" }, providers: [], ngImport: i0, template: "<!-- <span class=\"caption\">{{ 'giasgrid.ScegliUnaVistaCaption' | transloco}}</span> -->\n<kendo-dropdownlist [id]=\"dropdown?.id\" [data]=\"dropdown?.data\" [textField]=\"dropdown?.textField\"\n  [valueField]=\"dropdown?.valueField\" [valuePrimitive]=\"false\" (ngModelChange)=\"changeValue($event)\"\n  [ngModel]=\"selected\" [defaultItem]=\"dropdown?.defaultValue\" [ngModelOptions]=\"{standalone: true}\"\n  [filterable]=\"filterable\" (filterChange)=\"handleFilter($event)\">\n  <ng-template kendoDropDownListNoDataTemplate>\n    <div>\n      {{ 'giasgrid.No_Dati' | transloco }}\n      <!-- <ng-container *ngIf=\"filter\">\n      {{ 'giasgrid.Nuovo_Elemento' | transloco }} \"{{ filter }}\" ?\n    </ng-container> -->\n      <br />\n      <button *ngIf=\"filter\" class=\"k-button btn-sm\" (click)=\"addNew()\">\n        {{ 'giasgrid.Nuovo_Elemento' | transloco }}\n      </button>\n    </div>\n  </ng-template>\n</kendo-dropdownlist>", dependencies: [{ kind: "directive", type: i3.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: i6$1.NoDataTemplateDirective, selector: "[kendoDropDownListNoDataTemplate],[kendoDropDownTreeNoDataTemplate],[kendoComboBoxNoDataTemplate],[kendoMultiColumnComboBoxNoDataTemplate],[kendoAutoCompleteNoDataTemplate],[kendoMultiSelectNoDataTemplate],[kendoMultiSelectTreeNoDataTemplate]" }, { kind: "component", type: i6$1.DropDownListComponent, selector: "kendo-dropdownlist", inputs: ["customIconClass", "showStickyHeader", "icon", "svgIcon", "loading", "data", "value", "textField", "valueField", "adaptiveMode", "title", "subtitle", "popupSettings", "listHeight", "defaultItem", "disabled", "itemDisabled", "readonly", "filterable", "virtual", "ignoreCase", "delay", "valuePrimitive", "tabindex", "tabIndex", "size", "rounded", "fillMode", "leftRightArrowsNavigation", "id"], outputs: ["valueChange", "filterChange", "selectionChange", "open", "opened", "close", "closed", "focus", "blur"], exportAs: ["kendoDropDownList"] }, { kind: "directive", type: i2$2.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i2$2.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }, { kind: "pipe", type: i1$1.TranslocoPipe, name: "transloco" }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: CustomizationDropdownComponent, decorators: [{
            type: Component,
            args: [{ standalone: false, selector: 'gias-customization-dropdown', providers: [], template: "<!-- <span class=\"caption\">{{ 'giasgrid.ScegliUnaVistaCaption' | transloco}}</span> -->\n<kendo-dropdownlist [id]=\"dropdown?.id\" [data]=\"dropdown?.data\" [textField]=\"dropdown?.textField\"\n  [valueField]=\"dropdown?.valueField\" [valuePrimitive]=\"false\" (ngModelChange)=\"changeValue($event)\"\n  [ngModel]=\"selected\" [defaultItem]=\"dropdown?.defaultValue\" [ngModelOptions]=\"{standalone: true}\"\n  [filterable]=\"filterable\" (filterChange)=\"handleFilter($event)\">\n  <ng-template kendoDropDownListNoDataTemplate>\n    <div>\n      {{ 'giasgrid.No_Dati' | transloco }}\n      <!-- <ng-container *ngIf=\"filter\">\n      {{ 'giasgrid.Nuovo_Elemento' | transloco }} \"{{ filter }}\" ?\n    </ng-container> -->\n      <br />\n      <button *ngIf=\"filter\" class=\"k-button btn-sm\" (click)=\"addNew()\">\n        {{ 'giasgrid.Nuovo_Elemento' | transloco }}\n      </button>\n    </div>\n  </ng-template>\n</kendo-dropdownlist>" }]
        }], ctorParameters: () => [{ type: GridCustomizationsService }, { type: CustomizeDropdownService }, { type: GridPublicService }, { type: FiltroJSONService }], propDecorators: { selected: [{
                type: Input
            }], selectedChange: [{
                type: Output
            }], applyView: [{
                type: Output
            }], applyViewAndJSON: [{
                type: Output
            }], sourceChange: [{
                type: Output
            }] } });

/** TODO: Razvan. Quando questa componente è attiva, la pagina della griglia è
 * renderizzata due volte.
 **/
class GridCustomizationsComponent {
    service;
    dropdownService;
    canApplyChanges = false;
    options;
    showSwitch = false;
    set selectedDDLItem(value) {
        this._selectedDDLItem = value;
        //Tengo aggiornato anche il parametro nel servizio
        this.service.selectedDDLItem = value;
    }
    canApplyChangesChange = new EventEmitter();
    applyView = new EventEmitter();
    faAlign = faAlignJustify;
    faSave = faSave;
    faTrash = faTrash;
    switchValue = false;
    defualtIsOnServer;
    DropdownDefaultItem;
    $signal = new Subject();
    _selectedDDLItem;
    get selectedDDLItem() {
        return this._selectedDDLItem;
    }
    constructor(service, dropdownService) {
        this.service = service;
        this.dropdownService = dropdownService;
        this.DropdownDefaultItem = this.dropdownService.defaultItem;
    }
    ngOnInit() {
        this.service.permessoPubblica = this.showSwitch;
        this.loadSubscriptions();
    }
    ngOnChanges(changes) {
        if (changes.canApplyChanges.currentValue)
            this.forceApplyModifications();
        this.defualtIsOnServer = this.service.defaultViewStoredServerSide();
    }
    ngOnDestroy() {
        this.service.persistView(this.selectedDDLItem);
        this.$signal.next();
        this.$signal.complete();
    }
    showRemoveBtnOnNonDefaultSelected() {
        return this.selectedDDLItem && !(this.selectedDDLItem.data?.Predefinita);
    }
    showRemoveBtnOnDefaultSelected() {
        return this.selectedDDLItem && this.selectedDDLItem.data?.Predefinita && this.defualtIsOnServer;
    }
    isDefaultSaveDisabled() {
        return this.service.conf.views.isSaveDisabledOnDefaultView && this.selectedDDLItem?.data?.Predefinita;
    }
    forceApplyModifications() {
        const view = this.service.getView(this.selectedDDLItem, true);
        if (view) {
            //this.applyView.emit(view);
            view.IsModified = true;
        }
        this.canApplyChanges = false;
        this.canApplyChangesChange.emit(this.canApplyChanges);
    }
    applyOrCreateAndApplyView(ev) {
        const isPredefinedView = (selectedDdl) => selectedDdl.data?.Predefinita;
        this.selectedDDLItem = ev.item;
        if (!ev.isNew) {
            this.canApplyChanges = false;
        }
        if (isPredefinedView(this.selectedDDLItem) && !this.defaultViewStoredServerSide()) {
            // default view is selected and is not stored server side
            // so apply default 'programmer' settings
            this.applyView.emit(null); // load default view
            return;
        }
        const view = this.service.getView(ev.item, false);
        this.switchValue = view.FlagPubblica;
        this.service.switchValue = this.switchValue;
        if (this.service.checkIfThereIsAForm()) {
            this.service.setFormFields(view);
            return;
        }
        this.applyView.emit(view);
    }
    applyViewAndJSON(ev) {
        const view = this.service.getView(ev.item, false);
        //questa chiamata fa partire la ricarica della griglia
        this.service.setFormFields(view);
    }
    onSave(event) {
        //this.service.saveAllViews();
        this.service.switchValue = this.switchValue;
        this.service.saveCurrentView(this.selectedDDLItem);
    }
    onRemove(event) {
        this.service.deleteCustomization(this.selectedDDLItem);
    }
    defaultViewStoredServerSide() {
        return this.service.defaultViewStoredServerSide();
    }
    loadSubscriptions() {
        this.service.defaultStoredOnServer
            .pipe(takeUntil(this.$signal))
            .subscribe((storedOnServer) => {
            this.defualtIsOnServer = storedOnServer;
        });
        this.service.viewToApply
            .pipe(takeUntil(this.$signal))
            .subscribe((item) => {
            this.selectedDDLItem = item;
            if (!this.service.cacheViewWasApplied) {
                const ev = new SelectionChangeEvent({ item: item, isNew: false });
                this.applyOrCreateAndApplyView(ev);
            }
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: GridCustomizationsComponent, deps: [{ token: GridCustomizationsService }, { token: CustomizeDropdownService }], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "19.2.9", type: GridCustomizationsComponent, isStandalone: false, selector: "gias-grid-customizations", inputs: { canApplyChanges: "canApplyChanges", options: "options", showSwitch: "showSwitch", selectedDDLItem: "selectedDDLItem" }, outputs: { canApplyChangesChange: "canApplyChangesChange", applyView: "applyView" }, providers: [], usesOnChanges: true, ngImport: i0, template: "<!-- \n<label [for]=\"viewPicker\">{{ 'giasgrid.ScegliUnaVista' | transloco }} </label> -->\n\n<ng-content select=\"[start]\">\n  \n</ng-content>\n\n<ng-container *ngIf=\"showSwitch\">\n  <span class=\"switch-label k-label gias-switch-left-label\">{{ 'giasgrid.Privata' | transloco }}</span>\n    <kendo-switch [(ngModel)]=\"switchValue\"></kendo-switch>\n  <span class=\"switch-label k-label gias-switch-right-label\">{{ 'giasgrid.Pubblica' | transloco }}</span>\n</ng-container>\n\n<gias-customization-dropdown #viewPicker\n  (applyView)=\"applyOrCreateAndApplyView($event)\"\n  (applyViewAndJSON)=\"applyViewAndJSON($event)\"\n  [(selected)]=\"selectedDDLItem\">\n</gias-customization-dropdown>\n\n<!-- <fa-icon class=\"faDoubleArrowRight\"> </fa-icon> -->\n\n<!-- TODO: Aggiungere traduzione per InfoViste in cui viene spiegato \n  come aggiungere e gestire le viste -->\n<gias-info-template [title]=\"'giasgrid.InfoViste' | transloco\"></gias-info-template>\n\n<div kendoTooltip [title]=\"selectedDDLItem?.data == null ? '' : isDefaultSaveDisabled() ? ('giasgrid.SalvaPredefinita' | transloco) : ('giasgrid.SalvaPersonalizzazioni' | transloco)\">\n  <button \n    [disabled]=\"!selectedDDLItem || isDefaultSaveDisabled()\"\n    type=\"button\"\n    (click)=\"onSave($event)\"\n    class=\"btn btn-default btn-sm\"\n    size=\"small\">\n      <fa-icon\n        size=\"lg\"\n        [icon]=\"faSave\"\n        aria-hidden=\"true\">\n      </fa-icon>\n      <!-- {{ 'giasgrid.Salva' | transloco }} -->\n  </button>\n</div>\n\n<button \n  *ngIf=\"selectedDDLItem && !selectedDDLItem.data?.Predefinita; else defaultSelected\"\n  type=\"button\"\n  kendoTooltip\n  (click)=\"onRemove($event)\"\n  class=\"btn btn-default btn-sm\"\n  size=\"small\"\n  [title]=\"'giasgrid.CancellaPersonalizzazioni' | transloco\">\n    <fa-icon\n      size=\"lg\"\n      [icon]=\"faTrash\"\n      aria-hidden=\"true\">\n    </fa-icon>\n    <!-- {{ 'giasgrid.Cancella' | transloco }} -->\n</button>\n\n\n<ng-template #defaultSelected>\n  <button \n    kendoTooltip\n    [disabled]=\"!(selectedDDLItem && selectedDDLItem.data?.Predefinita && defualtIsOnServer)\"\n    type=\"button\"\n    (click)=\"onRemove($event)\"\n    class=\"btn btn-default btn-sm\"\n    size=\"small\"\n    [title]=\"'giasgrid.CancellaPersonalizzazioni' | transloco\">\n      <fa-icon\n        size=\"lg\"\n        [icon]=\"faTrash\"\n        aria-hidden=\"true\">\n      </fa-icon>\n      <!-- {{ 'giasgrid.Cancella' | transloco }} -->\n  </button>\n</ng-template>\n\n<ng-content select=\"[end]\">\n  \n</ng-content>\n\n\n<!-- <button *ngIf=\"canApplyChanges && selectedDDLItem.id != DropdownDefaultItem.id\"\n  type=\"button\"\n  (click)=\"forceApplyModifications($event)\"\n  class=\"btn btn-default\"\n  title=\"Applica\">\n    <fa-icon\n      size=\"lg\"\n      [icon]=\"faAlign\"\n      aria-hidden=\"true\">\n    </fa-icon>\n    {{ 'giasgrid.Applica_Modifiche' | transloco }}\n</button> -->\n", dependencies: [{ kind: "directive", type: i3.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "component", type: i14.SwitchComponent, selector: "kendo-switch", inputs: ["focusableId", "onLabel", "offLabel", "checked", "disabled", "readonly", "tabindex", "size", "thumbRounded", "trackRounded", "tabIndex"], outputs: ["focus", "blur", "valueChange"], exportAs: ["kendoSwitch"] }, { kind: "directive", type: i2$2.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i2$2.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }, { kind: "component", type: i7.FaIconComponent, selector: "fa-icon", inputs: ["icon", "title", "animation", "mask", "flip", "size", "pull", "border", "inverse", "symbol", "rotate", "fixedWidth", "transform", "a11yRole"] }, { kind: "directive", type: i7$1.TooltipDirective, selector: "[kendoTooltip]", inputs: ["filter", "position", "titleTemplate", "showOn", "showAfter", "callout", "closable", "offset", "tooltipWidth", "tooltipHeight", "tooltipClass", "tooltipContentClass", "collision", "closeTitle", "tooltipTemplate"], exportAs: ["kendoTooltip"] }, { kind: "component", type: i2$1.GiasInfoTemplateComponent, selector: "gias-info-template", inputs: ["title", "size", "tooltipTemplate"] }, { kind: "component", type: CustomizationDropdownComponent, selector: "gias-customization-dropdown", inputs: ["selected"], outputs: ["selectedChange", "applyView", "applyViewAndJSON", "sourceChange"] }, { kind: "pipe", type: i1$1.TranslocoPipe, name: "transloco" }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: GridCustomizationsComponent, decorators: [{
            type: Component,
            args: [{ standalone: false, selector: 'gias-grid-customizations', providers: [], template: "<!-- \n<label [for]=\"viewPicker\">{{ 'giasgrid.ScegliUnaVista' | transloco }} </label> -->\n\n<ng-content select=\"[start]\">\n  \n</ng-content>\n\n<ng-container *ngIf=\"showSwitch\">\n  <span class=\"switch-label k-label gias-switch-left-label\">{{ 'giasgrid.Privata' | transloco }}</span>\n    <kendo-switch [(ngModel)]=\"switchValue\"></kendo-switch>\n  <span class=\"switch-label k-label gias-switch-right-label\">{{ 'giasgrid.Pubblica' | transloco }}</span>\n</ng-container>\n\n<gias-customization-dropdown #viewPicker\n  (applyView)=\"applyOrCreateAndApplyView($event)\"\n  (applyViewAndJSON)=\"applyViewAndJSON($event)\"\n  [(selected)]=\"selectedDDLItem\">\n</gias-customization-dropdown>\n\n<!-- <fa-icon class=\"faDoubleArrowRight\"> </fa-icon> -->\n\n<!-- TODO: Aggiungere traduzione per InfoViste in cui viene spiegato \n  come aggiungere e gestire le viste -->\n<gias-info-template [title]=\"'giasgrid.InfoViste' | transloco\"></gias-info-template>\n\n<div kendoTooltip [title]=\"selectedDDLItem?.data == null ? '' : isDefaultSaveDisabled() ? ('giasgrid.SalvaPredefinita' | transloco) : ('giasgrid.SalvaPersonalizzazioni' | transloco)\">\n  <button \n    [disabled]=\"!selectedDDLItem || isDefaultSaveDisabled()\"\n    type=\"button\"\n    (click)=\"onSave($event)\"\n    class=\"btn btn-default btn-sm\"\n    size=\"small\">\n      <fa-icon\n        size=\"lg\"\n        [icon]=\"faSave\"\n        aria-hidden=\"true\">\n      </fa-icon>\n      <!-- {{ 'giasgrid.Salva' | transloco }} -->\n  </button>\n</div>\n\n<button \n  *ngIf=\"selectedDDLItem && !selectedDDLItem.data?.Predefinita; else defaultSelected\"\n  type=\"button\"\n  kendoTooltip\n  (click)=\"onRemove($event)\"\n  class=\"btn btn-default btn-sm\"\n  size=\"small\"\n  [title]=\"'giasgrid.CancellaPersonalizzazioni' | transloco\">\n    <fa-icon\n      size=\"lg\"\n      [icon]=\"faTrash\"\n      aria-hidden=\"true\">\n    </fa-icon>\n    <!-- {{ 'giasgrid.Cancella' | transloco }} -->\n</button>\n\n\n<ng-template #defaultSelected>\n  <button \n    kendoTooltip\n    [disabled]=\"!(selectedDDLItem && selectedDDLItem.data?.Predefinita && defualtIsOnServer)\"\n    type=\"button\"\n    (click)=\"onRemove($event)\"\n    class=\"btn btn-default btn-sm\"\n    size=\"small\"\n    [title]=\"'giasgrid.CancellaPersonalizzazioni' | transloco\">\n      <fa-icon\n        size=\"lg\"\n        [icon]=\"faTrash\"\n        aria-hidden=\"true\">\n      </fa-icon>\n      <!-- {{ 'giasgrid.Cancella' | transloco }} -->\n  </button>\n</ng-template>\n\n<ng-content select=\"[end]\">\n  \n</ng-content>\n\n\n<!-- <button *ngIf=\"canApplyChanges && selectedDDLItem.id != DropdownDefaultItem.id\"\n  type=\"button\"\n  (click)=\"forceApplyModifications($event)\"\n  class=\"btn btn-default\"\n  title=\"Applica\">\n    <fa-icon\n      size=\"lg\"\n      [icon]=\"faAlign\"\n      aria-hidden=\"true\">\n    </fa-icon>\n    {{ 'giasgrid.Applica_Modifiche' | transloco }}\n</button> -->\n" }]
        }], ctorParameters: () => [{ type: GridCustomizationsService }, { type: CustomizeDropdownService }], propDecorators: { canApplyChanges: [{
                type: Input
            }], options: [{
                type: Input
            }], showSwitch: [{
                type: Input
            }], selectedDDLItem: [{
                type: Input
            }], canApplyChangesChange: [{
                type: Output
            }], applyView: [{
                type: Output
            }] } });

class GridCustomComponent {
    resolver;
    changeDetector;
    entry;
    component;
    input;
    field;
    edit;
    formGroup;
    componentRef;
    constructor(resolver, changeDetector) {
        this.resolver = resolver;
        this.changeDetector = changeDetector;
    }
    ngOnChanges(changes) {
        this.handleComponent();
    }
    ngAfterViewInit() {
        this.handleComponent();
    }
    handleComponent() {
        if (this.component && this.entry) {
            if (this.componentRef) {
                this.componentRef.destroy();
            }
            this.componentRef = this.entry.createComponent(this.component);
            this.componentRef.instance.input = this.input;
            this.componentRef.instance.edit = this.edit;
            this.componentRef.instance.field = this.field;
            this.componentRef.instance.formGroup = this.formGroup;
            this.changeDetector.detectChanges();
        }
    }
    ngOnDestroy() {
        if (this.componentRef) {
            this.componentRef.destroy();
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: GridCustomComponent, deps: [{ token: i0.ComponentFactoryResolver }, { token: i0.ChangeDetectorRef }], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "19.2.9", type: GridCustomComponent, isStandalone: false, selector: "gias-grid-custom", inputs: { component: "component", input: "input", field: "field", edit: "edit", formGroup: "formGroup" }, viewQueries: [{ propertyName: "entry", first: true, predicate: ["component"], descendants: true, read: ViewContainerRef }], usesOnChanges: true, ngImport: i0, template: "<template #component>\n</template>\n", styles: [""] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: GridCustomComponent, decorators: [{
            type: Component,
            args: [{ standalone: false, selector: 'gias-grid-custom', template: "<template #component>\n</template>\n" }]
        }], ctorParameters: () => [{ type: i0.ComponentFactoryResolver }, { type: i0.ChangeDetectorRef }], propDecorators: { entry: [{
                type: ViewChild,
                args: ['component', { read: ViewContainerRef }]
            }], component: [{
                type: Input
            }], input: [{
                type: Input
            }], field: [{
                type: Input
            }], edit: [{
                type: Input
            }], formGroup: [{
                type: Input
            }] } });

/**
 * Questa componente è stata creata per la kendo grid.
 * Non dovrebbe essere usata fuori da questo modulo.
 * */
class GridBooleanComponent {
    formGroup;
    controlName;
    defaultValue;
    editable;
    useCheckbox;
    container;
    valueChange = new EventEmitter();
    constructor() { }
    ngOnInit() {
        if (!this.formGroup && !this.controlName) {
            this.formGroup = new FormGroup({
                value: new FormControl(this.defaultValue)
            });
            this.controlName = 'value';
        }
        if (this.editable)
            this.formGroup.get(this.controlName).enable();
        else
            this.formGroup.get(this.controlName).disable();
    }
    onChange(value) {
        this.valueChange.emit(value);
    }
    ngOnChanges(changes) {
        if (this.container) {
            let checkbox = this.container.nativeElement.querySelector('.k-checkbox');
            checkbox.checked = this.defaultValue;
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: GridBooleanComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "19.2.9", type: GridBooleanComponent, isStandalone: false, selector: "gias-grid-boolean", inputs: { formGroup: "formGroup", controlName: "controlName", defaultValue: "defaultValue", editable: "editable", useCheckbox: "useCheckbox" }, outputs: { valueChange: "valueChange" }, viewQueries: [{ propertyName: "container", first: true, predicate: ["checkContainer"], descendants: true }], usesOnChanges: true, ngImport: i0, template: "<form [formGroup]=\"formGroup\">\n  <div class=\"bool-container\" *ngIf=\"useCheckbox; else switch\" #checkContainer>\n    <gias-checkbox-template\n      [giasFormControlName]=\"controlName\"\n      [value]=\"defaultValue\"\n      [isDisabled]=\"!editable\"\n      (valueChange)=\"onChange($event)\"\n    ></gias-checkbox-template>\n  </div>\n  <ng-template #switch>\n    <gias-switch-template\n      [giasFormControlName]=\"controlName\"\n      [value]=\"defaultValue\"\n      [hideLabel]=\"true\"\n      [isDisabled]=\"!editable\"\n      (valueChange)=\"onChange($event)\"\n    ></gias-switch-template>\n  </ng-template>\n</form>\n", styles: [".bool-container{display:flex;flex-direction:column;align-items:center}\n"], dependencies: [{ kind: "directive", type: i3.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: i2$2.ɵNgNoValidate, selector: "form:not([ngNoForm]):not([ngNativeValidate])" }, { kind: "directive", type: i2$2.NgControlStatusGroup, selector: "[formGroupName],[formArrayName],[ngModelGroup],[formGroup],form:not([ngNoForm]),[ngForm]" }, { kind: "directive", type: i2$2.FormGroupDirective, selector: "[formGroup]", inputs: ["formGroup"], outputs: ["ngSubmit"], exportAs: ["ngForm"] }, { kind: "component", type: i2$1.GiasCheckboxTemplateComponent, selector: "gias-checkbox-template", inputs: ["name", "value", "isDisabled", "giasFormControlName"], outputs: ["valueChange"] }, { kind: "component", type: i2$1.GiasSwitchTemplateComponent, selector: "gias-switch-template", inputs: ["name", "value", "placeholder", "isDisabled", "giasFormControlName", "siLabel", "noLabel", "isBlue", "hideLabel", "hideformfield"], outputs: ["valueChange"] }], viewProviders: [{ provide: ControlContainer, useExisting: FormGroupDirective }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: GridBooleanComponent, decorators: [{
            type: Component,
            args: [{ standalone: false, selector: 'gias-grid-boolean', viewProviders: [{ provide: ControlContainer, useExisting: FormGroupDirective }], template: "<form [formGroup]=\"formGroup\">\n  <div class=\"bool-container\" *ngIf=\"useCheckbox; else switch\" #checkContainer>\n    <gias-checkbox-template\n      [giasFormControlName]=\"controlName\"\n      [value]=\"defaultValue\"\n      [isDisabled]=\"!editable\"\n      (valueChange)=\"onChange($event)\"\n    ></gias-checkbox-template>\n  </div>\n  <ng-template #switch>\n    <gias-switch-template\n      [giasFormControlName]=\"controlName\"\n      [value]=\"defaultValue\"\n      [hideLabel]=\"true\"\n      [isDisabled]=\"!editable\"\n      (valueChange)=\"onChange($event)\"\n    ></gias-switch-template>\n  </ng-template>\n</form>\n", styles: [".bool-container{display:flex;flex-direction:column;align-items:center}\n"] }]
        }], ctorParameters: () => [], propDecorators: { formGroup: [{
                type: Input
            }], controlName: [{
                type: Input
            }], defaultValue: [{
                type: Input
            }], editable: [{
                type: Input
            }], useCheckbox: [{
                type: Input
            }], container: [{
                type: ViewChild,
                args: ['checkContainer']
            }], valueChange: [{
                type: Output
            }] } });

class CellTypePipe {
    services;
    service;
    constructor(services) {
        this.services = services;
        if (Array.isArray(services)) {
            this.service = services[0];
        }
        else {
            this.service = services;
        }
    }
    transform(column) {
        const model = this.service.getModel();
        const exists = model[column.field] != null;
        if (!exists) {
            return;
        }
        switch (model[column.field].type) {
            case CELL_TYPES.STRING:
            case CELL_TYPES.DATE:
            case CELL_TYPES.DATETIME:
            case CELL_TYPES.NUMBER:
            case CELL_TYPES.DROPDOWNLIST:
            case CELL_TYPES.MULTI_DROPDOWNLIST:
            case CELL_TYPES.CUSTOM:
            case CELL_TYPES.BOOLEAN:
                return model[column.field].type;
            default:
                return true;
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: CellTypePipe, deps: [{ token: KendoGridService }], target: i0.ɵɵFactoryTarget.Pipe });
    static ɵpipe = i0.ɵɵngDeclarePipe({ minVersion: "14.0.0", version: "19.2.9", ngImport: i0, type: CellTypePipe, isStandalone: false, name: "cellType" });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: CellTypePipe, decorators: [{
            type: Pipe,
            args: [{
                    standalone: false,
                    name: 'cellType',
                    pure: true
                }]
        }], ctorParameters: () => [{ type: KendoGridService }] });

class CellDropdownNamePipe {
    logService;
    constructor(logService) {
        this.logService = logService;
    }
    transform(row, column) {
        let ddlItem = null;
        if (column.ddl?.valuePrimitive) {
            ddlItem = column.ddl.data.find(x => row[column.ddl.formControlName] == x['id'] && row[column.ddl.descriptionField] == x['name']);
        }
        else {
            let value;
            try {
                value = row[column.ddl.formControlName];
            }
            catch (e) {
                console.log(column.field);
            }
            value = row[column.ddl.formControlName];
            if (value?.id != null) {
                value = value.id;
            }
            ddlItem = column.ddl.data.find(x => value == x['id']);
        }
        if (ddlItem == null && column.ddl.loadOnEdit) {
            ddlItem = {
                name: row[column.ddl.descriptionField],
            };
            // if (column.ddl.data == null || column.ddl.data.length == 0) {
            //     const obj = new DropdownListItem(row[column.ddl.formControlName], row[column.ddl.descriptionField]);
            //     column.ddl.data = [obj];
            // } else {
            //     const obj = new DropdownListItem(row[column.ddl.formControlName], row[column.ddl.descriptionField]);
            //     column.ddl.data = [obj];
            // }
            const obj = new DropdownListItem(row[column.ddl.formControlName], row[column.ddl.descriptionField]);
            column.ddl.data = [obj];
        }
        return ddlItem?.name;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: CellDropdownNamePipe, deps: [{ token: GridErrorService }], target: i0.ɵɵFactoryTarget.Pipe });
    static ɵpipe = i0.ɵɵngDeclarePipe({ minVersion: "14.0.0", version: "19.2.9", ngImport: i0, type: CellDropdownNamePipe, isStandalone: false, name: "cellDropdownName" });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: CellDropdownNamePipe, decorators: [{
            type: Pipe,
            args: [{
                    standalone: false,
                    name: 'cellDropdownName',
                    pure: true
                }]
        }], ctorParameters: () => [{ type: GridErrorService }] });

class CellMultiDropdownNamePipe {
    logService;
    constructor(logService) {
        this.logService = logService;
    }
    transform(row, column) {
        let helper = new DropdownHelper();
        let cellOutput = helper.gridCellClosedOuput(column, row);
        if (cellOutput.columnDataNeedsUpdate) {
            column.ddl.data = cellOutput.items;
        }
        let itemNames = cellOutput.items.map(item => item.name);
        let commaSeparatedResult = itemNames.join(" | ");
        return commaSeparatedResult;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: CellMultiDropdownNamePipe, deps: [{ token: GridErrorService }], target: i0.ɵɵFactoryTarget.Pipe });
    static ɵpipe = i0.ɵɵngDeclarePipe({ minVersion: "14.0.0", version: "19.2.9", ngImport: i0, type: CellMultiDropdownNamePipe, isStandalone: false, name: "cellMultiDropdownName" });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: CellMultiDropdownNamePipe, decorators: [{
            type: Pipe,
            args: [{
                    standalone: false,
                    name: 'cellMultiDropdownName',
                    pure: true
                }]
        }], ctorParameters: () => [{ type: GridErrorService }] });

class GroupHeaderNamePipe {
    transform(group, column, field) {
        let elem = null;
        let nextGroup = group;
        do {
            nextGroup = nextGroup.items[0];
            if (!Array.isArray(nextGroup.items)) {
                elem = nextGroup;
                break;
            }
        } while (true);
        let result = elem[column.ddl.descriptionField];
        return result;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: GroupHeaderNamePipe, deps: [], target: i0.ɵɵFactoryTarget.Pipe });
    static ɵpipe = i0.ɵɵngDeclarePipe({ minVersion: "14.0.0", version: "19.2.9", ngImport: i0, type: GroupHeaderNamePipe, isStandalone: false, name: "groupHeaderName" });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: GroupHeaderNamePipe, decorators: [{
            type: Pipe,
            args: [{
                    standalone: false,
                    name: 'groupHeaderName',
                    pure: true
                }]
        }] });

class AggregateTypePipe {
    conf;
    constructor(conf) {
        this.conf = conf;
    }
    transform(col) {
        const descriptors = this.conf.aggregates.descriptors;
        const index = descriptors.findIndex(s => s.field === col.field);
        if (index >= 0) {
            return { show: true, descriptor: descriptors[index] };
        }
        return { show: false };
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: AggregateTypePipe, deps: [{ token: GRID_HTTP_TOKEN }], target: i0.ɵɵFactoryTarget.Pipe });
    static ɵpipe = i0.ɵɵngDeclarePipe({ minVersion: "14.0.0", version: "19.2.9", ngImport: i0, type: AggregateTypePipe, isStandalone: false, name: "aggrType" });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: AggregateTypePipe, decorators: [{
            type: Pipe,
            args: [{
                    standalone: false,
                    name: 'aggrType',
                    pure: true,
                }]
        }], ctorParameters: () => [{ type: AbstractGridConfigService, decorators: [{
                    type: Inject,
                    args: [GRID_HTTP_TOKEN]
                }] }] });

class StringToDatePipe {
    conf;
    conversionService;
    constructor(conf, conversionService) {
        this.conf = conf;
        this.conversionService = conversionService;
    }
    transform(strVal, col) {
        let retVal;
        if (strVal == null) {
            retVal = col?.date?.defaultValue;
        }
        retVal = strVal;
        if (typeof strVal == 'string') {
            retVal = this.conversionService.convertStringToDate(strVal);
        }
        return retVal;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: StringToDatePipe, deps: [{ token: GRID_HTTP_TOKEN }, { token: i2$1.ConversionService }], target: i0.ɵɵFactoryTarget.Pipe });
    static ɵpipe = i0.ɵɵngDeclarePipe({ minVersion: "14.0.0", version: "19.2.9", ngImport: i0, type: StringToDatePipe, isStandalone: false, name: "stringToDate" });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: StringToDatePipe, decorators: [{
            type: Pipe,
            args: [{
                    standalone: false,
                    name: 'stringToDate',
                    pure: true
                }]
        }], ctorParameters: () => [{ type: AbstractGridConfigService, decorators: [{
                    type: Inject,
                    args: [GRID_HTTP_TOKEN]
                }] }, { type: i2$1.ConversionService }] });

class FormatNumberPipe {
    conf;
    intl;
    constructor(conf, intl) {
        this.conf = conf;
        this.intl = intl;
    }
    transform(val, col, aggrFormat) {
        if (val != undefined && val != null && val != "") {
            let val_str = val.toString();
            if (aggrFormat != undefined && aggrFormat != "") {
                val_str = this.intl.formatNumber(val, aggrFormat);
            }
            else if (col?.format != undefined && col?.format != "") {
                let format_str = this.pulisciFormato(col?.format);
                val_str = this.intl.formatNumber(val, format_str);
            }
            else if (col?.numeric?.format != undefined && col?.numeric?.format != "") {
                let format_str = this.pulisciFormato(col?.numeric?.format);
                val_str = this.intl.formatNumber(val, format_str);
            }
            return val_str;
        }
        else {
            return val;
        }
    }
    pulisciFormato(format) {
        let format_str = format.replace("{", "");
        format_str = format_str.replace("}", "");
        format_str = format_str.replace("0:", "");
        return format_str;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: FormatNumberPipe, deps: [{ token: GRID_HTTP_TOKEN }, { token: i4.IntlService }], target: i0.ɵɵFactoryTarget.Pipe });
    static ɵpipe = i0.ɵɵngDeclarePipe({ minVersion: "14.0.0", version: "19.2.9", ngImport: i0, type: FormatNumberPipe, isStandalone: false, name: "formatNumber" });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: FormatNumberPipe, decorators: [{
            type: Pipe,
            args: [{
                    standalone: false,
                    name: 'formatNumber',
                    pure: true
                }]
        }], ctorParameters: () => [{ type: AbstractGridConfigService, decorators: [{
                    type: Inject,
                    args: [GRID_HTTP_TOKEN]
                }] }, { type: i4.IntlService }] });

class FilterTypePipe {
    service;
    constructor(services) {
        if (Array.isArray(services)) {
            this.service = services[0];
        }
        else {
            this.service = services;
        }
    }
    transform(column) {
        const model = this.service.getModel();
        const exists = model[column.field] != null;
        if (!exists) {
            return;
        }
        switch (model[column.field].type) {
            case CELL_TYPES.NUMBER:
                return 'numeric';
            case CELL_TYPES.DROPDOWNLIST:
                return CELL_TYPES.DROPDOWNLIST;
            case CELL_TYPES.STRING:
            case CELL_TYPES.DATE:
            case CELL_TYPES.DATETIME:
            case CELL_TYPES.BOOLEAN:
                return model[column.field].type;
            default:
                return true;
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: FilterTypePipe, deps: [{ token: KendoGridService }], target: i0.ɵɵFactoryTarget.Pipe });
    static ɵpipe = i0.ɵɵngDeclarePipe({ minVersion: "14.0.0", version: "19.2.9", ngImport: i0, type: FilterTypePipe, isStandalone: false, name: "filterType" });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: FilterTypePipe, decorators: [{
            type: Pipe,
            args: [{
                    standalone: false,
                    name: 'filterType',
                    pure: true
                }]
        }], ctorParameters: () => [{ type: KendoGridService }] });

/**
 * Various section:
 * - [Section] Grid state
 */
const visibleCols = (cols) => cols?.filter(col => col.isVisible);
class GiasKendoGridComponent {
    customizationService;
    gridServices;
    logService;
    intlService;
    changeDetector;
    ngZone;
    worker;
    translocoService;
    renderer;
    gridBatchHandlerService;
    kendoGridMasterService;
    /**
     * TODO_RV
     * Adjust column width based on contents (visible buttons): dettagliColumn and commandiColumn.
     * Features to add.
     * 1. Allow user to select between the loading animation of the grid and global loading animation mode.
     * 2. Nel metodo initView, dovrei togliergli la verifica if(!kData). Si spreca un evento al
     * caricamento della pagina prima che i dati siano caricati. Esempio sulla pagina dei campi (durante la
     * chiamata al server).
     * 3. Da inserire una funzione configurabile per la ricerca dentro una dropdown list.
     */
    unsubSignal = new Subject();
    noRecordsTemplateRef;
    gridContext = this;
    IN_CELL = EditingMode.IN_CELL;
    IN_LINE = EditingMode.IN_LINE;
    IN_LINE_BATCH = EditingMode.IN_LINE_BATCH;
    IN_CELL_BATCH = EditingMode.IN_CELL_BATCH;
    /**
     *  Constants
     * */
    STRING = CELL_TYPES.STRING;
    DATE = CELL_TYPES.DATE;
    DATETIME = CELL_TYPES.DATETIME;
    DROPDOWNLIST = CELL_TYPES.DROPDOWNLIST;
    MULTI_DROPDOWNLIST = CELL_TYPES.MULTI_DROPDOWNLIST;
    NUMERIC = CELL_TYPES.NUMBER;
    BOOLEAN = CELL_TYPES.BOOLEAN;
    CUSTOM = CELL_TYPES.CUSTOM;
    /**
     * Font awesome.
     */
    faInfo = faInfo;
    faEdit = faEdit;
    faDelete = faTrashAlt;
    faCancel = faTimes;
    faNew = faPlusSquare;
    faCopy = faCopy;
    faSave = faSave; // icona usata per il salvataggio delle viste
    faCircleSave = faCheckCircle;
    faArrow = faCaretDown;
    faDots = faEllipsis;
    /**
     * Required parameters
     */
    editingMode;
    loader;
    key;
    /**
     * General settings.
     * See the sortChange function.
     */
    generalSettings;
    /**
     * Pagination and sorting.
     */
    sort;
    pagination;
    masterdetailSettings = new MasterDetailSettings(false);
    /**
     * In cell editing.
     * */
    view;
    formGroup = new FormGroup({});
    /**
     * In line editing
     */
    editedRowIndex;
    isInEditMode;
    inLineModificaIsDisabled = false;
    /**
     * Grid (optional) parameters
     * */
    selectable = new AgrSelectableSettings();
    toolbar = new ToolbarSettings();
    cmdColumn = new CommandsColumnSettings();
    cmdDropDown = new CommandsDropDownSettings();
    dettagliColumn = null;
    customColumn = null;
    columnMenu = new ColumnMenuSettings();
    groups;
    columnGroups;
    /**
     * Setting behavior and not UI related functionality.
     */
    behavior;
    privateService;
    publicService;
    AGRODATA_INIZIO = AGRODATAINIZIO;
    AGRODATA_FINE = AGRODATAFINE;
    insideWindow = window;
    SMARTPHONE_WIDTH = SMARTPHONE_WIDTH;
    config;
    gridDialogService;
    /** Use cases */
    Scrollable = ScrollingMode.Scrollable;
    currentScrollingMode;
    customCommandColumnCellTemplate = null;
    customCommandColumnHeaderTemplate = null;
    showSwitchViewsPrivatePublic = false;
    rowsLoaded = new EventEmitter();
    constructor(customizationService, gridServices, /* Could be of type array or object */ logService, intlService, changeDetector, ngZone, worker, translocoService, renderer, gridBatchHandlerService, kendoDialogService, kendoGridMasterService) {
        this.customizationService = customizationService;
        this.gridServices = gridServices;
        this.logService = logService;
        this.intlService = intlService;
        this.changeDetector = changeDetector;
        this.ngZone = ngZone;
        this.worker = worker;
        this.translocoService = translocoService;
        this.renderer = renderer;
        this.gridBatchHandlerService = gridBatchHandlerService;
        this.kendoGridMasterService = kendoGridMasterService;
        this.groups = new GroupSettings({}, this.translocoService);
        this.total = new Map();
        if (!Array.isArray(this.gridServices)) {
            this.privateService = this.gridServices;
            this.publicService = this.privateService.pubService;
            this.config = this.privateService.conf;
        }
        this.gridDialogService = new GridDialogService(this.publicService, kendoDialogService, this.config, translocoService);
    }
    getColumnsGroupValue() {
        let arr = [];
        this.columnGroups?.forEach((val) => {
            val.forEach((val1) => {
                if (!val1.hidden) {
                    arr.push({
                        field: val1.title,
                        orderIndex: val1.orderIndex
                    });
                }
            });
        });
        return JSON.stringify(arr);
    }
    getComandValue() {
        let arr = [];
        this.columnGroups?.forEach((val) => {
            val.forEach((val1) => {
                if (val1.title == 'Comandi') {
                    arr.push(val1);
                }
            });
        });
        return JSON.stringify(arr);
    }
    get gridState() {
        return this.pagination.gridState;
    }
    get pageSize() {
        return this.pagination.gridState.take;
    }
    rowClassCallback(e) {
        let rowClasses = {};
        if (typeof this.config.onRowClass === 'function')
            rowClasses = this.config.onRowClass(e);
        return {
            ...rowClasses,
            'pending-deletion-row': e.dataItem['pending-deletion-row'] ?? false
        };
    }
    ShowHTMLAsString(cellType, col) {
        let show = false;
        let complete_column = null;
        if (col instanceof ColumnComponent) {
            complete_column = this.columns?.find(c => c.field === col.field);
        }
        else {
            complete_column = col;
        }
        if (cellType === CELL_TYPES.STRING && complete_column.editable === false && complete_column.showHTMLAsString === true) {
            show = true;
        }
        return show;
    }
    /**
     * Utilizzato per determinare il corrispondente token quando multi: true.
     */
    gridId;
    ngOnDestroy() {
        this.unsubSignal.next();
        this.unsubSignal.complete();
        this.privateService.signal?.next();
        this.worker.workerInst?.terminate();
        if (Array.isArray(this.gridServices)) {
            this.privateService.clearKendoGridService();
            this.publicService.clearGridPublicService();
        }
        if (this.pagination?.gridState?.skip !== undefined && this.pagination?.gridState?.skip !== null)
            this._storeCurrentGridPage();
    }
    ngOnInit() {
        this.publicService.gridElRef = this.gridElRef;
        if (Array.isArray(this.gridServices)) {
            for (let i = 0; i < this.gridServices.length; i++) {
                if (this.gridServices[i].freeMultiIndex) {
                    this.gridServices[i].initProviders(this);
                    this.publicService = this.privateService.pubService;
                    this.config = this.privateService.conf;
                    break;
                }
            }
        }
        this.rowId = this.config.rowId;
        this.privateService.ngOnInit(this);
        this._restorePreviousGridPage();
        this.initParams();
        this.createUsecaseServices();
        if (this.loader === LoaderType.RESOLVER) {
            this.initializeUsingResolver();
        }
        else if (this.loader === LoaderType.HTML) {
            this.initializeUsingHTML();
        }
        else if (this.loader === LoaderType.SERVICE) {
            this.defaultInitializationMethod();
        }
        this.registerSubscriptions();
        this.manageWindowResizeEvents();
    }
    resizeObservable;
    manageWindowResizeEvents() {
        const onWindowResize = () => {
            this.resizeObservable = fromEvent(window, 'resize');
            return this.resizeObservable.pipe(takeUntil(this.unsubSignal));
        };
        onWindowResize().subscribe(event => {
            this.resizeFnWidth(event.target.innerWidth);
            this.adjustGridHeightBasedOnContent();
        });
        this.resizeFnWidth(window.innerWidth);
    }
    resizeFnWidth(innerWidth) {
        const width = "width";
        const isMobileWidth = (value) => value < SMARTPHONE_WIDTH;
        const setProperty = (obj, prop, value) => !_isNull(obj) && (obj[prop] = value);
        const triggerSticky = (_switch) => {
            const sticky = "sticky";
            setProperty(this.dettagliColumn, sticky, _switch);
            setProperty(this.customColumn, sticky, _switch);
            setProperty(this.cmdColumn, sticky, _switch);
            setProperty(this.cmdDropDown, sticky, _switch);
            setProperty(this.selectable, sticky, _switch);
        };
        let infoBtnAbilitato = this.cmdColumn.infoBtn;
        let _isMobileWidth = isMobileWidth(innerWidth);
        let widthNum = this.dettagliColumn.computeWidth(_isMobileWidth, infoBtnAbilitato);
        if (_isMobileWidth) {
            triggerSticky(false);
            setProperty(this.dettagliColumn, width, widthNum);
        }
        else {
            triggerSticky(true);
            setProperty(this.dettagliColumn, width, widthNum);
        }
        let widthNumCustomClm = this.customColumn.computeWidth(_isMobileWidth, infoBtnAbilitato);
        if (_isMobileWidth) {
            triggerSticky(false);
            setProperty(this.customColumn, width, widthNumCustomClm);
        }
        else {
            triggerSticky(true);
            setProperty(this.customColumn, width, widthNumCustomClm);
        }
        this.changeDetector.detectChanges();
    }
    /**
     * [Section] Grid state.
     * [Item] Store current grid page in cache, to be restored when creating the
     * grid.
     */
    _storeCurrentGridPage() {
        const skip = this.pagination.gridState.skip;
        this.privateService.storeCurrentGridPage(skip);
    }
    _restorePreviousGridPage() {
        const state = this.privateService.conf.pagination.gridState;
        this.pagination.gridState = this.privateService.clone(state);
        const prevNavigationIndex = +this.privateService.checkCacheForPreviousPage();
        if (prevNavigationIndex != null)
            this.pagination.gridState.skip = Shared.changeGridPage(prevNavigationIndex, this.pageSize);
    }
    /**
     * [Item] adjust grid height based on content.
     */
    adjustGridHeightBasedOnContent() {
        const computeTableHeight = () => {
            let gridElemRef = this.gridElRef.nativeElement;
            let configHeight = this.config.generalSettings.height;
            if (this._scrollbarIsVisibleOn(gridElemRef, configHeight)) {
                let pixels = null;
                if (typeof configHeight === 'number')
                    pixels = configHeight + 'px';
                this.generalSettings.height = pixels;
            }
            else if (configHeight === 'auto')
                this.generalSettings.height = 'auto';
            else
                this._adaptHeightOnContainer();
            this.changeDetector.detectChanges();
        };
        this.ngZone.onStable
            .asObservable()
            .pipe(take$1(1))
            .subscribe(computeTableHeight);
    }
    /** Adatta l'altezza della griglia a quella del primo div padre con altezza fissa. */
    _adaptHeightOnContainer() {
        let gridElemRef = this.gridElRef.nativeElement;
        this.generalSettings.height = 'auto';
        let parent = this._findFirstParentWithFixedHeight(gridElemRef);
        let parentHeight = parent?.clientHeight ?? 0;
        let margin = 40;
        // Se la griglia risulta più alta del div padre, adatto l'altezza specificando i pixel necessari
        if (gridElemRef.clientHeight > parentHeight) {
            this.generalSettings.height = (parentHeight - margin) + 'px';
        }
    }
    _allRowsFit(nativeElement) {
        const tolerance = 20; // Usual height of a row is 40px
        const innerGridHeight = nativeElement.querySelector('.k-grid-content').clientHeight;
        const rows = nativeElement.querySelector('.k-grid-content').querySelectorAll('tr');
        let rowsHeight = 0;
        for (let row of rows) {
            rowsHeight += row.clientHeight;
            if (rowsHeight > (innerGridHeight + tolerance))
                return false;
        }
        return true;
    }
    _findFirstParentWithFixedHeight(nativeElement) {
        let parent = nativeElement?.parentElement?.parentElement;
        while (parent?.clientHeight == 0) {
            parent = parent.parentElement;
        }
        return parent;
    }
    _hasRowsScrollBar(nativeElement) {
        let clientHeight = nativeElement.getElementsByClassName('k-grid-content')[0].clientHeight;
        let scrollHeight = nativeElement.getElementsByClassName('k-grid-content')[0].scrollHeight;
        return clientHeight < scrollHeight;
    }
    _scrollbarIsVisibleOn(nativeElem, configHeight) {
        let inner = nativeElem.querySelector('kendo-grid-list .k-grid-content');
        if (configHeight === 'auto' || configHeight === "100%")
            return false;
        let height;
        if (typeof configHeight === 'string')
            height = parseInt(configHeight, 10);
        else
            height = configHeight;
        return inner.scrollHeight > height;
    }
    /** END [Section] Grid state */
    registerSubscriptions() {
        if (this.views.enabled) {
            this.customizationService.customizationRequest.pipe(takeUntil(this.unsubSignal)).subscribe((req) => {
                this.customizationService.mapGridSettingsAndSaveThem(this, req.dropdownItem, req.isNewView);
            });
        }
    }
    /**
     * Used for resizing the grid.
     */
    resizable;
    grid;
    checkboxColumn;
    commandColumn;
    gridElRef;
    input;
    /**
     * In-cell and in-line modification settings
     * */
    cellClick = new EventEmitter();
    resetGroupColumns() {
        if (this.columnGroups != null && !this.haveColumnsChanged()) {
            return;
        }
        const groups = new Map();
        for (const col of this.columns) {
            if (!groups.has(col.customParent)) {
                groups.set(col.customParent, []);
            }
            groups.get(col.customParent).push(col);
        }
        this.columnGroups = groups;
    }
    haveColumnsChanged() {
        const oldColumns = [...this.columnGroups.values()].flatMap(x => x);
        if (oldColumns.length != this.columns.length) {
            return true;
        }
        for (let i = 0; i < this.columns.length; i++) {
            const newColumn = this.columns[i];
            const oldColumn = oldColumns[i];
            if (oldColumn.field != newColumn.field || oldColumn.title != newColumn.title || oldColumn.width != newColumn.width ||
                oldColumn.orderIndex != newColumn.orderIndex || oldColumn.hidden != newColumn.hidden) {
                return true;
            }
        }
        return false;
    }
    cellClickHandler(event) {
        let item = event.dataItem;
        if (elementQueuedForDeletion(item) || this.privateService.preventEdit(event))
            return;
        this.isInEditMode = true;
        const isInCell = this.privateService.getEditingMode() === EditingMode.IN_CELL || this.privateService.getEditingMode() === EditingMode.IN_CELL_BATCH;
        if (isInCell && !this.inLineModificaIsDisabled && !event.isEdited) {
            if (this.behavior.createFormGroupFromOutside) {
                this.formGroup = this.privateService.onCreateExternalFormGroup(event);
            }
            else {
                this.createFormGroup(event.dataItem);
            }
            event.sender.editCell(event.rowIndex, event.columnIndex, this.formGroup);
            this.changeDetector.detectChanges();
        }
        this.privateService.onCellClick(event);
        this.cellClick.emit(event);
        this.isInEditMode = false;
    }
    cellCloseHandler(event) {
        const { formGroup, dataItem } = event;
        const isFormValid = this.editingMode == EditingMode.IN_CELL
            ? formGroup.controls[event.column.field].valid : formGroup.valid;
        if (!isFormValid) {
            event.preventDefault();
        }
        else if (formGroup.dirty) {
            this.privateService.assignValues(dataItem, formGroup.value);
            this.privateService.inCellUpdate(dataItem);
            // this.publicService.changeDetected.next(event);
        }
        this.privateService.onCellClose(event, this.input);
        this.applyRendererGiven(event);
        if (this.editingMode == EditingMode.IN_CELL_BATCH) {
            const item = this.rows.find(x => x[this.rowId] == dataItem[this.rowId]);
            const index = this.rows.indexOf(item);
            this.rows[index] = dataItem;
            this.gridBatchHandlerService.update(dataItem, this.rowId);
        }
    }
    disableButtonsDuringEditMode(disabled) {
        this.inLineModificaIsDisabled = disabled;
        let btnsToDisable = this.gridElRef.nativeElement.querySelectorAll('.btnDisabledInModifica');
        for (let i = 0; i < btnsToDisable.length; ++i) {
            this.renderer.setProperty(btnsToDisable[i], 'disabled', disabled);
        }
    }
    addHandler(event) {
        this.isInEditMode = true;
        this.publicService.currentDataItem = event.dataItem;
        this.closeEditor(event.sender);
        switch (this.editingMode) {
            case EditingMode.IN_LINE:
            case EditingMode.IN_CELL:
            case EditingMode.IN_LINE_BATCH:
            case EditingMode.IN_CELL_BATCH:
                if (this.behavior.createFormGroupFromOutside) {
                    this.formGroup = this.privateService.onCreateExternalFormGroup(event);
                }
                else {
                    this.createFormGroup(event.dataItem);
                }
                event.sender.addRow(this.formGroup);
                break;
            case EditingMode.IN_PAGE:
                // Nothing to do...
                break;
            default:
                this.logService.generalErrors(GenericErrors.EditingModeNotFound, this.editingMode);
        }
        this.handleDdlValue(event);
        this.publicService.changeDetected.next(event);
        this.isInEditMode = false;
        // if (this.resizable.autoFitColumns) {
        //     this.grid.autoFitColumns();
        // }
        this.disableButtonsDuringEditMode(true);
    }
    cancelHandler(event) {
        this.closeEditor(event.sender, event.rowIndex);
        const editingMode = this.privateService.getEditingMode();
        switch (editingMode) {
            case EditingMode.IN_LINE:
                this.closeEditor(event.sender);
                break;
            case EditingMode.IN_CELL:
                event.sender.closeRow(event.rowIndex);
                break;
            case EditingMode.IN_PAGE:
                // Nothing to do...
                break;
            case EditingMode.IN_LINE_BATCH:
            case EditingMode.IN_CELL_BATCH:
                this.closeEditor(event.sender);
                event.sender.closeRow(event.rowIndex);
                break;
            default:
                this.logService.generalErrors(GenericErrors.EditingModeNotFound, editingMode);
                break;
        }
        this.publicService.changeDetected.next(event);
        this.publicService.currentDataItem = null;
        this.applyRendererGiven(event);
        this.disableButtonsDuringEditMode(false);
    }
    saveHandler(event) {
        event.formGroup.markAllAsTouched();
        if (!event.formGroup.valid) {
            event['action'] = 'save-failed';
            this.publicService.changeDetected.next(event);
            return;
        }
        let obs;
        let editingMode;
        if (event.formGroup.valid) {
            editingMode = this.privateService.getEditingMode();
            const row = event.formGroup.getRawValue();
            switch (editingMode) {
                case EditingMode.IN_LINE:
                    obs = this.privateService.save(row, event.dataItem.chiave, event.isNew, event.rowIndex);
                    break;
                case EditingMode.IN_CELL:
                    this.privateService.incellCreate(row);
                    break;
                case EditingMode.IN_PAGE:
                    // Nothing to do...
                    break;
                case EditingMode.IN_LINE_BATCH:
                case EditingMode.IN_CELL_BATCH:
                    if (event.isNew) {
                        this.gridBatchHandlerService.add(row);
                        this.rows.push(row);
                    }
                    else {
                        const item = this.rows.find(x => x[this.rowId] == row[this.rowId]);
                        const index = this.rows.indexOf(item);
                        this.rows[index] = row;
                        this.gridBatchHandlerService.update(row, this.rowId);
                    }
                    this.publicService.refresh(false);
                    break;
                default:
                    this.logService.generalErrors(GenericErrors.EditingModeNotFound, editingMode);
            }
        }
        // TODO(RV) nel caso in cui il salvataggio non è andato a buon fine,
        // non chiudere la riga selezionata (e non rifa la lettura)
        if (obs != null) {
            obs.pipe(catchError((err) => {
                switch (editingMode) {
                    case EditingMode.IN_LINE:
                        this.privateService.idealRead(true, true);
                        break;
                    case EditingMode.IN_CELL:
                        this.privateService.idealRead(false, true);
                        break;
                    case EditingMode.IN_PAGE:
                    case EditingMode.IN_LINE_BATCH:
                    case EditingMode.IN_CELL_BATCH:
                        this.privateService.idealRead(false, true);
                        break;
                    default:
                        this.privateService.idealRead(false, true);
                        break;
                }
                return of(err);
            })).subscribe((val) => {
                if (val !== false) {
                    event.sender.closeRow(event.rowIndex);
                    this.publicService.changeDetected.next(event);
                    this.publicService.currentDataItem = null;
                    this.disableButtonsDuringEditMode(false);
                    switch (editingMode) {
                        case EditingMode.IN_LINE:
                            this.privateService.idealRead(true, true, [], true);
                            break;
                        case EditingMode.IN_CELL:
                            this.privateService.idealRead(false, true, [], true);
                            break;
                        case EditingMode.IN_PAGE:
                        case EditingMode.IN_LINE_BATCH:
                        case EditingMode.IN_CELL_BATCH:
                            this.privateService.idealRead(false, true);
                            break;
                        default:
                            this.privateService.idealRead(false, true);
                            break;
                    }
                }
            });
        }
        else {
            event.sender.closeRow(event.rowIndex);
            this.publicService.changeDetected.next(event);
            this.publicService.currentDataItem = null;
            this.disableButtonsDuringEditMode(false);
        }
    }
    async removeHandler(event) {
        const selected = this.privateService.getAllSelectedRows(event.dataItem);
        await this.gridDialogService.showDialog(() => {
            if (this.editingMode === EditingMode.IN_LINE_BATCH || this.editingMode === EditingMode.IN_CELL_BATCH) {
                this.batchRemove(event.dataItem);
            }
            else if (this.behavior.deletionMode === DeletionMode.HandleSingleRowDeletionOnly) {
                this.privateService.remove(event.dataItem);
            }
            else {
                selected.forEach(r => r['Selected'] = true);
                this.privateService.remove(selected);
            }
        }, event.dataItem);
        const editingMode = this.privateService.getEditingMode();
        switch (editingMode) {
            case EditingMode.IN_LINE:
                // Nothing to do...
                break;
            case EditingMode.IN_CELL:
                event.sender.cancelCell();
                break;
            case EditingMode.IN_PAGE:
                // Nothing to do...
                break;
            case EditingMode.IN_LINE_BATCH:
                break;
            case EditingMode.IN_CELL_BATCH:
                event.sender.cancelCell();
                break;
            default:
                this.logService.generalErrors(GenericErrors.EditingModeNotFound, editingMode);
        }
        this.publicService.changeDetected.next(event);
    }
    batchRemove(row) {
        if (this.behavior.deletionMode === DeletionMode.HandleSingleRowDeletionOnly) {
            this.gridBatchHandlerService.remove(row, this.rowId);
            return;
        }
        const rows = this.privateService.getAllSelectedRows(row);
        rows.forEach(row => { this.privateService.highlightRowDeletion(row); });
        this.gridBatchHandlerService.remove(rows, this.rowId);
        this.privateService.updatePubService();
    }
    saveChanges(grid) {
        grid.closeCell();
        grid.cancelCell();
        this.privateService.incellSaveChanges(this.config.generalSettings);
    }
    batchSave() {
        const data = this.gridBatchHandlerService.getData();
        this.privateService.batchSave(data).pipe(tap$1((val) => {
            this.resetHandler();
            this.privateService.idealRead(true, true);
        })).subscribe();
    }
    cancelChanges(grid) {
        grid.cancelCell();
        this.privateService.cancelChanges();
    }
    /**
     * In line edit handler
     */
    editHandler(event) {
        this.isInEditMode = true;
        this.publicService.currentDataItem = event.dataItem;
        // TODO IN_CELL_BATCH
        if (this.editingMode === EditingMode.IN_LINE || this.editingMode === EditingMode.IN_LINE_BATCH) {
            this.closeEditor(event.sender);
            if (this.behavior.createFormGroupFromOutside) {
                this.formGroup = this.privateService.onCreateExternalFormGroup(event);
            }
            else {
                this.createFormGroup(event.dataItem);
                this.editedRowIndex = event.rowIndex;
            }
            event.sender.editRow(event.rowIndex, this.formGroup);
        }
        this.handleDdlValue(event);
        this.isInEditMode = false;
        // if (this.resizable.autoFitColumns) {
        //     this.grid.autoFitColumns();
        // }
        this.disableButtonsDuringEditMode(true);
        this.publicService.changeDetected.next(event);
    }
    handleDdlValue(event) {
        let helper = new GridHelper();
        this.columns.forEach((col) => {
            if (event.dataItem && col.ddl && col.ddl.descriptionField && col.ddl.loadOnEdit) {
                if (helper.columnContainsSimpleDropdownList(this.model, col.field)) {
                    const id = event.dataItem[col.field];
                    const name = event.dataItem[col.ddl.descriptionField];
                    const ddlItem = col.ddl.data.find((el) => (el.id == id && el.name == name));
                    if (ddlItem == undefined) {
                        col.ddl.data = [{ id: id, name: name }];
                    }
                }
                else if (helper.columnContainsMultiDropdownList(this.model, col.field)) {
                    const { missingItemInSource, newDDLData } = helper.getMultiDDLDataIfMissing(event.dataItem, col);
                    if (missingItemInSource)
                        col.ddl.data = [...newDDLData];
                }
            }
        });
    }
    resetHandler() {
        this.privateService.reset();
        // Call it here to avoid injection problems
        if (this.editingMode === EditingMode.IN_LINE_BATCH || this.editingMode === EditingMode.IN_CELL_BATCH) {
            this.gridBatchHandlerService.reset();
        }
    }
    resetFilter() {
        if (this.gridState.filter) {
            let filters = this.gridState.filter;
            let finalFilters = {
                filters: [],
                logic: filters.logic
            };
            //this.gridServices.pubService.filters.next(finalFilters);
            this.gridState.filter = finalFilters;
            this.grid.filter = finalFilters;
            // this.grid.data = process((<any[]>this.grid.data), this.gridState);
            this.gridServices.pubService.refresh(false);
        }
    }
    onStateChange(state) {
        const deselectPrev = false;
        this.pagination.gridState = state;
        //this.autofitColumnComponents();
        if (this.views.enabled && !this.currentScrollingMode.isVirtual()) {
            this.updateViewCustomization(true);
        }
        else {
            if (this.pagination.scrollingType == ScrollingMode.Virtual) {
                const data = this.currentScrollingMode.loadData({ model: this.model, columns: this.columns, rows: this.rows });
                this.view = of(data);
            }
            else {
                this.privateService.idealRead(false);
            }
        }
        this.publicService.filters.next(state.filter);
        //TODO Chiedere ad Anny perchè h fatto questo perchè crea problemi quando cambi pagina si perde le righe
        /* Inizialmente era stato fatto a cause di questo:
         *     se nella griglia applico il filtro su una colonna (es. appezzamenti coinvolti) e clicco sul seleziona tutti,
         *     mi prende TUTTE le righe e non solamente quelle filtrate come ci si aspetterebbe.
         * Si era quindi pensato di resettare le righe selezionate al cambio dei filtri della griglia.
         * Ciò per evitare di avere righe selezionate che però non appaiono in griglia.
         *
         * 07/06/23 si decide che la selezione delle righe deve essere persistente al cambio di vista/filtri
        */
        if (deselectPrev) {
            // Deseleziono tutte le righe precedentemente selezionate
            this.rows.forEach(s => s['Selected'] = false);
            this.selectAllState = "unchecked";
        }
    }
    showToolbar;
    showCmdColumn;
    showCmdDDL;
    showDettagliColumn;
    showCustomColumn;
    initParams() {
        const computeCmdColumnWidth = () => {
            let count = 0;
            this.cmdColumn.editBtn && count++;
            this.cmdColumn.infoBtn && count++;
            this.cmdColumn.removeBtn && count++;
            return count == 1 ? 70 : count == 2 ? 110 : count == 3 ? 170 : 0;
        };
        const showDettagliColumn = () => {
            if (this.dettagliColumn == null) {
                this.dettagliColumn = new DettagliColumnSettings();
            }
            return this.dettagliColumn?.editBtn || this.cmdColumn?.infoBtn;
        };
        const showCustomColumn = () => {
            if (this.customColumn == null) {
                this.customColumn = new CustomColumnSettings();
            }
            return this.customColumn?.showColumn;
        };
        this.showToolbar = this.toolbar.showToolbar() || this.columnMenu.kendoGridColumnChooser || this.views.enabled;
        this.showCmdColumn = this.cmdColumn.showCmdColumn();
        this.showCmdDDL = this.cmdDropDown.showCmdDropDown();
        this.showDettagliColumn = showDettagliColumn();
        this.showCustomColumn = showCustomColumn();
        this.cmdColumn.width = computeCmdColumnWidth();
    }
    pageChangeEvent = new EventEmitter();
    pageChange(event) {
        if (this.pagination.scrollingType != ScrollingMode.Virtual) {
            this.pageChangeEvent.emit({
                grid: this.grid,
                event: event
            });
            this.pagination.gridState.skip = event.skip;
        }
        else {
            // This is being handled in onStateChange
        }
    }
    selectionChange = new EventEmitter();
    onSelectionChange(event) {
        event.selectedRows?.forEach(s => s.dataItem['Selected'] = true);
        event.deselectedRows?.forEach(s => s.dataItem['Selected'] = false);
        this.onSelectedKeysChange(null);
        if (this.selectable.selectable?.enabled && this.selectable.preselectedRows.selectionChangeFn) {
            setTimeout(() => {
                if (!this.selectAllChecked) {
                    this.selectable.preselectedRows.selectionChangeFn(event, this);
                }
            }, 1);
        }
        this.publicService.next({
            stopPropagation: true,
            forceRefresh: false,
            data: this.GetDatiAttuali()
        });
        this.publicService.selection.getSelectedValue.next({ value: event });
        this.selectionChange.emit(event);
    }
    // public isRowSelected = (e: RowArgs) => {
    //     if(typeof this.selectable.preselectedRows.isRowSelectedFn !== 'function') {
    //         return;
    //     }
    //     return this.selectable.preselectedRows.isRowSelectedFn(e, this);
    // };
    isRowSelected = (e) => e.dataItem['Selected'];
    /**
     * Signal column visibility change.
     */
    columnVisibilityChange = new EventEmitter();
    columnVisibilityChangeHandler(event) {
        //console.log(event);
        this.updateViewCustomization(true);
        this.applyRendererGiven(event);
        this.columnVisibilityChange.emit(event);
    }
    numericTextBox = new EventEmitter();
    onChange(event) {
        this.numericTextBox.emit(event);
    }
    /**
     *  Auxiliary functions
     **/
    closeEditor(grid, rowIndex = this.editedRowIndex) {
        grid.closeRow(rowIndex);
        this.editedRowIndex = undefined;
        this.formGroup = undefined;
        this.disableButtonsDuringEditMode(false);
    }
    tooltipDir;
    showTooltip(event) {
        let element = event.target;
        //let currCol = this.columns.find(c => c.title === element.innerText);
        if ((element.nodeName !== 'SPAN') // is not a header
            || !this.columns?.map(c => c.title).includes(element.innerText)) { // is not a data column
            this.tooltipDir.hide();
            return;
        }
        this.tooltipDir.show(element);
    }
    /**
     * Aggregates.
     */
    aggregates;
    total;
    defaultInitializationMethod() {
        this.initView();
        this.logService.checkGridMasterDetailConfig(this.kendoGridMasterService, this.masterdetailSettings.enable);
        let dataItem = null;
        //Passo il dataItem della riga Master che si è aperta se sono in una grid master detail
        if (this.masterdetailSettings.IsGridMaster()) {
            this.kendoGridMasterService.GridMasterService = this.privateService;
            this.kendoGridMasterService.RowIdGridMaster = this.rowId;
        }
        if (this.masterdetailSettings.IsGridDetail()) {
            dataItem = this.kendoGridMasterService.Last_RowExpanded;
            this.kendoGridMasterService.GridDetailService = new GridDetailInfo(dataItem[this.kendoGridMasterService.RowIdGridMaster], this.privateService);
            //Rendo il gridId univoco
            this.gridId = this.gridId + "|_|" + dataItem[this.kendoGridMasterService.RowIdGridMaster];
            this.publicService.Current_Grid_Master_RowExpanded = dataItem;
        }
        this.privateService.idealRead(true, false);
    }
    ShowkendoGridDetailTemplate() {
        let show = false;
        if (this.masterdetailSettings.IsGridMaster() && this.masterdetailSettings.templateGridDetail) {
            show = true;
        }
        return show;
    }
    initializeUsingResolver() {
        this.rows = this.privateService.getRows();
        this.model = this.privateService.getModel();
        this.columns = this.privateService.getColumns();
        this.initView();
        this.resetGroupColumns();
        this.rowsLoaded.emit();
    }
    initializeUsingHTML() {
        this.privateService.setKendoData(this.rows, this.model, this.columns);
        this.initView();
    }
    colsLoaded = new Subject();
    initView() {
        this.view = this.privateService.pipe(map((kData) => {
            this.total = new Map();
            this._calculateAggregatesTotal(kData.rows, true, '', '');
            if (!kData || kData.model == undefined) {
                return this._feedEmptyGrid();
            }
            this._initializeGridData(kData);
            this._updateSelectAllColumnBasedOnSelectedRows();
            return this.currentScrollingMode.loadData(kData);
        }));
        this.changeDetector.detectChanges();
    }
    refreshAggregateTotal() {
        this.total = new Map();
        this._calculateAggregatesTotal(this.rows, true, '', '');
    }
    _calculateAggregatesTotal(rows, footer, field, value) {
        if (this.aggregates.enabled) {
            let key = "";
            if (field != "") {
                key = JSON.stringify({ field: field, value: value });
            }
            if (this.total.has(key)) {
                return this.total.get(key);
            }
            let gridHelper = new GridHelper();
            let aggregate = gridHelper.calculateAggregate(rows, this.pagination, this.aggregates, footer);
            this.total.set(key, aggregate);
            return aggregate;
        }
        return {};
    }
    _initializeGridData(kData) {
        this.model = kData.model;
        this.columns = kData.columns;
        this.rows = kData.rows;
        this.resetGroupColumns();
        this.rowsLoaded.emit();
    }
    _feedEmptyGrid() {
        this.model = {};
        this.columns = [];
        this.resetGroupColumns();
        return process([], this.pagination.gridState);
    }
    _updateSelectAllColumnBasedOnSelectedRows() {
        if (this.selectable.selectable.enabled)
            this.onSelectedKeysChange(null);
    }
    manageSelectedRows() {
        // if(this.selectable.selectable.enabled) {
        //   this.selectedRows = this.rows.filter(s => s['Selected']).map(s => s[this.rowId]);
        // this.selectable.preselectedRows.selectedRows =
        //}
    }
    //@ContentChildren(ColumnComponent) contentColumns!: QueryList<ColumnComponent>;
    // const inCols: Array<ColumnBase> =  this.contentCmdColumns.toArray().concat(this.contentColumns.toArray());
    // Le colonne inserite nel shadow dom della componente padre.
    contentCmdColumns;
    initialized = false;
    createColumnsDynamically(kdata) {
        if (this.contentCmdColumns.length == 0) {
            return;
        }
        this.addShadowDomColumnsToTheGrid(this.grid.columns);
    }
    reorderMissplacedColumnsAfterUpdate() {
        // Must be called, otherwise we risk performing behavior on non updated data.
        this.changeDetector.detectChanges();
        let cmdColumns = this.grid.columns.filter((col) => col instanceof CommandColumnComponent);
        let colsToReorder = [...cmdColumns.reverse()];
        const alreadyApplied = columnAlreadyInView(this.contentCmdColumns, this.grid.columns);
        if (!alreadyApplied) {
            colsToReorder = [...colsToReorder, , ...this.contentCmdColumns.toArray()];
        }
        colsToReorder.forEach(col => {
            this.grid.reorderColumn(col, 0, { before: false });
        });
        //Riordino le colonne in base a come erano state salvate nella vista se sono state
        //messe prime le colonne con i comandi
        if (colsToReorder && colsToReorder.length > 0 && this.loadedView && this.loadedView.Colonne && this.loadedView.Colonne.length > 0) {
            let NotCmdColumn = this.loadedView.Colonne.filter(c => c.field && c.field !== "");
            if (NotCmdColumn && NotCmdColumn.length > 0) {
                NotCmdColumn.forEach((c, index) => {
                    let columnbase = this.grid.columns.toArray().find(columnbase => columnbase.title === c.title);
                    let newIndex = colsToReorder.length + index;
                    this.grid.reorderColumn(columnbase, newIndex, { before: false });
                });
            }
        }
        this.changeDetector.detectChanges();
    }
    addShadowDomColumnsToTheGrid(alreadyAppliedColumns) {
        this.changeDetector.detectChanges();
        const applied = columnAlreadyInView(this.contentCmdColumns, this.grid.columns);
        if (applied) {
            return;
        }
        let checkboxColumns = alreadyAppliedColumns.filter(s => s instanceof CheckboxColumnComponent);
        let cmdColumns = alreadyAppliedColumns.filter(s => s instanceof CommandColumnComponent);
        let colComp = alreadyAppliedColumns.filter(s => s instanceof ColumnComponent);
        this.changeDetector.detectChanges();
        let result = [...checkboxColumns, ...this.contentCmdColumns, ...cmdColumns, ...colComp];
        this.grid.columns.reset(result);
        this.changeDetector.detectChanges();
        this.reorderMissplacedColumnsAfterUpdate();
    }
    viewInit = new Subject();
    /**
     * Called one time once the data is set inside the grid.
     */
    async ngAfterViewInit() {
        this.privateService.pipe(takeUntil(this.unsubSignal)).subscribe((kdata) => {
            this.createColumnsDynamically(kdata);
            this.dataWasReadApplyRenderer();
            this.publicService.parseQueryParams();
            this.autofitColumns(this.grid.columns);
            this.adjustGridHeightBasedOnContent();
            // visibleCols(this.grid.columns.toArray())
        });
    }
    _loadedViewApplied = false;
    ngAfterViewChecked() {
        let tbs = document.getElementsByTagName('table');
        for (let i = 0; i < tbs.length; i++) {
            tbs.item(i).style.width = '100%';
        }
        if (!this._loadedViewApplied && this.loadedView) {
            let cols = this.publicService.gridComp.columns.toArray();
            this.loadedView.Colonne.forEach(c => {
                let column = cols.find(col => col.title === c.title);
                if (!column)
                    return;
                column.hidden = c.hidden || column.hidden;
                column.width = c.width || column.width;
            });
            this._loadedViewApplied = true;
        }
    }
    createUsecaseServices() {
        this.currentScrollingMode = ScrollingModeFactory.Create({
            mode: this.pagination.scrollingType,
            componentContext: this
        });
    }
    autofitInitialized = false;
    autofitColumns(columnsQL) {
        if (!this.resizable.autoFitColumns) {
            return;
        }
        const getColumnsEligibleForAutofit = (columns) => {
            return columns.filter(column => _isNull(column.width) /*&& !column.isCheckboxColumn*/ && !column.hidden);
        };
        const autoFitColumns = () => {
            let columnAutofittable = getColumnsEligibleForAutofit(columnsQL);
            let chkCol = columnsQL.filter((column) => column.isCheckboxColumn);
            if (chkCol != undefined && chkCol[0] != undefined) {
                chkCol[0].width = 40;
            }
            if (columnAutofittable && columnAutofittable.length > 0)
                this.grid.autoFitColumns(columnAutofittable);
            // this.grid.autoFitColumns();
        };
        this.ngZone.onStable
            .asObservable()
            .pipe(take$1(1))
            .subscribe(autoFitColumns);
    }
    dataWasReadApplyRenderer() {
        const readEvent = {
            columns: this.grid.columns.toArray()
        };
        this.applyRendererGiven(readEvent);
    }
    applyRendererGiven(eventType) {
        const opts = {
            grid: this.grid,
            gridElRef: this.gridElRef,
            event: eventType
        };
        const applyRendererIfDefined = (opts) => {
            const _applyRendererRules = () => {
                this.changeDetector.detectChanges();
                this.publicService.gridElRef = this.gridElRef;
                this.publicService.gridComp = this.grid;
                this.publicService.giasGridComponent = this;
                this.config.applyRendererRules(opts);
                this._adaptHeightOnContainer();
                this.changeDetector.detectChanges();
            };
            this.ngZone.onStable
                .asObservable()
                .pipe(take$1(1))
                .subscribe(_applyRendererRules);
        };
        applyRendererIfDefined(opts);
    }
    /**
     * Editing
     */
    createFormGroup(row) {
        this.formGroup = new FormGroup({});
        let helper = new GridHelper();
        Object.keys(this.model).forEach((key) => {
            let c;
            let ctrlInput;
            c = this.privateService.getColumns().find((col) => col.field == key);
            const field = this.model[key];
            if (c) {
                switch (field.type) {
                    case this.STRING:
                        ctrlInput = row?.[c.field] ?? (c.string?.defaultValue ?? '');
                        break;
                    case this.DATE:
                        ctrlInput = this.intlService.parseDate(row?.[c.field])
                            ?? (c.date?.defaultValue ?? new Date());
                        break;
                    case this.MULTI_DROPDOWNLIST:
                        let mddlHelper = new DropdownHelper();
                        ctrlInput = mddlHelper.getMultiDropdownCtrlInput(c, row);
                        break;
                    case this.DROPDOWNLIST:
                        if (!c.ddl?.valuePrimitive) {
                            let valueCod = row?.[c.ddl.formControlName] ?? (c.ddl?.defaultValue ?? null);
                            if (typeof (valueCod) == 'number' || typeof (valueCod) == 'string') {
                                const objDdl = {};
                                objDdl[c.ddl.valueField] = valueCod;
                                objDdl[c.ddl.textField] = row?.[c.ddl.formControlValue] ?? (c.ddl?.defaultValue ?? null);
                                valueCod = objDdl;
                            }
                            helper.setCustomValidatorRow(c, row);
                            const formCtrlValue = new FormControl(valueCod, c.validators);
                            this.formGroup.addControl(c.ddl.formControlName, formCtrlValue);
                            return;
                        }
                        else {
                            helper.setCustomValidatorRow(c, row);
                            ctrlInput = row?.[c.ddl.formControlName] ?? (c.ddl?.defaultValue ?? null);
                        }
                        break;
                    case this.BOOLEAN:
                        ctrlInput = row?.[c.field] ?? (c.boolean?.defaultValue ?? false);
                        break;
                    case this.NUMERIC:
                        ctrlInput = row?.[c.field] ?? (c.numeric?.defaultValue ?? 0);
                        break;
                }
                const formCtrl = new FormControl(ctrlInput, c.validators);
                if (c.disabledRule && c.disabledRule(row))
                    formCtrl.disable();
                this.formGroup.addControl(c.field, formCtrl);
            }
            else {
                switch (field.type) {
                    case this.STRING:
                        ctrlInput = row?.[key];
                        break;
                    case this.DATE:
                        ctrlInput = this.intlService.parseDate(row?.[key]);
                        break;
                    case this.DROPDOWNLIST:
                    case this.BOOLEAN:
                        ctrlInput = row?.[key];
                        break;
                    case this.NUMERIC:
                        ctrlInput = row?.[key];
                        break;
                }
                const formCtrl = new FormControl(ctrlInput);
                this.formGroup.addControl(key, formCtrl);
            }
        });
        // ! Hook to enable form group control from the public API.
        this.publicService.formGroup.next(this.formGroup);
    }
    getDate(row, column) {
        const date = this.intlService.parseDate(row[column.field]);
        return date;
    }
    onOpenReloadDDL(event, formgroup, forceReload) {
        let helper = new GridHelper();
        let component = null;
        if (event.data instanceof GridMultiDropdownComponent) {
            component = event.data;
        }
        const dati = { component: component, columns: this.columns, row: formgroup.value };
        helper.loadDropdownListOnCellOpened(dati, forceReload);
    }
    /**
     * Used for displaying validation messages.
     */
    get formControls() {
        return this.formGroup.controls;
    }
    /**
     * Used for dinamically updating different dropdown lists.
     */
    ddlStateChanged(event, formgroup, col) {
        this.privateService.dropdownListSubject.next({
            id: event.id,
            type: DropdownEventType.ON_CHANGE_VALUE,
            data: event.data,
            listItems: event.listItems
        });
        let helper = new GridHelper();
        if (col.ddl.descriptionField != null && col.ddl.descriptionField != '') {
            if (helper.columnContainsSimpleDropdownList(this.model, col.field)) {
                const val = event.listItems.find((el) => el.id == event.data);
                if (val) {
                    formgroup.controls[col.ddl.descriptionField].setValue(val.name);
                }
            }
            else if (helper.columnContainsMultiDropdownList(this.model, col.field)) {
                const values = event.listItems.filter((el) => event.data.includes(el.id));
                if (values) {
                    formgroup.controls[col.ddl.descriptionField].setValue(values.map(v => v.name));
                    // Notify the component that there has been a value change
                    // even if the multiselect's panel has not been closed yet
                    const event = {
                        action: 'multiselectValueChange',
                        dataItem: values,
                        isNew: false,
                        rowIndex: col.orderIndex,
                        sender: this.grid
                    };
                    this.publicService.changeDetected.next(event);
                }
            }
        }
    }
    ddlOpenEvent(event, formGroup) {
        //console.log(event.type, event.id, event.data);
        const gridDropdownListComponent = event.data;
        const cols = this.columns.find((col) => col.field == gridDropdownListComponent.controlName);
        if (cols.ddl.loadOnEdit) {
            cols.ddl.loadFunction(formGroup.getRawValue()).pipe(take$1(1)).subscribe((data) => {
                if (data.length != 0) {
                    let item = data[0];
                    if (!item.hasOwnProperty('id') || !item.hasOwnProperty('name')) { }
                    //throw Error('Property id and descrizione are required.');
                }
                const ddlData = data.map(el => new DropdownListItem(el[cols.ddl.id], el[cols.ddl.formControlValue], el));
                gridDropdownListComponent.data = ddlData;
                gridDropdownListComponent.source = ddlData;
                cols.ddl.data = ddlData;
            });
        }
        //console.log(cols);
    }
    ddlReload(event, formGroup, col) {
        //console.log(event.type, event.id, event.data);
        const gridDropdownListComponent = event.data;
        const cols = this.columns.find((col) => col.field == gridDropdownListComponent.controlName);
        cols.ddl.loadFunction(formGroup.getRawValue()).pipe(take$1(1)).subscribe((data) => {
            if (data.length != 0) {
                let item = data[0];
                if (!item.hasOwnProperty('id') || !item.hasOwnProperty('name')) { }
            }
            const ddlData = data.map(el => new DropdownListItem(el[cols.ddl.id], el[cols.ddl.formControlValue], el));
            gridDropdownListComponent.data = ddlData;
            gridDropdownListComponent.source = ddlData;
            cols.ddl.data = ddlData;
        });
        //console.log(cols);
    }
    onOpenCommands(data) {
        this.cmdDropDown.resetCommands();
        this.publicService.openCommands.next(data);
    }
    onCommand(cmd, dataItem, isNew, rowIndex) {
        switch (cmd.action) {
            case CommandsDropDownEvents.INLINE_EDIT:
                this.editHandler({
                    dataItem: dataItem,
                    isNew: isNew,
                    rowIndex: rowIndex,
                    sender: this.publicService.gridComp
                });
                break;
            case CommandsDropDownEvents.REMOVE:
                this.removeHandler({
                    dataItem: dataItem,
                    isNew: isNew,
                    rowIndex: rowIndex,
                    sender: this.publicService.gridComp
                });
                break;
            case CommandsDropDownEvents.INFO:
                this.infoCmdHandler(dataItem, isNew, rowIndex);
                break;
            case CommandsDropDownEvents.USER_BIND:
                this.userBindCmdHandler(dataItem, isNew, rowIndex);
                break;
        }
        this.publicService.commandEvent.next({
            command: cmd,
            dataItem: dataItem,
            rowIndex: rowIndex
        });
    }
    ButtonGridCommandName(cmd) {
        let name = "";
        if (cmd.paramsforTrasloco) {
            name = this.translocoService.translate(cmd.actionName, cmd.paramsforTrasloco);
        }
        else {
            name = this.translocoService.translate(cmd.actionName);
        }
        return name;
    }
    editBtnHandler(data, isNew, rowIndex) {
        this.dettagliColumn.edit(data, isNew, rowIndex);
    }
    actionBtnHandler(data, isNew, rowIndex) {
        this.customColumn.action(data, isNew, rowIndex);
    }
    infoCmdHandler(data, isNew, rowIndex) {
        const event = {
            action: 'info',
            dataItem: data,
            isNew: isNew,
            rowIndex: rowIndex,
            sender: this.grid
        };
        this.publicService.changeDetected.next(event);
    }
    userBindCmdHandler(data, isNew, rowIndex) {
        const event = {
            action: 'userBind',
            dataItem: data,
            isNew: isNew,
            rowIndex: rowIndex,
            sender: this.grid
        };
        this.publicService.changeDetected.next(event);
    }
    columns;
    rows;
    model;
    applyColumnReorderPolicy(event) {
        if (event.column instanceof CommandColumnComponent) {
            // event.preventDefault();
            return;
        }
        this.updateViewCustomization(null);
        // this.autofitColumns(visibleCols([event?.column]));
    }
    applyColumnVisibilityChangePolicy(event) {
        this.updateViewCustomization(true);
        // this.autofitColumns(visibleCols(event?.columns));
    }
    /**
     * Grid customizations.
     */
    rereadRowsOnViewUpdate = true;
    updateViewCustomization(leaveRereadRowsUntouched) {
        if (this.views.enabled) {
            if (!leaveRereadRowsUntouched)
                this.rereadRowsOnViewUpdate = false;
            this.customizationViewChanged = false;
            this.changeDetector.detectChanges();
            this.customizationViewChanged = true;
            /*let col = this.mapKendoGridColumnfromColumnComponent(this.grid.columns);
            this.privateService.reReadRows(this.model, col, false);*/
        }
    }
    mapKendoGridColumnfromColumnComponent(col) {
        let kendogridCol = [];
        const columns = col
            .toArray()
            .flatMap(x => 'children' in x ? x.children.toArray() : x);
        columns.forEach(columnComponent => {
            if (columnComponent instanceof ColumnComponent) {
                const savedColumn = new KendoGridColumn({ field: '', title: '' });
                Object.keys(savedColumn).forEach((key) => {
                    savedColumn[key] = columnComponent[key];
                    if (key === 'filter') {
                        this.customizationService.manageCellTypes(columnComponent, savedColumn, key, this.columns);
                    }
                });
                kendogridCol.push(savedColumn);
            }
        });
        return kendogridCol;
    }
    views;
    customizationViewChanged;
    /** Vista caricata tra quelle salvate dall'utente. */
    loadedView = null;
    lastView;
    applyView(view) {
        const restoreLostData = (cols) => {
            return this.privateService.restoreLostData(cols);
        };
        if (!view) {
            //Reimposto lo stato di default della griglia
            if (this.privateService.defaultGridState)
                this.pagination.gridState = this.privateService.defaultGridState;
            //this.mostraCheckECmdColumn();
            this.privateService.reReadRows(this.model, [], true);
            return;
        }
        const settings = this.mapGridSettings(view);
        this.loadedView = settings;
        this.pagination.gridState = settings.Stato;
        let cambioVista = false;
        if (this.lastView?.NomeVista != view.NomeVista) {
            cambioVista = true;
        }
        if (this.rereadRowsOnViewUpdate || cambioVista) {
            //this.mostraCheckECmdColumn();
            this.privateService.reReadRows(this.model, restoreLostData(settings.Colonne), false);
        }
        else {
            this.rereadRowsOnViewUpdate = true;
        }
        this.changeDetector.detectChanges();
        this.lastView = cloneDeep(view);
    }
    mostraCheckECmdColumn() {
        // let event: ColumnVisibilityChangeEvent;
        // event = new ColumnVisibilityChangeEvent([]);
        // if(this.checkboxColumn && this.selectable?.checkboxIsEnabled){
        //   this.checkboxColumn.hidden = false;
        //   this.checkboxColumn.orderIndex = 0;
        //   event.columns.push(this.checkboxColumn);
        // }
        // if (this.commandColumn){
        //   this.commandColumn.hidden = false;
        //   this.commandColumn.orderIndex = 0;
        //   event.columns.push(this.commandColumn);
        // }
        // this.initParams();
        // //this.columnVisibilityChangeHandler(event);
        // this.applyRendererGiven(event);
    }
    mapGridSettings(view) {
        const state = view.Stato;
        mapDateFilter(state.filter, this.model, this.columns);
        view.Colonne = this.mapColumns(view.Colonne, this.columns);
        return {
            IdVista: view.IdVista,
            IsModified: null,
            IsNew: null,
            NomeVista: view.NomeVista,
            NomeUtente: view.NomeUtente,
            GridId: view.GridId,
            Predefinita: view.Predefinita,
            Stato: state,
            Colonne: view.Colonne.sort((a, b) => a.orderIndex - b.orderIndex), //view.Colonne // view.Colonne.sort((a, b) => a.orderIndex - b.orderIndex)
            FiltroJSON: view.FiltroJSON,
            FlagPubblica: view.FlagPubblica
        };
    }
    /**
     *
     * @param viewColumns - le colonne della vista
     * @param columns - le colonne presenti in griglia (attuali)
     * @returns le colonne una volta applicata la vista
     */
    onColumnResize() {
        this.rereadRowsOnViewUpdate = false;
        this.updateViewCustomization(true);
    }
    /// End grid customizations
    /**
     * Export data via excel.
     * Generates the data required for exporting to Excel.
     *
     * This method processes the current grid data, applying grouping, sorting,
     * and filtering based on the grid's state. It then maps the processed data
     * into a format suitable for Excel export using a helper function. The
     * mapping concerns the colums labeled as dropdown or multiselect.
     *
     * @returns {ExcelExportData} The formatted data ready for Excel export.
     *
     * If there's the need to handle the serialization of custom columns, modify
     * the mapping function in the helper {@link GridHelper.mapForExcelExport}.
     */
    excelData() {
        let helper = new GridHelper();
        //let dataForExcel = helper.mapForExcelExport(this.rows.slice(), this.columns);
        let dataForExcel = this.rows.slice();
        let data = process(dataForExcel, {
            group: this.pagination.gridState.group,
            sort: this.pagination.gridState.sort,
            filter: this.grid.filter
        });
        let dataForExcel2 = helper.mapForExcelExport(data.data, this.columns);
        const result = {
            data: dataForExcel2
        };
        console.log('result', result);
        return result;
    }
    selectAllState = "unchecked";
    rowId;
    selectAllChecked = false;
    onSelectAllChange(checkedState) {
        this.selectAllChecked = true;
        const filteredRows = process(this.rows, { filter: this.grid.filter }).data;
        if (checkedState === "checked") {
            // Checks only the filtered ones
            this.rows.forEach(s => s['Selected'] = filteredRows.includes(s));
            this.selectAllState = "checked";
        }
        else {
            // Unchecks everything
            this.rows.forEach(s => s['Selected'] = false);
            this.selectAllState = "unchecked";
        }
        this.publicService.next({
            stopPropagation: true,
            forceRefresh: false,
            data: this.GetDatiAttuali()
        });
        let selectedRow = this.rows.filter((r) => r['Selected'] == true);
        let deselectedRow = this.rows.filter((r) => r['Selected'] == false);
        let selectedRowArgs = selectedRow.map((e, index) => {
            return {
                dataItem: e,
                index: index
            };
        });
        let deselectedRowArgs = deselectedRow.map((e, index) => {
            return {
                dataItem: e,
                index: index
            };
        });
        if (this.selectable.preselectedRows.selectionChangeFn) {
            this.selectable.preselectedRows.selectionChangeFn({
                selectedRows: selectedRowArgs,
                deselectedRows: deselectedRowArgs
            }, this);
        }
        setTimeout(() => {
            this.selectAllChecked = false;
        }, 1);
    }
    onSelectedKeysChange(ev) {
        const selected = this.rows.some(s => s['Selected']);
        const unselected = this.rows.some(s => !s['Selected']);
        if (selected && unselected) {
            this.selectAllState = "indeterminate";
        }
        else if (!selected) {
            this.selectAllState = "unchecked";
        }
        else {
            this.selectAllState = "checked";
        }
    }
    GetDatiAttuali() {
        return {
            rows: this.rows,
            columns: this.columns,
            model: this.model
        };
    }
    filterableGrid() {
        if (this.columns) {
            let index = this.columns.findIndex((c) => { return c.filterable == true; });
            if (index >= 0) {
                return true;
            }
        }
        return false;
    }
    showEditButton(dataItem) {
        let show = false;
        if (this.cmdColumn.editBtn || this.cmdColumn.showEditBtn(dataItem))
            show = true;
        return show;
    }
    getColumnStyle(col) {
        if (col) {
            let field = this.model[col.field];
            if (field?.type == CELL_TYPES.NUMBER && col.style == undefined) {
                return { "text-align": "right" };
            }
            else {
                return col.style;
            }
        }
        return null;
    }
    getColumnFooterStyle(col) {
        if (col) {
            let field = this.model[col.field];
            if (field?.type == CELL_TYPES.NUMBER && col.footerStyle == undefined) {
                return { "text-align": "right" };
            }
            else {
                return col.footerStyle;
            }
        }
        return null;
    }
    setSelectedRows(opts) {
        if (opts.resetPreviousSelection)
            resetSelection(this.rows);
        let firstMatchIndex = -1;
        opts.keys.forEach((key) => {
            let index = findMatchedIndex(key, this.rows, this.rowId, opts);
            if (index >= 0) {
                this.rows[index]['Selected'] = true;
                if (firstMatchIndex === -1)
                    firstMatchIndex = index;
            }
        });
        this.gridState.skip = Shared.changeGridPage(firstMatchIndex, this.pageSize);
        this.refresh();
    }
    deselectRows(rows) {
        resetSelection(this.rows.filter(row => {
            return rows.map(r => r.dataItem).includes(row);
        }));
    }
    deselectAllRows() {
        resetSelection(this.rows);
    }
    resetMulticheckStore() {
        this.worker.resetStore();
    }
    refresh() {
        this.publicService.refresh(false, this.GetDatiAttuali());
    }
    forceReload() {
        this.publicService.refresh(true);
    }
    detailCollapse = new EventEmitter();
    detailMasterRowCollapse(event) {
        if (this.masterdetailSettings.IsGridMaster()) {
            this.kendoGridMasterService.Last_RowExpanded = null;
        }
        this.detailCollapse.emit(event);
    }
    detailExpand = new EventEmitter();
    detailMasterRowExpand(event) {
        if (this.masterdetailSettings.IsGridMaster()) {
            this.kendoGridMasterService.Last_RowExpanded = event.dataItem;
        }
        this.detailExpand.emit(event);
    }
    showCmdDdlButton(dataItem) {
        let show = false;
        if (this.showCmdDDL && !this.cmdDropDown.hidecmdDropDown(dataItem))
            show = true;
        return show;
    }
    IsVisibleCmdClumn() {
        let visible = false;
        if (this.showCmdColumn || this.showCmdDDL) {
            visible = true;
        }
        return visible;
    }
    // Function used to keep the original order in the columnGroups
    defaultOrder(a, b) {
        return 0;
    }
    get hasBatchChanges() {
        return this.gridBatchHandlerService.hasChanges;
    }
    useCustomColumnCellTemplate() {
        let applyCustomColumnTemplate = false;
        if (this.customCommandColumnCellTemplate && this.customColumn.useCustomColumnCellTemplate) {
            applyCustomColumnTemplate = true;
        }
        return applyCustomColumnTemplate;
    }
    mapColumns(viewColumns, columns) {
        let colonneRet = viewColumns.map((colonna) => {
            let col = columns.find((col) => col.field == colonna.field);
            let colCopy = cloneDeep(colonna);
            if (col) {
                colonna = col;
            }
            // for (var variableKey in colCopy){
            //     if (colCopy.hasOwnProperty(variableKey)){
            //         colonna[variableKey] = colCopy[variableKey];
            //     }
            // }
            colonna.width = colCopy.width;
            colonna.field = colCopy.field;
            //colonna.title = colCopy.title;
            colonna.hidden = colCopy.hidden;
            colonna.orderIndex = colCopy.orderIndex;
            return colonna;
            // if (col && col.date != null) {
            //     colonna.date = col.date;
            //     return colonna
            // } else {
            //     return colonna;
            // }
        });
        //Aggiungo le nuove colonne che potrebbero essere state aggiunte nel frattempo dallo sviluppatore
        //ma che non sono presenti nella vista
        if (colonneRet.length > 0) {
            columns.forEach(c => {
                if (colonneRet.findIndex(i => c.field && i.field === c.field) === -1) {
                    colonneRet.push(c);
                }
            });
        }
        return colonneRet;
    }
    useCustomColumnHeaderTemplate() {
        let applyCustomColumnTemplate = false;
        if (this.customCommandColumnHeaderTemplate && this.customColumn.useCustomColumnHeaderTemplate) {
            applyCustomColumnTemplate = true;
        }
        return applyCustomColumnTemplate;
    }
    showBtncustomColumn(isNew) {
        let show = false;
        if (!isNew && this.customColumn.showBtn) {
            show = true;
        }
        return show;
    }
    useColumnGroup(group) {
        let use = false;
        if (group.key && group.key !== "") {
            use = true;
        }
        return use;
    }
    showAgronicakendoGridCellTemplate(cellType, col) {
        return (cellType === CELL_TYPES.DATE || cellType === CELL_TYPES.DATETIME || cellType === CELL_TYPES.DROPDOWNLIST ||
            cellType === CELL_TYPES.MULTI_DROPDOWNLIST || cellType === CELL_TYPES.CUSTOM || cellType === CELL_TYPES.NUMBER ||
            cellType === CELL_TYPES.BOOLEAN || this.ShowHTMLAsString(cellType, col));
    }
    showAgronicakendoGridGroupHeaderTemplate(cellType) {
        let show = false;
        if (this.groups.groupable && (cellType === CELL_TYPES.DROPDOWNLIST || cellType === CELL_TYPES.MULTI_DROPDOWNLIST)) {
            show = true;
        }
        return show;
    }
    showAgronicakendoGridFooterTemplate(cellType) {
        let show = false;
        if (this.aggregates.enabled && cellType === CELL_TYPES.NUMBER) {
            show = true;
        }
        return show;
    }
    getAggregateResult(aggregateSetting, col, aggregate) {
        let n = aggregateSetting?.[col.field]?.[aggregate];
        return n;
    }
    showkendoGridFilterMenuTemplate(cellType, column) {
        let show = false;
        if (this.showMultiCheckFilter(cellType, column) || this.showAgronicakendoGridFilterMenuTemplate(cellType)) {
            show = true;
        }
        return show;
    }
    showAgronicakendoGridFilterMenuTemplate(cellType) {
        return false;
    }
    showMultiCheckFilter(cellType, column) {
        if (cellType === CELL_TYPES.STRING || cellType === CELL_TYPES.DROPDOWNLIST || cellType === CELL_TYPES.DATE
            || cellType === CELL_TYPES.DATETIME || cellType === CELL_TYPES.MULTI_DROPDOWNLIST) {
            return true;
        }
        if (cellType === CELL_TYPES.NUMBER && column.numeric?.multiCheckFiltering) {
            return true;
        }
        return false;
    }
    showAgronicakendoGridEditTemplate(cellType) {
        return (cellType === CELL_TYPES.NUMBER || cellType === CELL_TYPES.DATE || cellType === CELL_TYPES.DATETIME ||
            cellType === CELL_TYPES.DROPDOWNLIST || cellType === CELL_TYPES.MULTI_DROPDOWNLIST ||
            cellType === CELL_TYPES.BOOLEAN || cellType === CELL_TYPES.CUSTOM);
    }
    sortChange(sort) {
        let sortNew = [];
        let sortCopy = [];
        let allDescriptionField = this.getAllDescriptionField();
        sort.forEach((s) => {
            if (allDescriptionField.indexOf(s.field) < 0) {
                sortCopy.push(s);
            }
        });
        sortCopy.forEach((s) => {
            if (s.dir != undefined) {
                let col = this.columns.find((c) => c.field == s.field);
                if (col && col.ddl && col.ddl?.descriptionField != "" && sortNew.findIndex((s1) => s1.field == col.ddl?.descriptionField) < 0) {
                    let d = { dir: s.dir, field: col.ddl.descriptionField };
                    let sDescriptionField = d;
                    sortNew.push(sDescriptionField);
                }
                sortNew.push(s);
            }
        });
        // console.log(sortNew);
        this.pagination.gridState.sort = sortNew;
    }
    getAllDescriptionField() {
        let df = this.columns.filter((c) => c.ddl != undefined).
            filter((c) => c.ddl.descriptionField != undefined)
            .map((c) => c.ddl.descriptionField);
        if (df) {
            return df;
        }
        return [];
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: GiasKendoGridComponent, deps: [{ token: GridCustomizationsService }, { token: KendoGridService }, { token: GridErrorService }, { token: i4.IntlService }, { token: i0.ChangeDetectorRef }, { token: i0.NgZone }, { token: GridWorkerService }, { token: i1$1.TranslocoService }, { token: i0.Renderer2 }, { token: GridBatchHandlerService }, { token: i2$3.DialogService }, { token: KendoGridMasterDetailService, optional: true }], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "19.2.9", type: GiasKendoGridComponent, isStandalone: false, selector: "gias-kendo-grid", inputs: { customCommandColumnCellTemplate: "customCommandColumnCellTemplate", customCommandColumnHeaderTemplate: "customCommandColumnHeaderTemplate", showSwitchViewsPrivatePublic: "showSwitchViewsPrivatePublic", gridId: "gridId", columns: "columns", rows: "rows", model: "model" }, outputs: { rowsLoaded: "rowsLoaded", cellClick: "cellClick", pageChangeEvent: "pageChangeEvent", selectionChange: "selectionChange", columnVisibilityChange: "columnVisibilityChange", numericTextBox: "numericTextBox", detailCollapse: "detailCollapse", detailExpand: "detailExpand" }, providers: [
            GridCustomizationsService,
            GridDropdownService,
            DatePipe,
            CustomizeDropdownService,
            GridWorkerService,
            GridBatchHandlerService
        ], queries: [{ propertyName: "noRecordsTemplateRef", first: true, predicate: ["noRecordsTemplateRef"], descendants: true }, { propertyName: "contentCmdColumns", predicate: CommandColumnComponent }], viewQueries: [{ propertyName: "grid", first: true, predicate: ["grid"], descendants: true, static: true }, { propertyName: "checkboxColumn", first: true, predicate: ["CheckboxColumn"], descendants: true }, { propertyName: "commandColumn", first: true, predicate: ["CommandColumn"], descendants: true }, { propertyName: "gridElRef", first: true, predicate: ["grid"], descendants: true, read: ElementRef, static: true }, { propertyName: "input", first: true, predicate: ["input"], descendants: true }, { propertyName: "tooltipDir", first: true, predicate: TooltipDirective, descendants: true }], ngImport: i0, template: "<div kendoTooltip [tooltipTemplate]=\"tooltipTemplate\" filter=\".k-grid .k-header\"\n     showOn=\"none\" (mouseover)=\"showTooltip($event)\">\n\n    <!-- Note: the option 'columnMenu=true' causes issues involving unwanted\n    horizontal scrolling when changing the state of the grid. -->\n\n    <!-- [rowSelected]=\"selectable.preselectedRows.isRowSelectedFn ? isRowSelected: null\" -->\n    <!-- [height]=\"generalSettings.height\" -->\n    <!-- (selectedKeysChange)=\"keyChange($event)\" -->\n    <!-- [rowSelected]=\"selectable.preselectedRows.isRowSelectedFn ? isRowSelected: null\" -->\n    <!-- (selectedKeysChange)=\"onSelectedKeysChange($event)\" -->\n    <kendo-grid #grid [id]=\"config.gridId\" [data]=\"view | async\" (cellClick)=\"cellClickHandler($event)\"\n                (cellClose)=\"cellCloseHandler($event)\" [selectable]=\"selectable.selectable\" [kendoGridSelectBy]=\"rowId\"\n                (selectedKeysChange)=\"onSelectedKeysChange($event)\" (selectionChange)=\"onSelectionChange($event)\"\n                (dataStateChange)=\"onStateChange($event)\" [resizable]=\"resizable.isResizable\"\n                [rowSelected]=\"isRowSelected\"\n                [reorderable]=\"generalSettings.reordable\" (columnResize)=\"views.enabled && onColumnResize()\"\n                (edit)=\"editHandler($event)\" (cancel)=\"cancelHandler($event)\" (save)=\"saveHandler($event)\"\n                (remove)=\"removeHandler($event)\" (add)=\"addHandler($event)\" [sortable]=\"sort.sortable ?? false\"\n                [sort]=\"pagination.gridState.sort\" [pageable]=\"pagination.pageable\"\n                [skip]=\"pagination.gridState.skip\" [navigable]=\"pagination.navigable\" (pageChange)=\"pageChange($event)\"\n                [groupable]=\"groups.groupable\" [group]=\"pagination.gridState.group\" [columnMenu]=\"false\"\n                [filterable]=\"$any(columnMenu.filterable)\" [filter]=\"pagination.gridState.filter\"\n                (columnVisibilityChange)=\"columnVisibilityChangeHandler($event)\"\n                (columnReorder)=\"applyColumnReorderPolicy($event)\"\n                [rowClass]=\"rowClassCallback.bind(this)\"\n                [style.height]=\"generalSettings.height\"\n                [height]=\"pagination?.virtualScrolling?.viewportHeight\"\n                [scrollable]=\"pagination.scrollingType\"\n                [rowHeight]=\"currentScrollingMode?.rowHeight\"\n                [pageSize]=\"currentScrollingMode?.pageSize\"\n                (detailCollapse)=\"detailMasterRowCollapse($event)\"\n                (detailExpand)=\"detailMasterRowExpand($event)\"\n                (sortChange)=\"sortChange($event)\">\n\n\n        <ng-template *ngIf=\"showToolbar\" kendoGridToolbarTemplate position=\"both\" let-position=\"position\">\n            <ng-container *ngIf=\"position == 'top'\">\n              <ng-container class=\"row\">\n                  <ng-content select=\"[toolbarStart]\">\n\n                  </ng-content>\n\n                  <span class=\"separator\"></span>\n                  <div class=\"gias-toolbar-section\">\n                      <div kendoTooltip *ngIf=\"behavior.excelSettings.enabled\">\n                          <button size=\"small\" type=\"button\" class=\"k-button\" kendoGridExcelCommand icon=\"file-excel\"\n                                  [title]=\"'giasgrid.Export_Excel' | transloco\">\n                          </button>\n                      </div>\n\n                      <div kendoTooltip *ngIf=\"behavior.pdfSettings.enabled\">\n                          <button size=\"small\" type=\"button\" class=\"k-button\" kendoGridPDFCommand icon=\"file-pdf\"\n                                  [title]=\"'giasgrid.Export_PDF' | transloco\">\n                          </button>\n                      </div>\n\n                      <button *ngIf=\"editingMode === IN_CELL && generalSettings.performOnEdit == false && toolbar.SaveBtn\"\n                              class=\"k-button grid-toolbar-button btn-primary-fill\"\n                              size=\"small\"\n                              [disabled]=\"!gridServices.incellHasChanges()\" (click)=\"saveChanges(grid)\">\n                          <div *ngIf=\"toolbar.title_save_button === '';else custom_title_save_button\">\n                              {{ 'giasgrid.Save_Changes' | transloco }}\n                          </div>\n                          <ng-template #custom_title_save_button>\n                              {{ toolbar.title_save_button }}\n                          </ng-template>\n                      </button>\n\n                      <button *ngIf=\"toolbar.resetChanges\" kendoButton class=\"grid-toolbar-button\" size=\"small\" (click)=\"resetHandler()\">\n                          {{ 'giasgrid.Annulla_Modifiche' | transloco }}\n                      </button>\n                  </div>\n\n                  <ng-content select=\"[headerContent]\">\n                      <!-- Content to be included by the user. -->\n                  </ng-content>\n                  <div class=\"spacer\"></div>\n                  <ng-container *ngIf=\"views.enabled\">\n\n                      <gias-grid-customizations class=\"ms-auto p-2 bd-highlight\" [options]=\"views\"\n                                          [(canApplyChanges)]=\"customizationViewChanged\" (applyView)=\"applyView($event)\"\n                                          [showSwitch]=\"showSwitchViewsPrivatePublic\">\n                          <kendo-grid-column-chooser kendoTooltip *ngIf=\"columnMenu.kendoGridColumnChooser\" end>\n                          </kendo-grid-column-chooser>\n                      </gias-grid-customizations>\n\n                  </ng-container>\n\n                  <ng-container *ngIf=\"!views.enabled\">\n                      <div class=\"ms-auto p-2 bd-highlight\"></div>\n                  </ng-container>\n\n                  <span *ngIf=\"views.enabled\" class=\"separator must-show\"></span>\n\n                  <ng-container *ngIf=\"filterableGrid()\">\n                      <div kendoTooltip class=\"gias-button-esercizi\">\n                          <button kendoButton type=\"button\" class=\"k-button\" (click)=\"resetFilter()\" icon=\"filter-funnel\"\n                                  [title]=\"'giasgrid.PulisciFiltri' | transloco\">\n                          </button>\n                      </div>\n                  </ng-container>\n\n                  <div class=\"gias-toolbar-section full-width-section\">\n                      <span *ngIf=\"views.enabled\" class=\"separator must-show\"></span>\n                      <ng-content select=\"[headerContentButtons]\">\n                      </ng-content>\n                  </div>\n                  <div class=\"gias-toolbar-section full-width-section\">\n                      <div kendoTooltip *ngIf=\"toolbar.newItem\" class=\"gias-new-item-rapid-button\">\n                          <button [title]=\"'giasgrid.NuovaSchedaRapida' | transloco\" size=\"small\" kendoGridAddCommand\n                                  class=\"btnDisabledInModifica btn-primary-fill btn-important\">\n                              <fa-icon class=\"faAddRowSingle\"></fa-icon>\n                          </button>\n                      </div>\n\n                      <div kendoTooltip *ngIf=\"editingMode == IN_LINE_BATCH || editingMode == IN_CELL_BATCH\">\n                          <button size=\"small\" [title]=\"'giasgrid.Salva' | transloco\" class=\"btn btn-primary-fill btn-important\"\n                              [disabled]=\"!hasBatchChanges\" (click)=\"batchSave()\">\n                              <fa-icon class=\"lg\" [icon]=\"faCircleSave\"></fa-icon>\n                          </button>\n                      </div>\n\n                      <ng-content select=\"[headerContentEnd]\">\n                          <!-- Content to be included by the user. -->\n                      </ng-content>\n                  </div>\n              </ng-container>\n              <ng-container class=\"row\">\n                  <div class=\"gias-toolbar-section full-width-section\">\n                      <ng-content select=\"[headerSecondLine]\">\n                          <!-- Content to be included by the user. -->\n                      </ng-content>\n                  </div>\n              </ng-container>\n            </ng-container>\n\n            <ng-container *ngIf=\"position == 'bottom'\">\n              <!-- THIS CAN BE USED AS A GENERIC FOOTER FOR THE WHOLE KENDO GRID -->\n              <div *ngIf=\"currentScrollingMode.isVirtual()\" class=\"footer-virtual-count\">\n                <p>{{ 'giasgrid.TotaleXElementi' | transloco: { count: currentScrollingMode.totalCount } }}</p>\n              </div>\n\n              <div *ngIf=\"!currentScrollingMode.isVirtual()\" class=\"footer-virtual-empty\">\n                <!-- This removes any extra space when footer is not needed -->\n              </div>\n            </ng-container>\n          </ng-template>\n\n        <ng-template kendoGridNoRecordsTemplate>\n          <ng-container *ngTemplateOutlet=\"noRecordsTemplateRef;\">\n          </ng-container>\n        </ng-template>\n\n        <kendo-grid-checkbox-column #CheckboxColumn *ngIf=\"selectable.checkboxIsEnabled\"\n                                    [showSelectAll]=\"selectable.columnSettings.showSelectAll\"\n                                    [title]=\"selectable.columnSettings.title\"\n                                    [width]=\"selectable.columnSettings.width? selectable.columnSettings.width: 30 \"\n                                    [includeInChooser]=\"selectable.columnSettings.includeInChooser\"\n                                    [sticky]=\"selectable.columnSettings.sticky\"\n                                    [headerStyle]=\"{\n        'background-color': '#428BCA',\n        color: 'white'\n      }\">\n            <ng-template kendoGridHeaderTemplate>\n                <input *ngIf=\"selectable.columnSettings.showSelectAll\" type=\"checkbox\" kendoCheckBox\n                       id=\"selectAllCheckboxId\" kendoGridSelectAllCheckbox [state]=\"selectAllState\"\n                       (selectAllChange)=\"onSelectAllChange($event)\"\n                       [disabled]=\"selectable.selectable.disableAllcheckbox\"/>\n                <label class=\"k-checkbox-label\" for=\"selectAllCheckboxId\"></label>\n            </ng-template>\n            <ng-template kendoGridCellTemplate let-dataItem let-rowIndex=\"rowIndex\">\n                <input type=\"checkbox\" kendoCheckBox\n                       [kendoGridSelectionCheckbox]=\"rowIndex\"\n                       [disabled]=\"selectable.selectable.disableAllcheckbox\"/>\n            </ng-template>\n        </kendo-grid-checkbox-column>\n        <!-- [minResizableWidth]=\"20\" -->\n        <kendo-grid-command-column #CommandColumn [title]=\"dettagliColumn.title | transloco\" [width]=\"dettagliColumn.width\"\n                                   [sticky]=\"dettagliColumn.sticky\" *ngIf=\"showDettagliColumn\"\n                                   [headerStyle]=\"{ 'background-color': '#428BCA', color: 'white' }\">\n            <ng-template kendoGridCellTemplate let-isNew=\"isNew\" let-dataItem let-rowIndex=\"rowIndex\">\n                <div class=\"btn-group btn-sm divEditFull divDettagliColumn\" *ngIf=\"!isNew\" kendoTooltip>\n                    <!-- <button *ngIf=\"insideWindow.innerWidth > SMARTPHONE_WIDTH && dettagliColumn.editBtn\"\n                      class=\"btn btn-outline btn-edit-command btn-sm inlineBtnDisabledInModifica k-mr-2\" [type]=\"'button'\"\n                      [disabled]=\"inLineModificaIsDisabled\" size=\"small\" (click)=\"editBtnHandler(dataItem, isNew, rowIndex)\">\n                      {{ 'giasgrid.Modifica' | transloco }}\n                    </button> -->\n                    <button *ngIf=\"dettagliColumn.editBtn\" [title]=\"'giasgrid.Modifica' | transloco\"\n                            [disabled]=\"dettagliColumn.onDisableEditBtn(dataItem) || inLineModificaIsDisabled\"\n                            class=\"btn btn-outline btn-edit-command btn-sm inlineBtnDisabledInModifica k-mr-2\"\n                            [type]=\"'button'\"\n                            size=\"small\" (click)=\"editBtnHandler(dataItem, isNew, rowIndex)\">\n                        <fa-icon class=\"faEditFull\" aria-hidden=\"true\"></fa-icon>\n                    </button>\n\n                    <ng-container *ngIf=\"!isInEditMode\">\n                        <button type=\"button\" [id]=\"'infoBtn'\" (click)=\"infoCmdHandler(dataItem, isNew, rowIndex)\"\n                                *ngIf=\"cmdColumn.infoBtn\"\n                                [disabled]=\"cmdColumn.onDisableInfoBtn(dataItem) || inLineModificaIsDisabled\"\n                                class=\"btn btn-outline btn-inline-info btn-sm\" [title]=\"'giasgrid.Informazioni' | transloco\"\n                                size=\"small\"\n                                style=\"color: #5BC0DE;\">\n\n                            <div class=\"faGridRowIcon faInfo\"></div>\n                        </button>\n\n                    </ng-container>\n\n                </div>\n            </ng-template>\n        </kendo-grid-command-column>\n\n        <kendo-grid-command-column [title]=\"cmdColumn.title | transloco\" [width]=\"150\"\n                                   [minResizableWidth]=\"70\"\n                                   [sticky]=\"cmdColumn.sticky\" [media]=\"cmdColumn.media\" [ngClass]=\"'blue-header'\"\n                                   *ngIf=\"showCmdColumn || showCmdDDL\">\n            <ng-template kendoGridCellTemplate let-isNew=\"isNew\" let-dataItem let-rowIndex=\"rowIndex\">\n                <div class=\"row\">\n                    <div class=\"btn-group btn-sm\" kendoTooltip>\n                        <button type=\"button\" *ngIf=\"showCmdColumn && showEditButton(dataItem) && !isNew\" kendoGridEditCommand\n                                class=\"btn btn-primary increase-border btn-inline-edit btn-sm editBtn\" size=\"small\"\n                                look=\"flat\"\n                                [title]=\"cmdColumn.editBtnTitle | transloco\"\n                                [disabled]=\"cmdColumn.onDisableEditBtn(dataItem) ||inLineModificaIsDisabled\">\n                            <fa-icon size=\"lg\" [icon]=\"faEdit\">\n                            </fa-icon>\n                        </button>\n\n                        <button [id]=\"'btnDelete'\" type=\"button\"\n                                class=\"btn btn-danger increase-border btn-inline-delete btn-sm\"\n                                kendoGridRemoveCommand *ngIf=\"cmdColumn.removeBtn && showCmdColumn  && !isNew\"\n                                [disabled]=\"cmdColumn.onDisableRemoveBtn(dataItem) || inLineModificaIsDisabled\"\n                                size=\"small\"\n                                [title]=\"'giasgrid.Cancella' | transloco\" look=\"flat\"\n                                style=\"color: #D41E1A;\">\n                            <fa-icon size=\"lg\" [icon]=\"faDelete\">\n                            </fa-icon>\n                        </button>\n                        <div *ngIf=\"showCmdDdlButton(dataItem)\">\n                            <kendo-dropdownbutton fillMode=\"flat\" *ngIf=\"!inLineModificaIsDisabled\"\n                                                  [title]=\"'giasgrid.AltreAzioni' | transloco\"\n                                                  [data]=\"cmdDropDown.cmdList\"\n                                                  (open)=\"onOpenCommands(dataItem)\"\n                                                  (itemClick)=\"onCommand($event, dataItem, isNew, rowIndex)\">\n                                <fa-icon class=\"btn increase-border btn-outline btn-sm\" size=\"lg\"\n                                         [icon]=\"faDots\"></fa-icon>\n\n                                <ng-template kendoDropDownButtonItemTemplate let-ddlItem\n                                             class=\"transparentBg\">\n\n                                    <ng-container *ngIf=\"!ddlItem.fontawesomeIcon && ddlItem.iconClass !== ''\">\n                                      <div class=\"faGridRowIcon {{ ddlItem.iconClass }}\"></div>\n                                    </ng-container>\n\n\n                                    <ng-container *ngIf=\"ddlItem.fontawesomeIcon && ddlItem.iconClass === ''\">\n                                      <fa-icon [icon]=\"ddlItem.fontawesomeIcon\"></fa-icon>\n                                    </ng-container>\n\n\n                                    <span>{{ ButtonGridCommandName(ddlItem) }}</span>\n\n                                </ng-template>\n                            </kendo-dropdownbutton>\n                        </div>\n                    </div>\n                </div>\n                <ng-container>\n                    <div class=\"row\">\n                        <div class=\"btn-group btn-sm\" kendoTooltip>\n                            <button type=\"button\" class=\"btn btn-success btn-sm\" kendoGridSaveCommand\n                                    *ngIf=\"isNew\" size=\"small\" look=\"flat\" [title]=\"'giasgrid.Aggiungi' | transloco\">\n                                <fa-icon size=\"lg\" [icon]=\"isNew ? faSave: faSave \">\n                                </fa-icon>\n                            </button>\n                            <button type=\"button\" class=\"btn btn-success btn-sm\" kendoGridSaveCommand\n                                    *ngIf=\"!isNew\" size=\"small\" look=\"flat\" [title]=\"'giasgrid.Salva' | transloco\">\n                                <fa-icon size=\"lg\" [icon]=\"isNew ? faSave: faSave \">\n                                </fa-icon>\n                            </button>\n                            <button type=\"button\" class=\"btn btn-warning increase-border btn-sm\"\n                                    [title]=\"'giasgrid.Annulla' | transloco\" size=\"small\"\n                                    look=\"flat\" style=\"color: #D41E1A;\" kendoGridCancelCommand>\n                                <fa-icon size=\"lg\" [icon]=\"faCancel\">\n                                </fa-icon>\n                            </button>\n                        </div>\n                    </div>\n                </ng-container>\n            </ng-template>\n        </kendo-grid-command-column>\n\n        <kendo-grid-command-column\n            [title]=\"customColumn.title | transloco\"\n            [width]=\"customColumn.width\"\n            [sticky]=\"customColumn.sticky\"\n            *ngIf=\"showCustomColumn\"\n            [headerStyle]=\"customColumn.headerStyle\"\n        >\n\n          <ng-template kendoGridCellTemplate let-isNew=\"isNew\" let-dataItem=\"dataItem\" let-rowIndex=\"rowIndex\">\n            <ng-container [ngTemplateOutlet]=\"useCustomColumnCellTemplate() ? customCommandColumnCellTemplate : defaultCommandColumnTemplate\"\n                          [ngTemplateOutletContext]=\"{ dataItem: dataItem, isNew: isNew, rowIndex: rowIndex}\">\n            </ng-container>\n          </ng-template>\n\n          <ng-container *ngIf=\"useCustomColumnHeaderTemplate()\">\n            <ng-template kendoGridHeaderTemplate let-column=\"column\" let-columnIndex=\"columnIndex\">\n              <ng-container [ngTemplateOutlet]=\"customCommandColumnHeaderTemplate\"\n                            [ngTemplateOutletContext]=\"{ column: column, columnIndex: columnIndex}\">\n              </ng-container>\n            </ng-template>\n          </ng-container>\n\n\n\n            <ng-template #defaultCommandColumnTemplate let-isNew=\"isNew\" let-dataItem=\"dataItem\" let-rowIndex=\"rowIndex\">\n                <div class=\"btn-group btn-sm divEditFull\" *ngIf=\"showBtncustomColumn(isNew)\" kendoTooltip>\n                    <button\n                        [title]=\"customColumn.btnTooltip | transloco\"\n                        [disabled]=\"customColumn.onDisableActionBtn(dataItem) || inLineModificaIsDisabled\"\n                        class=\"btn btn-outline btn-edit-command btn-sm inlineBtnDisabledInModifica k-mr-2\"\n                        [type]=\"'button'\"\n                        size=\"small\"\n                        (click)=\"actionBtnHandler(dataItem, isNew, rowIndex)\"\n                    >\n                      <ng-container *ngIf=\"customColumn.btnIcon == '' && customColumn.fontawesomeIcon\">\n                        <fa-icon [icon]=\"customColumn.fontawesomeIcon\"></fa-icon>\n                      </ng-container>\n\n                      <ng-container *ngIf=\"customColumn.btnIcon !== '' && !customColumn.fontawesomeIcon\">\n                        <fa-icon [ngClass]=\"customColumn.btnIcon\" aria-hidden=\"true\"></fa-icon>\n                      </ng-container>\n\n                    </button>\n                </div>\n            </ng-template>\n        </kendo-grid-command-column>\n\n\n        <!--Riportare le modifiche fatte alle colonne nel gridColumnGroupTemplate e nel gridNoColumnGroupTemplate-->\n        <ng-container *ngFor=\"let group of columnGroups | keyvalue: defaultOrder\">\n\n          <ng-container  *ngIf=\"useColumnGroup(group)\"\n                         [ngTemplateOutlet]=\"gridColumnGroupTemplate\"\n                         [ngTemplateOutletContext]=\"{ group: group }\">\n          </ng-container>\n\n          <ng-container  *ngIf=\"!useColumnGroup(group)\"\n                         [ngTemplateOutlet]=\"gridNoColumnGroupTemplate\"\n                         [ngTemplateOutletContext]=\"{ group: group }\">\n          </ng-container>\n\n        </ng-container>\n\n\n       <!--Riportare le modifiche fatte alle colonne anche nel gridNoColumnGroupTemplate-->\n        <ng-template #gridColumnGroupTemplate let-group=\"group\">\n          <kendo-grid-column-group [title]=\"group.key\">\n\n            <kendo-grid-column *ngFor=\"let col of group.value;\n                          let i = index\"\n                               [editable]=\"col.editable\" [field]=\"col.field\" [title]=\"col.title\" [class]=\"col.class\"\n                               [width]=\"col.width\" [hidden]=\"col.hidden\" [filter]=\"col | filterType\" [format]=\"col.format\"\n                               [filterable]=\"col?.filterable === false ? false: true\"\n                               [includeInChooser]=\"col.includeInChooser\" [media]=\"col.media\" [sticky]=\"col.sticky\"\n                               [ngClass]=\"'blue-header'\" [style]=\"getColumnStyle(col)\" [footerStyle]=\"getColumnFooterStyle(col)\">\n\n              <ng-container *ngIf=\"col | cellType as cellType\">\n                <ng-template  kendoGridCellTemplate\n                              let-columnIndex=\"columnIndex\"  let-rowIndex=\"rowIndex\" let-dataItem=\"dataItem\" let-column=\"column\"\n                              *ngIf=\"showAgronicakendoGridCellTemplate(cellType,col)\">\n                  <ng-container [ngTemplateOutlet]=\"AgronicakendoGridCellTemplate\"\n                                [ngTemplateOutletContext]=\"{ cellType: cellType, dataItem: dataItem, col: col}\">\n                  </ng-container>\n\n                </ng-template>\n\n                <ng-template  kendoGridGroupHeaderTemplate\n                              let-group=\"group\" let-field=\"field\" let-value=\"value\" let-aggregates=\"aggregates\" let-index=\"index\" let-expanded=\"expanded\"\n                              *ngIf=\"showAgronicakendoGridGroupHeaderTemplate(cellType)\">\n\n                  <ng-container [ngTemplateOutlet]=\"AgronicakendoGridGroupHeaderTemplate\"\n                                [ngTemplateOutletContext]=\"{ group: group, field: field, value: value, aggregates: aggregates,index: index, expanded: expanded,  cellType: cellType, col: col}\">\n                  </ng-container>\n                </ng-template>\n\n\n                <ng-template  kendoGridFooterTemplate\n                              let-column=\"column\" let-columnIndex=\"columnIndex\"\n                              *ngIf=\"showAgronicakendoGridFooterTemplate(cellType)\">\n\n                  <ng-container [ngTemplateOutlet]=\"AgronicakendoGridFooterTemplate\"\n                                [ngTemplateOutletContext]=\"{ columnIndex: columnIndex, cellType: cellType, col: col, total:_calculateAggregatesTotal(rows, false, '', '') }\">\n                  </ng-container>\n                </ng-template>\n\n                <ng-template  kendoGridFilterMenuTemplate\n                              let-column=\"column\" let-filter=\"filter\" let-filterService=\"filterService\"\n                              *ngIf=\"showkendoGridFilterMenuTemplate(cellType, col)\">\n\n                    <ng-container *ngIf=\"showMultiCheckFilter(cellType, col)\">\n\n                        <gias-multicheck-filter [multiIndex]=\"privateService.multiIndex\" [type]=\"cellType\"\n                                           [isPrimitive]=\"true\"\n                                           [field]=\"col.field\" [filterService]=\"filterService\"\n                                           [currentFilter]=\"filter\"\n                                           [showHTMLAsString]=\"ShowHTMLAsString(cellType,col)\"\n                                           [ordering]=\"col.filterOrdering\"></gias-multicheck-filter>\n                    </ng-container>\n\n                  <ng-container *ngIf=\"showAgronicakendoGridFilterMenuTemplate(cellType)\"\n                                [ngTemplateOutlet]=\"AgronicakendoGridFilterMenuTemplate\"\n                                [ngTemplateOutletContext]=\"{ filter: filter,filterService: filterService, cellType: cellType, col: col}\">\n                  </ng-container>\n                </ng-template>\n\n                <ng-template  kendoGridEditTemplate\n                              let-formGroup=\"formGroup\" let-rowIndex=\"rowIndex\" let-dataItem=\"dataItem\" let-column=\"column\" let-isNew=\"isNew\"\n                              *ngIf=\"showAgronicakendoGridEditTemplate(cellType)\">\n                  <ng-container [ngTemplateOutlet]=\"AgronicakendoGridEditTemplate\"\n                                [ngTemplateOutletContext]=\"{ formGroup: formGroup,rowIndex: rowIndex,dataItem: dataItem, isNew: isNew, cellType: cellType, col: col}\">\n                  </ng-container>\n                </ng-template>\n\n              </ng-container>\n\n            </kendo-grid-column>\n\n          </kendo-grid-column-group>\n        </ng-template>\n\n        <!--Riportare le modifiche fatte alle colonne anche nel gridColumnGroupTemplate-->\n        <ng-template #gridNoColumnGroupTemplate let-group=\"group\">\n          <kendo-grid-column *ngFor=\"let col of group.value;\n                          let i = index\"\n                             [editable]=\"col.editable\" [field]=\"col.field\" [title]=\"col.title\" [class]=\"col.class\"\n                             [width]=\"col.width\" [hidden]=\"col.hidden\" [filter]=\"col | filterType\" [format]=\"col.format\"\n                             [filterable]=\"col?.filterable === false ? false: true\"\n                             [includeInChooser]=\"col.includeInChooser\" [media]=\"col.media\" [sticky]=\"col.sticky\"\n                             [ngClass]=\"'blue-header'\" [style]=\"getColumnStyle(col)\" [footerStyle]=\"getColumnFooterStyle(col)\">\n\n            <ng-container *ngIf=\"col | cellType as cellType\">\n              <ng-template  kendoGridCellTemplate\n                            let-columnIndex=\"columnIndex\"  let-rowIndex=\"rowIndex\" let-dataItem=\"dataItem\" let-column=\"column\"\n                            *ngIf=\"showAgronicakendoGridCellTemplate(cellType,col)\">\n                <ng-container [ngTemplateOutlet]=\"AgronicakendoGridCellTemplate\"\n                              [ngTemplateOutletContext]=\"{ cellType: cellType, dataItem: dataItem, col: col}\">\n                </ng-container>\n\n              </ng-template>\n\n              <ng-template  kendoGridGroupHeaderTemplate\n                            let-group=\"group\" let-field=\"field\" let-value=\"value\" let-aggregates=\"aggregates\" let-index=\"index\" let-expanded=\"expanded\"\n                            *ngIf=\"showAgronicakendoGridGroupHeaderTemplate(cellType)\">\n\n                <ng-container [ngTemplateOutlet]=\"AgronicakendoGridGroupHeaderTemplate\"\n                              [ngTemplateOutletContext]=\"{ group: group, field: field, value: value, aggregates: aggregates,index: index, expanded: expanded,  cellType: cellType, col: col}\">\n                </ng-container>\n              </ng-template>\n\n\n              <ng-template  kendoGridFooterTemplate\n                            let-column=\"column\" let-columnIndex=\"columnIndex\"\n                            *ngIf=\"showAgronicakendoGridFooterTemplate(cellType)\">\n\n                <ng-container [ngTemplateOutlet]=\"AgronicakendoGridFooterTemplate\"\n                              [ngTemplateOutletContext]=\"{ columnIndex: columnIndex, cellType: cellType, col: col, total:_calculateAggregatesTotal(rows, false, '', '')}\">\n                </ng-container>\n              </ng-template>\n\n              <ng-template  kendoGridGroupFooterTemplate\n                            let-aggregates=\"aggregates\" let-group=\"group\" let-field=\"field\" let-column=\"column\"\n                            *ngIf=\"showAgronicakendoGridFooterTemplate(cellType)\">\n                <ng-container [ngTemplateOutlet]=\"AgronicakendoGridGroupFooterTemplate\"\n                              [ngTemplateOutletContext]=\"{ cellType: cellType, col: col, total:_calculateAggregatesTotal(group.items, false, group.field, group.value), group: group}\">\n                </ng-container>\n\n              </ng-template>\n\n                <ng-template  kendoGridFilterMenuTemplate\n                              let-column=\"column\" let-filter=\"filter\" let-filterService=\"filterService\"\n                              *ngIf=\"showkendoGridFilterMenuTemplate(cellType, col)\">\n\n                    <ng-container\n                            *ngIf=\"showMultiCheckFilter(cellType, col)\">\n\n                        <gias-multicheck-filter [multiIndex]=\"privateService.multiIndex\" [type]=\"cellType\"\n                                           [isPrimitive]=\"true\"\n                                           [field]=\"col.field\" [filterService]=\"filterService\"\n                                           [currentFilter]=\"filter\"\n                                           [showHTMLAsString]=\"ShowHTMLAsString(cellType,col)\"\n                                           [ordering]=\"col.filterOrdering\"></gias-multicheck-filter>\n                    </ng-container>\n\n                    <ng-container *ngIf=\"showAgronicakendoGridFilterMenuTemplate(cellType)\"\n                                  [ngTemplateOutlet]=\"AgronicakendoGridFilterMenuTemplate\"\n                                  [ngTemplateOutletContext]=\"{ filter: filter,filterService: filterService, cellType: cellType, col: col}\">\n                    </ng-container>\n                </ng-template>\n\n              <ng-template  kendoGridEditTemplate\n                            let-formGroup=\"formGroup\" let-rowIndex=\"rowIndex\" let-dataItem=\"dataItem\" let-column=\"column\" let-isNew=\"isNew\"\n                             *ngIf=\"showAgronicakendoGridEditTemplate(cellType)\">\n                <ng-container [ngTemplateOutlet]=\"AgronicakendoGridEditTemplate\"\n                              [ngTemplateOutletContext]=\"{ formGroup: formGroup,rowIndex: rowIndex,dataItem: dataItem, isNew: isNew, cellType: cellType, col: col}\">\n                </ng-container>\n              </ng-template>\n\n            </ng-container>\n\n          </kendo-grid-column>\n        </ng-template>\n\n\n        <kendo-grid-excel *ngIf=\"behavior.excelSettings.enabled\" [fileName]=\"'Export.xlsx'\" [fetchData]=\"excelData\">\n        </kendo-grid-excel>\n\n        <kendo-grid-pdf *ngIf=\"behavior.pdfSettings.enabled\" [fileName]=\"config.gridId + '.pdf'\"\n                        [allPages]=\"behavior.pdfSettings.allPages\" paperSize=\"A4\" [repeatHeaders]=\"true\"\n                        [landscape]=\"true\">\n            <kendo-grid-pdf-margin top=\"2cm\" left=\"1cm\" right=\"1cm\" bottom=\"2cm\"></kendo-grid-pdf-margin>\n            <ng-template kendoGridPDFTemplate let-pageNum=\"pageNum\" let-totalPages=\"totalPages\">\n                <div class=\"page-template\">\n                    <div class=\"header\">\n                        <div style=\"float: right\">\n                            {{ \"giasgrid.Page\" | transloco }} {{ pageNum }} {{\"giasgrid.of\" | transloco}} {{ totalPages }}\n                        </div>\n                    </div>\n                    <!-- <div class=\"footer\">{{ \"giasgrid.Page\" | transloco }} {{ pageNum }} {{\"giasgrid.of\" | transloco}} {{ totalPages }}</div> -->\n                </div>\n            </ng-template>\n        </kendo-grid-pdf>\n\n        <ng-container *ngIf=\"ShowkendoGridDetailTemplate()\">\n            <ng-template\n                    kendoGridDetailTemplate\n                    let-dataItem\n                    let-rowIndex\n                    [kendoGridDetailTemplateShowIf]=\"masterdetailSettings.showDetailTemplate\">\n\n                <ng-container [ngTemplateOutlet]=\"masterdetailSettings.templateGridDetail\">\n                </ng-container>\n            </ng-template>\n        </ng-container>\n\n    </kendo-grid>\n</div>\n\n<ng-template #tooltipTemplate>\n    <span>{{ 'giasgrid.Ordina' | transloco }}</span>\n</ng-template>\n\n<!-- Celle nella modalit\u00E0 di visualizzazione -->\n<ng-template #AgronicakendoGridCellTemplate let-cellType=\"cellType\" let-dataItem=\"dataItem\" let-col=\"col\">\n  <ng-container *ngIf=\"cellType === DATE\">\n    {{ ((dataItem[col.field] | stringToDate: col)?.getTime() == AGRODATA_INIZIO.getTime() || (dataItem[col.field] | stringToDate: col)?.getTime() ==\n    AGRODATA_FINE.getTime()) ? (col.date?.placeholder ?? '') : ((dataItem[col.field] | stringToDate: col) | date:(col.date?.format ?? 'dd/MM/yyyy')) }}\n  </ng-container>\n\n  <ng-container *ngIf=\"cellType === DATETIME\">\n    {{ ((dataItem[col.field] | stringToDate: col)?.getTime() == AGRODATA_INIZIO.getTime() || (dataItem[col.field] | stringToDate: col)?.getTime() ==\n    AGRODATA_FINE.getTime()) ? (col.date?.placeholder ?? '') : ((dataItem[col.field] | stringToDate: col) | date:(col.date?.format ?? 'dd/MM/yyyy HH:mm:ss')) }}\n  </ng-container>\n\n  <ng-container *ngIf=\"cellType === NUMERIC\">\n    {{ dataItem[col.field] | formatNumber: col: null }}\n  </ng-container>\n\n  <ng-container *ngIf=\"cellType === DROPDOWNLIST\">\n    {{ dataItem | cellDropdownName:col }}\n  </ng-container>\n\n  <ng-container *ngIf=\"cellType === MULTI_DROPDOWNLIST\">\n    {{ dataItem | cellMultiDropdownName:col }}\n  </ng-container>\n\n  <ng-container *ngIf=\"ShowHTMLAsString(cellType,col)\">\n    <div [innerHtml]=\"dataItem[col.field]\"></div>\n  </ng-container>\n\n  <ng-container *ngIf=\"!ShowHTMLAsString(cellType,col) && cellType === STRING\">\n    {{ dataItem[col.field] }}\n  </ng-container>\n\n  <ng-container *ngIf=\"cellType === BOOLEAN\">\n    <gias-grid-boolean [defaultValue]=\"dataItem[col.field]\" [editable]=\"false\" [useCheckbox]=\"true\"\n    ></gias-grid-boolean>\n  </ng-container>\n\n  <ng-container *ngIf=\"cellType === CUSTOM\">\n    <gias-grid-custom [component]=\"col.component\" [input]=\"dataItem\" [field]=\"col.field\" [edit]=\"false\">\n    </gias-grid-custom>\n  </ng-container>\n</ng-template>\n\n<!-- GridGroupHeaderTemplate -->\n<ng-template #AgronicakendoGridGroupHeaderTemplate\n             let-group=\"group\" let-field=\"field\" let-value=\"value\" let-aggregates=\"aggregates\"\n             let-index=\"index\" let-expanded=\"expanded\" let-cellType=\"cellType\" let-col=\"col\">\n  <ng-container *ngIf=\"groups.groupable && (cellType === DROPDOWNLIST || cellType === MULTI_DROPDOWNLIST) \">\n    {{ group | groupHeaderName:col:field }}\n  </ng-container>\n</ng-template>\n\n<!-- GridFooterTemplate -->\n<ng-template #AgronicakendoGridFooterTemplate\n             let-columnIndex=\"columnIndex\" let-cellType=\"cellType\" let-col=\"col\" >\n  <ng-container *ngIf=\"\n                            aggregates.enabled &&\n                            cellType === NUMERIC\">\n    <ng-container *ngIf=\"col | aggrType as aggrType\">\n      <ng-container *ngIf=\"aggrType.show\" >\n          <ng-container *ngIf=\"aggrType.descriptor?.aggregate === 'sum'\">\n            {{\"giasgrid.Somma_Totale_Abbr\" | transloco}} {{ getAggregateResult(total.get(''), col, aggrType.descriptor?.aggregate) | formatNumber:col: aggrType.descriptor?.format}}\n          </ng-container>\n          <ng-container *ngIf=\"aggrType.descriptor?.aggregate === 'average'\">\n            {{\"giasgrid.Media\" | transloco}} {{getAggregateResult(total.get(''), col, aggrType.descriptor?.aggregate)  | formatNumber:col: aggrType.descriptor?.format}}\n          </ng-container>\n          <ng-container *ngIf=\"aggrType.descriptor?.aggregate === 'count'\">\n            {{\"giasgrid.Conteggio_Totale\" | transloco}} {{getAggregateResult(total.get(''), col, aggrType.descriptor?.aggregate)  | formatNumber:col: aggrType.descriptor?.format}}\n          </ng-container>\n          <ng-container *ngIf=\"aggrType.descriptor?.aggregate === 'max'\">\n            {{\"giasgrid.Massimo\" | transloco}} {{getAggregateResult(total.get(''), col, aggrType.descriptor?.aggregate)  | formatNumber:col: aggrType.descriptor?.format}}\n          </ng-container>\n          <ng-container  *ngIf=\"aggrType.descriptor?.aggregate === 'min'\">\n            {{\"giasgrid.Minimo\" | transloco}} {{getAggregateResult(total.get(''), col, aggrType.descriptor?.aggregate)  | formatNumber:col: aggrType.descriptor?.format}}\n          </ng-container>\n\n      </ng-container>\n\n    </ng-container>\n\n    <ng-container *ngIf=\"col?.customFooter != null\">\n      {{ col.customFooter(rows) }}\n    </ng-container>\n\n  </ng-container>\n</ng-template>\n\n<!-- GridGroupFooterTemplate -->\n<ng-template #AgronicakendoGridGroupFooterTemplate\n             let-cellType=\"cellType\" let-col=\"col\" let-total=\"total\" let-group=\"group\" style=\"'text-align': 'right'\" >\n  <ng-container *ngIf=\"aggregates.enabled && cellType === NUMERIC\">\n    <ng-container *ngIf=\"col | aggrType as aggrType\">\n      <ng-container *ngIf=\"aggrType.show\" >\n        <div style=\"text-align: right; font-weight: bold;\" >\n          <ng-container *ngIf=\"aggrType.descriptor?.aggregate === 'sum'\">\n            {{\"giasgrid.Somma_Totale_Abbr\" | transloco}} {{ getAggregateResult(total, col, aggrType.descriptor?.aggregate) | formatNumber:col: aggrType.descriptor?.format}}\n          </ng-container>\n          <ng-container *ngIf=\"aggrType.descriptor?.aggregate === 'average'\">\n            {{\"giasgrid.Media\" | transloco}} {{getAggregateResult(total, col, aggrType.descriptor?.aggregate)  | formatNumber:col: aggrType.descriptor?.format}}\n          </ng-container>\n          <ng-container *ngIf=\"aggrType.descriptor?.aggregate === 'count'\">\n            {{\"giasgrid.Conteggio_Totale\" | transloco}} {{getAggregateResult(total, col, aggrType.descriptor?.aggregate)  | formatNumber:col: aggrType.descriptor?.format}}\n          </ng-container>\n          <ng-container *ngIf=\"aggrType.descriptor?.aggregate === 'max'\">\n            {{\"giasgrid.Massimo\" | transloco}} {{getAggregateResult(total, col, aggrType.descriptor?.aggregate)  | formatNumber:col: aggrType.descriptor?.format}}\n          </ng-container>\n          <ng-container  *ngIf=\"aggrType.descriptor?.aggregate === 'min'\">\n            {{\"giasgrid.Minimo\" | transloco}} {{getAggregateResult(total, col, aggrType.descriptor?.aggregate)  | formatNumber:col: aggrType.descriptor?.format}}\n          </ng-container>\n        </div>\n      </ng-container>\n    </ng-container>\n\n    <ng-container *ngIf=\"col?.customFooter != null\">\n      {{ col.customFooter(rows) }}\n    </ng-container>\n\n  </ng-container>\n</ng-template>\n\n<!-- GridFilterMenuTemplate -->\n<ng-template #AgronicakendoGridFilterMenuTemplate\n             let-filter=\"filter\" let-filterService=\"filterService\"\n             let-cellType=\"cellType\" let-col=\"col\"\n></ng-template>\n\n<!-- Celle nella modalit\u00E0 di editing -->\n<ng-template #AgronicakendoGridEditTemplate\n             let-formGroup=\"formGroup\" let-rowIndex=\"rowIndex\" let-dataItem=\"dataItem\" let-isNew=\"isNew\" let-cellType=\"cellType\" let-col=\"col\">\n\n  <!-- getDate(dataItem, col) -->\n  <ng-container *ngIf=\"cellType === DATE\">\n    <kendo-datepicker #input [min]=\" (col.date) ? col.date?.min : AGRODATA_INIZIO\"\n                      [max]=\" (col.date) ? col.date?.max : AGRODATA_FINE\"\n                      [formControl]=\"formGroup.get(col.field)\"\n                      calendarType=\"classic\">\n    </kendo-datepicker>\n    <div *ngIf=\"formControls[col.field].touched && formControls[col.field].errors\"\n         class=\"k-tooltip-validation\">\n\n    </div>\n  </ng-container>\n\n\n  <ng-container *ngIf=\"cellType === DATETIME\">\n    <kendo-datetimepicker #input [min]=\" (col.date) ? col.date?.min : AGRODATA_INIZIO\"\n                      [max]=\" (col.date) ? col.date?.max : AGRODATA_FINE\"\n                      [formControl]=\"formGroup.get(col.field)\" calendarType=\"classic\">\n    </kendo-datetimepicker>\n    <div *ngIf=\"formControls[col.field].touched && formControls[col.field].errors\"\n         class=\"k-tooltip-validation\">\n\n    </div>\n  </ng-container>\n\n  <!-- *ngIf=\"cellType === NUMERIC && aggregates.enabled\" -->\n  <ng-container *ngIf=\"cellType === NUMERIC\">\n    <kendo-numerictextbox #input [formControl]=\"formGroup.get(col.field)\"\n                          [min]=\"col.numeric.min\" [max]=\"col.numeric.max\" [format]=\"col.numeric.format\"\n                          [spinners]=\"false\"\n                          [autoCorrect]=\"col.numeric.autoCorrect\"\n                          [decimals]=\"col.numeric.decimals\"\n                          [step]=\"col.numeric?.step ?? 0\"></kendo-numerictextbox>\n    <div *ngIf=\"formControls[col.field].touched && formControls[col.field].errors\"\n         class=\"k-tooltip-validation\">\n\n    </div>\n  </ng-container>\n\n  <ng-container *ngIf=\"cellType === DROPDOWNLIST\">\n    <gias-grid-ddl #input [column]=\"col\" [useForm]=\"true\" [id]=\"col.ddl.id\"\n                   [defaultItem]=\"col.ddl.defaultItem\"\n                   [source]=\"col.ddl.data\" [textField]=\"col.ddl.textField\"\n                   [valueField]=\"col.ddl.valueField\"\n                   [valuePrimitive]=\"col.ddl.valuePrimitive\" [filterable]=\"true\" [formGroup]=\"formGroup\"\n                   [controlName]=\"col.ddl.formControlName\" [ddl]=\"col.ddl\"\n                   (reload)=\"ddlReload($event, formGroup,col)\"\n                   (valueChange)=\"ddlStateChanged($event, formGroup, col)\"\n                   (open)=\"ddlOpenEvent($event, formGroup)\">\n    </gias-grid-ddl>\n    <div *ngIf=\"formControls[col.field].touched && formControls[col.field].errors\"\n         class=\"k-tooltip-validation\">\n\n    </div>\n  </ng-container>\n\n  <ng-container *ngIf=\"cellType === MULTI_DROPDOWNLIST\">\n    <gias-grid-multi-ddl #input [useForm]=\"true\" [id]=\"col.ddl.id\" [defaultItem]=\"col.ddl.defaultItem\"\n                         [source]=\"col.ddl.data\" [textField]=\"col.ddl.textField\"\n                         [valueField]=\"col.ddl.valueField\"\n                         [valuePrimitive]=\"col.ddl.valuePrimitive\" [filterable]=\"true\"\n                         [formGroup]=\"formGroup\"\n                         [controlName]=\"col.ddl.formControlName\" [ddl]=\"col.ddl\"\n                         [defaultOpen]=\"col.ddl.defaultOpen\"\n                         (reload)=\"onOpenReloadDDL($event, formGroup, true)\"\n                         (valueChange)=\"ddlStateChanged($event, formGroup, col)\"\n                         (open)=\"onOpenReloadDDL($event, formGroup, false)\">\n    </gias-grid-multi-ddl>\n    <div *ngIf=\"formControls[col.field].touched && formControls[col.field].errors\"\n         class=\"k-tooltip-validation\">\n\n    </div>\n  </ng-container>\n\n  <ng-container *ngIf=\"cellType === BOOLEAN\">\n    <gias-grid-boolean [editable]=\"true\" [useCheckbox]=\"true\"\n      [defaultValue]=\"dataItem[col.field]\"\n      [formGroup]=\"formGroup\" [controlName]=\"col.field\"\n    ></gias-grid-boolean>\n  </ng-container>\n\n  <ng-container *ngIf=\"cellType === CUSTOM\">\n    <gias-grid-custom [component]=\"col.component\" [field]=\"col.field\"\n                      [input]=\"dataItem\" [formGroup]=\"formGroup\"\n                      [edit]=\"true\"\n    ></gias-grid-custom>\n    <div *ngIf=\"formControls[col.field].touched && formControls[col.field].errors\"\n         class=\"k-tooltip-validation\">\n\n    </div>\n  </ng-container>\n\n</ng-template>\n", styles: [".footer-virtual-count{width:100%;display:flex;justify-content:flex-end;align-items:center}.footer-virtual-count p{text-align:right;font-size:.9rem;margin:0}.k-grid-toolbar-bottom:has(>.footer-virtual-empty){height:0px!important;padding:0!important}.btn:disabled{border:0px}.increase-border{margin-left:5px!important;margin-right:5px}:host ::ng-deep thead th{background-color:#428bca!important;color:#fff!important}:host ::ng-deep .k-grid-header .k-i-sort-asc-sm{color:#fff!important}:host ::ng-deep .k-grid-header .k-i-sort-desc-sm{color:#fff!important}#btnDelete,.editBtn,#infoBtn{max-width:45px}.pending-deletion-row{text-decoration:line-through;color:red}.batch-fixed-top{top:-6px}.breakWord120{word-break:break-all!important;word-wrap:break-word!important}.k-grid tbody td{white-space:wrap!important;line-height:20px!important;padding:8px 12px!important}multicheck-filter{align-self:center;width:100%}\n"], dependencies: [{ kind: "directive", type: i3.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: i3.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: i3.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: i3.NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "component", type: i11.GridComponent, selector: "kendo-grid", inputs: ["data", "pageSize", "height", "rowHeight", "detailRowHeight", "skip", "scrollable", "selectable", "sort", "size", "trackBy", "filter", "group", "virtualColumns", "filterable", "sortable", "pageable", "groupable", "rowReorderable", "navigable", "navigatable", "autoSize", "rowClass", "rowSticky", "rowSelected", "isRowSelectable", "cellSelected", "resizable", "reorderable", "loading", "columnMenu", "hideHeader", "isDetailExpanded", "isGroupExpanded"], outputs: ["filterChange", "pageChange", "groupChange", "sortChange", "selectionChange", "rowReorder", "dataStateChange", "groupExpand", "groupCollapse", "detailExpand", "detailCollapse", "edit", "cancel", "save", "remove", "add", "cellClose", "cellClick", "pdfExport", "excelExport", "columnResize", "columnReorder", "columnVisibilityChange", "columnLockedChange", "columnStickyChange", "scrollBottom", "contentScroll"], exportAs: ["kendoGrid"] }, { kind: "directive", type: i11.ToolbarTemplateDirective, selector: "[kendoGridToolbarTemplate]", inputs: ["position"] }, { kind: "directive", type: i11.SelectionDirective, selector: "[kendoGridSelectBy]" }, { kind: "directive", type: i11.GridToolbarFocusableDirective, selector: "        [kendoGridToolbarFocusable],        [kendoGridAddCommand],        [kendoGridCancelCommand],        [kendoGridEditCommand],        [kendoGridRemoveCommand],        [kendoGridSaveCommand],        [kendoGridExcelCommand],        [kendoGridPDFCommand]    " }, { kind: "directive", type: i11.GroupHeaderTemplateDirective, selector: "[kendoGridGroupHeaderTemplate]" }, { kind: "directive", type: i11.GroupFooterTemplateDirective, selector: "[kendoGridGroupFooterTemplate]" }, { kind: "component", type: i11.ColumnComponent, selector: "kendo-grid-column", inputs: ["field", "format", "sortable", "groupable", "editor", "filter", "filterable", "editable"] }, { kind: "component", type: i11.ColumnGroupComponent, selector: "kendo-grid-column-group" }, { kind: "directive", type: i11.FocusableDirective, selector: "[kendoGridFocusable],        [kendoGridEditCommand],        [kendoGridRemoveCommand],        [kendoGridSaveCommand],        [kendoGridCancelCommand],        [kendoGridSelectionCheckbox]    ", inputs: ["kendoGridFocusable"] }, { kind: "directive", type: i11.FooterTemplateDirective, selector: "[kendoGridFooterTemplate]" }, { kind: "directive", type: i11.DetailTemplateDirective, selector: "[kendoGridDetailTemplate]", inputs: ["kendoGridDetailTemplateShowIf"] }, { kind: "component", type: i11.CommandColumnComponent, selector: "kendo-grid-command-column" }, { kind: "component", type: i11.CheckboxColumnComponent, selector: "kendo-grid-checkbox-column", inputs: ["showSelectAll", "showDisabledCheckbox"] }, { kind: "directive", type: i11.SelectionCheckboxDirective, selector: "[kendoGridSelectionCheckbox]", inputs: ["kendoGridSelectionCheckbox"] }, { kind: "directive", type: i11.CellTemplateDirective, selector: "[kendoGridCellTemplate]" }, { kind: "directive", type: i11.EditTemplateDirective, selector: "[kendoGridEditTemplate]" }, { kind: "directive", type: i11.NoRecordsTemplateDirective, selector: "[kendoGridNoRecordsTemplate]" }, { kind: "component", type: i11.EditCommandDirective, selector: "[kendoGridEditCommand]" }, { kind: "component", type: i11.CancelCommandDirective, selector: "[kendoGridCancelCommand]" }, { kind: "component", type: i11.SaveCommandDirective, selector: "[kendoGridSaveCommand]" }, { kind: "component", type: i11.RemoveCommandDirective, selector: "[kendoGridRemoveCommand]" }, { kind: "component", type: i11.AddCommandDirective, selector: "[kendoGridAddCommand]" }, { kind: "directive", type: i11.HeaderTemplateDirective, selector: "[kendoGridHeaderTemplate]" }, { kind: "directive", type: i11.SelectAllCheckboxDirective, selector: "[kendoGridSelectAllCheckbox]", inputs: ["state"], outputs: ["selectAllChange"] }, { kind: "directive", type: i11.FilterMenuTemplateDirective, selector: "[kendoGridFilterMenuTemplate]" }, { kind: "component", type: i11.ColumnChooserComponent, selector: "kendo-grid-column-chooser", inputs: ["autoSync", "allowHideAll"] }, { kind: "component", type: i11.PDFComponent, selector: "kendo-grid-pdf", inputs: ["allPages", "delay"] }, { kind: "component", type: i11.PDFMarginComponent, selector: "kendo-grid-pdf-margin" }, { kind: "component", type: i11.PDFCommandDirective, selector: "[kendoGridPDFCommand]" }, { kind: "directive", type: i11.PDFTemplateDirective, selector: "[kendoGridPDFTemplate]" }, { kind: "component", type: i11.ExcelComponent, selector: "kendo-grid-excel", inputs: ["fileName", "filterable", "creator", "date", "forceProxy", "proxyURL", "fetchData", "paddingCellOptions", "headerPaddingCellOptions", "collapsible"] }, { kind: "component", type: i11.ExcelCommandDirective, selector: "[kendoGridExcelCommand]" }, { kind: "directive", type: i5.LabelDirective, selector: "label[for]", inputs: ["for", "labelClass"] }, { kind: "component", type: i13.ButtonComponent, selector: "button[kendoButton]", inputs: ["arrowIcon", "toggleable", "togglable", "selected", "tabIndex", "imageUrl", "iconClass", "icon", "disabled", "size", "rounded", "fillMode", "themeColor", "svgIcon", "primary", "look"], outputs: ["selectedChange", "click"], exportAs: ["kendoButton"] }, { kind: "component", type: i13.DropDownButtonComponent, selector: "kendo-dropdownbutton", inputs: ["arrowIcon", "icon", "svgIcon", "iconClass", "imageUrl", "textField", "data", "size", "rounded", "fillMode", "themeColor", "buttonAttributes"], outputs: ["itemClick", "focus", "blur"], exportAs: ["kendoDropDownButton"] }, { kind: "directive", type: i13.ButtonItemTemplateDirective, selector: "[kendoDropDownButtonItemTemplate],[kendoSplitButtonItemTemplate]" }, { kind: "component", type: i14.NumericTextBoxComponent, selector: "kendo-numerictextbox", inputs: ["focusableId", "disabled", "readonly", "title", "autoCorrect", "format", "max", "min", "decimals", "placeholder", "step", "spinners", "rangeValidation", "tabindex", "tabIndex", "changeValueOnScroll", "selectOnFocus", "value", "maxlength", "size", "rounded", "fillMode", "inputAttributes"], outputs: ["valueChange", "focus", "blur", "inputFocus", "inputBlur"], exportAs: ["kendoNumericTextBox"] }, { kind: "directive", type: i14.CheckBoxDirective, selector: "input[kendoCheckBox]", inputs: ["size", "rounded"] }, { kind: "component", type: i15.DatePickerComponent, selector: "kendo-datepicker", inputs: ["focusableId", "cellTemplate", "clearButton", "inputAttributes", "monthCellTemplate", "yearCellTemplate", "decadeCellTemplate", "centuryCellTemplate", "weekNumberTemplate", "headerTitleTemplate", "headerTemplate", "footerTemplate", "footer", "navigationItemTemplate", "weekDaysFormat", "showOtherMonthDays", "activeView", "bottomView", "topView", "calendarType", "animateCalendarNavigation", "disabled", "readonly", "readOnlyInput", "popupSettings", "navigation", "min", "max", "incompleteDateValidation", "autoCorrectParts", "autoSwitchParts", "autoSwitchKeys", "enableMouseWheel", "allowCaretMode", "autoFill", "focusedDate", "value", "format", "twoDigitYearMax", "formatPlaceholder", "placeholder", "tabindex", "tabIndex", "disabledDates", "title", "subtitle", "rangeValidation", "disabledDatesValidation", "weekNumber", "size", "rounded", "fillMode", "adaptiveMode"], outputs: ["valueChange", "focus", "blur", "open", "close", "escape"], exportAs: ["kendo-datepicker"] }, { kind: "component", type: i15.DateTimePickerComponent, selector: "kendo-datetimepicker", inputs: ["focusableId", "weekDaysFormat", "showOtherMonthDays", "value", "format", "twoDigitYearMax", "tabindex", "disabledDates", "popupSettings", "title", "subtitle", "disabled", "readonly", "readOnlyInput", "cancelButton", "formatPlaceholder", "placeholder", "steps", "focusedDate", "calendarType", "animateCalendarNavigation", "weekNumber", "min", "max", "rangeValidation", "disabledDatesValidation", "incompleteDateValidation", "autoCorrectParts", "autoSwitchParts", "autoSwitchKeys", "enableMouseWheel", "allowCaretMode", "clearButton", "autoFill", "adaptiveMode", "inputAttributes", "defaultTab", "size", "rounded", "fillMode", "headerTemplate", "footerTemplate", "footer"], outputs: ["valueChange", "open", "close", "focus", "blur", "escape"], exportAs: ["kendo-datetimepicker"] }, { kind: "directive", type: i2$2.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i2$2.NgControlStatusGroup, selector: "[formGroupName],[formArrayName],[ngModelGroup],[formGroup],form:not([ngNoForm]),[ngForm]" }, { kind: "directive", type: i2$2.FormControlDirective, selector: "[formControl]", inputs: ["formControl", "disabled", "ngModel"], outputs: ["ngModelChange"], exportAs: ["ngForm"] }, { kind: "directive", type: i2$2.FormGroupDirective, selector: "[formGroup]", inputs: ["formGroup"], outputs: ["ngSubmit"], exportAs: ["ngForm"] }, { kind: "component", type: i7.FaIconComponent, selector: "fa-icon", inputs: ["icon", "title", "animation", "mask", "flip", "size", "pull", "border", "inverse", "symbol", "rotate", "fixedWidth", "transform", "a11yRole"] }, { kind: "directive", type: i7$1.TooltipDirective, selector: "[kendoTooltip]", inputs: ["filter", "position", "titleTemplate", "showOn", "showAfter", "callout", "closable", "offset", "tooltipWidth", "tooltipHeight", "tooltipClass", "tooltipContentClass", "collision", "closeTitle", "tooltipTemplate"], exportAs: ["kendoTooltip"] }, { kind: "component", type: GridMultiDropdownComponent, selector: "gias-grid-multi-ddl", inputs: ["useForm", "id", "filterable", "defaultItem", "textField", "valueField", "valuePrimitive", "controlName", "formGroup", "selected", "ddl", "defaultOpen", "source"], outputs: ["valueChange", "open", "reload", "sourceChange"] }, { kind: "component", type: GridDropdownListComponent, selector: "gias-grid-ddl", inputs: ["useForm", "column", "id", "filterable", "defaultItem", "textField", "valueField", "valuePrimitive", "controlName", "formGroup", "selected", "ddl", "source"], outputs: ["selectedChange", "valueChange", "open", "reload", "sourceChange"] }, { kind: "component", type: MultiCheckFilterComponent, selector: "gias-multicheck-filter", inputs: ["type", "isPrimitive", "currentFilter", "textField", "valueField", "filterService", "field", "multiIndex", "showHTMLAsString", "ordering"], outputs: ["valueChange"] }, { kind: "component", type: GridCustomizationsComponent, selector: "gias-grid-customizations", inputs: ["canApplyChanges", "options", "showSwitch", "selectedDDLItem"], outputs: ["canApplyChangesChange", "applyView"] }, { kind: "component", type: GridCustomComponent, selector: "gias-grid-custom", inputs: ["component", "input", "field", "edit", "formGroup"] }, { kind: "component", type: GridBooleanComponent, selector: "gias-grid-boolean", inputs: ["formGroup", "controlName", "defaultValue", "editable", "useCheckbox"], outputs: ["valueChange"] }, { kind: "pipe", type: i3.AsyncPipe, name: "async" }, { kind: "pipe", type: i3.DatePipe, name: "date" }, { kind: "pipe", type: i3.KeyValuePipe, name: "keyvalue" }, { kind: "pipe", type: i1$1.TranslocoPipe, name: "transloco" }, { kind: "pipe", type: CellTypePipe, name: "cellType" }, { kind: "pipe", type: CellDropdownNamePipe, name: "cellDropdownName" }, { kind: "pipe", type: CellMultiDropdownNamePipe, name: "cellMultiDropdownName" }, { kind: "pipe", type: GroupHeaderNamePipe, name: "groupHeaderName" }, { kind: "pipe", type: AggregateTypePipe, name: "aggrType" }, { kind: "pipe", type: StringToDatePipe, name: "stringToDate" }, { kind: "pipe", type: FormatNumberPipe, name: "formatNumber" }, { kind: "pipe", type: FilterTypePipe, name: "filterType" }], viewProviders: [{ provide: ControlContainer, useExisting: FormGroupDirective },], encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: GiasKendoGridComponent, decorators: [{
            type: Component,
            args: [{ standalone: false, selector: 'gias-kendo-grid', viewProviders: [{ provide: ControlContainer, useExisting: FormGroupDirective },], providers: [
                        GridCustomizationsService,
                        GridDropdownService,
                        DatePipe,
                        CustomizeDropdownService,
                        GridWorkerService,
                        GridBatchHandlerService
                    ], encapsulation: ViewEncapsulation.None, template: "<div kendoTooltip [tooltipTemplate]=\"tooltipTemplate\" filter=\".k-grid .k-header\"\n     showOn=\"none\" (mouseover)=\"showTooltip($event)\">\n\n    <!-- Note: the option 'columnMenu=true' causes issues involving unwanted\n    horizontal scrolling when changing the state of the grid. -->\n\n    <!-- [rowSelected]=\"selectable.preselectedRows.isRowSelectedFn ? isRowSelected: null\" -->\n    <!-- [height]=\"generalSettings.height\" -->\n    <!-- (selectedKeysChange)=\"keyChange($event)\" -->\n    <!-- [rowSelected]=\"selectable.preselectedRows.isRowSelectedFn ? isRowSelected: null\" -->\n    <!-- (selectedKeysChange)=\"onSelectedKeysChange($event)\" -->\n    <kendo-grid #grid [id]=\"config.gridId\" [data]=\"view | async\" (cellClick)=\"cellClickHandler($event)\"\n                (cellClose)=\"cellCloseHandler($event)\" [selectable]=\"selectable.selectable\" [kendoGridSelectBy]=\"rowId\"\n                (selectedKeysChange)=\"onSelectedKeysChange($event)\" (selectionChange)=\"onSelectionChange($event)\"\n                (dataStateChange)=\"onStateChange($event)\" [resizable]=\"resizable.isResizable\"\n                [rowSelected]=\"isRowSelected\"\n                [reorderable]=\"generalSettings.reordable\" (columnResize)=\"views.enabled && onColumnResize()\"\n                (edit)=\"editHandler($event)\" (cancel)=\"cancelHandler($event)\" (save)=\"saveHandler($event)\"\n                (remove)=\"removeHandler($event)\" (add)=\"addHandler($event)\" [sortable]=\"sort.sortable ?? false\"\n                [sort]=\"pagination.gridState.sort\" [pageable]=\"pagination.pageable\"\n                [skip]=\"pagination.gridState.skip\" [navigable]=\"pagination.navigable\" (pageChange)=\"pageChange($event)\"\n                [groupable]=\"groups.groupable\" [group]=\"pagination.gridState.group\" [columnMenu]=\"false\"\n                [filterable]=\"$any(columnMenu.filterable)\" [filter]=\"pagination.gridState.filter\"\n                (columnVisibilityChange)=\"columnVisibilityChangeHandler($event)\"\n                (columnReorder)=\"applyColumnReorderPolicy($event)\"\n                [rowClass]=\"rowClassCallback.bind(this)\"\n                [style.height]=\"generalSettings.height\"\n                [height]=\"pagination?.virtualScrolling?.viewportHeight\"\n                [scrollable]=\"pagination.scrollingType\"\n                [rowHeight]=\"currentScrollingMode?.rowHeight\"\n                [pageSize]=\"currentScrollingMode?.pageSize\"\n                (detailCollapse)=\"detailMasterRowCollapse($event)\"\n                (detailExpand)=\"detailMasterRowExpand($event)\"\n                (sortChange)=\"sortChange($event)\">\n\n\n        <ng-template *ngIf=\"showToolbar\" kendoGridToolbarTemplate position=\"both\" let-position=\"position\">\n            <ng-container *ngIf=\"position == 'top'\">\n              <ng-container class=\"row\">\n                  <ng-content select=\"[toolbarStart]\">\n\n                  </ng-content>\n\n                  <span class=\"separator\"></span>\n                  <div class=\"gias-toolbar-section\">\n                      <div kendoTooltip *ngIf=\"behavior.excelSettings.enabled\">\n                          <button size=\"small\" type=\"button\" class=\"k-button\" kendoGridExcelCommand icon=\"file-excel\"\n                                  [title]=\"'giasgrid.Export_Excel' | transloco\">\n                          </button>\n                      </div>\n\n                      <div kendoTooltip *ngIf=\"behavior.pdfSettings.enabled\">\n                          <button size=\"small\" type=\"button\" class=\"k-button\" kendoGridPDFCommand icon=\"file-pdf\"\n                                  [title]=\"'giasgrid.Export_PDF' | transloco\">\n                          </button>\n                      </div>\n\n                      <button *ngIf=\"editingMode === IN_CELL && generalSettings.performOnEdit == false && toolbar.SaveBtn\"\n                              class=\"k-button grid-toolbar-button btn-primary-fill\"\n                              size=\"small\"\n                              [disabled]=\"!gridServices.incellHasChanges()\" (click)=\"saveChanges(grid)\">\n                          <div *ngIf=\"toolbar.title_save_button === '';else custom_title_save_button\">\n                              {{ 'giasgrid.Save_Changes' | transloco }}\n                          </div>\n                          <ng-template #custom_title_save_button>\n                              {{ toolbar.title_save_button }}\n                          </ng-template>\n                      </button>\n\n                      <button *ngIf=\"toolbar.resetChanges\" kendoButton class=\"grid-toolbar-button\" size=\"small\" (click)=\"resetHandler()\">\n                          {{ 'giasgrid.Annulla_Modifiche' | transloco }}\n                      </button>\n                  </div>\n\n                  <ng-content select=\"[headerContent]\">\n                      <!-- Content to be included by the user. -->\n                  </ng-content>\n                  <div class=\"spacer\"></div>\n                  <ng-container *ngIf=\"views.enabled\">\n\n                      <gias-grid-customizations class=\"ms-auto p-2 bd-highlight\" [options]=\"views\"\n                                          [(canApplyChanges)]=\"customizationViewChanged\" (applyView)=\"applyView($event)\"\n                                          [showSwitch]=\"showSwitchViewsPrivatePublic\">\n                          <kendo-grid-column-chooser kendoTooltip *ngIf=\"columnMenu.kendoGridColumnChooser\" end>\n                          </kendo-grid-column-chooser>\n                      </gias-grid-customizations>\n\n                  </ng-container>\n\n                  <ng-container *ngIf=\"!views.enabled\">\n                      <div class=\"ms-auto p-2 bd-highlight\"></div>\n                  </ng-container>\n\n                  <span *ngIf=\"views.enabled\" class=\"separator must-show\"></span>\n\n                  <ng-container *ngIf=\"filterableGrid()\">\n                      <div kendoTooltip class=\"gias-button-esercizi\">\n                          <button kendoButton type=\"button\" class=\"k-button\" (click)=\"resetFilter()\" icon=\"filter-funnel\"\n                                  [title]=\"'giasgrid.PulisciFiltri' | transloco\">\n                          </button>\n                      </div>\n                  </ng-container>\n\n                  <div class=\"gias-toolbar-section full-width-section\">\n                      <span *ngIf=\"views.enabled\" class=\"separator must-show\"></span>\n                      <ng-content select=\"[headerContentButtons]\">\n                      </ng-content>\n                  </div>\n                  <div class=\"gias-toolbar-section full-width-section\">\n                      <div kendoTooltip *ngIf=\"toolbar.newItem\" class=\"gias-new-item-rapid-button\">\n                          <button [title]=\"'giasgrid.NuovaSchedaRapida' | transloco\" size=\"small\" kendoGridAddCommand\n                                  class=\"btnDisabledInModifica btn-primary-fill btn-important\">\n                              <fa-icon class=\"faAddRowSingle\"></fa-icon>\n                          </button>\n                      </div>\n\n                      <div kendoTooltip *ngIf=\"editingMode == IN_LINE_BATCH || editingMode == IN_CELL_BATCH\">\n                          <button size=\"small\" [title]=\"'giasgrid.Salva' | transloco\" class=\"btn btn-primary-fill btn-important\"\n                              [disabled]=\"!hasBatchChanges\" (click)=\"batchSave()\">\n                              <fa-icon class=\"lg\" [icon]=\"faCircleSave\"></fa-icon>\n                          </button>\n                      </div>\n\n                      <ng-content select=\"[headerContentEnd]\">\n                          <!-- Content to be included by the user. -->\n                      </ng-content>\n                  </div>\n              </ng-container>\n              <ng-container class=\"row\">\n                  <div class=\"gias-toolbar-section full-width-section\">\n                      <ng-content select=\"[headerSecondLine]\">\n                          <!-- Content to be included by the user. -->\n                      </ng-content>\n                  </div>\n              </ng-container>\n            </ng-container>\n\n            <ng-container *ngIf=\"position == 'bottom'\">\n              <!-- THIS CAN BE USED AS A GENERIC FOOTER FOR THE WHOLE KENDO GRID -->\n              <div *ngIf=\"currentScrollingMode.isVirtual()\" class=\"footer-virtual-count\">\n                <p>{{ 'giasgrid.TotaleXElementi' | transloco: { count: currentScrollingMode.totalCount } }}</p>\n              </div>\n\n              <div *ngIf=\"!currentScrollingMode.isVirtual()\" class=\"footer-virtual-empty\">\n                <!-- This removes any extra space when footer is not needed -->\n              </div>\n            </ng-container>\n          </ng-template>\n\n        <ng-template kendoGridNoRecordsTemplate>\n          <ng-container *ngTemplateOutlet=\"noRecordsTemplateRef;\">\n          </ng-container>\n        </ng-template>\n\n        <kendo-grid-checkbox-column #CheckboxColumn *ngIf=\"selectable.checkboxIsEnabled\"\n                                    [showSelectAll]=\"selectable.columnSettings.showSelectAll\"\n                                    [title]=\"selectable.columnSettings.title\"\n                                    [width]=\"selectable.columnSettings.width? selectable.columnSettings.width: 30 \"\n                                    [includeInChooser]=\"selectable.columnSettings.includeInChooser\"\n                                    [sticky]=\"selectable.columnSettings.sticky\"\n                                    [headerStyle]=\"{\n        'background-color': '#428BCA',\n        color: 'white'\n      }\">\n            <ng-template kendoGridHeaderTemplate>\n                <input *ngIf=\"selectable.columnSettings.showSelectAll\" type=\"checkbox\" kendoCheckBox\n                       id=\"selectAllCheckboxId\" kendoGridSelectAllCheckbox [state]=\"selectAllState\"\n                       (selectAllChange)=\"onSelectAllChange($event)\"\n                       [disabled]=\"selectable.selectable.disableAllcheckbox\"/>\n                <label class=\"k-checkbox-label\" for=\"selectAllCheckboxId\"></label>\n            </ng-template>\n            <ng-template kendoGridCellTemplate let-dataItem let-rowIndex=\"rowIndex\">\n                <input type=\"checkbox\" kendoCheckBox\n                       [kendoGridSelectionCheckbox]=\"rowIndex\"\n                       [disabled]=\"selectable.selectable.disableAllcheckbox\"/>\n            </ng-template>\n        </kendo-grid-checkbox-column>\n        <!-- [minResizableWidth]=\"20\" -->\n        <kendo-grid-command-column #CommandColumn [title]=\"dettagliColumn.title | transloco\" [width]=\"dettagliColumn.width\"\n                                   [sticky]=\"dettagliColumn.sticky\" *ngIf=\"showDettagliColumn\"\n                                   [headerStyle]=\"{ 'background-color': '#428BCA', color: 'white' }\">\n            <ng-template kendoGridCellTemplate let-isNew=\"isNew\" let-dataItem let-rowIndex=\"rowIndex\">\n                <div class=\"btn-group btn-sm divEditFull divDettagliColumn\" *ngIf=\"!isNew\" kendoTooltip>\n                    <!-- <button *ngIf=\"insideWindow.innerWidth > SMARTPHONE_WIDTH && dettagliColumn.editBtn\"\n                      class=\"btn btn-outline btn-edit-command btn-sm inlineBtnDisabledInModifica k-mr-2\" [type]=\"'button'\"\n                      [disabled]=\"inLineModificaIsDisabled\" size=\"small\" (click)=\"editBtnHandler(dataItem, isNew, rowIndex)\">\n                      {{ 'giasgrid.Modifica' | transloco }}\n                    </button> -->\n                    <button *ngIf=\"dettagliColumn.editBtn\" [title]=\"'giasgrid.Modifica' | transloco\"\n                            [disabled]=\"dettagliColumn.onDisableEditBtn(dataItem) || inLineModificaIsDisabled\"\n                            class=\"btn btn-outline btn-edit-command btn-sm inlineBtnDisabledInModifica k-mr-2\"\n                            [type]=\"'button'\"\n                            size=\"small\" (click)=\"editBtnHandler(dataItem, isNew, rowIndex)\">\n                        <fa-icon class=\"faEditFull\" aria-hidden=\"true\"></fa-icon>\n                    </button>\n\n                    <ng-container *ngIf=\"!isInEditMode\">\n                        <button type=\"button\" [id]=\"'infoBtn'\" (click)=\"infoCmdHandler(dataItem, isNew, rowIndex)\"\n                                *ngIf=\"cmdColumn.infoBtn\"\n                                [disabled]=\"cmdColumn.onDisableInfoBtn(dataItem) || inLineModificaIsDisabled\"\n                                class=\"btn btn-outline btn-inline-info btn-sm\" [title]=\"'giasgrid.Informazioni' | transloco\"\n                                size=\"small\"\n                                style=\"color: #5BC0DE;\">\n\n                            <div class=\"faGridRowIcon faInfo\"></div>\n                        </button>\n\n                    </ng-container>\n\n                </div>\n            </ng-template>\n        </kendo-grid-command-column>\n\n        <kendo-grid-command-column [title]=\"cmdColumn.title | transloco\" [width]=\"150\"\n                                   [minResizableWidth]=\"70\"\n                                   [sticky]=\"cmdColumn.sticky\" [media]=\"cmdColumn.media\" [ngClass]=\"'blue-header'\"\n                                   *ngIf=\"showCmdColumn || showCmdDDL\">\n            <ng-template kendoGridCellTemplate let-isNew=\"isNew\" let-dataItem let-rowIndex=\"rowIndex\">\n                <div class=\"row\">\n                    <div class=\"btn-group btn-sm\" kendoTooltip>\n                        <button type=\"button\" *ngIf=\"showCmdColumn && showEditButton(dataItem) && !isNew\" kendoGridEditCommand\n                                class=\"btn btn-primary increase-border btn-inline-edit btn-sm editBtn\" size=\"small\"\n                                look=\"flat\"\n                                [title]=\"cmdColumn.editBtnTitle | transloco\"\n                                [disabled]=\"cmdColumn.onDisableEditBtn(dataItem) ||inLineModificaIsDisabled\">\n                            <fa-icon size=\"lg\" [icon]=\"faEdit\">\n                            </fa-icon>\n                        </button>\n\n                        <button [id]=\"'btnDelete'\" type=\"button\"\n                                class=\"btn btn-danger increase-border btn-inline-delete btn-sm\"\n                                kendoGridRemoveCommand *ngIf=\"cmdColumn.removeBtn && showCmdColumn  && !isNew\"\n                                [disabled]=\"cmdColumn.onDisableRemoveBtn(dataItem) || inLineModificaIsDisabled\"\n                                size=\"small\"\n                                [title]=\"'giasgrid.Cancella' | transloco\" look=\"flat\"\n                                style=\"color: #D41E1A;\">\n                            <fa-icon size=\"lg\" [icon]=\"faDelete\">\n                            </fa-icon>\n                        </button>\n                        <div *ngIf=\"showCmdDdlButton(dataItem)\">\n                            <kendo-dropdownbutton fillMode=\"flat\" *ngIf=\"!inLineModificaIsDisabled\"\n                                                  [title]=\"'giasgrid.AltreAzioni' | transloco\"\n                                                  [data]=\"cmdDropDown.cmdList\"\n                                                  (open)=\"onOpenCommands(dataItem)\"\n                                                  (itemClick)=\"onCommand($event, dataItem, isNew, rowIndex)\">\n                                <fa-icon class=\"btn increase-border btn-outline btn-sm\" size=\"lg\"\n                                         [icon]=\"faDots\"></fa-icon>\n\n                                <ng-template kendoDropDownButtonItemTemplate let-ddlItem\n                                             class=\"transparentBg\">\n\n                                    <ng-container *ngIf=\"!ddlItem.fontawesomeIcon && ddlItem.iconClass !== ''\">\n                                      <div class=\"faGridRowIcon {{ ddlItem.iconClass }}\"></div>\n                                    </ng-container>\n\n\n                                    <ng-container *ngIf=\"ddlItem.fontawesomeIcon && ddlItem.iconClass === ''\">\n                                      <fa-icon [icon]=\"ddlItem.fontawesomeIcon\"></fa-icon>\n                                    </ng-container>\n\n\n                                    <span>{{ ButtonGridCommandName(ddlItem) }}</span>\n\n                                </ng-template>\n                            </kendo-dropdownbutton>\n                        </div>\n                    </div>\n                </div>\n                <ng-container>\n                    <div class=\"row\">\n                        <div class=\"btn-group btn-sm\" kendoTooltip>\n                            <button type=\"button\" class=\"btn btn-success btn-sm\" kendoGridSaveCommand\n                                    *ngIf=\"isNew\" size=\"small\" look=\"flat\" [title]=\"'giasgrid.Aggiungi' | transloco\">\n                                <fa-icon size=\"lg\" [icon]=\"isNew ? faSave: faSave \">\n                                </fa-icon>\n                            </button>\n                            <button type=\"button\" class=\"btn btn-success btn-sm\" kendoGridSaveCommand\n                                    *ngIf=\"!isNew\" size=\"small\" look=\"flat\" [title]=\"'giasgrid.Salva' | transloco\">\n                                <fa-icon size=\"lg\" [icon]=\"isNew ? faSave: faSave \">\n                                </fa-icon>\n                            </button>\n                            <button type=\"button\" class=\"btn btn-warning increase-border btn-sm\"\n                                    [title]=\"'giasgrid.Annulla' | transloco\" size=\"small\"\n                                    look=\"flat\" style=\"color: #D41E1A;\" kendoGridCancelCommand>\n                                <fa-icon size=\"lg\" [icon]=\"faCancel\">\n                                </fa-icon>\n                            </button>\n                        </div>\n                    </div>\n                </ng-container>\n            </ng-template>\n        </kendo-grid-command-column>\n\n        <kendo-grid-command-column\n            [title]=\"customColumn.title | transloco\"\n            [width]=\"customColumn.width\"\n            [sticky]=\"customColumn.sticky\"\n            *ngIf=\"showCustomColumn\"\n            [headerStyle]=\"customColumn.headerStyle\"\n        >\n\n          <ng-template kendoGridCellTemplate let-isNew=\"isNew\" let-dataItem=\"dataItem\" let-rowIndex=\"rowIndex\">\n            <ng-container [ngTemplateOutlet]=\"useCustomColumnCellTemplate() ? customCommandColumnCellTemplate : defaultCommandColumnTemplate\"\n                          [ngTemplateOutletContext]=\"{ dataItem: dataItem, isNew: isNew, rowIndex: rowIndex}\">\n            </ng-container>\n          </ng-template>\n\n          <ng-container *ngIf=\"useCustomColumnHeaderTemplate()\">\n            <ng-template kendoGridHeaderTemplate let-column=\"column\" let-columnIndex=\"columnIndex\">\n              <ng-container [ngTemplateOutlet]=\"customCommandColumnHeaderTemplate\"\n                            [ngTemplateOutletContext]=\"{ column: column, columnIndex: columnIndex}\">\n              </ng-container>\n            </ng-template>\n          </ng-container>\n\n\n\n            <ng-template #defaultCommandColumnTemplate let-isNew=\"isNew\" let-dataItem=\"dataItem\" let-rowIndex=\"rowIndex\">\n                <div class=\"btn-group btn-sm divEditFull\" *ngIf=\"showBtncustomColumn(isNew)\" kendoTooltip>\n                    <button\n                        [title]=\"customColumn.btnTooltip | transloco\"\n                        [disabled]=\"customColumn.onDisableActionBtn(dataItem) || inLineModificaIsDisabled\"\n                        class=\"btn btn-outline btn-edit-command btn-sm inlineBtnDisabledInModifica k-mr-2\"\n                        [type]=\"'button'\"\n                        size=\"small\"\n                        (click)=\"actionBtnHandler(dataItem, isNew, rowIndex)\"\n                    >\n                      <ng-container *ngIf=\"customColumn.btnIcon == '' && customColumn.fontawesomeIcon\">\n                        <fa-icon [icon]=\"customColumn.fontawesomeIcon\"></fa-icon>\n                      </ng-container>\n\n                      <ng-container *ngIf=\"customColumn.btnIcon !== '' && !customColumn.fontawesomeIcon\">\n                        <fa-icon [ngClass]=\"customColumn.btnIcon\" aria-hidden=\"true\"></fa-icon>\n                      </ng-container>\n\n                    </button>\n                </div>\n            </ng-template>\n        </kendo-grid-command-column>\n\n\n        <!--Riportare le modifiche fatte alle colonne nel gridColumnGroupTemplate e nel gridNoColumnGroupTemplate-->\n        <ng-container *ngFor=\"let group of columnGroups | keyvalue: defaultOrder\">\n\n          <ng-container  *ngIf=\"useColumnGroup(group)\"\n                         [ngTemplateOutlet]=\"gridColumnGroupTemplate\"\n                         [ngTemplateOutletContext]=\"{ group: group }\">\n          </ng-container>\n\n          <ng-container  *ngIf=\"!useColumnGroup(group)\"\n                         [ngTemplateOutlet]=\"gridNoColumnGroupTemplate\"\n                         [ngTemplateOutletContext]=\"{ group: group }\">\n          </ng-container>\n\n        </ng-container>\n\n\n       <!--Riportare le modifiche fatte alle colonne anche nel gridNoColumnGroupTemplate-->\n        <ng-template #gridColumnGroupTemplate let-group=\"group\">\n          <kendo-grid-column-group [title]=\"group.key\">\n\n            <kendo-grid-column *ngFor=\"let col of group.value;\n                          let i = index\"\n                               [editable]=\"col.editable\" [field]=\"col.field\" [title]=\"col.title\" [class]=\"col.class\"\n                               [width]=\"col.width\" [hidden]=\"col.hidden\" [filter]=\"col | filterType\" [format]=\"col.format\"\n                               [filterable]=\"col?.filterable === false ? false: true\"\n                               [includeInChooser]=\"col.includeInChooser\" [media]=\"col.media\" [sticky]=\"col.sticky\"\n                               [ngClass]=\"'blue-header'\" [style]=\"getColumnStyle(col)\" [footerStyle]=\"getColumnFooterStyle(col)\">\n\n              <ng-container *ngIf=\"col | cellType as cellType\">\n                <ng-template  kendoGridCellTemplate\n                              let-columnIndex=\"columnIndex\"  let-rowIndex=\"rowIndex\" let-dataItem=\"dataItem\" let-column=\"column\"\n                              *ngIf=\"showAgronicakendoGridCellTemplate(cellType,col)\">\n                  <ng-container [ngTemplateOutlet]=\"AgronicakendoGridCellTemplate\"\n                                [ngTemplateOutletContext]=\"{ cellType: cellType, dataItem: dataItem, col: col}\">\n                  </ng-container>\n\n                </ng-template>\n\n                <ng-template  kendoGridGroupHeaderTemplate\n                              let-group=\"group\" let-field=\"field\" let-value=\"value\" let-aggregates=\"aggregates\" let-index=\"index\" let-expanded=\"expanded\"\n                              *ngIf=\"showAgronicakendoGridGroupHeaderTemplate(cellType)\">\n\n                  <ng-container [ngTemplateOutlet]=\"AgronicakendoGridGroupHeaderTemplate\"\n                                [ngTemplateOutletContext]=\"{ group: group, field: field, value: value, aggregates: aggregates,index: index, expanded: expanded,  cellType: cellType, col: col}\">\n                  </ng-container>\n                </ng-template>\n\n\n                <ng-template  kendoGridFooterTemplate\n                              let-column=\"column\" let-columnIndex=\"columnIndex\"\n                              *ngIf=\"showAgronicakendoGridFooterTemplate(cellType)\">\n\n                  <ng-container [ngTemplateOutlet]=\"AgronicakendoGridFooterTemplate\"\n                                [ngTemplateOutletContext]=\"{ columnIndex: columnIndex, cellType: cellType, col: col, total:_calculateAggregatesTotal(rows, false, '', '') }\">\n                  </ng-container>\n                </ng-template>\n\n                <ng-template  kendoGridFilterMenuTemplate\n                              let-column=\"column\" let-filter=\"filter\" let-filterService=\"filterService\"\n                              *ngIf=\"showkendoGridFilterMenuTemplate(cellType, col)\">\n\n                    <ng-container *ngIf=\"showMultiCheckFilter(cellType, col)\">\n\n                        <gias-multicheck-filter [multiIndex]=\"privateService.multiIndex\" [type]=\"cellType\"\n                                           [isPrimitive]=\"true\"\n                                           [field]=\"col.field\" [filterService]=\"filterService\"\n                                           [currentFilter]=\"filter\"\n                                           [showHTMLAsString]=\"ShowHTMLAsString(cellType,col)\"\n                                           [ordering]=\"col.filterOrdering\"></gias-multicheck-filter>\n                    </ng-container>\n\n                  <ng-container *ngIf=\"showAgronicakendoGridFilterMenuTemplate(cellType)\"\n                                [ngTemplateOutlet]=\"AgronicakendoGridFilterMenuTemplate\"\n                                [ngTemplateOutletContext]=\"{ filter: filter,filterService: filterService, cellType: cellType, col: col}\">\n                  </ng-container>\n                </ng-template>\n\n                <ng-template  kendoGridEditTemplate\n                              let-formGroup=\"formGroup\" let-rowIndex=\"rowIndex\" let-dataItem=\"dataItem\" let-column=\"column\" let-isNew=\"isNew\"\n                              *ngIf=\"showAgronicakendoGridEditTemplate(cellType)\">\n                  <ng-container [ngTemplateOutlet]=\"AgronicakendoGridEditTemplate\"\n                                [ngTemplateOutletContext]=\"{ formGroup: formGroup,rowIndex: rowIndex,dataItem: dataItem, isNew: isNew, cellType: cellType, col: col}\">\n                  </ng-container>\n                </ng-template>\n\n              </ng-container>\n\n            </kendo-grid-column>\n\n          </kendo-grid-column-group>\n        </ng-template>\n\n        <!--Riportare le modifiche fatte alle colonne anche nel gridColumnGroupTemplate-->\n        <ng-template #gridNoColumnGroupTemplate let-group=\"group\">\n          <kendo-grid-column *ngFor=\"let col of group.value;\n                          let i = index\"\n                             [editable]=\"col.editable\" [field]=\"col.field\" [title]=\"col.title\" [class]=\"col.class\"\n                             [width]=\"col.width\" [hidden]=\"col.hidden\" [filter]=\"col | filterType\" [format]=\"col.format\"\n                             [filterable]=\"col?.filterable === false ? false: true\"\n                             [includeInChooser]=\"col.includeInChooser\" [media]=\"col.media\" [sticky]=\"col.sticky\"\n                             [ngClass]=\"'blue-header'\" [style]=\"getColumnStyle(col)\" [footerStyle]=\"getColumnFooterStyle(col)\">\n\n            <ng-container *ngIf=\"col | cellType as cellType\">\n              <ng-template  kendoGridCellTemplate\n                            let-columnIndex=\"columnIndex\"  let-rowIndex=\"rowIndex\" let-dataItem=\"dataItem\" let-column=\"column\"\n                            *ngIf=\"showAgronicakendoGridCellTemplate(cellType,col)\">\n                <ng-container [ngTemplateOutlet]=\"AgronicakendoGridCellTemplate\"\n                              [ngTemplateOutletContext]=\"{ cellType: cellType, dataItem: dataItem, col: col}\">\n                </ng-container>\n\n              </ng-template>\n\n              <ng-template  kendoGridGroupHeaderTemplate\n                            let-group=\"group\" let-field=\"field\" let-value=\"value\" let-aggregates=\"aggregates\" let-index=\"index\" let-expanded=\"expanded\"\n                            *ngIf=\"showAgronicakendoGridGroupHeaderTemplate(cellType)\">\n\n                <ng-container [ngTemplateOutlet]=\"AgronicakendoGridGroupHeaderTemplate\"\n                              [ngTemplateOutletContext]=\"{ group: group, field: field, value: value, aggregates: aggregates,index: index, expanded: expanded,  cellType: cellType, col: col}\">\n                </ng-container>\n              </ng-template>\n\n\n              <ng-template  kendoGridFooterTemplate\n                            let-column=\"column\" let-columnIndex=\"columnIndex\"\n                            *ngIf=\"showAgronicakendoGridFooterTemplate(cellType)\">\n\n                <ng-container [ngTemplateOutlet]=\"AgronicakendoGridFooterTemplate\"\n                              [ngTemplateOutletContext]=\"{ columnIndex: columnIndex, cellType: cellType, col: col, total:_calculateAggregatesTotal(rows, false, '', '')}\">\n                </ng-container>\n              </ng-template>\n\n              <ng-template  kendoGridGroupFooterTemplate\n                            let-aggregates=\"aggregates\" let-group=\"group\" let-field=\"field\" let-column=\"column\"\n                            *ngIf=\"showAgronicakendoGridFooterTemplate(cellType)\">\n                <ng-container [ngTemplateOutlet]=\"AgronicakendoGridGroupFooterTemplate\"\n                              [ngTemplateOutletContext]=\"{ cellType: cellType, col: col, total:_calculateAggregatesTotal(group.items, false, group.field, group.value), group: group}\">\n                </ng-container>\n\n              </ng-template>\n\n                <ng-template  kendoGridFilterMenuTemplate\n                              let-column=\"column\" let-filter=\"filter\" let-filterService=\"filterService\"\n                              *ngIf=\"showkendoGridFilterMenuTemplate(cellType, col)\">\n\n                    <ng-container\n                            *ngIf=\"showMultiCheckFilter(cellType, col)\">\n\n                        <gias-multicheck-filter [multiIndex]=\"privateService.multiIndex\" [type]=\"cellType\"\n                                           [isPrimitive]=\"true\"\n                                           [field]=\"col.field\" [filterService]=\"filterService\"\n                                           [currentFilter]=\"filter\"\n                                           [showHTMLAsString]=\"ShowHTMLAsString(cellType,col)\"\n                                           [ordering]=\"col.filterOrdering\"></gias-multicheck-filter>\n                    </ng-container>\n\n                    <ng-container *ngIf=\"showAgronicakendoGridFilterMenuTemplate(cellType)\"\n                                  [ngTemplateOutlet]=\"AgronicakendoGridFilterMenuTemplate\"\n                                  [ngTemplateOutletContext]=\"{ filter: filter,filterService: filterService, cellType: cellType, col: col}\">\n                    </ng-container>\n                </ng-template>\n\n              <ng-template  kendoGridEditTemplate\n                            let-formGroup=\"formGroup\" let-rowIndex=\"rowIndex\" let-dataItem=\"dataItem\" let-column=\"column\" let-isNew=\"isNew\"\n                             *ngIf=\"showAgronicakendoGridEditTemplate(cellType)\">\n                <ng-container [ngTemplateOutlet]=\"AgronicakendoGridEditTemplate\"\n                              [ngTemplateOutletContext]=\"{ formGroup: formGroup,rowIndex: rowIndex,dataItem: dataItem, isNew: isNew, cellType: cellType, col: col}\">\n                </ng-container>\n              </ng-template>\n\n            </ng-container>\n\n          </kendo-grid-column>\n        </ng-template>\n\n\n        <kendo-grid-excel *ngIf=\"behavior.excelSettings.enabled\" [fileName]=\"'Export.xlsx'\" [fetchData]=\"excelData\">\n        </kendo-grid-excel>\n\n        <kendo-grid-pdf *ngIf=\"behavior.pdfSettings.enabled\" [fileName]=\"config.gridId + '.pdf'\"\n                        [allPages]=\"behavior.pdfSettings.allPages\" paperSize=\"A4\" [repeatHeaders]=\"true\"\n                        [landscape]=\"true\">\n            <kendo-grid-pdf-margin top=\"2cm\" left=\"1cm\" right=\"1cm\" bottom=\"2cm\"></kendo-grid-pdf-margin>\n            <ng-template kendoGridPDFTemplate let-pageNum=\"pageNum\" let-totalPages=\"totalPages\">\n                <div class=\"page-template\">\n                    <div class=\"header\">\n                        <div style=\"float: right\">\n                            {{ \"giasgrid.Page\" | transloco }} {{ pageNum }} {{\"giasgrid.of\" | transloco}} {{ totalPages }}\n                        </div>\n                    </div>\n                    <!-- <div class=\"footer\">{{ \"giasgrid.Page\" | transloco }} {{ pageNum }} {{\"giasgrid.of\" | transloco}} {{ totalPages }}</div> -->\n                </div>\n            </ng-template>\n        </kendo-grid-pdf>\n\n        <ng-container *ngIf=\"ShowkendoGridDetailTemplate()\">\n            <ng-template\n                    kendoGridDetailTemplate\n                    let-dataItem\n                    let-rowIndex\n                    [kendoGridDetailTemplateShowIf]=\"masterdetailSettings.showDetailTemplate\">\n\n                <ng-container [ngTemplateOutlet]=\"masterdetailSettings.templateGridDetail\">\n                </ng-container>\n            </ng-template>\n        </ng-container>\n\n    </kendo-grid>\n</div>\n\n<ng-template #tooltipTemplate>\n    <span>{{ 'giasgrid.Ordina' | transloco }}</span>\n</ng-template>\n\n<!-- Celle nella modalit\u00E0 di visualizzazione -->\n<ng-template #AgronicakendoGridCellTemplate let-cellType=\"cellType\" let-dataItem=\"dataItem\" let-col=\"col\">\n  <ng-container *ngIf=\"cellType === DATE\">\n    {{ ((dataItem[col.field] | stringToDate: col)?.getTime() == AGRODATA_INIZIO.getTime() || (dataItem[col.field] | stringToDate: col)?.getTime() ==\n    AGRODATA_FINE.getTime()) ? (col.date?.placeholder ?? '') : ((dataItem[col.field] | stringToDate: col) | date:(col.date?.format ?? 'dd/MM/yyyy')) }}\n  </ng-container>\n\n  <ng-container *ngIf=\"cellType === DATETIME\">\n    {{ ((dataItem[col.field] | stringToDate: col)?.getTime() == AGRODATA_INIZIO.getTime() || (dataItem[col.field] | stringToDate: col)?.getTime() ==\n    AGRODATA_FINE.getTime()) ? (col.date?.placeholder ?? '') : ((dataItem[col.field] | stringToDate: col) | date:(col.date?.format ?? 'dd/MM/yyyy HH:mm:ss')) }}\n  </ng-container>\n\n  <ng-container *ngIf=\"cellType === NUMERIC\">\n    {{ dataItem[col.field] | formatNumber: col: null }}\n  </ng-container>\n\n  <ng-container *ngIf=\"cellType === DROPDOWNLIST\">\n    {{ dataItem | cellDropdownName:col }}\n  </ng-container>\n\n  <ng-container *ngIf=\"cellType === MULTI_DROPDOWNLIST\">\n    {{ dataItem | cellMultiDropdownName:col }}\n  </ng-container>\n\n  <ng-container *ngIf=\"ShowHTMLAsString(cellType,col)\">\n    <div [innerHtml]=\"dataItem[col.field]\"></div>\n  </ng-container>\n\n  <ng-container *ngIf=\"!ShowHTMLAsString(cellType,col) && cellType === STRING\">\n    {{ dataItem[col.field] }}\n  </ng-container>\n\n  <ng-container *ngIf=\"cellType === BOOLEAN\">\n    <gias-grid-boolean [defaultValue]=\"dataItem[col.field]\" [editable]=\"false\" [useCheckbox]=\"true\"\n    ></gias-grid-boolean>\n  </ng-container>\n\n  <ng-container *ngIf=\"cellType === CUSTOM\">\n    <gias-grid-custom [component]=\"col.component\" [input]=\"dataItem\" [field]=\"col.field\" [edit]=\"false\">\n    </gias-grid-custom>\n  </ng-container>\n</ng-template>\n\n<!-- GridGroupHeaderTemplate -->\n<ng-template #AgronicakendoGridGroupHeaderTemplate\n             let-group=\"group\" let-field=\"field\" let-value=\"value\" let-aggregates=\"aggregates\"\n             let-index=\"index\" let-expanded=\"expanded\" let-cellType=\"cellType\" let-col=\"col\">\n  <ng-container *ngIf=\"groups.groupable && (cellType === DROPDOWNLIST || cellType === MULTI_DROPDOWNLIST) \">\n    {{ group | groupHeaderName:col:field }}\n  </ng-container>\n</ng-template>\n\n<!-- GridFooterTemplate -->\n<ng-template #AgronicakendoGridFooterTemplate\n             let-columnIndex=\"columnIndex\" let-cellType=\"cellType\" let-col=\"col\" >\n  <ng-container *ngIf=\"\n                            aggregates.enabled &&\n                            cellType === NUMERIC\">\n    <ng-container *ngIf=\"col | aggrType as aggrType\">\n      <ng-container *ngIf=\"aggrType.show\" >\n          <ng-container *ngIf=\"aggrType.descriptor?.aggregate === 'sum'\">\n            {{\"giasgrid.Somma_Totale_Abbr\" | transloco}} {{ getAggregateResult(total.get(''), col, aggrType.descriptor?.aggregate) | formatNumber:col: aggrType.descriptor?.format}}\n          </ng-container>\n          <ng-container *ngIf=\"aggrType.descriptor?.aggregate === 'average'\">\n            {{\"giasgrid.Media\" | transloco}} {{getAggregateResult(total.get(''), col, aggrType.descriptor?.aggregate)  | formatNumber:col: aggrType.descriptor?.format}}\n          </ng-container>\n          <ng-container *ngIf=\"aggrType.descriptor?.aggregate === 'count'\">\n            {{\"giasgrid.Conteggio_Totale\" | transloco}} {{getAggregateResult(total.get(''), col, aggrType.descriptor?.aggregate)  | formatNumber:col: aggrType.descriptor?.format}}\n          </ng-container>\n          <ng-container *ngIf=\"aggrType.descriptor?.aggregate === 'max'\">\n            {{\"giasgrid.Massimo\" | transloco}} {{getAggregateResult(total.get(''), col, aggrType.descriptor?.aggregate)  | formatNumber:col: aggrType.descriptor?.format}}\n          </ng-container>\n          <ng-container  *ngIf=\"aggrType.descriptor?.aggregate === 'min'\">\n            {{\"giasgrid.Minimo\" | transloco}} {{getAggregateResult(total.get(''), col, aggrType.descriptor?.aggregate)  | formatNumber:col: aggrType.descriptor?.format}}\n          </ng-container>\n\n      </ng-container>\n\n    </ng-container>\n\n    <ng-container *ngIf=\"col?.customFooter != null\">\n      {{ col.customFooter(rows) }}\n    </ng-container>\n\n  </ng-container>\n</ng-template>\n\n<!-- GridGroupFooterTemplate -->\n<ng-template #AgronicakendoGridGroupFooterTemplate\n             let-cellType=\"cellType\" let-col=\"col\" let-total=\"total\" let-group=\"group\" style=\"'text-align': 'right'\" >\n  <ng-container *ngIf=\"aggregates.enabled && cellType === NUMERIC\">\n    <ng-container *ngIf=\"col | aggrType as aggrType\">\n      <ng-container *ngIf=\"aggrType.show\" >\n        <div style=\"text-align: right; font-weight: bold;\" >\n          <ng-container *ngIf=\"aggrType.descriptor?.aggregate === 'sum'\">\n            {{\"giasgrid.Somma_Totale_Abbr\" | transloco}} {{ getAggregateResult(total, col, aggrType.descriptor?.aggregate) | formatNumber:col: aggrType.descriptor?.format}}\n          </ng-container>\n          <ng-container *ngIf=\"aggrType.descriptor?.aggregate === 'average'\">\n            {{\"giasgrid.Media\" | transloco}} {{getAggregateResult(total, col, aggrType.descriptor?.aggregate)  | formatNumber:col: aggrType.descriptor?.format}}\n          </ng-container>\n          <ng-container *ngIf=\"aggrType.descriptor?.aggregate === 'count'\">\n            {{\"giasgrid.Conteggio_Totale\" | transloco}} {{getAggregateResult(total, col, aggrType.descriptor?.aggregate)  | formatNumber:col: aggrType.descriptor?.format}}\n          </ng-container>\n          <ng-container *ngIf=\"aggrType.descriptor?.aggregate === 'max'\">\n            {{\"giasgrid.Massimo\" | transloco}} {{getAggregateResult(total, col, aggrType.descriptor?.aggregate)  | formatNumber:col: aggrType.descriptor?.format}}\n          </ng-container>\n          <ng-container  *ngIf=\"aggrType.descriptor?.aggregate === 'min'\">\n            {{\"giasgrid.Minimo\" | transloco}} {{getAggregateResult(total, col, aggrType.descriptor?.aggregate)  | formatNumber:col: aggrType.descriptor?.format}}\n          </ng-container>\n        </div>\n      </ng-container>\n    </ng-container>\n\n    <ng-container *ngIf=\"col?.customFooter != null\">\n      {{ col.customFooter(rows) }}\n    </ng-container>\n\n  </ng-container>\n</ng-template>\n\n<!-- GridFilterMenuTemplate -->\n<ng-template #AgronicakendoGridFilterMenuTemplate\n             let-filter=\"filter\" let-filterService=\"filterService\"\n             let-cellType=\"cellType\" let-col=\"col\"\n></ng-template>\n\n<!-- Celle nella modalit\u00E0 di editing -->\n<ng-template #AgronicakendoGridEditTemplate\n             let-formGroup=\"formGroup\" let-rowIndex=\"rowIndex\" let-dataItem=\"dataItem\" let-isNew=\"isNew\" let-cellType=\"cellType\" let-col=\"col\">\n\n  <!-- getDate(dataItem, col) -->\n  <ng-container *ngIf=\"cellType === DATE\">\n    <kendo-datepicker #input [min]=\" (col.date) ? col.date?.min : AGRODATA_INIZIO\"\n                      [max]=\" (col.date) ? col.date?.max : AGRODATA_FINE\"\n                      [formControl]=\"formGroup.get(col.field)\"\n                      calendarType=\"classic\">\n    </kendo-datepicker>\n    <div *ngIf=\"formControls[col.field].touched && formControls[col.field].errors\"\n         class=\"k-tooltip-validation\">\n\n    </div>\n  </ng-container>\n\n\n  <ng-container *ngIf=\"cellType === DATETIME\">\n    <kendo-datetimepicker #input [min]=\" (col.date) ? col.date?.min : AGRODATA_INIZIO\"\n                      [max]=\" (col.date) ? col.date?.max : AGRODATA_FINE\"\n                      [formControl]=\"formGroup.get(col.field)\" calendarType=\"classic\">\n    </kendo-datetimepicker>\n    <div *ngIf=\"formControls[col.field].touched && formControls[col.field].errors\"\n         class=\"k-tooltip-validation\">\n\n    </div>\n  </ng-container>\n\n  <!-- *ngIf=\"cellType === NUMERIC && aggregates.enabled\" -->\n  <ng-container *ngIf=\"cellType === NUMERIC\">\n    <kendo-numerictextbox #input [formControl]=\"formGroup.get(col.field)\"\n                          [min]=\"col.numeric.min\" [max]=\"col.numeric.max\" [format]=\"col.numeric.format\"\n                          [spinners]=\"false\"\n                          [autoCorrect]=\"col.numeric.autoCorrect\"\n                          [decimals]=\"col.numeric.decimals\"\n                          [step]=\"col.numeric?.step ?? 0\"></kendo-numerictextbox>\n    <div *ngIf=\"formControls[col.field].touched && formControls[col.field].errors\"\n         class=\"k-tooltip-validation\">\n\n    </div>\n  </ng-container>\n\n  <ng-container *ngIf=\"cellType === DROPDOWNLIST\">\n    <gias-grid-ddl #input [column]=\"col\" [useForm]=\"true\" [id]=\"col.ddl.id\"\n                   [defaultItem]=\"col.ddl.defaultItem\"\n                   [source]=\"col.ddl.data\" [textField]=\"col.ddl.textField\"\n                   [valueField]=\"col.ddl.valueField\"\n                   [valuePrimitive]=\"col.ddl.valuePrimitive\" [filterable]=\"true\" [formGroup]=\"formGroup\"\n                   [controlName]=\"col.ddl.formControlName\" [ddl]=\"col.ddl\"\n                   (reload)=\"ddlReload($event, formGroup,col)\"\n                   (valueChange)=\"ddlStateChanged($event, formGroup, col)\"\n                   (open)=\"ddlOpenEvent($event, formGroup)\">\n    </gias-grid-ddl>\n    <div *ngIf=\"formControls[col.field].touched && formControls[col.field].errors\"\n         class=\"k-tooltip-validation\">\n\n    </div>\n  </ng-container>\n\n  <ng-container *ngIf=\"cellType === MULTI_DROPDOWNLIST\">\n    <gias-grid-multi-ddl #input [useForm]=\"true\" [id]=\"col.ddl.id\" [defaultItem]=\"col.ddl.defaultItem\"\n                         [source]=\"col.ddl.data\" [textField]=\"col.ddl.textField\"\n                         [valueField]=\"col.ddl.valueField\"\n                         [valuePrimitive]=\"col.ddl.valuePrimitive\" [filterable]=\"true\"\n                         [formGroup]=\"formGroup\"\n                         [controlName]=\"col.ddl.formControlName\" [ddl]=\"col.ddl\"\n                         [defaultOpen]=\"col.ddl.defaultOpen\"\n                         (reload)=\"onOpenReloadDDL($event, formGroup, true)\"\n                         (valueChange)=\"ddlStateChanged($event, formGroup, col)\"\n                         (open)=\"onOpenReloadDDL($event, formGroup, false)\">\n    </gias-grid-multi-ddl>\n    <div *ngIf=\"formControls[col.field].touched && formControls[col.field].errors\"\n         class=\"k-tooltip-validation\">\n\n    </div>\n  </ng-container>\n\n  <ng-container *ngIf=\"cellType === BOOLEAN\">\n    <gias-grid-boolean [editable]=\"true\" [useCheckbox]=\"true\"\n      [defaultValue]=\"dataItem[col.field]\"\n      [formGroup]=\"formGroup\" [controlName]=\"col.field\"\n    ></gias-grid-boolean>\n  </ng-container>\n\n  <ng-container *ngIf=\"cellType === CUSTOM\">\n    <gias-grid-custom [component]=\"col.component\" [field]=\"col.field\"\n                      [input]=\"dataItem\" [formGroup]=\"formGroup\"\n                      [edit]=\"true\"\n    ></gias-grid-custom>\n    <div *ngIf=\"formControls[col.field].touched && formControls[col.field].errors\"\n         class=\"k-tooltip-validation\">\n\n    </div>\n  </ng-container>\n\n</ng-template>\n", styles: [".footer-virtual-count{width:100%;display:flex;justify-content:flex-end;align-items:center}.footer-virtual-count p{text-align:right;font-size:.9rem;margin:0}.k-grid-toolbar-bottom:has(>.footer-virtual-empty){height:0px!important;padding:0!important}.btn:disabled{border:0px}.increase-border{margin-left:5px!important;margin-right:5px}:host ::ng-deep thead th{background-color:#428bca!important;color:#fff!important}:host ::ng-deep .k-grid-header .k-i-sort-asc-sm{color:#fff!important}:host ::ng-deep .k-grid-header .k-i-sort-desc-sm{color:#fff!important}#btnDelete,.editBtn,#infoBtn{max-width:45px}.pending-deletion-row{text-decoration:line-through;color:red}.batch-fixed-top{top:-6px}.breakWord120{word-break:break-all!important;word-wrap:break-word!important}.k-grid tbody td{white-space:wrap!important;line-height:20px!important;padding:8px 12px!important}multicheck-filter{align-self:center;width:100%}\n"] }]
        }], ctorParameters: () => [{ type: GridCustomizationsService }, { type: KendoGridService }, { type: GridErrorService }, { type: i4.IntlService }, { type: i0.ChangeDetectorRef }, { type: i0.NgZone }, { type: GridWorkerService }, { type: i1$1.TranslocoService }, { type: i0.Renderer2 }, { type: GridBatchHandlerService }, { type: i2$3.DialogService }, { type: KendoGridMasterDetailService, decorators: [{
                    type: Optional
                }] }], propDecorators: { noRecordsTemplateRef: [{
                type: ContentChild,
                args: ['noRecordsTemplateRef']
            }], customCommandColumnCellTemplate: [{
                type: Input
            }], customCommandColumnHeaderTemplate: [{
                type: Input
            }], showSwitchViewsPrivatePublic: [{
                type: Input
            }], rowsLoaded: [{
                type: Output
            }], gridId: [{
                type: Input
            }], grid: [{
                type: ViewChild,
                args: ['grid', { static: true }]
            }], checkboxColumn: [{
                type: ViewChild,
                args: ['CheckboxColumn']
            }], commandColumn: [{
                type: ViewChild,
                args: ['CommandColumn']
            }], gridElRef: [{
                type: ViewChild,
                args: ['grid', { static: true, read: ElementRef }]
            }], input: [{
                type: ViewChild,
                args: ['input', { static: false }]
            }], cellClick: [{
                type: Output
            }], pageChangeEvent: [{
                type: Output
            }], selectionChange: [{
                type: Output
            }], columnVisibilityChange: [{
                type: Output
            }], numericTextBox: [{
                type: Output
            }], tooltipDir: [{
                type: ViewChild,
                args: [TooltipDirective]
            }], contentCmdColumns: [{
                type: ContentChildren,
                args: [CommandColumnComponent]
            }], columns: [{
                type: Input
            }], rows: [{
                type: Input
            }], model: [{
                type: Input
            }], detailCollapse: [{
                type: Output
            }], detailExpand: [{
                type: Output
            }] } });
class GridHelper {
    /**
     * Excel export.
     * Maps rows and columns of a Kendo Grid for Excel export by transforming dropdown fields
     * into their corresponding text descriptions.
     *
     * @param rows - An array of `KendoGridRow` objects representing the grid's data rows.
     * @param columns - An array of `KendoGridColumn` objects representing the grid's column definitions.
     * @returns An array of transformed rows where dropdown fields are replaced with their text descriptions.
     *
     * The method processes each row and updates fields specified in the column definitions
     * by replacing dropdown value fields with their corresponding text descriptions. If the field
     * contains an array of values, they are joined into a comma-separated string.
     *
     * Debugging:
     * Logs the rows, columns, and dropdown information to the console for debugging purposes.
     */
    mapForExcelExport(rows, columns) {
        let resultRows = [];
        let ddlInfos = this.getDropdownsDescriptionField(columns);
        console.debug('KENDO_GRID_DEBUG::MAP_ROWS::', rows, columns, ddlInfos);
        for (let row of rows) {
            ddlInfos.forEach(info => {
                let textDescription = "";
                if (Array.isArray(row[info.descriptionField]) && row[info.descriptionField].length > 0) {
                    textDescription = row[info.descriptionField].join(', ');
                }
                else {
                    textDescription = row[info.descriptionField];
                }
                row[info.valueField] = textDescription;
            });
            resultRows.push(row);
        }
        return resultRows;
    }
    getDropdownsDescriptionField(columns) {
        return columns.filter(s => s.ddl != null).map(col => {
            let descField = col.ddl.descriptionField;
            let valueField = col.ddl.formControlName;
            if (descField == null || valueField == null)
                throw Error(`Una colonna non è stata configurata bene. ValueField: ${valueField}, descField: ${descField}`);
            const info = {
                descriptionField: descField,
                valueField: valueField
            };
            return info;
        });
    }
    // END Excel Export
    setCustomValidatorRow(c, row) {
        c.validators?.forEach(s => {
            if (s instanceof PropertyValidator) {
                s.setCurrentRow(row);
            }
        });
    }
    getDigitsFromFormat(format) {
        if (format != '' || format != undefined) {
            return toNumber(format.slice(1));
        }
        else {
            return 0;
        }
    }
    calculateAggregate(rows, pagination, aggregates, footer) {
        const take = pagination.gridState.take;
        pagination.gridState.take = undefined;
        const proc = process(rows ?? [], pagination.gridState);
        let dataCopy = cloneDeep(proc.data);
        let data = this.appiattisciData(dataCopy);
        const total = aggregateBy(data, aggregates.descriptors);
        //const total = aggregateBy(proc.data, aggregates.descriptors);
        // const format = this.getDigitsFromFormat(aggregates.descriptors[0].format);
        // aggregates.descriptors.forEach(d => {
        //   d.field
        //   if (total[d.field] != undefined) {
        //     total[d.field].sum = toNumber(total[d.field]?.sum?.toFixed(format));
        //   }
        // });
        pagination.gridState.take = take;
        return total;
    }
    appiattisciData(data) {
        let rows = [];
        if (data?.length > 0 && data[0].field && data[0].aggregates) {
            data.forEach((item) => {
                let rowAppiattite = this.appiattisciData(item);
                rowAppiattite.forEach((el) => {
                    rows.push(el);
                });
            });
        }
        else if (data?.length > 0) {
            data.forEach((item) => rows.push(item));
        }
        else if (data?.items?.length > 0) {
            data.items.forEach((item) => {
                let rowAppiattite = this.appiattisciData(item);
                rowAppiattite.forEach((el) => {
                    rows.push(el);
                });
            });
        }
        else {
            rows.push(data);
        }
        return rows;
    }
    columnContainsSimpleDropdownList(model, field) {
        return model[field].type === CELL_TYPES.DROPDOWNLIST;
    }
    columnContainsMultiDropdownList(model, field) {
        return model[field].type === CELL_TYPES.MULTI_DROPDOWNLIST;
    }
    getMultiDDLDataIfMissing(row, col) {
        const ids = row[col.field];
        const names = row[col.ddl.descriptionField];
        const missingInSource = col.ddl.data.some((el) => !ids.includes(el.id) && !names.includes(el.name));
        let items = [];
        if (missingInSource) {
            let data = ids.map((id, index) => new DropdownListItem(id, names[index]));
            items.push(...data);
        }
        return {
            missingItemInSource: missingInSource,
            newDDLData: items
        };
    }
    loadDropdownListOnCellOpened(dati, forceReload) {
        let columns = dati.columns;
        let component = dati.component;
        let row = dati.row;
        const col = columns.find((col) => col.field == component.controlName);
        if (col.ddl.loadOnEdit || forceReload) {
            col.ddl.loadFunction(row).pipe(take$1(1)).subscribe((data) => {
                const ddlData = data.map(el => new DropdownListItem(el[col.ddl.id], el[col.ddl.formControlValue], el));
                component.data = ddlData;
                component.source = ddlData;
                col.ddl.data = ddlData;
            });
        }
    }
}
function elementQueuedForDeletion(item) {
    return item['pending-deletion-row'];
}

class KendoGridCustomColumnDirective {
    templateRef;
    constructor(templateRef) {
        this.templateRef = templateRef;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: KendoGridCustomColumnDirective, deps: [{ token: i0.TemplateRef }], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "19.2.9", type: KendoGridCustomColumnDirective, isStandalone: false, selector: "[kendoCustomColumnContent]", ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: KendoGridCustomColumnDirective, decorators: [{
            type: Directive,
            args: [{
                    standalone: false,
                    selector: '[kendoCustomColumnContent]'
                }]
        }], ctorParameters: () => [{ type: i0.TemplateRef }] });

class GridNumericComponent {
    value;
    min;
    max;
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: GridNumericComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "19.2.9", type: GridNumericComponent, isStandalone: false, selector: "gias-grid-numeric", inputs: { value: "value", min: "min", max: "max" }, ngImport: i0, template: "<kendo-numerictextbox\n  [style.marginBottom.px]=\"10\"\n  [value]=\"value\"\n  [min]=\"min\"\n  [max]=\"max\"\n>\n</kendo-numerictextbox>", styles: [""], dependencies: [{ kind: "component", type: i14.NumericTextBoxComponent, selector: "kendo-numerictextbox", inputs: ["focusableId", "disabled", "readonly", "title", "autoCorrect", "format", "max", "min", "decimals", "placeholder", "step", "spinners", "rangeValidation", "tabindex", "tabIndex", "changeValueOnScroll", "selectOnFocus", "value", "maxlength", "size", "rounded", "fillMode", "inputAttributes"], outputs: ["valueChange", "focus", "blur", "inputFocus", "inputBlur"], exportAs: ["kendoNumericTextBox"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: GridNumericComponent, decorators: [{
            type: Component,
            args: [{ standalone: false, selector: 'gias-grid-numeric', template: "<kendo-numerictextbox\n  [style.marginBottom.px]=\"10\"\n  [value]=\"value\"\n  [min]=\"min\"\n  [max]=\"max\"\n>\n</kendo-numerictextbox>" }]
        }], propDecorators: { value: [{
                type: Input
            }], min: [{
                type: Input
            }], max: [{
                type: Input
            }] } });

class GridDateTimeComponent {
    value = new Date(2000, 2, 10);
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: GridDateTimeComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "19.2.9", type: GridDateTimeComponent, isStandalone: false, selector: "gias-grid-date", ngImport: i0, template: "<!-- <kendo-datepicker  [(value)]=\"value\"></kendo-datepicker> -->", styles: [""] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: GridDateTimeComponent, decorators: [{
            type: Component,
            args: [{ standalone: false, selector: 'gias-grid-date', template: "<!-- <kendo-datepicker  [(value)]=\"value\"></kendo-datepicker> -->" }]
        }] });

class ToolbarColumnMenuComponent {
    columns;
    onChange(item) {
        item.hidden = !item.hidden;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: ToolbarColumnMenuComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "19.2.9", type: ToolbarColumnMenuComponent, isStandalone: false, selector: "gias-toolbar-column-menu", inputs: { columns: "columns" }, ngImport: i0, template: "<button kendoButton #target class=\"target\">\n  Sel. Colonne\n</button>\n<kendo-contextmenu\n      [target]=\"target\"\n      [items]=\"columns\"\n    >\n    <ng-template kendoMenuItemTemplate let-item=\"item\">\n      <input type=\"checkbox\" [id]=\"item.field\" [checked]=\"!item.hidden\" kendoCheckBoxc (click)=\"onChange(item)\" />\n      <label class=\"k-checkbox-label\" >{{ item.title }}</label>\n    </ng-template>\n    </kendo-contextmenu>\n", styles: [""], dependencies: [{ kind: "component", type: i13.ButtonComponent, selector: "button[kendoButton]", inputs: ["arrowIcon", "toggleable", "togglable", "selected", "tabIndex", "imageUrl", "iconClass", "icon", "disabled", "size", "rounded", "fillMode", "themeColor", "svgIcon", "primary", "look"], outputs: ["selectedChange", "click"], exportAs: ["kendoButton"] }, { kind: "directive", type: i2$4.ItemTemplateDirective, selector: "[kendoMenuItemTemplate]" }, { kind: "component", type: i2$4.ContextMenuComponent, selector: "kendo-contextmenu", inputs: ["showOn", "target", "filter", "alignToAnchor", "vertical", "popupAnimate", "popupAlign", "anchorAlign", "collision", "appendTo", "ariaLabel"], outputs: ["popupOpen", "popupClose", "select", "open", "close"], exportAs: ["kendoContextMenu"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: ToolbarColumnMenuComponent, decorators: [{
            type: Component,
            args: [{ standalone: false, selector: 'gias-toolbar-column-menu', template: "<button kendoButton #target class=\"target\">\n  Sel. Colonne\n</button>\n<kendo-contextmenu\n      [target]=\"target\"\n      [items]=\"columns\"\n    >\n    <ng-template kendoMenuItemTemplate let-item=\"item\">\n      <input type=\"checkbox\" [id]=\"item.field\" [checked]=\"!item.hidden\" kendoCheckBoxc (click)=\"onChange(item)\" />\n      <label class=\"k-checkbox-label\" >{{ item.title }}</label>\n    </ng-template>\n    </kendo-contextmenu>\n" }]
        }], propDecorators: { columns: [{
                type: Input
            }] } });

// https://www.telerik.com/kendo-angular-ui/components/grid/editing/custom-reactive-editing/
class PopupAnchorDirective {
    element;
    constructor(element) {
        this.element = element;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: PopupAnchorDirective, deps: [{ token: i0.ElementRef }], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "19.2.9", type: PopupAnchorDirective, isStandalone: false, selector: "[popupAnchor]", exportAs: ["popupAnchor"], ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: PopupAnchorDirective, decorators: [{
            type: Directive,
            args: [{
                    standalone: false,
                    selector: '[popupAnchor]',
                    exportAs: 'popupAnchor',
                }]
        }], ctorParameters: () => [{ type: i0.ElementRef }] });

class ShortenPipe {
    transform(value, limit) {
        if (value?.length > limit) {
            return value.substring(0, limit) + ' ...';
        }
        return value;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: ShortenPipe, deps: [], target: i0.ɵɵFactoryTarget.Pipe });
    static ɵpipe = i0.ɵɵngDeclarePipe({ minVersion: "14.0.0", version: "19.2.9", ngImport: i0, type: ShortenPipe, isStandalone: false, name: "shorten" });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: ShortenPipe, decorators: [{
            type: Pipe,
            args: [{
                    standalone: false,
                    name: 'shorten'
                }]
        }] });

class SafePipe {
    sanitizer;
    constructor(sanitizer) {
        this.sanitizer = sanitizer;
    }
    transform(url) {
        const sanitizedUrl = this.sanitizer.sanitize(SecurityContext.URL, url);
        const result = this.sanitizer.bypassSecurityTrustResourceUrl(sanitizedUrl);
        return result;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: SafePipe, deps: [{ token: i1$2.DomSanitizer }], target: i0.ɵɵFactoryTarget.Pipe });
    static ɵpipe = i0.ɵɵngDeclarePipe({ minVersion: "14.0.0", version: "19.2.9", ngImport: i0, type: SafePipe, isStandalone: false, name: "safe" });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: SafePipe, decorators: [{
            type: Pipe,
            args: [{
                    standalone: false, name: 'safe'
                }]
        }], ctorParameters: () => [{ type: i1$2.DomSanitizer }] });

var enum_PagineGiasNG;
(function (enum_PagineGiasNG) {
    enum_PagineGiasNG[enum_PagineGiasNG["Pagina_Corrente"] = 0] = "Pagina_Corrente";
    enum_PagineGiasNG[enum_PagineGiasNG["Pagina_Menu_Anagrafica"] = 1] = "Pagina_Menu_Anagrafica";
    enum_PagineGiasNG[enum_PagineGiasNG["Pagina_Menu_Anagrafica_Imprese"] = 10] = "Pagina_Menu_Anagrafica_Imprese";
    enum_PagineGiasNG[enum_PagineGiasNG["Pagina_Menu_Anagrafica_Centri"] = 11] = "Pagina_Menu_Anagrafica_Centri";
    enum_PagineGiasNG[enum_PagineGiasNG["Pagina_Menu_Anagrafica_Catasto"] = 12] = "Pagina_Menu_Anagrafica_Catasto";
    enum_PagineGiasNG[enum_PagineGiasNG["Pagina_Menu_Anagrafica_Campi"] = 13] = "Pagina_Menu_Anagrafica_Campi";
    enum_PagineGiasNG[enum_PagineGiasNG["Pagina_Menu_Anagrafica_Impianti"] = 14] = "Pagina_Menu_Anagrafica_Impianti";
    enum_PagineGiasNG[enum_PagineGiasNG["Pagina_Menu_Anagrafica_Macchine"] = 15] = "Pagina_Menu_Anagrafica_Macchine";
    enum_PagineGiasNG[enum_PagineGiasNG["Pagina_Menu_Anagrafica_Contatti"] = 16] = "Pagina_Menu_Anagrafica_Contatti";
    enum_PagineGiasNG[enum_PagineGiasNG["Pagina_Menu_Anagrafica_Fabbricati"] = 17] = "Pagina_Menu_Anagrafica_Fabbricati";
    enum_PagineGiasNG[enum_PagineGiasNG["Pagina_Edit_Impresa"] = 2] = "Pagina_Edit_Impresa";
    enum_PagineGiasNG[enum_PagineGiasNG["Pagina_Edit_Centro"] = 3] = "Pagina_Edit_Centro";
    enum_PagineGiasNG[enum_PagineGiasNG["Pagina_Edit_Campo"] = 4] = "Pagina_Edit_Campo";
    enum_PagineGiasNG[enum_PagineGiasNG["Pagina_Edit_Catasto"] = 5] = "Pagina_Edit_Catasto";
    enum_PagineGiasNG[enum_PagineGiasNG["Pagina_Edit_AppezzamentoGlobal"] = 6] = "Pagina_Edit_AppezzamentoGlobal";
    enum_PagineGiasNG[enum_PagineGiasNG["Pagina_Edit_Fabbricato"] = 7] = "Pagina_Edit_Fabbricato";
    enum_PagineGiasNG[enum_PagineGiasNG["Pagina_Edit_Contatto"] = 8] = "Pagina_Edit_Contatto";
    enum_PagineGiasNG[enum_PagineGiasNG["Pagina_Edit_Macchina"] = 9] = "Pagina_Edit_Macchina";
    enum_PagineGiasNG[enum_PagineGiasNG["Pagina_Menu_Agenda"] = 20] = "Pagina_Menu_Agenda";
    enum_PagineGiasNG[enum_PagineGiasNG["Pagina_Edit_Attivita"] = 21] = "Pagina_Edit_Attivita";
    enum_PagineGiasNG[enum_PagineGiasNG["Pagina_Configurazione_Operazioni_Culturali"] = 22] = "Pagina_Configurazione_Operazioni_Culturali";
    enum_PagineGiasNG[enum_PagineGiasNG["Pagina_Menu_Profilazione"] = 30] = "Pagina_Menu_Profilazione";
    enum_PagineGiasNG[enum_PagineGiasNG["Pagina_Profilazione_Import_Utenti"] = 31] = "Pagina_Profilazione_Import_Utenti";
    enum_PagineGiasNG[enum_PagineGiasNG["Pagina_Menu_Gruppi_Merce_Anagrafica"] = 40] = "Pagina_Menu_Gruppi_Merce_Anagrafica";
    enum_PagineGiasNG[enum_PagineGiasNG["Pagina_Menu_Gruppi_Merce_Autorizzazioni"] = 41] = "Pagina_Menu_Gruppi_Merce_Autorizzazioni";
    enum_PagineGiasNG[enum_PagineGiasNG["Pagina_AmministrazioneSistema_ConsultaSincroDatiApp"] = 50] = "Pagina_AmministrazioneSistema_ConsultaSincroDatiApp";
    enum_PagineGiasNG[enum_PagineGiasNG["Pagina_Menu_Visite"] = 60] = "Pagina_Menu_Visite";
    enum_PagineGiasNG[enum_PagineGiasNG["Pagina_Edit_Visite"] = 61] = "Pagina_Edit_Visite";
    enum_PagineGiasNG[enum_PagineGiasNG["Pagina_Valutazioni"] = 70] = "Pagina_Valutazioni";
    enum_PagineGiasNG[enum_PagineGiasNG["Pagina_Valutazioni_Edit"] = 71] = "Pagina_Valutazioni_Edit";
    enum_PagineGiasNG[enum_PagineGiasNG["Pagina_PianoConti"] = 80] = "Pagina_PianoConti";
    enum_PagineGiasNG[enum_PagineGiasNG["Pagina_Budget_Menu_Anagrafica_Imprese"] = 100] = "Pagina_Budget_Menu_Anagrafica_Imprese";
    enum_PagineGiasNG[enum_PagineGiasNG["Pagina_Budget_Menu_Anagrafica_Centri"] = 110] = "Pagina_Budget_Menu_Anagrafica_Centri";
    enum_PagineGiasNG[enum_PagineGiasNG["Pagina_Budget_Menu_Anagrafica_Catasto"] = 120] = "Pagina_Budget_Menu_Anagrafica_Catasto";
    enum_PagineGiasNG[enum_PagineGiasNG["Pagina_Budget_Menu_Anagrafica_Campi"] = 130] = "Pagina_Budget_Menu_Anagrafica_Campi";
    enum_PagineGiasNG[enum_PagineGiasNG["Pagina_Budget_Menu_Anagrafica_Impianti"] = 140] = "Pagina_Budget_Menu_Anagrafica_Impianti";
    enum_PagineGiasNG[enum_PagineGiasNG["Pagina_Budget_Menu_Anagrafica_Macchine"] = 150] = "Pagina_Budget_Menu_Anagrafica_Macchine";
    enum_PagineGiasNG[enum_PagineGiasNG["Pagina_GIS"] = 200] = "Pagina_GIS";
    enum_PagineGiasNG[enum_PagineGiasNG["Pagina_GIS_cfg_proiezioni"] = 201] = "Pagina_GIS_cfg_proiezioni";
    enum_PagineGiasNG[enum_PagineGiasNG["Pagina_Dashboard"] = 999] = "Pagina_Dashboard";
    enum_PagineGiasNG[enum_PagineGiasNG["Pagina_Preferiti_Config"] = 1000] = "Pagina_Preferiti_Config";
    enum_PagineGiasNG[enum_PagineGiasNG["Pagina_Gruppi_Raccolta"] = 300] = "Pagina_Gruppi_Raccolta";
    enum_PagineGiasNG[enum_PagineGiasNG["Pagina_Requisiti_Stabilimento"] = 301] = "Pagina_Requisiti_Stabilimento";
    enum_PagineGiasNG[enum_PagineGiasNG["Pagina_Requisiti_Stabilimento_PianoColturale"] = 302] = "Pagina_Requisiti_Stabilimento_PianoColturale";
    enum_PagineGiasNG[enum_PagineGiasNG["Pagina_Requisiti_Stabilimento_Contratti"] = 303] = "Pagina_Requisiti_Stabilimento_Contratti";
    enum_PagineGiasNG[enum_PagineGiasNG["Pagina_Dati_Previsionali_Colture"] = 305] = "Pagina_Dati_Previsionali_Colture";
    enum_PagineGiasNG[enum_PagineGiasNG["Pagina_Requisiti_Stabilimento_VD_PianoColturale"] = 306] = "Pagina_Requisiti_Stabilimento_VD_PianoColturale";
    enum_PagineGiasNG[enum_PagineGiasNG["Pagina_Requisiti_Stabilimento_VD_Contratti"] = 307] = "Pagina_Requisiti_Stabilimento_VD_Contratti";
    enum_PagineGiasNG[enum_PagineGiasNG["Pagina_Confronto_Piano_Colturale"] = 308] = "Pagina_Confronto_Piano_Colturale";
    enum_PagineGiasNG[enum_PagineGiasNG["Pagina_Filtro_Ricerca"] = 309] = "Pagina_Filtro_Ricerca";
    enum_PagineGiasNG[enum_PagineGiasNG["Pagina_Export_QdC_To_Agea"] = 310] = "Pagina_Export_QdC_To_Agea";
    enum_PagineGiasNG[enum_PagineGiasNG["Pagina_Profilazione_Imprese"] = 311] = "Pagina_Profilazione_Imprese";
    enum_PagineGiasNG[enum_PagineGiasNG["Pagina_Analisi_Terreno_Menu"] = 312] = "Pagina_Analisi_Terreno_Menu";
    enum_PagineGiasNG[enum_PagineGiasNG["Pagina_Analisi_Terreno_Edit"] = 313] = "Pagina_Analisi_Terreno_Edit";
    enum_PagineGiasNG[enum_PagineGiasNG["Pagina_Report_Impiego_Prodotti_Fitosanitari"] = 314] = "Pagina_Report_Impiego_Prodotti_Fitosanitari";
    enum_PagineGiasNG[enum_PagineGiasNG["Pagina_Lettura_Contatori"] = 315] = "Pagina_Lettura_Contatori";
    enum_PagineGiasNG[enum_PagineGiasNG["Pagina_Domanda_Irrigua"] = 320] = "Pagina_Domanda_Irrigua";
    enum_PagineGiasNG[enum_PagineGiasNG["Pagina_Terapie"] = 321] = "Pagina_Terapie";
})(enum_PagineGiasNG || (enum_PagineGiasNG = {}));
var enum_AnagraficaNgTabs;
(function (enum_AnagraficaNgTabs) {
    enum_AnagraficaNgTabs[enum_AnagraficaNgTabs["imprese"] = 1] = "imprese";
    enum_AnagraficaNgTabs[enum_AnagraficaNgTabs["centri"] = 2] = "centri";
    enum_AnagraficaNgTabs[enum_AnagraficaNgTabs["fabbricati"] = 3] = "fabbricati";
    enum_AnagraficaNgTabs[enum_AnagraficaNgTabs["catasto"] = 4] = "catasto";
    enum_AnagraficaNgTabs[enum_AnagraficaNgTabs["campi"] = 5] = "campi";
    enum_AnagraficaNgTabs[enum_AnagraficaNgTabs["impianti"] = 6] = "impianti";
    enum_AnagraficaNgTabs[enum_AnagraficaNgTabs["contatti"] = 7] = "contatti";
    enum_AnagraficaNgTabs[enum_AnagraficaNgTabs["macchine"] = 8] = "macchine";
})(enum_AnagraficaNgTabs || (enum_AnagraficaNgTabs = {}));
function getMasterWithEditPages() {
    return [
        {
            masterPage: enum_PagineGiasNG.Pagina_Menu_Anagrafica,
            editPage: [enum_PagineGiasNG.Pagina_Edit_Campo, enum_PagineGiasNG.Pagina_Edit_Contatto,
                enum_PagineGiasNG.Pagina_Edit_Fabbricato, enum_PagineGiasNG.Pagina_Edit_Catasto,
                enum_PagineGiasNG.Pagina_Edit_AppezzamentoGlobal, enum_PagineGiasNG.Pagina_Edit_Centro,
                enum_PagineGiasNG.Pagina_Edit_Impresa, enum_PagineGiasNG.Pagina_Edit_Macchina]
        },
        {
            masterPage: enum_PagineGiasNG.Pagina_Menu_Agenda,
            editPage: [enum_PagineGiasNG.Pagina_Edit_Attivita]
        },
        {
            masterPage: enum_PagineGiasNG.Pagina_Valutazioni,
            editPage: [enum_PagineGiasNG.Pagina_Valutazioni_Edit]
        },
        {
            masterPage: enum_PagineGiasNG.Pagina_Menu_Visite,
            editPage: [enum_PagineGiasNG.Pagina_Edit_Visite]
        },
        {
            masterPage: enum_PagineGiasNG.Pagina_Analisi_Terreno_Menu,
            editPage: [enum_PagineGiasNG.Pagina_Analisi_Terreno_Edit]
        }
    ];
}
/**
 * Codifica i permessi posseduti da un utente.
 * Utilizzare {@link enum_Security_Operazione} per verificare la tipologia di permesso.
 */
var enum_Security_Attivita;
(function (enum_Security_Attivita) {
    enum_Security_Attivita[enum_Security_Attivita["Gest_Menu"] = 1] = "Gest_Menu";
    enum_Security_Attivita[enum_Security_Attivita["Gest_AvvisiMessaggi"] = 2] = "Gest_AvvisiMessaggi";
    enum_Security_Attivita[enum_Security_Attivita["Gest_Messaggi_AccessoMenu"] = 2] = "Gest_Messaggi_AccessoMenu";
    /** Gestisce accesso alla gestione di utenti e permessi nel gias vecchio.
     * Per la gestione della profilazione NG vedi {@link Profilazione_NG}.
     */
    enum_Security_Attivita[enum_Security_Attivita["Gest_UtentiPermessi"] = 3] = "Gest_UtentiPermessi";
    enum_Security_Attivita[enum_Security_Attivita["Gest_AnagraficaAzienda"] = 4] = "Gest_AnagraficaAzienda";
    enum_Security_Attivita[enum_Security_Attivita["Anagrafica_AccessoMenu"] = 4] = "Anagrafica_AccessoMenu";
    enum_Security_Attivita[enum_Security_Attivita["Gest_Contabilita"] = 5] = "Gest_Contabilita";
    enum_Security_Attivita[enum_Security_Attivita["Sementieri_UtenteVedeTutto"] = 6] = "Sementieri_UtenteVedeTutto";
    enum_Security_Attivita[enum_Security_Attivita["Gest_Stampe"] = 7] = "Gest_Stampe";
    enum_Security_Attivita[enum_Security_Attivita["Gest_Certificazioni"] = 8] = "Gest_Certificazioni";
    enum_Security_Attivita[enum_Security_Attivita["Gest_VerificaScadenze"] = 9] = "Gest_VerificaScadenze";
    enum_Security_Attivita[enum_Security_Attivita["Gest_Magazzino"] = 10] = "Gest_Magazzino";
    enum_Security_Attivita[enum_Security_Attivita["Agenda_AccessoMenu"] = 11] = "Agenda_AccessoMenu";
    enum_Security_Attivita[enum_Security_Attivita["Gest_CartografiaAziendale"] = 12] = "Gest_CartografiaAziendale";
    /**
     * IN SCRITTURA:
     * - Usato nella pagina Utenti e Permessi per modificare le impostazioni utente
     */
    enum_Security_Attivita[enum_Security_Attivita["Gest_UtentiImpostazioni"] = 13] = "Gest_UtentiImpostazioni";
    // BUCO 14 15 16 17
    enum_Security_Attivita[enum_Security_Attivita["Gest_ImpiantiVegetali"] = 18] = "Gest_ImpiantiVegetali";
    enum_Security_Attivita[enum_Security_Attivita["Gest_Prodotti"] = 19] = "Gest_Prodotti";
    enum_Security_Attivita[enum_Security_Attivita["Gest_Stalle"] = 20] = "Gest_Stalle";
    enum_Security_Attivita[enum_Security_Attivita["Gest_AnalisiCosti"] = 21] = "Gest_AnalisiCosti";
    enum_Security_Attivita[enum_Security_Attivita["Gest_ValidazioneDati"] = 22] = "Gest_ValidazioneDati";
    enum_Security_Attivita[enum_Security_Attivita["Gest_Certificati_AccessoMenu"] = 23] = "Gest_Certificati_AccessoMenu";
    enum_Security_Attivita[enum_Security_Attivita["Gest_Certificati_AttivaDisattiva"] = 24] = "Gest_Certificati_AttivaDisattiva";
    enum_Security_Attivita[enum_Security_Attivita["Gest_Certificati_M005"] = 25] = "Gest_Certificati_M005";
    enum_Security_Attivita[enum_Security_Attivita["Gest_Certificati_M006"] = 26] = "Gest_Certificati_M006";
    enum_Security_Attivita[enum_Security_Attivita["Gest_Certificati_M007"] = 27] = "Gest_Certificati_M007";
    enum_Security_Attivita[enum_Security_Attivita["Gest_Certificati_M014"] = 28] = "Gest_Certificati_M014";
    enum_Security_Attivita[enum_Security_Attivita["Gest_CartellaAziendale_PAP_Vegetale"] = 29] = "Gest_CartellaAziendale_PAP_Vegetale";
    enum_Security_Attivita[enum_Security_Attivita["Gest_CartellaAziendale_Notifiche"] = 30] = "Gest_CartellaAziendale_Notifiche";
    enum_Security_Attivita[enum_Security_Attivita["Gest_CartellaAziendale_VisiteIspettive"] = 31] = "Gest_CartellaAziendale_VisiteIspettive";
    enum_Security_Attivita[enum_Security_Attivita["Gest_CartellaAziendale_Irregolarita"] = 32] = "Gest_CartellaAziendale_Irregolarita";
    enum_Security_Attivita[enum_Security_Attivita["Gest_Ingredienti"] = 33] = "Gest_Ingredienti";
    enum_Security_Attivita[enum_Security_Attivita["Gest_CartellaAziendale_DelibereComm"] = 34] = "Gest_CartellaAziendale_DelibereComm";
    enum_Security_Attivita[enum_Security_Attivita["Gest_CartellaAziendale_PAP_Zootecnico"] = 35] = "Gest_CartellaAziendale_PAP_Zootecnico";
    enum_Security_Attivita[enum_Security_Attivita["Gest_CartellaAziendale_PAP_Preparazioni"] = 36] = "Gest_CartellaAziendale_PAP_Preparazioni";
    enum_Security_Attivita[enum_Security_Attivita["Gest_CartellaAziendale_Deroghe"] = 37] = "Gest_CartellaAziendale_Deroghe";
    enum_Security_Attivita[enum_Security_Attivita["Gest_CartellaAziendale_AccessoMenu"] = 38] = "Gest_CartellaAziendale_AccessoMenu";
    enum_Security_Attivita[enum_Security_Attivita["Gest_CartellaAziendale_CompartoFiliera"] = 39] = "Gest_CartellaAziendale_CompartoFiliera";
    enum_Security_Attivita[enum_Security_Attivita["Gest_Messaggi_SegreteriaTecnica"] = 40] = "Gest_Messaggi_SegreteriaTecnica";
    // ??????????????
    // Ricezione_Messaggi_UST = 40
    // ManutenzioneArchivi_CoefficientiUBA = 41
    enum_Security_Attivita[enum_Security_Attivita["Gest_CartellaAziendale_PeriodiControllo"] = 42] = "Gest_CartellaAziendale_PeriodiControllo";
    enum_Security_Attivita[enum_Security_Attivita["ManutenzioneArchivi_SuperficieParticelle"] = 43] = "ManutenzioneArchivi_SuperficieParticelle";
    enum_Security_Attivita[enum_Security_Attivita["ManutenzioneArchivi_AccessoMenu"] = 44] = "ManutenzioneArchivi_AccessoMenu";
    // BUCO 45
    enum_Security_Attivita[enum_Security_Attivita["ManutenzioneArchivi_ModificaPIVA"] = 46] = "ManutenzioneArchivi_ModificaPIVA";
    enum_Security_Attivita[enum_Security_Attivita["ManutenzioneArchivi_GestioneVarieta"] = 47] = "ManutenzioneArchivi_GestioneVarieta";
    enum_Security_Attivita[enum_Security_Attivita["ManutenzioneArchivi_GestioneFormulati"] = 48] = "ManutenzioneArchivi_GestioneFormulati";
    enum_Security_Attivita[enum_Security_Attivita["ManutenzioneArchivi_GestioneDisciplinari"] = 49] = "ManutenzioneArchivi_GestioneDisciplinari";
    // ManutenzioneArchivi_ImportiSpecieVegetali = 50
    // ManutenzioneArchivi_GestioneFasiFenologiche = 51
    // ManutenzioneArchivi_GestioneCalibriFrutti = 52
    // ManutenzioneArchivi_ImportiQuoteControllo = 53
    // BUCO 54
    // ManutenzioneArchivi_GestioneIndiciMaturita = 55
    enum_Security_Attivita[enum_Security_Attivita["Anagrafica_Impresa"] = 56] = "Anagrafica_Impresa";
    enum_Security_Attivita[enum_Security_Attivita["Anagrafica_CentroAziendale"] = 57] = "Anagrafica_CentroAziendale";
    enum_Security_Attivita[enum_Security_Attivita["Anagrafica_Campo"] = 58] = "Anagrafica_Campo";
    enum_Security_Attivita[enum_Security_Attivita["Anagrafica_Appezzamento"] = 59] = "Anagrafica_Appezzamento";
    enum_Security_Attivita[enum_Security_Attivita["Anagrafica_Impianto"] = 60] = "Anagrafica_Impianto";
    enum_Security_Attivita[enum_Security_Attivita["Anagrafica_Fabbricato"] = 61] = "Anagrafica_Fabbricato";
    enum_Security_Attivita[enum_Security_Attivita["Anagrafica_ParticellaCatastale"] = 62] = "Anagrafica_ParticellaCatastale";
    enum_Security_Attivita[enum_Security_Attivita["Anagrafica_Contatto"] = 63] = "Anagrafica_Contatto";
    enum_Security_Attivita[enum_Security_Attivita["Anagrafica_ParcoMacchine"] = 64] = "Anagrafica_ParcoMacchine";
    enum_Security_Attivita[enum_Security_Attivita["ManutenzioneArchivi_SbloccaAnagrafe"] = 65] = "ManutenzioneArchivi_SbloccaAnagrafe";
    // ManutenzioneArchivi_GestioneSpecieAnimali = 66
    enum_Security_Attivita[enum_Security_Attivita["Anagrafica_GestioneAllegati"] = 67] = "Anagrafica_GestioneAllegati";
    // ManutenzioneArchivi_PianificazioneInterventi = 68
    enum_Security_Attivita[enum_Security_Attivita["Agenda_OperazioniMultiAziendali"] = 68] = "Agenda_OperazioniMultiAziendali";
    enum_Security_Attivita[enum_Security_Attivita["ManutenzioneArchivi_MultiCancellazioneInterventi"] = 69] = "ManutenzioneArchivi_MultiCancellazioneInterventi";
    enum_Security_Attivita[enum_Security_Attivita["ManutenzioneArchivi_GestioneFertilizzanti"] = 70] = "ManutenzioneArchivi_GestioneFertilizzanti";
    enum_Security_Attivita[enum_Security_Attivita["Gest_Analisi_AccessoMenu"] = 71] = "Gest_Analisi_AccessoMenu";
    enum_Security_Attivita[enum_Security_Attivita["Gest_Analisi_Cartografia"] = 72] = "Gest_Analisi_Cartografia";
    // ManutenzioneArchivi_GestioneTipologieVarietali = 73
    enum_Security_Attivita[enum_Security_Attivita["ManutenzioneArchivi_GestioneSpecieVegetali"] = 74] = "ManutenzioneArchivi_GestioneSpecieVegetali";
    enum_Security_Attivita[enum_Security_Attivita["Stampe_Esportazione_OP_Inv"] = 75] = "Stampe_Esportazione_OP_Inv";
    enum_Security_Attivita[enum_Security_Attivita["Stampe_Esportatore_Universale"] = 76] = "Stampe_Esportatore_Universale";
    enum_Security_Attivita[enum_Security_Attivita["SupportoDecisioni_AccessoMenu"] = 77] = "SupportoDecisioni_AccessoMenu";
    enum_Security_Attivita[enum_Security_Attivita["SupportoDecisioni_PianoConcimazione"] = 78] = "SupportoDecisioni_PianoConcimazione";
    enum_Security_Attivita[enum_Security_Attivita["Agenda_Operazioni_Blocco"] = 79] = "Agenda_Operazioni_Blocco";
    enum_Security_Attivita[enum_Security_Attivita["Agenda_Operazioni_Sblocco"] = 80] = "Agenda_Operazioni_Sblocco";
    enum_Security_Attivita[enum_Security_Attivita["ManutenzioneArchivi_GestioneMigrazionePoliennale"] = 81] = "ManutenzioneArchivi_GestioneMigrazionePoliennale";
    // Report Riconversione Varietale x AgriBologna
    enum_Security_Attivita[enum_Security_Attivita["Stampe_Riconversione_Varietale"] = 82] = "Stampe_Riconversione_Varietale";
    enum_Security_Attivita[enum_Security_Attivita["VerificaConformita_Richieste"] = 83] = "VerificaConformita_Richieste";
    enum_Security_Attivita[enum_Security_Attivita["VerificaConformita_Gestione"] = 84] = "VerificaConformita_Gestione";
    enum_Security_Attivita[enum_Security_Attivita["ManutenzioneArchivi_RevisioneDB"] = 85] = "ManutenzioneArchivi_RevisioneDB";
    // Esportazione Rintraccio x ARP
    enum_Security_Attivita[enum_Security_Attivita["Stampe_Esportazione_Rintraccio"] = 86] = "Stampe_Esportazione_Rintraccio";
    // Report Impegno Produzione Soci x AgriBologna
    enum_Security_Attivita[enum_Security_Attivita["Stampe_Impegno_Produzione_Soci"] = 87] = "Stampe_Impegno_Produzione_Soci";
    enum_Security_Attivita[enum_Security_Attivita["Stampe_Esportazione_OP_Gest"] = 88] = "Stampe_Esportazione_OP_Gest";
    enum_Security_Attivita[enum_Security_Attivita["ManutenzioneArchivi_ImportaAnagrafiche_XLS2GIAS"] = 89] = "ManutenzioneArchivi_ImportaAnagrafiche_XLS2GIAS";
    enum_Security_Attivita[enum_Security_Attivita["Gest_Ricette"] = 90] = "Gest_Ricette";
    enum_Security_Attivita[enum_Security_Attivita["Anagrafica_RapportiContabili"] = 91] = "Anagrafica_RapportiContabili";
    // Stampe_Bolle_Fatture = 92
    enum_Security_Attivita[enum_Security_Attivita["Stampe_Contabilita"] = 92] = "Stampe_Contabilita";
    enum_Security_Attivita[enum_Security_Attivita["ACC_Configurazione"] = 93] = "ACC_Configurazione";
    enum_Security_Attivita[enum_Security_Attivita["ACC_Promozioni"] = 94] = "ACC_Promozioni";
    enum_Security_Attivita[enum_Security_Attivita["ACC_Vetrina"] = 95] = "ACC_Vetrina";
    enum_Security_Attivita[enum_Security_Attivita["ACC_AccessoMenu"] = 96] = "ACC_AccessoMenu";
    enum_Security_Attivita[enum_Security_Attivita["ManutenzioneArchivi_CodificaProdottiAziendali"] = 97] = "ManutenzioneArchivi_CodificaProdottiAziendali";
    enum_Security_Attivita[enum_Security_Attivita["ManutenzioneArchivi_ModificaCodContatto"] = 98] = "ManutenzioneArchivi_ModificaCodContatto";
    enum_Security_Attivita[enum_Security_Attivita["ManutenzioneArchivi_ImportaAnagraficheAnimali_XLS2GIAS"] = 99] = "ManutenzioneArchivi_ImportaAnagraficheAnimali_XLS2GIAS";
    enum_Security_Attivita[enum_Security_Attivita["Gest_CartellaAziendale_Condizionalita"] = 100] = "Gest_CartellaAziendale_Condizionalita";
    enum_Security_Attivita[enum_Security_Attivita["ManutenzioneArchivi_Esporta_CodificheCultivar"] = 101] = "ManutenzioneArchivi_Esporta_CodificheCultivar";
    enum_Security_Attivita[enum_Security_Attivita["ManutenzioneArchivi_Esporta_CodificheSpecieVegetali"] = 102] = "ManutenzioneArchivi_Esporta_CodificheSpecieVegetali";
    enum_Security_Attivita[enum_Security_Attivita["Gest_Pianificazione_Produzione_Vegetale"] = 103] = "Gest_Pianificazione_Produzione_Vegetale";
    enum_Security_Attivita[enum_Security_Attivita["Gest_PUA"] = 104] = "Gest_PUA";
    enum_Security_Attivita[enum_Security_Attivita["Stampe_Esportazione_OP_Gest_Coop"] = 105] = "Stampe_Esportazione_OP_Gest_Coop";
    enum_Security_Attivita[enum_Security_Attivita["Registri_Cantina"] = 106] = "Registri_Cantina";
    enum_Security_Attivita[enum_Security_Attivita["ManutenzioneArchivi_Importa_DDTRicevuti"] = 107] = "ManutenzioneArchivi_Importa_DDTRicevuti";
    enum_Security_Attivita[enum_Security_Attivita["ManutenzioneArchivi_Importa_RaccolteConferimenti_DaRintraccio"] = 108] = "ManutenzioneArchivi_Importa_RaccolteConferimenti_DaRintraccio";
    enum_Security_Attivita[enum_Security_Attivita["ManutenzioneArchivi_Importa_DDTRicevuti_AgriOK"] = 109] = "ManutenzioneArchivi_Importa_DDTRicevuti_AgriOK";
    enum_Security_Attivita[enum_Security_Attivita["ManutenzioneArchivi_Importa_Anagrafe_EmiliaRomagna"] = 110] = "ManutenzioneArchivi_Importa_Anagrafe_EmiliaRomagna";
    enum_Security_Attivita[enum_Security_Attivita["ManutenzioneArchivi_EsportaXMLAnagrafiche_GIAS"] = 111] = "ManutenzioneArchivi_EsportaXMLAnagrafiche_GIAS";
    enum_Security_Attivita[enum_Security_Attivita["ManutenzioneArchivi_EsportaConferimenti_JDEdwards"] = 112] = "ManutenzioneArchivi_EsportaConferimenti_JDEdwards";
    enum_Security_Attivita[enum_Security_Attivita["ManutenzioneArchivi_Importa_AGREA"] = 113] = "ManutenzioneArchivi_Importa_AGREA";
    enum_Security_Attivita[enum_Security_Attivita["ManutenzioneArchivi_Importa_AVEPA"] = 114] = "ManutenzioneArchivi_Importa_AVEPA";
    enum_Security_Attivita[enum_Security_Attivita["Contabilita_Operazioni_Blocco"] = 115] = "Contabilita_Operazioni_Blocco";
    enum_Security_Attivita[enum_Security_Attivita["Contabilita_Operazioni_Sblocco"] = 116] = "Contabilita_Operazioni_Sblocco";
    enum_Security_Attivita[enum_Security_Attivita["ManutenzioneArchivi_ImpostazionePasswordServizi"] = 117] = "ManutenzioneArchivi_ImpostazionePasswordServizi";
    enum_Security_Attivita[enum_Security_Attivita["ManutenzioneArchivi_Importa_DDT_Pianocolturale"] = 118] = "ManutenzioneArchivi_Importa_DDT_Pianocolturale";
    enum_Security_Attivita[enum_Security_Attivita["Raccolta_Dati_PAC_UMA_Brogliaccio"] = 119] = "Raccolta_Dati_PAC_UMA_Brogliaccio";
    enum_Security_Attivita[enum_Security_Attivita["ManutenzioneArchivi_Importa_Anagrafe_BA"] = 120] = "ManutenzioneArchivi_Importa_Anagrafe_BA";
    enum_Security_Attivita[enum_Security_Attivita["CheckList_Sicurezza_Lavoro"] = 121] = "CheckList_Sicurezza_Lavoro";
    enum_Security_Attivita[enum_Security_Attivita["Report_Accettazione_DaDiversi"] = 122] = "Report_Accettazione_DaDiversi";
    enum_Security_Attivita[enum_Security_Attivita["ManutenzioneArchivi_EsportaConferimentiPomodoro_Agrea"] = 123] = "ManutenzioneArchivi_EsportaConferimentiPomodoro_Agrea";
    enum_Security_Attivita[enum_Security_Attivita["Gest_CartellaAziendale_MonitoraggioCE"] = 124] = "Gest_CartellaAziendale_MonitoraggioCE";
    enum_Security_Attivita[enum_Security_Attivita["ManutenzioneArchivi_BolleAccettazione2AltroCliente"] = 125] = "ManutenzioneArchivi_BolleAccettazione2AltroCliente";
    enum_Security_Attivita[enum_Security_Attivita["Stampe_RegistroCaricoScarico_Pomodoro"] = 126] = "Stampe_RegistroCaricoScarico_Pomodoro";
    enum_Security_Attivita[enum_Security_Attivita["ProfilazioneImpresa"] = 127] = "ProfilazioneImpresa";
    enum_Security_Attivita[enum_Security_Attivita["Utilizzo_Dati_Meteo"] = 128] = "Utilizzo_Dati_Meteo";
    enum_Security_Attivita[enum_Security_Attivita["ManutenzioneArchivi_Importa_UfficiZona"] = 129] = "ManutenzioneArchivi_Importa_UfficiZona";
    enum_Security_Attivita[enum_Security_Attivita["ManutenzioneArchivi_Importa_AGREA_Massiva"] = 130] = "ManutenzioneArchivi_Importa_AGREA_Massiva";
    enum_Security_Attivita[enum_Security_Attivita["PianiCampionamento_GestioneLotti"] = 131] = "PianiCampionamento_GestioneLotti";
    enum_Security_Attivita[enum_Security_Attivita["PianiCampionamento_GestioneWorkFlow"] = 132] = "PianiCampionamento_GestioneWorkFlow";
    enum_Security_Attivita[enum_Security_Attivita["PianiCampionamento_GestioneAnalisi"] = 133] = "PianiCampionamento_GestioneAnalisi";
    enum_Security_Attivita[enum_Security_Attivita["PianiCampionamento_InterrogazioneBloccoSblocco"] = 134] = "PianiCampionamento_InterrogazioneBloccoSblocco";
    enum_Security_Attivita[enum_Security_Attivita["Anagrafica_MultiModificaSupImp"] = 135] = "Anagrafica_MultiModificaSupImp";
    enum_Security_Attivita[enum_Security_Attivita["ManutenzioneArchivi_SincronizzazioneHarvard"] = 136] = "ManutenzioneArchivi_SincronizzazioneHarvard";
    enum_Security_Attivita[enum_Security_Attivita["Profilazione_DefaultSpecie_Globali"] = 137] = "Profilazione_DefaultSpecie_Globali";
    enum_Security_Attivita[enum_Security_Attivita["Gest_CartellaAziendale_GlobalGap"] = 138] = "Gest_CartellaAziendale_GlobalGap";
    enum_Security_Attivita[enum_Security_Attivita["ManutenzioneArchivi_Importa_AGREA_OP"] = 139] = "ManutenzioneArchivi_Importa_AGREA_OP";
    enum_Security_Attivita[enum_Security_Attivita["ManutenzioneArchivi_Import_DDTFatture_Seled"] = 140] = "ManutenzioneArchivi_Import_DDTFatture_Seled";
    enum_Security_Attivita[enum_Security_Attivita["ManutenzioneArchivi_SincronizzazioneArcView"] = 141] = "ManutenzioneArchivi_SincronizzazioneArcView";
    enum_Security_Attivita[enum_Security_Attivita["ManutenzioneArchivi_Importa_Giacenze"] = 142] = "ManutenzioneArchivi_Importa_Giacenze";
    enum_Security_Attivita[enum_Security_Attivita["ManutenzioneArchivi_Importa_AVEPA_Vino"] = 143] = "ManutenzioneArchivi_Importa_AVEPA_Vino";
    enum_Security_Attivita[enum_Security_Attivita["ManutenzioneArchivi_ImportDateRaccolta_Harvard"] = 144] = "ManutenzioneArchivi_ImportDateRaccolta_Harvard";
    /**
     * IN SCRITTURA:
     * - Usato nella pagina Utenti e Profili per visualizzare le statistiche della pagina.
     * -
     */
    enum_Security_Attivita[enum_Security_Attivita["Statistiche_Sito"] = 145] = "Statistiche_Sito";
    enum_Security_Attivita[enum_Security_Attivita["ManutenzioneArchivi_Import_Anagrafiche_Seled"] = 146] = "ManutenzioneArchivi_Import_Anagrafiche_Seled";
    enum_Security_Attivita[enum_Security_Attivita["ManutenzioneArchivi_Importa_Notifica_AgriBio"] = 147] = "ManutenzioneArchivi_Importa_Notifica_AgriBio";
    enum_Security_Attivita[enum_Security_Attivita["ManutenzioneArchivi_SincroRaccoltaCCCI"] = 148] = "ManutenzioneArchivi_SincroRaccoltaCCCI";
    enum_Security_Attivita[enum_Security_Attivita["Anagrafica_Appezzamento_CancellazioneMultipla"] = 149] = "Anagrafica_Appezzamento_CancellazioneMultipla";
    enum_Security_Attivita[enum_Security_Attivita["PianiSemina_Tabelle"] = 150] = "PianiSemina_Tabelle";
    enum_Security_Attivita[enum_Security_Attivita["PianiSemina_Gestione"] = 151] = "PianiSemina_Gestione";
    enum_Security_Attivita[enum_Security_Attivita["Meteo_Tabelle"] = 152] = "Meteo_Tabelle";
    enum_Security_Attivita[enum_Security_Attivita["Gestione_Etichette"] = 153] = "Gestione_Etichette";
    enum_Security_Attivita[enum_Security_Attivita["PianiCampionamento_GestioneAnalisiXLaboratori"] = 154] = "PianiCampionamento_GestioneAnalisiXLaboratori";
    enum_Security_Attivita[enum_Security_Attivita["ManutenzioneArchivi_SincroCatastoImportPianificazioneAccessOP"] = 155] = "ManutenzioneArchivi_SincroCatastoImportPianificazioneAccessOP";
    enum_Security_Attivita[enum_Security_Attivita["Gest_CartellaAziendale_CheckCOOP"] = 156] = "Gest_CartellaAziendale_CheckCOOP";
    enum_Security_Attivita[enum_Security_Attivita["PianiCampionamento_GestioneImpostazioni"] = 157] = "PianiCampionamento_GestioneImpostazioni";
    enum_Security_Attivita[enum_Security_Attivita["PianiCampionamento_GestionePianoProduttivo"] = 158] = "PianiCampionamento_GestionePianoProduttivo";
    enum_Security_Attivita[enum_Security_Attivita["PianiCampionamento_GestionePianoCampioni"] = 159] = "PianiCampionamento_GestionePianoCampioni";
    enum_Security_Attivita[enum_Security_Attivita["PianiCampionamento_ControlloValiditaCapitolati"] = 160] = "PianiCampionamento_ControlloValiditaCapitolati";
    enum_Security_Attivita[enum_Security_Attivita["PianiCampionamento_Menu"] = 161] = "PianiCampionamento_Menu";
    enum_Security_Attivita[enum_Security_Attivita["PianiCampionamento_ControlloValiditaQDC"] = 162] = "PianiCampionamento_ControlloValiditaQDC";
    enum_Security_Attivita[enum_Security_Attivita["PianiCampionamento_GestioneBloccoSblocco"] = 163] = "PianiCampionamento_GestioneBloccoSblocco";
    enum_Security_Attivita[enum_Security_Attivita["PianiCampionamento_GestioneLaboratori"] = 164] = "PianiCampionamento_GestioneLaboratori";
    enum_Security_Attivita[enum_Security_Attivita["SMART_RegistrazioneSmart"] = 165] = "SMART_RegistrazioneSmart";
    enum_Security_Attivita[enum_Security_Attivita["SMART_AgendaOperazioniColturali"] = 166] = "SMART_AgendaOperazioniColturali";
    enum_Security_Attivita[enum_Security_Attivita["SMART_GiasProfitosan"] = 167] = "SMART_GiasProfitosan";
    enum_Security_Attivita[enum_Security_Attivita["SMART_GIS"] = 168] = "SMART_GIS";
    enum_Security_Attivita[enum_Security_Attivita["SMART_gestioneAnagrafica"] = 169] = "SMART_gestioneAnagrafica";
    enum_Security_Attivita[enum_Security_Attivita["SMART_NuovaAzienda"] = 170] = "SMART_NuovaAzienda";
    enum_Security_Attivita[enum_Security_Attivita["SMART_Nuovo_Centro"] = 171] = "SMART_Nuovo_Centro";
    enum_Security_Attivita[enum_Security_Attivita["SMART_NuovoAppezzamento"] = 172] = "SMART_NuovoAppezzamento";
    enum_Security_Attivita[enum_Security_Attivita["SMART_NuovoContatto"] = 173] = "SMART_NuovoContatto";
    enum_Security_Attivita[enum_Security_Attivita["SMART_Gias"] = 174] = "SMART_Gias";
    enum_Security_Attivita[enum_Security_Attivita["SMART_Menu"] = 175] = "SMART_Menu";
    enum_Security_Attivita[enum_Security_Attivita["SMART_GestioneAnagrafica_Nodo"] = 176] = "SMART_GestioneAnagrafica_Nodo";
    enum_Security_Attivita[enum_Security_Attivita["ManutenzioneArchivi_AllineaCarenze"] = 177] = "ManutenzioneArchivi_AllineaCarenze";
    enum_Security_Attivita[enum_Security_Attivita["manutenzioneArchivi_Esportazione_SIGPA"] = 178] = "manutenzioneArchivi_Esportazione_SIGPA";
    enum_Security_Attivita[enum_Security_Attivita["Rilievo_Attivita"] = 179] = "Rilievo_Attivita";
    enum_Security_Attivita[enum_Security_Attivita["Blocco_Modifica_PianificazioneVegetale"] = 180] = "Blocco_Modifica_PianificazioneVegetale";
    enum_Security_Attivita[enum_Security_Attivita["Creazione_Automatica_CentriAziendali"] = 181] = "Creazione_Automatica_CentriAziendali";
    enum_Security_Attivita[enum_Security_Attivita["PianiCampionamento_Filtrone"] = 182] = "PianiCampionamento_Filtrone";
    enum_Security_Attivita[enum_Security_Attivita["Budget_Menu"] = 183] = "Budget_Menu";
    enum_Security_Attivita[enum_Security_Attivita["Budget_Testata"] = 184] = "Budget_Testata";
    enum_Security_Attivita[enum_Security_Attivita["Budget_Import_Da_Anagrafe"] = 185] = "Budget_Import_Da_Anagrafe";
    enum_Security_Attivita[enum_Security_Attivita["Budget_Dettagli_del_Piano"] = 186] = "Budget_Dettagli_del_Piano";
    enum_Security_Attivita[enum_Security_Attivita["Report_Incongruenze_CatastoVSAgrea"] = 187] = "Report_Incongruenze_CatastoVSAgrea";
    enum_Security_Attivita[enum_Security_Attivita["Gestione_Servizi"] = 188] = "Gestione_Servizi";
    enum_Security_Attivita[enum_Security_Attivita["Stampa_Inglese"] = 189] = "Stampa_Inglese";
    enum_Security_Attivita[enum_Security_Attivita["Stampe_Italiano"] = 190] = "Stampe_Italiano";
    enum_Security_Attivita[enum_Security_Attivita["ManutenzioneArchivi_Importazione_Massiva_Anagrafe_BA"] = 191] = "ManutenzioneArchivi_Importazione_Massiva_Anagrafe_BA";
    enum_Security_Attivita[enum_Security_Attivita["ManutenzioneArchivi_Gias_2_Gias"] = 192] = "ManutenzioneArchivi_Gias_2_Gias";
    enum_Security_Attivita[enum_Security_Attivita["LinkGiasStrandard"] = 193] = "LinkGiasStrandard";
    enum_Security_Attivita[enum_Security_Attivita["ManutenzioneArchivi_ImportaMagazzino_XmlPubblico"] = 194] = "ManutenzioneArchivi_ImportaMagazzino_XmlPubblico";
    enum_Security_Attivita[enum_Security_Attivita["ManutenzioneArchivi_Sincronizzatore_Apofruit"] = 195] = "ManutenzioneArchivi_Sincronizzatore_Apofruit";
    enum_Security_Attivita[enum_Security_Attivita["Rilevamento_Smart_Gis"] = 196] = "Rilevamento_Smart_Gis";
    enum_Security_Attivita[enum_Security_Attivita["ManutenzioneArchivi_Sincronizzatore_Valdoca"] = 197] = "ManutenzioneArchivi_Sincronizzatore_Valdoca";
    enum_Security_Attivita[enum_Security_Attivita["Scadenziario_Menu"] = 198] = "Scadenziario_Menu";
    enum_Security_Attivita[enum_Security_Attivita["Precision_Farming"] = 199] = "Precision_Farming";
    enum_Security_Attivita[enum_Security_Attivita["Link_AgronicaSementi"] = 200] = "Link_AgronicaSementi";
    enum_Security_Attivita[enum_Security_Attivita["Modifica_Contatti_Pubblici"] = 201] = "Modifica_Contatti_Pubblici";
    enum_Security_Attivita[enum_Security_Attivita["Cartografia_Catasto"] = 202] = "Cartografia_Catasto";
    enum_Security_Attivita[enum_Security_Attivita["Cartografia_Esporta_Dati"] = 203] = "Cartografia_Esporta_Dati";
    enum_Security_Attivita[enum_Security_Attivita["ManutenzioneArchivi_Importazione_Anagrafiche_Agenda_Seled"] = 204] = "ManutenzioneArchivi_Importazione_Anagrafiche_Agenda_Seled";
    enum_Security_Attivita[enum_Security_Attivita["ManutenzioneArchivi_Importazione_Anagrafiche_Viticolo_Avepa"] = 205] = "ManutenzioneArchivi_Importazione_Anagrafiche_Viticolo_Avepa";
    enum_Security_Attivita[enum_Security_Attivita["SupportoDecisioni_PianoConcimazioneMassivo"] = 206] = "SupportoDecisioni_PianoConcimazioneMassivo";
    enum_Security_Attivita[enum_Security_Attivita["PrenotazionePiante_Menu"] = 207] = "PrenotazionePiante_Menu";
    enum_Security_Attivita[enum_Security_Attivita["Creazione_Automatica_SemilavoratiVegetali"] = 208] = "Creazione_Automatica_SemilavoratiVegetali";
    enum_Security_Attivita[enum_Security_Attivita["ManutenzioneArchivi_Importazione_Catasto_Uniforma"] = 209] = "ManutenzioneArchivi_Importazione_Catasto_Uniforma";
    enum_Security_Attivita[enum_Security_Attivita["Consultazione_Meteo_Dati_Stazioni_Metos"] = 210] = "Consultazione_Meteo_Dati_Stazioni_Metos";
    enum_Security_Attivita[enum_Security_Attivita["ManutenzioneArchivi_Importazione_Catasto_CantinaSoave"] = 211] = "ManutenzioneArchivi_Importazione_Catasto_CantinaSoave";
    // ManutenzioneArchivi_Importazione_Catasto_OPTA = 212
    enum_Security_Attivita[enum_Security_Attivita["PROFITOSAN_Elenco_Prodotti_DPI"] = 213] = "PROFITOSAN_Elenco_Prodotti_DPI";
    enum_Security_Attivita[enum_Security_Attivita["Gest_CartellaAziendale_Check_SchedaTecnicaTTI"] = 214] = "Gest_CartellaAziendale_Check_SchedaTecnicaTTI";
    enum_Security_Attivita[enum_Security_Attivita["Gest_CartellaAziendale_Check_SchedaControlliTTI"] = 215] = "Gest_CartellaAziendale_Check_SchedaControlliTTI";
    enum_Security_Attivita[enum_Security_Attivita["manutenzioneArchivi_VerificaEsportazioneAgendaVerso_SIGPA"] = 216] = "manutenzioneArchivi_VerificaEsportazioneAgendaVerso_SIGPA";
    enum_Security_Attivita[enum_Security_Attivita["ManutenzioneArchivi_Importazione_OptaMacchine"] = 217] = "ManutenzioneArchivi_Importazione_OptaMacchine";
    enum_Security_Attivita[enum_Security_Attivita["ManutenzioneArchivi_Importazione_OptaParticelle"] = 218] = "ManutenzioneArchivi_Importazione_OptaParticelle";
    enum_Security_Attivita[enum_Security_Attivita["Gest_Pianificazione_Produzione_Vegetale_Ribalta"] = 219] = "Gest_Pianificazione_Produzione_Vegetale_Ribalta";
    enum_Security_Attivita[enum_Security_Attivita["ManutenzioneArchivi_Importa_Anagrafe_BA_Veneto"] = 220] = "ManutenzioneArchivi_Importa_Anagrafe_BA_Veneto";
    enum_Security_Attivita[enum_Security_Attivita["Esportazione_RIBA_CBI"] = 221] = "Esportazione_RIBA_CBI";
    enum_Security_Attivita[enum_Security_Attivita["NonConformita"] = 222] = "NonConformita";
    enum_Security_Attivita[enum_Security_Attivita["Agenda_Operazione_Di_Cura"] = 223] = "Agenda_Operazione_Di_Cura";
    enum_Security_Attivita[enum_Security_Attivita["ManutenzioneArchivi_Importazione_Anagrafiche_Brogliaccio_SIAN"] = 224] = "ManutenzioneArchivi_Importazione_Anagrafiche_Brogliaccio_SIAN";
    enum_Security_Attivita[enum_Security_Attivita["SupportoDecisioni_LaboratorioControlloQualita"] = 225] = "SupportoDecisioni_LaboratorioControlloQualita";
    enum_Security_Attivita[enum_Security_Attivita["Stampe_Esportazione_OP_Produttori"] = 226] = "Stampe_Esportazione_OP_Produttori";
    enum_Security_Attivita[enum_Security_Attivita["Stampe_Esportazione_OP_Catasto"] = 227] = "Stampe_Esportazione_OP_Catasto";
    enum_Security_Attivita[enum_Security_Attivita["Rintraccio_Operazione_Di_Cura"] = 228] = "Rintraccio_Operazione_Di_Cura";
    enum_Security_Attivita[enum_Security_Attivita["ManutenzioneArchivi_Importa_AVEPA_Catasto"] = 229] = "ManutenzioneArchivi_Importa_AVEPA_Catasto";
    enum_Security_Attivita[enum_Security_Attivita["Stampa_MovimentiMagazziniExcel"] = 230] = "Stampa_MovimentiMagazziniExcel";
    enum_Security_Attivita[enum_Security_Attivita["SupportoDecisioni_LaboratorioControlloQualita_CreaApriDoc"] = 231] = "SupportoDecisioni_LaboratorioControlloQualita_CreaApriDoc";
    enum_Security_Attivita[enum_Security_Attivita["SupportoDecisioni_LaboratorioControlloQualita_Impostazioni"] = 232] = "SupportoDecisioni_LaboratorioControlloQualita_Impostazioni";
    enum_Security_Attivita[enum_Security_Attivita["SupportoDecisioni_LaboratorioControlloQualita_FiltraEsporta"] = 233] = "SupportoDecisioni_LaboratorioControlloQualita_FiltraEsporta";
    enum_Security_Attivita[enum_Security_Attivita["ManutenzioneArchivi_Importazione_Anagrafiche_COFRUTA"] = 234] = "ManutenzioneArchivi_Importazione_Anagrafiche_COFRUTA";
    enum_Security_Attivita[enum_Security_Attivita["Gest_CartellaAziendale_Check_AnalisiDatiCura"] = 235] = "Gest_CartellaAziendale_Check_AnalisiDatiCura";
    enum_Security_Attivita[enum_Security_Attivita["ManutenzioneArchivi_Importazione_Anagrafiche_APOL"] = 236] = "ManutenzioneArchivi_Importazione_Anagrafiche_APOL";
    enum_Security_Attivita[enum_Security_Attivita["AnalisiSchedeRilievi"] = 237] = "AnalisiSchedeRilievi";
    enum_Security_Attivita[enum_Security_Attivita["Rintracciabilit\u00E0"] = 238] = "Rintracciabilit\u00E0";
    enum_Security_Attivita[enum_Security_Attivita["Stampa_SchedaCampagna_Massiva"] = 240] = "Stampa_SchedaCampagna_Massiva";
    enum_Security_Attivita[enum_Security_Attivita["Gestione_Ordini_Piante"] = 241] = "Gestione_Ordini_Piante";
    enum_Security_Attivita[enum_Security_Attivita["ManutenzioneArchivi_Importazione_Anagrafiche_APOT"] = 242] = "ManutenzioneArchivi_Importazione_Anagrafiche_APOT";
    /**
     * IN SCRITTURA:
     * - Usato nella pagina Utenti e Permessi per creare e modificare profili utenti
     */
    enum_Security_Attivita[enum_Security_Attivita["Gest_UtentiProfili"] = 243] = "Gest_UtentiProfili";
    /**
     * IN SCRITTURA:
     * - Usato nella pagina Utenti e Permessi per creare e modificare gruppi utenti e le impostazioni collegate a essi
     */
    enum_Security_Attivita[enum_Security_Attivita["Gest_UtentiGruppi"] = 244] = "Gest_UtentiGruppi";
    enum_Security_Attivita[enum_Security_Attivita["ManutenzioneArchivi_Importazione_Anagrafiche_SISCO"] = 245] = "ManutenzioneArchivi_Importazione_Anagrafiche_SISCO";
    enum_Security_Attivita[enum_Security_Attivita["Macchine_Assegnazione_Pubblica"] = 246] = "Macchine_Assegnazione_Pubblica";
    enum_Security_Attivita[enum_Security_Attivita["Gest_UtentiAgendaBlocchi"] = 247] = "Gest_UtentiAgendaBlocchi";
    enum_Security_Attivita[enum_Security_Attivita["ManutenzioneArchivi_Importazione_Anagrafiche_Casalasco"] = 248] = "ManutenzioneArchivi_Importazione_Anagrafiche_Casalasco";
    enum_Security_Attivita[enum_Security_Attivita["ReportPercorsi"] = 249] = "ReportPercorsi";
    enum_Security_Attivita[enum_Security_Attivita["EsportazioneZespri"] = 250] = "EsportazioneZespri";
    enum_Security_Attivita[enum_Security_Attivita["EsportazioneSQNPI"] = 251] = "EsportazioneSQNPI";
    enum_Security_Attivita[enum_Security_Attivita["CheckList_Pratiche_Ecologiche_APOT"] = 252] = "CheckList_Pratiche_Ecologiche_APOT";
    enum_Security_Attivita[enum_Security_Attivita["CheckList_Formazione"] = 253] = "CheckList_Formazione";
    enum_Security_Attivita[enum_Security_Attivita["Gestione_Rifiuti"] = 254] = "Gestione_Rifiuti";
    enum_Security_Attivita[enum_Security_Attivita["ManutenzioneArchivi_MultiModificaInterventi"] = 255] = "ManutenzioneArchivi_MultiModificaInterventi";
    enum_Security_Attivita[enum_Security_Attivita["NonConformita_Impostazioni"] = 256] = "NonConformita_Impostazioni";
    enum_Security_Attivita[enum_Security_Attivita["NonConformita_FiltraEsporta"] = 257] = "NonConformita_FiltraEsporta";
    enum_Security_Attivita[enum_Security_Attivita["NonConformita_Anagrafiche"] = 258] = "NonConformita_Anagrafiche";
    enum_Security_Attivita[enum_Security_Attivita["Cartografia_BufferZone"] = 259] = "Cartografia_BufferZone";
    enum_Security_Attivita[enum_Security_Attivita["Gest_UtentiImpostazioni_Avanzate"] = 265] = "Gest_UtentiImpostazioni_Avanzate";
    enum_Security_Attivita[enum_Security_Attivita["ManutenzioneArchivi_Importa_ARPEA"] = 279] = "ManutenzioneArchivi_Importa_ARPEA";
    enum_Security_Attivita[enum_Security_Attivita["FiltraEdEsporta_PianiColturali"] = 280] = "FiltraEdEsporta_PianiColturali";
    enum_Security_Attivita[enum_Security_Attivita["ManutenzioneArchivi_Importa_ARTEA"] = 288] = "ManutenzioneArchivi_Importa_ARTEA";
    enum_Security_Attivita[enum_Security_Attivita["SupportoDecisioni_VerificaConformitaIAF"] = 289] = "SupportoDecisioni_VerificaConformitaIAF";
    enum_Security_Attivita[enum_Security_Attivita["Esportazione_RegioneER"] = 290] = "Esportazione_RegioneER";
    enum_Security_Attivita[enum_Security_Attivita["Importazione_SIARL"] = 291] = "Importazione_SIARL";
    enum_Security_Attivita[enum_Security_Attivita["ManutenzioneArchivi_Importazione_Anagrafiche_CIO"] = 292] = "ManutenzioneArchivi_Importazione_Anagrafiche_CIO";
    enum_Security_Attivita[enum_Security_Attivita["ManutenzioneArchivi_EsportazioneConferimentiFF"] = 293] = "ManutenzioneArchivi_EsportazioneConferimentiFF";
    enum_Security_Attivita[enum_Security_Attivita["ManutenzioneArchivi_Importa_AGEA_RealTime"] = 296] = "ManutenzioneArchivi_Importa_AGEA_RealTime";
    enum_Security_Attivita[enum_Security_Attivita["ManutenzioneArchivi_Importa_AGEA_Coordinamento_Massiva"] = 298] = "ManutenzioneArchivi_Importa_AGEA_Coordinamento_Massiva";
    enum_Security_Attivita[enum_Security_Attivita["ManutenzioneArchivi_Importa_AGEA_GIS"] = 299] = "ManutenzioneArchivi_Importa_AGEA_GIS";
    // ############################################################
    // ------------ F&F Campionamento e Liquidazioni ------------
    enum_Security_Attivita[enum_Security_Attivita["FrashAndFood"] = 260] = "FrashAndFood";
    enum_Security_Attivita[enum_Security_Attivita["FF_Conferimenti"] = 261] = "FF_Conferimenti";
    enum_Security_Attivita[enum_Security_Attivita["FF_CampionamentoLiquidazioni_Anag"] = 262] = "FF_CampionamentoLiquidazioni_Anag";
    enum_Security_Attivita[enum_Security_Attivita["FF_CampionamentoLiquidazioni_Movimenti"] = 263] = "FF_CampionamentoLiquidazioni_Movimenti";
    enum_Security_Attivita[enum_Security_Attivita["FF_CampionamentoLiquidazioni_Liquidazioni"] = 264] = "FF_CampionamentoLiquidazioni_Liquidazioni";
    enum_Security_Attivita[enum_Security_Attivita["FF_CampionamentoLiquidazioni_ValorUnaTantumAUltimoListino"] = 422] = "FF_CampionamentoLiquidazioni_ValorUnaTantumAUltimoListino";
    // ------------ F&F Campionamento e Liquidazioni ------------
    enum_Security_Attivita[enum_Security_Attivita["NonConformita_Testata_Crea"] = 266] = "NonConformita_Testata_Crea";
    enum_Security_Attivita[enum_Security_Attivita["NonConformita_Testata_Modifica"] = 267] = "NonConformita_Testata_Modifica";
    enum_Security_Attivita[enum_Security_Attivita["NonConformita_Testata_Chiudi"] = 268] = "NonConformita_Testata_Chiudi";
    enum_Security_Attivita[enum_Security_Attivita["NonConformita_Testata_Elimina"] = 269] = "NonConformita_Testata_Elimina";
    enum_Security_Attivita[enum_Security_Attivita["NonConformita_Fase_Crea"] = 270] = "NonConformita_Fase_Crea";
    enum_Security_Attivita[enum_Security_Attivita["NonConformita_Fase_Modifica"] = 271] = "NonConformita_Fase_Modifica";
    enum_Security_Attivita[enum_Security_Attivita["NonConformita_Fase_Chiudi"] = 272] = "NonConformita_Fase_Chiudi";
    enum_Security_Attivita[enum_Security_Attivita["NonConformita_Fase_Elimina"] = 273] = "NonConformita_Fase_Elimina";
    enum_Security_Attivita[enum_Security_Attivita["Analisi_Dati_Meteo"] = 274] = "Analisi_Dati_Meteo";
    enum_Security_Attivita[enum_Security_Attivita["Analisi_Curve_Maturazione"] = 275] = "Analisi_Curve_Maturazione";
    enum_Security_Attivita[enum_Security_Attivita["NonConformita_Lista"] = 276] = "NonConformita_Lista";
    enum_Security_Attivita[enum_Security_Attivita["NonConformita_Lista_AncheDiAltriUtenti"] = 277] = "NonConformita_Lista_AncheDiAltriUtenti";
    enum_Security_Attivita[enum_Security_Attivita["Analisi_Modelli_Previsionali"] = 278] = "Analisi_Modelli_Previsionali";
    enum_Security_Attivita[enum_Security_Attivita["GestioneAvanzataETabelleLookUp"] = 281] = "GestioneAvanzataETabelleLookUp";
    enum_Security_Attivita[enum_Security_Attivita["ReportSostenibilit\u00E0"] = 282] = "ReportSostenibilit\u00E0";
    enum_Security_Attivita[enum_Security_Attivita["Scadenzario_Lista"] = 283] = "Scadenzario_Lista";
    enum_Security_Attivita[enum_Security_Attivita["Scadenzario_IndiciRicerca"] = 284] = "Scadenzario_IndiciRicerca";
    enum_Security_Attivita[enum_Security_Attivita["Visite_Lista"] = 285] = "Visite_Lista";
    enum_Security_Attivita[enum_Security_Attivita["Visite_Anagrafiche"] = 286] = "Visite_Anagrafiche";
    enum_Security_Attivita[enum_Security_Attivita["invioSMS"] = 287] = "invioSMS";
    enum_Security_Attivita[enum_Security_Attivita["Scadenzario_Impostazioni"] = 294] = "Scadenzario_Impostazioni";
    enum_Security_Attivita[enum_Security_Attivita["Gest_Prodotti_VisibilitaPubblica"] = 295] = "Gest_Prodotti_VisibilitaPubblica";
    enum_Security_Attivita[enum_Security_Attivita["ManutenzioneArchivi_Import_Utenti_Da_Excel"] = 297] = "ManutenzioneArchivi_Import_Utenti_Da_Excel";
    // ############################################################
    // ------------ AGRONICA MANUTENZIONE ------------
    // i permessi dell'Agronica Manutenzione vanno dal 300 al 349
    enum_Security_Attivita[enum_Security_Attivita["AgronicaManutenzione_AccessoMenu"] = 300] = "AgronicaManutenzione_AccessoMenu";
    enum_Security_Attivita[enum_Security_Attivita["AgronicaManutenzione_SpecieVegetali"] = 301] = "AgronicaManutenzione_SpecieVegetali";
    enum_Security_Attivita[enum_Security_Attivita["AgronicaManutenzione_Varieta"] = 302] = "AgronicaManutenzione_Varieta";
    enum_Security_Attivita[enum_Security_Attivita["AgronicaManutenzione_CalibriFrutti"] = 303] = "AgronicaManutenzione_CalibriFrutti";
    enum_Security_Attivita[enum_Security_Attivita["AgronicaManutenzione_IndiciMaturita"] = 304] = "AgronicaManutenzione_IndiciMaturita";
    enum_Security_Attivita[enum_Security_Attivita["AgronicaManutenzione_FasiFenologiche"] = 305] = "AgronicaManutenzione_FasiFenologiche";
    enum_Security_Attivita[enum_Security_Attivita["AgronicaManutenzione_TipologieVarietali"] = 306] = "AgronicaManutenzione_TipologieVarietali";
    enum_Security_Attivita[enum_Security_Attivita["AgronicaManutenzione_GruppoFinalita"] = 307] = "AgronicaManutenzione_GruppoFinalita";
    enum_Security_Attivita[enum_Security_Attivita["AgronicaManutenzione_FormeAllevamento"] = 308] = "AgronicaManutenzione_FormeAllevamento";
    enum_Security_Attivita[enum_Security_Attivita["AgronicaManutenzione_ImpiantiIrrigazione"] = 309] = "AgronicaManutenzione_ImpiantiIrrigazione";
    enum_Security_Attivita[enum_Security_Attivita["AgronicaManutenzione_Portinnesti"] = 310] = "AgronicaManutenzione_Portinnesti";
    enum_Security_Attivita[enum_Security_Attivita["AgronicaManutenzione_UnitaMisura"] = 311] = "AgronicaManutenzione_UnitaMisura";
    enum_Security_Attivita[enum_Security_Attivita["AgronicaManutenzione_MisuraAvversita"] = 312] = "AgronicaManutenzione_MisuraAvversita";
    enum_Security_Attivita[enum_Security_Attivita["AgronicaManutenzione_Fertilizzanti"] = 313] = "AgronicaManutenzione_Fertilizzanti";
    enum_Security_Attivita[enum_Security_Attivita["AgronicaManutenzione_Formulati"] = 314] = "AgronicaManutenzione_Formulati";
    enum_Security_Attivita[enum_Security_Attivita["AgronicaManutenzione_Disciplinari"] = 315] = "AgronicaManutenzione_Disciplinari";
    enum_Security_Attivita[enum_Security_Attivita["AgronicaManutenzione_CoefficientiUBA"] = 316] = "AgronicaManutenzione_CoefficientiUBA";
    enum_Security_Attivita[enum_Security_Attivita["AgronicaManutenzione_SpecieAnimali"] = 317] = "AgronicaManutenzione_SpecieAnimali";
    // ECC...
    // ------------ AGRONICA MANUTENZIONE ------------
    // ############################################################
    // Fresh & Food Magazzino
    enum_Security_Attivita[enum_Security_Attivita["FF_Magazzino"] = 350] = "FF_Magazzino";
    enum_Security_Attivita[enum_Security_Attivita["FF_Lavorazioni_PC"] = 351] = "FF_Lavorazioni_PC";
    enum_Security_Attivita[enum_Security_Attivita["FF_Lavorazioni_Terminalino"] = 352] = "FF_Lavorazioni_Terminalino";
    // ------------ Fresh & Food Magazzino ------------
    enum_Security_Attivita[enum_Security_Attivita["ManutenzioneArchivi_ImportazioneHarvard"] = 353] = "ManutenzioneArchivi_ImportazioneHarvard";
    enum_Security_Attivita[enum_Security_Attivita["ReportRaccolteGIS"] = 354] = "ReportRaccolteGIS";
    enum_Security_Attivita[enum_Security_Attivita["Brogliaccio"] = 355] = "Brogliaccio";
    enum_Security_Attivita[enum_Security_Attivita["ManutenzioneArchivi_ImportazioneRicetteDaInterscambioApp"] = 356] = "ManutenzioneArchivi_ImportazioneRicetteDaInterscambioApp";
    enum_Security_Attivita[enum_Security_Attivita["ManutenzioneArchivi_ImportazioneAnagraficheZespri"] = 357] = "ManutenzioneArchivi_ImportazioneAnagraficheZespri";
    enum_Security_Attivita[enum_Security_Attivita["ManutenzioneArchivi_ImportazioneQDCZespri"] = 358] = "ManutenzioneArchivi_ImportazioneQDCZespri";
    enum_Security_Attivita[enum_Security_Attivita["ManutenzioneArchivi_EsportazioneAGEA"] = 359] = "ManutenzioneArchivi_EsportazioneAGEA";
    enum_Security_Attivita[enum_Security_Attivita["GIS_SAT_AnalisiDatiSatellitari"] = 360] = "GIS_SAT_AnalisiDatiSatellitari";
    // Fatturazione Elettronica
    enum_Security_Attivita[enum_Security_Attivita["Contabilita_FattElettronica"] = 361] = "Contabilita_FattElettronica";
    // gestione di permessi per chiamate a web service di provisioning (AgronicaWebApiProfilatore)
    enum_Security_Attivita[enum_Security_Attivita["Provisioning_agronica"] = 362] = "Provisioning_agronica";
    enum_Security_Attivita[enum_Security_Attivita["ManutenzioneArchivi_EsportazioneAgendaSISCO"] = 363] = "ManutenzioneArchivi_EsportazioneAgendaSISCO";
    enum_Security_Attivita[enum_Security_Attivita["ManutenzioneArchivi_EsportazioneEuresys"] = 364] = "ManutenzioneArchivi_EsportazioneEuresys";
    enum_Security_Attivita[enum_Security_Attivita["ManutenzioneArchivi_ConfigurazioneServizi"] = 365] = "ManutenzioneArchivi_ConfigurazioneServizi";
    enum_Security_Attivita[enum_Security_Attivita["Gest_PUA_2"] = 366] = "Gest_PUA_2";
    enum_Security_Attivita[enum_Security_Attivita["G2GFiltraDatiPerInvioGias2Gias"] = 367] = "G2GFiltraDatiPerInvioGias2Gias";
    enum_Security_Attivita[enum_Security_Attivita["GIS_VisualizzazioneGestioneWMS"] = 368] = "GIS_VisualizzazioneGestioneWMS";
    enum_Security_Attivita[enum_Security_Attivita["Gestione_Listini"] = 369] = "Gestione_Listini";
    enum_Security_Attivita[enum_Security_Attivita["Ordini_Acquisto"] = 370] = "Ordini_Acquisto";
    enum_Security_Attivita[enum_Security_Attivita["Consegne_Acquisto"] = 371] = "Consegne_Acquisto";
    enum_Security_Attivita[enum_Security_Attivita["Fatture_Acquisto"] = 372] = "Fatture_Acquisto";
    enum_Security_Attivita[enum_Security_Attivita["Ordini_Vendita"] = 373] = "Ordini_Vendita";
    enum_Security_Attivita[enum_Security_Attivita["Consegne_Vendita"] = 374] = "Consegne_Vendita";
    enum_Security_Attivita[enum_Security_Attivita["Fatture_Vendita"] = 375] = "Fatture_Vendita";
    enum_Security_Attivita[enum_Security_Attivita["Correlazione_Righe_Vendita"] = 376] = "Correlazione_Righe_Vendita";
    enum_Security_Attivita[enum_Security_Attivita["Statistiche_Vendita"] = 377] = "Statistiche_Vendita";
    enum_Security_Attivita[enum_Security_Attivita["Consegne_Conferimento"] = 378] = "Consegne_Conferimento";
    enum_Security_Attivita[enum_Security_Attivita["Numerazione_Documenti"] = 379] = "Numerazione_Documenti";
    enum_Security_Attivita[enum_Security_Attivita["Gestione_Imballaggi"] = 380] = "Gestione_Imballaggi";
    enum_Security_Attivita[enum_Security_Attivita["Nuovo_Conferimento"] = 381] = "Nuovo_Conferimento";
    enum_Security_Attivita[enum_Security_Attivita["Nuovo_DDT_Vendita"] = 382] = "Nuovo_DDT_Vendita";
    enum_Security_Attivita[enum_Security_Attivita["ManutenzioneArchivi_ImportazioneAnagraficheJDE"] = 383] = "ManutenzioneArchivi_ImportazioneAnagraficheJDE";
    enum_Security_Attivita[enum_Security_Attivita["ManutenzioneArchivi_ImportazionePianoColturaleExcel"] = 384] = "ManutenzioneArchivi_ImportazionePianoColturaleExcel";
    enum_Security_Attivita[enum_Security_Attivita["ManutenzioneArchivi_ImportazioneBizerba"] = 385] = "ManutenzioneArchivi_ImportazioneBizerba";
    enum_Security_Attivita[enum_Security_Attivita["Gestione_MenuControlliALP"] = 386] = "Gestione_MenuControlliALP";
    enum_Security_Attivita[enum_Security_Attivita["Gestione_MenuControlliALP_Admin"] = 387] = "Gestione_MenuControlliALP_Admin";
    enum_Security_Attivita[enum_Security_Attivita["Blocca_Sblocca_Pratiche"] = 388] = "Blocca_Sblocca_Pratiche";
    enum_Security_Attivita[enum_Security_Attivita["Importazione_AGREA_CSV"] = 389] = "Importazione_AGREA_CSV";
    enum_Security_Attivita[enum_Security_Attivita["Importazione_AGREA_Grafico"] = 390] = "Importazione_AGREA_Grafico";
    enum_Security_Attivita[enum_Security_Attivita["Report_Analisi_PdC"] = 391] = "Report_Analisi_PdC";
    enum_Security_Attivita[enum_Security_Attivita["Audit_BIO_COPROB"] = 392] = "Audit_BIO_COPROB";
    enum_Security_Attivita[enum_Security_Attivita["Audit_SQNPI_COPROB"] = 393] = "Audit_SQNPI_COPROB";
    enum_Security_Attivita[enum_Security_Attivita["Stime_Analisi_Produzione"] = 394] = "Stime_Analisi_Produzione";
    enum_Security_Attivita[enum_Security_Attivita["Trasferimenti_Magazzino"] = 395] = "Trasferimenti_Magazzino";
    // ############################################################
    // Controllo di gestione
    enum_Security_Attivita[enum_Security_Attivita["Gestione_Anagrafiche_CdG"] = 396] = "Gestione_Anagrafiche_CdG";
    enum_Security_Attivita[enum_Security_Attivita["Inserimento_CostiRicavi_Da_QdC_CdG"] = 397] = "Inserimento_CostiRicavi_Da_QdC_CdG";
    enum_Security_Attivita[enum_Security_Attivita["Inserimento_CostiRicavi_CdG"] = 398] = "Inserimento_CostiRicavi_CdG";
    enum_Security_Attivita[enum_Security_Attivita["Gestione_Report_CdG"] = 399] = "Gestione_Report_CdG";
    enum_Security_Attivita[enum_Security_Attivita["Gestione_Completa_CdG"] = 400] = "Gestione_Completa_CdG";
    // ############################################################
    enum_Security_Attivita[enum_Security_Attivita["VivaiAttivitaAdempimenti"] = 401] = "VivaiAttivitaAdempimenti";
    enum_Security_Attivita[enum_Security_Attivita["FiltraEdEsporta_PianiConcimazionePUA"] = 402] = "FiltraEdEsporta_PianiConcimazionePUA";
    enum_Security_Attivita[enum_Security_Attivita["NuovaVisitaDaFiltroDiRicerca"] = 403] = "NuovaVisitaDaFiltroDiRicerca";
    enum_Security_Attivita[enum_Security_Attivita["Pratiche_Filtri_Avanzati"] = 404] = "Pratiche_Filtri_Avanzati";
    enum_Security_Attivita[enum_Security_Attivita["Gest_PUA_2_ImportaFertilizzazioniDaRegistro"] = 405] = "Gest_PUA_2_ImportaFertilizzazioniDaRegistro";
    enum_Security_Attivita[enum_Security_Attivita["Gestione_Prezzi"] = 406] = "Gestione_Prezzi";
    enum_Security_Attivita[enum_Security_Attivita["Scadenzario_Inser"] = 407] = "Scadenzario_Inser";
    enum_Security_Attivita[enum_Security_Attivita["Scadenzario_Canc"] = 408] = "Scadenzario_Canc";
    enum_Security_Attivita[enum_Security_Attivita["Documentale_Lista"] = 409] = "Documentale_Lista";
    enum_Security_Attivita[enum_Security_Attivita["Documentale_Inser"] = 410] = "Documentale_Inser";
    enum_Security_Attivita[enum_Security_Attivita["Documentale_Canc"] = 411] = "Documentale_Canc";
    enum_Security_Attivita[enum_Security_Attivita["Documentale_Valid"] = 412] = "Documentale_Valid";
    enum_Security_Attivita[enum_Security_Attivita["Angrafica_Prodotti"] = 414] = "Angrafica_Prodotti";
    enum_Security_Attivita[enum_Security_Attivita["Valori_Economici_legati_alle_Attivita"] = 415] = "Valori_Economici_legati_alle_Attivita";
    enum_Security_Attivita[enum_Security_Attivita["Progetto_Piante"] = 416] = "Progetto_Piante";
    enum_Security_Attivita[enum_Security_Attivita["ReportPercorsi_Amministrtore"] = 417] = "ReportPercorsi_Amministrtore";
    enum_Security_Attivita[enum_Security_Attivita["Prenotazione_Piante_OrdineDaRichiesta"] = 418] = "Prenotazione_Piante_OrdineDaRichiesta";
    enum_Security_Attivita[enum_Security_Attivita["Prenotazione_Piante_SoloOrdini"] = 419] = "Prenotazione_Piante_SoloOrdini";
    enum_Security_Attivita[enum_Security_Attivita["Prenotazione_Piante_RichiestaMaterialeVivaistico"] = 420] = "Prenotazione_Piante_RichiestaMaterialeVivaistico";
    enum_Security_Attivita[enum_Security_Attivita["Importazione_Anagrafiche_Zespri"] = 421] = "Importazione_Anagrafiche_Zespri";
    enum_Security_Attivita[enum_Security_Attivita["Meteo_Modifica_creazioneStazioniProprietaVirtuali"] = 423] = "Meteo_Modifica_creazioneStazioniProprietaVirtuali";
    enum_Security_Attivita[enum_Security_Attivita["Biologico_ReportBio"] = 424] = "Biologico_ReportBio";
    enum_Security_Attivita[enum_Security_Attivita["ManutenzioneArchivi_ImportazioneAnalisiCampioniMaselli"] = 425] = "ManutenzioneArchivi_ImportazioneAnalisiCampioniMaselli";
    enum_Security_Attivita[enum_Security_Attivita["ManutenzioneArchivi_CodificaProdottiDaInterscambioApp"] = 426] = "ManutenzioneArchivi_CodificaProdottiDaInterscambioApp";
    enum_Security_Attivita[enum_Security_Attivita["Prenotazione_Piante_nuovo_ordine_a_vivaio"] = 427] = "Prenotazione_Piante_nuovo_ordine_a_vivaio";
    enum_Security_Attivita[enum_Security_Attivita["Prenotazione_Piante_nuova_richiesta_materiale_vivaistico"] = 428] = "Prenotazione_Piante_nuova_richiesta_materiale_vivaistico";
    enum_Security_Attivita[enum_Security_Attivita["PianiCampionamento_MarketAccess"] = 429] = "PianiCampionamento_MarketAccess";
    enum_Security_Attivita[enum_Security_Attivita["Gestione_Contratti_Conferimento"] = 430] = "Gestione_Contratti_Conferimento";
    enum_Security_Attivita[enum_Security_Attivita["Gis_Gestione_Di_SR_e_Trasfromazioni_Fra_SR"] = 431] = "Gis_Gestione_Di_SR_e_Trasfromazioni_Fra_SR";
    enum_Security_Attivita[enum_Security_Attivita["PianiCampionamento_RichiestaAnalisiMultiple"] = 432] = "PianiCampionamento_RichiestaAnalisiMultiple";
    enum_Security_Attivita[enum_Security_Attivita["Nuovo_Conferimento_Pomodoro"] = 433] = "Nuovo_Conferimento_Pomodoro";
    enum_Security_Attivita[enum_Security_Attivita["PUA_Blocca_Sblocca"] = 434] = "PUA_Blocca_Sblocca";
    enum_Security_Attivita[enum_Security_Attivita["PianoConcimazione_Blocca_Sblocca"] = 435] = "PianoConcimazione_Blocca_Sblocca";
    enum_Security_Attivita[enum_Security_Attivita["Contabilita_MVVElettronico"] = 436] = "Contabilita_MVVElettronico";
    enum_Security_Attivita[enum_Security_Attivita["PianiCampionamento_MarketAccess_Globale"] = 437] = "PianiCampionamento_MarketAccess_Globale";
    enum_Security_Attivita[enum_Security_Attivita["Contabilita_Clienti"] = 438] = "Contabilita_Clienti";
    enum_Security_Attivita[enum_Security_Attivita["Contabilita_Fornitori"] = 439] = "Contabilita_Fornitori";
    enum_Security_Attivita[enum_Security_Attivita["Interferenze_MenuPrincipale_Accesso"] = 440] = "Interferenze_MenuPrincipale_Accesso"; // Ex TipiEnumerativiSementieri MenuPrincipale_Accesso = 1
    enum_Security_Attivita[enum_Security_Attivita["Interferenze_UtentiPermessi_Gestione"] = 441] = "Interferenze_UtentiPermessi_Gestione"; // Ex TipiEnumerativiSementieri UtentiPermessi_Gestione = 2
    enum_Security_Attivita[enum_Security_Attivita["Interferenze_Configurazione_Distanze"] = 442] = "Interferenze_Configurazione_Distanze"; // Ex TipiEnumerativiSementieri Interferenze_Configurazione_Distanze = 3
    enum_Security_Attivita[enum_Security_Attivita["Interferenze_Configurazione_Colore"] = 443] = "Interferenze_Configurazione_Colore"; // Ex TipiEnumerativiSementieri Interferenze_Configurazione_Colore = 4
    enum_Security_Attivita[enum_Security_Attivita["Interferenze_Visualizzazione_Ridotta"] = 444] = "Interferenze_Visualizzazione_Ridotta"; // Ex TipiEnumerativiSementieri Interferenze_Visualizzazione_Ridotta = 5
    enum_Security_Attivita[enum_Security_Attivita["Interferenze_Visualizzazione_Estesa"] = 445] = "Interferenze_Visualizzazione_Estesa"; // Ex TipiEnumerativiSementieri Interferenze_Visualizzazione_Estesa = 6
    enum_Security_Attivita[enum_Security_Attivita["Audit_Budwood_Projects"] = 446] = "Audit_Budwood_Projects";
    enum_Security_Attivita[enum_Security_Attivita["Menu_Agenda_Visualizzazione_Dettagli_Operazioni"] = 447] = "Menu_Agenda_Visualizzazione_Dettagli_Operazioni";
    enum_Security_Attivita[enum_Security_Attivita["Anagrafiche_Conferimento"] = 448] = "Anagrafiche_Conferimento";
    enum_Security_Attivita[enum_Security_Attivita["Configurazione_Lavorazioni"] = 449] = "Configurazione_Lavorazioni";
    enum_Security_Attivita[enum_Security_Attivita["Undo_Pratiche"] = 450] = "Undo_Pratiche";
    enum_Security_Attivita[enum_Security_Attivita["Gias2JohnDeere"] = 451] = "Gias2JohnDeere";
    enum_Security_Attivita[enum_Security_Attivita["Statistiche_Acquisto"] = 452] = "Statistiche_Acquisto";
    enum_Security_Attivita[enum_Security_Attivita["ManutenzioneArchivi_ImportazioneConferimentiPomodoro"] = 453] = "ManutenzioneArchivi_ImportazioneConferimentiPomodoro";
    enum_Security_Attivita[enum_Security_Attivita["Gestione_Carburanti_UMA"] = 454] = "Gestione_Carburanti_UMA";
    enum_Security_Attivita[enum_Security_Attivita["Richiesta_UMA"] = 455] = "Richiesta_UMA";
    enum_Security_Attivita[enum_Security_Attivita["Rendicontazione_UMA"] = 456] = "Rendicontazione_UMA";
    enum_Security_Attivita[enum_Security_Attivita["Approvazione_Richiesta_UMA"] = 457] = "Approvazione_Richiesta_UMA";
    enum_Security_Attivita[enum_Security_Attivita["Approvazione_Rendicontazione_UMA"] = 458] = "Approvazione_Rendicontazione_UMA";
    enum_Security_Attivita[enum_Security_Attivita["Import_Anagrafiche_COPROB"] = 459] = "Import_Anagrafiche_COPROB";
    enum_Security_Attivita[enum_Security_Attivita["Configurazione_UMA"] = 460] = "Configurazione_UMA";
    enum_Security_Attivita[enum_Security_Attivita["Ordini_Lavorazioni"] = 461] = "Ordini_Lavorazioni";
    enum_Security_Attivita[enum_Security_Attivita["Utility_Cambio_CF_Utente"] = 462] = "Utility_Cambio_CF_Utente";
    enum_Security_Attivita[enum_Security_Attivita["UMA_Vendite_Carburanti"] = 463] = "UMA_Vendite_Carburanti";
    enum_Security_Attivita[enum_Security_Attivita["Esportazione_Trapianti_Agribologna"] = 464] = "Esportazione_Trapianti_Agribologna";
    enum_Security_Attivita[enum_Security_Attivita["PianiCampionamento_RisultatiAnalisiInGrigliaAnalisi"] = 465] = "PianiCampionamento_RisultatiAnalisiInGrigliaAnalisi";
    enum_Security_Attivita[enum_Security_Attivita["Configurazione_Modelli_Previsionali"] = 466] = "Configurazione_Modelli_Previsionali";
    enum_Security_Attivita[enum_Security_Attivita["Riepilogo_UMA"] = 467] = "Riepilogo_UMA";
    enum_Security_Attivita[enum_Security_Attivita["ImportazionePcgAvepa"] = 468] = "ImportazionePcgAvepa";
    enum_Security_Attivita[enum_Security_Attivita["Piano_Nutrizionale"] = 469] = "Piano_Nutrizionale";
    enum_Security_Attivita[enum_Security_Attivita["Visibilita_Aziende_UMA"] = 470] = "Visibilita_Aziende_UMA";
    enum_Security_Attivita[enum_Security_Attivita["Contabilita_DAA_Elettronico"] = 471] = "Contabilita_DAA_Elettronico";
    enum_Security_Attivita[enum_Security_Attivita["Anagrafica_MultiModifica_PianoColturale"] = 472] = "Anagrafica_MultiModifica_PianoColturale";
    enum_Security_Attivita[enum_Security_Attivita["Contabilita_CarichiScarichi_Magazzino"] = 473] = "Contabilita_CarichiScarichi_Magazzino";
    enum_Security_Attivita[enum_Security_Attivita["Budget"] = 474] = "Budget";
    enum_Security_Attivita[enum_Security_Attivita["Budget_Gestione_Anagrafiche_CdG"] = 475] = "Budget_Gestione_Anagrafiche_CdG";
    enum_Security_Attivita[enum_Security_Attivita["Budget_Inserimento_CostiRicavi"] = 476] = "Budget_Inserimento_CostiRicavi";
    enum_Security_Attivita[enum_Security_Attivita["Budget_Gestione_Report"] = 477] = "Budget_Gestione_Report";
    enum_Security_Attivita[enum_Security_Attivita["Budget_Valori_Economici_legati_alle_Attivita"] = 478] = "Budget_Valori_Economici_legati_alle_Attivita";
    enum_Security_Attivita[enum_Security_Attivita["Budget_Anagrafiche_Colturali"] = 479] = "Budget_Anagrafiche_Colturali";
    enum_Security_Attivita[enum_Security_Attivita["Audit_Convenzionale_Greenyard"] = 480] = "Audit_Convenzionale_Greenyard";
    enum_Security_Attivita[enum_Security_Attivita["Audit_Biologico_Greenyard"] = 481] = "Audit_Biologico_Greenyard";
    enum_Security_Attivita[enum_Security_Attivita["GIS_GestioneLayerPersonalizzati"] = 482] = "GIS_GestioneLayerPersonalizzati";
    enum_Security_Attivita[enum_Security_Attivita["Esportazione_Enogis"] = 483] = "Esportazione_Enogis";
    enum_Security_Attivita[enum_Security_Attivita["Esportazone_Artea"] = 484] = "Esportazone_Artea";
    enum_Security_Attivita[enum_Security_Attivita["PianiCampionamento_CompilazioneCapitolatiCliente"] = 485] = "PianiCampionamento_CompilazioneCapitolatiCliente";
    enum_Security_Attivita[enum_Security_Attivita["DSS_Irrigazione"] = 486] = "DSS_Irrigazione";
    enum_Security_Attivita[enum_Security_Attivita["Gruppi_Merce"] = 487] = "Gruppi_Merce";
    enum_Security_Attivita[enum_Security_Attivita["ReteAcqua_AnalisiDati"] = 494] = "ReteAcqua_AnalisiDati";
    enum_Security_Attivita[enum_Security_Attivita["Cartografia_VisualizzazioneTotale"] = 496] = "Cartografia_VisualizzazioneTotale";
    enum_Security_Attivita[enum_Security_Attivita["Cartografia_SetupVisualizzazione"] = 497] = "Cartografia_SetupVisualizzazione";
    enum_Security_Attivita[enum_Security_Attivita["Agenda_AccessoMenu_NG"] = 502] = "Agenda_AccessoMenu_NG";
    enum_Security_Attivita[enum_Security_Attivita["Gest_CartografiaAziendale_NG"] = 503] = "Gest_CartografiaAziendale_NG";
    enum_Security_Attivita[enum_Security_Attivita["Gest_AnagraficaAzienda_NG"] = 504] = "Gest_AnagraficaAzienda_NG";
    enum_Security_Attivita[enum_Security_Attivita["Anagrafica_Appezzamento_CopiaSposta"] = 506] = "Anagrafica_Appezzamento_CopiaSposta";
    enum_Security_Attivita[enum_Security_Attivita["Caricamento_Utilizzo_Mappe_Prescrizione_Personalizzate"] = 507] = "Caricamento_Utilizzo_Mappe_Prescrizione_Personalizzate";
    enum_Security_Attivita[enum_Security_Attivita["AggiornamentoMatricoleMadri"] = 508] = "AggiornamentoMatricoleMadri";
    enum_Security_Attivita[enum_Security_Attivita["SmartTractors"] = 509] = "SmartTractors";
    enum_Security_Attivita[enum_Security_Attivita["SmartTractors_Parametrizzazione"] = 510] = "SmartTractors_Parametrizzazione";
    enum_Security_Attivita[enum_Security_Attivita["SmartTractors_InvioRicette"] = 511] = "SmartTractors_InvioRicette";
    enum_Security_Attivita[enum_Security_Attivita["GIS_Configurazione_Algoritmi_Cartografici"] = 512] = "GIS_Configurazione_Algoritmi_Cartografici";
    enum_Security_Attivita[enum_Security_Attivita["GIS_Gestione_Parametri_Maschere_Raster"] = 513] = "GIS_Gestione_Parametri_Maschere_Raster";
    /**
     * Gestisce l'accesso alla gestione di utenti e permessi NG.
     *
     * IN LETTURA:
     * - Usato nella pagina Utenti e Permessi per accedere alla pagina
     *
     * IN SCRITTURA:
     * - Usato nella pagina Utenti e Permessi per: creare un nuovo utente, modificare un utente, assegnare visibilità,
     * copiare visibilità, assegnare permessi, modificare intervallo validità permessi,
     * modificare intervallo finestre temporali, bottone privacy(?)
     */
    enum_Security_Attivita[enum_Security_Attivita["Profilazione_NG"] = 514] = "Profilazione_NG";
    enum_Security_Attivita[enum_Security_Attivita["Visite_Lista_NG"] = 515] = "Visite_Lista_NG";
    enum_Security_Attivita[enum_Security_Attivita["Gestione_GHG"] = 516] = "Gestione_GHG";
    enum_Security_Attivita[enum_Security_Attivita["Configurazione_Operazioni_Colturali"] = 517] = "Configurazione_Operazioni_Colturali";
    enum_Security_Attivita[enum_Security_Attivita["DomandaIrrigua"] = 518] = "DomandaIrrigua";
    enum_Security_Attivita[enum_Security_Attivita["DomandaIrrigua_Scheda"] = 519] = "DomandaIrrigua_Scheda";
    enum_Security_Attivita[enum_Security_Attivita["DomandaIrrigua_Ricerca"] = 520] = "DomandaIrrigua_Ricerca";
    enum_Security_Attivita[enum_Security_Attivita["LettureContatoriAziendali"] = 521] = "LettureContatoriAziendali";
    enum_Security_Attivita[enum_Security_Attivita["ElaboraCalcoloTariffazione"] = 522] = "ElaboraCalcoloTariffazione";
    enum_Security_Attivita[enum_Security_Attivita["Valutazioni_Rischio"] = 523] = "Valutazioni_Rischio";
    enum_Security_Attivita[enum_Security_Attivita["Gruppi_Raccolta"] = 524] = "Gruppi_Raccolta";
    enum_Security_Attivita[enum_Security_Attivita["Requisiti_Stabilimento"] = 526] = "Requisiti_Stabilimento";
    enum_Security_Attivita[enum_Security_Attivita["GisBulkExportSuLayer"] = 533] = "GisBulkExportSuLayer";
    enum_Security_Attivita[enum_Security_Attivita["Budget_Ribaltamento_Su_Reale"] = 534] = "Budget_Ribaltamento_Su_Reale";
    enum_Security_Attivita[enum_Security_Attivita["Dati_Previsionali_Colture"] = 535] = "Dati_Previsionali_Colture";
    enum_Security_Attivita[enum_Security_Attivita["Confronto_Piano_Colturale"] = 545] = "Confronto_Piano_Colturale";
    enum_Security_Attivita[enum_Security_Attivita["Widget_MultiAzienda"] = 546] = "Widget_MultiAzienda";
    enum_Security_Attivita[enum_Security_Attivita["Menu_Precedente"] = 547] = "Menu_Precedente";
    enum_Security_Attivita[enum_Security_Attivita["UMA_Report_Controllo"] = 548] = "UMA_Report_Controllo";
    enum_Security_Attivita[enum_Security_Attivita["Visibilita_Viste_Grid"] = 549] = "Visibilita_Viste_Grid";
    enum_Security_Attivita[enum_Security_Attivita["Visibilita_Aziende_UMA_GestioneVisibilitaCompleta"] = 550] = "Visibilita_Aziende_UMA_GestioneVisibilitaCompleta";
    enum_Security_Attivita[enum_Security_Attivita["Menu_Stampe_New"] = 551] = "Menu_Stampe_New";
    enum_Security_Attivita[enum_Security_Attivita["Filiera_Trasporti_COPROB"] = 552] = "Filiera_Trasporti_COPROB";
    enum_Security_Attivita[enum_Security_Attivita["FiltroRicerca_NG"] = 553] = "FiltroRicerca_NG";
    enum_Security_Attivita[enum_Security_Attivita["Esportazione_Agea_NG"] = 554] = "Esportazione_Agea_NG";
    enum_Security_Attivita[enum_Security_Attivita["Statistometro_New"] = 555] = "Statistometro_New";
    enum_Security_Attivita[enum_Security_Attivita["Gestione_Servizi_NEW"] = 556] = "Gestione_Servizi_NEW";
    enum_Security_Attivita[enum_Security_Attivita["RegistrazioneMassiva_BDN"] = 557] = "RegistrazioneMassiva_BDN";
    enum_Security_Attivita[enum_Security_Attivita["UMA_Ricerca_Macrousi_Lavorazioni"] = 558] = "UMA_Ricerca_Macrousi_Lavorazioni";
    enum_Security_Attivita[enum_Security_Attivita["SincronizzazioneMassivaStalleVetInfo"] = 559] = "SincronizzazioneMassivaStalleVetInfo";
    enum_Security_Attivita[enum_Security_Attivita["Visualizza_Comandi_Avanzati_Esportazione_Agea_NG"] = 560] = "Visualizza_Comandi_Avanzati_Esportazione_Agea_NG";
    enum_Security_Attivita[enum_Security_Attivita["ProfilazioneImprese_NG"] = 561] = "ProfilazioneImprese_NG";
    enum_Security_Attivita[enum_Security_Attivita["ImpostazioniImprese_NG"] = 562] = "ImpostazioniImprese_NG";
    /** Permette la lettura o modifica di tutti gli utenti (non solo sé stessi) */
    enum_Security_Attivita[enum_Security_Attivita["AmministrazioneUtenti"] = 564] = "AmministrazioneUtenti";
    enum_Security_Attivita[enum_Security_Attivita["Enquete_certification_Hevea_brasiliensis"] = 565] = "Enquete_certification_Hevea_brasiliensis";
    enum_Security_Attivita[enum_Security_Attivita["Banca_Cambiano_Azienda"] = 566] = "Banca_Cambiano_Azienda";
    enum_Security_Attivita[enum_Security_Attivita["ImportazioneMassivaModelli4"] = 567] = "ImportazioneMassivaModelli4";
    enum_Security_Attivita[enum_Security_Attivita["CalcoloMassivo_Compliance_ISCC_AziendeInVisibilita"] = 568] = "CalcoloMassivo_Compliance_ISCC_AziendeInVisibilita";
    enum_Security_Attivita[enum_Security_Attivita["InserisciDocNonConformeISCC"] = 569] = "InserisciDocNonConformeISCC";
    enum_Security_Attivita[enum_Security_Attivita["ReportImpiegoProdottiFitosanitari"] = 570] = "ReportImpiegoProdottiFitosanitari";
    enum_Security_Attivita[enum_Security_Attivita["LettureContatoriAziendali_NG"] = 571] = "LettureContatoriAziendali_NG";
    enum_Security_Attivita[enum_Security_Attivita["GestioneAssociazioneAppezzamentiXParcoMacchine"] = 572] = "GestioneAssociazioneAppezzamentiXParcoMacchine";
    enum_Security_Attivita[enum_Security_Attivita["GestioneCache"] = 573] = "GestioneCache";
    enum_Security_Attivita[enum_Security_Attivita["Terapie"] = 574] = "Terapie";
    /** Gestisce la visibilità e l'accesso alla pagina delle operazioni zootecniche NG tramite il pulsante di menù
     * "Operazioni Zootcniche (new!)"*/
    enum_Security_Attivita[enum_Security_Attivita["MenuZooNG"] = 575] = "MenuZooNG";
    // andare avanti da qui.....
    // ############################################################
    // GIASAPP
    enum_Security_Attivita[enum_Security_Attivita["GiasAPP_Permessi"] = 800] = "GiasAPP_Permessi";
    enum_Security_Attivita[enum_Security_Attivita["GiasAPP_NUOVA_RICETTA"] = 801] = "GiasAPP_NUOVA_RICETTA";
    enum_Security_Attivita[enum_Security_Attivita["GiasAPP_NUOVO_INTERVENTO"] = 802] = "GiasAPP_NUOVO_INTERVENTO";
    enum_Security_Attivita[enum_Security_Attivita["GiasAPP_INTERVENTI_DA_FARE"] = 803] = "GiasAPP_INTERVENTI_DA_FARE";
    enum_Security_Attivita[enum_Security_Attivita["GiasAPP_SCARICO_ORE"] = 804] = "GiasAPP_SCARICO_ORE";
    enum_Security_Attivita[enum_Security_Attivita["GiasAPP_ENTRATAUSCITA"] = 805] = "GiasAPP_ENTRATAUSCITA";
    enum_Security_Attivita[enum_Security_Attivita["GiasAPP_LAMIAPOSIZIONE"] = 806] = "GiasAPP_LAMIAPOSIZIONE";
    enum_Security_Attivita[enum_Security_Attivita["GiasAPP_VISITE"] = 807] = "GiasAPP_VISITE";
    enum_Security_Attivita[enum_Security_Attivita["GiasAPP_DOCUMENTI"] = 808] = "GiasAPP_DOCUMENTI";
    enum_Security_Attivita[enum_Security_Attivita["GiasAPP_RILIEVI"] = 809] = "GiasAPP_RILIEVI";
    enum_Security_Attivita[enum_Security_Attivita["GiasAPP_GIS"] = 810] = "GiasAPP_GIS";
    enum_Security_Attivita[enum_Security_Attivita["GiasAPP_InCab"] = 811] = "GiasAPP_InCab";
    enum_Security_Attivita[enum_Security_Attivita["GiasAPP_PianoColturale"] = 812] = "GiasAPP_PianoColturale";
    enum_Security_Attivita[enum_Security_Attivita["GiasAPP_Magazzini"] = 813] = "GiasAPP_Magazzini";
    enum_Security_Attivita[enum_Security_Attivita["GiasAPP_Macchine"] = 814] = "GiasAPP_Macchine";
    enum_Security_Attivita[enum_Security_Attivita["GiasAPP_Manutenzioni"] = 815] = "GiasAPP_Manutenzioni";
    enum_Security_Attivita[enum_Security_Attivita["GiasAPP_DDT_Movimenti"] = 816] = "GiasAPP_DDT_Movimenti";
    enum_Security_Attivita[enum_Security_Attivita["GiasAPP_Gias"] = 817] = "GiasAPP_Gias";
    enum_Security_Attivita[enum_Security_Attivita["GiasAPP_Aziende"] = 818] = "GiasAPP_Aziende";
    enum_Security_Attivita[enum_Security_Attivita["GiasAPP_Centri"] = 819] = "GiasAPP_Centri";
    enum_Security_Attivita[enum_Security_Attivita["GiasAPP_Isolamenti"] = 820] = "GiasAPP_Isolamenti";
    enum_Security_Attivita[enum_Security_Attivita["GiasAPP_DSS_Difesa"] = 821] = "GiasAPP_DSS_Difesa";
    enum_Security_Attivita[enum_Security_Attivita["GiasAPP_ConsultaSincroDatiAppDaWeb"] = 822] = "GiasAPP_ConsultaSincroDatiAppDaWeb";
    // ############################################################
    // PROFITOSAN
    enum_Security_Attivita[enum_Security_Attivita["Profitosan_Home"] = 1000] = "Profitosan_Home";
    enum_Security_Attivita[enum_Security_Attivita["Profitosan_Prodotto_Testata"] = 1001] = "Profitosan_Prodotto_Testata";
    enum_Security_Attivita[enum_Security_Attivita["Profitosan_Prodotto_Dettagli"] = 1002] = "Profitosan_Prodotto_Dettagli";
    enum_Security_Attivita[enum_Security_Attivita["Profitosan_Prodotto_Etichetta"] = 1003] = "Profitosan_Prodotto_Etichetta";
    enum_Security_Attivita[enum_Security_Attivita["Profitosan_Prodotto_SchedaSicurezza"] = 1004] = "Profitosan_Prodotto_SchedaSicurezza";
    enum_Security_Attivita[enum_Security_Attivita["Profitosan_RicercaProdotti"] = 1005] = "Profitosan_RicercaProdotti"; // codice/nome prodotto
    enum_Security_Attivita[enum_Security_Attivita["Profitosan_RicercaProdottiAvanzata"] = 1006] = "Profitosan_RicercaProdottiAvanzata"; // campi impiego, sostanze attive, ditte, RMA
    enum_Security_Attivita[enum_Security_Attivita["Profitosan_RicercaProdottiSimili"] = 1007] = "Profitosan_RicercaProdottiSimili";
    enum_Security_Attivita[enum_Security_Attivita["Profitosan_Disciplinari"] = 1008] = "Profitosan_Disciplinari";
    enum_Security_Attivita[enum_Security_Attivita["Profitosan_RMA"] = 1009] = "Profitosan_RMA";
    enum_Security_Attivita[enum_Security_Attivita["Profitosan_Prodotto_Decreto"] = 1010] = "Profitosan_Prodotto_Decreto";
    enum_Security_Attivita[enum_Security_Attivita["Profitosan_Tunnel_Prodotto"] = 1011] = "Profitosan_Tunnel_Prodotto";
    // ############################################################
    // PianoConcimazione
    enum_Security_Attivita[enum_Security_Attivita["PianoConcimazione_CalcoloBilancio"] = 2000] = "PianoConcimazione_CalcoloBilancio";
})(enum_Security_Attivita || (enum_Security_Attivita = {}));
var enum_TipoOperazioneDB;
(function (enum_TipoOperazioneDB) {
    enum_TipoOperazioneDB[enum_TipoOperazioneDB["Lettura"] = 0] = "Lettura";
    enum_TipoOperazioneDB[enum_TipoOperazioneDB["Scrittura"] = 1] = "Scrittura";
    enum_TipoOperazioneDB[enum_TipoOperazioneDB["Modifica"] = 2] = "Modifica";
    enum_TipoOperazioneDB[enum_TipoOperazioneDB["Cancellazione"] = 3] = "Cancellazione";
    enum_TipoOperazioneDB[enum_TipoOperazioneDB["Trasferimento"] = 4] = "Trasferimento";
    enum_TipoOperazioneDB[enum_TipoOperazioneDB["Copia"] = 10] = "Copia";
})(enum_TipoOperazioneDB || (enum_TipoOperazioneDB = {}));
var enum_Security_Operazione;
(function (enum_Security_Operazione) {
    enum_Security_Operazione[enum_Security_Operazione["Lettura"] = 0] = "Lettura";
    enum_Security_Operazione[enum_Security_Operazione["Scrittura"] = 1] = "Scrittura";
    enum_Security_Operazione[enum_Security_Operazione["Modifica"] = 2] = "Modifica";
    enum_Security_Operazione[enum_Security_Operazione["Cancellazione"] = 3] = "Cancellazione";
    enum_Security_Operazione[enum_Security_Operazione["Esecuzione"] = 4] = "Esecuzione";
    enum_Security_Operazione[enum_Security_Operazione["Stampa"] = 5] = "Stampa";
})(enum_Security_Operazione || (enum_Security_Operazione = {}));
var enum_LAVCOD;
(function (enum_LAVCOD) {
    // #####################################################################
    // GRUPPO OPERAZIONE = 1 Rilievi in Campo
    enum_LAVCOD[enum_LAVCOD["RILIEVO_FALDA"] = 30] = "RILIEVO_FALDA";
    enum_LAVCOD[enum_LAVCOD["FASI_FENOLOGICHE"] = 79] = "FASI_FENOLOGICHE";
    enum_LAVCOD[enum_LAVCOD["INSTALLAZIONE_TRAPPOLE"] = 107] = "INSTALLAZIONE_TRAPPOLE";
    enum_LAVCOD[enum_LAVCOD["RILIEVO_AVVERSITA_TRAPPOLE"] = 110] = "RILIEVO_AVVERSITA_TRAPPOLE";
    enum_LAVCOD[enum_LAVCOD["RILIEVO_AVVERSITA_CAMPO"] = 113] = "RILIEVO_AVVERSITA_CAMPO";
    enum_LAVCOD[enum_LAVCOD["RILIEVO_ERBE_INFESTANTI"] = 119] = "RILIEVO_ERBE_INFESTANTI";
    enum_LAVCOD[enum_LAVCOD["RILIEVO_PIOGGE"] = 126] = "RILIEVO_PIOGGE";
    enum_LAVCOD[enum_LAVCOD["REINNESCO_TRAPPOLE"] = 150] = "REINNESCO_TRAPPOLE";
    enum_LAVCOD[enum_LAVCOD["MONITORAGGIO_ACQUE"] = 164] = "MONITORAGGIO_ACQUE";
    // ------------------------------------------------------------
    // GRUPPO OPERAZIONE = 2 Rilievi alla Raccolta
    enum_LAVCOD[enum_LAVCOD["DANNI_RACCOLTA"] = 108] = "DANNI_RACCOLTA";
    enum_LAVCOD[enum_LAVCOD["RILIEVO_INDICI_MATURITA"] = 109] = "RILIEVO_INDICI_MATURITA";
    enum_LAVCOD[enum_LAVCOD["RACCOLTA"] = 125] = "RACCOLTA";
    /** aka. Rilievo Produzione Prevista */
    enum_LAVCOD[enum_LAVCOD["RILIEVO_INDICI_RESE_RACCOLTA"] = 169] = "RILIEVO_INDICI_RESE_RACCOLTA";
    // ------------------------------------------------------------
    // GRUPPO OPERAZIONE = 3 Trattamenti
    enum_LAVCOD[enum_LAVCOD["CONCIA_SEME"] = 13] = "CONCIA_SEME";
    enum_LAVCOD[enum_LAVCOD["DISERBO"] = 18] = "DISERBO";
    enum_LAVCOD[enum_LAVCOD["TRATTAMENTO_ANTIPARASSITARIO"] = 74] = "TRATTAMENTO_ANTIPARASSITARIO";
    enum_LAVCOD[enum_LAVCOD["TRATTAMENTO_FITOREGOLATORE"] = 103] = "TRATTAMENTO_FITOREGOLATORE";
    enum_LAVCOD[enum_LAVCOD["DISTRIBUZIONE_INSETTI"] = 116] = "DISTRIBUZIONE_INSETTI";
    enum_LAVCOD[enum_LAVCOD["CONFUSIONE_SESSUALE"] = 118] = "CONFUSIONE_SESSUALE";
    enum_LAVCOD[enum_LAVCOD["DISORIENTAMENTO_SESSUALE"] = 121] = "DISORIENTAMENTO_SESSUALE";
    enum_LAVCOD[enum_LAVCOD["CATTURE_MASSA"] = 122] = "CATTURE_MASSA";
    enum_LAVCOD[enum_LAVCOD["GEODISINFESTAZIONE"] = 155] = "GEODISINFESTAZIONE";
    enum_LAVCOD[enum_LAVCOD["DISSECCAMENTO"] = 158] = "DISSECCAMENTO";
    enum_LAVCOD[enum_LAVCOD["TRATTAMENTO_POST_RACCOLTA"] = 163] = "TRATTAMENTO_POST_RACCOLTA";
    enum_LAVCOD[enum_LAVCOD["TRATTAMENTO_DICHIARAZIONE_NON_UTILIZZO"] = 165] = "TRATTAMENTO_DICHIARAZIONE_NON_UTILIZZO";
    // ------------------------------------------------------------
    // GRUPPO OPERAZIONE = 4 LAVORAZIONI
    enum_LAVCOD[enum_LAVCOD["IRRIGAZIONE"] = 1] = "IRRIGAZIONE";
    enum_LAVCOD[enum_LAVCOD["SEMINA"] = 2] = "SEMINA";
    enum_LAVCOD[enum_LAVCOD["TRAPIANTO"] = 71] = "TRAPIANTO";
    enum_LAVCOD[enum_LAVCOD["TRAPIANTO_IN_SERRA"] = 151] = "TRAPIANTO_IN_SERRA";
    enum_LAVCOD[enum_LAVCOD["SOVESCIO"] = 160] = "SOVESCIO";
    enum_LAVCOD[enum_LAVCOD["SOD_SEDDING"] = 68] = "SOD_SEDDING";
    enum_LAVCOD[enum_LAVCOD["ARATURA"] = 8] = "ARATURA";
    enum_LAVCOD[enum_LAVCOD["ANDANAMENTO"] = 9] = "ANDANAMENTO";
    enum_LAVCOD[enum_LAVCOD["FERTIRRIGAZIONE"] = 26] = "FERTIRRIGAZIONE";
    enum_LAVCOD[enum_LAVCOD["DISTRIBUZIONE_CONCIME"] = 14] = "DISTRIBUZIONE_CONCIME";
    enum_LAVCOD[enum_LAVCOD["CONCIMAZIONE_FOGLIARE"] = 123] = "CONCIMAZIONE_FOGLIARE";
    enum_LAVCOD[enum_LAVCOD["DISTRIBUZIONE_AMMENDANTI"] = 124] = "DISTRIBUZIONE_AMMENDANTI";
    enum_LAVCOD[enum_LAVCOD["SARCHIATURA_CONCIMAZIONE"] = 156] = "SARCHIATURA_CONCIMAZIONE";
    enum_LAVCOD[enum_LAVCOD["TRATTAMENTO_ANTIBUTTERATURA"] = 106] = "TRATTAMENTO_ANTIBUTTERATURA";
    enum_LAVCOD[enum_LAVCOD["FERTILIZZAZIONI_DICHIARAZIONE_NON_UTILIZZO"] = 166] = "FERTILIZZAZIONI_DICHIARAZIONE_NON_UTILIZZO";
    enum_LAVCOD[enum_LAVCOD["MANUTENZIONE_IMPIANTI"] = 159] = "MANUTENZIONE_IMPIANTI";
    //Stesso LAV_COD di ALTRE_OPERAZIONI
    enum_LAVCOD[enum_LAVCOD["RILIEVO_ATTIVITA"] = 162] = "RILIEVO_ATTIVITA";
    enum_LAVCOD[enum_LAVCOD["ASPORTAZIONE_ORGANI_INFETTI"] = 120] = "ASPORTAZIONE_ORGANI_INFETTI";
    enum_LAVCOD[enum_LAVCOD["ASSOLCATURA"] = 10] = "ASSOLCATURA";
    enum_LAVCOD[enum_LAVCOD["CARICO_MANUALE_FRUTTA"] = 78] = "CARICO_MANUALE_FRUTTA";
    enum_LAVCOD[enum_LAVCOD["CIMATURA"] = 12] = "CIMATURA";
    enum_LAVCOD[enum_LAVCOD["DIRADAMENTO_MANUALE"] = 17] = "DIRADAMENTO_MANUALE";
    enum_LAVCOD[enum_LAVCOD["DISSODAMENTO"] = 19] = "DISSODAMENTO";
    enum_LAVCOD[enum_LAVCOD["ERPICATURA"] = 21] = "ERPICATURA";
    enum_LAVCOD[enum_LAVCOD["ERPICATURA_ROTANTE"] = 157] = "ERPICATURA_ROTANTE";
    enum_LAVCOD[enum_LAVCOD["ESPIANTO"] = 81] = "ESPIANTO";
    enum_LAVCOD[enum_LAVCOD["ESTIRPATURA"] = 22] = "ESTIRPATURA";
    enum_LAVCOD[enum_LAVCOD["FALCIACONDIZIONATURA"] = 23] = "FALCIACONDIZIONATURA";
    enum_LAVCOD[enum_LAVCOD["FALCIATURA_ERBAI"] = 25] = "FALCIATURA_ERBAI";
    enum_LAVCOD[enum_LAVCOD["FORMAZIONE_ARGINELLI"] = 27] = "FORMAZIONE_ARGINELLI";
    enum_LAVCOD[enum_LAVCOD["FRANGIZOLLATURA"] = 31] = "FRANGIZOLLATURA";
    enum_LAVCOD[enum_LAVCOD["FRESATURA"] = 32] = "FRESATURA";
    enum_LAVCOD[enum_LAVCOD["GEBIATURA"] = 152] = "GEBIATURA";
    enum_LAVCOD[enum_LAVCOD["IMBALLO_FIENO_ROTOLI"] = 33] = "IMBALLO_FIENO_ROTOLI";
    enum_LAVCOD[enum_LAVCOD["INTERRAMENTO_PAGLIE"] = 34] = "INTERRAMENTO_PAGLIE";
    enum_LAVCOD[enum_LAVCOD["INTERVENTO_ANTIBRINA"] = 161] = "INTERVENTO_ANTIBRINA";
    enum_LAVCOD[enum_LAVCOD["LAVORAZIONE_CONBINATA"] = 154] = "LAVORAZIONE_CONBINATA";
    enum_LAVCOD[enum_LAVCOD["LAVORAZIONE_TRA_FILA"] = 82] = "LAVORAZIONE_TRA_FILA";
    enum_LAVCOD[enum_LAVCOD["LAVORAZIONE_SU_FILA"] = 83] = "LAVORAZIONE_SU_FILA";
    enum_LAVCOD[enum_LAVCOD["LEGATURA"] = 84] = "LEGATURA";
    enum_LAVCOD[enum_LAVCOD["LIVELLAMENTO"] = 40] = "LIVELLAMENTO";
    enum_LAVCOD[enum_LAVCOD["MANUTENZIONE_ARGINI"] = 41] = "MANUTENZIONE_ARGINI";
    enum_LAVCOD[enum_LAVCOD["MESSA_DIMORA_PIANTE"] = 85] = "MESSA_DIMORA_PIANTE";
    enum_LAVCOD[enum_LAVCOD["MIETITREBBIATURA"] = 46] = "MIETITREBBIATURA";
    enum_LAVCOD[enum_LAVCOD["MINIMUM_TILLAGE"] = 47] = "MINIMUM_TILLAGE";
    enum_LAVCOD[enum_LAVCOD["PACCIAMATURA"] = 48] = "PACCIAMATURA";
    enum_LAVCOD[enum_LAVCOD["POTATURA_SECCA"] = 87] = "POTATURA_SECCA";
    enum_LAVCOD[enum_LAVCOD["POTATURA_VERDE"] = 88] = "POTATURA_VERDE";
    enum_LAVCOD[enum_LAVCOD["PRESSATURA"] = 49] = "PRESSATURA";
    enum_LAVCOD[enum_LAVCOD["RACCOLTA_LEGNA_POTATURA"] = 90] = "RACCOLTA_LEGNA_POTATURA";
    enum_LAVCOD[enum_LAVCOD["RANGHINATURA"] = 53] = "RANGHINATURA";
    enum_LAVCOD[enum_LAVCOD["RINCALZATURA"] = 55] = "RINCALZATURA";
    enum_LAVCOD[enum_LAVCOD["RIPPATURA"] = 115] = "RIPPATURA";
    enum_LAVCOD[enum_LAVCOD["RIPUNTATURA"] = 56] = "RIPUNTATURA";
    enum_LAVCOD[enum_LAVCOD["RIVOLTAMENTO_FORAGGIO"] = 57] = "RIVOLTAMENTO_FORAGGIO";
    enum_LAVCOD[enum_LAVCOD["ROMPICROSTA"] = 153] = "ROMPICROSTA";
    enum_LAVCOD[enum_LAVCOD["RULLATURA"] = 58] = "RULLATURA";
    enum_LAVCOD[enum_LAVCOD["SARCHIATURA"] = 59] = "SARCHIATURA";
    enum_LAVCOD[enum_LAVCOD["SCARIFICATURA"] = 62] = "SCARIFICATURA";
    enum_LAVCOD[enum_LAVCOD["SCASSO"] = 63] = "SCASSO";
    enum_LAVCOD[enum_LAVCOD["TRINCIATURA"] = 75] = "TRINCIATURA";
    enum_LAVCOD[enum_LAVCOD["VANGATURA"] = 76] = "VANGATURA";
    enum_LAVCOD[enum_LAVCOD["ZAPPATURA"] = 77] = "ZAPPATURA";
    enum_LAVCOD[enum_LAVCOD["RACCOLTA_MANUALE"] = 91] = "RACCOLTA_MANUALE";
    enum_LAVCOD[enum_LAVCOD["RACCOLTA_MECCANICA"] = 92] = "RACCOLTA_MECCANICA";
    enum_LAVCOD[enum_LAVCOD["RILIEVO_PRODUZIONE_DATA_RACCOLTA"] = 125] = "RILIEVO_PRODUZIONE_DATA_RACCOLTA";
    enum_LAVCOD[enum_LAVCOD["STRIGLIATURA"] = 167] = "STRIGLIATURA";
    enum_LAVCOD[enum_LAVCOD["PIRODISERBO"] = 168] = "PIRODISERBO";
    //Stesso LAV_COD di RILIEVO_ATTIVITA
    enum_LAVCOD[enum_LAVCOD["ALTRE_OPERAZIONI"] = 162] = "ALTRE_OPERAZIONI";
    enum_LAVCOD[enum_LAVCOD["ABBATTIMENTOIMPIANTI"] = 170] = "ABBATTIMENTOIMPIANTI";
    enum_LAVCOD[enum_LAVCOD["CONFUSIONE_DISORIENTAMENTO_SESSUALE"] = 172] = "CONFUSIONE_DISORIENTAMENTO_SESSUALE";
    // ------------------------------------------------------------
    // GRUPPO OPERAZIONE = 5 Altre Operazioni Colturali(non gestite)
    // ------------------------------------------------------------
    // GRUPPO OPERAZIONE = 6 (tutte)
    enum_LAVCOD[enum_LAVCOD["BOLLA_EMESSA"] = 1031] = "BOLLA_EMESSA";
    enum_LAVCOD[enum_LAVCOD["BOLLA_RICEVUTA"] = 1025] = "BOLLA_RICEVUTA";
    enum_LAVCOD[enum_LAVCOD["DDT_CONTABILIZZATO_EMESSO"] = 1069] = "DDT_CONTABILIZZATO_EMESSO";
    enum_LAVCOD[enum_LAVCOD["FATTURA_EMESSA"] = 1001] = "FATTURA_EMESSA";
    enum_LAVCOD[enum_LAVCOD["FATTURA_RICEVUTA"] = 1000] = "FATTURA_RICEVUTA";
    enum_LAVCOD[enum_LAVCOD["FATTURA_PROFESSIONISTI"] = 1070] = "FATTURA_PROFESSIONISTI";
    enum_LAVCOD[enum_LAVCOD["FATTURA_PROFORMA"] = 1064] = "FATTURA_PROFORMA";
    enum_LAVCOD[enum_LAVCOD["FATTURA_LIQ_CONF_EMESSA"] = 1055] = "FATTURA_LIQ_CONF_EMESSA";
    enum_LAVCOD[enum_LAVCOD["FATTURA_LIQ_CONF_RICEVUTA"] = 1056] = "FATTURA_LIQ_CONF_RICEVUTA";
    enum_LAVCOD[enum_LAVCOD["AUTOFATTURA_LIQ_CONF_EMESSA"] = 1057] = "AUTOFATTURA_LIQ_CONF_EMESSA";
    enum_LAVCOD[enum_LAVCOD["AUTOFATTURA_LIQ_CONF_RICEVUTA"] = 1058] = "AUTOFATTURA_LIQ_CONF_RICEVUTA";
    enum_LAVCOD[enum_LAVCOD["RICEVUTA_EMESSA"] = 1053] = "RICEVUTA_EMESSA";
    enum_LAVCOD[enum_LAVCOD["ALTRI_RICAVI"] = 1027] = "ALTRI_RICAVI";
    enum_LAVCOD[enum_LAVCOD["ALTRI_COSTI"] = 1026] = "ALTRI_COSTI";
    // RESI/ABBUONI SU ACQUISTI
    enum_LAVCOD[enum_LAVCOD["NOTA_ACCREDITO_RICEVUTA"] = 1002] = "NOTA_ACCREDITO_RICEVUTA";
    // RESI/ABBUONI SU VENDITE
    enum_LAVCOD[enum_LAVCOD["NOTA_ACCREDITO_EMESSA"] = 1003] = "NOTA_ACCREDITO_EMESSA";
    enum_LAVCOD[enum_LAVCOD["MOV_FINANZIARIO"] = 1032] = "MOV_FINANZIARIO";
    enum_LAVCOD[enum_LAVCOD["REG_COMPENSI"] = 1005] = "REG_COMPENSI";
    enum_LAVCOD[enum_LAVCOD["AUTOFATTURA_BENI_ESTERO"] = 1004] = "AUTOFATTURA_BENI_ESTERO";
    enum_LAVCOD[enum_LAVCOD["SPESE_PER_DIPENDENTI"] = 1006] = "SPESE_PER_DIPENDENTI";
    enum_LAVCOD[enum_LAVCOD["SPESE_VARIE"] = 1007] = "SPESE_VARIE";
    enum_LAVCOD[enum_LAVCOD["ACQUISTO_MATERIE_PRIME_SOCI"] = 1060] = "ACQUISTO_MATERIE_PRIME_SOCI";
    enum_LAVCOD[enum_LAVCOD["PROCEDURA_LIQUIDAZIONE_SOCI"] = 1079] = "PROCEDURA_LIQUIDAZIONE_SOCI";
    enum_LAVCOD[enum_LAVCOD["COSTI_CDG"] = 4500] = "COSTI_CDG";
    // ------------------------------------------------------------
    // il 5000 è Trasformazioni e non è associato ad alcun gruppo
    enum_LAVCOD[enum_LAVCOD["TRASFORMAZIONI"] = 5000] = "TRASFORMAZIONI";
    enum_LAVCOD[enum_LAVCOD["CURA"] = 5004] = "CURA";
    // ------------------------------------------------------------
    // GRUPPO OPERAZIONE = 7 (tutte)
    enum_LAVCOD[enum_LAVCOD["ACQUISTO_BENI"] = 1008] = "ACQUISTO_BENI";
    enum_LAVCOD[enum_LAVCOD["CESSIONE_BENI"] = 1009] = "CESSIONE_BENI";
    enum_LAVCOD[enum_LAVCOD["REG_AMMORTAMENTI"] = 1010] = "REG_AMMORTAMENTI";
    enum_LAVCOD[enum_LAVCOD["FINE_AMMORTAMENTI"] = 1011] = "FINE_AMMORTAMENTI";
    // -------------------------------------------------------------
    // GRUPPO OPERAZIONE = 8 (tutte)
    enum_LAVCOD[enum_LAVCOD["PAGAMENTO_FATTURA"] = 1012] = "PAGAMENTO_FATTURA";
    enum_LAVCOD[enum_LAVCOD["INCASSO_FATTURA"] = 1013] = "INCASSO_FATTURA";
    enum_LAVCOD[enum_LAVCOD["PAGAMENTI_DIVERSI"] = 1014] = "PAGAMENTI_DIVERSI";
    enum_LAVCOD[enum_LAVCOD["INCASSI_DIVERSI"] = 1015] = "INCASSI_DIVERSI";
    enum_LAVCOD[enum_LAVCOD["PAGAMENTO_RATA_PRESTITO"] = 1024] = "PAGAMENTO_RATA_PRESTITO";
    // --------------------------------------------------------------
    // GRUPPO OPERAZIONE = 9 (tutte)
    enum_LAVCOD[enum_LAVCOD["SCADENZA_FATTURA_EMESSA"] = 1017] = "SCADENZA_FATTURA_EMESSA";
    enum_LAVCOD[enum_LAVCOD["SCADENZA_FATTURA_RICEVUTA"] = 1016] = "SCADENZA_FATTURA_RICEVUTA";
    enum_LAVCOD[enum_LAVCOD["SCADENZA_PAGAMENTI_DIVERSI"] = 1018] = "SCADENZA_PAGAMENTI_DIVERSI";
    enum_LAVCOD[enum_LAVCOD["SCADENZA_INCASSI_DIVERSI"] = 1019] = "SCADENZA_INCASSI_DIVERSI";
    // --------------------------------------------------------------
    // GRUPPO OPERAZIONE = 10 (tutte)
    enum_LAVCOD[enum_LAVCOD["CARICO"] = 1022] = "CARICO";
    enum_LAVCOD[enum_LAVCOD["SCARICO"] = 1023] = "SCARICO";
    enum_LAVCOD[enum_LAVCOD["PARTITA_DOPPIA"] = 1032] = "PARTITA_DOPPIA";
    enum_LAVCOD[enum_LAVCOD["TRASFERIMENTO"] = 1033] = "TRASFERIMENTO";
    enum_LAVCOD[enum_LAVCOD["AUTOCONSUMO"] = 1028] = "AUTOCONSUMO";
    enum_LAVCOD[enum_LAVCOD["AUTOCONSUMO_VINO_SFUSO"] = 1066] = "AUTOCONSUMO_VINO_SFUSO";
    enum_LAVCOD[enum_LAVCOD["PRODUZIONI"] = 1029] = "PRODUZIONI";
    enum_LAVCOD[enum_LAVCOD["MOV_MAG_MATERIE_PRIME"] = 1030] = "MOV_MAG_MATERIE_PRIME";
    enum_LAVCOD[enum_LAVCOD["CONFERIMENTO"] = 1050] = "CONFERIMENTO";
    enum_LAVCOD[enum_LAVCOD["ACCETTAZIONE"] = 1051] = "ACCETTAZIONE";
    enum_LAVCOD[enum_LAVCOD["CONFERIMENTO_DIVERSI"] = 1052] = "CONFERIMENTO_DIVERSI";
    enum_LAVCOD[enum_LAVCOD["ACCETTAZIONE_DIVERSI"] = 1054] = "ACCETTAZIONE_DIVERSI";
    enum_LAVCOD[enum_LAVCOD["VENDITA"] = 1020] = "VENDITA";
    enum_LAVCOD[enum_LAVCOD["ACQUISTO"] = 1021] = "ACQUISTO";
    enum_LAVCOD[enum_LAVCOD["CORRISPETTIVO_VENDITA_SFUSO"] = 1065] = "CORRISPETTIVO_VENDITA_SFUSO";
    enum_LAVCOD[enum_LAVCOD["DOCO_EMESSO"] = 1061] = "DOCO_EMESSO";
    enum_LAVCOD[enum_LAVCOD["DOCO_RICEVUTO"] = 1062] = "DOCO_RICEVUTO";
    enum_LAVCOD[enum_LAVCOD["DAA_EMESSO"] = 1063] = "DAA_EMESSO";
    enum_LAVCOD[enum_LAVCOD["MVV_EMESSO"] = 1071] = "MVV_EMESSO";
    enum_LAVCOD[enum_LAVCOD["MVV_RICEVUTO"] = 1072] = "MVV_RICEVUTO";
    enum_LAVCOD[enum_LAVCOD["ALTRI_RICAVI_NERO"] = 1073] = "ALTRI_RICAVI_NERO";
    enum_LAVCOD[enum_LAVCOD["ALTRI_COSTI_NERO"] = 1074] = "ALTRI_COSTI_NERO";
    enum_LAVCOD[enum_LAVCOD["DISTINTA_CARICO"] = 1075] = "DISTINTA_CARICO";
    enum_LAVCOD[enum_LAVCOD["DISTINTA_CARICO_ACCETTAZIONE"] = 1076] = "DISTINTA_CARICO_ACCETTAZIONE";
    enum_LAVCOD[enum_LAVCOD["AUTO_DDT_EMESSO"] = 1077] = "AUTO_DDT_EMESSO";
    enum_LAVCOD[enum_LAVCOD["AUTO_DDT_EMESSO_ACCETTAZIONE"] = 1078] = "AUTO_DDT_EMESSO_ACCETTAZIONE";
    enum_LAVCOD[enum_LAVCOD["GESTIONE_RIFIUTI"] = 1080] = "GESTIONE_RIFIUTI";
    // ------------------------------------------------------------------
    // GRUPPO OPERAZIONE = 11 (tutte)
    enum_LAVCOD[enum_LAVCOD["NOTE"] = 2000] = "NOTE";
    enum_LAVCOD[enum_LAVCOD["RATE"] = 2001] = "RATE";
    enum_LAVCOD[enum_LAVCOD["ORDINE_VENDITA"] = 2002] = "ORDINE_VENDITA";
    enum_LAVCOD[enum_LAVCOD["ORDINE_ACQUISTO"] = 2004] = "ORDINE_ACQUISTO";
    enum_LAVCOD[enum_LAVCOD["PREVENTIVO_VENDITA"] = 2003] = "PREVENTIVO_VENDITA";
    // ------------------------------------------------------------------
    // GRUPPO OPERAZIONE = 12 (tutte)
    enum_LAVCOD[enum_LAVCOD["ANALISI_LATTE_SINGOLA"] = 3006] = "ANALISI_LATTE_SINGOLA";
    enum_LAVCOD[enum_LAVCOD["ANALISI_LATTE_MASSA"] = 3007] = "ANALISI_LATTE_MASSA";
    // ------------------------------------------------------------------
    // GRUPPO OPERAZIONE = 13 (tutte)
    enum_LAVCOD[enum_LAVCOD["NASCITA_ANIMALI"] = 3000] = "NASCITA_ANIMALI";
    enum_LAVCOD[enum_LAVCOD["INCREMENTO_CONSISTENZE_ZOO"] = 3001] = "INCREMENTO_CONSISTENZE_ZOO";
    enum_LAVCOD[enum_LAVCOD["DECREMENTO_CONSISTENZE_ZOO"] = 3002] = "DECREMENTO_CONSISTENZE_ZOO";
    enum_LAVCOD[enum_LAVCOD["MORTE_ANIMALI"] = 3003] = "MORTE_ANIMALI";
    enum_LAVCOD[enum_LAVCOD["MACELLAZIONE_ANIMALI"] = 3004] = "MACELLAZIONE_ANIMALI";
    enum_LAVCOD[enum_LAVCOD["SOSTITUZIONE_MARCA"] = 3005] = "SOSTITUZIONE_MARCA";
    enum_LAVCOD[enum_LAVCOD["SPOSTAMENTI_ZOO"] = 3030] = "SPOSTAMENTI_ZOO";
    enum_LAVCOD[enum_LAVCOD["PESATURA_ANIMALI"] = 3033] = "PESATURA_ANIMALI";
    enum_LAVCOD[enum_LAVCOD["ACQUISTO_ANIMALI"] = 3034] = "ACQUISTO_ANIMALI";
    enum_LAVCOD[enum_LAVCOD["VENDITA_ANIMALI"] = 3035] = "VENDITA_ANIMALI";
    // ------------------------------------------------------------------
    // GRUPPO OPERAZIONE = 14 Rilievi produzioni
    // ------------------------------------------------------------------
    // GRUPPO OPERAZIONE = 15 Gestione mungitura
    enum_LAVCOD[enum_LAVCOD["MUNGITURA_PREPARAZIONE"] = 3009] = "MUNGITURA_PREPARAZIONE";
    enum_LAVCOD[enum_LAVCOD["MUNGITURA_SECCHIO_POSTA"] = 3010] = "MUNGITURA_SECCHIO_POSTA";
    enum_LAVCOD[enum_LAVCOD["MUNGITURA_GRUPPI_POSTA"] = 3011] = "MUNGITURA_GRUPPI_POSTA";
    enum_LAVCOD[enum_LAVCOD["MUNGITURA_SALA_LATTE"] = 3012] = "MUNGITURA_SALA_LATTE";
    enum_LAVCOD[enum_LAVCOD["MUNGITURA_LAVAGGIO_IMPIANTI"] = 3013] = "MUNGITURA_LAVAGGIO_IMPIANTI";
    enum_LAVCOD[enum_LAVCOD["MUNGITURA_LAVAGGIO_SALA_LATTE"] = 3014] = "MUNGITURA_LAVAGGIO_SALA_LATTE";
    // ------------------------------------------------------------------
    // GRUPPO OPERAZIONE = 16 Gestione lettiere
    // ------------------------------------------------------------------
    // GRUPPO OPERAZIONE = 17 Gestione alimentazione
    enum_LAVCOD[enum_LAVCOD["ALIMENTAZIONE_PULIZIA_IMPIANTI"] = 3019] = "ALIMENTAZIONE_PULIZIA_IMPIANTI";
    enum_LAVCOD[enum_LAVCOD["ALIMENTAZIONE_DISTRIBUZIONE_MANUALE_FORAGGI"] = 3020] = "ALIMENTAZIONE_DISTRIBUZIONE_MANUALE_FORAGGI";
    enum_LAVCOD[enum_LAVCOD["ALIMENTAZIONE_DISTRIBUZIONE_MECCANICA_FORAGGI"] = 3021] = "ALIMENTAZIONE_DISTRIBUZIONE_MECCANICA_FORAGGI";
    enum_LAVCOD[enum_LAVCOD["ALIMENTAZIONE_DISTRIBUZIONE_MANUALE_MANGIMI"] = 3022] = "ALIMENTAZIONE_DISTRIBUZIONE_MANUALE_MANGIMI";
    enum_LAVCOD[enum_LAVCOD["ALIMENTAZIONE_DISTRIBUZIONE_MECCANICA_MANGIMI"] = 3023] = "ALIMENTAZIONE_DISTRIBUZIONE_MECCANICA_MANGIMI";
    enum_LAVCOD[enum_LAVCOD["ALIMENTAZIONE_CONTROLLO_REGOLAZIONE_SISTEMI"] = 3024] = "ALIMENTAZIONE_CONTROLLO_REGOLAZIONE_SISTEMI";
    // ------------------------------------------------------------------
    // GRUPPO OPERAZIONE = 18 Altri lavori di stalla
    enum_LAVCOD[enum_LAVCOD["ALTRE_LAVORAZIONI_ZOO"] = 3036] = "ALTRE_LAVORAZIONI_ZOO";
    // ------------------------------------------------------------------
    // GRUPPO OPERAZIONE = 19 MACCHINE
    enum_LAVCOD[enum_LAVCOD["MANUTENZIONE_MACCHINE"] = 1500] = "MANUTENZIONE_MACCHINE";
    enum_LAVCOD[enum_LAVCOD["REVISIONE_MACCHINE"] = 4000] = "REVISIONE_MACCHINE";
    // ------------------------------------------------------------------
    enum_LAVCOD[enum_LAVCOD["PREPARAZIONE"] = 5000] = "PREPARAZIONE";
    // GRUPPO OPERAZIONE = 20 Gestione Visite Ispettive
    enum_LAVCOD[enum_LAVCOD["MONITORAGGIO_TEMPI_RIENTRO"] = 5001] = "MONITORAGGIO_TEMPI_RIENTRO";
    enum_LAVCOD[enum_LAVCOD["VISITA_GENERICA"] = 5002] = "VISITA_GENERICA";
    enum_LAVCOD[enum_LAVCOD["MONITORAGGIO_CE"] = 5003] = "MONITORAGGIO_CE";
    enum_LAVCOD[enum_LAVCOD["PRATICA_ECOLOGICA"] = 5005] = "PRATICA_ECOLOGICA";
    enum_LAVCOD[enum_LAVCOD["FORMAZIONE"] = 5006] = "FORMAZIONE";
    enum_LAVCOD[enum_LAVCOD["VISITA"] = 5007] = "VISITA";
    // ------------------------------------------------------------------
    // GRUPPO OPERAZIONE = 100 Linee Produzione Vegetale
    // ------------------------------------------------------------------
    // GRUPPO OPERAZIONE = 101 Linee Produzione Animale
    // ------------------------------------------------------------
    // #####################################################################
})(enum_LAVCOD || (enum_LAVCOD = {}));
var enum_Disciplinare_Tipo_Testata;
(function (enum_Disciplinare_Tipo_Testata) {
    enum_Disciplinare_Tipo_Testata[enum_Disciplinare_Tipo_Testata["Difesa"] = 0] = "Difesa";
    enum_Disciplinare_Tipo_Testata[enum_Disciplinare_Tipo_Testata["Diserbo"] = 1] = "Diserbo";
    enum_Disciplinare_Tipo_Testata[enum_Disciplinare_Tipo_Testata["Fitoregolatore"] = 2] = "Fitoregolatore";
    enum_Disciplinare_Tipo_Testata[enum_Disciplinare_Tipo_Testata["Fertilizzazione"] = 4] = "Fertilizzazione";
})(enum_Disciplinare_Tipo_Testata || (enum_Disciplinare_Tipo_Testata = {}));
var enum_Gestione_Lotti;
(function (enum_Gestione_Lotti) {
    enum_Gestione_Lotti[enum_Gestione_Lotti["Nessuna"] = 0] = "Nessuna";
    enum_Gestione_Lotti[enum_Gestione_Lotti["Obbligatoria"] = 1] = "Obbligatoria";
    enum_Gestione_Lotti[enum_Gestione_Lotti["Facoltativa"] = 2] = "Facoltativa";
})(enum_Gestione_Lotti || (enum_Gestione_Lotti = {}));
var enum_Gestione_Giacenze;
(function (enum_Gestione_Giacenze) {
    enum_Gestione_Giacenze[enum_Gestione_Giacenze["SoloMovimentati"] = 0] = "SoloMovimentati";
    enum_Gestione_Giacenze[enum_Gestione_Giacenze["SoloPresenti"] = 1] = "SoloPresenti";
    enum_Gestione_Giacenze[enum_Gestione_Giacenze["TuttiProdotti"] = 2] = "TuttiProdotti";
})(enum_Gestione_Giacenze || (enum_Gestione_Giacenze = {}));
var enum_RACCOLTA_TIPO;
(function (enum_RACCOLTA_TIPO) {
    enum_RACCOLTA_TIPO[enum_RACCOLTA_TIPO["Fast"] = 10] = "Fast";
    enum_RACCOLTA_TIPO[enum_RACCOLTA_TIPO["Leggera"] = 20] = "Leggera";
    enum_RACCOLTA_TIPO[enum_RACCOLTA_TIPO["Leggera_Con_Dettagli_Magazzino"] = 30] = "Leggera_Con_Dettagli_Magazzino";
    enum_RACCOLTA_TIPO[enum_RACCOLTA_TIPO["Standard"] = 40] = "Standard";
    enum_RACCOLTA_TIPO[enum_RACCOLTA_TIPO["Raccolta_e_Cura"] = 50] = "Raccolta_e_Cura";
})(enum_RACCOLTA_TIPO || (enum_RACCOLTA_TIPO = {}));
// Tipi di Mezzo
var enum_TipoMezzo;
(function (enum_TipoMezzo) {
    enum_TipoMezzo[enum_TipoMezzo["Indefinito"] = -1] = "Indefinito";
    enum_TipoMezzo[enum_TipoMezzo["Ettolitro"] = 0] = "Ettolitro";
    enum_TipoMezzo[enum_TipoMezzo["Ettaro"] = 1] = "Ettaro";
    enum_TipoMezzo[enum_TipoMezzo["Ora"] = 2] = "Ora";
    enum_TipoMezzo[enum_TipoMezzo["Mensile"] = 3] = "Mensile";
    enum_TipoMezzo[enum_TipoMezzo["Complessivo"] = 4] = "Complessivo";
    enum_TipoMezzo[enum_TipoMezzo["Chilometro"] = 5] = "Chilometro";
    enum_TipoMezzo[enum_TipoMezzo["Quintale"] = 6] = "Quintale";
})(enum_TipoMezzo || (enum_TipoMezzo = {}));
var enum_UnitaMisura;
(function (enum_UnitaMisura) {
    enum_UnitaMisura[enum_UnitaMisura["KG"] = 2] = "KG";
    enum_UnitaMisura[enum_UnitaMisura["Grammi"] = 3] = "Grammi";
    enum_UnitaMisura[enum_UnitaMisura["Quintali"] = 4] = "Quintali";
    enum_UnitaMisura[enum_UnitaMisura["Milligrammi"] = 2032] = "Milligrammi";
    enum_UnitaMisura[enum_UnitaMisura["Tonnellate"] = 304] = "Tonnellate";
    enum_UnitaMisura[enum_UnitaMisura["Millilitri"] = 101] = "Millilitri";
    enum_UnitaMisura[enum_UnitaMisura["CentimetriCubi"] = 104] = "CentimetriCubi";
    enum_UnitaMisura[enum_UnitaMisura["Litri"] = 29] = "Litri";
    enum_UnitaMisura[enum_UnitaMisura["Metri_Cubi"] = 19] = "Metri_Cubi";
    enum_UnitaMisura[enum_UnitaMisura["Ettolitro"] = 2121] = "Ettolitro";
    enum_UnitaMisura[enum_UnitaMisura["Grammi__HA"] = 20] = "Grammi__HA";
    enum_UnitaMisura[enum_UnitaMisura["KG__HA"] = 88] = "KG__HA";
    enum_UnitaMisura[enum_UnitaMisura["UNITA__HA"] = 89] = "UNITA__HA";
    enum_UnitaMisura[enum_UnitaMisura["METRI3__HA"] = 90] = "METRI3__HA";
    enum_UnitaMisura[enum_UnitaMisura["Tonnellate__HA"] = 2098] = "Tonnellate__HA";
    enum_UnitaMisura[enum_UnitaMisura["NumUnita__HA"] = 176] = "NumUnita__HA";
    enum_UnitaMisura[enum_UnitaMisura["QUINTALI__HA"] = 2120] = "QUINTALI__HA";
    enum_UnitaMisura[enum_UnitaMisura["Tonnellate__HA_Spighe"] = 2112] = "Tonnellate__HA_Spighe";
    enum_UnitaMisura[enum_UnitaMisura["Litro__HA"] = 22] = "Litro__HA";
    enum_UnitaMisura[enum_UnitaMisura["Millilitri__Ha"] = 163] = "Millilitri__Ha";
    enum_UnitaMisura[enum_UnitaMisura["Millilitri__Quintale"] = 165] = "Millilitri__Quintale";
    enum_UnitaMisura[enum_UnitaMisura["KG__Quintale"] = 169] = "KG__Quintale";
    enum_UnitaMisura[enum_UnitaMisura["Grammi__Quintale"] = 174] = "Grammi__Quintale";
    enum_UnitaMisura[enum_UnitaMisura["Litri__Quintale"] = 303] = "Litri__Quintale";
    enum_UnitaMisura[enum_UnitaMisura["CC__HL"] = 21] = "CC__HL";
    enum_UnitaMisura[enum_UnitaMisura["Grammi__HL"] = 23] = "Grammi__HL";
    enum_UnitaMisura[enum_UnitaMisura["Milligrammi__HL"] = 126] = "Milligrammi__HL";
    enum_UnitaMisura[enum_UnitaMisura["Millilitri__HL"] = 164] = "Millilitri__HL";
    enum_UnitaMisura[enum_UnitaMisura["Litri__HL"] = 173] = "Litri__HL";
    enum_UnitaMisura[enum_UnitaMisura["Millilitri__Litro"] = 2016] = "Millilitri__Litro";
    enum_UnitaMisura[enum_UnitaMisura["Chilogrammi__HL"] = 175] = "Chilogrammi__HL";
    enum_UnitaMisura[enum_UnitaMisura["Grammi__Litro"] = 2003] = "Grammi__Litro";
    enum_UnitaMisura[enum_UnitaMisura["Milligrammi__Litro"] = 5001006] = "Milligrammi__Litro";
    enum_UnitaMisura[enum_UnitaMisura["Num_Piante"] = 92] = "Num_Piante";
    enum_UnitaMisura[enum_UnitaMisura["Unita_Seme"] = 93] = "Unita_Seme";
    enum_UnitaMisura[enum_UnitaMisura["Confezioni"] = 1003] = "Confezioni";
    enum_UnitaMisura[enum_UnitaMisura["Ettaro"] = 2123] = "Ettaro";
    enum_UnitaMisura[enum_UnitaMisura["Metri"] = 25] = "Metri";
    enum_UnitaMisura[enum_UnitaMisura["MetriQuadri"] = 28] = "MetriQuadri";
    enum_UnitaMisura[enum_UnitaMisura["Ore"] = 141] = "Ore";
    enum_UnitaMisura[enum_UnitaMisura["Giorni"] = 1002] = "Giorni";
    enum_UnitaMisura[enum_UnitaMisura["Numero_Trappole"] = 11] = "Numero_Trappole";
    enum_UnitaMisura[enum_UnitaMisura["Numero_Inneschi"] = 38] = "Numero_Inneschi";
    enum_UnitaMisura[enum_UnitaMisura["Numero_Diffusori_HA"] = 119] = "Numero_Diffusori_HA";
    enum_UnitaMisura[enum_UnitaMisura["Numero"] = 38] = "Numero";
    enum_UnitaMisura[enum_UnitaMisura["Anno"] = 2019] = "Anno";
    enum_UnitaMisura[enum_UnitaMisura["StagioneColturale"] = 2024] = "StagioneColturale";
    enum_UnitaMisura[enum_UnitaMisura["CicloColturale"] = 2025] = "CicloColturale";
    enum_UnitaMisura[enum_UnitaMisura["Montegradi"] = 5001040] = "Montegradi";
    enum_UnitaMisura[enum_UnitaMisura["Millimetri"] = 18] = "Millimetri";
    enum_UnitaMisura[enum_UnitaMisura["UNITA"] = 5001053] = "UNITA";
    enum_UnitaMisura[enum_UnitaMisura["Numero_Diffusori"] = 5001052] = "Numero_Diffusori";
})(enum_UnitaMisura || (enum_UnitaMisura = {}));
var enum_SEMINA_TIPO;
(function (enum_SEMINA_TIPO) {
    //Fast = 10,
    //Leggera = 20,
    //Leggera_Con_Dettagli_Magazzino = 30,
    enum_SEMINA_TIPO[enum_SEMINA_TIPO["Solo_Semina_Default"] = 30] = "Solo_Semina_Default";
    enum_SEMINA_TIPO[enum_SEMINA_TIPO["Semina_e_Modifica_Appezzamenti_Default"] = 40] = "Semina_e_Modifica_Appezzamenti_Default";
    enum_SEMINA_TIPO[enum_SEMINA_TIPO["Frazionamento_Appezzamenti_perLotto_e_Semina_sui_Singoli_Default"] = 50] = "Frazionamento_Appezzamenti_perLotto_e_Semina_sui_Singoli_Default";
    enum_SEMINA_TIPO[enum_SEMINA_TIPO["Solo_Semina_Vincolo"] = 60] = "Solo_Semina_Vincolo";
    enum_SEMINA_TIPO[enum_SEMINA_TIPO["Semina_e_Modifica_Appezzamenti_Vincolo"] = 70] = "Semina_e_Modifica_Appezzamenti_Vincolo";
    enum_SEMINA_TIPO[enum_SEMINA_TIPO["Frazionamento_Appezzamenti_perLotto_e_Semina_sui_Singoli_Vincolo"] = 80] = "Frazionamento_Appezzamenti_perLotto_e_Semina_sui_Singoli_Vincolo"; //frazionamento appezzamento + semina sui singoli (con magazzino)
})(enum_SEMINA_TIPO || (enum_SEMINA_TIPO = {}));
var enum_TipoControllo;
(function (enum_TipoControllo) {
    enum_TipoControllo[enum_TipoControllo["UNDEFINED"] = 0] = "UNDEFINED";
    enum_TipoControllo[enum_TipoControllo["CASELLA_TESTO"] = 1] = "CASELLA_TESTO";
    enum_TipoControllo[enum_TipoControllo["AREA_TESTO"] = 2] = "AREA_TESTO";
    enum_TipoControllo[enum_TipoControllo["MENU_DISCESA"] = 3] = "MENU_DISCESA";
    enum_TipoControllo[enum_TipoControllo["CASELLA_SPUNTA"] = 4] = "CASELLA_SPUNTA";
    enum_TipoControllo[enum_TipoControllo["CALENDARIO"] = 5] = "CALENDARIO";
    enum_TipoControllo[enum_TipoControllo["ALLEGATO"] = 6] = "ALLEGATO";
    enum_TipoControllo[enum_TipoControllo["LINK"] = 7] = "LINK";
    enum_TipoControllo[enum_TipoControllo["PASSWORD"] = 8] = "PASSWORD";
    enum_TipoControllo[enum_TipoControllo["MULTISELECT_ESTESA_SERVER"] = 9] = "MULTISELECT_ESTESA_SERVER";
    enum_TipoControllo[enum_TipoControllo["PULSANTE_SCELTA"] = 10] = "PULSANTE_SCELTA";
    enum_TipoControllo[enum_TipoControllo["IMMAGINE"] = 11] = "IMMAGINE";
    enum_TipoControllo[enum_TipoControllo["DDL_ESTESA_CLIENT"] = 12] = "DDL_ESTESA_CLIENT";
    enum_TipoControllo[enum_TipoControllo["GIS_VIEWER"] = 13] = "GIS_VIEWER";
    enum_TipoControllo[enum_TipoControllo["DDL_ESTESA_SERVER_LIGHT"] = 14] = "DDL_ESTESA_SERVER_LIGHT";
    enum_TipoControllo[enum_TipoControllo["NUMERO_INTERO"] = 15] = "NUMERO_INTERO";
    enum_TipoControllo[enum_TipoControllo["NUMERO_DECIMALE"] = 16] = "NUMERO_DECIMALE";
    enum_TipoControllo[enum_TipoControllo["MULTISELECT"] = 17] = "MULTISELECT";
})(enum_TipoControllo || (enum_TipoControllo = {}));
var enum_AlgoritmoCostiAccessori;
(function (enum_AlgoritmoCostiAccessori) {
    enum_AlgoritmoCostiAccessori[enum_AlgoritmoCostiAccessori["CAB"] = 1] = "CAB";
    enum_AlgoritmoCostiAccessori[enum_AlgoritmoCostiAccessori["SBTF"] = 2] = "SBTF";
    enum_AlgoritmoCostiAccessori[enum_AlgoritmoCostiAccessori["BASE"] = 3] = "BASE";
})(enum_AlgoritmoCostiAccessori || (enum_AlgoritmoCostiAccessori = {}));
var enum_PUARegolamenti_Tipo;
(function (enum_PUARegolamenti_Tipo) {
    enum_PUARegolamenti_Tipo[enum_PUARegolamenti_Tipo["PianoComcimazione"] = 1] = "PianoComcimazione";
    enum_PUARegolamenti_Tipo[enum_PUARegolamenti_Tipo["PUA"] = 2] = "PUA";
    enum_PUARegolamenti_Tipo[enum_PUARegolamenti_Tipo["Pan"] = 3] = "Pan";
    enum_PUARegolamenti_Tipo[enum_PUARegolamenti_Tipo["PianoNutrizionale"] = 4] = "PianoNutrizionale";
    enum_PUARegolamenti_Tipo[enum_PUARegolamenti_Tipo["PianoNutrizionale_IBF"] = 5] = "PianoNutrizionale_IBF";
})(enum_PUARegolamenti_Tipo || (enum_PUARegolamenti_Tipo = {}));
var enum_CodiciAnagrafe;
(function (enum_CodiciAnagrafe) {
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["Codice_Ausl"] = 4] = "Codice_Ausl";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["Centro_Sede_Legale"] = 101] = "Centro_Sede_Legale";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["Centro_Sede_Aziendale"] = 102] = "Centro_Sede_Aziendale";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["Centro_Stabilimento"] = 103] = "Centro_Stabilimento";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["TipoAttivita"] = 1000] = "TipoAttivita";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["DataFineControllo"] = 1001] = "DataFineControllo";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["CodiceCentro_Precedente"] = 1002] = "CodiceCentro_Precedente";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["CodiceCentro_Attuale"] = 1003] = "CodiceCentro_Attuale";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["PartitaIva_Fittizia"] = 1004] = "PartitaIva_Fittizia";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["Associazione_CODEX"] = 1005] = "Associazione_CODEX";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["Conformita_Biologico"] = 1006] = "Conformita_Biologico";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["Conformita_FilieraControllata"] = 1007] = "Conformita_FilieraControllata";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["OTE"] = 1009] = "OTE";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["CodiceCUAA"] = 1010] = "CodiceCUAA";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["DataFineImpiegoPNC"] = 1014] = "DataFineImpiegoPNC";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["OrientamentoProduttivo"] = 1015] = "OrientamentoProduttivo";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["TitoloPossesso"] = 1016] = "TitoloPossesso";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["MetodoDiProduzione"] = 1018] = "MetodoDiProduzione";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["pers_LegaleRappresentante"] = 1019] = "pers_LegaleRappresentante";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["pers_Conduttore"] = 1020] = "pers_Conduttore";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["pers_Delegato"] = 1021] = "pers_Delegato";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["pers_Detentore"] = 1022] = "pers_Detentore";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["ImpresaPAT"] = 1278] = "ImpresaPAT";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["Codice_Socio"] = 1033] = "Codice_Socio";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["Impianto_LimiteN"] = 1050] = "Impianto_LimiteN";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["Impianto_LimiteN_Organico"] = 1316] = "Impianto_LimiteN_Organico";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["Impianto_LimiteP"] = 1051] = "Impianto_LimiteP";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["Impianto_LimiteK"] = 1052] = "Impianto_LimiteK";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["Impianto_LimiteMg"] = 1053] = "Impianto_LimiteMg";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["Impianto_Ibrido"] = 1054] = "Impianto_Ibrido";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["Impianto_CodiceB_Maschio"] = 1055] = "Impianto_CodiceB_Maschio";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["Impianto_CodiceB_Femmina"] = 1056] = "Impianto_CodiceB_Femmina";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["Impianto_Genetica_Maschio"] = 1057] = "Impianto_Genetica_Maschio";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["Impianto_Genetica_Femmina"] = 1058] = "Impianto_Genetica_Femmina";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["Impianto_OffType_Maschio"] = 1059] = "Impianto_OffType_Maschio";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["Impianto_OffType_Femmina"] = 1060] = "Impianto_OffType_Femmina";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["Impianto_TraFila_Maschio"] = 1061] = "Impianto_TraFila_Maschio";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["Impianto_TraFila_Femmina"] = 1062] = "Impianto_TraFila_Femmina";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["Impianto_SuFila_Maschio"] = 1063] = "Impianto_SuFila_Maschio";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["Impianto_SuFila_Femmina"] = 1064] = "Impianto_SuFila_Femmina";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["Impianto_Interbina"] = 1065] = "Impianto_Interbina";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["Impianto_Germinabilita"] = 1066] = "Impianto_Germinabilita";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["Impianto_PianoSemina"] = 1071] = "Impianto_PianoSemina";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["Impianto_LottoFitosanitarioOmogeneo"] = 1072] = "Impianto_LottoFitosanitarioOmogeneo";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["Impianto_GroverCode"] = 1076] = "Impianto_GroverCode";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["Impianto_Nr_domanda_ACA"] = 1359] = "Impianto_Nr_domanda_ACA";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["Appezzamento_CodiceContratto"] = 1073] = "Appezzamento_CodiceContratto";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["Impianto_Cooperativa"] = 1074] = "Impianto_Cooperativa";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["Appezzamento_ConfiniRischio"] = 1075] = "Appezzamento_ConfiniRischio";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["Organismo_Referente"] = 1074] = "Organismo_Referente";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["GestioneDocumentiAllegati"] = 1077] = "GestioneDocumentiAllegati";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["CodiceRigaRiferimentoQuadroP"] = 1078] = "CodiceRigaRiferimentoQuadroP";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["Coltura_Precedente_1"] = 1079] = "Coltura_Precedente_1";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["Coltura_Precedente_2"] = 1080] = "Coltura_Precedente_2";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["Coltura_Precedente_3"] = 1081] = "Coltura_Precedente_3";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["Coltura_Precedente_4"] = 1082] = "Coltura_Precedente_4";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["Impianto_Taglio_Tuberi_Patate"] = 1083] = "Impianto_Taglio_Tuberi_Patate";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["Impianto_Parti_Tuberi_Patate"] = 1084] = "Impianto_Parti_Tuberi_Patate";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["Codice_Appezza_Biologico"] = 1085] = "Codice_Appezza_Biologico";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["Codice_Libro_Soci"] = 1086] = "Codice_Libro_Soci";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["Data_Iscrizione_Libro_Soci"] = 1087] = "Data_Iscrizione_Libro_Soci";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["Tecnico"] = 1088] = "Tecnico";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["Codice_Cliente"] = 1089] = "Codice_Cliente";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["Codice_Fornitore"] = 1090] = "Codice_Fornitore";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["Codice_Fornitore_2"] = 1091] = "Codice_Fornitore_2";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["Codice_Fornitore_3"] = 1092] = "Codice_Fornitore_3";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["Organismo_di_Controllo"] = 1205] = "Organismo_di_Controllo";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["Mandato"] = 1206] = "Mandato";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["Codice_Capitolato_Privato"] = 1093] = "Codice_Capitolato_Privato";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["Riferimento_Alfanumerico_Appezzamento"] = 1104] = "Riferimento_Alfanumerico_Appezzamento";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["Magazzino_Conferimento"] = 1122] = "Magazzino_Conferimento";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["Codice_Unione_OP"] = 1125] = "Codice_Unione_OP";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["Certificazione"] = 1130] = "Certificazione";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["Codice_GlobalGap"] = 1261] = "Codice_GlobalGap";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["Codice_GlobalGap2"] = 1314] = "Codice_GlobalGap2";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["Tribunale_di_registrazione"] = 1275] = "Tribunale_di_registrazione";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["Regolamento_Aziendale_Default"] = 1294] = "Regolamento_Aziendale_Default";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["Disciplinare_Aziendale_Default"] = 1295] = "Disciplinare_Aziendale_Default";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["Impianto_IAF_ImpegniAggiuntiviFacoltativi"] = 1296] = "Impianto_IAF_ImpegniAggiuntiviFacoltativi";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["Programmazione_Impianto_Pratica_Cod"] = 1298] = "Programmazione_Impianto_Pratica_Cod";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["INDICODE_EDI_Euritmo_Codice_punto_consegna_NAD"] = 4013] = "INDICODE_EDI_Euritmo_Codice_punto_consegna_NAD";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["INDICODE_EDI_Euritmo_Codice_magazzino_emissione_ordine_NAB"] = 4014] = "INDICODE_EDI_Euritmo_Codice_magazzino_emissione_ordine_NAB";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["INDICODE_EDI_Euritmo_Codice_fornitore_NAS_CodForn"] = 4015] = "INDICODE_EDI_Euritmo_Codice_fornitore_NAS_CodForn";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["INDICODE_EDI_Euritmo_Tipo_Codice_fornitore_NAS_QCodForn"] = 4016] = "INDICODE_EDI_Euritmo_Tipo_Codice_fornitore_NAS_QCodForn";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["GS1_CompanyPrefix"] = 1276] = "GS1_CompanyPrefix";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["BNDOO_BancaDatiOperatoriOrtofrutticoli"] = 1277] = "BNDOO_BancaDatiOperatoriOrtofrutticoli";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["GestioneContabile_DataInizio"] = 1284] = "GestioneContabile_DataInizio";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["GestioneContabile_ConsideraSaldiIniziali"] = 1285] = "GestioneContabile_ConsideraSaldiIniziali";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["Tipo_Gestione_Impresa"] = 1286] = "Tipo_Gestione_Impresa";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["Zespri_Codice_kPIN"] = 1287] = "Zespri_Codice_kPIN";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["Zespri_Block_Name"] = 1288] = "Zespri_Block_Name";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["Zepri_Grower_Number"] = 1317] = "Zepri_Grower_Number";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["Zepri_Identificativo_Flex2B"] = 1329] = "Zepri_Identificativo_Flex2B";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["Default_Sincro_DDT_Terremerse"] = 1289] = "Default_Sincro_DDT_Terremerse";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["CampoSperimentaleBZ"] = 3000] = "CampoSperimentaleBZ";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["SetAside"] = 3001] = "SetAside";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["IntercalareAzione3"] = 3002] = "IntercalareAzione3";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["Azione09_SiepieBoschetti"] = 3003] = "Azione09_SiepieBoschetti";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["Azione10_Laghetti"] = 3004] = "Azione10_Laghetti";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["AzioneG"] = 3005] = "AzioneG";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["ForestazioneL2080"] = 3006] = "ForestazioneL2080";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["Agricampeggio"] = 3007] = "Agricampeggio";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["Lago"] = 3008] = "Lago";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["Alberatura"] = 3009] = "Alberatura";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["AzioneF3"] = 3010] = "AzioneF3";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["AzioneD1"] = 3011] = "AzioneD1";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["AzioneF1"] = 3012] = "AzioneF1";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["VivaioOrnamentali"] = 3013] = "VivaioOrnamentali";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["Azione_Agroambientale"] = 3014] = "Azione_Agroambientale";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["Tara_improduttiva"] = 3015] = "Tara_improduttiva";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["Prato"] = 3016] = "Prato";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["Affitto"] = 3017] = "Affitto";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["Misura_2H"] = 3018] = "Misura_2H";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["Orto"] = 3019] = "Orto";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["Biomassa"] = 3020] = "Biomassa";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["Colture_a_perdere_per_fauna_selvatica"] = 3021] = "Colture_a_perdere_per_fauna_selvatica";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["Frutteto"] = 3022] = "Frutteto";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["Erbaio"] = 3023] = "Erbaio";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["Bosco"] = 3024] = "Bosco";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["NessunaMappaturaConGias"] = 3078] = "NessunaMappaturaConGias";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["Riferimento_Alfanumerico_Campo"] = 1279] = "Riferimento_Alfanumerico_Campo";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["Coltura_Appezzamento_Precedente_1"] = 1280] = "Coltura_Appezzamento_Precedente_1";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["Coltura_Appezzamento_Precedente_2"] = 1281] = "Coltura_Appezzamento_Precedente_2";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["Coltura_Appezzamento_Precedente_3"] = 1282] = "Coltura_Appezzamento_Precedente_3";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["Coltura_Appezzamento_Precedente_4"] = 1283] = "Coltura_Appezzamento_Precedente_4";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["Coltura_Campo_Precedente_1"] = 1290] = "Coltura_Campo_Precedente_1";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["Coltura_Campo_Precedente_2"] = 1291] = "Coltura_Campo_Precedente_2";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["Coltura_Campo_Precedente_3"] = 1292] = "Coltura_Campo_Precedente_3";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["Coltura_Campo_Precedente_4"] = 1293] = "Coltura_Campo_Precedente_4";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["Capitolato_Privato"] = 1093] = "Capitolato_Privato";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["Gruppo_Varietale_1"] = 1094] = "Gruppo_Varietale_1";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["Gruppo_Varietale_2"] = 1095] = "Gruppo_Varietale_2";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["Gruppo_Varietale_3"] = 1096] = "Gruppo_Varietale_3";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["Gruppo_Varietale_4"] = 1097] = "Gruppo_Varietale_4";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["Gruppo_Varietale_5"] = 1098] = "Gruppo_Varietale_5";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["Gruppo_Varietale_6"] = 1099] = "Gruppo_Varietale_6";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["Gruppo_Varietale_7"] = 1100] = "Gruppo_Varietale_7";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["Gruppo_Varietale_8"] = 1101] = "Gruppo_Varietale_8";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["Gruppo_Varietale_9"] = 1102] = "Gruppo_Varietale_9";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["Gruppo_Varietale_10"] = 1103] = "Gruppo_Varietale_10";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["Dettaglio_Specie_Personalizzato"] = 1108] = "Dettaglio_Specie_Personalizzato";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["Centro_Aziendale_Esterno_Collegato"] = 1337] = "Centro_Aziendale_Esterno_Collegato";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["PivaSuperUser_Origine_Dato"] = 1107] = "PivaSuperUser_Origine_Dato";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["Codice_ICQ"] = 1109] = "Codice_ICQ";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["Impianto_Codice_Programmazione"] = 1110] = "Impianto_Codice_Programmazione";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["CodiceREA"] = 1112] = "CodiceREA";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["CodiceISO"] = 1111] = "CodiceISO";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["NumIscrAlboSocCoop"] = 1113] = "NumIscrAlboSocCoop";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["NumRegImprese"] = 1119] = "NumRegImprese";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["CodiceStabilimento"] = 1114] = "CodiceStabilimento";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["CodiceConferente"] = 1115] = "CodiceConferente";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["CodiceProduttore"] = 1116] = "CodiceProduttore";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["CodiceCooperativa"] = 1117] = "CodiceCooperativa";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["Codice_Zona"] = 1118] = "Codice_Zona";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["Flag_Smart_Impianto"] = 1131] = "Flag_Smart_Impianto";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["Flag_Smart_Appezzamento"] = 1132] = "Flag_Smart_Appezzamento";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["Codice_Specie_Agea"] = 1133] = "Codice_Specie_Agea";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["Codice_Cultivar_Agea"] = 1134] = "Codice_Cultivar_Agea";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["Isola"] = 1320] = "Isola";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["codice_RUOP"] = 1321] = "codice_RUOP";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["Codice_Sito_Vivaio"] = 1323] = "Codice_Sito_Vivaio";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["Contratto_Produzione"] = 1324] = "Contratto_Produzione";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["Sup_Contratto"] = 1325] = "Sup_Contratto";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["Filiera"] = 1326] = "Filiera";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["Riferimento_Trasferimento_Dati"] = 1327] = "Riferimento_Trasferimento_Dati";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["Data_Inizio_Portinnesto"] = 1328] = "Data_Inizio_Portinnesto";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["CodiceCliente_FRUTTAGEL"] = 2025] = "CodiceCliente_FRUTTAGEL";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["TracciaEsportazioneSIGPA_Fabbricati_XFertilizzanti"] = 5007] = "TracciaEsportazioneSIGPA_Fabbricati_XFertilizzanti";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["TracciaEsportazioneSIGPA_Fabbricati_XFormulati"] = 5017] = "TracciaEsportazioneSIGPA_Fabbricati_XFormulati";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["TracciaEsportazioneSIGPA_ChiusuraGiacenze_XFertilizzanti"] = 5008] = "TracciaEsportazioneSIGPA_ChiusuraGiacenze_XFertilizzanti";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["TracciaEsportazioneSIGPA_ChiusuraGiacenze_XFormulati"] = 5018] = "TracciaEsportazioneSIGPA_ChiusuraGiacenze_XFormulati";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["CodiceCliente_GranfruttaZani"] = 2029] = "CodiceCliente_GranfruttaZani";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["CodiceCliente_Apofruit"] = 2013] = "CodiceCliente_Apofruit";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["CodiceCliente_Orogel"] = 2039] = "CodiceCliente_Orogel";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["CodiceCliente_Apot"] = 2042] = "CodiceCliente_Apot";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["CodiceCliente_Tecnoterr"] = 2063] = "CodiceCliente_Tecnoterr";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["CodiceCliente_Casalasco"] = 2064] = "CodiceCliente_Casalasco";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["acciseDAA_CodiceAccisa_Mittente"] = 4003] = "acciseDAA_CodiceAccisa_Mittente";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["acciseDAA_CodiceAccisa_UfficioDoganale"] = 4005] = "acciseDAA_CodiceAccisa_UfficioDoganale";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["acciseDAA_CodiceAccisa_Destinatario"] = 4006] = "acciseDAA_CodiceAccisa_Destinatario";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["acciseDAA_CodiceAccisa_codiceUA"] = 4008] = "acciseDAA_CodiceAccisa_codiceUA";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["acciseDAA_Accise_Conto_Garanzia"] = 4009] = "acciseDAA_Accise_Conto_Garanzia";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["acciseDAA_Codice_Accise_Prefisso"] = 4010] = "acciseDAA_Codice_Accise_Prefisso";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["acciseDAA_VIDIMA_RegistroElettronica"] = 4011] = "acciseDAA_VIDIMA_RegistroElettronica";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["Contatto_OrganismoDiControllo_BIO"] = 4018] = "Contatto_OrganismoDiControllo_BIO";
    //CBI corporate interbancario
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["CBI_CodiceSIA"] = 1264] = "CBI_CodiceSIA";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["Codice_Centro"] = 1265] = "Codice_Centro";
    //spesometro
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["CodiceAteco2007"] = 1266] = "CodiceAteco2007";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["codiceFiscaleProduttoreSoftware"] = 1267] = "codiceFiscaleProduttoreSoftware";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["Spesometro_intermediario_CodFisc"] = 1268] = "Spesometro_intermediario_CodFisc";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["Spesometro_intermediario_AlboCAF"] = 1269] = "Spesometro_intermediario_AlboCAF";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["SISPAC_Codice_Anagrafico"] = 4007] = "SISPAC_Codice_Anagrafico";
    //----CODICI APOFRUIT SIAGR
    //inizio 1135
    //impresa
    //V01CON00_VCCOD = 1213 //Codice Conferente
    //V01CON00_VCCOD = Codice_Socio //Codice Socio (Conferente) uso quello presente in gias, visualizzato SOCIO
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["V01CON00_VCDNA"] = 1135] = "V01CON00_VCDNA";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["V01CON00_VCLNA"] = 1136] = "V01CON00_VCLNA";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["V01CON00_VCZON"] = 1137] = "V01CON00_VCZON";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["V01CON00_VCSUA"] = 1138] = "V01CON00_VCSUA";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["V01CON00_VCQTE"] = 1139] = "V01CON00_VCQTE";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["V01CON00_VCGRU"] = 1140] = "V01CON00_VCGRU";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["V01CON00_VCTRA"] = 1141] = "V01CON00_VCTRA";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["V01CON00_VCNIS"] = 1142] = "V01CON00_VCNIS";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["V01CON00_VCDIS"] = 1143] = "V01CON00_VCDIS";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["V01CON00_VCAIC"] = 1144] = "V01CON00_VCAIC";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["V01CON00_VCIFA"] = 1145] = "V01CON00_VCIFA";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["V01CON00_VCLIS"] = 1146] = "V01CON00_VCLIS";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["V01CON00_VCMEZ"] = 1147] = "V01CON00_VCMEZ";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["V01CON00_VCVAL"] = 1240] = "V01CON00_VCVAL";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["V01CON00_VCPRP"] = 1148] = "V01CON00_VCPRP";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["V01CON00_VCAT1"] = 1149] = "V01CON00_VCAT1";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["V01CON00_VCAT2"] = 1150] = "V01CON00_VCAT2";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["V01CON00_VCAT3"] = 1151] = "V01CON00_VCAT3";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["V01CON00_VCAT4"] = 1152] = "V01CON00_VCAT4";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["V01CON00_VCAT5"] = 1153] = "V01CON00_VCAT5";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["V01CON00_VCAT6"] = 1154] = "V01CON00_VCAT6";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["V01CON00_VCAT7"] = 1155] = "V01CON00_VCAT7";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["V01CON00_VCAT8"] = 1156] = "V01CON00_VCAT8";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["V01CON00_VCAT9"] = 1157] = "V01CON00_VCAT9";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["V01CON00_VCAT0"] = 1158] = "V01CON00_VCAT0";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["V01CON00_VCDUM"] = 1175] = "V01CON00_VCDUM";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["V01CON00_VCANN"] = 1160] = "V01CON00_VCANN";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["V01CON00_VTPCON"] = 1161] = "V01CON00_VTPCON";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["V01CON00_VCCOIS"] = 1162] = "V01CON00_VCCOIS";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["Stabilimento"] = 1163] = "Stabilimento";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["V01CON00_VANAN"] = 1164] = "V01CON00_VANAN";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["V01CON00_VANUL"] = 1165] = "V01CON00_VANUL";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["V01CON00_VANULI"] = 1166] = "V01CON00_VANULI";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["V01CON00_VLIATR"] = 1167] = "V01CON00_VLIATR";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["V01CON00_VLIRTR"] = 1168] = "V01CON00_VLIRTR";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["V01CON00_VCFOR"] = 1169] = "V01CON00_VCFOR";
    //impresadettagli
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["CATCON0F_CCRAP"] = 1170] = "CATCON0F_CCRAP";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["CATCON0F_CCEST"] = 1171] = "CATCON0F_CCEST";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["CATCON0F_CCRIF"] = 1172] = "CATCON0F_CCRIF";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["CATCON0F_CCSES"] = 1173] = "CATCON0F_CCSES";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["CATCON0F_CCDTN"] = 1174] = "CATCON0F_CCDTN";
    //CATCON0F_CCDTV = 1175, //Data variazione/Taratura Atomiz. non lo sal,co, lo uso per la prima importaz e basta
    //centro
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["CATANA0F_CAFON"] = 1262] = "CATANA0F_CAFON";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["CATANA0F_CAZON"] = 1176] = "CATANA0F_CAZON";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["CATANA0F_CAZOP"] = 1177] = "CATANA0F_CAZOP";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["CATANA0F_CACON"] = 1241] = "CATANA0F_CACON";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["CATANA0F_CARES"] = 1242] = "CATANA0F_CARES";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["CATANA0F_CAFPR"] = 1243] = "CATANA0F_CAFPR";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["CATANA0F_CATCO"] = 1178] = "CATANA0F_CATCO";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["CATANA0F_CASUT"] = 1244] = "CATANA0F_CASUT";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["CATANA0F_CASUP"] = 1245] = "CATANA0F_CASUP";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["CATANA0F_CASUC"] = 1246] = "CATANA0F_CASUC";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["CATANA0F_CATAR"] = 1247] = "CATANA0F_CATAR";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["CATANA0F_CASUI"] = 1248] = "CATANA0F_CASUI";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["CATANA0F_CASUF"] = 1249] = "CATANA0F_CASUF";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["CATANA0F_CASUO"] = 1250] = "CATANA0F_CASUO";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["CATANA0F_CASUV"] = 1251] = "CATANA0F_CASUV";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["CATANA0F_CASUS"] = 1252] = "CATANA0F_CASUS";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["CATANA0F_CASUA"] = 1253] = "CATANA0F_CASUA";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["CATANA0F_CAALT"] = 1254] = "CATANA0F_CAALT";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["CATANA0F_CAFLI"] = 1255] = "CATANA0F_CAFLI";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["CATANA0F_CAFLH"] = 1256] = "CATANA0F_CAFLH";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["CATANA0F_CAFLR"] = 1257] = "CATANA0F_CAFLR";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["CATANA0F_CAREA"] = 1258] = "CATANA0F_CAREA";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["CATANA0F_CARED"] = 1259] = "CATANA0F_CARED";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["CATANA0F_CAPCA"] = 1260] = "CATANA0F_CAPCA";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["CATANA0F_CAA01"] = 1179] = "CATANA0F_CAA01";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["CATANA0F_CAA02"] = 1180] = "CATANA0F_CAA02";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["CATANA0F_CAA03"] = 1181] = "CATANA0F_CAA03";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["CATANA0F_CAA04"] = 1182] = "CATANA0F_CAA04";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["CATANA0F_CAA05"] = 1183] = "CATANA0F_CAA05";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["CATANA0F_CAA06"] = 1184] = "CATANA0F_CAA06";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["CATANA0F_CAA07"] = 1185] = "CATANA0F_CAA07";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["CATANA0F_CAA08"] = 1186] = "CATANA0F_CAA08";
    //impianto
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["CATIMP0F_CINPR"] = 1214] = "CATIMP0F_CINPR";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["CATIMP0F_CIFPC"] = 1187] = "CATIMP0F_CIFPC";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["CATIMP0F_CIFIR"] = 1188] = "CATIMP0F_CIFIR";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["CATIMP0F_CISER"] = 1189] = "CATIMP0F_CISER";
    //CATIMP0F_CILIN = 1190, //codice lotta intagrata, (uso capitolato)
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["CATIMP0F_CIRAC"] = 1191] = "CATIMP0F_CIRAC";
    //CATIMP0F_CIPIN = 1192, //Portinnesto
    //CATIMP0F_CIALL = 1193, //Allevamento
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["CATIMP0F_CIIRR"] = 1194] = "CATIMP0F_CIIRR";
    //CATIMP0F_CITPR = 1195, // tpo produzione-regolamento bio
    //CATIMP0F_CINAP = 1195, //numero appezzamento per consociazione (utilizzato enum_CodiciAnagrafe.Codice_Appezza_Biologico)
    //CATIMP0F_CIQTP = 1196, //raccolta ottimale
    //CATIMP0F_CIQTC = 1197, //raccolta corretta
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["CATIMP0F_CIC02"] = 1198] = "CATIMP0F_CIC02";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["CATIMP0F_CIC04"] = 1199] = "CATIMP0F_CIC04";
    //CATIMP0F_CITCO = 1200, //Tipo copertura
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["CATIMP0F_CIDAL"] = 1201] = "CATIMP0F_CIDAL";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["CATIMP0F_CIDEL"] = 1202] = "CATIMP0F_CIDEL";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["CATIMP0F_CITIM"] = 1203] = "CATIMP0F_CITIM";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["CATIMP0F_CISEQ"] = 1204] = "CATIMP0F_CISEQ";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["CATIMP0F_CISPE_CIVAR"] = 1205] = "CATIMP0F_CISPE_CIVAR";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["CATIMP0F_VarietaContratto"] = 1206] = "CATIMP0F_VarietaContratto";
    //impresa note codificate
    // V01NOC00_NCPRO_9000 = 1207, //codice ente certificazione bio
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["V01NOC00_NCPRO_9001"] = 1208] = "V01NOC00_NCPRO_9001";
    //V01NOC00_NCPRO_9002 = 1209, //Cellulare del socio
    //V01NOC00_NCPRO_9003 = 1210, //codice operatore bio
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["V01NOC00_NCPRO_9004"] = 1211] = "V01NOC00_NCPRO_9004";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["V01NOC00_NCPRO_9005"] = 1212] = "V01NOC00_NCPRO_9005";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["V01NOC00_NCPRO_9006"] = 1261] = "V01NOC00_NCPRO_9006";
    //impresa note generiche
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["V01NOC00_NCPRO_1"] = 1215] = "V01NOC00_NCPRO_1";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["V01NOC00_NCPRO_2"] = 1216] = "V01NOC00_NCPRO_2";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["V01NOC00_NCPRO_3"] = 1217] = "V01NOC00_NCPRO_3";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["V01NOC00_NCPRO_4"] = 1218] = "V01NOC00_NCPRO_4";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["V01NOC00_NCPRO_5"] = 1219] = "V01NOC00_NCPRO_5";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["V01NOC00_NCPRO_6"] = 1220] = "V01NOC00_NCPRO_6";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["V01NOC00_NCPRO_7"] = 1221] = "V01NOC00_NCPRO_7";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["V01NOC00_NCPRO_8"] = 1222] = "V01NOC00_NCPRO_8";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["V01NOC00_NCPRO_9"] = 1223] = "V01NOC00_NCPRO_9";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["V01NOC00_NCPRO_10"] = 1224] = "V01NOC00_NCPRO_10";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["V01NOC00_NCPRO_11"] = 1225] = "V01NOC00_NCPRO_11";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["V01NOC00_NCPRO_12"] = 1226] = "V01NOC00_NCPRO_12";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["V01NOC00_NCPRO_13"] = 1227] = "V01NOC00_NCPRO_13";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["V01NOC00_NCPRO_14"] = 1218] = "V01NOC00_NCPRO_14";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["V01NOC00_NCPRO_15"] = 1229] = "V01NOC00_NCPRO_15";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["V01NOC00_NCPRO_16"] = 1230] = "V01NOC00_NCPRO_16";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["V01NOC00_NCPRO_17"] = 1231] = "V01NOC00_NCPRO_17";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["V01NOC00_NCPRO_18"] = 1232] = "V01NOC00_NCPRO_18";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["V01NOC00_NCPRO_19"] = 1233] = "V01NOC00_NCPRO_19";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["V01NOC00_NCPRO_20"] = 1234] = "V01NOC00_NCPRO_20";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["V01NOC00_NCPRO_21"] = 1235] = "V01NOC00_NCPRO_21";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["V01NOC00_NCPRO_22"] = 1236] = "V01NOC00_NCPRO_22";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["V01NOC00_NCPRO_23"] = 1237] = "V01NOC00_NCPRO_23";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["V01NOC00_NCPRO_24"] = 1238] = "V01NOC00_NCPRO_24";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["V01NOC00_NCPRO_25"] = 1239] = "V01NOC00_NCPRO_25";
    //----FINE CODICI APOFRUIT SIAGRultimo 1262
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["ORGANISMO_DI_CONTROLLO_BIO"] = 1263] = "ORGANISMO_DI_CONTROLLO_BIO";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["Fabbricato_Forno_Combustibile"] = 1270] = "Fabbricato_Forno_Combustibile";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["Fabbricato_Forno_Fiamma"] = 1271] = "Fabbricato_Forno_Fiamma";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["Fabbricato_Forno_Cantiere"] = 1272] = "Fabbricato_Forno_Cantiere";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["Fabbricato_Forno_Umidificazione"] = 1273] = "Fabbricato_Forno_Umidificazione";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["Fabbricato_Forno_Tipo"] = 1274] = "Fabbricato_Forno_Tipo";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["OrganismoRefIntestatarioQDC"] = 1299] = "OrganismoRefIntestatarioQDC";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["Codice_Impianto"] = 1300] = "Codice_Impianto";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["Distinta_Chiusa"] = 1301] = "Distinta_Chiusa";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["Codice_Impianto_Ribaltato"] = 1311] = "Codice_Impianto_Ribaltato";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["Algoritmo_Codifica"] = 1312] = "Algoritmo_Codifica";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["ScontoContattoDefault"] = 4000] = "ScontoContattoDefault";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["ListinoPrezziAcquistoDefault"] = 4001] = "ListinoPrezziAcquistoDefault";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["ListinoPrezziVenditaDefault"] = 4002] = "ListinoPrezziVenditaDefault";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["CodiceAccisa"] = 4003] = "CodiceAccisa";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["ModalitaPagamentoDefault"] = 4004] = "ModalitaPagamentoDefault";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["IBANDefault"] = 4012] = "IBANDefault";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["NumeroIscrizioneAlboAutotrasportatori"] = 4017] = "NumeroIscrizioneAlboAutotrasportatori";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["PEC"] = 4019] = "PEC";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["SDI"] = 4020] = "SDI";
    // --- Per Fattura Elettronica
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["CapitaleSociale"] = 1123] = "CapitaleSociale";
    // <see cref="enumTipoSocieta"/>
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["TipoSocieta"] = 1302] = "TipoSocieta";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["UfficioRea"] = 1304] = "UfficioRea";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["NumeroRea"] = 1305] = "NumeroRea";
    // <see cref="enumNumeroSoci"/>
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["NumeroSoci"] = 1306] = "NumeroSoci";
    // <see cref="enumStatoLiquidazione"/>
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["StatoLiquidazione"] = 1307] = "StatoLiquidazione";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["DataAttivazioneEFattura"] = 1309] = "DataAttivazioneEFattura";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["DataUltimaRicezioneEFattura"] = 1310] = "DataUltimaRicezioneEFattura";
    // <see cref="enumTipoContattoFattura"/>
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["TipoContattoFattura"] = 1303] = "TipoContattoFattura";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["PecContatto"] = 4019] = "PecContatto";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["CodiceSDI"] = 4020] = "CodiceSDI";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["RappresentanteFiscale"] = 4021] = "RappresentanteFiscale";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["Visibile_da_App"] = 1308] = "Visibile_da_App";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["UfficioICQRF"] = 1313] = "UfficioICQRF";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["CodiceParticella"] = 1318] = "CodiceParticella";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["Finalita_Concimazione_Impianto"] = 1319] = "Finalita_Concimazione_Impianto";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["Centro_CodiceStabilimento"] = 1322] = "Centro_CodiceStabilimento";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["Zespri_Fasi_Fase"] = 1330] = "Zespri_Fasi_Fase";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["Zespri_Fasi_Tipo"] = 1331] = "Zespri_Fasi_Tipo";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["Zespri_Fasi_Grower"] = 1332] = "Zespri_Fasi_Grower";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["Num_Piante_Femmine"] = 1333] = "Num_Piante_Femmine";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["Num_Piante_Maschi"] = 1334] = "Num_Piante_Maschi";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["Impresa_Pubblica"] = 1335] = "Impresa_Pubblica";
    enum_CodiciAnagrafe[enum_CodiciAnagrafe["TipologiaDIInnestoTrapianto"] = 1336] = "TipologiaDIInnestoTrapianto";
})(enum_CodiciAnagrafe || (enum_CodiciAnagrafe = {}));
var enum_Tipo_Salvataggio_QdC;
(function (enum_Tipo_Salvataggio_QdC) {
    enum_Tipo_Salvataggio_QdC[enum_Tipo_Salvataggio_QdC["Salva_ed_Esci"] = 1] = "Salva_ed_Esci";
    enum_Tipo_Salvataggio_QdC[enum_Tipo_Salvataggio_QdC["Salva_e_Nuovo"] = 2] = "Salva_e_Nuovo";
    enum_Tipo_Salvataggio_QdC[enum_Tipo_Salvataggio_QdC["Salva_e_Duplica"] = 3] = "Salva_e_Duplica";
    enum_Tipo_Salvataggio_QdC[enum_Tipo_Salvataggio_QdC["Salva_e_CDG"] = 4] = "Salva_e_CDG";
    enum_Tipo_Salvataggio_QdC[enum_Tipo_Salvataggio_QdC["Salva_Ricetta_e_Nuovo_Dettaglio"] = 5] = "Salva_Ricetta_e_Nuovo_Dettaglio";
    enum_Tipo_Salvataggio_QdC[enum_Tipo_Salvataggio_QdC["Salva_Visita_Aggiungi_Operazione"] = 6] = "Salva_Visita_Aggiungi_Operazione";
})(enum_Tipo_Salvataggio_QdC || (enum_Tipo_Salvataggio_QdC = {}));
var enum_doseQuantitaTotale;
(function (enum_doseQuantitaTotale) {
    enum_doseQuantitaTotale[enum_doseQuantitaTotale["Qta_Totale"] = 10] = "Qta_Totale";
    enum_doseQuantitaTotale[enum_doseQuantitaTotale["Dose"] = 11] = "Dose";
})(enum_doseQuantitaTotale || (enum_doseQuantitaTotale = {}));
var enum_TipoFormulato;
(function (enum_TipoFormulato) {
    enum_TipoFormulato[enum_TipoFormulato["Tutti"] = 0] = "Tutti";
    enum_TipoFormulato[enum_TipoFormulato["Antiparassitari"] = 1] = "Antiparassitari";
    enum_TipoFormulato[enum_TipoFormulato["Diserbanti"] = 2] = "Diserbanti";
    enum_TipoFormulato[enum_TipoFormulato["Fitoregolatori"] = 3] = "Fitoregolatori";
    enum_TipoFormulato[enum_TipoFormulato["Coadiuvanti"] = 4] = "Coadiuvanti";
    enum_TipoFormulato[enum_TipoFormulato["Concianti"] = 5] = "Concianti";
    enum_TipoFormulato[enum_TipoFormulato["Disseccanti"] = 6] = "Disseccanti";
    enum_TipoFormulato[enum_TipoFormulato["Geodisinfestanti"] = 7] = "Geodisinfestanti";
    enum_TipoFormulato[enum_TipoFormulato["Antiparassitari_Concianti"] = 8] = "Antiparassitari_Concianti";
    enum_TipoFormulato[enum_TipoFormulato["Diserbanti_Disseccanti"] = 9] = "Diserbanti_Disseccanti";
    enum_TipoFormulato[enum_TipoFormulato["Antiparassitari_Geodisinfestanti"] = 10] = "Antiparassitari_Geodisinfestanti";
    enum_TipoFormulato[enum_TipoFormulato["Corroboranti_Fisiofarmaci"] = 11] = "Corroboranti_Fisiofarmaci";
    enum_TipoFormulato[enum_TipoFormulato["PostRaccolta"] = 12] = "PostRaccolta";
    enum_TipoFormulato[enum_TipoFormulato["Antiparassitari_Concianti_Geodisinfestanti_Fitoregolatori_Coadiuvanti_CorroborantiFisiofarmaci"] = 13] = "Antiparassitari_Concianti_Geodisinfestanti_Fitoregolatori_Coadiuvanti_CorroborantiFisiofarmaci";
    enum_TipoFormulato[enum_TipoFormulato["ConfusioneSessuale"] = 14] = "ConfusioneSessuale";
    enum_TipoFormulato[enum_TipoFormulato["DisorientamentoSessuale"] = 15] = "DisorientamentoSessuale";
})(enum_TipoFormulato || (enum_TipoFormulato = {}));
var enum_Servizi;
(function (enum_Servizi) {
    enum_Servizi[enum_Servizi["QuadernoCampagnaStd"] = 1] = "QuadernoCampagnaStd";
    enum_Servizi[enum_Servizi["QuadernoCampagnaGlobal"] = 2] = "QuadernoCampagnaGlobal";
    enum_Servizi[enum_Servizi["RegistroTrattamenti"] = 3] = "RegistroTrattamenti";
    enum_Servizi[enum_Servizi["RegistroFertilizzazioni"] = 4] = "RegistroFertilizzazioni";
    enum_Servizi[enum_Servizi["RegistriCaricoScaricoMagazzino"] = 5] = "RegistriCaricoScaricoMagazzino";
    enum_Servizi[enum_Servizi["QuadernoCampagnaBio"] = 6] = "QuadernoCampagnaBio";
    enum_Servizi[enum_Servizi["RegistroVenditeBio"] = 7] = "RegistroVenditeBio";
    enum_Servizi[enum_Servizi["RegistroMateriePrimeBio"] = 8] = "RegistroMateriePrimeBio";
    enum_Servizi[enum_Servizi["PAPVegetale"] = 9] = "PAPVegetale";
    enum_Servizi[enum_Servizi["PAPZootecnico"] = 10] = "PAPZootecnico";
    enum_Servizi[enum_Servizi["PAPPreparazioni"] = 11] = "PAPPreparazioni";
    enum_Servizi[enum_Servizi["NotificaBio"] = 12] = "NotificaBio";
    enum_Servizi[enum_Servizi["PUA"] = 13] = "PUA";
    enum_Servizi[enum_Servizi["PianoConcimazione"] = 14] = "PianoConcimazione";
    enum_Servizi[enum_Servizi["CheckListCondizionalita"] = 15] = "CheckListCondizionalita";
    enum_Servizi[enum_Servizi["CheckListSicurezzaLavoro"] = 16] = "CheckListSicurezzaLavoro";
    enum_Servizi[enum_Servizi["CheckListGlobal"] = 17] = "CheckListGlobal";
    enum_Servizi[enum_Servizi["Teleregistri"] = 18] = "Teleregistri";
    enum_Servizi[enum_Servizi["Sistema_Qualit\u00C3_Nazionale_Produzione_Integrata"] = 19] = "Sistema_Qualit\u00C3_Nazionale_Produzione_Integrata";
    enum_Servizi[enum_Servizi["Esportazione_in_formato_Zespri"] = 20] = "Esportazione_in_formato_Zespri";
    enum_Servizi[enum_Servizi["Esecuzione_ed_avanzamento_delle_ricette"] = 21] = "Esecuzione_ed_avanzamento_delle_ricette";
    enum_Servizi[enum_Servizi["DocContabili_Ordine_Acquisto"] = 100] = "DocContabili_Ordine_Acquisto";
    enum_Servizi[enum_Servizi["DocContabili_Bolla_Ricevuta"] = 101] = "DocContabili_Bolla_Ricevuta";
    enum_Servizi[enum_Servizi["DocContabili_Bolla_Emessa"] = 102] = "DocContabili_Bolla_Emessa";
    enum_Servizi[enum_Servizi["DocContabili_Accettazione"] = 103] = "DocContabili_Accettazione";
    enum_Servizi[enum_Servizi["Profitosan"] = 1001] = "Profitosan";
    enum_Servizi[enum_Servizi["QStandard"] = 1002] = "QStandard";
    enum_Servizi[enum_Servizi["QPlus"] = 1003] = "QPlus";
    enum_Servizi[enum_Servizi["QBio"] = 1004] = "QBio";
    enum_Servizi[enum_Servizi["QFert"] = 1005] = "QFert";
    enum_Servizi[enum_Servizi["QMaps"] = 1006] = "QMaps";
    enum_Servizi[enum_Servizi["Condizionalita2018"] = 1007] = "Condizionalita2018";
    enum_Servizi[enum_Servizi["Profitosan_serverSide"] = 1008] = "Profitosan_serverSide";
    enum_Servizi[enum_Servizi["QDemetra"] = 1017] = "QDemetra";
    enum_Servizi[enum_Servizi["Workflow_di_attivazione_aziende_GIAS"] = 1050] = "Workflow_di_attivazione_aziende_GIAS";
    enum_Servizi[enum_Servizi["Registro_Trattamenti"] = 2001] = "Registro_Trattamenti";
    enum_Servizi[enum_Servizi["Registro_Trattamenti_Bio"] = 2002] = "Registro_Trattamenti_Bio";
    enum_Servizi[enum_Servizi["Quaderno_Campagna_Azienda"] = 2003] = "Quaderno_Campagna_Azienda";
    enum_Servizi[enum_Servizi["Quaderno_Campagna_Caa"] = 2004] = "Quaderno_Campagna_Caa";
    enum_Servizi[enum_Servizi["Registro_Fertilizzazioni_PUA"] = 2005] = "Registro_Fertilizzazioni_PUA";
    enum_Servizi[enum_Servizi["Quaderno_Campagna_CBPA"] = 2006] = "Quaderno_Campagna_CBPA";
    enum_Servizi[enum_Servizi["Gestione_UMA"] = 2007] = "Gestione_UMA";
    enum_Servizi[enum_Servizi["Gestione_Azienda"] = 3000] = "Gestione_Azienda";
    enum_Servizi[enum_Servizi["Azienda_NO_SQNPI_PUA"] = 2008] = "Azienda_NO_SQNPI_PUA";
})(enum_Servizi || (enum_Servizi = {}));
var enum_Cod_Regolamento;
(function (enum_Cod_Regolamento) {
    enum_Cod_Regolamento[enum_Cod_Regolamento["Non_Specificato"] = 0] = "Non_Specificato";
    enum_Cod_Regolamento[enum_Cod_Regolamento["Regolamento_Nessuno"] = 1] = "Regolamento_Nessuno";
    enum_Cod_Regolamento[enum_Cod_Regolamento["Regolamento_bio"] = 4] = "Regolamento_bio";
    enum_Cod_Regolamento[enum_Cod_Regolamento["Regolamento_ProduzioneIntegrata"] = 10] = "Regolamento_ProduzioneIntegrata";
})(enum_Cod_Regolamento || (enum_Cod_Regolamento = {}));
var enum_TipoNodo;
(function (enum_TipoNodo) {
    enum_TipoNodo[enum_TipoNodo["Utente"] = 1] = "Utente";
    enum_TipoNodo[enum_TipoNodo["Impresa"] = 2] = "Impresa";
    enum_TipoNodo[enum_TipoNodo["Centro"] = 3] = "Centro";
    enum_TipoNodo[enum_TipoNodo["Campo"] = 4] = "Campo";
    enum_TipoNodo[enum_TipoNodo["Serra"] = 41] = "Serra";
    enum_TipoNodo[enum_TipoNodo["Appezzamento"] = 5] = "Appezzamento";
    enum_TipoNodo[enum_TipoNodo["ImpiantoNudo"] = 6] = "ImpiantoNudo";
    enum_TipoNodo[enum_TipoNodo["ImpiantoArborea"] = 7] = "ImpiantoArborea";
    enum_TipoNodo[enum_TipoNodo["ImpiantoErbacea"] = 8] = "ImpiantoErbacea";
    enum_TipoNodo[enum_TipoNodo["ImpiantoOrticola"] = 9] = "ImpiantoOrticola";
    enum_TipoNodo[enum_TipoNodo["Impianto_Generico"] = 19] = "Impianto_Generico";
    enum_TipoNodo[enum_TipoNodo["Particella"] = 10] = "Particella";
    enum_TipoNodo[enum_TipoNodo["Persona"] = 11] = "Persona";
    enum_TipoNodo[enum_TipoNodo["CatastoAziendale"] = 18] = "CatastoAziendale";
    enum_TipoNodo[enum_TipoNodo["Fabbricato_Generico"] = 20] = "Fabbricato_Generico";
    enum_TipoNodo[enum_TipoNodo["f_Abitazione"] = 21] = "f_Abitazione";
    enum_TipoNodo[enum_TipoNodo["f_Magazzino"] = 22] = "f_Magazzino";
    enum_TipoNodo[enum_TipoNodo["f_Silos"] = 23] = "f_Silos";
    enum_TipoNodo[enum_TipoNodo["f_CellaFrigorifera"] = 24] = "f_CellaFrigorifera";
    enum_TipoNodo[enum_TipoNodo["f_ImpiantoLavorazione"] = 25] = "f_ImpiantoLavorazione";
    enum_TipoNodo[enum_TipoNodo["f_Stalla"] = 26] = "f_Stalla";
    enum_TipoNodo[enum_TipoNodo["f_Fienile"] = 33] = "f_Fienile";
    enum_TipoNodo[enum_TipoNodo["f_Essiccatoio"] = 10034] = "f_Essiccatoio";
    enum_TipoNodo[enum_TipoNodo["p_PortafoglioProdotti"] = 27] = "p_PortafoglioProdotti";
    enum_TipoNodo[enum_TipoNodo["p_Prodotto"] = 28] = "p_Prodotto";
    enum_TipoNodo[enum_TipoNodo["p_Preparazione"] = 29] = "p_Preparazione";
    enum_TipoNodo[enum_TipoNodo["x_ConsistenzeAnimali"] = 30] = "x_ConsistenzeAnimali";
    enum_TipoNodo[enum_TipoNodo["x_MovimentiMagazzino"] = 31] = "x_MovimentiMagazzino";
    enum_TipoNodo[enum_TipoNodo["x_PreparazioniAlimentari"] = 32] = "x_PreparazioniAlimentari";
    enum_TipoNodo[enum_TipoNodo["x_GiacenzeMagazzino"] = 34] = "x_GiacenzeMagazzino";
    enum_TipoNodo[enum_TipoNodo["x_ParcoMacchine"] = 35] = "x_ParcoMacchine";
    enum_TipoNodo[enum_TipoNodo["x_Contatti"] = 36] = "x_Contatti";
    enum_TipoNodo[enum_TipoNodo["x_ListaFabbricatiAziendali"] = 37] = "x_ListaFabbricatiAziendali";
    enum_TipoNodo[enum_TipoNodo["x_Cooperativa"] = 38] = "x_Cooperativa";
    enum_TipoNodo[enum_TipoNodo["x_Consorzio"] = 39] = "x_Consorzio";
    enum_TipoNodo[enum_TipoNodo["x_OP"] = 40] = "x_OP";
    enum_TipoNodo[enum_TipoNodo["Analisi_Certificato"] = 42] = "Analisi_Certificato";
    enum_TipoNodo[enum_TipoNodo["Analisi_Testata"] = 43] = "Analisi_Testata";
    enum_TipoNodo[enum_TipoNodo["Analisi_Dettaglio"] = 44] = "Analisi_Dettaglio";
    enum_TipoNodo[enum_TipoNodo["Analisi_Campione"] = 45] = "Analisi_Campione";
    enum_TipoNodo[enum_TipoNodo["PianoConcimazione_Testata"] = 46] = "PianoConcimazione_Testata";
    enum_TipoNodo[enum_TipoNodo["DistintaDiProduzione"] = 47] = "DistintaDiProduzione";
    enum_TipoNodo[enum_TipoNodo["x_VariazioniConsistenzeAnimali"] = 48] = "x_VariazioniConsistenzeAnimali";
    enum_TipoNodo[enum_TipoNodo["Cantine_Piani"] = 49] = "Cantine_Piani";
    enum_TipoNodo[enum_TipoNodo["Cantine_Vasche"] = 50] = "Cantine_Vasche";
    enum_TipoNodo[enum_TipoNodo["PlanningTestata"] = 51] = "PlanningTestata";
    enum_TipoNodo[enum_TipoNodo["PlanningEntita"] = 52] = "PlanningEntita";
    enum_TipoNodo[enum_TipoNodo["PlanningEntitaImpianto"] = 53] = "PlanningEntitaImpianto";
    enum_TipoNodo[enum_TipoNodo["Agenda"] = 54] = "Agenda";
    enum_TipoNodo[enum_TipoNodo["ricette_Testata"] = 60] = "ricette_Testata";
    enum_TipoNodo[enum_TipoNodo["ricette_dettaglio"] = 61] = "ricette_dettaglio";
    enum_TipoNodo[enum_TipoNodo["Anagrafica_Generica"] = 62] = "Anagrafica_Generica";
    enum_TipoNodo[enum_TipoNodo["AgendaDestinazioni"] = 63] = "AgendaDestinazioni";
    enum_TipoNodo[enum_TipoNodo["Precision"] = 64] = "Precision";
})(enum_TipoNodo || (enum_TipoNodo = {}));
var enum_PosizioniNodo;
(function (enum_PosizioniNodo) {
    enum_PosizioniNodo[enum_PosizioniNodo["TipoNodo"] = 0] = "TipoNodo";
    enum_PosizioniNodo[enum_PosizioniNodo["Piva"] = 1] = "Piva";
    enum_PosizioniNodo[enum_PosizioniNodo["Sa_Cod"] = 2] = "Sa_Cod";
    enum_PosizioniNodo[enum_PosizioniNodo["Campo_Cod"] = 3] = "Campo_Cod";
    enum_PosizioniNodo[enum_PosizioniNodo["Appezza"] = 4] = "Appezza";
    enum_PosizioniNodo[enum_PosizioniNodo["Id_Imp"] = 5] = "Id_Imp";
    enum_PosizioniNodo[enum_PosizioniNodo["p_Part_Cod"] = 6] = "p_Part_Cod";
    enum_PosizioniNodo[enum_PosizioniNodo["p_Provincia_Cod"] = 7] = "p_Provincia_Cod";
    enum_PosizioniNodo[enum_PosizioniNodo["p_Comune_Cod"] = 8] = "p_Comune_Cod";
    enum_PosizioniNodo[enum_PosizioniNodo["p_Sezione"] = 9] = "p_Sezione";
    enum_PosizioniNodo[enum_PosizioniNodo["p_Foglio"] = 10] = "p_Foglio";
    enum_PosizioniNodo[enum_PosizioniNodo["p_Numero"] = 11] = "p_Numero";
    enum_PosizioniNodo[enum_PosizioniNodo["p_Subalterno"] = 12] = "p_Subalterno";
    enum_PosizioniNodo[enum_PosizioniNodo["Cod_Fiscale"] = 13] = "Cod_Fiscale";
    enum_PosizioniNodo[enum_PosizioniNodo["Fabbricato_Cod"] = 14] = "Fabbricato_Cod";
    enum_PosizioniNodo[enum_PosizioniNodo["Prodotto_Cod"] = 15] = "Prodotto_Cod";
    enum_PosizioniNodo[enum_PosizioniNodo["Data_Lavorazione"] = 16] = "Data_Lavorazione";
    enum_PosizioniNodo[enum_PosizioniNodo["Analisi_Certificato_Cod"] = 17] = "Analisi_Certificato_Cod";
    enum_PosizioniNodo[enum_PosizioniNodo["Analisi_Testata_Cod"] = 18] = "Analisi_Testata_Cod";
    enum_PosizioniNodo[enum_PosizioniNodo["Analisi_Dettaglio_Cod"] = 19] = "Analisi_Dettaglio_Cod";
    enum_PosizioniNodo[enum_PosizioniNodo["Analisi_Campione_Cod"] = 20] = "Analisi_Campione_Cod";
    enum_PosizioniNodo[enum_PosizioniNodo["PianoConcimazione_Testata_Cod"] = 21] = "PianoConcimazione_Testata_Cod";
    enum_PosizioniNodo[enum_PosizioniNodo["Progetto_Cod"] = 22] = "Progetto_Cod";
    enum_PosizioniNodo[enum_PosizioniNodo["Programmazione_Cod"] = 23] = "Programmazione_Cod";
    enum_PosizioniNodo[enum_PosizioniNodo["Programmazione_Entita_Cod"] = 24] = "Programmazione_Entita_Cod";
    enum_PosizioniNodo[enum_PosizioniNodo["id_agenda"] = 25] = "id_agenda";
    enum_PosizioniNodo[enum_PosizioniNodo["PivaPadre"] = 26] = "PivaPadre";
})(enum_PosizioniNodo || (enum_PosizioniNodo = {}));
var Tipo_Polverulento;
(function (Tipo_Polverulento) {
    Tipo_Polverulento[Tipo_Polverulento["NonPolverulento"] = 0] = "NonPolverulento";
    Tipo_Polverulento[Tipo_Polverulento["Polverulento"] = 1] = "Polverulento";
})(Tipo_Polverulento || (Tipo_Polverulento = {}));
var enum_CodificaStampe;
(function (enum_CodificaStampe) {
    enum_CodificaStampe[enum_CodificaStampe["Nessuna"] = 0] = "Nessuna";
    enum_CodificaStampe[enum_CodificaStampe["SchedaCampagna_2078"] = 1] = "SchedaCampagna_2078";
    enum_CodificaStampe[enum_CodificaStampe["RegistroTrattamenti"] = 2] = "RegistroTrattamenti";
    enum_CodificaStampe[enum_CodificaStampe["SchedaRegistrazione"] = 3] = "SchedaRegistrazione";
    enum_CodificaStampe[enum_CodificaStampe["SchedaCampagna_Biologico"] = 4] = "SchedaCampagna_Biologico";
    enum_CodificaStampe[enum_CodificaStampe["Bolle"] = 5] = "Bolle";
    enum_CodificaStampe[enum_CodificaStampe["Fatture"] = 6] = "Fatture";
    enum_CodificaStampe[enum_CodificaStampe["Quadro_P"] = 7] = "Quadro_P";
    enum_CodificaStampe[enum_CodificaStampe["PianoRaccolta"] = 8] = "PianoRaccolta";
    enum_CodificaStampe[enum_CodificaStampe["SchedaMagazzinoMovimenti"] = 9] = "SchedaMagazzinoMovimenti";
    enum_CodificaStampe[enum_CodificaStampe["SchedaMagazzinoGiacenze"] = 10] = "SchedaMagazzinoGiacenze";
    enum_CodificaStampe[enum_CodificaStampe["SchedaMagazzinoFertilizzanti"] = 11] = "SchedaMagazzinoFertilizzanti";
    enum_CodificaStampe[enum_CodificaStampe["SchedaMagazzinoProdottiFitosanitari"] = 12] = "SchedaMagazzinoProdottiFitosanitari";
    enum_CodificaStampe[enum_CodificaStampe["SchedaCampagna_2078_Semplificata"] = 13] = "SchedaCampagna_2078_Semplificata";
    enum_CodificaStampe[enum_CodificaStampe["RegistroTrattamenti_Semplificata"] = 14] = "RegistroTrattamenti_Semplificata";
    enum_CodificaStampe[enum_CodificaStampe["SchedaRegistrazione_Semplificata"] = 15] = "SchedaRegistrazione_Semplificata";
    enum_CodificaStampe[enum_CodificaStampe["SchedaCampagna_Biologico_Semplificata"] = 16] = "SchedaCampagna_Biologico_Semplificata";
    enum_CodificaStampe[enum_CodificaStampe["ReportRisultatoFilrone"] = 17] = "ReportRisultatoFilrone";
    enum_CodificaStampe[enum_CodificaStampe["RiepilogoImpiegoSuperfici"] = 18] = "RiepilogoImpiegoSuperfici";
    enum_CodificaStampe[enum_CodificaStampe["Eurep_Gap"] = 19] = "Eurep_Gap";
    enum_CodificaStampe[enum_CodificaStampe["SchedaColturale_Biologico"] = 20] = "SchedaColturale_Biologico";
    enum_CodificaStampe[enum_CodificaStampe["SchedaMateriePrime_Biologico"] = 21] = "SchedaMateriePrime_Biologico";
    enum_CodificaStampe[enum_CodificaStampe["SchedaVendite_Biologico"] = 22] = "SchedaVendite_Biologico";
    enum_CodificaStampe[enum_CodificaStampe["Esporta_GiasToSap"] = 23] = "Esporta_GiasToSap";
    enum_CodificaStampe[enum_CodificaStampe["PAP_Vegetale"] = 24] = "PAP_Vegetale";
    enum_CodificaStampe[enum_CodificaStampe["SchedaTracciabilita"] = 25] = "SchedaTracciabilita";
    enum_CodificaStampe[enum_CodificaStampe["ReportConserveItalia"] = 26] = "ReportConserveItalia";
    enum_CodificaStampe[enum_CodificaStampe["SchedaCampagna_ConserveItalia"] = 27] = "SchedaCampagna_ConserveItalia";
    enum_CodificaStampe[enum_CodificaStampe["RapportinoStrube"] = 28] = "RapportinoStrube";
    enum_CodificaStampe[enum_CodificaStampe["Eurep_Gap_Semplificata"] = 29] = "Eurep_Gap_Semplificata";
    enum_CodificaStampe[enum_CodificaStampe["DatiAnelloFilieraIngresso"] = 30] = "DatiAnelloFilieraIngresso";
    enum_CodificaStampe[enum_CodificaStampe["DatiAnelloFilieraLegameLotti"] = 31] = "DatiAnelloFilieraLegameLotti";
    enum_CodificaStampe[enum_CodificaStampe["GestioneAllegati"] = 32] = "GestioneAllegati";
    enum_CodificaStampe[enum_CodificaStampe["AnalisiCosti_XLS"] = 33] = "AnalisiCosti_XLS";
    enum_CodificaStampe[enum_CodificaStampe["AnalisiRicavi_XLS"] = 34] = "AnalisiRicavi_XLS";
    enum_CodificaStampe[enum_CodificaStampe["MarginiEconomici_XLS"] = 36] = "MarginiEconomici_XLS";
    enum_CodificaStampe[enum_CodificaStampe["SchedaTracciabilita_ByLotto"] = 35] = "SchedaTracciabilita_ByLotto";
    enum_CodificaStampe[enum_CodificaStampe["EstrattoreDatiGrafici"] = 37] = "EstrattoreDatiGrafici";
    enum_CodificaStampe[enum_CodificaStampe["LibroConferimenti"] = 38] = "LibroConferimenti";
    enum_CodificaStampe[enum_CodificaStampe["PianoColturale"] = 39] = "PianoColturale";
    enum_CodificaStampe[enum_CodificaStampe["SchedaCampagna_Pizzoli"] = 40] = "SchedaCampagna_Pizzoli";
    enum_CodificaStampe[enum_CodificaStampe["Esportazione_OP_Inv"] = 41] = "Esportazione_OP_Inv";
    enum_CodificaStampe[enum_CodificaStampe["Esportatore_Universale_Impianti"] = 42] = "Esportatore_Universale_Impianti";
    enum_CodificaStampe[enum_CodificaStampe["Esportatore_Universale_Imprese"] = 43] = "Esportatore_Universale_Imprese";
    enum_CodificaStampe[enum_CodificaStampe["Esportatore_Universale_Centri"] = 44] = "Esportatore_Universale_Centri";
    enum_CodificaStampe[enum_CodificaStampe["Esportatore_Universale_Appezza"] = 45] = "Esportatore_Universale_Appezza";
    enum_CodificaStampe[enum_CodificaStampe["Esportatore_Universale_Agenda"] = 46] = "Esportatore_Universale_Agenda";
    enum_CodificaStampe[enum_CodificaStampe["AnalisiTerreno"] = 47] = "AnalisiTerreno";
    enum_CodificaStampe[enum_CodificaStampe["Report_RiconversioneVarietale"] = 48] = "Report_RiconversioneVarietale";
    enum_CodificaStampe[enum_CodificaStampe["Esportatore_Universale_Rintraccio"] = 49] = "Esportatore_Universale_Rintraccio";
    enum_CodificaStampe[enum_CodificaStampe["Verifica_Conformita"] = 50] = "Verifica_Conformita";
    enum_CodificaStampe[enum_CodificaStampe["Report_ImpegnoProduzioneSoci"] = 51] = "Report_ImpegnoProduzioneSoci";
    enum_CodificaStampe[enum_CodificaStampe["Esportazione_OP_Gest"] = 52] = "Esportazione_OP_Gest";
    enum_CodificaStampe[enum_CodificaStampe["ImportaAnagrafiche_XLS2GIAS"] = 53] = "ImportaAnagrafiche_XLS2GIAS";
    enum_CodificaStampe[enum_CodificaStampe["GestioneRicette_Lista"] = 54] = "GestioneRicette_Lista";
    enum_CodificaStampe[enum_CodificaStampe["Registro_FattureAcquisto"] = 55] = "Registro_FattureAcquisto";
    enum_CodificaStampe[enum_CodificaStampe["Registro_FattureVendita"] = 56] = "Registro_FattureVendita";
    enum_CodificaStampe[enum_CodificaStampe["Registro_Corrispettivi"] = 57] = "Registro_Corrispettivi";
    enum_CodificaStampe[enum_CodificaStampe["Registro_AltriCosti"] = 58] = "Registro_AltriCosti";
    enum_CodificaStampe[enum_CodificaStampe["Registro_AltriRicavi"] = 59] = "Registro_AltriRicavi";
    enum_CodificaStampe[enum_CodificaStampe["Registro_PrimaNota"] = 60] = "Registro_PrimaNota";
    enum_CodificaStampe[enum_CodificaStampe["Lista_InsolutiClienti"] = 61] = "Lista_InsolutiClienti";
    enum_CodificaStampe[enum_CodificaStampe["Lista_InsolutiFornitori"] = 62] = "Lista_InsolutiFornitori";
    enum_CodificaStampe[enum_CodificaStampe["LiquidazionePeriodica_IVA"] = 63] = "LiquidazionePeriodica_IVA";
    enum_CodificaStampe[enum_CodificaStampe["Bilancio_Civilistico"] = 64] = "Bilancio_Civilistico";
    enum_CodificaStampe[enum_CodificaStampe["PianoDeiConti"] = 65] = "PianoDeiConti";
    enum_CodificaStampe[enum_CodificaStampe["Report_NPK_Totali"] = 66] = "Report_NPK_Totali";
    enum_CodificaStampe[enum_CodificaStampe["Bolle_Conferimento_Soci"] = 67] = "Bolle_Conferimento_Soci";
    enum_CodificaStampe[enum_CodificaStampe["Bolle_Conferimento_Diversi"] = 68] = "Bolle_Conferimento_Diversi";
    enum_CodificaStampe[enum_CodificaStampe["PAP_Zootecnico"] = 69] = "PAP_Zootecnico";
    enum_CodificaStampe[enum_CodificaStampe["Costo_Manodopera_XLS"] = 70] = "Costo_Manodopera_XLS";
    enum_CodificaStampe[enum_CodificaStampe["Costo_ParcoMacchine_XLS"] = 71] = "Costo_ParcoMacchine_XLS";
    enum_CodificaStampe[enum_CodificaStampe["Analisi_Vino"] = 72] = "Analisi_Vino";
    enum_CodificaStampe[enum_CodificaStampe["RicevuteFiscali"] = 73] = "RicevuteFiscali";
    enum_CodificaStampe[enum_CodificaStampe["Atto_Notorio"] = 74] = "Atto_Notorio";
    enum_CodificaStampe[enum_CodificaStampe["Adesione_Etico_Ambientale"] = 75] = "Adesione_Etico_Ambientale";
    enum_CodificaStampe[enum_CodificaStampe["Tenuta_Scheda_Campagna"] = 76] = "Tenuta_Scheda_Campagna";
    enum_CodificaStampe[enum_CodificaStampe["Adesione_DPI"] = 77] = "Adesione_DPI";
    enum_CodificaStampe[enum_CodificaStampe["Impegnativa_Eurep"] = 78] = "Impegnativa_Eurep";
    enum_CodificaStampe[enum_CodificaStampe["Impegnativa_QC"] = 79] = "Impegnativa_QC";
    enum_CodificaStampe[enum_CodificaStampe["Impegnativa_Confusione_Sessuale"] = 80] = "Impegnativa_Confusione_Sessuale";
    enum_CodificaStampe[enum_CodificaStampe["Codice_Condotta"] = 81] = "Codice_Condotta";
    enum_CodificaStampe[enum_CodificaStampe["Modello4"] = 82] = "Modello4";
    enum_CodificaStampe[enum_CodificaStampe["Registro_Stalla"] = 83] = "Registro_Stalla";
    enum_CodificaStampe[enum_CodificaStampe["ImportaAnagraficheAnimali_XLS2GIAS"] = 84] = "ImportaAnagraficheAnimali_XLS2GIAS";
    enum_CodificaStampe[enum_CodificaStampe["VasiVinari"] = 85] = "VasiVinari";
    enum_CodificaStampe[enum_CodificaStampe["GestioneCondizionalita"] = 86] = "GestioneCondizionalita";
    enum_CodificaStampe[enum_CodificaStampe["Esportatore_Codifiche_Cultivar"] = 87] = "Esportatore_Codifiche_Cultivar";
    enum_CodificaStampe[enum_CodificaStampe["Esportatore_Codifiche_SpecieVegetali"] = 88] = "Esportatore_Codifiche_SpecieVegetali";
    enum_CodificaStampe[enum_CodificaStampe["Produzioni_XLS"] = 89] = "Produzioni_XLS";
    enum_CodificaStampe[enum_CodificaStampe["FiltroStrube"] = 90] = "FiltroStrube";
    enum_CodificaStampe[enum_CodificaStampe["Esportazione_AnagraficaProdotti"] = 91] = "Esportazione_AnagraficaProdotti";
    enum_CodificaStampe[enum_CodificaStampe["PacchettoIgiene_RegistroFornitori"] = 92] = "PacchettoIgiene_RegistroFornitori";
    enum_CodificaStampe[enum_CodificaStampe["PacchettoIgiene_RegistroClienti"] = 93] = "PacchettoIgiene_RegistroClienti";
    enum_CodificaStampe[enum_CodificaStampe["PacchettoIgiene_SchedaUsoAlimentiOGM"] = 94] = "PacchettoIgiene_SchedaUsoAlimentiOGM";
    enum_CodificaStampe[enum_CodificaStampe["PacchettoIgiene_RegistroAlimentazioneStalla"] = 95] = "PacchettoIgiene_RegistroAlimentazioneStalla";
    enum_CodificaStampe[enum_CodificaStampe["PacchettoIgiene_RegistroRazionamento"] = 96] = "PacchettoIgiene_RegistroRazionamento";
    enum_CodificaStampe[enum_CodificaStampe["PacchettoIgiene_RegistroAnalisiNonConformi"] = 97] = "PacchettoIgiene_RegistroAnalisiNonConformi";
    // BUCO NEL 98
    enum_CodificaStampe[enum_CodificaStampe["Esportazione_AnagraficaContatti"] = 99] = "Esportazione_AnagraficaContatti";
    enum_CodificaStampe[enum_CodificaStampe["Esportazione_CellulariContatti"] = 100] = "Esportazione_CellulariContatti";
    enum_CodificaStampe[enum_CodificaStampe["Analisi_Vino_Derivanti_Da_Travasi"] = 101] = "Analisi_Vino_Derivanti_Da_Travasi";
    enum_CodificaStampe[enum_CodificaStampe["Bilanci_DiVerifica_Confronto"] = 102] = "Bilanci_DiVerifica_Confronto";
    enum_CodificaStampe[enum_CodificaStampe["Nota_Accredito"] = 103] = "Nota_Accredito";
    enum_CodificaStampe[enum_CodificaStampe["Mastrino"] = 104] = "Mastrino";
    enum_CodificaStampe[enum_CodificaStampe["Esportazione_OP_Gest_Coop"] = 105] = "Esportazione_OP_Gest_Coop";
    enum_CodificaStampe[enum_CodificaStampe["Registri_Preparazioni"] = 106] = "Registri_Preparazioni";
    enum_CodificaStampe[enum_CodificaStampe["EtichetteVascheEnologiche"] = 107] = "EtichetteVascheEnologiche";
    // 'BUCO X NICOLETTA 108
    enum_CodificaStampe[enum_CodificaStampe["Bilancio_Fertilizzazioni"] = 109] = "Bilancio_Fertilizzazioni";
    enum_CodificaStampe[enum_CodificaStampe["Programmazione_Vegetale"] = 110] = "Programmazione_Vegetale";
    enum_CodificaStampe[enum_CodificaStampe["Esporta_GiasToXMLPubblico"] = 111] = "Esporta_GiasToXMLPubblico";
    enum_CodificaStampe[enum_CodificaStampe["Esporta_Conferimenti_JDEdwards"] = 112] = "Esporta_Conferimenti_JDEdwards";
    enum_CodificaStampe[enum_CodificaStampe["Buono_Accettazione_Diversi"] = 113] = "Buono_Accettazione_Diversi";
    enum_CodificaStampe[enum_CodificaStampe["Buono_Accettazione"] = 114] = "Buono_Accettazione";
    enum_CodificaStampe[enum_CodificaStampe["Registro_Fertilizzazioni"] = 115] = "Registro_Fertilizzazioni";
    enum_CodificaStampe[enum_CodificaStampe["SchedaTracciabilita_Animale"] = 116] = "SchedaTracciabilita_Animale";
    enum_CodificaStampe[enum_CodificaStampe["RaccoltaDatiAnagrafici"] = 117] = "RaccoltaDatiAnagrafici";
    enum_CodificaStampe[enum_CodificaStampe["Importa_RaccolteConferimenti_DaRintraccio"] = 118] = "Importa_RaccolteConferimenti_DaRintraccio";
    enum_CodificaStampe[enum_CodificaStampe["ADD_Filtro_Report_Accettazione_DaDiversi"] = 119] = "ADD_Filtro_Report_Accettazione_DaDiversi";
    enum_CodificaStampe[enum_CodificaStampe["ADD_Riepilogo_Conf_XSpecie"] = 120] = "ADD_Riepilogo_Conf_XSpecie";
    enum_CodificaStampe[enum_CodificaStampe["ADD_EC_Bolle_Accettazione_DaDiversi"] = 121] = "ADD_EC_Bolle_Accettazione_DaDiversi";
    enum_CodificaStampe[enum_CodificaStampe["ADD_EC_Imballi"] = 122] = "ADD_EC_Imballi";
    enum_CodificaStampe[enum_CodificaStampe["ADD_Saldo_Imballi"] = 123] = "ADD_Saldo_Imballi";
    enum_CodificaStampe[enum_CodificaStampe["ADD_Export_Bolle_Accettazione_DaDiversi"] = 124] = "ADD_Export_Bolle_Accettazione_DaDiversi";
    enum_CodificaStampe[enum_CodificaStampe["ADD_Export_Traportatori"] = 125] = "ADD_Export_Traportatori";
    enum_CodificaStampe[enum_CodificaStampe["Importazione_DDT_PianoColturale"] = 126] = "Importazione_DDT_PianoColturale";
    enum_CodificaStampe[enum_CodificaStampe["Mandato_Trasmissione_Telematica_Dati"] = 127] = "Mandato_Trasmissione_Telematica_Dati";
    enum_CodificaStampe[enum_CodificaStampe["DOCO"] = 128] = "DOCO";
    enum_CodificaStampe[enum_CodificaStampe["DAA"] = 129] = "DAA";
    enum_CodificaStampe[enum_CodificaStampe["Impegnativa_Orticole_Gest_Annuale"] = 130] = "Impegnativa_Orticole_Gest_Annuale";
    enum_CodificaStampe[enum_CodificaStampe["Impegnativa_Orticole_Gest_Breve"] = 131] = "Impegnativa_Orticole_Gest_Breve";
    enum_CodificaStampe[enum_CodificaStampe["Impegnativa_Orticole_Industria"] = 132] = "Impegnativa_Orticole_Industria";
    enum_CodificaStampe[enum_CodificaStampe["Impegnativa_Pomodoro_Industria"] = 133] = "Impegnativa_Pomodoro_Industria";
    enum_CodificaStampe[enum_CodificaStampe["Impegnativa_Fagiolino_Mercato_Fresco"] = 134] = "Impegnativa_Fagiolino_Mercato_Fresco";
    enum_CodificaStampe[enum_CodificaStampe["ImportaContatti_XLS2GIAS"] = 135] = "ImportaContatti_XLS2GIAS";
    enum_CodificaStampe[enum_CodificaStampe["Certificato_Pomodoro"] = 136] = "Certificato_Pomodoro";
    enum_CodificaStampe[enum_CodificaStampe["Certificato_Pomodoro_Interno"] = 137] = "Certificato_Pomodoro_Interno";
    enum_CodificaStampe[enum_CodificaStampe["Certificato_Pomodoro_Esterno"] = 138] = "Certificato_Pomodoro_Esterno";
    enum_CodificaStampe[enum_CodificaStampe["Registro_CaricoScarico_Pomodoro"] = 139] = "Registro_CaricoScarico_Pomodoro";
    enum_CodificaStampe[enum_CodificaStampe["Esporta_ConferimentiPomodoro_Agrea"] = 140] = "Esporta_ConferimentiPomodoro_Agrea";
    enum_CodificaStampe[enum_CodificaStampe["Esporta_BolleAccettazione2AltroClienteGias"] = 141] = "Esporta_BolleAccettazione2AltroClienteGias";
    enum_CodificaStampe[enum_CodificaStampe["ExportExcel_MonitoraggioCE"] = 142] = "ExportExcel_MonitoraggioCE";
    enum_CodificaStampe[enum_CodificaStampe["ADD_ExportExcel_CertificatiPomodoro"] = 143] = "ADD_ExportExcel_CertificatiPomodoro";
    enum_CodificaStampe[enum_CodificaStampe["SchedaCampagna_Ricette"] = 144] = "SchedaCampagna_Ricette";
    enum_CodificaStampe[enum_CodificaStampe["GestioneRicette_Edit"] = 145] = "GestioneRicette_Edit";
    enum_CodificaStampe[enum_CodificaStampe["ExportExcel_MonitoraggioCE_Aggregata"] = 146] = "ExportExcel_MonitoraggioCE_Aggregata";
    enum_CodificaStampe[enum_CodificaStampe["GestioneEtichette_Trasformati"] = 147] = "GestioneEtichette_Trasformati";
    enum_CodificaStampe[enum_CodificaStampe["LibroConferimenti_XLS"] = 148] = "LibroConferimenti_XLS";
    enum_CodificaStampe[enum_CodificaStampe["RegistroTrattamenti_Veneto"] = 149] = "RegistroTrattamenti_Veneto";
    enum_CodificaStampe[enum_CodificaStampe["SchedaCampagnaMultiCentro"] = 150] = "SchedaCampagnaMultiCentro";
    enum_CodificaStampe[enum_CodificaStampe["RiepilogoImpiegoSuperfici_Multiazienda"] = 151] = "RiepilogoImpiegoSuperfici_Multiazienda";
    enum_CodificaStampe[enum_CodificaStampe["Eurep_Gap_Multicentro"] = 152] = "Eurep_Gap_Multicentro";
    enum_CodificaStampe[enum_CodificaStampe["SchedaPreparati_Biologico"] = 153] = "SchedaPreparati_Biologico";
    enum_CodificaStampe[enum_CodificaStampe["Notifica_Biologico"] = 154] = "Notifica_Biologico";
    enum_CodificaStampe[enum_CodificaStampe["RiBa_Report_Presentazione"] = 155] = "RiBa_Report_Presentazione";
    enum_CodificaStampe[enum_CodificaStampe["RiBa_Export_CBI"] = 156] = "RiBa_Export_CBI";
    enum_CodificaStampe[enum_CodificaStampe["Listini_XLS"] = 157] = "Listini_XLS";
    enum_CodificaStampe[enum_CodificaStampe["DDT_Contabilizzato_Emesso"] = 158] = "DDT_Contabilizzato_Emesso";
    enum_CodificaStampe[enum_CodificaStampe["Ordine"] = 159] = "Ordine";
    enum_CodificaStampe[enum_CodificaStampe["AgentiProvvigioni_XLS"] = 160] = "AgentiProvvigioni_XLS";
    enum_CodificaStampe[enum_CodificaStampe["Eurep_Gap_Multicentro_Immediata"] = 161] = "Eurep_Gap_Multicentro_Immediata";
    enum_CodificaStampe[enum_CodificaStampe["Report_Incongruenze_CatastoVSAgrea"] = 162] = "Report_Incongruenze_CatastoVSAgrea";
    enum_CodificaStampe[enum_CodificaStampe["Preventivo_Vendita"] = 163] = "Preventivo_Vendita";
    enum_CodificaStampe[enum_CodificaStampe["Scheda_Rilievi"] = 164] = "Scheda_Rilievi";
    enum_CodificaStampe[enum_CodificaStampe["PianoColturaleCatasto"] = 166] = "PianoColturaleCatasto";
    enum_CodificaStampe[enum_CodificaStampe["GiornaleContabile"] = 167] = "GiornaleContabile";
    enum_CodificaStampe[enum_CodificaStampe["Ordine_Acquisto"] = 168] = "Ordine_Acquisto";
    enum_CodificaStampe[enum_CodificaStampe["FF_Etichette"] = 169] = "FF_Etichette";
    enum_CodificaStampe[enum_CodificaStampe["Liquidazione_Soci"] = 170] = "Liquidazione_Soci";
    enum_CodificaStampe[enum_CodificaStampe["Allegato_CatastoeValorizzazioni"] = 171] = "Allegato_CatastoeValorizzazioni";
    enum_CodificaStampe[enum_CodificaStampe["Esportazione_OP_Produttori"] = 172] = "Esportazione_OP_Produttori";
    enum_CodificaStampe[enum_CodificaStampe["Esportazione_OP_Catasto"] = 173] = "Esportazione_OP_Catasto";
    enum_CodificaStampe[enum_CodificaStampe["ADD_ExcelTracciabilitaConferimenti"] = 174] = "ADD_ExcelTracciabilitaConferimenti";
    enum_CodificaStampe[enum_CodificaStampe["FreshFood_BollaAccettazione"] = 175] = "FreshFood_BollaAccettazione";
    enum_CodificaStampe[enum_CodificaStampe["FreshFood_DistintaCarico_Accettazione"] = 176] = "FreshFood_DistintaCarico_Accettazione";
    enum_CodificaStampe[enum_CodificaStampe["FreshFood_AutoDDT_Accettazione"] = 177] = "FreshFood_AutoDDT_Accettazione";
    enum_CodificaStampe[enum_CodificaStampe["SchedaMagazzinoMovimentiExcel"] = 178] = "SchedaMagazzinoMovimentiExcel";
    // ' OLD Buono_Accettazione_Diversi_DDTRicevuto = 165
    enum_CodificaStampe[enum_CodificaStampe["ConferimentoUva_DDTRicevuto"] = 165] = "ConferimentoUva_DDTRicevuto";
    enum_CodificaStampe[enum_CodificaStampe["ConferimentoUva_DistintaCarico"] = 179] = "ConferimentoUva_DistintaCarico";
    enum_CodificaStampe[enum_CodificaStampe["ConferimentoUva_AutoDDT"] = 180] = "ConferimentoUva_AutoDDT";
    enum_CodificaStampe[enum_CodificaStampe["Registro_Fertilizzazioni_Massivo"] = 181] = "Registro_Fertilizzazioni_Massivo";
    enum_CodificaStampe[enum_CodificaStampe["Registro_Trattamenti_Massivo"] = 182] = "Registro_Trattamenti_Massivo";
    enum_CodificaStampe[enum_CodificaStampe["Conf_FiltroStampe"] = 183] = "Conf_FiltroStampe";
    enum_CodificaStampe[enum_CodificaStampe["Conf_EC_Imballi"] = 184] = "Conf_EC_Imballi";
    enum_CodificaStampe[enum_CodificaStampe["Conf_Saldo_Imballi"] = 185] = "Conf_Saldo_Imballi";
    enum_CodificaStampe[enum_CodificaStampe["Conf_Riepilogo_Conferimenti"] = 186] = "Conf_Riepilogo_Conferimenti";
    enum_CodificaStampe[enum_CodificaStampe["Conf_Tracciabilita"] = 187] = "Conf_Tracciabilita";
    enum_CodificaStampe[enum_CodificaStampe["Bilancio_SezioniContrapposte"] = 188] = "Bilancio_SezioniContrapposte";
    enum_CodificaStampe[enum_CodificaStampe["EstrattoConto_Contatti"] = 189] = "EstrattoConto_Contatti";
    enum_CodificaStampe[enum_CodificaStampe["Cespiti_FiltroStampe"] = 190] = "Cespiti_FiltroStampe";
    enum_CodificaStampe[enum_CodificaStampe["SchedaCampagna_ProvAut_Trento"] = 191] = "SchedaCampagna_ProvAut_Trento";
    enum_CodificaStampe[enum_CodificaStampe["SchedaCampagna_Multi_Lombardia"] = 192] = "SchedaCampagna_Multi_Lombardia";
    enum_CodificaStampe[enum_CodificaStampe["FreshFood_BollaCampionatura"] = 193] = "FreshFood_BollaCampionatura";
    enum_CodificaStampe[enum_CodificaStampe["RisultatoAnalisiConformita"] = 194] = "RisultatoAnalisiConformita";
    enum_CodificaStampe[enum_CodificaStampe["FreshFood_FatturaLiquidazioneSoci"] = 195] = "FreshFood_FatturaLiquidazioneSoci";
    enum_CodificaStampe[enum_CodificaStampe["FreshFood_PagatiSuConferito"] = 196] = "FreshFood_PagatiSuConferito";
    enum_CodificaStampe[enum_CodificaStampe["FreshFood_AutofatturaLiquidazioneSoci"] = 197] = "FreshFood_AutofatturaLiquidazioneSoci";
    enum_CodificaStampe[enum_CodificaStampe["FreshFood_RiepilogoLiquidazioneSoci"] = 198] = "FreshFood_RiepilogoLiquidazioneSoci";
    enum_CodificaStampe[enum_CodificaStampe["FreshFood_PagatiSuCampionato"] = 199] = "FreshFood_PagatiSuCampionato";
    enum_CodificaStampe[enum_CodificaStampe["Analisi_Progetti"] = 200] = "Analisi_Progetti";
    enum_CodificaStampe[enum_CodificaStampe["SchedaInterventiAgronomici"] = 201] = "SchedaInterventiAgronomici";
    enum_CodificaStampe[enum_CodificaStampe["EsportazioneAgeaTxtCSV"] = 202] = "EsportazioneAgeaTxtCSV";
    enum_CodificaStampe[enum_CodificaStampe["RegistroAziendaleUnico"] = 203] = "RegistroAziendaleUnico";
    enum_CodificaStampe[enum_CodificaStampe["SchedaCatastoeUtilizzi"] = 204] = "SchedaCatastoeUtilizzi";
    enum_CodificaStampe[enum_CodificaStampe["RegistroTrattamentiVeneto_StdCondizionalita"] = 205] = "RegistroTrattamentiVeneto_StdCondizionalita";
    enum_CodificaStampe[enum_CodificaStampe["RiepiloghiAccise"] = 206] = "RiepiloghiAccise";
    enum_CodificaStampe[enum_CodificaStampe["DAA_GaranzieCircolanti"] = 207] = "DAA_GaranzieCircolanti";
    enum_CodificaStampe[enum_CodificaStampe["DAA_PariteSospensione"] = 208] = "DAA_PariteSospensione";
    enum_CodificaStampe[enum_CodificaStampe["MVV"] = 209] = "MVV";
    enum_CodificaStampe[enum_CodificaStampe["Report_Vendita_PDF"] = 210] = "Report_Vendita_PDF";
    enum_CodificaStampe[enum_CodificaStampe["ReportRisultatoFiltroneG2G"] = 211] = "ReportRisultatoFiltroneG2G";
    enum_CodificaStampe[enum_CodificaStampe["EsportazionePomodoroIndustriaOINordItalia"] = 212] = "EsportazionePomodoroIndustriaOINordItalia";
    enum_CodificaStampe[enum_CodificaStampe["RiepilogoProdottiUtilizzati"] = 213] = "RiepilogoProdottiUtilizzati";
    enum_CodificaStampe[enum_CodificaStampe["PassaportoMaterialeVivaistico"] = 214] = "PassaportoMaterialeVivaistico";
    enum_CodificaStampe[enum_CodificaStampe["ReportRisultatoFiltroneIncludiVisita"] = 215] = "ReportRisultatoFiltroneIncludiVisita";
    enum_CodificaStampe[enum_CodificaStampe["Bilancio_Fertilizzazioni_Dettagliato"] = 216] = "Bilancio_Fertilizzazioni_Dettagliato";
    enum_CodificaStampe[enum_CodificaStampe["Conf_Esportazione_BolleFF_XLS"] = 217] = "Conf_Esportazione_BolleFF_XLS";
    enum_CodificaStampe[enum_CodificaStampe["Filtro_StampeBiologico"] = 218] = "Filtro_StampeBiologico";
    enum_CodificaStampe[enum_CodificaStampe["Conf_EsportazionexTrasportatori_XLS"] = 219] = "Conf_EsportazionexTrasportatori_XLS";
    enum_CodificaStampe[enum_CodificaStampe["Conf_RiepilogoxArticolo"] = 220] = "Conf_RiepilogoxArticolo";
    enum_CodificaStampe[enum_CodificaStampe["Conf_EC_Bolle"] = 221] = "Conf_EC_Bolle";
    enum_CodificaStampe[enum_CodificaStampe["Conf_Certificato_Pomodoro"] = 222] = "Conf_Certificato_Pomodoro";
    enum_CodificaStampe[enum_CodificaStampe["Conf_Esportazione_CertificatiPomodoro_XLS"] = 223] = "Conf_Esportazione_CertificatiPomodoro_XLS";
    enum_CodificaStampe[enum_CodificaStampe["UMA_RichiestaCarbPrevisioneLav"] = 224] = "UMA_RichiestaCarbPrevisioneLav";
    enum_CodificaStampe[enum_CodificaStampe["UMA_VerbaleIstruttoriaRichCarb"] = 225] = "UMA_VerbaleIstruttoriaRichCarb";
    enum_CodificaStampe[enum_CodificaStampe["UMA_RendicontazioneCarb"] = 226] = "UMA_RendicontazioneCarb";
    enum_CodificaStampe[enum_CodificaStampe["UMA_IstruttoriaRendCarb"] = 227] = "UMA_IstruttoriaRendCarb";
    enum_CodificaStampe[enum_CodificaStampe["EstrazioneCatastoAffitti"] = 228] = "EstrazioneCatastoAffitti";
    enum_CodificaStampe[enum_CodificaStampe["Conf_ComunicazioneCredito"] = 229] = "Conf_ComunicazioneCredito";
    enum_CodificaStampe[enum_CodificaStampe["CredenzialiPrivacy"] = 230] = "CredenzialiPrivacy";
    enum_CodificaStampe[enum_CodificaStampe["Report_OrdiniVivaio"] = 231] = "Report_OrdiniVivaio";
    enum_CodificaStampe[enum_CodificaStampe["Report_PianoColturalePreventivoVivaio"] = 232] = "Report_PianoColturalePreventivoVivaio";
    enum_CodificaStampe[enum_CodificaStampe["Impegnative_capitolati"] = 233] = "Impegnative_capitolati";
    enum_CodificaStampe[enum_CodificaStampe["Adesione_ModuloGrasp"] = 234] = "Adesione_ModuloGrasp";
    enum_CodificaStampe[enum_CodificaStampe["Adesione_ProtocolloGlobalGAP"] = 235] = "Adesione_ProtocolloGlobalGAP";
    enum_CodificaStampe[enum_CodificaStampe["Adesione_NurtureModule"] = 236] = "Adesione_NurtureModule";
    enum_CodificaStampe[enum_CodificaStampe["Adesione_Despar"] = 237] = "Adesione_Despar";
    enum_CodificaStampe[enum_CodificaStampe["Adesione_Conad"] = 238] = "Adesione_Conad";
    enum_CodificaStampe[enum_CodificaStampe["Accordo_Responsabilita_di_Filiera"] = 239] = "Accordo_Responsabilita_di_Filiera";
    enum_CodificaStampe[enum_CodificaStampe["Dichiarazione_di_Responsabilita"] = 240] = "Dichiarazione_di_Responsabilita";
    enum_CodificaStampe[enum_CodificaStampe["Fitoregolatori_Kiwi"] = 241] = "Fitoregolatori_Kiwi";
    enum_CodificaStampe[enum_CodificaStampe["Adesione_StandardLeaf"] = 242] = "Adesione_StandardLeaf";
    enum_CodificaStampe[enum_CodificaStampe["SchedaAziendale"] = 243] = "SchedaAziendale";
    enum_CodificaStampe[enum_CodificaStampe["ImpegnoProduzioneSociDivisoxCentri"] = 244] = "ImpegnoProduzioneSociDivisoxCentri";
    enum_CodificaStampe[enum_CodificaStampe["ObiettivoDiProduzioneAsipo"] = 245] = "ObiettivoDiProduzioneAsipo";
    enum_CodificaStampe[enum_CodificaStampe["ImpegnativaColtivazioneConferimento"] = 246] = "ImpegnativaColtivazioneConferimento";
    enum_CodificaStampe[enum_CodificaStampe["QuestionarioValutazioneAzienda_Aggiornamento"] = 247] = "QuestionarioValutazioneAzienda_Aggiornamento";
    enum_CodificaStampe[enum_CodificaStampe["PianoColturaleCatastoGrid"] = 248] = "PianoColturaleCatastoGrid";
    enum_CodificaStampe[enum_CodificaStampe["Statistometro"] = 249] = "Statistometro";
    enum_CodificaStampe[enum_CodificaStampe["GiasAPP_ConsultaSincroDatiAppDaWeb"] = 822] = "GiasAPP_ConsultaSincroDatiAppDaWeb";
})(enum_CodificaStampe || (enum_CodificaStampe = {}));
var enum_TipoFiltrone;
(function (enum_TipoFiltrone) {
    /** Permette l'accesso al filtrone se l'utente possiede il permesso Gest_Stampe in modalità lettura. */
    enum_TipoFiltrone[enum_TipoFiltrone["Stampa"] = 1] = "Stampa";
    enum_TipoFiltrone[enum_TipoFiltrone["Utenti"] = 2] = "Utenti";
    enum_TipoFiltrone[enum_TipoFiltrone["Agenda"] = 3] = "Agenda";
    enum_TipoFiltrone[enum_TipoFiltrone["AnalisiCosti"] = 4] = "AnalisiCosti";
    enum_TipoFiltrone[enum_TipoFiltrone["ModificaImpianti"] = 5] = "ModificaImpianti";
    enum_TipoFiltrone[enum_TipoFiltrone["PianificazioneInterventi"] = 6] = "PianificazioneInterventi";
    enum_TipoFiltrone[enum_TipoFiltrone["EliminaInterventi"] = 7] = "EliminaInterventi";
    enum_TipoFiltrone[enum_TipoFiltrone["Esportazione_OP_Inv"] = 8] = "Esportazione_OP_Inv";
    enum_TipoFiltrone[enum_TipoFiltrone["Esportazione_OP_Gest"] = 17] = "Esportazione_OP_Gest";
    enum_TipoFiltrone[enum_TipoFiltrone["Esportatore_Universale_Impianti"] = 9] = "Esportatore_Universale_Impianti";
    enum_TipoFiltrone[enum_TipoFiltrone["Esportatore_Universale_Imprese"] = 10] = "Esportatore_Universale_Imprese";
    enum_TipoFiltrone[enum_TipoFiltrone["Esportatore_Universale_Centri"] = 11] = "Esportatore_Universale_Centri";
    enum_TipoFiltrone[enum_TipoFiltrone["Esportatore_Universale_Appezza"] = 12] = "Esportatore_Universale_Appezza";
    enum_TipoFiltrone[enum_TipoFiltrone["Esportatore_Universale_Agenda"] = 13] = "Esportatore_Universale_Agenda";
    enum_TipoFiltrone[enum_TipoFiltrone["Esportatore_Universale_Rintraccio"] = 16] = "Esportatore_Universale_Rintraccio";
    enum_TipoFiltrone[enum_TipoFiltrone["Blocco_OperazioniAgenda"] = 14] = "Blocco_OperazioniAgenda";
    enum_TipoFiltrone[enum_TipoFiltrone["Richiesta_Verifica_Conformita"] = 15] = "Richiesta_Verifica_Conformita";
    enum_TipoFiltrone[enum_TipoFiltrone["Associa_Ricetta_Impianti"] = 18] = "Associa_Ricetta_Impianti";
    enum_TipoFiltrone[enum_TipoFiltrone["Esportazione_CellulariTecnici"] = 19] = "Esportazione_CellulariTecnici";
    enum_TipoFiltrone[enum_TipoFiltrone["Esportazione_OP_Gest_Coop"] = 20] = "Esportazione_OP_Gest_Coop";
    enum_TipoFiltrone[enum_TipoFiltrone["Bilancio_Fertilizzazioni"] = 21] = "Bilancio_Fertilizzazioni";
    enum_TipoFiltrone[enum_TipoFiltrone["MultiModificaImpianti"] = 22] = "MultiModificaImpianti";
    enum_TipoFiltrone[enum_TipoFiltrone["Esportatore_Contatti"] = 23] = "Esportatore_Contatti";
    enum_TipoFiltrone[enum_TipoFiltrone["Associa_Ricetta_Interventi"] = 24] = "Associa_Ricetta_Interventi";
    enum_TipoFiltrone[enum_TipoFiltrone["MultiModificaAgenda"] = 25] = "MultiModificaAgenda";
    enum_TipoFiltrone[enum_TipoFiltrone["FiltroStrube"] = 26] = "FiltroStrube";
    enum_TipoFiltrone[enum_TipoFiltrone["PianiCampionamento_AggiungiImpianti"] = 27] = "PianiCampionamento_AggiungiImpianti";
    enum_TipoFiltrone[enum_TipoFiltrone["CancellaAppezzamenti"] = 28] = "CancellaAppezzamenti";
    enum_TipoFiltrone[enum_TipoFiltrone["Gestione_Servizi"] = 29] = "Gestione_Servizi";
    enum_TipoFiltrone[enum_TipoFiltrone["PianoConcimazione"] = 30] = "PianoConcimazione";
    enum_TipoFiltrone[enum_TipoFiltrone["ExportSigpa"] = 31] = "ExportSigpa";
    enum_TipoFiltrone[enum_TipoFiltrone["ModificaAperturaCampi"] = 32] = "ModificaAperturaCampi";
    enum_TipoFiltrone[enum_TipoFiltrone["OperazioniMultiAziendali"] = 33] = "OperazioniMultiAziendali";
    enum_TipoFiltrone[enum_TipoFiltrone["Esportazione_AgeaTXTCSV"] = 34] = "Esportazione_AgeaTXTCSV";
    enum_TipoFiltrone[enum_TipoFiltrone["EsportazionePomodoroIndustriaOINordItalia"] = 35] = "EsportazionePomodoroIndustriaOINordItalia";
    enum_TipoFiltrone[enum_TipoFiltrone["StimeProduzione"] = 36] = "StimeProduzione";
    enum_TipoFiltrone[enum_TipoFiltrone["Modifica_Multipla_PianoColturale"] = 37] = "Modifica_Multipla_PianoColturale";
    enum_TipoFiltrone[enum_TipoFiltrone["DuplicaOperazione"] = 38] = "DuplicaOperazione";
})(enum_TipoFiltrone || (enum_TipoFiltrone = {}));
var enum_FiltroneParams;
(function (enum_FiltroneParams) {
    enum_FiltroneParams["Sito_Origine"] = "s_o";
    enum_FiltroneParams["Pagina_Origine"] = "p_o";
    enum_FiltroneParams["Pagina_Destinazione"] = "p_d";
    enum_FiltroneParams["Sito_Destinazione"] = "s_d";
    /** @usageNotes Da inserire tra i parametri una volta sola.
     * In caso contrario la pagina del FIltrone potrebbe parsare male il valore del parametro. */
    enum_FiltroneParams["Tipo_Filtrone"] = "t_f";
    enum_FiltroneParams["Codifica_Stampe"] = "c_s";
    /** Header/Footer (se diverso da "" vengono nascosti) */
    enum_FiltroneParams["Mostra_Header_Footer"] = "hdr_ftr";
    enum_FiltroneParams["Categoria"] = "cat";
    /** 1 = blocca, 0 = lascia editable (default) */
    enum_FiltroneParams["BloccaCategoria"] = "cat_blk";
    enum_FiltroneParams["Piva"] = "piva";
    enum_FiltroneParams["Includi_Visite"] = "IncludiVisite";
    enum_FiltroneParams["No_Piva"] = "nopiva";
    enum_FiltroneParams["Gias2Gias"] = "g2g";
    enum_FiltroneParams["Filtrino"] = "f";
    enum_FiltroneParams["Veg_Cod"] = "v_c";
    enum_FiltroneParams["Cul_Cod"] = "c_c";
    enum_FiltroneParams["Data_Inizio"] = "d_i";
    enum_FiltroneParams["Data_Fine"] = "d_f";
    enum_FiltroneParams["Dati_Di_Ritorno"] = "ddr";
    /** Forza il redirect al filtrone se diverso da "" (ignora i check sui permessi).
     * Attualmente usato solo in combinazione con `enum_TipoFiltrone.Esportatore_Universale_Imprese`
     * per permettere l'assegnazione della visibilità dalla profilazione nuova senza
     * aver bisogno del permesso `Stampe_Esportatore_Universale`. */
    enum_FiltroneParams["Forza_Redirect"] = "f_r";
})(enum_FiltroneParams || (enum_FiltroneParams = {}));
var enum_TipoOperatoreVisita;
(function (enum_TipoOperatoreVisita) {
    enum_TipoOperatoreVisita[enum_TipoOperatoreVisita["Capo"] = 0] = "Capo";
    enum_TipoOperatoreVisita[enum_TipoOperatoreVisita["Tecnico"] = 1] = "Tecnico";
    enum_TipoOperatoreVisita[enum_TipoOperatoreVisita["CapoTecnico"] = 2] = "CapoTecnico";
    enum_TipoOperatoreVisita[enum_TipoOperatoreVisita["Altro"] = -1] = "Altro";
})(enum_TipoOperatoreVisita || (enum_TipoOperatoreVisita = {}));
var enum_statiWorkflowQdC;
(function (enum_statiWorkflowQdC) {
    enum_statiWorkflowQdC[enum_statiWorkflowQdC["Non_Definito"] = 0] = "Non_Definito";
    enum_statiWorkflowQdC[enum_statiWorkflowQdC["Da_Eseguire"] = 400] = "Da_Eseguire";
    enum_statiWorkflowQdC[enum_statiWorkflowQdC["Eseguito"] = 401] = "Eseguito";
})(enum_statiWorkflowQdC || (enum_statiWorkflowQdC = {}));
var enum_Menu_Agenda_NG_Mode;
(function (enum_Menu_Agenda_NG_Mode) {
    enum_Menu_Agenda_NG_Mode["Standard"] = "";
    enum_Menu_Agenda_NG_Mode["PUA"] = "AggiungiAlPua";
})(enum_Menu_Agenda_NG_Mode || (enum_Menu_Agenda_NG_Mode = {}));
var enum_OrigineApp;
(function (enum_OrigineApp) {
    enum_OrigineApp["GiasApp"] = "APP";
    enum_OrigineApp["Demetra"] = "DEMETRA";
})(enum_OrigineApp || (enum_OrigineApp = {}));
/** Usata sia per i valori di `UTENTE_COD_RACCOLTA_TIPO_NUOVO_IMPIANTO`
 * che per quelli di `Utente_OpzioneChiusuraAbbattimenti`
 */
var enum_Valori_UTENTE_COD_RACCOLTA_TIPO_NUOVO_IMPIANTO;
(function (enum_Valori_UTENTE_COD_RACCOLTA_TIPO_NUOVO_IMPIANTO) {
    enum_Valori_UTENTE_COD_RACCOLTA_TIPO_NUOVO_IMPIANTO[enum_Valori_UTENTE_COD_RACCOLTA_TIPO_NUOVO_IMPIANTO["OLD_NON_APRIRE_NUOVI_ESERCIZI_NUOVI_IMPIANTI"] = 0] = "OLD_NON_APRIRE_NUOVI_ESERCIZI_NUOVI_IMPIANTI";
    enum_Valori_UTENTE_COD_RACCOLTA_TIPO_NUOVO_IMPIANTO[enum_Valori_UTENTE_COD_RACCOLTA_TIPO_NUOVO_IMPIANTO["OLD_APRI_NUOVI_ESERCIZI_NUOVI_IMPIANTI"] = 1] = "OLD_APRI_NUOVI_ESERCIZI_NUOVI_IMPIANTI";
    enum_Valori_UTENTE_COD_RACCOLTA_TIPO_NUOVO_IMPIANTO[enum_Valori_UTENTE_COD_RACCOLTA_TIPO_NUOVO_IMPIANTO["LASCIARE_IMPIANTI_ATTIVI_DEFAULT"] = 10] = "LASCIARE_IMPIANTI_ATTIVI_DEFAULT";
    enum_Valori_UTENTE_COD_RACCOLTA_TIPO_NUOVO_IMPIANTO[enum_Valori_UTENTE_COD_RACCOLTA_TIPO_NUOVO_IMPIANTO["CHIUDI_ESERCIZI_DEFAULT"] = 20] = "CHIUDI_ESERCIZI_DEFAULT";
    enum_Valori_UTENTE_COD_RACCOLTA_TIPO_NUOVO_IMPIANTO[enum_Valori_UTENTE_COD_RACCOLTA_TIPO_NUOVO_IMPIANTO["CHIUDI_APRI_ESERCIZI_DEFAULT"] = 30] = "CHIUDI_APRI_ESERCIZI_DEFAULT";
    enum_Valori_UTENTE_COD_RACCOLTA_TIPO_NUOVO_IMPIANTO[enum_Valori_UTENTE_COD_RACCOLTA_TIPO_NUOVO_IMPIANTO["CHIUDI_IMPIANTI_ESERCIZI_DEFAULT"] = 40] = "CHIUDI_IMPIANTI_ESERCIZI_DEFAULT";
    enum_Valori_UTENTE_COD_RACCOLTA_TIPO_NUOVO_IMPIANTO[enum_Valori_UTENTE_COD_RACCOLTA_TIPO_NUOVO_IMPIANTO["CHIUDI_APRI_IMPIANTI_ESERCIZI_DEFAULT"] = 50] = "CHIUDI_APRI_IMPIANTI_ESERCIZI_DEFAULT";
    enum_Valori_UTENTE_COD_RACCOLTA_TIPO_NUOVO_IMPIANTO[enum_Valori_UTENTE_COD_RACCOLTA_TIPO_NUOVO_IMPIANTO["CHIUDI_APPEZZAMENTI_IMPIANTI_ESERCIZI_DEFAULT"] = 60] = "CHIUDI_APPEZZAMENTI_IMPIANTI_ESERCIZI_DEFAULT";
    enum_Valori_UTENTE_COD_RACCOLTA_TIPO_NUOVO_IMPIANTO[enum_Valori_UTENTE_COD_RACCOLTA_TIPO_NUOVO_IMPIANTO["LASCIARE_IMPIANTI_ATTIVI_VINCOLO"] = 70] = "LASCIARE_IMPIANTI_ATTIVI_VINCOLO";
    enum_Valori_UTENTE_COD_RACCOLTA_TIPO_NUOVO_IMPIANTO[enum_Valori_UTENTE_COD_RACCOLTA_TIPO_NUOVO_IMPIANTO["CHIUDI_ESERCIZI_VINCOLO"] = 80] = "CHIUDI_ESERCIZI_VINCOLO";
    enum_Valori_UTENTE_COD_RACCOLTA_TIPO_NUOVO_IMPIANTO[enum_Valori_UTENTE_COD_RACCOLTA_TIPO_NUOVO_IMPIANTO["CHIUDI_APRI_ESERCIZI_VINCOLO"] = 90] = "CHIUDI_APRI_ESERCIZI_VINCOLO";
    enum_Valori_UTENTE_COD_RACCOLTA_TIPO_NUOVO_IMPIANTO[enum_Valori_UTENTE_COD_RACCOLTA_TIPO_NUOVO_IMPIANTO["CHIUDI_IMPIANTI_ESERCIZI_VINCOLO"] = 100] = "CHIUDI_IMPIANTI_ESERCIZI_VINCOLO";
    enum_Valori_UTENTE_COD_RACCOLTA_TIPO_NUOVO_IMPIANTO[enum_Valori_UTENTE_COD_RACCOLTA_TIPO_NUOVO_IMPIANTO["CHIUDI_APRI_IMPIANTI_ESERCIZI_VINCOLO"] = 110] = "CHIUDI_APRI_IMPIANTI_ESERCIZI_VINCOLO";
    enum_Valori_UTENTE_COD_RACCOLTA_TIPO_NUOVO_IMPIANTO[enum_Valori_UTENTE_COD_RACCOLTA_TIPO_NUOVO_IMPIANTO["CHIUDI_APPEZZAMENTI_IMPIANTI_ESERCIZI_VINCOLO"] = 120] = "CHIUDI_APPEZZAMENTI_IMPIANTI_ESERCIZI_VINCOLO";
})(enum_Valori_UTENTE_COD_RACCOLTA_TIPO_NUOVO_IMPIANTO || (enum_Valori_UTENTE_COD_RACCOLTA_TIPO_NUOVO_IMPIANTO = {}));
/**
 * Le imprese con tipo Cooperativa, Consorzio o OrganizzazioneProduttore
 * possono essere scelte come padri per altre imprese.
 */
var enum_TipoImpresaGerarchia;
(function (enum_TipoImpresaGerarchia) {
    enum_TipoImpresaGerarchia[enum_TipoImpresaGerarchia["Impresa"] = 1] = "Impresa";
    enum_TipoImpresaGerarchia[enum_TipoImpresaGerarchia["Cooperativa"] = 2] = "Cooperativa";
    enum_TipoImpresaGerarchia[enum_TipoImpresaGerarchia["Consorzio"] = 3] = "Consorzio";
    enum_TipoImpresaGerarchia[enum_TipoImpresaGerarchia["OrganizzazioneProduttore"] = 4] = "OrganizzazioneProduttore";
})(enum_TipoImpresaGerarchia || (enum_TipoImpresaGerarchia = {}));
var enum_Esportazioni_Sistema_Cod;
(function (enum_Esportazioni_Sistema_Cod) {
    enum_Esportazioni_Sistema_Cod[enum_Esportazioni_Sistema_Cod["Enogis"] = 1] = "Enogis";
    enum_Esportazioni_Sistema_Cod[enum_Esportazioni_Sistema_Cod["Artea"] = 2] = "Artea";
    enum_Esportazioni_Sistema_Cod[enum_Esportazioni_Sistema_Cod["BDN"] = 3] = "BDN";
    enum_Esportazioni_Sistema_Cod[enum_Esportazioni_Sistema_Cod["XFarm"] = 4] = "XFarm";
    enum_Esportazioni_Sistema_Cod[enum_Esportazioni_Sistema_Cod["OnPlantImport"] = 5] = "OnPlantImport";
    enum_Esportazioni_Sistema_Cod[enum_Esportazioni_Sistema_Cod["OnPlantExport"] = 6] = "OnPlantExport";
    enum_Esportazioni_Sistema_Cod[enum_Esportazioni_Sistema_Cod["HubIoT"] = 7] = "HubIoT";
    enum_Esportazioni_Sistema_Cod[enum_Esportazioni_Sistema_Cod["Nogmo"] = 8] = "Nogmo";
    enum_Esportazioni_Sistema_Cod[enum_Esportazioni_Sistema_Cod["Fex"] = 9] = "Fex";
    enum_Esportazioni_Sistema_Cod[enum_Esportazioni_Sistema_Cod["AsipoImport"] = 10] = "AsipoImport";
    enum_Esportazioni_Sistema_Cod[enum_Esportazioni_Sistema_Cod["AsipoOrdiniMVExport"] = 11] = "AsipoOrdiniMVExport";
    enum_Esportazioni_Sistema_Cod[enum_Esportazioni_Sistema_Cod["AsipoOrdiniMVGetStato"] = 12] = "AsipoOrdiniMVGetStato";
    enum_Esportazioni_Sistema_Cod[enum_Esportazioni_Sistema_Cod["Recap_Ricette_CAI"] = 20] = "Recap_Ricette_CAI";
    enum_Esportazioni_Sistema_Cod[enum_Esportazioni_Sistema_Cod["OrogelBI"] = 21] = "OrogelBI";
    enum_Esportazioni_Sistema_Cod[enum_Esportazioni_Sistema_Cod["Demetra_Import_Analisi"] = 22] = "Demetra_Import_Analisi";
    enum_Esportazioni_Sistema_Cod[enum_Esportazioni_Sistema_Cod["Demetra_Export_Analisi"] = 23] = "Demetra_Export_Analisi";
    enum_Esportazioni_Sistema_Cod[enum_Esportazioni_Sistema_Cod["Demetra_Import_Attivita"] = 24] = "Demetra_Import_Attivita";
    enum_Esportazioni_Sistema_Cod[enum_Esportazioni_Sistema_Cod["Demetra_Export_Attivita"] = 25] = "Demetra_Export_Attivita";
    enum_Esportazioni_Sistema_Cod[enum_Esportazioni_Sistema_Cod["Demetra_Import_Fabbricati"] = 26] = "Demetra_Import_Fabbricati";
    enum_Esportazioni_Sistema_Cod[enum_Esportazioni_Sistema_Cod["Demetra_Export_Fabbricati"] = 27] = "Demetra_Export_Fabbricati";
    enum_Esportazioni_Sistema_Cod[enum_Esportazioni_Sistema_Cod["Demetra_Import_LavoratoriQDC"] = 28] = "Demetra_Import_LavoratoriQDC";
    enum_Esportazioni_Sistema_Cod[enum_Esportazioni_Sistema_Cod["Demetra_Export_LavoratoriQDC"] = 29] = "Demetra_Export_LavoratoriQDC";
    enum_Esportazioni_Sistema_Cod[enum_Esportazioni_Sistema_Cod["Demetra_Import_Fornitori"] = 30] = "Demetra_Import_Fornitori";
    enum_Esportazioni_Sistema_Cod[enum_Esportazioni_Sistema_Cod["Demetra_Export_Fornitori"] = 31] = "Demetra_Export_Fornitori";
    enum_Esportazioni_Sistema_Cod[enum_Esportazioni_Sistema_Cod["Demetra_Import_Macchine"] = 32] = "Demetra_Import_Macchine";
    enum_Esportazioni_Sistema_Cod[enum_Esportazioni_Sistema_Cod["Demetra_Export_Macchine"] = 33] = "Demetra_Export_Macchine";
    enum_Esportazioni_Sistema_Cod[enum_Esportazioni_Sistema_Cod["Demetra_Import_MovimentiMag"] = 34] = "Demetra_Import_MovimentiMag";
    enum_Esportazioni_Sistema_Cod[enum_Esportazioni_Sistema_Cod["Demetra_Export_MovimentiMag"] = 35] = "Demetra_Export_MovimentiMag";
    enum_Esportazioni_Sistema_Cod[enum_Esportazioni_Sistema_Cod["Demetra_Import_DataPublish"] = 36] = "Demetra_Import_DataPublish";
    enum_Esportazioni_Sistema_Cod[enum_Esportazioni_Sistema_Cod["Demetra_Export_DataPublish"] = 37] = "Demetra_Export_DataPublish";
})(enum_Esportazioni_Sistema_Cod || (enum_Esportazioni_Sistema_Cod = {}));
var enum_TipoConfrontoCatasto;
(function (enum_TipoConfrontoCatasto) {
    enum_TipoConfrontoCatasto[enum_TipoConfrontoCatasto["Planning_PianoColturale"] = 0] = "Planning_PianoColturale";
    enum_TipoConfrontoCatasto[enum_TipoConfrontoCatasto["PianoColturale_Planning"] = 1] = "PianoColturale_Planning";
})(enum_TipoConfrontoCatasto || (enum_TipoConfrontoCatasto = {}));
var enum_TipoSelect_FiltroneSuperNova;
(function (enum_TipoSelect_FiltroneSuperNova) {
    enum_TipoSelect_FiltroneSuperNova[enum_TipoSelect_FiltroneSuperNova["Base"] = 0] = "Base";
    enum_TipoSelect_FiltroneSuperNova[enum_TipoSelect_FiltroneSuperNova["ImpreseAlbero"] = 1] = "ImpreseAlbero";
    enum_TipoSelect_FiltroneSuperNova[enum_TipoSelect_FiltroneSuperNova["Imprese"] = 2] = "Imprese";
    enum_TipoSelect_FiltroneSuperNova[enum_TipoSelect_FiltroneSuperNova["Imprese_Visibilita_Appoggio"] = 13] = "Imprese_Visibilita_Appoggio";
    enum_TipoSelect_FiltroneSuperNova[enum_TipoSelect_FiltroneSuperNova["CentriAziendali"] = 3] = "CentriAziendali";
    enum_TipoSelect_FiltroneSuperNova[enum_TipoSelect_FiltroneSuperNova["CentriAziendali_Visibilita_Appoggio"] = 14] = "CentriAziendali_Visibilita_Appoggio";
    enum_TipoSelect_FiltroneSuperNova[enum_TipoSelect_FiltroneSuperNova["Appezzamenti"] = 4] = "Appezzamenti";
    enum_TipoSelect_FiltroneSuperNova[enum_TipoSelect_FiltroneSuperNova["Impianti"] = 5] = "Impianti";
    enum_TipoSelect_FiltroneSuperNova[enum_TipoSelect_FiltroneSuperNova["Movimenti"] = 6] = "Movimenti";
    enum_TipoSelect_FiltroneSuperNova[enum_TipoSelect_FiltroneSuperNova["Contatti"] = 7] = "Contatti";
    enum_TipoSelect_FiltroneSuperNova[enum_TipoSelect_FiltroneSuperNova["Campi"] = 8] = "Campi";
    enum_TipoSelect_FiltroneSuperNova[enum_TipoSelect_FiltroneSuperNova["Imprese_Codici"] = 9] = "Imprese_Codici";
    enum_TipoSelect_FiltroneSuperNova[enum_TipoSelect_FiltroneSuperNova["Esercizi"] = 10] = "Esercizi";
    enum_TipoSelect_FiltroneSuperNova[enum_TipoSelect_FiltroneSuperNova["AppezzamentiRipartoCatasto"] = 11] = "AppezzamentiRipartoCatasto";
    enum_TipoSelect_FiltroneSuperNova[enum_TipoSelect_FiltroneSuperNova["Fabbricati"] = 12] = "Fabbricati";
    enum_TipoSelect_FiltroneSuperNova[enum_TipoSelect_FiltroneSuperNova["Imprese_APP"] = 15] = "Imprese_APP";
    enum_TipoSelect_FiltroneSuperNova[enum_TipoSelect_FiltroneSuperNova["PianoColturale"] = 16] = "PianoColturale";
    enum_TipoSelect_FiltroneSuperNova[enum_TipoSelect_FiltroneSuperNova["PianoColturaleBudget"] = 17] = "PianoColturaleBudget";
})(enum_TipoSelect_FiltroneSuperNova || (enum_TipoSelect_FiltroneSuperNova = {}));
//#region Filtro Ricerca NEW
var Enum_TipoMostra_FiltroRicerca;
(function (Enum_TipoMostra_FiltroRicerca) {
    Enum_TipoMostra_FiltroRicerca[Enum_TipoMostra_FiltroRicerca["Aziende"] = 1] = "Aziende";
    Enum_TipoMostra_FiltroRicerca[Enum_TipoMostra_FiltroRicerca["CentriAziendali"] = 2] = "CentriAziendali";
    Enum_TipoMostra_FiltroRicerca[Enum_TipoMostra_FiltroRicerca["Campi"] = 3] = "Campi";
    Enum_TipoMostra_FiltroRicerca[Enum_TipoMostra_FiltroRicerca["Appezzamenti"] = 4] = "Appezzamenti";
    Enum_TipoMostra_FiltroRicerca[Enum_TipoMostra_FiltroRicerca["Impianti"] = 5] = "Impianti";
    Enum_TipoMostra_FiltroRicerca[Enum_TipoMostra_FiltroRicerca["Esercizi"] = 6] = "Esercizi";
    Enum_TipoMostra_FiltroRicerca[Enum_TipoMostra_FiltroRicerca["PianoColturale"] = 7] = "PianoColturale";
    Enum_TipoMostra_FiltroRicerca[Enum_TipoMostra_FiltroRicerca["PianoColturaleBudget"] = 8] = "PianoColturaleBudget";
    Enum_TipoMostra_FiltroRicerca[Enum_TipoMostra_FiltroRicerca["Fabbricati"] = 9] = "Fabbricati";
    Enum_TipoMostra_FiltroRicerca[Enum_TipoMostra_FiltroRicerca["Movimenti"] = 10] = "Movimenti";
})(Enum_TipoMostra_FiltroRicerca || (Enum_TipoMostra_FiltroRicerca = {}));
var Enum_Entita_FiltroRicerca;
(function (Enum_Entita_FiltroRicerca) {
    Enum_Entita_FiltroRicerca[Enum_Entita_FiltroRicerca["Azienda"] = 1] = "Azienda";
    Enum_Entita_FiltroRicerca[Enum_Entita_FiltroRicerca["CentroAziendale"] = 2] = "CentroAziendale";
    Enum_Entita_FiltroRicerca[Enum_Entita_FiltroRicerca["Campo"] = 3] = "Campo";
    Enum_Entita_FiltroRicerca[Enum_Entita_FiltroRicerca["Appezzamento"] = 4] = "Appezzamento";
    Enum_Entita_FiltroRicerca[Enum_Entita_FiltroRicerca["Impianto"] = 5] = "Impianto";
    Enum_Entita_FiltroRicerca[Enum_Entita_FiltroRicerca["Esercizio"] = 6] = "Esercizio";
    Enum_Entita_FiltroRicerca[Enum_Entita_FiltroRicerca["Fabbricato"] = 7] = "Fabbricato";
})(Enum_Entita_FiltroRicerca || (Enum_Entita_FiltroRicerca = {}));
var Enum_FiltroDestinazioneUso_FiltroRicerca;
(function (Enum_FiltroDestinazioneUso_FiltroRicerca) {
    Enum_FiltroDestinazioneUso_FiltroRicerca[Enum_FiltroDestinazioneUso_FiltroRicerca["Tutto"] = 0] = "Tutto";
    Enum_FiltroDestinazioneUso_FiltroRicerca[Enum_FiltroDestinazioneUso_FiltroRicerca["SoloDestinazioniUso"] = 1] = "SoloDestinazioniUso";
    Enum_FiltroDestinazioneUso_FiltroRicerca[Enum_FiltroDestinazioneUso_FiltroRicerca["EscludiDestinazioniUso"] = 2] = "EscludiDestinazioniUso";
})(Enum_FiltroDestinazioneUso_FiltroRicerca || (Enum_FiltroDestinazioneUso_FiltroRicerca = {}));
var Enum_FiltroPoligoni_FiltroRicerca;
(function (Enum_FiltroPoligoni_FiltroRicerca) {
    Enum_FiltroPoligoni_FiltroRicerca[Enum_FiltroPoligoni_FiltroRicerca["Tutto"] = 0] = "Tutto";
    Enum_FiltroPoligoni_FiltroRicerca[Enum_FiltroPoligoni_FiltroRicerca["ConPoligoni"] = 1] = "ConPoligoni";
    Enum_FiltroPoligoni_FiltroRicerca[Enum_FiltroPoligoni_FiltroRicerca["SenzaPoligoni"] = 2] = "SenzaPoligoni";
})(Enum_FiltroPoligoni_FiltroRicerca || (Enum_FiltroPoligoni_FiltroRicerca = {}));
var Enum_FiltroRipartoCatasto_FiltroRicerca;
(function (Enum_FiltroRipartoCatasto_FiltroRicerca) {
    Enum_FiltroRipartoCatasto_FiltroRicerca[Enum_FiltroRipartoCatasto_FiltroRicerca["Tutto"] = 0] = "Tutto";
    Enum_FiltroRipartoCatasto_FiltroRicerca[Enum_FiltroRipartoCatasto_FiltroRicerca["ConRiparto"] = 1] = "ConRiparto";
    Enum_FiltroRipartoCatasto_FiltroRicerca[Enum_FiltroRipartoCatasto_FiltroRicerca["SenzaRiparto"] = 2] = "SenzaRiparto";
})(Enum_FiltroRipartoCatasto_FiltroRicerca || (Enum_FiltroRipartoCatasto_FiltroRicerca = {}));
var Enum_ColonnaData_FiltroRicerca;
(function (Enum_ColonnaData_FiltroRicerca) {
    Enum_ColonnaData_FiltroRicerca[Enum_ColonnaData_FiltroRicerca["ValiditaInizio"] = 0] = "ValiditaInizio";
    Enum_ColonnaData_FiltroRicerca[Enum_ColonnaData_FiltroRicerca["ValiditaFine"] = 1] = "ValiditaFine";
    Enum_ColonnaData_FiltroRicerca[Enum_ColonnaData_FiltroRicerca["IntervalloValidita"] = 2] = "IntervalloValidita";
    Enum_ColonnaData_FiltroRicerca[Enum_ColonnaData_FiltroRicerca["DataCreazioneAnagrafica"] = 3] = "DataCreazioneAnagrafica";
})(Enum_ColonnaData_FiltroRicerca || (Enum_ColonnaData_FiltroRicerca = {}));
var Enum_TipoConfronto_FiltroRicerca;
(function (Enum_TipoConfronto_FiltroRicerca) {
    Enum_TipoConfronto_FiltroRicerca[Enum_TipoConfronto_FiltroRicerca["Maggiore"] = 0] = "Maggiore";
    Enum_TipoConfronto_FiltroRicerca[Enum_TipoConfronto_FiltroRicerca["Minore"] = 1] = "Minore";
    Enum_TipoConfronto_FiltroRicerca[Enum_TipoConfronto_FiltroRicerca["MaggioreUguale"] = 2] = "MaggioreUguale";
    Enum_TipoConfronto_FiltroRicerca[Enum_TipoConfronto_FiltroRicerca["MinoreUguale"] = 3] = "MinoreUguale";
    Enum_TipoConfronto_FiltroRicerca[Enum_TipoConfronto_FiltroRicerca["CompresoFra"] = 4] = "CompresoFra";
})(Enum_TipoConfronto_FiltroRicerca || (Enum_TipoConfronto_FiltroRicerca = {}));
var Enum_ModalitaFiltroData_FiltroRicerca;
(function (Enum_ModalitaFiltroData_FiltroRicerca) {
    Enum_ModalitaFiltroData_FiltroRicerca[Enum_ModalitaFiltroData_FiltroRicerca["Manuale"] = 0] = "Manuale";
    Enum_ModalitaFiltroData_FiltroRicerca[Enum_ModalitaFiltroData_FiltroRicerca["AnnataAgraria"] = 1] = "AnnataAgraria";
    Enum_ModalitaFiltroData_FiltroRicerca[Enum_ModalitaFiltroData_FiltroRicerca["Oggi"] = 2] = "Oggi";
})(Enum_ModalitaFiltroData_FiltroRicerca || (Enum_ModalitaFiltroData_FiltroRicerca = {}));
var Enum_FiltroOperatoreLogico_FiltroRicerca;
(function (Enum_FiltroOperatoreLogico_FiltroRicerca) {
    Enum_FiltroOperatoreLogico_FiltroRicerca[Enum_FiltroOperatoreLogico_FiltroRicerca["OR_AlmenoUnaCondizioneTrue"] = 0] = "OR_AlmenoUnaCondizioneTrue";
    Enum_FiltroOperatoreLogico_FiltroRicerca[Enum_FiltroOperatoreLogico_FiltroRicerca["AND_TutteLeCondizioniTrue"] = 1] = "AND_TutteLeCondizioniTrue";
})(Enum_FiltroOperatoreLogico_FiltroRicerca || (Enum_FiltroOperatoreLogico_FiltroRicerca = {}));
var Enum_FiltroOperazioniSelezionate_FiltroRicerca;
(function (Enum_FiltroOperazioniSelezionate_FiltroRicerca) {
    Enum_FiltroOperazioniSelezionate_FiltroRicerca[Enum_FiltroOperazioniSelezionate_FiltroRicerca["Tutto"] = 0] = "Tutto";
    Enum_FiltroOperazioniSelezionate_FiltroRicerca[Enum_FiltroOperazioniSelezionate_FiltroRicerca["ConOperazioni"] = 1] = "ConOperazioni";
    Enum_FiltroOperazioniSelezionate_FiltroRicerca[Enum_FiltroOperazioniSelezionate_FiltroRicerca["SenzaOperazioni"] = 2] = "SenzaOperazioni";
})(Enum_FiltroOperazioniSelezionate_FiltroRicerca || (Enum_FiltroOperazioniSelezionate_FiltroRicerca = {}));
var Enum_TipoComportamento_FiltroRicerca;
(function (Enum_TipoComportamento_FiltroRicerca) {
    Enum_TipoComportamento_FiltroRicerca[Enum_TipoComportamento_FiltroRicerca["Ricerca"] = 0] = "Ricerca";
    Enum_TipoComportamento_FiltroRicerca[Enum_TipoComportamento_FiltroRicerca["RicercaAvanzataAzienda"] = 1] = "RicercaAvanzataAzienda";
    Enum_TipoComportamento_FiltroRicerca[Enum_TipoComportamento_FiltroRicerca["EsportaPdf"] = 2] = "EsportaPdf";
    Enum_TipoComportamento_FiltroRicerca[Enum_TipoComportamento_FiltroRicerca["SelezionamentoEntita"] = 3] = "SelezionamentoEntita";
    Enum_TipoComportamento_FiltroRicerca[Enum_TipoComportamento_FiltroRicerca["EsportaExcel"] = 4] = "EsportaExcel";
})(Enum_TipoComportamento_FiltroRicerca || (Enum_TipoComportamento_FiltroRicerca = {}));
//#endregion
//#region Analisi Del Terreno NEW
var enum_ID_Area_Alert;
(function (enum_ID_Area_Alert) {
    enum_ID_Area_Alert[enum_ID_Area_Alert["Contatti"] = 1] = "Contatti";
    enum_ID_Area_Alert[enum_ID_Area_Alert["Macchine"] = 2] = "Macchine";
    enum_ID_Area_Alert[enum_ID_Area_Alert["Analisi"] = 3] = "Analisi";
    enum_ID_Area_Alert[enum_ID_Area_Alert["PianiConcimazione"] = 4] = "PianiConcimazione";
    enum_ID_Area_Alert[enum_ID_Area_Alert["Nitrati"] = 5] = "Nitrati";
    enum_ID_Area_Alert[enum_ID_Area_Alert["AgricolturaDiPrecisione"] = 6] = "AgricolturaDiPrecisione";
    enum_ID_Area_Alert[enum_ID_Area_Alert["UMA_Carburanti"] = 7] = "UMA_Carburanti";
    enum_ID_Area_Alert[enum_ID_Area_Alert["Richiesta_Iscrizione_GIAS"] = 8] = "Richiesta_Iscrizione_GIAS";
    enum_ID_Area_Alert[enum_ID_Area_Alert["Report_Gias"] = 9] = "Report_Gias";
    enum_ID_Area_Alert[enum_ID_Area_Alert["Documenti_Contabili"] = 10] = "Documenti_Contabili";
    enum_ID_Area_Alert[enum_ID_Area_Alert["Operazioni_Campagna_QDC"] = 11] = "Operazioni_Campagna_QDC";
    enum_ID_Area_Alert[enum_ID_Area_Alert["Catasto"] = 12] = "Catasto";
    enum_ID_Area_Alert[enum_ID_Area_Alert["Carichi_Scarichi"] = 13] = "Carichi_Scarichi";
})(enum_ID_Area_Alert || (enum_ID_Area_Alert = {}));
var enum_ID_Area_Tipologia;
(function (enum_ID_Area_Tipologia) {
    enum_ID_Area_Tipologia[enum_ID_Area_Tipologia["Patentino_trattamenti"] = -1] = "Patentino_trattamenti";
    enum_ID_Area_Tipologia[enum_ID_Area_Tipologia["Taratura_ugelli"] = -2] = "Taratura_ugelli";
    enum_ID_Area_Tipologia[enum_ID_Area_Tipologia["Carta_Identita"] = -3] = "Carta_Identita";
    enum_ID_Area_Tipologia[enum_ID_Area_Tipologia["Analisi_terreno"] = -4] = "Analisi_terreno";
    enum_ID_Area_Tipologia[enum_ID_Area_Tipologia["Piano_Concimazione"] = -5] = "Piano_Concimazione";
    enum_ID_Area_Tipologia[enum_ID_Area_Tipologia["PUA"] = -6] = "PUA";
    enum_ID_Area_Tipologia[enum_ID_Area_Tipologia["Laboratorio"] = -7] = "Laboratorio";
    enum_ID_Area_Tipologia[enum_ID_Area_Tipologia["OrganismoDiControllo"] = -8] = "OrganismoDiControllo";
    enum_ID_Area_Tipologia[enum_ID_Area_Tipologia["AgricolturaDiPrecisione_MappaPrescrizione"] = -9] = "AgricolturaDiPrecisione_MappaPrescrizione";
    enum_ID_Area_Tipologia[enum_ID_Area_Tipologia["AgricolturaDiPrecisione_MappaProduzione"] = -10] = "AgricolturaDiPrecisione_MappaProduzione";
    enum_ID_Area_Tipologia[enum_ID_Area_Tipologia["AgricolturaDiPrecisione_FileBordoMacchina"] = -11] = "AgricolturaDiPrecisione_FileBordoMacchina";
    enum_ID_Area_Tipologia[enum_ID_Area_Tipologia["Doc_Template_Richiesta_Iscrizione_GIAS"] = -12] = "Doc_Template_Richiesta_Iscrizione_GIAS";
    enum_ID_Area_Tipologia[enum_ID_Area_Tipologia["Richiesta_Iscrizione_GIAS"] = -13] = "Richiesta_Iscrizione_GIAS";
    enum_ID_Area_Tipologia[enum_ID_Area_Tipologia["Scheda_Campagna_Completa"] = -14] = "Scheda_Campagna_Completa";
    enum_ID_Area_Tipologia[enum_ID_Area_Tipologia["UMA_dichiarazione_pre_assegnazione"] = -15] = "UMA_dichiarazione_pre_assegnazione";
    enum_ID_Area_Tipologia[enum_ID_Area_Tipologia["Fatture_Attive_Da_Sistema_Esterno"] = -16] = "Fatture_Attive_Da_Sistema_Esterno";
    enum_ID_Area_Tipologia[enum_ID_Area_Tipologia["Fatture_Passive_Da_Sistema_Esterno"] = -17] = "Fatture_Passive_Da_Sistema_Esterno";
    enum_ID_Area_Tipologia[enum_ID_Area_Tipologia["Ordini_Acquisto"] = -18] = "Ordini_Acquisto";
    enum_ID_Area_Tipologia[enum_ID_Area_Tipologia["DDT_Ricevuti"] = -19] = "DDT_Ricevuti";
    enum_ID_Area_Tipologia[enum_ID_Area_Tipologia["Conferimenti"] = -20] = "Conferimenti";
    enum_ID_Area_Tipologia[enum_ID_Area_Tipologia["DDT_Emessi"] = -21] = "DDT_Emessi";
    enum_ID_Area_Tipologia[enum_ID_Area_Tipologia["Ordini_Vendita"] = -22] = "Ordini_Vendita";
    enum_ID_Area_Tipologia[enum_ID_Area_Tipologia["Fatture_Passive"] = -23] = "Fatture_Passive";
    enum_ID_Area_Tipologia[enum_ID_Area_Tipologia["Fatture_Attive"] = -24] = "Fatture_Attive";
    enum_ID_Area_Tipologia[enum_ID_Area_Tipologia["Operazioni_Campagna_QDC"] = -25] = "Operazioni_Campagna_QDC";
    enum_ID_Area_Tipologia[enum_ID_Area_Tipologia["Contratti_Affitto"] = -26] = "Contratti_Affitto";
    enum_ID_Area_Tipologia[enum_ID_Area_Tipologia["Possesso_Particelle"] = -27] = "Possesso_Particelle";
    enum_ID_Area_Tipologia[enum_ID_Area_Tipologia["Carichi_Magazzino"] = -28] = "Carichi_Magazzino";
    enum_ID_Area_Tipologia[enum_ID_Area_Tipologia["Scarichi_Magazzino"] = -29] = "Scarichi_Magazzino";
})(enum_ID_Area_Tipologia || (enum_ID_Area_Tipologia = {}));
var enum_AnalisiTipo;
(function (enum_AnalisiTipo) {
    enum_AnalisiTipo[enum_AnalisiTipo["Analisi_Terreno"] = 1] = "Analisi_Terreno";
    enum_AnalisiTipo[enum_AnalisiTipo["Analisi_Terreno_Fanghi"] = 2] = "Analisi_Terreno_Fanghi";
    enum_AnalisiTipo[enum_AnalisiTipo["Analisi_Acqua"] = 3] = "Analisi_Acqua";
    enum_AnalisiTipo[enum_AnalisiTipo["Analisi_Residui_Fitofarmaci_Vegetali"] = 4] = "Analisi_Residui_Fitofarmaci_Vegetali";
    enum_AnalisiTipo[enum_AnalisiTipo["Analisi_Latte"] = 5] = "Analisi_Latte";
    enum_AnalisiTipo[enum_AnalisiTipo["Analisi_Vino"] = 6] = "Analisi_Vino";
    enum_AnalisiTipo[enum_AnalisiTipo["Analisi_Residui"] = 7] = "Analisi_Residui";
    enum_AnalisiTipo[enum_AnalisiTipo["Analisi_Fitofarmaci"] = 8] = "Analisi_Fitofarmaci";
    enum_AnalisiTipo[enum_AnalisiTipo["Analisi_Organolettiche"] = 9] = "Analisi_Organolettiche";
    enum_AnalisiTipo[enum_AnalisiTipo["Analisi_Varie"] = 10] = "Analisi_Varie";
    enum_AnalisiTipo[enum_AnalisiTipo["Analisi_Merceologiche"] = 11] = "Analisi_Merceologiche";
    enum_AnalisiTipo[enum_AnalisiTipo["Analisi_Del_Sangue"] = 12] = "Analisi_Del_Sangue";
})(enum_AnalisiTipo || (enum_AnalisiTipo = {}));
var enum_AnalisiTipologia_Schema;
(function (enum_AnalisiTipologia_Schema) {
    enum_AnalisiTipologia_Schema[enum_AnalisiTipologia_Schema["Piano_Concimazione"] = -1] = "Piano_Concimazione";
    enum_AnalisiTipologia_Schema[enum_AnalisiTipologia_Schema["Area_Omogenea"] = -2] = "Area_Omogenea";
})(enum_AnalisiTipologia_Schema || (enum_AnalisiTipologia_Schema = {}));
var enum_Entita_Analisi;
(function (enum_Entita_Analisi) {
    enum_Entita_Analisi[enum_Entita_Analisi["NonDefinito"] = 0] = "NonDefinito";
    enum_Entita_Analisi[enum_Entita_Analisi["Impresa"] = 1] = "Impresa";
    enum_Entita_Analisi[enum_Entita_Analisi["Centro"] = 2] = "Centro";
    enum_Entita_Analisi[enum_Entita_Analisi["Campo"] = 3] = "Campo";
    enum_Entita_Analisi[enum_Entita_Analisi["Appezzamento"] = 4] = "Appezzamento";
    enum_Entita_Analisi[enum_Entita_Analisi["Impianto"] = 5] = "Impianto";
    enum_Entita_Analisi[enum_Entita_Analisi["Fabbricato"] = 6] = "Fabbricato";
    enum_Entita_Analisi[enum_Entita_Analisi["Particella"] = 7] = "Particella";
    enum_Entita_Analisi[enum_Entita_Analisi["EntitaGrafica"] = 8] = "EntitaGrafica";
})(enum_Entita_Analisi || (enum_Entita_Analisi = {}));
//#endregion

class DynamicInputSettigs {
    /** Il tipo di controllo da usare. */
    controlType = 0;
    /** Il vero campo contenente il valore. */
    realField;
    /** Funzione da eseguire al cambiamento del valore. */
    onEdit = (newValue) => {
        let a = 0; //Commento per funzione vuota SonarQube
    };
    ddl = null;
    numeric = null;
    boolean = null;
    date = null;
    string = null;
    constructor(settings) {
        this.controlType = settings?.controlType || 0;
        this.realField = settings?.realField || undefined;
        this.onEdit = settings?.onEdit || null;
        this.ddl = settings?.ddl || null;
        this.numeric = settings?.numeric || new NumericSettings();
        this.boolean = settings?.boolean || new BooleanSettings();
        this.date = settings?.date || new DateSettings();
        this.string = settings?.string || new StringSettings();
    }
}
/** Per ora utilizzato solo in <code>grid-rilievi.service.ts</code>.
 *  @Warning va in conflitto con le griglie con EditingMode di tipo <code>EditingMode.IN_CELL</code>
 */
class DynamicInputComponent {
    /** Il dataItem rappresentante la riga corrente. */
    input;
    /** Indica il campo in dataItem di tipo {@link DynamicInputSettigs} a cui fare
     *  riferimento per usare il componente.
     *  Necessario specificarlo per ogni riga in modo da rendere la cosa
     *  dinamica.
     */
    field;
    edit = false;
    settings;
    form;
    enum_TipoControllo = {
        UNDEFINED: 0,
        CASELLA_TESTO: 1,
        AREA_TESTO: 2,
        MENU_DISCESA: 3,
        CASELLA_SPUNTA: 4,
        CALENDARIO: 5,
        ALLEGATO: 6,
        LINK: 7,
        PASSWORD: 8,
        MULTISELECT_ESTESA_SERVER: 9,
        PULSANTE_SCELTA: 10,
        IMMAGINE: 11,
        DDL_ESTESA_CLIENT: 12,
        GIS_VIEWER: 13,
        DDL_ESTESA_SERVER_LIGHT: 14,
        NUMERO_INTERO: 15,
        NUMERO_DECIMALE: 16,
        MULTISELECT: 17
    };
    AGRODATA_INIZIO = AGRODATAINIZIO;
    fieldControl;
    _internalChange = false;
    ngOnInit() {
        this.settings = new DynamicInputSettigs(this.input[this.field]);
        if (this.input && this.settings.realField) {
            this.createForm();
        }
    }
    update(ev) {
        switch (this.settings.controlType) {
            case enum_TipoControllo.CALENDARIO:
            case enum_TipoControllo.NUMERO_DECIMALE:
                this.input[this.settings.realField] = this.fieldControl.value;
                break;
            case enum_TipoControllo.CASELLA_SPUNTA:
                this.input[this.settings.realField] = this.fieldControl.value ? 1 : 0;
                break;
            case enum_TipoControllo.NUMERO_INTERO:
                this.fieldControl.patchValue(Math.round(this.fieldControl.value));
                this.input[this.settings.realField] = this.fieldControl.value;
                break;
            case enum_TipoControllo.MENU_DISCESA:
                //const toPatch = this.settings.ddl.valuePrimitive ? ev.data.id : ev.data;
                this.input[this.settings.realField] = ev.data;
                break;
            default:
                console.error("Update handling for type ", this.settings.controlType, " not yet implemented!");
        }
        if (this.settings.onEdit) {
            this.settings.onEdit(this.input);
        }
    }
    createForm() {
        let property;
        this.form = new FormGroup([]);
        for (property in this.input) {
            this.form.addControl(property, new FormControl(this.input[property]));
        }
        this.fieldControl = this.form.get(this.settings.realField);
        this.updateFieldControl();
    }
    ngAfterContentChecked() {
        // if (this.fieldControl?.value !== this.input[this.settings?.realField]) {
        //     this._internalChange = true;
        //     this.updateFieldControl();
        // }
    }
    /**
     * Patches the value of the field in the control, eventually adapting
     * different values to the expected ones. i.e. boolean values.
     * @private
     */
    updateFieldControl() {
        if (this.settings.controlType === enum_TipoControllo.CASELLA_SPUNTA
            && !isBoolean(this.input[this.settings.realField])) {
            this.fieldControl.patchValue(this.parseBoolean(this.input[this.settings.realField]));
        }
        else {
            this.fieldControl.patchValue(this.input[this.settings.realField]);
        }
    }
    parseBoolean(value) {
        if (isNumber(value)) {
            return value !== 0;
        }
        else if (isString(value)) {
            return !(value === "" || value === "0");
        }
        else
            return !!value;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: DynamicInputComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "19.2.9", type: DynamicInputComponent, isStandalone: false, selector: "gias-dynamic-input", inputs: { input: "input", field: "field", edit: "edit" }, ngImport: i0, template: "<div style=\"display: flex; align-items: center; justify-content: center;\">\n    <form [formGroup]=\"form\" style=\"width: 90%;\">\n        <div *ngIf=\"settings.controlType === enum_TipoControllo.CALENDARIO\">\n            <gias-data-template\n                [giasFormControlName]=\"settings.realField\"\n                [nullValue]=\"AGRODATA_INIZIO\"\n                (valueChange)=\"update($event)\"\n            ></gias-data-template>\n        </div>\n        <div *ngIf=\"settings.controlType === enum_TipoControllo.CASELLA_SPUNTA\" class=\"centered\">\n            <span class=\"switch-label k-label\">{{settings.boolean.leftLabel}}</span>\n            <gias-switch-template\n                [giasFormControlName]=\"settings.realField\"\n                [hideLabel]=\"true\"\n                (valueChange)=\"update($event)\"\n            ></gias-switch-template>\n            <span class=\"switch-label k-label\">{{settings.boolean.rightLabel}}</span>\n        </div>\n        <div *ngIf=\"settings.controlType === enum_TipoControllo.NUMERO_INTERO\">\n            <kendo-numerictextbox\n                [formControl]=\"fieldControl\"\n                format=\"n0\"\n                [min]=\"settings.numeric.min\" [max]=\"settings.numeric.max\"\n                [autoCorrect]=\"settings.numeric.autoCorrect\"\n                [step]=\"settings.numeric.step\"\n                (blur)=\"update($event)\"\n            ></kendo-numerictextbox>\n        </div>\n        <div *ngIf=\"settings.controlType === enum_TipoControllo.NUMERO_DECIMALE\">\n            <kendo-numerictextbox\n                [formControl]=\"fieldControl\"\n                [min]=\"settings.numeric.min\" [max]=\"settings.numeric.max\" [format]=\"settings.numeric.format\"\n                [spinners]=\"false\"\n                [autoCorrect]=\"settings.numeric.autoCorrect\"\n                [decimals]=\"settings.numeric.decimals\"\n                [step]=\"settings.numeric.step\"\n                (blur)=\"update($event)\"\n            ></kendo-numerictextbox>\n        </div>\n        <div *ngIf=\"settings.controlType === enum_TipoControllo.MENU_DISCESA\">\n            <gias-drop-down-template\n                textField=\"name\"\n                valueField=\"id\"\n                [giasFormControlName]=\"settings.realField\"\n                [listItems]=\"settings.ddl.data\"\n                [valuePrimitive]=\"false\"\n                (valueChange)=\"update($event)\"\n            ></gias-drop-down-template>\n        </div>\n    </form>\n</div>\n", styles: [".k-switch-on .k-switch-track{background-color:#002850!important}gias-drop-down-template{width:100%}.centered{display:flex;justify-content:center}.switch-label{margin:6px 10px}\n"], dependencies: [{ kind: "directive", type: i3.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "component", type: i14.NumericTextBoxComponent, selector: "kendo-numerictextbox", inputs: ["focusableId", "disabled", "readonly", "title", "autoCorrect", "format", "max", "min", "decimals", "placeholder", "step", "spinners", "rangeValidation", "tabindex", "tabIndex", "changeValueOnScroll", "selectOnFocus", "value", "maxlength", "size", "rounded", "fillMode", "inputAttributes"], outputs: ["valueChange", "focus", "blur", "inputFocus", "inputBlur"], exportAs: ["kendoNumericTextBox"] }, { kind: "directive", type: i2$2.ɵNgNoValidate, selector: "form:not([ngNoForm]):not([ngNativeValidate])" }, { kind: "directive", type: i2$2.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i2$2.NgControlStatusGroup, selector: "[formGroupName],[formArrayName],[ngModelGroup],[formGroup],form:not([ngNoForm]),[ngForm]" }, { kind: "directive", type: i2$2.FormControlDirective, selector: "[formControl]", inputs: ["formControl", "disabled", "ngModel"], outputs: ["ngModelChange"], exportAs: ["ngForm"] }, { kind: "directive", type: i2$2.FormGroupDirective, selector: "[formGroup]", inputs: ["formGroup"], outputs: ["ngSubmit"], exportAs: ["ngForm"] }, { kind: "component", type: i2$1.GiasDataTemplateComponent, selector: "gias-data-template", inputs: ["name", "value", "nullValue", "startValue", "endValue", "obligatory", "isDisabled", "giasFormControlName", "parentGroup", "readOnlyInput", "format", "disabledDates", "inlineLabels"], outputs: ["valueChange", "onBlur"] }, { kind: "component", type: i2$1.GiasDropDownTemplateComponent, selector: "gias-drop-down-template", inputs: ["id", "name", "value", "listItems", "itemDisabledFn", "obligatory", "clearButton", "isDisabled", "textField", "valueField", "filterable", "defaultItem", "giasFormControlName", "parentGroup", "parentFormControl", "valuePrimitive", "applyMinimumFilterLength", "MinimumFilterLength", "ddlServerFiltering", "loadFunctionddlServerFiltering", "virtual"], outputs: ["valueChange", "open", "filterChange"] }, { kind: "component", type: i2$1.GiasSwitchTemplateComponent, selector: "gias-switch-template", inputs: ["name", "value", "placeholder", "isDisabled", "giasFormControlName", "siLabel", "noLabel", "isBlue", "hideLabel", "hideformfield"], outputs: ["valueChange"] }], encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: DynamicInputComponent, decorators: [{
            type: Component,
            args: [{ standalone: false, selector: 'gias-dynamic-input', encapsulation: ViewEncapsulation.None, template: "<div style=\"display: flex; align-items: center; justify-content: center;\">\n    <form [formGroup]=\"form\" style=\"width: 90%;\">\n        <div *ngIf=\"settings.controlType === enum_TipoControllo.CALENDARIO\">\n            <gias-data-template\n                [giasFormControlName]=\"settings.realField\"\n                [nullValue]=\"AGRODATA_INIZIO\"\n                (valueChange)=\"update($event)\"\n            ></gias-data-template>\n        </div>\n        <div *ngIf=\"settings.controlType === enum_TipoControllo.CASELLA_SPUNTA\" class=\"centered\">\n            <span class=\"switch-label k-label\">{{settings.boolean.leftLabel}}</span>\n            <gias-switch-template\n                [giasFormControlName]=\"settings.realField\"\n                [hideLabel]=\"true\"\n                (valueChange)=\"update($event)\"\n            ></gias-switch-template>\n            <span class=\"switch-label k-label\">{{settings.boolean.rightLabel}}</span>\n        </div>\n        <div *ngIf=\"settings.controlType === enum_TipoControllo.NUMERO_INTERO\">\n            <kendo-numerictextbox\n                [formControl]=\"fieldControl\"\n                format=\"n0\"\n                [min]=\"settings.numeric.min\" [max]=\"settings.numeric.max\"\n                [autoCorrect]=\"settings.numeric.autoCorrect\"\n                [step]=\"settings.numeric.step\"\n                (blur)=\"update($event)\"\n            ></kendo-numerictextbox>\n        </div>\n        <div *ngIf=\"settings.controlType === enum_TipoControllo.NUMERO_DECIMALE\">\n            <kendo-numerictextbox\n                [formControl]=\"fieldControl\"\n                [min]=\"settings.numeric.min\" [max]=\"settings.numeric.max\" [format]=\"settings.numeric.format\"\n                [spinners]=\"false\"\n                [autoCorrect]=\"settings.numeric.autoCorrect\"\n                [decimals]=\"settings.numeric.decimals\"\n                [step]=\"settings.numeric.step\"\n                (blur)=\"update($event)\"\n            ></kendo-numerictextbox>\n        </div>\n        <div *ngIf=\"settings.controlType === enum_TipoControllo.MENU_DISCESA\">\n            <gias-drop-down-template\n                textField=\"name\"\n                valueField=\"id\"\n                [giasFormControlName]=\"settings.realField\"\n                [listItems]=\"settings.ddl.data\"\n                [valuePrimitive]=\"false\"\n                (valueChange)=\"update($event)\"\n            ></gias-drop-down-template>\n        </div>\n    </form>\n</div>\n", styles: [".k-switch-on .k-switch-track{background-color:#002850!important}gias-drop-down-template{width:100%}.centered{display:flex;justify-content:center}.switch-label{margin:6px 10px}\n"] }]
        }], propDecorators: { input: [{
                type: Input
            }], field: [{
                type: Input
            }], edit: [{
                type: Input
            }] } });

class ListviewComponent {
    /** The ListView is as high as its content and as wide as the available space.
     * To enable scrolling, use a fixed height that is less than the height of the ListView content. */
    height$ = new ReplaySubject();
    loading$ = new ReplaySubject();
    data$ = new BehaviorSubject([]);
    removeDataItem$;
    resetStates$ = new Subject();
    showListHeader = () => false;
    showAddBtn = () => false;
    showEditBtn = () => false;
    showSaveBtn = () => false;
    showCancelBtn = () => false;
    showRemoveBtn = () => true;
    showDeleteBtn = () => false;
    removeBtnTitle = 'giasgrid.RemoveRowFromList';
    deleteBtnTitle = 'giasgrid.Elimina';
    addEvent$ = new Subject();
    editEvent$ = new Subject();
    saveEvent$ = new Subject();
    cancelEvent$ = new Subject();
    removeEvent$ = new Subject();
    deleteEvent$ = new Subject();
    faTrashCan = faTrashCan;
    faClose = faClose;
    destroy$ = new Subject();
    editedRowIndex;
    constructor() { }
    ngOnInit() {
        this.removeDataItem$.pipe(takeUntil$1(this.destroy$)).subscribe(e => {
            this.removeDataItem(e.index, e.deleteCount);
        });
        this.resetStates$.pipe(takeUntil$1(this.destroy$)).subscribe(state => {
            this.resetDataState(state);
        });
    }
    ngOnDestroy() {
        this.destroy$.next();
        this.destroy$.complete();
    }
    addHandler(event) {
        throw new Error('Method not ye implemented');
    }
    editHandler(event) {
        throw new Error('Method not ye implemented');
    }
    saveHandler(event) {
        throw new Error('Method not ye implemented');
    }
    cancelHandler(event) {
        throw new Error('Method not ye implemented');
    }
    removeHandler(event) {
        this.removeDataItem$.next({ index: event.itemIndex, deleteCount: 1 });
    }
    deleteHandler(dataItem, index) {
        this.deleteEvent$.next({ item: dataItem, itemIndex: index });
    }
    setItemStateStyle(item, index) {
        // edit freely the style for warning and success, there was no time to do it well (as usual)
        let style;
        if (item.error) {
            style = 'background-color: #F8EEED !important';
        }
        else if (item.warning) {
            style = index % 2 === 0 ? 'background-color: #F0F0F0 !important' : '';
        }
        else if (item.success) {
            style = index % 2 === 0 ? 'background-color: #F0F0F0 !important' : '';
        }
        else {
            style = index % 2 === 0 ? 'background-color: #F0F0F0 !important' : '';
        }
        return style;
    }
    removeDataItem(index, deleteCount) {
        this.data$.value.splice(index, deleteCount);
        this.data$.next([...this.data$.value]);
    }
    closeEditor(sender, itemIndex = this.editedRowIndex) {
        sender.closeItem(itemIndex);
        this.editedRowIndex = undefined;
    }
    resetDataState(state = false) {
        this.data$.next(this.data$.getValue().map(r => {
            r.error = state;
            r.success = state;
            r.warning = state;
            return r;
        }));
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: ListviewComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "19.2.9", type: ListviewComponent, isStandalone: false, selector: "app-listview", inputs: { height$: "height$", loading$: "loading$", data$: "data$", removeDataItem$: "removeDataItem$", resetStates$: "resetStates$", showListHeader: "showListHeader", showAddBtn: "showAddBtn", showEditBtn: "showEditBtn", showSaveBtn: "showSaveBtn", showCancelBtn: "showCancelBtn", showRemoveBtn: "showRemoveBtn", showDeleteBtn: "showDeleteBtn", removeBtnTitle: "removeBtnTitle", deleteBtnTitle: "deleteBtnTitle" }, outputs: { addEvent$: "add", editEvent$: "edit", saveEvent$: "save", cancelEvent$: "cancel", removeEvent$: "remove", deleteEvent$: "delete" }, ngImport: i0, template: "<kendo-listview\n  #listview\n  class=\"k-listview\"\n  [height]=\"height$ | async\"\n  [data]=\"data$ | async\"\n  (add)=\"addHandler($event)\"\n  (edit)=\"editHandler($event)\"\n  (save)=\"saveHandler($event)\"\n  (cancel)=\"cancelHandler($event)\"\n  (remove)=\"removeHandler($event)\"\n  [loading]=\"loading$ | async\"\n>\n\n  <ng-template kendoListViewLoaderTemplate>\n    <gias-wait-frame></gias-wait-frame>\n  </ng-template>\n\n  <ng-template *ngif=\"false\" kendoListViewHeaderTemplate>\n    <button *ngIf=\"showAddBtn()\" class=\"k-add-button\" kendoListViewAddCommand>\n      {{ 'giasgrid.AggiungiElemento' | transloco }}\n    </button>\n    <button *ngIf=\"showRemoveBtn()\" class=\"k-add-button\" kendoListViewRemoveCommand>\n      {{ 'giasgrid.RemoveAllItems' | transloco }}\n    </button>\n  </ng-template>\n\n  <ng-template\n    kendoListViewItemTemplate\n    let-dataItem=\"dataItem\"\n    let-index=\"index\"\n    let-isFirst=\"isFirst\"\n    let-isLast=\"isLast\"\n  >\n    <div class=\"listview-item-template\" [style]=\"setItemStateStyle(dataItem, index)\">\n      <dl>\n<!--        <dt>Product Name</dt>-->\n        <dd class=\"listview-item-dd\">{{ dataItem.description }}</dd>\n      </dl>\n      <div class=\"\">\n        <button *ngIf=\"showEditBtn()\" kendoListViewEditCommand>{{ 'giasgrid.Edit' | transloco }}</button>\n        <button\n          *ngIf=\"showRemoveBtn()\"\n          class=\"listview-remove-btn\"\n          kendoTooltip\n          kendoListViewRemoveCommand\n          type=\"button\"\n          [title]=\"removeBtnTitle | transloco\"\n        >\n          <fa-icon\n            size=\"lg\"\n            [icon]=\"faClose\"\n            aria-hidden=\"true\"\n          ></fa-icon>\n        </button>\n        <button\n          *ngIf=\"showDeleteBtn()\"\n          class=\"listview-remove-btn k-button k-button-md k-rounded-md k-button-solid-base k-button-solid\"\n          kendoTooltip\n          type=\"button\"\n          [title]=\"deleteBtnTitle | transloco\"\n          (click)=\"deleteHandler(dataItem, index)\"\n        >\n          <fa-icon\n            size=\"lg\"\n            [icon]=\"faTrashCan\"\n            aria-hidden=\"true\"\n          ></fa-icon>\n        </button>\n      </div>\n    </div>\n  </ng-template>\n</kendo-listview>\n", styles: [".k-listview{font-family:sans-serif;width:100%;margin:0;border-radius:5px}.listview-item-template{display:flex;flex-direction:row;justify-content:space-between;align-items:baseline;padding:.5em}.listview-remove-btn{background-color:transparent!important;border:none!important;color:red;max-width:45px}dd,dl{margin:unset}\n"], dependencies: [{ kind: "directive", type: i3.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "component", type: i7.FaIconComponent, selector: "fa-icon", inputs: ["icon", "title", "animation", "mask", "flip", "size", "pull", "border", "inverse", "symbol", "rotate", "fixedWidth", "transform", "a11yRole"] }, { kind: "directive", type: i7$1.TooltipDirective, selector: "[kendoTooltip]", inputs: ["filter", "position", "titleTemplate", "showOn", "showAfter", "callout", "closable", "offset", "tooltipWidth", "tooltipHeight", "tooltipClass", "tooltipContentClass", "collision", "closeTitle", "tooltipTemplate"], exportAs: ["kendoTooltip"] }, { kind: "component", type: i4$1.ListViewComponent, selector: "kendo-listview", inputs: ["bordered", "data", "loading", "containerStyle", "itemStyle", "containerClass", "itemClass", "containerLabel", "containerRole", "listItemRole", "navigable", "pageSize", "skip", "pageable", "height"], outputs: ["scrollBottom", "pageChange", "pageSizeChange", "edit", "cancel", "save", "remove", "add"], exportAs: ["kendoListView"] }, { kind: "directive", type: i4$1.ItemTemplateDirective, selector: "[kendoListViewItemTemplate]" }, { kind: "directive", type: i4$1.HeaderTemplateDirective, selector: "[kendoListViewHeaderTemplate]" }, { kind: "directive", type: i4$1.LoaderTemplateDirective, selector: "[kendoListViewLoaderTemplate]" }, { kind: "component", type: i4$1.EditCommandDirective, selector: "[kendoListViewEditCommand]" }, { kind: "component", type: i4$1.RemoveCommandDirective, selector: "[kendoListViewRemoveCommand]" }, { kind: "component", type: i4$1.AddCommandDirective, selector: "[kendoListViewAddCommand]" }, { kind: "component", type: i2$1.GiasWaitFrameComponent, selector: "gias-wait-frame", inputs: ["message"] }, { kind: "pipe", type: i3.AsyncPipe, name: "async" }, { kind: "pipe", type: i1$1.TranslocoPipe, name: "transloco" }], encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: ListviewComponent, decorators: [{
            type: Component,
            args: [{ standalone: false, selector: 'app-listview', encapsulation: ViewEncapsulation.None, template: "<kendo-listview\n  #listview\n  class=\"k-listview\"\n  [height]=\"height$ | async\"\n  [data]=\"data$ | async\"\n  (add)=\"addHandler($event)\"\n  (edit)=\"editHandler($event)\"\n  (save)=\"saveHandler($event)\"\n  (cancel)=\"cancelHandler($event)\"\n  (remove)=\"removeHandler($event)\"\n  [loading]=\"loading$ | async\"\n>\n\n  <ng-template kendoListViewLoaderTemplate>\n    <gias-wait-frame></gias-wait-frame>\n  </ng-template>\n\n  <ng-template *ngif=\"false\" kendoListViewHeaderTemplate>\n    <button *ngIf=\"showAddBtn()\" class=\"k-add-button\" kendoListViewAddCommand>\n      {{ 'giasgrid.AggiungiElemento' | transloco }}\n    </button>\n    <button *ngIf=\"showRemoveBtn()\" class=\"k-add-button\" kendoListViewRemoveCommand>\n      {{ 'giasgrid.RemoveAllItems' | transloco }}\n    </button>\n  </ng-template>\n\n  <ng-template\n    kendoListViewItemTemplate\n    let-dataItem=\"dataItem\"\n    let-index=\"index\"\n    let-isFirst=\"isFirst\"\n    let-isLast=\"isLast\"\n  >\n    <div class=\"listview-item-template\" [style]=\"setItemStateStyle(dataItem, index)\">\n      <dl>\n<!--        <dt>Product Name</dt>-->\n        <dd class=\"listview-item-dd\">{{ dataItem.description }}</dd>\n      </dl>\n      <div class=\"\">\n        <button *ngIf=\"showEditBtn()\" kendoListViewEditCommand>{{ 'giasgrid.Edit' | transloco }}</button>\n        <button\n          *ngIf=\"showRemoveBtn()\"\n          class=\"listview-remove-btn\"\n          kendoTooltip\n          kendoListViewRemoveCommand\n          type=\"button\"\n          [title]=\"removeBtnTitle | transloco\"\n        >\n          <fa-icon\n            size=\"lg\"\n            [icon]=\"faClose\"\n            aria-hidden=\"true\"\n          ></fa-icon>\n        </button>\n        <button\n          *ngIf=\"showDeleteBtn()\"\n          class=\"listview-remove-btn k-button k-button-md k-rounded-md k-button-solid-base k-button-solid\"\n          kendoTooltip\n          type=\"button\"\n          [title]=\"deleteBtnTitle | transloco\"\n          (click)=\"deleteHandler(dataItem, index)\"\n        >\n          <fa-icon\n            size=\"lg\"\n            [icon]=\"faTrashCan\"\n            aria-hidden=\"true\"\n          ></fa-icon>\n        </button>\n      </div>\n    </div>\n  </ng-template>\n</kendo-listview>\n", styles: [".k-listview{font-family:sans-serif;width:100%;margin:0;border-radius:5px}.listview-item-template{display:flex;flex-direction:row;justify-content:space-between;align-items:baseline;padding:.5em}.listview-remove-btn{background-color:transparent!important;border:none!important;color:red;max-width:45px}dd,dl{margin:unset}\n"] }]
        }], ctorParameters: () => [], propDecorators: { height$: [{
                type: Input
            }], loading$: [{
                type: Input
            }], data$: [{
                type: Input
            }], removeDataItem$: [{
                type: Input
            }], resetStates$: [{
                type: Input
            }], showListHeader: [{
                type: Input
            }], showAddBtn: [{
                type: Input
            }], showEditBtn: [{
                type: Input
            }], showSaveBtn: [{
                type: Input
            }], showCancelBtn: [{
                type: Input
            }], showRemoveBtn: [{
                type: Input
            }], showDeleteBtn: [{
                type: Input
            }], removeBtnTitle: [{
                type: Input
            }], deleteBtnTitle: [{
                type: Input
            }], addEvent$: [{
                type: Output,
                args: ['add']
            }], editEvent$: [{
                type: Output,
                args: ['edit']
            }], saveEvent$: [{
                type: Output,
                args: ['save']
            }], cancelEvent$: [{
                type: Output,
                args: ['cancel']
            }], removeEvent$: [{
                type: Output,
                args: ['remove']
            }], deleteEvent$: [{
                type: Output,
                args: ['delete']
            }] } });

const itTranslations = {
    "A": "A",
    "Aggiungi": "Aggiungi",
    "AggiungiElemento": "Aggiungi elemento",
    "AltreAzioni": "Altre Azioni",
    "and": "E",
    "Annulla": "Annulla",
    "Annulla_Modifiche": "Annulla le Modifiche",
    "Applica_Modifiche": "Applica",
    "Base": "Base",
    "BasicFilters": "Filtri di base",
    "Campo": "Campo",
    "Cancella": "Cancella",
    "CancellaPersonalizzazioni": "Cancella personalizzazioni",
    "Caricamento": "Caricamento in corso...",
    "Conferma": "Conferma",
    "Conteggio_Totale": "Conteggio Totale:",
    "DA": "Da",
    "DataNonCoerente": "Data non coerente",
    "DestinazioneDUsoObbligatoria": "Destinazione D'uso Obbligatoria",
    "Dettagli": "Dettagli",
    "Edit": "Modifica",
    "EditVistaPubblicaWarning": "Non disponi dei permessi per modificare le viste pubbliche!",
    "eq": "Uguale a",
    "Errore_": "Errore",
    "Export_Excel": "Esporta in Excel",
    "Export_PDF": "Esporta in PDF",
    "ExtendedFilters": "Filtri Estesi",
    "grpEmptyMsg": "Trascina un'intestazione di colonna e rilasciala qui per raggruppare i dati in base a quella colonna",
    "gt": "Maggiore di",
    "gte": "Maggiore o uguale a",
    "Informazioni": "Informazioni",
    "InfoViste": "Imposta i filtri desiderati e crea una nuova vista scrivendo il titolo nel campo qui a fianco o salva la vista corrente cliccando il pulsante sulla destra.",
    "isnotnull": "Non è uguale a null",
    "isnull": "È uguale a null",
    "loading": "Caricamento in corso",
    "lt": "Minore di",
    "lte": "Minore o uguale a",
    "Massimo": "Massimo:",
    "Media": "Media:",
    "MenuAgendaActivityDeletionWBrogliaccio": "La cancellazione dell'agenda comporterà la cancellazione del relativo brogliaccio.",
    "Minimo": "Minimo:",
    "Modifica": "Modifica",
    "MultipleDeletionConfirmation": "Sei sicuro di voler cancellare {0} elementi?",
    "neq": "Non uguale a",
    "No_Dati": "Nessun dato trovato",
    "NuovaSchedaRapida": "Nuova Riga",
    "Nuovo_Elemento": "Aggiungi",
    "Obbligatorio": "Obbligatorio",
    "of": "di",
    "Ok": "Ok",
    "or": "O",
    "Ordina": "Ordina",
    "Page": "Pagina",
    "PartitaIvaGiàInserita": "VAT number already entered",
    "Privata": "Privata",
    "Pubblica": "Pubblica",
    "PulisciFiltri": "Pulisci Filtri",
    "RemoveAllItems": "Rimuovi tutti gli elementi",
    "Ricerca": "Ricerca",
    "Salva": "Salva",
    "SalvaPersonalizzazioni": "Salva Personalizzazioni",
    "SalvaPredefinita": "La vista Base non è modificabile. Per personalizzare, crea una nuova vista",
    "Save_Changes": "Salva le Modifiche",
    "ScegliUnaVista": "Personalizzazioni Griglia:",
    "ScegliUnaVistaCaption": "Scegli una vista",
    "Select_All": "Seleziona tutto",
    "SoleDeletionConfirmation": "Sei sicuro di voler cancellare l'elemento selezionato?",
    "Somma_Totale_Abbr": "Tot:",
    "SonoStatiRilevatiISeguentiErrori_": "Sono stati rilevati i seguenti errori:",
    "SpecieObbligatoria": "Specie Obbligatoria",
    "TotaleXElementi": "Totale: {count} elementi",
    "Tutti": "Tutti",
    "VarietàObbligatoria": "Varietà Obbligatoria",
    "VistaCancellata": "La vista è stata cancellata.",
    "VisteSalvate": "Le viste sono state salvate."
};

const enTranslations = {
    "A": "To",
    "Aggiungi": "Add",
    "AggiungiElemento": "Add item",
    "AltreAzioni": "Other Actions",
    "and": "And",
    "Annulla": "Cancel",
    "Annulla_Modifiche": "Undo Changes",
    "Applica_Modifiche": "Apply",
    "Base": "Basic",
    "BasicFilters": "Basic Filters",
    "Campo": "SuperPlot",
    "Cancella": "Remove",
    "CancellaPersonalizzazioni": "Clear customizations",
    "Caricamento": "Loading...",
    "Conferma": "Confirm",
    "Conteggio_Totale": "Total Count:",
    "DA": "From",
    "DataNonCoerente": "Inconsistent date",
    "DestinazioneDUsoObbligatoria": "Mandatory intended use",
    "Dettagli": "Details",
    "Edit": "Edit",
    "EditVistaPubblicaWarning": "You do not have permission to edit public views!",
    "eq": "Equal to",
    "Errore_": "Mistake",
    "Export_Excel": "Export to Excel",
    "Export_PDF": "Export to PDF",
    "ExtendedFilters": "Extended Filters",
    "grpEmptyMsg": "Drag a column header and drop it here to group by that column",
    "gt": "Greater than",
    "gte": "Greater than or equal to",
    "Informazioni": "Infos",
    "InfoViste": "Set the desired filters and create a new view by writing the title in the field opposite or save the current view by clicking the button on the right.",
    "isnotnull": "Is not equal to null",
    "isnull": "Is equal to null",
    "loading": "Loading",
    "lt": "Less than",
    "lte": "Less than or equal to",
    "Massimo": "Maximum:",
    "Media": "Average:",
    "MenuAgendaActivityDeletionWBrogliaccio": "Cancellation of the agenda will result in the cancellation of the related plan.",
    "Minimo": "Minimum:",
    "Modifica": "Change",
    "MultipleDeletionConfirmation": "Are you sure you want to delete {0} items?",
    "neq": "Not equal to",
    "No_Dati": "No data found",
    "NuovaSchedaRapida": "New Row",
    "Nuovo_Elemento": "Add new item",
    "Obbligatorio": "Obligatory",
    "of": "of",
    "Ok": "Okay",
    "or": "Or",
    "Ordina": "Sort",
    "Page": "Page",
    "Privata": "Private",
    "Pubblica": "Public",
    "PulisciFiltri": "Clean Filter",
    "RemoveAllItems": "Remove all items",
    "Ricerca": "Search",
    "Salva": "Save",
    "SalvaPersonalizzazioni": "Save Customizations",
    "SalvaPredefinita": "The Basic view is not editable. To customize, create a new view",
    "Save_Changes": "Save Changes",
    "ScegliUnaVista": "Select a view",
    "ScegliUnaVistaCaption": "Choose a view",
    "Select_All": "Select all",
    "SoleDeletionConfirmation": "Are you sure you want to delete the selected item?",
    "Somma_Totale_Abbr": "Total:",
    "SonoStatiRilevatiISeguentiErrori_": "The following errors were detected:",
    "SpecieObbligatoria": "Mandatory species",
    "TotaleXElementi": "Total: {count} items",
    "Tutti": "All",
    "VarietàObbligatoria": "Mandatory variety",
    "VistaCancellata": "View was successfully deleted.",
    "VisteSalvate": "Views successfully saved."
};

const ptTranslations = {
    "A": "PARA",
    "Aggiungi": "adicionar",
    "AggiungiElemento": "Adicionar Item",
    "AltreAzioni": "Outras ações",
    "and": "E",
    "Annulla": "Cancelar",
    "Annulla_Modifiche": "Desfazer mudanças",
    "Applica_Modifiche": "Aplicar",
    "Base": "Básica",
    "BasicFilters": "Basic Filters",
    "Campo": "Campo",
    "Cancella": "Cancelar",
    "CancellaPersonalizzazioni": "Limpar personalizações",
    "Caricamento": "Loading...",
    "Conferma": "Ele confirma",
    "Conteggio_Totale": "Contagem total:",
    "DA": "De",
    "DataNonCoerente": "Data inconsistente",
    "DestinazioneDUsoObbligatoria": "Uso pretendido obrigatório",
    "Dettagli": "Detalhes",
    "Edit": "Editar",
    "EditVistaPubblicaWarning": "Você não tem permissão para editar visualizações públicas!",
    "eq": "Igual a",
    "Errore_": "Erro",
    "Export_Excel": "Exportar para Excel",
    "Export_PDF": "Exportar para PDF",
    "ExtendedFilters": "Extended Filters",
    "grpEmptyMsg": "Arraste o cabeçalho de uma coluna e solte-o aqui para agrupar os dados por essa coluna",
    "gt": "Maior um",
    "gte": "Melhor que ou igual a",
    "Informazioni": "Informações",
    "InfoViste": "Defina os filtros desejados e crie uma nova visualização escrevendo o título no campo ao lado ou salve a visualização atual clicando no botão à direita.",
    "isnotnull": "Não é igual a nulo",
    "isnull": "É igual a nulo",
    "loading": "Loading",
    "lt": "Menor que",
    "lte": "Menos que ou igual a",
    "Massimo": "Máximo:",
    "Media": "Média:",
    "MenuAgendaActivityDeletionWBrogliaccio": "O cancelamento da agenda resultará no cancelamento do plano relacionado.",
    "Minimo": "Mínimo:",
    "Modifica": "Modificaçao",
    "MultipleDeletionConfirmation": "Tem certeza de que deseja excluir {0} itens?",
    "neq": "Não é igual a",
    "No_Dati": "Nenhum dado encontrado",
    "NuovaSchedaRapida": "Nova linha",
    "Nuovo_Elemento": "adicionar",
    "Obbligatorio": "Obrigatório",
    "of": "De",
    "Ok": "OK",
    "or": "OU",
    "Ordina": "Ordene",
    "Page": "Página",
    "PartitaIvaGiàInserita": "Número de IVA já inserido",
    "Privata": "Privado",
    "Pubblica": "Pública",
    "PulisciFiltri": "Filtros limpos",
    "RemoveAllItems": "Remover todos os itens",
    "Ricerca": "Pesquisar",
    "Salva": "Salvar",
    "SalvaPersonalizzazioni": "Salvar personalizações",
    "SalvaPredefinita": "A vista Básica não é modificável. Para personalizar, crie uma nova vista.",
    "Save_Changes": "Salvar alterações",
    "ScegliUnaVista": "Personalizações de grade:",
    "ScegliUnaVistaCaption": "Escolha uma visualização",
    "Select_All": "Select all",
    "SoleDeletionConfirmation": "Tem certeza de que deseja excluir o item selecionado?",
    "Somma_Totale_Abbr": "Total:",
    "SonoStatiRilevatiISeguentiErrori_": "Os seguintes erros foram detectados:",
    "SpecieObbligatoria": "Espécies obrigatórias",
    "TotaleXElementi": "Total: {count} itens",
    "Tutti": "Todos",
    "VarietàObbligatoria": "Variedade obrigatória",
    "VistaCancellata": "A visão foi apagada.",
    "VisteSalvate": "Views successfully saved."
};

const frTranslations = {
    "A": "À",
    "Aggiungi": "Ajouté",
    "AggiungiElemento": "Ajouter un article",
    "AltreAzioni": "Autres actions",
    "and": "ET",
    "Annulla": "Annuler",
    "Annulla_Modifiche": "Annuler les changements",
    "Applica_Modifiche": "Appliquer",
    "Base": "Basique",
    "BasicFilters": "Filtres de base",
    "Campo": "Champ",
    "Cancella": "Annuler",
    "CancellaPersonalizzazioni": "Effacer les personnalisations",
    "Caricamento": "Chargement...",
    "Conferma": "Confirme",
    "Conteggio_Totale": "Le compte total:",
    "DA": "De",
    "DataNonCoerente": "Date incohérente",
    "DestinazioneDUsoObbligatoria": "Utilisation prévue obligatoire",
    "Dettagli": "Détails",
    "Edit": "Modifier",
    "EditVistaPubblicaWarning": "Vous n'êtes pas autorisé à modifier les vues publiques !",
    "eq": "Égal à",
    "Errore_": "Erreur",
    "Export_Excel": "Exporter vers Excel",
    "Export_PDF": "Exporter au format PDF",
    "ExtendedFilters": "Filtres étendus",
    "grpEmptyMsg": "Faites glisser un en-tête de colonne et déposez-le ici pour regrouper les données par cette colonne",
    "gt": "Un majeur",
    "gte": "Plus grand ou égal à",
    "Informazioni": "Information",
    "InfoViste": "Définissez les filtres souhaités et créez une nouvelle vue en écrivant le titre dans le champ à côté ou enregistrez la vue actuelle en cliquant sur le bouton à droite.",
    "isnotnull": "Ce n'est pas égal à null",
    "isnull": "Il est égal à nul",
    "loading": "Chargement",
    "lt": "Moins que",
    "lte": "Inférieur ou égal à",
    "Massimo": "Maximum:",
    "Media": "Moyenne:",
    "MenuAgendaActivityDeletionWBrogliaccio": "L’annulation de l’ordre du jour entraînera l’annulation du plan y afférent.",
    "Minimo": "Le minimum:",
    "Modifica": "Modifier",
    "MultipleDeletionConfirmation": "Êtes-vous sûr de vouloir supprimer {0} éléments ?",
    "neq": "Pas égal à",
    "No_Dati": "Aucune donnée disponible",
    "NuovaSchedaRapida": "Nouvelle rangée",
    "Nuovo_Elemento": "ajouter",
    "Obbligatorio": "Obligatoire",
    "of": "De",
    "Ok": "D'accord",
    "or": "OU",
    "Ordina": "Commande",
    "Page": "Page",
    "PartitaIvaGiàInserita": "Numéro de TVA déjà renseigné",
    "Privata": "Privé",
    "Pubblica": "Publique",
    "PulisciFiltri": "Nettoyer les filtres",
    "RemoveAllItems": "Supprimer tous les éléments",
    "Ricerca": "Recherche",
    "Salva": "Sauvegarder",
    "SalvaPersonalizzazioni": "Enregistrer les personnalisations",
    "SalvaPredefinita": "La vue Basique n'est pas modifiable. Pour personnaliser, créez une nouvelle vue.",
    "Save_Changes": "Sauvegarder les modifications",
    "ScegliUnaVista": "Personnalisations de la grille :",
    "ScegliUnaVistaCaption": "Choisissez une vue",
    "Select_All": "Tout sélectionner",
    "SoleDeletionConfirmation": "Êtes-vous sûr de vouloir supprimer l'élément sélectionné ?",
    "Somma_Totale_Abbr": "Total:",
    "SonoStatiRilevatiISeguentiErrori_": "Les erreurs suivantes ont été détectées :",
    "SpecieObbligatoria": "Espèces obligatoires",
    "TotaleXElementi": "Total : {count} éléments",
    "Tutti": "Tous",
    "VarietàObbligatoria": "Variété obligatoire",
    "VistaCancellata": "La vue a été effacée.",
    "VisteSalvate": "Les vues ont été enregistrées."
};

const giasGridTranslocoLoader = (lang) => {
    // These are not loaded using http because we will be inside the node modules folder
    // and the http client will not be able to find the files
    if (lang === 'it') {
        return itTranslations;
    }
    if (lang === 'en') {
        return enTranslations;
    }
    if (lang === 'pt') {
        return ptTranslations;
    }
    if (lang === 'fr') {
        return frTranslations;
    }
    return {};
};
class GiasKendoGridModule {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: GiasKendoGridModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
    static ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "19.2.9", ngImport: i0, type: GiasKendoGridModule, declarations: [GiasKendoGridComponent,
            ToolbarColumnMenuComponent,
            KendoGridCustomColumnDirective,
            GridDateTimeComponent,
            GridNumericComponent,
            CellTypePipe,
            CellDropdownNamePipe,
            CellMultiDropdownNamePipe,
            GroupHeaderNamePipe,
            GridMultiDropdownComponent,
            GridDropdownListComponent,
            MultiCheckFilterComponent,
            ShortenPipe,
            GridCustomizationsComponent,
            CustomizationDropdownComponent,
            AggregateTypePipe,
            StringToDatePipe,
            FormatNumberPipe,
            FilterTypePipe,
            PopupAnchorDirective,
            SafePipe,
            GridCustomComponent,
            DateRangeFilterComponent,
            DynamicInputComponent,
            GridBooleanComponent,
            ListviewComponent], imports: [A11yModule,
            ClipboardModule,
            CdkStepperModule,
            CdkTableModule,
            CdkTreeModule,
            DragDropModule,
            CommonModule,
            GridModule,
            PDFModule,
            ExcelModule,
            PDFModule,
            DropDownsModule,
            LabelModule,
            ButtonsModule,
            InputsModule,
            LayoutModule,
            DateInputsModule,
            FormsModule,
            ReactiveFormsModule,
            PortalModule,
            ScrollingModule,
            MenusModule,
            FontAwesomeModule,
            TooltipModule,
            NavigationModule,
            TreeViewModule,
            HttpClientModule,
            HttpClientJsonpModule,
            ScrollingModule,
            ScrollingModule$1,
            DateRangeModule,
            ListViewModule,
            RouterModule,
            TranslocoModule,
            GiasUikitModule], exports: [GiasKendoGridComponent,
            ToolbarColumnMenuComponent,
            KendoGridCustomColumnDirective,
            GridDateTimeComponent,
            GridNumericComponent,
            CellTypePipe,
            CellDropdownNamePipe,
            CellMultiDropdownNamePipe,
            GroupHeaderNamePipe,
            GridMultiDropdownComponent,
            GridDropdownListComponent,
            MultiCheckFilterComponent,
            ShortenPipe,
            GridCustomizationsComponent,
            CustomizationDropdownComponent,
            AggregateTypePipe,
            StringToDatePipe,
            FormatNumberPipe,
            FilterTypePipe,
            PopupAnchorDirective,
            SafePipe,
            GridCustomComponent,
            DateRangeFilterComponent,
            DynamicInputComponent,
            GridBooleanComponent,
            ListviewComponent] });
    static ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: GiasKendoGridModule, imports: [A11yModule,
            ClipboardModule,
            CdkStepperModule,
            CdkTableModule,
            CdkTreeModule,
            DragDropModule,
            CommonModule,
            GridModule,
            PDFModule,
            ExcelModule,
            PDFModule,
            DropDownsModule,
            LabelModule,
            ButtonsModule,
            InputsModule,
            LayoutModule,
            DateInputsModule,
            FormsModule,
            ReactiveFormsModule,
            PortalModule,
            ScrollingModule,
            MenusModule,
            FontAwesomeModule,
            TooltipModule,
            NavigationModule,
            TreeViewModule,
            HttpClientModule,
            HttpClientJsonpModule,
            ScrollingModule,
            ScrollingModule$1,
            DateRangeModule,
            ListViewModule,
            RouterModule,
            TranslocoModule,
            GiasUikitModule] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: GiasKendoGridModule, decorators: [{
            type: NgModule,
            args: [{
                    declarations: [
                        GiasKendoGridComponent,
                        ToolbarColumnMenuComponent,
                        KendoGridCustomColumnDirective,
                        GridDateTimeComponent,
                        GridNumericComponent,
                        CellTypePipe,
                        CellDropdownNamePipe,
                        CellMultiDropdownNamePipe,
                        GroupHeaderNamePipe,
                        GridMultiDropdownComponent,
                        GridDropdownListComponent,
                        MultiCheckFilterComponent,
                        ShortenPipe,
                        GridCustomizationsComponent,
                        CustomizationDropdownComponent,
                        AggregateTypePipe,
                        StringToDatePipe,
                        FormatNumberPipe,
                        FilterTypePipe,
                        PopupAnchorDirective,
                        SafePipe,
                        GridCustomComponent,
                        DateRangeFilterComponent,
                        DynamicInputComponent,
                        GridBooleanComponent,
                        ListviewComponent,
                    ],
                    exports: [
                        GiasKendoGridComponent,
                        ToolbarColumnMenuComponent,
                        KendoGridCustomColumnDirective,
                        GridDateTimeComponent,
                        GridNumericComponent,
                        CellTypePipe,
                        CellDropdownNamePipe,
                        CellMultiDropdownNamePipe,
                        GroupHeaderNamePipe,
                        GridMultiDropdownComponent,
                        GridDropdownListComponent,
                        MultiCheckFilterComponent,
                        ShortenPipe,
                        GridCustomizationsComponent,
                        CustomizationDropdownComponent,
                        AggregateTypePipe,
                        StringToDatePipe,
                        FormatNumberPipe,
                        FilterTypePipe,
                        PopupAnchorDirective,
                        SafePipe,
                        GridCustomComponent,
                        DateRangeFilterComponent,
                        DynamicInputComponent,
                        GridBooleanComponent,
                        ListviewComponent,
                    ],
                    imports: [
                        A11yModule,
                        ClipboardModule,
                        CdkStepperModule,
                        CdkTableModule,
                        CdkTreeModule,
                        DragDropModule,
                        CommonModule,
                        GridModule,
                        PDFModule,
                        ExcelModule,
                        PDFModule,
                        DropDownsModule,
                        LabelModule,
                        ButtonsModule,
                        InputsModule,
                        LayoutModule,
                        DateInputsModule,
                        FormsModule,
                        ReactiveFormsModule,
                        PortalModule,
                        ScrollingModule,
                        MenusModule,
                        FontAwesomeModule,
                        TooltipModule,
                        NavigationModule,
                        TreeViewModule,
                        HttpClientModule,
                        HttpClientJsonpModule,
                        ScrollingModule,
                        ScrollingModule$1,
                        DateRangeModule,
                        ListViewModule,
                        RouterModule,
                        TranslocoModule,
                        GiasUikitModule
                    ],
                    providers: []
                }]
        }] });

class CommonFunctionsService {
    static getOrigins() {
        if (window.location.origin.indexOf("localhost") > -1) {
            return '*';
        }
        else {
            return window.location.origin;
        }
    }
    static isJSON(str) {
        if (/^\s*$/.test(str))
            return false;
        str = str.replace(/\\(?:["\\\/bfnrt]|u[0-9a-fA-F]{4})/g, '@');
        str = str.replace(/"[^"\\\n\r]*"|true|false|null|-?\d+(?:\.\d*)?(?:[eE][+\-]?\d+)?/g, ']');
        str = str.replace(/(?:^|:|,)(?:\s*\[)+/g, '');
        return (/^[\],:{}\s]*$/).test(str);
    }
}
;

class CoreWS_GenericPayload {
    obj;
    constructor(obj) {
        this.obj = obj;
    }
}
class CoreWS_Generic extends CoreWS_GenericPayload {
    InData;
    constructor(objP, InData) {
        super(objP);
        this.InData = InData;
    }
}
class CoreWS_GenericObjP {
    objP_super_server;
    objP_server;
    objP_utenti;
}
class AjaxAgronicaService {
    http;
    giasMasterService;
    conversionService;
    giasDialogService;
    constructor(http, giasMasterService, conversionService, giasDialogService) {
        this.http = http;
        this.giasMasterService = giasMasterService;
        this.conversionService = conversionService;
        this.giasDialogService = giasDialogService;
    }
    ajaxAgronicaCoreWS_Promise(url, parametri, setLoading = true, showErroriGestiti = true) {
        console.error('La funzione ha chiamato direttamente i CoreWS (' + url + '), ritornando una Promise. Da cambiare in una chiamata WebAPI!');
        return this.ajaxPost(url, parametri, true, setLoading, showErroriGestiti);
    }
    ajaxCoreWSPost(url, parametri, setLoading = true, compressione = true, showErroriGestiti = true) {
        console.error('La funzione ha eseguito una chiamata Post sui CoreWS (' + url + '). Da cambiare in una chiamata WebAPI!');
        return this.ajaxPost(url, parametri, false, setLoading, compressione, showErroriGestiti);
    }
    ajaxAgronica(url, parametri, compressione = true, showErroriGestiti = true) {
        const httpOptions = {
            headers: new HttpHeaders({
                'Content-Type': 'application/json',
                'x-compressione': compressione.toString()
            })
        };
        return lastValueFrom(this.http.post(url, JSON.stringify(parametri), httpOptions)
            .pipe(catchError((err) => {
            return this.errorHandling(err);
        }), map((r) => {
            const resp = r.d;
            return resp;
        }), map((val) => {
            return this.decomprimi(val);
        }), map(resp => {
            if (resp.RispostaOK === false) {
                this.rispostaOK_FalseHandling(resp, showErroriGestiti);
                return resp;
            }
            return resp;
        })));
    }
    ajaxAgronicaObs(url, parametri, compressione = true, showErroriGestiti = true) {
        const httpOptions = {
            headers: new HttpHeaders({
                'Content-Type': 'application/json',
                'x-compressione': compressione.toString()
            })
        };
        return this.http.post(url, JSON.stringify(parametri), httpOptions)
            .pipe(catchError((err) => {
            return this.errorHandling(err);
        }), map((r) => {
            const resp = r.d;
            return resp;
        }), map((val) => {
            return this.decomprimi(val);
        }), map(r => {
            const resp = r;
            if (resp.RispostaOK === false) {
                return this.rispostaOK_FalseHandling(resp, showErroriGestiti);
            }
            return resp;
        }));
    }
    ajaxAgronicaG(url, parametri, compressione = true, showErroriGestiti = true) {
        const httpOptions = {
            headers: new HttpHeaders({
                'Content-Type': 'application/json',
                'x-compressione': compressione.toString()
            })
        };
        return lastValueFrom(this.http.post(url, JSON.stringify(parametri), httpOptions)
            .pipe(catchError((err) => {
            return this.errorHandling(err);
        }), map((r) => {
            const resp = r.d;
            return resp;
        }), map((val) => {
            return this.decomprimi(val);
        }), map(r => {
            const resp = r;
            if (resp.RispostaOK === false) {
                return this.rispostaOK_FalseHandling(resp, showErroriGestiti);
            }
            return r;
        }), map((r) => {
            const obj = r.RispostaStringa;
            this.conversionService.ConversionDateInObject(obj);
            this.conversionService.remove__type(obj);
            return r;
        })));
    }
    /**
   * Per le chiamate utilizzando codice vecchio non ancora adattato alla
   * nuova modalità di caricare i dati (tramite RispostaStandard generic).
   * @param url Endpoint.
   * @param parametri I parametri che compaiono nella testata della chiamata.
   * @returns il risultato della chiamata http.
   */
    legacy_get(url, parametri, displayErrorMessage = true, compressione = true) {
        const httpOptions = {
            headers: new HttpHeaders({
                'Content-Type': 'application/json',
                'x-compressione': compressione.toString()
            })
        };
        return this.http.post(url, JSON.stringify(parametri), httpOptions)
            .pipe(catchError((err) => {
            return this.errorHandling(err);
        }), map((r) => {
            const resp = r.d;
            return resp;
        }), map((val) => {
            return this.decomprimi(val);
        }), map(r => {
            const resp = r;
            if (resp.RispostaOK === false && displayErrorMessage) {
                return this.rispostaOK_FalseHandling(resp, displayErrorMessage).pipe(take$1(1), map((val) => {
                    return val;
                }));
            }
            return r;
        }));
    }
    post(url, parametri, compressione = true, gestisciErrore = true, showErroriGestiti = true) {
        const httpOptions = {
            headers: new HttpHeaders({
                'Content-Type': 'application/json',
                'x-compressione': compressione.toString()
            })
        };
        return this.http.post(url, JSON.stringify(parametri), httpOptions)
            .pipe(catchError((err) => {
            return this.errorHandling(err);
        }), map((r) => {
            const resp = r.d;
            return resp;
        }), map((val) => {
            return this.decomprimi(val);
        }), map(r => {
            const resp = r;
            if (resp.RispostaOK === false && !resp.RispostaConferma && gestisciErrore) {
                return this.rispostaOK_FalseHandling(resp, showErroriGestiti);
            }
            return r;
        })).pipe(map((r) => {
            const obj = r.RispostaStringa;
            this.conversionService.ConversionDateInObject(obj);
            this.conversionService.remove__type(obj);
            return r;
        }));
    }
    ajaxAgronicaCoreWS_GenericsObs(url, parametri, compressione = true, showErroriGestiti = true) {
        const httpOptions = {
            headers: new HttpHeaders({
                'Content-Type': 'application/json',
                'x-compressione': compressione.toString()
            })
        };
        console.error('La funzione ha chiamato direttamente i CoreWS (' + url + '), ritornando un Observable. Da cambiare in una chiamata WebAPI!');
        const p1 = { InData: parametri };
        return this.ajaxCoreWSPost(url, parametri, false, compressione, showErroriGestiti);
    }
    ajaxCoreWSGet(url, showErroriGestiti = true) {
        this.giasMasterService.set_isLoading({
            isLoading: true,
            message: 'Caricamento in corso'
        });
        const httpOptions = {
            headers: new HttpHeaders({
                'Content-Type': 'application/json',
            })
        };
        return this.http.get(url, httpOptions)
            .pipe(catchError((err) => {
            return this.errorHandling(err);
        }), map(r => {
            const resp = r.d;
            if (resp.RispostaOK === false) {
                return this.rispostaOK_FalseHandling(resp, showErroriGestiti);
            }
            return r.d;
        }));
    }
    ajaxPost(url, parametri, returnPromise = true, setLoading = true, compressione = true, showErroriGestiti = true) {
        if (setLoading) {
            this.giasMasterService.set_isLoading({
                isLoading: true,
                message: 'Caricamento in corso'
            });
        }
        // let headers = new Headers();
        // headers.append('Content-Type', 'application/json');
        // headers.append('x-compressione', compressione.toString());
        const httpOptions = {
            headers: new HttpHeaders({
                'Content-Type': 'application/json',
                'x-compressione': compressione.toString()
            })
        };
        const p1 = { InData: parametri };
        // this.conversionService.remove__type(p1);
        const risposta = this.http.post(url, JSON.stringify(p1), httpOptions)
            .pipe(catchError((err) => {
            return this.errorHandling(err);
        }), map((r) => {
            const resp = r.d;
            return resp;
        }), map((val) => {
            return this.decomprimi(val);
        }), map(resp => {
            if (resp.RispostaOK === false) {
                this.rispostaOK_FalseHandling(resp, showErroriGestiti);
                return resp;
            }
            return resp;
        })).pipe(map((r) => {
            if (r.RispostaOK === true || r.RispostaStringa) {
                let obj = r.RispostaStringa;
                if (typeof r.RispostaStringa == 'string' && r.RispostaStringa != "" && CommonFunctionsService.isJSON(r.RispostaStringa)) {
                    obj = JSON.parse(r.RispostaStringa);
                }
                this.conversionService.ConversionDateInObject(obj);
                this.conversionService.remove__type(obj);
                r.RispostaStringa = obj;
                if (setLoading) {
                    this.giasMasterService.set_isLoading({ isLoading: false, message: '' });
                }
                return r;
            }
            else {
                return r;
            }
        }));
        if (returnPromise) {
            return risposta.toPromise();
        }
        else {
            return risposta;
        }
    }
    errorHandling(error) {
        let messaggio = "statusText:" + error.statusText + " - url:" + error.url;
        if (error.error) {
            messaggio += " error: " + JSON.stringify(error.error);
        }
        this.giasMasterService.changeErrorMsgType({ show: true, msg: error.statusText, errorNumber: error.status });
        return of(new Error(messaggio));
    }
    rispostaOK_FalseHandling(r, showErroriGestiti) {
        this.giasMasterService.set_isLoading({ isLoading: false, message: '' });
        if (r.ErroriGias && r.ErroriGias.length > 0) {
            const erroriNonGestiti = r.ErroriGias.filter((e) => e.tipo == enum_ErroreGias_Tipo.NonGestito);
            this.handleErrori_NonGestiti(erroriNonGestiti);
            if (showErroriGestiti) {
                const erroriGestiti = r.ErroriGias.filter((e) => e.tipo != enum_ErroreGias_Tipo.NonGestito);
                this.handleErrori_Gestiti(erroriGestiti);
            }
        }
        else {
            this.giasMasterService.changeErrorMsgType({ show: true, msg: r.Errore, errorNumber: 500 });
        }
        return of(new Error(JSON.stringify(r)));
    }
    handleErrori_NonGestiti(errori) {
        errori.forEach((e) => {
            this.giasMasterService.changeErrorMsgType({ show: true, msg: e.messaggio, errorNumber: 500 });
        });
    }
    handleErrori_Gestiti(errori) {
        const bloccanti = errori.filter((e) => e.severity == ErroreGias_Severity.Bloccante);
        bloccanti.forEach((e) => {
            this.giasDialogService.baseError('', e.messaggio);
        });
        const warning = errori.filter((e) => e.severity == ErroreGias_Severity.Bloccante);
        const info = errori.filter((e) => e.severity == ErroreGias_Severity.Bloccante);
    }
    decomprimi(r) {
        if (r && r?.Compressa) {
            if (r.RispostaCompressa !== undefined && r.RispostaCompressa !== null && r.RispostaCompressa.length > 0) {
                r.RispostaStringa = inflate(r.RispostaCompressa, { to: 'string' });
                r.RispostaCompressa = null;
            }
        }
        return r;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: AjaxAgronicaService, deps: [{ token: i1$3.HttpClient }, { token: GIAS_MASTER_SERVICE_TOKEN }, { token: i2$1.ConversionService }, { token: i2$1.GiasDialogService }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: AjaxAgronicaService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: AjaxAgronicaService, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }], ctorParameters: () => [{ type: i1$3.HttpClient }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [GIAS_MASTER_SERVICE_TOKEN]
                }] }, { type: i2$1.ConversionService }, { type: i2$1.GiasDialogService }] });

class DynamicOverlayContainer extends OverlayContainer {
    setContainerElement(containerElement) {
        this._containerElement = containerElement;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: DynamicOverlayContainer, deps: null, target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: DynamicOverlayContainer, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: DynamicOverlayContainer, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }] });

class DynamicOverlay extends Overlay {
    _dynamicOverlayContainer;
    renderer;
    constructor(scrollStrategies, _overlayContainer, _componentFactoryResolver, _positionBuilder, _keyboardDispatcher, _injector, _ngZone, _document, _directionality, rendererFactory, _location, _outsideClickDispatcher) {
        super(scrollStrategies, _overlayContainer, _componentFactoryResolver, _positionBuilder, _keyboardDispatcher, _injector, _ngZone, _document, _directionality, _location, _outsideClickDispatcher);
        this.renderer = rendererFactory.createRenderer(null, null);
        this._dynamicOverlayContainer = _overlayContainer;
    }
    setContainerElement(containerElement) {
        this.renderer.setStyle(containerElement, 'transform', 'translateZ(0)');
        this._dynamicOverlayContainer.setContainerElement(containerElement);
    }
    createWithDefaultConfig(containerElement) {
        this.setContainerElement(containerElement);
        return super.create({
            positionStrategy: this.position()
                .global()
                .centerHorizontally()
                .centerVertically(),
            hasBackdrop: true
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: DynamicOverlay, deps: [{ token: i1$4.ScrollStrategyOptions }, { token: DynamicOverlayContainer }, { token: i0.ComponentFactoryResolver }, { token: i1$4.OverlayPositionBuilder }, { token: i1$4.OverlayKeyboardDispatcher }, { token: i0.Injector }, { token: i0.NgZone }, { token: DOCUMENT }, { token: i3$1.Directionality }, { token: i0.RendererFactory2 }, { token: i3.Location }, { token: i1$4.OverlayOutsideClickDispatcher }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: DynamicOverlay, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: DynamicOverlay, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1$4.ScrollStrategyOptions }, { type: DynamicOverlayContainer }, { type: i0.ComponentFactoryResolver }, { type: i1$4.OverlayPositionBuilder }, { type: i1$4.OverlayKeyboardDispatcher }, { type: i0.Injector }, { type: i0.NgZone }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [DOCUMENT]
                }] }, { type: i3$1.Directionality }, { type: i0.RendererFactory2 }, { type: i3.Location }, { type: i1$4.OverlayOutsideClickDispatcher }] });

class SetDataItemPipe {
    privateService;
    constructor(privateService) {
        this.privateService = privateService;
    }
    transform(dataItem) {
        this.privateService.setDataItem(dataItem);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: SetDataItemPipe, deps: [{ token: KendoGridService }], target: i0.ɵɵFactoryTarget.Pipe });
    static ɵpipe = i0.ɵɵngDeclarePipe({ minVersion: "14.0.0", version: "19.2.9", ngImport: i0, type: SetDataItemPipe, isStandalone: false, name: "update-data-item" });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: SetDataItemPipe, decorators: [{
            type: Pipe,
            args: [{
                    standalone: false,
                    name: 'update-data-item'
                }]
        }], ctorParameters: () => [{ type: KendoGridService }] });

const gridPubServiceFactory = (function () {
    let index = 0;
    return (resolver) => {
        // console.log(index);
        const pubs = new GridPublicService(resolver);
        pubs.multiIndex = index;
        index++;
        return pubs;
    };
})();
function generateGridProviders(configService, gridParent, gridMasterDetail = null) {
    let gridConfigs = [];
    let pubServices = [];
    let privServices = [];
    let gridMasterServices = [];
    if (Array.isArray(configService)) {
        gridConfigs = getGridConfigs(configService);
        pubServices = getPubServices(configService.length);
        privServices = getPrivateServices(configService.length);
    }
    else {
        gridConfigs.push({
            provide: GRID_HTTP_TOKEN,
            useClass: configService
        });
        pubServices.push({
            provide: GridPublicService,
        });
        privServices.push({
            provide: KendoGridService,
        });
    }
    if (gridMasterDetail) {
        gridMasterServices.push({
            provide: KendoGridMasterDetailService
        });
    }
    const fatherComponent = {
        provide: GridParentComponent,
        useExisting: forwardRef(() => gridParent)
    };
    return [
        ...gridConfigs,
        fatherComponent,
        ...privServices,
        ...pubServices,
        ...gridMasterServices,
        GridErrorService,
        { provide: LOADING_TOKEN, useClass: LoadingService },
    ];
}
function getGridConfigs(configService) {
    const result = [];
    configService.forEach((config) => {
        result.push({
            provide: GRID_HTTP_TOKEN,
            useClass: config,
            multi: true
        });
    });
    return result;
}
function getPrivateServices(count) {
    const result = [];
    for (let i = 0; i < count; ++i) {
        result.push({
            provide: KendoGridService,
            multi: true
        });
    }
    return result;
}
function getPubServices(num) {
    const result = [];
    for (let i = 0; i < num; i++) {
        result.push({
            provide: GridPublicService,
            useFactory: gridPubServiceFactory,
            multi: true,
            deps: [[new Optional()], ActivatedRoute]
        });
    }
    return result;
}

class DataValidator {
    MINDATE;
    MAXDATE;
    constructor(MINDATE = AGRODATAINIZIO, MAXDATE = AGRODATAFINE) {
        this.MINDATE = MINDATE;
        this.MAXDATE = MAXDATE;
    }
    validate(control) {
        let error = null;
        if (!control.value) {
            error = { valid: false };
        }
        else {
            if (this.MINDATE && control.value <= this.MINDATE) {
                error = { valid: false };
            }
            if (this.MAXDATE && control.value >= this.MAXDATE) {
                error = { valid: false };
            }
        }
        return error;
    }
}

var UtilityFunctions;
(function (UtilityFunctions) {
    //Permette di nascondere o meno degli elementi Html
    function setStyle(renderer, parent, selector, name, value) {
        let elem = parent.querySelector(selector);
        if (elem) {
            renderer.setStyle(elem, name, value);
        }
    }
    UtilityFunctions.setStyle = setStyle;
    function setStyleAll(renderer, parent, selector, name, value) {
        let elems = parent.querySelectorAll(selector);
        if (elems) {
            for (let elem of elems) {
                renderer.setStyle(elem, name, value);
            }
        }
    }
    UtilityFunctions.setStyleAll = setStyleAll;
    function addClass(renderer, parent, selector, name) {
        let elem = parent.querySelector(selector);
        if (elem) {
            renderer.addClass(elem, name);
        }
    }
    UtilityFunctions.addClass = addClass;
    function hideElem(renderer, parent, selector) {
        UtilityFunctions.setStyle(renderer, parent, selector, 'display', 'none');
    }
    UtilityFunctions.hideElem = hideElem;
    function showElem(renderer, parent, selector) {
        UtilityFunctions.setStyle(renderer, parent, selector, 'display', 'block');
    }
    UtilityFunctions.showElem = showElem;
    function compareObjects(o, p) {
        let i, keysO = Object.keys(o).sort((a, b) => a.localeCompare(b)), keysP = Object.keys(p).sort((a, b) => a.localeCompare(b));
        if (keysO.length !== keysP.length) {
            return false;
        } // not the same nr of keys
        if (keysO.join('') !== keysP.join('')) {
            return false;
        } // different keys
        for (i = 0; i < keysO.length; ++i) {
            if (o[keysO[i]] instanceof Array) {
                if (!(p[keysO[i]] instanceof Array)) {
                    return false;
                }
                // if (compareObjects(o[keysO[i]], p[keysO[i]] === false) return false
                // would work, too, and perhaps is a better fit, still, this is easy, too
                if (p[keysO[i]].sort().join('') !== o[keysO[i]].sort().join('')) {
                    return false;
                }
            }
            else if (o[keysO[i]] instanceof Date) {
                if (!(p[keysO[i]] instanceof Date)) {
                    return false;
                }
                if (('' + o[keysO[i]]) !== ('' + p[keysO[i]])) {
                    return false;
                }
            }
            else if (o[keysO[i]] instanceof Function) {
                if (!(p[keysO[i]] instanceof Function)) {
                    return false;
                }
                // ignore functions, or check them regardless?
            }
            else if (o[keysO[i]] instanceof Object) {
                if (!(p[keysO[i]] instanceof Object)) {
                    return false;
                }
                if (o[keysO[i]] === o) { // self reference?
                    if (p[keysO[i]] !== p) {
                        return false;
                    }
                }
                else if (compareObjects(o[keysO[i]], p[keysO[i]]) === false) {
                    return false;
                } // WARNING: does not deal with circular refs other than ^^
            }
            if (o[keysO[i]] !== p[keysO[i]]) // change !== to != for loose comparison
             {
                return false;
            } // not the same value
        }
        return true;
    }
    UtilityFunctions.compareObjects = compareObjects;
    function clearFormArray(formArray) {
        while (formArray.length !== 0) {
            formArray.removeAt(0);
        }
    }
    UtilityFunctions.clearFormArray = clearFormArray;
    function distinctArrayValues(array, fields) {
        const retArray = new Array();
        array.forEach((arrayEl) => {
            let arrayApp = { ...retArray };
            fields.forEach((field) => {
                arrayApp = arrayApp.filter((el) => {
                    return el[field] == arrayEl[field];
                });
            });
            if (arrayApp.length == 0) {
                retArray.push(arrayEl);
            }
        });
        return [];
    }
    UtilityFunctions.distinctArrayValues = distinctArrayValues;
    function GetListofPropertyinArrayObject(input_array, property) {
        let output_array = input_array;
        if (output_array !== null && output_array !== undefined) {
            let properties = property.split(".");
            for (let i = 0; i < properties.length; i++) {
                if (output_array === null || output_array === undefined)
                    break;
                output_array = output_array.map(x => x[properties[i]]);
            }
        }
        return output_array;
    }
    UtilityFunctions.GetListofPropertyinArrayObject = GetListofPropertyinArrayObject;
    function GetValueofPropertyinObject(input, property) {
        if (input !== null && input !== undefined) {
            let properties = property.split(".");
            for (let i = 0; i < properties.length; i++) {
                if (input === null || input === undefined)
                    break;
                input = input[properties[i]];
            }
        }
        return input;
    }
    UtilityFunctions.GetValueofPropertyinObject = GetValueofPropertyinObject;
    function forbiddenDdlValidator(control) {
        if (control.value.codice == undefined || control.value.codice == -1 || control.value.codice == 0) {
            return { 'ddlNotSet': true };
        }
        return null;
    }
    UtilityFunctions.forbiddenDdlValidator = forbiddenDdlValidator;
})(UtilityFunctions || (UtilityFunctions = {}));

class DropDownValidator {
    ValuePrimitive;
    valuefield;
    constructor(ValuePrimitive, valuefield = "codice") {
        this.ValuePrimitive = ValuePrimitive;
        this.valuefield = valuefield;
    }
    validate(control) {
        let error = null;
        let valuefield = this.valuefield;
        let value = control.value;
        if (!value) {
            error = { valid: false };
        }
        else {
            if (this.ValuePrimitive) {
                if (+value === 0) {
                    error = { valid: false };
                }
            }
            else {
                value = UtilityFunctions.GetValueofPropertyinObject(value, valuefield);
                if (!value ||
                    +value === 0) {
                    error = { valid: false };
                }
            }
        }
        return error;
    }
}

class MultiSelectValidator {
    ValuePrimitive;
    valuefield;
    constructor(ValuePrimitive, valuefield = "codice") {
        this.ValuePrimitive = ValuePrimitive;
        this.valuefield = valuefield;
    }
    validate(control) {
        let error = null;
        let valuefield = this.valuefield;
        let value = control.value;
        if (!value || value.length === 0) {
            error = { valid: false };
        }
        else {
            if (this.ValuePrimitive) {
                let val = value.find(v => +v === 0);
                if (!val)
                    error = { valid: false };
            }
            else {
                value = UtilityFunctions.GetListofPropertyinArrayObject(value, valuefield);
                let val = value.find(v => !value || +v === 0);
                if (val)
                    error = { valid: false };
            }
        }
        return error;
    }
}

class ValiditaValidator {
    validate(control) {
        const validita_inizio = control.get('inizio')?.value;
        const validita_fine = control.get('fine')?.value;
        if (validita_inizio > validita_fine) {
            control.get('inizio').setErrors({ 'validita': false });
            control.get('fine').setErrors({ 'validita': false });
            return { 'validita': false };
        }
        control.get('inizio')?.setErrors(null);
        control.get('fine')?.setErrors(null);
        return null;
    }
}

/*
 * Public API Surface of gias-kendo-grid
 */

/**
 * Generated bundle index. Do not edit.
 */

export { AbstractGridConfigService, AggregateSettings, AggregateTypePipe, AgrSelectableSettings, AjaxAgronicaService, BehaviorSettings, BloccaAttivitaAgendaLink, BooleanSettings, BrogliaccioServerResult, CENTRI_LNK, CellDropdownNamePipe, CellMultiDropdownNamePipe, CellTypePipe, ChiaveVista, CodiciTemplate, ColumnMenuSettings, CommandsColumnSettings, CommandsDropDownEvents, CommandsDropDownSettings, CommonFunctionsService, ConfigTemplate, CopiaOperazioneSingola, CoreWS_Generic, CoreWS_GenericObjP, CoreWS_GenericPayload, CreateRecipeData, CreateRicettaLink, CustomColumnSettings, CustomMessageComponent, CustomMessageService, CustomizationDropdownComponent, CustomizationRequest, CustomizeDropdownService, CustomizedColumnComponent, DA_GESTIRE_PIANO_DISTRIBUZIONE_CONCIMI, DA_GESTIRE_PUA, DataValidator, DateFilters, DateManager, DateRangeFilterComponent, DateSettings, DateTimeSettings, DateToString, DefaultHttpService, DefaultTemplate, DeletionMode, DettagliColumnSettings, DropDownValidator, DropdownChanged, DropdownHelper, DropdownList, DropdownListItem, DropdownListWithForm, DropdownManager, DynamicInputComponent, DynamicInputSettigs, DynamicOverlay, DynamicOverlayContainer, EditingMode, ExcelSettings, FILTER_MODES, FilterMenuType, FilterTypePipe, Filters, FiltroJSONService, FormValueChange, FormValueManager, FormatNumberPipe, GRID_HTTP_TOKEN, GRID_WORKER_URL, GeneralSettings, GenericErrors, GetCentriParams, GetCentriParams_NG, GetOperazioniParams, GetSpeciParams, GiasAggregateDescriptor, GiasKendoGridComponent, GiasKendoGridModule, GiasMessageService, GridBatchHandlerService, GridBooleanComponent, GridCommandItem, GridCustomComponent, GridCustomizations, GridCustomizationsComponent, GridCustomizationsService, GridDataDetail, GridDataWithFilter, GridDateTimeComponent, GridDetailInfo, GridDialogService, GridDropdownBase, GridDropdownListComponent, GridDropdownService, GridErrorService, GridEvent, GridInfoCommandEvent, GridMassiveEvent, GridMultiDropdownComponent, GridMultiDropdownService, GridNumericComponent, GridParentComponent, GridPublicService, GridRootHelper, GridWorkerService, GridZooResult, GroupHeaderNamePipe, GroupSettings, HttpAction, IMPIANTI_LNK, ImpostazioniApp, InCellTemplate, InLineTemplate, InMemoryView, JsonKendoResult, KendoGridColumn, KendoGridCustomColumnDirective, KendoGridMasterDetailService, KendoGridModel, KendoGridRow, KendoGridService, KendoServerResult, KendoServerResultImpl, Link_ElimOpMultipla, ListviewComponent, LoaderType, MasterDetailSettings, ModelEntry, MultiCheckFilterComponent, MultiDropdownManager, MultiSelectValidator, MulticheckInput, NextSelection, NumToStr, NumberManager, NumericSettings, OPERAZIONI_LNK, PDFSettings, PaginationSettings, PopupAnchorDirective, PopupSettingsManager, PreselectedRowsSettings, PropertyValidator, PropertyValidatorFields, QdCRow, QryParamsResolver, ReadDataFilters, RemoveMultipleRowsParams, RendererGridEvent, ResizableSettings, RibaltamentoTypes, RicettaForm, RicettaModalParams, RicettaRow, RicetteNumLink, RicetteServerResult, SLIGHTLY_DIFFERENT_CODE_FROM_GIAS2010, SPECI_LNK, SafePipe, SalvaVisteWrapper, SbloccaAttivitaAgendaLink, ScrollableScrollingOpts, ScrollableScrollingService, ScrollingMode, ScrollingModeFactory, SelectableColumnSettings, SelectableSettings, SelectedOpts, SelectionChangeEvent, SelectionSettings, ServerResult, ServerView, SetDataItemPipe, Shared, SharedManager, ShortenPipe, SortMode, SortSettings, Sortable, StringManager, StringSettings, StringToDate, StringToDatePipe, TabTypes, TableQdCLink, TemplateSettings, ToolbarColumnMenuComponent, ToolbarSettings, UtilsService, ValidValuesFor, ValiditaValidator, ViewBase, VirtualScrollingOpts, VirtualScrollingService, WorkType, ZooModel, ZooRow, _isNull, closest, columnAlreadyInView, consoleLogDebug, consoleLogDebugMultiParam, consoleLogDebugParam, construisciChiaviComposite, emun_MassiveEventType, enum_menuAgendaGridCommands, filtersManager, findMatchedIndex, generateGridProviders, getCircularReplacer$1 as getCircularReplacer, getComponentIdAndLog, getServiceIdAndLog, giasGridTranslocoLoader, gridPubServiceFactory, isBrogliaccioRow, isNullOrUndefined, isQdCRow, isUndefined, lav_cod_copiabili, lav_cod_non_editabili, logicalOperators, mapDateFilter, operators, parseServerResult, qualsiasiLogDebug, resetSelection, scrollToFirstColumn, separatoreChiaveAlbero, separatoreFiltroAlbero, serviceMap };
//# sourceMappingURL=gias-kendo-grid.mjs.map
