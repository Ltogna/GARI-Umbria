import { FilterService } from "@progress/kendo-angular-grid";
import { CompositeFilterDescriptor } from "@progress/kendo-data-query";
import { SharedManager } from "./manager";
import { KendoGridColumn } from "../../../models/grid.model";
export declare class StringManager extends SharedManager {
    protected mapFilters(descriptor: CompositeFilterDescriptor): any[];
    distinctRows: string[];
    shownData: string[];
    protected setColumn(cols: KendoGridColumn[]): void;
    map(rows: any[], ordering: (rows: any) => any | null): string[];
    textAccessor(dataItem: any): any;
    valueAccessor(dataItem: any): any;
    filter(text: string): void;
    protected parseValue(item: any): any;
    isItemSelected(item: any): boolean;
    onSelectAll(service: FilterService): void;
}
