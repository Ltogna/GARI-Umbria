import { ComponentFactoryResolver, ComponentRef, OnDestroy, OnChanges, ViewContainerRef, AfterViewInit, ChangeDetectorRef, SimpleChanges, Type } from '@angular/core';
import { FormGroup } from "@angular/forms";
import { CustomComponent } from '../../models/custom-component';
import * as i0 from "@angular/core";
export declare class GridCustomComponent implements OnDestroy, AfterViewInit, OnChanges {
    private resolver;
    private changeDetector;
    entry: ViewContainerRef;
    component: Type<CustomComponent>;
    input: any;
    field: any;
    edit: any;
    formGroup: FormGroup;
    componentRef: ComponentRef<any>;
    constructor(resolver: ComponentFactoryResolver, changeDetector: ChangeDetectorRef);
    ngOnChanges(changes: SimpleChanges): void;
    ngAfterViewInit(): void;
    private handleComponent;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<GridCustomComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GridCustomComponent, "gias-grid-custom", never, { "component": { "alias": "component"; "required": false; }; "input": { "alias": "input"; "required": false; }; "field": { "alias": "field"; "required": false; }; "edit": { "alias": "edit"; "required": false; }; "formGroup": { "alias": "formGroup"; "required": false; }; }, {}, never, never, false, never>;
}
