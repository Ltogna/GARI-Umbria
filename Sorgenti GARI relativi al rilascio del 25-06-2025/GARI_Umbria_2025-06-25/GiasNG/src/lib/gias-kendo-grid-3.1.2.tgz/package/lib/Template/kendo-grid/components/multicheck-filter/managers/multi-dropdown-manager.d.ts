import { FilterService } from "@progress/kendo-angular-grid";
import { CompositeFilterDescriptor } from "@progress/kendo-data-query";
import { DropdownListItem, KendoGridColumn } from "../../../models/grid.model";
import { MultiCheckFilterComponent } from "../multicheck-filter.component";
import { SharedManager } from "./manager";
export declare class MultiDropdownManager extends SharedManager {
    shownData: DropdownListItem[];
    distinctRows: DropdownListItem[];
    /** Definisce il tipo di Manager. Usato per determinare la modalità
     * di filtro usato nella funzione `onSelectionChange`. */
    type: string;
    constructor(that: MultiCheckFilterComponent);
    protected mapFilters(descriptor: CompositeFilterDescriptor): any[];
    protected setColumn(cols: KendoGridColumn[]): void;
    map(rows: any[], ordering: (rows: any) => any | null): DropdownListItem[];
    valueAccessor(value: DropdownListItem | string): any;
    textAccessor(dataItem: DropdownListItem): string;
    getColumn(): KendoGridColumn;
    filter(text: string): void;
    protected parseValue(item: any): any;
    isItemSelected(item: any): boolean;
    onSelectAll(service: FilterService): void;
}
