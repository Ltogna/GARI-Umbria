import { FilterService } from "@progress/kendo-angular-grid";
import { CompositeFilterDescriptor } from "@progress/kendo-data-query";
import { DropdownListItem, KendoGridColumn } from "../../../models/grid.model";
import { MulticheckInput } from "../models";
import { DateFilters } from "../utils";
import { IMultiCheckFilter } from "../multicheck-filter";
export interface IManager {
    shownData: (string | DropdownListItem | number)[];
    store: {
        [key: string]: string[];
    };
    allRows: (string | DropdownListItem | number)[];
    selectAllChecked: boolean;
    column: KendoGridColumn;
    init(inpt: Required<MulticheckInput>): any;
    initDataNoPagination(): any;
    onSelectionChange(item: any, service: any): any;
    filter(text: string | DateFilters | number): any;
    fetchNewPage(): any;
    getColumn(): any;
    /**
     * Verifica se la voce corrente è stata selezionata in precedenza.
     * Le voci testate sono quelle prese dalla griglia come input
     * (vedi currentFilter in multicheck-filter.component.ts).
     * @param item la voce che (non) sarà selezionata
     */
    isItemSelected(item: any): boolean;
    showAllDataIfBelowThreshold(): any;
    distinctRowsLoaded(): any;
    dataWasInitialized(): any;
    onSelectAll(service: FilterService): any;
    textAccessor(dataItem: any): any;
    valueAccessor(dataItem: any): any;
}
export declare abstract class SharedManager implements IManager {
    protected comp: IMultiCheckFilter;
    SHOWN_THRESHOLD: number;
    abstract shownData: (string | DropdownListItem | number)[];
    abstract distinctRows: (string | DropdownListItem | number)[];
    allRows: (string | DropdownListItem | number)[];
    store: {
        [key: string]: string[];
    };
    column: KendoGridColumn;
    protected field: string;
    protected valueField: string;
    protected textField: string;
    protected values: string[];
    private curPageNum;
    private shutdownPagination;
    selectAllChecked: boolean;
    protected isPrimitive: boolean;
    protected abstract setColumn(cols: KendoGridColumn[]): any;
    protected abstract mapFilters(descriptor: CompositeFilterDescriptor): any;
    protected abstract parseValue(item: any): any;
    abstract onSelectAll(service: FilterService): any;
    constructor(comp: IMultiCheckFilter);
    init(inpt: Required<MulticheckInput>): void;
    getColumn(): KendoGridColumn;
    abstract textAccessor(dataItem: any): any;
    abstract valueAccessor(dataItem: any): any;
    abstract map(rows: string[], ordering: (rows: any) => any | null): any;
    dataWasInitialized(): boolean;
    fetchNewPage(): void;
    transitionToDistinctRows: boolean;
    private findNextDataPacket;
    protected getIterationLowerUpperBounds(offset?: number): number[];
    initDataNoPagination(): void;
    showAllDataIfBelowThreshold(): void;
    distinctRowsLoaded(): void;
    abstract filter(text: string): any;
    abstract isItemSelected(item: any): any;
    onSelectionChange(item: any, filterService: FilterService): void;
    protected selectOrDeselectItem(item: any): void;
    protected onSelectAllStringDropdown(service: FilterService): void;
    updateSelectedValues(): void;
}
