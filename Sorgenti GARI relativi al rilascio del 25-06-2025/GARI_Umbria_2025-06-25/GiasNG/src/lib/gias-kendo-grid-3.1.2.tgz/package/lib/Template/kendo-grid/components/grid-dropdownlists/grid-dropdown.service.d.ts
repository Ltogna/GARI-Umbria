import { FormGroup } from '@angular/forms';
import { BehaviorSubject, Observable } from 'rxjs';
import { DropdownList, DropdownListItem, KendoGridColumn, KendoGridRow } from '../../models/grid.model';
import { InMemoryView } from '../grid-customizations/model';
import * as i0 from "@angular/core";
export interface NextDropdownValue {
    controlName: string;
    value: string;
    loadData: (dataItem: any) => Observable<any[]>;
    formGroup: FormGroup;
    loadOnEdit: boolean;
    currentRow: KendoGridRow;
    column: KendoGridColumn;
}
export declare class GridDropdownService {
    readonly defaultItem: DropdownListItem;
    sourceChange: BehaviorSubject<DropdownList>;
    extractDropdownItems(data: InMemoryView[]): DropdownListItem[];
    getDefaultItem(): DropdownListItem;
    getDefaultItemId(): string;
    generateUID(): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<GridDropdownService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<GridDropdownService>;
}
