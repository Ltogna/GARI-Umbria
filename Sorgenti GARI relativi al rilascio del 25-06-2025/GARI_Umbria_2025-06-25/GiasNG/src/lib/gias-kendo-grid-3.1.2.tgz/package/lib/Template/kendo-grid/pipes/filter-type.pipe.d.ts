import { PipeTransform } from '@angular/core';
import { KendoGridColumn } from '../models/grid.model';
import { KendoGridService } from '../services/kendo-grid.service';
import * as i0 from "@angular/core";
export declare class FilterTypePipe implements PipeTransform {
    service: KendoGridService;
    constructor(services: KendoGridService);
    transform(column: KendoGridColumn): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<FilterTypePipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<FilterTypePipe, "filterType", false>;
}
