import { KendoGridService } from "./kendo-grid.service";
import { GridDataWithFilter } from './grid-data-with-filter';
import * as i0 from "@angular/core";
export declare class KendoGridMasterDetailService {
    private _GridMasterService;
    private _Array_GridDetail;
    private _Last_RowExpanded;
    private _RowIdGridMaster;
    get GridMasterService(): KendoGridService;
    set GridMasterService(service: KendoGridService);
    set GridDetailService(obj: GridDetailInfo);
    get Last_RowExpanded(): any;
    set Last_RowExpanded(row: any);
    get GridDataMaster(): GridDataWithFilter;
    get GridDataDetail(): Array<GridDataDetail>;
    get_GridDetailService(GridMasterRowId: any): KendoGridService;
    get RowIdGridMaster(): string;
    set RowIdGridMaster(RowId: string);
    static ɵfac: i0.ɵɵFactoryDeclaration<KendoGridMasterDetailService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<KendoGridMasterDetailService>;
}
export declare class GridDetailInfo {
    GridMasterRowId: any;
    Service: KendoGridService;
    constructor(GridMasterRowId: any, Service: KendoGridService);
}
export declare class GridDataDetail {
    GridMasterRowId: any;
    GridData: GridDataWithFilter;
    constructor(GridMasterRowId: any, GridData: GridDataWithFilter);
}
