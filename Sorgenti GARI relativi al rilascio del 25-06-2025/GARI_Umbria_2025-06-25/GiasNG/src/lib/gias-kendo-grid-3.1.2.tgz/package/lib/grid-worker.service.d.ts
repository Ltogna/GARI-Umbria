import { InjectionToken } from '@angular/core';
import { KendoGridColumn } from './Template/kendo-grid/models/grid.model';
import { GridPublicService } from './Template/kendo-grid/services/grid-public.service';
import { Subject } from 'rxjs';
import { IGridWorkerService } from './grid-worker.interface';
import { CELL_TYPES } from 'gias-ui-kit';
import * as i0 from "@angular/core";
export declare const GRID_WORKER_URL: InjectionToken<string>;
export declare class GridWorkerService implements IGridWorkerService {
    grid: GridPublicService;
    private gridWorkerUrl;
    resultsStore: {};
    workLoad: Subject<void>;
    workerInst: Worker;
    alreadySubed: boolean;
    constructor(grid: GridPublicService, gridWorkerUrl: string);
    refreshWorker(): void;
    runTaskDistinct(rows: any[], field: string, type: CELL_TYPES, col: KendoGridColumn, applyOrder: boolean): void;
    distinctPrimitive(rows: any): any[];
    distinctDropdown(rows: any, col: any): any[];
    distinctDates(rows: any): any;
    onError(e: any): void;
    resetStore(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<GridWorkerService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<GridWorkerService>;
}
