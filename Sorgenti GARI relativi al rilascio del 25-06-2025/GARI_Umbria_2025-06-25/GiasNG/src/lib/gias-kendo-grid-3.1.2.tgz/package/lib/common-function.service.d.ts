export declare class CommonFunctionsService {
    static getOrigins(): string;
    static isJSON(str: string): boolean;
}
