import { FilterService } from "@progress/kendo-angular-grid";
import { CompositeFilterDescriptor } from "@progress/kendo-data-query";
import { DropdownListItem, KendoGridColumn } from "../../../models/grid.model";
import { MultiCheckFilterComponent } from "../multicheck-filter.component";
import { SharedManager } from "./manager";
export declare class DropdownManager extends SharedManager {
    protected mapFilters(descriptor: CompositeFilterDescriptor): any[];
    shownData: DropdownListItem[];
    distinctRows: DropdownListItem[];
    constructor(that: MultiCheckFilterComponent);
    protected setColumn(cols: KendoGridColumn[]): void;
    map(rows: any[], ordering: (rows: any) => any | null): DropdownListItem[];
    valueAccessor(value: DropdownListItem | string): any;
    textAccessor(dataItem: DropdownListItem): string;
    getColumn(): KendoGridColumn;
    filter(text: string): void;
    protected parseValue(item: any): any;
    isItemSelected(item: any): boolean;
    onSelectAll(service: FilterService): void;
}
