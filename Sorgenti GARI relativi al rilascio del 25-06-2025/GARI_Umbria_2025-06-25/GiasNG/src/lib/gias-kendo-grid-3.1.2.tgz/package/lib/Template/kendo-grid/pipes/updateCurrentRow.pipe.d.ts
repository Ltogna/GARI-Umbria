import { PipeTransform } from '@angular/core';
import { KendoGridService } from '../services/kendo-grid.service';
import * as i0 from "@angular/core";
export declare class SetDataItemPipe implements PipeTransform {
    private privateService;
    constructor(privateService: KendoGridService);
    transform(dataItem: any): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SetDataItemPipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<SetDataItemPipe, "update-data-item", false>;
}
