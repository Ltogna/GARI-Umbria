import { EventEmitter, OnDestroy, OnInit } from '@angular/core';
import { DropdownList, DropdownListItem } from '../../../models/grid.model';
import { GridCustomizationsService } from '../grid-customizations.service';
import { SelectionChangeEvent as ApplyViewEvent } from '../model';
import { CustomizeDropdownService } from './customization-dropdown.service';
import { GridPublicService } from '../../../services/grid-public.service';
import { FiltroJSONService } from '../../../services/filtro-json.service';
import * as i0 from "@angular/core";
export declare class CustomizationDropdownComponent implements OnInit, OnDestroy {
    private service;
    private dropdownSerivce;
    private gridpublicService;
    private filtroJSONService;
    private signal$;
    /** Dati */
    dropdown: DropdownList;
    /** Campi di input/output */
    filterable: boolean;
    selected: DropdownListItem;
    selectedChange: EventEmitter<DropdownListItem>;
    applyView: EventEmitter<ApplyViewEvent>;
    applyViewAndJSON: EventEmitter<ApplyViewEvent>;
    source: DropdownListItem[];
    sourceChange: EventEmitter<DropdownListItem[]>;
    constructor(service: GridCustomizationsService, dropdownSerivce: CustomizeDropdownService, gridpublicService: GridPublicService, filtroJSONService: FiltroJSONService);
    /** Initialization */
    ngOnInit(): void;
    private init;
    onNgModelChange(item: DropdownListItem): void;
    handleFilter(value: string): void;
    changeValue(newValue: DropdownListItem): void;
    filter: string;
    addNew(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CustomizationDropdownComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CustomizationDropdownComponent, "gias-customization-dropdown", never, { "selected": { "alias": "selected"; "required": false; }; }, { "selectedChange": "selectedChange"; "applyView": "applyView"; "applyViewAndJSON": "applyViewAndJSON"; "sourceChange": "sourceChange"; }, never, never, false, never>;
}
