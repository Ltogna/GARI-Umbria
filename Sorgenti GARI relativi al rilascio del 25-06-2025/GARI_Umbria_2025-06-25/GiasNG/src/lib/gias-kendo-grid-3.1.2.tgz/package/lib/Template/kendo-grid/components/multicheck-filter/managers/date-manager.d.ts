import { FilterService } from "@progress/kendo-angular-grid";
import { CompositeFilterDescriptor } from "@progress/kendo-data-query";
import { KendoGridColumn } from "../../../models/grid.model";
import { DateFilters } from "../utils";
import { SharedManager } from "./manager";
export declare class DateManager extends SharedManager {
    distinctRows: string[];
    shownData: string[];
    map(rows: string[], ordering: (rows: any) => any | null): string[];
    protected setColumn(cols: KendoGridColumn[]): void;
    textAccessor(dataItem: any): any;
    valueAccessor(dataItem: any): any;
    filter(date: DateFilters | string): void;
    protected parseValue(item: any): any;
    protected mapFilters(descriptor: CompositeFilterDescriptor): any[];
    isItemSelected(item: any): boolean;
    onSelectAll(service: FilterService): void;
}
