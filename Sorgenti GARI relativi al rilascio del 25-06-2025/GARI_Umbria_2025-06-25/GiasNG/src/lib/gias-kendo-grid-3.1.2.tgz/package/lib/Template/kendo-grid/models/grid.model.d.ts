import { Component, ElementRef, InjectionToken, Type } from '@angular/core';
import { FormGroup, Validators } from '@angular/forms';
import { Event } from '@angular/router';
import { AddEvent, CancelEvent, CellClickEvent, CellCloseEvent, ColumnBase, ColumnVisibilityChangeEvent, EditEvent, GridComponent, SelectionEvent } from '@progress/kendo-angular-grid';
import { BehaviorSubject, Subject } from 'rxjs';
import { ColumnSettings } from '../components/grid-customizations/model';
import { AbstractGridConfigService } from '../services/grid-config.service';
import { State } from "@progress/kendo-data-query";
import { CustomComponent } from './custom-component';
import { CELL_TYPES } from 'gias-ui-kit';
export declare const GRID_HTTP_TOKEN: InjectionToken<AbstractGridConfigService<KendoServerResult>>;
export declare abstract class GridParentComponent extends Component {
}
export interface OnBeforeAfterEvents {
    /**
     * La funzione viene chiamata ogni volta si clicca su una cella.
     * Funzione chiamata in in cell editing.
     * @param event L'evento kendo grid.
     */
    onCellClick(event: CellClickEvent): void;
    /**
     * La funzione viene chiamata ogni volta si chiude una cella.
     * Funzione chiamata in in cell editing.
     * @param event L'evento kendo grid.
     */
    onCellClose(event: CellCloseEvent): void;
    /**
     * La funzione viene chiamata ogni volta che si deve creare un formGroup e si ha
     * necessita di crearlo dall'esterno della kendo grid.
     * @param event L'evento kendo grid.
     */
    onCreateExternalFormGroup(event: CellClickEvent | AddEvent | EditEvent): FormGroup;
}
/**
 * Modello Colonne KendoGridColumn
 * N.B. Se si deve aggiungere una nuova proprietà in questa classe che non è compresa tra quelle
 * standard di kendo(ColumnSettings) ricordarsi di aggiungere la nuova proprietà da memorizzare nelle viste della Griglia anche
 * nella funzione GridCustomizationsService.manageCellTypes (prendere come esempio showHTMLAsString).
 */
export declare class KendoGridColumn implements ColumnSettings {
    class?: string[];
    ddl?: DropdownListWithForm;
    numeric?: NumericSettings;
    boolean?: BooleanSettings;
    date?: DateSettings;
    string?: StringSettings;
    validators?: any[];
    editable: boolean;
    resizable: boolean;
    sticky: boolean;
    field: string;
    title: string;
    width: number;
    hidden: boolean;
    disabledRule: (rowData: any) => boolean;
    filter: 'text' | 'boolean' | 'numeric' | 'date' | 'datetime';
    filterOrdering: (rows: any) => any;
    format: string;
    filterable: boolean;
    orderIndex: number;
    leafIndex: number;
    includeInChooser: boolean;
    showHTMLAsString: boolean;
    media: string;
    customParent: string;
    customFooter: (rows: KendoGridRow) => string;
    style: {
        [key: string]: string;
    };
    footerStyle: {
        [key: string]: string;
    };
    component: Type<CustomComponent>;
    constructor(required: {
        field: string;
        title: string;
    }, optional?: Partial<KendoGridColumn>);
}
export interface TableData {
    kendo_model: KendoGridModel;
    kendo_columns: KendoGridColumn[];
    kendo_rows: [];
}
export declare class KendoGridModel {
    [key: string]: ModelEntry;
}
export declare class ModelEntry {
    type: string | CELL_TYPES;
    editable?: boolean;
    format?: string;
    validators?: Array<Validators>;
    editor?: (container: any) => any;
    constructor(type: string | CELL_TYPES, editable?: boolean, format?: string, validators?: Array<Validators>, editor?: (container: any) => any);
}
export declare abstract class KendoServerResult {
    model: KendoGridModel;
    columns: KendoGridColumn[];
    rows: KendoGridRow[];
    constructor(model: KendoGridModel, columns: KendoGridColumn[], rows: KendoGridRow[]);
}
export declare class KendoServerResultImpl extends KendoServerResult {
    constructor(model: any, columns: any, rows: any);
}
export declare class ServerResult {
    kendo_rows: KendoGridRow[];
    kendo_columns: KendoGridColumn[];
    kendo_model: KendoGridModel;
}
export declare class GridInfoCommandEvent {
    action: string;
    dataItem: any;
    isNew: boolean;
    rowIndex: number;
    sender: GridComponent;
}
export declare class NumericSettings {
    defaultValue?: number;
    min?: number;
    max?: number;
    format?: string;
    autoCorrect?: boolean;
    decimals?: number;
    step?: number;
    multiCheckFiltering?: boolean;
    constructor(settings?: NumericSettings);
}
export declare class DateSettings {
    defaultValue?: Date;
    min?: Date;
    max?: Date;
    format?: string;
    placeholder?: string;
    constructor(opts?: DateSettings);
}
export declare class DateTimeSettings {
    defaultValue?: Date;
    min?: Date;
    max?: Date;
    format?: string;
    placeholder?: string;
    constructor(opts?: DateTimeSettings);
}
export declare class StringSettings {
    defaultValue?: string;
    constructor(settings?: StringSettings);
}
export declare class BooleanSettings {
    defaultValue?: boolean;
    /** Used together with rightLable to define the labels next to the switch component. */
    leftLabel?: string;
    /** Used together with leftLable to define the labels next to the switch component. */
    rightLabel?: string;
    constructor(settings?: BooleanSettings);
}
export declare class GridCustomizations {
    enabled: boolean;
    isSaveDisabledOnDefaultView: boolean;
    constructor(options?: Partial<GridCustomizations>);
}
export declare class DropdownList {
    id: string;
    data: DropdownListItem[];
    defaultValue?: DropdownListItem;
    defaultOpen?: boolean;
    readonly textField: string;
    readonly valueField: string;
    valuePrimitive: boolean;
    loadOnEdit: boolean;
    descriptionField: string;
    loadFunction: (dataItem: any) => Subject<any[]>;
    itemDisabledFn: (i: any) => boolean;
    loading: boolean;
    constructor(id: string, data: DropdownListItem[], defaultValue?: DropdownListItem, defaultOpen?: boolean);
}
/**
 * Una dropdown list usata dentro la kendo griglia.
 * @param id - Codice che identifica la dropdown in modo univoco nella pagina.
 * @param formControlName - il nome del campo creato nel formGroup corrispondente a una riga.
 * Ripresenta il codice che identifica univocamente ogni voce della dropdown.
 * @param formControlValue - la descrizione che compare nella cella della dropdown list.
 */
export declare class DropdownListWithForm extends DropdownList {
    formControlName: string;
    formControlValue: string;
    reload: Subject<Boolean>;
    constructor(id: string, formControlName: string, formControlValue: string, data: DropdownListItem[], defaultValue?: DropdownListItem, defaultOpen?: boolean, reload?: Subject<Boolean>);
}
export declare class DropdownListItem {
    readonly id: any;
    readonly name: string;
    readonly data?: any;
    constructor(id: any, name: string, data?: any);
}
export declare class KendoGridRow {
}
export declare class GridEvent {
    event: Event;
    index: number;
    constructor(event: Event, index: number);
}
export declare enum EditingMode {
    IN_LINE = "in-line",
    IN_CELL = "in-cell",
    IN_PAGE = "in-page",
    IN_LINE_BATCH = "in-line-batch",
    IN_CELL_BATCH = "in-cell-batch"
}
export interface InCellBatchSaveEventObject {
    added: any[];
    updated: any[];
    deleted: any[];
}
export declare enum LoaderType {
    RESOLVER = "resolver",
    HTML = "html",
    SERVICE = "service"
}
export declare class JsonKendoResult {
    kendo_model: KendoGridModel;
    kendo_rows: KendoGridRow[];
    kendo_columns: KendoGridColumn[];
}
export declare class SelectedOpts {
    keys: string[] | number[];
    usePartialMatch?: boolean;
    resetPreviousSelection?: boolean;
}
export declare class NextSelection {
    value: SelectionEvent;
}
export declare class SelectionSettings {
    private _setSelected;
    getSelectedValue: BehaviorSubject<NextSelection>;
    get setSelected(): BehaviorSubject<SelectedOpts>;
    set setSelected(value: BehaviorSubject<SelectedOpts>);
}
export declare class CustomizedColumnComponent extends ColumnBase {
    applyAutofit: boolean;
    field: string;
}
/**
 * These event types are emited each time:
 *   ReadEvent - the grid performs a read operation.
 *   ColumnVisibilityChangeEvent - a collumn becomes visible.
 *   CellCloseEvent - a cell is closed (in cell)
 *   CancelEvent - a row modification is canceled (in line)
 */
export type ReadEvent = {
    columns?: ColumnBase[];
};
export type RendererGridEventType = ReadEvent | ColumnVisibilityChangeEvent | CellCloseEvent | CancelEvent | State;
export declare class RendererGridEvent {
    gridElRef: ElementRef;
    grid: GridComponent;
    event?: RendererGridEventType;
}
