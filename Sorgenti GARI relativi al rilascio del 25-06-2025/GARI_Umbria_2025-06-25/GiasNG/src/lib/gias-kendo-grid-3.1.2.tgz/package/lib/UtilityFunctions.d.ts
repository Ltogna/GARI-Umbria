import { Renderer2 } from '@angular/core';
import { AbstractControl, FormArray } from '@angular/forms';
export declare namespace UtilityFunctions {
    function setStyle(renderer: any, parent: any, selector: string, name: string, value: string): void;
    function setStyleAll(renderer: any, parent: any, selector: string, name: string, value: string): void;
    function addClass(renderer: Renderer2, parent: any, selector: string, name: string): void;
    function hideElem(renderer: any, parent: any, selector: string): void;
    function showElem(renderer: any, parent: any, selector: string): void;
    function compareObjects(o: any, p: any): boolean;
    function clearFormArray(formArray: FormArray): void;
    function distinctArrayValues(array: any[], fields: string[]): any[];
    function GetListofPropertyinArrayObject(input_array: Array<any>, property: string): Array<any>;
    function GetValueofPropertyinObject(input: any, property: string): any;
    function forbiddenDdlValidator(control: AbstractControl): {
        ddlNotSet: boolean;
    };
}
