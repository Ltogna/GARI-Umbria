import { KendoGridColumn } from '../../models/grid.model';
import * as i0 from "@angular/core";
export declare class ToolbarColumnMenuComponent {
    columns: KendoGridColumn[];
    onChange(item: KendoGridColumn): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ToolbarColumnMenuComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ToolbarColumnMenuComponent, "gias-toolbar-column-menu", never, { "columns": { "alias": "columns"; "required": false; }; }, {}, never, never, false, never>;
}
