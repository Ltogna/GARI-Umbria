import * as i0 from "@angular/core";
export declare class GridDateTimeComponent {
    value: Date;
    static ɵfac: i0.ɵɵFactoryDeclaration<GridDateTimeComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GridDateTimeComponent, "gias-grid-date", never, {}, {}, never, never, false, never>;
}
