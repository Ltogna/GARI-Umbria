import { InjectionToken, QueryList } from '@angular/core';
import { ColumnBase } from '@progress/kendo-angular-grid';
import { Subject } from 'rxjs';
import { KendoGridColumn, KendoGridModel, KendoGridRow, SelectedOpts } from '../models/grid.model';
export declare const QryParamsResolver: InjectionToken<IQueryParamsService>;
export interface IQueryParamsService {
    init(signal: Subject<void>): any;
    execute(params: any): any;
}
export declare function mapDateFilter(descriptor: any, model: KendoGridModel, columns: KendoGridColumn[]): void;
export declare const getCircularReplacer: () => (key: any, value: any) => any;
export declare function scrollToFirstColumn(parentName: string): void;
export declare function columnAlreadyInView(inCols: QueryList<ColumnBase>, curCols: QueryList<ColumnBase>): boolean;
export declare function findMatchedIndex(key: string | number, rows: KendoGridRow[], rowId: string, opts: SelectedOpts): any;
export declare function resetSelection(rows: KendoGridRow[]): void;
export declare function _isNull(value: any): boolean;
