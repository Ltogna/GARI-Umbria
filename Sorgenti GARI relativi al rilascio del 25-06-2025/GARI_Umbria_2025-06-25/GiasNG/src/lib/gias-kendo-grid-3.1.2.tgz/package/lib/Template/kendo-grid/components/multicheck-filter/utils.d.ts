import { IconDefinition } from '@fortawesome/free-solid-svg-icons';
import { TranslocoService } from '@jsverse/transloco';
import { PopupCloseEvent } from '@progress/kendo-angular-grid';
import { CompositeFilterDescriptor, FilterDescriptor } from '@progress/kendo-data-query';
import { DropdownListItem } from '../../models/grid.model';
export declare class DateFilters {
    start: Date;
    end: Date;
    filterDescriptors: FilterDescriptor | CompositeFilterDescriptor;
}
export declare enum FILTER_MODES {
    BASIC_FILTERS = 0,
    ADVANCED_FILTERS = 1
}
export declare class filtersManager {
    readonly basicFilteringMode = FILTER_MODES.BASIC_FILTERS;
    readonly extendedFilteringMode = FILTER_MODES.ADVANCED_FILTERS;
    activeMode: FILTER_MODES;
    advancedModeActive: boolean;
    faCog: IconDefinition;
    switchColor: 'cornflowerblue' | '#dc3545';
    changingSettingsMode: boolean;
    switchActiveMode(): void;
    /**
     * Prevents popup from closing if the filtering mode has been recently
     * changed. Strangely the popup would normally close when the
     * switchActiveMode() method is called. This has to do with the use of
     * the ng-template #settingsFooter in the view.
    */
    preventPopupCloseIfRequired(e: PopupCloseEvent): void;
}
export declare class FormValueManager {
    private readonly firstOpDefault;
    private readonly secondOpDefault;
    private readonly logicOpDefault;
    start: Date;
    end: Date;
    operators: DropdownListItem[];
    logicOperators: DropdownListItem[];
    firstOperator: DropdownListItem;
    secondOperator: DropdownListItem;
    logicOperator: DropdownListItem;
    constructor(transloco: TranslocoService);
    hasFilters(): boolean;
    clearFilters(): void;
    resetOperators(): void;
    private translateOperators;
    private translateLogicalOperators;
}
