import * as i0 from "@angular/core";
export declare class GridBatchHandlerService {
    private added;
    private updated;
    private deleted;
    get hasChanges(): boolean;
    getData(): any;
    add(row: any): void;
    update(row: any, rowKey: string): void;
    remove(rows: any[], rowKey: string): void;
    reset(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<GridBatchHandlerService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<GridBatchHandlerService>;
}
