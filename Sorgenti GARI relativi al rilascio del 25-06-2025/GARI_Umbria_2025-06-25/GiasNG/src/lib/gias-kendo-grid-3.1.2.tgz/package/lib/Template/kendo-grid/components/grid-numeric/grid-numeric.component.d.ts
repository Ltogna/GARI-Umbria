import * as i0 from "@angular/core";
export declare class GridNumericComponent {
    value: number;
    min: number;
    max: number;
    static ɵfac: i0.ɵɵFactoryDeclaration<GridNumericComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GridNumericComponent, "gias-grid-numeric", never, { "value": { "alias": "value"; "required": false; }; "min": { "alias": "min"; "required": false; }; "max": { "alias": "max"; "required": false; }; }, {}, never, never, false, never>;
}
