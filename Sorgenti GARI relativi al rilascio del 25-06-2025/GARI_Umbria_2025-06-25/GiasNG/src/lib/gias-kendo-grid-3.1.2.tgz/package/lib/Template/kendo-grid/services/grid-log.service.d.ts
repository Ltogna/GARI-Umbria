import { KendoGridColumn, KendoGridModel, KendoGridRow } from '../models/grid.model';
import { KendoGridMasterDetailService } from './grid-master-detail.service';
import * as i0 from "@angular/core";
export declare class GridErrorService {
    loggingAttivo: boolean;
    private infoBGColor;
    private errBGColor;
    /**
   * Expensive operation.
   */
    private runInDepthAnalysis;
    runDataConsistencyChecks(model: KendoGridModel, columns: KendoGridColumn[], righe: KendoGridRow[]): void;
    checkThis(func: (...fnArgs: any[]) => any, ...args: any[]): any;
    checkRequiredFields(model: KendoGridModel, columns: Array<KendoGridColumn>, rows: KendoGridRow[]): void;
    modelEntryExists(entryExists: boolean, fieldName: string): void;
    logErr(msg: string): void;
    logInfo(msg: string, className?: string, fnName?: string, ...args: any[]): void;
    generalErrors(errorType: GenericErrors, ...args: any[]): void;
    private checkValidDate;
    private checkValidNumber;
    checkGridMasterDetailConfig(masterDetailService: KendoGridMasterDetailService, enable_master_detail: boolean): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<GridErrorService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<GridErrorService>;
}
export declare enum GenericErrors {
    EditingModeNotFound = 0
}
