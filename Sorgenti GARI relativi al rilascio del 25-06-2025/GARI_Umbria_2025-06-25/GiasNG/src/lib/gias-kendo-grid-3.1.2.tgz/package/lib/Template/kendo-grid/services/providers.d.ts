import { Provider } from '@angular/core';
import { GridPublicService } from './grid-public.service';
import { IQueryParamsService } from './utilities';
export declare const gridPubServiceFactory: (resolver: IQueryParamsService[]) => GridPublicService;
export declare function generateGridProviders(configService: any, gridParent: any, gridMasterDetail?: any): Provider[];
