import { ElementRef, OnDestroy } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { EditEvent, GridComponent } from '@progress/kendo-angular-grid';
import { BehaviorSubject, Subject } from 'rxjs';
import { KendoGridRow, KendoServerResult as GridServerResult, SelectionSettings as SelectionHandler } from '../models/grid.model';
import { KendoGridService } from './kendo-grid.service';
import { IQueryParamsService } from './utilities';
import { CompositeFilterDescriptor } from '@progress/kendo-data-query/dist/npm/filtering/filter-descriptor.interface';
import { InMemoryView } from '../components/grid-customizations/model';
import { GridCommandItem } from '../../../shared/utils';
import { GridDataWithFilter } from './grid-data-with-filter';
import * as i0 from "@angular/core";
export declare class GridPublicService extends BehaviorSubject<GridDataWithFilter> implements OnDestroy {
    private qryParamServices;
    clearGridPublicService(): void;
    private _Current_Grid_Master_RowExpanded;
    get Current_Grid_Master_RowExpanded(): any;
    set Current_Grid_Master_RowExpanded(RowExpanded: any);
    formGroup: BehaviorSubject<FormGroup>;
    signal$: Subject<void>;
    /** A new value is emitted when pressing a row's commands' dropdown button.
     * @valueEmitted the row's dataItem
     */
    openCommands: BehaviorSubject<any>;
    /** A new value is emitted when pressing a command from the commands'
     * dropdown button.
     * @valueEmitted object containing `command`, `dataItem` and `rowIndex`
     * @usageNotes to select the right command use a `switch` over command.action
     * the base events can be found in the enumeration `CommandsDropDownEvents`.
     * Other events should be declared as constant numbers.
     *
     * @example
     * ```
     * this.gridPublicSerivce.commandEvent.GiasSubscribe(ev => {
            if (!ev) return;
            switch (ev.command.action) {
                case CommandsDropDownEvents.FULL_EDIT:
                    this.onTemplateBtnClick(ev.dataItem);
                    break;
            }
        })
     * ```
     */
    commandEvent: BehaviorSubject<{
        command: GridCommandItem;
        dataItem: any;
        rowIndex: number;
    }>;
    multiIndex: number;
    private gridPrivate;
    gridElRef: ElementRef<any>;
    gridComp: GridComponent;
    giasGridComponent: any;
    changeDetected: Subject<EditEvent>;
    detachedSaveBtn: Subject<void>;
    resetChanges$: Subject<void>;
    freeMultiIndex: boolean;
    /** Setter and getter of newly selected values */
    selection: SelectionHandler;
    currentDataItem: KendoGridRow;
    /** Contiene gli ultimi filtri applicati alle colonne della griglia.
     * @UsageNotes Possibile ricavare le righe filtrate tramite: <code>process(this.rows, { filter: this.grid.filter }).data;</code>
     */
    filters: BehaviorSubject<CompositeFilterDescriptor>;
    thereIsAForm: boolean;
    applyViewFiltroJSON: BehaviorSubject<InMemoryView>;
    afterSaveView: BehaviorSubject<string>;
    keyViewString: BehaviorSubject<string>;
    filtroJSONstring: string;
    constructor(qryParamServices: IQueryParamsService[]);
    ngOnDestroy(): void;
    changeFormValue(type: FormValueChange, controlName: string, value: any): void;
    /** Disables the editing of the grid.
     * @usageNotes
     * To be able to use this function, both the field `model` and `columns` of the {@link AbstractGridConfigService}
     * must be valorized with the data used in the grid. You can valorize the fields from the `read()` function in
     * your grid's configuration service.
     */
    disable(): void;
    /** Enables the editing of the grid.
     * @usageNotes
     * To be able to use this function, both the field `model` and `columns` of the {@link AbstractGridConfigService}
     * must be valorized with the data used in the grid. You can valorize the fields from the `read()` function in
     * your grid's configuration service.
     */
    enable(): void;
    refresh(forceRefresh?: boolean, newData?: GridServerResult): void;
    init(ctx: KendoGridService): void;
    /** Executed after the data has been placed inside the grid. */
    dataBinded: boolean;
    parseQueryParams(): void;
    /**
     * Called inside the ngOnInit() life cycle hook of the grid.
     * @param ctx Grid context. Used for unsubscribing and updating grid
     * properties.
     */
    ngOnInit(ctx: any): void;
    private initializeSubscriptions;
    static ɵfac: i0.ɵɵFactoryDeclaration<GridPublicService, [{ optional: true; }]>;
    static ɵprov: i0.ɵɵInjectableDeclaration<GridPublicService>;
}
export declare enum FormValueChange {
    DropdownItem = 1
}
