import { PipeTransform } from '@angular/core';
import { KendoGridColumn, KendoServerResult } from '../models/grid.model';
import { AbstractGridConfigService } from '../services/grid-config.service';
import { GiasAggregateDescriptor } from "../models/configuration.model";
import * as i0 from "@angular/core";
export declare class AggregateTypePipe implements PipeTransform {
    conf: AbstractGridConfigService<KendoServerResult>;
    constructor(conf: AbstractGridConfigService<KendoServerResult>);
    transform(col: KendoGridColumn): {
        show: boolean;
        descriptor?: GiasAggregateDescriptor;
    };
    static ɵfac: i0.ɵɵFactoryDeclaration<AggregateTypePipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<AggregateTypePipe, "aggrType", false>;
}
