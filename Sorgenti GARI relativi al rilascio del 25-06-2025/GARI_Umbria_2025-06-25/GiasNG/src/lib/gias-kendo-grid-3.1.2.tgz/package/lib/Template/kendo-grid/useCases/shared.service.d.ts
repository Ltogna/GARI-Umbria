export declare class Shared {
    static changeGridPage(index: number, pageSize: number): number;
}
