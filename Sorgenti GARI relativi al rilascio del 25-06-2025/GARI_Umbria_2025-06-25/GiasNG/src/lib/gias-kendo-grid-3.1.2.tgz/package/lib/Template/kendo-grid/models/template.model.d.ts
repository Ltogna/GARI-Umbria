import { TranslocoService } from '@jsverse/transloco';
import { CodiciTemplate } from '../../../shared/codici-config-template.model';
import { AggregateSettings, AgrSelectableSettings, BehaviorSettings, ColumnMenuSettings, CommandsColumnSettings, CommandsDropDownSettings, CustomColumnSettings, DettagliColumnSettings, GeneralSettings, GroupSettings, MasterDetailSettings, PaginationSettings, ResizableSettings, SortSettings, ToolbarSettings } from './configuration.model';
import { GridCustomizations } from './grid.model';
import { InCellTemplate } from './in-cell-template.model';
import { InLineTemplate } from './in-line-template.model';
import * as i0 from "@angular/core";
export interface IOptionalConfigParameters {
    selectable: AgrSelectableSettings;
    toolbar: ToolbarSettings;
    cmdColumn: CommandsColumnSettings;
    cmdDropDown: CommandsDropDownSettings;
    resizable: ResizableSettings;
    generalSettings: GeneralSettings;
    sort: SortSettings;
    pagination: PaginationSettings;
    columnMenu: ColumnMenuSettings;
    behavior: BehaviorSettings;
    views: GridCustomizations;
    aggregates: AggregateSettings;
    groups: GroupSettings;
    dettagliColumn: DettagliColumnSettings;
    customColumn: CustomColumnSettings;
}
export declare class DefaultTemplate implements IOptionalConfigParameters {
    private translocoService;
    selectable: AgrSelectableSettings;
    toolbar: ToolbarSettings;
    cmdColumn: CommandsColumnSettings;
    cmdDropDown: CommandsDropDownSettings;
    resizable: ResizableSettings;
    generalSettings: GeneralSettings;
    sort: SortSettings;
    pagination: PaginationSettings;
    columnMenu: ColumnMenuSettings;
    behavior: BehaviorSettings;
    views: GridCustomizations;
    aggregates: AggregateSettings;
    groups: GroupSettings;
    dettagliColumn: DettagliColumnSettings;
    customColumn: CustomColumnSettings;
    masterdetail: MasterDetailSettings;
    constructor(translocoService: TranslocoService);
    handleToolbarSettings(): ToolbarSettings;
    handleGeneralSettings(): GeneralSettings;
    handleCmdColumn(): CommandsColumnSettings;
    handleCmdDropDown(): CommandsDropDownSettings;
    handleResizable(): ResizableSettings;
    handleSelectable(): AgrSelectableSettings;
    handleColumnMenu(): ColumnMenuSettings;
    handleSort(): SortSettings;
    handlePagination(): PaginationSettings;
    static ɵfac: i0.ɵɵFactoryDeclaration<DefaultTemplate, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<DefaultTemplate>;
}
export declare class FilterMenuType {
    static readonly ROW = true;
    static readonly MENU = "menu";
}
/**
 * Aggiungendo un nuovo template bisgona soltanto aggiornare le due variabili qui sotto.
 */
export declare const serviceMap: {
    DefaultTemplate: typeof DefaultTemplate;
    CodiciTemplate: typeof CodiciTemplate;
    InLineTemplate: typeof InLineTemplate;
    InCellTemplate: typeof InCellTemplate;
};
export declare enum ConfigTemplate {
    DefaultTemplate = "DefaultTemplate",
    CodiciTemplate = "CodiciTemplate",
    InLineTemplate = "InLineTemplate",
    InCellTemplate = "InCellTemplate"
}
