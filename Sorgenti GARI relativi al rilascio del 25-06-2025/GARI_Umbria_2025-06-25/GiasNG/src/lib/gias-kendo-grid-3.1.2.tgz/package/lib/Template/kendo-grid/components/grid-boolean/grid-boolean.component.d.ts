import { EventEmitter, OnChanges, OnInit, SimpleChanges } from '@angular/core';
import * as i0 from "@angular/core";
/**
 * Questa componente è stata creata per la kendo grid.
 * Non dovrebbe essere usata fuori da questo modulo.
 * */
export declare class GridBooleanComponent implements OnInit, OnChanges {
    formGroup: any;
    controlName: string;
    defaultValue: boolean;
    editable: boolean;
    useCheckbox: boolean;
    container: any;
    valueChange: EventEmitter<boolean>;
    constructor();
    ngOnInit(): void;
    onChange(value: boolean): void;
    ngOnChanges(changes: SimpleChanges): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<GridBooleanComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GridBooleanComponent, "gias-grid-boolean", never, { "formGroup": { "alias": "formGroup"; "required": false; }; "controlName": { "alias": "controlName"; "required": false; }; "defaultValue": { "alias": "defaultValue"; "required": false; }; "editable": { "alias": "editable"; "required": false; }; "useCheckbox": { "alias": "useCheckbox"; "required": false; }; }, { "valueChange": "valueChange"; }, never, never, false, never>;
}
