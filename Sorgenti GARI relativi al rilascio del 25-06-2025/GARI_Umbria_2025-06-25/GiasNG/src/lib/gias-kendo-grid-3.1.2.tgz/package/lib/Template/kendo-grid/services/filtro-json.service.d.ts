import * as i0 from "@angular/core";
export declare class FiltroJSONService {
    isFirstApplyView: boolean;
    applyLoadCacheFirstTime: boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<FiltroJSONService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<FiltroJSONService>;
}
