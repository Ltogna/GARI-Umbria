import { TranslocoService } from '@jsverse/transloco';
import { ColumnComponent } from '@progress/kendo-angular-grid';
import { GiasMessageService } from '../../../../shared/gias-message.service';
import { CookieService } from 'ngx-cookie-service';
import { Subject } from 'rxjs';
import { DropdownListItem, KendoGridColumn } from '../../models/grid.model';
import { AbstractGridConfigService } from '../../services/grid-config.service';
import { KendoGridService } from '../../services/kendo-grid.service';
import { CustomizeDropdownService } from './dropdown/customization-dropdown.service';
import { ChiaveVista, CustomizationRequest, InMemoryView } from './model';
import { Router } from "@angular/router";
import { GridPublicService } from '../../services/grid-public.service';
import { FiltroJSONService } from '../../services/filtro-json.service';
import { ConversionService, IGiasApiService, IUsernameService } from 'gias-ui-kit';
import * as i0 from "@angular/core";
export declare class GridCustomizationsService {
    private ajaxAgronicaAPIService;
    dropdownService: CustomizeDropdownService;
    private cookies;
    private giasMessageService;
    private privateGridService;
    private transloco;
    private conversionService;
    private gridPublicService;
    private filtroJSONService;
    conf: AbstractGridConfigService<any>;
    private router;
    defaultViewStoredServerSide(): boolean;
    customizationRequest: Subject<CustomizationRequest>;
    private _inMemoryViews;
    username: string;
    permessoPubblica: boolean;
    switchValue: boolean;
    selectedDDLItem: DropdownListItem;
    viewToApply: Subject<DropdownListItem>;
    defaultStoredOnServer: Subject<boolean>;
    constructor(userService: IUsernameService, ajaxAgronicaAPIService: IGiasApiService, dropdownService: CustomizeDropdownService, cookies: CookieService, giasMessageService: GiasMessageService, privateGridService: KendoGridService, transloco: TranslocoService, conversionService: ConversionService, gridPublicService: GridPublicService, filtroJSONService: FiltroJSONService, conf: AbstractGridConfigService<any>, // GridNoteServerResult
    router: Router);
    checkIfThereIsAForm(): boolean;
    setFormFields(view: InMemoryView): void;
    get inMemoryViews(): InMemoryView[];
    inMemViewsLoaded: boolean;
    cacheViewWasApplied: boolean;
    init(): void;
    /**
     * Initializes the component (the views and dropdown list).
     * Loads preselected view from the cache.
     */
    private loadInMemoryViews;
    checkDefaultViewOnServer(): void;
    private mapViews;
    private handleCacheItem;
    private loadCacheItem;
    private findExistingCookie;
    private SearchCookie;
    /**
     * Saves all views server side. Used when clicking the save button.
     * @param selectedDDLItem
     */
    saveAllViews(): void;
    /**
     * Saves the current view server side. Used when clicking 'Add'or the save
     * button.
     * @param ddlViewItem
     */
    saveCurrentView(ddlViewItem: any): void;
    /**
     * Deletes a customization.
     * @param selected the view to remove.
     */
    deleteCustomization(selected: DropdownListItem): void;
    private cleanupCookie;
    private removeInMemoryItem;
    /**
     * Creates or loads the view to be applied.
     * @param item the selected item of the dropdown.
     * @returns the view to be applied to the grid.
     */
    getView(item: DropdownListItem, forceUpdateView: boolean): InMemoryView;
    mapGridSettingsAndSaveThem(thatGrid: any, item: DropdownListItem, isNew: boolean): void;
    private saveGridSettings;
    /**
     * Save the previously created view in memory, to be displayed to the user.
     * @param gridParentName the name of the component using the the grid.
     * @param customView the view to save.
     */
    saveInMemoryCustomization(customView: InMemoryView): void;
    private updateInMemoryView;
    /** Set the column type of the saved column
     * @param columns the columns passed to KendoServerModel.
     * @param savedColumn the column it is being processed.
     * @param columnComponent
     */
    manageCellTypes(columnComponent: ColumnComponent, savedColumn: KendoGridColumn, key: string, columns: KendoGridColumn[]): void;
    persistView(selected: DropdownListItem): void;
    private storeCurrentViewChoice;
    private defaultIsSelected;
    private cleanupCookies;
    private viewIsNew;
    private transformData;
    private prepareToSaveViews;
    findCurrentlyAttachedGridColumn(columnComponent: ColumnComponent, attchedColumns: KendoGridColumn[]): KendoGridColumn;
    CreateNewKeyView(IdVista: string, NomeUtente: string, GridId?: string): ChiaveVista;
    CreateNewGridIdforView(): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<GridCustomizationsService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<GridCustomizationsService>;
}
