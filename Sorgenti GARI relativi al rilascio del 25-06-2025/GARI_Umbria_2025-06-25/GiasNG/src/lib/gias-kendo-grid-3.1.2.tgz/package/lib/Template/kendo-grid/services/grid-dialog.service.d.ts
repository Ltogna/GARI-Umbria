import { TranslocoService } from "@jsverse/transloco";
import { DialogService } from "@progress/kendo-angular-dialog";
import { KendoGridRow, KendoServerResult } from "../models/grid.model";
import { AbstractGridConfigService } from "./grid-config.service";
import { GridPublicService } from "./grid-public.service";
import { GiasDialogService } from "gias-ui-kit";
import * as i0 from "@angular/core";
export declare class GridDialogService extends GiasDialogService {
    private gridPublicService;
    conf: AbstractGridConfigService<KendoServerResult>;
    ts: TranslocoService;
    constructor(gridPublicService: GridPublicService, kendoDialogService: DialogService, conf: AbstractGridConfigService<KendoServerResult>, translocoService: TranslocoService);
    showDialog(callback: (row: any) => void, row: KendoGridRow): Promise<void>;
    private getSelectedRows;
    static ɵfac: i0.ɵɵFactoryDeclaration<GridDialogService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<GridDialogService>;
}
