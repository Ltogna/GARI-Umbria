import { ElementRef } from '@angular/core';
import * as i0 from "@angular/core";
export declare class PopupAnchorDirective {
    element: ElementRef;
    constructor(element: ElementRef);
    static ɵfac: i0.ɵɵFactoryDeclaration<PopupAnchorDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<PopupAnchorDirective, "[popupAnchor]", ["popupAnchor"], {}, {}, never, never, false, never>;
}
