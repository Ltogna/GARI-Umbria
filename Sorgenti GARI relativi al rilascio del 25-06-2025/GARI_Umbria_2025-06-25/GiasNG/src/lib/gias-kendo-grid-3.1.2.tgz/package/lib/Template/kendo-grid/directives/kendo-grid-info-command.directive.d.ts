import { TemplateRef } from '@angular/core';
import * as i0 from "@angular/core";
export declare class KendoGridCustomColumnDirective {
    templateRef: TemplateRef<any>;
    constructor(templateRef: TemplateRef<any>);
    static ɵfac: i0.ɵɵFactoryDeclaration<KendoGridCustomColumnDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<KendoGridCustomColumnDirective, "[kendoCustomColumnContent]", never, {}, {}, never, never, false, never>;
}
