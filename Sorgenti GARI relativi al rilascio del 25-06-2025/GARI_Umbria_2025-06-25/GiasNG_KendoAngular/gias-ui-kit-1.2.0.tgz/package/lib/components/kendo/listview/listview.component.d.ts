import { OnDestroy, OnInit } from '@angular/core';
import { AddEvent, CancelEvent, EditEvent, RemoveEvent, SaveEvent } from '@progress/kendo-angular-listview';
import { BehaviorSubject, ReplaySubject, Subject } from 'rxjs';
import * as i0 from "@angular/core";
export declare class ListviewComponent implements OnInit, OnDestroy {
    /** The ListView is as high as its content and as wide as the available space.
     * To enable scrolling, use a fixed height that is less than the height of the ListView content. */
    height$: ReplaySubject<number>;
    loading$: ReplaySubject<boolean>;
    data$: BehaviorSubject<IListViewItem[]>;
    removeDataItem$: Subject<{
        index: number;
        deleteCount: number;
    }>;
    resetStates$: Subject<boolean>;
    showListHeader: (...args: any[]) => boolean;
    showAddBtn: (...args: any[]) => boolean;
    showEditBtn: (...args: any[]) => boolean;
    showSaveBtn: (...args: any[]) => boolean;
    showCancelBtn: (...args: any[]) => boolean;
    showRemoveBtn: (...args: any[]) => boolean;
    showDeleteBtn: (...args: any[]) => boolean;
    removeBtnTitle: string;
    deleteBtnTitle: string;
    addEvent$: Subject<AddEvent>;
    editEvent$: Subject<EditEvent>;
    saveEvent$: Subject<SaveEvent>;
    cancelEvent$: Subject<CancelEvent>;
    removeEvent$: Subject<RemoveEvent>;
    deleteEvent$: Subject<{
        item: IListViewItem;
        itemIndex: number;
    }>;
    protected readonly faTrashCan: import("@fortawesome/fontawesome-common-types").IconDefinition;
    protected readonly faClose: import("@fortawesome/fontawesome-common-types").IconDefinition;
    private destroy$;
    private editedRowIndex;
    constructor();
    ngOnInit(): void;
    ngOnDestroy(): void;
    addHandler(event: AddEvent): void;
    editHandler(event: EditEvent): void;
    saveHandler(event: SaveEvent): void;
    cancelHandler(event: CancelEvent): void;
    removeHandler(event: RemoveEvent): void;
    deleteHandler(dataItem: IListViewItem, index: number): void;
    setItemStateStyle(item: IListViewItem, index: number): string;
    private removeDataItem;
    private closeEditor;
    private resetDataState;
    static ɵfac: i0.ɵɵFactoryDeclaration<ListviewComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ListviewComponent, "app-listview", never, { "height$": { "alias": "height$"; "required": false; }; "loading$": { "alias": "loading$"; "required": false; }; "data$": { "alias": "data$"; "required": false; }; "removeDataItem$": { "alias": "removeDataItem$"; "required": false; }; "resetStates$": { "alias": "resetStates$"; "required": false; }; "showListHeader": { "alias": "showListHeader"; "required": false; }; "showAddBtn": { "alias": "showAddBtn"; "required": false; }; "showEditBtn": { "alias": "showEditBtn"; "required": false; }; "showSaveBtn": { "alias": "showSaveBtn"; "required": false; }; "showCancelBtn": { "alias": "showCancelBtn"; "required": false; }; "showRemoveBtn": { "alias": "showRemoveBtn"; "required": false; }; "showDeleteBtn": { "alias": "showDeleteBtn"; "required": false; }; "removeBtnTitle": { "alias": "removeBtnTitle"; "required": false; }; "deleteBtnTitle": { "alias": "deleteBtnTitle"; "required": false; }; }, { "addEvent$": "add"; "editEvent$": "edit"; "saveEvent$": "save"; "cancelEvent$": "cancel"; "removeEvent$": "remove"; "deleteEvent$": "delete"; }, never, never, false, never>;
}
export interface IListViewItem {
    description: string;
    key: string | number;
    error?: boolean;
    success?: boolean;
    warning?: boolean;
}
