import { Observable } from 'rxjs';
import { IGiasApiService } from './gias-api.service';
import { CodiciNazioniISO3166, Comune, Provincia } from './models';
import * as i0 from "@angular/core";
export declare class GiasIstatService {
    private apiService;
    Provincie: Provincia[];
    ComunixProv: Map<string, Comune[]>;
    Stati: CodiciNazioniISO3166[];
    constructor(apiService: IGiasApiService);
    getProvincie(): Provincia[];
    getStati(): CodiciNazioniISO3166[];
    leggiProvincie(Stato_Cod: string, regione?: string): Promise<Provincia[]>;
    readProvinces(Stato_Cod: string, regione?: string): Observable<Provincia[]>;
    readRegioni(cod_stato: string): Observable<any[]>;
    readRegionsByProvince(prov: string): Observable<any>;
    /**
     * @deprecated use readCities() instead
     */
    leggiComuni(Prov: string): Promise<Comune[]>;
    readCities(province: string): Observable<Comune[]>;
    /**
     * @deprecated use readCountries() instead
     */
    leggiStati(): Promise<CodiciNazioniISO3166[]>;
    readCountries(): Observable<CodiciNazioniISO3166[]>;
    /**
     * @deprecated use readPostalCode() instead
     */
    leggiCAP(Prov: string, Com: string): Promise<string>;
    readPostalCode(province: string, city: string): Observable<string>;
    static ɵfac: i0.ɵɵFactoryDeclaration<GiasIstatService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<GiasIstatService>;
}
