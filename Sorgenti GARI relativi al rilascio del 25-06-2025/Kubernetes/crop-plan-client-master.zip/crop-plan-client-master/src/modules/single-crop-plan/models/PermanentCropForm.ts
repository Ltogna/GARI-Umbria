export interface PermanentCropFormMap<
    T extends Vue.Component | PermanentCropForm | PermanentCropFormData | string | boolean | null
> {
    VINEYARD_FORM?: VineyardForm | T;
}

export type PermanentCropFormType = keyof PermanentCropFormMap<null>;

export interface PermanentCropForm {
    formType: PermanentCropFormType;
    formCode: string | null;
    permanentCropFormData: PermanentCropFormData | null;
}

export interface PermanentCropFormOut {
    formType: PermanentCropFormType;
    formCode: string | null;
    permanentCropFormData: PermanentCropFormDataOut | null;
}

export type PermanentCropFormData = VineyardForm; // union with specific forms
export type PermanentCropFormDataOut = VineyardFormUpsertDTO; // union with specific forms

export interface PermanentCropField {
    fieldCode: string;
    fieldValues: PermanentCropFieldValues[];
}
export interface PermanentCropFieldValues {
    fieldValue: string;
    fieldValueDescription: string;
}

export interface VineyardForm {
    altitudeAboveSeaLevel: number | null;
    areaSqm: number | null;
    bio: string | null;
    covering: string | null;
    cultivationState: string | null;
    cultivationTypeCode: string | null;
    distanceBetweenRowsCm: number | null;
    distanceOnTheRowCm: number | null;
    externalDescription: string | null;
    externalCode: string | null;
    failuresPerc: number | null;
    farmingForm: string | null;
    graftDate: Date | null;
    graftHolder: string | null;
    headerAnchoring: string | null;
    irrigation: string | null;
    judgement: string | null;
    layering: string | null;
    origin: string | null;
    plantingType: string | null;
    plantingYear: number | null;
    shiftInYears: number | null;
    expectedCuttingDate: Date | null;
    polesDistanceCm: number | null;
    polesHeader: string | null;
    polesWeaving: string | null;
    productDestinationCode: string | null;
    pruning: string | null;
    protectionStructures: string | null;
    qualitySystem: string | null;
    rock: string | null;
    skeleton: string | null;
    soilLayeringPerc: number | null;
    stumpsDensity100: number | null;
    stumpsNumber: number | null;
    subscriptionCodes: string | null;
    supportWires: string | null;
    terracing: string | null;
    varietyCode: string | null;
    variationTypeCode: string | null;
    vegetativeState: string | null;
    vineyardTypeCode: string | null;
}

export interface VineyardFormUpsertDTO extends Omit<VineyardForm, "graftDate" | "expectedCuttingDate"> {
    graftDate: string | null;
    expectedCuttingDate: string | null;
}

export interface SubscriptionField {
    label: string;
    value: string;
}

export interface Subscription {
    code: string;
    description: string;
    fields: SubscriptionField[];
}

export interface VineyardPropertyRules {
    [key: string]: string[]; // All properties are arrays of strings
}
