export interface UnitsOfMeasure {
    basicUoms: UnitOfMeasurement[];
    perAreaUoms:  UnitOfMeasurement[];
}

export interface UnitOfMeasurement {
    uomLabel: string;
    uomCode: string;
    perArea: boolean;
}

export enum UomType
{
    VOLUME = "VOLUME",
    WEIGHT = "WEIGHT"
}