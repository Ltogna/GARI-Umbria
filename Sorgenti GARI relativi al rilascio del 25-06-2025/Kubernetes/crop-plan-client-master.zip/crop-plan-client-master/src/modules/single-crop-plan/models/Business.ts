export interface Business {
    businessId: string;
    code: string;
    description: string;
}
