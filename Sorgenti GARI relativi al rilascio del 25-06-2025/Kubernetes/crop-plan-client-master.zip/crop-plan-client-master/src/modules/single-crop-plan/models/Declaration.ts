import { Anomaly, LandUse, LandUseAdditionalDataField, Parcel, Plot } from "./Plot";
import { PermanentCropForm, PermanentCropFormOut } from "./PermanentCropForm";
import { ValidationMessage } from "./Utils";
import { UomType } from "./UnitOfMeasure";
import { VINEYARD_FORM } from "../../../shared/constants";
import { LandUseCodeWithRotation } from "./LandUse";

export interface GeneralTimeline {
    changingPoints: ChangingPoint[];
}

export interface ChangingPoint {
    date: Date;
    flAdded: number;
    flModified: number;
    flDeleted: number;
}

export interface Timeline {
    plotCode: string;
    areas: TimelineArea[];
    decls: Declaration[];
}
export interface TimelineArea {
    areaSqm: number;
    geom: string;
    fromDate: Date;
    toDate: Date;
}

export interface DeclarationResponse {
    declaration: Declaration;
    validationMessages: ValidationMessage[];
}

export interface Declaration {
    declCode: number;
    landuse: LandUse;
    areaPerc: number;
    areaSqm: number | null;
    style: { fillColor: string; borderColor: string };
    fromDate: Date;
    toDate: Date;
    permanentCropForms: PermanentCropForm[];
    anomalies: Anomaly[];
    fromDatePrecision: string;
    pesticides: Pesticide[];
    fieldsCodes: LandUseAdditionalDataField[];
}

export interface DeclarationOut {
    landuseCode: string | undefined;
    areaPerc: number | undefined;
    fromDate: Date | null;
    toDate: Date | null;
    permanentCropForms?: PermanentCropForm[];
    fieldsCodes?: LandUseAdditionalDataField[];
}

export interface DeclarationSingleScopeDate {
    day: number | undefined;
    month: number | undefined;
    year: number | undefined;
}

export interface MultipleDeclarationOut extends DeclarationOut {
    plots: {
        plotCode: string;
        areaPerc: number;
    }[];
}

export function toDeclarationOut(e: Declaration): DeclarationOut {
    return {
        landuseCode: e.landuse ? e.landuse.code : undefined,
        areaPerc: e.areaPerc === 0 || e.areaPerc ? e.areaPerc : undefined,
        fromDate: e.fromDate ? e.fromDate : null,
        toDate: e.toDate ? e.toDate : null,
        fieldsCodes: e.fieldsCodes ? e.fieldsCodes : undefined,
        permanentCropForms: e.permanentCropForms ? e.permanentCropForms : undefined,
    };
}

export interface TimelineSection {
    id: number;
    start: Date;
    end: Date;
    area: number | null;
    title: string;
    colture_code: string;
    text: string | null;
    percentage: number | null;
    distance_on_the_row: number | null;
    distance_between_rows: number | null;
    stumpsNumber?: number | null;
    externalCode: string | null;
    externalDescription: string | null;
    planting_form: string | null;
    anomalies: Anomaly[];
    fieldsCodes: LandUseAdditionalDataField[];
    permanentCropForms: string[];
    vineyardProductDestinationCode: string | null;
    declCode: number;
}

export interface TimelineSectionUI extends TimelineSection {
    position: number;
    column: number | null;
    condensed: boolean;
    anomalies: Anomaly[];
}

export function toTimelineSectionUI(e: TimelineSection): TimelineSectionUI {
    return {
        id: e.id,
        start: e.start,
        end: e.end,
        area: e.area,
        title: e.title,
        colture_code: e.colture_code,
        text: e.text,
        percentage: e.percentage,
        position: 0,
        column: null,
        condensed: false,
        stumpsNumber: e.stumpsNumber,
        distance_on_the_row: e.distance_on_the_row,
        distance_between_rows: e.distance_between_rows,
        externalCode: e.externalCode,
        externalDescription: e.externalDescription,
        planting_form: e.planting_form,
        anomalies: e.anomalies,
        permanentCropForms: e.permanentCropForms,
        fieldsCodes: e.fieldsCodes,
        vineyardProductDestinationCode: e.vineyardProductDestinationCode,
        declCode: e.declCode,
    };
}

export function toTimelineSection(e: Declaration, totalArea: number, index: number): TimelineSection {
    if (e.permanentCropForms && e.permanentCropForms.length > 0) {
        const vineyardForm = e.permanentCropForms.find((form: PermanentCropForm) => form.formType === VINEYARD_FORM);
        return {
            id: e.declCode,
            start: e.fromDate,
            end: e.toDate,
            area: e.areaSqm,
            title: e.landuse.description || e.landuse.code,
            colture_code: e.landuse.code,
            text: null,
            percentage: e.areaPerc,
            distance_on_the_row:
                vineyardForm && vineyardForm.permanentCropFormData
                    ? vineyardForm.permanentCropFormData.distanceOnTheRowCm
                    : null,
            distance_between_rows:
                vineyardForm && vineyardForm.permanentCropFormData
                    ? vineyardForm.permanentCropFormData.distanceBetweenRowsCm
                    : null,
            stumpsNumber:
                vineyardForm && vineyardForm.permanentCropFormData
                    ? vineyardForm.permanentCropFormData.stumpsNumber
                    : null,
            externalCode:
                vineyardForm && vineyardForm.permanentCropFormData
                    ? vineyardForm.permanentCropFormData.externalCode
                    : null,
            externalDescription:
                vineyardForm && vineyardForm.permanentCropFormData
                    ? vineyardForm.permanentCropFormData.externalDescription
                    : null,
            planting_form:
                vineyardForm && vineyardForm.permanentCropFormData
                    ? vineyardForm.permanentCropFormData.farmingForm
                    : null,
            anomalies: e.anomalies,
            permanentCropForms: e.permanentCropForms.map((permanentCropForm) => permanentCropForm.formType),
            fieldsCodes: e.fieldsCodes,
            vineyardProductDestinationCode:
                vineyardForm && vineyardForm.permanentCropFormData
                    ? vineyardForm.permanentCropFormData.productDestinationCode
                    : null,
            declCode: e.declCode,
        };
    } else
        return {
            id: index,
            start: e.fromDate,
            end: e.toDate,
            area: e.areaSqm || null,
            title: e.landuse.description || e.landuse.code,
            colture_code: e.landuse.code,
            text: null,
            percentage: e.areaPerc,
            distance_on_the_row: null,
            distance_between_rows: null,
            stumpsNumber: null,
            externalCode: null,
            externalDescription: null,
            planting_form: null,
            anomalies: e.anomalies,
            permanentCropForms: e.permanentCropForms.map((permanentCropForm) => permanentCropForm.formType),
            fieldsCodes: e.fieldsCodes,
            vineyardProductDestinationCode: null,
            declCode: e.declCode,
        };
}

// Interface created for a possible expansion
export interface SinglePlotPeriod {
    plot: PlotPeriodsData | null;
}

// Interface created for a possible expansion
export interface MultiplePlotPeriod {
    code: string;
    isOpen: boolean;
    plot: PlotPeriodsData;
    percentage: number | null;
}

export interface PeriodArea {
    id: string;
    areaSqm: number | null;
}

export interface PlotPeriod {
    id: string;
    areaSqm: number;
    declaredAreaPerc: number;
    date: Date;
}

export interface PlotPeriodsData {
    plotCode: string;
    declaredAreas: PlotPeriod[];
    maxDeclarableAreaPerc: number;
    totalDeclarableAreaPerc: number;
}

export interface PlotRanges {
    minFromDate: Date;
    maxToDate: Date;
}

export interface CropPlanArea {
    totalPlotsAreaSqm: number;
    areaPerc: number;
    domainPlotsAreaSqm: number;
    domainAreaPerc: number;
}

export interface Pesticide {
    productName: string | null;
    productCode: string | null;
    plantProtectionProductType: string | null;
    activeSubstanceConcentrationAmount: number | null;
    activeSubstanceConcentrationAmountUom: string | null;
    uomType: UomType | null;
    entryDate?: Date;
    userId?: string;
}

export interface PesticideOut {
    productCode: string | undefined;
    uomCode: string | undefined;
    amount: number | null;
    date?: string | undefined;
}

export interface PesticideEntry {
    amount: number;
    entryDate: Date | null;
    declCode: string;
    declaration: Declaration;
    pesticideEntryCode: string;
    planId: number;
    plotCode: string;
    productCode: string;
    productName: string;
    uomCode: string;
    uomLabel: string;
    parcelIntersection: Parcel[];
}

export interface PesticideFilter {
    productName: string | null;
    landUse: string | null;
}

export function EmptyPesticideFilter() {
    return {
        productName: null,
        landUse: null,
    };
}

export function toPesticideOut(pesticideEntry: PesticideEntry): PesticideOut {
    return {
        productCode: pesticideEntry.productCode,
        uomCode: pesticideEntry.uomCode ? pesticideEntry.uomCode : undefined,
        amount: pesticideEntry.amount,
    };
}

export interface Pest {
    pestCode: string | null;
    pestName: string | null;
    quarantineDays?: number | null;
    actions?: string | null;
    entryDate?: Date;
    userId?: string;
}

export interface PestEntry {
    pestEntryCode: string;
    pestCode: string;
    pestName: string;
    areaAffected: number;
    measuresApplied: string;
    entryDate: Date | null;
    declCode: string;
    declaration: Declaration;
    planId: number;
    plotCode: string;
    userId: string;
    parcelIntersection: Parcel[];
    plotAreaSqm: number;
    quarantineDays: string | null;
}

export interface PestOut {
    pestCode: string | undefined;
    areaAffected: number | null;
    measuresApplied: string | null;
    date?: string | undefined;
}

export function toPestOut(pestEntry: PestEntry): PestOut {
    return {
        pestCode: pestEntry.pestCode,
        areaAffected: pestEntry.areaAffected,
        measuresApplied: pestEntry.measuresApplied,
    };
}

export interface CadastralData {
    areaSqm: number | null;
    geom: string | null;
    hasUnar: boolean;
    hasUnimm: boolean;
    holdingCount: number;
    holdingPercentage: number;
    holdingType: string | null;
    holdingTypeDescription: string | null;
    mbrOverview: string | null;
    parcel: string;
    parcelType: string | null;
    parcelTypeDescription: string | null;
    sectorBlock: string;
    srs: string | null;
}

export interface CadastralOverlap {
    domainZoneCode1: string;
    domainZoneCode2: string;
    domainZoneDescription1: string;
    domainZoneDescription2: string;
    geom: string | null;
    overlapAreaSqm: number;
    parcel1: string;
    parcel2: string;
    sectorBlock1: string;
    sectorBlock2: string;
    srs: string | null;
}

export interface ParcelData {
    areaSqm: number;
    description: string | null;
    geom: string;
    hasUnar: boolean | null;
    hasUnimm: boolean | null;
    holdingCount: number | null;
    holdingPercentage: number;
    holdingType: string | null;
    holdingTypeDescription: string | null;
    mbrOverview: string;
    parcelCode: string;
    parcelType: string | null;
    parcelTypeDescription: string | null;
    sectorBlock: string;
    srs: string;
    landCovers: { landCoverCode: string; landCoverDescription: string | null }[];
    anomalies: Anomaly[];
}

export interface CopyOrMoveDeclarationsPayload {
    pointInTime: string;
    sourcePlotCode: string;
    sourceDeclCodes: string[];
    destPlotCode: string;
    removeSourceDecls: boolean;
}

export interface CopyOrMoveDeclarationsResponse {
    validationMessages: ValidationMessage[];
    sourceUpdatedPlot: Plot | null;
    destUpdatedPlot: Plot;
    sourceDeclarationsAlreadyExisting: Declaration[];
}

export type AnomalieStatus = "all" | "some" | "none";

export interface LandUseAnomalyStatus {
    landUseCode: string;
    status: AnomalieStatus;
}

export interface DomainZonePlotDeclarationResponse {
    anomalies: Anomaly[];
    plotCode: string;
    declId: number;
    declCode: string;
    landUse: { code: string; description: string };
    areaPerc: number;
    declAreaSqm: number;
    rotation: number;
    dayFrom: Date;
    dayFromPrecision: string;
    dayTo: Date;
}

export interface DomainZonePlotDeclaration extends DomainZonePlotDeclarationResponse {
    domainZoneId: string;
    domainZoneDescription: string;
    _uniqueLandUseCode: string;
}

export interface DomainZonePlot {
    domainZoneId: string;
    domainZoneDescription: string;
    plotCode: string;
    decls: DomainZonePlotDeclarationResponse[];
}

export interface BulkDeclarationFieldsUpdatate {
    domainZoneIds: string[];
    landUseCodeWithRotationDtos: LandUseCodeWithRotation[];
    permanentCropForms?: PermanentCropForm[];
    fields?: LandUseAdditionalDataField[];
}

export interface ExcludeFromCopyCampaignLanduse {
    landuse: LandUse;
    excludedFromAggregation: boolean;
}

export interface CopyCampaignPayload {
    /** The source crop plan id */
    sourceCropPlanId: number;
    /** The source crop plan version (if null then current plan in progress is used) */
    sourceVersion?: string;
    /** The source point in time */
    sourcePointInTime: string;
    /** The destination point in time */
    destPointInTime: string;
    /** The list of land use codes to be excluded from aggregation */
    landuseCodesExcludedFromAggregation?: string[];
    flCopyFromOtherBusinesses?: boolean;
    preserveSourceDeclDates: boolean;
}
