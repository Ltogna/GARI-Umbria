export interface Version {
    flPublished: boolean;
    cropPlanId: number;
    version: string;
    versionDate: Date;
    versionReferenceDate: string;
    message: string;
    userId: string;
}

export interface VersionOut {
    message: string | undefined;
    havingAcknowledgedAnomalies: boolean;
    forcePublish: boolean;
    pointInTime: string | undefined;
}
