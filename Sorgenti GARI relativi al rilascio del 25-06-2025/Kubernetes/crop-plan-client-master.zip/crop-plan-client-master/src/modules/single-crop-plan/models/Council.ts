export interface Council {
    domainZoneId: string;
    code: string;
    description: string;
    srs: string;
    mbr: { xmin: number; ymin: number; xmax: number; ymax: number };
    bigDomainZone: boolean;
}

export interface SubdomainZone {
    id: number;
    gemo: string;
}