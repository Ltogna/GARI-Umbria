export interface CadastralParcel {
    description: string;
    srs: string;
    geom: string;
}
