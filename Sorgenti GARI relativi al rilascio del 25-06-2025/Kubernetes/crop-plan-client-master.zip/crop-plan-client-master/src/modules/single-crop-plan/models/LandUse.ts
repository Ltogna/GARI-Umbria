import { LandUseAdditionalDataConf, PermanentCropFormConfig } from "./Plot";


export interface LandUseListItem {
    domainZoneIds: string[];
    domainZoneDescription: string;
    declCode: string;
    landUse: { code: string; description: string };
    rotation: number;
    declAreaSqm: number;
    _uniqueLandUseCode: string;
    _selected: boolean;
}

export interface CommonConfigAndValues {
    landUseAdditionalDataConfigs: LandUseAdditionalDataConf[];
    permanentCropFormConfigs: PermanentCropFormConfig[];
}

export interface LandUseCodeWithRotation {
    landUseCode: string;
    rotation: number;
}