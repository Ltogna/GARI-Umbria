import { ResponseDiff } from "./Utils";
import { PermanentCropForm } from "./PermanentCropForm";

export interface Anomaly {
    blocking: boolean;
    errorCode: string;
    description: string;
    objectCode: string;
    errorDescription?: string | null;
    objectType: string;
}
export interface PlotResponse {
    anomalies: Anomaly[];
    plotCode: string;
    description: string | null;
    parcelIntersections: Parcel[];
    areaSqm: number;
    geom: string;
    decls: PlotDeclaration[];
    style: { fillColor: string; borderColor: string; fillStyle: string| undefined } | null;
    fromDate: Date;
    toDate: Date;
    fullRangeFromDate: Date;
    fullRangeToDate: Date;
    editability: Editability;
    mbrOverview: string;
    notes: string | null;
}

export interface Plot extends Omit<PlotResponse, "style"> {
    style: { fillColor: string; borderColor: string; fillStyle: string | undefined };
}

export interface PlotStyleOverride {
    plotCode: string;
    style: { fillColor: string | CanvasPattern; borderColor: string };
}

export type Editability = "NOT_EDITABLE" | "ONLY_DECLARATIONS" | "EDITABLE";

export interface Parcel {
    areaSqm: number;
    code: string;
    notes: string | null;
    description: string;
    landCoverCode: string;
    landCoverDescription: string;
    parcelCode?: string;
    anomalies?: Anomaly[];
    canDeclarePesticides?: boolean;
}

export interface PlotDeclaration {
    anomalies: Anomaly[];
    declCode: number;
    landuse: LandUse;
    areaPerc: number;
    style: { fillColor: string; borderColor: string };
    fromDate: Date;
    toDate: Date;
    permanentCropForms?: PermanentCropForm[];
}

export interface TargetPlotDeclaration {
    anomalies: Anomaly[];
    declCode: number;
    landuse: LandUse;
    areaPerc: number;
    style: { fillColor: string; borderColor: string };
    fromDate: Date;
    toDate: Date;
    areaSqm: number;
    formattedArea: string;
}

export enum LandUseAdditionalFieldType {
    COMBO,
}

export interface LandUseAdditionalDataField {
    fieldCode: string;
    fieldDescription: string;
    dayFrom: Date | string;
    dayTo: Date | string;
    sortOrder: number;
    value: string | null;
    valueDescription: string;
    flShowInTooltip: boolean;
}

export interface LandUseAdditionalDataConf {
    landUseCode: string;
    landUseDescription: string;
    fieldCode: string;
    fieldDescription: string;
    fieldType: LandUseAdditionalFieldType;
    validFrom: Date;
    validTo: Date;
    sortOrder: number;
    defaultValue: string | null;
    nullable: boolean;
    allowedValues: LandUseAdditionalDataField[];
    groupCode: string;
    selectedValue?: LandUseAdditionalDataField;
    flEditable: boolean;
    headerTitleCode: string | null;
    headerTitleDescription: string | null;
    formula: string | null;
}

export interface PermanentCropFormValueConfig {
    fieldCode: string;
    flMandatory: boolean;
    flEditable: boolean;
}

export interface PermanentCropFormConfig {
    formType: string;
    fields: PermanentCropFormValueConfig[];
}

export interface LandUse {
    code: string;
    description: string | null;
    defaultHarvestDays: number | null;
    defaultFromDate: Date | null;
    landUseClass: LandUseClass;
    formsConfig?: PermanentCropFormConfig[];
    isFavourite?: boolean;
}

export interface SwappableLandUse {
    code: string;
    description: string | null;
    defaultHarvestDays: number | null;
    defaultFromDate: Date | null;
    landUseClass: LandUseClass;
    formsConfig?: PermanentCropFormConfig[];
    isFavourite?: boolean;
    declarationFromDate: Date;
}

export type LandCoverFilterIn = {
    enabledByDefault: boolean;
    filterLandCoverCodes: LandCoverFilter[];
    landCoverDescription: string;
};

export interface LandUseClass {
    landUseClassCode: string;
    landUseClassDescription: string;
    percFixedTo100: boolean;
    permanent: boolean;
}

export interface LandCover {
    landCoverCode: string;
    landCoverDescription: string;
}

export interface LandCoverFilter {
    withWarnings: boolean;
    landCoverCode: string;
}

export interface PlotFilter {
    search: string | null;
}

export interface PlotBuffer {
    bufferSize: number;
}

export interface PlotPreviewDiff {
    added: PlotPreview[];
    deleted: string[];
    updated: PlotPreview[];
    coveredByInserted: string[];
}

export interface PlotPreview {
    plotCode: string;
    geom: string;
}

export function EmptyPlotFilter() {
    return {
        search: null,
    };
}

export interface PlotOut {
    fromPointInTime: Date;
    geom: string;
    cutParameters: CutParameters;
    description?: string;
}

export interface CutParameters {
    behaviour: string;
    plotCodes: string[] | null;
}

export enum PlotBehaviour {
    "CUT_ON_EXISTING" = "CUT_ON_EXISTING",
    "CUT_EXISTING" = "CUT_EXISTING",
}

export enum EditPlotMode {
    EDITING,
    ADDING,
    CUTTING,
    MERGING,
    DELETING,
    RESTORING,
    ADDING_BUFFER,
    NOT_SELECTED,
    MULTISELECTION,
}

export interface CuttableLayer {
    layerCode: string;  
    flMergeGeomsOnCutOnLayer: boolean;
    flCalcCoveredByInsertedOnCutOnLayer: boolean;
}

export type BufferBehaviour = "INTERNAL" | "EXTERNAL" | "FREE_DRAW";

export type CopyOrMove = "COPY" | "MOVE";
// export function toPlotOut(e: Plot): PlotOut {
//     return {
//         fromPointInTime: undefined,
//         description: e.description ? e.description : undefined,
//         geom: e.geom ? e.geom : undefined,
//         cutParameters: undefined,
//     }
// }

export interface PlotEditOut {
    description: string | undefined;
}
export function toPlotEditOut(e: Plot): PlotEditOut {
    return {
        description: e.description ? e.description : undefined,
    };
}

export type PlotResponseDiff = ResponseDiff<Plot, string, Plot, string>;
