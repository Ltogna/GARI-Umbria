export interface CropPlan {
    cropPlanId: number;
    cropPlanTypeCode: string;
    cropPlanTypeDescription: string;
    description: string;
    changesPending: boolean;
    lastEditingDate?: Date;
    readOnly: boolean;
    canAddPlots: boolean;
    cropPlanPrints: CropPlanPrints[];
    locked?: boolean;
    lockedErrorCode?: string;
}

export interface CropPlanPrints {
    code: string;
    description: string;
}

export interface CropPlanTypesDTO {
    cropPlanTypeCode: string;
    description: string;
    multiple: boolean;
    dayFrom: string | null;
    dayTo: string | null;
}
export interface CropPlanType {
    cropPlanTypeCode: string;
    description: string;
    multiple: boolean;
    dayFrom: Date | null;
    dayTo: Date | null;
}

export interface CropPlanOut {
    cropPlanTypeCode: string;
    description: string;
}

export interface CropPlanDates {
    fixedOpenDate: string | null;
    fixedEditDate: string | null;
    referenceDate: string;
    campaignStartDate: string | null;
    lastSyncReferenceDate: string | null;
}

export interface SyncResponse {
    syncProgressStatus: SyncStatus;
    syncType: string;
    withErrors: boolean;
}

export interface Configuration extends Record<string, unknown> {
    ALLOW_DECLS_PERC_TO_ZERO?: string | null;
    CLEAR_DECL_END_DATE_WHEN_START_DATE_IS_CHANGED?: string;
    CONSTRAINTS_DECLS_PERC_TO_100?: string;
    CONSTRAINTS_DECLS_TO_PLOTS?: string;
    CONSTRAINTS_VERSION_TO_SYNC_REF_DATE?: string | null;
    COPY_DECLARATIONS_AT_DATE?: string | null;
    DECLS_PERCENTAGE_NUM_OF_DECIMALS?: number | null;
    DISABLE_ADD_DECLARATIONS?: string | null;
    DISABLE_CHANGE_DATE?: string;
    DISABLE_CHANGE_DATE_WHEN_READ_ONLY?: string | null;
    DISABLE_DELETE_DECLARATIONS_IF_EXTERNAL?: string | null;
    DISABLE_PERMANENT_CROP_EXTIRPATION?: string;
    DISABLE_PUBLISH_CROP_PLAN?: string;
    DISABLE_VALID_VALUED_DECL_FIELDS_EDIT?: string | null;
    DISABLE_VALUED_DECL_FIELDS_EDIT?: string | null;
    ENABLE_ALL_COUNCILS_SELECTION?: string;
    ENABLE_BULK_DECLARATIONS_FIELDS_EDIT?: string | null;
    ENABLE_COPY_CAMPAIGN?: string | null;
    ENABLE_COPY_DECLARATIONS_FROM_VERSION?: string | null;
    ENABLE_DECLARATIONS_COPY_ON_MULTIPLE_PLOTS?: string;
    ENABLE_DECLARATIONS_MERGE?: string | null;
    ENABLE_DECLARATIONS_REPROPORTION?: string | null;
    ENABLE_DECLARATIONS_REPROPORTION_WHEN_NOT_EDITABLE?: string;
    ENABLE_DECLARATIONS_SWAP?: string | null;
    ENABLE_DEFAULT_NOT_PRESERVE_DECLS_ON_PLOTS_MERGE?: string | null;
    ENABLE_FAVOURITES_LAND_USES?: string | null;
    ENABLE_FORCED_SYNC?: string;
    ENABLE_INFO_GIS?: string;
    ENABLE_PARCELS_NOTES?: string | null;
    ENABLE_PESTICIDES?: string;
    ENABLE_PESTS?: string;
    ENABLE_PLACES_SEARCH?: string;
    ENABLE_PLOT_EDIT_DATE_WARNING?: string | null;
    ENABLE_PUBLICATIONS_LIST?: string;
    ENABLE_RESTORE_LAST_VERSION?: string | null;
    ENABLE_RESTORE_PLOT_DEFAULT?: string;
    ENABLE_RESUME_PLOT_FROM_FIRST_CROP_PLAN_VERSION?: string;
    FIELDS_LAYER_DESCRIPTION?: string | null;
    FORCE_DEFAULT_HARVEST_DATE_FOR_PERMANENT_DECL?: string | null;
    HIDE_LAND_USE_DEFAULT_HARVEST_DATE?: string | null;
    HIDE_PARCELS?: string;
    HIDE_PLOTS_NAMES?: string | null;
    HIDE_PLOTS_NOTES?: string | null;
    INVALID_LAND_USE_CODES?: string | null;
    LINEAR_ELEMENTS?: string;
    LOCK_DECLARATIONS_FIELDS_IF_EXTERNAL?: string | null;
    MANDATORY_PLANTING_DATE_PRECISION?: string | null;
    MAX_ZOOM?: number | null;
    PLOTS_OUT_OF_FILTER_BACKGROUND_STYLE?: string;
    PRESERVE_PERMANTENT_CROP_FORM_DATA?: string | null;
    RESTORE_PLOTS_AT_CAMPAIGN_START_DATE?: string | null;
    RESTORE_PLOTS_PROPAGATING_BEHAVIOUR?: string | null;
    SHOW_DECLS_AREA_IN_PLOTS_LIST?: string | null;
    SYNC_TYPE_ON_OPEN?: string;
    TARE_LAND_USE_CODE?: string | null;
    DISABLE_CHECK_ON_MANDATORY_DECL_FIELDS?: string | null;
    CAMPAIGN_REF_DATE?: string | null;
    ENABLE_PLOT_EDIT_BUFFER?: string | null;
}



export type SyncStatus = "IN_PROGRESS" | "COMPLETED";

export interface DomainZone {
    domainZoneId: string;
    code: string;
    description: string;
}

export interface CropPlanAnomaly {
    blocking: boolean;
    errorCode: string;
    errorDescription?: string | null;
    numOfAnomalies: number;
    objectType: string;
    baseDomainZoneList: DomainZone[];
}

export interface GroupedAnomaly {
    anomalies: CropPlanAnomaly[];
    numOfBlockingAnomalies: number;
    numOfNonBlockingAnomalies: number;
}

export interface PrintStatus {
    printProgressStatus: "IN_PROGRESS" | "COMPLETED";
    withErrors: boolean;
}

export type FunctionCode =
    | "ADD_DECLARATIONS"
    | "CUT_PLOTS"
    | "DELETE_DECLARATIONS"
    | "DELETE_PLOTS"
    | "EDIT_DECLARATIONS"
    | "EDIT_PLOTS"
    | "MERGE_DECLARATIONS"
    | "REPROPORTION_DECLARATIONS"
    | "MULTISELECTION_PLOTS";

export interface AnomaliesScenarioConfiguration {
    scenario: string;
    functionsDisabledConfig: {
        functionCode: FunctionCode;
    }[];
    scenarioAnomaliesConfig: {
        anomaliyCode: string;
        fl_present: boolean | null;
    }[];
}

export interface CompleteWithTareDates {
    minFromDate: string;
    maxToDate: string;
}

export interface DomainZoneListItem extends DomainZone {
    _selected?: boolean;
}

export enum SyncProgressStatus {
    "IN_PROGRESS" = "IN_PROGRESS",
    "COMPLETED" = "COMPLETED",
}