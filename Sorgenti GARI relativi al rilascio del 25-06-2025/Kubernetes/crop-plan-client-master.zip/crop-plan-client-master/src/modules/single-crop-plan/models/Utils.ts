export interface ResponseDiff<A, D, U, C> {
    added: A[] | null;
    deleted: D[] | null;
    updated: U[] | null;
    coveredByInserted: C[] | null;
    validationMessages: ValidationMessage[];
    alertCodes: string[];
}

export interface ValidationMessage {
    message: string;
    blocking: boolean;
}

export interface AppLoadingItem {
    id: symbol;
    message?: string;
}