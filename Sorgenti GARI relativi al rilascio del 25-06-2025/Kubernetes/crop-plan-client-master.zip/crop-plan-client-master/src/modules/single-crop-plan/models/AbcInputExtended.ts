
import AbcInput from "@abaco/web-components/src/components/input/AbcInput.vue";

export interface AbcInputExtended extends AbcInput {
    runRules(input?: unknown): void;
}

export interface AbcDateInputExtended extends AbcInput {
    runInputRules(input?: unknown): void;
}