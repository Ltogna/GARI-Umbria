import { LayerDef } from "@abaco/iacs-map-module/src/modules/map-module/Layer/GenericLayer";

export interface SnapGeometryDef {
    types: SnapPolygon[];
    geometries: SnapGeometry[];
}

export interface SnapPolygon {
    type: string;
    description: string;
    flMergeGeomsOnCutOnLayer: boolean;
    flCalcCoveredByInsertedOnCutOnLayer: boolean;
}

export interface SnapGeometry {
    id: string;
    type: string;
    description: string;
    geom: string;
    tooltipData: { [k: string]: string } | null;
}

export interface LayerDefIn extends LayerDef {
    legendOrder: number;
}

export interface GisInfo {
    layerCode: string;
    title: string;
    cards: GisInfoCard[];
}

export interface GisInfoCard {
    title: string;
    areaSqm?: number;
    mbr?: string;
    fields?: {
        label: string;
        value: string;
    }[];
}
