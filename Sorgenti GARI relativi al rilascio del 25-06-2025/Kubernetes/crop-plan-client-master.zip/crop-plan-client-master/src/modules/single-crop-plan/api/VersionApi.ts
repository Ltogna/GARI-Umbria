import { HTTPClient } from "@abaco/web-common/src/HTTP";
import { NextPagedResults } from "@abaco/web-common/src/Paging";
import { Version, VersionOut } from "../models/Version";
import { formatDate } from "./Utils";

export default class VersionApi {
    private http: HTTPClient;
    private rootPath: string;

    constructor(http: HTTPClient, rootPath: string) {
        this.http = http;
        this.rootPath = rootPath;
    }

    public async getVersions(
        businessId: string | null,
        cropPlanId: number,
        nextKey: string | undefined | null,
        referenceDate?: Date,
        ignoreCropPlanId?: boolean
    ): Promise<NextPagedResults<Version>> {
        const res = await this.http.get(`${this.rootPath}/v1/crop-plans/${businessId}/plans/${cropPlanId}/versions`, {
            params: {
                nextKey: nextKey ? nextKey : undefined,
                referenceDate: referenceDate ? formatDate(referenceDate) : undefined,
                ignoreCropPlanId : ignoreCropPlanId ? ignoreCropPlanId : false
            },
        });
        res.data.records.forEach((version: Version) => version.versionDate = new Date(version.versionDate));
        return res.data;
    }

    public async insertVersion(
        businessId: string,
        cropPlanId: number,
        detailOut: VersionOut,
    ): Promise<Version> {
        const filterQuery = detailOut.forcePublish ? "?forcePublish=true" : "";
        const res = await this.http.post(
            `${this.rootPath}/v1/crop-plans/${businessId}/plans/${cropPlanId}/versions${filterQuery}`,
            detailOut
        );
        return res.data;
    }

    public async restoreLastVersion(businessId: string, cropPlanId: number) {
        const res = await this.http.put(
            `${this.rootPath}/v1/crop-plans/${businessId}/plans/${cropPlanId}/versions/restore-last`,
        );
        return res.data;
    }
}
