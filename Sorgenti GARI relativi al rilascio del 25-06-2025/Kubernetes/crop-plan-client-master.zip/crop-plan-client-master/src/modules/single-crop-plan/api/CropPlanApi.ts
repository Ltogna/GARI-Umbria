import { HTTPClient } from "@abaco/web-common/src/HTTP";
import { MaxPagedResults, NextPagedResults } from "@abaco/web-common/src/Paging";
import {
    AnomaliesScenarioConfiguration,
    CompleteWithTareDates,
    Configuration,
    CropPlan,
    CropPlanDates,
    CropPlanOut,
    CropPlanType,
    CropPlanTypesDTO,
    PrintStatus,
    SyncResponse,
} from "../models/CropPlan";
import {
    CropPlanArea,
    DeclarationResponse,
    Pest,
    PestEntry,
    PestOut,
    Pesticide,
    PesticideEntry,
    PesticideOut,
} from "../models/Declaration";
import { Subscription } from "../models/PermanentCropForm";
import { UnitsOfMeasure, UomType } from "../models/UnitOfMeasure";
import { formatDate, toDateFromFormat } from "./Utils";

export default class CropPlanApi {
    private http: HTTPClient;
    private rootPath: string;

    constructor(http: HTTPClient, rootPath: string) {
        this.http = http;
        this.rootPath = rootPath;
    }

    public getRootPath() {
        return this.rootPath;
    }

    public async getCropPlans(businessId: string, type: string | null): Promise<CropPlan[]> {
        const cropPlans: CropPlan[] = [];
        let nextKey: string | null = null;
        do {
            const curPage: NextPagedResults<CropPlan> = await this.getCropPlan(businessId, type, nextKey);
            nextKey = curPage.nextKey || null;
            cropPlans.push(...curPage.records);
        } while (nextKey !== null);
        return cropPlans;
    }

    private async getCropPlan(
        businessId: string,
        type: string | null,
        nextKey: string | null
    ): Promise<NextPagedResults<CropPlan>> {
        const filterQuery = type ? `?cropPlanTypeCode=${type.toUpperCase()}` : "";
        const nextPage = await this.http.get(
            `${this.rootPath}/v1/crop-plans/${businessId}/plans${filterQuery}${nextKey ? `&nextKey=${nextKey}` : ``}`
        );
        return nextPage.data;
    }

    // Add get crop plan by id

    public async getCropPlanById(businessId: string, cropPlanId: number): Promise<CropPlan> {
        const url = `${this.rootPath}/v1/crop-plans/${businessId}/plans/${cropPlanId}`;
        const res = await this.http.get(url);
        return res.data;
    }

    public async getCropPlanArea(
        businessId: string,
        cropPlanId: number,
        pointInTime: Date,
        version: string | null,
        domainZoneId: string | undefined
    ): Promise<CropPlanArea> {
        const res = await this.http.get(
            `${this.rootPath}/v1/crop-plans/${businessId}/plans/${cropPlanId}/declared-area`,
            {
                params: {
                    version: version ? version : undefined,
                    pointInTime: formatDate(pointInTime),
                    domainZoneId
                },
            }
        );
        return res.data;
    }

    public async insertCropPlan(businessId: string, detailOut: CropPlanOut): Promise<CropPlan> {
        const url = `${this.rootPath}/v1/crop-plans/${businessId}/plans`;
        const res = await this.http.post(url, detailOut);
        return res.data;
    }

    public async lockCropPlan(businessId: string, cropPlanId: number): Promise<boolean> {
        const res = await this.http.put(`${this.rootPath}/v1/crop-plans/${businessId}/plans/${cropPlanId}/lock`);
        return res.status === 204 || res.status === 200 ? true : false;
    }

    public async syncCropPlan(
        businessId: string,
        cropPlanId: number,
        syncType: string,
        pointInTime: Date,
        ignorePreviousSyncs?: boolean
    ): Promise<SyncResponse> {
        const url = `${this.rootPath}/v1/crop-plans/${businessId}/plans/${cropPlanId}/sync/${syncType}`;
        const params = { ignorePreviousSyncs };
        const res = await this.http.put(url, { pointInTime: formatDate(pointInTime) }, { params });

        return res.data;
    }

    public async getSyncCropPlanStatus(businessId: string, cropPlanId: number): Promise<SyncResponse> {
        const url = `${this.rootPath}/v1/crop-plans/${businessId}/plans/${cropPlanId}/sync/status`;
        const res = await this.http.get(url);
        return res.data;
    }

    public async getCropPlanTypeConfiguration(businessId: string, cropPlanId: number): Promise<Configuration> {
        const res: { paramName: string; paramValue: string }[] = (
            await this.http.get(`${this.rootPath}/v1/crop-plans/${businessId}/plans/${cropPlanId}/config`)
        ).data;
        const mappedConfiguration: Configuration = {};
        res.map((configuration) => {
            mappedConfiguration[configuration.paramName] = configuration.paramValue;
        });
        return mappedConfiguration;
    }

    public async getCropPlanTypes(businessId: string): Promise<CropPlanType[]> {
        const url = `${this.rootPath}/v1/crop-plans/${businessId}/plan-types`;
        const res = await this.http.get(url);
        res.data.forEach((cpt: CropPlanTypesDTO) => toDateFromFormat(cpt,  ["dayFrom", "dayTo"]));
        return res.data;
    }

    public async getCropPlanLastUpdateDate(businessId: string, cropPlanId: number): Promise<Date> {
        const url = `${this.rootPath}/v1/crop-plans/${businessId}/plans/${cropPlanId}/declarations/updates/last-modification-date`;
        const res = await this.http.get(url);
        return res.data;
    }

    public async deleteCropPlan(businessId: string, cropPlanId: number) {
        const url = `${this.rootPath}/v1/crop-plans/${businessId}/plans/${cropPlanId}`;
        const res = await this.http.delete(url);
        return res.data;
    }

    public async updateCropPlan(businessId: string, cropPlan: CropPlan): Promise<CropPlan> {
        const url = `${this.rootPath}/v1/crop-plans/${businessId}/plans/${cropPlan.cropPlanId}`;
        // const res = await this.http.post(url, cropPlan);
        const res = await this.http.put(url, { description: cropPlan.description });
        return res.data;
    }

    public async getPesticidesList(
        businessId: string,
        cropPlanId: number,
        search: string | null,
        landUseCode: string | null
    ): Promise<MaxPagedResults<Pesticide>> {
        const res = await this.http.get(
            `${this.rootPath}/v1/pesticides/${businessId}/plans/${cropPlanId}/available-pesticides`,
            {
                params: {
                    search: search ? search : undefined,
                    landUseCode: landUseCode,
                },
            }
        );
        return res.data;
    }

    public async getPesticideUoms(businessId: string, cropPlanId: number, type: UomType): Promise<UnitsOfMeasure> {
        const res = await this.http.get(
            `${this.rootPath}/v1/pesticides/${businessId}/plans/${cropPlanId}/available-pesticides/units-of-measurment/${type}`,
            {
                params: {
                    offset: 0,
                    count: 300,
                },
            }
        );
        return res.data;
    }

    public async insertPesticide(
        businessId: string,
        cropPlanId: number,
        domainZoneId: string,
        plotCode: string,
        declCode: string,
        detailOut: PesticideOut
    ) {
        const url = `${this.rootPath}/v1/pesticides/${businessId}/plans/${cropPlanId}/zones/${domainZoneId}/plots/${plotCode}/decls/${declCode}/pesticides-entries`;
        const res = await this.http.post(url, detailOut);
        return res.data;
    }

    public async updatePesticide(
        businessId: string,
        cropPlanId: number,
        domainZoneId: string,
        plotCode: string,
        declCode: string,
        pesticideEntryCode: string,
        detailOut: PesticideOut
    ) {
        const url = `${this.rootPath}/v1/pesticides/${businessId}/plans/${cropPlanId}/zones/${domainZoneId}/plots/${plotCode}/decls/${declCode}/pesticides-entries/${pesticideEntryCode}`;
        const res = await this.http.put(url, detailOut);
        return res.data;
    }

    public async getAllPesticides(
        businessId: string,
        cropPlanId: number,
        version: string | null,
        search: string | null,
        nextKey?: string | null
    ): Promise<NextPagedResults<PesticideEntry>> {
        const res = await this.http.get(
            `${this.rootPath}/v1/pesticides/${businessId}/plans/${cropPlanId}/pesticides-entries`,
            {
                params: {
                    version: version ? version : undefined,
                    nextKey: nextKey ? nextKey : undefined,
                    search: search ? search : undefined,
                },
            }
        );
        res.data.records.forEach((e: any) => toDateFromFormat(e, ["entryDate"]));
        return res.data;
    }

    public async deletePesticide(
        businessId: string,
        cropPlanId: number,
        domainZoneId: string,
        plotCode: string,
        declCode: string,
        pesticideEntryCode: string
    ) {
        const url = `${this.rootPath}/v1/pesticides/${businessId}/plans/${cropPlanId}/zones/${domainZoneId}/plots/${plotCode}/decls/${declCode}/pesticides-entries/${pesticideEntryCode}`;
        const res = await this.http.delete(url);
        return res.data;
    }

    public async getPestList(
        businessId: string,
        cropPlanId: number,
        search: string | null,
        landUseCode: string | null
    ): Promise<MaxPagedResults<Pest>> {
        const res = await this.http.get(`${this.rootPath}/v1/pests/${businessId}/plans/${cropPlanId}/pests`, {
            params: {
                search: search ? search : undefined,
                landUseCode: landUseCode,
            },
        });
        return res.data;
    }
    public async insertPest(
        businessId: string,
        cropPlanId: number,
        domainZoneId: string,
        plotCode: string,
        declCode: string,
        detailOut: PestOut
    ) {
        const url = `${this.rootPath}/v1/pests/${businessId}/plans/${cropPlanId}/zones/${domainZoneId}/plots/${plotCode}/decls/${declCode}/pests`;
        const res = await this.http.post(url, detailOut);
        return res.data;
    }
    public async updatePest(
        businessId: string,
        cropPlanId: number,
        domainZoneId: string,
        plotCode: string,
        declCode: string,
        pestEntryCode: string,
        detailOut: PestOut
    ) {
        const url = `${this.rootPath}/v1/pests/${businessId}/plans/${cropPlanId}/zones/${domainZoneId}/plots/${plotCode}/decls/${declCode}/pests-entries/${pestEntryCode}`;
        const res = await this.http.put(url, detailOut);
        return res.data;
    }
    public async getAllPests(
        businessId: string,
        cropPlanId: number,
        version: string | null,
        search: string | null,
        nextKey?: string | null
    ): Promise<NextPagedResults<PestEntry>> {
        const res = await this.http.get(`${this.rootPath}/v1/pests/${businessId}/plans/${cropPlanId}/pests-entries`, {
            params: {
                version: version ? version : undefined,
                nextKey: nextKey ? nextKey : undefined,
                search: search ? search : undefined,
            },
        });
        res.data.records.forEach((e: any) => toDateFromFormat(e, ["entryDate"]));
        return res.data;
    }
    public async deletePest(
        businessId: string,
        cropPlanId: number,
        domainZoneId: string,
        plotCode: string,
        declCode: string,
        pestEntryCode: string
    ) {
        const url = `${this.rootPath}/v1/pests/${businessId}/plans/${cropPlanId}/zones/${domainZoneId}/plots/${plotCode}/decls/${declCode}/pests-entries/${pestEntryCode}`;
        const res = await this.http.delete(url);
        return res.data;
    }

    public async cloneDeclarationsFromPastYear(businessId: string, cropPlanId: number, pointInTime: Date) {
        const url = `${
            this.rootPath
        }/v1/crop-plans/${businessId}/plans/${cropPlanId}/decls/copy-from-previous-year?pointInTime=${formatDate(
            pointInTime
        )}`;
        const res = await this.http.put(url);
        return res.data;
    }

    public async copyDeclarationsFromPreviousVersion(
        businessId: string,
        cropPlanId: number,
        version: string | null,
        pointInTime: Date,
        forceNotCompatibleLandCover: boolean,
        ignoreDeclValidationWarnings: boolean
    ) {
        const body = {
            version: version,
        };

        const params = {
            pointInTime: formatDate(pointInTime),
            forceNotCompatibleLandCover,
            ignoreDeclValidationWarnings,
        };
        const url = `${this.rootPath}/v1/crop-plans/${businessId}/plans/${cropPlanId}/decls/copy-previous-year-from-version`;
        const res = await this.http.put(url, body, { params });
        return res.data;
    }

    public async copyDeclarationsFromCurrentVersion(
        businessId: string,
        cropPlanId: number,
        version: string | null,
        pointInTime: Date,
        forceNotCompatibleLandCover: boolean,
        ignoreDeclValidationWarnings: boolean
    ) {
        const body = {
            version: version,
        };

        const params = {
            pointInTime: formatDate(pointInTime),
            forceNotCompatibleLandCover,
            ignoreDeclValidationWarnings,
        };
        const url = `${this.rootPath}/v1/crop-plans/${businessId}/plans/${cropPlanId}/decls/copy-current-year-from-version`;
        const res = await this.http.put(url, body, { params });
        return res.data;
    }

    public async swapLanduses(
        businessId: string,
        cropPlanId: number,
        domainZoneId: string,
        sourceLandUseCode: string,
        newLandUseCode: string,
        pointInTime: Date,
        sourcePointInTime: Date,
        newFromDate?: Date | null,
        newToDate?: Date | null
    ) {
        const body = {
            sourceLandUseCode: sourceLandUseCode,
            newLandUseCode: newLandUseCode,
            pointInTime: formatDate(pointInTime),
            sourcePointInTime: formatDate(sourcePointInTime),
            newFromDate: newFromDate ? formatDate(newFromDate) : null,
            newToDate: newToDate ? formatDate(newToDate) : null,
        };
        const url = `${this.rootPath}/v1/crop-plans/${businessId}/plans/${cropPlanId}/zones/${domainZoneId}/decls/swap-land-uses`;
        const res = await this.http.post(url, body);
        return res.data;
    }

    public async completeWithTareDates(
        businessId: string,
        cropPlanId: number,
        domainZoneId: string,
        plotCodes: string[],
        pointInTime: Date
    ): Promise<CompleteWithTareDates> {
        const body = {
            plotCodes: plotCodes,
            pointInTime: formatDate(pointInTime),
        };
        const url = `${this.rootPath}/v1/crop-plans/${businessId}/plans/${cropPlanId}/zones/${domainZoneId}/decls/complete-with-tare/dates`;
        const res = await this.http.post(url, body);
        return res.data;
    }

    public async completeWithTare(
        businessId: string,
        cropPlanId: number,
        domainZoneId: string,
        plotCodes: string[],
        fromDate: Date,
        toDate: Date,
        pointInTime: Date,
        ignoreDeclValidationWarnings: boolean
    ): Promise<DeclarationResponse> {
        const body = {
            plotCodes: plotCodes,
            fromDate: formatDate(fromDate),
            toDate: formatDate(toDate),
            pointInTime: formatDate(pointInTime),
        };
        const params = { ignoreDeclValidationWarnings };
        const url = `${this.rootPath}/v1/crop-plans/${businessId}/plans/${cropPlanId}/zones/${domainZoneId}/decls/complete-with-tare`;
        const res = await this.http.put(url, body, { params });
        return res.data;
    }

    public async getGroupedAnomalies(businessId: string, cropPlanId: number) {
        const url = `${this.rootPath}/v1/crop-plans/${businessId}/plans/${cropPlanId}/grouped-anomalies`;
        const res = await this.http.get(url);
        return res.data;
    }

    public async printRequest(
        businessId: string,
        cropPlanId: number,
        printCode: string,
        pointInTime: string
    ): Promise<string> {
        const body = {
            printCode,
            pointInTime,
        };
        const url = `${this.rootPath}/v1/crop-plans/${businessId}/plans/${cropPlanId}/prints`;
        const res = await this.http.post(url, body);
        return res.data;
    }

    public async printStatus(businessId: string, cropPlanId: number, printId: string): Promise<PrintStatus> {
        const url = `${this.rootPath}/v1/crop-plans/${businessId}/plans/${cropPlanId}/prints/${printId}/status`;
        const res = await this.http.get(url);
        return res.data;
    }

    public async getFile(businessId: string, cropPlanId: number, printId: string) {
        const url = `${this.rootPath}/v1/crop-plans/${businessId}/plans/${cropPlanId}/prints/${printId}`;
        const res = await this.http.get(url, { responseType: "blob" });
        let ext = "unknown";
        if (res.headers["content-disposition"])
            ext = res.headers["content-disposition"]
                .split("filename=")
                .pop()!
                .split(".")
                .pop()!
                .replace(/[^A-Za-z0-9]/g, "");
        return [res.data, ext];
    }

    public async getSubscriptionsData(
        businessId: string,
        cropPlanId: number,
        subscriptionCodes: string[],
        externalCode: string | null
    ): Promise<Subscription[]> {
        const url = `${this.rootPath}/v1/crop-plans/${businessId}/plans/${cropPlanId}/subscriptions`;
        const body = {
            subscriptionCodes: subscriptionCodes,
            externalCode: externalCode,
        };
        const res = await this.http.post(url, body);
        return res.data;
    }

    public async getDates(businessId: string, cropPlanId: number, pointInTime: string): Promise<CropPlanDates> {
        const url = `${this.rootPath}/v1/crop-plans/${businessId}/plans/${cropPlanId}/dates?pointInTime=${pointInTime}`;
        const res = await this.http.get(url);
        return res.data;
    }

    public async getDefaultDate(businessId: string, cropPlanId: number): Promise<string> {
        const url = `${this.rootPath}/v1/crop-plans/${businessId}/plans/${cropPlanId}/default-open-date`;
        const res = await this.http.get(url);
        return res.data;
    }

    public async getDisabledFunctionsConfig(
        businessId: string,
        cropPlanId: number
    ): Promise<AnomaliesScenarioConfiguration[]> {
        const res = await this.http.get(
            `${this.rootPath}/v1/crop-plans/${businessId}/plans/${cropPlanId}/config-functions-disabled`
        );
        return res.data.anomScenarioConfig;
    }
}
