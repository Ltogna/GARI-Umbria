import { HTTPClient } from "@abaco/web-common/src/HTTP";
import axios, { CancelTokenSource } from "axios";
import { MaxPagedResults } from "@abaco/web-common/src/Paging";
import { Council, SubdomainZone } from "../models/Council";
import { formatDate } from "./Utils";

export default class CouncilApi {
    private http: HTTPClient;
    private rootPath: string;
    private cancelTokenSource: CancelTokenSource | null;

    constructor(http: HTTPClient, rootPath: string) {
        this.http = http;
        this.rootPath = rootPath;
        this.cancelTokenSource = null;
    }

    public async getCouncils(
        businessId: string | null,
        pointInTime: Date,
        version: string | null,
        cropPlanId: number,
        filter: string | null,
        filterByBusiness: boolean
    ): Promise<MaxPagedResults<Council>> {
        if (this.cancelTokenSource) {
            this.cancelTokenSource.cancel();
        }
        this.cancelTokenSource = axios.CancelToken.source();

        const res = await this.http.get(
            `${this.rootPath}/v1/domains/${businessId ? businessId : 0}/plans/${cropPlanId}/zones`,
            {
                params: {
                    version: version ? version : undefined,
                    search: filter ? filter.toUpperCase() : undefined,
                    filterByBusiness: filterByBusiness,
                    pointInTime: formatDate(pointInTime),
                    cancelToken: this.cancelTokenSource?.token,
                },
            }
        );
        return res.data;
    }

    public async getSubdomainZone(
        businessId: string,
        cropPlanId: number,
        domainZoneId: string,
        pointInTime: Date,
        geom: string,
    ): Promise<SubdomainZone> {
        const url = `${this.rootPath}/v1/crop-plans/${businessId}/plans/${cropPlanId}/zones/${domainZoneId}/subdomain-zones`;
        const body = {
            geom: geom,
        };
        const params = { pointInTime: formatDate(pointInTime) };

        const res = await this.http.post<SubdomainZone>(url, body, { params });
        return res.data;
    }
}
