import { HTTPClient } from "@abaco/web-common/src/HTTP";
import axios, { CancelTokenSource } from "axios";
import {
    BulkDeclarationFieldsUpdatate,
    ChangingPoint,
    CopyCampaignPayload,
    CopyOrMoveDeclarationsPayload,
    CopyOrMoveDeclarationsResponse,
    Declaration,
    DeclarationOut,
    DeclarationResponse,
    DomainZonePlot,
    DomainZonePlotDeclaration,
    ExcludeFromCopyCampaignLanduse,
    GeneralTimeline,
    MultipleDeclarationOut,
    PlotPeriodsData,
    PlotRanges,
    Timeline,
} from "../models/Declaration";
import { convertPermanentCropFormsForOutput, formatDate, toDateFromFormat } from "./Utils";
import cloneDeep from "lodash/cloneDeep";
import { NextPagedResults } from "@abaco/web-common/src/Paging";
import { PermanentCropForm } from "../models/PermanentCropForm";
import { SyncResponse } from "../models/CropPlan";

export default class CropApi {
    private http: HTTPClient;
    private rootPath: string;
    private cancelTokenSource: CancelTokenSource | null;

    constructor(http: HTTPClient, rootPath: string) {
        this.http = http;
        this.rootPath = rootPath;
        this.cancelTokenSource = null;
    }

    public async getGeneralTimeline(
        businessId: string,
        cropPlanId: number,
        domainZoneId: string,
        from: Date,
        to: Date,
        version?: string
    ): Promise<ChangingPoint[]> {
        const params = {
            pointInTimeFrom: formatDate(from),
            pointInTimeTo: formatDate(to),
            version: version,
        };
        const url = `${this.rootPath}/v1/crop-plans/${businessId}/plans/${cropPlanId}/zones/${domainZoneId}/timeline`;
        const res = await this.http.get<GeneralTimeline>(url, { params });
        res.data.changingPoints.forEach((e: ChangingPoint) => toDateFromFormat(e, ["date"]));
        return res.data.changingPoints;
    }

    public async getTimeline(
        businessId: string,
        cropPlanId: number,
        domainZoneId: string,
        plotCode: string,
        pointInTimeFrom: string,
        pointInTimeTo: string,
        version: string | null
    ): Promise<Timeline | any> {
        if (this.cancelTokenSource) {
            this.cancelTokenSource.cancel();
        }
        this.cancelTokenSource = axios.CancelToken.source();
        const res: any = await this.http.get(
            `${this.rootPath}/v1/crop-plans/${businessId}/plans/${cropPlanId}/zones/${domainZoneId}/plots/${plotCode}/timeline`,
            {
                params: {
                    version: version ? version : undefined,
                    pointInTimeFrom: pointInTimeFrom,
                    pointInTimeTo: pointInTimeTo,
                    cancelToken: this.cancelTokenSource?.token,
                },
            }
        );
        res.data.areas.forEach((e: any) => toDateFromFormat(e, ["fromDate", "toDate"]));
        res.data.decls.forEach((e: any) => {
            toDateFromFormat(e, ["fromDate", "toDate"]);
            e.pesticides.forEach((p: any) => toDateFromFormat(p, ["entryDate"]));
        });

        // Format dates of permanentCropForm
        res.data.decls.forEach((decl: Declaration) => {
            decl.permanentCropForms?.forEach((permanentCropForm: PermanentCropForm) => {
                if (!permanentCropForm.permanentCropFormData) return;
                toDateFromFormat(permanentCropForm.permanentCropFormData, ["graftDate", "expectedCuttingDate"]);
            });
        });

        return res.data;
    }

    public async insertDeclaration(
        businessId: string,
        cropPlanId: number,
        domainZoneId: string,
        plotCode: string,
        detailOut: DeclarationOut,
        fromDatePrecision: string,
        withTolerance: boolean,
        ignoreWarning = false,
        isCopyFromDecl: boolean,
        removeExistingDeclarations: boolean,
        pointInTime: Date
    ): Promise<DeclarationResponse> {
        const detailOutFormatted: any = cloneDeep(detailOut);
        detailOutFormatted.fromDate = formatDate(detailOutFormatted.fromDate);
        detailOutFormatted.toDate = formatDate(detailOutFormatted.toDate);
        detailOutFormatted.areaSqm = detailOutFormatted.areaSqm * 10000;
        detailOutFormatted.fromDatePrecision = fromDatePrecision;
        detailOutFormatted.permanentCropForms = convertPermanentCropFormsForOutput(detailOutFormatted.permanentCropForms)

        if (detailOutFormatted.fieldsCodes)
            for (const option of detailOutFormatted.fieldsCodes) {
                if (option.dayFrom instanceof Date) option.dayFrom = formatDate(option.dayFrom);
                if (option.dayTo instanceof Date) option.dayTo = formatDate(option.dayTo);
            }
        const params = {
            ignoreDeclValidationWarnings: ignoreWarning,
            withTolerance: withTolerance,
            isCopyFromDecl: isCopyFromDecl,
            pointInTime: formatDate(pointInTime),
        };
        const payload = {
            ...detailOutFormatted,
            removeExistingDeclarations,
        };
        const res = await this.http.post<DeclarationResponse>(
            `${this.rootPath}/v1/crop-plans/${businessId}/plans/${cropPlanId}/zones/${domainZoneId}/plots/${plotCode}/decls`,
            payload,
            { params }
        );
        toDateFromFormat(res.data.declaration, ["fromDate", "toDate"]);
        return res.data;
    }

    public async insertMultipleDeclaration(
        businessId: string,
        cropPlanId: number,
        domainZoneId: string,
        detailOut: MultipleDeclarationOut,
        fromDatePrecision: string,
        ignoreWarning = false,
        isCopyFromDecl: boolean,
        removeExistingDeclarations: boolean,
        pointInTime: Date
    ): Promise<DeclarationResponse> {
        const url = `${this.rootPath}/v1/crop-plans/${businessId}/plans/${cropPlanId}/zones/${domainZoneId}/plots/decls`;
        const detailOutFormatted: any = cloneDeep(detailOut);
        detailOutFormatted.fromDate = formatDate(detailOutFormatted.fromDate);
        detailOutFormatted.toDate = formatDate(detailOutFormatted.toDate);
        detailOutFormatted.fromDatePrecision = fromDatePrecision;
        detailOutFormatted.permanentCropForms = convertPermanentCropFormsForOutput(detailOutFormatted.permanentCropForms)

        if (detailOutFormatted.fieldsCodes)
            for (const option of detailOutFormatted.fieldsCodes) {
                if (option.dayFrom instanceof Date) option.dayFrom = formatDate(option.dayFrom);
                if (option.dayTo instanceof Date) option.dayTo = formatDate(option.dayTo);
            }

        const payload = {
            ...detailOutFormatted,
            removeExistingDeclarations,
        };
        const params = {
            ignoreDeclValidationWarnings: ignoreWarning,
            isCopyFromDecl: isCopyFromDecl,
            pointInTime: formatDate(pointInTime),
        };
        const res = await this.http.post(url, payload, { params });
        return res.data;
    }

    public async editDeclaration(
        businessId: string,
        cropPlanId: number,
        domainZoneId: string,
        plotCode: string,
        declCode: number,
        detailOut: DeclarationOut,
        fromDatePrecision: string,
        withTolerance: boolean,
        ignoreWarning = false,
        pointInTime: Date
    ): Promise<DeclarationResponse> {
        const detailOutFormatted: any = cloneDeep(detailOut);
        detailOutFormatted.fromDate = formatDate(detailOutFormatted.fromDate);
        detailOutFormatted.toDate = formatDate(detailOutFormatted.toDate);
        detailOutFormatted.areaSqm = detailOutFormatted.areaSqm * 10000;
        detailOutFormatted.fromDatePrecision = fromDatePrecision;
        detailOutFormatted.permanentCropForms = convertPermanentCropFormsForOutput(detailOutFormatted.permanentCropForms);

        if (detailOutFormatted.fieldsCodes) {
            for (const option of detailOutFormatted.fieldsCodes) {
                if (option.dayFrom instanceof Date) option.dayFrom = formatDate(option.dayFrom);
                if (option.dayTo instanceof Date) option.dayTo = formatDate(option.dayTo);
            }
        }

        const params = {
            ignoreDeclValidationWarnings: ignoreWarning,
            withTolerance: withTolerance,
            pointInTime: formatDate(pointInTime),
        };
        const res = await this.http.put<DeclarationResponse>(
            `${this.rootPath}/v1/crop-plans/${businessId}/plans/${cropPlanId}/zones/${domainZoneId}/plots/${plotCode}/decls/${declCode}`,
            detailOutFormatted,
            { params }
        );
        toDateFromFormat(res.data.declaration, ["fromDate", "toDate"]);
        return res.data;
    }

    public async deleteDeclaration(
        businessId: string,
        cropPlanId: number,
        domainZoneId: string,
        plotCode: string,
        declCode: number,
        ignoreWarning = false
    ): Promise<DeclarationResponse> {
        const params = { ignoreDeclValidationWarnings: ignoreWarning };
        const res: any = await this.http.delete(
            `${this.rootPath}/v1/crop-plans/${businessId}/plans/${cropPlanId}/zones/${domainZoneId}/plots/${plotCode}/decls/${declCode}`,
            { params }
        );
        // toDateFromFormat(res.data, ["fromDate", "toDate"]);
        return res.data;
    }

    public async deleteMultipleDeclarationsByPlots(
        businessId: string,
        cropPlanId: number,
        domainZoneId: string,
        plotCodes: string[],
        pointInTime: Date,
        ignoreWarning = false
    ): Promise<DeclarationResponse> {
        const res: any = await this.http.delete(
            `${this.rootPath}/v1/crop-plans/${businessId}/plans/${cropPlanId}/zones/${domainZoneId}/plots/decls`,
            {
                data: {
                    plotCodes: plotCodes,
                    pointInTime: formatDate(pointInTime),
                    ignoreDeclValidationWarnings: ignoreWarning,
                },
            }
        );
        return res.data;
    }

    public async copyOrMoveDeclarations(
        businessId: string,
        cropPlanId: number,
        domainZoneId: string,
        payload: CopyOrMoveDeclarationsPayload,
        ignoreWarning = false
    ): Promise<CopyOrMoveDeclarationsResponse> {
        const res = await this.http.post<CopyOrMoveDeclarationsResponse>(
            `${this.rootPath}/v1/crop-plans/${businessId}/plans/${cropPlanId}/zones/${domainZoneId}/copy-decls`,
            payload,
            { params: { ignoreDeclValidationWarnings: ignoreWarning } }
        );
        if (res.data.sourceUpdatedPlot) {
            toDateFromFormat(res.data.sourceUpdatedPlot, [
                "fromDate",
                "toDate",
                "fullRangeFromDate",
                "fullRangeToDate",
            ]);
            res.data.sourceUpdatedPlot.decls.forEach((d) => toDateFromFormat(d, ["fromDate", "toDate"]));
        }
        if (res.data.destUpdatedPlot) {
            toDateFromFormat(res.data.destUpdatedPlot, ["fromDate", "toDate", "fullRangeFromDate", "fullRangeToDate"]);
            res.data.destUpdatedPlot.decls.forEach((d) => toDateFromFormat(d, ["fromDate", "toDate"]));
        }

        return res.data;
    }

    public async loadPlotPeriods(
        businessId: string,
        cropPlanId: number,
        domainZoneId: string,
        plotCode: string,
        pointInTimeFrom: string,
        pointInTimeTo: string,
        excludedDeclCode: number | null,
        version: string | null,
        withTolerance: boolean
    ): Promise<PlotPeriodsData> {
        if (this.cancelTokenSource) {
            this.cancelTokenSource.cancel();
        }
        this.cancelTokenSource = axios.CancelToken.source();
        const res: any = await this.http.get(
            `${this.rootPath}/v1/crop-plans/${businessId}/plans/${cropPlanId}/zones/${domainZoneId}/plots/${plotCode}/declared-areas`,
            {
                params: {
                    version: version ? version : undefined,
                    pointInTimeFrom: pointInTimeFrom,
                    pointInTimeTo: pointInTimeTo,
                    excludedDeclCode: excludedDeclCode ? excludedDeclCode : undefined,
                    cancelToken: this.cancelTokenSource?.token,
                    withTolerance: withTolerance,
                },
            }
        );
        res.data.declaredAreas.forEach((e: any) => toDateFromFormat(e, ["date"]));
        return res.data;
    }

    public async loadPlotRanges(
        businessId: string,
        cropPlanId: number,
        domainZoneId: string,
        plotCode: string,
        version: string | null
    ): Promise<PlotRanges> {
        const res: any = await this.http.get(
            `${this.rootPath}/v1/crop-plans/${businessId}/plans/${cropPlanId}/zones/${domainZoneId}/plots/${plotCode}/lifecycle`,
            {
                params: {
                    version: version ? version : undefined,
                },
            }
        );
        toDateFromFormat(res.data, ["minFromDate", "maxToDate"]);
        return res.data;
    }

    public async mergeDeclarations(
        businessId: string,
        cropPlanId: number,
        domainZoneId: string,
        plotCode: string,
        fromDate: Date,
        ignoreWarning = false
    ): Promise<DeclarationResponse> {
        const body = {
            fromDate: formatDate(fromDate),
        };
        const res = await this.http.put<DeclarationResponse>(
            `${this.rootPath}/v1/crop-plans/${businessId}/plans/${cropPlanId}/zones/${domainZoneId}/plots/${plotCode}/merge-decls`,
            body,
            { params: { ignoreDeclValidationWarnings: ignoreWarning } }
        );

        return res.data;
    }

    public async reproportionDeclarations(
        businessId: string,
        cropPlanId: number,
        domainZoneId: string,
        plotCode: string,
        curPointInTime: Date,
        ignoreWarning = false
    ): Promise<DeclarationResponse> {
        const body = {
            pointInTime: formatDate(curPointInTime),
        };
        const res = await this.http.post<DeclarationResponse>(
            `${this.rootPath}/v1/crop-plans/${businessId}/plans/${cropPlanId}/${domainZoneId}/plots/${plotCode}/reproportion-decls`,
            body,
            { params: { ignoreDeclValidationWarnings: ignoreWarning } }
        );
        return res.data;
    }

    public async getDomainZoneDeclarations(
        businessId: string,
        cropPlanId: number,
        pointInTime: Date,
        nextKey: string | null
    ): Promise<NextPagedResults<DomainZonePlot>> {
        const res: any = await this.http.get(`${this.rootPath}/v1/crop-plans/${businessId}/plans/${cropPlanId}/decls`, {
            params: {
                pointInTime: formatDate(pointInTime),
                nextKey: nextKey ? nextKey : undefined,
            },
        });
        return res.data;
    }

    /** Update declarations fields (permanent crop form and additional values) by domain zones ids, landuse codes and rotations */
    public async getAllDomainZoneDeclarations(
        businessId: string,
        cropPlanId: number,
        pointInTime: Date
    ): Promise<DomainZonePlotDeclaration[]> {
        let resPlots: DomainZonePlot[] = [];
        const resDeclarations: DomainZonePlotDeclaration[] = [];
        let nextKey = null;

        do {
            const curPage: NextPagedResults<DomainZonePlot> = await this.getDomainZoneDeclarations(
                businessId,
                cropPlanId,
                pointInTime,
                nextKey
            );
            const newDomainZoneDeclarations: DomainZonePlot[] = curPage.records;
            resPlots = [...resPlots, ...newDomainZoneDeclarations];
            nextKey = curPage.nextKey;
        } while (nextKey);

        resPlots.forEach((p) =>
            resDeclarations.push(
                ...p.decls.map((d) => {
                    return {
                        ...d,
                        domainZoneId: p.domainZoneId,
                        domainZoneDescription: p.domainZoneDescription,
                        _uniqueLandUseCode: d.landUse.code + "-" + d.rotation,
                        _selected: false,
                    };
                })
            )
        );

        return resDeclarations;
    }

    /** Update declarations fields (permanent crop form and additional values)
     * by domain zones ids, landuse codes and rotations */
    public async bulkDeclarationFieldsUpdate(
        businessId: string,
        cropPlanId: number,
        pointInTime: Date,
        payload: BulkDeclarationFieldsUpdatate
    ): Promise<any> {
        const body = payload;
        const res = await this.http.put<DeclarationResponse>(
            `${this.rootPath}/v1/crop-plans/${businessId}/plans/${cropPlanId}/decls/massive-fields-update`,
            body,
            {
                params: {
                    pointInTime: formatDate(pointInTime),
                },
            }
        );

        return res.data;
    }

    /** Update declarations fields (permanent crop form and additional values) by domain zones ids, landuse codes and rotations */
    public async getSourceLandUsesForCopyCampaign(
        businessId: string,
        cropPlanId: number,
        sourceCropPlanId: number,
        pointInTime: Date,
        sourcePointInTime: string,
        sourceVersion?: string,
    ): Promise<ExcludeFromCopyCampaignLanduse[]> {
            const resLandUses: any = await this.http.get(`${this.rootPath}/v1/crop-plans/${businessId}/plans/${cropPlanId}/copy-campaign/land-use-codes`, {
                params: {
                    pointInTime: formatDate(pointInTime),
                    sourceCropPlanId: sourceCropPlanId,
                    sourceVersion: sourceVersion,
                    sourcePointInTime: sourcePointInTime,
                },
            });

        return resLandUses.data;
    }

    public async copyCampaign(
        businessId: string,
        cropPlanId: number,
        payload: CopyCampaignPayload
    ): Promise<SyncResponse> {
        const res = await this.http.put<SyncResponse>(
            `${this.rootPath}/v1/crop-plans/${businessId}/plans/${cropPlanId}/copy-campaign`,
            payload
        );

        return res.data;
    }
}
