
import { HTTPClient } from "@abaco/web-common/src/HTTP";
import { CommonConfigAndValues } from "../models/LandUse";
import { formatDate, toDateFromFormat } from "./Utils";
import { LandUseAdditionalDataField } from "../models/Plot";

export default class LayerApi {
    private http: HTTPClient;
    private rootPath: string;

    constructor(http: HTTPClient, rootPath: string) {
        this.http = http;
        this.rootPath = rootPath;
    }

    public async getLandUseCommonConfigAndValues(
        businessId: string,
        cropPlanId: number,
        pointInTime: Date,
        landUseCodes: string[],
    ): Promise<CommonConfigAndValues> {
        const url = `${this.rootPath}/v1/crop-codes/${businessId}/plans/${cropPlanId}/land-uses/common-config-and-values`;
        const body = {
            landUseCodes: landUseCodes,
        };
        const params = { pointInTime: formatDate(pointInTime), };

        const res = await this.http.post<CommonConfigAndValues>(url, body, { params });

        for (const data of res.data.landUseAdditionalDataConfigs) {
            for (const value of data.allowedValues) toDateFromFormat(value, ["dayFrom", "dayTo"]);
            const emptyValue: LandUseAdditionalDataField = {
                fieldCode: data.fieldCode,
                fieldDescription: data.fieldDescription,
                dayFrom: new Date(1970, 0, 1), // 0 -> January
                dayTo: new Date(9999, 11, 31), // 11 -> December
                sortOrder: data.sortOrder,
                value: null,
                valueDescription: "",
                flShowInTooltip: false,
            };
            if(data.nullable) data.allowedValues.push(emptyValue);
            if (data.defaultValue !== "" && data.defaultValue !== null) {
                data.selectedValue =
                    data.allowedValues.find((value: LandUseAdditionalDataField) => value.value == data.defaultValue)
            } else {
                data.defaultValue = emptyValue.value;
                data.selectedValue = emptyValue;
            }
        }
        return res.data;
    }
}
