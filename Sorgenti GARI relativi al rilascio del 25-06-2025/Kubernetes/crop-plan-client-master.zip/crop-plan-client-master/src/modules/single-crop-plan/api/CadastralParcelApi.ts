import { HTTPClient } from "@abaco/web-common/src/HTTP";
import axios, { CancelTokenSource } from "axios";
import { MaxPagedResults, NextPagedResults } from "@abaco/web-common/src/Paging";
import { CadastralParcel } from "../models/CadastralParcel";
import { formatDate } from "./Utils";
import { CadastralData, CadastralOverlap, ParcelData } from "../models/Declaration";

export default class CadastralParcelApi {
    private http: HTTPClient;
    private rootPath: string;
    private cancelTokenSource: CancelTokenSource | null;

    constructor(http: HTTPClient, rootPath: string) {
        this.http = http;
        this.rootPath = rootPath;
        this.cancelTokenSource = null;
    }

    public async getCadastralParcels(
        businessId: string,
        cropPlanId: number,
        domainZoneId: string,
        search?: string
    ): Promise<MaxPagedResults<CadastralParcel>> {
        if (this.cancelTokenSource) {
            this.cancelTokenSource.cancel();
        }
        this.cancelTokenSource = axios.CancelToken.source();
        //
        const params: { [k: string]: any } = {};
        if (search) params.search = search;
        //
        const res = await this.http.get(
            `${this.rootPath}/v1/domains/${businessId}/plans/${cropPlanId}/zones/${domainZoneId}/places`,
            {
                params: params,
            }
        );
        return res.data;
    }

    private async getCadastral(
        businessId: string,
        cropPlanId: number,
        domainZoneId: string,
        pointInTime: Date,
        version: string | null,
        nextKey: string | null
    ): Promise<NextPagedResults<CadastralData>> {
        const res = await this.http.get(
            `${this.rootPath}/v1/domains/${businessId}/plans/${cropPlanId}/zones/${domainZoneId}/cadastral-parcels`,
            {
                params: {
                    version: version ? version : undefined,
                    pointInTime: formatDate(pointInTime),
                    nextKey: nextKey ? nextKey : undefined,
                },
            }
        );

        return res.data;
    }

    public async getAllCadastral(
        businessId: string,
        cropPlanId: number,
        domainZoneId: string,
        pointInTime: Date,
        version: string | null
    ): Promise<NextPagedResults<CadastralData>> {
        let count = 0;
        let res: CadastralData[] = [];
        let nextKey = null;
        do {
            const curPage: NextPagedResults<CadastralData> = await this.getCadastral(
                businessId,
                cropPlanId,
                domainZoneId,
                pointInTime,
                version,
                nextKey
            );
            count += curPage.count;
            res = [...res, ...curPage.records];
            nextKey = curPage.nextKey;
        } while (nextKey);

        const pageRes = { count: count, records: res, nextKey: null };
        return pageRes;
    }

    private async getCadastralOverlaps(
        businessId: string,
        cropPlanId: number,
        domainZoneId: string,
        pointInTime: Date,
        version: string | null,
        nextKey: string | null
    ): Promise<NextPagedResults<CadastralOverlap>> {
        const res = await this.http.get(
            `${this.rootPath}/v1/domains/${businessId}/plans/${cropPlanId}/zones/${domainZoneId}/cadastral-parcels/overlaps`,
            {
                params: {
                    version: version ? version : undefined,
                    pointInTime: formatDate(pointInTime),
                    nextKey: nextKey ? nextKey : undefined,
                },
            }
        );

        return res.data;
    }

    public async getAllCadastralOverlaps(
        businessId: string,
        cropPlanId: number,
        domainZoneId: string,
        pointInTime: Date,
        version: string | null
    ): Promise<NextPagedResults<CadastralOverlap>> {
        let count = 0;
        let res: CadastralOverlap[] = [];
        let nextKey = null;
        do {
            const curPage: NextPagedResults<CadastralOverlap> = await this.getCadastralOverlaps(
                businessId,
                cropPlanId,
                domainZoneId,
                pointInTime,
                version,
                nextKey
            );
            count += curPage.count;
            res = [...res, ...curPage.records];
            nextKey = curPage.nextKey;
        } while (nextKey);

        const pageRes = { count: count, records: res, nextKey: null };
        return pageRes;
    }

    private async getParcel(
        businessId: string,
        cropPlanId: number,
        domainZoneId: string,
        pointInTime: Date,
        version: string | null,
        nextKey: string | null
    ): Promise<NextPagedResults<ParcelData>> {
        const res = await this.http.get(
            `${this.rootPath}/v1/domains/${businessId}/plans/${cropPlanId}/zones/${domainZoneId}/parcels`,
            {
                params: {
                    version: version ? version : undefined,
                    pointInTime: formatDate(pointInTime),
                    nextKey: nextKey ? nextKey : undefined,
                },
            }
        );

        return res.data;
    }

    public async getAllParcels(
        businessId: string,
        cropPlanId: number,
        domainZoneId: string,
        pointInTime: Date,
        version: string | null
    ): Promise<NextPagedResults<ParcelData>> {
        let count = 0;
        let res: ParcelData[] = [];
        let nextKey = null;
        do {
            const curPage: NextPagedResults<ParcelData> = await this.getParcel(
                businessId,
                cropPlanId,
                domainZoneId,
                pointInTime,
                version,
                nextKey
            );
            count += curPage.count;
            res = [...res, ...curPage.records];
            nextKey = curPage.nextKey;
        } while (nextKey);

        const pageRes = { count: count, records: res, nextKey: null };
        return pageRes;
    }
}
