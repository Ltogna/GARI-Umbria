import { propsToDate, propsToDatePaged } from "@abaco/web-common/src/HTTP";
import { MaxPagedResults, NextPagedResults } from "@abaco/web-common/src/Paging";
import { DateHelper } from "@abaco/web-components/src/components/DateUtils";
import { PermanentCropForm, PermanentCropFormOut, VineyardFormUpsertDTO } from "../models/PermanentCropForm";

export const DATE_FORMAT = "yyyyMMdd";
export const DATE_TIME_FORMAT = "yyyyMMddHHmmss";

export function formatDate(dt: Date) {
    return new DateHelper(dt).format(DATE_FORMAT);
}
export function formatDateTime(dt: Date) {
    return new DateHelper(dt).format(DATE_TIME_FORMAT);
}

const toDate = (val: any): Date | null => {
    if (val !== null) {
        if (typeof val === "string") {
            const year = parseInt(val.substring(0, 4));
            const month = parseInt(val.substring(4, 6)) - 1;
            const day = parseInt(val.substring(6));
            return new Date(year, month, day, 0, 0, 0, 0);
        }
        console.warn(`Cannot convert ${val} of type ${typeof val} to Date`);
    }
    return null;
};
export function convertToDate(dt: string) {
    return toDate(dt);
}

export function toDateFromFormat(obj: { [key: string]: any }, keys: string[]) {
    propsToDate(obj, keys, false, toDate);
}

export function toDatePagedFromFormat(obj: MaxPagedResults<any> | NextPagedResults<any>, keys: string[]) {
    propsToDatePaged(obj, keys, false, toDate);
}

export const isLeap = (year: number) => new Date(year, 1, 29).getDate() === 29;

export const isNullish = (item: any) => item === undefined || item === null;

// TODO - Extend functionality
export const getDeepValue = (obj: Record<string, any>, keys: Array<string>): Record<string, any> => {
    try {
        let result = obj;
        for (const key of keys) {
            if (Array.isArray(result[key])) {
                result = result[0][key];
            } else {
                result = result[key];
            }
        }

        return result;
    } catch (error) {
        return {};
    }
};

export const isAllEqual = (arr: Array<any>, keys: Array<string>): boolean => {
    try {
        if (keys) {
            const resultToCompare = getDeepValue(arr[0], keys);
            return arr.every((it) => getDeepValue(it, keys) === resultToCompare);
        }

        return arr.every((it) => it === arr[0]);
    } catch (error) {
        return false;
    }
};

export const removeDuplicates = (items: Array<any>, key: string): Array<any> => {
    return items.filter((value, index, self) => index === self.findIndex((t) => t[key] === value[key]));
};

export const removeDuplicatesDeep = (items: Array<any>, keys: Array<string>): Array<any> => {
    try {
        return items.filter(
            (value, index, self) => index === self.findIndex((t) => getDeepValue(t, keys) === getDeepValue(value, keys))
        );
    } catch (error) {
        return [];
    }
};

export const groupBy = <T extends Record<string, any>>(items: Array<T>, key: string): Record<string, T[]> => {
    return items.reduce(
        (result, item) => ({
            ...result,
            [item[key] as string]: [...(result[item[key] as string] || []), item],
        }),
        {} as Record<string, T[]>
    );
};

export const groupByDeep = (items: Array<any>, keys: Array<string>): Record<string, any> => {
    try {
        return items.reduce(
            (result, item) => ({
                ...result,
                [getDeepValue(item, keys).toString()]: [
                    ...(getDeepValue(result, keys)[getDeepValue(item, keys).toString()] || []),
                    item,
                ],
            }),
            {}
        );
    } catch (error) {
        return {};
    }
};

export const upperCaseFirstChar = (v: string) => {
    return v.charAt(0).toUpperCase() + v.slice(1).toLowerCase();
};

/**
 * Strict check if the passed value is not nullish
 * @ref https://www.typescriptlang.org/docs/handbook/2/narrowing.html#using-type-predicates
 *
 * @param value Item to check
 * @returns boolean status
 */
export function notEmpty<TValue>(value: TValue | null | undefined): value is TValue {
    return value !== null && value !== undefined;
}

export function isMacOs(): boolean {
    return window.navigator.userAgent.indexOf("Mac") !== -1;
}

/**
 * Check if the passed date is valid.
 * @param date Passed Date
 * @return boolean
 */
export function dateIsValid(date: Date): boolean {
    try {
        if (date instanceof Date && !isNaN(date.getTime())) {
            return true;
        } else {
            throw "Invalid Date";
        }
    } catch (error) {
        return false;
    }
}

/**
 * Converts `PermanentCropForm[]` into `PermanentCropFormOut[]`, ensuring that
 * all `Date` properties are converted from `Date | null` to `string | null`
 * as required by `VineyardFormUpsertDTO`.
 *
 * @param permanentCropForms - The array of `PermanentCropForm` objects.
 * @returns A new array of `PermanentCropFormOut` with `Date` fields converted to `string`, or `undefined` if input is `undefined`.
 */
export function convertPermanentCropFormsForOutput(
    permanentCropForms?: PermanentCropForm[]
): PermanentCropFormOut[] | undefined {
    if (!permanentCropForms) return undefined;

    return permanentCropForms.map((permanentCropForm) => {
        const data = permanentCropForm.permanentCropFormData;
        if (!data) {
            return { ...permanentCropForm, permanentCropFormData: null };
        }

        return {
            ...permanentCropForm,
            permanentCropFormData: {
                ...data,
                graftDate: data.graftDate ? formatDate(data.graftDate) : null, // Convert Date to string
                expectedCuttingDate: data.expectedCuttingDate ? formatDate(data.expectedCuttingDate) : null, // Convert Date to string
            } as VineyardFormUpsertDTO, // Ensures the correct type
        };
    });
}
