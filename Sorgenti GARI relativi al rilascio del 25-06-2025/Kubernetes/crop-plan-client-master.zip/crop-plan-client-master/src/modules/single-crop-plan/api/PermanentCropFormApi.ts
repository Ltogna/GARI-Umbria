import { HTTPClient } from "@abaco/web-common/src/HTTP";
import { PermanentCropField } from "../models/PermanentCropForm";

export default class PermanentCropFormApi {
    private http: HTTPClient;
    private rootPath: string;

    constructor(http: HTTPClient, rootPath: string) {
        this.http = http;
        this.rootPath = rootPath;
    }

    public async getFieldsCodes(
        businessId: string,
        cropPlanId: number,
        formType: string
    ): Promise<PermanentCropField[]> {
        const url = `${this.rootPath}/v1/crop-plans/${businessId}/plans/${cropPlanId}/permanent-crop-form/fields-codes/${formType}`;
        const res = await this.http.get<PermanentCropField[]>(url);
        return res.data;
    }
}
