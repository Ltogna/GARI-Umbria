import { HTTPClient } from "@abaco/web-common/src/HTTP";
import axios, { CancelTokenSource } from "axios";
import { MaxPagedResults } from "@abaco/web-common/src/Paging";
import { Business } from "../models/Business";
import SsoVuexModule from "@abaco/sso-web-module/src/abaco-module/state";

export default class BusinessApi {
    private http: HTTPClient;
    private ssoStore: SsoVuexModule;
    private rootPath: string;
    private cancelTokenSource: CancelTokenSource | null;

    constructor(http: HTTPClient, rootPath: string, ssoStore: SsoVuexModule) {
        this.http = http;
        this.rootPath = rootPath;
        this.ssoStore = ssoStore;
        this.cancelTokenSource = null;
    }

    public async getBusinesses(filter: string | null): Promise<MaxPagedResults<Business>> {
        if (this.cancelTokenSource) {
            this.cancelTokenSource.cancel();
        }
        this.cancelTokenSource = axios.CancelToken.source();
        const filterQuery = filter ? `?search=${filter.toUpperCase()}` : "";
        const res = await this.http.get(`${this.rootPath}/v1/business-registry${filterQuery}`, {
            cancelToken: this.cancelTokenSource?.token
        });
        return res.data;
    }

    public async getBusiness(businessId: string): Promise<Business> {
        const res = await this.http.get(`${this.rootPath}/v1/business-registry/${businessId}`);
        return res.data;
    }

    //WARNING: NOT YET DONE ON NEW BACK END
    public async getLastUsedBusinesses(): Promise<Business[]> {
        // if (!this.ssoStore.user) {
        //     return [];
        // }
        // const lastUsedRPP = 10;
        // const params = {
        //     count: lastUsedRPP,
        //     username: this.ssoStore.user.username
        // }
        // const res = await this.http.get(`${this.rootPath}/v1/business-registry-last-used`, { params });
        // return res.data;

        const res: Business[] = [];
        res.push({ businessId: '3163', code: "1234567890", description: "MUSTAF ANDREW" });
        res.push({ businessId: '406926', code: "75757575757", description: "AGRITURISMO BARBARINA" });
        res.push({ businessId: '415946', code: "01010101010", description: "ZAMPIERI MASSIMO" });
        res.push({ businessId: '529769', code: "STSLRCLL57T83B2R", description: "STANIS LA ROCHELLE" });
        return res;
    }

    //WARNING: NOT YET DONE ON NEW BACK END
    async setLastUsedBusiness(businessId: string) {
        // if (!this.ssoStore.user) {
        //     return;
        // }
        // await this.http.get("/siticatasto/dbgis-servlet/rest_tl_data", {
        //     params: {
        //         svccode: "portal/register_search",
        //         id_obj_type: 2,
        //         pkid: businessId,
        //         username: this.ssoStore.user.username
        //     }
        // });
    }
}
