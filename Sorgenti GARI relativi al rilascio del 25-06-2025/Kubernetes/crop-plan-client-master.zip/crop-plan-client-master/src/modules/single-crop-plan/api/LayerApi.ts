import { HTTPClient } from "@abaco/web-common/src/HTTP";
import { LayerDef } from "@abaco/iacs-map-module/src/modules/map-module/Layer/GenericLayer";
import { LayerDefIn, SnapGeometryDef, GisInfo } from "../models/Layer";
import { formatDate } from "./Utils";

export default class LayerApi {
    private http: HTTPClient;
    private rootPath: string;

    constructor(http: HTTPClient, rootPath: string) {
        this.http = http;
        this.rootPath = rootPath;
    }

    public async getAdditionalLayers(
        businessId: string,
        cropPlanId: number,
        domainZoneId: string
    ): Promise<LayerDef[]> {
        const url = `${this.rootPath}/v1/domains/${businessId}/plans/${cropPlanId}/additional-layers?domainZoneId=${domainZoneId}`;
        const res = await this.http.get<LayerDefIn[]>(url);
        res.data.forEach((l, i) => {
            (l.layerId = `${i}-${l.description}`), (l.zIndex = l.legendOrder * -1);
        });
        return res.data;
    }

    public async getSnapGeometries(
        businessId: string,
        cropPlanId: number,
        domainZoneId: string,
        poinInTime: Date,
        snapElementTypes?: string[],
    ): Promise<SnapGeometryDef> {
        const url = `${this.rootPath}/v1/domains/${businessId}/plans/${cropPlanId}/zones/${domainZoneId}/snap-geometries`;
        const params = {
            version: undefined,
            pointInTime: formatDate(poinInTime),
            snapElementTypes: snapElementTypes
        };
        const res = await this.http.get(url, { params });
        return res.data;
    }

    public async getGisInfo(
        businessId: string,
        cropPlanId: number,
        domainZoneId: string,
        coordinate: number[],
        pointInTime: Date,
        layerCodes: string[]
    ): Promise<GisInfo[]> {
        const url = `${this.rootPath}/v1/domains/${businessId}/plans/${cropPlanId}/zones/${domainZoneId}/gis-info`;
        const params = {
            x: coordinate[0],
            y: coordinate[1],
            pointInTime: formatDate(pointInTime),
            layerCodes: layerCodes
        }
        const res = await this.http.get(url, { params });
        return res.data;
    }
}
