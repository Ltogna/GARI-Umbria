import { AxiosResponse, HTTPClient } from "@abaco/web-common/src/HTTP";
import { MaxPagedResults, NextPagedResults } from "@abaco/web-common/src/Paging";
import {
    BufferBehaviour,
    CuttableLayer,
    LandCover,
    LandCoverFilterIn,
    LandUse,
    LandUseAdditionalDataConf,
    LandUseAdditionalDataField,
    Plot,
    PlotBuffer,
    PlotOut,
    PlotPreview,
    PlotPreviewDiff,
    PlotResponse,
    PlotResponseDiff,
} from "../models/Plot";
import { formatDate, toDateFromFormat, toDatePagedFromFormat } from "./Utils";
import { defaultPlotStyle } from "../components/mapComponent/EditStyle";

export default class PlotApi {
    private http: HTTPClient;
    private rootPath: string;

    constructor(http: HTTPClient, rootPath: string) {
        this.http = http;
        this.rootPath = rootPath;
    }

    public async getLandUses(
        businessId: string,
        cropPlanId: number,
        pointInTime: Date,
        search: string | null,
        landCoverCodes: string[] | null
    ): Promise<MaxPagedResults<LandUse>> {
        const res = await this.http.get(`${this.rootPath}/v1/crop-codes/${businessId}/plans/${cropPlanId}/land-uses`, {
            params: {
                search: search ? search : undefined,
                landCoverCodes:
                    landCoverCodes && landCoverCodes.length > 0
                        ? landCoverCodes.filter((lc, i, list) => list.indexOf(lc) === i)
                        : [],
                pointInTime: formatDate(pointInTime),
            },
        });
        res.data.records.forEach((lu: LandUse) => {
            toDateFromFormat(lu, ["defaultFromDate"]);
        });
        return res.data;
    }

    public async getLandUse(
        businessId: string,
        cropPlanId: number,
        pointInTime: Date,
        landUseCode: string,
        landCoverCodes?: string[]
    ): Promise<LandUse> {
        const res = await this.http.get(
            `${this.rootPath}/v1/crop-codes/${businessId}/plans/${cropPlanId}/land-uses/${landUseCode}`,
            {
                params: {
                    pointInTime: formatDate(pointInTime),
                    landCoverCodes:
                        landCoverCodes && landCoverCodes.length > 0
                            ? landCoverCodes.filter((lc, i, list) => list.indexOf(lc) === i)
                            : [],
                },
            }
        );
        toDateFromFormat(res.data, ["defaultFromDate"]);
        return res.data;
    }

    public async getLandUseLandCover(businessId: string, cropPlanId: number, landUseCode: string): Promise<LandCover> {
        const res = await this.http.get(
            `${this.rootPath}/v1/crop-codes/${businessId}/plans/${cropPlanId}/land-uses/${landUseCode}/land-cover`
        );
        return res.data;
    }

    public async getLandUseAdditionalDataConf(
        businessId: string,
        cropPlanId: number,
        landUseCode: string,
        pointInTime: Date
    ): Promise<LandUseAdditionalDataConf[]> {
        const res = await this.http.get(
            `${this.rootPath}/v1/crop-codes/${businessId}/plans/${cropPlanId}/land-uses/${landUseCode}/fields-codes`,
            {
                params: {
                    pointInTime: formatDate(pointInTime),
                },
            }
        );

        for (const data of res.data) {
            for (const value of data.allowedValues) toDateFromFormat(value, ["dayFrom", "dayTo"]);
            const emptyValue: LandUseAdditionalDataField = {
                fieldCode: data.fieldCode,
                fieldDescription: data.fieldDescription,
                dayFrom: new Date(1970, 0, 1), // 0 -> January
                dayTo: new Date(9999, 11, 31), // 11 -> December
                sortOrder: data.sortOrder,
                value: null,
                valueDescription: "",
                flShowInTooltip: false,
            };
            if (data.nullable) data.allowedValues.push(emptyValue);
            if (data.defaultValue !== "" && data.defaultValue !== null) {
                data.selectedValue =
                    data.allowedValues.find((value: LandUseAdditionalDataField) => value.value == data.defaultValue)
            } else {
                data.defaultValue = emptyValue.value;
                data.selectedValue = emptyValue;
            }
        }
        return res.data;
    }

    public async getLandCoverFilters(businessId: string, cropPlanId: number): Promise<LandCoverFilterIn[]> {
        const url = `${this.rootPath}/v1/crop-codes/${businessId}/plans/${cropPlanId}/land-cover-filters`;
        const res = await this.http.get<LandCoverFilterIn[]>(url);
        return res.data;
    }

    public async getPlots(
        businessId: string,
        cropPlanId: number,
        domainZoneId: string,
        pointInTime: Date,
        version: string | null,
        nextKey: string | null,
        subdomainZoneId?: number
    ): Promise<NextPagedResults<PlotResponse>> {
        const res = await this.http.get(
            `${this.rootPath}/v1/crop-plans/${businessId}/plans/${cropPlanId}/zones/${domainZoneId}/plots`,
            {
                params: {
                    version: version ? version : undefined,
                    pointInTime: formatDate(pointInTime),
                    subdomainZoneId: subdomainZoneId,
                    nextKey: nextKey ? nextKey : undefined,
                },
            }
        );
        toDatePagedFromFormat(res.data, ["fromDate", "toDate", "fullRangeFromDate", "fullRangeToDate"]);
        res.data.records.forEach((e: any) => {
            e.decls.forEach((a: any) => toDateFromFormat(a, ["fromDate", "toDate"]));
        });
        return res.data;
    }

    public async getAllPlots(
        businessId: string,
        cropPlanId: number,
        domainZoneId: string,
        pointInTime: Date,
        version: string | null,
        subdomainZoneId?: number
    ): Promise<NextPagedResults<Plot>> {
        let count = 0;
        let res: Plot[] = [];
        let nextKey = null;
        do {
            const curPage: NextPagedResults<PlotResponse> = await this.getPlots(
                businessId,
                cropPlanId,
                domainZoneId,
                pointInTime,
                version,
                nextKey,
                subdomainZoneId
            );
            count += curPage.count;
            const newPlots: Plot[] = curPage.records.map(p => p.style ? p as Plot : { ...p, style: defaultPlotStyle } as Plot);
            res = [...res, ...newPlots];
            nextKey = curPage.nextKey;
        } while (nextKey);

        const pageRes = { count: count, records: res, nextKey: null };
        return pageRes;
    }

    public async getPlot(
        businessId: string,
        cropPlanId: number,
        domainZoneId: string,
        plotCode: string,
        pointInTime: Date,
        version: string | null
    ): Promise<Plot> {
        const res = await this.http.get(
            `${this.rootPath}/v1/crop-plans/${businessId}/plans/${cropPlanId}/zones/${domainZoneId}/plots/${plotCode}`,
            {
                params: {
                    version: version ? version : undefined,
                    pointInTime: formatDate(pointInTime),
                },
            }
        );
        // Formant plot's dates
        toDateFromFormat(res.data, ["fromDate", "toDate", "fullRangeFromDate", "fullRangeToDate"]);
        // Format plot's declaration's dates
        res.data.decls.forEach((a: any) => toDateFromFormat(a, ["fromDate", "toDate"]));
        return res.data;
    }

    public async mergePlotsPreview(
        businessId: string,
        cropPlanId: number,
        domainZoneId: string,
        pointInTime: Date,
        plotCode: string,
        plotCodes: string[] | null,
        subdomainZoneId?: number
    ): Promise<PlotPreviewDiff> {
        const url = `${this.rootPath}/v1/crop-plans/${businessId}/plans/${cropPlanId}/${domainZoneId}/plots/${plotCode}/merged_plots/preview`;
        const body = {
            fromPointInTime: formatDate(pointInTime),
            plotCodes: plotCodes,
        };
        const params = { subdomain_id: subdomainZoneId };
        const res = await this.http.post(url, body, { params });
        return res.data;
    }

    public async mergePlots(
        businessId: string,
        cropPlanId: number,
        domainZoneId: string,
        pointInTime: Date,
        plotCode: string,
        plotCodes: string[] | null,
        ignoreDeclValidationWarnings: boolean,
        subdomainZoneId?: number
    ): Promise<PlotResponseDiff> {
        const url = `${this.rootPath}/v1/crop-plans/${businessId}/plans/${cropPlanId}/${domainZoneId}/plots/${plotCode}/merged_plots`;
        const body = {
            fromPointInTime: formatDate(pointInTime),
            plotCodes: plotCodes,
            // preserveDeclarations: !enableDefaultNotPreserveDeclsOnPlotsMerge,
        };
        const params = { ignoreDeclValidationWarnings, subdomain_id: subdomainZoneId };
        const res = await this.http.post<PlotResponseDiff>(url, body, { params });
        this.formatDateResponseDiff(res);
        return res.data;
    }

    public async cutPlotPreview(
        businessId: string,
        cropPlanId: number,
        domainZoneId: string,
        pointInTime: Date,
        geom: string,
        plotCodes: string[] | null,
        subdomainZoneId?: number
    ): Promise<PlotPreviewDiff> {
        const url = `${this.rootPath}/v1/crop-plans/${businessId}/plans/${cropPlanId}/${domainZoneId}/plots/cut-lines/preview`;
        const body = {
            fromPointInTime: formatDate(pointInTime),
            geom: geom,
            cutParameters: {
                plotCodes: plotCodes,
            },
        };
        const params = { subdomain_id: subdomainZoneId };
        const res = await this.http.post(url, body, { params });
        return res.data;
    }

    public async cutPlot(
        businessId: string,
        cropPlanId: number,
        domainZoneId: string,
        pointInTime: Date,
        geom: string,
        plotCodes: string[] | null,
        ignoreDeclValidationWarnings: boolean,
        subdomainZoneId?: number
    ): Promise<PlotResponseDiff> {
        const url = `${this.rootPath}/v1/crop-plans/${businessId}/plans/${cropPlanId}/${domainZoneId}/plots/cut-lines`;
        const body = {
            fromPointInTime: formatDate(pointInTime),
            geom: geom,
            cutParameters: {
                plotCodes: plotCodes,
            },
        };
        const params = { ignoreDeclValidationWarnings, subdomain_id: subdomainZoneId };
        const res = await this.http.post<PlotResponseDiff>(url, body, { params });
        this.formatDateResponseDiff(res);
        return res.data;
    }

    public async cutGeometriesPlotPreview(
        businessId: string,
        cropPlanId: number,
        domainZoneId: string,
        pointInTime: Date,
        geoms: string[],
        plotCodes: string[] | null,
        flMergeGeomsOnCutOnLayer: boolean,
        flCalcCoveredByInsertedOnCutOnLayer: boolean,
        subdomainZoneId?: number
    ): Promise<PlotPreviewDiff> {
        const url = `${this.rootPath}/v1/crop-plans/${businessId}/plans/${cropPlanId}/${domainZoneId}/plots/cut-geometries/preview`;
        const body = {
            fromPointInTime: formatDate(pointInTime),
            geoms: geoms,
            cutParameters: {
                plotCodes: plotCodes,
                flMergeGeomsOnCutOnLayer: flMergeGeomsOnCutOnLayer,
                flCalcCoveredByInsertedOnCutOnLayer: flCalcCoveredByInsertedOnCutOnLayer
            },
        };
        const params = { subdomain_id: subdomainZoneId };
        const res = await this.http.post(url, body, { params });
        return res.data;
    }

    public async cutGeometriesPlot(
        businessId: string,
        cropPlanId: number,
        domainZoneId: string,
        pointInTime: Date,
        geoms: string[],
        plotCodes: string[] | null,
        ignoreDeclValidationWarnings: boolean,
        flMergeGeomsOnCutOnLayer: boolean,
        flCalcCoveredByInsertedOnCutOnLayer: boolean,
        subdomainZoneId?: number
    ): Promise<PlotResponseDiff> {
        const url = `${this.rootPath}/v1/crop-plans/${businessId}/plans/${cropPlanId}/${domainZoneId}/plots/cut-geometries`;
        const body = {
            fromPointInTime: formatDate(pointInTime),
            geoms: geoms,
            cutParameters: {
                plotCodes: plotCodes,
                flMergeGeomsOnCutOnLayer: flMergeGeomsOnCutOnLayer,
                flCalcCoveredByInsertedOnCutOnLayer: flCalcCoveredByInsertedOnCutOnLayer
            },
        };
        const params = { ignoreDeclValidationWarnings, subdomain_id: subdomainZoneId };
        const res = await this.http.post<PlotResponseDiff>(url, body, { params });
        this.formatDateResponseDiff(res);
        return res.data;
    }

    public async cutByLayerPreview(
        businessId: string,
        cropPlanId: number,
        domainZoneId: string,
        pointInTime: Date,
        layerCode: string,
        plotCodes: string[] | null,
        flMergeGeomsOnCutOnLayer: boolean,
        flCalcCoveredByInsertedOnCutOnLayer: boolean,
        subdomainZoneId?: number
    ): Promise<PlotPreviewDiff> {
        const url = `${this.rootPath}/v1/crop-plans/${businessId}/plans/${cropPlanId}/${domainZoneId}/plots/cut-by-layer/preview`;
        const params = { subdomain_id: subdomainZoneId };
        const body = {
            fromPointInTime: formatDate(pointInTime),
            layerCode: layerCode,
            cutParameters: {
                plotCodes: plotCodes,
                flMergeGeomsOnCutOnLayer: flMergeGeomsOnCutOnLayer,
                flCalcCoveredByInsertedOnCutOnLayer: flCalcCoveredByInsertedOnCutOnLayer
            },
        };
        const res = await this.http.post(url, body, { params });
        return res.data;
    }

    public async cutByLayer(
        businessId: string,
        cropPlanId: number,
        domainZoneId: string,
        pointInTime: Date,
        layerCode: string,
        plotCodes: string[] | null,
        ignoreDeclValidationWarnings: boolean,
        flMergeGeomsOnCutOnLayer: boolean,
        flCalcCoveredByInsertedOnCutOnLayer: boolean,
        subdomainZoneId?: number
    ): Promise<PlotResponseDiff> {
        const url = `${this.rootPath}/v1/crop-plans/${businessId}/plans/${cropPlanId}/${domainZoneId}/plots/cut-by-layer`;
        const params = { ignoreDeclValidationWarnings, subdomain_id: subdomainZoneId };
        const body = {
            fromPointInTime: formatDate(pointInTime),
            layerCode: layerCode,
            cutParameters: {
                plotCodes: plotCodes,
                flMergeGeomsOnCutOnLayer: flMergeGeomsOnCutOnLayer,
                flCalcCoveredByInsertedOnCutOnLayer: flCalcCoveredByInsertedOnCutOnLayer
            },
        };
        const res = await this.http.post<PlotResponseDiff>(url, body, { params });
        this.formatDateResponseDiff(res);
        return res.data;
    }

    public async insertPlotPreview(
        businessId: string,
        cropPlanId: number,
        domainZoneId: string,
        detailOut: PlotOut,
        subdomainZoneId?: number
    ): Promise<PlotPreviewDiff> {
        const url = `${this.rootPath}/v1/crop-plans/${businessId}/plans/${cropPlanId}/${domainZoneId}/plots/preview`;
        const params = { subdomain_id: subdomainZoneId };
        const res = await this.http.post(
            url,
            {
                ...detailOut,
                fromPointInTime: formatDate(detailOut.fromPointInTime),
            },
            { params }
        );
        return res.data;
    }

    public async insertPlot(
        businessId: string,
        cropPlanId: number,
        domainZoneId: string,
        detailOut: PlotOut,
        ignoreDeclValidationWarnings: boolean,
        subdomainZoneId?: number
    ): Promise<PlotResponseDiff> {
        const body = {
            ...detailOut,
            fromPointInTime: formatDate(detailOut.fromPointInTime),
        };
        const params = { ignoreDeclValidationWarnings, subdomain_id: subdomainZoneId };
        const res = await this.http.post<PlotResponseDiff>(
            `${this.rootPath}/v1/crop-plans/${businessId}/plans/${cropPlanId}/${domainZoneId}/plots`,
            body,
            { params }
        );
        this.formatDateResponseDiff(res);
        return res.data;
    }

    public async editPlotPreview(
        businessId: string,
        cropPlanId: number,
        domainZoneId: string,
        plotCode: string,
        detailOut: PlotOut,
        subdomainZoneId?: number,
        bufferSize?: number | null,
    ): Promise<PlotPreviewDiff> {
        const params = { subdomain_id: subdomainZoneId };
        const res = await this.http.put(
            `${this.rootPath}/v1/crop-plans/${businessId}/plans/${cropPlanId}/${domainZoneId}/plots/${plotCode}/preview`,
            {
                ...detailOut,
                fromPointInTime: formatDate(detailOut.fromPointInTime),
                bufferSize: bufferSize,
            },
            { params }
        );
        return res.data;
    }

    public async editPlotData(
        businessId: string,
        cropPlanId: number,
        domainZoneId: string,
        plotCode: string,
        description: string | null,
        notes: string | null,
    ): Promise<void> {
        const url = `${this.rootPath}/v1/crop-plans/${businessId}/plans/${cropPlanId}/${domainZoneId}/plots/${plotCode}/name`;
        await this.http.put<PlotResponseDiff>(url, {
            description,
            notes
        });
    }

    public async editPlot(
        businessId: string,
        cropPlanId: number,
        domainZoneId: string,
        plotCode: string,
        detailOut: PlotOut,
        ignoreDeclValidationWarnings: boolean,
        subdomainZoneId?: number,
        bufferSize?: number | null,
    ): Promise<PlotResponseDiff> {
        const body = {
            ...detailOut,
            fromPointInTime: formatDate(detailOut.fromPointInTime),
            bufferSize: bufferSize,
        };
        const params = { ignoreDeclValidationWarnings, subdomain_id: subdomainZoneId };
        const res = await this.http.put<PlotResponseDiff>(
            `${this.rootPath}/v1/crop-plans/${businessId}/plans/${cropPlanId}/${domainZoneId}/plots/${plotCode}`,
            body,
            { params }
        );
        this.formatDateResponseDiff(res);
        return res.data;
    }

    public async editMultiplePlotPreview(
        businessId: string,
        cropPlanId: number,
        domainZoneId: string,
        pointInTime: Date,
        plots: PlotPreview[],
        behaviour: string,
        subdomainZoneId?: number
    ): Promise<PlotPreviewDiff> {
        const params = { subdomain_id: subdomainZoneId };
        const res = await this.http.put<PlotPreviewDiff>(
            `${this.rootPath}/v1/crop-plans/${businessId}/plans/${cropPlanId}/${domainZoneId}/plots/preview`,
            {
                fromPointInTime: formatDate(pointInTime),
                description: undefined,
                plots: plots,
                cutParameters: {
                    behaviour: behaviour,
                },
            },
            { params }
        );
        return res.data;
    }

    public async editMultiplePlot(
        businessId: string,
        cropPlanId: number,
        domainZoneId: string,
        pointInTime: Date,
        plots: PlotPreview[],
        behaviour: string,
        ignoreDeclValidationWarnings: boolean,
        subdomainZoneId?: number
    ): Promise<PlotResponseDiff> {
        const body = {
            fromPointInTime: formatDate(pointInTime),
            description: undefined,
            plots: plots,
            cutParameters: {
                behaviour: behaviour,
            },
        };
        const params = { ignoreDeclValidationWarnings, subdomain_id: subdomainZoneId };
        const res = await this.http.put<PlotResponseDiff>(
            `${this.rootPath}/v1/crop-plans/${businessId}/plans/${cropPlanId}/${domainZoneId}/plots`,
            body,
            { params }
        );
        this.formatDateResponseDiff(res);
        return res.data;
    }

    public async deletePlot(
        businessId: string,
        cropPlanId: number,
        domainZoneId: string,
        plotCode: string,
        pointInTime: Date,
        ignoreDeclValidationWarnings: boolean
    ): Promise<PlotResponseDiff> {
        const res = await this.http.delete<PlotResponseDiff>(
            `${this.rootPath}/v1/crop-plans/${businessId}/plans/${cropPlanId}/${domainZoneId}/plots/${plotCode}`,
            {
                params: {
                    fromPointInTime: formatDate(pointInTime),
                    ignoreDeclValidationWarnings,
                },
            }
        );
        this.formatDateResponseDiff(res);
        return res.data;
    }

    public async deletePlots(
        businessId: string,
        cropPlanId: number,
        domainZoneId: string,
        pointInTime: Date,
        plotCodes: Array<string>
    ): Promise<PlotResponseDiff> {
        const res = await this.http.post<PlotResponseDiff>(
            `${this.rootPath}/v1/crop-plans/${businessId}/plans/${cropPlanId}/${domainZoneId}/delete-plots`,
            { plotCodes },
            { params: { fromPointInTime: formatDate(pointInTime) } }
        );

        this.formatDateResponseDiff(res);
        return res.data;
    }

    private formatDateResponseDiff(res: AxiosResponse<PlotResponseDiff>) {
        res.data.added?.forEach((p) => {
            toDateFromFormat(p, ["fromDate", "toDate", "fullRangeFromDate", "fullRangeToDate"]);
            p.decls.forEach((d) => toDateFromFormat(d, ["fromDate", "toDate"]));
        });
        res.data.updated?.forEach((p) => {
            toDateFromFormat(p, ["fromDate", "toDate", "fullRangeFromDate", "fullRangeToDate"]);
            p.decls.forEach((d) => toDateFromFormat(d, ["fromDate", "toDate"]));
        });
    }

    public async restorePlot(
        businessId: string,
        cropPlanId: number,
        domainZoneId: string,
        plotCode: string,
        pointInTime: Date,
        ignoreDeclValidationWarnings: boolean
    ): Promise<PlotResponseDiff> {
        const body = {
            fromPointInTime: formatDate(pointInTime),
        };
        const params = { ignoreDeclValidationWarnings };
        const res = await this.http.put<PlotResponseDiff>(
            `${this.rootPath}/v1/crop-plans/${businessId}/plans/${cropPlanId}/${domainZoneId}/plots/${plotCode}/restore_default`,
            body,
            { params }
        );
        return res.data;
    }

    public async restoreFirstVersion(
        businessId: string,
        cropPlanId: number,
        domainZoneId: string,
        plotCode: string,
        pointInTime: Date,
    ): Promise<PlotResponseDiff> {
        const body = {
            pointInTime: formatDate(pointInTime),
        };
        const res = await this.http.put<PlotResponseDiff>(
            `${this.rootPath}/v1/crop-plans/${businessId}/plans/${cropPlanId}/${domainZoneId}/plots/${plotCode}/resume-first-version`,
            body,
        );
        return res.data;
    }

    public async restorePlots(
        businessId: string,
        cropPlanId: number,
        domainZoneId: string,
        plotCodes: string[],
        pointInTime: Date,
        ignoreDeclValidationWarnings: boolean
    ): Promise<PlotResponseDiff> {
        const body = {
            plotCodes: plotCodes,
            fromPointInTime: formatDate(pointInTime),
        };
        const params = { ignoreDeclValidationWarnings };
        const res = await this.http.put<PlotResponseDiff>(
            `${this.rootPath}/v1/crop-plans/${businessId}/plans/${cropPlanId}/${domainZoneId}/plots/restore_default`,
            body,
            { params }
        );
        return res.data;
    }

    public async getBuffer(
        businessId: string,
        cropPlanId: number,
        domainZoneId: string,
        plotCode: string | null,
        pointInTime: Date,
    ): Promise<PlotBuffer> {
        const url = `${this.rootPath}/v1/crop-plans/${businessId}/plans/${cropPlanId}/zones/${domainZoneId}/plots/${plotCode}/buffer`;
        const res = await this.http.get(url, {
            params: { pointInTime: formatDate(pointInTime) },
        });

        return res.data;
    }

    public async insertBufferPreview(
        businessId: string,
        cropPlanId: number,
        domainZoneId: string,
        pointInTime: Date,
        geom: string,
        bufferSize: number,
        bufferPosition: string,
        bufferBehaviour: BufferBehaviour,
        plotCodes: string[] | null,
        subdomainZoneId?: number
    ): Promise<PlotPreviewDiff> {
        const url = `${this.rootPath}/v1/crop-plans/${businessId}/plans/${cropPlanId}/${domainZoneId}/plots/line-buffer/preview`;
        const body = {
            fromPointInTime: formatDate(pointInTime),
            geom: geom,
            bufferSize: bufferSize,
            drawLineBufferParameters: {
                behaviour: bufferBehaviour,
                position: bufferPosition,
                plotCodes: plotCodes,
            },
        };
        const params = { subdomain_id: subdomainZoneId }
        const res = await this.http.post(url, body, { params });
        return res.data;
    }

    public async insertBuffer(
        businessId: string,
        cropPlanId: number,
        domainZoneId: string,
        pointInTime: Date,
        geom: string,
        bufferSize: number,
        bufferPosition: string,
        bufferBehaviour: BufferBehaviour,
        plotCodes: string[] | null,
        ignoreDeclValidationWarnings: boolean,
        subdomainZoneId?: number
    ): Promise<PlotResponseDiff> {
        const url = `${this.rootPath}/v1/crop-plans/${businessId}/plans/${cropPlanId}/${domainZoneId}/plots/line-buffer`;
        const body = {
            fromPointInTime: formatDate(pointInTime),
            geom: geom,
            bufferSize: bufferSize,
            drawLineBufferParameters: {
                behaviour: bufferBehaviour,
                position: bufferPosition,
                plotCodes: plotCodes,
            },
        };
        const params = { ignoreDeclValidationWarnings, subdomain_id: subdomainZoneId };
        const res = await this.http.post<PlotResponseDiff>(url, body, { params });
        this.formatDateResponseDiff(res);
        return res.data;
    }

    public async addToFavourite(businessId: string, cropPlanId: number, landUseCode: string): Promise<void> {
        const res = await this.http.put(
            `${this.rootPath}/v1/crop-codes/${businessId}/plans/${cropPlanId}/land-uses/${landUseCode}/favourite`
        );
        return res.data;
    }

    public async editParcelNotes(
        businessId: string,
        cropPlanId: number,
        parcelCode: string,
        notes: string
    ): Promise<void> {
        const body = { notes: notes };
        const url = `${this.rootPath}/v1/crop-plans/${businessId}/plans/${cropPlanId}/parcels/${parcelCode}/data`;
        const res = await this.http.put(url, body);
        return res.data;
    }

    public async removeFromFavourite(businessId: string, cropPlanId: number, landUseCode: string): Promise<void> {
        const res = await this.http.delete(
            `${this.rootPath}/v1/crop-codes/${businessId}/plans/${cropPlanId}/land-uses/${landUseCode}/favourite`
        );
        return res.data;
    }

    public async getCuttableLayers(
        businessId: string,
        cropPlanId: number,
        domainZoneId: string,
        subdomainZoneId: number | undefined,
        plotCodes: string[],
        LayerCodes: string[],
        pointInTime: Date
    ): Promise<CuttableLayer[]> {
        const url = `${this.rootPath}/v1/crop-plans/${businessId}/plans/${cropPlanId}/${domainZoneId}/plots/cuttable-layers`;
        const params = {
            ...(subdomainZoneId && { subdomainZoneId }),
        }
        const payload = {
            plotCodes: plotCodes,
            layerCodes: LayerCodes,
            pointInTime: formatDate(pointInTime),
        }
        const res = await this.http.post<CuttableLayer[]>(url, payload, { params });
        return res.data;
    }
}
