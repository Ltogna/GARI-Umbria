import { VueRegistration } from "@abaco/web-common/src/app";

const globals: VueRegistration = {
    BusinessSelectNavBarItem: () => import("./components/navbar/business-select/BusinessSelectNavBarItem.vue"),
    CropPlanSelectNavBarItem: () => import("./components/navbar/crop-plan-select/CropPlanSelectNavBarItem.vue"),
    CouncilSelectNavBarItem: () => import("./components/navbar/council-select/CouncilSelectNavBarItem.vue"),
    PointInTimeSelectNavBarItem: () =>
        import("./components/navbar/point-in-time-select/PoinInTimeSelectNavBarItem.vue"),

    SearchCropPlansEdit: () => import("./components/navbar/crop-plan-select/SearchCropPlansEdit.vue"),
    CropPlanEditModal: () => import("./components/navbar/crop-plan-select/CropPlanEditModal.vue"),
    SwapLandusesModal: () => import("./components/private/SwapLandusesModal.vue"),

    SingleCpPlotList: () => import("./components/tiles/SingleCpPlotList.vue"),
    SingleCpPlotInfo: () => import("./components/tiles/SingleCpPlotInfo.vue"),
    SingleCpPlotEdit: () => import("./components/tiles/SingleCpPlotEdit.vue"),
    SingleCpMap: () => import("./components/tiles/SingleCpMap.vue"),

    // TODO - REMOVE
    SingleCpDeclarationEdit: () => import("./components/tiles/SingleCpDeclarationEdit.vue"),

    SingleCpAddPesticide: () => import("./components/tiles/SingleCpAddPesticide.vue"),
    SingleCpPesticides: () => import("./components/tiles/SingleCpPesticides.vue"),
    SingleCpAddPest: () => import("./components/tiles/SingleCpAddPest.vue"),
    SingleCpPests: () => import("./components/tiles/SingleCpPests.vue"),
    SingleCpDeclPesticideEdit: () => import("./components/tiles/SingleCpDeclPesticideEdit.vue"),
    SingleCpDeclPestEdit: () => import("./components/tiles/SingleCpDeclPestEdit.vue"),
    LandUseAdditionalOptionsParser: () => import("./components/tiles/LandUseAdditionalOptionsParser.vue")
};

export default globals;
