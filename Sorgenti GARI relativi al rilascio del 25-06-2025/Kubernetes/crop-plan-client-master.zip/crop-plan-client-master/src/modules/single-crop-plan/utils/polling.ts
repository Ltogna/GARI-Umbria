/**
 * Executes the provided async function `fun`:
 * - if it returns `true` it will try it again after a `wait` timeout;
 * - otherwise it will do nothing.
 */
export async function pollFunction(fun: () => Promise<any>, wait = 5000) {
    const res = await fun();
    if (res === true) {
        await new Promise((resolve) => setTimeout(resolve, wait));
        await pollFunction(fun, wait);
    }
}