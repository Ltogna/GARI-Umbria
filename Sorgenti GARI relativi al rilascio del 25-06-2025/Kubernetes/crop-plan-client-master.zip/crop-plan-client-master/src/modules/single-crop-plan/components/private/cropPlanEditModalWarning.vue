<template>
    <!-- z-index was forced to 52 because the map on fullscreen mode is z-50 and confirmation delete on z-51 -->
    <abc-modal
        v-if="showWarningModal || showWarningDateModal"
        :additionalStyle="{ 'z-index': 52 }"
        @close="cancel"
        isMessage
    >
        <template #body>
            <div
                class="mx-auto flex items-center justify-center rounded-full bg-bg-500 text-secondary-300"
                style="width: 65px; height: 65px; font-size: 28px"
            >
                <em class="fal fa-calendar-day" style="margin-top: -3px" />
            </div>
            <div v-if="showWarningModal">
                <div v-if="fixedEditDate" class="flex flex-col items-center justify-center">
                    <p class="pt-4 text-lg px-6">{{ i18n("edits-require-fixed-date-confirm-update") }}</p>
                    <p class="pt-1 text-lg font-bold">{{ formattedDate(fixedEditDate) }}</p>
                </div>
                <template v-else>
                    <div class="flex flex-col items-center justify-center">
                        <p class="pt-4 text-lg px-6">{{ i18n("edit-will-be-applied-from") }}</p>
                        <p class="pt-1 text-lg font-bold">{{ formattedDate(curPointInTime) }}</p>
                    </div>
                    <abc-checkbox
                        v-model="editModalWarningDisabled"
                        class="mt-4 px-6"
                        :label="i18n('do-not-show-anymore')"
                    >
                    </abc-checkbox>
                </template>
            </div>
            <div v-if="showWarningDateModal" class="text-center pt-6">
                <p>
                    <strong>{{ i18n('crop-in-progress-warning-1') }}</strong> {{ i18n('crop-in-progress-warning-2') }} <br/> 
                    {{ i18n('crop-in-progress-warning-3') }} <strong>{{ minAndMaxDateFormatted.minDate }}</strong> {{ i18n('crop-in-progress-warning-4') }} <strong>{{ minAndMaxDateFormatted.maxDate }}</strong>
                </p>
            </div>
        </template>
        <template #footer>
            <div class="flex w-full justify-end">
                <template v-if="fixedEditDate">
                    <abc-button @click="cancel" is-outlined class="flex">
                        <em class="fal fa-calendar" style="margin-right: 6px" />
                        <p>{{ i18n("cancel") }}</p>
                    </abc-button>
                    <abc-button
                        v-if="new Date(formattedDate(fixedEditDate)).getTime() !== curPointInTime.getTime()"
                        @click="applyFixedDate"
                        is-success
                        class="flex"
                    >
                        <em class="fal fa-arrow-right" style="margin-right: 7px; margin-top: 1px" />
                        <p>{{ i18n("go-to-date") }}</p>
                    </abc-button>
                </template>
                <template v-else>
                    <abc-button @click="switchDate" is-outlined class="flex">
                        <em class="fal fa-calendar" style="margin-right: 6px" />
                        <p>{{ i18n("switch-date") }}</p>
                    </abc-button>
                    <abc-button @click="proceed" is-success class="flex">
                        <em class="fal fa-arrow-right" style="margin-right: 7px; margin-top: 1px" />
                        <p>{{ i18n("continue") }}</p>
                    </abc-button>
                </template>
            </div>
        </template>
    </abc-modal>
</template>

<script lang="ts">
import { Component, Inject, Watch, Mixins } from "vue-property-decorator";
import { TranslateResult } from "vue-i18n";
import { FromStore } from "@abaco/web-common/src/app";
import SingleCropPlan from "../..";
import { EditPlotMode } from "../../models/Plot";
import DateUtils from "../../mixins/DateUtils";
import { Declaration } from "../../models/Declaration";
import { Configuration, CropPlanDates } from "../../models/CropPlan";

interface Interval {
    minDate: Date;
    maxDate: Date;
}

@Component
export default class CropPlanEditModalWarning extends Mixins(DateUtils) {
    @Inject() i18n!: (key: string, values?: unknown) => TranslateResult;

    @FromStore(SingleCropPlan.MODULE_ID) editPlotMode!: EditPlotMode;
    @FromStore(SingleCropPlan.MODULE_ID) editModalWarningDisabled!: boolean;
    @FromStore(SingleCropPlan.MODULE_ID) curPointInTime!: Date;
    @FromStore(SingleCropPlan.MODULE_ID) pointInTimeNavBarFilterOpen!: boolean;
    @FromStore(SingleCropPlan.MODULE_ID) currentPlotDeclarations!: Declaration[];
    @FromStore(SingleCropPlan.MODULE_ID) cropPlanDates!: CropPlanDates;

    private showWarningModal = false;
    private showWarningDateModal = false;
    private sortedDeclarations: Declaration[] = [];
    private fixedEditDate: Date | null = null;

    @Watch("editPlotMode")
    onModeChange() {
        this.showWarningModal = false;
        this.showWarningDateModal = false;
        this.fixedEditDate = null;
        //
        if (this.editPlotMode !== EditPlotMode.NOT_SELECTED) {
            const now = new Date();
            const fixedDateStr = this.cropPlanDates?.fixedEditDate;
            if (typeof fixedDateStr == "string") {
                this.fixedEditDate =
                    fixedDateStr.length == 4
                        ? new Date(
                              now.getFullYear() - 1,
                              parseInt(fixedDateStr.slice(0, 2)) - 1,
                              parseInt(fixedDateStr.slice(2))
                          )
                        : new Date(
                              parseInt(fixedDateStr.slice(0, 4)),
                              parseInt(fixedDateStr.slice(4, 6)) - 1,
                              parseInt(fixedDateStr.slice(6))
                          );
                if (this.formattedDate(this.curPointInTime) != this.formattedDate(this.fixedEditDate)) {
                    this.showWarningModal = true;
                }
            } else if (fixedDateStr) {
                if (!this.editModalWarningDisabled) this.showWarningModal = true; 
                if (this.minAndMaxDate) this.showWarningDateModal = true;
            }
        }
    }

    @Watch("currentPlotDeclarations")
    private onDeclarations() {
        this.sortedDeclarations = [...this.currentPlotDeclarations].sort((a, b) => {
            if (a.fromDate.getTime() < b.fromDate.getTime()) {
                return -1;
            }
            if (a.fromDate.getTime() > b.fromDate.getTime()) {
                return 1;
            }
            return 0;
        });
    }

    private get minAndMaxDate(): Interval | undefined {
        if (this.sortedDeclarations.length === 0) {
            return undefined;
        }
        const intervals: Interval[] = [];
        this.sortedDeclarations.forEach((sd) => {
            if (intervals.length == 0) {
                intervals.push({ minDate: sd.fromDate, maxDate: sd.toDate });
                return;
            }
            const intervalFound = intervals.find((i) => this.isLesser(sd.fromDate, i.maxDate));
            if (intervalFound) {
                intervalFound.maxDate.setTime(Math.max(sd.toDate.getTime(), intervalFound.maxDate.getTime()));
            } else {
                intervals.push({ minDate: sd.fromDate, maxDate: sd.toDate });
            }
        });
        return intervals.find(
            (i) => this.isLesser(i.minDate, this.curPointInTime) && this.isGreater(i.maxDate, this.curPointInTime)
        );
    }

    private get minAndMaxDateFormatted() {
        if (this.minAndMaxDate) {
            return {
                minDate: this.formattedDate(this.minAndMaxDate.minDate),
                maxDate: this.formattedDate(this.minAndMaxDate.maxDate),
            };
        }
        return undefined;
    }

    private isGreater(d1: Date | null, d2: Date | null) {
        const t1 = d1 ? d1.getTime() : +Infinity;
        const t2 = d2 ? d2.getTime() : -Infinity;
        return t1 > t2;
    }

    private isLesser(d1: Date | null, d2: Date | null) {
        const t1 = d1 ? d1.getTime() : -Infinity;
        const t2 = d2 ? d2.getTime() : +Infinity;
        return t1 < t2;
    }

    private cancel() {
        this.editPlotMode = EditPlotMode.NOT_SELECTED;
        this.closeWarnings();
    }

    private switchDate() {
        this.editPlotMode = EditPlotMode.NOT_SELECTED;
        this.closeWarnings();
        this.pointInTimeNavBarFilterOpen = true;
    }

    private proceed() {
        this.closeWarnings();
    }

    private closeWarnings() {
        this.showWarningModal = false;
        this.showWarningDateModal = false;
    }

    private applyFixedDate() {
        if (this.fixedEditDate) {
            this.curPointInTime = this.fixedEditDate;
            this.cancel();
        }
    }
}
</script>
