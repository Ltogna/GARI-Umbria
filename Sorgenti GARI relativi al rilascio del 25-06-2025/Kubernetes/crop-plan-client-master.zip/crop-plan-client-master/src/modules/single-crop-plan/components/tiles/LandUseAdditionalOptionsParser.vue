<template>
    <div class="flex flex-col space-y-6">
        <div v-for="(luaoHTC, indexHeaderTitleCode) in Object.entries(luaoHeaderTitleCode)" :key="indexHeaderTitleCode">
            <abc-accordion
                :forceUpdate="forceUpdate"
                :value="accordionRef[luaoHTC[0]]"
                @input="(e) => setAccordionRef(e, luaoHTC[0])"
                class="w-full"
            >
                <template #title>
                    <div class="w-full flex items-center justify-between mr-2">
                        <div>{{ getHeaderTitleDescription(luaoHTC[0]) }}</div>
                    </div>
                </template>

                <template #content>
                    <div class="p-4">
                        <div
                            v-for="(luaoGC, indexGropCode) in Object.entries(luaoGroupCode(luaoHTC[0]))"
                            class="flex flex-col space-y-4 p-2"
                            :class="{ 'border rounded-xl': luaoGC[0] !== 'null' }"
                            :key="indexGropCode"
                        >
                            <abc-checkbox
                                v-if="chooseOptionsToUpdate && luaoGC[0] !== 'null'"
                                :value="selectedForUpdateFieldCodes.includes(luaoGC[0])"
                                @input="updateLuaoSelection(luaoGC[0])"
                                class="mr-3"
                            >
                            </abc-checkbox>
                            <div v-for="(luao, index) in luaoGC[1]" class="flex items-center w-full" :key="index">
                                <abc-checkbox
                                    v-if="chooseOptionsToUpdate && luao && luaoGC[0] === 'null'"
                                    :value="selectedForUpdateFieldCodes.includes(luao.fieldCode)"
                                    @input="updateLuaoSelection(luao.fieldCode)"
                                    class="mr-3"
                                >
                                </abc-checkbox>
                                <abc-radio
                                    v-if="luao && luaoGC[0] !== 'null'"
                                    v-model="radiosNoneOfThePrevious[indexGropCode]"
                                    @input="(currVal) => onRadioChange(currVal, luaoGC[1])"
                                    :is-disabled="isDisabled(luao, luaoGC[0], radiosNoneOfThePrevious[indexGropCode])"
                                    :radio-value="luao.fieldCode"
                                />
                                <abc-dropdown2
                                    v-if="luao && luao.fieldType == 'COMBO'"
                                    class="w-full"
                                    :label="luao.fieldDescription"
                                    :items="luao.allowedValues"
                                    :max-height="'200px'"
                                    v-model="luao.selectedValue"
                                    @input="forceAutocompleteFieldsValidation(luao.fieldCode)"
                                    maxHeight="300px"
                                    :is-required="!luao.nullable"
                                    :is-disabled="
                                        isComboDisabled(luao, luaoGC[0], radiosNoneOfThePrevious[indexGropCode])
                                    "
                                    :rules="
                                        hasToRunRules(
                                            luao.selectedValue.value,
                                            luao.nullable,
                                            luao.fieldCode,
                                            radiosNoneOfThePrevious[indexGropCode]
                                        )
                                            ? [
                                                  mandatoryRule,
                                                  comboMandatoryRule,
                                                  additionalRules(luao.allowedValues, luao.nullable),
                                              ]
                                            : []
                                    "
                                    @error-status="onFieldError(luao.fieldCode)"
                                >
                                    <p>
                                        {{
                                            luao.selectedValue
                                                ? overrideEmptyString(luao.selectedValue.valueDescription)
                                                : ""
                                        }}
                                    </p>
                                    <template #items="{ item }">
                                        <div class="cursor-pointer">
                                            {{ overrideEmptyString(item.valueDescription) }}
                                        </div>
                                    </template>
                                </abc-dropdown2>
                                <abc-input
                                    v-if="luao.fieldType == 'PERCENTAGE'"
                                    class="w-full"
                                    :label="luao.fieldDescription"
                                    :isNumeric="true"
                                    :decimals="2"
                                    right-tools
                                    remove-trailing-zero
                                    :value="parsePercentage(luao.selectedValue.value)"
                                    @input="setPercentage($event, luao)"
                                    :is-required="!luao.nullable"
                                    :is-disabled="
                                        isDisabled(luao, luaoGC[0], parsePercentage(luao.selectedValue.value))
                                    "
                                    :rules="
                                        hasToRunRules(
                                            luao.selectedValue.value,
                                            luao.nullable,
                                            luao.fieldCode,
                                            radiosNoneOfThePrevious[indexGropCode]
                                        )
                                            ? [
                                                  mandatoryRule,
                                                  percentageRule,
                                                  additionalRules(luao.allowedValues, luao.nullable),
                                              ]
                                            : fieldChecked(luao.fieldCode)
                                            ? [percentageRule, additionalRules(luao.allowedValues, luao.nullable)]
                                            : []
                                    "
                                    @error-status="onFieldError(luao.fieldCode)"
                                >
                                    <template #right>%&thinsp;</template>
                                </abc-input>

                                <abc-input
                                    v-if="luao.fieldType == 'INTEGER'"
                                    :ref="`luao-${luao.fieldType}-${luao.fieldCode}`"
                                    class="w-full"
                                    :label="luao.fieldDescription"
                                    :isNumeric="true"
                                    :decimals="0"
                                    remove-trailing-zero
                                    autocomplete="off"
                                    :value="luao.formula ? integerValue(luao) : parseInteger(luao.selectedValue.value)"
                                    @input="setInteger($event, luao)"
                                    :is-required="!luao.nullable"
                                    :is-disabled="isDisabled(luao, luaoGC[0], parseInteger(luao.selectedValue.value))"
                                    :rules="
                                        hasToRunRules(
                                            luao.selectedValue.value,
                                            luao.nullable,
                                            luao.fieldCode,
                                            radiosNoneOfThePrevious[indexGropCode]
                                        )
                                            ? [mandatoryRule, additionalRules(luao.allowedValues, luao.nullable)]
                                            : fieldChecked(luao.fieldCode)
                                            ? [additionalRules(luao.allowedValues, luao.nullable)]
                                            : []
                                    "
                                />

                                <abc-input
                                    v-if="luao.fieldType == 'NUMBER'"
                                    :ref="`luao-${luao.fieldType}-${luao.fieldCode}`"
                                    class="w-full"
                                    :label="luao.fieldDescription"
                                    :isNumeric="true"
                                    :decimals="2"
                                    remove-trailing-zeroÍ
                                    :value="luao.formula ? numberValue(luao) : parseNumber(luao.selectedValue.value)"
                                    @input="setNumber($event, luao)"
                                    :is-required="!luao.nullable"
                                    :is-disabled="isDisabled(luao, luaoGC[0], parseNumber(luao.selectedValue.value))"
                                    :rules="
                                        hasToRunRules(
                                            luao.selectedValue.value,
                                            luao.nullable,
                                            luao.fieldCode,
                                            radiosNoneOfThePrevious[indexGropCode]
                                        )
                                            ? [mandatoryRule, additionalRules(luao.allowedValues, luao.nullable)]
                                            : fieldChecked(luao.fieldCode)
                                            ? [additionalRules(luao.allowedValues, luao.nullable)]
                                            : []
                                    "
                                />

                                <abc-textarea
                                    v-if="luao.fieldType == 'STRING'"
                                    class="w-full"
                                    :label="luao.fieldDescription"
                                    :value="luao.selectedValue.value"
                                    maxlength="4000"
                                    @input="setText($event, luao)"
                                    :is-required="!luao.nullable"
                                    :is-disabled="isDisabled(luao, luaoGC[0], luao.selectedValue.value)"
                                    :rules="
                                        hasToRunRules(
                                            luao.selectedValue.value,
                                            luao.nullable,
                                            luao.fieldCode,
                                            radiosNoneOfThePrevious[indexGropCode]
                                        )
                                            ? [mandatoryRule, additionalRules(luao.allowedValues, luao.nullable)]
                                            : fieldChecked(luao.fieldCode)
                                            ? [additionalRules(luao.allowedValues, luao.nullable)]
                                            : []
                                    "
                                    @error-status="onFieldError(luao.fieldCode)"
                                />
                            </div>

                            <abc-radio
                                v-if="luaoGC[0] !== 'null'"
                                v-model="radiosNoneOfThePrevious[indexGropCode]"
                                @input="(currVal) => onNoneOfThePreviousRadioChange(currVal, luaoGC[1])"
                                :is-disabled="
                                    isNoneOfThePreviosRadioDisabled(luaoGC, radiosNoneOfThePrevious[indexGropCode])
                                "
                                radio-value="NONE"
                                :label="i18n('none-of-the-previous')"
                            />
                        </div>
                    </div>
                </template>
            </abc-accordion>
        </div>
    </div>
</template>

<script lang="ts">
import { Component, Inject, Mixins, Prop, Watch } from "vue-property-decorator";
import { TranslateResult } from "vue-i18n";
import SingleCropPlanModule, { MODULE_ID } from "../..";
import DateUtils from "../../mixins/DateUtils";
import AreaUtils from "../../mixins/AreaUtils";
import DeclFieldEditability from "../../mixins/DeclFieldEditability";
import { LandUseAdditionalDataConf, LandUseAdditionalDataField } from "../../models/Plot";
import cloneDeep from "lodash/cloneDeep";
import { groupBy, notEmpty } from "../../api/Utils";
import { evaluate } from "mathjs";
import { AbcInputExtended } from "../../models/AbcInputExtended";

@Component
export default class LandUseAdditionalOptionsParser extends Mixins(DateUtils, AreaUtils, DeclFieldEditability) {
    @Inject() i18n!: (key: string, values?: unknown) => TranslateResult;
    @Inject(MODULE_ID) singleCropPlanModule!: SingleCropPlanModule;

    @Prop() landUseAdditionalOptions!: LandUseAdditionalDataConf[];
    @Prop({ default: false }) isNew!: boolean;
    @Prop({ default: 0 }) forceUpdate!: number;
    @Prop({ default: false }) chooseOptionsToUpdate!: boolean;
    @Prop({ default: false }) disableNotCheckedFields!: boolean;
    @Prop({ default: false }) disableCheckOnMandatoryDeclFields!: boolean;

    private deepCloneLandUseAdditionalOptions = cloneDeep(this.landUseAdditionalOptions);
    private radiosNoneOfThePrevious: string[] = [];
    private accordionRef: Record<string, boolean> = {};
    // private forceUpdateAccordions: number[] = [];
    private selectedForUpdateFieldCodes: string[] = [];

    beforeMount() {
        for (const luaoGC of Object.entries(this.luaoGroupCode())) {
            const [key, luao] = luaoGC;
            const isAllDefaultSetting = luao.every((it) => it.selectedValue?.value === it.defaultValue);

            if (isAllDefaultSetting && key !== "null") this.radiosNoneOfThePrevious.push("NONE");

            const diffFromDefaultSetting = luao.find((it) => it.selectedValue?.value !== it.defaultValue);
            if (diffFromDefaultSetting && key !== "null")
                this.radiosNoneOfThePrevious.push(diffFromDefaultSetting.fieldCode);
        }

        for (const luaoHTC of Object.entries(this.luaoHeaderTitleCode)) {
            this.accordionRef[luaoHTC[0]] = true;
            // this.forceUpdateAccordions.push(0);
        }
    }

    private parsePercentage(value: string): number {
        return parseFloat(value);
    }

    private parseInteger(value: string): number {
        return parseInt(value);
    }

    private parseNumber(value: string): number {
        return parseFloat(value);
    }

    private setPercentage(value: string, luao: LandUseAdditionalDataConf) {
        if (luao.selectedValue !== undefined) luao.selectedValue.value = value;
        this.forceAutocompleteFieldsValidation(luao.fieldCode);
    }

    private setInteger(value: string, luao: LandUseAdditionalDataConf) {
        if (luao.selectedValue !== undefined) luao.selectedValue.value = value;
        this.forceAutocompleteFieldsValidation(luao.fieldCode);
    }

    private setNumber(value: string, luao: LandUseAdditionalDataConf) {
        if (luao.selectedValue !== undefined) luao.selectedValue.value = value;
        this.forceAutocompleteFieldsValidation(luao.fieldCode);
    }

    private setText(value: string, luao: LandUseAdditionalDataConf) {
        if (luao.selectedValue !== undefined) luao.selectedValue.value = value;
        this.forceAutocompleteFieldsValidation(luao.fieldCode);
    }

    private integerValue(currLuao: LandUseAdditionalDataConf): number | null {
        if (!currLuao.formula) return null;

        const scope: Record<string, string> = {};
        for (const luao of this.landUseAdditionalOptions) {
            scope[luao.fieldCode] = luao.selectedValue?.value ?? "";
        }
        const res = evaluate(currLuao.formula, scope);
        const isValid = notEmpty(res) && !isNaN(res) && isFinite(res);
        if (currLuao.selectedValue !== undefined)
            currLuao.selectedValue.value = isValid ? Math.round(res).toString() : null;
        return isValid ? Math.round(res) : null;
    }

    private numberValue(currLuao: LandUseAdditionalDataConf): number | null {
        if (!currLuao.formula) return null;

        const scope: Record<string, string> = {};
        for (const luao of this.landUseAdditionalOptions) {
            scope[luao.fieldCode] = luao.selectedValue?.value ?? "";
        }
        const res = evaluate(currLuao.formula, scope);
        const isValid = notEmpty(res) && !isNaN(res) && isFinite(res);
        if (currLuao.selectedValue !== undefined) currLuao.selectedValue.value = isValid ? res.toString() : null;
        return isValid ? parseFloat(res) : null;
    }

    private forceAutocompleteFieldsValidation(fieldCode: string) {
        const luaos = this.deepCloneLandUseAdditionalOptions.filter(
            (it) => it.formula?.includes(fieldCode) || it.fieldCode === fieldCode
        );
        for (const luao of luaos) {
            const ref = this.$refs[`luao-${luao.fieldType}-${luao.fieldCode}`];
            if (ref && Array.isArray(ref)) {
                this.$nextTick(() => (ref[0] as AbcInputExtended).runRules());
            } else {
                ref && this.$nextTick(() => (ref as AbcInputExtended).runRules());
            }
        }
    }

    private get mandatoryRule() {
        return (v: unknown) =>
            this.disableCheckOnMandatoryDeclFields || !!v || v === 0 || this.i18n("valid.mandatory-field");
    }

    private get comboMandatoryRule() {
        return <T extends { value?: string }>(v: T) =>
            this.disableCheckOnMandatoryDeclFields || !!v.value || this.i18n("valid.mandatory-field");
    }

    private get percentageRule() {
        return (v: string) => {
            const convertedValue = parseInt(v);
            return (
                isNaN(convertedValue) ||
                (convertedValue >= 0 && convertedValue <= 100) ||
                this.i18n("between-0-and-100-rule")
            );
        };
    }

    private isInvalidRegex(regexStr: string): boolean {
        try {
            new RegExp(regexStr);
            return /^[0-9.]+$/.test(regexStr);
        } catch (e) {
            return true;
        }
    }

    private checkAllowedValue(allowedValues: LandUseAdditionalDataField[], value: string | null) {
        const valueOrRegexes = allowedValues.filter((it) => !!it.value).map((it) => it.value as string);

        if (!valueOrRegexes.length) return true;

        for (const valueOrRegex of valueOrRegexes) {
            if (value == valueOrRegex) {
                return true;
            }

            if (this.isInvalidRegex(valueOrRegex)) continue;

            const regex: any = new RegExp(valueOrRegex);
            if (regex.test(value)) {
                return true;
            }
        }
        return false;
    }

    private additionalRules(allowedValues: LandUseAdditionalDataField[], nullable: boolean) {
        return (v: unknown) => {
            const value: string | null =
                typeof v === "object" && v !== null
                    ? ((v as LandUseAdditionalDataField).value as string | null)
                    : (v as string | null);
            if ((!value && (nullable || this.disableCheckOnMandatoryDeclFields)) || !allowedValues.some((v) => v.value))
                return true;
            if (!value) return this.i18n("valid.mandatory-field");

            return this.checkAllowedValue(allowedValues, value) ? true : this.i18n("valid.invalid-value");
        };
    }

    private get luaoHeaderTitleCode() {
        return groupBy(this.deepCloneLandUseAdditionalOptions, "headerTitleCode");
    }

    private luaoGroupCode(headerTitleCode?: string | null) {
        if (headerTitleCode === undefined) return groupBy(this.deepCloneLandUseAdditionalOptions, "groupCode");

        if (headerTitleCode === "null") {
            return groupBy(
                this.deepCloneLandUseAdditionalOptions.filter(
                    (it) => it.headerTitleCode === JSON.parse(headerTitleCode)
                ),
                "groupCode"
            );
        }

        return groupBy(
            this.deepCloneLandUseAdditionalOptions.filter((it) => it.headerTitleCode === headerTitleCode),
            "groupCode"
        );
    }

    private getHeaderTitleDescription(headerTitleCode: string) {
        if (headerTitleCode === "null") return this.i18n("additional-attributes");

        return this.deepCloneLandUseAdditionalOptions.find((it) => it.headerTitleCode === headerTitleCode)
            ?.headerTitleDescription;
    }

    private setAccordionRef(e: boolean, key: string) {
        this.accordionRef[key] = e;
        this.accordionRef = { ...this.accordionRef };
    }

    // TODO WORKAROUND 03/12/24
    private fieldChecked(fieldCode: string) {
        if (!this.chooseOptionsToUpdate) return true;
        if (this.chooseOptionsToUpdate && this.selectedForUpdateFieldCodes.includes(fieldCode)) return true;
    }

    private hasToRunRules(value: string | null, isNullable: boolean, fieldCode: string, radioFieldCode: string) {
        if (!this.fieldChecked(fieldCode)) return false; // TODO WORKAROUND 03/12/24
        if(value === null && isNullable) return false;
        const allowedValues = this.deepCloneLandUseAdditionalOptions.find((it) => it.fieldCode === fieldCode)
            ?.allowedValues || [];
        if (!this.checkAllowedValue(allowedValues, value)) return true;
        if (!(radioFieldCode && fieldCode.toLowerCase().trim() === radioFieldCode.toLowerCase().trim())) {
            return false;
        } else {
            return true;
        }
    }

    private isDisabled(luao: LandUseAdditionalDataConf, fieldCode: string, val?: string | null | Date) {
        if (!luao.flEditable) return true;

        if (this.disableNotCheckedFields) {
            const codeToCheck = luao.groupCode ? luao.groupCode : luao.fieldCode;
            const isIncluded = this.selectedForUpdateFieldCodes.find((it) => it === codeToCheck);
            if (!isIncluded) return true;
        }

        return !this.checkIfFieldIsEditable(fieldCode, this.isNew, val);
    }

    private isComboDisabled(luao: LandUseAdditionalDataConf, key: string, radioFieldCode: string) {
        if (this.isDisabled(luao, key, radioFieldCode)) return true;
        if (key === "null") return false;

        if (radioFieldCode && luao.fieldCode.toLowerCase().trim() === radioFieldCode.toLowerCase().trim()) return false; // TODO controllare che i dati ritornati siano corretti

        return true;
    }

    private isNoneOfThePreviosRadioDisabled(luaoGC: [string, LandUseAdditionalDataConf[]], val?: string | null | Date) {
        const [fieldCode, list] = luaoGC;
        if (fieldCode === "null") return !this.checkIfFieldIsEditable(fieldCode, this.isNew, val);

        const isAllRadioDisabled = list.every((it) => this.isDisabled(it, fieldCode, val));
        return isAllRadioDisabled || !this.checkIfFieldIsEditable(fieldCode, this.isNew, val);
    }

    private onRadioChange(currVal: string, luaos: LandUseAdditionalDataConf[]) {
        for (const luao of luaos) {
            const isCurrent = luao.fieldCode === currVal;
            luao.selectedValue = luao.allowedValues[0];
            if (isCurrent) continue;

            const defaultVal = luao.allowedValues.find((it) => it.value === luao.defaultValue);
            if (defaultVal) luao.selectedValue = defaultVal;
        }
    }

    private onNoneOfThePreviousRadioChange(currVal: string, luaos: LandUseAdditionalDataConf[]) {
        if (currVal !== "NONE") return;

        for (const luao of luaos) {
            const defaultVal = luao.allowedValues.find((it) => it.value === luao.defaultValue);

            if (defaultVal) luao.selectedValue = defaultVal;
        }
    }

    private overrideEmptyString(value: string): string {
        if (!value) {
            return `--- ${this.i18n("no-value")} ---`;
        }

        return value;
    }

    private onFieldError(key: string) {
        if (this.curConfiguration?.DISABLE_VALID_VALUED_DECL_FIELDS_EDIT === "TRUE" && !this.isNew) {
            this.pushToNotValidFields(key);
            this.$forceUpdate(); // WORKAROUND: Need to force input componets rerender to update isDisabled property values
        }
    }

    private updateLuaoSelection(fieldCode: string) {
        if (this.selectedForUpdateFieldCodes.includes(fieldCode)) {
            this.selectedForUpdateFieldCodes = this.selectedForUpdateFieldCodes.filter((it) => it !== fieldCode);
        } else {
            this.selectedForUpdateFieldCodes.push(fieldCode);
        }
    }

    @Watch("deepCloneLandUseAdditionalOptions", { deep: true })
    private emitLandUseAdditionalOptionsUpdate() {
        this.$emit("updateLandUseAdditionalOptions", cloneDeep(this.deepCloneLandUseAdditionalOptions));
        // Update accordions
        // this.updateAccordions();
    }

    @Watch("selectedForUpdateFieldCodes", { deep: true })
    private emitSelectedForUpdateFieldCodes() {
        this.$emit("selectedForUpdateFieldCodes", cloneDeep(this.selectedForUpdateFieldCodes));
    }

    @Watch("forceUpdate")
    private updateAccordions() {
        this.$forceUpdate();
    }
}
</script>

<style lang="scss" scoped></style>
