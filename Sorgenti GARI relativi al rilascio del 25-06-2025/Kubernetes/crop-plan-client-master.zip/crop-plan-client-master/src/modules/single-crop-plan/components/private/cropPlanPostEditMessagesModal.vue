<template>
    <!-- z-index was forced to 51 because the map on fullscreen mode is z-50 -->
    <abc-modal
        v-if="showModal"
        :title="i18n('post-edit-messages')"
        :additionalStyle="{ 'z-index': 51 }"
        @close="onClose"
        modal-class="w-11/12 lg:w-8/12 xxl:w-4/12"
    >
        <template #body>
            <div v-for="(item, index) in messages" :key="index">
                <div class="flex items-center py-2" :class="item.blocking ? '' : ''">
                    <p class="text-xl">
                        <em v-if="item.blocking" class="abc-icon abc-icon-exclamation-point-triangle text-danger-500" />
                        <em v-else class="abc-icon abc-icon-exclamation-point-circle text-warning-500" />
                    </p>
                    <p class="pl-4 font-semibold">{{ item.message }}</p>
                </div>
            </div>
        </template>
        <template #footer>
            <abc-button @click="onClose" is-outlined>{{ i18n("close") }}</abc-button>
            <abc-button @click="proceedAnyWay" v-if="!isBlocking">{{ i18n("continue-anyway") }}</abc-button>
        </template>
    </abc-modal>
</template>

<script lang="ts">
import { Prop, Component, Vue, Inject, Watch } from "vue-property-decorator";
import { TranslateResult } from "vue-i18n";
import { ValidationMessage } from "../../models/Utils";

@Component
export default class CropPlanPostEditMessagesModal extends Vue {
    @Inject() i18n!: (key: string, values?: unknown) => TranslateResult;

    @Prop() messages!: ValidationMessage[];

    private loading = false;
    private showModal = false;

    private get isBlocking() {
        return this.messages.some((m) => m.blocking);
    }

    @Watch("messages")
    onMessageChange() {
        this.loading = false;
        this.showModal = this.messages.length > 0;
    }

    private onClose() {
        this.showModal = false;
        this.$emit("close");
    }

    private proceedAnyWay() {
        this.$emit("proceedAnyWay");
        this.showModal = false;
    }
}
</script>
