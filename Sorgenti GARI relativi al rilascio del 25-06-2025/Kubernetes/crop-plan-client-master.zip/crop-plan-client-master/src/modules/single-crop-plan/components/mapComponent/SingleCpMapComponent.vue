<template>
    <div class="w-full h-full">
        <!-- z-index was forced to 51 because the map on fullscreen mode is z-50 -->
        <abc-modal
            v-if="showAlertCodesModal"
            :additionalStyle="{ 'z-index': 51 }"
            @close="alertCodes = null"
            is-message
            modal-class="w-full md:w-8/12 lg:w-6/12 xxl:w-4/12"
            force-modal
        >
            <template #body>
                <div class="pt-2 pb-4 flex flex-col w-full">
                    <div
                        class="mx-auto flex items-center justify-center rounded-full bg-warning-100 text-warning-300"
                        style="width: 80px; height: 80px; font-size: 30px"
                    >
                        <em class="fa-solid fa-exclamation" />
                    </div>
                    <div class="mt-4 w-full">
                        <h3 class="text-lg text-center text-secondary-600">
                            <div class="flex flex-col">
                                <span v-for="alertCode in alertCodes" :key="alertCode">
                                    {{ i18n(alertCode.toLowerCase()) }}
                                </span>
                            </div>
                        </h3>
                    </div>
                </div>
            </template>
            <template #footer>
                <abc-button class="mx-2" is-success @click="alertCodes = null">{{ i18n("confirm") }}</abc-button>
            </template>
        </abc-modal>
        <cadastral-parcel-search-modal
            v-if="isCadastralParcelSearchEnabled && showCadastralParcelSearchModal"
            @close="showCadastralParcelSearchModal = false"
            @select="zoomOnCadastralParcel"
        />
        <div ref="plot_popover" v-show="showPlotPopover" class="plot-popover">
            <template v-if="hoveredPlot">
                <div v-if="hoveredPlot.description" class="plot-name">{{ hoveredPlot.description }}</div>
                <div>
                    <label>{{ i18n("pcf-label-area") }}:</label>
                    {{ formattedArea(hoveredPlot.areaSqm) }} ({{ areaLabel() }})
                </div>
                <div v-if="hoveredPlot.parcelIntersections.length > 0">
                    <div>
                        <label>{{ i18n("parcel-e") }}:</label>
                        <div v-for="parcel in hoveredPlot.parcelIntersections" :key="parcel.code">
                            {{ parcel.description }}
                        </div>
                    </div>
                    <div v-if="hasAtLeastOneLandCoverDescription">
                        <label>{{ i18n("land-cover-order") }}:</label>
                        <div v-for="parcel in hoveredPlot.parcelIntersections" :key="parcel.code">
                            {{ parcel.landCoverDescription }}
                        </div>
                    </div>
                </div>
                <div v-if="filteredHoveredPlotDeclarations.length">
                    <label>{{ i18n("crops") }}:</label>
                    <ul>
                        <template v-for="(decl, i) in filteredHoveredPlotDeclarations">
                            <li v-if="i < 20" :key="decl.declCode">
                                {{ decl.landuse.description ? decl.landuse.description : decl.landuse.code }}
                            </li>
                        </template>
                    </ul>
                    <small v-if="filteredHoveredPlotDeclarations.length > 20">
                        {{ i18n("plus-additional-coltures", { count: filteredHoveredPlotDeclarations.length - 20 }) }}
                    </small>
                </div>
            </template>
            <template v-if="hoveredLayerGeom && hoveredLayerGeom.tooltipData">
                <div>
                    <label>{{ getLayerDescription(hoveredLayerGeom.type) }}:</label>
                </div>
                <ul>
                    <template v-for="(value, key) in hoveredLayerGeom.tooltipData">
                        <li :key="key">
                            {{ `${key}: ${value}` }}
                        </li>
                    </template>
                </ul>
            </template>
        </div>
        <div ref="parcel_popover" v-show="showParcelPopover" class="plot-popover">
            <template v-if="hoveredParcel">
                <div>
                    <label>{{ i18n("pcf-label-area") }}:</label> {{ formattedArea(hoveredParcel.areaSqm) }} ({{
                        areaLabel()
                    }})
                </div>
                <div>
                    <label>{{ i18n("parcel-e") }}:</label>
                    {{ hoveredParcel.description }}
                </div>
                <div v-if="hoveredParcel.landCovers.length > 0">
                    <label>{{ i18n("land-cover-order") }}:</label>
                    <ul>
                        <li v-for="landCover in hoveredParcel.landCovers" :key="landCover.landCoverCode">
                            {{ landCover.landCoverDescription }}
                        </li>
                    </ul>
                </div>
            </template>
        </div>
        <div ref="cadastral_popover" v-show="showCadastralPopover" class="plot-popover">
            <template v-if="hoveredCadastral">
                <div>
                    <label>{{ i18n("pcf-label-area") }}:</label> {{ formattedArea(hoveredCadastral.areaSqm) }} ({{
                        areaLabel()
                    }})
                </div>
                <div>
                    <label>{{ i18n("sheet") }}:</label> {{ hoveredCadastral.sectorBlock }}
                </div>
                <div>
                    <label>{{ i18n("parcel-title") }}:</label> {{ hoveredCadastral.parcel }}
                </div>
            </template>
        </div>
        <abc-loader v-if="loadingSubdomainZone" scope="fixed"></abc-loader>
        <iacs-map-component
            v-if="curMbr"
            class="w-full h-full bg-secondary-600"
            :showActionBox="editPlotMode !== getEditPlotMode.NOT_SELECTED"
            :initial-mbr="curMbr"
            :srs="curCouncil.srs"
            :disable-single-child-layer-group="true"
            showFullscreenButton
            :max-zoom="curConfiguration.MAX_ZOOM ? curConfiguration.MAX_ZOOM : 21"
            @is-map-fullscreen-changed="onChangeIsMapOnFullScreen"
            @map-loaded="onMapLoaded"
            @pick="onPick"
            @hover="onHover"
            :padding="padding"
            has-additional-controls
            has-additional-management-controls
            hasHelpers
            :customControlStyle="{
                'margin-bottom': mapOnFullscreenStatus ? '0px' : `${paddingBottom}px`,
                'transition-property': 'all',
                'transition-duration': paddingBottom > 0 ? '220ms' : '0ms',
                'transition-timing-function': 'cubic-bezier(0.2, 0, 1, 1)',
            }"
            overlay-class="w-full md:w-11/12 xl:w-9/12 xxl:w-7/12"
            :notification-message="notificationMessage"
        >
            <template #helpers>
                <single-cp-map-help-measure
                    v-if="measureMap"
                    :map="localMap"
                    :snapLayers="snapLayers"
                    :plotsLayer="plotsLayer"
                    @close="measureMap = false"
                />
                <single-cp-map-help-legend v-else />
            </template>

            <operation-result
                v-if="editPlotMode !== getEditPlotMode.NOT_SELECTED && editPlotMode !== getEditPlotMode.ADDING_BUFFER"
                :previewLayerDiff="previewLayerDiff"
                :multiselectionIntersectedPlots="multiselectionIntersectedPlots"
                :map="map"
            />

            <gis-info
                v-if="gisInfoShow"
                :map="localMap"
                :additionalLayers="additionalLayers"
                @close="gisInfoActive = false"
                @panelHeightUpdated="(val) => (gisInfoPanelHeight = val)"
                @zoomOnMbr="zoomOnMbr"
            />

            <template #action-box>
                <div v-if="showBufferBehaviour && editPlotMode === getEditPlotMode.ADDING_BUFFER">
                    <div class="mb-5">
                        <p class="text-lg mb-2">{{ i18n("buffer-action-box-title") }}</p>
                        <p>{{ i18n("buffer-action-box-instruction") }}</p>
                    </div>
                    <div class="flex gap-8">
                        <div class="flex-auto">
                            <div class="flex gap-8">
                                <div class="flex-auto border-b pb-3 mb-3">
                                    <div v-if="curPlot || curPlots.length" class="flex gap-6 items-center">
                                        <abc-radio
                                            v-model="bufferBehaviour"
                                            radio-value="INTERNAL"
                                            :label="i18n('buffer-mode-border-internal')"
                                        />
                                        <abc-radio
                                            v-model="bufferBehaviour"
                                            radio-value="FREE_DRAW"
                                            :label="i18n('buffer-mode-internal')"
                                        />
                                        <abc-radio
                                            v-model="bufferBehaviour"
                                            radio-value="EXTERNAL"
                                            :label="i18n('buffer-mode-border-external')"
                                        />
                                    </div>
                                </div>
                                <div class="flex-initial flex items-center w-32 border-b pb-3 mb-3">
                                    {{ i18n("distance") }}
                                </div>
                            </div>
                            <div class="flex gap-8">
                                <div class="flex-auto flex gap-2">
                                    <abc-dropdown2
                                        class="info-select w-1/2"
                                        :items="bufferSizeOptions"
                                        v-model="bufferSize"
                                    >
                                        <p
                                            class="text-sm font-semibold tracking-wide"
                                            style="color: var(--primary-800)"
                                        >
                                            {{ bufferSize ? bufferSize.toLocaleString() : "" }} mt
                                        </p>
                                        <template #items="{ item }">
                                            <div class="text-sm cursor-pointer">{{ item }} mt</div>
                                        </template>
                                    </abc-dropdown2>
                                    <abc-dropdown2
                                        v-if="showBufferPositionSelect"
                                        v-model="bufferPosition"
                                        class="info-select w-1/2"
                                        :items="['CENTER', 'RIGHT', 'LEFT']"
                                    >
                                        <p
                                            class="text-sm font-semibold tracking-wide"
                                            style="color: var(--primary-800)"
                                        >
                                            {{ i18n("buffer-position-" + bufferPosition.toLowerCase()) }}
                                        </p>
                                        <template #items="{ item }">
                                            <div class="text-sm cursor-pointer">
                                                {{ i18n("buffer-position-" + item.toLowerCase()) }}
                                            </div>
                                        </template>
                                    </abc-dropdown2>
                                </div>
                                <div class="flex-initial w-32">
                                    {{ formattedDrawingDistance }}
                                </div>
                            </div>
                        </div>
                        <div class="flex-initial w-48">
                            <div>
                                <abc-button
                                    class="w-full"
                                    is-success
                                    :is-disabled="disableSave || loadingPreview || saving"
                                    @click="saveDrawing(false, showModalOnAlertCodes)"
                                >
                                    <abc-loader v-if="loadingPreview || saving" scope="absolute" :size="20" />
                                    <em class="abc-icon abc-icon abc-icon-floppy-disk" />
                                    <p>{{ i18n("save") }}</p>
                                </abc-button>
                            </div>
                            <div>
                                <abc-button
                                    class="w-full mt-2"
                                    is-secondary
                                    @click="forceResetEditModeAndCancelEditingOperation"
                                >
                                    <em class="abc-icon abc-icon-arrow-left-round" />
                                    <p>{{ i18n("cancel") }}</p>
                                </abc-button>
                            </div>
                        </div>
                    </div>
                </div>
                <div v-else class="flex flex-col w-full">
                    <div class="flex w-full text-lg font-semibold gap-6 mb-6">
                        <transition
                            name="custom-classes-transition"
                            enter-active-class="animate__animated animate__fadeIn animate__faster"
                            leave-active-class="animate__animated animate__fadeOut animate__faster"
                            mode="out-in"
                        >
                            <p :key="helperMessage ? helperMessage : 0" class="w-full">{{ helperMessage }}</p>
                        </transition>
                        <div class="w-full text-sm">
                            {{ i18n("map-actionbox-instructions-1") }}<br />{{ i18n("map-actionbox-instructions-2")
                            }}<br />{{ i18n("map-actionbox-instructions-3") }}
                        </div>
                        <div v-if="cutting" class="pl-2 text-sm font-normal">
                            <div class="w-32">
                                <div class="border-b pb-3 mb-3">
                                    {{ i18n("distance") }}
                                </div>
                                {{ formattedDrawingDistance }}
                            </div>
                        </div>
                    </div>

                    <div class="flex w-full">
                        <!-- CONFIG -->
                        <div
                            v-if="showPlotDescription || showCutBehaviour"
                            class="flex flex-grow justify-between items-center border-r border-secondary-600 pr-3 mr-3"
                        >
                            <div
                                v-if="showPlotDescription"
                                class="flex w-6/12 justify-end flex-col p-4 rounded-md h-full"
                                style="background: rgba(250, 250, 250, 0.2)"
                            >
                                <div class="text-sm pb-2">
                                    {{ i18n("insert-plot-name") }}
                                </div>
                                <abc-input class="text-text" v-model="curPlotOut.description"> </abc-input>
                            </div>
                            <div
                                class="flex flex-col"
                                :class="{ 'pl-4 w-6/12': showPlotDescription, 'w-full': !showPlotDescription }"
                            >
                                <div v-if="showCutBehaviour">
                                    <abc-radio
                                        class="pb-1 text-sm"
                                        v-model="curBehaviour"
                                        v-for="be in possibleBehaviour"
                                        :key="be"
                                        :radio-value="be"
                                        :label="i18n(be.toLowerCase())"
                                    />
                                </div>
                                <div v-if="isBufferSizeEnabled" class="w-4/12 mt-2 buffer_size_input">
                                    <abc-input
                                        :label="i18n('buffer-size')"
                                        :isNumeric="true"
                                        :decimals="2"
                                        @input="getBufferPreview"
                                        buttons
                                        right-tools
                                        remove-trailing-zero
                                        v-model="plotBufferSize"
                                    >
                                        <template #right>{{ i18n("m") }}</template>
                                        <template #buttons>
                                            <abc-button
                                                style="height: 37px"
                                                is-info
                                                is-icon
                                                v-b-tooltip.hover.window.ds400
                                                @click="getPlotBuffer"
                                            >
                                                <em class="fa-regular fa-calculator" />
                                            </abc-button>
                                        </template>
                                    </abc-input>
                                </div>
                            </div>
                        </div>

                        <!-- ACTIONS -->
                        <div
                            class="flex justify-center items-end overflow-hidden -ml-2 -mt-2"
                            :class="showPlotDescription || showCutBehaviour ? 'flex-col flex-wrap ' : 'w-full'"
                            :style="showPlotDescription || showCutBehaviour ? 'width: 152px' : ''"
                        >
                            <div class="mt-2 pl-2" :class="{ 'w-full': showPlotDescription || showCutBehaviour }">
                                <abc-button
                                    :class="{ 'w-full': showPlotDescription || showCutBehaviour }"
                                    :style="showPlotDescription || showCutBehaviour ? 'min-width: 0px;' : ''"
                                    is-success
                                    :is-disabled="disableSave || loadingPreview || saving"
                                    @click="saveDrawing(false, showModalOnAlertCodes)"
                                >
                                    <abc-loader v-if="loadingPreview || saving" scope="absolute" :size="20" />
                                    <p v-if="editPlotMode != getEditPlotMode.MULTISELECTION">{{ i18n("save") }}</p>
                                    <p v-else>{{ i18n("proceed") }}</p>
                                </abc-button>
                            </div>
                            <div class="flex pl-2" :class="editPlotMode != getEditPlotMode.MERGING ? 'w-full' : ''">
                                <!-- <transition
                                    name="custom-classes-transition"
                                    enter-active-class="animate__animated animate__fadeIn animate__faster"
                                    leave-active-class="animate__animated animate__fadeOut animate__faster"
                                    mode="out-in"
                                > -->
                                <template v-if="!drawing && editing && showCancel">
                                    <abc-button
                                        class="mt-2 w-6/12"
                                        style="height: 37px"
                                        :style="showPlotDescription || showCutBehaviour ? 'min-width: 0px;' : ''"
                                        is-secondary
                                        is-icon
                                        @click="forceResetEditModeAndCancelEditingOperation"
                                        v-b-tooltip.hover.window.ds400
                                        :title="i18n('cancel')"
                                    >
                                        <em class="abc-icon abc-icon-arrow-left-round" />
                                    </abc-button>

                                    <abc-button
                                        class="mt-2 w-6/12"
                                        style="height: 37px"
                                        :style="showPlotDescription || showCutBehaviour ? 'min-width: 0px;' : ''"
                                        is-danger
                                        is-icon
                                        :is-disabled="!vertexSelected"
                                        @click="deleteLastPoint"
                                        v-b-tooltip.hover.window.ds400
                                        :title="i18n('cancel-vertex')"
                                    >
                                        <em class="abc-icon abc-icon-trash-bin" />
                                    </abc-button>
                                    <abc-button
                                        class="mt-2 w-full"
                                        style="height: 37px"
                                        is-warning
                                        is-icon
                                        @click="toggleEraseParcelModal"
                                        v-b-tooltip.hover.window.ds400
                                        :title="i18n('cancel-selection')"
                                    >
                                        <em class="fa-light fa-eraser" />
                                    </abc-button>
                                </template>
                                <template v-else>
                                    <abc-button
                                        v-if="showCancel"
                                        class="mt-2"
                                        is-secondary
                                        @click="forceResetEditModeAndCancelEditingOperation"
                                        :style="showPlotDescription || showCutBehaviour ? 'min-width: 0px;' : ''"
                                        :class="{ 'w-full': showPlotDescription || showCutBehaviour }"
                                    >
                                        <em class="abc-icon abc-icon-arrow-left-round" />
                                        <p>{{ i18n("cancel") }}</p>
                                    </abc-button>
                                    <abc-button
                                        v-if="!drawing && editing"
                                        class="mt-2"
                                        :style="showPlotDescription || showCutBehaviour ? 'min-width: 0px;' : ''"
                                        is-danger
                                        :is-disabled="!vertexSelected"
                                        @click="deleteLastPoint"
                                    >
                                        <em class="abc-icon abc-icon-trash-bin" />
                                        <p>{{ i18n("cancel-vertex") }}</p>
                                    </abc-button>
                                </template>
                                <!-- </transition> -->
                            </div>
                            <!-- <div v-if="editPlotMode == getEditPlotMode.MERGING">
                                <abc-checkbox
                                    class="mt-2 ml-6 small"
                                    v-model="enableDefaultNotPreserveDeclsOnPlotsMerge"
                                    :label="i18n('do-not-preserve-decls-on-plots-merge')"
                                />
                            </div> -->
                            <div
                                v-if="cutting && (getCuttableLayersCodes.length || getCuttableLayersLoading)"
                                class="pl-2"
                            >
                                <abc-dropdown2
                                    :label="i18n('cut-on-layer')"
                                    class="info-select w-48"
                                    :items="[null, ...getCuttableLayersCodes]"
                                    v-model="layerForCuttingPlots"
                                >
                                    <p class="text-sm font-semibold tracking-wide" style="color: var(--primary-800)">
                                        {{
                                            layerForCuttingPlots
                                                ? layerNamesBySnapElemType[layerForCuttingPlots]
                                                : i18n("no-layer-selected")
                                        }}
                                    </p>
                                    <abc-loader v-if="getCuttableLayersLoading" scope="absolute" :size="20" />
                                    <template #items="{ item }">
                                        <div v-if="item" class="text-sm cursor-pointer">
                                            {{ layerNamesBySnapElemType[item] }}
                                        </div>
                                        <div v-else class="text-sm cursor-pointer">{{ i18n("no-layer-selected") }}</div>
                                    </template>
                                </abc-dropdown2>
                            </div>
                        </div>
                    </div>
                </div>
            </template>
            <template v-if="plots && !parcelData && !cadastralData" #additional-controls>
                <!-- PLOTS DECLARATION ACTIONS -->
                <tile-button
                    v-if="(isMapOnFullscreen || !timelineExpanded) && curPlot && !isReadOnly"
                    is-active
                    @click="
                        checkAndExecAddDecl(() => {
                            curTimelineSection = null;
                            curDeclaration = null;
                            openEditTile = true;
                            newDeclEditOpened = true;
                        })
                    "
                    boundary="viewport"
                    :tooltip="i18n('add-declaration')"
                    :is-disabled="curDisabledFunctions.includes('ADD_DECLARATIONS')"
                >
                    <em class="abc-icon abc-icon-plus"></em>
                </tile-button>
                <!-- class="text-success-600 dark:text-success-dark-600 border-success-500 dark:border-success-dark-500 hover:bg-success-100" -->
                <tile-button
                    v-if="(isMapOnFullscreen || !timelineExpanded) && showCompleteWithTara && curPlot && !isReadOnly"
                    class="override-tile-button-class"
                    @click="openPlotCompleteTaraModal = true"
                    boundary="viewport"
                    :tooltip="i18n('complete-with-tara')"
                >
                    <em class="fal fa-puzzle"></em>
                </tile-button>
                <tile-button
                    v-if="showAdditionalControls && showBufferBehaviour && !isReadOnly && isCanAddPlots"
                    @click="
                        checkAndExecEditGeom(() =>
                            checkDate(evalBufferMode, getEditPlotMode.ADDING_BUFFER, maxCampaignAndPlotsDate)
                        )
                    "
                    is-content
                    boundary="viewport"
                    :tooltip="i18n('add-linear-element')"
                >
                    <em class="fal fa-grip-lines-vertical"></em>
                </tile-button>

                <!-- <tile-button
                    v-if="showAdditionalControls && toolbuttonsEnabled && !isReadOnly"
                    @click="checkAndExecEditGeom(startMultiselection)"
                    is-content
                    boundary="viewport"
                    :tooltip="i18n('graphic-multiselection')"
                    :is-disabled="curDisabledFunctions.includes('MULTISELECTION_PLOTS')"
                >
                    <em class="fal fa-square-dashed"></em>
                </tile-button> -->

                <tile-button
                    v-if="showAdditionalControls && toolbuttonsEnabled && !isReadOnly"
                    @click="
                        checkAndExecEditGeom(() =>
                            checkDate(startCutting, getEditPlotMode.CUTTING, maxCampaignAndPlotsDate)
                        )
                    "
                    is-content
                    boundary="viewport"
                    :tooltip="i18n('cut-plots')"
                    :is-disabled="curDisabledFunctions.includes('CUT_PLOTS')"
                >
                    <em class="fal fa-cut"></em>
                </tile-button>
                <tile-button
                    v-if="curPlots.length && curPlot && showAdditionalControls && !isReadOnly"
                    @click="checkAndExecEditGeom(startMerging)"
                    is-content
                    boundary="viewport"
                    :tooltip="i18n('merge-plots')"
                    :is-disabled="curDisabledFunctions.includes('MERGE_DECLARATIONS')"
                >
                    <em class="fal fa-object-group"></em>
                </tile-button>
            </template>
            <template #additional-management-controls>
                <tile-button
                    v-if="isCadastralParcelSearchEnabled"
                    @click="showCadastralParcelSearchModal = true"
                    is-content
                    :tooltip="i18n('search-cadastral-parcel')"
                >
                    <em class="fal fa-magnifying-glass-location"></em>
                </tile-button>
                <tile-button
                    v-if="editPlotMode === getEditPlotMode.NOT_SELECTED && !gisInfoActive"
                    @click="measureMap = !measureMap"
                    is-content
                    :tooltip="i18n('measure')"
                    boundary="viewport"
                >
                    <em class="fal fa-ruler-horizontal"></em>
                </tile-button>
                <tile-button
                    v-if="gisInfoEnabled && editPlotMode === getEditPlotMode.NOT_SELECTED && !measureMap"
                    @click="gisInfoActive = !gisInfoActive"
                    is-content
                    :tooltip="i18n('gis-info')"
                    boundary="viewport"
                >
                    <em class="fal fa-circle-info"></em>
                </tile-button>
                <tile-button
                    v-if="curCouncil.bigDomainZone"
                    @click="fetchSubdomainZone()"
                    is-content
                    :tooltip="i18n('define-subdomain-zone')"
                    boundary="viewport"
                >
                    <em class="fa fa-square-o" aria-hidden="true"></em>
                </tile-button>

                <!-- Additional controls on full screen isMapOnFullscreen-->
                <div v-if="isMapOnFullscreen && !parcelData && !cadastralData" class="flex flex-col">
                    <div class="border"></div>
                    <tile-button
                        v-if="curPlot && !curParcelData && !curCadastralData"
                        is-content
                        :tooltip="i18n('deselect')"
                        :toggled="false"
                        @click="deselect"
                        boundary="viewport"
                    >
                        <em class="abc-icon abc-icon-x text-sm text-white"></em>
                    </tile-button>
                    <tile-button
                        v-if="curPlot && deleteAuth && editPlotMode === getEditPlotMode.NOT_SELECTED && !isReadOnly"
                        is-content
                        :tooltip="i18n('remove')"
                        @click="
                            checkAndExecEditDeleteGeom(() =>
                                checkDate(
                                    () => (showConfirmDeletePlot = true),
                                    getEditPlotMode.DELETING,
                                    maxCampaignAndPlotsDate
                                )
                            )
                        "
                        :is-disabled="curDisabledFunctions.includes('DELETE_PLOTS')"
                        boundary="viewport"
                    >
                        <em class="abc-icon abc-icon-trash-bin text-white"></em>
                    </tile-button>
                    <tile-button
                        v-if="curPlot && editPlotMode === getEditPlotMode.NOT_SELECTED && !isReadOnly"
                        is-content
                        :tooltip="i18n('edit')"
                        @click="
                            checkAndExecEditDeleteGeom(() =>
                                checkDate(() => forceStartEditing++, getEditPlotMode.EDITING, maxCampaignAndPlotsDate)
                            )
                        "
                        :is-disabled="curDisabledFunctions.includes('EDIT_PLOTS')"
                        boundary="viewport"
                    >
                        <em class="abc-icon abc-icon-pen text-white"></em>
                    </tile-button>
                    <tile-button
                        v-if="editPlotMode === getEditPlotMode.NOT_SELECTED && isCanAddPlots"
                        is-content
                        :tooltip="i18n('graphic-multiselection')"
                        :is-disabled="showSnapLoader"
                        @click="editPlotMode = getEditPlotMode.MULTISELECTION"
                        boundary="viewport"
                    >
                        <em class="fal fa-square-dashed"></em>
                    </tile-button>
                    <tile-button
                        v-if="curPlot && !editPlotMode && !isReadOnly"
                        is-content
                        :tooltip="i18n('edit')"
                        @click="
                            checkAndExecEditDeleteGeom(() =>
                                checkDate(() => continueWithEditing(), getEditPlotMode.EDITING, maxCampaignAndPlotsDate)
                            )
                        "
                        boundary="viewport"
                    >
                        <em class="abc-icon abc-icon-pen text-white"></em>
                    </tile-button>
                    <tile-button
                        v-if="
                            curConfiguration.ENABLE_RESTORE_PLOT_DEFAULT === 'TRUE' &&
                            curPlot &&
                            editPlotMode === getEditPlotMode.NOT_SELECTED &&
                            !isReadOnly
                        "
                        is-content
                        :tooltip="i18n('restore')"
                        @click="
                            checkAndExecEditDeleteGeom(() => {
                                showConfirmRestorePlot = true;
                            })
                        "
                        boundary="viewport"
                    >
                        <em class="abc-icon abc-icon-arrow-circle text-white"></em>
                    </tile-button>
                    <tile-button
                        v-if="editPlotMode === getEditPlotMode.NOT_SELECTED && isCanAddPlots"
                        is-content
                        :tooltip="i18n('add')"
                        @click="
                            checkAndExecEditDeleteGeom(() =>
                                checkDate(() => continueWithEditing(), getEditPlotMode.ADDING, maxCampaignAndPlotsDate)
                            )
                        "
                        boundary="viewport"
                    >
                        <em class="abc-icon abc-icon-plus text-white"></em>
                    </tile-button>
                </div>
            </template>
        </iacs-map-component>
        <app-loading-modal v-if="saving" />
        <crop-plan-can-not-edit-modal-warning v-model="showWarningCannotEdit" :editabilityCheck="'!EDITABLE'" />
        <crop-plan-post-edit-messages-modal
            :messages="validationMessages"
            @proceedAnyWay="saveDrawing(true, showModalOnAlertCodes)"
        />
        <abc-modal
            v-if="showEditWarningModal && maxCampaignAndPlotsDate"
            @close="
                () => {
                    (showEditWarningModal = false), (lastEditPlotMode = null);
                }
            "
            is-message
        >
            <template #body>
                {{
                    i18n(
                        showPlotStartDateMessage
                            ? "point-in-time-not-aligned-with-calculated-date"
                            : "point-in-time-not-aligned-with-campaign-date",
                        {
                            pointInTime: formattedDate(curPointInTime),
                            startDate: formattedDate(maxCampaignAndPlotsDate),
                        }
                    ).toString()
                }}
                <div v-if="needsReferenceSync">
                    <abc-checkbox
                        v-model="flSyncToRecalcAnomalies"
                        class="py-3"
                        :label="
                            i18n('recalc-anomalies-on-date-change', {
                                date: formattedDate(maxCampaignAndPlotsDate),
                            }).toString()
                        "
                    />
                    <span class="text-warning-600 font-semibold italic">
                        {{ i18n("anomalies-recalculation-warning") }}
                    </span>
                </div>
            </template>
            <template #footer>
                <abc-button class="mr-2" is-secondary is-outlined @click="confirmEditDateChange">
                    {{ i18n("change-date") }}
                </abc-button>
                <abc-button is-danger @click="continueWithEditing">
                    {{ i18n("continue-anyway") }}
                </abc-button>
            </template>
        </abc-modal>
        <abc-modal v-if="showEraseParcelModal" is-message @close="toggleEraseParcelModal">
            <template #body>
                <p>{{ i18n("modal-confirm-delete-all-vertices") }}</p>
            </template>
            <template #footer>
                <abc-button class="mr-2" is-secondary is-outlined @click="toggleEraseParcelModal">
                    {{ i18n("cancel") }}
                </abc-button>
                <abc-button is-warning @click="eraseParcel">
                    {{ i18n("continue-anyway") }}
                </abc-button>
            </template>
        </abc-modal>
    </div>
</template>

<script lang="ts">
import IacsMapModule from "@abaco/iacs-map-module/src/modules/map-module";
import AbcVectorLayer, {
    FEATURE_ID,
    VectorLayerDef,
} from "@abaco/iacs-map-module/src/modules/map-module/Layer/AbcVectorLayer";
import GenericLayer, {
    LayerDef,
    LayerParamDef,
    LayerParamType,
} from "@abaco/iacs-map-module/src/modules/map-module/Layer/GenericLayer";
import {
    MapFunctions,
    MapView,
    SelectFeatureObject,
} from "@abaco/iacs-map-module/src/modules/map-module/models/AbcMap";
import { FromStore } from "@abaco/web-common/src/app";
import { cloneDeep } from "lodash";
import { containsExtent, intersects, createEmpty, extend, isEmpty } from "ol/extent";
import Feature, { FeatureLike } from "ol/Feature";
import Overlay from "ol/Overlay";
import Geometry from "ol/geom/Geometry";
import MapBrowserEvent from "ol/MapBrowserEvent";
import { Fill, Stroke, Style } from "ol/style";
import { Source, Vector as VectorSource } from "ol/source";
import { Layer, Vector as VectorLayer } from "ol/layer";
import { Component, Inject, Mixins, Prop, Watch, Ref } from "vue-property-decorator";
import SingleCropPlan, { MODULE_ID } from "../..";
import { SnapGeometry, SnapGeometryDef } from "../../models/Layer";
import { EditPlotMode, Plot, PlotDeclaration } from "../../models/Plot";
import MapEditMixin from "./MapEditMixin";
import SingleCpMapHelpLegend from "./SingleCpMapHelpLegend.vue";
import SingleCpMapHelpMeasure from "./SingleCpMapHelpMeasure.vue";
import { VBTooltip } from "bootstrap-vue";
import { convertToDate, formatDate, formatDateTime, isMacOs, isNullish } from "../../api/Utils";
import AbcWMSLayer, { WMSLayerDef } from "@abaco/iacs-map-module/src/modules/map-module/Layer/AbcWMSLayer";
import AppLoadingModal from "../private/appLoadingModal.vue";
import CropPlanCanNotEditModalWarning from "../private/cropPlanCanNotEditModalWarning.vue";
import CanEditCheckAndExecute from "../../mixins/CanEditCheckAndExecute";
import CropPlanPostEditMessagesModal from "../private/cropPlanPostEditMessagesModal.vue";
import { ObjectEvent } from "ol/Object";
import { fromExtent } from "ol/geom/Polygon";
import OperationResult from "./OperationResult.vue";
import GisInfo from "./GisInfo.vue";
import DateUtils from "../../mixins/DateUtils";
import AreaUtils from "../../mixins/AreaUtils";
import { FunctionCode } from "../../models/CropPlan";
import AbcWKT from "@abaco/iacs-map-module/src/modules/map-module/Layer/AbcWKT";
import CadastralParcelSearchModal from "../private/cadastralParcelSearchModal.vue";
import { CadastralParcel } from "../../models/CadastralParcel";
import { CadastralData, CadastralOverlap, ParcelData } from "../../models/Declaration";
import { ToastOptions } from "@abaco/web-common/src/app/Toasted";
import { TranslateResult } from "vue-i18n";
import { Debounce } from "vue-debounce-decorator";
import { Snap } from "ol/interaction";
import { makeStrokePattern } from "./EditStyle";
import { isSCP } from "../../../../../src/main";
import PointInTimeChange from "../../mixins/PointInTimeChange";

@Component({
    directives: {
        "b-tooltip": VBTooltip,
    },
    components: {
        SingleCpMapHelpLegend,
        SingleCpMapHelpMeasure,
        CropPlanCanNotEditModalWarning,
        CropPlanPostEditMessagesModal,
        OperationResult,
        CadastralParcelSearchModal,
        GisInfo,
        AppLoadingModal,
    },
})
export default class SingleCpMapComponent extends Mixins(MapEditMixin, CanEditCheckAndExecute, DateUtils, AreaUtils, PointInTimeChange) {
    @Inject(IacsMapModule.MODULE_ID) iacsMapModule!: IacsMapModule;
    @Inject(MODULE_ID) singleCropPlanModule!: SingleCropPlan;
    @Inject() toast!: (message: string, options?: ToastOptions) => TranslateResult;
    @FromStore(MODULE_ID) showNavBar!: boolean;

    @Prop() timelineHeight!: number;
    @FromStore(MODULE_ID) timelineExpanded!: boolean;
    @FromStore(IacsMapModule.MODULE_ID) globalMapView!: MapView;
    @FromStore(SingleCropPlan.MODULE_ID) defaultLayers!: LayerDef[];
    @FromStore(SingleCropPlan.MODULE_ID) hideFieldName!: boolean;
    @FromStore(SingleCropPlan.MODULE_ID) toolbuttonsEnabled!: boolean;
    @FromStore(SingleCropPlan.MODULE_ID) multiplePlotSelection!: boolean;
    @FromStore(MODULE_ID) selectorStep!: string;
    @FromStore(MODULE_ID) curParcelData!: ParcelData | null;
    @FromStore(MODULE_ID) curCadastralData!: CadastralData | null;
    @FromStore(MODULE_ID) curCadastralOverlapData!: CadastralOverlap | null;
    @FromStore(MODULE_ID) parcelData!: ParcelData[] | null;
    @FromStore(MODULE_ID) cadastralData!: CadastralData[] | null;
    @FromStore(MODULE_ID) showConfirmDeletePlot!: boolean;
    @FromStore(MODULE_ID) showConfirmRestorePlot!: boolean;
    @FromStore(MODULE_ID) blockMapPlotSelection!: boolean;
    @FromStore(MODULE_ID) openPlotCompleteTaraModal!: boolean;
    @FromStore(MODULE_ID) plotsForceReload!: number;
    @FromStore(MODULE_ID) forceApplyFilters!: number;
    @FromStore(MODULE_ID) curDisabledFunctions!: FunctionCode[];
    @FromStore(MODULE_ID) forceSync!: number;
    @FromStore(MODULE_ID) filteredPlots!: Plot[];
    @FromStore(MODULE_ID) flSyncToRecalcAnomalies!: boolean;

    @Ref("plot_popover") plotPopoverElement!: HTMLElement;
    @Ref("parcel_popover") parcelPopoverElement!: HTMLElement;
    @Ref("cadastral_popover") cadastralPopoverElement!: HTMLElement;

    private additionalLayersDefaultState: Map<string, boolean> | null = null;
    private additionalLayersDef: LayerDef[] = [];

    private hoveredFeature: FeatureLike | null = null;
    private hoveredParcel: ParcelData | null = null;
    private hoveredCadastral: CadastralData | null = null;
    private pickedFeature: Feature<Geometry> | null = null;
    private multiplePickedFeatures: Feature<Geometry>[] = [];
    private highlightLayer: AbcVectorLayer | null = null;

    private plotsLayerDef: VectorLayerDef | null = null;
    private clickOnMap = false;

    private showEraseParcelModal = false;
    private mapLoaded = false;
    private updateCounter = 0;
    private isMapOnFullscreen = false;
    private measureMap = false;
    private selectedLayer: GenericLayer | null = null;
    private hiddenClickableFeatLayer: VectorLayer<VectorSource<Geometry>> | null = null;
    // Duplicate consts
    private deleteAuth = !this.envConfig.hideDeletePlot || false;

    private gisInfoActive = false;
    private gisInfoPanelHeight = 0;
    private loadingSnapGeomsCounter = 0;
    private previouslyLoadedSnappableElementTypes: string[] = [];

    private get getEditPlotMode() {
        return EditPlotMode;
    }

    private get gisInfoEnabled() {
        return this.curConfiguration?.ENABLE_INFO_GIS == "TRUE" && this.editPlotMode === EditPlotMode.NOT_SELECTED;
    }
    private get gisInfoShow() {
        return this.gisInfoEnabled && this.gisInfoActive;
    }
    private get isCanAddPlots() {
        return this.curCropPlan && !this.curCropPlan.readOnly && this.curCropPlan.canAddPlots;
    }

    private get needsReferenceSync() {
        if (!this.maxCampaignAndPlotsDate) return false;
        return (
            this.curConfiguration?.CONSTRAINTS_VERSION_TO_SYNC_REF_DATE === "TRUE" &&
            !(formatDate(this.maxCampaignAndPlotsDate) === this.cropPlanDates.lastSyncReferenceDate)
        );
    }

    private get hasAtLeastOneLandCoverDescription() {
        return this.hoveredPlot?.parcelIntersections.some((it) => it.landCoverDescription) || false;
    }

    private plotPopoverOverlay: Overlay | null = null;
    private parcelPopoverOverlay: Overlay | null = null;
    private cadastralPopoverOverlay: Overlay | null = null;
    private hoveredPlot: Plot | null = null;
    private hoveredLayerGeom: SnapGeometry | null = null;
    private plotPopoverUpdateTimerId: number | null = null;
    private flSKeyPressed = false;
    private loadingSubdomainZone = false;

    mounted() {
        this.drawLayer.setZIndex(999);
        this.editLayer.setZIndex(999);
        window.addEventListener("keydown", this.handleKeyPress);
        window.addEventListener("keyup", this.handleKeyPress);
    }

    beforeDestroy() {
        this.localMap.un("click", this.checkMapClickOnHiddenParcel);
        window.addEventListener("keydown", this.handleKeyPress);
        window.addEventListener("keyup", this.handleKeyPress);
    }

    private handleKeyPress(evt: KeyboardEvent) {
        this.flSKeyPressed = evt && evt.code === "KeyS" && evt.type !== "keyup";
    }

    @Watch("flSKeyPressed")
    onCtrlPressedChange(newValue: boolean, oldValue: boolean) {
        this.localMap.getInteractions().forEach((interaction) => {
            if (interaction instanceof Snap) {
                interaction.setActive(!newValue);
            }
        });
    }

    private get showPlotPopover() {
        return this.plotPopoverOverlay && this.hoveredPlot;
    }

    private get showParcelPopover(): boolean {
        return this.parcelPopoverOverlay !== null && this.hoveredParcel !== null;
    }

    private get showCadastralPopover(): boolean {
        return this.cadastralPopoverOverlay !== null && this.hoveredCadastral !== null;
    }

    private get showPlotStartDateMessage() {
        if (!this.maxCampaignAndPlotsDate || !this.curPlot) return false;
        const campaignStartDate = this.cropPlanDates.campaignStartDate
            ? convertToDate(this.cropPlanDates.campaignStartDate)
            : null;
        return campaignStartDate && this.maxCampaignAndPlotsDate > campaignStartDate;
    }

    private resumeEditPlotMode() {
        if (this.lastEditPlotMode === null) {
            console.error("Dev - error: lost lastEditPlotMode");
            return;
        }
        switch (this.lastEditPlotMode) {
            case EditPlotMode.ADDING:
                this.startDrawing();
                break;
            case EditPlotMode.ADDING_BUFFER:
                this.editPlotMode = this.lastEditPlotMode;
                this.evalBufferMode();
                break;
            case EditPlotMode.MULTISELECTION:
                this.startMultiselection();
                break;
            case EditPlotMode.CUTTING:
                this.startCutting();
                break;
            case EditPlotMode.DELETING:
                this.showConfirmDeletePlot = true;
                break;
            case EditPlotMode.EDITING:
                this.startEditing();
                break;
            default:
                break;
        }
        this.lastEditPlotMode = null;
        this.showEditWarningModal = false;
    }

    private continueWithEditing() {
        if (this.lastEditPlotMode === null) return;
        switch (this.lastEditPlotMode) {
            case EditPlotMode.ADDING:
                this.startDrawing();
                break;
            case EditPlotMode.ADDING_BUFFER:
                this.evalBufferMode();
                break;
            case EditPlotMode.MULTISELECTION:
                this.startMultiselection();
                break;
            case EditPlotMode.CUTTING:
                this.startCutting();
                break;
            case EditPlotMode.DELETING:
                this.showConfirmDeletePlot = true;
                break;
            case EditPlotMode.EDITING:
                this.startEditing();
                break;
        }
        this.lastEditPlotMode = null;
        this.showEditWarningModal = false;
    }

    private forceResetEditModeAndCancelEditingOperation() {
        this.forcePlotModeReset = true;
        this.lastEditPlotMode = null;
        this.$nextTick(() => this.cancel());
    }

    private confirmEditDateChange() {
        if (!this.cropPlanDates.campaignStartDate || !this.maxCampaignAndPlotsDate) return;
        this.showEditWarningModal = false;
        this.curPointInTime = this.maxCampaignAndPlotsDate;
        this.saveCurSelectedPlots();

        if (this.needsReferenceSync) {
            if (this.flSyncToRecalcAnomalies) this.forceSync++;
            else {
                this.plotsForceReload++;
            }
        } else {
            this.forceSync++;
        }
        this.flSyncToRecalcAnomalies = false;
    }

    private alertCodes: string[] | null = null;

    private showCadastralParcelSearchModal = false;

    private async onMapLoaded(map: MapFunctions) {
        this.map = map;
        this.localMap = this.map.localMap;

        await this.loadAdditionalLayers().then((additionalLayers) => {
            this.addAdditionalLayers(additionalLayers).then((additionalLayers) => {
                this.additionalLayers = additionalLayers;
                this.additionalLayersDefaultState = new Map<string, boolean>(
                    this.additionalLayers.map((layer) => [layer.layerDef.code!, layer.layerDef.on])
                );
            });
        });
        // await this.loadSnapGeometries().then((snapGeometriesDef) => {
        //     const snapGeometriesDefOff = snapGeometriesDef.map((it) => ({ ...it, on: false }));
        //     this.addSnapLayers(snapGeometriesDefOff).then((snapLayers) => {
        //         this.snapLayers = snapLayers;
        //     });
        // });
        //
        await this.buildPlots();
        this.initPlotPopover();
        if (this.lastEditPlotMode !== null) setTimeout(() => this.resumeEditPlotMode(), 1000); // Better to wait due to initial state mutations
    }

    private get showCutBehaviour() {
        return this.editPlotMode === EditPlotMode.ADDING || this.editPlotMode === EditPlotMode.EDITING;
    }

    private get showCancel() {
        return this.editPlotMode !== EditPlotMode.NOT_SELECTED;
    }

    private get showPlotDescription() {
        return this.editPlotMode === EditPlotMode.ADDING && this.curPlotOut && !this.hideFieldName;
    }

    private get showAdditionalControls() {
        return this.editPlotMode === EditPlotMode.NOT_SELECTED && !this.measureMap;
    }

    private get showBufferBehaviour() {
        return this.bufferSizeOptions.length > 0;
    }

    private get showBufferPositionSelect() {
        return (
            ((this.curPlot || this.curPlots.length) && this.bufferBehaviour == "FREE_DRAW") ||
            (!this.curPlot && this.curPlots.length == 0)
        );
    }

    private get bufferSizeOptions() {
        return typeof this.curConfiguration?.LINEAR_ELEMENTS == "string"
            ? this.curConfiguration?.LINEAR_ELEMENTS.split(" ")
                  .map((v) => parseFloat(v))
                  .filter((v) => !!v)
            : [];
    }

    private get formattedDrawingDistance() {
        return this.drawingDistance > 1000
            ? Math.round((this.drawingDistance / 1000) * 100) / 100 + " km"
            : Math.round(this.drawingDistance * 100) / 100 + " m";
    }

    private get curCouncilMbr() {
        return [this.curCouncil.mbr.xmin, this.curCouncil.mbr.ymin, this.curCouncil.mbr.xmax, this.curCouncil.mbr.ymax];
    }

    private get curMbr() {
        let res = createEmpty();
        if (this.curPlot) {
            const extent = this.WKTParser.readGeometry(this.curPlot.geom).getExtent();
            extend(res, extent);
        }
        this.curPlots.forEach((plot) => {
            const extent = this.WKTParser.readGeometry(plot.geom).getExtent();
            extend(res, extent);
        });
        res = isEmpty(res) ? this.curCouncilMbr : res;
        return res;
    }

    private get paddingBottom() {
        return this.gisInfoPanelHeight > this.timelineHeight ? this.gisInfoPanelHeight : this.timelineHeight;
    }

    private get padding() {
        return [0, 0, this.paddingBottom, 0];
    }

    private get mapOnFullscreenStatus() {
        return this.isMapOnFullscreen;
    }

    private get isReadOnly() {
        return this.curCropPlan && this.curCropPlan.readOnly;
    }

    private get filteredHoveredPlotDeclarations() {
        let result: PlotDeclaration[] = [];
        if (this.hoveredPlot && this.hoveredPlot.decls.length) {
            result = this.hoveredPlot.decls.filter(
                (value, index, self) =>
                    index === self.findIndex((t) => t.landuse.code === value.landuse.code) && value.areaPerc > 0
            );
        }
        return result;
    }

    private get layerNamesBySnapElemType() {
        const out: { [k: string]: string } = {},
            layersDefWithSnapType = this.additionalLayersDef.filter((l) => l.snapElementType);
        this.getCuttableLayersCodes.forEach((code) => {
            const match = layersDefWithSnapType.find((l) => l.code == code);
            out[code] = match ? match.description.replace("->", " - ") : code;
        });
        return out;
    }

    private get getCuttableLayersCodes() {
        return this.cuttableLayers.map((cl) => cl.layerCode);
    }

    private get cutting() {
        return this.editPlotMode == EditPlotMode.CUTTING;
    }

    private get multiselection() {
        return this.editPlotMode === EditPlotMode.MULTISELECTION;
    }

    private get curSnappableElementTypes() {
        return this.additionalLayers
            .filter((l) => l.layerDef.on && l.layerDef.snapElementType)
            .map((l) => l.layerDef.snapElementType as string);
    }

    @Watch("editPlotMode")
    onEditPlotModeChange() {
        this.plotsLayer?.buildedLayer.changed();
        this.highlightLayer?.buildedLayer.changed();
        if (this.editPlotMode !== EditPlotMode.NOT_SELECTED) {
            this.measureMap = false;
        } else {
            this.highlightLayer?.buildedLayer.setVisible(true);
            this.bufferBehaviour = "INTERNAL";
        }
    }

    @Watch("additionalLayers")
    onAdditionalLayersChange() {
        const res = this.additionalLayers.filter((l) => l.layerDef.enabledInOverview);
        this.defaultLayers = res.map((r) => cloneDeep(r.layerDef));
    }

    @Watch("curSnappableElementTypes")
    async onCurSnappableElementTypes() {
        await this.handleSnapLayersLoader();
    }

    private async handleSnapLayersLoader() {
        const currentTypes = this.curSnappableElementTypes;

        // Determine type to add and to remove
        const toAdd = currentTypes.filter((type) => !this.previouslyLoadedSnappableElementTypes.includes(type));
        const toRemove = this.previouslyLoadedSnappableElementTypes.filter((type) => !currentTypes.includes(type));

        // Remove unused geometries from map
        this.snapLayers
            .filter((sl) => sl.layerDef.snapElementType && toRemove.includes(sl.layerDef.snapElementType))
            .forEach((l) => {
                this.previouslyLoadedSnappableElementTypes = this.previouslyLoadedSnappableElementTypes.filter((snapElementType) => snapElementType != l.layerDef.snapElementType);
                l.buildedLayer.un("change:visible", this.cancel);
                this.map.removeMapLayer(l.layerId);
            });

        // Load new geometries
        if (toAdd.length > 0) {
            await this.loadSnapGeometries(toAdd).then((snapGeometriesDef) => {
                const snapGeometriesDefOff = snapGeometriesDef.map((it) => ({ ...it, on: true }));

                // Add new geometries
                this.addSnapLayers(snapGeometriesDefOff).then((snapLayers) => {
                    this.snapLayers = snapLayers;
                });

                // Save the loaded types
                toAdd.forEach((loadedSnappableElementType) => {
                   this.previouslyLoadedSnappableElementTypes.push(loadedSnappableElementType);
                });
            });
        }
    }

    @Watch("curCouncil")
    @Watch("business")
    private async updateLayers() {
        const additionalLyayers = await this.loadAdditionalLayers();

        this.additionalLayers = await this.addAdditionalLayers(additionalLyayers);
        this.additionalLayersDefaultState = new Map<string, boolean>(
            this.additionalLayers.map((layer) => [layer.layerId, layer.layerDef.on])
        );
    }

    @Watch("cropPlanDates.referenceDate", { deep: true })
    private async updateSnaps() {
        const activeLayerIds = this.additionalLayers.filter((l) => l.layerDef.on).map((l) => l.layerDef.layerId);
        //
        this.additionalLayers = await this.addAdditionalLayers(
            this.additionalLayersDef.map((ldef) => ({ ...ldef, on: activeLayerIds.includes(ldef.layerId) }))
        );
        this.additionalLayersDefaultState = new Map<string, boolean>(
            this.additionalLayers.map((layer) => [layer.layerId, layer.layerDef.on])
        );
    }

    @Watch("curCouncilMbr")
    centerMapOnCouncil() {
        if (this.map) {
            this.map.centerViewOnMbr(this.curCouncilMbr);
        }
    }

    @Watch("curPlot")
    onCurPlotSelected() {
        if (!this.curPlot || !this.map) {
            this.pickedFeature = null;
            this.highlightLayer?.buildedLayer.changed();
            return;
        }
        const sourcePlot = this.plotsLayer?.buildedLayer.getSource();
        if (sourcePlot)
            this.pickedFeature =
                sourcePlot.getFeatures().find((f) => f.get(FEATURE_ID) == this.curPlot?.plotCode) || null;

        this.centerMapOnPick();

        if (this.clickOnMap) {
            this.clickOnMap = false;
        }
        this.highlightLayer?.buildedLayer.changed();
    }

    @Watch("localMap")
    @Watch("parcelData")
    @Watch("cadastralData")
    async changeLayerStatus() {
        if (!this.localMap || !this.plotsLayer || !this.plots) return;
        //
        this.cancel();
        //
        if (!this.cadastralData && !this.parcelData) {
            if (this.additionalLayersDefaultState) {
                for (const entry of this.additionalLayersDefaultState) {
                    this.additionalLayers.find((it) => it.layerDef.code === entry[0])?.setVisibility(entry[1]);
                }
            } else {
                this.additionalLayers.find((it) => it.layerDef.code === "PARCELS")?.setVisibility(false);
                this.additionalLayers.find((it) => it.layerDef.code === "CADPARCELS")?.setVisibility(false);
            }
            this.plotsLayer.setVisibility(true);
        } else {
            this.plotsLayer.setVisibility(false);
        }
        //
        if (this.hiddenClickableFeatLayer) {
            this.localMap.un("click", this.checkMapClickOnHiddenParcel);
            this.localMap.removeLayer(this.hiddenClickableFeatLayer);
            this.hiddenClickableFeatLayer = null;
        }
        //
        if (this.cadastralData) {
            this.additionalLayers.find((it) => it.layerDef.code === "CADPARCELS")?.setVisibility(true);
            // add transparent features for selecting parcel on map
            const parcelWithGeom = this.cadastralData.filter((p) => !!p.geom);
            if (parcelWithGeom.length) {
                this.hiddenClickableFeatLayer = new VectorLayer({
                    source: new VectorSource({
                        features: parcelWithGeom.map(
                            (p) =>
                                new Feature({
                                    geometry: this.WKTParser.readGeometry(p.geom!),
                                    cadParcelCode: p.sectorBlock + "-" + p.parcel,
                                })
                        ),
                    }),
                    style: new Style({
                        fill: new Fill({ color: "rgba(0, 0, 0, 0)" }),
                        stroke: new Stroke({ color: "rgba(0, 0, 0, 0)" }),
                    }),
                });
                this.localMap.addLayer(this.hiddenClickableFeatLayer!);
            }
        } else {
            this.additionalLayers.find((it) => it.layerDef.code === "CADPARCELS")?.setVisibility(false);
        }
        //
        if (this.parcelData) {
            this.additionalLayers.find((it) => it.layerDef.code === "PARCELS")?.setVisibility(true);
            // add transparent features for selecting parcel on map
            const parcelWithGeom = this.parcelData.filter((p) => !!p.geom);
            if (parcelWithGeom.length) {
                this.hiddenClickableFeatLayer = new VectorLayer({
                    source: new VectorSource({
                        features: parcelWithGeom.map(
                            (p) =>
                                new Feature({
                                    geometry: this.WKTParser.readGeometry(p.geom),
                                    parcelCode: p.parcelCode,
                                })
                        ),
                    }),
                    style: new Style({
                        fill: new Fill({ color: "rgba(0, 0, 0, 0)" }),
                        stroke: new Stroke({ color: "rgba(0, 0, 0, 0)" }),
                    }),
                });
                this.localMap.addLayer(this.hiddenClickableFeatLayer!);
            }
        } else {
            this.additionalLayers.find((it) => it.layerDef.code === "PARCELS")?.setVisibility(false);
        }
        //
        if (this.hiddenClickableFeatLayer) {
            this.localMap.on("click", this.checkMapClickOnHiddenParcel);
        }
    }

    private checkMapClickOnHiddenParcel(e: MapBrowserEvent<any>) {
        if (e.type == "click" && this.hiddenClickableFeatLayer && e.pixel && e.coordinate) {
            const hits: FeatureLike[] = [];
            this.localMap.forEachFeatureAtPixel(e.pixel, (feature) => hits.push(feature), {
                layerFilter: (layer: Layer<Source>) => layer === this.hiddenClickableFeatLayer,
            });
            if (!hits.length) return;
            if (this.parcelData) {
                const pick = this.parcelData.find((p) => p.parcelCode == hits[0].get("parcelCode"));
                if (pick) this.curParcelData = pick.parcelCode == this.curParcelData?.parcelCode ? null : pick;
            } else if (this.cadastralData) {
                const pick = this.cadastralData.find(
                    (p) => p.sectorBlock + "-" + p.parcel == hits[0].get("cadParcelCode")
                );
                if (pick)
                    this.curCadastralData =
                        this.curCadastralData &&
                        pick.sectorBlock + "-" + pick.parcel ==
                            this.curCadastralData.sectorBlock + "-" + this.curCadastralData.parcel
                            ? null
                            : pick;
            }
        }
    }

    @Watch("curParcelData")
    async onChangeCurParcelData() {
        if (this.selectedLayer) {
            this.map?.removeMapLayer(this.selectedLayer.layerId);
            this.selectedLayer = null;
        }
        if (!this.map || !this.curParcelData) {
            return;
        }
        const selectedParcel: VectorLayerDef = {
            layerType: "VECTOR",
            layerId: "SELECTED_PARCEL",
            features: [
                {
                    wkt: this.curParcelData.geom,
                    id: this.curParcelData.parcelCode,
                    style: {
                        borderColor: "blue",
                        fillColor: "rgb(0, 0, 255, 0.2)",
                        width: 4,
                    },
                },
            ],
            isOverlay: true,
            description: "selected parcel",
            on: true,
            zIndex: 1005,
        };
        this.selectedLayer = await this.map.addMapLayer(selectedParcel);
        this.zoomOnMbrWithTransition(this.curParcelData.mbrOverview);
    }

    @Watch("curCadastralData")
    async onChangeCurCadastralData() {
        if (this.selectedLayer) {
            this.map?.removeMapLayer(this.selectedLayer.layerId);
            this.selectedLayer = null;
        }
        if (!this.map || !this.curCadastralData || !this.curCadastralData.geom || !this.curCadastralData.mbrOverview) {
            return;
        }
        const selectedCadParcel: VectorLayerDef = {
            layerType: "VECTOR",
            layerId: "SELECTED_CADPARCEL",
            features: [
                {
                    wkt: this.curCadastralData.geom,
                    id: this.curCadastralData.parcel,
                    style: {
                        borderColor: "blue",
                        fillColor: "rgb(0, 0, 255, 0.2)",
                        width: 4,
                    },
                },
            ],
            isOverlay: true,
            description: "selected cadastral parcel",
            on: true,
            zIndex: 1005,
        };
        this.selectedLayer = await this.map.addMapLayer(selectedCadParcel);
        this.zoomOnMbrWithTransition(this.curCadastralData.mbrOverview);
    }

    @Watch("curCadastralOverlapData")
    async onChangeCurCadastralOverlapData() {
        if (this.selectedLayer) {
            this.map?.removeMapLayer(this.selectedLayer.layerId);
            this.selectedLayer = null;
        }
        if (!this.map || !this.curCadastralOverlapData || !this.curCadastralOverlapData.geom) {
            return;
        }
        const selectedCadParcel: VectorLayerDef = {
            layerType: "VECTOR",
            layerId: "SELECTED_CADPARCEL",
            features: [
                {
                    wkt: this.curCadastralOverlapData.geom,
                    id: this.curCadastralOverlapData.parcel1 + "-" + this.curCadastralOverlapData.parcel2,
                    style: {
                        borderColor: "red",
                        fillColor: "rgb(0, 0, 255, 0.2)",
                        width: 4,
                    },
                },
            ],
            isOverlay: true,
            description: "selected cadastral parcel overlap",
            on: true,
            zIndex: 1005,
        };
        this.selectedLayer = await this.map.addMapLayer(selectedCadParcel);
        this.localMap.getView().fit(this.WKTParser.readGeometry(this.curCadastralOverlapData.geom).getExtent(), {
            padding: this.padding.map((v: number) => v + 10),
        });
    }

    onChangeIsMapOnFullScreen(value: boolean) {
        this.showNavBar = !value;
        this.isMapOnFullscreen = value;
    }

    private centerMapOnPick() {
        const geometryExtent = this.pickedFeature?.getGeometry()?.getExtent();

        const size = this.localMap.getSize() as number[];
        const height = size[1];
        const pixelSize = (this.globalMapView.extent[3] - this.globalMapView.extent[1]) / height;

        const editedExtent = [...this.globalMapView.extent];
        editedExtent[1] = editedExtent[1] + pixelSize * this.paddingBottom;

        if (!this.clickOnMap && geometryExtent && !containsExtent(editedExtent, geometryExtent)) {
            this.map.centerViewOnMbr(geometryExtent, {
                minResolution: intersects(editedExtent, geometryExtent) ? this.globalMapView.resolution : undefined,
            });
        }
    }

    @Watch("forceApplyFilters")
    centerMapOnFilteredPlots() {
        if (!this.filteredPlots.length || !this.localMap || !this.globalMapView) return;
        let extent = createEmpty();
        this.filteredPlots.forEach((plot) => {
            const plotExtent = this.WKTParser.readGeometry(plot.geom).getExtent();
            extend(extent, plotExtent);
        });
        extent = isEmpty(extent) ? this.curCouncilMbr : extent;

        const size = this.localMap.getSize() as number[];
        const height = size[1];
        const pixelSize = (this.globalMapView.extent[3] - this.globalMapView.extent[1]) / height;

        const editedExtent = [...this.globalMapView.extent];
        editedExtent[1] = editedExtent[1] + pixelSize * this.paddingBottom;

        if (!this.clickOnMap && extent && !containsExtent(editedExtent, extent)) {
            this.map.centerViewOnMbr(extent);
        }
    }

    @Watch("curPlots")
    onMultipleSelection() {
        const sourceMultiple = this.plotsLayer?.buildedLayer.getSource();
        if (sourceMultiple)
            this.multiplePickedFeatures =
                sourceMultiple
                    .getFeatures()
                    .filter((f) => this.curPlots.some((p) => p.plotCode == f.get(FEATURE_ID))) || [];
        this.highlightLayer?.buildedLayer.changed();
    }

    @Watch("plots")
    @Watch("plotsStyleOverride")
    @Debounce(100)
    private async buildPlots() {
        if (!this.map) {
            return;
        }

        this.plotsLayerDef = {
            layerType: "VECTOR",
            layerId: "PLOTS",
            features: this.plots.map((p: Plot) => {
                const styleOverride = this.plotsStyleOverride.find((o) => o.plotCode == p.plotCode);
                return {
                    wkt: p.geom,
                    id: p.plotCode,
                    style: styleOverride
                        ? styleOverride.style
                        : {
                              borderColor: p.style.borderColor,
                              fillColor:
                                  p.style.fillStyle == "stroke"
                                      ? "transparent"
                                      : p.style.fillColor.length === 9
                                      ? p.style.fillColor
                                      : p.style.fillColor + "30",
                          },
                };
            }),
            description: this.curConfiguration?.FIELDS_LAYER_DESCRIPTION || (this.i18n("fields") as string),
            on: true,
            zIndex: 0,
            styleFunction: this.basicStyleFunction,
        };

        this.highlightLayer = await this.addHighlightLayers();
        this.plotsLayer?.buildedLayer.un("change:visible", this.changeVisibility);
        this.plotsLayer = (await this.map.updateMapLayer(
            this.plotsLayerDef,
            this.plotsLayer?.layerId
        )) as AbcVectorLayer;
        this.plotsLayer.buildedLayer.on("change:visible", this.changeVisibility);
        this.onCurPlotSelected();
        this.onMultipleSelection();
    }

    private changeVisibility(evt: ObjectEvent) {
        this.cancel();
        this.highlightLayer?.buildedLayer.setVisible(!evt.oldValue);
    }

    private async loadAdditionalLayers() {
        return await this.singleCropPlan.layerApi.getAdditionalLayers(
            this.business.businessId,
            this.curCropPlan.cropPlanId,
            this.curCouncil.domainZoneId
        );
    }

    private async loadSnapGeometries(snapElementType: string[]) {
        /* const refDate = convertToDate(this.cropPlanDates?.referenceDate);
        if (!refDate) {
            console.error("DevError - No referenceDate was found");
            return [];
        } */
        try {
            this.snapGeometries = await this.singleCropPlan.layerApi.getSnapGeometries(
                this.business.businessId,
                this.curCropPlan.cropPlanId,
                this.curCouncil.domainZoneId,
                this.curPointInTime,
                snapElementType
            );
        } catch (error) {
            console.error("DEV - error: ", error);
            this.snapGeometries = null;
        }
        if (this.snapGeometries) return this.buildSnapLayersDef(this.snapGeometries);
        return [];
    }

    private get getCuttableLayersLoading() {
        return this.cuttableLayersLoading;
    }

    private onHover(hoveredFeatures: SelectFeatureObject[]) {
        if (this.drawing || this.editing || this.cutting || this.measureMap) {
            return;
        }
        this.hoveredFeature = null;
        if (hoveredFeatures.length) {
            const hoveredFeature = hoveredFeatures[0].features[0];
            const plot = this.plots.find((p) => p.plotCode == hoveredFeature.get(FEATURE_ID));
            if (plot && this.filteredPlots.find((e) => e.plotCode === plot.plotCode))
                this.hoveredFeature = hoveredFeatures[0].features[0];
        }
        this.highlightLayer?.buildedLayer.changed();
    }

    private onPick(pickedFeatures: SelectFeatureObject[], evt: MapBrowserEvent<PointerEvent>) {
        if (
            this.drawing ||
            this.editing ||
            this.cutting ||
            this.measureMap ||
            this.gisInfoActive ||
            !pickedFeatures.length ||
            !pickedFeatures[0].features.length ||
            this.blockMapPlotSelection
        ) {
            return;
        }
        //
        const tmpPicked = pickedFeatures[0].features[0];
        const plot = this.plots.find((p) => p.plotCode == tmpPicked.get(FEATURE_ID));

        if (plot && !this.filteredPlots.find((e) => e.plotCode === plot.plotCode) && isSCP) return;

        this.clickOnMap = true;
        if (
            this.multiplePlotSelection &&
            ((evt.originalEvent.ctrlKey && !isMacOs()) || (evt.originalEvent.metaKey && isMacOs()))
        ) {
            if (this.curPlot) this.handleMultipleSelection(plot, tmpPicked);
            return;
        }
        this.handleSingleSelection(plot, tmpPicked);
    }

    private handleMultipleSelection(plot?: Plot, tmpPicked?: FeatureLike) {
        if (!plot || plot.plotCode === this.curPlot?.plotCode) {
            return;
        }
        if (tmpPicked && this.multiplePickedFeatures.every((mf) => mf.get(FEATURE_ID) !== tmpPicked.get(FEATURE_ID))) {
            this.curPlots = [...this.curPlots, plot];
        } else {
            this.curPlots = this.curPlots.filter((p) => p.plotCode != plot.plotCode);
        }
    }

    private handleSingleSelection(plot?: Plot, tmpPicked?: FeatureLike) {
        if (tmpPicked && tmpPicked.get(FEATURE_ID) !== this.pickedFeature?.get(FEATURE_ID)) {
            this.curPlot = plot || null;
        } else {
            this.curPlot = null;
        }
        this.curPlots = [];
    }
    private plotStyleFunction(feature: FeatureLike) {
        feature = feature as Feature<Geometry>;
        const plot = this.plots.find((p) => p.plotCode == feature.get(FEATURE_ID));
        const style = [];
        if (this.hoveredFeature && feature.get(FEATURE_ID) === this.hoveredFeature.get(FEATURE_ID)) {
            style.push(
                new Style({
                    stroke: new Stroke({
                        width: 5,
                        color: plot?.style.borderColor,
                    }),
                    fill: new Fill({
                        color:
                            plot?.style.fillStyle == "stroke"
                                ? "transparent"
                                : this.editPlotMode !== EditPlotMode.NOT_SELECTED
                                ? "transparent"
                                : plot?.style.fillColor.length === 9
                                ? plot?.style.fillColor
                                : plot?.style.fillColor + "30",
                    }),
                    zIndex: 900,
                })
            );
        }

        if (this.pickedFeature && feature.get(FEATURE_ID) === this.pickedFeature.get(FEATURE_ID)) {
            style.push(
                new Style({
                    stroke: new Stroke({
                        width: 5,
                        color: "#6ea5ad",
                    }),
                    fill: new Fill({
                        color:
                            plot?.style.fillStyle == "stroke"
                                ? "transparent"
                                : this.editPlotMode !== EditPlotMode.NOT_SELECTED
                                ? "transparent"
                                : plot?.style.fillColor.length === 9
                                ? plot?.style.fillColor
                                : plot?.style.fillColor + "30",
                    }),
                    zIndex: 900,
                })
            );
        }
        if (
            this.multiplePickedFeatures.length &&
            this.multiplePickedFeatures.some((f) => f.get(FEATURE_ID) === feature.get(FEATURE_ID))
        ) {
            style.push(
                new Style({
                    stroke: new Stroke({
                        width: 5,
                        color: plot?.style.borderColor,
                    }),
                    fill: new Fill({
                        color:
                            plot?.style.fillStyle == "stroke"
                                ? "transparent"
                                : this.editPlotMode !== EditPlotMode.NOT_SELECTED
                                ? "transparent"
                                : plot?.style.fillColor.length === 9
                                ? plot?.style.fillColor
                                : plot?.style.fillColor + "30",
                    }),
                    zIndex: 899,
                })
            );
        }

        if (
            plot &&
            plot.style.fillStyle == "stroke" &&
            !this.plotsStyleOverride.find((o) => o.plotCode == plot.plotCode)
        ) {
            style.push(
                new Style({
                    stroke: new Stroke({
                        width: 1,
                        color: plot.style.borderColor,
                    }),
                    fill: new Fill({
                        color: makeStrokePattern(plot.style.borderColor),
                    }),
                })
            );
        }

        return style.length ? style : [];
    }

    private basicStyleFunction() {
        if (this.editPlotMode !== EditPlotMode.NOT_SELECTED) {
            return new Style({
                stroke: new Stroke({
                    width: 2,
                    color: "#ffffff",
                }),
                fill: new Fill({
                    color: "transparent",
                }),
            });
        }
        return null;
    }

    private buildSnapLayersDef(snapGeometries: SnapGeometryDef): VectorLayerDef[] {
        return snapGeometries.types.map((type) => {
            return {
                layerType: "VECTOR",
                layerId: "SNAPS",
                features: snapGeometries.geometries
                    .filter((g) => g.type === type.type)
                    .map((g) => ({
                        wkt: g.geom,
                        id: g.id,
                    })),
                style: {
                    fillColor: "transparent",
                    borderColor: "transparent",
                },
                description: type.description,
                on: true,
                isOverlay: true,
                snapElementType: type.type,
            };
        });
    }

    private async addSnapLayers(snapGeometriesDef: VectorLayerDef[]) {
        if (!this.map) {
            return [];
        }

        try {
            const snapLayers: Promise<AbcVectorLayer>[] = [];
            snapGeometriesDef.forEach((snapGeom) => {
                // Prevent throw error by removing null wkt's features
                snapGeom.features = snapGeom.features.filter((it) => !isNullish(it.wkt));
                if (snapGeom.features) {
                    try {
                        snapLayers.push(this.map.addMapLayer(snapGeom) as Promise<AbcVectorLayer>);
                    } catch (error) {
                        console.error("Error adding snap layer", error);
                    }
                }
            });
            const res = await Promise.all(snapLayers);
            res.forEach((l) => l.buildedLayer.on("change:visible", this.cancel));
            return res;
        } catch (error) {
            console.error("DevError - addSnapLayers() encounter an error: ", error);
            return [];
        }
    }

    private async addAdditionalLayers(additionalLayersDef: LayerDef[]): Promise<GenericLayer[]> {
        if (!this.map || (!this.cropPlanDates.referenceDate && !this.curPointInTime)) return [];

        this.additionalLayers.forEach((l) => {
            this.map.removeMapLayer(l.layerId);
        });
        const addLayers: Promise<GenericLayer | null>[] = [];
        additionalLayersDef.forEach((layerDef) => {
            if (AbcWMSLayer.instanceOfWmsDef(layerDef)) {
                (layerDef as WMSLayerDef) = {
                    ...layerDef,
                    optionalParams:
                        layerDef.layerParameters && layerDef.layerParameters.length
                            ? this.getParamsValue(layerDef.layerParameters)
                            : { point_in_time: this.cropPlanDates.referenceDate ?? this.curPointInTime },
                };
            }
            addLayers.push(
                this.map.addMapLayer(layerDef).catch((error) => {
                    console.error("Error adding additional layer", error);
                    return null;
                })
            );
        });
        this.additionalLayersDef = additionalLayersDef;
        const res = await Promise.all(addLayers);
        return res.filter((l) => l !== null) as GenericLayer[];
    }

    private getParamsValue(layerParams: LayerParamDef[]) {
        const refDate = convertToDate(this.cropPlanDates?.referenceDate);
        if (!refDate) {
            console.error("DevError - No referenceDate was found");
            return {};
        }

        return layerParams.reduce<Record<string, string>>((outObj, param) => {
            if (param.type == LayerParamType.POINT_IN_TIME) {
                outObj[param.name] = formatDate(refDate);
            } else if (param.type == LayerParamType.POINT_IN_TIME_WITH_TIME) {
                outObj[param.name] = formatDateTime(new Date(refDate.setHours(23, 59, 59)));
            } else if (param.type == LayerParamType.DOMAIN_ZONE_ID) {
                outObj[param.name] = this.curCouncil.domainZoneId;
            } else if (param.type == LayerParamType.CAMPAIGN) {
                outObj[param.name] = this.cropPlanDates.referenceDate.slice(0, 4);
            }
            return outObj;
        }, {});
    }

    private async addHighlightLayers(): Promise<AbcVectorLayer> {
        const hoveredFeaturesLayer: VectorLayerDef = {
            layerType: "VECTOR",
            layerId: "HIGHLIGHTED_FEATURES",
            features: this.plots.map((p: Plot) => {
                const styleOverride = this.plotsStyleOverride.find((o) => o.plotCode == p.plotCode);
                return {
                    wkt: p.geom,
                    id: p.plotCode,
                    style: styleOverride
                        ? styleOverride.style
                        : {
                              borderColor: p.style.borderColor,
                              fillColor:
                                  p.style.fillStyle == "stroke"
                                      ? "transparent"
                                      : p.style.fillColor.length === 9
                                      ? p.style.fillColor
                                      : p.style.fillColor + "30",
                          },
                };
            }),
            isOverlay: true,
            description: "highlighted features",
            on: true,
            zIndex: 999,
            styleFunction: this.plotStyleFunction,
        };

        return (await this.map.updateMapLayer(hoveredFeaturesLayer, this.highlightLayer?.layerId)) as AbcVectorLayer;
    }

    private showModalOnAlertCodes(alertCodes: string[] | null) {
        this.alertCodes = alertCodes;
        if (alertCodes && alertCodes.length > 0) this.plotsForceReload++;
    }

    private get showAlertCodesModal() {
        return this.alertCodes !== null && this.alertCodes.length > 0;
    }

    private get isCadastralParcelSearchEnabled() {
        return this.curConfiguration?.ENABLE_PLACES_SEARCH === "TRUE" ?? false;
    }

    private zoomOnCadastralParcel(data: CadastralParcel) {
        this.showCadastralParcelSearchModal = false;
        //
        const geomData = new AbcWKT().WKTParser.readFeature(data.geom, { dataProjection: data.srs }).getGeometry();
        if (geomData)
            this.localMap.getView().fit(geomData.getExtent(), {
                padding: this.padding.map((v: number) => v + 10),
            });
        // show cadastralParcels layer
        const cadParcelsLayer = this.additionalLayers.find((l) => l.layerDef.code == "PLACES");
        if (cadParcelsLayer) cadParcelsLayer.setVisibility(true);
    }

    private zoomOnMbr(mbr: string) {
        const geom = new AbcWKT().WKTParser.readFeature(mbr).getGeometry();
        if (geom)
            this.localMap.getView().fit(geom.getExtent(), {
                padding: this.padding.map((v: number) => v + 10),
            });
    }

    private zoomOnMbrWithTransition(mbr: string) {
        const geom = new AbcWKT().WKTParser.readFeature(mbr).getGeometry();
        const geometryExtent = geom ? geom.getExtent() : undefined;

        const size = this.localMap.getSize() as number[];
        const height = size[1];
        const pixelSize = (this.globalMapView.extent[3] - this.globalMapView.extent[1]) / height;

        const editedExtent = [...this.globalMapView.extent];
        editedExtent[1] = editedExtent[1] + pixelSize * this.paddingBottom;

        if (!this.clickOnMap && geometryExtent && !containsExtent(editedExtent, geometryExtent)) {
            this.map.centerViewOnMbr(geometryExtent, {
                minResolution: intersects(editedExtent, geometryExtent) ? this.globalMapView.resolution : undefined,
            });
        }
    }

    private initPlotPopover() {
        const updateOverlay = (e: MapBrowserEvent<any>) => {
            const pixel = this.localMap.getEventPixel(e.originalEvent);
            if (this.localMap.hasFeatureAtPixel(pixel)) {
                this.localMap.forEachFeatureAtPixel(pixel, (feature, layer) => {
                    if (this.snapGeometries) {
                        this.hoveredLayerGeom =
                            this.snapGeometries.geometries.find((geometry) => geometry.id == feature.get(FEATURE_ID)) ??
                            null;
                    }
                    if (layer && layer.get("abaco_layer_id") === "PLOTS") {
                        const plotCode = feature.get(FEATURE_ID);
                        this.hoveredPlot = this.plots.find((p) => p.plotCode == plotCode) ?? null;
                        const elementPlotPopoverOverlay = this.plotPopoverOverlay
                            ? this.plotPopoverOverlay.getElement()
                            : undefined;
                        if (elementPlotPopoverOverlay) elementPlotPopoverOverlay.hidden = this.hoveredPlot === null;
                        if (this.hoveredPlot && this.plotPopoverOverlay) {
                            this.plotPopoverOverlay.setPosition(e.coordinate);
                        }
                    } else if (
                        layer &&
                        layer.get("abaco_layer_id") === "SNAPS" &&
                        this.parcelData &&
                        this.parcelData.length > 0 &&
                        feature.get(FEATURE_ID)
                    ) {
                        const parcelCode = feature.get(FEATURE_ID);
                        const parcel = this.parcelData.find((parcel) => parcel.parcelCode === parcelCode);
                        if (parcel) {
                            this.hoveredParcel = parcel;
                            const elementParcelPopoverOverlay = this.parcelPopoverOverlay
                                ? this.parcelPopoverOverlay.getElement()
                                : undefined;
                            if (elementParcelPopoverOverlay)
                                elementParcelPopoverOverlay.hidden = this.hoveredParcel === null;
                            if (this.hoveredParcel && this.parcelPopoverOverlay) {
                                this.parcelPopoverOverlay.setPosition(e.coordinate);
                            }
                        }
                    } else if (
                        this.cadastralData &&
                        this.cadastralData.length > 0 &&
                        feature.get(FEATURE_ID) &&
                        this.snapGeometries
                    ) {
                        const cadastralCode = feature.get(FEATURE_ID);
                        const cadastralParcelInfo = this.snapGeometries.geometries.find(
                            (geometry) => geometry.type == "CADPARCEL" && geometry.id == cadastralCode
                        );
                        if (cadastralParcelInfo) {
                            const cadastralParcel = this.cadastralData.find(
                                (cadastralData) => cadastralData.parcel === cadastralParcelInfo.description
                            );
                            if (cadastralParcel) {
                                this.hoveredCadastral = cadastralParcel;
                                const elementCadastralPopoverOverlay = this.cadastralPopoverOverlay
                                    ? this.cadastralPopoverOverlay.getElement()
                                    : undefined;
                                if (elementCadastralPopoverOverlay)
                                    elementCadastralPopoverOverlay.hidden = this.hoveredCadastral === null;
                                if (this.hoveredCadastral && this.cadastralPopoverOverlay) {
                                    this.cadastralPopoverOverlay.setPosition(e.coordinate);
                                }
                            }
                        }
                    }
                });
            }
        };
        this.plotPopoverOverlay = new Overlay({
            element: this.plotPopoverElement,
            positioning: "bottom-center",
            offset: [0, -10],
        });
        this.parcelPopoverOverlay = new Overlay({
            element: this.parcelPopoverElement,
            positioning: "bottom-center",
            offset: [0, -10],
        });
        this.cadastralPopoverOverlay = new Overlay({
            element: this.cadastralPopoverElement,
            positioning: "bottom-center",
            offset: [0, -10],
        });
        this.localMap.addOverlay(this.plotPopoverOverlay);
        this.localMap.addOverlay(this.parcelPopoverOverlay);
        this.localMap.addOverlay(this.cadastralPopoverOverlay);
        //
        this.localMap.on("pointermove", (e) => {
            this.hoveredPlot = null;
            this.hoveredParcel = null;
            this.hoveredCadastral = null;
            if (this.plotPopoverOverlay) {
                const elementPlotPopoverOverlay = this.plotPopoverOverlay.getElement();
                if (elementPlotPopoverOverlay) elementPlotPopoverOverlay.hidden = true;
            }
            if (this.parcelPopoverOverlay) {
                const elementParcelPopoverOverlay = this.parcelPopoverOverlay.getElement();
                if (elementParcelPopoverOverlay) elementParcelPopoverOverlay.hidden = true;
            }
            if (this.cadastralPopoverOverlay) {
                const elementCadastralPopoverOverlay = this.cadastralPopoverOverlay.getElement();
                if (elementCadastralPopoverOverlay) elementCadastralPopoverOverlay.hidden = true;
            }
            if (this.measureMap) return;
            //
            if (this.plotPopoverUpdateTimerId) clearTimeout(this.plotPopoverUpdateTimerId);
            if (this.editPlotMode !== EditPlotMode.NOT_SELECTED)
                this.plotPopoverUpdateTimerId = setTimeout(() => updateOverlay(e), 1000);
            else updateOverlay(e);
        });
    }

    @Watch("bufferSizeOptions", { immediate: true })
    private onBufferSizeOptionsUpdate() {
        if (this.bufferSizeOptions.length) this.bufferSize = this.bufferSizeOptions[0];
    }

    @Watch("bufferBehaviour")
    private onBufferModeUpdate() {
        if (this.editPlotMode === EditPlotMode.ADDING_BUFFER) this.evalBufferMode();
    }

    @Watch("showBufferPositionSelect")
    private onShowBufferPositionSelectUpdate() {
        if (!this.showBufferPositionSelect) this.bufferPosition = "CENTER";
    }

    private evalBufferMode() {
        if (this.bufferBehaviour != "FREE_DRAW" && !this.curPlot && !this.curPlots.length)
            this.bufferBehaviour = "FREE_DRAW";
        this.$nextTick(() => {
            this.startAddingBuffer();
            this.highlightLayer?.buildedLayer.setVisible(this.bufferBehaviour == "FREE_DRAW");
        });
    }

    // Duplicate code
    private deselect() {
        this.curPlot = null;
        this.curPlots = [];
    }

    private async fetchSubdomainZone() {
        const mapViewExtent = this.localMap.getView().calculateExtent();
        const mapViewPolygon = fromExtent(mapViewExtent);
        const mapViewGeom = this.WKTParser.writeGeometry(mapViewPolygon);
        this.loadingSubdomainZone = true;
        try {
            this.subdomainZone = await this.singleCropPlan.councilApi.getSubdomainZone(
                this.business.businessId,
                this.curCropPlan.cropPlanId,
                this.curCouncil.domainZoneId,
                this.curPointInTime,
                mapViewGeom
            );
            this.plotsForceReload++;
        } catch (error) {
            const errorCode = (error as any).response?.data?.errorCode;
            const errorMessage = (error as any).response?.data?.message;
            if (errorCode && errorCode == "TOO_MANY_PLOTS_IN_SUBDOMAIN_ZONE") {
                this.toast(
                    this.i18n("too-many-plots-in-subdomain-zone-modify-zoom", {
                        date: this.formattedDate(this.curPointInTime),
                    }).toString(),
                    { type: "error", duration: 6000 }
                );
            } else if (errorMessage) {
                this.toast(errorMessage, { type: "error", duration: 6000 });
            }
        }
        this.loadingSubdomainZone = false;
    }
    private get showCompleteWithTara() {
        return !!this.curConfiguration?.TARE_LAND_USE_CODE && this.curConfiguration?.TARE_LAND_USE_CODE != "NULL";
    }

    private getLayerDescription(type: string) {
        return this.snapGeometries
            ? this.snapGeometries.types.find((t) => t.type === type)?.description.replace("->", " - ")
            : "";
    }

    private toggleEraseParcelModal() {
        this.showEraseParcelModal = !this.showEraseParcelModal;
    }

    private get isBufferSizeEnabled() {
        return this.curConfiguration?.ENABLE_PLOT_EDIT_BUFFER === "TRUE";
    }

    private eraseParcel() {
        this.cancelDraw();
        this.toggleEraseParcelModal();
        this.startDrawFromErased();
    }

    @Debounce(500)
    private async getBufferPreview() {
        if (this.curPlotOut) await this.requestEditPreview(this.curPlotOut);
    }

    private async getPlotBuffer() {
        try {
            if (this.curPlot?.plotCode) {
                const res = await this.singleCropPlan.plotApi.getBuffer(
                    this.business.businessId,
                    this.curCropPlan.cropPlanId,
                    this.curCouncil.domainZoneId,
                    this.curPlot.plotCode,
                    this.curPointInTime
                );
                this.plotBufferSize = res.bufferSize;
            }
        } catch (error) {
            const errorCode = (error as any).response?.data?.errorCode;
            if (errorCode === "MISSING_DISTANCE_BETWEEN_ROWS_CM") {
                this.toast(this.i18n("missing-distance-between-rows").toString(), { type: "error", duration: 6000})
            }
        }
    }
}
</script>

<style lang="scss" scoped>
.plot-popover {
    padding: 0.5rem;
    border-radius: 3px;
    color: var(--color-text);
    background-color: var(--color-bg-100);
    > div {
        &:not(.plot-name) {
            font-size: 0.8rem;
            label {
                font-size: 1rem;
                font-weight: 700;
            }
        }
    }
    .plot-name {
        padding: 0 0.5rem;
        margin-bottom: 0.5rem;
        text-align: center;
        font-weight: 700;
        color: var(--color-text-opposite);
        background-color: var(--brand-yellow-500);
    }
    ul {
        list-style: circle;
        list-style-position: inside;
    }
}
</style>

<style lang="scss">
.override-tile-button-class .frk-tile-button {
    background-color: white !important;
    @apply text-success-600;
}

[data-theme="dark"] .override-tile-button-class .frk-tile-button {
    background-color: var(--color-bg-100) !important;
    @apply text-success-dark-600;
}
</style>

<style lang="scss">
.buffer_size_input {
    label {
        color: white;
    }
    input {
        color: rgba(0, 0, 0, 0.85);
    }
}
</style>
