<template>
    <div
        class="cp-timeline-line flex absolute bg-danger-200 border-danger-200 h-full border-2 z-10 rounded-full"
        :style="containerStyle"
    ></div>
</template>

<script lang="ts">
import { Prop, Component, Inject, Vue } from "vue-property-decorator";
import { TranslateResult } from "vue-i18n";

@Component
export default class CropPlanTimelineGraphLine extends Vue {
    @Inject() i18n!: (key: string, values?: unknown) => TranslateResult;

    @Prop() title!: string;
    @Prop() top!: number;
    @Prop() left!: number;

    private isHovering = false;

    private get containerStyle() {
        return {
            left: this.left + "px",
        };
    }
}
</script>

<style lang="scss">
.cp-timeline-line {
    @apply transition-all duration-150 ease-in-out;
    top: 0px;
    width: 4px;
    [data-theme="dark"] & {
        @apply bg-danger-500 border-danger-500;
    }
}
</style>
