<template>
    <div
        class="s-cp-declaration-period-row flex w-full px-2"
        :class="{ 'mb-5': !isOverallArea && idx < plotPeriodData.declaredAreas.length - 1 }"
    >
        <div v-if="!isOverallArea" class="flex flex-col items-center h-full">
            <div
                v-if="idx === 0 && maxDate"
                class="mb-5 flex flex-col items-center justify-center py-1 px-3 border rounded-xl text-label-primary text-sm"
            >
                <span class="text-label-primary" style="font-size: 9px">{{
                    formattedYear(maxDate) !== new Date("9999-12-31") ? "" : formattedYear(maxDate)
                }}</span>
                <span style="margin-top: -2px">{{
                    formattedYear(maxDate) !== new Date("9999-12-31") ? "--" : formattedDayMonth(maxDate)
                }}</span>
            </div>
            <div
                class="flex flex-grow bg-bg-500 rounded"
                style="width: 3px; margin-top: -10px; margin-bottom: 10px; height: 28px"
            />
            <div
                class="flex flex-col items-center justify-center py-1 px-3 border rounded-xl text-label-primary text-sm"
            >
                <span class="text-label-primary" style="font-size: 9px">{{ formattedYear(period.date) }}</span>
                <span style="margin-top: -2px">{{ formattedDayMonth(period.date) }}</span>
            </div>
        </div>
        <div
            class="flex items-center pl-4 flex-grow pt-1 pb-1 relative"
            :class="{
                's-cp-declaration-period-row-bordered-bottom': !isOverallArea,
                's-cp-declaration-period-row-bordered-top': !isOverallArea && idx === 0,
            }"
            :style="[
                !isOverallArea && idx > 0
                    ? { 'margin-top': '-60px' }
                    : !isOverallArea && idx === 0
                    ? { 'margin-top': '0px' }
                    : { 'padding-left': '70px' },
            ]"
        >
            <!-- :style="[!isOverallArea ? {'margin-top': '0px'} : {'padding-left': '70px'}]" -->
            <area-section
                :plotPeriodData="plotPeriodData"
                :plotAreaSqm="areaSqm"
                :coveredPercentage="compiledArea"
                :isHectarVisualization="!isOverallArea"
                :lockAreaTo100="lockAreaTo100"
                :overridePercentage="overriddenPercentage"
                :ignoreAreaLimit="ignoreAreaLimit"
                :enableZeroArea="enableZeroArea"
                :forceDisableInput="forceDisableInput"
                :isCollective="isCollective"
                :showUseAllAvailable="showUseAllAvailable"
                :percentageDecimalsNumber="percentageDecimalsNumber"
                :isNew="isNew"
                @coveredPercentageUpdated="onCoveredPercentageUpdated"
            />
        </div>
    </div>
</template>

<script lang="ts">
import { Prop, Component, Mixins, Inject } from "vue-property-decorator";
import { TranslateResult } from "vue-i18n";
import { PlotPeriod, PlotPeriodsData } from "../../models/Declaration";
import DateUtils from "../../mixins/DateUtils";
import AreaUtils from "../../mixins/AreaUtils";
import AreaSection from "../tiles/NewCropPlanDeclarationImplementation/AreaSection.vue";

@Component({
    components: {
        AreaSection,
    },
})
export default class DeclarationEditAreaSection extends Mixins(DateUtils, AreaUtils) {
    @Inject() i18n!: (key: string, values?: unknown) => TranslateResult;

    @Prop() plotPeriodData!: PlotPeriodsData;
    @Prop() period!: PlotPeriod | null;
    @Prop() idx!: number | null;
    @Prop() compiledArea!: number;
    @Prop() maxDate!: Date | null;
    @Prop() lockAreaTo100!: boolean;
    @Prop({ type: Boolean, default: false }) forceDisableInput!: boolean;
    @Prop({ type: Boolean, default: false }) ignoreAreaLimit!: boolean;
    @Prop({ type: Boolean, default: false }) enableZeroArea!: boolean;
    @Prop({ default: undefined, type: Number }) overriddenPercentage!: number;
    @Prop({ type: Boolean, default: false }) isCollective!: boolean;
    @Prop({ type: Boolean, default: false }) showUseAllAvailable!: boolean;
    @Prop() percentageDecimalsNumber!: number;
    @Prop({ default: false }) isNew!: boolean;

    private get isOverallArea(): boolean {
        return this.period ? false : true;
    }

    private get areaSqm() {
        return this.period ? this.period.areaSqm : 0;
    }

    private onCoveredPercentageUpdated(value: { percentageInput: number; plotCode: string }) {
        this.$emit("coveredPercentageUpdated", value);
    }
}
</script>

<style lang="scss">
.s-cp-declaration-period-row-bordered-bottom::after {
    content: "";
    @apply absolute left-0 right-0 bg-border;
    bottom: 19px;
    height: 1px;
}

.s-cp-declaration-period-row-bordered-top::before {
    content: "";
    @apply absolute left-0 right-0 bg-border;
    top: 19px;
    height: 1px;
}
</style>
