<script lang="ts">
/**
 * This doesn't actually render a modal,
 * it creates a unique ID to the requested loading and manages its data through its own lifecycle
 */

import { Vue, Component, Prop, Inject } from "vue-property-decorator";
import { TranslateResult } from "vue-i18n";
import { FromStore } from "@abaco/web-common/src/app";
import SingleCropPlanModule, { MODULE_ID } from "../..";
import { AppLoadingItem } from "../../models/Utils";

@Component
export default class AppLoadingModal extends Vue {
    @Inject() i18n!: (key: string, values?: unknown) => TranslateResult;
    @Inject(MODULE_ID) singleCropPlanModule!: SingleCropPlanModule;

    @FromStore(MODULE_ID) appLoadingQueue!: AppLoadingItem[];

    @Prop() message?: string;

    private id = Symbol();

    mounted() {
        this.appLoadingQueue = [
            ...this.appLoadingQueue,
            {
                id: this.id,
                message: this.message,
            },
        ];
    }

    beforeDestroy() {
        this.appLoadingQueue = this.appLoadingQueue.filter((i) => i.id != this.id);
    }
}
</script>

<template>
    <div style="display: none"></div>
</template>
