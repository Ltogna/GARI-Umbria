<template>
    <div>
        <h4 v-if="title" class="my-5 font-bold">{{ title }}</h4>
        <abc-table v-if="landuseList.length > 0" :items="uniqueLandUses" item-id="landUseTableId">
            <template #headers>
                <th id="toggle-all-landuse-action">
                    <abc-checkbox :value="allLandusesSelected" @input="onLandUsesSelect()"></abc-checkbox>
                </th>
                <th id="landuse_code_description">{{ i18n("landuse-code-description") }}</th>
                <th id="rotation">{{ i18n("landuse-rotation") }}</th>
                <th id="declared_area">{{ i18n("landuse-declared-area") }}</th>
                <th id="mandatory_attributes">{{ i18n("mandatory-attributes") }}</th>
            </template>
            <template #items="{ item }">
                <td>
                    <abc-checkbox v-model="item._selected"></abc-checkbox>
                </td>
                <td class="cursor-pointer">
                    {{ item.landUse.description }}
                </td>
                <td class="cursor-pointer">{{ item.rotation }}</td>
                <td class="cursor-pointer">{{ formattedAreaWithLabel(item.declAreaSqm) }}</td>
                <td class="cursor-pointer text-end">
                    <em
                        v-if="getAnomalyStatus(item) === 'all'"
                        class="fa-regular fa-pen-circle text-secondary-500 text-2xl"
                        v-b-tooltip.hover="i18n('mandatory-data-missing')"
                    />
                    <em
                        v-else-if="getAnomalyStatus(item) === 'some'"
                        class="fa-regular fa-circle-dashed text-success-500 text-2xl"
                        v-b-tooltip.hover="i18n('mandatory-data-partial')"
                    />
                    <em
                        v-else
                        class="fa-regular fa-circle-check text-success-500 text-2xl"
                        v-b-tooltip.hover="i18n('mandatory-data-complete')"
                    />
                </td>
            </template>
        </abc-table>
        <abc-no-data-found v-else />
    </div>
</template>

<script lang="ts">
import { Component, Inject, Mixins, Prop, Watch } from "vue-property-decorator";
import { TranslateResult } from "vue-i18n";
import { MODULE_ID } from "../..";
import SingleCropPlanModule from "../..";
import { LandUseListItem } from "../../models/LandUse";
import AreaUtils from "../../mixins/AreaUtils";
import { AnomalieStatus, LandUseAnomalyStatus } from "../../models/Declaration";
import { VBTooltip } from "bootstrap-vue";

@Component({
    directives: {
        "b-tooltip": VBTooltip,
    },
    components: {},
})
export default class LandUseTable extends Mixins(AreaUtils) {
    @Inject() i18n!: (key: string, values?: unknown) => TranslateResult;
    @Inject(MODULE_ID) singleCropPlanModule!: SingleCropPlanModule;

    @Prop({ default: [] }) uniqueLandUses!: LandUseListItem[];
    @Prop({ default: null }) title!: string | null;
    @Prop({ default: [] }) landUseAnomalyStatusList!: LandUseAnomalyStatus[];

    private landuseList: LandUseListItem[] = [];

    mounted() {
        this.landuseList = this.uniqueLandUses;
    }

    private get allLandusesSelected() {
        return this.landuseList.every((l) => l._selected);
    }

    getAnomalyStatus(item: LandUseListItem): AnomalieStatus {
        return this.landUseAnomalyStatusList.find((it) => it.landUseCode === item._uniqueLandUseCode)?.status || "none";
    }

    onLandUsesSelect() {
        const someNotSelected = this.uniqueLandUses.some((l) => !l._selected);
        this.landuseList.forEach((l) => {
            l._selected = someNotSelected;
        });
    }

    @Watch("landuseList", { deep: true, immediate: true })
    onLanduseListChange(newVal: LandUseListItem[], oldVal: LandUseListItem[]) {
        if (!oldVal) {
            return;
        }
        this.$emit("landUseListChange", newVal);
    }
}
</script>
