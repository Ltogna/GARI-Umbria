<template>
    <div class="wrap">
        <div class="measurement-panel px-4 py-3 text-sm rounded">
            <div class="title items-center mb-2 pb-2 font-semibold border-b">
                <em class="fal fa-ruler-horizontal"></em>
                <span>{{ i18n("measure") }}</span>
                <span
                    class="info flex align-center justify-center"
                    @mouseover="showMeasurementInfo = true"
                    @mouseleave="showMeasurementInfo = false"
                >
                    <em class="fal fa-info"></em>
                </span>
            </div>
            <div class="row">
                <abc-radio :label="i18n('pcf-label-area')" v-model="mode" radio-value="AREA" />
            </div>
            <div class="row mb-3">
                <abc-radio :label="i18n('distance')" v-model="mode" radio-value="DISTANCE" />
            </div>
            <div class="mb-3 w-full text-center text-xl">
                {{ measureFormatted }}
            </div>
            <abc-button @click="$emit('close')" class="measurement-close-button">
                {{ i18n("close-measurement") }}
            </abc-button>
            <div class="flex flex-col">
                <div
                    class="w-full font-semibold border-b py-1"
                    style="
                        padding-bottom: 2px;
                        color: rgba(255, 255, 255, 0.5);
                        border-color: rgba(255, 255, 255, 0.2);
                    "
                >
                    <em class="fal fa-clone pr-1 text-secondary-500"></em> {{ i18n("commands") }}
                </div>
                <div class="flex mt-1">
                    <div class="flex">
                        <span
                            class="rounded-md border flex items-center justify-center text-xs"
                            style="
                                height: 18px;
                                width: 18px;
                                border-color: rgba(255, 255, 255, 0.5);
                            "
                        >
                            {{ keyToPressDisableSnap }}
                        </span>
                    </div>
                    <p class="ml-2">{{ i18n("disable-snap") }}</p>
                </div>
            </div>
        </div>
        <div v-if="showMeasurementInfo" class="instructions-panel text-sm rounded">
            <div class="title p-2 text-center">{{ i18n("instructions") }}</div>
            <div class="instructions px-4 py-3">
                <ul>
                    <li>{{ i18n('map-measurement-instructions-1') }}</li>
                    <li>{{ i18n('map-measurement-instructions-2') }}</li>
                    <li>{{ i18n('map-measurement-instructions-3') }}</li>
                </ul>
            </div>
        </div>
    </div>
</template>

<script lang="ts">
import { Prop, Component, Inject, Watch, Mixins } from "vue-property-decorator";
import { TranslateResult } from "vue-i18n";
import Map from "ol/Map";
import Collection from "ol/Collection";
import Feature from "ol/Feature";
import { EventsKey } from "ol/events";
import { unByKey } from "ol/Observable";
import MapBrowserEvent from "ol/MapBrowserEvent";
import { Draw, Snap } from "ol/interaction";
import { Vector as VectorSource } from "ol/source";
import { Vector as VectorLayer } from "ol/layer";
import { LineString, Polygon, Geometry, LinearRing } from "ol/geom";
import { Fill, Stroke, Style, Circle } from "ol/style";
import AreaUtils from "../../mixins/AreaUtils";
import AbcVectorLayer from "@abaco/iacs-map-module/src/modules/map-module/Layer/AbcVectorLayer";
import cloneDeep from "lodash/cloneDeep";

@Component
export default class SingleCpMapHelpMeasure extends Mixins(AreaUtils) {
    @Inject() i18n!: (key: string, values?: unknown) => TranslateResult;

    @Prop() map!: Map;
    @Prop({ default: null }) snapLayers!: AbcVectorLayer[] | null;
    @Prop({ default: null }) plotsLayer!: AbcVectorLayer | null;

    private mode: "DISTANCE" | "AREA" = "DISTANCE";

    private readonly sketchSource = new VectorSource();
    private readonly sketchLayer = new VectorLayer({
        source: this.sketchSource,
        style: new Style({
            fill: new Fill({ color: "rgba(0, 0, 0, 0)" }),
            stroke: new Stroke({ color: "rgba(0, 0, 0, 0)" }),
        }),
    });
    private sketchFeat: Feature<Geometry> | null = null;

    private readonly previewLayer = new VectorLayer({
        source: new VectorSource(),
        style: new Style({
            fill: new Fill({
                color: "rgba(255, 255, 255, 0.2)",
            }),
            stroke: new Stroke({
                width: 2.5,
                color: "#ffffff",
            }),
            image: new Circle({
                radius: 7,
                fill: new Fill({ color: "#ffffff" }),
            }),
        }),
    });
    private previewFeat: Feature<Geometry> | null = null;

    private drawInteraction: Draw | null = null;
    private snapInteraction: Snap | null = null;
    private sketchSnapInteraction: Snap | null = null;

    private measureFormatted = "";

    private showMeasurementInfo = false;

    private get snappableLayers() {
        const res = this.snapLayers ? this.snapLayers.filter((sl) => sl.layerDef.on) : [];
        if (this.plotsLayer?.layerDef.on) res.push(this.plotsLayer);
        return res.map((sl) => sl.buildedLayer);
    }

    mounted() {
        this.sketchLayer.setZIndex(998);
        this.previewLayer.setZIndex(999);
        this.map.addLayer(this.sketchLayer);
        this.map.addLayer(this.previewLayer);
        this.map.on("click", this.previewFromSketch);
    }

    beforeDestroy() {
        this.map.un("click", this.previewFromSketch);
        this.removeInteraction();
        this.map.removeLayer(this.sketchLayer);
        this.map.removeLayer(this.previewLayer);
  }

    @Watch("mode", { immediate: true })
    private onModeUpdate() {
        this.measureFormatted = this.mode == "DISTANCE" ? this.formatMeasureLength(0) : this.formatMeasureArea(0);
        // if still was drawing end it
        if (this.drawInteraction)
            this.drawInteraction.finishDrawing();
        // toggle preview area/line
        if (this.previewFeat) {
            const prevGeom = cloneDeep(this.previewFeat.getGeometry());
            this.previewReset();
            //
            const geom =
                prevGeom instanceof Polygon
                    ? new LineString(prevGeom.getLinearRing(0)!.getCoordinates())
                    : new Polygon([new LinearRing((prevGeom as LineString).getCoordinates()).getCoordinates()]);
            this.previewFromFeature(
                new Feature({
                    geometry: geom,
                })
            );
            this.updateMeasurement(geom);
        } else this.previewReset();
        //
        this.sketchSource.clear();
        this.removeInteraction();
        this.addInteraction();
    }

    private addInteraction() {
        this.drawInteraction = new Draw({
            source: this.sketchSource,
            type: this.mode == "DISTANCE" ? "LineString" : "Polygon",
            clickTolerance: 6,
            style: new Style({
                fill: new Fill({
                    color: "rgba(0, 0, 0, 0)",
                }),
                stroke: new Stroke({
                    color: "rgba(255, 255, 255, 1)",
                    lineDash: [5, 5],
                    width: 2,
                }),
                image: new Circle({
                    radius: 4,
                    stroke: new Stroke({
                        color: "rgba(255, 255, 255, 1)",
                        width: 4,
                    }),
                    fill: new Fill({
                        color: "rgba(0, 0, 0, 1)",
                    }),
                }),
            }),
        });
        this.map.addInteraction(this.drawInteraction);
        const previewLayerSource = this.previewLayer.getSource();
        if (previewLayerSource)
            this.sketchSnapInteraction = new Snap({
                source: previewLayerSource,
            });
        if (this.sketchSnapInteraction) this.map.addInteraction(this.sketchSnapInteraction);

        if (this.snappableLayers.length) {
            this.snapInteraction = new Snap({
                features: new Collection(
                    this.snappableLayers
                        .map((l) => l.getSource()!.getFeatures())
                        .reduce((accum, curFeatures) => (accum = [...accum, ...curFeatures]), [])
                ),
            });
            this.map.addInteraction(this.snapInteraction);
        }

        let listener: EventsKey | undefined;

        this.drawInteraction.on("drawstart", (e) => {
            this.sketchSource.clear();
            this.previewReset();
            this.sketchFeat = e.feature;
            //
            if (!this.sketchFeat) return;
            const geometrySketchFeat = this.sketchFeat.getGeometry();
            if (geometrySketchFeat)
                listener = geometrySketchFeat.on("change", (ce) =>
                    this.updateMeasurement(ce.target as LineString | Polygon)
                );
        });

        this.drawInteraction.on("drawend", (e) => {
            if (listener) unByKey(listener);
            this.sketchFeat = null;
            this.sketchSource.clear();
            this.previewFromFeature(e.feature);
            this.updateMeasurement(e.feature.getGeometry() as Polygon | LineString);
        });
    }

    private removeInteraction() {
        if (this.drawInteraction) {
            this.map.removeInteraction(this.drawInteraction);
            this.drawInteraction = null;
        }
        if (this.sketchSnapInteraction) {
            this.map.removeInteraction(this.sketchSnapInteraction);
            this.sketchSnapInteraction = null;
        }
        if (this.snapInteraction) {
            this.map.removeInteraction(this.snapInteraction);
            this.snapInteraction = null;
        }
    }

    private previewReset() {
        const sourcePreviewLayer = this.previewLayer.getSource();
        if (sourcePreviewLayer) sourcePreviewLayer.clear();
        this.previewFeat = null;
    }

    private previewFromFeature(feature: Feature<Geometry>) {
        this.previewReset();
        this.previewFeat = feature;
        const sourcePreviewLayer = this.previewLayer.getSource();
        if (sourcePreviewLayer) sourcePreviewLayer.addFeature(this.previewFeat);
    }

    private previewFromSketch(e: MapBrowserEvent<any>) {
        if (e.type == "click" && this.sketchFeat) {
            const geometry = this.sketchFeat.getGeometry(),
                coords =
                    geometry instanceof Polygon
                        ? geometry.getLinearRing(0)!.getCoordinates()
                        : (geometry as LineString).getCoordinates();
            //
            if (coords.length > 1) {
                this.previewFromFeature(
                    new Feature({
                        geometry: new LineString(coords.slice(0, coords.length - 1)),
                    })
                );
            }
        }
    }

    private updateMeasurement(geom: Polygon | LineString) {
        this.measureFormatted =
            geom instanceof LineString ? this.formatMeasureLength(geom) : this.formatMeasureArea(geom);
    }

    private formatMeasureLength(source: LineString | number) {
        const length = source instanceof LineString ? source.getLength() : source;
        return length > 1000 ? Math.round((length / 1000) * 100) / 100 + " km" : Math.round(length * 100) / 100 + " m";
    }

    private formatMeasureArea(source: Polygon | number) {
        const area = source instanceof Polygon ? source.getArea() : source;
        return this.formattedArea(area) + " " + this.areaLabel();
    }

    private get keyToPressDisableSnap() {
        return "S";
    }
}
</script>

<style lang="scss" scoped>
.wrap {
    position: relative;
}
.measurement-panel {
    margin-top: 6px;
    margin-left: 6px;
    background: rgba(10, 10, 10, 0.45);
    backdrop-filter: blur(10px);
    color: rgba(255, 255, 255, 0.7);
    > .title {
        border-color: rgba(255, 255, 255, 0.2);
        .info {
            width: 1.2rem;
            height: 1.2rem;
            line-height: 1rem;
            border-radius: 50%;
            padding: 0.2rem;
            color: rgba(255, 255, 255, 0.8);
            background: rgba(255, 255, 255, 0.1);
        }
    }
    > .title,
    > .row {
        @apply flex justify-between items-center gap-2;
    }
    .measurement-close-button {
        width: 100%;
        padding-top: 0.2rem;
        padding-bottom: 0.2rem;
        justify-content: center !important;
        color: rgba(255, 255, 255, 0.8);
        background: rgba(255, 255, 255, 0.1);
    }
}
.instructions-panel {
    position: absolute;
    top: 26%;
    left: 80%;
    width: 220px;
    overflow: hidden;
    background: rgba(10, 10, 10, 0.45);
    backdrop-filter: blur(10px);
    color: rgba(255, 255, 255, 0.7);
    .title {
        background: rgba(10, 10, 10, 0.45);
    }
    .instructions ::v-deep {
        ul {
            color: rgba(255, 255, 255, 0.8);
            list-style: circle !important;
            list-style-position: inside !important;
            li:not(:last-child) {
                padding-bottom: 0.4rem;
            }
        }
    }
}
</style>
