<template>
    <nav-bar-item
        v-if="!pollingIsProcessing && !pollingIsModalOpen && !showCropPlanNotAccessibleModal && !showCannotUseCropPlan && !showRecalcAnomaliesConfirmModal && !showBulkDeclarationEdit"
        v-show="!showCropPlanSyncModal && curCropPlan"
        v-model="councilNavBarFilterOpen"
        custom-class="w-8/12 lg:w-6/12 xxl:w-5/12"
    >
        <template #label>
            <abc-nav-bar-item :opened="councilNavBarFilterOpen">
                <template #icon>
                    <em class="fal fa-map-marker mr-1" />
                </template>
                <p>{{ label }}</p>
            </abc-nav-bar-item>
        </template>
        <abc-nav-bar-item-panel style="min-height: 300px" title="select-council" i18nKeys>
            <div class="h-full w-full flex flex-col overflow-hidden">
                <search-council-criteria
                    :reset-filter="resetFilter"
                    v-model="filter"
                    :filterBySubject="filterBySubject"
                    @update-filter-by-subject="updateFilterBySubject"
                />
                <search-council-results
                    :filter="filter"
                    @select="setCurrentCouncil"
                    :triggerLoad="triggerLoad"
                    :filterBySubject="filterBySubject"
                />
            </div>
        </abc-nav-bar-item-panel>
    </nav-bar-item>
</template>

<script lang="ts">
import { Component, Inject, Watch, Mixins } from "vue-property-decorator";
import { TranslateResult } from "vue-i18n";
import { FromStore } from "@abaco/web-common/src/app";
import FarmerRegistryModule, { MODULE_ID } from "../../../index";
import DateUtils from "../../../mixins/DateUtils";
import { Council } from "../../../models/Council";
import { Business } from "../../../models/Business";
import SearchCouncilCriteria from "./SearchCouncilCriteria.vue";
import SearchCouncilResults from "./SearchCouncilResults.vue";
import { Version } from "../../../models/Version";

@Component({
    components: {
        SearchCouncilCriteria,
        SearchCouncilResults,
    },
})
export default class CouncilSelectNavBarItem extends Mixins(DateUtils) {
    @Inject(MODULE_ID) farmRegistryModule!: FarmerRegistryModule;
    @Inject() i18n!: (key: string, values?: unknown) => TranslateResult;

    @FromStore(MODULE_ID) curCouncil!: Council | null;
    @FromStore(MODULE_ID) business!: Business | null;
    @FromStore(MODULE_ID) curCropPlan!: Business | null;
    @FromStore(MODULE_ID) curVersion!: Version | null;
    @FromStore(MODULE_ID) curPointInTime!: Date | null;
    @FromStore(MODULE_ID) pollingIsProcessing!: boolean;
    @FromStore(MODULE_ID) pollingIsModalOpen!: boolean;
    @FromStore(MODULE_ID) showCannotUseCropPlan!: boolean;
    @FromStore(MODULE_ID) showCropPlanNotAccessibleModal!: boolean;
    @FromStore(MODULE_ID) showCropPlanSyncModal!: boolean;
    @FromStore(MODULE_ID) flRecalcAnomalies!: boolean;
    @FromStore(MODULE_ID) showRecalcAnomaliesConfirmModal!: boolean;
    @FromStore(MODULE_ID) forceSearchCouncil!: number;
    @FromStore(MODULE_ID) showBulkDeclarationEdit!: boolean;

    private councilNavBarFilterOpen = false;
    private loading = false;
    private filterBySubject = true;
    private searchCouncilLoading = false;

    private filter = "";
    private triggerLoad = 0;
    private resetFilter = 0;

    private onCancel() {
        this.curCouncil = null;
        this.councilNavBarFilterOpen = false;
    }

    private setCurrentCouncil(e: Council | null) {
        this.curCouncil = e;
        this.councilNavBarFilterOpen = false;
    }

    @Watch("curCropPlan.cropPlanId")
    @Watch("curVersion")
    private onUpdateFilter() {
        this.curCouncil = null;
        if (this.business && this.curPointInTime && this.curCropPlan) {
            this.councilNavBarFilterOpen = true;
        }
    }

    private updateFilterBySubject(e: boolean) {
        this.filterBySubject = e;
    }

    get label(): TranslateResult {
        return this.curCouncil ? this.curCouncil.description : this.i18n("select-council");
    }

    @Watch("councilNavBarFilterOpen")
    private incrementTriggerLoad() {
        if (this.councilNavBarFilterOpen == true)
            this.triggerLoad++;
    }

    @Watch("flRecalcAnomalies")
    private onRecalcAnomalies(newVal: boolean, oldVal: boolean) {
        if(!newVal && oldVal && !this.curCouncil)
            this.councilNavBarFilterOpen = true;
    }

    @Watch("forceSearchCouncil")
    private onForceSearchCouncil() {
        this.councilNavBarFilterOpen = true;
    }

    @Watch('pollingIsProcessing')
    @Watch('pollingIsModalOpen')
    private forceUpdateAfterPolling() {
        if (!this.pollingIsProcessing && !this.pollingIsModalOpen) {
            this.councilNavBarFilterOpen = true;
        }
    }
}
</script>

<style lang="scss"></style>
