<template>
    <abc-modal
        :title="
            i18n('swap-landuses-title', {
                landuseLabel: i18n('land-uses-legend').toString().toLowerCase(),
                date: formattedCurrentDate,
            })
        "
        @close="$emit('back')"
    >
        <template #body>
            <span>
                {{
                    i18n('swap-landuses-description-1', {
                        landusesLabel: i18n('land-uses-legend').toString().toLowerCase(),
                        date: formattedCurrentDate,
                    })
                }}<br />{{
                    i18n('swap-landuses-description-2', {
                        landusesLabel: i18n('land-uses-legend').toString().toLowerCase()
                    })
                }}
            </span>
            <hr class="my-4" />
            <abc-form ref="form">
                <abc-autocomplete
                    :items="filteredOldLanduses"
                    max-height="200px"
                    :label="i18n('old-landuse', { landuseLabel: i18n('land-use').toString().toLowerCase() })"
                    :stringify="(v) => v.description"
                    :rules="mandatoryRule"
                    v-model="oldLanduse"
                    ref="old-landuse"
                    :search.sync="oldLanduseSearch"
                >
                    <template #items="props">
                        <p>{{ props.item.description }}</p>
                    </template>
                </abc-autocomplete>
                <abc-autocomplete
                    :is-disabled="oldLanduse === null"
                    max-height="200px"
                    :label="i18n('new-landuse', { landuseLabel: i18n('land-use').toString().toLowerCase() })"
                    :value="newLanduse"
                    :items="newLandusesPage.records"
                    :stringify="(item) => (item ? item.description : null)"
                    @input="updateNewLanduse"
                    :search.sync="newLanduseSearch"
                    :rules="mandatoryRule"
                    ref="new-landuse"
                    class="mt-4"
                >
                    <template #items="{ item }">
                        <div>{{ item.description }}</div>
                    </template>
                    <template>
                        <div v-if="newLandusesLoading" class="flex justify-center items-center h-12">
                            <abc-loader :size="32" />
                        </div>
                        <div
                            v-if="!newLandusesLoading && newLandusesPage.records.length === 0"
                            class="flex justify-center items-center h-12"
                        >
                            <abc-no-data-found />
                        </div>
                        <div
                            v-if="!newLandusesLoading && newLandusesPage.records.length > 0 && newLandusesPage.haveMore"
                            class="flex justify-center items-center h-12"
                        >
                            <abc-refine-filter />
                        </div>
                    </template>
                </abc-autocomplete>
                <!-- <abc-switch :label="i18n('edit-dates')" v-model="updateDates" class="mt-4" />
                <template v-if="updateDates">
                    <abc-date-input
                        ref="planting-date"
                        :label="
                            isPermanent
                                ? i18n('pcf-label-planting-date')
                                : i18n('planting-date-base')
                        "
                        v-model="newFromDate"
                        :range-min="dateRange.plantingMin"
                        :range-max="dateRange.plantingMax"
                        hide-delete
                        :rules="[mandatoryRuleAtomic, plantingDateGreaterThanPlotDateRule]"
                        class="mt-4"
                    />
                    <abc-date-input
                        ref="harvest-date"
                        :label="
                            isPermanent
                                ? i18n('pcf-label-uprooting-date')
                                : i18n('harvest-date-base')
                        "
                        v-model="newToDate"
                        :initial-date-ref="newFromDate"
                        :range-min="dateRange.harvestMin"
                        :range-max="dateRange.harvestMax"
                        hide-delete
                        :rules="[mandatoryRuleAtomic, harvestingDateLesserThanPlotDateRule]"
                        class="mt-4"
                    />
                </template> -->
                <abc-date-input
                    ref="planting-date"
                    is-required
                    :label="
                        isPermanent
                            ? i18n('pcf-label-planting-date')
                            : i18n('planting-date-base')
                    "
                    v-model="newFromDate"
                    :range-min="dateRange.plantingMin"
                    :range-max="dateRange.plantingMax"
                    hide-delete
                    :rules="[mandatoryRuleAtomic, plantingDateGreaterThanPlotDateRule]"
                    class="mt-4"
                />
                <abc-date-input
                    ref="harvest-date"
                    is-required
                    :label="
                        isPermanent
                            ? i18n('pcf-label-uprooting-date')
                            : i18n('harvest-date-base')
                    "
                    v-model="newToDate"
                    :initial-date-ref="newFromDate"
                    :range-min="dateRange.harvestMin"
                    :range-max="dateRange.harvestMax"
                    hide-delete
                    :rules="[mandatoryRuleAtomic, harvestingDateLesserThanPlotDateRule]"
                    class="mt-4"
                />
            </abc-form>
        </template>
        <template #footer>
            <abc-button class="mr-2" is-secondary is-outlined @click="$emit('back')">
                <em class="abc-icon abc-icon-arrow-left-round" /> {{ i18n("back") }}
            </abc-button>
            <abc-button @click="sendSwapToServer" is-danger>
                <em class="abc-icon abc-icon-plant-circle" />
                {{ i18n("swap-landuses", { landuseLabel: i18n("land-uses-legend").toString().toLowerCase() }) }}
            </abc-button>
        </template>
    </abc-modal>
</template>

<script lang="ts">
import { Component, Prop, Inject, Watch, Mixins, Ref } from "vue-property-decorator";
import { TranslateResult } from "vue-i18n";
import DateUtils from "../../mixins/DateUtils";
import { FromStore, ToastOptions } from "@abaco/web-common/src/app";
import { MODULE_ID } from "../..";
import { LandUse, Plot, SwappableLandUse } from "../../models/Plot";
import SingleCropPlanModule from "../..";
import { Business } from "../../models/Business";
import { CropPlan, Configuration } from "../../models/CropPlan";
import { Validable } from "@abaco/web-components/src/components/form/Validable";
import { Council } from "../../models/Council";
import { MaxPagedResults, EmptyMaxPagedResults } from "@abaco/web-common/src/Paging";
import { Debounce } from "vue-debounce-decorator";
import { toDateFromFormat } from "../../api/Utils";
import { AbcInputExtended } from "../../models/AbcInputExtended";
import AbcInput from "@abaco/web-components/src/components/input/AbcInput.vue";

@Component
export default class SwapLandusesModal extends Mixins(DateUtils) {
    @Inject(MODULE_ID) singleCropPlanModule!: SingleCropPlanModule;
    @Inject() i18n!: (key: string, values?: unknown) => TranslateResult;
    @Inject() toast!: (message: string, options?: ToastOptions) => TranslateResult;

    @FromStore(MODULE_ID) curPointInTime!: Date;
    @FromStore(MODULE_ID) business!: Business;
    @FromStore(MODULE_ID) curCropPlan!: CropPlan | null;
    @FromStore(MODULE_ID) curCouncil!: Council;
    @FromStore(MODULE_ID) curConfiguration!: Configuration | null;
    @FromStore(MODULE_ID) curPlot!: Plot | null;
    @FromStore(MODULE_ID) curPlots!: Plot[];

    @Prop() readonly swappableLanduses!: SwappableLandUse[];

    @Ref("form") form!: Validable;
    @Ref("old-landuse") oldLanduseInput!: AbcInputExtended;
    @Ref("new-landuse") newLanduseInput!: AbcInputExtended;
    @Ref("planting-date") plantingDateInput!: AbcInput;
    @Ref("harvest-date") harvestDateInput!: AbcInput;

    private mandatoryRule = [(v: unknown) => !!v || this.i18n("valid.mandatory-field")];

    private oldLanduseSearch = "";
    private oldLanduse: SwappableLandUse | null = null;

    private newLanduse: LandUse | null = null;
    private newLandusesRawValues: LandUse[] = [];
    private newLandusesPage: MaxPagedResults<LandUse> = new EmptyMaxPagedResults();
    private newLanduseSearch: string | null = null;
    private newLandusesLoading = false;

    private updateDates = true;
    private newFromDate: Date | null = null;
    private newToDate: Date | null = null;

    get formattedCurrentDate() {
        return this.formattedDate(this.curPointInTime);
    }

    get filteredOldLanduses() {
        if (this.oldLanduseSearch != "") {
            return this.swappableLanduses.filter((landuse) =>
                landuse.description ? landuse.description.search(this.oldLanduseSearch) : false
            );
        }
        return this.swappableLanduses;
    }

    private get dateRange() {
        if (!this.updateDates)
            return {
                plantingMin: null,
                plantingMax: null,
                harvestMin: null,
                harvestMax: null,
            };
        //
        const plots = this.curPlot ? [...this.curPlots, this.curPlot] : this.curPlots;
        let maxPlotStart: Date | null = null,
            minPlotEnd: Date | null = null;
        //
        plots.forEach((fPlot) => {
            if (!maxPlotStart || fPlot.fromDate > maxPlotStart) maxPlotStart = fPlot.fromDate;
            if (!minPlotEnd || fPlot.toDate < minPlotEnd) minPlotEnd = fPlot.toDate;
        });
        //
        if (
            !this.curConfiguration?.CONSTRAINTS_DECLS_TO_PLOTS ||
            this.curConfiguration.CONSTRAINTS_DECLS_TO_PLOTS === "TRUE"
        ) {
            return {
                plantingMin: maxPlotStart ? new Date((maxPlotStart as Date).getTime() + 1) : null,
                plantingMax: minPlotEnd ? new Date((minPlotEnd as Date).getTime() - 1) : null,
                harvestMin: this.newFromDate,
                harvestMax: minPlotEnd ? new Date((minPlotEnd as Date).getTime() - 1) : null,
            };
        }
        const harvestMin = maxPlotStart ? new Date((maxPlotStart as Date).getTime() + 1) : null;
        return {
            plantingMin: null,
            plantingMax: minPlotEnd ? new Date((minPlotEnd as Date).getTime() - 1) : null,
            harvestMin:
                this.newFromDate && (!harvestMin || harvestMin < new Date(this.newFromDate))
                    ? this.newFromDate
                    : harvestMin,
            harvestMax: null,
        };
    }

    private get isPermanent() {
        return this.newLanduse?.landUseClass.permanent;
    }

    private mandatoryRuleAtomic = (v: unknown) => !!v || this.i18n("valid.mandatory-field");

    private plantingDateGreaterThanPlotDateRule(e: any | null): string | null {
        let curDate = e;
        if (e && typeof e.getMonth !== "function") {
            curDate = new Date(e.substring(6), e.substring(3, 5) - 1, e.substring(0, 2));
        }
        let res = null;
        if (curDate && this.dateRange.plantingMin && curDate.getTime() < this.dateRange.plantingMin.getTime()) {
            res = this.i18n("planting-date-greater-than-plot-date").toString();
        }
        return res;
    }

    private harvestingDateLesserThanPlotDateRule(e: any | null): string | null {
        let curDate = e;
        if (e && typeof e.getMonth !== "function") {
            curDate = new Date(e.substring(6), e.substring(3, 5) - 1, e.substring(0, 2));
        }
        let res = null;
        if (curDate && this.dateRange.harvestMax && curDate.getTime() > this.dateRange.harvestMax.getTime()) {
            res = this.i18n("harvesting-date-lesser-than-plot-date").toString();
        }
        return res;
    }

    @Watch("oldLanduse")
    async onLanduseChange() {
        if (this.oldLanduse === null) {
            this.newLandusesRawValues = [];
        } else {
            this.triggernewLandusesearch();
        }
    }

    private async getLandUseLandCover() {
        if (!this.curCropPlan || !this.oldLanduse) return;
        return await this.singleCropPlanModule.plotApi.getLandUseLandCover(
            this.business.businessId,
            this.curCropPlan.cropPlanId,
            this.oldLanduse.code
        );
    }

    private async getAvailableLanduses(landCoverCode: string) {
        if (!this.curCropPlan) return;
        const availableLanduses = await this.singleCropPlanModule.plotApi.getLandUses(
            this.business.businessId,
            this.curCropPlan.cropPlanId,
            this.curPointInTime,
            this.newLanduseSearch,
            [landCoverCode]
        );
        return availableLanduses;
    }

    private async sendSwapToServer() {
        if (this.updateDates) {
            (this.plantingDateInput as any).runInputRules();
            (this.harvestDateInput as any).runInputRules();
        }
        if (this.oldLanduse === null) this.oldLanduseInput.runRules();
        else if (this.newLanduse === null) this.newLanduseInput.runRules();
        else if (this.form.validate() && this.curCropPlan) {
            try {
                await this.singleCropPlanModule.cropPlanApi.swapLanduses(
                    this.business.businessId,
                    this.curCropPlan.cropPlanId,
                    this.curCouncil.domainZoneId,
                    this.oldLanduse.code,
                    this.newLanduse.code,
                    this.curPointInTime,
                    this.oldLanduse.declarationFromDate,
                    this.newFromDate,
                    this.newToDate
                );
                this.$emit("swap");
            } catch (error) {
                const errorCode = (error as any).response?.data?.errorCode;
                let errorMessage: string | null = null;
                if (errorCode)
                    switch (errorCode) {
                        case "PLOT_NOT_EMPTY_AT_NEW_DECL_DATES_EXCEPTION":
                            errorMessage = this.i18n("swap-landuse-error-plot-notempty-date").toString();
                            break;
                        case "ONLY_ONE_NEW_DATE_PROVIDED_EXCEPTION":
                            errorMessage = this.i18n("swap-landuse-error-date-missing").toString();
                            break;
                        case "INVALID_DECLARATION_DATES_EXCEPTION":
                            errorMessage = this.i18n("swap-landuse-error-dates-invalid").toString();
                            break;
                    }
                if (errorMessage) this.toast(errorMessage, { type: "error", duration: 4000 });
            }
        }
    }

    @Watch("newLanduseSearch")
    @Debounce(300)
    private async triggernewLandusesearch() {
        if (this.oldLanduse !== null) {
            this.newLandusesLoading = true;
            this.newLandusesPage = new EmptyMaxPagedResults();
            const landCover = await this.getLandUseLandCover();
            if (!landCover) return;
            const page = await this.getAvailableLanduses(landCover.landCoverCode);
            /* if (page.count === 1 && this.newLanduseSearch === page.records[0].description) {
                const res = page.records[0];
                page = await this.getAvailableLanduses(landuseDetails.landUseClass.landUseClassCode);
                page.records = page.records.filter((l) => l.code !== res.code);
                page.records.unshift(res);
            } */
            if (page) this.newLandusesPage = page;
            this.newLandusesLoading = false;
        }
    }

    private updateNewLanduse(value: LandUse) {
        this.newLanduse = value;
    }

    @Watch("newFromDate")
    private onNewFromDateUpdate() {
        if (this.newFromDate == null || (this.newToDate && this.newFromDate >= this.newToDate)) this.newToDate = null;
    }

    @Watch("newLanduse")
    private onNewLanduseSelection() {
        if(this.newLanduse)
        {
            toDateFromFormat(this.newLanduse, ["defaultFromDate"]);

            if(this.newLanduse.defaultFromDate !== null)
            {
                this.newFromDate = this.newLanduse.defaultFromDate;
                if(this.newLanduse.defaultHarvestDays !== null)
                    this.newToDate = new Date(this.newFromDate.getTime() + (1000 * 60 * 60 * 24) * this.newLanduse.defaultHarvestDays);
            }
        }
    }
}
</script>

<style lang="scss">
.single-cp-map-sidebar-modal {
    @apply w-full bg-bg-100 h-full absolute top-0 left-0;
}

.single-cp-map-sidebar-modal-close,
.single-cp-map-sidebar-modal-back {
    @apply transition duration-200 ease-in-out text-text;
    @apply flex justify-center items-center;
    width: 28px;
    height: 28px;
    outline: none !important;
}
.single-cp-map-sidebar-modal-close {
    border-radius: 50px;
}
.single-cp-map-sidebar-modal-back {
    @apply rounded-sm;
    width: 38px;
    height: 34px;
}
.single-cp-map-sidebar-modal-close i,
.single-cp-map-sidebar-modal-back i {
    @apply text-secondary-500;
}
.single-cp-map-sidebar-modal-close i {
    font-size: 18px;
}
.single-cp-map-sidebar-modal-back i {
    font-size: 14px;
}
.single-cp-map-sidebar-modal-close {
    margin-right: 8px;
}
.single-cp-map-sidebar-modal-close:hover,
.single-cp-map-sidebar-modal-back:hover {
    @apply bg-bg-500;
}
</style>
