<template>
    <div>
        <div class="absolute top-0 right-0 z-20">
            <div class="gis-info-panel px-4 py-3 text-sm rounded">
                <div class="title mb-2 pb-2 font-semibold border-b items-baseline">
                    <em class="fal fa-circle-info"></em>
                    <span>{{ i18n("gis-info") }}</span>
                </div>
                <div class="instructions mb-2">
                    {{ i18n("gis-instructions") }}
                </div>
                <abc-button @click="$emit('close')" class="gis-info-close-button">
                    {{ i18n("close") }}
                </abc-button>
            </div>
        </div>

        <transition
            name="custom-classes-transition"
            enter-active-class="animate__animated animate__fadeInUp animate__faster"
            leave-active-class="animate__animated animate__fadeOutDown animate__faster"
            mode="out-in"
        >
            <div
                v-if="data"
                :style="`height: ${data ? panelHeight : 0}px`"
                class="w-full absolute bottom-0 bg-bg-100 z-50"
            >
                <div class="flex w-full h-full">
                    <abc-tabs v-model="selectedTab" right-tools class="gis-info-tabs">
                        <template #tabs>
                            <abc-tab v-for="(layer, i) in data" :key="`tab-${i}`" :id="`tab-${i}`">
                                <div class="w-full h-full p-4">{{ layer.title }}</div>
                            </abc-tab>
                        </template>
                        <div
                            v-for="(layer, i) in data"
                            :key="`tab-${i}`"
                            v-show="selectedTab == `tab-${i}`"
                            class="w-full"
                        >
                            <div v-for="(card, k) in layer.cards" :key="`card-${i}-${k}`" class="gis-card">
                                <div class="head flex justify-between items-center">
                                    <div class="text-xl font-bold">{{ card.title }}</div>
                                    <abc-tool-button
                                        v-if="card.mbr"
                                        @click="$emit('zoomOnMbr', card.mbr)"
                                        class="location-btn"
                                    >
                                        <em class="fal fa-location-dot"></em>
                                    </abc-tool-button>
                                </div>
                                <div v-if="card.fields" class="body">
                                    <div class="flex">
                                        <div class="w-4/5">
                                            <div
                                                v-for="(field, f) in card.fields"
                                                :key="`field-${i}-${k}-${f}`"
                                                class="flex"
                                            >
                                                <div class="w-60 pr-1 text-label-primary">{{ field.label }}</div>
                                                <div>{{ field.value }}</div>
                                            </div>
                                        </div>
                                        <div v-if="card.areaSqm !== null" class="w-1/5 text-right">
                                            <span class="font-bold text-3xl pr-1" style="font-size: 26px">{{
                                                formattedArea(card.areaSqm)
                                            }}</span>
                                            <span class="text-base">{{ areaLabel() }}</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <template #right>
                            <abc-tool-button @click="data = null" class="close-button">
                                <em class="fal fa-xmark"></em>
                            </abc-tool-button>
                        </template>
                    </abc-tabs>
                </div>
            </div>
        </transition>
    </div>
</template>

<script lang="ts">
import { Prop, Component, Inject, Watch, Mixins } from "vue-property-decorator";
import { TranslateResult } from "vue-i18n";
import Map from "ol/Map";
import MapBrowserEvent from "ol/MapBrowserEvent";
import { FromStore, ToastOptions } from "@abaco/web-common/src/app";
import GenericLayer from "@abaco/iacs-map-module/src/modules/map-module/Layer/GenericLayer";
import SingleCropPlanModule, { MODULE_ID } from "../..";
import AreaUtils from "../../mixins/AreaUtils";
import { GisInfo as GisInfoDef } from "../../models/Layer";
import { Business } from "../../models/Business";
import { Council } from "../../models/Council";
import { CropPlan } from "../../models/CropPlan";

@Component
export default class GisInfo extends Mixins(AreaUtils) {
    @Inject() i18n!: (key: string, values?: unknown) => TranslateResult;
    @Inject(MODULE_ID) singleCropPlanModule!: SingleCropPlanModule;
    @Inject() toast!: (message: string, options?: ToastOptions) => TranslateResult;

    @FromStore(MODULE_ID) business!: Business | null;
    @FromStore(MODULE_ID) curCropPlan!: CropPlan | null;
    @FromStore(MODULE_ID) curCouncil!: Council | null;
    @FromStore(MODULE_ID) curPointInTime!: Date;

    @Prop() map!: Map;
    @Prop() additionalLayers!: GenericLayer[];

    private panelHeight = 360;

    private selectedTab: string | null = null;

    private data: GisInfoDef[] | null = null;

    mounted() {
        this.map.on("click", this.getPointInfo);
    }

    beforeDestroy() {
        this.$emit("panelHeightUpdated", 0);
        this.map.un("click", this.getPointInfo);
    }

    private async getPointInfo(e: MapBrowserEvent<any>) {
        if (
            e.type == "click" &&
            this.business?.businessId &&
            this.curCropPlan?.cropPlanId &&
            this.curCouncil?.domainZoneId
        ) {
            const res = await this.singleCropPlanModule.layerApi.getGisInfo(
                this.business?.businessId,
                this.curCropPlan?.cropPlanId,
                this.curCouncil?.domainZoneId,
                e.coordinate,
                this.curPointInTime,
                this.additionalLayers
                    .filter((l) => l.layerDef.on && l.layerDef.code)
                    .map((l) => l.layerDef.code as string)
            );
            this.data = res.length ? res : null;

            if (this.data) this.selectedTab = "tab-0";
            else this.toast(this.i18n("no-information-available").toString());
        }
    }

    @Watch("data")
    private onDataUpdate() {
        this.$emit("panelHeightUpdated", this.data ? this.panelHeight : 0);
    }
}
</script>

<style lang="scss" scoped>
.gis-info-panel {
    width: 220px;
    margin-top: 6px;
    margin-right: 6px;
    background: rgba(10, 10, 10, 0.45);
    backdrop-filter: blur(10px);
    color: rgba(255, 255, 255, 0.7);
    > .title,
    > .instructions {
        @apply flex items-center gap-2;
    }
    > .title {
        border-color: rgba(255, 255, 255, 0.2);
    }
    > .instructions {
        color: rgba(255, 255, 255, 0.8);
    }
    .gis-info-close-button {
        width: 100%;
        margin-left: 0;
        margin-right: 0;
        padding-top: 0.2rem;
        padding-bottom: 0.2rem;
        justify-content: center !important;
        color: rgba(255, 255, 255, 0.8);
        background: rgba(255, 255, 255, 0.1);
    }
}
.gis-info-tabs {
    .close-button {
        width: 2.5rem;
        min-width: 2.5rem;
        height: 2.5rem;
        margin: 0;
        padding: 0;
        border: 0;
        border-radius: 0;
    }
    .gis-card {
        margin: 1rem;
        border: 1px solid var(--color-border);
        border-radius: 8px;
        > .head {
            padding: 0.8rem 1rem;
            border-bottom: 1px solid var(--color-border);
            .location-btn {
                min-width: 2.5rem;
                min-height: 2.5rem;
            }
        }
        > .body {
            padding: 0.8rem 1rem;
            > div {
                &:not(:last-child) {
                    padding-bottom: 0.8rem;
                    margin-bottom: 0.8rem;
                    border-bottom: 1px solid var(--color-border);
                }
            }
        }
    }
}
</style>
