<template>
    <!-- PRINT MODAL -->
    <abc-modal 
        :title="i18n('lot.print.button')" 
        @close="$emit('close')" 
        :additionalStyle="{ 'z-index': 52 }"
        :forceModal="isLoading"
    >
        <template #body>
            <div v-if="isLoading" class="w-50 py-3 px-24 flex flex-col">
                <abc-loader :size="40" /><span>{{ i18n("printing") }}</span>
            </div>
            <abc-table v-else :items="curCropPlan.cropPlanPrints" :disableSelectOnClick="true">
                <template #items="{ item }">
                    <td>{{ item.description }}</td>
                    <td>
                        <abc-button isIcon @click="print(item.code, item.description)"
                            ><em class="abc-icon abc-icon-printer text-sm text-white"></em
                        ></abc-button>
                    </td>
                </template>
            </abc-table>
        </template>
    </abc-modal>
</template>

<script lang="ts">
import { Component, Inject, Mixins } from "vue-property-decorator";
import { TranslateResult } from "vue-i18n";
import { FromStore } from "@abaco/web-common/src/app";
import SingleCropPlanModule, { MODULE_ID } from "../..";
import { CropPlan } from "../../models/CropPlan";
import { Business } from "../../models/Business";
import DateUtils from "../../mixins/DateUtils";
import { ToastOptions } from "@abaco/web-common/src/app/Toasted";

@Component
export default class PrintModal extends Mixins(DateUtils) {
    @Inject() i18n!: (key: string, values?: unknown) => TranslateResult;
    @Inject(MODULE_ID) singleCropPlanModule!: SingleCropPlanModule;
    @Inject() toast!: (message: string, options?: ToastOptions) => TranslateResult;

    @FromStore(MODULE_ID) curPointInTime!: Date | null;
    @FromStore(MODULE_ID) curCropPlan!: CropPlan | null;
    @FromStore(MODULE_ID) business!: Business | null;

    private isLoading = false;

    private async print(code: string, description: string) {
        if (!this.business || !this.curCropPlan || !this.curPointInTime) return;
        this.isLoading = true;
        try {
            const printId = await this.singleCropPlanModule.cropPlanApi.printRequest(
                this.business.businessId,
                this.curCropPlan.cropPlanId,
                code,
                this.formattedDateWithFormat(this.curPointInTime, "yyyyMMdd")
            );
            if (!printId) return;
            await this.pollingPrintStatus(printId, description);
        } catch (error) {
            if ((error as any).response?.data?.message)
                this.toast((error as any).response.data.message, { type: "error" });
        }
        this.isLoading = false;
    }

    private async pollingPrintStatus(printId: string, description: string) {
        if (!this.business || !this.curCropPlan) return;
        try {
            const status = await this.singleCropPlanModule.cropPlanApi.printStatus(
                this.business.businessId,
                this.curCropPlan?.cropPlanId,
                printId
            );
            if (status.printProgressStatus === "COMPLETED" && !status.withErrors) {
                const [data, ext] = await this.singleCropPlanModule.cropPlanApi.getFile(
                    this.business.businessId,
                    this.curCropPlan?.cropPlanId,
                    printId
                );
                if (!data) 
                    return;
                //File download
                const href = URL.createObjectURL(data);
                const link = document.createElement("a");
                link.href = href;
                const date = new Date();
                link.setAttribute(
                    "download",
                    `${description.trim()} - ${this.formattedDateWithFormat(
                        date,
                        "yyyyMMdd"
                    )}_${date.getHours()}${date.getMinutes()}${date.getMilliseconds()}.${ext}`
                );
                document.body.appendChild(link);
                link.click();
                document.body.removeChild(link);
                URL.revokeObjectURL(href);
            } else if (status.printProgressStatus === "IN_PROGRESS") {
                await new Promise((resolve) => setTimeout(resolve, 10000));
                await this.pollingPrintStatus(printId, description);
            } else {
                this.toast(this.i18n("crop-plan-not-published-info").toString(), { type: "error" });
            }
        } catch (error) {
            if ((error as any).response?.data?.message)
                this.toast((error as any).response.data.message, { type: "error" });
        }
    }
}
</script>

<style lang="scss" scoped>
.icon {
    height: 42px;
    width: 42px;
}

.error {
    background-color: var(--danger-50);
    i {
        color: var(--danger-600);
    }
}
</style>
