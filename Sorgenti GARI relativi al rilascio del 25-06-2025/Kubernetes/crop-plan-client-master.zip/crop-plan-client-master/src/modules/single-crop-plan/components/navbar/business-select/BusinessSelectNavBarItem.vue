<template>
    <fragment>
        <div v-if="lockedBusinessId" class="abc-nav-bar-item fake w-full md:w-auto no-select mb-1 md:mb-0 ml-0 md:ml-3">
            <div class="flex flex-grow">
                <div class="abc-nav-bar-item-icon">
                    <em class="abc-icon abc-icon-member mr-1"></em>
                </div>
                <div class="abc-nav-bar-item-text">
                    <p>{{ label }}</p>
                </div>
            </div>
        </div>
        <template v-else-if="!showCannotUseCropPlan">
            <nav-bar-item v-if="!autoSelectableBusiness" v-model="businessNavBarFilterOpen">
                <template #label>
                    <div />
                    <abc-nav-bar-item
                        v-abc-tooltip.hover.ds1000="i18n('select-farm')"
                        :opened="businessNavBarFilterOpen"
                    >
                        <template #icon>
                            <em class="abc-icon abc-icon-member mr-1" />
                        </template>
                        <p>{{ label }}</p>
                    </abc-nav-bar-item>
                </template>

                <abc-nav-bar-item-panel
                    v-if="businessNavBarFilterOpen"
                    style="min-height: 300px"
                    title="select-farm"
                    i18nKeys
                >
                    <abc-tabs v-model="selected" right-tools>
                        <template #tabs>
                            <!-- <abc-tab :id="0"
                                ><em class="abc-icon abc-icon-clock pr-1" />{{ i18n("last-used-farms") }}</abc-tab
                            > -->
                            <abc-tab :id="1"
                                ><em class="abc-icon abc-icon-folder mr-1" />{{ i18n("search-farm") }}</abc-tab
                            >
                        </template>
                        <template #right>
                            <abc-tool-button
                                v-if="business"
                                :is-disabled="!business"
                                class="my-2 mr-2 single-cp-remove-business-button"
                                :title="i18n('cancel-selection')"
                                is-secondary
                                @click="onCancel"
                            >
                                <em class="abc-icon abc-icon-trash-bin"></em>
                            </abc-tool-button>
                        </template>
                        <div class="w-full h-full">
                            <last-used-businesses
                                v-if="selected === 0"
                                @select="setCurrentBusiness"
                                @changeTab="selected = 1"
                                :reset="resetFilter"
                                class="w-full pt-8"
                            />
                            <div v-show="selected === 1" class="h-full w-full flex flex-col overflow-hidden">
                                <search-business-criteria :reset-filter="resetFilter" v-model="filter" />
                                <search-business-results
                                    :filter="filter"
                                    @select="setCurrentBusiness"
                                    :triggerLoad="triggerLoad"
                                />
                            </div>
                        </div>
                    </abc-tabs>
                </abc-nav-bar-item-panel>
            </nav-bar-item>
            <nav-bar-item v-else>
                <template #label>
                    <div
                        class="text-brand-black-500 font-semibold abc-business-label border-t border-brand-black-500"
                        @click="openBusinessDetail"
                    >
                        {{ autoSelectableBusiness.description }}
                    </div>
                </template>
            </nav-bar-item>
            <abc-loader v-if="loading" scope="fixed" />
        </template>
    </fragment>
</template>

<script lang="ts">
import { Vue, Component, Inject, Watch } from "vue-property-decorator";
import { TranslateResult } from "vue-i18n";
import { FromStore } from "@abaco/web-common/src/app";
import SearchBusinessCriteria from "./SearchBusinessCriteria.vue";
import SearchBusinessResults from "./SearchBusinessResults.vue";
import LastUsedBusinesses from "./LastUsedBusinesses.vue";
import { Business } from "../../../models/Business";
import SingleCropPlanModule, { MODULE_ID } from "../../..";
import { CropPlan, CropPlanType } from "../../../models/CropPlan";
import SSOModule, { MODULE_ID as SSO_MODULE_ID } from "@abaco/sso-web-module/src/abaco-module/index";

@Component({
    components: {
        SearchBusinessCriteria,
        SearchBusinessResults,
        LastUsedBusinesses,
    },
})
export default class BusinessSelectNavBarItem extends Vue {
    @Inject(MODULE_ID) singleCropPlanModule!: SingleCropPlanModule;
    @Inject(SSO_MODULE_ID) ssoWebModule!: SSOModule;

    @FromStore(MODULE_ID) lockedBusinessId!: string | null;
    @FromStore(MODULE_ID) businessNavBarFilterOpen!: boolean;
    @FromStore(MODULE_ID) cropPlanNavbarFilterOpen!: boolean;
    @FromStore(MODULE_ID) business!: Business | null;
    @FromStore(MODULE_ID) availableCropPlanTypes!: CropPlanType[];
    @FromStore(MODULE_ID) editEnabled!: boolean;
    @FromStore(MODULE_ID) deleteEnabled!: boolean;
    @FromStore(MODULE_ID) curCropPlan!: CropPlan | null;
    @FromStore(MODULE_ID) showCannotUseCropPlan!: boolean;
    @FromStore(MODULE_ID) showCannotUseCropPlanForThisBusiness!: boolean;
    @FromStore(SingleCropPlanModule.MODULE_ID) autoSelectBusiness!: boolean;
    @FromStore(SingleCropPlanModule.MODULE_ID) autoSelectableBusiness!: Business | null;

    @Inject() i18n!: (key: string, values?: unknown) => TranslateResult;

    private selected = 0;
    private filter = "";
    private triggerLoad = 0;
    private loading = false;
    private resetFilter = 0;

    async mounted() {
        this.businessNavBarFilterOpen = false;

        // init business if ID passed via URL
        if (!this.business && this.lockedBusinessId) {
            this.loading = true;
            const business = await this.singleCropPlanModule.businessApi.getBusiness(this.lockedBusinessId);
            if (business) this.setCurrentBusiness(business);
            this.loading = false;
        }

        if (!this.business) this.autoSelectIfOnlyOne();
    }

    get label(): TranslateResult {
        if (!this.business) return this.i18n("select-farm");
        //
        const segments = [];
        if (this.business.description) segments.push(this.business.description);
        if (this.business.code) segments.push(this.business.code);
        return segments.reduce((out, item, index) => out + (index > 0 ? " - " : "") + item, "");
    }

    onCancel() {
        this.business = null;
        this.businessNavBarFilterOpen = false;
    }

    @Watch("businessNavBarFilterOpen")
    onOpen() {
        if (this.businessNavBarFilterOpen) {
            this.selected = 1;
        }
    }

    @Watch("selected")
    onTabChange() {
        this.triggerLoad += 1;
    }

    private setCurrentBusiness(business: Business | null) {
        this.showCannotUseCropPlanForThisBusiness = false;
        this.curCropPlan = null;
        this.business = business;
        this.businessNavBarFilterOpen = false;
        this.cropPlanNavbarFilterOpen = !!this.business;
        if (business) {
            this.singleCropPlanModule.businessApi.setLastUsedBusiness(business.businessId);
        }
    }

    private async autoSelectIfOnlyOne() {
        this.loading = true;
        const cuaa = this.$route.query.CUAA;
        try {
            if (cuaa && !Array.isArray(cuaa)) {
                const res = await this.singleCropPlanModule.businessApi.getBusinesses(cuaa);
                if (res.count === 1 && res.records.length) {
                    this.business = res.records[0];
                    this.businessNavBarFilterOpen = false;
                    this.cropPlanNavbarFilterOpen = true;
                }
            }
            if (!this.business && !this.showCannotUseCropPlan) {
                this.businessNavBarFilterOpen = true;
            }
        } catch (error) {
            console.error(error);
        } finally {
            this.loading = false;
        }
    }

    @Watch("business")
    private async doSelectBusiness(business: Business) {
        if (business) {
            [this.availableCropPlanTypes, this.editEnabled, this.deleteEnabled] = await Promise.all([
                this.singleCropPlanModule.cropPlanApi.getCropPlanTypes(business.businessId),
                this.ssoWebModule.isFunctionEnabled("CRPL", "CAN_EDIT_CROPPLAN_DESC"),
                this.ssoWebModule.isFunctionEnabled("CRPL", "CAN_DELETE_CROPPLAN"),
            ]);
        }
    }
}
</script>

<style lang="scss">
.abc-business-label {
    @apply flex items-center justify-start cursor-pointer;
    border-color: theme("colors.brand-black.500");
    padding: 5px 12px;
    min-width: 100px;
    font-size: 12px;
    border-bottom-left-radius: 4px;
    border-bottom-right-radius: 4px;
}
.abc-business-label:hover {
    background: rgba(255, 255, 255, 0.25);
}
.single-cp-remove-business-button.abc-tool-button {
    min-height: 34px;
    height: 34px;
}
.abc-nav-bar-item.fake {
    pointer-events: none;
}
</style>
