<template>
    <abc-modal v-if="value" @close="close" isMessage>
        <template #body>
            <div class="flex flex-col items-center justify-center">
                <div class="fa-stack text-danger-500" style="font-size: 28px">
                    <template v-if="editabilityCheck === '!EDITABLE'">
                        <em class="fas fa-circle fa-stack-2x text-danger-100"></em>
                        <em class="abc-icon abc-icon-pen text-label-primary fa-stack-1x"></em>
                        <em class="fal fa-horizontal-rule fa-stack-1x transform rotate-45"></em>
                    </template>
                    <template v-if="editabilityCheck === 'NOT_EDITABLE'">
                        <em class="fas fa-circle fa-stack-2x text-danger-100"></em>
                        <em class="fal fa-wheat text-label-primary fa-stack-1x"></em>
                        <em class="fal fa-horizontal-rule fa-stack-1x transform rotate-45"></em>
                    </template>
                </div>

                <p v-if="editabilityCheck === '!EDITABLE'" class="pt-4 text-lg px-6">
                    {{ i18n("cannot-edit-plot-geometry") }}
                </p>
                <p v-if="editabilityCheck === 'NOT_EDITABLE'" class="pt-4 text-lg px-6">
                    {{ i18n("cannot-edit-plot-declaration") }}
                </p>
            </div>
        </template>
        <template #footer>
            <abc-button @click="close" isSecondary isOutlined>
                <em class="abc-icon abc-icon-arrow-left-round" />
                <p>{{ i18n("cancel") }}</p></abc-button
            >
            <abc-button @click="deselectAndClose"> {{ i18n("deselect-not-editable-and-close") }}</abc-button>
        </template>
    </abc-modal>
</template>

<script lang="ts">
import { Prop, Component, Vue, Inject } from "vue-property-decorator";
import { TranslateResult } from "vue-i18n";
import { FromStore } from "@abaco/web-common/src/app";
import SingleCropPlan from "../..";
import { Plot } from "../../models/Plot";

@Component
export default class CropPlanCanNotEditModalWarning extends Vue {
    @Inject() i18n!: (key: string, values?: unknown) => TranslateResult;

    @Prop({ type: Boolean }) value!: boolean;
    @Prop() editabilityCheck!: "NOT_EDITABLE" | "!EDITABLE";

    @FromStore(SingleCropPlan.MODULE_ID) curPlot!: Plot | null;
    @FromStore(SingleCropPlan.MODULE_ID) curPlots!: Plot[];

    private get nonEditablePlots() {
        let plots = this.curPlots;
        if (this.curPlot) {
            plots = plots.concat(this.curPlot);
        }
        if (this.editabilityCheck.startsWith("!")) {
            return plots.filter((p) => p.editability !== this.editabilityCheck.substring(1));
        }
        return plots.filter((p) => p.editability === this.editabilityCheck);
    }

    private deselectAndClose() {
        this.curPlots = this.curPlots.filter(
            (p) => !this.nonEditablePlots.map((np) => np.plotCode).includes(p.plotCode)
        );
        const isCurPlotNotEditable = this.nonEditablePlots.some((np) => np.plotCode === this.curPlot?.plotCode);
        if (isCurPlotNotEditable && this.curPlots.length) {
            this.curPlot = this.curPlots[0];
            this.curPlots = [...this.curPlots.slice(1)];
        } else if (isCurPlotNotEditable && this.curPlots.length === 0) {
            this.curPlot = null;
        }
        this.close();
    }

    private close() {
        this.$emit("input", false);
    }
}
</script>
