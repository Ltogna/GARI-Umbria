<template>
    <div div v-if="!isLoading" class="flex flex-col">
        <!-- PLANTING DATE -->
        <div class="flex w-full mb-4">
            <abc-date-input
                v-if="!hasPermanentCropData"
                class="w-4/12 px-2"
                :label="isPermanent ? i18n('pcf-label-planting-date') : i18n('planting-date-base')"
                :value="declarationDetail.fromDate"
                :rules="[mandatoryRuleAtomic, plantingDateGreaterThanPlotDateRule, plantingDateRangeRule]"
                :range-min="dateRange.plantingMin"
                :range-max="dateRange.plantingMax"
                hide-delete
                @input="updateFromDate"
                :info="
                    curPlot && curConfiguration.CONSTRAINTS_DECLS_TO_PLOTS == 'FALSE'
                        ? i18n('start-date') + ' ' + formattedDate(curPlot.fullRangeFromDate)
                        : ''
                "
                :is-disabled="!checkIfFieldIsEditable('FROM_DATE', isNew, declarationDetail.fromDate)"
                @error-status="onFieldError('FROM_DATE', declarationDetail.fromDate)"
            />

            <!-- SCOPED PLANTING DATE -->
            <div v-if="hasPermanentCropData" class="flex w-full">
                <abc-input
                    v-model="plantingDetailDate.day"
                    ref="date-day-input"
                    class="flex flex-col pl-2"
                    :label="i18n('vineyard-day')"
                    @input="updateDay"
                    is-numeric
                    mask="##"
                    :rules="!externalUvDeclarationLock && !readonly ? [dayRule] : []"
                    :is-disabled="!checkIfFieldIsEditable('DATE_DAY', isNew, plantingDetailDate.day)"
                    @error-status="onFieldError('DATE_DAY', plantingDetailDate.day)"
                />
                <abc-input
                    v-model="plantingDetailDate.month"
                    ref="date-month-input"
                    class="flex flex-col px-2"
                    :label="i18n('vineyard-month')"
                    @input="updateMonth"
                    is-numeric
                    mask="##"
                    :rules="!externalUvDeclarationLock && !readonly ? [monthRule] : []"
                    :is-disabled="!checkIfFieldIsEditable('DATE_MONTH', isNew, plantingDetailDate.month)"
                    @error-status="onFieldError('DATE_MONTH', plantingDetailDate.month)"
                />
                <abc-input
                    v-model="plantingDetailDate.year"
                    ref="date-year-input"
                    class="flex flex-col"
                    :label="i18n('vineyard-year')"
                    @input="updateYear"
                    is-numeric
                    mask="####"
                    :rules="!externalUvDeclarationLock && !readonly ? [yearRule] : []"
                    :is-disabled="!checkIfFieldIsEditable('DATE_YEAR', isNew, plantingDetailDate.year)"
                    @error-status="onFieldError('DATE_YEAR', plantingDetailDate.year)"
                />
            </div>
        </div>

        <!-- HARVEST DATE -->
        <div v-if="curConfiguration.DISABLE_PERMANENT_CROP_EXTIRPATION !== 'TRUE'" class="flex w-full mb-4">
            <abc-date-input
                v-if="!hasPermanentCropData || hasUprootingDate"
                v-model="declarationDetail.toDate"
                ref="to-date-input"
                class="w-4/12 px-2"
                :label="isPermanent || hasUprootingDate ? i18n('pcf-label-uprooting-date') : i18n('harvest-date-base')"
                :rules="[mandatoryRuleAtomic, harvestingDateLesserThanPlotDateRule, harvestingDateRangeRule]"
                :range-min="dateRange.harvestMin"
                :range-max="dateRange.harvestMax"
                :initial-date-ref="declarationDetail.fromDate"
                hide-delete
                :info="harvestDateTips"
                @input="(newVal) => defaultToDateIfPermanent(newVal)"
                :is-disabled="!checkIfFieldIsEditable('TO_DATE', isNew, declarationDetail.toDate)"
                @error-status="onFieldError('TO_DATE',  declarationDetail.toDate)"
            />
            <div v-if="hasPermanentCropData" class="w-4/12 px-2">
                <div v-if="hasUprootingDate">
                    <div class="mb-1"><label>&nbsp;</label></div>
                    <abc-button
                        @click="declarationDetail.toDate = new Date(9999, 11, 31)"
                        is-outlined
                        :is-disabled="
                            !checkIfFieldIsEditable('PERMANENT_DATA_TO_DATE', isNew, declarationDetail.toDate)
                        "
                    >
                        {{ i18n("pcf-button-cancel-uprooting-date") }}
                    </abc-button>
                </div>
                <div v-else>
                    <div class="mb-1"><label>&nbsp;</label></div>
                    <abc-button @click="showModalUprootingDate = true">{{
                        i18n("pcf-button-set-uprooting-date")
                    }}</abc-button>
                    <abc-modal
                        v-if="showModalUprootingDate"
                        :isMessage="true"
                        :forceModal="true"
                        @close="showModalUprootingDate = false"
                    >
                        <template #body>
                            <abc-date-input
                                :label="i18n('pcf-label-uprooting-date')"
                                v-model="tempUprootingDate"
                                :rangeMin="declarationDetail.fromDate"
                                :rangeMax="new Date(9999, 11, 31)"
                            />
                        </template>
                        <template #footer>
                            <abc-button
                                isSecondary
                                isOutlined
                                class="mx-2"
                                @click="
                                    showModalUprootingDate = false;
                                    tempUprootingDate = null;
                                "
                                >{{ i18n("cancel") }}</abc-button
                            >
                            <abc-button
                                class="mx-2"
                                @click="
                                    declarationDetail.toDate = tempUprootingDate;
                                    showModalUprootingDate = false;
                                    tempUprootingDate = null;
                                "
                                :isDisabled="tempUprootingDate === null"
                                >{{ i18n("save") }}</abc-button
                            >
                        </template>
                    </abc-modal>
                </div>
            </div>
        </div>
    </div>

    <!-- Loader -->
    <div v-else class="flex justify-center items-center h-12">
        <abc-loader :size="32" />
    </div>
</template>

<script lang="ts">
import { Component, Prop, Inject, Ref, Watch, Mixins } from "vue-property-decorator";
import { FromStore } from "@abaco/web-common/src/app";
import { Declaration, DeclarationOut, DeclarationSingleScopeDate } from "../../../models/Declaration";
import { TranslateResult } from "vue-i18n";
import { MODULE_ID } from "../../..";
import { Configuration } from "../../../models/CropPlan";
import { AbcDateInputExtended, AbcInputExtended } from "../../../models/AbcInputExtended";
import DateUtils from "../../../mixins/DateUtils";
import DeclFieldEditability from "../../../mixins/DeclFieldEditability";

@Component
export default class DateSection extends Mixins(DateUtils, DeclFieldEditability) {
    @Inject() i18n!: (key: string, values?: unknown) => TranslateResult;

    // ---------- States
    @FromStore(MODULE_ID) curConfiguration!: Configuration | null;
    @FromStore(MODULE_ID) curDeclaration!: Declaration | null;

    // ---------- Props
    @Prop() declarationDetail!: DeclarationOut;
    @Prop() minInsertableDate!: Date | null;
    @Prop() maxInsertableDate!: Date | null;
    @Prop() defaultHarvestDays!: number | null;
    @Prop({ type: Boolean, default: false }) hasPermanentCropData!: boolean;
    @Prop({ type: Boolean, default: false }) isLoading!: boolean;
    @Prop() isPermanent!: boolean;
    @Prop({ type: Boolean, default: false }) externalUvDeclarationLock!: boolean;
    @Prop({ default: false }) readonly!: boolean;
    @Prop({ default: false }) isNew!: boolean;

    // ---------- Planting inputs ref
    @Ref("date-day-input") dateDayInput!: AbcInputExtended;
    @Ref("date-month-input") dateMonthInput!: AbcInputExtended;
    @Ref("date-year-input") dateYearInput!: AbcInputExtended;
    // ---------- HARVEST inputs ref
    @Ref("to-date-input") toDateInput!: AbcDateInputExtended;
    // ---------- Locals
    private tempUprootingDate: Date | null = null;
    private showModalUprootingDate = false;
    private plantingDetailDate: DeclarationSingleScopeDate = {
        day: undefined,
        month: undefined,
        year: undefined,
    };

    mounted() {
        if (this.curDeclaration && this.curPlot) {
            if (!this.hasPermanentCropData) this.plantingDetailDate.year = this.curPlot.fullRangeFromDate.getFullYear();
            if (this.curDeclaration.fromDatePrecision.includes("M"))
                this.plantingDetailDate.month = this.curPlot.fullRangeFromDate.getMonth() + 1;
            if (this.curDeclaration.fromDatePrecision.includes("D"))
                this.plantingDetailDate.day = this.curPlot.fullRangeFromDate.getDate();
        }
        if (
            this.dateRange.plantingMin &&
            this.dateRange.plantingMax &&
            this.declarationDetail.fromDate &&
            (this.dateRange.plantingMin > this.declarationDetail.fromDate ||
                this.dateRange.plantingMax < this.declarationDetail.fromDate)
        ) {
            this.declarationDetail.fromDate = null;
        }
        if (this.curDeclaration?.fromDatePrecision?.includes("Y") && this.declarationDetail.fromDate) {
            this.plantingDetailDate.year = this.declarationDetail.fromDate.getFullYear();
        } else {
            this.shouldBeEditable.add("DATE_YEAR");
        }
        if (this.curDeclaration?.fromDatePrecision?.includes("M") && this.declarationDetail.fromDate) {
            this.plantingDetailDate.month = this.declarationDetail.fromDate.getMonth() + 1;
        } else {
            this.shouldBeEditable.add("DATE_MONTH");
        }
        if (this.curDeclaration?.fromDatePrecision?.includes("D") && this.declarationDetail.fromDate) {
            this.plantingDetailDate.day = this.declarationDetail.fromDate.getDate();
        } else {
            this.shouldBeEditable.add("DATE_DAY");
        }

        if (
            !this.declarationDetail.toDate &&
            this.isPermanent &&
            this.curConfiguration?.FORCE_DEFAULT_HARVEST_DATE_FOR_PERMANENT_DECL === "TRUE"
        )
            this.declarationDetail.toDate = this.defaultToDate;

        if (this.curDeclaration?.fromDate == null) this.shouldBeEditable.add("FROM_DATE");
        if (this.curDeclaration?.toDate == null) {
            this.shouldBeEditable.add("TO_DATE");
            this.shouldBeEditable.add("PERMANENT_DATA_TO_DATE");
        }
    }

    // ---------- Rules
    private mandatoryRuleAtomic = (v: unknown) => !!v || this.i18n("valid.mandatory-field");

    private plantingDateGreaterThanPlotDateRule(e: any | null): string | null {
        let curDate = e;
        if (e && typeof e.getMonth !== "function") {
            curDate = new Date(e.substring(6), e.substring(3, 5) - 1, e.substring(0, 2));
        }
        let res = null;
        if (curDate && this.minInsertableDate && curDate.getTime() < this.minInsertableDate.getTime()) {
            res = this.i18n("planting-date-greater-than-plot-date").toString();
        }
        return res;
    }

    private plantingDateRangeRule(e: any | null): string | null {
        let curDate = e;
        if (e && typeof e.getMonth !== "function") {
            curDate = new Date(e.substring(6), e.substring(3, 5) - 1, e.substring(0, 2));
        }
        let res = null;
        if (
            (curDate && this.dateRange.plantingMin && curDate < this.dateRange.plantingMin) ||
            (curDate && this.dateRange.plantingMax && curDate > this.dateRange.plantingMax)
        ) {
            res = this.i18n("date-out-range").toString();
        }
        return res;
    }

    private harvestingDateLesserThanPlotDateRule(e: any | null): string | null {
        let curDate = e;
        if (e && typeof e.getMonth !== "function") {
            curDate = new Date(e.substring(6), e.substring(3, 5) - 1, e.substring(0, 2));
        }
        let res = null;
        if (curDate && this.maxInsertableDate && curDate.getTime() > this.maxInsertableDate.getTime()) {
            res = this.i18n("harvesting-date-lesser-than-plot-date").toString();
        }
        return res;
    }

    private harvestingDateRangeRule(e: any | null): string | null {
        let curDate = e;
        if (e && typeof e.getMonth !== "function") {
            curDate = new Date(e.substring(6), e.substring(3, 5) - 1, e.substring(0, 2));
        }
        let res = null;
        if (
            (curDate && this.dateRange.harvestMin && curDate < this.dateRange.harvestMin) ||
            (curDate && this.dateRange.harvestMax && curDate > this.dateRange.harvestMax)
        ) {
            res = this.i18n("date-out-range").toString();
        }
        return res;
    }

    private dayRule(e: number | null): string | null {
        let res = null;

        // Check if plantig day is mandatory
        if(
            this.curConfiguration?.MANDATORY_PLANTING_DATE_PRECISION &&
            this.curConfiguration.MANDATORY_PLANTING_DATE_PRECISION.includes("D") &&
            e == null
        )
            return  this.i18n("valid.mandatory-field").toString();
        
        const daysInMonth = this.plantingDetailDate.month
            ? new Date(
                  this.plantingDetailDate.year ? this.plantingDetailDate.year : new Date().getFullYear(),
                  this.plantingDetailDate.month,
                  0
              ).getDate()
            : undefined;

        if (
            e &&
            daysInMonth &&
            this.plantingDetailDate.month &&
            this.plantingDetailDate.month <= 12 &&
            e > daysInMonth
        ) {
            res = this.i18n("invalid-day-month").toString();
        }

        if (e && e > 31) {
            res = this.i18n("invalid-day-number").toString();
        }

        if (
            e &&
            this.plantingDetailDate.month &&
            this.plantingDetailDate.year &&
            this.curPlot &&
            (!this.curConfiguration?.CONSTRAINTS_DECLS_TO_PLOTS ||
                this.curConfiguration?.CONSTRAINTS_DECLS_TO_PLOTS === "TRUE") &&
            this.calculateDate(this.plantingDetailDate.year, this.plantingDetailDate.month, e) <
                this.curPlot.fullRangeFromDate
        ) {
            res = this.i18n("invalid-year-number").toString();
        }

        return res;
    }

    private monthRule(e: number | null): string | null {
        let res = null;

        // Check if plantig month is mandatory
        if(
            this.curConfiguration?.MANDATORY_PLANTING_DATE_PRECISION &&
            this.curConfiguration.MANDATORY_PLANTING_DATE_PRECISION.includes("M") &&
            e == null
        )
            return  this.i18n("valid.mandatory-field").toString();

        if (!e && this.plantingDetailDate.day) {
            res = this.i18n("invalid_day_no_month").toString();
        }

        if (e && (e > 12 || e < 1)) {
            res = this.i18n("invalid_month_number").toString();
        }

        if (
            e &&
            this.plantingDetailDate.day &&
            this.plantingDetailDate.year &&
            this.curPlot &&
            (!this.curConfiguration?.CONSTRAINTS_DECLS_TO_PLOTS ||
                this.curConfiguration?.CONSTRAINTS_DECLS_TO_PLOTS === "TRUE") &&
            this.calculateDate(this.plantingDetailDate.year, e, this.plantingDetailDate.day) <
                this.curPlot.fullRangeFromDate
        ) {
            res = this.i18n("invalid-year-number").toString();
        }

        return res;
    }

    private yearRule(e: number | null): string | null {
        let res = null;
        
        // Check if plantig year is mandatory
        if(
            this.curConfiguration?.MANDATORY_PLANTING_DATE_PRECISION &&
            this.curConfiguration.MANDATORY_PLANTING_DATE_PRECISION.includes("Y") &&
            e == null
        )
            return  this.i18n("valid.mandatory-field").toString();
    
        if (
            e &&
            this.plantingDetailDate.day &&
            this.plantingDetailDate.month &&
            this.curPlot &&
            (!this.curConfiguration?.CONSTRAINTS_DECLS_TO_PLOTS ||
                this.curConfiguration?.CONSTRAINTS_DECLS_TO_PLOTS === "TRUE") &&
            this.calculateDate(e, this.plantingDetailDate.month, this.plantingDetailDate.day) <
                this.curPlot.fullRangeFromDate
        ) {
            res = this.i18n("invalid-year-number").toString();
        }

        if ((e && e < 1900) || (e && e > new Date().getFullYear())) {
            res = this.i18n("year-1900-and-over-required").toString();
        }

        if (e && e > new Date().getFullYear()) {
            res = this.i18n("year-over-cur-year").toString();
        }

        if (e && this.hasPermanentCropData && e > new Date().getFullYear()) {
            res = this.i18n("invalid-year-permanent-crop").toString();
        }

        if (
            e &&
            this.minInsertableDate &&
            this.curConfiguration &&
            this.curConfiguration.CONSTRAINTS_DECLS_TO_PLOTS &&
            this.curConfiguration?.CONSTRAINTS_DECLS_TO_PLOTS === "TRUE" &&
            this.calculateDate(
                e,
                this.plantingDetailDate.month ? this.plantingDetailDate.month : 1,
                this.plantingDetailDate.day ? this.plantingDetailDate.day : 1
            ).getTime() < this.minInsertableDate.getTime()
        ) {
            res = this.i18n("planting-date-greater-than-plot-date").toString();
        }

        return res;
    }

    // ---------- Computeds
    private get hasUprootingDate() {
        return (
            this.hasPermanentCropData &&
            this.declarationDetail.toDate &&
            this.declarationDetail.toDate < new Date(9999, 11, 31)
        );
    }

    private get dateRange() {
        const out =
            !this.curConfiguration?.CONSTRAINTS_DECLS_TO_PLOTS ||
            this.curConfiguration.CONSTRAINTS_DECLS_TO_PLOTS === "TRUE"
                ? {
                      plantingMin: this.curPlot ? new Date(this.curPlot.fullRangeFromDate.getTime() - 1) : null,
                      plantingMax: this.declarationDetail.toDate
                          ? this.declarationDetail.toDate
                          : this.curPlot?.fullRangeToDate ?? null,
                      harvestMin: this.declarationDetail.fromDate,
                      harvestMax: this.curPlot ? new Date(this.curPlot.fullRangeToDate.getTime() + 1) : null,
                  }
                : {
                      plantingMin: null,
                      plantingMax: this.declarationDetail.toDate
                          ? this.declarationDetail.toDate
                          : this.curPlot?.fullRangeToDate ?? null,
                      harvestMin: this.declarationDetail.fromDate,
                      harvestMax: null,
                  };
        // date range should have at least one day within the plot lifetime
        if (this.curPlot && out.plantingMin && out.plantingMin > this.curPlot.fullRangeToDate)
            out.plantingMin = this.curPlot.fullRangeToDate;
        if (this.curPlot && out.harvestMin && out.harvestMin < this.curPlot.fullRangeFromDate)
            out.harvestMin = this.curPlot.fullRangeFromDate;
        if (out.plantingMin && out.harvestMin && out.harvestMin < out.plantingMin) out.harvestMin = out.plantingMin;
        //
        return out;
    }

    private get harvestDateTips() {
        const plotEnd =
            this.curConfiguration?.CONSTRAINTS_DECLS_TO_PLOTS == "FALSE" && this.curPlot
                ? this.i18n("end-date") + " " + this.formattedDate(this.curPlot.fullRangeToDate)
                : "";
        const suggestedDate =
            this.curConfiguration?.HIDE_LAND_USE_DEFAULT_HARVEST_DATE !== "TRUE"
                ? !!this.defaultHarvestDays && this.declarationDetail.fromDate && this.suggestedHarvestDate
                    ? this.i18n("suggested-harvest-date") + " " + this.formattedDate(this.suggestedHarvestDate)
                    : this.defaultHarvestDays && this.defaultHarvestDays >= 0 && !this.declarationDetail.fromDate
                    ? this.i18n("suggested-harvest-days") + " " + this.defaultHarvestDays
                    : this.curPlot &&
                      this.declarationDetail.fromDate &&
                      this.declarationDetail.fromDate < this.curPlot.fullRangeFromDate
                    ? this.i18n("suggested-harvest-date") +
                      " " +
                      this.formattedDate(new Date(this.curPlot.fullRangeFromDate.getTime() + 1000 * 60 * 60 * 24))
                    : ""
                : "";
        return plotEnd + (plotEnd && suggestedDate ? " - " : "") + suggestedDate;
    }

    private get suggestedHarvestDate(): Date {
        if (!!this.defaultHarvestDays && this.declarationDetail.fromDate) {
            if (this.defaultHarvestDays === -1) {
                return this.curConfiguration?.CONSTRAINTS_DECLS_TO_PLOTS == "FALSE"
                    ? new Date(9999, 11, 31)
                    : this.curPlot?.fullRangeToDate || new Date(9999, 11, 31);
            }
            const newDate = new Date(this.declarationDetail.fromDate);
            newDate.setDate(newDate.getDate() + this.defaultHarvestDays);
            return newDate;
        } else {
            return new Date();
        }
    }

    private get defaultToDate() {
        if (this.curConfiguration?.FORCE_DEFAULT_HARVEST_DATE_FOR_PERMANENT_DECL !== "TRUE") return null;
        let newDate = this.dateRange.harvestMax ?? new Date(9999, 11, 31);
        if (this.declarationDetail.fromDate && this.defaultHarvestDays && this.defaultHarvestDays === -1) {
            newDate = this.declarationDetail.fromDate;
            newDate.setDate(newDate.getDate() + this.defaultHarvestDays);
        }
        return this.curPlot && this.curPlot.fullRangeToDate < newDate ? this.curPlot.fullRangeToDate : newDate;
    }
    // ---------- Methods
    private updateDay(e: number | null) {
        const daysInMonth = this.plantingDetailDate.month
            ? new Date(
                  this.plantingDetailDate.year ? this.plantingDetailDate.year : new Date().getFullYear(),
                  this.plantingDetailDate.month,
                  0
              ).getDate()
            : undefined;

        // Force run rules
        if (
            e &&
            this.plantingDetailDate.month &&
            this.plantingDetailDate.year &&
            this.curPlot &&
            (!this.curConfiguration?.CONSTRAINTS_DECLS_TO_PLOTS ||
                this.curConfiguration?.CONSTRAINTS_DECLS_TO_PLOTS === "TRUE") &&
            this.calculateDate(this.plantingDetailDate.year, this.plantingDetailDate.month, e) <
                this.curPlot.fullRangeFromDate
        ) {
            this.dateMonthInput.runRules(this.plantingDetailDate.month);
            this.dateYearInput.runRules(this.plantingDetailDate.year);
        }

        // Emit Update DatePicker
        if (e && daysInMonth && e <= daysInMonth && this.plantingDetailDate.year && this.plantingDetailDate.month) {
            this.updateFromDate(this.calculateDate(this.plantingDetailDate.year, this.plantingDetailDate.month, e));
        }

        if (!this.plantingDetailDate.month) {
            this.dateMonthInput.runRules(this.plantingDetailDate.month);
        }
    }

    private updateMonth(e: number | null) {
        if (!e) {
            this.plantingDetailDate.month = undefined;
        }

        // Force reset data and emit update DatePicker
        if (this.plantingDetailDate.day && this.declarationDetail.fromDate && !e) {
            this.plantingDetailDate.day = undefined;
            this.plantingDetailDate.month = undefined;
            this.updateFromDate(
                this.calculateDate(
                    this.plantingDetailDate.year
                        ? this.plantingDetailDate.year
                        : this.declarationDetail.fromDate.getFullYear(),
                    1,
                    this.plantingDetailDate.day ? this.plantingDetailDate.day : 1
                )
            );
        }

        // Force assign year (if it not exists) when month is entered
        if (e && e <= 12 && this.curDeclaration && !this.plantingDetailDate.year) {
            this.plantingDetailDate.year = this.curDeclaration.fromDate.getFullYear();
            this.dateYearInput.runRules(this.plantingDetailDate.year);
        }

        // Force run year rule
        // if (
        //     e &&
        //     this.plantingDetailDate.day &&
        //     this.plantingDetailDate.year &&
        //     this.curPlot &&
        //     (!this.curConfiguration?.CONSTRAINTS_DECLS_TO_PLOTS ||
        //         this.curConfiguration?.CONSTRAINTS_DECLS_TO_PLOTS === "TRUE") &&
        //     this.calculateDate(this.plantingDetailDate.year, e, this.plantingDetailDate.day) <
        //         this.curPlot.fullRangeFromDate
        // ) {
        //     // Only year's rules is called because on the bottom of this method the day ones is always called
        //     this.dateYearInput.runRules(this.plantingDetailDate.year);
        // }

        // Emit Update DatePicker
        if (e && this.plantingDetailDate.year) {
            this.updateFromDate(
                this.calculateDate(
                    this.plantingDetailDate.year,
                    e,
                    this.plantingDetailDate.day ? this.plantingDetailDate.day : 1
                )
            );
        }

        this.dateDayInput.runRules(this.plantingDetailDate.day);
    }

    private updateYear(e: number | null) {
        // Force reset data
        if (!e) {
            this.plantingDetailDate.day = undefined;
            this.plantingDetailDate.month = undefined;
            this.plantingDetailDate.year = undefined;
        }

        // Emit Update DatePicker
        if (e) {
            this.updateFromDate(
                this.calculateDate(
                    e,
                    this.plantingDetailDate.month ? this.plantingDetailDate.month : 1,
                    this.plantingDetailDate.day ? this.plantingDetailDate.day : 1
                )
            );
        }

        this.dateDayInput.runRules(this.plantingDetailDate.day);
        this.dateMonthInput.runRules(this.plantingDetailDate.month);
    }

    /**
     *  Emit on-update-from-date
     *  @param date well formatted date to pass to parent
     */
    private updateFromDate(date: Date) {
        this.$emit("on-update-from-date", date);
    }

    /**
     * This approach prevent mutate month since by passing number instead of string
     * the Date would start from index 0 (ie Jenuary is 0)
     */
    private calculateDate(year: number, month: number, day: number): Date {
        return new Date(`${year}-${month}-${day}`);
    }

    private defaultToDateIfPermanent(newVal: Date | null) {
        if (this.curConfiguration?.FORCE_DEFAULT_HARVEST_DATE_FOR_PERMANENT_DECL !== "TRUE" || !this.isPermanent)
            return;
        if (!newVal && this.defaultToDate) {
            this.declarationDetail.toDate = new Date(
                this.defaultToDate.getFullYear(),
                this.defaultToDate.getMonth(),
                this.defaultToDate.getDate()
            );
            setTimeout(() => {
                this.toDateInput.runInputRules();
            }, 300);
        }
    }

    private onFieldError(key: string, val: number) {
        const disableValued = this.curConfiguration?.DISABLE_VALUED_DECL_FIELDS_EDIT === 'TRUE' && val;
        if((this.curConfiguration?.DISABLE_VALID_VALUED_DECL_FIELDS_EDIT === 'TRUE' || disableValued) && !this.isNew) {
            this.pushToNotValidFields(key);
        }
        this.$forceUpdate(); // WORKAROUND: Need to force input componets rerender to update isDisabled property values
    }

    // ---------- Watches
    /**
     * Everytime plantingDetailDate change this component emit to his parent the current fromDatePrecision status (ie: YMD, YM, Y, -).
     */
    @Watch("plantingDetailDate", { deep: true })
    private generateFromDatePrecision() {
        let fromDatePrecision = "-";
        if (this.plantingDetailDate.day && this.plantingDetailDate.month && this.plantingDetailDate.year) {
            fromDatePrecision = "YMD";
        } else if (!this.plantingDetailDate.day && this.plantingDetailDate.month && this.plantingDetailDate.year) {
            fromDatePrecision = "YM";
        } else if (!this.plantingDetailDate.day && !this.plantingDetailDate.month && this.plantingDetailDate.year) {
            fromDatePrecision = "Y";
        }

        this.$emit("on-update-from-date-precision", fromDatePrecision);
    }

}
</script>

<style lang="scss" scoped></style>
