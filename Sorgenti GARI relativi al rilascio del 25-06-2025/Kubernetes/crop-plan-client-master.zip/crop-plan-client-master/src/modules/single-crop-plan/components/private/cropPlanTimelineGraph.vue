<template>
    <div class="flex flex-col w-full h-full" v-resize.300="onResize">
        <div class="flex w-full" style="height: 44px;">
            <div
                v-if="!disableTimelineDateChange"
                @click="changeYear('down')"
                class="cp-timeline border-r border-b"
                :style="headerStyle"
                :class="{ disabled: isChangeYearDisabled }"
            >
                <em class="fa fa-chevron-left" />
            </div>
            <div
                ref="cpTimelineHeader"
                class="flex border-b cursor-pointer"
                :style="{width: !disableTimelineDateChange ? 'calc(100% - 90px)' : '100%'}"
                @mouseover="isHeaderHovering = true"
                @mouseleave="isHeaderHovering = false"
                @click="onHeaderClick()"
            >
                <!-- <div class="flex border-b w-full"> -->
                <div
                    v-for="(e, i) in months"
                    :key="e"
                    class="cp-timeline-header-month"
                    :style="'width: ' + getMonthWidth(e) + 'px'"
                >
                    {{ i18n("month-l-short-" + e) }}
                    <p v-if="e === 1 && i !== 0" class="pl-2">
                        {{ realYear(e) }}
                    </p>
                </div>
            </div>
            <div
                v-if="!disableTimelineDateChange"
                @click="changeYear('up')"
                class="cp-timeline border-l border-b"
                :style="headerStyle"
            >
                <em class="fa fa-chevron-right" />
            </div>
        </div>
        <div class="flex w-full h-full">
            <div
                ref="cpTimelineContainer"
                class="flex mx-auto h-full relative"
                :style="{width: !disableTimelineDateChange ? 'calc(100% - 90px)' : '100%'}"
                @mouseover="isHovering = true"
                @mouseleave="isHovering = false"
            >
                <transition
                    name="custom-classes-transition"
                    enter-active-class="animate__animated animate__fadeIn animate__faster"
                    mode="out-in"
                >
                    <div v-if="isHovering" class="cp-timeline-cursor-bar" :style="cursorBarStyle" />
                </transition>
                <transition
                    name="custom-classes-transition"
                    enter-active-class="animate__animated animate__fadeIn animate__faster"
                    mode="out-in" 
                >
                    <div v-if="isHeaderHovering" class="cp-timeline-cursor-bar-header" :style="cursorBarStyle" />
                </transition>
                <transition
                    name="custom-classes-transition"
                    enter-active-class="animate__animated animate__fadeIn animate__faster"
                    mode="out-in"
                >
                    <div
                        v-if="isHovering || isHeaderHovering"
                        class="cp-timeline-cursor-counter flex flex-col cp-timeline-cursor-counter-header"
                        :style="cursorCounterStyle"
                    >
                        {{ cursorCounterValue }}
                    </div>
                    <div
                        v-else
                        class="cp-timeline-cursor-counter flex flex-col cp-timeline-cursor-counter-header"
                        :style="cursorCounterStyle"
                    >
                        {{ cursorCounterValue }}
                    </div>
                </transition>

                <div class="flex w-full h-full absolute top-0 left-0">
                    <div
                        v-for="e in months"
                        :key="e"
                        class="cp-timeline-month-divider flex border-l border-dashed mt-3 mb-4"
                        :style="'width: ' + getMonthWidth(e) + 'px'"
                    />
                </div>
                <div class="flex flex-col h-full w-full relative mt-3">
                    <CropPlanTimelineGraphPlotLine
                        key="crop_plan_timeline_graph_plot_line"
                        :left="getPlotLineLeft"
                        :width="getPlotLineWidth"
                        :events="getPlotLineEvents"
                    />
                    <div class="overflow-y-auto w-full relative" style="height: calc(100% - 0.75rem)">
                        <transition-group
                            name="custom-classes-transition"
                            enter-active-class="animate__animated animate__fadeInLeft30Px animate__faster"
                            leave-active-class="animate__animated animate__fadeOut animate__faster"
                            mode="out-in"
                            :title="i18n('current-point-in-time')"
                        >
                            <template v-if="curPlot">
                                <CropPlanTimelineGraphSection
                                    v-for="sectionUI in sectionsUI"
                                    @click="onRowClick(sectionUI, $event)"
                                    @hovering="section => setDisplaySecondaryCheckbox(section)"
                                    :active="curTimelineSection && curTimelineSection.id === sectionUI.id ? true : false"
                                    :plotArea="getPlotArea(sectionUI)"
                                    :key="sectionUI.id"
                                    :section="sectionUI"
                                    :percentage="sectionUI.percentage"
                                    :condensed="false"
                                    :top="getSectionTop(sectionUI)"
                                    :left="getSectionLeft(sectionUI)"
                                    :width="getSectionWidth(sectionUI)"
                                    :default-height="sectionDefaultHeight"
                                    :condensed-height="sectionDefaultHeight"
                                    :has-warning="isCurPlotWithWarning"
                                >
                                    <template #checkbox>
                                        <transition
                                            name="custom-classes-trantition"
                                            enter-active-class="animate__animated animate__fadeInLeft animate__faster"
                                            mode="out-in"
                                        >
                                            <div
                                                v-if="
                                                    ((displaySecondaryCheckbox === sectionUI.id &&
                                                            curTimelineSection &&
                                                            displaySecondaryCheckbox != curTimelineSection.id) ||
                                                            (curTimelineSection &&
                                                                curTimelineSections.find((p) => p.id === sectionUI.id)))
                                                "
                                                class="absolute bottom-0 left-0 top-0 z-10 s-cp-checkbox-container flex items-center justify-center"
                                            >
                                                <div
                                                    @click.stop="onRowCheckboxClick(sectionUI)"
                                                    class="cursor-default h-full flex items-center justify-center w-full bg-secondary-100"
                                                    :class="{
                                                        'cursor-not-allowed':
                                                            curTimelineSection  && curTimelineSection.id === sectionUI.id,
                                                    }"
                                                    style="
                                                        padding-left: 10px;
                                                        padding-right: 10px;
                                                        margin-bottom: -1px;
                                                    "
                                                >
                                                    <transition
                                                        name="custom-classes-transition"
                                                        enter-active-class="animate__animated animate__fadeIn animate__faster"
                                                        mode="out-in"
                                                    >
                                                        <abc-checkbox
                                                            is-list
                                                            :value="
                                                                curTimelineSections.find(s => s.id == sectionUI.id)
                                                            "
                                                        />
                                                    </transition>
                                                </div>
                                            </div>
                                        </transition>
                                    </template>
                                </CropPlanTimelineGraphSection>
                            </template>
                            <div
                                v-else
                                class="absolute inset-0 flex flex-col justify-around"
                                key="changing-point-container"
                            >
                                <hr key="add-line" />
                                <hr key="change-line" />
                                <hr key="delete-line" />
                                <crop-plan-timeline-changing-point
                                    v-for="changingPoint in changingPoints"
                                    :key="changingPoint.date.getTime()"
                                    :left="getChangingPointPosition(changingPoint)"
                                    :changingPoint="changingPoint"
                                    :curDate="curDate"
                                />
                            </div>
                            <CropPlanTimelineGraphLine
                                v-if="isCurDateTimeInRange && dateByPositionArray.length"
                                key="crop_plan_timeline_graph_line"
                                :left="getPointInTimeLineLeft"
                            />
                        </transition-group>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script lang="ts">
import { Prop, Component, Mixins, Inject, Watch } from "vue-property-decorator";
import { TranslateResult } from "vue-i18n";
import {
    ChangingPoint,
    TimelineArea,
    TimelineSection,
    TimelineSectionUI,
    toTimelineSectionUI,
} from "../../models/Declaration";
import CropPlanTimelineGraphSection from "./cropPlanTimelineGraphSection.vue";
import CropPlanTimelineGraphLine from "./cropPlanTimelineGraphLine.vue";
import CropPlanTimelineGraphPlotLine from "./cropPlanTimelineGraphPlotLine.vue";
import CropPlanTimelineChangingPoint from "./cropPlanTimelineChanginPoint.vue";
import { FromStore } from "@abaco/web-common/src/app";
import { MODULE_ID } from "../..";
import DateUtils from "../../mixins/DateUtils";
import { CropPlan } from "../../models/CropPlan";
import { isMacOs } from "../../api/Utils";
import PointInTimeChange from "../../mixins/PointInTimeChange";

@Component({
    components: {
        CropPlanTimelineGraphSection,
        CropPlanTimelineGraphLine,
        CropPlanTimelineGraphPlotLine,
        CropPlanTimelineChangingPoint,
    },
})
export default class CropPlanTimelineGraph extends Mixins(DateUtils, PointInTimeChange) {

    // @Ref("cpTimelineContainer") cpTimelineContainerHTML!: HTMLElement;
    // @Ref("cpTimelineHeader") cpTimelineHeaderHTML!: HTMLElement;

    @FromStore(MODULE_ID) curTimelineSection!: TimelineSection | null;
    @FromStore(MODULE_ID) isCurPlotWithWarning!: boolean;
    @FromStore(MODULE_ID) curPointInTime!: Date;
    @FromStore(MODULE_ID) curCropPlan!: CropPlan | null;
    @FromStore(MODULE_ID) curTimelineSections!: TimelineSection[];
    @FromStore(MODULE_ID) showConfirmDateChangeModal!: boolean;

    @Prop() curDate!: Date;
    @Prop() startDate!: Date;
    @Prop() headerHeight!: number;
    @Prop() sections!: TimelineSection[];
    @Prop() areas!: TimelineArea[];
    @Prop() changingPoints!: ChangingPoint[];

    private baseMonths = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12];
    private dayMS = 24 * 60 * 60 * 1000;
    private sectionDefaultHeight = 42;
    private sectionSpaceBetween = 0;
    private sectionCondensedHeight = 21;
    private maxElementsBeforeCondensed = 5;
    private sectionsUI: TimelineSectionUI[] = [];
    private mouseX = 0;
    private mouseY = 0;
    private isHeaderHovering = false;
    private isHovering = false;

    private positionsByDateMap: Record<number, { width: number; daysPosition: Record<number, number> }> = {};
    private monthByPositionArray: number[] = []; // position, month
    private dateByPositionArray: number[][] = []; // month, position - date
    private displaySecondaryCheckbox: number | null = null;
    private refDate: Date | null = this.curDate;

    @Watch("curDate")
    onRefDate() {
        this.currentDate = this.curDate;
    }

    private get isChangeYearDisabled() {
        if (this.pointInTimeRangeMin) {
            return (
                new Date(this.startDate.getFullYear(), this.startDate.getMonth(), this.startDate.getDate() - 1) <
                this.pointInTimeRangeMin
            );
        }
        return false;
    }

    private get currentDate() {
        return this.refDate;
    }

    private set currentDate(dt: Date | null) {
        this.refDate = dt;
    }

    cpTimelineContainerHTML: HTMLElement | null = null;
    cpTimelineHeaderHTML: HTMLElement | null = null;

    private get months() {
        const baseRef = [...this.baseMonths];
        const deleted = baseRef.splice(0, this.startDate.getMonth());
        baseRef.push(...deleted);
        return baseRef;
    }

    private get yearDays(): number {
        const februaryYear = this.realYear(1);
        return new Date(februaryYear, 1, 29).getDate() === 29 ? 366 : 365;
    }
    private get dayPercentual(): number {
        return 100 / this.yearDays;
    }

    private get headerStyle() {
        return { height: this.headerHeight + "px" };
    }

    private get yearStart(): Date {
        return this.startDate;
    }
    private get yearEnd(): Date {
        return new Date(this.startDate.getFullYear() + 1, this.startDate.getMonth(), this.startDate.getDate() - 1);
    }

    private get isCurDateTimeInRange() {
        const curDate = this.currentDate || this.curDate;
        return curDate.getTime() >= this.yearStart.getTime() && curDate.getTime() <= this.yearEnd.getTime();
    }
    
    private getPlotArea() {
        const areas = this.areas.filter((a) => this.curPointInTime >= a.fromDate && this.curPointInTime <= a.toDate);
        return areas.length == 1 ? areas[0].areaSqm : null;
    }

    destroyed() {
        document.removeEventListener("mousemove", this.onMouseMove);
    }

    mounted() {
        this.cpTimelineContainerHTML = this.$refs.cpTimelineContainer as HTMLElement;
        this.cpTimelineHeaderHTML = this.$refs.cpTimelineHeader as HTMLElement;
        this.setSectionPositions();
        document.addEventListener("mousemove", this.onMouseMove);
        requestAnimationFrame(() => this.computePositionsMap());
    }

    private onMouseMove(ev: MouseEvent) {
        this.mouseX = ev.clientX;
        this.mouseY = ev.clientY;
    }

    private onHeaderClick() {
        if (this.cursorDateValue && this.curConfiguration?.DISABLE_CHANGE_DATE !== "TRUE" && !this.disableTimelineDateChange) {
            this.onPointInTimeChange(this.cursorDateValue)
        }
    }

    private get cursorBarStyle() {
        return {
            left:
                this.mouseX && this.cpTimelineContainerHTML
                    ? this.mouseX - this.cpTimelineContainerHTML.getBoundingClientRect().left + "px"
                    : -1 + "px",
        };
    }
    private get cursorCounterStyle() {
        if (this.isHovering || this.isHeaderHovering)
            return {
                left:
                    this.mouseX && this.cpTimelineContainerHTML
                        ? this.mouseX -
                          this.cpTimelineContainerHTML.getBoundingClientRect().left -
                          (this.cursorCounterValue > 9 ? 5 : 3) +
                          "px"
                        : 0 + "px"
                // backgroundColor: "red"
            };
        else
            return {
                left: this.getPointInTimeLineLeft + "px"
            };
    }

    private realYear(month: number) {
        if (month < this.startDate.getMonth()) {
            return this.startDate.getFullYear() + 1;
        }
        return this.startDate.getFullYear();
    }

    private daysInMonth(month: number): number {
        return new Date(this.realYear(month), month, 0).getDate();
    }
    private get cursorCounterValue(): number {
        let date = this.curPointInTime.getDate();
        if ((this.isHovering && this.cpTimelineContainerHTML) || (this.isHeaderHovering && this.cpTimelineHeaderHTML)) {
            // get percentage of the cursor position in realation to the container width
            // const percentage =
            //     Math.round(
            //         ((this.mouseX -
            //             (this.isHovering
            //                 ? this.cpTimelineContainerHTML!.getBoundingClientRect().left
            //                 : this.cpTimelineHeaderHTML!.getBoundingClientRect().left)) /
            //             ((this.isHovering
            //                 ? this.cpTimelineContainerHTML!.getBoundingClientRect().width
            //                 : this.cpTimelineHeaderHTML!.getBoundingClientRect().width) /
            //                 100)) *
            //             10
            //     ) / 10;
            // return this.computeDayOfMonth(percentage).dayOfMonth;

            let dist = 0;
            if (this.isHovering) {
                if (this.cpTimelineContainerHTML) dist = this.cpTimelineContainerHTML.getBoundingClientRect().left;
            } else {
                if (this.cpTimelineHeaderHTML) dist = this.cpTimelineHeaderHTML.getBoundingClientRect().left;
            }

            const mousePos = this.mouseX - dist;

            const index = this.monthByPositionArray.findIndex((p) => mousePos < p);
            if (index >= 0 && this.dateByPositionArray.length) {
                date = this.dateByPositionArray[index].findIndex((pos) => mousePos < pos) + 1;
            }
        }
        return date;
    }

    private get cursorDateValue(): Date | null {
        let curDate = new Date();
        if ((this.isHovering && this.cpTimelineContainerHTML) || (this.isHeaderHovering && this.cpTimelineHeaderHTML)) {
            // get percentage of the cursor position in realation to the container width

            let dist = 0;
            if (this.isHovering) {
                if (this.cpTimelineContainerHTML) dist = this.cpTimelineContainerHTML.getBoundingClientRect().left;
            } else {
                if (this.cpTimelineHeaderHTML) dist = this.cpTimelineHeaderHTML.getBoundingClientRect().left;
            }

            const mousePos = this.mouseX - dist;

            const index = this.monthByPositionArray.findIndex((p) => mousePos < p);
            if (index >= 0 && this.dateByPositionArray.length) {
                const date = this.dateByPositionArray[index].findIndex((pos) => mousePos < pos) + 1;
                const curMonth = this.months[index];

                curDate = new Date(this.realYear(curMonth), curMonth - 1, date);
            }
        } else curDate = this.curPointInTime;
        return curDate;
    }

    // private computeDayOfMonth(percentage: number) {
    //     const dayFromStartDate = Math.floor(percentage / this.dayPercentual);
    //     let dayCount = 0;
    //     let dayOfMonth = 0;
    //     let curMonth = 0;
    //     //define day of the month based on cursor position
    //     this.months.forEach((m) => {
    //         dayCount = dayCount + this.daysInMonth(m);
    //         if (dayOfMonth === 0 && dayFromStartDate <= dayCount) {
    //             curMonth = m;
    //             let previousMonthsDays = 0;
    //             const startMonth = this.months[0];
    //             const endMonth = m < startMonth ? m + 12 : m;
    //             for (let i = startMonth; i < endMonth; i++) {
    //                 previousMonthsDays = previousMonthsDays + this.daysInMonth(i);
    //             }
    //             dayOfMonth = dayFromStartDate - previousMonthsDays;
    //         }
    //     });
    //     return dayOfMonth > 0 ? { dayOfMonth, curMonth } : { dayOfMonth: 1, curMonth };
    // }

    @Watch("sections", { deep: true })
    private onSectionsUpdate() {
        this.setSectionPositions();
    }

    private setSectionPositions() {
        this.sectionsUI = this.sections.map((e) => toTimelineSectionUI(e));

        this.sectionsUI.forEach((s: TimelineSectionUI, idx: number) => {
            if (idx > 0) {
                this.sectionsUI.forEach((s1: TimelineSectionUI, idx1: number) => {
                    //if start period is less than current end period or if end period is greater than current start period
                    if (idx1 < idx && s1.start < s.end && s1.end > s.start) {
                        s.position = s1.position + 1;
                        if (!s1.column) {
                            s1.column = s1.start.getTime();
                        }
                        s.column = s1.column;
                    }
                });
            }
        });

        //condense all columns with more than X elements
        this.sectionsUI.forEach((s: TimelineSectionUI) => {
            if (s.position >= this.maxElementsBeforeCondensed - 1) {
                this.sectionsUI.filter((s1) => s1.column === s.column).forEach((s1) => (s1.condensed = true));
            }
        });
    }

    // private bubbleSort(array: number[]) {
    //     let done = false;
    //     while (!done) {
    //         done = true;
    //         for (var i = 1; i < array.length; i += 1) {
    //             if (array[i - 1] > array[i]) {
    //                 done = false;
    //                 var tmp = array[i - 1];
    //                 array[i - 1] = array[i];
    //                 array[i] = tmp;
    //             }
    //         }
    //     }
    //     return array;
    // }

    private getPositionLeftByDate(date: Date) {
        const month = date.getMonth();
        const day = date.getDate();

        return this.positionsByDateMap &&
            this.positionsByDateMap[month] &&
            this.positionsByDateMap[month].daysPosition[day]
            ? this.positionsByDateMap[month].daysPosition[day]
            : 0;
    }

    private getChangingPointPosition(changingPoint: ChangingPoint) {
        const startDateNormalized =
            changingPoint.date.getTime() < this.yearStart.getTime() ? this.yearStart : changingPoint.date;
        // const daysFromYearStart = Math.round(
        //     Math.abs((startDateNormalized.getTime() - this.yearStart.getTime()) / this.dayMS)
        // );
        return this.getPositionLeftByDate(startDateNormalized);
    }

    private getSectionTop(e: TimelineSectionUI): number {
        const height =
            e.position > 0
                ? (this.sectionDefaultHeight + this.sectionSpaceBetween) * e.position + this.sectionSpaceBetween
                : this.sectionSpaceBetween;
        return height;
    }
    private getSectionLeft(e: TimelineSectionUI): number {
        const startDateNormalized = e.start.getTime() < this.yearStart.getTime() ? this.yearStart : e.start;
        // const daysFromYearStart = Math.round(
        //     Math.abs((startDateNormalized.getTime() - this.yearStart.getTime()) / this.dayMS)
        // );
        // return daysFromYearStart * this.dayPercentual;
        return this.getPositionLeftByDate(startDateNormalized);
    }
    private getSectionWidth(e: TimelineSectionUI): number {
        const startDateNormalized = e.start.getTime() < this.yearStart.getTime() ? this.yearStart : e.start;
        const endDateNormalized = e.end.getTime() > this.yearEnd.getTime() ? this.yearEnd : e.end;
        const sectionDays = Math.round(
            Math.abs((startDateNormalized.getTime() - endDateNormalized.getTime()) / this.dayMS)
        );
        return (sectionDays + 1) * this.absoluteWidthUnit;
    }

    private getMonthWidth(month: number): number {
        // const sectionDays = Math.abs(
        //     (new Date(this.realYear(month - 1), month - 1, 1).getTime() -
        //         new Date(this.realYear(month), month, 0).getTime()) /
        //         this.dayMS
        // );

        //return (sectionDays + 1) * this.dayPercentual;
        return this.getDayWidthPerMonth(month).width;
    }

    private get getPointInTimeLineLeft(): number {
        // const daysFromYearStart = Math.round(
        //     Math.abs((this.curDate!.getTime() - this.yearStart.getTime()) / this.dayMS)
        // );
        // return daysFromYearStart * this.dayPercentual;

        return this.getPositionLeftByDate(this.currentDate || this.curDate);
    }

    private get getPlotLineLeft(): number {
        if (!this.areas || (this.areas && this.areas.length === 0)) {
            return 0;
        }
        // const startDateNormalized = this.curPlot!.fromDate.getTime() < this.yearStart.getTime() ? this.yearStart : this.curPlot!.fromDate;
        const startDateNormalized =
            this.areas[0].fromDate.getTime() < this.yearStart.getTime() ? this.yearStart : this.areas[0].fromDate;
        // const daysFromYearStart = Math.round(
        //     Math.abs((startDateNormalized.getTime() - this.yearStart.getTime()) / this.dayMS)
        // );
        // return daysFromYearStart * this.dayPercentual;
        return this.getPositionLeftByDate(startDateNormalized);
    }
    private get getPlotLineWidth(): number {
        if (!this.areas || (this.areas && this.areas.length === 0)) {
            return 0;
        }
        // const startDateNormalized = this.curPlot!.fromDate.getTime() < this.yearStart.getTime() ? this.yearStart : this.curPlot!.fromDate;
        // const endDateNormalized = this.curPlot!.toDate.getTime() > this.yearEnd.getTime() ? this.yearEnd : this.curPlot!.toDate;
        const startDateNormalized =
            this.areas[0].fromDate.getTime() < this.yearStart.getTime() ? this.yearStart : this.areas[0].fromDate;
        const endDateNormalized =
            this.areas[this.areas.length - 1].toDate.getTime() > this.yearEnd.getTime()
                ? this.yearEnd
                : this.areas[this.areas.length - 1].toDate;
        if (endDateNormalized.getTime() < startDateNormalized.getTime()) return 0;
        const sectionDays = Math.round(
            Math.abs((startDateNormalized.getTime() - endDateNormalized.getTime()) / this.dayMS)
        );
        return (sectionDays + 1) * this.absoluteWidthUnit;
    }
    private get getPlotLineEvents(): number[] {
        const events: number[] = [];
        this.areas.forEach((e, i) => {
            if (
                i > 0 &&
                e.fromDate.getTime() >= this.yearStart.getTime() &&
                e.fromDate.getTime() <= this.yearEnd.getTime()
            ) {
                const daysFromYearStart = Math.round(
                    Math.abs((e.fromDate.getTime() - this.yearStart.getTime()) / this.dayMS)
                );
                const leftCoord = daysFromYearStart * this.absoluteWidthUnit;
                events.push(leftCoord);
            }
        });
        return events;
    }

    private get absoluteWidthUnit() {
        if (this.cpTimelineContainerHTML) {
            return this.cpTimelineContainerHTML.getBoundingClientRect().width / this.yearDays;
        }
        return 0;
    }

    private get disableTimelineDateChange() {
        return this.curConfiguration?.DISABLE_CHANGE_DATE_ON_TIMELINE === 'TRUE'
            || (this.curConfiguration?.DISABLE_CHANGE_DATE_WHEN_READ_ONLY === "TRUE" && this.curCropPlan?.readOnly)
    }

    private getDayWidthPerMonth(month: number) {
        const numOfDays = this.daysInMonth(month);
        return { width: numOfDays * this.absoluteWidthUnit, numOfDays };
    }

    private onResize() {
        this.cpTimelineContainerHTML = null;
        this.cpTimelineContainerHTML = this.$refs.cpTimelineContainer as HTMLElement;
        this.computePositionsMap();
    }

    @Watch("startDate")
    private computePositionsMap() {
        this.monthByPositionArray = [];
        this.dateByPositionArray = [];
        let cumulativeOfsset = 0;
        this.months.forEach((m, i) => {
            const monthWidth = this.getDayWidthPerMonth(m);
            cumulativeOfsset += i === 0 ? 0 : this.getDayWidthPerMonth(this.months[i - 1]).width;
            this.monthByPositionArray.push(monthWidth.width + cumulativeOfsset);
            const absoluteWidthUnit = this.absoluteWidthUnit;
            this.positionsByDateMap[m - 1] = {
                width: monthWidth.width,
                daysPosition: this.getDaysPosition(
                    [...Array(monthWidth.numOfDays).keys()],
                    absoluteWidthUnit,
                    cumulativeOfsset
                ),
            };
        });
        this.currentDate = null;
        this.currentDate = this.curDate;
    }

    private getDaysPosition(days: number[], absoluteWidthUnit: number, offset: number) {
        const tmp: Record<number, number> = {};
        const tmpPositions: number[] = [];
        days.forEach((d) => {
            const width = d * absoluteWidthUnit + offset;
            tmp[d + 1] = width;
            tmpPositions.push(width);
        });
        tmpPositions.shift();
        tmpPositions.push(days.length * absoluteWidthUnit + offset);
        this.dateByPositionArray.push(tmpPositions);
        return tmp;
    }

    private changeYear(direction: "up" | "down") {
        if(
            this.curConfiguration?.DISABLE_CHANGE_DATE_ON_TIMELINE === "TRUE"
            || (this.curConfiguration?.DISABLE_CHANGE_DATE_WHEN_READ_ONLY !== "TRUE" && this.curCropPlan?.readOnly)
        ) return
        const refMonth = this.startDate.getMonth();
        const refDate = this.startDate.getDate();
        const refYear = this.startDate.getFullYear();
        let newDate =
            direction === "up" ? new Date(refYear + 1, refMonth, refDate) : new Date(refYear - 1, refMonth, refDate);
        if (direction === "down" && this.pointInTimeRangeMin && refYear - 1 < this.pointInTimeRangeMin.getFullYear()) {
            newDate = new Date(
                this.pointInTimeRangeMin.getFullYear(),
                this.pointInTimeRangeMin.getMonth(),
                this.pointInTimeRangeMin.getDate()
            );
        }
        this.$emit("changeDate", newDate);
    }

    // .reduce(
    //     (obj: Record<number, string>, n: number) => (obj[n] = (n * absoluteWidthUnit).toString()),
    //     {} as Record<number, string>
    // ),

    private onRowClick(section: TimelineSection, evt: PointerEvent) {
        // Deselect curPlots
        if (this.curPlots.length > 0) this.curPlots = [];

        if (((evt.ctrlKey && !isMacOs()) || (evt.metaKey && isMacOs()))) {
            if (this.curTimelineSection) this.onRowCheckboxClick(section);
            return;
        }
        if (this.curTimelineSection && this.curTimelineSection.id === section.id) {
            this.curTimelineSection = null;
        } else {
            this.curTimelineSection = section;
        }
        this.curTimelineSections = [];
    }

    private onRowCheckboxClick(e: TimelineSection) {
        if (this.curTimelineSection && this.curTimelineSection.id !== e.id) {
            const selectedSection = this.curTimelineSections.find(s => s.id == e.id);
            if(selectedSection)
                this.curTimelineSections = [...this.curTimelineSections.filter(s => s.id != e.id)];
            else 
                this.curTimelineSections = [...this.curTimelineSections, e];
        }
    }
    
    private setDisplaySecondaryCheckbox(section: TimelineSection | null) {
        if (this.curTimelineSection && this.curTimelineSection.id != section?.id) {
            this.displaySecondaryCheckbox = section?.id || null;
        }
    }
}
</script>

<style lang="scss">
.cp-timeline {
    @apply transition-all duration-150 ease-in-out;
}

// .cp-timeline-cursor-bar{
//     @apply flex absolute bg-border;
//     width: 1px;
//     top: 13px;
//     bottom: 13px;
// }
.cp-timeline-cursor-bar {
    @apply flex absolute border-r border-dashed;
    width: 1px;
    top: 13px;
    bottom: 13px;
}
.cp-timeline-cursor-bar-header {
    @apply flex absolute border-2 border-danger-100 bg-danger-100  z-10 rounded-full;
    width: 5px;
    top: 12px;
    height: calc(100% - 12px);
    bottom: 12px;
    margin-left: -2px;
}
.cp-timeline-cursor-counter {
    @apply flex absolute text-secondary-200;
    top: -15px;
    font-size: 10px;
}
.cp-timeline-cursor-counter.cp-timeline-cursor-counter-header {
    @apply text-secondary-600 font-semibold;
}

.cp-timeline {
    @apply flex px-5 items-center justify-center text-secondary-600 cursor-pointer;
    width: 45px;
}

.cp-timeline.disabled {
    @apply flex px-5 items-center justify-center text-secondary-300 cursor-not-allowed;
    width: 45px;
}

.cp-timeline:hover:not(.disabled) {
    @apply bg-bg-500;
}

.cp-timeline-header-month {
    @apply flex text-label-primary text-sm items-center justify-center relative;
}
.cp-timeline-header-month:after {
    content: "";
    position: absolute;
    width: 1px;
    top: 13px;
    bottom: 13px;
    right: -1px;
    @apply bg-border;
}
.cp-timeline-header-month:last-of-type:after {
    content: none;
}
.cp-timeline-month-divider {
    @apply relative;
    // z-index: 10;
    opacity: 1;
}
.cp-timeline-month-divider:first-of-type {
    border-left-color: theme("colors.text-opposite");
}
</style>
