<template>
    <tile :title="'Edit declaration pesticide'" noContainerStyled>
        <div class="flex w-full h-full overflow-auto">
            <div v-if="!loading" class="flex flex-col px-4 py-6 sm:w-full md:w-full lg:w-5/12 xxl:w-4/12 mx-auto">
                <abc-form ref="form" class="flex flex-col w-full" @submit="submit">
                    <!-- PESTICIDES LIST -->
                    <div class="flex w-full mb-4">
                        <abc-autocomplete
                            class="w-full mr-2"
                            :label="i18n('pesticide-title')"
                            :value="selectedPesticide"
                            itemId="productCode"
                            :items="pesticidesPage.records"
                            :stringify="(item) => (item ? item.productName : null)"
                            :search.sync="searchPesticide"
                            maxHeight="300px"
                            buttons
                            @input="updateSelectedPesticide"
                            :rules="mandatoryRule"
                        >
                            <template #items="{ item }">
                                <div>{{ item.productName }}</div>
                            </template>
                            <template>
                                <div v-if="pesticidesLoading" class="flex justify-center items-center h-12">
                                    <abc-loader :size="32" />
                                </div>
                                <div
                                    v-if="!pesticidesLoading && pesticidesPage.records.length === 0"
                                    class="flex justify-center items-center h-12"
                                >
                                    <abc-no-data-found />
                                </div>
                                <div
                                    v-if="
                                        !pesticidesLoading &&
                                        pesticidesPage.records.length > 0 &&
                                        pesticidesPage.haveMore
                                    "
                                    class="flex justify-center items-center h-12"
                                >
                                    <abc-refine-filter />
                                </div>
                            </template>
                            <template #buttons>
                                <abc-tool-button
                                    is-secondary
                                    @click="
                                        searchPesticide = '';
                                        selectedPesticide = null;
                                        curPesticideUom = null;
                                        detail.uomCode = undefined;
                                        uomsReady = false;
                                    "
                                    :title="i18n('clear-field')"
                                >
                                    <em class="abc-icon abc-icon-x text-xs"></em>
                                </abc-tool-button>
                            </template>
                        </abc-autocomplete>
                    </div>

                    <div class="flex w-full">
                        <abc-input
                            class="w-3/12 pr-2"
                            text-right
                            is-numeric
                            v-model="detail.amount"
                            autocomplete="off"
                            :label="i18n('dosage')"
                            ref="pesticideQt"
                            :rules="mandatoryRule"
                        >
                        </abc-input>
                                
                        <abc-dropdown2 
                            class="w-4/12 pl-2"
                            :label="i18n('unit-of-measure')"
                            :value="detail.uomCode"
                            @input="val => detail.uomCode = val.uomCode"
                            :items="uomsList"
                            :rules="mandatoryRule"
                            :is-disabled="!uomsReady"
                            ref="pesticideUoms"
                        >
                            <p v-if="detail.uomCode && uomsList.find(i => i.uomCode == detail.uomCode)">
                                {{ uomsList.find(i => i.uomCode == detail.uomCode).uomLabel }}
                            </p>
                            <template #items="{ item }">
                                <div class="cursor-pointer">
                                    {{ item.uomLabel }}
                                </div>
                            </template>
                        </abc-dropdown2>

                        <abc-switch
                            class="w-4/12 px-2 flex justify-start"
                            style="margin-top: 25px"
                            :label="i18n('product-quantity-per-area')"
                            v-model="perAreaUoms"
                        />
                    </div>

                    <abc-form-buttons
                        class="pb-6 mt-4"
                        @save="submit"
                        @cancel="close"
                        :has-continue="false"
                        :disable-confirm-button="disableFormButtons"
                    />
                </abc-form>
            </div>
            <abc-loader v-if="loading" scope="fixed" />
        </div>
    </tile>
</template>

<script lang="ts">
import { Component, Inject, Watch, Mixins, Ref } from "vue-property-decorator";
import { TranslateResult } from "vue-i18n";
import SingleCropPlanModule, { MODULE_ID } from "../..";
import { FromStore, ToastOptions } from "@abaco/web-common/src/app";
import { Business } from "../../models/Business";
import { Plot } from "../../models/Plot";
import DateUtils from "../../mixins/DateUtils";
import { Validable } from "@abaco/web-components/src/components/form/Validable";
import { Configuration, CropPlan } from "../../models/CropPlan";
import { Council } from "../../models/Council";
import { Pesticide, PesticideEntry, PesticideOut, toPesticideOut } from "../../models/Declaration";
import AreaUtils from "../../mixins/AreaUtils";
import { VBTooltip } from "bootstrap-vue";
import cloneDeep from "lodash/cloneDeep";
import { EmptyMaxPagedResults, MaxPagedResults } from "@abaco/web-common/src/Paging";
import { Debounce } from "vue-debounce-decorator";
import { Version } from "../../models/Version";
import { ValidationMessage } from "../../models/Utils";
import { UnitOfMeasurement, UnitsOfMeasure, UomType } from "../../models/UnitOfMeasure";
import { formatDate } from "../../api/Utils";

@Component({
    directives: {
        "b-tooltip": VBTooltip,
    },
})
export default class SingleCpDeclPesticideEdit extends Mixins(DateUtils, AreaUtils) {
    @Inject() i18n!: (key: string, values?: unknown) => TranslateResult;
    @Inject() toast!: (message: string, options?: ToastOptions) => TranslateResult;
    @Inject(MODULE_ID) singleCropPlanModule!: SingleCropPlanModule;

    @FromStore(MODULE_ID) business!: Business;
    @FromStore(MODULE_ID) curPlot!: Plot | null;
    @FromStore(MODULE_ID) curPlots!: Plot[];
    @FromStore(MODULE_ID) curPointInTime!: Date;
    @FromStore(MODULE_ID) curCropPlan!: CropPlan | null;
    @FromStore(MODULE_ID) curCouncil!: Council | null;
    @FromStore(MODULE_ID) editPlotPolygonDrawn!: boolean;
    @FromStore(MODULE_ID) curVersion!: Version | null;
    @FromStore(MODULE_ID) hideFieldName!: boolean;
    @FromStore(MODULE_ID) curConfiguration!: Configuration | null;
    @FromStore(MODULE_ID) curPesticide!: PesticideEntry | null;
    @FromStore(MODULE_ID) curPlotPesticideUpdated!: boolean;

    @Ref("form") form!: Validable;

    private detail: PesticideOut = {
        productCode: undefined,
        uomCode: undefined,
        amount: null,
        date: undefined,
    };

    private loading = true;
    private disableFormButtons = false;
    private validationMessages: ValidationMessage[] = [];
    private mandatoryRule = [(v: unknown) => !!v || this.i18n("valid.mandatory-field")];

    private pesticidesPage: MaxPagedResults<unknown> = new EmptyMaxPagedResults();
    private pesticidesLoading = false;
    private searchPesticide: string | null = null;
    private uomsTypes!: UnitsOfMeasure;
    private uomsList: UnitOfMeasurement[] = [];
    private curPesticideUom: UnitOfMeasurement | null = null;
    private curPesticideQt: number | null = null;
    private perAreaUoms = false;
    private selectedPesticide: Pesticide | null = null;
    private isInit = true;
    private uomsReady = false;

    @Watch("perAreaUoms")
    checkPerAreaSwitch() {
        this.curPesticideUom = null;
        this.detail.uomCode = undefined;
        if (this.perAreaUoms) this.uomsList = this.uomsTypes.perAreaUoms;
        else this.uomsList = this.uomsTypes.basicUoms;
    }

    async mounted() {
        if (this.curPesticide) {
            const curPesticideCopy = cloneDeep(this.curPesticide);
            this.detail = toPesticideOut(curPesticideCopy);
            if (this.curPesticide.entryDate) this.detail.date = formatDate(this.curPesticide.entryDate);
            this.selectedPesticide = {
                productName: this.curPesticide.productName,
                productCode: this.curPesticide.productCode,
                activeSubstanceConcentrationAmount: this.curPesticide.amount,
                activeSubstanceConcentrationAmountUom: this.curPesticide.uomCode,
                plantProtectionProductType: null,
                uomType: null,
            };
            await this.triggerPesticideSearch();
            this.loading = false;
        }
    }

    private async getUoms(uomType: UomType) {
        if (!this.curCropPlan) return;
        this.uomsReady = false;
        const pesticideUoms = await this.singleCropPlanModule.cropPlanApi.getPesticideUoms(
            this.business.businessId,
            this.curCropPlan.cropPlanId,
            uomType
        );
        if (pesticideUoms) {
            this.uomsTypes = pesticideUoms;
            if (this.isInit) {
                let isInBasicUoms = false;
                this.uomsTypes.basicUoms.forEach((uom) => {
                    if (this.curPesticide?.uomCode === uom.uomCode) {
                        this.uomsList = this.uomsTypes.basicUoms;
                        isInBasicUoms = true;
                    }
                });
                if (!isInBasicUoms) {
                    this.uomsList = this.uomsTypes.perAreaUoms;
                    this.detail.uomCode = this.curPesticide?.uomCode;
                    this.perAreaUoms = true;
                }
                this.detail.uomCode = this.curPesticide?.uomCode;
            }
            this.isInit = false;
            this.uomsReady = true;
        }
    }

    @Watch("searchPesticide")
    @Debounce(300)
    private async triggerPesticideSearch() {
        if (!this.curCropPlan || !this.searchPesticide) return;
        this.pesticidesLoading = true;
        this.pesticidesPage = new EmptyMaxPagedResults();
        let page = await this.singleCropPlanModule.cropPlanApi.getPesticidesList(
            this.business.businessId,
            this.curCropPlan.cropPlanId,
            this.searchPesticide.trim().toUpperCase(),
            this.curPesticide ? this.curPesticide.declaration.landuse.code : null
        );
        if (page.count === 1 && this.searchPesticide === page.records[0].productName) {
            const res = page.records[0];
            page = await this.singleCropPlanModule.cropPlanApi.getPesticidesList(
                this.business.businessId,
                this.curCropPlan.cropPlanId,
                null,
                this.curPesticide ? this.curPesticide.declaration.landuse.code : null
            );
            page.records = page.records.filter((l) => l.productCode !== res.productCode);
            page.records.unshift(res);
            if (this.selectedPesticide) {
                this.selectedPesticide = { ...this.selectedPesticide };
                if (page.records[0].uomType) await this.getUoms(page.records[0].uomType);
            }
        }
        this.pesticidesPage = page;
        this.pesticidesLoading = false;
    }
    private updateSelectedPesticide(value: Pesticide) {
        this.selectedPesticide = value;
    }

    private async submit() {
        const isValid = this.form.validate();
        if (isValid) {
            this.disableFormButtons = true;
            await this.updatePesticide();
        }
    }

    private async updatePesticide() {
        try {
            const detailOut: PesticideOut = this.detail;
            if (!this.selectedPesticide || !this.selectedPesticide.productCode) return;
            detailOut.productCode = this.selectedPesticide.productCode;
            if (this.curPesticide && this.curPesticide.plotCode && this.curCropPlan && this.curCouncil) {
                await this.singleCropPlanModule.cropPlanApi.updatePesticide(
                    this.business.businessId,
                    this.curCropPlan.cropPlanId,
                    this.curCouncil.domainZoneId,
                    this.curPesticide.plotCode,
                    this.curPesticide.declCode,
                    this.curPesticide.pesticideEntryCode,
                    detailOut
                );
                this.$emit("updated");
                this.$emit("close-current-view");
            }
        } catch (error) {
            this.toast(error as any, { type: "error" });
        } finally {
            this.disableFormButtons = false;
        }
    }

    private close() {
        this.$emit("close-current-view");
    }
}
</script>

<style lang="scss" scoped></style>
