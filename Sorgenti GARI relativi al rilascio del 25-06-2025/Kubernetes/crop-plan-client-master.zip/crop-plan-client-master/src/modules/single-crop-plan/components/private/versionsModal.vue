<template>
    <abc-modal
        :title="i18n('published-versions-list')"
        :items="versions"
        @close="$emit('close')"
    >
        <template #body>
            <div style="min-width: 400px">
                <abc-loader v-if="loading" />
                <abc-table v-else :items="versions" disableSelectOnClick>
                    <template #headers>
                        <th id="user" class="w-24">{{ i18n("user") }}</th>
                        <th id="date" class="">{{ i18n("date") }}</th>
                        <th id="date" class="">{{ i18n("date-reference") }}</th>
                        <th id="notes" class="">{{ i18n("notes") }}</th>
                    </template>
                    <template #items="{ item }">
                        <td class="w-24">{{ item.userId }}</td>
                        <td>
                            {{ formattedDate(item.versionDate) }}
                            {{ formattedDateWithFormat(item.versionDate, "HH:mm:ss") }}
                        </td>
                        <td>
                            {{ item.versionReferenceDate ? referenceDate(item.versionReferenceDate) : "" }}
                        </td>
                        <td class="w-24">{{ item.message }}</td>
                    </template>
                </abc-table>
            </div>
        </template>
    </abc-modal>
</template>

<script lang="ts">
import { FromStore } from "@abaco/web-common/src/app";
import { EmptyMaxPagedResults, infiniteNextLoad, NextPagedResults } from "@abaco/web-common/src/Paging";
import { Component, Mixins, Inject } from "vue-property-decorator";
import { TranslateResult } from "vue-i18n";
import SingleCropPlanModule, { MODULE_ID } from "../..";
import DateUtils from "../../mixins/DateUtils";
import { Business } from "../../models/Business";
import { CropPlan } from "../../models/CropPlan";
import { Version } from "../../models/Version";
import { convertToDate } from "../../api/Utils";

@Component
export default class VersionsModal extends Mixins(DateUtils) {
    @Inject(MODULE_ID) singleCropPlanModule!: SingleCropPlanModule;
    @Inject() i18n!: (key: string, values?: unknown) => TranslateResult;

    @FromStore(MODULE_ID) business!: Business;
    @FromStore(MODULE_ID) curCropPlan!: CropPlan | null;

    private loading = false;
    private versions: Version[] = [];

    mounted() {
        this.updateList();
    }
    
    private async updateList() {
        if (!this.curCropPlan) {
            console.error("Missing data for api request");
            this.versions = [];
            return;
        }
        this.loading = true;
        const res = await infiniteNextLoad(() =>
            this.curCropPlan
                ? this.singleCropPlanModule.versionApi.getVersions(
                      this.business.businessId,
                      this.curCropPlan.cropPlanId,
                      undefined
                  )
                : new Promise<NextPagedResults<Version>>(() => ({
                    haveMore: false,
                    records: [],
                    count: 0
                }))
        );
        this.versions = res ? res.records : [];
        this.loading = false;
    }

    private referenceDate(date: string) {
        if(convertToDate(date))
            return this.formattedDate(convertToDate(date)!)
        return "";
    }
}
</script>
