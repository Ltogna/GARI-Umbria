<template>
    <div
        class="absolute inset-y-0 flex flex-col justify-around z-20"
        :style="containerStyle"
        :class="{ 'z-30': isCurDate }"
    >
        <div
            class="cp-timeline-changing-point rounded-full"
            :class="{ 'bg-success-500 border-t-4 border-b-4 border border-bg-100': changingPoint.flAdded }"
        ></div>
        <div
            class="cp-timeline-changing-point rounded-full"
            :class="{ 'bg-brand-yellow-600 border border-t-4 border-b-4 border-bg-100': changingPoint.flModified }"
        ></div>
        <div
            class="cp-timeline-changing-point rounded-full"
            :class="{ 'bg-danger-500 border border-t-4 border-b-4 border-bg-100': changingPoint.flDeleted }"
        ></div>
    </div>
</template>

<script lang="ts">
import { Prop, Component, Inject, Mixins } from "vue-property-decorator";
import { TranslateResult } from "vue-i18n";
import { ChangingPoint } from "../../models/Declaration";
import DateUtils from "../../mixins/DateUtils";

@Component
export default class CropPlanTimelineChangingPoint extends Mixins(DateUtils) {
    @Inject() i18n!: (key: string, values?: unknown) => TranslateResult;

    @Prop() curDate!: Date;
    @Prop() left!: number;
    @Prop() changingPoint!: ChangingPoint;

    private isHovering = false;

    private get isCurDate() {
        return this.curDate.getTime() === this.changingPoint.date.getTime();
    }

    private get containerStyle() {
        return {
            // left: `calc(${this.left}px - 0.25px)`,
            left: `${this.left}px`,
        };
    }
}
</script>

<style lang="scss">
.cp-timeline-changing-point {
    @apply transition-all duration-150 ease-in-out w-1 h-8;
    // width: 5px;
    // height: 15px;
}
</style>
