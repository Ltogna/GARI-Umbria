<template>
    <abc-modal isMessage v-if="showModal" @close="onClose">
        <template #body>
            <div class="sm:flex sm:items-start w-full">
                <div
                    v-if="cropPlanModalMode === 2"
                    class="mx-auto flex-shrink-0 flex items-center justify-center h-12 w-12 rounded-full bg-danger-50 sm:mx-0 sm:h-10 sm:w-10 text-danger-600 text-xl"
                >
                    <em class="fal fa-exclamation-triangle"></em>
                </div>
                <div class="mt-3 text-center sm:mt-0 sm:ml-4 sm:text-left w-full">
                    <div class="text-lg leading-6 font-semibold">
                        {{ getModalTitle() }}
                    </div>
                    <div class="mt-2">
                        <p v-if="cropPlanType">
                            <strong>{{ i18n("crop-plan-type") }}: </strong>{{ cropPlanType.description }}
                        </p>
                        <abc-form ref="form">
                            <abc-input
                                v-if="cropPlanModalMode !== 2"
                                v-model="newCropPlanDescription"
                                class="mt-2"
                                :label="i18n('crop-plan-description')"
                                :rules="mandatoryRule"
                            ></abc-input>
                            <div v-else>
                                <p>{{ i18n("crop-plan-delete-warning.1") }}: {{ newCropPlanDescription }}?</p>
                                {{ i18n("crop-plan-delete-warning.2") }}
                            </div>
                        </abc-form>
                    </div>
                </div>
            </div>
        </template>
        <template #footer>
            <abc-button isSuccess v-if="cropPlanModalMode == 0" class="mx-2" @click="saveEdit"
                ><em class="abc-icon abc-icon-plus" />{{ i18n("create-and-open-crop-plan") }}</abc-button
            >
            <abc-button isSuccess v-if="cropPlanModalMode == 1" class="mx-2" @click="saveEdit"
                ><em class="abc-icon abc-icon-pen" />{{ i18n("save") }}</abc-button
            >
            <abc-button isSecondary isOutlined class="mx-2" @click="onClose"
                ><em class="abc-icon abc-icon-arrow-left" />{{ i18n("cancel") }}</abc-button
            >
            <abc-button isDanger isFilled v-if="cropPlanModalMode == 2" class="mx-2" @click="saveEdit"
                ><em class="abc-icon abc-icon-trash-bin" />{{ i18n("delete") }}</abc-button
            >
        </template>
    </abc-modal>
</template>

<script lang="ts">
import { Vue, Component, Inject, Ref, Prop, Watch } from "vue-property-decorator";
import { TranslateResult } from "vue-i18n";
import { Validable } from "@abaco/web-components/src/components/form/Validable";
import SingleCropPlanModule from "../../..";
import { FromStore } from "@abaco/web-common/src/app";
import { CropPlan, CropPlanType } from "../../../models/CropPlan";
import { Business } from "../../../models/Business";

@Component
export default class CropPlanEditModal extends Vue {
    @Inject() i18n!: (key: string, values?: unknown) => TranslateResult;
    @Inject(SingleCropPlanModule.MODULE_ID) singleCropPlanModule!: SingleCropPlanModule;
    @Ref("form") form!: Validable;

    @Prop({ type: Number }) cropPlanModalMode!: number;
    @Prop() cropPlanType!: CropPlanType | null;
    @Prop() selectedCropPlan!: CropPlan | null;
    @Prop({ type: Boolean }) showModal!: boolean;

    @FromStore(SingleCropPlanModule.MODULE_ID) business!: Business;
    @FromStore(SingleCropPlanModule.MODULE_ID) curCropPlan!: CropPlan | null;
    @FromStore(SingleCropPlanModule.MODULE_ID) cropPlanEditModeEnabled!: boolean;

    private mandatoryRule = [(v: unknown) => !!v || this.i18n("valid.mandatory-field")];
    private newCropPlanDescription = "";

    @Watch("showModal")
    updateCurrentData() {
        if (this.showModal) {
            if (this.cropPlanModalMode === 0) this.newCropPlanDescription = "";
            else if (this.selectedCropPlan) this.newCropPlanDescription = this.selectedCropPlan.description;
        }
    }

    async saveEdit() {
        if (this.cropPlanModalMode === 0 && this.form.validate() && this.cropPlanType) {
            this.curCropPlan = await this.singleCropPlanModule.cropPlanApi.insertCropPlan(this.business.businessId, {
                cropPlanTypeCode: this.cropPlanType.cropPlanTypeCode,
                description: this.newCropPlanDescription,
            });
            this.$emit("close", true);
        }
        if (this.cropPlanModalMode === 1 && this.selectedCropPlan) {
            const updatedCropPlan: CropPlan = { ...this.selectedCropPlan, description: this.newCropPlanDescription };
            await this.singleCropPlanModule.cropPlanApi.updateCropPlan(this.business.businessId, updatedCropPlan);
            this.$emit("close", true);
        }
        if (this.cropPlanModalMode === 2 && this.selectedCropPlan) {
            this.curCropPlan = null;
            await this.singleCropPlanModule.cropPlanApi.deleteCropPlan(
                this.business.businessId,
                this.selectedCropPlan.cropPlanId
            );
            this.$emit("close", true);
        }
    }

    onClose() {
        this.$emit("close", false);
    }

    getModalTitle(): string {
        if (this.cropPlanModalMode === 0) return this.i18n("create-crop-plan").toString();
        if (this.cropPlanModalMode === 1) return this.i18n("edit-crop-plan").toString();
        return this.i18n("delete-crop-plan").toString();
    }
}
</script>
