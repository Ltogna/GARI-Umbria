<template>
    <div class="h-full w-full flex flex-col overflow-auto">
        <template v-if="!loading">
            <search-crop-plans-edit
                v-if="cropPlanEditModeEnabled"
                @close="onModalClose"
                :edit-enabled="editEnabled"
                :delete-enabled="deleteEnabled"
            />
            <div
                v-for="cropPlanType in cropPlanTypesAccordions"
                :key="cropPlanType.cropPlanTypeCode"
                style="margin-top: -4px"
            >
                <div class="px-4 mb-1 mt-6" :value="true">
                    <div
                        class="flex justify-between items-center py-2 pl-4 pr-2 transition-all ease-in-out bg-bg-400 dark:bg-bg-dark-400 duration-400 border-t border-b"
                    >
                        <div class="w-full flex items-center justify-between">
                            <div class="w-full flex items-center justify-between">
                                <p class="text-label-primary">
                                    {{
                                        cropPlanType.description
                                            ? cropPlanType.description
                                            : cropPlanType.cropPlanTypeCode
                                    }}
                                </p>
                                <abc-button
                                    v-if="
                                        cropPlanType.multiple ||
                                        (!cropPlanType.multiple && cropPlanType.cropPlans.length < 1)
                                        "
                                    @click="handleAddCropPlan(cropPlanType)"
                                    is-icon
                                    is-secondary
                                    :isDisabled="isAddingCropPlan"
                                >
                                    <abc-loader v-if="isAddingCropPlan" scope="absulute" :size="14" />
                                    <em v-else class="abc-icon abc-icon-plus" />
                                </abc-button>
                            </div>
                        </div>
                    </div>
                    <div v-if="cropPlanType.cropPlans.length > 0">
                        <abc-list
                            class="abc-grouped-inner-list"
                            borderLess
                            invertedBorderLess
                            :items="cropPlanType.cropPlans"
                            @select="onSelect(cropPlanType.cropPlans[arguments[0]])"
                            :selected-item="curCropPlan"
                            itemId="cropPlanId"
                            :hideCheckbox="true"
                        >
                            <template #items="{ item }">
                                <div class="w-full">
                                    {{ item.description }}
                                </div>
                            </template>
                        </abc-list>
                    </div>
                    <abc-no-data-found v-else />
                </div>
            </div>
        </template>
        <abc-loader v-if="loading" class="pt-4" />
        <div v-else-if="!business">
            <p class="flex justify-center items-center text-label-primary h-16 mb-8">
                <em
                    class="abc-icon abc-icon-exclamation-point-circle text-secondary-100 text-3xl pr-3"
                    style="margin-top: -1px"
                />
                <template>
                    {{ i18n("select-a-farm-first") }}
                </template>
            </p>
        </div>
        <!-- MODAL INSERT CROP PLAN -->
        <abc-modal
            v-if="showInsertCropPlan"
            :title="getCropPlanTitle"
            force-modal
            modal-class="w-full md:w-8/12 lg:w-6/12 xxl:w-4/12"
        >
            <template #body>
                <abc-form ref="form">
                    <abc-input
                        v-model="newCropPlanDescription"
                        class="mt-2"
                        :label="i18n('crop-plan-description')"
                        :rules="mandatoryRule"
                    ></abc-input>
                    <div class="w-full flex my-4">
                        <abc-button @click="saveCropPlan" is-outlined>
                            <em class="fa-regular fa-floppy-disk mr-1"></em>
                            {{ i18n("save-close") }}
                        </abc-button>
                        <abc-button @click="closeInsertCropPlanModal" is-outlined>
                            <em class="abc-icon abc-icon-arrow-left-round"></em>
                            {{ i18n("cancel") }}
                        </abc-button>
                    </div>
                </abc-form>
            </template>
        </abc-modal>
    </div>
</template>

<script lang="ts">
import { Mixins, Component, Prop, Inject, Watch } from "vue-property-decorator";
import SingleCropPlanModule, { MODULE_ID } from "../../../index";
import { Business } from "../../../models/Business";
import { TranslateResult } from "vue-i18n";
import { FromStore } from "@abaco/web-common/src/app";
import { Debounce } from "vue-debounce-decorator";
import { CropPlan, CropPlanType } from "../../../models/CropPlan";
import DateUtils from "../../../mixins/DateUtils";

interface CropPlanTypeAccordion {
    cropPlanTypeCode: string;
    description: string;
    multiple: boolean;
    cropPlans: CropPlan[];
}

@Component
export default class SearchCropPlansResults extends Mixins(DateUtils) {
    @Inject() i18n!: (key: string, values?: unknown) => TranslateResult;
    @Inject(MODULE_ID) singleCropPlanModule!: SingleCropPlanModule;
    @FromStore(MODULE_ID) availableCropPlanTypes!: CropPlanType[];
    @FromStore(MODULE_ID) cropPlanEditModeEnabled!: boolean;
    @FromStore(MODULE_ID) editEnabled!: boolean;
    @FromStore(MODULE_ID) deleteEnabled!: boolean;

    @Prop() filter!: string;
    @Prop() triggerLoad!: number;

    @FromStore(MODULE_ID) business!: Business;
    @FromStore(MODULE_ID) curCropPlan!: CropPlan;

    private isAddingCropPlan = false;
    private loading = true;
    private showCropPlanModal = false;
    private cropPlanModalMode = -1;
    private selectedCropPlan: CropPlan | null = null;
    private targetCropPlanType: CropPlanType | null = null;

    private cropPlanTypesAccordions: CropPlanTypeAccordion[] = [];

    private showInsertCropPlan = false;
    private cropPlanTypeCode = "";
    private mandatoryRule = [(v: unknown) => !!v || this.i18n("valid.mandatory-field")];
    private newCropPlanDescription = "";

    private get getCropPlanTitle() {
        const cp = this.availableCropPlanTypes.find((t) => t.cropPlanTypeCode === this.cropPlanTypeCode);
        return cp?.description ?? "";
    }

    mounted() {
        // if(this.filter){
        this.resetAndLoad();
        // }
    }

    @Watch("filter")
    onFilterChange() {
        this.loading = true;
        this.waitAndReset();
    }

    @Debounce(400)
    waitAndReset() {
        this.resetAndLoad();
    }

    @Watch("triggerLoad")
    async resetAndLoad() {
        this.cropPlanTypesAccordions = [];
        if (this.business && this.availableCropPlanTypes) {
            for (const cropPlanType of this.availableCropPlanTypes) {
                const cropPlans = await this.singleCropPlanModule.cropPlanApi.getCropPlans(
                    this.business.businessId,
                    cropPlanType.cropPlanTypeCode
                );
                this.cropPlanTypesAccordions.push({
                    ...cropPlanType,
                    cropPlans: cropPlans,
                });
            }
        }
        this.loading = false;
    }

    private handleAddCropPlan(cropPlanType: CropPlanTypeAccordion) {
        this.isAddingCropPlan = true;
        if (cropPlanType.multiple) this.showInsertCropPlanModal(cropPlanType.cropPlanTypeCode);
        if (!cropPlanType.multiple && cropPlanType.cropPlans.length < 1) {
            this.cropPlanTypeCode = cropPlanType.cropPlanTypeCode;
            const cp = this.availableCropPlanTypes.find((it) => it.cropPlanTypeCode === cropPlanType.cropPlanTypeCode);
            this.newCropPlanDescription = cp?.description ? cp?.description : "";
            this.saveCropPlan();
        }
        this.isAddingCropPlan = false;
    }

    private onSelect(selectedCropPlan: CropPlan) {
        this.curCropPlan = selectedCropPlan;
        this.$emit("next-step");
    }

    private onModalClose(reset: boolean) {
        this.showCropPlanModal = false;
        if (reset) this.resetAndLoad();
    }

    private showInsertCropPlanModal(cropPlanTypeCode: string) {
        this.cropPlanTypeCode = cropPlanTypeCode;
        this.showInsertCropPlan = true;
    }

    private closeInsertCropPlanModal() {
        this.cropPlanTypeCode = "";
        this.showInsertCropPlan = false;
        this.newCropPlanDescription = "";
    }

    private async saveCropPlan() {
        if (this.business?.businessId) {
            await this.singleCropPlanModule.cropPlanApi.insertCropPlan(this.business.businessId, {
                cropPlanTypeCode: this.cropPlanTypeCode,
                description: this.newCropPlanDescription,
            });
            this.$emit("added-new-crop-plan");
        }
        this.showInsertCropPlan = false;
        this.newCropPlanDescription = "";
    }
}
</script>
