<template>
    <div>
        <transition
            name="custom-classes-transition"
            enter-active-class="animate__animated animate__fadeInDown10 animate__faster"
            mode="out-in"
        >
            <div>
                <div  class="flex w-full">
                    <div
                        v-if="
                            (!curCropPlan.readOnly && flCurCorpPlanChangesPending) || 
                            (!curCropPlan.readOnly && curConfiguration.ENABLE_PUBLISH_WHEN_NO_CHANGES_PENDING === 'TRUE')
                        "
                        class="flex px-3 py-3 bg-info-100 items-center w-full"
                        :class="{ 'justify-between': !flCurCorpPlanChangesPending || (curCropPlan && !curCropPlan.readOnly) }"
                    >
                        <div class="flex pr-2 text-info-200 h-full items-center">
                            <svg
                                xmlns="http://www.w3.org/2000/svg"
                                viewBox="0 0 192 512"
                                class="svg-image stroked"
                                style="width: 14px; height: 14px; margin-top: -3px"
                            >
                                <path
                                    fill="currentColor"
                                    d="M20 424.229h20V279.771H20c-11.046 0-20-8.954-20-20V212c0-11.046 8.954-20 20-20h112c11.046 0 20 8.954 20 20v212.229h20c11.046 0 20 8.954 20 20V492c0 11.046-8.954 20-20 20H20c-11.046 0-20-8.954-20-20v-47.771c0-11.046 8.954-20 20-20zM96 0C56.235 0 24 32.235 24 72s32.235 72 72 72 72-32.235 72-72S135.764 0 96 0z"
                                ></path>
                            </svg>
                        </div>
                        <div class="font-semibold text-info-600 text-sm pr-2">
                            {{ i18n("publish-crop-plan-when-done") }}
                        </div>
                        <div v-if="curCropPlan && !curCropPlan.readOnly" class="flex justify-center">
                            <abc-button
                                @click="checkCanPublish"
                                is-info
                                is-icon
                                :title="i18n('publish-crop-plan')"
                                v-b-tooltip.hover.window
                            >
                                <em class="abc-icon abc-icon-arrow-up-" />
                            </abc-button>
                            <abc-button
                                @click="checkAndExecEditDeleteGeom(() => (showRestoreVersionModal = true))"
                                is-danger
                                is-icon
                                :title="i18n('restore-crop-plan')"
                                v-b-tooltip.hover.window
                                v-if="isCropPlanRestoreVersionAvailable"
                            >
                                <em class="abc-icon abc-icon-arrow-circle" />
                            </abc-button>
                        </div>
                    </div>
                    <div
                        v-else-if="isCropPlanRestoreVersionAvailable == true && !getisGCP"
                        class="flex px-3 py-3 w-full"
                        :class="getisGCP ? 'bg-danger-400' : 'bg-success-400'"
                    >
                        <div v-if="getisGCP" class="flex pr-2 text-danger-800 h-full items-center">
                            <em class="fa-solid fa-triangle-exclamation"></em>
                        </div>
                        <div v-else class="flex pr-2 text-success-800 h-full items-center">
                            <em class="fa-solid fa-check"></em>
                        </div>
                        <div
                            class="font-semibold text-sm pl-2"
                            :class="getisGCP ? 'text-danger-800' : 'text-success-800'"
                        >
                            {{ i18n("publish-crop-plan-status") }}
                        </div>
                    </div>
                </div>
                <div
                    v-if="getisGCP"
                    class="flex px-3 py-3 w-full mt-3"
                    :class="flCurCorpPlanChangesPending ? 'bg-danger-600' : 'bg-success-600'"
                >
                    <div v-if="flCurCorpPlanChangesPending" class="flex pr-2 text-white h-full items-center">
                        <em class="fa-solid fa-triangle-exclamation"></em>
                    </div>
                    <div v-else class="flex pr-2 text-white h-full items-center">
                        <em class="fa-solid fa-check"></em>
                    </div>
                    <div
                        class="font-semibold text-sm pl-2 text-white"
                    >
                        {{ flCurCorpPlanChangesPending ? i18n("crop-plan-changes-pending") : i18n("publish-crop-plan-published") }}
                    </div>
                </div>
                <div
                    v-if="
                        !!lastPublicatedVersionDate && curConfiguration.ENABLE_PUBLISH_WHEN_NO_CHANGES_PENDING === 'TRUE'
                    "
                    class="flex px-3 py-3 bg-danger-200 w-full mt-1 text-danger-800 text-sm"
                >
                        <div class="flex text-danger-800 items-center">
                            <svg 
                                xmlns="http://www.w3.org/2000/svg"
                                viewBox="0 0 448 512"
                                class="svg-image stroked"
                                style="width: 14px; height: 14px; margin-top: -3px"
                            >
                                <path
                                    fill="currentColor"
                                    d="M216.1 408.1C207.6 418.3 192.4 418.3 183 408.1L119 344.1C109.7 335.6 109.7 320.4 119 311C128.4 301.7 143.6 301.7 152.1 311L200 358.1L295 263C304.4 253.7 319.6 253.7 328.1 263C338.3 272.4 338.3 287.6 328.1 296.1L216.1 408.1zM128 0C141.3 0 152 10.75 152 24V64H296V24C296 10.75 306.7 0 320 0C333.3 0 344 10.75 344 24V64H384C419.3 64 448 92.65 448 128V448C448 483.3 419.3 512 384 512H64C28.65 512 0 483.3 0 448V128C0 92.65 28.65 64 64 64H104V24C104 10.75 114.7 0 128 0zM400 192H48V448C48 456.8 55.16 464 64 464H384C392.8 464 400 456.8 400 448V192z"
                                />
                            </svg>
                        </div>
                        <div 
                            v-if="!!lastPublicatedVersionReferenceDate"
                            class="font-semibold pl-1 w-full text-center"
                        >
                            {{ 
                            i18n(
                                "last-pubblicated-version-dates",
                                { "date": lastPublicatedVersionDate, "referenceDate": lastPublicatedVersionReferenceDate }
                            ).toString()
                        }}
                        </div>
                        <div 
                            v-else
                            class="font-semibold pl-1 w-full text-center"
                        >
                            {{ 
                            i18n(
                                "last-pubblicated-version-date-no-reference",
                                { "date": lastPublicatedVersionDate }
                            ).toString()
                        }}
                        </div>
                </div>
            </div>
        </transition>

        <!-- CONFIRM PUBLISH MODAL -->
        <abc-modal
            modal-class="w-full lg:w-6/12 xxl:w-4/12"
            :title="
                i18n(
                    'publishing-details-at-date',
                    { 'date': this.formattedDate(this.curPointInTime) }
                ).toString()
            "
            force-modal
            @close="openEditModal = false"
            @submit="openEditModal = false"
            v-if="openEditModal"
        >
            <template #body>
                <abc-form
                    v-if="groupedAnomalies.numOfBlockingAnomalies === 0"
                    ref="form"
                    class="flex flex-col w-full"
                    @submit="submit"
                >
                    <div class="flex flex-col w-full mb-4">
                        <abc-input
                            class="w-full mt-3"
                            :label="i18n('publish-message')"
                            :info="i18n('publish-message-info')"
                            v-model="detail.message"
                        />

                        <div v-if="warningAnomalies.length > 0" class="flex flex-col mt-3">
                            <span class="italic font-semibold mb-3">{{ i18n("warning-anomalies-info") }}:</span>
                            <div class="bg-warning-100 w-full px-6 py-4 rounded-xl my-2">
                                <div class="text-warning-600 text-xl font-bold">
                                    <em class="text-warning-600 fa-regular fa-triangle-exclamation mr-5" />{{
                                        i18n("warning-anomalies")
                                    }}
                                </div>
                            </div>
                            <table aria-describedby="" class="w-full" style="border: none" cellspacing="0" cellpadding="0">
                                <tr v-for="item in warningAnomalies" :key="item.errorCode">
                                    <td class="warning-bullet pr-2">&bull;</td>
                                    <td>
                                        {{ item.errorDescription ? item.errorDescription : item.errorCode }}
                                    </td>
                                    <td>
                                        <div class="flex justify-end pr-3">
                                            <div
                                                class="py-0.5 px-2 bg-gray-300 rounded-full text-sm font-semibold w-fit"
                                            >
                                                {{ i18n("total-farms") + ": " + item.numOfAnomalies }}
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                            </table>
                            <span class="italic font-semibold mt-3">{{ i18n("warning-publish-proceed") }}</span>
                        </div>
                    </div>
                </abc-form>
                <div v-else>
                    <!-- BLOCKING ANOMALIES -->
                    <span class="italic font-semibold"> {{ i18n("blocking-anomalies-info") }} </span>
                    <div class="bg-danger-100 w-full px-6 py-4 rounded-xl mb-2 mt-4">
                        <div class="text-danger-600 text-xl font-bold">
                            <em class="text-danger-600 fa-regular fa-circle-xmark mr-5" />{{
                                i18n("blocking-anomalies")
                            }}
                        </div>
                    </div>
                    <div class="w-full">
                        <div
                            v-for="(item, index) in blockingAnomalies"
                            :key="item.errorCode"
                            :class="{ 'mt-3': index }"
                        >
                            <div class="flex">
                                <div class="blocking-bullet pr-2">&bull;</div>
                                <div>
                                    {{ item.errorDescription ? item.errorDescription : item.errorCode }} <br />
                                    <!-- councils -->
                                    <div class="d-flex" v-if="item.baseDomainZoneList">
                                        <button
                                            class="mt-2 py-0.5 px-2 border rounded-full text-sm font-semibold nowrap mr-1"
                                            v-for="council in item.baseDomainZoneList"
                                            :key="council.domainZoneId"
                                            @click="selectCouncil(council.domainZoneId)"
                                        >
                                            {{ council.description }}
                                        </button>
                                    </div>
                                </div>
                                <div class="ml-auto">
                                    <div class="flex justify-end pr-3">
                                        <div
                                            class="py-0.5 px-2 bg-gray-300 rounded-full text-sm font-semibold nowrap ihand"
                                        >
                                            {{ i18n("total-farms") + ": " + item.numOfAnomalies }}
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- WARNING ANOMALIES -->
                    <div
                        v-if="warningAnomalies.length > 0"
                        class="bg-warning-100 w-full px-6 py-4 rounded-xl mb-2 mt-5"
                    >
                        <div class="text-warning-600 text-xl font-bold">
                            <em class="text-warning-600 fa-regular fa-triangle-exclamation mr-5" />{{
                                i18n("warning-anomalies")
                            }}
                        </div>
                    </div>
                    <div class="w-full">
                        <div v-for="(item, index) in warningAnomalies" :key="item.errorCode" :class="{ 'mt-3': index }">
                            <div class="flex">
                                <div class="blocking-bullet pr-2">&bull;</div>
                                <div>
                                    {{ item.errorDescription ? item.errorDescription : item.errorCode }} <br />
                                    <!-- councils -->
                                    <div class="d-flex" v-if="item.baseDomainZoneList">
                                        <button
                                            class="mt-2 py-0.5 px-2 border rounded-full text-sm font-semibold nowrap mr-1"
                                            v-for="council in item.baseDomainZoneList"
                                            :key="council.domainZoneId"
                                            @click="selectCouncil(council.domainZoneId)"
                                        >
                                            {{ council.description }}
                                        </button>
                                    </div>
                                </div>
                                <div class="ml-auto">
                                    <div class="flex justify-end pr-3">
                                        <div class="py-0.5 px-2 bg-gray-300 rounded-full text-sm font-semibold nowrap">
                                            {{ i18n("total-farms") + ": " + item.numOfAnomalies }}
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </template>
            <template #footer>
                <div class="w-full">
                    <strong v-if="notOnFixedOpenDate" class="text-danger-500">
                        {{ 
                            i18n(
                                "not-on-fixed-date-warning",
                                { "date": fixedOpenDate }
                            ).toString()
                        }}
                    </strong>
                    <div class="flex" :class="{ 'mt-3': notOnFixedOpenDate }">
                        <abc-button
                            v-if="groupedAnomalies.numOfBlockingAnomalies === 0"
                            class="mr-1"
                            @click="submit"
                            is-success
                        >
                            <em class="abc-icon abc-icon-arrow-up-" /> {{ i18n("publish-crop-plan") }}
                        </abc-button>
                        <abc-button is-secondary is-outlined @click="openEditModal = false">
                            <em class="abc-icon abc-icon-arrow-left-round" /> {{ i18n("cancel") }}
                        </abc-button>
                    </div>
                </div>
            </template>
        </abc-modal>

        <abc-modal
            v-if="openProgressModal"
            @close="openProgressModal = false"
            is-message
            modal-class="w-full md:w-8/12 lg:w-6/12 xxl:w-4/12"
            force-modal
            hide-footer
        >
            <template #body>
                <div class="pt-2 pb-4 flex flex-col w-full">
                    <div
                        class="s-cp-publish-icon mx-auto flex items-center justify-center rounded-full"
                        :class="{
                            'bg-info-100 text-info-300': loading,
                            'bg-success-100 text-success-300': !loading && isPublishSuccess,
                            'bg-danger-100 text-danger-300': !loading && !isPublishSuccess,
                        }"
                        style="width: 80px; height: 80px; font-size: 30px"
                    >
                        <transition
                            name="custom-classes-transition"
                            enter-active-class="animate__animated animate__fadeIn animate__faster"
                            leave-active-class="animate__animated animate__fadeOut animate__faster"
                            mode="out-in"
                        >
                            <div v-if="loading" key="1">
                                <em class="fad fa-cog s-cp-movement-info-rotate" />
                            </div>
                            <em v-else-if="isPublishSuccess" key="2" class="fa fa-check" />
                            <em v-else-if="!isPublishSuccess" key="3" class="fa fa-times" />
                        </transition>
                    </div>
                    <div class="mt-4 w-full">
                        <h3 class="text-lg text-center font-bold text-secondary-600" style="height: 50px">
                            <transition
                                name="custom-classes-transition"
                                enter-active-class="animate__animated animate__fadeIn animate__faster"
                                leave-active-class="animate__animated animate__fadeOut animate__faster"
                                mode="out-in"
                            >
                                <div v-if="loading" key="1">{{ i18n("crop-plan-publishing") }}</div>
                                <div v-else-if="isPublishSuccess" key="2" class="flex flex-col">
                                    <span>{{ i18n("crop-plan-published") }}</span>
                                    <span class="text-base font-normal pt-1">{{
                                        i18n("crop-plan-published-info")
                                    }}</span>
                                </div>
                                <div v-else-if="!isPublishSuccess" key="3" class="flex flex-col">
                                    <span v-if="publishError.errorCode !== 'CREATE_VERSION_EXCEPTION'">{{
                                        i18n("crop-plan-not-published")
                                    }}</span>
                                    <span class="text-base font-normal pt-1">{{ modalMessage }}</span>
                                </div>
                            </transition>
                        </h3>
                    </div>
                    <div class="flex w-full justify-center mt-8 -mb-4" style="height: 45px">
                        <abc-button
                            v-if="!loading"
                            is-info
                            is-big
                            is-outlined
                            @click="openProgressModal = false"
                            :is-disabled="loading"
                        >
                            <em class="abc-icon abc-icon-arrow-left-round" />{{ i18n("close") }}
                        </abc-button>
                    </div>
                </div>
            </template>
        </abc-modal>

        <abc-modal v-if="showRestoreVersionModal" @close="showRestoreVersionModal = false" is-message>
            <template #body>
                {{
                    i18n("restore-version-description", {
                        versionDate: formattedDate(lastCropPlanVersionAvailable.versionDate) || "",
                    })
                }}
            </template>
            <template #footer>
                <abc-button class="mr-2" is-secondary is-outlined @click="showRestoreVersionModal = false">
                    <em class="abc-icon abc-icon-arrow-left-round" /> {{ i18n("cancel") }}
                </abc-button>
                <abc-button @click="restoreCropPlanVersion()" is-danger>
                    <em class="abc-icon abc-icon-arrow-circle" /> {{ i18n("restore-version") }}
                </abc-button>
            </template>
        </abc-modal>

        <abc-modal
            v-if="showEditPublishedCropPlanModal"
            :title="i18n('editing-published-crop-plan-title')"
            force-modal
            modal-class="w-full md:w-8/12 lg:w-6/12 xxl:w-4/12"
            style="z-index: 1000"
        >
            <template #body>
                <div class="w-full flex items-center">
                    {{ i18n("editing-published-crop-plan-message") }}
                </div>
            </template>
            <template #footer>
                <abc-button class="mr-2" is-secondary is-outlined @click="showEditPublishedCropPlanModal = false">
                    <em class="abc-icon abc-icon-arrow-left-round" /> {{ i18n("cancel") }}
                </abc-button>
                <abc-button
                    is-success
                    class="flex"
                    @click="
                        () => {
                            showEditPublishedCropPlanModal = false;
                            editPublishedCropPlanCallback();
                        }
                    "
                >
                    <em class="fal fa-arrow-right" style="margin-right: 7px; margin-top: 1px" />
                    <p>{{ i18n("continue") }}</p>
                </abc-button>
            </template>
        </abc-modal>

        <abc-modal 
            v-if="showRecalculateAnomaliesModal"
            modal-class="w-full md:w-8/12 lg:w-6/12 xxl:w-4/12"
            force-modal
            :title="i18n('anomalies-recalculation')"
        >
            <template #body>
                <div class="py-4 flex flex-col w-full">
                    <span class="font-semibold">
                        {{ i18n("publishing-not-available-anomalies-not-calculated", { date: getSyncReferanceDate}) }}
                    </span>
                </div>
            </template>
            <template #footer>
                <div class="flex">
                    <abc-button class="ml-2" is-success @click="forceSync++">
                        {{
                            i18n("recalculate")
                        }}
                    </abc-button>
                    <abc-button class="ml-2" @click="showRecalculateAnomaliesModal = false">{{ i18n("cancel") }}</abc-button>
                </div>
            </template>
        </abc-modal>
        <app-loading-modal v-if="showAppLoading" />
    </div>
</template>

<script lang="ts">
import { Component, Inject, Watch, Ref, Mixins } from "vue-property-decorator";
import { TranslateResult } from "vue-i18n";
import SingleCropPlanModule, { MODULE_ID } from "../..";
import { FromStore } from "@abaco/web-common/src/app";
import { Business } from "../../models/Business";
import { Configuration, CropPlanDates, GroupedAnomaly } from "../../models/CropPlan";
import { Validable } from "@abaco/web-components/src/components/form/Validable";
import { Version, VersionOut } from "../../models/Version";
import { VBTooltip } from "bootstrap-vue";
import CanEditCheckAndExecute from "../../mixins/CanEditCheckAndExecute";
import DateUtils from "../../mixins/DateUtils";
import cloneDeep from "lodash/cloneDeep";
import { Council } from "../../models/Council";
import SSOModule from "@abaco/sso-web-module/src/abaco-module";
import { pollFunction } from "../../utils/polling";
import AppLoadingModal from "./appLoadingModal.vue";
import { isGCP } from "../../../../../src/main";
import { convertToDate, formatDate } from "../../api/Utils";

@Component({
    directives: {
        "b-tooltip": VBTooltip,
    },
    components: {
        AppLoadingModal,
    },
})
export default class CropPlanPublish extends Mixins(DateUtils, CanEditCheckAndExecute) {
    @Inject() i18n!: (key: string, values?: unknown) => TranslateResult;
    @Inject(MODULE_ID) singleCropPlanModule!: SingleCropPlanModule;
    @Inject(SSOModule.MODULE_ID) ssoWebModule!: SSOModule;

    @FromStore(MODULE_ID) business!: Business;
    @FromStore(MODULE_ID) curConfiguration!: Configuration | null;
    @FromStore(MODULE_ID) curCouncil!: Council | null;
    @FromStore(MODULE_ID) curVersion!: Version | null;
    @FromStore(MODULE_ID) curPointInTime!: Date | null;
    @FromStore(MODULE_ID) lastCropPlanVersionAvailable!: Version | null;
    @FromStore(MODULE_ID) isCropPlanRestoreVersionAvailable!: boolean;
    @FromStore(MODULE_ID) loadingCropPlan!: boolean;
    @FromStore(MODULE_ID) cropPlanDates!: CropPlanDates;
    @FromStore(MODULE_ID) forceSync!: number;

    @Ref("form") form!: Validable;

    private detail: VersionOut = {
        message: undefined,
        havingAcknowledgedAnomalies: false,
        forcePublish: false,
        pointInTime: undefined
    };
    private cropPlanCode = "CROPPLAN";

    private openEditModal = false;
    private openProgressModal = false;
    private loading = false;
    private isPublishSuccess = false;
    private publishError: any | null = null;
    private showRestoreVersionModal = false;
    private groupedAnomalies: GroupedAnomaly | null = null;
    private showAppLoading = false;
    private showRecalculateAnomaliesModal = false;

    @Watch("business")
    private onBusinessChange() {
        this.flCurCorpPlanChangesPending = false;
    }

    private get notOnFixedOpenDate() {
        if(this.cropPlanDates.fixedOpenDate)
            return this.cropPlanDates.fixedOpenDate != formatDate(this.curPointInTime!)
        return false
    }

    private get fixedOpenDate() {
        if(this.cropPlanDates.fixedOpenDate && convertToDate(this.cropPlanDates.fixedOpenDate) != null)
            return this.formattedDate(convertToDate(this.cropPlanDates.fixedOpenDate)!)
        return ""
    }

    private get lastPublicatedVersionDate() {
        if(this.lastCropPlanVersionAvailable?.versionDate && this.lastCropPlanVersionAvailable.versionDate != null)
            return this.formattedDate(this.lastCropPlanVersionAvailable.versionDate) + " " + this.formattedDateWithFormat(this.lastCropPlanVersionAvailable.versionDate, "HH:mm:ss");
        return "";
    }

    private get lastPublicatedVersionReferenceDate() {
        if(this.lastCropPlanVersionAvailable?.versionReferenceDate && convertToDate(this.lastCropPlanVersionAvailable.versionReferenceDate) != null)
            return this.formattedDate(convertToDate(this.lastCropPlanVersionAvailable.versionReferenceDate)!);
        return "";
    }

    private get modalMessage() {
        if (!this.publishError) return this.i18n("crop-plan-not-published-info");

        if (
            this.publishError &&
            this.publishError.status === 500 &&
            this.publishError.errorCode === "CREATE_VERSION_EXCEPTION"
        ) {
            return this.i18n("crop-plan-fail-publish");
        }
        if (this.publishError && this.publishError.errorCode) {
            return this.i18n(this.publishError.errorCode.toLowerCase());
        }

        return this.i18n("unknown-publish-error");
    }

    private async submit() {
        const isValid = this.form.validate();
        if (isValid) {
            this.publishError = null;
            this.isPublishSuccess = true;
            this.loading = true;
            this.openEditModal = false;
            this.openProgressModal = true;
            if (this.detail.message === undefined) this.detail.message = " ";
            if(this.curConfiguration?.ENABLE_PUBLISH_WHEN_NO_CHANGES_PENDING === "TRUE" && this.curPointInTime) {
                this.detail.pointInTime = formatDate(this.curPointInTime)
                this.detail.forcePublish = this.curConfiguration?.ENABLE_PUBLISH_WHEN_NO_CHANGES_PENDING === "TRUE" ? true : false;
            }
            try {
                if (this.curCropPlan) {
                    const newVersion = await this.singleCropPlanModule.versionApi.insertVersion(
                        this.business.businessId,
                        this.curCropPlan.cropPlanId,
                        this.detail
                    );
                    await pollFunction(async () => {
                        const res = await this.singleCropPlanModule.versionApi.getVersions(
                            this.business.businessId,
                            this.curCropPlan!.cropPlanId,
                            null
                        );
                        const lastPubVersion = res.records[0];
                        if (newVersion.version != lastPubVersion?.version) {
                            this.isPublishSuccess = false;
                            this.publishError = {
                                status: 500,
                                errorCode: "CREATE_VERSION_EXCEPTION",
                            };
                        } else {
                            if (newVersion.version === lastPubVersion?.version && !lastPubVersion.flPublished) {
                                return true; // try again after timeout
                            } else {
                                this.curCropPlan = await this.singleCropPlanModule.cropPlanApi.getCropPlanById(
                                    this.business.businessId,
                                    this.curCropPlan!.cropPlanId
                                );
                            }
                        }
                    });
                    this.loading = false;
                    this.flCurCorpPlanChangesPending = !this.isPublishSuccess;
                }
            } catch (error) {
                this.publishError = (error as any).response.data;
                this.isPublishSuccess = false;
                this.loading = false;
            }
            this.detail.message = undefined;
        }
    }

    private delay(time: number) {
        return new Promise((resolve) => setTimeout(resolve, time));
    }

    private async restoreCropPlanVersion() {
        if (!this.curCropPlan) return;
        await this.singleCropPlanModule.versionApi.restoreLastVersion(
            this.business.businessId,
            this.curCropPlan.cropPlanId
        );
        this.showRestoreVersionModal = false;
        this.forceSync++;
        this.curCouncil = cloneDeep(this.curCouncil);
        this.flCurCorpPlanChangesPending = false;
    }

    private async checkCanPublish() {
        if (!this.curCropPlan) {
            console.error("DevError - curCropPlan does not exist");
            return;
        }
        if(
            this.curConfiguration?.CONSTRAINTS_VERSION_TO_SYNC_REF_DATE === "TRUE" && 
            this.anomaliesNotCalculatedAtDate
        ) {
            this.showRecalculateAnomaliesModal = true;
            return;
        }
        this.showAppLoading = true;
        const res = await this.singleCropPlanModule.cropPlanApi.getGroupedAnomalies(
            this.business.businessId,
            this.curCropPlan?.cropPlanId
        );
        this.groupedAnomalies = res;
        this.showAppLoading = false;
        this.openEditModal = true;
    }

    private get blockingAnomalies() {
        return this.groupedAnomalies?.anomalies.filter((it) => it.blocking);
    }

    private get warningAnomalies() {
        return this.groupedAnomalies?.anomalies.filter((it) => !it.blocking);
    }

    private get anomaliesNotCalculatedAtDate() {
        return this.curPointInTime && this.cropPlanDates.lastSyncReferenceDate != formatDate(this.curPointInTime)
    }

    private get getSyncReferanceDate() {
        if(this.cropPlanDates.lastSyncReferenceDate && convertToDate(this.cropPlanDates.lastSyncReferenceDate) != null)
            return this.formattedDate(convertToDate(this.cropPlanDates.lastSyncReferenceDate)!)
        return ""
    }

    private get getisGCP() {
        return isGCP;
    }

    @Watch("warningAnomalies", { immediate: true })
    private onWarningAnomaliesUpdate() {
        this.detail.havingAcknowledgedAnomalies = !!this.warningAnomalies && this.warningAnomalies.length > 0;
    }

    private async selectCouncil(code: string) {
        if (!this.curCropPlan || !this.curPointInTime || this.loadingCropPlan) {
            return;
        }

        if (this.curCouncil?.code == code) {
            this.openEditModal = false;
            return;
        }

        const res = await this.singleCropPlanModule.councilApi.getCouncils(
            this.business ? this.business.businessId : null,
            this.curPointInTime,
            this.curVersion ? this.curVersion.version : null,
            this.curCropPlan.cropPlanId,
            code,
            true
        );
        if (res.records[0]) {
            this.curCouncil = res.records[0];
            this.openEditModal = false;
        }
    }
}
</script>

<style scoped lang="scss">
.s-cp-publish-icon {
    @apply transition duration-200 ease-in-out;
}

.s-cp-movement-info-rotate {
    animation: s-cp-movement-info-rotate 1700ms linear infinite;
}
@keyframes s-cp-movement-info-rotate {
    from {
        transform: rotate(0deg);
    }
    to {
        transform: rotate(360deg);
    }
}
</style>
