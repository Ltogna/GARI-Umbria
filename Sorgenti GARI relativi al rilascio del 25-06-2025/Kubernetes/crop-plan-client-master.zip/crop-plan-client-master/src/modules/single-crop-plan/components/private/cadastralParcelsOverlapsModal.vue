<template>
    <abc-modal modal-class="w-full md:w-10/12 lg:w-8/12 xl:w-6/12" :title="i18n('overlaps')" @close="close">
        <template #body>
            <abc-loader v-if="loading" />
            <div v-else-if="overlaps.length > 0" class="py-1">
                <div class="px-2" style="max-height: calc(100vh - 250px); overflow-y: auto">
                    <div
                        v-for="(item, index) in overlaps"
                        :key="index"
                        class="w-full grid grid-cols-8 gap-3"
                        :class="{ 'mb-5': overlaps.length && index < overlaps.length - 1 }"
                    >
                        <div
                            class="col-span-3 flex rounded justify-between bg-bg-500 p-4 text-sm font-semibold gap-5 items-center"
                        >
                            <div class="flex flex-col text-secondary-500">
                                <span>{{ i18n("council") }}</span
                                ><span>{{ i18n("sheet") }}</span
                                ><span>{{ i18n("parcel-l") }}</span>
                            </div>
                            <div class="flex-1 flex flex-col" style="min-width: 0">
                                <span
                                    style="white-space: nowrap; overflow: hidden; text-overflow: ellipsis"
                                    :title="item.domainZoneDescription1"
                                >
                                    {{ item.domainZoneDescription1 }}
                                </span>
                                <span>{{ item.sectorBlock1 }}</span>
                                <span>{{ item.parcel1 }}</span>
                            </div>
                        </div>
                        <div
                            class="col-span-3 flex rounded justify-between bg-bg-500 p-4 text-sm font-semibold gap-5 items-center"
                        >
                            <div class="flex flex-col text-secondary-500">
                                <span>{{ i18n("council") }}</span
                                ><span>{{ i18n("sheet") }}</span
                                ><span>{{ i18n("parcel-l") }}</span>
                            </div>
                            <div class="flex-1 flex flex-col" style="min-width: 0">
                                <span
                                    style="white-space: nowrap; overflow: hidden; text-overflow: ellipsis"
                                    :title="item.domainZoneDescription1"
                                >
                                    {{ item.domainZoneDescription2 }}
                                </span>
                                <span>{{ item.sectorBlock2 }}</span>
                                <span>{{ item.parcel2 }}</span>
                            </div>
                        </div>
                        <div class="col-span-2 flex flex-col gap-3">
                            <div
                                class="nowrap flex rounded w-full gap-1 px-3 py-2 justify-between bg-danger-50 text-sm text-danger-500 font-semibold"
                            >
                                <span style="white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">{{ i18n("overlap-area") }}</span>
                                <span class="text-danger-600 shrink-0">{{ formattedArea(item.overlapAreaSqm) }} {{ areaLabel() }}</span>
                            </div>
                            <abc-button
                                v-if="item.geom"
                                class="font-semibold text-lg h-9"
                                isOutlined
                                isInfo
                                @click="showOverlapOnMap(item)"
                                style="min-width: 0;"
                            >
                                <em class="fa-regular fa-location-dot mr-2 text-info-200"></em>
                                {{ i18n("view-title") }}
                            </abc-button>
                        </div>
                    </div>
                </div>
            </div>
            <div v-else>
                <abc-no-data-found />
            </div>
        </template>
    </abc-modal>
</template>

<script lang="ts">
import { FromStore } from "@abaco/web-common/src/app";
import { Component, Mixins, Inject, Watch } from "vue-property-decorator";
import { TranslateResult } from "vue-i18n";
import SingleCropPlanModule, { MODULE_ID } from "../..";
import AreaUtils from "../../mixins/AreaUtils";
import { CadastralOverlap } from "../../models/Declaration";
import { Business } from "../../models/Business";
import { Council } from "../../models/Council";
import { CropPlan } from "../../models/CropPlan";
import { Version } from "../../models/Version";

@Component
export default class CadastralParcelsOverlapsModal extends Mixins(AreaUtils) {
    @Inject(MODULE_ID) singleCropPlanModule!: SingleCropPlanModule;
    @Inject() i18n!: (key: string, values?: unknown) => TranslateResult;

    @FromStore(MODULE_ID) business!: Business;
    @FromStore(MODULE_ID) curCropPlan!: CropPlan | null;
    @FromStore(MODULE_ID) curCouncil!: Council | null;
    @FromStore(MODULE_ID) curVersion!: Version | null;
    @FromStore(MODULE_ID) curPointInTime!: Date;
    @FromStore(MODULE_ID) curCadastralOverlapData!: CadastralOverlap | null;

    private loading = false;
    private overlaps: CadastralOverlap[] = [];

    mounted() {
        this.updateList();
    }

    @Watch("curCouncil")
    private updateList() {
        if (!this.curCropPlan || !this.curCouncil) {
            console.error("Missing data for api request");
            this.overlaps = [];
            return;
        }
        this.loading = true;
        this.$nextTick(() => {
            if (!this.curCropPlan || !this.curCouncil) return;
            this.singleCropPlanModule.cadastralParcelApi
                .getAllCadastralOverlaps(
                    this.business.businessId,
                    this.curCropPlan.cropPlanId,
                    this.curCouncil.domainZoneId,
                    this.curPointInTime,
                    this.curVersion ? this.curVersion?.version : null
                )
                .then((res) => {
                    this.overlaps = res.records;
                    this.loading = false;
                });
        });
    }

    private showOverlapOnMap(overlap: CadastralOverlap) {
        this.curCadastralOverlapData = overlap;
        this.close();
    }

    private close() {
        this.$emit("close");
    }
}
</script>
