<template>
    <layout
        :title="this.curParcel.notes ? i18n('edit-notes') : i18n('add-notes')"
        :show-back="true"
ì        @back="$emit('close')"
    >
        <abc-form ref="form" class="flex flex-col h-full w-full" @submit="submit">
            <div class="flex flex-col w-full h-full">
                <div class="flex w-full mt-4 mb-4">
                    <abc-input
                        class="w-full px-4"
                        v-model="notes"
                    />
                </div>
            </div>
            <div class="flex flex-wrap justify-center border-t sticky bottom-0 py-3 -mt-2">
                <div>
                    <abc-button
                        class="mr-2 mt-2"
                        is-secondary
                        is-outlined
                        @click="$emit('close')"
                        :is-disabled="disableFormButtons"
                    >
                        <em class="abc-icon abc-icon-arrow-left-round" /> {{ i18n("back") }}
                    </abc-button>
                </div>
                <div>
                    <abc-button
                        class="mr-2 mt-2"
                        @click="submit()"
                        is-success
                        :is-disabled="!notes || disableFormButtons"
                    >
                        <em class="abc-icon abc-icon-check" /> {{ i18n("save") }}
                    </abc-button>
                </div>
            </div>
        </abc-form>

    </layout>
</template>

<script lang="ts">
import { Component, Inject, Mixins, Ref } from "vue-property-decorator";
import { TranslateResult } from "vue-i18n";
import SingleCropPlanModule, { MODULE_ID } from "../..";
import { FromStore, ToastOptions } from "@abaco/web-common/src/app";
import { Business } from "../../models/Business";
import { Parcel, Plot } from "../../models/Plot";
import DateUtils from "../../mixins/DateUtils";
import Layout from "../private/mapSidebarModal.vue";
import { Validable } from "@abaco/web-components/src/components/form/Validable";
import { CropPlan } from "../../models/CropPlan";

@Component({
    components: {
        Layout,
    },
})
export default class SingleCpParcelNoteEdit extends Mixins(DateUtils) {
    @Inject() i18n!: (key: string, values?: unknown) => TranslateResult;
    @Inject() toast!: (message: string, options?: ToastOptions) => TranslateResult;
    @Inject(MODULE_ID) singleCropPlanModule!: SingleCropPlanModule;

    @FromStore(MODULE_ID) business!: Business;
    @FromStore(MODULE_ID) curPlot!: Plot | null;
    @FromStore(MODULE_ID) curCropPlan!: CropPlan;
    @FromStore(MODULE_ID) curParcel!: Parcel;


    @Ref("form") form!: Validable;

    private disableFormButtons = false;
    private notes: string | null = null

    mounted() {
        if (!this.curParcel) {
            return;
        }
        this.notes = this.curParcel.notes
    }

    private async submit() {
        const isValid = this.form.validate();
        if (isValid && this.notes) {
            this.disableFormButtons = true;
            try {
                if(this.curParcel && this.curPlot){
                    await this.singleCropPlanModule.plotApi.editParcelNotes(
                        this.business.businessId,
                        this.curCropPlan.cropPlanId,
                        this.curParcel.code,
                        this.notes
                    );
                    
                    const parcels = this.curPlot.parcelIntersections.filter((p) => p.code != this.curParcel.code);
                    const tempParcel = {...this.curParcel, notes: this.notes };
                    const tempPlot = { ...this.curPlot, parcelIntersections: [...parcels, tempParcel]};
                    this.$emit("updated", tempPlot);
                    this.toast(this.i18n("plot-updated").toString(), { type: "success" });
                }
            } catch (error) {
                this.toast(error as any, { type: "error" });
            } finally {
                this.disableFormButtons = false;
            }
        }
    }
}
</script>
