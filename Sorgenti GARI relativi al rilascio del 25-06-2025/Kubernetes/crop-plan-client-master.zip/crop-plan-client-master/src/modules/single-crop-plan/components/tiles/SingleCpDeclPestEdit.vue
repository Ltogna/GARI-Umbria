<template>
    <tile :title="i18n('edit-decl-pest')" noContainerStyled>
        <div class="flex w-full h-full overflow-auto">
            <div v-if="!loading" class="flex flex-col px-4 py-6 sm:w-full md:w-full lg:w-5/12 xxl:w-4/12 mx-auto">
                <abc-form ref="form" class="flex flex-col w-full" @submit="submit">
                    <!-- PEST LIST -->
                    <div class="flex w-full mb-4">
                        <abc-autocomplete
                            class="w-full mr-2"
                            :label="i18n('pest-title')"
                            :value="selectedPest"
                            itemId="pestCode"
                            :items="pestsPage.records"
                            :stringify="(item) => (item ? item.pestName : null)"
                            :search.sync="searchPest"
                            maxHeight="300px"
                            buttons
                            @input="updateSelectedPest"
                            :rules="[mandatoryRule]"
                        >
                            <template #items="{ item }">
                                <div>{{ item.pestName }}</div>
                            </template>
                            <template>
                                <div v-if="pestsLoading" class="flex justify-center items-center h-12">
                                    <abc-loader :size="32" />
                                </div>
                                <div
                                    v-if="!pestsLoading && pestsPage.records.length === 0"
                                    class="flex justify-center items-center h-12"
                                >
                                    <abc-no-data-found />
                                </div>
                                <div
                                    v-if="
                                        !pestsLoading &&
                                        pestsPage.records.length > 0 &&
                                        pestsPage.haveMore
                                    "
                                    class="flex justify-center items-center h-12"
                                >
                                    <abc-refine-filter />
                                </div>
                            </template>
                            <template #buttons>
                                <abc-tool-button
                                    is-secondary
                                    @click="
                                        searchPest = '';
                                        selectedPest = null;
                                    "
                                    :title="i18n('clear-field')"
                                >
                                    <em class="abc-icon abc-icon-x text-xs"></em>
                                </abc-tool-button>
                            </template>
                        </abc-autocomplete>
                    </div>

                    <div class="flex w-full">
                        <abc-input
                            class="w-9/12 pr-2"
                            v-model="detail.measuresApplied"
                            autocomplete="off"
                            :label="i18n('pest-measures-applied')"
                            ref="pestMeasuresApplied"
                            :rules="[mandatoryRule]"
                        >
                        </abc-input>
                        <abc-input
                            right-tools
                            text-right
                            is-numeric
                            v-model="detail.areaAffected"
                            autocomplete="off"
                            :label="i18n('pest-area-affected-perc')"
                            ref="pestAreaAffected"
                            :rules="[mandatoryRule, percentageRule]"
                        >
                            <template #right>%&thinsp;</template>
                        </abc-input>
                    </div>

                    <abc-form-buttons
                        class="pb-6 mt-4"
                        @save="submit"
                        @cancel="close"
                        :has-continue="false"
                        :disable-confirm-button="disableFormButtons"
                    />
                </abc-form>
            </div>
            <abc-loader v-if="loading" scope="fixed" />
        </div>
    </tile>
</template>

<script lang="ts">
import { Component, Inject, Watch, Mixins, Ref } from "vue-property-decorator";
import { TranslateResult } from "vue-i18n";
import SingleCropPlanModule, { MODULE_ID } from "../..";
import { FromStore, ToastOptions } from "@abaco/web-common/src/app";
import { Business } from "../../models/Business";
import { Plot } from "../../models/Plot";
import DateUtils from "../../mixins/DateUtils";
import { Validable } from "@abaco/web-components/src/components/form/Validable";
import { Configuration, CropPlan } from "../../models/CropPlan";
import { Council } from "../../models/Council";
import { PestEntry, toPestOut, PestOut, Pest } from "../../models/Declaration";
import AreaUtils from "../../mixins/AreaUtils";
import { VBTooltip } from "bootstrap-vue";
import cloneDeep from "lodash/cloneDeep";
import { EmptyMaxPagedResults, MaxPagedResults } from "@abaco/web-common/src/Paging";
import { Debounce } from "vue-debounce-decorator";
import { Version } from "../../models/Version";
import { ValidationMessage } from "../../models/Utils";
import { formatDate } from "../../api/Utils";

@Component({
    directives: {
        "b-tooltip": VBTooltip,
    },
})
export default class SingleCpDeclPesticideEdit extends Mixins(DateUtils, AreaUtils) {
    @Inject() i18n!: (key: string, values?: unknown) => TranslateResult;
    @Inject() toast!: (message: string, options?: ToastOptions) => TranslateResult;
    @Inject(MODULE_ID) singleCropPlanModule!: SingleCropPlanModule;

    @FromStore(MODULE_ID) business!: Business;
    @FromStore(MODULE_ID) curPlot!: Plot | null;
    @FromStore(MODULE_ID) curPlots!: Plot[];
    @FromStore(MODULE_ID) curPointInTime!: Date;
    @FromStore(MODULE_ID) curCropPlan!: CropPlan | null;
    @FromStore(MODULE_ID) curCouncil!: Council | null;
    @FromStore(MODULE_ID) editPlotPolygonDrawn!: boolean;
    @FromStore(MODULE_ID) curVersion!: Version | null;
    @FromStore(MODULE_ID) hideFieldName!: boolean;
    @FromStore(MODULE_ID) curConfiguration!: Configuration | null;
    @FromStore(MODULE_ID) curPest!: PestEntry | null;
    @FromStore(MODULE_ID) curPlotPestUpdated!: boolean;

    @Ref("form") form!: Validable;

    private detail: PestOut = {
        pestCode: undefined,
        areaAffected: null,
        measuresApplied: null,
        date: undefined,
    };

    private loading = true;
    private disableFormButtons = false;
    private validationMessages: ValidationMessage[] = [];

    private pestsPage: MaxPagedResults<unknown> = new EmptyMaxPagedResults();
    private pestsLoading = false;
    private searchPest: string | null = null;
    private curPestQt: number | null = null;
    private selectedPest: Pest | null = null;
    private isInit = true;

    async mounted() {
        if (this.curPest) {
            const curPestCopy = cloneDeep(this.curPest);
            this.detail = toPestOut(curPestCopy);
            if (this.curPest.entryDate) this.detail.date = formatDate(this.curPest.entryDate);
            this.selectedPest = {
                pestName: this.curPest.pestName,
                pestCode: this.curPest.pestCode
            };
            await this.triggerPestSearch();
            this.loading = false;
        }
    }

    @Watch("searchPest")
    @Debounce(300)
    private async triggerPestSearch() {
        if (!this.curCropPlan || !this.searchPest) return;
        this.pestsLoading = true;
        this.pestsPage = new EmptyMaxPagedResults();
        let page = await this.singleCropPlanModule.cropPlanApi.getPestList(
            this.business.businessId,
            this.curCropPlan.cropPlanId,
            this.searchPest.trim().toUpperCase(),
            this.curPest ? this.curPest.declaration.landuse.code : null
        );
        if (page.count === 1 && this.searchPest === page.records[0].pestName) {
            const res = page.records[0];
            page = await this.singleCropPlanModule.cropPlanApi.getPestList(
                this.business.businessId,
                this.curCropPlan.cropPlanId,
                null,
                this.curPest ? this.curPest.declaration.landuse.code : null
            );
            page.records = page.records.filter((l) => l.pestCode !== res.pestCode);
            page.records.unshift(res);
            if (this.selectedPest) {
                this.selectedPest = { ...this.selectedPest };
            }
        }
        this.pestsPage = page;
        this.pestsLoading = false;
    }
    private updateSelectedPest(value: Pest) {
        this.selectedPest = value;
    }

    private async submit() {
        const isValid = this.form.validate();
        if (isValid) {
            this.disableFormButtons = true;
            await this.updatePest();
        }
    }

    private async updatePest() {
        try {
            const detailOut: PestOut = this.detail;
            if (!this.selectedPest || !this.selectedPest.pestCode) return;
            detailOut.pestCode = this.selectedPest.pestCode;
            if (this.curPest && this.curPest.plotCode && this.curCropPlan && this.curCouncil) {
                await this.singleCropPlanModule.cropPlanApi.updatePest(
                    this.business.businessId,
                    this.curCropPlan.cropPlanId,
                    this.curCouncil.domainZoneId,
                    this.curPest.plotCode,
                    this.curPest.declCode,
                    this.curPest.pestEntryCode,
                    detailOut
                );
                this.$emit("updated");
                this.$emit("close-current-view");
            }
        } catch (error) {
            this.toast(error as any, { type: "error" });
        } finally {
            this.disableFormButtons = false;
        }
    }

    private close() {
        this.$emit("close-current-view");
    }

    private mandatoryRule = (v: unknown) => !!v || this.i18n("valid.mandatory-field");
    
    private percentageRule = (v: string | null) =>
        (v && (parseInt(v) < 0 || parseInt(v) > 100)) || v == "0" ? this.i18n("between-0-and-100-rule") : null;
}
</script>

<style lang="scss" scoped></style>
