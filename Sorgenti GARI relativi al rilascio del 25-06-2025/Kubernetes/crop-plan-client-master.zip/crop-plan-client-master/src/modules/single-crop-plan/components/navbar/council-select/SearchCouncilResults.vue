<template>
    <div class="h-full w-full flex flex-col overflow-hidden">
        <abc-loader v-if="loading || loadingCropPlan" class="pt-4" />
        <template v-else>
            <abc-table
                v-if="page.records.length > 0 && curCropPlan && business"
                class="px-4"
                style="margin-top: -1px"
                :items="page.records"
                item-id="domainZoneId"
                border-less
                hide-no-data
                hasFooter
                @select="onSelect"
                :selected-item="curCouncil"
            >
                <template #items="{ item }">
                    <td v-if="showMapPreview" class="cursor-pointer minimap">
                        <single-cp-map-preview :mbr="item.mbr" :minimapMode="true" :domainZoneId="item.domainZoneId" />
                    </td>
                    <td class="cursor-pointer">{{ item.description }}</td>
                </template>
                <template #footer>
                    <div class="relative mt-4 mb-4">
                        <abc-refine-filter v-if="page.haveMore" />
                    </div>
                </template>

                <!-- <template #footer>
                    <div class="relative mt-4 mb-4">
                        <abc-infinite-support :dataProvider="loadNextpage">
                            <template #no-results>
                                <p
                                    v-if="!filter || loading"
                                    class="flex justify-center items-center text-label-secondary h-16 mb-8"
                                >
                                    {{ i18n("search-for-a-council") }}
                                </p>
                                <abc-no-data-found v-else />
                            </template>
                        </abc-infinite-support>
                    </div>
                </template> -->
            </abc-table>

            <div v-if="((page && page.records.length === 0) || !page) && !filter" class="relative mt-4 mb-4">
                <p class="flex justify-center items-center text-label-primary h-16 mb-8">
                    <em
                        class="abc-icon abc-icon-exclamation-point-circle text-secondary-100 text-3xl pr-3"
                        style="margin-top: -1px"
                    />
                    <template v-if="curCropPlan && (!filterBySubject || (filterBySubject && business))">
                        {{ i18n("no-council-for-business") }}
                    </template>
                    <template v-else-if="!curCropPlan && business">
                        {{ i18n("select-a-crop-plan-first") }}
                    </template>
                    <template v-else-if="!business">
                        {{ i18n("select-a-farm-first") }}
                    </template>
                </p>
            </div>
        </template>
    </div>
</template>

<script lang="ts">
import { Vue, Component, Prop, Inject, Watch } from "vue-property-decorator";
import SingleCropPlanModule, { MODULE_ID } from "../../../index";
import { Council } from "../../../models/Council";
import { TranslateResult } from "vue-i18n";
import { FromStore } from "@abaco/web-common/src/app";
import { Debounce } from "vue-debounce-decorator";
import { Version } from "../../../models/Version";
import { Business } from "../../../models/Business";
import { Configuration, CropPlan } from "../../../models/CropPlan";
import { MaxPagedResults, EmptyMaxPagedResults } from "@abaco/web-common/src/Paging";
import SingleCpMapPreview from "../../mapComponent/SingleCPMapPreview.vue";
import { LayerDef } from "@abaco/iacs-map-module/src/modules/map-module/Layer/GenericLayer";

@Component({
    components: {
        SingleCpMapPreview,
    },
})
export default class SearchCouncilResults extends Vue {
    @Inject() i18n!: (key: string, values?: unknown) => TranslateResult;
    @Inject(MODULE_ID) singleCropPlanModule!: SingleCropPlanModule;

    @Prop() filter!: string;
    @Prop() triggerLoad!: number;
    @Prop({ type: Boolean }) filterBySubject!: boolean;

    @FromStore(MODULE_ID) curCouncil!: Council | null;
    @FromStore(MODULE_ID) curVersion!: Version | null;
    @FromStore(MODULE_ID) curPointInTime!: Date | null;
    @FromStore(MODULE_ID) curCropPlan!: CropPlan | null;
    @FromStore(MODULE_ID) business!: Business | null;
    @FromStore(MODULE_ID) resetCouncil!: number;
    @FromStore(MODULE_ID) curConfiguration!: Configuration | null;
    @FromStore(MODULE_ID) flShowCropPlanProgressBar!: boolean;
    @FromStore(MODULE_ID) loadingCropPlan!: boolean;
    @FromStore(MODULE_ID) forceSearchCouncil!: number;

    private page: MaxPagedResults<Council> = new EmptyMaxPagedResults();
    private loading = false;
    private get showMapPreview() {
        return this.curConfiguration?.ENABLE_COUNCILS_MINIMAP_PREVIEW === "TRUE";
    }

    mounted() {
        if (this.business && this.curPointInTime) {
            this.resetAndLoad();
        }
    }

    @Watch("curPointInTime")
    private onCurPointInTimeUpdate() {
        if (((this.filterBySubject && this.business) || !this.filterBySubject) && this.curPointInTime) {
            this.resetAndLoad();
            this.curCouncil = this.page.records.find((p) => p.domainZoneId === this.curCouncil?.domainZoneId) || null;
            if(!this.curCouncil) this.forceSearchCouncil++;
        }
    }

    @Watch("business")
    @Watch("curVersion")
    @Watch("filterBySubject")
    private onUpdateFilter() {
        this.page = new EmptyMaxPagedResults();
        if (((this.filterBySubject && this.business) || !this.filterBySubject) && this.curPointInTime) {
            this.resetAndLoad();
        }
    }

    @Watch("filter")
    onFilterChange() {
        this.loading = true;
        this.waitAndReset();
    }

    @Debounce(400)
    waitAndReset() {
        this.resetAndLoad();
    }

    @Watch("resetCouncil")
    async doResetCouncil() {
        await this.resetAndLoad();
        this.curCouncil = this.page.records.find((p) => p.domainZoneId === this.curCouncil?.domainZoneId) || null;
    }

    @Watch("triggerLoad")
    @Watch("curCropPlan.cropPlanId")
    @Watch("loadingCropPlan")
    @Debounce(100)
    async resetAndLoad() {
        if (!this.curCropPlan || !this.curPointInTime || this.loadingCropPlan) {
            this.page = new EmptyMaxPagedResults();
            return;
        }
        this.loading = true;
        this.page = await this.singleCropPlanModule.councilApi.getCouncils(
            this.business ? this.business.businessId : null,
            this.curPointInTime,
            this.curVersion ? this.curVersion.version : null,
            this.curCropPlan.cropPlanId,
            this.filter,
            this.filterBySubject
        );
        if (this.page.count > 1) this.flShowCropPlanProgressBar = true;
        this.loading = false;
    }

    private onSelect(index: number) {
        this.$emit("select", this.page.records[index]);
    }
}
</script>

<style lang="scss" scoped>
td.minimap {
    width: 6rem;
    > .map-preview {
        width: 6rem;
        height: 6rem;
    }
}
</style>
