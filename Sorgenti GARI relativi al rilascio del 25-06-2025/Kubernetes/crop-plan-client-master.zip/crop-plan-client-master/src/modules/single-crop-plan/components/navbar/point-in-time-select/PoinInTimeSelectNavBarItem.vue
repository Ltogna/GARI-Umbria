<template>
    <div>
        <div
            v-if="
                (curConfiguration.DISABLE_CHANGE_DATE === 'TRUE' && !showCropPlanNotAccessibleModal) ||
                (curConfiguration.DISABLE_CHANGE_DATE_WHEN_READ_ONLY === 'TRUE' && curCropPlan && curCropPlan.readOnly)
            "
            class="abc-nav-bar-item fake w-full md:w-auto no-select mb-1 md:mb-0 ml-0 md:ml-3"
        >
            <div class="flex flex-grow">
                <div class="abc-nav-bar-item-icon">
                    <em class="fal fa-calendar mr-1" />
                </div>
                <div class="abc-nav-bar-item-text">
                    <p>{{ label }}</p>
                </div>
            </div>
        </div>
        <nav-bar-item
            v-else-if="!showCropPlanNotAccessibleModal && !showCannotUseCropPlan"
            v-show="!showCropPlanSyncModal && curCropPlan"
            v-model="pointInTimeNavBarFilterOpen"
            custom-class="w-8/12 lg:w-5/12 xxl:w-3/12"
        >
            <template #label>
                <abc-nav-bar-item :opened="pointInTimeNavBarFilterOpen">
                    <template #icon>
                        <em class="fal fa-calendar mr-1" />
                    </template>
                    <p>{{ label }}</p>
                </abc-nav-bar-item>
            </template>
            <abc-nav-bar-item-panel title="select-point-in-time" i18nKeys>
                <div class="p-2 mx-auto py-3 flex justify-center single-cp-date-selector">
                    <div class="flex flex-col">
                        <abc-date-picker
                            v-if="availableCropPlanTypes"
                            :value="curPointInTime"
                            @input="onPointInTimeChange"
                            class="flex justify-center"
                            hide-delete
                            :rangeMin="getPointInTimeRangeMin"
                            :rangeMax="getPointInTimeRangeMax"
                            hasAdditionalActions
                            hideNotAvailableDates
                            hideToday
                        >
                            <template #additionalActions>
                                <abc-button
                                    v-if="isSetToFixedOpenDateVisible && !pointInTimeIsAtFixedOpenDate"
                                    class="h-8 text-sm mr-1 flex w-6/12 btn-fixed-date ml-auto"
                                    @click="setToFixedOpenDate"
                                    isOutlined
                                >
                                    {{ i18n("date-reference") }}
                                </abc-button>
                            </template>
                        </abc-date-picker>
                    </div>
                </div>
            </abc-nav-bar-item-panel>
        </nav-bar-item>
        <abc-modal
            v-if="showConfirmDateChangeModal"
            modal-class="w-full md:w-8/12 lg:w-6/12 xxl:w-4/12"
            style="z-index: 1000"
            force-modal
            :title="i18n('anomalies-recalculation')"
        >
            <template #body>
                <div class="pt-2 pb-4 flex flex-col w-full">
                    <span v-if="curConfiguration.ENABLE_CHANGE_DATE_CONFIRM === 'TRUE' && pointInTimeIsAtFixedOpenDate">
                        {{ i18n("change-point-in-time-confirm", { date: fixedOpenDate }).toString() }}
                    </span>
                    <div v-if="constrainsVersionToSyncRefDate">
                        <abc-checkbox
                            v-model="flSyncToRecalcAnomalies"
                            class="py-3"
                            :label="i18n('recalc-anomalies-on-date-change', { date: getNewPointInTime }).toString()"
                        />
                        <span class="text-warning-600 font-semibold italic">
                            {{ i18n("anomalies-recalculation-warning") }}
                        </span>
                    </div>
                </div>
            </template>
            <template #footer>
                <div class="flex">
                    <abc-button class="ml-2" is-success @click="confirmPointInTimeChange">{{
                        i18n("confirm")
                    }}</abc-button>
                    <abc-button class="ml-2" @click="cancelPointInTimeChange">{{ i18n("cancel") }}</abc-button>
                </div>
            </template>
        </abc-modal>
    </div>
</template>

<script lang="ts">
import { Component, Inject, Watch, Mixins } from "vue-property-decorator";
import { TranslateResult } from "vue-i18n";
import { FromStore } from "@abaco/web-common/src/app";
import { MODULE_ID } from "../../../index";
import DateUtils from "../../../mixins/DateUtils";
import PointInTimeChange from "../../../mixins/PointInTimeChange";

@Component
export default class PointInTimeSelectNavBarItem extends Mixins(DateUtils, PointInTimeChange) {
    @FromStore(MODULE_ID) pointInTimeNavBarFilterOpen!: boolean;
    @FromStore(MODULE_ID) showCannotUseCropPlan!: boolean;
    @FromStore(MODULE_ID) showCropPlanNotAccessibleModal!: boolean;
    @FromStore(MODULE_ID) showCropPlanSyncModal!: boolean;

    private loading = false;
    private openedAtFixedDate = false;

    async mounted() {
        if (!this.curPointInTime && !this.openedAtFixedDate) this.curPointInTime = new Date();
    }

    @Watch("curPointInTime")
    private onUpdateValue() {
        this.pointInTimeNavBarFilterOpen = false;
    }

    get label(): TranslateResult {
        return this.curPointInTime ? this.formattedDate(this.curPointInTime) : this.i18n("select-point-in-time");
    }

    private get isSetToFixedOpenDateVisible() {
        return !!this.cropPlanDates?.fixedOpenDate;
    }
}
</script>

<style lang="scss">
.single-cp-date-selector .abc-datepicker-wrapper {
    border: 0;
}

.btn-fixed-date {
    @apply text-label-primary;
    justify-content: center !important;
    border: 1px solid var(--color-border) !important;
    border-radius: 4px !important;
    min-width: auto !important;
}
.btn-fixed-date:hover {
    @apply bg-bg-500;
}
</style>
