<template>
    <div v-if="!loading">
        <div v-for="formType in activeTypes" :key="formType">
            <abc-accordion
                v-model="formsOpen[formType]"
                :forceUpdate="accordionsForceUpdate"
                @input="onAccorditionStatusChange"
                class="w-full permanentcrop-accordion"
            >
                <template #title>
                    <div class="w-full flex mr-2">
                        <abc-checkbox
                            v-if="enableHeaderCheckbox"
                            :value="permanentCropFormChecked"
                            @input="permanentCropFormChecked = !permanentCropFormChecked"
                            class="mr-3"
                        ></abc-checkbox>
                        <div>{{ formsTitles[formType] }}</div>
                    </div>
                </template>
                <template #content>
                    <div class="permanentcrop-accordion-content p-4">
                        <component
                            :is="formsComponents[formType]"
                            v-model="formsData[formType]"
                            :fieldsValues="formsFieldsValues[formType]"
                            @bubbleEmit="bubbleEmit"
                            @heightUpdated="accordionsForceUpdate++"
                            :declarationArea="areaSqm ? areaSqm : null"
                            :disableRequirementCheck="disableRequirementCheck"
                            :disableNotCheckedFields="enableHeaderCheckbox && !permanentCropFormChecked"
                            :readonly="readonly"
                            :isNew="isNew"
                            :disableCheckOnMandatoryDeclFields="disableCheckOnMandatoryDeclFields"
                        />
                    </div>
                </template>
            </abc-accordion>
            <subscription-component
                v-if="getSubscriptionCodesFromPermanentCropFormData(formsData[formType]).length > 0"
                :subscriptionCodes="getSubscriptionCodesFromPermanentCropFormData(formsData[formType])"
                :externalCode="getExternalCodesFromPermanentCropFormData(formsData[formType])"
                @onSubscriptionLoaded="() => {subscriptionAreLoading = false;}"
            />
            <abc-loader
                v-if="subscriptionAreLoading && getSubscriptionCodesFromPermanentCropFormData(formsData[formType]).length > 0"
            />
        </div>
    </div>
</template>

<script lang="ts">
import { Prop, Component, Mixins, Inject, Watch } from "vue-property-decorator";
import { TranslateResult } from "vue-i18n";
import SingleCropPlanModule, { MODULE_ID } from "../..";
import { FromStore } from "@abaco/web-common/src/app";
import DateUtils from "../../mixins/DateUtils";
import { Business } from "../../models/Business";
import { CropPlan } from "../../models/CropPlan";
import { Council } from "../../models/Council";
import {
    PermanentCropFieldValues,
    PermanentCropForm,
    PermanentCropFormData,
    PermanentCropFormMap,
    PermanentCropFormType,
} from "../../models/PermanentCropForm";
import VineyardPermanentCropForm from "../permanentCropForms/Vineyard.vue";
import SubscriptionComponent from "./SubscriptionComponent.vue";

@Component({
    components: {
        VineyardPermanentCropForm,
        SubscriptionComponent,
    },
})
export default class PermanentCropForms extends Mixins(DateUtils) {
    @Inject() i18n!: (key: string, values?: unknown) => TranslateResult;
    @Inject(MODULE_ID) singleCropPlanModule!: SingleCropPlanModule;

    @FromStore(MODULE_ID) business!: Business;
    @FromStore(MODULE_ID) curCropPlan!: CropPlan | null;
    @FromStore(MODULE_ID) curCouncil!: Council | null;

    @Prop() value!: PermanentCropForm[] | null;
    @Prop() forceUpdate!: number;
    @Prop() areaSqm!: number;
    @Prop({default: false}) disableRequirementCheck!: boolean;
    @Prop({default: false}) readonly!: boolean;
    @Prop({ default: false }) isNew!: boolean;
    @Prop({ default: false }) enableHeaderCheckbox!: boolean;
    @Prop({ default: false }) disableCheckOnMandatoryDeclFields!: boolean;

    private loading = true;

    private isAccorditionOpened = false;
    private accordionsForceUpdate = 0;

    private subscriptionAreLoading = false;
    private permanentCropFormChecked = false;

    private formsTitles: PermanentCropFormMap<string> = {
        VINEYARD_FORM: this.i18n("pcf-vineyard-title") as string,
    };

    private formsComponents: PermanentCropFormMap<Vue.Component> = {
        VINEYARD_FORM: VineyardPermanentCropForm,
    };

    private formsOpen: PermanentCropFormMap<boolean> = {
        VINEYARD_FORM: false,
    };

    private formsActive: PermanentCropFormMap<boolean> = {
        VINEYARD_FORM: false,
    };

    private formsCode: PermanentCropFormMap<string | null> = {
        VINEYARD_FORM: null,
    };

    private formsData: PermanentCropFormMap<PermanentCropFormData | null> = {
        VINEYARD_FORM: null,
    };

    private formsFieldsValues: PermanentCropFormMap<{ [k: string]: PermanentCropFieldValues[] } | null> = {
        VINEYARD_FORM: null,
    };

    private get activeTypes(): PermanentCropFormType[] {
        return Object.entries(this.formsActive)
            .filter(([, active]) => active)
            .map(([type]) => type as PermanentCropFormType);
    }

    private onAccorditionStatusChange(e: boolean) {
        this.isAccorditionOpened = e;
    }

    async mounted() {
        const requests: Promise<any>[] = [];
        // get fields options
        this.activeTypes.forEach((formType) => {
            if (!this.formsFieldsValues[formType] && this.curCropPlan)
                requests.push(
                    this.singleCropPlanModule.permanentCropFormApi
                        .getFieldsCodes(this.business.businessId, this.curCropPlan.cropPlanId, formType)
                        .then((fields) => {
                            if (fields && fields.length) {
                                const fieldsObject: { [k: string]: PermanentCropFieldValues[] } = {};
                                fields.forEach((field) => {
                                    const fieldCode = field.fieldCode
                                        .split("_")
                                        .map((i) => i.toLowerCase())
                                        .reduce((out, i) => out + (out ? i[0].toUpperCase() + i.slice(1) : i), "");
                                    fieldsObject[fieldCode] = field.fieldValues;
                                });
                                this.formsFieldsValues[formType] = fieldsObject;
                            }
                        })
                );
        });
        await Promise.all(requests);
        this.loading = false;
        // ugly fix for accordions wrong height issue
        setTimeout(() => {
            this.accordionsForceUpdate++;
        }, 250);
        this.subscriptionAreLoading = true;
    }

    private bubbleEmit(eventName: string, ...params: any) {
        this.$emit(eventName, ...params);
    }

    @Watch("value", { deep: true, immediate: true })
    private onValueUpdate() {
        if (this.value) {
            const oldActiveTypes = [...this.activeTypes],
                newActiveTypes = this.value.map((i) => i.formType);
            this.value.forEach((i) => {
                this.formsActive[i.formType] = true;
                this.formsCode[i.formType] = i.formCode;
                this.formsData[i.formType] = i.permanentCropFormData;
            });
            oldActiveTypes.forEach((type) => {
                if (!newActiveTypes.includes(type)) {
                    this.formsOpen[type] = true;
                    this.formsActive[type] = false;
                    this.formsCode[type] = null;
                    this.formsData[type] = null;
                }
            });
        }
    }

    @Watch("forceUpdate")
    private onForceUpdate() {
        if (!this.isAccorditionOpened) {
            this.formsOpen.VINEYARD_FORM = true;
            setTimeout(() => {
                this.scrollToWrongInput();
            }, 250);
        } else {
            this.scrollToWrongInput();
        }
    }

    private scrollToWrongInput() {
        this.$nextTick(() => {
            const firstWrongInput = document.querySelector(".border-danger-400:first-of-type");
            firstWrongInput?.scrollIntoView({ behavior: "smooth", block: "center" });
            if (firstWrongInput === null) {
                const wrongInputFallback = document.querySelector(".border-danger-400");
                wrongInputFallback?.scrollIntoView({ behavior: "smooth", block: "center" });
            }
        });
    }

    @Watch("formsData", { deep: true })
    private onFormsDataUpdate() {
        this.$emit(
            "input",
            this.activeTypes.map((type) => ({
                formType: type,
                formCode: this.formsCode[type],
                permanentCropFormData: this.formsData[type],
            }))
        );
    }

    @Watch("permanentCropFormChecked", { deep: true })
    private emitpermanentCropFormChecked() {
        this.$emit("permanentCropFormChecked", this.permanentCropFormChecked);
    }

    private getSubscriptionCodesFromPermanentCropFormData(permanentCropFormData: PermanentCropFormData): string[] {
        if (permanentCropFormData && permanentCropFormData.subscriptionCodes !== null) {
            const subscriptionCodes = permanentCropFormData.subscriptionCodes.split(",");
            const distinctSubscriptionCodes = [...new Set(subscriptionCodes)];
            return distinctSubscriptionCodes;
        }
        return [];
    }

    private getExternalCodesFromPermanentCropFormData(permanentCropFormData: PermanentCropFormData): string | null {
        if (permanentCropFormData && permanentCropFormData.externalCode !== null)
            return permanentCropFormData.externalCode;
        return null;
    }
}
</script>
