<template>
    <div class="h-full w-full flex flex-col overflow-hidden">
        <template v-if="!loading">
            <abc-table
                v-if="page.records.length > 0"
                class="px-4"
                style="margin-top: -1px"
                :items="page.records"
                item-id="businessId"
                border-less
                hide-no-data
                hasFooter
                @select="onSelect"
                :selected-item="business"
            >
                <template #items="{ item }">
                    <td class="cursor-pointer">{{ item.description }}</td>
                    <td class="cursor-pointer">{{ item.code }}</td>
                </template>
                <template #footer>
                    <div class="relative mt-4 mb-4">
                        <abc-refine-filter v-if="page.haveMore" />
                    </div>
                </template>

                <!-- <template #footer>
                    <div class="relative mt-4 mb-4">
                        <abc-infinite-support :dataProvider="loadNextpage">
                            <template #no-results>
                                <p
                                    v-if="!filter || loading"
                                    class="flex justify-center items-center text-label-secondary h-16 mb-8"
                                >
                                    {{ i18n("search-for-a-business") }}
                                </p>
                                <abc-no-data-found v-else />
                            </template>
                        </abc-infinite-support>
                    </div>
                </template> -->
            </abc-table>
        </template>

        <abc-loader v-if="loading" class="pt-4" />

        <div v-if="!loading && ((page && page.records.length === 0) || !page)" class="relative mt-4 mb-4">
            <p v-if="!filter || loading" class="flex justify-center items-center text-label-secondary h-16 mb-8">
                {{ i18n("search-for-a-farm") }}
            </p>
            <abc-no-data-found v-else />
        </div>

        <!-- <div v-if="page.records.length > 0" class="flex pt-3 pb-2 mx-4">
            <div class="w-full text-right">
                <span class="rounded px-2 py-1 text-xs uppercase bg-info-100 text-info-500 mr-1"
                    ><span><em class="fad fa-user pr-1"></em> {{ i18n("total-farms") }} </span
                    ><span class="font-semibold pl-1">{{ page.records.length }}</span></span
                >
            </div>
        </div> -->
    </div>
</template>

<script lang="ts">
import { Vue, Component, Prop, Inject, Watch } from "vue-property-decorator";
import SingleCropPlanModule, { MODULE_ID } from "../../../index";
import { Business } from "../../../models/Business";
import { TranslateResult } from "vue-i18n";
import { FromStore } from "@abaco/web-common/src/app";
import { Debounce } from "vue-debounce-decorator";
import { MaxPagedResults, EmptyMaxPagedResults } from "@abaco/web-common/src/Paging";

@Component
export default class SearchBusinessResults extends Vue {
    @Inject() i18n!: (key: string, values?: unknown) => TranslateResult;
    @Inject(MODULE_ID) singleCropPlanModule!: SingleCropPlanModule;

    @Prop() filter!: string;
    @Prop() triggerLoad!: number;

    @FromStore(MODULE_ID) business!: Business;

    private page: MaxPagedResults<Business> = new EmptyMaxPagedResults();
    private loading = false;

    mounted() {
        // if(this.filter){
        // this.resetAndLoad();
        // }
        this.onFilterChange();
    }

    @Watch("filter")
    onFilterChange() {
        if (this.filter) {
            this.loading = true;
            this.waitAndReset();
        } else {
            this.page = new EmptyMaxPagedResults();
        }
    }

    @Debounce(400)
    waitAndReset() {
        this.resetAndLoad();
    }

    @Watch("triggerLoad")
    async resetAndLoad() {
        this.page = await this.singleCropPlanModule.businessApi.getBusinesses(this.filter);
        this.loading = false;
    }

    private async onSelect(index: number) {
        const business = this.page.records[index];

        this.$emit("select", business);
    }
}
</script>
