<template>
    <div class="single-cp-map-sidebar-modal flex flex-col absolute h-full top-0 left-0 z-40 bg-bg-100">
        <div class="single-cp-map-sidebar-modal-title flex border-b items-center flex-shrink-0" style="height: 46px">
            <!-- <transition-group
                name="custom-classes-transition"
                enter-active-class="animate__animated animate__fadeIn animate__faster"
                mode="out-in"
                tag="div"
                class="flex items-baseline flex-grow"
            > -->
            <transition
                name="custom-classes-transition"
                enter-active-class="animate__animated animate__fadeIn animate__faster"
                mode="out-in"
            >
                <button
                    v-if="showBack"
                    type="button"
                    :title="i18n('back')"
                    class="single-cp-map-sidebar-modal-back flex items-center justify-center pr-2"
                    @click="$emit('back')"
                    key="999"
                >
                    <em class="fa fa-arrow-left pl-2"></em>
                </button>
                <div v-else style="width: 36px" />
            </transition>
            <span class="flex pl-1 text-label-primary flex-grow">{{ title }}</span>
            <!-- </transition-group> -->
            <button
                v-if="showClose"
                type="button"
                :title="i18n('close')"
                class="single-cp-map-sidebar-modal-close flex items-center justify-center px-2"
                @click="$emit('close')"
            >
                <em class="fal fa-times"></em>
            </button>
        </div>
        <slot></slot>
    </div>
</template>

<script lang="ts">
import { Vue, Component, Prop, Inject, Watch } from "vue-property-decorator";
import { TranslateResult } from "vue-i18n";

@Component
export default class MapSidebarModal extends Vue {
    @Inject() i18n!: (key: string, values?: unknown) => TranslateResult;
    @Prop() readonly title!: string | null;
    @Prop() readonly showBack!: boolean | false;
    @Prop() readonly showClose!: boolean | false;

    private titleKey = 0;

    @Watch("modalTitle")
    private onTitleUpdate() {
        this.titleKey++;
    }
}
</script>

<style lang="scss">
.single-cp-map-sidebar-modal {
    @apply w-full bg-bg-100 h-full absolute top-0 left-0;
}

.single-cp-map-sidebar-modal-close,
.single-cp-map-sidebar-modal-back {
    @apply transition duration-200 ease-in-out text-text;
    @apply flex justify-center items-center;
    width: 28px;
    height: 28px;
    outline: none !important;
}
.single-cp-map-sidebar-modal-close {
    border-radius: 50px;
}
.single-cp-map-sidebar-modal-back {
    @apply rounded-sm;
    width: 38px;
    height: 34px;
}
.single-cp-map-sidebar-modal-close i,
.single-cp-map-sidebar-modal-back i {
    @apply text-secondary-500;
}
.single-cp-map-sidebar-modal-close i {
    font-size: 18px;
}
.single-cp-map-sidebar-modal-back i {
    font-size: 14px;
}
.single-cp-map-sidebar-modal-close {
    margin-right: 8px;
}
.single-cp-map-sidebar-modal-close:hover,
.single-cp-map-sidebar-modal-back:hover {
    @apply bg-bg-500;
}
</style>
