<template>
    <abc-modal
        v-if="cropPlanEditModeEnabled"
        @close="onClose"
        modal-class="w-full md:w-10/12 lg:w-6/12 xxl:w-4/12"
        :title="i18n('edit-crop-plans')"
    >
        <template #body>
            <crop-plan-edit-modal
                :showModal="showCropPlanModal"
                :selectedCropPlan="selectedCropPlan"
                :cropPlanType="targetCropPlanType"
                :cropPlanModalMode="cropPlanModalMode"
                @close="onModalClose"
            />
            <div v-for="cropPlanType in cropPlanTypesAccordions" :key="cropPlanType.cropPlanTypeCode">
                <div class="px-4 mb-1 mt-6" :value="true">
                    <div
                        class="flex justify-between items-center py-2 pl-4 pr-2 transition-all ease-in-out bg-bg-400 dark:bg-bg-dark-400 duration-400 border-t border-b"
                    >
                        <div class="w-full flex items-center justify-between" style="min-height: 37px">
                            <div class="w-full flex items-center justify-between">
                                <p class="text-label-primary">{{ cropPlanType.description }}</p>
                                <div class="flex flex-row">
                                    <abc-tool-button
                                        v-if="cropPlanType.multiple || cropPlanType.cropPlans.length === 0"
                                        is-success
                                        class="mr-2"
                                        @click="
                                            showCropPlanModal = true;
                                            cropPlanModalMode = 0;
                                            targetCropPlanType = cropPlanType;
                                            selectedCropPlan = null;
                                        "
                                    >
                                        <em class="abc-icon abc-icon-plus" />
                                    </abc-tool-button>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div v-if="cropPlanType.cropPlans.length > 0">
                        <abc-list
                            class="abc-grouped-inner-list"
                            borderLess
                            invertedBorderLess
                            :items="cropPlanType.cropPlans"
                            itemId="cropPlanId"
                            :hideCheckbox="true"
                            withoutSelection
                        >
                            <template #items="{ item }">
                                <div class="w-full">
                                    {{ item.description }}
                                    <!-- <br>{{i18n('last-edit-date')}} {{item.editDate}} -->
                                </div>
                                <abc-tool-button
                                    v-if="cropPlanType.multiple && deleteEnabled"
                                    isWarning
                                    @click="
                                        showCropPlanModal = true;
                                        cropPlanModalMode = 2;
                                        selectedCropPlan = item;
                                        targetCropPlanType = null;
                                    "
                                >
                                    <em class="abc-icon abc-icon-trash-bin" />
                                </abc-tool-button>
                                <abc-tool-button
                                    isSuccess
                                    v-if="editEnabled"
                                    @click="
                                        showCropPlanModal = true;
                                        cropPlanModalMode = 1;
                                        selectedCropPlan = item;
                                        targetCropPlanType = null;
                                    "
                                >
                                    <em class="abc-icon abc-icon-pen" />
                                </abc-tool-button>
                            </template>
                        </abc-list>
                    </div>
                    <abc-no-data-found v-else />
                </div>
            </div>
        </template>

        <abc-loader v-if="loading" class="pt-4" />
    </abc-modal>
</template>

<script lang="ts">
import { Mixins, Component, Prop, Inject, Watch } from "vue-property-decorator";
import SingleCropPlanModule, { MODULE_ID } from "../../../index";
import { Business } from "../../../models/Business";
import { TranslateResult } from "vue-i18n";
import { FromStore } from "@abaco/web-common/src/app";
import { Debounce } from "vue-debounce-decorator";
import { CropPlan, CropPlanType } from "../../../models/CropPlan";
import DateUtils from "../../../mixins/DateUtils";

interface CropPlanTypeAccordion {
    cropPlanTypeCode: string;
    description: string;
    multiple: boolean;
    cropPlans: CropPlan[];
}

@Component
export default class SearchCropPlansEdit extends Mixins(DateUtils) {
    @Inject() i18n!: (key: string, values?: unknown) => TranslateResult;
    @Inject(MODULE_ID) singleCropPlanModule!: SingleCropPlanModule;
    @FromStore(MODULE_ID) availableCropPlanTypes!: CropPlanType[];
    @FromStore(MODULE_ID) cropPlanEditModeEnabled!: boolean;
    @FromStore(MODULE_ID) business!: Business;
    @FromStore(MODULE_ID) curCropPlan!: CropPlan;
    @FromStore(MODULE_ID) editEnabled!: boolean;
    @FromStore(MODULE_ID) deleteEnabled!: boolean;

    @Prop() filter!: string;
    @Prop() triggerLoad!: number;

    private loading = true;
    private cropPlanTypesAccordions: CropPlanTypeAccordion[] = [];
    private showCropPlanModal = false;
    private cropPlanModalMode = -1;
    private selectedCropPlan: CropPlan | null = null;
    private targetCropPlanType: CropPlanType | null = null;
    private reloadRequired = false;

    mounted() {
        // if(this.filter){
        this.resetAndLoad();
        // }
    }

    @Watch("filter")
    onFilterChange() {
        this.loading = true;
        this.waitAndReset();
    }

    @Debounce(400)
    waitAndReset() {
        this.resetAndLoad();
    }

    @Watch("triggerLoad")
    async resetAndLoad() {
        this.cropPlanTypesAccordions = [];
        if (this.business && this.availableCropPlanTypes) {
            for (const cropPlanType of this.availableCropPlanTypes) {
                const cropPlans = await this.singleCropPlanModule.cropPlanApi.getCropPlans(
                    this.business.businessId,
                    cropPlanType.cropPlanTypeCode
                );
                this.cropPlanTypesAccordions.push({
                    ...cropPlanType,
                    cropPlans: cropPlans,
                });
            }
        }
        this.loading = false;
    }
    private onClose() {
        this.cropPlanEditModeEnabled = false;
        this.$emit("close", this.reloadRequired);
    }

    private onModalClose(reset: boolean) {
        this.showCropPlanModal = false;
        this.reloadRequired = reset;
        if (reset) this.resetAndLoad();
        if (reset && this.cropPlanModalMode === 0) this.onClose();
    }
}
</script>
