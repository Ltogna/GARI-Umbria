<template>
    <layout
        :title="i18n('edit-parcel-data')"
        :show-back="true"
        :show-close="false"
        @back="$emit('close')"
        @close="$emit('close')"
    >
        <abc-form ref="form" class="flex flex-col h-full w-full" @submit="submit">
            <div class="flex flex-col w-full h-full">
                <div v-if="!hideFieldName" class="flex w-full mt-4">
                    <abc-input
                        class="w-full px-4"
                        :label="i18n('name')"
                        :info="i18n('plot-name-info')"
                        v-model="curPlotOut.description"
                    />
                </div>
                <div v-if="!hidePlotNotes" class="flex w-full mt-4 mb-4">
                    <abc-textarea
                        class="w-full px-4"
                        maxlength="4000"
                        :label="i18n('notes')"
                        v-model="curPlotOut.notes"
                    />
                </div>
            </div>

            <div class="flex flex-wrap justify-center border-t sticky bottom-0 py-3 -mt-2">
                <div>
                    <abc-button
                        class="mr-2 mt-2"
                        is-secondary
                        is-outlined
                        @click="$emit('close')"
                        :is-disabled="disableFormButtons"
                    >
                        <em class="abc-icon abc-icon-arrow-left-round" /> {{ i18n("back") }}
                    </abc-button>
                </div>
                <div>
                    <abc-button
                        class="mr-2 mt-2"
                        @click="submit()"
                        is-success
                        :is-disabled="!plotDataEditChangesPending || disableFormButtons"
                    >
                        <em class="abc-icon abc-icon-check" /> {{ i18n("save") }}
                    </abc-button>
                </div>
            </div>
        </abc-form>
    </layout>
</template>

<script lang="ts">
import { Component, Inject, Watch, Mixins, Ref } from "vue-property-decorator";
import { TranslateResult } from "vue-i18n";
import SingleCropPlanModule, { MODULE_ID } from "../..";
import { FromStore, ToastOptions } from "@abaco/web-common/src/app";
import { Business } from "../../models/Business";
import { EditPlotMode, Plot } from "../../models/Plot";
import DateUtils from "../../mixins/DateUtils";
import Layout from "../private/mapSidebarModal.vue";
import { Validable } from "@abaco/web-components/src/components/form/Validable";
import { Configuration, CropPlan } from "../../models/CropPlan";
import { Council } from "../../models/Council";

@Component({
    components: {
        Layout,
    },
})
export default class SingleCpPlotEdit extends Mixins(DateUtils) {
    @Inject() i18n!: (key: string, values?: unknown) => TranslateResult;
    @Inject() toast!: (message: string, options?: ToastOptions) => TranslateResult;
    @Inject(MODULE_ID) singleCropPlanModule!: SingleCropPlanModule;

    @FromStore(MODULE_ID) business!: Business;
    @FromStore(MODULE_ID) curPlot!: Plot | null;
    @FromStore(MODULE_ID) curPointInTime!: Date;
    @FromStore(MODULE_ID) editPlotMode!: EditPlotMode;
    @FromStore(MODULE_ID) curCropPlan!: CropPlan;
    @FromStore(MODULE_ID) curCouncil!: Council;
    @FromStore(MODULE_ID) hideFieldName!: boolean;
    @FromStore(MODULE_ID) curConfiguration!: Configuration | null;

    @Ref("form") form!: Validable;

    private disableFormButtons = false;
    private isLoading = true;
    private mandatoryRule = [(v: unknown) => !!v || this.i18n("valid.mandatory-field")];
    private curPlotOut: { description: string | null; notes: string | null } = { description: null, notes: null };

    @Watch("editPlotMode")
    onEditPlotModeChange() {
        if (this.editPlotMode === EditPlotMode.NOT_SELECTED) {
            this.$emit("close");
        }
    }

    mounted() {
        this.initPlotOut();
    }

    private get plotDataEditChangesPending() {
        if (!this.curPlot) return false;
        return (
            this.curPlot.notes != this.curPlotOut.notes ||
            (!this.hideFieldName &&
                this.curPlotOut.description &&
                (this.curPlot.description || "") != this.curPlotOut.description)
        );
    }

    private get hidePlotNotes() {
        return this.curConfiguration?.HIDE_PLOTS_NOTES !== "FALSE";
    }

    private initPlotOut() {
        if (!this.curPlot) {
            return;
        }
        this.curPlotOut.description = this.curPlot.description;
        this.curPlotOut.notes = this.curPlot.notes;
    }

    private async submit() {
        const isValid = this.form.validate();
        if (isValid) {
            // notes are optional
            this.disableFormButtons = true;
            try {
                if (this.curPlot) {
                    await this.singleCropPlanModule.plotApi.editPlotData(
                        this.business.businessId,
                        this.curCropPlan.cropPlanId,
                        this.curCouncil.domainZoneId,
                        this.curPlot.plotCode,
                        this.curPlotOut.description,
                        this.curPlotOut.notes
                    );
                    const tempPlot = { ...this.curPlot };
                    tempPlot.description = this.curPlotOut.description;
                    tempPlot.notes = this.curPlotOut.notes;
                    this.$emit("updated", tempPlot);
                    this.toast(this.i18n("plot-updated").toString(), { type: "success" });
                }
            } catch (error) {
                this.toast(error as any, { type: "error" });
            } finally {
                this.disableFormButtons = false;
            }
        }
    }
}
</script>

<style lang="scss" scoped></style>
