<template>
    <tile :title="tileTitle" noContainerStyled>
        <div class="px-4 py-6 sm:w-full md:w-11/12 mx-auto lg:w-11/12 xxl:w-11/12">
            <abc-form ref="form" class="flex flex-col w-full sc-decl-edit-form pb-8" @submit="submit">
                <abc-loader v-if="loading" scope="absolute" class="pt-4" />
                <section-titled
                    :number="1"
                    :title="i18n('bdfe-select-order-title')"
                    :description="i18n('bdfe-select-order-description')"
                >
                    <template #content>
                        <abc-radio
                            class="py-1"
                            v-model="listOrder"
                            v-for="e in listOrders"
                            :key="e.id"
                            :radio-value="e.id"
                            :label="e.description"
                        />
                    </template>
                </section-titled>

                <section-titled
                    :number="2"
                    :title="getSecondSectionTitle"
                    :description="getSecondSectionDescription"
                    class="mt-5"
                >
                    <template #content>
                        <component
                            v-for="(component, index) in orderedComponents"
                            :is="component.name"
                            :key="component.name + '-' + index + '-' + forseUpdateLists"
                            v-bind="component.props"
                            v-on="component.events"
                            class="mt-3"
                        />

                        <div class="flex justify-center mt-5 pt-5">
                            <abc-button
                                v-if="
                                    selectedLandUses.length > 0 &&
                                    selectedDomainZoneIds.length > 0 &&
                                    !hasCommonData &&
                                    !loadingLandUseCommonData
                                "
                                @click="loadLandUseCommonConfigAndValues()"
                                >{{ i18n("laoad-additional-fields-and-permanent-crop-forms") }}
                            </abc-button>
                            <abc-loader v-if="loadingLandUseCommonData" scope="absulute" class="pt-4" />
                        </div>
                        <abc-no-data-found
                            v-if="commonDataLoaded && !hasCommonData"
                            :text="i18n('no-common-data-found')"
                        />
                    </template>
                </section-titled>

                <!-- Section landUseAdditionalOptions -->
                <section-titled
                    v-if="landUseAdditionalOptions && landUseAdditionalOptions.length > 0"
                    :number="3"
                    :title="i18n('luap-section-title')"
                    :description="i18n('luap-section-description')"
                    class="mt-5"
                >
                    <template #content>
                        <land-use-additional-options-parser
                            v-if="!loadingLandUseCommonData"
                            :landUseAdditionalOptions="landUseAdditionalOptions"
                            :isNew="true"
                            :forceUpdate="forceUpdateLuao"
                            :chooseOptionsToUpdate="true"
                            :disableNotCheckedFields="true"
                            @updateLandUseAdditionalOptions="onUpdateLandUseAdditionalDataConf"
                            @selectedForUpdateFieldCodes="onSelectedForUpdateFieldCodes"
                        />
                    </template>
                </section-titled>

                <!-- Section PermanentCropForms -->
                <section-titled
                    v-if="permanentCropFormsData && permanentCropFormsData.length > 0"
                    :number="landUseAdditionalOptions.length > 0 ? 4 : 3"
                    :title="i18n('pcf-section-title')"
                    :description="i18n('pcf-section-description')"
                    class="mt-5"
                >
                    <template #content>
                        <PermanentCropForms
                            v-if="!loadingLandUseCommonData"
                            v-model="permanentCropFormsData"
                            :forceUpdate="forceUpdatePermanentCrop"
                            :areaSqm="calculateAreaSqm"
                            :disableRequirementCheck="true"
                            :readonly="false"
                            :isNew="true"
                            :enableHeaderCheckbox="true"
                            @permanentCropFormChecked="(val) => (selectPermanentCropFormUpdate = val)"
                            class="mt-5"
                        />
                    </template>
                </section-titled>
                <!-- Footer Button -->
                <div
                    class="sc-decl-edit-fields ml-auto md:w-8/12 lg:w-8/12 xxl:w-8/12 my-5"
                    v-if="hasMandatoryData && curCropPlan && !curCropPlan.readOnly"
                >
                    <div class="form-buttons">
                        <abc-form-buttons
                            class="justify-center"
                            @save="validateAndSubmit"
                            @cancel="close"
                            :has-continue="false"
                            :disable-save-button="curDisabledFunctions.includes('EDIT_DECLARATIONS')"
                        />
                    </div>
                </div>
            </abc-form>
        </div>

        <abc-modal v-if="showSaveWarningModal" @close="showSaveWarningModal = false" is-message>
            <template #body>
                {{ i18n("confirm-save-changes") }}
            </template>
            <template #footer>
                <abc-button class="mr-2" is-secondary is-outlined @click="showSaveWarningModal = false">
                    {{ i18n("cancel") }}
                </abc-button>
                <abc-button @click="submit">
                    {{ i18n("confirm") }}
                </abc-button>
            </template>
        </abc-modal>
    </tile>
</template>

<script lang="ts">
import Component from "vue-class-component";
import { Inject, Mixins, Prop, Ref, Watch } from "vue-property-decorator";
import SingleCropPlanModule, { MODULE_ID } from "../../index";
import DeclFieldEditability from "../../mixins/DeclFieldEditability";
import AppLoadingModal from "../private/appLoadingModal.vue";
import PermanentCropForms from "../private/permanentCropForms.vue";
import SectionTitled from "../shared/SectionTitled.vue";
import DeclAreasController from "../tiles/NewCropPlanDeclarationImplementation/DeclAreasController.vue";
import DomainZoneTable from "./DomainZoneTable.vue";
import LandUseTable from "./LandUseTable.vue";
import { TranslateResult } from "vue-i18n";
import { Business } from "../../models/Business";
import { CropPlan, DomainZoneListItem, FunctionCode } from "../../models/CropPlan";
import {
    AnomalieStatus,
    BulkDeclarationFieldsUpdatate,
    DomainZonePlotDeclaration,
    LandUseAnomalyStatus,
} from "../../models/Declaration";
import { LandUseCodeWithRotation, LandUseListItem } from "../../models/LandUse";
import {
    LandUseAdditionalDataConf,
    LandUseAdditionalDataField,
    PermanentCropFormConfig,
    PermanentCropFormValueConfig,
} from "../../models/Plot";
import { PermanentCropField, PermanentCropForm } from "../../models/PermanentCropForm";
import { VINEYARD_FORM } from "../../../../shared/constants";
import { FromStore, ToastOptions } from "@abaco/web-common/src/app";
import { formatDate } from "../../api/Utils";
import { Validable } from "@abaco/web-components/src/components/form/Validable";
import { groupBy } from "lodash";

@Component({
    components: {
        PermanentCropForms,
        SectionTitled,
        DeclAreasController,
        AppLoadingModal,
        LandUseTable,
        DomainZoneTable,
    },
})
export default class BulkDeclarationEdit extends Mixins(DeclFieldEditability) {
    @Inject(MODULE_ID) singleCropPlanModule!: SingleCropPlanModule;
    @Inject() i18n!: (key: string, values?: unknown) => TranslateResult;
    @Inject() toast!: (message: string, options?: ToastOptions) => TranslateResult;

    @Prop({ default: null }) business!: Business | null;
    @Prop({ default: null }) curCropPlan!: CropPlan | null;
    @Prop({ default: null }) curPointInTime!: Date | null;

    @FromStore(MODULE_ID) savedFormsTypes!: Record<string, PermanentCropField[]>;
    @FromStore(MODULE_ID) enabledPermanentCropFormsValues!: PermanentCropFormValueConfig[];
    @FromStore(MODULE_ID) curDisabledFunctions!: FunctionCode[];
    @FromStore(MODULE_ID) showBulkDeclarationEdit!: boolean;
    @FromStore(MODULE_ID) plotsForceReload!: number;
    @FromStore(MODULE_ID) forceSync!: number;

    @Ref("form") form!: Validable;

    protected uniqueLandUses: LandUseListItem[] = [];
    protected uniqueDomainZones: DomainZoneListItem[] = [];

    protected landUseAdditionalOptions: LandUseAdditionalDataConf[] = [];
    protected permanentCropFormsData: PermanentCropForm[] | null = null;

    private loading = 0;
    private loadingLandUseCommonData = 0;
    private forceUpdateLuao = 0;
    private forceUpdatePermanentCrop = 0;
    private forseUpdateLists = 0;
    private selectedForUpdateFieldCodes: string[] = [];
    private selectPermanentCropFormUpdate = false;
    private commonDataLoaded = false;
    private showSaveWarningModal = false;
    private domainZonePlotDeclarationList: DomainZonePlotDeclaration[] = [];

    private get tileTitle() {
        return this.i18n("bulk-declaration-fields-edit-title");
    }

    private listOrder = "land_use_domain_zone" || "domain_zone_land_use";
    private listOrders = [
        {
            id: "land_use_domain_zone",
            description: this.i18n("land-use-domain-zone-order").toString(),
            secondSectionTitle: this.i18n("bdfe-select-land-uses-and-domain-zones-title"),
            secondSectionDescription: this.i18n("bdfe-select-land-uses-and-domain-zones-description"),
            componentsOrder: ["land-use-table", "domain-zone-table"],
        },
        {
            id: "domain_zone_land_use",
            description: this.i18n("domain-zone-land-use-order").toString(),
            secondSectionTitle: this.i18n("bdfe-select-domain-zones-and-land-uses-title"),
            secondSectionDescription: this.i18n("bdfe-select-domain-zones-and-land-uses-description"),
            componentsOrder: ["domain-zone-table", "land-use-table"],
        },
    ];

    private get getSecondSectionTitle() {
        return this.listOrders.find((o) => o.id === this.listOrder)?.secondSectionTitle || "";
    }

    private get getSecondSectionDescription() {
        return this.listOrders.find((o) => o.id === this.listOrder)?.secondSectionDescription || "";
    }

    private get filteredDomainZones() {
        if (this.listOrder === "land_use_domain_zone") {
            if (this.selectedLandUses.length) {
                return this.uniqueDomainZones.filter(
                    (udz) => this.selectedLandUses.some((lu) => lu.domainZoneIds.includes(udz.domainZoneId))
                );
            }

            return this.uniqueDomainZones;
        } else {
            return this.uniqueDomainZones;
        }
    }

    private get filteredLandUses() {
        if (this.listOrder === "domain_zone_land_use" && this.selectedDomainZoneIds.length) {
            return this.uniqueLandUses.filter((ulu) =>
                this.selectedDomainZoneIds.some((dz) => ulu.domainZoneIds.includes(dz))
            );
        } else {
            return this.uniqueLandUses;
        }
    }

    private get landUseAnomalyStatusList(): LandUseAnomalyStatus[] {
        // Group declarations by land use code using lodash's groupBy.
        const groupedDeclarationsByLandUseCode = groupBy(
            this.domainZonePlotDeclarationList,
            (decl) => decl._uniqueLandUseCode
        );

        const result: LandUseAnomalyStatus[] = [];

        // Iterate over each groupedDeclarationsByLandUseCode
        for (const landUseCode in groupedDeclarationsByLandUseCode) {
            const declarations = groupedDeclarationsByLandUseCode[landUseCode];

            // Count the number of declarations that have the missing mandatory fields anomaly
            const anomalyCount = declarations.filter((decl) =>
                decl.anomalies.some((anomaly) => anomaly.errorCode === "DECLARATION_MISSING_MANDATORY_FIELDS")
            ).length;

            // Determine the final status based on the anomaly count
            const status: AnomalieStatus =
                anomalyCount === declarations.length ? "all" : anomalyCount > 0 ? "some" : "none";

            // Add the computed status for the current land use
            result.push({ landUseCode, status });
        }

        return result;
    }

    private get selectedLandUses(): LandUseListItem[] {
        return this.uniqueLandUses.filter((l) => l._selected);
    }

    private get selectedDomainZoneIds(): string[] {
        return this.uniqueDomainZones.filter((d) => d._selected).map((dz) => dz.domainZoneId);
    }

    private get hasCommonData(): boolean {
        return (
            this.landUseAdditionalOptions.length > 0 ||
            (this.permanentCropFormsData && this.permanentCropFormsData.length > 0) ||
            false
        );
    }

    protected get orderedComponents() {
        if (this.filteredDomainZones.length === 0 && this.filteredLandUses.length === 0) return [];
        const components: any = [];
        // Add land-use-table if applicable
        components.push({
            name: "land-use-table",
            props: {
                uniqueLandUses: this.filteredLandUses,
                title: this.i18n("select-land-uses"),
                landUseAnomalyStatusList: this.landUseAnomalyStatusList,
            },
            events: {
                landUseListChange: this.handleLandUseListSelectionChange,
            },
        });

        // Add domain-zone-table if applicable
        components.push({
            name: "domain-zone-table",
            props: {
                uniqueDomainZones: this.filteredDomainZones,
                title: this.i18n("select-domain-zones"),
            },
            events: {
                domainZoneListChange: this.handleDomainZoneListSelectionChange,
            },
        });

        // Find the list order configuration
        const currentListOrder = this.listOrders.find((o) => o.id === this.listOrder);
        if (!currentListOrder) {
            console.warn(`List order with id ${this.listOrder} not found`);
            return components; // Return the default components if no specific order is found
        }
        this.forseUpdateLists++;
        // Sort components based on the configured order
        return currentListOrder.componentsOrder.map((name) => components.find((c: any) => c.name === name));
    }

    // Harcoded 0 for now
    private get calculateAreaSqm() {
        return 0;
    }

    private get hasMandatoryData() {
        return (
            this.hasCommonData &&
            this.selectedLandUses.length > 0 &&
            this.selectedDomainZoneIds.length > 0 &&
            (this.selectPermanentCropFormUpdate || this.selectedForUpdateFieldCodes.length > 0)
        );
    }

    // Reset land use additional options when land use codes change
    @Watch("selectedLandUses")
    @Watch("selectedDomainZoneIds")
    onSelectedLandUsesChange() {
        this.landUseAdditionalOptions = [];
        this.permanentCropFormsData = [];
        this.commonDataLoaded = false;
    }

    @Watch("listOrder", { deep: true, immediate: true })
    onlistOrderChange() {
        // Reset
        this.uniqueDomainZones = [...this.uniqueDomainZones].map((udz) => {
            return { ...udz, _selected: false };
        });
        this.uniqueLandUses = [...this.uniqueLandUses].map((ulu) => {
            return { ...ulu, _selected: false };
        });
    }

    @Watch("curPointInTime")
    private onUpdateValue() {
        this.close();
    }

    async beforeMount() {
        if (this.business && this.curPointInTime && this.curCropPlan) {
            this.loading++;
            try {
                const domainZoneDeclarations =
                    await this.singleCropPlanModule.declarationApi.getAllDomainZoneDeclarations(
                        this.business.businessId,
                        this.curCropPlan.cropPlanId,
                        this.curPointInTime
                    );
                this.domainZonePlotDeclarationList = domainZoneDeclarations;
                if (domainZoneDeclarations) {
                    this.buildLanduseAndDomainZoneLists(domainZoneDeclarations);
                }
            } catch (error) {
                console.error(error);
            }
            this.loading--;
        } else {
            console.error("DEV - Error: missing data");
        }
    }

    buildLanduseAndDomainZoneLists(domainZoneDeclarations: DomainZonePlotDeclaration[]) {
        domainZoneDeclarations.forEach((decl) => {
            // Find the corresponding land use in uniqueLandUses
            const landUse = this.uniqueLandUses.find((l) => l._uniqueLandUseCode === decl._uniqueLandUseCode);

            if (landUse) { // If found, update the declAreaSqm
                // Remove the land use from the list
                this.uniqueLandUses.splice(this.uniqueLandUses.indexOf(landUse), 1);
                // Add the domainZoneId only if it's not already in domainZoneIds
                if (!landUse.domainZoneIds.includes(decl.domainZoneId)) {
                    landUse.domainZoneIds.push(decl.domainZoneId);
                }
                this.uniqueLandUses.push({
                    ...landUse,
                    declAreaSqm: landUse.declAreaSqm + decl.declAreaSqm,
                    _selected: false,
                });
            } else {
                // If not found, add a new land use entry with the domainZoneId
                this.uniqueLandUses.push({
                    ...decl,
                    domainZoneIds: [decl.domainZoneId],
                    _selected: false,
                });
            }
        });

        this.uniqueDomainZones = domainZoneDeclarations
            .filter(
                (declaration, index, self) =>
                    index === self.findIndex((d) => d.domainZoneId === declaration.domainZoneId)
            )
            .map((d) => {
                return {
                    domainZoneId: d.domainZoneId,
                    description: d.domainZoneDescription,
                    code: d.domainZoneId,
                    _selected: false,
                };
            }) as DomainZoneListItem[];
    }

    async loadLandUseCommonConfigAndValues() {
        if (this.business && this.curPointInTime && this.curCropPlan) {
            this.loadingLandUseCommonData++;
            try {
                const res = await this.singleCropPlanModule.landUseApi.getLandUseCommonConfigAndValues(
                    this.business.businessId,
                    this.curCropPlan.cropPlanId,
                    this.curPointInTime,
                    this.selectedLandUses.map((l) => l.landUse.code)
                );

                if (res) {
                    this.landUseAdditionalOptions = res.landUseAdditionalDataConfigs;
                    this.buildPermanentCropFormsData(res.permanentCropFormConfigs);
                    this.commonDataLoaded = true;
                }
            } catch (error) {
                console.error(error);
            }
            this.loadingLandUseCommonData--;
            setTimeout(() => {
                this.forceUpdateLuao++;
                this.forceUpdatePermanentCrop++;
            }, 300);
        }
    }

    async buildPermanentCropFormsData(permanentCropForms: PermanentCropFormConfig[]) {
        const formsTypes = permanentCropForms.map((it) => it.formType);
        this.enabledPermanentCropFormsValues = permanentCropForms.map((value) => value.fields).flat();
        if (formsTypes.length) {
            // Forms
            const forms: PermanentCropForm[] = [];
            //
            if (this.curConfiguration?.PRESERVE_PERMANTENT_CROP_FORM_DATA === "TRUE") {
                formsTypes.forEach((type) => {
                    const lastPermanentCropFormData = this.permanentCropFormsData?.find((it) => it.formType === type);
                    return forms.push({
                        formType: VINEYARD_FORM,
                        formCode: lastPermanentCropFormData?.formCode || null,
                        permanentCropFormData:
                            lastPermanentCropFormData?.formType === VINEYARD_FORM
                                ? lastPermanentCropFormData?.permanentCropFormData
                                : null,
                    });
                });
            } else {
                forms.push({
                    formType: VINEYARD_FORM,
                    formCode: null,
                    permanentCropFormData: null,
                });
            }
            this.permanentCropFormsData = forms;
        } else {
            this.permanentCropFormsData = null;
        }
    }

    async validateAndSubmit() {
        const isValid = this.form.validate();
        if (isValid) {
            this.showSaveWarningModal = true;
        } else {
            this.$nextTick(() => this.forceUpdatePermanentCrop++);
            this.$nextTick(() => this.forceUpdateLuao++);
        }
    }

    async submit() {
        this.showSaveWarningModal = false;
        if (this.business && this.curPointInTime && this.curCropPlan) {
            const fieldCodes: LandUseAdditionalDataField[] = this.landUseAdditionalOptions
                .filter(
                    (luao) =>
                        (this.selectedForUpdateFieldCodes.includes(luao.fieldCode) ||
                            (luao.groupCode && this.selectedForUpdateFieldCodes.includes(luao.groupCode))) &&
                        luao.selectedValue !== undefined
                )
                .map((luao) => luao.selectedValue!);

            for (const option of fieldCodes) {
                if (option.dayFrom instanceof Date) option.dayFrom = formatDate(option.dayFrom);
                if (option.dayTo instanceof Date) option.dayTo = formatDate(option.dayTo);
            }

            const luWithRotation: LandUseCodeWithRotation[] = this.selectedLandUses.map((lu) => {
                return {
                    landUseCode: lu.landUse.code,
                    rotation: lu.rotation,
                };
            });
            const payload: BulkDeclarationFieldsUpdatate = {
                domainZoneIds: this.selectedDomainZoneIds,
                landUseCodeWithRotationDtos: luWithRotation,
                fields: fieldCodes,
                permanentCropForms: this.selectPermanentCropFormUpdate ? this.permanentCropFormsData || [] : [],
            };
            try {
                this.loading++;
                const res = await this.singleCropPlanModule.declarationApi.bulkDeclarationFieldsUpdate(
                    this.business.businessId,
                    this.curCropPlan.cropPlanId,
                    this.curPointInTime,
                    payload
                );
                if(res.errorCode) throw new Error(res.errorCode);
                this.close();
                this.forceSync++;
            } catch (error) {
                this.toast(this.i18n("generic-error").toString(), { type: "error", duration: 4000 });
                console.error(error);
            } finally {
                this.loading--;
            }
        }
    }

    close() {
        this.showBulkDeclarationEdit = false;
    }

    private onUpdateLandUseAdditionalDataConf(luads: LandUseAdditionalDataConf[]) {
        this.landUseAdditionalOptions = luads;
    }

    onSelectedForUpdateFieldCodes(selectedValues: string[]) {
        this.selectedForUpdateFieldCodes = selectedValues;
    }

    /**
     * This method ensures that all selected domain zone IDs (`selectedDomainZoneIds`)
     * are present in the filtered domain zones (`filteredDomainZones`). If not, it updates
     * the `uniqueDomainZones` list to reset the `_selected` property for invalid items.
     */
    handleLandUseListSelectionChange() {
        const areAllCorrectlySelect = this.selectedDomainZoneIds.every((sdzi) =>
            this.filteredDomainZones.some((fdz) => fdz.domainZoneId === sdzi)
        );
        if (!areAllCorrectlySelect) {
            this.uniqueDomainZones = [...this.uniqueDomainZones].map((udz) => {
                const isSelected = this.selectedDomainZoneIds.some((sdzi) => sdzi === udz.domainZoneId);
                const isPresent = this.filteredDomainZones.some((it) => it.domainZoneId === udz.domainZoneId);
                if (isSelected && isPresent) return udz;
                return { ...udz, _selected: false };
            });
        }
    }

    /**
     * This method ensures that all selected land uses (`selectedLandUses`)
     * are present in the filtered land uses (`filteredLandUses`). If not, it updates
     * the `uniqueLandUses` list to reset the `_selected` property for invalid items.
     */
    handleDomainZoneListSelectionChange() {
        const areAllCorrectlySelect = this.selectedLandUses.every((sdzi) =>
            this.filteredLandUses.some((fdz) => fdz.domainZoneIds === sdzi.domainZoneIds)
        );
        if (!areAllCorrectlySelect) {
            this.uniqueLandUses = [...this.uniqueLandUses].map((udz) => {
                const isSelected = this.selectedLandUses.some((slu) => slu.domainZoneIds === udz.domainZoneIds);
                const isPresent = this.filteredLandUses.some((it) => it.domainZoneIds === udz.domainZoneIds);
                if (isSelected && isPresent) return udz;
                return { ...udz, _selected: false };
            });
        }
    }
}
</script>
