<template>
    <div>
        <div
            v-if="
                !declarationDetail.fromDate ||
                !declarationDetail.toDate ||
                (declarationDetail.fromDate &&
                    declarationDetail.toDate &&
                    (isLessThanMinInsertableDate || isBiggerThanMaxInsertableDate)) ||
                isLoading
            "
            class="flex flex-col w-full h-full items-center justify-center pt-4"
            style="height: 180px"
        >
            <template v-if="!declarationDetail.fromDate || !declarationDetail.toDate">
                <div class="pb-4">
                    <em class="fad fa-calendar-day text-secondary-100" style="font-size: 70px"></em>
                </div>
                <div class="font-semibold text-label-secondary">
                    {{ i18n("select-dates-to-load-plot-period") }}
                </div>
            </template>
            <template
                v-if="
                    declarationDetail.fromDate &&
                    declarationDetail.toDate &&
                    (isLessThanMinInsertableDate || isBiggerThanMaxInsertableDate)
                "
            >
                <div class="pb-4">
                    <em class="fad fa-calendar-day text-danger-100" style="font-size: 70px"></em>
                </div>
                <div class="font-semibold text-danger-300">
                    {{ i18n("select-valid-dates-to-load-plot-period") }}
                </div>
            </template>
            <template v-if="isLoading">
                <abc-loader />
            </template>
        </div>

        <div
            class="flex flex-col w-full"
            v-if="
                singlePlotPeriod.plot &&
                !hasMultiplePlotSelection &&
                declarationDetail.fromDate &&
                declarationDetail.toDate &&
                minInsertableDate &&
                maxInsertableDate &&
                isBiggerOrEqualThanMinInsertableDate &&
                isLessOrEqualThanMaxInsertableDate &&
                !isLoading
            "
        >
            <!-- PERCENT / AREA -->
            <div class="flex mb-3 text-secondary-600 font-bold">
                {{ i18n("insert-area-by-percentage") }}
            </div>

            <div class="flex border rounded-xl px-3 pb-3 pt-3">
                <DeclarationEditAreaSection
                    :plot-period-data="singlePlotPeriod.plot"
                    :compiled-area="getUsedAreaPerc(singlePlotPeriod.plot.maxDeclarableAreaPerc)"
                    :lockAreaTo100="lockAreaTo100"
                    :ignoreAreaLimit="ignoreAreaLimit"
                    :enableZeroArea="enableZeroArea"
                    :overriddenPercentage="declarationDetail.areaPerc"
                    :percentageDecimalsNumber="getPercentageDecimalNumber"
                    :isNew="isNew"
                    show-use-all-available
                    @coveredPercentageUpdated="updateAreaPerc"
                />
            </div>

            <div class="flex mt-5 mb-3 text-secondary-600 font-bold">
                {{ i18n("insert-area-by-ectars") }}
            </div>

            <div class="flex flex-col w-full border rounded-xl p-3 pt-4 pb-5">
                <DeclarationEditAreaSection
                    v-for="(declaredArea, idx) in singlePlotPeriod.plot.declaredAreas"
                    :key="idx"
                    :plotPeriodData="singlePlotPeriod.plot"
                    :period="declaredArea"
                    :idx="idx"
                    :compiled-area="declaredArea.declaredAreaPerc"
                    :max-date="declarationDetail.toDate"
                    :lockAreaTo100="lockAreaTo100"
                    :overriddenPercentage="declarationDetail.areaPerc"
                    :percentageDecimalsNumber="getPercentageDecimalNumber"
                    :enableZeroArea="enableZeroArea"
                    :isNew="isNew"
                    show-use-all-available
                    @coveredPercentageUpdated="updateAreaPerc"
                />
            </div>
        </div>

        <div
            v-if="
                hasMultiplePlotSelection &&
                declarationDetail.fromDate &&
                declarationDetail.toDate &&
                isBiggerOrEqualThanMinInsertableDate &&
                isLessOrEqualThanMaxInsertableDate &&
                !isLoading
            "
        >
            <div v-if="showRemoveExistingDeclsMessage">
                <div  class="text-warning-600 font-semibold pb-3 mb-5">
                    {{ i18n('existing-declaration-will-be-deleted-for-selected-period') }}
                </div>
            </div>
            <!-- COMPILE COLLECTIVELY PANEL -->
            <div class="flex flex-col pb-3 mb-5 border rounded p-3">
                <div v-if="!showRemoveExistingDeclsMessage" class="flex items-center">
                    <abc-switch :value="editAreaCollectively" @input="editAreaCollectively = !editAreaCollectively" />
                    <div class="font-semibold">
                        {{ i18n("edit-plot-declaration-collectively") }}
                    </div>
                </div>
                <transition
                    name="custom-classes-transition"
                    enter-active-class="animate__animated animate__fadeInDown10 animate__faster"
                    mode="out-in"
                >
                    <div v-if="editAreaCollectively" class="flex flex-col w-full mt-4">
                        <div class="w-full flex mb-2">{{ i18n("collective-area") }}</div>
                        <div class="flex w-full">
                            <abc-input
                                ref="collective-perc-input"
                                :info="i18n('percent-area-collective-info')"
                                class="w-4/12 pr-2"
                                :value="collectiveAreaPercent"
                                @input="updateCollectiveAreaPercent(...arguments, '-1', true)"
                                right-tools
                                text-right
                                is-numeric
                                :is-disabled="lockAreaTo100"
                                :decimals="getPercentageDecimalNumber"
                                :rules="getCollectiveRules()"
                            >
                                <template #right>%</template>
                            </abc-input>
                        </div>
                    </div>
                </transition>
            </div>

            <div v-for="e in curEditablePlots" :key="e.plotCode" class="flex flex-col w-full mb-3">
                <div class="flex w-full">
                    <div
                        class="edit-crop-plan-crop-row"
                        @click="onRowClick(e)"
                        :class="{
                            'edit-crop-plan-crop-row-active':
                                curPlotsToSave && curPlotsToSave.find((p) => p.plotCode === e.plotCode),
                        }"
                        :style="removeExistingDeclarations ? 'width: 100%' : 'width: calc(100% - 412px)'"
                    >
                        <div class="edit-crop-plan-crop-row-border" />
                        <div class="edit-crop-plan-crop-row-inner">
                            <div class="flex items-center pr-3">
                                <single-cp-map-preview :plot="e" />
                            </div>
                            <div class="flex flex-col flex-grow pr-2 justify-between" style="min-width: 0">
                                <div class="flex flex-col">
                                    <div
                                        v-if="!hideFieldName"
                                        class="font-semibold truncate"
                                        v-b-tooltip.hover.window
                                        :title="e.description && e.description.length > 20 ? e.description : ''"
                                        style="margin-top: 3px; height: 21px"
                                    >
                                        {{ e.description }}
                                    </div>
                                    <div v-if="showParcelInfo" class="text-label-primary truncate mb-2">
                                        {{ parcelsPiped(e) }}
                                    </div>
                                </div>
                                <div class="flex flex-col">
                                    <div
                                        v-if="e.decls && e.decls.length > 0"
                                        class="text-secondary-700 truncate"
                                        v-b-tooltip.hover.window
                                        :title="
                                            e.decls && e.decls.length > 0 && declarationsPiped(e).length > 25
                                                ? declarationsPiped(e)
                                                : ''
                                        "
                                    >
                                        {{ declarationsPiped(e) }}
                                    </div>
                                    <div v-else class="text-label-secondary truncate">
                                        {{ i18n("no-land-uses") }}
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <transition
                        v-if="!removeExistingDeclarations"
                        name="custom-classes-transition"
                        enter-active-class="animate__animated animate__fadeInLeft30Px animate__faster"
                        mode="out-in"
                    >
                        <div
                            v-if="curPlotsToSave && curPlotsToSave.find((p) => p.plotCode === e.plotCode)"
                            class="flex ml-3"
                            style="width: 400px"
                            @click.stop="&quot;&quot;;"
                        >
                            <div class="flex flex-col border rounded-lg px-3 justify-center flex-grow">
                                <div class="flex">
                                    <div class="flex flex-grow">
                                        <div class="flex flex-col flex-grow">
                                            <p class="flex text-label-primary text-sm">
                                                {{ i18n("available-sp-area") }}
                                            </p>
                                            <div
                                                class="flex lowercase items-baseline truncate"
                                                :class="{
                                                    'text-success-600': getIsMaxDeclarableAreaPercGratherThanZero(
                                                        e.plotCode
                                                    ),
                                                    'text-label-primary': getIsMaxDeclarableAreaPercLessEqualThanZero(
                                                        e.plotCode
                                                    ),
                                                }"
                                            >
                                                <span class="flex lowercase items-baseline truncate">
                                                    <span class="font-semibold text-3xl -mt-1" style="font-size: 16px">
                                                        {{ getPlotPercentage(e) }}
                                                    </span>
                                                    <span class="text-base">&thinsp;%</span>
                                                </span>
                                            </div>
                                        </div>
                                        <div class="flex flex-col flex-grow">
                                            <p class="flex text-label-primary text-sm">
                                                {{ i18n("available-after-edit-sp-area") }}
                                            </p>
                                            <div
                                                class="flex lowercase items-baseline truncate"
                                                :class="{
                                                    'text-danger-600': availableAreaPercAfterEdit(e.plotCode) < 0,
                                                    'text-label-primary': availableAreaPercAfterEdit(e.plotCode) >= 0,
                                                }"
                                            >
                                                <span class="flex lowercase items-baseline truncate">
                                                    <span class="font-semibold text-3xl -mt-1" style="font-size: 16px">
                                                        {{
                                                            formattedPercentage(
                                                                availableAreaPercAfterEdit(e.plotCode),
                                                                getPercentageDecimalNumber
                                                            )
                                                        }}
                                                    </span>
                                                    <span class="text-base">&thinsp;%</span>
                                                </span>
                                            </div>
                                        </div>
                                    </div>
                                    <transition
                                        name="custom-classes-transition"
                                        enter-active-class="animate__animated animate__fadeIn animate__faster"
                                        mode="out-in"
                                    >
                                        <div v-if="!editAreaCollectively" class="flex" style="width: 135px">
                                            <abc-input
                                                :ref="`collective-perc-input__${e.plotCode}`"
                                                class="w-full"
                                                :value="getCollectiveInputValue(e.plotCode)"
                                                @input="setCollectiveInputValue(e.plotCode, ...arguments)"
                                                :rules="[
                                                    percentageRule,
                                                    getPeriodAreaRules(
                                                        tempMultiplePlotPeriod.find((p) => p.code === e.plotCode).plot
                                                            .maxDeclarableAreaPerc
                                                    ),
                                                    mandatoryNumberRuleAtomic,
                                                ]"
                                                right-tools
                                                text-right
                                                is-numeric
                                                :decimals="getPercentageDecimalNumber"
                                                :is-disabled="lockAreaTo100 || editAreaCollectively"
                                            >
                                                <template #right>%&thinsp;</template>
                                            </abc-input>
                                        </div>
                                    </transition>
                                </div>
                            </div>
                            <abc-tool-button
                                @click="togglePlotPeriodPanel(e.plotCode)"
                                :title="
                                    getIsPlotPeriodOpen(e.plotCode)
                                        ? i18n('hide-area-periods')
                                        : i18n('view-area-periods')
                                "
                                is-info
                                class="ml-2"
                                :is-active="getIsPlotPeriodOpen(e.plotCode)"
                            >
                                <em class="fad text-lg fa-th-list"></em>
                            </abc-tool-button>
                        </div>
                    </transition>
                </div>

                <transition
                    name="custom-classes-transition"
                    enter-active-class="animate__animated animate__fadeInDown10 animate__faster"
                    mode="out-in"
                >
                    <div
                        v-if="getIsPlotPeriodOpen(e.plotCode)"
                        class="mt-2 mb-4 flex flex-col border rounded p-3 w-full pt-4 pb-5"
                    >
                        <DeclarationEditAreaSection
                            v-for="(declaredArea, idx) in tempMultiplePlotPeriod.find((p) => p.code === e.plotCode).plot
                                .declaredAreas"
                            :key="idx"
                            :plotPeriodData="tempMultiplePlotPeriod.find((p) => p.code === e.plotCode).plot"
                            :period="declaredArea"
                            :idx="idx"
                            :compiled-area="declaredArea.declaredAreaPerc"
                            :maxDate="declarationDetail.toDate"
                            :overriddenPercentage="
                                getCollectiveInputValue(tempMultiplePlotPeriod.find((p) => p.code === e.plotCode).code)
                            "
                            force-disable-input
                            :percentageDecimalsNumber="getPercentageDecimalNumber"
                            :isCollective="editAreaCollectively"
                            :enableZeroArea="enableZeroArea"
                            :isNew="isNew"
                            @coveredPercentageUpdated="updateAreaPerc"
                        >
                        </DeclarationEditAreaSection>
                    </div>
                </transition>
            </div>
            <div class="pt-3" />
        </div>
    </div>
</template>

<script lang="ts">
import { Component, Prop, Ref, Inject, Mixins, Watch } from "vue-property-decorator";
import { TranslateResult } from "vue-i18n";
import AbcInput from "@abaco/web-components/src/components/input/AbcInput.vue";
import { VBTooltip } from "bootstrap-vue";
import SingleCpMapPreview from "../../mapComponent/SingleCPMapPreview.vue";
import PermanentCropForms from "../../private/permanentCropForms.vue";
import { DeclarationOut, MultiplePlotPeriod, SinglePlotPeriod } from "../../../models/Declaration";
import { Plot } from "../../../models/Plot";
import { Configuration } from "../../../models/CropPlan";
import { FromStore } from "@abaco/web-common/src/app";
import { MODULE_ID } from "../../..";
import DeclarationEditAreaSection from "../../private/declarationEditAreaSection.vue";
import AreaUtils from "../../../mixins/AreaUtils";
import cloneDeep from "lodash/cloneDeep";
import { DEFAULT_PERCENTAGE_DECIMAL_NUMBER } from "../../../../../shared/constants";

@Component({
    directives: {
        "b-tooltip": VBTooltip,
    },
    components: {
        SingleCpMapPreview,
        DeclarationEditAreaSection,
        PermanentCropForms,
    },
})
export default class DeclAreasController extends Mixins(AreaUtils) {
    @Inject() i18n!: (key: string, values?: unknown) => TranslateResult;

    // ---------- State
    @FromStore(MODULE_ID) curPlot!: Plot | null;
    @FromStore(MODULE_ID) curPlots!: Plot[];
    @FromStore(MODULE_ID) hideFieldName!: boolean;
    @FromStore(MODULE_ID) curConfiguration!: Configuration | null;

    // ---------- Props
    @Prop() declarationDetail!: DeclarationOut;
    @Prop() singlePlotPeriod!: SinglePlotPeriod;
    @Prop() multiplePlotPeriod!: MultiplePlotPeriod[];
    @Prop() minInsertableDate!: Date | null;
    @Prop() maxInsertableDate!: Date | null;
    @Prop({ default: [] }) curPlotsToSave!: Plot[];
    @Prop({ type: Boolean, default: false }) lockAreaTo100!: boolean;
    @Prop({ type: Boolean, default: false }) hasMultiplePlotSelection!: boolean;
    @Prop({ type: Boolean, default: false }) isLoading!: boolean;
    @Prop({ type: Boolean, default: false }) ignoreAreaLimit!: boolean;
    @Prop({ type: Boolean, default: false }) isBiggerOrEqualThanMinInsertableDate!: boolean;
    @Prop({ type: Boolean, default: false }) isLessOrEqualThanMaxInsertableDate!: boolean;
    @Prop({ type: Boolean, default: false }) isBiggerThanMaxInsertableDate!: boolean;
    @Prop({ type: Boolean, default: false }) isLessThanMinInsertableDate!: boolean;
    @Prop({ default: false }) isNew!: boolean;
    @Prop({ default: true }) removeExistingDeclarations!: boolean;

    // ---------- Planting inputs ref
    @Ref("single-perc-input") singlePercInput!: AbcInput;
    @Ref("collective-perc-input") collectivePercInput!: AbcInput;

    // ---------- Local
    private editAreaCollectively = true;
    private collectiveAreaPercent: number | null = null;
    private collectivesValue: { plotCode: string; value: number }[] = [];
    // Backup multiplePlotPeriod list for adding and removing element for the principal one on row click
    private bkMultiplePlotPeriod = cloneDeep(this.multiplePlotPeriod);
    private tempMultiplePlotPeriod = cloneDeep(this.multiplePlotPeriod);

    mounted() {
        if (this.hasMultiplePlotSelection)
            this.updateCollectiveAreaPercent(this.lockAreaTo100 ? 100 : 0);
        // Populate collectivesValue
        this.curPlotsToSave.forEach((it) => this.collectivesValue.push({ plotCode: it.plotCode, value: 0 }));
    }

    // ---------- Rules
    private mandatoryNumberRuleAtomic = (v: unknown) => !!v || v == 0 || this.i18n("valid.mandatory-field");

    private percentageRule = (v: string | null) =>
        (v && (parseInt(v) < 0 || parseInt(v) > 100)) || v == "0" ? this.i18n("between-0-and-100-rule") : null;

    private haRule = (v: string | null) => (v && parseFloat(v) <= 0 ? this.i18n("valid.gt-zero") : null);

    private maxAreaRule(e: string | null): string | null {
        let res = null;
        if (!this.singlePlotPeriod.plot || !this.singlePlotPeriod.plot.maxDeclarableAreaPerc) {
            return null;
        }
        if (
            e &&
            parseFloat(e) > 0 &&
            parseFloat(e) <= 100 &&
            parseFloat(e) > this.singlePlotPeriod.plot.maxDeclarableAreaPerc
        ) {
            res = this.i18n("area-less-than-plot-area-rule").toString();
        }
        return res;
    }

    private getPeriodAreaRules(area: number) {
        return (v: number) => {
            if (this.ignoreAreaLimit) return null;
            if (v && v > area) return this.i18n("area-less-than-plot-area-rule");
            return null;
        };
    }

    private maxAreaCollectiveRule(e: string | null): string | null {
        let res = null;
        let maxArea = 100;
        this.tempMultiplePlotPeriod.forEach((it) => {
            maxArea = maxArea > it.plot.maxDeclarableAreaPerc ? it.plot.maxDeclarableAreaPerc : maxArea;
        });
        if (
            e &&
            parseFloat(e) > 0 &&
            parseFloat(e) <= 100 &&
            parseFloat(e) > parseFloat(maxArea.toFixed(this.getPercentageDecimalNumber))
        ) {
            res = this.i18n("area-less-than-plot-area-rule").toString();
        }
        return res;
    }

    // ---------- Computeds
    private get curEditablePlots(): Plot[] {
        const plots = cloneDeep(this.curPlots);
        if (this.curPlot) plots.push(this.curPlot);
        return plots;
    }

    private get showParcelInfo() {
        return this.curConfiguration?.HIDE_PARCELS === "TRUE" ? false : true;
    }

    private get getPercentageDecimalNumber() {
        return this.curConfiguration?.DECLS_PERCENTAGE_NUM_OF_DECIMALS
            ? this.curConfiguration?.DECLS_PERCENTAGE_NUM_OF_DECIMALS
            : DEFAULT_PERCENTAGE_DECIMAL_NUMBER;
    }

    private get enableZeroArea() {
        return this.curConfiguration?.ALLOW_DECLS_PERC_TO_ZERO === "TRUE" ? true : false;
    }
    
    private get showRemoveExistingDeclsMessage() {
        return this.removeExistingDeclarations;
    }
    // ---------- Methods
    /**
     * @param plotCode - used for identify the target plot
     * @return collectiveValue retrieved from collectivesValue using the plotCode
     */
    private getCollectiveInputValue(plotCode: string): number {
        return this.collectivesValue.find((it) => it.plotCode === plotCode)?.value || 0;
    }

    /**
     * Update relative collectiveValue value by using plotcode & update CollectiveAreaPercent
     * @param plotCode - used for identify the target plot
     * @param value - input value
     */
    private setCollectiveInputValue(plotCode: string, value: number | null) {
        // UpdateCollectiveAreaPerc
        const collectiveValue = this.collectivesValue.find((it) => it.plotCode === plotCode);
        if (collectiveValue) {
            collectiveValue.value = value || 0;
            this.updateCollectiveAreaPercent(value || 0, plotCode);
        }
    }

    private getIsMaxDeclarableAreaPercGratherThanZero(plotCode: string) {
        const targetPlotPeriod = this.tempMultiplePlotPeriod.find((p) => p.code === plotCode);
        if (targetPlotPeriod) {
            return targetPlotPeriod.plot.maxDeclarableAreaPerc > 0;
        }

        return false;
    }

    private getIsMaxDeclarableAreaPercLessEqualThanZero(plotCode: string) {
        const targetPlotPeriod = this.tempMultiplePlotPeriod.find((p) => p.code === plotCode);
        if (targetPlotPeriod) {
            return targetPlotPeriod.plot.maxDeclarableAreaPerc <= 0;
        }

        return false;
    }

    private getIsPlotPeriodOpen(plotCode: string) {
        const targetPlotPeriod = this.tempMultiplePlotPeriod.find((it) => it.code === plotCode);
        if (targetPlotPeriod) {
            return targetPlotPeriod.isOpen;
        }

        return false;
    }

    private onRowClick(e: Plot) {
        const copiedPlots = cloneDeep(this.curPlotsToSave);
        if (this.curPlotsToSave.find((p) => p.plotCode === e.plotCode)) {
            const curIdx = copiedPlots.findIndex((p) => p.plotCode === e.plotCode);
            copiedPlots.splice(curIdx, 1);

            // Remove from list
            const targetPlotPeriod = this.tempMultiplePlotPeriod.find((it) => it.code === e.plotCode);
            if (targetPlotPeriod) {
                const targetPlotPeriodIdx = this.tempMultiplePlotPeriod.findIndex((it) => it.code === e.plotCode);
                this.tempMultiplePlotPeriod.splice(targetPlotPeriodIdx, 1);
                this.updateMultiplePlotPeriod();
            }
        } else {
            copiedPlots.push(e);

            // Re add from list
            const collectiveValue = this.collectivesValue.find((it) => it.plotCode === e.plotCode)?.value;
            const targetPlotPeriod = this.bkMultiplePlotPeriod.find((it) => it.code === e.plotCode);
            if (targetPlotPeriod) {
                targetPlotPeriod.percentage = this.editAreaCollectively
                    ? this.collectiveAreaPercent
                    : collectiveValue || 0;
                this.tempMultiplePlotPeriod.push(targetPlotPeriod);
                this.updateMultiplePlotPeriod();
            }
        }
        this.$emit("update-cur-plots-to-save", copiedPlots);
    }

    private parcelsPiped(plot: Plot): string | null {
        if (plot.parcelIntersections && plot.parcelIntersections.length > 0) {
            let str = "";
            plot.parcelIntersections.forEach((e) => (str = str ? str + ", " + e.description : e.description));
            return str;
        } else {
            return this.i18n("no-parcel-intersection").toString();
        }
    }

    private declarationsPiped(e: Plot): string | null {
        if (e.decls && e.decls.length > 0) {
            let str = "";
            e.decls.forEach(
                (e) =>
                    (str = str
                        ? str + ", " + (e.landuse.description || e.landuse.code)
                        : e.landuse.description || e.landuse.code)
            );
            return str;
        } else {
            return null;
        }
    }

    /**
     * Only for showing data purpose
     * @param plotCode - used for identify the target plot
     * @return availableAreaPerc for the targetPlot
     */
    private availableAreaPercAfterEdit(plotCode: string): number {
        const compiledAreaPerc = this.getCollectiveInputValue(plotCode);
        const targetPlotPeriod = this.tempMultiplePlotPeriod.find((it) => it.plot.plotCode === plotCode);
        let perc = 0;
        if (targetPlotPeriod && targetPlotPeriod.plot) {
            perc = compiledAreaPerc
                ? targetPlotPeriod.plot.maxDeclarableAreaPerc - compiledAreaPerc
                : targetPlotPeriod.plot.maxDeclarableAreaPerc;
        }
        return perc;
    }

    /**
     * Toggle [isOpen] status of target plot and update multiplePlotPeriod
     * @param plotCode - used for identify the target plot
     */
    private togglePlotPeriodPanel(plotCode: string) {
        const targetPlotPeriod = this.tempMultiplePlotPeriod.find((p) => p.code === plotCode);
        if (!targetPlotPeriod) return;

        if (targetPlotPeriod.isOpen) {
            targetPlotPeriod.isOpen = false;
            this.updateMultiplePlotPeriod();
        } else {
            this.tempMultiplePlotPeriod.forEach((it) => (it.isOpen = false));
            targetPlotPeriod.isOpen = true;
            this.updateMultiplePlotPeriod();
        }
    }

    // Only for collective/multiple
    private getPlotPercentage(plot: Plot) {
        const targetPlotPeriod = this.tempMultiplePlotPeriod.find((p) => p.code === plot.plotCode);
        if (!targetPlotPeriod) return 0;
        return this.formattedPercentage(targetPlotPeriod.plot.maxDeclarableAreaPerc, this.getPercentageDecimalNumber);
    }

    /**
     * Update and [EMIT] new collectiveAreaPercent
     * Update multiplePlotPeriod -> percentage based on overrideCollectiveArea
     * Update all the collectivesValue if based on plotCode
     * @param percentageInput - value to update with collectiveAreaPercent
     * @param plotCode - identifier for what plot to update, if -1 update all
     * @param overrideCollectiveArea - if [TRUE] all the collectivesValue will be setted with percentageInput
     */
    private updateCollectiveAreaPercent(
        percentageInput: number | null,
        plotCode = "-1",
        overrideCollectiveArea = false
    ) {
        // Set the multiplePlotPeriod percentage
        const targetPlotPeriod = this.tempMultiplePlotPeriod.find((it) => it.code === plotCode);
        if (targetPlotPeriod) {
            targetPlotPeriod.percentage = percentageInput;
            this.updateMultiplePlotPeriod();
        } else if (plotCode === "-1") {
            this.tempMultiplePlotPeriod.forEach((it) => (it.percentage = percentageInput));
            this.updateMultiplePlotPeriod();
        }

        // Update all if overrideCollectiveArea [true]
        if (overrideCollectiveArea) {
            this.collectivesValue.forEach((it) => (it.value = percentageInput || 0));
        }

        // Update and emit
        this.collectiveAreaPercent = percentageInput;
        this.$emit("update-detail-area-perc", { percentageInput, plotCode });
        this.updateMultiplePlotPeriod();
    }

    /**
     * [EMIT] New value for detail.areaPerc when an input inside DeclarationEditAreaSection is modified
     * @param val - Obj with [percentageInput] and [plotCode]
     */
    private updateAreaPerc(val: { percentageInput: number; plotCode: string }) {
        this.$emit("update-detail-area-perc", val);
    }

    private getCollectiveRules() {
        const rules = [this.percentageRule, this.mandatoryNumberRuleAtomic]
        if(!this.removeExistingDeclarations) rules.push(this.maxAreaCollectiveRule)
        return rules
    }

    /**
     * [EMIT] New instance of multiplePlotPeriod when called
     * @param val - new MultiplePlotPeriod instance
     */
    private updateMultiplePlotPeriod(val?: MultiplePlotPeriod[]) {
        this.$emit("update-multiple-plot-period", val ? val : this.tempMultiplePlotPeriod);
    }

    // ---------- Watches
    @Watch("editAreaCollectively")
    private onCollectiveToggleUpdate() {
        if (this.lockAreaTo100) return;

        // Reset collectiveAreaPercent
        this.updateCollectiveAreaPercent(null);
        // Reset all insered values
        this.collectivesValue.forEach((it) => (it.value = 0));
        // Update multiplePlotPeriod
        this.tempMultiplePlotPeriod.forEach((it) => (it.isOpen = false));
        this.updateMultiplePlotPeriod();
    }

    @Watch("declarationDetail.fromDate")
    @Watch("declarationDetail.toDate")
    private clearCollectivesValuesOnDatesChange() {
        // Clear entered input values every time dates are changes
        this.collectivesValue.forEach((it) => (it.value = this.lockAreaTo100 ? 100 : 0));
        if (this.hasMultiplePlotSelection) this.updateCollectiveAreaPercent(this.lockAreaTo100 ? 100 : 0);
    }

    @Watch("multiplePlotPeriod")
    private updateBkMultiplePlotPeriod() {
        this.tempMultiplePlotPeriod = cloneDeep(this.multiplePlotPeriod);
        // Everytime multiplePlotPeriod change check if something is added.
        // If it's removed than simply ignore this method, otherwise update bkMultiplePlotPeriod.
        // With this procedure we can always react to [onRowClick] without lost any data
        if (this.multiplePlotPeriod.length > this.bkMultiplePlotPeriod.length) {
            this.bkMultiplePlotPeriod = cloneDeep(this.multiplePlotPeriod);
        }
    }
}
</script>

<style lang="scss" scoped>
.edit-crop-plan-crop-row,
.edit-crop-plan-crop-row-border {
    @apply transition-all duration-150 ease-in-out relative;
}

.edit-crop-plan-crop-row {
    @apply flex cursor-pointer items-stretch w-full max-w-full relative;
}
.edit-crop-plan-crop-row-inner {
    @apply flex items-stretch w-full max-w-full py-3 px-3;
}

.edit-crop-plan-crop-row .edit-crop-plan-crop-row-border {
    @apply border rounded-lg absolute top-0 left-0 w-full h-full;
}
.edit-crop-plan-crop-row:hover .edit-crop-plan-crop-row-border,
.edit-crop-plan-crop-row-active .edit-crop-plan-crop-row-border {
    @apply border-info-300;
}

.edit-crop-plan-crop-row-active .edit-crop-plan-crop-row-border {
    border-width: 2px;
}
</style>
