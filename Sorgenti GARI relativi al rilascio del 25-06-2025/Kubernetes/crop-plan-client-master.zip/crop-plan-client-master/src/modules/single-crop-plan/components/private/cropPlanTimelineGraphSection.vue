<template>
    <div
        class="cp-timeline-section flex flex-row absolute items-center justify-center cursor-pointer overflow-hidden z-20"
        :style="containerStyle"
        @mouseover="$emit('hovering', section)"
        @mouseleave="$emit('hovering', null)"
        @click="$emit('click', $event)"
        :class="{ 'cp-timeline-section-active': active }"
        ref="container"
        v-abc-tooltip="tooltipText"
        v-resize="checkSizeWithDelay"
    >
        <div
            class="cp-timeline-section-percentage absolute z-0 top-0 left-0 h-full"
            :style="percentageStyle"
        />
        <div ref="section" class="flex px-2 w-full text-xs">
            <div class="flex flex-col w-full shrink cp-ts-truncate-text">
                <slot name="checkbox"></slot>
                <div
                    :class="{
                        flex: showAdditionalData && externalDescription,
                        'truncate-target': !showAdditionalData && !externalDescription,
                    }"
                >
                    <div>
                        <p class="truncate-target font-bold">{{ title }}</p>
                        <p class="truncate-target">
                            {{
                                plantingFormDescription +
                                (this.vineyardProductDestination ? " - " + this.vineyardProductDestination : "")
                            }}
                        </p>
                    </div>
                    <div v-if="showAdditionalData && externalDescription">
                        <div class="flex flex-col px-2">
                            <p style="white-space: nowrap">
                                {{ i18n("external-description") }}: {{ externalDescription }}
                            </p>
                            <!-- <p style="white-space: nowrap">{{ externalDescription }}</p> -->
                        </div>
                    </div>
                </div>
                <!-- <p style="white-space: nowrap">Alberello a potatura corta (mock)</p> -->
            </div>
            <div v-if="distance !== null && showAdditionalData" class="flex flex-col px-2">
                <!-- 2 campi da combinare -->
                <p style="white-space: nowrap">{{ i18n("gap") }}</p>
                <p style="white-space: nowrap">{{ distance }}</p>
                <!-- <p style="white-space: nowrap">0,7 x 2,5 (mock)</p> -->
            </div>
            <div v-if="showAdditionalData" class="flex flex-col px-2">
                <p style="white-space: nowrap">{{ i18n("start-date") }}</p>
                <p style="white-space: nowrap">{{ startDate }}</p>
            </div>
            <div v-if="showAdditionalData" class="flex flex-col px-2">
                <p style="white-space: nowrap">{{ i18n("end-date") }}</p>
                <p style="white-space: nowrap">{{ endDate }}</p>
            </div>
            <div class="flex flex-row pl-2">
                <div class="flex text-3xl">
                    <em v-if="blockingAnomalies.length > 0" class="fa-sharp fa-solid fa-circle-xmark mr-1" />
                    <em v-if="warningAnomalies.length > 0" class="fa-sharp fa-solid fa-circle-exclamation" />
                </div>
                <div class="flex flex-col px-2">
                    <p class="text-right font-bold" style="white-space: nowrap">{{ percentageLabel }}</p>
                    <p class="text-right font-bold" style="white-space: nowrap">{{ area }}</p>
                </div>
            </div>
        </div>
    </div>
</template>

<script lang="ts">
import { Prop, Component, Mixins, Inject, Ref } from "vue-property-decorator";
import { TranslateResult } from "vue-i18n";
import { TimelineSectionUI } from "../../models/Declaration";
import DateUtils from "../../mixins/DateUtils";
import AreaUtils from "../../mixins/AreaUtils";
import { VBTooltip } from "bootstrap-vue";
import { FromStore } from "@abaco/web-common/src/app";
import { MODULE_ID } from "../..";
import { PermanentCropField } from "../../models/PermanentCropForm";
import { DEFAULT_PERCENTAGE_DECIMAL_NUMBER, INFINITE_END_DATE, VINEYARD_FORM } from "../../../../shared/constants";
import { Configuration, CropPlan } from "../../models/CropPlan";

@Component({
    directives: {
        "b-tooltip": VBTooltip,
    },
})
export default class CropPlanTimelineGraphSection extends Mixins(DateUtils, AreaUtils) {
    @Inject() i18n!: (key: string, values?: unknown) => TranslateResult;
    @FromStore(MODULE_ID) savedFormsTypes!: Record<string, PermanentCropField[]>;
    @FromStore(MODULE_ID) curConfiguration!: Configuration | null;
    @FromStore(MODULE_ID) curCropPlan!: CropPlan | null;
    @Ref("section") sectionContainer!: HTMLElement;
    @Ref("container") containerHTML!: HTMLElement;

    @Prop() condensed!: boolean;
    @Prop() active!: boolean;
    @Prop() top!: number;
    @Prop() left!: number;
    @Prop() width!: number;
    @Prop() defaultHeight!: number;
    @Prop() condensedHeight!: number;
    @Prop() percentage!: number | null;
    @Prop() section!: TimelineSectionUI;
    @Prop() hasWarning!: boolean;
    @Prop() plotArea!: number | null;

    private containerWidth = 0;
    private totalDataWidth = 0;
    private descriptionWidth = 0;
    private percentageWidth = 0;

    mounted() {
        this.checkSizeWithDelay();
    }

    private checkSizeWithDelay() {
        window.setTimeout(this.checkSize, 50);
    }

    private checkSize() {
        if (!this.containerHTML) return;
        this.containerWidth = this.containerHTML.clientWidth;
        this.totalDataWidth = 0;
        this.descriptionWidth = 0;
        this.percentageWidth = 0;
        if (
            this.sectionContainer &&
            this.sectionContainer.firstElementChild &&
            this.sectionContainer.lastElementChild
        ) {
            this.sectionContainer
                .querySelectorAll(".cp-ts-truncate-text")
                .forEach((el) => el.classList.add("disable-truncate"));
            //
            this.descriptionWidth = this.sectionContainer.firstElementChild.clientWidth;
            this.percentageWidth = this.sectionContainer.lastElementChild.clientWidth;
            for (const child of this.sectionContainer.children) this.totalDataWidth += child.clientWidth;
            //
            this.sectionContainer
                .querySelectorAll(".cp-ts-truncate-text")
                .forEach((el) => el.classList.remove("disable-truncate"));
        }
    }

    private get hasSmallWidth(): boolean {
        return this.containerWidth < 125 ? true : false;
    }

    private get showAdditionalData() {
        return this.containerWidth > this.totalDataWidth;
    }

    private get showDescription() {
        return this.containerWidth > this.descriptionWidth + this.percentageWidth;
    }

    private get containerStyle() {
        return {
            height: this.condensed ? this.condensedHeight + "px" : this.defaultHeight + "px",
            top: this.top + "px",
            left: this.left + "px",
            width: this.width + "px",
        };
    }

    private get percentageStyle() {
        return {
            width: this.percentage ? this.percentage + "%" : 0 + "%",
        };
        // return {};
    }

    private get warningStyle() {
        if (this.hasSmallWidth && !this.condensed) {
            return "font-size: 14px; padding-top: 22px;";
        }
        if (!this.hasSmallWidth && this.condensed) {
            return "font-size: 14px; padding-top: 2px;";
        }
        if (!this.hasSmallWidth && !this.condensed) {
            return "font-size: 24px;";
        }
        return "";
    }

    private get title(): string {
        return this.section.title;
    }

    private get coltureCode() {
        return this.section.title ?? this.section.colture_code;
    }

    private get description(): string {
        return this.section.text || "";
    }

    private get distance(): string | null {
        if (
            this.section.permanentCropForms.find((permanentCropForm) => permanentCropForm === VINEYARD_FORM) ===
            undefined
        )
            return null;
        if (this.section.distance_on_the_row === null && this.section.distance_between_rows === null) return "-";

        return (
            (this.section.distance_on_the_row ? this.section.distance_on_the_row : "-") +
            " x " +
            (this.section.distance_between_rows ? this.section.distance_between_rows : "-") +
            " cm"
        );
    }

    private get stumpsDensity(): number | null {
        if (
            this.section.permanentCropForms.find((permanentCropForm) => permanentCropForm === VINEYARD_FORM) ===
            undefined
        )
            return null;
        if (this.section.stumpsNumber === null || this.section.stumpsNumber === undefined) return null;

        return Math.round((this.section.stumpsNumber * 10000) / this.declarationArea);
    }

    private get startDate(): string {
        return this.formattedDate(this.section.start);
    }

    private get endDate(): string {
        if (this.formattedDate(this.section.end) === INFINITE_END_DATE) return "-";

        return this.formattedDate(this.section.end);
    }

    private get declarationArea(): number { //TODO round
        if (this.plotArea === null || !this.section?.percentage) return 0;
        return Math.round((this.plotArea * this.section.percentage) / 100);
    }

    private get area(): string {
        if (this.plotArea === null || !this.section.percentage) return "";
        else return this.formattedArea(this.declarationArea) + " " + this.areaLabel();
    }

    private get externalDescription(): string | null {
        if (
            this.section.permanentCropForms.find((permanentCropForm) => permanentCropForm === VINEYARD_FORM) ===
            undefined
        )
            return null;
        return this.section.externalDescription;
    }

    private get getPercentageDecimalNumber() {
        return this.curConfiguration?.DECLS_PERCENTAGE_NUM_OF_DECIMALS
            ? this.curConfiguration?.DECLS_PERCENTAGE_NUM_OF_DECIMALS
            : DEFAULT_PERCENTAGE_DECIMAL_NUMBER;
    }

    private get percentageLabel(): string {
        if (!this.section.percentage) return "0%";
        return `${this.formattedPercentage(this.section.percentage, this.getPercentageDecimalNumber)} %`;
    }

    private get tooltipText() {
        const title = [
            this.coltureCode == this.title ? this.title : this.coltureCode + " - " + this.title,
            this.accessoryData,
            ...(this.description !== "" ? [this.description] : []),
            ...(this.plantingFormDescription !== ""
                ? [
                      this.plantingFormDescription +
                          (this.vineyardProductDestination ? " - " + this.vineyardProductDestination : ""),
                  ]
                : []),
            ...(this.distance !== null ? [this.i18n("gap") + ": " + this.distance] : []),
            ...(this.stumpsDensity !== null
                ? [this.i18n("pcf-label-stumps-density100") + ": " + this.stumpsDensity]
                : []),
            this.i18n("start-date") + ": " + this.startDate,
            this.i18n("end-date") + ": " + this.endDate,
            this.i18n("pcf-label-area") +
                ": " +
                (this.area ? this.area + " (" + this.percentageLabel + ")" : this.percentageLabel),
            ...(this.externalDescription !== null
                ? [this.i18n("external-description") + ": " + this.externalDescription]
                : []),
            ...(this.warningAnomalies.length > 0
                ? [this.i18n("warning-anomalies") + ": " + this.warningAnomalies.length]
                : []),
            ...(this.blockingAnomalies.length > 0
                ? [this.i18n("blocking-anomalies") + ": " + this.blockingAnomalies.length]
                : []),
        ].join("<br>");
        return {
            title: title,
            html: true,
            trigger: "hover",
            delay: { show: 800 },
            boundary: "window",
            customClass: "centered-tooltip",
        };
    }

    private get warningAnomalies() {
        return this.section.anomalies
            .filter((anomaly) => !anomaly.blocking)
            .sort((a, b) => (a.errorCode > b.errorCode ? 1 : -1));
    }

    private get blockingAnomalies() {
        return this.section.anomalies
            .filter((anomaly) => anomaly.blocking)
            .sort((a, b) => (a.errorCode > b.errorCode ? 1 : -1));
    }

    private get accessoryData(): string {
        let res = "";
        this.section.fieldsCodes
            .filter((f) => f.flShowInTooltip && f.value)
            .sort((a, b) => (a.sortOrder > b.sortOrder ? 1 : -1))
            .forEach((o, index, array) => {
                res += "&#8226 " + o.fieldDescription;
                if (o.valueDescription) res += ": " + o.valueDescription;
                if (index + 1 !== array.length) res += "<br>";
            });
        return res;
    }

    private get plantingFormDescription() {
        if (this.savedFormsTypes !== null && this.savedFormsTypes.VINEYARD_FORM) {
            const plantingForm = this.savedFormsTypes.VINEYARD_FORM.find((ff) => ff.fieldCode == "FARMING_FORM");
            if (plantingForm) {
                const plantingValue = plantingForm.fieldValues.find(
                    (pv) => pv.fieldValue == this.section.planting_form
                );
                if (plantingValue) return plantingValue.fieldValueDescription;
            }
        }
        return "";
    }

    private get vineyardProductDestination() {
        if (
            this.savedFormsTypes !== null &&
            this.savedFormsTypes.VINEYARD_FORM &&
            this.section.vineyardProductDestinationCode
        ) {
            const vineyardForm = this.savedFormsTypes.VINEYARD_FORM.find(
                (ff) => ff.fieldCode == "PRODUCT_DESTINATION_CODE"
            );
            if (vineyardForm) {
                const productDestination = vineyardForm.fieldValues.find(
                    (pv) => pv.fieldValue == this.section.vineyardProductDestinationCode
                );
                if (productDestination) return productDestination.fieldValueDescription;
            }
        }
        return null;
    }
}
</script>

<style lang="scss">
ul.warning li::before {
    content: "\2022";
    color: var(--warning-600);
    font-weight: bold;
    display: inline-block;
    width: 1em;
    margin-left: 1em;
}

ul.danger li::before {
    content: "\2022";
    color: var(--danger-600);
    font-weight: bold;
    display: inline-block;
    width: 1em;
    margin-left: 1em;
}

.cp-timeline-section {
    @apply transition-colors duration-150 ease-in-out;
}

.cp-timeline-section-percentage {
    opacity: 0.25;
}

.cp-timeline-section {
    @apply border-b border-l border-bg-100;
    // background: rgba(91,164,117, 0.3);
    background: linear-gradient(90deg, #39937b40, #44997940, #4f9f7740, #5ba47540);
}
.cp-timeline-section:hover {
    // background: rgba(91,164,117, 0.4);
    background: linear-gradient(90deg, #39937b50, #44997950, #4f9f7750, #5ba47550);
}
.cp-timeline-section-active,
.cp-timeline-section-active:hover {
    @apply cursor-default bg-success-500 text-text-opposite;
    // background: rgba(91,164,117, 0.6);
    background: linear-gradient(90deg, #39937b, #449979, #4f9f77, #5ba475);
}
.cp-timeline-section-active .cp-timeline-section-percentage {
    @apply bg-success-800;
}

.tooltip-inner {
    text-align: center;
}

.cp-ts-truncate-text {
    .truncate-target {
        white-space: nowrap;
    }
    &:not(.disable-truncate) {
        min-width: 0;
        .truncate-target {
            overflow: hidden;
            text-overflow: ellipsis;
        }
    }
}

// .cp-timeline-section:after{
//     content: "";
//     position: absolute;
//     left: 0px;
//     width: 100%;
//     bottom: 0px;
//     height: 1px;
//     @apply bg-bg-100 z-20;
// }

// .cp-timeline-section:before{
//     content: "";
//     position: absolute;
//     left: 0px;
//     width: 1px;
//     height: 100%;
//     @apply bg-success-300 z-10;
// }
</style>
