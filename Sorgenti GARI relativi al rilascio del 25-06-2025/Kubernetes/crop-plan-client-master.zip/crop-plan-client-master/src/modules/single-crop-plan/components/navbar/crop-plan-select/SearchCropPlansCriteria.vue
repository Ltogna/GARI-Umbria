<template>
    <div class="flex pt-3 pb-2 border-b mx-4 sticky bg-bg-100 top-0 w-full">
        <abc-form ref="form" class="flex items-start mt-4 w-full">
            <div class="w-full flex justify-between">
                <abc-input
                    left-tools
                    :value="localFilter"
                    @input="updateFilter"
                    class="w-full lg:w-8/12 xxl:w-6/12 mr-4"
                    :placeholder="i18n('search')"
                    :rules="[checkLength]"
                >
                    <template #left>
                        <em class="abc-icon abc-icon-lens" />
                    </template>
                </abc-input>

                <abc-button
                    is-success
                    is-info
                    is-outlined
                    v-if="business && (editEnabled || deleteEnabled)"
                    @click="cropPlanEditModeEnabled = true"
                >
                    <em class="abc-icon abc-icon-pen-square"></em>
                    {{ i18n("edit-crop-plans") }}
                </abc-button>
            </div>
        </abc-form>
    </div>
</template>

<script lang="ts">
import { Vue, Component, Inject, Ref, Prop, Watch } from "vue-property-decorator";
import { TranslateResult } from "vue-i18n";
import { Validable } from "@abaco/web-components/src/components/form/Validable";
import SingleCropPlanModule from "../../..";
import { FromStore } from "@abaco/web-common/src/app";
import { Business } from "../../../models/Business";

@Component
export default class SearchCropPlansCriteria extends Vue {
    @Inject() i18n!: (key: string, values?: unknown) => TranslateResult;
    @Inject(SingleCropPlanModule.MODULE_ID) cropPlanModule!: SingleCropPlanModule;
    @FromStore(SingleCropPlanModule.MODULE_ID) cropPlanEditModeEnabled!: boolean;
    @FromStore(SingleCropPlanModule.MODULE_ID) business!: Business;
    @FromStore(SingleCropPlanModule.MODULE_ID) editEnabled!: boolean;
    @FromStore(SingleCropPlanModule.MODULE_ID) deleteEnabled!: boolean;
    @Ref("form") form!: Validable;

    @Prop() value!: string;
    @Prop() resetFilter!: number;
    @Prop({ type: Boolean }) checkLenght!: boolean;
    @Prop({ type: Boolean }) isSupplyChain!: boolean;

    private localFilter = this.value;

    private get filter() {
        return this.value;
    }

    private set filter(val) {
        this.$emit("input", val);
    }

    @Watch("resetFilter")
    onReset() {
        this.updateFilter("");
    }

    private get checkLength() {
        return (v: string) => {
            return !v || v.length > 2 || this.i18n("type-at-least-3-ch");
        };
    }

    private updateFilter(val: string) {
        this.localFilter = val;
        if (this.localFilter && this.localFilter.length > 2) {
            this.filter = this.localFilter;
        } else {
            this.filter = "";
        }
    }
}
</script>
