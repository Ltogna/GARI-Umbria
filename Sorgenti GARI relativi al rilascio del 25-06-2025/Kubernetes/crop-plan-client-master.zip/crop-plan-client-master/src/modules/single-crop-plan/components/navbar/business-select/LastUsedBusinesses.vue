<template>
    <abc-table
        v-if="!loading"
        :items="items"
        item-id="businessId"
        border-less
        @select="onSelect"
        :selected-item="business"
        class="px-4"
    >
        <template #items="{ item }">
            <td class="cursor-pointer">
                {{ item.description }}
            </td>
            <td class="cursor-pointer">{{ item.code }}</td>
        </template>
        <template #no-data>
            <div v-show="!loading" class="flex flex-col items-center p-4">
                <div class="flex items-center pb-4">
                    <em class="text-2xl abc-icon abc-icon-exclamation-point-circle"></em>
                    <div class="ml-2">{{ i18n("no-farm-used") }}</div>
                </div>
                <abc-button @click="$emit('changeTab')">
                    <div class="flex items-center">
                        <em class="abc-icon abc-icon-lens pr-2" />
                        <p>{{ i18n("search-farm") }}</p>
                    </div>
                </abc-button>
            </div>
        </template>
    </abc-table>
    <abc-loader v-else class="h-16 flex w-full items-center justify-center mb-8" />
</template>

<script lang="ts">
import { Vue, Component, Inject, Watch, Prop } from "vue-property-decorator";
import { TranslateResult } from "vue-i18n";
import { Business } from "../../../models/Business";
import SingleCropPlanModule, { MODULE_ID } from "../../..";
import { FromStore } from "@abaco/web-common/src/app";

@Component
export default class LastUsedBusinesses extends Vue {
    @Inject(MODULE_ID) singleCropPlanModule!: SingleCropPlanModule;
    @Inject() i18n!: (key: string, values?: unknown) => TranslateResult;

    @FromStore(MODULE_ID) business!: Business;

    @Prop() reset!: number;

    private loading = true;
    private items: Business[] = [];

    async mounted() {
        this.loadBusinesses();
    }

    @Watch("reset")
    private async loadBusinesses() {
        this.loading = true;
        try {
            this.items = await this.singleCropPlanModule.businessApi.getLastUsedBusinesses();
        } finally {
            this.loading = false;
        }
    }

    onSelect(index: number) {
        this.$emit("select", this.items[index]);
    }
}
</script>
