<template>
    <div class="w-full flex">
        <div class="flex flex-grow justify-between pr-2">
            <!-- Total -->
            <div v-if="!hideTotal" class="flex flex-grow flex-col">
                <p class="flex text-label-primary text-sm">{{ i18n("total-sp-area") }}</p>
                <div class="flex lowercase items-baseline truncate">
                    <span class="font-semibold text-3xl -mt-1" style="font-size: 16px">
                        {{ totalAreaVisualization }}
                    </span>
                    <span class="pl-1 text-base">
                        {{ measureUnitLabel }}
                    </span>
                </div>
            </div>
            <!-- Available -->
            <div v-if="!hideAvailableAndAfterEdit" class="flex flex-col" style="width: 150px">
                <p class="flex text-label-primary text-sm">{{ i18n("available-sp-area") }}</p>
                <div
                    class="flex lowercase items-baseline truncate"
                    :class="isAvailableAreaGreatherThanZero ? 'text-success-600' : 'text-label-primary'"
                >
                    <span class="flex lowercase items-baseline truncate">
                        <span class="font-semibold text-3xl -mt-1" style="font-size: 16px">
                            {{ availableAreaVisualization }}
                        </span>
                        <span class="pl-1 text-base">
                            {{ measureUnitLabel }}
                        </span>
                    </span>
                    <span v-if="isHectarVisualization" class="pl-2">
                        <span class="text-sm">
                            {{ formattedPercentage(availablePercentage, percentageDecimalsNumber) }}
                        </span>
                        <span class="text-sm">%</span>
                    </span>
                </div>
            </div>
            <!-- After Edit -->
            <div v-if="!hideAvailableAndAfterEdit" class="flex flex-col" style="width: 150px">
                <p class="flex text-label-primary text-sm">{{ i18n("available-after-edit-sp-area") }}</p>
                <div
                    class="flex lowercase items-baseline truncate"
                    :class="isOverDeclaring ? 'text-danger-600' : 'text-label-primary'"
                >
                    <span class="flex lowercase items-baseline truncate">
                        <span class="font-semibold text-3xl -mt-1" style="font-size: 16px">
                            {{ afterEditAreaVisualization }}
                        </span>
                        <span class="pl-1 text-base">
                            {{ measureUnitLabel }}
                        </span>
                    </span>
                    <span v-if="isHectarVisualization && plotAreaSqm != 0" class="pl-2">
                        <span class="text-sm">
                            {{ formattedPercentage(afterEditPercentage, percentageDecimalsNumber) }}
                        </span>
                        <span class="text-sm">%</span>
                    </span>
                </div>
            </div>
        </div>
        <div v-if="!hideInput" class="flex items-end" style="width: 130px">
            <!-- Area Input -->
            <abc-input
                v-if="isHectarVisualization"
                :value="hectarsInput"
                right-tools
                text-right
                is-numeric
                remove-trailing-zero
                :decimals="areaDecimalsNumber"
                :is-disabled="lockAreaTo100 || forceDisableInput"
                @input="onAreaInput"
                :rules="areaRules"
            >
                <template #right>{{ areaLabel() }}</template>
            </abc-input>
            <!-- Percentage Input -->
            <abc-input
                v-else
                :value="percentageInput"
                right-tools
                text-right
                is-numeric
                :decimals="percentageDecimalsNumber"
                :is-disabled="lockAreaTo100 || forceDisableInput"
                @input="onPercentageInput"
                :rules="areaPercRules"
            >
                <template #right>%&thinsp;</template>
            </abc-input>
        </div>
        <abc-button
            v-if="showUseAllAvailable"
            isSecondary
            isOutlined
            :is-disabled="lockAreaTo100"
            class="ml-2"
            style="min-width: min-content"
            @click="updateCoveredPercentage(availablePercentage)"
            >{{ i18n("use-all-available") }}</abc-button
        >
    </div>
</template>

<script lang="ts">
import { Prop, Mixins, Watch, Inject, Component } from "vue-property-decorator";
import AreaUtils from "../../../mixins/AreaUtils";
import { TranslateResult } from "vue-i18n";
import { PlotPeriodsData } from "../../../../single-crop-plan/models/Declaration";

@Component
export default class AreaSection extends Mixins(AreaUtils) {
    @Inject() i18n!: (key: string, values?: unknown) => TranslateResult;
    @Prop() plotAreaSqm!: number; // THE PLOT AREA
    @Prop() coveredPercentage!: number; // INITIAL PRE COVERED PERCENTAGE
    @Prop() isHectarVisualization!: boolean; // NEED TO SHOW DATA AS HECTARS OR PERCENTAGE
    @Prop() lockAreaTo100!: boolean; // IF TRUE SET INPUT TO 100% OR PLOT AREA (USE MAIS FOR TESTS)
    @Prop() forceDisableInput!: boolean; // IF TRUE FORCE INPUT TO BE DISABLED
    @Prop() overridePercentage!: number | undefined; // OVERRIDE CURRENT INPUT TO THE DEFINED PERCENTAGE
    @Prop() isCollective!: boolean; // IF TRUE RETURN PLOTCODE OTHERWISE -1
    @Prop({ default: false }) hideTotal!: boolean;
    @Prop({ default: false }) hideAvailableAndAfterEdit!: boolean;
    @Prop({ default: false }) hideInput!: boolean;
    @Prop() plotPeriodData!: PlotPeriodsData;
    @Prop({ type: Boolean, default: false }) ignoreAreaLimit!: boolean;
    @Prop({ type: Boolean, default: false }) enableZeroArea!: boolean;
    @Prop({ type: Boolean, default: false }) showUseAllAvailable!: boolean;
    @Prop({ default: false }) isNew!: boolean;
    @Prop() percentageDecimalsNumber!: number;

    private hectarsInput: number | null = null;
    private percentageInput: number | null = null;
    private areaDecimalsNumber = 4;

    mounted() {
        if (this.overridePercentage === undefined) return;

        this.overrideInput(this.overridePercentage);
    }

    @Watch("lockAreaTo100")
    onLockAreaTo100() {
        this.overrideInput(100);
    }

    @Watch("overridePercentage")
    onOverridePercentageUpdate() {
        if (this.overridePercentage === undefined) return;

        this.overrideInput(this.overridePercentage);
    }

    @Watch("coveredPercentage")
    private overrideInput(percentage: number) {
        if (this.isHectarVisualization) {
            const rawTotalHectars = this.convertPercentageToHectars(percentage);
            this.hectarsInput = rawTotalHectars;
        }
        this.percentageInput = percentage;
    }

    private convertPercentageToHectars(percentage: number): number {
        const onePercent = this.plotAreaSqm / 100;
        const targetAreaSqm = percentage * onePercent;
        return targetAreaSqm / 10000;
    }

    private formatHectars(hectars: number): string {
        const trimmedHectars = hectars.toLocaleString(this.getLocale(), {
            minimumFractionDigits: 0,
            maximumFractionDigits: this.areaDecimalsNumber,
        });
        return trimmedHectars;
    }

    private get availablePercentage(): number {
        return this.plotPeriodData.totalDeclarableAreaPerc - (this.coveredPercentage ? this.coveredPercentage : 0);
    }

    private convertAreaInputIntoPercentage(areaToConvert: number): void {
        if (this.isHectarVisualization && this.hectarsInput !== null) {
            const hectarsAreaConvertedIntoSqm = this.convertHectarsAreaIntoSqm(areaToConvert);
            const convertedPercentage = (hectarsAreaConvertedIntoSqm * 100) / this.plotAreaSqm;
            this.percentageInput = convertedPercentage;
        }
    }

    private convertHectarsAreaIntoSqm(areaToConvert: number): number {
        return areaToConvert * 10000;
    }

    // Whenever I change the selected percentage/area I convert it into percentage and send it to parent
    private onAreaInput(newArea: number | null) {
        if (newArea && this.formatHectars(newArea) == this.standardizeHectarsOrPercentage(this.availablePercentage)) {
            newArea = this.convertPercentageToHectars(this.availablePercentage);
        }

        this.convertAreaInputIntoPercentage(newArea || 0);
        this.updateCoveredPercentage();
    }

    private onPercentageInput(newPercentage: number | null) {
        if (
            newPercentage &&
            this.formattedPercentage(newPercentage, this.percentageDecimalsNumber) ==
                this.standardizeHectarsOrPercentage(this.availablePercentage)
        )
            newPercentage = this.availablePercentage;

        this.percentageInput = newPercentage || 0;
        this.updateCoveredPercentage();
    }

    private updateCoveredPercentage(val?: number) {
        this.$emit("coveredPercentageUpdated", {
            percentageInput: val ? val : this.percentageInput || 0,
            plotCode: this.isCollective ? "-1" : this.plotPeriodData.plotCode,
        });
    }

    private standardizeHectarsOrPercentage(percentage: number): string {
        if (this.isHectarVisualization) {
            const hectars = this.convertPercentageToHectars(percentage);
            return this.formatHectars(hectars);
        }

        return this.formattedPercentage(percentage, this.percentageDecimalsNumber);
    }

    private get afterEditPercentage(): number {
        let res = this.availablePercentage;
        if (this.percentageInput !== null) res = this.availablePercentage - this.percentageInput;
        if (Math.trunc(res * Math.pow(10, this.percentageDecimalsNumber)) / Math.pow(10, this.percentageDecimalsNumber) == 0) res = 0;
        return res;
    }

    private get totalAreaVisualization(): string {
        return this.standardizeHectarsOrPercentage(100);
    }

    private get availableAreaVisualization(): string {
        return this.standardizeHectarsOrPercentage(this.availablePercentage);
    }

    private get afterEditAreaVisualization(): string {
        return this.standardizeHectarsOrPercentage(this.afterEditPercentage);
    }

    private get isOverDeclaring(): boolean {
        return this.afterEditPercentage < 0;
    }

    private get isAvailableAreaGreatherThanZero(): boolean {
        return this.availablePercentage > 0;
    }

    private get measureUnitLabel(): string {
        if (this.isHectarVisualization) return this.areaLabel();
        else return "%";
    }

    private get areaPercRules() {
        const rules: Record<string, any>[] = [this.mandatoryNumberRuleAtomic, this.valueNotNegative];
        if (!this.enableZeroArea)
            rules.push(this.valueGreaterThanZero);
        if (!this.ignoreAreaLimit) {
            rules.push(this.percentageRule);
            rules.push(this.maxAreaRule);
            if (this.afterEditPercentage < 0) 
                rules.push(this.valueGreaterThanAvailable);
        }
        return rules;
    }

    private get areaRules() {
        const rules: Record<string, any>[] = [this.valueNotNegative];
        if (!this.enableZeroArea)
            rules.push(this.valueGreaterThanZero);
        return rules;
    }

    private valueGreaterThanAvailable() {
        return this.afterEditPercentage < 0 ? this.i18n("area-less-than-plot-area-rule") : null;
    }

    private valueGreaterThanZero(v: string | null) {
        return typeof v == "string" && parseInt(v) <= 0 || typeof v == "number" && v <= 0 
            ? this.i18n("rule-val-gt0") 
            : null;
    }

    private valueNotNegative(v: any | null) {
        return typeof v == "string" && parseInt(v) < 0 || typeof v == "number" && v < 0 
            ? this.i18n("rule-val-not-negative") 
            : null;
    }

    private mandatoryNumberRuleAtomic = (v: unknown) => !!v || v == 0 || this.i18n("valid.mandatory-field");

    private percentageRule = (v: string | null) =>
        (v && (parseInt(v) < 0 || parseInt(v) > 100)) || v == "0" ? this.i18n("between-0-and-100-rule") : null;

    private maxAreaRule(e: string | null): string | null {
        let res = null;
        if (!this.plotPeriodData || !this.plotPeriodData.maxDeclarableAreaPerc) {
            return null;
        }
        if (
            e &&
            parseFloat(e) > 0 &&
            parseFloat(e) <= 100 &&
            parseFloat(e) > this.plotPeriodData.maxDeclarableAreaPerc
        ) {
            res = this.i18n("area-less-than-plot-area-rule").toString();
        }
        return res;
    }
}
</script>

<style lang="scss">
.edit-crop-plan-crop-row,
.edit-crop-plan-crop-row-border {
    @apply transition-all duration-150 ease-in-out relative;
}

.edit-crop-plan-crop-row {
    @apply flex cursor-pointer items-stretch w-full max-w-full relative;
}
.edit-crop-plan-crop-row-inner {
    @apply flex items-stretch w-full max-w-full py-3 px-3;
}

.edit-crop-plan-crop-row .edit-crop-plan-crop-row-border {
    @apply border rounded-lg absolute top-0 left-0 w-full h-full;
}
.edit-crop-plan-crop-row:hover .edit-crop-plan-crop-row-border,
.edit-crop-plan-crop-row-active .edit-crop-plan-crop-row-border {
    @apply border-info-300;
}

.edit-crop-plan-crop-row-active .edit-crop-plan-crop-row-border {
    border-width: 2px;
}
</style>
