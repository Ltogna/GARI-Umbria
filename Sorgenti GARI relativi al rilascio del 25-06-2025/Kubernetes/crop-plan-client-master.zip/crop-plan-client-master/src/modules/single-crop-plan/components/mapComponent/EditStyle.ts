const CANVAS_OFFSET = 20;

export function createAddIconCanvasPattern() {
    const canvas = document.createElement("canvas");
    const ctx = canvas.getContext("2d");
    if (!ctx) {
        return "";
    }
    const size = 48;
    canvas.width = size;
    canvas.height = size;
    // ctx.font = '12px verdana';
    // ctx.fillText('Please wait for Font Awesome to load...', 20, 30);

    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.fillStyle = "rgba(253, 210, 77, 0.7)";
    ctx.font = "900 42px 'Font Awesome 5 Pro'";
    ctx.textAlign = "center";

    ctx.fillText("\uf067", 20, 30);
    return ctx.createPattern(canvas, "repeat") || "";
}

export function createEditIconCanvasPattern() {
    const canvas = document.createElement("canvas");
    const ctx = canvas.getContext("2d");
    if (!ctx) {
        return "";
    }
    const size = 48;
    canvas.width = size;
    canvas.height = size;
    // ctx.font = '12px verdana';
    // ctx.fillText('Please wait for Font Awesome to load...', 20, 30);

    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.fillStyle = "rgba(253, 210, 77, 0.7)";
    ctx.font = "900 34px 'Font Awesome 5 Pro'";
    ctx.textAlign = "center";

    ctx.fillText("\uf304", 20, 30);
    return ctx.createPattern(canvas, "repeat") || "";
}

export function createDeleteIconCanvasPattern() {
    const canvas = document.createElement("canvas");
    const ctx = canvas.getContext("2d");
    if (!ctx) {
        return "";
    }
    const size = 48;
    canvas.width = size;
    canvas.height = size;
    // ctx.font = '12px verdana';
    // ctx.fillText('Please wait for Font Awesome to load...', 20, 30);

    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.fillStyle = "red";
    ctx.font = "900 20px icone_abaco";
    ctx.textAlign = "center";

    ctx.fillText("\ue875", 20, 30);
    return ctx.createPattern(canvas, "repeat") || "";
}

export function createCrossIconCanvasPattern() {
    const canvas = document.createElement("canvas");
    const ctx = canvas.getContext("2d");
    if (!ctx) return "";
    //
    const size = 20,
        padding = 4;
    canvas.width = size;
    canvas.height = size;
    //
    ctx.lineWidth = 1;
    ctx.strokeStyle = "#ffffff";
    ctx.beginPath();
    ctx.moveTo(padding, padding);
    ctx.lineTo(canvas.width - padding, canvas.height - padding);
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(canvas.width - padding, padding);
    ctx.lineTo(padding, canvas.height - padding);
    ctx.stroke();
    //
    return ctx.createPattern(canvas, "repeat") || "";
}

export function makeStrokePattern(lineColor: string, offset?: number) {
    const size = offset || CANVAS_OFFSET
    const cnv = document.createElement("canvas");
    const ctx = cnv.getContext("2d");
    if (ctx) {
        cnv.width = size;
        cnv.height = size;

        ctx.lineWidth = 1;
        ctx.lineCap = "round";
        ctx.strokeStyle = lineColor;

        ctx.beginPath();
        ctx.moveTo(size, 0);
        ctx.lineTo(0, size);
        ctx.stroke();

        return ctx.createPattern(cnv, "repeat");
    }
    return "#FFFFFF";
}

export const defaultPlotStyle = {
    borderColor: "#4d4a4a",
    fillColor: "#4d4a4a",
};