<template>
    <div class="grid gap-4" ref="form_container">
        <template v-if="formdata">
            <div class="grid grid-cols-2 gap-4">
                <abc-input
                    v-if="checkIfFormIsShown('DISTANCE_ON_THE_ROW_CM')"
                    :label="i18n('pcf-label-distance-on-the-row')"
                    :isNumeric="true"
                    :decimals="0"
                    right-tools
                    remove-trailing-zero
                    v-model="formdata.distanceOnTheRowCm"
                    :is-required="checkIfFormIsMandatory('DISTANCE_ON_THE_ROW_CM')"
                    :isDisabled="
                        readonly || !checkIfFormIsEditable('DISTANCE_ON_THE_ROW_CM', formdata.distanceOnTheRowCm)
                    "
                    :rules="
                        !readonly
                            ? checkIfFormIsMandatory('DISTANCE_ON_THE_ROW_CM')
                                ? [mandatoryRule, distanceRangeRule]
                                : [distanceRangeRule]
                            : []
                    "
                >
                    <template #right>{{ i18n("cm") }}</template>
                </abc-input>

                <abc-input
                    v-if="checkIfFormIsShown('DISTANCE_BETWEEN_ROWS_CM')"
                    :label="i18n('pcf-label-distance-between-rows')"
                    :isNumeric="true"
                    :decimals="0"
                    right-tools
                    remove-trailing-zero
                    v-model="formdata.distanceBetweenRowsCm"
                    :is-required="checkIfFormIsMandatory('DISTANCE_BETWEEN_ROWS_CM')"
                    :isDisabled="
                        readonly || !checkIfFormIsEditable('DISTANCE_BETWEEN_ROWS_CM', formdata.distanceBetweenRowsCm)
                    "
                    :rules="
                        !readonly
                            ? checkIfFormIsMandatory('DISTANCE_BETWEEN_ROWS_CM')
                                ? [mandatoryRule, distanceRangeRule]
                                : [distanceRangeRule]
                            : []
                    "
                >
                    <template #right>{{ i18n("cm") }}</template>
                </abc-input>
            </div>

            <div class="grid grid-cols-2 gap-4">
                <abc-input
                    v-if="checkIfFormIsShown('STUMPS_NUMBER')"
                    :label="i18n('pcf-label-stumps-number')"
                    :isNumeric="true"
                    :decimals="0"
                    v-model="formdata.stumpsNumber"
                    :is-required="checkIfFormIsMandatory('STUMPS_NUMBER')"
                    :isDisabled="!checkIfFormIsEditable('STUMPS_NUMBER', formdata.stumpsNumber)"
                    :rules="
                        !readonly
                            ? checkIfFormIsMandatory('STUMPS_NUMBER')
                                ? [mandatoryRule, greaterThanZeroRule]
                                : [greaterThanZeroRule]
                            : []
                    "
                    ref="stumps-number"
                />

                <abc-input
                    v-if="checkIfFormIsShown('STUMPS_DENSITY_100')"
                    :label="i18n('pcf-label-stumps-density100')"
                    :isNumeric="true"
                    :decimals="0"
                    v-model="formdata.stumpsDensity100"
                    ref="stumps-density-100"
                    :isDisabled="readonly || !checkIfFormIsEditable('STUMPS_DENSITY_100', formdata.stumpsDensity100)"
                    :is-required="
                        !readonly &&
                        checkIfFormIsMandatory('STUMPS_DENSITY_100') &&
                        checkIfFormIsEditable('STUMPS_DENSITY_100', formdata.stumpsDensity100)
                    "
                    :rules="
                        !readonly &&
                        checkIfFormIsMandatory('STUMPS_DENSITY_100') &&
                        checkIfFormIsEditable('STUMPS_DENSITY_100', formdata.stumpsDensity100)
                            ? [mandatoryRule]
                            : []
                    "
                    buttons
                >
                    <template #buttons>
                        <abc-tool-button
                            v-if="!readonly"
                            is-secondary
                            :title="i18n('calc-stumps-density')"
                            :is-disabled="
                                !stumpsDensityCanBeCalculated ||
                                !checkIfFormIsEditable('STUMPS_DENSITY_100', formdata.stumpsDensity100)
                            "
                            @click="calcStumpsDensity"
                        >
                            <em class="fa-solid fa-calculator"></em>
                        </abc-tool-button>
                    </template>
                </abc-input>
            </div>

            <abc-autocomplete
                v-if="checkIfFormIsShown('FARMING_FORM')"
                :label="i18n('pcf-label-farming-form')"
                :value="acFieldsSelected.farmingForm"
                @input="(v) => (formdata.farmingForm = v ? v.fieldValue : null)"
                :items="acFieldsValues.farmingForm"
                :stringify="
                    (i) => {
                        return i ? i.fieldValueDescription : null;
                    }
                "
                :search.sync="acFieldsSearch.farmingForm"
                itemId="fieldValue"
                maxHeight="300px"
                buttons
                :is-required="checkIfFormIsMandatory('FARMING_FORM')"
                :isDisabled="readonly || !checkIfFormIsEditable('FARMING_FORM', acFieldsSelected.farmingForm)"
                :rules="
                    !readonly
                        ? checkIfFormIsMandatory('FARMING_FORM')
                            ? [mandatoryRule, (v) => notFallbackOptionRule('farmingForm', v)]
                            : [(v) => notFallbackOptionRule('farmingForm', v)]
                        : []
                "
            >
                <template #items="{ item }">
                    {{ item.fieldValueDescription }}
                </template>
                <template #buttons>
                    <abc-tool-button
                        is-secondary
                        :title="i18n('clear-field')"
                        :isDisabled="readonly || !checkIfFormIsEditable('FARMING_FORM', acFieldsSelected.farmingForm)"
                        @click="
                            acFieldsSearch.farmingForm = '';
                            formdata.farmingForm = null;
                        "
                    >
                        <em class="abc-icon abc-icon-x text-xs"></em>
                    </abc-tool-button>
                </template>
            </abc-autocomplete>

            <abc-autocomplete
                v-if="checkIfFormIsShown('IRRIGATION')"
                :label="i18n('pcf-label-irrigation')"
                :value="acFieldsSelected.irrigation"
                @input="(v) => (formdata.irrigation = v ? v.fieldValue : null)"
                :items="acFieldsValues.irrigation"
                :stringify="
                    (i) => {
                        return i ? i.fieldValueDescription : null;
                    }
                "
                :search.sync="acFieldsSearch.irrigation"
                itemId="fieldValue"
                maxHeight="300px"
                buttons
                :is-required="checkIfFormIsMandatory('IRRIGATION')"
                :isDisabled="readonly || !checkIfFormIsEditable('IRRIGATION', acFieldsSelected.irrigation)"
                :rules="
                    !readonly
                        ? checkIfFormIsMandatory('IRRIGATION')
                            ? [mandatoryRule, (v) => notFallbackOptionRule('irrigation', v)]
                            : [(v) => notFallbackOptionRule('irrigation', v)]
                        : []
                "
            >
                <template #items="{ item }">
                    {{ item.fieldValueDescription }}
                </template>
                <template #buttons>
                    <abc-tool-button
                        is-secondary
                        :title="i18n('clear-field')"
                        :isDisabled="readonly || !checkIfFormIsEditable('IRRIGATION', acFieldsSelected.irrigation)"
                        @click="
                            acFieldsSearch.irrigation = '';
                            formdata.irrigation = null;
                        "
                    >
                        <em class="abc-icon abc-icon-x text-xs"></em>
                    </abc-tool-button>
                </template>
            </abc-autocomplete>

            <abc-autocomplete
                v-if="checkIfFormIsShown('PRODUCT_DESTINATION_CODE')"
                :label="i18n('pcf-label-product-destination-code')"
                :value="acFieldsSelected.productDestinationCode"
                @input="(v) => (formdata.productDestinationCode = v ? v.fieldValue : null)"
                :items="acFieldsValues.productDestinationCode"
                :stringify="
                    (i) => {
                        return i ? i.fieldValueDescription : null;
                    }
                "
                :search.sync="acFieldsSearch.productDestinationCode"
                itemId="fieldValue"
                maxHeight="300px"
                buttons
                :is-required="checkIfFormIsMandatory('PRODUCT_DESTINATION_CODE')"
                :isDisabled="
                    readonly ||
                    !checkIfFormIsEditable('PRODUCT_DESTINATION_CODE', acFieldsSelected.productDestinationCode)
                "
                :rules="
                    !readonly
                        ? checkIfFormIsMandatory('PRODUCT_DESTINATION_CODE')
                            ? [mandatoryRule, (v) => notFallbackOptionRule('productDestinationCode', v)]
                            : [(v) => notFallbackOptionRule('productDestinationCode', v)]
                        : []
                "
            >
                <template #items="{ item }">
                    {{ item.fieldValueDescription }}
                </template>
                <template #buttons>
                    <abc-tool-button
                        is-secondary
                        :title="i18n('clear-field')"
                        :isDisabled="
                            readonly ||
                            !checkIfFormIsEditable('PRODUCT_DESTINATION_CODE', acFieldsSelected.productDestinationCode)
                        "
                        @click="
                            acFieldsSearch.productDestinationCode = '';
                            formdata.productDestinationCode = null;
                        "
                    >
                        <em class="abc-icon abc-icon-x text-xs"></em>
                    </abc-tool-button>
                </template>
            </abc-autocomplete>

            <abc-autocomplete
                v-if="checkIfFormIsShown('CULTIVATION_TYPE_CODE')"
                :label="i18n('pcf-label-cultivation-type-code')"
                :value="acFieldsSelected.cultivationTypeCode"
                @input="(v) => (formdata.cultivationTypeCode = v ? v.fieldValue : null)"
                :items="acFieldsValues.cultivationTypeCode"
                :stringify="
                    (i) => {
                        return i ? i.fieldValueDescription : null;
                    }
                "
                :search.sync="acFieldsSearch.cultivationTypeCode"
                itemId="fieldValue"
                maxHeight="300px"
                buttons
                :is-required="checkIfFormIsMandatory('CULTIVATION_TYPE_CODE')"
                :isDisabled="
                    readonly || !checkIfFormIsEditable('CULTIVATION_TYPE_CODE', acFieldsSelected.cultivationTypeCode)
                "
                :rules="
                    !readonly && checkIfFormIsMandatory('CULTIVATION_TYPE_CODE')
                        ? [mandatoryRule, (v) => notFallbackOptionRule('cultivationTypeCode', v)]
                        : []
                "
            >
                <template #items="{ item }">
                    {{ item.fieldValueDescription }}
                </template>
                <template #buttons>
                    <abc-tool-button
                        is-secondary
                        :title="i18n('clear-field')"
                        :isDisabled="
                            readonly ||
                            !checkIfFormIsEditable('CULTIVATION_TYPE_CODE', acFieldsSelected.cultivationTypeCode)
                        "
                        @click="
                            acFieldsSearch.cultivationTypeCode = '';
                            formdata.cultivationTypeCode = null;
                        "
                    >
                        <em class="abc-icon abc-icon-x text-xs"></em>
                    </abc-tool-button>
                </template>
            </abc-autocomplete>

            <abc-autocomplete
                v-if="checkIfFormIsShown('VARIATION_TYPE_CODE')"
                :label="i18n('pcf-label-variety-source-type-code')"
                :value="acFieldsSelected.variationTypeCode"
                @input="(v) => (formdata.variationTypeCode = v ? v.fieldValue : null)"
                :items="acFieldsValues.variationTypeCode"
                :stringify="
                    (i) => {
                        return i ? i.fieldValueDescription : null;
                    }
                "
                :search.sync="acFieldsSearch.variationTypeCode"
                itemId="fieldValue"
                maxHeight="300px"
                buttons
                :is-required="checkIfFormIsMandatory('VARIATION_TYPE_CODE')"
                :isDisabled="
                    readonly || !checkIfFormIsEditable('VARIATION_TYPE_CODE', acFieldsSelected.variationTypeCode)
                "
                :rules="
                    !readonly && checkIfFormIsMandatory('VARIATION_TYPE_CODE')
                        ? [mandatoryRule, (v) => notFallbackOptionRule('variationTypeCode', v)]
                        : []
                "
            >
                <template #items="{ item }">
                    {{ item.fieldValueDescription }}
                </template>
                <template #buttons>
                    <abc-tool-button
                        is-secondary
                        :title="i18n('clear-field')"
                        @click="
                            acFieldsSearch.variationTypeCode = '';
                            formdata.variationTypeCode = null;
                        "
                        :isDisabled="
                            readonly ||
                            !checkIfFormIsEditable('VARIATION_TYPE_CODE', acFieldsSelected.variationTypeCode)
                        "
                    >
                        <em class="abc-icon abc-icon-x text-xs"></em>
                    </abc-tool-button>
                </template>
            </abc-autocomplete>

            <abc-autocomplete
                v-if="checkIfFormIsShown('VINEYARD_TYPE_CODE')"
                :label="i18n('pcf-label-vineyard-type-code')"
                :value="acFieldsSelected.vineyardTypeCode"
                @input="(v) => (formdata.vineyardTypeCode = v ? v.fieldValue : null)"
                :items="acFieldsValues.vineyardTypeCode"
                :stringify="
                    (i) => {
                        return i ? i.fieldValueDescription : null;
                    }
                "
                :search.sync="acFieldsSearch.vineyardTypeCode"
                itemId="fieldValue"
                maxHeight="300px"
                buttons
                :is-required="checkIfFormIsMandatory('VINEYARD_TYPE_CODE')"
                :isDisabled="
                    readonly || !checkIfFormIsEditable('VINEYARD_TYPE_CODE', acFieldsSelected.vineyardTypeCode)
                "
                :rules="
                    !readonly && checkIfFormIsMandatory('VINEYARD_TYPE_CODE')
                        ? [mandatoryRule, (v) => notFallbackOptionRule('vineyardTypeCode', v)]
                        : []
                "
            >
                <template #items="{ item }">
                    {{ item.fieldValueDescription }}
                </template>
                <template #buttons>
                    <abc-tool-button
                        is-secondary
                        :title="i18n('clear-field')"
                        :isDisabled="
                            readonly || !checkIfFormIsEditable('VINEYARD_TYPE_CODE', acFieldsSelected.vineyardTypeCode)
                        "
                        @click="
                            acFieldsSearch.vineyardTypeCode = '';
                            formdata.vineyardTypeCode = null;
                        "
                    >
                        <em class="abc-icon abc-icon-x text-xs"></em>
                    </abc-tool-button>
                </template>
            </abc-autocomplete>

            <abc-autocomplete
                v-if="checkIfFormIsShown('PLANTING_TYPE')"
                :label="i18n('pcf-label-planting-type')"
                :value="acFieldsSelected.plantingType"
                @input="(v) => (formdata.plantingType = v ? v.fieldValue : null)"
                :items="acFieldsValues.plantingType"
                :stringify="
                    (i) => {
                        return i ? i.fieldValueDescription : null;
                    }
                "
                :search.sync="acFieldsSearch.plantingType"
                itemId="fieldValue"
                maxHeight="300px"
                buttons
                :is-required="checkIfFormIsMandatory('PLANTING_TYPE')"
                :isDisabled="readonly || !checkIfFormIsEditable('PLANTING_TYPE', acFieldsSelected.plantingType)"
                :rules="
                    !readonly && checkIfFormIsMandatory('PLANTING_TYPE')
                        ? [mandatoryRule, (v) => notFallbackOptionRule('plantingType', v)]
                        : []
                "
            >
                <template #items="{ item }">
                    {{ item.fieldValueDescription }}
                </template>
                <template #buttons>
                    <abc-tool-button
                        is-secondary
                        :title="i18n('clear-field')"
                        :isDisabled="readonly || !checkIfFormIsEditable('PLANTING_TYPE', acFieldsSelected.plantingType)"
                        @click="
                            acFieldsSearch.plantingType = '';
                            formdata.plantingType = null;
                        "
                    >
                        <em class="abc-icon abc-icon-x text-xs"></em>
                    </abc-tool-button>
                </template>
            </abc-autocomplete>

            <abc-input
                v-if="checkIfFormIsShown('PLANTING_YEAR')"
                :label="i18n('pcf-label-planting-year')"
                :decimals="0"
                remove-trailing-zero
                v-model="formdata.plantingYear"
                :is-required="checkIfFormIsMandatory('PLANTING_YEAR')"
                :isDisabled="readonly || !checkIfFormIsEditable('PLANTING_YEAR', formdata.plantingYear)"
                :rules="
                    !readonly
                        ? checkIfFormIsMandatory('PLANTING_YEAR')
                            ? [mandatoryRule, plantingYearRule]
                            : [plantingYearRule]
                        : []
                "
            />

            <abc-input
                v-if="checkIfFormIsShown('SHIFT_IN_YEARS')"
                :label="i18n('pcf-label-shift-in-years')"
                :isNumeric="true"
                :decimals="0"
                remove-trailing-zero
                v-model="formdata.shiftInYears"
                :is-required="checkIfFormIsMandatory('SHIFT_IN_YEARS')"
                :isDisabled="readonly || !checkIfFormIsEditable('SHIFT_IN_YEARS', formdata.shiftInYears)"
                :rules="
                    !readonly
                        ? checkIfFormIsMandatory('SHIFT_IN_YEARS')
                            ? [mandatoryRule, greaterThanZeroRule]
                            : [greaterThanZeroRule]
                        : []
                "
            />

            <abc-date-input
                v-if="checkIfFormIsShown('EXPECTED_CUTTING_DATE')"
                :label="i18n('pcf-label-expected-cutting-date')"
                v-model="formdata.expectedCuttingDate"
                :rangeMin="new Date(1990)"
                :is-required="checkIfFormIsMandatory('EXPECTED_CUTTING_DATE')"
                :isDisabled="readonly || !checkIfFormIsEditable('EXPECTED_CUTTING_DATE', formdata.expectedCuttingDate)"
                :rules="!readonly && checkIfFormIsMandatory('EXPECTED_CUTTING_DATE') ? [mandatoryRule] : []"
            />

            <abc-autocomplete
                v-if="checkIfFormIsShown('LAYERING')"
                :label="i18n('pcf-label-layering')"
                :value="acFieldsSelected.layering"
                @input="(v) => (formdata.layering = v ? v.fieldValue : null)"
                :items="acFieldsValues.layering"
                :stringify="
                    (i) => {
                        return i ? i.fieldValueDescription : null;
                    }
                "
                :search.sync="acFieldsSearch.layering"
                itemId="fieldValue"
                maxHeight="300px"
                buttons
                :is-required="checkIfFormIsMandatory('LAYERING')"
                :isDisabled="readonly || !checkIfFormIsEditable('LAYERING', acFieldsSelected.layering)"
                :rules="
                    !readonly && checkIfFormIsMandatory('LAYERING')
                        ? [mandatoryRule, (v) => notFallbackOptionRule('layering', v)]
                        : []
                "
            >
                <template #items="{ item }">
                    {{ item.fieldValueDescription }}
                </template>
                <template #buttons>
                    <abc-tool-button
                        is-secondary
                        :title="i18n('clear-field')"
                        :isDisabled="readonly || !checkIfFormIsEditable('LAYERING', acFieldsSelected.layering)"
                        @click="
                            acFieldsSearch.layering = '';
                            formdata.layering = null;
                        "
                    >
                        <em class="abc-icon abc-icon-x text-xs"></em>
                    </abc-tool-button>
                </template>
            </abc-autocomplete>

            <abc-autocomplete
                v-if="checkIfFormIsShown('ROCK')"
                :label="i18n('pcf-label-rock')"
                :value="acFieldsSelected.rock"
                @input="(v) => (formdata.rock = v ? v.fieldValue : null)"
                :items="acFieldsValues.rock"
                :stringify="
                    (i) => {
                        return i ? i.fieldValueDescription : null;
                    }
                "
                :search.sync="acFieldsSearch.rock"
                itemId="fieldValue"
                maxHeight="300px"
                buttons
                :is-required="checkIfFormIsMandatory('ROCK')"
                :isDisabled="readonly || !checkIfFormIsEditable('ROCK', acFieldsSelected.rock)"
                :rules="
                    !readonly && checkIfFormIsMandatory('ROCK')
                        ? [mandatoryRule, (v) => notFallbackOptionRule('rock', v)]
                        : []
                "
            >
                <template #items="{ item }">
                    {{ item.fieldValueDescription }}
                </template>
                <template #buttons>
                    <abc-tool-button
                        is-secondary
                        :title="i18n('clear-field')"
                        :isDisabled="readonly || !checkIfFormIsEditable('ROCK', acFieldsSelected.rock)"
                        @click="
                            acFieldsSearch.rock = '';
                            formdata.rock = null;
                        "
                    >
                        <em class="abc-icon abc-icon-x text-xs"></em>
                    </abc-tool-button>
                </template>
            </abc-autocomplete>

            <abc-autocomplete
                v-if="checkIfFormIsShown('SKELETON')"
                :label="i18n('pcf-label-skeleton')"
                :value="acFieldsSelected.skeleton"
                @input="(v) => (formdata.skeleton = v ? v.fieldValue : null)"
                :items="acFieldsValues.skeleton"
                :stringify="
                    (i) => {
                        return i ? i.fieldValueDescription : null;
                    }
                "
                :search.sync="acFieldsSearch.skeleton"
                itemId="fieldValue"
                maxHeight="300px"
                buttons
                :is-required="checkIfFormIsMandatory('SKELETON')"
                :isDisabled="readonly || !checkIfFormIsEditable('SKELETON', acFieldsSelected.skeleton)"
                :rules="
                    !readonly && checkIfFormIsMandatory('SKELETON')
                        ? [mandatoryRule, (v) => notFallbackOptionRule('skeleton', v)]
                        : []
                "
            >
                <template #items="{ item }">
                    {{ item.fieldValueDescription }}
                </template>
                <template #buttons>
                    <abc-tool-button
                        is-secondary
                        :title="i18n('clear-field')"
                        :isDisabled="readonly || !checkIfFormIsEditable('SKELETON', acFieldsSelected.skeleton)"
                        @click="
                            acFieldsSearch.skeleton = '';
                            formdata.skeleton = null;
                        "
                    >
                        <em class="abc-icon abc-icon-x text-xs"></em>
                    </abc-tool-button>
                </template>
            </abc-autocomplete>

            <abc-autocomplete
                v-if="checkIfFormIsShown('VEGETATIVE_STATE')"
                :label="i18n('pcf-label-vegetative-state')"
                :value="acFieldsSelected.vegetativeState"
                @input="(v) => (formdata.vegetativeState = v ? v.fieldValue : null)"
                :items="acFieldsValues.vegetativeState"
                :stringify="
                    (i) => {
                        return i ? i.fieldValueDescription : null;
                    }
                "
                :search.sync="acFieldsSearch.vegetativeState"
                itemId="fieldValue"
                maxHeight="300px"
                buttons
                :is-required="checkIfFormIsMandatory('VEGETATIVE_STATE')"
                :isDisabled="readonly || !checkIfFormIsEditable('VEGETATIVE_STATE', acFieldsSelected.vegetativeState)"
                :rules="
                    !readonly && checkIfFormIsMandatory('VEGETATIVE_STATE')
                        ? [mandatoryRule, (v) => notFallbackOptionRule('vegetativeState', v)]
                        : []
                "
            >
                <template #items="{ item }">
                    {{ item.fieldValueDescription }}
                </template>
                <template #buttons>
                    <abc-tool-button
                        is-secondary
                        :title="i18n('clear-field')"
                        :isDisabled="
                            readonly || !checkIfFormIsEditable('VEGETATIVE_STATE', acFieldsSelected.vegetativeState)
                        "
                        @click="
                            acFieldsSearch.vegetativeState = '';
                            formdata.vegetativeState = null;
                        "
                    >
                        <em class="abc-icon abc-icon-x text-xs"></em>
                    </abc-tool-button>
                </template>
            </abc-autocomplete>

            <abc-autocomplete
                v-if="checkIfFormIsShown('PRUNING')"
                :label="i18n('pcf-label-pruning')"
                :value="acFieldsSelected.pruning"
                @input="(v) => (formdata.pruning = v ? v.fieldValue : null)"
                :items="acFieldsValues.pruning"
                :stringify="
                    (i) => {
                        return i ? i.fieldValueDescription : null;
                    }
                "
                :search.sync="acFieldsSearch.pruning"
                itemId="fieldValue"
                maxHeight="300px"
                buttons
                :is-required="checkIfFormIsMandatory('PRUNING')"
                :isDisabled="readonly || !checkIfFormIsEditable('PRUNING', acFieldsSelected.pruning)"
                :rules="
                    !readonly && checkIfFormIsMandatory('PRUNING')
                        ? [mandatoryRule, (v) => notFallbackOptionRule('pruning', v)]
                        : []
                "
            >
                <template #items="{ item }">
                    {{ item.fieldValueDescription }}
                </template>
                <template #buttons>
                    <abc-tool-button
                        is-secondary
                        :title="i18n('clear-field')"
                        :isDisabled="readonly || !checkIfFormIsEditable('PRUNING', acFieldsSelected.pruning)"
                        @click="
                            acFieldsSearch.pruning = '';
                            formdata.pruning = null;
                        "
                    >
                        <em class="abc-icon abc-icon-x text-xs"></em>
                    </abc-tool-button>
                </template>
            </abc-autocomplete>

            <abc-autocomplete
                v-if="checkIfFormIsShown('JUDGEMENT')"
                :label="i18n('pcf-label-judgement')"
                :value="acFieldsSelected.judgement"
                @input="(v) => (formdata.judgement = v ? v.fieldValue : null)"
                :items="acFieldsValues.judgement"
                :stringify="
                    (i) => {
                        return i ? i.fieldValueDescription : null;
                    }
                "
                :search.sync="acFieldsSearch.judgement"
                itemId="fieldValue"
                maxHeight="300px"
                buttons
                :is-required="checkIfFormIsMandatory('JUDGEMENT')"
                :isDisabled="readonly || !checkIfFormIsEditable('JUDGEMENT', acFieldsSelected.judgement)"
                :rules="
                    !readonly && checkIfFormIsMandatory('JUDGEMENT')
                        ? [mandatoryRule, (v) => notFallbackOptionRule('judgement', v)]
                        : []
                "
            >
                <template #items="{ item }">
                    {{ item.fieldValueDescription }}
                </template>
                <template #buttons>
                    <abc-tool-button
                        is-secondary
                        :title="i18n('clear-field')"
                        :isDisabled="readonly || !checkIfFormIsEditable('JUDGEMENT', acFieldsSelected.judgement)"
                        @click="
                            acFieldsSearch.judgement = '';
                            formdata.judgement = null;
                        "
                    >
                        <em class="abc-icon abc-icon-x text-xs"></em>
                    </abc-tool-button>
                </template>
            </abc-autocomplete>

            <div v-if="checkIfFormIsShown('PLANTING_AGE')">
                <div class="mb-1">
                    <label>{{ i18n("pcf-label-planting-age") }}</label>
                </div>
                <div class="fakeput">{{ plantingAgeInfo }}</div>
            </div>

            <abc-input
                v-if="checkIfFormIsShown('FAILURES_PERC')"
                :label="i18n('pcf-label-failures-percentage')"
                :isNumeric="true"
                :decimals="0"
                right-tools
                remove-trailing-zero
                v-model="formdata.failuresPerc"
                :is-required="checkIfFormIsMandatory('FAILURES_PERC')"
                :isDisabled="readonly || !checkIfFormIsEditable('FAILURES_PERC', formdata.failuresPerc)"
                :rules="
                    !readonly
                        ? checkIfFormIsMandatory('FAILURES_PERC')
                            ? [mandatoryRule, percentageRule]
                            : [percentageRule]
                        : []
                "
            >
                <template #right>%&thinsp;</template>
            </abc-input>

            <abc-input
                v-if="checkIfFormIsShown('SOIL_LAYERING_PERC')"
                :label="i18n('pcf-label-soil-layering')"
                :isNumeric="true"
                :decimals="0"
                right-tools
                remove-trailing-zero
                v-model="formdata.soilLayeringPerc"
                :is-required="checkIfFormIsMandatory('SOIL_LAYERING_PERC')"
                :isDisabled="readonly || !checkIfFormIsEditable('SOIL_LAYERING_PERC', formdata.soilLayeringPerc)"
                :rules="
                    !readonly
                        ? checkIfFormIsMandatory('SOIL_LAYERING_PERC')
                            ? [mandatoryRule, percentageRule]
                            : [percentageRule]
                        : []
                "
            >
                <template #right>%&thinsp;</template>
            </abc-input>

            <abc-input
                v-if="checkIfFormIsShown('ALTITUDE_ABOVE_SEA_LEVEL')"
                :label="i18n('pcf-label-altitude-above-sea-level')"
                :isNumeric="true"
                :decimals="0"
                v-model="formdata.altitudeAboveSeaLevel"
                :is-required="checkIfFormIsMandatory('ALTITUDE_ABOVE_SEA_LEVEL')"
                :isDisabled="
                    readonly || !checkIfFormIsEditable('ALTITUDE_ABOVE_SEA_LEVEL', formdata.altitudeAboveSeaLevel)
                "
                :rules="
                    !readonly
                        ? checkIfFormIsMandatory('ALTITUDE_ABOVE_SEA_LEVEL')
                            ? [mandatoryRule, altitudeAboveSeaLevelRule]
                            : [altitudeAboveSeaLevelRule]
                        : []
                "
            />

            <abc-autocomplete
                v-if="checkIfFormIsShown('TERRACING')"
                :label="i18n('pcf-label-terracing')"
                :value="acFieldsSelected.terracing"
                @input="(v) => (formdata.terracing = v ? v.fieldValue : null)"
                :items="acFieldsValues.terracing"
                :stringify="
                    (i) => {
                        return i ? i.fieldValueDescription : null;
                    }
                "
                :search.sync="acFieldsSearch.terracing"
                itemId="fieldValue"
                maxHeight="300px"
                buttons
                :is-required="checkIfFormIsMandatory('TERRACING')"
                :isDisabled="readonly || !checkIfFormIsEditable('TERRACING', acFieldsSelected.terracing)"
                :rules="
                    !readonly && checkIfFormIsMandatory('TERRACING')
                        ? [mandatoryRule, (v) => notFallbackOptionRule('terracing', v)]
                        : []
                "
            >
                <template #items="{ item }">
                    {{ item.fieldValueDescription }}
                </template>
                <template #buttons>
                    <abc-tool-button
                        is-secondary
                        :title="i18n('clear-field')"
                        :isDisabled="readonly || !checkIfFormIsEditable('TERRACING', acFieldsSelected.terracing)"
                        @click="
                            acFieldsSearch.terracing = '';
                            formdata.terracing = null;
                        "
                    >
                        <em class="abc-icon abc-icon-x text-xs"></em>
                    </abc-tool-button>
                </template>
            </abc-autocomplete>

            <abc-autocomplete
                v-if="checkIfFormIsShown('HEADER_ANCHORING')"
                :label="i18n('pcf-label-header-anchoring')"
                :value="acFieldsSelected.headerAnchoring"
                @input="(v) => (formdata.headerAnchoring = v ? v.fieldValue : null)"
                :items="acFieldsValues.headerAnchoring"
                :stringify="
                    (i) => {
                        return i ? i.fieldValueDescription : null;
                    }
                "
                :search.sync="acFieldsSearch.headerAnchoring"
                itemId="fieldValue"
                maxHeight="300px"
                buttons
                :is-required="checkIfFormIsMandatory('HEADER_ANCHORING')"
                :isDisabled="readonly || !checkIfFormIsEditable('HEADER_ANCHORING', acFieldsSelected.headerAnchoring)"
                :rules="
                    !readonly && checkIfFormIsMandatory('HEADER_ANCHORING')
                        ? [mandatoryRule, (v) => notFallbackOptionRule('headerAnchoring', v)]
                        : []
                "
            >
                <template #items="{ item }">
                    {{ item.fieldValueDescription }}
                </template>
                <template #buttons>
                    <abc-tool-button
                        is-secondary
                        :title="i18n('clear-field')"
                        :isDisabled="
                            readonly || !checkIfFormIsEditable('HEADER_ANCHORING', acFieldsSelected.headerAnchoring)
                        "
                        @click="
                            acFieldsSearch.headerAnchoring = '';
                            formdata.headerAnchoring = null;
                        "
                    >
                        <em class="abc-icon abc-icon-x text-xs"></em>
                    </abc-tool-button>
                </template>
            </abc-autocomplete>

            <abc-autocomplete
                v-if="checkIfFormIsShown('PLOES_HEADER')"
                :label="i18n('pcf-label-poles-header')"
                :value="acFieldsSelected.polesHeader"
                @input="(v) => (formdata.polesHeader = v ? v.fieldValue : null)"
                :items="acFieldsValues.polesHeader"
                :stringify="
                    (i) => {
                        return i ? i.fieldValueDescription : null;
                    }
                "
                :search.sync="acFieldsSearch.polesHeader"
                itemId="fieldValue"
                maxHeight="300px"
                buttons
                :is-required="checkIfFormIsMandatory('PLOES_HEADER')"
                :isDisabled="readonly || !checkIfFormIsEditable('PLOES_HEADER', acFieldsSelected.polesHeader)"
                :rules="
                    !readonly && checkIfFormIsMandatory('PLOES_HEADER')
                        ? [mandatoryRule, (v) => notFallbackOptionRule('polesHeader', v)]
                        : []
                "
            >
                <template #items="{ item }">
                    {{ item.fieldValueDescription }}
                </template>
                <template #buttons>
                    <abc-tool-button
                        is-secondary
                        :title="i18n('clear-field')"
                        :isDisabled="readonly || !checkIfFormIsEditable('PLOES_HEADER', acFieldsSelected.polesHeader)"
                        @click="
                            acFieldsSearch.polesHeader = '';
                            formdata.polesHeader = null;
                        "
                    >
                        <em class="abc-icon abc-icon-x text-xs"></em>
                    </abc-tool-button>
                </template>
            </abc-autocomplete>

            <abc-autocomplete
                v-if="checkIfFormIsShown('POLES_WEAVING')"
                :label="i18n('pcf-label-poles-weaving')"
                :value="acFieldsSelected.polesWeaving"
                @input="(v) => (formdata.polesWeaving = v ? v.fieldValue : null)"
                :items="acFieldsValues.polesWeaving"
                :stringify="
                    (i) => {
                        return i ? i.fieldValueDescription : null;
                    }
                "
                :search.sync="acFieldsSearch.polesWeaving"
                itemId="fieldValue"
                maxHeight="300px"
                buttons
                :is-required="checkIfFormIsMandatory('POLES_WEAVING')"
                :isDisabled="readonly || !checkIfFormIsEditable('POLES_WEAVING', acFieldsSelected.polesWeaving)"
                :rules="
                    !readonly && checkIfFormIsMandatory('POLES_WEAVING')
                        ? [mandatoryRule, (v) => notFallbackOptionRule('polesWeaving', v)]
                        : []
                "
            >
                <template #items="{ item }">
                    {{ item.fieldValueDescription }}
                </template>
                <template #buttons>
                    <abc-tool-button
                        is-secondary
                        :title="i18n('clear-field')"
                        :isDisabled="readonly || !checkIfFormIsEditable('POLES_WEAVING', acFieldsSelected.polesWeaving)"
                        @click="
                            acFieldsSearch.polesWeaving = '';
                            formdata.polesWeaving = null;
                        "
                    >
                        <em class="abc-icon abc-icon-x text-xs"></em>
                    </abc-tool-button>
                </template>
            </abc-autocomplete>

            <abc-input
                v-if="checkIfFormIsShown('POLES_DISTANCE_CM')"
                :label="i18n('pcf-label-poles-distance')"
                :isNumeric="true"
                :decimals="2"
                right-tools
                remove-trailing-zero
                v-model="formdata.polesDistanceCm"
                :is-required="checkIfFormIsMandatory('POLES_DISTANCE_CM')"
                :isDisabled="readonly || !checkIfFormIsEditable('POLES_DISTANCE_CM', formdata.polesDistanceCm)"
                :rules="
                    !readonly
                        ? checkIfFormIsMandatory('POLES_DISTANCE_CM')
                            ? [mandatoryRule, polesDistanceRule]
                            : [polesDistanceRule]
                        : []
                "
            >
                <template #right>{{ i18n("cm") }}</template>
            </abc-input>

            <abc-autocomplete
                v-if="checkIfFormIsShown('SUPPORT_WIRES')"
                :label="i18n('pcf-label-support-wires')"
                :value="acFieldsSelected.supportWires"
                @input="(v) => (formdata.supportWires = v ? v.fieldValue : null)"
                :items="acFieldsValues.supportWires"
                :stringify="
                    (i) => {
                        return i ? i.fieldValueDescription : null;
                    }
                "
                :search.sync="acFieldsSearch.supportWires"
                itemId="fieldValue"
                maxHeight="300px"
                buttons
                :is-required="checkIfFormIsMandatory('SUPPORT_WIRES')"
                :isDisabled="readonly || !checkIfFormIsEditable('SUPPORT_WIRES', acFieldsSelected.supportWires)"
                :rules="
                    !readonly && checkIfFormIsMandatory('SUPPORT_WIRES')
                        ? [mandatoryRule, (v) => notFallbackOptionRule('supportWires', v)]
                        : []
                "
            >
                <template #items="{ item }">
                    {{ item.fieldValueDescription }}
                </template>
                <template #buttons>
                    <abc-tool-button
                        is-secondary
                        :title="i18n('clear-field')"
                        :isDisabled="readonly || !checkIfFormIsEditable('SUPPORT_WIRES', acFieldsSelected.supportWires)"
                        @click="
                            acFieldsSearch.supportWires = '';
                            formdata.supportWires = null;
                        "
                    >
                        <em class="abc-icon abc-icon-x text-xs"></em>
                    </abc-tool-button>
                </template>
            </abc-autocomplete>

            <abc-autocomplete
                v-if="checkIfFormIsShown('CULTIVATION_STATE')"
                :label="i18n('pcf-label-cultivation-state')"
                :value="acFieldsSelected.cultivationState"
                @input="(v) => (formdata.cultivationState = v ? v.fieldValue : null)"
                :items="acFieldsValues.cultivationState"
                :stringify="
                    (i) => {
                        return i ? i.fieldValueDescription : null;
                    }
                "
                :search.sync="acFieldsSearch.cultivationState"
                itemId="fieldValue"
                maxHeight="300px"
                buttons
                :is-required="checkIfFormIsMandatory('CULTIVATION_STATE')"
                :isDisabled="readonly || !checkIfFormIsEditable('CULTIVATION_STATE', acFieldsSelected.cultivationState)"
                :rules="
                    !readonly && checkIfFormIsMandatory('CULTIVATION_STATE')
                        ? [mandatoryRule, (v) => notFallbackOptionRule('cultivationState', v)]
                        : []
                "
            >
                <template #items="{ item }">
                    {{ item.fieldValueDescription }}
                </template>
                <template #buttons>
                    <abc-tool-button
                        is-secondary
                        :title="i18n('clear-field')"
                        :isDisabled="
                            readonly || !checkIfFormIsEditable('CULTIVATION_STATE', acFieldsSelected.cultivationState)
                        "
                        @click="
                            acFieldsSearch.cultivationState = '';
                            formdata.cultivationState = null;
                        "
                    >
                        <em class="abc-icon abc-icon-x text-xs"></em>
                    </abc-tool-button>
                </template>
            </abc-autocomplete>

            <abc-autocomplete
                v-if="checkIfFormIsShown('ORIGIN')"
                :label="i18n('pcf-label-origin')"
                :value="acFieldsSelected.origin"
                @input="(v) => (formdata.origin = v ? v.fieldValue : null)"
                :items="acFieldsValues.origin"
                :stringify="
                    (i) => {
                        return i ? i.fieldValueDescription : null;
                    }
                "
                :search.sync="acFieldsSearch.origin"
                itemId="fieldValue"
                maxHeight="300px"
                buttons
                :is-required="checkIfFormIsMandatory('ORIGIN')"
                :isDisabled="readonly || !checkIfFormIsEditable('ORIGIN', acFieldsSelected.origin)"
                :rules="
                    !readonly && checkIfFormIsMandatory('ORIGIN')
                        ? [mandatoryRule, (v) => notFallbackOptionRule('origin', v)]
                        : []
                "
            >
                <template #items="{ item }">
                    {{ item.fieldValueDescription }}
                </template>
                <template #buttons>
                    <abc-tool-button
                        is-secondary
                        :title="i18n('clear-field')"
                        :isDisabled="readonly || !checkIfFormIsEditable('ORIGIN', acFieldsSelected.origin)"
                        @click="
                            acFieldsSearch.origin = '';
                            formdata.origin = null;
                        "
                    >
                        <em class="abc-icon abc-icon-x text-xs"></em>
                    </abc-tool-button>
                </template>
            </abc-autocomplete>

            <abc-date-input
                v-if="checkIfFormIsShown('GRAFT_DATE')"
                :label="i18n('pcf-label-graft-date')"
                v-model="formdata.graftDate"
                :rangeMin="new Date(1990)"
                :rangeMax="today00"
                :is-required="checkIfFormIsMandatory('GRAFT_DATE')"
                :isDisabled="readonly || !checkIfFormIsEditable('GRAFT_DATE', formdata.graftDate)"
                :rules="!readonly && checkIfFormIsMandatory('GRAFT_DATE') ? [mandatoryRule] : []"
            />

            <abc-autocomplete
                v-if="checkIfFormIsShown('GRAFT_HOLDER')"
                :label="i18n('pcf-label-graft-holder')"
                :value="acFieldsSelected.graftHolder"
                @input="(v) => (formdata.graftHolder = v ? v.fieldValue : null)"
                :items="acFieldsValues.graftHolder"
                :stringify="
                    (i) => {
                        return i ? i.fieldValueDescription : null;
                    }
                "
                :search.sync="acFieldsSearch.graftHolder"
                itemId="fieldValue"
                maxHeight="300px"
                buttons
                :is-required="checkIfFormIsMandatory('GRAFT_HOLDER')"
                :isDisabled="readonly || !checkIfFormIsEditable('GRAFT_HOLDER', acFieldsSelected.graftHolder)"
                :rules="
                    !readonly && checkIfFormIsMandatory('GRAFT_HOLDER')
                        ? [mandatoryRule, (v) => notFallbackOptionRule('graftHolder', v)]
                        : []
                "
            >
                <template #items="{ item }">
                    {{ item.fieldValueDescription }}
                </template>
                <template #buttons>
                    <abc-tool-button
                        is-secondary
                        :title="i18n('clear-field')"
                        :isDisabled="readonly || !checkIfFormIsEditable('GRAFT_HOLDER', acFieldsSelected.graftHolder)"
                        @click="
                            acFieldsSearch.graftHolder = '';
                            formdata.graftHolder = null;
                        "
                    >
                        <em class="abc-icon abc-icon-x text-xs"></em>
                    </abc-tool-button>
                </template>
            </abc-autocomplete>

            <abc-input
                v-if="checkIfFormIsShown('COVERING')"
                :label="i18n('pcf-label-covering')"
                v-model="formdata.covering"
                :is-required="checkIfFormIsMandatory('COVERING')"
                :isDisabled="readonly || !checkIfFormIsEditable('COVERING', formdata.covering)"
                :rules="!readonly && checkIfFormIsMandatory('COVERING') ? [mandatoryRule] : []"
            />

            <abc-autocomplete
                v-if="checkIfFormIsShown('BIO')"
                :label="i18n('pcf-label-bio')"
                :value="acFieldsSelected.bio"
                @input="(v) => (formdata.bio = v ? v.fieldValue : null)"
                :items="acFieldsValues.bio"
                :stringify="
                    (i) => {
                        return i ? i.fieldValueDescription : null;
                    }
                "
                :search.sync="acFieldsSearch.bio"
                itemId="fieldValue"
                maxHeight="300px"
                buttons
                :is-required="checkIfFormIsMandatory('BIO')"
                :isDisabled="readonly || !checkIfFormIsEditable('BIO', acFieldsSelected.bio)"
                :rules="
                    !readonly && checkIfFormIsMandatory('BIO')
                        ? [mandatoryRule, (v) => notFallbackOptionRule('bio', v)]
                        : []
                "
            >
                <template #items="{ item }">
                    {{ item.fieldValueDescription }}
                </template>
                <template #buttons>
                    <abc-tool-button
                        is-secondary
                        :title="i18n('clear-field')"
                        :isDisabled="readonly || !checkIfFormIsEditable('BIO', acFieldsSelected.bio)"
                        @click="
                            acFieldsSearch.bio = '';
                            formdata.bio = null;
                        "
                    >
                        <em class="abc-icon abc-icon-x text-xs"></em>
                    </abc-tool-button>
                </template>
            </abc-autocomplete>

            <abc-autocomplete
                v-if="checkIfFormIsShown('PROTECTION_STRUCTURES')"
                :label="i18n('pcf-label-protection-structures')"
                :value="acFieldsSelected.protectionStructures"
                @input="(v) => (formdata.protectionStructures = v ? v.fieldValue : null)"
                :items="acFieldsValues.protectionStructures"
                :stringify="
                    (i) => {
                        return i ? i.fieldValueDescription : null;
                    }
                "
                :search.sync="acFieldsSearch.protectionStructures"
                itemId="fieldValue"
                maxHeight="300px"
                buttons
                :is-required="checkIfFormIsMandatory('PROTECTION_STRUCTURES')"
                :isDisabled="
                    readonly || !checkIfFormIsEditable('PROTECTION_STRUCTURES', acFieldsSelected.protectionStructures)
                "
                :rules="
                    !readonly
                        ? checkIfFormIsMandatory('PROTECTION_STRUCTURES')
                            ? [mandatoryRule, (v) => notFallbackOptionRule('protectionStructures', v)]
                            : [(v) => notFallbackOptionRule('protectionStructures', v)]
                        : []
                "
            >
                <template #items="{ item }">
                    {{ item.fieldValueDescription }}
                </template>
                <template #buttons>
                    <abc-tool-button
                        is-secondary
                        :title="i18n('clear-field')"
                        :isDisabled="
                            readonly || !checkIfFormIsEditable('FARMING_FORM', acFieldsSelected.protectionStructures)
                        "
                        @click="
                            acFieldsSearch.protectionStructures = '';
                            formdata.protectionStructures = null;
                        "
                    >
                        <em class="abc-icon abc-icon-x text-xs"></em>
                    </abc-tool-button>
                </template>
            </abc-autocomplete>

            <abc-autocomplete
                v-if="checkIfFormIsShown('QUALITY_SYSTEM')"
                :label="i18n('pcf-label-quality-system')"
                :value="acFieldsSelected.qualitySystem"
                @input="(v) => (formdata.qualitySystem = v ? v.fieldValue : null)"
                :items="acFieldsValues.qualitySystem"
                :stringify="
                    (i) => {
                        return i ? i.fieldValueDescription : null;
                    }
                "
                :search.sync="acFieldsSearch.qualitySystem"
                itemId="fieldValue"
                maxHeight="300px"
                buttons
                :is-required="checkIfFormIsMandatory('QUALITY_SYSTEM')"
                :isDisabled="readonly || !checkIfFormIsEditable('QUALITY_SYSTEM', acFieldsSelected.qualitySystem)"
                :rules="
                    !readonly
                        ? checkIfFormIsMandatory('QUALITY_SYSTEM')
                            ? [mandatoryRule, (v) => notFallbackOptionRule('qualitySystem', v)]
                            : [(v) => notFallbackOptionRule('qualitySystem', v)]
                        : []
                "
            >
                <template #items="{ item }">
                    {{ item.fieldValueDescription }}
                </template>
                <template #buttons>
                    <abc-tool-button
                        is-secondary
                        :title="i18n('clear-field')"
                        :isDisabled="
                            readonly || !checkIfFormIsEditable('QUALITY_SYSTEM', acFieldsSelected.qualitySystem)
                        "
                        @click="
                            acFieldsSearch.qualitySystem = '';
                            formdata.qualitySystem = null;
                        "
                    >
                        <em class="abc-icon abc-icon-x text-xs"></em>
                    </abc-tool-button>
                </template>
            </abc-autocomplete>
        </template>
    </div>
</template>

<script lang="ts">
import { Prop, Component, Mixins, Inject, InjectReactive, Watch, Ref } from "vue-property-decorator";
import { MODULE_ID } from "../..";
import { FromStore } from "@abaco/web-common/src/app";
import { TranslateResult } from "vue-i18n";
import DateUtils from "../../mixins/DateUtils";
import AreaUtils from "../../mixins/AreaUtils";
import { VineyardForm, PermanentCropFieldValues } from "../../models/PermanentCropForm";
import { DeclarationOut } from "../../models/Declaration";
import { Configuration } from "../../models/CropPlan";
import { PermanentCropFormValueConfig } from "../../models/Plot";
import { AbcInputExtended } from "../../models/AbcInputExtended";
import DeclFieldEditability from "../../mixins/DeclFieldEditability";

interface FieldOption extends PermanentCropFieldValues {
    isFallback?: boolean;
}

@Component
export default class VineyardPermanentCropForm extends Mixins(DateUtils, AreaUtils, DeclFieldEditability) {
    @Inject() i18n!: (key: string, values?: unknown) => TranslateResult;
    @InjectReactive() readonly declarationDetail!: DeclarationOut;

    @FromStore(MODULE_ID) curConfiguration!: Configuration | null;
    @FromStore(MODULE_ID) enabledPermanentCropFormsValues!: PermanentCropFormValueConfig[];

    @Prop() readonly value!: VineyardForm | null;
    @Prop() readonly fieldsValues!: { [k: string]: PermanentCropFieldValues[] } | null;
    @Prop() readonly declarationArea!: number | null;
    @Prop({ default: false }) disableRequirementCheck!: boolean;
    @Prop({ default: false }) disableNotCheckedFields!: boolean;
    @Prop({ default: false }) readonly!: boolean;
    @Prop({ default: false }) isNew!: boolean;
    @Prop({ default: false }) disableCheckOnMandatoryDeclFields!: boolean;

    @Ref("form_container") readonly formContainer!: HTMLElement;
    @Ref("stumps-number") readonly stumpsNumberInput!: AbcInputExtended;
    @Ref("stumps-density-100") readonly stumpsDensity100Input!: AbcInputExtended;

    private formdata = this.defaultFormData;

    private resizeObserver?: ResizeObserver;

    private acFieldsSearch: { [k: string]: string } = {};

    private skippCalcStumpsDensity = false;
    private skippCalcStumpsNumber = false;

    private get stumpsDensityCanBeCalculated() {
        return (
            this.formdata.stumpsNumber &&
            this.formdata.stumpsNumber > 0 &&
            this.declarationArea &&
            !this.skippCalcStumpsDensity
        );
    }

    private get stumpsNumberCanBeCalculated() {
        return (
            this.declarationArea &&
            this.formdata.distanceBetweenRowsCm != null &&
            this.formdata?.distanceOnTheRowCm != null &&
            !this.skippCalcStumpsNumber
        );
    }

    private get acFieldsValues() {
        return this.fieldsOptions
            ? Object.fromEntries(
                  Object.entries(this.fieldsOptions).map(([k, values]) => {
                      let filteredVals =
                          this.acFieldsSearch[k] &&
                          (!this.acFieldsSelected![k] ||
                              this.acFieldsSearch[k] != this.acFieldsSelected![k]!.fieldValueDescription)
                              ? values.filter((v) =>
                                    v.fieldValueDescription.toLowerCase().includes(this.acFieldsSearch[k].toLowerCase())
                                )
                              : values;
                      if (this.acFieldsSelected![k])
                          filteredVals = filteredVals.sort((i) =>
                              i.fieldValue == this.acFieldsSelected![k]?.fieldValue ? -1 : 1
                          );
                      return [k, filteredVals];
                  })
              )
            : null;
    }

    private get acFieldsSelected() {
        return this.fieldsOptions
            ? Object.fromEntries(
                  Object.entries(this.fieldsOptions).map(([k, values]) => {
                      return [
                          k,
                          this.formdata[k as keyof VineyardForm]
                              ? values.find((v) => v.fieldValue === this.formdata[k as keyof VineyardForm]) ?? null
                              : null,
                      ];
                  })
              )
            : null;
    }

    /**
     * Appends to fieldsValues items a fallback option for fields with a value no longer available
     */
    private get fieldsOptions(): { [k: string]: FieldOption[] } | null {
        return this.fieldsValues
            ? Object.fromEntries(
                  Object.entries(this.fieldsValues).map(([k, items]) => {
                      const val = this.formdata[k as keyof VineyardForm],
                          options = items.map((i) => ({ ...i, isFallback: false } as FieldOption));
                      if (val && !items.map((i) => i.fieldValue).includes(val.toString()))
                          options.push({
                              fieldValue: val.toString(),
                              fieldValueDescription: val.toString(),
                              isFallback: true,
                          } as FieldOption);
                      return [k, options];
                  })
              )
            : null;
    }

    private get mandatoryRule() {
        return (v: unknown) =>
            this.disableCheckOnMandatoryDeclFields || this.disableRequirementCheck || !!v || this.i18n("valid.mandatory-field");
    }

    private get distanceRangeRule() {
        return (v: string) => {
            const convertedValue = parseInt(v);

            return (
                v === null ||
                (convertedValue >= 50 && convertedValue <= 1000) ||
                this.i18n("pcf-info-val-between-50-1000")
            );
        };
    }

    private get polesDistanceRule() {
        return (v: string) => {
            const convertedValue = parseInt(v);
            return (
                this.disableRequirementCheck ||
                v === null ||
                (convertedValue >= 50 && convertedValue <= 1000) ||
                this.i18n("pcf-info-val-between-50-1000")
            );
        };
    }

    private get greaterThanZeroRule() {
        return (v: string) => {
            const convertedValue = parseInt(v);
            return this.disableRequirementCheck || v === null || convertedValue >= 0 || this.i18n("rule-val-gt0");
        };
    }

    private get percentageRule() {
        return (v: string) => {
            const convertedValue = parseInt(v);
            return (
                this.disableRequirementCheck ||
                v === null ||
                (convertedValue >= 0 && convertedValue <= 100) ||
                this.i18n("between-0-and-100-rule")
            );
        };
    }

    private get altitudeAboveSeaLevelRule() {
        return (v: string) => {
            const convertedValue = parseInt(v);
            return (
                this.disableRequirementCheck ||
                v === null ||
                (convertedValue >= 0 && convertedValue <= 3000) ||
                this.i18n("rule-val-altitude-above-sea-level").toString().replace("{minAltitude}", "0")
            );
        };
    }

    private get plantingYearRule() {
        return (v: string | null) => {
            if (v === null) return true;

            // Convert the string to a number
            const parsedYear = typeof v === "number" ? v : parseInt(v, 10);

            // Check if the year is not less than 1900
            if (parsedYear < 1900) {
                return this.i18n("year-1900-and-over-required").toString();
            }

            // Check if the year is not later than the current year
            const currentYear = new Date().getFullYear();
            if (parsedYear > currentYear) {
                return this.i18n("year-over-cur-year").toString();
            }

            return true;
        };
    }

    private notFallbackOptionRule(fieldId: keyof VineyardForm) {
        return this.acFieldsSelected && this.acFieldsSelected[fieldId] && this.acFieldsSelected[fieldId]?.isFallback
            ? this.i18n("deprecated-option")
            : null;
    }

    private get defaultFormData(): VineyardForm {
        return {
            altitudeAboveSeaLevel: null,
            areaSqm: null,
            bio: null,
            covering: null,
            cultivationState: null,
            cultivationTypeCode: null,
            distanceBetweenRowsCm: null,
            distanceOnTheRowCm: null,
            externalDescription: null,
            externalCode: null,
            failuresPerc: null,
            farmingForm: null,
            graftDate: null,
            graftHolder: null,
            headerAnchoring: null,
            irrigation: null,
            judgement: null,
            layering: null,
            origin: null,
            plantingType: null,
            plantingYear: null,
            shiftInYears: null,
            expectedCuttingDate: null,
            polesDistanceCm: null,
            polesHeader: null,
            polesWeaving: null,
            productDestinationCode: null,
            pruning: null,
            protectionStructures: null,
            qualitySystem: null,
            rock: null,
            skeleton: null,
            soilLayeringPerc: null,
            stumpsDensity100: null,
            stumpsNumber: null,
            subscriptionCodes: null,
            supportWires: null,
            terracing: null,
            varietyCode: null,
            variationTypeCode: null,
            vegetativeState: null,
            vineyardTypeCode: null,
        };
    }

    private get plotDateStart() {
        return this.curPlot?.fullRangeFromDate ?? new Date(1991);
    }

    private get plotDateEnd() {
        return this.curPlot?.fullRangeToDate ?? new Date(9999, 11, 31);
    }

    private get declPlantingDate() {
        return this.declarationDetail.fromDate ?? new Date(1970);
    }
    private set declPlantingDate(val) {
        this.$emit("bubbleEmit", "updateDeclPlantingDate", val);
    }

    private get declHarvestDate() {
        return this.declarationDetail.toDate;
    }
    private set declHarvestDate(val) {
        this.$emit("bubbleEmit", "updateDeclHarvestDate", val);
    }

    private get plantingAgeInfo(): string {
        const years = this.formdata ? new Date().getFullYear() - this.declPlantingDate.getFullYear() : 0;
        if (years > 100) return this.i18n("pfc-planting-age-info-f").toString();
        else if (years > 25 && years <= 100) return this.i18n("pfc-planting-age-info-e").toString();
        else if (years > 20 && years <= 25) return this.i18n("pfc-planting-age-info-d").toString();
        else if (years > 10 && years <= 20) return this.i18n("pfc-planting-age-info-c").toString();
        else if (years > 5 && years <= 10) return this.i18n("pfc-planting-age-info-b").toString();
        return this.i18n("pfc-planting-age-info-a").toString();
    }

    private get today00() {
        const date = new Date();
        date.setHours(0, 0, 0, 0);
        return date;
    }

    mounted() {
        this.formdata = Object.assign({}, this.defaultFormData, this.value);
        //
        if (
            (this.curConfiguration?.DISABLE_VALID_VALUED_DECL_FIELDS_EDIT === "TRUE" ||
                this.curConfiguration?.DISABLE_VALUED_DECL_FIELDS_EDIT === "TRUE") &&
            !this.isNew
        )
            this.checkFieldsValidation(this.formdata);
        this.$nextTick(() => {
            this.stumpsNumberInput?.runRules();
            this.stumpsDensity100Input?.runRules();
        });
        //
        this.resizeObserver = new ResizeObserver(() => {
            this.$emit("heightUpdated");
        });
        this.resizeObserver.observe(this.formContainer);
    }

    beforeDestroy() {
        if (this.resizeObserver) this.resizeObserver.unobserve(this.formContainer);
    }

    private getAreaHaFromSqm(sqmArea: number | null) {
        return sqmArea === null ? null : parseFloat(this.formattedArea(sqmArea).replace(",", "."));
    }

    private getAreaSqmFromHa(haArea: number | null) {
        return haArea === null ? null : Math.round(haArea * 10000 * 10000) / 10000;
    }

    @Watch("formdata", { deep: true, immediate: true })
    private onFormdataUpdate(newVal: VineyardForm | null, oldVal: VineyardForm | null) {
        this.$emit("input", newVal);
        if (oldVal == null && newVal) {
            this.skippCalcStumpsDensity = true;
            this.skippCalcStumpsNumber = true;
        }
    }

    @Watch("formdata.distanceBetweenRowsCm")
    private ondDstanceBetweenRowsCmUdopate(newVal: number | null, oldVal: number | null) {
        if (this.skippCalcStumpsNumber && oldVal == null && newVal) return;
        this.calcStumpsNumber();
        this.skippCalcStumpsNumber = false;
    }

    @Watch("formdata.distanceOnTheRowCm")
    private onDistanceOnTheRowCmUdopate(newVal: number | null, oldVal: number | null) {
        if (this.skippCalcStumpsNumber && oldVal == null && newVal) return;
        this.calcStumpsNumber();
        this.skippCalcStumpsNumber = false;
    }

    @Watch("formdata.declarationArea")
    private onDeclarationAreaUdopate(newVal: number | null, oldVal: number | null) {
        if (this.skippCalcStumpsNumber && oldVal == null && newVal) return;
        this.calcStumpsNumber();
        this.skippCalcStumpsNumber = false;
    }

    private calcStumpsNumber() {
        if (
            this.declarationArea &&
            this.formdata.distanceBetweenRowsCm != null &&
            this.formdata?.distanceOnTheRowCm != null
        ) {
            this.formdata.stumpsNumber =
                this.declarationArea /
                ((this.formdata.distanceBetweenRowsCm / 100) * (this.formdata?.distanceOnTheRowCm / 100));
            this.stumpsNumberInput?.runRules();
        }
    }

    @Watch("formdata.stumpsNumber")
    private onStumpsNumberUpdate(newVal: number | null, oldVal: number | null) {
        if (this.stumpsDensityCanBeCalculated && oldVal == null && newVal) return;
        this.calcStumpsDensity();
        this.skippCalcStumpsDensity = false;
    }

    @Watch("declarationArea")
    private onDeclarationAreaUpdate(newVal: number | null, oldVal: number | null) {
        if (this.stumpsDensityCanBeCalculated && oldVal == null && newVal) return;
        this.calcStumpsDensity();
        this.skippCalcStumpsDensity = false;
    }

    private calcStumpsDensity() {
        if (
            this.declarationArea
        ) {
            if (!this.formdata.stumpsNumber) this.formdata.stumpsDensity100 = null;
            // do not calculate density when stumpsNumber is set first time
            else this.formdata.stumpsDensity100 = Math.round((this.formdata.stumpsNumber * 10000) / this.declarationArea);
            this.stumpsDensity100Input?.runRules();
        }
    }

    @Watch("acFieldsSelected")
    private onAcFieldsSelectedUpdate() {
        if (this.acFieldsSelected)
            Object.keys(this.acFieldsSelected).forEach((k) => {
                if (!this.acFieldsSelected || !this.acFieldsSelected[k]) return;
                const temp = this.acFieldsSelected[k];
                this.acFieldsSearch[k] = temp && temp.fieldValueDescription ? temp.fieldValueDescription : "";
            });
    }

    private checkIfFormIsShown(formName: string): boolean {
        const value = this.enabledPermanentCropFormsValues.filter((value) => value.fieldCode == formName);
        return value.length == 1;
    }

    private checkIfFormIsMandatory(formName: string): boolean {
        if (this.readonly || this.disableRequirementCheck) return false;
        const value = this.enabledPermanentCropFormsValues.filter((value) => value.fieldCode == formName);
        return value.length == 1 && value[0].flMandatory;
    }

    protected checkFieldsValidation(formData: VineyardForm) {
        Object.entries(formData).forEach(([key, value]: [string, string | number]) => {
            const fieldKey = this.formDataFieldsKeys[key];
            // Mandatory fields check
            if (this.checkIfFormIsMandatory(fieldKey)) {
                if (value === null || value === "") {
                    this.pushToNotValidFields(fieldKey);
                }
            }
            // Generic rules check
            if (this.vineyardPropertyRules[key].length > 0 && value !== null && value !== "") {
                this.vineyardPropertyRules[key].forEach((rule: string) => {
                    if (!this.rules[rule].test(value.toString())) {
                        this.pushToNotValidFields(fieldKey);
                    }
                });
            }
            // Not fallback option check
            if (this.acFieldsSelected && this.acFieldsSelected[key] && this.acFieldsSelected[key]?.isFallback) {
                this.pushToNotValidFields(fieldKey);
            }

            this.setVineyardFormFieldEditability(fieldKey, this.isNew, value);
        });
    }

    private checkIfFormIsEditable(formName: string, val: string): boolean {
        if (this.disableNotCheckedFields) return false;

        const value = this.enabledPermanentCropFormsValues.filter((value) => value.fieldCode == formName);
        if (value.length == 1 && value[0].flEditable) {
            return !this.disabledFields.has(formName);
        }
        return false;
    }
}
</script>

<style lang="scss" scoped>
.fakeput {
    display: flex;
    align-content: center;
    line-height: 1.5;
    padding: 0.4375rem 0;
}
</style>
