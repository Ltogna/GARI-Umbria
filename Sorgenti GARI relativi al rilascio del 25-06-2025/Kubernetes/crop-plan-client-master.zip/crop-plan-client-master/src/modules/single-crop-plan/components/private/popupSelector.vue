<template>
    <fragment>
        <abc-loader v-if="loading" scope="fixed" />
        <div v-else>
            <div v-if="selectorStep === 'idle'">
                <div class="overlay"></div>
                <div class="popup-wrap z-50 w-full lg:w-8/12 xxl:w-7/12">
                    <abc-nav-bar-item-panel style="min-height: 300px" title="select-crop-plan" i18nKeys>
                        <template #tabs class="mx-4">
                            <abc-tab><em class="abc-icon abc-icon-folder pr-1" />{{ i18n("search-crop-plan") }}</abc-tab>
                        </template>

                        <div class="w-full h-full">
                            <div class="h-full w-full flex flex-col overflow-hidden">
                                <div class="flex flex-row">
                                    <search-crop-plans-criteria :reset-filter="resetFilter" v-model="filter" />
                                </div>
                                <search-crop-plans-results
                                    :filter="filter"
                                    @next-step="nextStep"
                                    @added-new-crop-plan="triggerLoadOnNewCropPlan"
                                    :triggerLoad="triggerLoad"
                                />
                            </div>
                        </div>
                    </abc-nav-bar-item-panel>
                </div>
            </div>
            <div v-if="selectorStep === 'hasCropPlanType'">
                <div class="overlay" @click="closeModal"></div>
                <div class="popup-wrap z-50 w-full lg:w-8/12 xxl:w-7/12">
                    <abc-nav-bar-item-panel style="min-height: 300px" title="select-council" i18nKeys>
                        <div class="h-full w-full flex flex-col overflow-hidden">
                            <search-council-criteria
                                :reset-filter="resetFilter"
                                v-model="filter"
                                :filterBySubject="filterBySubject"
                                @update-filter-by-subject="updateFilterBySubject"
                            />
                            <search-council-results
                                :filter="filter"
                                @select="setCurrentCouncil"
                                :triggerLoad="triggerLoad"
                                :filterBySubject="filterBySubject"
                            />
                        </div>
                    </abc-nav-bar-item-panel>
                </div>
            </div>
            <div v-if="selectorStep === 'selectTime'">
                <div class="overlay" @click="closeModal"></div>
                <div class="popup-wrap z-50 w-8/12 lg:w-5/12 xxl:w-3/12">
                    <abc-nav-bar-item-panel title="select-point-in-time" i18nKeys>
                        <div class="p-2 mx-auto py-3 flex justify-center single-cp-date-selector">
                            <div class="flex flex-col">
                                <abc-date-picker
                                    v-model="curPointInTime"
                                    class="flex justify-center"
                                    hide-delete
                                    hideNotAvailableDates
                                />
                            </div>
                        </div>
                    </abc-nav-bar-item-panel>
                </div>
            </div>
        </div>
    </fragment>
</template>

<script lang="ts">
import { Vue, Component, Inject, Prop, Watch } from "vue-property-decorator";
import { TranslateResult } from "vue-i18n";
import SearchCropPlansCriteria from "../navbar/crop-plan-select/SearchCropPlansCriteria.vue";
import SearchCropPlansResults from "../navbar/crop-plan-select/SearchCropPlansResults.vue";
import SearchCouncilCriteria from "../navbar/council-select/SearchCouncilCriteria.vue";
import SearchCouncilResults from "../navbar/council-select/SearchCouncilResults.vue";
import { FromStore } from "@abaco/web-common/src/app";
import SingleCropPlanModule, { MODULE_ID } from "../..";
import { Business } from "../../models/Business";
import { Configuration, CropPlan, CropPlanDates, CropPlanType } from "../../models/CropPlan";
import { Council } from "../../models/Council";

@Component({
    components: {
        SearchCropPlansCriteria,
        SearchCropPlansResults,
        SearchCouncilResults,
        SearchCouncilCriteria,
    },
})
export default class PopupSelector extends Vue {
    @Inject() i18n!: (key: string, values?: unknown) => TranslateResult;
    @Inject(MODULE_ID) singleCropPlanModule!: SingleCropPlanModule;

    @FromStore(MODULE_ID) curConfiguration!: Configuration | null;
    @FromStore(MODULE_ID) curPointInTime!: Date | null;
    @FromStore(MODULE_ID) business!: Business | null;
    @FromStore(MODULE_ID) curCropPlan!: CropPlan | null;
    @FromStore(MODULE_ID) availableCropPlanTypes!: CropPlanType[];
    @FromStore(MODULE_ID) curCouncil!: Council | null;
    @FromStore(MODULE_ID) selectorStep!: string;
    @FromStore(MODULE_ID) cropPlanDates!: CropPlanDates;

    @Prop() url!: URL;

    private loading = true;
    private filter = "";
    private triggerLoad = 0;
    private resetFilter = 0;
    private filterBySubject = true;
    private openedAtFixedDate = false;

    async mounted() {
        if (!this.curPointInTime && !this.openedAtFixedDate) this.curPointInTime = new Date();

        const businessId = this.url.searchParams.get("businessId");

        if (!this.business && businessId && !!businessId.trim()) {
            this.loading = true;
            const business = await this.singleCropPlanModule.businessApi.getBusiness(businessId);

            if (business) {
                this.business = business;
                const cropPlanTypes = await this.singleCropPlanModule.cropPlanApi.getCropPlanTypes(
                    this.business.businessId
                );
                this.availableCropPlanTypes = cropPlanTypes;
            }

            if (this.url.searchParams.has("cropPlanTypeCode")) {
                const cropPlanTypeCode = this.url.searchParams.get("cropPlanTypeCode") as string;
                const cp = this.availableCropPlanTypes.find((it) => cropPlanTypeCode === it.cropPlanTypeCode);

                if (cp && !cp.multiple) {
                    const cropPlans = await this.singleCropPlanModule.cropPlanApi.getCropPlans(
                        business.businessId,
                        cropPlanTypeCode
                    );

                    const cropPlan = cropPlans.find((it) => it.cropPlanTypeCode === cropPlanTypeCode);

                    if (cropPlan) {
                        this.curCropPlan = cropPlan;
                        this.selectorStep = "hasCropPlanType";
                    } else {
                        const newCropPlan = await this.singleCropPlanModule.cropPlanApi.insertCropPlan(businessId, {
                            cropPlanTypeCode: cropPlanTypeCode,
                            description: this.i18n("crop-plan-description-with-type", {
                                cpTypeDescription: cp.description ?? cropPlanTypeCode,
                            }) as string,
                        });
                        this.curCropPlan = newCropPlan;
                        this.selectorStep = "hasCropPlanType";
                    }
                }
            }

            this.loading = false;
        }
    }

    private nextStep() {
        this.selectorStep = "hasCropPlanType";
        this.filter = "";
    }

    private setCurrentCouncil(e: Council | null) {
        if (!e) {
            this.selectorStep = "hasCouncil";
            return;
        }
        this.curCouncil = e;
        this.selectorStep = "hasCouncil";
    }

    private updateFilterBySubject(e: boolean) {
        this.filterBySubject = e;
    }

    @Watch("curPointInTime")
    private timeChanged() {
        if (this.selectorStep === "selectTime") this.selectorStep = "hasCouncil";
    }

    @Watch("cropPlanDates.fixedOpenDate", { deep: true, immediate: true })
    private onConfigurationUpdate() {
        if (!this.openedAtFixedDate && typeof this.cropPlanDates?.fixedOpenDate == "string") {
            const openDate = this.cropPlanDates.fixedOpenDate;
            this.curPointInTime =
                openDate.length == 4
                    ? new Date(
                          new Date().getFullYear(),
                          parseInt(openDate.slice(0, 2)) - 1,
                          parseInt(openDate.slice(2))
                      )
                    : new Date(
                          parseInt(openDate.slice(0, 4)),
                          parseInt(openDate.slice(4, 6)) - 1,
                          parseInt(openDate.slice(6))
                      );
            this.openedAtFixedDate = true;
        }
    }

    private triggerLoadOnNewCropPlan() {
        this.triggerLoad++;
    }

    private closeModal() {
        if (this.curCouncil) this.selectorStep = "hasCouncil";
    }
}
</script>

<style lang="scss" scoped>
.overlay {
    position: absolute;
    height: 100%;
    width: 100%;
    background-color: black;
    opacity: 0.4;
    z-index: 25;
}
.popup-wrap {
    display: flex;
    justify-content: center;
    position: fixed;
    margin-left: auto;
    margin-right: auto;
    min-height: 300px;
    max-height: calc(100vh - 87px);
    align-items: stretch;
    cursor: initial;
    top: 25px;
    right: 0;
    left: 0;
}
</style>
