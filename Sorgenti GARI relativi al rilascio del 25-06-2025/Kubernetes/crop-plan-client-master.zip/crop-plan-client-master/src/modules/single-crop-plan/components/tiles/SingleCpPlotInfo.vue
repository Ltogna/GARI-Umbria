<template>
    <layout
        :title="i18n('field-details')"
        :show-back="true"
        :show-close="false"
        @back="$emit('close')"
        @close="$emit('close')"
    >
        <div class="flex flex-col py-2 px-3 divide-y divide-border overflow-auto h-full">
            <div v-if="!hideFieldName" class="flex pt-4">
                <p class="w-5/5 font-bold text-secondary-700 text-xl tracking-wider uppercase">
                    {{ curPlot.description }}
                </p>
            </div>

            <div class="flex flex-col pt-2 pb-2 border-t-0" style="border-top: 0">
                <div class="flex">
                    <p class="w-5/5 text-label-primary">{{ i18n("field-id") }}</p>
                </div>
                <div class="flex pb-2">
                    <p class="w-5/5">{{ curPlot.plotCode || i18n("detail.data_not_present") }}</p>
                </div>
                <template v-if="!hideFieldName">
                    <div class="flex">
                        <p class="w-5/5 text-label-primary">{{ i18n("field-name") }}</p>
                    </div>
                    <div class="flex pb-2">
                        <p class="w-5/5">{{ curPlot.description || i18n("detail.data_not_present") }}</p>
                    </div>
                </template>
                <template v-if="curPlot.notes">
                    <div class="flex">
                        <p class="w-5/5 text-label-primary">{{ i18n("field-notes") }}</p>
                    </div>
                    <div class="flex pb-2">
                        <p class="w-5/5">{{ curPlot.notes }}</p>
                    </div>
                </template>
                <template v-if="showParcelInfo && showParcelName">
                    <div
                        v-if="
                            (curPlot.parcelIntersections.length === 1 &&
                                curPlot.parcelIntersections[0].description !=
                                    curPlot.parcelIntersections[0].parcelCode) ||
                            curPlot.parcelIntersections.length != 1
                        "
                        class="flex"
                    >
                        <p class="w-5/5 text-label-primary">{{ i18n("parcel-name") }}</p>
                    </div>
                    <div
                        v-if="
                            curPlot.parcelIntersections.length === 1 &&
                            curPlot.parcelIntersections[0].description != curPlot.parcelIntersections[0].parcelCode
                        "
                        class="flex pb-2"
                    >
                        <p class="w-5/5">
                            {{ curPlot.parcelIntersections[0].description || i18n("detail.data_not_present") }}
                        </p>
                    </div>
                    <div v-else-if="curPlot.parcelIntersections.length > 1" class="flex pb-2">
                        <p class="w-5/5">{{ i18n("multiple-values") }}</p>
                    </div>
                    <div v-else-if="curPlot.parcelIntersections.length === 0" class="flex pb-2">
                        <p class="w-5/5">{{ i18n("no-parcel-intersection") }}</p>
                    </div>
                </template>
                <div class="flex">
                    <p class="w-5/5 text-label-primary">{{ i18n("council") }}</p>
                </div>
                <div class="flex pb-2">
                    <p class="w-5/5">{{ curCouncil ? curCouncil.description : i18n("detail.data_not_present") }}</p>
                </div> 
                <div v-if="showParcelInfo" class="pb-2">
                    <div
                        v-for="e in curPlot.parcelIntersections"
                        :key="e.code"
                        class="rounded justify-between w-full bg-bg-500 px-3 py-2 text-sm my-2"
                    >
                        <div>
                            <p class="font-semibold ">
                                {{ i18n("parcel-id") }}
                            </p>
                            <p class="font-bold pt-2">{{ e.parcelCode }}</p>
                            <p>{{ e.landCoverDescription }}</p>
                        </div>
                        <div v-if="curConfiguration.ENABLE_PARCELS_NOTES" class="bg-white rounded mt-2 p-2" >
                            <p v-if="e.notes" class="font-semibold border-b pb-1">
                                {{ i18n("notes") }}
                            </p>
                            <p v-if="e.notes" class="py-2">
                                {{ e.notes }}
                            </p>
                            <div class="flex justify-end">
                                <abc-button
                                    is-outlined
                                    is-secondary 
                                    @click="showParcelTile(e)">
                                        <em class="abc-icon abc-icon-pen-2" />
                                        {{ e.notes ? i18n('edit-notes') : i18n('add-notes') }}
                                </abc-button>
                            </div>
                        </div>
                    </div>
                    <div
                        v-if="
                            !curPlot.parcelIntersections ||
                            (curPlot.parcelIntersections && curPlot.parcelIntersections.length === 0)
                        "
                        class="text-secondary-200"
                    >
                        {{ i18n("no-parcel-intersection") }}
                    </div>
                </div>
                
                <div class="flex">
                    <p class="w-5/5 text-label-primary">{{ i18n("crops") }}</p>
                </div>
                <div class="flex flex-col pb-2">
                    <div
                        v-for="e in uniqueDeclaration"
                        :key="e.declCode"
                        class="flex rounded justify-between w-full bg-bg-500 px-3 py-2 text-sm mt-1"
                    >
                        <div class="font-semibold">
                            {{ e.landuse.description ? e.landuse.description : e.landuse.code }}
                        </div>
                        <div class="flex flex-col text-xs">
                            <div class="text-label-primary" style="padding-bottom: 1px">
                                {{ e.fromDate ? formattedDate(e.fromDate) : i18n("detail.data_not_present") }}
                            </div>
                            <div class="text-label-primary">
                                {{ e.toDate ? formattedDate(e.toDate) : i18n("detail.data_not_present") }}
                            </div>
                        </div>
                    </div>
                    <div
                        v-if="!curPlot.decls || (curPlot.decls && curPlot.decls.length === 0)"
                        class="text-secondary-200"
                    >
                        {{ i18n("crops-not-present") }}
                    </div>
                </div>
            </div>
            <div class="flex flex-col py-4">
                <div class="flex justify-between pb-2">
                    <p class="text-label-primary">{{ i18n("start-date-first") }}</p>
                    <p class="">
                        {{ curPlot.fullRangeFromDate ? formattedDate(curPlot.fullRangeFromDate) : i18n("detail.data_not_present") }}
                    </p>
                </div>
                <div class="flex justify-between">
                    <p class="text-label-primary">{{ i18n("end-date-first") }}</p>
                    <p class="">
                        {{
                            curPlot.fullRangeToDate
                                ? curPlot.fullRangeToDate.getTime() === new Date(9999, 11, 31).getTime()
                                    ? "-"
                                    : formattedDate(curPlot.fullRangeToDate)
                                : i18n("detail.data_not_present")
                        }}
                    </p>
                </div>
            </div>
            <div class="flex py-4">
                <div class="flex flex-col w-6/12">
                    <p class="flex text-label-primary">{{ i18n("plot-field-occupied") }}</p>
                    <div class="flex lowercase items-baseline">
                        <span class="font-bold text-3xl pr-1" style="font-size: 26px">{{ fieldOccupied }}</span>
                        <span class="text-base">%</span>
                    </div>
                </div>
                <div class="flex flex-col w-6/12">
                    <p class="flex text-label-primary">{{ i18n("pcf-label-area") }}</p>
                    <div class="flex lowercase items-baseline">
                        <span class="font-bold text-3xl pr-1" style="font-size: 26px">{{
                            formattedArea(curPlot.areaSqm)
                        }}</span>
                        <span class="text-base">{{ areaLabel() }}</span>
                    </div>
                </div>
            </div>
            <div
                class="flex flex-col py-4 w-full"
                v-if="warningAnomalies.length !== 0 || blockingAnomalies.length !== 0"
            >
                <p class="flex text-label-primary">{{ i18n("anomalies") }}</p>
                <div class="flex flex-grow flex-col items-baseline pt-3">
                    <div v-if="warningAnomalies.length > 0" class="bg-warning-100 w-full px-6 py-4 rounded-xl mb-2">
                        <div class="text-warning-600 text-xl font-bold">
                            <em class="text-warning-600 fa-regular fa-triangle-exclamation mr-5" />{{
                                i18n("warning-anomalies")
                            }}
                        </div>
                    </div>
                    <table aria-describedby="" style="border: none" cellspacing="0" cellpadding="0">
                        <tr v-for="item in warningAnomalies" :key="item.errorCode">
                            <td class="warning-bullet pr-2">&bull;</td>
                            <td>
                                {{ item.errorDescription ? item.errorDescription : item.errorCode }}
                            </td>
                        </tr>
                    </table>
                    <div
                        v-if="blockingAnomalies.length > 0"
                        class="bg-danger-100 w-full px-6 py-4 rounded-xl mb-2 mt-5"
                    >
                        <div class="text-danger-600 text-xl font-bold">
                            <em class="text-danger-600 fa-regular fa-circle-xmark mr-5" />{{
                                i18n("blocking-anomalies")
                            }}
                        </div>
                    </div>
                    <table aria-describedby="" style="border: none" cellspacing="0" cellpadding="0">
                        <tr v-for="item in blockingAnomalies" :key="item.errorCode">
                            <td class="blocking-bullet pr-2">&bull;</td>
                            <td>
                                {{ item.errorDescription ? item.errorDescription : item.errorCode }}
                            </td>
                        </tr>
                    </table>
                </div>
            </div>
        </div>

        <div class="flex justify-center border-t sticky bottom-0 py-3">
            <abc-button class="mr-2" is-secondary is-outlined @click="$emit('close')">
                <em class="abc-icon abc-icon-arrow-left-round" /> {{ i18n("back") }}
            </abc-button>
        </div>
    </layout>
</template>

<script lang="ts">
import { Component, Inject, Mixins, Watch } from "vue-property-decorator";
import { TranslateResult } from "vue-i18n";
import SingleCropPlanModule, { MODULE_ID } from "../..";
import { FromStore, ToastOptions } from "@abaco/web-common/src/app";
import { Business } from "../../models/Business";
import { Anomaly, Parcel, Plot } from "../../models/Plot";
import DateUtils from "../../mixins/DateUtils";
import AreaUtils from "../../mixins/AreaUtils";
import Layout from "../private/mapSidebarModal.vue";
import { Council } from "../../models/Council";
import { Configuration } from "../../models/CropPlan";

@Component({
    components: {
        Layout,
    },
})
export default class SingleCpPlotInfo extends Mixins(DateUtils, AreaUtils) {
    @Inject() i18n!: (key: string, values?: unknown) => TranslateResult;
    @Inject() toast!: (message: string, options?: ToastOptions) => TranslateResult;
    @Inject(MODULE_ID) singleCropPlanModule!: SingleCropPlanModule;

    @FromStore(MODULE_ID) curConfiguration!: Configuration | null;
    @FromStore(MODULE_ID) business!: Business;
    @FromStore(MODULE_ID) curPlot!: Plot | null;
    @FromStore(MODULE_ID) curPlots!: Plot[];
    @FromStore(MODULE_ID) curCouncil!: Council | null;
    @FromStore(MODULE_ID) curPointInTime!: Date;
    @FromStore(MODULE_ID) showParcelName!: boolean;
    @FromStore(MODULE_ID) hideFieldName!: boolean;
    @FromStore(MODULE_ID) openParcelTile!: boolean;
    @FromStore(MODULE_ID) curParcel!: Parcel;

    private showParcelTile(e: Parcel){
        this.curParcel = e;
        this.openParcelTile = true;
    }

    private get showParcelInfo() {
        return this.curConfiguration?.HIDE_PARCELS === "TRUE" ? false : true;
    }

    private get fieldOccupied(): number {
        if (!this.curPlot) return 0;
        let totalCropArea = 0;
        this.curPlot.decls
            .filter(
                (e) =>
                    e.fromDate.getTime() <= this.curPointInTime.getTime() &&
                    e.toDate.getTime() >= this.curPointInTime.getTime()
            )
            .forEach((e) => {
                if (!this.curPlot) return;
                let areaSqm = 0;
                if (e.areaPerc === 100) {
                    areaSqm = this.curPlot.areaSqm;
                } else {
                    const plotAreaHa = this.curPlot.areaSqm;
                    const onePercent = plotAreaHa / 100;
                    areaSqm = Math.round(onePercent * e.areaPerc * 10000) / 10000;
                }
                totalCropArea = totalCropArea + areaSqm;
            });
        const areaPercent = this.curPlot.areaSqm / 100;
        const res = totalCropArea / areaPercent;
        return Math.round(isNaN(res) ? 0 : res);
    }

    private get warningAnomalies() {
        if (!this.curPlot) return [];
        const plotWarningAnomalies = this.curPlot.anomalies.filter((anomaly) => !anomaly.blocking);
        const declarationsWarningAnomalies: Anomaly[] = [];
        for (const declaration of this.curPlot.decls)
            declarationsWarningAnomalies.push(...declaration.anomalies.filter((anomaly) => !anomaly.blocking));

        for (const parcel of this.curPlot.parcelIntersections) {
            if (!parcel.anomalies) continue;
            declarationsWarningAnomalies.push(...parcel.anomalies.filter((anomaly) => !anomaly.blocking));
        }

        const cumulativeArray = [...plotWarningAnomalies, ...declarationsWarningAnomalies];

        return [...new Map(cumulativeArray.map((item) => [item.errorCode, item])).values()].sort((a, b) =>
            a.errorCode > b.errorCode ? 1 : -1
        );
    }

    private get blockingAnomalies() {
        if (!this.curPlot) return [];
        const plotBlockingAnomalies = this.curPlot.anomalies.filter((anomaly) => anomaly.blocking);
        const declarationsBlockingAnomalies: Anomaly[] = [];
        for (const declaration of this.curPlot.decls)
            declarationsBlockingAnomalies.push(...declaration.anomalies.filter((anomaly) => anomaly.blocking));

        for (const parcel of this.curPlot.parcelIntersections) {
            if (!parcel.anomalies) continue;
            declarationsBlockingAnomalies.push(...parcel.anomalies.filter((anomaly) => anomaly.blocking));
        }

        const cumulativeArray = [...plotBlockingAnomalies, ...declarationsBlockingAnomalies];

        return [...new Map(cumulativeArray.map((item) => [item.errorCode, item])).values()].sort((a, b) =>
            a.errorCode > b.errorCode ? 1 : -1
        );
    }

    private get uniqueDeclaration() {
        return this.curPlot?.decls.filter(
            (v, i, arr) =>
                arr.findIndex(
                    (v2) =>
                        v.landuse.code === v2.landuse.code &&
                        v.fromDate.getTime() === v2.fromDate.getTime() &&
                        v.toDate.getTime() === v2.toDate.getTime()
                ) === i
        );
    }
}
</script>

<style lang="scss" scoped>
ul.warning li::before {
    content: "\2022";
    color: var(--warning-600);
    font-weight: bold;
    display: inline-block;
    width: 1em;
    margin-left: 1em;
}
ul.danger li::before {
    content: "\2022";
    color: var(--danger-600);
    font-weight: bold;
    display: inline-block;
    width: 1em;
    margin-left: 1em;
}
</style>
