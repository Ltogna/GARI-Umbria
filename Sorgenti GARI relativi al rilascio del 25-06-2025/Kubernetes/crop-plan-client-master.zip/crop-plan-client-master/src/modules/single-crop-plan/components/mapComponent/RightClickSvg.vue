<template functional>
    <svg width="15px" height="16px" viewBox="0 0 500 500" xml:space="preserve">
        <g transform="matrix(0.94 0 0 0.94 250.09 250.12)">
            <path
                style="
                    stroke: none;
                    stroke-width: 1;
                    stroke-dasharray: none;
                    stroke-linecap: butt;
                    stroke-dashoffset: 0;
                    stroke-linejoin: miter;
                    stroke-miterlimit: 4;
                    fill: #b1b1b5;
                    fill-rule: nonzero;
                    opacity: 1;
                "
                vector-effect="non-scaling-stroke"
                transform=" translate(-192, -256)"
                d="M 384 160 L 384 352 C 384 440.36556 312.36556 512 224 512 L 160 512 C 71.63444 512 0 440.36556 0 352 L 0 160 C 0 71.63444 71.63444 0 160 0 L 224 0 C 312.36556 0 384 71.63444 384 160 z M 352 224 L 32 224 L 32 352 C 32.07716 422.66046 89.33954 479.92284 160 480 L 224 480 C 294.66046 479.92284 351.92284 422.66046 352 352 z M 352 160 C 351.92284 89.33954 294.66046 32.077160000000006 224 32 L 208 32 L 208 192 L 352 192 z"
                stroke-linecap="round"
            />
        </g>
    </svg>
</template>
