<template>
    <div>
        <div v-if="openCloneMode" class="flex flex-col w-full h-full p-5">
            <abc-loader v-if="loadingCopyOrMove" scope="absolute" :size="20" />
            <div class="flex flex-row h-full">
                <div class="flex flex-col w-1/2 flex-grow">
                    <span class="font-semibold text-2xl">{{ i18n("copy-uv") }}</span>
                    <span class="font-bold mt-6">{{
                        i18n("select-destination-plot" + (multiplePlotSelection ? "-multiple" : ""))
                    }}</span>
                    <span class="mt-2">{{
                        i18n("copy-description" + (multiplePlotSelection ? "-multiple" : ""))
                    }}</span>
                </div>
                <div class="flex flex-col w-1/2 h-full">
                    <div
                        :class="
                            'flex flex-row rounded-2xl px-6 py-4 m-auto ' +
                            (!noClonePlotCodes.length ? 'bg-info-50' : 'bg-danger-50')
                        "
                        style="min-width: 470px; min-height: 85px"
                    >
                        <em
                            class="text-info-400 text-3xl fa-regular fa-map-location-dot"
                            style="margin-top: auto; margin-bottom: auto; margin-right: 30px"
                        />
                        <span v-if="!targetPlots.length" style="margin-top: auto; margin-bottom: auto">
                            {{ i18n("no-field-selected") }}
                        </span>
                        <div
                            v-else
                            class="w-full"
                            style="margin-top: auto; margin-bottom: auto; overflow: auto; max-height: 100%"
                        >
                            <span v-if="loadingCompatibleUse" class="flex flex-row">
                                <span style="margin-top: auto; margin-bottom: auto">{{
                                    i18n("checking-compatible-use")
                                }}</span>
                                <abc-loader style="margin-left: 10px" />
                            </span>
                            <div v-else-if="!noClonePlotCodes.length">
                                <div v-for="(plot, index) in targetPlots" :key="index" class="flex">
                                    <div class="w-full">{{ plot.description }}</div>
                                    <div class="w-full font-semibold text-right">
                                        {{ formattedArea(plot.areaSqm || 0) + "&thinsp;" + areaLabel() }}
                                    </div>
                                </div>
                            </div>
                            <span v-else class="text-danger-700 font-bold">{{
                                i18n("not-compatible-use" + (multiplePlotSelection ? "-multiple" : ""))
                            }}</span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="flex flex-row" style="margin-left: 1.5px; margin-top: auto">
                <abc-button
                    @click="() => $emit('openCloneModeUpdate', false)"
                    is-icon
                    is-outlined
                    style="min-width: 150px"
                >
                    <em class="abc-icon abc-icon-arrow-left" style="margin-top: 3.5px; margin-bottom: 3.5px" />&nbsp;{{
                        i18n("cancel")
                    }}
                </abc-button>
                <div class="ml-2">
                    <abc-radio v-model="copyMove" radio-value="COPY" :label="i18n('copy-uv-in-destination-parcel')" />
                    <abc-radio v-model="copyMove" radio-value="MOVE" :label="i18n('move-uv-in-destination-parcel')" />
                </div>
                <abc-button
                    v-if="targetPlots.length && !noClonePlotCodes.length"
                    @click="
                        checkAndExecAddDecl(
                            () => copyOrMoveDeclarations(),
                            () => $emit('openCloneModeUpdate', false)
                        )
                    "
                    is-icon
                    is-success
                    class="ml-5"
                    style="min-width: 150px"
                >
                    <em class="abc-icon abc-icon-arrow-right" style="margin-top: 3.5px; margin-bottom: 3.5px" />&nbsp;
                    {{ i18n("continue") }}
                </abc-button>
            </div>
        </div>

        <!-- DUPLICATED DECL MODAL -->
        <abc-modal
            modal-class="w-full lg:w-6/12 xxl:w-4/12"
            :title="i18n('copy-uv')"
            :top-pinned="true"
            show-navbar
            v-if="showDeclAlreadyExistModal"
            @close="showDeclAlreadyExistModal = false"
        >
            <template #body>
                <p>{{ i18n("copy-move-not-available-duplicated-declarations") }}:</p>
                <div style="max-height: 500px; overflow-y: scroll">
                    <ul class="pl-5 my-3" style="list-style-type: circle">
                        <li v-for="(decl, i) in existingDeclarations" :key="'existing-decl' + i">
                            <div class="flex">
                                <div>
                                    <p class="truncate-target font-bold">
                                        {{ decl.landuse.description || decl.landuse.code }}
                                    </p>
                                </div>
                                <div>
                                    <div class="flex flex-col px-2">
                                        <p style="white-space: nowrap">
                                            {{ i18n("external-description") }}: {{ getDeclDescription(decl) }}
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </li>
                    </ul>
                </div>
            </template>
            <template #footer>
                <div class="flex w-full justify-end">
                    <abc-button is-secondary is-outlined @click="showDeclAlreadyExistModal = false">
                        {{ i18n("close") }}
                    </abc-button>
                </div>
            </template>
        </abc-modal>
    </div>
</template>
<script lang="ts">
import { Component, Prop, Inject, Mixins } from "vue-property-decorator";
import { TranslateResult } from "vue-i18n";
import SingleCropPlanModule, { MODULE_ID } from "../..";
import {
    TimelineSection,
    CopyOrMoveDeclarationsResponse,
    CopyOrMoveDeclarationsPayload,
    Declaration,
} from "../../models/Declaration";
import { FromStore, ToastOptions } from "@abaco/web-common/src/app";
import { CopyOrMove, Plot } from "../../models/Plot";
import { Business } from "../../models/Business";
import { Council } from "../../models/Council";
import { formatDate } from "../../api/Utils";
import AreaUtils from "../../mixins/AreaUtils";
import CanEditCheckAndExecute from "../../mixins/CanEditCheckAndExecute";
import { PermanentCropField, PermanentCropForm } from "../../models/PermanentCropForm";
import { VINEYARD_FORM } from "../../../../shared/constants";

@Component
export default class CopyOrMoveDeclarations extends Mixins(AreaUtils, CanEditCheckAndExecute) {
    @Inject() i18n!: (key: string, values?: unknown) => TranslateResult;
    @Inject(MODULE_ID) singleCropPlanModule!: SingleCropPlanModule;
    @Inject() toast!: (message: string, options?: ToastOptions) => TranslateResult;

    @FromStore(MODULE_ID) business!: Business;
    @FromStore(MODULE_ID) curTimelineSection!: TimelineSection | null;
    @FromStore(MODULE_ID) curTimelineSections!: TimelineSection[];
    @FromStore(MODULE_ID) curCouncil!: Council | null;
    @FromStore(MODULE_ID) plots!: Plot[];
    @FromStore(MODULE_ID) toolbuttonsEnabled!: boolean;
    @FromStore(MODULE_ID) multiplePlotSelection!: boolean;
    @FromStore(MODULE_ID) savedFormsTypes!: Record<string, PermanentCropField[]>;

    @Prop({ default: false }) openCloneMode!: boolean;
    @Prop({ default: false }) loadingCompatibleUse!: boolean;

    @Prop({ default: [] }) noClonePlotCodes!: string[];
    @Prop({ default: [] }) targetPlots!: Plot[];

    @Prop() sourcePlot!: Plot;

    private copyMove: CopyOrMove = "COPY";
    private loadingCopyOrMove = false;
    private showDeclAlreadyExistModal = false;
    private existingDeclarations: Declaration[] = [];

    private getDeclDescription(declaration: Declaration) {
        const vineyardForm = declaration.permanentCropForms.find(
            (form: PermanentCropForm) => form.formType === VINEYARD_FORM
        );

        return vineyardForm && vineyardForm.permanentCropFormData?.externalDescription
            ? vineyardForm.permanentCropFormData.externalDescription
            : "";
    }

    private replacePlotAfterUpdate(newPlot: Plot) {
        const tempPlots = [...this.plots];
        const tempPlotIndex = tempPlots.findIndex((p) => p.plotCode === newPlot.plotCode);
        tempPlots[tempPlotIndex] = newPlot;
        this.plots = tempPlots;
    }

    private async copyOrMoveDeclarations() {
        if (
            !this.curPointInTime ||
            !this.curPlot ||
            !this.curTimelineSection ||
            !this.curCropPlan ||
            !this.curCouncil
        ) {
            console.error("DEV - error: missing data");
            return;
        }
        try {
            this.loadingCopyOrMove = true;
            const sections = [this.curTimelineSection, ...this.curTimelineSections];
            const sourceDeclCodes = sections.map((s) => s.declCode.toString());
            const paylaod: CopyOrMoveDeclarationsPayload = {
                pointInTime: formatDate(this.curPointInTime),
                sourcePlotCode: this.sourcePlot.plotCode,
                sourceDeclCodes: sourceDeclCodes,
                destPlotCode: this.curPlot.plotCode,
                removeSourceDecls: this.copyMove === "MOVE" ? true : false,
            };
            const copyOrMoveResponse: CopyOrMoveDeclarationsResponse =
                await this.singleCropPlanModule.declarationApi.copyOrMoveDeclarations(
                    this.business.businessId,
                    this.curCropPlan.cropPlanId,
                    this.curCouncil.domainZoneId,
                    paylaod,
                    true
                );
            if (copyOrMoveResponse.sourceUpdatedPlot != null) {
                this.replacePlotAfterUpdate(copyOrMoveResponse.sourceUpdatedPlot);
            }
            if (copyOrMoveResponse.destUpdatedPlot != null) {
                this.replacePlotAfterUpdate(copyOrMoveResponse.destUpdatedPlot);
            }

            if (copyOrMoveResponse.sourceDeclarationsAlreadyExisting.length > 0) {
                this.showDeclAlreadyExistModal = true;
                this.existingDeclarations = copyOrMoveResponse.sourceDeclarationsAlreadyExisting;
            }

            this.flCurCorpPlanChangesPending = true;
            this.curTimelineSection = null;
            this.curTimelineSections = [];
            this.$emit("openCloneModeUpdate", false);
            if (copyOrMoveResponse.destUpdatedPlot != null)
                this.toast(this.i18n("operation-success").toString(), {
                    type: "success",
                    duration: 4000,
                });
        } catch (error) {
            const errorCode = (error as any).response?.data?.errorCode;
            let errorMessage = this.i18n("generic-error").toString();
            switch (errorCode) {
                case "DUPLICATED_DECL_EXTERNAL_CODE_EXCEPTION":
                    errorMessage = this.i18n("duplicated_decl_external_code_exception").toString();
                    break;
                case "MAX_ALLOWED_DECLARABLE_AREA_EXCEPTION":
                    errorMessage = this.i18n("max_allowed_declarable_area_exception").toString();
                    break;
            }
            this.toast(errorMessage, { type: "error", duration: 5000 });
        } finally {
            this.loadingCopyOrMove = false;
        }
    }
}
</script>
