<template>
    <!-- Dates Controller -->
    <div v-if="!isLoading" class="flex flex-col">
        <!-- PLANTING DATE -->
        <div class="flex w-full mb-4">
            <abc-date-input
                v-if="isPlantingDateVisible && !hasPermanentCropData"
                class="w-4/12 px-2"
                :label="hasPermanentCropData ? i18n('pcf-label-planting-date') : i18n('planting-date-base')"
                :value="declarationDetail.fromDate"
                :rules="[mandatoryRuleAtomic, plantingDateGreaterThanPlotDateRule]"
                :range-min="dateRange.plantingMin"
                :range-max="dateRange.plantingMax"
                :hide-delete="!isPlantingDeleteVisible"
                @input="$emit('input-planting-date', $event)"
                :info="plantingInfo"
            />

            <!-- SCOPED PLANTING DATE -->
            <div v-if="isPlantingDateVisible && hasPermanentCropData" class="flex w-full">
                <abc-input
                    v-model="plantingDetailDate.day"
                    ref="date-day-input"
                    class="flex flex-col pl-2"
                    :label="i18n('vineyard-day')"
                    @input="updateDay"
                    is-numeric
                    mask="##"
                    :rules="[dayRule]"
                />
                <abc-input
                    v-model="plantingDetailDate.month"
                    ref="date-month-input"
                    class="flex flex-col px-2"
                    :label="i18n('vineyard-month')"
                    @input="updateMonth"
                    is-numeric
                    mask="##"
                    :rules="[monthRule]"
                />
                <abc-input
                    v-model="plantingDetailDate.year"
                    ref="date-year-input"
                    class="flex flex-col"
                    :label="i18n('vineyard-year')"
                    @input="updateYear"
                    is-numeric
                    mask="####"
                    :rules="[yearRule]"
                />
            </div>
        </div>

        <!-- HARVEST DATE -->
        <div v-if="curConfiguration.DISABLE_PERMANENT_CROP_EXTIRPATION !== 'TRUE'" class="flex w-full mb-4">
            <abc-date-input
                v-if="isHarvestDateVisible"
                class="w-4/12 px-2"
                :label="hasPermanentCropData ? i18n('pcf-label-uprooting-date') : i18n('harvest-date-base')"
                v-model="declarationDetail.toDate"
                :rules="[mandatoryRuleAtomic, harvestingDateLesserThanPlotDateRule]"
                :range-min="dateRange.harvestMin"
                :range-max="dateRange.harvestMax"
                :hide-delete="!isHarvestinDeleteVisible"
                :initial-date-ref="declarationDetail.fromDate"
                :info="harvestingInfo"
            />
            <div v-if="hasPermanentCropData" class="w-4/12 px-2">
                <div v-if="hasUprootingDate">
                    <div class="mb-1"><label>&nbsp;</label></div>
                    <abc-button @click="declarationDetail.toDate = new Date(9999, 11, 31)" is-outlined>{{
                        i18n("pcf-button-cancel-uprooting-date")
                    }}</abc-button>
                </div>
                <div v-else>
                    <div class="mb-1"><label>&nbsp;</label></div>
                    <abc-button @click="showModalUprootingDate = true">{{
                        i18n("pcf-button-set-uprooting-date")
                    }}</abc-button>
                    <abc-modal
                        v-if="showModalUprootingDate"
                        :isMessage="true"
                        :forceModal="true"
                        @close="showModalUprootingDate = false"
                    >
                        <template #body>
                            <abc-date-input
                                :label="i18n('pcf-label-uprooting-date')"
                                v-model="tempUprootingDate"
                                :rangeMin="declarationDetail.fromDate"
                                :rangeMax="new Date(9999, 11, 31)"
                            />
                        </template>
                        <template #footer>
                            <abc-button
                                isSecondary
                                isOutlined
                                class="mx-2"
                                @click="
                                    showModalUprootingDate = false;
                                    tempUprootingDate = null;
                                "
                                >{{ i18n("cancel") }}</abc-button
                            >
                            <abc-button
                                class="mx-2"
                                @click="
                                    declarationDetail.toDate = tempUprootingDate;
                                    showModalUprootingDate = false;
                                    tempUprootingDate = null;
                                "
                                :isDisabled="tempUprootingDate === null"
                                >{{ i18n("save") }}</abc-button
                            >
                        </template>
                    </abc-modal>
                </div>
            </div>
        </div>
    </div>

    <!-- Loader -->
    <div v-else class="flex justify-center items-center h-12">
        <abc-loader :size="32" />
    </div>
</template>

<script lang="ts">
import { Component, Vue, Prop, Inject, Ref, Watch } from "vue-property-decorator";
import { TranslateResult } from "vue-i18n";
import { Declaration, DeclarationOut, DeclarationSingleScopeDate } from "../../models/Declaration";
import { FromStore } from "@abaco/web-common/src/app";
import SingleCropPlan, { MODULE_ID } from "../..";
import { Configuration } from "../../models/CropPlan";
import { AbcInputExtended } from "../../models/AbcInputExtended";
import { Plot } from "../../models/Plot";

@Component
export default class DeclDatesController extends Vue {
    @Inject() i18n!: (key: string, values?: unknown) => TranslateResult;

    // ---------- State
    @FromStore(MODULE_ID) curConfiguration!: Configuration | null;
    @FromStore(MODULE_ID) curDeclaration!: Declaration | null;
    @FromStore(SingleCropPlan.MODULE_ID) curPlot!: Plot | null;

    // ---------- Props
    @Prop() declarationDetail!: DeclarationOut;
    @Prop() plantingInfo?: string | null;
    @Prop() harvestingInfo?: string | null;
    @Prop() dateRange!: Record<string, unknown>;
    @Prop() minInsertableDate!: Date | null;
    @Prop() maxInsertableDate!: Date | null;
    @Prop({ type: Boolean, default: false }) isPlantingDateVisible!: boolean;
    @Prop({ type: Boolean, default: false }) isHarvestDateVisible!: boolean;
    @Prop({ type: Boolean, default: false }) isHarvestBtnVisible!: boolean;
    @Prop({ type: Boolean, default: false }) isPlantingDeleteVisible!: boolean;
    @Prop({ type: Boolean, default: false }) isHarvestinDeleteVisible!: boolean;
    @Prop({ type: Boolean, default: false }) hasPermanentCropData!: boolean;
    @Prop({ type: Boolean, default: false }) isDetailDateMountOnStart!: boolean;
    @Prop({ type: Boolean, default: false }) isLoading!: boolean;
    // Only for force update plantingDetailDate purpose
    @Prop() forcePlantingDetailDate!: DeclarationSingleScopeDate;

    // ---------- Planting inputs ref
    @Ref("date-day-input") dateDayInput!: AbcInputExtended;
    @Ref("date-month-input") dateMonthInput!: AbcInputExtended;
    @Ref("date-year-input") dateYearInput!: AbcInputExtended;

    // ---------- Local
    private tempUprootingDate: Date | null = null;
    private showModalUprootingDate = false;

    private plantingDetailDate: DeclarationSingleScopeDate = {
        day: undefined,
        month: undefined,
        year: undefined,
    };

    mounted() {
        if (!this.isDetailDateMountOnStart) return;

        if (this.curDeclaration && this.curPlot) {
            this.plantingDetailDate.year = this.curPlot.fullRangeFromDate.getFullYear();
            this.plantingDetailDate.month = this.curPlot.fullRangeFromDate.getMonth() + 1;
            this.plantingDetailDate.day = this.curPlot.fullRangeFromDate.getDate();
        }
        if (this.curDeclaration?.fromDatePrecision?.includes("Y") && this.declarationDetail.fromDate) {
            this.plantingDetailDate.year = this.declarationDetail.fromDate.getFullYear();
        }
        if (this.curDeclaration?.fromDatePrecision?.includes("M") && this.declarationDetail.fromDate) {
            this.plantingDetailDate.month = this.declarationDetail.fromDate.getMonth() + 1;
        }
        if (this.curDeclaration?.fromDatePrecision?.includes("D") && this.declarationDetail.fromDate) {
            this.plantingDetailDate.day = this.declarationDetail.fromDate.getDate();
        }
    }

    // ---------- Rules
    private mandatoryRuleAtomic = (v: unknown) => !!v || this.i18n("valid.mandatory-field");

    private plantingDateGreaterThanPlotDateRule(e: any | null): string | null {
        let curDate = e;
        if (e && typeof e.getMonth !== "function") {
            curDate = new Date(e.substring(6), e.substring(3, 5) - 1, e.substring(0, 2));
        }
        let res = null;
        if (curDate && this.minInsertableDate && curDate.getTime() < this.minInsertableDate.getTime()) {
            res = this.i18n("planting-date-greater-than-plot-date").toString();
        }
        return res;
    }

    private harvestingDateLesserThanPlotDateRule(e: any | null): string | null {
        let curDate = e;
        if (e && typeof e.getMonth !== "function") {
            curDate = new Date(e.substring(6), e.substring(3, 5) - 1, e.substring(0, 2));
        }
        let res = null;
        if (curDate && this.maxInsertableDate && curDate.getTime() > this.maxInsertableDate.getTime()) {
            res = this.i18n("harvesting-date-lesser-than-plot-date").toString();
        }
        return res;
    }

    private dayRule(e: number | null): string | null {
        let res = null;
        const daysInMonth = this.plantingDetailDate.month
            ? new Date(
                  this.plantingDetailDate.year ? this.plantingDetailDate.year : new Date().getFullYear(),
                  this.plantingDetailDate.month,
                  0
              ).getDate()
            : undefined;

        if (
            e &&
            daysInMonth &&
            this.plantingDetailDate.month &&
            this.plantingDetailDate.month <= 12 &&
            e > daysInMonth
        ) {
            res = this.i18n("invalid-day-month").toString();
        }

        if (e && e > 31) {
            res = this.i18n("invalid-day-number").toString();
        }

        if (
            e &&
            this.plantingDetailDate.month &&
            this.plantingDetailDate.year &&
            this.curPlot &&
            (!this.curConfiguration?.CONSTRAINTS_DECLS_TO_PLOTS ||
                this.curConfiguration?.CONSTRAINTS_DECLS_TO_PLOTS === "TRUE") &&
            this.calculateDate(this.plantingDetailDate.year, this.plantingDetailDate.month, e) < this.curPlot.fullRangeFromDate
        ) {
            res = this.i18n("invalid-year-number").toString();
        }

        return res;
    }

    private monthRule(e: number | null): string | null {
        let res = null;

        if (!e && this.plantingDetailDate.day) {
            res = this.i18n("invalid_day_no_month").toString();
        }

        if (e && e > 12) {
            res = this.i18n("invalid_month_number").toString();
        }

        if (
            e &&
            this.plantingDetailDate.day &&
            this.plantingDetailDate.year &&
            this.curPlot &&
            (!this.curConfiguration?.CONSTRAINTS_DECLS_TO_PLOTS ||
                this.curConfiguration?.CONSTRAINTS_DECLS_TO_PLOTS === "TRUE") &&
            this.calculateDate(this.plantingDetailDate.year, e, this.plantingDetailDate.day) < this.curPlot.fullRangeFromDate
        ) {
            res = this.i18n("invalid-year-number").toString();
        }

        return res;
    }

    private yearRule(e: number | null): string | null {
        let res = null;
        if (
            e &&
            this.plantingDetailDate.day &&
            this.plantingDetailDate.month &&
            this.curPlot &&
            (!this.curConfiguration?.CONSTRAINTS_DECLS_TO_PLOTS ||
                this.curConfiguration?.CONSTRAINTS_DECLS_TO_PLOTS === "TRUE") &&
            this.calculateDate(e, this.plantingDetailDate.month, this.plantingDetailDate.day) < this.curPlot.fullRangeFromDate
        ) {
            res = this.i18n("invalid-year-number").toString();
        }

        if (e && e.toString().length < 4) {
            res = this.i18n("invalid-year-length").toString();
        }

        if (e && this.hasPermanentCropData && e > new Date().getFullYear()) {
            res = this.i18n("invalid-year-permanent-crop").toString();
        }

        if (
            e &&
            this.minInsertableDate &&
            this.curConfiguration &&
            this.curConfiguration.CONSTRAINTS_DECLS_TO_PLOTS &&
            this.curConfiguration?.CONSTRAINTS_DECLS_TO_PLOTS === "TRUE" &&
            this.calculateDate(
                e,
                this.plantingDetailDate.month ? this.plantingDetailDate.month : 1,
                this.plantingDetailDate.day ? this.plantingDetailDate.day : 1
            ).getTime() < this.minInsertableDate.getTime()
        ) {
            res = this.i18n("planting-date-greater-than-plot-date").toString();
        }

        return res;
    }

    // ---------- Computeds
    private get hasUprootingDate() {
        return (
            this.hasPermanentCropData &&
            this.declarationDetail.toDate &&
            this.declarationDetail.toDate < new Date(9999, 11, 31)
        );
    }

    // ---------- Methods
    private updateDay(e: number | null) {
        const daysInMonth = this.plantingDetailDate.month
            ? new Date(
                  this.plantingDetailDate.year ? this.plantingDetailDate.year : new Date().getFullYear(),
                  this.plantingDetailDate.month,
                  0
              ).getDate()
            : undefined;

        // Force run rules
        if (
            e &&
            this.plantingDetailDate.month &&
            this.plantingDetailDate.year &&
            this.curPlot &&
            (!this.curConfiguration?.CONSTRAINTS_DECLS_TO_PLOTS ||
                this.curConfiguration?.CONSTRAINTS_DECLS_TO_PLOTS === "TRUE") &&
            this.calculateDate(this.plantingDetailDate.year, this.plantingDetailDate.month, e) < this.curPlot.fullRangeFromDate
        ) {
            this.dateMonthInput.runRules(this.plantingDetailDate.month);
            this.dateYearInput.runRules(this.plantingDetailDate.year);
        }

        // Emit Update DatePicker
        if (e && daysInMonth && e <= daysInMonth && this.declarationDetail.fromDate) {
            this.$emit(
                "on-update-from-date",
                this.calculateDate(
                    this.plantingDetailDate.year
                        ? this.plantingDetailDate.year
                        : this.declarationDetail.fromDate.getFullYear(),
                    this.plantingDetailDate.month
                        ? this.plantingDetailDate.month
                        : this.declarationDetail.fromDate.getMonth() + 1,
                    e
                )
            );
        }

        if (!this.plantingDetailDate.month) {
            this.dateMonthInput.runRules(this.plantingDetailDate.month);
        }
    }

    private updateMonth(e: number | null) {
        if (e && e === 0) {
            this.plantingDetailDate.month = undefined;
        }

        // Force reset data and emit update DatePicker
        if (this.plantingDetailDate.day && this.declarationDetail.fromDate && !e) {
            this.plantingDetailDate.day = undefined;
            this.plantingDetailDate.month = undefined;
            this.$emit(
                "on-update-from-date",
                this.calculateDate(
                    this.plantingDetailDate.year
                        ? this.plantingDetailDate.year
                        : this.declarationDetail.fromDate.getFullYear(),
                    1,
                    this.plantingDetailDate.day ? this.plantingDetailDate.day : 1
                )
            );
        }

        // Force assign year (if it not exists) when month is entered
        if (e && e <= 12 && this.curDeclaration && !this.plantingDetailDate.year) {
            this.plantingDetailDate.year = this.curDeclaration.fromDate.getFullYear();
        }

        // Force run yuar rule
        if (
            e &&
            this.plantingDetailDate.day &&
            this.plantingDetailDate.year &&
            this.curPlot &&
            (!this.curConfiguration?.CONSTRAINTS_DECLS_TO_PLOTS ||
                this.curConfiguration?.CONSTRAINTS_DECLS_TO_PLOTS === "TRUE") &&
            this.calculateDate(this.plantingDetailDate.year, e, this.plantingDetailDate.day) < this.curPlot.fullRangeFromDate
        ) {
            // Only year's rules is called because on the bottom of this method the day ones is always called
            this.dateYearInput.runRules(this.plantingDetailDate.year);
        }

        // Emit Update DatePicker
        if (e && this.declarationDetail.fromDate) {
            this.$emit(
                "on-update-from-date",
                this.calculateDate(
                    this.plantingDetailDate.year
                        ? this.plantingDetailDate.year
                        : this.declarationDetail.fromDate.getFullYear(),
                    e,
                    this.plantingDetailDate.day ? this.plantingDetailDate.day : 1
                )
            );
        }

        this.dateDayInput.runRules(this.plantingDetailDate.day);
    }

    private updateYear(e: number | null) {
        if (e && e === 0) {
            this.plantingDetailDate.year = undefined;
        }

        // Force reset data
        if (!e) {
            this.plantingDetailDate.day = undefined;
            this.plantingDetailDate.month = undefined;
            this.plantingDetailDate.year = undefined;
        }

        // Emit Update DatePicker
        if (e && this.declarationDetail.fromDate) {
            this.$emit(
                "on-update-from-date",
                this.calculateDate(
                    e,
                    this.plantingDetailDate.month ? this.plantingDetailDate.month : 1,
                    this.plantingDetailDate.day ? this.plantingDetailDate.day : 1
                )
            );
        }

        this.dateDayInput.runRules(this.plantingDetailDate.day);
        this.dateMonthInput.runRules(this.plantingDetailDate.month);
    }

    /**
     * This approach prevent mutate month since by passing number instead of string
     * the Date would start from index 0 (ie Jenuary is 0)
     */
    private calculateDate(year: number, month: number, day: number): Date {
        return new Date(`${year}-${month}-${day}`);
    }

    // ---------- Watches
    /**
     * Everytime plantingDetailDate change this component emit to his parent the current fromDatePrecision status (ie: YMD, YM, Y, -).
     */
    @Watch("plantingDetailDate", { deep: true })
    private generateFromDatePrecision() {
        let fromDatePrecision = "-";
        if (this.plantingDetailDate.day && this.plantingDetailDate.month && this.plantingDetailDate.year) {
            fromDatePrecision = "YMD";
        } else if (!this.plantingDetailDate.day && this.plantingDetailDate.month && this.plantingDetailDate.year) {
            fromDatePrecision = "YM";
        } else if (!this.plantingDetailDate.day && !this.plantingDetailDate.month && this.plantingDetailDate.year) {
            fromDatePrecision = "Y";
        }

        this.$emit("on-update-from-date-precision", fromDatePrecision);
    }

    /**
     * Force update forcePlantingDetailDate only if parent have this necessity.
     * Otherwise all the forcePlantingDetailDate logic are delegated to this component.
     */
    @Watch("forcePlantingDetailDate")
    private forceUpdatePlantingDetailDate() {
        if (this.forcePlantingDetailDate && this.plantingDetailDate !== this.forcePlantingDetailDate) {
            this.plantingDetailDate = this.forcePlantingDetailDate;
        }
    }
}
</script>

<style lang="scss" scoped></style>
