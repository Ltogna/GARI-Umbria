<template>
    <div class="absolute top-0 right-0 z-20">
        <div class="map-operation-result flex flex-col px-4 pb-2 text-sm rounded relative">
            <div class="flex flex-col">
                <div class="flex flex-col mt-2">
                    <div
                        class="w-full font-semibold border-b py-1"
                        style="
                            padding-bottom: 2px;
                            color: rgba(255, 255, 255, 0.5);
                            border-color: rgba(255, 255, 255, 0.2);
                        "
                    >
                        <em class="fal fa-layer-group pr-1 text-secondary-500"></em>
                        {{ `${i18n("results")} ${i18n("operation").toLocaleLowerCase()}` }}
                    </div>
                    <div
                        v-for="(plot, index) in plotsArea()"
                        :key="index"
                        class="map-operation-result-item font-semibold border-b py-1 px-2"
                        @mouseover="showPlotOnHover(plot)"
                        @mouseout="hidePlotOnMouseOut()"
                    >
                        {{
                            `${plot.areaSqm.toLocaleString(getLocale(), {
                                minimumFractionDigits: 4,
                                maximumFractionDigits: 4,
                            })} ha`
                        }}
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script lang="ts">
import { Component, Inject, Mixins, Prop, Watch } from "vue-property-decorator";
import { TranslateResult } from "vue-i18n";
import { MODULE_ID } from "../..";
import { Plot, PlotPreviewDiff } from "../../models/Plot";
import { FromStore } from "@abaco/web-common/src/app";
import WKTReader from "jsts/org/locationtech/jts/io/WKTReader";
import { MapFunctions } from "@abaco/iacs-map-module/src/modules/map-module/models/AbcMap";
import GenericLayer from "@abaco/iacs-map-module/src/modules/map-module/Layer/GenericLayer";
import { VectorLayerDef } from "@abaco/iacs-map-module/src/modules/map-module/Layer/AbcVectorLayer";
import AreaUtils from "../../mixins/AreaUtils";

@Component
export default class OperationResult extends Mixins(AreaUtils) {
    @Inject() i18n!: (key: string, values?: unknown) => TranslateResult;

    @FromStore(MODULE_ID) plots!: Plot[];

    @Prop() map!: MapFunctions | null;
    @Prop() previewLayerDiff!: PlotPreviewDiff;
    @Prop() multiselectionIntersectedPlots!: Plot [];


    private JSTSWktParser = new WKTReader();
    private layer: GenericLayer | null = null;

    @Watch("previewLayerDiff")
    private plotsArea() {
        
        const tempPlots: Plot[] = [];

        if (this.previewLayerDiff) {
            this.previewLayerDiff.updated.map((p) => {
                const targetPlot = this.plots.find((it) => it.plotCode === p.plotCode);
                if (targetPlot) {
                    tempPlots.push({
                        ...targetPlot,
                        areaSqm: this.calculateAreaFromWkt(p.geom),
                        geom: p.geom,
                    });
                }
            });

            this.previewLayerDiff.added.map((p) => {
                const newPlot: Plot = { ...this.plots[0] };
                newPlot.areaSqm = this.calculateAreaFromWkt(p.geom);
                newPlot.geom = p.geom;
                tempPlots.push(newPlot);
            });
        } else if (this.multiselectionIntersectedPlots) {
            this.multiselectionIntersectedPlots.map((it) => {
                const targetPlot = this.plots.find((p) => p.plotCode === it.plotCode);
                if (targetPlot) {
                    tempPlots.push({
                        ...targetPlot,
                        areaSqm: this.calculateAreaFromWkt(it.geom),
                        geom: it.geom,
                    });
                }
            })
        }

        return tempPlots;
    }

    private calculateAreaFromWkt(wkt: string): number {
        const geometry = this.JSTSWktParser.read(wkt);
        if (geometry) {
            return parseFloat((geometry.getArea() / 10000).toFixed(4));
        }
        return 0;
    }

    private async showPlotOnHover(plot: Plot) {
        if (!this.map) {
            return;
        }
        const plotOnHover: VectorLayerDef = {
            layerType: "VECTOR",
            layerId: "PLOT_CUT_HOVER",
            features: [
                {
                    wkt: plot.geom,
                    id: plot.plotCode,
                    style: {
                        borderColor: "red",
                        fillColor: "rgb(255, 0, 0, 0.2)",
                        width: 4,
                    },
                },
            ],
            isOverlay: true,
            description: "plot cut on hover",
            on: true,
            zIndex: 1000,
        };

        this.layer = await this.map.addMapLayer(plotOnHover);
    }

    private hidePlotOnMouseOut() {
        if (this.layer?.layerId) {
            this.map?.removeMapLayer(this.layer.layerId);
            this.layer = null;
        }
    }
}
</script>

<style lang="scss" scoped>
.map-operation-result {
    margin-top: 6px;
    margin-right: 6px;
    background: rgba(10, 10, 10, 0.45);
    backdrop-filter: blur(10px);
    color: rgba(255, 255, 255, 0.7);
    max-height: 300px;
    overflow: auto;
}

.map-operation-result-item {
    border-color: rgba(255, 255, 255, 0.2);
    cursor: pointer;
}

.map-operation-result-item:hover {
    backdrop-filter: brightness(50%);
}
</style>
