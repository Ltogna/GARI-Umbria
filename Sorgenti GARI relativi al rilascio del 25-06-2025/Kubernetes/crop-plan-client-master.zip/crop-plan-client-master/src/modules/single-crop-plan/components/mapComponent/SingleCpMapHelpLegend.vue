<template>
    <div v-if="showMapHelpLegend">
        <transition
            name="custom-classes-transition"
            enter-active-class="appear animate__animated animate__fadeIn animate__fast"
            mode="out-in"
        >
            <div v-if="!isCollapsed" class="map-help-legend flex flex-col px-4 pb-2 text-sm rounded relative">
                <button class="scp-map-menu-close" @click="isCollapsed = true" type="button">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" class="svg-image stroked">
                        <line x1="18" y1="6" x2="6" y2="18"></line>
                        <line x1="6" y1="6" x2="18" y2="18"></line>
                    </svg>
                </button>

                <div class="flex flex-col">
                    <div class="flex flex-col mt-2">
                        <div
                            class="w-full font-semibold border-b py-1"
                            style="
                                padding-bottom: 2px;
                                color: rgba(255, 255, 255, 0.5);
                                border-color: rgba(255, 255, 255, 0.2);
                            "
                        >
                            <em class="fal fa-clone pr-1 text-secondary-500"></em> {{ i18n("commands") }}
                        </div>
                        <transition-group
                            name="custom-classes-transition"
                            enter-active-class="animate__animated animate__fadeInDown10 animate__faster"
                            mode="out-in"
                            tag="div"
                            class="flex flex-col"
                        >
                            <div v-if="showDoubleClick" class="flex mt-1" key="0">
                                <div class="flex" style="width: 56px">
                                    <right-click-svg />
                                    <p class="">&nbsp;x2</p>
                                </div>
                                <p class="ml-3">{{ i18n("close-geometry") }}</p>
                            </div>
                            <div v-if="showSelection" class="flex flex-col" key="1">
                                <div class="flex mt-1">
                                    <div class="flex" style="width: 56px">
                                        <em class="fa-thin fa-computer-mouse-scrollwheel" style="font-size: 16px"></em>
                                    </div>
                                    <p class="ml-3">{{ i18n("change-zoom-level") }}</p>
                                </div>
                                <div class="flex mt-1" style="margin-left: -2px">
                                    <div class="flex" style="width: 56px">
                                        <right-click-svg />
                                    </div>
                                    <p class="ml-3">{{ i18n("select-main-plot") }}</p>
                                </div>
                                <div class="flex mt-1">
                                    <div class="flex" style="width: 56px">
                                        <span
                                            class="rounded-md border flex items-center justify-center text-xs"
                                            style="
                                                height: 18px;
                                                width: 26px;
                                                margin-top: -1px;
                                                border-color: rgba(255, 255, 255, 0.5);
                                            "
                                        >
                                            {{ keyToPress }}
                                        </span>
                                        <p>&nbsp;+&nbsp;</p>
                                        <right-click-svg />
                                    </div>
                                    <p class="ml-3">{{ i18n("select-secondary-plot") }}</p>
                                </div>
                                <div class="flex mt-1">
                                    <div class="flex" style="width: 56px">
                                        <span
                                            class="rounded-md border flex items-center justify-center text-xs"
                                            style="
                                                height: 18px;
                                                width: 26px;
                                                margin-top: -1px;
                                                border-color: rgba(255, 255, 255, 0.5);
                                            "
                                        >
                                            {{ keyToPress }}
                                        </span>
                                        <p>&nbsp;+&nbsp;</p>
                                        <right-click-svg />
                                    </div>
                                    <p class="ml-3">{{ i18n("select-secondary-declaration") }}</p>
                                </div>
                            </div>

                            <div v-if="showDisableSnap" class="flex flex-col" key="2">
                                <div class="flex mt-1">
                                    <div class="flex" style="width: 56px">
                                        <span
                                            class="rounded-md border flex items-center justify-center text-xs"
                                            style="height: 18px; width: 18px; border-color: rgba(255, 255, 255, 0.5)"
                                        >
                                            {{ keyToPressDisableSnap }}
                                        </span>
                                    </div>
                                    <p class="ml-3">{{ i18n("disable-snap") }}</p>
                                </div>
                            </div>
                        </transition-group>
                    </div>
                    <transition
                        name="custom-classes-transition"
                        enter-active-class="appear animate__animated animate__fadeInDown10 animate__fast"
                        mode="out-in"
                    >
                        <div v-if="editPlotMode !== getEditPlotMode.NOT_SELECTED" class="flex flex-col mt-2">
                            <div
                                class="w-full font-semibold border-b border-secondary-600 text-secondary-400 py-1"
                                style="
                                    padding-bottom: 2px;
                                    color: rgba(255, 255, 255, 0.5);
                                    border-color: rgba(255, 255, 255, 0.2);
                                "
                            >
                                <em class="fal fa-layer-group pr-1 text-secondary-500"></em> {{ i18n("fields") }}
                            </div>
                            <div class="flex mt-1 items-center">
                                <div class="scp-map-menu-row-indicator mr-1">
                                    <div class="scp-map-menu-row-indicator-dot bg-info-500" />
                                </div>
                                <div>{{ i18n("plot-to-be-added") }}</div>
                            </div>
                            <div class="flex mt-1 items-center">
                                <div class="scp-map-menu-row-indicator mr-1">
                                    <div class="scp-map-menu-row-indicator-dot background-yellow" />
                                </div>
                                <div>{{ i18n("plot-to-be-updated") }}</div>
                            </div>
                        </div>
                    </transition>
                </div>

                <!-- <div
                    class="cursor-pointer flex items-center justify-center hover:text-secondary-500"
                    :class="isCollapsed ? '' : 'border-t pt-2'"
                    @click="isCollapsed = !isCollapsed"
                >
                    <p v-if="isCollapsed" class="pr-2">{{ i18n("show-help-legend") }}</p>
                    <em class="abc-icon abc-icon-arrow-down-2 transform" :class="{ 'rotate-180': !isCollapsed }" />
                </div> -->
            </div>

            <button v-else class="scp-map-menu-open" @click="isCollapsed = false" type="button">
                <em class="fas fa-info-circle"></em>
            </button>
        </transition>
    </div>
</template>

<script lang="ts">
import { Component, Vue, Inject } from "vue-property-decorator";
import { TranslateResult } from "vue-i18n";
import { FromStore } from "@abaco/web-common/src/app";
import SingleCropPlan from "../..";
import { EditPlotMode } from "../../models/Plot";
import RightClickSvg from "./RightClickSvg.vue";
import { isMacOs } from "../../api/Utils";

@Component({
    components: {
        RightClickSvg,
    },
})
export default class SingleCpMapHelpLegend extends Vue {
    @Inject() i18n!: (key: string, values?: unknown) => TranslateResult;

    @FromStore(SingleCropPlan.MODULE_ID) editPlotMode!: EditPlotMode;

    private showMapHelpLegend = true;
    private isCollapsed = false;

    private get getEditPlotMode() {
        return EditPlotMode;
    }

    private get showDoubleClick() {
        return this.editPlotMode === EditPlotMode.ADDING || this.editPlotMode === EditPlotMode.EDITING;
    }

    private get showSelection() {
        return this.editPlotMode === EditPlotMode.NOT_SELECTED || this.editPlotMode === EditPlotMode.MERGING;
    }

    private get showDisableSnap() {
        return (
            this.editPlotMode === EditPlotMode.EDITING ||
            this.editPlotMode === EditPlotMode.CUTTING ||
            this.editPlotMode === EditPlotMode.ADDING
        );
    }

    private get keyToPress() {
        return isMacOs() ? "cmd" : "ctrl";
    }

    private get keyToPressDisableSnap() {
        return "S";
    }
}
</script>

<style lang="scss" scoped>
.map-help-legend,
.scp-map-menu-close,
.scp-map-menu-open {
    @apply transition-all duration-150 ease-in-out;
}

.map-help-legend {
    margin-top: 6px;
    margin-left: 6px;
    background: rgba(10, 10, 10, 0.45);
    backdrop-filter: blur(10px);
    color: rgba(255, 255, 255, 0.7);
}

.scp-map-menu-row-indicator {
    @apply flex items-center justify-center rounded-full;
    width: 14px;
    height: 14px;
    background: rgba(250, 250, 250, 0.4);
}
.scp-map-menu-row-indicator-dot {
    @apply rounded-full flex;
    width: 8px;
    height: 8px;
}

.scp-map-menu-close {
    @apply absolute rounded-lg;
    outline: none !important;
    padding: 3px;
    top: 4px;
    right: 4px;
}
.scp-map-menu-close svg {
    width: 15px;
    height: 15px;
    color: rgba(255, 255, 255, 0.6);
}

.scp-map-menu-close:hover {
    background: rgba(250, 250, 250, 0.2);
}

.scp-map-menu-close:hover svg {
    // @apply text-danger-200;
}

.scp-map-menu-open {
    @apply rounded flex flex-shrink-0 items-center justify-center;
    outline: none !important;
    font-size: 18px;
    height: 40px;
    width: 40px;
    margin-top: 6px;
    margin-left: 6px;
    background: rgba(10, 10, 10, 0.45);
    backdrop-filter: blur(10px);
    color: rgba(255, 255, 255, 0.8);
}
.scp-map-menu-open:hover {
    background: rgba(10, 10, 10, 0.65);
}

.background-yellow {
    background-color: #fdd24d;
}
</style>
