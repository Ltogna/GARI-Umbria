<template>
    <abc-modal
        :title="i18n('search-cadastral-parcel')"
        :top-pinned="true"
        @close="popClose"
        class="abc-modal-cadastral-parcel-search"
        :additionalStyle="{ 'z-index': 1001 }"
    >
        <template #body>
            <div style="min-width: 500px; min-height: 300px">
                <div class="flex border-b py-4 sticky bg-bg-100 top-0">
                    <abc-form ref="form" class="flex items-start w-full">
                        <div class="w-full flex justify-between">
                            <abc-input
                                v-model="filter"
                                left-tools
                                :isFocused="true"
                                :placeholder="i18n('search-cadastral-parcel')"
                                class="w-full"
                            >
                                <template #left>
                                    <em class="abc-icon abc-icon-lens" />
                                </template>
                            </abc-input>
                        </div>
                    </abc-form>
                </div>

                <div class="h-full w-full flex flex-col overflow-hidden">
                    <template v-if="!loading">
                        <abc-table
                            v-if="page.records.length > 0"
                            style="margin-top: -1px"
                            :items="page.records"
                            border-less
                            hasFooter
                            @select="onSelect"
                        >
                            <template #items="{ item }">
                                <td class="cursor-pointer">{{ item.description }}</td>
                            </template>
                            <template #footer>
                                <div class="relative mt-4 mb-4">
                                    <abc-refine-filter v-if="page.haveMore" />
                                </div>
                            </template>
                        </abc-table>
                    </template>

                    <abc-loader v-if="loading" class="pt-4" />

                    <div v-if="!loading && ((page && page.records.length === 0) || !page)" class="relative mt-4 mb-4">
                        <p class="flex justify-center items-center text-label-primary h-16 mb-8">
                            <em
                                class="abc-icon abc-icon-exclamation-point-circle text-secondary-100 text-3xl pr-3"
                                style="margin-top: -1px"
                            />
                            {{ i18n("no-cadastral-parcel-found") }}
                        </p>
                    </div>
                </div>
            </div>
        </template>
    </abc-modal>
</template>

<script lang="ts">
import { Vue, Component, Inject, Ref, Watch } from "vue-property-decorator";
import { TranslateResult } from "vue-i18n";
import { FromStore } from "@abaco/web-common/src/app";
import { Validable } from "@abaco/web-components/src/components/form/Validable";
import { MaxPagedResults, EmptyMaxPagedResults } from "@abaco/web-common/src/Paging";
import { Debounce } from "vue-debounce-decorator";
import { Council } from "../../models/Council";
import { Business } from "../../models/Business";
import { CadastralParcel } from "../../models/CadastralParcel";
import SingleCropPlanModule, { MODULE_ID } from "../../index";
import { CropPlan } from "../../models/CropPlan";

@Component
export default class CadastralParcelSearchModal extends Vue {
    @Inject() i18n!: (key: string, values?: unknown) => TranslateResult;
    @Inject(MODULE_ID) singleCropPlanModule!: SingleCropPlanModule;

    @FromStore(MODULE_ID) curCouncil!: Council | null;
    @FromStore(MODULE_ID) curCropPlan!: CropPlan | null;
    @FromStore(MODULE_ID) business!: Business | null;

    @Ref("form") form!: Validable;

    private page: MaxPagedResults<CadastralParcel> = new EmptyMaxPagedResults();
    private loading = true;
    private filter = "";

    mounted() {
        this.resetAndLoad();
    }

    @Watch("filter")
    onFilterChange() {
        if (this.filter) {
            this.loading = true;
            this.waitAndReset();
        }
    }

    @Debounce(400)
    waitAndReset() {
        this.resetAndLoad();
    }

    @Watch("triggerLoad")
    async resetAndLoad() {
        if (!this.business?.businessId || !this.curCropPlan || !this.curCouncil?.domainZoneId) return;
        //
        this.page = await this.singleCropPlanModule.cadastralParcelApi.getCadastralParcels(
            this.business.businessId,
            this.curCropPlan.cropPlanId,
            this.curCouncil.domainZoneId,
            this.filter
        );
        this.loading = false;
    }

    private onSelect(index: number) {
        this.$emit("select", this.page.records[index]);
    }

    private popClose() {
        this.$emit("close");
    }
}
</script>

<style lang="scss">
.abc-modal-cadastral-parcel-search {
    > .abc-modal {
        width: 100%;
        max-width: unset;
        padding-left: 1rem;
        padding-right: 1rem;
        background: transparent;
        @media (min-width: 1024px) {
            // lg\:w-8\/12
            width: 66.666667%;
        }
        @media (min-width: 1537px) {
            // xxl\:w-7\/12
            width: 58.333333%;
        }
        > div {
            background-color: var(--color-bg-100);
            &:last-child {
                border-bottom-left-radius: 6px;
                border-bottom-right-radius: 6px;
            }
        }
        .abc-modal-body {
            padding-top: 0;
        }
        > div:not(.abc-modal-body):not(.abc-modal-footer) {
            padding-top: 0.7rem;
            padding-bottom: 0.7rem;
            border-top-left-radius: 6px;
            border-top-right-radius: 6px;
            color: var(--brand-black-500);
            background-color: var(--brand-yellow-400);
            > .text-xl {
                font-size: 0.875rem;
            }
            .abc-modal-close-button {
                top: 0.7rem;
            }
        }
    }
}
</style>
