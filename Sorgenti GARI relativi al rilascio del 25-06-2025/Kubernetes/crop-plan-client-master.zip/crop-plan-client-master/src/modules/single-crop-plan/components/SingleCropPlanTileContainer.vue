<template>
    <div class="w-full h-full">
        <abc-modal
            v-if="showCropPlanNotAccessibleModal"
            is-message
            modal-class="w-full md:w-8/12 lg:w-6/12 xxl:w-4/12"
            force-modal
        >
            <template #body>
                <div class="pt-2 pb-4 flex flex-col w-full">
                    <div
                        class="mx-auto flex items-center justify-center rounded-full bg-danger-100 text-danger-300"
                        style="width: 80px; height: 80px; font-size: 30px"
                    >
                        <em class="fad fa-user-times" />
                    </div>
                    <div class="mt-4 w-full">
                        <h3 class="text-lg text-center font-bold text-secondary-600">
                            <div class="flex flex-col">
                                <span>{{ i18n(showCropPlanNotAccessibleModalMessage) }}</span>
                            </div>
                        </h3>
                    </div>
                </div>
            </template>
        </abc-modal>
        <abc-modal
            v-else-if="showCropPlanSyncModal"
            is-message
            modal-class="w-full md:w-8/12 lg:w-6/12 xxl:w-4/12"
            :force-modal="!syncError"
            :additionalStyle="{ 'z-index': 1002 }"
        >
            <template #body>
                <div v-if="!syncError" class="pt-2 pb-4 flex flex-col w-full">
                    <div class="w-full flex items-center justify-center">
                        <em class="fal fa-sync-alt animate-spin text-5xl text-label-secondary"></em>
                    </div>
                    <div class="mt-4 w-full">
                        <h3 class="text-lg text-center font-bold text-secondary-600">
                            <div class="flex flex-col">
                                <span v-if="curSyncType == 'COPY_CAMPAIGN'">{{
                                    i18n("crop-plan-copy-campaign-in-progress")
                                }}</span>
                                <span v-else-if="curSyncType == 'MASSIVE_FIELDS_UPDATE'">{{
                                    i18n("crop-plan-massive-fields-update-in-progress")
                                }}</span>
                                <span v-else-if="flRecalcAnomalies">
                                    {{ i18n("crop-plan-recalculating-anomalies-info") }}
                                </span>
                                <span v-else>{{ i18n("crop-plan-syncing") }}</span>
                                <span class="text-base font-normal pt-1">
                                    {{ i18n("crop-plan-syncing-info") }}
                                </span>
                            </div>
                        </h3>
                    </div>
                </div>
                <div v-else class="pt-2 pb-4 flex flex-col w-full">
                    <div class="w-full flex items-center justify-center">
                        <em class="fad fa-exclamation-triangle text-danger-500 text-5xl"></em>
                    </div>
                    <div class="mt-4 w-full flex flex-col items-center justify-center">
                        <template v-if="curSyncType == 'COPY_CAMPAIGN'">
                            <h3 class="text-lg text-center font-bold text-secondary-600">
                                <div class="flex flex-col">
                                    <span class="text-danger-500">{{ i18n("something-went-wrong") }}</span>
                                    <span>{{ i18n("crop-plan-copy-campaign-failed") }}</span>
                                </div>
                            </h3>
                              <abc-button class="mt-4" is-outlined @click="onSyncModalClose">
                                <em class="abc-icon abc-icon-arrow-circle pr-2" />
                                <span>{{ i18n("close") }}</span>
                            </abc-button>
                        </template>
                        <template v-else-if="curSyncType == 'MASSIVE_FIELDS_UPDATE'">
                            <h3 class="text-lg text-center font-bold text-secondary-600">
                                <div class="flex flex-col">
                                    <span class="text-danger-500">{{ i18n("something-went-wrong") }}</span>
                                    <span>{{ i18n("crop-plan-massive-update-failed") }}</span>
                                </div>
                            </h3>
                             <abc-button class="mt-4" is-outlined @click="onSyncModalClose">
                                <em class="abc-icon abc-icon-arrow-circle pr-2" />
                                <span>{{ i18n("close") }}</span>
                            </abc-button>
                        </template>
                        <template v-else>
                            <h3 class="text-lg text-center font-bold text-secondary-600">
                                <div class="flex flex-col">
                                    <span class="text-danger-500">{{ i18n("something-went-wrong") }}</span>
                                    <span class="text-base font-normal pt-1">{{ syncError }}</span>
                                </div>
                            </h3>
                            <abc-button class="mt-4" is-outlined @click="retrySync">
                                <em class="abc-icon abc-icon-arrow-circle pr-2" />
                                <span>{{ i18n("retry") }}</span>
                            </abc-button>
                        </template>
                    </div>
                </div>
            </template>
        </abc-modal>
        <div
            v-else-if="
                (!business || !curCropPlan || !curCouncil) &&
                !showNoCropPlanFound &&
                !showCannotUseCropPlan &&
                !showCropPlanNotAccessibleModal
            "
            class="flex justify-center mt-8"
        >
            <abc-alert v-if="!business && !curCropPlan && !curCouncil" i18nKeys :messages="['select-farm']" />
            <abc-modal
                v-else-if="!curCropPlan && !curCouncil && showCannotUseCropPlanForThisBusiness"
                @close="showCannotUseCropPlanForThisBusiness = false"
                is-message
                modal-class="w-full md:w-8/12 lg:w-6/12 xxl:w-4/12 z-100"
                force-modal
            >
                <template #body>
                    <div class="pt-2 pb-4 flex flex-col w-full">
                        <div
                            class="mx-auto flex items-center justify-center rounded-full text-danger-300"
                            style="width: 80px; height: 80px; font-size: 80px"
                        >
                            <em class="fad fa-circle-xmark" />
                        </div>
                        <div class="mt-4 w-full">
                            <h3 class="text-lg text-center font-bold text-secondary-600">
                                <div class="flex flex-col">
                                    <span>{{ i18n("cannot-use-crop-plan-for-this-business") }}</span>
                                </div>
                            </h3>
                        </div>
                    </div>
                </template>
            </abc-modal>
            <abc-alert
                v-else-if="!curCropPlan && !curCouncil"
                i18nKeys
                :messages="['select-crop-plan-and-council-for-plots']"
            />
            <abc-alert v-else-if="!curCouncil" i18nKeys :messages="['select-council-for-plots']" />
        </div>
        <abc-modal
            v-else-if="showCannotUseCropPlan"
            @close="showCannotUseCropPlan = false"
            is-message
            modal-class="w-full md:w-8/12 lg:w-6/12 xxl:w-4/12 z-100"
            force-modal
        >
            <template #body>
                <div class="pt-2 pb-4 flex flex-col w-full">
                    <div
                        class="mx-auto flex items-center justify-center rounded-full text-danger-300"
                        style="width: 80px; height: 80px; font-size: 80px"
                    >
                        <em class="fad fa-circle-xmark" />
                    </div>
                    <div class="mt-4 w-full">
                        <h3 class="text-lg text-center font-bold text-secondary-600">
                            <div class="flex flex-col">
                                <span>{{ i18n("cannot-use-crop-plan") }}</span>
                            </div>
                        </h3>
                    </div>
                </div>
            </template>
        </abc-modal>
        <abc-modal
            v-else-if="showNoCropPlanFound"
            @close="showNoCropPlanFound = false"
            is-message
            modal-class="w-full md:w-8/12 lg:w-6/12 xxl:w-4/12 z-100"
            force-modal
        >
            <template #body>
                <div class="pt-2 pb-4 flex flex-col w-full">
                    <div
                        class="mx-auto flex items-center justify-center rounded-full text-danger-300"
                        style="width: 80px; height: 80px; font-size: 80px"
                    >
                        <em class="fad fa-circle-xmark" />
                    </div>
                    <div class="mt-4 w-full">
                        <h3 class="text-lg text-center font-bold text-secondary-600">
                            <div class="flex flex-col">
                                <span>{{ i18n("no-crop-plan-found") }}</span>
                                <span class="text-base font-normal pt-1">{{ i18n("no-crop-plan-found-info") }}</span>
                            </div>
                        </h3>
                    </div>
                </div>
            </template>
        </abc-modal>
        <abc-loader v-else-if="loadingCropPlan" scope="fixed" />
        <tile-container
            v-else-if="!showLockErrorModal && !showCropPlanSyncModal && !showCropPlanNotAccessibleModal"
            :value="content"
        />
        <abc-modal
            v-else-if="showLockErrorModal"
            @close="showLockErrorModal = false"
            is-message
            modal-class="w-full md:w-8/12 lg:w-6/12 xxl:w-4/12"
            force-modal
        >
            <template #body>
                <div class="pt-2 pb-4 flex flex-col w-full">
                    <div
                        class="mx-auto flex items-center justify-center rounded-full bg-danger-100 text-danger-300"
                        style="width: 80px; height: 80px; font-size: 30px"
                    >
                        <em class="fad fa-user-times" />
                    </div>
                    <div class="mt-4 w-full">
                        <h3 class="text-lg text-center font-bold text-secondary-600">
                            <div class="flex flex-col">
                                <span>{{ i18n("crop-plan-locked-by-other") }}</span>
                                <span class="text-base font-normal pt-1">{{
                                    i18n("crop-plan-locked-by-other-info")
                                }}</span>
                            </div>
                        </h3>
                    </div>
                </div>
            </template>
        </abc-modal>
        <abc-modal
            v-if="appLoadingQueue.length && !showCropPlanNotAccessibleModal"
            is-message
            force-modal
            modal-class="w-full md:w-8/12 lg:w-6/12 xxl:w-4/12"
            style="z-index: 1000"
        >
            <template #body>
                <div class="w-full flex items-center justify-center">
                    <em class="fal fa-sync-alt animate-spin text-5xl text-label-secondary"></em>
                </div>
                <div class="mt-4 w-full">
                    <h3 class="text-lg text-center font-bold text-secondary-600">
                        <div class="flex flex-col">
                            <span>{{ i18n("in-progress") }}...</span>
                        </div>
                    </h3>
                </div>
            </template>
        </abc-modal>
        <abc-modal
            v-if="showRecalcAnomaliesConfirmModal"
            modal-class="w-full md:w-8/12 lg:w-6/12 xxl:w-4/12"
            force-modal
            style="z-index: 1000"
            :title="i18n('anomalies-recalculation')"
        >
            <template #body>
                <div class="pt-2 pb-4 flex flex-col w-full">
                    <abc-checkbox
                        v-model="flSyncToRecalcAnomalies"
                        class="pt-3"
                        :label="i18n('recalc-anomalies-on-date-change', { date: formattedDate(curPointInTime) })"
                    />
                    <span class="text-warning-600 mt-3 font-semibold italic">
                        {{ i18n("anomalies-recalculation-warning") }}
                    </span>
                </div>
            </template>
            <template #footer>
                <div class="flex">
                    <abc-button class="ml-2" is-success @click="confirmSyncToRecalcAnomalies">{{
                        i18n("confirm")
                    }}</abc-button>
                </div>
            </template>
        </abc-modal>
        <modal-view v-model="showBulkDeclarationEdit">
            <bulk-declaration-edit :business="business" :curPointInTime="curPointInTime" :curCropPlan="curCropPlan" />
        </modal-view>
    </div>
</template>

<script lang="ts">
import { Vue, Component, Prop, Watch, Inject, Mixins } from "vue-property-decorator";
import { TranslateResult } from "vue-i18n";
import { ITileContainer } from "@abaco/tiles-framework/src/components/tile-container/ITileContainer";
import { FromStore } from "@abaco/web-common/src/app";
import { Business } from "../models/Business";
import SingleCropPlanModule, { MODULE_ID } from "..";
import { Council } from "../models/Council";
import {
    Configuration,
    CropPlan,
    CropPlanDates,
    AnomaliesScenarioConfiguration,
    FunctionCode,
    SyncProgressStatus,
} from "../models/CropPlan";
import { Version } from "../models/Version";
import { Plot } from "../models/Plot";
import { CropPlanArea, Declaration } from "../models/Declaration";
import { EnvConfig } from "@abaco/web-common/src/app/Application";
import { AppLoadingItem } from "../models/Utils";
import { convertToDate, formatDate } from "../api/Utils";
import AppLoadingModal from "./private/appLoadingModal.vue";
import SSOModule from "@abaco/sso-web-module/src/abaco-module";
import { isEqual } from "lodash";
import DateUtils from "../mixins/DateUtils";
import BulkDeclarationEdit from "./bulkDeclarationFieldsEdit/BulkDeclarationFieldsEdit.vue";

@Component({
    components: {
        AppLoadingModal,
        BulkDeclarationEdit,
    },
})
export default class SingleCropPlanTileContainer extends Mixins(DateUtils) {
    @Inject() i18n!: (key: string, values?: unknown) => TranslateResult;
    @Inject() envConfig!: EnvConfig;
    @Inject(SingleCropPlanModule.MODULE_ID) singleCropPlanModule!: SingleCropPlanModule;
    @Inject(SSOModule.MODULE_ID) ssoWebModule!: SSOModule;

    @FromStore(MODULE_ID) business!: Business;
    @FromStore(MODULE_ID) curCouncil!: Council;
    @FromStore(MODULE_ID) curCropPlan!: CropPlan | null;
    @FromStore(MODULE_ID) curConfiguration!: Configuration | null;
    @FromStore(MODULE_ID) anomScenarioConfig!: AnomaliesScenarioConfiguration[];
    @FromStore(MODULE_ID) curVersion!: Version | null;
    @FromStore(MODULE_ID) curPointInTime!: Date;
    @FromStore(MODULE_ID) showLockErrorModal!: boolean;
    @FromStore(MODULE_ID) showNoCropPlanFound!: boolean;
    @FromStore(MODULE_ID) showCannotUseCropPlan!: boolean;
    @FromStore(MODULE_ID) showCropPlanNotAccessibleModal!: boolean;
    @FromStore(MODULE_ID) showCropPlanNotAccessibleModalMessage!: string;
    @FromStore(MODULE_ID) showParcelName!: boolean;
    @FromStore(MODULE_ID) hideFieldName!: boolean;
    @FromStore(MODULE_ID) resetCouncil!: number;
    @FromStore(MODULE_ID) appLoadingQueue!: AppLoadingItem[];
    @FromStore(MODULE_ID) cropPlanDates!: CropPlanDates;
    @FromStore(MODULE_ID) plots!: Plot[];
    @FromStore(MODULE_ID) flCurCorpPlanChangesPending!: boolean;
    @FromStore(MODULE_ID) showCannotUseCropPlanForThisBusiness!: boolean;
    @FromStore(MODULE_ID) pollingIsProcessing!: boolean;
    @FromStore(MODULE_ID) pollingIsPublishSuccess!: boolean;
    @FromStore(MODULE_ID) pollingIsModalOpen!: boolean;
    @FromStore(MODULE_ID) loadingCropPlan!: boolean;
    @FromStore(MODULE_ID) lastCropPlanVersionAvailable!: Version | null;
    @FromStore(MODULE_ID) isCropPlanRestoreVersionAvailable!: boolean;
    @FromStore(MODULE_ID) curDisabledFunctions!: FunctionCode[];
    @FromStore(MODULE_ID) curPlot!: Plot | null;
    @FromStore(MODULE_ID) curPlots!: Plot[];
    @FromStore(MODULE_ID) curDeclaration!: Declaration | null;
    // @FromStore(MODULE_ID) enableDefaultNotPreserveDeclsOnPlotsMerge!: boolean;
    @FromStore(MODULE_ID) showCropPlanSyncModal!: boolean;
    @FromStore(MODULE_ID) flRecalcAnomalies!: boolean;
    @FromStore(MODULE_ID) forceSync!: number;
    @FromStore(MODULE_ID) forceSearchCouncil!: number;
    @FromStore(MODULE_ID) flVinealignBackoffice!: boolean;
    @FromStore(MODULE_ID) flIgnorePreviousSyncs!: boolean;
    @FromStore(MODULE_ID) flSyncToRecalcAnomalies!: boolean;
    @FromStore(MODULE_ID) showRecalcAnomaliesConfirmModal!: boolean;
    @FromStore(MODULE_ID) curCropPlanArea!: CropPlanArea;
    @FromStore(MODULE_ID) showBulkDeclarationEdit!: boolean;

    @Prop() tileId!: string;

    private cropPlans: CropPlan[] = [];
    private syncError: string | null = null;
    private syncIntervalId: number | null = null;
    private flFirstTime = true;
    private forceDatesUpdate = false;
    private curSyncType: string | null = null;
    private get content(): ITileContainer[] {
        return [
            {
                x: 0,
                y: 0,
                w: 1.5,
                h: 6,
                tileIdentifier: "single-cp-plot-list",
            },
            {
                x: 1.5,
                y: 0,
                w: 4.5,
                h: 6,
                tileIdentifier: "single-cp-map",
            },
        ];
    }

    private get syncType() {
        return this.curConfiguration?.SYNC_TYPE_ON_OPEN && this.curConfiguration.SYNC_TYPE_ON_OPEN != "NULL"
            ? this.curConfiguration.SYNC_TYPE_ON_OPEN
            : null;
    }

    private get appLoadingMessages() {
        return this.appLoadingQueue.filter((i) => i.message).map((m) => m.message);
    }

    private async mounted() {
        const cropPlanEnabled =
            (await this.ssoWebModule.isFunctionEnabled("CRPL", "USER")) ||
            (await this.ssoWebModule.isFunctionEnabled("CRPL", "EDITOR"));
        this.flVinealignBackoffice = await this.ssoWebModule.isFunctionEnabled("VINEALIGN", "BACKOFFICE");
        this.showCannotUseCropPlan = !cropPlanEnabled;
        this.showParcelName = this.envConfig.showParcelName || false;
        this.hideFieldName = this.envConfig.hideFieldName || false;
        document.title = this.i18n("crop-plan-tab-title").toString();
    }

    @Watch("curPointInTime")
    private async updateDates(newPt: Date | null, oldPt: Date | null) {
        // if `oldPt == null` we skip as dates are requested by SingleCropPlanTileContainer.loadCropPlan()
        // also we get dates only if the date actually changes (yyyymmdd)
        if (
            !this.curCropPlan ||
            ((!newPt || !oldPt || (oldPt && formatDate(newPt) == formatDate(oldPt))) && !this.forceDatesUpdate)
        ) {
            return;
        }
        await this.updateCropPlanDates();
        this.forceDatesUpdate = false;
    }

    @Watch("curCropPlan")
    private async loadCropPlan(newCp: CropPlan | null, oldCp: CropPlan | null) {
        if (this.curCropPlan === null) this.isCropPlanRestoreVersionAvailable = false;

        if (!this.business || !this.curCropPlan || isEqual(newCp, oldCp)) return;

        this.loadingCropPlan = true;
        this.showCropPlanNotAccessibleModal = false;

        if (this.curCropPlan.locked) {
            this.showCropPlanNotAccessibleModal = true;
            this.showCropPlanNotAccessibleModalMessage = `CROP_PLAN_NOT_ACCESSIBLE_EXCEPTION-${
                this.curCropPlan.lockedErrorCode ?? "BUSINESS_LOCKED"
            }`.toLowerCase();
        }

        // try to lock plan, if it fails the "already locked" res will be intercepted on SingleCropPlan.beforeEnterAnyRoutes()
        if (!this.curCropPlan.readOnly) {
            this.showLockErrorModal = false;
            try {
                await this.singleCropPlanModule.cropPlanApi.lockCropPlan(
                    this.business.businessId,
                    this.curCropPlan.cropPlanId
                );
            } catch (error) {
                console.error(error);
            }
        }

        if (!this.showLockErrorModal && !this.showCropPlanNotAccessibleModal && !this.showCropPlanNotAccessibleModal) {
            await this.downloadCropPlanTypeConfiguration();
            await this.downloadDisabledFunctionsConfig();
            await this.loadCropPlanArea();
            // version check
            const versions = await this.singleCropPlanModule.versionApi.getVersions(
                this.business?.businessId,
                this.curCropPlan?.cropPlanId,
                null
            );
            const lastVersion = versions.records[0];
            if (lastVersion && lastVersion.version && !lastVersion.flPublished) {
                this.pollingVersions(lastVersion.version);
            }
            if (
                this.curConfiguration?.ENABLE_RESTORE_LAST_VERSION === undefined ||
                this.curConfiguration.ENABLE_RESTORE_LAST_VERSION === "FALSE"
            )
                this.isCropPlanRestoreVersionAvailable = false;
            else {
                if (versions.count === 0) {
                    this.isCropPlanRestoreVersionAvailable = false;
                } else {
                    this.isCropPlanRestoreVersionAvailable = true;
                    this.lastCropPlanVersionAvailable = lastVersion;
                }
            }
            if (this.flFirstTime || newCp?.cropPlanId != oldCp?.cropPlanId) {
                // Set to default date: fist time or on cropPlanId change
                const defaultDate =
                    (await this.singleCropPlanModule.cropPlanApi.getDefaultDate(
                        this.business.businessId,
                        this.curCropPlan.cropPlanId
                    )) || formatDate(new Date());

                this.cropPlanDates = {
                    fixedOpenDate: defaultDate,
                    fixedEditDate: null,
                    referenceDate: "",
                    campaignStartDate: null,
                    lastSyncReferenceDate: null,
                };

                await this.updateCropPlanDates();
                if (defaultDate) {
                    const oldPointInTime = this.curPointInTime;
                    const newCurPointInTime = convertToDate(defaultDate);
                    if (formatDate(oldPointInTime) == defaultDate)
                        // if CropPlan changed and curPointIntime not, force dates update
                        this.forceDatesUpdate = true;
                    if (newCurPointInTime) this.curPointInTime = newCurPointInTime;
                    else {
                        this.curPointInTime = new Date();
                    }
                }

                this.flFirstTime = false;
            }
            if (
                this.curConfiguration?.CONSTRAINTS_VERSION_TO_SYNC_REF_DATE === "TRUE" &&
                this.cropPlanDates.lastSyncReferenceDate != null &&
                this.cropPlanDates.lastSyncReferenceDate != formatDate(this.curPointInTime)
            )
                this.showRecalcAnomaliesConfirmModal = true;
            else this.shouldSync();
        }
        this.loadingCropPlan = false;
    }

    // @Watch("curCouncil")
    // private async loadCropPlanAreaOnBigDomainZone() {
    //     if(this.curCouncil && this.curCouncil.bigDomainZone && this.plots.length == 0) {
    //         // this.loadCropPlanArea();
    //     }
    // }

    @Watch("curVersion")
    @Watch("plots")
    private async loadCropPlanArea() {
        if (this.curCropPlan) {
            try {
                const cropPlanAreaResp = await this.singleCropPlanModule.cropPlanApi.getCropPlanArea(
                    this.business.businessId,
                    this.curCropPlan.cropPlanId,
                    this.curPointInTime,
                    this.curVersion ? this.curVersion.version : null,
                    this.curCouncil?.domainZoneId
                );

                this.curCropPlanArea = cropPlanAreaResp;
            } catch (error) {
                console.error(error);
            }
        }
    }

    @Watch("business", { immediate: true })
    private async updateCropPlans() {
        this.resetIntervalId();
        this.syncError = null;
        this.showCropPlanSyncModal = false;
        this.cropPlans = [];
        this.curCropPlan = null;
    }

    @Watch("plots")
    private async checkChangesPending() {
        if (!this.curCropPlan) return;
        const cropPlan = await this.singleCropPlanModule.cropPlanApi.getCropPlanById(
            this.business.businessId,
            this.curCropPlan.cropPlanId
        );
        this.flCurCorpPlanChangesPending = cropPlan.changesPending;
    }

    @Watch("curPlot")
    @Watch("curPlots")
    @Watch("curDeclaration")
    @Watch("plots")
    private updateDisabledFunctions() {
        const activeScenarios: AnomaliesScenarioConfiguration[] = [];
        const funcToDisable: FunctionCode[] = [];
        const onlyIfIn: FunctionCode[] = [];
        // valuto alla selezione di una declaration, check su anomalie della decl selezionata, del plot e delle parcel del plot
        if (this.curDeclaration && this.curPlot) {
            let anomalyCodes: string[] = [];
            anomalyCodes.push(...this.curDeclaration.anomalies.map((d) => d.errorCode));
            if (this.curPlot) {
                anomalyCodes.push(...this.curPlot.anomalies.map((d) => d.errorCode));
                this.curPlot.parcelIntersections.forEach((p) => {
                    if (p.anomalies) anomalyCodes.push(...p.anomalies.map((d) => d.errorCode));
                });
            }
            anomalyCodes = anomalyCodes.filter((v, i, s) => s.indexOf(v) === i);
            this.anomScenarioConfig.forEach((s) => {
                if (this.isScenarioActive(s, anomalyCodes)) activeScenarios.push(s);
            });
        }
        // valuto alla selezione di un plot, check su anomalie del plot, delle parcel del plot e di tutte le decl del plot
        else {
            if (!this.curPlot) onlyIfIn.push("CUT_PLOTS");
            const plots = this.curPlot ? [this.curPlot, ...this.curPlots] : this.plots;
            plots.forEach((plot) => {
                let anomalyCodes: string[] = [];
                anomalyCodes.push(...plot.anomalies.map((d) => d.errorCode));
                plot.parcelIntersections.forEach((p) => {
                    if (p.anomalies) anomalyCodes.push(...p.anomalies.map((d) => d.errorCode));
                });
                plot.decls.forEach((d) => {
                    anomalyCodes.push(...d.anomalies.map((d) => d.errorCode));
                });
                anomalyCodes = anomalyCodes.filter((v, i, s) => s.indexOf(v) === i);
                this.anomScenarioConfig.forEach((s) => {
                    if (this.isScenarioActive(s, anomalyCodes)) activeScenarios.push(s);
                });
            });
        }
        activeScenarios.forEach((s) => {
            funcToDisable.push(...s.functionsDisabledConfig.map((f) => f.functionCode));
        });
        //
        this.curDisabledFunctions = funcToDisable
            .filter((v, i, s) => s.indexOf(v) === i)
            .filter((c) => !onlyIfIn.length || onlyIfIn.includes(c));
    }

    private isScenarioActive(scenario: AnomaliesScenarioConfiguration, anomalyCodes: string[]) {
        let matchesAllReq = true;
        scenario.scenarioAnomaliesConfig.forEach((r) => {
            if (r.fl_present === true && !anomalyCodes.includes(r.anomaliyCode)) {
                matchesAllReq = false;
            } else if (r.fl_present === false && anomalyCodes.includes(r.anomaliyCode)) {
                matchesAllReq = false;
            }
        });
        return matchesAllReq;
    }

    @Watch("forceSync")
    private shouldSync() {
        if (this.business && this.curCropPlan && this.syncType) this.checkAndSyncCropPlan(this.syncType, 10000);
    }

    private retrySync() {
        this.syncError = null;
        this.forceSync++;
    }

    private async checkAndSyncCropPlan(syncType: string, syncPoll: number) {
        if (!this.business || !this.curCropPlan || !this.curPointInTime) {
            console.error("Select a business id and a crop plan first");
            return;
        }
        try {
            this.curSyncType = null;
            let status = await this.singleCropPlanModule.cropPlanApi.getSyncCropPlanStatus(
                this.business.businessId,
                this.curCropPlan.cropPlanId
            );
            if (!this.curCropPlan.readOnly && status.syncProgressStatus !== SyncProgressStatus.IN_PROGRESS) {
                status = await this.singleCropPlanModule.cropPlanApi.syncCropPlan(
                    this.business.businessId,
                    this.curCropPlan.cropPlanId,
                    syncType,
                    this.curPointInTime,
                    this.flIgnorePreviousSyncs
                );
                this.flIgnorePreviousSyncs = false;
            }
            this.curSyncType = status.syncType;
            if (status.syncProgressStatus === SyncProgressStatus.IN_PROGRESS) {
                if (status.syncType === "RECALC_ANOMALIES") {
                    this.flRecalcAnomalies = true;
                }
                this.showCropPlanSyncModal = true;
                await this.pollForSyncStatus(this.business.businessId, this.curCropPlan.cropPlanId, syncPoll);
                return;
            }
        } catch (error) {
            console.error(error);
            this.syncError = (error as any).message;
        }
    }

    private async pollForSyncStatus(businessId: string, cropPlanId: number, syncPoll: number) {
        if (this.syncIntervalId) {
            this.resetIntervalId();
        }
        this.syncIntervalId = window.setInterval(async () => {
            try {
                const status = await this.singleCropPlanModule.cropPlanApi.getSyncCropPlanStatus(
                    businessId,
                    cropPlanId
                );
                if (status.syncProgressStatus === SyncProgressStatus.IN_PROGRESS) {
                    return;
                }
                if (status.syncProgressStatus === SyncProgressStatus.COMPLETED && status.withErrors) {
                    this.syncError = this.i18n("sync-failed-msg").toString();
                    this.resetIntervalId();
                    return;
                }
                if (status.syncProgressStatus === SyncProgressStatus.COMPLETED && !status.withErrors) {
                    this.resetIntervalId();
                    if (!this.curCropPlan) return;
                    if (!this.flRecalcAnomalies)
                        this.curCropPlan = await this.singleCropPlanModule.cropPlanApi.getCropPlanById(
                            this.business.businessId,
                            this.curCropPlan.cropPlanId
                        );
                    const editEnabled = await this.ssoWebModule.isFunctionEnabled("CRPL", "EDITOR");
                    if (!editEnabled) this.curCropPlan.readOnly = true;
                    await this.updateCropPlanDates();
                    this.syncError = null;
                    this.showCropPlanSyncModal = false;
                    this.flRecalcAnomalies = false;
                    this.resetCouncil++;
                }
            } catch (error) {
                console.error(error);
                this.syncError = (error as any).message;
                this.resetIntervalId();
            }
        }, syncPoll);
    }

    private onSyncModalClose() {
        this.showCropPlanSyncModal = false;
        this.curSyncType = null;
        this.syncError = null;
    }

    private resetIntervalId() {
        if (this.syncIntervalId) {
            window.clearInterval(this.syncIntervalId);
            this.syncIntervalId = null;
        }
    }

    // Recoursive polling fn
    private async pollingVersions(lastVersion: string) {
        if (!this.business || !this.curCropPlan) return;
        try {
            // Start polling
            this.pollingIsProcessing = true;
            this.pollingIsModalOpen = true;
            const res = await this.singleCropPlanModule.versionApi.getVersions(
                this.business.businessId,
                this.curCropPlan.cropPlanId,
                null
            );
            // There aren't versions
            if (res.records.length === 0) {
                // Stop polling
                this.pollingIsProcessing = false;
                this.pollingIsPublishSuccess = false;
                return;
            }

            const currLastVersion = res.records[0]?.version;
            const isFlPublish = res.records[0]?.flPublished;

            // Polling isn't needed
            if (lastVersion === currLastVersion && isFlPublish) {
                // Stop polling
                this.pollingIsProcessing = false;
                this.pollingIsPublishSuccess = true;
                return;
            }

            // Start recoursive polling
            if (lastVersion === currLastVersion && !isFlPublish) {
                await new Promise((resolve) => setTimeout(resolve, 5000));
                await this.pollingVersions(lastVersion);
            }

            // The compared versions aren't equal
            if (lastVersion !== currLastVersion) {
                const updatedCropPlan = await this.singleCropPlanModule.cropPlanApi.getCropPlanById(
                    this.business.businessId,
                    this.curCropPlan.cropPlanId
                );
                if (updatedCropPlan && this.curCropPlan) {
                    this.curCropPlan = updatedCropPlan;
                }
                // Stop polling
                this.pollingIsProcessing = false;
                this.pollingIsPublishSuccess = false;
                return;
            }
        } catch (error) {
            // Show error modal & Stop polling
            this.pollingIsProcessing = false;
            this.pollingIsPublishSuccess = false;
            return;
        }
    }

    private async downloadCropPlanTypeConfiguration() {
        if (!this.curCropPlan) return;
        this.curConfiguration = await this.singleCropPlanModule.cropPlanApi.getCropPlanTypeConfiguration(
            this.business.businessId,
            this.curCropPlan.cropPlanId
        );
        // if(this.curConfiguration.ENABLE_DEFAULT_NOT_PRESERVE_DECLS_ON_PLOTS_MERGE)
        //     this.enableDefaultNotPreserveDeclsOnPlotsMerge =
        //         this.curConfiguration.ENABLE_DEFAULT_NOT_PRESERVE_DECLS_ON_PLOTS_MERGE ? true : false
    }

    private async downloadDisabledFunctionsConfig() {
        if (!this.curCropPlan) return;
        this.anomScenarioConfig = await this.singleCropPlanModule.cropPlanApi.getDisabledFunctionsConfig(
            this.business.businessId,
            this.curCropPlan.cropPlanId
        );
    }

    private async updateCropPlanDates() {
        if (!this.curCropPlan?.cropPlanId) return;
        const res = await this.singleCropPlanModule.cropPlanApi.getDates(
            this.business.businessId,
            this.curCropPlan.cropPlanId,
            formatDate(this.curPointInTime)
        );

        this.cropPlanDates = {
            fixedEditDate: res.fixedEditDate,
            referenceDate: res.referenceDate,
            campaignStartDate: res.campaignStartDate,
            fixedOpenDate: this.cropPlanDates.fixedOpenDate,
            lastSyncReferenceDate: res.lastSyncReferenceDate,
        };
    }

    private async confirmSyncToRecalcAnomalies() {
        if (this.flSyncToRecalcAnomalies) await this.shouldSync();
        else this.forceSearchCouncil++;
        this.flSyncToRecalcAnomalies = false;
        this.showRecalcAnomaliesConfirmModal = false;
    }
}
</script>
