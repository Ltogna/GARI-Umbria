<template>
    <tile :title="!showDropdown ? i18n('fields') : i18n('list-view')" :noTopbar="getisGCP()">
        <template v-if="!openInfoTile && !openEditTile && !openParcelTile && toolbuttonsEnabled" #tile-buttons>
            <tile-button
                :tooltip="i18n('search')"
                :isActive="isFilterActive"
                @click="
                    showOrderPanel = false;
                    showFilterPanel = !showFilterPanel;
                "
            >
                <em v-if="!showFilterPanel" class="fal fa-search text-white" />
                <em v-else class="abc-icon abc-icon-x text-sm text-white" />
            </tile-button>
            <tile-button
                v-if="selectedInfo === 'cadparcels'"
                :tooltip="i18n('overlaps')"
                @click="showOverlapsModal = !showOverlapsModal"
            >
                <em class="fa-regular fa-copy text-white"></em>
            </tile-button>
            <tile-button
                v-if="selectedInfo === 'crop-plan'"
                :tooltip="i18n('order-by')"
                @click="
                    showFilterPanel = false;
                    showOrderPanel = !showOrderPanel;
                "
            >
                <em v-if="!showOrderPanel" class="text-lg fal fa-exchange-alt transform rotate-90 text-white" />
                <em v-else class="abc-icon abc-icon-x text-sm text-white" />
            </tile-button>
        </template>

        <template v-if="!openInfoTile && !openEditTile && !openParcelTile && toolbuttonsEnabled" #content-buttons>
            <tile-button
                v-if="curPlot || curParcelData || curCadastralData"
                :tooltip="i18n('deselect')"
                @click="deselect"
            >
                <em class="abc-icon abc-icon-x text-sm text-white"></em>
            </tile-button>
            <tile-button
                v-if="curPlot && deleteAuth && editPlotMode === getEditPlotMode.NOT_SELECTED && !isReadOnly"
                :tooltip="i18n('remove')"
                @click="
                    checkAndExecEditDeleteGeom(() =>
                        checkDate(
                            () => (showConfirmDeletePlot = true),
                            getEditPlotMode.DELETING,
                            maxCampaignAndPlotsDate
                        )
                    )
                "
                :is-disabled="curDisabledFunctions.includes('DELETE_PLOTS')"
            >
                <em class="abc-icon abc-icon-trash-bin text-white"></em>
            </tile-button>
            <tile-button
                v-if="curPlot && editPlotMode === getEditPlotMode.NOT_SELECTED && !isReadOnly"
                :tooltip="i18n('edit')"
                @click="
                    checkAndExecEditDeleteGeom(() =>
                        checkDate(() => forceStartEditing++, getEditPlotMode.EDITING, maxCampaignAndPlotsDate)
                    )
                "
                :is-disabled="curDisabledFunctions.includes('EDIT_PLOTS')"
            >
                <em class="abc-icon abc-icon-pen text-white"></em>
            </tile-button>

            <tile-button
                v-if="curPlot && editPlotMode === getEditPlotMode.NOT_SELECTED && showEditPlotData && !isReadOnly"
                :tooltip="i18n('edit-plot-data')"
                @click="openEditTile = true"
                :is-disabled="curDisabledFunctions.includes('EDIT_PLOTS')"
            >
                <em class="abc-icon abc-icon-pen-2 text-white"></em>
            </tile-button>
            <tile-button
                v-if="
                    curConfiguration.ENABLE_RESTORE_PLOT_DEFAULT === 'TRUE' &&
                    curPlot &&
                    editPlotMode === getEditPlotMode.NOT_SELECTED &&
                    !isReadOnly
                "
                :tooltip="i18n('restore')"
                @click="
                    checkAndExecEditDeleteGeom(() => {
                        showConfirmRestorePlot = true;
                    })
                "
            >
                <em class="abc-icon abc-icon-arrow-circle text-white"></em>
            </tile-button>
            <tile-button
                v-if="
                    curPlot &&
                    editPlotMode === getEditPlotMode.NOT_SELECTED &&
                    !isReadOnly &&
                    curConfiguration.ENABLE_RESUME_PLOT_FROM_FIRST_CROP_PLAN_VERSION === 'TRUE'
                "
                :tooltip="i18n('restore-first-version')"
                @click="
                    checkAndExecEditDeleteGeom(() => {
                        showConfirmRestoreFirstVersionPlot = true;
                    })
                "
            >
                <em class="fa-light fa-repeat-1 text-white"></em>
            </tile-button>

            <tile-button
                v-if="curPlot || curCadastralData || curParcelData"
                :tooltip="i18n('view-info')"
                @click="openInfoTile = true"
            >
                <em class="abc-icon abc-icon-folder text-white"></em>
            </tile-button>
            <tile-button
                v-if="
                    editAuth &&
                    editPlotMode === getEditPlotMode.NOT_SELECTED &&
                    isCanAddPlots &&
                    selectedInfo === 'crop-plan'
                "
                :tooltip="i18n('add')"
                @click="checkDate(() => forceStartDrawing++, getEditPlotMode.ADDING, maxCampaignAndPlotsDate)"
            >
                <em class="abc-icon abc-icon-plus text-white"></em>
            </tile-button>
            <tile-button
                v-if="
                    editAuth &&
                    editPlotMode === getEditPlotMode.NOT_SELECTED &&
                    isCanAddPlots &&
                    selectedInfo === 'crop-plan'
                "
                :tooltip="i18n('graphic-multiselection')"
                @click="editPlotMode = getEditPlotMode.MULTISELECTION"
            >
                <em class="fal fa-square-dashed"></em>
            </tile-button>
            <tile-button
                v-if="
                    convertedCurConfigCopyDate !== null &&
                    editAuth &&
                    editPlotMode === getEditPlotMode.NOT_SELECTED &&
                    isCanAddPlots &&
                    selectedInfo == 'crop-plan'
                "
                :tooltip="i18n('copy-declarations')"
                @click="checkAndExecAddDecl(() => (showConfirmCopy = true))"
            >
                <em class="abc-icon abc-icon-level-add text-white"></em>
            </tile-button>
            <tile-button
                v-if="
                    (curConfiguration.ENABLE_COPY_DECLARATIONS_FROM_VERSION === 'TRUE' || curConfiguration.ENABLE_COPY_CAMPAIGN === 'TRUE') &&
                    editAuth &&
                    editPlotMode === getEditPlotMode.NOT_SELECTED &&
                    isCanAddPlots &&
                    selectedInfo == 'crop-plan'
                "
                :tooltip="curConfiguration.ENABLE_COPY_CAMPAIGN === 'TRUE' ? i18n('copy-campaign') : i18n('copy-declarations-from-version')"
                @click="checkAndExecAddDecl(() => (showCopyDeclarationsFromVersionModal = true))"
            >
                <em class="abc-icon abc-icon-level-add text-white"></em>
            </tile-button>
            <tile-button
                v-if="
                    editAuth &&
                    editPlotMode === getEditPlotMode.NOT_SELECTED &&
                    isCanAddPlots &&
                    selectedInfo == 'crop-plan' &&
                    swappableLanduses.length > 0 &&
                    isSwapEnabled
                "
                :tooltip="i18n('swap-landuses', { landuseLabel: i18n('land-uses-legend').toString().toLowerCase() })"
                @click="checkAndExecAddDecl(() => (openSwapModal = true))"
            >
                <em class="abc-icon abc-icon-plant-circle text-white"></em>
            </tile-button>
            <tile-button
                v-if="enablePesticides"
                :tooltip="i18n('add-pesticide-use')"
                @click="
                    openAddProductMode = true;
                    openAddPestMode = false;
                "
            >
                <em class="fal fa-bug text-white"></em>
            </tile-button>
            <tile-button
                v-if="enablePesticides"
                :tooltip="i18n('show-all-pesticides')"
                @click="openShowAllPesticides = true"
            >
                <em class="fal fa-bugs text-white"></em>
            </tile-button>

            <tile-button
                v-if="enablePest"
                :tooltip="i18n('add-pest-use')"
                @click="
                    openAddPestMode = true;
                    openAddProductMode = false;
                "
            >
                <em class="fal fa-virus text-white"></em>
            </tile-button>
            <tile-button v-if="enablePest" :tooltip="i18n('show-all-pests')" @click="openShowAllPEST = true">
                <em class="fal fa-viruses text-white"></em>
            </tile-button>
            <tile-button
                v-if="
                    !isReadOnly &&
                    curConfiguration.ENABLE_FORCED_SYNC === 'TRUE' &&
                    canForceSync &&
                    curCropPlan.cropPlanTypeCode
                "
                :tooltip="i18n('force-sync')"
                @click="showForceSyncConfirmModal = true"
            >
                <em class="fa-regular fa-rotate-exclamation text-white"></em>
            </tile-button>
            <tile-button
                v-if="enablePublicationsList && !openInfoTile && !openEditTile && !openParcelTile"
                :tooltip="i18n('published-versions-list')"
                @click="showVersionsModal = true"
            >
                <em class="fal fa-list text-white"></em>
            </tile-button>
            <tile-button
                v-if="curCropPlan.cropPlanPrints.length > 0"
                :tooltip="i18n('lot.print.button')"
                @click="showPrintModal = true"
            >
                <em class="abc-icon abc-icon-printer text-sm text-white"></em>
            </tile-button>
        </template>

        <div class="flex flex-col w-full h-full relative overflow-x-hidden overflow-y-hidden">
            <!-- INFO MODAL -->
            <transition
                name="custom-classes-transition"
                enter-active-class="animate__animated animate__fadeInRight animate__faster"
                leave-active-class="animate__animated animate__fadeOutRight animate__faster"
                mode="out-in"
            >
                <single-cp-plot-info v-if="openInfoTile && curPlot" @close="openInfoTile = false" />
                <single-cp-parcel-info v-else-if="openInfoTile && curParcelData" @close="openInfoTile = false" />
                <single-cp-parcel-info v-else-if="openInfoTile && curCadastralData" @close="openInfoTile = false" />
            </transition>

            <!-- EDIT MODAL -->

            <transition
                name="custom-classes-transition"
                enter-active-class="animate__animated animate__fadeInRight animate__faster"
                leave-active-class="animate__animated animate__fadeOutRight animate__faster"
                mode="out-in"
            >
                <single-cp-plot-edit v-if="openEditTile" @close="openEditTile = false" @updated="updatePlotDescr" />
            </transition>
            <!-- OPEN PARCEL TILE  -->
            <transition
                name="custom-classes-transition"
                enter-active-class="animate__animated animate__fadeInRight animate__faster"
                leave-active-class="animate__animated animate__fadeOutRight animate__faster"
                mode="out-in"
            >
                <single-cp-parcel-notes-edit
                    v-if="openParcelTile"
                    @close="openParcelTile = false"
                    @updated="updatePlot"
                />
            </transition>
            <!-- END OPEN PARCEL TILE  -->
            <!-- PUBLISH PANEL -->
            <crop-plan-publish v-if="isCropPlanPublishShown" />

            <!-- COUNCIL AND DATE -->
            <div v-if="!showNavBar" class="single-cp-progress-card flex flex-col border-b px-3 pt-2 pb-2">
                <span class="text-xs uppercase tracking-wider text-label-primary">{{ i18n("filters") }}</span>
                <div class="filter-container py-2">
                    <div class="filter-item" @click="timeSelect()">
                        <div class="flex justify-center justify-items-center mx-4">
                            <span class="text-xs uppercase"
                                ><em class="abc-icon abc-icon-calendar mr-1" />
                                {{ curPointInTime.toLocaleString([], { dateStyle: "short" }) }}</span
                            >
                        </div>
                        <div class="edit-button"><em class="abc-icon abc-icon-pen text-sm" /></div>
                    </div>
                    <div class="filter-item" @click="toggleCouncilSelection()">
                        <div class="flex justify-center justify-items-center mx-4">
                            <span class="text-xs uppercase"
                                ><em class="abc-icon abc-icon-maps-2 mr-1" />{{ curCouncil.description }}</span
                            >
                        </div>
                        <div class="edit-button"><em class="abc-icon abc-icon-pen text-sm" /></div>
                    </div>
                </div>
            </div>

            <!-- FILTER PANEL -->
            <transition
                name="custom-classes-transition"
                enter-active-class="animate__animated animate__fadeInDown10 animate__faster"
                mode="out-in"
            >
                <div
                    v-if="showFilterPanel && selectedInfo === 'crop-plan'"
                    class="flex flex-col w-full absolute top-0 px-4 py-6 pt-2 z-40 bg-bg-100 shadow-xl"
                    @keydown.enter="showFilterPanel = false"
                >
                    <div class="fixed inset-0" @click="showFilterPanel = false"></div>
                    <div class="flex pt-2">
                        <abc-input
                            class="w-full"
                            :label="i18n('search')"
                            v-model="filter.search"
                            :placeholder="
                                !hideFieldName ? i18n('search-for-plot-or-parcel') : i18n('search-for-parcel')
                            "
                            ref="plotSearchInput"
                            is-focused
                        />
                    </div>
                    <div class="flex pt-2">
                        <abc-autocomplete
                            class="w-full"
                            :label="i18n('land-use-order')"
                            v-model="curLandUse"
                            :items="availableLandUses"
                            :stringify="(item) => (item ? item.description : null)"
                            :search.sync="searchLandUse"
                            maxHeight="300px"
                            buttons
                        >
                            <template>
                                <div class="flex w-full"></div>
                            </template>
                            <template #items="{ item }">
                                <div>{{ item.description }}</div>
                            </template>
                            <template>
                                <div
                                    v-if="availableLandUses.length === 0"
                                    class="flex justify-center items-center h-12"
                                >
                                    <abc-no-data-found />
                                </div>
                            </template>
                            <template #buttons>
                                <abc-tool-button
                                    is-secondary
                                    @click="
                                        searchLandUse = '';
                                        curLandUse = null;
                                    "
                                    :title="i18n('clear-field')"
                                >
                                    <em class="abc-icon abc-icon-x text-xs"></em>
                                </abc-tool-button>
                            </template>
                        </abc-autocomplete>
                    </div>
                    <div v-if="landCoverFilters.length === 0" class="flex pt-2">
                        <abc-autocomplete
                            class="w-full"
                            :label="i18n('land-cover-order')"
                            v-model="curLandCover"
                            :items="availableLandCovers"
                            :stringify="(item) => (item ? item.landCoverDescription : null)"
                            :search.sync="searchLandCover"
                            maxHeight="300px"
                            buttons
                        >
                            <template>
                                <div class="flex w-full"></div>
                            </template>
                            <template #items="{ item }">
                                <div>{{ item.landCoverDescription }}</div>
                            </template>
                            <template>
                                <div
                                    v-if="availableLandCovers.length === 0"
                                    class="flex justify-center items-center h-12"
                                >
                                    <abc-no-data-found />
                                </div>
                            </template>
                            <template #buttons>
                                <abc-tool-button
                                    is-secondary
                                    @click="
                                        searchLandCover = '';
                                        curLandCover = null;
                                    "
                                    :title="i18n('clear-field')"
                                >
                                    <em class="abc-icon abc-icon-x text-xs"></em>
                                </abc-tool-button>
                            </template>
                        </abc-autocomplete>
                    </div>
                    <div v-if="landCoverFilters.length" class="pt-2">
                        <p>{{ i18n("land-cover-filters") }}</p>
                        <div class="pt-2">
                            <abc-switch
                                v-for="filter in landCoverFilters"
                                :key="filter.landCoverDescription"
                                :label="filter.landCoverDescription"
                                :value="landCoverFilterStatus[filter.landCoverDescription]"
                                @input="updateActiveLandCoverFilter($event, filter.landCoverDescription)"
                            />
                        </div>
                    </div>
                    <div v-if="anomaliesFilters.length" class="flex pt-2">
                        <abc-switch :label="i18n('plot-anomalies')" v-model="anomaliesOnlyEnabled" />
                    </div>
                    <div v-if="anomaliesFilters.length && anomaliesOnlyEnabled" class="pt-2">
                        <div class="gap-x-4 gap-y-2 pt-2">
                            <abc-autocomplete
                                class="w-full"
                                :label="i18n('plot-anomalies-filters')"
                                v-model="activeAnomalyFilter"
                                :items="filteredAnomalies"
                                :stringify="
                                    (item) =>
                                        item ? (item.errorDescription ? item.errorDescription : item.errorCode) : null
                                "
                                :search.sync="searchAnomaly"
                                maxHeight="300px"
                                buttons
                            >
                                <template>
                                    <div class="flex w-full"></div>
                                </template>
                                <template #items="{ item }">
                                    <div>{{ item.errorDescription ? item.errorDescription : item.errorCode }}</div>
                                </template>
                                <template>
                                    <div
                                        v-if="anomaliesFilters.length === 0"
                                        class="flex justify-center items-center h-12"
                                    >
                                        <abc-no-data-found />
                                    </div>
                                </template>
                                <template #buttons>
                                    <abc-tool-button
                                        is-secondary
                                        @click="
                                            searchAnomaly = '';
                                            activeAnomalyFilter = null;
                                        "
                                        :title="i18n('clear-field')"
                                    >
                                        <em class="abc-icon abc-icon-x text-xs"></em>
                                    </abc-tool-button>
                                </template>
                            </abc-autocomplete>
                        </div>
                    </div>
                    <div class="flex w-full pt-6">
                        <abc-button
                            class="w-full"
                            is-outlined
                            @click="
                                showFilterPanel = false;
                                resetFilter();
                            "
                        >
                            <em class="abc-icon abc-icon-sheet" />
                            {{ i18n("clear-field") }}
                        </abc-button>
                        <abc-button class="w-full" @click="applyFilters()">
                            <em class="abc-icon abc-icon-lens" style="margin-bottom: -3px" />
                            {{ i18n("apply") }}
                        </abc-button>
                    </div>
                </div>

                <div
                    v-if="showFilterPanel && selectedInfo !== 'crop-plan'"
                    class="flex flex-col w-full absolute top-0 px-4 py-6 pt-2 z-40 bg-bg-100 shadow-xl"
                    @keydown.enter="showFilterPanel = false"
                >
                    <div class="fixed inset-0" @click="showFilterPanel = false"></div>
                    <div class="flex pt-2">
                        <abc-input
                            class="w-full"
                            :label="i18n('sheet')"
                            v-model="searchSheet"
                            :placeholder="i18n('sheet')"
                            is-focused
                        />
                    </div>
                    <div class="flex pt-2">
                        <abc-input
                            class="w-full"
                            :label="i18n('parcel-l')"
                            v-model="searchParcel"
                            :placeholder="i18n('parcel-l')"
                        />
                    </div>

                    <div v-if="showParcelAnomaliesFilter" class="flex pt-2">
                        <abc-switch :label="i18n('plot-anomalies')" v-model="anomaliesOnlyEnabled" />
                    </div>
                    <div v-if="showParcelAnomaliesFilter && anomaliesOnlyEnabled" class="pt-2">
                        <div class="gap-x-4 gap-y-2 pt-2">
                            <abc-autocomplete
                                class="w-full"
                                :label="i18n('plot-anomalies-filters')"
                                v-model="selectedParcelAnomaly"
                                :items="filteredParcelAnomaly"
                                :stringify="
                                    (item) =>
                                        item ? (item.errorDescription ? item.errorDescription : item.errorCode) : null
                                "
                                :search.sync="searchParcelAnomaly"
                                maxHeight="300px"
                                buttons
                            >
                                <template>
                                    <div class="flex w-full"></div>
                                </template>
                                <template #items="{ item }">
                                    <div>{{ item.errorDescription ? item.errorDescription : item.errorCode }}</div>
                                </template>
                                <template>
                                    <div
                                        v-if="filteredParcelAnomaly.length === 0"
                                        class="flex justify-center items-center h-12"
                                    >
                                        <abc-no-data-found />
                                    </div>
                                </template>
                                <template #buttons>
                                    <abc-tool-button
                                        is-secondary
                                        @click="
                                            searchParcelAnomaly = '';
                                            selectedParcelAnomaly = null;
                                        "
                                        :title="i18n('clear-field')"
                                    >
                                        <em class="abc-icon abc-icon-x text-xs"></em>
                                    </abc-tool-button>
                                </template>
                            </abc-autocomplete>
                        </div>
                    </div>

                    <div class="flex w-full pt-6">
                        <abc-button
                            class="w-full"
                            is-outlined
                            @click="
                                showFilterPanel = false;
                                resetFilter();
                            "
                        >
                            <em class="abc-icon abc-icon-sheet" />
                            {{ i18n("clear-field") }}
                        </abc-button>
                        <abc-button class="w-full" @click="applyFilters()">
                            <em class="abc-icon abc-icon-lens" style="margin-bottom: -3px" />
                            {{ i18n("apply") }}
                        </abc-button>
                    </div>
                </div>
            </transition>

            <!-- ORDER PANEL -->
            <transition
                name="custom-classes-transition"
                enter-active-class="animate__animated animate__fadeInDown10 animate__faster"
                mode="out-in"
            >
                <div
                    v-if="showOrderPanel"
                    class="flex flex-col w-full absolute top-0 px-4 py-6 pt-4 z-40 bg-bg-100 shadow-xl"
                    @keydown.enter="showOrderPanel = false"
                >
                    <div class="fixed inset-0" @click="showOrderPanel = false"></div>
                    <div class="flex pt-2">
                        <div class="flex flex-col">
                            <div class="pb-2">{{ i18n("order-by") }}</div>
                            <abc-radio
                                class="py-1"
                                v-model="listOrder"
                                v-for="e in orders"
                                :key="e.id"
                                :radio-value="e.id"
                                :label="e.description"
                                @change="showOrderPanel = false"
                            />
                        </div>
                    </div>
                </div>
            </transition>

            <!-- DROPDOWN SELECT -->
            <div v-if="showDropdown" class="w-full pl-2 pr-4 py-4 flex justify-center items-center">
                <abc-dropdown2 class="info-select w-full" :items="infoOptions" v-model="selectedInfo">
                    <p v-if="selectedInfo === 'crop-plan'" class="text-sm font-semibold tracking-wide">
                        {{ i18n("fields") }}
                    </p>
                    <p v-if="selectedInfo === 'cadparcels'" class="text-sm font-semibold tracking-wide">
                        {{ i18n("cadastral-parcels") }}
                    </p>
                    <p v-if="selectedInfo === 'parcels'" class="text-sm font-semibold tracking-wide">
                        {{ getParcelDescription() }}
                    </p>
                    <template #items="{ item }">
                        <div v-if="item === 'crop-plan'" class="text-sm cursor-pointer">
                            {{ i18n("fields") }}
                        </div>
                        <div v-if="item === 'cadparcels'" class="text-sm cursor-pointer">
                            {{ i18n("cadastral-parcels") }}
                        </div>
                        <div v-if="item === 'parcels'" class="text-sm cursor-pointer">
                            {{ getParcelDescription() }}
                        </div>
                    </template>
                </abc-dropdown2>
            </div>
            <!-- CROP PLAN PROGRESSION BAR -->
            <crop-plan-progress-card
                v-if="selectedInfo === 'crop-plan' && flShowCropPlanProgressBar"
                :value="cropPlanTotalAreaPerc"
                :label="i18n('total-holding-planted-at-date')"
                :haDeclared="
                    i18n('holding-planted-at-date-area-ha', {
                        declaredArea: formattedArea(cropPlanTotalDeclaredArea),
                        totalArea: formattedArea(curCropPlanArea.totalPlotsAreaSqm || 0),
                    })
                "
            />

            <!-- COUNCIL PROGRESSION BAR -->
            <crop-plan-progress-card
                v-if="selectedInfo === 'crop-plan'"
                :value="domainTotalAreaPerc"
                :label="i18n('holding-planted-at-date')"
                :haDeclared="
                    i18n('holding-planted-at-date-area-ha', {
                        declaredArea: formattedArea(domainTotalDeclaredArea),
                        totalArea: formattedArea(curCropPlanArea.domainPlotsAreaSqm || 0),
                    })
                "
            />
            <div
                class="flex flex-col w-full h-full relative overflow-x-hidden"
                @scroll="onScroll"
                :class="{ 'overflow-y-hidden': openInfoTile || openEditTile }"
                v-resize="forceAccordionUpdateAfterDelay"
            >
                <abc-loader v-if="loading" class="pt-12" />

                <single-cp-cad-parcel-list
                    v-else-if="selectedInfo === 'cadparcels'"
                    :cadastral-data="searchResults"
                    :scrollUpdate="scrollUpdate"
                />

                <single-cp-parcel-list
                    v-else-if="selectedInfo === 'parcels'"
                    :parcel-data="searchResults"
                    :scrollUpdate="scrollUpdate"
                />

                <!-- PLOT LIST -->
                <transition
                    v-else
                    name="custom-classes-transition"
                    enter-active-class="animate__animated animate__fadeIn animate__faster"
                    mode="out-in"
                >
                    <div v-if="filteredPlots.length > 0" key="0" class="flex flex-col w-full">
                        <transition-group
                            name="custom-classes-transition"
                            enter-active-class="animate__animated animate__fadeInDown10 animate__faster"
                            tag="div"
                            mode="out-in"
                        >
                            <div v-for="g in listGroups" :key="g.id" class="flex flex-col">
                                <abc-accordion
                                    v-if="g.plots.length"
                                    v-model="formsOpen[g.id]"
                                    @input="onAccordionClose()"
                                    :forceUpdate="accordionForceUpdate"
                                    class="accordionOverride"
                                >
                                    <template #title>
                                        <div class="flex gap-4" style="min-width: 0">
                                            <abc-checkbox
                                                v-if="multiplePlotSelection"
                                                is-list
                                                :value="listGroupsSelectedPlots[g.id].length == g.plots.length"
                                                @input="(v) => toggleGroupPlotsSelection(g, v)"
                                            />
                                            <div class="flex flex-col pr-4" style="min-width: 0">
                                                <div
                                                    class="font-bold text-primary-900 accordion-title rounded-none"
                                                    v-b-tooltip.hover.window.ds400
                                                    :title="
                                                        g.description && g.description.length > 20 ? g.description : ''
                                                    "
                                                >
                                                    {{ g.description }}
                                                </div>
                                                <div class="flex leading-none">
                                                    {{ getTotalHa(g.plots) }}
                                                    <div class="ml-2 text-secondary-500">
                                                        {{ g.plots.length }}
                                                        {{ g.plots.length > 1 ? i18n("fields") : i18n("field") }}
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </template>
                                    <template #content>
                                        <div
                                            v-for="e in g.plots"
                                            :key="e.plotCode"
                                            class="single-crop-plan-crop-row"
                                            @mouseover="setDisplaySecondaryCheckbox(e)"
                                            @mouseleave="setDisplaySecondaryCheckbox(null)"
                                            @click="onRowClick(e, $event)"
                                            v-scroll="lastSelected && e.plotCode === lastSelected.plotCode"
                                            :class="{
                                                'single-crop-plan-crop-row-active':
                                                    curPlot && curPlot.plotCode === e.plotCode,
                                                'bg-bg-500':
                                                    curPlots.length && curPlots.some((p) => p.plotCode === e.plotCode),
                                            }"
                                        >
                                            <transition
                                                name="custom-classes-trantition"
                                                enter-active-class="animate__animated animate__fadeInLeft animate__faster"
                                                mode="out-in"
                                            >
                                                <div
                                                    v-if="
                                                        multiplePlotSelection &&
                                                        ((displaySecondaryCheckbox === e.plotCode &&
                                                            curPlot &&
                                                            displaySecondaryCheckbox != curPlot.plotCode) ||
                                                            (curPlot &&
                                                                curPlots.find((p) => p.plotCode === e.plotCode)))
                                                    "
                                                    class="absolute bottom-0 left-0 top-0 z-10 s-cp-checkbox-container flex items-center justify-center"
                                                >
                                                    <div
                                                        @click.stop="onRowCheckboxClick(e)"
                                                        class="cursor-default h-full flex items-center justify-center w-full bg-secondary-100"
                                                        :class="{
                                                            'cursor-not-allowed':
                                                                curPlot && curPlot.plotCode === e.plotCode,
                                                        }"
                                                        style="
                                                            padding-left: 10px;
                                                            padding-right: 10px;
                                                            margin-bottom: -1px;
                                                        "
                                                    >
                                                        <transition
                                                            name="custom-classes-transition"
                                                            enter-active-class="animate__animated animate__fadeIn animate__faster"
                                                            mode="out-in"
                                                        >
                                                            <abc-checkbox
                                                                is-list
                                                                :value="
                                                                    curPlots.find((p) => p.plotCode === e.plotCode) ||
                                                                    (curPlot && curPlot.plotCode === e.plotCode)
                                                                "
                                                            />
                                                        </transition>
                                                    </div>
                                                </div>
                                            </transition>
                                            <div class="single-crop-plan-crop-row-inner">
                                                <div class="flex items-center mr-3 relative">
                                                    <div
                                                        class="w-12 h-12"
                                                        ref="mapWrappers"
                                                        :data-plot-code="e.plotCode"
                                                    >
                                                        <single-cp-map-preview
                                                            v-if="loadedMapPlotCodes.includes(e.plotCode)"
                                                            :plot="e"
                                                        />
                                                    </div>
                                                </div>
                                                <div class="flex flex-col flex-grow" style="min-width: 0">
                                                    <div class="flex w-full justify-between items-baseline">
                                                        <div class="flex flex-wrap items-center">
                                                            <div
                                                                v-if="e.description && showFieldName"
                                                                class="font-semibold truncate mr-2"
                                                                v-b-tooltip.hover.window.ds400
                                                                :title="
                                                                    e.description && e.description.length > 15
                                                                        ? e.description
                                                                        : ''
                                                                "
                                                            >
                                                                {{ e.description }}
                                                            </div>
                                                            <span
                                                                class="fa-stack text-danger-500"
                                                                v-if="e.editability !== 'EDITABLE'"
                                                                v-abc-tooltip="
                                                                    i18n('cannot-edit-plot-geometry-tooltip')
                                                                "
                                                            >
                                                                <em
                                                                    class="fas fa-circle fa-stack-2x text-danger-100"
                                                                ></em>
                                                                <em
                                                                    class="abc-icon abc-icon-pen fa-stack-1x text-label-primary"
                                                                ></em>
                                                                <em
                                                                    class="fal fa-horizontal-rule fa-stack-1x transform rotate-45"
                                                                ></em>
                                                            </span>
                                                            <span
                                                                class="fa-stack text-danger-500"
                                                                v-if="e.editability === 'NOT_EDITABLE'"
                                                                v-abc-tooltip="
                                                                    i18n('cannot-edit-plot-declaration-tooltip')
                                                                "
                                                            >
                                                                <em
                                                                    class="fas fa-circle fa-stack-2x text-danger-100"
                                                                ></em>
                                                                <em
                                                                    class="fal fa-wheat fa-stack-1x text-label-primary"
                                                                ></em>
                                                                <em
                                                                    class="fal fa-horizontal-rule fa-stack-1x transform rotate-45"
                                                                ></em>
                                                            </span>
                                                            <em
                                                                v-if="isWithWarning(e)"
                                                                v-abc-tooltip="i18n('plot-with-warning-tooltip')"
                                                                class="px-1 fad fa-exclamation-circle text-danger-300"
                                                                style="font-size: 27px"
                                                            ></em>
                                                        </div>
                                                        <div class="flex items-baseline" style="margin-top: -2px">
                                                            <span class="font-semibold text-lg pr-1">{{
                                                                formattedArea(e.areaSqm)
                                                            }}</span>
                                                            <span class="text-base lowercase">{{ areaLabel() }}</span>
                                                        </div>
                                                    </div>
                                                    <div class="flex w-full justify-between">
                                                        <div
                                                            v-if="showParcelInfo"
                                                            class="text-label-primary truncate mb-2"
                                                            v-b-tooltip.hover.window.ds400
                                                            :title="
                                                                e.parcelIntersections &&
                                                                e.parcelIntersections.length > 0 &&
                                                                parcelsPiped(e) &&
                                                                parcelsPiped(e).length > 20
                                                                    ? parcelsPiped(e)
                                                                    : ''
                                                            "
                                                        >
                                                            {{ parcelsPiped(e) }}
                                                        </div>
                                                        <div v-else><!-- placeholder --></div>
                                                        <div class="flex text-3xl">
                                                            <!-- ANOMALIES ICONS -->
                                                            <em
                                                                v-if="blockingAnomalies(e).length > 0"
                                                                v-b-popover="getAnomaliesPopover(e, 'blocking')"
                                                                class="text-danger-600 fa-sharp fa-solid fa-circle-xmark ml-1"
                                                            />
                                                            <em
                                                                v-if="warningAnomalies(e).length > 0"
                                                                v-b-popover="getAnomaliesPopover(e, 'warning')"
                                                                class="text-warning-600 fa-sharp fa-solid fa-circle-exclamation ml-1"
                                                            />
                                                        </div>
                                                    </div>
                                                    <template v-if="showLanduseArea">
                                                        <div v-if="e.curLandUses.length == 0" class="w-full">
                                                            <span class="text-label-secondary">
                                                                {{ i18n("no-land-uses") }}
                                                            </span>
                                                        </div>
                                                        <div v-else class="w-full">
                                                            <div
                                                                v-if="e.curLandUses.length > 1"
                                                                class="flex w-full justify-between"
                                                            >
                                                                <div
                                                                    v-b-tooltip.hover.window.ds400
                                                                    :title="i18n('multiple-land-uses')"
                                                                    class="truncate flex flex-col"
                                                                    style="
                                                                        white-space: nowrap;
                                                                        text-overflow: ellipsis;
                                                                        overflow: hidden;
                                                                    "
                                                                >
                                                                    <span class="text-secondary-700">
                                                                        <p>{{ i18n("multiple-land-uses") }}</p>
                                                                    </span>
                                                                </div>
                                                                <div class="flex items-baseline lowercase ml-2">
                                                                    <span style="white-space: nowrap">
                                                                        <span style="padding-right: 1px">{{
                                                                            formattedArea(e.totalUsedAreaSqm)
                                                                        }}</span>
                                                                        {{ areaLabel() }}
                                                                    </span>
                                                                    <span class="ml-1">
                                                                        (<span style="padding-right: 1px">{{
                                                                            formattedPercentage(
                                                                                e.totalUsedAreaPerc,
                                                                                getPercentageDecimalNumber
                                                                            )
                                                                        }}</span
                                                                        >%)
                                                                    </span>
                                                                </div>
                                                            </div>
                                                            <div
                                                                v-else
                                                                v-for="(lu, i) in e.curLandUses"
                                                                :key="i"
                                                                class="flex flex-wrap w-full justify-between"
                                                            >
                                                                <div
                                                                    v-b-tooltip.hover.window.ds400
                                                                    :title="lu.description"
                                                                    class="truncate flex flex-col mr-2"
                                                                    style="
                                                                        white-space: nowrap;
                                                                        text-overflow: ellipsis;
                                                                        overflow: hidden;
                                                                    "
                                                                >
                                                                    <span class="text-secondary-700">
                                                                        <p>{{ lu.description }}</p>
                                                                    </span>
                                                                </div>
                                                                <div
                                                                    v-b-tooltip.hover.window.ds400
                                                                    :title="lu.description"
                                                                    class="flex items-baseline lowercase ml-auto"
                                                                >
                                                                    <span style="white-space: nowrap">
                                                                        <span style="padding-right: 1px">{{
                                                                            formattedArea(lu.areaSqm)
                                                                        }}</span>
                                                                        {{ areaLabel() }}
                                                                    </span>
                                                                    <span class="ml-1">
                                                                        (<span style="padding-right: 1px">{{
                                                                            formattedPercentage(
                                                                                lu.areaPerc,
                                                                                getPercentageDecimalNumber
                                                                            )
                                                                        }}</span
                                                                        >%)
                                                                    </span>
                                                                </div>
                                                            </div>
                                                            <div class="flex w-full justify-between">
                                                                <div class="truncate flex flex-col">
                                                                    <span class="text-secondary-700">
                                                                        <p>{{ i18n("plot-area-remaining") }}</p>
                                                                    </span>
                                                                </div>
                                                                <div class="flex items-baseline lowercase ml-2">
                                                                    <span style="white-space: nowrap">
                                                                        <span style="padding-right: 1px">{{
                                                                            formattedArea(e.freeAreaSqm)
                                                                        }}</span>
                                                                        {{ areaLabel() }}
                                                                    </span>
                                                                    <span class="ml-1">
                                                                        (<span style="padding-right: 1px">{{
                                                                            formattedPercentage(
                                                                                e.freeAreaPerc,
                                                                                getPercentageDecimalNumber
                                                                            )
                                                                        }}</span
                                                                        >%)
                                                                    </span>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </template>
                                                    <template v-else>
                                                        <div class="flex w-full justify-between">
                                                            <div class="truncate flex flex-col">
                                                                <span
                                                                    v-if="e.decls && e.decls.length > 0"
                                                                    class="text-secondary-700"
                                                                    v-b-tooltip.hover.window.ds400
                                                                    :title="
                                                                        e.decls &&
                                                                        e.decls.length > 0 &&
                                                                        declarationsPiped(e) &&
                                                                        declarationsPiped(e).length > 20
                                                                            ? declarationsPiped(e)
                                                                            : ''
                                                                    "
                                                                >
                                                                    <p v-if="isMultipleLandUses(e)">
                                                                        {{ i18n("multiple-land-uses") }}
                                                                    </p>
                                                                    <p v-else>{{ declarationsPiped(e) }}</p>
                                                                </span>
                                                                <span v-else class="text-label-secondary">
                                                                    {{ i18n("no-land-uses") }}
                                                                </span>
                                                            </div>
                                                            <div class="flex items-baseline ml-2">
                                                                <span style="padding-right: 1px">
                                                                    {{ getFieldOccupied(e) }}
                                                                </span>
                                                                <span class="lowercase">%</span>
                                                            </div>
                                                        </div>
                                                    </template>
                                                </div>
                                            </div>
                                        </div>
                                    </template>
                                </abc-accordion>
                            </div>
                        </transition-group>
                    </div>
                    <div v-else-if="filteredPlots.length === 0" class="flex w-full justify-center pt-6" key="1">
                        <div
                            v-if="curCouncil.bigDomainZone"
                            class="font-semibold text-danger-600 uppercase text-sm px-3"
                        >
                            {{ i18n("current-municipality-contains-too-many-plots-warning") }}
                        </div>
                        <abc-no-data-found v-else :text="i18n('no-field-present')" />
                    </div>
                </transition>
            </div>
        </div>

        <!-- PLOT SELECTION COUNTER -->
        <transition
            name="custom-classes-transition"
            enter-active-class="animate__animated animate__fadeIn animate__faster"
            mode="out-in"
        >
            <div
                v-if="curPlots && curPlots.length > 0 && !openAddProductMode"
                class="absolute rounded-full bg-secondary-100 py-2 px-4 mx-auto text-sm mb-2 text-secondary-600 shadow-lg overflow-hidden z-30 flex flex-col"
                style="bottom: 10px; left: calc(50% - 115px)"
            >
                <div class="text-center">
                    <div>
                        <transition
                            name="custom-classes-transition"
                            enter-active-class="animate__animated animate__fadeInDown animate__faster"
                            leave-active-class="animate__animated animate__fadeOutDown animate__faster"
                            mode="out-in"
                        >
                            <span class="inline-block font-bold pr-1" :key="curPlots.length">{{
                                curPlots.length
                            }}</span>
                        </transition>
                        <span>{{ i18n("secondary-plots-selected") }}</span>
                    </div>
                    <div v-if="totalSelectedAreaInSqm !== null">
                        {{ i18n("total-selected-area") }} {{ formattedArea(totalSelectedAreaInSqm) }} {{ areaLabel() }}
                    </div>
                </div>
            </div>
        </transition>

        <!-- CONFIRM REMOVAL MODAL -->
        <abc-modal
            v-if="showConfirmDeletePlot"
            @close="
                () => {
                    (showConfirmDeletePlot = false), (lastEditPlotMode = null);
                }
            "
            is-message
            :additionalStyle="{ 'z-index': 51 }"
        >
            <template #body>
                {{
                    multiplePlotsSelected
                        ? i18n("confirm-removal-of-selected-multiple")
                        : i18n("confirm-removal-of-selected", { field: i18n("selected-field") })
                }}?
            </template>
            <template #footer>
                <abc-button
                    class="mr-2"
                    is-secondary
                    is-outlined
                    @click="
                        () => {
                            (showConfirmDeletePlot = false), (lastEditPlotMode = null);
                        }
                    "
                >
                    <em class="abc-icon abc-icon-arrow-left-round" /> {{ i18n("back") }}
                </abc-button>
                <abc-button @click="confirmDelete" is-danger>
                    <em class="abc-icon abc-icon-trash-bin" /> {{ i18n("remove") }}
                </abc-button>
            </template>
        </abc-modal>

        <!-- CONFIRM FORCE SYNC MODAL -->
        <abc-modal
            v-if="showForceSyncConfirmModal"
            modal-class="w-full md:w-8/12 lg:w-6/12 xxl:w-4/12"
            @close="showForceSyncConfirmModal = false"
            is-message
            force-modal
        >
            <template #body>
                <div class="flex flex-col w-full">
                    {{ i18n("force-massive-sync") }}
                </div>
            </template>
            <template #footer>
                <div class="flex">
                    <abc-button class="ml-2" is-secondary is-outlined @click="showForceSyncConfirmModal = false">
                        <em class="abc-icon abc-icon-arrow-left-round" /> {{ i18n("back") }}
                    </abc-button>
                    <abc-button class="ml-2" is-danger @click="confirmForceMassiveSync">
                        {{ i18n("confirm") }}
                    </abc-button>
                </div>
            </template>
        </abc-modal>

        <!-- OVERLAPS MODAL -->
        <cadastral-parcels-overlaps-modal v-if="showOverlapsModal" @close="showOverlapsModal = false" />

        <!-- CONFIRM RESTORE MODAL -->
        <abc-modal
            v-if="showConfirmRestorePlot"
            @close="showConfirmRestorePlot = false"
            is-message
            :additionalStyle="{ 'z-index': 51 }"
        >
            <template #body>
                <p v-if="flPlotsCanBeRestored">{{ restoreMessage }}?</p>
                <strong v-else class="text-danger-500">
                    {{ i18n("error-different-restore-point-in-time") }}
                </strong>
            </template>
            <template #footer>
                <abc-button class="mr-2" is-secondary is-outlined @click="showConfirmRestorePlot = false">
                    <em class="abc-icon abc-icon-arrow-left-round" /> {{ i18n("back") }}
                </abc-button>
                <abc-button v-if="flPlotsCanBeRestored" @click="restoreElement()" is-danger>
                    <em class="abc-icon abc-icon-arrow-circle" /> {{ i18n("restore") }}
                </abc-button>
            </template>
        </abc-modal>

        <!-- CONFIRM RESTORE FIRST VERSION MODAL -->
        <abc-modal
            v-if="showConfirmRestoreFirstVersionPlot"
            @close="showConfirmRestoreFirstVersionPlot = false"
            is-message
            :additionalStyle="{ 'z-index': 51 }"
        >
            <template #body>
                <p>{{ i18n("confirm-restore-field-to-first-version") }}?</p>
            </template>
            <template #footer>
                <abc-button class="mr-2" is-secondary is-outlined @click="showConfirmRestoreFirstVersionPlot = false">
                    <em class="abc-icon abc-icon-arrow-left-round" /> {{ i18n("back") }}
                </abc-button>
                <abc-button @click="restoreFirstVersion()" is-danger>
                    <em class="fa-light fa-repeat-1 mr-1" /> {{ i18n("restore-first-version") }}
                </abc-button>
            </template>
        </abc-modal>

        <abc-modal v-if="showConfirmCopy" @close="showConfirmCopy = false" is-message>
            <template #body>
                <span>
                    {{ i18n("confirm-copy-of-declarations-1", { startDate: copyStartDate, targetDate: copyTargetDate })
                    }}<br />{{ i18n("confirm-copy-of-declarations-2") }}
                </span>
            </template>
            <template #footer>
                <abc-button class="mr-2" is-secondary is-outlined @click="showConfirmCopy = false">
                    <em class="abc-icon abc-icon-arrow-left-round" /> {{ i18n("back") }}
                </abc-button>
                <abc-button @click="copyDeclarationsAtDate()" is-danger>
                    <em class="abc-icon abc-icon-level-add" /> {{ i18n("copy-declarations") }}
                </abc-button>
            </template>
        </abc-modal>

        <swap-landuses-modal
            v-if="openSwapModal"
            @back="openSwapModal = false"
            @swap="
                () => {
                    openSwapModal = false;
                    forceReset();
                }
            "
            :swappable-landuses="swappableLanduses"
        />

        <crop-plan-can-not-edit-modal-warning v-model="showWarningCannotEdit" :editabilityCheck="'!EDITABLE'" />
        <crop-plan-post-edit-messages-modal :messages="validationMessages" @proceedAnyWay="deleteElement(true)" />
        <crop-plan-post-edit-messages-modal
            :messages="restoreValidationMessages"
            @proceedAnyWay="restoreElement(true)"
        />

        <versions-modal v-if="enablePublicationsList && showVersionsModal" @close="showVersionsModal = false" />
        <!-- COPY DECLARATIONS FROM VERSION -->
        <copy-campaign-modal
            v-if="enablePublicationsList && showCopyDeclarationsFromVersionModal"
            @close="showCopyDeclarationsFromVersionModal = false"
        />

        <!-- SHOW ALL PESTICIDES -->
        <modal-view v-model="openShowAllPesticides">
            <single-cp-pesticides @close-current-view="onCloseModal()" />
        </modal-view>

        <!-- SHOW ALL PEST -->
        <modal-view v-model="openShowAllPEST">
            <single-cp-pests @close-current-view="onCloseModalPEST()" />
        </modal-view>

        <app-loading-modal v-if="saving" />
        <!-- PRINT MODAL -->
        <print-modal v-if="showPrintModal" @close="showPrintModal = false" />
    </tile>
</template>

<script lang="ts">
import { FromStore, ToastOptions } from "@abaco/web-common/src/app";
import { EmptyNextPagedResults, infiniteNextLoad, NextPagedResults } from "@abaco/web-common/src/Paging";
import { BPopover, VBPopover, VBTooltip } from "bootstrap-vue";
import cloneDeep from "lodash/cloneDeep";
import { TranslateResult } from "vue-i18n";
import { Component, Inject, Mixins, Ref, Watch } from "vue-property-decorator";
import SingleCropPlanModule, { MODULE_ID } from "../..";
import { isGCP } from "../../../../../src/main";
import { DEFAULT_PERCENTAGE_DECIMAL_NUMBER, VINEYARD_FORM } from "../../../../shared/constants";
import {
    convertToDate,
    isAllEqual,
    isMacOs,
    isNullish,
    notEmpty,
    removeDuplicatesDeep,
} from "../../api/Utils";
import AreaUtils from "../../mixins/AreaUtils";
import CanEditCheckAndExecute from "../../mixins/CanEditCheckAndExecute";
import DateUtils from "../../mixins/DateUtils";
import { Business } from "../../models/Business";
import { Council, SubdomainZone } from "../../models/Council";
import { FunctionCode } from "../../models/CropPlan";
import { CadastralData, CadastralOverlap, CropPlanArea, ParcelData, TimelineSection } from "../../models/Declaration";
import {
    Anomaly,
    EditPlotMode,
    EmptyPlotFilter,
    LandCoverFilterIn,
    LandUse,
    SwappableLandUse,
    Parcel,
    Plot,
    PlotDeclaration,
    PlotFilter,
    PlotResponseDiff,
    PlotStyleOverride,
} from "../../models/Plot";
import { ValidationMessage } from "../../models/Utils";
import { Version } from "../../models/Version";
import { createCrossIconCanvasPattern, makeStrokePattern } from "../mapComponent/EditStyle";
import SingleCpMapPreview from "../mapComponent/SingleCPMapPreview.vue";
import AppLoadingModal from "../private/appLoadingModal.vue";
import CadastralParcelsOverlapsModal from "../private/cadastralParcelsOverlapsModal.vue";
import CropPlanCanNotEditModalWarning from "../private/cropPlanCanNotEditModalWarning.vue";
import CropPlanPostEditMessagesModal from "../private/cropPlanPostEditMessagesModal.vue";
import CropPlanProgressCard from "../private/cropPlanProgressCard.vue";
import CropPlanPublish from "../private/cropPlanPublish.vue";
import PrintModal from "../private/printModal.vue";
import VersionsModal from "../private/versionsModal.vue";
import SingleCpCadParcelList from "./SingleCpCadParcelList.vue";
import SingleCpParcelInfo from "./SingleCpParcelInfo.vue";
import SingleCpParcelList from "./SingleCpParcelList.vue";
import SingleCpParcelNotesEdit from "./SingleCpParcelNotesEdit.vue";
import { Debounce } from "vue-debounce-decorator";
import { isEqual } from "lodash";
import SSOModule from "@abaco/sso-web-module/src/abaco-module";
import CopyCampaignModal from "../private/copyCampaignModal.vue";
import { isSCP } from "../../../../../src/main";
import { PermanentCropField } from "../../models/PermanentCropForm";

type SortableField = "parcelDescription" | "parcelCode" | "plotCode" | "toDate";

interface PlotListItemLanduse {
    code: string;
    description: string;
    areaSqm: number;
    areaPerc: number;
}
interface PlotListItem extends Plot {
    curLandUses: PlotListItemLanduse[];
    freeAreaSqm: number;
    freeAreaPerc: number;
}

@Component({
    directives: {
        "b-tooltip": VBTooltip,
        "b-popover": VBPopover,
        scroll: {
            inserted(el, binding) {
                if (binding.value) {
                    el.scrollIntoView({ block: "nearest" });
                }
            },
            componentUpdated(el, binding) {
                if (binding.value) {
                    el.scrollIntoView({ block: "nearest" });
                }
            },
        },
    },
    components: {
        BPopover,
        CropPlanProgressCard,
        CropPlanPublish,
        SingleCpMapPreview,
        CropPlanCanNotEditModalWarning,
        CropPlanPostEditMessagesModal,
        VersionsModal,
        CadastralParcelsOverlapsModal,
        SingleCpParcelList,
        SingleCpCadParcelList,
        SingleCpParcelInfo,
        AppLoadingModal,
        PrintModal,
        SingleCpParcelNotesEdit,
        CopyCampaignModal,
    },
})
export default class SingleCpPlotList extends Mixins(DateUtils, AreaUtils, CanEditCheckAndExecute) {
    @Inject() i18n!: (key: string, values?: unknown) => TranslateResult;
    @Inject() toast!: (message: string, options?: ToastOptions) => TranslateResult;
    @Inject(MODULE_ID) singleCropPlanModule!: SingleCropPlanModule;
    @Inject(SSOModule.MODULE_ID) ssoWebModule!: SSOModule;

    @FromStore(MODULE_ID) business!: Business;
    @FromStore(MODULE_ID) curCouncil!: Council | null;
    @FromStore(MODULE_ID) curVersion!: Version | null;
    @FromStore(MODULE_ID) curPointInTime!: Date;
    @FromStore(MODULE_ID) plots!: Plot[];
    @FromStore(MODULE_ID) plotsStyleOverride!: PlotStyleOverride[];
    @FromStore(MODULE_ID) editPlotMode!: EditPlotMode;
    @FromStore(MODULE_ID) hideFieldName!: boolean;
    @FromStore(MODULE_ID) showParcelName!: boolean;
    @FromStore(MODULE_ID) isCurPlotWithWarning!: boolean;
    @FromStore(MODULE_ID) selectorStep!: string;
    @FromStore(MODULE_ID) toolbuttonsEnabled!: boolean;
    @FromStore(MODULE_ID) showNavBar!: boolean;
    @FromStore(MODULE_ID) multiplePlotSelection!: boolean;
    @FromStore(MODULE_ID) openAddProductMode!: boolean;
    @FromStore(MODULE_ID) cadastralData!: CadastralData[] | null;
    @FromStore(MODULE_ID) parcelData!: ParcelData[] | null;
    @FromStore(MODULE_ID) curCadastralData!: CadastralData | null;
    @FromStore(MODULE_ID) curCadastralOverlapData!: CadastralOverlap | null;
    @FromStore(MODULE_ID) curParcelData!: ParcelData | null;
    @FromStore(MODULE_ID) showConfirmDeletePlot!: boolean;
    @FromStore(MODULE_ID) showConfirmRestorePlot!: boolean;
    @FromStore(MODULE_ID) showConfirmRestoreFirstVersionPlot!: boolean;
    @FromStore(MODULE_ID) blockMapPlotSelection!: boolean;
    @FromStore(MODULE_ID) flShowCropPlanProgressBar!: boolean;
    @FromStore(MODULE_ID) openAddPestMode!: boolean;
    @FromStore(MODULE_ID) plotsForceReload!: number;
    @FromStore(MODULE_ID) curTimelineSection!: TimelineSection | null;
    @FromStore(MODULE_ID) curDisabledFunctions!: FunctionCode[];
    @FromStore(MODULE_ID) openParcelTile!: boolean;
    @FromStore(MODULE_ID) forceSync!: number;
    @FromStore(MODULE_ID) flIgnorePreviousSyncs!: boolean;
    @FromStore(MODULE_ID) plotCodeToSelect!: string | null;
    @FromStore(MODULE_ID) plotCodesToSelect!: string[];
    @FromStore(MODULE_ID) filteredPlots!: Plot[];
    @FromStore(MODULE_ID) forceStartEditing!: number;
    @FromStore(MODULE_ID) forceStartDrawing!: number;
    @FromStore(MODULE_ID) forceApplyFilters!: number;
    @FromStore(MODULE_ID) subdomainZone!: SubdomainZone;
    @FromStore(MODULE_ID) curCropPlanArea!: CropPlanArea;
    @FromStore(MODULE_ID) savedFormsTypes!: Record<string, PermanentCropField[]>;

    @Ref() readonly mapWrappers!: HTMLDivElement[];

    private loading = false;
    private saving = false;
    private plotsPage: NextPagedResults<Plot> = new EmptyNextPagedResults();

    private filter: PlotFilter = EmptyPlotFilter();
    private openEditTile = false;
    private openInfoTile = false;
    private showConfirmCopy = false;
    private showFilterPanel = false;
    private showOrderPanel = false;
    private openSwapModal = false;
    private editAuth = true;
    private deleteAuth = !this.envConfig.hideDeletePlot || false;

    private listOrder: "land_use" | "land_cover" | "name" | "parcel" | null = "land_use";
    private searchLandUse: string | null = null;
    private searchLandCover: string | null = null;

    private curLandUse: LandUse | null = null;
    private curLandCover: Parcel | null = null;

    private disableListAutoscroll = false;
    private lastSelected: Plot | null = null;
    private displaySecondaryCheckbox: string | null = null;
    private validationMessages: ValidationMessage[] = [];
    private restoreValidationMessages: ValidationMessage[] = [];

    private landCoverFilters: LandCoverFilterIn[] = [];
    private landCoverFilterStatus: Record<string, boolean> = {};
    private activeLandCoverFilters: string[] = [];
    private landCoverWithWarning: string[] = [];

    private anomaliesFilters: Anomaly[] = [];
    private anomaliesOnlyEnabled = false;
    private activeAnomalyFilter: Anomaly | null = null;
    private searchAnomaly: string | null = null;
    private selectedInfo = "crop-plan";

    private openShowAllPesticides = false;
    private openShowAllPEST = false;
    private formsOpen: Record<string, boolean> = {};
    private searchSheet = "";
    private searchParcel = "";
    private showOverlapsModal = false;
    private showVersionsModal = false;

    private searchParcelAnomaly: string | null = null;
    private selectedParcelAnomaly: Anomaly | null = null;

    private showPrintModal = false;

    private accordionForceUpdate = 0;
    private scrollUpdate = 0;

    private loadedMapPlotCodes: string[] = [];
    private minimapDelayTimer: number | undefined;

    private cropPlanTotalArea = 0;
    private cropPlanTotalDeclaredArea = 0;
    private cropPlanTotalAreaPerc = 0;
    private domainTotalArea = 0;
    private domainTotalDeclaredArea = 0;
    private domainTotalAreaPerc = 0;
    private showForceSyncConfirmModal = false;
    private showCopyDeclarationsFromVersionModal = false;
    private canForceSync = false;
    private canDeleteMultiplePlotsFunctionEnabled = false;

    async mounted() {
        await this.updatePlots();
        await this.initLandCoverFilters();
        await this.initFormsTypes();
        this.canForceSync = await this.ssoWebModule.isFunctionEnabled("CRPL", "CAN_FORCE_SYNC");

        this.canDeleteMultiplePlotsFunctionEnabled =
            (await this.ssoWebModule.isFunctionEnabled("CRPL", "CAN_DELETE_PLOTS")) &&
            (await this.ssoWebModule.isFunctionEnabled("CRPL", "EDITOR"));
    }

    private get getEditPlotMode() {
        return EditPlotMode;
    }

    private get getPercentageDecimalNumber() {
        return this.curConfiguration?.DECLS_PERCENTAGE_NUM_OF_DECIMALS
            ? this.curConfiguration?.DECLS_PERCENTAGE_NUM_OF_DECIMALS
            : DEFAULT_PERCENTAGE_DECIMAL_NUMBER;
    }

    private get searchResults() {
        if (this.selectedInfo === "cadparcels" && this.cadastralData) {
            return this.cadastralData
                .filter((it) => it.sectorBlock.includes(this.searchSheet))
                .filter((it) => it.parcel.includes(this.searchParcel));
        } else if (this.selectedInfo === "parcels" && this.parcelData) {
            const parcelResults = this.parcelData
                .filter((it) => it.sectorBlock.includes(this.searchSheet))
                .filter((it) => (it.description ? it.description.includes(this.searchParcel) : false));
            if (this.anomaliesOnlyEnabled)
                return parcelResults
                    .filter((it) => it.anomalies.length > 0)
                    .filter((it) =>
                        it.anomalies.some((a) =>
                            a.errorCode.includes(
                                this.selectedParcelAnomaly?.errorCode ? this.selectedParcelAnomaly.errorCode : ""
                            )
                        )
                    );
            return parcelResults;
        }
        return [];
    }

    private get enablePesticides(): boolean {
        return this.curConfiguration?.ENABLE_PESTICIDES && this.curConfiguration.ENABLE_PESTICIDES === "TRUE"
            ? true
            : false;
    }

    private get enablePest(): boolean {
        return this.curConfiguration?.ENABLE_PESTS && this.curConfiguration.ENABLE_PESTS === "TRUE" ? true : false;
    }

    private get enablePublicationsList(): boolean {
        return this.curConfiguration?.ENABLE_PUBLICATIONS_LIST &&
            this.curConfiguration.ENABLE_PUBLICATIONS_LIST === "TRUE"
            ? true
            : false;
    }

    private get showLanduseArea() {
        return this.curConfiguration?.SHOW_DECLS_AREA_IN_PLOTS_LIST &&
            this.curConfiguration?.SHOW_DECLS_AREA_IN_PLOTS_LIST === "TRUE"
            ? true
            : false;
    }

    private get orders(): { id: string; description: string }[] {
        const res = [
            { id: "land_use", description: this.i18n("land-use-order").toString() },
            { id: "land_cover", description: this.i18n("land-cover-order").toString() },
        ];
        if (
            this.curConfiguration &&
            (this.curConfiguration.HIDE_PARCELS === "FALSE" || this.curConfiguration.HIDE_PARCELS == undefined)
        )
            res.push({ id: "parcel", description: this.i18n("parcel-s").toString() });
        if (!this.hideFieldName) {
            res.push({ id: "name", description: this.i18n("name").toString() });
        }
        return res;
    }

    private get showParcelInfo() {
        return this.curConfiguration?.HIDE_PARCELS === "TRUE" ? false : true;
    }

    private get isReadOnly() {
        return this.curCropPlan && this.curCropPlan.readOnly;
    }

    private get isCanAddPlots() {
        return this.curCropPlan && !this.curCropPlan.readOnly && this.curCropPlan.canAddPlots;
    }

    private get isCropPlanPublishShown() {
        return this.curConfiguration?.DISABLE_PUBLISH_CROP_PLAN === "TRUE" ? false : this.toolbuttonsEnabled;
    }

    private get isSwapEnabled() {
        if (!this.curConfiguration) return false;
        return this.curConfiguration.ENABLE_DECLARATIONS_SWAP === "TRUE";
    }

    private get showParcelAnomaliesFilter() {
        return !!this.parcelData && this.parcelData.some((it) => it.anomalies.length > 0);
    }

    private get filteredParcelAnomaly() {
        if (!this.parcelData) return [];

        const allAnomalies: Anomaly[] = [];

        for (const p of this.parcelData) {
            for (const parcelAnomaly of p.anomalies)
                if (!allAnomalies.find((anomaly) => anomaly.errorCode === parcelAnomaly.errorCode))
                    allAnomalies.push(parcelAnomaly);
        }

        if (this.searchParcelAnomaly) {
            return allAnomalies
                .filter((anomaly) =>
                    (anomaly.errorDescription ? anomaly.errorDescription : anomaly.errorCode)
                        .toString()
                        .toLowerCase()
                        .includes(this.searchParcelAnomaly ? this.searchParcelAnomaly.toLowerCase() : "")
                )
                .sort((a, b) => a.errorCode.localeCompare(b.errorCode));
        }

        return allAnomalies.sort((a, b) => a.errorCode.localeCompare(b.errorCode));
    }

    private get showFieldName() {
        if (this.curConfiguration && this.curConfiguration?.HIDE_PLOTS_NAMES) {
            return this.curConfiguration?.HIDE_PLOTS_NAMES !== "TRUE";
        }
        return !this.hideFieldName;
    }

    private get showEditPlotData() {
        return !this.hideFieldName || this.curConfiguration?.HIDE_PLOTS_NOTES === "FALSE";
    }

    private get multiplePlotsSelected() {
        return this.curPlot && this.curPlots.length > 0;
    }

    private get totalSelectedAreaInSqm(): number | null {
        if (!this.curPlot) return null;

        return [this.curPlot.areaSqm, ...this.curPlots.map((plot) => plot.areaSqm)].reduce(
            (prev, curr) => prev + curr,
            0
        );
    }

    private getisGCP() {
        return isGCP;
    }

    @Watch("anomaliesOnlyEnabled")
    private clearSelectedAnomalies() {
        this.selectedParcelAnomaly = null;
        this.activeAnomalyFilter = null;
    }

    @Watch("curPlot")
    async onCurPlot() {
        if (!this.disableListAutoscroll) this.lastSelected = this.curPlot;
        if (this.curPlot) {
            this.isCurPlotWithWarning = this.isWithWarning(this.curPlot);
        } else {
            this.isCurPlotWithWarning = false;
        }
    }

    @Watch("curPlots")
    onCurPlots(newPlots: Plot[], oldPlots: Plot[]) {
        if (this.curPlots.length > 0 && newPlots.length > oldPlots.length && !this.disableListAutoscroll) {
            this.lastSelected = this.curPlots[this.curPlots.length - 1];
        }
        // deselect timeline selection on secondary plot select
        if (newPlots.length && this.curTimelineSection) {
            this.curTimelineSection = null;
        }
    }

    @Watch("curPointInTime")
    private updateLandUses(newVal: Date | null, oldVal: Date | null) {
        if (isEqual(newVal, oldVal)) return false;
        this.curLandUse = null;
        this.searchLandUse = null;
        this.curLandCover = null;
        this.searchLandCover = null;
    }

    @Watch("business")
    @Watch("curCouncil")
    @Watch("curCropPlan.cropPlanId")
    @Watch("plotsForceReload")
    private async updatePlots() {
        //hold selected plot after reload
        this.plotsPage = new EmptyNextPagedResults();
        this.plots = [];
        this.curPlot = null;
        this.curPlots = [];
        this.openEditTile = false;
        this.openInfoTile = false;
        this.curLandUse = null;
        this.searchLandUse = null;
        this.curLandCover = null;
        this.searchLandCover = null;
        this.filter = EmptyPlotFilter();
        await this.loadPlots(true);
        await this.clearAndGetAllParcels();
    }

    @Watch("showConfirmDeletePlot")
    private onConfirmDelete() {
        this.editPlotMode = this.showConfirmDeletePlot ? EditPlotMode.DELETING : EditPlotMode.NOT_SELECTED;
    }

    @Watch("showConfirmRestorePlot")
    private onConfirmRestore() {
        this.editPlotMode = this.showConfirmRestorePlot ? EditPlotMode.RESTORING : EditPlotMode.NOT_SELECTED;
    }

    @Watch("editPlotMode")
    private onEditPlotModeUpdate() {
        if (this.showConfirmDeletePlot && this.editPlotMode !== EditPlotMode.DELETING)
            this.showConfirmDeletePlot = false;
        if (this.showConfirmRestorePlot && this.editPlotMode !== EditPlotMode.RESTORING)
            this.showConfirmRestorePlot = false;
    }

    @Watch("listGroups")
    private updateFormsOpen() {
        if (this.listGroups.length === 0) return;

        for (const group of this.listGroups) {
            const haveCurrKey = Object.keys(this.formsOpen).some((it) => it === group.id);
            if (!haveCurrKey) {
                this.formsOpen[group.id] = true;
            }
        }
    }

    @Watch("curPlot")
    @Watch("curPlots")
    private openCollapsedAccordionOnSelection() {
        const plotCodes: string[] = this.curPlots.map((p) => p.plotCode);
        if (this.curPlot) plotCodes.push(this.curPlot.plotCode);
        if (!plotCodes.length) return;
        //
        const closedGids = Object.keys(this.formsOpen).filter((gid) => !this.formsOpen[gid]);
        this.listGroups.forEach((g) => {
            if (closedGids.includes(g.id) && g.plots.some((p) => plotCodes.includes(p.plotCode)))
                this.formsOpen[g.id] = true;
        });
    }

    @Watch("selectedInfo")
    private async clearAndGetAllParcels() {
        this.resetFilter();

        this.blockMapPlotSelection = this.selectedInfo !== "crop-plan";
        if (this.selectedInfo !== "crop-plan") {
            this.curPlot = null;
            this.curPlots = [];
        }

        if (this.selectedInfo === "cadparcels") {
            await this.loadCadastral();
        } else {
            this.cadastralData = null;
            this.curCadastralData = null;
            this.curCadastralOverlapData = null;
        }

        if (this.selectedInfo === "parcels") {
            await this.loadParcels();
        } else {
            this.parcelData = null;
            this.curParcelData = null;
        }
    }

    private getParcelDescription() {
        return this.curCropPlan?.cropPlanTypeCode === "CROPPLAN_2025"
            ? this.i18n("parcels-list-island")
            : this.i18n("parcels-list-vinealign");
    }
    private get isFilterActive() {
        return (
            !!this.filter.search ||
            !!this.curLandUse ||
            !!this.curLandCover ||
            !!this.searchSheet ||
            !!this.searchParcel ||
            !!this.anomaliesOnlyEnabled
        );
    }

    private get flRestoreAtCampagnDate() {
        return (
            this.curConfiguration?.RESTORE_PLOTS_AT_CAMPAIGN_START_DATE === "TRUE" &&
            !!this.cropPlanDates?.campaignStartDate
        );
    }

    private get restoreMessage() {
        if (
            this.flRestoreAtCampagnDate &&
            this.cropPlanDates.campaignStartDate &&
            convertToDate(this.cropPlanDates.campaignStartDate) != null
        ) {
            const campaignStartDate = this.formattedDate(convertToDate(this.cropPlanDates.campaignStartDate)!);
            let message = "";
            if (this.curPlots.length) {
                message =
                    this.curConfiguration?.RESTORE_PLOTS_PROPAGATING_BEHAVIOUR !== "TRUE"
                        ? "confirm-restore-of-selected-fields-at-campaign-start-date"
                        : "confirm-restore-of-selected-fields-at-campaign-start-date-propagating-behaviour";
            } else {
                message =
                    this.curConfiguration?.RESTORE_PLOTS_PROPAGATING_BEHAVIOUR !== "TRUE"
                        ? "confirm-restore-of-selected-at-campaign-start-date"
                        : "confirm-restore-of-selected-at-campaign-start-date-propagating-behaviour";
            }
            return this.i18n(message, { date: campaignStartDate }).toString();
        }
        return this.curPlots.length
            ? this.i18n("confirm-restore-of-selected-fields")
            : this.i18n("confirm-restore-of-selected", { field: this.i18n("selected-field") });
    }

    private get flPlotsCanBeRestored() {
        if (this.curConfiguration?.RESTORE_PLOTS_AT_CAMPAIGN_START_DATE !== "TRUE" || !this.curPlots.length)
            return true; // means than user is trying to restore a single plot so same fromDate check is non mandatory
        if (
            this.curPlot &&
            this.curPlots.length &&
            [...new Set([this.curPlot, ...this.curPlots].map((p) => this.formattedDate(p.fromDate)))].length > 1
        )
            // check if curPlots have the same fromDate
            return false;
        return true;
    }

    private get filteredAnomalies() {
        return this.anomaliesFilters
            .filter((anomaly) =>
                this.searchAnomaly
                    ? (anomaly.errorDescription ? anomaly.errorDescription : anomaly.errorCode)
                          .toString()
                          .toLowerCase()
                          .includes(this.searchAnomaly.toLowerCase())
                    : true
            )
            .sort((a, b) => a.errorCode.localeCompare(b.errorCode));
    }

    private onCloseModal() {
        // this.openAddProductTile = false;
        this.openAddProductMode = false;
    }

    private onCloseModalPEST() {
        this.openAddPestMode = false;
    }

    private updatePlotDescr(editedPlot: Plot) {
        const tempPlots = [...this.plots];
        const tempPlotIndex = tempPlots.findIndex((p) => p.plotCode === editedPlot.plotCode);
        tempPlots[tempPlotIndex] = editedPlot;
        this.plots = tempPlots;
        this.curPlot = this.plots.find((p) => p.plotCode === this.curPlot?.plotCode) || null;
        this.curPlots = this.plots.filter((p) => this.curPlots.map((cp) => cp.plotCode).includes(p.plotCode));
        this.flCurCorpPlanChangesPending = true;
        this.openEditTile = false;
        this.openParcelTile = false;
        this.accordionForceUpdate++;
    }

    private updatePlot(editedPlot: Plot) {
        const tempPlots = [...this.plots];
        const tempPlotIndex = tempPlots.findIndex((p) => p.plotCode === editedPlot.plotCode);
        tempPlots[tempPlotIndex] = editedPlot;
        this.plots = tempPlots;
        this.curPlot = this.plots.find((p) => p.plotCode === this.curPlot?.plotCode) || null;
        this.curPlots = this.plots.filter((p) => this.curPlots.map((cp) => cp.plotCode).includes(p.plotCode));
        this.flCurCorpPlanChangesPending = true;
        this.openParcelTile = false;
    }

    private updatePlotsAfterEdit(diff: PlotResponseDiff) {
        const tempPlots = this.plots
            .filter((p) => !diff.deleted?.includes(p.plotCode))
            .map((p) => {
                const updatedPlot = diff.updated?.find((up) => up.plotCode === p.plotCode);
                return updatedPlot ? updatedPlot : p;
            });
        if (diff.added) {
            tempPlots.push(...diff.added);
        }
        this.plots = tempPlots;
        this.curPlot = this.plots.find((p) => p.plotCode === this.curPlot?.plotCode) || null;
        this.curPlots = this.plots.filter((p) => this.curPlots.map((cp) => cp.plotCode).includes(p.plotCode));
        this.flCurCorpPlanChangesPending = true;
        this.openEditTile = false;
    }

    private resetFilter() {
        this.searchSheet = "";
        this.searchParcel = "";
        this.curLandUse = null;
        this.searchLandUse = null;
        this.curLandCover = null;
        this.searchLandCover = null;
        this.activeAnomalyFilter = null;
        this.selectedParcelAnomaly = null;
        this.anomaliesOnlyEnabled = false;
        this.filter = EmptyPlotFilter();
        this.landCoverFilters.forEach((l) => (this.landCoverFilterStatus[l.landCoverDescription] = l.enabledByDefault));

        this.activeLandCoverFilters = this.landCoverFilters
            .filter((l) => l.enabledByDefault)
            .reduce((res: string[], cur: LandCoverFilterIn) => {
                return [...res, ...cur.filterLandCoverCodes.map((c) => c.landCoverCode)];
            }, []);

        this.filteredPlots = this.notAppliedFilteredPlots;
        this.accordionForceUpdate++; // to resize accordions height
        this.showFilterPanel = false;
    }

    private async loadPlots(showLoading: boolean) {
        if (!this.curPointInTime && !this.business && !this.curCouncil && !this.curCropPlan) {
            return false;
        }
        this.loading = true;
        const newPage = await infiniteNextLoad(
            () =>
                this.curCropPlan && this.curCouncil
                    ? this.singleCropPlanModule.plotApi.getAllPlots(
                          this.business.businessId,
                          this.curCropPlan.cropPlanId,
                          this.curCouncil.domainZoneId,
                          this.curPointInTime,
                          this.curVersion ? this.curVersion.version : null,
                          this.curCouncil.bigDomainZone ? this.subdomainZone.id : undefined
                      )
                    : new Promise<NextPagedResults<Plot>>(() => []),
            this.plotsPage
        );
        if (newPage) {
            this.plotsPage = newPage;
            this.plots = this.plotsPage.records;
            for (const plot of this.plots) {
                const plotAnomalies = this.getAnomaliesRelatedToPlot(plot);
                for (const plotAnomaly of plotAnomalies)
                    if (!this.anomaliesFilters.find((anomaly) => anomaly.errorCode === plotAnomaly.errorCode))
                        this.anomaliesFilters.push(plotAnomaly);
            }
            if (this.plotCodeToSelect && this.plots.find((e) => e.plotCode === this.plotCodeToSelect)) {
                this.curPlot = this.plots.find((e) => e.plotCode === this.plotCodeToSelect) ?? null;
            }
            if (this.plotCodesToSelect && this.plots.filter((p) => this.plotCodesToSelect.includes(p.plotCode)).length) {
                this.curPlots = this.plots.filter((p) => this.plotCodesToSelect.includes(p.plotCode));
            }
            this.plotCodeToSelect = null;
            this.plotCodesToSelect = [];
        }
        if (showLoading) {
            this.loading = false;
        }
    }

    private getAnomaliesRelatedToPlot(plot: Plot): Anomaly[] {
        const plotRelatedAnomalies: Anomaly[] = [];
        for (const anomaly of plot.anomalies) {
            if (!plotRelatedAnomalies.find((storedAnomaly) => storedAnomaly.errorCode == anomaly.errorCode))
                plotRelatedAnomalies.push(anomaly);
        }
        for (const declaration of plot.decls) {
            for (const declarationAnomaly of declaration.anomalies) {
                if (
                    !plotRelatedAnomalies.find(
                        (storedAnomaly) => storedAnomaly.errorCode == declarationAnomaly.errorCode
                    )
                )
                    plotRelatedAnomalies.push(declarationAnomaly);
            }
        }

        for (const parcel of plot.parcelIntersections) {
            if (!parcel.anomalies) continue;
            for (const parcelAnomaly of parcel.anomalies) {
                if (!plotRelatedAnomalies.find((storedAnomaly) => storedAnomaly.errorCode == parcelAnomaly.errorCode))
                    plotRelatedAnomalies.push(parcelAnomaly);
            }
        }

        return plotRelatedAnomalies;
    }

    private checkAnomalyPresenceInPlot(plot: Plot, anomaly_code: string): boolean {
        for (const anomaly of plot.anomalies) {
            if (anomaly.errorCode === anomaly_code) return true;
        }
        for (const declaration of plot.decls) {
            for (const declarationAnomaly of declaration.anomalies) {
                if (declarationAnomaly.errorCode === anomaly_code) return true;
            }
        }
        for (const parcel of plot.parcelIntersections) {
            if (!parcel.anomalies) continue;
            for (const parcelAnomaly of parcel.anomalies) {
                if (parcelAnomaly.errorCode === anomaly_code) return true;
            }
        }
        return false;
    }

    private updateActiveLandCoverFilter(value: boolean, filter: string) {
        this.landCoverFilterStatus[filter] = value;
        const activeFilters = Object.entries(this.landCoverFilterStatus)
            .filter((lfs) => lfs[1])
            .map((keyValue) => keyValue[0]);
        this.activeLandCoverFilters = activeFilters.reduce((res: string[], cur: string) => {
            const landCoverFilter = this.landCoverFilters.find((l) => l.landCoverDescription === cur);
            if (landCoverFilter) return [...res, ...landCoverFilter.filterLandCoverCodes.map((lc) => lc.landCoverCode)];
            else return [...res];
        }, []);
    }

    private get notAppliedFilteredPlots(): Plot[] {
        let filtered: Plot[] = cloneDeep(this.plots);
        if (this.curLandUse && this.curLandUse.code === "none") {
            filtered = filtered.filter((e) => e.decls.length === 0);
        } else if (this.curLandUse) {
            filtered = filtered.filter((e) =>
                e.decls.find((d) => this.curLandUse && d.landuse.code === this.curLandUse.code)
            );
        }
        if (this.curLandCover && isNullish(this.curLandCover.landCoverCode)) {
            filtered = filtered.filter(
                (e) =>
                    !e.parcelIntersections ||
                    (e.parcelIntersections && e.parcelIntersections.length === 0) ||
                    (e.parcelIntersections.length === 1 && !e.parcelIntersections[0].landCoverCode)
            );
        } else if (this.curLandCover) {
            filtered = filtered.filter((e) =>
                e.parcelIntersections.find(
                    (p) => this.curLandCover && p.landCoverCode === this.curLandCover.landCoverCode
                )
            );
        }
        if (this.filter.search) {
            const filter = this.filter.search.toLowerCase();
            filtered = filtered.filter(
                (e) => this.i18n(this.getPlotSearchString(e)).toString().toLowerCase().indexOf(filter) > -1
            );
        }
        if (this.landCoverFilters && this.landCoverFilters.length > 0) {
            filtered = filtered.filter((plot) =>
                plot.parcelIntersections.some((parcel) => this.activeLandCoverFilters.includes(parcel.landCoverCode))
            );
        }
        if (this.anomaliesOnlyEnabled)
            filtered = filtered.filter(
                (plot) =>
                    plot.parcelIntersections.some((it) => it.anomalies && it.anomalies.length > 0) ||
                    plot.decls.some((it) => it.anomalies.length > 0) ||
                    plot.anomalies.length > 0
            );
        if (this.anomaliesOnlyEnabled && this.activeAnomalyFilter !== null) {
            filtered = filtered.filter((plot) => {
                if (this.activeAnomalyFilter)
                    return this.checkAnomalyPresenceInPlot(plot, this.activeAnomalyFilter.errorCode);
            });
        }
        return filtered;
    }

    private applyFilters() {
        this.filteredPlots = this.notAppliedFilteredPlots;
        this.accordionForceUpdate++; // to resize accordions height
        this.showFilterPanel = false;
        this.forceApplyFilters++;
    }

    private async initLandCoverFilters() {
        if (!this.curCropPlan) return;
        this.landCoverFilters = await this.singleCropPlanModule.plotApi.getLandCoverFilters(
            this.business.businessId,
            this.curCropPlan.cropPlanId
        );
        this.landCoverFilters.forEach((l) => (this.landCoverFilterStatus[l.landCoverDescription] = l.enabledByDefault));

        this.activeLandCoverFilters = this.landCoverFilters
            .filter((l) => l.enabledByDefault)
            .reduce((res: string[], cur: LandCoverFilterIn) => {
                return [...res, ...cur.filterLandCoverCodes.map((c) => c.landCoverCode)];
            }, []);
        this.landCoverWithWarning = this.landCoverFilters.reduce(
            (res: string[], cur: LandCoverFilterIn) => [
                ...res,
                ...cur.filterLandCoverCodes.filter((c) => c.withWarnings).map((c) => c.landCoverCode),
            ],
            []
        );
    }

    private async initFormsTypes() {
        // Check if there are declarations of type VINEYARD_FORM
        const plotDeclarations: PlotDeclaration[] = [];

        // Extract all declarations from the groups of plots
        this.listGroups.forEach((group) => {
            group.plots.forEach((plot) => {
                plot.decls.forEach((declaration) => plotDeclarations.push(declaration));
            });
        });

        // Check if any declaration contains a permanent crop of type VINEYARD_FORM
        const hasVineyardForm = plotDeclarations.some((declaration) =>
            declaration.permanentCropForms?.some((cropForm) => cropForm.formType === VINEYARD_FORM)
        );

        if (
            this.savedFormsTypes !== null &&
            !this.savedFormsTypes.VINEYARD_FORM &&
            hasVineyardForm &&
            this.curCropPlan
        ) {
            // Perform the required action when VINEYARD_FORM exists
            try {
                this.loading = true;
                const vineyardFieldForms = await this.singleCropPlanModule.permanentCropFormApi.getFieldsCodes(
                    this.business.businessId,
                    this.curCropPlan.cropPlanId,
                    VINEYARD_FORM
                );
                this.savedFormsTypes = { ...this.savedFormsTypes, VINEYARD_FORM: vineyardFieldForms };
            } catch (error) {
                console.error("DevError - something onCurLandUseUpdate went wrong: ", error);
            } finally {
                this.loading = false;
            }
        }
    }

    private isWithWarning(p: Plot): boolean {
        return p.parcelIntersections.some((parcel) => this.landCoverWithWarning.includes(parcel.landCoverCode));
    }

    private getPlotSearchString(e: Plot): string {
        let parcelString = "";
        e.parcelIntersections.forEach((p) => (parcelString += " " + p.description));
        return this.hideFieldName ? parcelString : e.description + " " + parcelString;
    }

    private get listGroups(): { id: string; description: string; plots: PlotListItem[] }[] {
        if (!this.filteredPlots || this.filteredPlots.length == 0 || !this.listOrder) return [];
        //
        const groups: { id: string; description: string }[] = [];
        this.filteredPlots.forEach((p) => {
            let group: { id: string; description: string } | null = null;
            if (this.listOrder === "land_use") {
                if (p.decls && p.decls.length > 1 && !isAllEqual(p.decls, ["landuse", "code"])) {
                    group = {
                        id: "<$>multiple-land-uses",
                        description: this.i18n("multiple-land-uses").toString(),
                    };
                } else if (
                    p.decls &&
                    p.decls.length > 0 &&
                    (p.decls.length === 1 || isAllEqual(p.decls, ["landuse", "code"]))
                ) {
                    group = {
                        id: p.decls[0].landuse.code,
                        description: p.decls[0].landuse.description || p.decls[0].landuse.code,
                    };
                } else {
                    group = { id: "<$>no-land-uses", description: this.i18n("no-land-uses").toString() };
                }
            }
            if (this.listOrder === "land_cover") {
                if (p.parcelIntersections && p.parcelIntersections.length > 1) {
                    group = {
                        id: "<$>multiple-land-cover",
                        description: this.i18n("multiple-land-cover").toString(),
                    };
                } else if (p.parcelIntersections && p.parcelIntersections.length === 1) {
                    group = {
                        id: p.parcelIntersections[0].landCoverCode || "<$>no-land-cover",
                        description:
                            p.parcelIntersections[0].landCoverDescription || this.i18n("no-land-cover").toString(),
                    };
                } else {
                    group = {
                        id: "<$>no-land-cover",
                        description: this.i18n("no-land-cover").toString(),
                    };
                }
            }
            if (this.listOrder === "name") {
                if (p.description && p.description.length) {
                    group = { id: p.description.toLowerCase(), description: p.description };
                } else {
                    group = { id: "<$>no-description", description: this.i18n("no-plot-name").toString() };
                }
            }
            if (this.listOrder === "parcel") {
                if (p.parcelIntersections && p.parcelIntersections.length > 1) {
                    group = {
                        id: "<$>multiple-parcel-intersection",
                        description: this.i18n("multiple-parcel-intersection").toString(),
                    };
                } else if (p.parcelIntersections && p.parcelIntersections.length === 1) {
                    group = {
                        id: p.parcelIntersections[0].description,
                        description: p.parcelIntersections[0].description,
                    };
                } else {
                    group = {
                        id: "<$>no-parcel-intersection",
                        description: this.i18n("no-parcel-intersection").toString(),
                    };
                }
            }
            if (
                group &&
                !groups.find((e) => {
                    if (group) return e.id.toUpperCase() === group.id.toUpperCase();
                })
            ) {
                groups.push(group);
            }
        });
        groups.sort(function (a, b) {
            if (a.id.startsWith("<$>")) return 1;
            if (b.id.startsWith("<$>")) return -1;
            const textA = a.description.toUpperCase();
            const textB = b.description.toUpperCase();
            return textA < textB ? -1 : textA > textB ? 1 : 0;
        });
        return groups.map((g) => ({
            ...g,
            plots: this.getPlotsByGroup(g.id),
        }));
    }

    // lists of selected plotCodes mapped by groupId
    private get listGroupsSelectedPlots(): { [k: string]: string[] } {
        const curPlotCodes = this.curPlot
            ? [this.curPlot.plotCode, ...this.curPlots.map((p) => p.plotCode)]
            : this.curPlots.map((p) => p.plotCode);
        return Object.fromEntries(
            this.listGroups.map((g) => [
                g.id,
                g.plots.filter((p) => curPlotCodes.includes(p.plotCode)).map((p) => p.plotCode),
            ])
        );
    }

    private getRestoreFromPointInTime(date: Date) {
        if (!this.cropPlanDates.campaignStartDate) return date;
        const campaignStartDate = convertToDate(this.cropPlanDates.campaignStartDate);
        if (!campaignStartDate) return date;
        return campaignStartDate > date ? campaignStartDate : date;
    }

    private getTotalHa(plots: Plot[]): string {
        let total = 0;
        plots.forEach((it) => (total += Number(this.formattedArea(it.areaSqm).replaceAll(",", "."))));
        return (
            total.toLocaleString(this.getLocale(), {
                minimumFractionDigits: 4,
                maximumFractionDigits: 4,
            }) + " ha"
        );
    }

    private getPlotsByGroup(groupId: string): PlotListItem[] {
        let filtered: Plot[] = [];
        if (this.listOrder && this.listOrder === "land_use") {
            if (groupId === "<$>multiple-land-uses") {
                filtered = this.filteredPlots.filter(
                    (p) => p.decls && p.decls.length > 1 && !isAllEqual(p.decls, ["landuse", "code"])
                );
            } else if (groupId === "<$>no-land-uses") {
                filtered = this.filteredPlots.filter((p) => !p.decls || (p.decls && p.decls.length === 0));
            } else {
                filtered = this.filteredPlots.filter(
                    (p) =>
                        p.decls &&
                        (p.decls.length === 1 || (p.decls.length > 1 && isAllEqual(p.decls, ["landuse", "code"]))) &&
                        p.decls[0].landuse.code === groupId
                );
            }
            this.sortPlot(filtered, ["toDate", "parcelDescription", "parcelCode", "plotCode"]);
        }
        if (this.listOrder && this.listOrder === "land_cover") {
            if (groupId === "<$>multiple-land-cover") {
                filtered = this.filteredPlots.filter((p) => p.parcelIntersections && p.parcelIntersections.length > 1);
            } else if (groupId === "<$>no-land-cover") {
                // Filter all the parcel which have landCoverCode -> null
                filtered = this.filteredPlots.filter(
                    (p) =>
                        !p.parcelIntersections ||
                        (p.parcelIntersections && p.parcelIntersections.length === 0) ||
                        (p.parcelIntersections.length === 1 && !p.parcelIntersections[0].landCoverCode)
                );
            } else {
                filtered = this.filteredPlots.filter(
                    (p) =>
                        p.parcelIntersections &&
                        p.parcelIntersections.length === 1 &&
                        p.parcelIntersections[0].landCoverCode === groupId
                );
            }
            this.sortPlot(filtered, ["parcelDescription"]);
        }
        if (this.listOrder && this.listOrder === "name") {
            if (groupId === "<$>no-description") {
                filtered = this.filteredPlots.filter((p) => !p.description);
            } else {
                filtered = this.filteredPlots.filter(
                    (p) => p.description && p.description.toUpperCase() === groupId.toUpperCase()
                );
            }
            this.sortPlot(filtered, ["toDate", "parcelDescription", "parcelCode", "plotCode"]);
        }
        if (this.listOrder && this.listOrder === "parcel") {
            if (groupId === "<$>multiple-parcel-intersection") {
                filtered = this.filteredPlots.filter((p) => p.parcelIntersections && p.parcelIntersections.length > 1);
            } else if (groupId === "<$>no-parcel-intersection") {
                filtered = this.filteredPlots.filter(
                    (p) => !p.parcelIntersections || (p.parcelIntersections && p.parcelIntersections.length === 0)
                );
            } else {
                filtered = this.filteredPlots.filter(
                    (p) =>
                        p.parcelIntersections &&
                        p.parcelIntersections.length === 1 &&
                        p.parcelIntersections[0].description === groupId
                );
            }
            this.sortPlot(filtered, ["toDate"]);
        }

        return filtered.map((p) => {
            let freeAreaSqm = p.areaSqm,
                freeAreaPerc = 100;
            const landUseMap: { [k: string]: PlotListItemLanduse } = {};
            p.decls
                .filter(
                    (d) =>
                        d.fromDate.getTime() <= this.curPointInTime.getTime() &&
                        d.toDate.getTime() >= this.curPointInTime.getTime()
                )
                .map((d) => ({
                    ...d,
                    areaSqm: (p.areaSqm * d.areaPerc) / 100,
                }))
                .forEach((d) => {
                    freeAreaSqm -= d.areaSqm;
                    freeAreaPerc -= d.areaPerc;
                    if (landUseMap[d.landuse.code]) {
                        landUseMap[d.landuse.code].areaSqm += d.areaSqm;
                        landUseMap[d.landuse.code].areaPerc += d.areaPerc;
                    } else {
                        landUseMap[d.landuse.code] = {
                            code: d.landuse.code,
                            description: d.landuse.description || d.landuse.code,
                            areaSqm: d.areaSqm,
                            areaPerc: d.areaPerc,
                        };
                    }
                });
            const landUses = Object.values(landUseMap);
            return {
                ...p,
                curLandUses: landUses,
                totalUsedAreaSqm: landUses.reduce((total, lu) => (total += lu.areaSqm), 0),
                totalUsedAreaPerc: landUses.reduce((total, lu) => (total += lu.areaPerc), 0),
                freeAreaSqm: freeAreaSqm > 0 ? freeAreaSqm : 0,
                freeAreaPerc: freeAreaPerc > 0 ? freeAreaPerc : 0,
            };
        });
    }

    private toggleGroupPlotsSelection(group: { id: string; description: string; plots: Plot[] }, select: boolean) {
        if (group.plots.length == 0) return;
        if (select) {
            this.disableListAutoscroll = true;
            //
            const curPlotCodes = this.curPlot
                    ? [this.curPlot.plotCode, ...this.curPlots.map((p) => p.plotCode)]
                    : this.curPlots.map((p) => p.plotCode),
                gPlots = [...group.plots];
            if (!this.curPlot) this.curPlot = gPlots.shift() as Plot;
            this.curPlots = [...this.curPlots, ...gPlots.filter((p) => !curPlotCodes.includes(p.plotCode))];
            //
            this.$nextTick(() => (this.disableListAutoscroll = false));
        } else {
            const toRemove = this.listGroupsSelectedPlots[group.id];
            if (this.curPlot && toRemove.includes(this.curPlot.plotCode)) this.curPlot = null;
            this.curPlots = this.curPlots.filter((p) => !toRemove.includes(p.plotCode));
        }
    }

    private sortPlot(plots: Plot[], sortOrder: SortableField[]) {
        plots.sort((a, b) => {
            let res = 0;
            let index = 0;
            while (res == 0 && index < sortOrder.length) {
                res = this.compareFunc(a, b, sortOrder[index]);
                index++;
            }
            return res;
        });
    }

    private compareFunc(a: Plot, b: Plot, field: SortableField) {
        let res;
        switch (field) {
            case "parcelDescription":
                res = this.compareArray(a.parcelIntersections, b.parcelIntersections);
                if (res == 0) {
                    let index = 0;
                    while (res == 0 && index < a.parcelIntersections.length) {
                        res = this.compareString(
                            a.parcelIntersections[index].description,
                            b.parcelIntersections[index].description
                        );
                        index++;
                    }
                }
                return res;
            case "parcelCode":
                res = this.compareArray(a.parcelIntersections, b.parcelIntersections);
                if (res == 0) {
                    let index = 0;
                    while (res == 0 && index < a.parcelIntersections.length) {
                        res = this.compareString(a.parcelIntersections[index].code, b.parcelIntersections[index].code);
                        index++;
                    }
                }
                return res;
            case "plotCode":
                return this.compareString(a.plotCode, b.plotCode);
            case "toDate":
                return this.compareDate(a.toDate, b.toDate);
            default:
                return 0;
        }
    }

    private compareArray(a: unknown[], b: unknown[]) {
        if (a.length < b.length) {
            return -1;
        }
        if (a.length > b.length) {
            return 1;
        }
        return 0;
    }

    private compareDate(a: Date, b: Date) {
        if (a.getTime() < b.getTime()) {
            return -1;
        }
        if (a.getTime() > b.getTime()) {
            return 1;
        }
        return 0;
    }

    private compareString(a: string, b: string) {
        if (a < b) {
            return -1;
        }
        if (a > b) {
            return 1;
        }
        return 0;
    }

    private parcelsPiped(e: Plot): string | null {
        if (e.parcelIntersections && e.parcelIntersections.length > 0) {
            let str = "";
            e.parcelIntersections
                .filter((p) => p.description)
                .forEach((e) => (str = str ? str + ", " + e.description : e.description));
            return str != "" ? str : this.i18n("n-a").toString();
        } else {
            return this.i18n("no-parcel-intersection").toString();
        }
    }

    private deselect() {
        this.curPlot = null;
        this.curPlots = [];
        this.curCadastralData = null;
        this.curParcelData = null;
    }

    private onRowClick(plot: Plot, evt: PointerEvent) {
        // secondary selection
        if (this.multiplePlotSelection && ((evt.ctrlKey && !isMacOs()) || (evt.metaKey && isMacOs()))) {
            if (this.curPlot) this.onRowCheckboxClick(plot);
            return;
        }
        if (this.curPlot && this.curPlot.plotCode === plot.plotCode) {
            this.curPlot = null;
        } else {
            this.curPlot = plot;
        }
        this.curPlots = [];
    }

    private onRowCheckboxClick(e: Plot) {
        if (this.curPlot && this.curPlot.plotCode === e.plotCode) {
            return;
        }
        const copiedPlots = cloneDeep(this.curPlots);
        if (this.curPlots.find((p) => p.plotCode === e.plotCode)) {
            const curIdx = copiedPlots.findIndex((p) => p.plotCode === e.plotCode);
            copiedPlots.splice(curIdx, 1);
        } else {
            copiedPlots.push(e);
        }
        this.curPlots = copiedPlots;
    }

    private confirmDelete() {
        this.lastEditPlotMode = null;
        this.showConfirmDeletePlot = false;
        this.multiplePlotsSelected ? this.deleteElements() : this.deleteElement();
    }

    private async deleteElements() {
        if (!this.curCropPlan || !this.curCouncil || !this.curPlot || !this.curPlots.length) return;

        this.saving = true;

        const selectedPlots = [
            this.curPlot.plotCode.toString(),
            ...this.curPlots.map((plot) => plot.plotCode.toString()),
        ];

        try {
            const res = await this.singleCropPlanModule.plotApi.deletePlots(
                this.business.businessId,
                this.curCropPlan.cropPlanId,
                this.curCouncil.domainZoneId,
                this.curPointInTime,
                selectedPlots
            );
            this.validationMessages = res.validationMessages;
            if (this.validationMessages.length) {
                this.saving = false;
                return;
            }

            this.plots = this.handlePlotResponseDiff(res);

            this.toast(this.i18n("fields-removed") as string, {
                type: "success",
                duration: 4000,
            });
            this.curPlot = null;
            this.curPlots = [];
            this.flCurCorpPlanChangesPending = true;
        } catch (error) {
            this.toast(error as string, { type: "error", duration: 4000 });
        }
        this.saving = false;
    }

    private async deleteElement(ignoreWarning = false) {
        if (!this.curCropPlan || !this.curCouncil || !this.curPlot) return;
        this.saving = true;
        const e = this.curPlot;
        // const curIdx = this.plots.findIndex((el) => el.plotCode == e!.plotCode);
        try {
            const res = await this.singleCropPlanModule.plotApi.deletePlot(
                this.business.businessId,
                this.curCropPlan.cropPlanId,
                this.curCouncil.domainZoneId,
                this.curPlot.plotCode,
                this.curPointInTime,
                ignoreWarning
            );

            this.validationMessages = res.validationMessages;
            if (this.validationMessages.length) {
                this.saving = false;
                return;
            }

            this.plots = this.handlePlotResponseDiff(res);
            this.toast(this.i18n(this.i18n("field") + " " + this.i18n("removed")) as string, {
                type: "success",
                duration: 4000,
            });
            this.curPlot = null;
            this.flCurCorpPlanChangesPending = true;
        } catch (error) {
            this.toast(error as string, { type: "error", duration: 4000 });
        }
        this.saving = false;
    }
    private async restoreElement(ignoreWarning = false) {
        if (!this.curCropPlan || !this.curCouncil || !this.curPlot) return;
        this.saving = true;
        this.showConfirmRestorePlot = false;
        try {
            const campaignStartDate =
                this.flRestoreAtCampagnDate && this.curConfiguration?.RESTORE_PLOTS_PROPAGATING_BEHAVIOUR !== "TRUE"
                    ? this.getRestoreFromPointInTime(this.curPlot.fromDate)
                    : this.curPointInTime;
            const res = this.curPlots.length
                ? await this.singleCropPlanModule.plotApi.restorePlots(
                      this.business.businessId,
                      this.curCropPlan.cropPlanId,
                      this.curCouncil.domainZoneId,
                      [this.curPlot, ...this.curPlots].map((p) => p.plotCode),
                      campaignStartDate,
                      ignoreWarning
                  )
                : await this.singleCropPlanModule.plotApi.restorePlot(
                      this.business.businessId,
                      this.curCropPlan.cropPlanId,
                      this.curCouncil.domainZoneId,
                      this.curPlot.plotCode,
                      campaignStartDate,
                      ignoreWarning
                  );

            this.restoreValidationMessages = res.validationMessages;
            if (this.restoreValidationMessages.length) {
                this.saving = false;
                return;
            }

            if (this.curConfiguration?.RESTORE_PLOTS_PROPAGATING_BEHAVIOUR === "TRUE") {
                this.forceSync++;
            } else {
                this.toast(this.i18n(this.i18n("field") + " " + this.i18n("restored")) as string, {
                    type: "success",
                    duration: 4000,
                });
                this.curPlot = null;

                this.forceReset();
            }
        } catch (error) {
            this.toast(error as string, { type: "error", duration: 4000 });
        }
        this.saving = false;
    }

    private async restoreFirstVersion() {
        if (!this.curCropPlan || !this.curCouncil || !this.curPlot) return;
        this.saving = true;
        this.showConfirmRestoreFirstVersionPlot = false;
        try {
            await this.singleCropPlanModule.plotApi.restoreFirstVersion(
                this.business.businessId,
                this.curCropPlan.cropPlanId,
                this.curCouncil.domainZoneId,
                this.curPlot.plotCode,
                this.curPointInTime
            );
            this.toast(this.i18n(this.i18n("field") + " " + this.i18n("restored")) as string, {
                type: "success",
                duration: 4000,
            });
            this.forceReset();
        } catch (error) {
            this.toast(error as string, { type: "error", duration: 4000 });
        }
        this.saving = false;
    }

    @Watch("curCropPlanArea")
    private cropPlanProgressionBarValue(): void {
        this.accordionForceUpdate++;
        if (this.curCropPlan && this.curCropPlanArea.areaPerc && this.curCropPlanArea.totalPlotsAreaSqm) {
            this.cropPlanTotalDeclaredArea =
                (this.curCropPlanArea.totalPlotsAreaSqm * this.curCropPlanArea.areaPerc) / 100;
            this.cropPlanTotalAreaPerc = Math.round(this.curCropPlanArea.areaPerc);
        }
        if (this.curCropPlan && this.curCropPlanArea.domainAreaPerc && this.curCropPlanArea.domainPlotsAreaSqm) {
            this.domainTotalDeclaredArea =
                (this.curCropPlanArea.domainPlotsAreaSqm * this.curCropPlanArea.domainAreaPerc) / 100;
            this.domainTotalAreaPerc = Math.round(this.curCropPlanArea.domainAreaPerc);
        }
        this.filteredPlots = this.plots;
    }

    private get availableLandUses() {
        return (
            this.plots
                // get all the land uses available
                .reduce((landUses: LandUse[], p: Plot) => [...landUses, ...p.decls.map((d) => d.landuse)], [])
                // create a set with unuque values
                .filter((val, index, self) => self.map((v) => v.code).indexOf(val.code) === index)
                // filter per searchLandUse
                .filter((landUse) =>
                    this.searchLandUse
                        ? landUse.description?.toLowerCase().includes(this.searchLandUse.toLowerCase())
                        : true
                )
        );
    }

    private get availableLandCovers() {
        return (
            this.plots
                // get all the land covers available
                .reduce(
                    (landCovers: Parcel[], p: Plot) => [
                        ...landCovers,
                        ...p.parcelIntersections.filter((parcel) => !isNullish(parcel.landCoverCode)),
                    ],
                    []
                )
                // create a set with unuque values
                .filter((val, index, self) => self.map((it) => it.landCoverCode).indexOf(val.landCoverCode) === index)
                // filter per searchLandUse
                .filter((landCover) =>
                    this.searchLandCover
                        ? landCover.landCoverDescription?.toLowerCase().includes(this.searchLandCover.toLowerCase())
                        : true
                )
        );
    }

    private setDisplaySecondaryCheckbox(plot: Plot | null) {
        if (this.curPlot && this.curPlot.plotCode !== plot?.plotCode) {
            this.displaySecondaryCheckbox = plot?.plotCode || null;
        }
    }

    @Debounce(100)
    private onScroll() {
        this.lastSelected = null;
        this.scrollUpdate++;
        this.initMinimapsOnViewport();
    }

    private get multipleSelectionTooltip(): string {
        // <li class='ml-4'>${this.i18n("double-selection-tooltip-cut")}</li>
        return `${this.i18n("double-selection-tooltip-title")}
            <ul class'w-64 list-disc'>
                <li class='ml-4'>${this.i18n("double-selection-tooltip-edit")}</li>
                <li class='ml-4'>${this.i18n("double-selection-tooltip-unify")}</li>
                <li class='ml-4'>${this.i18n("double-selection-tooltip-declaration")}</li>
            </ul>`;
    }

    private warningAnomalies(plot: Plot) {
        // Get parcelIntersections warning anomalies
        const parcelIntWarningAnomalies = plot.parcelIntersections
            .flatMap((it) => it.anomalies)
            .filter(notEmpty)
            .filter((it) => !it.blocking);
        // Get plot warning anomalies
        const plotWarningAnomalies = plot.anomalies.filter((anomaly) => !anomaly.blocking);
        const declarationsWarningAnomalies: Anomaly[] = [];
        for (const declaration of plot.decls)
            declarationsWarningAnomalies.push(...declaration.anomalies.filter((anomaly) => !anomaly.blocking));

        const cumulativeArray = [
            ...plotWarningAnomalies,
            ...parcelIntWarningAnomalies,
            ...declarationsWarningAnomalies,
        ];

        return [...new Map(cumulativeArray.map((item) => [item.errorCode, item])).values()].sort((a, b) =>
            a.errorCode > b.errorCode ? 1 : -1
        );
    }

    private blockingAnomalies(plot: Plot) {
        // Get parcelIntersections blocking anomalies
        const parcelIntBlockingAnomalies = plot.parcelIntersections
            .flatMap((it) => it.anomalies)
            .filter(notEmpty)
            .filter((it) => it.blocking);
        // Get plot blocking anomalies
        const plotBlockingAnomalies = plot.anomalies.filter((anomaly) => anomaly.blocking);
        const declarationsBlockingAnomalies: Anomaly[] = [];
        for (const declaration of plot.decls)
            declarationsBlockingAnomalies.push(...declaration.anomalies.filter((anomaly) => anomaly.blocking));

        const cumulativeArray = [
            ...plotBlockingAnomalies,
            ...parcelIntBlockingAnomalies,
            ...declarationsBlockingAnomalies,
        ];

        return [...new Map(cumulativeArray.map((item) => [item.errorCode, item])).values()].sort((a, b) =>
            a.errorCode > b.errorCode ? 1 : -1
        );
    }

    private toggleCouncilSelection() {
        if (this.selectorStep === "hasCropPlanType") {
            this.selectorStep = "hasCouncil";
        } else if (this.selectorStep === "hasCouncil") {
            this.selectorStep = "hasCropPlanType";
        }
    }

    private timeSelect() {
        if (this.selectorStep !== "selectTime") {
            this.selectorStep = "selectTime";
        } else {
            this.selectorStep = "hasCouncil";
        }
    }

    private getAnomaliesPopover(plot: Plot, type: "warning" | "blocking") {
        const cssClassAlias = type == "blocking" ? "danger" : "warning";
        const anomalies = type == "blocking" ? this.blockingAnomalies(plot) : this.warningAnomalies(plot);
        const anomalyRows = anomalies
            .map((a) => {
                return `
                    <span class="${type}-bullet pr-2">&bull;</span>
                    ${a.errorDescription ? a.errorDescription : a.errorCode}
                `;
            })
            .join("<br>");

        return {
            placement: "bottom",
            trigger: "hover",
            boundary: "viewport",
            customClass: "anomalies-popover",
            html: true,
            content: `
                <div class="flex flex-grow flex-col">
                    <div class="bg-warning-100 px-3 py-2 rounded-t-xl mb-2">
                        <div class="text-${cssClassAlias}-600 text-xl font-bold">
                            <em class="text-${cssClassAlias}-600 fa-regular fa-triangle-exclamation mr-5"></em>
                            ${this.i18n(type + "-anomalies")}
                        </div>
                    </div>
                    <div class="px-3 py-2 mb-2">
                    ${anomalyRows}
                    </div>
                </div>`,
        };
    }

    private async loadCadastral() {
        if (!this.curCropPlan || !this.curCouncil) return;
        this.loading = true;
        const allCadastral = await this.singleCropPlanModule.cadastralParcelApi.getAllCadastral(
            this.business.businessId,
            this.curCropPlan.cropPlanId,
            this.curCouncil.domainZoneId,
            this.curPointInTime,
            this.curVersion ? this.curVersion.version : null
        );
        this.cadastralData = allCadastral.records;
        this.loading = false;
    }

    private async loadParcels() {
        if (!this.curCropPlan || !this.curCouncil) return;
        this.loading = true;
        const allParcels = await this.singleCropPlanModule.cadastralParcelApi.getAllParcels(
            this.business.businessId,
            this.curCropPlan.cropPlanId,
            this.curCouncil.domainZoneId,
            this.curPointInTime,
            this.curVersion ? this.curVersion.version : null
        );
        this.parcelData = allParcels.records.map((p) => {
            if (p.description === null) {
                p.description = this.i18n("n-a") as string;
            }
            return p;
        });
        this.loading = false;
    }

    private onAccordionClose() {
        this.accordionForceUpdate++;
    }

    private get infoOptions(): string[] {
        const options = ["crop-plan"];
        if (this.showParcelsInDropdown) options.push("parcels");
        if (this.showCadParcelsInDropdown) options.push("cadparcels");
        return options;
    }

    private get showParcelsInDropdown() {
        return (
            this.curConfiguration &&
            this.curConfiguration.ENABLE_PARCELS_LIST &&
            this.curConfiguration.ENABLE_PARCELS_LIST === "TRUE"
        );
    }

    private get showCadParcelsInDropdown() {
        return (
            this.curConfiguration &&
            this.curConfiguration.ENABLE_CADPARCELS_LIST &&
            this.curConfiguration.ENABLE_CADPARCELS_LIST === "TRUE"
        );
    }

    private get showDropdown() {
        return this.showParcelsInDropdown || this.showCadParcelsInDropdown;
    }

    get copyStartDate() {
        return this.convertedCurConfigCopyDate + "/" + (this.curPointInTime.getFullYear() - 1);
    }

    get copyTargetDate() {
        return this.convertedCurConfigCopyDate + "/" + this.curPointInTime.getFullYear();
    }

    get convertedCurConfigCopyDate() {
        const input = this.curConfiguration?.COPY_DECLARATIONS_AT_DATE;
        if (input === null || input === undefined) return null;
        const month = input?.substring(0, 2);
        const day = input?.substring(2);
        return day + "/" + month;
    }

    private async copyDeclarationsAtDate() {
        if (!this.curCropPlan) return;
        this.saving = true;
        this.loading = true;
        this.showConfirmCopy = false;
        try {
            await this.singleCropPlanModule.cropPlanApi.cloneDeclarationsFromPastYear(
                this.business.businessId,
                this.curCropPlan.cropPlanId,
                this.curPointInTime
            );
            this.forceReset();
        } catch (error) {
            this.toast(this.i18n("generic-error").toString(), { type: "error", duration: 4000 });
            console.error(error);
        }
        this.loading = false;
        this.saving = false;
    }

    private forceReset() {
        this.plotsForceReload++;
    }

    get swappableLanduses() {
        const landuses: SwappableLandUse[] = [];
        for (const group of this.listGroups) {
            const plots = this.getPlotsByGroup(group.id);
            for (const plot of plots) {
                for (const declaration of plot.decls) {
                    if (landuses.find((landuse) => landuse.code == declaration.landuse.code) === undefined)
                        landuses.push({
                            code: declaration.landuse.code,
                            description: declaration.landuse.description,
                            defaultHarvestDays: null,
                            defaultFromDate: null,
                            landUseClass: declaration.landuse.landUseClass,
                            declarationFromDate: declaration.fromDate,
                        });
                }
            }
        }
        return landuses;
    }

    private isMultipleLandUses(plot: Plot): boolean {
        const declarationsPiped = this.declarationsPiped(plot);
        if (declarationsPiped) {
            return (
                plot.decls.length > 1 && !isAllEqual(plot.decls, ["landuse", "code"]) && declarationsPiped.length > 20
            );
        }
        return false;
    }

    private declarationsPiped(e: Plot): string | null {
        if (e.decls && e.decls.length > 0 && !isAllEqual(e.decls, ["landuse", "code"])) {
            let str = "";
            const filteredDuplicateDeclarations = removeDuplicatesDeep(e.decls, [
                "landuse",
                "code",
            ]) as PlotDeclaration[];
            filteredDuplicateDeclarations.forEach(
                (e) =>
                    (str = str
                        ? str + ", " + (e.landuse.description || e.landuse.code)
                        : e.landuse.description || e.landuse.code)
            );
            return str;
        } else if (e.decls && e.decls.length > 0 && isAllEqual(e.decls, ["landuse", "code"])) {
            return e.decls[0].landuse.description || e.decls[0].landuse.code;
        } else {
            return null;
        }
    }

    private getFieldOccupied(e: Plot): number | null {
        let totalPerc = 0;
        e.decls
            .filter(
                (d) =>
                    d.fromDate.getTime() <= this.curPointInTime.getTime() &&
                    d.toDate.getTime() >= this.curPointInTime.getTime()
            )
            .forEach((d) => {
                totalPerc += d.areaPerc;
            });
        return Math.round(totalPerc);
    }

    private forceAccordionUpdateAfterDelay() {
        setTimeout(() => {
            this.accordionForceUpdate++;
        }, 100);
    }

    @Watch("filteredPlots", { immediate: true })
    private resetLoadedMinimaps() {
        // lazy load mini-maps
        this.loadedMapPlotCodes = [];
        if (this.filteredPlots.length)
            this.$nextTick(() => {
                this.initMinimapsOnViewport();
            });

        // Add style to NOT FILTERED plots
        const filteredPlotCodes = this.filteredPlots.map((p) => p.plotCode),
            crossPatternMode = this.curConfiguration?.PLOTS_OUT_OF_FILTER_BACKGROUND_STYLE !== "NONE";
        this.plotsStyleOverride = this.plots
            .filter((p) => !filteredPlotCodes.includes(p.plotCode))
            .map((p) => {
                return {
                    plotCode: p.plotCode,
                    style: {
                        fillColor: crossPatternMode ? createCrossIconCanvasPattern() : "transparent",
                        borderColor: crossPatternMode ? p.style.borderColor : "#ffffff",
                    },
                };
            });
        if (!isSCP)
            //highlight FILTERED plots
            this.plotsStyleOverride = [
                ...this.plotsStyleOverride,
                ...this.plots
                    .filter((p) => filteredPlotCodes.includes(p.plotCode))
                    .map((p) => {
                        return {
                            plotCode: p.plotCode,
                            style: {
                                fillColor:
                                    p.style.fillStyle == "stroke"
                                        ? makeStrokePattern(p.style.borderColor) ?? "trasparent"
                                        : p.style.fillColor.length === 9
                                        ? p.style.fillColor
                                        : p.style.fillColor + "30",
                                borderColor:
                                    this.plots.length === this.filteredPlots.length ? p.style.borderColor : "#00FF00",
                                width: this.plots.length === this.filteredPlots.length ? undefined : 4,
                            },
                        };
                    }),
            ];
    }

    private initMinimapsOnViewport() {
        clearTimeout(this.minimapDelayTimer);
        this.minimapDelayTimer = setTimeout(() => {
            if (this.mapWrappers)
                this.mapWrappers.forEach((el) => {
                    if (el.dataset.plotCode && !this.loadedMapPlotCodes.includes(el.dataset.plotCode)) {
                        const rect = el.getBoundingClientRect();
                        if (
                            rect.top >= 0 &&
                            rect.left >= 0 &&
                            rect.bottom <= (window.innerHeight || document.documentElement.clientHeight) &&
                            rect.right <= (window.innerWidth || document.documentElement.clientWidth)
                        ) {
                            this.loadedMapPlotCodes.push(el.dataset.plotCode);
                        }
                    }
                });
        }, 1000);
    }

    private confirmForceMassiveSync() {
        this.flIgnorePreviousSyncs = true;
        this.forceSync++;
    }

    private handlePlotResponseDiff(diff: PlotResponseDiff): Plot[] {
        const tempPlots = this.plots
            .filter((p) => !diff.deleted?.includes(p.plotCode))
            .map((p) => {
                const updatedPlot = diff.updated?.find((up) => up.plotCode === p.plotCode);
                return updatedPlot ? updatedPlot : p;
            });
        if (diff.added) {
            tempPlots.push(...diff.added);
        }
        return tempPlots;
    }
}
</script>

<style lang="scss">
.accordionOverride > div {
    border-top-left-radius: 0px !important;
    border-top-right-radius: 0px !important;
    border-bottom-left-radius: 0px !important;
    border-bottom-right-radius: 0px !important;
    border-width: 0;
    border-bottom-width: 1px;
}
.warning-bullet {
    content: "\2022";
    color: var(--warning-600);
    font-weight: bold;
    display: inline-block;
    margin-left: 1em;
    margin-bottom: 2px;
}
.blocking-bullet {
    content: "\2022";
    color: var(--danger-600);
    font-weight: bold;
    display: inline-block;
    margin-left: 1em;
    margin-bottom: 2px;
}
.anomalies-popover {
    border-radius: 0.75rem;
    padding-bottom: 1rem;
    table {
        margin-right: 0.8rem;
    }
}

.single-crop-plan-crop-row,
.single-crop-plan-crop-row-inner {
    @apply transition-all duration-150 ease-in-out relative;
}

.single-crop-plan-crop-row {
    @apply flex cursor-pointer border-b items-stretch w-full max-w-full relative;
    scroll-margin-top: 38px;
}
.single-crop-plan-crop-row-inner {
    @apply flex items-stretch w-full max-w-full py-2 px-3;
}

.single-crop-plan-crop-row-inner:hover,
.single-crop-plan-crop-row-active .single-crop-plan-crop-row-inner {
    @apply bg-bg-500;
}

.single-crop-plan-crop-row-multiple-active .single-crop-plan-crop-row-inner {
    @apply cursor-default;
}

.single-crop-plan-crop-row-active .single-crop-plan-crop-row-inner {
    @apply bg-info-100;
}

.single-crop-plan-crop-row-active {
    @apply border-info-400 bg-info-100;
}

.single-crop-plan-crop-row-active:after {
    content: "";
    position: absolute;
    height: 1px;
    left: 0px;
    right: 0px;
    @apply bg-info-400 z-30 transition-all duration-150 ease-in-out;
}
.single-crop-plan-crop-row-active:after {
    top: -1px;
}
.single-crop-plan-crop-row-active:before {
    bottom: -1px;
}

.s-cp-checkbox-container .abc-checkbox.abc-checkbox-focused {
    -webkit-box-shadow: none;
    box-shadow: none;
}

.single-crop-plan-crop-row-active .abc-checkbox,
.single-crop-plan-crop-row-active .abc-radio {
    @apply cursor-not-allowed;
}
// .single-crop-plan-crop-row-active .abc-checkbox-bg,
// .single-crop-plan-crop-row-active .abc-checkbox:after,
// .single-crop-plan-crop-row-active .abc-checkbox-icon-tic,
// .single-crop-plan-crop-row-active .abc-checkbox{
//     @apply rounded-full;
// }
.single-crop-plan-crop-row-active .abc-checkbox-icon-tic,
.single-crop-plan-crop-row-active .abc-radio-bg {
    @apply bg-info-500;
}
.single-crop-plan-crop-row-active .abc-checkbox:checked:not(.errored),
.single-crop-plan-crop-row-active .abc-checkbox.checked:not(.errored),
.single-crop-plan-crop-row-active .abc-checkbox.undefined[type="button"]:not(.errored),
.single-crop-plan-crop-row-active .abc-radio {
    @apply border-info-500;
}

.single-crop-plan-checkbox-enter-active {
    transition: all 0.2s ease-in-out;
}
.single-crop-plan-checkbox-enter,
.single-crop-plan-checkbox-leave-to {
    overflow: hidden;
    max-height: 0px;
    opacity: 0;
}

.single-crop-plan-checkbox-enter-to {
    overflow: hidden;
    max-height: 30px;
    opacity: 1;
}

.filter-container {
    display: flex;
    justify-content: space-evenly;
    gap: 4px;
    white-space: nowrap;
}

.filter-item {
    border-radius: 9999px;
    background-color: var(--primary-100);
    display: flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    color: var(--primary-800);
}

.filter-item i {
    color: var(--secondary-900);
    opacity: 0.25;
}

.filter-item:hover {
    background-color: var(--primary-300);
    color: var(--inner-content-color);
}

.filter-item:hover i {
    color: var(--inner-content-color);
    opacity: 1;
}

.filter-item:hover > .edit-button,
.filter-item:hover > .edit-button > i {
    background-color: var(--primary-400);
    color: var(--inner-content-color);
}

.edit-button {
    height: 26px;
    width: 26px;
    display: flex;
    justify-content: center;
    align-items: center;
    border-radius: 50%;
    background-color: var(--primary-200);
}

.edit-button i {
    color: var(--primary-600);
    font-weight: bold;
    opacity: 1;
}

.accordion-title {
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
}

.info-select > .abc-dropdown2-wrapper {
    @apply rounded-md;
    border-color: var(--primary-100);
}

.info-select > .abc-dropdown2-wrapper > div > #popperRefabc-9 > .abc-dropdown2 {
    @apply rounded-md flex items-center;
    background-color: var(--primary-100);
    color: var(--brand-yellow-300);
}

.nowrap {
    white-space: nowrap;
}
</style>
