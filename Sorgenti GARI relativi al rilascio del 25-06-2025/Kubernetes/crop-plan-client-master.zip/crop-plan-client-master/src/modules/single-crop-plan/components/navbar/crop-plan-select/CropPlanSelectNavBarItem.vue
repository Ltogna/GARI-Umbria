<template>
    <fragment>
        <nav-bar-item
            v-model="cropPlanNavbarFilterOpen"
            :filter="filter"
            :triggerLoad="triggerLoad"
            v-show="showCropPlanNavbar"
        >
            <template #label>
                <div />
                <abc-nav-bar-item
                    v-abc-tooltip.hover.ds1000="i18n('select-crop-plan')"
                    :opened="cropPlanNavbarFilterOpen"
                >
                    <template #icon>
                        <em class="abc-icon abc-icon-maps-2 mr-1" />
                    </template>
                    <p>{{ label }}</p>
                </abc-nav-bar-item>
            </template>

            <abc-nav-bar-item-panel style="min-height: 300px" title="select-crop-plan" i18nKeys>
                <abc-tabs v-model="selected" right-tools>
                    <template #tabs>
                        <abc-tab :id="0"><em class="abc-icon abc-icon-folder mr-1" />{{ i18n("select-crop-plan") }}</abc-tab>
                    </template>
                    <div class="w-full h-full">
                        <div class="h-full w-full flex flex-col overflow-hidden">
                            <search-crop-plans-results
                                :filter="filter"
                                @select="setCurrentCropPlan"
                                @added-new-crop-plan="triggerLoadOnNewCropPlan"
                                :triggerLoad="triggerLoad"
                            />
                        </div>
                    </div>
                </abc-tabs>
            </abc-nav-bar-item-panel>
        </nav-bar-item>
        <abc-loader v-if="loading" scope="fixed" />

        <!-- MODAL -->
        <abc-modal
            v-if="pollingIsModalOpen"
            @close="pollingIsModalOpen = false"
            is-message
            modal-class="w-full md:w-8/12 lg:w-6/12 xxl:w-4/12"
            force-modal
            hide-footer
        >
            <template #body>
                <div class="pt-2 pb-4 flex flex-col w-full">
                    <div
                        class="s-cp-publish-icon mx-auto flex items-center justify-center rounded-full"
                        :class="{
                            'bg-info-100 text-info-300': pollingIsProcessing,
                            'bg-success-100 text-success-300': !pollingIsProcessing && pollingIsPublishSuccess,
                            'bg-danger-100 text-danger-300': !pollingIsProcessing && !pollingIsPublishSuccess,
                        }"
                        style="width: 80px; height: 80px; font-size: 30px"
                    >
                        <transition
                            name="custom-classes-transition"
                            enter-active-class="animate__animated animate__fadeIn animate__faster"
                            leave-active-class="animate__animated animate__fadeOut animate__faster"
                            mode="out-in"
                        >
                            <div v-if="pollingIsProcessing" key="1">
                                <em class="fad fa-cog s-cp-movement-info-rotate" />
                            </div>
                            <em v-else-if="pollingIsPublishSuccess" key="2" class="fa fa-check" />
                            <em v-else-if="!pollingIsPublishSuccess" key="3" class="fa fa-times" />
                        </transition>
                    </div>
                    <div class="mt-4 w-full">
                        <h3 class="text-lg text-center font-bold text-secondary-600" style="height: 50px">
                            <transition
                                name="custom-classes-transition"
                                enter-active-class="animate__animated animate__fadeIn animate__faster"
                                leave-active-class="animate__animated animate__fadeOut animate__faster"
                                mode="out-in"
                            >
                                <div v-if="pollingIsProcessing" key="1">{{ i18n("crop-plan-publishing") }}</div>
                                <div v-else-if="pollingIsPublishSuccess" key="2" class="flex flex-col">
                                    <span>{{ i18n("crop-plan-published") }}</span>
                                    <span class="text-base font-normal pt-1">{{
                                        i18n("crop-plan-published-info")
                                    }}</span>
                                </div>
                                <div v-else-if="!pollingIsPublishSuccess" key="3" class="flex flex-col">
                                    <span>{{ i18n("crop-plan-not-published") }}</span>
                                    <span class="text-base font-normal pt-1">{{ i18n("crop-plan-fail-publish") }}</span>
                                </div>
                            </transition>
                        </h3>
                    </div>
                    <div class="flex w-full justify-center mt-8 -mb-4" style="height: 45px">
                        <abc-button
                            v-if="!pollingIsProcessing"
                            is-info
                            is-big
                            is-outlined
                            @click="pollingIsModalOpen = false"
                            :is-disabled="pollingIsProcessing"
                        >
                            <em class="abc-icon abc-icon-arrow-left-round mr-1" />{{ i18n("close") }}
                        </abc-button>
                    </div>
                </div>
            </template>
        </abc-modal>
    </fragment>
</template>

<script lang="ts">
import { Vue, Component, Inject, Watch } from "vue-property-decorator";
import { TranslateResult } from "vue-i18n";
import { FromStore } from "@abaco/web-common/src/app";
import SearchCropPlansCriteria from "./SearchCropPlansCriteria.vue";
import SearchCropPlansResults from "./SearchCropPlansResults.vue";
import { Business } from "../../../models/Business";
import { Version } from "../../../models/Version";
import SingleCropPlanModule, { MODULE_ID } from "../../..";
import { CropPlan, CropPlanType } from "../../../models/CropPlan";
import SSOModule from "@abaco/sso-web-module/src/abaco-module";
import { AxiosError } from "axios";

@Component({
    components: {
        SearchCropPlansCriteria,
        SearchCropPlansResults,
    },
})
export default class CropPlanSelectNavBarItem extends Vue {
    @Inject(MODULE_ID) singleCropPlanModule!: SingleCropPlanModule;
    @Inject(SSOModule.MODULE_ID) ssoWebModule!: SSOModule;

    @FromStore(MODULE_ID) availableCropPlanTypes!: CropPlanType[];
    @FromStore(MODULE_ID) businessNavBarFilterOpen!: boolean;
    @FromStore(MODULE_ID) cropPlanNavbarFilterOpen!: boolean;
    @FromStore(MODULE_ID) business!: Business | null;
    @FromStore(MODULE_ID) curCropPlan!: CropPlan | null;
    @FromStore(MODULE_ID) lockedCropPlanTypeCode!: string | null;
    @FromStore(MODULE_ID) curVersion!: Version | null;
    @FromStore(MODULE_ID) flCurCorpPlanChangesPending!: boolean;
    @FromStore(MODULE_ID) showNoCropPlanFound!: boolean;
    @FromStore(MODULE_ID) showCannotUseCropPlan!: boolean;
    @FromStore(MODULE_ID) showCannotUseCropPlanForThisBusiness!: boolean;
    @FromStore(MODULE_ID) pollingIsProcessing!: boolean;
    @FromStore(MODULE_ID) pollingIsPublishSuccess!: boolean;
    @FromStore(MODULE_ID) pollingIsModalOpen!: boolean;

    @Inject() i18n!: (key: string, values?: unknown) => TranslateResult;

    private selected = 0;
    private triggerLoad = 0;
    private filter = "";
    private loading = false;
    private resetFilter = 0;
    private hide = false;

    async mounted() {
        this.cropPlanNavbarFilterOpen = false;
        if (this.showCannotUseCropPlan) this.businessNavBarFilterOpen = false;
    }

    private get showCropPlanNavbar() {
        return (
            !this.hide &&
            this.availableCropPlanTypes !== null &&
            (this.availableCropPlanTypes.length > 1 ||
                (this.availableCropPlanTypes.length === 1 && this.availableCropPlanTypes[0].multiple))
        );
    }

    get label(): TranslateResult {
        return this.curCropPlan ? `${this.curCropPlan.description}` : this.i18n("select-crop-plan");
    }

    @Watch("availableCropPlanTypes")
    async onTabChange() {
        if (!this.lockedCropPlanTypeCode) {
            const onlyOne = await this.autoSelectIfOnlyOne();
            if (!onlyOne && this.cropPlanNavbarFilterOpen)
                this.triggerLoad += 1;
        }
    }

    private async setCurrentCropPlan(cropPlan: CropPlan | null) {
        const editEnabled = await this.ssoWebModule.isFunctionEnabled("CRPL", "EDITOR");
        if (!editEnabled && cropPlan) cropPlan.readOnly = true;
        this.curCropPlan = cropPlan;
        this.flCurCorpPlanChangesPending = cropPlan?.changesPending || false;
        this.cropPlanNavbarFilterOpen = false;
    }

    private async autoSelectIfOnlyOne() {
        this.loading = true;
        let onlyOne = false;
        try {
            if (this.business && this.availableCropPlanTypes) {
                if (this.availableCropPlanTypes.length === 1 && this.availableCropPlanTypes[0].multiple === false) {
                    const cropPlans = await this.singleCropPlanModule.cropPlanApi.getCropPlans(
                        this.business.businessId,
                        this.availableCropPlanTypes[0].cropPlanTypeCode
                    );
                    if (cropPlans.length === 1) {
                        this.setCurrentCropPlan(cropPlans[0]);
                        onlyOne = true;
                    } else if (cropPlans.length === 0) {
                        const editEnabled = await this.ssoWebModule.isFunctionEnabled("CRPL", "EDITOR");
                        if (editEnabled) {
                            this.curCropPlan = await this.singleCropPlanModule.cropPlanApi.insertCropPlan(
                                this.business.businessId,
                                {
                                    cropPlanTypeCode: this.availableCropPlanTypes[0].cropPlanTypeCode,
                                    description: this.i18n("crop-plan-description-with-type", {
                                        cpTypeDescription:
                                            this.availableCropPlanTypes[0].description ??
                                            this.availableCropPlanTypes[0].cropPlanTypeCode,
                                    }) as string,
                                }
                            );
                            this.cropPlanNavbarFilterOpen = false;
                            onlyOne = true;
                        } else {
                            this.showNoCropPlanFound = true;
                            this.loading = false;
                            this.cropPlanNavbarFilterOpen = false;
                        }
                    }
                }
            }
            if (!this.business && !this.showCannotUseCropPlan) {
                this.businessNavBarFilterOpen = true;
                this.cropPlanNavbarFilterOpen = false;
            }
        } catch (error) {
            const axiosErr = error as AxiosError;
            if (axiosErr.response?.status === 403) {
                this.cropPlanNavbarFilterOpen = false;
                this.showCannotUseCropPlanForThisBusiness = true;
            } else {
                console.error(error);
            }
        } finally {
            this.loading = false;
        }
        return onlyOne;
    }

    private triggerLoadOnNewCropPlan() {
        this.triggerLoad++;
    }

    @Watch("lockedCropPlanTypeCode", { immediate: true })
    @Watch("business", { immediate: true })
    private async loadLockedCropPlanTypeCode() {
        if (this.lockedCropPlanTypeCode && this.business) {
            this.loading = true;
            //
            this.availableCropPlanTypes = await this.singleCropPlanModule.cropPlanApi.getCropPlanTypes(
                this.business.businessId
            );
            const cp = this.availableCropPlanTypes.find((it) => it.cropPlanTypeCode === this.lockedCropPlanTypeCode);
            if (cp && !cp.multiple) {
                const cropPlans = await this.singleCropPlanModule.cropPlanApi.getCropPlans(
                    this.business.businessId,
                    this.lockedCropPlanTypeCode
                );
                //
                const cropPlan = cropPlans.find((it) => it.cropPlanTypeCode === this.lockedCropPlanTypeCode);
                if (cropPlan) {
                    this.setCurrentCropPlan(cropPlan);
                } else {
                    const newCropPlan = await this.singleCropPlanModule.cropPlanApi.insertCropPlan(
                        this.business.businessId,
                        {
                            cropPlanTypeCode: this.lockedCropPlanTypeCode,
                            description: this.i18n("crop-plan-description-with-type", {
                                cpTypeDescription: cp.description ?? this.lockedCropPlanTypeCode,
                            }) as string,
                        }
                    );
                    this.curCropPlan = newCropPlan;
                }
                //
                this.hide = true;
            }
            //
            this.loading = false;
        }
    }
}
</script>

<style lang="scss">
.abc-business-label {
    @apply flex items-center justify-start cursor-pointer;
    border-color: theme("colors.brand-black.500");
    padding: 5px 12px;
    min-width: 100px;
    font-size: 12px;
    border-bottom-left-radius: 4px;
    border-bottom-right-radius: 4px;
}
.abc-business-label:hover {
    background: rgba(255, 255, 255, 0.25);
}
.single-cp-remove-business-button.abc-tool-button {
    min-height: 34px;
    height: 34px;
}
.s-cp-publish-icon {
    @apply transition duration-200 ease-in-out;
}
.s-cp-movement-info-rotate {
    animation: s-cp-movement-info-rotate 1700ms linear infinite;
}
@keyframes s-cp-movement-info-rotate {
    from {
        transform: rotate(0deg);
    }
    to {
        transform: rotate(360deg);
    }
}
</style>
