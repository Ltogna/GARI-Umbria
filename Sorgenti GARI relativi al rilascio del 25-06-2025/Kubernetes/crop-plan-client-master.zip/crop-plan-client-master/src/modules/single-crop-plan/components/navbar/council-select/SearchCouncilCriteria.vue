<template>
    <div class="flex pt-3 pb-2 border-b mx-4 sticky bg-bg-100 top-0">
        <abc-form ref="form" class="flex items-start mt-4 w-full">
            <div class="w-full flex justify-between relative">
                <abc-input
                    left-tools
                    :value="localFilter"
                    @input="updateFilter"
                    class="w-7/12 pr-2"
                    :placeholder="i18n('search-for-council')"
                    :rules="[checkLength]"
                >
                    <template #left>
                        <em class="abc-icon abc-icon-lens" />
                    </template>
                </abc-input>
                <div v-if="!hideShowAllCouncil" class="flex w-5/12 pl-2 justify-end">
                    <div class="flex items-center">
                        <abc-switch
                            :value="filterBySubjectInner"
                            @input="filterBySubjectInner = !filterBySubjectInner"
                        />
                        <div>{{ i18n("council-by-subject-toggle") }}</div>
                    </div>
                </div>
            </div>
        </abc-form>
    </div>
</template>

<script lang="ts">
import { Vue, Component, Inject, Ref, Prop, Watch } from "vue-property-decorator";
import { TranslateResult } from "vue-i18n";
import { Validable } from "@abaco/web-components/src/components/form/Validable";
import SingleCropPlanModule, { MODULE_ID } from "../../..";
import { FromStore } from "@abaco/web-common/src/app";
import { Configuration } from "../../../models/CropPlan";

@Component
export default class SearchCouncilCriteria extends Vue {
    @Inject() i18n!: (key: string, values?: unknown) => TranslateResult;
    @Inject(SingleCropPlanModule.MODULE_ID) businessRegistryModule!: SingleCropPlanModule;

    @FromStore(MODULE_ID) curConfiguration!: Configuration | null;

    @Ref("form") form!: Validable;

    @Prop() value!: string;
    @Prop() resetFilter!: number;
    @Prop({ type: Boolean }) checkLenght!: boolean;
    @Prop({ type: Boolean }) isSupplyChain!: boolean;
    @Prop({ type: Boolean }) filterBySubject!: boolean;

    private localFilter = this.value;

    private get hideShowAllCouncil() {
        return this.curConfiguration?.ENABLE_ALL_COUNCILS_SELECTION
            ? this.curConfiguration?.ENABLE_ALL_COUNCILS_SELECTION === "FALSE"
            : true;
    }

    private get filter() {
        return this.value;
    }
    private set filter(val) {
        this.$emit("input", val);
    }

    private get filterBySubjectInner(): boolean {
        return this.filterBySubject;
    }
    private set filterBySubjectInner(e: boolean) {
        this.$emit("update-filter-by-subject", e);
    }

    @Watch("resetFilter")
    onReset() {
        this.updateFilter("");
        this.filterBySubjectInner = true;
    }

    private get checkLength() {
        return (v: string) => {
            return !v || v.length > 2 || this.i18n("type-at-least-3-ch");
        };
    }

    private updateFilter(val: string) {
        this.localFilter = val;
        if (this.localFilter && this.localFilter.length > 2) {
            this.filter = this.localFilter;
        } else {
            this.filter = "";
        }
    }
}
</script>
