<template>
    <div class="flex flex-col">
        <strong class="my-2">{{ i18n("enrolments") }}</strong>
        <div
            class="w-full border rounded-lg mb-2 px-4 py-2"
            v-for="subscription in subscriptions"
            :key="subscription.code"
        >
            <div v-for="(field, index) in subscription.fields" :key="subscription.code + index">
                <div class="flex items-center gap-1">
                    <span class="text-secondary-600 font-medium capitalize"> {{ i18n(field.label) }}: </span>
                    <strong>{{ field.value }}</strong>
                </div>
            </div>
        </div>
    </div>
</template>

<script lang="ts">
import { Prop, Component, Mixins, Inject } from "vue-property-decorator";
import { TranslateResult } from "vue-i18n";
import AreaUtils from "../../mixins/AreaUtils";
import DateUtils from "../../mixins/DateUtils";
import { Subscription } from "../../models/PermanentCropForm";
import SingleCropPlanModule, { MODULE_ID } from "../..";
import { FromStore } from "@abaco/web-common/src/app";
import { Business } from "../../models/Business";
import { CropPlan } from "../../models/CropPlan";
@Component
export default class SubscriptionComponent extends Mixins(DateUtils, AreaUtils) {
    @Inject() i18n!: (key: string, values?: unknown) => TranslateResult;
    @Inject(SingleCropPlanModule.MODULE_ID) singleCropPlanModule!: SingleCropPlanModule;

    @FromStore(MODULE_ID) business!: Business;
    @FromStore(MODULE_ID) curCropPlan!: CropPlan | null;
    @Prop() readonly subscriptionCodes!: string[];
    @Prop() readonly externalCode!: string | null;

    private subscriptions: Subscription[] = [];

    async mounted() {
        if (this.curCropPlan) {
            const res = await this.singleCropPlanModule.cropPlanApi.getSubscriptionsData(
                this.business.businessId,
                this.curCropPlan.cropPlanId,
                this.subscriptionCodes,
                this.externalCode
            );

            this.subscriptions = res;
            this.$emit("onSubscriptionLoaded", true);
        }
    }
}
</script>

<style></style>
