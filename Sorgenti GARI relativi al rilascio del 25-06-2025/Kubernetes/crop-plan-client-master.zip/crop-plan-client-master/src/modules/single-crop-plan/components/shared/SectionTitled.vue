<template>
    <div class="sc-decl-edit-section">
        <div class="sc-decl-edit-info w-full md:w-4/12 justify-center md:justify-start">
            <div class="sc-decl-edit-title">
                <span class="text-4xl text-label-secondary pr-2">{{ number }}</span>
                {{ title }}
            </div>
            <div class="sc-decl-edit-sub-title">
                {{ description }}
            </div>
        </div>
        <div class="sc-decl-edit-fields justify-center md:justify-start w-full md:w-8/12">
            <slot name="content"></slot>
        </div>
    </div>
</template>

<script lang="ts">
import { Component, Vue, Prop } from "vue-property-decorator";

@Component
export default class SectionTitled extends Vue {
    @Prop() number!: number;
    @Prop() title!: string;
    @Prop() description!: string;
}
</script>

<style lang="scss" scoped>
.sc-decl-edit-section {
    @apply px-4 flex flex-wrap;
    flex-grow: 1;
}

.sc-decl-edit-info {
    @apply flex flex-col items-start pr-6 text-label-primary;
}

.sc-decl-edit-title {
    @apply w-full flex font-bold items-baseline text-secondary-700;
}
.sc-decl-edit-sub-title {
    @apply w-full flex;
}

.sc-decl-edit-info div:last-of-type {
    @apply pb-2 border-b;
}

.sc-decl-edit-fields {
    @apply flex flex-col;
}

@media (min-width: 640px) {
    .sc-decl-edit-fields {
        @apply mt-2;
    }
}
@media (min-width: 768px) {
    .sc-decl-edit-fields {
        @apply pl-6 border-l;
    }
}
</style>
