<template>
    <div class="flex w-full">
        <div
            class="cp-timeline-plot-line flex flex-col absolute bg-info-300 items-center justify-center z-100 rounded-full"
            :style="containerStyle"
        >
            <!-- <div
                class="cp-timeline-plot-line-dot-border absolute z-0 bg-info-300 top-0 rounded-full"
                style="left: 0px;"
            /> -->
            <!-- <div
                class="cp-timeline-plot-line-dot-border absolute z-0 bg-info-300 top-0 rounded-full"
                style="right: 0px;"
            /> -->
        </div>

        <div
            v-for="(e, i) in events"
            :key="i"
            class="cp-timeline-plot-line-dot absolute z-0 bg-info-200 border-bg-100 top-0 rounded-full"
            :style="getEventStyle(e)"
        />
    </div>
</template>

<script lang="ts">
import { Prop, Component, Inject, Vue } from "vue-property-decorator";
import { TranslateResult } from "vue-i18n";

@Component
export default class CropPlanTimelineGraphPlotLine extends Vue {
    @Inject() i18n!: (key: string, values?: unknown) => TranslateResult;

    @Prop() left!: number;
    @Prop() width!: number;
    @Prop() events!: number[];

    private isHovering = false;

    private get containerStyle() {
        return {
            left: this.left + "px",
            width: this.width + "px",
        };
    }

    private getEventStyle(e: number) {
        return {
            left: e + "px",
        };
    }
}
</script>

<style lang="scss">
.cp-timeline-plot-line {
    top: -7px;
    height: 2px;
}

.cp-timeline-plot-line-dot {
    top: -11px;
    border-width: 3px;
    width: 9px;
    height: 10px;
}

.cp-timeline-plot-line-dot-border {
    top: -1px;
    width: 5px;
    height: 5px;
}
</style>
