<template>
    <div>
        <div 
            v-for="(item, index) in cadastralData"
            :key="index"
            @click="onSelect(item)"
            v-scroll="lastSelected && getParcelCode(item) === getParcelCode(lastSelected)"
            class="single-crop-plan-crop-row"
            :class="{ 'single-crop-plan-crop-row-active': getParcelCode(curCadastralData) === getParcelCode(item) }"
        >
            <div 
                class="single-crop-plan-crop-row-inner gap-3"
                :class="{ 'border-t': index === 0 }"
            >
                <div class="flex items-center">
                    <single-cp-map-preview v-if="item.geom" :mbrOverview="item.mbrOverview" :geom="item.geom" />
                    <!-- !HARDCODED SIZE MAP PREVIEW -->
                    <div
                        v-else
                        class="bg-danger-50 rounded-lg h-12 w-12 flex justify-center items-center text-danger-500"
                        v-b-tooltip.hover.window.ds400
                        :title="i18n('not-available-gis')"
                    >
                        <em class="fa-sharp fa-solid fa-xmark-large"></em>
                    </div>
                </div>
                <div class="flex flex-row flex-1">
                    <ul class="gray-color mr-3">
                        <li>{{ i18n("sheet") }}</li>
                        <li>{{ i18n("parcel-l") }}</li>
                        <li>{{ i18n("conduction") }}</li>
                    </ul>
                    <ul class="font-normal text-right">
                        <li>{{ item.sectorBlock }}</li>
                        <li>{{ item.parcel }}</li>
                        <li>{{ item.holdingPercentage }}&#37;</li>
                    </ul>
                </div>
                <div class="flex flex-col">
                    <div v-if="item.areaSqm || item.areaSqm === 0" class="flex items-baseline">
                        <span class="font-semibold text-lg pr-1">{{ formattedArea(item.areaSqm) }}</span>
                        <span class="text-base lowercase">{{ areaLabel() }}</span>
                    </div>
                    <div class="flex flex-row justify-end gap-1">
                        <div
                            v-if="item.parcelType"
                            v-b-tooltip.hover.window.ds400
                            :title="item.parcelTypeDescription"
                            class="h-6 w-6 rounded-full flex justify-center items-center text-xs text-white"
                            style="background-color:var(--success-400); color:var(--color-bg-100);"
                        >
                            <em v-if="item.parcelType === 'URBAN'" class="far fa-building"></em>
                            <em v-if="item.parcelType === 'AGRICULTURAL'" class="far fa-leaf"></em>
                            <em v-if="item.parcelType === 'ROADS'" class="far fa-road"></em>
                            <em v-if="item.parcelType === 'WATERS'" class="far fa-droplet"></em>
                        </div>
                        <div
                            v-b-tooltip.hover.window.ds400
                            :title="item.holdingTypeDescription"
                            class="h-6 w-6 rounded-full flex justify-center items-center text-xs text-white"
                            style="background-color:var(--info-500); color:var(--color-bg-100);"
                        >
                            <em v-if="item.holdingCount > 1" class="far fa-users"></em>
                            <em v-else class="far fa-user"></em>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script lang="ts">
import { Component, Inject, Vue, Prop, Mixins, Watch } from "vue-property-decorator";
import { VBTooltip } from "bootstrap-vue";
import { TranslateResult } from "vue-i18n";
import { CadastralData } from "../../models/Declaration";
import SingleCpMapPreview from "../mapComponent/SingleCPMapPreview.vue";
import { FromStore } from "@abaco/web-common/src/app";
import { MODULE_ID } from "../..";
import AreaUtils from "../../mixins/AreaUtils";

@Component({
    components: {
        SingleCpMapPreview,
    },
    directives: {
        "b-tooltip": VBTooltip,
        scroll: {
            inserted(el, binding) {
                if (binding.value) {
                    el.scrollIntoView({ block: "nearest" });
                }
            },
            componentUpdated(el, binding) {
                if (binding.value) {
                    el.scrollIntoView({ block: "nearest" });
                }
            },
        },
    },
})
export default class SingleCpCadParcelList extends Mixins(AreaUtils) {
    @Inject() i18n!: (key: string, values?: unknown) => TranslateResult;
    @FromStore(MODULE_ID) curCadastralData!: CadastralData | null;

    @Prop() cadastralData!: CadastralData[];
    @Prop({ default: 0 }) scrollUpdate!: number;

    private lastSelected: CadastralData | null = null;

    private onSelect(selected: CadastralData) {
        this.curCadastralData = (this.curCadastralData === selected)
            ? null
            : selected;
    }

    private getParcelCode(data: CadastralData | null) {
        return data
            ? data.sectorBlock + "-" + data.parcel
            : null;
    }

    @Watch("curCadastralData")
    onCurParcelDataUpdate() {
        this.lastSelected = this.curCadastralData;
    }

    @Watch("scrollUpdate")
    private onScroll() {
        this.lastSelected = null;
    }
}
</script>

<style lang="scss" scoped>
.gray-color {
    color: var(--secondary-500);
}
.green-color {
    background-color: var(--success-400);
}
.blue-color {
    background-color: var(--info-500);
}
</style>
