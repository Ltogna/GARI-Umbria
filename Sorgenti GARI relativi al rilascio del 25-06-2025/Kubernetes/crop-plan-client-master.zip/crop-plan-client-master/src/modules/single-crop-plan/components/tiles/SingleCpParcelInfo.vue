<template>
    <layout :title="i18n('info')" :show-back="true" :show-close="false" @back="$emit('close')" @close="$emit('close')">
        <!-- CURRENT CADASTRAL DATA -->
        <div v-if="curCadastralData" class="flex flex-col w-full py-3 px-2 divide-y overflow-auto h-full">
            <div class="flex p-1">
                <div class="flex flex-col flex-1">
                    <span class="text-secondary-400 font-semibold">{{ i18n("sheet") }}</span
                    ><span class="text-2xl">{{ curCadastralData.sectorBlock }}</span>
                </div>
                <div class="flex flex-col flex-1">
                    <span class="text-secondary-400 font-semibold">{{ i18n("parcel-title") }}</span
                    ><span class="text-2xl">{{ curCadastralData.parcel }}</span>
                </div>
            </div>
            <div class="flex flex-col p-1">
                <span class="text-secondary-400 font-semibold">{{ i18n("percentage-conduction") }}</span
                ><span>{{ curCadastralData.holdingPercentage }}&#37;</span>
            </div>
            <div class="flex flex-col p-1">
                <span class="text-secondary-400 font-semibold">{{ i18n("gis") }}</span>
                <abc-tag v-if="curCadastralData.geom" class="rounded-tag my-2" type="success">
                    <template #icon><em class="fa-solid fa-check"></em></template>{{ i18n("agreement-status-available") }}
                </abc-tag>
                <abc-tag v-else class="rounded-tag my-2" type="danger">
                    <template #icon><em class="fa-sharp fa-solid fa-xmark-large"></em></template
                    >{{ upperCase(i18n("not-available")) }}
                </abc-tag>
            </div>
            <div class="flex flex-col p-1">
                <span class="text-secondary-400 font-semibold">{{ i18n("unimm") }}</span>
                <abc-tag v-if="curCadastralData.hasUnimm" class="rounded-tag my-2" type="success">
                    <template #icon><em class="fa-solid fa-check"></em></template>{{ i18n("agreement-status-available") }}
                </abc-tag>
                <abc-tag v-else class="rounded-tag my-2" type="danger">
                    <template #icon><em class="fa-sharp fa-solid fa-xmark-large"></em></template
                    >{{ upperCase(i18n("detail.data_not_present")) }}
                </abc-tag>
            </div>
            <div class="flex flex-col p-1">
                <span class="text-secondary-400 font-semibold">{{ i18n("unar") }}</span>
                <abc-tag v-if="curCadastralData.hasUnar" class="rounded-tag my-2" type="success">
                    <template #icon><em class="fa-solid fa-check"></em></template>{{ i18n("agreement-status-available") }}
                </abc-tag>
                <abc-tag v-else class="rounded-tag my-2" type="danger">
                    <template #icon><em class="fa-sharp fa-solid fa-xmark-large"></em></template
                    >{{ upperCase(i18n("detail.data_not_present")) }}
                </abc-tag>
            </div>
            <div v-if="curCadastralData.parcelType" class="flex flex-col p-1">
                <span class="text-secondary-400 font-semibold">{{ i18n("parcel-type") }}</span>
                <div class="flex items-center gap-2">
                    <div class="green-color h-8 w-8 rounded-full flex justify-center items-center text-xs my-2">
                        <em v-if="curCadastralData.parcelType === 'URBAN'" class="far fa-building"></em>
                        <em v-if="curCadastralData.parcelType === 'AGRICULTURAL'" class="far fa-leaf"></em>
                        <em v-if="curCadastralData.parcelType === 'ROADS'" class="far fa-road"></em>
                        <em v-if="curCadastralData.parcelType === 'WATERS'" class="far fa-droplet"></em>
                    </div>
                    <span>{{ upperCase(curCadastralData.parcelTypeDescription) }}</span>
                </div>
            </div>
            <div class="flex flex-col p-1">
                <span class="text-secondary-400 font-semibold">{{ i18n("conduction-type") }}</span>
                <div class="flex items-center gap-2">
                    <div class="blue-color h-8 w-8 rounded-full flex justify-center items-center text-xs my-2">
                        <em v-if="curCadastralData.holdingCount > 1" class="far fa-users"></em>
                        <em v-else class="far fa-user"></em>
                    </div>

                    <span>{{ upperCase(curCadastralData.holdingTypeDescription) }}</span>
                </div>
            </div>
            <div v-if="curCadastralData.geom" class="flex p-1">
                <div class="flex flex-col flex-1">
                    <span class="text-secondary-400 font-semibold">{{ i18n("area") }}</span
                    ><span class="text-2xl"
                        ><strong>{{ formattedArea(curCadastralData.areaSqm) }}</strong> ha</span
                    >
                </div>
                <div class="flex flex-col flex-1">
                    <span class="text-secondary-400 font-semibold">{{ i18n("holded-area") }}</span
                    ><span class="text-2xl"
                        ><strong>{{
                            formattedArea((curCadastralData.areaSqm * curCadastralData.holdingPercentage) / 100)
                        }}</strong>
                        ha</span
                    >
                </div>
            </div>
        </div>
        <!-- CURRENT PARCEL DATA -->
        <div v-else-if="curParcelData" class="flex flex-col w-full py-3 px-2 divide-y overflow-auto h-full">
            <div class="flex flex-col p-1">
                <span class="text-secondary-400 font-semibold">{{ i18n("parcel-e") }}</span
                ><span>{{ curParcelData.description }}</span>
            </div>
            <div v-if="curParcelData.landCovers.length > 0" class="flex flex-col p-1">
                <span class="text-secondary-400 font-semibold">{{ i18n("land-cover-order") }}</span>
                <div
                    v-for="(land, index) in curParcelData.landCovers"
                    :key="index"
                    class="flex rounded justify-between w-full bg-bg-500 px-3 py-2 text-sm mt-1 font-semibold"
                >
                    {{ land.landCoverCode + (land.landCoverDescription ? ` - ${land.landCoverDescription}` : "") }}
                </div>
            </div>
            <div class="flex flex-col p-1">
                <span class="text-secondary-400 font-semibold">{{ i18n("percentage-conduction") }}</span
                ><span>{{ curParcelData.holdingPercentage }}&#37;</span>
            </div>
            <div class="flex flex-col p-1">
                <span class="text-secondary-400 font-semibold">{{ i18n("gis") }}</span>
                <abc-tag v-if="curParcelData.geom" class="rounded-tag my-2" type="success">
                    <template #icon><em class="fa-solid fa-check"></em></template>{{ i18n("agreement-status-available") }}
                </abc-tag>
                <abc-tag v-else class="rounded-tag my-2" type="danger">
                    <template #icon><em class="fa-sharp fa-solid fa-xmark-large"></em></template
                    >{{ upperCase(i18n("not-available")) }}
                </abc-tag>
            </div>
            <div v-if="curParcelData.hasUnimm != null" class="flex flex-col p-1">
                <span class="text-secondary-400 font-semibold">{{ i18n("unimm") }}</span>
                <abc-tag v-if="curParcelData.hasUnimm" class="rounded-tag my-2" type="success">
                    <template #icon><em class="fa-solid fa-check"></em></template>{{ i18n("agreement-status-available") }}
                </abc-tag>
                <abc-tag v-else class="rounded-tag my-2" type="danger">
                    <template #icon><em class="fa-sharp fa-solid fa-xmark-large"></em></template
                    >{{ upperCase(i18n("detail.data_not_present")) }}
                </abc-tag>
            </div>
            <div v-if="curParcelData.hasUnar != null" class="flex flex-col p-1">
                <span class="text-secondary-400 font-semibold">{{ i18n("unar") }}</span>
                <abc-tag v-if="curParcelData.hasUnar" class="rounded-tag my-2" type="success">
                    <template #icon><em class="fa-solid fa-check"></em></template>{{ i18n("agreement-status-available") }}
                </abc-tag>
                <abc-tag v-else class="rounded-tag my-2" type="danger">
                    <template #icon><em class="fa-sharp fa-solid fa-xmark-large"></em></template
                    >{{ upperCase(i18n("detail.data_not_present")) }}
                </abc-tag>
            </div>
            <div v-if="curParcelData.parcelType" class="flex flex-col p-1">
                <span class="text-secondary-400 font-semibold">{{ i18n("parcel-type") }}</span>
                <div class="flex items-center gap-2">
                    <div class="green-color h-8 w-8 rounded-full flex justify-center items-center text-xs my-2">
                        <em v-if="curParcelData.parcelType === 'URBAN'" class="far fa-building"></em>
                        <em v-if="curParcelData.parcelType === 'AGRICULTURAL'" class="far fa-leaf"></em>
                        <em v-if="curParcelData.parcelType === 'ROADS'" class="far fa-road"></em>
                        <em v-if="curParcelData.parcelType === 'WATERS'" class="far fa-droplet"></em>
                    </div>
                    <span>{{ curParcelData.parcelTypeDescription ? upperCase(curParcelData.parcelTypeDescription) : "" }}</span>
                </div>
            </div>
            <div v-if="curParcelData.holdingCount != null" class="flex flex-col p-1">
                <span class="text-secondary-400 font-semibold">{{ i18n("conduction-type") }}</span>
                <div class="flex items-center gap-2">
                    <div class="blue-color h-8 w-8 rounded-full flex justify-center items-center text-xs my-2">
                        <em v-if="curParcelData.holdingCount > 1" class="far fa-users"></em>
                        <em v-else class="far fa-user"></em>
                    </div>

                    <span>{{ curParcelData.holdingTypeDescription ? upperCase(curParcelData.holdingTypeDescription) : "" }}</span>
                </div>
            </div>
            <div class="flex p-1">
                <div class="flex flex-col flex-1">
                    <span class="text-secondary-400 font-semibold">{{ i18n("area") }}</span
                    ><span class="text-2xl"
                        ><strong>{{ formattedArea(curParcelData.areaSqm) }}</strong> ha</span
                    >
                </div>
                <div class="flex flex-col flex-1">
                    <span class="text-secondary-400 font-semibold">{{ i18n("holded-area") }}</span
                    ><span class="text-2xl"
                        ><strong>{{
                            formattedArea((curParcelData.areaSqm * curParcelData.holdingPercentage) / 100)
                        }}</strong>
                        ha</span
                    >
                </div>
            </div>
            <div v-if="curParcelData.anomalies.length > 0" class="flex flex-col p-1">
                <span class="text-secondary-400 font-semibold mb-2">{{ i18n("anomalies") }}</span>
                <div v-if="warningAnomalies.length > 0" class="bg-warning-100 w-full px-6 py-4 rounded-xl mb-2">
                    <div class="text-warning-600 text-xl font-bold">
                        <em class="text-warning-600 fa-regular fa-triangle-exclamation mr-5" />{{
                            i18n("warning-anomalies")
                        }}
                    </div>
                </div>
                <table aria-describedby="" style="border: none" cellspacing="0" cellpadding="0">
                    <tr v-for="w in warningAnomalies" :key="w.errorCode">
                        <td class="warning-bullet pr-2">&bull;</td>
                        <td>
                            {{ w.errorDescription ? w.errorDescription : w.errorCode }}
                        </td>
                    </tr>
                </table>
                <div v-if="blockingAnomalies.length > 0" class="bg-danger-100 w-full px-6 py-4 rounded-xl mb-2 mt-5">
                    <div class="text-danger-600 text-xl font-bold">
                        <em class="text-danger-600 fa-regular fa-circle-xmark mr-5" />{{ i18n("blocking-anomalies") }}
                    </div>
                </div>
                <table aria-describedby="" style="border: none" cellspacing="0" cellpadding="0">
                    <tr v-for="b in blockingAnomalies" :key="b.errorCode">
                        <td class="blocking-bullet pr-2">&bull;</td>
                        <td>
                            {{ b.errorDescription ? b.errorDescription : b.errorCode }}
                        </td>
                    </tr>
                </table>
            </div>
        </div>
    </layout>
</template>

<script lang="ts">
import { Component, Inject, Mixins } from "vue-property-decorator";
import { TranslateResult } from "vue-i18n";
import Layout from "../private/mapSidebarModal.vue";
import { MODULE_ID } from "../..";
import { FromStore } from "@abaco/web-common/src/app";
import { CadastralData, ParcelData } from "../../models/Declaration";
import { upperCaseFirstChar } from "../../api/Utils";
import AreaUtils from "../../mixins/AreaUtils";

@Component({
    components: {
        Layout,
    },
})
export default class SingleCpParcelInfo extends Mixins(AreaUtils) {
    @Inject() i18n!: (key: string, values?: unknown) => TranslateResult;

    @FromStore(MODULE_ID) curCadastralData!: CadastralData | null;
    @FromStore(MODULE_ID) curParcelData!: ParcelData | null;

    private upperCase(s: string) {
        return upperCaseFirstChar(s);
    }

    private get blockingAnomalies() {
        return this.curParcelData?.anomalies.filter((it) => it.blocking);
    }

    private get warningAnomalies() {
        return this.curParcelData?.anomalies.filter((it) => !it.blocking);
    }
}
</script>

<style lang="scss" scoped>
.rounded-tag {
    border-radius: 12px;
    min-width: 108px;
    max-width: fit-content;
}

.green-color {
    background-color: var(--success-100);
    color: var(--success-500);
}
.blue-color {
    background-color: var(--info-100);
    color: var(--info-500);
}
</style>
