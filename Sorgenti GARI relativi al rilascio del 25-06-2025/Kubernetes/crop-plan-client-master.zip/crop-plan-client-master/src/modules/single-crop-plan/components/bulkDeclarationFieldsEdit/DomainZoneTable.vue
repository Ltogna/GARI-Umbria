<template>
    <div>
        <h4 v-if="title" class="my-5 font-bold">{{ title }}</h4>
        <abc-table v-if="domainZoneList.length > 0" :items="uniqueDomainZones" item-id="domainZoneTableId">
            <template #headers>
                <th id="toggle-all-domainZone-action">
                    <abc-checkbox :value="allDomainZonesSelected" @input="onDomainZonesSelect()"></abc-checkbox>
                </th>
                <th id="domainZone_code_description">{{ i18n("domain-zone-code-description") }}</th>
            </template>
            <template #items="{ item }">    
                <td>
                    <abc-checkbox v-model="item._selected"></abc-checkbox>
                </td>
                <td class="cursor-pointer">
                    {{ item.description }}
                </td>
            </template>
        </abc-table>
        <abc-no-data-found v-else />
    </div>
</template>

<script lang="ts">
import { Component, Inject, Prop, Watch } from "vue-property-decorator";
import { TranslateResult } from "vue-i18n";
import { MODULE_ID } from "../..";
import SingleCropPlanModule from "../..";
import { DomainZoneListItem } from "../../models/CropPlan";
import Vue from "vue";

@Component({
    components: {},
})
export default class DomainZoneTable extends Vue {
    @Inject() i18n!: (key: string, values?: unknown) => TranslateResult;
    @Inject(MODULE_ID) singleCropPlanModule!: SingleCropPlanModule;

    @Prop({ default: [] }) uniqueDomainZones!: DomainZoneListItem[];
    @Prop({ default: null }) title!: string | null;

    private domainZoneList: DomainZoneListItem[] = [];

    mounted() {
        this.domainZoneList = this.uniqueDomainZones;
    }

    private get allDomainZonesSelected() {
        return this.domainZoneList.every((l) => l._selected);
    }

    onDomainZonesSelect() {
        const someNotSelected = this.uniqueDomainZones.some((l) => !l._selected);
        this.domainZoneList.forEach((l) => {
            l._selected = someNotSelected;
        });
    }

    @Watch("domainZoneList", { deep: true, immediate: true })
    onDomainZoneListChange(newVal: DomainZoneListItem[], oldVal: DomainZoneListItem[]) {
        if (!oldVal) {
            return;
        }
        this.$emit("domainZoneListChange", newVal);
    }
}
</script>