<template>
    <crop-plan-can-not-edit-modal-warning
        v-if="hasPlotsWithNonEditableDecls"
        :editabilityCheck="'NOT_EDITABLE'"
        :value="true"
        @input="onCpEditWarningModalUpdate"
    />
    <abc-modal v-else :title="i18n('complete-with-tara')" @close="$emit('close')">
        <template #body>
            <abc-loader v-if="isLoading" />
            <template v-else>
                <abc-form ref="form">
                    <abc-switch :label="i18n('auto-fill-tara')" v-model="autoFill" />
                    <abc-date-input
                        v-if="!autoFill"
                        ref="planting-date"
                        :label="i18n('start-date-first')"
                        v-model="fromDate"
                        :range-min="plantingMin"
                        :range-max="plantingMax"
                        hide-delete
                        :rules="[mandatoryRuleAtomic, plantingDateGreaterThanPlotDateRule]"
                        class="mt-4"
                    />
                    <abc-date-input
                        v-if="!autoFill"
                        ref="harvest-date"
                        :label="i18n('end-date-first')"
                        v-model="toDate"
                        :initial-date-ref="fromDate"
                        :range-min="harvestMin"
                        :range-max="harvestMax"
                        hide-delete
                        :rules="[mandatoryRuleAtomic, harvestingDateLesserThanPlotDateRule]"
                        class="mt-4"
                    />
                </abc-form>
                <crop-plan-post-edit-messages-modal :messages="validationMessages" @proceedAnyWay="sendRequest(true)" />
                <app-loading-modal v-if="saving" />
            </template>
        </template>
        <template #footer>
            <abc-button class="mr-2" is-secondary is-outlined :is-disabled="isLoading" @click="$emit('close')">
                <em class="abc-icon abc-icon-arrow-left-round" /> {{ i18n("back") }}
            </abc-button>
            <abc-button :is-disabled="isLoading" @click="sendRequest" is-danger>
                <em class="fal fa-puzzle pr-1" />
                {{ i18n("complete-with-tara") }}
            </abc-button>
        </template>
    </abc-modal>
</template>

<script lang="ts">
import { Vue, Component, Inject, Watch, Ref } from "vue-property-decorator";
import { TranslateResult } from "vue-i18n";
import { FromStore, ToastOptions } from "@abaco/web-common/src/app";
import { MODULE_ID } from "../..";
import { Plot } from "../../models/Plot";
import SingleCropPlanModule from "../..";
import { Business } from "../../models/Business";
import { CropPlan, Configuration, CompleteWithTareDates } from "../../models/CropPlan";
import { Validable } from "@abaco/web-components/src/components/form/Validable";
import AbcInput from "@abaco/web-components/src/components/input/AbcInput.vue";
import { Council } from "../../models/Council";
import CropPlanCanNotEditModalWarning from "./cropPlanCanNotEditModalWarning.vue";
import CropPlanPostEditMessagesModal from "./cropPlanPostEditMessagesModal.vue";
import { ValidationMessage } from "../../models/Utils";
import AppLoadingModal from "./appLoadingModal.vue";
import { convertToDate } from "../../api/Utils";

@Component({
    components: {
        CropPlanCanNotEditModalWarning,
        CropPlanPostEditMessagesModal,
        AppLoadingModal,
    },
})
export default class PlotCompleteTaraModal extends Vue {
    @Inject(MODULE_ID) singleCropPlanModule!: SingleCropPlanModule;
    @Inject() i18n!: (key: string, values?: unknown) => TranslateResult;
    @Inject() toast!: (message: string, options?: ToastOptions) => TranslateResult;

    @FromStore(MODULE_ID) curPointInTime!: Date;
    @FromStore(MODULE_ID) business!: Business;
    @FromStore(MODULE_ID) curCropPlan!: CropPlan | null;
    @FromStore(MODULE_ID) curCouncil!: Council;
    @FromStore(MODULE_ID) curConfiguration!: Configuration | null;
    @FromStore(MODULE_ID) curPlot!: Plot | null;
    @FromStore(MODULE_ID) curPlots!: Plot[];
    @FromStore(MODULE_ID) plotsForceReload!: number;
    // Only for force dismiss on beforeMount if an error has been encountered
    @FromStore(MODULE_ID) openPlotCompleteTaraModal!: boolean;

    @Ref("form") form!: Validable;
    @Ref("planting-date") plantingDateInput!: AbcInput;
    @Ref("harvest-date") harvestDateInput!: AbcInput;

    private fromDate: Date | null = null;
    private toDate: Date | null = null;
    private completeWithTareDates: CompleteWithTareDates | null = null;

    private autoFill = true;
    private isLoading = false;
    private saving = false;

    private validationMessages: ValidationMessage[] = [];

    async beforeMount() {
        try {
            this.isLoading = true;
            if (this.curCropPlan) {
                this.completeWithTareDates = await this.singleCropPlanModule.cropPlanApi.completeWithTareDates(
                    this.business.businessId,
                    this.curCropPlan.cropPlanId,
                    this.curCouncil.domainZoneId,
                    this.selectedPlots.map((p) => p.plotCode),
                    this.curPointInTime
                );
            }
        } catch (error) {
            const errorCode = (error as any).response?.data?.errorCode;
            let errorMessage: string = this.i18n("generic-error").toString(); // Generic error as default

            if (errorCode)
                // if errorCode handled, update errorMessage
                switch (errorCode) {
                    case "INVALID_DECLARATION_DATES_EXCEPTION":
                        errorMessage = this.i18n("swap-landuse-error-dates-invalid").toString();
                        break;
                    case "INCOMPATIBLE_LAND_USE_EXCEPTION":
                        errorMessage = this.i18n("tara-error-incompatible-land-use").toString();
                        break;
                    case "PLOT_NOT_EMPTY_AT_NEW_DECL_DATES_EXCEPTION":
                        errorMessage = this.i18n("swap-landuse-error-plot-notempty-date").toString();
                        break;
                }
            this.toast(errorMessage, { type: "error", duration: 4000 });

            // Force dismiss modal
            this.openPlotCompleteTaraModal = false;
        }

        this.isLoading = false;
    }

    private get hasPlotsWithNonEditableDecls() {
        return this.selectedPlots.some((p) => p.editability == "NOT_EDITABLE");
    }

    private get selectedPlots() {
        return this.curPlot ? [...this.curPlots, this.curPlot] : this.curPlots;
    }

    // private get dateRange() {
    //     let maxPlotStart: Date | null = null,
    //         minPlotEnd: Date | null = null;
    //     //
    //     this.selectedPlots.forEach((fPlot) => {
    //         if (!maxPlotStart || fPlot.fromDate > maxPlotStart) maxPlotStart = fPlot.fromDate;
    //         if (!minPlotEnd || fPlot.toDate < minPlotEnd) minPlotEnd = fPlot.toDate;
    //     });
    //     //
    //     if (
    //         !this.curConfiguration?.CONSTRAINTS_DECLS_TO_PLOTS ||
    //         this.curConfiguration.CONSTRAINTS_DECLS_TO_PLOTS === "TRUE"
    //     ) {
    //         return {
    //             plantingMin: maxPlotStart ? new Date((maxPlotStart as Date).getTime() + 1) : null,
    //             plantingMax: minPlotEnd ? new Date((minPlotEnd as Date).getTime() - 1) : null,
    //             harvestMin: this.fromDate,
    //             harvestMax: minPlotEnd ? new Date((minPlotEnd as Date).getTime() - 1) : null,
    //         };
    //     }
    //     const harvestMin = maxPlotStart ? new Date((maxPlotStart as Date).getTime() + 1) : null;
    //     return {
    //         plantingMin: null,
    //         plantingMax: minPlotEnd ? new Date((minPlotEnd as Date).getTime() - 1) : null,
    //         harvestMin:
    //             this.fromDate && (!harvestMin || harvestMin < new Date(this.fromDate)) ? this.fromDate : harvestMin,
    //         harvestMax: null,
    //     };
    // }

    private get plantingMin() {
        if (this.completeWithTareDates) {
            const minFromDate = convertToDate(this.completeWithTareDates.minFromDate);

            return minFromDate ? new Date(minFromDate?.getTime() - 1) : null;
        }

        return null;
    }

    private get plantingMax() {
        if (this.toDate) return new Date(this.toDate.getTime() + 1);

        if (this.harvestMax) return this.harvestMax;

        return null;
    }

    private get harvestMin() {
        if (this.fromDate) return new Date(this.fromDate.getTime() - 1);

        if (this.plantingMin) return this.plantingMin;

        return null;
    }

    private get harvestMax() {
        if (this.completeWithTareDates) {
            const maxToDate = convertToDate(this.completeWithTareDates.maxToDate);

            return maxToDate ? new Date(maxToDate?.getTime() + 1) : null;
        }

        return null;
    }

    private mandatoryRuleAtomic = (v: unknown) => !!v || this.i18n("valid.mandatory-field");

    private plantingDateGreaterThanPlotDateRule(e: any | null): string | null {
        let curDate = e;
        if (e && typeof e.getMonth !== "function") {
            curDate = new Date(e.substring(6), e.substring(3, 5) - 1, e.substring(0, 2));
        }
        let res = null;
        if (curDate && this.plantingMin && curDate.getTime() < this.plantingMin.getTime()) {
            res = this.i18n("planting-date-greater-than-plot-date").toString();
        }
        return res;
    }

    private harvestingDateLesserThanPlotDateRule(e: any | null): string | null {
        let curDate = e;
        if (e && typeof e.getMonth !== "function") {
            curDate = new Date(e.substring(6), e.substring(3, 5) - 1, e.substring(0, 2));
        }
        let res = null;
        if (curDate && this.harvestMax && curDate.getTime() > this.harvestMax.getTime()) {
            res = this.i18n("harvesting-date-lesser-than-plot-date").toString();
        }
        return res;
    }

    private async sendRequest(ignoreWarning = false) {
        if (this.plantingDateInput) (this.plantingDateInput as any).runInputRules();
        if (this.harvestDateInput) (this.harvestDateInput as any).runInputRules();
        //
        const fromDate =
            this.autoFill && this.completeWithTareDates
                ? convertToDate(this.completeWithTareDates.minFromDate)
                : this.fromDate;
        const toDate =
            this.autoFill && this.completeWithTareDates
                ? convertToDate(this.completeWithTareDates.maxToDate)
                : this.toDate;
        //
        if (this.form.validate() && fromDate && toDate && this.curCropPlan) {
            this.saving = true;
            try {
                await this.singleCropPlanModule.cropPlanApi.completeWithTare(
                    this.business.businessId,
                    this.curCropPlan.cropPlanId,
                    this.curCouncil.domainZoneId,
                    this.selectedPlots.map((p) => p.plotCode),
                    fromDate,
                    toDate,
                    this.curPointInTime,
                    ignoreWarning
                );
                //
                if (this.validationMessages.length) {
                    this.saving = false;
                    return null;
                }
                //
                this.toast(this.i18n("complete-with-tara-success").toString(), { type: "success" });
                this.plotsForceReload++;
                this.$emit("update");
            } catch (error) {
                const errorCode = (error as any).response?.data?.errorCode;
                let errorMessage: string = this.i18n("generic-error").toString(); // Generic error as default

                if (errorCode)
                    // if errorCode handled, update errorMessage
                    switch (errorCode) {
                        case "INVALID_DECLARATION_DATES_EXCEPTION":
                            errorMessage = this.i18n("swap-landuse-error-dates-invalid").toString();
                            break;
                        case "INCOMPATIBLE_LAND_USE_EXCEPTION":
                            errorMessage = this.i18n("tara-error-incompatible-land-use").toString();
                            break;
                        case "PLOT_NOT_EMPTY_AT_NEW_DECL_DATES_EXCEPTION":
                            errorMessage = this.i18n("swap-landuse-error-plot-notempty-date").toString();
                            break;
                    }
                this.toast(errorMessage, { type: "error", duration: 4000 });
            }
            this.saving = false;
        }
    }

    private onCpEditWarningModalUpdate() {
        // it means the user has clicked on "cancel" in the warning modal so we close
        if (this.hasPlotsWithNonEditableDecls) this.$emit("close");
    }

    @Watch("fromDate")
    private onFromDateUpdate() {
        if (this.fromDate == null || (this.toDate && this.fromDate >= this.toDate)) this.toDate = null;
    }
}
</script>
