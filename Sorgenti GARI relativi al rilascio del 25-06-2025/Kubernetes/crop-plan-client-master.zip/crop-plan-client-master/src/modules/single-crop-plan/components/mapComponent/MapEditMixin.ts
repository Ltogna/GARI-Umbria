import AbcVectorLayer, { VectorLayerDef } from "@abaco/iacs-map-module/src/modules/map-module/Layer/AbcVectorLayer";
import DrawMixin from "@abaco/iacs-map-module/src/modules/map-module/mixins/DrawMixin";
import { MapFunctions } from "@abaco/iacs-map-module/src/modules/map-module/models/AbcMap";
import { FromStore } from "@abaco/web-common/src/app";
import { Feature } from "ol";
import { Vector as VectorSource } from "ol/source";
import { Vector as VectorLayer } from "ol/layer";
import { Geometry, Polygon, LineString, MultiPolygon, MultiLineString } from "ol/geom";
import OverlayOp from "jsts/org/locationtech/jts/operation/overlay/OverlayOp";
import WKTParser from "jsts/org/locationtech/jts/io/WKTParser";
import { TranslateResult } from "vue-i18n";
import { Component, Inject, Mixins, Watch } from "vue-property-decorator";
import SingleCropPlan from "../..";
import { Business } from "../../models/Business";
import { Council, SubdomainZone } from "../../models/Council";
import { CropPlan, CropPlanDates } from "../../models/CropPlan";
import {
    EditPlotMode,
    Plot,
    PlotBehaviour,
    PlotOut,
    PlotPreview,
    PlotPreviewDiff,
    PlotResponseDiff,
    BufferBehaviour,
    PlotStyleOverride,
    CuttableLayer,
} from "../../models/Plot";
import { ValidationMessage } from "../../models/Utils";
import { Version } from "../../models/Version";
import { Declaration, TimelineSection } from "../../models/Declaration";
import { includes } from "lodash";
import { SnapGeometryDef } from "../../models/Layer";
import GenericLayer from "@abaco/iacs-map-module/src/modules/map-module/Layer/GenericLayer";

@Component
export default class MapEditMixin extends Mixins(DrawMixin) {
    @Inject() i18n!: (key: string, values?: unknown) => TranslateResult;
    @Inject(SingleCropPlan.MODULE_ID) singleCropPlan!: SingleCropPlan;
    @FromStore(SingleCropPlan.MODULE_ID) forceStartEditing!: number;
    @FromStore(SingleCropPlan.MODULE_ID) forceStartDrawing!: number;

    JSTSWktParser = new WKTParser();

    protected map!: MapFunctions;
    protected snapLayers: AbcVectorLayer[] = [];
    protected plotsLayer: AbcVectorLayer | null = null;
    protected curPlotOut: PlotOut | null = null;
    protected curBehaviour = PlotBehaviour.CUT_ON_EXISTING;
    protected possibleBehaviour = Object.keys(PlotBehaviour);
    protected helperMessage: TranslateResult = "";
    protected initialMessage: TranslateResult = "";
    protected notificationMessage: { type: "info" | "error" | "success"; label: TranslateResult } | null = null;
    protected disableSave = true;
    protected loadingPreview = false;
    protected saving = false;

    protected bufferBehaviour: BufferBehaviour = "INTERNAL";
    protected bufferSize: number | null = null;
    protected bufferPosition: "CENTER" | "RIGHT" | "LEFT" = "CENTER";
    protected plotBufferSize: number | null = null;

    protected layerForCuttingPlots: string | null = null;
    protected snapGeometries: SnapGeometryDef | null = null;
    protected additionalLayers: GenericLayer[] = [];
    protected cuttableLayers: CuttableLayer[] = [];
    protected cuttableLayersLoading = false;
    private validationMessages: ValidationMessage[] = [];

    @FromStore(SingleCropPlan.MODULE_ID) business!: Business;
    @FromStore(SingleCropPlan.MODULE_ID) curCropPlan!: CropPlan;
    @FromStore(SingleCropPlan.MODULE_ID) curCouncil!: Council;
    @FromStore(SingleCropPlan.MODULE_ID) curPointInTime!: Date;
    @FromStore(SingleCropPlan.MODULE_ID) cropPlanDates!: CropPlanDates;
    @FromStore(SingleCropPlan.MODULE_ID) domain!: Date;
    @FromStore(SingleCropPlan.MODULE_ID) curVersion!: Version;
    @FromStore(SingleCropPlan.MODULE_ID) plots!: Plot[];
    @FromStore(SingleCropPlan.MODULE_ID) curPlot!: Plot | null;
    @FromStore(SingleCropPlan.MODULE_ID) curPlots!: Plot[];
    @FromStore(SingleCropPlan.MODULE_ID) editPlotMode!: EditPlotMode;
    @FromStore(SingleCropPlan.MODULE_ID) lastEditPlotMode!: EditPlotMode | null;
    @FromStore(SingleCropPlan.MODULE_ID) forcePlotModeReset!: boolean;
    @FromStore(SingleCropPlan.MODULE_ID) plotsStyleOverride!: PlotStyleOverride[];

    @FromStore(SingleCropPlan.MODULE_ID) flCurCorpPlanChangesPending!: boolean;
    @FromStore(SingleCropPlan.MODULE_ID) hasCoveredByInserted!: boolean;
    @FromStore(SingleCropPlan.MODULE_ID) openEditTile!: boolean;
    @FromStore(SingleCropPlan.MODULE_ID) newDeclEditOpened!: boolean;
    @FromStore(SingleCropPlan.MODULE_ID) calcCoveredByInsertedOnCutOnLayer!: boolean;
    @FromStore(SingleCropPlan.MODULE_ID) curTimelineSection!: TimelineSection | null;
    @FromStore(SingleCropPlan.MODULE_ID) curDeclaration!: Declaration | null;
    @FromStore(SingleCropPlan.MODULE_ID) subdomainZone!: SubdomainZone;

    // @FromStore(SingleCropPlan.MODULE_ID) enableDefaultNotPreserveDeclsOnPlotsMerge!: boolean;

    private previewLayer: AbcVectorLayer | null = null;
    private previewLayerDiff: PlotPreviewDiff | null = null;
    private multiselectPreviewLayer: AbcVectorLayer | null = null;
    private multiselectionIntersectedPlots: Plot[] = [];

    private get snappableLayers() {
        const res = this.snapLayers.filter((sl) => sl.layerDef.on);
        if (this.plotsLayer?.layerDef.on) {
            res.push(this.plotsLayer);
        }
        return res;
    }

    private get plotCodes() {
        let res: string[] | null = [];
        if (this.curPlots.length) {
            res = this.curPlots.map((p) => p.plotCode);
        }
        if (this.curPlot) {
            res.push(this.curPlot.plotCode);
        }
        if (res.length === 0) {
            res = null;
        }
        return res;
    }

    private get plotCodesWithoutCurPlot() {
        return this.curPlots.map((p) => p.plotCode);
    }

    private get plotPreviews() {
        let res: PlotPreview[] = [];
        if (this.multiplePreviewWkt.length) {
            res = this.multiplePreviewWkt.map((p) => ({ plotCode: p.id, geom: p.wkt }));
        }
        return res;
    }

    private getMergeGeomsOnCutOnLayer(snapElementType: string) {
        const layerType = this.cuttableLayers?.find((sg) => sg.layerCode == snapElementType);
        return layerType?.flMergeGeomsOnCutOnLayer || false;
    }

    private getCalcCoveredByInsertedOnCutOnLayer(snapElementType: string) {
        const layerType = this.cuttableLayers?.find((sg) => sg.layerCode == snapElementType);
        return layerType?.flCalcCoveredByInsertedOnCutOnLayer || false;
    }

    beforeDestroy() {
        if (this.editPlotMode !== EditPlotMode.NOT_SELECTED) this.cancel();
    }

    @Watch("plotCodes")
    onPlotCodesChange() {
        if (this.editPlotMode === EditPlotMode.MERGING) {
            this.startMerging();
            return;
        }
        this.cancel();
    }

    @Watch("previewWkt")
    @Watch("curBehaviour")
    onPreviewWkt() {
        if (!this.previewWkt) {
            if (this.previewLayer) {
                this.map.removeMapLayer(this.previewLayer.layerId);
            }
            if (this.multiselectPreviewLayer) {
                this.map.removeMapLayer(this.multiselectPreviewLayer.layerId);
            }
            return;
        }
        if (this.editPlotMode === EditPlotMode.MULTISELECTION) {
            this.handleMultiselectionPreview(this.previewWkt);
            return;
        }
        if (this.editPlotMode === EditPlotMode.CUTTING) {
            this.handleCuttingPreview(this.previewWkt);
            return;
        }
        if (this.editPlotMode === EditPlotMode.ADDING || this.editPlotMode === EditPlotMode.EDITING) {
            this.handleDrawingPreview(this.previewWkt);
        }
        if (this.editPlotMode === EditPlotMode.ADDING_BUFFER) {
            this.handleBufferPreview(this.previewWkt);
        }
    }

    @Watch("multiplePreviewWkt")
    @Watch("curBehaviour")
    private onMultiplePreviewWkt() {
        if (this.curPlots.length === 0 || this.editPlotMode !== EditPlotMode.EDITING) {
            return;
        }
        if (this.multiplePreviewWkt.length === 0) {
            if (this.previewLayer) {
                this.map.removeMapLayer(this.previewLayer.layerId);
            }
            if (this.multiselectPreviewLayer) {
                this.map.removeMapLayer(this.multiselectPreviewLayer.layerId);
            }
            return;
        }
        this.getEditMultiplePreview();
    }

    @Watch("editPlotMode")
    onEditPlotMode() {
        if (this.editPlotMode) {
            this.plotsLayer?.buildedLayer.changed();
        }
        switch (this.editPlotMode) {
            case EditPlotMode.ADDING:
                // this.startDrawing();
                break;
            case EditPlotMode.EDITING:
                console.info("Cutting mode");
                // this.startEditing();
                break;
            case EditPlotMode.MULTISELECTION:
                this.startMultiselection();
                console.info("Multiselecion mode");
                break;
            case EditPlotMode.CUTTING:
                console.info("Cutting mode");
                break;
            case EditPlotMode.MERGING:
                console.info("Merging mode");
                break;
            case EditPlotMode.DELETING:
                console.info("Deleting mode");
                break;
            case EditPlotMode.RESTORING:
                console.info("Restoring plot: " + this.curPlot?.plotCode);
                break;
            case EditPlotMode.ADDING_BUFFER:
                console.info("Buffer Add mode");
                break;
            default:
                this.cancel();
                break;
        }
    }

    @Watch("bufferSize")
    @Watch("bufferPosition")
    private refreshBufferPreview() {
        if (this.editPlotMode === EditPlotMode.ADDING_BUFFER && this.previewWkt)
            this.handleBufferPreview(this.previewWkt);
    }

    protected async saveDrawing(ignoreWarning = false, callback?: (submitResults: string[] | null) => {}) {
        this.saving = true;
        let submitResult: string[] | null = null;
        try {
            switch (this.editPlotMode) {
                case EditPlotMode.ADDING:
                    submitResult = await this.insertNewPlot(ignoreWarning);
                    break;
                case EditPlotMode.EDITING:
                    submitResult = await this.updatePlot(ignoreWarning);
                    break;
                case EditPlotMode.MULTISELECTION:
                    this.doMultiselectionPlots();
                    break;
                case EditPlotMode.CUTTING:
                    submitResult = await this.doCut(ignoreWarning);
                    break;
                case EditPlotMode.MERGING:
                    submitResult = await this.doMerge(ignoreWarning);
                    break;
                case EditPlotMode.ADDING_BUFFER:
                    submitResult = await this.insertBuffer(ignoreWarning);
                    break;
                default:
                    submitResult = null;
                    this.cancel();
                    break;
            }
        } catch (error) {
            console.error(error);
        } finally {
            if (submitResult !== null) {
                this.forcePlotModeReset = true;
                this.lastEditPlotMode = null;
                this.cancel();
            }
            this.saving = false;
            if (callback !== undefined) {
                callback(submitResult);
            }
        }
    }

    @Watch("cropPlanDates.referenceDate", { deep: true })
    @Watch("business")
    @Watch("curCouncil")
    protected cancel() {
        if (this.forcePlotModeReset || this.lastEditPlotMode === null) {
            this.cancelDraw();
            this.editPlotMode = this.lastEditPlotMode || EditPlotMode.NOT_SELECTED;
            this.lastEditPlotMode = null;
            this.forcePlotModeReset = false;

            this.helperMessage = "";
            this.initialMessage = "";
            this.notificationMessage = null;
            this.previewLayerDiff = null;
            this.multiselectionIntersectedPlots = [];
            if (this.previewLayer) {
                this.map.removeMapLayer(this.previewLayer.layerId);
            }
            if (this.multiselectPreviewLayer) {
                this.map.removeMapLayer(this.multiselectPreviewLayer.layerId);
            }
        }
    }

    @Watch("layerForCuttingPlots")
    private onlayerForCuttingPlotsUpdate() {
        if (this.editPlotMode !== EditPlotMode.CUTTING) return;
        this.disableSave = true;
        if (this.layerForCuttingPlots) {
            this.cancelDraw();
            this.previewLayerDiff = null;
            if (this.previewLayer) this.map.removeMapLayer(this.previewLayer.layerId);
            if (this.multiselectPreviewLayer) this.map.removeMapLayer(this.multiselectPreviewLayer.layerId);

            const flMergeGeomsOnCutOnLayer = this.getMergeGeomsOnCutOnLayer(this.layerForCuttingPlots);
            const calcCoveredByInsertedOnCutOnLayer = this.getCalcCoveredByInsertedOnCutOnLayer(this.layerForCuttingPlots);
            this.handleCuttingGeometriesPreview(flMergeGeomsOnCutOnLayer, calcCoveredByInsertedOnCutOnLayer);
        } else {
            this.cancel();
            this.startCutting();
        }
    }

    @Watch("forceStartDrawing")
    protected startDrawing() {
        if (!this.plotsLayer) return;
        this.editPlotMode = EditPlotMode.ADDING;
        //
        this.curPlotOut = {
            fromPointInTime: this.curPointInTime,
            description: "",
            geom: "",
            cutParameters: {
                behaviour: PlotBehaviour.CUT_ON_EXISTING,
                plotCodes: this.plotCodes,
            },
        };
        //
        this.initialMessage = this.i18n("helper-map-message.start-drawing-plot");
        this.helperMessage = this.initialMessage;
        this.notificationMessage = null;
        this.draw(
            "Polygon",
            this.snappableLayers.map((sl) => sl.buildedLayer)
        );
    }

    @Watch("forceStartEditing")
    protected startEditing() {
        this.editPlotMode = EditPlotMode.EDITING;
        this.curPlotOut = {
            fromPointInTime: this.curPointInTime,
            geom: this.curPlot?.geom || "",
            cutParameters: {
                behaviour: PlotBehaviour.CUT_ON_EXISTING,
                plotCodes: null,
            },
        };
        //
        let mainFeature;
        let features: Feature<Geometry>[] = [];
        if (this.curPlot) {
            mainFeature = this.WKTParser.readFeature(this.curPlot.geom, this.curPlot.plotCode);
            features = [mainFeature];
        }
        if (this.curPlots.length) {
            this.initialMessage = this.i18n("helper-map-message.start-editing-plots");
            this.helperMessage = this.initialMessage;
            this.notificationMessage = null;
            this.editDraw(
                "Polygon",
                [...features, ...this.curPlots.map((p) => this.WKTParser.readFeature(p.geom, p.plotCode))],
                this.snappableLayers.map((sl) => sl.buildedLayer)
            );
            return;
        }
        if (mainFeature) {
            this.initialMessage = this.i18n("helper-map-message.start-editing-plot");
            this.helperMessage = this.initialMessage;
            this.notificationMessage = null;
            this.editDraw(
                "Polygon",
                mainFeature,
                this.snappableLayers.map((sl) => sl.buildedLayer)
            );
        }
    }

    protected startDrawFromErased() {
        if (!this.plotsLayer) return;
        //
        this.curPlotOut = {
            fromPointInTime: this.curPointInTime,
            description: "",
            geom: "",
            cutParameters: {
                behaviour: PlotBehaviour.CUT_ON_EXISTING,
                plotCodes: this.plotCodes,
            },
        };
        //
        this.initialMessage = this.i18n("helper-map-message.start-drawing-plot");
        this.helperMessage = this.initialMessage;
        this.notificationMessage = null;
        this.draw(
            "Polygon",
            this.snappableLayers.map((sl) => sl.buildedLayer)
        );
    }

    protected startMultiselection() {
        this.editPlotMode = EditPlotMode.MULTISELECTION;
        this.initialMessage = this.i18n("helper-map-message.start-multiselection");
        this.helperMessage = this.initialMessage;
        this.layerForCuttingPlots = null;
        this.notificationMessage = null;
        this.draw(
            "Polygon",
            this.snappableLayers.map((sl) => sl.buildedLayer)
        );
    }

    protected startCutting() {
        this.editPlotMode = EditPlotMode.CUTTING;
        this.initialMessage = this.i18n("helper-map-message.start-cutting");
        this.helperMessage = this.initialMessage;
        this.layerForCuttingPlots = null;
        this.notificationMessage = null;
        if (this.curPlot || this.curPlots.length) {
            this.loadCuttableLayers().then((cuttableLayers) => {
                this.cuttableLayers = cuttableLayers;
            });
        }
        this.draw(
            "LineString",
            this.snappableLayers.map((sl) => sl.buildedLayer)
        );
    }

    protected async startMerging() {
        if (!this.curPlot || this.curPlots.length === 0) {
            console.error("Select at least one plot");
            this.cancel();
            return;
        }
        this.editPlotMode = EditPlotMode.MERGING;
        //
        this.callPreviewApi(() =>
            this.curPlot
                ? this.singleCropPlan.plotApi.mergePlotsPreview(
                    this.business.businessId,
                    this.curCropPlan.cropPlanId,
                    this.curCouncil.domainZoneId,
                    this.curPointInTime,
                    this.curPlot.plotCode,
                    this.plotCodesWithoutCurPlot,
                    this.curCouncil.bigDomainZone ? this.subdomainZone.id : undefined
                )
                : new Promise<PlotPreviewDiff>(() => undefined)
        );
    }

    protected startAddingBuffer() {
        let selectionPolygon: Polygon | null = null;
        if (this.curPlots.length) {
            const geomList = (this.curPlot ? [this.curPlot, ...this.curPlots] : this.curPlots)
                .map((plot) => plot.geom)
                .filter((wkt) => this.WKTParser.readGeometry(wkt).getType() == "Polygon")
                .map((wkt) => this.JSTSWktParser.read(wkt));
            if (geomList.length) {
                let union = geomList.shift();
                geomList.forEach((geom) => {
                    if (!union) return;
                    union = OverlayOp.union(union, geom);
                });
                if (union) {
                    const unionGeom = this.WKTParser.readGeometry(this.JSTSWktParser.write(union));
                    if (["Polygon", "MultiPolygon"].includes(unionGeom.getType()))
                        selectionPolygon = unionGeom as Polygon;
                }
            }
        } else if (this.curPlot) {
            const plotGeom = this.WKTParser.readGeometry(this.curPlot.geom);
            if (["Polygon", "MultiPolygon"].includes(plotGeom.getType())) selectionPolygon = plotGeom as Polygon;
        }
        //
        if (this.bufferBehaviour != "FREE_DRAW" && !selectionPolygon) {
            console.error(
                `startAddingBuffer(mode: "${this.bufferBehaviour}") => No plots selected with valid geometry`
            );
            return this.cancel();
        }
        //
        this.cancelDraw();
        this.editPlotMode = EditPlotMode.ADDING_BUFFER;
        this.disableSave = true;
        //
        if (this.bufferBehaviour == "FREE_DRAW") {
            this.draw(
                "LineString",
                selectionPolygon
                    ? [
                        ...this.snappableLayers.map((sl) => sl.buildedLayer),
                        new VectorLayer({
                            source: new VectorSource({
                                features: [
                                    new Feature({
                                        geometry: selectionPolygon,
                                    }),
                                ],
                            }),
                        }),
                    ]
                    : this.snappableLayers.map((sl) => sl.buildedLayer)
            );
        } else if (selectionPolygon) {
            this.trace(selectionPolygon);
        }
    }

    private async handleDrawingPreview(previewWkt: string) {
        if (!this.curPlotOut) {
            return;
        }
        this.curPlotOut = {
            ...this.curPlotOut,
            geom: previewWkt,
            cutParameters: {
                plotCodes: this.plotCodes,
                behaviour: this.curBehaviour,
            },
        };

        if (this.editPlotMode === EditPlotMode.EDITING) {
            this.getEditPreview(this.curPlotOut);
            return;
        }
        this.getInsertPreview(this.curPlotOut);
    }

    private async handleMultiselectionPreview(previewWkt: string) {
        this.multiselectionIntersectedPlots = [];
        this.disableSave = true;
        for (const plot of this.plots) {
            try {
                const intersection = OverlayOp.intersection(
                    this.JSTSWktParser.read(plot.geom),
                    this.JSTSWktParser.read(previewWkt)
                );
                if (
                    !intersection.isEmpty() &&
                    intersection.getArea() >= 1 &&
                    !includes(this.multiselectionIntersectedPlots, plot)
                ) {
                    this.multiselectionIntersectedPlots.push(plot);
                }
            } catch (error) {
                console.warn(error);
            }
        }

        if (this.multiselectionIntersectedPlots.length) this.disableSave = false;

        const tmpDef: VectorLayerDef = {
            layerType: "VECTOR",
            layerId: "MULTISELECTION_PREVIEW",
            zIndex: 1000,
            isOverlay: true,
            features: this.plots.map((p: Plot) => {
                const styleOverride = this.plotsStyleOverride.find((o) => o.plotCode == p.plotCode);
                const isIntersected = this.multiselectionIntersectedPlots.find((mip) => p.plotCode === mip.plotCode);
                const defaultStyle: {
                    fillColor: string | CanvasPattern;
                    borderColor: string;
                } = {
                    borderColor: p.style.borderColor,
                    fillColor:
                        p.style.fillStyle == "stroke"
                            ? "transparent"
                            : p.style.fillColor.length === 9
                                ? p.style.fillColor
                                : p.style.fillColor + "30",
                };
                const intersectedStyle = {
                    borderColor: "#0d6977",
                    fillColor: "#0d697750",
                    width: 4,
                };

                return {
                    wkt: p.geom,
                    id: p.plotCode,
                    style: isIntersected ? intersectedStyle : styleOverride ? styleOverride.style : defaultStyle,
                };
            }),
            description: "Appezzamenti selezionati",
            on: true,
        };
        this.multiselectPreviewLayer = (await this.map.updateMapLayer(
            tmpDef,
            this.multiselectPreviewLayer?.layerId
        )) as AbcVectorLayer;
    }

    @Watch("drawing")
    private multiselectionForceEnableSave() {
        if (this.editPlotMode === EditPlotMode.MULTISELECTION && !this.drawing) {
            // Force disableSave to false
            this.disableSave = false;
        }
    }

    private async handleCuttingPreview(previewWkt: string) {
        this.callPreviewApi(() =>
            this.singleCropPlan.plotApi.cutPlotPreview(
                this.business.businessId,
                this.curCropPlan.cropPlanId,
                this.curCouncil.domainZoneId,
                this.curPointInTime,
                previewWkt,
                this.plotCodes,
                this.curCouncil.bigDomainZone ? this.subdomainZone.id : undefined
            )
        );
    }

    private async handleCuttingGeometriesPreview(flMergeGeomsOnCutOnLayer: boolean, calcCoveredByInsertedOnCutOnLayer: boolean) {
        if (this.layerForCuttingPlots !== null) {
            this.callPreviewApi(() =>
                this.singleCropPlan.plotApi.cutByLayerPreview(
                    this.business.businessId,
                    this.curCropPlan.cropPlanId,
                    this.curCouncil.domainZoneId,
                    this.curPointInTime,
                    this.layerForCuttingPlots!,
                    this.plotCodes,
                    flMergeGeomsOnCutOnLayer,
                    calcCoveredByInsertedOnCutOnLayer,
                    this.curCouncil.bigDomainZone ? this.subdomainZone.id : undefined
                )
            );
        }
    }

    private async handleBufferPreview(previewWkt: string) {
        if (!this.bufferSize) {
            console.error("No bufferSize selected");
            return;
        }
        //
        this.callPreviewApi(() =>
            this.bufferSize
                ? this.singleCropPlan.plotApi.insertBufferPreview(
                    this.business.businessId,
                    this.curCropPlan.cropPlanId,
                    this.curCouncil.domainZoneId,
                    this.curPointInTime,
                    previewWkt,
                    this.bufferSize,
                    this.bufferPosition,
                    this.bufferBehaviour,
                    this.plotCodes,
                    this.curCouncil.bigDomainZone ? this.subdomainZone.id : undefined
                )
                : new Promise<PlotPreviewDiff>(() => undefined)
        );
    }

    protected async requestEditPreview(plotOut: PlotOut) {
        return this.getEditPreview(plotOut);
    }

    private async getEditPreview(plotOut: PlotOut) {
        if (!this.curPlot || !this.curPlotOut) {
            console.error("Select at least one curPlot");
            return;
        }
        this.curPlotOut.cutParameters.plotCodes = null;
        this.callPreviewApi(() =>
            this.curPlot
                ? this.singleCropPlan.plotApi.editPlotPreview(
                    this.business.businessId,
                    this.curCropPlan.cropPlanId,
                    this.curCouncil.domainZoneId,
                    this.curPlot.plotCode,
                    plotOut,
                    this.curCouncil.bigDomainZone ? this.subdomainZone.id : undefined,
                    this.plotBufferSize ?? 0,
                )
                : new Promise<PlotPreviewDiff>(() => undefined)
        );
    }

    private async getEditMultiplePreview() {
        this.callPreviewApi(() =>
            this.singleCropPlan.plotApi.editMultiplePlotPreview(
                this.business.businessId,
                this.curCropPlan.cropPlanId,
                this.curCouncil.domainZoneId,
                this.curPointInTime,
                this.plotPreviews,
                this.curBehaviour,
                this.curCouncil.bigDomainZone ? this.subdomainZone.id : undefined
            )
        );
    }

    private async getInsertPreview(plotOut: PlotOut) {
        this.callPreviewApi(() =>
            this.singleCropPlan.plotApi.insertPlotPreview(
                this.business.businessId,
                this.curCropPlan.cropPlanId,
                this.curCouncil.domainZoneId,
                plotOut,
                this.curCouncil.bigDomainZone ? this.subdomainZone.id : undefined
            )
        );
    }

    private async callPreviewApi(previewCall: () => Promise<PlotPreviewDiff>) {
        let editModeAlias = this.editPlotMode.toString().toLowerCase();
        if (this.editPlotMode === EditPlotMode.CUTTING && this.layerForCuttingPlots)
            editModeAlias += "-by-layer";
        //
        this.previewLayerDiff = null;
        this.notificationMessage = null;
        this.helperMessage = this.initialMessage;
        try {
            this.loadingPreview = true;
            const res = await previewCall();
            if (res.added.length === 0 && res.updated.length === 0 && res.deleted.length === 0 && res.coveredByInserted.length === 0) {
                this.disableSave = true;
                this.notificationMessage = {
                    type: "error",
                    label: this.i18n(`helper-map-message.nothing-to-save-${editModeAlias}`),
                };
                this.buildPreviewLayer(res);
                return;
            }
            this.disableSave = false;
            this.helperMessage = this.i18n(`helper-map-message.save-${editModeAlias}-or-cancel`);
            this.buildPreviewLayer(res);
            this.previewLayerDiff = res;
        } catch (error) {
            this.disableSave = true;
            if (this.previewLayer) {
                this.map.removeMapLayer(this.previewLayer.layerId);
                this.previewLayer = null;
            }
            if (this.multiselectPreviewLayer) {
                this.map.removeMapLayer(this.multiselectPreviewLayer.layerId);
                this.multiselectPreviewLayer = null;
            }
            this.notificationMessage = {
                type: "error",
                label: this.i18n(`helper-map-message.invalid-${editModeAlias}`),
            };
        } finally {
            this.loadingPreview = false;
        }
    }

    private async buildPreviewLayer(previewResponse: PlotPreviewDiff) {
        //HERE
        if (!this.map) {
            return;
        }
        const coveredByInserted = [
            ...previewResponse.added.filter((a) => previewResponse.coveredByInserted.includes(a.plotCode)),
            ...previewResponse.updated.filter((a) => previewResponse.coveredByInserted.includes(a.plotCode)),
        ];
        const tmpDef: VectorLayerDef = {
            layerType: "VECTOR",
            layerId: "PREVIEW",
            zIndex: 1000,
            isOverlay: true,
            features: [
                // ...previewResponse.deleted.map(ad => ({
                //     wkt: this.plots.find(p => p.plotCode == ad)?.geom || "",
                //     id: ad,
                //     style: {
                //         borderColor: "red",
                //         fillColor: createDeleteIconCanvasPattern(),
                //         width: 2,
                //     },
                // })),
                ...previewResponse.updated
                    .filter((a) => !previewResponse.coveredByInserted.includes(a.plotCode))
                    .map((ad) => ({
                        wkt: ad.geom,
                        id: ad.plotCode,
                        style: {
                            borderColor: "#fdd24d",
                            fillColor: "#fdd24d80",
                            width: 4,
                        },
                    })),
                ...previewResponse.added
                    .filter((a) => !previewResponse.coveredByInserted.includes(a.plotCode))
                    .map((ad: PlotPreview, index: number) => ({
                        wkt: ad.geom,
                        id: index.toString(),
                        style: {
                            borderColor: "#0d6977",
                            fillColor: "#0d697750",
                            width: 4,
                        },
                    })),
                ...coveredByInserted.map((c) => ({
                    wkt: c.geom,
                    id: c.plotCode,
                    style: {
                        borderColor: "#0a515c",
                        fillColor: "#0a515c80",
                        width: 4,
                    },
                })),
            ],
            description: "Appezzamenti aggiunti",
            on: true,
        };
        this.previewLayer = (await this.map.updateMapLayer(tmpDef, this.previewLayer?.layerId)) as AbcVectorLayer;
    }

    private async insertNewPlot(ignoreWarning = false) {
        if (!this.curPlotOut) {
            return null;
        }
        return await this.doSubmit(
            (ignoreWarning) =>
                this.singleCropPlan.plotApi.insertPlot(
                    this.business.businessId,
                    this.curCropPlan.cropPlanId,
                    this.curCouncil.domainZoneId,
                    this.curPlotOut as PlotOut,
                    ignoreWarning,
                    this.curCouncil.bigDomainZone ? this.subdomainZone.id : undefined
                ),
            ignoreWarning
        );
    }

    private async updatePlot(ignoreWarning = false) {
        if (!this.curPlotOut || !this.curPlot) {
            return null;
        }
        //
        if (this.curPlots.length) {
            return await this.doSubmit(
                (ignoreWarning) =>
                    this.singleCropPlan.plotApi.editMultiplePlot(
                        this.business.businessId,
                        this.curCropPlan.cropPlanId,
                        this.curCouncil.domainZoneId,
                        this.curPointInTime,
                        this.plotPreviews,
                        this.curBehaviour,
                        ignoreWarning,
                        this.curCouncil.bigDomainZone ? this.subdomainZone.id : undefined
                    ),
                ignoreWarning
            );
        } else {
            return await this.doSubmit(
                (ignoreWarning) =>
                    this.curPlot
                        ? this.singleCropPlan.plotApi.editPlot(
                            this.business.businessId,
                            this.curCropPlan.cropPlanId,
                            this.curCouncil.domainZoneId,
                            this.curPlot.plotCode,
                            this.curPlotOut as PlotOut,
                            ignoreWarning,
                            this.curCouncil.bigDomainZone ? this.subdomainZone.id : undefined,
                            this.plotBufferSize ?? 0,
                        )
                        : new Promise<PlotResponseDiff>(() => undefined),
                ignoreWarning
            );
        }
    }

    private async doMultiselectionPlots() {
        if (this.multiselectionIntersectedPlots && this.multiselectionIntersectedPlots.length) {
            this.curPlot = null;
            this.curPlots = [];

            this.curPlot = this.multiselectionIntersectedPlots[0];
            this.curPlots = this.multiselectionIntersectedPlots.filter(
                (mip) => mip.plotCode !== this.curPlot?.plotCode
            );
            this.multiselectionIntersectedPlots = [];
        }
        this.editPlotMode = EditPlotMode.NOT_SELECTED;
    }

    private async doCut(ignoreWarning = false) {
        if (!this.previewWkt && !this.layerForCuttingPlots) {
            return null;
        }

        if (this.layerForCuttingPlots) {
            const flMergeGeomsOnCutOnLayer = this.getMergeGeomsOnCutOnLayer(this.layerForCuttingPlots);
            this.calcCoveredByInsertedOnCutOnLayer = this.getCalcCoveredByInsertedOnCutOnLayer(this.layerForCuttingPlots);
            return await this.doSubmit(
                (ignoreWarning) =>
                    this.singleCropPlan.plotApi.cutByLayer(
                        this.business.businessId,
                        this.curCropPlan.cropPlanId,
                        this.curCouncil.domainZoneId,
                        this.curPointInTime,
                        this.layerForCuttingPlots!,
                        this.plotCodes,
                        ignoreWarning,
                        flMergeGeomsOnCutOnLayer,
                        this.calcCoveredByInsertedOnCutOnLayer,
                        this.curCouncil.bigDomainZone ? this.subdomainZone.id : undefined
                    ),
                ignoreWarning,
            )
        }

        return await this.doSubmit(
            (ignoreWarning) =>
                this.singleCropPlan.plotApi.cutPlot(
                    this.business.businessId,
                    this.curCropPlan.cropPlanId,
                    this.curCouncil.domainZoneId,
                    this.curPointInTime,
                    this.previewWkt as string,
                    this.plotCodes,
                    ignoreWarning,
                    this.curCouncil.bigDomainZone ? this.subdomainZone.id : undefined
                ),
            ignoreWarning
        );
    }

    private async doMerge(ignoreWarning = false) {
        if (!this.curPlot || !this.curPlots.length) {
            return null;
        }
        return await this.doSubmit(
            (ignoreWarning) =>
                this.curPlot
                    ? this.singleCropPlan.plotApi.mergePlots(
                        this.business.businessId,
                        this.curCropPlan.cropPlanId,
                        this.curCouncil.domainZoneId,
                        this.curPointInTime,
                        this.curPlot.plotCode,
                        this.plotCodesWithoutCurPlot,
                        ignoreWarning,
                        this.curCouncil.bigDomainZone ? this.subdomainZone.id : undefined
                    )
                    : new Promise<PlotResponseDiff>(() => undefined),
            ignoreWarning
        );
    }

    private async insertBuffer(ignoreWarning = false) {
        if (!this.previewWkt) {
            return null;
        }
        if (!this.bufferSize) {
            console.error("No bufferSize selected");
            return null;
        }
        return await this.doSubmit(
            (ignoreWarning) =>
                this.bufferSize
                    ? this.singleCropPlan.plotApi.insertBuffer(
                        this.business.businessId,
                        this.curCropPlan.cropPlanId,
                        this.curCouncil.domainZoneId,
                        this.curPointInTime,
                        this.previewWkt as string,
                        this.bufferSize,
                        this.bufferPosition,
                        this.bufferBehaviour,
                        this.plotCodes,
                        ignoreWarning,
                        this.curCouncil.bigDomainZone ? this.subdomainZone.id : undefined
                    )
                    : new Promise<PlotResponseDiff>(() => undefined),
            ignoreWarning
        );
    }

    private async doSubmit(apiCall: (ignoreWarning: boolean) => Promise<PlotResponseDiff>, ignoreWarning: boolean) {
        try {
            const res = await apiCall(ignoreWarning);

            this.validationMessages = res.validationMessages;

            if (this.validationMessages.length > 0) {
                return null;
            }

            this.updatePlots(res);
            this.editPlotMode = EditPlotMode.NOT_SELECTED;
            return res.alertCodes || [];
        } catch (error) {
            console.error(error);
            // this.helperMessage = this.i18n(`helper-map-message.invalid-${this.editPlotMode?.toLowerCase()}`);
            this.notificationMessage = {
                type: "error",
                label: this.i18n(`helper-map-message.invalid-${this.editPlotMode.toString().toLowerCase()}`),
            };
            return null;
        }
    }

    private updatePlots(diff: PlotResponseDiff) {
        const tempPlots = this.plots
            .filter((p) => !diff.deleted?.includes(p.plotCode))
            .map((p) => {
                const updatedPlot = diff.updated?.find((up) => up.plotCode === p.plotCode);
                return updatedPlot ? updatedPlot : p;
            });
        if (diff.added) {
            tempPlots.push(...diff.added);
        }
        this.plots = tempPlots; // TODO
        if (diff.coveredByInserted?.length) {
            const coveredIds = diff.coveredByInserted;
            this.curPlot = this.plots.find((p) => p.plotCode === coveredIds[0]) || null;
            this.curPlots = this.plots.filter((p) =>
                coveredIds.filter((c) => c != this.curPlot?.plotCode).includes(p.plotCode)
            );
            this.hasCoveredByInserted = true;
        } else {
            this.curPlot = this.plots.find((p) => p.plotCode === this.curPlot?.plotCode) || null;
            this.curPlots = this.plots.filter((p) => this.curPlots.map((cp) => cp.plotCode).includes(p.plotCode));
        }
        this.flCurCorpPlanChangesPending = true;
    }

    private async loadCuttableLayers() {
        const selectedLayers: string[] = this.additionalLayers.filter((l) => l.layerDef.on && l.layerDef.code != undefined).map((l) => l.layerDef.code as string);
        const selectedPlots: string[] = [...this.curPlots, ...(this.curPlot ? [this.curPlot] : [])].map((p) => p.plotCode);
        let response: CuttableLayer[] = [];
        try {
            this.cuttableLayersLoading = true;
            response = await this.singleCropPlan.plotApi.getCuttableLayers(
                this.business.businessId,
                this.curCropPlan.cropPlanId,
                this.curCouncil.domainZoneId,
                this.curCouncil.bigDomainZone ? this.subdomainZone.id : undefined,
                selectedPlots,
                selectedLayers,
                this.curPointInTime
            );
        } catch (error) {
            console.error("DEV error:", error);
        } finally {
            this.cuttableLayersLoading = false;
        }
        return response;
    }
}
