<template>
    <div class="flex rounded-lg bg-success-100 w-12 h-12 map-preview">
        <div :id="mapId" class="h-full w-full"></div>
    </div>
</template>

<script lang="ts">
import { Prop, Component, Vue, Inject, Watch } from "vue-property-decorator";
import { TranslateResult } from "vue-i18n";
import { Map, View } from "ol";
import BaseLayer from "ol/layer/Base";
import Projection from "ol/proj/Projection";
import { OlVectorLayer, VectorLayerDef } from "@abaco/iacs-map-module/src/modules/map-module/Layer/AbcVectorLayer";
import IacsMapModule from "@abaco/iacs-map-module/src/modules/map-module/index";
import { Plot } from "../../models/Plot";
import { Council } from "../../models/Council";
import { FromStore } from "@abaco/web-common/src/app";
import SingleCropPlan from "../..";
import SingleCropPlanModule from "../..";
import ID from "@abaco/web-components/src/ID";
import AbcWKT from "@abaco/iacs-map-module/src/modules/map-module/Layer/AbcWKT";
import { createEmpty, extend } from "ol/extent";
import { formatDate, formatDateTime } from "../../api/Utils";
import AbcWMSLayer, { WMSLayerDef } from "@abaco/iacs-map-module/src/modules/map-module/Layer/AbcWMSLayer";
import { CropPlan, CropPlanDates } from "../../models/CropPlan";
import { Business } from "../../models/Business";
import {
    LayerDef,
    LayerParamDef,
    LayerParamType,
} from "@abaco/iacs-map-module/src/modules/map-module/Layer/GenericLayer";
import { makeStrokePattern } from "./EditStyle";
import { tenant } from "../../../../main";

@Component
export default class SingleCpMapPreview extends Vue {
    @Inject() i18n!: (key: string, values?: unknown) => TranslateResult;
    @Inject(IacsMapModule.MODULE_ID) IacsMapModule!: IacsMapModule;
    @Inject(SingleCropPlanModule.MODULE_ID) singleCropPlanModule!: SingleCropPlanModule;

    @Prop() plot?: Plot;
    @Prop() plots?: Plot[];
    @Prop() mbrOverview?: string;
    @Prop() geom?: string;
    @Prop() mbr?: Council["mbr"];
    @Prop() domainZoneId?: string;
    @Prop() minimapMode?: boolean;

    @FromStore(SingleCropPlan.MODULE_ID) defaultLayers!: LayerDef[];
    @FromStore(SingleCropPlan.MODULE_ID) curPointInTime!: Date;
    @FromStore(SingleCropPlan.MODULE_ID) curCouncil!: Council;
    @FromStore(SingleCropPlan.MODULE_ID) curCropPlan!: CropPlan | null;
    @FromStore(SingleCropPlan.MODULE_ID) business!: Business;
    @FromStore(SingleCropPlan.MODULE_ID) cropPlanDates!: CropPlanDates;

    private map!: Map | null;
    private addedLayers: BaseLayer[] = [];
    private mapId: string = ID.next() + this.alias;
    private vectorLayer: OlVectorLayer | null = null;

    private wktParser = new AbcWKT();
    private additionalLayers: LayerDef[] = [];

    private get plotList() {
        return this.plots?.length ? this.plots : this.plot ? [this.plot] : [];
    }

    private get alias() {
        return this.plotList.length == 0
            ? ""
            : this.plotList.length > 1
            ? this.plotList[0].plotCode + "_" + this.plotList[this.plotList.length - 1].plotCode
            : this.plotList[0].plotCode;
    }

    async mounted() {
        await this.loadAdditionalLayers();
        window.setTimeout(() => this.buildMap(), 50);
    }

    destroyed() {
        if (this.map) {
            this.map.setTarget(undefined);
            this.map = null;
        }
    }

    @Watch("plotList")
    async onPlotChange(newVal: Plot[], oldVal: Plot[]) {
        let changed = false;
        newVal.forEach((plot, i) => {
            if (plot.geom != oldVal[i].geom) changed = true;
        });
        if (changed) {
            if (this.vectorLayer) this.map?.removeLayer(this.vectorLayer);
            this.vectorLayer = (await this.buildVectorLayer()) as OlVectorLayer;
            this.map?.addLayer(this.vectorLayer);
        }
    }

    private async buildMap() {
        let zoomToExtent = createEmpty();
        let geomLayer: VectorLayerDef;

        if (this.mbr) zoomToExtent = [this.mbr.xmin, this.mbr.ymin, this.mbr.xmax, this.mbr.ymax];
        else if (this.mbrOverview && this.geom) {
            const geom = new AbcWKT().WKTParser.readFeature(this.mbrOverview).getGeometry();
            if (geom) zoomToExtent = geom.getExtent();

            geomLayer = {
                layerType: "VECTOR",
                layerId: "geom-plot",
                features: [
                    {
                        wkt: this.geom,
                        id: "geom-plot",
                        style: {
                            borderColor: "blue",
                            fillColor: "rgb(0, 0, 255, 0.2)",
                            width: 2,
                        },
                    },
                ],
                isOverlay: true,
                description: "geom-plot",
                on: true,
                zIndex: 1000,
            };
        }

        if (this.plotList.length > 1) {
            this.plotList.forEach((plot) => {
                const extent = this.wktParser.WKTParser.readGeometry(plot.geom).getExtent();
                extend(zoomToExtent, extent);
            });
        } else if (this.plotList.length == 1) {
            if (this.plotList[0].mbrOverview) {
                const zoomToExtentGeom = this.wktParser.WKTParser.readFeature(
                    this.plotList[0].mbrOverview
                ).getGeometry();
                if (zoomToExtentGeom) zoomToExtent = zoomToExtentGeom.getExtent();
            } else extend(zoomToExtent, this.wktParser.WKTParser.readGeometry(this.plotList[0].geom).getExtent());
        }

        let computedAdditionalLayers: BaseLayer[] = [];
        try {
            if (this.additionalLayers !== undefined) {
                computedAdditionalLayers = await this.buildLayers(this.additionalLayers);
            }
        } catch (error) {
            console.error(error)
        }

        this.addedLayers = await this.buildLayers(this.defaultLayers);
        let plotLayer = null;
        if (this.minimapMode && this.curCropPlan) {
            const layerDef: WMSLayerDef = {
                code: "DOMAIN_PLOTS",
                description: "DOMAIN_PLOTS",
                snapElementType: null,
                minResolution: null,
                maxResolution: null,
                on: true,
                enabledInOverview: true,
                url: `/crop-plan-api/${tenant}/wms`,
                layers: "DOMAIN_PLOTS",
                styles: "",
                version: "1.0.0",
                srs: "none",
                format: "image/png",
                layerType: "WMS",
                layerId: "DOMAIN_PLOTS",
                bgcolor: "",
                transparent: true,
                optionalParams: {
                    cropPlanId: this.curCropPlan.cropPlanId,
                    domainZoneId: this.domainZoneId,
                    pointInTime: formatDate(this.curPointInTime),
                },
            };
            plotLayer = await this.IacsMapModule.layerFactory.getLayerBuilder(layerDef).build();
        }

        const selectedLayers = computedAdditionalLayers.length ? computedAdditionalLayers : this.addedLayers;

        this.map = new Map({
            target: this.mapId,
            view: new View({
                projection: new Projection({
                    code: "none",
                    units: "m",
                }),
            }),
            interactions: [],
            controls: [],
            layers: selectedLayers,
        });
        if (plotLayer != null) {
            this.map.addLayer(plotLayer);
        }
        if (!this.minimapMode) {
            this.vectorLayer = (await this.buildVectorLayer()) as OlVectorLayer;
            this.map.addLayer(this.vectorLayer);
        }
        if (this.mbrOverview && this.geom) {
            this.map.addLayer(
                (await this.IacsMapModule.layerFactory.getLayerBuilder(geomLayer!).build()) as OlVectorLayer
            );
        }
        this.map.getView().fit(zoomToExtent, {
            minResolution: 0.1,
            size: this.map.getSize(),
            padding: [5, 5, 5, 5],
        });

        this.onLayers();
    }

    @Watch("defaultLayers")
    async onLayers() {
        if (!this.map) {
            return;
        }
        this.addedLayers.forEach((l) => {
            if (this.map) this.map.removeLayer(l);
        });
        this.addedLayers = await this.buildLayers(this.defaultLayers);
        if (this.map)
            // it can beome null after waiting for buildLayers
            this.addedLayers.forEach((l) => {
                if (this.map) this.map.addLayer(l);
            });
    }

    private async buildVectorLayer() {
        const vectorLayerDef: VectorLayerDef = {
            layerType: "VECTOR",
            layerId: "SMALL_PREVIEW",
            features: this.plotList.map((plot) => ({
                wkt: plot.geom,
                id: plot.plotCode,
                style: {
                    fillColor:
                        plot?.style.fillStyle == "stroke"
                            ?  makeStrokePattern(plot.style.borderColor) ?? "trasparent"
                            : plot?.style.fillColor.length === 9
                            ? plot?.style.fillColor
                            : plot?.style.fillColor + "50",
                    borderColor: plot.style.borderColor,
                },
            })),
            description: this.alias,
            on: true,
            zIndex: 0,
        };
        return (await this.IacsMapModule.layerFactory.getLayerBuilder(vectorLayerDef).build()) as OlVectorLayer;
    }

    // @Watch("additionalLayers")
    // onAdditionalLayersChange() {
    //     const res = this.additionalLayers.filter((l) => l.layerDef.enabledInOverview);
    //     this.defaultLayers = res.map((r) => cloneDeep(r.buildedLayer));
    // }

    private async buildLayers(layerDefs: LayerDef[]): Promise<BaseLayer[]> {
        const addLayers: Promise<BaseLayer>[] = [];
        layerDefs.forEach(async (layerDef) => {
            if (AbcWMSLayer.instanceOfWmsDef(layerDef)) {
                (layerDef as WMSLayerDef) = {
                    ...layerDef,
                    optionalParams:
                        layerDef.layerParameters && layerDef.layerParameters.length
                            ? this.getParamsValue(layerDef.layerParameters)
                            : { point_in_time: formatDate(this.curPointInTime) },
                };
            }
            if (layerDef.enabledInOverview) {
                const buildedLayer = this.IacsMapModule.layerFactory.getLayerBuilder(layerDef).build();
                addLayers.push(buildedLayer);
            }
        });
        const res = await Promise.all(addLayers);
        return res.filter((l) => l !== null) as BaseLayer[];
    }

    private getParamsValue(layerParams: LayerParamDef[]) {
        if(!this.cropPlanDates || !this.cropPlanDates?.referenceDate)
            return;
        return layerParams.reduce<{ [key: string]: any }>((outObj, param) => {
            if (param.type == LayerParamType.POINT_IN_TIME) {
                outObj[param.name] = formatDate(this.curPointInTime);
            } else if (param.type == LayerParamType.POINT_IN_TIME_WITH_TIME) {
                outObj[param.name] = formatDateTime(this.curPointInTime);
            } else if (param.type == "DOMAIN_ZONE_ID") {
                outObj[param.name] = this.domainZoneId;
            } else if (param.type == LayerParamType.CAMPAIGN)
                outObj[param.name] = this.cropPlanDates.referenceDate.slice(0, 4);
            return outObj;
        }, {});
    }

    @Watch("domainZoneId")
    private async loadAdditionalLayers() {
        if (this.curCropPlan && this.business && this.domainZoneId)
            this.additionalLayers = await this.singleCropPlanModule.layerApi.getAdditionalLayers(
                this.business.businessId,
                this.curCropPlan.cropPlanId,
                this.domainZoneId
            );
    }
}
</script>

<style>
.map-preview .ol-viewport {
    @apply rounded-lg;
}
</style>
