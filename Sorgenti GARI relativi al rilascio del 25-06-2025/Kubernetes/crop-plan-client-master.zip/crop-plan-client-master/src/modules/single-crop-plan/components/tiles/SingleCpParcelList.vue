<template>
    <div>
        <div v-for="(sector, gindex) in groupedBySector" :key="gindex" class="w-full">
            <div class="sector-title w-full px-3 py-2 flex justify-between" :class="{ 'border-t': gindex === 0 }">
                <span class="font-bold text-primary-900">{{ i18n("sheet") }} {{ sector[0].sectorBlock }}</span>
                <span class="text-secondary-500">{{ sector.length }} {{ i18n("parcels") }}</span>
            </div>
            <div
                v-for="(item, index) in sector"
                :key="index"
                @click="onSelect(item)"
                v-scroll="lastSelected && item.parcelCode === lastSelected.parcelCode"
                class="single-crop-plan-crop-row"
                :class="{
                    'single-crop-plan-crop-row-active': curParcelData && curParcelData.parcelCode === item.parcelCode,
                }"
            >
                <div class="single-crop-plan-crop-row-inner gap-3">
                    <div class="w-full flex justify-between p-1 gap-3">
                        <single-cp-map-preview :mbrOverview="item.mbrOverview" :geom="item.geom" />
                        <div class="flex flex-col flex-1 min-w-0">
                            <span
                                class="text-label-primary truncate"
                                v-b-tooltip.hover.window.ds400
                                :title="item.description.length > 20 ? item.description : ''"
                                >{{ item.description }}</span
                            ><span
                                class="truncate"
                                v-b-tooltip.hover.window.ds400
                                :title="getTooltipDescription(item).length > 20 ? getTooltipDescription(item) : ''"
                                >{{ getDescription(item) }}</span
                            >
                        </div>
                        <div class="whitespace-nowrap text-right flex flex-col">
                            <div class="flex items-baseline">
                                <span class="font-semibold text-lg pr-1">{{ formattedArea(item.areaSqm) }}</span>
                                <span class="text-base lowercase">{{ areaLabel() }}</span>
                            </div>
                            <div class="flex flex-row justify-end gap-1 pt-1 text-3xl">
                                <em
                                    v-if="item.anomalies.some((it) => it.blocking)"
                                    v-b-popover="getAnomaliesPopover(item.anomalies, 'blocking')"
                                    class="text-danger-600 fa-sharp fa-solid fa-circle-xmark ml-1"
                                />
                                <em
                                    v-if="item.anomalies.some((it) => !it.blocking)"
                                    v-b-popover="getAnomaliesPopover(item.anomalies, 'warning')"
                                    class="text-warning-600 fa-sharp fa-solid fa-circle-exclamation"
                                />
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script lang="ts">
import { FromStore } from "@abaco/web-common/src/app";
import { VBPopover, VBTooltip } from "bootstrap-vue";
import { TranslateResult } from "vue-i18n";
import { Component, Inject, Mixins, Prop, Watch } from "vue-property-decorator";
import { MODULE_ID } from "../..";
import { groupBy } from "../../api/Utils";
import AreaUtils from "../../mixins/AreaUtils";
import { ParcelData } from "../../models/Declaration";
import { Anomaly } from "../../models/Plot";
import SingleCpMapPreview from "../mapComponent/SingleCPMapPreview.vue";

@Component({
    components: {
        SingleCpMapPreview,
    },
    directives: {
        "b-tooltip": VBTooltip,
        "b-popover": VBPopover,
        scroll: {
            inserted(el, binding) {
                if (binding.value) {
                    el.scrollIntoView({ block: "nearest" });
                }
            },
            componentUpdated(el, binding) {
                if (binding.value) {
                    el.scrollIntoView({ block: "nearest" });
                }
            },
        },
    },
})
export default class SingleCpParcelList extends Mixins(AreaUtils) {
    @Inject() i18n!: (key: string, values?: unknown) => TranslateResult;
    @FromStore(MODULE_ID) curParcelData!: ParcelData | null;

    @Prop() parcelData!: ParcelData[];
    @Prop({ default: 0 }) scrollUpdate!: number;

    private lastSelected: ParcelData | null = null;

    private onSelect(selected: ParcelData) {
        this.curParcelData = this.curParcelData === selected ? null : selected;
    }

    private get groupedBySector() {
        if (this.parcelData) return Object.values(groupBy(this.parcelData, "sectorBlock"));
        return [];
    }

    private getDescription(item: ParcelData) {
        if (item.landCovers.length === 0) {
            return this.i18n("no-land-cover");
        }

        if (item.landCovers.length > 1) {
            return this.i18n("multiple-land-cover");
        }

        return (
            item.landCovers[0].landCoverCode +
            (item.landCovers[0].landCoverDescription ? ` - ${item.landCovers[0].landCoverDescription}` : "")
        );
    }

    private getTooltipDescription(item: ParcelData) {
        if (item.landCovers.length === 0) {
            return "";
        }

        if (item.landCovers.length === 1) {
            return (
                item.landCovers[0].landCoverCode +
                (item.landCovers[0].landCoverDescription ? ` - ${item.landCovers[0].landCoverDescription}` : "")
            );
        }

        let tooltipLandCovers = "";
        for (const landCover of item.landCovers) {
            tooltipLandCovers =
                tooltipLandCovers +
                (landCover.landCoverCode +
                    (landCover.landCoverDescription ? ` ${landCover.landCoverDescription}` : "")) +
                " - ";
        }
        return tooltipLandCovers.substring(0, tooltipLandCovers.length - 3);
    }

    private getAnomaliesPopover(anomalies: Anomaly[], type: "warning" | "blocking") {
        const cssClassAlias = type == "blocking" ? "danger" : "warning";
        const anom = type == "blocking"
            ? anomalies.filter((it) => it.blocking)
            : anomalies.filter((it) => !it.blocking);
        const anomalyRows = anom
            .map((a) => {
                return `
                <span class="${type}-bullet pr-2">&bull;</span>
                ${a.errorDescription ? a.errorDescription : a.errorCode}
            `;
            })
            .join("<br>");
        return {
            placement: "bottom",
            trigger: "hover",
            boundary: "viewport",
            customClass: "anomalies-popover",
            html: true,
            content: `
                <div class="flex flex-grow flex-col">
                    <div class="bg-warning-100 px-3 py-2 rounded-t-xl mb-2">
                        <div class="text-${cssClassAlias}-600 text-xl font-bold">
                            <em class="text-${cssClassAlias}-600 fa-regular fa-triangle-exclamation mr-5"></em>
                            ${this.i18n(type + "-anomalies")}
                        </div>
                    </div>
                    <div class="px-3 py-2 mb-2">
                    ${anomalyRows}
                    </div>
                </div>`,
        };
    }

    @Watch("curParcelData")
    onCurParcelDataUpdate() {
        this.lastSelected = this.curParcelData;
    }

    @Watch("scrollUpdate")
    private onScroll() {
        this.lastSelected = null;
    }
}
</script>

<style lang="scss" scoped>
.sector-title {
    background-color: var(--color-bg-500);
    border-bottom-width: 1px;
    border-color: var(--color-border);
}
.whitespace-nowrap {
    white-space: nowrap;
}
</style>
