<template>
    <tile :title="tileTitle" noContainerStyled>
        <div class="flex w-full h-full overflow-auto" id="single-cp-declaration-container">
            <div
                v-if="!loading && hasLandUses"
                class="flex px-4 py-6 sm:w-full md:w-full mx-auto lg:w-11/12 xxl:w-9/12"
            >
                <abc-form ref="form" class="flex flex-col w-full sc-decl-edit-form" @submit="submit">
                    <!-- Section Titled 1 -->
                    <section-titled
                        :number="1"
                        :title="i18n('crop-section-title')"
                        :description="i18n('crop-section-description')"
                    >
                        <template #content>
                            <!-- LAND USE -->
                            <div class="flex w-full mb-4">
                                <abc-autocomplete
                                    class="w-full px-2"
                                    :label="i18n('land-use')"
                                    v-model="curLandUse"
                                    itemId="code"
                                    :items="landUsesOptions"
                                    :stringify="(item) => (item ? item.description : null)"
                                    :search.sync="searchLandUse"
                                    maxHeight="300px"
                                    buttons
                                    :rules="[mandatoryRule, notFallbackLanduseRule, landUseRule]"
                                    :is-disabled="!checkIfFieldIsEditable('LANDUSE', isNew, curLandUse)"
                                    @error-status="onLandUseError"
                                >
                                    <template #items="{ item }">
                                        <div>
                                            <em v-if="item.isFavourite" class="fa-solid fa-star"></em>
                                            {{ item.description }}
                                        </div>
                                    </template>
                                    <template>
                                        <div v-if="landUseLoading" class="flex justify-center items-center h-12">
                                            <abc-loader :size="32" />
                                        </div>
                                        <div
                                            v-if="!landUseLoading && landUsesPage.records.length === 0"
                                            class="flex justify-center items-center h-12"
                                        >
                                            <abc-no-data-found />
                                        </div>
                                        <div
                                            v-if="
                                                !landUseLoading &&
                                                landUsesPage.records.length > 0 &&
                                                landUsesPage.haveMore
                                            "
                                            class="flex justify-center items-center h-12"
                                        >
                                            <abc-refine-filter />
                                        </div>
                                    </template>
                                    <template #buttons>
                                        <div
                                            v-if="
                                                curConfiguration.ENABLE_FAVOURITES_LAND_USES &&
                                                curConfiguration.ENABLE_FAVOURITES_LAND_USES === 'TRUE' &&
                                                curLandUse
                                            "
                                        >
                                            <abc-tool-button
                                                @click="toggleFavourite"
                                                :is-disabled="!checkIfFieldIsEditable('LANDUSE', isNew, curLandUse)"
                                            >
                                                <em
                                                    v-if="!isFavoriteLoading"
                                                    class="fa-regular fa-star"
                                                    :class="[curLandUse.isFavourite ? 'solid-icon' : 'regular-icon']"
                                                />
                                                <abc-loader v-else :size="24" />
                                            </abc-tool-button>
                                        </div>
                                        <abc-tool-button
                                            is-secondary
                                            :is-disabled="!checkIfFieldIsEditable('LANDUSE', isNew, curLandUse)"
                                            @click="
                                                searchLandUse = '';
                                                curLandUse = null;
                                            "
                                            :title="i18n('clear-field')"
                                        >
                                            <em class="abc-icon abc-icon-x text-xs"></em>
                                        </abc-tool-button>
                                    </template>
                                </abc-autocomplete>
                            </div>

                            <date-section
                                v-if="curLandUse"
                                :is-loading="loadingFormFields"
                                :declaration-detail="detail"
                                :min-insertable-date="minInsertableDate"
                                :max-insertable-date="maxInsertableDate"
                                :has-permanent-crop-data="isAlignMode"
                                :externalUvDeclarationLock="externalUvDeclarationLock"
                                :readonly="curCropPlan.readOnly"
                                :is-permanent="isPermanent"
                                :isNew="isNew"
                                :default-harvest-days="
                                    curLandUse && curLandUse.defaultHarvestDays ? curLandUse.defaultHarvestDays : null
                                "
                                @on-update-from-date="updateHarvestDateByLandUse"
                                @on-update-from-date-precision="setFromDatePrecision"
                            />
                        </template>
                    </section-titled>

                    <!-- Section Titled 2 -->
                    <section-titled
                        :number="2"
                        :title="!hasMultiplePlotSelection ? i18n('set-area-title') : i18n('plot-area-selection-title')"
                        :description="
                            !hasMultiplePlotSelection
                                ? i18n('set-area-description')
                                : i18n('plot-area-selection-description')
                        "
                    >
                        <template #content>
                            <div class="plot-area-section">
                                <abc-switch
                                    v-if="
                                        curConfiguration.PERIMETER_MULTIPLIER_AREA_TOLERANCE &&
                                        detail.fromDate &&
                                        detail.toDate &&
                                        !isLessThanMinInsertableDate &&
                                        !isBiggerThanMaxInsertableDate &&
                                        curPlots.length == 0 &&
                                        !calcCoveredByInsertedOnCutOnLayer
                                    "
                                    :label="i18n('enable-tollerance')"
                                    v-model="enableTollerance"
                                    @input="
                                        (newVal) => {
                                            enableTollerance = newVal;
                                            updatePeriods();
                                        }
                                    "
                                    :is-disabled="!checkIfFieldIsEditable('DECLARED_AREA')"
                                    @error-status="pushToNotValidFields('DECLARED_AREA')"
                                />
                                <decl-areas-controller
                                    :lockAreaTo100="lockAreaTo100"
                                    :declaration-detail="detail"
                                    :single-plot-period="singlePlotPeriod"
                                    :multiple-plot-period="multiplePlotPeriod"
                                    :min-insertable-date="minInsertableDate"
                                    :max-insertable-date="maxInsertableDate"
                                    :cur-plots-to-save="curPlotsToSave"
                                    :has-multiple-plot-selection="hasMultiplePlotSelection"
                                    :is-loading="loadingPlotPeriods"
                                    :ignore-area-limit="ignoreAreaLimit"
                                    :is-bigger-or-equal-than-min-insertable-date="isBiggerOrEqualThanMinInsertableDate"
                                    :is-less-or-equal-than-max-insertable-date="isLessOrEqualThanMaxInsertableDate"
                                    :is-bigger-than-max-insertable-date="isBiggerThanMaxInsertableDate"
                                    :is-less-than-min-insertable-date="isLessThanMinInsertableDate"
                                    :isNew="isNew"
                                    :removeExistingDeclarations="calcCoveredByInsertedOnCutOnLayer"
                                    @update-detail-area-perc="onUpdateDetailAreaPerc"
                                    @update-multiple-plot-period="onUpdateMultiplePlotPeriod"
                                    @update-cur-plots-to-save="onUpdateCurPlotsToSave"
                                />
                            </div>
                        </template>
                    </section-titled>

                    <!-- Section Titled 3 -->
                    <section-titled
                        v-if="landUseAdditionalOptions && landUseAdditionalOptions.length > 0"
                        :number="3"
                        :title="i18n('luap-section-title')"
                        :description="i18n('luap-section-description')"
                    >
                        <template #content>
                            <land-use-additional-options-parser
                                v-if="!loadingLandUseAdditionalOptions"
                                :landUseAdditionalOptions="landUseAdditionalOptions"
                                :isNew="isNew"
                                :forceUpdate="forceUpdateLuao"
                                :disableCheckOnMandatoryDeclFields="disableCheckOnMandatoryDeclFields"
                                @updateLandUseAdditionalOptions="onUpdateLandUseAdditionalDataConf"
                            />
                            <div v-else class="flex justify-center items-center h-12">
                                <abc-loader :size="32" />
                            </div>
                        </template>
                    </section-titled>

                    <!-- Section Titled 4 -->
                    <section-titled
                        v-if="showPermanentCropForms && isCurLandUseValid"
                        :number="landUseAdditionalOptions.length > 0 ? 4 : 3"
                        :title="i18n('pcf-section-title')"
                        :description="i18n('pcf-section-description')"
                    >
                        <template #content>
                            <PermanentCropForms
                                v-if="!loadingFormFields"
                                v-model="permanentCropFormsData"
                                @updateDeclPlantingDate="updateFromDate"
                                @updateDeclHarvestDate="updateToDate"
                                :forceUpdate="forceUpdatePermanentCrop"
                                :areaSqm="calculateAreaSqm"
                                :disableRequirementCheck="disablePermanentCropRequirementCheck"
                                :readonly="readonly"
                                :isNew="isNew"
                                :disableCheckOnMandatoryDeclFields="disableCheckOnMandatoryDeclFields"
                            />
                            <div v-else class="flex justify-center items-center h-12">
                                <abc-loader :size="32" />
                            </div>
                        </template>
                    </section-titled>

                    <!-- Footer Button -->
                    <div v-if="!readonly" class="sc-decl-edit-section">
                        <div class="sc-decl-edit-info w-full md:w-4/12 justify-center md:justify-start"></div>
                        <div class="sc-decl-edit-fields justify-center md:justify-start w-full md:w-8/12">
                            <div class="form-buttons">
                                <abc-form-buttons
                                    class="pb-8"
                                    @save="submit"
                                    @cancel="close"
                                    :has-continue="false"
                                    :disable-confirm-button="disableFormButtons || loadingLandUseAdditionalOptions"
                                    :disable-save-button="
                                        (isNew && curDisabledFunctions.includes('ADD_DECLARATIONS')) ||
                                        (!isNew && curDisabledFunctions.includes('EDIT_DECLARATIONS'))
                                    "
                                />
                            </div>
                        </div>
                    </div>
                </abc-form>
            </div>
            <div v-if="!loading && !hasLandUses" class="flex flex-col w-full h-full items-center justify-center">
                <div class="pb-2">
                    <em class="fad fa-folder-times text-secondary-100" style="font-size: 80px"></em>
                </div>
                <div class="font-semibold text-label-secondary">
                    {{ i18n("no-land-uses-for-parcel-selected") }}
                </div>

                <div class="flex justify-center pt-8">
                    <abc-button is-secondary is-outlined @click="close()">
                        <em class="abc-icon abc-icon-arrow-left-round" /> {{ i18n("back") }}
                    </abc-button>
                </div>
            </div>
        </div>
        <crop-plan-post-edit-messages-modal :messages="validationMessages" @proceedAnyWay="submit(true)" />
        <app-loading-modal v-if="saving" />
    </tile>
</template>

<script lang="ts">
import { FromStore, ToastOptions } from "@abaco/web-common/src/app";
import { EmptyMaxPagedResults, MaxPagedResults } from "@abaco/web-common/src/Paging";
import { Validable } from "@abaco/web-components/src/components/form/Validable";
import { VBTooltip } from "bootstrap-vue";
import cloneDeep from "lodash/cloneDeep";
import { ALLOWED_ALIGN_TYPES, VINEYARD_FORM } from "../../../../shared/constants";
import { Debounce } from "vue-debounce-decorator";
import { TranslateResult } from "vue-i18n";
import { Component, Inject, Mixins, Prop, ProvideReactive, Ref, Watch } from "vue-property-decorator";
import SingleCropPlanModule, { MODULE_ID } from "../..";
import AreaUtils from "../../mixins/AreaUtils";
import DateUtils from "../../mixins/DateUtils";
import AppLoadingModal from "../private/appLoadingModal.vue";
import { Business } from "../../models/Business";
import { Council } from "../../models/Council";
import { Configuration, CropPlan, FunctionCode } from "../../models/CropPlan";
import {
    Declaration,
    DeclarationOut,
    DeclarationResponse,
    MultiplePlotPeriod,
    PlotPeriodsData,
    SinglePlotPeriod,
    toDeclarationOut,
} from "../../models/Declaration";
import { PermanentCropField, PermanentCropForm } from "../../models/PermanentCropForm";
import {
    LandUse,
    LandUseAdditionalDataConf,
    LandUseAdditionalDataField,
    PermanentCropFormValueConfig,
    Plot,
} from "../../models/Plot";
import { ValidationMessage } from "../../models/Utils";
import { Version } from "../../models/Version";
import SingleCpMapPreview from "../mapComponent/SingleCPMapPreview.vue";
import CropPlanPostEditMessagesModal from "../private/cropPlanPostEditMessagesModal.vue";
import PermanentCropForms from "../private/permanentCropForms.vue";
import SectionTitled from "../shared/SectionTitled.vue";
import DeclAreasController from "./NewCropPlanDeclarationImplementation/DeclAreasController.vue";
import DateSection from "../tiles/NewCropPlanDeclarationImplementation/DateSection.vue";
import { convertPermanentCropFormsForOutput, dateIsValid } from "../../api/Utils";
import LandUseAdditionalOptionsParser from "./LandUseAdditionalOptionsParser.vue";
import $ from "jquery";
import DeclFieldEditability from "../../mixins/DeclFieldEditability";

@Component({
    directives: {
        "b-tooltip": VBTooltip,
    },
    components: {
        SingleCpMapPreview,
        CropPlanPostEditMessagesModal,
        PermanentCropForms,
        SectionTitled,
        DateSection,
        DeclAreasController,
        AppLoadingModal,
        LandUseAdditionalOptionsParser,
    },
})
export default class SingleCpDeclarationEdit extends Mixins(DateUtils, AreaUtils, DeclFieldEditability) {
    @Inject() i18n!: (key: string, values?: unknown) => TranslateResult;
    @Inject() toast!: (message: string, options?: ToastOptions) => TranslateResult;
    @Inject(MODULE_ID) singleCropPlanModule!: SingleCropPlanModule;

    @FromStore(MODULE_ID) business!: Business;
    @FromStore(MODULE_ID) curPointInTime!: Date;
    @FromStore(MODULE_ID) curCropPlan!: CropPlan | null;
    @FromStore(MODULE_ID) curCouncil!: Council | null;
    @FromStore(MODULE_ID) curDeclaration!: Declaration | null;
    @FromStore(MODULE_ID) curVersion!: Version | null;
    @FromStore(MODULE_ID) curConfiguration!: Configuration | null;
    @FromStore(MODULE_ID) savedFormsTypes!: Record<string, PermanentCropField[]>;
    @FromStore(MODULE_ID) enabledPermanentCropFormsValues!: PermanentCropFormValueConfig[];
    @FromStore(MODULE_ID) curDisabledFunctions!: FunctionCode[];
    @FromStore(MODULE_ID) flVinealignBackoffice!: boolean;
    @FromStore(MODULE_ID) calcCoveredByInsertedOnCutOnLayer!: boolean;

    @Prop() declarations!: Declaration[];
    @Prop({ default: true }) readonly!: boolean;
    @Prop({ default: null }) firstPlot!: Plot | null;

    @Ref("form") form!: Validable;

    @ProvideReactive("declarationDetail")
    private detail: DeclarationOut = {
        landuseCode: undefined,
        areaPerc: undefined,
        fromDate: null,
        toDate: null,
        fieldsCodes: [],
    };

    private singlePlotPeriod: SinglePlotPeriod = { plot: null };
    private multiplePlotPeriod: MultiplePlotPeriod[] = [];
    private disableFormButtons = false;
    private loading = true;
    private landUseFallback: LandUse | null = null;
    private landUsesPage: MaxPagedResults<LandUse> = new EmptyMaxPagedResults();
    private curPlotsToSave: Plot[] = [];
    private searchLandUse: string | null = null;
    private landUseLoading = false;
    private curLandUse: LandUse | null = null;
    private landCovers: string[] = [];
    private minInsertableDate: Date | null = null;
    private maxInsertableDate: Date | null = null;
    private loadingPlotPeriods = false;
    private loadingFormFields = false;
    private hasLandUses = true;
    private validationMessages: ValidationMessage[] = [];
    private fromDatePrecision = "-";
    private fromDateLoaded: Date | null = null;
    private toDateLoaded: Date | null = null;
    private permanentCropFormsData: PermanentCropForm[] | null = null;
    private forceUpdatePermanentCrop = 0;
    private forceUpdateLuao = 0;
    private isFavoriteLoading = false;
    private saving = false;
    private enableTollerance = false;
    private oldEnableTolleranceValue = false;
    private updateDateByLandUse = false;
    private disablePermanentCropRequirementCheck = false;
    private landUseAdditionalOptions: LandUseAdditionalDataConf[] = [];
    private loadingLandUseAdditionalOptions = false;
    private flDeclarationLandUseUpdatedAtLeastOnce = false;

    private skipHarvestUpdateByLanduse = false;

    async beforeMount() {
        this.loading = true;
        let obsoleteLandUse = false;

        if (this.curPlots && this.curPlots.length > 0 && this.curPlot) {
            this.curPlotsToSave = cloneDeep(this.curPlots);
            this.curPlotsToSave.push(this.curPlot);
        }

        //load land use harvest days
        try {
            if (!this.isNew && this.curDeclaration && this.curCropPlan) {
                const declCopy = cloneDeep(this.curDeclaration);
                this.$emit("cur-declaration-copied");
                const res = await this.singleCropPlanModule.plotApi.getLandUse(
                    this.business.businessId,
                    this.curCropPlan.cropPlanId,
                    this.curPointInTime,
                    this.curDeclaration.landuse.code
                );
                if (res) declCopy.landuse = res;
                else this.landUseFallback = cloneDeep(declCopy.landuse);
                this.skipHarvestUpdateByLanduse = true;
                this.curDeclaration = declCopy;
            }
        } catch (error) {
            const errorCode = (error as any).response?.data?.errorCode;
            if (errorCode && errorCode == "LAND_USE_CODE_NOT_FOUND_EXCEPTION") {
                this.toast(
                    this.i18n("landuse-not-available-pointintime", {
                        date: this.formattedDate(this.curPointInTime),
                    }).toString(),
                    { type: "error", duration: 4000 }
                );
            } else this.toast(this.i18n("generic-error").toString(), { type: "error", duration: 4000 });

            this.curLandUse = null;
            obsoleteLandUse = true;
        }

        //load min and max date
        if (this.curConfiguration && this.curConfiguration.CONSTRAINTS_DECLS_TO_PLOTS == "FALSE") {
            this.minInsertableDate = new Date(0);
            this.maxInsertableDate = new Date(8640000000000000);
        } else if (this.curPlotsToSave && this.curPlotsToSave.length > 0) {
            const minDates: Date[] = [];
            const maxDates: Date[] = [];
            await Promise.all(
                this.curPlotsToSave.map(async (e) => {
                    if (this.curCropPlan && this.curCouncil) {
                        const res = await this.singleCropPlanModule.declarationApi.loadPlotRanges(
                            this.business.businessId,
                            this.curCropPlan.cropPlanId,
                            this.curCouncil.domainZoneId,
                            e.plotCode,
                            this.curVersion ? this.curVersion.version : null
                        );
                        minDates.push(res.minFromDate);
                        maxDates.push(res.maxToDate);
                    }
                })
            );
            let biggestMinDate: Date | null = null;
            minDates.forEach((e) => {
                biggestMinDate = !biggestMinDate ? e : biggestMinDate.getTime() > e.getTime() ? biggestMinDate : e;
            });
            this.minInsertableDate = biggestMinDate;
            let smallestMaxDate: Date | null = null;
            maxDates.forEach((e) => {
                smallestMaxDate = !smallestMaxDate ? e : smallestMaxDate.getTime() < e.getTime() ? smallestMaxDate : e;
            });
            this.maxInsertableDate = smallestMaxDate;
        } else if (this.curPlot && this.curCropPlan && this.curCouncil) {
            const res = await this.singleCropPlanModule.declarationApi.loadPlotRanges(
                this.business.businessId,
                this.curCropPlan.cropPlanId,
                this.curCouncil.domainZoneId,
                this.curPlot.plotCode,
                this.curVersion ? this.curVersion.version : null
            );
            this.minInsertableDate = res.minFromDate;
            this.maxInsertableDate = res.maxToDate;
        }

        //check land cover codes
        if (this.curPlotsToSave && this.curPlotsToSave.length > 0) {
            this.curPlotsToSave.forEach((e) => {
                if (e.parcelIntersections && e.parcelIntersections.length > 0) {
                    if (e.parcelIntersections.length === 1 && e.parcelIntersections[0].landCoverCode) {
                        this.landCovers.push(e.parcelIntersections[0].landCoverCode);
                    } else {
                        let biggestArea = 0;
                        e.parcelIntersections.forEach((e) => {
                            biggestArea = e.areaSqm > biggestArea ? e.areaSqm : biggestArea;
                        });
                        const biggestAreaFinded = e.parcelIntersections.find((e) => e.areaSqm === biggestArea);
                        if (biggestAreaFinded) this.landCovers.push(biggestAreaFinded.landCoverCode);
                    }
                }
            });
        } else {
            if (this.curPlot?.parcelIntersections && this.curPlot?.parcelIntersections.length > 0) {
                if (this.curPlot?.parcelIntersections.length === 1) {
                    if (this.curPlot?.parcelIntersections[0].landCoverCode) {
                        this.landCovers.push(this.curPlot?.parcelIntersections[0].landCoverCode);
                    }
                } else {
                    let biggestArea = 0;
                    this.curPlot?.parcelIntersections.forEach((e) => {
                        biggestArea = e.areaSqm > biggestArea ? e.areaSqm : biggestArea;
                    });
                    const targetParcelIntersection = this.curPlot.parcelIntersections.find(
                        (e) => e.areaSqm === biggestArea
                    );
                    if (targetParcelIntersection && targetParcelIntersection.landCoverCode) {
                        this.landCovers.push(targetParcelIntersection.landCoverCode);
                    }
                }
            }
        }

        //check for land use availability
        if (this.isNew && this.curCropPlan && this.curPointInTime) {
            const res = await this.singleCropPlanModule.plotApi.getLandUses(
                this.business.businessId,
                this.curCropPlan.cropPlanId,
                this.curPointInTime,
                null,
                this.landCovers
            );
            if (res.count === 0) {
                this.hasLandUses = false;
            }
        }

        if (!this.isNew && this.curDeclaration && !obsoleteLandUse) {
            this.detail = toDeclarationOut({
                ...this.curDeclaration,
                areaPerc: this.lockAreaTo100 ? 100 : this.getReproportionatedAreaPerc(),
            });
            this.curLandUse = this.curDeclaration.landuse;
            this.updateDateByLandUse = false;
            if (this.curDeclaration.permanentCropForms.length)
                this.permanentCropFormsData = cloneDeep(this.curDeclaration.permanentCropForms);
        }

        this.loading = false;
    }

    beforeDestroy() {
        this.resetDeclFieldEditabilityState();
    }

    updated() {
        const disableFields = this.readonly || this.externalUvDeclarationLock,
            parentsExceptionSelector = this.externalUvDeclarationLock ? ".plot-area-section, .form-buttons" : null;
        this.disablePermanentCropRequirementCheck = this.externalUvDeclarationLock == true; // If declaration is locked disable validation rule to allow form submit
        if (disableFields) {
            const cont = $("#single-cp-declaration-container");
            cont.find("button, input, select, textarea").each((i, el) => {
                const jEl = $(el);
                if (
                    (parentsExceptionSelector && jEl.parents(parentsExceptionSelector).length) ||
                    (jEl.parents(".permanentcrop-accordion").length &&
                        !jEl.parents(".permanentcrop-accordion-content").length)
                )
                    return;
                else jEl.prop("disabled", true);
            });
            cont.find(".abc-input-wrapper").each((i, el) => {
                const jEl = $(el);
                if (parentsExceptionSelector && jEl.parents(parentsExceptionSelector).length) return;
                jEl.on("click", (e: Event) => {
                    e.stopPropagation();
                    e.preventDefault();
                });
            });
            cont.find(".abc-dropdown2-wrapper").each((i, el) => {
                const jEl = $(el);
                if (parentsExceptionSelector && jEl.parents(parentsExceptionSelector).length) return;
                jEl.parent().css("pointer-events", "none").prop("tabindex", "-1");
            });
        }
    }

    // ---------- Rules
    private mandatoryRule = (v: unknown) => !!v || this.i18n("valid.mandatory-field");

    private notFallbackLanduseRule = (v: LandUse | null) =>
        v && v.code == this.landUseFallback?.code ? this.i18n("deprecated-option") : null;

    // ---------- Computeds
    private get ignoreAreaLimit() {
        return this.curConfiguration?.CONSTRAINTS_DECLS_PERC_TO_100 === "FALSE";
    }

    private get showPermanentCropForms() {
        return this.permanentCropFormsData && this.permanentCropFormsData.length;
        // && this.hasMultiplePlotSelection; NOTE: permanent crop forms required for multiple plots declaration edit https://abacogroup.easyredmine.com/issues/141587
    }

    private get removeExistingDeclarations() {
        return this.calcCoveredByInsertedOnCutOnLayer;
    }

    private get disableCheckOnMandatoryDeclFields() {
        return this.curConfiguration?.DISABLE_CHECK_ON_MANDATORY_DECL_FIELDS === "TRUE";
    }

    private landUseRule() {
        if (!this.curLandUse || !this.curConfiguration?.INVALID_LAND_USE_CODES) return true;
        return this.curConfiguration.INVALID_LAND_USE_CODES.split(" ").includes(this.curLandUse.code)
            ? this.i18n("invalid-land-use")
            : true;
    }

    /**
     * @returns
     * - curDeclaration areaPerc by default
     * - Calculates the adjusted percentage of declared area by proportionally scaling it based on the copied declaration's plot area on the declaration copy action
     */
    private getReproportionatedAreaPerc() {
        let areaPerc = this.curDeclaration?.areaPerc ?? 0;
        if (
            this.curDeclaration?.areaPerc &&
            this.firstPlot?.areaSqm &&
            this.firstPlot.plotCode != this.curPlot?.plotCode
        ) {
            const declaredArea = (this.curDeclaration?.areaPerc / 100) * this.firstPlot?.areaSqm;
            if (this.curPlot?.areaSqm) areaPerc = (declaredArea / this.curPlot.areaSqm) * 100;
        }
        return areaPerc;
    }

    private get isLessThanMinInsertableDate() {
        // Bypass check since CONSTRAINTS_DECLS_TO_PLOTS = 'FALSE'
        if (this.curConfiguration && this.curConfiguration.CONSTRAINTS_DECLS_TO_PLOTS == "FALSE") {
            return false;
        }

        return !!(
            this.detail &&
            this.detail.fromDate &&
            this.minInsertableDate &&
            this.detail.fromDate.getTime() < this.minInsertableDate.getTime()
        );
    }

    private get isBiggerThanMaxInsertableDate() {
        // Bypass check since CONSTRAINTS_DECLS_TO_PLOTS = 'FALSE'
        if (this.curConfiguration && this.curConfiguration.CONSTRAINTS_DECLS_TO_PLOTS == "FALSE") {
            return false;
        }

        return !!(
            this.detail &&
            this.detail.toDate &&
            this.maxInsertableDate &&
            this.detail.toDate.getTime() > this.maxInsertableDate.getTime()
        );
    }

    private get lockAreaTo100() {
        if (!this.curLandUse || !this.curLandUse?.landUseClass) return false;
        return this.curLandUse.landUseClass.percFixedTo100;
    }

    private get isNew(): boolean {
        return this.curDeclaration ? false : true;
    }

    private get hasMultiplePlotSelection(): boolean {
        return this.curPlots && this.curPlots.length > 0;
    }

    private get tileTitle(): string {
        if (this.readonly) return this.i18n("view-declaration").toString();
        return this.isNew ? this.i18n("add-declaration").toString() : this.i18n("edit-declaration").toString();
    }

    private get landUsesOptions() {
        return this.landUseFallback ? [...this.landUsesPage.records, this.landUseFallback] : this.landUsesPage.records;
    }

    private get isLessOrEqualThanMaxInsertableDate() {
        // Bypass check since CONSTRAINTS_DECLS_TO_PLOTS = 'FALSE'
        if (this.curConfiguration && this.curConfiguration.CONSTRAINTS_DECLS_TO_PLOTS == "FALSE") {
            return true;
        }

        return !!(
            this.detail &&
            this.detail.toDate &&
            this.maxInsertableDate &&
            this.detail.toDate.getTime() <= this.maxInsertableDate.getTime()
        );
    }

    private get isBiggerOrEqualThanMinInsertableDate() {
        // Bypass check since CONSTRAINTS_DECLS_TO_PLOTS = 'FALSE'
        if (this.curConfiguration && this.curConfiguration.CONSTRAINTS_DECLS_TO_PLOTS == "FALSE") {
            return true;
        }

        return !!(
            this.detail &&
            this.detail.fromDate &&
            this.minInsertableDate &&
            this.detail.fromDate.getTime() >= this.minInsertableDate.getTime()
        );
    }

    private get harvestDateTips() {
        const plotEnd =
            this.curConfiguration?.CONSTRAINTS_DECLS_TO_PLOTS == "FALSE" && this.curPlot
                ? this.i18n("end-date") + " " + this.formattedDate(this.curPlot.fullRangeToDate)
                : "";
        const suggestedDate =
            this.curLandUse && this.curLandUse.defaultHarvestDays && this.detail.fromDate && this.suggestedHarvestDate
                ? this.i18n("suggested-harvest-date") + " " + this.formattedDate(this.suggestedHarvestDate)
                : this.curLandUse &&
                  this.curLandUse.defaultHarvestDays &&
                  this.curLandUse.defaultHarvestDays >= 0 &&
                  !this.detail.fromDate
                ? this.i18n("suggested-harvest-days") + " " + this.curLandUse.defaultHarvestDays
                : "";
        return plotEnd + (plotEnd && suggestedDate ? " - " : "") + suggestedDate;
    }

    private get suggestedHarvestDate(): Date {
        if (this.curLandUse && this.curLandUse.defaultHarvestDays && this.detail.fromDate) {
            if (this.curLandUse.defaultHarvestDays === -1) {
                return this.curConfiguration?.CONSTRAINTS_DECLS_TO_PLOTS == "FALSE"
                    ? new Date(9999, 11, 31)
                    : this.curPlot?.fullRangeToDate || new Date(9999, 11, 31);
            }
            const newDate = new Date(this.detail.fromDate);
            newDate.setDate(newDate.getDate() + this.curLandUse.defaultHarvestDays);
            return newDate;
        } else {
            return new Date();
        }
    }

    private get dateRange() {
        if (
            !this.curConfiguration?.CONSTRAINTS_DECLS_TO_PLOTS ||
            this.curConfiguration.CONSTRAINTS_DECLS_TO_PLOTS === "TRUE"
        ) {
            return {
                plantingMin: this.curPlot ? new Date(this.curPlot.fullRangeFromDate.getTime() - 1) : null,
                plantingMax: this.curPlot?.fullRangeToDate ?? null,
                harvestMin: this.detail.fromDate,
                harvestMax: this.curPlot ? new Date(this.curPlot.fullRangeToDate.getTime() + 1) : null,
            };
        }
        return {
            plantingMin: null,
            plantingMax: this.curPlot ? this.curPlot.fullRangeToDate : null,
            harvestMin: this.detail.fromDate,
            harvestMax: null,
        };
    }

    private get calculateAreaSqm() {
        if (!this.detail?.areaPerc || !this.curPlot) return 0;
        return (this.detail.areaPerc / 100) * this.curPlot.areaSqm;
    }

    private get isAlignMode() {
        return this.curCropPlan?.cropPlanTypeCode && ALLOWED_ALIGN_TYPES.includes(this.curCropPlan?.cropPlanTypeCode);
    }

    private get isPermanent() {
        return this.curLandUse && this.curLandUse.landUseClass ? this.curLandUse.landUseClass.permanent : false;
    }

    private get isExternalUv() {
        return (
            this.permanentCropFormsData &&
            this.permanentCropFormsData.find(
                (pf) => pf.formType == "VINEYARD_FORM" && pf.permanentCropFormData?.externalCode != null
            ) != undefined
        );
    }

    private get externalUvDeclarationLock() {
        return (
            this.isExternalUv &&
            this.curConfiguration?.LOCK_DECLARATIONS_FIELDS_IF_EXTERNAL === "TRUE" &&
            !this.flVinealignBackoffice
        ); // VINEALIGN BACKOFFICE can edit external UV Declaration
    }

    private get isCurLandUseValid() {
        return this.curLandUse && this.landUseRule() === true;
    }

    // ---------- Methods
    private onUpdateDetailAreaPerc(value: { percentageInput: number; plotCode: string }) {
        // Update detail.areaPerc (it's usefull only for single/not collective plotPeriod)
        this.detail.areaPerc = value.percentageInput;
    }

    private async submit(ignoreWarning = false) {
        if (this.readonly) return;
        const isValid = this.form.validate();
        if (isValid && this.curLandUse) {
            this.disableFormButtons = true;
            this.detail.landuseCode = this.curLandUse.code;
            if (this.landUseAdditionalOptions) {
                this.detail.fieldsCodes = [];
                for (const option of this.landUseAdditionalOptions)
                    if (option.selectedValue) this.detail.fieldsCodes.push(option.selectedValue);
            }

            if (!this.isNew && this.curDeclaration && this.curDeclaration.declCode !== -1) {
                await this.editDeclaration(ignoreWarning);
            } else {
                await this.insertDeclaration(ignoreWarning);
            }
        } else {
            // Open accordion
            this.$nextTick(() => this.forceUpdatePermanentCrop++);
            this.$nextTick(() => this.forceUpdateLuao++);
        }
    }

    private close() {
        this.calcCoveredByInsertedOnCutOnLayer = false;
        this.$emit("close-current-view");
    }

    private async editDeclaration(ignoreWarning = false) {
        if (!this.curCropPlan || !this.curCouncil || !this.curPlot || !this.curDeclaration || this.readonly) return;
        this.saving = true;
        try {
            const res = await this.singleCropPlanModule.declarationApi.editDeclaration(
                this.business.businessId,
                this.curCropPlan.cropPlanId,
                this.curCouncil.domainZoneId,
                this.curPlot.plotCode,
                this.curDeclaration.declCode,
                this.permanentCropFormsData?.some((it) => it.permanentCropFormData !== null)
                    ? {
                          ...this.detail,
                          permanentCropForms: this.permanentCropFormsData,
                      }
                    : { ...this.detail, permanentCropForms: [] },
                this.fromDatePrecision,
                this.enableTollerance,
                ignoreWarning,
                this.curPointInTime
            );

            this.validationMessages = res.validationMessages;

            if (this.validationMessages.length > 0) {
                this.saving = false;
                return;
            }
            this.$emit("updated", res);
            this.$emit("refresh");
            this.toast(this.i18n("declaration-updated").toString(), { type: "success" });
        } catch (error) {
            const errorCode = (error as any).response?.data?.errorCode;
            let errorMessage = this.i18n("generic-error").toString();
            switch (errorCode) {
                case "LAND_USE_CODE_NOT_FOUND_EXCEPTION":
                    errorMessage = this.i18n("landuse-not-available-selected-date").toString();
                    break;
                case "MAX_ALLOWED_DECLARABLE_AREA_EXCEPTION":
                    errorMessage = this.i18n("max_allowed_declarable_area_exception").toString();
                    break;
            }
            this.toast(errorMessage, { type: "error", duration: 4000 });
        } finally {
            this.disableFormButtons = false;
            this.saving = false;
        }
    }

    private async insertDeclaration(ignoreWarning = false) {
        if (!this.curCropPlan || !this.curCouncil || !this.curPlot || this.readonly) return;
        this.saving = true;
        try {
            // Create obj with [detail] and [permanentCropFormsData] (if exists)
            const declOut = this.permanentCropFormsData?.some((it) => it.permanentCropFormData !== null)
                ? {
                      ...this.detail,
                      permanentCropForms: this.permanentCropFormsData,
                  }
                : this.detail;

            // Instantiate [res] and [validationMessages]
            let res: DeclarationResponse | null = null;
            this.validationMessages = [];
            // Check if it's a mutiple/collective
            if (this.curPlotsToSave && this.curPlotsToSave.length > 0) {
                const areasToUpdate: { plotCode: string; areaPerc: number }[] = [];
                if (this.multiplePlotPeriod.length) {
                    // Create a list with [plotCode, areaPerc] from multiplePlotPeriod
                    // for passing it to insertMultipleDeclaration
                    for (const plotPeriod of this.multiplePlotPeriod) {
                        /**
                         * ? [WARNING!] Maybe this can be cause multiple key-value with the same plotCode
                         */
                        areasToUpdate.push({ plotCode: plotPeriod.code, areaPerc: plotPeriod.percentage || 0 });
                    }
                } else {
                    areasToUpdate.push(
                        ...this.curPlotsToSave.map((plot) => {
                            return { plotCode: plot.plotCode, areaPerc: this.detail.areaPerc || 0 };
                        })
                    );
                }

                res = await this.singleCropPlanModule.declarationApi.insertMultipleDeclaration(
                    this.business.businessId,
                    this.curCropPlan.cropPlanId,
                    this.curCouncil.domainZoneId,
                    {
                        ...declOut,
                        plots: areasToUpdate,
                    },
                    this.fromDatePrecision,
                    ignoreWarning,
                    !this.isNew,
                    this.removeExistingDeclarations,
                    this.curPointInTime
                );
            } else {
                res = await this.singleCropPlanModule.declarationApi.insertDeclaration(
                    this.business.businessId,
                    this.curCropPlan.cropPlanId,
                    this.curCouncil.domainZoneId,
                    this.curPlot.plotCode,
                    declOut,
                    this.fromDatePrecision,
                    this.enableTollerance,
                    ignoreWarning,
                    !this.isNew,
                    this.removeExistingDeclarations,
                    this.curPointInTime
                );
            }

            this.validationMessages = res.validationMessages;

            if (this.validationMessages.length > 0) {
                this.saving = false;
                return;
            }

            if (this.curPlotsToSave && this.curPlotsToSave.length > 1) {
                this.$emit("inserted-multiple", this.curPlotsToSave);
            } else {
                this.$emit("inserted", res.declaration);
            }
            this.calcCoveredByInsertedOnCutOnLayer = false;
            this.$emit("refresh");
            this.toast(this.i18n("declaration-inserted").toString(), { type: "success" });
        } catch (error) {
            const errorCode = (error as any).response?.data?.errorCode;
            let errorMessage = this.i18n("generic-error").toString();
            switch (errorCode) {
                case "LAND_USE_CODE_NOT_FOUND_EXCEPTION":
                    errorMessage = this.i18n("landuse-not-available-selected-date").toString();
                    break;
                case "MAX_ALLOWED_DECLARABLE_AREA_EXCEPTION":
                    errorMessage = this.i18n("max_allowed_declarable_area_exception").toString();
                    break;
            }
            this.toast(errorMessage, { type: "error", duration: 4000 });
        } finally {
            this.disableFormButtons = false;
            this.saving = false;
        }
    }

    private updateHarvestDateByLandUse(inputDate: Date) {
        if (!inputDate || !dateIsValid(inputDate)) return;
        //
        const dateChanged = this.detail.fromDate ? inputDate.getTime() != this.detail.fromDate.getTime() : true,
            resetHarvest =
                this.curConfiguration &&
                this.curConfiguration.CLEAR_DECL_END_DATE_WHEN_START_DATE_IS_CHANGED === "TRUE";
        if (dateChanged) this.detail.fromDate = inputDate;
        //
        if (resetHarvest && !this.updateDateByLandUse) {
            this.detail.toDate = null;
            this.updateDateByLandUse = false;
        } else if (this.curLandUse && this.curLandUse.defaultHarvestDays) {
            if (
                (this.detail.fromDate &&
                    this.dateRange.plantingMin &&
                    this.detail.fromDate >= this.dateRange.plantingMin) ||
                (this.detail.fromDate && this.dateRange.plantingMin == null)
            ) {
                let newDate;
                if (this.curLandUse.defaultHarvestDays === -1) {
                    newDate =
                        this.curConfiguration?.CONSTRAINTS_DECLS_TO_PLOTS == "FALSE"
                            ? new Date(9999, 11, 31)
                            : this.curPlot?.fullRangeToDate || new Date(9999, 11, 31);
                } else {
                    newDate = new Date(this.detail.fromDate);
                    newDate.setDate(newDate.getDate() + this.curLandUse.defaultHarvestDays);
                }
                // date range should have at least one day within the plot lifetime
                if (
                    this.curPlot &&
                    newDate >= this.curPlot.fullRangeFromDate &&
                    newDate <= this.curPlot.fullRangeToDate
                ) {
                    this.detail.toDate = newDate;
                    this.updateDateByLandUse = false;
                }
            }
        }
    }

    /* private resetDates(value: LandUse) {
        this.curLandUse = value;
        if (this.detail.fromDate && this.curLandUse && this.curLandUse.defaultHarvestDays != null) {
            const newDate = new Date(this.detail.fromDate);
            newDate.setDate(newDate.getDate() + this.curLandUse.defaultHarvestDays);
            this.detail.toDate = newDate;
        }
    } */

    private updateFromDate(val: Date | null) {
        if (val && dateIsValid(val)) {
            this.detail.fromDate = val;
        }
    }

    private updateToDate(val: Date | null) {
        this.detail.toDate = val;
    }

    private setFromDatePrecision(e: string) {
        this.fromDatePrecision = e;
    }

    private onUpdateMultiplePlotPeriod(val: MultiplePlotPeriod[]) {
        this.multiplePlotPeriod = val;
    }

    private onUpdateCurPlotsToSave(val: Plot[]) {
        this.curPlotsToSave = val;
    }

    private onUpdateLandUseAdditionalDataConf(luads: LandUseAdditionalDataConf[]) {
        this.landUseAdditionalOptions = luads;
    }

    private async updateLandUse() {
        if (!this.curCropPlan) return;
        this.landUseLoading = true;
        this.landUsesPage = new EmptyMaxPagedResults();
        let page = await this.singleCropPlanModule.plotApi.getLandUses(
            this.business.businessId,
            this.curCropPlan.cropPlanId,
            this.curPointInTime,
            this.searchLandUse ? this.searchLandUse.trim().toUpperCase() : "",
            this.landCovers
        );
        if (page.count === 1 && this.searchLandUse === page.records[0].description) {
            const res = page.records[0];
            page = await this.singleCropPlanModule.plotApi.getLandUses(
                this.business.businessId,
                this.curCropPlan.cropPlanId,
                this.curPointInTime,
                null,
                this.landCovers
            );
            page.records = page.records.filter((l) => l.code !== res.code);
            page.records.unshift(res);
            if (this.curLandUse) {
                this.curLandUse = { ...this.curLandUse };
            }
        }

        this.landUsesPage = page;
        this.landUseLoading = false;
    }

    private onLandUseError() {
        this.pushToShouldBeEditable("LANDUSE");
        this.pushToNotValidFields("LANDUSE");
        this.$forceUpdate(); // WORKAROUND: Need to force input componets rerender to update isDisabled property values
    }

    private async updateLandUseAdditionalOptions() {
        this.loadingLandUseAdditionalOptions = true;
        try {
            const landUseAdditionalOptions = await this.singleCropPlanModule.plotApi.getLandUseAdditionalDataConf(
                this.business.businessId,
                this.curCropPlan!.cropPlanId,
                this.curLandUse!.code,
                this.curPointInTime
            );
            this.landUseAdditionalOptions = landUseAdditionalOptions;

            // If there are any saved fields in the current statement,
            // assigns the saved value to the corresponding option
            if (this.curDeclaration?.fieldsCodes?.length) {
                // const selectedFieldCodes: string[] = [];

                this.curDeclaration.fieldsCodes.forEach((field) => {
                    const option = this.landUseAdditionalOptions.find((option) => option.fieldCode === field.fieldCode);
                    if (option) {
                        option.selectedValue = field;
                        // selectedFieldCodes.push(field.fieldCode);
                    }
                });

                // // Default value for unselected options
                // const defaultValue: LandUseAdditionalDataField = {
                //     fieldCode: "",
                //     fieldDescription: "",
                //     dayFrom: "",
                //     dayTo: "",
                //     sortOrder: 0,
                //     value: null,
                //     valueDescription: "",
                //     flShowInTooltip: false,
                // };

                // // Applies the default value to options that have not been selected
                // this.landUseAdditionalOptions
                //     .filter((option) => !selectedFieldCodes.includes(option.fieldCode))
                //     .forEach((option) => {
                //         option.selectedValue = {
                //             ...defaultValue,
                //             fieldCode: option.fieldCode
                //         };
                //     });
            }
        } catch (error) {
            console.error("DevError - something went wrong while loading additional landuse options: ", error);
            this.landUseAdditionalOptions = [];
        } finally {
            this.loadingLandUseAdditionalOptions = false;
        }
    }

    private async toggleFavourite() {
        if (!this.curCropPlan || !this.curLandUse) return;

        try {
            // Start loading
            this.isFavoriteLoading = true;
            if (this.curLandUse.isFavourite) {
                await this.singleCropPlanModule.plotApi.removeFromFavourite(
                    this.business.businessId,
                    this.curCropPlan.cropPlanId,
                    this.curLandUse.code
                );
            } else {
                await this.singleCropPlanModule.plotApi.addToFavourite(
                    this.business.businessId,
                    this.curCropPlan.cropPlanId,
                    this.curLandUse.code
                );
            }

            await this.updateLandUse();

            const newLandUse = this.landUsesPage.records.find((it) => it.code === this.curLandUse?.code);
            if (newLandUse) this.curLandUse = cloneDeep(newLandUse);
        } catch (e) {
            console.error("DevError - toggleFavourite has encountered an error:", e);
        } finally {
            this.isFavoriteLoading = false;
        }
    }

    /**
     *  Check if lockAreaTo100 is True.
     *  True -> detail.areaPerc = 100
     *  False -> Ignore
     */
    private setLockAreaIfNecessary() {
        if (this.lockAreaTo100) {
            this.detail.areaPerc = 100;
            this.multiplePlotPeriod.forEach((i) => (i.percentage = 100));
        }
    }

    // ---------- Watches
    @Watch("searchLandUse")
    @Debounce(300)
    private async triggerLandUseSearch() {
        await this.updateLandUse();
    }

    @Watch("curLandUse")
    public async onCurLandUseUpdate(newVal: LandUse | null, oldVal: LandUse | null) {
        this.setLockAreaIfNecessary();
        const curLandUseIsChanged = !!(newVal && newVal.code != oldVal?.code);
        this.loadingFormFields = true;
        if (this.curLandUse) {
            this.updateDateByLandUse = curLandUseIsChanged;

            if (curLandUseIsChanged) {
                if (this.skipHarvestUpdateByLanduse) this.skipHarvestUpdateByLanduse = false;
                else if (this.curLandUse.defaultFromDate) {
                    this.updateHarvestDateByLandUse(this.curLandUse.defaultFromDate);
                } else if (oldVal && !this.isAlignMode) {
                    this.detail.fromDate = null;
                    this.detail.toDate = null;
                }
            }

            if (this.curDeclaration && this.curLandUse.code !== this.curDeclaration.landuse.code) {
                const declCopy = cloneDeep(this.curDeclaration);
                declCopy.fieldsCodes = [];
                declCopy.permanentCropForms = [];
                this.curDeclaration = declCopy;
            }

            if (curLandUseIsChanged) await this.updateLandUseAdditionalOptions();

            const formsTypes = newVal && newVal.formsConfig ? newVal.formsConfig.map((value) => value.formType) : [];
            this.enabledPermanentCropFormsValues =
                newVal && newVal.formsConfig ? newVal.formsConfig.map((value) => value.fields).flat() : [];
            if (formsTypes.length) {
                // Check if state already containts formstypes and VINEYARD_FORM as key
                // also check if [newVal] has as formstypes VINEYARD_FORM
                if (
                    this.savedFormsTypes !== null &&
                    !this.savedFormsTypes.VINEYARD_FORM &&
                    formsTypes.some((it) => it === VINEYARD_FORM) &&
                    this.curCropPlan
                ) {
                    try {
                        const vineyardFieldForms = await this.singleCropPlanModule.permanentCropFormApi.getFieldsCodes(
                            this.business.businessId,
                            this.curCropPlan.cropPlanId,
                            VINEYARD_FORM
                        );
                        this.savedFormsTypes = { ...this.savedFormsTypes, VINEYARD_FORM: vineyardFieldForms };
                    } catch (error) {
                        console.error("DevError - something onCurLandUseUpdate went wrong: ", error);
                    }
                }

                // Forms
                const forms: PermanentCropForm[] = [];
                let formTypes = formsTypes;
                // set date defaults if prev landUse didn't have permanentCropForms
                if (this.isNew && (!oldVal || !oldVal.formsConfig)) {
                    // this.detail.fromDate = this.curPlot.fullRangeFromDate ?? new Date(1970);
                    this.detail.toDate =
                        this.curConfiguration?.CONSTRAINTS_DECLS_TO_PLOTS == "FALSE"
                            ? new Date(9999, 11, 31)
                            : this.curPlot?.fullRangeToDate ?? null;
                }
                //
                if (this.curDeclaration?.permanentCropForms?.length) {
                    this.curDeclaration.permanentCropForms.forEach((form) => {
                        if (formTypes.includes(form.formType)) formTypes = formTypes.filter((i) => i !== form.formType);
                        forms.push(cloneDeep(form));
                    });
                } else if (this.curConfiguration?.PRESERVE_PERMANTENT_CROP_FORM_DATA === "TRUE") {
                    formTypes.forEach((type) => {
                        const lastPermanentCropFormData = this.permanentCropFormsData?.find(
                            (it) => it.formType === type
                        );
                        return forms.push({
                            formType: VINEYARD_FORM,
                            formCode: lastPermanentCropFormData?.formCode || null,
                            permanentCropFormData:
                                lastPermanentCropFormData?.formType === VINEYARD_FORM
                                    ? lastPermanentCropFormData?.permanentCropFormData
                                    : null,
                        });
                    });
                } else {
                    forms.push({
                        formType: VINEYARD_FORM,
                        formCode: null,
                        permanentCropFormData: null,
                    });
                }

                this.permanentCropFormsData = forms;
            } else {
                this.permanentCropFormsData = null;
            }
        } else {
            this.detail.fromDate = null;
            this.detail.toDate = this.isAlignMode
                ? this.curConfiguration?.CONSTRAINTS_DECLS_TO_PLOTS == "FALSE"
                    ? new Date(9999, 11, 31)
                    : this.curPlot?.fullRangeToDate ?? null
                : null;
            this.landUseAdditionalOptions = [];
        }

        this.loadingFormFields = false;
        if ((!this.isNew && !this.form.validate()) || curLandUseIsChanged) {
            this.$nextTick(() => this.forceUpdatePermanentCrop++);
            this.$nextTick(() => this.forceUpdateLuao++);
        }
    }

    @Watch("detail.fromDate")
    @Watch("detail.toDate")
    private async updatePeriods(newVal: Date | null, oldVal: Date | null) {
        if (
            (newVal ? newVal.getTime() : null) == (oldVal ? oldVal.getTime() : null) &&
            this.oldEnableTolleranceValue == this.enableTollerance
        )
            return; // continue only if val has changed
        this.oldEnableTolleranceValue = this.enableTollerance;
        if (
            this.detail.fromDate &&
            this.detail.toDate &&
            this.minInsertableDate &&
            this.maxInsertableDate &&
            this.isLessOrEqualThanMaxInsertableDate &&
            this.isBiggerOrEqualThanMinInsertableDate
        ) {
            this.fromDateLoaded = new Date(
                this.detail.fromDate.getFullYear(),
                this.detail.fromDate.getMonth(),
                this.detail.fromDate.getDate()
            );
            this.toDateLoaded = new Date(
                this.detail.toDate.getFullYear(),
                this.detail.toDate.getMonth(),
                this.detail.toDate.getDate()
            );

            if (
                !this.isAlignMode &&
                this.singlePlotPeriod &&
                this.singlePlotPeriod.plot &&
                this.singlePlotPeriod.plot.declaredAreas.length > 0
            )
                this.detail.areaPerc = 0;

            // Start loading
            this.loadingPlotPeriods = true;

            if (!this.hasMultiplePlotSelection && this.curCropPlan && this.curCouncil && this.curPlot) {
                this.singlePlotPeriod = { plot: null };
                const res = await this.singleCropPlanModule.declarationApi.loadPlotPeriods(
                    this.business.businessId,
                    this.curCropPlan.cropPlanId,
                    this.curCouncil.domainZoneId,
                    this.curPlot.plotCode,
                    this.formattedDateWithFormat(this.detail.fromDate, "yyyyMMdd"),
                    this.formattedDateWithFormat(this.detail.toDate, "yyyyMMdd"),
                    this.curDeclaration && this.curDeclaration.declCode && !this.isNew
                        ? this.curDeclaration.declCode
                        : null,
                    this.curVersion ? this.curVersion.version : null,
                    this.enableTollerance
                );

                // Force add id to declecaredAreas
                res.declaredAreas = res.declaredAreas.map((it, idx) => {
                    return { ...it, id: `${res.plotCode}_${idx}` };
                });
                // Filter all out of ranges dates
                res.declaredAreas = res.declaredAreas
                    .filter((d) => {
                        return (
                            this.curPlot &&
                            d.date >= this.curPlot.fullRangeFromDate &&
                            d.date <= this.curPlot.fullRangeToDate
                        );
                    })
                    .reverse();

                // Set singlePlotPeriod
                this.singlePlotPeriod = {
                    plot: res,
                };
            } else if (!this.calcCoveredByInsertedOnCutOnLayer) {
                // Clear before api calls for preventintg inconsistency of data
                this.multiplePlotPeriod = [];

                // Load period for each plot
                const resPlotsPeriods: (PlotPeriodsData | undefined)[] = await Promise.all(
                    this.curPlotsToSave.map(async (e) => {
                        if (this.detail.fromDate && this.detail.toDate && this.curCropPlan && this.curCouncil) {
                            const res = await this.singleCropPlanModule.declarationApi.loadPlotPeriods(
                                this.business.businessId,
                                this.curCropPlan.cropPlanId,
                                this.curCouncil.domainZoneId,
                                e.plotCode,
                                this.formattedDateWithFormat(this.detail.fromDate, "yyyyMMdd"),
                                this.formattedDateWithFormat(this.detail.toDate, "yyyyMMdd"),
                                null,
                                this.curVersion ? this.curVersion.version : null,
                                this.curConfiguration?.CONSTRAINTS_DECLS_TO_PLOTS == "FALSE"
                            );
                            // Force add id to declecaredAreas
                            res.declaredAreas = res.declaredAreas.map((it, idx) => {
                                return { ...it, id: `${res.plotCode}_${idx}` };
                            });
                            // Filter all out of ranges dates
                            res.declaredAreas = res.declaredAreas
                                .filter((d) => {
                                    return e && d.date >= e.fullRangeFromDate && d.date <= e.fullRangeToDate;
                                })
                                .reverse();

                            return res;
                        }
                    })
                );

                // Set multiplePlotPeriod
                this.multiplePlotPeriod = [];
                for (const plotPeriodData of resPlotsPeriods) {
                    if (!plotPeriodData) continue;

                    this.multiplePlotPeriod.push({
                        code: plotPeriodData.plotCode,
                        isOpen: false,
                        plot: plotPeriodData,
                        percentage: null,
                    });
                }
            }

            this.setLockAreaIfNecessary();

            // Stop loading
            this.loadingPlotPeriods = false;
        }
    }
}
</script>

<style lang="scss" scoped>
.regular-icon {
    font-weight: normal;
}
.solid-icon {
    font-weight: bold;
}

.sc-decl-edit-form {
    @apply flex gap-4;
    flex-direction: column;
    align-content: stretch;
}

.sc-decl-edit-section {
    @apply px-4 flex flex-wrap;
    flex-grow: 1;
}

.sc-decl-edit-info {
    @apply flex flex-col items-start pr-6 text-label-primary;
}

.sc-decl-edit-title {
    @apply w-full flex font-bold items-baseline text-secondary-700;
}
.sc-decl-edit-sub-title {
    @apply w-full flex;
}

.sc-decl-edit-info div:last-of-type {
    @apply pb-2 border-b;
}

.sc-decl-edit-fields {
    @apply flex flex-col;
}

@media (min-width: 640px) {
    .sc-decl-edit-fields {
        @apply mt-2;
    }
}
@media (min-width: 768px) {
    .sc-decl-edit-fields {
        @apply pl-6 border-l;
    }
}
</style>
