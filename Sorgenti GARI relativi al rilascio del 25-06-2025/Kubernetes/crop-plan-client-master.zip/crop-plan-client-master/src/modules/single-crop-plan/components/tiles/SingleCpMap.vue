<template>
    <tile :title="i18n('map')" :noTopbar="getisGCP()">
        <crop-plan-edit-modal-warning />
        <div class="w-full h-full relative overflow-hidden">
            <single-cp-map-component
                class="w-full h-full bg-secondary-600"
                :timelineHeight="!cadastralData && !parcelData ? timelineHeight : 0"
            />
            <transition
                name="custom-classes-transition"
                enter-active-class="animate__animated animate__fadeInUp animate__faster"
                mode="out-in"
            >
                <crop-plan-timeline
                    v-show="editPlotMode === getEditPlotMode.NOT_SELECTED && !cadastralData && !parcelData"
                    :style="`height: ${timelineHeight}px`"
                    class="absolute bottom-0 bg-bg-100"
                />
            </transition>
        </div>
    </tile>
</template>

<script lang="ts">
import { Component, Inject, Mixins } from "vue-property-decorator";
import { TranslateResult } from "vue-i18n";
import DrawMixin from "@abaco/iacs-map-module/src/modules/map-module/mixins/DrawMixin";

import SingleCropPlan from "../..";
import { EditPlotMode, Plot } from "../../models/Plot";
import { FromStore } from "@abaco/web-common/src/app";
import CropPlanTimeline from "./SingleCpTimeline.vue";
import SingleCpMapComponent from "../mapComponent/SingleCpMapComponent.vue";
import CropPlanEditModalWarning from "../private/cropPlanEditModalWarning.vue";
import { CadastralData, ParcelData } from "../../models/Declaration";
import { isGCP } from "../../../../../src/main";

@Component({
    components: {
        CropPlanTimeline,
        SingleCpMapComponent,
        CropPlanEditModalWarning,
    },
})
export default class SingleCpPlotMap extends Mixins(DrawMixin) {
    @Inject() i18n!: (key: string, values?: unknown) => TranslateResult;

    @FromStore(SingleCropPlan.MODULE_ID) editPlotMode!: EditPlotMode;
    @FromStore(SingleCropPlan.MODULE_ID) curPlot!: Plot | null;
    @FromStore(SingleCropPlan.MODULE_ID) curPlots!: Plot[];
    @FromStore(SingleCropPlan.MODULE_ID) cadastralData!: CadastralData[] | null;
    @FromStore(SingleCropPlan.MODULE_ID) parcelData!: ParcelData[] | null;
    @FromStore(SingleCropPlan.MODULE_ID) timelineExpanded!: boolean;

    private timelineHeightOpen = 260; //px

    private get getEditPlotMode() {
        return EditPlotMode;
    }

    private get mapContainerStyle() {
        return {
            height:
                this.editPlotMode !== EditPlotMode.NOT_SELECTED ? "100%" : "calc(100% - " + this.timelineHeight + "px)",
        };
    }
    private get timelineHeight() {
        return this.editPlotMode === EditPlotMode.NOT_SELECTED ? this.timelineExpanded ? this.timelineHeightOpen : 44 : 0;
        // return {
        //     height: this.timelineHeight + "px   ",
        // };
    }

    private getisGCP() {
        return isGCP
    }
}
</script>

<style lang="scss">
.single-cp-map-cointainer,
.cp-timeline-year-selector-icon {
    @apply transition-all duration-150 ease-in-out;
}
.single-cp-timeline-empty-state {
    // background: rgba(255,255,255,.45);
    background: rgba(255, 255, 255, 1);
    -webkit-backdrop-filter: blur(10px);
    backdrop-filter: blur(10px);
}
</style>
