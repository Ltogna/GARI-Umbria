<template>
    <div
        class="single-cp-progress-card flex flex-col border-b px-3 pt-2 pb-2"
        @mouseover="isHovering = true"
        @mouseleave="isHovering = false"
    >
        <!-- <transition name="custom-classes-transition" enter-active-class="animate__animated animate__fadeInDown10 animate__faster" mode="out-in"> -->
        <span class="text-sm font-bold uppercase tracking-wider text-label-primary">{{ label }}</span>
        <!-- </transition> -->
        <span class="text-xs uppercase tracking-wider text-label-primary">{{ haDeclared }}</span>
        <div class="flex items-center">
            <div class="single-cp-area-progress" style="margin-top: 2px">
                <transition
                    appear
                    @before-appear="progressBarBeforeEnter"
                    @after-appear="progressBarEnter(...arguments)"
                >
                    <div
                        class="single-cp-area-progress-bar"
                        :class="{
                            'under-threshold': normal,
                            'under-threshold-warning': warning,
                            'over-threshold': expired,
                        }"
                        ref="bar"
                    />
                </transition>
            </div>
            <div class="pl-3">
                <div class="flex lowercase items-baseline text-label-primary" style="font-size: 13px; margin-top: -1px">
                    <span class="font-semibolda">{{ value }}</span>
                    <span style="padding-left: 1px">%</span>
                </div>
            </div>
        </div>
    </div>
</template>

<script lang="ts">
import { Prop, Component, Inject, Vue, Watch } from "vue-property-decorator";
import { TranslateResult } from "vue-i18n";

@Component
export default class CropPlanProgressCard extends Vue {
    @Inject() i18n!: (key: string, values?: unknown) => TranslateResult;

    @Prop() value!: number;
    @Prop() label!: string;
    @Prop() haDeclared!: string;

    private isHovering = false;
    private barHTML: HTMLElement | null = null;

    mounted() {
        this.barHTML = this.$refs.bar as HTMLElement;
    }

    private get totalThreshold() {
        return 100;
    }

    private get usedThreshold() {
        return this.value;
    }

    private get curPercentage() {
        let percentage = Math.floor(this.usedThreshold / (this.totalThreshold / 100));
        percentage = percentage > 100 ? 100 : percentage;
        return percentage;
    }

    private get warning() {
        return this.curPercentage < 100 && this.curPercentage >= 80;
    }
    private get expired() {
        return this.curPercentage === 100;
    }
    private get normal() {
        return !this.warning && !this.expired;
    }

    private progressBarBeforeEnter(el: HTMLElement) {
        el.style.width = "0%";
    }
    private progressBarEnter(el: HTMLElement) {
        el.style.width = `${this.curPercentage}%`;
        el.style.transition = `width 0.6s ease`;
    }

    @Watch("curPercentage")
    private onPercentageUpdate() {
        if (!this.barHTML) return;
        this.barHTML.style.width = `${this.curPercentage}%`;
    }
}
</script>

<style lang="scss">
.single-cp-progress-card {
    @apply transition-all duration-150 ease-in-out;
}

.single-cp-area-progress,
.single-cp-area-progress-bar,
.single-cp-area-progress-bar-tolerance {
    display: flex;
    overflow: hidden;
}
.single-cp-area-progress {
    width: 100%;
    height: 1rem;
    font-size: 0.75rem;
    border-radius: 0.25rem;
    @apply bg-bg-500 relative;
}
.single-cp-area-progress-bar,
.single-cp-area-progress-bar-tolerance {
    flex-direction: column;
    justify-content: center;
    text-align: center;
    white-space: nowrap;
    transition: width 0.6s ease;
    height: 100%;
}
.single-cp-area-progress {
    @apply mt-2;
    height: 6px;
    border-radius: 50px;
    background: rgba(130, 150, 160, 0.15);
}
.single-cp-area-progress-bar {
    background: linear-gradient(90deg, rgba(39, 163, 227, 1) 0%, rgba(35, 184, 176, 1) 35%, #00c3b3 100%);
    background: linear-gradient(90deg, #fdd24d 0%, #e6cc53 35%, #5ba475 100%);
}

.single-cp-area-progress-bar.under-threshold {
    // background: linear-gradient(90deg, #fdd24d 0%, #e6cc53 35%, #5ba475 100%);
    // background: linear-gradient(90deg, #c5ca53, #abc45a, #94bd61, #5ba475);
    background: #5ba475;
}

.single-cp-area-progress-bar.under-threshold-warning {
    // background: linear-gradient(90deg, #fdd24d 0%, #e6cc53 35%, #5ba475 100%);
    background: linear-gradient(90deg, #fdd24d, #fdca49, #fdc246, #fcb944, #fbb142, #faa940, #f8a140, #f6993f);
}
.single-cp-area-progress-bar.over-threshold {
    background: linear-gradient(90deg, #f8ad65 0%, #ec7a0b 75%, #c0564a 100%);
}

.single-cp-area-progress-bar-tolerance {
    @apply bg-bg-500 absolute;
    top: 0;
    right: 0;
    opacity: 0.5;
}
</style>
