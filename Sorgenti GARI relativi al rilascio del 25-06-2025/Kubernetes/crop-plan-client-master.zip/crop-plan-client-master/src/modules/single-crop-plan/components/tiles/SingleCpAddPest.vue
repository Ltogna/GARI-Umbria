<template>
    <tile :title="i18n('insert-pest')" noContainerStyled>
        <div class="flex w-full h-full overflow-auto">
            <div class="flex px-4 py-6 sm:w-full md:w-full mx-auto lg:w-11/12 xxl:w-9/12">
                <abc-form ref="form" class="flex flex-col w-full sc-decl-edit-form" @submit="submit">
                    <div class="sc-addpesticide-section">
                        <div class="sc-decl-edit-info w-full h-full md:w-4/12 justify-center md:justify-start">
                            <div class="sc-decl-edit-title">
                                <span class="text-4xl text-label-secondary pr-2">{{ i18n("1") }}</span>
                                {{ i18n("add-pest-section-tile") }}
                            </div>
                            <div class="sc-decl-edit-sub-title">
                                {{ i18n("add-pest-section-description") }}
                            </div>
                        </div>
                        <div
                            class="sc-add-pest-plots-list px-4 h-full overflow-y-auto overflow-x-hidden justify-items-start md:justify-start w-full md:w-8/12"
                        >
                            <!-- PLOTS LIST -->
                            <div v-if="plotsReady" class="flex flex-col justify-items-start w-full mb-4">
                                <!-- PLOTS LIST -->
                                <abc-selectable-card
                                    v-for="(plot, index) in plots"
                                    :key="index"
                                    @click="onClick(index, plot)"
                                    :isActive="selectedPlot[index].isActive"
                                    class="flex flex-col w-full ml-0"
                                    style="margin-left: 0"
                                >
                                    <div class="single-crop-plan-crop-row-inner">
                                        <div class="flex items-center mr-3 relative">
                                            <single-cp-map-preview :plot="plot" />
                                        </div>
                                        <div class="flex flex-col flex-grow" style="min-width: 0">
                                            <div class="flex w-full justify-between items-baseline">
                                                <div class="flex flex-wrap items-center font-semibold">
                                                    {{ plot.description }}
                                                </div>
                                                <div class="flex items-baseline" style="margin-top: -2px">
                                                    <span class="font-semibold text-lg pr-1">{{
                                                        formattedArea(plot.areaSqm)
                                                    }}</span>
                                                    <span class="text-base lowercase">{{ areaLabel() }}</span>
                                                </div>
                                            </div>
                                            <div class="flex w-full justify-between">
                                                <div
                                                    class="text-label-primary truncate mb-2"
                                                    :title="
                                                        plot.parcelIntersections &&
                                                        plot.parcelIntersections.length > 0 &&
                                                        parcelsPiped(plot) &&
                                                        parcelsPiped(plot).length > 20
                                                            ? parcelsPiped(plot)
                                                            : ''
                                                    "
                                                >
                                                    {{ parcelsPiped(plot) }}
                                                </div>
                                            </div>
                                            <div class="flex w-full justify-between">
                                                <div class="truncate flex flex-col">
                                                    <span
                                                        v-if="plot.decls && plot.decls.length > 0"
                                                        class="text-secondary-700"
                                                        v-b-tooltip.hover.window.ds400
                                                        :title="
                                                            plot.decls &&
                                                            plot.decls.length > 0 &&
                                                            declarationsPiped(plot) &&
                                                            declarationsPiped(plot).length > 20
                                                                ? declarationsPiped(plot)
                                                                : ''
                                                        "
                                                    >
                                                        <p
                                                            v-if="
                                                                plot.decls.length > 1 &&
                                                                declarationsPiped(plot).length > 20
                                                            "
                                                        >
                                                            {{ i18n("multiple-land-uses") }}
                                                        </p>
                                                        <p v-else>{{ declarationsPiped(plot) }}</p>
                                                    </span>
                                                    <span v-else class="text-label-secondary">
                                                        {{ i18n("no-land-uses") }}
                                                    </span>
                                                </div>
                                                <div class="flex items-baseline">
                                                    <span style="padding-right: 1px">
                                                        {{ getFieldOccupied(plot) }}
                                                    </span>
                                                    <span class="lowercase">%</span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </abc-selectable-card>
                            </div>
                        </div>
                    </div>

                    <div class="sc-decl-edit-section">
                        <div class="sc-decl-edit-info w-full md:w-4/12 justify-center md:justify-start">
                            <div class="sc-decl-edit-title">
                                <span class="text-4xl text-label-secondary pr-2">{{ i18n("2") }}</span>
                                {{ i18n("add-pest-details-title") }}
                            </div>
                            <div class="sc-decl-edit-sub-title">
                                {{ i18n("add-pest-details-description") }}
                            </div>
                        </div>
                        <div class="sc-decl-edit-fields w-full md:w-8/12 justify-center md:justify-start">
                            <div class="flex w-full mb-4">
                                <!-- DECLS LIST -->
                                <abc-dropdown2 
                                    class="w-1/2"
                                    :label="i18n('crop')"
                                    v-model="curCrop"
                                    :items="declarations" 
                                    :rules="[mandatoryRule]"
                                >
                                    <p v-if="curCrop">
                                        {{ curCrop.landuse.description }}
                                        {{ curCropTotalArea ? " - " + curCropTotalArea : "" }}
                                    </p>
                                    <template #items="{ item }">
                                        <div class="cursor-pointer">
                                            {{ item.landuse.description }}
                                            {{ curCropTotalArea ? " - " + curCropTotalArea : "" }}
                                        </div>
                                    </template>
                                </abc-dropdown2>
                            </div>
                            <div class="flex w-full">
                                <!-- PESTS LIST -->
                                <div class="flex w-6/12">
                                    <abc-autocomplete
                                        :is-disabled="!this.curCrop || this.curCrop === null"
                                        class="w-full"
                                        :label="i18n('pest-title')"
                                        :value="curPest"
                                        itemId="pestCode"
                                        :items="pestsPage.records"
                                        :stringify="(item) => (item ? item.pestName : null)"
                                        :search.sync="searchPest"
                                        maxHeight="300px"
                                        buttons
                                        @input="updatecurPest"
                                        :rules="[mandatoryRule]"
                                    >
                                        <template #items="{ item }">
                                            <div>{{ item.pestName }}</div>
                                        </template>
                                        <template>
                                            <div v-if="pestsLoading" class="flex justify-center items-center h-12">
                                                <abc-loader :size="32" />
                                            </div>
                                            <div
                                                v-if="!pestsLoading && pestsPage.records.length === 0"
                                                class="flex justify-center items-center h-12"
                                            >
                                                <abc-no-data-found />
                                            </div>
                                            <div
                                                v-if="
                                                    !pestsLoading &&
                                                    pestsPage.records.length > 0 &&
                                                    pestsPage.haveMore
                                                "
                                                class="flex justify-center items-center h-12"
                                            >
                                                <abc-refine-filter />
                                            </div>
                                        </template>
                                        <template #buttons>
                                            <abc-tool-button
                                                is-secondary
                                                @click="
                                                    searchPest = '';
                                                    curPest = null;
                                                "
                                                :title="i18n('clear-field')"
                                            >
                                                <em class="abc-icon abc-icon-x text-xs"></em>
                                            </abc-tool-button>
                                        </template>
                                    </abc-autocomplete>
                                </div>
                            </div>

                            <div class="flex w-full mt-2 mb-4">
                                <!-- Actions -->
                                <abc-alert
                                    v-if="curPest && curPest !== null && curPest.actions"
                                    class="w-7/12 mb-4 mr-2" 
                                    is-info 
                                    :title="i18n('pest-actions-todo')" 
                                    :messages="[curPest.actions]" 
                                />
                                <abc-alert
                                    v-if="curPest && curPest !== null && curPest.quarantineDays !== null"
                                    class="w-4/12 mb-4" 
                                    is-info 
                                    :title="i18n('quarantine-days')" 
                                    :messages="[curPest.quarantineDays]" 
                                />
                            </div>

                            <div class="flex w-full">
                                <abc-input
                                    class="w-6/12 pr-2"
                                    v-model="curPestAppliedMeasures"
                                    autocomplete="off"
                                    :label="i18n('pest-measures-applied')"
                                    ref="pestMeasuresApplied"
                                    :rules="[mandatoryRule]"
                                >
                                </abc-input>
                                <abc-input
                                    class="w-3/12 pr-2"
                                    right-tools
                                    text-right
                                    is-numeric
                                    :maxLength="100"
                                    v-model="curPestAffectedAreaPerc"
                                    autocomplete="off"
                                    :label="i18n('pest-area-affected-perc')"
                                    ref="pestAreaAffected"
                                    :rules="[mandatoryRule, percentageRule]"
                                >
                                    <template #right>%&thinsp;</template>
                                </abc-input>
                                <div class="w-2/12 ml-2">
                                    <div class="mb-1 flex">
                                        {{i18n("affected-area-m2")}}
                                    </div>
                                    <div class="flex items-center text-3xl" style="font-size: 16px; margin-top: 8px;">
                                        <span class="font-semibold">
                                            {{ convertAreaPercentToSqm(curPestAffectedAreaPerc) }}
                                        </span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="sc-decl-edit-section">
                        <div class="sc-decl-edit-info w-full md:w-4/12 justify-center md:justify-start"></div>
                        <div class="sc-decl-edit-fields justify-center md:justify-start w-full md:w-8/12">
                            <abc-form-buttons
                                class="pb-8"
                                @save="submit"
                                @cancel="close"
                                :has-continue="false"
                                :disable-confirm-button="disableFormButtons"
                            />
                        </div>
                    </div>
                </abc-form>
            </div>
        </div>
    </tile>
</template>

<script lang="ts">
import { Prop, Component, Inject, Watch, Mixins, Ref, ProvideReactive } from "vue-property-decorator";
import { TranslateResult } from "vue-i18n";
import SingleCropPlanModule, { MODULE_ID } from "../..";
import { FromStore, ToastOptions } from "@abaco/web-common/src/app";
import { Business } from "../../models/Business";
import { Plot, TargetPlotDeclaration } from "../../models/Plot";
import DateUtils from "../../mixins/DateUtils";
import { Validable } from "@abaco/web-components/src/components/form/Validable";
import { Configuration, CropPlan } from "../../models/CropPlan";
import { Council } from "../../models/Council";
import { Pest, Pesticide, PesticideOut, PestOut } from "../../models/Declaration";
import AreaUtils from "../../mixins/AreaUtils";
import { VBTooltip } from "bootstrap-vue";
import { EmptyMaxPagedResults, MaxPagedResults } from "@abaco/web-common/src/Paging";
import { Debounce } from "vue-debounce-decorator";
import SingleCpMapPreview from "../mapComponent/SingleCPMapPreview.vue";
import { Version } from "../../models/Version";
import { ValidationMessage } from "../../models/Utils";
import CropPlanPostEditMessagesModal from "../private/cropPlanPostEditMessagesModal.vue";
import PermanentCropForms from "../private/permanentCropForms.vue";
import { UnitOfMeasurement, UnitsOfMeasure, UomType } from "../../models/UnitOfMeasure";
import { formatDate } from "../../api/Utils";

@Component({
    directives: {
        "b-tooltip": VBTooltip,
    },
    components: {
        SingleCpMapPreview,
        CropPlanPostEditMessagesModal,
        PermanentCropForms,
    },
})
export default class SingleCpAddPesticide extends Mixins(DateUtils, AreaUtils) {
    @Inject() i18n!: (key: string, values?: unknown) => TranslateResult;
    @Inject() toast!: (message: string, options?: ToastOptions) => TranslateResult;
    @Inject(MODULE_ID) singleCropPlanModule!: SingleCropPlanModule;

    @FromStore(MODULE_ID) business!: Business;
    @FromStore(MODULE_ID) curPlot!: Plot | null;
    @FromStore(MODULE_ID) curPlots!: Plot[];
    @FromStore(MODULE_ID) curPointInTime!: Date;
    @FromStore(MODULE_ID) curCropPlan!: CropPlan | null;
    @FromStore(MODULE_ID) curCouncil!: Council | null;
    @FromStore(MODULE_ID) editPlotPolygonDrawn!: boolean;
    @FromStore(MODULE_ID) curVersion!: Version | null;
    @FromStore(MODULE_ID) hideFieldName!: boolean;
    @FromStore(MODULE_ID) curConfiguration!: Configuration | null;

    @Prop() declarations!: TargetPlotDeclaration[];
    @Prop() targetPlots!: Plot[];

    @Ref("form") form!: Validable;

    @ProvideReactive("PestOutDetail")
    private detail: PestOut = {
        pestCode: undefined,
        areaAffected: null,
        measuresApplied: null,
        date: undefined,
    };

    private disableFormButtons = false;
    private loading = true;
    private percentageDivider = 1000000;
    private percentageDecimalNumber = 6;
    private hectaresDecimalNumber = 4;
    private validationMessages: ValidationMessage[] = [];

    private selectedPlots: Plot[] = [];
    private plots: Plot[] = [];
    private selectedPlot: { plotCode: string; isActive: boolean }[] = [];
    private plotsReady = false;
    private curCrop: TargetPlotDeclaration | null = null;
    private curCropTotalArea: string | null = null;
    private selectedPlotsTotalArea: number | null = null;
    private selectedPlotsDecls: TargetPlotDeclaration[] = [];

    private pestsPage: MaxPagedResults<unknown> = new EmptyMaxPagedResults();
    private searchPest: string | null = null;
    private pestsLoading = false;
    private curPest: Pest | null = null;

    private lastCurCrop: TargetPlotDeclaration | null = null;
    private curPestAppliedMeasures: string | null = null;
    private curPestAffectedAreaPerc: number | null = null;

    @Watch("plots")
    checkPlots() {
        this.selectedPlot = this.plots.map((plot: Plot) => {
            return { plotCode: plot.plotCode, isActive: false };
        });
    }

    @Watch("curCrop")
    async checkSelectedPlots() {
        this.getTotalDeclsAreas();
        this.searchPest = "";
        this.curPest = null;
        await this.triggerPestSearch();
    }

    @Watch("searchPest")
    @Debounce(300)
    private async triggerPestSearch() {
        if (this.curCrop && this.curCrop !== null && this.curCropPlan) {
            this.pestsLoading = true;
            this.pestsPage = new EmptyMaxPagedResults();
            let page = await this.singleCropPlanModule.cropPlanApi.getPestList(
                this.business.businessId,
                this.curCropPlan.cropPlanId,
                this.searchPest ? this.searchPest.trim().toUpperCase() : "",
                this.curCrop ? this.curCrop.landuse.code : null
            );
            if (page.count === 1 && this.searchPest === page.records[0].pestName) {
                const res = page.records[0];
                page = await this.singleCropPlanModule.cropPlanApi.getPestList(
                    this.business.businessId,
                    this.curCropPlan.cropPlanId,
                    null,
                    this.curCrop ? this.curCrop.landuse.code : null
                );
                page.records = page.records.filter((l) => l.pestCode !== res.pestCode);
                page.records.unshift(res);
                if (this.curPest) {
                    this.curPest = { ...this.curPest };
                }
            }
            this.pestsPage = page;
            this.pestsLoading = false;
        }
    }

    private updatecurPest(value: Pest) {
        this.curPest = value;
    }

    async mounted() {
        this.targetPlots.forEach((p) => {
            this.plots.push(p);
        });
        this.plotsReady = true;
        this.getTotalDeclsAreas();
    }

    private async submit() {
        const isValid = this.form.validate();
        if (isValid) {
            this.disableFormButtons = true;
            await this.insertPest();
        }
    }

    private async insertPest() {
        try {
            if (!this.curPest || !this.curPest.pestCode || !this.curPestAppliedMeasures || !this.curPestAffectedAreaPerc) return;
            const detailOut: PestOut = this.detail;
            detailOut.pestCode = this.curPest.pestCode;
            detailOut.measuresApplied = this.curPestAppliedMeasures;
            detailOut.areaAffected = this.curPestAffectedAreaPerc;
            detailOut.date = this.curPointInTime ? formatDate(this.curPointInTime) : undefined;
            if (this.curCrop && this.selectedPlots.length > 0) {
                const insertRes = await Promise.all(
                    this.selectedPlots.map(async (plot) => {
                        plot.decls.map(async (decl) => {
                            if (
                                this.curCrop &&
                                decl.landuse.code === this.curCrop.landuse.code &&
                                this.curCropPlan &&
                                this.curCouncil
                            ) {
                                const res = await this.singleCropPlanModule.cropPlanApi.insertPest(
                                    this.business.businessId,
                                    this.curCropPlan.cropPlanId,
                                    this.curCouncil.domainZoneId,
                                    plot.plotCode,
                                    decl.declCode.toString(),
                                    detailOut
                                );
                                if (!res) {
                                    return;
                                }
                            }
                        });
                    })
                );
                if (insertRes) {
                    this.$emit("inserted");
                    this.$emit("refresh");
                    this.toast(this.i18n("pest-inserted").toString(), { type: "success" });
                }
            } else {
                if (!this.selectedPlots.length)
                    this.toast(this.i18n("no-plots-selected-message-pesticide").toString(), { type: "warn" });
            }
        } catch (error) {
            this.toast(error as string, { type: "error" });
        } finally {
            this.disableFormButtons = false;
        }
    }

    private close() {
        this.$emit("close-current-view");
    }

    private onClick(index: number, plot: Plot) {
        this.selectedPlot[index].isActive = !this.selectedPlot[index].isActive;
        this.selectedPlot.push({ plotCode: "-1", isActive: false });
        this.selectedPlot.pop();

        const curIdx = this.selectedPlots.findIndex((p) => p.plotCode === plot.plotCode);
        if (curIdx > -1) {
            this.selectedPlots.splice(curIdx, 1);
        } else {
            this.selectedPlots.push(plot);
        }
        this.getTotalDeclsAreas();
    }

    private parcelsPiped(e: Plot): string | null {
        if (e.parcelIntersections && e.parcelIntersections.length > 0) {
            let str = "";
            e.parcelIntersections.forEach((e) => (str = str ? str + ", " + e.description : e.description));
            return str;
        } else {
            return this.i18n("no-parcel-intersection").toString();
        }
    }
    private declarationsPiped(e: Plot): string | null {
        if (e.decls && e.decls.length > 0) {
            let str = "";
            e.decls.forEach(
                (e) =>
                    (str = str
                        ? str + ", " + (e.landuse.description || e.landuse.code)
                        : e.landuse.description || e.landuse.code)
            );
            return str;
        } else {
            return null;
        }
    }
    private getFieldOccupied(e: Plot): number | null {
        let totalCropArea = 0;
        e.decls
            .filter(
                (d) =>
                    d.fromDate.getTime() <= this.curPointInTime.getTime() &&
                    d.toDate.getTime() >= this.curPointInTime.getTime()
            )
            .forEach((d) => {
                let areaSqm = 0;
                if (d.areaPerc === 100) {
                    areaSqm = e.areaSqm;
                } else {
                    const plotAreaHa = e.areaSqm;
                    const onePercent = plotAreaHa / 100;
                    areaSqm = Math.round(onePercent * d.areaPerc * 10000) / 10000;
                }
                totalCropArea = totalCropArea + areaSqm;
            });
        const areaPercent = e.areaSqm / 100;
        const res = totalCropArea / areaPercent;
        return Math.round(isNaN(res) ? 0 : res);
    }

    private getTotalDeclsAreas() {
        this.selectedPlotsDecls = [];
        let sum = 0;
        let selectedPlotsAreaSum = 0;
        if (this.selectedPlots.length > 0) {
            this.selectedPlots.forEach((plot) => {
                plot.decls.forEach((decl) => {
                    const targetDecl: TargetPlotDeclaration = decl as TargetPlotDeclaration;
                    targetDecl.areaSqm = plot.areaSqm;
                    targetDecl.formattedArea = this.getCropAreaFromPercent(
                        targetDecl.areaPerc,
                        this.formattedArea(targetDecl.areaSqm)
                    );
                    this.selectedPlotsDecls.push(targetDecl);
                });
                selectedPlotsAreaSum += plot.areaSqm;
                this.selectedPlotsTotalArea = selectedPlotsAreaSum;
            });
            if (this.selectedPlotsDecls.length) {
                if (this.curCrop && this.curCrop !== null) {
                    this.selectedPlotsDecls.forEach((decl) => {
                        if (decl.landuse && this.curCrop?.landuse && decl.landuse.code === this.curCrop?.landuse.code) {
                            sum += Number(decl.formattedArea);
                        }
                    });
                    this.curCropTotalArea =
                        sum.toLocaleString(this.getLocale(), { minimumFractionDigits: 4, maximumFractionDigits: 4 }) +
                        " " +
                        this.areaLabel();
                }
            }
        } else {
            this.curCropTotalArea = null;
            this.selectedPlotsTotalArea = null;
        }
    }

    private getCropAreaFromPercent(declPercent: number, plotArea: string) {
        return ((Number(plotArea) * declPercent) / 100).toLocaleString(this.getLocale(), {
            minimumFractionDigits: 2,
            maximumFractionDigits: 4,
        });
    }

    private convertAreaPercentToSqm(percentage: number): string {
        return (this.selectedPlotsTotalArea! * percentage / 100).toLocaleString(this.getLocale(), {
            minimumFractionDigits: 2,
            maximumFractionDigits: 4,
        });
    }

    
    private mandatoryRule = (v: unknown) => !!v || this.i18n("valid.mandatory-field");

    private mandatoryRuleAtomic = (v: unknown) => !!v || this.i18n("valid.mandatory-field");
    
    private mandatoryNumberRuleAtomic = (v: unknown) => !!v || v == 0 || this.i18n("valid.mandatory-field");

    private percentageRule = (v: string | null) =>
        (v && (parseInt(v) < 0 || parseInt(v) > 100)) || v == "0" ? this.i18n("between-0-and-100-rule") : null;
}
</script>

<style lang="scss" scoped>
.edit-crop-plan-crop-row,
.edit-crop-plan-crop-row-border {
    @apply transition-all duration-150 ease-in-out relative;
}

.edit-crop-plan-crop-row {
    @apply flex cursor-pointer items-stretch w-full max-w-full relative;
}
.edit-crop-plan-crop-row-inner {
    @apply flex items-stretch w-full max-w-full py-3 px-3;
}

.edit-crop-plan-crop-row .edit-crop-plan-crop-row-border {
    @apply border rounded-lg absolute top-0 left-0 w-full h-full;
}
.edit-crop-plan-crop-row:hover .edit-crop-plan-crop-row-border,
.edit-crop-plan-crop-row-active .edit-crop-plan-crop-row-border {
    @apply border-info-300;
}

.edit-crop-plan-crop-row-active .edit-crop-plan-crop-row-border {
    border-width: 2px;
}

.sc-decl-edit-form {
    @apply flex gap-4;
    flex-direction: column;
    align-content: stretch;
}
.sc-decl-edit-section {
    @apply px-4 flex flex-wrap;
    flex-grow: 1;
}
.sc-addpesticide-section {
    @apply px-4 flex flex-wrap;
    flex-grow: 1;
    height: 40vh;
}

.sc-decl-edit-info {
    @apply flex flex-col items-start pr-6 text-label-primary;
}

.sc-decl-edit-title {
    @apply w-full flex font-bold items-baseline text-secondary-700;
}
.sc-decl-edit-sub-title {
    @apply w-full flex;
}

.sc-decl-edit-info div:last-of-type {
    @apply pb-2 border-b;
}

.sc-decl-edit-fields {
    @apply flex flex-col;
}
.sc-addpesticide-plots-list {
    @apply flex flex-col;
    height: 40vh;
    .selectable-card {
        margin-left: 0 !important;
    }
}

@media (min-width: 640px) {
    .sc-decl-edit-fields {
        @apply mt-2;
    }
}
@media (min-width: 768px) {
    .sc-decl-edit-fields {
        @apply pl-6 border-l;
    }
}
</style>
