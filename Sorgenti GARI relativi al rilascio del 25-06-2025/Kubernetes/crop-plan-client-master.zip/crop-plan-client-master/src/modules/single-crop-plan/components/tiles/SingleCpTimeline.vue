<template>
    <div class="flex w-full h-full">
        <div
            class="px-5"
            style="
                left: 50%;
                position: absolute;
                top: -20px;
                background-color: white;
                border-top-left-radius: 25px 15px;
                border-top-right-radius: 25px 15px;
            "
            @click="expandCollapseTimeline()"
        >
            <em class="fa-solid" :class="timelineExpanded ? 'fa-chevron-down' : 'fa-chevron-up'"></em>
        </div>
        <abc-modal
            v-if="openAnomaliesModal"
            @close="openAnomaliesModal = false"
            modal-class="w-full md:w-8/12 lg:w-6/12 xxl:w-4/12"
            :title="i18n('declaration-anomalies')"
        >
            <template #body>
                <div class="pb-4 flex flex-col w-full">
                    <div class="flex flex-grow flex-col items-baseline">
                        <div
                            v-if="declarationWarningAnomalies.length > 0"
                            class="bg-warning-100 w-full px-6 py-4 rounded-xl mb-2"
                        >
                            <div class="text-warning-600 text-xl font-bold">
                                <em class="text-warning-600 fa-regular fa-triangle-exclamation mr-5" />{{
                                    i18n("warning-anomalies")
                                }}
                            </div>
                        </div>
                        <table
                            aria-describedby=""
                            v-if="declarationWarningAnomalies.length > 0"
                            style="border: none"
                            cellspacing="0"
                            cellpadding="0"
                        >
                            <tr v-for="item in declarationWarningAnomalies" :key="item.errorCode">
                                <td class="warning-bullet pr-2">&bull;</td>
                                <td>
                                    {{ item.errorDescription ? item.errorDescription : item.errorCode }}
                                </td>
                            </tr>
                        </table>
                        <div
                            v-if="declarationBlockingAnomalies.length > 0"
                            class="bg-danger-100 w-full px-6 py-4 rounded-xl my-2"
                        >
                            <div class="text-danger-600 text-xl font-bold">
                                <em class="text-danger-600 fa-regular fa-circle-xmark mr-5" />{{
                                    i18n("blocking-anomalies")
                                }}
                            </div>
                        </div>
                        <table
                            aria-describedby=""
                            v-if="declarationBlockingAnomalies.length > 0"
                            style="border: none"
                            cellspacing="0"
                            cellpadding="0"
                        >
                            <tr v-for="item in declarationBlockingAnomalies" :key="item.errorCode">
                                <td class="blocking-bullet pr-2">&bull;</td>
                                <td>
                                    {{ item.errorDescription ? item.errorDescription : item.errorCode }}
                                </td>
                            </tr>
                        </table>
                    </div>
                </div>
            </template>
        </abc-modal>

        <PlotCompleteTaraModal
            v-if="openPlotCompleteTaraModal"
            @update="openPlotCompleteTaraModal = false"
            @close="openPlotCompleteTaraModal = false"
            style="z-index: 51"
        />

        <!-- SHARED CROPS MODAL -->
        <abc-modal
            modal-class="w-full lg:w-6/12 xxl:w-4/12"
            top-pinned
            show-navbar
            :title="getSharedCropsModalTitle"
            v-if="showSharedCropsModal"
            @close="showSharedCropsModal = false"
        >
            <template #body>
                <div class="flex">
                    <div v-if="curPlots && curPlots.length">
                        <div v-if="uniqueTargetPlotsDeclarations.length" class="flex flex-col w-full">
                            <div
                                v-for="(decl, index) in uniqueTargetPlotsDeclarations"
                                :key="index"
                                class="flex flex-col border-b pt-2"
                            >
                                <div class="flex">
                                    <p class="w-full font-semibold">{{ decl.landuse.description }}</p>
                                </div>
                                <div class="flex pb-2">
                                    <p class="w-full">{{ getModalTotalDeclsAreas(decl.landuse.code) }}</p>
                                </div>
                            </div>
                        </div>
                        <div v-else>
                            <span>{{ i18n("no-shared-crops") }}</span>
                        </div>
                    </div>
                    <div v-if="curPlot && curPlot !== null && !curPlots.length">
                        <div v-if="curSinglePlotDeclarations.length" class="flex flex-col w-full">
                            <div
                                v-for="(decl, index) in curSinglePlotDeclarations"
                                :key="index"
                                class="flex flex-col border-b pt-2"
                            >
                                <div class="flex">
                                    <p class="w-full font-semibold">{{ decl.landuse.description }}</p>
                                </div>
                                <div class="flex pb-2">
                                    <p class="w-full">{{ getModalTotalDeclsAreas(decl.landuse.code) }}</p>
                                </div>
                            </div>
                        </div>
                        <div v-else>
                            <span>{{ i18n("no-shared-crops") }}</span>
                        </div>
                    </div>
                </div>
            </template>
            <template #footer>
                <div class="flex w-full justify-start">
                    <abc-button is-secondary is-outlined @click="showSharedCropsModal = false">
                        <em class="abc-icon abc-icon-arrow-left-round" />{{ i18n("back") }}
                    </abc-button>
                </div>
            </template>
        </abc-modal>

        <!-- CROP PESTICIDE LIST MODAL -->
        <abc-modal
            class="z-50"
            modal-class="w-full lg:w-6/12 xxl:w-4/12 z-50"
            top-pinned
            show-navbar
            :title="i18n('decl-pesticide-list')"
            v-if="showDeclPesticidesModal"
            @close="showDeclPesticidesModal = false"
        >
            <template #body>
                <div v-if="curDeclaration.pesticides.length" class="w-full flex flex-col gap-2">
                    <div
                        v-for="(product, index) in curDeclaration.pesticides"
                        :key="index"
                        :class="{ 'border-b': index < curDeclaration.pesticides.length - 1 }"
                    >
                        <div class="flex flex-row gap-4 justify-between">
                            <div>
                                <p class="w-full font-semibold">{{ product.productName }}</p>
                                <p class="w-full">{{ getPesticideQt(product) }}</p>
                            </div>
                            <div class="text-right">
                                <div>
                                    {{
                                        (product.entryDate ? formattedDate(product.entryDate) : "") +
                                        (product.userId ? " " + i18n("by") + " " + product.userId : "")
                                    }}
                                </div>
                                <div class="text-label-primary">
                                    {{
                                        curPlot.parcelIntersections.reduce(
                                            (out, i) => (out != "" ? ", " + i.description : i.description),
                                            ""
                                        )
                                    }}
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div v-else>
                    <abc-no-data-found />
                </div>
            </template>
            <template #footer>
                <div class="flex w-full justify-start">
                    <abc-button is-secondary is-outlined @click="showDeclPesticidesModal = false">
                        <em class="abc-icon abc-icon-arrow-left-round" />{{ i18n("back") }}
                    </abc-button>
                </div>
            </template>
        </abc-modal>

        <!-- openCloneMode -->
        <CopyOrMoveDeclaration
            :sourcePlot="firstPlot"
            :openCloneMode="openCloneMode"
            :noClonePlotCodes="getNoClonPlotCodes"
            :targetPlots="getTargetPlots"
            :loadingCompatibleUse="getLoadingCompatibleUse"
            @openCloneModeUpdate="(value) => (openCloneMode = value)"
        />

        <!-- ADD PRODUCT mode -->
        <div class="flex flex-col w-full h-full p-5" v-if="openAddProductMode && enablePesticides && !openAddPestMode">
            <div class="flex flex-row h-full">
                <div class="flex flex-col w-1/2 flex-grow">
                    <span class="font-semibold text-2xl">{{ i18n("add-pesticide-use") }}</span>
                    <span class="font-bold mt-6">{{ i18n("select-interested-plots") }}</span>
                    <span class="mt-2 mr-4">{{ i18n("select-interested-plots-desc") }}</span>
                </div>
                <div class="flex flex-col w-1/2 h-full">
                    <div
                        class="border flex flex-row m-auto w-full px-6 py-4 rounded-2xl"
                        :class="{ 'bg-danger-50': invalidParcelsForPesticides.length }"
                        style="min-height: 85px"
                    >
                        <em
                            class="text-icon bg-bg-500 rounded my-auto px-4 py-4 mr-3 text-info-400 text-3xl abc-icon abc-icon-point-of-interest"
                        />
                        <div class="flex flex-col">
                            <div v-if="invalidParcelsForPesticides.length">
                                <span class="font-semibold"
                                    >{{ i18n("invalid-parcels-for-pesticides-message") }} :</span
                                >
                                <ul>
                                    <li v-for="parcel in invalidParcelsForPesticides" :key="parcel.code">
                                        - {{ parcel.description }}
                                    </li>
                                </ul>
                            </div>
                            <template v-else>
                                <div class="flex">
                                    <span>{{ i18n("selected-plots") }}</span>
                                </div>
                                <div class="flex flex-row items-center">
                                    <div class="flex flex-col">
                                        <span class="font-bold text-3xl">
                                            {{ curPlots.length + (curPlot !== null ? 1 : 0) }}
                                        </span>
                                    </div>
                                    <div class="flex flex-col mx-2">
                                        <span class="font-semibold text-3xl text-icon">
                                            {{ getTotalDeclsAreas() }}
                                        </span>
                                    </div>
                                    <div class="flex flex-col" v-if="curPlots && !curPlots.length && !notCommonDecls">
                                        <abc-button
                                            v-if="curPlot !== null"
                                            is-icon
                                            :is-success="sharedCropsLength > 0"
                                            :is-danger="sharedCropsLength === 0"
                                            :is-disabled="sharedCropsLength === 0"
                                            class="w-full items-center sc-shared-crops-button"
                                            @click="
                                                () =>
                                                    curSinglePlotDeclarations.length
                                                        ? (showSharedCropsModal = true)
                                                        : null
                                            "
                                        >
                                            <em class="abc-icon abc-icon-plant-2" />
                                            <template v-if="sharedCropsLength > 0">
                                                &nbsp;
                                                <span>{{ sharedCropsLength }}</span>
                                                <span>&nbsp;{{ i18n("selected-crops") }}</span>
                                            </template>
                                            <template v-if="sharedCropsLength === 0">
                                                &nbsp;
                                                <span> {{ i18n("no-shared-crops") }}</span>
                                            </template>
                                        </abc-button>

                                        <abc-button
                                            v-if="curPlot === null"
                                            is-icon
                                            is-danger
                                            is-disabled
                                            class="w-full items-center sc-shared-crops-button"
                                        >
                                            <em class="abc-icon abc-icon-plant-2" />
                                            <span>
                                                &nbsp;
                                                {{ i18n("no-shared-crops") }}
                                            </span>
                                        </abc-button>
                                    </div>
                                    <div class="flex flex-col" v-if="curPlots && curPlots.length > 0">
                                        <abc-button
                                            v-if="!notCommonDecls"
                                            is-icon
                                            is-success
                                            is-clickable
                                            class="w-full items-center sc-shared-crops-button"
                                            @click="() => (showSharedCropsModal = true)"
                                        >
                                            <em class="abc-icon abc-icon-plant-2" />
                                            <span>
                                                &nbsp;
                                                <span>{{ sharedCropsLength }}</span>
                                                <span>&nbsp;{{ i18n("shared-crops") }}</span>
                                            </span>
                                        </abc-button>

                                        <abc-button
                                            v-if="notCommonDecls"
                                            is-icon
                                            is-danger
                                            is-disabled
                                            class="w-full items-center sc-shared-crops-button"
                                        >
                                            <em class="abc-icon abc-icon-plant-2" />
                                            &nbsp;{{ i18n("no-shared-crops") }}
                                        </abc-button>
                                    </div>
                                </div>
                            </template>
                        </div>
                    </div>
                </div>
            </div>
            <div class="flex flex-row" style="margin-left: 1.5px; margin-top: auto">
                <abc-button @click="() => (openAddProductMode = false)" is-icon is-outlined style="min-width: 150px">
                    <em class="abc-icon abc-icon-arrow-left" style="margin-top: 3.5px; margin-bottom: 3.5px" />&nbsp;{{
                        i18n("cancel")
                    }}
                </abc-button>
                <abc-button
                    v-if="
                        curPlot !== null &&
                        !notCommonDecls &&
                        (uniqueTargetPlotsDeclarations.length > 0 || curSinglePlotDeclarations.length > 0) &&
                        invalidParcelsForPesticides.length == 0
                    "
                    @click="
                        () => {
                            curTimelineSection = null;
                            openAddProductTile = true;
                        }
                    "
                    is-icon
                    is-success
                    class="ml-5"
                    style="min-width: 150px"
                >
                    <em class="abc-icon abc-icon-arrow-right" style="margin-top: 3.5px; margin-bottom: 3.5px" />&nbsp;
                    {{ i18n("continue") }}
                </abc-button>
            </div>
        </div>

        <!-- ADD PEST mode -->
        <div class="flex flex-col w-full h-full p-5" v-if="openAddPestMode && enablePest && !openAddProductMode">
            <div class="flex flex-row h-full">
                <div class="flex flex-col w-1/2 flex-grow">
                    <span class="font-semibold text-2xl">{{ i18n("add-pest-use") }}</span>
                    <span class="font-bold mt-6">{{ i18n("select-interested-plots") }}</span>
                    <span class="mt-2 mr-4">{{ i18n("select-interested-plots-pest-desc") }}</span>
                </div>
                <div class="flex flex-col w-1/2 h-full">
                    <div class="border flex flex-row m-auto w-full px-6 py-4 rounded-2xl" style="min-height: 85px">
                        <em
                            class="text-icon bg-bg-500 rounded my-auto px-4 py-4 mr-3 text-info-400 text-3xl abc-icon abc-icon-point-of-interest"
                        />
                        <div class="flex flex-col">
                            <template>
                                <div class="flex">
                                    <span>{{ i18n("selected-plots") }}</span>
                                </div>
                                <div class="flex flex-row items-center">
                                    <div class="flex flex-col">
                                        <span class="font-bold text-3xl">
                                            {{ curPlots.length + (curPlot !== null ? 1 : 0) }}
                                        </span>
                                    </div>
                                    <div class="flex flex-col mx-2">
                                        <span class="font-semibold text-3xl text-icon">
                                            {{ getTotalDeclsAreas() }}
                                        </span>
                                    </div>
                                    <div class="flex flex-col" v-if="curPlots && !curPlots.length && !notCommonDecls">
                                        <abc-button
                                            v-if="curPlot !== null"
                                            is-icon
                                            :is-success="sharedCropsLength > 0"
                                            :is-danger="sharedCropsLength === 0"
                                            :is-disabled="sharedCropsLength === 0"
                                            class="w-full items-center sc-shared-crops-button"
                                            @click="
                                                () =>
                                                    curSinglePlotDeclarations.length
                                                        ? (showSharedCropsModal = true)
                                                        : null
                                            "
                                        >
                                            <em class="abc-icon abc-icon-plant-2" />
                                            <template v-if="sharedCropsLength > 0">
                                                &nbsp;
                                                <span>{{ sharedCropsLength }}</span>
                                                <span>&nbsp;{{ i18n("selected-crops") }}</span>
                                            </template>
                                            <template v-if="sharedCropsLength === 0">
                                                &nbsp;
                                                <span> {{ i18n("no-shared-crops") }}</span>
                                            </template>
                                        </abc-button>

                                        <abc-button
                                            v-if="curPlot === null"
                                            is-icon
                                            is-danger
                                            is-disabled
                                            class="w-full items-center sc-shared-crops-button"
                                        >
                                            <em class="abc-icon abc-icon-plant-2" />
                                            <span>
                                                &nbsp;
                                                {{ i18n("no-shared-crops") }}
                                            </span>
                                        </abc-button>
                                    </div>
                                    <div class="flex flex-col" v-if="curPlots && curPlots.length > 0">
                                        <abc-button
                                            v-if="!notCommonDecls"
                                            is-icon
                                            is-success
                                            is-clickable
                                            class="w-full items-center sc-shared-crops-button"
                                            @click="() => (showSharedCropsModal = true)"
                                        >
                                            <em class="abc-icon abc-icon-plant-2" />
                                            <span>
                                                &nbsp;
                                                <span>{{ sharedCropsLength }}</span>
                                                <span>&nbsp;{{ i18n("shared-crops") }}</span>
                                            </span>
                                        </abc-button>

                                        <abc-button
                                            v-if="notCommonDecls"
                                            is-icon
                                            is-danger
                                            is-disabled
                                            class="w-full items-center sc-shared-crops-button"
                                        >
                                            <em class="abc-icon abc-icon-plant-2" />
                                            &nbsp;{{ i18n("no-shared-crops") }}
                                        </abc-button>
                                    </div>
                                </div>
                            </template>
                        </div>
                    </div>
                </div>
            </div>
            <div class="flex flex-row" style="margin-left: 1.5px; margin-top: auto">
                <abc-button @click="() => (openAddPestMode = false)" is-icon is-outlined style="min-width: 150px">
                    <em class="abc-icon abc-icon-arrow-left" style="margin-top: 3.5px; margin-bottom: 3.5px" />&nbsp;{{
                        i18n("cancel")
                    }}
                </abc-button>
                <abc-button
                    v-if="
                        curPlot !== null &&
                        !notCommonDecls &&
                        (uniqueTargetPlotsDeclarations.length > 0 || curSinglePlotDeclarations.length > 0)
                    "
                    @click="
                        () => {
                            curTimelineSection = null;
                            openAddPestTile = true;
                        }
                    "
                    is-icon
                    is-success
                    class="ml-5"
                    style="min-width: 150px"
                >
                    <em class="abc-icon abc-icon-arrow-right" style="margin-top: 3.5px; margin-bottom: 3.5px" />&nbsp;
                    {{ i18n("continue") }}
                </abc-button>
            </div>
        </div>

        <div class="flex w-full h-full" v-if="!openCloneMode && !openAddProductMode && !openAddPestMode">
            <!-- <tile :title="i18n('timeline')"> -->
            <div class="flex w-full h-full">
                <div class="flex pr-2" style="width: calc(100% - 160px)">
                    <CropPlanTimelineGraph
                        :curDate="curPointInTimeTrunc"
                        :startDate="curDate"
                        :sections="sections"
                        :areas="areas"
                        :headerHeight="headerHeight"
                        :changing-points="changingPoints"
                        @changeDate="changeDate"
                    />
                </div>
                <div class="flex flex-col px-4 relative" style="width: 160px">
                    <div class="flex w-full border-b flex-shrink-0" :style="headerStyle">
                        <button
                            v-if="!cropPlanDates.campaignStartDate"
                            class="flex w-full items-center justify-center relative cp-timeline-year-selector"
                            id="cp-timeline-year-selector"
                            @click="toggleYearPopover()"
                            @blur="onYearButtonBlur"
                        >
                            <transition
                                name="custom-classes-transition"
                                enter-active-class="animate__animated animate__fadeInDown30 animate__faster"
                                leave-active-class="animate__animated animate__fadeOutDown30 animate__faster"
                                mode="out-in"
                            >
                                <span
                                    class="inline-block text-lg font-bold text-secondary-700"
                                    :key="curDate.getTime()"
                                    >{{ formattedDateWithFormat(curStartDate, "MM/yyyy") }}</span
                                >
                            </transition>
                            <div class="absolute text-secondary-300 text-sm" style="top: 13px; right: 8px">
                                <em
                                    class="cp-timeline-year-selector-icon fa fa-chevron-down"
                                    :class="{ 'cp-timeline-year-selector-icon-opened': yearPopoverOpened }"
                                />
                            </div>
                        </button>
                        <div v-else class="flex w-full items-center justify-center">
                            <span class="text-lg font-bold text-secondary-700">{{
                                formattedDateWithFormat(curStartDate, "MM/yyyy")
                            }}</span>
                        </div>
                    </div>
                    <div
                        v-if="curPlot"
                        class="cp-timeline-toolbarjustify-center h-full relative overflow-x-hidden pr-3"
                        :class="{ 'pt-4 gap-1': !isReadOnly, 'pt-3': isReadOnly }"
                        :style="!timelineExpanded ? 'visibility: hidden' : ''"
                    >
                        <div>
                            <div
                                v-if="showAddDeclaration || showCompleteWithTara"
                                class="flex w-full justify-center mb-2"
                            >
                                <div
                                    v-if="
                                        !isReadOnly &&
                                        !curTimelineSections.length &&
                                        curPlot.editability !== 'NOT_EDITABLE' &&
                                        showAddDeclaration
                                    "
                                    :title="i18n('add')"
                                    v-b-tooltip.hover.window.ds600
                                    class="w-full"
                                >
                                    <abc-button
                                        @click="
                                            checkAndExecAddDecl(() => {
                                                curTimelineSection = null;
                                                curTimelineSections = [];
                                                curDeclaration = null;
                                                openEditTile = true;
                                                newDeclEditOpened = true;
                                            })
                                        "
                                        is-success
                                        :is-disabled="
                                            disabledButtons || curDisabledFunctions.includes('ADD_DECLARATIONS')
                                        "
                                        class="w-full"
                                        is-icon
                                    >
                                        <em
                                            class="abc-icon abc-icon-plus"
                                            style="margin-top: 3.5px; margin-bottom: 3.5px"
                                        />
                                    </abc-button>
                                </div>
                                <div
                                    v-if="!isReadOnly && showCompleteWithTara && curPlot.editability !== 'NOT_EDITABLE'"
                                    :title="i18n('complete-with-tara')"
                                    v-b-tooltip.hover.window.ds600
                                    class="w-full"
                                >
                                    <abc-button
                                        @click="openPlotCompleteTaraModal = true"
                                        is-success
                                        :is-disabled="disabledButtons"
                                        class="w-full"
                                        is-icon
                                        is-outlined
                                    >
                                        <em class="fal fa-puzzle" style="margin-top: 3.5px; margin-bottom: 3.5px" />
                                    </abc-button>
                                </div>
                            </div>
                        </div>
                        <div
                            v-if="
                                !isReadOnly &&
                                (!curTimelineSection || (curTimelineSection && curTimelineSections.length)) &&
                                curPlot.decls.length > 0 &&
                                curPlot.editability !== 'NOT_EDITABLE'
                            "
                            class="flex w-full justify-center mb-2"
                        >
                            <div
                                v-if="!isReadOnly"
                                class="w-full"
                                :title="i18n('remove-multiple-decls')"
                                v-b-tooltip.hover.window.ds600
                            >
                                <abc-button
                                    v-if="
                                        ((curConfiguration.DISABLE_DELETE_DECLARATIONS_IF_EXTERNAL === 'TRUE' &&
                                            !this.plotsExternalDecls.length) ||
                                            curConfiguration.DISABLE_DELETE_DECLARATIONS_IF_EXTERNAL !== 'TRUE') &&
                                        !curTimelineSection
                                    "
                                    is-secondary
                                    is-outlined
                                    class="w-full"
                                    is-icon
                                    @click="checkAndExecEditCurDecl(() => (showConfirmMultipleDelete = true))"
                                >
                                    <em
                                        class="abc-icon abc-icon-trash-bin"
                                        style="margin-top: 3.5px; margin-bottom: 3.5px"
                                    />
                                </abc-button>
                                <!-- MULTIPLE RESET OR DELETE-->
                                <abc-button
                                    v-else
                                    is-secondary
                                    is-outlined
                                    class="w-full"
                                    is-icon
                                    :is-disabled="!resetOrDeleteAvailable"
                                    @click="
                                        () => {
                                            flMultipleResetOrDelete = true;
                                            checkAndExecEditCurDecl(() => {
                                                showConfirmResetOrDelete = true;
                                            });
                                        }
                                    "
                                >
                                    <em
                                        class="abc-icon abc-icon-trash-bin"
                                        style="margin-top: 3.5px; margin-bottom: 3.5px"
                                    />
                                </abc-button>
                            </div>
                        </div>
                        <div
                            v-if="
                                !isReadOnly &&
                                !curTimelineSection &&
                                enableMergeVariety &&
                                curPlot.decls.length > 1 &&
                                curPlot.editability !== 'NOT_EDITABLE'
                            "
                            class="flex w-full justify-center mb-2"
                        >
                            <div v-if="!isReadOnly" class="w-full">
                                <abc-button
                                    @click="
                                        checkAndExecEditCurDecl(() => {
                                            showVarietyMergeWarningModal = true;
                                        })
                                    "
                                    is-success
                                    :is-disabled="
                                        disabledButtons || curDisabledFunctions.includes('MERGE_DECLARATIONS')
                                    "
                                    class="w-full"
                                    is-icon
                                    is-outlined
                                >
                                    {{ i18n("merge-variety") }}
                                </abc-button>
                            </div>
                        </div>
                        <div
                            v-if="
                                (isReadOnly || curPlot.editability === 'NOT_EDITABLE') &&
                                curTimelineSection &&
                                !curTimelineSections.length
                            "
                            class="flex w-full justify-center mb-2"
                        >
                            <div :title="i18n('view-declaration')" v-b-tooltip.hover.window.ds600 class="w-full">
                                <abc-button
                                    @click="openEditTile = true"
                                    is-info
                                    :is-disabled="disabledButtons"
                                    class="w-full"
                                    is-icon
                                >
                                    <em class="fa-regular fa-eye" />
                                </abc-button>
                            </div>
                        </div>
                        <div class="flex flex-grow flex-col relative">
                            <transition
                                name="custom-classes-transition"
                                enter-active-class="animate__animated animate__fadeIn animate__faster"
                                mode="out-in"
                            >
                                <div class="flex flex-col w-full" >
                                    <div class="flex flex-row w-full">
                                        <div
                                            v-if="
                                                !isReadOnly &&
                                                curTimelineSection &&
                                                curPlot.editability !== 'NOT_EDITABLE'
                                            "
                                            :title="i18n('edit')"
                                            v-b-tooltip.hover.window.ds600
                                            class="flex flex-grow mb-2"
                                            style="margin-right: 1.5px"
                                        >
                                            <abc-button
                                                @click="checkAndExecEditCurDecl(() => (openEditTile = true))"
                                                is-info
                                                :is-disabled="
                                                    disabledButtons ||
                                                    curDisabledFunctions.includes('EDIT_DECLARATIONS')
                                                "
                                                class="flex flex-grow override-btn-min-width"
                                                is-icon
                                            >
                                                <em
                                                    class="abc-icon abc-icon-pen"
                                                    style="margin-top: 3.5px; margin-bottom: 3.5px"
                                                />
                                            </abc-button>
                                        </div>
                                        <div
                                            v-if="
                                                !isReadOnly &&
                                                curTimelineSection &&
                                                !curTimelineSections.length &&
                                                curPlot.editability !== 'NOT_EDITABLE'
                                            "
                                            :title="i18n('remove')"
                                            v-b-tooltip.hover.window.ds600
                                            class="flex flex-grow mb-2"
                                            style="margin-left: 1.5px"
                                        >
                                            <abc-button
                                                v-if="curTimelineSection && disposableExternalDecl"
                                                @click="checkAndExecEditCurDecl(() => (showConfirmDelete = true))"
                                                is-secondary
                                                is-outlined
                                                :is-disabled="
                                                    disabledButtons ||
                                                    curDisabledFunctions.includes('DELETE_DECLARATIONS')
                                                "
                                                class="flex flex-grow override-btn-min-width"
                                                is-icon
                                            >
                                                <em
                                                    class="abc-icon abc-icon-trash-bin"
                                                    style="margin-top: 3.5px; margin-bottom: 3.5px"
                                                />
                                            </abc-button>
                                            <abc-button
                                                v-else-if="curTimelineSection"
                                                is-secondary
                                                is-outlined
                                                class="w-full"
                                                is-icon
                                                :is-disabled="
                                                    curConfiguration.ALLOW_DECLS_PERC_TO_ZERO === 'FALSE' ||
                                                    curDeclaration.areaPerc == 0
                                                "
                                                @click="
                                                    checkAndExecEditCurDecl(() => {
                                                        showConfirmResetOrDelete = true;
                                                    })
                                                "
                                            >
                                                <em
                                                    class="abc-icon abc-icon-trash-bin"
                                                    style="margin-top: 3.5px; margin-bottom: 3.5px"
                                                />
                                            </abc-button>
                                        </div>
                                    </div>
                                    <div
                                        v-if="
                                            !isReadOnly && curPlot.editability !== 'NOT_EDITABLE' && curTimelineSection
                                        "
                                        class="flex w-full justify-center"
                                        :class="{ 'mb-2': !isReadOnly }"
                                    >
                                        <abc-button
                                            @click="invertSelection"
                                            is-success
                                            :is-disabled="disabledButtons"
                                            class="w-full"
                                            is-icon
                                            is-outlined
                                        >
                                            {{ i18n("invert-selection") }}
                                        </abc-button>
                                    </div>
                                    <div
                                        v-if="!isReadOnly && enableReproportionVariety"
                                        class="flex w-full justify-center"
                                        :class="{ 'mb-2': !isReadOnly }"
                                    >
                                        <div v-if="!isReadOnly" class="w-full">
                                            <abc-button
                                                @click="
                                                    checkAndExecEditCurDecl(() => {
                                                        showVarietyReproportionWarningModal = true;
                                                    }, enableDeclarationsReproportionWhenNotEditable)
                                                "
                                                is-success
                                                :is-disabled="
                                                    disabledButtons ||
                                                    curDisabledFunctions.includes('REPROPORTION_DECLARATIONS')
                                                "
                                                class="w-full"
                                                is-icon
                                                is-outlined
                                            >
                                                {{ i18n("reproportion-variety") }}
                                            </abc-button>
                                        </div>
                                    </div>
                                    <div v-if="curPlot.editability !== 'NOT_EDITABLE'" class="flex flex-row w-full">
                                        <div
                                            v-if="!isReadOnly"
                                            :title="i18n('copy-uv')"
                                            v-b-tooltip.hover.window.ds600
                                            class="flex flex-grow mb-2"
                                            :style="
                                                'width: 62.5px;' +
                                                (!declarationHasAnomalies ? 'margin-left:auto;margin-right:auto' : '')
                                            "
                                        >
                                            <abc-button
                                                v-if="curTimelineSection"
                                                @click="openCloneMode = true"
                                                is-success
                                                :is-disabled="disabledButtons"
                                                class="flex flex-grow"
                                                is-icon
                                                is-outlined
                                            >
                                                <em
                                                    class="fa-regular fa-copy"
                                                    style="margin-top: 3.5px; margin-bottom: 3.5px"
                                                />
                                            </abc-button>
                                        </div>
                                        <div
                                            v-if="declarationHasAnomalies"
                                            :title="i18n('anomalies')"
                                            v-b-tooltip.hover.window.ds600
                                            class="flex flex-grow"
                                            style="margin-left: 1.5px; width: 62.5px"
                                            :class="{ 'mb-2': !isReadOnly }"
                                        >
                                            <abc-button
                                                v-if="curTimelineSection && !this.curTimelineSections.length"
                                                @click="() => (openAnomaliesModal = true)"
                                                is-warning
                                                :is-disabled="disabledButtons"
                                                class="flex flex-grow"
                                                is-icon
                                                is-outlined
                                            >
                                                <em
                                                    class="fa-regular fa-message-exclamation"
                                                    style="margin-top: 3.5px; margin-bottom: 3.5px"
                                                />
                                            </abc-button>
                                        </div>
                                    </div>

                                    <!-- DECL PESTICIDES AND PEST LIST BUTTON -->
                                    <div
                                        v-if="
                                            enablePesticides || (enablePest && curPlot.editability !== 'NOT_EDITABLE')
                                        "
                                        class="flex flex-row w-full"
                                    >
                                        <div class="flex flex-grow cp-timeline-year-selector mb-2">
                                            <button
                                                type="button"
                                                v-if="
                                                    curTimelineSection &&
                                                    !this.curTimelineSections.length &&
                                                    curDeclaration
                                                "
                                                id="cp-timeline-curdecl-selector"
                                                @click="toggleCurDeclActionsPopover()"
                                                @blur="onCurDeclActionsButtonBlur"
                                                is-success
                                                :is-disabled="disabledButtons"
                                                class="flex flex-grow justify-center py-1 cur-decl-actions-toggle-compact-button"
                                                is-icon
                                                is-outlined
                                            >
                                                <em
                                                    class="abc-icon abc-icon-3-point"
                                                    style="transform: rotate(90deg)"
                                                ></em>
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </transition>

                            <!-- <transition name="custom-classes-transition" enter-active-class="animate__animated animate__fadeIn animate__faster" mode="out-in">
                            <abc-tool-button v-if="curTimelineSection" @click="openEditTile = true;" is-info :title="i18n('edit')" :is-disabled="disabledButtons" class="rounded rounded-b-none" style="margin-left: 0;">
                                <em class="abc-icon abc-icon-pen" />
                            </abc-tool-button>
                        </transition>
                        <transition name="custom-classes-transition" enter-active-class="animate__animated animate__fadeIn animate__faster" mode="out-in">
                            <abc-tool-button v-if="curTimelineSection" @click="showConfirmDelete = true;" is-secondary :title="i18n('remove')" :is-disabled="disabledButtons" class=" rounded rounded-t-none" style="margin-left: 0; margin-top: -1px; border-top-right-radius: 0;">
                                <em class="abc-icon abc-icon-trash-bin" />
                            </abc-tool-button>
                        </transition> -->
                            <div class="flex flex-col left-0 w-full rounded text-xs text-label-primary pb-1 mt-2 mb-2">
                                <div class="m-auto">
                                    <div class="flex items-center">
                                        <div class="bg-info-300 rounded-full w-2 h-2" />
                                        <div class="pl-1">{{ i18n("plot-legend") }}</div>
                                    </div>
                                    <div class="flex items-center">
                                        <div class="bg-primary-300 rounded-full w-2 h-2" />
                                        <div class="pl-1">{{ i18n("land-uses-legend") }}</div>
                                    </div>
                                    <div class="flex items-center">
                                        <div class="bg-danger-300 rounded-full w-2 h-2" />
                                        <div class="pl-1">{{ i18n("set-date-legend") }}</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div v-else class="relative h-full w-full" :style="!timelineExpanded ? 'visibility: hidden' : ''">
                        <div
                            class="mt-3 flex flex-col justify-around absolute left-0 inset-y-0 rounded text-sm text-label-primary"
                        >
                            <div class="flex items-center">
                                <div
                                    class="bg-success-500 border border-bg-100 border-t-4 border-b-4 rounded-full w-1 h-8"
                                />
                                <div class="pl-2">{{ i18n("fl-added-legend") }}</div>
                            </div>
                            <div class="flex items-center">
                                <div
                                    class="bg-brand-yellow-600 border border-bg-100 border-t-4 border-b-4 rounded-full w-1 h-8"
                                />
                                <div class="pl-2">{{ i18n("fl-edited-legend") }}</div>
                            </div>
                            <div class="flex items-center">
                                <div
                                    class="bg-danger-500 border border-bg-100 border-t-4 border-b-4 rounded-full w-1 h-8"
                                />
                                <div class="pl-2">{{ i18n("fl-deleted-legend") }}</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <b-popover
                target="cp-timeline-year-selector"
                placement="bottom"
                triggers="manual"
                boundary="viewport"
                custom-class="abc-date-input-popover"
                :show.sync="yearPopoverOpened"
                offset="0"
            >
                <div @mousedown.stop.prevent>
                    <abc-month-picker
                        v-model="curStartDate"
                        :hide-delete="true"
                        format="MM/yyyy"
                        @input="onYearButtonBlur"
                        :range-min="pointInTimeRangeMin"
                        hideNotAvailableDates
                    />
                </div>
            </b-popover>

            <b-popover
                target="cp-timeline-curdecl-selector"
                placement="top"
                triggers="manual"
                boundary="viewport"
                custom-class="cur-decl-actions-popover"
                :show.sync="curDeclActionsPopoverOpened"
                offset="0"
            >
                <div @mousedown.stop.prevent>
                    <div
                        class="cur-decl-actions-toggle-compact-list p-6 mb-2 rounded-lg flex flex-col"
                        style="min-width: 240px"
                    >
                        <!-- Show decl pesticides button -->
                        <abc-button
                            @click="() => (showDeclPesticidesModal = true)"
                            is-success
                            class="flex w-full align-items-center"
                            is-icon
                            is-outlined
                        >
                            <em class="abc-icon abc-icon-bug"></em>
                            &nbsp;
                            <span>{{ i18n("show-declaration-pesticides") }}</span>
                        </abc-button>
                        <!-- Show decl PEST button -->
                        <!-- <abc-button
                            @click="() => (showDeclPESTModal = true)"
                            is-success
                            class="flex w-full align-items-center mt-2"
                            is-icon
                            is-outlined
                        >
                            <em class="abc-icon abc-icon-bug"></em>
                            &nbsp;
                            <span>{{ i18n('show-declaration-pest') }}</span>
                        </abc-button> -->
                    </div>
                </div>
            </b-popover>

            <!-- CONFIRM REMOVAL MODAL -->
            <abc-modal v-if="showConfirmDelete" @close="showConfirmDelete = false" is-message>
                <template #body>
                    {{ i18n("confirm-removal-of") }}
                    <span class="font-bold">{{ curTimelineSection.title }}</span>
                    <span class="pl-2"
                        >{{ formattedDate(curTimelineSection.start) }} -
                        {{ formattedDate(curTimelineSection.end) }}</span
                    >
                    ?
                </template>
                <template #footer>
                    <abc-button class="mr-2" is-secondary is-outlined @click="showConfirmDelete = false">
                        <em class="abc-icon abc-icon-arrow-left-round" /> {{ i18n("back") }}
                    </abc-button>
                    <abc-button @click="deleteElement()" is-danger>
                        <em class="abc-icon abc-icon-trash-bin" /> {{ i18n("remove") }}
                    </abc-button>
                </template>
            </abc-modal>
            <abc-modal v-if="showConfirmMultipleDelete" @close="showConfirmMultipleDelete = false" is-message>
                <template #body>
                    {{ i18n("confirm-removal-multiple-decls", { date: formattedDate(curPointInTime) }) }}
                </template>
                <template #footer>
                    <abc-button class="mr-2" is-secondary is-outlined @click="showConfirmMultipleDelete = false">
                        <em class="abc-icon abc-icon-arrow-left-round" /> {{ i18n("back") }}
                    </abc-button>
                    <abc-button @click="deleteMultiple()" is-danger>
                        <em class="abc-icon abc-icon-trash-bin" /> {{ i18n("confirm") }}
                    </abc-button>
                </template>
            </abc-modal>
            <!-- Reset declaration area confirm modal -->
            <abc-modal
                v-if="showConfirmResetOrDelete"
                @close="
                    () => {
                        flMultipleResetOrDelete = false;
                        showConfirmResetOrDelete = false;
                    }
                "
                is-message
            >
                <template #body>
                    {{ resetOrDeleteModalMessage }}
                </template>
                <template #footer>
                    <abc-button
                        class="mr-2"
                        is-secondary
                        is-outlined
                        @click="
                            () => {
                                flMultipleResetOrDelete = false;
                                showConfirmResetOrDelete = false;
                            }
                        "
                    >
                        <em class="abc-icon abc-icon-arrow-left-round" /> {{ i18n("back") }}
                    </abc-button>
                    <abc-button
                        @click="
                            () => {
                                flMultipleResetOrDelete ? multipleResetOrDelete() : deleteOrResetDeclArea();
                            }
                        "
                        is-danger
                    >
                        <em class="abc-icon abc-icon-trash-bin" /> {{ i18n("confirm") }}
                    </abc-button>
                </template>
            </abc-modal>
            <crop-plan-can-not-edit-modal-warning v-model="showWarningCannotEdit" :editabilityCheck="'NOT_EDITABLE'" />
            <crop-plan-post-edit-messages-modal
                v-if="editModalConfirmFn"
                :messages="validationMessages"
                @proceedAnyWay="editModalConfirmFn"
            />
            <!-- </tile> -->
        </div>

        <modal-view v-model="openEditTile" @close-current-view="newDeclEditOpened = false">
            <single-cp-declaration-edit
                :declarations="currentPlotDeclarations"
                :firstPlot="firstPlot"
                :oldDeclaration="targetDeclaration"
                :readonly="curCropPlan.readOnly || (curPlot && curPlot.editability === 'NOT_EDITABLE')"
                @updated="onDeclarationUpdate"
                @inserted="onDeclarationUpdate"
                @inserted-multiple="onDeclarationUpdateMultiple"
                @refresh="
                    openEditTile = false;
                    openCloneMode = false;
                    curDeclaration = null;
                "
                @close-current-view="onDeclEditModalClose"
                @cur-declaration-copied="curTimelineSection = null"
            />
        </modal-view>

        <!-- openAddProductTile -->
        <modal-view v-model="openAddProductTile">
            <single-cp-add-pesticide
                :declarations="!curPlots.length ? curSinglePlotDeclarations : uniqueTargetPlotsDeclarations"
                :targetPlots="targetPlots"
                @inserted="onPesticideInserted"
                @refresh="
                    openAddProductTile = false;
                    openAddProductMode = false;
                "
                @close-current-view="
                    openAddProductTile = false;
                    openAddProductMode = false;
                "
            />
        </modal-view>

        <!-- openAddPestTile -->
        <modal-view v-model="openAddPestTile">
            <single-cp-add-pest
                :declarations="!curPlots.length ? curSinglePlotDeclarations : uniqueTargetPlotsDeclarations"
                :targetPlots="targetPlots"
                @inserted="onPesticideInserted"
                @refresh="
                    openAddPestTile = false;
                    openAddPestMode = false;
                "
                @close-current-view="
                    openAddPestTile = false;
                    openAddPestMode = false;
                "
            />
        </modal-view>

        <abc-modal
            v-if="showVarietyMergeWarningModal"
            is-message
            force-modal
            @close="showVarietyMergeWarningModal = false"
        >
            <template #body>
                <div class="p-2">
                    <p class="text-xl text-center">{{ i18n("merge-variety-confirm-message") }}</p>
                </div>
            </template>
            <template #footer>
                <abc-button @click="showVarietyMergeWarningModal = false" is-outlined>{{ i18n("close") }}</abc-button>
                <abc-button
                    @click="
                        showVarietyMergeWarningModal = false;
                        mergeCropVariety();
                    "
                    is-warning
                    >{{ i18n("confirm") }}</abc-button
                >
            </template>
        </abc-modal>
        <abc-modal
            v-if="showVarietyReproportionWarningModal"
            is-message
            force-modal
            @close="showVarietyReproportionWarningModal = false"
        >
            <template #body>
                <div class="p-2">
                    <p class="text-xl text-center">{{ i18n("reproportion-variety-confirm-message") }}</p>
                </div>
            </template>
            <template #footer>
                <abc-button @click="showVarietyReproportionWarningModal = false" is-outlined>{{
                    i18n("close")
                }}</abc-button>
                <abc-button
                    @click="
                        showVarietyReproportionWarningModal = false;
                        reproportionCropVariety();
                    "
                    is-warning
                    >{{ i18n("confirm") }}</abc-button
                >
            </template>
        </abc-modal>

        <app-loading-modal v-if="saving" />
    </div>
</template>

<script lang="ts">
import { Component, Vue, Inject, Watch, Mixins } from "vue-property-decorator";
import { TranslateResult } from "vue-i18n";
import CropPlanTimelineGraph from "../private/cropPlanTimelineGraph.vue";
import { BPopover } from "bootstrap-vue";
import {
    ChangingPoint,
    Declaration,
    DeclarationOut,
    PesticideEntry,
    PlotPeriodsData,
    TimelineArea,
    TimelineSection,
    toTimelineSection,
    toTimelineSectionUI,
    toDeclarationOut,
} from "../../models/Declaration";
import { FromStore, ToastOptions } from "@abaco/web-common/src/app";
import SingleCropPlanModule, { MODULE_ID } from "../..";
import DateUtils from "../../mixins/DateUtils";
import AreaUtils from "../../mixins/AreaUtils";
import { Business } from "../../models/Business";
import { Anomaly, EditPlotMode, Parcel, Plot, PlotDeclaration, TargetPlotDeclaration } from "../../models/Plot";
import { Version } from "../../models/Version";
import { Council } from "../../models/Council";
import { FunctionCode } from "../../models/CropPlan";
import cloneDeep from "lodash/cloneDeep";
import { VBTooltip } from "bootstrap-vue";
import CanEditCheckAndExecute from "../../mixins/CanEditCheckAndExecute";
import AppLoadingModal from "../private/appLoadingModal.vue";
import CropPlanCanNotEditModalWarning from "../private/cropPlanCanNotEditModalWarning.vue";
import { ValidationMessage } from "../../models/Utils";
import CropPlanPostEditMessagesModal from "../private/cropPlanPostEditMessagesModal.vue";
import PlotCompleteTaraModal from "../private/plotCompleteTaraModal.vue";
import CopyOrMoveDeclaration from "../private/CopyOrMoveDeclaration.vue";
import { convertToDate, notEmpty } from "../../api/Utils";
import { Debounce } from "vue-debounce-decorator";
import { isEqual } from "lodash";
import { VINEYARD_FORM } from "../../../../shared/constants";

@Component({
    directives: {
        "b-tooltip": VBTooltip,
    },
    components: {
        BPopover,
        CropPlanTimelineGraph,
        CropPlanCanNotEditModalWarning,
        CropPlanPostEditMessagesModal,
        PlotCompleteTaraModal,
        AppLoadingModal,
        CopyOrMoveDeclaration,
    },
})
export default class SingleCpTimeline extends Mixins(DateUtils, AreaUtils, CanEditCheckAndExecute) {
    @Inject() i18n!: (key: string, values?: unknown) => TranslateResult;
    @Inject() toast!: (message: string, options?: ToastOptions) => TranslateResult;
    @Inject(MODULE_ID) singleCropPlanModule!: SingleCropPlanModule;

    @FromStore(MODULE_ID) business!: Business;
    @FromStore(MODULE_ID) curVersion!: Version | null;
    @FromStore(MODULE_ID) curTimelineSection!: TimelineSection | null;
    @FromStore(MODULE_ID) curTimelineSections!: TimelineSection[];
    @FromStore(MODULE_ID) curCouncil!: Council | null;
    @FromStore(MODULE_ID) curDeclaration!: Declaration | null;
    @FromStore(MODULE_ID) plots!: Plot[];
    @FromStore(MODULE_ID) editPlotMode!: EditPlotMode;
    @FromStore(MODULE_ID) currentPlotDeclarations!: Declaration[];
    @FromStore(MODULE_ID) toolbuttonsEnabled!: boolean;
    @FromStore(MODULE_ID) multiplePlotSelection!: boolean;
    @FromStore(MODULE_ID) openAddProductMode!: boolean;
    @FromStore(MODULE_ID) openAddPestMode!: boolean;
    @FromStore(MODULE_ID) curPlotPesticideUpdated!: boolean;
    @FromStore(MODULE_ID) timelineExpanded!: boolean;
    @FromStore(MODULE_ID) openEditTile!: boolean;
    @FromStore(MODULE_ID) openPlotCompleteTaraModal!: boolean;
    @FromStore(MODULE_ID) plotsForceReload!: number;
    @FromStore(MODULE_ID) newDeclEditOpened!: boolean;
    @FromStore(MODULE_ID) hasCoveredByInserted!: boolean;
    @FromStore(MODULE_ID) curDisabledFunctions!: FunctionCode[];

    private disabledButtons = false;
    private yearPopoverOpened = false;
    private sections: TimelineSection[] = [];
    private areas: TimelineArea[] = [];
    private changingPoints: ChangingPoint[] = [];
    private loading = false;
    private saving = false;
    private showConfirmDelete = false;
    private showConfirmMultipleDelete = false;
    private showConfirmResetOrDelete = false;
    private flMultipleResetOrDelete = false;
    private headerHeight = 44;
    private validationMessages: ValidationMessage[] = [];
    private openCloneMode = false;
    private firstPlot: Plot | null = null;
    private targetPlot: Plot | null = null;
    private targetDeclaration: Declaration | null = null;
    private collectiveAreaPercent: number | null = null;
    private plotsAreas: { plotCode: string; areaHa: number | null; areaPercentTemp: number | null }[] = [];
    private plotPeriodData: PlotPeriodsData | null = null;
    private periodsAreas: { periodIndex: number; areaSqm: number | null; doNotUpdate: boolean }[] = [];
    private percentageDecimalNumber = 6;
    private hectaresDecimalNumber = 4;
    private copyDetailsPanel = false;
    private maxAreaPerc = 100;
    private maxAreaSqm = 100;
    private targetPercentage = 100;
    private targetArea = 0;
    private notCompatibleUse = true;
    private noClonePlotCodes: string[] = [];
    private clonePlotCodesChecked: string[] = [];
    private openAnomaliesModal = false;

    private laodedRange: number | null = null;
    private curDate: Date = new Date();
    private loadingCompatibleUse = true;

    //ADD PRODUCT and PEST
    private notCommonDecls = false;
    private targetPlots: Plot[] = [];
    private targetPlotsDeclarations: TargetPlotDeclaration[] = [];
    private uniqueTargetPlotsDeclarations: TargetPlotDeclaration[] = [];
    private curSinglePlotDeclarations: TargetPlotDeclaration[] = [];
    private sharedCropsLength = 0;
    private showSharedCropsModal = false;
    private openAddProductTile = false;
    private openAddPestTile = false;
    private showDeclPesticidesModal = false;
    private showDeclPESTModal = false;
    private curDeclActionsPopoverOpened = false;
    private curPlotsSelection: Plot[] = [];
    private showVarietyMergeWarningModal = false;
    private showVarietyReproportionWarningModal = false;
    private editModalConfirmFn: Function | null = null;
    private councilExternalCodes: { code: string; count: number }[] = [];

    private get getNoClonPlotCodes() {
        return this.noClonePlotCodes;
    }

    private get getTargetPlots() {
        return this.targetPlots;
    }

    private get getLoadingCompatibleUse() {
        return this.loadingCompatibleUse;
    }

    private get enablePesticides(): boolean {
        return this.curConfiguration?.ENABLE_PESTICIDES && this.curConfiguration.ENABLE_PESTICIDES === "TRUE"
            ? true
            : false;
    }

    private get enablePest(): boolean {
        return this.curConfiguration?.ENABLE_PESTS && this.curConfiguration.ENABLE_PESTS === "TRUE" ? true : false;
    }

    private get enableMergeVariety(): boolean {
        return this.curConfiguration?.ENABLE_DECLARATIONS_MERGE &&
            this.curConfiguration.ENABLE_DECLARATIONS_MERGE === "TRUE"
            ? true
            : false;
    }
    private get enableDeclarationsReproportionWhenNotEditable() {
        return (
            this.curConfiguration?.ENABLE_DECLARATIONS_REPROPORTION_WHEN_NOT_EDITABLE &&
            this.curConfiguration.ENABLE_DECLARATIONS_REPROPORTION_WHEN_NOT_EDITABLE === "TRUE"
        );
    }

    private get enableReproportionVariety(): boolean {
        return this.curConfiguration?.ENABLE_DECLARATIONS_REPROPORTION &&
            this.curConfiguration.ENABLE_DECLARATIONS_REPROPORTION === "TRUE"
            ? true
            : false;
    }

    private get showCompleteWithTara() {
        return !!this.curConfiguration?.TARE_LAND_USE_CODE && this.curConfiguration?.TARE_LAND_USE_CODE != "NULL";
    }

    private get getSharedCropsModalTitle(): string {
        return this.targetPlots && this.targetPlots.length > 1
            ? this.i18n("shared-crops").toString()
            : this.i18n("selected-crops").toString();
    }

    private get invalidParcelsForPesticides(): Parcel[] {
        const plots = this.curPlot ? [this.curPlot, ...this.curPlots] : [...this.curPlots],
            invalidParcels: Parcel[] = [],
            addedCodes: string[] = [];
        plots.forEach((plot) => {
            plot?.parcelIntersections.forEach((i: Parcel) => {
                if (!i.canDeclarePesticides && !addedCodes.includes(i.code)) {
                    addedCodes.push(i.code);
                    invalidParcels.push(i);
                }
            });
        });
        return invalidParcels;
    }

    private get plotsExternalDecls() {
        const plots = [this.curPlot, ...this.curPlots];
        const decls: PlotDeclaration[] = [];
        plots.forEach((p) => {
            p?.decls.forEach((d) => {
                if (d.permanentCropForms) {
                    if (d.permanentCropForms.some((c) => c.permanentCropFormData?.externalCode)) decls.push(d);
                }
            });
        });
        return decls;
    }

    private get plotsNotExternalDecls() {
        if (!this.curPlot) return [];
        const plots = [this.curPlot, ...this.curPlots];
        const decls: PlotDeclaration[] = [];
        plots.forEach((p) => {
            p.decls.forEach((d) => {
                if (d.permanentCropForms && d.permanentCropForms.length)
                    d.permanentCropForms.forEach((pc) => {
                        if (!pc.permanentCropFormData?.externalCode) decls.push(d);
                    });
                else decls.push(d);
            });
        });
        return decls;
    }

    private get resetOrDeleteAvailable() {
        if (
            (this.curConfiguration?.ALLOW_DECLS_PERC_TO_ZERO === "TRUE" &&
                (this.plotsExternalDecls.find((d) => d.areaPerc > 0) ||
                    this.plotsExternalDecls.find((d) => {
                        const targetExternalCode = this.getTargetExternalCode(d as Declaration);
                        return targetExternalCode && targetExternalCode?.count > 1;
                    }))) ||
            this.plotsNotExternalDecls.length
        )
            return true;
        return false;
    }

    private get disposableExternalDecl() {
        if (this.curConfiguration?.DISABLE_DELETE_DECLARATIONS_IF_EXTERNAL !== "TRUE") return true;
        // External declaration can be directly deleted when exists another declaration with same external code in current coucil
        if (!this.curDeclaration) return false;
        const targetExternalCode = this.getTargetExternalCode(this.curDeclaration);
        return !targetExternalCode || (targetExternalCode && targetExternalCode?.count > 1) ? true : false;
    }

    private get resetOrDeleteModalMessage() {
        if (!this.curPointInTime) return "";
        let message = "confirm-reset-decls-area";
        if (this.flMultipleResetOrDelete) {
            if (this.curConfiguration?.DISABLE_DELETE_DECLARATIONS_IF_EXTERNAL !== "TRUE")
                message = "confirm-delete-selected-decls";
            else
                message =
                    this.curConfiguration?.ALLOW_DECLS_PERC_TO_ZERO === "TRUE" &&
                    this.plotsExternalDecls.some((d) => {
                        const targetExternalCode = this.getTargetExternalCode(d as Declaration);
                        if (!targetExternalCode) return false;
                        return targetExternalCode?.count > 1;
                    })
                        ? "confirm-multiple-reset-decls-area"
                        : "confirm-delete-only-not-external";
        }
        return this.i18n(message, { date: this.formattedDate(this.curPointInTime) });
    }

    @Watch("curPlots")
    checkPlots() {
        this.checkSelectedPlots();
    }

    @Watch("curPlot")
    checkPlot() {
        this.checkSelectedPlots();
    }

    @Watch("plots")
    updateCouncilExternalCodes() {
        this.councilExternalCodes = [];
        for (const plot of this.plots) {
            for (const d of plot.decls) {
                const declaration = d as Declaration;
                const externalCode = declaration.permanentCropForms.find(
                    (c) => c.permanentCropFormData?.externalCode != null
                )?.permanentCropFormData?.externalCode;
                if (externalCode) {
                    const targetExternalCode = this.councilExternalCodes.find((ec) => ec.code === externalCode);
                    if (!targetExternalCode) {
                        this.councilExternalCodes.push({
                            code: externalCode,
                            count: 1,
                        });
                    } else {
                        targetExternalCode.count++;
                    }
                }
            }
        }
    }

    private checkSelectedPlots() {
        // if(this.curPlot === null && !this.curPlots.length) {
        //     this.openAddProductMode = false;
        // }
        const plots: { plotId: string; contains: PlotDeclaration[] }[] = [];
        this.resetTargets();

        if (this.curPlots.length > 0) {
            for (let i = 0; i < this.curPlots.length; i++) {
                const curPlotEl = this.curPlots[i];
                const contains = curPlotEl.decls.filter((elDecl) =>
                    this.curPlot?.decls.some((curPlotDecl) => elDecl.landuse.code === curPlotDecl.landuse.code)
                );
                if (contains.length !== 0) {
                    plots.push({
                        plotId: curPlotEl.plotCode,
                        contains: contains,
                    });
                }
            }

            if (plots.length < this.curPlots.length) {
                this.notCommonDecls = true;
            } else if (plots.length === this.curPlots.length) {
                this.notCommonDecls = false;
                this.curPlots.forEach((plot) => {
                    this.targetPlots.push(plot);
                });

                this.targetPlots.forEach((plot) => {
                    plot.decls.forEach((decl) => {
                        const targetDecl: TargetPlotDeclaration = decl as TargetPlotDeclaration;
                        targetDecl.areaSqm = plot.areaSqm;
                        targetDecl.formattedArea = this.getCropAreaFromPercent(
                            targetDecl.areaPerc,
                            this.formattedArea(targetDecl.areaSqm)
                        );
                        const plotsContainSharedDeclLanduse = plots.filter((elDecl) =>
                            elDecl.contains.some((containsEl) => containsEl.landuse.code === decl.landuse.code)
                        );
                        if (!this.curPointInTime) return;
                        const isInPointInTime =
                            this.curPointInTime.getTime() > decl.fromDate.getTime() &&
                            this.curPointInTime.getTime() < decl.toDate.getTime();
                        if (plotsContainSharedDeclLanduse.length && isInPointInTime)
                            this.targetPlotsDeclarations.push(targetDecl);
                    });
                });

                this.getSharedCropsLength();
            }
        } else {
            if (this.curPlot !== null) {
                if (this.curPlot.decls.length > 0) {
                    this.curPlot.decls.forEach((decl) => {
                        const targetDecl: TargetPlotDeclaration = decl as TargetPlotDeclaration;
                        if (!this.curPlot) return;
                        targetDecl.areaSqm = this.curPlot.areaSqm;
                        targetDecl.formattedArea = this.getCropAreaFromPercent(
                            targetDecl.areaPerc,
                            this.formattedArea(targetDecl.areaSqm)
                        );
                        this.targetPlotsDeclarations.push(targetDecl);
                    });
                    this.getSharedCropsLength();
                    const opt = this.targetPlotsDeclarations.filter(
                        (value, index, self) => index === self.findIndex((t) => t.landuse.code === value.landuse.code)
                    );
                    this.curSinglePlotDeclarations = opt;
                }
            }
        }
    }

    private getTotalDeclsAreas() {
        let sum = 0;
        this.targetPlotsDeclarations.forEach((decl) => {
            sum += Number(decl.formattedArea);
        });
        return (
            sum.toLocaleString(this.getLocale(), { minimumFractionDigits: 4, maximumFractionDigits: 4 }) +
            " " +
            this.areaLabel()
        );
    }

    private getModalTotalDeclsAreas(declCode: string) {
        let sum = 0;
        this.targetPlotsDeclarations.forEach((decl) => {
            if (decl.landuse.code === declCode) sum += Number(decl.formattedArea);
        });
        return (
            sum.toLocaleString(this.getLocale(), { minimumFractionDigits: 4, maximumFractionDigits: 4 }) +
            " " +
            this.areaLabel()
        );
    }

    private resetTargets() {
        this.targetPlots = [];
        this.targetPlotsDeclarations = [];
        this.uniqueTargetPlotsDeclarations = [];
        this.curSinglePlotDeclarations = [];
        this.sharedCropsLength = 0;
        this.notCommonDecls = false;
        if (this.curPlot !== null) {
            this.targetPlots.push(this.curPlot);
        }
    }

    private getSharedCropsLength() {
        const declCodes: string[] = [];
        this.targetPlotsDeclarations.forEach((decl) => {
            declCodes.push(decl.landuse.code);
        });
        if (this.curPlots.length > 0) {
            const sharedCrops = [...new Set(declCodes.filter((e, i, a) => a.indexOf(e) !== i))];
            this.sharedCropsLength = sharedCrops.length;

            const copiedValues = [...this.targetPlotsDeclarations];
            const duplicateObjects = this.targetPlotsDeclarations.filter(
                (v) => copiedValues.filter((cp) => cp.landuse.code === v.landuse.code).length > 1
            );
            const opt = duplicateObjects.filter(
                (value, index, self) => index === self.findIndex((t) => t.landuse.code === value.landuse.code)
            );
            this.uniqueTargetPlotsDeclarations = opt;
        } else {
            const sharedCrops = [...new Set(declCodes.filter((e, i, a) => a.indexOf(e) === i))];
            this.sharedCropsLength = sharedCrops.length;
        }
    }

    private getTargetPlotsTotalArea() {
        if (!this.curPlot) return;
        let sum = 0;
        const tempPlots = cloneDeep(this.curPlots);
        tempPlots.push(this.curPlot);
        tempPlots.forEach((a) => (sum += a.areaSqm));
        return this.formattedArea(sum) + " " + this.areaLabel();
    }

    private getCropAreaFromPercent(declPercent: number, plotArea: string) {
        return ((Number(plotArea) * declPercent) / 100).toLocaleString(this.getLocale(), {
            minimumFractionDigits: 2,
            maximumFractionDigits: 4,
        });
    }

    private getPesticideQt(product: PesticideEntry) {
        return product.amount + " " + product.uomLabel;
    }

    private onCurDeclActionsButtonBlur() {
        this.curDeclActionsPopoverOpened = false;
    }
    private toggleCurDeclActionsPopover() {
        if (this.curDeclActionsPopoverOpened) {
            this.curDeclActionsPopoverOpened = false;
        } else {
            this.curDeclActionsPopoverOpened = true;
        }
    }

    @Watch("openCloneMode")
    onCloneModeStateChange() {
        if (this.openCloneMode) {
            this.firstPlot = this.curPlot;
            this.targetDeclaration = this.curDeclaration;
            this.targetPlots = [];
            this.curPlot = null;
            this.curPlots = [];
            this.clonePlotCodesChecked = [];
            this.noClonePlotCodes = [];
            this.toolbuttonsEnabled = false;
            this.loadingCompatibleUse = false;
            this.multiplePlotSelection =
                this.curConfiguration?.ENABLE_DECLARATIONS_COPY_ON_MULTIPLE_PLOTS == "TRUE" ? true : false;
        } else {
            this.curPlot = this.firstPlot;
            this.firstPlot = null;
            this.targetPlots = [];
            this.curDeclaration = null;
            this.toolbuttonsEnabled = true;
            this.multiplePlotSelection = true;
        }
    }

    @Watch("curPlot")
    @Watch("curPlots")
    async onPlotSelectionChange() {
        const temp = this.curPlot ? [this.curPlot, ...this.curPlots] : [...this.curPlots];
        if (isEqual(this.curPlotsSelection, temp)) return;
        //
        this.curPlotsSelection = this.curPlot ? [this.curPlot, ...this.curPlots] : [...this.curPlots];
        //
        if (this.openCloneMode && this.targetDeclaration && this.curCropPlan) {
            this.targetPlots = cloneDeep(this.curPlotsSelection);
            const targetCodes = this.targetPlots.map((p) => p.plotCode),
                plotsToCheck = this.targetPlots.filter((p) => !this.clonePlotCodesChecked.includes(p.plotCode));
            // remove unselected codes
            this.clonePlotCodesChecked = this.clonePlotCodesChecked.filter((c) => targetCodes.includes(c));
            this.noClonePlotCodes = this.noClonePlotCodes.filter((c) => targetCodes.includes(c));
            //
            if (!plotsToCheck.length) return;
            //
            this.loadingCompatibleUse = true;
            const requests = plotsToCheck.map(
                (p) =>
                    new Promise((resolve) => {
                        this.singleCropPlanModule.plotApi
                            .getLandUse(
                                this.business.businessId,
                                this.curCropPlan!.cropPlanId,
                                this.targetDeclaration!.fromDate,
                                this.targetDeclaration!.landuse.code,
                                p.parcelIntersections.map((e) => e.landCoverCode)
                            )
                            .then((compatibleLandUse) => {
                                if (compatibleLandUse && this.targetDeclaration) {
                                    this.curDeclaration = { ...this.targetDeclaration, declCode: -1 };
                                } else {
                                    this.noClonePlotCodes.push(p.plotCode);
                                }
                            })
                            .catch(() => {
                                this.noClonePlotCodes.push(p.plotCode);
                            })
                            .finally(() => {
                                this.clonePlotCodesChecked.push(p.plotCode);
                                resolve(p);
                            });
                    })
            );
            Promise.allSettled(requests).then(() => {
                this.loadingCompatibleUse = false;
            });
        }
    }

    async mounted() {
        if (this.cropPlanDates.campaignStartDate) {
            const newStartDate = convertToDate(this.cropPlanDates.campaignStartDate);
            if (newStartDate) this.curDate = newStartDate;
        } else if (this.curPointInTime) {
            this.curDate = new Date(this.curPointInTime.getFullYear(), 0, 1);
        } else {
            const savedDate = window.localStorage.getItem("abcCpTimelineStart");
            this.curDate = savedDate ? new Date(savedDate) : new Date(new Date().getFullYear(), 0, 1);
        }
    }

    private get curPointInTimeTrunc() {
        if (!this.curPointInTime) return new Date();
        return new Date(
            this.curPointInTime.getFullYear(),
            this.curPointInTime.getMonth(),
            this.curPointInTime.getDate()
        );
    }

    @Watch("business")
    @Watch("curCouncil")
    @Watch("curCropPlan.cropPlanId")
    @Watch("curVersion")
    private resetAll() {
        this.changingPoints = [];
        this.resetTimeline();
    }

    @Watch("editPlotMode")
    onEditPlotModeChange() {
        if (this.editPlotMode === EditPlotMode.NOT_SELECTED) {
            this.resetTimeline();
        }
    }

    @Watch("curPlot")
    private async resetTimeline() {
        if (!this.openCloneMode) this.curTimelineSection = null;
        this.openEditTile = false;
        this.sections = [];
        this.currentPlotDeclarations = [];
        this.areas = [];
        if (!this.hasCoveredByInserted) await this.loadTimeline(true);
    }

    @Watch("hasCoveredByInserted")
    onhasCoveredByInserted() {
        if (this.hasCoveredByInserted) {
            this.currentPlotDeclarations = [];
            this.curTimelineSection = null;
            this.curDeclaration = null;
            this.openEditTile = true;
            this.newDeclEditOpened = true;
            this.hasCoveredByInserted = false;
        }
    }

    @Watch("curPointInTime")
    private onChangePointInTime() {
        if (!this.curPointInTime) return;
        if (!this.cropPlanDates?.campaignStartDate) this.curDate = new Date(this.curPointInTime.getFullYear(), 0, 1);
    }

    @Watch("cropPlanDates.campaignStartDate", { deep: true })
    private onChangeCampaignStartDate() {
        const tempCampaing = this.cropPlanDates?.campaignStartDate;
        if (tempCampaing) {
            const convertedDate = convertToDate(tempCampaing);
            if (!convertedDate) return;

            this.curDate = new Date(convertedDate.getFullYear(), convertedDate.getMonth(), 1);
        }
    }

    @Watch("curDate")
    private onChangeDate() {
        if (!this.laodedRange || (this.laodedRange && this.laodedRange !== this.curDate.getTime())) {
            window.localStorage.setItem("abcCpTimelineStart", this.curDate.toString());
            this.curTimelineSection = null;
            this.openEditTile = false;
            this.sections = [];
            this.currentPlotDeclarations = [];
            this.areas = [];
            this.changingPoints = [];
            this.loadTimeline(true);
        }
    }

    @Watch("curTimelineSection")
    private updateCurDeclaration() {
        const declSection = this.currentPlotDeclarations.find((d) => d.declCode == this.curTimelineSection?.declCode);
        if (declSection) {
            this.curDeclaration = declSection;
        } else if (!this.openEditTile) {
            this.curDeclaration = null;
        }
    }

    @Watch("curPlotPesticideUpdated")
    private updateTimeline() {
        if (this.curPlot && this.curPlotPesticideUpdated) {
            this.resetTimeline();
        }
        this.curPlotPesticideUpdated = false;
    }

    private async loadTimeline(showLoading?: boolean) {
        if (!this.curCropPlan || !this.curCouncil) return;
        this.loading = true;
        if (!this.curPlot) {
            this.changingPoints = await this.singleCropPlanModule.declarationApi.getGeneralTimeline(
                this.business.businessId,
                this.curCropPlan.cropPlanId,
                this.curCouncil.domainZoneId,
                this.curStartDate,
                this.curEndDate
            );
        } else {
            const res = await this.singleCropPlanModule.declarationApi.getTimeline(
                this.business.businessId,
                this.curCropPlan.cropPlanId,
                this.curCouncil.domainZoneId,
                this.curPlot.plotCode,
                this.formattedDateWithFormat(this.curStartDate, "yyyyMMdd"),
                this.formattedDateWithFormat(this.curEndDate, "yyyyMMdd"),
                this.curVersion ? this.curVersion.version : null
            );
            this.currentPlotDeclarations = res.decls;
            res.areas.sort(function (a: TimelineArea, b: TimelineArea) {
                return a.fromDate.getTime() - b.fromDate.getTime();
            });
            this.areas = res.areas;
            //transform data on timeline section
            this.sections = this.currentPlotDeclarations
                .map((e: Declaration, index: number) => {
                    return this.curPlot ? toTimelineSection(e, this.curPlot.areaSqm, index) : null;
                })
                .filter(notEmpty);
            // autoselect if only one declaration in pointInTime
            if (!this.openCloneMode && this.curPointInTime) {
                const onPoint = this.sections.filter((s) => {
                    if (this.curPointInTime) return s.start <= this.curPointInTime && s.end >= this.curPointInTime;
                });
                if (onPoint.length == 1 && !this.curPlots.length) {
                    this.curTimelineSection = toTimelineSectionUI(onPoint[0]);
                }
            }
        }
        if (showLoading) {
            this.loading = false;
        }
        this.laodedRange = this.curDate.getTime();
    }

    private async deleteElement(ignoreWarning = false) {
        if (!this.curCropPlan || !this.curCouncil || !this.curPlot || !this.curDeclaration || !this.curTimelineSection)
            return;
        this.showConfirmDelete = false;
        this.saving = true;
        const e = this.curTimelineSection;
        const curIdx = this.sections.findIndex((el) => el.id == e.id);
        try {
            const res = await this.singleCropPlanModule.declarationApi.deleteDeclaration(
                this.business.businessId,
                this.curCropPlan.cropPlanId,
                this.curCouncil.domainZoneId,
                this.curPlot.plotCode,
                this.curDeclaration.declCode,
                ignoreWarning
            );
            this.editModalConfirmFn = res.validationMessages.length
                ? () => {
                      this.deleteElement(true);
                  }
                : null;
            this.validationMessages = res.validationMessages;
            if (this.validationMessages.length > 0) {
                this.saving = false;
                return;
            }
            this.sections.splice(curIdx, 1);
            this.currentPlotDeclarations = this.currentPlotDeclarations.filter((d, i) => i !== curIdx);
            if (e)
                this.toast(this.i18n(e.title + " " + this.i18n("removed")) as string, {
                    type: "success",
                    duration: 4000,
                });
            this.onDeclarationUpdate();
            this.curTimelineSection = null;
        } catch (error) {
            this.toast(error as string, { type: "error", duration: 4000 });
        }
        this.saving = false;
        this.forceReset();
    }

    private async deleteOrResetDeclArea(ignoreWarning = false) {
        if (!this.curCropPlan || !this.curCouncil || !this.curPlot || !this.curPointInTime || !this.curDeclaration)
            return;
        this.saving = true;
        this.showConfirmResetOrDelete = false;
        try {
            const declOut: DeclarationOut = toDeclarationOut({
                ...this.curDeclaration,
                areaPerc: 0,
            });
            if (this.disposableExternalDecl) {
                const res = await this.singleCropPlanModule.declarationApi.deleteDeclaration(
                    this.business.businessId,
                    this.curCropPlan!.cropPlanId,
                    this.curCouncil!.domainZoneId,
                    this.curPlot!.plotCode,
                    this.curDeclaration.declCode,
                    false
                );
                if (res.validationMessages.length) console.error(res.validationMessages);
            } else {
                if (this.curConfiguration?.ALLOW_DECLS_PERC_TO_ZERO === "TRUE" && this.curDeclaration.areaPerc) {
                    await this.singleCropPlanModule.declarationApi.editDeclaration(
                        this.business.businessId,
                        this.curCropPlan!.cropPlanId,
                        this.curCouncil!.domainZoneId,
                        this.curPlot!.plotCode,
                        this.curDeclaration.declCode,
                        declOut,
                        this.curDeclaration.fromDatePrecision,
                        false,
                        false,
                        this.curPointInTime
                    );
                }
            }

            if (this.validationMessages.length > 0) {
                this.saving = false;
                return;
            }
            this.toast(this.i18n("multiple-decls-removed").toString(), {
                type: "success",
                duration: 4000,
            });
            this.onDeclarationUpdate();
        } catch (error) {
            const errorCode = (error as any).response?.data?.errorCode;
            const errorMessage: string =
                errorCode == "DISABLE_FUNCTION_EXCEPTION"
                    ? this.i18n("unavailable-feature").toString()
                    : this.i18n("generic-error").toString();
            this.toast(errorMessage, { type: "error", duration: 4000 });
        }
        this.saving = false;
        this.forceReset();
    }

    private async deleteMultiple(ignoreWarning = false) {
        if (!this.curCropPlan || !this.curCouncil || !this.curPlot || !this.curPointInTime) return;
        this.showConfirmMultipleDelete = false;
        this.saving = true;
        try {
            const res = await this.singleCropPlanModule.declarationApi.deleteMultipleDeclarationsByPlots(
                this.business.businessId,
                this.curCropPlan.cropPlanId,
                this.curCouncil.domainZoneId,
                [this.curPlot, ...this.curPlots].map((p) => p.plotCode),
                this.curPointInTime,
                ignoreWarning
            );
            this.editModalConfirmFn = res.validationMessages.length
                ? () => {
                      this.deleteMultiple(true);
                  }
                : null;
            this.validationMessages = res.validationMessages;
            if (this.validationMessages.length > 0) {
                this.saving = false;
                return;
            }
            //
            this.toast(this.i18n("multiple-decls-removed").toString(), {
                type: "success",
                duration: 4000,
            });
            this.onDeclarationUpdate();
        } catch (error) {
            const errorCode = (error as any).response?.data?.errorCode;
            const errorMessage: string =
                errorCode == "DISABLE_FUNCTION_EXCEPTION"
                    ? this.i18n("unavailable-feature").toString()
                    : this.i18n("generic-error").toString();
            this.toast(errorMessage, { type: "error", duration: 4000 });
        }
        this.saving = false;
        this.forceReset();
    }

    private getTargetExternalCode(declaration: Declaration) {
        let targetExternalCode: { code: string; count: number } | undefined;
        if (declaration.permanentCropForms) {
            declaration.permanentCropForms
                .filter((f) => f.formType == VINEYARD_FORM)
                .forEach((pc) => {
                    if (pc.permanentCropFormData?.externalCode)
                        targetExternalCode = this.councilExternalCodes.find(
                            (ec) => ec.code == pc.permanentCropFormData?.externalCode
                        );
                });
        }
        return targetExternalCode;
    }

    private async multipleResetOrDelete() {
        if (!this.curCropPlan || !this.curCouncil || !this.curPlot || !this.curPointInTime) return;
        this.flMultipleResetOrDelete = false;
        this.saving = true;
        this.showConfirmResetOrDelete = false;
        const plots = [this.curPlot, ...this.curPlots];
        try {
            if (this.curTimelineSection && this.curTimelineSections.length) {
                // DELETE OR RESET SELECTED
                const sections = [this.curTimelineSection, ...this.curTimelineSections];

                for (const section of sections) {
                    const declaration = this.curPlot?.decls.find((d) => d.declCode === section.declCode) as Declaration;
                    const targetExternalCode = this.getTargetExternalCode(declaration);

                    if (declaration) {
                        const declOut: DeclarationOut = toDeclarationOut({
                            ...declaration,
                            areaPerc: 0,
                        });
                        if (
                            this.curConfiguration?.DISABLE_DELETE_DECLARATIONS_IF_EXTERNAL !== "TRUE" ||
                            (targetExternalCode && targetExternalCode.count > 1)
                        ) {
                            const res = await this.singleCropPlanModule.declarationApi.deleteDeclaration(
                                this.business.businessId,
                                this.curCropPlan!.cropPlanId,
                                this.curCouncil!.domainZoneId,
                                this.curPlot!.plotCode,
                                declaration.declCode,
                                false
                            );
                            if (res.validationMessages.length) console.error(res.validationMessages);
                        } else {
                            if (this.curConfiguration?.ALLOW_DECLS_PERC_TO_ZERO === "TRUE" && declaration.areaPerc) {
                                await this.singleCropPlanModule.declarationApi.editDeclaration(
                                    this.business.businessId,
                                    this.curCropPlan!.cropPlanId,
                                    this.curCouncil!.domainZoneId,
                                    this.curPlot!.plotCode,
                                    section.declCode,
                                    declOut,
                                    declaration.fromDatePrecision,
                                    false,
                                    false,
                                    this.curPointInTime
                                );
                            }
                        }
                    }
                }
            } else {
                // DELETE OR RESET ALL
                for (const plot of plots) {
                    for (const d of plot.decls) {
                        const declaration = d as Declaration;
                        const targetExternalCode = this.getTargetExternalCode(declaration);

                        if (targetExternalCode && targetExternalCode.count > 1) {
                            const res = await this.singleCropPlanModule.declarationApi.deleteDeclaration(
                                this.business.businessId,
                                this.curCropPlan!.cropPlanId,
                                this.curCouncil!.domainZoneId,
                                plot.plotCode,
                                declaration.declCode,
                                false
                            );
                            if (res.validationMessages.length) console.error(res.validationMessages);
                        } else {
                            if (this.curConfiguration?.ALLOW_DECLS_PERC_TO_ZERO === "TRUE" && declaration.areaPerc) {
                                const declOut: DeclarationOut = toDeclarationOut({
                                    ...declaration,
                                    areaPerc: 0,
                                });
                                await this.singleCropPlanModule.declarationApi.editDeclaration(
                                    this.business.businessId,
                                    this.curCropPlan!.cropPlanId,
                                    this.curCouncil!.domainZoneId,
                                    plot.plotCode,
                                    declaration.declCode,
                                    declOut,
                                    declaration.fromDatePrecision,
                                    false,
                                    false,
                                    this.curPointInTime
                                );
                            }
                        }
                    }
                }
            }
        } catch (error) {
            const errorCode = (error as any).response?.data?.errorCode;
            const errorMessage: string =
                errorCode == "DISABLE_FUNCTION_EXCEPTION"
                    ? this.i18n("unavailable-feature").toString()
                    : this.i18n("generic-error").toString();
            this.toast(errorMessage, { type: "error", duration: 4000 });
        }
        this.toast(this.i18n("multiple-decls-removed").toString(), {
            type: "success",
            duration: 4000,
        });
        this.saving = false;
        this.onDeclarationUpdate();
        this.forceReset();
    }

    private get headerStyle(): Record<string, string> {
        return { height: this.headerHeight + "px" };
    }

    private changeDate(date: Date) {
        this.curDate = date;
    }

    private get percentageLabel(): string {
        return this.maxAreaPerc.toFixed(2) + " %";
    }

    private get curStartDate(): Date {
        const refDate = this.curDate;
        refDate.setHours(0, 0, 0, 0);
        return refDate;
    }

    private set curStartDate(e: Date) {
        e.setHours(0, 0, 0, 0);
        this.curDate = e;
        // if(this.curPointInTime){
        //     const newDate = this.curPointInTime;
        //     newDate.setFullYear(e.getFullYear());
        //     this.curPointInTime = newDate;
        // }
    }

    private get curEndDate(): Date {
        const refYear = this.curDate.getFullYear();
        const refDate = new Date(refYear + 1, this.curDate.getMonth(), this.curDate.getDate() - 1);
        return refDate;
    }

    private onYearButtonBlur() {
        this.yearPopoverOpened = false;
    }
    private toggleYearPopover() {
        if (this.yearPopoverOpened) {
            this.yearPopoverOpened = false;
        } else {
            this.yearPopoverOpened = true;
        }
    }

    private closeTimeline() {
        this.curPlot = null;
    }

    private async onDeclarationUpdate() {
        if (!this.curCropPlan || !this.curCouncil || !this.curPlot || !this.curPointInTime) return;
        this.flCurCorpPlanChangesPending = true;
        //refresh cur
        this.curPlot = await this.singleCropPlanModule.plotApi.getPlot(
            this.business.businessId,
            this.curCropPlan.cropPlanId,
            this.curCouncil.domainZoneId,
            this.curPlot.plotCode,
            this.curPointInTime,
            this.curVersion ? this.curVersion.version : null
        );
        //refresh list
        const copiedPlots = cloneDeep(this.plots);
        // TODO - Ask Luca
        const curIdx = copiedPlots.findIndex((e) => {
            if (this.curPlot) return e.plotCode === this.curPlot.plotCode;
        });
        Vue.set(copiedPlots, curIdx, this.curPlot);
        this.plots = copiedPlots;
        this.forceReset();
    }

    private async onDeclarationUpdateMultiple(plots: Plot[]) {
        this.flCurCorpPlanChangesPending = true;
        //refresh selected plots
        const updatedPlots: Plot[] = [];
        await Promise.all(
            plots.map(async (p: Plot) => {
                if (this.curCropPlan && this.curCouncil && this.curPointInTime) {
                    const res = await this.singleCropPlanModule.plotApi.getPlot(
                        this.business.businessId,
                        this.curCropPlan.cropPlanId,
                        this.curCouncil.domainZoneId,
                        p.plotCode,
                        this.curPointInTime,
                        this.curVersion ? this.curVersion.version : null
                    );
                    updatedPlots.push(res);
                }
            })
        );
        //refresh list and cur
        const copiedPlots = cloneDeep(this.plots);
        updatedPlots.forEach((p) => {
            if (this.curPlot && this.curPlot.plotCode === p.plotCode) {
                this.curPlot = p;
            }
            const curIdx = copiedPlots.findIndex((e) => e.plotCode === p.plotCode);
            Vue.set(copiedPlots, curIdx, p);
        });
        this.plots = copiedPlots;
        this.forceReset();
    }

    private async onPesticideInserted() {
        this.curPlot = null;
        this.curPlots = [];
    }

    private get showAddDeclaration() {
        return this.curConfiguration?.DISABLE_ADD_DECLARATIONS !== "TRUE";
    }

    private get declarationWarningAnomalies() {
        const declarationsWarningAnomalies: Anomaly[] = [];
        if (this.curDeclaration)
            declarationsWarningAnomalies.push(...this.curDeclaration.anomalies.filter((anomaly) => !anomaly.blocking));

        return [...new Map(declarationsWarningAnomalies.map((item) => [item.errorCode, item])).values()].sort((a, b) =>
            a.errorCode > b.errorCode ? 1 : -1
        );
    }

    private get declarationBlockingAnomalies() {
        const declarationsBlockingAnomalies: Anomaly[] = [];
        if (this.curDeclaration)
            declarationsBlockingAnomalies.push(...this.curDeclaration.anomalies.filter((anomaly) => anomaly.blocking));

        return [...new Map(declarationsBlockingAnomalies.map((item) => [item.errorCode, item])).values()].sort((a, b) =>
            a.errorCode > b.errorCode ? 1 : -1
        );
    }

    private get declarationHasAnomalies() {
        return this.declarationWarningAnomalies.length > 0 || this.declarationBlockingAnomalies.length > 0;
    }

    private get isReadOnly() {
        return this.curCropPlan && this.curCropPlan.readOnly;
    }

    private onDeclEditModalClose() {
        this.openEditTile = false;
        this.openCloneMode = false;
    }

    @Debounce(100)
    private forceReset() {
        this.plotsForceReload++;
    }

    private async mergeCropVariety(ignoreWarning = false) {
        if (!this.enableMergeVariety || !this.curCropPlan || !this.curPlot || !this.curCouncil || !this.curPointInTime)
            return;
        //
        this.saving = true;
        try {
            const res = await this.singleCropPlanModule.declarationApi.mergeDeclarations(
                this.business.businessId,
                this.curCropPlan.cropPlanId,
                this.curCouncil.domainZoneId,
                this.curPlot.plotCode,
                this.curPointInTime,
                ignoreWarning
            );
            this.validationMessages = res.validationMessages;
            if (this.validationMessages.length > 0) {
                this.saving = false;
                return;
            }
            this.forceReset();
        } catch (error) {
            this.toast((error as any).message, { type: "error", duration: 4000 });
        }
        this.saving = false;
    }

    private async reproportionCropVariety(ignoreWarning = false) {
        if (!this.curCropPlan || !this.curPlot || !this.curCouncil || !this.curPointInTime) return;
        //
        this.saving = true;
        try {
            const res = await this.singleCropPlanModule.declarationApi.reproportionDeclarations(
                this.business.businessId,
                this.curCropPlan.cropPlanId,
                this.curCouncil.domainZoneId,
                this.curPlot.plotCode,
                this.curPointInTime,
                ignoreWarning
            );
            this.saving = false;
            this.forceReset();
        } catch (error) {
            this.toast((error as any).message, { type: "error", duration: 4000 });
        }
        this.saving = false;
    }

    private expandCollapseTimeline() {
        this.timelineExpanded = !this.timelineExpanded;
    }

    private invertSelection() {
        const sectionsUI = this.sections.map((it) => toTimelineSectionUI(it));

        let selected: TimelineSection[] = [];
        if (this.curTimelineSection) {
            selected = [this.curTimelineSection, ...this.curTimelineSections];
        } else {
            selected = [...this.curTimelineSections];
        }

        // If all the sectionsUI are selected then return
        if (
            isEqual(
                sectionsUI.map((it) => it.id).sort((a, b) => a - b),
                selected.map((it) => it.id).sort((a, b) => a - b)
            )
        ) {
            return;
        }

        const notSelectedSectionUI = sectionsUI.filter(
            (sectionUI) => !selected.some((select) => sectionUI.id === select.id)
        );
        if (notSelectedSectionUI.length === 1) {
            this.curTimelineSection = notSelectedSectionUI[0];
            this.curTimelineSections = [];
        } else {
            this.curTimelineSection = notSelectedSectionUI[0];
            this.curTimelineSections = notSelectedSectionUI.slice(1);
        }
    }
}
</script>

<style lang="scss">
.cp-timeline-year-selector,
.cp-timeline-year-selector-icon {
    @apply transition-all duration-150 ease-in-out;
}
.cp-timeline-year-selector {
    @apply cursor-pointer outline-none border-0;
}
.cp-timeline-year-selector:focus {
    @apply outline-none;
}
.cp-timeline-year-selector:hover {
    @apply bg-bg-500;
}
.cp-timeline-year-selector-icon-opened {
    transform: rotate(180deg);
}

.abc-date-input-popover.popover .arrow {
    visibility: hidden;
}
.abc-date-input-popover.popover {
    border: 0px;
    max-width: 100%;
    margin-top: 0;
    margin-bottom: 0;
}

.cp-timeline-curdecl-selector,
.cp-timeline-curdecl-selector-icon {
    @apply transition-all duration-150 ease-in-out;
}
.cp-timeline-curdecl-selector {
    @apply cursor-pointer outline-none border-0;
}
.cp-timeline-curdecl-selector:focus {
    @apply outline-none;
}
.cp-timeline-curdecl-selector:hover {
    @apply bg-bg-500;
}
.cp-timeline-curdecl-selector-icon-opened {
    transform: rotate(180deg);
}

.cur-decl-actions-popover.popover .arrow {
    visibility: hidden;
}
.cur-decl-actions-popover.popover {
    border: 0px;
    max-width: 100%;
    margin-top: 0;
    margin-bottom: 0;
    z-index: 40;
}

.sc-timeline-close-button,
.sc-timeline-close-button svg {
    @apply transition-all duration-150 ease-in-out;
}

.sc-timeline-close-button {
    @apply rounded-full;
    outline: none !important;
    padding: 4px;
    top: 11px;
    right: 12px;
}
.sc-timeline-close-button svg {
    width: 18px;
    height: 18px;
    @apply text-icon;
}

.sc-timeline-close-button:hover {
    @apply bg-danger-100;
}

.sc-timeline-close-button:hover svg {
    @apply text-danger-500;
}

.cur-decl-actions-toggle-compact-list {
    @apply bg-bg-100 overflow-y-auto overflow-x-hidden;
    max-height: 250px;
}
.cur-decl-actions-toggle-compact-button {
    @apply flex items-center cursor-pointer relative rounded border text-secondary-600 border-secondary-500;
    outline: none !important;
    text-decoration: none;
    user-select: none;
}
.sc-shared-crops-button {
    padding: 0.125rem 0.5rem !important;
}

.override-btn-min-width.abc-button.default-sized {
    min-width: fit-content;
} 
</style>
