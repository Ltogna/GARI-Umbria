<template>
    <abc-modal :title="i18n('copy-campaign')" :force-modal="loading" :items="versions" @close="$emit('close')">
        <template #body>
            <div :style="showConfirmation ? '' : 'width: 800px; height: 500px'">
                <abc-loader v-if="loading" scope="absolute" :size="20" />

                <template v-if="showConfirmation">
                    <span>
                        {{
                            i18n("confirm-copy-of-declarations-1", {
                                startDate: formattedDate(versionsReferenceDate),
                                targetDate: formattedDate(curPointInTime),
                            })
                        }}
                    </span>
                </template>

                <template v-else-if="showLandUsesToExcludeSection">
                    <div>
                        <span class="font-semibold text-label-primary">
                            {{ i18n("select-land-uses-to-exclude") }}
                        </span>
                        <abc-table class="py-3" :items="sourceLauses" disableSelectOnClick>
                            <template #headers>
                                <th id="landuse">{{ i18n("land-use") }}</th>
                                <th id="action" class="w-24"></th>
                            </template>
                            <template #items="{ item }">
                                <td>{{ item.landuse.description }}</td>
                                <td class="w-24">
                                    <abc-checkbox v-model="item.excludedFromAggregation"></abc-checkbox>
                                </td>
                            </template>
                        </abc-table>
                    </div>
                </template>

                <template v-else>
                    <div v-if="enableCopyCampaign">
                        <abc-radio
                            v-model="copyMethod"
                            radio-value="PREVIOUS"
                            :label="i18n('copy-campaign-from-previous-year')"
                        />
                        <abc-radio
                            v-model="copyMethod"
                            radio-value="CURRENT"
                            :label="i18n('copy-campaign-from-current-year')"
                        />
                    </div>
                    <div v-else>
                        <abc-radio v-model="copyMethod" radio-value="CURRENT" :label="i18n('copy-from-current-year')" />
                        <abc-radio
                            v-model="copyMethod"
                            radio-value="PREVIOUS"
                            :label="i18n('copy-from-previous-year')"
                        />
                    </div>

                    <div>
                        <div>
                            <template v-if="enableCopyCampaign">
                                <abc-checkbox
                                    v-if="showCopyFromOtherBusinesses"
                                    v-model="flCopyFromOtherBusinesses"
                                    class="mt-3"
                                    :label="i18n('copy-from-other-businesses')"
                                >
                                </abc-checkbox>
                            </template>
                            <abc-checkbox
                                v-else
                                v-model="forceNotCompatibleLandCover"
                                class="mt-3"
                                :label="i18n('force-not-compatible-land-cover')"
                            >
                            </abc-checkbox>

                            <hr class="my-3" />
                            <template v-if="copyMethod === 'PREVIOUS' && showCopyFromCurrentSituation">
                                <div class="mt-3 flex">
                                    <span class="font-semibold">{{ i18n("copy-from-current-situation") }}</span>
                                    <abc-button
                                        @click="onSelectVersion(null)"
                                        is-secondary
                                        is-outlined
                                        is-icon
                                        class="ml-auto"
                                    >
                                        <em class="abc-icon abc-icon-arrow-right" />
                                    </abc-button>
                                </div>
                            </template>
                        </div>

                        <span class="font-semibold text-label-primary mt-3">
                            {{ i18n("copy-from-version") }}
                        </span>
                        <abc-table class="py-3" :items="versions" disableSelectOnClick>
                            <template #headers>
                                <th id="user" class="w-24">{{ i18n("user") }}</th>
                                <th id="date" class="">{{ i18n("date") }}</th>
                                <th id="date" class="">{{ i18n("date-reference") }}</th>
                                <th id="notes" class="">{{ i18n("notes") }}</th>
                                <th id="action"></th>
                            </template>
                            <template #items="{ item }">
                                <td class="w-24">{{ item.userId }}</td>
                                <td>
                                    {{ formattedDate(item.versionDate) }}
                                    {{ formattedDateWithFormat(item.versionDate, "HH:mm:ss") }}
                                </td>
                                <td>
                                    {{
                                        item.versionReferenceDate
                                            ? getFormattedReferenceDate(item.versionReferenceDate)
                                            : ""
                                    }}
                                </td>
                                <td>{{ item.message }}</td>
                                <td>
                                    <abc-button @click="onSelectVersion(item)" is-secondary is-outlined is-icon>
                                        <em class="abc-icon abc-icon-arrow-right" />
                                    </abc-button>
                                </td>
                            </template>
                        </abc-table>
                    </div>
                </template>
            </div>
        </template>
        <template #footer>
            <div class="flex" v-if="showConfirmation || showLandUsesToExcludeSection">
                <abc-button class="mr-2" is-secondary is-outlined @click="onBack()">
                    <em class="abc-icon abc-icon-arrow-left-round" /> {{ i18n("back") }}
                </abc-button>
                <abc-button @click="submit()" is-danger>
                    <em class="abc-icon abc-icon-level-add" />
                    {{ enableCopyCampaign ? i18n("proceed-copy-campaign") : i18n("copy-declarations") }}
                </abc-button>
            </div>
        </template>
    </abc-modal>
</template>

<script lang="ts">
import { FromStore } from "@abaco/web-common/src/app";
import { ToastOptions } from "@abaco/web-common/src/app/components/ToastOptions";
import { infiniteNextLoad, NextPagedResults } from "@abaco/web-common/src/Paging";
import { TranslateResult } from "vue-i18n";
import { Component, Inject, Mixins, Watch } from "vue-property-decorator";
import SingleCropPlanModule, { MODULE_ID } from "../..";
import { convertToDate, formatDate } from "../../api/Utils";
import DateUtils from "../../mixins/DateUtils";
import { Business } from "../../models/Business";
import { Configuration, CropPlan, CropPlanType } from "../../models/CropPlan";
import { ExcludeFromCopyCampaignLanduse, CopyCampaignPayload } from "../../models/Declaration";
import { Version } from "../../models/Version";

@Component
export default class CopyDeclarationFromVersionModal extends Mixins(DateUtils) {
    @Inject(MODULE_ID) singleCropPlanModule!: SingleCropPlanModule;
    @Inject() i18n!: (key: string, values?: unknown) => TranslateResult;
    @Inject() toast!: (message: string, options?: ToastOptions) => TranslateResult;

    @FromStore(MODULE_ID) business!: Business;
    @FromStore(MODULE_ID) curCropPlan!: CropPlan | null;
    @FromStore(MODULE_ID) curPointInTime!: Date;
    @FromStore(MODULE_ID) curConfiguration!: Configuration;
    @FromStore(MODULE_ID) availableCropPlanTypes!: CropPlanType[];
    @FromStore(MODULE_ID) forceSync!: number;

    @FromStore(MODULE_ID) plotsForceReload!: number;

    private loading = false;
    private showConfirmation = false;
    private forceNotCompatibleLandCover = false;
    private flCopyFromOtherBusinesses = false;
    private versions: Version[] = [];
    private selectedVersion: Version | null = null;
    private showLandUsesToExcludeSection = false;
    private preserveSourceDeclDates = false;

    private sourceLauses: ExcludeFromCopyCampaignLanduse[] = [];

    private copyMethod: "CURRENT" | "PREVIOUS" | "CAMPAIGN" = "PREVIOUS";

    /**
     * Returns a reference date that is one year before the current point in time.
     * @returns {Date} The reference date.
     */
    private get versionsReferenceDate() {
        const referenceDate = new Date(this.curPointInTime);

        if (this.copyMethod === "PREVIOUS") {
            referenceDate.setFullYear(referenceDate.getFullYear() - 1);
        }

        return referenceDate;
    }

    private get enableCopyCampaign() {
        return this.curConfiguration?.ENABLE_COPY_CAMPAIGN === "TRUE";
    }

    private get showCopyFromCurrentSituation() {
        const defaltToDate = new Date(9999, 11, 31);
        const defaltFromDate = new Date(1970, 11, 31);
        const lastYearPointInTime = new Date(this.curPointInTime);
        lastYearPointInTime.setFullYear(lastYearPointInTime.getFullYear() - 1);
        return this.availableCropPlanTypes.some(
            (cpt) =>
                cpt.cropPlanTypeCode === this.curCropPlan?.cropPlanTypeCode &&
                lastYearPointInTime >= (cpt.dayFrom || defaltFromDate) &&
                lastYearPointInTime <= (cpt.dayTo || defaltToDate)
        );
    }

    private get showCopyFromOtherBusinesses() {
        if(!this.curConfiguration.CAMPAIGN_REF_DATE) return false;
        const campaignRefMonthDay = this.curConfiguration.CAMPAIGN_REF_DATE;
        const curPointInTimeMonth = this.curPointInTime.getMonth() >= 9 ? this.curPointInTime.getMonth() + 1 : `0${this.curPointInTime.getMonth() + 1}`
        const curPointinTImeMonthDay = `${curPointInTimeMonth}${this.curPointInTime.getDate()}`;
        return campaignRefMonthDay === curPointinTImeMonthDay;
    }

    mounted() {
        this.laodVersion();
    }

    @Watch("copyMethod")
    async refetchVersions() {
        if (this.copyMethod !== "CAMPAIGN") this.preserveSourceDeclDates = this.copyMethod === "CURRENT";
        this.copyMethod === "CAMPAIGN" ? await this.laodCopyCampaignLandUses() : await this.laodVersion();
    }

    private async laodVersion() {
        this.versions = [];
        if (!this.curCropPlan?.cropPlanId) {
            console.error("Missing data for api request");
            return;
        }
        this.loading = true;
        try {
            let nextKey: string | undefined | null = undefined;
            do {
                const res: NextPagedResults<Version> = await this.singleCropPlanModule.versionApi.getVersions(
                    this.business.businessId,
                    this.curCropPlan!.cropPlanId,
                    nextKey,
                    this.versionsReferenceDate,
                    this.enableCopyCampaign
                );
                nextKey = res.nextKey ?? null;
                if (res && res.records.length) this.versions.push(...res.records);
            } while (nextKey);
        } catch (error) {
            this.toast(this.i18n("generic-error").toString(), { type: "error", duration: 4000 });
            console.error(error);
            this.versions = [];
        } finally {
            this.loading = false;
        }
    }

    private async laodCopyCampaignLandUses() {
        this.versions = [];
        if (!this.curCropPlan) {
            console.error("Missing data for api request");
            return;
        }
        this.loading = true;
        try {
            const sourceCropPlanId = this.selectedVersion?.cropPlanId ?? this.curCropPlan.cropPlanId;
            const sourcePointInTime =
                this.selectedVersion?.versionReferenceDate ?? formatDate(this.versionsReferenceDate);

            const res = await this.singleCropPlanModule.declarationApi.getSourceLandUsesForCopyCampaign(
                this.business.businessId,
                this.curCropPlan.cropPlanId,
                sourceCropPlanId,
                this.curPointInTime,
                sourcePointInTime,
                this.selectedVersion?.version ?? undefined
            );
            this.sourceLauses = res;
        } catch (error) {
            this.toast(this.i18n("generic-error").toString(), { type: "error", duration: 4000 });
            console.error(error);
            this.sourceLauses = [];
        } finally {
            this.loading = false;
        }
    }

    private getFormattedReferenceDate(date: string) {
        const convertedDate = convertToDate(date);
        if (convertedDate) {
            return this.formattedDate(convertedDate);
        }
        return "";
    }

    private onSelectVersion(version: Version | null) {
        this.selectedVersion = version;
        if (this.enableCopyCampaign) {
            this.showLandUsesToExcludeSection = true;
            this.copyMethod = "CAMPAIGN";
        } else this.showConfirmation = true;
    }

    private forcePlotsReset() {
        this.plotsForceReload++;
    }

    private onBack() {
        this.copyMethod = "PREVIOUS";
        this.showConfirmation = false;
        this.showLandUsesToExcludeSection = false;
        this.selectedVersion = null;
        this.sourceLauses = [];
    }

    private async submit() {
        this.loading = true;
        if (this.curCropPlan) {
            try {
                switch (this.copyMethod) {
                    case "CURRENT":
                        await this.singleCropPlanModule.cropPlanApi.copyDeclarationsFromCurrentVersion(
                            this.business.businessId,
                            this.curCropPlan.cropPlanId,
                            this.selectedVersion?.version ?? null,
                            this.curPointInTime,
                            this.forceNotCompatibleLandCover,
                            false
                        );
                        break;
                    case "PREVIOUS":
                        await this.singleCropPlanModule.cropPlanApi.copyDeclarationsFromPreviousVersion(
                            this.business.businessId,
                            this.curCropPlan.cropPlanId,
                            this.selectedVersion?.version ?? null,
                            this.curPointInTime,
                            this.forceNotCompatibleLandCover,
                            false
                        );
                        break;
                    case "CAMPAIGN":
                        {
                            const sourceCropPlanId = this.selectedVersion?.cropPlanId ?? this.curCropPlan.cropPlanId;
                            const sourceVersion = this.selectedVersion?.version;
                            const sourcePointInTime =
                                this.selectedVersion?.versionReferenceDate ??
                                formatDate(new Date(this.curPointInTime.getTime() - 1));
                            const destPointInTime =
                                formatDate(this.curPointInTime) ??
                                formatDate(new Date(this.curPointInTime.getTime() - 1));

                            const landuseCodesExcludedFromAggregation = this.sourceLauses
                                .filter(({ excludedFromAggregation }) => excludedFromAggregation)
                                .map(({ landuse }) => landuse.code);

                            const payload: CopyCampaignPayload = {
                                sourceCropPlanId,
                                sourceVersion,
                                sourcePointInTime,
                                destPointInTime,
                                landuseCodesExcludedFromAggregation,
                                preserveSourceDeclDates: this.preserveSourceDeclDates,
                                flCopyFromOtherBusinesses: this.flCopyFromOtherBusinesses,
                            };
                            await this.singleCropPlanModule.declarationApi.copyCampaign(
                                this.business.businessId,
                                this.curCropPlan.cropPlanId,
                                payload
                            );
                            this.forceSync++;
                        }
                        break;
                }

                // this.forcePlotsReset();
            } catch (error) {
                this.toast(this.i18n("generic-error").toString(), { type: "error", duration: 4000 });
                console.error(error);
            }
        } else {
            console.warn("DEV - Warn: curCropPlan or selectedVersion is null");
        }

        this.loading = false;
        this.showConfirmation = false;
        this.selectedVersion = null;
        this.$emit("close");
    }
}
</script>
