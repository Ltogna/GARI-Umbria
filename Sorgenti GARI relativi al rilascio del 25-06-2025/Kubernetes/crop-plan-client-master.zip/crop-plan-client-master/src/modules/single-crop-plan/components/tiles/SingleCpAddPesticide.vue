<template>
    <tile :title="i18n('insert-pesticide')" noContainerStyled>
        <div class="flex w-full h-full overflow-auto">
            <div class="flex px-4 py-6 sm:w-full md:w-full mx-auto lg:w-11/12 xxl:w-9/12">
                <abc-form ref="form" class="flex flex-col w-full sc-decl-edit-form" @submit="submit">
                    <div class="sc-add-pesticide-section">
                        <div class="sc-decl-edit-info w-full h-full md:w-4/12 justify-center md:justify-start">
                            <div class="sc-decl-edit-title">
                                <span class="text-4xl text-label-secondary pr-2">{{ i18n("1") }}</span>
                                {{ i18n("add-pesticide-section-tile") }}
                            </div>
                            <div class="sc-decl-edit-sub-title">
                                {{ i18n("add-pesticide-section-description") }}
                            </div>
                        </div>
                        <div
                            class="sc-add-pesticide-plots-list px-4 h-full overflow-y-auto overflow-x-hidden justify-items-start md:justify-start w-full md:w-8/12"
                        >
                            <!-- PLOTS LIST -->
                            <div v-if="plotsReady" class="flex flex-col justify-items-start w-full mb-4">
                                <!-- PLOTS LIST -->
                                <abc-selectable-card
                                    v-for="(plot, index) in plots"
                                    :key="index"
                                    @click="onClick(index, plot)"
                                    :isActive="selectedPlot[index].isActive"
                                    class="flex flex-col w-full ml-0"
                                    style="margin-left: 0"
                                >
                                    <div class="single-crop-plan-crop-row-inner">
                                        <div class="flex items-center mr-3 relative">
                                            <single-cp-map-preview :plot="plot" />
                                        </div>
                                        <div class="flex flex-col flex-grow" style="min-width: 0">
                                            <div class="flex w-full justify-between items-baseline">
                                                <div class="flex flex-wrap items-center font-semibold">
                                                    {{ plot.description }}
                                                </div>
                                                <div class="flex items-baseline" style="margin-top: -2px">
                                                    <span class="font-semibold text-lg pr-1">{{
                                                        formattedArea(plot.areaSqm)
                                                    }}</span>
                                                    <span class="text-base lowercase">{{ areaLabel() }}</span>
                                                </div>
                                            </div>
                                            <div class="flex w-full justify-between">
                                                <div
                                                    class="text-label-primary truncate mb-2"
                                                    :title="
                                                        plot.parcelIntersections &&
                                                        plot.parcelIntersections.length > 0 &&
                                                        parcelsPiped(plot) &&
                                                        parcelsPiped(plot).length > 20
                                                            ? parcelsPiped(plot)
                                                            : ''
                                                    "
                                                >
                                                    {{ parcelsPiped(plot) }}
                                                </div>
                                            </div>
                                            <div class="flex w-full justify-between">
                                                <div class="truncate flex flex-col">
                                                    <span
                                                        v-if="plot.decls && plot.decls.length > 0"
                                                        class="text-secondary-700"
                                                        v-b-tooltip.hover.window.ds400
                                                        :title="
                                                            plot.decls &&
                                                            plot.decls.length > 0 &&
                                                            declarationsPiped(plot) &&
                                                            declarationsPiped(plot).length > 20
                                                                ? declarationsPiped(plot)
                                                                : ''
                                                        "
                                                    >
                                                        <p
                                                            v-if="
                                                                plot.decls.length > 1 &&
                                                                declarationsPiped(plot).length > 20
                                                            "
                                                        >
                                                            {{ i18n("multiple-land-uses") }}
                                                        </p>
                                                        <p v-else>{{ declarationsPiped(plot) }}</p>
                                                    </span>
                                                    <span v-else class="text-label-secondary">
                                                        {{ i18n("no-land-uses") }}
                                                    </span>
                                                </div>
                                                <div class="flex items-baseline">
                                                    <span style="padding-right: 1px">
                                                        {{ getFieldOccupied(plot) }}
                                                    </span>
                                                    <span class="lowercase">%</span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </abc-selectable-card>
                            </div>
                        </div>
                    </div>

                    <div class="sc-decl-edit-section">
                        <div class="sc-decl-edit-info w-full md:w-4/12 justify-center md:justify-start">
                            <div class="sc-decl-edit-title">
                                <span class="text-4xl text-label-secondary pr-2">{{ i18n("2") }}</span>
                                {{ i18n("add-pesticide-details-title") }}
                            </div>
                            <div class="sc-decl-edit-sub-title">
                                {{ i18n("add-pesticide-details-description") }}
                            </div>
                        </div>
                        <div class="sc-decl-edit-fields w-full md:w-8/12 justify-center md:justify-start">
                            <div class="flex w-full mb-4">
                                <!-- DECLS LIST -->
                                <abc-dropdown2 
                                    class="w-1/2"
                                    :label="i18n('crop')"
                                    v-model="curCrop"
                                    :items="declarations" 
                                    :rules="mandatoryRule"
                                >
                                    <p v-if="curCrop">
                                        {{ curCrop.landuse.description }}
                                        {{ curCropTotalArea ? " - " + curCropTotalArea : "" }}
                                    </p>
                                    <template #items="{ item }">
                                        <div class="cursor-pointer">
                                            {{ item.landuse.description }}
                                            {{ curCropTotalArea ? " - " + curCropTotalArea : "" }}
                                        </div>
                                    </template>
                                </abc-dropdown2>
                            </div>
                            <div class="flex w-full">
                                <!-- PESTICIDES LIST -->
                                <div class="flex w-5/12">
                                    <abc-autocomplete
                                        :is-disabled="!this.curCrop || this.curCrop === null"
                                        class="w-full mr-2"
                                        :label="i18n('pesticide-title')"
                                        :value="curPesticide"
                                        itemId="productCode"
                                        :items="pesticidesPage.records"
                                        :stringify="(item) => (item ? item.productName : null)"
                                        :search.sync="searchPesticide"
                                        maxHeight="300px"
                                        buttons
                                        @input="updateCurPesticide"
                                        :rules="mandatoryRule"
                                    >
                                        <template #items="{ item }">
                                            <div>{{ item.productName }}</div>
                                        </template>
                                        <template>
                                            <div v-if="pesticidesLoading" class="flex justify-center items-center h-12">
                                                <abc-loader :size="32" />
                                            </div>
                                            <div
                                                v-if="!pesticidesLoading && pesticidesPage.records.length === 0"
                                                class="flex justify-center items-center h-12"
                                            >
                                                <abc-no-data-found />
                                            </div>
                                            <div
                                                v-if="
                                                    !pesticidesLoading &&
                                                    pesticidesPage.records.length > 0 &&
                                                    pesticidesPage.haveMore
                                                "
                                                class="flex justify-center items-center h-12"
                                            >
                                                <abc-refine-filter />
                                            </div>
                                        </template>
                                        <template #buttons>
                                            <abc-tool-button
                                                is-secondary
                                                @click="
                                                    searchPesticide = '';
                                                    curPesticide = null;
                                                    curPesticideUom = null;
                                                "
                                                :title="i18n('clear-field')"
                                            >
                                                <em class="abc-icon abc-icon-x text-xs"></em>
                                            </abc-tool-button>
                                        </template>
                                    </abc-autocomplete>
                                </div>

                                <abc-input
                                    class="w-2/12 pr-2"
                                    text-right
                                    is-numeric
                                    v-model="curPesticideQt"
                                    autocomplete="off"
                                    :label="i18n('cc-quantity')"
                                    ref="pesticideQt"
                                    :rules="mandatoryRule"
                                >
                                </abc-input>
                                
                                <abc-dropdown2 
                                    class="w-2/12 pl-2"
                                    :label="i18n('measure')"
                                    v-model="curPesticideUom"
                                    :items="uomsList"
                                    :rules="mandatoryRule"
                                    :is-disabled="!uomsReady"
                                    ref="pesticideUoms"
                                >
                                    <abc-loader v-if="uomsLoading"  :size="16" />
                                    <p v-else-if="curPesticideUom">
                                        {{ curPesticideUom.uomLabel }}
                                    </p>
                                    <template #items="{ item }">
                                        <div class="cursor-pointer">
                                            {{ item.uomLabel }}
                                        </div>
                                    </template>
                                </abc-dropdown2>

                                <abc-switch
                                    class="w-3/12 px-2 flex justify-start"
                                    style="margin-top: 25px"
                                    :label="i18n('product-quantity-per-area')"
                                    v-model="perAreaUoms"
                                />
                            </div>
                        </div>
                    </div>

                    <div class="sc-decl-edit-section">
                        <div class="sc-decl-edit-info w-full md:w-4/12 justify-center md:justify-start"></div>
                        <div class="sc-decl-edit-fields justify-center md:justify-start w-full md:w-8/12">
                            <abc-form-buttons
                                class="pb-8"
                                @save="submit"
                                @cancel="close"
                                :has-continue="false"
                                :disable-confirm-button="disableFormButtons"
                            />
                        </div>
                    </div>
                </abc-form>
            </div>
        </div>

        <!-- <crop-plan-post-edit-messages-modal :messages="validationMessages" @proceedAnyWay="submit(true)" /> -->
    </tile>
</template>

<script lang="ts">
import { Prop, Component, Inject, Watch, Mixins, Ref, ProvideReactive } from "vue-property-decorator";
import { TranslateResult } from "vue-i18n";
import SingleCropPlanModule, { MODULE_ID } from "../..";
import { FromStore, ToastOptions } from "@abaco/web-common/src/app";
import { Business } from "../../models/Business";
import { Plot, TargetPlotDeclaration } from "../../models/Plot";
import DateUtils from "../../mixins/DateUtils";
import { Validable } from "@abaco/web-components/src/components/form/Validable";
import { Configuration, CropPlan } from "../../models/CropPlan";
import { Council } from "../../models/Council";
import { Pesticide, PesticideOut } from "../../models/Declaration";
import AreaUtils from "../../mixins/AreaUtils";
import { VBTooltip } from "bootstrap-vue";
import { EmptyMaxPagedResults, MaxPagedResults } from "@abaco/web-common/src/Paging";
import { Debounce } from "vue-debounce-decorator";
import SingleCpMapPreview from "../mapComponent/SingleCPMapPreview.vue";
import { Version } from "../../models/Version";
import { ValidationMessage } from "../../models/Utils";
import CropPlanPostEditMessagesModal from "../private/cropPlanPostEditMessagesModal.vue";
import PermanentCropForms from "../private/permanentCropForms.vue";
import { UnitOfMeasurement, UnitsOfMeasure, UomType } from "../../models/UnitOfMeasure";
import { formatDate } from "../../api/Utils";

@Component({
    directives: {
        "b-tooltip": VBTooltip,
    },
    components: {
        SingleCpMapPreview,
        CropPlanPostEditMessagesModal,
        PermanentCropForms,
    },
})
export default class SingleCpAddPesticide extends Mixins(DateUtils, AreaUtils) {
    @Inject() i18n!: (key: string, values?: unknown) => TranslateResult;
    @Inject() toast!: (message: string, options?: ToastOptions) => TranslateResult;
    @Inject(MODULE_ID) singleCropPlanModule!: SingleCropPlanModule;

    @FromStore(MODULE_ID) business!: Business;
    @FromStore(MODULE_ID) curPlot!: Plot | null;
    @FromStore(MODULE_ID) curPlots!: Plot[];
    @FromStore(MODULE_ID) curPointInTime!: Date;
    @FromStore(MODULE_ID) curCropPlan!: CropPlan | null;
    @FromStore(MODULE_ID) curCouncil!: Council | null;
    @FromStore(MODULE_ID) editPlotPolygonDrawn!: boolean;
    @FromStore(MODULE_ID) curVersion!: Version | null;
    @FromStore(MODULE_ID) hideFieldName!: boolean;
    @FromStore(MODULE_ID) curConfiguration!: Configuration | null;

    @Prop() declarations!: TargetPlotDeclaration[];
    @Prop() targetPlots!: Plot[];

    @Ref("form") form!: Validable;

    @ProvideReactive("pesticideOutDetail")
    private detail: PesticideOut = {
        productCode: undefined,
        uomCode: undefined,
        amount: null,
        date: undefined,
    };

    private disableFormButtons = false;
    private loading = true;
    private percentageDivider = 1000000;
    private percentageDecimalNumber = 6;
    private hectaresDecimalNumber = 4;
    private validationMessages: ValidationMessage[] = [];
    private mandatoryRule = [(v: unknown) => !!v || this.i18n("valid.mandatory-field")];
    private mandatoryRuleAtomic = (v: unknown) => !!v || this.i18n("valid.mandatory-field");
    private mandatoryNumberRuleAtomic = (v: unknown) => !!v || v == 0 || this.i18n("valid.mandatory-field");

    private selectedPlots: Plot[] = [];
    private plots: Plot[] = [];
    private selectedPlot: { plotCode: string; isActive: boolean }[] = [];
    private plotsReady = false;
    private curCrop: TargetPlotDeclaration | null = null;
    private curCropTotalArea: string | null = null;
    private selectedPlotsDecls: TargetPlotDeclaration[] = [];

    private pesticidesPage: MaxPagedResults<unknown> = new EmptyMaxPagedResults();
    private searchPesticide: string | null = null;
    private pesticidesLoading = false;
    private curPesticide: Pesticide | null = null;

    private lastCurCrop: TargetPlotDeclaration | null = null;
    private uomsTypes!: UnitsOfMeasure;
    private uomsList: UnitOfMeasurement[] = [];
    private curPesticideUom: UnitOfMeasurement | null = null;
    private curPesticideQt: number | null = null;
    private perAreaUoms = false;
    private uomsReady = false;
    private uomsLoading = false;

    @Watch("plots")
    checkPlots() {
        this.selectedPlot = this.plots.map((plot: Plot) => {
            return { plotCode: plot.plotCode, isActive: false };
        });
    }

    @Watch("curCrop")
    async checkSelectedPlots() {
        this.getTotalDeclsAreas();
        this.searchPesticide = "";
        this.curPesticide = null;
        this.curPesticideUom = null;
        await this.triggerPesticideSearch();
    }

    @Watch("perAreaUoms")
    checkPerAreaSwitch() {
        this.curPesticideUom = null;
        if (!this.uomsTypes) return;
        if (this.perAreaUoms) this.uomsList = this.uomsTypes.perAreaUoms;
        else this.uomsList = this.uomsTypes.basicUoms;
    }

    @Watch("searchPesticide")
    @Debounce(300)
    private async triggerPesticideSearch() {
        if (this.curCrop && this.curCrop !== null && this.curCropPlan) {
            this.pesticidesLoading = true;
            this.pesticidesPage = new EmptyMaxPagedResults();
            let page = await this.singleCropPlanModule.cropPlanApi.getPesticidesList(
                this.business.businessId,
                this.curCropPlan.cropPlanId,
                this.searchPesticide ? this.searchPesticide.trim().toUpperCase() : "",
                this.curCrop ? this.curCrop.landuse.code : null
            );
            if (page.count === 1 && this.searchPesticide === page.records[0].productName) {
                const res = page.records[0];
                page = await this.singleCropPlanModule.cropPlanApi.getPesticidesList(
                    this.business.businessId,
                    this.curCropPlan.cropPlanId,
                    null,
                    this.curCrop ? this.curCrop.landuse.code : null
                );
                page.records = page.records.filter((l) => l.productCode !== res.productCode);
                page.records.unshift(res);
                if (this.curPesticide) {
                    this.curPesticide = { ...this.curPesticide };
                }
            }
            this.pesticidesPage = page;
            this.pesticidesLoading = false;
        }
    }

    private updateCurPesticide(value: Pesticide) {
        this.curPesticide = value;
    }

    async mounted() {
        this.targetPlots.forEach((p) => {
            this.plots.push(p);
        });
        this.plotsReady = true;
        this.getTotalDeclsAreas();
    }

    @Watch("curPesticide")
    private async getUoms(newVal: Pesticide | null, oldVal: Pesticide | null) {
        if (!this.curCropPlan) return;
        this.uomsReady = !!newVal?.uomType;
        if (newVal?.uomType != oldVal?.uomType && newVal?.uomType) {
            this.uomsLoading = true;
            const pesticideUoms = await this.singleCropPlanModule.cropPlanApi.getPesticideUoms(
                this.business.businessId,
                this.curCropPlan.cropPlanId,
                newVal.uomType
            );
            if (pesticideUoms) {
                this.uomsTypes = pesticideUoms;
                this.uomsList = this.perAreaUoms ? this.uomsTypes.perAreaUoms : this.uomsTypes.basicUoms;
                this.uomsReady = true;
            }
            this.uomsLoading = false;
        }
    }

    private async submit() {
        const isValid = this.form.validate();
        if (isValid) {
            this.disableFormButtons = true;
            await this.insertPesticide();
        }
    }

    private async insertPesticide() {
        try {
            if (!this.curPesticide || !this.curPesticide.productCode || !this.curPesticideUom) return;
            const detailOut: PesticideOut = this.detail;
            detailOut.productCode = this.curPesticide.productCode;
            detailOut.uomCode = this.curPesticideUom.uomCode;
            detailOut.amount = this.curPesticideQt;
            detailOut.date = this.curPointInTime ? formatDate(this.curPointInTime) : undefined;
            if (this.curCrop && this.selectedPlots.length > 0) {
                const insertRes = await Promise.all(
                    this.selectedPlots.map(async (plot) => {
                        plot.decls.map(async (decl) => {
                            if (
                                this.curCrop &&
                                decl.landuse.code === this.curCrop.landuse.code &&
                                this.curCropPlan &&
                                this.curCouncil
                            ) {
                                const res = await this.singleCropPlanModule.cropPlanApi.insertPesticide(
                                    this.business.businessId,
                                    this.curCropPlan.cropPlanId,
                                    this.curCouncil.domainZoneId,
                                    plot.plotCode,
                                    decl.declCode.toString(),
                                    detailOut
                                );
                                if (!res) {
                                    return;
                                }
                            }
                        });
                    })
                );
                if (insertRes) {
                    this.$emit("inserted");
                    this.$emit("refresh");
                    this.toast(this.i18n("pesticide-inserted").toString(), { type: "success" });
                }
            } else {
                if (!this.selectedPlots.length)
                    this.toast(this.i18n("no-plots-selected-message-pesticide").toString(), { type: "warn" });
            }
        } catch (error) {
            this.toast(error as string, { type: "error" });
        } finally {
            this.disableFormButtons = false;
        }
    }

    private close() {
        this.$emit("close-current-view");
    }

    private onClick(index: number, plot: Plot) {
        this.selectedPlot[index].isActive = !this.selectedPlot[index].isActive;
        this.selectedPlot.push({ plotCode: "-1", isActive: false });
        this.selectedPlot.pop();

        const curIdx = this.selectedPlots.findIndex((p) => p.plotCode === plot.plotCode);
        if (curIdx > -1) {
            this.selectedPlots.splice(curIdx, 1);
        } else {
            this.selectedPlots.push(plot);
        }
        this.getTotalDeclsAreas();
    }

    private parcelsPiped(e: Plot): string | null {
        if (e.parcelIntersections && e.parcelIntersections.length > 0) {
            let str = "";
            e.parcelIntersections.forEach((e) => (str = str ? str + ", " + e.description : e.description));
            return str;
        } else {
            return this.i18n("no-parcel-intersection").toString();
        }
    }
    private declarationsPiped(e: Plot): string | null {
        if (e.decls && e.decls.length > 0) {
            let str = "";
            e.decls.forEach(
                (e) =>
                    (str = str
                        ? str + ", " + (e.landuse.description || e.landuse.code)
                        : e.landuse.description || e.landuse.code)
            );
            return str;
        } else {
            return null;
        }
    }
    private getFieldOccupied(e: Plot): number | null {
        let totalCropArea = 0;
        e.decls
            .filter(
                (d) =>
                    d.fromDate.getTime() <= this.curPointInTime.getTime() &&
                    d.toDate.getTime() >= this.curPointInTime.getTime()
            )
            .forEach((d) => {
                let areaSqm = 0;
                if (d.areaPerc === 100) {
                    areaSqm = e.areaSqm;
                } else {
                    const plotAreaHa = e.areaSqm;
                    const onePercent = plotAreaHa / 100;
                    areaSqm = Math.round(onePercent * d.areaPerc * 10000) / 10000;
                }
                totalCropArea = totalCropArea + areaSqm;
            });
        const areaPercent = e.areaSqm / 100;
        const res = totalCropArea / areaPercent;
        return Math.round(isNaN(res) ? 0 : res);
    }

    private getTotalDeclsAreas() {
        this.selectedPlotsDecls = [];
        let sum = 0;
        if (this.selectedPlots.length > 0) {
            this.selectedPlots.forEach((plot) => {
                plot.decls.forEach((decl) => {
                    const targetDecl: TargetPlotDeclaration = decl as TargetPlotDeclaration;
                    targetDecl.areaSqm = plot.areaSqm;
                    targetDecl.formattedArea = this.getCropAreaFromPercent(
                        targetDecl.areaPerc,
                        this.formattedArea(targetDecl.areaSqm)
                    );
                    this.selectedPlotsDecls.push(targetDecl);
                });
            });
            if (this.selectedPlotsDecls.length) {
                if (this.curCrop && this.curCrop !== null) {
                    this.selectedPlotsDecls.forEach((decl) => {
                        if (decl.landuse && this.curCrop?.landuse && decl.landuse.code === this.curCrop?.landuse.code) {
                            sum += Number(decl.formattedArea);
                        }
                    });
                    this.curCropTotalArea =
                        sum.toLocaleString(this.getLocale(), { minimumFractionDigits: 4, maximumFractionDigits: 4 }) +
                        " " +
                        this.areaLabel();
                }
            }
        } else {
            this.curCropTotalArea = null;
        }
    }

    private getCropAreaFromPercent(declPercent: number, plotArea: string) {
        return ((Number(plotArea) * declPercent) / 100).toLocaleString(this.getLocale(), {
            minimumFractionDigits: 2,
            maximumFractionDigits: 4,
        });
    }
}
</script>

<style lang="scss" scoped>
.edit-crop-plan-crop-row,
.edit-crop-plan-crop-row-border {
    @apply transition-all duration-150 ease-in-out relative;
}

.edit-crop-plan-crop-row {
    @apply flex cursor-pointer items-stretch w-full max-w-full relative;
}
.edit-crop-plan-crop-row-inner {
    @apply flex items-stretch w-full max-w-full py-3 px-3;
}

.edit-crop-plan-crop-row .edit-crop-plan-crop-row-border {
    @apply border rounded-lg absolute top-0 left-0 w-full h-full;
}
.edit-crop-plan-crop-row:hover .edit-crop-plan-crop-row-border,
.edit-crop-plan-crop-row-active .edit-crop-plan-crop-row-border {
    @apply border-info-300;
}

.edit-crop-plan-crop-row-active .edit-crop-plan-crop-row-border {
    border-width: 2px;
}

.sc-decl-edit-form {
    @apply flex gap-4;
    flex-direction: column;
    align-content: stretch;
}
.sc-decl-edit-section {
    @apply px-4 flex flex-wrap;
    flex-grow: 1;
}
.sc-add-pesticide-section {
    @apply px-4 flex flex-wrap;
    flex-grow: 1;
    height: 40vh;
}

.sc-decl-edit-info {
    @apply flex flex-col items-start pr-6 text-label-primary;
}

.sc-decl-edit-title {
    @apply w-full flex font-bold items-baseline text-secondary-700;
}
.sc-decl-edit-sub-title {
    @apply w-full flex;
}

.sc-decl-edit-info div:last-of-type {
    @apply pb-2 border-b;
}

.sc-decl-edit-fields {
    @apply flex flex-col;
}
.sc-add-pesticide-plots-list {
    @apply flex flex-col;
    height: 40vh;
    .selectable-card {
        margin-left: 0 !important;
    }
}

@media (min-width: 640px) {
    .sc-decl-edit-fields {
        @apply mt-2;
    }
}
@media (min-width: 768px) {
    .sc-decl-edit-fields {
        @apply pl-6 border-l;
    }
}
</style>
