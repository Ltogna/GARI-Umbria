<template>
    <tile :title="i18n('pesticides')" noContainerStyled>
        <template #tile-buttons>
            <tile-button :tooltip="i18n('search')" has-side-card v-model="showSearch" :is-active="isFilterActive">
                <template #side-card>
                    <div
                        class="p-6 pt-2"
                        @keydown.enter="
                            showSearch = false;
                            onChangeFilter();
                        "
                    >
                        <div class="flex pt-2">
                            <abc-input class="w-64" :label="i18n('product-name')" v-model="search" />
                        </div>
                        <div class="flex flex-col pt-4">
                            <div class="w-full">
                                <abc-button
                                    class="w-full"
                                    is-outlined
                                    @click="
                                        showSearch = false;
                                        resetFilter();
                                    "
                                >
                                    {{ i18n("clear-field") }}</abc-button
                                >
                            </div>
                            <div class="w-full pt-1">
                                <abc-button
                                    class="w-full"
                                    @click="
                                        showSearch = false;
                                        onChangeFilter();
                                    "
                                    >{{ i18n("search") }}</abc-button
                                >
                            </div>
                        </div>
                    </div>
                </template>
                <em class="text-lg abc-icon abc-icon-lens" />
            </tile-button>
        </template>

        <template #content-buttons>
            <tile-button v-if="curPesticide" :tooltip="i18n('deselect')" @click="curPesticide = null">
                <em class="abc-icon abc-icon-x"></em>
            </tile-button>
            <tile-button v-if="curPesticide" :tooltip="i18n('remove')" @click="showConfirmDelete = true">
                <em class="abc-icon abc-icon-trash-bin"></em>
            </tile-button>
            <tile-button v-if="curPesticide" :tooltip="i18n('edit')" @click="openEditTile = true">
                <em class="abc-icon abc-icon-pen-2"></em>
            </tile-button>
        </template>

        <abc-modal v-if="showConfirmDelete" @close="showConfirmDelete = false" is-message>
            <template #body>
                {{ i18n("confirm-removal-of") }} <span class="font-bold">{{ curPesticide.productName }}</span
                >?
            </template>
            <template #footer>
                <abc-button class="mr-2" is-secondary is-outlined @click="showConfirmDelete = false">
                    <em class="abc-icon abc-icon-arrow-left-round" /> {{ i18n("back") }}
                </abc-button>
                <abc-button @click="deleteElement()" is-danger>
                    <em class="abc-icon abc-icon-trash-bin" /> {{ i18n("confirm") }}
                </abc-button>
            </template>
        </abc-modal>

        <abc-table
            has-footer
            :items="pesticidesPage.records"
            :selected-item="curPesticide"
            @select="onRowSelected"
            hide-no-data
            border-less
        >
            <template #headers>
                <th id="product-name">{{ i18n("product-name") }}</th>
                <th id="date">{{ i18n("date") }}</th>
                <th id="land-use">{{ i18n("land-use") }}</th>
                <th id="dosage">{{ i18n("dosage") }}</th>
                <th id="parcels-id">{{ i18n("parcels-id") }}</th>
            </template>
            <template #items="{ item }">
                <td>
                    {{ item.productName }} <span class="text-label-secondary">{{ item.productCode }}</span>
                </td>
                <td>{{ formattedDate(item.entryDate) }}</td>
                <td>{{ item.declaration.landuse.description }}</td>
                <td>{{ item.amount + " " + item.uomLabel }}</td>
                <td>
                    {{
                        item.parcelIntersection.reduce(
                            (out, i) => (out != "" ? ", " + i.description : i.description),
                            ""
                        )
                    }}
                </td>
            </template>
            <template #footer>
                <abc-infinite-support :data-provider="loadNextpage" :identifier="loadingId"></abc-infinite-support>
            </template>
        </abc-table>
        <div
            v-if="!pesticidesPage.records && pesticidesPage.count === 0"
            class="px-3 py-6 text-label-secondary justify-center flex"
        >
            {{ i18n("no-pesticides") }}
        </div>

        <modal-view v-model="openEditTile">
            <single-cp-decl-pesticide-edit
                @updated="
                    refresh();
                    openEditTile = false;
                "
                @close-current-view="openEditTile = false"
            />
        </modal-view>
    </tile>
</template>

<script lang="ts">
import { Component, Inject, Mixins } from "vue-property-decorator";
import { TranslateResult } from "vue-i18n";
import SingleCropPlanModule, { MODULE_ID } from "../..";
import { FromStore, ToastOptions } from "@abaco/web-common/src/app";
import { Business } from "../../models/Business";
import DateUtils from "../../mixins/DateUtils";
import { Configuration, CropPlan } from "../../models/CropPlan";
import { Council } from "../../models/Council";
import { PesticideEntry } from "../../models/Declaration";
import AreaUtils from "../../mixins/AreaUtils";
import { VBTooltip } from "bootstrap-vue";
import { EmptyNextPagedResults, infiniteNextLoad, NextPagedResults } from "@abaco/web-common/src/Paging";
import SingleCpMapPreview from "../mapComponent/SingleCPMapPreview.vue";
import { Version } from "../../models/Version";
import CropPlanPostEditMessagesModal from "../private/cropPlanPostEditMessagesModal.vue";
import PermanentCropForms from "../private/permanentCropForms.vue";
import { Plot } from "../../models/Plot";

@Component({
    directives: {
        "b-tooltip": VBTooltip,
    },
    components: {
        SingleCpMapPreview,
        CropPlanPostEditMessagesModal,
        PermanentCropForms,
    },
})
export default class SingleCpPesticides extends Mixins(DateUtils, AreaUtils) {
    @Inject() i18n!: (key: string, values?: unknown) => TranslateResult;
    @Inject() toast!: (message: string, options?: ToastOptions) => TranslateResult;
    @Inject(MODULE_ID) singleCropPlanModule!: SingleCropPlanModule;

    @FromStore(MODULE_ID) business!: Business;
    @FromStore(MODULE_ID) curPlot!: Plot | null;
    @FromStore(MODULE_ID) curPlots!: Plot[];
    @FromStore(MODULE_ID) curPointInTime!: Date;
    @FromStore(MODULE_ID) curCropPlan!: CropPlan | null;
    @FromStore(MODULE_ID) curCouncil!: Council | null;
    @FromStore(MODULE_ID) editPlotPolygonDrawn!: boolean;
    @FromStore(MODULE_ID) curVersion!: Version | null;
    @FromStore(MODULE_ID) hideFieldName!: boolean;
    @FromStore(MODULE_ID) curConfiguration!: Configuration | null;
    @FromStore(MODULE_ID) curPesticide!: PesticideEntry | null;
    @FromStore(MODULE_ID) curPlotPesticideUpdated!: boolean;

    private loading = true;
    private loadingId = 0;
    private pesticidesPage: NextPagedResults<PesticideEntry> = new EmptyNextPagedResults();
    private openEditTile = false;
    private showConfirmDelete = false;

    private search: string | null = null;
    private showSearch = false;

    private onChangeFilter() {
        this.curPesticide = null;
        this.openEditTile = false;
        this.pesticidesPage = new EmptyNextPagedResults();
        this.loadingId++;
    }

    private refresh() {
        this.curPesticide = null;
        this.onChangeFilter();
        this.toast(this.i18n("decl-pesticide-updated") as string, { type: "success" });
    }
    private resetFilter() {
        this.search = null;
        this.onChangeFilter();
    }
    private get isFilterActive() {
        if (this.search) {
            return true;
        }
        return false;
    }

    async mounted() {
        this.curPesticide = null;
    }

    private async onRowSelected(itemIndex: number) {
        this.curPesticide = this.pesticidesPage.records[itemIndex];
    }

    private async loadNextpage(): Promise<boolean> {
        this.loading = true;
        const newPage = await infiniteNextLoad(
            (nextKey) =>
                this.curCropPlan
                    ? this.singleCropPlanModule.cropPlanApi.getAllPesticides(
                          this.business.businessId,
                          this.curCropPlan.cropPlanId,
                          this.curVersion ? this.curVersion.version : null,
                          this.search,
                          nextKey
                      )
                    : new Promise<NextPagedResults<PesticideEntry>>(() => []),
            this.pesticidesPage
        );
        if (newPage) {
            this.pesticidesPage = newPage;
            this.loading = false;
            return true;
        }
        return false;
    }

    private async deleteElement() {
        if (!this.curPointInTime && !this.business && !this.curCouncil && !this.curCropPlan) {
            return false;
        }
        this.showConfirmDelete = false;
        const e = this.curPesticide;
        const currentElementIdx = this.pesticidesPage.records.findIndex((el) => {
            if (e) return el.productCode == e.productCode;
        });
        try {
            if (!this.curPointInTime || !this.business || !this.curCouncil || !this.curCropPlan || !this.curPesticide)
                return;
            await this.singleCropPlanModule.cropPlanApi.deletePesticide(
                this.business.businessId,
                this.curCropPlan.cropPlanId,
                this.curCouncil.domainZoneId,
                this.curPesticide.plotCode,
                this.curPesticide.declCode,
                this.curPesticide.pesticideEntryCode
            );
            this.pesticidesPage.records.splice(currentElementIdx, 1);
            if (e)
                this.toast(this.i18n(e.productCode + " " + this.i18n("removed")) as string, {
                    type: "success",
                    duration: 4000,
                });
            this.curPesticide = null;
            this.curPlotPesticideUpdated = true;
            if (this.curPlotPesticideUpdated) this.$emit("deleted");
        } catch (error) {
            this.toast(error as string, { type: "error", duration: 4000 });
        }
    }

    private close() {
        this.$emit("close-current-view");
    }
}
</script>

<style lang="scss" scoped></style>
