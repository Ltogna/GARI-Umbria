import { RouteConfig } from "@abaco/web-common/src/app";

const routes: RouteConfig[] = [
    {
        name: "single-crop-plan-home",
        path: "/",
        component: () => import("./components/SingleCropPlanTileContainer.vue"),
        meta: {
            navbarItems: [
                "point-in-time-select-nav-bar-item",
                "council-select-nav-bar-item",
                "crop-plan-select-nav-bar-item",
                "business-select-nav-bar-item",
            ],
        },
    },
];

export default routes;
