import { Component, Inject, Mixins } from "vue-property-decorator";
import { TranslateResult } from "vue-i18n";
import { FromStore } from "@abaco/web-common/src/app";
import FarmerRegistryModule, { MODULE_ID } from "../index";
import DateUtils from "../mixins/DateUtils";
import { Configuration, CropPlan, CropPlanType } from "../models/CropPlan";
import { convertToDate, formatDate } from "../api/Utils";
import { Council } from "../models/Council";

@Component
export default class PointInTimeChange extends Mixins(DateUtils) {
    @Inject(MODULE_ID) farmRegistryModule!: FarmerRegistryModule;
    @Inject() i18n!: (key: string, values?: unknown) => TranslateResult;

    @FromStore(MODULE_ID) availableCropPlanTypes!: CropPlanType[];
    @FromStore(MODULE_ID) curCropPlan!: CropPlan | null;
    @FromStore(MODULE_ID) curConfiguration!: Configuration | null;
    @FromStore(MODULE_ID) curPointInTime!: Date | null;
    @FromStore(MODULE_ID) newPointInTime!: Date | null;
    @FromStore(MODULE_ID) forceSync!: number;
    @FromStore(MODULE_ID) flSyncToRecalcAnomalies!: boolean;
    @FromStore(MODULE_ID) forceSearchCouncil!: number;
    @FromStore(MODULE_ID) curCouncil!: Council | null;
    @FromStore(MODULE_ID) plotsForceReload!: number;
    @FromStore(MODULE_ID) showConfirmDateChangeModal!: boolean;
    @FromStore(MODULE_ID) plotCodeToSelect!: string | null;
    @FromStore(MODULE_ID) plotCodesToSelect!: string[];

    protected onPointInTimeChange(val: Date) {
        if ((this.getPointInTimeRangeMin && val < this.getPointInTimeRangeMin) || (this.getPointInTimeRangeMax && val > this.getPointInTimeRangeMax)) return; // TODO add error message: date not valid for cur ctop plan type
        this.newPointInTime = val;
        if (
            (this.curConfiguration?.ENABLE_CHANGE_DATE_CONFIRM === "TRUE" && this.pointInTimeIsAtFixedOpenDate) ||
            this.constrainsVersionToSyncRefDate
        ) {
            this.showConfirmDateChangeModal = true;
        } else {
            this.saveCurSelectedPlots();
            this.curPointInTime = val;
            this.plotsForceReload++; // reload plots by default
            this.forceSync++; // check if recal anomalies is required, if required plots will be reloaded again
        }
    }

    protected get constrainsVersionToSyncRefDate() {
        return (
            this.curConfiguration?.CONSTRAINTS_VERSION_TO_SYNC_REF_DATE === "TRUE" &&
            !this.anomaliesCalculatedForNewPointInTime
        );
    }

    protected setToFixedOpenDate() {
        if (!this.cropPlanDates?.fixedOpenDate) return;
        const fixedOpenDate = convertToDate(this.cropPlanDates.fixedOpenDate);
        if (fixedOpenDate) {
            this.newPointInTime = fixedOpenDate;
            if (this.constrainsVersionToSyncRefDate) {
                this.showConfirmDateChangeModal = true;
            } else {
                this.saveCurSelectedPlots();
                this.curPointInTime = fixedOpenDate;
                this.newPointInTime = null;
                this.plotsForceReload++; // reload plots by default
                this.forceSync++;
            }
        }
    }

    protected confirmPointInTimeChange() {
        this.saveCurSelectedPlots();
        this.curPointInTime = this.newPointInTime;
        if (this.constrainsVersionToSyncRefDate) {
            if (this.flSyncToRecalcAnomalies) this.forceSync++;
            else {
                if (!this.curCouncil) this.forceSearchCouncil++;
                this.plotsForceReload++;
            }
        } else {
            this.plotsForceReload++; // reload plots by default
            this.forceSync++;
        }
        this.showConfirmDateChangeModal = false;
        this.newPointInTime = null;
        this.flSyncToRecalcAnomalies = false;
    }

    protected cancelPointInTimeChange() {
        this.showConfirmDateChangeModal = false;
        this.flSyncToRecalcAnomalies = false;
        this.newPointInTime = null;
    }

    protected get fixedOpenDate() {
        if (this.cropPlanDates.fixedOpenDate && convertToDate(this.cropPlanDates.fixedOpenDate) != null)
            return this.formattedDate(convertToDate(this.cropPlanDates.fixedOpenDate)!);
        return "";
    }

    protected saveCurSelectedPlots(){
        this.plotCodeToSelect = this.curPlot?.plotCode || null;
        this.plotCodesToSelect = this.curPlots.map((p) => p.plotCode);
    }

    protected get getNewPointInTime() {
        if (this.newPointInTime != null) return this.formattedDate(this.newPointInTime);
        return "";
    }

    protected get anomaliesCalculatedForNewPointInTime() {
        return this.newPointInTime && formatDate(this.newPointInTime) === this.cropPlanDates.lastSyncReferenceDate;
    }

    protected get pointInTimeIsAtFixedOpenDate() {
        return (
            this.cropPlanDates.fixedOpenDate &&
            this.curPointInTime &&
            formatDate(this.curPointInTime) == this.cropPlanDates.fixedOpenDate
        );
    }

    private get getPointInTimeRangeMin(): Date | null {
        if (!this.availableCropPlanTypes.length) return null;
        const dayFrom = this.availableCropPlanTypes.find((cpt) => cpt.cropPlanTypeCode === this.curCropPlan?.cropPlanTypeCode)?.dayFrom || null;
        return dayFrom ? new Date(dayFrom.getTime() - 24 * 60 * 60 * 1000) : null;    }

    private get getPointInTimeRangeMax(): Date | null {
        if (!this.availableCropPlanTypes.length) return null;
        const dayTo =  this.availableCropPlanTypes.find((cpt) => cpt.cropPlanTypeCode === this.curCropPlan?.cropPlanTypeCode)?.dayTo || null;
        return dayTo ? new Date(dayTo.getTime() + 24 * 60 * 60 * 1000) : null;
    }
}
