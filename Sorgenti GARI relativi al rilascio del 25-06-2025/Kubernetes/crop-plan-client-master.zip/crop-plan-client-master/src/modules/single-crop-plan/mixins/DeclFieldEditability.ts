import { Component, Inject, Vue } from "vue-property-decorator";

import { FromStore } from "@abaco/web-common/src/app";
import { EnvConfig } from "@abaco/web-common/src/app/Application";
import { Configuration } from "../models/CropPlan";
import { MODULE_ID } from "..";
import { VineyardPropertyRules } from "../models/PermanentCropForm";

interface ValidationRules {
    [key: string]: RegExp;
}
interface FormDataFieldsKeys {
    [key: string]: string;
}

@Component
export default class DeclFieldEditability extends Vue {
    @Inject() envConfig!: EnvConfig;
    @FromStore(MODULE_ID) curConfiguration!: Configuration | null;

    protected formDataFieldsKeys: FormDataFieldsKeys = {
        altitudeAboveSeaLevel: "ALTITUDE_ABOVE_SEA_LEVEL",
        areaSqm: "AREA_SQM",
        bio: "BIO",
        covering: "COVERING",
        cultivationState: "CULTIVATION_STATE",
        cultivationTypeCode: "CULTIVATION_TYPE_CODE",
        distanceBetweenRowsCm: "DISTANCE_BETWEEN_ROWS_CM",
        distanceOnTheRowCm: "DISTANCE_ON_THE_ROW_CM",
        externalDescription: "EXTERNAL_DESCRIPTION",
        externalCode: "EXTERNAL_CODE",
        failuresPerc: "FAILURES_PERC",
        farmingForm: "FARMING_FORM",
        graftDate: "GRAFT_DATE",
        graftHolder: "GRAFT_HOLDER",
        headerAnchoring: "HEADER_ANCHORING",
        irrigation: "IRRIGATION",
        judgement: "JUDGEMENT",
        layering: "LAYERING",
        origin: "ORIGIN",
        plantingType: "PLANTING_TYPE",
        polesDistanceCm: "POLES_DISTANCE_CM",
        polesHeader: "POLES_HEADER",
        polesWeaving: "POLES_WEAVING",
        productDestinationCode: "PRODUCT_DESTINATION_CODE",
        pruning: "PRUNING",
        protectionStructures: "PROTECTION_STRUCTURES",
        qualitySystem: "QUALITY_SYSTEM",
        rock: "ROCK",
        skeleton: "SKELETON",
        soilLayeringPerc: "SOIL_LAYERING_PERC",
        stumpsDensity100: "STUMPS_DENSITY_100",
        stumpsNumber: "STUMPS_NUMBER",
        subscriptionCodes: "SUBSCRIPTION_CODES",
        supportWires: "SUPPORT_WIRES",
        terracing: "TERRACING",
        varietyCode: "VARIETY_CODE",
        variationTypeCode: "VARIATION_TYPE_CODE",
        vegetativeState: "VEGETATIVE_STATE",
        vineyardTypeCode: "VINEYARD_TYPE_CODE",
        plantingYear: "PLANTING_YEAR",
        shiftInYears: "SHIFT_IN_YEARS",
        expectedCuttingDate: "EXPECTED_CUTTING_DATE"
    }

    protected rules: ValidationRules = { // TODO - Handle also function rules
        altitudeAboveSeaLevelRule: /^(0|[1-9]\d{0,2}|[1-2]\d{3}|3000)$/,
        distanceRangeRule: /^(50|[5-9]\d|[1-9]\d{2}|1000)$/,
        greaterThanZeroRule: /^(0|[1-9]\d*)$/,
        percentageRule: /^(100|[1-9]?\d)$/,
        polesDistanceRule: /^(50|[5-9]\d|[1-9]\d{2}|1000)$/,
        yearRule: /^([1-9]\d{3})$/
    }

    protected vineyardPropertyRules: VineyardPropertyRules = {
        altitudeAboveSeaLevel: ["altitudeAboveSeaLevelRule"],
        areaSqm: [],
        bio: [],
        covering: [],
        cultivationState: [],
        cultivationTypeCode: [],
        distanceBetweenRowsCm: ["distanceRangeRule"],
        distanceOnTheRowCm: ["distanceRangeRule"],
        externalDescription: [],
        externalCode: [],
        failuresPerc: ["percentageRule"],
        farmingForm: [],
        graftDate: [],
        graftHolder: [],
        headerAnchoring: [],
        irrigation: [],
        judgement: [],
        layering: [],
        origin: [],
        plantingType: [],
        polesDistanceCm: ["polesDistanceRule"],
        polesHeader: [],
        polesWeaving: [],
        productDestinationCode: [],
        pruning: [],
        protectionStructures: [],
        qualitySystem: [],
        rock: [],
        skeleton: [],
        soilLayeringPerc: ["percentageRule"],
        stumpsDensity100: [],
        stumpsNumber: ["greaterThanZeroRule"],
        subscriptionCodes: [],
        supportWires: [],
        terracing: [],
        varietyCode: [],
        variationTypeCode: [],
        vegetativeState: [],
        vineyardTypeCode: [],
        plantingYear: ["yearRule"],
        shiftInYears: ["greaterThanZeroRule"],
        expectedCuttingDate: [],
    
    }

    protected notValidFields = new Set<string>([]);
    protected shouldBeEditable = new Set<string>([]);
    protected disabledFields = new Set<string>([]);

    protected pushToNotValidFields(fieldCode: string) {
        this.notValidFields.add(fieldCode);
    }

    protected pushToShouldBeEditable(fieldCode: string) {
        this.shouldBeEditable.add(fieldCode);
    }

    protected checkIfFieldIsEditable(fieldCode: string, isNew: boolean, val?: any): boolean {
        if (this.shouldBeEditable.has(fieldCode)) return true;
        if (this.curConfiguration?.DISABLE_VALUED_DECL_FIELDS_EDIT === 'TRUE' && !isNew && val) {
            return false
        }
        if (this.curConfiguration?.DISABLE_VALID_VALUED_DECL_FIELDS_EDIT === 'TRUE' && !isNew) {
            if (!val && val !== 0) return true;
            return this.notValidFields.has(fieldCode);
        }
        return true;
    }

    protected pushToDisabledFields(fieldCode: string) {
        this.disabledFields.add(fieldCode);
    }

    protected setVineyardFormFieldEditability(fieldCode: string, isNew: boolean, val?: any) {
        if (this.curConfiguration?.DISABLE_VALUED_DECL_FIELDS_EDIT === 'TRUE' && !isNew && ((val != null) &&
            (val !== '') &&
            !isNaN(Number(val.toString())))
        ) {
            this.pushToDisabledFields(fieldCode);
        }
        if (this.curConfiguration?.DISABLE_VALID_VALUED_DECL_FIELDS_EDIT === 'TRUE' && !isNew) {
            if (!this.notValidFields.has(fieldCode) && (val || typeof val === "number")) this.pushToDisabledFields(fieldCode);
        }
    }

    protected resetDeclFieldEditabilityState() {
        this.notValidFields = new Set<string>([]);
        this.shouldBeEditable = new Set<string>([]);
        this.disabledFields = new Set<string>([]);
    }
}
