import { Component, Vue } from "vue-property-decorator";
import { MODULE_ID as SSO_MODULE_ID } from "@abaco/sso-web-module/src/abaco-module";
import { BaseUser } from "@abaco/web-common/src/BaseUser";
import { FromStore } from "@abaco/web-common/src/app";
import { i18n } from "@abaco/web-components/src/components/i18n";

@Component
export default class AreaUtils extends Vue {
    @FromStore(SSO_MODULE_ID) user!: BaseUser;

    private areaMeasureLabel = "ha";

    formattedArea(e: number): string {
        const inEctars = e / 10000;
        return `${Number(inEctars).toLocaleString(this.getLocale(), {
            minimumFractionDigits: 4,
            maximumFractionDigits: 4,
        })}`;
    }
    formattedAreaWithLabel(e: number): string {
        const inEctars = e / 10000;
        return `${Number(inEctars).toLocaleString(this.getLocale(), {
            minimumFractionDigits: 4,
            maximumFractionDigits: 4,
        })} ${this.areaMeasureLabel}`;
    }
    areaLabel(): string {
        return this.areaMeasureLabel;
    }

    getLocale(): string {
        return i18n.locale;
    }

    getUsedAreaPerc(maxDeclarableAreaPerc: number) {
        return 100 - maxDeclarableAreaPerc;
    }

    formattedPercentage(e: number, numberOfDecimals: number): string {
        return `${e.toLocaleString(this.getLocale(), {
            minimumFractionDigits: numberOfDecimals,
            maximumFractionDigits: numberOfDecimals,
        })}`;
    }
}
