import { Component, Inject, Vue } from "vue-property-decorator";
import { DateHelper } from "@abaco/web-components/src/components/DateUtils";
import { MODULE_ID as SSO_MODULE_ID } from "@abaco/sso-web-module/src/abaco-module";
import { BaseUser } from "@abaco/web-common/src/BaseUser";
import { FromStore } from "@abaco/web-common/src/app";
import { EnvConfig } from "@abaco/web-common/src/app/Application";
import SingleCropPlan from "..";
import { CropPlanDates } from "../models/CropPlan";
import { convertToDate } from "../api/Utils";
import { Plot } from "../models/Plot";

@Component
export default class DateUtils extends Vue {
    @Inject() envConfig!: EnvConfig;
    @FromStore(SSO_MODULE_ID) user!: BaseUser;
    @FromStore(SingleCropPlan.MODULE_ID) cropPlanDates!: CropPlanDates;
    @FromStore(SingleCropPlan.MODULE_ID) curPlot!: Plot | null;
    @FromStore(SingleCropPlan.MODULE_ID) curPlots!: Plot[];
    
    formattedDate(dt: Date): string {
        return new DateHelper(dt).format(this.user.dateFormat);
    }

    formattedYear(dt: Date): string {
        return new DateHelper(dt).format(`yyyy`);
    }

    formattedDayMonth(dt: Date): string {
        return new DateHelper(dt).format(`dd/MM`);
    }

    formattedDateWithFormat(dt: Date, format: string): string {
        const res = new DateHelper(dt).format(format);
        return res;
    }

    getLocale(): string {
        return this.user.locale;
    }

    get pointInTimeRangeMin() {
        if (this.envConfig.pointInTimeRangeMin) {
            return this.parseConfig(this.envConfig.pointInTimeRangeMin);
        }
        return null;
    }

    get maxCampaignAndPlotsDate(): Date | null {
        const dates = [];
        if(this.cropPlanDates.campaignStartDate) {
            const campaignStartDate = convertToDate(this.cropPlanDates.campaignStartDate);
            if(campaignStartDate)
                dates.push(campaignStartDate.getTime());
        }
        
        if (this.curPlot) {
            dates.push(
                this.curPlot.fullRangeFromDate.getTime(),
                ...this.curPlots.map((plot) => plot.fullRangeFromDate.getTime()),
            )
        }
        return  dates.length ? new Date(Math.max(...dates)) : null;
    }

    private parseConfig(config: string) {
        const tokens = config.match(/(\d+[ymd]+)/g);
        if (!tokens) {
            return null;
        }
        let res = new Date();
        tokens?.forEach((tk) => {
            const value = parseInt(tk.substring(0, tk.length - 1));
            const format = tk.charAt(tk.length - 1);
            switch (format) {
                case "y":
                    res = new Date(res.getFullYear() - value, 0, 1);
                    break;
                case "m":
                    res = new Date(res.getFullYear(), res.getMonth() - value, 1);
                    break;
                case "d":
                    res.setDate(res.getDate() - value);
                    break;
                default:
                    throw new Error(format + " is Not a valid format");
            }
        });
        return res;
    }
}
