import { FromStore } from "@abaco/web-common/src/app";
import { Component, Vue } from "vue-property-decorator";
import SingleCropPlan from "..";
import { Configuration, CropPlan } from "../models/CropPlan";
import { EditPlotMode, Plot } from "../models/Plot";

@Component
export default class CanEditCheckAndExecute extends Vue {
    @FromStore(SingleCropPlan.MODULE_ID) curPlots!: Plot[];
    @FromStore(SingleCropPlan.MODULE_ID) curPlot!: Plot | null;
    @FromStore(SingleCropPlan.MODULE_ID) showEditPublishedCropPlanModal!: boolean;
    @FromStore(SingleCropPlan.MODULE_ID) curCropPlan!: CropPlan | null;
    @FromStore(SingleCropPlan.MODULE_ID) editPublishedCropPlanCallback!: (() => void) | null;
    @FromStore(SingleCropPlan.MODULE_ID) flCurCorpPlanChangesPending!: boolean;
    @FromStore(SingleCropPlan.MODULE_ID) curConfiguration!: Configuration | null;
    @FromStore(SingleCropPlan.MODULE_ID) lastEditPlotMode!: EditPlotMode | null;
    @FromStore(SingleCropPlan.MODULE_ID) curPointInTime!: Date | null;
    @FromStore(SingleCropPlan.MODULE_ID) showEditWarningModal!: boolean;

    private showWarningCannotEdit = false;

    private checkAndExecEditGeom(action: () => void) {
        let plotsSelected = this.curPlots;
        if (this.curPlot) {
            plotsSelected = plotsSelected.concat([this.curPlot]);
        }

        if (plotsSelected.some((p) => p.editability != "EDITABLE")) {
            this.showWarningCannotEdit = true;
            return;
        }

        if(
            !((this.curCropPlan && !this.curCropPlan.readOnly && !this.curCropPlan.changesPending) || this.flCurCorpPlanChangesPending) 
            && this.curConfiguration?.ENABLE_PUBLISH_WHEN_NO_CHANGES_PENDING !== 'TRUE'
            && this.curCropPlan?.cropPlanTypeCode !== "VINE"
        )
        {
            this.editPublishedCropPlanCallback = action;
            this.showEditPublishedCropPlanModal = true;
        }
        else
            action();
    }

    private checkAndExecAddDecl(action: () => void, fallbackAction?: () => void) {
        let plotsSelected = this.curPlots;
        if (this.curPlot) {
            plotsSelected = plotsSelected.concat([this.curPlot]);
        }

        if (plotsSelected.some((p) => p.editability === "NOT_EDITABLE")) {
            this.showWarningCannotEdit = true;
            if (fallbackAction) fallbackAction();

            return;
        }

        if(
            !((this.curCropPlan && !this.curCropPlan.readOnly && !this.curCropPlan.changesPending) || this.flCurCorpPlanChangesPending) 
            && this.curConfiguration?.ENABLE_PUBLISH_WHEN_NO_CHANGES_PENDING !== 'TRUE'
            && this.curCropPlan?.cropPlanTypeCode !== "VINE"
        )
        {
            this.editPublishedCropPlanCallback = action;
            this.showEditPublishedCropPlanModal = true;
            
            if (fallbackAction) fallbackAction();
        }
        else
        action();
    }

    private checkAndExecEditCurDecl(action: () => void, flIgnoreNotEditable?: boolean) {
        if (this.curPlot && this.curPlot.editability === "NOT_EDITABLE" && !flIgnoreNotEditable) {
            this.showWarningCannotEdit = true;
            return;
        }

        if(
            !((this.curCropPlan && !this.curCropPlan.readOnly && !this.curCropPlan.changesPending) || this.flCurCorpPlanChangesPending) 
            && this.curConfiguration?.ENABLE_PUBLISH_WHEN_NO_CHANGES_PENDING !== 'TRUE'
            && this.curCropPlan?.cropPlanTypeCode !== "VINE"
        )
        {
            this.editPublishedCropPlanCallback = action;
            this.showEditPublishedCropPlanModal = true;
        }
        else
        action();
    }

    private checkAndExecEditCurPlots(action: () => void) {
        if (this.curPlot && (this.curPlot.editability === "NOT_EDITABLE" || this.curPlots.find(p => p.editability == "NOT_EDITABLE"))) {
            this.showWarningCannotEdit = true;
            return;
        }

        if(
            !((this.curCropPlan && !this.curCropPlan.readOnly && !this.curCropPlan.changesPending) || this.flCurCorpPlanChangesPending) 
            && this.curConfiguration?.ENABLE_PUBLISH_WHEN_NO_CHANGES_PENDING !== 'TRUE'
            && this.curCropPlan?.cropPlanTypeCode !== "VINE"
        )
        {
            this.editPublishedCropPlanCallback = action;
            this.showEditPublishedCropPlanModal = true;
        }
        else
        action();
    }

    protected checkAndExecEditDeleteGeom(action: () => void) {
        if (this.curPlot?.editability === "NOT_EDITABLE" || this.curPlot?.editability === "ONLY_DECLARATIONS") {
            this.showWarningCannotEdit = true;
            return;
        }

        if(
            !((this.curCropPlan && !this.curCropPlan.readOnly && !this.curCropPlan.changesPending) || this.flCurCorpPlanChangesPending) 
            && this.curConfiguration?.ENABLE_PUBLISH_WHEN_NO_CHANGES_PENDING !== 'TRUE'
            && this.curCropPlan?.cropPlanTypeCode !== "VINE"
        )
        {
            this.editPublishedCropPlanCallback = action;
            this.showEditPublishedCropPlanModal = true;
        }
        else
            action();
    }

    protected checkDate(action: () => void, mode: EditPlotMode, maxCampaignAndPlotsDate: Date): void {
        if(
            this.curConfiguration?.ENABLE_PLOT_EDIT_DATE_WARNING !== "TRUE" ||
            !(maxCampaignAndPlotsDate && this.curPointInTime) ||
            (
                maxCampaignAndPlotsDate &&
                this.curPointInTime.getTime() === maxCampaignAndPlotsDate.getTime()
            )
        ) {
            action();
            return;
        }
        this.lastEditPlotMode = mode;
        this.showEditWarningModal = true;
    }
}
