import { LayerDef } from "@abaco/iacs-map-module/src/modules/map-module/Layer/GenericLayer";
import { AbacoVuexModule, State } from "@abaco/web-common/src/app";
import { Business } from "./models/Business";
import { Council, SubdomainZone } from "./models/Council";
import {
    AnomaliesScenarioConfiguration,
    Configuration,
    CropPlan,
    CropPlanDates,
    CropPlanType,
    FunctionCode,
} from "./models/CropPlan";
import {
    CadastralData,
    CadastralOverlap,
    Declaration,
    ParcelData,
    PestEntry,
    PesticideEntry,
    TimelineSection,
} from "./models/Declaration";
import { PermanentCropField } from "./models/PermanentCropForm";
import { EditPlotMode, Parcel, PermanentCropFormValueConfig, Plot, PlotStyleOverride } from "./models/Plot";
import { AppLoadingItem } from "./models/Utils";
import { Version } from "./models/Version";

export default class SingleCropPlanVuexModule extends AbacoVuexModule {
    @State() autoSelectableBusiness!: Business | null;
    @State() autoSelectBusiness!: boolean;
    @State() businessNavBarFilterOpen!: boolean;
    @State() cropPlanNavbarFilterOpen!: boolean;
    @State() pointInTimeNavBarFilterOpen!: boolean;
    @State() business!: Business | null;
    @State() curPlot!: Plot | null;
    @State({ default: [] }) curPlots!: Plot[];
    @State({ default: EditPlotMode.NOT_SELECTED }) editPlotMode!: EditPlotMode;
    @State({ default: null }) lastEditPlotMode!: EditPlotMode | null;
    @State({ default: false }) forcePlotModeReset!: boolean;

    @State() curTimelineSection!: TimelineSection | null;
    @State() curDeclaration!: Declaration | null;
    @State({ default: false }) newDeclEditOpened!: boolean;
    @State() curVersion!: Version | null;
    @State({ default: null }) curPointInTime!: Date | null;
    @State({ default: null }) newPointInTime!: Date | null;
    @State() curCouncil!: Council | null;
    @State() curCropPlan!: CropPlan | null;
    @State() availableCropPlanTypes!: CropPlanType[];
    @State({ default: [] }) plots!: Plot[];
    @State({ default: 0 }) plotsForceReload!: number;
    @State({ default: 0 }) forceApplyFilters!: number;
    @State({ default: [] }) plotsStyleOverride!: PlotStyleOverride[];
    @State({ default: false }) showLockErrorModal!: boolean;
    @State({ default: false }) showNoCropPlanFound!: boolean;
    @State({ default: false }) showCannotUseCropPlan!: boolean;
    @State({ default: false }) showCannotUseCropPlanForThisBusiness!: boolean;
    @State({ default: false }) showCropPlanNotAccessibleModal!: boolean;
    @State({ default: false }) showCropPlanNotAccessibleModalMessage!: string;
    @State({ default: false }) flCurCorpPlanChangesPending!: boolean;
    @State({ default: false }) flShowCropPlanProgressBar!: boolean;
    @State({ default: false }) editModalWarningDisabled!: boolean;
    @State({ default: [] }) defaultLayers!: LayerDef[];
    @State({ default: false }) hideFieldName!: boolean;
    @State({ default: false }) showParcelName!: boolean;
    @State({ default: 0 }) resetCouncil!: number;
    @State({ default: false }) isCurPlotWithWarning!: boolean;
    @State({ default: [] }) currentPlotDeclarations!: Declaration[];
    @State({
        default: {
            CONSTRAINTS_DECLS_TO_PLOTS: "TRUE",
            COPY_DECLARATIONS_AT_DATE: null,
        },
    })
    curConfiguration!: Configuration | null;
    @State({ default: false }) cropPlanEditModeEnabled!: boolean;
    @State({ default: false }) editEnabled!: boolean;
    @State({ default: false }) deleteEnabled!: boolean;
    @State({ default: "idle" }) selectorStep!: string;
    @State({ default: false }) openCloneMode!: boolean;
    @State({ default: true }) toolbuttonsEnabled!: boolean;
    @State({ default: true }) showNavBar!: boolean;
    @State({ default: true }) multiplePlotSelection!: boolean;
    @State({ default: null }) lockedBusinessId!: string | null;
    @State({ default: null }) lockedCropPlanTypeCode!: string | null;
    @State({ default: false }) loadingCropPlan!: boolean;
    @State({ default: null }) lastCropPlanVersionAvailable!: Version | null;
    @State({ default: false }) isCropPlanRestoreVersionAvailable!: boolean;
    @State({ default: false }) openAddProductMode!: boolean;
    @State({ default: false }) openAddPestMode!: boolean;
    @State({ default: false }) curPesticide!: PesticideEntry | null;
    @State({ default: false }) curPest!: PestEntry | null;
    @State({ default: false }) curPlotPesticideDelete!: boolean;
    @State({ default: false }) curPlotPestDelete!: boolean;
    @State({ default: null }) cadastralData!: CadastralData[] | null;
    @State({ default: null }) parcelData!: ParcelData[] | null;
    @State({ default: null }) curParcelData!: ParcelData | null;
    @State({ default: null }) curParcel!: Parcel | null;
    @State({ default: null }) curCadastralData!: CadastralData | null;
    @State({ default: null }) curCadastralOverlapData!: CadastralOverlap | null;
    @State({ default: false }) blockMapPlotSelection!: boolean;
    @State({ default: [] }) appLoadingQueue!: AppLoadingItem[];
    @State({ default: null }) cropPlanDates!: CropPlanDates;
    // Check flPublish if polling is running
    @State({ default: false }) pollingIsProcessing!: boolean;
    // Check flPublish if polling is success
    @State({ default: false }) pollingIsPublishSuccess!: boolean;
    // Check flPublish if polling status on modal is shown
    @State({ default: false }) pollingIsModalOpen!: boolean;
    // Flag for handle show confirmation delete plot modal
    @State({ default: false }) showConfirmDeletePlot!: boolean;
    // Flag for handle show confirmation restore plot modal
    @State({ default: false }) showConfirmRestorePlot!: boolean;
    @State({ default: false }) showConfirmRestoreFirstVersionPlot!: boolean;
    @State({ default: true }) timelineExpanded!: boolean;
    // Array of key -> FormType & value -> FormFields
    @State({ default: {} }) savedFormsTypes!: Record<string, PermanentCropField[]>;
    @State({ default: false }) openEditTile!: boolean;
    @State({ default: false }) openParcelTile!: boolean;
    @State({ default: false }) openPlotCompleteTaraModal!: boolean;
    @State({ default: false }) showEditPublishedCropPlanModal!: boolean;
    @State({ default: null }) editPublishedCropPlanCallback!: (() => void) | null;
    @State({ default: [] }) enabledPermanentCropFormsValues!: PermanentCropFormValueConfig[];
    @State({ default: false }) hasCoveredByInserted!: boolean;
    @State({ default: [] }) anomScenarioConfig!: AnomaliesScenarioConfiguration[];
    @State({ default: [] }) curDisabledFunctions!: FunctionCode[];
    // @State({ default: false }) enableDefaultNotPreserveDeclsOnPlotsMerge!: boolean;
    @State({ default: false }) showCropPlanSyncModal!: boolean;
    @State({ default: false }) flRecalcAnomalies!: boolean;
    @State({ default: false }) flVinealignBackoffice!: boolean;
    @State({ default: 0 }) forceSync!: number;
    @State({ default: [] }) curTimelineSections!: TimelineSection[];
    @State({ default: false }) flIgnorePreviousSyncs!: boolean;
    @State() plotCodeToSelect!: string | null; // curPlot selected
    @State() plotCodesToSelect!: string[]; // curPlots selected
    @State({ default: [] }) filteredPlots!: Plot[];
    @State({ default: false }) showEditWarningModal!: boolean;
    @State({ default: 0 }) forceStartDrawing!: number;
    @State({ default: 0 }) forceStartEditing!: number;
    @State({ default: 0 }) forceSearchCouncil!: number;
    @State({ default: false} ) flSyncToRecalcAnomalies!: boolean;
    @State({ default: false} ) showRecalcAnomaliesConfirmModal!: boolean;
    @State({ default: { id: -1, geom: null} }) subdomainZone!: SubdomainZone;
    @State({ default: { id: -1, geom: null} }) curCropPlanArea!: SubdomainZone;
    @State({ default: false} ) calcCoveredByInsertedOnCutOnLayer!: boolean;
    @State({ default: false} ) showBulkDeclarationEdit!: boolean;
    @State({ default: false} ) showConfirmDateChangeModal!: boolean;
}
