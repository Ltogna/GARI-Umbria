import { AbacoWebModule, RouterReadyEvent, VueRouter, ApplicationReadyEvent } from "@abaco/web-common/src/app";
import globals from "./globals";
import myRoutes from "./routes";
import SingleCropPlanVuexModule from "./state";
import { HTTPClient } from "@abaco/web-common/src/HTTP";
import PlotApi from "./api/PlotApi";
import BusinessApi from "./api/BusinessApi";
import DeclarationApi from "./api/DeclarationApi";
import CouncilApi from "./api/CouncilApi";
import CropPlanApi from "./api/CropPlanApi";
import VersionApi from "./api/VersionApi";
import SsoVuexModule from "@abaco/sso-web-module/src/abaco-module/state";
import SSOModule, { MODULE_ID as SSO_MODULE_ID } from "@abaco/sso-web-module/src/abaco-module";
import LayerApi from "./api/LayerApi";
import { DateHelper } from "@abaco/web-components/src/components/DateUtils";
import PermanentCropFormApi from "./api/PermanentCropFormApi";
import CadastralParcelApi from "./api/CadastralParcelApi";
import LandUseApi from "./api/LandUseApi";

export const MODULE_ID = "single_crop_plan";

export interface ResponseWithErrorCode {
    status: number;
    data: {
        errorCode: string;
    };
}

export default class SingleCropPlan implements AbacoWebModule {
    public static MODULE_ID = MODULE_ID;

    private apiCreated = false;
    private plApi!: PlotApi;
    private busApi!: BusinessApi;
    private declApi!: DeclarationApi;
    private councApi!: CouncilApi;
    private cpApi!: CropPlanApi;
    private lyrApi!: LayerApi;
    private verApi!: VersionApi;
    private pcfApi!: PermanentCropFormApi;
    private cadparcelApi!: CadastralParcelApi;
    private luApi!: LandUseApi;
    private rootPath: string;

    private router!: VueRouter;
    private ssoStore!: SsoVuexModule;

    private dateFormatter = new DateHelper();

    readonly id = MODULE_ID;
    readonly routes = myRoutes;
    readonly globalComponents = globals;
    readonly vuexModule = new SingleCropPlanVuexModule();

    onRouterReady(evt: RouterReadyEvent) {
        this.router = evt.router;
    }

    constructor(rootPath: string) {
        this.rootPath = rootPath;
    }

    async onApplicationReady(evt: ApplicationReadyEvent) {
        const ssoModule = evt.modules.find((m) => m.id === SSO_MODULE_ID) as SSOModule | undefined;
        if (!ssoModule) {
            throw new Error("SSOModule not found!");
        }
        this.ssoStore = ssoModule.vuexModule;
        //
        const urlParams = new URL(window.location.href).searchParams;
        const businessId = urlParams.get("businessId");
        if (businessId && !!businessId.trim())
            this.vuexModule.lockedBusinessId = businessId;
        if (urlParams.has("cropPlanTypeCode"))
            this.vuexModule.lockedCropPlanTypeCode = urlParams.get("cropPlanTypeCode");
    }

    async beforeEnterAnyRoutes(http: HTTPClient) {
        if (this.apiCreated) {
            return;
        }

        const notAccessibleErrorCodes = [
            "CROP_PLAN_NOT_ACCESSIBLE_EXCEPTION",
            "CROP_PLAN_NOT_WRITEABLE_EXCEPTION",
            "CROP_PLAN_NOT_CREATEABLE_EXCEPTION",
            "SYNC_IN_PROGRESS_EXCEPTION"
        ];
        http.addErrorHandler({
            onResponseError: (err, response: ResponseWithErrorCode | undefined) => {
                if (response && response.data?.errorCode) {
                    if (response.status === 409 && response.data.errorCode === "LOCK_EXCEPTION") {
                        this.vuexModule.showLockErrorModal = true;
                    } else if (
                        notAccessibleErrorCodes.includes(response.data.errorCode) 
                        || notAccessibleErrorCodes.find(c => response.data.errorCode.startsWith(c + "-"))
                    ) {
                        this.vuexModule.showCropPlanNotAccessibleModal = true;
                        this.vuexModule.showCropPlanNotAccessibleModalMessage = response.data.errorCode.toLowerCase();
                    }
                }
            },
        });

        this.apiCreated = true;

        const PlotApi = (await import("./api/PlotApi")).default;
        this.plApi = new PlotApi(http, this.rootPath);

        const BusinessApi = (await import("./api/BusinessApi")).default;
        this.busApi = new BusinessApi(http, this.rootPath, this.ssoStore);

        const DeclarationApi = (await import("./api/DeclarationApi")).default;
        this.declApi = new DeclarationApi(http, this.rootPath);

        const CouncilApi = (await import("./api/CouncilApi")).default;
        this.councApi = new CouncilApi(http, this.rootPath);

        const CropPlanApi = (await import("./api/CropPlanApi")).default;
        this.cpApi = new CropPlanApi(http, this.rootPath);

        const LayerApi = (await import("./api/LayerApi")).default;
        this.lyrApi = new LayerApi(http, this.rootPath);

        const VersionApi = (await import("./api/VersionApi")).default;
        this.verApi = new VersionApi(http, this.rootPath);

        const PermanentCropFormApi = (await import("./api/PermanentCropFormApi")).default;
        this.pcfApi = new PermanentCropFormApi(http, this.rootPath);

        const CadastralParcelApi = (await import("./api/CadastralParcelApi")).default;
        this.cadparcelApi = new CadastralParcelApi(http, this.rootPath);

        const LandUseApi = (await import("./api/LandUseApi")).default;
        this.luApi = new LandUseApi(http, this.rootPath);
    }

    public get plotApi() {
        return this.plApi;
    }

    public get businessApi() {
        return this.busApi;
    }

    public get declarationApi() {
        return this.declApi;
    }

    public get councilApi() {
        return this.councApi;
    }

    public get cropPlanApi() {
        return this.cpApi;
    }

    public get layerApi() {
        return this.lyrApi;
    }

    public get versionApi() {
        return this.verApi;
    }

    public get permanentCropFormApi() {
        return this.pcfApi;
    }

    public get cadastralParcelApi() {
        return this.cadparcelApi;
    }

    public get landUseApi() {
        return this.luApi;
    }
}
