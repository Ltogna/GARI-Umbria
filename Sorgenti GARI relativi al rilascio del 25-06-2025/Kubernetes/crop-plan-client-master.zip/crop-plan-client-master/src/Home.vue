<template>
    <div>
        <!-- hideMenu -->
        <nav-bar :style="{ 'z-index': !showNavBar ? -1000 : '' }" hideMenu>
            <template #navbar-logo>
                <abc-button v-if="backUrl" @click="navigateOnBackUrl" is-icon>
                    <em class="abc-icon abc-icon-arrow-left" style="margin-top: 3.5px; margin-bottom: 3.5px" />
                </abc-button>
            </template>

            <!-- <template #sidemenu-icon>
                <sidebar-menu-button :showSidebar="showSidebar" />
            </template>
            <template #sidemenu>
                <sidebar-menu @close="showSidebar = false" />
            </template>
            <template #secondary-navbar-left>
                <topbar-menu />
            </template>
            <template #navbar-logo>
                <div class="flex items-center justify-center h-full cursor-pointer space-x-2">
                    <img style="max-height: 36px" src="./assets/logo_abaco.png" />
                </div>
            </template> -->
            <template #navbar-filters>
                <div
                    v-if="flBulkDeclarationEditVisible"
                    class="abc-nav-bar-item w-ful border-t"
                    @click="showBulkDeclarationEdit = true"
                >
                    <div class="flex flex-grow">
                        <div class="abc-nav-bar-item-icon">
                            <em class="fal fa-pen-to-square mr-1"></em>
                        </div>
                        <div class="abc-nav-bar-item-text">
                            <p>{{ i18n("bulk-declaration-fields-edit") }}</p>
                        </div>
                    </div>
                </div>

                <component v-for="f in filters" :key="f" :is="f" />

                <!-- <button
                    @click="toggleDarkMode()"
                    class="cpc-night-mode-button ml-3"
                    type="button"
                    :title="!darkMode ? 'Enable dark mode' : 'Disable dark mode'"
                >
                    <svg
                        v-if="darkMode"
                        xmlns="http://www.w3.org/2000/svg"
                        class="svg-image filled"
                        viewBox="0 0 20 20"
                    >
                        <path
                            fill-rule="evenodd"
                            d="M10 2a1 1 0 011 1v1a1 1 0 11-2 0V3a1 1 0 011-1zm4 8a4 4 0 11-8 0 4 4 0 018 0zm-.464 4.95l.707.707a1 1 0 001.414-1.414l-.707-.707a1 1 0 00-1.414 1.414zm2.12-10.607a1 1 0 010 1.414l-.706.707a1 1 0 11-1.414-1.414l.707-.707a1 1 0 011.414 0zM17 11a1 1 0 100-2h-1a1 1 0 100 2h1zm-7 4a1 1 0 011 1v1a1 1 0 11-2 0v-1a1 1 0 011-1zM5.05 6.464A1 1 0 106.465 5.05l-.708-.707a1 1 0 00-1.414 1.414l.707.707zm1.414 8.486l-.707.707a1 1 0 01-1.414-1.414l.707-.707a1 1 0 011.414 1.414zM4 11a1 1 0 100-2H3a1 1 0 000 2h1z"
                            clip-rule="evenodd"
                        />
                    </svg>
                    <svg v-else xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" class="svg-image stroked filled">
                        <path
                            stroke-linecap="round"
                            stroke-linejoin="round"
                            stroke-width="2"
                            d="M20.354 15.354A9 9 0 018.646 3.646 9.003 9.003 0 0012 21a9.003 9.003 0 008.354-5.646z"
                        ></path>
                    </svg>
                </button> -->
            </template>
            <!-- <template #navbar-items>
                <message-nav-bar-item v-if="!hasSecondaryNavbar"/>
                <user-nav-bar-item v-if="!hasSecondaryNavbar" />
            </template> -->
        </nav-bar>
        <popup-selector v-if="!showNavBar" :url="url" />
        <navigation :class="{ standalone: !showNavBar }">
            <router-view />
        </navigation>
    </div>
</template>

<script lang="ts">
import { Vue, Component, Inject } from "vue-property-decorator";
import PopupSelector from "./modules/single-crop-plan/components/private/popupSelector.vue";
import { FromStore } from "@abaco/web-common/src/app";
import { MODULE_ID } from "./modules/single-crop-plan";
import { TranslateResult } from "vue-i18n";
import { Business } from "./modules/single-crop-plan/models/Business";
import { Configuration, CropPlan } from "./modules/single-crop-plan/models/CropPlan";

@Component({
    components: {
        PopupSelector,
    },
})
export default class Home extends Vue {
    @Inject() i18n!: (key: string, values?: unknown) => TranslateResult;

    @FromStore(MODULE_ID) showNavBar!: boolean;
    @FromStore(MODULE_ID) showBulkDeclarationEdit!: boolean;
    @FromStore(MODULE_ID) business!: Business | null;
    @FromStore(MODULE_ID) curCropPlan!: CropPlan | null;
    @FromStore(MODULE_ID) curPointInTime!: Date | null;
    @FromStore(MODULE_ID) curConfiguration!: Configuration | null;

    // showSidebar = false;
    private hasSecondaryNavbar = false;
    // private darkMode = false;
    private url = new URL(window.location.href);
    private isBackButtonVisible = false;

    get filters(): string[] {
        const meta = this.$route.meta;
        return meta?.navbarItems || [];
    }
    private get flBulkDeclarationEditVisible() {
        return (
            this.curConfiguration?.ENABLE_BULK_DECLARATIONS_FIELDS_EDIT === "TRUE" &&
            this.business?.businessId &&
            this.curCropPlan?.cropPlanId &&
            this.curPointInTime &&
            !this.showBulkDeclarationEdit && 
            !this.curCropPlan.readOnly
        );
    }

    private get backUrl(): string | null {
        const urlParams = new URLSearchParams(window.location.search);
        const backUrl = urlParams.get("backUrl");
        if(!backUrl) return null;
        const url = new URL(backUrl, window.location.origin);
        if (url.origin !== window.location.origin) {
            console.error("BackUrl's origin not valid: ", url.href);
            return null;
        }
        return backUrl;
    }

    private navigateOnBackUrl() {
        if (this.backUrl) location.assign(decodeURIComponent(this.backUrl));
    }

    /* private toggleDarkMode() {
        if (this.darkMode) {
            this.darkMode = false;
        } else {
            this.darkMode = true;
        }
        localStorage.setItem("darkMode", JSON.stringify(this.darkMode));
        this.updateDarkMode();
    }
    private checkDarkMode() {
        return false;
    }
    private updateDarkMode() {
        if (this.checkDarkMode() || this.darkMode) {
            this.darkMode = true;
            document.documentElement.setAttribute("data-theme", "dark");
        } else {
            document.documentElement.setAttribute("data-theme", "light");
        }
    }
    private initDarkMode() {
        //check local storage
        if (localStorage.getItem("darkMode")) {
            const cur = JSON.parse(localStorage.getItem("darkMode")!);
            this.darkMode = cur;
        }
        this.updateDarkMode();
    } */
}
</script>

<style lang="scss">
.standalone .frk-modal-view {
    margin-top: 0px !important;
}
</style>
<style scoped lang="scss">
.cpc-night-mode-button {
    @apply transition duration-100 ease-in-out flex items-center justify-center py-1 px-2 rounded text-primary-500;
    outline: none !important;
    height: 34px;
    // background: rgba(255,255,255,0.35);
    [data-theme="dark"] & {
        @apply text-primary-200;
    }
}
.cpc-night-mode-button:hover {
    background: rgba(255, 255, 255, 0.35);
}
.cpc-night-mode-button svg {
    height: 18px;
    width: 18px;
}
</style>
