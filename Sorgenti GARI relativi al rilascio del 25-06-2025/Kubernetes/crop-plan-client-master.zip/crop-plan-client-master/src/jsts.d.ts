declare module 'jsts/org/locationtech/jts/geom/PrecisionModel' {
    export default class PrecisionModel {
        static FIXED: string;
        static FLOATING: string;
        static FLOATING_SINGLE: string;

        /**
         *
         * @param modelType
         */
        constructor(modelType?: number | string);
    }
}

declare module 'jsts/org/locationtech/jts/geom/Coordinate' {
    /**
     * A lightweight class used to store coordinates on the 2-dimensional
     * Cartesian plane. It is distinct from {@link Point}, which is a subclass of
     * {@link Geometry}. Unlike objects of type {@link Point} (which contain
     * additional information such as an envelope, a precision model, and spatial
     * reference system information), a <code>Coordinate</code> only contains
     * coordinate values and accessor methods.
     */
    export default class Coordinate {
        /**
         * @constructor
         */
        constructor(x: number, y: number);

        /**
         * @constructor
         */
        constructor(c: Coordinate);

        /**
         * Gets the x value.
         */
        getX(): number;

        /**
         * Gets the y value.
         */
        getY(): number;

        /**
         * Gets the z value.
         */
        getZ(): number;

        /**
         * Sets the x value.
         */
        setX(): number;

        /**
         * Sets the y value.
         */
        setY(): number;

        /**
         * Sets the z value.
         */
        setZ(): number;

        /**
         * Sets this <code>Coordinate</code>s (x,y,z) values to that of
         * <code>other</code>.
         *
         * @param {Coordinate}
         *          other the <code>Coordinate</code> to copy.
         */
        setCoordinate(other: Coordinate): void;

        /**
         * Clones this instance.
         *
         * @return {Coordinate} A point instance cloned from this.
         */
        clone(): Coordinate;

        /**
         * Computes the 2-dimensional Euclidean distance to another location. The
         * Z-ordinate is ignored.
         *
         * @param {Coordinate}
         *          p a point.
         * @return {number} the 2-dimensional Euclidean distance between the
         *         locations.
         */
        distance(p: Coordinate): number;

        /**
         * Returns whether the planar projections of the two <code>Coordinate</code>s
         * are equal.
         *
         * @return {boolean} <code>true</code> if the x- and y-coordinates are
         *         equal; the z-coordinates do not have to be equal.
         */
        equals2D(): boolean;

        /**
         * Returns <code>true</code> if <code>other</code> has the same values for
         * the x and y ordinates. Since Coordinates are 2.5D, this routine ignores the
         * z value when making the comparison.
         *
         * @param {Coordinate}
         *          other a <code>Coordinate</code> with which to do the comparison.
         * @return {boolean} <code>true</code> if <code>other</code> is a
         *         <code>Coordinate</code> with the same values for the x and y
         *         ordinates.
         */
        equals(other: Coordinate): boolean;

        /**
         * Compares this {@link Coordinate} with the specified {@link Coordinate} for
         * order. This method ignores the z value when making the comparison. Returns:
         * <UL>
         * <LI> -1 : this.x < other.x || ((this.x == other.x) && (this.y < other.y))
         * <LI> 0 : this.x == other.x && this.y = other.y
         * <LI> 1 : this.x > other.x || ((this.x == other.x) && (this.y > other.y))
         *
         * </UL>
         * Note: This method assumes that ordinate values are valid numbers. NaN
         * values are not handled correctly.
         *
         * @param {Coordinate}
         *          other the <code>Coordinate</code> with which this
         *          <code>Coordinate</code> is being compared.
         * @return {number} -1, zero, or 1 as explained above.
         */
        compareTo(other: Coordinate): number;

        copy(): Coordinate;
        toString(): string;
        hashCode(): number;
    }
}

declare module 'jsts/org/locationtech/jts/geom/Envelope' {
    import Coordinate from "jsts/org/locationtech/jts/geom/Coordinate";
    /**
        * Defines a rectangular region of the 2D coordinate plane. It is often used to
        * represent the bounding box of a {@link Geometry}, e.g. the minimum and
        * maximum x and y values of the {@link Coordinate}s.
        * <p>
        * Note that Envelopes support infinite or half-infinite regions, by using the
        * values of <code>Double.POSITIVE_INFINITY</code> and
        * <code>Double.NEGATIVE_INFINITY</code>.
        * <p>
        * When Envelope objects are created or initialized, the supplies extent values
        * are automatically sorted into the correct order.
        */
    export default class Envelope {
        static intersects(): boolean;

        /**
         * Creates an <code>Envelope</code> for a region defined by maximum and
         * minimum values.
         *
         * @param {number} x1 the first x-value.
         * @param {number} x2 the second x-value.
         * @param {number} y1 the first y-value.
         * @param {number} y2 the second y-value.
         */
        constructor(x1: number, x2: number, y1: number, y2: number);

        /**
         * Initialize an <code>Envelope</code> to a region defined by two Coordinates.
         *
         * @param {jsts.geom.Coordinate} p1 the first Coordinate.
         * @param {jsts.geom.Coordinate} p2 the second Coordinate.
         */
        constructor(p1: Coordinate, p2: Coordinate);

        /**
         * Initialize an <code>Envelope</code> to a region defined by a single
         * Coordinate.
         *
         * @param {jsts.geom.Coordinate} p the Coordinate.
         */
        constructor(p: Coordinate);

        /**
         * Initialize an <code>Envelope</code> from an existing Envelope.
         *
         * @param {jsts.geom.Envelope} env the Envelope to initialize from.
         */
        constructor(env: Envelope);

        /**
         * Makes this <code>Envelope</code> a "null" envelope, that is, the envelope
         * of the empty geometry.
         */
        setToNull(): void;

        /**
         * Returns <code>true</code> if this <code>Envelope</code> is a "null"
         * envelope.
         *
         * @return {boolean} <code>true</code> if this <code>Envelope</code> is
         *         uninitialized or is the envelope of the empty geometry.
         */
        isNull(): boolean;

        /**
         * Returns the difference between the maximum and minimum y values.
         *
         * @return {number} max y - min y, or 0 if this is a null <code>Envelope.</code>
         */
        getHeight(): number;

        /**
         * Returns the difference between the maximum and minimum x values.
         *
         * @return {number} max x - min x, or 0 if this is a null <code>Envelope.</code>
         */
        getWidth(): number;

        /**
         * Returns the <code>Envelope</code>s minimum x-value. min x > max x
         * indicates that this is a null <code>Envelope</code>.
         *
         * @return {number} the minimum x-coordinate.
         */
        getMinX(): number;

        /**
         * Returns the <code>Envelope</code>s maximum x-value. min x > max x
         * indicates that this is a null <code>Envelope</code>.
         *
         * @return {number} the maximum x-coordinate.
         */
        getMaxX(): number;

        /**
         * Returns the <code>Envelope</code>s minimum y-value. min y > max y
         * indicates that this is a null <code>Envelope</code>.
         *
         * @return {number} the minimum y-coordinate.
         */
        getMinY(): number;

        /**
         * Returns the <code>Envelope</code>s maximum y-value. min y > max y
         * indicates that this is a null <code>Envelope</code>.
         *
         * @return {number} the maximum y-coordinate.
         */
        getMaxY(): number;

        /**
         * Gets the area of this envelope.
         *
         * @return {number} the area of the envelope, 0.0 if the envelope is null.
         */
        getArea(): number;

        expandToInclude(): void;

        expandBy(): void;

        /**
         * Translates this envelope by given amounts in the X and Y direction.
         *
         * @param {number}
         *          transX the amount to translate along the X axis.
         * @param {number}
         *          transY the amount to translate along the Y axis.
         */
        translate(transX: number, transY: number): void;

        /**
         * Computes the coordinate of the centre of this envelope (as long as it is
         * non-null
         *
         * @return {jsts.geom.Coordinate} the centre coordinate of this envelope <code>null</code>
         *         if the envelope is null.
         */
        centre(): Coordinate;

        /**
         * Computes the intersection of two {@link Envelopes}
         *
         * @param {jsts.geom.Envelope}
         *          env the envelope to intersect with.
         * @return {jsts.geom.Envelope} a new Envelope representing the intersection of
         *         the envelopes (this will be the null envelope if either argument is
         *         null, or they do not intersect.
         */
        intersection(env: Envelope): Envelope;

        intersects(): boolean;

        contains(): boolean;

        covers(x: number, y: number): boolean;


        /**
         * Computes the distance between this and another <code>Envelope</code>.
         *
         * @param {jsts.geom.Envelope}
         *          env The <code>Envelope</code> to test this <code>Envelope</code>
         *          against.
         * @return {number} The distance between overlapping Envelopes is 0. Otherwise,
         *         the distance is the Euclidean distance between the closest points.
         */
        distance(env: Envelope): number;

        /**
         * @param {jsts.geom.Envelope}
         *          other the <code>Envelope</code> to check against.
         * @return {boolean} true if envelopes are equal.
         */
        equals(other: Envelope): boolean;

        /**
         * @return {string} String representation of this <code>Envelope.</code>
         */
        toString(): string;
    }

}

declare module 'jsts/org/locationtech/jts/geom/Geometry' {
    import PrecisionModel from 'jsts/org/locationtech/jts/geom/PrecisionModel'
    import Envelope from 'jsts/org/locationtech/jts/geom/Envelope';
    import Coordinate from 'jsts/org/locationtech/jts/geom/Coordinate';

    export default class Geometry {
        /**
             * Creates a new <tt>Geometry</tt> via the specified GeometryFactory.
             */
        constructor(factory?: any);

        /**
         * Gets the factory which contains the context in which this geometry was created.
         *
         * @return {jsts.geom.GeometryFactory} the factory for this geometry.
         */
        getFactory(): any;

        /**
         *Returns the number of {@link Geometry}s in a {@link GeometryCollection}
         * (or 1, if the geometry is not a collection).
         *
         * @return {number} the number of geometries contained in this geometry.
         */
        getNumGeometries(): number;

        /**
         * Returns an element {@link Geometry} from a {@link GeometryCollection} (or
         * <code>this</code>, if the geometry is not a collection).
         *
         * @param {number} n The index of the geometry element.
         *
         * @return {Geometry} the n'th geometry contained in this geometry.
         */
        getGeometryN(n: number): Geometry;

        /**
         * Returns the <code>PrecisionModel</code> used by the <code>Geometry</code>.
         *
         * @return {PrecisionModel} the specification of the grid of allowable points, for this
         * <code>Geometry</code> and all other <code>Geometry</code>s.
         */
        getPrecisionModel(): PrecisionModel;

        /**
         * Returns whether or not the set of points in this <code>Geometry</code> is
         * empty.
         *
         * @return {boolean} <code>true</code> if this <code>Geometry</code> equals
         *         the empty geometry.
         */
        isEmpty(): boolean;

        /**
         * Returns the minimum distance between this <code>Geometry</code> and the
         * <code>Geometry</code> g
         *
         * @param {Geometry}
         *          g the <code>Geometry</code> from which to compute the distance.
         * @return {number} the distance between the geometries. 0 if either input
         *         geometry is empty.
         * @throws IllegalArgumentException
         *           if g is null
         */
        distance(g: Geometry): number;

        isRectangle(): boolean;

        /**
         * Returns the area of this <code>Geometry</code>. Areal Geometries have a
         * non-zero area. They override this function to compute the area. Others return
         * 0.0
         *
         * @return the area of the Geometry.
         */
        getArea(): number;

        /**
         * Returns the length of this <code>Geometry</code>. Linear geometries return
         * their length. Areal geometries return their perimeter. They override this
         * function to compute the area. Others return 0.0
         *
         * @return the length of the Geometry.
         */
        getLength(): number;

        /**
         * Returns this <code>Geometry</code>s bounding box. If this
         * <code>Geometry</code> is the empty geometry, returns an empty
         * <code>Point</code>. If the <code>Geometry</code> is a point, returns a
         * non-empty <code>Point</code>. Otherwise, returns a <code>Polygon</code>
         * whose points are (minx, miny), (maxx, miny), (maxx, maxy), (minx, maxy),
         * (minx, miny).
         *
         * @return {Geometry} an empty <code>Point</code> (for empty
         *         <code>Geometry</code>s), a <code>Point</code> (for
         *         <code>Point</code>s) or a <code>Polygon</code> (in all other
         *         cases).
         */
        getEnvelope(): Geometry;

        /**
         * Returns the minimum and maximum x and y values in this <code>Geometry</code>,
         * or a null <code>Envelope</code> if this <code>Geometry</code> is empty.
         *
         * @return {Envelope} this <code>Geometry</code>s bounding box; if the
         *         <code>Geometry</code> is empty, <code>Envelope#isNull</code> will
         *         return <code>true.</code>
         */
        getEnvelopeInternal(): Envelope;

        /**
         * Tests whether this geometry is structurally and numerically equal to a given
         * <tt>Object</tt>. If the argument <tt>Object</tt> is not a
         * <tt>Geometry</tt>, the result is <tt>false</tt>. Otherwise, the result
         * is computed using {@link #equalsExact(Geometry)}.
         * <p>
         * This method is provided to fulfill the Java contract for value-based object
         * equality. In conjunction with {@link #hashCode()} it provides semantics which
         * are most useful for using <tt>Geometry</tt>s as keys and values in Java
         * collections.
         * <p>
         * Note that to produce the expected result the input geometries should be in
         * normal form. It is the caller's responsibility to perform this where required
         * (using {@link Geometry#norm() or {@link #normalize()} as appropriate).
         *
         * @param {Object}
         *          o the Object to compare.
         * @return {boolean} true if this geometry is exactly equal to the argument.
         *
         * @see #equalsExact(Geometry)
         * @see #hashCode()
         * @see #norm()
         * @see #normalize()
         */
        equals(o: Record<string, any>): boolean;

        /**
         * Returns true if the two <code>Geometry</code>s are exactly equal, up to a
         * specified distance tolerance. Two Geometries are exactly equal within a
         * distance tolerance if and only if:
         * <ul>
         * <li>they have the same class
         * <li>they have the same values for their vertices, within the given tolerance
         * distance, in exactly the same order.
         * </ul>
         * If this and the other <code>Geometry</code>s are composites and any
         * children are not <code>Geometry</code>s, returns <code>false</code>.
         *
         * @param {Geometry}
         *          other the <code>Geometry</code> with which to compare this
         *          <code>Geometry.</code>
         * @param {number}
         *          tolerance distance at or below which two <code>Coordinate</code>s
         *          are considered equal.
         * @return {boolean}
         */
        equalsExact(other: Geometry, tolerance: number): boolean;

        /**
         * Tests whether two geometries are exactly equal in their normalized forms.
         * This is a convenience method which creates normalized versions of both
         * geometries before computing {@link #equalsExact(Geometry)}. This method is
         * relatively expensive to compute. For maximum performance, the client should
         * instead perform normalization itself at an appropriate point during
         * execution.
         *
         * @param {Geometry}
         *          g a Geometry.
         * @return {boolean} true if the input geometries are exactly equal in their
         *         normalized form.
         */
        equalsNorm(g: Geometry): boolean;

        /**
         * Performs an operation with or on this <code>Geometry</code> and its
         * subelement <code>Geometry</code>s (if any). Only GeometryCollections and
         * subclasses have subelement Geometry's.
         *
         * @param filter
         *          the filter to apply to this <code>Geometry</code> (and its
         *          children, if it is a <code>GeometryCollection</code>).
         */
        apply(filter: any): void;

        /**
         * Converts this <code>Geometry</code> to <strong>normal form</strong> (or <strong>
         * canonical form</strong> ). Normal form is a unique representation for
         * <code>Geometry</code> s. It can be used to test whether two
         * <code>Geometry</code>s are equal in a way that is independent of the
         * ordering of the coordinates within them. Normal form equality is a stronger
         * condition than topological equality, but weaker than pointwise equality. The
         * definitions for normal form use the standard lexicographical ordering for
         * coordinates. "Sorted in order of coordinates" means the obvious extension of
         * this ordering to sequences of coordinates.
         */
        normalize(): void;

        /**
         * Creates a new Geometry which is a normalized copy of this Geometry.
         *
         * @return a normalized copy of this geometry.
         * @see #normalize()
         */
        norm(): Geometry;

        /**
         * Returns whether this <code>Geometry</code> is greater than, equal to, or
         * less than another <code>Geometry</code>.
         * <P>
         *
         * If their classes are different, they are compared using the following
         * ordering:
         * <UL>
         * <LI> Point (lowest)
         * <LI> MultiPoint
         * <LI> LineString
         * <LI> LinearRing
         * <LI> MultiLineString
         * <LI> Polygon
         * <LI> MultiPolygon
         * <LI> GeometryCollection (highest)
         * </UL>
         * If the two <code>Geometry</code>s have the same class, their first
         * elements are compared. If those are the same, the second elements are
         * compared, etc.
         *
         * @param {Geometry}
         *          other a <code>Geometry</code> with which to compare this
         *          <code>Geometry.</code>
         * @return {number} a positive number, 0, or a negative number, depending on
         *         whether this object is greater than, equal to, or less than
         *         <code>o</code>, as defined in "Normal Form For Geometry" in the
         *         JTS Technical Specifications.
         */
        compareTo(o: Geometry): number;

        /**
         * Returns whether the two <code>Geometry</code>s are equal, from the point
         * of view of the <code>equalsExact</code> method. Called by
         * <code>equalsExact</code> . In general, two <code>Geometry</code> classes
         * are considered to be "equivalent" only if they are the same class. An
         * exception is <code>LineString</code> , which is considered to be equivalent
         * to its subclasses.
         *
         * @param {Geometry}
         *          other the <code>Geometry</code> with which to compare this
         *          <code>Geometry</code> for equality.
         * @return {boolean} <code>true</code> if the classes of the two
         *         <code>Geometry</code> s are considered to be equal by the
         *         <code>equalsExact</code> method.
         */
        isEquivalentClass(other: Geometry): boolean;

        /**
         * Throws an exception if <code>g</code>'s class is
         * <code>GeometryCollection</code> . (Its subclasses do not trigger an
         * exception).
         *
         * @param {Geometry}
         *          g the <code>Geometry</code> to check.
         * @throws Error
         *           if <code>g</code> is a <code>GeometryCollection</code> but not
         *           one of its subclasses
         */
        checkNotGeometryCollection(g: Geometry): void;

        /**
         *
         * @return {boolean} true if this is a GeometryCollection.
         */
        isGeometryCollection(): boolean;

        /**
         * Returns the minimum and maximum x and y values in this <code>Geometry</code>,
         * or a null <code>Envelope</code> if this <code>Geometry</code> is empty.
         * Unlike <code>getEnvelopeInternal</code>, this method calculates the
         * <code>Envelope</code> each time it is called;
         * <code>getEnvelopeInternal</code> caches the result of this method.
         *
         * @return {Envelope} this <code>Geometry</code>s bounding box; if the
         *         <code>Geometry</code> is empty, <code>Envelope#isNull</code> will
         *         return <code>true.</code>
         */
        computeEnvelopeInternal(): Envelope;

        /**
         * Returns whether this <code>Geometry</code> is greater than, equal to, or
         * less than another <code>Geometry</code> having the same class.
         *
         * @param o
         *          a <code>Geometry</code> having the same class as this
         *          <code>Geometry.</code>
         * @return a positive number, 0, or a negative number, depending on whether this
         *         object is greater than, equal to, or less than <code>o</code>, as
         *         defined in "Normal Form For Geometry" in the JTS Technical
         *         Specifications.
         */
        compareToSameClass(o: Geometry): number;

        /**
         * Returns the first non-zero result of <code>compareTo</code> encountered as
         * the two <code>Collection</code>s are iterated over. If, by the time one of
         * the iterations is complete, no non-zero result has been encountered, returns
         * 0 if the other iteration is also complete. If <code>b</code> completes
         * before <code>a</code>, a positive number is returned; if a before b, a
         * negative number.
         *
         * @param {Array}
         *          a a <code>Collection</code> of <code>Comparable</code>s.
         * @param {Array}
         *          b a <code>Collection</code> of <code>Comparable</code>s.
         * @return {number} the first non-zero <code>compareTo</code> result, if any;
         *         otherwise, zero.
         */
        compare(a: Array<any>, b: Array<any>): number;

        /**
         * @param {jsts.geom.Coordinate}
         *          a first Coordinate to compare.
         * @param {jsts.geom.Coordinate}
         *          b second Coordinate to compare.
         * @param {number}
         *          tolerance tolerance when comparing.
         * @return {boolean} true if equal.
         */
        equal(a: Coordinate, b: Coordinate, tolerance: number): boolean;

    }
}

declare module "jsts/org/locationtech/jts/geom/GeometryFactory" {
    import Coordinate from "jsts/org/locationtech/jts/geom/Coordinate";
    import PrecisionModel from "jsts/org/locationtech/jts/geom/PrecisionModel";

    import {LinearRing, LineString, Point, Polygon} from "ol/geom";
    /**
     * Supplies a set of utility methods for building Geometry objects from lists
     * of Coordinates.
     *
     * Note that the factory constructor methods do <strong>not</strong> change the input
     * coordinates in any way.
     *
     * In particular, they are not rounded to the supplied <tt>PrecisionModel</tt>.
     * It is assumed that input Coordinates meet the given precision.
     */
    export default class GeometryFactory {

        /**
         * Constructs a GeometryFactory that generates Geometries having a floating PrecisionModel and a spatial-reference ID of 0.
         */
        constructor(precisionModel?: PrecisionModel);


        /**
         * Creates a LineString using the given Coordinates; a null or empty array will
         * create an empty LineString. Consecutive points must not be equal.
         *
         * @param {Coordinate[]}
         *          coordinates an array without null elements, or an empty array, or
         *          null.
         * @return {LineString} A new LineString.
         */
        createLineString(coordinates: Array<Coordinate>): LineString;
        /**
         * Creates a Point using the given Coordinate; a null Coordinate will create an
         * empty Geometry.
         *
         * @param {Coordinate}
         *          coordinate Coordinate to base this Point on.
         * @return {Point} A new Point.
         */
        createPoint(coordinates: Coordinate): Point;
        /**
        * Creates a LinearRing using the given Coordinates; a null or empty array
        * will create an empty LinearRing. Consecutive points must not be equal.
        *
        * @param {Coordinate[]}
        *          coordinates an array without null elements, or an empty array,
        * or null.
        * @return {LineString} A new LinearRing.
        */
        createLinearRing(coordinates: Array<Coordinate>): LinearRing;
        /**
        * Creates a Polygon using the given LinearRing.
        *
        * @param {LinearRing} A LinearRing constructed by coordinates.
        * @return {Polygon} A new Polygon.
        */
        createPolygon(shell: LinearRing, holes: Array<LinearRing>): Polygon;            

    }
}


declare module 'jsts/org/locationtech/jts/io/WKTParser' {
    import Geometry from "jsts/org/locationtech/jts/geom/Geometry"
    import GeometryFactory from "jsts/org/locationtech/jts/geom/GeometryFactory";
    export default class WKTParser {
        constructor(geometryFactory?: GeometryFactory);
        read(wkt: string): Geometry;
        write(geometry: Geometry): string;
    }
}

declare module 'jsts/org/locationtech/jts/io/OL3Parser' {
    import { Geometry as OlGeom } from "ol/geom";
    import Geometry from "jsts/org/locationtech/jts/geom/Geometry"
    import GeometryFactory from "jsts/org/locationtech/jts/geom/GeometryFactory";
    export default class OL3Parser {
        constructor(geometryFactory?: GeometryFactory);
        read(geometry: OlGeom): Geometry;
        write(geometry: Geometry): OlGeom;
        inject(Point: any, LineString: any, LinearRing: any, Polygon: any, MultiPoint: any, MultiLineString: any, MultiPolygon: any, GeometryCollection: any): void
    }
}

declare module 'jsts/org/locationtech/jts/operation/overlay/OverlayOp' {
    import Geometry from "jsts/org/locationtech/jts/geom/Geometry"
    export default class OverlayOp {
        static intersection(geom: Geometry, other: Geometry): Geometry
        static difference(geom: Geometry, other: Geometry): Geometry
        static union(geom: Geometry, other: Geometry): Geometry
    }
}

declare module 'jsts/org/locationtech/jts/operation/IsSimpleOp' {
    import Geometry from "jsts/org/locationtech/jts/geom/Geometry"
    export default class IsSimpleOp {
        static isSimple(geom: Geometry): boolean
    }
}

declare module 'jsts/org/locationtech/jts/operation/distance/DistanceOp' {
    import Geometry from "jsts/org/locationtech/jts/geom/Geometry";
    export default class DistanceOp {
        static distance(geom: Geometry, other: Geometry): number;
    }
}

declare module 'jsts/org/locationtech/jts/operation/relate/RelateOp' {
    import Geometry from "jsts/org/locationtech/jts/geom/Geometry"
    export default class RelateOp {
        static contains(g1: Geometry, g2: Geometry): boolean
    }
}