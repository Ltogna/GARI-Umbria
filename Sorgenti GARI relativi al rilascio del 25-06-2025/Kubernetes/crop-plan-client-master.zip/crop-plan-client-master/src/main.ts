import Vue from "vue";
import App from "./App.vue";
import Home from "./Home.vue";
import WebComponents, { setI18N } from "@abaco/web-components/src/components";
import TilesFramework from "@abaco/tiles-framework/src/components";
import { Application, ToastOptions } from "@abaco/web-common/src/app";
import { HTTPClient } from "@abaco/web-common/src/HTTP";
import { AxiosError } from "axios";

import SsoWebModule from "@abaco/sso-web-module/src/abaco-module";
import SingleCropPlanModule from "./modules/single-crop-plan/";
import IacsMapModule from "@abaco/iacs-map-module/src/modules/map-module";
import toast from "@abaco/web-common/src/app/Toasted";
import { FORCED_CONTEXT } from "./constants";

Vue.use(TilesFramework);
Vue.use(WebComponents);

Vue.config.productionTip = false;
let config: any = null;

let rootPath = "";

export let isSCP = false;
export let isGCP = false;
export let tenant = '';

async function getConfig(): Promise<any> {
    const http = new HTTPClient({forcedContext: FORCED_CONTEXT});
    try {
        config = (await http.get(`${process.env.BASE_URL || "/crop-plan-client/"}general-config.json`)).data;
    } catch (error) {
        config = {
            mode: "standard",
        };
        console.warn("no config found");
    }

    const url = new URL(window.location.href);
    let tenantUrl = '';
    if (url.searchParams.has("tenant")) {
        tenantUrl = url.searchParams.get("tenant")!;
    }
    tenant = tenantUrl || config.tenant;
    rootPath = `/crop-plan-api/${tenant}/api-priv`;

    return config;
}

const doAddCss = (url: string) => {
    const link = document.createElement("link");
    link.rel = "stylesheet";
    link.href = url;
    link.id = "theme";
    document.head.appendChild(link);
};

function startApp(config: any) {
    const http = new HTTPClient({useApiGw: config.useApiGw, forcedContext: FORCED_CONTEXT});
    const MODE = config.mode;
    isSCP = MODE === "iacs_malta";
    isGCP = MODE === "avepa" ||  MODE === "fvg";

    const abacoApp = new Application({
        http,
        rootComponent: Home,
        i18nAPI: config.i18nApi || undefined,
        i18nVariant: MODE != "iacs" ? { modules: [SingleCropPlanModule.MODULE_ID], variant: isGCP ? "gcp" :  MODE } : undefined,
        toastFunction: (message: string, options: ToastOptions, i18n) => {
            const axiosError = message as unknown as AxiosError<any, any>;
            if (axiosError && axiosError.response) {
                if (axiosError.response.status === 409 && axiosError.response.data.errorCode === "LOCK_EXCEPTION") {
                    console.error(axiosError);
                    return;
                } else if (typeof axiosError.response?.data?.errorCode == "string" && i18n) {
                    message = i18n(axiosError.response.data.errorCode.toLowerCase()).toString();
                }
            }
            toast(message, options);
        },
    });

    const url = new URL(window.location.href);
    if (url.searchParams.has("tenant")) {
        tenant = url.searchParams.get("tenant")!;
    }

    //DEVS4F abacoApp.add(new SsoWebModule((user) => {
    //MALTA-DEV abacoApp.add(new SsoWebModule({skipPrivacyChecks: true}, (user) => {
        
    abacoApp.add(
        new SsoWebModule(
            {
                skipPrivacyChecks: true,
                hidePasswordRecovery: true,
                environment: MODE,
                loginContext: config.loginContext,
                tenant: tenant,
                useApiGw: config.useApiGw || false
            },
            (user) => {
                setI18N({ locale: user.locale, dateFormat: user.dateFormat });
                abacoApp.setLanguage(user.locale);
            }
        )
    );

    abacoApp.add(new SingleCropPlanModule(rootPath));
    abacoApp.add(new IacsMapModule());

    abacoApp
        .start((h) => h(App))
        .then((vue) => vue.$mount("#app"))
        .catch((err) => {
            console.error(err);
            alert("An error has occurred");
        });
}

getConfig().then((config) => {
    doAddCss(`${process.env.BASE_URL || "/crop-plan-client/"}css/${config.mode}.css`);
    // Applica il tema verde solo in locale - commentare prima di committare
    // require(`../themes/${config.mode}.scss`);
    startApp(config);
});
