<template>
    <div class="text-base antialiased">
        <router-view />
    </div>
</template>
<script lang="ts">
import { FromStore } from "@abaco/web-common/src/app";
import { Vue, Component, Watch, Inject } from "vue-property-decorator";
import { CropPlan } from "./modules/single-crop-plan/models/CropPlan";
import { SetI18nVariantFunction } from "@abaco/web-common/src/app/index";
import { MODULE_ID } from "./modules/single-crop-plan";
import { TranslateResult } from "vue-i18n";
import { isGCP, isSCP } from "../src/main";
import { ALLOWED_ALIGN_TYPES } from "./shared/constants";

@Component
export default class App extends Vue {
    @Inject() setI18nVariant!: SetI18nVariantFunction;
    @Inject() i18n!: (key: string, values?: unknown) => TranslateResult;
    @FromStore(MODULE_ID) curCropPlan!: CropPlan | null;
    @FromStore(MODULE_ID) lockedCropPlanTypeCode!: string | null;

    private oldVariant: string | null = null;

    @Watch("lockedCropPlanTypeCode")
    @Watch("curCropPlan.cropPlanTypeCode")
    async onCropPlanTypeUpdate() {
        if (
            this.oldVariant === null ||
            (this.curCropPlan !== null ? this.oldVariant !== this.curCropPlan.cropPlanTypeCode : false) ||
            (this.lockedCropPlanTypeCode !== null ? this.oldVariant !== this.lockedCropPlanTypeCode : false)
        ) {
            if (this.lockedCropPlanTypeCode !== null && ALLOWED_ALIGN_TYPES.includes(this.lockedCropPlanTypeCode)) {
                await this.setI18nVariant({ variant: this.lockedCropPlanTypeCode.toLocaleLowerCase(), modules: [MODULE_ID] });
                this.oldVariant = this.lockedCropPlanTypeCode;
            } else if (this.curCropPlan !== null && ALLOWED_ALIGN_TYPES.includes(this.curCropPlan.cropPlanTypeCode)) {
                await this.setI18nVariant({ variant: this.curCropPlan.cropPlanTypeCode.toLocaleLowerCase(), modules: [MODULE_ID] });
                this.oldVariant = this.curCropPlan.cropPlanTypeCode;
            } else {
                await this.setI18nVariant(isSCP ? "iacs_malta" : isGCP ? "gcp" : null);
            }
            document.title = this.i18n("crop-plan-tab-title").toString();
        }
    }
}
</script>
