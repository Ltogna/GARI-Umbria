declare module "vue-grid-layout";
declare module "vue-fragment";
declare module "*.js";
declare module "v-mask/*";
declare module 'vue-tippy';

declare module "jsts/org/locationtech/jts/io/WKTReader" {
    import WKTParser from "jsts/org/locationtech/jts/geom/WKTParser";
    import GeometryFactory from "jsts/org/locationtech/jts/geom/GeometryFactory";
    export default class WKTReader {
        constructor(geometryFactory?: GeometryFactory);
        read(wkt: string): Geometry;
    }
}
