/* eslint-disable @typescript-eslint/no-var-requires */
const cmpTailwindConfig = require("@abaco/web-components/tailwind.config");

module.exports = {
    ...cmpTailwindConfig,
    purge: [
        './public/**/*.html',
        './node_modules/@abaco/**/*.vue',
        './node_modules/@abaco/**/*.html',
        './src/**/*.html',
        './src/**/*.vue'
    ]
};
