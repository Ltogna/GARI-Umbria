# Single Crop plan Module

Modulo per la gestione di piani colturali in ambiente New Agri
Il modulo permette all'utente di gestire numerose funzioni legate al mondo dei piani colturali quali:

* Gestione delle dichiarazioni (creazione, modifica ed eliminazione)
* Visualizzazione di eventuali anomalie presenti nel piano
* Modifica della geometria degli appezzamenti in conduzione
* Possibilitá di navigare fra i comuni di competenza con relativo filtro sulla lista degli appezzamenti
* Invocare stampe PDF / Excel
* Invocare operazioni legate alla gestione delle versioni del piano colturale quali:
  * Gestione delle versioni
  * Pubblicazione del piano
  * Importazione di dati da anni precedenti

## Table of Contents

* [Project Setup](#project-setup)
* [Getting Started](#getting-started)
* [Quick Test](#quick-test)
* [Publish](#publish)

## Project setup

1. If you are already logged in to abaco private repository npm-group skip to step 4.

```
npm login --registry=https://nexus.fe.abacogroup.eu/repository/npm-group/
```

2. Insert the SSO Credential for the nexus repository when prompted.
3. Insert your email when prompted
4. Install the project dependecies.

```
npm install
```

Done

### Compiles and hot-reloads for development

```
npm run serve
```

### Compiles and minifies for production

```
npm run build
```

### Run your unit tests

```
npm run test:unit
```

### Lints and fixes files

```
npm run lint
```

### Customize configuration

See [Configuration Reference](https://cli.vuejs.org/config/).

## Getting started

Struttura del progetto

```
📦crop-plan-client
 ┣ 📂conf
 ┃ ┗ 📂template
 ┃   ┗ 📜default.conf.template <-- Risorsa obsoleta
 ┣ 📂helm <-- Contiene tutti i files di configurazione Kubernetes
 ┃ ┣ 📂template
 ┃ ┃ ┣ 📜apigateway.yaml
 ┃ ┃ ┣ 📜config-map.yaml
 ┃ ┃ ┣ 📜deployment.yaml
 ┃ ┃ ┣ 📜ingress.yaml
 ┃ ┃ ┗ 📜service.yaml
 ┃ ┣ 📜Chart.yaml
 ┃ ┗ 📜values.yaml
 ┣ 📂k8s <-- Contiene i files di configurazione che kubernetes userà in fase di deploy per impostare a livello di ambiente la configurazione desiderata del crop plan client (vd voce dedicata)
 ┃ ┗ 📜values-{ambiente}.yaml
 ┣ 📂node_modules <-- Cartella che contiene tutte le dipendenze del modulo
 ┣ 📂public
 ┣ 📂src
 ┣ 📂themes <-- Cartella che contiene tutti i fogli di stile utilizzabili con il crop plan client (vd /src/main.ts:121 metodo "doAddCss")
 ┃ ┗ 📜{nome_modalita_portale}.scss
 ┣ 📜.eslintrc.js <-- File di configurazione che contiene tutte le configurazioni/regole utilizzate dal lint
 ┣ 📜tsconfig.json <-- File di configurazione utilizzato dal compilatore typescript
 ┣ 📜.gitlab-ci.yml <-- File contenente tutte le prorogative utilizzati dalla pipeline gitlab
 ┣ 📜jest.config.js <-- File di configurazione per test junit del progetto
 ┣ 📜package-lock.json <-- File node parallelo al file package.json
 ┣ 📜package.json <-- File descrittore del progetto node in cui sono indicati gli script npm, la definizione del package del progetto e dipendenze operative e di sviluppo
 ┣ 📜README.md <-- Questo file (ricordarsi di aggiornarlo il più possibile di modo da avere una documentazione sempre aggiornata)
 ┣ 📜tailwind.config.js <-- File di configurazione richiesto da tailwind
 ┣ 📜tsconfig.json <-- File di configurazione utilizzato dal compilatore typescript
 ┗ 📜vue.config.js <-- File di configurazione utilizzato da Vue2 per impostare le rotte da interrogare per ogni endpoint richiamato nel codice
```

### index.ts

This is the entry poitn file of the module, where you initiliaze your module, or call the server APIs.

A basic module normally requires

* id: string. A unique id to identify the module,
* globalComponents: VueRegistration. All the components that the module expose externally.
* routes: RouteConfig[]. An array of RouteConfig containing the module routes.
* menu: MenuItem[]. An array of MenuItem containing all the menu voices that the module exposes.
* vuexModule: AbacoVuexModule. The module used to handle the module store.

Then the module has two lifecycle hooks:

* OnRouteReady,fired when the route has been created, which exposes
  * An Axios HTTPClient,
  * The application Store,
  * The application Router
* OnApplicationReady, fired when the application has been mounted, which exposes
  * An Axios HTTPClient,
  * the Vue instance,
  * the list of application modules

### global.ts

This is the file where you can register the components to be exposed externally to the module. It can be for example a component tile.

### state.ts

This is the file where you can add objects to the module store.

### routes.ts

This is the file where you can configure the module routes.

### menu.ts

This is the file where you can configure the module menu voices.

### components

This is the folder to place the module components.
To keep it organized it has been divided into two folders:

* navbar, place here all the components to be shown in the fixed top navbar, like filters
* tiles, place here all the tiles components to be placed inside a tile container

### models

This is the folder to place the module models. Like interfaces types and classes that are used across the module.

## Quick Test

To test the module without having to embed it inside the portal or other modules, in this template have been included all the needed dependecies, expecially two files with the main structure of the portal.

These three files are the following

* main.ts
* Home.vue

### main.ts

Here it has been initialized an application with:

* SSO Web Module, which authenticates each request and furnish a login page
* Menu Module, which handles the sidebar menu.
* TilesFramework
* Abaco Web Components

In order to test your module, or if you need to add other modules, remeber to add it/them to the application doing as follow:

```
abacoApp.add(new yourModule());
```

before starting the application

### Home.vue

Here the main structure of the portal is replicated.

## Publish

In order to publish the module to the private npm abaco repository follow these steps:

1. Update the version number in the package.json
2. If you are already logged in to abaco private repository npm-private skip to step 5.

```
npm login --registry=https://nexus.fe.abacogroup.eu/repository/npm-private/
```

3. Insert the SSO Credential for the nexus repository if prompted.
4. Insert your email if prompted
5. Publish to the repo

```
npm publish
```

Done
