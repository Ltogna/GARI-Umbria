module.exports = {
    publicPath: process.env.BASE_URL || "/crop-plan-client",
    outputDir: "./dist" + (process.env.BASE_URL || "/crop-plan-client"),
    devServer: {
        port: 9090,
        proxy: {
            "/sso2": {
                // target: "https://dev-iacs.gov.mt.abacogroup.eu/",
                // target: "https://avepa-dev.fe.abacogroup.eu/",
                target: "https://iacs-dev.fe.abacogroup.eu/",
            },
            "/i18n": {
                target: "https://devs4f.fe.abacogroup.eu/",
                // target: "https://test-iacs.gov.mt.abacogroup.eu/",
                // target: "https://avepa-dev.fe.abacogroup.eu/",
                //target: "https://iacs-dev.fe.abacogroup.eu/",
            },
            "/abacoGeocodingRest": {
                // target: "https://avepa-dev.fe.abacogroup.eu/",
                target: "https://iacs-dev.fe.abacogroup.eu/",
                // target: "https://dev-iacs.gov.mt.abacogroup.eu/",
            },
            "/crop-plan-api": {
                // target: "https://dev-iacs.gov.mt.abacogroup.eu/"
                // target: "https://avepa-dev.fe.abacogroup.eu/",
                target: "https://iacs-dev.fe.abacogroup.eu/",
                // target: "http://localhost:8080/",
                // pathRewrite: {'^/crop-plan-api' : ''}
            },
            "/dev-proxy": {
                // target: "https://avepa-dev.fe.abacogroup.eu/",
                target: "https://iacs-dev.fe.abacogroup.eu/",
                // target: "https://dev-iacs.gov.mt.abacogroup.eu/",
            },
            "/ac": {
                target: "https://iacs-dev.fe.abacogroup.eu/",
                // target: "https://dev-iacs.gov.mt.abacogroup.eu/",
            }
        },
    },
};

//DEVS4F
// https://devs4f.fe.abacogroup.eu/
