# sso2-login-page

This template should help get you started developing with Vue 3 in Vite.

## Recommended IDE Setup

[VSCode](https://code.visualstudio.com/) + [Volar](https://marketplace.visualstudio.com/items?itemName=Vue.volar) (and disable Vetur).

## Type Support for `.vue` Imports in TS

TypeScript cannot handle type information for `.vue` imports by default, so we replace the `tsc` CLI with `vue-tsc` for type checking. In editors, we need [Volar](https://marketplace.visualstudio.com/items?itemName=Vue.volar) to make the TypeScript language service aware of `.vue` types.

## Customize configuration

See [Vite Configuration Reference](https://vitejs.dev/config/).

## Project Setup

```sh
npm install
```

### Compile and Hot-Reload for Development

```sh
npm run dev
```

### Type-Check, Compile and Minify for Production

```sh
npm run build
```

### Lint with [ESLint](https://eslint.org/)

```sh
npm run lint
```

### Formattin [Prettier](https://prettier.io/)

```sh
npm run fmt
```

### Create style with sass

```sh
npm run create-styles
```

### Create changelog with [convco](https://convco.github.io/)

> need to installed convco

```sh
npm run changelog
```

## Config .env file

```dotenv
## need to end with slash
VITE_BASE=/sso2-login/
VITE_FORCED_CONTEXT=
VITE_MODULE_ID=sso2-login-page
VITE_DEFAULT_TENANT=master
VITE_SSO2_BASE_PATH=/sso2
VITE_ACCESS_CONTROL_PATH=/ac
VITE_ALTERNATIVE_LOGINS=W10=

```

### VITE_BASE

The base application url

### VITE_FORCED_CONTEXT

The force context. Added VITE_FORCED_CONTEXT to VITE_BASE and all the API collded.

### VITE_MODULE_ID

Module ID

### VITE_DEFAULT_TENANT

Default tenant if isn't specified on query param.

### VITE_SSO2_BASE_PATH

Base url to make requests.

### VITE_ACCESS_CONTROL_PATH

Where to sumbited request after login. If not configurated the software ignore submited.

### VITE_ALTERNATIVE_LOGINS

An array of alternative login. Accept a valid JSON.
It can be a simple string or base64.

#### Example of configuration. This need to converted in base64 'couse .evn not support multilines

```json
[
	{
		"action": "/lepida",
		"text": "SPID/CE/CNS",
		"method": "POST",
		"options": [
			{
				"name": "tenant",
				"value": "{tenant}"
			},
			{
				"name": "redirectUrl",
				"value": "{origin}{baseURL}not-found"
			}
		]
	},
	{
		"action": "/iam",
		"text": "IAM",
		"method": "GET"
	},
	{
		"action": "/other",
		"text": "Other",
		"method": "GET"
	}
]


// VITE_ALTERNATIVE_LOGINS=WwogIHsKICAgICJhY3Rpb24iOiAiL2xlcGlkYSIsCiAgICAidGV4dCI6ICJTUElEL0NFL0NOUyIsCiAgICAibWV0aG9kIjogIlBPU1QiLAogICAgIm9wdGlvbnMiOiBbCiAgICAgIHsKICAgICAgICAibmFtZSI6ICJ0ZW5hbnQiLAogICAgICAgICJ2YWx1ZSI6ICJ7dGVuYW50fSIKICAgICAgfSwKICAgICAgewogICAgICAgICJuYW1lIjogInJlZGlyZWN0VXJsIiwKICAgICAgICAidmFsdWUiOiAie29yaWdpbn17YmFzZVVSTH1ub3QtZm91bmQiCiAgICAgIH0KICAgIF0KICB9LAogIHsKICAgICJhY3Rpb24iOiAiL2lhbSIsCiAgICAidGV4dCI6ICJJQU0iLAogICAgIm1ldGhvZCI6ICJHRVQiCiAgfSwKICB7CiAgICAiYWN0aW9uIjogIi9vdGhlciIsCiAgICAidGV4dCI6ICJPdGhlciIsCiAgICAibWV0aG9kIjogIkdFVCIKICB9Cl0=
```

or

```
VITE_ALTERNATIVE_LOGINS=[{"action":"/lepida","text":"SPID/CE/CNS","method":"POST","options":[{"name":"tenant","value":"{tenant}"},{"name":"redirectUrl","value":"{origin}{baseURL}not-found"}]},{"action":"/iam","text":"IAM","method":"GET"},{"action":"/other","text":"Other","method":"GET"}]
```

#### `options`:

`options` is an array with `name` and `value`.

Value has some replace variables:

- `tenant`: current tenant
- `origin`: the origin of request Es.: "http://example.com"
- `baseURL`: the `VITE_BASE` of application.
