import { fileURLToPath, URL } from "node:url";
import { execSync } from "node:child_process";

import { ConfigEnv, defineConfig, loadEnv, UserConfig } from "vite";
import nodePackage from "./package.json";
import vue from "@vitejs/plugin-vue";
import vueDevTools from "vite-plugin-vue-devtools";
import { viteStaticCopy } from "vite-plugin-static-copy";

export default function (config: ConfigEnv): UserConfig {
	let VITE_APP_GIT_COMMIT = "xxxxxxxx";
	try {
		VITE_APP_GIT_COMMIT = execSync("git rev-parse --short=8 HEAD")
			.toString()
			.trim();
	} catch (err) {
		console.warn("Error parse git rev");
		//
	}
	process.env = {
		...process.env,
		...loadEnv(config.mode, process.cwd(), ["VITE"]),
		VITE_APP_VERSION: nodePackage.version,
		VITE_APP_GIT_COMMIT,
	};

	const forceContext = process.env.VITE_FORCED_CONTEXT ?? "";

	return defineConfig({
		plugins: [
			viteStaticCopy({
				targets: [
					{
						src: "node_modules/bootstrap-italia/dist/**/*",
						dest: "bootstrap-italia/dist",
					},
				],
			}),
			vue(),
			vueDevTools(),
		],
		base: `${forceContext}${process.env.VITE_BASE}`,
		resolve: {
			alias: {
				"@": fileURLToPath(new URL("./src", import.meta.url)),
			},
		},
		css: {
			devSourcemap: true,
		},
		build: {
			target: "ESNext",
			rollupOptions: {
				output: {
					entryFileNames: "[name].[hash].js",
					assetFileNames: "assets/[name].[hash].[ext]",
				},
			},
		},
		server: {
			port: 3000,
			proxy: {
				[`${forceContext}/sso2/`]: {
					target: "https://iacs-dev.fe.abacogroup.eu/",
					changeOrigin: true,
					secure: false,
				},
			},
		},
	});
}
