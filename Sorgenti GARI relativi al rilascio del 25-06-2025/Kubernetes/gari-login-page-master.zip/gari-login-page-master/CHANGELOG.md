# Changelog

## Unreleased (2024-09-30)

### Features

- :tada: #129235 first import, closes
  [#129235](https://abacogroup.easyredmine.com/issues/129235)

### Fixes

- :green_heart: fixed CI

### Other

- :wrench: added tenant to options
- :memo: update changelog
