<script setup lang="ts">
import BiButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiButton.vue";
import { ref } from "vue";

const props = defineProps<{
	authToken: string;
	accessControlPath: string;
	state?: string;
}>();

defineExpose({
	submitForm,
});

const form = ref<HTMLFormElement>();

function submitForm() {
	if (form.value && props.accessControlPath) {
		form.value.submit();
	}
}
</script>

<template>
	<form
		ref="form"
		v-if="accessControlPath"
		:action="accessControlPath"
		method="POST">
		<p>
			Reindirizzamento ad auth, se non vieni reindirizzato entro pochi secondi
			clicca sul pulsante Invia
		</p>
		<input hidden name="authToken" :value="authToken" />
		<input hidden name="state" :value="props.state" />
		<div class="form-group mt-5">
			<BiButton type="submit" color="primary" class="form-control">
				Invia
			</BiButton>
		</div>
	</form>
</template>
