<script setup lang="ts">
import type { AlternativeLoginModel } from "@/models/options";
import BiButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiButton.vue";

defineProps<{
	item: AlternativeLoginModel;
	isSubmitting: boolean;
	fixedWidth: boolean;
}>();
</script>

<template>
	<form :key="item.action" :action="item.action" :method="item.method">
		<input
			v-for="(option, i) in item.options"
			:key="`${option.name}-${i}`"
			:name="option.name"
			:value="option.value"
			type="hidden" />
		<div class="form-group mb-2">
			<BiButton
				type="submit"
				color="primary"
				class="form-control rounded-2"
				:class="{ 'sso2-login-page__action-btn': fixedWidth }"
				:is-disabled="isSubmitting">
				{{ item.text }}
			</BiButton>
		</div>
	</form>
</template>
<style lang="scss" scoped>
.sso2-login-page {
	&__action-btn {
		width: 150px;
	}
}
</style>
