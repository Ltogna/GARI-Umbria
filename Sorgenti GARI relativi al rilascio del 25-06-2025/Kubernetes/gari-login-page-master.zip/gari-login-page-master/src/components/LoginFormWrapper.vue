<template>
	<div class="row justify-content-center pt-5">
		<div class="col-6 sso2-login-page__card-col">
			<div class="card-wrapper card-space">
				<div class="card no-after card-bg">
					<div class="card-body">
						<div class="row justify-content-center mb-4">
							<div class="col-12 d-inline-flex justify-content-center mb-3">
								<img
									src="/gari-logo-tiny.png"
									alt="GARI UMBRIA Gestione Agricola e Rurale Informatizzata"
									class="img-fluid sso2-login-page__logo" />
							</div>

							<div class="d-flex justify-content-center">
								<h3 class="ms-2">
									<span class="d-block">Benvenuti in GARI UMBRIA</span>
								</h3>
							</div>
						</div>

						<slot />
					</div>
				</div>
			</div>
		</div>
	</div>
</template>
<style lang="scss" scoped>
.sso2-login-page {
	&__card-col {
		max-width: 600px;
	}
	&__logo {
		object-fit: contain;
	}
}
</style>
