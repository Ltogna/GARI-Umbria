import "./assets/sso2-login-page.scss";

import createBootstrapItaliaComponentPlugin from "@abaco/bootstrap-italia-components/src/components/BootstrapItaliaComponentPlugin";
import { createAbcRouter } from "@abaco/micro-frontend/src/Utility";
import { getUserData, whoAmI } from "@abaco/safe-rest/src/sso2";
import { createApp } from "vue";
import App from "./App.vue";
import { BASE, MODULE_ID, SSO2_BASE_PATH } from "./constants";
import getRoutes from "./router";

console.log(
	`${MODULE_ID}: v${import.meta.env.VITE_APP_VERSION}-${import.meta.env.VITE_APP_GIT_COMMIT}`
);

window.bootstrap.loadFonts(BASE + "bootstrap-italia/dist/fonts");

const router = createAbcRouter(
	getRoutes(import.meta.env.BASE_URL),
	import.meta.env.BASE_URL
);

// eslint-disable-next-line @typescript-eslint/no-unused-vars
router.beforeEach(async (to, _from) => {
	let userData = getUserData();
	if (userData === null && !to.meta.unauthenticated) {
		await whoAmI(SSO2_BASE_PATH);
		userData = getUserData();
		if (userData === null) {
			return {
				name: "LoginView",
				query: { externalError: "No valid user found" },
			};
		}
	}
});

const bootstrapItaliaComponentPlugin =
	await createBootstrapItaliaComponentPlugin({
		includeGlobalComponent: false,
		includeFontAwesome: true,
	});
const app = createApp(App);

app.use(bootstrapItaliaComponentPlugin);
app.use(router);

app.mount("#app");
