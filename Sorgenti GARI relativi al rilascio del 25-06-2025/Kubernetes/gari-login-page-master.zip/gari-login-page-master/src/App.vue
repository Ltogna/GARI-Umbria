<script setup lang="ts">
import { RouterView } from "vue-router";
</script>

<template>
	<main class="sso2-login-page primary-bg container p-3">
		<RouterView />
	</main>
</template>
