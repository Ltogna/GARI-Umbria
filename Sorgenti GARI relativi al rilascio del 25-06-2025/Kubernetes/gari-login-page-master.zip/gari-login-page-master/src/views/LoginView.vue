<script setup lang="ts">
import AccessControlForm from "@/components/AccessControlForm.vue";
import LoginButton from "@/components/LoginButton.vue";
import LoginFormWrapper from "@/components/LoginFormWrapper.vue";
import {
	ACCESS_CONTROL_PATH,
	ALTERNATIVE_LOGINS,
	BASE,
	SSO2_BASE_PATH,
} from "@/constants";
import { templateOptions, type AlternativeLoginsModel } from "@/models/options";
import BiAlert from "@abaco/bootstrap-italia-components/src/components/BiAlert/BiAlert.vue";
import BiButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiButton.vue";
import BiInput from "@abaco/bootstrap-italia-components/src/components/form/BiInput.vue";
import { ErrorType } from "@abaco/safe-rest/src/HTTPClient";
import { login } from "@abaco/safe-rest/src/sso2";
import { toTypedSchema } from "@vee-validate/zod";
import { template } from "lodash";
import { useForm } from "vee-validate";
import { computed, nextTick, reactive, ref, toRef } from "vue";
import { z } from "zod";

const props = defineProps<{
	tenant: string;
	state?: string;
	externalError?: string;
}>();

const options = reactive({
	tenant: props.tenant,
	origin: location.origin,
	baseURL: BASE,
});

const errorMessage = toRef(props.externalError);
const authToken = ref("");
const accessControlForm = ref<InstanceType<typeof AccessControlForm>>();

const LoginFormSchema = z.object({
	username: z.string().min(1, { message: "Richiesto" }),
	password: z.string().min(1, { message: "Richiesto" }),
});

const { handleSubmit, defineField, errors, submitCount, isSubmitting } =
	useForm({
		initialValues: {
			password: "",
			username: "",
		},
		validationSchema: toTypedSchema(LoginFormSchema),
	});

const submitForm = handleSubmit(async data => {
	const res = await login({ ...data, tenant: props.tenant }, SSO2_BASE_PATH);

	switch (res.errorType) {
		case ErrorType.NONE:
			console.log("logged in to call external auth back");
			errorMessage.value = "";
			authToken.value = res.data.auth_token;
			nextTick(() => {
				accessControlForm.value?.submitForm();
			});
			break;
		case ErrorType.HTTP_STATUS:
		case ErrorType.OTHER:
		default:
			errorMessage.value = "Invalid username or password";
			break;
	}
});

const [username] = defineField("username");
const [password] = defineField("password");

const alternativeLogins = computed<AlternativeLoginsModel>(() => {
	const altLogs = structuredClone(ALTERNATIVE_LOGINS);
	altLogs.forEach(
		alt =>
			(alt.options = alt.options.map(e => {
				e.value = template(e.value, templateOptions)(options);
				return e;
			}))
	);

	return altLogs;
});
</script>

<template>
	<LoginFormWrapper>
		<AccessControlForm
			ref="accessControlForm"
			v-if="ACCESS_CONTROL_PATH && authToken"
			:access-control-path="ACCESS_CONTROL_PATH"
			:auth-token="authToken"
			:state="props.state" />
		<div v-else class="row justify-content-center">
			<div class="col-12">
				<BiAlert v-if="errorMessage" :title="errorMessage" is-error></BiAlert>
				<div class="login-wrap p-0">
					<h3 class="mb-4 text-center">Accedi</h3>
					<form
						action="#"
						@submit="submitForm"
						class="signin-form"
						novalidate
						autocomplete="off">
						<BiInput
							v-model="username"
							label="Username"
							:errors="
								submitCount > 0 && errors.username ? [errors.username] : []
							"
							:disabled="isSubmitting" />
						<div class="sso2-login-page__password mt-4">
							<BiInput
								v-model="password"
								label="Password"
								type="password"
								:errors="
									submitCount > 0 && errors.password ? [errors.password] : []
								"
								:disabled="isSubmitting" />

							<div class="form-group mt-5 d-flex justify-content-center">
								<div class="w-40">
									<BiButton
										type="submit"
										color="primary"
										class="form-control rounded-2 mb-5"
										:is-disabled="isSubmitting">
										Login
									</BiButton>

									<template v-if="alternativeLogins.length">
										<div
											:class="{
												'justify-content-between d-flex px-5':
													alternativeLogins.length === 2,
											}">
											<LoginButton
												v-for="loginButton in alternativeLogins"
												:key="loginButton.action"
												:is-submitting="isSubmitting"
												:item="loginButton"
												:fixedWidth="alternativeLogins.length === 2" />
										</div>
									</template>
								</div>
							</div>
						</div>
					</form>
				</div>
			</div>
		</div>
	</LoginFormWrapper>
</template>
<style lang="scss" scoped>
.sso2-login-page__password :deep(.password-icon) {
	background-color: transparent;
}
</style>
