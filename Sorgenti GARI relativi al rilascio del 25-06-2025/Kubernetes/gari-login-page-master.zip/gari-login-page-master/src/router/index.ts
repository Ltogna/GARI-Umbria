import { DEFAULT_TENANT } from "@/constants";
import type { RouteRecordRaw } from "vue-router";

function getRoutes(basePath = "/") {
	if (!basePath?.endsWith("/")) {
		basePath += "/";
	}
	const routes: RouteRecordRaw[] = [
		{
			path: "/",
			name: "LoginView",
			component: () => import("../views/LoginView.vue"),
			meta: {
				unauthenticated: true,
			},
			props: route => {
				return {
					tenant: route.query.tenant ?? DEFAULT_TENANT,
					state: route.query.state,
				};
			},
		},
		/*
		{
			path: "/auth-error",
			name: "ErrorOnLogin",
			component: () => import("../views/LoginView.vue"),
			meta: {
				unauthenticated: true,
			},
			props: route => {
				return {
					externalError: route.query.externalError,
					tenant: route.query.tenant ?? DEFAULT_TENANT,
				};
			},
		},
		*/
	];

	return routes;
}

export default getRoutes;
