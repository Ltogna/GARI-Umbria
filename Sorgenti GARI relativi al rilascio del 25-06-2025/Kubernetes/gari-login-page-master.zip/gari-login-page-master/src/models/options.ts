import type { TemplateOptions } from "lodash";
import z from "zod";

export const AlternativeLoginOptionSchema = z.object({
	value: z.string(),
	name: z.string(),
});
export const AlternativeLoginOptionsSchema =
	AlternativeLoginOptionSchema.array();

export type AlternativeLoginOptionModel = z.infer<
	typeof AlternativeLoginOptionSchema
>;
export type AlternativeLoginOptionsModel = z.infer<
	typeof AlternativeLoginOptionsSchema
>;

export const AlternativeLoginSchema = z.object({
	action: z.string().min(1),
	text: z.string().min(1),
	method: z.string().min(1),
	options: AlternativeLoginOptionsSchema.default([]),
});

export const AlternativeLoginsSchema = AlternativeLoginSchema.array();

export type AlternativeLoginModel = z.infer<typeof AlternativeLoginSchema>;
export type AlternativeLoginsModel = z.infer<typeof AlternativeLoginsSchema>;

export const EnvSchema = z.object({
	VITE_BASE: z.string().min(1),
	VITE_MODULE_ID: z.string().min(1),
	VITE_DEFAULT_TENANT: z.string().min(1),
	VITE_SSO2_BASE_PATH: z.string().min(1),
	VITE_FORCED_CONTEXT: z.string().default(""),
	VITE_ACCESS_CONTROL_PATH: z.string().optional(),
});

export type EnvModel = z.infer<typeof EnvSchema>;

export const templateOptions: TemplateOptions = {
	interpolate: /\{([\s\S]+?)\}/g,
};
