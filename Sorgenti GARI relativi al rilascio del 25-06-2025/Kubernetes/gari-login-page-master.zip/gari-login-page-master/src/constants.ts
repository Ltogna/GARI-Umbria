import {
	AlternativeLoginsSchema,
	EnvSchema,
	type AlternativeLoginsModel,
} from "./models/options";
export const MODULE_REF = "sso2-login-page"; //! IMPORTANT not override this

const env = EnvSchema.parse(import.meta.env);

let alternativeLogins: string | null = null;

try {
	alternativeLogins = atob(import.meta.env.VITE_ALTERNATIVE_LOGINS);
} catch (err) {
	alternativeLogins = import.meta.env.VITE_ALTERNATIVE_LOGINS;
}

const alternativeLoginsParsed = AlternativeLoginsSchema.safeParse(
	JSON.parse(alternativeLogins ?? "[]")
);

if (!alternativeLoginsParsed.success) {
	console.warn(
		"Error parsed VITE_ALTERNATIVE_LOGINS",
		alternativeLoginsParsed.error
	);
}

export const FORCED_CONTEXT = env.VITE_FORCED_CONTEXT;
export const BASE = `${FORCED_CONTEXT}${env.VITE_BASE}`;
export const MODULE_ID = env.VITE_MODULE_ID;
export const DEFAULT_TENANT = env.VITE_DEFAULT_TENANT;
export const SSO2_BASE_PATH = `${FORCED_CONTEXT}${env.VITE_SSO2_BASE_PATH}`;
export const ACCESS_CONTROL_PATH = env.VITE_ACCESS_CONTROL_PATH;
export const ALTERNATIVE_LOGINS: AlternativeLoginsModel =
	alternativeLoginsParsed.success ? alternativeLoginsParsed.data : [];

export const BASE_MODULE = MODULE_ID;
export const INFINITE_DATE = "99991231";

export type FORCED_CONTEXT = typeof FORCED_CONTEXT;
export type MODULE_ID = typeof MODULE_ID;
export type BASE = typeof BASE;
