# Changelog

### [v4.0.4](https://gitlab.fe.abacogroup.eu/new-agri/anomaly-registry/compare/v4.0.3...v4.0.4) (2024-09-12)

### Feature
* implement new api for multiple parcels anomalies search "/{tenant}/public/v1/anomalies/by-parcel-ids"

### [v4.0.3](https://gitlab.fe.abacogroup.eu/new-agri/anomaly-registry/compare/v4.0.2...v4.0.3) (2024-03-27)

### [v4.0.2](https://gitlab.fe.abacogroup.eu/new-agri/anomaly-registry/compare/v4.0.1...v4.0.2) (2024-02-21)

### [v4.0.1](https://gitlab.fe.abacogroup.eu/new-agri/anomaly-registry/compare/v4.0.0...v4.0.1) (2024-02-13)

## [v4.0.0](https://gitlab.fe.abacogroup.eu/new-agri/anomaly-registry/compare/v1.0.1...v4.0.0) (2024-01-09)

### [v1.0.1](https://gitlab.fe.abacogroup.eu/new-agri/anomaly-registry/compare/v1.0.0...v1.0.1) (2023-02-08)

## v1.0.0 (2022-12-23)
