create table anm_anomaly_types
(
    id             bigserial    not null,
    tenant_id      varchar(100) not null,

    group_code     varchar(100) not null,
    code           varchar(100) not null,

    dt_insert      timestamp    NOT NULL,
    user_id_insert varchar(100) NOT NULL,
    dt_delete      timestamp    NOT NULL,
    user_id_delete varchar(100),

    constraint anm_anomaly_types_pk primary key (id),
    constraint anm_anomaly_types_uk1 unique (tenant_id, code, group_code, dt_delete)

);


create table anm_anomalies
(
    id             bigserial    not null,
    tenant_id      varchar(100) not null,

    type_id        bigint       not null,
    entity_code    varchar(100) not null,
    entity_id      varchar(100) not null,

    dt_insert      timestamp    NOT NULL,
    user_id_insert varchar(100) NOT NULL,
    dt_delete      timestamp    NOT NULL,
    user_id_delete varchar(100),

    constraint anm_anomalies_pk primary key (id),
    constraint anm_anomalies_uk1 unique (tenant_id, type_id, entity_code, entity_id, dt_delete),
    constraint anm_anomalies_fk1 foreign key (type_id) references anm_anomaly_types (id)
);

create index anm_anomalies_ix1 ON anm_anomalies (tenant_id, entity_code, entity_id);


-- I18N

create table anm_i18n_values
(
    tenant_id  varchar(100)  not null,
    table_name varchar(100)  not null,
    field_name varchar(100)  not null,
    i18n_value varchar(4000) not null,
    lang       varchar(20)   not null,
    i18n_text  varchar(4000) not null,

    constraint anm_i18n_values_pk primary key (tenant_id, table_name, field_name, i18n_value, lang)
);


