#!/bin/bash

stack=_docker
rmi=local

if [ -z ${1+x} ];
  then rmi=local;
  else rmi=$1;
fi
# echo $rmi

## --rmi flag must be one of: all, local
docker-compose -p $stack down --rmi $rmi --volumes

docker-compose -f docker-compose.yml -p $stack up -d --build --remove-orphans --force-recreate