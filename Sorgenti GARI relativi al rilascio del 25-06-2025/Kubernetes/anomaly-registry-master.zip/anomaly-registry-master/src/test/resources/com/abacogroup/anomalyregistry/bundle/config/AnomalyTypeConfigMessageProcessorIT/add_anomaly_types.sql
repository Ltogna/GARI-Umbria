insert into anm_anomaly_types (id, tenant_id, group_code, code, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-1001, :test_tenant, 'GR1', 'AT1', TO_DATE('2020-01-01', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);

insert into anm_anomaly_types (id, tenant_id, group_code, code, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-1002, :test_tenant, 'GR1', 'AT2', TO_DATE('2020-01-01', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);

insert into anm_anomaly_types (id, tenant_id, group_code, code, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-1003, :test_tenant, 'GR2', 'AT3', TO_DATE('2020-01-01', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);

insert into anm_anomaly_types (id, tenant_id, group_code, code, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-1014, :test_tenant, 'GR2', 'AT2', TO_DATE('2020-01-01', 'YYYY-MM-DD'), :user_id, TO_DATE('2020-01-01', 'YYYY-MM-DD'), :user_id);
insert into anm_anomaly_types (id, tenant_id, group_code, code, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-1004, :test_tenant, 'GR2', 'AT2', TO_DATE('2020-01-01', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);

-- deleted
insert into anm_anomaly_types (id, tenant_id, group_code, code, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-1005, :test_tenant, 'GR2', 'AT5', TO_DATE('2020-01-01', 'YYYY-MM-DD'), :user_id, TO_DATE('2020-01-01', 'YYYY-MM-DD'), :user_id);

-- deleted
insert into anm_anomaly_types (id, tenant_id, group_code, code, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-1006, :test_tenant, 'GR2', 'AT6', TO_DATE('2020-01-01', 'YYYY-MM-DD'), :user_id, TO_DATE('2020-01-01', 'YYYY-MM-DD'), :user_id);

