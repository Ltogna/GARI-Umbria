---------------------
----- anomalies -----
---------------------
insert into anm_anomalies (id, tenant_id, type_id, entity_code, entity_id, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-101, :test_tenant, -1001, 'ITEM', '12', TO_DATE('2020-01-01', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);

-- expired
insert into anm_anomalies (id, tenant_id, type_id, entity_code, entity_id, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-102, :test_tenant, -1002, 'PARTY', '5', TO_DATE('2020-01-01', 'YYYY-MM-DD'), :user_id, TO_DATE('2020-12-31', 'YYYY-MM-DD'), :user_id);
