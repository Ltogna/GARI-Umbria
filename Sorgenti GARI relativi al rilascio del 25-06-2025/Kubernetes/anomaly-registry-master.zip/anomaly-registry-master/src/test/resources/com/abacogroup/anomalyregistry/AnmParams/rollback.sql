delete
from anm_anomalies
where tenant_id = :test_tenant;

delete
from anm_anomaly_types
where tenant_id = :test_tenant;

delete
from anm_i18n_values
where tenant_id = :test_tenant;


delete
from bnd_registry
where tenant_id = :test_tenant;

delete
from bnd_tenant
where tenant_id = :test_tenant;

