insert into anm_anomaly_types (id, tenant_id, group_code, code, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-1001, :test_tenant, 'GR1', 'AT1', TO_DATE('2020-01-01', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);

insert into anm_anomaly_types (id, tenant_id, group_code, code, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-1002, :test_tenant, 'GR1', 'AT2', TO_DATE('2020-01-01', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);

insert into anm_anomaly_types (id, tenant_id, group_code, code, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-1003, :test_tenant, 'GR2', 'AT3', TO_DATE('2020-01-01', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);

insert into anm_anomaly_types (id, tenant_id, group_code, code, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-1004, :test_tenant, 'GR2', 'AT2', TO_DATE('2020-01-01', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);

-- deleted
insert into anm_anomaly_types (id, tenant_id, group_code, code, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-1005, :test_tenant, 'GR2', 'AT5', TO_DATE('2020-01-01', 'YYYY-MM-DD'), :user_id, TO_DATE('2020-01-01', 'YYYY-MM-DD'), :user_id);

-------

INSERT INTO anm_i18n_values (tenant_id, table_name, field_name, i18n_value, lang, i18n_text)
    (select tenant_id, 'anm_anomaly_types', 'code', code, 'en', '-'
     from anm_anomaly_types
     where tenant_id = :test_tenant
     union
     select tenant_id, 'anm_anomaly_types', 'code', code, 'it', '-'
     from anm_anomaly_types
     where tenant_id = :test_tenant);

update anm_i18n_values
set i18n_text = lower(i18n_value) || ' ' || lang
WHERE table_name in ('anm_anomaly_types')
  and tenant_id = :test_tenant;
