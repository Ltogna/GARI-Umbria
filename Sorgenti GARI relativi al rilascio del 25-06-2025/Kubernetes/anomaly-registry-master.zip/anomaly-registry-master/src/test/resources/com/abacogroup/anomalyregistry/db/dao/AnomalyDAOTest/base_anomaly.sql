-- anomaly types
insert into anm_anomaly_types (id, tenant_id, group_code, code, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-1, :test_tenant, 'GR1', 'AT1', TO_DATE('2020-01-01', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);

insert into anm_anomaly_types (id, tenant_id, group_code, code, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-2, :test_tenant, 'GR1', 'AT2', TO_DATE('2020-01-01', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);
