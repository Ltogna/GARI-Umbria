package com.abacogroup.anomalyregistry.db.dao;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.junit.jupiter.api.Assertions.assertTrue;

import com.abacogroup.anomalyregistry.AnmParams;
import com.abacogroup.anomalyregistry.api.req.AnomalyReq;
import com.abacogroup.anomalyregistry.db.ntt.AnomalyEntity;
import com.abacogroup.common.core.MyJdbi;
import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import org.hamcrest.CoreMatchers;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

@ExtendWith(DropwizardExtensionsSupport.class)
class AnomalyDAOTest extends MyJdbi {

	private static final String currentUser = "AnomalyDAOTest_u";
	private static final String tenantId = "AnomalyDAOTest_t";

	private static final Map<String, Object> testScriptParams = Map.of(
			"test_tenant", tenantId,
			"user_id", currentUser
	);

	private final AnomalyDAO dao = getDAO(AnomalyDAO.class);

	@BeforeAll
	@AfterAll
	public static void beforeAll() {
		execSqlFiles(AnmParams.class, List.of("rollback"), testScriptParams);
	}

	@Disabled("`@GetGeneratedKeys(\"id\")` generates error in oracle")
	@Test
	void test_insert_in_batch() {
		getJdbi().useHandle(handle -> {
			handle.begin();
			List<String> initScripts = List.of("base_anomaly");
			execSqlFiles(this.getClass(), initScripts, testScriptParams);

			assertThat(dao.countAll(tenantId), CoreMatchers.is(0L));

			AnomalyEntity[] anomalies = List.of(
							AnomalyEntity.builder().setTenantId(tenantId).setTypeId(-1L).setEntityCode("PARTY").setEntityId("1").build(),
							AnomalyEntity.builder().setTenantId(tenantId).setTypeId(-2L).setEntityCode("ITEM").setEntityId("5").build(),
							AnomalyEntity.builder().setTenantId(tenantId).setTypeId(-1L).setEntityCode("PARTY").setEntityId("22").build())
					.toArray(AnomalyEntity[]::new);

			dao.setAuditForInsert(currentUser, anomalies);

			Long[] ids = dao.insertInBatch(anomalies);

			assertThat(ids.length, CoreMatchers.is(3));
			assertThat(dao.countAll(tenantId), CoreMatchers.is(3L));

			handle.rollback();
		});
	}

	@Disabled("`@GetGeneratedKeys(\"id\")` generates error in oracle")
	@Test
	void test_insert_duplicates_in_batch() {
		getJdbi().useHandle(handle -> {
			handle.begin();
			List<String> initScripts = List.of("base_anomaly");
			execSqlFiles(this.getClass(), initScripts, testScriptParams);

			assertThat(dao.countAll(tenantId), CoreMatchers.is(0L));
			// list of the same objects
			AnomalyEntity[] anomalies = List.of(
							AnomalyEntity.builder().setTenantId(tenantId).setTypeId(-1L).setEntityCode("PARTY").setEntityId("1").build(),
							AnomalyEntity.builder().setTenantId(tenantId).setTypeId(-1L).setEntityCode("PARTY").setEntityId("1").build())
					.toArray(AnomalyEntity[]::new);

			dao.setAuditForInsert(currentUser, anomalies);

			dao.insertInBatch(anomalies);

			assertThat("same object inserted just one time", dao.countAll(tenantId), CoreMatchers.is(1L));
			// insert an existing object

			AnomalyEntity[] existing_anomaly = List.of(
							AnomalyEntity.builder().setTenantId(tenantId).setTypeId(-1L).setEntityCode("PARTY").setEntityId("1").build())
					.toArray(AnomalyEntity[]::new);

			dao.setAuditForInsert(currentUser, existing_anomaly);

			dao.insertInBatch(existing_anomaly);

			assertThat("existing anomaly not inserted", dao.countAll(tenantId), CoreMatchers.is(1L));

			handle.rollback();
		});
	}

	@Test
	void test_expire_in_batch() {

		var audit = new AnomalyEntity();
		dao.setAuditForExpire(currentUser, audit);
		getJdbi().useHandle(handle -> {
			handle.begin();
			List<String> initScripts = List.of("base_anomaly", "add_anomalies");
			execSqlFiles(this.getClass(), initScripts, testScriptParams);
			assertThat(dao.countAll(tenantId), CoreMatchers.is(1L));

			dao.expireInBatch(List.of(-101L, 0L), audit);

			assertThat(dao.countAll(tenantId), CoreMatchers.is(0L));

			handle.rollback();
		});
	}

	@Test
	void test_find_id_by_request() {
		getJdbi().useHandle(handle -> {
			handle.begin();
			List<String> initScripts = List.of("base_anomaly", "add_anomalies");
			execSqlFiles(this.getClass(), initScripts, testScriptParams);

			assertThat(dao.countAll(tenantId), CoreMatchers.is(1L));

			Optional<AnomalyEntity> entity = dao.findByRequest(tenantId,
					AnomalyReq.builder().setTypeGroupCode("GR1").setTypeCode("AT1").setEntityCode("ITEM").setEntityId("12").build());

			assertTrue(entity.isPresent());
			assertThat(entity.get().getId(), CoreMatchers.is(-101L));

			Optional<AnomalyEntity> entity2 = dao.findByRequest(tenantId,
					AnomalyReq.builder().setTypeGroupCode("GR1").setTypeCode("AT2").setEntityCode("PARTY").setEntityId("5").build());
			// entity2 is expired
			assertTrue(entity2.isEmpty());

			handle.rollback();
		});
	}

}
