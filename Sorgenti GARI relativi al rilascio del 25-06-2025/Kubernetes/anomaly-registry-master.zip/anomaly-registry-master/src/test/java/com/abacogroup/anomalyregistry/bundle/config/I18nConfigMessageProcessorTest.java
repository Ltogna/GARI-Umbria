package com.abacogroup.anomalyregistry.bundle.config;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;

import com.abacogroup.anomalyregistry.db.dao.I18nDAO;
import com.abacogroup.bundles.initializer.impl.FileSupport;
import com.abacogroup.bundles.listener.configdata.ConfigDataMessage;
import com.abacogroup.common.core.MyJdbi;
import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;
import java.nio.file.Path;
import java.util.List;
import org.jdbi.v3.core.Jdbi;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

@ExtendWith(DropwizardExtensionsSupport.class)
class I18nConfigMessageProcessorTest extends MyJdbi {

	private static final String tenantIdStar = "myTenant*";

	private final I18nDAO dao = getJdbi().onDemand(I18nDAO.class);

	private final I18nConfigMessageProcessor init = getService(I18nConfigMessageProcessor.class);

	private void clearBundles() {
		Jdbi jdbi = getJdbi();
		jdbi.useTransaction(handle -> {
			handle.execute("delete from anm_i18n_values where tenant_id = ? ", tenantIdStar);
			handle.execute("delete from bnd_registry where tenant_id = ? ", tenantIdStar);
		});
	}

	@Test
	void test_process_bundle_files() {
		try {
			ConfigDataMessage configDataMessage = new ConfigDataMessage();
			configDataMessage.setTenantId(tenantIdStar);
			String domainPathString = "src/test/resources/bundles/standard/anomaly-registry/anm-001/i18n";
			Path domainPath = Path.of(domainPathString);
			List<Path> paths = FileSupport.listFilesRecursive(domainPath);
			configDataMessage.setConfigFiles(paths);
			init.onMessage(configDataMessage);

			String label = this.dao.searchLabel(tenantIdStar, "anm_anomaly_types", "code", "PC", "en");
			assertThat(label, is("CRPL"));
		} finally {
			this.clearBundles();
		}
	}
}
