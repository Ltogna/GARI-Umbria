package com.abacogroup.anomalyregistry.core.impl;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.ArgumentMatchers.same;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.verify;

import com.abacogroup.anomalyregistry.api.AnomalyTypeRes;
import com.abacogroup.anomalyregistry.api.req.AnomalyTypeSearchReq;
import com.abacogroup.anomalyregistry.api.v1.AnomalyTypeResponse;
import com.abacogroup.anomalyregistry.api.v1.req.AnomalyTypeSearchRequest;
import com.abacogroup.anomalyregistry.core.AnomalyTypeService;
import com.abacogroup.common.core.ReqContext;
import java.util.List;
import java.util.Optional;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

class AnomalyTypeServiceV1ImplTest {

	private static final ReqContext context = new ReqContext("tenant1", "userX", "en");

	@Mock
	private AnomalyTypeService anomalyTypeService;
	@InjectMocks
	private AnomalyTypeServiceV1Impl anomalyTypeServiceV1;

	@Captor
	private ArgumentCaptor<AnomalyTypeSearchReq> searchReqCaptor;

	private AutoCloseable closeable;

	@BeforeEach
	public void openMocks() {
		closeable = MockitoAnnotations.openMocks(this);
	}

	@AfterEach
	public void releaseMocks() throws Exception {
		closeable.close();
	}

	// ----- searchAll -----
	@Test
	void test_searchAll_ok() {
		var searchRequest = new AnomalyTypeSearchRequest().setGroupCode("GR1").setCode("ATx").setI18nCode("gr1");
		given(anomalyTypeService.searchAll(any(), any()))
				.willReturn(List.of(
						AnomalyTypeRes.builder()
								.setGroupCode("GR1").setCode("AT1").setI18nCode("gr1.at1")
								.build(),
						AnomalyTypeRes.builder()
								.setGroupCode("GR1").setCode("AT2").setI18nCode("gr1.at2")
								.build()
				));

		var responseList = anomalyTypeServiceV1.searchAll(context, searchRequest);

		verify(anomalyTypeService).searchAll(same(context), searchReqCaptor.capture());
		assertThat(searchReqCaptor.getValue()).isNotNull()
				.usingRecursiveComparison()
				.isEqualTo(searchRequest);
		assertThat(responseList).isNotNull().hasSize(2)
				.containsExactly(
						AnomalyTypeResponse.builder()
								.setGroupCode("GR1").setCode("AT1").setI18nCode("gr1.at1")
								.build(),
						AnomalyTypeResponse.builder()
								.setGroupCode("GR1").setCode("AT2").setI18nCode("gr1.at2")
								.build()
				);

	}

	// ----- getById -----
	@Test
	void test_getById_ok() {
		given(anomalyTypeService.getById(any(), anyLong()))
				.willReturn(Optional.of(AnomalyTypeRes.builder()
						.setGroupCode("GR1").setCode("AT1").setI18nCode("gr1.at1")
						.build()));

		var response = anomalyTypeServiceV1.getById(context, -5555L);

		verify(anomalyTypeService).getById(same(context), eq(-5555L));
		assertThat(response).isNotNull()
				.isPresent().get()
				.isEqualTo(AnomalyTypeResponse.builder()
						.setGroupCode("GR1").setCode("AT1").setI18nCode("gr1.at1")
						.build());

	}
}
