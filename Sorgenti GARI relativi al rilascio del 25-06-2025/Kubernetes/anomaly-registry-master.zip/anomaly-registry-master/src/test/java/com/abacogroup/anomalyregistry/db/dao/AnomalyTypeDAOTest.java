package com.abacogroup.anomalyregistry.db.dao;

import static org.hamcrest.MatcherAssert.assertThat;

import com.abacogroup.anomalyregistry.api.AnomalyTypeRes;
import com.abacogroup.anomalyregistry.bundle.BundleConstants;
import com.abacogroup.anomalyregistry.core.PojoBuilders;
import com.abacogroup.anomalyregistry.db.ntt.AnomalyTypeEntity;
import com.abacogroup.bundles.Constants;
import com.abacogroup.common.core.MyJdbi;
import com.abacogroup.common.core.ReqContext;
import com.abacogroup.jdbi.orderby.OrderByBuilder;
import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;
import java.util.List;
import java.util.Map;
import org.hamcrest.Matchers;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

@ExtendWith(DropwizardExtensionsSupport.class)
class AnomalyTypeDAOTest extends MyJdbi {

	private static final String currentUser = "AnomalyTypeDAOTest_u";
	private static final String tenantId = "AnomalyTypeDAOTest_t";

	private static final ReqContext reqContext = new ReqContext(tenantId, currentUser, "en");

	private static final Map<String, Object> testScriptParams = Map.of(
			"test_tenant", tenantId,
			"user_id", currentUser
	);

	private final AnomalyTypeDAO dao = this.getDAO(AnomalyTypeDAO.class);

	@Test
	void test_insert_idempotent() {

		getJdbi().useHandle(handle -> {
			handle.begin();

			List<AnomalyTypeRes> list1 = dao.searchAll(reqContext, null, OrderByBuilder.field("id"));
			assertThat(list1, Matchers.hasSize(0));

			List<AnomalyTypeEntity> input = List.of(
					PojoBuilders.anomalyTypeEntity(tenantId, "GC", "A").build(),
					PojoBuilders.anomalyTypeEntity(tenantId, "GC", "B").build(),
					PojoBuilders.anomalyTypeEntity(tenantId, "GC", "C").build(),
					PojoBuilders.anomalyTypeEntity(tenantId, "GC", "A").build(),
					PojoBuilders.anomalyTypeEntity(tenantId, "XX", "A").build()
			);

			dao.setAuditForInsert(currentUser, input);
			dao.insertBatch(input.toArray(AnomalyTypeEntity[]::new));

			List<AnomalyTypeRes> list2 = dao.searchAll(reqContext, null, OrderByBuilder.field("id"));
			assertThat(list2, Matchers.hasSize(4));
			handle.rollback();
		});
	}

	@Test
	void test_new_tenant() {

		var defaultReqCtx = new ReqContext(Constants.ALL_TENANTS, currentUser, "en");

		getJdbi().useHandle(handle -> {
			handle.begin();

			//GIVEN
			List<AnomalyTypeRes> list1 = dao.searchAll(defaultReqCtx, null, OrderByBuilder.field("id"));
			assertThat(list1, Matchers.hasSize(0));

			List<AnomalyTypeEntity> input = List.of(
					PojoBuilders.anomalyTypeEntity(Constants.ALL_TENANTS, "GC", "A").build(),
					PojoBuilders.anomalyTypeEntity(Constants.ALL_TENANTS, "GC", "B").build(),
					PojoBuilders.anomalyTypeEntity(Constants.ALL_TENANTS, "GC", "C").build()
			);
			dao.setAuditForInsert(currentUser, input);
			dao.insertBatch(input.toArray(AnomalyTypeEntity[]::new));

			List<AnomalyTypeRes> list2 = dao.searchAll(defaultReqCtx, null, OrderByBuilder.field("id"));
			assertThat(list2, Matchers.hasSize(3));

			//WHEN
			AnomalyTypeEntity audit = AnomalyTypeEntity.builder().build();
			dao.setAuditForInsert(BundleConstants.SYSTEM_USER, audit);
			dao.insertNewTenant(Constants.ALL_TENANTS, "new_tenant", audit);

			//THEN
			List<AnomalyTypeRes> list3 = dao.searchAll(
					new ReqContext("new_tenant", currentUser, "en"),
					null, OrderByBuilder.field("id"));

			assertThat(list3, Matchers.hasSize(3));

			handle.rollback();
		});
	}
}
