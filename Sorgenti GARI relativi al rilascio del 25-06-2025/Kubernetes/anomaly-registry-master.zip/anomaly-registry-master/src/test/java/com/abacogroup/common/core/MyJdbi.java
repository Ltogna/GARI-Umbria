package com.abacogroup.common.core;

import com.abacogroup.anomalyregistry.AnomalyRegistryConfiguration;
import com.abacogroup.anomalyregistry.TestAnomalyRegistryApplication;
import io.dropwizard.testing.ResourceHelpers;
import io.dropwizard.testing.junit5.DropwizardAppExtension;
import java.lang.reflect.Field;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.reflect.FieldUtils;
import org.jdbi.v3.core.Jdbi;
import org.jdbi.v3.core.locator.ClasspathSqlLocator;
import org.jdbi.v3.core.statement.SqlStatements;

/**
 * Abstract class per integration test di Service e DAO layer
 * <p>
 * - applica le migrazioni in automatico (se configurato)
 * <p>
 * - espone jdbi e getDAO
 */
public class MyJdbi {

	protected static DropwizardAppExtension<AnomalyRegistryConfiguration> EXT = new DropwizardAppExtension<>(
			TestAnomalyRegistryApplication.class,
			ResourceHelpers.resourceFilePath(System.getProperty("test_config_file", "test_config.yml"))
	);

	protected final TestAnomalyRegistryApplication app = EXT.getApplication();

	public static Jdbi getJdbi() {
		return ((TestAnomalyRegistryApplication) EXT.getApplication()).getJdbi();
	}

	public static AnomalyRegistryConfiguration getPartyRegistryConfiguration() {
		return EXT.getConfiguration();
	}

	protected static void setUnusedBindingAllowed(boolean allowed) {
		getJdbi().getConfig().get(SqlStatements.class).setUnusedBindingAllowed(allowed);
	}

	/**
	 * esegue gli script, ma con bindMap
	 */
	protected static void execSqlFiles(Class clazz, List<String> scripts, Map<String, Object> args) {
		Map<String, Object> params = new HashMap<>(Optional.ofNullable(args).orElse(new HashMap<>()));

		if (!scripts.isEmpty()) {
			String name = String.format("%s.", clazz.getName());
			setUnusedBindingAllowed(true);
			getJdbi().useTransaction(handle -> {
				scripts.stream().forEach(s -> {
					String sqlFileAsString = ClasspathSqlLocator.removingComments().locate(name + s);
					Arrays.stream(sqlFileAsString.split(";"))
							.filter(StringUtils::isNotBlank)
							.forEach(str -> handle.createUpdate(str).bindMap(params).execute());
				});
			});
		}
	}

	protected <T> T getDAO(Class<T> classDAO) {
		return (T) app.getJdbi().onDemand(classDAO);
	}

	@SuppressWarnings("unchecked")
	protected <T> T getService(Class<T> clazz) {
		return (T) Optional
				.ofNullable(app.getServices().get(clazz))
				.orElseThrow(() -> new RuntimeException(
						String.format("Error loading %s! Did you call by interface? Implementation required", clazz.getSimpleName())));
	}

	@SuppressWarnings("unchecked")
	protected <T, M> void injectMock(T target, M mock) {
		try {
			Class<T> targetClazz = (Class<T>) target.getClass();
			Field field = Arrays.stream(FieldUtils.getAllFields(targetClazz))
					.filter(f -> f.getType().isAssignableFrom(mock.getClass()))
					.findFirst()
					.orElseThrow();
			FieldUtils.writeField(target, field.getName(), mock, true);
		} catch (IllegalAccessException ex) {
			throw new RuntimeException("errore in inject", ex);
		}
	}

}
