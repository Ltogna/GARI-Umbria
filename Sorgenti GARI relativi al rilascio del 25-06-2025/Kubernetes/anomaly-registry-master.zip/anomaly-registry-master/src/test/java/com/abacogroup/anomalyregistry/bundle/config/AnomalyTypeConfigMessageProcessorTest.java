package com.abacogroup.anomalyregistry.bundle.config;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.hasItems;
import static org.hamcrest.Matchers.hasSize;
import static org.hamcrest.Matchers.notNullValue;
import static org.mockito.BDDMockito.given;

import java.nio.file.Path;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;
import java.util.function.Supplier;
import java.util.stream.Collectors;

import org.hamcrest.CoreMatchers;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.Mockito;

import com.abacogroup.anomalyregistry.db.dao.AnomalyTypeDAO;
import com.abacogroup.anomalyregistry.db.ntt.AnomalyTypeEntity;
import com.abacogroup.bundles.initializer.impl.FileSupport;
import com.abacogroup.bundles.listener.configdata.ConfigDataMessage;
import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.SneakyThrows;

class AnomalyTypeConfigMessageProcessorTest {

	private final AnomalyTypeDAO anomalyTypeDAO = Mockito.spy(AnomalyTypeDAO.class);
	private final ObjectMapper objectMapper = new ObjectMapper();

	private final AnomalyTypeConfigMessageProcessor processor = new AnomalyTypeConfigMessageProcessor(anomalyTypeDAO, objectMapper);

	private final Supplier<Path> thisFolder = () -> Path.of(
			"src/test/resources",
			this.getClass().getName().replaceAll("\\.", "/"));

	@Test
	@SneakyThrows
	void test_process_add() {
		given(anomalyTypeDAO.getCurrentTimestamp()).willReturn(LocalDateTime.now());

		List<Path> paths = FileSupport.listFilesRecursive(thisFolder.get());
		ConfigDataMessage msg = new ConfigDataMessage();
		msg.setConfigFiles(paths);
		msg.setTenantId("some_tenant");

		processor.onMessage(msg);

		ArgumentCaptor<AnomalyTypeEntity[]> entities = ArgumentCaptor.forClass(AnomalyTypeEntity[].class);
		Mockito.verify(anomalyTypeDAO, Mockito.times(1))
				.insertBatch(entities.capture());

		assertThat(Arrays.asList(entities.getAllValues().get(0)), hasSize(6));

		var map = Arrays.asList(entities.getAllValues().get(0))
				.stream()
				.collect(Collectors.groupingBy(AnomalyTypeEntity::getGroupCode));
		assertThat(map.keySet(), hasItems("app.something_else", "app.something"));

		var e = map.get("app.something_else").get(0);
		assertThat(e.getDtInsert(), notNullValue());
		assertThat(e.getTenantId(), CoreMatchers.is("some_tenant"));

	}
}
