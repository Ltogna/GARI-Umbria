package com.abacogroup.anomalyregistry.core;

import com.abacogroup.anomalyregistry.api.AnomalySearchRes;
import com.abacogroup.anomalyregistry.api.AnomalySearchRes.AnomalySearchResBuilder;
import com.abacogroup.anomalyregistry.api.AnomalyTypeRes;
import com.abacogroup.anomalyregistry.api.AnomalyTypeRes.AnomalyTypeResBuilder;
import com.abacogroup.anomalyregistry.api.dto.AnomalyEventDto;
import com.abacogroup.anomalyregistry.api.dto.AnomalyEventDto.AnomalyEventDtoBuilder;
import com.abacogroup.anomalyregistry.api.dto.AnomalyEventDto.AnomalyTypeDto;
import com.abacogroup.anomalyregistry.api.dto.AnomalyEventDto.AnomalyTypeDto.AnomalyTypeDtoBuilder;
import com.abacogroup.anomalyregistry.api.req.AnomalyReq;
import com.abacogroup.anomalyregistry.api.req.AnomalyReq.AnomalyReqBuilder;
import com.abacogroup.anomalyregistry.api.v1.AnomalySearchResponse;
import com.abacogroup.anomalyregistry.api.v1.AnomalySearchResponse.AnomalySearchResponseBuilder;
import com.abacogroup.anomalyregistry.api.v1.AnomalyTypeResponse;
import com.abacogroup.anomalyregistry.api.v1.AnomalyTypeResponse.AnomalyTypeResponseBuilder;
import com.abacogroup.anomalyregistry.db.ntt.AnomalyTypeEntity;
import com.abacogroup.anomalyregistry.db.ntt.AnomalyTypeEntity.AnomalyTypeEntityBuilder;

public class PojoBuilders {

	public static AnomalySearchResponseBuilder<?, ?> completeAnomalyResponse() {
		return completeAnomalyResponse(completeAnomalyTypeResponse().build());
	}

	public static AnomalySearchResponseBuilder<?, ?> completeAnomalyResponse(AnomalyTypeResponse type) {
		return AnomalySearchResponse.builder()
				.setId(123L)
				.setEntityCode("PARTY")
				.setEntityId("321")
				.setType(type);
	}

	public static AnomalyTypeResponseBuilder<?, ?> completeAnomalyTypeResponse() {
		return AnomalyTypeResponse.builder()
				.setId(456L)
				.setCode("AT1")
				.setGroupCode("GR1");
	}

	public static AnomalySearchResBuilder<?, ?> completeAnomalyRes() {
		return completeAnomalyRes(completeAnomalyTypeRes().build());
	}

	public static AnomalySearchResBuilder<?, ?> completeAnomalyRes(AnomalyTypeRes type) {
		return AnomalySearchRes.builder()
				.setId(123L)
				.setEntityCode("PARTY")
				.setEntityId("321")
				.setType(type);
	}

	public static AnomalyTypeResBuilder<?, ?> completeAnomalyTypeRes() {
		return AnomalyTypeRes.builder()
				.setId(456L)
				.setCode("AT1")
				.setGroupCode("GR1");
	}

	public static AnomalyEventDtoBuilder<?, ?> completeAnomalyEventDto() {
		return completeAnomalyEventDto(completeAnomalyTypeDto().build());
	}

	public static AnomalyEventDtoBuilder<?, ?> completeAnomalyEventDto(AnomalyTypeDto type) {
		return AnomalyEventDto.builder()
				.setId(123L)
				.setEntityCode("PARTY")
				.setEntityId("321")
				.setType(type);
	}

	public static AnomalyTypeDtoBuilder<?, ?> completeAnomalyTypeDto() {
		return AnomalyTypeDto.builder()
				.setId(456L)
				.setCode("AT1")
				.setGroupCode("GR1");
	}

	public static AnomalyTypeEntityBuilder<?, ?> anomalyTypeEntity(String tenantId, String groupCode, String code) {
		return AnomalyTypeEntity.builder()
				.setGroupCode(groupCode)
				.setCode(code)
				.setTenantId(tenantId);
	}

	public static AnomalyReqBuilder<?, ?> anomalyRequest(String typeGroupCode, String typeCode, String entityCode, String entityId) {
		return AnomalyReq.builder()
				.setTypeGroupCode(typeGroupCode)
				.setTypeCode(typeCode)
				.setEntityCode(entityCode)
				.setEntityId(entityId);
	}
}
