package com.abacogroup.anomalyregistry.resources.pub;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoMoreInteractions;

import com.abacogroup.anomalyregistry.AnmParams;
import com.abacogroup.anomalyregistry.api.v1.AnomalyTypeResponse;
import com.abacogroup.anomalyregistry.api.v1.req.AnomalyTypeSearchRequest;
import com.abacogroup.anomalyregistry.core.AnomalyTypeServiceV1;
import com.abacogroup.anomalyregistry.resources.WebCliHelper;
import com.abacogroup.common.core.ReqContext;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;
import io.dropwizard.testing.junit5.ResourceExtension;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mockito;

@ExtendWith(DropwizardExtensionsSupport.class)
@Slf4j
class AnomalyTypeV1ResourceTest {

	public static final String PATH = AnmParams.MASTER_PUBLIC_PATH + "/anomaly-types";
	private final AnomalyTypeServiceV1 anomalyTypeService = Mockito.mock(AnomalyTypeServiceV1.class);

	private final ResourceExtension EXT = WebCliHelper.createEXT(new AnomalyTypeV1Resource(anomalyTypeService));

	private final ObjectMapper mapper = new ObjectMapper();

	@Test
	void test_search() {
		var searchParams = new AnomalyTypeSearchRequest().setGroupCode("GR1").setCode("ATx").setI18nCode("gr1");
		Map<String, Object> beanMap = mapper.convertValue(searchParams, Map.class);
		var expectedResults = List.of(
				AnomalyTypeResponse.builder()
						.setGroupCode("GR1").setCode("AT1").setI18nCode("gr1.at1")
						.build(),
				AnomalyTypeResponse.builder()
						.setGroupCode("GR1").setCode("AT2").setI18nCode("gr1.at2")
						.build());
		given(anomalyTypeService.searchAll(any(), any())).willReturn(expectedResults);

		List<?> response = WebCliHelper.executeGet(EXT, PATH, beanMap, WebCliHelper.BASIC_CREDENTIALS, List.class);

		assertThat(response).isNotNull().hasSize(2);
		assertThat(response.stream().map(c -> mapper.convertValue(c, AnomalyTypeResponse.class)))
				.containsAll(expectedResults);
		var requestArgumentCaptor = ArgumentCaptor.forClass(AnomalyTypeSearchRequest.class);
		ArgumentCaptor<ReqContext> reqCtxCaptor = ArgumentCaptor.forClass(ReqContext.class);
		verify(anomalyTypeService, times(1))
				.searchAll(reqCtxCaptor.capture(), requestArgumentCaptor.capture());
		verifyNoMoreInteractions(anomalyTypeService);
		var searchRequest = requestArgumentCaptor.getValue();
		assertThat(searchRequest).isEqualTo(searchParams);
		ReqContext reqContext = reqCtxCaptor.getValue();
		assertThat(reqContext.getTenantId()).isEqualTo("master");
		assertThat(reqContext.getLang()).isEqualTo("en");
		assertThat(reqContext.getUsername()).isEqualTo(WebCliHelper.BASIC_USERNAME);
	}

	@Test
	void test_getById() {
		Long id = 123L;
		String path = String.format("%s/%s", PATH, id);
		var expected = AnomalyTypeResponse.builder()
				.setGroupCode("GR1").setCode("AT1").setI18nCode("gr1.at1")
				.build();
		given(anomalyTypeService.getById(any(), anyLong())).willReturn(Optional.of(expected));

		var response = WebCliHelper.executeGet(EXT, path, null, WebCliHelper.BASIC_CREDENTIALS, AnomalyTypeResponse.class);

		ArgumentCaptor<ReqContext> reqCtxCaptor = ArgumentCaptor.forClass(ReqContext.class);

		assertThat(response).isNotNull().isEqualTo(expected);
		verify(anomalyTypeService, times(1)).getById(reqCtxCaptor.capture(), eq(id));
		verifyNoMoreInteractions(anomalyTypeService);
		ReqContext reqContext = reqCtxCaptor.getValue();
		assertThat(reqContext.getTenantId()).isEqualTo("master");
		assertThat(reqContext.getLang()).isEqualTo("en");
		assertThat(reqContext.getUsername()).isEqualTo(WebCliHelper.BASIC_USERNAME);
	}

}
