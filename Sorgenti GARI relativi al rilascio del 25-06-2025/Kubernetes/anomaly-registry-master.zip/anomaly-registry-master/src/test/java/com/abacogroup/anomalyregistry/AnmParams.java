package com.abacogroup.anomalyregistry;

import java.time.LocalDate;
import java.time.LocalDateTime;

public class AnmParams {

	public static final String TENANT_DEFAULT_CODE = "master";

	public static final String MASTER_PATH = "/master/api-priv/v1";
	public static final String MASTER_PUBLIC_PATH = "/master/public/v1";

	public static final LocalDateTime active = LocalDate.of(9999, 12, 31)
			.atTime(23, 59, 59, 9);

}
