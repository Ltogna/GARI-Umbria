package com.abacogroup.anomalyregistry.core.impl;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.ArgumentMatchers.same;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoMoreInteractions;

import com.abacogroup.anomalyregistry.api.AnomalySearchRes;
import com.abacogroup.anomalyregistry.api.AnomalyTypeRes;
import com.abacogroup.anomalyregistry.api.req.AnomalyReq;
import com.abacogroup.anomalyregistry.api.req.AnomalySearchReq;
import com.abacogroup.anomalyregistry.api.v1.AnomalySearchResponse;
import com.abacogroup.anomalyregistry.api.v1.AnomalyTypeResponse;
import com.abacogroup.anomalyregistry.api.v1.req.AnomalyRequest;
import com.abacogroup.anomalyregistry.api.v1.req.AnomalySearchRequest;
import com.abacogroup.anomalyregistry.core.AnomalyService;
import com.abacogroup.common.core.ReqContext;
import java.util.List;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

class AnomalyServiceV1ImplTest {

	private static final ReqContext context = new ReqContext("tenant1", "userX", "en");

	@Mock
	private AnomalyService anomalyService;
	@InjectMocks
	private AnomalyServiceV1Impl anomalyServiceV1;

	@Captor
	private ArgumentCaptor<List<AnomalyReq>> reqsCaptor;

	@Captor
	private ArgumentCaptor<AnomalySearchReq> searchReqCaptor;

	private AutoCloseable closeable;

	@BeforeEach
	public void openMocks() {
		closeable = MockitoAnnotations.openMocks(this);
	}

	@AfterEach
	public void releaseMocks() throws Exception {
		closeable.close();
	}

	// ----- search -----
	@Test
	void test_search_ok() {
		var searchRequest = new AnomalySearchRequest()
				.setGroupCode(List.of("GR1", "GR2"))
				.setTypeCode(List.of("ATx", "ATy"))
				.setTypeId(List.of(123L, 456L, 789L))
				.setEntityId(List.of("11", "22"));
		given(anomalyService.search(any(), anyString(), any()))
				.willReturn(List.of(
						AnomalySearchRes.builder()
								.setType(AnomalyTypeRes.builder()
										.setGroupCode("GR1").setCode("AT1").setI18nCode("gr1.at1")
										.build())
								.setId(1L)
								.setEntityCode("PARTY")
								.setEntityId("11")
								.build(),
						AnomalySearchRes.builder()
								.setType(AnomalyTypeRes.builder()
										.setGroupCode("GR1").setCode("AT2").setI18nCode("gr1.at2")
										.build())
								.setId(2L)
								.setEntityCode("PARTY")
								.setEntityId("22")
								.build()
				));

		var responseList = anomalyServiceV1.search(context, "PARTY", searchRequest);

		verify(anomalyService).search(same(context), eq("PARTY"), searchReqCaptor.capture());
		assertThat(searchReqCaptor.getValue()).isNotNull()
				.usingRecursiveComparison()
				.isEqualTo(searchRequest);
		assertThat(responseList).isNotNull().hasSize(2)
				.containsExactly(
						AnomalySearchResponse.builder()
								.setType(AnomalyTypeResponse.builder()
										.setGroupCode("GR1").setCode("AT1").setI18nCode("gr1.at1")
										.build())
								.setId(1L)
								.setEntityCode("PARTY")
								.setEntityId("11")
								.build(),
						AnomalySearchResponse.builder()
								.setType(AnomalyTypeResponse.builder()
										.setGroupCode("GR1").setCode("AT2").setI18nCode("gr1.at2")
										.build())
								.setId(2L)
								.setEntityCode("PARTY")
								.setEntityId("22")
								.build()
				);

	}

	// ----- add -----
	@Test
	void test_add_ok() {
		var requests = List.of(
				AnomalyRequest.builder().setTypeGroupCode("GR1").setTypeCode("AT1").setEntityCode("PARTY").setEntityId("18").build(),
				AnomalyRequest.builder().setTypeGroupCode("GR2").setTypeCode("AT2").setEntityCode("CROP").setEntityId("XYZ").build()
		);

		anomalyServiceV1.add(context, requests);

		verify(anomalyService).add(eq(context), reqsCaptor.capture());
		assertThat(reqsCaptor.getValue()).isNotNull()
				.hasSize(2)
				.containsExactly(
						AnomalyReq.builder().setTypeGroupCode("GR1").setTypeCode("AT1").setEntityCode("PARTY").setEntityId("18").build(),
						AnomalyReq.builder().setTypeGroupCode("GR2").setTypeCode("AT2").setEntityCode("CROP").setEntityId("XYZ").build()
				);
		verifyNoMoreInteractions(anomalyService);
	}

	// ----- expire -----
	@Test
	void test_expire_ok() {
		var requests = List.of(
				AnomalyRequest.builder().setTypeGroupCode("GR1").setTypeCode("AT1").setEntityCode("PARTY").setEntityId("18").build(),
				AnomalyRequest.builder().setTypeGroupCode("GR2").setTypeCode("AT2").setEntityCode("CROP").setEntityId("XYZ").build()
		);

		anomalyServiceV1.expire(context, requests);

		verify(anomalyService).expire(eq(context), reqsCaptor.capture());
		assertThat(reqsCaptor.getValue()).isNotNull()
				.hasSize(2)
				.containsExactly(
						AnomalyReq.builder().setTypeGroupCode("GR1").setTypeCode("AT1").setEntityCode("PARTY").setEntityId("18").build(),
						AnomalyReq.builder().setTypeGroupCode("GR2").setTypeCode("AT2").setEntityCode("CROP").setEntityId("XYZ").build()
				);
		verifyNoMoreInteractions(anomalyService);
	}

	// ----- expireAllById -----
	@Test
	void test_expireAllById_ok() {
		var requests = List.of(1L, 2L, 3L);

		anomalyServiceV1.expireAllById(context, requests);

		verify(anomalyService).expireAllById(same(context), same(requests));
		verifyNoMoreInteractions(anomalyService);
	}
}
