package com.abacogroup.anomalyregistry.bundle.config;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.hasSize;

import java.nio.file.Path;
import java.util.Arrays;
import java.util.List;
import java.util.function.Supplier;

import org.hamcrest.CoreMatchers;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.Mockito;

import com.abacogroup.anomalyregistry.db.dao.I18nDAO;
import com.abacogroup.anomalyregistry.db.ntt.I18nEntity;
import com.abacogroup.common.bundle.config.I18nProcessor;
import com.abacogroup.common.bundle.config.I18nProcessor.I18nContext;

class I18nProcessorTest {

	private final Supplier<Path> thisFolder = () -> Path.of(
			"src/test/resources",
			this.getClass().getName().replaceAll("\\.", "/"));

	@Test
	void test_process() {

		I18nDAO i18nDAO = Mockito.mock(I18nDAO.class);
		String tenantId = "some_tenant";

		Path path = Path.of(thisFolder.get().toString(), "i18n.jsonl");

		new I18nProcessor(i18nDAO)
				.addContent(tenantId,
						path,
						I18nContext.builder()
								.setFieldName("code")
								.setTableName("anm_anomaly_types")
								.build(),
						I18nContext.builder()
								.setFieldName("groupCode")
								.setTableName("anm_anomaly_types2")
								.build()

				);

		ArgumentCaptor<I18nEntity[]> argumentCaptor = ArgumentCaptor.forClass(I18nEntity[].class);
		Mockito.verify(i18nDAO, Mockito.times(1))
				.insertBatch(argumentCaptor.capture());

		List<I18nEntity> list = Arrays.asList(argumentCaptor.getAllValues().get(0));

		assertThat(list, hasSize(6));
		assertThat(list.get(2).getLang(), CoreMatchers.is("en"));
		assertThat(list.get(2).getI18nText(), CoreMatchers.is("pi_si"));

		assertThat(list.get(2).getI18nValue(), CoreMatchers.is("PC"));
		assertThat(list.get(2).getFieldName(), CoreMatchers.is("code"));

		assertThat(list.get(2).getTableName(), CoreMatchers.is("anm_anomaly_types"));
		assertThat(list.get(2).getTenantId(), CoreMatchers.is("some_tenant"));

	}

	@Test
	void test_process_err() {

		I18nDAO i18nDAO = Mockito.mock(I18nDAO.class);
		String tenantId = "some_tenant";

		Path path = Path.of(thisFolder.get().toString(), "i18n_err_1.jsonl");

		new I18nProcessor(i18nDAO)
				.addContent(tenantId,
						path,
						I18nContext.builder()
								.setFieldName("code")
								.setTableName("anm_anomaly_types")
								.build()

				);

		ArgumentCaptor<I18nEntity> argumentCaptor = ArgumentCaptor.forClass(I18nEntity.class);
		Mockito.verify(i18nDAO, Mockito.times(1))
				.insertBatch(argumentCaptor.capture());

		List<I18nEntity> list = argumentCaptor.getAllValues();

		assertThat(list, hasSize(1));

	}

	@Test
	void test_process_err_2() {
		I18nDAO i18nDAO = Mockito.mock(I18nDAO.class);
		String tenantId = "some_tenant";

		Path path = Path.of(thisFolder.get().toString(), "i18n_err_1.jsonl");
		new I18nProcessor(i18nDAO)
				.addContent(tenantId,
						path,
						I18nContext.builder()
								.setFieldName("groupCode")
								.setTableName("anm_anomaly_types2")
								.build()
				);

		ArgumentCaptor<I18nEntity[]> argumentCaptor = ArgumentCaptor.forClass(I18nEntity[].class);
		Mockito.verify(i18nDAO, Mockito.times(1))
				.insertBatch(argumentCaptor.capture());

		List<I18nEntity> list = Arrays.asList(argumentCaptor.getAllValues().get(0));

		assertThat(list, hasSize(0));

	}
}
