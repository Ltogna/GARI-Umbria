package com.abacogroup.anomalyregistry.bundle.config;

import static org.assertj.core.api.Assertions.assertThat;

import java.nio.file.Path;
import java.util.List;
import java.util.Map;
import java.util.function.Supplier;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

import com.abacogroup.anomalyregistry.AnmParams;
import com.abacogroup.bundles.initializer.impl.FileSupport;
import com.abacogroup.bundles.listener.configdata.ConfigDataMessage;
import com.abacogroup.common.core.MyJdbi;

import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@ExtendWith(DropwizardExtensionsSupport.class)
class AnomalyTypeConfigMessageProcessorIT extends MyJdbi {

	private static final String TENANT_ID = AnomalyTypeConfigMessageProcessorIT.class.getSimpleName() + "_t";
	private static final String CURRENT_USER = AnomalyTypeConfigMessageProcessorIT.class.getSimpleName() + "_u";

	private static final Map<String, Object> testScriptParams = Map.of(
			"test_tenant", TENANT_ID,
			"user_id", CURRENT_USER
	);

	private final AnomalyTypeConfigMessageProcessor processor = getService(AnomalyTypeConfigMessageProcessor.class);

	private final Supplier<Path> thisFolder = () -> Path.of(
			"src/test/resources",
			(this.getClass().getName() + "." + processor.getDomainName()).replaceAll("\\.", "/"));

	@BeforeAll
	@AfterAll
	public static void beforeAll() {
		execSqlFiles(AnmParams.class, List.of("rollback"), testScriptParams);
	}

	@Test
	@SneakyThrows
	void test_givenDeleteFile_process_ok() {
		getJdbi().useHandle(handle -> {
			handle.begin();
			List<String> initScripts = List.of("add_anomaly_types", "add_anomalies");
			execSqlFiles(this.getClass(), initScripts, testScriptParams);

			List<Path> paths = FileSupport.listFilesRecursive(thisFolder.get());
			ConfigDataMessage msg = new ConfigDataMessage();
			msg.setConfigFiles(paths);
			msg.setTenantId(TENANT_ID);

			processor.onMessage(msg);

			List<Long> notDeleted = handle.select("select id from anm_anomaly_types where CURRENT_TIMESTAMP between dt_insert and dt_delete")
					.mapTo(Long.class)
					.list();
			assertThat(notDeleted).hasSize(2)
					.containsExactlyInAnyOrder(-1001L, -1003L);

			List<Long> deleted = handle.select("select id from anm_anomaly_types where CURRENT_TIMESTAMP > dt_delete")
					.mapTo(Long.class)
					.list();
			assertThat(deleted).hasSize(5)
					.containsExactlyInAnyOrder(-1002L, -1014L, -1004L, -1005L, -1006L);

			handle.rollback();
		});

	}
}
