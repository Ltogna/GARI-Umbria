package com.abacogroup.anomalyregistry.core.impl;

import static com.abacogroup.anomalyregistry.core.PojoBuilders.completeAnomalyEventDto;
import static com.abacogroup.anomalyregistry.core.impl.AnomalyEventProducerImpl.EXCHANGE;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.verify;

import com.abacogroup.anomalyregistry.TestAnomalyRegistryApplication;
import com.abacogroup.anomalyregistry.api.dto.AnomalyEventDto;
import com.abacogroup.anomalyregistry.core.AnomalyEventProducer.AnomalyEventType;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.rabbitmq.client.AMQP;
import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import lombok.SneakyThrows;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;

class AnomalyEventProducerImplTest {

	public static final String TENANT = "tenant1";

	@Mock
	private Channel channel;
	@Mock
	private Connection connection;
	@Spy
	private ObjectMapper objectMapper = TestAnomalyRegistryApplication.getObjectMapper();

	@InjectMocks
	private AnomalyEventProducerImpl anomalyEventProducer;

	@Captor
	private ArgumentCaptor<byte[]> bodyCaptor;

	private AutoCloseable closeable;

	@BeforeEach
	public void openMocks() {
		closeable = MockitoAnnotations.openMocks(this);
	}

	@AfterEach
	public void releaseMocks() throws Exception {
		closeable.close();
	}

	// ----- pushNewAnomalyEvent -----
	@Test
	@SneakyThrows
	void test_pushNewAnomalyEvent_ok() {
		given(connection.createChannel()).willReturn(channel);
		AnomalyEventDto message = completeAnomalyEventDto().build();
		byte[] expectedBody = objectMapper.writeValueAsBytes(message);

		anomalyEventProducer.pushAnomalyEvent(message, TENANT, AnomalyEventType.NEW);

		verify(channel).basicPublish(eq(EXCHANGE), eq("anomalies.new"), any(AMQP.BasicProperties.class), bodyCaptor.capture());
		assertThat(bodyCaptor.getValue()).isEqualTo(expectedBody);
	}

	// ----- pushExpiredAnomalyEvent -----
	@Test
	@SneakyThrows
	void test_pushExpiredAnomalyEvent_ok() {
		given(connection.createChannel()).willReturn(channel);
		AnomalyEventDto message = completeAnomalyEventDto().build();
		byte[] expectedBody = objectMapper.writeValueAsBytes(message);

		anomalyEventProducer.pushAnomalyEvent(message, TENANT, AnomalyEventType.EXPIRED);

		verify(channel).basicPublish(eq(EXCHANGE), eq("anomalies.expired"), any(AMQP.BasicProperties.class), bodyCaptor.capture());
		assertThat(bodyCaptor.getValue()).isEqualTo(expectedBody);
	}
}
