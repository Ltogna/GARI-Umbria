package com.abacogroup.anomalyregistry.bundle.tenant;

import static com.abacogroup.bundles.Constants.ALL_TENANTS;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.notNullValue;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.times;

import com.abacogroup.anomalyregistry.db.dao.AnomalyTypeDAO;
import com.abacogroup.anomalyregistry.db.ntt.AnomalyTypeEntity;
import com.abacogroup.bundles.listener.tenant.TenantMessage;
import java.time.LocalDateTime;
import org.hamcrest.CoreMatchers;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.Mockito;

class AnomalyTypeTenantMessageProcessorTest {

	private final AnomalyTypeDAO anomalyTypeDAO = Mockito.spy(AnomalyTypeDAO.class);

	private final AnomalyTypeTenantMessageProcessor processor = new AnomalyTypeTenantMessageProcessor(anomalyTypeDAO);

	@Test
	void test_process() {
		given(anomalyTypeDAO.getCurrentTimestamp()).willReturn(LocalDateTime.now());
		processor.onMessage(new TenantMessage().setTenantId("some_tenant"));
		ArgumentCaptor<AnomalyTypeEntity> argumentCaptor = ArgumentCaptor.forClass(AnomalyTypeEntity.class);
		Mockito.verify(anomalyTypeDAO, times(1))
				.insertNewTenant(eq(ALL_TENANTS), eq("some_tenant"), argumentCaptor.capture());
		assertThat(argumentCaptor.getValue().getDtInsert(), CoreMatchers.is(notNullValue()));
	}
}
