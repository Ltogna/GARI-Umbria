package com.abacogroup.anomalyregistry.core.impl;

import static org.assertj.core.api.AssertionsForClassTypes.tuple;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import com.abacogroup.anomalyregistry.AnmParams;
import com.abacogroup.anomalyregistry.api.AnomalySearchRes;
import com.abacogroup.anomalyregistry.api.AnomalyTypeRes;
import com.abacogroup.anomalyregistry.api.dto.AnomalyEventDto;
import com.abacogroup.anomalyregistry.api.req.AnomalyReq;
import com.abacogroup.anomalyregistry.api.req.AnomalySearchReq;
import com.abacogroup.anomalyregistry.core.AnomalyEventProducer;
import com.abacogroup.anomalyregistry.core.AnomalyEventProducer.AnomalyEventType;
import com.abacogroup.anomalyregistry.core.AnomalyService;
import com.abacogroup.anomalyregistry.core.PojoBuilders;
import com.abacogroup.anomalyregistry.core.exceptions.AnomalyTypeException;
import com.abacogroup.anomalyregistry.db.dao.AnomalyDAO;
import com.abacogroup.anomalyregistry.db.ntt.AnomalyEntity;
import com.abacogroup.common.core.MyJdbi;
import com.abacogroup.common.core.ReqContext;
import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.assertj.core.groups.Tuple;
import org.hamcrest.CoreMatchers;
import org.hamcrest.MatcherAssert;
import org.hamcrest.Matchers;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;

@Slf4j
@ExtendWith(DropwizardExtensionsSupport.class)
class AnomalyServiceImplTest extends MyJdbi {

	private static final String TENANT_ID = "AnomalyServiceImplTest_t";
	private static final String CURRENT_USER = "AnomalyServiceImplTest_u";
	private static final ReqContext context = new ReqContext(TENANT_ID, CURRENT_USER, "en");
	private static final Map<String, Object> testScriptParams = Map.of(
			"test_tenant", TENANT_ID,
			"user_id", CURRENT_USER
	);

	private final AnomalyService service = getService(AnomalyServiceImpl.class);
	private final AnomalyDAO dao = getDAO(AnomalyDAO.class);
	private final AnomalyEventProducer anomalyEventProducer = mock(AnomalyEventProducer.class);

	@BeforeEach
	@AfterEach
	public void beforeAll() {
		execSqlFiles(AnmParams.class, List.of("rollback"), testScriptParams);
	}

	@BeforeEach
	public void mockProducer() {
		injectMock(service, anomalyEventProducer);
	}

	// ----- searchAll -----
	@Test
	void test_search_ok() {
		getJdbi().useHandle(handle -> {
			handle.begin();
			List<String> initScripts = List.of("base_anomaly", "add_anomalies");
			execSqlFiles(this.getClass(), initScripts, testScriptParams);

			String entityCodeItem = "ITEM";
			String entityCodeParty = "PARTY";

			List<AnomalySearchRes> responseList;

			responseList = service.search(context, entityCodeItem, new AnomalySearchReq());
			org.assertj.core.api.Assertions.assertThat(responseList).describedAs("by entity Code")
					.isNotNull().hasSize(3);

			responseList = service.search(context, entityCodeParty, new AnomalySearchReq());
			org.assertj.core.api.Assertions.assertThat(responseList).describedAs("by entity Code")
					.isNotNull().hasSize(1)
					.extracting(AnomalySearchRes::getId)
					.containsExactlyInAnyOrder(-105L);

			responseList = service.search(context, entityCodeItem, new AnomalySearchReq()
					.setEntityId(List.of("12")));
			org.assertj.core.api.Assertions.assertThat(responseList).describedAs("by entity ID")
					.isNotNull().hasSize(2);

			responseList = service.search(context, entityCodeItem, new AnomalySearchReq()
					.setTypeId(List.of(-3L)));
			org.assertj.core.api.Assertions.assertThat(responseList).describedAs("by type ID")
					.isNotNull().hasSize(1)
					.extracting(AnomalySearchRes::getId)
					.containsExactlyInAnyOrder(-103L);

			responseList = service.search(context, entityCodeItem, new AnomalySearchReq()
					.setGroupCode(List.of("GR1")));
			org.assertj.core.api.Assertions.assertThat(responseList).describedAs("by group Code")
					.isNotNull().hasSize(2)
					.extracting(AnomalySearchRes::getId)
					.containsExactlyInAnyOrder(-101L, -104L);

			responseList = service.search(context, entityCodeItem, new AnomalySearchReq()
					.setTypeCode(List.of("AT3")));
			org.assertj.core.api.Assertions.assertThat(responseList).describedAs("by anomalyType Code")
					.isNotNull().hasSize(1)
					.extracting(AnomalySearchRes::getId)
					.containsExactlyInAnyOrder(-103L);

			responseList = service.search(context, entityCodeItem, new AnomalySearchReq()
					.setTypeCode(List.of("AT1")).setGroupCode(List.of("GR1")));
			org.assertj.core.api.Assertions.assertThat(responseList).describedAs("by entity Code, typeCode , groupCode")
					.isNotNull().hasSize(1);

			responseList = service.search(context, entityCodeItem, new AnomalySearchReq()
					.setGroupCode(List.of("GR2")));
			org.assertj.core.api.Assertions.assertThat(responseList).describedAs("by entityCode, groupCode")
					.isNotNull().hasSize(1)
					.extracting(AnomalySearchRes::getType)
					.containsExactlyInAnyOrder(AnomalyTypeRes.builder().setId(-3L).setCode("AT3").setI18nCode("at3 en").setGroupCode("GR2").build());
			handle.rollback();
		});
	}

	@Test
	@SneakyThrows
	void test_insert() {
		getJdbi().useHandle(handle -> {
			handle.begin();

			List<String> initScripts = List.of("base_anomaly");
			execSqlFiles(this.getClass(), initScripts, testScriptParams);
			ArgumentCaptor<AnomalyEventDto> anomalyEventDtoCaptor = ArgumentCaptor.forClass(AnomalyEventDto.class);

			List<AnomalyReq> anomalies = List.of(
					PojoBuilders.anomalyRequest("GR1", "AT1", "PARTY", "2").build(),
					PojoBuilders.anomalyRequest("GR1", "AT1", "ITEM", "9").build(),
					PojoBuilders.anomalyRequest("GR1", "AT1", "ITEM", "8").build());

			service.add(context, anomalies);

			assertThat(dao.countAll(TENANT_ID), CoreMatchers.is(3L));

			service.add(context, new ArrayList<>());
			assertThat(dao.countAll(TENANT_ID), CoreMatchers.is(3L));

			// duplicated anomaly
			List<AnomalyReq> existing_anomalies = List.of(
					PojoBuilders.anomalyRequest("GR1", "AT1", "PARTY", "2").build(),
					PojoBuilders.anomalyRequest("GR1", "AT1", "ITEM", "8").build());

			service.add(context, existing_anomalies);

			assertThat("duplicates are not inserted", dao.countAll(TENANT_ID), CoreMatchers.is(3L));

			// invalid anomalyType
			List<AnomalyReq> anomalies2 = List.of(
					PojoBuilders.anomalyRequest("GR0", "AT0", "ITEM", "8").build());

			AnomalyTypeException ex = Assertions.assertThrows(AnomalyTypeException.class,
					() -> {
						service.add(context, anomalies2);
					});
			MatcherAssert.assertThat(ex, Matchers.notNullValue());
			MatcherAssert.assertThat(ex.getCode(), CoreMatchers.is(AnomalyTypeException.ANOMALY_TYPE_NOT_FOUND));

			assertThat(dao.countAll(TENANT_ID), CoreMatchers.is(3L));

			verify(anomalyEventProducer, times(3))
					.pushAnomalyEvent(anomalyEventDtoCaptor.capture(), eq(TENANT_ID), eq(AnomalyEventType.NEW));
			org.assertj.core.api.Assertions.assertThat(anomalyEventDtoCaptor.getAllValues()).hasSize(3)
					.extracting(a -> a.getType().getGroupCode(), a -> a.getType().getCode(), AnomalyEventDto::getEntityCode, AnomalyEventDto::getEntityId)
					.containsExactlyInAnyOrder(anomalies.stream()
							.map(a -> tuple(a.getTypeGroupCode(), a.getTypeCode(), a.getEntityCode(), a.getEntityId()))
							.toArray(Tuple[]::new));

			handle.rollback();
		});
	}

	@Test
	@SneakyThrows
	void test_expire() {
		getJdbi().useHandle(handle -> {
			handle.begin();
			List<String> initScripts = List.of("base_anomaly", "add_anomalies");
			execSqlFiles(this.getClass(), initScripts, testScriptParams);
			ArgumentCaptor<AnomalyEventDto> anomalyEventDtoCaptor = ArgumentCaptor.forClass(AnomalyEventDto.class);

			Optional<AnomalyEntity> entity2 = service.findEntityById(TENANT_ID, -101L);
			assertTrue(entity2.isPresent());

			List<AnomalyReq> anomalies = List.of(
					PojoBuilders.anomalyRequest("GR1", "AT1", "ITEM", "12").build());

			service.expire(context, anomalies);

			Optional<AnomalyEntity> entity3 = service.findEntityById(TENANT_ID, -101L);
			assertTrue(entity3.isEmpty());

			verify(anomalyEventProducer, times(1))
					.pushAnomalyEvent(anomalyEventDtoCaptor.capture(), eq(TENANT_ID), eq(AnomalyEventType.EXPIRED));
			org.assertj.core.api.Assertions.assertThat(anomalyEventDtoCaptor.getValue()).isNotNull()
					.extracting("id")
					.isEqualTo(entity2.get().getId());

			handle.rollback();
		});
	}

}
