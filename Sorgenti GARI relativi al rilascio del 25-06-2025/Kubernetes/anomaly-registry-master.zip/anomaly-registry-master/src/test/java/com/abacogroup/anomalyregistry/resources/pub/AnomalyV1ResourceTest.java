package com.abacogroup.anomalyregistry.resources.pub;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoMoreInteractions;

import com.abacogroup.anomalyregistry.AnmParams;
import com.abacogroup.anomalyregistry.api.v1.AnomalySearchResponse;
import com.abacogroup.anomalyregistry.api.v1.req.AnomalyRequest;
import com.abacogroup.anomalyregistry.api.v1.req.AnomalySearchRequest;
import com.abacogroup.anomalyregistry.core.AnomalyServiceV1;
import com.abacogroup.anomalyregistry.core.PojoBuilders;
import com.abacogroup.anomalyregistry.resources.WebCliHelper;
import com.abacogroup.common.core.ReqContext;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;
import io.dropwizard.testing.junit5.ResourceExtension;
import java.util.List;
import java.util.Map;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mockito;

@ExtendWith(DropwizardExtensionsSupport.class)
@Slf4j
class AnomalyV1ResourceTest {

	public static final String PATH = AnmParams.MASTER_PUBLIC_PATH + "/anomalies";
	private final AnomalyServiceV1 anomalyService = Mockito.mock(AnomalyServiceV1.class);

	private final ResourceExtension EXT = WebCliHelper.createEXT(new AnomalyV1Resource(anomalyService));

	private final ObjectMapper mapper = new ObjectMapper();

	@Test
	void test_search() {
		String entityCode = "party";
		String path = String.format("%s/%s", PATH, entityCode);
		var searchParams = new AnomalySearchRequest()
				.setGroupCode(List.of("GR1", "GR2"))
				.setTypeCode(List.of("ATx", "ATy"))
				.setTypeId(List.of(123L, 456L, 789L))
				.setEntityId(List.of("11", "22"));
		Map<String, Object> beanMap = mapper.convertValue(searchParams, Map.class);
		var expectedResults = List.of(
				PojoBuilders.completeAnomalyResponse().setId(1L).build(),
				PojoBuilders.completeAnomalyResponse().setId(2L).build()
		);
		given(anomalyService.search(any(), anyString(), any())).willReturn(expectedResults);

		List<?> response = WebCliHelper.executeGet(EXT, path, beanMap, WebCliHelper.BASIC_CREDENTIALS, List.class);

		assertThat(response).isNotNull().hasSize(2);
		assertThat(response.stream().map(c -> mapper.convertValue(c, AnomalySearchResponse.class)))
				.usingRecursiveFieldByFieldElementComparatorIgnoringFields("id", "type.id")
				.containsAll(expectedResults);
		var requestArgumentCaptor = ArgumentCaptor.forClass(AnomalySearchRequest.class);
		ArgumentCaptor<ReqContext> reqCtxCaptor = ArgumentCaptor.forClass(ReqContext.class);
		verify(anomalyService, times(1))
				.search(reqCtxCaptor.capture(), eq("PARTY"), requestArgumentCaptor.capture());
		verifyNoMoreInteractions(anomalyService);
		var searchRequest = requestArgumentCaptor.getValue();
		assertThat(searchRequest).isEqualTo(searchParams);
		ReqContext reqContext = reqCtxCaptor.getValue();
		assertThat(reqContext.getTenantId()).isEqualTo("master");
		assertThat(reqContext.getLang()).isEqualTo("en");
		assertThat(reqContext.getUsername()).isEqualTo(WebCliHelper.BASIC_USERNAME);
	}

	// ----- add -----
	@Test
	void test_add_ok() {
		var request = List.of(
				AnomalyRequest.builder().setTypeGroupCode("GR1").setTypeCode("AT1").setEntityCode("PARTY").setEntityId("11").build(),
				AnomalyRequest.builder().setTypeGroupCode("GR2").setTypeCode("AT2").setEntityCode("PARTY").setEntityId("22").build()
		);

		WebCliHelper.executePost(EXT, PATH, request, WebCliHelper.BASIC_CREDENTIALS, Void.class);

		ArgumentCaptor<ReqContext> reqCtxCaptor = ArgumentCaptor.forClass(ReqContext.class);
		verify(anomalyService).add(reqCtxCaptor.capture(), eq(request));
		verifyNoMoreInteractions(anomalyService);
		ReqContext reqContext = reqCtxCaptor.getValue();
		assertThat(reqContext.getTenantId()).isEqualTo("master");
		assertThat(reqContext.getLang()).isEqualTo("en");
		assertThat(reqContext.getUsername()).isEqualTo(WebCliHelper.BASIC_USERNAME);
	}

	// ----- expire -----
	@Test
	void test_expire_ok() {
		String path = String.format("%s/expired", PATH);
		var request = List.of(
				AnomalyRequest.builder().setTypeGroupCode("GR1").setTypeCode("AT1").setEntityCode("PARTY").setEntityId("11").build(),
				AnomalyRequest.builder().setTypeGroupCode("GR2").setTypeCode("AT2").setEntityCode("PARTY").setEntityId("22").build()
		);

		WebCliHelper.executePost(EXT, path, request, WebCliHelper.BASIC_CREDENTIALS, Void.class);

		ArgumentCaptor<ReqContext> reqCtxCaptor = ArgumentCaptor.forClass(ReqContext.class);
		verify(anomalyService).expire(reqCtxCaptor.capture(), eq(request));
		verifyNoMoreInteractions(anomalyService);
		ReqContext reqContext = reqCtxCaptor.getValue();
		assertThat(reqContext.getTenantId()).isEqualTo("master");
		assertThat(reqContext.getLang()).isEqualTo("en");
		assertThat(reqContext.getUsername()).isEqualTo(WebCliHelper.BASIC_USERNAME);
	}
}
