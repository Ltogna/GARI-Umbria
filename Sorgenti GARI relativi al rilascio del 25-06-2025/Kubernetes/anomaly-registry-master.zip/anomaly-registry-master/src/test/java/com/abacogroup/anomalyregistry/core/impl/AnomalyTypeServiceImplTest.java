package com.abacogroup.anomalyregistry.core.impl;

import static org.assertj.core.api.Assertions.assertThat;

import com.abacogroup.anomalyregistry.AnmParams;
import com.abacogroup.anomalyregistry.api.AnomalyTypeRes;
import com.abacogroup.anomalyregistry.api.req.AnomalyTypeSearchReq;
import com.abacogroup.anomalyregistry.core.AnomalyTypeService;
import com.abacogroup.common.core.MyJdbi;
import com.abacogroup.common.core.ReqContext;
import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;
import java.util.List;
import java.util.Map;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

@Slf4j
@ExtendWith(DropwizardExtensionsSupport.class)
class AnomalyTypeServiceImplTest extends MyJdbi {

	private static final String TENANT_ID = AnomalyTypeServiceImplTest.class.getSimpleName() + "_t";
	private static final String CURRENT_USER = AnomalyTypeServiceImplTest.class.getSimpleName() + "_u";
	private static final ReqContext context = new ReqContext(TENANT_ID, CURRENT_USER, "en");
	private static final Map<String, Object> testScriptParams = Map.of(
			"test_tenant", TENANT_ID,
			"user_id", CURRENT_USER
	);

	private final AnomalyTypeService service = getService(AnomalyTypeServiceImpl.class);

	@BeforeAll
	@AfterAll
	public static void beforeAll() {
		execSqlFiles(AnmParams.class, List.of("rollback"), testScriptParams);
	}

	// ----- searchAll -----
	@Test
	void test_searchAll_ok() {
		getJdbi().useHandle(handle -> {
			handle.begin();
			List<String> initScripts = List.of("add_anomaly_types");
			execSqlFiles(this.getClass(), initScripts, testScriptParams);

			List<AnomalyTypeRes> responseList;

			responseList = service.searchAll(context, new AnomalyTypeSearchReq()
					.setCode("at1").setGroupCode("gr1"));
			assertThat(responseList).describedAs("by code and group")
					.isNotNull().hasSize(1)
					.contains(AnomalyTypeRes.builder()
							.setId(-1001L)
							.setGroupCode("GR1")
							.setCode("AT1")
							.setI18nCode("at1 en")
							.build());

			responseList = service.searchAll(context, new AnomalyTypeSearchReq());
			assertThat(responseList).describedAs("no filters")
					.isNotNull().hasSize(4)
					.extracting(AnomalyTypeRes::getId)
					.containsExactlyInAnyOrder(-1001L, -1002L, -1003L, -1004L);

			responseList = service.searchAll(context, new AnomalyTypeSearchReq()
					.setCode("at2"));
			assertThat(responseList).describedAs("by code duplicated")
					.isNotNull().hasSize(2)
					.extracting(AnomalyTypeRes::getId)
					.containsExactlyInAnyOrder(-1002L, -1004L);

			responseList = service.searchAll(context, new AnomalyTypeSearchReq()
					.setCode("at3"));
			assertThat(responseList).describedAs("by code")
					.isNotNull().hasSize(1)
					.extracting(AnomalyTypeRes::getId)
					.containsExactlyInAnyOrder(-1003L);

			responseList = service.searchAll(context, new AnomalyTypeSearchReq()
					.setCode("at5"));
			assertThat(responseList).describedAs("by code deleted")
					.isNotNull().isEmpty();

			responseList = service.searchAll(context, new AnomalyTypeSearchReq()
					.setGroupCode("gr1"));
			assertThat(responseList).describedAs("by group")
					.isNotNull().hasSize(2)
					.extracting(AnomalyTypeRes::getId)
					.containsExactlyInAnyOrder(-1001L, -1002L);

			responseList = service.searchAll(context, new AnomalyTypeSearchReq()
					.setI18nCode("AT"));
			assertThat(responseList).describedAs("by i18nCode all")
					.isNotNull().hasSize(4)
					.extracting(AnomalyTypeRes::getId)
					.containsExactlyInAnyOrder(-1001L, -1002L, -1003L, -1004L);

			responseList = service.searchAll(context, new AnomalyTypeSearchReq()
					.setI18nCode("AT1"));
			assertThat(responseList).describedAs("by i18nCode")
					.isNotNull().hasSize(1)
					.extracting(AnomalyTypeRes::getId)
					.containsExactlyInAnyOrder(-1001L);

			handle.rollback();
		});
	}

	// ----- getById -----
	@Test
	void test_getById_okAndKo() {
		getJdbi().useHandle(handle -> {
			handle.begin();
			List<String> initScripts = List.of("add_anomaly_types");
			execSqlFiles(this.getClass(), initScripts, testScriptParams);

			var response = service.getById(context, -1001L);

			assertThat(response).describedAs("found").isPresent()
					.get().isEqualTo(AnomalyTypeRes.builder()
							.setId(-1001L)
							.setGroupCode("GR1")
							.setCode("AT1")
							.setI18nCode("at1 en")
							.build());

			assertThat(service.getById(context, -9999L)).describedAs("not found").isNotPresent();

			handle.rollback();
		});
	}
}
