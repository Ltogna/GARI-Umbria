package com.abacogroup.anomalyregistry.bundle.config;

import com.abacogroup.anomalyregistry.bundle.BundleConstants;
import com.abacogroup.anomalyregistry.db.dao.AnomalyTypeDAO;
import com.abacogroup.anomalyregistry.db.dao.I18nDAO;
import com.abacogroup.anomalyregistry.db.ntt.AnomalyTypeEntity;
import com.abacogroup.bundles.initializer.impl.exceptions.BundleException;
import com.abacogroup.bundles.listener.configdata.ConfigDataMessage;
import com.abacogroup.bundles.listener.configdata.ConfigMessageProcessor;
import com.abacogroup.common.bundle.config.I18nProcessor;
import com.abacogroup.common.bundle.config.I18nProcessor.I18nContext;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

@Slf4j
public class AnomalyTypeConfigMessageProcessor implements ConfigMessageProcessor {

	private final AnomalyTypeDAO anomalyTypeDAO;
	private final ObjectMapper objectMapper;

	public AnomalyTypeConfigMessageProcessor(AnomalyTypeDAO anomalyTypeDAO, ObjectMapper objectMapper) {
		this.anomalyTypeDAO = anomalyTypeDAO;
		this.objectMapper = objectMapper;
	}

	@Override
	public String getDomainName() {
		return BundleConstants.DOMAIN_ANOMALY_TYPE;
	}

	@Override
	public void onMessage(ConfigDataMessage message) {
		String tenantId = message.getTenantId();

		Function<String, FileOperationEnum> groupingPredicate = x -> {
			if (StringUtils.containsIgnoreCase(x, "delete")) {
				return FileOperationEnum.DELETE;
			} else if (StringUtils.containsIgnoreCase(x, "i18n")) {
				return FileOperationEnum.I18N;
			} else {
				return FileOperationEnum.DEFAULT;
			}
		};

		List<Path> paths = message.getConfigFiles();
		var map = paths.stream()
				.collect(Collectors.groupingBy(x -> groupingPredicate.apply(x.toString()),
						Collectors.toCollection(ArrayList::new)));

		map.getOrDefault(FileOperationEnum.DELETE, new ArrayList<>()).forEach(path -> removeContent(tenantId, path));
		map.getOrDefault(FileOperationEnum.DEFAULT, new ArrayList<>()).forEach(path -> addContent(tenantId, path));
		map.getOrDefault(FileOperationEnum.I18N, new ArrayList<>()).forEach(path -> processI18N(tenantId, path));

	}

	private void processI18N(String tenantId, Path path) {
		new I18nProcessor(anomalyTypeDAO.getHandle().attach(I18nDAO.class))
				.addContent(tenantId, path,
						I18nContext.builder()
								.setFieldName("code")
								.setTableName("anm_anomaly_types")
								.build(),
						I18nContext.builder()
								.setFieldName("groupCode")
								.setTableName("anm_anomaly_types")
								.build()
				);
	}

	private void removeContent(String tenantId, Path path) {
		try {
			try (Stream<String> input = Files.lines(path, StandardCharsets.UTF_8)) {
				input.map(String::strip)
						.filter(s -> !StringUtils.isBlank(s))
						.filter(s -> !s.startsWith(BundleConstants.JSONL_COMMENT))
						.map(jsonLine -> mapEntity(tenantId, jsonLine))
						.distinct()
						.forEach(toDelete -> anomalyTypeDAO.findNotInUseByCodeAndGroupCode(tenantId, toDelete.getCode(), toDelete.getGroupCode())
								.ifPresentOrElse(
										at -> anomalyTypeDAO.doExpire(BundleConstants.SYSTEM_USER, at, anomalyTypeDAO::expireRow),
										() -> log.warn("cannot remove type {}.{}: type in use or already deleted!",
												toDelete.getGroupCode(), toDelete.getCode())
								));
			}
		} catch (Exception e) {
			throw new BundleException(String.format("error deleting from file %s", path), e);
		}
	}

	private void addContent(String tenantId, Path path) {
		try {
			try (Stream<String> input = Files.lines(path, StandardCharsets.UTF_8)) {
				AnomalyTypeEntity[] entities = input
						.map(String::strip)
						.filter(s -> !StringUtils.isBlank(s))
						.filter(s -> !s.startsWith(BundleConstants.JSONL_COMMENT))
						.map(jsonLine -> mapEntity(tenantId, jsonLine))
						.distinct()
						.toArray(AnomalyTypeEntity[]::new);

				anomalyTypeDAO.setAuditForInsert(BundleConstants.SYSTEM_USER, entities);
				anomalyTypeDAO.insertBatch(entities);
			}
		} catch (Exception e) {
			throw new BundleException(String.format("error saving file %s", path), e);
		}
	}

	private AnomalyTypeEntity mapEntity(String tenantId, String jsonLine) {
		try {
			AnomalyTypeEntity entity = objectMapper.readValue(jsonLine, AnomalyTypeEntity.class);
			entity.setTenantId(tenantId);
			return entity;
		} catch (Exception e) {
			throw new BundleException("error in deserialization json " + jsonLine, e);
		}
	}

	private enum FileOperationEnum {
		DELETE,
		DEFAULT,
		I18N

	}

}
