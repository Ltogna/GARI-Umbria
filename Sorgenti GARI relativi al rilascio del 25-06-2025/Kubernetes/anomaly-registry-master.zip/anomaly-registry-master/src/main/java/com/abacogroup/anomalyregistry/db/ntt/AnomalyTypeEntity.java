package com.abacogroup.anomalyregistry.db.ntt;

import com.abacogroup.common.db.ntt.AuditEntity;
import java.time.LocalDateTime;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder(setterPrefix = "set", toBuilder = true)
@NoArgsConstructor
public class AnomalyTypeEntity implements AuditEntity {

	private Long id;
	private String tenantId;

	private String groupCode;
	private String code;

	private LocalDateTime dtInsert;
	private String userIdInsert;
	private LocalDateTime dtDelete;
	private String userIdDelete;

}
