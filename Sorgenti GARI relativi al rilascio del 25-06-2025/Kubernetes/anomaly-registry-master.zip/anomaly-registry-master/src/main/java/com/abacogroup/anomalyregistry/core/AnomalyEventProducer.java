package com.abacogroup.anomalyregistry.core;

import com.abacogroup.anomalyregistry.api.dto.AnomalyEventDto;
import java.io.IOException;
import lombok.Getter;

public interface AnomalyEventProducer {

	void pushAnomalyEvent(AnomalyEventDto message, String tenant, AnomalyEventType eventType) throws IOException;

	enum AnomalyEventType {

		NEW("new"),
		EXPIRED("expired");

		@Getter
		private final String topic;

		AnomalyEventType(String topicName) {
			this.topic = String.format("anomalies.%s", topicName);
		}
	}

}
