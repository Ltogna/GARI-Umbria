package com.abacogroup.common.db.ntt;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.function.Consumer;
import java.util.function.Function;

public interface AuditDAO extends BasicDAO {

	default <E extends AuditEntity> void setAuditForInsert(String currentUser, List<E> list) {
		setAuditForInsert(currentUser, list.toArray(AuditEntity[]::new));
	}

	default <E extends AuditEntity> void setAuditForInsert(String currentUser, E... list) {
		LocalDateTime now = this.getCurrentTimestamp();
		setAuditForInsert(currentUser, now, list);
	}

	default <E extends AuditEntity> void setAuditForInsert(String currentUser, LocalDateTime now, E... list) {
		Arrays.stream(list)
				.filter(Objects::nonNull)
				.forEach(audit -> {
					audit.setUserIdInsert(currentUser);
					audit.setDtInsert(now);
					audit.setDtDelete(AuditEntity.dateActive);
					audit.setUserIdDelete(null);
				});
	}

	default <E extends AuditEntity> void setAuditForExpire(String currentUser, E... list) {
		LocalDateTime now = this.getCurrentTimestamp();
		setAuditForExpire(currentUser, now, list);
	}

	default <E extends AuditEntity> void setAuditForExpire(String currentUser, LocalDateTime currentTimestamp, E... list) {
		Arrays.stream(list).forEach(audit -> {
			audit.setDtDelete(currentTimestamp.minusSeconds(1));
			audit.setUserIdDelete(currentUser);
		});
	}

	//-------

	default <E extends AuditEntity> Long doUpdate(String currentUser, E audit,
			Consumer<E> expireConsumer,
			Function<E, Long> insertFunction) {

		LocalDateTime currentTimestamp = this.getCurrentTimestamp();

		setAuditForExpire(currentUser, currentTimestamp, audit);
		expireConsumer.accept(audit);

		setAuditForInsert(currentUser, currentTimestamp, audit);
		return insertFunction.apply(audit);
	}

	default <E extends AuditEntity> void doExpire(String currentUser, E audit,
			Consumer<E> expireConsumer) {

		LocalDateTime currentTimestamp = this.getCurrentTimestamp();

		setAuditForExpire(currentUser, currentTimestamp, audit);
		expireConsumer.accept(audit);

	}

}
