package com.abacogroup.anomalyregistry.bundle.tenant;

import static com.abacogroup.bundles.Constants.ALL_TENANTS;

import com.abacogroup.anomalyregistry.bundle.BundleConstants;
import com.abacogroup.anomalyregistry.db.dao.AnomalyTypeDAO;
import com.abacogroup.anomalyregistry.db.ntt.AnomalyTypeEntity;
import com.abacogroup.bundles.listener.tenant.TenantMessage;
import com.abacogroup.bundles.listener.tenant.TenantMessageProcessor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class AnomalyTypeTenantMessageProcessor implements TenantMessageProcessor {

	private final AnomalyTypeDAO anomalyTypeDAO;

	public AnomalyTypeTenantMessageProcessor(AnomalyTypeDAO anomalyTypeDAO) {
		this.anomalyTypeDAO = anomalyTypeDAO;
	}

	@Override
	public void onMessage(TenantMessage message) {
		String tenantId = message.getTenantId();
		AnomalyTypeEntity audit = AnomalyTypeEntity.builder().build();
		anomalyTypeDAO.setAuditForInsert(BundleConstants.SYSTEM_USER, audit);
		anomalyTypeDAO.insertNewTenant(ALL_TENANTS, tenantId, audit);
	}
}
