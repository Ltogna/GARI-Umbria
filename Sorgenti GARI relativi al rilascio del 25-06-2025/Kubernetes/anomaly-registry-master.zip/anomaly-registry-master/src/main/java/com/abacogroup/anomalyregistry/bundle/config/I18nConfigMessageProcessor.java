package com.abacogroup.anomalyregistry.bundle.config;

import com.abacogroup.anomalyregistry.bundle.BundleConstants;
import com.abacogroup.anomalyregistry.db.dao.I18nDAO;
import com.abacogroup.anomalyregistry.db.ntt.I18nEntity;
import com.abacogroup.bundles.initializer.impl.exceptions.BundleException;
import com.abacogroup.bundles.listener.configdata.ConfigDataMessage;
import com.abacogroup.bundles.listener.configdata.ConfigMessageProcessor;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.stream.Stream;
import jakarta.validation.constraints.NotNull;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

@Slf4j
public class I18nConfigMessageProcessor implements ConfigMessageProcessor {
	private final I18nDAO i18nDAO;

	private final ObjectMapper mapper = new ObjectMapper().addMixIn(I18nEntity.class, I18nEntityMixin.class);

	public I18nConfigMessageProcessor(I18nDAO i18nDAO) {
		this.i18nDAO = i18nDAO;
	}

	@Override
	public String getDomainName() {
		return BundleConstants.DOMAIN_I18N;
	}

	@Override
	public void onMessage(ConfigDataMessage message) {
		String tenantId = message.getTenantId();
		message.getConfigFiles().forEach(path -> {
			addContent(tenantId, path);
		});
	}

	private void addContent(String tenantId, Path path) {
		try {
			try (Stream<String> input = Files.lines(path, StandardCharsets.UTF_8)) {
				I18nEntity[] entities = input
						.map(String::strip)
						.filter(s -> !StringUtils.isBlank(s))
						.filter(s -> !s.startsWith(BundleConstants.JSONL_COMMENT))
						.map(jsonLine -> mapEntity(tenantId, jsonLine))
						.toArray(I18nEntity[]::new);
				i18nDAO.deleteBatch(entities);
				i18nDAO.insertBatch(entities);
			}
		} catch (Exception e) {
			throw new BundleException(String.format("error saving file %s", path), e);
		}
	}

	private I18nEntity mapEntity(String tenantId, String jsonLine) {
		try {
			I18nEntity entity = mapper.readValue(jsonLine, I18nEntity.class);
			entity.setTenantId(tenantId);
			return entity;
		} catch (Exception e) {
			throw new BundleException("error in deserialization json " + jsonLine, e);
		}
	}

	private abstract static class I18nEntityMixin {

		@NotNull
		@JsonProperty("table_name")
		private String tableName;

		@NotNull
		@JsonProperty("field_name")
		private String fieldName;

		@NotNull
		@JsonProperty("i18n_value")
		private String i18nValue;

		@NotNull
		@JsonProperty("lang")
		private String lang;

		@NotNull
		@JsonProperty("i18n_text")
		private String i18nText;
	}

}
