package com.abacogroup.anomalyregistry.core.impl;

import com.abacogroup.anomalyregistry.api.AnomalySearchRes;
import com.abacogroup.anomalyregistry.api.dto.SearchAnomaliesByParcelIdsDto;
import com.abacogroup.anomalyregistry.api.req.mappers.AnomalyMapper;
import com.abacogroup.anomalyregistry.api.req.mappers.AnomalySearchReqMapper;
import com.abacogroup.anomalyregistry.api.v1.AnomalySearchResponse;
import com.abacogroup.anomalyregistry.api.v1.req.AnomalyRequest;
import com.abacogroup.anomalyregistry.api.v1.req.AnomalySearchRequest;
import com.abacogroup.anomalyregistry.core.AnomalyService;
import com.abacogroup.anomalyregistry.core.AnomalyServiceV1;
import com.abacogroup.common.core.ReqContext;
import java.util.List;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class AnomalyServiceV1Impl implements AnomalyServiceV1 {

	private final AnomalyService anomalyService;

	public AnomalyServiceV1Impl(AnomalyService anomalyService) {
		this.anomalyService = anomalyService;

	}

	@Override
	public List<AnomalySearchResponse> search(ReqContext reqContext, String entityCode, AnomalySearchRequest searchRequest) {
		List<AnomalySearchRes> searchRes = anomalyService.search(reqContext, entityCode, AnomalySearchReqMapper.INSTANCE.fromV1(searchRequest));
		return AnomalyMapper.INSTANCE.toV1List(searchRes);
	}

	@Override
	public void add(ReqContext reqContext, List<AnomalyRequest> anomalyRequests) {
		anomalyService.add(reqContext, AnomalyMapper.INSTANCE.fromV1List(anomalyRequests));
	}

	@Override
	public void expire(ReqContext reqContext, List<AnomalyRequest> anomalyRequests) {
		anomalyService.expire(reqContext, AnomalyMapper.INSTANCE.fromV1List(anomalyRequests));
	}

	@Override
	public void expireAllById(ReqContext reqContext, List<Long> listIds) {
		anomalyService.expireAllById(reqContext, listIds);
	}

	@Override
	public List<AnomalySearchResponse> searchByParcelIds(ReqContext reqContext, SearchAnomaliesByParcelIdsDto dto) {
		var res = anomalyService.searchByParcelIds(reqContext, dto);

		return AnomalyMapper.INSTANCE.toV1List(res);
	}

}
