package com.abacogroup.anomalyregistry.api.req.mappers;

import com.abacogroup.anomalyregistry.api.AnomalySearchRes;
import com.abacogroup.anomalyregistry.api.req.AnomalyReq;
import com.abacogroup.anomalyregistry.api.v1.AnomalySearchResponse;
import com.abacogroup.anomalyregistry.api.v1.req.AnomalyRequest;
import com.abacogroup.anomalyregistry.db.ntt.AnomalyEntity;
import java.util.List;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper
public interface AnomalyMapper {

	AnomalyMapper INSTANCE = Mappers.getMapper(AnomalyMapper.class);

	AnomalyEntity requestToEntity(AnomalyReq request);

	AnomalyReq fromV1(AnomalyRequest request);

	List<AnomalyReq> fromV1List(List<AnomalyRequest> request);

	AnomalySearchResponse toV1(AnomalySearchRes res);

	List<AnomalySearchResponse> toV1List(List<? extends AnomalySearchRes> res);

}
