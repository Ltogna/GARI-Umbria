package com.abacogroup.anomalyregistry.api.req.mappers;

import com.abacogroup.anomalyregistry.api.req.AnomalyTypeSearchReq;
import com.abacogroup.anomalyregistry.api.v1.req.AnomalyTypeSearchRequest;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper
public interface AnomalyTypeSearchReqMapper {

	AnomalyTypeSearchReqMapper INSTANCE = Mappers.getMapper(AnomalyTypeSearchReqMapper.class);

	AnomalyTypeSearchReq fromV1(AnomalyTypeSearchRequest searchRequest);

}
