package com.abacogroup.anomalyregistry.core.impl;

import com.abacogroup.anomalyregistry.api.AnomalyTypeRes;
import com.abacogroup.anomalyregistry.api.req.AnomalyTypeSearchReq;
import com.abacogroup.anomalyregistry.core.AnomalyTypeService;
import com.abacogroup.anomalyregistry.db.dao.AnomalyTypeDAO;
import com.abacogroup.anomalyregistry.db.ntt.AnomalyTypeEntity;
import com.abacogroup.common.core.ReqContext;
import com.abacogroup.jdbi.criteria.Criteria;
import com.abacogroup.jdbi.orderby.OrderByElement;
import java.util.List;
import java.util.Optional;

public class AnomalyTypeServiceImpl implements AnomalyTypeService {

	private final AnomalyTypeDAO anomalyTypeDAO;

	public AnomalyTypeServiceImpl(AnomalyTypeDAO anomalyTypeDAO) {
		this.anomalyTypeDAO = anomalyTypeDAO;
	}

	@Override
	public List<AnomalyTypeRes> searchAll(ReqContext reqContext, AnomalyTypeSearchReq searchRequest) {
		Criteria criteria = searchRequest.getCriteria();
		OrderByElement sort = searchRequest.getSort();

		return anomalyTypeDAO.searchAll(reqContext, criteria, sort);
	}

	@Override
	public Optional<AnomalyTypeRes> getById(ReqContext reqContext, Long id) {
		return anomalyTypeDAO.getById(id, reqContext);
	}

	@Override
	public Optional<AnomalyTypeEntity> findEntityByGroupCodeAndCode(String tenantId, String groupCode, String code) {
		return anomalyTypeDAO.findByGroupCodeAndCode(tenantId, groupCode, code);
	}
}
