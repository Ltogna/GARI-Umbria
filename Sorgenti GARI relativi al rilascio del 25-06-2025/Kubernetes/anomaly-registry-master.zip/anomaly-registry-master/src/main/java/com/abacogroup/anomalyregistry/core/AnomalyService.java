package com.abacogroup.anomalyregistry.core;

import com.abacogroup.anomalyregistry.api.AnomalySearchRes;
import com.abacogroup.anomalyregistry.api.dto.SearchAnomaliesByParcelIdsDto;
import com.abacogroup.anomalyregistry.api.req.AnomalyReq;
import com.abacogroup.anomalyregistry.api.req.AnomalySearchReq;
import com.abacogroup.anomalyregistry.api.v1.AnomalySearchResponse;
import com.abacogroup.anomalyregistry.db.ntt.AnomalyEntity;
import com.abacogroup.common.core.ReqContext;
import java.util.List;
import java.util.Optional;

public interface AnomalyService {

	List<AnomalySearchRes> search(ReqContext reqContext, String entityCode, AnomalySearchReq searchRequest);

	void add(ReqContext reqContext, List<AnomalyReq> anomalyRequests);

	void expire(ReqContext reqContext, List<AnomalyReq> anomalyRequests);

	void expireAllById(ReqContext reqContext, List<Long> listIds);

	Optional<AnomalyEntity> findEntityById(String tenantId, Long id);

	List<AnomalySearchRes> searchByParcelIds(ReqContext reqContext, SearchAnomaliesByParcelIdsDto dto);
}
