package com.abacogroup.anomalyregistry.api.req.mappers;

import com.abacogroup.anomalyregistry.api.req.AnomalySearchReq;
import com.abacogroup.anomalyregistry.api.v1.req.AnomalySearchRequest;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper
public interface AnomalySearchReqMapper {

	AnomalySearchReqMapper INSTANCE = Mappers.getMapper(AnomalySearchReqMapper.class);

	AnomalySearchReq fromV1(AnomalySearchRequest searchRequest);

}
