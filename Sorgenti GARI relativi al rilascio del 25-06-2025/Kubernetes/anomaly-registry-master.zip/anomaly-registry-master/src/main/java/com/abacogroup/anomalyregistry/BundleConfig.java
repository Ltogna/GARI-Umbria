package com.abacogroup.anomalyregistry;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Data
public class BundleConfig {

	@NotBlank
	private String configLocation;

	private String initBaseTempDir;

}
