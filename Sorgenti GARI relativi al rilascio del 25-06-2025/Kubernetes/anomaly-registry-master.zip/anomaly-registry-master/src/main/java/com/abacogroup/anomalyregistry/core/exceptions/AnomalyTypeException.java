package com.abacogroup.anomalyregistry.core.exceptions;

import io.swagger.v3.oas.annotations.media.Schema;

public class AnomalyTypeException extends AbstractAppException {

	public static final String INVALID_ANOMALY_TYPE = "INVALID_ANOMALY_TYPE";
	public static final String ANOMALY_TYPE_NOT_FOUND = "ANOMALY_TYPE_NOT_FOUND";

	public AnomalyTypeException(String code, String message) {
		super(new AnomalyTypeException.ErrorBody(code, message));
	}

	@Schema(name = "InvalidAnomalyTypeErrorBody")
	public static class ErrorBody implements ExceptionErrorBody {
		private final String code;
		private final String message;

		public ErrorBody(String code, String message) {
			this.code = code;
			this.message = message;
		}

		@Override
		@Schema(allowableValues = { INVALID_ANOMALY_TYPE, ANOMALY_TYPE_NOT_FOUND })
		public String getErrorCode() {
			return code;
		}

		@Override
		@Schema
		public String getMessage() {
			return message;
		}
	}
}
