package com.abacogroup.anomalyregistry.api.dto;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;
import org.jdbi.v3.core.mapper.Nested;

@Data
@NoArgsConstructor
@SuperBuilder(setterPrefix = "set")
public class AnomalyEventDto {

	private Long id;

	@Nested("at")
	private AnomalyTypeDto type;
	private String entityCode;
	private String entityId;

	@Data
	@NoArgsConstructor
	@SuperBuilder(setterPrefix = "set")
	public static class AnomalyTypeDto {
		private Long id;

		private String groupCode;
		private String code;
	}

}
