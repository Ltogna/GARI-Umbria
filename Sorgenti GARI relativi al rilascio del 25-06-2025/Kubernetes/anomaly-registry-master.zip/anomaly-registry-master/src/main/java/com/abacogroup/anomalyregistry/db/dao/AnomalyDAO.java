package com.abacogroup.anomalyregistry.db.dao;

import com.abacogroup.anomalyregistry.api.AnomalySearchRes;
import com.abacogroup.anomalyregistry.api.dto.AnomalyEventDto;
import com.abacogroup.anomalyregistry.api.req.AnomalyReq;
import com.abacogroup.anomalyregistry.db.ntt.AnomalyEntity;
import com.abacogroup.common.core.ReqContext;
import com.abacogroup.common.db.ntt.AuditDAO;
import com.abacogroup.jdbi.criteria.BindCriteria;
import com.abacogroup.jdbi.criteria.Criteria;
import com.abacogroup.jdbi.orderby.DefineOrder;
import com.abacogroup.jdbi.orderby.OrderBy;
import java.util.List;
import java.util.Optional;
import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.customizer.BindBean;
import org.jdbi.v3.sqlobject.customizer.BindList;
import org.jdbi.v3.sqlobject.customizer.BindList.EmptyHandling;
import org.jdbi.v3.sqlobject.statement.GetGeneratedKeys;
import org.jdbi.v3.sqlobject.statement.SqlBatch;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;
import org.jdbi.v3.sqlobject.transaction.Transactional;

public interface AnomalyDAO extends Transactional<AnomalyDAO>, AuditDAO {

	@SqlQuery("SELECT a.id, a.tenant_id, a.type_id, a.entity_code, a.entity_id "
			+ " , at.id as at_id, at.code as at_code, at.group_code as at_group_code "
			+ " FROM anm_anomalies a "
			+ " inner join anm_anomaly_types at on a.type_id = at.id and (CURRENT_TIMESTAMP between at.dt_insert and at.dt_delete) "
			+ " WHERE a.tenant_id = :tenantId "
			+ " AND a.id in (<ids>) ")
	@RegisterBeanMapper(AnomalyEventDto.class)
	List<AnomalyEventDto> getAnomaliesByIdInAndIncludeDeleted(
			@Bind("tenantId") String tenantId,
			@BindList(value = "ids", onEmpty = EmptyHandling.NULL_VALUE) List<Long> ids);

	@SqlQuery("select * from ( "
			+ " SELECT an.id , type_id , entity_code , entity_id "
			+ ", at.id as anomaly_type_id, at.group_code as anomaly_type_group_code, at.code as anomaly_type_code "
			+ ", coalesce (§i18n(:tenantId, 'anm_anomaly_types', 'code', at.code, :lang)§, at.code) AS anomaly_type_i18n_code "
			+ " FROM anm_anomalies an "
			+ " inner join anm_anomaly_types at on an.type_id = at.id AND (CURRENT_TIMESTAMP between at.dt_insert and at.dt_delete) AND at.tenant_id = :tenantId "
			+ " WHERE an.tenant_id = :tenantId AND (CURRENT_TIMESTAMP between an.dt_insert and an.dt_delete) "
			+ " and an.entity_code= UPPER(:entityCode) "
			+ " ) inner_result "
			+ "where <criteria> "
			+ "ORDER BY <orderBy> "
	)
	@RegisterBeanMapper(AnomalySearchRes.class)
	List<AnomalySearchRes> search(
			@BindBean ReqContext ctx,
			@Bind("entityCode") String entityCode,
			@BindCriteria Criteria criteria,
			@DefineOrder OrderBy orderBy);

	@SqlQuery("select * from ( "
			+ " SELECT an.id , type_id , entity_code , entity_id "
			+ ", at.id as anomaly_type_id, at.group_code as anomaly_type_group_code, at.code as anomaly_type_code "
			+ ", coalesce (§i18n(:tenantId, 'anm_anomaly_types', 'code', at.code, :lang)§, at.code) AS anomaly_type_i18n_code "
			+ " FROM anm_anomalies an "
			+ " inner join anm_anomaly_types at on an.type_id = at.id AND (CURRENT_TIMESTAMP between at.dt_insert and at.dt_delete) AND at.tenant_id = :tenantId "
			+ " WHERE an.tenant_id = :tenantId AND (CURRENT_TIMESTAMP between an.dt_insert and an.dt_delete) "
			+ " and an.entity_code= 'REFERENCE_PARCEL' "
			+ " ) inner_result "
			+ "where entity_code = 'REFERENCE_PARCEL' and  entity_id in (<parcelIds>)"
	)
	@RegisterBeanMapper(AnomalySearchRes.class)
	List<AnomalySearchRes> searchByParcelId(
			@BindBean ReqContext ctx,
			@BindList("parcelIds") List<Long> parcelIds);

	/**
	 * @deprecated <code>@GetGeneratedKeys("id")</code> generates error in oracle
	 */
	@Deprecated
	@SqlBatch("INSERT INTO anm_anomalies (tenant_id, type_id, entity_code, entity_id, dt_insert, user_id_insert, dt_delete, user_id_delete) "
			+ " §select_from_dual(:tenantId, :typeId, :entityCode , :entityId, :dtInsert, :userIdInsert, :dtDelete, :userIdDelete )§ "
			+ " where not exists("
			+ " SELECT type_id , entity_code, entity_id"
			+ " from anm_anomalies "
			+ " where  tenant_id = :tenantId and type_id = :typeId and entity_code = :entityCode and entity_id = :entityId and ( CURRENT_TIMESTAMP between dt_insert and dt_delete ) )")
	@GetGeneratedKeys("id")
	Long[] insertInBatch(@BindBean AnomalyEntity... entity);

	@SqlUpdate("INSERT INTO anm_anomalies (tenant_id, type_id, entity_code, entity_id, dt_insert, user_id_insert, dt_delete, user_id_delete) "
			+ " values (:tenantId, :typeId, :entityCode , :entityId, :dtInsert, :userIdInsert, :dtDelete, :userIdDelete )")
	@GetGeneratedKeys("id")
	Long insert(@BindBean AnomalyEntity entity);

	@SqlUpdate("UPDATE anm_anomalies SET dt_delete =:dtDelete, user_id_delete=:userIdDelete WHERE id in (<ids>)")
	void expireInBatch(
			@BindList(value = "ids", onEmpty = EmptyHandling.NULL_VALUE) List<Long> ids,
			@BindBean AnomalyEntity audit);

	@SqlQuery("SELECT count(*) FROM anm_anomalies"
			+ " WHERE tenant_id = :tenantId "
			+ " AND (CURRENT_TIMESTAMP between dt_insert and dt_delete)")
	Long countAll(@Bind("tenantId") String tenantId);

	//	@SqlQuery("SELECT type_id, entity_code,entity_id, dt_insert, user_id_insert, dt_delete, user_id_delete"
	//			+ " FROM anm_anomalies "
	//			+ " WHERE tenant_id = :tenantId AND id = :id  "
	//			+ " AND (CURRENT_TIMESTAMP between dt_insert and dt_delete)")
	//	@RegisterBeanMapper(AnomalyEntity.class)
	//	Optional<AnomalyEntity> findByTenantAndId(
	//			@Bind("tenantId") String tenantId,
	//			@Bind("id") Long id);

	@SqlQuery("SELECT a.id, a.tenant_id, a.type_id, a.entity_code, a.entity_id "
			+ " FROM anm_anomalies a "
			+ " inner join anm_anomaly_types at on a.type_id = at.id /*and (CURRENT_TIMESTAMP between at.dt_insert and at.dt_delete)*/ "
			+ " WHERE a.tenant_id = :tenantId "
			+ " AND at.group_code = :typeGroupCode "
			+ " AND at.code = :typeCode "
			+ " AND a.entity_code =:entityCode "
			+ " AND a.entity_id =:entityId "
			+ " AND (CURRENT_TIMESTAMP between a.dt_insert and a.dt_delete)")
	@RegisterBeanMapper(AnomalyEntity.class)
	Optional<AnomalyEntity> findByRequest(
			@Bind("tenantId") String tenantId,
			@BindBean AnomalyReq req);

	@SqlQuery("SELECT id, tenant_id, type_id, entity_code, entity_id, dt_insert, user_id_insert, dt_delete, user_id_delete "
			+ " FROM anm_anomalies "
			+ " WHERE tenant_id = :tenantId "
			+ " AND id = :id "
			+ " AND (CURRENT_TIMESTAMP between dt_insert and dt_delete)")
	@RegisterBeanMapper(AnomalyEntity.class)
	Optional<AnomalyEntity> findById(
			@Bind("tenantId") String tenantId,
			@Bind("id") Long id);
}
