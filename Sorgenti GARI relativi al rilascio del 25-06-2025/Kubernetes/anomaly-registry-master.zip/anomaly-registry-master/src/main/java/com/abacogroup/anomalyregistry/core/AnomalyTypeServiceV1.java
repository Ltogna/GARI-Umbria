package com.abacogroup.anomalyregistry.core;

import com.abacogroup.anomalyregistry.api.v1.AnomalyTypeResponse;
import com.abacogroup.anomalyregistry.api.v1.req.AnomalyTypeSearchRequest;
import com.abacogroup.common.core.ReqContext;
import java.util.List;
import java.util.Optional;

public interface AnomalyTypeServiceV1 extends PublicService {
	List<AnomalyTypeResponse> searchAll(ReqContext reqContext, AnomalyTypeSearchRequest searchRequest);

	Optional<AnomalyTypeResponse> getById(ReqContext reqContext, Long id);
}
