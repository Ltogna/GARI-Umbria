package com.abacogroup.common.db.ntt;

import java.time.LocalDate;
import java.time.LocalDateTime;

public interface AuditEntity {

	LocalDateTime dateActive = LocalDate.of(9999, 12, 31).atStartOfDay();

	LocalDateTime getDtInsert();

	void setDtInsert(LocalDateTime dtInsert);

	String getUserIdInsert();

	void setUserIdInsert(String userIdInsert);

	LocalDateTime getDtDelete();

	void setDtDelete(LocalDateTime dtDelete);

	String getUserIdDelete();

	void setUserIdDelete(String userIdDelete);
}
