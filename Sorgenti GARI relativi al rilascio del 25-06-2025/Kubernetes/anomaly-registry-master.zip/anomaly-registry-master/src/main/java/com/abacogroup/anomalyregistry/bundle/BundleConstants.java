package com.abacogroup.anomalyregistry.bundle;

public interface BundleConstants {

	String DOMAIN_I18N = "i18n";

	String DOMAIN_ANOMALY_ENTITY = "entity";

	String DOMAIN_ANOMALY_TYPE = "type";

	//--

	String SYSTEM_USER = "system";

	String JSONL_COMMENT = "--";
}
