package com.abacogroup.anomalyregistry.core;

public interface PublicService {
}
