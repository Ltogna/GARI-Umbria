package com.abacogroup.anomalyregistry;

import java.io.IOException;
import java.util.ArrayList;
import java.util.EnumSet;
import java.util.List;
import java.util.Optional;
import java.util.TimeZone;
import java.util.concurrent.TimeoutException;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.eclipse.jetty.servlets.CrossOriginFilter;
import org.jdbi.v3.core.Jdbi;

import com.abacogroup.anomalyregistry.AnomalyRegistryConfiguration.RabbitmqConfig;
import com.abacogroup.anomalyregistry.bundle.config.AnomalyTypeConfigMessageProcessor;
import com.abacogroup.anomalyregistry.bundle.config.I18nConfigMessageProcessor;
import com.abacogroup.anomalyregistry.bundle.tenant.AnomalyTypeTenantMessageProcessor;
import com.abacogroup.anomalyregistry.bundle.tenant.I18nTenantMessageProcessor;
import com.abacogroup.anomalyregistry.core.AnomalyEventProducer;
import com.abacogroup.anomalyregistry.core.AnomalyService;
import com.abacogroup.anomalyregistry.core.AnomalyServiceV1;
import com.abacogroup.anomalyregistry.core.AnomalyTypeService;
import com.abacogroup.anomalyregistry.core.AnomalyTypeServiceV1;
import com.abacogroup.anomalyregistry.core.impl.AnomalyEventProducerImpl;
import com.abacogroup.anomalyregistry.core.impl.AnomalyServiceImpl;
import com.abacogroup.anomalyregistry.core.impl.AnomalyServiceV1Impl;
import com.abacogroup.anomalyregistry.core.impl.AnomalyTypeServiceImpl;
import com.abacogroup.anomalyregistry.core.impl.AnomalyTypeServiceV1Impl;
import com.abacogroup.anomalyregistry.db.dao.AnomalyDAO;
import com.abacogroup.anomalyregistry.db.dao.AnomalyTypeDAO;
import com.abacogroup.anomalyregistry.db.dao.I18nDAO;
import com.abacogroup.anomalyregistry.resources.priv.DevtoolsResource;
import com.abacogroup.anomalyregistry.resources.pub.AnomalyTypeV1Resource;
import com.abacogroup.anomalyregistry.resources.pub.AnomalyV1Resource;
import com.abacogroup.bundles.Constants;
import com.abacogroup.bundles.initializer.BundleInitServiceBuilder;
import com.abacogroup.bundles.initializer.InitService;
import com.abacogroup.bundles.initializer.impl.BundleInitServiceProducer;
import com.abacogroup.bundles.listener.ListenerBuilder;
import com.abacogroup.bundles.listener.RabbitListener;
import com.abacogroup.bundles.listener.configdata.ConfigDataLogProducer;
import com.abacogroup.bundles.listener.configdata.ProcessorOrderPolicyEnum;
import com.abacogroup.bundles.listener.configdata.builder.ConfigDataConsumerBuilder;
import com.abacogroup.bundles.listener.tenant.builder.NewTenantEventConsumerBuilder;
import com.abacogroup.dropwizard.auth.multitenant.MultitenantFilter;
import com.abacogroup.dropwizard.auth.sso2.AuthUtils;
import com.abacogroup.dropwizard.auth.sso2.Sso2Client;
import com.abacogroup.dropwizard.auth.sso2.SsoAuthorizer;
import com.abacogroup.jdbi.OraJdbiPlugin;
import com.abacogroup.jdbi.PgJdbiPlugin;
import com.abacogroup.jdbi.config.AbacoJdbiConfig;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;

import io.dropwizard.client.JerseyClientBuilder;
import io.dropwizard.configuration.EnvironmentVariableSubstitutor;
import io.dropwizard.configuration.SubstitutingSourceProvider;
import io.dropwizard.core.Application;
import io.dropwizard.core.setup.Bootstrap;
import io.dropwizard.core.setup.Environment;
import io.dropwizard.db.DataSourceFactory;
import io.dropwizard.forms.MultiPartBundle;
import io.dropwizard.jdbi3.JdbiFactory;
import io.dropwizard.jersey.setup.JerseyEnvironment;
import io.dropwizard.migrations.MigrationsBundle;
import io.swagger.v3.jaxrs2.integration.resources.OpenApiResource;
import io.swagger.v3.oas.integration.SwaggerConfiguration;
import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Contact;
import io.swagger.v3.oas.models.info.Info;
import jakarta.servlet.DispatcherType;
import jakarta.servlet.FilterRegistration.Dynamic;
import jakarta.ws.rs.client.Client;
import jakarta.ws.rs.client.WebTarget;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class AnomalyRegistryApplication extends Application<AnomalyRegistryConfiguration> {

	public static void main(final String[] args) {
		try {
			new AnomalyRegistryApplication().run(args);
		} catch (Exception e) {
			log.error("Error during run anomaly-registry application: ", e);
			System.exit(1);
		}
	}

	@Override
	public String getName() {
		return "anomaly-registry";
	}

	@Override
	public void initialize(final Bootstrap<AnomalyRegistryConfiguration> bootstrap) {
		bootstrap.addBundle(new MigrationsBundle<>() {
			@Override
			public DataSourceFactory getDataSourceFactory(AnomalyRegistryConfiguration configuration) {
				return configuration.getDatabase();
			}
		});

		SubstitutingSourceProvider provider = new SubstitutingSourceProvider(bootstrap.getConfigurationSourceProvider(),
				new EnvironmentVariableSubstitutor(false));
		bootstrap.setConfigurationSourceProvider(provider);

		bootstrap.addBundle(new MultiPartBundle());
	}

	@Override
	public void run(final AnomalyRegistryConfiguration configuration, final Environment environment) throws Exception {
		ObjectMapper objectMapper = environment.getObjectMapper();
		configureObjectMapper(objectMapper);

		Jdbi jdbi = jdbi(configuration, environment);
		Connection rabbitmqConnection = this.createRabbitmqConnection(configuration);

		final WebTarget sso2Target = this.initSso2Target(configuration, environment);

		final AnomalyTypeDAO anomalyTypeDAO = jdbi.onDemand(AnomalyTypeDAO.class);
		final AnomalyDAO anomalyDAO = jdbi.onDemand(AnomalyDAO.class);

		final AnomalyTypeService anomalyTypeService = this.register(new AnomalyTypeServiceImpl(anomalyTypeDAO));
		final AnomalyEventProducer anomalyEventProducer = this.register(new AnomalyEventProducerImpl(rabbitmqConnection, objectMapper));
		final AnomalyService anomalyService = this.register(new AnomalyServiceImpl(anomalyDAO, anomalyTypeService, anomalyEventProducer));
		final AnomalyTypeServiceV1 anomalyTypeServiceV1 = this.register(new AnomalyTypeServiceV1Impl(anomalyTypeService));
		final AnomalyServiceV1 anomalyServiceV1 = this.register(new AnomalyServiceV1Impl(anomalyService));

		List<Object> resources = new ArrayList<>();

		// public
		resources.add(new AnomalyTypeV1Resource(anomalyTypeServiceV1));
		resources.add(new AnomalyV1Resource(anomalyServiceV1));

		if (configuration.isDevToolsEnabled()) {
			resources.add(new DevtoolsResource(rabbitmqConnection, jdbi));
		}

		resources.forEach(environment.jersey()::register);

		this.initAuth(environment, new Sso2Client(sso2Target));
		this.initMultiTenant(environment);
		this.initOpenApi(environment.jersey());
		this.setupCORS(configuration, environment);

		log.info("creating CONSUMERS rabbitConsumerManager");

		RabbitListener rabbitListener = ListenerBuilder
				.newBuilder(rabbitmqConnection)
				.withConfigDataConsumer(this.register(ConfigDataConsumerBuilder.newBuilder(jdbi, rabbitmqConnection)
						.route("anomaly-registry")
						.processor(this.register(new I18nConfigMessageProcessor(jdbi.onDemand(I18nDAO.class))))
						.processor(this.register(new AnomalyTypeConfigMessageProcessor(anomalyTypeDAO, objectMapper)))

						.configLogProducer(configDataLogProducerBean(objectMapper, rabbitmqConnection))
						.withOrderPolicy(ProcessorOrderPolicyEnum.PROCESSOR)
						.build()))

				.withNewTenantEventConsumer(NewTenantEventConsumerBuilder.newBuilder(jdbi)
						.route("anomaly-registry")
						.processor(this.register(new I18nTenantMessageProcessor(jdbi.onDemand(I18nDAO.class))))
						.processor(this.register(new AnomalyTypeTenantMessageProcessor(anomalyTypeDAO)))
						.build())
				.buildListener();

		log.info("creating INITIALIZERS");
		BundleConfig bundleConfig = configuration.getBundleConfig();

		InitService bundleInitService = BundleInitServiceBuilder
				.producer(this.register(new BundleInitServiceProducer(rabbitmqConnection)))
				.configLocation(bundleConfig.getConfigLocation())
				// .baseTempDir()
				.build();

		this.startRabbitConsumerAndProducers(bundleInitService, rabbitListener);
		this.afterServicesUp();

	}

	protected void afterServicesUp() {
		log.debug("application started");
	}

	protected ConfigDataLogProducer configDataLogProducerBean(ObjectMapper objectMapper, Connection rabbitmqConnection) {
		return this.register(new ConfigDataLogProducer(objectMapper, rabbitmqConnection, Constants.DEFAULT_EXCHANGE_NAME));
	}

	// private WebTarget initLauTarget(PartyRegistryConfiguration configuration, Environment environment) {
	// final Client client = new JerseyClientBuilder(environment)
	// .using(configuration.getJerseyClient())
	// .build("lau-client");
	// WebTarget lau = client.target(configuration.getLauUrl());
	// return lau;
	// }
	//

	private WebTarget initSso2Target(AnomalyRegistryConfiguration configuration, Environment environment) {
		final Client client = new JerseyClientBuilder(environment)
				.using(configuration.getJerseyClient())
				.build("sso2-client");

		WebTarget sso2Cli = client.target(configuration.getSso2Url());
		return sso2Cli;
	}

	protected void startRabbitConsumerAndProducers(InitService initService, RabbitListener rabbitListener) throws Exception {
		rabbitListener.start();
		initService.start();
	}

	protected Connection createRabbitmqConnection(AnomalyRegistryConfiguration configuration)
			throws IOException, TimeoutException {
		RabbitmqConfig rabbitmqConfig = configuration.getRabbitmqConfig();

		ConnectionFactory factory = new ConnectionFactory();

		if (rabbitmqConfig.getHost() != null) {
			factory.setHost(rabbitmqConfig.getHost());
		}
		if (rabbitmqConfig.getUser() != null) {
			factory.setUsername(rabbitmqConfig.getUser());
		}
		if (rabbitmqConfig.getPassword() != null) {
			factory.setPassword(rabbitmqConfig.getPassword());
		}
		if (rabbitmqConfig.getVirtualhost() != null) {
			factory.setVirtualHost(rabbitmqConfig.getVirtualhost());
		}
		if (rabbitmqConfig.getPort() != null) {
			factory.setPort(rabbitmqConfig.getPort());
		}
		factory.setAutomaticRecoveryEnabled(true);

		Connection connection = factory.newConnection();
		return connection;
	}

	protected void configureObjectMapper(ObjectMapper objectMapper) {
		objectMapper.registerModule(new JavaTimeModule());
		objectMapper
				.setTimeZone(TimeZone.getDefault())
				.disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);
	}

	protected void initAuth(Environment environment, Sso2Client sso2Cli) {
		AuthUtils.installAuthFilter(environment, sso2Cli, new SsoAuthorizer(sso2Cli));
	}

	protected Jdbi jdbi(final AnomalyRegistryConfiguration configuration, final Environment environment) {
		final JdbiFactory factory = new JdbiFactory();
		final Jdbi jdbi = factory.build(environment, configuration.getDatabase(), "AnomalyRegistryApplication");

		jdbi.configure(AbacoJdbiConfig.class, cfg -> cfg.setTablesPrefix("anm"));

		String driverClassName = Optional.ofNullable(configuration.getDatabase()
				.getDriverClass())
				.orElse("");

		if (driverClassName.equalsIgnoreCase("org.postgresql.Driver")) {
			jdbi.installPlugin(new PgJdbiPlugin());
		} else {
			jdbi.installPlugin(new OraJdbiPlugin());
		}
		return jdbi;
	}

	protected <T> T register(T service) {
		return service;
	}

	protected void initOpenApi(JerseyEnvironment jersey) {
		OpenAPI oas = new OpenAPI();
		oas.info(new Info()
				.title("ABACO Anomaly Registry")
				.description("Anomaly Registry APIs")
				.version("1.0")
				// .termsOfService("http://example.com/terms")
				.contact(new Contact().email("info@abacogroup.eu")));

		SwaggerConfiguration oasConfig = new SwaggerConfiguration()
				.openAPI(oas)
				.prettyPrint(true)
				.resourcePackages(Stream.of("com.abacogroup.anomalyregistry")
						.collect(Collectors.toSet()));

		jersey.register(new OpenApiResource()
				.openApiConfiguration(oasConfig));
	}

	private void setupCORS(AnomalyRegistryConfiguration configuration, Environment environment) {
		if (!configuration.isCors()) {
			log.info("CORS is disabled");
			return;
		}

		log.info("CORS is enabled");

		Dynamic cors = environment.servlets().addFilter("CORS", CrossOriginFilter.class);
		cors.setInitParameter(CrossOriginFilter.ALLOWED_ORIGINS_PARAM, "*");
		cors.setInitParameter(CrossOriginFilter.ALLOWED_HEADERS_PARAM, "*");
		cors.setInitParameter(CrossOriginFilter.ALLOWED_METHODS_PARAM, "GET,PUT,POST,DELETE");

		// OPTIONS pre-flight request will be served by the filter ONLY and not
		// passed ahead
		// cors.setInitParameter(CrossOriginFilter.CHAIN_PREFLIGHT_PARAM,
		// "false");

		// Add URL mapping
		cors.addMappingForUrlPatterns(EnumSet.allOf(DispatcherType.class), false, "*");
	}

	private void initMultiTenant(Environment environment) {
		environment.jersey().register(new MultitenantFilter("tenant"));
	}
}
