package com.abacogroup.anomalyregistry.core.impl;

import com.abacogroup.anomalyregistry.api.dto.AnomalyEventDto;
import com.abacogroup.anomalyregistry.core.AnomalyEventProducer;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.rabbitmq.client.AMQP;
import com.rabbitmq.client.BuiltinExchangeType;
import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import java.io.IOException;
import java.util.Map;
import java.util.UUID;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class AnomalyEventProducerImpl implements AnomalyEventProducer {

	private final Connection connection;
	private final ObjectMapper objectMapper;
	private Channel singleChannel;

	public static final String EXCHANGE = "anomaly-registry-exchange";

	public AnomalyEventProducerImpl(Connection connection, ObjectMapper objectMapper) {
		this.connection = connection;
		this.objectMapper = objectMapper;
	}

	@Override
	public void pushAnomalyEvent(AnomalyEventDto message, String tenant, AnomalyEventType eventType) throws IOException {
		String topic = eventType.getTopic();

		this.sendMessage(message, tenant, topic);
	}

	private synchronized void sendMessage(AnomalyEventDto message, String tenant, String topic) throws IOException {
		Map<String, Object> headers = Map.of("tenant", tenant);
		AMQP.BasicProperties properties = new AMQP.BasicProperties.Builder()
				.deliveryMode(2) // persistent
				.correlationId(UUID.randomUUID().toString())
				.contentType("application/octet-stream")
				.headers(headers)
				.build();
		byte[] body = objectMapper.writeValueAsBytes(message);

		Channel channel = this.getOrCreateChannel();
		channel.basicPublish(EXCHANGE, topic, properties, body);

		log.debug("'{}' pushed to exchange {} with topic {} and headers {}", message, EXCHANGE, topic, headers);
	}

	private synchronized Channel getOrCreateChannel() throws IOException {
		if (singleChannel == null) {
			Channel channel = connection.createChannel();
			channel.exchangeDeclare(EXCHANGE, BuiltinExchangeType.TOPIC);

			this.singleChannel = channel;
		}

		return this.singleChannel;
	}

}
