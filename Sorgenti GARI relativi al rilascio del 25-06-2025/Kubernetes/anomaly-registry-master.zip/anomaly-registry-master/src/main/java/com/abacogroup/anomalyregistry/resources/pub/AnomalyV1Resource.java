package com.abacogroup.anomalyregistry.resources.pub;

import com.abacogroup.anomalyregistry.api.dto.SearchAnomaliesByParcelIdsDto;
import com.abacogroup.anomalyregistry.api.v1.AnomalySearchResponse;
import com.abacogroup.anomalyregistry.api.v1.req.AnomalyRequest;
import com.abacogroup.anomalyregistry.api.v1.req.AnomalySearchRequest;
import com.abacogroup.anomalyregistry.core.AnomalyServiceV1;
import com.abacogroup.anomalyregistry.core.exceptions.AnomalyTypeException;
import com.abacogroup.anomalyregistry.resources.ResourceConstants;
import com.abacogroup.common.core.ReqContext;
import com.abacogroup.dropwizard.auth.sso2.User;
import io.dropwizard.auth.Auth;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import java.util.List;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import jakarta.ws.rs.BeanParam;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DefaultValue;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.HeaderParam;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Path(ResourceConstants.API_PUB + "/anomalies")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
@Tag(name = "Anomalies", description = "Operations on anomalies")
public class AnomalyV1Resource {

	private final AnomalyServiceV1 anomalyService;

	public AnomalyV1Resource(AnomalyServiceV1 anomalyService) {
		this.anomalyService = anomalyService;
	}

	@Operation(summary = "search anomalies", description = "Get list of anomalies by entity code filtered with criteria")
	@ApiResponse(responseCode = "200", description = "Successfully, returns a list of anomalies (sorted/filtered)",
			content = @Content(mediaType = "application/json",
					array = @ArraySchema(schema = @Schema(implementation = AnomalySearchResponse.class))))
	@GET
	@Path("/{entityCode}")
	//@RolesAllowed()
	public List<AnomalySearchResponse> search(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@PathParam("tenant") String tenantId,
			@PathParam("entityCode") String entityCode,
			@BeanParam AnomalySearchRequest searchRequest
	) {
		ReqContext reqContext = new ReqContext(user, lang);
		return anomalyService.search(reqContext, entityCode.toUpperCase(), searchRequest);
	}

	@POST
	@Path("/by-parcel-ids")
	public List<AnomalySearchResponse> searchByParcelIds(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@PathParam("tenant") String tenantId,
			@Valid SearchAnomaliesByParcelIdsDto dto
	) {
		ReqContext reqContext = new ReqContext(tenantId, user.getName(), lang);
		return anomalyService.searchByParcelIds(reqContext, dto);
	}

	@Operation(summary = "Create anomalies", description = "Insert new anomalies", responses = {
			@ApiResponse(responseCode = "200", description = "Successfully, the anomalies are created"),
			@ApiResponse(responseCode = "400", description = "anomaly creation error",
					content = @Content(mediaType = "application/json", schema = @Schema(anyOf = {
							AnomalyTypeException.ErrorBody.class
					})))
	})
	@POST
	//@RolesAllowed()
	public void add(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@PathParam("tenant") String tenantId,
			@NotNull @Valid List<AnomalyRequest> req
	) {
		ReqContext reqContext = new ReqContext(user, lang);
		anomalyService.add(reqContext, req);
	}

	@Operation(summary = "Remove anomalies", description = "Delete existing anomalies by setting them as expired", responses = {
			@ApiResponse(responseCode = "200", description = "Successfully, the anomalies are deleted")
	})
	@POST
	@Path("/expired")
	//@RolesAllowed()
	public void expire(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@PathParam("tenant") String tenantId,
			@NotNull @Valid List<AnomalyRequest> req
	) {
		ReqContext reqContext = new ReqContext(user, lang);
		anomalyService.expire(reqContext, req);
	}

}
