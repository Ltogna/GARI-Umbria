package com.abacogroup.anomalyregistry.resources.pub;

import com.abacogroup.anomalyregistry.api.v1.AnomalyTypeResponse;
import com.abacogroup.anomalyregistry.api.v1.req.AnomalyTypeSearchRequest;
import com.abacogroup.anomalyregistry.core.AnomalyTypeServiceV1;
import com.abacogroup.anomalyregistry.resources.ResourceConstants;
import com.abacogroup.common.core.ReqContext;
import com.abacogroup.dropwizard.auth.sso2.User;
import io.dropwizard.auth.Auth;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import java.util.List;
import jakarta.ws.rs.BeanParam;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DefaultValue;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.HeaderParam;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Path(ResourceConstants.API_PUB + "/anomaly-types")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
@Tag(name = "Anomaly Types", description = "Operations on anomaly types")
public class AnomalyTypeV1Resource {

	private final AnomalyTypeServiceV1 anomalyTypeService;

	public AnomalyTypeV1Resource(AnomalyTypeServiceV1 anomalyTypeService) {
		this.anomalyTypeService = anomalyTypeService;
	}

	@Operation(summary = "search anomaly types", description = "Get list of anomaly types filtered with criteria")
	@ApiResponse(responseCode = "200", description = "Successfully, returns a list of anomaly types (sorted/filtered)",
			content = @Content(mediaType = "application/json",
					array = @ArraySchema(schema = @Schema(implementation = AnomalyTypeResponse.class))))
	@GET
	//@RolesAllowed()
	public List<AnomalyTypeResponse> search(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@PathParam("tenant") String tenantId,
			@BeanParam AnomalyTypeSearchRequest searchRequest
	) {
		ReqContext reqContext = new ReqContext(user, lang);
		return anomalyTypeService.searchAll(reqContext, searchRequest);
	}

	@Operation(summary = "Find anomaly type by id", description = "Get anomaly type info based on its id")
	@ApiResponses({
			@ApiResponse(responseCode = "200", description = "Successfully, anomaly type is found",
					content = @Content(mediaType = "application/json",
							schema = @Schema(implementation = AnomalyTypeResponse.class, nullable = true))),
			@ApiResponse(responseCode = "204", description = "Anomaly type is not found")
	})
	@GET
	@Path("/{id}")
	//@RolesAllowed()
	public AnomalyTypeResponse getById(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@PathParam("tenant") String tenantId,
			@PathParam("id") Long id
	) {
		ReqContext reqContext = new ReqContext(user, lang);
		return this.anomalyTypeService.getById(reqContext, id).orElse(null);
	}

}
