package com.abacogroup.anomalyregistry.api.req;

import com.abacogroup.anomalyregistry.resources.ResourceConstants;
import com.abacogroup.jdbi.criteria.Criteria;
import com.abacogroup.jdbi.criteria.CriteriaBuilder;
import com.abacogroup.jdbi.orderby.OrderByBuilder;
import com.abacogroup.jdbi.orderby.OrderByElement;
import com.abacogroup.jdbi.orderby.SortDirection;
import com.fasterxml.jackson.annotation.JsonIgnore;
import io.swagger.v3.oas.annotations.media.Schema;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import jakarta.ws.rs.QueryParam;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;
import org.apache.commons.lang3.StringUtils;

@Data
@NoArgsConstructor
@Accessors(chain = true)
public class AnomalyTypeSearchReq implements BaseSearchReq {

	@QueryParam("code")
	private String code;

	@QueryParam("groupCode")
	private String groupCode;

	@QueryParam("i18nCode")
	private String i18nCode;

	@Override
	@JsonIgnore
	@Schema(hidden = true)
	public int getPageSize() {
		return ResourceConstants.PAGE_SIZE;
	}

	@Override
	@JsonIgnore
	@Schema(hidden = true)
	public Criteria getCriteria() {
		List<Criteria> specs = new ArrayList<>();

		Optional.ofNullable(this.getCode())
				.filter(StringUtils::isNotBlank)
				.ifPresent(v -> specs.add(CriteriaBuilder.string("code").eq(StringUtils.upperCase(v))));

		Optional.ofNullable(this.getGroupCode())
				.filter(StringUtils::isNotBlank)
				.ifPresent(v -> specs.add(CriteriaBuilder.string("group_code").eq(StringUtils.upperCase(v))));

		Optional.ofNullable(this.getI18nCode())
				.filter(StringUtils::isNotBlank)
				.ifPresent(v -> specs.add(CriteriaBuilder.string("i18n_code").caseInsensitiveContains(v)));

		return CriteriaBuilder.and(specs.toArray(new Criteria[0]));
	}

	@JsonIgnore
	@Schema(hidden = true)
	@Override
	public OrderByElement getSort() {
		return OrderByBuilder.field("i18n_code").direction(SortDirection.ASC);
	}
}
