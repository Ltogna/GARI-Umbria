package com.abacogroup.common.bundle.config;

import com.abacogroup.anomalyregistry.bundle.BundleConstants;
import com.abacogroup.anomalyregistry.db.dao.I18nDAO;
import com.abacogroup.anomalyregistry.db.ntt.I18nEntity;
import com.abacogroup.bundles.initializer.impl.exceptions.BundleException;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Optional;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import jakarta.validation.constraints.NotNull;
import lombok.Builder;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

@Slf4j
public class I18nProcessor {
	private final I18nDAO i18nDAO;

	private final ObjectMapper mapper = new ObjectMapper();

	public I18nProcessor(I18nDAO i18nDAO) {
		this.i18nDAO = i18nDAO;
	}

	public void addContent(String tenantId, Path path, I18nContext... contexts) {

		mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		try {

			var contextMaps = Arrays.stream(contexts)
					.collect(Collectors.toMap(I18nContext::getFieldName, Function.identity()));

			try (Stream<String> input = Files.lines(path, StandardCharsets.UTF_8)) {
				I18nEntity[] entities = input
						.map(String::strip)
						.filter(s -> !StringUtils.isBlank(s))
						.filter(s -> !s.startsWith(BundleConstants.JSONL_COMMENT))
						.map(jsonLine -> mapEntity(tenantId, contextMaps, jsonLine))
						.filter(Optional::isPresent)
						.map(Optional::get)
						.toArray(I18nEntity[]::new);
				i18nDAO.deleteBatch(entities);
				i18nDAO.insertBatch(entities);
			}
		} catch (Exception e) {
			throw new BundleException(String.format("error saving file %s", path), e);
		}
	}

	private Optional<? extends I18nEntity> mapEntity(String tenantId, Map<String, I18nContext> contexts, String jsonLine) {
		try {
			I18nEntityMixin entityMixin = mapper.readValue(jsonLine, I18nEntityMixin.class);
			var codeEntry = entityMixin.getDynamicCode()
					.entrySet()
					.stream()
					.findFirst();

			if (codeEntry.isEmpty()) {
				log.warn("unable to determine the code in {}", jsonLine);
				return Optional.empty();
			}

			var dynamicKey = codeEntry.map(Entry::getKey).orElse(null);
			var dynamicVal = codeEntry.map(Entry::getValue).orElse(null);
			if (StringUtils.isBlank(dynamicKey) || StringUtils.isBlank(dynamicVal)) {
				log.warn("unable to determine the code in {}", jsonLine);
				return Optional.empty();
			}

			var ctx = contexts.get(dynamicKey);
			if (ctx == null) {
				log.warn("missing configuration for {}", dynamicKey);
				return Optional.empty();
			}

			return Optional.of(ctx)
					.map(c -> I18nEntity.builder()
							.setTableName(c.getTableName())
							.setFieldName(c.getFieldName())
							.setTenantId(tenantId)
							.setLang(entityMixin.getLang())
							.setI18nValue(dynamicVal)
							.setI18nText(entityMixin.getI18nText())
							.build());

		} catch (Exception e) {
			throw new BundleException("error in deserialization json " + jsonLine, e);
		}
	}

	/**
	 * il json DEVE presentare un attributo identico al valore fieldName
	 */
	@Data
	@Builder(setterPrefix = "set")
	public static class I18nContext {
		private String tableName;
		private String fieldName;
	}

	@Data
	static class I18nEntityMixin {

		@JsonAnyGetter
		@JsonAnySetter
		private Map<String, String> dynamicCode = new HashMap<>();

		@NotNull
		@JsonProperty("lang")
		private String lang;

		@NotNull
		@JsonProperty("value")
		private String i18nText;
	}

}
