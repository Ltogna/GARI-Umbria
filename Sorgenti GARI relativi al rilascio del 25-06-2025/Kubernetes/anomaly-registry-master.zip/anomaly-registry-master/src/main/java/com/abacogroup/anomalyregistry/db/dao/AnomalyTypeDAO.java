package com.abacogroup.anomalyregistry.db.dao;

import java.util.List;
import java.util.Optional;

import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.customizer.BindBean;
import org.jdbi.v3.sqlobject.statement.SqlBatch;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;
import org.jdbi.v3.sqlobject.transaction.Transactional;

import com.abacogroup.anomalyregistry.api.AnomalyTypeRes;
import com.abacogroup.anomalyregistry.db.ntt.AnomalyTypeEntity;
import com.abacogroup.common.core.ReqContext;
import com.abacogroup.common.db.ntt.AuditDAO;
import com.abacogroup.jdbi.criteria.BindCriteria;
import com.abacogroup.jdbi.criteria.Criteria;
import com.abacogroup.jdbi.orderby.DefineOrder;
import com.abacogroup.jdbi.orderby.OrderBy;

public interface AnomalyTypeDAO extends Transactional<AnomalyTypeDAO>, AuditDAO {

	@SqlQuery("select * from ( "
			+ " SELECT at.id, at.code, at.group_code "
			+ ", coalesce (§i18n(:tenantId, 'anm_anomaly_types', 'code', at.code, :lang)§, at.code) AS i18n_code "
			+ " FROM anm_anomaly_types at "
			+ " WHERE at.tenant_id = :tenantId "
			+ " AND (CURRENT_TIMESTAMP between at.dt_insert and at.dt_delete) "
			+ ") inner_result "
			+ "where <criteria> ORDER BY <orderBy> "
	)
	@RegisterBeanMapper(AnomalyTypeRes.class)
	List<AnomalyTypeRes> searchAll(
			@BindBean ReqContext ctx,
			@BindCriteria Criteria criteria,
			@DefineOrder OrderBy orderBy);

	@SqlQuery(" SELECT at.id, at.code, at.group_code "
			+ ", coalesce (§i18n(:tenantId, 'anm_anomaly_types', 'code', at.code, :lang)§, at.code) AS i18n_code "
			+ " FROM anm_anomaly_types at "
			+ " WHERE at.tenant_id = :tenantId "
			+ " AND at.id = :id "
			+ " AND (CURRENT_TIMESTAMP between at.dt_insert and at.dt_delete) "
	)
	@RegisterBeanMapper(AnomalyTypeRes.class)
	Optional<AnomalyTypeRes> getById(
			@Bind("id") Long id,
			@BindBean ReqContext ctx);

	@SqlQuery(" SELECT at.id, at.code, at.group_code "
			+ " FROM anm_anomaly_types at "
			+ " WHERE at.tenant_id = :tenantId "
			+ " AND at.code = :code and at.group_code = :groupCode "
			+ " AND (CURRENT_TIMESTAMP between at.dt_insert and at.dt_delete) "
	)
	@RegisterBeanMapper(AnomalyTypeEntity.class)
	Optional<AnomalyTypeEntity> findByGroupCodeAndCode(
			@Bind("tenantId") String tenantId,
			@Bind("groupCode") String groupCode,
			@Bind("code") String code);

	@SqlQuery(" SELECT distinct at.id, at.code, at.group_code "
			+ " FROM anm_anomaly_types at "
			+ " left join anm_anomalies a on a.type_id = at.id and (CURRENT_TIMESTAMP between a.dt_insert and a.dt_delete) "
			+ " WHERE at.tenant_id = :tenantId "
			+ " AND at.code = :code and at.group_code = :groupCode "
			+ " AND a.type_id is null "
			+ " AND (CURRENT_TIMESTAMP between at.dt_insert and at.dt_delete) "
	)
	@RegisterBeanMapper(AnomalyTypeEntity.class)
	Optional<AnomalyTypeEntity> findNotInUseByCodeAndGroupCode(
			@Bind("tenantId") String tenantId,
			@Bind("code") String code,
			@Bind("groupCode") String groupCode);

	@SqlBatch("insert into anm_anomaly_types (tenant_id,group_code,code,dt_insert,user_id_insert,dt_delete,user_id_delete) "
			+ "§select_from_dual(:tenantId,:groupCode,:code,:dtInsert, :userIdInsert, :dtDelete, :userIdDelete)§ "
			+ "where not exists (select id from anm_anomaly_types where tenant_id = :tenantId and group_code = :groupCode and code =:code AND (CURRENT_TIMESTAMP between dt_insert and dt_delete))")
	void insertBatch(@BindBean AnomalyTypeEntity... entities);

	@SqlUpdate("insert into anm_anomaly_types (tenant_id,group_code,code,dt_insert,user_id_insert,dt_delete,user_id_delete)"
			+ " select :newTenantId, group_code, code, :dtInsert, :userIdInsert, :dtDelete, :userIdDelete "
			+ " from anm_anomaly_types "
			+ " where tenant_id = :sourceTenant AND (CURRENT_TIMESTAMP between dt_insert and dt_delete) ")
	void insertNewTenant(
			@Bind("sourceTenant") String sourceTenant,
			@Bind("newTenantId") String newTenantId,
			@BindBean AnomalyTypeEntity audit);

	@SqlUpdate("update anm_anomaly_types set dt_delete =:dtDelete, user_id_delete=:userIdDelete where id = :id")
	void expireRow(@BindBean AnomalyTypeEntity entity);
}
