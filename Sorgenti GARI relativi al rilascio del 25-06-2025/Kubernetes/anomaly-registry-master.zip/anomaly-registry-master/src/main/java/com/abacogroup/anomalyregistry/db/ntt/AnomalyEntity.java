package com.abacogroup.anomalyregistry.db.ntt;

import com.abacogroup.common.db.ntt.AuditEntity;
import java.time.LocalDateTime;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder(setterPrefix = "set")
@NoArgsConstructor
public class AnomalyEntity implements AuditEntity {

	private Long id;
	private String tenantId;

	private Long typeId;        //FK
	private String entityCode;
	private String entityId;

	private LocalDateTime dtInsert;
	private String userIdInsert;
	private LocalDateTime dtDelete;
	private String userIdDelete;

}
