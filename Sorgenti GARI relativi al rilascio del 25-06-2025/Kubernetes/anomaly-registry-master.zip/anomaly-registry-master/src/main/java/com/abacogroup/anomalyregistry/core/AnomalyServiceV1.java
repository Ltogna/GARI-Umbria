package com.abacogroup.anomalyregistry.core;

import com.abacogroup.anomalyregistry.api.AnomalySearchRes;
import com.abacogroup.anomalyregistry.api.dto.SearchAnomaliesByParcelIdsDto;
import com.abacogroup.anomalyregistry.api.v1.AnomalySearchResponse;
import com.abacogroup.anomalyregistry.api.v1.req.AnomalyRequest;
import com.abacogroup.anomalyregistry.api.v1.req.AnomalySearchRequest;
import com.abacogroup.common.core.ReqContext;
import jakarta.validation.Valid;

import java.util.List;

public interface AnomalyServiceV1 extends PublicService {
	List<AnomalySearchResponse> search(ReqContext reqContext, String entityCode, AnomalySearchRequest searchRequest);

	void add(ReqContext reqContext, List<AnomalyRequest> anomalyRequests);

	void expire(ReqContext reqContext, List<AnomalyRequest> anomalyRequests);

	void expireAllById(ReqContext reqContext, List<Long> listIds);

	List<AnomalySearchResponse> searchByParcelIds(ReqContext reqContext, @Valid SearchAnomaliesByParcelIdsDto dto);
}
