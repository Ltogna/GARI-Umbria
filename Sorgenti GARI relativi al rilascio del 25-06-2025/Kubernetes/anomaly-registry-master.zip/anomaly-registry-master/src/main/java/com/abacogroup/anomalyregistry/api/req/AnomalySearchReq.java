package com.abacogroup.anomalyregistry.api.req;

import static java.util.stream.Collectors.toList;

import com.abacogroup.anomalyregistry.resources.ResourceConstants;
import com.abacogroup.jdbi.criteria.Criteria;
import com.abacogroup.jdbi.criteria.CriteriaBuilder;
import com.abacogroup.jdbi.orderby.OrderByBuilder;
import com.abacogroup.jdbi.orderby.OrderByElement;
import com.abacogroup.jdbi.orderby.SortDirection;
import com.fasterxml.jackson.annotation.JsonIgnore;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.media.Schema;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import jakarta.ws.rs.QueryParam;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

@Data
@NoArgsConstructor
@Accessors(chain = true)
public class AnomalySearchReq implements BaseSearchReq {

	@Parameter(in = ParameterIn.QUERY, description = "list of group code")
	@QueryParam("groupCode")
	private List<String> groupCode;

	@Parameter(in = ParameterIn.QUERY, description = "list of anomalyType code")
	@QueryParam("typeCode")
	private List<String> typeCode;

	@Parameter(in = ParameterIn.QUERY, description = "list of entity ID")
	@QueryParam("entityId")
	private List<String> entityId;

	@Parameter(in = ParameterIn.QUERY, description = "list of type ID")
	@QueryParam("typeId")
	private List<Long> typeId;

	@Override public int getPageSize() {
		return ResourceConstants.PAGE_SIZE;
	}

	@Override
	@JsonIgnore
	@Schema(hidden = true)
	public Criteria getCriteria() {
		List<Criteria> specs = new ArrayList<>();

		Optional.ofNullable(this.getGroupCode())
				.filter(x -> !x.isEmpty())
				.ifPresent(v -> specs.add(CriteriaBuilder.string("anomaly_type_group_code").in(v)));

		Optional.ofNullable(getTypeCode())
				.filter(x -> !x.isEmpty())
				.ifPresent(v -> specs.add(CriteriaBuilder.string("anomaly_type_code").in(v)));

		Optional.ofNullable(getEntityId())
				.filter(x -> !x.isEmpty())
				.ifPresent(v -> specs.add(CriteriaBuilder.string("entity_id").in(v)));

		Optional.ofNullable(getTypeId())
				.filter(x -> !x.isEmpty())
				.ifPresent(v -> specs.add(CriteriaBuilder.number("type_id").in(v.stream().map(Number.class::cast).collect(toList()))));

		return CriteriaBuilder.and(specs.toArray(new Criteria[0]));
	}

	@Override
	@JsonIgnore
	@Schema(hidden = true)
	public OrderByElement getSort() {
		return OrderByBuilder.field("id").direction(SortDirection.ASC);
	}

}
