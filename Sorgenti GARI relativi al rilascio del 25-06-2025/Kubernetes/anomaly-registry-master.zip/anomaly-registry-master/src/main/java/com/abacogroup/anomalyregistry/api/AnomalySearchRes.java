package com.abacogroup.anomalyregistry.api;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;
import org.jdbi.v3.core.mapper.Nested;

// TO MOVE
@Data
@SuperBuilder(setterPrefix = "set")
@NoArgsConstructor
@AllArgsConstructor
public class AnomalySearchRes {

	private Long id;

	private String entityCode;
	private String entityId;

	@Nested("anomaly_type")
	private AnomalyTypeRes type;

}
