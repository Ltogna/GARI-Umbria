package com.abacogroup.anomalyregistry.core.impl;

import com.abacogroup.anomalyregistry.api.AnomalySearchRes;
import com.abacogroup.anomalyregistry.api.dto.AnomalyEventDto;
import com.abacogroup.anomalyregistry.api.dto.SearchAnomaliesByParcelIdsDto;
import com.abacogroup.anomalyregistry.api.req.AnomalyReq;
import com.abacogroup.anomalyregistry.api.req.AnomalySearchReq;
import com.abacogroup.anomalyregistry.api.req.mappers.AnomalyMapper;
import com.abacogroup.anomalyregistry.api.v1.AnomalySearchResponse;
import com.abacogroup.anomalyregistry.core.AnomalyEventProducer;
import com.abacogroup.anomalyregistry.core.AnomalyEventProducer.AnomalyEventType;
import com.abacogroup.anomalyregistry.core.AnomalyService;
import com.abacogroup.anomalyregistry.core.AnomalyTypeService;
import com.abacogroup.anomalyregistry.core.exceptions.AnomalyTypeException;
import com.abacogroup.anomalyregistry.db.dao.AnomalyDAO;
import com.abacogroup.anomalyregistry.db.ntt.AnomalyEntity;
import com.abacogroup.anomalyregistry.db.ntt.AnomalyTypeEntity;
import com.abacogroup.common.core.ReqContext;
import com.abacogroup.jdbi.criteria.Criteria;
import com.abacogroup.jdbi.orderby.OrderByElement;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

import com.google.common.collect.Iterators;
import com.google.common.collect.UnmodifiableIterator;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class AnomalyServiceImpl implements AnomalyService {

	private final AnomalyDAO anomalyDAO;
	private final AnomalyTypeService anomalyTypeService;
	private final AnomalyEventProducer anomalyEventProducer;

	public AnomalyServiceImpl(AnomalyDAO anomalyDAO, AnomalyTypeService anomalyTypeService, AnomalyEventProducer anomalyEventProducer) {
		this.anomalyDAO = anomalyDAO;
		this.anomalyTypeService = anomalyTypeService;
		this.anomalyEventProducer = anomalyEventProducer;
	}

	@Override
	public List<AnomalySearchRes> search(ReqContext reqContext, String entityCode, AnomalySearchReq searchRequest) {

		Criteria criteria = searchRequest.getCriteria();
		OrderByElement sort = searchRequest.getSort();

		return anomalyDAO.search(reqContext, entityCode, criteria, sort);
	}

	@Override
	public List<AnomalySearchRes> searchByParcelIds(ReqContext reqContext, SearchAnomaliesByParcelIdsDto dto) {
		UnmodifiableIterator<List<Long>> parcelIdsPartition = Iterators.partition(dto.getParcelIds().iterator(), 500);
		List<AnomalySearchRes> result = new ArrayList<>();

		parcelIdsPartition.forEachRemaining(parcelIds -> {
			List<AnomalySearchRes> partialResult = anomalyDAO.searchByParcelId(reqContext, dto.getParcelIds());
			result.addAll(partialResult);
		});

		return result;
	}

	@Override
	public void add(ReqContext reqContext, List<AnomalyReq> anomalyRequests) {

		List<Long> ids = anomalyDAO.inTransaction(dao -> anomalyRequests.stream()
				.filter(anm -> dao.findByRequest(reqContext.getTenantId(), anm).isEmpty())
				.map(anm -> {
					// check fg key : typeId
					AnomalyTypeEntity anomalyTypeEntity = anomalyTypeService.findEntityByGroupCodeAndCode(reqContext.getTenantId(),
									anm.getTypeGroupCode(), anm.getTypeCode())
							.orElseThrow(() -> new AnomalyTypeException(AnomalyTypeException.ANOMALY_TYPE_NOT_FOUND,
									String.format("no anomaly type found by groupCode %s and code %s", anm.getTypeGroupCode(), anm.getTypeCode())));

					AnomalyEntity entity = AnomalyMapper.INSTANCE.requestToEntity(anm);
					entity.setTenantId(reqContext.getTenantId());
					entity.setTypeId(anomalyTypeEntity.getId());
					entity.setEntityCode(entity.getEntityCode().toUpperCase());
					return entity;
				})
				.map(anomaly -> {
					dao.setAuditForInsert(reqContext.getUsername(), anomaly);
					Long id = dao.insert(anomaly);
					return id;
				})
				.filter(Objects::nonNull)
				.collect(Collectors.toList()));

		if (!ids.isEmpty()) {
			this.pushAnomalyEvent(reqContext, ids, AnomalyEventType.NEW);
		}
	}

	@Override
	public void expire(ReqContext reqContext, List<AnomalyReq> anomalyRequests) {
		List<Long> listIds = anomalyRequests.stream()
				.flatMap(anm -> anomalyDAO.findByRequest(reqContext.getTenantId(), anm)
						.map(AnomalyEntity::getId)
						.stream())
				.collect(Collectors.toList());

		expireAllById(reqContext, listIds);
	}

	@Override
	public void expireAllById(ReqContext reqContext, List<Long> listIds) {
		if (!listIds.isEmpty()) {
			AnomalyEntity audit = AnomalyEntity.builder().build();
			anomalyDAO.setAuditForExpire(reqContext.getUsername(), audit);
			anomalyDAO.expireInBatch(listIds, audit);

			this.pushAnomalyEvent(reqContext, listIds, AnomalyEventType.EXPIRED);
		}
	}

	@Override
	public Optional<AnomalyEntity> findEntityById(String tenantId, Long id) {
		return anomalyDAO.findById(tenantId, id);
	}

	private void pushAnomalyEvent(ReqContext reqContext, List<Long> listIds, AnomalyEventType eventType) {
		List<AnomalyEventDto> anomalies = anomalyDAO.getAnomaliesByIdInAndIncludeDeleted(reqContext.getTenantId(), listIds);

		for (AnomalyEventDto anomalyEventDto : anomalies) {
			try {
				anomalyEventProducer.pushAnomalyEvent(anomalyEventDto, reqContext.getTenantId(), eventType);
			} catch (IOException e) {
				log.warn("cannot send {} anomaly event for anomaly {}: {}", eventType, anomalyEventDto.getId(), e.getMessage(), e);
			}
		}
	}
}
