package com.abacogroup.anomalyregistry.api;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder(setterPrefix = "set")
@NoArgsConstructor
public class AnomalyTypeRes {

	private Long id;

	private String groupCode;
	private String code;

	private String i18nCode;

}
