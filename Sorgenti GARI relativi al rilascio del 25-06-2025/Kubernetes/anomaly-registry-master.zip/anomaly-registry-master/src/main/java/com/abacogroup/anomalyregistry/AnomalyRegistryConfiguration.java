package com.abacogroup.anomalyregistry;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.dropwizard.client.JerseyClientConfiguration;
import io.dropwizard.core.Configuration;
import io.dropwizard.db.DataSourceFactory;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Data
public class AnomalyRegistryConfiguration extends Configuration {

	private boolean cors = true;

	@Valid
	@NotNull
	private DataSourceFactory database;

	private RabbitmqConfig rabbitmqConfig;

	@JsonProperty("sso2-url")
	private String sso2Url;

	@Valid
	private BundleConfig bundleConfig;

	@JsonProperty("devtools-enabled")
	private boolean devToolsEnabled = false;

	@Valid
	@NotNull
	@Getter
	@Setter
	private JerseyClientConfiguration jerseyClient = new JerseyClientConfiguration();

	@Data
	public static class RabbitmqConfig {

		private String host;
		private String user;
		private String password;
		private String virtualhost;
		private Integer port;
	}

}
