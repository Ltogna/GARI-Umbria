package com.abacogroup.anomalyregistry.api.req.mappers;

import com.abacogroup.anomalyregistry.api.AnomalyTypeRes;
import com.abacogroup.anomalyregistry.api.v1.AnomalyTypeResponse;
import java.util.List;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper
public interface AnomalyTypeMapper {

	AnomalyTypeMapper INSTANCE = Mappers.getMapper(AnomalyTypeMapper.class);

	AnomalyTypeResponse toV1(AnomalyTypeRes res);

	List<AnomalyTypeResponse> toV1List(List<AnomalyTypeRes> resList);

}
