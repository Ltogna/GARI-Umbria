package com.abacogroup.anomalyregistry.core;

import com.abacogroup.anomalyregistry.api.AnomalyTypeRes;
import com.abacogroup.anomalyregistry.api.req.AnomalyTypeSearchReq;
import com.abacogroup.anomalyregistry.db.ntt.AnomalyTypeEntity;
import com.abacogroup.common.core.ReqContext;
import java.util.List;
import java.util.Optional;

public interface AnomalyTypeService {
	List<AnomalyTypeRes> searchAll(ReqContext reqContext, AnomalyTypeSearchReq searchRequest);

	Optional<AnomalyTypeRes> getById(ReqContext reqContext, Long id);

	Optional<AnomalyTypeEntity> findEntityByGroupCodeAndCode(String tenantId, String groupCode, String code);
}
