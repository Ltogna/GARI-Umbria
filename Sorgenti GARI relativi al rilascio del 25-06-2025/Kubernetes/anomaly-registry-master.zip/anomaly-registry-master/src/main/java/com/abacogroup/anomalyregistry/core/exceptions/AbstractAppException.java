package com.abacogroup.anomalyregistry.core.exceptions;

import jakarta.ws.rs.WebApplicationException;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.core.Response.Status;
import lombok.Data;

@Data
public abstract class AbstractAppException extends WebApplicationException {

	private ExceptionErrorBody errorBody;

	protected AbstractAppException() {
	}

	AbstractAppException(ExceptionErrorBody body) {
		super(body.getMessage(),
				Response.status(Status.BAD_REQUEST)
						.entity(body)
						.build());
		this.errorBody = body;
	}

	public String getCode() {
		return getErrorBody().getErrorCode();
	}

	public interface ExceptionErrorBody {
		String getErrorCode();

		default String getMessage() {
			return "TODO";
		}
	}

}
