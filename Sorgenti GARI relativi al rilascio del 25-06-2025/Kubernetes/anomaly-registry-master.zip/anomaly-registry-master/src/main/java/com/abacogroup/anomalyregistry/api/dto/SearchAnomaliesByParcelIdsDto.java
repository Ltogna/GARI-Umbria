package com.abacogroup.anomalyregistry.api.dto;

import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Data;

import java.util.List;

@Data
public class SearchAnomaliesByParcelIdsDto {
    @NotNull
    @NotEmpty
    @Size(min = 1, max = 1000)
    private List<Long> parcelIds;
}
