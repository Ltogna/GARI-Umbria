package com.abacogroup.anomalyregistry.core.impl;

import com.abacogroup.anomalyregistry.api.AnomalyTypeRes;
import com.abacogroup.anomalyregistry.api.req.mappers.AnomalyTypeMapper;
import com.abacogroup.anomalyregistry.api.req.mappers.AnomalyTypeSearchReqMapper;
import com.abacogroup.anomalyregistry.api.v1.AnomalyTypeResponse;
import com.abacogroup.anomalyregistry.api.v1.req.AnomalyTypeSearchRequest;
import com.abacogroup.anomalyregistry.core.AnomalyTypeService;
import com.abacogroup.anomalyregistry.core.AnomalyTypeServiceV1;
import com.abacogroup.common.core.ReqContext;
import java.util.List;
import java.util.Optional;

public class AnomalyTypeServiceV1Impl implements AnomalyTypeServiceV1 {

	private final AnomalyTypeService anomalyTypeService;

	public AnomalyTypeServiceV1Impl(AnomalyTypeService anomalyTypeService) {
		this.anomalyTypeService = anomalyTypeService;
	}

	@Override
	public List<AnomalyTypeResponse> searchAll(ReqContext reqContext, AnomalyTypeSearchRequest searchRequest) {
		List<AnomalyTypeRes> resList = anomalyTypeService.searchAll(reqContext, AnomalyTypeSearchReqMapper.INSTANCE.fromV1(searchRequest));
		return AnomalyTypeMapper.INSTANCE.toV1List(resList);
	}

	@Override
	public Optional<AnomalyTypeResponse> getById(ReqContext reqContext, Long id) {
		return anomalyTypeService.getById(reqContext, id).map(AnomalyTypeMapper.INSTANCE::toV1);
	}
}
