package com.abacogroup.anomalyregistry.core.exceptions;

import io.swagger.v3.oas.annotations.media.Schema;

public class AnomalyException extends AbstractAppException {

	public static final String ANOMALY_NOT_FOUND = "ANOMALY_NOT_FOUND";
	public static final String INVALID_ENTITY_CODE = "INVALID_ENTITY_CODE";

	public AnomalyException(String code, String message) {
		super(new ErrorBody(code, message));
	}

	@Schema(name = "InvalidAnomalyErrorBody")
	public static class ErrorBody implements ExceptionErrorBody {
		private final String code;
		private final String message;

		public ErrorBody(String code, String message) {
			this.code = code;
			this.message = message;
		}

		@Override
		@Schema(allowableValues = { ANOMALY_NOT_FOUND, INVALID_ENTITY_CODE })
		public String getErrorCode() {
			return code;
		}

		@Override
		@Schema
		public String getMessage() {
			return message;
		}
	}
}
