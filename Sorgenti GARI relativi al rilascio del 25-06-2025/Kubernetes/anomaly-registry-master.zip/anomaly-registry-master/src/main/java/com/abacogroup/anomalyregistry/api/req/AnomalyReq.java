package com.abacogroup.anomalyregistry.api.req;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;
import lombok.experimental.SuperBuilder;

@Data
@NoArgsConstructor
@Accessors(chain = true)
@SuperBuilder(setterPrefix = "set")
public class AnomalyReq {

	@NotBlank
	private String typeGroupCode;

	@NotBlank
	private String typeCode;

	@NotBlank
	private String entityCode;

	@NotBlank
	private String entityId;

}
