# AGRI APPLICATIONS

## Bundles Infrastructure integration

The application must be connected to a RabbitMQ instance.

The bundles infrastructure will automatically set up to allow automatic configuration.

The application module id is `applications` and the supported changeset domains are:

```
📂 applications
┣ 📂 <client-id>-<nnnn>
┣ ┣ 📂 workflows
    ┣ 📜 <any file>.jar|.zip
    📂 modules
    ┣ 📜 <any file>.json
    📂 sectors
    ┣ 📜 <any file>.json
```

n = one digit (0..9)

The workflow file(s) is a jar or zip containing the workflow definition.

The modules JSON file(s) must have the following structure:

```json
{
  "modules": [
    {
      "moduleCode": "String (mandatory)",
      "sectorCode": "String (mandatory)",
      "workflowCode": "String (mandatory)",
      "annuality": "Integer",
      "contextFunction": "String",
      "dtValidityStart": "AbsoluteDate (mandatory)",
      "dtValidityEnd": "AbsoluteDate (mandatory)",
      "i18n": [
        {
          "lang": "String (mandatory)",
          "description": "String (mandatory)"
        }
      ],
      "forms": {
        "formCatalogs": [
          {
            "formCode": "String (mandatory)",
            "softwareUrl": "String (mandatory)",
            "routerUrl": "String (mandatory)",
            "i18n": [
              {
                "lang": "String (mandatory)",
                "description": "String (mandatory)"
              }
            ]
          }
        ],
        "formGroups": [
          {
            "formGroupCode": "String (mandatory)",
            "formGroupChildren": [
              {
                "formGroupCode": "String (mandatory)",
                "formGroupChildren": [],
                "i18n": [
                  {
                    "lang": "String (mandatory)",
                    "description": "String (mandatory)"
                  }
                ]
              }
            ],
            "i18n": [
              {
                "lang": "String (mandatory)",
                "description": "String (mandatory)"
              }
            ]
          }
        ],
        "moduleFormConfigs": [
          {
            "moduleCode": "String (mandatory)",
            "formCode": "String (mandatory)",
            "formGroupCode": "String (mandatory)",
            "processStatus": "String (mandatory exactly one between processStatus and processStatusList)",
            "processStatusList": "String[] (mandatory exactly one between processStatus and processStatusList)",
            "sortOrder": "Integer (mandatory)",
            "flReadOnly": "1|0 (mandatory)",
            "compileStatusIdentifier": "String",
            "contextFunction": "String",
            "requiredProfiles": "String[] | undefined",
            "params": {
              "name": "String (mandatory)",
              "surname": "String (mandatory)"
            }
          }
        ]
      },
      "moduleProfiles": [
        {
          "prfCode": "String (mandatory)",
          "i18n": [
            {
              "lang": "String (mandatory)",
              "description": "Srting (mandatory)"
            }
          ],
          "labelExposed": "Boolean (optional, default FALSE)"
        }
      ],
      "modulePrints": [
        {
          "printCode": "String (mandatory)",
          "processStatus": "String (mandatory exactly one between processStatus and processStatusList)",
          "processStatusList": "String[] (mandatory exactly one between processStatus and processStatusList)",
          "sortOrder": "Integer (mandatory)",
          "contextFunction": "String",
          "i18n": [
            {
              "lang": "String (mandatory)",
              "description": "String (mandatory)"
            }
          ],
          "params": {
            // any object
          },
          "requiredProfiles": "String[] (mandatory)",
          "flAvailableToUser": "Integer"
        }
      ],
      "moduleCalculations": [
        {
          "calculationCode": "String (mandatory)",
          "processStatus": "String (mandatory exactly one between processStatus and processStatusList)",
          "processStatusList": "String[] (mandatory exactly one between processStatus and processStatusList)",
          "sortOrder": "Integer (mandatory)",
          "contextFunction": "String",
          "i18n": [
            {
              "lang": "String (mandatory)",
              "description": "String (mandatory)"
            }
          ],
          "params": {
            // any object
          },
          "requiredProfiles": "String[] (mandatory)",
        }
      ],
      "flAmendModule": Boolean,
      "flChildModule": Boolean
    }
  ]
}
```

The sectors JSON file(s) must have the following structure:

```json
{
  "sectors": [
    {
      "sectorCode": "String (mandatory)",
      "i18n": [
        {
          "lang": "String (mandatory)",
          "description": "String (mandatory)"
        }
      ]
    }
  ]
}
```

## Environment variables

- ACTIVATE_JWT_AUTH: BOOLEAN If TRUE, activate the JWT Filter, which verify the jwt token in the header Authorization, with schema "JWT". Example:
  Authorization: "JWT >token<". if FALSE, a Dev Filter is activated, which does not verify any Authorization header and inject an User with username: "ADMIN"
  and tenant: "tenant"
- SSO2_URL: STRING the url from which the application downloads the certificates to verify the JWT token signature
- DATABASE_TYPE: STRING
  "oracle" or "postgresql", defines which database the application should connect
- DATABASE_DRIVER: STRING the database driver in form of full defined class name
- JDBC_URL: STRING jdbc url for connecting to database
- JDBC_USER: STRING user for connecting to database
- JDBC_PASSWORD: STRING password for database
- JDBC_VALIDATION_QUERY: STRING a validation query for certify that connection is working (required by JDBI)

## Additional optional databases
The module can connect to additional databases to be used from the application workflows; in order to use this facility you have to set the `additionalDatabases` configuration parameter to a comma separated list of identifiers and then add the following environment variables for each identifier:
- JDBC_DRIVER_`identifier`: STRING the database driver in form of full defined class name
- JDBC_URL_`identifier`: STRING jdbc url for connecting to database
- JDBC_USER_`identifier`: STRING user for connecting to database
- JDBC_PASSWORD_`identifier`: STRING password for database
- JDBC_VALIDATION_QUERY_`identifier`: STRING a validation query for certify that connection is working (required by JDBI)

## SSO context|function
The allowed SSO context|function are:
- APPLICATIONS|USER:
  - it enables the user to applications

## Events on RabbitMQ

An event is emitted on rabbitmq, when an application transitions between workflow statuses, with the following settings:
* exchange: applications-exchange
* topic: transition.`sector code`.`application module code`.`transition code`
* payload:
  ```json
  {
    "tenant": "the tenant",
    "applicationId": 123,
    "sectorCode": "sector code",
    "moduleCode": "module code",
    "currentStatus": "the current application status",
    "transitionCode": "the executed transition code",
    "userId": "the user that performed the transition"
  }
  ```

If the `transition code` is not defined for the current transition, then the constant `NONE` is used.

