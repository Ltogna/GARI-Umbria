package com.abacogroup.agri.applications.core.services.workflow.sdkimpl;

import com.abacogroup.agri.applications.core.exceptions.NoTransitionFoundRuntimeException;
import com.abacogroup.agri.applications.core.model.ProgressTypeEnum;
import com.abacogroup.agri.applications.core.model.dto.publics.ProgressApplicationDTO;
import com.abacogroup.agri.applications.core.services.ProgressService;
import com.abacogroup.applicationworkflowsdk.model.exception.AmendException;
import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.workflow.sdk.beans.ProcessData;
import com.abacogroup.workflow.sdk.beans.testsupport.ProcessDataTestSupport;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class ApplicationAmendWaiveImplTest {
    @Mock
    ProgressService progressService;

    @InjectMocks
    ApplicationAmendWaiveImpl applicationAmend;

    private static final String TENANT = "ADMIN";
    private static final Long APPLICATION_ID = 5L;
    private static final String USERNAME = "Username";
    private static final User USER = new User(USERNAME, TENANT);
    private static final String TAG_NAME = "Tag Name";
    private static final String SCOPE = "Scope";

    @Test
    void amendApplication_ok() {
        try {
            ProcessData processData = new ProcessDataTestSupport();

            when(progressService.lastTransitionHasError(TENANT, APPLICATION_ID, USER))
                    .thenReturn(false);

            applicationAmend.amendApplication(TENANT, APPLICATION_ID, USER, TAG_NAME, SCOPE, processData);

            verify(progressService, times(1))
                    .progress(TENANT, APPLICATION_ID, TAG_NAME, USER, SCOPE, ProgressApplicationDTO.builder().build(), ProgressTypeEnum.SYNC, processData);
        } catch (Exception e) {
            fail(e);
        }
    }

    @Test
    void amendApplication_transitionError_ko() {
        try {
            when(progressService.lastTransitionHasError(TENANT, APPLICATION_ID, USER))
                    .thenReturn(true);

            assertThrows(AmendException.class, () ->
                    applicationAmend.amendApplication(TENANT, APPLICATION_ID, USER, TAG_NAME, SCOPE, new ProcessDataTestSupport()));
        } catch (Exception e) {
            fail(e);
        }
    }

    @Test
    void amendApplication_ko() {
        try {
            doThrow(NoTransitionFoundRuntimeException.class).when(progressService)
                    .progress(TENANT, APPLICATION_ID, TAG_NAME, USER, SCOPE, new ProgressApplicationDTO(), ProgressTypeEnum.SYNC);

            assertThrows(AmendException.class, () ->
                    applicationAmend.amendApplication(TENANT, APPLICATION_ID, USER, TAG_NAME, SCOPE, new ProcessDataTestSupport()));
        } catch (Exception e) {
            fail(e);
        }
    }
}