package com.abacogroup.agri.applications.core.services.crud;

import com.abacogroup.agri.applications.core.exceptions.ObjectNotFoundException;
import com.abacogroup.agri.applications.core.mappers.ModuleDetailsMapper;
import com.abacogroup.agri.applications.core.model.dto.ModuleDetailsDTO;
import com.abacogroup.agri.applications.db.dao.ModuleDetailsDAO;
import com.abacogroup.agri.applications.db.ntt.ModuleDetailsNTT;
import org.jdbi.v3.sqlobject.transaction.TransactionalCallback;
import org.jdbi.v3.sqlobject.transaction.TransactionalConsumer;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class ModuleDetailsCrudServiceTest extends AbstractCrudServiceTest {

	private static final String TENANT_ID_1 = "tenant_1";
	private static final Long DETAILS_ID_1 = 1L;
	private static final String USER_ID = "user1";
	private static final Long MODULE_ID_1 = 1L;
	private static final String MODULE_CODE = "Module Code";

	private static final ModuleDetailsDTO moduleDetailsDTO = ModuleDetailsDTO.builder()
			.annuality(1)
			.moduleId(MODULE_ID_1)
			.build();
	private static final ModuleDetailsDTO moduleDetailsDTOResult = ModuleDetailsDTO.builder()
			.annuality(1)
			.moduleId(MODULE_ID_1)
			.pkid(DETAILS_ID_1)
			.build();
	private static final ModuleDetailsNTT moduleDetailsNTT = ModuleDetailsNTT.builder()
			.annuality(1)
			.module_id(MODULE_ID_1)
			.pkid(DETAILS_ID_1)
			.build();

	@Mock
	private ModuleDetailsDAO dao;
	private final ModuleDetailsMapper moduleDetailsMapper = ModuleDetailsMapper.INSTANCE;
	@InjectMocks
	private ModuleDetailsCrudService moduleDetailsCrudService;

	@BeforeEach
	protected void init() {
		moduleDetailsCrudService = new ModuleDetailsCrudService(dao, moduleDetailsMapper);
	}

	@Test
	void test_hasPrimaryKey() {
		assertTrue(moduleDetailsCrudService.hasPrimaryKey());
	}

	@Test
	void test_retrieveCustomKeyByResultSet() {
		assertNull(moduleDetailsCrudService.retrieveCustomKeyByResultSet(moduleDetailsNTT));
	}

	@Test
	void test_findRsByCustomKey() {
		assertEquals(Optional.empty(), moduleDetailsCrudService.findRsByCustomKey(null));
	}

	@SuppressWarnings({"rawtypes", "unchecked"})
	@Test
	void test_insert() {
		try {
			ArgumentCaptor<TransactionalCallback> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(TransactionalCallback.class);

			when(dao.nextSequenceVal()).thenReturn(DETAILS_ID_1);
			when(dao.findById(DETAILS_ID_1)).thenReturn(List.of(moduleDetailsNTT));

			moduleDetailsCrudService.insert(moduleDetailsDTO, USER_ID);

			verify(dao).inTransaction(handleConsumerLambdaCaptor.capture());

			ModuleDetailsDTO result = (ModuleDetailsDTO) handleConsumerLambdaCaptor.getValue().inTransaction(dao);

			assertEquals(moduleDetailsDTOResult, result);

		} catch (Exception e) {
			fail(e.getMessage(), e);
		}
	}

	@SuppressWarnings({"rawtypes", "unchecked"})
	@Test
	void test_update() {
		try {
			ArgumentCaptor<TransactionalCallback> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(TransactionalCallback.class);

			when(dao.getCurrentTimestamp())
					.thenReturn(LocalDateTime.now());
			when(dao.inTransaction(handleConsumerLambdaCaptor.capture()))
					.thenReturn(moduleDetailsDTO);

			moduleDetailsCrudService.update(DETAILS_ID_1, moduleDetailsDTO, USER_ID);

			verify(dao).inTransaction(handleConsumerLambdaCaptor.capture());
			ModuleDetailsDTO result = (ModuleDetailsDTO) handleConsumerLambdaCaptor.getValue().inTransaction(dao);

			assertEquals(moduleDetailsDTO, result);
		} catch (Exception e) {
			fail(e.getMessage(), e);
		}
	}

	@Test
	void test_findById() throws ObjectNotFoundException {
		when(dao.findById(DETAILS_ID_1)).thenReturn(List.of(moduleDetailsNTT));
		assertEquals(moduleDetailsDTOResult, moduleDetailsCrudService.findById(DETAILS_ID_1));
	}

	@Test
	void test_findByModuleId() {
		when(dao.findByModuleId(TENANT_ID_1, MODULE_ID_1)).thenReturn(List.of(moduleDetailsNTT));
		assertEquals(moduleDetailsDTOResult, moduleDetailsCrudService.findByModuleId(TENANT_ID_1, MODULE_ID_1));
	}

	@SuppressWarnings({"rawtypes", "unchecked"})
	@Test
	void test_delete() throws Exception {
		ArgumentCaptor<TransactionalConsumer> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(TransactionalConsumer.class);
		when(dao.getCurrentTimestamp()).thenReturn(LocalDateTime.now());
		moduleDetailsCrudService.delete(DETAILS_ID_1, USER_ID);

		verify(dao).useTransaction(handleConsumerLambdaCaptor.capture());

		handleConsumerLambdaCaptor.getValue().useTransaction(dao);
		verify(dao).logicallyDeleteById(eq(DETAILS_ID_1), eq(USER_ID), any(LocalDateTime.class));
	}

	@Test
	void test_deleteByModuleId() {
		moduleDetailsCrudService.deleteByModuleId(MODULE_ID_1, USER_ID);
		verify(dao).logicallyDeleteByModuleId(eq(MODULE_ID_1), eq(USER_ID), any(LocalDateTime.class));
	}

	@Test
	void findByModuleCode_ok() {
		when(dao.findByModuleCode(TENANT_ID_1, MODULE_CODE))
				.thenReturn(List.of(moduleDetailsNTT));

		ModuleDetailsDTO result = moduleDetailsCrudService.findByModuleCode(TENANT_ID_1, MODULE_CODE);

		assertEquals(moduleDetailsDTOResult, result);
	}
}
