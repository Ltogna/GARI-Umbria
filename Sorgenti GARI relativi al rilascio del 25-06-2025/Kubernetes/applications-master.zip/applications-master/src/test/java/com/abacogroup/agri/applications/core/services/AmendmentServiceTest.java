package com.abacogroup.agri.applications.core.services;

import com.abacogroup.agri.applications.core.exceptions.ApplicationNotFoundRuntimeException;
import com.abacogroup.agri.applications.core.exceptions.ObjectNotFoundException;
import com.abacogroup.agri.applications.core.exceptions.ObjectNotFoundRuntimeException;
import com.abacogroup.agri.applications.core.model.dto.AmendableModuleDTO;
import com.abacogroup.agri.applications.core.model.dto.ApplicationDetailsDTO;
import com.abacogroup.agri.applications.core.model.dto.ModuleDTO;
import com.abacogroup.agri.applications.core.model.dto.ModuleWithDetailDTO;
import com.abacogroup.agri.applications.core.model.dto.publics.ApplicationDTO;
import com.abacogroup.agri.applications.core.model.dto.publics.ApplicationWithDetailsDTO;
import com.abacogroup.agri.applications.core.services.crud.AmendableModuleCrudService;
import com.abacogroup.agri.applications.core.services.crud.ApplicationDetailsCrudService;
import com.abacogroup.agri.applications.core.services.crud.ApplicationsCrudService;
import com.abacogroup.agri.applications.core.services.crud.ModuleCrudService;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import jakarta.ws.rs.core.SecurityContext;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class AmendmentServiceTest {
	@Mock
	ApplicationsCrudService applicationsCrudService;
	@Mock
	ModuleCrudService moduleCrudService;
	@Mock
	AmendableModuleCrudService amendableModuleCrudService;
	@Mock
	ApplicationDetailsCrudService applicationDetailsCrudService;

	@InjectMocks
	AmendmentService amendmentService;

	private static final String TENANT = "ADMIN";
	private static final Long APPLICATION_ID = 5L;
	private static final Long AMENDED_APPLICATION_ID = 20L;
	private static final String PROCESS_STATUS_DELETED = "DELETED";
	private static final String PROCESS_STATUS_PROTOCOLED = "PROTOCOLED";
	private static final String PROCESS_STATUS_COMPLIANT = "COMPLIANT";
	private static final String PROCESS_STATUS_IN_COMPILATION = "IN_COMPILATION";
	private static final Integer FIND_ONLY_AMEND_MODULES = 1;
	private static final Long MODULE_ID = 10L;
	private static final Long AMENDABLE_MODULE_ID = 20L;
	private static final Long SECTOR_ID = 15L;
	private static final Long PKID = 1L;
	private static final String MODULE_CODE = "Module Code";
	private static final String WORKFLOW_CODE = "Workflow Code";
	private static final Integer REFERRED_YEAR = 2023;
	private static final String NEXT_KEY = "Next Key";

	private final ApplicationDetailsDTO applicationDetailsProtocoled = ApplicationDetailsDTO.builder()
			.pkid(PKID)
			.applicationId(APPLICATION_ID)
			.applicationCode(APPLICATION_ID.toString())
			.processStatus(PROCESS_STATUS_PROTOCOLED)
			.build();
	private final ApplicationDetailsDTO applicationDetailsCompliant = ApplicationDetailsDTO.builder()
			.pkid(PKID)
			.applicationId(APPLICATION_ID)
			.applicationCode(APPLICATION_ID.toString())
			.processStatus(PROCESS_STATUS_COMPLIANT)
			.build();
	private final ApplicationDetailsDTO applicationDetailsInCompilation = ApplicationDetailsDTO.builder()
			.pkid(PKID)
			.applicationId(APPLICATION_ID)
			.applicationCode(APPLICATION_ID.toString())
			.processStatus(PROCESS_STATUS_IN_COMPILATION)
			.build();
	private final ModuleDTO module = ModuleDTO.builder()
			.moduleId(MODULE_ID)
			.sectorId(SECTOR_ID)
			.moduleCode(MODULE_CODE)
			.workflowCode(WORKFLOW_CODE)
			.flAmendModule(false)
			.build();
	private final AmendableModuleDTO amendableModule = AmendableModuleDTO.builder()
			.moduleId(MODULE_ID)
			.amendableModuleId(AMENDABLE_MODULE_ID)
			.build();
	private final ModuleWithDetailDTO moduleWithDetail = ModuleWithDetailDTO.builder()
			.moduleId(MODULE_ID)
			.moduleCode(MODULE_CODE)
			.workflowCode(WORKFLOW_CODE)
			.sectorId(SECTOR_ID)
			.annuality(REFERRED_YEAR)
			.build();
	private final ModuleWithDetailDTO moduleWithDetailWithContextFunction = ModuleWithDetailDTO.builder()
			.moduleId(MODULE_ID)
			.moduleCode(MODULE_CODE)
			.workflowCode(WORKFLOW_CODE)
			.sectorId(SECTOR_ID)
			.annuality(REFERRED_YEAR)
			.contextFunction(SecurityContext.BASIC_AUTH)
			.build();
	private final ApplicationWithDetailsDTO applicationWithDetailsInCompilation = ApplicationWithDetailsDTO.builder()
			.applicationId(APPLICATION_ID)
			.applicationCode(APPLICATION_ID.toString())
			.moduleId(MODULE_ID)
			.referredYear(REFERRED_YEAR)
			.processStatus(PROCESS_STATUS_IN_COMPILATION)
			.build();
	private final ApplicationWithDetailsDTO applicationWithDetails = ApplicationWithDetailsDTO.builder()
			.applicationId(APPLICATION_ID)
			.applicationCode(APPLICATION_ID.toString())
			.moduleId(MODULE_ID)
			.referredYear(REFERRED_YEAR)
			.processStatus(PROCESS_STATUS_PROTOCOLED)
			.amendedApplicationId(AMENDED_APPLICATION_ID)
			.build();
	private final ApplicationWithDetailsDTO amendedApplicationWithDetails = ApplicationWithDetailsDTO.builder()
			.applicationId(AMENDED_APPLICATION_ID)
			.applicationCode(AMENDED_APPLICATION_ID.toString())
			.moduleId(MODULE_ID)
			.referredYear(REFERRED_YEAR)
			.processStatus(PROCESS_STATUS_PROTOCOLED)
			.build();
	private final ApplicationWithDetailsDTO applicationWithDetailsDeleted = ApplicationWithDetailsDTO.builder()
			.applicationId(APPLICATION_ID)
			.applicationCode(APPLICATION_ID.toString())
			.moduleId(MODULE_ID)
			.referredYear(REFERRED_YEAR)
			.processStatus(PROCESS_STATUS_DELETED)
			.build();
	private final ApplicationDTO application = ApplicationDTO.builder()
			.applicationId(APPLICATION_ID)
			.referredYear(REFERRED_YEAR)
			.moduleId(MODULE_ID)
			.build();

	@Test
	void checkAmendmentStatus_protocoled_true_ok() {
		try {
			when(moduleCrudService.findByCode(TENANT, MODULE_CODE))
					.thenReturn(Optional.of(module));
			when(amendableModuleCrudService.findByAmendableModuleId(TENANT, MODULE_ID))
					.thenReturn(List.of(amendableModule));
			when(moduleCrudService.findValidAmendModulesWithDetailByModuleId(eq(TENANT), eq(MODULE_ID), eq(FIND_ONLY_AMEND_MODULES), any()))
					.thenReturn(List.of(moduleWithDetail));

			assertTrue(amendmentService.checkAmendmentStatus(TENANT, MODULE_CODE));
		} catch (Exception e) {
			fail(e);
		}
	}

	@Test
	void checkAmendmentStatus_compliant_true_ok() {
		try {
			when(moduleCrudService.findByCode(TENANT, MODULE_CODE))
					.thenReturn(Optional.of(module));
			when(amendableModuleCrudService.findByAmendableModuleId(TENANT, MODULE_ID))
					.thenReturn(List.of(amendableModule));
			when(moduleCrudService.findValidAmendModulesWithDetailByModuleId(eq(TENANT), eq(MODULE_ID), eq(FIND_ONLY_AMEND_MODULES), any()))
					.thenReturn(List.of(moduleWithDetail));

			assertTrue(amendmentService.checkAmendmentStatus(TENANT, MODULE_CODE));
		} catch (Exception e) {
			fail(e);
		}
	}

	@Test
	void checkAmendmentStatus_moduleNotPresent_false_ok() {
		try {
			when(moduleCrudService.findByCode(TENANT, MODULE_CODE))
					.thenReturn(Optional.empty());

			assertFalse(amendmentService.checkAmendmentStatus(TENANT, MODULE_CODE));
		} catch (Exception e) {
			fail(e);
		}
	}

	@Test
	void isAmendModule_true_ok() {
		when(moduleCrudService.findValidAmendModulesWithDetailByModuleId(eq(TENANT), eq(MODULE_ID), eq(FIND_ONLY_AMEND_MODULES), any()))
				.thenReturn(List.of(moduleWithDetail));

		assertTrue(amendmentService.isAmendModule(TENANT, MODULE_ID));
	}

	@Test
	void isAmendModule_false_ok() {
		when(moduleCrudService.findValidAmendModulesWithDetailByModuleId(eq(TENANT), eq(MODULE_ID), eq(FIND_ONLY_AMEND_MODULES), any()))
				.thenReturn(List.of());

		assertFalse(amendmentService.isAmendModule(TENANT, MODULE_ID));
	}

	@Test
	void isApplicationAmendable_true_ok() {
		try {
			when(applicationsCrudService.findWithDetailsByApplicationId(TENANT, APPLICATION_ID))
					.thenReturn(applicationWithDetailsInCompilation);

			assertTrue(amendmentService.isApplicationAmendable(TENANT, APPLICATION_ID));
		} catch (Exception e) {
			fail(e);
		}
	}

	@Test
	void isApplicationAmendable_notPresent_false_ok() {
		try {
			when(applicationsCrudService.findWithDetailsByApplicationId(TENANT, APPLICATION_ID))
					.thenReturn(null);

			assertFalse(amendmentService.isApplicationAmendable(TENANT, APPLICATION_ID));
		} catch (Exception e) {
			fail(e);
		}
	}

	@Test
	void isApplicationAmendable_deleted_false_ok() {
		try {
			when(applicationsCrudService.findWithDetailsByApplicationId(TENANT, APPLICATION_ID))
					.thenReturn(applicationWithDetailsDeleted);

			assertFalse(amendmentService.isApplicationAmendable(TENANT, APPLICATION_ID));
		} catch (Exception e) {
			fail(e);
		}
	}

	@Test
	void isApplicationAmendable_ApplicationNotFoundRuntimeException_false_ok() {
		try {
			when(applicationsCrudService.findWithDetailsByApplicationId(TENANT, APPLICATION_ID))
					.thenThrow(ApplicationNotFoundRuntimeException.class);

			assertFalse(amendmentService.isApplicationAmendable(TENANT, APPLICATION_ID));
		} catch (Exception e) {
			fail(e);
		}
	}

	@Test
	void getAmendmentModules_ok() {
		SecurityContext securityContext = mock(SecurityContext.class);

		when(applicationsCrudService.findById(APPLICATION_ID))
				.thenReturn(Optional.of(application));
		when(amendableModuleCrudService.findByAmendableModuleId(TENANT, MODULE_ID))
				.thenReturn(List.of(amendableModule));
		when(moduleCrudService.findModulesWithDetailByModuleIds(eq(TENANT), eq(List.of(MODULE_ID)), eq(FIND_ONLY_AMEND_MODULES), any()))
				.thenReturn(List.of(moduleWithDetail, moduleWithDetailWithContextFunction));
		when(securityContext.isUserInRole(SecurityContext.BASIC_AUTH))
				.thenReturn(true);

		InfiniteListResults<ModuleWithDetailDTO> result =
				amendmentService.getAmendmentModules(TENANT, APPLICATION_ID, NEXT_KEY, securityContext);

		assertEquals(List.of(moduleWithDetail, moduleWithDetailWithContextFunction), result.getRecords());
	}

	@Test
	void getAmendmentModules_ko() {
		SecurityContext securityContext = mock(SecurityContext.class);

		when(applicationsCrudService.findById(APPLICATION_ID))
				.thenReturn(Optional.empty());

		assertThrows(ApplicationNotFoundRuntimeException.class, () ->
				amendmentService.getAmendmentModules(TENANT, APPLICATION_ID, NEXT_KEY, securityContext));
	}

	@Test
	void getOriginalAmendedApplicationId_ok() {
		when(applicationsCrudService.findWithDetailsByApplicationId(TENANT, AMENDED_APPLICATION_ID))
				.thenReturn(applicationWithDetails, amendedApplicationWithDetails);

		Long result = amendmentService.getOriginalAmendedApplicationId(applicationWithDetails, TENANT);

		assertEquals(AMENDED_APPLICATION_ID, result);
	}

	@Test
	void getOriginalAmendedApplicationId_null_ok() {
		assertNull(amendmentService.getOriginalAmendedApplicationId(amendedApplicationWithDetails, TENANT));
	}
}
