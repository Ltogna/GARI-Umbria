package com.abacogroup.agri.applications.resources;

import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

import lombok.extern.slf4j.Slf4j;


@Slf4j
@ExtendWith(MockitoExtension.class)
class ApplicationsPublicResourcesTest {

	@Test
	void simpleTest() {
		// Simple test for sonar issue
		assertTrue(true);
	}
}
