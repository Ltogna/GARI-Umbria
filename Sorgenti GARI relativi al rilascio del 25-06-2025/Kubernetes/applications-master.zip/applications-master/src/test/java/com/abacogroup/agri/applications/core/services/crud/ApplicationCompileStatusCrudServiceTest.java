package com.abacogroup.agri.applications.core.services.crud;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.fail;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.Mockito.lenient;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.List;
import java.util.Optional;

import org.jdbi.v3.sqlobject.transaction.TransactionalCallback;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;
import org.slf4j.MDC;

import com.abacogroup.agri.applications.core.exceptions.ObjectNotFoundException;
import com.abacogroup.agri.applications.core.mappers.ApplicationCompileStatusMapper;
import com.abacogroup.agri.applications.db.dao.ApplicationCompileStatusDAO;
import com.abacogroup.agri.applications.db.ntt.ApplicationCompileStatusNTT;
import com.abacogroup.applicationworkflowsdk.model.io.output.ApplicationCompileStatusDTO;
import com.abacogroup.jaxrsutils.filter.MDCPreFilter;
import com.abacogroup.jdbi.paging.impl.InfiniteListResultsImpl;

@ExtendWith(MockitoExtension.class)
class ApplicationCompileStatusCrudServiceTest extends AbstractCrudServiceTest {

	private static final Long APPLICATION_ID_1 = 48L;
	private static final String APPLICATION_CODE_1 = "48";
	private static final String COMPILE_STATUS_IDENTIFIER_1 = "60L";
	private static final String STATUS_1 = "compiling";
	private static final Long APP_COMPILE_STATUS_PKID_1 = 24L;
	private static final LocalDateTime DT_INSERT = LocalDateTime.now();
	private static final LocalDateTime DT_DELETE = LocalDateTime.ofInstant(Instant.ofEpochSecond(253402300799L), ZoneOffset.UTC);

	private static final String USERNAME_ID_1 = "user1";

	private static final ApplicationCompileStatusDTO applicationCompileStatusInDtoMock = ApplicationCompileStatusDTO.builder()
			.applicationId(APPLICATION_ID_1)
			.compileStatusIdentifier(COMPILE_STATUS_IDENTIFIER_1)
			.status(STATUS_1)
			.build();
	private static final ApplicationCompileStatusDTO applicationCompileStatusDtoMock = ApplicationCompileStatusDTO.builder()
			.pkid(APP_COMPILE_STATUS_PKID_1)
			.applicationId(APPLICATION_ID_1)
			.compileStatusIdentifier(COMPILE_STATUS_IDENTIFIER_1)
			.status(STATUS_1)
			.build();
	private static final ApplicationCompileStatusNTT applicationCompileStatusNttMock = ApplicationCompileStatusNTT.builder()
			.pkid(APP_COMPILE_STATUS_PKID_1)
			.application_id(APPLICATION_ID_1)
			.compile_status_identifier(COMPILE_STATUS_IDENTIFIER_1)
			.status(STATUS_1)
			.dt_insert(DT_INSERT)
			.dt_delete(DT_DELETE)
			.user_id_insert(USERNAME_ID_1)
			.build();
	private static final ApplicationCompileStatusNTT applicationCompileStatusNttDeletedMock = ApplicationCompileStatusNTT.builder()
			.pkid(APP_COMPILE_STATUS_PKID_1)
			.application_id(APPLICATION_ID_1)
			.compile_status_identifier(COMPILE_STATUS_IDENTIFIER_1)
			.status(STATUS_1)
			.dt_insert(DT_INSERT)
			.dt_delete(DT_INSERT)
			.user_id_insert(USERNAME_ID_1)
			.user_id_delete(USERNAME_ID_1)
			.build();
	private static final String TENANT_ID_1 = "tenant1";

	@Mock
	private ApplicationCompileStatusDAO dao;
	@Spy
	private ApplicationCompileStatusMapper applicationCompileStatusMapper = ApplicationCompileStatusMapper.INSTANCE;
	@InjectMocks
	private ApplicationCompileStatusCrudService applicationCompileStatusCrudService;

	@BeforeEach
	void beforeEach() {
		lenient().when(dao.getCurrentTimestamp()).thenAnswer($ -> LocalDateTime.now());
	}

	@Test
	void test_hasPrimaryKey() {
		assertTrue(applicationCompileStatusCrudService.hasPrimaryKey());
	}

	@Test
	void test_findRsByCustomKey() {
		assertEquals(Optional.empty(), applicationCompileStatusCrudService.findRsByCustomKey(null));
	}

	@Test
	void test_retrieveCustomKeyByResultSet() {
		assertNull(applicationCompileStatusCrudService.retrieveCustomKeyByResultSet(null));
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Test
	void test_insert() {
		try {
			ArgumentCaptor<TransactionalCallback> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(TransactionalCallback.class);

			when(dao.nextSequenceVal()).thenReturn(APPLICATION_ID_1);
			when(dao.findById(APPLICATION_ID_1)).thenReturn(List.of(applicationCompileStatusNttMock));

			applicationCompileStatusCrudService.insert(applicationCompileStatusInDtoMock, USERNAME_ID_1);

			verify(dao).inTransaction(handleConsumerLambdaCaptor.capture());

			ApplicationCompileStatusDTO result = (ApplicationCompileStatusDTO) handleConsumerLambdaCaptor.getValue().inTransaction(dao);

			assertEquals(applicationCompileStatusDtoMock, result);

		} catch (Exception e) {
			fail(e.getMessage(), e);
		}
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Test
	void test_update() {
		try {
			ArgumentCaptor<TransactionalCallback> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(TransactionalCallback.class);
			when(dao.nextSequenceVal()).thenReturn(APP_COMPILE_STATUS_PKID_1);
			when(dao.getCurrentTimestamp()).thenReturn(LocalDateTime.now());
			when(dao.findById(APP_COMPILE_STATUS_PKID_1)).thenReturn(List.of(applicationCompileStatusNttMock));
			when(applicationCompileStatusMapper.dtoToEntity(applicationCompileStatusInDtoMock)).thenReturn(applicationCompileStatusNttMock);
			when(applicationCompileStatusMapper.entityToDto(applicationCompileStatusNttMock)).thenReturn(applicationCompileStatusDtoMock);
			applicationCompileStatusCrudService.update(APP_COMPILE_STATUS_PKID_1, applicationCompileStatusInDtoMock, USERNAME_ID_1);

			verify(dao).inTransaction(handleConsumerLambdaCaptor.capture());

			handleConsumerLambdaCaptor.getValue().inTransaction(dao);
			verify(dao, times(2)).inTransaction(handleConsumerLambdaCaptor.capture());

			ApplicationCompileStatusDTO result = (ApplicationCompileStatusDTO) handleConsumerLambdaCaptor.getValue().inTransaction(dao);

			assertEquals(applicationCompileStatusDtoMock, result);
		} catch (Exception e) {
			fail(e.getMessage(), e);
		}
	}

	@Test
	void test_delete() {
		try {
			applicationCompileStatusCrudService.delete(APP_COMPILE_STATUS_PKID_1, USERNAME_ID_1);

		} catch (Exception e) {
			fail(e.getMessage(), e);
		}
	}

	@Test
	void test_findById() throws ObjectNotFoundException {
		when(dao.findById(APP_COMPILE_STATUS_PKID_1)).thenReturn(List.of(applicationCompileStatusNttMock));
		assertEquals(applicationCompileStatusDtoMock, applicationCompileStatusCrudService.findById(APP_COMPILE_STATUS_PKID_1));
	}

	@Test
	void test_find() {
		when(dao.findByApplicationId(TENANT_ID_1, APP_COMPILE_STATUS_PKID_1)).thenReturn(List.of(applicationCompileStatusNttMock));

		assertEquals(List.of(applicationCompileStatusDtoMock), applicationCompileStatusCrudService.find(TENANT_ID_1, APP_COMPILE_STATUS_PKID_1));

		MDC.remove(MDCPreFilter.LOCALE);
	}

	@Test
	void test_find_infiniteList_withApplicationCode() {
		when(dao.infinite(any(), any(), anyInt()))
				.thenReturn(new InfiniteListResultsImpl<>(List.of(applicationCompileStatusNttMock), null));

		List<ApplicationCompileStatusDTO> result =
				applicationCompileStatusCrudService.find(TENANT_ID_1, APPLICATION_CODE_1, null).getRecords();

		assertEquals(List.of(applicationCompileStatusDtoMock), result);

	}

	@Test
	void test_find_infiniteList_withApplicationId() {
		when(dao.infinite(any(), any(), anyInt()))
				.thenReturn(new InfiniteListResultsImpl<>(List.of(applicationCompileStatusNttMock), null));

		List<ApplicationCompileStatusDTO> result =
				applicationCompileStatusCrudService.find(TENANT_ID_1, APPLICATION_ID_1, null).getRecords();

		assertEquals(List.of(applicationCompileStatusDtoMock), result);

	}

	@Test
	void test_findById_withTenant() {
		try {
			when(dao.findById(APP_COMPILE_STATUS_PKID_1))
					.thenReturn(List.of(applicationCompileStatusNttMock));

			ApplicationCompileStatusDTO result = applicationCompileStatusCrudService.findById(TENANT_ID_1, APP_COMPILE_STATUS_PKID_1);

			assertEquals(applicationCompileStatusDtoMock, result);
		} catch (Exception e) {
			fail(e);
		}
	}

	@Test
	void test_findByCompileStatusIdentifier() {
		try {
			when(dao.findByApplicationIdAndCompileStatus(TENANT_ID_1, APPLICATION_ID_1, COMPILE_STATUS_IDENTIFIER_1))
					.thenReturn(List.of(applicationCompileStatusNttMock));
			when(applicationCompileStatusMapper.entityToDto(applicationCompileStatusNttMock))
					.thenReturn(applicationCompileStatusDtoMock);

			ApplicationCompileStatusDTO result = applicationCompileStatusCrudService.findByCompileStatusIdentifier(TENANT_ID_1, APPLICATION_ID_1,
					COMPILE_STATUS_IDENTIFIER_1);

			assertEquals(applicationCompileStatusDtoMock, result);
		} catch (Exception e) {
			fail(e);
		}

	}

	@Test
	void test_findByTenantAndPrimaryKey() {
		try {
			when(dao.findByTenantAndId(TENANT_ID_1, APP_COMPILE_STATUS_PKID_1))
					.thenReturn(List.of(applicationCompileStatusNttMock));
			when(applicationCompileStatusMapper.entityToDto(applicationCompileStatusNttMock))
					.thenReturn(applicationCompileStatusDtoMock);

			ApplicationCompileStatusDTO result = applicationCompileStatusCrudService.findByTenantAndPrimaryKey(TENANT_ID_1, APP_COMPILE_STATUS_PKID_1);

			assertEquals(applicationCompileStatusDtoMock, result);
		} catch (Exception e) {
			fail(e);
		}

	}

	@Test
	void test_findByCompileStatusIdentifier_ko() {
		try {
			when(dao.findByApplicationIdAndCompileStatus(TENANT_ID_1, APPLICATION_ID_1, COMPILE_STATUS_IDENTIFIER_1))
					.thenReturn(List.of(applicationCompileStatusNttDeletedMock));

			assertThrows(ObjectNotFoundException.class,
					() -> applicationCompileStatusCrudService.findByCompileStatusIdentifier(TENANT_ID_1, APPLICATION_ID_1, COMPILE_STATUS_IDENTIFIER_1));
		} catch (Exception e) {
			fail(e);
		}

	}

	@Test
	void test_findByTenantAndPrimaryKey_ko() {
		try {
			when(dao.findByTenantAndId(TENANT_ID_1, APP_COMPILE_STATUS_PKID_1))
					.thenReturn(List.of(applicationCompileStatusNttDeletedMock));

			assertThrows(ObjectNotFoundException.class,
					() -> applicationCompileStatusCrudService.findByTenantAndPrimaryKey(TENANT_ID_1, APP_COMPILE_STATUS_PKID_1));
		} catch (Exception e) {
			fail(e);
		}

	}

}
