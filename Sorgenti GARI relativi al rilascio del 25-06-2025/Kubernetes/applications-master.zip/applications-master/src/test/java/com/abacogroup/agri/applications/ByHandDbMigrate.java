package com.abacogroup.agri.applications;

public class ByHandDbMigrate {

	public static void main(String[] args) throws Exception {
		ApplicationsModuleApplication.main(new String[] {
				"db", "migrate", "config-dev.yml"
		});
	}
}
