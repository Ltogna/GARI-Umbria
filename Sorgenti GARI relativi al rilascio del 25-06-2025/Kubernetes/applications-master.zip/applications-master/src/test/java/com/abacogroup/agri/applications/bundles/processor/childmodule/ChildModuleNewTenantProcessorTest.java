package com.abacogroup.agri.applications.bundles.processor.childmodule;

import com.abacogroup.agri.applications.core.model.dto.ChildModuleDTO;
import com.abacogroup.agri.applications.core.model.dto.ModuleDTO;
import com.abacogroup.agri.applications.core.model.dto.SectorDTO;
import com.abacogroup.agri.applications.core.services.crud.ChildModuleCrudService;
import com.abacogroup.agri.applications.core.services.crud.ModuleCrudService;
import com.abacogroup.agri.applications.core.services.crud.SectorsCrudService;
import com.abacogroup.bundles.listener.tenant.TenantMessage;
import lombok.extern.slf4j.Slf4j;
import org.jdbi.v3.core.Handle;
import org.jdbi.v3.core.HandleConsumer;
import org.jdbi.v3.core.Jdbi;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.fail;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@Slf4j
@ExtendWith(MockitoExtension.class)
class ChildModuleNewTenantProcessorTest {
    @Mock
    private Jdbi jdbi;
    @Mock
    private Handle handle;
    @Mock
    private ChildModuleCrudService childModuleCrudService;
    @Mock
    private ModuleCrudService moduleCrudService;
    @Mock
    private SectorsCrudService sectorsCrudService;
    @Mock
    private ChildrenModulesBundleWorker childrenModulesBundleWorker;

    @InjectMocks
    private ChildModuleNewTenantProcessor childModuleNewTenantProcessor;

    private static final String TEMPLATE_TENANT_ID = "*";
    private static final Long MODULE_ID = 1L;
    private static final Long PARENT_MODULE_ID = 2L;
    private static final String MODULE_CODE = "module_code";
    private static final Long SECTOR_ID = 1L;
    private static final Long SECTOR_ID_2 = 2L;
    private static final String PARENT_MODULE_CODE = "PARENT_MODULE_CODE";
    private static final String WORKFLOW_CODE = "workflow_code";

    private final ChildModuleDTO childModuleDTO = ChildModuleDTO.builder()
            .moduleId(MODULE_ID)
            .parentModuleId(PARENT_MODULE_ID)
            .build();

    private final ModuleDTO moduleDTOInMock = ModuleDTO.builder()
            .moduleId(MODULE_ID)
            .sectorId(SECTOR_ID)
            .moduleCode(MODULE_CODE)
            .workflowCode(WORKFLOW_CODE)
            .flAmendModule(false)
            .build();

    private final ModuleDTO childModuleDTOInMock = ModuleDTO.builder()
            .moduleId(PARENT_MODULE_ID)
            .sectorId(SECTOR_ID_2)
            .moduleCode(PARENT_MODULE_CODE)
            .workflowCode(WORKFLOW_CODE)
            .flAmendModule(true)
            .build();


    @SuppressWarnings({"rawtypes", "unchecked"})
    @Test
    void test_onMessage() {
        try {
            ArgumentCaptor<HandleConsumer> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(HandleConsumer.class);

            TenantMessage message = new TenantMessage();
            message.setTenantId(TEMPLATE_TENANT_ID);

            when(childrenModulesBundleWorker.exposeChildModuleCrudService()).thenReturn(childModuleCrudService);
            when(childrenModulesBundleWorker.exposeModuleCrudService()).thenReturn(moduleCrudService);
            when(childModuleCrudService.findAllByTenant(TEMPLATE_TENANT_ID)).thenReturn(List.of(childModuleDTO));
            when(childrenModulesBundleWorker.exposeSectorCrudService()).thenReturn(sectorsCrudService);
            when(sectorsCrudService.findById(any(), any())).thenReturn(SectorDTO.builder().build());
            when(moduleCrudService.findById(PARENT_MODULE_ID)).thenReturn(Optional.of(childModuleDTOInMock));
            when(moduleCrudService.findById(MODULE_ID)).thenReturn(Optional.of(moduleDTOInMock));

            childModuleNewTenantProcessor.onMessage(message);

            verify(jdbi).useTransaction(handleConsumerLambdaCaptor.capture());

            handleConsumerLambdaCaptor.getValue().useHandle(handle);
        } catch (Exception e) {
            fail(e.getMessage(), e);
        }
    }

}
