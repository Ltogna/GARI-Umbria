package com.abacogroup.agri.applications.bundles.processor.env;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.fail;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.verify;

import java.io.File;
import java.nio.file.Path;
import java.util.List;

import org.jdbi.v3.core.Jdbi;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.abacogroup.agri.applications.bundles.model.env.BundleApplicationEnvInDTO;
import com.abacogroup.agri.applications.bundles.model.env.BundleApplicationEnvMessage;
import com.abacogroup.bundles.listener.configdata.ConfigDataMessage;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@ExtendWith(MockitoExtension.class)
class BundleApplicationEnvProcessorTest {

	protected static final String TEMPLATE_TENANT_ID = "*";
	protected static final String DOMAIN_NAME = "application-env";
	private static final String ENV_KEY = "env_key";
	private static final String VALUE = "value";
	private static final Integer FL_CLIENT = 1;

	private static final Path PATH = new File("test.json").toPath();
	private final BundleApplicationEnvInDTO bundleApplicationEnvInDTO = BundleApplicationEnvInDTO.builder()
			.key(ENV_KEY)
			.value(VALUE)
			.flClient(FL_CLIENT)
			.build();

	private final BundleApplicationEnvMessage bundleApplicationEnvMessage = BundleApplicationEnvMessage.builder()
			.bundleApplicationEnvInDTOList(List.of(bundleApplicationEnvInDTO))
			.build();

	private final ConfigDataMessage configDataMessage = new ConfigDataMessage();
	@Mock
	private ApplicationEnvBundleWorker applicationEnvBundleWorker;
	@Mock
	private ObjectMapper objectMapper;
	@Mock
	private Jdbi jdbi;
	@InjectMocks
	private BundleApplicationEnvProcessor bundleApplicationEnvProcessor;

	@BeforeEach
	void init() {
		configDataMessage.setTenantId(TEMPLATE_TENANT_ID);
		bundleApplicationEnvProcessor = new BundleApplicationEnvProcessor(objectMapper, applicationEnvBundleWorker, jdbi);
	}

	@Test
	void test_getDomainName() {
		assertEquals(DOMAIN_NAME, bundleApplicationEnvProcessor.getDomainName());
	}

	@Test
	void test_getTypeReference() {
		assertEquals(new TypeReference<BundleApplicationEnvMessage>() {
		}.getType(), bundleApplicationEnvProcessor.getTypeReference().getType());
	}

	@Test
	void onMessageInTransaction() {
		try {
			configDataMessage.setConfigFiles(List.of(PATH));
			bundleApplicationEnvProcessor.onMessageInTransaction(configDataMessage);
			verify(objectMapper).readValue(eq(PATH.toFile()), any(TypeReference.class));
		} catch (Exception e) {
			fail(e.getMessage(), e);
		}
	}

	@Test
	void test_doInsertOrUpdate() {
		bundleApplicationEnvProcessor.doInsertOrUpdate(TEMPLATE_TENANT_ID, bundleApplicationEnvMessage);
		verify(applicationEnvBundleWorker).upsertApplicationEnvironments(TEMPLATE_TENANT_ID, bundleApplicationEnvMessage);
	}

	// TODO when delete method is implemented
	@Test
	void test_delete() {
		bundleApplicationEnvProcessor.delete(TEMPLATE_TENANT_ID, bundleApplicationEnvMessage);

		assertTrue(true);
	}
}
