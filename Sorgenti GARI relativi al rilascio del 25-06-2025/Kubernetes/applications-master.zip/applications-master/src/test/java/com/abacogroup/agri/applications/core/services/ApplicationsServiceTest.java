package com.abacogroup.agri.applications.core.services;

import com.abacogroup.agri.applications.core.caller.CreateCustomApplicationIdCaller;
import com.abacogroup.agri.applications.core.exceptions.*;
import com.abacogroup.agri.applications.core.mappers.DetailLogMapper;
import com.abacogroup.agri.applications.core.model.*;
import com.abacogroup.agri.applications.core.model.dto.PartyDTO;
import com.abacogroup.agri.applications.core.model.dto.*;
import com.abacogroup.agri.applications.core.model.dto.publics.*;
import com.abacogroup.agri.applications.core.services.calculation.CalculationService;
import com.abacogroup.agri.applications.core.services.crud.*;
import com.abacogroup.agri.applications.core.services.embededqueue.CreateProcessQueue;
import com.abacogroup.agri.applications.core.services.print.PrintService;
import com.abacogroup.agri.applications.core.services.workflow.ApplicationsWorkflowService;
import com.abacogroup.applicationworkflowsdk.model.ApplicationsWorkflowParams;
import com.abacogroup.applicationworkflowsdk.model.CreateProcessType;
import com.abacogroup.applicationworkflowsdk.model.DetailedSdkTransitionLog;
import com.abacogroup.applicationworkflowsdk.model.io.output.*;
import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.jaxrsutils.filter.MDCPreFilter;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.jdbi.paging.impl.InfiniteListResultsImpl;
import com.abacogroup.workflow.sdk.auth.AuthContext;
import com.abacogroup.workflow.sdk.beans.testsupport.AuthContextTestSupport;
import com.abacogroup.workflow.server.db.ntt.WorLogTransitionWithDetailsEntity;
import com.abacogroup.workflow.server.model.DetailedTransitionLog;
import com.abacogroup.workflow.server.model.NodeType;
import com.abacogroup.workflow.server.model.Transition;
import com.abacogroup.workflow.server.model.WorkflowNode;
import com.abacogroup.workflow.server.services.exceptions.ProcessNotFoundException;
import com.abacogroup.workflow.server.services.exceptions.WorkflowNotFoundException;
import com.fasterxml.jackson.core.JsonToken;
import io.dropwizard.jackson.Jackson;
import jakarta.ws.rs.core.SecurityContext;
import lombok.extern.slf4j.Slf4j;
import org.jdbi.v3.core.Handle;
import org.jdbi.v3.core.HandleCallback;
import org.jdbi.v3.core.HandleConsumer;
import org.jdbi.v3.core.Jdbi;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.slf4j.MDC;

import java.time.*;
import java.util.*;

import static com.abacogroup.agri.applications.core.services.AnomaliesService.WAIVED_APPLICATION_ERROR_CODE;
import static com.abacogroup.agri.applications.core.services.AnomaliesService.WAIVED_APPLICATION_ERROR_MSG;
import static com.abacogroup.applicationworkflowsdk.model.Constants.WORKFLOW_CLOSED_KEY;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@Slf4j
@ExtendWith(MockitoExtension.class)
class ApplicationsServiceTest {

	public static final String STATUS_2 = "status2";
	private static final Long FORM_ID_1 = 33L;
	private static final String FORM_CODE = "Form Code";
	private static final String FORM_NAME = "Form Name";
	private static final Long FORM_GROUP_ID_1 = 45L;
	private static final Long MODULE_FORM_CONFIG_ID_1 = 65L;
	private static final Long MODULE_PRINT_CONFIG_ID_1 = 10L;
	private static final String MODULE_PRINT_CONFIG_1_PARAMETER_NAME_1 = "print param name";
	private static final String MODULE_PRINT_CONFIG_1_PARAMETER_VALUE_1 = "123456";
	public static final String STATUS_1 = "status1";
	@Mock
	private Jdbi jdbi;
	@Mock
	private ApplicationsWorkflowService applicationsWorkflowService;
	@Mock
	private PartyService partyService;
	@Mock
	private ModuleCrudService moduleCrudService;
	@Mock
	private ModuleDetailsCrudService moduleDetailsCrudService;
	@Mock
	private ApplicationDetailsCrudService applicationDetailsCrudService;
	@Mock
	private ApplicationsCrudService applicationsCrudService;
	@Mock
	private ModuleFormConfigsCrudService moduleFormConfigsCrudService;
	@Mock
	private ApplicationCompileStatusCrudService applicationCompileStatusCrudService;
	@Mock
	private ApplicationProfilesCrudService applicationProfilesCrudService;
	@Mock
	private ModuleProfilesCrudService moduleProfilesCrudService;
	@Mock
	private AnomaliesService anomaliesService;
	@Mock
	private CheckPartyService checkPartyService;
	@Mock
	private CreateProcessQueue createProcessQueue;
	@Mock
	private ModulePrintConfigsCrudService modulePrintConfigsCrudService;
	@Mock
	private ModulePrintConfigParamCrudService modulePrintConfigParamCrudService;
	@Mock
	private ApplicationGeneratedPrintCrudService applicationGeneratedPrintCrudService;
	@Mock
	private ApplicationGeneratedCalculationCrudService applicationGeneratedCalculationCrudService;
	@Mock
	private SectorsCrudService sectorsCrudService;
	@Mock
	private FormConfigService formConfigService;
	@Mock
	private ApplicationProtocolsCrudService applicationProtocolsCrudService;
	@Mock
	private AmendmentService amendmentService;
	@Mock
	private ProgressService progressService;
	@Mock
	private PrintService printService;
	@Mock
	private HistoryService historyService;
	@Mock
	private CalculationService calculationService;
	@Mock
	private Handle handle;
	@Mock
	private SecurityContext sc;
	@Mock
	private CustomApplicationIdGenerationConfig customApplicationIdGenerationConfig;
	@Mock
	private CreateCustomApplicationIdCaller createCustomApplicationIdCaller;
	@Mock
	private ModuleFormConfigParamCrudService moduleFormConfigParamCrudService;
	@Mock
	private ForceReadOnlyContextCheckerService forceReadOnlyContextCheckerService;

	private ApplicationsService applicationsService;

	private static final String TENANT_1 = "tenant_1";
	private static final String NEXT_KEY = "1";
	private static final Long PARTY_ID_1 = 24L;
	private static final AbsoluteDate ABSOLUTE_DATE_1 = new AbsoluteDate("20200919");
	private static final String MODULE_CODE = "module_code_1";
	private static final String MODULE_CODE_DESC = "module_code_1_desc";
	private static final Long SECTOR_ID_1 = 12L;
	private static final String SECTOR_CODE = "sector_code_1";
	private static final String SECTOR_CODE_DESC = "sector_code_1_desc";
	private static final Integer YEAR_1 = 2022;
	private static final String APPLICATION_CODE = "code";
	private static final Long APPLICATION_ID_1 = 30L;
	private static final String TAG_NAME = "tag_name";
	private static final Long AMEND_OF_ID = 5L;
	private static final Long AMENDED_BY_ID = 15L;
	private static final String SCOPE = "scope";
	private static final String WORKFLOW_DESCRIPTION = "workflow description";
	private static final String PRINT_CODE_1 = "print code - 1";
	private static final Long MODULE_ID_1 = 1L;
	private static final Integer TRANSITION_ID = 5;
	private static final String NODE_FROM = "node from";
	private static final String NODE_TO = "node to";
	private static final String NOTES = "notes";
	private static final Integer REFERRED_YEAR = 2022; // LocalDateTime.now().getYear();
	private static final Long PROCESS_ID_1 = 1L;
	private static final String USER_1 = "user_1";
	private static final LocalDateTime NOW = LocalDateTime.now();
	private static final String PROCESS_STATUS = "start";
	private static final String PROCESS_STATUS_DESCRIPTION = "Inizio Workflow";
	private static final User logged_user1 = new User(USER_1, TENANT_1);
	private static final LocalDateTime DEFAULT_NOT_DELETED_DATE = LocalDateTime.ofInstant(Instant.ofEpochSecond(253402300799L), ZoneOffset.UTC);
	private static final String PROCESS_STATUS_1 = "status_1";
	private static final String APPLICATION_CODE_1 = "30";
	private static final String PROCESS_1_START_NODE = "start";
	private static final String WORKFLOW_CODE_1 = "wf-code-1";
	private static final Long APPLICATION_DETAILS_ID_1 = 36L;
	private static final String PROFILE_CODE_1 = "code1";
	private static final AbsoluteDate DT_VALIDITY_START = new AbsoluteDate(LocalDate.now());
	private static final AbsoluteDate DT_VALIDITY_END = new AbsoluteDate(LocalDate.MAX);
	private static final String CONTEXT_FUNCTION = "context function";
	private static final Integer WORKFLOW_NODE_ID = 1;
	private static final String ACTION = "action";
	private static final String NAME = "name";
	private static final NodeType NODE_TYPE = NodeType.start;
	private static final Long PK_ID_1 = 1L;
	private static final String CUAA_1 = "0123213";
	private static final String APPLICATION_COMPILE_STATUS_1 = "compile-status-1";
	private static final String APPLICATION_COMPILE_STATUS_IDENTIFIER_1 = "compile-status-identifier-1";
	private static final LocalDateTime PRINT_DATE = LocalDateTime.of(2022, Month.JULY, 12, 14, 46, 49);
	private static final String FILE_ID = "123";
	private static final Integer FL_AMEND = 0;

	private static final ModuleByPointInTimeDTO MODULE_BY_POINT_IN_TIME_DTO = ModuleByPointInTimeDTO.builder()
			.moduleCode(MODULE_CODE)
			.moduleShortDescription(MODULE_CODE_DESC)
			.sectorCode(SECTOR_CODE)
			.sectorShortDescription(SECTOR_CODE_DESC)
			.year(YEAR_1)
			.build();
	private final ApplicationProfileDTO applicationProfileDTO = ApplicationProfileDTO.builder()
			.profileCode(PROFILE_CODE_1)
			.applicationId(APPLICATION_ID_1)
			.profileCodeDescription(PROFILE_CODE_1)
			.pkid(PK_ID_1)
			.build();
	private final ApplicationWithDetailsDTO applicationWithDetailsDTO = ApplicationWithDetailsDTO.builder()
			.applicationId(APPLICATION_ID_1)
			.moduleId(MODULE_ID_1)
			.referredYear(REFERRED_YEAR)
			.partyId(PARTY_ID_1)
			.processId(PROCESS_ID_1)
			.applicationCode(APPLICATION_CODE)
			.dtPresentation(NOW)
			.processStatus(PROCESS_STATUS)
			.processStatusDescription(PROCESS_STATUS_DESCRIPTION)
			.userIdInsert(USER_1)
			.userIdDelete(null)
			.dtInsert(NOW)
			.dtDelete(DEFAULT_NOT_DELETED_DATE)
			.profileList(List.of(applicationProfileDTO))
			.amendmentApplicationId(AMEND_OF_ID)
			.amendedApplicationId(AMENDED_BY_ID)
			.build();

	private final ApplicationDetailsDTO applicationDetailsDTO = ApplicationDetailsDTO.builder()
			.pkid(PK_ID_1)
			.processStatus(PROCESS_STATUS)
			.applicationCode(APPLICATION_CODE)
			.applicationId(APPLICATION_ID_1)
			.amendOfId(AMEND_OF_ID)
			.build();
	private final ApplicationDetailsDTO applicationDetailsDTONotInTransition = ApplicationDetailsDTO.builder()
			.flInTransition(0)
			.build();

	private final ApplicationDetailsDTO applicationDetailsDTOInTransition = ApplicationDetailsDTO.builder()
			.flInTransition(1)
			.build();

	private final AppByPartyAndYearDTO applicationByPartyAndYearDTOMock = AppByPartyAndYearDTO.builder()
			.applicationCode(APPLICATION_CODE_1)
			.dtPresentation(ABSOLUTE_DATE_1)
			.moduleCode(MODULE_CODE)
			.moduleDescription(MODULE_CODE_DESC)
			.partyId(PARTY_ID_1)
			.sectorCode(SECTOR_CODE)
			.sectorDescription(SECTOR_CODE_DESC)
			.year(YEAR_1)
			.processStatus(PROCESS_STATUS_1)
			.build();

	private static final ModuleProfileDTO moduleProfileDTO = ModuleProfileDTO.builder()
			.profileCode(PROFILE_CODE_1)
			.moduleId(MODULE_ID_1)
			.pkid(PK_ID_1)
			.build();

	private static final SectorDTO sectorDTO = SectorDTO.builder()
			.tenantId(TENANT_1)
			.sectorCode(SECTOR_CODE)
			.sectorId(SECTOR_ID_1)
			.build();

	private static final ModuleWithDetailDTO moduleWithDetailDTO = ModuleWithDetailDTO.builder()
			.moduleId(MODULE_ID_1)
			.moduleCode(MODULE_CODE)
			.sectorId(SECTOR_ID_1)
			.contextFunction("")
			.build();

	private static final SectorPublicDTO sectorPublicDTO = SectorPublicDTO.builder()
			.sectorId(SECTOR_ID_1)
			.sectorCode(SECTOR_CODE)
			.build();

	private static final ModuleProfilePublicDTO moduleProfilePublicDTO = ModuleProfilePublicDTO.builder()
			.profileCode(PROFILE_CODE_1)
			.build();

	private static final ModuleDetailsDTO moduleDetailsDto = ModuleDetailsDTO.builder()
			.dtValidityStart(DT_VALIDITY_START)
			.dtValidityEnd(DT_VALIDITY_END)
			.annuality(YEAR_1)
			.contextFunction(CONTEXT_FUNCTION)
			.build();
	private final ApplicationOutDTO applicationOutDTO = ApplicationOutDTO.builder()
			.application(applicationWithDetailsDTO)
			.applicationDetail(applicationDetailsDTO)
			.build();
	private final FormDetailsPublicDTO formDetailsPublicDTO = FormDetailsPublicDTO.builder()
			.formCode(FORM_CODE)
			.formConfigId(FORM_ID_1)
			.formName(FORM_NAME)
			.build();
	private final FormWithGroupHierarchyPublicDTO formWithGroupHierarchyPublicDTO = FormWithGroupHierarchyPublicDTO.builder()
			.formDetails(formDetailsPublicDTO)
			.build();
	private final ModuleDTO moduleDTO = ModuleDTO.builder()
			.flAmendModule(false)
			.moduleCode(MODULE_CODE)
			.moduleId(MODULE_ID_1)
			.sectorId(SECTOR_ID_1)
			.workflowCode(WORKFLOW_CODE_1)
			.build();
	private final PartyDTO partyDTO = PartyDTO.builder()
			.partyId(PARTY_ID_1)
			.cuaa(CUAA_1)
			.build();
	private final LastPrintDTO lastPrintDTO = LastPrintDTO.builder()
			.printDate(PRINT_DATE)
			.fileId(FILE_ID)
			.build();
	private final PrintDetailsOutDTO printDetailsOutDTO = PrintDetailsOutDTO.builder()
			.printCode(PRINT_CODE_1)
			.printConfigId(MODULE_PRINT_CONFIG_ID_1)
			.printDescription(PRINT_CODE_1)
			.sortOrder(1)
			.params(Map.of(MODULE_PRINT_CONFIG_1_PARAMETER_NAME_1, MODULE_PRINT_CONFIG_1_PARAMETER_VALUE_1))
			.lastPrint(lastPrintDTO)
			.build();

	private final Map<String, Object> metadataMock = new HashMap<>();
	private final WorkflowNode workflowNodeMock = WorkflowNode.builder()
			.id(WORKFLOW_NODE_ID)
			.action(ACTION)
			.name(NAME)
			.type(NODE_TYPE)
			.metadata(metadataMock)
			.build();

	private final ApplicationDTO applicationDTO = ApplicationDTO.builder()
			.moduleId(MODULE_ID_1)
			.applicationId(APPLICATION_ID_1)
			.referredYear(YEAR_1)
			.partyId(PARTY_ID_1)
			.build();

	private final ModuleWithParamsPublicDTO moduleWithParamsPublicDTO = ModuleWithParamsPublicDTO.builder()
			.moduleCode(MODULE_CODE)
			.build();

	private final ProgressApplicationDTO progressApplicationDTO = ProgressApplicationDTO.builder()
			.notes(NOTES)
			.build();

	private final WorkflowNodePublic workflowNodePublic = WorkflowNodePublic.builder()
			.name(NAME)
			.build();

	@BeforeEach
	protected void init() {
		CrudServiceContainer crudServiceContainer = CrudServiceContainer.builder()
				.moduleCrudService(moduleCrudService)
				.moduleDetailsCrudService(moduleDetailsCrudService)
				.applicationDetailsCrudService(applicationDetailsCrudService)
				.applicationsCrudService(applicationsCrudService)
				.moduleFormConfigsCrudService(moduleFormConfigsCrudService)
				.applicationCompileStatusCrudService(applicationCompileStatusCrudService)
				.applicationProfilesCrudService(applicationProfilesCrudService)
				.moduleProfilesCrudService(moduleProfilesCrudService)
				.modulePrintConfigsCrudService(modulePrintConfigsCrudService)
				.modulePrintConfigParamCrudService(modulePrintConfigParamCrudService)
				.applicationGeneratedPrintCrudService(applicationGeneratedPrintCrudService)
				.applicationGeneratedCalculationCrudService(applicationGeneratedCalculationCrudService)
				.sectorsCrudService(sectorsCrudService)
				.applicationProtocolsCrudService(applicationProtocolsCrudService)
				.moduleFormConfigParamCrudService(moduleFormConfigParamCrudService)
				.build();

		applicationsService = new ApplicationsService(
				jdbi,
				applicationsWorkflowService,
				checkPartyService,
				partyService,
				crudServiceContainer,
				createProcessQueue,
				progressService,
				formConfigService,
				amendmentService, printService, historyService, calculationService,
				customApplicationIdGenerationConfig,
				createCustomApplicationIdCaller,
				forceReadOnlyContextCheckerService);
		applicationsService.setAnomaliesService(anomaliesService);
	}

	@Test
	void test_getModulesByPointInTime_date_not_null() {
		when(moduleCrudService.findParentModules(TENANT_1, ABSOLUTE_DATE_1, FL_AMEND))
				.thenReturn(List.of(MODULE_BY_POINT_IN_TIME_DTO));
		assertEquals(MODULE_BY_POINT_IN_TIME_DTO,
				applicationsService.getModulesByPointInTime(TENANT_1, ABSOLUTE_DATE_1, FL_AMEND, null, sc).getRecords().stream().findFirst().orElse(null));
	}

	@Test
	void test_getModulesByPointInTime_date_null() {
		AbsoluteDate now = new AbsoluteDate(LocalDate.now());
		when(moduleCrudService.findParentModules(TENANT_1, now, FL_AMEND))
				.thenReturn(List.of(MODULE_BY_POINT_IN_TIME_DTO));
		assertEquals(MODULE_BY_POINT_IN_TIME_DTO,
				applicationsService.getModulesByPointInTime(TENANT_1, null, FL_AMEND, null, sc).getRecords().stream().findFirst().orElse(null));
	}

	@Test
	void test_getModulesByPointInTime_not_found() {
		when(moduleCrudService.findParentModules(TENANT_1, ABSOLUTE_DATE_1, FL_AMEND))
				.thenReturn(List.of());

		assertThrows(NoModulesFoundAtDateRuntimeException.class,
				() -> applicationsService.getModulesByPointInTime(TENANT_1, ABSOLUTE_DATE_1, FL_AMEND, null, sc));
	}

	@Test
	void test_getApplicationWithDetailsById_ok() {
		try {
			when(applicationsCrudService.findWithDetailsByApplicationId(TENANT_1, APPLICATION_ID_1)).thenReturn(applicationWithDetailsDTO);
			when(moduleDetailsCrudService.findByModuleId(TENANT_1, applicationWithDetailsDTO.getModuleId())).thenReturn(ModuleDetailsDTO.builder().build());
			when((applicationsWorkflowService.getProcessStatusDescription(TENANT_1, PROCESS_ID_1, logged_user1))).thenReturn(PROCESS_STATUS_DESCRIPTION);
			// when(applicationsCrudService.findWithDetailsByApplicationId(TENANT_1, AMEND_OF_ID))
			// .thenReturn(applicationWithDetailsDTO);
			// when(amendmentService.isApplicationAmendable(TENANT_1, AMEND_OF_ID))
			// .thenReturn(true);
			// when(amendmentService.isAmendModule(TENANT_1, MODULE_ID_1))
			// .thenReturn(true);
			assertEquals(applicationWithDetailsDTO, applicationsService.getApplicationWithDetailsById(TENANT_1, APPLICATION_ID_1, logged_user1, sc));
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			fail(e);
		}
	}

	@Test
	void test_getApplicationWithDetailsById_ActionNotAuthorizedRuntimeException() {
		try {
			when(applicationsCrudService.findWithDetailsByApplicationId(TENANT_1, APPLICATION_ID_1)).thenReturn(applicationWithDetailsDTO);
			when(moduleDetailsCrudService.findByModuleId(TENANT_1, applicationWithDetailsDTO.getModuleId())).thenReturn(moduleDetailsDto);

			when(sc.isUserInRole(CONTEXT_FUNCTION)).thenReturn(false);

			assertThrows(ActionNotAuthorizedRuntimeException.class,
					() -> applicationsService.getApplicationWithDetailsById(TENANT_1, APPLICATION_ID_1, logged_user1, sc));
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			fail(e);
		}
	}

	@Test
	void test_getApplicationWithDetailsById_WorkflowGenericRuntimeException() {
		try {
			when(applicationsCrudService.findWithDetailsByApplicationId(TENANT_1, APPLICATION_ID_1))
					.thenReturn(applicationWithDetailsDTO);
			when(moduleDetailsCrudService.findByModuleId(TENANT_1, applicationWithDetailsDTO.getModuleId()))
					.thenReturn(moduleDetailsDto);
			when((applicationsWorkflowService.getProcessStatusDescription(TENANT_1, PROCESS_ID_1, logged_user1)))
					.thenThrow(WorkflowNotFoundException.class);
			when(sc.isUserInRole(CONTEXT_FUNCTION)).thenReturn(true);

			assertThrows(WorkflowGenericRuntimeException.class,
					() -> applicationsService.getApplicationWithDetailsById(TENANT_1, APPLICATION_ID_1, logged_user1, sc));
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			fail(e);
		}
	}

	@Test
	void test_getPrintsByModuleIdAndProcessStatus_ok() {
		List<String> profileCodeList = List.of(PROFILE_CODE_1);

		Map<String, String> params = Map.of(MODULE_PRINT_CONFIG_1_PARAMETER_NAME_1, MODULE_PRINT_CONFIG_1_PARAMETER_VALUE_1);
		List<PrintDetailsOutDTO> expectedOutput = List.of(PrintDetailsOutDTO.builder()
				.printConfigId(MODULE_PRINT_CONFIG_ID_1)
				.printCode(PRINT_CODE_1)
				.printDescription(PRINT_CODE_1)
				.sortOrder(1)
				.params(params)
				.lastPrint(LastPrintDTO.builder()
						.fileId(FILE_ID)
						.printDate(PRINT_DATE)
						.build())
				.build());

		when(printService.getPrintsByModuleIdAndProcessStatus(TENANT_1, APPLICATION_ID_1, MODULE_ID_1, PROCESS_STATUS_1, List.of(PROFILE_CODE_1), sc))
				.thenReturn(List.of(printDetailsOutDTO));

		List<PrintDetailsOutDTO> result = applicationsService.getPrintsByModuleIdAndProcessStatus(TENANT_1, APPLICATION_ID_1, MODULE_ID_1, PROCESS_STATUS_1,
				profileCodeList, sc);

		assertEquals(expectedOutput, result);
	}

	@Test
	void test_getApplicationsByPartyAndYear_ok() {
		when(applicationsCrudService.find(TENANT_1, sc,PARTY_ID_1, YEAR_1, null))
				.thenReturn(new InfiniteListResultsImpl<>(List.of(applicationByPartyAndYearDTOMock), null));
		when(moduleCrudService.findByCode(TENANT_1, MODULE_CODE))
				.thenReturn(Optional.of(ModuleDTO.builder().moduleCode(MODULE_CODE).moduleId(MODULE_ID_1).build()));

		AppByPartyAndYearDTO result = applicationsService.getApplicationsByPartyAndYear(TENANT_1, PARTY_ID_1, YEAR_1, null, null, sc).getRecords().get(0);

		assertEquals(applicationByPartyAndYearDTOMock, result);
	}

	@Test
	void test_getApplicationsByPartyYearAndModuleCode_ok() {
		when(applicationsCrudService.findWithModuleCode(TENANT_1, PARTY_ID_1, YEAR_1, MODULE_CODE))
				.thenReturn(List.of(applicationByPartyAndYearDTOMock));
		when(moduleCrudService.findByCode(TENANT_1, MODULE_CODE))
				.thenReturn(Optional.of(ModuleDTO.builder().moduleCode(MODULE_CODE).moduleId(MODULE_ID_1).build()));

		List<AppByPartyAndYearDTO> result = applicationsService.getApplicationsByPartyYearAndModuleCode(TENANT_1, PARTY_ID_1, YEAR_1, MODULE_CODE,
				logged_user1);

		assertEquals(List.of(applicationByPartyAndYearDTOMock), result);
	}

	@Test
	void test_getApplicationsByPartyAndYear_catchException_ok() {
		when(applicationsCrudService.find(TENANT_1, sc, PARTY_ID_1, YEAR_1, null))
				.thenReturn(new InfiniteListResultsImpl<>(List.of(applicationByPartyAndYearDTOMock), null));
		when(moduleCrudService.findByCode(TENANT_1, MODULE_CODE))
				.thenReturn(Optional.of(ModuleDTO.builder().moduleCode(MODULE_CODE).moduleId(MODULE_ID_1).build()));
		when(applicationsWorkflowService.getProcessStatusDescription(TENANT_1, PROCESS_ID_1, logged_user1))
				.thenThrow(ProcessNotFoundException.class);

		AppByPartyAndYearDTO expectedOutput = AppByPartyAndYearDTO.builder()
				.applicationCode(APPLICATION_CODE_1)
				.dtPresentation(ABSOLUTE_DATE_1)
				.moduleCode(MODULE_CODE)
				.moduleDescription(MODULE_CODE_DESC)
				.partyId(PARTY_ID_1)
				.sectorCode(SECTOR_CODE)
				.sectorDescription(SECTOR_CODE_DESC)
				.year(YEAR_1)
				.processStatus(PROCESS_STATUS_1)
				.processStatusDescription("ERROR")
				.isClosed(true)
				.build();

		AppByPartyAndYearDTO result = applicationsService.getApplicationsByPartyAndYear(TENANT_1, PARTY_ID_1, YEAR_1, null, null, sc).getRecords().get(0);

		assertEquals(expectedOutput, result);
	}

	@Test
	void test_getApplicationsByPartyAndYear_not_found() {
		when(applicationsCrudService.find(TENANT_1, sc, PARTY_ID_1, YEAR_1, null))
				.thenReturn(new InfiniteListResultsImpl<>(List.of(), null));

		assertThrows(NoApplicationsFoundByPartyAndYearRuntimeException.class,
				() -> applicationsService.getApplicationsByPartyAndYear(TENANT_1, PARTY_ID_1, YEAR_1, null, null, sc));
	}

	@Test
	void test_getApplicationsByPartyAndYear_ActionNotAuthorizedRuntimeException() {
		doThrow(ActionNotAuthorizedRuntimeException.class).when(checkPartyService)
				.checkCanReadParty(TENANT_1, PARTY_ID_1, logged_user1);

		InfiniteListResults<AppByPartyAndYearDTO> result = applicationsService.getApplicationsByPartyAndYear(TENANT_1, PARTY_ID_1, YEAR_1, null, logged_user1, null);

		assertEquals(List.of(), result.getRecords());
	}

	@Test
	void test_getApplicationsSummaryByYear_no_party_id_ko() {
		assertThrows(NoMandatoryInputPartyIdRuntimeException.class, () -> applicationsService.getApplicationsSummaryByYear(TENANT_1, null, null, null));
	}

	@Test
	void test_getApplicationsSummaryByYear_no_data_found_ko() {

		when(applicationsCrudService.findAllByPartyId(TENANT_1, PARTY_ID_1)).thenReturn(List.of());

		assertThrows(NoApplicationSummaryFoundRuntimeException.class, () -> applicationsService.getApplicationsSummaryByYear(TENANT_1, PARTY_ID_1, null, null));
	}

	@Test
	void test_getApplicationsSummaryByYear_same_year_ok() {
		ApplicationDTO application1 = ApplicationDTO.builder()
				.partyId(PARTY_ID_1)
				.referredYear(2022)
				.applicationId(1L)
				.build();

		ApplicationDTO application2 = ApplicationDTO.builder()
				.partyId(PARTY_ID_1)
				.referredYear(2022)
				.applicationId(2L)
				.build();

		when(applicationsCrudService.findAllByPartyId(TENANT_1, PARTY_ID_1)).thenReturn(List.of(application1, application2));

		ApplicationsSummaryByYearOutDTO expectedResult = ApplicationsSummaryByYearOutDTO.builder()
				.partyId(PARTY_ID_1)
				.applicationsSummaryByYear(List.of(ApplicationsSummaryByYearDTO.builder()
						.applicationsNumber(2)
						.year(2022)
						.build()))
				.build();

		ApplicationsSummaryByYearOutDTO result = applicationsService.getApplicationsSummaryByYear(TENANT_1, PARTY_ID_1, null, sc);

		assertEquals(expectedResult, result);
	}

	@Test
	void test_getApplicationsSummaryByYear_different_years_ok() {
		ApplicationDTO application1 = ApplicationDTO.builder()
				.partyId(PARTY_ID_1)
				.referredYear(2021)
				.applicationId(1L)
				.build();

		ApplicationDTO application2 = ApplicationDTO.builder()
				.partyId(PARTY_ID_1)
				.referredYear(2022)
				.applicationId(2L)
				.build();

		when(applicationsCrudService.findAllByPartyId(TENANT_1, PARTY_ID_1)).thenReturn(List.of(application1, application2));

		ApplicationsSummaryByYearOutDTO expectedResult = ApplicationsSummaryByYearOutDTO.builder()
				.partyId(PARTY_ID_1)
				.applicationsSummaryByYear(List.of(ApplicationsSummaryByYearDTO.builder()
						.applicationsNumber(1)
						.year(2021)
						.build(),
						ApplicationsSummaryByYearDTO.builder()
								.applicationsNumber(1)
								.year(2022)
								.build()))
				.build();

		ApplicationsSummaryByYearOutDTO result = applicationsService.getApplicationsSummaryByYear(TENANT_1, PARTY_ID_1, null, sc);

		assertEquals(expectedResult, result);
	}

	@Test
	void test_createApplication_noModuleFound_ko() {
		when(moduleCrudService.findByModuleCodeAndSectorCode(TENANT_1, MODULE_CODE, SECTOR_CODE)).thenReturn(Optional.empty());

		CreateApplicationInDTO createApplicationInDTO = CreateApplicationInDTO.builder()
				.moduleCode(MODULE_CODE)
				.sectorCode(SECTOR_CODE)
				.partyId(PARTY_ID_1)
				.year(YEAR_1)
				.build();

		assertThrows(NoModulesFoundAtDateRuntimeException.class, () -> applicationsService.createApplication(TENANT_1, logged_user1, createApplicationInDTO, CreateProcessType.ASYNC, null));
	}

	@Test
	void test_createApplication_noModuleFound_sync_ko() {
		when(moduleCrudService.findByModuleCodeAndSectorCode(TENANT_1, MODULE_CODE, SECTOR_CODE)).thenReturn(Optional.empty());

		CreateApplicationInDTO createApplicationInDTO = CreateApplicationInDTO.builder()
				.moduleCode(MODULE_CODE)
				.sectorCode(SECTOR_CODE)
				.partyId(PARTY_ID_1)
				.year(YEAR_1)
				.build();

		assertThrows(NoModulesFoundAtDateRuntimeException.class, () -> applicationsService.createApplication(TENANT_1, logged_user1, createApplicationInDTO, CreateProcessType.SYNC, null));
	}

	@Test
	void test_createApplicationAsync_emptyApplicationAnomalies_ok() {
		ModuleDTO module1 = ModuleDTO.builder()
				.moduleCode(MODULE_CODE)
				.moduleId(MODULE_ID_1)
				.sectorId(SECTOR_ID_1)
				.build();

		when(moduleCrudService.findByModuleCodeAndSectorCode(TENANT_1, MODULE_CODE, SECTOR_CODE)).thenReturn(Optional.of(module1));
		when(moduleDetailsCrudService.findByModuleId(TENANT_1, MODULE_ID_1)).thenReturn(moduleDetailsDto);

		/*
		 * when(anomaliesService.checkForMultipleApplication(TENANT_1, MODULE_CODE, PARTY_ID_1, REFERRED_YEAR)).thenReturn(Collections.emptyList());
		 */

		CreateApplicationInDTO createApplicationInDTO = CreateApplicationInDTO.builder()
				.moduleCode(MODULE_CODE)
				.sectorCode(SECTOR_CODE)
				.partyId(PARTY_ID_1)
				.year(YEAR_1)
				.build();

		ApplicationDTO insertedApplicationDTO = ApplicationDTO.builder()
				.applicationId(APPLICATION_ID_1)
				.dtDelete(DEFAULT_NOT_DELETED_DATE)
				.dtInsert(NOW)
				.moduleId(MODULE_ID_1)
				.processId(PROCESS_ID_1)
				.referredYear(YEAR_1)
				.userIdInsert(USER_1)
				.build();

		ApplicationDetailsDTO insertedApplicationDetailsDTO = ApplicationDetailsDTO.builder()
				.applicationCode(APPLICATION_CODE_1)
				.applicationId(APPLICATION_ID_1)
				.dtDelete(DEFAULT_NOT_DELETED_DATE)
				.dtInsert(NOW)
				.pkid(APPLICATION_DETAILS_ID_1)
				.processStatus(PROCESS_STATUS)
				.userIdInsert(USER_1)
				.build();

		ApplicationOutDTO transactionOutput = ApplicationOutDTO.builder()
				.application(insertedApplicationDTO)
				.applicationDetail(insertedApplicationDetailsDTO)
				.build();

		CreateApplicationOutDTO expectedResult = CreateApplicationOutDTO.builder()
				.applicationId(APPLICATION_ID_1)
				.applicationCode(transactionOutput.getApplicationDetail().getApplicationCode())
				.build();

		ApplicationsService applicationsServiceSpy = spy(applicationsService);

		Mockito.doReturn(transactionOutput).when(applicationsServiceSpy)
				.doInsertApplication(TENANT_1, logged_user1, createApplicationInDTO, module1, CreateProcessType.ASYNC, null);

		assertEquals(expectedResult, applicationsServiceSpy.createApplication(TENANT_1, logged_user1, createApplicationInDTO, CreateProcessType.ASYNC, null));
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Test
	void createAmendmentApplicationAsync_ok() {
		try {
			ArgumentCaptor<HandleCallback> handleCallbackArgumentCaptor = ArgumentCaptor.forClass(HandleCallback.class);
			ArgumentCaptor<HandleConsumer> handleConsumerArgumentCaptor = ArgumentCaptor.forClass(HandleConsumer.class);

			ModuleDTO module1 = ModuleDTO.builder()
					.moduleCode(MODULE_CODE)
					.moduleId(MODULE_ID_1)
					.sectorId(SECTOR_ID_1)
					.build();
			ApplicationDetailsDTO applicationDetailsToUpdate = ApplicationDetailsDTO.builder()
					.pkid(PK_ID_1)
					.processStatus(PROCESS_STATUS)
					.applicationCode(APPLICATION_CODE)
					.applicationId(APPLICATION_ID_1)
					.build();

			when(moduleCrudService.findByModuleCodeAndSectorCode(TENANT_1, MODULE_CODE, SECTOR_CODE))
					.thenReturn(Optional.of(module1));
			when(jdbi.inTransaction(any()))
					.thenCallRealMethod()
					.thenReturn(applicationOutDTO);
			when(applicationDetailsCrudService.findApplicationDetailById(TENANT_1, APPLICATION_ID_1))
					.thenReturn(applicationDetailsToUpdate);

			CreateApplicationInDTO createApplicationInDTO = CreateApplicationInDTO.builder()
					.moduleCode(MODULE_CODE)
					.sectorCode(SECTOR_CODE)
					.partyId(PARTY_ID_1)
					.year(YEAR_1)
					.amendmentApplicationId(APPLICATION_ID_1)
					.build();

			CreateAmendmentApplicationOutDTO expectedResult = CreateAmendmentApplicationOutDTO.builder()
					.applicationId(APPLICATION_ID_1)
					.applicationCode(APPLICATION_CODE)
					.amendmentApplicationId(AMEND_OF_ID)
					.build();

			applicationsService.createAmendmentApplicationAsync(TENANT_1, logged_user1, createApplicationInDTO, null);

			verify(jdbi).inTransaction(handleCallbackArgumentCaptor.capture());
			CreateAmendmentApplicationOutDTO result = (CreateAmendmentApplicationOutDTO) handleCallbackArgumentCaptor.getValue().withHandle(handle);

			verify(jdbi).useTransaction(handleConsumerArgumentCaptor.capture());
			handleConsumerArgumentCaptor.getValue().useHandle(handle);

			applicationDetailsToUpdate.setAmendOfId(AMEND_OF_ID);
			verify(applicationDetailsCrudService, times(1)).update(PK_ID_1, applicationDetailsToUpdate, USER_1);

			assertEquals(expectedResult, result);
		} catch (Exception e) {
			fail(e);
		}
	}

	@Test
	void createAmendmentApplicationAsync_withAnomalies_ok() {
		try {
			ModuleDTO module1 = ModuleDTO.builder()
					.moduleCode(MODULE_CODE)
					.moduleId(MODULE_ID_1)
					.sectorId(SECTOR_ID_1)
					.build();

			ApplicationAnomaly applicationAnomaly = ApplicationAnomaly.builder()
					.code(WAIVED_APPLICATION_ERROR_CODE)
					.message(WAIVED_APPLICATION_ERROR_MSG)
					.build();

			when(moduleCrudService.findByModuleCodeAndSectorCode(TENANT_1, MODULE_CODE, SECTOR_CODE))
					.thenReturn(Optional.of(module1));
			when(anomaliesService.checkForApplicationWaived(TENANT_1, APPLICATION_ID_1))
					.thenReturn(List.of(applicationAnomaly));

			CreateApplicationInDTO createApplicationInDTO = CreateApplicationInDTO.builder()
					.moduleCode(MODULE_CODE)
					.sectorCode(SECTOR_CODE)
					.partyId(PARTY_ID_1)
					.year(YEAR_1)
					.amendmentApplicationId(APPLICATION_ID_1)
					.build();

			CreateAmendmentApplicationOutDTO expectedResult = CreateAmendmentApplicationOutDTO.builder()
					.anomalies(List.of(applicationAnomaly))
					.build();

			CreateAmendmentApplicationOutDTO result = applicationsService.createAmendmentApplicationAsync(TENANT_1, logged_user1, createApplicationInDTO, null);

			assertEquals(expectedResult, result);
		} catch (Exception e) {
			fail(e);
		}
	}

	@Test
	void createAmendmentApplicationAsync_withoutAmendmentApplicationId_ko() {
		try {
			CreateApplicationInDTO createApplicationInDTO = CreateApplicationInDTO.builder()
					.moduleCode(MODULE_CODE)
					.sectorCode(SECTOR_CODE)
					.partyId(PARTY_ID_1)
					.year(YEAR_1)
					.build();

			assertThrows(BadRequestRuntimeException.class, () -> applicationsService.createAmendmentApplicationAsync(TENANT_1, logged_user1, createApplicationInDTO, null));
		} catch (Exception e) {
			fail(e);
		}
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Test
	void createAmendmentApplicationAsync_withoutApplicationToUpdate_ko() {
		try {
			ArgumentCaptor<HandleCallback> handleCallbackArgumentCaptor = ArgumentCaptor.forClass(HandleCallback.class);
			ArgumentCaptor<HandleConsumer> handleConsumerArgumentCaptor = ArgumentCaptor.forClass(HandleConsumer.class);

			ModuleDTO module1 = ModuleDTO.builder()
					.moduleCode(MODULE_CODE)
					.sectorId(SECTOR_ID_1)
					.build();

			when(moduleCrudService.findByModuleCodeAndSectorCode(TENANT_1, MODULE_CODE, SECTOR_CODE))
					.thenReturn(Optional.of(module1));
			when(jdbi.inTransaction(any()))
					.thenCallRealMethod()
					.thenReturn(applicationOutDTO);
			when(applicationDetailsCrudService.findApplicationDetailById(TENANT_1, APPLICATION_ID_1))
					.thenThrow(ObjectNotFoundException.class);

			CreateApplicationInDTO createApplicationInDTO = CreateApplicationInDTO.builder()
					.moduleCode(MODULE_CODE)
					.sectorCode(SECTOR_CODE)
					.partyId(PARTY_ID_1)
					.year(YEAR_1)
					.amendmentApplicationId(APPLICATION_ID_1)
					.build();

			applicationsService.createAmendmentApplicationAsync(TENANT_1, logged_user1, createApplicationInDTO, null);

			assertThrows(ApplicationNotFoundRuntimeException.class, () -> {
				verify(jdbi).inTransaction(handleCallbackArgumentCaptor.capture());
				handleCallbackArgumentCaptor.getValue().withHandle(handle);

				verify(jdbi).useTransaction(handleConsumerArgumentCaptor.capture());
				handleConsumerArgumentCaptor.getValue().useHandle(handle);
			});
		} catch (Exception e) {
			fail(e);
		}
	}

	@Test
	void getDetailedApplicationById_ok() {
		when(applicationsCrudService.findWithDetailsByApplicationId(TENANT_1, APPLICATION_ID_1))
				.thenReturn(applicationWithDetailsDTO);
		when(applicationProfilesCrudService.findAll(TENANT_1, APPLICATION_ID_1, MDC.get(MDCPreFilter.LOCALE)))
				.thenReturn(List.of(applicationProfileDTO));
		when(moduleDetailsCrudService.findByModuleId(TENANT_1, applicationWithDetailsDTO.getModuleId()))
				.thenReturn(ModuleDetailsDTO.builder().build());
		when((applicationsWorkflowService.getProcessStatusDescription(TENANT_1, PROCESS_ID_1, logged_user1)))
				.thenReturn(PROCESS_STATUS_DESCRIPTION);
		when(amendmentService.getOriginalAmendedApplicationId(applicationWithDetailsDTO, TENANT_1))
				.thenReturn(AMEND_OF_ID);
		when(formConfigService.getFormsByModuleIdAndProcessStatus(TENANT_1, MODULE_ID_1, PROCESS_STATUS, List.of(),
				List.of(PROFILE_CODE_1), sc, MDC.get(MDCPreFilter.LOCALE)))
				.thenReturn(List.of(formWithGroupHierarchyPublicDTO));
		when(moduleCrudService.findById(MODULE_ID_1))
				.thenReturn(Optional.of(moduleDTO));
		when(applicationsWorkflowService.getNodeMetadata(TENANT_1, WORKFLOW_CODE_1, PROCESS_1_START_NODE))
				.thenReturn(Map.of());
		when(partyService.getPartyByPartyId(TENANT_1, PARTY_ID_1, logged_user1))
				.thenReturn(partyDTO);
		when(printService.getPrintsByModuleIdAndProcessStatus(TENANT_1, APPLICATION_ID_1, MODULE_ID_1, PROCESS_STATUS, List.of(PROFILE_CODE_1), sc))
				.thenReturn(List.of(printDetailsOutDTO));

		ApplicationWithDetailsDTO expectedOutput = ApplicationWithDetailsDTO.builder()
				.applicationCode(APPLICATION_CODE)
				.processStatus(PROCESS_STATUS)
				.processStatusDescription(PROCESS_STATUS_DESCRIPTION)
				.dtPresentation(NOW)
				.compileStatus(Collections.emptyList())
				.profileList(List.of(applicationProfileDTO))
				.moduleId(MODULE_ID_1)
				.processId(PROCESS_ID_1)
				.originalAmendedApplicationId(AMEND_OF_ID)
				.amendmentApplicationId(AMEND_OF_ID)
				.amendedApplicationId(AMENDED_BY_ID)
				.referredYear(REFERRED_YEAR)
				.partyId(PARTY_ID_1)
				.applicationId(APPLICATION_ID_1)
				.forms(List.of(formWithGroupHierarchyPublicDTO))
				.prints(List.of(printDetailsOutDTO))
				.isClosed(false)
				.party(partyDTO)
				.userIdInsert(USER_1)
				.dtDelete(DEFAULT_NOT_DELETED_DATE)
				.build();

		ApplicationWithDetailsDTO result = applicationsService.getDetailedApplicationById(TENANT_1, APPLICATION_ID_1, logged_user1, sc);

		assertEquals(expectedOutput, result);
	}

	@Test
	void test_createApplicationAsync_notEmptyApplicationAnomalies_ok() {
		ModuleDTO module1 = ModuleDTO.builder()
				.moduleCode(MODULE_CODE)
				.moduleId(MODULE_ID_1)
				.sectorId(SECTOR_ID_1)
				.build();

		List<ApplicationAnomaly> applicationAnomalies = List.of(ApplicationAnomaly.builder()
				.code(APPLICATION_CODE)
				.build());

		when(moduleCrudService.findByModuleCodeAndSectorCode(TENANT_1, MODULE_CODE, SECTOR_CODE))
				.thenReturn(Optional.of(module1));
		when(moduleDetailsCrudService.findByModuleId(TENANT_1, MODULE_ID_1)).thenReturn(moduleDetailsDto);

		when(anomaliesService.checkForMultipleApplication(TENANT_1, module1, PARTY_ID_1, REFERRED_YEAR, null))
				.thenReturn(applicationAnomalies);

		CreateApplicationInDTO createApplicationInDTO = CreateApplicationInDTO.builder()
				.moduleCode(MODULE_CODE)
				.sectorCode(SECTOR_CODE)
				.partyId(PARTY_ID_1)
				.year(YEAR_1)
				.build();

		CreateApplicationOutDTO expectedResult = CreateApplicationOutDTO.builder()
				.anomalies(applicationAnomalies)
				.build();

		ApplicationsService applicationsServiceSpy = spy(applicationsService);

		assertEquals(expectedResult, applicationsServiceSpy.createApplication(TENANT_1, logged_user1, createApplicationInDTO, CreateProcessType.ASYNC, null));
	}

	@Test
	void test_getProfilesByModuleAndSector() {
		when(moduleProfilesCrudService.find(TENANT_1, SECTOR_CODE, MODULE_CODE, ABSOLUTE_DATE_1, null))
				.thenReturn(new InfiniteListResultsImpl<>(List.of(moduleProfileDTO), null));
		assertEquals(List.of(moduleProfilePublicDTO),
				applicationsService.getProfilesByModuleAndSector(TENANT_1, SECTOR_CODE, MODULE_CODE, ABSOLUTE_DATE_1, null).getRecords());
	}

	@Test
	void test_getModulesBySectorCode() {

		try {
			when(sectorsCrudService.findSectorByCode(TENANT_1, SECTOR_CODE))
					.thenReturn(sectorDTO);

			when(moduleCrudService.findAllModulesWithDetailBySectorId(TENANT_1, SECTOR_ID_1)).thenReturn(List.of(moduleWithDetailDTO));

			assertEquals(List.of(moduleWithDetailDTO),
					applicationsService.getModulesBySectorCode(TENANT_1, SECTOR_CODE, sc));

		} catch (Exception e) {
			fail(e);
		}

	}

	@Test
	void test_getSectorsByTenant() {
		when(sectorsCrudService.findInfiniteAllSectors(TENANT_1, NEXT_KEY))
				.thenReturn(new InfiniteListResultsImpl<>(List.of(sectorDTO), NEXT_KEY));
		assertEquals(List.of(sectorPublicDTO),
				applicationsService.getSectorsByTenant(TENANT_1, NEXT_KEY).getRecords());
	}

	@Test
	void test_getSectorsByTenant_exception() {
		when(sectorsCrudService.findInfiniteAllSectors(TENANT_1, null))
				.thenReturn(new InfiniteListResultsImpl<>(Collections.emptyList(), null));

		assertThrows(NoSectorsFoundAtDateRuntimeException.class,
				() -> applicationsService.getSectorsByTenant(TENANT_1, null));
	}

	@Test
	void test_getStatusNodes() {
		when(moduleCrudService.findByCode(TENANT_1, MODULE_CODE))
				.thenReturn(Optional.of(moduleDTO));
		when(applicationsWorkflowService.getWorkflowNodesByType(TENANT_1, WORKFLOW_CODE_1, NodeType.status)).thenReturn(List.of(workflowNodeMock));

		assertEquals(List.of(workflowNodePublic),
				applicationsService.getStatusNodes(TENANT_1, MODULE_CODE));
	}

	@Test
	void test_getProfilesByModuleAndSector_exception() {
		when(moduleProfilesCrudService.find(TENANT_1, SECTOR_CODE, MODULE_CODE, ABSOLUTE_DATE_1, null))
				.thenReturn(new InfiniteListResultsImpl<>(Collections.emptyList(), null));

		assertThrows(NoProfilesFoundAtDateRuntimeException.class,
				() -> applicationsService.getProfilesByModuleAndSector(TENANT_1, SECTOR_CODE, MODULE_CODE, ABSOLUTE_DATE_1, null));
	}

	@Test
	void test_findCompileStatus_ok() {
		ApplicationCompileStatusDTO compileStatus = ApplicationCompileStatusDTO.builder()
				.applicationId(APPLICATION_ID_1)
				.compileStatusIdentifier(STATUS_1)
				.pkid(PK_ID_1)
				.build();

		InfiniteListResultsImpl<ApplicationCompileStatusDTO> infiniteListResults = new InfiniteListResultsImpl<>();
		infiniteListResults.setRecords(List.of(compileStatus));

		when(applicationCompileStatusCrudService.find(TENANT_1, APPLICATION_ID_1, null)).thenReturn(infiniteListResults);

		assertEquals(infiniteListResults, applicationsService.findCompileStatus(TENANT_1, APPLICATION_ID_1, null));
	}

	@Test
	void test_findCompileStatus_object_not_found_ko() {
		when(applicationCompileStatusCrudService.find(TENANT_1, APPLICATION_ID_1, null))
				.thenThrow(new ObjectNotFoundRuntimeException("not found"));

		assertThrows(ObjectNotFoundRuntimeException.class, () -> applicationsService.findCompileStatus(TENANT_1, APPLICATION_ID_1, null));
	}

	@Test
	void test_updateCompileStatus_ok() {
		ApplicationCompileStatusDTO compileStatus = ApplicationCompileStatusDTO.builder()
				.applicationId(APPLICATION_ID_1)
				.compileStatusIdentifier(STATUS_1)
				.status(STATUS_2)
				.pkid(PK_ID_1)
				.build();

		ApplicationCompileStatusPayloadDTO compileStatusInput = ApplicationCompileStatusPayloadDTO.builder()
				.status(STATUS_2)
				.build();

		ApplicationCompileStatusDTO compileStatusUpdated = ApplicationCompileStatusDTO.builder()
				.applicationId(APPLICATION_ID_1)
				.compileStatusIdentifier(STATUS_2)
				.pkid(PK_ID_1)
				.build();

		ApplicationDTO application = ApplicationDTO.builder()
				.applicationId(APPLICATION_ID_1)
				.build();

		try {
			when(applicationsCrudService.findById(TENANT_1, APPLICATION_ID_1)).thenReturn(application);
			when(applicationCompileStatusCrudService.findByCompileStatusIdentifier(TENANT_1, APPLICATION_ID_1, STATUS_1)).thenReturn(compileStatus);
			when(applicationCompileStatusCrudService.update(PK_ID_1, compileStatus, USER_1)).thenReturn(compileStatusUpdated);

			assertEquals(compileStatusUpdated, applicationsService.updateCompileStatus(TENANT_1, APPLICATION_ID_1, STATUS_1, compileStatusInput, USER_1));
		} catch (Exception e) {
			fail(e);
		}
	}

	@Test
	void test_updateCompileStatus_application_not_found_ko() throws ObjectNotFoundException {
		ApplicationCompileStatusPayloadDTO compileStatusInput = ApplicationCompileStatusPayloadDTO.builder()
				.status(STATUS_2)
				.build();

		when(applicationsCrudService.findById(TENANT_1, APPLICATION_ID_1)).thenThrow(new ObjectNotFoundException("not found"));

		assertThrows(ApplicationNotFoundRuntimeException.class,
				() -> applicationsService.updateCompileStatus(TENANT_1, APPLICATION_ID_1, STATUS_2, compileStatusInput, USER_1));
	}

	@Test
	void test_updateCompileStatus_compile_status_not_found() {
		try {
			ApplicationCompileStatusPayloadDTO compileStatusInput = ApplicationCompileStatusPayloadDTO.builder()
					.status(STATUS_2)
					.build();
			ApplicationDTO application = ApplicationDTO.builder()
					.applicationId(APPLICATION_ID_1)
					.build();

			when(applicationsCrudService.findById(TENANT_1, APPLICATION_ID_1)).thenReturn(application);
			when(applicationCompileStatusCrudService.findByCompileStatusIdentifier(TENANT_1, APPLICATION_ID_1, STATUS_1))
					.thenThrow(new ObjectNotFoundException("not found"));

			applicationsService.updateCompileStatus(TENANT_1, APPLICATION_ID_1, STATUS_1, compileStatusInput, USER_1);
		} catch (Exception e) {
			fail(e.getMessage(), e);
		}
	}

	// @Test
	// void test_getApplicationsByModuleCode_ok() {
	//
	// when(partyService.getPartiesByCodeOrDesc(TENANT_1 , -1L, CUAA_1, "", logged_user1)).thenReturn(List.of(partyDTO));
	//
	// when(applicationsCrudService.findInfiniteResults(TENANT_1, MODULE_CODE, PARTY_ID_1, YEAR_1, PROCESS_STATUS)).thenReturn(List.of(appByPartyAndYearDTO));
	//
	// InfiniteListResults<AppByPartyAndYearDTO> results = applicationsService.getModuleFormConfigsByModuleCode(TENANT_1, MODULE_CODE, CUAA_1, YEAR_1,
	// PROCESS_STATUS, NEXT_KEY, logged_user1);
	//
	// assertEquals(List.of(appByPartyAndYearDTO), results.getRecords());
	// }

	// @Test
	// void test_getApplicationsByCuaa_ok() {
	//
	// when(partyService.getPartiesByCodeOrDesc(TENANT_1 , -1L, CUAA_1, "", logged_user1)).thenReturn(List.of(partyDTO));
	//
	// when(applicationsCrudService.findInfiniteResults(TENANT_1, MODULE_CODE, PARTY_ID_1, YEAR_1, PROCESS_STATUS)).thenReturn(List.of(appByPartyAndYearDTO));
	//
	// InfiniteListResults<AppByPartyAndYearDTO> results = applicationsService.getApplicationsByCuaa(TENANT_1, CUAA_1, MODULE_CODE, YEAR_1, PROCESS_STATUS,
	// NEXT_KEY, logged_user1);
	//
	// assertEquals(List.of(appByPartyAndYearDTO), results.getRecords());
	// }

	@Test
	void test_getApplicationProfiles_ok() {
		ApplicationProfileDTO applicationProfile = ApplicationProfileDTO.builder()
				.profileCode("profileCode1")
				.profileCodeDescription("profileDesc1")
				.build();

		ApplicationProfilePublicDTO applicationProfilePublic = ApplicationProfilePublicDTO.builder()
				.profileCode("profileCode1")
				.profileCodeDescription("profileDesc1")
				.build();
		InfiniteListResultsImpl<ApplicationProfileDTO> infiniteListAppProfile = new InfiniteListResultsImpl<>();
		infiniteListAppProfile.setRecords(List.of(applicationProfile));

		InfiniteListResultsImpl<ApplicationProfilePublicDTO> infiniteListResults = new InfiniteListResultsImpl<>();
		infiniteListResults.setRecords(List.of(applicationProfilePublic));

		when(applicationProfilesCrudService.find(TENANT_1, APPLICATION_ID_1, null, null)).thenReturn(infiniteListAppProfile);
		assertEquals(infiniteListResults.getRecords(), applicationsService.getApplicationProfiles(TENANT_1, APPLICATION_ID_1, null, null, null).getRecords());
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Test
	void test_doInsertApplication_ok() {
		try {
			ArgumentCaptor<HandleCallback> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(HandleCallback.class);

			ModuleDTO module = ModuleDTO.builder()
					.moduleId(MODULE_ID_1)
					.workflowCode(WORKFLOW_CODE_1)
					.build();

			CreateApplicationInDTO applicationIn = CreateApplicationInDTO.builder()
					.build();
			ApplicationDetailsDTO insertedDetails = ApplicationDetailsDTO.builder()
					.applicationCode(APPLICATION_CODE_1)
					.build();
			ApplicationDTO insertedApplication = ApplicationDTO.builder()
					.applicationId(APPLICATION_ID_1)
					.moduleId(MODULE_ID_1)
					.partyId(PARTY_ID_1)
					.referredYear(YEAR_1)
					.build();
			ApplicationsWorkflowParams wfParams = ApplicationsWorkflowParams.builder()
					.applicationId(APPLICATION_ID_1)
					.applicationCode(APPLICATION_CODE_1)
					.tenant(TENANT_1)
					.username(USER_1)
					.userid(USER_1)
					.locale(MDC.get(MDCPreFilter.LOCALE))
					.partyId(PARTY_ID_1)
					.workflowCode(WORKFLOW_CODE_1)
					.referredYear(YEAR_1)
					.build();

			ApplicationOutDTO expectedOutput = ApplicationOutDTO.builder()
					.application(insertedApplication)
					.applicationDetail(insertedDetails)
					.build();

			when(jdbi.inTransaction(any()))
					.thenReturn(expectedOutput);

			applicationsService.doInsertApplication(TENANT_1, logged_user1, applicationIn, module, CreateProcessType.ASYNC, null);

			verify(jdbi).inTransaction(handleConsumerLambdaCaptor.capture());
			ApplicationOutDTO result = (ApplicationOutDTO) handleConsumerLambdaCaptor.getValue().withHandle(handle);

			verify(createProcessQueue).add(eq(wfParams), anyLong());

			assertEquals(expectedOutput, result);
		} catch (Exception e) {
			fail(e);
		}

	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Test
	void test_createVanillaApplicationWithDetails_ok() throws Exception {
		ArgumentCaptor<HandleCallback> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(HandleCallback.class);

		CreateApplicationInDTO payload = CreateApplicationInDTO.builder()
				.year(YEAR_1)
				.partyId(PARTY_ID_1)
				.build();

		ApplicationDTO applicationDTO = ApplicationDTO.builder()
				.partyId(PARTY_ID_1)
				.referredYear(YEAR_1)
				.moduleId(MODULE_ID_1)
				.userIdInsert(USER_1)
				.build();

		ApplicationDTO applicationOutDTO = ApplicationDTO.builder()
				.applicationId(APPLICATION_ID_1)
				.partyId(PARTY_ID_1)
				.referredYear(YEAR_1)
				.moduleId(MODULE_ID_1)
				.userIdInsert(USER_1)
				.build();

		ApplicationDetailsDTO applicationDetailsDTO = ApplicationDetailsDTO.builder()
				.applicationId(APPLICATION_ID_1)
				.applicationCode(APPLICATION_CODE_1)
				.flInTransition(ProcessTransitionEnum.NOT_IN_TRANSITION.getFl())
				.build();

		ModuleDTO module = ModuleDTO.builder()
				.moduleId(MODULE_ID_1)
				.build();

		when(applicationsCrudService.insert(applicationDTO, USER_1)).thenReturn(applicationOutDTO);

		applicationsService.createVanillaApplicationWithDetails(TENANT_1, logged_user1, payload, module);

		verify(jdbi).inTransaction(handleConsumerLambdaCaptor.capture());
		handleConsumerLambdaCaptor.getValue().withHandle(handle);

		verify(applicationsCrudService, times(1)).insert(applicationDTO, USER_1);
		verify(applicationDetailsCrudService, times(1)).insert(applicationDetailsDTO, USER_1);
	}

	@Test
	void test_checkForMetadata_ok() {
		ModuleDTO moduleDTO = ModuleDTO.builder()
				.build();
		Map<String, Object> expectedOutput = Map.of("first", "value", "second", "value");

		when(applicationsCrudService.findWithDetailsByApplicationCode(TENANT_1, APPLICATION_CODE))
				.thenReturn(applicationWithDetailsDTO);
		when(moduleCrudService.findById(applicationWithDetailsDTO.getModuleId()))
				.thenReturn(Optional.of(moduleDTO));
		when(applicationsWorkflowService.getNodeMetadata(TENANT_1, moduleDTO.getWorkflowCode(),
				applicationWithDetailsDTO.getProcessStatus()))
						.thenReturn(expectedOutput);

		Map<String, Object> result = applicationsService.checkForMetadata(TENANT_1, APPLICATION_CODE);

		assertEquals(expectedOutput, result);
	}

	@Test
	void test_checkForMetadataOnCreate_returnsEmptyMap() {
		ApplicationWithDetailsDTO dto = ApplicationWithDetailsDTO.builder()
				.applicationCode("x")
				.processStatus(null)
				.build();

		Map<String, Object> result = applicationsService.checkForMetadata(TENANT_1, dto);
		assertEquals(0, result.size());
		verify(applicationsWorkflowService, never()).getNodeMetadata(anyString(), anyString(), anyString());
	}

	@Test
	void test_isApplicationClosed_true_ok() {
		ModuleDTO moduleDTO = ModuleDTO.builder()
				.build();
		Map<String, Object> metadata = Map.of(WORKFLOW_CLOSED_KEY, true);

		when(applicationsCrudService.findWithDetailsByApplicationId(TENANT_1, APPLICATION_ID_1))
				.thenReturn(applicationWithDetailsDTO);
		when(moduleDetailsCrudService.findByModuleId(TENANT_1, applicationWithDetailsDTO.getModuleId()))
				.thenReturn(moduleDetailsDto);
		when(sc.isUserInRole(CONTEXT_FUNCTION)).thenReturn(true);
		when(moduleCrudService.findById(applicationWithDetailsDTO.getModuleId()))
				.thenReturn(Optional.of(moduleDTO));
		when(applicationsWorkflowService.getNodeMetadata(TENANT_1, moduleDTO.getWorkflowCode(),
				applicationWithDetailsDTO.getProcessStatus()))
						.thenReturn(metadata);

		boolean result = applicationsService.isApplicationClosed(TENANT_1, APPLICATION_ID_1, logged_user1, sc);

		assertTrue(result);
	}

	@Test
	void test_isApplicationClosed_invalidMetadata_ko() {
		ModuleDTO moduleDTO = ModuleDTO.builder()
				.build();
		Map<String, Object> metadata = Map.of(WORKFLOW_CLOSED_KEY, "invalid value");

		when(applicationsCrudService.findWithDetailsByApplicationId(TENANT_1, APPLICATION_ID_1))
				.thenReturn(applicationWithDetailsDTO);
		when(moduleDetailsCrudService.findByModuleId(TENANT_1, applicationWithDetailsDTO.getModuleId()))
				.thenReturn(moduleDetailsDto);
		when(sc.isUserInRole(CONTEXT_FUNCTION))
				.thenReturn(true);
		when(moduleCrudService.findById(applicationWithDetailsDTO.getModuleId()))
				.thenReturn(Optional.of(moduleDTO));
		when(applicationsWorkflowService.getNodeMetadata(TENANT_1, moduleDTO.getWorkflowCode(),
				applicationWithDetailsDTO.getProcessStatus()))
						.thenReturn(metadata);

		assertThrows(IllegalStateException.class, () -> applicationsService.isApplicationClosed(TENANT_1, APPLICATION_ID_1, logged_user1, sc));
	}

	@Test
	void test_isApplicationClosed_false_ok() {
		ModuleDTO moduleDTO = ModuleDTO.builder()
				.build();
		Map<String, Object> emptyMetadata = Map.of();

		when(applicationsCrudService.findWithDetailsByApplicationId(TENANT_1, APPLICATION_ID_1))
				.thenReturn(applicationWithDetailsDTO);
		when(moduleDetailsCrudService.findByModuleId(TENANT_1, applicationWithDetailsDTO.getModuleId()))
				.thenReturn(moduleDetailsDto);
		when(sc.isUserInRole(CONTEXT_FUNCTION))
				.thenReturn(true);
		when(moduleCrudService.findById(applicationWithDetailsDTO.getModuleId()))
				.thenReturn(Optional.of(moduleDTO));
		when(applicationsWorkflowService.getNodeMetadata(TENANT_1, moduleDTO.getWorkflowCode(),
				applicationWithDetailsDTO.getProcessStatus()))
						.thenReturn(emptyMetadata);

		boolean result = applicationsService.isApplicationClosed(TENANT_1, APPLICATION_ID_1, logged_user1, sc);

		assertFalse(result);
	}

	@Test
	void test_findReadOnly_applicationNotClosed_ok() {
		ModuleFormConfigsDTO moduleFormConfig = ModuleFormConfigsDTO.builder()
				.compileStatusIdentifier(APPLICATION_COMPILE_STATUS_IDENTIFIER_1)
				.formId(FORM_ID_1)
				.formGroupId(FORM_GROUP_ID_1)
				.flReadOnly(1)
				.build();

		ReadOnlyDto expectedOutput = ReadOnlyDto.builder()
				.readOnly(true)
				.build();

		try {
			when(applicationsCrudService.findWithDetailsByApplicationId(TENANT_1, APPLICATION_ID_1))
					.thenReturn(applicationWithDetailsDTO);
			when(applicationDetailsCrudService.findApplicationDetailById(TENANT_1, APPLICATION_ID_1))
					.thenReturn(applicationDetailsDTONotInTransition);
			when(moduleDetailsCrudService.findByModuleId(TENANT_1, applicationWithDetailsDTO.getModuleId()))
					.thenReturn(ModuleDetailsDTO.builder().build());
			when((applicationsWorkflowService.getProcessStatusDescription(TENANT_1, PROCESS_ID_1, logged_user1)))
					.thenReturn(PROCESS_STATUS_DESCRIPTION);
			when(moduleCrudService.findById(applicationWithDetailsDTO.getModuleId()))
					.thenReturn(Optional.of(ModuleDTO.builder().moduleCode(MODULE_CODE).moduleId(MODULE_ID_1).build()));
			when(moduleFormConfigsCrudService.findById(TENANT_1, MODULE_FORM_CONFIG_ID_1))
					.thenReturn(moduleFormConfig);

			ReadOnlyDto result = applicationsService.findReadOnly(TENANT_1, APPLICATION_ID_1, MODULE_FORM_CONFIG_ID_1, logged_user1, sc);

			assertEquals(expectedOutput, result);
		} catch (Exception e) {
			fail(e);
		}
	}

	@Test
	void test_findReadOnly_application_in_transition_ok() {
		Map<String, Object> metadata = Map.of(WORKFLOW_CLOSED_KEY, true);
		ModuleDTO moduleDTO = ModuleDTO.builder()
				.moduleCode(MODULE_CODE)
				.moduleId(MODULE_ID_1)
				.build();

		ReadOnlyDto expectedOutput = ReadOnlyDto.builder()
				.readOnly(true)
				.build();

		try {
			when(applicationsCrudService.findWithDetailsByApplicationId(TENANT_1, APPLICATION_ID_1))
					.thenReturn(applicationWithDetailsDTO);
			when(applicationDetailsCrudService.findApplicationDetailById(TENANT_1, APPLICATION_ID_1))
					.thenReturn(applicationDetailsDTOInTransition);
			when(moduleDetailsCrudService.findByModuleId(TENANT_1, applicationWithDetailsDTO.getModuleId()))
					.thenReturn(ModuleDetailsDTO.builder().build());
			when((applicationsWorkflowService.getProcessStatusDescription(TENANT_1, PROCESS_ID_1, logged_user1)))
					.thenReturn(PROCESS_STATUS_DESCRIPTION);
			when(moduleCrudService.findById(applicationWithDetailsDTO.getModuleId()))
					.thenReturn(Optional.of(moduleDTO));
			when(applicationsWorkflowService.getNodeMetadata(TENANT_1, moduleDTO.getWorkflowCode(),
					applicationWithDetailsDTO.getProcessStatus()))
							.thenReturn(metadata);

			ReadOnlyDto result = applicationsService.findReadOnly(TENANT_1, APPLICATION_ID_1, MODULE_FORM_CONFIG_ID_1, logged_user1, sc);

			assertEquals(expectedOutput, result);
		} catch (Exception e) {
			fail(e);
		}
	}

	@Test
	void test_findReadOnly_applicationClosed_ok() {
		Map<String, Object> metadata = Map.of(WORKFLOW_CLOSED_KEY, true);
		ModuleDTO moduleDTO = ModuleDTO.builder()
				.moduleCode(MODULE_CODE)
				.moduleId(MODULE_ID_1)
				.build();

		ReadOnlyDto expectedOutput = ReadOnlyDto.builder()
				.readOnly(true)
				.build();

		try {
			when(applicationsCrudService.findWithDetailsByApplicationId(TENANT_1, APPLICATION_ID_1))
					.thenReturn(applicationWithDetailsDTO);
			when(applicationDetailsCrudService.findApplicationDetailById(TENANT_1, APPLICATION_ID_1))
					.thenReturn(applicationDetailsDTONotInTransition);
			when(moduleDetailsCrudService.findByModuleId(TENANT_1, applicationWithDetailsDTO.getModuleId()))
					.thenReturn(ModuleDetailsDTO.builder().build());
			when((applicationsWorkflowService.getProcessStatusDescription(TENANT_1, PROCESS_ID_1, logged_user1)))
					.thenReturn(PROCESS_STATUS_DESCRIPTION);
			when(moduleCrudService.findById(applicationWithDetailsDTO.getModuleId()))
					.thenReturn(Optional.of(moduleDTO));
			when(applicationsWorkflowService.getNodeMetadata(TENANT_1, moduleDTO.getWorkflowCode(),
					applicationWithDetailsDTO.getProcessStatus()))
							.thenReturn(metadata);

			ReadOnlyDto result = applicationsService.findReadOnly(TENANT_1, APPLICATION_ID_1, MODULE_FORM_CONFIG_ID_1, logged_user1, sc);

			assertEquals(expectedOutput, result);
		} catch (Exception e) {
			fail(e);
		}
	}

	@Test
	void test_deleteCompileStatus_ok() {
		ApplicationCompileStatusDTO compileStatus = ApplicationCompileStatusDTO.builder()
				.pkid(PK_ID_1)
				.status(APPLICATION_COMPILE_STATUS_1)
				.applicationId(APPLICATION_ID_1)
				.compileStatusIdentifier(APPLICATION_COMPILE_STATUS_IDENTIFIER_1)
				.build();

		try {
			when(applicationCompileStatusCrudService.findByCompileStatusIdentifier(TENANT_1, APPLICATION_ID_1,
					APPLICATION_COMPILE_STATUS_IDENTIFIER_1))
							.thenReturn(compileStatus);

			applicationsService.deleteCompileStatus(TENANT_1, APPLICATION_ID_1, APPLICATION_COMPILE_STATUS_IDENTIFIER_1, USER_1);

			verify(applicationsCrudService, times(1)).findById(TENANT_1, APPLICATION_ID_1);
			verify(applicationCompileStatusCrudService, times(1)).delete(PK_ID_1, USER_1);
		} catch (Exception e) {
			fail(e);
		}
	}

	@Test
	void test_getAvailableTransitionListByProcessId_ok() {
		ApplicationDTO applicationDTO = ApplicationDTO.builder()
				.processId(PROCESS_ID_1)
				.partyId(PARTY_ID_1)
				.applicationId(APPLICATION_ID_1)
				.referredYear(YEAR_1)
				.moduleId(MODULE_ID_1)
				.build();

		List<String> tags = List.of("Tag - 1", "Tag - 2", "Tag - 3", "Tag - 4");
		List<Transition> expectedOutput = List.of(Transition.builder()
				.scope(SCOPE)
				.id(TRANSITION_ID)
				.notesRequired(false)
				.fromNode(NODE_FROM)
				.toNode(NODE_TO)
				.tags(tags)
				.build());

		try {
			when(applicationsCrudService.findById(TENANT_1, APPLICATION_ID_1))
					.thenReturn(applicationDTO);
			when(applicationsWorkflowService.getUserAvailableTransitions(TENANT_1, APPLICATION_ID_1, PROCESS_ID_1, logged_user1, SCOPE))
					.thenReturn(expectedOutput);

			List<Transition> result = applicationsService.getAvailableTransitionListByProcessId(TENANT_1, APPLICATION_ID_1, logged_user1, SCOPE);

			assertEquals(expectedOutput, result);
		} catch (Exception e) {
			fail(e);
		}
	}

	@Test
	void test_checkForOngoingPrints_ok() {
		List<ApplicationGeneratedPrintDTO> applicationGeneratedPrintDTOs = List.of(ApplicationGeneratedPrintDTO.builder()
				.build());
		List<String> printCodes = List.of(PRINT_CODE_1);

		when(applicationGeneratedPrintCrudService.findOngoingPrintByCode(TENANT_1, APPLICATION_ID_1, PRINT_CODE_1))
				.thenReturn(applicationGeneratedPrintDTOs);

		List<ApplicationGeneratedPrintDTO> result = applicationsService.checkForOngoingPrints(TENANT_1, APPLICATION_ID_1, printCodes);

		assertEquals(applicationGeneratedPrintDTOs, result);
	}

	@Test
	void test_getApplicationInTransition_withProcessId_ok() {
		try {
			ApplicationDTO applicationDTO = ApplicationDTO.builder()
					.moduleId(MODULE_ID_1)
					.applicationId(APPLICATION_ID_1)
					.referredYear(YEAR_1)
					.partyId(PARTY_ID_1)
					.processId(PROCESS_ID_1)
					.build();
			ApplicationDetailsDTO applicationDetailsDTO = ApplicationDetailsDTO.builder()
					.applicationCode(APPLICATION_CODE_1)
					.applicationId(APPLICATION_ID_1)
					.dtDelete(DEFAULT_NOT_DELETED_DATE)
					.dtInsert(NOW)
					.pkid(APPLICATION_DETAILS_ID_1)
					.processStatus(PROCESS_STATUS)
					.userIdInsert(USER_1)
					.flInTransition(1)
					.build();

			WorLogTransitionWithDetailsEntity ntt = new WorLogTransitionWithDetailsEntity();
			ntt.setIs_failed(0);
			ntt.setFrom(new WorLogTransitionWithDetailsEntity.Node());
			ntt.setTo(new WorLogTransitionWithDetailsEntity.Node());
			ntt.setMessages(JsonToken.VALUE_NULL.asString());
			AuthContext authContext = new AuthContextTestSupport();
			DetailedTransitionLog log = new DetailedTransitionLog(ntt, authContext, Jackson.newObjectMapper());
			List<DetailedSdkTransitionLog> detailedTransitionLogs = List.of(DetailLogMapper.INSTANCE.entityToDto(log));

			ApplicationInTransitionDTO expectedOutput = ApplicationInTransitionDTO.builder()
					.inTransition(true)
					.lastTransitionLog(detailedTransitionLogs.get(0))
					.build();

			when(applicationsCrudService.findByIdAlsoExpired(TENANT_1, APPLICATION_ID_1))
					.thenReturn(applicationDTO);
			when(applicationDetailsCrudService.findApplicationDetailByIdAlsoExpired(TENANT_1, APPLICATION_ID_1))
					.thenReturn(applicationDetailsDTO);
			when(historyService.getApplicationHistoryByApplicationId(TENANT_1, APPLICATION_ID_1, logged_user1))
					.thenReturn(List.of(log));

			ApplicationInTransitionDTO result = applicationsService.getApplicationInTransition(TENANT_1, APPLICATION_ID_1, logged_user1);

			assertEquals(expectedOutput, result);
		} catch (Exception e) {
			fail(e);
		}
	}

	@Test
	void test_getApplicationInTransition_withoutProcessId_ok() {
		try {
			ApplicationDTO applicationDTO = ApplicationDTO.builder()
					.moduleId(MODULE_ID_1)
					.applicationId(APPLICATION_ID_1)
					.referredYear(YEAR_1)
					.partyId(PARTY_ID_1)
					.build();

			ApplicationInTransitionDTO expectedOutput = ApplicationInTransitionDTO.builder()
					.inTransition(true)
					.build();

			when(applicationsCrudService.findByIdAlsoExpired(TENANT_1, APPLICATION_ID_1))
					.thenReturn(applicationDTO);

			ApplicationInTransitionDTO result = applicationsService.getApplicationInTransition(TENANT_1, APPLICATION_ID_1, logged_user1);

			assertEquals(expectedOutput, result);
		} catch (Exception e) {
			fail(e);
		}
	}

	@Test
	void test_getApplicationInTransition_withoutProcessId_ko() {
		try {
			when(applicationsCrudService.findByIdAlsoExpired(TENANT_1, APPLICATION_ID_1))
					.thenThrow(ObjectNotFoundException.class);

			assertThrows(ApplicationNotFoundRuntimeException.class,
					() -> applicationsService.getApplicationInTransition(TENANT_1, APPLICATION_ID_1, logged_user1));
		} catch (Exception e) {
			fail(e);
		}
	}

	@Test
	void test_checkForMetadata_ObjectNotFoundRuntimeException() {
		when(moduleCrudService.findByCode(TENANT_1, MODULE_CODE))
				.thenReturn(Optional.empty());

		assertThrows(ObjectNotFoundRuntimeException.class, () -> applicationsService.checkForMetadata(TENANT_1, MODULE_CODE, PROCESS_STATUS_1));

	}

	@Test
	void test_getAvailableTransitionListByProcessId_ko() {
		try {
			when(applicationsCrudService.findById(TENANT_1, APPLICATION_ID_1))
					.thenThrow(ObjectNotFoundException.class);

			assertThrows(ApplicationNotFoundRuntimeException.class,
					() -> applicationsService.getAvailableTransitionListByProcessId(TENANT_1, APPLICATION_ID_1, logged_user1, SCOPE));
		} catch (Exception e) {
			fail(e);
		}
	}

	// @Test
	// void test_deleteCompileStatus_ko() {
	// try {
	// doThrow(ObjectNotFoundException.class)
	// .when(applicationsCrudService).findById(TENANT_1, APPLICATION_ID_1);
	//
	// assertThrows(ApplicationNotFoundRuntimeException.class,
	// () -> applicationsService.deleteCompileStatus(TENANT_1, APPLICATION_ID_1, APPLICATION_COMPILE_STATUS_IDENTIFIER_1,
	// USER_1));
	// } catch (Exception e) {
	// fail(e);
	// }
	// }

	@Test
	void test_findReadOnly_ko() {
		try {
			when(applicationsCrudService.findWithDetailsByApplicationId(TENANT_1, APPLICATION_ID_1))
					.thenReturn(applicationWithDetailsDTO);
			when(applicationDetailsCrudService.findApplicationDetailById(TENANT_1, APPLICATION_ID_1))
					.thenReturn(applicationDetailsDTONotInTransition);
			when(moduleDetailsCrudService.findByModuleId(TENANT_1, applicationWithDetailsDTO.getModuleId()))
					.thenReturn(ModuleDetailsDTO.builder().build());
			when((applicationsWorkflowService.getProcessStatusDescription(TENANT_1, PROCESS_ID_1, logged_user1)))
					.thenReturn(PROCESS_STATUS_DESCRIPTION);
			when(moduleCrudService.findById(applicationWithDetailsDTO.getModuleId()))
					.thenReturn(Optional.of(ModuleDTO.builder().moduleCode(MODULE_CODE).moduleId(MODULE_ID_1).build()));
			when(moduleFormConfigsCrudService.findById(TENANT_1, MODULE_FORM_CONFIG_ID_1))
					.thenThrow(ObjectNotFoundException.class);

			assertThrows(ObjectNotFoundRuntimeException.class,
					() -> applicationsService.findReadOnly(TENANT_1, APPLICATION_ID_1, MODULE_FORM_CONFIG_ID_1, logged_user1, sc));
		} catch (Exception e) {
			fail(e);
		}
	}

	@Test
	void test_checkForMetadata_ko() {
		when(applicationsCrudService.findWithDetailsByApplicationCode(TENANT_1, APPLICATION_CODE))
				.thenReturn(applicationWithDetailsDTO);
		when(moduleCrudService.findById(applicationWithDetailsDTO.getModuleId()))
				.thenReturn(Optional.empty());

		assertThrows(ObjectNotFoundRuntimeException.class, () -> applicationsService.checkForMetadata(TENANT_1, APPLICATION_CODE));
	}

	@Test
	void test_checkCanReadByAppId_ko() {
		when(applicationsCrudService.findWithDetailsByApplicationId(TENANT_1, APPLICATION_ID_1)).thenReturn(applicationWithDetailsDTO);

		applicationsService.checkCanReadByAppId(TENANT_1, APPLICATION_ID_1, logged_user1);

		verify(checkPartyService, times(1)).checkCanReadParty(TENANT_1, PARTY_ID_1, logged_user1);
	}

	@Test
	void test_progress_ok() {

		try {
			when(applicationsCrudService.findById(TENANT_1, APPLICATION_ID_1)).thenReturn(applicationDTO);

			applicationsService.progress(TENANT_1, APPLICATION_ID_1, TAG_NAME, logged_user1, SCOPE, progressApplicationDTO, ProgressTypeEnum.ASYNC);

			verify(checkPartyService, times(1)).checkCanReadParty(TENANT_1, PARTY_ID_1, logged_user1);
			verify(progressService, times(1))
					.progress(TENANT_1, APPLICATION_ID_1, TAG_NAME, logged_user1, SCOPE, progressApplicationDTO, ProgressTypeEnum.ASYNC);
		} catch (Exception e) {
			fail(e);
		}

	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Test
	void test_progress2_ok() {

		try {

			ArgumentCaptor<HandleConsumer> handleConsumerArgumentCaptor = ArgumentCaptor.forClass(HandleConsumer.class);

			when(applicationsCrudService.findById(TENANT_1, APPLICATION_ID_1)).thenReturn(applicationDTO);

			applicationsService.progress(TENANT_1, APPLICATION_ID_1, TRANSITION_ID, logged_user1, SCOPE, progressApplicationDTO, ProgressTypeEnum.ASYNC);

			verify(checkPartyService, times(1)).checkCanReadParty(TENANT_1, PARTY_ID_1, logged_user1);

			verify(jdbi).useTransaction(handleConsumerArgumentCaptor.capture());
			handleConsumerArgumentCaptor.getValue().useHandle(handle);

			verify(progressService, times(1))
					.progress(TENANT_1, APPLICATION_ID_1, TRANSITION_ID, logged_user1, SCOPE, progressApplicationDTO, ProgressTypeEnum.ASYNC);

		} catch (Exception e) {
			fail(e);
		}

	}

	@Test
	void test_getModuleFormConfigsByModuleCode_ok() {

		when(formConfigService.findModuleFormConfigsByModuleCode(TENANT_1, MODULE_CODE)).thenReturn(moduleWithParamsPublicDTO);

		assertEquals(moduleWithParamsPublicDTO,
				applicationsService.getModuleFormConfigsByModuleCode(TENANT_1, MODULE_CODE));

	}

}
