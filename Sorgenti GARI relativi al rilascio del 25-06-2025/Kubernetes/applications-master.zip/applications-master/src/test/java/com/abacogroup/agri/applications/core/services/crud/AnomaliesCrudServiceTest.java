package com.abacogroup.agri.applications.core.services.crud;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.fail;
import static org.mockito.Mockito.lenient;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.time.LocalDateTime;
import java.time.Month;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.Optional;

import org.jdbi.v3.sqlobject.transaction.TransactionalCallback;
import org.jdbi.v3.sqlobject.transaction.TransactionalConsumer;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.slf4j.MDC;

import com.abacogroup.agri.applications.core.exceptions.ObjectNotFoundException;
import com.abacogroup.agri.applications.core.mappers.AnomalyMapper;
import com.abacogroup.agri.applications.core.model.dto.publics.AnomalyDTO;
import com.abacogroup.agri.applications.db.dao.AnomalyDAO;
import com.abacogroup.agri.applications.db.ntt.AnomalyNTT;
import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.jaxrsutils.filter.MDCPreFilter;

@ExtendWith(MockitoExtension.class)
class AnomaliesCrudServiceTest {
	@Mock
	private AnomalyDAO anomalyDAOMock;
	@Mock
	private AnomalyMapper anomalyMapperMock;
	@InjectMocks
	private AnomaliesCrudService anomaliesCrudService;

	private static final String TENANT = "tenant";
	private static final Long APPLICATION_ID = 5L;
	private static final Long PKID = 1L;
	private static final String USERNAME = "Username";
	private static final User USER = new User(USERNAME, TENANT);
	private static final String ANOMALY_CODE = "anomaly code";
	private static final String ANOMALY_DESCRIPTION = "anomaly description";
	private static final String SEVERITY = "severity";
	private static final LocalDateTime DT_INSERT = LocalDateTime.of(2014, Month.SEPTEMBER, 27, 18, 0);
	private static final LocalDateTime DT_DELETE = LocalDateTime.MAX;
	private static final LocalDateTime DT_INSERT_MINUS_1_MILLI = DT_INSERT.minus(1, ChronoUnit.MILLIS);

	private final AnomalyNTT anomalyNTT = AnomalyNTT.builder()
			.anomaly_code(ANOMALY_CODE)
			.anomaly_desc(ANOMALY_DESCRIPTION)
			.severity(SEVERITY)
			.pkid(PKID)
			.application_id(APPLICATION_ID)
			.dt_insert(DT_INSERT)
			.dt_delete(DT_DELETE)
			.user_id_insert(USERNAME)
			.build();
	private final AnomalyDTO anomalyDTO = AnomalyDTO.builder()
			.pkid(PKID)
			.applicationId(APPLICATION_ID)
			.anomalyCode(ANOMALY_CODE)
			.anomalyDesc(ANOMALY_DESCRIPTION)
			.severity(SEVERITY)
			.dtInsert(DT_INSERT)
			.build();

	@BeforeEach
	void beforeEach() {
		lenient().when(anomalyDAOMock.getCurrentTimestamp()).thenAnswer($ -> LocalDateTime.now());
	}

	@Test
	void hasPrimaryKey() {
		assertTrue(anomaliesCrudService.hasPrimaryKey());
	}

	@Test
	void retrieveCustomKeyByResultSet_ok() {
		assertNull(anomaliesCrudService.retrieveCustomKeyByResultSet(anomalyNTT));
	}

	@Test
	void adjustR_ok() {
		assertEquals(anomalyNTT, anomaliesCrudService.adjustR(anomalyNTT));
	}

	@Test
	void findRsByCustomKey_ok() {
		assertEquals(Optional.empty(), anomaliesCrudService.findRsByCustomKey(null));
	}

	@Test
	void findById_ok() {
		try {
			when(anomalyDAOMock.findById(PKID))
					.thenReturn(List.of(anomalyNTT));
			when(anomalyMapperMock.entityToDto(anomalyNTT))
					.thenReturn(anomalyDTO);

			AnomalyDTO result = anomaliesCrudService.findById(PKID);

			assertEquals(anomalyDTO, result);
		} catch (Exception e) {
			fail(e);
		}
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Test
	void insert_ok() {
		AnomalyDTO payload = AnomalyDTO.builder()
				.applicationId(APPLICATION_ID)
				.anomalyCode(ANOMALY_CODE)
				.anomalyDesc(ANOMALY_DESCRIPTION)
				.severity(SEVERITY)
				.build();

		try {
			ArgumentCaptor<TransactionalCallback> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(TransactionalCallback.class);

			when(anomalyDAOMock.nextSequenceVal())
					.thenReturn(PKID);
			when(anomalyDAOMock.getCurrentTimestamp())
					.thenReturn(DT_INSERT);
			when(anomalyMapperMock.dtoToEntity(payload))
					.thenReturn(anomalyNTT);
			when(anomalyMapperMock.entityToDto(anomalyNTT))
					.thenReturn(anomalyDTO);
			when(anomalyDAOMock.findById(PKID))
					.thenReturn(List.of(anomalyNTT));

			anomaliesCrudService.insert(payload, USERNAME);

			verify(anomalyDAOMock).inTransaction(handleConsumerLambdaCaptor.capture());

			AnomalyDTO result = (AnomalyDTO) handleConsumerLambdaCaptor.getValue().inTransaction(anomalyDAOMock);

			assertEquals(anomalyDTO, result);

		} catch (Exception e) {
			fail(e);
		}

	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Test
	void update_ok() {
		AnomalyDTO payload = AnomalyDTO.builder()
				.applicationId(APPLICATION_ID)
				.anomalyCode(ANOMALY_CODE)
				.anomalyDesc(ANOMALY_DESCRIPTION)
				.severity(SEVERITY)
				.build();

		try {
			ArgumentCaptor<TransactionalCallback> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(TransactionalCallback.class);

			when(anomalyDAOMock.getCurrentTimestamp())
					.thenReturn(DT_INSERT);
			when(anomalyDAOMock.inTransaction(handleConsumerLambdaCaptor.capture()))
					.thenReturn(anomalyDTO);

			anomaliesCrudService.update(PKID, payload, USERNAME);

			verify(anomalyDAOMock).inTransaction(handleConsumerLambdaCaptor.capture());
			AnomalyDTO result = (AnomalyDTO) handleConsumerLambdaCaptor.getValue().inTransaction(anomalyDAOMock);

			assertEquals(anomalyDTO, result);
		} catch (Exception e) {
			fail(e);
		}
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Test
	void delete_ok() {
		try {
			ArgumentCaptor<TransactionalConsumer> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(TransactionalConsumer.class);

			when(anomalyDAOMock.getCurrentTimestamp())
					.thenReturn(DT_INSERT);

			anomaliesCrudService.delete(PKID, USERNAME);

			verify(anomalyDAOMock).useTransaction(handleConsumerLambdaCaptor.capture());
			handleConsumerLambdaCaptor.getValue().useTransaction(anomalyDAOMock);

			verify(anomalyDAOMock).logicallyDeleteById(PKID, USER.getUserId(), DT_INSERT_MINUS_1_MILLI);
		} catch (Exception e) {
			fail(e);
		}
	}

	@Test
	void find_withoutAnomalyCode_ok() {
		when(anomalyDAOMock.find(TENANT, APPLICATION_ID, MDC.get(MDCPreFilter.LOCALE)))
				.thenReturn(List.of(anomalyNTT));
		when(anomalyMapperMock.entityToDto(anomalyNTT))
				.thenReturn(anomalyDTO);

		List<AnomalyDTO> result = anomaliesCrudService.find(TENANT, APPLICATION_ID);

		assertEquals(List.of(anomalyDTO), result);
	}

	@Test
	void find_withAnomalyCode_ok() {
		when(anomalyDAOMock.find(TENANT, APPLICATION_ID, ANOMALY_CODE, MDC.get(MDCPreFilter.LOCALE)))
				.thenReturn(List.of(anomalyNTT));
		when(anomalyMapperMock.entityToDto(anomalyNTT))
				.thenReturn(anomalyDTO);

		Optional<AnomalyDTO> result = anomaliesCrudService.find(TENANT, APPLICATION_ID, ANOMALY_CODE);

		assertEquals(Optional.of(anomalyDTO), result);
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Test
	void deleteByAnomalyCode_ok() {
		try {
			ArgumentCaptor<TransactionalConsumer> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(TransactionalConsumer.class);

			when(anomalyDAOMock.getCurrentTimestamp())
					.thenReturn(DT_INSERT);
			when(anomalyDAOMock.findWithoutJoiningCatalog(TENANT, APPLICATION_ID, ANOMALY_CODE, MDC.get(MDCPreFilter.LOCALE)))
					.thenReturn(List.of(anomalyNTT));
			when(anomalyMapperMock.entityToDto(anomalyNTT))
					.thenReturn(anomalyDTO);

			anomaliesCrudService.deleteByAnomalyCode(TENANT, APPLICATION_ID, ANOMALY_CODE, USERNAME);

			verify(anomalyDAOMock).useTransaction(handleConsumerLambdaCaptor.capture());
			handleConsumerLambdaCaptor.getValue().useTransaction(anomalyDAOMock);

			verify(anomalyDAOMock).logicallyDeleteById(PKID, USER.getUserId(), DT_INSERT_MINUS_1_MILLI);
		} catch (Exception e) {
			fail(e);
		}

	}

	@Test
	void findById_ko() {
		try {
			when(anomalyDAOMock.findById(PKID))
					.thenReturn(List.of());

			assertThrows(ObjectNotFoundException.class, () -> anomaliesCrudService.findById(PKID));
		} catch (Exception e) {
			fail(e);
		}
	}
}
