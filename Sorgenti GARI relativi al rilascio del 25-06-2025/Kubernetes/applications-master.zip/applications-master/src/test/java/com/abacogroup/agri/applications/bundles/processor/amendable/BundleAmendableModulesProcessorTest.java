package com.abacogroup.agri.applications.bundles.processor.amendable;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.fail;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.verify;

import java.io.File;
import java.nio.file.Path;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.abacogroup.agri.applications.bundles.model.amendable.BundleAmendableModuleInDTO;
import com.abacogroup.agri.applications.bundles.model.amendable.BundleAmendableModulesMessage;
import com.abacogroup.bundles.listener.configdata.ConfigDataMessage;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@ExtendWith(MockitoExtension.class)
class BundleAmendableModulesProcessorTest {
	@Mock
	private AmendableModulesBundleWorker amendableModulesBundleWorker;
	@Mock
	private ObjectMapper objectMapper;

	private static final String TEMPLATE_TENANT_ID = "*";
	private static final String DOMAIN_NAME = "amendable-modules";
	private static final String AMENDABLE_MODULE_CODE = "AMENDABLE_MODULE_CODE";
	private static final String MODULE_CODE = "MODULE_CODE";

	private static final Path PATH = new File("test.json").toPath();

	private final BundleAmendableModuleInDTO bundleAmendableModuleInDTO = BundleAmendableModuleInDTO.builder()
			.amendableModuleCode(AMENDABLE_MODULE_CODE)
			.moduleCode(MODULE_CODE)
			.build();

	private final BundleAmendableModulesMessage bundleModulesMessageMock = BundleAmendableModulesMessage.builder()
			.amendableModules(List.of(bundleAmendableModuleInDTO))
			.build();

	@InjectMocks
	private BundleAmendableModulesProcessor bundleAmendableModulesProcessor;

	@Test
	void test_getDomainName() {
		assertEquals(DOMAIN_NAME, bundleAmendableModulesProcessor.getDomainName());
	}

	@Test
	void test_getTypeReference() {
		assertEquals(new TypeReference<BundleAmendableModulesMessage>() {
		}.getType(), bundleAmendableModulesProcessor.getTypeReference().getType());
	}

	@SuppressWarnings("unchecked")
	@Test
	void onMessageInTransaction() {
		try {
			ConfigDataMessage message = new ConfigDataMessage();
			message.setTenantId(TEMPLATE_TENANT_ID);
			message.setConfigFiles(List.of(PATH));

			bundleAmendableModulesProcessor.onMessageInTransaction(message);

			verify(objectMapper).readValue(eq(PATH.toFile()), any(TypeReference.class));
		} catch (Exception e) {
			fail(e.getMessage(), e);
		}
	}

	@Test
	void test_doInsertOrUpdate() {
		bundleAmendableModulesProcessor.doInsertOrUpdate(TEMPLATE_TENANT_ID, bundleModulesMessageMock);
		verify(amendableModulesBundleWorker).upsertBundleModules(TEMPLATE_TENANT_ID, bundleModulesMessageMock);
	}

	@Test
	void test_delete() {
		bundleAmendableModulesProcessor.delete(TEMPLATE_TENANT_ID, bundleModulesMessageMock);
		verify(amendableModulesBundleWorker).deleteBundleAmendableModules(TEMPLATE_TENANT_ID, bundleModulesMessageMock);
	}
}
