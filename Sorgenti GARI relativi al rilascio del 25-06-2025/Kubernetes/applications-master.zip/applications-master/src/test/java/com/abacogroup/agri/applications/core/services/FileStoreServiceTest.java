package com.abacogroup.agri.applications.core.services;

import com.abacogroup.agri.applications.core.exceptions.FileStoreIORuntimeException;
import com.abacogroup.agri.applications.core.exceptions.FileStoreMetadataNotFoundException;
import com.abacogroup.agri.applications.core.model.dto.FileDTO;
import com.abacogroup.agri.applications.core.model.dto.SavedFileDTO;
import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.filestore.client.FileStoreClient;
import com.abacogroup.filestore.client.auth.Authenticator;
import com.abacogroup.filestore.client.response.AddFileResponse;
import com.abacogroup.filestore.client.response.FileMetadata;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URI;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

/**
 * The type File store service test.
 * @author Carlo Sindico
 */
@Slf4j
@ExtendWith(MockitoExtension.class)
class FileStoreServiceTest {

    private static final String TENANT = "tenant";

    private static final String FILE_ID = "file_id";

    private static final String FILE_RESPONSE_ID = "file_response_id";

    private static final String FILE_NAME = "file_name";

    private static final String BUCKET_ID = "bucket_id";

    private final FileDTO fileDTOMock = FileDTO.builder()
            .id(FILE_ID)
            .name(FILE_NAME)
            .bucketId(BUCKET_ID)
            .build();

    private final User userMock = new User(TENANT, "name");


    @Mock
    private FileStoreClient fileStoreClient;

    @InjectMocks
    private FileStoreService fileStoreService;

    @BeforeEach
    void init() {
        fileStoreService = new FileStoreService(fileStoreClient);
    }

    @Test
    void test_getFile() {
        FileMetadata fileMetadataMock = mock(FileMetadata.class);
        Authenticator authenticatorMock = mock(Authenticator.class);
        try {
            when(fileStoreClient.getFileMetadata(authenticatorMock, TENANT, BUCKET_ID, FILE_ID)).thenReturn(fileMetadataMock);


            FileDTO result = fileStoreService.getFile(TENANT, FILE_ID, BUCKET_ID, userMock, authenticatorMock);

            Assertions.assertEquals(fileDTOMock.getId(), result.getId());
            Assertions.assertEquals(fileDTOMock.getBucketId(), result.getBucketId());
        } catch (FileStoreMetadataNotFoundException | IOException e) {
            fail(e);
        }
    }

    @Test
    void test_saveFile_ok() {
        Authenticator authenticatorMock = mock(Authenticator.class);
        byte[] bytes = new byte[] {0x12, (byte) 0xF2};
        InputStream inputStream = new ByteArrayInputStream(bytes);
        AddFileResponse addFileResponse = new AddFileResponse();
        addFileResponse.setId(FILE_RESPONSE_ID);

        SavedFileDTO expectedOutput = SavedFileDTO.builder()
                .fileId(FILE_RESPONSE_ID)
                .build();

        try {
            when(fileStoreClient.addFile(any(), eq(TENANT), eq(BUCKET_ID), any(), eq(inputStream)))
                    .thenReturn(addFileResponse);

            SavedFileDTO result = fileStoreService.saveFile(TENANT, BUCKET_ID, inputStream, FILE_NAME, userMock, authenticatorMock);

            assertEquals(expectedOutput, result);
        } catch (Exception e) {
            fail(e);
        }
    }

    @Test
    void test_saveFile_ko() {
        Authenticator authenticatorMock = mock(Authenticator.class);
        byte[] bytes = new byte[] {0x12, (byte) 0xF2};
        InputStream inputStream = new ByteArrayInputStream(bytes);
        AddFileResponse addFileResponse = new AddFileResponse();
        addFileResponse.setId(FILE_RESPONSE_ID);

        try {
            when(fileStoreClient.addFile(any(), eq(TENANT), eq(BUCKET_ID), any(), eq(inputStream)))
                    .thenThrow(IOException.class);

            assertThrows(FileStoreIORuntimeException.class, () ->
                    fileStoreService.saveFile(TENANT, BUCKET_ID, inputStream, FILE_NAME, userMock, authenticatorMock));
        } catch (Exception e) {
            fail(e);
        }
    }

    @Test
    void test_deleteFile() {
        Authenticator authenticatorMock = mock(Authenticator.class);
        try {
            fileStoreService.deleteFile(TENANT, FILE_ID, BUCKET_ID, userMock, authenticatorMock);
        } catch (Exception e) {
            fail(e);
        }
    }
    
    @Test
    void test_getFileForDownload_ko() {
        Authenticator authenticatorMock = mock(Authenticator.class);
        URI uri = URI.create("invalid-uri");

        when(fileStoreClient.jaxrs())
                .thenReturn(new FileStoreClient(uri, null).jaxrs());

        assertThrows(FileStoreIORuntimeException.class, () ->
                fileStoreService.getFileForDownload(TENANT, FILE_ID, BUCKET_ID, FILE_NAME, userMock, authenticatorMock));
    }

    @Test
    void test_getFile_FileStoreIORuntimeException() {
        FileMetadata fileMetadataMock = mock(FileMetadata.class);
        Authenticator authenticatorMock = mock(Authenticator.class);
        try {
            when(fileStoreClient.getFileMetadata(authenticatorMock, TENANT, BUCKET_ID, FILE_ID))
                    .thenReturn(fileMetadataMock);
            doThrow(IOException.class).when(fileStoreClient)
                    .getFileContent(eq(authenticatorMock), eq(TENANT), eq(BUCKET_ID), eq(FILE_ID), any());

            assertThrows(FileStoreIORuntimeException.class, () ->
                    fileStoreService.getFile(TENANT, FILE_ID, BUCKET_ID, userMock, authenticatorMock));
        } catch (Exception e) {
            fail(e);
        }
    }

    @Test
    void test_getFile_FileStoreMetadataNotFoundException() {
        try {
            Authenticator authenticatorMock = mock(Authenticator.class);
            when(fileStoreClient.getFileMetadata(authenticatorMock, TENANT, BUCKET_ID, FILE_ID))
                    .thenReturn(null);


            assertThrows(FileStoreMetadataNotFoundException.class, () ->
                    fileStoreService.getFile(TENANT, FILE_ID, BUCKET_ID, userMock, authenticatorMock));
        } catch (Exception e) {
            fail(e);
        }
    }

}
