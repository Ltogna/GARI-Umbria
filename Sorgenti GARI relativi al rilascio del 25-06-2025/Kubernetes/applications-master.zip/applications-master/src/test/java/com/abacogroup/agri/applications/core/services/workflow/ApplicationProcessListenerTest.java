package com.abacogroup.agri.applications.core.services.workflow;

import com.abacogroup.agri.applications.core.exceptions.ObjectNotFoundException;
import com.abacogroup.agri.applications.core.model.ProcessTransitionEnum;
import com.abacogroup.agri.applications.core.services.crud.ApplicationDetailsCrudService;
import com.abacogroup.agri.applications.core.services.crud.ApplicationsCrudService;
import com.abacogroup.applicationworkflowsdk.model.ApplicationsWorkflowParams;
import com.abacogroup.workflow.sdk.beans.WorkflowMessage;
import com.abacogroup.workflow.server.model.ProcessTransitionResult;
import org.jdbi.v3.core.Handle;
import org.jdbi.v3.core.Jdbi;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import static com.abacogroup.agri.applications.core.services.crud.ApplicationsCrudService.FIND_EXPIRED;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.fail;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class ApplicationProcessListenerTest {
	@Mock
	private ApplicationsCrudService applicationsCrudServiceMock;
	@Mock
	private ApplicationDetailsCrudService applicationDetailsCrudServiceMock;
	@Mock
	private ApplicationsWorkflowService applicationsWorkflowServiceMock;
	@Mock
	private Jdbi jdbiMock;

	@InjectMocks
	ApplicationProcessListener applicationProcessListener;

	private static final Long PROCESS_ID = 1L;
	private static final String CURRENT_NODE = "current_node";
	private static final String EXCPTION_MESSAGE = "exception message thrown";

	@Test
	void onProcessCreated_ok() {
		Map<String, Object> globalVars = Map.of(ApplicationsWorkflowParams.KEY, new ApplicationsWorkflowParams());
		ProcessTransitionResult.TransitionLog transitionLogMock = mock(ProcessTransitionResult.TransitionLog.class);
		List<WorkflowMessage> messages = List.of(new WorkflowMessage());
		ProcessTransitionResult processTransitionResult = ProcessTransitionResult.builder()
				.processId(PROCESS_ID)
				.currentNode(CURRENT_NODE)
				.globalVars(globalVars)
				.lastTransitionLog(transitionLogMock)
				.messages(messages)
				.allTransitionLogs(new ArrayList<>())
				.build();
		ApplicationsWorkflowParams params = (ApplicationsWorkflowParams) globalVars.get(ApplicationsWorkflowParams.KEY);

		try {
			applicationProcessListener.onProcessCreated(processTransitionResult);

			verify(applicationsCrudServiceMock, times(1))
					.getApplicationAndUpdateProcessId(params.getTenant(), params.getApplicationId(), processTransitionResult.getProcessId(), FIND_EXPIRED);
		} catch (Exception e) {
			fail(e);
		}
	}

	@Test
	void onTransitionCompleted_ok() {
		Map<String, Object> globalVars = Map.of(ApplicationsWorkflowParams.KEY, new ApplicationsWorkflowParams());
		ProcessTransitionResult.TransitionLog transitionLogMock = mock(ProcessTransitionResult.TransitionLog.class);
		List<WorkflowMessage> messages = List.of(new WorkflowMessage());
		ProcessTransitionResult processTransitionResult = ProcessTransitionResult.builder()
				.processId(PROCESS_ID)
				.currentNode(CURRENT_NODE)
				.globalVars(globalVars)
				.lastTransitionLog(transitionLogMock)
				.messages(messages)
				.allTransitionLogs(new ArrayList<>())
				.build();
		ApplicationsWorkflowParams params = (ApplicationsWorkflowParams) globalVars.get(ApplicationsWorkflowParams.KEY);

		try {
			applicationProcessListener.onTransitionCompleted(processTransitionResult);

			verify(applicationDetailsCrudServiceMock, times(1))
					.updateProcessStatusAndFlTransition(params.getTenant(), params.getApplicationId(),
							processTransitionResult.getCurrentNode(), params.getUsername(),
							ProcessTransitionEnum.NOT_IN_TRANSITION);
		} catch (Exception e) {
			fail(e);
		}
	}

	@Test
	void onProcessCreated_ko() {
		Map<String, Object> globalVars = Map.of(ApplicationsWorkflowParams.KEY, new ApplicationsWorkflowParams());
		ProcessTransitionResult.TransitionLog transitionLogMock = mock(ProcessTransitionResult.TransitionLog.class);
		List<WorkflowMessage> messages = List.of(new WorkflowMessage());
		ProcessTransitionResult processTransitionResult = ProcessTransitionResult.builder()
				.processId(PROCESS_ID)
				.currentNode(CURRENT_NODE)
				.globalVars(globalVars)
				.lastTransitionLog(transitionLogMock)
				.messages(messages)
				.allTransitionLogs(new ArrayList<>())
				.build();
		ApplicationsWorkflowParams params = (ApplicationsWorkflowParams) globalVars.get(ApplicationsWorkflowParams.KEY);

		try {
			doThrow(new ObjectNotFoundException(EXCPTION_MESSAGE))
					.when(applicationsCrudServiceMock)
					.getApplicationAndUpdateProcessId(params.getTenant(), params.getApplicationId(),
							processTransitionResult.getProcessId(), FIND_EXPIRED);

			applicationProcessListener.onProcessCreated(processTransitionResult);
		} catch (Exception e) {
			assertEquals(EXCPTION_MESSAGE, e.getMessage());
		}
	}

	@Test
	void onTransitionCompleted_ko() {
		Map<String, Object> globalVars = Map.of(ApplicationsWorkflowParams.KEY, new ApplicationsWorkflowParams());
		ProcessTransitionResult.TransitionLog transitionLogMock = mock(ProcessTransitionResult.TransitionLog.class);
		List<WorkflowMessage> messages = List.of(new WorkflowMessage());
		ProcessTransitionResult processTransitionResult = ProcessTransitionResult.builder()
				.processId(PROCESS_ID)
				.currentNode(CURRENT_NODE)
				.globalVars(globalVars)
				.lastTransitionLog(transitionLogMock)
				.messages(messages)
				.allTransitionLogs(new ArrayList<>())
				.build();
		ApplicationsWorkflowParams params = (ApplicationsWorkflowParams) globalVars.get(ApplicationsWorkflowParams.KEY);

		try {
			doThrow(new ObjectNotFoundException(EXCPTION_MESSAGE))
					.when(applicationDetailsCrudServiceMock)
					.updateProcessStatusAndFlTransition(params.getTenant(), params.getApplicationId(),
							processTransitionResult.getCurrentNode(), params.getUsername(),
							ProcessTransitionEnum.NOT_IN_TRANSITION);

			applicationProcessListener.onTransitionCompleted(processTransitionResult);
		} catch (Exception e) {
			assertEquals(EXCPTION_MESSAGE, e.getMessage());
		}
	}
}
