package com.abacogroup.agri.applications.bundles.processor.childmodule;

import com.abacogroup.agri.applications.bundles.model.chilldmodule.BundleChildModuleInDTO;
import com.abacogroup.agri.applications.bundles.model.chilldmodule.BundleChildrenModulesMessage;
import com.abacogroup.bundles.listener.configdata.ConfigDataMessage;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.io.File;
import java.nio.file.Path;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.verify;

@Slf4j
@ExtendWith(MockitoExtension.class)
class BundleChildrenModulesProcessorTest {
	@Mock
	private ChildrenModulesBundleWorker childrenModulesBundleWorker;
	@Mock
	private ObjectMapper objectMapper;

	@InjectMocks
	private BundleChildrenModulesProcessor bundleChildrenModulesProcessor;

	private static final String TEMPLATE_TENANT_ID = "*";
	private static final String PARENT_MODULE_CODE = "PARENT_MODULE_CODE";
	private static final String MODULE_CODE = "MODULE_CODE";
	private static final Path PATH = new File("test.json").toPath();

	private final BundleChildModuleInDTO bundleChildModuleInDTO = BundleChildModuleInDTO.builder()
			.parentModuleCode(PARENT_MODULE_CODE)
			.moduleCode(MODULE_CODE)
			.build();

	private final BundleChildrenModulesMessage bundleChildrenModulesMessage = BundleChildrenModulesMessage.builder()
			.childrenModules(List.of(bundleChildModuleInDTO))
			.build();

	@Test
	void test_getDomainName() {
		assertEquals("children-modules", bundleChildrenModulesProcessor.getDomainName());
	}

	@Test
	void test_getTypeReference() {
		assertEquals(new TypeReference<BundleChildrenModulesMessage>() {
		}.getType(), bundleChildrenModulesProcessor.getTypeReference().getType());
	}

	@SuppressWarnings("unchecked")
	@Test
	void onMessageInTransaction() {
		try {
			ConfigDataMessage message = new ConfigDataMessage();
			message.setTenantId(TEMPLATE_TENANT_ID);
			message.setConfigFiles(List.of(PATH));

			bundleChildrenModulesProcessor.onMessageInTransaction(message);

			verify(objectMapper).readValue(eq(message.getConfigFiles().get(0).toFile()), any(TypeReference.class));
		} catch (Exception e) {
			fail(e.getMessage(), e);
		}
	}

	@Test
	void test_doInsertOrUpdate() {
		bundleChildrenModulesProcessor.doInsertOrUpdate(TEMPLATE_TENANT_ID, bundleChildrenModulesMessage);
		verify(childrenModulesBundleWorker).upsertBundleChildrenModules(TEMPLATE_TENANT_ID, bundleChildrenModulesMessage);
	}

	@Test
	void test_delete() {
		bundleChildrenModulesProcessor.delete(TEMPLATE_TENANT_ID, bundleChildrenModulesMessage);
		verify(childrenModulesBundleWorker).deleteBundleChildrenModules(TEMPLATE_TENANT_ID, bundleChildrenModulesMessage);
	}
}
