package com.abacogroup.agri.applications.core.services.crud;

import com.abacogroup.agri.applications.core.exceptions.ObjectNotFoundException;
import com.abacogroup.agri.applications.core.mappers.ModulePrintConfigParamMapper;
import com.abacogroup.agri.applications.core.model.dto.ModulePrintConfigParamDTO;
import com.abacogroup.agri.applications.db.dao.ModulePrintConfigParamDAO;
import com.abacogroup.agri.applications.db.ntt.ModulePrintConfigParamNTT;
import com.abacogroup.agri.applications.db.ntt.compoundkeys.PrintConfigParamKey;
import org.jdbi.v3.sqlobject.transaction.TransactionalCallback;
import org.jdbi.v3.sqlobject.transaction.TransactionalConsumer;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class ModulePrintConfigParamCrudServiceTest {
    @Mock
    private ModulePrintConfigParamDAO modulePrintConfigParamDAOMock;
    @Mock
    private ModulePrintConfigParamMapper modulePrintConfigParamMapperMock;

    @InjectMocks
    private ModulePrintConfigParamCrudService modulePrintConfigParamCrudService;

    private static final String TENANT = "ADMIN";
    private static final Long MODULE_PRINT_CONFIG_ID = 10L;
    private static final String PARAMETER_NAME = "Parameter name";
    private static final String PARAMETER_VALUE = "Parameter value";

    private final PrintConfigParamKey printConfigParamKey = PrintConfigParamKey.builder()
            .module_print_config_id(MODULE_PRINT_CONFIG_ID)
            .parameter_name(PARAMETER_NAME)
            .build();
    private final ModulePrintConfigParamNTT modulePrintConfigParamNTT = ModulePrintConfigParamNTT.builder()
            .module_print_config_id(MODULE_PRINT_CONFIG_ID)
            .parameter_name(PARAMETER_NAME)
            .parameter_value(PARAMETER_VALUE)
            .build();
    private final ModulePrintConfigParamDTO modulePrintConfigParamDTO = ModulePrintConfigParamDTO.builder()
            .modulePrintConfigId(MODULE_PRINT_CONFIG_ID)
            .parameterName(PARAMETER_NAME)
            .parameterValue(PARAMETER_VALUE)
            .build();

    @SuppressWarnings({"rawtypes", "unchecked"})
    @Test
    void insert_ok() {
        ModulePrintConfigParamDTO payload = ModulePrintConfigParamDTO.builder()
                .modulePrintConfigId(MODULE_PRINT_CONFIG_ID)
                .parameterValue(PARAMETER_VALUE)
                .parameterName(PARAMETER_NAME)
                .build();

        try {
            ArgumentCaptor<TransactionalCallback> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(TransactionalCallback.class);

            when(modulePrintConfigParamMapperMock.dtoToEntity(payload))
                    .thenReturn(modulePrintConfigParamNTT);
            when(modulePrintConfigParamMapperMock.entityToDto(modulePrintConfigParamNTT))
                    .thenReturn(modulePrintConfigParamDTO);
            when(modulePrintConfigParamDAOMock.findById(MODULE_PRINT_CONFIG_ID, PARAMETER_NAME))
                    .thenReturn(List.of(modulePrintConfigParamNTT));

            modulePrintConfigParamCrudService.insert(payload);

            verify(modulePrintConfigParamDAOMock).inTransaction(handleConsumerLambdaCaptor.capture());

            ModulePrintConfigParamDTO result = (ModulePrintConfigParamDTO) handleConsumerLambdaCaptor.getValue().inTransaction(modulePrintConfigParamDAOMock);

            assertEquals(modulePrintConfigParamDTO, result);

        } catch (Exception e) {
            fail(e);
        }

    }

    @SuppressWarnings({"rawtypes", "unchecked"})
    @Test
    void update_ok() {
        ModulePrintConfigParamDTO payload = ModulePrintConfigParamDTO.builder()
                .modulePrintConfigId(MODULE_PRINT_CONFIG_ID)
                .parameterValue(PARAMETER_VALUE)
                .parameterName(PARAMETER_NAME)
                .build();

        try {
            ArgumentCaptor<TransactionalCallback> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(TransactionalCallback.class);

            when(modulePrintConfigParamDAOMock.inTransaction(handleConsumerLambdaCaptor.capture()))
                    .thenReturn(modulePrintConfigParamDTO);
            when(modulePrintConfigParamMapperMock.dtoToEntity(payload))
                    .thenReturn(modulePrintConfigParamNTT);
            when(modulePrintConfigParamDAOMock.findById(MODULE_PRINT_CONFIG_ID, PARAMETER_NAME))
                    .thenReturn(List.of(modulePrintConfigParamNTT));
            when(modulePrintConfigParamMapperMock.entityToDto(modulePrintConfigParamNTT))
                    .thenReturn(modulePrintConfigParamDTO);

            modulePrintConfigParamCrudService.update(payload);

            verify(modulePrintConfigParamDAOMock).inTransaction(handleConsumerLambdaCaptor.capture());
            ModulePrintConfigParamDTO result = (ModulePrintConfigParamDTO) handleConsumerLambdaCaptor.getValue().inTransaction(modulePrintConfigParamDAOMock);

            assertEquals(modulePrintConfigParamDTO, result);
        } catch (Exception e) {
            fail(e);
        }
    }

    @SuppressWarnings({"rawtypes", "unchecked"})
    @Test
    void delete_ok() {
        try {
            ArgumentCaptor<TransactionalConsumer> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(TransactionalConsumer.class);

            modulePrintConfigParamCrudService.delete(printConfigParamKey);

            verify(modulePrintConfigParamDAOMock).useTransaction(handleConsumerLambdaCaptor.capture());
            handleConsumerLambdaCaptor.getValue().useTransaction(modulePrintConfigParamDAOMock);

            verify(modulePrintConfigParamDAOMock, times(1)).deleteById(MODULE_PRINT_CONFIG_ID, PARAMETER_NAME);
        } catch (Exception e) {
            fail(e);
        }
    }

    @Test
    void deleteByModulePrintConfigId_ok() {
        modulePrintConfigParamCrudService.deleteByModulePrintConfigId(MODULE_PRINT_CONFIG_ID);

        verify(modulePrintConfigParamDAOMock, times(1)).deleteByModulePrintConfigId(MODULE_PRINT_CONFIG_ID);
    }

    @Test
    void findById_ok() {
        try {
            when(modulePrintConfigParamDAOMock.findById(TENANT, MODULE_PRINT_CONFIG_ID, PARAMETER_NAME))
                    .thenReturn(List.of(modulePrintConfigParamNTT));
            when(modulePrintConfigParamMapperMock.entityToDto(modulePrintConfigParamNTT))
                    .thenReturn(modulePrintConfigParamDTO);

            ModulePrintConfigParamDTO result = modulePrintConfigParamCrudService.findById(TENANT, printConfigParamKey);

            assertEquals(modulePrintConfigParamDTO, result);
        } catch (Exception e) {
            fail(e);
        }
    }

    @Test
    void find_ok() {
        when(modulePrintConfigParamDAOMock.find(TENANT, MODULE_PRINT_CONFIG_ID))
                .thenReturn(List.of(modulePrintConfigParamNTT));
        when(modulePrintConfigParamMapperMock.entityToDto(modulePrintConfigParamNTT))
                .thenReturn(modulePrintConfigParamDTO);

        List<ModulePrintConfigParamDTO> result = modulePrintConfigParamCrudService.find(TENANT, MODULE_PRINT_CONFIG_ID);

        assertEquals(List.of(modulePrintConfigParamDTO), result);
    }

    @Test
    void findById_ko() {
        try {
            when(modulePrintConfigParamDAOMock.findById(TENANT, MODULE_PRINT_CONFIG_ID, PARAMETER_NAME))
                    .thenReturn(List.of());

            assertThrows(ObjectNotFoundException.class, () ->
                    modulePrintConfigParamCrudService.findById(TENANT, printConfigParamKey));
        } catch (Exception e) {
            fail(e);
        }
    }
}
