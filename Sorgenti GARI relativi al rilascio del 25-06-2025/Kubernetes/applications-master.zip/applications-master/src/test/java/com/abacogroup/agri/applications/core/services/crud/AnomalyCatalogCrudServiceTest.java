package com.abacogroup.agri.applications.core.services.crud;

import com.abacogroup.agri.applications.core.exceptions.AgriApplicationsRuntimeException;
import com.abacogroup.agri.applications.core.exceptions.ObjectNotFoundException;
import com.abacogroup.agri.applications.core.mappers.AnomalyCatalogMapper;
import com.abacogroup.agri.applications.core.model.dto.publics.AnomalyCatalogDTO;
import com.abacogroup.agri.applications.core.services.I18NService;
import com.abacogroup.agri.applications.db.dao.AnomalyCatalogDAO;
import com.abacogroup.agri.applications.db.ntt.AnomalyCatalogNTT;
import com.abacogroup.agri.applications.db.ntt.AnomalyCatalogWIthModuleCodeNTT;
import com.abacogroup.agri.applications.db.ntt.applications.RsI18N;
import com.abacogroup.agri.applications.db.ntt.compoundkeys.AnomalyCatalogKey;
import org.jdbi.v3.sqlobject.transaction.TransactionalCallback;
import org.jdbi.v3.sqlobject.transaction.TransactionalConsumer;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class AnomalyCatalogCrudServiceTest {
	@Mock
	private I18NService i18NServiceMock;
	@Mock
	private AnomalyCatalogDAO anomalyCatalogDAOMock;
	@Mock
	private AnomalyCatalogMapper anomalyCatalogMapperMock;

	@InjectMocks
	private AnomalyCatalogCrudService anomalyCatalogCrudService;

	private static final String I18N_ANOMALY_CATALOG_TABLE = "apps_anomaly_catalog";
	private static final String TENANT = "ADMIN";
	private static final String ANOMALY_CODE = "anomaly_code";
	private static final String ANOMALY_DESCRIPTION = "anomaly_description";
	private static final String MODULE_CODE = "module_code";
	private static final String SEVERITY = "severity";
	private static final Long MODULE_ID = 15L;
	private static final String LANG = "Language";
	private static final String TEXT = "text";
	private static final String VALUE = "value";
	private static final String FIELD_NAME = "field_name";

	private static final AnomalyCatalogKey ANOMALY_CATALOG_KEY = new AnomalyCatalogKey(ANOMALY_CODE, MODULE_ID);

	private final AnomalyCatalogWIthModuleCodeNTT anomalyCatalogWIthModuleCodeNTT = AnomalyCatalogWIthModuleCodeNTT.builder()
			.anomaly_code(ANOMALY_CODE)
			.module_code(MODULE_CODE)
			.severity(SEVERITY)
			.build();
	private final AnomalyCatalogNTT anomalyCatalogNTT = AnomalyCatalogNTT.builder()
			.anomaly_code(ANOMALY_CODE)
			.anomaly_desc(ANOMALY_DESCRIPTION)
			.severity(SEVERITY)
			.module_id(MODULE_ID)
			.build();
	private final AnomalyCatalogDTO anomalyCatalogDTO = AnomalyCatalogDTO.builder()
			.anomalyCode(ANOMALY_CODE)
			.anomalyDesc(ANOMALY_DESCRIPTION)
			.severity(SEVERITY)
			.moduleId(MODULE_ID)
			.build();
	private final RsI18N rsI18N = RsI18N.builder()
			.tenant_id(TENANT)
			.i18n_text(TEXT)
			.i18n_value(VALUE)
			.field_name(FIELD_NAME)
			.table_name(I18N_ANOMALY_CATALOG_TABLE)
			.lang(LANG)
			.build();

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Test
	void insert_ok() {
		AnomalyCatalogDTO payload = AnomalyCatalogDTO.builder()
				.anomalyCode(ANOMALY_CODE)
				.anomalyDesc(ANOMALY_DESCRIPTION)
				.severity(SEVERITY)
				.moduleId(MODULE_ID)
				.build();

		try {
			ArgumentCaptor<TransactionalCallback> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(TransactionalCallback.class);

			when(anomalyCatalogMapperMock.dtoToEntity(payload))
					.thenReturn(anomalyCatalogNTT);
			when(anomalyCatalogMapperMock.entityToDto(anomalyCatalogNTT))
					.thenReturn(anomalyCatalogDTO);
			when(anomalyCatalogDAOMock.findById(ANOMALY_CATALOG_KEY))
					.thenReturn(List.of(anomalyCatalogNTT));

			anomalyCatalogCrudService.insert(payload);

			verify(anomalyCatalogDAOMock).inTransaction(handleConsumerLambdaCaptor.capture());

			AnomalyCatalogDTO result = (AnomalyCatalogDTO) handleConsumerLambdaCaptor.getValue().inTransaction(anomalyCatalogDAOMock);

			assertEquals(anomalyCatalogDTO, result);

		} catch (Exception e) {
			fail(e);
		}

	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Test
	void update_NotImplemented() {
		AnomalyCatalogDTO payload = AnomalyCatalogDTO.builder()
				.anomalyCode(ANOMALY_CODE)
				.anomalyDesc(ANOMALY_DESCRIPTION)
				.severity(SEVERITY)
				.build();

		try {
			ArgumentCaptor<TransactionalCallback> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(TransactionalCallback.class);

			when(anomalyCatalogDAOMock.inTransaction(handleConsumerLambdaCaptor.capture()))
					.thenReturn(anomalyCatalogDTO);
			when(anomalyCatalogMapperMock.dtoToEntity(payload))
					.thenReturn(anomalyCatalogNTT);

			anomalyCatalogCrudService.update(ANOMALY_CATALOG_KEY, payload);

			verify(anomalyCatalogDAOMock).inTransaction(handleConsumerLambdaCaptor.capture());

			assertThrows(AgriApplicationsRuntimeException.class, () ->
					handleConsumerLambdaCaptor.getValue().inTransaction(anomalyCatalogDAOMock));
		} catch (Exception e) {
			fail(e);
		}
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Test
	void delete_notImplemented() {
		try {
			ArgumentCaptor<TransactionalConsumer> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(TransactionalConsumer.class);

			anomalyCatalogCrudService.delete(ANOMALY_CATALOG_KEY);

			verify(anomalyCatalogDAOMock).useTransaction(handleConsumerLambdaCaptor.capture());

			assertThrows(AgriApplicationsRuntimeException.class, () ->
					handleConsumerLambdaCaptor.getValue().useTransaction(anomalyCatalogDAOMock));
		} catch (Exception e) {
			fail(e);
		}
	}

	@Test
	void findAllByTenant_ok() {
		when(anomalyCatalogDAOMock.findAllByTenant(TENANT))
				.thenReturn(List.of(anomalyCatalogWIthModuleCodeNTT));

		List<AnomalyCatalogWIthModuleCodeNTT> result = anomalyCatalogCrudService.findAllByTenant(TENANT);

		assertEquals(List.of(anomalyCatalogWIthModuleCodeNTT), result);
	}

	@Test
	void deleteByIdAndModuleId_ok() {
		anomalyCatalogCrudService.deleteByIdAndModuleId(ANOMALY_CODE, MODULE_ID);

		verify(anomalyCatalogDAOMock, times(1)).deleteByIdAndModuleId(ANOMALY_CODE, MODULE_ID);
	}

	@Test
	void findById_ok() {
		try {
			when(anomalyCatalogDAOMock.findById(ANOMALY_CATALOG_KEY))
					.thenReturn(List.of(anomalyCatalogNTT));
			when(anomalyCatalogMapperMock.entityToDto(anomalyCatalogNTT))
					.thenReturn(anomalyCatalogDTO);

			AnomalyCatalogDTO result = anomalyCatalogCrudService.findById(ANOMALY_CATALOG_KEY);

			assertEquals(anomalyCatalogDTO, result);
		} catch (Exception e) {
			fail(e);
		}
	}

	@Test
	void findById_ko() {
		try {
			when(anomalyCatalogDAOMock.findById(ANOMALY_CATALOG_KEY))
					.thenReturn(List.of());

			assertThrows(ObjectNotFoundException.class, () ->
					anomalyCatalogCrudService.findById(ANOMALY_CATALOG_KEY));
		} catch (Exception e) {
			fail(e);
		}
	}

	@Test
	void insertAnomalyCatalogI18N_ok() {
		anomalyCatalogCrudService.insertAnomalyCatalogI18N(TENANT, ANOMALY_CODE, LANG, ANOMALY_DESCRIPTION);

		verify(i18NServiceMock, times(1))
				.insertI18N(TENANT, I18N_ANOMALY_CATALOG_TABLE, AnomalyCatalogCrudService.ANOMALY_CATALOG_I18N.ANOMALY_CODE.getCode(),
						LANG, ANOMALY_CODE, ANOMALY_DESCRIPTION);
	}

	@Test
	void deleteAnomalyCatalogI18N_ok() {
		anomalyCatalogCrudService.deleteAnomalyCatalogI18N(TENANT, ANOMALY_CODE, LANG);

		verify(i18NServiceMock, times(1))
				.deleteI18N(TENANT, I18N_ANOMALY_CATALOG_TABLE, AnomalyCatalogCrudService.ANOMALY_CATALOG_I18N.ANOMALY_CODE.getCode(),
						ANOMALY_CODE, LANG);
	}

	@Test
	void getAllAnomalyCatalogI18NByTenantAndCode_ok() {
		when(i18NServiceMock.getAllI18NbyCode(TENANT, I18N_ANOMALY_CATALOG_TABLE, ANOMALY_CODE))
				.thenReturn(List.of(rsI18N));

		List<RsI18N> result = anomalyCatalogCrudService.getAllAnomalyCatalogI18NByTenantAndCode(TENANT, ANOMALY_CODE);

		assertEquals(List.of(rsI18N), result);
	}

}
