package com.abacogroup.agri.applications.core.services.crud;

import com.abacogroup.agri.applications.core.mappers.ApplicationProtocolsMapper;
import com.abacogroup.agri.applications.core.model.dto.publics.ApplicationProtocolsDTO;
import com.abacogroup.agri.applications.db.dao.ApplicationProtocolsDAO;
import com.abacogroup.agri.applications.db.ntt.ApplicationProtocolsNTT;
import org.jdbi.v3.sqlobject.transaction.TransactionalCallback;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class ApplicationProtocolCrudServiceTest {
	@Mock
	ApplicationProtocolsDAO applicationProtocolsDAO;
	@Mock
	ApplicationProtocolsMapper applicationProtocolsMapper;

	@InjectMocks
	ApplicationProtocolsCrudService applicationProtocolsCrudService;

	private static final String TENANT = "ADMIN";
	private static final String USERNAME = "Username";
	private static final Long APPLICATION_ID = 5L;
	private static final Long PKID = 1L;
	private static final String PROTOCOL = "Protocol";
	private static final LocalDateTime REQUEST_DATE = LocalDateTime.now();
	private static final LocalDateTime RESPONSE_DATE = LocalDateTime.of(2030, 9, 27, 10, 5, 26);

	private final ApplicationProtocolsDTO applicationProtocolsDTO = ApplicationProtocolsDTO.builder()
			.pkid(PKID)
			.applicationId(APPLICATION_ID)
			.protocol(PROTOCOL)
			.dtRequest(REQUEST_DATE)
			.dtResponse(RESPONSE_DATE)
			.build();
	private final ApplicationProtocolsNTT applicationProtocolsNTT = ApplicationProtocolsNTT.builder()
			.pkid(PKID)
			.application_id(APPLICATION_ID)
			.protocol(PROTOCOL)
			.dt_request(REQUEST_DATE)
			.dt_response(RESPONSE_DATE)
			.build();

	@Test
	void findById_ok() {
		try {
			when(applicationProtocolsDAO.findById(PKID))
					.thenReturn(List.of(applicationProtocolsNTT));
			when(applicationProtocolsMapper.entityToDto(applicationProtocolsNTT))
					.thenReturn(applicationProtocolsDTO);

			ApplicationProtocolsDTO result = applicationProtocolsCrudService.findById(PKID);

			assertEquals(applicationProtocolsDTO, result);
		} catch (Exception e) {
			fail(e);
		}
	}

	@Test
	void findAll_ok() {
		when(applicationProtocolsDAO.find(TENANT, APPLICATION_ID))
				.thenReturn(List.of(applicationProtocolsNTT));
		when(applicationProtocolsMapper.entityToDto(applicationProtocolsNTT))
				.thenReturn(applicationProtocolsDTO);

		List<ApplicationProtocolsDTO> result = applicationProtocolsCrudService.findAll(TENANT, APPLICATION_ID);

		assertEquals(List.of(applicationProtocolsDTO), result);
	}

	@Test
	void logicallyDeleteByApplicationId_ok() {
		applicationProtocolsCrudService.logicallyDeleteByApplicationId(PKID, USERNAME);

		verify(applicationProtocolsDAO, times(1)).logicallyDeleteById(eq(PKID), eq(USERNAME), any());
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Test
	void insert_ok() {
		ApplicationProtocolsDTO in = ApplicationProtocolsDTO.builder()
				.applicationId(APPLICATION_ID)
				.protocol(PROTOCOL)
				.build();

		try {
			ArgumentCaptor<TransactionalCallback> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(TransactionalCallback.class);

			when(applicationProtocolsDAO.nextSequenceVal())
					.thenReturn(PKID);
			when(applicationProtocolsMapper.dtoToEntity(in))
					.thenReturn(applicationProtocolsNTT);
			when(applicationProtocolsDAO.findById(PKID))
					.thenReturn(List.of(applicationProtocolsNTT));
			when(applicationProtocolsMapper.entityToDto(applicationProtocolsNTT))
					.thenReturn(applicationProtocolsDTO);

			applicationProtocolsCrudService.insert(in, USERNAME);

			verify(applicationProtocolsDAO).inTransaction(handleConsumerLambdaCaptor.capture());

			ApplicationProtocolsDTO result = (ApplicationProtocolsDTO) handleConsumerLambdaCaptor.getValue().inTransaction(applicationProtocolsDAO);

			assertEquals(applicationProtocolsDTO, result);
		} catch (Exception e) {
			fail(e);
		}
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Test
	void update_ok() {
		ApplicationProtocolsDTO in = ApplicationProtocolsDTO.builder()
				.applicationId(APPLICATION_ID)
				.protocol(PROTOCOL)
				.build();

		try {
			ArgumentCaptor<TransactionalCallback> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(TransactionalCallback.class);
			when(applicationProtocolsDAO.getCurrentTimestamp())
					.thenReturn(LocalDateTime.now());
			when(applicationProtocolsDAO.inTransaction(handleConsumerLambdaCaptor.capture()))
					.thenReturn(applicationProtocolsDTO);

			applicationProtocolsCrudService.update(PKID, in, USERNAME);

			verify(applicationProtocolsDAO).inTransaction(handleConsumerLambdaCaptor.capture());
			ApplicationProtocolsDTO result = (ApplicationProtocolsDTO) handleConsumerLambdaCaptor.getValue().inTransaction(applicationProtocolsDAO);

			assertEquals(applicationProtocolsDTO, result);
		} catch (Exception e) {
			fail(e);
		}
	}

	@Test
	void retrieveCustomKeyByResultSet_ok() {
		assertNull(applicationProtocolsCrudService.retrieveCustomKeyByResultSet(applicationProtocolsNTT));
	}

	@Test
	void findRsByCustomKey_ok() {
		Optional<ApplicationProtocolsNTT> result = applicationProtocolsCrudService.findRsByCustomKey(null);

		assertEquals(Optional.empty(), result);
	}
}
