package com.abacogroup.agri.applications.core.services.crud;

import com.abacogroup.agri.applications.core.exceptions.ObjectNotFoundException;
import com.abacogroup.agri.applications.core.mappers.ModuleCalculationConfigsMapper;
import com.abacogroup.agri.applications.core.model.dto.ModuleCalculationConfigsDTO;
import com.abacogroup.agri.applications.core.services.I18NService;
import com.abacogroup.agri.applications.db.dao.ModuleCalculationConfigsDAO;
import com.abacogroup.agri.applications.db.ntt.ModuleCalculationConfigsNTT;
import com.abacogroup.agri.applications.db.ntt.applications.RsI18N;
import com.abacogroup.jaxrsutils.filter.MDCPreFilter;
import org.apache.commons.lang3.NotImplementedException;
import org.jdbi.v3.sqlobject.transaction.TransactionalCallback;
import org.jdbi.v3.sqlobject.transaction.TransactionalConsumer;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.slf4j.MDC;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class ModuleCalculationConfigsCrudServiceTest {
    @Mock
    private I18NService i18NServiceMock;
    @Mock
    private ModuleCalculationConfigsDAO moduleCalculationConfigsDAOMock;
    @Mock
    private ModuleCalculationConfigsMapper moduleCalculationConfigsMapperMock;
    
    @InjectMocks
    private ModuleCalculationConfigsCrudService moduleCalculationConfigsCrudService;

    private static final String TENANT = "ADMIN";
    private static final String I18N_APPLICATION_CALCULATIONS_TABLE = "apps_module_calculation_configs";
    private static final Long MODULE_CALCULATION_CONFIG_ID = 12L;
    private static final Long MODULE_ID = 5L;
    private static final String PROCESS_STATUS = "process status";
    private static final String CALCULATION_CODE = "calculation code";
    private static final String CALCULATION_DESCRIPTION = "calculation description";
    private static final Integer SORT_ORDER = 1;
    private static final String CONTEXT_FUNCTION = "context function";
    private static final String PROFILE_CODE = "profile code";
    private static final String LANG = "Language";
    private static final String TEXT = "text";
    private static final String VALUE = "value";
    private static final String FIELD_NAME = "field_name";

    private final ModuleCalculationConfigsNTT moduleCalculationConfigsNTT = ModuleCalculationConfigsNTT.builder()
            .id(MODULE_CALCULATION_CONFIG_ID)
            .module_id(MODULE_ID)
            .process_status(PROCESS_STATUS)
            .calculation_code(CALCULATION_CODE)
            .calculation_description(CALCULATION_DESCRIPTION)
            .sort_order(SORT_ORDER)
            .context_function(CONTEXT_FUNCTION)
            .build();
    private final ModuleCalculationConfigsDTO moduleCalculationConfigsDTO = ModuleCalculationConfigsDTO.builder()
            .id(MODULE_CALCULATION_CONFIG_ID)
            .moduleId(MODULE_ID)
            .processStatus(PROCESS_STATUS)
            .calculationCode(CALCULATION_CODE)
            .calculationDescription(CALCULATION_DESCRIPTION)
            .sortOrder(SORT_ORDER)
            .contextFunction(CONTEXT_FUNCTION)
            .build();
    private final RsI18N rsI18N = RsI18N.builder()
            .tenant_id(TENANT)
            .i18n_text(TEXT)
            .i18n_value(VALUE)
            .field_name(FIELD_NAME)
            .table_name(I18N_APPLICATION_CALCULATIONS_TABLE)
            .lang(LANG)
            .build();
    
    @Test
    void findAllModuleCalculationConfigsByTenant_ok() {
        when(moduleCalculationConfigsDAOMock.findAllModuleCalculationConfigsByTenant(TENANT))
                .thenReturn(List.of(moduleCalculationConfigsNTT));
        when(moduleCalculationConfigsMapperMock.entityToDto(moduleCalculationConfigsNTT))
                .thenReturn(moduleCalculationConfigsDTO);

        List<ModuleCalculationConfigsDTO> result = moduleCalculationConfigsCrudService.findAllModuleCalculationConfigsByTenant(TENANT);

        assertEquals(List.of(moduleCalculationConfigsDTO), result);
    }

    @Test
    void findAllModuleCalculationConfigs_ok() {
        when(moduleCalculationConfigsDAOMock.findAllModuleCalculationConfigs(TENANT, MODULE_ID))
                .thenReturn(List.of(moduleCalculationConfigsNTT));
        when(moduleCalculationConfigsMapperMock.entityToDto(moduleCalculationConfigsNTT))
                .thenReturn(moduleCalculationConfigsDTO);

        List<ModuleCalculationConfigsDTO> result = moduleCalculationConfigsCrudService.findAllModuleCalculationConfigs(TENANT, MODULE_ID);

        assertEquals(List.of(moduleCalculationConfigsDTO), result);
    }

    @Test
    void findRsByCustomKey_ok() {
        Optional<ModuleCalculationConfigsNTT> result = moduleCalculationConfigsCrudService.findRsByCustomKey(null);

        assertEquals(Optional.empty(), result);
    }

    @Test
    void deleteByCustomKey_ok() {
        assertThrows(NotImplementedException.class, () ->
                moduleCalculationConfigsCrudService.deleteByCustomKey(null));
    }

    @Test
    void setCustomSearchKey_ok() {
        assertThrows(NotImplementedException.class, () ->
                moduleCalculationConfigsCrudService.setCustomSearchKey(moduleCalculationConfigsNTT, null));
    }

    @SuppressWarnings({"rawtypes", "unchecked"})
    @Test
    void test_insert() {
        ModuleCalculationConfigsDTO payload = ModuleCalculationConfigsDTO.builder()
                .id(MODULE_CALCULATION_CONFIG_ID)
                .moduleId(MODULE_ID)
                .processStatus(PROCESS_STATUS)
                .calculationCode(CALCULATION_CODE)
                .contextFunction(CONTEXT_FUNCTION)
                .build();

        try {
            ArgumentCaptor<TransactionalCallback> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(TransactionalCallback.class);

            when(moduleCalculationConfigsDAOMock.nextSequenceVal())
                    .thenReturn(MODULE_ID);
            when(moduleCalculationConfigsDAOMock.findById(MODULE_ID))
                    .thenReturn(List.of(moduleCalculationConfigsNTT));
            when(moduleCalculationConfigsMapperMock.entityToDto(moduleCalculationConfigsNTT))
                    .thenReturn(moduleCalculationConfigsDTO);
            when(moduleCalculationConfigsMapperMock.dtoToEntity(payload))
                    .thenReturn(moduleCalculationConfigsNTT);

            moduleCalculationConfigsCrudService.insert(payload);

            verify(moduleCalculationConfigsDAOMock).inTransaction(handleConsumerLambdaCaptor.capture());
            ModuleCalculationConfigsDTO actual = (ModuleCalculationConfigsDTO) handleConsumerLambdaCaptor.getValue().inTransaction(moduleCalculationConfigsDAOMock);

            assertEquals(moduleCalculationConfigsDTO, actual);
        } catch (Exception e) {
            fail(e);
        }
    }

    @SuppressWarnings({"rawtypes", "unchecked"})
    @Test
    void test_update() {
        ModuleCalculationConfigsDTO payload = ModuleCalculationConfigsDTO.builder()
                .id(MODULE_CALCULATION_CONFIG_ID)
                .moduleId(MODULE_ID)
                .processStatus(PROCESS_STATUS)
                .calculationCode(CALCULATION_CODE)
                .contextFunction(CONTEXT_FUNCTION)
                .build();

        try {
            ArgumentCaptor<TransactionalCallback> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(TransactionalCallback.class);

            when(moduleCalculationConfigsDAOMock.findById(MODULE_ID))
                    .thenReturn(List.of(moduleCalculationConfigsNTT));
            when(moduleCalculationConfigsMapperMock.entityToDto(moduleCalculationConfigsNTT))
                    .thenReturn(moduleCalculationConfigsDTO);
            when(moduleCalculationConfigsMapperMock.dtoToEntity(payload))
                    .thenReturn(moduleCalculationConfigsNTT);

            moduleCalculationConfigsCrudService.update(MODULE_ID, payload);

            verify(moduleCalculationConfigsDAOMock).inTransaction(handleConsumerLambdaCaptor.capture());
            handleConsumerLambdaCaptor.getValue().inTransaction(moduleCalculationConfigsDAOMock);

            verify(moduleCalculationConfigsDAOMock, times(1)).inTransaction(handleConsumerLambdaCaptor.capture());

            ModuleCalculationConfigsDTO actual = (ModuleCalculationConfigsDTO) handleConsumerLambdaCaptor.getValue().inTransaction(moduleCalculationConfigsDAOMock);

            assertEquals(moduleCalculationConfigsDTO, actual);
        } catch (Exception e) {
            fail(e);
        }
    }

    @SuppressWarnings({"rawtypes", "unchecked"})
    @Test
    void test_delete() {
        try {
            ArgumentCaptor<TransactionalConsumer> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(TransactionalConsumer.class);

            moduleCalculationConfigsCrudService.delete(MODULE_ID);

            verify(moduleCalculationConfigsDAOMock).useTransaction(handleConsumerLambdaCaptor.capture());
            handleConsumerLambdaCaptor.getValue().useTransaction(moduleCalculationConfigsDAOMock);

            verify(moduleCalculationConfigsDAOMock, times(1)).deleteById(MODULE_ID);
        } catch (Exception e) {
            fail(e);
        }
    }

    @Test
    void findById_ok() {
        try {
            when(moduleCalculationConfigsDAOMock.findById(TENANT, MODULE_CALCULATION_CONFIG_ID, MDC.get(MDCPreFilter.LOCALE)))
                    .thenReturn(List.of(moduleCalculationConfigsNTT));
            when(moduleCalculationConfigsMapperMock.entityToDto(moduleCalculationConfigsNTT))
                    .thenReturn(moduleCalculationConfigsDTO);

            ModuleCalculationConfigsDTO result = moduleCalculationConfigsCrudService.findById(TENANT, MODULE_CALCULATION_CONFIG_ID);

            assertEquals(moduleCalculationConfigsDTO, result);
        } catch (Exception e) {
            fail(e);
        }
    }

    @Test
    void findById_ko() {
            when(moduleCalculationConfigsDAOMock.findById(TENANT, MODULE_CALCULATION_CONFIG_ID, MDC.get(MDCPreFilter.LOCALE)))
                    .thenReturn(List.of());

            assertThrows(ObjectNotFoundException.class, () ->
                    moduleCalculationConfigsCrudService.findById(TENANT, MODULE_CALCULATION_CONFIG_ID));
    }

    @Test
    void find_withProfileCodeList_ok() {
        List<String> profileCodeList = List.of(PROFILE_CODE);

        when(moduleCalculationConfigsDAOMock.find(TENANT, MODULE_ID, PROCESS_STATUS, profileCodeList, MDC.get(MDCPreFilter.LOCALE)))
                .thenReturn(List.of(moduleCalculationConfigsNTT));
        when(moduleCalculationConfigsMapperMock.entityToDto(moduleCalculationConfigsNTT))
                .thenReturn(moduleCalculationConfigsDTO);

        List<ModuleCalculationConfigsDTO> result = moduleCalculationConfigsCrudService.find(TENANT, MODULE_ID, PROCESS_STATUS, profileCodeList);

        assertEquals(List.of(moduleCalculationConfigsDTO), result);
    }

    @Test
    void find_withoutProfileCodeList_ok() {
        when(moduleCalculationConfigsDAOMock.find(TENANT, MODULE_ID, CALCULATION_CODE, PROCESS_STATUS))
                .thenReturn(List.of(moduleCalculationConfigsNTT));
        when(moduleCalculationConfigsMapperMock.entityToDto(moduleCalculationConfigsNTT))
                .thenReturn(moduleCalculationConfigsDTO);

        Optional<ModuleCalculationConfigsDTO> result = moduleCalculationConfigsCrudService.find(TENANT, MODULE_ID, CALCULATION_CODE, PROCESS_STATUS);

        assertEquals(Optional.of(moduleCalculationConfigsDTO), result);
    }

    @Test
    void insertCalculationCodeI18N_ok() {
        moduleCalculationConfigsCrudService.insertCalculationCodeI18N(TENANT, CALCULATION_CODE, LANG, CALCULATION_DESCRIPTION);

        verify(i18NServiceMock, times(1)).insertI18N(TENANT, I18N_APPLICATION_CALCULATIONS_TABLE,
                ModuleCalculationConfigsCrudService.CALCULATION_CODE_I18N.PROFILE_CODE.getCode(), LANG, CALCULATION_CODE, CALCULATION_DESCRIPTION);
    }

    @Test
    void deleteCalculationCodeI18N_ok() {
        moduleCalculationConfigsCrudService.deleteCalculationCodeI18N(TENANT, CALCULATION_CODE, LANG);

        verify(i18NServiceMock, times(1)).deleteI18N(TENANT, I18N_APPLICATION_CALCULATIONS_TABLE,
                ModuleCalculationConfigsCrudService.CALCULATION_CODE_I18N.PROFILE_CODE.getCode(), CALCULATION_CODE, LANG);
    }

    @Test
    void getAllCalculationCodeI18NByTenantAndCode_ok() {
        when(i18NServiceMock.getAllI18NbyCode(TENANT, I18N_APPLICATION_CALCULATIONS_TABLE, CALCULATION_CODE))
                .thenReturn(List.of(rsI18N));

        List<RsI18N> result = moduleCalculationConfigsCrudService.getAllCalculationCodeI18NByTenantAndCode(TENANT, CALCULATION_CODE);

        assertEquals(List.of(rsI18N), result);
    }
}
