package com.abacogroup.agri.applications.core.services.crud;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.fail;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.lenient;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import org.jdbi.v3.sqlobject.transaction.TransactionalCallback;
import org.jdbi.v3.sqlobject.transaction.TransactionalConsumer;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.slf4j.MDC;

import com.abacogroup.agri.applications.core.exceptions.ApplicationNotFoundRuntimeException;
import com.abacogroup.agri.applications.core.exceptions.ObjectNotFoundException;
import com.abacogroup.agri.applications.core.mappers.ApplicationMapper;
import com.abacogroup.agri.applications.core.mappers.ApplicationsByPartyAndYearMapper;
import com.abacogroup.agri.applications.core.model.AbsoluteDate;
import com.abacogroup.agri.applications.core.model.dto.publics.AppByPartyAndYearDTO;
import com.abacogroup.agri.applications.core.model.dto.publics.ApplicationDTO;
import com.abacogroup.agri.applications.core.model.dto.publics.ApplicationWithDetailsDTO;
import com.abacogroup.agri.applications.db.dao.ApplicationDAO;
import com.abacogroup.agri.applications.db.ntt.ApplicationByPartyAndYearNTT;
import com.abacogroup.agri.applications.db.ntt.ApplicationNTT;
import com.abacogroup.agri.applications.db.ntt.ApplicationWithDetailsNTT;
import com.abacogroup.jaxrsutils.filter.MDCPreFilter;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.jdbi.paging.impl.InfiniteListResultsImpl;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@ExtendWith(MockitoExtension.class)
class ApplicationsCrudServiceTest {

	private static final String TENANT = "tenantId";
	private static final String APPLICATION_CODE = "code";
	private static final Long APPLICATION_ID_1 = 1L;
	private static final String APPLICATION_CODE_1 = "app_code_1";
	private static final Long MODULE_ID_1 = 1L;
	private static final String MODULE_CODE_1 = "module_code_1";
	private static final String SECTOR_CODE_1 = "sector_code_1";
	private static final String PROCESS_STATUS_1 = "status_1";
	private static final Integer REFERRED_YEAR = LocalDateTime.now().getYear();
	private static final Long PARTY_ID_1 = 1L;
	private static final Long PROCESS_ID_1 = 1L;
	private static final String USER_1 = "user_1";
	private static final String TENANT_1 = "tenant1";
	private static final String LANG = "LANG";
	private static final LocalDateTime NOW = LocalDateTime.now();
	private static final String PROCESS_STATUS = "start";
	private static final LocalDateTime DEFAULT_NOT_DELETED_DATE = LocalDateTime.ofInstant(Instant.ofEpochSecond(253402300799L), ZoneOffset.UTC);
	private static final AbsoluteDate NOW_ABS_DATE = new AbsoluteDate(NOW.toLocalDate());

	private final ApplicationDTO applicationDTOIn = ApplicationDTO.builder()
			.moduleId(MODULE_ID_1)
			.referredYear(REFERRED_YEAR)
			.partyId(PARTY_ID_1)
			.processId(PROCESS_ID_1)
			.userIdInsert(USER_1)
			.userIdDelete(null)
			.dtInsert(NOW)
			.dtDelete(DEFAULT_NOT_DELETED_DATE)
			.build();

	private final ApplicationDTO applicationDTOOut = ApplicationDTO.builder()
			.applicationId(APPLICATION_ID_1)
			.moduleId(MODULE_ID_1)
			.referredYear(REFERRED_YEAR)
			.partyId(PARTY_ID_1)
			.processId(PROCESS_ID_1)
			.userIdInsert(USER_1)
			.userIdDelete(null)
			.dtInsert(NOW)
			.dtDelete(DEFAULT_NOT_DELETED_DATE)
			.build();

	private final ApplicationNTT applicationNTTMock = ApplicationNTT.builder()
			.id(APPLICATION_ID_1)
			.module_id(MODULE_ID_1)
			.referred_year(REFERRED_YEAR)
			.party_id(PARTY_ID_1)
			.process_id(PROCESS_ID_1)
			.user_id_insert(USER_1)
			.user_id_delete(null)
			.dt_insert(NOW)
			.dt_delete(DEFAULT_NOT_DELETED_DATE)
			.build();

	private final ApplicationWithDetailsDTO applicationWithDetailsDTO = ApplicationWithDetailsDTO.builder()
			.applicationId(APPLICATION_ID_1)
			.moduleId(MODULE_ID_1)
			.referredYear(REFERRED_YEAR)
			.partyId(PARTY_ID_1)
			.processId(PROCESS_ID_1)
			.applicationCode(APPLICATION_CODE)
			.dtPresentation(NOW)
			.processStatus(PROCESS_STATUS)
			.userIdInsert(USER_1)
			.userIdDelete(null)
			.dtInsert(NOW)
			.dtDelete(DEFAULT_NOT_DELETED_DATE)
			.build();

	private final ApplicationWithDetailsNTT applicationWithDetailsNTT = ApplicationWithDetailsNTT.builder()
			.id(APPLICATION_ID_1)
			.module_id(MODULE_ID_1)
			.referred_year(REFERRED_YEAR)
			.party_id(PARTY_ID_1)
			.process_id(PROCESS_ID_1)
			.application_code(APPLICATION_CODE)
			.dt_presentation(NOW)
			.process_status(PROCESS_STATUS)
			.user_id_insert(USER_1)
			.user_id_delete(null)
			.dt_insert(NOW)
			.dt_delete(DEFAULT_NOT_DELETED_DATE)
			.build();

	private final AppByPartyAndYearDTO appByPartyAndYearDTOMock = AppByPartyAndYearDTO.builder()
			.applicationCode(APPLICATION_CODE_1)
			.dtPresentation(NOW_ABS_DATE)
			.moduleCode(MODULE_CODE_1)
			.moduleDescription(null)
			.partyId(PARTY_ID_1)
			.sectorCode(SECTOR_CODE_1)
			.sectorDescription(null)
			.year(REFERRED_YEAR)
			.processStatus(PROCESS_STATUS_1)
			.applicationId(APPLICATION_ID_1)
			.build();

	private final ApplicationByPartyAndYearNTT applicationByPartyAndYearNTT = ApplicationsByPartyAndYearMapper.INSTANCE
			.dtoToEntity(appByPartyAndYearDTOMock);

	@Mock
	private ApplicationMapper applicationMapper;

	@Mock
	private ApplicationDAO applicationDAO;
	@InjectMocks
	private ApplicationsCrudService applicationsCrudService;

	@BeforeEach
	protected void init() {
		applicationsCrudService = new ApplicationsCrudService(applicationDAO, applicationMapper);
		lenient().when(applicationDAO.getCurrentTimestamp()).thenAnswer($ -> LocalDateTime.now());
	}

	@Test
	void test_retrieveCustomKeyByResultSet() {
		assertNull(applicationsCrudService.retrieveCustomKeyByResultSet(applicationNTTMock));
	}

	@Test
	void test_findRsByCustomKey() {
		Optional<ApplicationNTT> result = applicationsCrudService.findRsByCustomKey(null);

		assertEquals(Optional.empty(), result);
	}

	@Test
	void test_findById_optional() {
		when(applicationDAO.findById(MODULE_ID_1))
				.thenReturn(List.of(applicationNTTMock));
		when(applicationMapper.entityToDto(applicationNTTMock))
				.thenReturn(applicationDTOOut);

		Optional<ApplicationDTO> result = applicationsCrudService.findById(MODULE_ID_1);

		assertEquals(Optional.of(applicationDTOOut), result);
	}

	@Test
	void test_findByCode() {
		try {
			when(applicationDAO.findByCode(TENANT, APPLICATION_CODE))
					.thenReturn(List.of(applicationNTTMock));
			when(applicationMapper.entityToDto(applicationNTTMock))
					.thenReturn(applicationDTOOut);

			ApplicationDTO result = applicationsCrudService.findByCode(TENANT, APPLICATION_CODE);

			assertEquals(applicationDTOOut, result);
		} catch (Exception e) {
			fail(e);
		}
	}

	@Test
	void test_findById() {
		try {
			when(applicationDAO.findById(TENANT, APPLICATION_ID_1))
					.thenReturn(List.of(applicationNTTMock));
			when(applicationMapper.entityToDto(applicationNTTMock))
					.thenReturn(applicationDTOOut);

			ApplicationDTO result = applicationsCrudService.findById(TENANT, APPLICATION_ID_1);

			assertEquals(applicationDTOOut, result);
		} catch (Exception e) {
			fail(e);
		}
	}

	@Test
	void test_findByCode_ko() {
		try {
			when(applicationDAO.findByCode(TENANT, APPLICATION_CODE))
					.thenReturn(List.of());

			assertThrows(ObjectNotFoundException.class, () -> applicationsCrudService.findByCode(TENANT, APPLICATION_CODE));
		} catch (Exception e) {
			fail(e);
		}
	}

	@Test
	void test_findById_ko() {
		try {
			when(applicationDAO.findById(TENANT, APPLICATION_ID_1))
					.thenReturn(List.of());

			assertThrows(ObjectNotFoundException.class, () -> applicationsCrudService.findById(TENANT, APPLICATION_ID_1));
		} catch (Exception e) {
			fail(e);
		}
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Test
	void test_insert() {
		try {
			ArgumentCaptor<TransactionalCallback> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(TransactionalCallback.class);
			when(applicationDAO.nextSequenceVal()).thenReturn(MODULE_ID_1);
			when(applicationDAO.findById(MODULE_ID_1)).thenReturn(List.of(applicationNTTMock));
			applicationsCrudService.insert(applicationDTOIn, USER_1);
			when(applicationMapper.dtoToEntity(applicationDTOIn)).thenReturn(applicationNTTMock);
			when(applicationMapper.entityToDto(applicationNTTMock)).thenReturn(applicationDTOOut);

			verify(applicationDAO).inTransaction(handleConsumerLambdaCaptor.capture());

			ApplicationDTO actual = (ApplicationDTO) handleConsumerLambdaCaptor.getValue().inTransaction(applicationDAO);

			assertEquals(applicationDTOOut, actual);
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			fail(e.getMessage(), e);
		}
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Test
	void test_update() {
		try {
			ArgumentCaptor<TransactionalCallback> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(TransactionalCallback.class);
			when(applicationDAO.nextSequenceVal()).thenReturn(MODULE_ID_1);
			when(applicationDAO.getCurrentTimestamp()).thenReturn(LocalDateTime.now());
			when(applicationDAO.findById(MODULE_ID_1)).thenReturn(List.of(applicationNTTMock));
			applicationsCrudService.update(MODULE_ID_1, applicationDTOIn, USER_1);
			when(applicationMapper.dtoToEntity(applicationDTOIn)).thenReturn(applicationNTTMock);
			when(applicationMapper.entityToDto(applicationNTTMock)).thenReturn(applicationDTOOut);

			verify(applicationDAO).inTransaction(handleConsumerLambdaCaptor.capture());

			handleConsumerLambdaCaptor.getValue().inTransaction(applicationDAO);

			verify(applicationDAO, times(2)).inTransaction(handleConsumerLambdaCaptor.capture());

			ApplicationDTO actual = (ApplicationDTO) handleConsumerLambdaCaptor.getValue().inTransaction(applicationDAO);

			assertEquals(applicationDTOOut, actual);
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			fail(e.getMessage(), e);
		}
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Test
	void test_delete() {
		try {
			ArgumentCaptor<TransactionalConsumer> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(TransactionalConsumer.class);
			applicationsCrudService.delete(MODULE_ID_1, USER_1);

			verify(applicationDAO).useTransaction(handleConsumerLambdaCaptor.capture());
			handleConsumerLambdaCaptor.getValue().useTransaction(applicationDAO);
			verify(applicationDAO).logicallyDeleteById(eq(MODULE_ID_1), eq(USER_1), any());
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			fail(e.getMessage(), e);
		}
	}

	@Test
	void test_findWithDetailsByApplicationCode_ok() {
		try {
			when(applicationDAO.findWithDetailByCode(TENANT, APPLICATION_CODE, null)).thenReturn(List.of(applicationWithDetailsNTT));
			assertEquals(applicationWithDetailsDTO, applicationsCrudService.findWithDetailsByApplicationCode(TENANT, APPLICATION_CODE));
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			fail(e.getMessage(), e);
		}
	}

	@Test
	void test_findWithDetailsByApplicationId_ok() {
		when(applicationDAO.findWithDetailById(TENANT, APPLICATION_ID_1, MDC.get(MDCPreFilter.LOCALE)))
				.thenReturn(List.of(applicationWithDetailsNTT));

		ApplicationWithDetailsDTO result = applicationsCrudService.findWithDetailsByApplicationId(TENANT, APPLICATION_ID_1);

		assertEquals(applicationWithDetailsDTO, result);
	}

	@Test
	void test_findWithDetailsByApplicationId_ko_ApplicationNotFoundRuntimeException() {
		when(applicationDAO.findWithDetailById(TENANT, APPLICATION_ID_1, MDC.get(MDCPreFilter.LOCALE)))
				.thenReturn(List.of());

		assertThrows(ApplicationNotFoundRuntimeException.class, () ->
				applicationsCrudService.findWithDetailsByApplicationId(TENANT, APPLICATION_ID_1));
	}

	@Test
	void test_findWithDetailsByApplicationCode_ko_ApplicationNotFoundByCodeRuntimeException() {
		try {
			when(applicationDAO.findWithDetailByCode(TENANT, APPLICATION_CODE, MDC.get(MDCPreFilter.LOCALE)))
					.thenReturn(Collections.emptyList());

			assertThrows(ApplicationNotFoundRuntimeException.class, () -> applicationsCrudService.findWithDetailsByApplicationCode(TENANT, APPLICATION_CODE));

		} catch (Exception e) {
			log.error(e.getMessage(), e);
			fail(e.getMessage(), e);
		}
	}

	@Test
	void test_findAllByPartyId_ok() {
		when(applicationDAO.findAllByPartyId(TENANT_1, PARTY_ID_1)).thenReturn(List.of(applicationNTTMock));
		when(applicationMapper.entityToDto(applicationNTTMock)).thenReturn(applicationDTOOut);

		List<ApplicationDTO> expectedResults = List.of(applicationDTOOut);

		List<ApplicationDTO> results = applicationsCrudService.findAllByPartyId(TENANT_1, PARTY_ID_1);

		assertEquals(expectedResults, results);
	}

	@Test
	void test_find_by_party_and_year() {
		when(applicationDAO.infinite(any(), any(), anyInt())).thenReturn(new InfiniteListResultsImpl<>(List.of(applicationByPartyAndYearNTT), null));

		InfiniteListResults<AppByPartyAndYearDTO> results = applicationsCrudService.find(TENANT_1, PARTY_ID_1, REFERRED_YEAR, LANG);

		assertEquals(List.of(appByPartyAndYearDTOMock), results.getRecords());
	}

	@Test
	void test_findWithModuleCode() {
		when(applicationDAO.find(TENANT, PARTY_ID_1, REFERRED_YEAR, MODULE_CODE_1, MDC.get(MDCPreFilter.LOCALE)))
				.thenReturn(List.of(applicationByPartyAndYearNTT));

		List<AppByPartyAndYearDTO> result = applicationsCrudService.findWithModuleCode(TENANT, PARTY_ID_1, REFERRED_YEAR, MODULE_CODE_1);

		assertEquals(List.of(appByPartyAndYearDTOMock), result);
	}

	@Test
	void findInfiniteResults_ok() {
		InfiniteListResults<Object> mockResult = new InfiniteListResultsImpl<>(List.of(applicationByPartyAndYearNTT), null);
		when(applicationDAO.infinite(any(), any(), anyInt())).thenReturn(mockResult);
		List<AppByPartyAndYearDTO> result = applicationsCrudService
				.findInfiniteResults(TENANT, MODULE_CODE_1, PARTY_ID_1, List.of(REFERRED_YEAR), PROCESS_STATUS, List.of(APPLICATION_ID_1), null, null, null)
				.getRecords();
		assertEquals(List.of(appByPartyAndYearDTOMock), result);
	}

	@Test
	void test_findAllByModuleId() {
		when(applicationDAO.findAllByModuleId(TENANT, MODULE_ID_1))
				.thenReturn(List.of(applicationNTTMock));
		when(applicationMapper.entityToDto(applicationNTTMock))
				.thenReturn(applicationDTOOut);

		List<ApplicationDTO> result = applicationsCrudService.findAllByModuleId(TENANT, MODULE_ID_1);

		assertEquals(List.of(applicationDTOOut), result);
	}

	@Test
	void test_findAllByModuleIdAndPartyIdAndReferredYear() {
		when(applicationDAO.findAllByModuleIdAndPartyIdAndReferredYear(TENANT, MODULE_ID_1, PARTY_ID_1, REFERRED_YEAR))
				.thenReturn(List.of(applicationWithDetailsNTT));

		List<ApplicationWithDetailsDTO> result =
				applicationsCrudService.findAllByModuleIdAndPartyIdAndReferredYear(TENANT, MODULE_ID_1, PARTY_ID_1, REFERRED_YEAR);

		assertEquals(List.of(applicationWithDetailsDTO), result);
	}

	@Test
	void test_getApplicationAndUpdateProcessId() {
		try {
			when(applicationDAO.findById(TENANT, APPLICATION_ID_1))
					.thenReturn(List.of(applicationNTTMock));
			when(applicationMapper.entityToDto(applicationNTTMock))
					.thenReturn(applicationDTOOut);

			applicationsCrudService.getApplicationAndUpdateProcessId(TENANT, APPLICATION_ID_1, PROCESS_ID_1, false);

			verify(applicationDAO, times(1)).updateProcessId(APPLICATION_ID_1, PROCESS_ID_1);
		} catch (Exception e) {
			fail(e);
		}
	}

}
