package com.abacogroup.agri.applications.core.services.crud;

import com.abacogroup.agri.applications.core.exceptions.ObjectNotFoundException;
import com.abacogroup.agri.applications.core.mappers.ModuleCalculationConfigParamMapper;
import com.abacogroup.agri.applications.core.mappers.ModulePrintConfigParamMapper;
import com.abacogroup.agri.applications.core.model.dto.ModuleCalculationConfigParamDTO;
import com.abacogroup.agri.applications.core.model.dto.ModulePrintConfigParamDTO;
import com.abacogroup.agri.applications.db.dao.ModuleCalculationConfigParamDAO;
import com.abacogroup.agri.applications.db.ntt.ModuleCalculationConfigParamNTT;
import com.abacogroup.agri.applications.db.ntt.ModulePrintConfigParamNTT;
import com.abacogroup.agri.applications.db.ntt.compoundkeys.CalculationConfigParamKey;
import com.abacogroup.agri.applications.db.ntt.compoundkeys.PrintConfigParamKey;
import org.jdbi.v3.sqlobject.transaction.TransactionalCallback;
import org.jdbi.v3.sqlobject.transaction.TransactionalConsumer;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class ModuleCalculationConfigParamCrudServiceTest {
    @Mock
    private ModuleCalculationConfigParamDAO moduleCalculationConfigParamDAOMock;
    @Mock
    private ModuleCalculationConfigParamMapper moduleCalculationConfigParamMapperMock;

    @InjectMocks
    private ModuleCalculationConfigParamCrudService moduleCalculationConfigParamCrudService;

    private static final String TENANT = "ADMIN";
    private static final Long MODULE_PRINT_CONFIG_ID = 10L;
    private static final String PARAMETER_NAME = "Parameter name";
    private static final String PARAMETER_VALUE = "Parameter value";

    private final CalculationConfigParamKey calculationConfigParamKey = CalculationConfigParamKey.builder()
            .module_calculation_config_id(MODULE_PRINT_CONFIG_ID)
            .parameter_name(PARAMETER_NAME)
            .build();
    private final ModuleCalculationConfigParamNTT moduleCalculationConfigParamNTT = ModuleCalculationConfigParamNTT.builder()
            .module_calculation_config_id(MODULE_PRINT_CONFIG_ID)
            .parameter_name(PARAMETER_NAME)
            .parameter_value(PARAMETER_VALUE)
            .build();
    private final ModuleCalculationConfigParamDTO moduleCalculationConfigParamDTO = ModuleCalculationConfigParamDTO.builder()
            .moduleCalculationConfigId(MODULE_PRINT_CONFIG_ID)
            .parameterName(PARAMETER_NAME)
            .parameterValue(PARAMETER_VALUE)
            .build();

    @SuppressWarnings({"rawtypes", "unchecked"})
    @Test
    void insert_ok() {
        ModuleCalculationConfigParamDTO payload = ModuleCalculationConfigParamDTO.builder()
                .moduleCalculationConfigId(MODULE_PRINT_CONFIG_ID)
                .parameterValue(PARAMETER_VALUE)
                .parameterName(PARAMETER_NAME)
                .build();

        try {
            ArgumentCaptor<TransactionalCallback> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(TransactionalCallback.class);

            when(moduleCalculationConfigParamMapperMock.dtoToEntity(payload))
                    .thenReturn(moduleCalculationConfigParamNTT);
            when(moduleCalculationConfigParamMapperMock.entityToDto(moduleCalculationConfigParamNTT))
                    .thenReturn(moduleCalculationConfigParamDTO);
            when(moduleCalculationConfigParamDAOMock.findById(MODULE_PRINT_CONFIG_ID, PARAMETER_NAME))
                    .thenReturn(List.of(moduleCalculationConfigParamNTT));

            moduleCalculationConfigParamCrudService.insert(payload);

            verify(moduleCalculationConfigParamDAOMock).inTransaction(handleConsumerLambdaCaptor.capture());

            ModuleCalculationConfigParamDTO result = (ModuleCalculationConfigParamDTO) handleConsumerLambdaCaptor.getValue().inTransaction(moduleCalculationConfigParamDAOMock);

            assertEquals(moduleCalculationConfigParamDTO, result);

        } catch (Exception e) {
            fail(e);
        }

    }

    @SuppressWarnings({"rawtypes", "unchecked"})
    @Test
    void update_ok() {
        ModuleCalculationConfigParamDTO payload = ModuleCalculationConfigParamDTO.builder()
                .moduleCalculationConfigId(MODULE_PRINT_CONFIG_ID)
                .parameterValue(PARAMETER_VALUE)
                .parameterName(PARAMETER_NAME)
                .build();

        try {
            ArgumentCaptor<TransactionalCallback> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(TransactionalCallback.class);

            when(moduleCalculationConfigParamDAOMock.inTransaction(handleConsumerLambdaCaptor.capture()))
                    .thenReturn(moduleCalculationConfigParamDTO);
            when(moduleCalculationConfigParamMapperMock.dtoToEntity(payload))
                    .thenReturn(moduleCalculationConfigParamNTT);
            when(moduleCalculationConfigParamDAOMock.findById(MODULE_PRINT_CONFIG_ID, PARAMETER_NAME))
                    .thenReturn(List.of(moduleCalculationConfigParamNTT));
            when(moduleCalculationConfigParamMapperMock.entityToDto(moduleCalculationConfigParamNTT))
                    .thenReturn(moduleCalculationConfigParamDTO);

            moduleCalculationConfigParamCrudService.update(payload);

            verify(moduleCalculationConfigParamDAOMock).inTransaction(handleConsumerLambdaCaptor.capture());
            ModuleCalculationConfigParamDTO result = (ModuleCalculationConfigParamDTO) handleConsumerLambdaCaptor.getValue().inTransaction(moduleCalculationConfigParamDAOMock);

            assertEquals(moduleCalculationConfigParamDTO, result);
        } catch (Exception e) {
            fail(e);
        }
    }

    @SuppressWarnings({"rawtypes", "unchecked"})
    @Test
    void delete_ok() {
        try {
            ArgumentCaptor<TransactionalConsumer> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(TransactionalConsumer.class);

            moduleCalculationConfigParamCrudService.delete(calculationConfigParamKey);

            verify(moduleCalculationConfigParamDAOMock).useTransaction(handleConsumerLambdaCaptor.capture());
            handleConsumerLambdaCaptor.getValue().useTransaction(moduleCalculationConfigParamDAOMock);

            verify(moduleCalculationConfigParamDAOMock, times(1)).deleteById(MODULE_PRINT_CONFIG_ID, PARAMETER_NAME);
        } catch (Exception e) {
            fail(e);
        }
    }

    @Test
    void deleteByModuleCalculationConfigId_ok() {
        moduleCalculationConfigParamCrudService.deleteByModuleCalculationConfigId(MODULE_PRINT_CONFIG_ID);

        verify(moduleCalculationConfigParamDAOMock, times(1)).deleteByModuleCalculationConfigId(MODULE_PRINT_CONFIG_ID);
    }

    @Test
    void findById_ok() {
        try {
            when(moduleCalculationConfigParamDAOMock.findById(TENANT, MODULE_PRINT_CONFIG_ID, PARAMETER_NAME))
                    .thenReturn(List.of(moduleCalculationConfigParamNTT));
            when(moduleCalculationConfigParamMapperMock.entityToDto(moduleCalculationConfigParamNTT))
                    .thenReturn(moduleCalculationConfigParamDTO);

            ModuleCalculationConfigParamDTO result = moduleCalculationConfigParamCrudService.findById(TENANT, calculationConfigParamKey);

            assertEquals(moduleCalculationConfigParamDTO, result);
        } catch (Exception e) {
            fail(e);
        }
    }

    @Test
    void find_ok() {
        when(moduleCalculationConfigParamDAOMock.find(TENANT, MODULE_PRINT_CONFIG_ID))
                .thenReturn(List.of(moduleCalculationConfigParamNTT));
        when(moduleCalculationConfigParamMapperMock.entityToDto(moduleCalculationConfigParamNTT))
                .thenReturn(moduleCalculationConfigParamDTO);

        List<ModuleCalculationConfigParamDTO> result = moduleCalculationConfigParamCrudService.find(TENANT, MODULE_PRINT_CONFIG_ID);

        assertEquals(List.of(moduleCalculationConfigParamDTO), result);
    }

    @Test
    void findById_ko() {
        try {
            when(moduleCalculationConfigParamDAOMock.findById(TENANT, MODULE_PRINT_CONFIG_ID, PARAMETER_NAME))
                    .thenReturn(List.of());

            assertThrows(ObjectNotFoundException.class, () ->
                    moduleCalculationConfigParamCrudService.findById(TENANT, calculationConfigParamKey));
        } catch (Exception e) {
            fail(e);
        }
    }
}
