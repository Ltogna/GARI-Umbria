package com.abacogroup.agri.applications.core.services;

import static com.abacogroup.agri.applications.core.services.AnomaliesService.ALLOWED_MULTIPLE_APPLICATIONS_VALUE;
import static com.abacogroup.agri.applications.core.services.AnomaliesService.ALREADY_AMENDED_APPLICATION_ERROR_CODE;
import static com.abacogroup.agri.applications.core.services.AnomaliesService.ALREADY_AMENDED_APPLICATION_ERROR_MSG;
import static com.abacogroup.agri.applications.core.services.AnomaliesService.NOT_ALLOWED_MULTIPLE_APPLICATIONS_VALUE;
import static com.abacogroup.agri.applications.core.services.AnomaliesService.NOT_AMENDMENT_MODULE_ERROR_CODE;
import static com.abacogroup.agri.applications.core.services.AnomaliesService.NOT_AMENDMENT_MODULE_ERROR_MSG;
import static com.abacogroup.agri.applications.core.services.AnomaliesService.WAIVED_APPLICATION_ERROR_CODE;
import static com.abacogroup.agri.applications.core.services.AnomaliesService.WAIVED_APPLICATION_ERROR_MSG;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.fail;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.Month;
import java.time.ZoneOffset;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.abacogroup.agri.applications.core.exceptions.ApplicationNotFoundRuntimeException;
import com.abacogroup.agri.applications.core.exceptions.ObjectNotFoundException;
import com.abacogroup.agri.applications.core.exceptions.ObjectNotFoundRuntimeException;
import com.abacogroup.agri.applications.core.model.AbsoluteDate;
import com.abacogroup.agri.applications.core.model.ApplicationAnomaly;
import com.abacogroup.agri.applications.core.model.dto.ApplicationDetailsDTO;
import com.abacogroup.agri.applications.core.model.dto.ModuleDTO;
import com.abacogroup.agri.applications.core.model.dto.ModuleDetailsDTO;
import com.abacogroup.agri.applications.core.model.dto.publics.ApplicationWithDetailsDTO;
import com.abacogroup.agri.applications.core.services.crud.ApplicationDetailsCrudService;
import com.abacogroup.agri.applications.core.services.crud.ApplicationsCrudService;
import com.abacogroup.agri.applications.core.services.crud.CrudServiceContainer;
import com.abacogroup.agri.applications.core.services.crud.ModuleCrudService;
import com.abacogroup.agri.applications.core.services.crud.ModuleDetailsCrudService;

@ExtendWith(MockitoExtension.class)
class AnomaliesServiceTest {

	private static final String TENANT_ID_1 = "tenant_1";
	private static final Long MODULE_ID_1 = 1L;
	private static final String MODULE_CODE_1 = "module_code_1";
	private static final Long SECTOR_ID_1 = 1L;
	private static final Long APPLICATION_ID_1 = 1L;
	private static final Long AMENDED_BY_ID = 2L;
	private static final String APPLICATION_CODE = "code";
	private static final String WORKFLOW_CODE = "workflow_code";
	private static final Long PARTY_ID = 1L;
	private static final Integer REFERRED_YEAR = 2022;
	private static final Long PROCESS_ID_1 = 1L;
	private static final String PROCESS_STATUS = "start";
	private static final String PROCESS_STATUS_DELETED = "DELETED";
	private static final String PROCESS_STATUS_WAIVED = "WAIVED";
	private static final String PROCESS_STATUS_DESCRIPTION = "Inizio Workflow";
	private static final String USER_1 = "user_1";
	private static final LocalDateTime NOW = LocalDateTime.now();
	private static final AbsoluteDate DT_VALIDITY_START = new AbsoluteDate(LocalDate.now());
	private static final AbsoluteDate DT_VALIDITY_START_EMPTY = new AbsoluteDate(LocalDate.of(2020, Month.JANUARY, 1));
	private static final AbsoluteDate DT_VALIDITY_END = new AbsoluteDate(LocalDate.MAX);
	public static final String MODULE_VALIDITY_EXPIRED_ERROR_CODE = "CREATING_APPLICATION_NOT_IN_VALIDITY_PERIOD_ERROR_CODE";
	public static final String MODULE_VALIDITY_EXPIRED_ERROR_MSG = "This module's validity is expired";
	private static final Map<String, Object> METADATA_with_multipleApps = Map
			.of(AnomaliesService.METADATA_KEY_MULTIPLE_APPLICATIONS, ALLOWED_MULTIPLE_APPLICATIONS_VALUE);
	private static final Map<String, Object> METADATA_without_multipleApps = Map
			.of(AnomaliesService.METADATA_KEY_MULTIPLE_APPLICATIONS, NOT_ALLOWED_MULTIPLE_APPLICATIONS_VALUE);
	private static final LocalDateTime DEFAULT_NOT_DELETED_DATE = LocalDateTime.ofInstant(Instant.ofEpochSecond(253402300799L), ZoneOffset.UTC);
	private final ModuleDTO moduleDTOOut = ModuleDTO.builder()
			.moduleId(MODULE_ID_1)
			.moduleCode(MODULE_CODE_1)
			.sectorId(SECTOR_ID_1)
			.workflowCode(WORKFLOW_CODE)
			.build();
	private final ModuleDTO notAmendModule = ModuleDTO.builder()
			.moduleId(MODULE_ID_1)
			.moduleCode(MODULE_CODE_1)
			.sectorId(SECTOR_ID_1)
			.workflowCode(WORKFLOW_CODE)
			.flAmendModule(false)
			.build();
	private final ModuleDTO amendModule = ModuleDTO.builder()
			.moduleId(MODULE_ID_1)
			.moduleCode(MODULE_CODE_1)
			.sectorId(SECTOR_ID_1)
			.workflowCode(WORKFLOW_CODE)
			.flAmendModule(true)
			.build();

	private final ApplicationWithDetailsDTO applicationWithDetailsDTO = ApplicationWithDetailsDTO.builder()
			.applicationId(APPLICATION_ID_1)
			.moduleId(MODULE_ID_1)
			.referredYear(REFERRED_YEAR)
			.partyId(PARTY_ID)
			.processId(PROCESS_ID_1)
			.applicationCode(APPLICATION_CODE)
			.dtPresentation(NOW)
			.processStatus(PROCESS_STATUS)
			.processStatusDescription(PROCESS_STATUS_DESCRIPTION)
			.userIdInsert(USER_1)
			.userIdDelete(null)
			.dtInsert(NOW)
			.dtDelete(DEFAULT_NOT_DELETED_DATE)
			.build();
	private final ApplicationDetailsDTO applicationDetails = ApplicationDetailsDTO.builder()
			.applicationId(APPLICATION_ID_1)
			.applicationCode(APPLICATION_CODE)
			.amendedById(AMENDED_BY_ID)
			.processStatus(PROCESS_STATUS)
			.build();
	private final ApplicationDetailsDTO applicationDetailsWaived = ApplicationDetailsDTO.builder()
			.applicationId(APPLICATION_ID_1)
			.applicationCode(APPLICATION_CODE)
			.amendedById(AMENDED_BY_ID)
			.processStatus(PROCESS_STATUS_WAIVED)
			.build();
	private final ApplicationDetailsDTO applicationDetailsWithoutAmendedById = ApplicationDetailsDTO.builder()
			.applicationId(APPLICATION_ID_1)
			.applicationCode(APPLICATION_CODE)
			.processStatus(PROCESS_STATUS)
			.build();
	private final ApplicationDetailsDTO deletedApplicationDetails = ApplicationDetailsDTO.builder()
			.applicationId(APPLICATION_ID_1)
			.applicationCode(APPLICATION_CODE)
			.amendedById(AMENDED_BY_ID)
			.processStatus(PROCESS_STATUS_DELETED)
			.build();

	@Mock
	private ApplicationsService applicationsService;
	@Mock
	private ModuleCrudService moduleCrudService;
	@Mock
	private ApplicationsCrudService applicationsCrudService;
	@Mock
	private ApplicationDetailsCrudService applicationDetailsCrudService;
	@Mock
	private ModuleDetailsCrudService moduleDetailsCrudService;

	private AnomaliesService anomaliesService;

	@BeforeEach
	void init() {
		CrudServiceContainer crudServiceContainer = CrudServiceContainer.builder()
				.moduleCrudService(moduleCrudService)
				.applicationsCrudService(applicationsCrudService)
				.moduleDetailsCrudService(moduleDetailsCrudService)
				.applicationDetailsCrudService(applicationDetailsCrudService)
				.build();

		anomaliesService = new AnomaliesService(applicationsService, crudServiceContainer);
	}

	@Test
	void test_ok_checkForModuleDateValidity() {
		ModuleDetailsDTO moduleDetails = ModuleDetailsDTO.builder()
				.dtValidityStart(DT_VALIDITY_START)
				.dtValidityEnd(DT_VALIDITY_END)
				.build();

		List<ApplicationAnomaly> expectedOutput = List.of(ApplicationAnomaly.builder()
				.code(MODULE_VALIDITY_EXPIRED_ERROR_CODE)
				.message(MODULE_VALIDITY_EXPIRED_ERROR_MSG)
				.build());

		List<ApplicationAnomaly> result = anomaliesService.checkForModuleDateValidity(moduleDetails);

		assertEquals(expectedOutput, result);
	}

	@Test
	void test_ok_checkForModuleDateValidity_empty() {
		ModuleDetailsDTO moduleDetails = ModuleDetailsDTO.builder()
				.dtValidityStart(DT_VALIDITY_START_EMPTY)
				.dtValidityEnd(DT_VALIDITY_END)
				.build();

		when(moduleDetailsCrudService.checkValidityByPkId(any())).thenReturn(moduleDetails);
		List<ApplicationAnomaly> result = anomaliesService.checkForModuleDateValidity(moduleDetails);

		assertEquals(List.of(), result);
	}

	@Test
	void test_ok_checkForMultipleApplication_no_anomalies() {
		when(moduleCrudService.findByCode(TENANT_ID_1, MODULE_CODE_1)).thenReturn(Optional.of(moduleDTOOut));
		when(applicationsCrudService.findAllByModuleIdAndPartyIdAndReferredYear(TENANT_ID_1, MODULE_ID_1, PARTY_ID, REFERRED_YEAR)).thenReturn(
				List.of(applicationWithDetailsDTO));
		when(applicationsService.checkForMetadata(TENANT_ID_1, applicationWithDetailsDTO)).thenReturn(METADATA_with_multipleApps);
		assertEquals(Collections.emptyList(), anomaliesService.checkForMultipleApplication(TENANT_ID_1, MODULE_CODE_1, PARTY_ID, REFERRED_YEAR));
	}

	@Test
	void test_ok_checkForMultipleApplication_with_anomalies() {
		when(moduleCrudService.findByCode(TENANT_ID_1, MODULE_CODE_1)).thenReturn(Optional.of(moduleDTOOut));
		when(applicationsCrudService.findAllByModuleIdAndPartyIdAndReferredYear(TENANT_ID_1, MODULE_ID_1, PARTY_ID, REFERRED_YEAR)).thenReturn(
				List.of(applicationWithDetailsDTO));
		when(applicationsService.checkForMetadata(TENANT_ID_1, applicationWithDetailsDTO)).thenReturn(METADATA_without_multipleApps);
		assertEquals(List.of(ApplicationAnomaly.builder()
				.code(AnomaliesService.MULTIPLE_APPLICATIONS_ERROR_CODE)
				.message(AnomaliesService.MULTIPLE_APPLICATIONS_ERROR_MSG)
				.build()), anomaliesService.checkForMultipleApplication(TENANT_ID_1, MODULE_CODE_1, PARTY_ID, REFERRED_YEAR));
	}

	@Test
	void test_ko_checkForMultipleApplication_moduleNotFound() {
		when(moduleCrudService.findByCode(TENANT_ID_1, MODULE_CODE_1)).thenReturn(Optional.empty());
		assertThrows(ObjectNotFoundRuntimeException.class, () ->
				anomaliesService.checkForMultipleApplication(TENANT_ID_1, MODULE_CODE_1, PARTY_ID, REFERRED_YEAR));
	}

	@Test
	void checkForAmendmentModule_withAnomalies_ok() {
		ApplicationAnomaly expectedOutput = ApplicationAnomaly.builder()
				.code(NOT_AMENDMENT_MODULE_ERROR_CODE)
				.message(NOT_AMENDMENT_MODULE_ERROR_MSG)
				.build();

		List<ApplicationAnomaly> result = anomaliesService.checkForAmendmentModule(notAmendModule);

		assertEquals(List.of(expectedOutput), result);
	}

	@Test
	void checkForAmendmentModule_withoutAnomalies_ok() {
		List<ApplicationAnomaly> result = anomaliesService.checkForAmendmentModule(amendModule);

		assertEquals(List.of(), result);
	}

	@Test
	void checkForApplicationNotAmended_ok() {
		try {
			ApplicationAnomaly expectedOutput = ApplicationAnomaly.builder()
					.code(ALREADY_AMENDED_APPLICATION_ERROR_CODE)
					.message(ALREADY_AMENDED_APPLICATION_ERROR_MSG)
					.build();

			when(applicationDetailsCrudService.findApplicationDetailById(TENANT_ID_1, APPLICATION_ID_1))
					.thenReturn(applicationDetails);
			when(applicationDetailsCrudService.findApplicationDetailById(TENANT_ID_1, AMENDED_BY_ID))
					.thenReturn(applicationDetails);

			List<ApplicationAnomaly> result = anomaliesService.checkForApplicationNotAmended(TENANT_ID_1, APPLICATION_ID_1);

			assertEquals(List.of(expectedOutput), result);
		} catch (Exception e) {
			fail(e);
		}
	}

	@Test
	void checkForApplicationNotAmended_withoutAmendedById_ok() {
		try {
			when(applicationDetailsCrudService.findApplicationDetailById(TENANT_ID_1, APPLICATION_ID_1))
					.thenReturn(applicationDetailsWithoutAmendedById);

			List<ApplicationAnomaly> result = anomaliesService.checkForApplicationNotAmended(TENANT_ID_1, APPLICATION_ID_1);

			assertEquals(List.of(), result);
		} catch (Exception e) {
			fail(e);
		}
	}

	@Test
	void checkForApplicationNotAmended_deletedApplication_ok() {
		try {
			when(applicationDetailsCrudService.findApplicationDetailById(TENANT_ID_1, APPLICATION_ID_1))
					.thenReturn(applicationDetails);
			when(applicationDetailsCrudService.findApplicationDetailById(TENANT_ID_1, AMENDED_BY_ID))
					.thenReturn(deletedApplicationDetails);

			List<ApplicationAnomaly> result = anomaliesService.checkForApplicationNotAmended(TENANT_ID_1, APPLICATION_ID_1);

			assertEquals(List.of(), result);
		} catch (Exception e) {
			fail(e);
		}
	}

	@Test
	void checkForApplicationNotAmended_ko() {
		try {
			when(applicationDetailsCrudService.findApplicationDetailById(TENANT_ID_1, APPLICATION_ID_1))
					.thenThrow(ObjectNotFoundException.class);

			assertThrows(ApplicationNotFoundRuntimeException.class, () ->
					anomaliesService.checkForApplicationNotAmended(TENANT_ID_1, APPLICATION_ID_1));
		} catch (Exception e) {
			fail(e);
		}
	}

	@Test
	void checkForApplicationWaived_ok() {
		try {
			ApplicationAnomaly expectedOutput = ApplicationAnomaly.builder()
					.code(WAIVED_APPLICATION_ERROR_CODE)
					.message(WAIVED_APPLICATION_ERROR_MSG)
					.build();

			when(applicationDetailsCrudService.findApplicationDetailById(TENANT_ID_1, APPLICATION_ID_1))
					.thenReturn(applicationDetailsWaived);

			List<ApplicationAnomaly> result = anomaliesService.checkForApplicationWaived(TENANT_ID_1, APPLICATION_ID_1);

			assertEquals(List.of(expectedOutput), result);
		} catch (Exception e) {
			fail(e);
		}
	}

	@Test
	void checkForApplicationWaived_notWaived_ok() {
		try {
			when(applicationDetailsCrudService.findApplicationDetailById(TENANT_ID_1, APPLICATION_ID_1))
					.thenReturn(applicationDetails);

			List<ApplicationAnomaly> result = anomaliesService.checkForApplicationWaived(TENANT_ID_1, APPLICATION_ID_1);

			assertEquals(List.of(), result);
		} catch (Exception e) {
			fail(e);
		}
	}

	@Test
	void checkForApplicationWaived_ko() {
		try {
			when(applicationDetailsCrudService.findApplicationDetailById(TENANT_ID_1, APPLICATION_ID_1))
					.thenThrow(ObjectNotFoundException.class);

			assertThrows(ApplicationNotFoundRuntimeException.class, () ->
					anomaliesService.checkForApplicationWaived(TENANT_ID_1, APPLICATION_ID_1));
		} catch (Exception e) {
			fail(e);
		}
	}
}
