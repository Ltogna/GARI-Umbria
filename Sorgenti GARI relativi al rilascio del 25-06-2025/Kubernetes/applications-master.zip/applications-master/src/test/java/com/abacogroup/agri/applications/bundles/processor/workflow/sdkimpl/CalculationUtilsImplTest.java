package com.abacogroup.agri.applications.bundles.processor.workflow.sdkimpl;

import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.File;
import java.io.IOException;
import java.net.URISyntaxException;
import java.nio.file.Files;
import java.util.HashMap;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.abacogroup.agri.applications.core.services.calculation.CalculationService;
import com.abacogroup.agri.applications.core.services.crud.ApplicationProfilesCrudService;
import com.abacogroup.agri.applications.core.services.crud.ApplicationsCrudService;
import com.abacogroup.agri.applications.core.services.workflow.sdkimpl.CalculationUtilsImpl;
import com.abacogroup.dropwizard.auth.sso2.Sso2Client;
import com.fasterxml.jackson.databind.ObjectMapper;

@ExtendWith(MockitoExtension.class)
class CalculationUtilsImplTest {

	@Mock
	private ApplicationsCrudService applicationsCrudService;
	@Mock
	private ApplicationProfilesCrudService applicationProfilesCrudService;
	@Mock
	private CalculationService calculationService;
	@Mock
	private Sso2Client sso2Client;

	@InjectMocks
	private CalculationUtilsImpl calculationUtils;

	@Test
	void test_parse() throws IOException, URISyntaxException {
		ObjectMapper om = new ObjectMapper();
		ClassLoader classLoader = getClass().getClassLoader();
		File file = new File(classLoader.getResource("parseTest.txt").getFile());
		String text = new String(Files.readAllBytes(file.toPath()));
		var s = calculationUtils.parseResult(text, HashMap.class, om);
		System.out.println(s);
		var t = calculationUtils.parseResult(s.get("result").toString(), HashMap.class, om);
		System.out.println(t);

		assertTrue(true);
	}

}
