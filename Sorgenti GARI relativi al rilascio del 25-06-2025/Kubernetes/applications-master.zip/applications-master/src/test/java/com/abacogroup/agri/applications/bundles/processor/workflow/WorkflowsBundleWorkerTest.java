package com.abacogroup.agri.applications.bundles.processor.workflow;

import com.abacogroup.agri.applications.bundles.processor.workflow.WorkflowsBundleWorker;
import com.abacogroup.agri.applications.core.services.workflow.ApplicationsWorkflowService;
import com.abacogroup.bundles.listener.configdata.ConfigDataMessage;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.io.File;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.fail;
import static org.mockito.Mockito.verify;

@Slf4j
@ExtendWith(MockitoExtension.class)
class WorkflowsBundleWorkerTest {

	protected static final String TEMPLATE_TENANT_ID = "*";
	private final File workflowFileInputMock = new File("TMWorkflow_A.zip");

	private final ConfigDataMessage configDataMessage = new ConfigDataMessage();
	@InjectMocks
	private WorkflowsBundleWorker workflowsBundleWorker;
	@Mock
	private ApplicationsWorkflowService taskManagerWorkflowService;

	@BeforeEach
	void init() {
		configDataMessage.setTenantId(TEMPLATE_TENANT_ID);
		workflowsBundleWorker = new WorkflowsBundleWorker(taskManagerWorkflowService);
	}

	@Test
	void test_insertBundleWorkflow_ok() {
		try {
			workflowsBundleWorker.insertBundleWorkflow(TEMPLATE_TENANT_ID, workflowFileInputMock);
			verify(taskManagerWorkflowService).addOrUpdateWorkflowFromFile(TEMPLATE_TENANT_ID, workflowFileInputMock);
		} catch (Exception e) {
			fail(e.getMessage(), e);
		}
	}

	@Test
	void test_exposeWorkflowsService() {
		assertEquals(taskManagerWorkflowService, workflowsBundleWorker.exposeApplicationsWorkflowService());
	}

}
