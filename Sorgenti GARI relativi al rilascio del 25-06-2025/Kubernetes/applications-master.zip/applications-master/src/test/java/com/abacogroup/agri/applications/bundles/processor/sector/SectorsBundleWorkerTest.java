package com.abacogroup.agri.applications.bundles.processor.sector;

import com.abacogroup.agri.applications.bundles.model.I18nPair;
import com.abacogroup.agri.applications.bundles.model.sector.BundleSectorInDTO;
import com.abacogroup.agri.applications.bundles.model.sector.BundleSectorsMessage;
import com.abacogroup.agri.applications.core.exceptions.ObjectNotFoundException;
import com.abacogroup.agri.applications.core.services.crud.SectorsCrudService;
import com.abacogroup.bundles.listener.configdata.ConfigDataMessage;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.fail;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@Slf4j
@ExtendWith(MockitoExtension.class)
class SectorsBundleWorkerTest {

	protected static final String TEMPLATE_TENANT_ID = "*";
	protected static final String SECTOR_CODE = "sector_code";
	private static final String DESCRIPTION = "description";
	private static final String LANG = "lang";

	private final I18nPair sectorI18nMock = I18nPair.builder()
			.description(DESCRIPTION)
			.lang(LANG)
			.build();

	private final BundleSectorInDTO bundleSectorInDTOMock = BundleSectorInDTO.builder()
			.sectorCode(SECTOR_CODE)
			.i18n(List.of(sectorI18nMock))
			.build();

	private final BundleSectorsMessage bundleSectorsMessageMock = BundleSectorsMessage.builder()
			.sectors(List.of(bundleSectorInDTOMock))
			.build();

	private final ConfigDataMessage configDataMessage = new ConfigDataMessage();
	@InjectMocks
	private SectorsBundleWorker sectorsBundleWorker;
	@Mock
	private SectorsCrudService sectorsCrudService;

	@BeforeEach
	void init() {
		configDataMessage.setTenantId(TEMPLATE_TENANT_ID);
		sectorsBundleWorker = new SectorsBundleWorker(sectorsCrudService);
	}

	@Test
	void test_insertBundleSectors_ok() {
		try {
			when(sectorsCrudService.findSectorByCode(any(), any())).thenThrow(new ObjectNotFoundException("not found"));
			sectorsBundleWorker.upsertBundleSectors(TEMPLATE_TENANT_ID, bundleSectorsMessageMock);
			verify(sectorsCrudService).insert(any());
			verify(sectorsCrudService).insertSectorI18N(TEMPLATE_TENANT_ID, SECTOR_CODE, sectorI18nMock.getLang(),
					sectorI18nMock.getDescription());
		} catch (Exception e) {
			fail(e.getMessage(), e);
		}
	}

	@Test
	void test_exposeSectorsService() {
		assertEquals(sectorsCrudService, sectorsBundleWorker.exposeSectorsCrudService());
	}

}
