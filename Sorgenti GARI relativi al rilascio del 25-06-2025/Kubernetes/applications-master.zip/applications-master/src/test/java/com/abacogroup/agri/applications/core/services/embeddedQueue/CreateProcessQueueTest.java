package com.abacogroup.agri.applications.core.services.embeddedQueue;

import com.abacogroup.agri.applications.core.services.embededqueue.CreateProcessQueue;
import com.abacogroup.agri.applications.core.services.workflow.ApplicationsWorkflowService;
import com.abacogroup.applicationworkflowsdk.model.ApplicationsWorkflowParams;
import com.abacogroup.embeddedqueue.QueueErrorListener;
import com.abacogroup.embeddedqueue.ThrowingConsumer;
import com.abacogroup.embeddedqueue.db.JdbiRepository;
import com.codahale.metrics.MetricRegistry;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.Mock.Strictness;
import org.mockito.junit.jupiter.MockitoExtension;
import java.util.Map;
import static com.abacogroup.embeddedqueue.QueueErrorListener.ErrorAction.RESCHEDULE;
import static org.mockito.Mockito.when;

/**
 * The type Create process queue test.
 * 
 * @author Carlo Sindico
 */
@Slf4j
@ExtendWith(MockitoExtension.class)
class CreateProcessQueueTest {
    @Mock(strictness = Strictness.LENIENT)
    private JdbiRepository repository;

    @Mock
    private ObjectMapper objectMapper;

    @Mock
    private MetricRegistry registry;

    @Mock
    private ApplicationsWorkflowService applicationsWorkflowService;

    private CreateProcessQueue createProcessQueue;

    @BeforeEach
    void init() {
        long timeoutMs = 10000L;
        int numThreads = 1;

        when(repository.computeHostName()).thenReturn("test-host");

        createProcessQueue = new CreateProcessQueue(repository, objectMapper, registry,
                applicationsWorkflowService, numThreads, timeoutMs);
    }

    @Test
    void test_doTheJob() {
        try {
            ThrowingConsumer<ApplicationsWorkflowParams> doTheJob = appParams -> applicationsWorkflowService
                    .createProcess(appParams.getTenant(), appParams.getApplicationId(),
                            appParams.getUsername(), appParams.getWorkflowCode(),
                            appParams.getLocale(), Map.of(ApplicationsWorkflowParams.KEY, appParams));
        } catch (Exception e) {
            Assertions.fail();
        }
    }

    @Test
    void test_handleError() {
        try {
            QueueErrorListener<ApplicationsWorkflowParams> handleError = (appParams, exp) -> RESCHEDULE;
        } catch (Exception e) {
            Assertions.fail();
        }
    }

}
