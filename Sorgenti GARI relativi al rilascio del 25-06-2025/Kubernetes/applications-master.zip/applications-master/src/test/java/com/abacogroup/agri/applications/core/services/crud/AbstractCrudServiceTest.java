package com.abacogroup.agri.applications.core.services.crud;

import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

import lombok.extern.log4j.Log4j;

@Log4j
@ExtendWith(MockitoExtension.class)
class AbstractCrudServiceTest {

	// TASK TYPE 1
	private static final String TYPE_CODE_1 = "type-code-1";
	private static final Long TYPE_CATEGORY_ID_1 = 12L;
	private static final String TYPE_DAY_FROM_1 = "20220606";
	private static final String TYPE_DAY_TO_1 = "20220612";
	private static final String TYPE_TENANT_ID_1 = "tenant1";
	private static final String TYPE_WF_TYPE_CODE_1 = "wf-code-1";
	private static final Long TYPE_ID_1 = 36L;
	private static final String TYPE_DOCUMENT_TYPE_CODE_1 = "doc-type-code-1";

	private static final Long DAO_NEXT_VALUE = 24L;

	@Test
	void simpleTest() {
		// Simple test for sonar issue
		assertTrue(true);
	}
/* TODO fix this
	private static final RsTaskTypes rsTaskType1 = RsTaskTypes.builder()
			.category_id(TYPE_CATEGORY_ID_1)
			.code(TYPE_CODE_1)
			.day_from(TYPE_DAY_FROM_1)
			.day_to(TYPE_DAY_TO_1)
			.tenant_id(TYPE_TENANT_ID_1)
			.workflow_type_code(TYPE_WF_TYPE_CODE_1)
			.build();
	private final TaskTypesInDTO taskTypeIn = TaskTypesInDTO.builder()
			.code(TYPE_CODE_1)
			.categoryId(TYPE_CATEGORY_ID_1)
			.dayFrom(TYPE_DAY_FROM_1)
			.dayTo(TYPE_DAY_TO_1)
			.tenantId(TYPE_TENANT_ID_1)
			.workflowTypeCode(TYPE_WF_TYPE_CODE_1)
			.build();
	private final List<RsTaskTypes> taskTypes = new ArrayList<>(List.of(
			rsTaskType1));
	private final TaskTypesOutDTO expectedTaskTypeOut1 = TaskTypesOutDTO.builder()
			.categoryId(TYPE_CATEGORY_ID_1)
			.code(TYPE_CODE_1)
			.dayFrom(TYPE_DAY_FROM_1)
			.dayTo(TYPE_DAY_TO_1)
			.documentTypeCode(TYPE_DOCUMENT_TYPE_CODE_1)
			.id(TYPE_ID_1)
			.tenantId(TYPE_TENANT_ID_1)
			.workflowTypeCode(TYPE_WF_TYPE_CODE_1)
			.build();
	AbstractCrudServiceImplementation serviceImpl;
	@Mock
	private TaskTypesDAO dao;
	@Mock
	private Function<RsTaskTypes, TaskTypesOutDTO> mapFromRtoO;
	@Mock
	private Function<TaskTypesInDTO, RsTaskTypes> mapFromItoR;

	private static TaskTypesOutDTO InToOut(RsTaskTypes res) {
		return TaskTypesOutDTO.builder()
				.categoryId(TYPE_CATEGORY_ID_1)
				.code(TYPE_CODE_1)
				.dayFrom(TYPE_DAY_FROM_1)
				.dayTo(TYPE_DAY_TO_1)
				.documentTypeCode(TYPE_DOCUMENT_TYPE_CODE_1)
				.id(TYPE_ID_1)
				.tenantId(TYPE_TENANT_ID_1)
				.workflowTypeCode(TYPE_WF_TYPE_CODE_1)
				.build();
	}

	@Test
	void retrievePrimaryKey_ok() {
		when(dao.nextSequenceVal()).thenReturn(DAO_NEXT_VALUE);

		serviceImpl = new AbstractCrudServiceImplementation(dao, mapFromItoR, mapFromRtoO);
		assertEquals(DAO_NEXT_VALUE, serviceImpl.retrievePrimaryKey(null));
	}

	@Test
	void testInsert_ok() {
		try {
			ArgumentCaptor<TransactionalCallback> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(TransactionalCallback.class);

			when(mapFromItoR.apply(taskTypeIn)).thenReturn(rsTaskType1);
			when(dao.nextSequenceVal()).thenReturn(1L);

			when(dao.findById(1L)).thenReturn(taskTypes);

			mapFromRtoO = AbstractCrudServiceTest::InToOut;

			serviceImpl = new AbstractCrudServiceImplementation(dao, mapFromItoR, mapFromRtoO);
			serviceImpl.insert(taskTypeIn, null);

			verify(dao).inTransaction(handleConsumerLambdaCaptor.capture());

			TaskTypesOutDTO brgHeaderOut = (TaskTypesOutDTO) handleConsumerLambdaCaptor.getValue().inTransaction(dao);

			assertEquals(expectedTaskTypeOut1, brgHeaderOut);
		} catch (Exception e) {
			fail(e.getMessage());
		}
	}

	@Test
	void testInsert_customKey_ok() {
		try {
			String customKey = TYPE_CODE_1;

			ArgumentCaptor<TransactionalCallback> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(TransactionalCallback.class);

			when(mapFromItoR.apply(taskTypeIn)).thenReturn(rsTaskType1);
			when(dao.nextSequenceVal()).thenReturn(DAO_NEXT_VALUE);

			mapFromRtoO = AbstractCrudServiceTest::InToOut;

			serviceImpl = new AbstractCrudServiceImplementation(dao, mapFromItoR, mapFromRtoO);
			serviceImpl.insert(taskTypeIn, customKey);

			verify(dao).inTransaction(handleConsumerLambdaCaptor.capture());

			TaskTypesOutDTO brgHeaderOut = (TaskTypesOutDTO) handleConsumerLambdaCaptor.getValue().inTransaction(dao);

			assertEquals(expectedTaskTypeOut1, brgHeaderOut);
		} catch (Exception e) {
			fail(e.getMessage());
		}
	}

	@Test
	void testInsert_Forbidden_ko() {
		ArgumentCaptor<TransactionalCallback> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(TransactionalCallback.class);

		when(mapFromItoR.apply(taskTypeIn)).thenReturn(rsTaskType1);
		when(dao.nextSequenceVal()).thenReturn(1L);

		mapFromRtoO = AbstractCrudServiceTest::InToOut;
		serviceImpl = new AbstractCrudServiceImplementation(dao, mapFromItoR, mapFromRtoO);

		serviceImpl.insert(taskTypeIn, null);

		verify(dao).inTransaction(handleConsumerLambdaCaptor.capture());
		TransactionalCallback transactionalCallback = handleConsumerLambdaCaptor.getValue();
		assertThrows(ObjectNotFoundRuntimeException.class, () -> transactionalCallback.inTransaction(dao));
	}

	@Test
	void testInsert_ObjectNotFound_ko() {
		ArgumentCaptor<TransactionalCallback> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(TransactionalCallback.class);

		when(mapFromItoR.apply(taskTypeIn)).thenReturn(rsTaskType1);
		when(dao.nextSequenceVal()).thenReturn(1L);

		mapFromRtoO = AbstractCrudServiceTest::InToOut;
		serviceImpl = new AbstractCrudServiceImplementation(dao, mapFromItoR, mapFromRtoO);

		serviceImpl.insert(taskTypeIn, null);

		verify(dao).inTransaction(handleConsumerLambdaCaptor.capture());
		TransactionalCallback transactionalCallback = handleConsumerLambdaCaptor.getValue();
		assertThrows(ObjectNotFoundRuntimeException.class, () -> transactionalCallback.inTransaction(dao));
	}

	@Test
	void testUpdate_ok() {
		try {
			ArgumentCaptor<TransactionalCallback> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(TransactionalCallback.class);

			when(mapFromItoR.apply(taskTypeIn)).thenReturn(rsTaskType1);

			when(dao.findById(TYPE_ID_1)).thenReturn(taskTypes);
			mapFromRtoO = AbstractCrudServiceTest::InToOut;

			serviceImpl = new AbstractCrudServiceImplementation(dao, mapFromItoR, mapFromRtoO);
			serviceImpl.update(TYPE_ID_1, taskTypeIn, null);

			verify(dao).inTransaction(handleConsumerLambdaCaptor.capture());

			TaskTypesOutDTO brgHeaderOut = (TaskTypesOutDTO) handleConsumerLambdaCaptor.getValue().inTransaction(dao);

			assertEquals(expectedTaskTypeOut1, brgHeaderOut);
		} catch (Exception e) {
			fail(e.getMessage(), e);
		}
	}

	@Test
	void testUpdate_customKey_ok() {
		try {
			String customKey = TYPE_CODE_1;

			ArgumentCaptor<TransactionalCallback> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(TransactionalCallback.class);

			when(mapFromItoR.apply(taskTypeIn)).thenReturn(rsTaskType1);

			mapFromRtoO = AbstractCrudServiceTest::InToOut;

			serviceImpl = new AbstractCrudServiceImplementation(dao, mapFromItoR, mapFromRtoO);
			serviceImpl.update(TYPE_ID_1, taskTypeIn, customKey);

			verify(dao).inTransaction(handleConsumerLambdaCaptor.capture());

			TaskTypesOutDTO taskTypeOut = (TaskTypesOutDTO) handleConsumerLambdaCaptor.getValue().inTransaction(dao);

			assertEquals(expectedTaskTypeOut1, taskTypeOut);
		} catch (Exception e) {
			fail(e.getMessage(), e);
		}
	}

	@Test
	void testUpdate_forbiddenException_ko() {
		try {
			ArgumentCaptor<TransactionalCallback> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(TransactionalCallback.class);

			when(mapFromItoR.apply(taskTypeIn)).thenReturn(rsTaskType1);
			when(dao.findById(TYPE_ID_1)).thenReturn(taskTypes);

			mapFromRtoO = AbstractCrudServiceTest::InToOut;

			serviceImpl = new AbstractCrudServiceImplementation(dao, mapFromItoR, mapFromRtoO);
			serviceImpl.update(TYPE_ID_1, taskTypeIn, null);

			verify(dao).inTransaction(handleConsumerLambdaCaptor.capture());

			handleConsumerLambdaCaptor.getValue().inTransaction(dao);

		} catch (Exception e) {
			assertTrue(e instanceof ForbiddenException);
		}
	}

	@Test
	void testUpdate_ObjectNotFound_ko() {
		ArgumentCaptor<TransactionalCallback> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(TransactionalCallback.class);

		when(mapFromItoR.apply(taskTypeIn)).thenReturn(rsTaskType1);

		mapFromRtoO = AbstractCrudServiceTest::InToOut;

		serviceImpl = new AbstractCrudServiceImplementation(dao, mapFromItoR, mapFromRtoO);
		serviceImpl.update(TYPE_ID_1, taskTypeIn, null);

		verify(dao).inTransaction(handleConsumerLambdaCaptor.capture());
		TransactionalCallback transactionalCallback = handleConsumerLambdaCaptor.getValue();
		assertThrows(ObjectNotFoundRuntimeException.class, () -> {
			transactionalCallback.inTransaction(dao);
		});

	}

	@Test
	void testDelete_ok() {
		try {
			ArgumentCaptor<TransactionalConsumer> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(TransactionalConsumer.class);

			mapFromRtoO = AbstractCrudServiceTest::InToOut;

			serviceImpl = new AbstractCrudServiceImplementation(dao, mapFromItoR, mapFromRtoO);
			serviceImpl.delete(TYPE_ID_1, null);

			verify(dao).useTransaction(handleConsumerLambdaCaptor.capture());

			handleConsumerLambdaCaptor.getValue().useTransaction(dao);

			verify(dao, times(1)).deleteById(TYPE_ID_1);
		} catch (Exception e) {
			fail(e.getMessage(), e);
		}
	}

	@Test
	void testDelete_customKey_ok() {
		try {
			String customKey = TYPE_CODE_1;

			ArgumentCaptor<TransactionalConsumer> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(TransactionalConsumer.class);

			mapFromRtoO = AbstractCrudServiceTest::InToOut;

			serviceImpl = Mockito.spy(new AbstractCrudServiceImplementation(dao, mapFromItoR, mapFromRtoO));
			serviceImpl.delete(TYPE_ID_1, customKey);

			verify(dao).useTransaction(handleConsumerLambdaCaptor.capture());

			handleConsumerLambdaCaptor.getValue().useTransaction(dao);

			verify(serviceImpl, times(1)).deleteByCustomKey(customKey);
		} catch (Exception e) {
			fail(e.getMessage(), e);
		}
	}

	@Test
	void testDeleteWithoutPartyId_ok() {
		try {
			ArgumentCaptor<TransactionalConsumer> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(TransactionalConsumer.class);

			mapFromRtoO = AbstractCrudServiceTest::InToOut;

			serviceImpl = new AbstractCrudServiceImplementation(dao, mapFromItoR, mapFromRtoO);
			serviceImpl.delete(TYPE_ID_1, null);

			verify(dao).useTransaction(handleConsumerLambdaCaptor.capture());

			handleConsumerLambdaCaptor.getValue().useTransaction(dao);

			verify(dao, times(1)).deleteById(TYPE_ID_1);

		} catch (Exception e) {
			fail(e.getMessage(), e);
		}
	}

	@Test
	void testDelete_ObjectNotFound_ko() {
		try {
			ArgumentCaptor<TransactionalConsumer> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(TransactionalConsumer.class);

			serviceImpl = new AbstractCrudServiceImplementation(dao, mapFromItoR, mapFromRtoO);
			serviceImpl.delete(TYPE_ID_1, null);
			verify(dao).useTransaction(handleConsumerLambdaCaptor.capture());

			handleConsumerLambdaCaptor.getValue().useTransaction(dao);

		} catch (Exception e) {
			assertTrue(e instanceof ObjectNotFoundException);
		}
	}

	@Test
	void testReturnPagedResults_ok() {
		mapFromRtoO = AbstractCrudServiceTest::InToOut;

		serviceImpl = new AbstractCrudServiceImplementation(dao, mapFromItoR, mapFromRtoO);

		PagedResults pagedResults = new PagedResultsImpl(List.of(rsTaskType1));

		PagedResults<TaskTypesOutDTO> results = serviceImpl.returnPagedResults(pagedResults);

		PagedResults<TaskTypesOutDTO> expectedResults = new PagedResultsImpl<>(List.of(expectedTaskTypeOut1));

		assertEquals(expectedResults.getRecords(), results.getRecords());
		assertEquals(expectedResults.getRecords(), results.getRecords());
	}

	public static class AbstractCrudServiceImplementation extends AbstractCrudService<RsTaskTypes, Long, TaskTypesInDTO, TaskTypesOutDTO, String> {

		public AbstractCrudServiceImplementation(TaskTypesDAO dao,
				Function<TaskTypesInDTO, RsTaskTypes> mapFromItoR,
				Function<RsTaskTypes, TaskTypesOutDTO> mapFromRtoO) {
			super(dao, mapFromItoR, mapFromRtoO);
		}

		@Override
		protected boolean hasPrimaryKey() {
			return true;
		}

		@Override
		protected Optional<RsTaskTypes> findRsByCustomKey(String customKey) {
			switch (customKey) {
			case TYPE_CODE_1:
				return Optional.of(rsTaskType1);
			default:
				return Optional.empty();
			}
		}

		@Override
		protected void deleteByCustomKey(String customKey) {

		}

		@Override
		protected void setCustomSearchKey(RsTaskTypes rs, String customKey) {

		}

		@Override
		public PagedResults<TaskTypesOutDTO> returnPagedResults(PagedResults<RsTaskTypes> pagedResults) {
			return super.returnPagedResults(pagedResults);
		}

	}

 */
}
