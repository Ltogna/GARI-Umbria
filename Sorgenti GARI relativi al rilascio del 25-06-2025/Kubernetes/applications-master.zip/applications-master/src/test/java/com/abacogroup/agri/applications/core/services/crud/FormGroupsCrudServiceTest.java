package com.abacogroup.agri.applications.core.services.crud;

import com.abacogroup.agri.applications.core.exceptions.ObjectNotFoundException;
import com.abacogroup.agri.applications.core.mappers.FormGroupMapper;
import com.abacogroup.agri.applications.core.model.dto.FormGroupDTO;
import com.abacogroup.agri.applications.core.services.I18NService;
import com.abacogroup.agri.applications.db.dao.FormGroupDAO;
import com.abacogroup.agri.applications.db.ntt.FormGroupNTT;
import com.abacogroup.agri.applications.db.ntt.applications.RsI18N;
import com.abacogroup.jaxrsutils.filter.MDCPreFilter;
import org.apache.commons.lang3.NotImplementedException;
import org.jdbi.v3.sqlobject.transaction.TransactionalCallback;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;
import org.slf4j.MDC;

import java.util.List;
import java.util.Optional;

import static com.abacogroup.agri.applications.core.services.crud.FormGroupsCrudService.I18N_FORM_GROUPS_TABLE;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class FormGroupsCrudServiceTest extends AbstractCrudServiceTest {

	private static final String TENANT_ID_1 = "tenant_1";
	private static final Long FORM_GROUP_ID_1 = 1L;
	private static final Long PARENT_FORM_GROUP_ID_1 = 1L;
	private static final String FORM_GROUP_CODE_1 = "sectorCode_1";
	private static final String FORM_GROUP_CODE_DESC = "sector_title";
	private static final FormGroupDTO formGroupInDtoMock = FormGroupDTO.builder()
			.tenantId(TENANT_ID_1)
			.formGroupCode(FORM_GROUP_CODE_1)
			.parentFormGroupId(PARENT_FORM_GROUP_ID_1)
			.build();
	private static final FormGroupDTO formGroupOutDtoMock = FormGroupDTO.builder()
			.id(FORM_GROUP_ID_1)
			.tenantId(TENANT_ID_1)
			.formGroupCode(FORM_GROUP_CODE_1)
			.parentFormGroupId(PARENT_FORM_GROUP_ID_1)
			.build();
	private static final FormGroupNTT formGroupNttMock = FormGroupNTT.builder()
			.id(FORM_GROUP_ID_1)
			.form_group_code(FORM_GROUP_CODE_1)
			.tenant_id(TENANT_ID_1)
			.parent_form_group_id(PARENT_FORM_GROUP_ID_1)
			.build();

	private final RsI18N rsI18NMock = RsI18N.builder()
			.tenant_id(TENANT_ID_1)
			.i18n_text("text")
			.i18n_value("value")
			.field_name("field_name")
			.table_name("table_name")
			.lang("lang")
			.build();
	@Mock
	private FormGroupDAO dao;
	@Spy
	private FormGroupMapper formGroupMapper = FormGroupMapper.INSTANCE;
	@Mock
	private I18NService i18NService;
	@InjectMocks
	private FormGroupsCrudService formGroupsCrudService;

	@BeforeEach
	protected void init() {
		formGroupsCrudService = new FormGroupsCrudService(dao, formGroupMapper, i18NService);
	}

	@Test
	void test_hasPrimaryKey() {
		assertTrue(formGroupsCrudService.hasPrimaryKey());
	}

	@Test
	void test_deleteByCustomKey() {
		assertThrows(NotImplementedException.class, () -> formGroupsCrudService.deleteByCustomKey(null));
	}

	@Test
	void test_findRsByCustomKey() {
		assertEquals(Optional.empty(), formGroupsCrudService.findRsByCustomKey(null));
	}

	@Test
	void test_setCustomSearchKey() {
		assertThrows(NotImplementedException.class, () -> formGroupsCrudService.setCustomSearchKey(formGroupNttMock, null));
	}

	@Test
	void test_findAllFormGroups() {
		when(dao.findAllFormGroups(TENANT_ID_1, MDC.get(MDCPreFilter.LOCALE)))
				.thenReturn(List.of(formGroupNttMock));
		when(formGroupMapper.entityToDto(formGroupNttMock))
				.thenReturn(formGroupOutDtoMock);

		List<FormGroupDTO> result = formGroupsCrudService.findAllFormGroups(TENANT_ID_1);

		assertEquals(List.of(formGroupOutDtoMock), result);
	}

	@Test
	void test_findAllFormGroupsWithNoParentByTenant() {
		when(dao.findAllFormGroupsWithNoParentByTenant(TENANT_ID_1, MDC.get(MDCPreFilter.LOCALE)))
				.thenReturn(List.of(formGroupNttMock));
		when(formGroupMapper.entityToDto(formGroupNttMock))
				.thenReturn(formGroupOutDtoMock);

		List<FormGroupDTO> result = formGroupsCrudService.findAllFormGroupsWithNoParentByTenant(TENANT_ID_1);

		assertEquals(List.of(formGroupOutDtoMock), result);
	}

	@Test
	void test_findAllFormGroupsWithNoParent() {
		List<Long> formGroupIdList = List.of(FORM_GROUP_ID_1);

		when(dao.findAllFormGroupsWithNoParent(TENANT_ID_1, formGroupIdList, MDC.get(MDCPreFilter.LOCALE)))
				.thenReturn(List.of(formGroupNttMock));
		when(formGroupMapper.entityToDto(formGroupNttMock))
				.thenReturn(formGroupOutDtoMock);

		List<FormGroupDTO> result = formGroupsCrudService.findAllFormGroupsWithNoParent(TENANT_ID_1, formGroupIdList);

		assertEquals(List.of(formGroupOutDtoMock), result);
	}

	@Test
	void test_findFormGroupsByParentId() {
		when(dao.findFormCatalogsByParentId(TENANT_ID_1, PARENT_FORM_GROUP_ID_1))
				.thenReturn(List.of(formGroupNttMock));
		when(formGroupMapper.entityToDto(formGroupNttMock))
				.thenReturn(formGroupOutDtoMock);

		List<FormGroupDTO> result = formGroupsCrudService.findFormGroupsByParentId(TENANT_ID_1, PARENT_FORM_GROUP_ID_1);

		assertEquals(List.of(formGroupOutDtoMock), result);
	}

	@SuppressWarnings("rawtypes, unchecked")
	@Test
	void test_insert() {
		try {
			ArgumentCaptor<TransactionalCallback> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(TransactionalCallback.class);

			when(dao.nextSequenceVal()).thenReturn(FORM_GROUP_ID_1);
			when(dao.findById(FORM_GROUP_ID_1)).thenReturn(List.of(formGroupNttMock));

			formGroupsCrudService.insert(formGroupInDtoMock);

			verify(dao).inTransaction(handleConsumerLambdaCaptor.capture());

			FormGroupDTO result = (FormGroupDTO) handleConsumerLambdaCaptor.getValue().inTransaction(dao);

			assertEquals(formGroupOutDtoMock, result);

		} catch (Exception e) {
			fail(e.getMessage(), e);
		}
	}

	@SuppressWarnings("rawtypes, unchecked")
	@Test
	void test_update() {
		try {
			ArgumentCaptor<TransactionalCallback> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(TransactionalCallback.class);

			when(dao.findById(FORM_GROUP_ID_1)).thenReturn(List.of(formGroupNttMock));

			formGroupsCrudService.update(FORM_GROUP_ID_1, formGroupInDtoMock);

			verify(dao).inTransaction(handleConsumerLambdaCaptor.capture());

			FormGroupDTO result = (FormGroupDTO) handleConsumerLambdaCaptor.getValue().inTransaction(dao);

			assertEquals(formGroupOutDtoMock, result);
		} catch (Exception e) {
			fail(e.getMessage(), e);
		}
	}

	@Test
	void test_delete() {
		try {
			formGroupsCrudService.delete(FORM_GROUP_ID_1);

		} catch (Exception e) {
			fail(e.getMessage(), e);
		}
	}

	@Test
	void test_findById() throws ObjectNotFoundException {
		when(dao.findById(TENANT_ID_1, FORM_GROUP_ID_1, null)).thenReturn(List.of(formGroupNttMock));
		assertEquals(formGroupOutDtoMock, formGroupsCrudService.findById(TENANT_ID_1, FORM_GROUP_ID_1));
	}

	@Test
	void test_findByIdNoExp() {
		when(dao.findById(TENANT_ID_1, FORM_GROUP_ID_1, null))
				.thenReturn(List.of(formGroupNttMock));
		when(formGroupMapper.entityToDto(formGroupNttMock))
				.thenReturn(formGroupOutDtoMock);

		Optional<FormGroupDTO> result = formGroupsCrudService.findByIdNoExp(TENANT_ID_1, FORM_GROUP_ID_1);

		assertEquals(Optional.of(formGroupOutDtoMock), result);
	}

	@Test
	void test_findByIdNoExp_NotFound() {
		when(dao.findById(TENANT_ID_1, FORM_GROUP_ID_1, null))
				.thenReturn(List.of());

		Optional<FormGroupDTO> result = formGroupsCrudService.findByIdNoExp(TENANT_ID_1, FORM_GROUP_ID_1);

		assertEquals(Optional.empty(), result);
	}

	@Test
	void test_findFormGroupByCode() throws ObjectNotFoundException {
		when(dao.findByCode(TENANT_ID_1, FORM_GROUP_CODE_1, null)).thenReturn(List.of(formGroupNttMock));
		assertEquals(formGroupOutDtoMock, formGroupsCrudService.findFormGroupByCode(TENANT_ID_1, FORM_GROUP_CODE_1));
	}

	@Test
	void test_findFormGroupByCodeNullable() {
		when(dao.findByCode(TENANT_ID_1, FORM_GROUP_CODE_1, MDC.get(MDCPreFilter.LOCALE)))
				.thenReturn(List.of(formGroupNttMock));
		when(formGroupMapper.entityToDto(formGroupNttMock))
				.thenReturn(formGroupOutDtoMock);

		FormGroupDTO result = formGroupsCrudService.findFormGroupByCodeNullable(TENANT_ID_1, FORM_GROUP_CODE_1);

		assertEquals(formGroupOutDtoMock, result);
	}

	@Test
	void test_findFormGroupByCodeNullable_null() {
		when(dao.findByCode(TENANT_ID_1, FORM_GROUP_CODE_1, MDC.get(MDCPreFilter.LOCALE)))
				.thenReturn(List.of());

		FormGroupDTO result = formGroupsCrudService.findFormGroupByCodeNullable(TENANT_ID_1, FORM_GROUP_CODE_1);

		assertNull(result);
	}

	@Test
	void test_insertSectorI18N_ok() {
		formGroupsCrudService.insertFormGroupI18N(TENANT_ID_1, FORM_GROUP_CODE_1, null, FORM_GROUP_CODE_DESC);
		verify(i18NService).insertI18N(TENANT_ID_1, I18N_FORM_GROUPS_TABLE, FormGroupsCrudService.FORM_GROUPS_I18N.FORM_GROUP_CODE.getCode(), null,
				FORM_GROUP_CODE_1,
				FORM_GROUP_CODE_DESC);
	}

	@Test
	void test_deleteFormCatalogI18N_ok() {
		try {
			formGroupsCrudService.deleteFormGroupI18N(TENANT_ID_1, FORM_GROUP_CODE_1, null);
			verify(i18NService).deleteI18N(TENANT_ID_1, I18N_FORM_GROUPS_TABLE, FormGroupsCrudService.FORM_GROUPS_I18N.FORM_GROUP_CODE.getCode(),
					FORM_GROUP_CODE_1,
					null);
		} catch (Exception e) {
			fail(e.getMessage(), e);
		}
	}

	@Test
	void test_getAllFormCatalogI18NByTenantAndCode() {
		try {
			when(i18NService.getAllI18NbyCode(TENANT_ID_1, I18N_FORM_GROUPS_TABLE, FORM_GROUP_CODE_1)).thenReturn(List.of(rsI18NMock));
			assertEquals(List.of(rsI18NMock), formGroupsCrudService.getAllFormGroupI18NByTenantAndCode(TENANT_ID_1, FORM_GROUP_CODE_1));
		} catch (Exception e) {
			fail(e.getMessage(), e);
		}
	}
}
