package com.abacogroup.agri.applications.core.services.crud;

import com.abacogroup.agri.applications.core.exceptions.ObjectNotFoundException;
import com.abacogroup.agri.applications.core.mappers.FormCatalogMapper;
import com.abacogroup.agri.applications.core.model.dto.FormCatalogDTO;
import com.abacogroup.agri.applications.core.services.I18NService;
import com.abacogroup.agri.applications.db.dao.FormCatalogDAO;
import com.abacogroup.agri.applications.db.ntt.FormCatalogNTT;
import com.abacogroup.agri.applications.db.ntt.applications.RsI18N;
import com.abacogroup.jaxrsutils.filter.MDCPreFilter;
import org.apache.commons.lang3.NotImplementedException;
import org.jdbi.v3.sqlobject.transaction.TransactionalCallback;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;
import org.slf4j.MDC;

import java.util.List;
import java.util.Optional;

import static com.abacogroup.agri.applications.core.services.crud.FormCatalogsCrudService.I18N_FORM_CATALOG_TABLE;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class FormCatalogCrudServiceTest extends AbstractCrudServiceTest {

	private static final String TENANT_ID_1 = "tenant_1";
	private static final Long FORM_ID_1 = 1L;
	private static final String FORM_CODE_1 = "form_code_1";
	private static final String FORM_CODE_DESC = "form_code_desc";
	private static final String SOFTWARE_URL = "sw-url";
	private static final String ROUTER_URL = "router-url";
	private static final String LANG = "lang";
	private final FormCatalogDTO formCatalogInDtoMock = FormCatalogDTO.builder()
			.tenantId(TENANT_ID_1)
			.formCode(FORM_CODE_1)
			.softwareUrl(SOFTWARE_URL)
			.routerUrl(ROUTER_URL)
			.build();
	private final FormCatalogDTO formCatalogOutDtoMock = FormCatalogDTO.builder()
			.id(FORM_ID_1)
			.tenantId(TENANT_ID_1)
			.formCode(FORM_CODE_1)
			.softwareUrl(SOFTWARE_URL)
			.routerUrl(ROUTER_URL)
			.build();
	private final FormCatalogNTT formCatalogNttMock = FormCatalogNTT.builder()
			.id(FORM_ID_1)
			.form_code(FORM_CODE_1)
			.tenant_id(TENANT_ID_1)
			.software_url(SOFTWARE_URL)
			.router_url(ROUTER_URL)
			.build();
	private final RsI18N rsI18NMock = RsI18N.builder()
			.tenant_id(TENANT_ID_1)
			.i18n_text("text")
			.i18n_value("value")
			.field_name("field_name")
			.table_name("table_name")
			.lang(LANG)
			.build();
	@Mock
	private FormCatalogDAO dao;
	@Spy
	private FormCatalogMapper formCatalogMapper = FormCatalogMapper.INSTANCE;
	@Mock
	private I18NService i18NService;
	@InjectMocks
	private FormCatalogsCrudService formCatalogsCrudService;

	@BeforeEach
	protected void init() {
		formCatalogsCrudService = new FormCatalogsCrudService(dao, formCatalogMapper, i18NService);
	}

	@Test
	void test_hasPrimaryKey() {
		assertTrue(formCatalogsCrudService.hasPrimaryKey());
	}

	@Test
	void test_deleteByCustomKey() {
		assertThrows(NotImplementedException.class, () -> formCatalogsCrudService.deleteByCustomKey(null));
	}

	@Test
	void test_findRsByCustomKey() {
		assertEquals(Optional.empty(), formCatalogsCrudService.findRsByCustomKey(null));
	}

	@Test
	void test_setCustomSearchKey() {
		assertThrows(NotImplementedException.class, () -> formCatalogsCrudService.setCustomSearchKey(formCatalogNttMock, null));
	}

	@SuppressWarnings({"rawtypes", "unchecked"})
	@Test
	void test_insert() {
		try {
			ArgumentCaptor<TransactionalCallback> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(TransactionalCallback.class);

			when(dao.nextSequenceVal()).thenReturn(FORM_ID_1);
			when(dao.findById(FORM_ID_1)).thenReturn(List.of(formCatalogNttMock));

			formCatalogsCrudService.insert(formCatalogInDtoMock);

			verify(dao).inTransaction(handleConsumerLambdaCaptor.capture());

			FormCatalogDTO result = (FormCatalogDTO) handleConsumerLambdaCaptor.getValue().inTransaction(dao);

			assertEquals(formCatalogOutDtoMock, result);

		} catch (Exception e) {
			fail(e.getMessage(), e);
		}
	}

	@SuppressWarnings({"rawtypes", "unchecked"})
	@Test
	void test_update() {
		try {
			ArgumentCaptor<TransactionalCallback> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(TransactionalCallback.class);

			when(dao.findById(FORM_ID_1)).thenReturn(List.of(formCatalogNttMock));

			formCatalogsCrudService.update(FORM_ID_1, formCatalogInDtoMock);

			verify(dao).inTransaction(handleConsumerLambdaCaptor.capture());

			FormCatalogDTO result = (FormCatalogDTO) handleConsumerLambdaCaptor.getValue().inTransaction(dao);

			assertEquals(formCatalogOutDtoMock, result);
		} catch (Exception e) {
			fail(e.getMessage(), e);
		}
	}

	@Test
	void test_delete() {
		try {
			formCatalogsCrudService.delete(FORM_ID_1);

		} catch (Exception e) {
			fail(e.getMessage(), e);
		}
	}

	@Test
	void test_findById() throws ObjectNotFoundException {
		try {
			when(dao.findById(TENANT_ID_1, FORM_ID_1, null)).thenReturn(List.of(formCatalogNttMock));
			assertEquals(formCatalogOutDtoMock, formCatalogsCrudService.findById(TENANT_ID_1, FORM_ID_1));
		} catch (Exception e) {
			fail(e.getMessage(), e);
		}
	}

	@Test
	void test_findAllFormCatalogsByTenant() {
		when(dao.findAllFormCatalogsByTenant(TENANT_ID_1, MDC.get(MDCPreFilter.LOCALE)))
				.thenReturn(List.of(formCatalogNttMock));
		when(formCatalogMapper.entityToDto(formCatalogNttMock))
				.thenReturn(formCatalogOutDtoMock);

		List<FormCatalogDTO> result = formCatalogsCrudService.findAllFormCatalogsByTenant(TENANT_ID_1);

		assertEquals(List.of(formCatalogOutDtoMock), result);

	}

	@Test
	void test_findAllFormCatalogs() {
		List<Long> formIdList = List.of(FORM_ID_1);

		when(dao.findAllFormCatalogs(TENANT_ID_1, formIdList, MDC.get(MDCPreFilter.LOCALE)))
				.thenReturn(List.of(formCatalogNttMock));
		when(formCatalogMapper.entityToDto(formCatalogNttMock))
				.thenReturn(formCatalogOutDtoMock);

		List<FormCatalogDTO> result = formCatalogsCrudService.findAllFormCatalogs(TENANT_ID_1, formIdList);

		assertEquals(List.of(formCatalogOutDtoMock), result);
	}

	@Test
	void test_findByCode() {
		try {
			when(dao.findByCode(TENANT_ID_1, FORM_CODE_1)).thenReturn(List.of(formCatalogNttMock));
			assertEquals(formCatalogOutDtoMock, formCatalogsCrudService.findByCode(TENANT_ID_1, FORM_CODE_1));
		} catch (Exception e) {
			fail(e.getMessage(), e);
		}
	}

	@Test
	void test_findByCodeNullable() {
		try {
			when(dao.findByCode(TENANT_ID_1, FORM_CODE_1)).thenReturn(List.of(formCatalogNttMock));
			assertEquals(formCatalogOutDtoMock, formCatalogsCrudService.findByCodeNullable(TENANT_ID_1, FORM_CODE_1));
		} catch (Exception e) {
			fail(e.getMessage(), e);
		}
	}

	@Test
	void test_insertFormCatalogI18N_ok() {
		try {
			formCatalogsCrudService.insertFormCatalogI18N(TENANT_ID_1, FORM_CODE_1, null, FORM_CODE_DESC);
			verify(i18NService).insertI18N(TENANT_ID_1, I18N_FORM_CATALOG_TABLE, FormCatalogsCrudService.FORM_CATALOG_I18N.FORM_CODE.getCode(), null,
					FORM_CODE_1,
					FORM_CODE_DESC);
		} catch (Exception e) {
			fail(e.getMessage(), e);
		}
	}

	@Test
	void test_deleteFormCatalogI18N_ok() {
		try {
			formCatalogsCrudService.deleteFormCatalogI18N(TENANT_ID_1, FORM_CODE_1, LANG);
			verify(i18NService).deleteI18N(TENANT_ID_1, I18N_FORM_CATALOG_TABLE, FormCatalogsCrudService.FORM_CATALOG_I18N.FORM_CODE.getCode(),
					FORM_CODE_1,
					LANG);
		} catch (Exception e) {
			fail(e.getMessage(), e);
		}
	}

	@Test
	void test_getAllFormCatalogI18NByTenantAndCode() {
		try {
			when(i18NService.getAllI18NbyCode(TENANT_ID_1, I18N_FORM_CATALOG_TABLE, FORM_CODE_1)).thenReturn(List.of(rsI18NMock));
			assertEquals(List.of(rsI18NMock), formCatalogsCrudService.getAllFormCatalogI18NByTenantAndCode(TENANT_ID_1, FORM_CODE_1));
		} catch (Exception e) {
			fail(e.getMessage(), e);
		}
	}

}
