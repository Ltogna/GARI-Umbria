package com.abacogroup.agri.applications.bundles.processor.childmodule;

import com.abacogroup.agri.applications.bundles.BundleConstants;
import com.abacogroup.agri.applications.bundles.model.chilldmodule.BundleChildModuleInDTO;
import com.abacogroup.agri.applications.bundles.model.chilldmodule.BundleChildrenModulesMessage;
import com.abacogroup.agri.applications.core.exceptions.ObjectNotFoundRuntimeException;
import com.abacogroup.agri.applications.core.model.dto.ChildModuleDTO;
import com.abacogroup.agri.applications.core.model.dto.ModuleDTO;
import com.abacogroup.agri.applications.core.services.crud.ChildModuleCrudService;
import com.abacogroup.agri.applications.core.services.crud.ModuleCrudService;
import com.abacogroup.agri.applications.core.services.crud.SectorsCrudService;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@Slf4j
@ExtendWith(MockitoExtension.class)
class ChildrenModulesBundleWorkerTest {
    @Mock
    private ChildModuleCrudService childModuleCrudService;
    @Mock
    private ModuleCrudService moduleCrudService;
    @Mock
    private SectorsCrudService sectorsCrudService;

    @InjectMocks
    private ChildrenModulesBundleWorker childrenModulesBundleWorker;

    private static final String TEMPLATE_TENANT_ID = "*";
    private static final Long PKID = 1L;
    private static final Long MODULE_ID = 123L;
    private static final Long PARENT_MODULE_ID = 456L;
    private static final Long OLD_MODULE_ID = 789L;
    private static final String MODULE_CODE = "module_code";
    private static final String USER = "user";
    private static final String PARENT_MODULE_CODE = "PARENT_MODULE_CODE";
    private static final String OLD_PARENT_MODULE_CODE = "OLD_PARENT_MODULE_CODE";
    private static final Long SECTOR_ID = 10L;
    private static final Long SECTOR_ID_2 = 20L;
    private static final String WORKFLOW_CODE = "workflow_code";

    private final ModuleDTO module = ModuleDTO.builder()
            .moduleId(MODULE_ID)
            .sectorId(SECTOR_ID)
            .moduleCode(MODULE_CODE)
            .workflowCode(WORKFLOW_CODE)
            .flAmendModule(false)
            .build();

    private final ModuleDTO parentModule = ModuleDTO.builder()
            .moduleId(PARENT_MODULE_ID)
            .sectorId(SECTOR_ID_2)
            .moduleCode(PARENT_MODULE_CODE)
            .workflowCode(WORKFLOW_CODE)
            .flAmendModule(true)
            .build();

    private final ModuleDTO oldModule = ModuleDTO.builder()
            .moduleId(OLD_MODULE_ID)
            .sectorId(SECTOR_ID_2)
            .moduleCode(OLD_PARENT_MODULE_CODE)
            .workflowCode(WORKFLOW_CODE)
            .flAmendModule(true)
            .build();

    private final ChildModuleDTO oldChildModule = ChildModuleDTO.builder()
            .pkid(PKID)
            .parentModuleId(PARENT_MODULE_ID)
            .moduleId(MODULE_ID)
            .userIdInsert(USER)
            .build();

    @Test
    void upsertBundleModules_insert_ok() {
        when(moduleCrudService.findByCode(TEMPLATE_TENANT_ID, MODULE_CODE))
                .thenReturn(Optional.ofNullable(module));
        when(moduleCrudService.findByCode(TEMPLATE_TENANT_ID, PARENT_MODULE_CODE))
                .thenReturn(Optional.ofNullable(parentModule));

        BundleChildModuleInDTO bundleChildModuleInDTO = BundleChildModuleInDTO.builder()
                .moduleCode(MODULE_CODE)
                .parentModuleCode(PARENT_MODULE_CODE)
                .build();

        BundleChildrenModulesMessage message = BundleChildrenModulesMessage.builder()
                .childrenModules(List.of(bundleChildModuleInDTO))
                .build();

        childrenModulesBundleWorker.upsertBundleChildrenModules(TEMPLATE_TENANT_ID, message);

        ChildModuleDTO in = ChildModuleDTO.builder()
                .moduleId(MODULE_ID)
                .parentModuleId(PARENT_MODULE_ID)
                .build();

        verify(childModuleCrudService).insert(in, BundleConstants.BUNDLE_SYSTEM_USERNAME);
    }

    @Test
    void upsertBundleModules_update_ok() {
        when(moduleCrudService.findByCode(TEMPLATE_TENANT_ID, MODULE_CODE))
                .thenReturn(Optional.ofNullable(module));
        when(moduleCrudService.findByCode(TEMPLATE_TENANT_ID, OLD_PARENT_MODULE_CODE))
                .thenReturn(Optional.ofNullable(oldModule));
        when(childModuleCrudService.findOptByModuleIdAndParentModuleId(MODULE_ID, OLD_MODULE_ID))
                .thenReturn(Optional.ofNullable(oldChildModule));
        when(moduleCrudService.findByCode(TEMPLATE_TENANT_ID, PARENT_MODULE_CODE))
                .thenReturn(Optional.ofNullable(parentModule));

        BundleChildModuleInDTO bundleChildModuleInDTO = BundleChildModuleInDTO.builder()
                .moduleCode(MODULE_CODE)
                .parentModuleCode(PARENT_MODULE_CODE)
                .oldParentModuleCode(OLD_PARENT_MODULE_CODE)
                .build();

        BundleChildrenModulesMessage message = BundleChildrenModulesMessage.builder()
                .childrenModules(List.of(bundleChildModuleInDTO))
                .build();

        childrenModulesBundleWorker.upsertBundleChildrenModules(TEMPLATE_TENANT_ID, message);

        ChildModuleDTO in = ChildModuleDTO.builder()
                .moduleId(MODULE_ID)
                .parentModuleId(PARENT_MODULE_ID)
                .build();

        verify(childModuleCrudService).update(PKID, in, BundleConstants.BUNDLE_SYSTEM_USERNAME);
    }

    @Test
    void upsertBundleModules_ko() {
        when(moduleCrudService.findByCode(TEMPLATE_TENANT_ID, MODULE_CODE))
                .thenReturn(Optional.empty());

        BundleChildModuleInDTO bundleChildModuleInDTO = BundleChildModuleInDTO.builder()
                .moduleCode(MODULE_CODE)
                .parentModuleCode(PARENT_MODULE_CODE)
                .build();

        BundleChildrenModulesMessage message = BundleChildrenModulesMessage.builder()
                .childrenModules(List.of(bundleChildModuleInDTO))
                .build();

        assertThrows(ObjectNotFoundRuntimeException.class,
                () -> childrenModulesBundleWorker.upsertBundleChildrenModules(TEMPLATE_TENANT_ID, message));
    }

    @Test
    void deleteBundleAmendableModules_ok() {
        when(moduleCrudService.findByCode(TEMPLATE_TENANT_ID, MODULE_CODE))
                .thenReturn(Optional.ofNullable(module));
        when(moduleCrudService.findByCode(TEMPLATE_TENANT_ID, PARENT_MODULE_CODE))
                .thenReturn(Optional.ofNullable(parentModule));
        when(childModuleCrudService.findOptByModuleIdAndParentModuleId(MODULE_ID, PARENT_MODULE_ID))
                .thenReturn(Optional.ofNullable(oldChildModule));

        BundleChildModuleInDTO bundleChildModuleInDTO = BundleChildModuleInDTO.builder()
                .moduleCode(MODULE_CODE)
                .parentModuleCode(PARENT_MODULE_CODE)
                .build();

        BundleChildrenModulesMessage message = BundleChildrenModulesMessage.builder()
                .childrenModules(List.of(bundleChildModuleInDTO))
                .build();

        childrenModulesBundleWorker.deleteBundleChildrenModules(TEMPLATE_TENANT_ID, message);

        verify(childModuleCrudService).delete(PKID, BundleConstants.BUNDLE_SYSTEM_USERNAME);
    }

    @Test
    void deleteBundleAmendableModules_ko() {
        when(moduleCrudService.findByCode(TEMPLATE_TENANT_ID, MODULE_CODE))
                .thenReturn(Optional.ofNullable(module));
        when(moduleCrudService.findByCode(TEMPLATE_TENANT_ID, PARENT_MODULE_CODE))
                .thenReturn(Optional.ofNullable(parentModule));
        when(childModuleCrudService.findOptByModuleIdAndParentModuleId(MODULE_ID, PARENT_MODULE_ID))
                .thenReturn(Optional.empty());

        BundleChildModuleInDTO bundleChildModuleInDTO = BundleChildModuleInDTO.builder()
                .moduleCode(MODULE_CODE)
                .parentModuleCode(PARENT_MODULE_CODE)
                .build();

        BundleChildrenModulesMessage message = BundleChildrenModulesMessage.builder()
                .childrenModules(List.of(bundleChildModuleInDTO))
                .build();

        assertThrows(ObjectNotFoundRuntimeException.class,
                () -> childrenModulesBundleWorker.deleteBundleChildrenModules(TEMPLATE_TENANT_ID, message));
    }

    @Test
    void test_exposeModulesService() {
        assertEquals(moduleCrudService, childrenModulesBundleWorker.exposeModuleCrudService());
    }

    @Test
    void test_exposeChildModuleCrudService() {
        assertEquals(childModuleCrudService, childrenModulesBundleWorker.exposeChildModuleCrudService());
    }

}
