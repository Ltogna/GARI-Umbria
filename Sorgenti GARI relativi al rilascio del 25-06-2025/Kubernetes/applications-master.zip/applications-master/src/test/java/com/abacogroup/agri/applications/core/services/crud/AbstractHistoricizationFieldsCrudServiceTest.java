package com.abacogroup.agri.applications.core.services.crud;

import static org.junit.jupiter.api.Assertions.assertTrue;

import java.time.LocalDateTime;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class AbstractHistoricizationFieldsCrudServiceTest {

	public static final LocalDateTime NOW = LocalDateTime.now();
	// TASK GROUP DETAILS 1
	private static final Long DAO_NEXT_VALUE = 24L;
	private static final String TASK_GROUP_DETAILS_DESCRIPTION_1 = "desc-1";
	private static final LocalDateTime TASK_GROUP_DETAILS_DT_DELETE_1 = LocalDateTime.of(9999, 12, 31, 23, 59, 59);
	private static final LocalDateTime TASK_GROUP_DETAILS_DT_INSERT_1 = LocalDateTime.of(2022, 6, 9, 10, 0);
	private static final Long TASK_GROUP_DETAILS_PARENT_GROUP_ID_1 = 12L;
	private static final Long TASK_GROUP_DETAILS_GROUP_ID_1 = 24L;
	private static final String TASK_GROUP_DETAILS_USER_ID_DELETE_1 = "user-deleting";
	private static final String TASK_GROUP_DETAILS_USER_ID_INSERT_1 = "user-inserting";

	@Test
	void simpleTest() {
		// Simple test for sonar issue
		assertTrue(true);
	}
	/* TODO Fix this

	private static final RsTaskGroupDetailTest rsTaskGroupDetails1 = RsTaskGroupDetailTest.builder()
			.description(TASK_GROUP_DETAILS_DESCRIPTION_1)
			.dt_delete(TASK_GROUP_DETAILS_DT_DELETE_1)
			.dt_insert(TASK_GROUP_DETAILS_DT_INSERT_1)
			.parent_task_group_id(TASK_GROUP_DETAILS_PARENT_GROUP_ID_1)
			.task_group_id(TASK_GROUP_DETAILS_GROUP_ID_1)
			.user_id_delete(TASK_GROUP_DETAILS_USER_ID_DELETE_1)
			.user_id_insert(TASK_GROUP_DETAILS_USER_ID_INSERT_1)
			.build();
	private static final String USERNAME_1 = "username-1";

	private static final TaskGroupDetailsCustomKey CUSTOM_KEY_1 = TaskGroupDetailsCustomKey.builder()
			.taskGroupId(TASK_GROUP_DETAILS_GROUP_ID_1)
			.build();
	private final TaskGroupDetailsInDTO taskGroupDetailIn = TaskGroupDetailsInDTO.builder()
			.description(TASK_GROUP_DETAILS_DESCRIPTION_1)
			.parentTaskGroupId(TASK_GROUP_DETAILS_PARENT_GROUP_ID_1)
			.taskGroupId(TASK_GROUP_DETAILS_GROUP_ID_1)
			.userIdInsert(TASK_GROUP_DETAILS_USER_ID_INSERT_1)
			.build();
	private final List<RsTaskGroupDetailTest> taskGroupDetail = new ArrayList<>(List.of(
			rsTaskGroupDetails1));
	private final TaskGroupDetailsOutDTO expectedTaskGroupDetailOut1 = TaskGroupDetailsOutDTO.builder()
			.description(TASK_GROUP_DETAILS_DESCRIPTION_1)
			.dtDelete(TASK_GROUP_DETAILS_DT_DELETE_1)
			.dtInsert(TASK_GROUP_DETAILS_DT_INSERT_1)
			.parentGroupId(TASK_GROUP_DETAILS_PARENT_GROUP_ID_1)
			.groupId(TASK_GROUP_DETAILS_GROUP_ID_1)
			.userIdDelete(TASK_GROUP_DETAILS_USER_ID_DELETE_1)
			.userIdInsert(TASK_GROUP_DETAILS_USER_ID_INSERT_1)
			.build();
	AbstractHistoricizationCrudServiceImplementation serviceImpl;
	@Mock
	private IGenericHistoricizationFieldsDAO<RsTaskGroupDetailTest, Long, TaskGroupDetailsCustomKey> dao;
	@Mock
	private Function<RsTaskGroupDetailTest, TaskGroupDetailsOutDTO> mapFromRtoO;
	@Mock
	private Function<TaskGroupDetailsInDTO, RsTaskGroupDetailTest> mapFromItoR;

	private static TaskGroupDetailsOutDTO InToOut(RsTaskGroupDetailTest res) {
		return TaskGroupDetailsOutDTO.builder()
				.description(res.getDescription())
				.dtDelete(res.getDt_delete())
				.dtInsert(res.getDt_insert())
				.parentGroupId(res.getParent_task_group_id())
				.groupId(res.getTask_group_id())
				.userIdDelete(res.getUser_id_delete())
				.userIdInsert(res.getUser_id_insert())
				.build();
	}

	@Test
	void retrievePrimaryKey_ok() {
		when(dao.nextSequenceVal()).thenReturn(DAO_NEXT_VALUE);
		serviceImpl = new AbstractHistoricizationCrudServiceImplementation(dao, mapFromItoR, mapFromRtoO);
		assertEquals(DAO_NEXT_VALUE, serviceImpl.retrieveKey(null));
	}

	@Test
	void testInsert_ok() {
		try {
			ArgumentCaptor<TransactionalCallback> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(TransactionalCallback.class);

			when(mapFromItoR.apply(taskGroupDetailIn)).thenReturn(rsTaskGroupDetails1);
			when(dao.nextSequenceVal()).thenReturn(DAO_NEXT_VALUE);
			when(dao.findById(DAO_NEXT_VALUE)).thenReturn(List.of(rsTaskGroupDetails1));

			mapFromRtoO = AbstractHistoricizationFieldsCrudServiceTest::InToOut;

			serviceImpl = new AbstractHistoricizationCrudServiceImplementation(dao, mapFromItoR, mapFromRtoO);
			serviceImpl.insert(taskGroupDetailIn, USERNAME_1, null);

			verify(dao).inTransaction(handleConsumerLambdaCaptor.capture());

			TaskGroupDetailsOutDTO brgHeaderOut = (TaskGroupDetailsOutDTO) handleConsumerLambdaCaptor.getValue().inTransaction(dao);

			assertEquals(expectedTaskGroupDetailOut1, brgHeaderOut);
		} catch (Exception e) {
			fail(e.getMessage());
		}
	}

	@Test
	void testInsert_customKey_ok() {
		try {
			ArgumentCaptor<TransactionalCallback> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(TransactionalCallback.class);

			when(mapFromItoR.apply(taskGroupDetailIn)).thenReturn(rsTaskGroupDetails1);

			mapFromRtoO = AbstractHistoricizationFieldsCrudServiceTest::InToOut;

			serviceImpl = new AbstractHistoricizationCrudServiceImplementation(dao, mapFromItoR, mapFromRtoO);
			serviceImpl.insert(taskGroupDetailIn, USERNAME_1, CUSTOM_KEY_1);

			verify(dao).inTransaction(handleConsumerLambdaCaptor.capture());

			TaskGroupDetailsOutDTO taskGroupDetailsOut = (TaskGroupDetailsOutDTO) handleConsumerLambdaCaptor.getValue().inTransaction(dao);

			assertEquals(expectedTaskGroupDetailOut1, taskGroupDetailsOut);
		} catch (Exception e) {
			fail(e.getMessage());
		}
	}

	@Test
	void testInsert_Forbidden_ko() {
		ArgumentCaptor<TransactionalCallback> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(TransactionalCallback.class);

		when(mapFromItoR.apply(taskGroupDetailIn)).thenReturn(rsTaskGroupDetails1);

		mapFromRtoO = AbstractHistoricizationFieldsCrudServiceTest::InToOut;
		serviceImpl = new AbstractHistoricizationCrudServiceImplementation(dao, mapFromItoR, mapFromRtoO);

		serviceImpl.insert(taskGroupDetailIn, USERNAME_1, null);

		verify(dao).inTransaction(handleConsumerLambdaCaptor.capture());
		TransactionalCallback transactionalCallback = handleConsumerLambdaCaptor.getValue();
		assertThrows(ObjectNotFoundRuntimeException.class, () -> transactionalCallback.inTransaction(dao));

	}

	@Test
	void testInsert_ObjectNotFound_ko() {
		ArgumentCaptor<TransactionalCallback> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(TransactionalCallback.class);

		when(mapFromItoR.apply(taskGroupDetailIn)).thenReturn(rsTaskGroupDetails1);

		mapFromRtoO = AbstractHistoricizationFieldsCrudServiceTest::InToOut;
		serviceImpl = new AbstractHistoricizationCrudServiceImplementation(dao, mapFromItoR, mapFromRtoO);

		serviceImpl.insert(taskGroupDetailIn, USERNAME_1, null);

		verify(dao).inTransaction(handleConsumerLambdaCaptor.capture());
		TransactionalCallback transactionalCallback = handleConsumerLambdaCaptor.getValue();
		assertThrows(ObjectNotFoundRuntimeException.class, () -> {
			transactionalCallback.inTransaction(dao);
		});
	}

	@Test
	void testInsert_InsertExceptionRuntimeException_ko() {
		ArgumentCaptor<TransactionalCallback> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(TransactionalCallback.class);
		when(mapFromItoR.apply(taskGroupDetailIn)).thenReturn(rsTaskGroupDetails1);

		doThrow(new StatementExceptionTest("err")).when(dao).insert(eq(rsTaskGroupDetails1), eq(USERNAME_1), any(LocalDateTime.class));
		mapFromRtoO = AbstractHistoricizationFieldsCrudServiceTest::InToOut;
		serviceImpl = new AbstractHistoricizationCrudServiceImplementation(dao, mapFromItoR, mapFromRtoO);

		serviceImpl.insert(taskGroupDetailIn, USERNAME_1, null);

		verify(dao).inTransaction(handleConsumerLambdaCaptor.capture());
		TransactionalCallback transactionalCallback = handleConsumerLambdaCaptor.getValue();
		assertThrows(InsertExceptionRuntimeException.class, () -> transactionalCallback.inTransaction(dao));
	}

	@Test
	void testInsert_AgriTaskManagerRuntimeException_ko() {
		ArgumentCaptor<TransactionalCallback> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(TransactionalCallback.class);
		when(mapFromItoR.apply(taskGroupDetailIn)).thenReturn(rsTaskGroupDetails1);

		doThrow(new StatementExceptionRuntimeException("err")).when(dao).insert(eq(rsTaskGroupDetails1), eq(USERNAME_1), any(LocalDateTime.class));
		mapFromRtoO = AbstractHistoricizationFieldsCrudServiceTest::InToOut;
		serviceImpl = new AbstractHistoricizationCrudServiceImplementation(dao, mapFromItoR, mapFromRtoO);

		serviceImpl.insert(taskGroupDetailIn, USERNAME_1, null);

		verify(dao).inTransaction(handleConsumerLambdaCaptor.capture());
		TransactionalCallback transactionalCallback = handleConsumerLambdaCaptor.getValue();
		assertThrows(AgriApplicationsRuntimeException.class, () -> transactionalCallback.inTransaction(dao));
	}

	@Test
	void testUpdate_ok() {
		try {
			ArgumentCaptor<TransactionalCallback> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(TransactionalCallback.class);

			mapFromRtoO = AbstractHistoricizationFieldsCrudServiceTest::InToOut;
			serviceImpl = Mockito.spy(new AbstractHistoricizationCrudServiceImplementation(dao, mapFromItoR, mapFromRtoO));

			serviceImpl.update(null, taskGroupDetailIn, USERNAME_1, CUSTOM_KEY_1);

			verify(dao, times(1)).inTransaction(handleConsumerLambdaCaptor.capture());

			TaskGroupDetailsOutDTO groupDetailOut = (TaskGroupDetailsOutDTO) handleConsumerLambdaCaptor.getValue().inTransaction(dao);

			verify(serviceImpl, times(1)).delete(any(), any(), any(), any());
			verify(serviceImpl, times(1)).insert(any(), any(), any(), any());

		} catch (Exception e) {
			fail(e.getMessage(), e);
		}
	}

	@Test
	void testUpdate_customKey_ok() {
		try {
			ArgumentCaptor<TransactionalCallback> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(TransactionalCallback.class);

			mapFromRtoO = AbstractHistoricizationFieldsCrudServiceTest::InToOut;

			serviceImpl = Mockito.spy(new AbstractHistoricizationCrudServiceImplementation(dao, mapFromItoR, mapFromRtoO));
			serviceImpl.update(null, taskGroupDetailIn, USERNAME_1, CUSTOM_KEY_1);

			verify(dao).inTransaction(handleConsumerLambdaCaptor.capture());

			TaskGroupDetailsOutDTO taskGroupDetailsOut = (TaskGroupDetailsOutDTO) handleConsumerLambdaCaptor.getValue().inTransaction(dao);

			verify(serviceImpl, times(1)).delete(any(), any(), any(), any());
			verify(serviceImpl, times(1)).insert(any(), any(), any(), any());

		} catch (Exception e) {
			fail(e.getMessage(), e);
		}
	}

	@Test
	void testUpdate_ko() {
		ArgumentCaptor<TransactionalCallback> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(TransactionalCallback.class);

		mapFromRtoO = AbstractHistoricizationFieldsCrudServiceTest::InToOut;

		serviceImpl = Mockito.spy(new AbstractHistoricizationCrudServiceImplementation(dao, mapFromItoR, mapFromRtoO));

		doThrow(new RuntimeException("error deleting object")).when(serviceImpl).delete(eq(TASK_GROUP_DETAILS_GROUP_ID_1), eq(USERNAME_1), any(), any());

		serviceImpl.update(TASK_GROUP_DETAILS_GROUP_ID_1, taskGroupDetailIn, USERNAME_1, null);

		verify(dao).inTransaction(handleConsumerLambdaCaptor.capture());
		TransactionalCallback transactionalCallback = handleConsumerLambdaCaptor.getValue();
		assertThrows(RuntimeException.class, () -> transactionalCallback.inTransaction(dao));

	}

	@Test
	void testUpdate_forbiddenException_ko() {
		try {
			ArgumentCaptor<TransactionalCallback> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(TransactionalCallback.class);

			mapFromRtoO = AbstractHistoricizationFieldsCrudServiceTest::InToOut;

			serviceImpl = new AbstractHistoricizationCrudServiceImplementation(dao, mapFromItoR, mapFromRtoO);
			serviceImpl.update(null, taskGroupDetailIn, USERNAME_1, CUSTOM_KEY_1);

			verify(dao).inTransaction(handleConsumerLambdaCaptor.capture());

			handleConsumerLambdaCaptor.getValue().inTransaction(dao);

		} catch (Exception e) {
			assertTrue(e instanceof ForbiddenException);
		}
	}

	@Test
	void testUpdate_ObjectNotFound_ko() {
		try {
			ArgumentCaptor<TransactionalCallback> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(TransactionalCallback.class);

			mapFromRtoO = AbstractHistoricizationFieldsCrudServiceTest::InToOut;

			serviceImpl = new AbstractHistoricizationCrudServiceImplementation(dao, mapFromItoR, mapFromRtoO);
			serviceImpl.update(null, taskGroupDetailIn, USERNAME_1, CUSTOM_KEY_1);

			verify(dao).inTransaction(handleConsumerLambdaCaptor.capture());

			handleConsumerLambdaCaptor.getValue().inTransaction(dao);
		} catch (Exception e) {
			assertTrue(e instanceof AgriApplicationsRuntimeException);
		}
	}

	@Test
	void testDelete_ok() {
		try {
			ArgumentCaptor<TransactionalConsumer> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(TransactionalConsumer.class);

			mapFromRtoO = AbstractHistoricizationFieldsCrudServiceTest::InToOut;

			serviceImpl = new AbstractHistoricizationCrudServiceImplementation(dao, mapFromItoR, mapFromRtoO);
			serviceImpl.delete(TASK_GROUP_DETAILS_GROUP_ID_1, USERNAME_1, null);

			verify(dao).useTransaction(handleConsumerLambdaCaptor.capture());

			handleConsumerLambdaCaptor.getValue().useTransaction(dao);

		} catch (Exception e) {
			fail(e.getMessage(), e);
		}
	}

	@Test
	void testDelete_ko() {
		ArgumentCaptor<TransactionalConsumer> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(TransactionalConsumer.class);

		mapFromRtoO = AbstractHistoricizationFieldsCrudServiceTest::InToOut;

		doThrow(mock(StatementException.class)).when(dao).logicallyDeleteById(TASK_GROUP_DETAILS_GROUP_ID_1, USERNAME_1, NOW);

		serviceImpl = new AbstractHistoricizationCrudServiceImplementation(dao, mapFromItoR, mapFromRtoO);

		serviceImpl.delete(TASK_GROUP_DETAILS_GROUP_ID_1, USERNAME_1, null, NOW);

		verify(dao).useTransaction(handleConsumerLambdaCaptor.capture());
		TransactionalConsumer transactionalConsumer = handleConsumerLambdaCaptor.getValue();
		assertThrows(StatementExceptionRuntimeException.class, () -> {
			transactionalConsumer.useTransaction(dao);
		});

	}

	@Test
	void testDelete_customKey_ok() {
		try {

			ArgumentCaptor<TransactionalConsumer> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(TransactionalConsumer.class);

			mapFromRtoO = AbstractHistoricizationFieldsCrudServiceTest::InToOut;

			serviceImpl = Mockito.spy(new AbstractHistoricizationCrudServiceImplementation(dao, mapFromItoR, mapFromRtoO));
			serviceImpl.delete(USERNAME_1, CUSTOM_KEY_1, NOW);

			verify(dao).useTransaction(handleConsumerLambdaCaptor.capture());

			handleConsumerLambdaCaptor.getValue().useTransaction(dao);

			verify(dao, times(1)).logicallyDeleteByCustomKey(CUSTOM_KEY_1, USERNAME_1, NOW);
		} catch (Exception e) {
			fail(e.getMessage(), e);
		}
	}

	@Test
	void testDeleteWithoutPartyId_ok() {
		try {
			ArgumentCaptor<TransactionalConsumer> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(TransactionalConsumer.class);

			mapFromRtoO = AbstractHistoricizationFieldsCrudServiceTest::InToOut;

			serviceImpl = new AbstractHistoricizationCrudServiceImplementation(dao, mapFromItoR, mapFromRtoO);
			serviceImpl.delete(null, USERNAME_1, CUSTOM_KEY_1);

			verify(dao).useTransaction(handleConsumerLambdaCaptor.capture());

			handleConsumerLambdaCaptor.getValue().useTransaction(dao);

		} catch (Exception e) {
			fail(e.getMessage(), e);
		}
	}

	@Test
	void testDelete_ObjectNotFound_ko() {
		try {
			ArgumentCaptor<TransactionalConsumer> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(TransactionalConsumer.class);

			serviceImpl = new AbstractHistoricizationCrudServiceImplementation(dao, mapFromItoR, mapFromRtoO);
			serviceImpl.delete(null, USERNAME_1, CUSTOM_KEY_1);
			verify(dao).useTransaction(handleConsumerLambdaCaptor.capture());

			handleConsumerLambdaCaptor.getValue().useTransaction(dao);

		} catch (Exception e) {
			assertTrue(e instanceof ObjectNotFoundException);
		}
	}

	@Test
	void testReturnPagedResults_ok() {
		mapFromRtoO = AbstractHistoricizationFieldsCrudServiceTest::InToOut;

		serviceImpl = new AbstractHistoricizationCrudServiceImplementation(dao, mapFromItoR, mapFromRtoO);

		PagedResults pagedResults = new PagedResultsImpl(List.of(rsTaskGroupDetails1));

		PagedResults<TaskGroupDetailsOutDTO> results = serviceImpl.returnPagedResults(pagedResults);

		PagedResults<TaskGroupDetailsOutDTO> expectedResults = new PagedResultsImpl<>(List.of(expectedTaskGroupDetailOut1));

		assertEquals(expectedResults.getRecords(), results.getRecords());
		assertEquals(expectedResults.getRecords(), results.getRecords());
	}

	private static class StatementExceptionTest extends StatementException {

		public StatementExceptionTest(String string) {
			super(string);
		}
	}

	@Data
	@AllArgsConstructor
	@NoArgsConstructor
	@Builder
	private static class RsTaskGroupDetailTest implements IIdRs<Long>, IHistoricizationFields {
		private Long task_group_id;
		private Long parent_task_group_id;
		private String description;
		private String user_id_insert;
		private String user_id_delete;
		private LocalDateTime dt_insert;
		private LocalDateTime dt_delete;

		@Override
		public Optional<Long> getKey() {
			return Optional.empty();
		}

		@Override
		public void setKey(Long id) {
			// not in use
		}
	}

	private static class AbstractHistoricizationCrudServiceImplementation extends
			AbstractHistoricizationFieldsCrudService<RsTaskGroupDetailTest, Long, TaskGroupDetailsInDTO, TaskGroupDetailsOutDTO, TaskGroupDetailsCustomKey> {

		public AbstractHistoricizationCrudServiceImplementation(IGenericHistoricizationFieldsDAO<RsTaskGroupDetailTest, Long, TaskGroupDetailsCustomKey> dao,
				Function<TaskGroupDetailsInDTO, RsTaskGroupDetailTest> mapFromItoR,
				Function<RsTaskGroupDetailTest, TaskGroupDetailsOutDTO> mapFromRtoO) {

			super(dao, mapFromItoR, mapFromRtoO);
		}

		@Override
		protected boolean hasPrimaryKey() {
			return true;
		}

		@Override
		protected TaskGroupDetailsCustomKey retrieveCustomKeyByResultSet(RsTaskGroupDetailTest rs) {
			return null;
		}

		@Override
		protected RsTaskGroupDetailTest adjustR(RsTaskGroupDetailTest rs) throws Exception {
			// do nothing
			return rs;
		}

		@Override
		protected Optional<RsTaskGroupDetailTest> findRsByCustomKey(TaskGroupDetailsCustomKey customKey) {
			if (customKey.getTaskGroupId() == TASK_GROUP_DETAILS_GROUP_ID_1) {
				return Optional.of(rsTaskGroupDetails1);
			}
			return Optional.empty();
		}

		@Override
		public PagedResults<TaskGroupDetailsOutDTO> returnPagedResults(PagedResults<RsTaskGroupDetailTest> pagedResults) {
			return super.returnPagedResults(pagedResults);
		}

		public void delete(String userId, TaskGroupDetailsCustomKey customKey, LocalDateTime now) {
			this.delete(null, userId, customKey, now);
		}

	}

	 */
}
