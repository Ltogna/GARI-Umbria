package com.abacogroup.agri.applications.core.services.crud;

import com.abacogroup.agri.applications.core.exceptions.ObjectNotFoundException;
import com.abacogroup.agri.applications.core.mappers.ModuleFormConfigProfileMapper;
import com.abacogroup.agri.applications.core.model.dto.ModuleFormConfigProfileDTO;
import com.abacogroup.agri.applications.core.services.I18NService;
import com.abacogroup.agri.applications.db.dao.ModuleFormConfigProfileDAO;
import com.abacogroup.agri.applications.db.ntt.ModuleFormConfigProfileNTT;
import com.abacogroup.agri.applications.db.ntt.compoundkeys.FormConfigProfileKey;
import org.jdbi.v3.sqlobject.transaction.TransactionalCallback;
import org.jdbi.v3.sqlobject.transaction.TransactionalConsumer;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class ModuleFormConfigProfilesCrudServiceTest extends AbstractCrudServiceTest {

	private static final String TENANT_ID_1 = "tenant_1";
	private static final Long FORM_CONFIG_ID_1 = 1L;
	private static final String REQUIRED_PROFILE_CODE = "DEFAULT_PROFILE_CODE";
	private static final FormConfigProfileKey formConfigProfileKey = FormConfigProfileKey.builder()
			.module_form_config_id(FORM_CONFIG_ID_1)
			.required_profile_code(REQUIRED_PROFILE_CODE)
			.build();

	private static final ModuleFormConfigProfileNTT ModuleFormConfigProfileNttMock = ModuleFormConfigProfileNTT.builder()
			.module_form_config_id(FORM_CONFIG_ID_1)
			.required_profile_code(REQUIRED_PROFILE_CODE)
			.build();

	private static final ModuleFormConfigProfileDTO ModuleFormConfigProfileDtoMock = ModuleFormConfigProfileDTO.builder()
			.moduleFormConfigId(FORM_CONFIG_ID_1)
			.requiredProfileCode(REQUIRED_PROFILE_CODE)
			.build();

	@Mock
	private ModuleFormConfigProfileDAO dao;
	@Spy
	private ModuleFormConfigProfileMapper formGroupMapper = ModuleFormConfigProfileMapper.INSTANCE;
	@Mock
	private I18NService i18NService;
	@InjectMocks
	private ModuleFormConfigProfilesCrudService moduleFormConfigProfilesCrudService;

	@Test
	void test_hasPrimaryKey() {
		assertFalse(moduleFormConfigProfilesCrudService.hasPrimaryKey());
	}

	@Test
	void test_insert() {
		try {
			ArgumentCaptor<TransactionalCallback> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(TransactionalCallback.class);

			when(dao.findById(FORM_CONFIG_ID_1, REQUIRED_PROFILE_CODE)).thenReturn(List.of(ModuleFormConfigProfileNttMock));

			moduleFormConfigProfilesCrudService.insert(ModuleFormConfigProfileDtoMock);

			verify(dao).inTransaction(handleConsumerLambdaCaptor.capture());

			ModuleFormConfigProfileDTO result = (ModuleFormConfigProfileDTO) handleConsumerLambdaCaptor.getValue().inTransaction(dao);

			assertEquals(ModuleFormConfigProfileDtoMock, result);

		} catch (Exception e) {
			fail(e.getMessage(), e);
		}
	}

	@Test
	void test_update() {
		try {
			ArgumentCaptor<TransactionalCallback> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(TransactionalCallback.class);

			when(dao.findById(FORM_CONFIG_ID_1, REQUIRED_PROFILE_CODE)).thenReturn(List.of(ModuleFormConfigProfileNttMock));

			moduleFormConfigProfilesCrudService.update(ModuleFormConfigProfileDtoMock);

			verify(dao).inTransaction(handleConsumerLambdaCaptor.capture());

			ModuleFormConfigProfileDTO result = (ModuleFormConfigProfileDTO) handleConsumerLambdaCaptor.getValue().inTransaction(dao);

			assertEquals(ModuleFormConfigProfileDtoMock, result);
		} catch (Exception e) {
			fail(e.getMessage(), e);
		}
	}

	@Test
	void test_delete() throws Exception {
		try {
			ArgumentCaptor<TransactionalConsumer> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(TransactionalConsumer.class);
			moduleFormConfigProfilesCrudService.delete(formConfigProfileKey);
			verify(dao).useTransaction(handleConsumerLambdaCaptor.capture());
			handleConsumerLambdaCaptor.getValue().useTransaction(dao);
			verify(dao, times(1)).deleteById(formConfigProfileKey.getModule_form_config_id(), formConfigProfileKey.getRequired_profile_code());
		} catch (Exception e) {
			fail(e.getMessage(), e);
		}
	}

	@Test
	void test_findById() throws ObjectNotFoundException {
		try {

			when(dao.findById(TENANT_ID_1, FORM_CONFIG_ID_1, REQUIRED_PROFILE_CODE)).thenReturn(List.of(ModuleFormConfigProfileNttMock));
			assertEquals(ModuleFormConfigProfileDtoMock, moduleFormConfigProfilesCrudService.findById(TENANT_ID_1, formConfigProfileKey));
		} catch (Exception e) {
			fail(e.getMessage(), e);
		}
	}

	@Test
	void test_findAllById() {
		try {
			when(dao.find(TENANT_ID_1, FORM_CONFIG_ID_1)).thenReturn(List.of(ModuleFormConfigProfileNttMock));
			assertEquals(List.of(ModuleFormConfigProfileDtoMock), moduleFormConfigProfilesCrudService.find(TENANT_ID_1, FORM_CONFIG_ID_1));
		} catch (Exception e) {
			fail(e.getMessage(), e);
		}
	}

	@Test
	void test_deleteByModuleFormConfigId() {
		try {
			moduleFormConfigProfilesCrudService.deleteByModuleFormConfigId(FORM_CONFIG_ID_1);
			verify(dao).deleteByModuleFormConfigId(FORM_CONFIG_ID_1);
		} catch (Exception e) {
			fail(e.getMessage(), e);
		}
	}

}
