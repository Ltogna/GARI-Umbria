package com.abacogroup.agri.applications.core.services.crud;

import com.abacogroup.agri.applications.core.exceptions.ObjectNotFoundException;
import com.abacogroup.agri.applications.core.mappers.ModulePrintConfigProfileMapper;
import com.abacogroup.agri.applications.core.model.dto.ModulePrintConfigProfileDTO;
import com.abacogroup.agri.applications.db.dao.ModulePrintConfigProfileDAO;
import com.abacogroup.agri.applications.db.ntt.ModulePrintConfigProfileNTT;
import com.abacogroup.agri.applications.db.ntt.compoundkeys.PrintConfigProfileKey;
import org.jdbi.v3.sqlobject.transaction.TransactionalCallback;
import org.jdbi.v3.sqlobject.transaction.TransactionalConsumer;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class ModulePrintConfigProfilesCrudServiceTest {
    @Mock
    private ModulePrintConfigProfileDAO modulePrintConfigProfileDAOMock;
    @Mock
    private ModulePrintConfigProfileMapper modulePrintConfigProfileMapperMock;

    @InjectMocks
    private ModulePrintConfigProfilesCrudService modulePrintConfigProfilesCrudService;

    private static final String TENANT = "ADMIN";
    private static final Long MODULE_PRINT_CONFIG_ID = 10L;
    private static final String REQUIRED_PROFILE_CODE = "required profile code";

    private final ModulePrintConfigProfileNTT modulePrintConfigProfileNTT = ModulePrintConfigProfileNTT.builder()
            .module_print_config_id(MODULE_PRINT_CONFIG_ID)
            .required_profile_code(REQUIRED_PROFILE_CODE)
            .build();
    private final ModulePrintConfigProfileDTO modulePrintConfigProfileDTO = ModulePrintConfigProfileDTO.builder()
            .modulePrintConfigId(MODULE_PRINT_CONFIG_ID)
            .requiredProfileCode(REQUIRED_PROFILE_CODE)
            .build();
    private final PrintConfigProfileKey printConfigProfileKey = PrintConfigProfileKey.builder()
            .module_print_config_id(MODULE_PRINT_CONFIG_ID)
            .required_profile_code(REQUIRED_PROFILE_CODE)
            .build();

    @SuppressWarnings({"rawtypes", "unchecked"})
    @Test
    void insert_ok() {
        ModulePrintConfigProfileDTO payload = ModulePrintConfigProfileDTO.builder()
                .modulePrintConfigId(MODULE_PRINT_CONFIG_ID)
                .requiredProfileCode(REQUIRED_PROFILE_CODE)
                .build();

        try {
            ArgumentCaptor<TransactionalCallback> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(TransactionalCallback.class);

            when(modulePrintConfigProfileMapperMock.dtoToEntity(payload))
                    .thenReturn(modulePrintConfigProfileNTT);
            when(modulePrintConfigProfileMapperMock.entityToDto(modulePrintConfigProfileNTT))
                    .thenReturn(modulePrintConfigProfileDTO);
            when(modulePrintConfigProfileDAOMock.findById(MODULE_PRINT_CONFIG_ID, REQUIRED_PROFILE_CODE))
                    .thenReturn(List.of(modulePrintConfigProfileNTT));

            modulePrintConfigProfilesCrudService.insert(payload);

            verify(modulePrintConfigProfileDAOMock).inTransaction(handleConsumerLambdaCaptor.capture());

            ModulePrintConfigProfileDTO result = (ModulePrintConfigProfileDTO) handleConsumerLambdaCaptor.getValue().inTransaction(modulePrintConfigProfileDAOMock);

            assertEquals(modulePrintConfigProfileDTO, result);

        } catch (Exception e) {
            fail(e);
        }

    }

    @SuppressWarnings({"rawtypes", "unchecked"})
    @Test
    void update_ok() {
        ModulePrintConfigProfileDTO payload = ModulePrintConfigProfileDTO.builder()
                .modulePrintConfigId(MODULE_PRINT_CONFIG_ID)
                .requiredProfileCode(REQUIRED_PROFILE_CODE)
                .build();

        try {
            ArgumentCaptor<TransactionalCallback> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(TransactionalCallback.class);

            when(modulePrintConfigProfileDAOMock.inTransaction(handleConsumerLambdaCaptor.capture()))
                    .thenReturn(modulePrintConfigProfileDTO);
            when(modulePrintConfigProfileMapperMock.dtoToEntity(payload))
                    .thenReturn(modulePrintConfigProfileNTT);
            when(modulePrintConfigProfileDAOMock.findById(MODULE_PRINT_CONFIG_ID, REQUIRED_PROFILE_CODE))
                    .thenReturn(List.of(modulePrintConfigProfileNTT));
            when(modulePrintConfigProfileMapperMock.entityToDto(modulePrintConfigProfileNTT))
                    .thenReturn(modulePrintConfigProfileDTO);

            modulePrintConfigProfilesCrudService.update(payload);

            verify(modulePrintConfigProfileDAOMock).inTransaction(handleConsumerLambdaCaptor.capture());
            ModulePrintConfigProfileDTO result = (ModulePrintConfigProfileDTO) handleConsumerLambdaCaptor.getValue().inTransaction(modulePrintConfigProfileDAOMock);

            assertEquals(modulePrintConfigProfileDTO, result);
        } catch (Exception e) {
            fail(e);
        }
    }

    @SuppressWarnings({"rawtypes", "unchecked"})
    @Test
    void delete_ok() {
        try {
            ArgumentCaptor<TransactionalConsumer> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(TransactionalConsumer.class);

            modulePrintConfigProfilesCrudService.delete(printConfigProfileKey);

            verify(modulePrintConfigProfileDAOMock).useTransaction(handleConsumerLambdaCaptor.capture());
            handleConsumerLambdaCaptor.getValue().useTransaction(modulePrintConfigProfileDAOMock);

            verify(modulePrintConfigProfileDAOMock, times(1)).deleteById(MODULE_PRINT_CONFIG_ID, REQUIRED_PROFILE_CODE);
        } catch (Exception e) {
            fail(e);
        }
    }

    @Test
    void deleteByModulePrintConfigId_ok() {
        modulePrintConfigProfilesCrudService.deleteByModulePrintConfigId(MODULE_PRINT_CONFIG_ID);

        verify(modulePrintConfigProfileDAOMock, times(1)).deleteByModulePrintConfigId(MODULE_PRINT_CONFIG_ID);
    }

    @Test
    void findById_ok() {
        try {
            when(modulePrintConfigProfileDAOMock.findById(TENANT, MODULE_PRINT_CONFIG_ID, REQUIRED_PROFILE_CODE))
                    .thenReturn(List.of(modulePrintConfigProfileNTT));
            when(modulePrintConfigProfileMapperMock.entityToDto(modulePrintConfigProfileNTT))
                    .thenReturn(modulePrintConfigProfileDTO);

            ModulePrintConfigProfileDTO result = modulePrintConfigProfilesCrudService.findById(TENANT, printConfigProfileKey);

            assertEquals(modulePrintConfigProfileDTO, result);
        } catch (Exception e) {
            fail(e);
        }
    }

    @Test
    void find_ok() {
        when(modulePrintConfigProfileDAOMock.find(TENANT, MODULE_PRINT_CONFIG_ID))
                .thenReturn(List.of(modulePrintConfigProfileNTT));
        when(modulePrintConfigProfileMapperMock.entityToDto(modulePrintConfigProfileNTT))
                .thenReturn(modulePrintConfigProfileDTO);

        List<ModulePrintConfigProfileDTO> result = modulePrintConfigProfilesCrudService.find(TENANT, MODULE_PRINT_CONFIG_ID);

        assertEquals(List.of(modulePrintConfigProfileDTO), result);
    }

    @Test
    void findById_ko() {
        try {
            when(modulePrintConfigProfileDAOMock.findById(TENANT, MODULE_PRINT_CONFIG_ID, REQUIRED_PROFILE_CODE))
                    .thenReturn(List.of());

            assertThrows(ObjectNotFoundException.class, () ->
                    modulePrintConfigProfilesCrudService.findById(TENANT, printConfigProfileKey));
        } catch (Exception e) {
            fail(e);
        }
    }
}
