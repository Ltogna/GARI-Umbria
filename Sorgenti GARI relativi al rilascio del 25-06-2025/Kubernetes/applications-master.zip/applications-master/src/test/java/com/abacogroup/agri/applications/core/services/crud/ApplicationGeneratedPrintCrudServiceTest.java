package com.abacogroup.agri.applications.core.services.crud;

import com.abacogroup.agri.applications.core.mappers.ApplicationGeneratedPrintMapper;
import com.abacogroup.agri.applications.core.model.dto.ApplicationGeneratedPrintDTO;
import com.abacogroup.agri.applications.db.dao.ApplicationGeneratedPrintDAO;
import com.abacogroup.agri.applications.db.ntt.ApplicationGeneratedPrintNTT;
import com.abacogroup.jaxrsutils.filter.MDCPreFilter;
import org.apache.commons.lang3.NotImplementedException;
import org.jdbi.v3.sqlobject.transaction.TransactionalCallback;
import org.jdbi.v3.sqlobject.transaction.TransactionalConsumer;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.slf4j.MDC;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import static com.abacogroup.agri.applications.core.services.crud.ApplicationGeneratedPrintCrudService.DEFINITIVE_PRINT;
import static com.abacogroup.agri.applications.core.services.crud.ApplicationGeneratedPrintCrudService.ON_GOING_PRINT;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class ApplicationGeneratedPrintCrudServiceTest {
    @Mock
    ApplicationGeneratedPrintDAO applicationGeneratedPrintDAOMock;
    @Mock
    ApplicationGeneratedPrintMapper applicationGeneratedPrintMapperMock;

    @InjectMocks
    ApplicationGeneratedPrintCrudService applicationGeneratedPrintCrudService;

    private static final String TENANT = "ADMIN";
    private static final String USERNAME = "Username";
    private static final Long APPLICATION_ID = 5L;
    private static final Long PKID = 1L;
    private static final String PRINT_CODE = "Print Code";
    private static final String PRINT_DESCRIPTION = "Print Description";
    private static final String PROCESS_STATUS = "Process Status";
    private static final LocalDateTime NOW = LocalDateTime.now();
    private static final String FILE_ID = "File ID";
    private static final String PRINT_JOB_UUID = "Print Job UUID";
    private static final String PRINT_STATUS = "Print Status";

    private final ApplicationGeneratedPrintDTO applicationGeneratedPrintDTO = ApplicationGeneratedPrintDTO.builder()
            .pkid(PKID)
            .applicationId(APPLICATION_ID)
            .printCode(PRINT_CODE)
            .processStatus(PROCESS_STATUS)
            .username(USERNAME)
            .printDate(NOW)
            .fileId(FILE_ID)
            .printJobUuid(PRINT_JOB_UUID)
            .printDescription(PRINT_DESCRIPTION)
            .printStatus(PRINT_STATUS)
            .build();
    private final ApplicationGeneratedPrintNTT applicationGeneratedPrintNTT = ApplicationGeneratedPrintNTT.builder()
            .pkid(PKID)
            .application_id(APPLICATION_ID)
            .print_code(PRINT_CODE)
            .print_description(PRINT_DESCRIPTION)
            .print_date(NOW)
            .file_id(FILE_ID)
            .print_job_uuid(PRINT_JOB_UUID)
            .process_status(PROCESS_STATUS)
            .username(USERNAME)
            .status(PRINT_STATUS)
            .build();

    @Test
    void findAllGeneratedPrints_ok() {
        when(applicationGeneratedPrintDAOMock.findCompletedPrintsByApplicationIdAndPrintCode(TENANT, APPLICATION_ID, MDC.get(MDCPreFilter.LOCALE), null))
                .thenReturn(List.of(applicationGeneratedPrintNTT));
        when(applicationGeneratedPrintMapperMock.entityToDto(applicationGeneratedPrintNTT))
                .thenReturn(applicationGeneratedPrintDTO);

        List<ApplicationGeneratedPrintDTO> result = applicationGeneratedPrintCrudService.findAllGeneratedPrints(TENANT, APPLICATION_ID);

        assertEquals(List.of(applicationGeneratedPrintDTO), result);
    }

    @Test
    void findPrintByApplicationIdAndFileId_ok() {
        when(applicationGeneratedPrintDAOMock.findByApplicationIdAndFileId(TENANT, APPLICATION_ID, MDC.get(MDCPreFilter.LOCALE), FILE_ID))
                .thenReturn(List.of(applicationGeneratedPrintNTT));
        when(applicationGeneratedPrintMapperMock.entityToDto(applicationGeneratedPrintNTT))
                .thenReturn(applicationGeneratedPrintDTO);

        Optional<ApplicationGeneratedPrintDTO> result = applicationGeneratedPrintCrudService.findPrintByApplicationIdAndFileId(TENANT, APPLICATION_ID, FILE_ID);

        assertEquals(Optional.ofNullable(applicationGeneratedPrintDTO), result);
    }

    @Test
    void findLastGeneratedPrintByCode_ok() {
        when(applicationGeneratedPrintDAOMock.findLastGeneratedPrintByCode(TENANT, APPLICATION_ID, PRINT_CODE, MDC.get(MDCPreFilter.LOCALE), DEFINITIVE_PRINT))
                .thenReturn(List.of(applicationGeneratedPrintNTT));
        when(applicationGeneratedPrintMapperMock.entityToDto(applicationGeneratedPrintNTT))
                .thenReturn(applicationGeneratedPrintDTO);

        Optional<ApplicationGeneratedPrintDTO> result = applicationGeneratedPrintCrudService.findLastGeneratedPrintByCode(TENANT, APPLICATION_ID, PRINT_CODE);

        assertEquals(Optional.ofNullable(applicationGeneratedPrintDTO), result);
    }

    @Test
    void findOngoingPrintByCode_ok() {
        when(applicationGeneratedPrintDAOMock.findLastGeneratedPrintByCode(TENANT, APPLICATION_ID, PRINT_CODE, MDC.get(MDCPreFilter.LOCALE), ON_GOING_PRINT))
                .thenReturn(List.of(applicationGeneratedPrintNTT));
        when(applicationGeneratedPrintMapperMock.entityToDto(applicationGeneratedPrintNTT))
                .thenReturn(applicationGeneratedPrintDTO);

        List<ApplicationGeneratedPrintDTO> result = applicationGeneratedPrintCrudService.findOngoingPrintByCode(TENANT, APPLICATION_ID, PRINT_CODE);

        assertEquals(List.of(applicationGeneratedPrintDTO), result);
    }

    @Test
    void findByUuid_ok() {
        when(applicationGeneratedPrintDAOMock.findByUuid(PRINT_JOB_UUID))
                .thenReturn(applicationGeneratedPrintNTT);
        when(applicationGeneratedPrintMapperMock.entityToDto(applicationGeneratedPrintNTT))
                .thenReturn(applicationGeneratedPrintDTO);

        ApplicationGeneratedPrintDTO result = applicationGeneratedPrintCrudService.findByUuid(PRINT_JOB_UUID);

        assertEquals(applicationGeneratedPrintDTO, result);
    }

    @SuppressWarnings({"rawtypes", "unchecked"})
    @Test
    void insert_ok() {
        ApplicationGeneratedPrintDTO in = ApplicationGeneratedPrintDTO.builder()
                .applicationId(APPLICATION_ID)
                .printDescription(PRINT_DESCRIPTION)
                .fileId(FILE_ID)
                .build();

        try {
            ArgumentCaptor<TransactionalCallback> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(TransactionalCallback.class);

            when(applicationGeneratedPrintDAOMock.nextSequenceVal())
                    .thenReturn(PKID);
            when(applicationGeneratedPrintMapperMock.dtoToEntity(in))
                    .thenReturn(applicationGeneratedPrintNTT);
            when(applicationGeneratedPrintDAOMock.findById(PKID))
                    .thenReturn(List.of(applicationGeneratedPrintNTT));
            when(applicationGeneratedPrintMapperMock.entityToDto(applicationGeneratedPrintNTT))
                    .thenReturn(applicationGeneratedPrintDTO);

            applicationGeneratedPrintCrudService.insert(in);

            verify(applicationGeneratedPrintDAOMock).inTransaction(handleConsumerLambdaCaptor.capture());

            ApplicationGeneratedPrintDTO result = (ApplicationGeneratedPrintDTO) handleConsumerLambdaCaptor.getValue().inTransaction(applicationGeneratedPrintDAOMock);

            assertEquals(applicationGeneratedPrintDTO, result);
        } catch (Exception e) {
            fail(e);
        }
    }

    @SuppressWarnings({"rawtypes", "unchecked"})
    @Test
    void update_ok() {
        ApplicationGeneratedPrintDTO in = ApplicationGeneratedPrintDTO.builder()
                .applicationId(APPLICATION_ID)
                .printDescription(PRINT_DESCRIPTION)
                .fileId(FILE_ID)
                .build();

        try {
            ArgumentCaptor<TransactionalCallback> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(TransactionalCallback.class);
            when(applicationGeneratedPrintMapperMock.dtoToEntity(in))
                    .thenReturn(applicationGeneratedPrintNTT);
            when(applicationGeneratedPrintDAOMock.inTransaction(handleConsumerLambdaCaptor.capture()))
                    .thenReturn(applicationGeneratedPrintDTO);
            when(applicationGeneratedPrintDAOMock.findById(PKID))
                    .thenReturn(List.of(applicationGeneratedPrintNTT));
            when(applicationGeneratedPrintMapperMock.entityToDto(applicationGeneratedPrintNTT))
                    .thenReturn(applicationGeneratedPrintDTO);

            applicationGeneratedPrintCrudService.update(PKID, in);

            verify(applicationGeneratedPrintDAOMock).inTransaction(handleConsumerLambdaCaptor.capture());
            ApplicationGeneratedPrintDTO result = (ApplicationGeneratedPrintDTO) handleConsumerLambdaCaptor.getValue().inTransaction(applicationGeneratedPrintDAOMock);

            assertEquals(applicationGeneratedPrintDTO, result);
        } catch (Exception e) {
            fail(e);
        }
    }

    @SuppressWarnings({"rawtypes", "unchecked"})
    @Test
    void delete_ok() {
        try {
            ArgumentCaptor<TransactionalConsumer> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(TransactionalConsumer.class);

            applicationGeneratedPrintCrudService.delete(PKID);

            verify(applicationGeneratedPrintDAOMock).useTransaction(handleConsumerLambdaCaptor.capture());
            handleConsumerLambdaCaptor.getValue().useTransaction(applicationGeneratedPrintDAOMock);

            verify(applicationGeneratedPrintDAOMock, times(1)).deleteById(PKID);
        } catch (Exception e) {
            fail(e);
        }
    }

    @Test
    void findRsByCustomKey_ok() {
        Optional<ApplicationGeneratedPrintNTT> result = applicationGeneratedPrintCrudService.findRsByCustomKey(null);

        assertEquals(Optional.empty(), result);
    }

    @Test
    void deleteByCustomKey_ok() {
        assertThrows(NotImplementedException.class, () -> applicationGeneratedPrintCrudService.deleteByCustomKey(null));
    }

    @Test
    void setCustomSearchKey_ok() {
        assertThrows(NotImplementedException.class, () -> applicationGeneratedPrintCrudService.setCustomSearchKey(applicationGeneratedPrintNTT, null));
    }
}