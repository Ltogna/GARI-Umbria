package com.abacogroup.agri.applications.core.services;

import com.abacogroup.agri.applications.core.exceptions.ObjectNotFoundException;
import com.abacogroup.agri.applications.core.exceptions.ObjectNotFoundRuntimeException;
import com.abacogroup.agri.applications.core.model.dto.ApplicationEnvDTO;
import com.abacogroup.agri.applications.core.model.dto.publics.ApplicationEnvPublicDTO;
import com.abacogroup.agri.applications.core.services.crud.ApplicationEnvCrudService;
import com.abacogroup.agri.applications.db.ntt.compoundkeys.ApplicationEnvKey;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class ConfigServiceTest {
    @Mock
    ApplicationEnvCrudService applicationEnvCrudService;

    @InjectMocks
    ConfigService configService;

    private static final String TENANT = "ADMIN";
    private static final String SEARCH_KEY = "Search Key";
    private static final Integer FL_CLIENT = 1;
    private static final String VALUE = "Value";

    private final ApplicationEnvKey key = ApplicationEnvKey.builder()
            .tenant_id(TENANT)
            .key_(SEARCH_KEY)
            .fl_client(FL_CLIENT)
            .build();
    private final ApplicationEnvDTO applicationEnvDTO = ApplicationEnvDTO.builder()
            .tenant(TENANT)
            .flClient(FL_CLIENT)
            .key(SEARCH_KEY)
            .value(VALUE)
            .build();
    private final ApplicationEnvDTO applicationEnvDTOFalseFlClient = ApplicationEnvDTO.builder()
            .tenant(TENANT)
            .flClient(0)
            .key(SEARCH_KEY)
            .value(VALUE)
            .build();

    @Test
    void getConfig_ok() {
        try {
            when(applicationEnvCrudService.findEnvironmentByKey(key))
                    .thenReturn(applicationEnvDTO);

            ApplicationEnvPublicDTO expectedOutput = ApplicationEnvPublicDTO.builder()
                    .key(SEARCH_KEY)
                    .value(VALUE)
                    .build();

            List<ApplicationEnvPublicDTO> result = configService.getConfig(TENANT, SEARCH_KEY);

            assertEquals(List.of(expectedOutput), result);
        } catch (Exception e) {
            fail(e);
        }
    }

    @Test
    void getConfig_nullSearchKey_ok() {
            when(applicationEnvCrudService.findAllByTenant(TENANT))
                    .thenReturn(List.of(applicationEnvDTO));

            ApplicationEnvPublicDTO expectedOutput = ApplicationEnvPublicDTO.builder()
                    .key(SEARCH_KEY)
                    .value(VALUE)
                    .build();

            List<ApplicationEnvPublicDTO> result = configService.getConfig(TENANT, null);

            assertEquals(List.of(expectedOutput), result);
    }

    @Test
    void getConfig_flClientFalse_ok() {
            when(applicationEnvCrudService.findAllByTenant(TENANT))
                    .thenReturn(List.of(applicationEnvDTOFalseFlClient));

            List<ApplicationEnvPublicDTO> result = configService.getConfig(TENANT, null);

            assertEquals(List.of(), result);
    }

    @Test
    void getConfig_ko() {
        try {
            when(applicationEnvCrudService.findEnvironmentByKey(key))
                    .thenThrow(ObjectNotFoundException.class);

            assertThrows(ObjectNotFoundRuntimeException.class, () ->
                    configService.getConfig(TENANT, SEARCH_KEY));
        } catch (Exception e) {
            fail(e);
        }
    }
}