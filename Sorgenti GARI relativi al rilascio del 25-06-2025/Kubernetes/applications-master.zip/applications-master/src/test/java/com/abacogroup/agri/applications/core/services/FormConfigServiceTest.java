package com.abacogroup.agri.applications.core.services;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.fail;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import com.abacogroup.agri.applications.core.model.dto.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.abacogroup.agri.applications.core.exceptions.ObjectNotFoundException;
import com.abacogroup.agri.applications.core.exceptions.ObjectNotFoundRuntimeException;
import com.abacogroup.agri.applications.core.model.dto.publics.LastPrintDTO;
import com.abacogroup.agri.applications.core.model.dto.publics.ModuleFormConfigsPublicDTO;
import com.abacogroup.agri.applications.core.model.dto.publics.ModuleWithParamsPublicDTO;
import com.abacogroup.agri.applications.core.model.dto.publics.PrintDetailsOutDTO;
import com.abacogroup.agri.applications.core.services.crud.ApplicationCompileStatusCrudService;
import com.abacogroup.agri.applications.core.services.crud.ApplicationGeneratedPrintCrudService;
import com.abacogroup.agri.applications.core.services.crud.CrudServiceContainer;
import com.abacogroup.agri.applications.core.services.crud.FormCatalogsCrudService;
import com.abacogroup.agri.applications.core.services.crud.FormGroupsCrudService;
import com.abacogroup.agri.applications.core.services.crud.ModuleCrudService;
import com.abacogroup.agri.applications.core.services.crud.ModuleFormConfigParamCrudService;
import com.abacogroup.agri.applications.core.services.crud.ModuleFormConfigProfilesCrudService;
import com.abacogroup.agri.applications.core.services.crud.ModuleFormConfigsCrudService;
import com.abacogroup.agri.applications.core.services.crud.ModulePrintConfigParamCrudService;
import com.abacogroup.agri.applications.core.services.crud.ModulePrintConfigProfilesCrudService;
import com.abacogroup.agri.applications.core.services.crud.ModulePrintConfigsCrudService;
import com.abacogroup.applicationworkflowsdk.model.io.output.ApplicationCompileStatusDTO;
import com.abacogroup.applicationworkflowsdk.model.io.output.FormDetailsPublicDTO;
import com.abacogroup.applicationworkflowsdk.model.io.output.FormGroupPublicDTO;
import com.abacogroup.applicationworkflowsdk.model.io.output.FormWithGroupHierarchyPublicDTO;

import jakarta.ws.rs.core.SecurityContext;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@ExtendWith(MockitoExtension.class)
class FormConfigServiceTest {

	private static final String TENANT_1 = "tenant_1";
	private static final String MODULE_CODE = "module_code";
	private static final Long APPLICATION_ID_1 = 30L;
	private static final Long MODULE_ID_1 = 1L;
	private static final String PROCESS_STATUS_1 = "status_1";
	private static final String PROFILE_CODE_1 = "code1";
	private static final String APPLICATION_COMPILE_STATUS_1 = "compile-status-1";
	private static final String APPLICATION_COMPILE_STATUS_IDENTIFIER_1 = "compile-status-identifier-1";
	private static final Long FORM_ID_1 = 33L;
	private static final Long FORM_GROUP_ID_1 = 45L;
	private static final Long FORM_GROUP_ID_2 = 1L;
	private static final String FORM_GROUP_CODE_1 = "form-group-code-1";
	private static final String FORM_GROUP_CODE_2 = "form-group-code-2";
	private static final String FORM_GROUP_CODE_3 = "form-group-code-3";
	private static final Long PARENT_FORM_GROUP_ID_1 = 123L;
	private static final Long MODULE_PRINT_CONFIG_ID = 1L;
	private static final Long PARENT_FORM_GROUP_ID_2 = 456L;
	private static final String FORM_GROUP_DESCRIPTION_1 = "form-group-desc-1";
	private static final String FORM_GROUP_DESCRIPTION_2 = "form-group-desc-2";
	private static final String FORM_GROUP_DESCRIPTION_3 = "form-group-desc-3";
	private static final Long FORM_CATALOG_ID_1 = 55L;
	private static final String FORM_CODE_1 = "33";
	private static final String FORM_CATALOG_DESCRIPTION = "catalog-description";
	private static final String FORM_CATALOG_SW_URL = "http://localhost:3000";
	private static final String FORM_CATALOG_ROUTER_URL = "/test";
	private static final String REQUIRED_PROFILE_CODE = "required_profile_code";
	private static final String PARAMETER_NAME = "parameter_name";
	private static final String PARAMETER_VALUE = "parameter_value";
	private static final Long MODULE_FORM_CONFIG_ID = 1l;
	private static final Integer FORM_FL_READONLY = 0;
	private static final Integer FORM_SORT_ORDER = 1;

	private final ModuleFormConfigsDTO moduleFormConfigsDTO = ModuleFormConfigsDTO.builder()
			.compileStatusIdentifier(APPLICATION_COMPILE_STATUS_IDENTIFIER_1)
			.formId(FORM_CATALOG_ID_1)
			.formGroupId(FORM_GROUP_ID_1)
			.id(FORM_ID_1)
			.flReadOnly(FORM_FL_READONLY)
			.sortOrder(FORM_SORT_ORDER)
			.build();

	private final ModuleFormConfigParamDTO moduleFormConfigParamDTO = ModuleFormConfigParamDTO.builder()
			.moduleFormConfigId(MODULE_FORM_CONFIG_ID)
			.parameterName(PARAMETER_NAME)
			.parameterValue(PARAMETER_VALUE)
			.build();

	private final FormCatalogDTO formCatalogDTO = FormCatalogDTO.builder()
			.formCode(FORM_CODE_1)
			.formCatalogDescription(FORM_CATALOG_DESCRIPTION)
			.build();

	private final FormGroupDTO formGroupDTO = FormGroupDTO.builder()
			.formGroupCode(FORM_GROUP_CODE_1)
			.formGroupDescription(FORM_GROUP_DESCRIPTION_1)
			.parentFormGroupId(PARENT_FORM_GROUP_ID_1)
			.build();

	private final ModulePrintConfigsDTO modulePrintConfigsDTO = ModulePrintConfigsDTO.builder()
			.id(FORM_ID_1)
			.sortOrder(FORM_SORT_ORDER)
			.processStatus(PROCESS_STATUS_1)
			.moduleId(MODULE_ID_1)
			.build();

	private final ModulePrintConfigParamDTO modulePrintConfigParamDTO = ModulePrintConfigParamDTO.builder()
			.modulePrintConfigId(MODULE_PRINT_CONFIG_ID)
			.parameterName(PARAMETER_NAME)
			.parameterValue(PARAMETER_VALUE)
			.build();

	private final ApplicationGeneratedPrintDTO applicationGeneratedPrintDTO = ApplicationGeneratedPrintDTO.builder()
			.applicationId(APPLICATION_ID_1)
			.processStatus(PROCESS_STATUS_1)
			.build();

	private final ModuleFormConfigProfileDTO moduleFormConfigProfileDTO = ModuleFormConfigProfileDTO.builder()
			.moduleFormConfigId(MODULE_FORM_CONFIG_ID)
			.requiredProfileCode(REQUIRED_PROFILE_CODE)
			.build();

	private final ModulePrintConfigProfileDTO modulePrintConfigProfileDTO = ModulePrintConfigProfileDTO.builder()
			.modulePrintConfigId(MODULE_FORM_CONFIG_ID)
			.requiredProfileCode(REQUIRED_PROFILE_CODE)
			.build();

	private final ModuleDTO moduleDTO = ModuleDTO.builder()
			.moduleCode(MODULE_CODE)
			.moduleId(MODULE_ID_1)
			.build();

	@Mock
	private FormGroupsCrudService formGroupsCrudService;
	@Mock
	private ModuleFormConfigsCrudService moduleFormConfigsCrudService;
	@Mock
	private ModuleCrudService moduleCrudService;
	@Mock
	private ModuleFormConfigParamCrudService moduleFormConfigParamCrudService;
	@Mock
	private ModuleFormConfigProfilesCrudService moduleFormConfigProfilesCrudService;
	@Mock
	private ModulePrintConfigProfilesCrudService modulePrintConfigProfilesCrudService;
	@Mock
	private ModulePrintConfigsCrudService modulePrintConfigsCrudService;
	@Mock
	private ModulePrintConfigParamCrudService modulePrintConfigParamCrudService;
	@Mock
	private ApplicationGeneratedPrintCrudService applicationGeneratedPrintCrudService;
	@Mock
	private FormCatalogsCrudService formCatalogsCrudService;
	@Mock
	private SecurityContext sc;

	private FormConfigService formConfigService;

	@BeforeEach
	void init() {
		CrudServiceContainer crudServiceContainer = CrudServiceContainer.builder()
				.formGroupsCrudService(formGroupsCrudService)
				.moduleFormConfigsCrudService(moduleFormConfigsCrudService)
				.moduleCrudService(moduleCrudService)
				.moduleFormConfigParamCrudService(moduleFormConfigParamCrudService)
				.moduleFormConfigProfilesCrudService(moduleFormConfigProfilesCrudService)
				.modulePrintConfigProfilesCrudService(modulePrintConfigProfilesCrudService)
				.modulePrintConfigsCrudService(modulePrintConfigsCrudService)
				.modulePrintConfigParamCrudService(modulePrintConfigParamCrudService)
				.applicationGeneratedPrintCrudService(applicationGeneratedPrintCrudService)
				.formCatalogsCrudService(formCatalogsCrudService)
				.build();

		formConfigService = new FormConfigService(crudServiceContainer);
	}

	@Test
	void test_getFormsByModuleIdAndProcessStatus_ok() {
		ApplicationCompileStatusDTO compileStatus1 = ApplicationCompileStatusDTO.builder()
				.status(APPLICATION_COMPILE_STATUS_1)
				.applicationId(APPLICATION_ID_1)
				.compileStatusIdentifier(APPLICATION_COMPILE_STATUS_IDENTIFIER_1)
				.build();
		List<String> profileCodeList = List.of(PROFILE_CODE_1);
		FormGroupDTO formGroup1 = FormGroupDTO.builder()
				.formGroupCode(FORM_GROUP_CODE_1)
				.parentFormGroupId(PARENT_FORM_GROUP_ID_1)
				.formGroupDescription(FORM_GROUP_DESCRIPTION_1)
				.id(FORM_GROUP_ID_1)
				.tenantId(TENANT_1)
				.build();
		FormGroupDTO formGroup2 = FormGroupDTO.builder()
				.formGroupCode(FORM_GROUP_CODE_2)
				.parentFormGroupId(PARENT_FORM_GROUP_ID_2)
				.formGroupDescription(FORM_GROUP_DESCRIPTION_2)
				.id(PARENT_FORM_GROUP_ID_1)
				.tenantId(TENANT_1)
				.build();
		FormGroupDTO formGroup3 = FormGroupDTO.builder()
				.formGroupCode(FORM_GROUP_CODE_3)
				.formGroupDescription(FORM_GROUP_DESCRIPTION_3)
				.id(PARENT_FORM_GROUP_ID_2)
				.tenantId(TENANT_1)
				.build();
		FormGroupPublicDTO formGroupPublic1 = FormGroupPublicDTO.builder()
				.groupCode(FORM_GROUP_CODE_1)
				.groupName(FORM_GROUP_DESCRIPTION_1)
				.build();
		FormGroupPublicDTO formGroupPublic2 = FormGroupPublicDTO.builder()
				.groupCode(FORM_GROUP_CODE_2)
				.groupName(FORM_GROUP_DESCRIPTION_2)
				.build();
		FormGroupPublicDTO formGroupPublic3 = FormGroupPublicDTO.builder()
				.groupCode(FORM_GROUP_CODE_3)
				.groupName(FORM_GROUP_DESCRIPTION_3)
				.build();

		FormDetailsPublicDTO formDetailsPublicDTO = FormDetailsPublicDTO.builder()
				.formConfigId(FORM_ID_1)
				.formCode(FORM_CODE_1)
				.formName(FORM_CATALOG_DESCRIPTION)
				.softwareUrl(FORM_CATALOG_SW_URL)
				.routerUrl(FORM_CATALOG_ROUTER_URL)
				.flReadOnly(FORM_FL_READONLY)
				.sortOrder(FORM_SORT_ORDER)
				.compileStatusIdentifier(APPLICATION_COMPILE_STATUS_IDENTIFIER_1)
				.compileStatus(APPLICATION_COMPILE_STATUS_1)
				.params(Map.of())
				.requiredProfiles(Collections.emptyList())
				.build();
		List<FormGroupPublicDTO> publicFormGroups = List.of(formGroupPublic3, formGroupPublic2, formGroupPublic1);
		FormWithGroupHierarchyPublicDTO formWithGroupHierarchyPublicDTO1 = FormWithGroupHierarchyPublicDTO.builder()
				.formDetails(formDetailsPublicDTO)
				.groups(publicFormGroups)
				.build();
		ModuleFormConfigsDTO moduleFormConfig1 = ModuleFormConfigsDTO.builder()
				.compileStatusIdentifier(APPLICATION_COMPILE_STATUS_IDENTIFIER_1)
				.formId(FORM_CATALOG_ID_1)
				.formGroupId(FORM_GROUP_ID_1)
				.id(FORM_ID_1)
				.flReadOnly(FORM_FL_READONLY)
				.sortOrder(FORM_SORT_ORDER)
				.build();
		List<ModuleFormConfigsDTO> moduleFormConfigs = List.of(moduleFormConfig1);

		List<FormWithGroupHierarchyPublicDTO> expectedResults = List.of(formWithGroupHierarchyPublicDTO1);
		FormCatalogDTO formCatalogDTO = FormCatalogDTO.builder()
				.id(FORM_CATALOG_ID_1)
				.tenantId(TENANT_1)
				.formCode(FORM_CODE_1)
				.formCatalogDescription(FORM_CATALOG_DESCRIPTION)
				.softwareUrl(FORM_CATALOG_SW_URL)
				.routerUrl(FORM_CATALOG_ROUTER_URL)
				.build();

		try {
			when(formGroupsCrudService.findById(TENANT_1, FORM_GROUP_ID_1))
					.thenReturn(formGroup1);
			when(moduleFormConfigsCrudService.find(TENANT_1, MODULE_ID_1, PROCESS_STATUS_1, profileCodeList))
					.thenReturn(moduleFormConfigs);
			when(formCatalogsCrudService.findById(TENANT_1, FORM_CATALOG_ID_1, null))
					.thenReturn(formCatalogDTO);
			when(formGroupsCrudService.findById(TENANT_1, PARENT_FORM_GROUP_ID_1))
					.thenReturn(formGroup2);
			when(formGroupsCrudService.findById(TENANT_1, PARENT_FORM_GROUP_ID_2))
					.thenReturn(formGroup3);
		} catch (ObjectNotFoundException e) {
			fail(e);
		}

		List<FormWithGroupHierarchyPublicDTO> result = formConfigService.getFormsByModuleIdAndProcessStatus(TENANT_1, MODULE_ID_1, PROCESS_STATUS_1,
				List.of(compileStatus1), profileCodeList, null, null);

		assertEquals(expectedResults, result);
	}

	@Test
	void test_getFormsByModuleIdAndProcessStatus_withoutRelatedCompileStatus() {
		List<String> profileCodeList = List.of(PROFILE_CODE_1);
		FormGroupDTO formGroup1 = FormGroupDTO.builder()
				.formGroupCode(FORM_GROUP_CODE_1)
				.formGroupDescription(FORM_GROUP_DESCRIPTION_1)
				.id(FORM_GROUP_ID_1)
				.tenantId(TENANT_1)
				.build();
		FormGroupPublicDTO formGroupPublic1 = FormGroupPublicDTO.builder()
				.groupCode(FORM_GROUP_CODE_1)
				.groupName(FORM_GROUP_DESCRIPTION_1)
				.build();

		FormDetailsPublicDTO formDetailsPublicDTO = FormDetailsPublicDTO.builder()
				.formConfigId(FORM_ID_1)
				.formCode(FORM_CODE_1)
				.formName(FORM_CATALOG_DESCRIPTION)
				.softwareUrl(FORM_CATALOG_SW_URL)
				.routerUrl(FORM_CATALOG_ROUTER_URL)
				.flReadOnly(FORM_FL_READONLY)
				.sortOrder(FORM_SORT_ORDER)
				.compileStatusIdentifier(APPLICATION_COMPILE_STATUS_IDENTIFIER_1)
				.compileStatus(ApplicationCompileStatusCrudService.TO_BE_COMPILED)
				.params(Map.of())
				.requiredProfiles(Collections.emptyList())
				.build();
		List<FormGroupPublicDTO> publicFormGroups = List.of(formGroupPublic1);
		FormWithGroupHierarchyPublicDTO formWithGroupHierarchyPublicDTO = FormWithGroupHierarchyPublicDTO.builder()
				.formDetails(formDetailsPublicDTO)
				.groups(publicFormGroups)
				.build();
		ModuleFormConfigsDTO moduleFormConfig1 = ModuleFormConfigsDTO.builder()
				.compileStatusIdentifier(APPLICATION_COMPILE_STATUS_IDENTIFIER_1)
				.formId(FORM_CATALOG_ID_1)
				.formGroupId(FORM_GROUP_ID_1)
				.id(FORM_ID_1)
				.flReadOnly(FORM_FL_READONLY)
				.sortOrder(FORM_SORT_ORDER)
				.build();
		List<ModuleFormConfigsDTO> moduleFormConfigs = List.of(moduleFormConfig1);

		List<FormWithGroupHierarchyPublicDTO> expectedResults = List.of(formWithGroupHierarchyPublicDTO);
		FormCatalogDTO formCatalogDTO = FormCatalogDTO.builder()
				.id(FORM_CATALOG_ID_1)
				.tenantId(TENANT_1)
				.formCode(FORM_CODE_1)
				.formCatalogDescription(FORM_CATALOG_DESCRIPTION)
				.softwareUrl(FORM_CATALOG_SW_URL)
				.routerUrl(FORM_CATALOG_ROUTER_URL)
				.build();

		try {
			when(formGroupsCrudService.findById(TENANT_1, FORM_GROUP_ID_1))
					.thenReturn(formGroup1);
			when(moduleFormConfigsCrudService.find(TENANT_1, MODULE_ID_1, PROCESS_STATUS_1, profileCodeList))
					.thenReturn(moduleFormConfigs);
			when(formCatalogsCrudService.findById(TENANT_1, FORM_CATALOG_ID_1, null))
					.thenReturn(formCatalogDTO);
		} catch (ObjectNotFoundException e) {
			fail(e);
		}

		List<FormWithGroupHierarchyPublicDTO> result = formConfigService.getFormsByModuleIdAndProcessStatus(TENANT_1, MODULE_ID_1, PROCESS_STATUS_1,
				List.of(), profileCodeList, null, null);

		assertEquals(expectedResults, result);
	}

	@Test
	void test_getFormsByModuleIdAndProcessStatus_withoutCompileStatusIdentifier_ok() {
		ApplicationCompileStatusDTO compileStatus1 = ApplicationCompileStatusDTO.builder()
				.status(APPLICATION_COMPILE_STATUS_1)
				.applicationId(APPLICATION_ID_1)
				.compileStatusIdentifier(APPLICATION_COMPILE_STATUS_IDENTIFIER_1)
				.build();
		List<String> profileCodeList = List.of(PROFILE_CODE_1);
		FormGroupDTO formGroup1 = FormGroupDTO.builder()
				.formGroupCode(FORM_GROUP_CODE_1)
				.formGroupDescription(FORM_GROUP_DESCRIPTION_1)
				.id(FORM_GROUP_ID_1)
				.tenantId(TENANT_1)
				.build();
		FormGroupPublicDTO formGroupPublic1 = FormGroupPublicDTO.builder()
				.groupCode(FORM_GROUP_CODE_1)
				.groupName(FORM_GROUP_DESCRIPTION_1)
				.build();

		FormDetailsPublicDTO formDetailsPublicDTO = FormDetailsPublicDTO.builder()
				.formConfigId(FORM_ID_1)
				.formCode(FORM_CODE_1)
				.formName(FORM_CATALOG_DESCRIPTION)
				.softwareUrl(FORM_CATALOG_SW_URL)
				.routerUrl(FORM_CATALOG_ROUTER_URL)
				.flReadOnly(FORM_FL_READONLY)
				.sortOrder(FORM_SORT_ORDER)
				.params(Map.of())
				.requiredProfiles(Collections.emptyList())
				.build();
		List<FormGroupPublicDTO> publicFormGroups = List.of(formGroupPublic1);
		FormWithGroupHierarchyPublicDTO formWithGroupHierarchyPublicDTO = FormWithGroupHierarchyPublicDTO.builder()
				.formDetails(formDetailsPublicDTO)
				.groups(publicFormGroups)
				.build();
		ModuleFormConfigsDTO moduleFormConfig1 = ModuleFormConfigsDTO.builder()
				.formId(FORM_CATALOG_ID_1)
				.formGroupId(FORM_GROUP_ID_1)
				.id(FORM_ID_1)
				.flReadOnly(FORM_FL_READONLY)
				.sortOrder(FORM_SORT_ORDER)
				.build();
		List<ModuleFormConfigsDTO> moduleFormConfigs = List.of(moduleFormConfig1);

		List<FormWithGroupHierarchyPublicDTO> expectedResults = List.of(formWithGroupHierarchyPublicDTO);
		FormCatalogDTO formCatalogDTO = FormCatalogDTO.builder()
				.id(FORM_CATALOG_ID_1)
				.tenantId(TENANT_1)
				.formCode(FORM_CODE_1)
				.formCatalogDescription(FORM_CATALOG_DESCRIPTION)
				.softwareUrl(FORM_CATALOG_SW_URL)
				.routerUrl(FORM_CATALOG_ROUTER_URL)
				.build();

		try {
			when(formGroupsCrudService.findById(TENANT_1, FORM_GROUP_ID_1))
					.thenReturn(formGroup1);
			when(moduleFormConfigsCrudService.find(TENANT_1, MODULE_ID_1, PROCESS_STATUS_1, profileCodeList))
					.thenReturn(moduleFormConfigs);
			when(formCatalogsCrudService.findById(TENANT_1, FORM_CATALOG_ID_1, null))
					.thenReturn(formCatalogDTO);
		} catch (ObjectNotFoundException e) {
			fail(e);
		}

		List<FormWithGroupHierarchyPublicDTO> result = formConfigService.getFormsByModuleIdAndProcessStatus(TENANT_1, MODULE_ID_1, PROCESS_STATUS_1,
				List.of(compileStatus1), profileCodeList, null, null);

		assertEquals(expectedResults, result);
	}

	@Test
	void test_getFormsByModuleIdAndProcessStatus_formCatalogNotFound_ko() {
		ApplicationCompileStatusDTO compileStatus1 = ApplicationCompileStatusDTO.builder()
				.status(APPLICATION_COMPILE_STATUS_1)
				.applicationId(APPLICATION_ID_1)
				.compileStatusIdentifier(APPLICATION_COMPILE_STATUS_IDENTIFIER_1)
				.build();
		List<String> profileCodeList = List.of(PROFILE_CODE_1);

		ModuleFormConfigsDTO moduleFormConfig1 = ModuleFormConfigsDTO.builder()
				.compileStatusIdentifier(APPLICATION_COMPILE_STATUS_IDENTIFIER_1)
				.formId(FORM_ID_1)
				.formGroupId(FORM_GROUP_ID_1)
				.build();
		List<ModuleFormConfigsDTO> moduleFormConfigs = List.of(moduleFormConfig1);

		try {
			when(moduleFormConfigsCrudService.find(TENANT_1, MODULE_ID_1, PROCESS_STATUS_1, profileCodeList))
					.thenReturn(moduleFormConfigs);
			when(formCatalogsCrudService.findById(TENANT_1, FORM_ID_1, null))
					.thenThrow(ObjectNotFoundException.class);

			List<ApplicationCompileStatusDTO> compileStatuses = List.of(compileStatus1);
			assertThrows(ObjectNotFoundRuntimeException.class,
					() -> formConfigService.getFormsByModuleIdAndProcessStatus(TENANT_1, MODULE_ID_1, PROCESS_STATUS_1,
							compileStatuses, profileCodeList, null, null));
		} catch (Exception e) {
			fail(e.getMessage(), e);
		}
	}

	@Test
	void test_getFormsByModuleIdAndProcessStatus_formGroupNotFound_ko() {
		ApplicationCompileStatusDTO compileStatus1 = ApplicationCompileStatusDTO.builder()
				.status(APPLICATION_COMPILE_STATUS_1)
				.applicationId(APPLICATION_ID_1)
				.compileStatusIdentifier(APPLICATION_COMPILE_STATUS_IDENTIFIER_1)
				.build();
		List<String> profileCodeList = List.of(PROFILE_CODE_1);

		ModuleFormConfigsDTO moduleFormConfig1 = ModuleFormConfigsDTO.builder()
				.compileStatusIdentifier(APPLICATION_COMPILE_STATUS_IDENTIFIER_1)
				.formId(FORM_ID_1)
				.formGroupId(FORM_GROUP_ID_1)
				.build();
		List<ModuleFormConfigsDTO> moduleFormConfigs = List.of(moduleFormConfig1);

		try {
			when(moduleFormConfigsCrudService.find(TENANT_1, MODULE_ID_1, PROCESS_STATUS_1, profileCodeList))
					.thenReturn(moduleFormConfigs);
			when(formGroupsCrudService.findById(TENANT_1, FORM_GROUP_ID_1))
					.thenThrow(ObjectNotFoundException.class);

			List<ApplicationCompileStatusDTO> compileStatuses = List.of(compileStatus1);
			assertThrows(ObjectNotFoundRuntimeException.class,
					() -> formConfigService.getFormsByModuleIdAndProcessStatus(TENANT_1, MODULE_ID_1, PROCESS_STATUS_1,
							compileStatuses, profileCodeList, null, null));
		} catch (Exception e) {
			fail(e);
		}
	}

	@Test
	void test_getFormsByModuleIdAndProcessStatus_parentFormGroupNotFound_ko() {
		FormGroupDTO formGroup1 = FormGroupDTO.builder()
				.formGroupCode(FORM_GROUP_CODE_1)
				.formGroupDescription(FORM_GROUP_DESCRIPTION_1)
				.id(FORM_GROUP_ID_1)
				.tenantId(TENANT_1)
				.parentFormGroupId(PARENT_FORM_GROUP_ID_1)
				.build();
		ApplicationCompileStatusDTO compileStatus1 = ApplicationCompileStatusDTO.builder()
				.status(APPLICATION_COMPILE_STATUS_1)
				.applicationId(APPLICATION_ID_1)
				.compileStatusIdentifier(APPLICATION_COMPILE_STATUS_IDENTIFIER_1)
				.build();
		List<String> profileCodeList = List.of(PROFILE_CODE_1);

		ModuleFormConfigsDTO moduleFormConfig1 = ModuleFormConfigsDTO.builder()
				.compileStatusIdentifier(APPLICATION_COMPILE_STATUS_IDENTIFIER_1)
				.formId(FORM_ID_1)
				.formGroupId(FORM_GROUP_ID_1)
				.build();
		List<ModuleFormConfigsDTO> moduleFormConfigs = List.of(moduleFormConfig1);

		try {
			when(moduleFormConfigsCrudService.find(TENANT_1, MODULE_ID_1, PROCESS_STATUS_1, profileCodeList))
					.thenReturn(moduleFormConfigs);
			when(formGroupsCrudService.findById(TENANT_1, FORM_GROUP_ID_1))
					.thenReturn(formGroup1);
			when(formGroupsCrudService.findById(TENANT_1, PARENT_FORM_GROUP_ID_1))
					.thenThrow(ObjectNotFoundException.class);

			List<ApplicationCompileStatusDTO> compileStatuses = List.of(compileStatus1);
			assertThrows(ObjectNotFoundRuntimeException.class,
					() -> formConfigService.getFormsByModuleIdAndProcessStatus(TENANT_1, MODULE_ID_1, PROCESS_STATUS_1,
							compileStatuses, profileCodeList, null, null));
		} catch (Exception e) {
			fail(e);
		}
	}

	@Test
	void test_getFormsByModuleIdAndProcessStatus_RuntimeException_ko() {
		ApplicationCompileStatusDTO compileStatus1 = ApplicationCompileStatusDTO.builder()
				.status(APPLICATION_COMPILE_STATUS_1)
				.applicationId(APPLICATION_ID_1)
				.compileStatusIdentifier(APPLICATION_COMPILE_STATUS_IDENTIFIER_1)
				.build();
		List<String> profileCodeList = List.of(PROFILE_CODE_1);
		FormGroupDTO formGroup1 = FormGroupDTO.builder()
				.formGroupCode(FORM_GROUP_CODE_1)
				.parentFormGroupId(PARENT_FORM_GROUP_ID_1)
				.formGroupDescription(FORM_GROUP_DESCRIPTION_1)
				.id(FORM_GROUP_ID_1)
				.tenantId(TENANT_1)
				.build();
		FormGroupDTO formGroup2 = FormGroupDTO.builder()
				.formGroupCode(FORM_GROUP_CODE_2)
				.parentFormGroupId(PARENT_FORM_GROUP_ID_2)
				.formGroupDescription(FORM_GROUP_DESCRIPTION_2)
				.id(FORM_GROUP_ID_2)
				.tenantId(TENANT_1)
				.build();
		FormGroupDTO formGroup3 = FormGroupDTO.builder()
				.formGroupCode(FORM_GROUP_CODE_3)
				.formGroupDescription(FORM_GROUP_DESCRIPTION_3)
				.id(PARENT_FORM_GROUP_ID_2)
				.tenantId(TENANT_1)
				.build();

		ModuleFormConfigsDTO moduleFormConfig1 = ModuleFormConfigsDTO.builder()
				.compileStatusIdentifier(APPLICATION_COMPILE_STATUS_IDENTIFIER_1)
				.formId(FORM_CATALOG_ID_1)
				.formGroupId(FORM_GROUP_ID_1)
				.id(FORM_ID_1)
				.flReadOnly(FORM_FL_READONLY)
				.sortOrder(FORM_SORT_ORDER)
				.build();
		List<ModuleFormConfigsDTO> moduleFormConfigs = List.of(moduleFormConfig1);
		List<ApplicationCompileStatusDTO> compileStatuses = List.of(compileStatus1);
		FormCatalogDTO formCatalogDTO = FormCatalogDTO.builder()
				.id(FORM_CATALOG_ID_1)
				.tenantId(TENANT_1)
				.formCode(FORM_CODE_1)
				.formCatalogDescription(FORM_CATALOG_DESCRIPTION)
				.softwareUrl(FORM_CATALOG_SW_URL)
				.routerUrl(FORM_CATALOG_ROUTER_URL)
				.build();

		try {
			when(formGroupsCrudService.findById(TENANT_1, FORM_GROUP_ID_1))
					.thenReturn(formGroup1);
			when(moduleFormConfigsCrudService.find(TENANT_1, MODULE_ID_1, PROCESS_STATUS_1, profileCodeList))
					.thenReturn(moduleFormConfigs);
			when(formCatalogsCrudService.findById(TENANT_1, FORM_CATALOG_ID_1))
					.thenReturn(formCatalogDTO);
			when(formGroupsCrudService.findById(TENANT_1, PARENT_FORM_GROUP_ID_1))
					.thenReturn(formGroup2);
			when(formGroupsCrudService.findById(TENANT_1, PARENT_FORM_GROUP_ID_2))
					.thenReturn(formGroup3);
			when(moduleCrudService.findModuleWithDetail(any())).thenReturn(new ModuleWithDetailDTO());
		} catch (ObjectNotFoundException e) {
			fail(e);
		}

		assertThrows(RuntimeException.class, () -> formConfigService.getFormsByModuleIdAndProcessStatus(TENANT_1, MODULE_ID_1,
				PROCESS_STATUS_1, compileStatuses, profileCodeList, null, null));
	}

	@Test
	void checkForModuleFormConfigProfiles_false_ko() {

		when(moduleFormConfigProfilesCrudService.find(TENANT_1, FORM_ID_1)).thenReturn(List.of(moduleFormConfigProfileDTO));

		Boolean result = formConfigService.checkForModuleFormConfigProfiles(TENANT_1, moduleFormConfigsDTO, List.of(PROFILE_CODE_1));

		assertEquals(false, result);
	}

	@Test
	void checkForModuleFormConfigProfiles_true_ko() {
		Boolean result = formConfigService.checkForModuleFormConfigProfiles(TENANT_1, null, List.of(PROFILE_CODE_1));

		assertEquals(true, result);
	}

	@Test
	void checkForModulePrintConfigProfiles_false_ko() {

		when(modulePrintConfigProfilesCrudService.find(TENANT_1, FORM_ID_1)).thenReturn(List.of(modulePrintConfigProfileDTO));

		Boolean result = formConfigService.checkForModulePrintConfigProfiles(TENANT_1, modulePrintConfigsDTO, List.of(PROFILE_CODE_1));

		assertEquals(false, result);
	}

	@Test
	void checkForModulePrintConfigProfiles_true_ko() {
		Boolean result = formConfigService.checkForModulePrintConfigProfiles(TENANT_1, null, List.of(PROFILE_CODE_1));

		assertEquals(true, result);
	}

	@Test
	void getPrintsByModuleIdAndProcessStatus_ko() {

		PrintDetailsOutDTO expectedResult = PrintDetailsOutDTO.builder()
				.printConfigId(FORM_ID_1)
				.sortOrder(FORM_SORT_ORDER)
				.params(Map.of(PARAMETER_NAME, PARAMETER_VALUE))
				.lastPrint(LastPrintDTO.builder().build())
				.build();

		try {

			when(modulePrintConfigsCrudService.find(TENANT_1, MODULE_ID_1, PROCESS_STATUS_1, List.of(PROFILE_CODE_1)))
					.thenReturn(List.of(modulePrintConfigsDTO));
			when(modulePrintConfigParamCrudService.find(any(), any())).thenReturn(List.of(modulePrintConfigParamDTO));
			when(applicationGeneratedPrintCrudService.findLastGeneratedPrintByCode(any(), any(), any())).thenReturn(Optional.of(applicationGeneratedPrintDTO));
			List<PrintDetailsOutDTO> result = formConfigService
					.getPrintsByModuleIdAndProcessStatus(TENANT_1, APPLICATION_ID_1, MODULE_ID_1, PROCESS_STATUS_1, List.of(PROFILE_CODE_1), sc);

			assertEquals(List.of(expectedResult), result);
		} catch (Exception e) {
			fail(e.getMessage(), e);
		}

	}

	@Test
	void findModuleFormConfigsByModuleCode_ko() {

		ModuleFormConfigsPublicDTO config = ModuleFormConfigsPublicDTO.builder()
				.formConfigId(FORM_ID_1)
				.formCode(FORM_CODE_1)
				.formGroupCode(FORM_GROUP_CODE_1)
				.sortOrder(FORM_SORT_ORDER)
				.flReadOnly(FORM_FL_READONLY)
				.compileStatusIdentifier(APPLICATION_COMPILE_STATUS_IDENTIFIER_1)
				.params(Map.of(PARAMETER_NAME, PARAMETER_VALUE))
				.requiredProfiles(Collections.emptyList())
				.build();

		ModuleWithParamsPublicDTO expectedResult = ModuleWithParamsPublicDTO.builder()
				.moduleCode(MODULE_CODE)
				.configs(List.of(config))
				.build();

		try {
			when(moduleCrudService.findByCode(TENANT_1, MODULE_CODE)).thenReturn(Optional.of(moduleDTO));

			when(moduleFormConfigsCrudService.findAllModuleFormConfigs(TENANT_1, MODULE_ID_1)).thenReturn(List.of(moduleFormConfigsDTO));

			when(moduleFormConfigParamCrudService.find(TENANT_1, FORM_ID_1)).thenReturn(List.of(moduleFormConfigParamDTO));

			when(formCatalogsCrudService.findById(TENANT_1, FORM_CATALOG_ID_1)).thenReturn(formCatalogDTO);

			when(formGroupsCrudService.findById(TENANT_1, FORM_GROUP_ID_1)).thenReturn(formGroupDTO);

			ModuleWithParamsPublicDTO result = formConfigService.findModuleFormConfigsByModuleCode(TENANT_1, MODULE_CODE);

			assertEquals(expectedResult, result);
		} catch (Exception e) {
			fail(e.getMessage(), e);
		}

	}

}
