package com.abacogroup.agri.applications.core.services.workflow;

import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;

@Slf4j
@ExtendWith(MockitoExtension.class)
class FileFactoryTest {

    private static File tempFile = null;

    @InjectMocks
    private FileFactory fileFactory;

    @BeforeEach
    void init() throws IOException {
        fileFactory = new FileFactory();
        tempFile = Files.createTempFile("tempFile", ".txt").toFile();
    }

    @AfterAll
    static void atFinally() {
        tempFile.delete();
    }


    @Test
    void test_createFile() {
        byte[] array = new byte[10];
        ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(array);

        try {
            tempFile = fileFactory.createFile(byteArrayInputStream);
        } catch (Exception e) {
            Assertions.fail();
        }
    }



}
