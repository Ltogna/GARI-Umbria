package com.abacogroup.agri.applications.resources;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.List;

import com.abacogroup.agri.applications.core.model.ProgressTypeEnum;
import com.abacogroup.applicationworkflowsdk.model.CreateProcessType;
import jakarta.ws.rs.core.SecurityContext;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.abacogroup.agri.applications.core.model.dto.publics.ApplicationsSummaryByYearOutDTO;
import com.abacogroup.agri.applications.core.model.dto.publics.CreateApplicationInDTO;
import com.abacogroup.agri.applications.core.model.dto.publics.CreateApplicationOutDTO;
import com.abacogroup.agri.applications.core.services.ApplicationsService;
import com.abacogroup.dropwizard.auth.sso2.User;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@ExtendWith(MockitoExtension.class)
class ApplicationsPrivateResourcesTest {

	@Mock
	private ApplicationsService applicationsService;
	@InjectMocks
	private ApplicationsPrivateResources applicationsPrivateResources;

	private static final String TENANT_1 = "tenant1";
	private static final Long PARTY_ID_1 = 12L;
	private static final String USERNAME = "username";
	private static final User user = new User(USERNAME, TENANT_1);
	private final SecurityContext sc = mock(SecurityContext.class);

	{
		User p = mock(User.class);
		when(sc.getUserPrincipal()).thenReturn(p);
		when(p.getName()).thenReturn(USERNAME);
		when(p.getUserId()).thenReturn(USERNAME);
	}

	@Test
	void getApplicationsSummary_ok() {
		ApplicationsSummaryByYearOutDTO results = ApplicationsSummaryByYearOutDTO.builder()
				.partyId(PARTY_ID_1)
				.applicationsSummaryByYear(List.of())
				.build();
		when(applicationsService.getApplicationsSummaryByYear(any(), any(), any(), any())).thenReturn(results);

		assertEquals(results, applicationsPrivateResources.getApplicationsSummary(TENANT_1, PARTY_ID_1, new User(USERNAME, TENANT_1), sc));
	}

	@Test
	void createApplication_ok() {
		CreateApplicationInDTO createApplicationInDTO = CreateApplicationInDTO.builder()
				.partyId(PARTY_ID_1)
				.moduleCode("0001")
				.build();

		CreateApplicationOutDTO createApplicationOutDTO = CreateApplicationOutDTO.builder()
				.applicationCode("2000")
				.build();

		when(applicationsService.createApplication(TENANT_1, user , createApplicationInDTO, CreateProcessType.ASYNC, null)).thenReturn(createApplicationOutDTO);

		assertEquals(createApplicationOutDTO,
				applicationsPrivateResources.createApplicationAsync(TENANT_1, new User(USERNAME, TENANT_1), createApplicationInDTO, sc));
	}
}
