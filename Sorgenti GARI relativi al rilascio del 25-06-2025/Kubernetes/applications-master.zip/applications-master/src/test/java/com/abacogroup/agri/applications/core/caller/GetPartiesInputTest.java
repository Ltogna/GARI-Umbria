package com.abacogroup.agri.applications.core.caller;

import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class GetPartiesInputTest {

    private GetPartiesInput getPartiesInput;

    private static final String CUAA = "CUAA";
    private static final String URL = "URL";
    private static final String TENANT = "TENANT";
    private static final String DESCRIPTION = "DESCRIPTION";

	@Test
	void simpleTest() {
		// Simple test for sonar issue
		assertTrue(true);
	}

/* TODO
    @BeforeEach
    void init() {
        getPartiesInput = GetPartiesInput.builder()
                .cuaa(CUAA)
                .description(DESCRIPTION)
                .tenant(TENANT)
                .url(URL)
                .build();
    }

    @Test
    void of_ok() {
        GetPartiesInput expectedOutput = GetPartiesInput.builder()
                .cuaa(CUAA)
                .url(URL)
                .tenant(TENANT)
                .description(DESCRIPTION)
                .build();

        GetPartiesInput result = GetPartiesInput.of(URL, CUAA, TENANT, DESCRIPTION);

        assertEquals(expectedOutput, result);
    }


    @Test
    void getHttpMethod_ok() {
        assertNull(getPartiesInput.getHttpMethod());
    }*/
}
