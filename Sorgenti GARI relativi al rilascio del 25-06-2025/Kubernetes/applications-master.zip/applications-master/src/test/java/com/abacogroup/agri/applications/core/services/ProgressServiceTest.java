package com.abacogroup.agri.applications.core.services;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.fail;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.List;
import java.util.Optional;

import com.abacogroup.agri.applications.core.services.crud.ModuleCrudService;
import com.abacogroup.dropwizard.auth.sso2.Sso2Client;
import org.jdbi.v3.core.Handle;
import org.jdbi.v3.core.HandleConsumer;
import org.jdbi.v3.core.Jdbi;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.slf4j.MDC;

import com.abacogroup.agri.applications.core.exceptions.ApplicationNotFoundRuntimeException;
import com.abacogroup.agri.applications.core.exceptions.NoTransitionFoundRuntimeException;
import com.abacogroup.agri.applications.core.exceptions.ObjectNotFoundException;
import com.abacogroup.agri.applications.core.model.ProcessTransitionEnum;
import com.abacogroup.agri.applications.core.model.ProgressTypeEnum;
import com.abacogroup.agri.applications.core.model.dto.ApplicationDetailsDTO;
import com.abacogroup.agri.applications.core.model.dto.publics.ApplicationDTO;
import com.abacogroup.agri.applications.core.model.dto.publics.ProgressApplicationDTO;
import com.abacogroup.agri.applications.core.services.crud.ApplicationDetailsCrudService;
import com.abacogroup.agri.applications.core.services.crud.ApplicationsCrudService;
import com.abacogroup.agri.applications.core.services.embededqueue.CreateProcessQueue;
import com.abacogroup.agri.applications.core.services.embededqueue.UpdateProcessQueue;
import com.abacogroup.agri.applications.core.services.embededqueue.model.QueueWorkflowParams;
import com.abacogroup.agri.applications.core.services.workflow.ApplicationsWorkflowService;
import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.jaxrsutils.filter.MDCPreFilter;
import com.abacogroup.workflow.sdk.beans.WorkflowMessage;
import com.abacogroup.workflow.server.model.DetailedTransitionLog;
import com.abacogroup.workflow.server.model.Transition;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@ExtendWith(MockitoExtension.class)
class ProgressServiceTest {

	@Mock
	private Jdbi jdbi;
	@Mock
	private ApplicationsWorkflowService applicationsWorkflowService;
	@Mock
	private ApplicationDetailsCrudService applicationDetailsCrudService;
	@Mock
	private ApplicationsCrudService applicationsCrudService;
	@Mock
	private ForceReadOnlyContextCheckerService forceReadOnlyContextCheckerService;
	@Mock
	private CreateProcessQueue createProcessQueue;
	@Mock
	private UpdateProcessQueue updateProcessQueue;
	@Mock
	private Handle handle;
	@InjectMocks
	private ProgressService progressService;

	private static final String TENANT_1 = "tenant_1";
	private static final Long PARTY_ID_1 = 24L;
	private static final Integer YEAR_1 = 2022;
	private static final Long APPLICATION_ID_1 = 30L;
	private static final String SCOPE = "scope";
	private static final Long MODULE_ID_1 = 1L;
	private static final Integer TRANSITION_ID = 5;
	private static final String NODE_FROM = "node from";
	private static final String NODE_TO = "node to";
	private static final String NOTES = "notes";
	private static final Long PROCESS_ID_1 = 1L;
	private static final String USER_1 = "user_1";
	private static final LocalDateTime NOW = LocalDateTime.now();
	private static final String PROCESS_STATUS = "start";
	private static final User logged_user1 = new User(USER_1, TENANT_1);
	private static final LocalDateTime DEFAULT_NOT_DELETED_DATE = LocalDateTime.ofInstant(Instant.ofEpochSecond(253402300799L), ZoneOffset.UTC);
	private static final String APPLICATION_CODE_1 = "30";
	private static final Long APPLICATION_DETAILS_ID_1 = 36L;
	private static final User USER = new User(USER_1, TENANT_1);

	@BeforeEach
	protected void init() {
		progressService = new ProgressService(
				jdbi,
				applicationsWorkflowService,
				applicationsCrudService,
				applicationDetailsCrudService,
				updateProcessQueue,
				forceReadOnlyContextCheckerService);
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Test
	void test_progress_async_ok() {
		try {
			ArgumentCaptor<HandleConsumer> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(HandleConsumer.class);

			ApplicationDTO applicationDTO = ApplicationDTO.builder()
					.moduleId(MODULE_ID_1)
					.applicationId(APPLICATION_ID_1)
					.referredYear(YEAR_1)
					.partyId(PARTY_ID_1)
					.processId(PROCESS_ID_1)
					.build();
			List<String> tags = List.of("Tag - 1", "Tag - 2", "Tag - 3", "Tag - 4");
			Transition transition = Transition.builder()
					.scope(SCOPE)
					.id(TRANSITION_ID)
					.notesRequired(false)
					.fromNode(NODE_FROM)
					.toNode(NODE_TO)
					.tags(tags)
					.build();
			ProgressApplicationDTO progressApplicationDTO = ProgressApplicationDTO.builder()
					.notes(NOTES)
					.build();
			ApplicationDetailsDTO applicationDetailsDTO = ApplicationDetailsDTO.builder()
					.applicationCode(APPLICATION_CODE_1)
					.applicationId(APPLICATION_ID_1)
					.dtDelete(DEFAULT_NOT_DELETED_DATE)
					.dtInsert(NOW)
					.pkid(APPLICATION_DETAILS_ID_1)
					.processStatus(PROCESS_STATUS)
					.userIdInsert(USER_1)
					.flInTransition(0)
					.build();
			QueueWorkflowParams queueWorkflowParams = QueueWorkflowParams.builder()
					.processId(PROCESS_ID_1)
					.applicationId(APPLICATION_ID_1)
					.tenant(TENANT_1)
					.transitionId(TRANSITION_ID)
					.username(USER_1)
					.userid(USER_1)
					.locale(Optional.ofNullable(MDC.get(MDCPreFilter.LOCALE)).orElse("it"))
					.scope(SCOPE)
					.notes(progressApplicationDTO.getNotes())
					.build();

			when(applicationsCrudService.findById(TENANT_1, APPLICATION_ID_1))
					.thenReturn(applicationDTO);
			when(applicationsWorkflowService.getUserAvailableTransitions(TENANT_1, APPLICATION_ID_1, PROCESS_ID_1, logged_user1, SCOPE))
					.thenReturn(List.of(transition));
			when(applicationDetailsCrudService.findApplicationDetailById(TENANT_1, APPLICATION_ID_1))
					.thenReturn(applicationDetailsDTO);

			progressService.progress(TENANT_1, APPLICATION_ID_1, "Tag - 1", logged_user1, SCOPE, progressApplicationDTO, ProgressTypeEnum.ASYNC);

			verify(jdbi).useTransaction(handleConsumerLambdaCaptor.capture());
			handleConsumerLambdaCaptor.getValue().useHandle(handle);

			verify(applicationDetailsCrudService, times(1))
					.updateProcessStatusAndFlTransition(TENANT_1, APPLICATION_ID_1, PROCESS_STATUS, USER_1, ProcessTransitionEnum.IN_TRANSITION);
			verify(updateProcessQueue, times(1))
					.add(eq(queueWorkflowParams), anyLong());
		} catch (Exception e) {
			fail(e);
		}
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Test
	void test_progress_sync_ok() {
		try {
			ArgumentCaptor<HandleConsumer> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(HandleConsumer.class);

			ApplicationDTO applicationDTO = ApplicationDTO.builder()
					.moduleId(MODULE_ID_1)
					.applicationId(APPLICATION_ID_1)
					.referredYear(YEAR_1)
					.partyId(PARTY_ID_1)
					.processId(PROCESS_ID_1)
					.build();
			List<String> tags = List.of("Tag - 1", "Tag - 2", "Tag - 3", "Tag - 4");
			Transition transition = Transition.builder()
					.scope(SCOPE)
					.id(TRANSITION_ID)
					.notesRequired(false)
					.fromNode(NODE_FROM)
					.toNode(NODE_TO)
					.tags(tags)
					.build();
			ProgressApplicationDTO progressApplicationDTO = ProgressApplicationDTO.builder()
					.notes(NOTES)
					.build();
			ApplicationDetailsDTO applicationDetailsDTO = ApplicationDetailsDTO.builder()
					.applicationCode(APPLICATION_CODE_1)
					.applicationId(APPLICATION_ID_1)
					.dtDelete(DEFAULT_NOT_DELETED_DATE)
					.dtInsert(NOW)
					.pkid(APPLICATION_DETAILS_ID_1)
					.processStatus(PROCESS_STATUS)
					.userIdInsert(USER_1)
					.flInTransition(0)
					.build();
			QueueWorkflowParams queueWorkflowParams = QueueWorkflowParams.builder()
					.processId(PROCESS_ID_1)
					.applicationId(APPLICATION_ID_1)
					.tenant(TENANT_1)
					.transitionId(TRANSITION_ID)
					.username(USER_1)
					.userid(USER_1)
					.locale(Optional.ofNullable(MDC.get(MDCPreFilter.LOCALE)).orElse("it"))
					.scope(SCOPE)
					.notes(progressApplicationDTO.getNotes())
					.build();

			when(applicationsCrudService.findById(TENANT_1, APPLICATION_ID_1))
					.thenReturn(applicationDTO);
			when(applicationsWorkflowService.getUserAvailableTransitions(TENANT_1, APPLICATION_ID_1, PROCESS_ID_1, logged_user1, SCOPE))
					.thenReturn(List.of(transition));
			when(applicationDetailsCrudService.findApplicationDetailById(TENANT_1, APPLICATION_ID_1))
					.thenReturn(applicationDetailsDTO);

			progressService.progress(TENANT_1, APPLICATION_ID_1, "Tag - 1", logged_user1, SCOPE, progressApplicationDTO, ProgressTypeEnum.SYNC);

			verify(jdbi).useTransaction(handleConsumerLambdaCaptor.capture());
			handleConsumerLambdaCaptor.getValue().useHandle(handle);

			verify(applicationDetailsCrudService, times(1))
					.updateProcessStatusAndFlTransition(TENANT_1, APPLICATION_ID_1, PROCESS_STATUS, USER_1, ProcessTransitionEnum.IN_TRANSITION);
			verify(updateProcessQueue, times(1))
					.executeTransition(queueWorkflowParams, null);
		} catch (Exception e) {
			fail(e);
		}
	}

	@Test
	void test_progress_ApplicationNotFoundRuntimeException() {
		try {
			ProgressApplicationDTO progressApplicationDTO = ProgressApplicationDTO.builder()
					.notes(NOTES)
					.build();

			when(applicationsCrudService.findById(TENANT_1, APPLICATION_ID_1))
					.thenThrow(ObjectNotFoundException.class);

			assertThrows(ApplicationNotFoundRuntimeException.class,
					() -> progressService
							.progress(TENANT_1, APPLICATION_ID_1, "Tag - 1", logged_user1, SCOPE, progressApplicationDTO, ProgressTypeEnum.ASYNC));
		} catch (Exception e) {
			fail(e);
		}
	}

	@Test
	void test_progress_NoTransitionFoundRuntimeException() {
		try {
			ApplicationDTO applicationDTO = ApplicationDTO.builder()
					.moduleId(MODULE_ID_1)
					.applicationId(APPLICATION_ID_1)
					.referredYear(YEAR_1)
					.partyId(PARTY_ID_1)
					.processId(PROCESS_ID_1)
					.build();
			ProgressApplicationDTO progressApplicationDTO = ProgressApplicationDTO.builder()
					.notes(NOTES)
					.build();

			when(applicationsCrudService.findById(TENANT_1, APPLICATION_ID_1))
					.thenReturn(applicationDTO);
			when(applicationsWorkflowService.getUserAvailableTransitions(TENANT_1, APPLICATION_ID_1, PROCESS_ID_1, logged_user1, SCOPE))
					.thenReturn(List.of());

			assertThrows(NoTransitionFoundRuntimeException.class,
					() -> progressService
							.progress(TENANT_1, APPLICATION_ID_1, "Tag - 1", logged_user1, SCOPE, progressApplicationDTO, ProgressTypeEnum.ASYNC));
		} catch (Exception e) {
			fail(e);
		}
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Test
	void test_progress_JDBI_ApplicationNotFoundRuntimeException() {
		try {
			ArgumentCaptor<HandleConsumer> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(HandleConsumer.class);

			ProgressApplicationDTO progressApplicationDTO = ProgressApplicationDTO.builder()
					.notes(NOTES)
					.build();

			when(applicationsCrudService.findById(any(), any())).thenReturn(ApplicationDTO.builder().build());
			when(applicationDetailsCrudService.findApplicationDetailById(TENANT_1, APPLICATION_ID_1))
					.thenThrow(ObjectNotFoundException.class);

			assertThrows(ApplicationNotFoundRuntimeException.class, () -> {
				progressService.progress(TENANT_1, APPLICATION_ID_1, TRANSITION_ID, logged_user1, SCOPE, progressApplicationDTO, ProgressTypeEnum.ASYNC);

				verify(jdbi).useTransaction(handleConsumerLambdaCaptor.capture());
				handleConsumerLambdaCaptor.getValue().useHandle(handle);
			});
		} catch (Exception e) {
			fail(e);
		}
	}

	@Test
	void lastTransitionHasError_ok() {
		WorkflowMessage workflowMessage = new WorkflowMessage("Code", "Description", WorkflowMessage.Type.ERROR);
		DetailedTransitionLog detailedTransitionLog = mock(DetailedTransitionLog.class);
		try {
			when(applicationsCrudService.findById(TENANT_1, APPLICATION_ID_1))
					.thenReturn(ApplicationDTO.builder()
							.processId(PROCESS_ID_1)
							.build());
			when(applicationsWorkflowService.getProcessTransitionHistory(TENANT_1, PROCESS_ID_1, USER))
					.thenReturn(List.of(detailedTransitionLog));
			when(detailedTransitionLog.getMessages())
					.thenReturn(List.of(workflowMessage));

			assertTrue(progressService.lastTransitionHasError(TENANT_1, APPLICATION_ID_1, USER));
		} catch (Exception e) {
			fail(e);
		}
	}
}
