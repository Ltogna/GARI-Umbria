package com.abacogroup.agri.applications.core.services.workflow.sdkimpl;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.time.LocalDateTime;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.slf4j.MDC;

import com.abacogroup.agri.applications.core.model.dto.ApplicationGeneratedPrintDTO;
import com.abacogroup.agri.applications.core.model.dto.publics.ApplicationProtocolsDTO;
import com.abacogroup.agri.applications.core.model.dto.publics.ApplicationWithDetailsDTO;
import com.abacogroup.agri.applications.core.services.crud.ApplicationGeneratedPrintCrudService;
import com.abacogroup.agri.applications.core.services.crud.ApplicationProtocolsCrudService;
import com.abacogroup.agri.applications.core.services.crud.ApplicationsCrudService;
import com.abacogroup.agri.applications.core.services.crud.CrudServiceContainer;
import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.jaxrsutils.filter.MDCPreFilter;

@ExtendWith(MockitoExtension.class)
class ApplicationProtocolUtilsImplTest {
    @Mock
    ApplicationsCrudService applicationsCrudService;
    @Mock
    ApplicationProtocolsCrudService applicationProtocolsCrudService;
    @Mock
    ApplicationGeneratedPrintCrudService applicationGeneratedPrintCrudService;

    ApplicationProtocolUtilsImpl applicationProtocolUtils;

    private static final String TENANT = "ADMIN";
    private static final Long APPLICATION_ID = 5L;
    private static final String USERNAME = "Username";
    private static final User USER = new User(USERNAME, TENANT);
    private static final Long PROCESS_ID = 10L;
    private static final Integer REFERRED_YEAR = 2023;
    private static final Long MODULE_ID = 15L;
    private static final Long PARTY_ID = 123456L;
    private static final String MODULE_DESCRIPTION = "Module Description";
    private static final String SECTOR_DESCRIPTION = "Sector Description";
    private static final String PROCESS_STATUS = "Process Status";
    private static final String PRINT_CODE = "Print Code";
    private static final String PRINT_DESCRIPTION = "Print Description";
    private static final String PRINT_STATUS = "Print Status";
    private static final String PRINT_JOB_UUID = "Print Job UUID";
    private static final String FILE_ID = "File ID";
    private static final Long PKID = 1L;
    private static final LocalDateTime NOW = LocalDateTime.now();

	@BeforeEach
	void init() {
		CrudServiceContainer crudServiceContainer = CrudServiceContainer.builder()
				.applicationsCrudService(applicationsCrudService)
				.applicationProtocolsCrudService(applicationProtocolsCrudService)
				.applicationGeneratedPrintCrudService(applicationGeneratedPrintCrudService)
				.build();

		applicationProtocolUtils = new ApplicationProtocolUtilsImpl(crudServiceContainer, null);
	}

    private final ApplicationWithDetailsDTO applicationWithDetails = ApplicationWithDetailsDTO.builder()
            .applicationId(APPLICATION_ID)
            .processId(PROCESS_ID)
            .referredYear(REFERRED_YEAR)
            .moduleId(MODULE_ID)
            .moduleDescription(MODULE_DESCRIPTION)
            .sectorDescription(SECTOR_DESCRIPTION)
            .partyId(PARTY_ID)
            .processStatus(PROCESS_STATUS)
            .build();
    private final ApplicationGeneratedPrintDTO applicationGeneratedPrintDTO = ApplicationGeneratedPrintDTO.builder()
            .printCode(PRINT_CODE)
            .applicationId(APPLICATION_ID)
            .printDescription(PRINT_DESCRIPTION)
            .fileId(FILE_ID)
            .pkid(PKID)
            .printStatus(PRINT_STATUS)
            .printJobUuid(PRINT_JOB_UUID)
            .printDate(NOW)
            .username(USERNAME)
            .processStatus(PROCESS_STATUS)
            .build();

    @Test
    void retrieveSectorDescription_ok() {
        when(applicationsCrudService.findWithDetailsByApplicationId(TENANT, APPLICATION_ID, MDC.get(MDCPreFilter.LOCALE)))
                .thenReturn(applicationWithDetails);

        String result =
                applicationProtocolUtils.retrieveSectorDescription(TENANT, APPLICATION_ID, USER, MDC.get(MDCPreFilter.LOCALE));

        assertEquals(SECTOR_DESCRIPTION, result);
    }

    @Test
    void retrieveModuleDescription_ok() {
        when(applicationsCrudService.findWithDetailsByApplicationId(TENANT, APPLICATION_ID, MDC.get(MDCPreFilter.LOCALE)))
                .thenReturn(applicationWithDetails);

        String result =
                applicationProtocolUtils.retrieveModuleDescription(TENANT, APPLICATION_ID, USER, MDC.get(MDCPreFilter.LOCALE));

        assertEquals(MODULE_DESCRIPTION, result);
    }

    @Test
    void insertProtocolRequest_ok() {
        applicationProtocolUtils.insertProtocolRequest(TENANT, APPLICATION_ID, USER);

        verify(applicationProtocolsCrudService, times(1))
                .insert(any(ApplicationProtocolsDTO.class), eq(USERNAME));
    }

    @Test
    void retrievePrintId_ok() {
        when(applicationGeneratedPrintCrudService.findAllGeneratedPrints(TENANT, APPLICATION_ID))
                .thenReturn(List.of(applicationGeneratedPrintDTO));

        String result = applicationProtocolUtils.retrievePrintId(TENANT, APPLICATION_ID, PRINT_CODE, USER);

        assertEquals(FILE_ID, result);
    }

    @Test
    void retrievePrintId_ko() {
        when(applicationGeneratedPrintCrudService.findAllGeneratedPrints(TENANT, APPLICATION_ID))
                .thenReturn(List.of());

        assertThrows(RuntimeException.class, () ->
                applicationProtocolUtils.retrievePrintId(TENANT, APPLICATION_ID, PRINT_CODE, USER));
    }
}