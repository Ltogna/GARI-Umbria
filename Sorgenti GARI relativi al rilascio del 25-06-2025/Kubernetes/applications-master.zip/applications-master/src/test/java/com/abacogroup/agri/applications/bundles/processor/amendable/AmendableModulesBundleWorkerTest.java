package com.abacogroup.agri.applications.bundles.processor.amendable;

import com.abacogroup.agri.applications.bundles.BundleConstants;
import com.abacogroup.agri.applications.bundles.model.amendable.BundleAmendableModuleInDTO;
import com.abacogroup.agri.applications.bundles.model.amendable.BundleAmendableModulesMessage;
import com.abacogroup.agri.applications.core.exceptions.ObjectNotFoundRuntimeException;
import com.abacogroup.agri.applications.core.model.dto.AmendableModuleDTO;
import com.abacogroup.agri.applications.core.model.dto.ModuleDTO;
import com.abacogroup.agri.applications.core.services.crud.AmendableModuleCrudService;
import com.abacogroup.agri.applications.core.services.crud.ModuleCrudService;
import com.abacogroup.agri.applications.core.services.crud.SectorsCrudService;
import com.abacogroup.bundles.listener.configdata.ConfigDataMessage;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@Slf4j
@ExtendWith(MockitoExtension.class)
class AmendableModulesBundleWorkerTest {

    private static final String TEMPLATE_TENANT_ID = "*";
    private static final Long PKID = 1L;
    private static final Long MODULE_ID = 123L;
    private static final Long AMENDABLE_MODULE_ID = 456L;
    private static final Long OLD_MODULE_ID = 789L;
    private static final String MODULE_CODE = "module_code";
    private static final String USER = "user";
    private static final String AMENDABLE_MODULE_CODE = "AMENDABLE_MODULE_CODE";
    private static final String OLD_AMENDABLE_MODULE_CODE = "OLD_AMENDABLE_MODULE_CODE";
    private static final Long SECTOR_ID = 10L;
    private static final Long SECTOR_ID_2 = 20L;

    private static final String WORKFLOW_CODE = "workflow_code";

    private final ModuleDTO module = ModuleDTO.builder()
            .moduleId(MODULE_ID)
            .sectorId(SECTOR_ID)
            .moduleCode(MODULE_CODE)
            .workflowCode(WORKFLOW_CODE)
            .flAmendModule(false)
            .build();

    private final ModuleDTO amendableModule = ModuleDTO.builder()
            .moduleId(AMENDABLE_MODULE_ID)
            .sectorId(SECTOR_ID_2)
            .moduleCode(AMENDABLE_MODULE_CODE)
            .workflowCode(WORKFLOW_CODE)
            .flAmendModule(true)
            .build();

    private final ModuleDTO oldModule = ModuleDTO.builder()
            .moduleId(OLD_MODULE_ID)
            .sectorId(SECTOR_ID_2)
            .moduleCode(OLD_AMENDABLE_MODULE_CODE)
            .workflowCode(WORKFLOW_CODE)
            .flAmendModule(true)
            .build();

    private final AmendableModuleDTO oldAmendableModule = AmendableModuleDTO.builder()
            .pkid(PKID)
            .amendableModuleId(AMENDABLE_MODULE_ID)
            .moduleId(MODULE_ID)
            .userIdInsert(USER)
            .build();

    private final ConfigDataMessage configDataMessage = new ConfigDataMessage();

    @InjectMocks
    private AmendableModulesBundleWorker amendableModulesBundleWorker;
    @Mock
    private AmendableModuleCrudService amendableModuleCrudService;
    @Mock
    private ModuleCrudService moduleCrudService;
    @Mock
    private SectorsCrudService sectorsCrudService;

    @BeforeEach
    void init() {
        configDataMessage.setTenantId(TEMPLATE_TENANT_ID);
        amendableModulesBundleWorker = new AmendableModulesBundleWorker(amendableModuleCrudService, moduleCrudService,
                sectorsCrudService);
    }

    @Test
    void upsertBundleModules_insert_ok() {
        when(moduleCrudService.findByCode(TEMPLATE_TENANT_ID, MODULE_CODE))
                .thenReturn(Optional.ofNullable(module));
        when(moduleCrudService.findByCode(TEMPLATE_TENANT_ID, AMENDABLE_MODULE_CODE))
                .thenReturn(Optional.ofNullable(amendableModule));

        BundleAmendableModuleInDTO bundleAmendableModuleInDTO = BundleAmendableModuleInDTO.builder()
                .moduleCode(MODULE_CODE)
                .amendableModuleCode(AMENDABLE_MODULE_CODE)
                .build();

        BundleAmendableModulesMessage message = BundleAmendableModulesMessage.builder()
                .amendableModules(List.of(bundleAmendableModuleInDTO))
                .build();

        amendableModulesBundleWorker.upsertBundleModules(TEMPLATE_TENANT_ID, message);

        AmendableModuleDTO in = AmendableModuleDTO.builder()
                .moduleId(MODULE_ID)
                .amendableModuleId(AMENDABLE_MODULE_ID)
                .build();

        verify(amendableModuleCrudService).insert(in, BundleConstants.BUNDLE_SYSTEM_USERNAME);
    }

    @Test
    void upsertBundleModules_update_ok() {
        when(moduleCrudService.findByCode(TEMPLATE_TENANT_ID, MODULE_CODE))
                .thenReturn(Optional.ofNullable(module));
        when(moduleCrudService.findByCode(TEMPLATE_TENANT_ID, OLD_AMENDABLE_MODULE_CODE))
                .thenReturn(Optional.ofNullable(oldModule));
        when(amendableModuleCrudService.findOptByModuleIdAndAmendableModuleId(MODULE_ID, OLD_MODULE_ID))
                .thenReturn(Optional.ofNullable(oldAmendableModule));
        when(moduleCrudService.findByCode(TEMPLATE_TENANT_ID, AMENDABLE_MODULE_CODE))
                .thenReturn(Optional.ofNullable(amendableModule));

        BundleAmendableModuleInDTO bundleAmendableModuleInDTO = BundleAmendableModuleInDTO.builder()
                .moduleCode(MODULE_CODE)
                .amendableModuleCode(AMENDABLE_MODULE_CODE)
                .oldAmendableModuleCode(OLD_AMENDABLE_MODULE_CODE)
                .build();

        BundleAmendableModulesMessage message = BundleAmendableModulesMessage.builder()
                .amendableModules(List.of(bundleAmendableModuleInDTO))
                .build();

        amendableModulesBundleWorker.upsertBundleModules(TEMPLATE_TENANT_ID, message);

        AmendableModuleDTO in = AmendableModuleDTO.builder()
                .moduleId(MODULE_ID)
                .amendableModuleId(AMENDABLE_MODULE_ID)
                .build();

        verify(amendableModuleCrudService).update(PKID, in, BundleConstants.BUNDLE_SYSTEM_USERNAME);
    }

    @Test
    void upsertBundleModules_ko() {
        when(moduleCrudService.findByCode(TEMPLATE_TENANT_ID, MODULE_CODE))
                .thenReturn(Optional.empty());

        BundleAmendableModuleInDTO bundleAmendableModuleInDTO = BundleAmendableModuleInDTO.builder()
                .moduleCode(MODULE_CODE)
                .amendableModuleCode(AMENDABLE_MODULE_CODE)
                .oldAmendableModuleCode(OLD_AMENDABLE_MODULE_CODE)
                .build();

        BundleAmendableModulesMessage message = BundleAmendableModulesMessage.builder()
                .amendableModules(List.of(bundleAmendableModuleInDTO))
                .build();

        assertThrows(ObjectNotFoundRuntimeException.class,
                () -> amendableModulesBundleWorker.upsertBundleModules(TEMPLATE_TENANT_ID, message));
    }

    @Test
    void deleteBundleAmendableModules_ok() {
        when(moduleCrudService.findByCode(TEMPLATE_TENANT_ID, MODULE_CODE))
                .thenReturn(Optional.ofNullable(module));
        when(moduleCrudService.findByCode(TEMPLATE_TENANT_ID, AMENDABLE_MODULE_CODE))
                .thenReturn(Optional.ofNullable(amendableModule));
        when(amendableModuleCrudService.findOptByModuleIdAndAmendableModuleId(MODULE_ID, AMENDABLE_MODULE_ID))
                .thenReturn(Optional.ofNullable(oldAmendableModule));

        BundleAmendableModuleInDTO bundleAmendableModuleInDTO = BundleAmendableModuleInDTO.builder()
                .moduleCode(MODULE_CODE)
                .amendableModuleCode(AMENDABLE_MODULE_CODE)
                .build();

        BundleAmendableModulesMessage message = BundleAmendableModulesMessage.builder()
                .amendableModules(List.of(bundleAmendableModuleInDTO))
                .build();
        amendableModulesBundleWorker.deleteBundleAmendableModules(TEMPLATE_TENANT_ID, message);

        verify(amendableModuleCrudService).delete(PKID, BundleConstants.BUNDLE_SYSTEM_USERNAME);
    }

    @Test
    void deleteBundleAmendableModules_ko() {
        when(moduleCrudService.findByCode(TEMPLATE_TENANT_ID, MODULE_CODE))
                .thenReturn(Optional.ofNullable(module));
        when(moduleCrudService.findByCode(TEMPLATE_TENANT_ID, AMENDABLE_MODULE_CODE))
                .thenReturn(Optional.ofNullable(amendableModule));
        when(amendableModuleCrudService.findOptByModuleIdAndAmendableModuleId(MODULE_ID, AMENDABLE_MODULE_ID))
                .thenReturn(Optional.empty());

        BundleAmendableModuleInDTO bundleAmendableModuleInDTO = BundleAmendableModuleInDTO.builder()
                .moduleCode(MODULE_CODE)
                .amendableModuleCode(AMENDABLE_MODULE_CODE)
                .build();

        BundleAmendableModulesMessage message = BundleAmendableModulesMessage.builder()
                .amendableModules(List.of(bundleAmendableModuleInDTO))
                .build();

        assertThrows(ObjectNotFoundRuntimeException.class,
                () -> amendableModulesBundleWorker.deleteBundleAmendableModules(TEMPLATE_TENANT_ID, message));

    }

    @Test
    void test_exposeModulesService() {
        assertEquals(moduleCrudService, amendableModulesBundleWorker.exposeModuleCrudService());
    }

    @Test
    void test_exposeAmendableModuleDetailsCrudService() {
        assertEquals(amendableModuleCrudService, amendableModulesBundleWorker.exposeAmendableModuleCrudService());
    }

}
