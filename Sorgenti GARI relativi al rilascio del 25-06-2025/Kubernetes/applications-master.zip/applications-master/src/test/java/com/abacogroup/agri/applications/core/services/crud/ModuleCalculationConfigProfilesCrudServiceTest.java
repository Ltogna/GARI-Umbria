package com.abacogroup.agri.applications.core.services.crud;

import com.abacogroup.agri.applications.core.exceptions.ObjectNotFoundException;
import com.abacogroup.agri.applications.core.mappers.ModuleCalculationConfigProfileMapper;
import com.abacogroup.agri.applications.core.model.dto.ModuleCalculationConfigProfileDTO;
import com.abacogroup.agri.applications.db.dao.ModuleCalculationConfigProfileDAO;
import com.abacogroup.agri.applications.db.ntt.ModuleCalculationConfigProfileNTT;
import com.abacogroup.agri.applications.db.ntt.compoundkeys.CalculationConfigProfileKey;
import org.jdbi.v3.sqlobject.transaction.TransactionalCallback;
import org.jdbi.v3.sqlobject.transaction.TransactionalConsumer;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class ModuleCalculationConfigProfilesCrudServiceTest {
    @Mock
    private ModuleCalculationConfigProfileDAO moduleCalculationConfigProfileDAOMock;
    @Mock
    private ModuleCalculationConfigProfileMapper moduleCalculationConfigProfileMapperMock;

    @InjectMocks
    private ModuleCalculationConfigProfilesCrudService moduleCalculationConfigProfilesCrudService;

    private static final String TENANT = "ADMIN";
    private static final Long MODULE_CALCULATION_CONFIG_ID = 10L;
    private static final String REQUIRED_PROFILE_CODE = "required profile code";

    private final ModuleCalculationConfigProfileNTT moduleCalculationConfigProfileNTT = ModuleCalculationConfigProfileNTT.builder()
            .module_calculation_config_id(MODULE_CALCULATION_CONFIG_ID)
            .required_profile_code(REQUIRED_PROFILE_CODE)
            .build();
    private final ModuleCalculationConfigProfileDTO moduleCalculationConfigProfileDTO = ModuleCalculationConfigProfileDTO.builder()
            .moduleCalculationConfigId(MODULE_CALCULATION_CONFIG_ID)
            .requiredProfileCode(REQUIRED_PROFILE_CODE)
            .build();
    private final CalculationConfigProfileKey calculationConfigProfileKey = CalculationConfigProfileKey.builder()
            .module_calculation_config_id(MODULE_CALCULATION_CONFIG_ID)
            .required_profile_code(REQUIRED_PROFILE_CODE)
            .build();

    @SuppressWarnings({"rawtypes", "unchecked"})
    @Test
    void insert_ok() {
        ModuleCalculationConfigProfileDTO payload = ModuleCalculationConfigProfileDTO.builder()
                .moduleCalculationConfigId(MODULE_CALCULATION_CONFIG_ID)
                .requiredProfileCode(REQUIRED_PROFILE_CODE)
                .build();

        try {
            ArgumentCaptor<TransactionalCallback> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(TransactionalCallback.class);

            when(moduleCalculationConfigProfileMapperMock.dtoToEntity(payload))
                    .thenReturn(moduleCalculationConfigProfileNTT);
            when(moduleCalculationConfigProfileMapperMock.entityToDto(moduleCalculationConfigProfileNTT))
                    .thenReturn(moduleCalculationConfigProfileDTO);
            when(moduleCalculationConfigProfileDAOMock.findById(calculationConfigProfileKey))
                    .thenReturn(List.of(moduleCalculationConfigProfileNTT));

            moduleCalculationConfigProfilesCrudService.insert(payload);

            verify(moduleCalculationConfigProfileDAOMock).inTransaction(handleConsumerLambdaCaptor.capture());

            ModuleCalculationConfigProfileDTO result = (ModuleCalculationConfigProfileDTO) handleConsumerLambdaCaptor.getValue().inTransaction(moduleCalculationConfigProfileDAOMock);

            assertEquals(moduleCalculationConfigProfileDTO, result);

        } catch (Exception e) {
            fail(e);
        }

    }

    @SuppressWarnings({"rawtypes", "unchecked"})
    @Test
    void update_ok() {
        ModuleCalculationConfigProfileDTO payload = ModuleCalculationConfigProfileDTO.builder()
                .moduleCalculationConfigId(MODULE_CALCULATION_CONFIG_ID)
                .requiredProfileCode(REQUIRED_PROFILE_CODE)
                .build();

        try {
            ArgumentCaptor<TransactionalCallback> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(TransactionalCallback.class);

            when(moduleCalculationConfigProfileDAOMock.inTransaction(handleConsumerLambdaCaptor.capture()))
                    .thenReturn(moduleCalculationConfigProfileDTO);
            when(moduleCalculationConfigProfileMapperMock.dtoToEntity(payload))
                    .thenReturn(moduleCalculationConfigProfileNTT);
            when(moduleCalculationConfigProfileDAOMock.findById(calculationConfigProfileKey))
                    .thenReturn(List.of(moduleCalculationConfigProfileNTT));
            when(moduleCalculationConfigProfileMapperMock.entityToDto(moduleCalculationConfigProfileNTT))
                    .thenReturn(moduleCalculationConfigProfileDTO);

            moduleCalculationConfigProfilesCrudService.update(payload);

            verify(moduleCalculationConfigProfileDAOMock).inTransaction(handleConsumerLambdaCaptor.capture());
            ModuleCalculationConfigProfileDTO result = (ModuleCalculationConfigProfileDTO) handleConsumerLambdaCaptor.getValue().inTransaction(moduleCalculationConfigProfileDAOMock);

            assertEquals(moduleCalculationConfigProfileDTO, result);
        } catch (Exception e) {
            fail(e);
        }
    }

    @SuppressWarnings({"rawtypes", "unchecked"})
    @Test
    void delete_ok() {
        try {
            ArgumentCaptor<TransactionalConsumer> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(TransactionalConsumer.class);

            moduleCalculationConfigProfilesCrudService.delete(calculationConfigProfileKey);

            verify(moduleCalculationConfigProfileDAOMock).useTransaction(handleConsumerLambdaCaptor.capture());
            handleConsumerLambdaCaptor.getValue().useTransaction(moduleCalculationConfigProfileDAOMock);

            verify(moduleCalculationConfigProfileDAOMock, times(1)).deleteById(calculationConfigProfileKey);
        } catch (Exception e) {
            fail(e);
        }
    }

    @Test
    void deleteByModuleCalculationConfigId_ok() {
        moduleCalculationConfigProfilesCrudService.deleteByModuleCalculationConfigId(MODULE_CALCULATION_CONFIG_ID);

        verify(moduleCalculationConfigProfileDAOMock, times(1)).deleteByModuleCalculationConfigId(MODULE_CALCULATION_CONFIG_ID);
    }

    @Test
    void findById_ok() {
        try {
            when(moduleCalculationConfigProfileDAOMock.findById(TENANT, calculationConfigProfileKey))
                    .thenReturn(List.of(moduleCalculationConfigProfileNTT));
            when(moduleCalculationConfigProfileMapperMock.entityToDto(moduleCalculationConfigProfileNTT))
                    .thenReturn(moduleCalculationConfigProfileDTO);

            ModuleCalculationConfigProfileDTO result = moduleCalculationConfigProfilesCrudService.findById(TENANT, calculationConfigProfileKey);

            assertEquals(moduleCalculationConfigProfileDTO, result);
        } catch (Exception e) {
            fail(e);
        }
    }

    @Test
    void find_ok() {
        when(moduleCalculationConfigProfileDAOMock.find(TENANT, MODULE_CALCULATION_CONFIG_ID))
                .thenReturn(List.of(moduleCalculationConfigProfileNTT));
        when(moduleCalculationConfigProfileMapperMock.entityToDto(moduleCalculationConfigProfileNTT))
                .thenReturn(moduleCalculationConfigProfileDTO);

        List<ModuleCalculationConfigProfileDTO> result = moduleCalculationConfigProfilesCrudService.find(TENANT, MODULE_CALCULATION_CONFIG_ID);

        assertEquals(List.of(moduleCalculationConfigProfileDTO), result);
    }

    @Test
    void findById_ko() {
        try {
            when(moduleCalculationConfigProfileDAOMock.findById(TENANT, calculationConfigProfileKey))
                    .thenReturn(List.of());

            assertThrows(ObjectNotFoundException.class, () ->
                    moduleCalculationConfigProfilesCrudService.findById(TENANT, calculationConfigProfileKey));
        } catch (Exception e) {
            fail(e);
        }
    }
}
