package com.abacogroup.agri.applications.core.caller;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.assertEquals;

@ExtendWith(MockitoExtension.class)
class GetUserByTenantTest {

    private static final String USERNAME = "USERNAME";
    private static final String URL = "URL";
    private static final String TENANT = "TENANT";
    private static final String TOKEN = "TOKEN";

    @Test
    void of_ok() {
        GetUserByTenant expectedOutput = GetUserByTenant.builder()
                .url(URL)
                .tenant(TENANT)
                .token(TOKEN)
                .username(USERNAME)
                .build();

        GetUserByTenant result = GetUserByTenant.of(TENANT, USERNAME, URL, TOKEN);

        assertEquals(expectedOutput, result);
    }
}
