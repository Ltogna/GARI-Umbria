package com.abacogroup.agri.applications.bundles.processor.module;

import com.abacogroup.agri.applications.core.exceptions.ObjectNotFoundException;
import com.abacogroup.agri.applications.core.exceptions.ObjectNotFoundRuntimeException;
import com.abacogroup.agri.applications.core.model.AbsoluteDate;
import com.abacogroup.agri.applications.core.model.dto.*;
import com.abacogroup.agri.applications.core.services.crud.*;
import com.abacogroup.agri.applications.db.ntt.applications.RsI18N;
import com.abacogroup.applicationworkflowsdk.model.io.output.ModuleProfileDTO;
import com.abacogroup.bundles.listener.configdata.ConfigDataMessage;
import com.abacogroup.bundles.listener.tenant.TenantMessage;
import lombok.extern.slf4j.Slf4j;
import org.jdbi.v3.core.Handle;
import org.jdbi.v3.core.HandleConsumer;
import org.jdbi.v3.core.Jdbi;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.fail;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@Slf4j
@ExtendWith(MockitoExtension.class)
class ModulesNewTenantProcessorTest {

	private static final String TEMPLATE_TENANT_ID = "*";
	private static final Long MODULE_ID = 1L;
	private static final String MODULE_CODE = "module_code";
	private static final Long SECTOR_ID = 1L;
	private static final String SECTOR_CODE = "sector_code";
	private static final Long FORM_ID = 1L;
	private static final String FORM_CODE = "form_code";
	private static final Long FORM_GROUP_ID = 1L;
	private static final String FORM_GROUP_CODE = "form_group_code";
	private static final String FORM_GROUP_CODE_2 = "form_group_code_2";
	private static final String SOFTWARE_URL = "software-url";
	private static final String COMPILE_STATUS_IDENTIFIER = "CODE_1";

	private static final Long FORM_MODULE_CONFIG_ID = 1L;
	private static final String REQUIRED_PROFILE_CODE = "DEFAULT_PROFILE";
	private static final Integer ANNUALITY = 2022;
	private static final String WORKFLOW_CODE = "workflow_code";
	private static final Integer FL_READ_ONLY = 0;
	private static final Integer SORT_ORDER = 1;
	private static final String PROCESS_STATUS = "TODO";
	private static final String PARAM_KEY = "name";
	private static final String PARAM_VALUE = "John";

	private final ModuleWithDetailDTO modulesOutDTOMock = ModuleWithDetailDTO.builder()
			.moduleId(MODULE_ID)
			.sectorId(SECTOR_ID)
			.moduleCode(MODULE_CODE)
			.annuality(ANNUALITY)
			.dtValidityStart(new AbsoluteDate("20220101"))
			.dtValidityEnd(new AbsoluteDate("20230101"))
			.workflowCode(WORKFLOW_CODE)
			.build();
	private final ConfigDataMessage configDataMessage = new ConfigDataMessage();
	private final RsI18N rsI18NMock = RsI18N.builder()
			.tenant_id(TEMPLATE_TENANT_ID)
			.i18n_text("text")
			.i18n_value("value")
			.field_name("description")
			.table_name("table_name")
			.lang("lang")
			.build();

	private final SectorDTO sectorDTOMock = SectorDTO.builder()
			.tenantId(TEMPLATE_TENANT_ID)
			.sectorId(SECTOR_ID)
			.sectorCode(SECTOR_CODE)
			.build();

	private final FormCatalogDTO formCatalogDTOMock = FormCatalogDTO.builder()
			.tenantId(TEMPLATE_TENANT_ID)
			.formCode(FORM_CODE)
			.softwareUrl(SOFTWARE_URL)
			.build();

	private final FormGroupDTO formGroupDTOMock = FormGroupDTO.builder()
			.id(FORM_GROUP_ID)
			.tenantId(TEMPLATE_TENANT_ID)
			.formGroupCode(FORM_GROUP_CODE)
			.build();

	private final FormGroupDTO formGroupDTOMock_2 = FormGroupDTO.builder()
			.tenantId(TEMPLATE_TENANT_ID)
			.formGroupCode(FORM_GROUP_CODE_2)
			.parentFormGroupId(FORM_GROUP_ID)
			.build();

	private final ModuleFormConfigsDTO moduleFormConfigsDTOMock = ModuleFormConfigsDTO.builder()
			.id(FORM_MODULE_CONFIG_ID)
			.moduleId(MODULE_ID)
			.formId(FORM_ID)
			.formGroupId(FORM_GROUP_ID)
			.compileStatusIdentifier(COMPILE_STATUS_IDENTIFIER)
			.flReadOnly(FL_READ_ONLY)
			.sortOrder(SORT_ORDER)
			.processStatus(PROCESS_STATUS)
			.build();

	private final ModuleFormConfigProfileDTO moduleFormConfigProfileDTOMock = ModuleFormConfigProfileDTO.builder()
			.moduleFormConfigId(FORM_MODULE_CONFIG_ID)
			.requiredProfileCode(REQUIRED_PROFILE_CODE)
			.build();

	private final ModuleFormConfigParamDTO moduleFormConfigParamDTOMock = ModuleFormConfigParamDTO.builder()
			.moduleFormConfigId(FORM_MODULE_CONFIG_ID)
			.parameterName(PARAM_KEY)
			.parameterValue(PARAM_VALUE)
			.build();

	private final ModuleProfileDTO moduleProfileDTOOutMock = ModuleProfileDTO.builder()
			.pkid(1L)
			.moduleId(MODULE_ID)
			.profileCode(REQUIRED_PROFILE_CODE)
			.build();

	@Mock
	private ModulesBundleWorker modulesBundleWorker;
	@Mock
	private ModuleCrudService modulesCrudService;
	@Mock
	private SectorsCrudService sectorsCrudService;
	@Mock
	private FormCatalogsCrudService formCatalogsCrudService;
	@Mock
	private FormGroupsCrudService formGroupsCrudService;
	@Mock
	private ModuleFormConfigsCrudService moduleFormConfigsCrudService;
	@Mock
	private ModuleFormConfigParamCrudService moduleFormConfigParamCrudService;
	@Mock
	private ModuleFormConfigProfilesCrudService moduleFormConfigProfilesCrudService;
	@Mock
	private ModuleProfilesCrudService moduleProfilesCrudService;
	@Mock
	private ModulePrintConfigsCrudService modulePrintConfigsCrudService;
	@Mock
	private ModuleCalculationConfigsCrudService moduleCalculationConfigsCrudService;

	@Mock
	private Jdbi jdbi;
	@Mock
	private Handle handle;
	@InjectMocks
	private ModuleNewTenantProcessor modulesNewTenantProcessor;

	@BeforeEach
	void init() {
		configDataMessage.setTenantId(TEMPLATE_TENANT_ID);
		modulesNewTenantProcessor = new ModuleNewTenantProcessor(jdbi, modulesBundleWorker);
	}

	@SuppressWarnings({"rawtypes", "unchecked"})
	@Test
	void test_onMessage() {
		try {
			ArgumentCaptor<HandleConsumer> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(HandleConsumer.class);

			TenantMessage message = new TenantMessage();
			message.setTenantId(TEMPLATE_TENANT_ID);

			when(modulesBundleWorker.exposeSectorsCrudService()).thenReturn(sectorsCrudService);
			when(modulesBundleWorker.exposeModuleCrudService()).thenReturn(modulesCrudService);
			when(modulesBundleWorker.exposeFormCatalogsCrudService()).thenReturn(formCatalogsCrudService);
			when(modulesBundleWorker.exposeFormGroupsCrudService()).thenReturn(formGroupsCrudService);
			when(modulesBundleWorker.exposeModuleFormConfigsCrudService()).thenReturn(moduleFormConfigsCrudService);
			when(modulesBundleWorker.exposeModuleFormConfigParamCrudService()).thenReturn(moduleFormConfigParamCrudService);
			when(modulesBundleWorker.exposeModuleFormConfigProfilesCrudService()).thenReturn(moduleFormConfigProfilesCrudService);
			when(modulesBundleWorker.exposeModuleProfilesCrudService()).thenReturn(moduleProfilesCrudService);
			when(modulesBundleWorker.exposeModulePrintConfigsCrudService()).thenReturn(modulePrintConfigsCrudService);
			when(modulesBundleWorker.exposeModuleCalculationConfigsCrudService()).thenReturn(moduleCalculationConfigsCrudService);
			when(sectorsCrudService.findById(TEMPLATE_TENANT_ID, SECTOR_ID)).thenReturn(sectorDTOMock);

			when(formCatalogsCrudService.findAllFormCatalogs(eq(TEMPLATE_TENANT_ID), any())).thenReturn(List.of(formCatalogDTOMock));
			when(formCatalogsCrudService.findById(TEMPLATE_TENANT_ID, FORM_ID)).thenReturn(formCatalogDTOMock);
			when(formCatalogsCrudService.getAllFormCatalogI18NByTenantAndCode(TEMPLATE_TENANT_ID, FORM_CODE)).thenReturn(List.of(rsI18NMock));
			when(formGroupsCrudService.findAllFormGroupsWithNoParent(eq(TEMPLATE_TENANT_ID), any())).thenReturn(List.of(formGroupDTOMock));
			when(formGroupsCrudService.findById(TEMPLATE_TENANT_ID, FORM_GROUP_ID)).thenReturn(formGroupDTOMock);
			when(formGroupsCrudService.getAllFormGroupI18NByTenantAndCode(TEMPLATE_TENANT_ID, FORM_GROUP_CODE)).thenReturn(List.of(rsI18NMock));
			when(formGroupsCrudService.getAllFormGroupI18NByTenantAndCode(TEMPLATE_TENANT_ID, FORM_GROUP_CODE_2)).thenReturn(List.of(rsI18NMock));
			when(formGroupsCrudService.findFormGroupsByParentId(TEMPLATE_TENANT_ID, FORM_GROUP_ID)).thenReturn(List.of(formGroupDTOMock_2));
			when(formGroupsCrudService.findFormGroupByCode(TEMPLATE_TENANT_ID, FORM_GROUP_CODE_2)).thenReturn(formGroupDTOMock_2);
			when(modulesCrudService.findModulesWithDetail(TEMPLATE_TENANT_ID)).thenReturn(List.of(modulesOutDTOMock));
			when(modulesCrudService.getAllModuleI18NByTenantAndCode(TEMPLATE_TENANT_ID, MODULE_CODE)).thenReturn(List.of(rsI18NMock));
			when(moduleFormConfigsCrudService.findAllModuleFormConfigs(TEMPLATE_TENANT_ID, modulesOutDTOMock.getModuleId()))
					.thenReturn(List.of(moduleFormConfigsDTOMock));
			when(moduleFormConfigProfilesCrudService.find(TEMPLATE_TENANT_ID, FORM_MODULE_CONFIG_ID)).thenReturn(List.of(moduleFormConfigProfileDTOMock));
			when(moduleProfilesCrudService.find(TEMPLATE_TENANT_ID, MODULE_ID)).thenReturn(List.of(moduleProfileDTOOutMock));
			when(moduleProfilesCrudService.getAllModuleProfileI18NByTenantAndCode(TEMPLATE_TENANT_ID, REQUIRED_PROFILE_CODE)).thenReturn(List.of(rsI18NMock));
			when(moduleFormConfigParamCrudService.find(TEMPLATE_TENANT_ID, FORM_MODULE_CONFIG_ID)).thenReturn(List.of(moduleFormConfigParamDTOMock));

			modulesNewTenantProcessor.onMessage(message);

			verify(jdbi).useTransaction(handleConsumerLambdaCaptor.capture());

			handleConsumerLambdaCaptor.getValue().useHandle(handle);

			//			verify(modulesBundleWorker).insertBundleModules(TEMPLATE_TENANT_ID, bundleModulesMessageMock);
		} catch (Exception e) {
			fail(e.getMessage(), e);
		}
	}

	@SuppressWarnings({"rawtypes", "unchecked"})
	@Test
	void test_onMessage_ko_findFormGroupByCode_notFound() {
		try {
			ArgumentCaptor<HandleConsumer> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(HandleConsumer.class);

			TenantMessage message = new TenantMessage();
			message.setTenantId(TEMPLATE_TENANT_ID);

			when(modulesBundleWorker.exposeSectorsCrudService()).thenReturn(sectorsCrudService);
			when(modulesBundleWorker.exposeModuleCrudService()).thenReturn(modulesCrudService);
			when(modulesBundleWorker.exposeFormCatalogsCrudService()).thenReturn(formCatalogsCrudService);
			when(modulesBundleWorker.exposeFormGroupsCrudService()).thenReturn(formGroupsCrudService);
			when(modulesBundleWorker.exposeModuleFormConfigsCrudService()).thenReturn(moduleFormConfigsCrudService);
			when(modulesBundleWorker.exposeModulePrintConfigsCrudService()).thenReturn(modulePrintConfigsCrudService);
			when(modulesBundleWorker.exposeModuleCalculationConfigsCrudService()).thenReturn(moduleCalculationConfigsCrudService);
			when(sectorsCrudService.findById(TEMPLATE_TENANT_ID, SECTOR_ID)).thenReturn(sectorDTOMock);

			when(formCatalogsCrudService.findAllFormCatalogs(eq(TEMPLATE_TENANT_ID), any())).thenReturn(List.of(formCatalogDTOMock));
			when(formCatalogsCrudService.getAllFormCatalogI18NByTenantAndCode(TEMPLATE_TENANT_ID, FORM_CODE)).thenReturn(List.of(rsI18NMock));
			when(formGroupsCrudService.findAllFormGroupsWithNoParent(eq(TEMPLATE_TENANT_ID), any())).thenReturn(List.of(formGroupDTOMock));
			when(formGroupsCrudService.getAllFormGroupI18NByTenantAndCode(TEMPLATE_TENANT_ID, FORM_GROUP_CODE_2)).thenReturn(List.of(rsI18NMock));
			when(formGroupsCrudService.findFormGroupsByParentId(TEMPLATE_TENANT_ID, FORM_GROUP_ID)).thenReturn(List.of(formGroupDTOMock_2));
			when(formGroupsCrudService.findFormGroupByCode(TEMPLATE_TENANT_ID, FORM_GROUP_CODE_2)).thenThrow(new ObjectNotFoundException("err"));
			when(modulesCrudService.findModulesWithDetail(TEMPLATE_TENANT_ID)).thenReturn(List.of(modulesOutDTOMock));
			when(modulesCrudService.getAllModuleI18NByTenantAndCode(TEMPLATE_TENANT_ID, MODULE_CODE)).thenReturn(List.of(rsI18NMock));
			when(moduleFormConfigsCrudService.findAllModuleFormConfigs(TEMPLATE_TENANT_ID, modulesOutDTOMock.getModuleId()))
					.thenReturn(List.of(moduleFormConfigsDTOMock));

			modulesNewTenantProcessor.onMessage(message);

			verify(jdbi).useTransaction(handleConsumerLambdaCaptor.capture());

			HandleConsumer handleConsumer = handleConsumerLambdaCaptor.getValue();
			assertThrows(ObjectNotFoundRuntimeException.class, () -> handleConsumer.useHandle(handle));

		} catch (Exception e) {
			fail(e.getMessage(), e);
		}
	}
}
