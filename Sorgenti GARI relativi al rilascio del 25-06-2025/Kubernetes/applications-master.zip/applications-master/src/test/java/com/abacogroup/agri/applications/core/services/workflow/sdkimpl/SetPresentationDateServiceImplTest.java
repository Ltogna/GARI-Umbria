package com.abacogroup.agri.applications.core.services.workflow.sdkimpl;

import com.abacogroup.agri.applications.core.exceptions.ApplicationNotFoundRuntimeException;
import com.abacogroup.agri.applications.core.exceptions.ObjectNotFoundException;
import com.abacogroup.agri.applications.core.model.dto.ApplicationDetailsDTO;
import com.abacogroup.agri.applications.core.services.crud.ApplicationDetailsCrudService;
import com.abacogroup.dropwizard.auth.sso2.User;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.fail;
import static org.mockito.Mockito.*;

@Slf4j
@ExtendWith(MockitoExtension.class)
class SetPresentationDateServiceImplTest {

	private static final Long PK_ID_1 = 1L;
	private static final Long APPLICATION_ID_1 = 30L;
	private static final String PROCESS_STATUS_1 = "status_1";
	private static final String TENANT_1 = "tenant_1";
	private static final String USER_1 = "user_1";
	private static final User logged_user1 = new User(USER_1, TENANT_1);

	@Mock
	private ApplicationDetailsCrudService applicationDetailsCrudService;

	@InjectMocks
	private SetPresentationDateServiceImpl setPresentationDateService;

	@Test
	void test_conditionallySetPresentationDate_ok() {
		try {
			ApplicationDetailsDTO applicationDetailsDTO = ApplicationDetailsDTO.builder()
					.pkid(PK_ID_1)
					.applicationId(APPLICATION_ID_1)
					.processStatus(PROCESS_STATUS_1)
					.flInTransition(1)
					.build();

			when(applicationDetailsCrudService.findApplicationDetailById(TENANT_1, APPLICATION_ID_1))
					.thenReturn(applicationDetailsDTO);

			setPresentationDateService.conditionallySetPresentationDate(TENANT_1, APPLICATION_ID_1, logged_user1.getUserId());

			verify(applicationDetailsCrudService, times(1)).update(PK_ID_1, applicationDetailsDTO, logged_user1.getUserId());
		} catch (Exception e) {
			fail(e);
		}
	}

	@Test
	void test_conditionallySetPresentationDate_ko() {
		try {
			when(applicationDetailsCrudService.findApplicationDetailById(TENANT_1, APPLICATION_ID_1))
					.thenThrow(ObjectNotFoundException.class);

			assertThrows(ApplicationNotFoundRuntimeException.class,
					() -> setPresentationDateService.conditionallySetPresentationDate(TENANT_1, APPLICATION_ID_1, logged_user1.getUserId()));
		} catch (Exception e) {
			fail(e);
		}
	}
}
