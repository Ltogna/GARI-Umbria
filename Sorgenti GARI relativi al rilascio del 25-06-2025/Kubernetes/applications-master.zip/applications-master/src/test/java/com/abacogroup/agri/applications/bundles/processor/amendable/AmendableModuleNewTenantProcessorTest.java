package com.abacogroup.agri.applications.bundles.processor.amendable;

import com.abacogroup.agri.applications.bundles.model.amendable.BundleAmendableModuleInDTO;
import com.abacogroup.agri.applications.bundles.model.amendable.BundleAmendableModulesMessage;
import com.abacogroup.agri.applications.core.model.dto.AmendableModuleDTO;
import com.abacogroup.agri.applications.core.model.dto.ModuleDTO;
import com.abacogroup.agri.applications.core.model.dto.SectorDTO;
import com.abacogroup.agri.applications.core.services.crud.AmendableModuleCrudService;
import com.abacogroup.agri.applications.core.services.crud.ModuleCrudService;
import com.abacogroup.agri.applications.core.services.crud.SectorsCrudService;
import com.abacogroup.agri.applications.db.ntt.applications.RsI18N;
import com.abacogroup.bundles.listener.tenant.TenantMessage;
import lombok.extern.slf4j.Slf4j;
import org.jdbi.v3.core.Handle;
import org.jdbi.v3.core.HandleConsumer;
import org.jdbi.v3.core.Jdbi;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.fail;
import static org.mockito.Mockito.*;

@Slf4j
@ExtendWith(MockitoExtension.class)
public class AmendableModuleNewTenantProcessorTest {

    private static final String TEMPLATE_TENANT_ID = "*";

    private static final String ANOMALY_CODE = "anomaly_code";
    private static final Long MODULE_ID = 1L;
    private static final Long AMENDABLE_MODULE_ID = 2L;

    private static final String MODULE_CODE = "module_code";

    private static final String SEVERITY = "severity";
    private static final Long SECTOR_ID = 1L;
    private static final Long SECTOR_ID_2 = 2L;
    private static final String AMENDABLE_MODULE_CODE = "AMENDABLE_MODULE_CODE";
    private static final String WORKFLOW_CODE = "workflow_code";

    private final AmendableModuleDTO amendableModuleDTO = AmendableModuleDTO.builder()
            .moduleId(MODULE_ID)
            .amendableModuleId(AMENDABLE_MODULE_ID)
            .build();

    private final ModuleDTO moduleDTOInMock = ModuleDTO.builder()
            .moduleId(MODULE_ID)
            .sectorId(SECTOR_ID)
            .moduleCode(MODULE_CODE)
            .workflowCode(WORKFLOW_CODE)
            .flAmendModule(false)
            .build();

    private final ModuleDTO amendableModuleDTOInMock = ModuleDTO.builder()
            .moduleId(AMENDABLE_MODULE_ID)
            .sectorId(SECTOR_ID_2)
            .moduleCode(AMENDABLE_MODULE_CODE)
            .workflowCode(WORKFLOW_CODE)
            .flAmendModule(true)
            .build();

    private final RsI18N rsI18NMock = RsI18N.builder()
            .field_name("lang")
            .lang("lang")
            .i18n_text("lang")
            .tenant_id(TEMPLATE_TENANT_ID)
            .i18n_value("lang")
            .table_name("lang")
            .build();

    @Mock
    private Jdbi jdbi;

    @Mock
    private Handle handle;

    @Mock
    private AmendableModuleCrudService amendableModuleCrudService;
    @Mock
    private ModuleCrudService moduleCrudService;
    @Mock
    private SectorsCrudService sectorsCrudService;
    @Mock
    private AmendableModulesBundleWorker amendableModulesBundleWorker;

    @InjectMocks
    private AmendableModuleNewTenantProcessor amendableModuleNewTenantProcessor;

    @BeforeEach
    void init() {
        amendableModuleNewTenantProcessor = new AmendableModuleNewTenantProcessor(jdbi, amendableModulesBundleWorker);
    }

    @SuppressWarnings({"rawtypes", "unchecked"})
    @Test
    void test_onMessage() {
        try {
            ArgumentCaptor<HandleConsumer> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(HandleConsumer.class);

            TenantMessage message = new TenantMessage();
            message.setTenantId(TEMPLATE_TENANT_ID);

            when(amendableModulesBundleWorker.exposeAmendableModuleCrudService()).thenReturn(amendableModuleCrudService);
            when(amendableModulesBundleWorker.exposeModuleCrudService()).thenReturn(moduleCrudService);
            when(amendableModulesBundleWorker.exposeSectorCrudService()).thenReturn(sectorsCrudService);
            when(sectorsCrudService.findById(any(), any())).thenReturn(SectorDTO.builder().build());
            when(amendableModuleCrudService.findAllByTenant(TEMPLATE_TENANT_ID)).thenReturn(List.of(amendableModuleDTO));

            when(moduleCrudService.findById(AMENDABLE_MODULE_ID)).thenReturn(Optional.of(amendableModuleDTOInMock));

            when(moduleCrudService.findById(MODULE_ID)).thenReturn(Optional.of(moduleDTOInMock));

            List<BundleAmendableModuleInDTO> bundleAmendableModuleInDTOS = List.of(BundleAmendableModuleInDTO.builder()
                    .moduleCode(MODULE_CODE)
                    .amendableModuleCode(AMENDABLE_MODULE_CODE)
                    .build());

            amendableModuleNewTenantProcessor.onMessage(message);

            verify(jdbi).useTransaction(handleConsumerLambdaCaptor.capture());

            handleConsumerLambdaCaptor.getValue().useHandle(handle);
        } catch (Exception e) {
            fail(e.getMessage(), e);
        }
    }

}
