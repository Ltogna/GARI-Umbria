package com.abacogroup.agri.applications.bundles.processor.sector;

import com.abacogroup.agri.applications.core.model.dto.SectorDTO;
import com.abacogroup.agri.applications.core.services.crud.SectorsCrudService;
import com.abacogroup.agri.applications.db.ntt.applications.RsI18N;
import com.abacogroup.bundles.listener.configdata.ConfigDataMessage;
import com.abacogroup.bundles.listener.tenant.TenantMessage;
import lombok.extern.slf4j.Slf4j;
import org.jdbi.v3.core.Handle;
import org.jdbi.v3.core.HandleConsumer;
import org.jdbi.v3.core.Jdbi;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;

import static org.junit.jupiter.api.Assertions.fail;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@Slf4j
@ExtendWith(MockitoExtension.class)
class SectorsNewTenantProcessorTest {

	protected static final String TEMPLATE_TENANT_ID = "*";
	protected static final String SECTOR_CODE = "sector_code";

	private final SectorDTO sectorsOutDTOMock = SectorDTO.builder()
			.tenantId(TEMPLATE_TENANT_ID)
			.sectorId(1L)
			.sectorCode(SECTOR_CODE)
			.build();
	private final ConfigDataMessage configDataMessage = new ConfigDataMessage();
	private final RsI18N rsI18NMock = RsI18N.builder()
			.tenant_id(TEMPLATE_TENANT_ID)
			.i18n_text("text")
			.i18n_value("value")
			.field_name("field_name")
			.table_name("table_name")
			.lang("lang")
			.build();
	@Mock
	private SectorsBundleWorker sectorsBundleWorker;
	@Mock
	private SectorsCrudService sectorsCrudService;
	@Mock
	private Jdbi jdbi;
	@Mock
	private Handle handle;
	@InjectMocks
	private SectorNewTenantProcessor sectorsNewTenantProcessor;

	@BeforeEach
	void init() {
		configDataMessage.setTenantId(TEMPLATE_TENANT_ID);
		sectorsNewTenantProcessor = new SectorNewTenantProcessor(jdbi, sectorsBundleWorker);
	}

	@Test
	void test_onMessage() {
		try {
			ArgumentCaptor<HandleConsumer> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(HandleConsumer.class);

			TenantMessage message = new TenantMessage();
			message.setTenantId(TEMPLATE_TENANT_ID);
			when(sectorsBundleWorker.exposeSectorsCrudService()).thenReturn(sectorsCrudService);
			when(sectorsCrudService.findAllSectors(TEMPLATE_TENANT_ID)).thenReturn(List.of(sectorsOutDTOMock));
			when(sectorsCrudService.getAllSectorI18NByTenantAndCode(TEMPLATE_TENANT_ID, SECTOR_CODE)).thenReturn(List.of(rsI18NMock));
			sectorsNewTenantProcessor.onMessage(message);

			verify(jdbi).useTransaction(handleConsumerLambdaCaptor.capture());

			handleConsumerLambdaCaptor.getValue().useHandle(handle);

			verify(sectorsBundleWorker).upsertBundleSectors(any(), any());
		} catch (Exception e) {
			fail(e.getMessage(), e);
		}
	}

}
