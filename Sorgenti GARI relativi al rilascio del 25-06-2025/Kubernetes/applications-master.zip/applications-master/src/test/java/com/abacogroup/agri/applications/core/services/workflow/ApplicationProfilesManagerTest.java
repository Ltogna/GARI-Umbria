package com.abacogroup.agri.applications.core.services.workflow;

import com.abacogroup.agri.applications.core.model.dto.ApplicationProfileDTO;
import com.abacogroup.agri.applications.core.model.dto.publics.ApplicationDTO;
import com.abacogroup.agri.applications.core.services.crud.ApplicationProfilesCrudService;
import com.abacogroup.agri.applications.core.services.crud.ApplicationsCrudService;
import com.abacogroup.workflow.server.services.timer.TimerQueueJob;

import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.UUID;

import static org.mockito.Mockito.when;

/**
 * The type Application profiles manager test.
 *
 * @author Carlo Sindico
 */
@Slf4j
@ExtendWith(MockitoExtension.class)
class ApplicationProfilesManagerTest {

	private static final String TENANT = "tenant";

	private static final Long APPLICATION_ID = 1L;

	private static final String PROFILE_CODE = "profile_code";

	private static final String PROFILE_CODE_1 = "profile_code_1";

	private static final String PROFILE_CODE_2 = "profile_code_2";

	private final ApplicationProfileDTO applicationProfileDTOMock = ApplicationProfileDTO.builder()
			.applicationId(APPLICATION_ID)
			.profileCode(PROFILE_CODE)
			.build();

	@Mock
	private ApplicationProfilesCrudService applicationProfilesCrudService;

	@Mock
	private ApplicationDTO appDto;

	@Mock
	private ApplicationsCrudService applicationsCrudService;

	@Mock
	private TimerQueueJob job = TimerQueueJob.builder()
			.localeCode("en")
			.processId(1L)
			.tenantId(TENANT)
			.timerName("test")
			.userId("userID")
			.uuid(UUID.randomUUID().toString())
			.build();

	@InjectMocks
	private ApplicationProfilesManager applicationProfilesManager = new ApplicationProfilesManager(TENANT, APPLICATION_ID, applicationProfilesCrudService);

	@BeforeEach
	void init() {
		applicationProfilesManager = new ApplicationProfilesManager(TENANT, APPLICATION_ID, applicationProfilesCrudService);
	}

	@Test
	void test_getProfiles() {
		when(applicationProfilesCrudService.find(TENANT, APPLICATION_ID)).thenReturn(List.of(applicationProfileDTOMock));

		List<String> result = applicationProfilesManager.getAllProfiles(TENANT, APPLICATION_ID);

		Assertions.assertEquals(applicationProfileDTOMock.getProfileCode(), result.get(0));
	}

	@Test
	void test_haveAllOf() {
		try {
			Assertions.assertFalse(applicationProfilesManager.haveAllOf(PROFILE_CODE_1, PROFILE_CODE_2));
		} catch (Exception e) {
			Assertions.fail();
		}
	}

	@Test
	void test_haveAnyOf() {
		try {
			applicationProfilesManager.haveAnyOf(PROFILE_CODE_1, PROFILE_CODE_2);
		} catch (Exception e) {
			Assertions.fail();
		}
	}

}
