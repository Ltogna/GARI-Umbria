package com.abacogroup.agri.applications.core.services;

import com.abacogroup.agri.applications.core.caller.*;
import com.abacogroup.agri.applications.core.model.OverridePartyHostConfig;
import com.abacogroup.agri.applications.core.model.dto.PartyDTO;
import com.abacogroup.agri.applications.core.model.dto.PartyRegistryDTO;
import com.abacogroup.agri.applications.core.model.dto.publics.ApplicationEnvPublicDTO;
import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.jdbi.paging.impl.InfiniteListResultsImpl;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@Slf4j
@ExtendWith(MockitoExtension.class)
class PartyServiceTest {

	private static final String TENANT_ID_1 = "tenantId";
	private static final String CUAA = "1234567890";
	private static final String DESCRIPTION = "description_1";
	private static final String TENANT = "ADMIN";
	private static final Long PARTY_ID = 1l;
	private static final String PARTY_REGISTRY_DIRECTORY_URL = "party_registry_directory_url";
	private static final String PARTY_REGISTRY_DIRECTORY_SEARCH_URL = "party_registry_directory_search_url";
	private static final String USERNAME = "Username";
	private static final User USER = new User(USERNAME, TENANT);
	private static final String VALUE = "Value";
	private static final String KEY = "key";
	private static final String LEGACY = "legacy";

	@Mock
	private GetPartiesCaller getPartiesCaller;
	@Mock
	private GetPartyByPartyIdCaller getPartyByPartyIdCaller;
	@Mock
	private GetPartiesRegistryCaller getPartiesRegistryCaller;
	@Mock
	private GetPartyRegistryByPartyIdCaller getPartyRegistryByPartyIdCaller;
	@Mock
	private ConfigService configService;

	@InjectMocks
	private PartyService partyService;

	private final GetPartiesOutput getPartiesOutputMock = GetPartiesOutput.builder()
			.partyId(1L)
			.code(CUAA)
			.description("Azienda Agricola Rossini")
			.build();

	private final PartyRegistryDTO partyRegistryDTO = PartyRegistryDTO.builder()
			.code(CUAA)
			.build();

	private final PartyDTO partyDTO = PartyDTO.builder()
			.partyId(1L)
			.description("Azienda Agricola Rossini")
			.cuaa(CUAA)
			.build();

	private final ApplicationEnvPublicDTO applicationEnvPublicDTO = ApplicationEnvPublicDTO.builder()
			.key(PARTY_REGISTRY_DIRECTORY_URL)
			.value(LEGACY)
			.build();

	private final ApplicationEnvPublicDTO applicationEnvPublicDTO2 = ApplicationEnvPublicDTO.builder()
			.key(KEY)
			.value(VALUE)
			.build();

	@BeforeEach
	protected void init() {
		partyService = new PartyService(configService, getPartiesCaller, getPartyByPartyIdCaller, getPartiesRegistryCaller, getPartyRegistryByPartyIdCaller,
				OverridePartyHostConfig.builder().active(false).build());
	}

	@Test
	void test_getPartiesByCodeOrDesc() {
		when(getPartiesCaller.makeCall(any(GetPartiesInput.class)))
				.thenReturn(new InfiniteListResultsImpl<>(List.of(getPartiesOutputMock), null));

		PartyDTO expected = PartyDTO.builder()
				.partyId(1L)
				.cuaa(CUAA)
				.description("Azienda Agricola Rossini")
				.build();

		assertEquals(List.of(expected), partyService.getPartiesByCodeOrDesc(TENANT_ID_1, -1L, CUAA, DESCRIPTION, USER));
	}

	@Test
	void test_getPartiesByCuaaOrDesc_false_ok() {
		when(configService.getConfig(TENANT_ID_1, PARTY_REGISTRY_DIRECTORY_SEARCH_URL, 0)).thenReturn(List.of(applicationEnvPublicDTO2));

		when(getPartiesRegistryCaller.makeCall(any(GetPartiesRegistryInput.class)))
				.thenReturn(new InfiniteListResultsImpl<>(List.of(partyRegistryDTO), null));

		PartyDTO expected = PartyDTO.builder()
				.cuaa(CUAA)
				.description("")
				.build();

		assertEquals(List.of(expected), partyService.getPartiesByCodeOrDesc(TENANT_ID_1, -1L, CUAA, DESCRIPTION, USER));
	}

	@Test
	void test_getPartyByPartyId_checkCondition_true_ok() {
		when(configService.getConfig(TENANT, PARTY_REGISTRY_DIRECTORY_URL, 0)).thenReturn(List.of(applicationEnvPublicDTO));

		when(getPartyByPartyIdCaller.makeCall(any(GetPartyByPartyIdInput.class)))
				.thenReturn(getPartiesOutputMock);

		PartyDTO result = partyService.getPartyByPartyId(TENANT, PARTY_ID, USER);

		assertEquals(partyDTO, result);
	}

	@Test
	void test_getPartyByPartyId_checkCondition_false_ok() {

		PartyDTO expectedResult = PartyDTO.builder()
				.cuaa(CUAA)
				.description("")
				.build();

		when(configService.getConfig(TENANT, PARTY_REGISTRY_DIRECTORY_URL, 0)).thenReturn(List.of(applicationEnvPublicDTO2));

		when(getPartyRegistryByPartyIdCaller.makeCall(any(GetPartyRegistryByPartyIdInput.class)))
				.thenReturn(partyRegistryDTO);

		PartyDTO result = partyService.getPartyByPartyId(TENANT, PARTY_ID, USER);

		assertEquals(expectedResult, result);
	}

}
