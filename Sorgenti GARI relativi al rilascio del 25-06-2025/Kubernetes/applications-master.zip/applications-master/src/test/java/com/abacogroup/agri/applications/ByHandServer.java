package com.abacogroup.agri.applications;

public class ByHandServer {

	public static void main(String[] args) throws Exception {
		ApplicationsModuleApplication.main(new String[] {
				"server", "config-dev.yml"
		});
	}
}
