package com.abacogroup.agri.applications.core.services.print;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.fail;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;

import java.time.LocalDateTime;
import java.time.Month;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import com.abacogroup.agri.applications.core.model.dto.PartyDTO;
import com.abacogroup.agri.applications.core.services.ForceReadOnlyContextCheckerService;
import com.abacogroup.agri.applications.core.services.PartyService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.slf4j.MDC;

import com.abacogroup.agri.applications.core.caller.CreatePrintJobCaller;
import com.abacogroup.agri.applications.core.caller.CreatePrintJobInput;
import com.abacogroup.agri.applications.core.exceptions.ApplicationNotFoundRuntimeException;
import com.abacogroup.agri.applications.core.exceptions.ObjectNotFoundException;
import com.abacogroup.agri.applications.core.exceptions.ObjectNotFoundRuntimeException;
import com.abacogroup.agri.applications.core.model.dto.ApplicationGeneratedPrintDTO;
import com.abacogroup.agri.applications.core.model.dto.CreatePrintJobOutDTO;
import com.abacogroup.agri.applications.core.model.dto.ModuleDTO;
import com.abacogroup.agri.applications.core.model.dto.publics.ApplicationDTO;
import com.abacogroup.agri.applications.core.model.dto.publics.LastPrintDTO;
import com.abacogroup.agri.applications.core.model.dto.publics.PrintDetailsOutDTO;
import com.abacogroup.agri.applications.core.services.CheckPartyService;
import com.abacogroup.agri.applications.core.services.FileStoreService;
import com.abacogroup.agri.applications.core.services.crud.ApplicationGeneratedPrintCrudService;
import com.abacogroup.agri.applications.core.services.crud.ApplicationsCrudService;
import com.abacogroup.agri.applications.core.services.crud.CrudServiceContainer;
import com.abacogroup.agri.applications.core.services.crud.ModuleCrudService;
import com.abacogroup.agri.applications.core.services.crud.ModulePrintConfigParamCrudService;
import com.abacogroup.agri.applications.core.services.crud.ModulePrintConfigsCrudService;
import com.abacogroup.agri.applications.core.services.workflow.ApplicationsWorkflowService;
import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.jaxrsutils.filter.MDCPreFilter;
import com.abacogroup.workflow.server.model.WorkflowNode;

import jakarta.ws.rs.core.Response;

@ExtendWith(MockitoExtension.class)
class PrintServiceTest {
	@Mock
	private ModulePrintConfigsCrudService modulePrintConfigsCrudServiceMock;
	@Mock
	private ModulePrintConfigParamCrudService modulePrintConfigParamCrudService;
	@Mock
	private ApplicationGeneratedPrintCrudService applicationGeneratedPrintCrudServiceMock;
	@Mock
	private CreatePrintJobCaller createPrintJobCallerMock;
	@Mock
	private FileStoreService fileStoreServiceMock;
	@Mock
	private ApplicationsCrudService applicationsCrudService;
	@Mock
	private CheckPartyService checkPartyService;
	@Mock
	private ModuleCrudService moduleCrudService;
	@Mock
	private ApplicationsWorkflowService applicationsWorkflowService;
	@Mock
	private ForceReadOnlyContextCheckerService forceReadOnlyContextCheckerService;
	@Mock
	private PartyService partyService;

	private PrintService printService;

	private static final String PRINT_DESTINATION = "applications-prints-destination";
	private static final String TENANT = "ADMIN";
	private static final Long APPLICATION_ID = 46L;
	private static final Long PARTY_ID = 123L;
	private static final String FILE_ID = "123456";
	private static final String FILE_NAME = "File Name";
	private static final String PRINT_BUCKET_NAME = "application-prints-bucket";
	private static final String PRINT_ENGINE_URL = "http://print-engine:8080/print-engine";
	private static final String PRINT_CODE = "print code";
	private static final String DIFFERENT_PRINT_CODE = "different print code";
	private static final String PRINT_DESCRIPTION = "print description";
	private static final Long PRINT_CONFIG_ID = 27L;
	private static final String PROCESS_STATUS = "process status";
	private static final String USERNAME = "Username";
	private static final String AUTH_TOKEN = "Auth Token";
	private static final User USER = new User(USERNAME, AUTH_TOKEN, TENANT, USERNAME);
	private static final Long PKID = 1L;
	private static final LocalDateTime PRINT_DATE = LocalDateTime.of(2022, Month.JULY, 12, 14, 46, 49);
	private static final String UUID = "123456";

	private final ApplicationGeneratedPrintDTO applicationGeneratedPrintDTO = ApplicationGeneratedPrintDTO.builder()
			.applicationId(APPLICATION_ID)
			.processStatus(PROCESS_STATUS)
			.username(USERNAME)
			.pkid(PKID)
			.printDate(PRINT_DATE)
			.fileId(FILE_ID)
			.printDescription(FILE_NAME)
			.build();
	private final CreatePrintJobOutDTO createPrintJobOutDTO = CreatePrintJobOutDTO.builder()
			.uuid(UUID)
			.build();

	private final PartyDTO partyDTO = PartyDTO.builder()
			.partyId(PARTY_ID_1)
			.cuaa(CUAA_1)
			.build();

	@BeforeEach
	void init() {
		CrudServiceContainer crudServiceContainer = CrudServiceContainer.builder()
				.moduleCrudService(moduleCrudService)
				.applicationsCrudService(applicationsCrudService)
				.moduleCrudService(moduleCrudService)
				.modulePrintConfigsCrudService(modulePrintConfigsCrudServiceMock)
				.modulePrintConfigParamCrudService(modulePrintConfigParamCrudService)
				.applicationGeneratedPrintCrudService(applicationGeneratedPrintCrudServiceMock)
				.build();

		printService = new PrintService(crudServiceContainer, checkPartyService, applicationsWorkflowService,
				createPrintJobCallerMock, fileStoreServiceMock,
				PRINT_BUCKET_NAME,
				PRINT_ENGINE_URL,
				forceReadOnlyContextCheckerService, partyService);
	}

	@Test
	void startPrintJob_ok() {
		CreatePrintJobInput input = CreatePrintJobInput.builder()
				.url(PRINT_ENGINE_URL)
				.bucketName(PRINT_BUCKET_NAME)
				.destination(PRINT_DESTINATION)
				.printCode(PRINT_CODE)
				.tenant(TENANT)
				.token("JWT " + AUTH_TOKEN)
				.locale(MDC.get(MDCPreFilter.LOCALE))
				.params(Map.of("applicationId", APPLICATION_ID,
						"partyId", PARTY_ID))
				.build();
		PrintDetailsOutDTO printDetailsOutDTO = PrintDetailsOutDTO.builder()
				.printCode(PRINT_CODE)
				.printConfigId(PRINT_CONFIG_ID)
				.printDescription(PRINT_DESCRIPTION)
				.lastPrint(LastPrintDTO.builder()
						.printDate(PRINT_DATE)
						.fileId(FILE_ID)
						.build())
				.build();

		List<PrintDetailsOutDTO> modulesPrint = List.of(printDetailsOutDTO);

		when(createPrintJobCallerMock.makeCall(input))
				.thenReturn(createPrintJobOutDTO);
		when(applicationGeneratedPrintCrudServiceMock.insert(ApplicationGeneratedPrintDTO.builder()
				.applicationId(APPLICATION_ID)
				.printCode(PRINT_CODE)
				.printDate(any())
				.processStatus(PROCESS_STATUS)
				.printJobUuid(UUID)
				.username(USERNAME)
				.build()))
				.thenReturn(applicationGeneratedPrintDTO);

		ApplicationGeneratedPrintDTO result =
				printService.startPrintJob(TENANT, APPLICATION_ID, PARTY_ID, PROCESS_STATUS, modulesPrint, PRINT_CODE, USER);

		assertEquals(applicationGeneratedPrintDTO, result);
	}

	@Test
	void getPrintFromFileStore_ok() {
		Response expectedOutput = Response.ok().build();
		ApplicationDTO applicationDTO = ApplicationDTO.builder()
				.moduleId(MODULE_ID_1)
				.applicationId(APPLICATION_ID)
				.referredYear(YEAR_1)
				.partyId(PARTY_ID_1)
				.build();
		try {
			when(applicationGeneratedPrintCrudServiceMock.findPrintByApplicationIdAndFileId(TENANT, APPLICATION_ID, FILE_ID))
					.thenReturn(Optional.of(applicationGeneratedPrintDTO));
			when(fileStoreServiceMock.getFileForDownload(eq(TENANT), eq(FILE_ID), eq(PRINT_BUCKET_NAME), eq(FILE_NAME), eq(USER), any()))
					.thenReturn(expectedOutput);
			when(applicationsCrudService.findById(TENANT, APPLICATION_ID))
					.thenReturn(applicationDTO);
			when(partyService.getPartyByPartyId(TENANT, PARTY_ID_1, USER))
					.thenReturn(partyDTO);
			Response result = printService.getPrintFromFileStore(TENANT, APPLICATION_ID, FILE_ID, USER);

			assertEquals(expectedOutput, result);
		}catch (Exception e){
			fail(e);
		}
	}

	@Test
	void getPrintFromFileStore_ko() {
		when(applicationGeneratedPrintCrudServiceMock.findPrintByApplicationIdAndFileId(TENANT, APPLICATION_ID, FILE_ID))
				.thenReturn(Optional.empty());

		assertThrows(ObjectNotFoundRuntimeException.class, () ->
				printService.getPrintFromFileStore(TENANT, APPLICATION_ID, FILE_ID, USER));
	}

	@Test
	void startPrintJob_modulesPrint_noneMatch_ko() {
		PrintDetailsOutDTO printDetailsOutDTO = PrintDetailsOutDTO.builder()
				.printCode(DIFFERENT_PRINT_CODE)
				.printConfigId(PRINT_CONFIG_ID)
				.printDescription(PRINT_DESCRIPTION)
				.lastPrint(LastPrintDTO.builder()
						.printDate(PRINT_DATE)
						.fileId(FILE_ID)
						.build())
				.build();

		List<PrintDetailsOutDTO> modulesPrint = List.of(printDetailsOutDTO);

		assertThrows(RuntimeException.class, () ->
				printService.startPrintJob(TENANT, APPLICATION_ID, PARTY_ID, PROCESS_STATUS, modulesPrint, PRINT_CODE, USER));
	}

	@Test
	void startPrintJob_catchRuntimeException_ko() {
		CreatePrintJobInput input = CreatePrintJobInput.builder()
				.url(PRINT_ENGINE_URL)
				.bucketName(PRINT_BUCKET_NAME)
				.destination(PRINT_DESTINATION)
				.printCode(PRINT_CODE)
				.tenant(TENANT)
				.token(MDC.get(MDCPreFilter.USED_JWT))
				.locale(MDC.get(MDCPreFilter.LOCALE))
				.params(Map.of("businessId", "40952", //TODO remove mock
						"cropPlanId", "402",
						"pointInTime", "20221022"))
				.build();
		PrintDetailsOutDTO printDetailsOutDTO = PrintDetailsOutDTO.builder()
				.printCode(PRINT_CODE)
				.printConfigId(PRINT_CONFIG_ID)
				.printDescription(PRINT_DESCRIPTION)
				.lastPrint(LastPrintDTO.builder()
						.printDate(PRINT_DATE)
						.fileId(FILE_ID)
						.build())
				.build();

		List<PrintDetailsOutDTO> modulesPrint = List.of(printDetailsOutDTO);

		when(createPrintJobCallerMock.makeCall(input))
				.thenThrow(RuntimeException.class);

		assertThrows(RuntimeException.class, () ->
				printService.startPrintJob(TENANT, APPLICATION_ID, PARTY_ID, PROCESS_STATUS, modulesPrint, PRINT_CODE, USER));

	}

	private static final Long MODULE_ID_1 = 1L;
	private static final Long APPLICATION_ID_1 = 30L;
	private static final Integer YEAR_1 = 2022;
	private static final Long PARTY_ID_1 = 24L;
	private static final String CUAA_1 = "CUAA_1";
	private static final String MODULE_CODE = "module_code_1";
	private static final String WORKFLOW_CODE_1 = "wf-code-1";
	private static final String PROCESS_STATUS_1 = "status_1";
	private static final String USER_1 = "user_1";
	private static final Long PK_ID_1 = 1L;
	private static final String WORKFLOW_DESCRIPTION = "workflow description";
	private static final String TENANT_1 = "tenant_1";
	private static final User logged_user1 = new User(USER_1, TENANT_1);

	@Test
	void test_getApplicationPrintsByApplicationId_ok() {
		try {
			ApplicationDTO applicationDTO = ApplicationDTO.builder()
					.moduleId(MODULE_ID_1)
					.applicationId(APPLICATION_ID_1)
					.referredYear(YEAR_1)
					.partyId(PARTY_ID_1)
					.build();
			ModuleDTO moduleDTO = ModuleDTO.builder()
					.moduleCode(MODULE_CODE)
					.moduleId(MODULE_ID_1)
					.workflowCode(WORKFLOW_CODE_1)
					.build();
			List<ApplicationGeneratedPrintDTO> applicationGeneratedPrintDTOs = List.of(ApplicationGeneratedPrintDTO.builder()
					.applicationId(APPLICATION_ID_1)
					.processStatus(PROCESS_STATUS_1)
					.printDescription(PRINT_DESCRIPTION)
					.username(USER_1)
					.pkid(PK_ID_1)
					.build());

			WorkflowNode workflowNode = WorkflowNode.builder()
					.description(WORKFLOW_DESCRIPTION)
					.build();

			List<ApplicationGeneratedPrintDTO> expectedOutput = List.of(ApplicationGeneratedPrintDTO.builder()
					.applicationId(APPLICATION_ID_1)
					.processStatus(WORKFLOW_DESCRIPTION)
					.printDescription(PRINT_DESCRIPTION)
					.username(USER_1)
					.pkid(PK_ID_1)
					.build());

			when(applicationsCrudService.findById(TENANT_1, APPLICATION_ID_1))
					.thenReturn(applicationDTO);
			when(moduleCrudService.findById(MODULE_ID_1))
					.thenReturn(Optional.of(moduleDTO));
			when(applicationGeneratedPrintCrudServiceMock.findAllGeneratedPrintsByPrintCode(TENANT_1, APPLICATION_ID_1, null))
					.thenReturn(applicationGeneratedPrintDTOs);
			when(applicationsWorkflowService.getWorkflowNode(TENANT_1, WORKFLOW_CODE_1, PROCESS_STATUS_1))
					.thenReturn(workflowNode);

			when(partyService.getPartyByPartyId(TENANT_1, PARTY_ID_1, logged_user1))
					.thenReturn(partyDTO);

			List<ApplicationGeneratedPrintDTO> result = printService.getApplicationPrintsByApplicationId(TENANT_1, APPLICATION_ID_1, logged_user1, null);

			assertEquals(expectedOutput, result);
		} catch (Exception e) {
			fail(e);
		}

	}

	@Test
	void test_getApplicationPrintsByApplicationId_ApplicationNotFoundRuntimeException() {
		try {
			when(applicationsCrudService.findById(TENANT_1, APPLICATION_ID_1))
					.thenThrow(ObjectNotFoundException.class);

			assertThrows(ApplicationNotFoundRuntimeException.class,
					() -> printService.getApplicationPrintsByApplicationId(TENANT_1, APPLICATION_ID_1, logged_user1, null));
		} catch (Exception e) {
			fail(e);
		}

	}

	@Test
	void test_getApplicationPrintsByApplicationId_ObjectNotFoundRuntimeException() {
		try {
			ApplicationDTO applicationDTO = ApplicationDTO.builder()
					.moduleId(MODULE_ID_1)
					.applicationId(APPLICATION_ID_1)
					.referredYear(YEAR_1)
					.partyId(PARTY_ID_1)
					.build();

			when(applicationsCrudService.findById(TENANT_1, APPLICATION_ID_1))
					.thenReturn(applicationDTO);
			when(moduleCrudService.findById(MODULE_ID_1))
					.thenReturn(Optional.empty());

			assertThrows(ObjectNotFoundRuntimeException.class,
					() -> printService.getApplicationPrintsByApplicationId(TENANT_1, APPLICATION_ID_1, logged_user1, null));
		} catch (Exception e) {
			fail(e);
		}

	}
}
