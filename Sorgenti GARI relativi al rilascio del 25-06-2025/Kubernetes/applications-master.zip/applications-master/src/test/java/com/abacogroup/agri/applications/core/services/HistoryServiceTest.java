package com.abacogroup.agri.applications.core.services;

import com.abacogroup.agri.applications.core.exceptions.ApplicationNotFoundRuntimeException;
import com.abacogroup.agri.applications.core.exceptions.ObjectNotFoundException;
import com.abacogroup.agri.applications.core.model.dto.publics.ApplicationDTO;
import com.abacogroup.agri.applications.core.services.crud.ApplicationsCrudService;
import com.abacogroup.agri.applications.core.services.workflow.ApplicationsWorkflowService;
import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.workflow.sdk.auth.AuthContext;
import com.abacogroup.workflow.sdk.beans.testsupport.AuthContextTestSupport;
import com.abacogroup.workflow.server.db.ntt.WorLogTransitionWithDetailsEntity;
import com.abacogroup.workflow.server.model.DetailedTransitionLog;
import com.fasterxml.jackson.core.JsonToken;
import io.dropwizard.jackson.Jackson;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;

@Slf4j
@ExtendWith(MockitoExtension.class)
class HistoryServiceTest {

	@Mock
	private ApplicationsCrudService applicationsCrudService;
	@Mock
	private ApplicationsWorkflowService applicationsWorkflowService;
	@Mock
	private CheckPartyService checkPartyService;
	@InjectMocks
	private HistoryService historyService;

	private static final Long PROCESS_ID_1 = 1L;
	private static final Long PARTY_ID_1 = 24L;
	private static final Long APPLICATION_ID_1 = 30L;
	private static final Integer YEAR_1 = 2022;
	private static final Long MODULE_ID_1 = 1L;
	private static final String TENANT_1 = "tenant_1";
	private static final String USER_1 = "user_1";
	private static final User logged_user1 = new User(USER_1, TENANT_1);

	@Test
	void test_getApplicationHistoryByApplicationId_ok() {
		ApplicationDTO applicationDTO = ApplicationDTO.builder()
				.processId(PROCESS_ID_1)
				.partyId(PARTY_ID_1)
				.applicationId(APPLICATION_ID_1)
				.referredYear(YEAR_1)
				.moduleId(MODULE_ID_1)
				.build();

		WorLogTransitionWithDetailsEntity ntt = new WorLogTransitionWithDetailsEntity();
		ntt.setIs_failed(0);
		ntt.setFrom(new WorLogTransitionWithDetailsEntity.Node());
		ntt.setTo(new WorLogTransitionWithDetailsEntity.Node());
		ntt.setMessages(JsonToken.VALUE_NULL.asString());
		AuthContext authContext = new AuthContextTestSupport();
		List<DetailedTransitionLog> expectedOutput = List.of(new DetailedTransitionLog(ntt, authContext, Jackson.newObjectMapper()));

		try {
			when(applicationsCrudService.findByIdAlsoExpired(TENANT_1, APPLICATION_ID_1))
					.thenReturn(applicationDTO);
			when(applicationsWorkflowService.getProcessTransitionHistory(TENANT_1, PROCESS_ID_1, logged_user1))
					.thenReturn(expectedOutput);

			List<DetailedTransitionLog> result = historyService.getApplicationHistoryByApplicationId(TENANT_1, APPLICATION_ID_1, logged_user1);

			assertEquals(expectedOutput, result);
		} catch (Exception e) {
			fail(e.getMessage(), e);
		}
	}

	@Test
	void test_getApplicationHistoryByApplicationId_ko() {
		try {
			when(applicationsCrudService.findByIdAlsoExpired(TENANT_1, APPLICATION_ID_1))
					.thenThrow(ObjectNotFoundException.class);

			assertThrows(ApplicationNotFoundRuntimeException.class,
					() -> historyService.getApplicationHistoryByApplicationId(TENANT_1, APPLICATION_ID_1, logged_user1));
		} catch (Exception e) {
			fail(e);
		}
	}
}
