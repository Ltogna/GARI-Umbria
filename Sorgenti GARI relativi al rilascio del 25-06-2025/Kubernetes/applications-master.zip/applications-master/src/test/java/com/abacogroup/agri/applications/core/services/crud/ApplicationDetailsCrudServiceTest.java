package com.abacogroup.agri.applications.core.services.crud;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.fail;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.lenient;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.List;
import java.util.Optional;

import org.jdbi.v3.sqlobject.transaction.TransactionalCallback;
import org.jdbi.v3.sqlobject.transaction.TransactionalConsumer;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.abacogroup.agri.applications.core.exceptions.ObjectNotFoundException;
import com.abacogroup.agri.applications.core.mappers.ApplicationDetailsMapper;
import com.abacogroup.agri.applications.core.model.ProcessTransitionEnum;
import com.abacogroup.agri.applications.core.model.dto.ApplicationDetailsDTO;
import com.abacogroup.agri.applications.db.dao.ApplicationDetailsDAO;
import com.abacogroup.agri.applications.db.ntt.ApplicationDetailsNTT;

@ExtendWith(MockitoExtension.class)
class ApplicationDetailsCrudServiceTest extends AbstractCrudServiceTest {

	private static final String TENANT_ID_1 = "tenant_1";
	private static final Long APPLICATION_ID_1 = 1L;
	private static final String APPLICATION_CODE_1 = "applicationCode_1";
	private static final LocalDateTime APPLICATION_DT_PRESENTATION_1 = LocalDateTime.of(2022, 9, 19, 12, 0);
	private static final LocalDateTime DEFAULT_NOT_DELETED_DATE = LocalDateTime.ofInstant(Instant.ofEpochSecond(253402300799L), ZoneOffset.UTC);
	private static final LocalDateTime NOW = LocalDateTime.now();
	private static final String APPLICATION_PROCESS_STATUS_1 = "1L";
	private static final String USER_ID = "user1";
	private static final ApplicationDetailsDTO applicationDetailsDTO = ApplicationDetailsDTO.builder()
			.applicationCode(APPLICATION_CODE_1)
			.applicationId(APPLICATION_ID_1)
			.dtPresentation(APPLICATION_DT_PRESENTATION_1)
			.pkid(APPLICATION_ID_1)
			.processStatus(APPLICATION_PROCESS_STATUS_1)
			.userIdInsert(USER_ID)
			.userIdDelete(null)
			.dtInsert(NOW)
			.dtDelete(DEFAULT_NOT_DELETED_DATE)
			.flInTransition(1)
			.build();
	private static final ApplicationDetailsDTO applicationDetailsDTOResult = ApplicationDetailsDTO.builder()
			.applicationCode(APPLICATION_CODE_1)
			.applicationId(APPLICATION_ID_1)
			.dtPresentation(APPLICATION_DT_PRESENTATION_1)
			.pkid(APPLICATION_ID_1)
			.processStatus(APPLICATION_PROCESS_STATUS_1)
			.userIdInsert(USER_ID)
			.userIdDelete(null)
			.dtInsert(NOW)
			.dtDelete(DEFAULT_NOT_DELETED_DATE)
			.flInTransition(1)
			.build();
	private static final ApplicationDetailsNTT applicationDetailsNTT = ApplicationDetailsNTT.builder()
			.application_code(APPLICATION_CODE_1)
			.application_id(APPLICATION_ID_1)
			.dt_presentation(APPLICATION_DT_PRESENTATION_1)
			.pkid(APPLICATION_ID_1)
			.process_status(APPLICATION_PROCESS_STATUS_1)
			.user_id_insert(USER_ID)
			.user_id_delete(null)
			.dt_insert(NOW)
			.dt_delete(DEFAULT_NOT_DELETED_DATE)
			.fl_in_transition(1)
			.build();

	@Mock
	private ApplicationDetailsDAO dao;
	@Mock
	private ApplicationDetailsMapper applicationDetailsMapper;
	@InjectMocks
	private ApplicationDetailsCrudService applicationDetailsService;

	@BeforeEach
	void beforeEach() {
		lenient().when(dao.getCurrentTimestamp()).thenAnswer($ -> LocalDateTime.now());
	}

	@Test
	void test_hasPrimaryKey_ok() {
		assertTrue(applicationDetailsService.hasPrimaryKey());
	}

	@Test
	void test_retrieveCustomKeyByResultSet() {
		assertNull(applicationDetailsService.retrieveCustomKeyByResultSet(applicationDetailsNTT));
	}

	@Test
	void test_findRsByCustomKey_ok() {
		assertEquals(Optional.empty(), applicationDetailsService.findRsByCustomKey(null));
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Test
	void test_insert_ok() {
		try {
			ArgumentCaptor<TransactionalCallback> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(TransactionalCallback.class);

			when(dao.nextSequenceVal()).thenReturn(APPLICATION_ID_1);
			when(dao.findById(APPLICATION_ID_1)).thenReturn(List.of(applicationDetailsNTT));
			when(applicationDetailsMapper.dtoToEntity(applicationDetailsDTO)).thenReturn(applicationDetailsNTT);
			when(applicationDetailsMapper.entityToDto(applicationDetailsNTT)).thenReturn(applicationDetailsDTO);

			applicationDetailsService.insert(applicationDetailsDTO, USER_ID);

			verify(dao).inTransaction(handleConsumerLambdaCaptor.capture());

			ApplicationDetailsDTO result = (ApplicationDetailsDTO) handleConsumerLambdaCaptor.getValue().inTransaction(dao);

			assertEquals(applicationDetailsDTOResult, result);

		} catch (Exception e) {
			fail(e.getMessage(), e);
		}
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Test
	void test_update_ok() {
		try {
			ArgumentCaptor<TransactionalCallback> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(TransactionalCallback.class);
			when(dao.nextSequenceVal()).thenReturn(APPLICATION_ID_1);
			when(dao.getCurrentTimestamp()).thenReturn(LocalDateTime.now());
			when(dao.findById(APPLICATION_ID_1)).thenReturn(List.of(applicationDetailsNTT));
			when(applicationDetailsMapper.dtoToEntity(applicationDetailsDTO)).thenReturn(applicationDetailsNTT);
			when(applicationDetailsMapper.entityToDto(applicationDetailsNTT)).thenReturn(applicationDetailsDTO);

			applicationDetailsService.update(APPLICATION_ID_1, applicationDetailsDTO, USER_ID);

			verify(dao).inTransaction(handleConsumerLambdaCaptor.capture());

			handleConsumerLambdaCaptor.getValue().inTransaction(dao);

			verify(dao, times(2)).inTransaction(handleConsumerLambdaCaptor.capture());

			ApplicationDetailsDTO actual = (ApplicationDetailsDTO) handleConsumerLambdaCaptor.getValue().inTransaction(dao);

			assertEquals(applicationDetailsDTO, actual);
		} catch (Exception e) {
			fail(e.getMessage(), e);
		}
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Test
	void test_delete_ok() {
		try {
			ArgumentCaptor<TransactionalConsumer> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(TransactionalConsumer.class);

			applicationDetailsService.delete(APPLICATION_ID_1, USER_ID);

			verify(dao).useTransaction(handleConsumerLambdaCaptor.capture());
			handleConsumerLambdaCaptor.getValue().useTransaction(dao);
			verify(dao, times(1)).logicallyDeleteById(eq(APPLICATION_ID_1), eq(USER_ID), any());
		} catch (Exception e) {
			fail(e.getMessage(), e);
		}
	}

	@Test
	void test_findApplicationDetailByCode() {
		try {
			when(dao.findByCode(TENANT_ID_1, APPLICATION_CODE_1))
					.thenReturn(List.of(applicationDetailsNTT));
			when(applicationDetailsMapper.entityToDto(applicationDetailsNTT))
					.thenReturn(applicationDetailsDTO);

			ApplicationDetailsDTO result = applicationDetailsService.findApplicationDetailByCode(TENANT_ID_1, APPLICATION_CODE_1);

			assertEquals(applicationDetailsDTO, result);
		} catch (Exception e) {
			fail(e);
		}
	}

	@Test
	void test_findApplicationDetailById() {
		try {
			when(dao.findByApplicationId(TENANT_ID_1, APPLICATION_ID_1))
					.thenReturn(List.of(applicationDetailsNTT));
			when(applicationDetailsMapper.entityToDto(applicationDetailsNTT))
					.thenReturn(applicationDetailsDTO);
			when(dao.findFirstDtInsert(TENANT_ID_1, APPLICATION_ID_1))
					.thenReturn(NOW);

			ApplicationDetailsDTO result = applicationDetailsService.findApplicationDetailById(TENANT_ID_1, APPLICATION_ID_1);

			assertEquals(applicationDetailsDTO, result);
		} catch (Exception e) {
			fail(e);
		}
	}

	@Test
	void test_findApplicationDetailByCode_ko() {
		try {
			when(dao.findByCode(TENANT_ID_1, APPLICATION_CODE_1))
					.thenReturn(List.of());

			assertThrows(ObjectNotFoundException.class, () -> applicationDetailsService.findApplicationDetailByCode(TENANT_ID_1, APPLICATION_CODE_1));
		} catch (Exception e) {
			fail(e);
		}
	}

	@Test
	void test_findApplicationDetailById_ko() {
		try {
			when(dao.findByApplicationId(TENANT_ID_1, APPLICATION_ID_1))
					.thenReturn(List.of());

			assertThrows(ObjectNotFoundException.class, () -> applicationDetailsService.findApplicationDetailById(TENANT_ID_1, APPLICATION_ID_1));
		} catch (Exception e) {
			fail(e);
		}
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Test
	void test_updateProcessStatusAndFlTransition() {
		try {
			when(dao.findByApplicationIdAlsoExpired(TENANT_ID_1, APPLICATION_ID_1))
					.thenReturn(List.of(applicationDetailsNTT));
			when(applicationDetailsMapper.entityToDto(applicationDetailsNTT))
					.thenReturn(applicationDetailsDTO);
			when(dao.findFirstDtInsert(TENANT_ID_1, APPLICATION_ID_1))
					.thenReturn(NOW);

			ArgumentCaptor<TransactionalCallback> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(TransactionalCallback.class);
			when(dao.getCurrentTimestamp()).thenReturn(LocalDateTime.now());

			applicationDetailsService.updateProcessStatusAndFlTransition(TENANT_ID_1, APPLICATION_ID_1,
					APPLICATION_PROCESS_STATUS_1, USER_ID, ProcessTransitionEnum.IN_TRANSITION);

			verify(dao).inTransaction(handleConsumerLambdaCaptor.capture());
			handleConsumerLambdaCaptor.getValue().inTransaction(dao);

			verify(dao, times(2)).inTransaction(handleConsumerLambdaCaptor.capture());
		} catch (Exception e) {
			fail(e);
		}
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Test
	void test_updateFlTransition() {
		try {
			when(dao.findByApplicationId(TENANT_ID_1, APPLICATION_ID_1))
					.thenReturn(List.of(applicationDetailsNTT));
			when(applicationDetailsMapper.entityToDto(applicationDetailsNTT))
					.thenReturn(applicationDetailsDTO);
			when(dao.findFirstDtInsert(TENANT_ID_1, APPLICATION_ID_1))
					.thenReturn(NOW);

			ArgumentCaptor<TransactionalCallback> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(TransactionalCallback.class);
			when(dao.getCurrentTimestamp()).thenReturn(LocalDateTime.now());

			applicationDetailsService.updateFlTransition(TENANT_ID_1, APPLICATION_ID_1, USER_ID, ProcessTransitionEnum.IN_TRANSITION);

			verify(dao).inTransaction(handleConsumerLambdaCaptor.capture());
			handleConsumerLambdaCaptor.getValue().inTransaction(dao);

			verify(dao, times(2)).inTransaction(handleConsumerLambdaCaptor.capture());
		} catch (Exception e) {
			fail(e);
		}
	}

}
