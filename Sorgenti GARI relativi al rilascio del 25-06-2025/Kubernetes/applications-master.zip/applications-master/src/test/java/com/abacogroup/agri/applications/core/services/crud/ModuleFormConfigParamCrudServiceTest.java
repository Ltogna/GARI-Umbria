package com.abacogroup.agri.applications.core.services.crud;

import com.abacogroup.agri.applications.core.exceptions.ObjectNotFoundException;
import com.abacogroup.agri.applications.core.mappers.ModuleFormConfigParamMapper;
import com.abacogroup.agri.applications.core.model.dto.ModuleFormConfigParamDTO;
import com.abacogroup.agri.applications.core.services.I18NService;
import com.abacogroup.agri.applications.db.dao.ModuleFormConfigParamDAO;
import com.abacogroup.agri.applications.db.ntt.ModuleFormConfigParamNTT;
import com.abacogroup.agri.applications.db.ntt.compoundkeys.FormConfigParamKey;
import org.jdbi.v3.sqlobject.transaction.TransactionalCallback;
import org.jdbi.v3.sqlobject.transaction.TransactionalConsumer;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class ModuleFormConfigParamCrudServiceTest extends AbstractCrudServiceTest {

	private static final String TENANT_ID_1 = "tenant_1";
	private static final Long FORM_CONFIG_ID_1 = 1L;
	private static final String FORM_PARAMETER_NAME_1 = "sectorCode_1";
	private static final String FORM_PARAMETER_VALUE_1 = "val_1";
	private static final FormConfigParamKey formConfigParamKey = FormConfigParamKey.builder()
			.module_form_config_id(FORM_CONFIG_ID_1)
			.parameter_name(FORM_PARAMETER_NAME_1)
			.build();

	private static final ModuleFormConfigParamNTT moduleFormConfigParamNttMock = ModuleFormConfigParamNTT.builder()
			.module_form_config_id(FORM_CONFIG_ID_1)
			.parameter_name(FORM_PARAMETER_NAME_1)
			.parameter_value(FORM_PARAMETER_VALUE_1)
			.build();

	private static final ModuleFormConfigParamDTO moduleFormConfigParamDtoMock = ModuleFormConfigParamDTO.builder()
			.moduleFormConfigId(FORM_CONFIG_ID_1)
			.parameterName(FORM_PARAMETER_NAME_1)
			.parameterValue(FORM_PARAMETER_VALUE_1)
			.build();

	@Mock
	private ModuleFormConfigParamDAO dao;
	@Spy
	private ModuleFormConfigParamMapper formGroupMapper = ModuleFormConfigParamMapper.INSTANCE;
	@Mock
	private I18NService i18NService;
	@InjectMocks
	private ModuleFormConfigParamCrudService moduleFormConfigParamCrudService;

	@Test
	void test_hasPrimaryKey() {
		assertFalse(moduleFormConfigParamCrudService.hasPrimaryKey());
	}

	@SuppressWarnings({"rawtypes", "unchecked"})
	@Test
	void test_insert() {
		try {
			ArgumentCaptor<TransactionalCallback> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(TransactionalCallback.class);

			when(dao.findById(FORM_CONFIG_ID_1, FORM_PARAMETER_NAME_1)).thenReturn(List.of(moduleFormConfigParamNttMock));

			moduleFormConfigParamCrudService.insert(moduleFormConfigParamDtoMock);

			verify(dao).inTransaction(handleConsumerLambdaCaptor.capture());

			ModuleFormConfigParamDTO result = (ModuleFormConfigParamDTO) handleConsumerLambdaCaptor.getValue().inTransaction(dao);

			assertEquals(moduleFormConfigParamDtoMock, result);

		} catch (Exception e) {
			fail(e.getMessage(), e);
		}
	}

	@SuppressWarnings({"rawtypes", "unchecked"})
	@Test
	void test_update() {
		try {
			ArgumentCaptor<TransactionalCallback> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(TransactionalCallback.class);

			when(dao.findById(FORM_CONFIG_ID_1, FORM_PARAMETER_NAME_1)).thenReturn(List.of(moduleFormConfigParamNttMock));

			moduleFormConfigParamCrudService.update(moduleFormConfigParamDtoMock);

			verify(dao).inTransaction(handleConsumerLambdaCaptor.capture());

			ModuleFormConfigParamDTO result = (ModuleFormConfigParamDTO) handleConsumerLambdaCaptor.getValue().inTransaction(dao);

			assertEquals(moduleFormConfigParamDtoMock, result);
		} catch (Exception e) {
			fail(e.getMessage(), e);
		}
	}

	@SuppressWarnings({"rawtypes", "unchecked"})
	@Test
	void test_delete() throws Exception {
		ArgumentCaptor<TransactionalConsumer> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(TransactionalConsumer.class);
		moduleFormConfigParamCrudService.delete(formConfigParamKey);
		verify(dao).useTransaction(handleConsumerLambdaCaptor.capture());
		handleConsumerLambdaCaptor.getValue().useTransaction(dao);
		verify(dao, times(1)).deleteById(formConfigParamKey.getModule_form_config_id(), formConfigParamKey.getParameter_name());
	}

	@Test
	void test_deleteByModuleFormConfigId() {
		moduleFormConfigParamCrudService.deleteByModuleFormConfigId(FORM_CONFIG_ID_1);

		verify(dao, times(1)).deleteByModuleFormConfigId(FORM_CONFIG_ID_1);
	}

	@Test
	void test_findById() throws ObjectNotFoundException {
		when(dao.findById(TENANT_ID_1, FORM_CONFIG_ID_1, FORM_PARAMETER_NAME_1)).thenReturn(List.of(moduleFormConfigParamNttMock));
		assertEquals(moduleFormConfigParamDtoMock, moduleFormConfigParamCrudService.findById(TENANT_ID_1, formConfigParamKey));
	}

	@Test
	void test_findAllById() {
		when(dao.find(TENANT_ID_1, FORM_CONFIG_ID_1)).thenReturn(List.of(moduleFormConfigParamNttMock));
		assertEquals(List.of(moduleFormConfigParamDtoMock), moduleFormConfigParamCrudService.find(TENANT_ID_1, FORM_CONFIG_ID_1));
	}
}
