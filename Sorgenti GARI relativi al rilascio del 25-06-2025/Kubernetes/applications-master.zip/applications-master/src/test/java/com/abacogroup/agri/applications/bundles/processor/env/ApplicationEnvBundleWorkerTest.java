package com.abacogroup.agri.applications.bundles.processor.env;

import com.abacogroup.agri.applications.bundles.model.env.BundleApplicationEnvInDTO;
import com.abacogroup.agri.applications.bundles.model.env.BundleApplicationEnvMessage;
import com.abacogroup.agri.applications.core.exceptions.ObjectNotFoundException;
import com.abacogroup.agri.applications.core.model.dto.AmendableModuleDTO;
import com.abacogroup.agri.applications.core.model.dto.ApplicationEnvDTO;
import com.abacogroup.agri.applications.core.model.dto.ModuleDTO;
import com.abacogroup.agri.applications.core.services.crud.ApplicationEnvCrudService;
import com.abacogroup.agri.applications.db.ntt.compoundkeys.ApplicationEnvKey;
import com.abacogroup.bundles.listener.configdata.ConfigDataMessage;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.fail;
import static org.mockito.Mockito.*;

@Slf4j
@ExtendWith(MockitoExtension.class)
class ApplicationEnvBundleWorkerTest {

	private static final String TEMPLATE_TENANT_ID = "*";
	private static final String ENV_KEY = "env_key";
	private static final String VALUE = "value";
	private static final Integer FL_CLIENT = 1;

	private final ApplicationEnvDTO applicationEnvDTO = ApplicationEnvDTO.builder()
			.tenant(TEMPLATE_TENANT_ID)
			.key(ENV_KEY)
			.value(VALUE)
			.flClient(FL_CLIENT)
			.build();

	private final ConfigDataMessage configDataMessage = new ConfigDataMessage();

	private final BundleApplicationEnvInDTO bundleApplicationEnvInDTO = BundleApplicationEnvInDTO.builder()
			.key(ENV_KEY)
			.value(VALUE)
			.flClient(FL_CLIENT)
			.build();

	private final BundleApplicationEnvMessage bundleApplicationEnvMessage = BundleApplicationEnvMessage.builder()
			.bundleApplicationEnvInDTOList(List.of(bundleApplicationEnvInDTO))
			.build();

	@InjectMocks
	private ApplicationEnvBundleWorker applicationEnvBundleWorker;
	@Mock
	private ApplicationEnvCrudService applicationEnvCrudService;


	@BeforeEach
	void init() {
		configDataMessage.setTenantId(TEMPLATE_TENANT_ID);
		applicationEnvBundleWorker = new ApplicationEnvBundleWorker(applicationEnvCrudService);
	}

	@Test
	void test_upsertApplicationEnvironments_update_ok() {
		try {

			ApplicationEnvKey key = ApplicationEnvKey.builder()
					.tenant_id(TEMPLATE_TENANT_ID)
					.key_(ENV_KEY)
					.fl_client(FL_CLIENT)
					.build();

			when(applicationEnvCrudService.findEnvironmentByKey(key)).thenReturn(applicationEnvDTO);

			applicationEnvBundleWorker.upsertApplicationEnvironments(TEMPLATE_TENANT_ID, bundleApplicationEnvMessage);
			verify(applicationEnvCrudService, times(1)).update(key, applicationEnvDTO);


		} catch (Exception e) {
			fail(e.getMessage(), e);
		}
	}

	@Test
	void test_insertApplicationEnvironments_ok() {
		try {

			ApplicationEnvKey key = ApplicationEnvKey.builder()
					.tenant_id(TEMPLATE_TENANT_ID)
					.key_(ENV_KEY)
					.fl_client(FL_CLIENT)
					.build();

			when(applicationEnvCrudService.findEnvironmentByKey(key)).thenThrow(ObjectNotFoundException.class);

			applicationEnvBundleWorker.upsertApplicationEnvironments(TEMPLATE_TENANT_ID, bundleApplicationEnvMessage);

			verify(applicationEnvCrudService, times(1)).insert(applicationEnvDTO);

		} catch (Exception e) {
			fail(e.getMessage(), e);
		}
	}

	@Test
	void test_deleteApplicationEnvironments_ok() {
		try {

			ApplicationEnvKey key = ApplicationEnvKey.builder()
					.tenant_id(TEMPLATE_TENANT_ID)
					.key_(ENV_KEY)
					.build();

			when(applicationEnvCrudService.findEnvironmentByKey(key)).thenReturn(applicationEnvDTO);

			applicationEnvBundleWorker.deleteApplicationEnvironments(TEMPLATE_TENANT_ID, bundleApplicationEnvMessage);

			verify(applicationEnvCrudService, times(1)).delete(key);

		} catch (Exception e) {
			fail(e.getMessage(), e);
		}
	}

	@Test
	void test_exposeApplicationEnvCrudServicee() {
		assertEquals(applicationEnvCrudService, applicationEnvBundleWorker.exposeApplicationEnvCrudService());
	}

}
