package com.abacogroup.agri.applications.core.services.crud;

import com.abacogroup.agri.applications.core.exceptions.ObjectNotFoundException;
import com.abacogroup.agri.applications.core.mappers.SectorMapper;
import com.abacogroup.agri.applications.core.model.dto.SectorDTO;
import com.abacogroup.agri.applications.core.services.I18NService;
import com.abacogroup.agri.applications.db.dao.SectorDAO;
import com.abacogroup.agri.applications.db.ntt.SectorNTT;
import com.abacogroup.agri.applications.db.ntt.applications.RsI18N;
import com.abacogroup.jdbi.paging.impl.InfiniteListResultsImpl;
import org.apache.commons.lang3.NotImplementedException;
import org.jdbi.v3.sqlobject.transaction.TransactionalCallback;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.Optional;

import static com.abacogroup.agri.applications.core.services.crud.SectorsCrudService.I18N_SECTORS_TABLE;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class SectorsCrudServiceTest extends AbstractCrudServiceTest {

	private static final String TENANT_ID_1 = "tenant_1";
	private static final Long CATEGORY_ID_1 = 1L;
	private static final Long SECTOR_ID = 10L;
	private static final String SECTOR_CODE_1 = "sectorCode_1";
	private static final String SECTOR_DESCRIPTION = "sector_description";
	private static final String LANG = "Language";

	private static final SectorDTO sectorInDTOMock = SectorDTO.builder()
			.sectorId(CATEGORY_ID_1)
			.sectorCode(SECTOR_CODE_1)
			.tenantId(TENANT_ID_1)
			.build();
	private static final SectorDTO sectorDTOMock = SectorDTO.builder()
			.sectorId(CATEGORY_ID_1)
			.sectorCode(SECTOR_CODE_1)
			.tenantId(TENANT_ID_1)
			.build();
	private static final SectorNTT sectorNTT = SectorNTT.builder()
			.id(CATEGORY_ID_1)
			.sector_code(SECTOR_CODE_1)
			.tenant_id(TENANT_ID_1)
			.build();

	private final RsI18N rsI18NMock = RsI18N.builder()
			.tenant_id(TENANT_ID_1)
			.i18n_text("text")
			.i18n_value("value")
			.field_name("field_name")
			.table_name("table_name")
			.lang("lang")
			.build();
	@Mock
	private SectorDAO dao;
	@Mock
	private SectorMapper sectorMapper;
	@Mock
	private I18NService i18NService;
	@InjectMocks
	private SectorsCrudService sectorsCrudService;

	@Test
	void test_hasPrimaryKey() {
		assertTrue(sectorsCrudService.hasPrimaryKey());
	}

	@Test
	void test_deleteByCustomKey() {
		assertThrows(NotImplementedException.class, () -> sectorsCrudService.deleteByCustomKey(null));
	}

	@Test
	void test_findRsByCustomKey() {
		assertEquals(Optional.empty(), sectorsCrudService.findRsByCustomKey(null));
	}

	@Test
	void test_setCustomSearchKey() {
		assertThrows(NotImplementedException.class, () -> sectorsCrudService.setCustomSearchKey(sectorNTT, null));
	}

	@SuppressWarnings({"rawtypes", "unchecked"})
	@Test
	void test_insert() {
		try {
			ArgumentCaptor<TransactionalCallback> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(TransactionalCallback.class);

			when(dao.nextSequenceVal()).thenReturn(CATEGORY_ID_1);
			when(dao.findById(CATEGORY_ID_1)).thenReturn(List.of(sectorNTT));
			when(sectorMapper.dtoToEntity(any())).thenReturn(sectorNTT);
			when(sectorMapper.entityToDto(any())).thenReturn(sectorDTOMock);

			sectorsCrudService.insert(sectorInDTOMock);

			verify(dao).inTransaction(handleConsumerLambdaCaptor.capture());

			SectorDTO SectorDTO = (SectorDTO) handleConsumerLambdaCaptor.getValue().inTransaction(dao);

			assertEquals(sectorDTOMock, SectorDTO);

		} catch (Exception e) {
			fail(e.getMessage(), e);
		}
	}

	@SuppressWarnings({"rawtypes", "unchecked"})
	@Test
	void test_update() {
		try {
			ArgumentCaptor<TransactionalCallback> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(TransactionalCallback.class);

			when(sectorMapper.dtoToEntity(any())).thenReturn(sectorNTT);
			when(sectorMapper.entityToDto(any())).thenReturn(sectorDTOMock);

			when(dao.findById(CATEGORY_ID_1)).thenReturn(List.of(sectorNTT));

			sectorsCrudService.update(CATEGORY_ID_1, sectorInDTOMock);

			verify(dao).inTransaction(handleConsumerLambdaCaptor.capture());

			SectorDTO SectorDTO = (SectorDTO) handleConsumerLambdaCaptor.getValue().inTransaction(dao);

			assertEquals(sectorDTOMock, SectorDTO);
		} catch (Exception e) {
			fail(e.getMessage(), e);
		}
	}

	@Test
	void test_delete() {
		try {
			sectorsCrudService.delete(CATEGORY_ID_1);

		} catch (Exception e) {
			fail(e.getMessage(), e);
		}
	}

	@Test
	void test_findById() {
		try {
			when(dao.findById(TENANT_ID_1, SECTOR_ID))
					.thenReturn(List.of(sectorNTT));
			when(sectorMapper.entityToDto(sectorNTT))
					.thenReturn(sectorDTOMock);

			SectorDTO result = sectorsCrudService.findById(TENANT_ID_1, SECTOR_ID);

			assertEquals(sectorDTOMock, result);
		} catch (Exception e) {
			fail(e);
		}
	}

	@Test
	void test_findById_ko() {
		try {
			when(dao.findById(TENANT_ID_1, SECTOR_ID))
					.thenReturn(List.of());

			assertThrows(ObjectNotFoundException.class, () ->
					sectorsCrudService.findById(TENANT_ID_1, SECTOR_ID));
		} catch (Exception e) {
			fail(e);
		}
	}

	@Test
	void test_findSectorsByTenant() {
		try {
			when(dao.findAllSectors(TENANT_ID_1)).thenReturn(List.of(sectorNTT));
			when(sectorMapper.entityToDto(any())).thenReturn(sectorDTOMock);
			assertEquals(List.of(sectorDTOMock), sectorsCrudService.findAllSectors(TENANT_ID_1));
		} catch (Exception e) {
			fail(e.getMessage(), e);
		}
	}

	@Test
	void test_findInfiniteSectorsByTenant_ok() {
		try {
			when(dao.infinite(any(), any(), anyInt())).thenReturn(new InfiniteListResultsImpl<>(List.of(sectorNTT), null));
			when(sectorMapper.entityToDto(any())).thenReturn(sectorDTOMock);
			assertEquals(List.of(sectorDTOMock),
					sectorsCrudService.findInfiniteAllSectors(TENANT_ID_1, null).getRecords());
		} catch (Exception e) {
			fail(e.getMessage(), e);
		}
	}

	@Test
	void test_findSectorByCode_ok() {
		try {
			when(dao.findByCode(TENANT_ID_1, SECTOR_CODE_1)).thenReturn(List.of(sectorNTT));
			when(sectorMapper.entityToDto(any())).thenReturn(sectorDTOMock);
			assertEquals(sectorDTOMock, sectorsCrudService.findSectorByCode(TENANT_ID_1, SECTOR_CODE_1));
		} catch (Exception e) {
			fail(e.getMessage(), e);
		}
	}

	@Test
	void test_insertSectorI18N_ok() {
		sectorsCrudService.insertSectorI18N(TENANT_ID_1, SECTOR_CODE_1, LANG, SECTOR_DESCRIPTION);
		verify(i18NService).insertI18N(TENANT_ID_1, I18N_SECTORS_TABLE, SectorsCrudService.SECTOR_I18N.SECTOR_CODE.getCode(), LANG,
				SECTOR_CODE_1,
				SECTOR_DESCRIPTION);
	}

	@Test
	void test_deleteModuleI18N_ok() {
		sectorsCrudService.deleteModuleI18N(TENANT_ID_1, SECTOR_CODE_1, LANG);

		verify(i18NService, times(1))
				.deleteI18N(TENANT_ID_1, I18N_SECTORS_TABLE, SectorsCrudService.SECTOR_I18N.SECTOR_CODE.getCode(), SECTOR_CODE_1, LANG);
	}

	@Test
	void test_getAllSectorI18NByTenantAndCode_ok() {
		when(i18NService.getAllI18NbyCode(TENANT_ID_1, I18N_SECTORS_TABLE, SECTOR_CODE_1))
				.thenReturn(List.of(rsI18NMock));

		List<RsI18N> result = sectorsCrudService.getAllSectorI18NByTenantAndCode(TENANT_ID_1, SECTOR_CODE_1);

		assertEquals(List.of(rsI18NMock), result);
	}
}
