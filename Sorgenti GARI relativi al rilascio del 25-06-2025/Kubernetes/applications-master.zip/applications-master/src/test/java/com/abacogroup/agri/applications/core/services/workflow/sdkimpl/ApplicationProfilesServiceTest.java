package com.abacogroup.agri.applications.core.services.workflow.sdkimpl;

import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.jdbi.v3.core.HandleConsumer;
import org.jdbi.v3.core.Jdbi;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.abacogroup.agri.applications.core.exceptions.ProfileCodeNotExistsRuntimeException;
import com.abacogroup.agri.applications.core.model.dto.ApplicationProfileDTO;
import com.abacogroup.agri.applications.core.model.dto.publics.ApplicationWithDetailsDTO;
import com.abacogroup.agri.applications.core.services.crud.ApplicationProfilesCrudService;
import com.abacogroup.agri.applications.core.services.crud.ApplicationsCrudService;
import com.abacogroup.agri.applications.core.services.crud.CrudServiceContainer;
import com.abacogroup.agri.applications.core.services.crud.ModuleProfilesCrudService;
import com.abacogroup.applicationworkflowsdk.model.io.output.ModuleProfileDTO;
import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.jdbi.paging.impl.InfiniteListResultsImpl;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@ExtendWith(MockitoExtension.class)
class ApplicationProfilesServiceTest {

	@Mock
	private Jdbi jdbi;
	@Mock
	private ApplicationsCrudService applicationsCrudService;
	@Mock
	private ApplicationProfilesCrudService applicationProfilesCrudService;
	@Mock
	private ModuleProfilesCrudService moduleProfilesCrudService;

	private ApplicationProfilesService applicationProfilesService;

	private static final String TENANT_1 = "tenant_1";
	private static final Long APPLICATION_ID_1 = 30L;
	private static final Long MODULE_ID_1 = 1L;
	private static final String USER_1 = "user_1";
	private static final User logged_user1 = new User(USER_1, TENANT_1);
	private static final String PROFILE_CODE_1 = "code1";
	private static final String PROFILE_CODE_2 = "code2";
	private static final Long PK_ID_1 = 1L;

	private static final ModuleProfileDTO moduleProfileDTO = ModuleProfileDTO.builder()
			.profileCode(PROFILE_CODE_1)
			.moduleId(MODULE_ID_1)
			.pkid(PK_ID_1)
			.build();

	@BeforeEach
	protected void init() {
		CrudServiceContainer crudServiceContainer = CrudServiceContainer.builder()
				.applicationsCrudService(applicationsCrudService)
				.applicationProfilesCrudService(applicationProfilesCrudService)
				.moduleProfilesCrudService(moduleProfilesCrudService)
				.build();

		applicationProfilesService = new ApplicationProfilesService(jdbi, crudServiceContainer);
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Test
	void test_putApplicationProfile_ok() throws Exception {
		ApplicationProfileDTO applicationProfile = ApplicationProfileDTO.builder()
				.applicationId(APPLICATION_ID_1)
				.pkid(PK_ID_1)
				.profileCode(PROFILE_CODE_1)
				.build();
		ApplicationProfileDTO applicationProfileIn = ApplicationProfileDTO.builder()
				.applicationId(APPLICATION_ID_1)
				.profileCode(PROFILE_CODE_1)
				.build();

		InfiniteListResultsImpl<ApplicationProfileDTO> infiniteListResults = new InfiniteListResultsImpl<>();
		infiniteListResults.setRecords(List.of(applicationProfile));

		ApplicationWithDetailsDTO application = ApplicationWithDetailsDTO.builder()
				.applicationId(APPLICATION_ID_1)
				.moduleId(MODULE_ID_1)
				.build();

		when(applicationsCrudService.findWithDetailsByApplicationId(TENANT_1, APPLICATION_ID_1)).thenReturn(application);
		when(moduleProfilesCrudService.find(TENANT_1, MODULE_ID_1)).thenReturn(List.of(moduleProfileDTO));
		ArgumentCaptor<HandleConsumer> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(HandleConsumer.class);

		applicationProfilesService.putApplicationProfiles(TENANT_1, APPLICATION_ID_1, new ArrayList<>(List.of(PROFILE_CODE_1)), logged_user1);

		verify(jdbi).useTransaction(handleConsumerLambdaCaptor.capture());
		handleConsumerLambdaCaptor.getValue().useHandle(jdbi.open());

		verify(applicationProfilesCrudService, times(1)).bulkLogicallyDeleteByApplicationId(TENANT_1, APPLICATION_ID_1, USER_1);

		verify(applicationProfilesCrudService, times(1)).insert(applicationProfileIn, USER_1);
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Test
	void test_putApplicationProfile_profile_code_not_found_ok() {
		ApplicationProfileDTO applicationProfile = ApplicationProfileDTO.builder()
				.applicationId(APPLICATION_ID_1)
				.pkid(PK_ID_1)
				.profileCode(PROFILE_CODE_1)
				.build();

		InfiniteListResultsImpl<ApplicationProfileDTO> infiniteListResults = new InfiniteListResultsImpl<>();
		infiniteListResults.setRecords(List.of(applicationProfile));

		ApplicationWithDetailsDTO application = ApplicationWithDetailsDTO.builder()
				.applicationId(APPLICATION_ID_1)
				.moduleId(MODULE_ID_1)
				.build();

		when(applicationsCrudService.findWithDetailsByApplicationId(TENANT_1, APPLICATION_ID_1)).thenReturn(application);
		when(moduleProfilesCrudService.find(TENANT_1, MODULE_ID_1)).thenReturn(List.of(moduleProfileDTO));
		ArgumentCaptor<HandleConsumer> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(HandleConsumer.class);

		try {
			applicationProfilesService.putApplicationProfiles(TENANT_1, APPLICATION_ID_1, new ArrayList<>(List.of(PROFILE_CODE_2)), logged_user1);
			verify(jdbi).useTransaction(handleConsumerLambdaCaptor.capture());
			handleConsumerLambdaCaptor.getValue().useHandle(jdbi.open());
		} catch (Exception e) {
			assertTrue(e instanceof ProfileCodeNotExistsRuntimeException);
		}

		verify(applicationProfilesCrudService, times(1)).bulkLogicallyDeleteByApplicationId(TENANT_1, APPLICATION_ID_1, USER_1);
	}

}
