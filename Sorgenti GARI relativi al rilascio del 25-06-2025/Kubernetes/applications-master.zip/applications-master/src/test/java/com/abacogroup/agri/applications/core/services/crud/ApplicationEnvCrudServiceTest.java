package com.abacogroup.agri.applications.core.services.crud;

import com.abacogroup.agri.applications.core.mappers.ApplicationEnvMapper;
import com.abacogroup.agri.applications.core.model.dto.ApplicationEnvDTO;
import com.abacogroup.agri.applications.db.dao.ApplicationEnvDAO;
import com.abacogroup.agri.applications.db.ntt.ApplicationEnvNTT;
import com.abacogroup.agri.applications.db.ntt.compoundkeys.ApplicationEnvKey;
import lombok.extern.slf4j.Slf4j;
import org.jdbi.v3.sqlobject.transaction.TransactionalCallback;
import org.jdbi.v3.sqlobject.transaction.TransactionalConsumer;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

/**
 * The type Application env crud service test.
 * @author Carlo Sindico
 */
@Slf4j
@ExtendWith(MockitoExtension.class)
class ApplicationEnvCrudServiceTest {

    private static final String TENANT_ID = "*";
    private static final String KEY = "key";
    private static final String VALUE = "value";
    private static final Integer FL_CLIENT = 1;

    private final ApplicationEnvDTO applicationEnvDTOMock = ApplicationEnvDTO.builder()
            .tenant(TENANT_ID)
            .key(KEY)
            .value(VALUE)
            .flClient(FL_CLIENT)
            .build();

    private final ApplicationEnvNTT applicationEnvNTTMock = ApplicationEnvNTT.builder()
            .tenant_id(TENANT_ID)
            .key_(KEY)
            .value(VALUE)
            .fl_client(FL_CLIENT)
            .build();

    private final ApplicationEnvKey applicationEnvKeyMock = ApplicationEnvKey.builder()
            .tenant_id(TENANT_ID)
            .key_(KEY)
            .fl_client(FL_CLIENT)
            .build();


    private final ApplicationEnvMapper applicationEnvMapper = ApplicationEnvMapper.INSTANCE;
    @Mock
    private ApplicationEnvDAO applicationEnvDAO;
    @InjectMocks
    private ApplicationEnvCrudService applicationEnvCrudService;

    @BeforeEach
    protected void init() {
        applicationEnvCrudService = new ApplicationEnvCrudService(applicationEnvDAO, applicationEnvMapper);
    }

    @SuppressWarnings({"rawtypes", "unchecked"})
    @Test
    void test_insert() {
        try {
            ArgumentCaptor<TransactionalCallback> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(TransactionalCallback.class);
            when(applicationEnvDAO.findByKey(applicationEnvKeyMock)).thenReturn(applicationEnvNTTMock);
            applicationEnvCrudService.insert(applicationEnvDTOMock);

            verify(applicationEnvDAO).inTransaction(handleConsumerLambdaCaptor.capture());

            ApplicationEnvDTO actual = (ApplicationEnvDTO) handleConsumerLambdaCaptor.getValue().inTransaction(applicationEnvDAO);

            assertEquals(applicationEnvDTOMock, actual);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            fail(e.getMessage(), e);
        }
    }

    @SuppressWarnings({"rawtypes", "unchecked"})
    @Test
    void test_update() {
        try {
            ArgumentCaptor<TransactionalCallback> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(TransactionalCallback.class);
            when(applicationEnvDAO.findByKey(applicationEnvKeyMock)).thenReturn(applicationEnvNTTMock);
            applicationEnvCrudService.update(applicationEnvKeyMock, applicationEnvDTOMock);

            verify(applicationEnvDAO).inTransaction(handleConsumerLambdaCaptor.capture());

            handleConsumerLambdaCaptor.getValue().inTransaction(applicationEnvDAO);

            verify(applicationEnvDAO, times(1)).inTransaction(handleConsumerLambdaCaptor.capture());

            ApplicationEnvDTO actual = (ApplicationEnvDTO) handleConsumerLambdaCaptor.getValue().inTransaction(applicationEnvDAO);

            assertEquals(applicationEnvDTOMock, actual);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            fail(e.getMessage(), e);
        }
    }

    @SuppressWarnings({"rawtypes", "unchecked"})
    @Test
    void test_delete() {
        try {
            ArgumentCaptor<TransactionalConsumer> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(TransactionalConsumer.class);
            applicationEnvCrudService.delete(applicationEnvKeyMock);

            verify(applicationEnvDAO).useTransaction(handleConsumerLambdaCaptor.capture());
            handleConsumerLambdaCaptor.getValue().useTransaction(applicationEnvDAO);
            verify(applicationEnvDAO).deleteById(applicationEnvKeyMock);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            fail(e.getMessage(), e);
        }
    }

    @Test
    void test_findByEnv() {
        try {
            when(applicationEnvDAO.findByKey(applicationEnvKeyMock)).thenReturn(applicationEnvNTTMock);

            ApplicationEnvDTO result = applicationEnvCrudService.findEnvironmentByKey(applicationEnvKeyMock);

            assertEquals(applicationEnvDTOMock, result);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            fail(e.getMessage(), e);
        }
    }

    @Test
    void deleteByCustomKey_ok() {
        applicationEnvCrudService.deleteByCustomKey(applicationEnvKeyMock);

        verify(applicationEnvDAO, times(1)).deleteById(applicationEnvKeyMock);
    }

    @Test
    void setCustomSearchKey_ok() {
        ApplicationEnvNTT rs = ApplicationEnvNTT.builder()
                        .build();
        applicationEnvCrudService.setCustomSearchKey(rs, applicationEnvKeyMock);

        assertEquals(applicationEnvKeyMock.getTenant_id(), rs.getTenant_id());
        assertEquals(applicationEnvKeyMock.getKey_(), rs.getKey_());
        assertEquals(applicationEnvKeyMock.getFl_client(), rs.getFl_client());
    }

    @Test
    void findAllByTenant_ok() {
        when(applicationEnvDAO.findAll(TENANT_ID))
                .thenReturn(List.of(applicationEnvNTTMock));

        List<ApplicationEnvDTO> result = applicationEnvCrudService.findAllByTenant(TENANT_ID);

        assertEquals(List.of(applicationEnvDTOMock), result);
    }
}