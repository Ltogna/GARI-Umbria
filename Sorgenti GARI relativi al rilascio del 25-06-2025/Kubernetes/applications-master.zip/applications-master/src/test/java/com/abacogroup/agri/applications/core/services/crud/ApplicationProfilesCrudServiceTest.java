package com.abacogroup.agri.applications.core.services.crud;

import static com.abacogroup.agri.applications.utils.PagingParamsFactory.DEFAULT_PAGE_SIZE;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.fail;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.lenient;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import org.jdbi.v3.sqlobject.transaction.TransactionalCallback;
import org.jdbi.v3.sqlobject.transaction.TransactionalConsumer;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;
import org.slf4j.MDC;

import com.abacogroup.agri.applications.core.exceptions.ObjectNotFoundException;
import com.abacogroup.agri.applications.core.mappers.ApplicationProfileMapper;
import com.abacogroup.agri.applications.core.model.dto.ApplicationProfileDTO;
import com.abacogroup.agri.applications.core.services.I18NService;
import com.abacogroup.agri.applications.db.dao.ApplicationProfileDAO;
import com.abacogroup.agri.applications.db.ntt.ApplicationProfileNTT;
import com.abacogroup.jaxrsutils.filter.MDCPreFilter;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.jdbi.paging.impl.InfiniteListResultsImpl;

@ExtendWith(MockitoExtension.class)
class ApplicationProfilesCrudServiceTest extends AbstractCrudServiceTest {

	private static final String TENANT_ID_1 = "tenant_1";
	private static final Long PK_ID_1 = 1L;
	private static final String USER_ID = "user1";
	private static final String PROFILE_CODE_1 = "code1";
	private static final Long APPLICATION_ID_1 = 1L;
	private static final String APPLICATION_CODE_1 = "1L";
	private static final String LANG_1 = "pl";
	private static final String PROFILE_DESCRIPTION_1 = "profile-desc-1";

	private static final ApplicationProfileDTO applicationProfileDTO = ApplicationProfileDTO.builder()
			.profileCode(PROFILE_CODE_1)
			.applicationId(APPLICATION_ID_1)
			.build();
	private static final ApplicationProfileDTO applicationProfileDTOResult = ApplicationProfileDTO.builder()
			.profileCode(PROFILE_CODE_1)
			.applicationId(APPLICATION_ID_1)
			.pkid(PK_ID_1)
			.build();
	private static final ApplicationProfileNTT applicationProfileNTT = ApplicationProfileNTT.builder()
			.profile_code(PROFILE_CODE_1)
			.pkid(PK_ID_1)
			.application_id(APPLICATION_ID_1)
			.build();

	@Mock
	private ApplicationProfileDAO dao;
	@Spy
	private ApplicationProfileMapper applicationProfileMapper = ApplicationProfileMapper.INSTANCE;
	@Mock
	private I18NService i18NService;
	@InjectMocks
	private ApplicationProfilesCrudService applicationProfilesCrudService;

	@BeforeEach
	void beforeEach() {
		lenient().when(dao.getCurrentTimestamp()).thenAnswer($ -> LocalDateTime.now());
	}

	@Test
	void test_hasPrimaryKey() {
		assertTrue(applicationProfilesCrudService.hasPrimaryKey());
	}

	@Test
	void test_retrieveCustomKeyByResultSet() {
		assertNull(applicationProfilesCrudService.retrieveCustomKeyByResultSet(applicationProfileNTT));
	}

	@Test
	void test_findRsByCustomKey() {
		assertEquals(Optional.empty(), applicationProfilesCrudService.findRsByCustomKey(null));
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Test
	void test_insert() {
		try {
			ArgumentCaptor<TransactionalCallback> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(TransactionalCallback.class);

			when(dao.nextSequenceVal()).thenReturn(PK_ID_1);
			when(dao.findById(PK_ID_1)).thenReturn(List.of(applicationProfileNTT));

			applicationProfilesCrudService.insert(applicationProfileDTO, USER_ID);

			verify(dao).inTransaction(handleConsumerLambdaCaptor.capture());

			ApplicationProfileDTO result = (ApplicationProfileDTO) handleConsumerLambdaCaptor.getValue().inTransaction(dao);

			assertEquals(applicationProfileDTOResult, result);

		} catch (Exception e) {
			fail(e.getMessage(), e);
		}
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Test
	void test_update() {
		try {
			ArgumentCaptor<TransactionalCallback> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(TransactionalCallback.class);
			when(dao.getCurrentTimestamp())
					.thenReturn(LocalDateTime.now());
			when(dao.inTransaction(handleConsumerLambdaCaptor.capture()))
					.thenReturn(applicationProfileDTO);

			applicationProfilesCrudService.update(PK_ID_1, applicationProfileDTO, USER_ID);

			verify(dao).inTransaction(handleConsumerLambdaCaptor.capture());

			ApplicationProfileDTO result = (ApplicationProfileDTO) handleConsumerLambdaCaptor.getValue().inTransaction(dao);

			assertEquals(applicationProfileDTO, result);
		} catch (Exception e) {
			fail(e.getMessage(), e);
		}
	}

	@Test
	void test_findById() throws ObjectNotFoundException {
		when(dao.find(TENANT_ID_1, APPLICATION_CODE_1, null)).thenReturn(List.of(applicationProfileNTT));
		assertEquals(List.of(applicationProfileDTOResult), applicationProfilesCrudService.find(TENANT_ID_1, APPLICATION_CODE_1));
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Test
	void test_delete_ok() {
		try {
			ArgumentCaptor<TransactionalConsumer> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(TransactionalConsumer.class);

			applicationProfilesCrudService.delete(PK_ID_1, USER_ID);

			verify(dao).useTransaction(handleConsumerLambdaCaptor.capture());
			handleConsumerLambdaCaptor.getValue().useTransaction(dao);

			verify(dao, times(1))
					.logicallyDeleteById(eq(APPLICATION_ID_1), eq(USER_ID), any());
		} catch (Exception e) {
			fail(e.getMessage(), e);
		}
	}

	@Test
	void test_insertModuleI18N_ok() {
		applicationProfilesCrudService.insertModuleI18N(TENANT_ID_1, PROFILE_CODE_1, LANG_1, PROFILE_DESCRIPTION_1);

		verify(i18NService, times(1)).insertI18N(TENANT_ID_1, ApplicationProfilesCrudService.I18N_APPLICATION_PROFILES_TABLE,
				ApplicationProfilesCrudService.APPLICATION_PROFILES_I18N.DESCRIPTION.getCode(), LANG_1, PROFILE_CODE_1, PROFILE_DESCRIPTION_1);
	}

	@Test
	void test_findById_ok() {
		when(dao.findById(PK_ID_1)).thenReturn(List.of(applicationProfileNTT));
		when(applicationProfileMapper.entityToDto(applicationProfileNTT)).thenReturn(applicationProfileDTO);

		try {
			assertEquals(applicationProfileDTO, applicationProfilesCrudService.findById(PK_ID_1));
		} catch (ObjectNotFoundException e) {
			fail(e);
		}
	}

	@Test
	void test_findById_ko() {
		when(dao.findById(PK_ID_1)).thenReturn(List.of());

		assertThrows(ObjectNotFoundException.class, () -> applicationProfilesCrudService.findById(PK_ID_1));
	}

	@Test
	void test_bulkLogicallyDeleteByApplicationCode_ok() {
		applicationProfilesCrudService.bulkLogicallyDeleteByApplicationCode(TENANT_ID_1, APPLICATION_CODE_1, USER_ID);

		verify(dao, times(1)).bulkLogicallyDeleteByApplicationCode(TENANT_ID_1, APPLICATION_CODE_1, USER_ID);
	}

	@Test
	void test_bulkLogicallyDeleteByApplicationId_ok() {
		applicationProfilesCrudService.bulkLogicallyDeleteByApplicationId(TENANT_ID_1, APPLICATION_ID_1, USER_ID);

		verify(dao, times(1))
				.bulkLogicallyDeleteByApplicationId(TENANT_ID_1, APPLICATION_ID_1, USER_ID);
	}

	@Test
	void test_find_ok() {
		when(dao.find(TENANT_ID_1, APPLICATION_ID_1))
				.thenReturn(List.of(applicationProfileNTT));
		when(applicationProfileMapper.entityToDto(applicationProfileNTT))
				.thenReturn(applicationProfileDTO);

		List<ApplicationProfileDTO> result = applicationProfilesCrudService.find(TENANT_ID_1, APPLICATION_ID_1);

		assertEquals(List.of(applicationProfileDTO), result);
	}

	@Test
	void findAll_ok() {
		when(dao.find(TENANT_ID_1, APPLICATION_ID_1, MDC.get(MDCPreFilter.LOCALE)))
				.thenReturn(List.of(applicationProfileNTT));
		when(applicationProfileMapper.entityToDto(applicationProfileNTT))
				.thenReturn(applicationProfileDTO);

		List<ApplicationProfileDTO> result = applicationProfilesCrudService.findAll(TENANT_ID_1, APPLICATION_ID_1, MDC.get(MDCPreFilter.LOCALE));

		assertEquals(List.of(applicationProfileDTO), result);
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Test
	void test_find_infiniteList_withApplicationCode_ok() {
		InfiniteListResults<Object> infiniteListNttResults = new InfiniteListResultsImpl<>();
		((InfiniteListResultsImpl) infiniteListNttResults).setRecords(List.of(applicationProfileNTT));

		ApplicationProfileDTO expectedApplicationProfileDTO = ApplicationProfileDTO.builder()
				.applicationId(APPLICATION_ID_1)
				.pkid(PK_ID_1)
				.profileCode(PROFILE_CODE_1)
				.build();

		InfiniteListResults<ApplicationProfileDTO> expectedInfiniteListResults = new InfiniteListResultsImpl<>();
		((InfiniteListResultsImpl) expectedInfiniteListResults).setRecords(List.of(expectedApplicationProfileDTO));

		when(dao.infinite(any(), eq(null), eq(DEFAULT_PAGE_SIZE))).thenReturn(infiniteListNttResults);

		assertEquals(expectedInfiniteListResults.getRecords(), applicationProfilesCrudService.find(TENANT_ID_1, APPLICATION_CODE_1, null).getRecords());
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Test
	void test_find_infiniteList_withApplicationId_ok() {
		InfiniteListResults<Object> infiniteListNttResults = new InfiniteListResultsImpl<>();
		((InfiniteListResultsImpl) infiniteListNttResults).setRecords(List.of(applicationProfileNTT));

		ApplicationProfileDTO expectedApplicationProfileDTO = ApplicationProfileDTO.builder()
				.applicationId(APPLICATION_ID_1)
				.pkid(PK_ID_1)
				.profileCode(PROFILE_CODE_1)
				.build();

		InfiniteListResults<ApplicationProfileDTO> expectedInfiniteListResults = new InfiniteListResultsImpl<>();
		((InfiniteListResultsImpl) expectedInfiniteListResults).setRecords(List.of(expectedApplicationProfileDTO));

		when(dao.infinite(any(), eq(null), eq(DEFAULT_PAGE_SIZE))).thenReturn(infiniteListNttResults);

		assertEquals(expectedInfiniteListResults.getRecords(), applicationProfilesCrudService.find(TENANT_ID_1, APPLICATION_ID_1, null, null).getRecords());
	}

	/*
	 * public InfiniteListResults<ApplicationProfileDTO> find(String tenant, String applicationCode, String nextKey) {
	 * log.info("Invoking findCategoryByTenantAndCode with params tenant: {} sectorCode: {}", tenant, applicationCode); return returnInfiniteResults(
	 * this.dao.infinite(() -> ((ApplicationProfileDAO) this.dao).findInfinite(tenant, applicationCode, MDC.get(MDCPreFilter.LOCALE)), nextKey,
	 * DEFAULT_PAGE_SIZE ), mapper::entityToDto); }
	 *
	 * protected <Y, A> InfiniteListResults<A> returnInfiniteResults(InfiniteListResults<Y> infiniteListResults, Function<Y, A> customMapper) { return new
	 * InfiniteListResultsImpl<>( infiniteListResults.getRecords() .stream() .map(customMapper) .collect(Collectors.toList()),
	 * infiniteListResults.getNextKey()); }
	 *
	 */
}
