package com.abacogroup.agri.applications.bundles.processor.anomaly;

import com.abacogroup.agri.applications.bundles.model.I18nPair;
import com.abacogroup.agri.applications.bundles.model.anomaly.BundleAnomalyCatalogInDTO;
import com.abacogroup.agri.applications.bundles.model.anomaly.BundleAnomalyCatalogMessage;
import com.abacogroup.bundles.listener.configdata.ConfigDataMessage;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.jdbi.v3.core.Jdbi;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import java.util.List;
import static org.mockito.Mockito.mock;

/**
 * The type Bundle anomaly catalog processor test.
 * @author Carlo Sindico
 */
@Slf4j
@ExtendWith(MockitoExtension.class)
public class BundleAnomalyCatalogProcessorTest {

    private static final String TEMPLATE_TENANT_ID = "*";

    private static final String ANOMALY_CODE = "anomaly_code";

    private static final Long MODULE_ID = 1L;

    private static final String MODULE_CODE = "module_code";

    private static final String SEVERITY = "severity";


    private final I18nPair i18nPairMock = I18nPair.builder()
            .lang("lang")
            .description("lang")
            .build();

    private final BundleAnomalyCatalogInDTO bundleAnomalyCatalogInDTOMock = BundleAnomalyCatalogInDTO.builder()
            .anomalyCode(ANOMALY_CODE)
            .moduleCode(MODULE_CODE)
            .severity(SEVERITY)
            .i18n(List.of(i18nPairMock))
            .build();
    private final BundleAnomalyCatalogMessage bundleAnomalyCatalogMessageMock = BundleAnomalyCatalogMessage.builder()
            .anomalies(List.of(bundleAnomalyCatalogInDTOMock))
            .build();

    @Mock
    private Jdbi jdbi;

    @Mock
    private ObjectMapper objectMapper;

    @Mock
    private AnomalyCatalogBundleWorker anomalyCatalogBundleWorker;

    @InjectMocks
    private BundleAnomalyCatalogProcessor bundleAnomalyCatalogProcessor;

    @BeforeEach
    void init() {
        bundleAnomalyCatalogProcessor = new BundleAnomalyCatalogProcessor(objectMapper, anomalyCatalogBundleWorker, jdbi);
    }

    @Test
    void test_onMessageInTransaction() {
        try {
            bundleAnomalyCatalogProcessor.onMessageInTransaction(mock(ConfigDataMessage.class));
        } catch (Exception e) {
            Assertions.fail();
        }
    }

    @Test
    void test_delete() {
        try {
            bundleAnomalyCatalogProcessor.delete(TEMPLATE_TENANT_ID, bundleAnomalyCatalogMessageMock);
        } catch (Exception e) {
            Assertions.fail();
        }
    }

    @Test
    void test_getDomain() {
        String result = bundleAnomalyCatalogProcessor.getDomainName();

        Assertions.assertNotNull(result);
    }


    @Test
    void test_doInsertOrUpdate() {
        try {
            bundleAnomalyCatalogProcessor.doInsertOrUpdate(TEMPLATE_TENANT_ID, bundleAnomalyCatalogMessageMock);
        } catch (Exception e) {
            Assertions.fail();
        }
    }

}
