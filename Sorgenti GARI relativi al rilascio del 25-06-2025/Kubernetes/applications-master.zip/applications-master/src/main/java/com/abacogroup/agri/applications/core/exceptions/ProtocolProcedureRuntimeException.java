package com.abacogroup.agri.applications.core.exceptions;

import io.swagger.v3.oas.annotations.media.Schema;

import jakarta.ws.rs.core.Response;

public class ProtocolProcedureRuntimeException extends AbstractException {

	private static final ProtocolProcedureRuntimeException.ErrorBody BODY = new ProtocolProcedureRuntimeException.ErrorBody();

	public ProtocolProcedureRuntimeException(String message) {
		super(Response.Status.INTERNAL_SERVER_ERROR, BODY, message);
	}

	@Schema(name = "ProtocolProcedureRuntimeExceptionErrorBody")
	public static class ErrorBody implements ExceptionErrorBody {
		private static final String ERR = "PROTOCOL_PROCEDURE_ERROR";

		@Override
		@Schema(allowableValues = ERR)
		public String getErrorCode() {
			return ERR;
		}
	}
}
