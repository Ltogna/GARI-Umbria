package com.abacogroup.agri.applications.core.services.workflow;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.SystemUtils;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;

/**
 * @author Gennaro Tamburrelli
 */
public class FileFactory {

	private static final String TEMP_FILE_PREFIX = "upload-";
	private static final String TEMP_FILE_SUFFIX = ".data";

	public File createFile(InputStream inputStream) throws IOException {
		File tempFile = File.createTempFile(TEMP_FILE_PREFIX, TEMP_FILE_SUFFIX, SystemUtils.getJavaIoTmpDir());
		FileUtils.copyInputStreamToFile(inputStream, tempFile);
		return tempFile;
	}
}
