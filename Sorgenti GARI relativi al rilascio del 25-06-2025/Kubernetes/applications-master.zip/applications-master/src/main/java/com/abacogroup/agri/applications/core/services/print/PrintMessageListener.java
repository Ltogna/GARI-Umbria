package com.abacogroup.agri.applications.core.services.print;

import java.io.IOException;
import java.util.HashMap;

import com.abacogroup.agri.applications.core.model.dto.NotifyPrintJobResponse;
import com.abacogroup.agri.applications.core.services.embededqueue.NotifyPrintEventQueue;
import org.jdbi.v3.core.Jdbi;

import com.abacogroup.agri.applications.core.model.dto.PrintJobResponse;
import com.abacogroup.agri.applications.core.model.dto.PrintJobStatus;
import com.abacogroup.agri.applications.core.services.crud.ApplicationGeneratedPrintCrudService;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.rabbitmq.client.BuiltinExchangeType;
import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.Delivery;
import com.rabbitmq.client.Envelope;

import lombok.extern.slf4j.Slf4j;

/**
 * @author Gennaro Tamburrelli
 */
@Slf4j
public class PrintMessageListener {

	private final Channel channel;
	public static final String PRINT_EXCHANGE = "print-engine-exchange";
	public static final String QUEUE_NAME = "applications-prints";
	public static final String ROUTING_KEY_TEMPLATE = "print-engine-job.%s.*";

	private final ApplicationGeneratedPrintCrudService applicationGeneratedPrintCrudService;
	private final Jdbi jdbi;
	private final NotifyPrintEventQueue notifyPrintEventQueue;

	public PrintMessageListener(Connection rabbitMQConnection, String destination, ObjectMapper objectMapper,
								ApplicationGeneratedPrintCrudService applicationGeneratedPrintCrudService, Jdbi jdbi,
								NotifyPrintEventQueue notifyPrintEventQueue) throws IOException {
		this.channel = rabbitMQConnection.createChannel();
		this.applicationGeneratedPrintCrudService = applicationGeneratedPrintCrudService;
		this.jdbi = jdbi;
		this.notifyPrintEventQueue = notifyPrintEventQueue;

		this.channel.exchangeDeclare(PRINT_EXCHANGE, BuiltinExchangeType.TOPIC, true);

		String routingKey = String.format(ROUTING_KEY_TEMPLATE, destination);
		this.channel.queueDeclare(QUEUE_NAME, true, false, false, new HashMap<>());
		this.channel.queueBind(QUEUE_NAME, PRINT_EXCHANGE, routingKey);

		this.channel.basicQos(1);
		this.channel.basicConsume(QUEUE_NAME, false, (consumerTag, delivery) -> {
			handlePrintMessage(objectMapper, delivery);
		}, consumerTag -> {
		});
	}

	private void handlePrintMessage(ObjectMapper objectMapper, Delivery delivery) throws IOException {
		Envelope envelope = delivery.getEnvelope();
		String routingKey = envelope.getRoutingKey();
		long deliveryTag = envelope.getDeliveryTag();
		log.info("[PRINT-LISTENER] received message with routing key '{}'", routingKey);

		try {
			PrintJobResponse res = objectMapper.readValue(delivery.getBody(), PrintJobResponse.class);
			log.info("[PRINT-LISTENER] obtained message {}", res);
			jdbi.useTransaction(handle -> {
				var appPrint = this.applicationGeneratedPrintCrudService.findByUuid(res.getUuid());
				if (appPrint == null) {
					log.warn("[PRINT-LISTENER] print not found for message: {}", res);
				} else {
					if (res.getStatus().equals(PrintJobStatus.READY)) {
						appPrint.setFileId(res.getFileStoreId());
						appPrint.setPrintStatus(PrintJobStatus.READY.name());
						log.info("[PRINT-LISTENER] updated file id");
					} else if (res.getStatus().equals(PrintJobStatus.ERROR)) {
						appPrint.setPrintStatus(PrintJobStatus.ERROR.name());
						log.info("[PRINT-LISTENER] has error...");
					}
					this.applicationGeneratedPrintCrudService.update(appPrint.getPkid(), appPrint);
					notifyPrintEventQueue.add(NotifyPrintJobResponse.builder()
									.generatedPrint(appPrint)
									.applicationId(appPrint.getApplicationId())
									.build(),
							System.currentTimeMillis());
				}
			});

			this.channel.basicAck(deliveryTag, false);

			log.info("[PRINT-LISTENER] processed message with routing key '{}'", routingKey);
			log.trace("[PRINT-LISTENER] channel: {}", channel.getChannelNumber());
		} catch (Exception e) {
			log.warn("[PRINT-LISTENER] Got error during consumption of with routing key: " + routingKey, e);
			this.channel.basicNack(deliveryTag, false, false);
		}
	}

}
