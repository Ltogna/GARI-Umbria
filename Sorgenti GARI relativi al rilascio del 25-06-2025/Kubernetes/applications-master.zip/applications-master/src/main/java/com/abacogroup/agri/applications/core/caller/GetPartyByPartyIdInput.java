package com.abacogroup.agri.applications.core.caller;

import com.abacogroup.applicationsupport.model.io.callerinput.companyfile.BaseCompanyFileInput;
import com.abacogroup.jaxrsutils.callerv2.ICallerInput;

import jakarta.validation.constraints.NotNull;

import java.util.Collections;
import java.util.Map;
import java.util.Objects;

/**
 * @author Alexandru Paraschiv
 */
public class GetPartyByPartyIdInput extends BaseCompanyFileInput implements ICallerInput {

	private final String resourceUrl;

	public GetPartyByPartyIdInput(@NotNull String tenant, @NotNull Long partyId, @NotNull String authToken,
			@NotNull String resourceUrl) {
		super(tenant, partyId, authToken, resourceUrl);
		this.resourceUrl = resourceUrl;
	}

	@Override
	public Map<String, Object> getPathVariablesMap() {
		return Map.of("TENANT", this.tenant,
				"PARTY_ID", this.partyId);
	}

	@Override
	public String provideAuthToken() {
		return this.authToken;
	}

	@Override
	public Map<String, Object> getQueryParamsMap() {
		return Collections.emptyMap();
	}

	@Override
	public String getUrl() {
		return this.resourceUrl;
	}

	@Override
	public String getHttpMethod() {
		return "GET";
	}

	@Override
	public boolean equals(Object o) {
		if (this == o)
			return true;
		if (!(o instanceof GetPartyByPartyIdInput))
			return false;

		GetPartyByPartyIdInput getPartiesInput = (GetPartyByPartyIdInput) o;

		return Objects.equals(tenant, getPartiesInput.tenant) &&
				Objects.equals(partyId, getPartiesInput.partyId);
	}

	@Override
	public int hashCode() {
		return Objects.hash(tenant, partyId);
	}
}
