package com.abacogroup.agri.applications.core.model.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true) // tolerate foreign APIs evolution
public class CalculationJobResponse {

	private String uuid;
	private CalculationJobStatus status;
	private String dest;
}
