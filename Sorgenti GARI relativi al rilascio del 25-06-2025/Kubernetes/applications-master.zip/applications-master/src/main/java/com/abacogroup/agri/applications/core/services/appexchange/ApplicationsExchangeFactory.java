package com.abacogroup.agri.applications.core.services.appexchange;

import com.abacogroup.embeddedqueue.QueueErrorListener;
import com.abacogroup.embeddedqueue.db.JdbiRepository;
import com.abacogroup.embeddedqueue.rabbitmq.RabbitMqPublisher;
import com.abacogroup.embeddedqueue.rabbitmq.RabbitMqPublisherWorkQueue;
import com.codahale.metrics.MetricRegistry;
import com.rabbitmq.client.Connection;

import java.io.IOException;
import java.util.function.Function;

import static com.abacogroup.embeddedqueue.QueueErrorListener.ErrorAction.RESCHEDULE;

/**
 * @author Gennaro Tamburrelli
 */
public class ApplicationsExchangeFactory<T> {

    private ApplicationsExchangeFactory() {
    }

    public static final String EVENT_KEY = "app-topic";
    public static final String EXCHANGE_NAME = "applications-exchange";

    private static <T> RabbitMqPublisher<T> getConsumer(Connection connection, Function<T, String> routingKeySupplier) throws IOException {
        return new RabbitMqPublisher<>(connection) {
            @Override
            protected String getExchangeName() {
                return EXCHANGE_NAME;
            }

            @Override
            protected String getRoutingKey(T payload) {
                return routingKeySupplier.apply(payload);
            }
        };
    }

    private static final QueueErrorListener<?> handleError = (appParams, exp) -> {
        return RESCHEDULE;
    };

    public static <T> RabbitMqPublisherWorkQueue<T> getQueue(JdbiRepository repo, MetricRegistry registry,
                                                             Connection connection,
                                                             Class<T> clazz,
                                                             Function<T, String> routingKeySupplier) throws IOException {
        return RabbitMqPublisherWorkQueue.builder(EVENT_KEY, repo, clazz)
                .withConsumer(getConsumer(connection, routingKeySupplier))
                .withErrorListener((QueueErrorListener<T>) handleError)
                .withMetricsRegistry(registry)
                .build();
    }
}
