package com.abacogroup.agri.applications.core.services;

import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.function.Function;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;

import com.abacogroup.agri.applications.core.exceptions.ObjectNotFoundException;
import com.abacogroup.agri.applications.core.exceptions.ObjectNotFoundRuntimeException;
import com.abacogroup.agri.applications.core.mappers.FormGroupPublicMapper;
import com.abacogroup.agri.applications.core.mappers.PrintDetailsOutMapper;
import com.abacogroup.agri.applications.core.model.dto.FormCatalogDTO;
import com.abacogroup.agri.applications.core.model.dto.FormGroupDTO;
import com.abacogroup.agri.applications.core.model.dto.ModuleCalculationConfigProfileDTO;
import com.abacogroup.agri.applications.core.model.dto.ModuleCalculationConfigsDTO;
import com.abacogroup.agri.applications.core.model.dto.ModuleDTO;
import com.abacogroup.agri.applications.core.model.dto.ModuleFormConfigParamDTO;
import com.abacogroup.agri.applications.core.model.dto.ModuleFormConfigProfileDTO;
import com.abacogroup.agri.applications.core.model.dto.ModuleFormConfigsDTO;
import com.abacogroup.agri.applications.core.model.dto.ModulePrintConfigParamDTO;
import com.abacogroup.agri.applications.core.model.dto.ModulePrintConfigProfileDTO;
import com.abacogroup.agri.applications.core.model.dto.ModulePrintConfigsDTO;
import com.abacogroup.agri.applications.core.model.dto.publics.LastPrintDTO;
import com.abacogroup.agri.applications.core.model.dto.publics.ModuleFormConfigsPublicDTO;
import com.abacogroup.agri.applications.core.model.dto.publics.ModuleWithParamsPublicDTO;
import com.abacogroup.agri.applications.core.model.dto.publics.PrintDetailsOutDTO;
import com.abacogroup.agri.applications.core.services.crud.ApplicationCompileStatusCrudService;
import com.abacogroup.agri.applications.core.services.crud.ApplicationGeneratedPrintCrudService;
import com.abacogroup.agri.applications.core.services.crud.CrudServiceContainer;
import com.abacogroup.agri.applications.core.services.crud.FormCatalogsCrudService;
import com.abacogroup.agri.applications.core.services.crud.FormGroupsCrudService;
import com.abacogroup.agri.applications.core.services.crud.ModuleCalculationConfigProfilesCrudService;
import com.abacogroup.agri.applications.core.services.crud.ModuleCrudService;
import com.abacogroup.agri.applications.core.services.crud.ModuleFormConfigParamCrudService;
import com.abacogroup.agri.applications.core.services.crud.ModuleFormConfigProfilesCrudService;
import com.abacogroup.agri.applications.core.services.crud.ModuleFormConfigsCrudService;
import com.abacogroup.agri.applications.core.services.crud.ModulePrintConfigParamCrudService;
import com.abacogroup.agri.applications.core.services.crud.ModulePrintConfigProfilesCrudService;
import com.abacogroup.agri.applications.core.services.crud.ModulePrintConfigsCrudService;
import com.abacogroup.applicationworkflowsdk.model.io.output.ApplicationCompileStatusDTO;
import com.abacogroup.applicationworkflowsdk.model.io.output.FormDetailsPublicDTO;
import com.abacogroup.applicationworkflowsdk.model.io.output.FormGroupPublicDTO;
import com.abacogroup.applicationworkflowsdk.model.io.output.FormWithGroupHierarchyPublicDTO;

import jakarta.ws.rs.core.SecurityContext;

/**
 * @author Gennaro Tamburrelli
 */
public class FormConfigService {

	private final FormCatalogsCrudService formCatalogsCrudService;
	private final FormGroupsCrudService formGroupsCrudService;
	private final ModuleFormConfigsCrudService moduleFormConfigsCrudService;
	private final ModuleFormConfigParamCrudService moduleFormConfigParamCrudService;
	private final ModulePrintConfigsCrudService modulePrintConfigsCrudService;
	private final ModulePrintConfigParamCrudService modulePrintConfigParamCrudService;
	private final ApplicationGeneratedPrintCrudService applicationGeneratedPrintCrudService;
	private final ModuleCrudService moduleCrudService;
	private final ModuleFormConfigProfilesCrudService moduleFormConfigProfilesCrudService;
	private final ModulePrintConfigProfilesCrudService modulePrintConfigProfilesCrudService;
	private final ModuleCalculationConfigProfilesCrudService moduleCalculationConfigProfilesCrudService;

	public FormConfigService(CrudServiceContainer crudServiceContainer) {
		this.formCatalogsCrudService = crudServiceContainer.getFormCatalogsCrudService();
		this.formGroupsCrudService = crudServiceContainer.getFormGroupsCrudService();
		this.moduleFormConfigsCrudService = crudServiceContainer.getModuleFormConfigsCrudService();
		this.moduleFormConfigParamCrudService = crudServiceContainer.getModuleFormConfigParamCrudService();
		this.modulePrintConfigsCrudService = crudServiceContainer.getModulePrintConfigsCrudService();
		this.modulePrintConfigParamCrudService = crudServiceContainer.getModulePrintConfigParamCrudService();
		this.applicationGeneratedPrintCrudService = crudServiceContainer.getApplicationGeneratedPrintCrudService();
		this.moduleCrudService = crudServiceContainer.getModuleCrudService();
		this.moduleFormConfigProfilesCrudService = crudServiceContainer.getModuleFormConfigProfilesCrudService();
		this.modulePrintConfigProfilesCrudService = crudServiceContainer.getModulePrintConfigProfilesCrudService();
		this.moduleCalculationConfigProfilesCrudService = crudServiceContainer.getModuleCalculationConfigProfilesCrudService();
	}

	public List<FormWithGroupHierarchyPublicDTO> getFormsByModuleIdAndProcessStatus(String tenant, Long moduleId, String processStatus,
			List<ApplicationCompileStatusDTO> applicationCompileStatusList, List<String> profileCodeList, SecurityContext sc, String locale) {

		List<ModuleFormConfigsDTO> formConfigList = fetchFormConfigListEpuratingDuplicates(tenant, moduleId, processStatus, profileCodeList, sc);
		conditionallyForceSetReadOnly(formConfigList, moduleId, sc);

		List<FormCatalogDTO> formCatalogList = collectCatalogs(tenant, formConfigList, locale);
		List<FormGroupDTO> formGroupList = collectGroups(tenant, formConfigList);
		Map<Long, List<ModuleFormConfigParamDTO>> formParametersMap = collectParameters(tenant, formConfigList);
		return compact(formConfigList, formCatalogList, formGroupList, formParametersMap, applicationCompileStatusList);
	}

	private void conditionallyForceSetReadOnly(List<ModuleFormConfigsDTO> formConfigList, Long moduleId, SecurityContext sc) {
		formConfigList.forEach(config -> {
			var forceReadOnlyContextFunction = config.getForceReadOnlyContextFunction();
			if(forceReadOnlyContextFunction != null) {
				if (sc.isUserInRole(forceReadOnlyContextFunction)) {
					config.setFlReadOnly(1); // force read only
				}
			}
		});
	}

	private List<ModuleFormConfigsDTO> fetchFormConfigListEpuratingDuplicates(String tenant, Long moduleId, String processStatus, List<String> profileCodeList,
			SecurityContext sc) {
		List<ModuleFormConfigsDTO> result = new ArrayList<>();
		List<ModuleFormConfigsDTO> temporary = moduleFormConfigsCrudService
				.find(tenant, moduleId, processStatus, profileCodeList)
				.stream()
				.filter(x -> hasVisibilityOnContextFunction(sc, x.getContextFunction()))
				.collect(Collectors.toList());
		Function<Object, String> returnString = x -> Optional.ofNullable(x).map(Object::toString).orElse("NULL");
		Map<String, List<ModuleFormConfigsDTO>> toRemove = temporary.stream()
				.collect(Collectors.groupingBy(x -> List.of(
						returnString.apply(x.getModuleId()),
						returnString.apply(x.getFormId()),
						returnString.apply(x.getProcessStatus()),
						returnString.apply(x.getCompileStatusIdentifier()))
						.stream()
						.map(String::valueOf)
						.collect(Collectors.joining("."))));

		toRemove.forEach((key, val) -> {
			if (val.size() == 1) {
				result.add(val.get(0));
			} else {
				val.stream()
						.filter(x -> !StringUtils.isAllBlank(x.getContextFunction()))
						.filter(x -> {
							var hasContextFunction = Optional.ofNullable(sc)
									.map(xsc -> {
										try {
											return xsc.isUserInRole(x.getContextFunction());
										} catch (Exception e) {
											return false;
										}
									})
									.orElse(false);
							return Boolean.TRUE.equals(hasContextFunction);
						})
						.filter(x -> this.checkForModuleFormConfigProfiles(tenant, x, profileCodeList))
						.forEach(x -> {
							if (result.stream().noneMatch(y -> y.getModuleId().equals(x.getModuleId()) &&
									y.getFormId().equals(x.getFormId()) &&
									y.getProcessStatus().equals(x.getProcessStatus()) &&
									((y.getCompileStatusIdentifier() == null && x.getCompileStatusIdentifier() == null) ||
									 (y.getCompileStatusIdentifier() != null && y.getCompileStatusIdentifier().equals(x.getCompileStatusIdentifier())) &&
									y.getContextFunction().equals(x.getContextFunction())))) {
								result.add(x);
							}
						});

				val.stream()
						.filter(x -> StringUtils.isAllBlank(x.getContextFunction()))
						.filter(x -> checkForModuleFormConfigProfiles(tenant, x, profileCodeList))
						.forEach(x -> {
							if (result.stream().noneMatch(y -> y.getModuleId().equals(x.getModuleId()) &&
									y.getFormId().equals(x.getFormId()) &&
									y.getProcessStatus().equals(x.getProcessStatus()) &&
									((y.getCompileStatusIdentifier() == null && x.getCompileStatusIdentifier() == null) ||
											(y.getCompileStatusIdentifier() != null && y.getCompileStatusIdentifier().equals(x.getCompileStatusIdentifier()))))) {
								result.add(x);
							}
						});
			}
		});
		result.forEach(formConfig -> {
			formConfig.setRequiredProfiles(moduleFormConfigProfilesCrudService.find(tenant, formConfig.getId())
					.stream()
					.map(ModuleFormConfigProfileDTO::getRequiredProfileCode)
					.collect(Collectors.toList()));
		});

		return result;
	}

	private static boolean hasVisibilityOnContextFunction(SecurityContext sc, String contextFunction) {
		return StringUtils.isAllBlank(contextFunction) ||
				Optional.ofNullable(sc)
						.map(xsc -> xsc.isUserInRole(contextFunction)) // consent to see form if has read only context function
						.orElse(true);
	}

	private static boolean hasVisibilityOnReadOnlyContextFunction(SecurityContext sc, String contextFunction) {
		return StringUtils.isNotBlank(contextFunction) &&
				Optional.ofNullable(sc)
						.map(xsc -> xsc.isUserInRole(contextFunction)) // consent to see form if has read only context function
						.orElse(false);
	}

	/*
	 * returns true if modules form config can be updated because it already contains all the required profiles false otherwise, module form config must be
	 * inserted
	 */
	public boolean checkForModuleFormConfigProfiles(String tenant, ModuleFormConfigsDTO optExistingModuleFormConfig, List<String> requiredProfiles) {
		if (Optional.ofNullable(optExistingModuleFormConfig).isPresent()) {
			List<String> savedProfiles = moduleFormConfigProfilesCrudService.find(tenant, optExistingModuleFormConfig.getId())
					.stream()
					.map(ModuleFormConfigProfileDTO::getRequiredProfileCode)
					.collect(Collectors.toList());

			return new HashSet<>(savedProfiles).containsAll(requiredProfiles) || new HashSet<>(requiredProfiles).containsAll(savedProfiles);
		}
		return true;
	}

	/*
	 * returns true if modules print config can be updated because it already contains all the required profiles false otherwise, module print must be inserted
	 */
	public boolean checkForModulePrintConfigProfiles(String tenant, ModulePrintConfigsDTO modulePrintConfigsDTO, List<String> requiredProfiles) {
		if (Optional.ofNullable(modulePrintConfigsDTO).isPresent()) {
			List<String> savedProfiles = modulePrintConfigProfilesCrudService.find(tenant, modulePrintConfigsDTO.getId())
					.stream()
					.map(ModulePrintConfigProfileDTO::getRequiredProfileCode)
					.collect(Collectors.toList());

			return savedProfiles.containsAll(Optional.ofNullable(requiredProfiles).orElseGet(Collections::emptyList));
		}
		return true;
	}

	/*
	 * returns true if modules calculation config can be updated because it already contains all the required profiles false otherwise, module calculation must
	 * be inserted
	 */
	public boolean checkForModuleCalculationConfigProfiles(String tenant, ModuleCalculationConfigsDTO moduleCalculationConfigsDTO,
			List<String> requiredProfiles) {
		if (Optional.ofNullable(moduleCalculationConfigsDTO).isPresent()) {
			List<String> savedProfiles = moduleCalculationConfigProfilesCrudService.find(tenant, moduleCalculationConfigsDTO.getId())
					.stream()
					.map(ModuleCalculationConfigProfileDTO::getRequiredProfileCode)
					.collect(Collectors.toList());

			return savedProfiles.containsAll(Optional.ofNullable(requiredProfiles).orElseGet(Collections::emptyList));
		}
		return true;
	}

	public List<PrintDetailsOutDTO> getPrintsByModuleIdAndProcessStatus(String tenant, Long applicationId, Long moduleId, String processStatus,
			List<String> profileCodeList, SecurityContext sc) {

		return modulePrintConfigsCrudService
				.find(tenant, moduleId, processStatus, profileCodeList)
				.stream()
				.filter(x -> StringUtils.isAllBlank(x.getContextFunction()) || sc.isUserInRole(x.getContextFunction()))
				.map(PrintDetailsOutMapper.INSTANCE::toPublicDTO)
				.map(x -> {
					x.setParams(modulePrintConfigParamCrudService.find(tenant, x.getPrintConfigId())
							.stream()
							.collect(Collectors
									.toMap(ModulePrintConfigParamDTO::getParameterName,
											ModulePrintConfigParamDTO::getParameterValue)));
					var lastPrint = applicationGeneratedPrintCrudService.findLastGeneratedPrintByCode(tenant, applicationId, x.getPrintCode());
					lastPrint.ifPresent(y -> x.setLastPrint(LastPrintDTO.builder()
							.printDate(y.getPrintDate())
							.fileId(y.getFileId())
							.build()));

					return x;
				})
				.collect(Collectors.toList());
	}

	private List<FormWithGroupHierarchyPublicDTO> compact(List<ModuleFormConfigsDTO> formConfigList, List<FormCatalogDTO> formCatalogList,
			List<FormGroupDTO> formGroupList, Map<Long, List<ModuleFormConfigParamDTO>> formParametersMap,
			List<ApplicationCompileStatusDTO> applicationCompileStatusList) {
		return formConfigList.stream()
				.map(form -> {
					var optRelatedCompileStatus = applicationCompileStatusList.stream()
							.filter(x -> x.getCompileStatusIdentifier().equals(form.getCompileStatusIdentifier())).findFirst();

					var relatedCompileStatus = calculateCompileStatus(optRelatedCompileStatus, form.getCompileStatusIdentifier());

					return FormWithGroupHierarchyPublicDTO.builder()
							.groups(getGroupHierarchy(formGroupList, form.getFormGroupId()))
							.formDetails(formCatalogList.stream()
									.filter(catalogForm -> catalogForm.getId().equals(form.getFormId()))
									.findFirst()
									.map(catalogForm -> FormDetailsPublicDTO.builder()
											.formConfigId(form.getId())
											.formCode(catalogForm.getFormCode())
											.formName(catalogForm.getFormCatalogDescription())
											.softwareUrl(catalogForm.getSoftwareUrl())
											.routerUrl(catalogForm.getRouterUrl())
											.flReadOnly(form.getFlReadOnly())
											.sortOrder(form.getSortOrder())
											.compileStatusIdentifier(form.getCompileStatusIdentifier())
											.compileStatus(relatedCompileStatus.getStatus())
											.params(Optional.ofNullable(formParametersMap.get(form.getId()))
													.orElseGet(Collections::emptyList)
													.stream()
													.collect(Collectors
															.toMap(ModuleFormConfigParamDTO::getParameterName,
																	ModuleFormConfigParamDTO::getParameterValue)))
											.requiredProfiles(form.getRequiredProfiles())
											.build())
									.orElse(null))
							.build();
				})
				.sorted(Comparator.comparing(x -> x.getFormDetails().getSortOrder()))
				.collect(Collectors.toList());
	}

	private ApplicationCompileStatusDTO calculateCompileStatus(Optional<ApplicationCompileStatusDTO> optRelatedCompileStatus,
			String compileStatusIdentifier) {
		Optional<String> optCompileStatusIdentifier = Optional.ofNullable(compileStatusIdentifier);
		if (optCompileStatusIdentifier.isPresent() && optRelatedCompileStatus.isPresent()) {
			return optRelatedCompileStatus.get();
		}

		if (optCompileStatusIdentifier.isPresent() && optRelatedCompileStatus.isEmpty()) {
			return ApplicationCompileStatusDTO.builder()
					.status(ApplicationCompileStatusCrudService.TO_BE_COMPILED)
					.build();
		}

		return ApplicationCompileStatusDTO.builder()
				.build();
	}

	private List<FormGroupPublicDTO> getGroupHierarchy(List<FormGroupDTO> formGroupList, Long formGroupId) {
		List<FormGroupDTO> accumulator = new ArrayList<>();
		var leaf = getElement(formGroupList, formGroupId);
		accumulator.add(leaf);
		Long currentParentId = leaf.getParentFormGroupId();
		while (currentParentId != null) {
			var parent = getElement(formGroupList, currentParentId);
			currentParentId = parent.getParentFormGroupId();
			accumulator.add(parent);
		}
		var result = accumulator.stream().map(FormGroupPublicMapper.INSTANCE::toPublic).collect(Collectors.toList());
		Collections.reverse(result);
		return result;
	}

	private FormGroupDTO getElement(List<FormGroupDTO> formGroupList, Long formGroupId) {
		return formGroupList.stream()
				.filter(x -> x.getId().equals(formGroupId))
				.findFirst()
				.orElseThrow(RuntimeException::new);
	}

	private Map<Long, List<ModuleFormConfigParamDTO>> collectParameters(String tenant, List<ModuleFormConfigsDTO> formConfigList) {
		return formConfigList.stream()
				.map(ModuleFormConfigsDTO::getId)
				.map(x -> moduleFormConfigParamCrudService.find(tenant, x))
				.flatMap(Collection::stream)
				.collect(Collectors.groupingBy(ModuleFormConfigParamDTO::getModuleFormConfigId));
	}

	private List<FormGroupDTO> collectGroups(String tenant, List<ModuleFormConfigsDTO> formConfigList) {
		var childrenGroupList = formConfigList.stream()
				.map(ModuleFormConfigsDTO::getFormGroupId)
				.distinct()
				.map(id -> {
					try {
						return formGroupsCrudService.findById(tenant, id);
					} catch (ObjectNotFoundException e) {
						throw new ObjectNotFoundRuntimeException(e.getMessage());
					}
				})
				.collect(Collectors.toList());
		Set<FormGroupDTO> parentsGroupSet = new HashSet<>();
		childrenGroupList.stream().forEachOrdered(l -> {
			if (l.getParentFormGroupId() != null) {
				try {
					Long parentId = l.getParentFormGroupId();
					do {
						var parent = formGroupsCrudService.findById(tenant, parentId);
						parentsGroupSet.add(parent);
						parentId = parent.getParentFormGroupId();
					} while (parentId != null);
				} catch (ObjectNotFoundException e) {
					throw new ObjectNotFoundRuntimeException(e.getMessage());
				}
			}
		});
		parentsGroupSet.addAll(childrenGroupList);
		return new ArrayList<>(parentsGroupSet);
	}

	private List<FormCatalogDTO> collectCatalogs(String tenant, List<ModuleFormConfigsDTO> formConfigList, String locale) {
		return formConfigList.stream()
				.map(ModuleFormConfigsDTO::getFormId)
				.distinct()
				.map(x -> {
					try {
						return formCatalogsCrudService.findById(tenant, x, locale);
					} catch (ObjectNotFoundException e) {
						throw new ObjectNotFoundRuntimeException(e.getMessage());
					}
				})
				.collect(Collectors.toList());
	}

	public ModuleWithParamsPublicDTO findModuleFormConfigsByModuleCode(String tenant, String moduleCode) {
		ModuleWithParamsPublicDTO moduleWithParamsPublicDTO = new ModuleWithParamsPublicDTO();
		moduleWithParamsPublicDTO.setModuleCode(moduleCode);
		List<ModuleFormConfigsPublicDTO> configs = new ArrayList<>();
		ModuleDTO moduleDTO = moduleCrudService.findByCode(tenant, moduleCode)
				.orElseThrow(() -> new ObjectNotFoundRuntimeException(MessageFormat.format("Module not found by code: {0}", moduleCode)));

		moduleFormConfigsCrudService.findAllModuleFormConfigs(tenant, moduleDTO.getModuleId()).forEach(mfc -> {
			try {
				List<ModuleFormConfigParamDTO> moduleFormConfigParamDTOList = moduleFormConfigParamCrudService.find(tenant, mfc.getId());
				mfc.setRequiredProfiles(Optional.ofNullable(moduleFormConfigProfilesCrudService.find(tenant, mfc.getId()))
						.orElseGet(Collections::emptyList)
						.stream()
						.map(ModuleFormConfigProfileDTO::getRequiredProfileCode)
						.collect(Collectors.toList()));
				configs.add(ModuleFormConfigsPublicDTO.builder()
						.compileStatusIdentifier(mfc.getCompileStatusIdentifier())
						.contextFunction(mfc.getContextFunction())
						.formConfigId(mfc.getId())
						.flReadOnly(mfc.getFlReadOnly())
						.processStatus(mfc.getProcessStatus())
						.sortOrder(mfc.getSortOrder())
						.flReadOnly(mfc.getFlReadOnly())
						.formCode(formCatalogsCrudService.findById(tenant, mfc.getFormId()).getFormCode())
						.formGroupCode(formGroupsCrudService.findById(tenant, mfc.getFormGroupId()).getFormGroupCode())
						.params(Optional.ofNullable(moduleFormConfigParamDTOList)
								.orElseGet(Collections::emptyList)
								.stream()
								.collect(Collectors
										.toMap(ModuleFormConfigParamDTO::getParameterName,
												ModuleFormConfigParamDTO::getParameterValue)))
						.requiredProfiles(mfc.getRequiredProfiles())
						.build());

			} catch (ObjectNotFoundException e) {
				throw new ObjectNotFoundRuntimeException(e.getMessage());
			}
		});
		moduleWithParamsPublicDTO.setConfigs(configs);
		return moduleWithParamsPublicDTO;
	}

}
