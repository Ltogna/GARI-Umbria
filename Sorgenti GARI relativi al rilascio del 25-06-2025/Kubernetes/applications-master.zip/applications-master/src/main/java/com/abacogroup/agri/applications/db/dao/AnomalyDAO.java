package com.abacogroup.agri.applications.db.dao;

import com.abacogroup.agri.applications.db.ntt.AnomalyNTT;
import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.customizer.BindBean;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;

import java.time.LocalDateTime;
import java.util.List;

/**
 * @author Gennaro Tamburrelli
 */
public interface AnomalyDAO extends IGenericHistoricizationFieldsDAO<AnomalyNTT, Long, Void> {

	@Override
	@SqlQuery("§select_nextval(APPS_APPLICATION_ANOMALIES_ID_SEQ)§")
	Long nextSequenceVal();

	@Override
	@SqlUpdate("INSERT INTO APPS_ANOMALIES " +
			"(pkid, " +
			"application_id, " +
			"anomaly_code, " +
			"user_id_insert, " +
			"user_id_delete, " +
			"dt_insert, " +
			"dt_delete) " +
			"VALUES(:pkid, :application_id, :anomaly_code, :user_insert, NULL, :current_timestamp, TO_TIMESTAMP('9999-12-3123:59:59','YYYY-MM-DDHH24:MI:SS'))")
	void insert(@BindBean AnomalyNTT ntt, @Bind("user_insert") String userId, @Bind("current_timestamp") LocalDateTime currentTimestamp);

	@SqlQuery("select a.pkid," +
			"  a.application_id," +
			"  a.anomaly_code," +
			"  a.dt_insert," +
			"  a.dt_delete," +
			"  a.user_id_insert," +
			"  a.user_id_delete" +
			" from APPS_ANOMALIES a" +
			" where a.pkid = :id")
	@RegisterBeanMapper(AnomalyNTT.class)
	List<AnomalyNTT> findById(@Bind("id") Long id);

	@Override
	@SqlUpdate("UPDATE APPS_ANOMALIES SET " +
			"user_id_delete = :user_id_delete, dt_delete = :current_timestamp " +
			"WHERE pkid = :id " +
			"and §current_timestamp§ between dt_insert and dt_delete")
	void logicallyDeleteById(@Bind("id") Long id, @Bind("user_id_delete") String userDelete, @Bind("current_timestamp") LocalDateTime currentTimestamp);

	@SqlQuery("select an.pkid," +
			"   an.application_id," +
			"   an.anomaly_code," +
			"   ac.severity," +
			"   §i18n(:tenant_id, 'apps_anomaly_catalog', 'anomaly_code', an.anomaly_code, :lang)§ as anomaly_desc," +
			"   an.dt_insert," +
			"   an.dt_delete," +
			"   an.user_id_insert," +
			"   an.user_id_delete" +
			" from APPS_ANOMALIES an LEFT JOIN APPS_APPLICATIONS a ON an.application_id = a.id " +
			" LEFT JOIN APPS_ANOMALY_CATALOG ac on an.anomaly_code = ac.anomaly_code " +
			" LEFT JOIN APPS_APPLICATION_DETAILS ad on ad.application_id = a.id " +
			" LEFT JOIN APPS_MODULES am on am.id = a.module_id " +
			" LEFT JOIN APPS_SECTORS s on s.id = am.sector_id " +
			" where an.application_id = :application_id " +
			" and s.tenant_id = :tenant_id " +
			" and ac.module_id = am.id " +
			" and §current_timestamp§ between an.dt_insert and an.dt_delete " +
			" and §current_timestamp§ between a.dt_insert and a.dt_delete " +
			" and §current_timestamp§ between ad.dt_insert and ad.dt_delete " +
			" and §current_timestamp§ between am.dt_insert and am.dt_delete ")
	@RegisterBeanMapper(AnomalyNTT.class)
	List<AnomalyNTT> find(@Bind("tenant_id") String tenant, @Bind("application_id") Long applicationId, @Bind("lang") String lang);

	@SqlQuery("select an.pkid," +
			"   an.application_id," +
			"   an.anomaly_code," +
			"   ac.severity," +
			"   §i18n(:tenant_id, 'apps_anomaly_catalog', 'anomaly_code', an.anomaly_code, :lang)§ as anomaly_desc," +
			"   an.dt_insert," +
			"   an.dt_delete," +
			"   an.user_id_insert," +
			"   an.user_id_delete" +
			" from APPS_ANOMALIES an INNER JOIN APPS_APPLICATIONS a ON an.application_id = a.id " +
			" INNER JOIN APPS_ANOMALY_CATALOG ac on an.anomaly_code = ac.anomaly_code " +
			" INNER JOIN APPS_APPLICATION_DETAILS ad on ad.application_id = a.id " +
			" INNER JOIN APPS_MODULES am on am.id = a.module_id " +
			" INNER JOIN APPS_SECTORS s on s.id = am.sector_id " +
			" where an.application_id = :application_id " +
			" and an.anomaly_code = :anomaly_code " +
			" and s.tenant_id = :tenant_id " +
			" and §current_timestamp§ between an.dt_insert and an.dt_delete " +
			" and §current_timestamp§ between a.dt_insert and a.dt_delete " +
			" and §current_timestamp§ between ad.dt_insert and ad.dt_delete " +
			" and §current_timestamp§ between am.dt_insert and am.dt_delete ")
	@RegisterBeanMapper(AnomalyNTT.class)
	List<AnomalyNTT> find(@Bind("tenant_id") String tenant, @Bind("application_id") Long applicationId, @Bind("anomaly_code") String anomalyCode,
			@Bind("lang") String lang);

	@SqlQuery("select an.pkid," +
			"   an.application_id," +
			"   an.anomaly_code," +
			"   §i18n(:tenant_id, 'apps_anomaly_catalog', 'anomaly_code', an.anomaly_code, :lang)§ as anomaly_desc," +
			"   an.dt_insert," +
			"   an.dt_delete," +
			"   an.user_id_insert," +
			"   an.user_id_delete" +
			" from APPS_ANOMALIES an INNER JOIN APPS_APPLICATIONS a ON an.application_id = a.id " +
			" INNER JOIN APPS_APPLICATION_DETAILS ad on ad.application_id = a.id " +
			" INNER JOIN APPS_MODULES am on am.id = a.module_id " +
			" INNER JOIN APPS_SECTORS s on s.id = am.sector_id " +
			" where an.application_id = :application_id " +
			" and an.anomaly_code = :anomaly_code " +
			" and s.tenant_id = :tenant_id " +
			" and §current_timestamp§ between an.dt_insert and an.dt_delete " +
			" and §current_timestamp§ between a.dt_insert and a.dt_delete " +
			" and §current_timestamp§ between ad.dt_insert and ad.dt_delete " +
			" and §current_timestamp§ between am.dt_insert and am.dt_delete ")
	@RegisterBeanMapper(AnomalyNTT.class)
	List<AnomalyNTT> findWithoutJoiningCatalog(@Bind("tenant_id") String tenant, @Bind("application_id") Long applicationId,
			@Bind("anomaly_code") String anomalyCode,
			@Bind("lang") String lang);
}
