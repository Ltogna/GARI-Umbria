package com.abacogroup.agri.applications.core.mappers;

import com.abacogroup.agri.applications.core.model.dto.ModuleCalculationConfigsDTO;
import com.abacogroup.agri.applications.db.ntt.ModuleCalculationConfigsNTT;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

@Mapper(uses = AbsoluteDateMapper.class)
public interface ModuleCalculationConfigsMapper extends EntityMapper<ModuleCalculationConfigsDTO, ModuleCalculationConfigsNTT> {

	ModuleCalculationConfigsMapper INSTANCE = Mappers.getMapper(ModuleCalculationConfigsMapper.class);

	@InheritInverseConfiguration()
	ModuleCalculationConfigsDTO entityToDto(ModuleCalculationConfigsNTT entity);

	@Mapping(source = "id", target = "id")
	@Mapping(source = "moduleId", target = "module_id")
	@Mapping(source = "processStatus", target = "process_status")
	@Mapping(source = "calculationCode", target = "calculation_code")
	@Mapping(source = "calculationDescription", target = "calculation_description")
	@Mapping(source = "sortOrder", target = "sort_order")
	@Mapping(source = "contextFunction", target = "context_function")
	ModuleCalculationConfigsNTT dtoToEntity(ModuleCalculationConfigsDTO dto);

}
