package com.abacogroup.agri.applications.core.model.dto;

import com.abacogroup.calculatorengine.sdk.model.render.Label;
import com.abacogroup.calculatorengine.sdk.model.render.Section;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author Alexandru Paraschiv
 */
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class CalculatorRenderResponse {
	private List<Section> sections = new ArrayList<>();

	private Map<String, Label> tagLabels = new HashMap<>();
}
