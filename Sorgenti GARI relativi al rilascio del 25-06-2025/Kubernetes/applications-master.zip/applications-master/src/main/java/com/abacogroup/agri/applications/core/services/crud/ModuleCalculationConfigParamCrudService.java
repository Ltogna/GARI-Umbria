package com.abacogroup.agri.applications.core.services.crud;

import com.abacogroup.agri.applications.core.exceptions.ObjectNotFoundException;
import com.abacogroup.agri.applications.core.mappers.ModuleCalculationConfigParamMapper;
import com.abacogroup.agri.applications.core.model.dto.ModuleCalculationConfigParamDTO;
import com.abacogroup.agri.applications.db.dao.ModuleCalculationConfigParamDAO;
import com.abacogroup.agri.applications.db.ntt.ModuleCalculationConfigParamNTT;
import com.abacogroup.agri.applications.db.ntt.compoundkeys.CalculationConfigParamKey;
import lombok.extern.slf4j.Slf4j;

import java.util.List;
import java.util.Optional;

/**
 * @author Mauro Pozzana
 */
@Slf4j
public class ModuleCalculationConfigParamCrudService
		extends AbstractCrudService<ModuleCalculationConfigParamNTT, Void, ModuleCalculationConfigParamDTO, ModuleCalculationConfigParamMapper, CalculationConfigParamKey> {

	public ModuleCalculationConfigParamCrudService(ModuleCalculationConfigParamDAO dao, ModuleCalculationConfigParamMapper mapper) {
		super(dao, mapper);
	}

	@Override
	protected boolean hasPrimaryKey() {
		return false;
	}

	@Override
	protected Void retrievePrimaryKey(CalculationConfigParamKey customKey) {
		return null;
	}

	@Override
	protected Optional<ModuleCalculationConfigParamNTT> findRsByCustomKey(CalculationConfigParamKey customKey) {
		return ((ModuleCalculationConfigParamDAO) this.dao).findById(customKey.getModule_calculation_config_id(), customKey.getParameter_name())
				.stream()
				.findFirst();
	}

	@Override
	protected void deleteByCustomKey(CalculationConfigParamKey customKey) {
		((ModuleCalculationConfigParamDAO) this.dao).deleteById(customKey.getModule_calculation_config_id(), customKey.getParameter_name());
	}

	@Override
	protected void setCustomSearchKey(ModuleCalculationConfigParamNTT rs, CalculationConfigParamKey customKey) {
		rs.setModule_calculation_config_id(customKey.getModule_calculation_config_id());
		rs.setParameter_name(customKey.getParameter_name());
	}

	public ModuleCalculationConfigParamDTO insert(ModuleCalculationConfigParamDTO in) {
		log.info("Invoking insert with params in: {}", in);
		return this.insert(in, CalculationConfigParamKey.builder()
				.module_calculation_config_id(in.getModuleCalculationConfigId())
				.parameter_name(in.getParameterName())
				.build());
	}

	public ModuleCalculationConfigParamDTO update(ModuleCalculationConfigParamDTO in) {
		log.info("Invoking update with params in: {}", in);
		return this.update(null, in, CalculationConfigParamKey.builder()
				.module_calculation_config_id(in.getModuleCalculationConfigId())
				.parameter_name(in.getParameterName())
				.build());
	}

	public void delete(CalculationConfigParamKey key) {
		log.info("Invoking delete with params key: {}", key);
		this.delete(null, key);
	}

	public void deleteByModuleCalculationConfigId(Long moduleFormConfigId) {
		((ModuleCalculationConfigParamDAO) this.dao).deleteByModuleCalculationConfigId(moduleFormConfigId);
	}

	public ModuleCalculationConfigParamDTO findById(String tenant, CalculationConfigParamKey id) throws ObjectNotFoundException {
		log.info("Invoking findById with params tenant: {} id: {}", tenant, id);
		return returnOptionalRecord(((ModuleCalculationConfigParamDAO) this.dao).findById(tenant, id.getModule_calculation_config_id(), id.getParameter_name()))
				.orElseThrow(OBJECT_NOT_FOUND_EXCEPTION_SUPPLIER);
	}

	public List<ModuleCalculationConfigParamDTO> find(String tenant, Long formConfig) {
		log.info("Invoking findById with params tenant: {} formConfigId: {}", tenant, formConfig);
		return returnMappedList(((ModuleCalculationConfigParamDAO) this.dao).find(tenant, formConfig));
	}

}
