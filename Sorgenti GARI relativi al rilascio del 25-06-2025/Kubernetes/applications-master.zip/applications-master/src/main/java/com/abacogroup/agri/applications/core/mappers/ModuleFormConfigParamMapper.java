package com.abacogroup.agri.applications.core.mappers;

import com.abacogroup.agri.applications.core.model.dto.ModuleFormConfigParamDTO;
import com.abacogroup.agri.applications.db.ntt.ModuleFormConfigParamNTT;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

@Mapper(uses = AbsoluteDateMapper.class)
public interface ModuleFormConfigParamMapper extends EntityMapper<ModuleFormConfigParamDTO, ModuleFormConfigParamNTT> {

	ModuleFormConfigParamMapper INSTANCE = Mappers.getMapper(ModuleFormConfigParamMapper.class);

	@InheritInverseConfiguration()
	ModuleFormConfigParamDTO entityToDto(ModuleFormConfigParamNTT entity);

	@Mapping(source = "moduleFormConfigId", target = "module_form_config_id")
	@Mapping(source = "parameterName", target = "parameter_name")
	@Mapping(source = "parameterValue", target = "parameter_value")
	ModuleFormConfigParamNTT dtoToEntity(ModuleFormConfigParamDTO dto);

}
