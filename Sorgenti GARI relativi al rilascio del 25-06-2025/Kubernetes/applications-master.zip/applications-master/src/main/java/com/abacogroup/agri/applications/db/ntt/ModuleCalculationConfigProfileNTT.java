package com.abacogroup.agri.applications.db.ntt;

import com.abacogroup.agri.applications.db.ntt.applications.IIdRs;
import com.abacogroup.agri.applications.db.ntt.compoundkeys.CalculationConfigProfileKey;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Optional;

/**
 * @author Mattia Perini
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ModuleCalculationConfigProfileNTT implements IIdRs<CalculationConfigProfileKey> {

    private Long module_calculation_config_id;
    private String required_profile_code;

    @Override
    public void setKey(CalculationConfigProfileKey id) {
        this.module_calculation_config_id = id.getModule_calculation_config_id();
        this.required_profile_code = id.getRequired_profile_code();
    }

    @Override
    public Optional<CalculationConfigProfileKey> getKey() {
        return Optional.of(CalculationConfigProfileKey.builder()
                .module_calculation_config_id(this.module_calculation_config_id)
                .required_profile_code(this.required_profile_code)
                .build());
    }
}
