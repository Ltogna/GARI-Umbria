package com.abacogroup.agri.applications.core.caller;

import com.abacogroup.agri.applications.core.model.CheckCanReadDTO;
import com.abacogroup.jaxrsutils.GenericCallerService;
import com.abacogroup.jaxrsutils.callerv2.AbacoDtoCaller;

/**
 * @author Gennaro Tamburrelli
 */
public class CheckCanReadPartyCaller extends AbacoDtoCaller<CheckCanReadPartyInput, CheckCanReadDTO> {

	public CheckCanReadPartyCaller(GenericCallerService genericCallerService) {
		super(genericCallerService);
	}

}
