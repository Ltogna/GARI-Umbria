package com.abacogroup.agri.applications.core.services.embededqueue;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class QueueContainer {
	private CreateProcessQueue createProcessQueue;
	private UpdateProcessQueue updateProcessQueue;
	private NotifyCalculationEventQueue notifyCalculationEventQueue;
	private NotifyPrintEventQueue notifyPrintEventQueue;
	private NotifyApplicationsEventQueue notifyApplicationsEventQueue;
	private ResetIsInTransitionProcessQueue resetIsInTransitionProcessQueue;
}
