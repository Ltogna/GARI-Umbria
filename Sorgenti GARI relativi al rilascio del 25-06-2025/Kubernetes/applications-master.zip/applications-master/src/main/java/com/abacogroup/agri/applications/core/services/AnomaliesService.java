package com.abacogroup.agri.applications.core.services;

import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

import com.abacogroup.agri.applications.core.exceptions.ApplicationNotFoundRuntimeException;
import com.abacogroup.agri.applications.core.exceptions.ObjectNotFoundException;
import com.abacogroup.agri.applications.core.exceptions.ObjectNotFoundRuntimeException;
import com.abacogroup.agri.applications.core.model.ApplicationAnomaly;
import com.abacogroup.agri.applications.core.model.dto.ApplicationDetailsDTO;
import com.abacogroup.agri.applications.core.model.dto.ModuleDTO;
import com.abacogroup.agri.applications.core.model.dto.ModuleDetailsDTO;
import com.abacogroup.agri.applications.core.services.crud.ApplicationDetailsCrudService;
import com.abacogroup.agri.applications.core.services.crud.ApplicationsCrudService;
import com.abacogroup.agri.applications.core.services.crud.CrudServiceContainer;
import com.abacogroup.agri.applications.core.services.crud.ModuleCrudService;
import com.abacogroup.agri.applications.core.services.crud.ModuleDetailsCrudService;

import lombok.extern.slf4j.Slf4j;

/**
 * @author Alexandru Paraschiv
 */
@Slf4j
public class AnomaliesService {
	private static final String PROCESS_STATUS_DELETED = "DELETED"; // TODO to be moved?
	private static final String PROCESS_STATUS_WAIVED = "WAIVED"; // TODO to be moved?

	public static final String METADATA_KEY_MULTIPLE_APPLICATIONS = "multiple-applications-allowed";
	public static final String MULTIPLE_APPLICATIONS_ERROR_CODE = "NOT_ALLOWED_MULTIPLE_APPLICATIONS_ERROR";
	public static final String MULTIPLE_APPLICATIONS_ERROR_MSG = "Multiple applications are not allowed for this application";
	public static final Boolean NOT_ALLOWED_MULTIPLE_APPLICATIONS_VALUE = false;
	public static final Boolean ALLOWED_MULTIPLE_APPLICATIONS_VALUE = true;

	public static final String MODULE_VALIDITY_EXPIRED_ERROR_CODE = "CREATING_APPLICATION_NOT_IN_VALIDITY_PERIOD_ERROR_CODE";
	public static final String MODULE_VALIDITY_EXPIRED_ERROR_MSG = "This module's validity is expired";

	public static final String NOT_AMENDMENT_MODULE_ERROR_CODE = "NOT_AMENDMENT_MODULE_ERROR_CODE";
	public static final String NOT_AMENDMENT_MODULE_ERROR_MSG = "This is not an amendment module";

	public static final String ALREADY_AMENDED_APPLICATION_ERROR_CODE = "ALREADY_AMENDED_APPLICATION_ERROR_CODE";
	public static final String ALREADY_AMENDED_APPLICATION_ERROR_MSG = "It is not possible to create a new amendment application art. 15: amendment application already exists";

	public static final String WAIVED_APPLICATION_ERROR_CODE = "WAIVED_APPLICATION_ERROR_CODE";
	public static final String WAIVED_APPLICATION_ERROR_MSG = "It is not possible to create a new amendment application art. 15: application waived";

	private final ApplicationsService applicationsService;
	private final ApplicationsCrudService applicationsCrudService;
	private final ModuleCrudService moduleCrudService;
	private final ModuleDetailsCrudService moduleDetailsCrudService;
	private final ApplicationDetailsCrudService applicationDetailsCrudService;

	public AnomaliesService(ApplicationsService applicationsService,
			CrudServiceContainer crudServiceContainer) {
		this.applicationsCrudService = crudServiceContainer.getApplicationsCrudService();
		this.moduleCrudService = crudServiceContainer.getModuleCrudService();
		this.applicationsService = applicationsService;
		this.moduleDetailsCrudService = crudServiceContainer.getModuleDetailsCrudService();
		this.applicationDetailsCrudService = crudServiceContainer.getApplicationDetailsCrudService();
	}

	public List<ApplicationAnomaly> checkForModuleDateValidity(ModuleDetailsDTO moduleDetails) {
		List<ApplicationAnomaly> anomalies = new ArrayList<>();
		if (moduleDetailsCrudService.checkValidityByPkId(moduleDetails.getPkid()) != null) {
			log.info("application can be created because today is within module's validity range");
		} else {
			anomalies.add(ApplicationAnomaly.builder()
					.code(MODULE_VALIDITY_EXPIRED_ERROR_CODE)
					.message(MODULE_VALIDITY_EXPIRED_ERROR_MSG)
					.build());
		}
		return anomalies;
	}

	public List<ApplicationAnomaly> checkForAmendmentModule(ModuleDTO module) {
		List<ApplicationAnomaly> anomalies = new ArrayList<>();

		if (Boolean.TRUE.equals(module.getFlAmendModule())) {
			log.info("Amendment application can be created because the module is of amendment");
		} else {
			anomalies.add(ApplicationAnomaly.builder()
					.code(NOT_AMENDMENT_MODULE_ERROR_CODE)
					.message(NOT_AMENDMENT_MODULE_ERROR_MSG)
					.build());
		}

		return anomalies;
	}

	public List<ApplicationAnomaly> checkForApplicationNotAmended(String tenant, Long applicationId) {
		List<ApplicationAnomaly> anomalies = new ArrayList<>();
		try {
			ApplicationDetailsDTO applicationDetails = applicationDetailsCrudService.findApplicationDetailById(tenant, applicationId);

			if (Optional.ofNullable(applicationDetails.getAmendedById()).isPresent()) {
				ApplicationDetailsDTO amendApplicationDetails = applicationDetailsCrudService
						.findApplicationDetailById(tenant, applicationDetails.getAmendedById());

				if (!PROCESS_STATUS_DELETED.equals(amendApplicationDetails.getProcessStatus())) {
					anomalies.add(ApplicationAnomaly.builder()
							.code(ALREADY_AMENDED_APPLICATION_ERROR_CODE)
							.message(ALREADY_AMENDED_APPLICATION_ERROR_MSG)
							.build());
				}
			} else {
				log.info("Amended application can be created because the application is not amended by an amendment application");
			}
		} catch (ObjectNotFoundException e) {
			throw new ApplicationNotFoundRuntimeException(MessageFormat.format("Application with id {0} not found", applicationId));
		}

		return anomalies;
	}

	public List<ApplicationAnomaly> checkForApplicationWaived(String tenant, Long applicationId) {
		List<ApplicationAnomaly> anomalies = new ArrayList<>();
		try {
			ApplicationDetailsDTO applicationDetails = applicationDetailsCrudService.findApplicationDetailById(tenant, applicationId);

			if (PROCESS_STATUS_WAIVED.equals(applicationDetails.getProcessStatus())) {
				anomalies.add(ApplicationAnomaly.builder()
						.code(WAIVED_APPLICATION_ERROR_CODE)
						.message(WAIVED_APPLICATION_ERROR_MSG)
						.build());
			} else {
				log.info("Amended application can be created because the application is not amended by an amendment application");
			}
		} catch (ObjectNotFoundException e) {
			throw new ApplicationNotFoundRuntimeException(MessageFormat.format("Application with id {0} not found", applicationId));
		}

		return anomalies;
	}

	public List<ApplicationAnomaly> checkForMultipleApplication(String tenantId, String moduleCode, Long partyId, Integer referredYear) {
		Optional<ModuleDTO> moduleDTO = moduleCrudService.findByCode(tenantId, moduleCode);
		if (moduleDTO.isEmpty()) {
			throw new ObjectNotFoundRuntimeException(MessageFormat.format("Module not found by tenant: {0} code: {1}", tenantId, moduleCode));
		}

		return this.checkForMultipleApplication(tenantId, moduleDTO.get(), partyId, referredYear, null);

	}

	public List<ApplicationAnomaly> checkForMultipleApplication(String tenantId, ModuleDTO moduleDTO, Long partyId, Integer referredYear,
			Long applicationId) {
		return applicationsCrudService.findAllByModuleIdAndPartyIdAndReferredYear(tenantId, moduleDTO.getModuleId(), partyId, referredYear)
				.stream()
				.filter(x -> applicationId == null || !x.getApplicationId().equals(applicationId))
				.map(app -> {
					Map<String, Object> appMetadata = applicationsService.checkForMetadata(tenantId, app);
					if (appMetadata.containsKey(METADATA_KEY_MULTIPLE_APPLICATIONS) && appMetadata.get(METADATA_KEY_MULTIPLE_APPLICATIONS)
							.equals(NOT_ALLOWED_MULTIPLE_APPLICATIONS_VALUE)) {
						return ApplicationAnomaly.builder()
								.code(MULTIPLE_APPLICATIONS_ERROR_CODE)
								.message(MULTIPLE_APPLICATIONS_ERROR_MSG)
								.build();
					} else {
						return null;
					}
				})
				.filter(Objects::nonNull)
				.collect(Collectors.toList());
	}

}
