package com.abacogroup.agri.applications.core.model.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

/**
 * @author Mauro Pozzana
 */
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class ModuleCalculationConfigParamDTO {
	private Long moduleCalculationConfigId;
	private String parameterName;
	private String parameterValue;

}
