package com.abacogroup.agri.applications.db.ntt.compoundkeys;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author Mauro Pozzana
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class CalculationConfigParamKey {

	private Long module_calculation_config_id;
	private String parameter_name;
}
