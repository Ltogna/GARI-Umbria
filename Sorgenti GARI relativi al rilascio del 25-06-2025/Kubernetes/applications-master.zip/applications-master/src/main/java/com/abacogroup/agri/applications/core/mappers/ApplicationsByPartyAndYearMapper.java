package com.abacogroup.agri.applications.core.mappers;

import com.abacogroup.agri.applications.core.model.dto.publics.AppByPartyAndYearDTO;
import com.abacogroup.agri.applications.db.ntt.ApplicationByPartyAndYearNTT;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

@Mapper(uses = AbsoluteDateMapper.class)
public interface ApplicationsByPartyAndYearMapper extends EntityMapper<AppByPartyAndYearDTO, ApplicationByPartyAndYearNTT> {

	ApplicationsByPartyAndYearMapper INSTANCE = Mappers.getMapper(ApplicationsByPartyAndYearMapper.class);

	@InheritInverseConfiguration()
	AppByPartyAndYearDTO entityToDto(ApplicationByPartyAndYearNTT entity);

	@Mapping(source = "partyId", target = "party_id")
	@Mapping(source = "year", target = "referred_year")
	@Mapping(source = "sectorCode", target = "sector_code")
	@Mapping(source = "sectorDescription", target = "sector_description")
	@Mapping(source = "moduleCode", target = "module_code")
	@Mapping(source = "moduleDescription", target = "module_description")
	@Mapping(source = "applicationCode", target = "application_code")
	@Mapping(source = "applicationId", target = "application_id")
	@Mapping(source = "processStatus", target = "process_status")
	@Mapping(source = "processId", target = "process_id")
	@Mapping(source = "dtPresentation", target = "dt_presentation")
	@Mapping(source = "dtProtocol", target = "dt_protocol")
	@Mapping(source = "amendedById", target = "amended_by_id")
	@Mapping(source = "amendOfId", target = "amend_of_id")
	@Mapping(source = "protocol", target = "protocol")
	ApplicationByPartyAndYearNTT dtoToEntity(AppByPartyAndYearDTO dto);

}
