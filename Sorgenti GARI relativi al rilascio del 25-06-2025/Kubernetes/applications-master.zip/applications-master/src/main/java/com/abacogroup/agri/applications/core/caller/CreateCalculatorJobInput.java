package com.abacogroup.agri.applications.core.caller;

import static com.abacogroup.jaxrsutils.GenericCallerService.POST_METHOD;

import java.util.HashMap;
import java.util.Map;

import com.abacogroup.jaxrsutils.callerv2.ICallerInput;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author Alexandru Paraschiv
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class CreateCalculatorJobInput implements ICallerInput {

	private String url;
	private String tenant;
	private String destination;
	private String calculatorCode;
	private String token;
	private String locale;

	@Builder.Default
	private Map<String, Object> params = new HashMap<>();

	@Override
	public Object providePayload() {
		return params;
	}

	@Override
	public Map<String, Object> getPathVariablesMap() {
		return Map.of("TENANT_ID", this.tenant,
				"CALCULATOR_TYPE_NAME", this.calculatorCode);
	}

	@Override
	public Map<String, Object> getQueryParamsMap() {
		return Map.of("dest", this.destination);
	}

	@Override
	public String provideAuthToken() {
		return this.token;
	}

	@Override
	public String getUrl() {
		return this.url + "/{TENANT_ID}/public/v1/{CALCULATOR_TYPE_NAME}";
	}

	@Override
	public String getHttpMethod() {
		return POST_METHOD;
	}

	@Override
	public String locale() {
		return this.locale;
	}
}
