package com.abacogroup.agri.applications.core.services.workflow;

import com.abacogroup.agri.applications.core.model.ApplicationQueuePayload;
import com.abacogroup.agri.applications.core.services.ApplicationsService;
import com.abacogroup.agri.applications.core.services.crud.ApplicationsCrudService;
import com.abacogroup.agri.applications.core.services.crud.ModuleCrudService;
import com.abacogroup.applicationworkflowsdk.model.ApplicationsWorkflowParams;
import com.abacogroup.embeddedqueue.rabbitmq.RabbitMqPublisherWorkQueue;
import com.abacogroup.workflow.server.model.ProcessTransitionResult;

import java.util.Optional;
import java.util.function.Function;

/**
 * @author Gennaro Tamburrelli
 */
public class ApplicationExchangePublisher {

    public static final String ROUTING_KEY = "transition.%s.%s.%s";
    public static final String NONE = "NONE";
    private final RabbitMqPublisherWorkQueue<ApplicationQueuePayload> queue;
    private final ApplicationsCrudService applicationsCrudService;

    public ApplicationExchangePublisher(RabbitMqPublisherWorkQueue<ApplicationQueuePayload> queue, ApplicationsCrudService applicationsCrudService) {
        this.queue = queue;
        this.applicationsCrudService = applicationsCrudService;
    }

    public void addQueue(ApplicationsWorkflowParams applicationsWorkflowParams, ProcessTransitionResult processTransitionResult) {
        var app = applicationsCrudService.findWithDetailsByApplicationId(applicationsWorkflowParams.getTenant(), applicationsWorkflowParams.getApplicationId());
        this.queue.add(ApplicationQueuePayload.builder()
                        .tenant(applicationsWorkflowParams.getTenant())
                        .applicationId(applicationsWorkflowParams.getApplicationId())
                        .currentStatus(processTransitionResult.getCurrentNode())
                        .moduleCode(app.getModuleCode())
                        .sectorCode(app.getSectorCode())
                        .transitionCode(processTransitionResult.getAllTransitionLogs().stream().findFirst().map(ProcessTransitionResult.TransitionLog::getTransitionCode).orElse(NONE))
                        .userId(applicationsWorkflowParams.getUserid())
                .build(), System.currentTimeMillis());
    }

    public static Function<ApplicationQueuePayload, String> routingKeySupplier = (payload) ->
            String.format(ROUTING_KEY,
                    payload.getSectorCode(),
                    payload.getModuleCode(),
                    Optional.ofNullable(payload.getTransitionCode()).orElse(NONE));
}
