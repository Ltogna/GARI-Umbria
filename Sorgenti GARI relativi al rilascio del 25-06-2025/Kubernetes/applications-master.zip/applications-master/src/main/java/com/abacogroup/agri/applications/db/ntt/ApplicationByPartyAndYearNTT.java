package com.abacogroup.agri.applications.db.ntt;

import java.time.LocalDate;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author Gennaro Tamburrelli
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ApplicationByPartyAndYearNTT {
	private Long party_id;
	private Integer referred_year;
	private String sector_code;
	private String sector_description;
	private String module_code;
	private String module_description;
	private String application_code;
	private Long application_id;
	private String process_status;
	private Long process_id;
	private LocalDate dt_presentation;
	private Long amended_by_id;
	private Long amend_of_id;
	private LocalDate dt_protocol;
	private String protocol;
	private String context_function;
}
