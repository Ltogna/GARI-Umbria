package com.abacogroup.agri.applications.utils;

import com.abacogroup.agri.applications.core.exceptions.ObjectNotFoundException;
import com.abacogroup.agri.applications.core.model.dto.publics.DescriptionReplacer;
import com.abacogroup.agri.applications.core.services.PartyService;
import com.abacogroup.agri.applications.core.services.crud.ApplicationsCrudService;
import com.abacogroup.dropwizard.auth.sso2.User;
import lombok.extern.slf4j.Slf4j;

import java.util.List;
import java.util.Map;
import java.util.Optional;

/*
 * Utility that replaces the description of a class that implements 'DescriptionReplacer':
 * if the description contains the key '{APPLICATION_ID}', it will be replaced with the real value
 * Example: description = 'Print of application {APPLICATION_ID}' will change as 'Print of application 1234'
 *
 */
@Slf4j
public final class DescriptionReplacerUtility {

	private static final String KEY_APPLICATION_ID = "{APPLICATION_ID}";
	private static final String KEY_CUAA = "{CUAA}";

	private DescriptionReplacerUtility() {
	}

	public static <T extends DescriptionReplacer> void replaceDescriptionFromList(List<T> descriptionReplacerList, Long applicationId) {
		descriptionReplacerList.forEach(x -> replaceDescriptionFromList(x, buildMapWithApplicationId(applicationId)));
	}

	public static <T extends DescriptionReplacer> void replaceDescription(T descriptionReplacer, Long applicationId, String cuaa) {
		replaceDescriptionFromList(descriptionReplacer, buildMapWithApplicationId(applicationId));
		replaceDescriptionFromList(descriptionReplacer, buildMapWithCuaa(cuaa));
	}

	public static String replaceAndReturnSingleDescription(String descriptionToReplace, Long applicationId) {
		return replaceAndReturnSingleDescription(descriptionToReplace, buildMapWithApplicationId(applicationId));
	}

	private static Map<String, String> buildMapWithApplicationId(Long applicationId) {
		return Map.of(KEY_APPLICATION_ID, String.valueOf(applicationId));
	}
	private static Map<String, String> buildMapWithCuaa(String cuaa) {
		return Map.of(KEY_CUAA, cuaa);
	}

	private static String replaceAndReturnSingleDescription(String descriptionToReplace, Map<String, String> map) {
		if(Optional.ofNullable(descriptionToReplace).isPresent()){
			String processedDescription = descriptionToReplace;
			for (Map.Entry<String, String> entry : map.entrySet()) {
				processedDescription = processedDescription.replace(entry.getKey(), entry.getValue());
			}
			return processedDescription;
		}
		return null;
	}

	private static void replaceDescriptionFromList(DescriptionReplacer descriptionReplacer, Map<String, String> map) {
		if(Optional.ofNullable(descriptionReplacer.getDescription()).isPresent()) {
			String processedDescription = descriptionReplacer.getDescription();
			for (Map.Entry<String, String> entry : map.entrySet()) {
				processedDescription = processedDescription.replace(entry.getKey(), entry.getValue());
			}
			descriptionReplacer.setDescription(processedDescription);
		}
	}

	public static void processDescriptionReplacer(ApplicationsCrudService applicationsCrudService, PartyService partyService, User user, DescriptionReplacer x, String tenant, Long applicationId){
		try {
			Long partyId = applicationsCrudService.findById(tenant, applicationId).getPartyId();
			String cuaa = partyService.getPartyByPartyId(tenant, partyId, user).getCuaa();
			DescriptionReplacerUtility.replaceDescription(x, applicationId, cuaa);
		}
		catch (ObjectNotFoundException e){
			log.error(e.getMessage(), e);
		}
	}
}
