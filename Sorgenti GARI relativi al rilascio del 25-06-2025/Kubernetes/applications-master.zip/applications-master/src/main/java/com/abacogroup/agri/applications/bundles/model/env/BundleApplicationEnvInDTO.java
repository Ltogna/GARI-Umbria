package com.abacogroup.agri.applications.bundles.model.env;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.util.Map;

/**
 * The type Bundle application env in dto.
 * @author Carlo Sindico
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class BundleApplicationEnvInDTO {

    private String key;
    private String value;
    private Integer flClient;

}
