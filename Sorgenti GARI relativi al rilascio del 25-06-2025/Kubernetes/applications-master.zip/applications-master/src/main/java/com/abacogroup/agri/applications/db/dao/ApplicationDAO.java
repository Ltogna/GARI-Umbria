package com.abacogroup.agri.applications.db.dao;

import com.abacogroup.agri.applications.db.ntt.ApplicationByPartyAndYearNTT;
import com.abacogroup.agri.applications.db.ntt.ApplicationNTT;
import com.abacogroup.agri.applications.db.ntt.ApplicationWithDetailsNTT;
import org.jdbi.v3.core.result.ResultIterator;
import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.customizer.BindBean;
import org.jdbi.v3.sqlobject.customizer.BindList;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;

import java.time.LocalDateTime;
import java.util.List;

/**
 * @author Alexandru Paraschiv
 * @author Gennaro Tamburrelli
 */
public interface ApplicationDAO extends IGenericHistoricizationFieldsDAO<ApplicationNTT, Long, Long> {

	@Override
	@SqlQuery("§select_nextval(apps_application_id_seq)§")
	Long nextSequenceVal();

	@Override
	@SqlUpdate("INSERT INTO APPS_APPLICATIONS " +
			"(id, " +
			"party_id, " +
			"referred_year, " +
			"module_id, " +
			"process_id, " +
			"user_id_insert, " +
			"user_id_delete, " +
			"dt_insert, " +
			"dt_delete) " +
			"VALUES(:id, :party_id, :referred_year, :module_id, :process_id, :user_id, NULL, :current_timestamp, TO_TIMESTAMP('9999-12-3123:59:59','YYYY-MM-DDHH24:MI:SS'))")
	void insert(@BindBean ApplicationNTT ntt, @Bind("user_id") String userId, @Bind("current_timestamp") LocalDateTime currentTimestamp);

	@SqlQuery("select a.id," +
			"  a.party_id," +
			"  a.referred_year," +
			"  a.module_id," +
			"  a.process_id," +
			"  a.dt_insert," +
			"  a.dt_delete," +
			"  a.user_id_insert," +
			"  a.user_id_delete" +
			" from APPS_APPLICATIONS a" +
			" where a.id = :id")
	@RegisterBeanMapper(ApplicationNTT.class)
	List<ApplicationNTT> findById(@Bind("id") Long id);

	@SqlQuery("select a.id," +
			"  a.party_id," +
			"  a.referred_year," +
			"  a.module_id," +
			"  a.process_id," +
			"  a.dt_insert," +
			"  a.dt_delete," +
			"  a.user_id_insert," +
			"  a.user_id_delete" +
			" from APPS_APPLICATIONS a" +
			" where a.process_id = :porcessId")
	@RegisterBeanMapper(ApplicationNTT.class)
	List<ApplicationNTT> findByProcessId(@Bind("porcessId") Long porcessId);

	@Override
	@SqlUpdate("UPDATE APPS_APPLICATIONS SET " +
			"user_id_delete = :user_id_delete, dt_delete = :current_timestamp " +
			"WHERE id = :id " +
			"and §current_timestamp§ between dt_insert and dt_delete")
	void logicallyDeleteById(@Bind("id") Long id, @Bind("user_id_delete") String userDelete, @Bind("current_timestamp") LocalDateTime currentTimestamp);

	@SqlQuery("select a.id," +
			"  a.party_id," +
			"  a.referred_year," +
			"  a.module_id," +
			"  a.process_id," +
			"  ad.application_code," +
			"  ad.process_status," +
			"  ad.dt_presentation," +
			"  §i18n(:tenant_id, 'apps_sectors', 'sector_code', s.sector_code, :lang)§ as sector_description," +
			"  §i18n(:tenant_id, 'apps_modules', 'module_code', am.module_code, :lang)§ as module_description," +
			"  ad.dt_insert," +
			"  ad.dt_delete," +
			"  ad.user_id_insert," +
			"  ad.user_id_delete" +
			" from APPS_APPLICATIONS a " +
			" INNER JOIN APPS_APPLICATION_DETAILS ad on ad.application_id = a.id " +
			" INNER JOIN APPS_MODULES am on am.id = a.module_id " +
			" INNER JOIN APPS_SECTORS s on s.id = am.sector_id " +
			" where ad.application_code = :code " +
			" and s.tenant_id = :tenant_id " +
			" and §current_timestamp§ between a.dt_insert and a.dt_delete " +
			" and §current_timestamp§ between ad.dt_insert and ad.dt_delete " +
			" and §current_timestamp§ between am.dt_insert and am.dt_delete ")
	@RegisterBeanMapper(ApplicationWithDetailsNTT.class)
	List<ApplicationWithDetailsNTT> findWithDetailByCode(@Bind("tenant_id") String tenant, @Bind("code") String code, @Bind("lang") String lang);

	@SqlQuery("select a.id," +
			"  a.party_id," +
			"  a.referred_year," +
			"  a.module_id," +
			"  a.process_id," +
			"  ad.application_code," +
			"  ad.process_status," +
			"  ad.dt_presentation," +
			"  s.sector_code, " +
			"  am.module_code, " +
			"  §i18n(:tenant_id, 'apps_sectors', 'sector_code', s.sector_code, :lang)§ as sector_description," +
			"  §i18n(:tenant_id, 'apps_modules', 'module_code', am.module_code, :lang)§ as module_description," +
			"  ad.dt_insert," +
			"  ad.dt_delete," +
			"  ad.user_id_insert," +
			"  ad.user_id_delete, " +
			" ad.amended_by_id, " +
			" ad.amend_of_id, " +
			" amd.annuality as module_year " +
			" from APPS_APPLICATIONS a " +
			" INNER JOIN APPS_APPLICATION_DETAILS ad on ad.application_id = a.id " +
			" INNER JOIN APPS_MODULES am on am.id = a.module_id " +
			" INNER JOIN APPS_MODULE_DETAILS amd on amd.module_id = a.module_id " +
			" INNER JOIN APPS_SECTORS s on s.id = am.sector_id " +
			" where a.id = :app_id " +
			" and s.tenant_id = :tenant_id " +
			" and §current_timestamp§ between a.dt_insert and a.dt_delete " +
			" and §current_timestamp§ between ad.dt_insert and ad.dt_delete " +
			" and §current_timestamp§ between amd.dt_insert and amd.dt_delete " +
			" and §current_timestamp§ between am.dt_insert and am.dt_delete ")
	@RegisterBeanMapper(ApplicationWithDetailsNTT.class)
	List<ApplicationWithDetailsNTT> findWithDetailById(@Bind("tenant_id") String tenant, @Bind("app_id") Long appId, @Bind("lang") String lang);

	@SqlQuery("select a.id," +
			"  a.party_id," +
			"  a.referred_year," +
			"  a.module_id," +
			"  a.process_id," +
			"  a.dt_insert," +
			"  a.dt_delete," +
			"  a.user_id_insert," +
			"  a.user_id_delete" +
			" from APPS_APPLICATIONS a" +
			" left join apps_modules m ON a.module_id = m.id " +
			" left join apps_sectors s ON m.sector_id = s.id " +
			" where a.party_id = :partyId and s.tenant_id = :tenant " +
			" and §current_timestamp§ between a.dt_insert and a.dt_delete" +
			" and §current_timestamp§ between m.dt_insert and m.dt_delete")
	@RegisterBeanMapper(ApplicationNTT.class)
	List<ApplicationNTT> findAllByPartyId(@Bind("tenant") String tenant, @Bind("partyId") Long partyId);

	@SqlQuery("select a.id," +
			"  a.party_id," +
			"  a.referred_year," +
			"  a.module_id," +
			"  a.process_id," +
			"  a.dt_insert," +
			"  a.dt_delete," +
			"  a.user_id_insert," +
			"  a.user_id_delete" +
			" from APPS_APPLICATIONS a" +
			" left join apps_modules m ON a.module_id = m.id " +
			" left join apps_sectors s ON m.sector_id = s.id " +
			" where a.module_id = :moduleId and s.tenant_id = :tenant " +
			" and §current_timestamp§ between a.dt_insert and a.dt_delete")
	@RegisterBeanMapper(ApplicationNTT.class)
	List<ApplicationNTT> findAllByModuleId(@Bind("tenant") String tenant, @Bind("moduleId") Long moduleId);

	@SqlQuery("select a.id," +
			"  a.party_id," +
			"  a.referred_year," +
			"  a.module_id," +
			"  a.process_id," +
			"  ad.application_code," +
			"  ad.process_status," +
			"  ad.dt_presentation," +
			"  ad.dt_insert," +
			"  ad.dt_delete," +
			"  ad.user_id_insert," +
			"  ad.user_id_delete" +
			" from APPS_APPLICATIONS a " +
			" INNER JOIN APPS_APPLICATION_DETAILS ad on ad.application_id = a.id " +
			" INNER JOIN APPS_MODULES am on am.id = a.module_id " +
			" INNER JOIN APPS_SECTORS s on s.id = am.sector_id " +
			" where a.module_id = :moduleId and s.tenant_id = :tenant_id " +
			" and a.party_id = :partyId " +
			" and a.referred_year = :referredYear " +
			" and §current_timestamp§ between a.dt_insert and a.dt_delete " +
			" and §current_timestamp§ between ad.dt_insert and ad.dt_delete " +
			" and §current_timestamp§ between am.dt_insert and am.dt_delete ")
	@RegisterBeanMapper(ApplicationWithDetailsNTT.class)
	List<ApplicationWithDetailsNTT> findAllByModuleIdAndPartyIdAndReferredYear(@Bind("tenant_id") String tenant, @Bind("moduleId") Long moduleId,
			@Bind("partyId") Long partyId,
			@Bind("referredYear") Integer referredYear);

	@SqlQuery("select a.id," +
			"  a.party_id," +
			"  a.referred_year," +
			"  a.module_id," +
			"  a.process_id," +
			"  ad.application_code," +
			"  ad.process_status," +
			"  ad.dt_presentation," +
			"  ad.dt_insert," +
			"  ad.dt_delete," +
			"  ad.user_id_insert," +
			"  ad.user_id_delete" +
			" from APPS_APPLICATIONS a " +
			" INNER JOIN APPS_APPLICATION_DETAILS ad on ad.application_id = a.id " +
			" INNER JOIN APPS_MODULES am on am.id = a.module_id " +
			" INNER JOIN APPS_SECTORS s on s.id = am.sector_id " +
			" where s.tenant_id = :tenant_id " +
			" and a.party_id = :partyId " +
			" and (:moduleCode is NULL OR am.module_code = :moduleCode) " +
			" and (:processStatus is NULL OR ad.process_status = :processStatus)" +
			" and §current_timestamp§ between a.dt_insert and a.dt_delete " +
			" and §current_timestamp§ between ad.dt_insert and ad.dt_delete " +
			" and §current_timestamp§ between am.dt_insert and am.dt_delete ")
	@RegisterBeanMapper(ApplicationWithDetailsNTT.class)
	List<ApplicationWithDetailsNTT> findAllByPartyIdAndModuleCodeAndProcessStatus(@Bind("tenant_id") String tenant,
			@Bind("partyId") Long partyId,
			@Bind("moduleCode") String moduleCode,
			@Bind("processStatus") String processStatus);

	@SqlQuery("SELECT aa.PARTY_ID," +
			"aa.REFERRED_YEAR," +
			"as2.SECTOR_CODE," +
			"§i18n(:tenant_id, 'apps_sectors', 'sector_code', as2.sector_code, :lang)§ as sector_description, " +
			"am.MODULE_CODE," +
			"§i18n(:tenant_id, 'apps_modules', 'module_code', am.module_code, :lang)§ as module_description," +
			"aad.APPLICATION_CODE," +
			"aad.PROCESS_STATUS," +
			"aa.PROCESS_ID, " +
			"aa.ID as APPLICATION_ID, " +
			"aad.DT_PRESENTATION, " +
			"amd.context_function " +
			"FROM APPS_APPLICATIONS aa LEFT JOIN APPS_MODULES am ON aa.MODULE_ID = am.id " +
			"LEFT JOIN APPS_MODULE_DETAILS amd ON amd.MODULE_ID = am.id " +
			"LEFT JOIN APPS_APPLICATION_DETAILS aad ON aa.id = aad.APPLICATION_ID " +
			"LEFT JOIN APPS_SECTORS as2 ON am.SECTOR_ID = as2.id " +
			"WHERE aa.PARTY_ID = :party_id " +
			"AND aa.REFERRED_YEAR = :year " +
			"AND as2.TENANT_ID = :tenant_id" +
			" and §current_timestamp§ between aa.dt_insert and aa.dt_delete" +
			" and §current_timestamp§ between aad.dt_insert and aad.dt_delete" +
			" and §current_timestamp§ between am.dt_insert and am.dt_delete " +
			"and §current_timestamp§ between amd.dt_insert and amd.dt_delete")
	@RegisterBeanMapper(ApplicationByPartyAndYearNTT.class)
	ResultIterator<ApplicationByPartyAndYearNTT> find(@Bind("tenant_id") String tenant, @Bind("party_id") Long partyId, @Bind("year") Integer year,
			@Bind("lang") String lang);

	@SqlQuery("SELECT aa.PARTY_ID," +
			"aa.REFERRED_YEAR," +
			"as2.SECTOR_CODE," +
			"§i18n(:tenant_id, 'apps_sectors', 'sector_code', as2.sector_code, :lang)§ as sector_description, " +
			"am.MODULE_CODE," +
			"§i18n(:tenant_id, 'apps_modules', 'module_code', am.module_code, :lang)§ as module_description," +
			"aad.APPLICATION_CODE," +
			"aad.PROCESS_STATUS," +
			"aa.PROCESS_ID, " +
			"aa.ID as APPLICATION_ID, " +
			"aad.DT_PRESENTATION " +
			"FROM APPS_APPLICATIONS aa LEFT JOIN APPS_MODULES am ON aa.MODULE_ID = am.id " +
			"LEFT JOIN APPS_APPLICATION_DETAILS aad ON aa.id = aad.APPLICATION_ID " +
			"LEFT JOIN APPS_SECTORS as2 ON am.SECTOR_ID = as2.id " +
			"WHERE aa.PARTY_ID = :party_id " +
			"AND aa.REFERRED_YEAR = :year " +
			"AND as2.TENANT_ID = :tenant_id " +
			"AND am.module_code = :module_code " +
			" and §current_timestamp§ between aa.dt_insert and aa.dt_delete" +
			" and §current_timestamp§ between aad.dt_insert and aad.dt_delete" +
			" and §current_timestamp§ between am.dt_insert and am.dt_delete")
	@RegisterBeanMapper(ApplicationByPartyAndYearNTT.class)
	List<ApplicationByPartyAndYearNTT> find(@Bind("tenant_id") String tenant, @Bind("party_id") Long partyId, @Bind("year") Integer year,
			@Bind("module_code") String moduleCode, @Bind("lang") String lang);

	@SqlQuery("SELECT aa.PARTY_ID," +
			"aa.REFERRED_YEAR," +
			"as2.SECTOR_CODE," +
			"§i18n(:tenant_id, 'apps_sectors', 'sector_code', as2.sector_code, :lang)§ as sector_description, " +
			"am.MODULE_CODE," +
			"§i18n(:tenant_id, 'apps_modules', 'module_code', am.module_code, :lang)§ as module_description," +
			"aad.APPLICATION_CODE," +
			"aad.PROCESS_STATUS," +
			"aa.PROCESS_ID, " +
			"aa.ID as APPLICATION_ID, " +
			"aad.DT_PRESENTATION, " +
			"aad.AMENDED_BY_ID, " +
			"aad.AMEND_OF_ID, " +
			"aap.dt_response as dt_protocol, " +
			"aap.protocol " +
			"FROM APPS_APPLICATIONS aa LEFT JOIN APPS_MODULES am ON aa.MODULE_ID = am.id " +
			"JOIN APPS_APPLICATION_DETAILS aad ON aa.id = aad.APPLICATION_ID " +
			"JOIN APPS_SECTORS as2 ON am.SECTOR_ID = as2.id " +
			"LEFT JOIN APPS_APPLICATION_PROTOCOLS aap ON aa.id = aap.application_id " +
			"WHERE as2.TENANT_ID = :tenant_id " +
			"AND (:skipYearList = 1 OR aa.REFERRED_YEAR IN (<yearList>)) " +
			"AND (:party_id IS NULL OR aa.PARTY_ID = :party_id)" +
			"AND (:module_code IS NULL OR am.module_code = :module_code) " +
			"AND (:process_status IS NULL OR aad.PROCESS_STATUS = :process_status) " +
			"AND (:skipApplicationList = 1 OR aa.ID in (<application_id_list>)) " +
			" and §current_timestamp§ between aa.dt_insert and aa.dt_delete" +
			" and §current_timestamp§ between aad.dt_insert and aad.dt_delete" +
			" and §current_timestamp§ between am.dt_insert and am.dt_delete " +
			" and ((aap.dt_insert IS NOT NULL AND §current_timestamp§ between aap.dt_insert and aap.dt_delete) " +
			"      OR (aap.dt_insert IS NULL)) " +
			"ORDER BY aa.ID")
	@RegisterBeanMapper(ApplicationByPartyAndYearNTT.class)
	ResultIterator<ApplicationByPartyAndYearNTT> findInfinite(@Bind("tenant_id") String tenant, @Bind("party_id") Long partyId,
			@BindList("yearList") List<Integer> yearList,
			@Bind("skipYearList") int skipYearList,
			@Bind("module_code") String moduleCode, @Bind("process_status") String processStatus,
			@BindList("application_id_list") List<Long> applicationIdList,
			@Bind("skipApplicationList") int skipApplicationList,
			@Bind("lang") String lang);

	@SqlQuery("  SELECT aa.ID as APPLICATION_ID " +
			"      FROM APPS_APPLICATIONS aa " +
			" LEFT JOIN APPS_MODULES am " +
			"        ON aa.MODULE_ID = am.id " +
			"      JOIN APPS_SECTORS as2 " +
			"        ON am.SECTOR_ID = as2.id " +
			"     WHERE as2.TENANT_ID = :tenant_id " +
			"       AND am.module_code = :module_code " +
			"       AND §current_timestamp§ between aa.dt_insert and aa.dt_delete " +
			"       AND §current_timestamp§ between am.dt_insert and am.dt_delete " +
			"  ORDER BY aa.ID")
	ResultIterator<Long> findInfiniteApplicationIds(
			@Bind("tenant_id") String tenant,
			@Bind("module_code") String moduleCode
	);

	@SqlQuery("SELECT count(*) " +
			"FROM APPS_APPLICATIONS aa LEFT JOIN APPS_MODULES am ON aa.MODULE_ID = am.id " +
			"JOIN APPS_APPLICATION_DETAILS aad ON aa.id = aad.APPLICATION_ID " +
			"JOIN APPS_SECTORS as2 ON am.SECTOR_ID = as2.id " +
			"WHERE as2.TENANT_ID = :tenant_id " +
			"AND (:skipYearList = 1 OR aa.REFERRED_YEAR IN (<yearList>)) " +
			"AND (:party_id IS NULL OR aa.PARTY_ID = :party_id)" +
			"AND (:module_code IS NULL OR am.module_code = :module_code) " +
			"AND (:process_status IS NULL OR aad.PROCESS_STATUS = :process_status) " +
			"AND (:skipApplicationList = 1 OR aa.ID in (<application_id_list>)) " +
			" and §current_timestamp§ between aa.dt_insert and aa.dt_delete" +
			" and §current_timestamp§ between aad.dt_insert and aad.dt_delete" +
			" and §current_timestamp§ between am.dt_insert and am.dt_delete " +
			"ORDER BY aa.ID")
	Long countApplications(@Bind("tenant_id") String tenant,
			@Bind("party_id") Long partyId,
			@BindList("yearList") List<Integer> yearList,
			@Bind("skipYearList") int skipYearList,
			@Bind("module_code") String moduleCode, @Bind("process_status") String processStatus,
			@BindList("application_id_list") List<Long> applicationIdList,
			@Bind("skipApplicationList") int skipApplicationList);

	@SqlQuery("select a.id," +
			" a.party_id," +
			" a.referred_year," +
			" a.module_id," +
			" a.process_id," +
			" a.dt_insert," +
			" a.dt_delete," +
			" a.user_id_insert," +
			" a.user_id_delete" +
			" from APPS_APPLICATIONS a" +
			" left join APPS_APPLICATION_DETAILS aad ON a.id = aad.APPLICATION_ID" +
			" left join apps_modules m ON a.module_id = m.id" +
			" left join apps_sectors s ON m.sector_id = s.id" +
			" where s.tenant_id = :tenant" +
			" and aad.APPLICATION_CODE = :application_code" +
			" and §current_timestamp§ between a.dt_insert and a.dt_delete " +
			" and §current_timestamp§ between aad.dt_insert and aad.dt_delete " +
			" and §current_timestamp§ between m.dt_insert and m.dt_delete")
	@RegisterBeanMapper(ApplicationNTT.class)
	List<ApplicationNTT> findByCode(@Bind("tenant") String tenant, @Bind("application_code") String applicationCode);

	@SqlQuery("select a.id," +
			" a.party_id," +
			" a.referred_year," +
			" a.module_id," +
			" a.process_id," +
			" a.dt_insert," +
			" a.dt_delete," +
			" a.user_id_insert," +
			" a.user_id_delete" +
			" from APPS_APPLICATIONS a" +
			" left join apps_modules m ON a.module_id = m.id" +
			" left join apps_sectors s ON m.sector_id = s.id" +
			" where s.tenant_id = :tenant" +
			" and a.id = :application_id " +
			" and §current_timestamp§ between a.dt_insert and a.dt_delete " +
			" and §current_timestamp§ between m.dt_insert and m.dt_delete")
	@RegisterBeanMapper(ApplicationNTT.class)
	List<ApplicationNTT> findById(@Bind("tenant") String tenant, @Bind("application_id") Long applicationId);

	@SqlQuery("select a.id," +
			" a.party_id," +
			" a.referred_year," +
			" a.module_id," +
			" a.process_id," +
			" a.dt_insert," +
			" a.dt_delete," +
			" a.user_id_insert," +
			" a.user_id_delete" +
			" from APPS_APPLICATIONS a" +
			" left join apps_modules m ON a.module_id = m.id" +
			" left join apps_sectors s ON m.sector_id = s.id" +
			" where s.tenant_id = :tenant" +
			" and a.id = :application_id " +
			" and §current_timestamp§ between m.dt_insert and m.dt_delete")
	@RegisterBeanMapper(ApplicationNTT.class)
	List<ApplicationNTT> findByIdAlsoExpired(@Bind("tenant") String tenant, @Bind("application_id") Long applicationId);

	@SqlUpdate("UPDATE apps_applications " +
			"SET process_id = :process_id " +
			"WHERE id = :id")
	void updateProcessId(@Bind("id") Long id, @Bind("process_id") Long processId);
}
