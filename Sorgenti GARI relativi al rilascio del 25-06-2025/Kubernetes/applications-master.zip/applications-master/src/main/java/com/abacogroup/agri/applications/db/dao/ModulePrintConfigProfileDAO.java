package com.abacogroup.agri.applications.db.dao;

import com.abacogroup.agri.applications.db.ntt.ModulePrintConfigProfileNTT;
import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.customizer.BindBean;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;

import java.util.List;

/**
 * @author Gennaro Tamburrelli
 */
public interface ModulePrintConfigProfileDAO extends IGenericDAO<ModulePrintConfigProfileNTT, Void> {

	@Override
	@SqlQuery("not implemented")
	Void nextSequenceVal();

	@SqlUpdate("INSERT INTO apps_module_print_config_profiles " +
			"(module_print_config_id, required_profile_code) " +
			"VALUES(:module_print_config_id, :required_profile_code)")
	void insert(@BindBean ModulePrintConfigProfileNTT formGroup);

	@SqlQuery("SELECT p.module_print_config_id," +
			"p.required_profile_code " +
			"FROM apps_module_print_config_profiles p " +
			"WHERE p.module_print_config_id=:module_print_config_id AND p.required_profile_code = :required_profile_code AND " +
			":tenant_id in " +
			"(SELECT s.tenant_id " +
			" FROM apps_module_print_configs mfc" +
			" INNER JOIN apps_modules am on am.id = mfc.module_id " +
			" INNER JOIN apps_sectors s on s.id = am.sector_id " +
			" WHERE p.module_print_config_id = mfc.id)")
	@RegisterBeanMapper(ModulePrintConfigProfileNTT.class)
	List<ModulePrintConfigProfileNTT> findById(@Bind("tenant_id") String tenantId, @Bind("module_print_config_id") Long moduleFormConfigId,
			@Bind("required_profile_code") String requiredProfileCode);

	@SqlQuery("SELECT p.module_print_config_id," +
			"p.required_profile_code " +
			"FROM apps_module_print_config_profiles p " +
			"WHERE p.module_print_config_id=:module_print_config_id AND p.required_profile_code = :required_profile_code")
	@RegisterBeanMapper(ModulePrintConfigProfileNTT.class)
	List<ModulePrintConfigProfileNTT> findById(@Bind("module_print_config_id") Long moduleFormConfigId,
			@Bind("required_profile_code") String requiredProfileCode);

	@SqlQuery("SELECT p.module_print_config_id," +
			"p.required_profile_code " +
			"FROM apps_module_print_config_profiles p " +
			"WHERE p.module_print_config_id=:module_print_config_id AND " +
			":tenant_id in " +
			"(SELECT s.tenant_id " +
			" FROM apps_module_print_configs mfc" +
			" INNER JOIN apps_modules am on am.id = mfc.module_id " +
			" INNER JOIN apps_sectors s on s.id = am.sector_id " +
			" WHERE p.module_print_config_id = mfc.id)")
	@RegisterBeanMapper(ModulePrintConfigProfileNTT.class)
	List<ModulePrintConfigProfileNTT> find(@Bind("tenant_id") String tenantId, @Bind("module_print_config_id") Long moduleFormConfigId);

	@SqlUpdate("UPDATE apps_module_print_config_profiles SET " +
			"required_profile_code=:required_profile_code " +
			"where module_print_config_id=:module_print_config_id")
	void update(@BindBean ModulePrintConfigProfileNTT moduleFormConfig);

	@SqlUpdate("DELETE FROM apps_module_print_config_profiles p " +
			"WHERE p.module_print_config_id=:module_print_config_id AND p.required_profile_code = :required_profile_code")
	void deleteById(@Bind("module_print_config_id") Long moduleFormConfigId,
			@Bind("required_profile_code") String requiredProfileCode);

	@SqlUpdate("DELETE FROM apps_module_print_config_profiles p " +
			"WHERE p.module_print_config_id=:module_print_config_id")
	void deleteByModulePrintConfigId(@Bind("module_print_config_id") Long moduleFormConfigId);

}
