package com.abacogroup.agri.applications.core.exceptions;

import io.swagger.v3.oas.annotations.media.Schema;

import jakarta.ws.rs.core.Response;

public class AgriApplicationsRuntimeException extends AbstractException {

	private static final AgriApplicationsRuntimeException.ErrorBody BODY = new AgriApplicationsRuntimeException.ErrorBody();

	public AgriApplicationsRuntimeException(String message) {
		super(Response.Status.INTERNAL_SERVER_ERROR, BODY, message);
	}

	@Schema(name = "AgriApplicationsRuntimeExceptionErrorBody")
	public static class ErrorBody implements ExceptionErrorBody {
		private static final String ERR = "GENERIC_ERROR";

		@Override
		@Schema(allowableValues = ERR)
		public String getErrorCode() {
			return ERR;
		}
	}
}
