package com.abacogroup.agri.applications.core.mappers;

import com.abacogroup.agri.applications.core.model.dto.ApplicationGeneratedCalculationDTO;
import com.abacogroup.agri.applications.db.ntt.ApplicationGeneratedCalculationNTT;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

@Mapper(uses = AbsoluteDateMapper.class)
public interface ApplicationGeneratedCalculationMapper extends EntityMapper<ApplicationGeneratedCalculationDTO, ApplicationGeneratedCalculationNTT> {

	ApplicationGeneratedCalculationMapper INSTANCE = Mappers.getMapper(ApplicationGeneratedCalculationMapper.class);

	@InheritInverseConfiguration()
	ApplicationGeneratedCalculationDTO entityToDto(ApplicationGeneratedCalculationNTT entity);

	@Mapping(source = "pkid", target = "pkid")
	@Mapping(source = "applicationId", target = "application_id")
	@Mapping(source = "calculationCode", target = "calculation_code")
	@Mapping(source = "processStatus", target = "process_status")
	@Mapping(source = "calculationDescription", target = "calculation_description")
	@Mapping(source = "calculationDate", target = "calculation_date")
	@Mapping(source = "calculationJobUuid", target = "calculation_job_uuid")
	@Mapping(source = "username", target = "username")
	@Mapping(source = "calculationStatus", target = "status")
	@Mapping(source = "notes", target = "notes")
	ApplicationGeneratedCalculationNTT dtoToEntity(ApplicationGeneratedCalculationDTO dto);
}
