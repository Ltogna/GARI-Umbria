package com.abacogroup.agri.applications.utils;

import com.abacogroup.jdbi.orderby.OrderBy;
import com.abacogroup.jdbi.orderby.OrderByBuilder;
import com.abacogroup.jdbi.orderby.OrderByElement;
import com.abacogroup.jdbi.orderby.SortDirection;
import org.apache.commons.lang3.NotImplementedException;

import java.util.List;
import java.util.Optional;
import java.util.function.Supplier;

public class SortUtility {

	private SortUtility() {
	}

	private static final String DELIMITER = ",";
	private static final Integer SORT_FIELD_ELEMENT = 0;
	private static final Integer SORT_DIRECTION = 1;
	private static final SortDirection DEFAULT_SORT_DIRECTION = SortDirection.ASC;
	public static final Supplier<NotImplementedException> throwNotImplementedException = () -> new NotImplementedException("not in use");

	public static OrderBy createOrderBy(List<String> params) {
		return OrderByBuilder.from(buildElements(params));
	}

	private static OrderByElement[] buildElements(List<String> params) {
		if (Optional.ofNullable(params).isEmpty() || params.isEmpty()) {
			return new OrderByElement[] {};
		}
		OrderByElement[] orderByBuilderList = new OrderByElement[params.size()];
		params.forEach(param -> orderByBuilderList[params.indexOf(param)] = OrderByBuilder.field(param.split(DELIMITER)[SORT_FIELD_ELEMENT])
				.direction(getSortDirectionFromParam(param)));
		return orderByBuilderList;
	}

	private static SortDirection getSortDirectionFromParam(String param) {
		return SortDirection.valueOf(param.split(DELIMITER).length == 1 ? DEFAULT_SORT_DIRECTION.toString() : param.split(DELIMITER)[SORT_DIRECTION]);

	}
}
