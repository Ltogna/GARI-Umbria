package com.abacogroup.agri.applications.core.exceptions;

import io.swagger.v3.oas.annotations.media.Schema;

import jakarta.ws.rs.core.Response;

public class ObjectNotFoundRuntimeException extends AbstractException {

	private static final ObjectNotFoundRuntimeException.ErrorBody BODY = new ObjectNotFoundRuntimeException.ErrorBody();

	public ObjectNotFoundRuntimeException(String message) {
		super(Response.Status.NOT_FOUND, BODY, message);
	}

	public ObjectNotFoundRuntimeException() {
		super(Response.Status.NOT_FOUND, BODY, "Object not found");
	}

	@Schema(name = "ObjectNotFoundRuntimeExceptionErrorBody")
	public static class ErrorBody implements ExceptionErrorBody {
		private static final String ERR = "OBJECT_NOT_FOUND_ERROR";

		@Override
		@Schema(allowableValues = ERR)
		public String getErrorCode() {
			return ERR;
		}
	}
}
