package com.abacogroup.agri.applications.core.exceptions;

import io.swagger.v3.oas.annotations.media.Schema;

import jakarta.ws.rs.core.Response;

public class ApplicationNotFoundRuntimeException extends AbstractException {

	private static final ApplicationNotFoundRuntimeException.ErrorBody BODY = new ApplicationNotFoundRuntimeException.ErrorBody();

	public ApplicationNotFoundRuntimeException(String message) {
		super(Response.Status.NOT_FOUND, BODY, message);
	}

	@Schema(name = "ApplicationNotFoundByCodeRuntimeExceptionErrorBody")
	public static class ErrorBody implements ExceptionErrorBody {
		private static final String ERR = "APPLICATION_NOT_FOUND_ERROR";

		@Override
		@Schema(allowableValues = ERR)
		public String getErrorCode() {
			return ERR;
		}
	}
}
