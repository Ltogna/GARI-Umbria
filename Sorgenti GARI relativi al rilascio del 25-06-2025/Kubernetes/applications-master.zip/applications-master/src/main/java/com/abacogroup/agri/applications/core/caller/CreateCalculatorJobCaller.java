package com.abacogroup.agri.applications.core.caller;

import com.abacogroup.agri.applications.core.model.dto.CreateCalculatorJobOutDTO;
import com.abacogroup.jaxrsutils.GenericCallerService;
import com.abacogroup.jaxrsutils.callerv2.AbacoDtoCaller;

/**
 * @author Alexandru Paraschiv
 */
public class CreateCalculatorJobCaller extends AbacoDtoCaller<CreateCalculatorJobInput, CreateCalculatorJobOutDTO> {

	public CreateCalculatorJobCaller(GenericCallerService genericCallerService) {
		super(genericCallerService);
	}

}
