package com.abacogroup.agri.applications.core.exceptions;

import io.swagger.v3.oas.annotations.media.Schema;

import jakarta.ws.rs.core.Response;

public class NoApplicationSummaryFoundRuntimeException extends AbstractException {

	private static final NoApplicationSummaryFoundRuntimeException.ErrorBody BODY = new NoApplicationSummaryFoundRuntimeException.ErrorBody();

	public NoApplicationSummaryFoundRuntimeException(String message) {
		super(Response.Status.NOT_FOUND, BODY, message);
	}

	public NoApplicationSummaryFoundRuntimeException() {
		super(Response.Status.NOT_FOUND, BODY, "No summary found");
	}

	@Schema(name = "NoApplicationSummaryFoundRuntimeErrorBody")
	public static class ErrorBody implements ExceptionErrorBody {
		private static final String ERR = "NO_APPLICATION_SUMMARY_FOUND";

		@Override
		@Schema(allowableValues = ERR)
		public String getErrorCode() {
			return ERR;
		}
	}
}
