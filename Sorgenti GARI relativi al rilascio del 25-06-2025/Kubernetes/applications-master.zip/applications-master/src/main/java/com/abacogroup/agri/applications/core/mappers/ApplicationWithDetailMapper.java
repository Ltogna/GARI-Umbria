package com.abacogroup.agri.applications.core.mappers;

import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import com.abacogroup.agri.applications.core.model.dto.publics.ApplicationWithDetailsDTO;
import com.abacogroup.agri.applications.db.ntt.ApplicationWithDetailsNTT;

@Mapper(uses = AbsoluteDateMapper.class)
public interface ApplicationWithDetailMapper extends EntityMapper<ApplicationWithDetailsDTO, ApplicationWithDetailsNTT> {

	ApplicationWithDetailMapper INSTANCE = Mappers.getMapper(ApplicationWithDetailMapper.class);

	@InheritInverseConfiguration()
	ApplicationWithDetailsDTO entityToDto(ApplicationWithDetailsNTT entity);

	@Mapping(source = "applicationId", target = "id")
	@Mapping(source = "partyId", target = "party_id")
	@Mapping(source = "referredYear", target = "referred_year")
	@Mapping(source = "moduleId", target = "module_id")
	@Mapping(source = "processId", target = "process_id")
	@Mapping(source = "applicationCode", target = "application_code")
	@Mapping(source = "processStatus", target = "process_status")
	@Mapping(source = "dtPresentation", target = "dt_presentation")
	@Mapping(source = "sectorDescription", target = "sector_description")
	@Mapping(source = "moduleDescription", target = "module_description")
	@Mapping(source = "sectorCode", target = "sector_code")
	@Mapping(source = "moduleCode", target = "module_code")
	@Mapping(source = "moduleYear", target = "module_year")
	@Mapping(source = "userIdInsert", target = "user_id_insert")
	@Mapping(source = "userIdDelete", target = "user_id_delete")
	@Mapping(source = "dtInsert", target = "dt_insert")
	@Mapping(source = "dtDelete", target = "dt_delete")
	@Mapping(source = "amendmentApplicationId", target = "amended_by_id")
	@Mapping(source = "amendedApplicationId", target = "amend_of_id")
	ApplicationWithDetailsNTT dtoToEntity(ApplicationWithDetailsDTO dto);

}
