package com.abacogroup.agri.applications.core.mappers;

import com.abacogroup.agri.applications.core.model.dto.PartyDTO;
import com.abacogroup.agri.applications.core.model.dto.PartyRegistryDTO;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

@Mapper(uses = AbsoluteDateMapper.class)
public interface PartyRegistryMapper extends EntityMapper<PartyDTO, PartyRegistryDTO> {

	PartyRegistryMapper INSTANCE = Mappers.getMapper(PartyRegistryMapper.class);

	@Mapping(source = "id", target = "partyId")
	@Mapping(expression = "java(getCode(dto))", target = "cuaa")
	@Mapping(expression = "java(getDescription(dto))", target = "description")
	PartyDTO callerOutToDTO(PartyRegistryDTO dto);

	default String getDescription(PartyRegistryDTO pt) {
		List<String> a = new ArrayList<>();
		a.add(pt.getLastName());
		a.add(pt.getFirstName());
		return a.stream().filter(Objects::nonNull).collect(Collectors.joining(" "));
	}

	default String getCode(PartyRegistryDTO pt) {
		return pt.getCode() != null ? pt.getCode() : pt.getTaxCode();
	}

}
