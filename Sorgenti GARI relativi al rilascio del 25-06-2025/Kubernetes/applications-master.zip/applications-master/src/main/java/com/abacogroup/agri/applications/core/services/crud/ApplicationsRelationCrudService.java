package com.abacogroup.agri.applications.core.services.crud;

import com.abacogroup.agri.applications.core.exceptions.ObjectNotFoundException;
import com.abacogroup.agri.applications.core.exceptions.ObjectNotFoundRuntimeException;
import com.abacogroup.agri.applications.core.mappers.ApplicationsRelationMapper;
import com.abacogroup.agri.applications.core.model.dto.ApplicationsRelationDTO;
import com.abacogroup.agri.applications.db.dao.ApplicationsRelationsDAO;
import com.abacogroup.agri.applications.db.ntt.ApplicationsRelationNTT;
import lombok.extern.slf4j.Slf4j;

import java.text.MessageFormat;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * @author Mattia Perini
 */
@Slf4j
public class ApplicationsRelationCrudService
		extends AbstractHistoricizationFieldsCrudService<ApplicationsRelationNTT, Long, ApplicationsRelationDTO, ApplicationsRelationMapper, Void> {

	public ApplicationsRelationCrudService(ApplicationsRelationsDAO dao, ApplicationsRelationMapper mapper) {
		super(dao, mapper);
	}

	@Override
	protected boolean hasPrimaryKey() {
		return true;
	}

	@Override
	protected Void retrieveCustomKeyByResultSet(ApplicationsRelationNTT rs) {
		return null;
	}

	@Override
	protected ApplicationsRelationNTT adjustR(ApplicationsRelationNTT rs) throws Exception {
		return rs;
	}

	@Override
	protected Optional<ApplicationsRelationNTT> findRsByCustomKey(Void customKey) {
		return Optional.empty();
	}

	public ApplicationsRelationDTO findById(Long key) throws ObjectNotFoundException {
		log.info("Invoking find by  with params key: {}", key);
		return this.findOutDtoByPrimaryKey(key);
	}

	public List<ApplicationsRelationDTO> findByParentApplicationId(Long parentApplicationId) {
		log.info("Invoking findByParentApplicationId with params parentApplicationId: {}", parentApplicationId);
		return ((ApplicationsRelationsDAO) this.dao).findByParentApplicationId(parentApplicationId).stream()
				.map(mapper::entityToDto)
				.collect(Collectors.toList());
	}

	public ApplicationsRelationDTO findByParentApplicationIdAndModuleCode(Long parentApplicationId, String moduleCode) {
		log.info("Invoking findByParentApplicationIdAndModuleCode with params parentApplicationId: {} moduleCode: {}", parentApplicationId, moduleCode);
		return ((ApplicationsRelationsDAO) this.dao).findByParentApplicationIdAndModuleCode(parentApplicationId, moduleCode).stream()
				.map(mapper::entityToDto)
				.findFirst()
				.orElseThrow(() -> new ObjectNotFoundRuntimeException(MessageFormat.format("Relation with parent application id {0} and child module {1} not found", parentApplicationId, moduleCode)));
	}

	public ApplicationsRelationDTO findByChildApplicationId(Long childApplicationId) {
		log.info("Invoking findByChildApplicationId with params childApplicationId: {}", childApplicationId);
		return ((ApplicationsRelationsDAO) this.dao).findByChildApplicationId(childApplicationId).stream()
				.map(mapper::entityToDto)
				.findFirst()
				.orElseThrow(ObjectNotFoundRuntimeException::new);
	}

	public ApplicationsRelationDTO insert(ApplicationsRelationDTO in, String username) {
		log.info("Invoking insert with params in: {} username: {}", in, username);
		return this.insert(in, username, null, this.dao.getCurrentTimestamp());
	}

	public ApplicationsRelationDTO update(Long key, ApplicationsRelationDTO in, String username) {
		log.info("Invoking update with params key: {} in: {} username: {}", key, in, username);
		return this.update(key, in, username, null);
	}

	public void delete(Long key, String username) {
		log.info("Invoking delete with params key: {} username: {}", key, username);
		this.delete(key, username, null);
	}

	public ApplicationsRelationDTO findByParentApplicationIdAndChildApplicationId(Long parentApplicationId, Long childApplicationId) {
		log.info("Invoking findByParentApplicationIdAndChildApplicationId with params parentApplicationId: {} childApplicationId: {}", parentApplicationId, childApplicationId);
		return findOptByParentApplicationIdAndChildApplicationId(parentApplicationId, childApplicationId).orElseThrow(ObjectNotFoundRuntimeException::new);
	}

	public Optional<ApplicationsRelationDTO> findOptByParentApplicationIdAndChildApplicationId(Long parentApplicationId, Long childApplicationId) {
		log.info("Invoking findOptByParentApplicationIdAndChildApplicationId with params parentApplicationId: {} childApplicationId: {}", parentApplicationId, childApplicationId);
		return  returnOptionalRecord(((ApplicationsRelationsDAO) this.dao).findByParentApplicationIdAndChildApplicationId(parentApplicationId, childApplicationId));
	}
}
