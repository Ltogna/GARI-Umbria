package com.abacogroup.agri.applications.db.ntt.compoundkeys;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The type Application env key.
 * @author Carlo Sindico
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ApplicationEnvKey {
    private String tenant_id;
    private String key_;
    private Integer fl_client;

}
