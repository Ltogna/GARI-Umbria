package com.abacogroup.agri.applications.bundles.processor.anomaly;

import com.abacogroup.agri.applications.bundles.model.I18nPair;
import com.abacogroup.agri.applications.bundles.model.anomaly.BundleAnomalyCatalogInDTO;
import com.abacogroup.agri.applications.bundles.model.anomaly.BundleAnomalyCatalogMessage;
import com.abacogroup.agri.applications.core.services.crud.AnomalyCatalogCrudService;
import com.abacogroup.agri.applications.db.ntt.AnomalyCatalogWIthModuleCodeNTT;
import com.abacogroup.agri.applications.db.ntt.applications.RsI18N;
import com.abacogroup.bundles.listener.tenant.TenantMessage;
import com.abacogroup.bundles.listener.tenant.TenantMessageProcessor;
import lombok.extern.slf4j.Slf4j;
import org.jdbi.v3.core.Jdbi;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import static com.abacogroup.agri.applications.bundles.BundleConstants.TENANT_TEMPLATE_CODE;

/**
 * @author Gennaro Tamburrelli
 */
@Slf4j
public class AnomalyCatalogNewTenantProcessor implements TenantMessageProcessor {

	protected final Jdbi jdbi;
	protected final AnomalyCatalogBundleWorker anomalyCatalogBundleWorker;

	public AnomalyCatalogNewTenantProcessor(Jdbi jdbi, AnomalyCatalogBundleWorker anomalyCatalogBundleWorker) {
		this.jdbi = jdbi;
		this.anomalyCatalogBundleWorker = anomalyCatalogBundleWorker;
	}

	@Override
	public void onMessage(TenantMessage message) {
		jdbi.useTransaction(handle -> {
			log.info("AnomalyCatalogNewTenantProcessor got new tenant {}", message.getTenantId());
			checkAndInsertAnomalyCatalog(message.getTenantId());
			log.info("AnomalyCatalogNewTenantProcessor end working with new tenant {}", message.getTenantId());
		});
	}

	private void checkAndInsertAnomalyCatalog(String tenantId) {
		log.info("SectorNewTenantProcessor check and insert new tenant {}", tenantId);
		AnomalyCatalogCrudService anomalyCatalogCrudService = anomalyCatalogBundleWorker.exposeAnomalyCatalogCrudService();
		List<AnomalyCatalogWIthModuleCodeNTT> asteriskAnomalies = anomalyCatalogCrudService.findAllByTenant(TENANT_TEMPLATE_CODE);
		anomalyCatalogBundleWorker.upsertBundleAnomalyCatalog(tenantId,
				BundleAnomalyCatalogMessage.builder()
						.anomalies(asteriskAnomalies
								.stream()
								.map(anomaly -> BundleAnomalyCatalogInDTO.builder()
										.anomalyCode(anomaly.getAnomaly_code())
										.moduleCode(anomaly.getModule_code())
										.severity(anomaly.getSeverity())
										.i18n(mapI18NList(TENANT_TEMPLATE_CODE, anomaly.getAnomaly_code()))
										.build())
								.collect(Collectors.toList()))
						.build());
	}

	private List<I18nPair> mapI18NList(String tenantId, String anomalyCode) {
		var mapLang = anomalyCatalogBundleWorker.exposeAnomalyCatalogCrudService()
				.getAllAnomalyCatalogI18NByTenantAndCode(tenantId, anomalyCode)
				.stream()
				.collect(Collectors.groupingBy(RsI18N::getLang));
		List<I18nPair> records = new ArrayList<>();
		mapLang.forEach((lang, item) -> records.add(I18nPair.builder()
				.lang(lang)
				.description(extractI18NText(item, AnomalyCatalogCrudService.ANOMALY_CATALOG_I18N.ANOMALY_CODE.getCode()))
				.build()));

		return records;
	}

	private String extractI18NText(List<RsI18N> items, String field) {
		return items
				.stream()
				.filter(x -> field.equals(x.getField_name()))
				.findFirst()
				.map(RsI18N::getI18n_text)
				.orElse(null);
	}
}
