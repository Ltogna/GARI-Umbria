package com.abacogroup.agri.applications.core.mappers;

import com.abacogroup.agri.applications.core.model.dto.publics.ApplicationWithDetailsDTO;
import com.abacogroup.applicationworkflowsdk.model.io.output.ApplicationDetailsPublicDTO;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

@Mapper
public interface ApplicationDetailsPublicMapper extends EntityMapper<ApplicationDetailsPublicDTO, ApplicationWithDetailsDTO> {

	ApplicationDetailsPublicMapper INSTANCE = Mappers.getMapper(ApplicationDetailsPublicMapper.class);

	@InheritInverseConfiguration()
	ApplicationDetailsPublicDTO entityToDto(ApplicationWithDetailsDTO entity);

	@Mapping(source = "applicationId", target = "applicationId")
	@Mapping(source = "applicationCode", target = "applicationCode")
	@Mapping(source = "partyId", target = "partyId")
	@Mapping(source = "referredYear", target = "referredYear")
	@Mapping(source = "processStatus", target = "processStatus")
	@Mapping(source = "processId", target = "processId")
	@Mapping(source = "dtPresentation", target = "dtPresentation")
	@Mapping(source = "sectorDescription", target = "sectorDescription")
	@Mapping(source = "moduleDescription", target = "moduleDescription")
	ApplicationWithDetailsDTO dtoToEntity(ApplicationDetailsPublicDTO dto);

}
