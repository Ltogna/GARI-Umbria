package com.abacogroup.agri.applications.bundles.processor.childmodule;

import com.abacogroup.agri.applications.bundles.model.chilldmodule.BundleChildModuleInDTO;
import com.abacogroup.agri.applications.bundles.model.chilldmodule.BundleChildrenModulesMessage;
import com.abacogroup.agri.applications.core.exceptions.ObjectNotFoundException;
import com.abacogroup.agri.applications.core.exceptions.ObjectNotFoundRuntimeException;
import com.abacogroup.agri.applications.core.model.dto.ChildModuleDTO;
import com.abacogroup.agri.applications.core.model.dto.ModuleDTO;
import com.abacogroup.agri.applications.core.services.crud.ChildModuleCrudService;
import com.abacogroup.agri.applications.core.services.crud.ModuleCrudService;
import com.abacogroup.bundles.listener.tenant.TenantMessage;
import com.abacogroup.bundles.listener.tenant.TenantMessageProcessor;
import lombok.extern.slf4j.Slf4j;
import org.jdbi.v3.core.Jdbi;

import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import static com.abacogroup.agri.applications.bundles.BundleConstants.TENANT_TEMPLATE_CODE;

/**
 * @author Mattia Perini
 */
@Slf4j
public class ChildModuleNewTenantProcessor implements TenantMessageProcessor {

    protected final Jdbi jdbi;
    protected final ChildrenModulesBundleWorker childrenModulesBundleWorker;

    public ChildModuleNewTenantProcessor(Jdbi jdbi, ChildrenModulesBundleWorker childrenModulesBundleWorker) {
        this.jdbi = jdbi;
        this.childrenModulesBundleWorker = childrenModulesBundleWorker;
    }

    @Override
    public void onMessage(TenantMessage message) {
        jdbi.useTransaction(handle -> {
            log.info("ChildModuleNewTenantProcessor got new tenant {}", message.getTenantId());
            checkAndInsertChildrenModules(message.getTenantId());
            log.info("ChildModuleNewTenantProcessor end working with new tenant {}", message.getTenantId());
        });
    }



    private void checkAndInsertChildrenModules(String tenantId) {
        log.info("ChildModuleNewTenantProcessor check and insert new tenant {}", tenantId);
        ChildModuleCrudService childModuleCrudService = childrenModulesBundleWorker.exposeChildModuleCrudService();
        ModuleCrudService moduleCrudService = childrenModulesBundleWorker.exposeModuleCrudService();

        List<BundleChildModuleInDTO> bundleChildModuleInDTOS = new ArrayList<>();

        List<ChildModuleDTO> childModuleDTOS = childModuleCrudService.findAllByTenant(TENANT_TEMPLATE_CODE).stream()
                .distinct()
                .collect(Collectors.toList());


        childModuleDTOS.forEach(childModuleDTO -> {
            ModuleDTO module = moduleCrudService.findById(childModuleDTO.getModuleId())
                    .orElseThrow(() -> new ObjectNotFoundRuntimeException(MessageFormat.format("Module with id: {0} not found", childModuleDTO.getModuleId())));
            ModuleDTO parentModule = moduleCrudService.findById(childModuleDTO.getParentModuleId())
                    .orElseThrow(() -> new ObjectNotFoundRuntimeException(MessageFormat.format("Module with id: {0} not found", childModuleDTO.getParentModuleId())));

            bundleChildModuleInDTOS.add(BundleChildModuleInDTO.builder()
                            .sectorCode(getSectorCode(module))
                            .moduleCode(module.getModuleCode())
                            .parentModuleCode(parentModule.getModuleCode())
                    .build());

        });
        childrenModulesBundleWorker.upsertBundleChildrenModules(tenantId, BundleChildrenModulesMessage.builder()
                        .childrenModules(bundleChildModuleInDTOS)
                .build());

    }

    private String getSectorCode(ModuleDTO module) {
        try {
            return childrenModulesBundleWorker.exposeSectorCrudService()
                    .findById(TENANT_TEMPLATE_CODE, module.getSectorId())
                    .getSectorCode();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}
