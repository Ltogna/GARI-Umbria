package com.abacogroup.agri.applications.core.services.crud;

import com.abacogroup.agri.applications.core.exceptions.ObjectNotFoundException;
import com.abacogroup.agri.applications.core.mappers.AnomalyCatalogMapper;
import com.abacogroup.agri.applications.core.model.dto.publics.AnomalyCatalogDTO;
import com.abacogroup.agri.applications.core.services.I18NService;
import com.abacogroup.agri.applications.db.dao.AnomalyCatalogDAO;
import com.abacogroup.agri.applications.db.ntt.AnomalyCatalogNTT;
import com.abacogroup.agri.applications.db.ntt.AnomalyCatalogWIthModuleCodeNTT;
import com.abacogroup.agri.applications.db.ntt.applications.RsI18N;
import com.abacogroup.agri.applications.db.ntt.compoundkeys.AnomalyCatalogKey;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.NotImplementedException;

import java.util.List;
import java.util.Optional;

/**
 * @author Gennaro Tamburrelli
 */
@Slf4j
public class AnomalyCatalogCrudService
		extends AbstractCrudService<AnomalyCatalogNTT, AnomalyCatalogKey, AnomalyCatalogDTO, AnomalyCatalogMapper, AnomalyCatalogKey> {

	private final I18NService i18NService;
	public static final String I18N_ANOMALY_CATALOG_TABLE = "apps_anomaly_catalog";

	public AnomalyCatalogCrudService(AnomalyCatalogDAO dao, AnomalyCatalogMapper mapper, I18NService i18NService) {
		super(dao, mapper);
		this.i18NService = i18NService;
	}

	@Override
	protected boolean hasPrimaryKey() {
		return false;
	}

	@Override protected AnomalyCatalogKey retrievePrimaryKey(AnomalyCatalogKey customKey) {
		return customKey;
	}

	@Override
	protected Optional<AnomalyCatalogNTT> findRsByCustomKey(AnomalyCatalogKey customKey) {
		return this.dao.findById(customKey).stream().findFirst();
	}

	@Override
	protected void deleteByCustomKey(AnomalyCatalogKey customKey) {
		throw new NotImplementedException("Not implemented.");
	}

	@Override
	protected void setCustomSearchKey(AnomalyCatalogNTT rs, AnomalyCatalogKey customKey) {
		throw new NotImplementedException("Not implemented.");
	}

	public List<AnomalyCatalogWIthModuleCodeNTT> findAllByTenant(String tenant) {
		return ((AnomalyCatalogDAO) this.dao).findAllByTenant(tenant);
	}

	public AnomalyCatalogDTO insert(AnomalyCatalogDTO in) {
		log.info("Invoking insert with params in: {}", in);
		return this.insert(in, AnomalyCatalogKey.builder()
				.module_id(in.getModuleId())
				.anomaly_code(in.getAnomalyCode())
				.build());
	}

	public AnomalyCatalogDTO update(AnomalyCatalogKey key, AnomalyCatalogDTO in) {
		log.info("Invoking update with params key: {} in: {}", key, in);
		return this.update(null, in, key);
	}

	public void delete(AnomalyCatalogKey key) {
		log.info("Invoking delete with params key: {}", key);
		this.delete(null, key);
	}

	public void deleteByIdAndModuleId(String key, Long moduleId) {
		log.info("Invoking delete with params key: {}, moduleId: {}", key, moduleId);
		((AnomalyCatalogDAO) this.dao).deleteByIdAndModuleId(key, moduleId);
	}

	public AnomalyCatalogDTO findById(AnomalyCatalogKey anomalyCode) throws ObjectNotFoundException {
		log.info("Invoking findById with params anomalyCode: {} ", anomalyCode);
		return returnOptionalRecord(this.dao.findById(anomalyCode))
				.orElseThrow(OBJECT_NOT_FOUND_EXCEPTION_SUPPLIER);
	}

	public void insertAnomalyCatalogI18N(String tenant, String code, String lang, String description) {
		this.i18NService.insertI18N(tenant, I18N_ANOMALY_CATALOG_TABLE, ANOMALY_CATALOG_I18N.ANOMALY_CODE.code, lang, code, description);
	}

	public void deleteAnomalyCatalogI18N(String tenant, String code, String lang) {
		this.i18NService.deleteI18N(tenant, I18N_ANOMALY_CATALOG_TABLE, ANOMALY_CATALOG_I18N.ANOMALY_CODE.code, code, lang);
	}

	public List<RsI18N> getAllAnomalyCatalogI18NByTenantAndCode(String tenant, String code) {
		return this.i18NService.getAllI18NbyCode(tenant, I18N_ANOMALY_CATALOG_TABLE, code);
	}

	public enum ANOMALY_CATALOG_I18N {
		ANOMALY_CODE("anomaly_code");

		private final String code;

		ANOMALY_CATALOG_I18N(String val) {
			this.code = val;
		}

		public String getCode() {
			return this.code;
		}
	}

}
