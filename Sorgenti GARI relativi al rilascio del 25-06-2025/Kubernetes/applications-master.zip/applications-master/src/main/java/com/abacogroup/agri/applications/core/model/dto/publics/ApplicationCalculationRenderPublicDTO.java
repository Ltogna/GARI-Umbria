package com.abacogroup.agri.applications.core.model.dto.publics;

import com.abacogroup.agri.applications.core.model.dto.CalculatorRenderResponse;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

/**
 * @author Alexandru Paraschiv
 */
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class ApplicationCalculationRenderPublicDTO {
	private CalculatorRenderResponse result;
}
