package com.abacogroup.agri.applications.core.model.dto.publics;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author Mattia Perini
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class SectorPublicDTO {
	@Schema(description = "The sector id")
	private Long sectorId;
	@Schema(description = "The sector code")
	private String sectorCode;
	@Schema(description = "The sector description")
	private String description;
}
