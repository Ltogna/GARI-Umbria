package com.abacogroup.agri.applications.core.model.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author Gennaro Tamburrelli
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class ProtocolsPayload {
	private Long application_id;
	private String tenant;
	private String protocol;
	private String dt_protocol;
}
