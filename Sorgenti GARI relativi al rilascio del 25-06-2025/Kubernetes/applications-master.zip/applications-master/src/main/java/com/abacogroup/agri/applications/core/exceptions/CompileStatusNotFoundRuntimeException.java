package com.abacogroup.agri.applications.core.exceptions;

import io.swagger.v3.oas.annotations.media.Schema;

import jakarta.ws.rs.core.Response;

public class CompileStatusNotFoundRuntimeException extends AbstractException {

	private static final CompileStatusNotFoundRuntimeException.ErrorBody BODY = new CompileStatusNotFoundRuntimeException.ErrorBody();

	public CompileStatusNotFoundRuntimeException(String message) {
		super(Response.Status.NOT_FOUND, BODY, message);
	}

	@Schema(name = "CompileStatusNotFoundRuntimeExceptionErrorBody")
	public static class ErrorBody implements ExceptionErrorBody {
		private static final String ERR = "COMPILE_STATUS_NOT_FOUND_ERROR";

		@Override
		@Schema(allowableValues = ERR)
		public String getErrorCode() {
			return ERR;
		}
	}
}
