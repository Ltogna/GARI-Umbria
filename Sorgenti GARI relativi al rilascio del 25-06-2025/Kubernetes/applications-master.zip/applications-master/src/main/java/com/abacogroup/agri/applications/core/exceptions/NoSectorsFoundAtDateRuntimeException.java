package com.abacogroup.agri.applications.core.exceptions;

import io.swagger.v3.oas.annotations.media.Schema;

import jakarta.ws.rs.core.Response;

public class NoSectorsFoundAtDateRuntimeException extends AbstractException {

	private static final NoSectorsFoundAtDateRuntimeException.ErrorBody BODY = new NoSectorsFoundAtDateRuntimeException.ErrorBody();

	public NoSectorsFoundAtDateRuntimeException(String message) {
		super(Response.Status.NOT_FOUND, BODY, message);
	}

	public NoSectorsFoundAtDateRuntimeException() {
		super(Response.Status.NOT_FOUND, BODY, "No sectors found");
	}

	@Schema(name = "NoSectorsFoundAtDateRuntimeExceptionErrorBody")
	public static class ErrorBody implements ExceptionErrorBody {
		private static final String ERR = "NO_SECTORS_FOUND_WITH_SECTOR_AND_MODULE_AT_DATE";

		@Override
		@Schema(allowableValues = ERR)
		public String getErrorCode() {
			return ERR;
		}
	}
}
