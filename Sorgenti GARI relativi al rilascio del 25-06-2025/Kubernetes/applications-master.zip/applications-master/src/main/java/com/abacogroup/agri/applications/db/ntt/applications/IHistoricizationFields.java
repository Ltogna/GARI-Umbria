package com.abacogroup.agri.applications.db.ntt.applications;

import java.time.LocalDateTime;

/**
 * @author Gennaro Tamburrelli
 */
public interface IHistoricizationFields {
	String getUser_id_insert();

	void setUser_id_insert(String userId);

	String getUser_id_delete();

	void setUser_id_delete(String userId);

	LocalDateTime getDt_insert();

	void setDt_insert(LocalDateTime dt);

	LocalDateTime getDt_delete();

	void setDt_delete(LocalDateTime dt);
}
