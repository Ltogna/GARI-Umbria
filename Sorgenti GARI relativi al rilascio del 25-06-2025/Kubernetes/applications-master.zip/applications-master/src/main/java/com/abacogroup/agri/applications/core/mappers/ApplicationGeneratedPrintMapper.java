package com.abacogroup.agri.applications.core.mappers;

import com.abacogroup.agri.applications.core.model.dto.ApplicationGeneratedPrintDTO;
import com.abacogroup.agri.applications.db.ntt.ApplicationGeneratedPrintNTT;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

@Mapper(uses = AbsoluteDateMapper.class)
public interface ApplicationGeneratedPrintMapper extends EntityMapper<ApplicationGeneratedPrintDTO, ApplicationGeneratedPrintNTT> {

	ApplicationGeneratedPrintMapper INSTANCE = Mappers.getMapper(ApplicationGeneratedPrintMapper.class);

	@InheritInverseConfiguration()
	ApplicationGeneratedPrintDTO entityToDto(ApplicationGeneratedPrintNTT entity);

	@Mapping(source = "pkid", target = "pkid")
	@Mapping(source = "applicationId", target = "application_id")
	@Mapping(source = "printCode", target = "print_code")
	@Mapping(source = "processStatus", target = "process_status")
	@Mapping(source = "printDescription", target = "print_description")
	@Mapping(source = "printDate", target = "print_date")
	@Mapping(source = "printJobUuid", target = "print_job_uuid")
	@Mapping(source = "fileId", target = "file_id")
	@Mapping(source = "username", target = "username")
	@Mapping(source = "printStatus", target = "status")
	ApplicationGeneratedPrintNTT dtoToEntity(ApplicationGeneratedPrintDTO dto);
}
