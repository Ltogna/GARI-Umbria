package com.abacogroup.agri.applications.core.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author Gennaro Tamburrelli
 */
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Data
public class QueueProcessorConfig {

	private Integer numThreads;
	private Integer timeoutMs;
}
