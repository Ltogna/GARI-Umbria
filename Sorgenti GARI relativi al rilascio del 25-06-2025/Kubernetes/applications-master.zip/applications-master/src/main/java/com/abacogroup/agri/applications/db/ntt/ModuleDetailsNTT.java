package com.abacogroup.agri.applications.db.ntt;

import com.abacogroup.agri.applications.db.ntt.applications.IHistoricizationFields;
import com.abacogroup.agri.applications.db.ntt.applications.IIdRs;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.Optional;

/**
 * @author Gennaro Tamburrelli
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ModuleDetailsNTT implements IIdRs<Long>, IHistoricizationFields {

	private Long pkid;
	private Long module_id;
	private Integer annuality;
	private String context_function;
	private String force_read_only_context_function;
	private String dt_validity_start;
	private String dt_validity_end;
	private String user_id_insert;
	private String user_id_delete;
	private LocalDateTime dt_insert;
	private LocalDateTime dt_delete;

	@Override public void setKey(Long id) {
		this.pkid = id;
	}

	@Override public Optional<Long> getKey() {
		return Optional.ofNullable(this.pkid);
	}
}
