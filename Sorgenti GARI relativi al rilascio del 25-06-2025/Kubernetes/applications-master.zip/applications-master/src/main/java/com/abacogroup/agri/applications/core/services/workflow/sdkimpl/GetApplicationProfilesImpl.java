package com.abacogroup.agri.applications.core.services.workflow.sdkimpl;

import com.abacogroup.agri.applications.core.mappers.ApplicationProfilePublicMapper;
import com.abacogroup.agri.applications.core.services.crud.ApplicationProfilesCrudService;
import com.abacogroup.agri.applications.core.services.crud.ApplicationsCrudService;
import com.abacogroup.agri.applications.core.services.crud.ModuleProfilesCrudService;
import com.abacogroup.applicationworkflowsdk.model.io.output.ApplicationProfilePublicDTO;
import com.abacogroup.applicationworkflowsdk.model.io.output.ModuleProfileDTO;
import com.abacogroup.applicationworkflowsdk.service.GetApplicationProfiles;

import java.util.List;
import java.util.stream.Collectors;

/**
 * @author Gennaro Tamburrelli
 */
public class GetApplicationProfilesImpl implements GetApplicationProfiles {

	private final ApplicationsCrudService applicationsCrudService;
	private final ModuleProfilesCrudService moduleProfilesCrudService;
	private final ApplicationProfilesCrudService applicationProfilesCrudService;

	public GetApplicationProfilesImpl(ApplicationsCrudService applicationsCrudService,
			ModuleProfilesCrudService moduleProfilesCrudService,
			ApplicationProfilesCrudService applicationProfilesCrudService) {
		this.applicationsCrudService = applicationsCrudService;
		this.moduleProfilesCrudService = moduleProfilesCrudService;
		this.applicationProfilesCrudService = applicationProfilesCrudService;
	}

	@Override
	public List<ApplicationProfilePublicDTO> getAllApplicationProfiles(String tenant, Long applicationId, String locale) {
		return applicationProfilesCrudService.findAll(tenant, applicationId, locale)
				.stream()
				.map(ApplicationProfilePublicMapper.INSTANCE::dtoToPublic)
				.collect(Collectors.toList());
	}

	@Override
	public List<ModuleProfileDTO> getAllModuleProfiles(String tenant, Long applicationId, String locale) {
		var app = applicationsCrudService.findWithDetailsByApplicationId(tenant, applicationId);
		return moduleProfilesCrudService.findWithLocale(tenant, app.getModuleId(), locale);
	}
}
