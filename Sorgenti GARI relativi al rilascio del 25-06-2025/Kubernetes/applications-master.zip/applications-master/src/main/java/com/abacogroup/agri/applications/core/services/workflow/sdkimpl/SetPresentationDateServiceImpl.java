package com.abacogroup.agri.applications.core.services.workflow.sdkimpl;

import com.abacogroup.agri.applications.core.exceptions.ApplicationNotFoundRuntimeException;
import com.abacogroup.agri.applications.core.exceptions.ObjectNotFoundException;
import com.abacogroup.agri.applications.core.services.crud.ApplicationDetailsCrudService;
import com.abacogroup.applicationworkflowsdk.service.SetApplicationPresentationDate;
import lombok.extern.slf4j.Slf4j;

import java.time.LocalDateTime;
import java.util.Optional;

/**
 * @author Gennaro Tamburrelli
 */
@Slf4j
public class SetPresentationDateServiceImpl implements SetApplicationPresentationDate {

	private final ApplicationDetailsCrudService applicationDetailsCrudService;

	public SetPresentationDateServiceImpl(ApplicationDetailsCrudService applicationDetailsCrudService) {
		this.applicationDetailsCrudService = applicationDetailsCrudService;
	}

	public void conditionallySetPresentationDate(String tenant, Long applicationId, String userid) {
		try {
			var appDetails = applicationDetailsCrudService.findApplicationDetailById(tenant, applicationId);
			Optional.ofNullable(appDetails.getDtPresentation()).ifPresentOrElse(date -> log.info("application presentation date is already set"),
					() -> {
						appDetails.setDtPresentation(LocalDateTime.now());
						applicationDetailsCrudService.update(appDetails.getPkid(), appDetails, userid);
						log.info("application presentation date set");
					});
		} catch (ObjectNotFoundException e) {
			throw new ApplicationNotFoundRuntimeException("application not found");
		}

	}

	@Override
	public void setPresentationDate(String tenant, Long applicationId, String username) {
		this.conditionallySetPresentationDate(tenant, applicationId, username);
	}
}
