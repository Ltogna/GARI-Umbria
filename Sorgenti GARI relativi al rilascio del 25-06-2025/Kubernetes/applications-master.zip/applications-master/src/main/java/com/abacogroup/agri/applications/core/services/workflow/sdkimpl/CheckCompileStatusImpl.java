package com.abacogroup.agri.applications.core.services.workflow.sdkimpl;

import com.abacogroup.agri.applications.core.services.crud.ApplicationCompileStatusCrudService;
import com.abacogroup.applicationworkflowsdk.model.io.output.ApplicationCompileStatusDTO;
import com.abacogroup.applicationworkflowsdk.service.CheckCompileStatus;

import java.util.List;

/**
 * @author Gennaro Tamburrelli
 */
public class CheckCompileStatusImpl implements CheckCompileStatus {

	private final ApplicationCompileStatusCrudService applicationCompileStatusCrudService;

	public CheckCompileStatusImpl(ApplicationCompileStatusCrudService applicationCompileStatusCrudService) {
		this.applicationCompileStatusCrudService = applicationCompileStatusCrudService;
	}

	@Override public List<ApplicationCompileStatusDTO> getStatuses(String tenant, Long applicationId) {
		return this.applicationCompileStatusCrudService.find(tenant, applicationId);
	}
}
