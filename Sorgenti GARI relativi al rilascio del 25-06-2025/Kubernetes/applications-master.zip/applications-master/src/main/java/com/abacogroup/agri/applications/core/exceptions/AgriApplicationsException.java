package com.abacogroup.agri.applications.core.exceptions;

public class AgriApplicationsException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 748787262154109107L;

	public AgriApplicationsException(String errorMessage, Throwable err) {
		super(errorMessage, err);
	}

	public AgriApplicationsException(String errorMessage) {
		super(errorMessage);
	}

	public AgriApplicationsException(Throwable err) {
		super(err);
	}
}
