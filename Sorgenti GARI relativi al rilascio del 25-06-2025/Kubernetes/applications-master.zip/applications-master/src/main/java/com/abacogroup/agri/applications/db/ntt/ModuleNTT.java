package com.abacogroup.agri.applications.db.ntt;

import com.abacogroup.agri.applications.db.ntt.applications.IHistoricizationFields;
import com.abacogroup.agri.applications.db.ntt.applications.IIdRs;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.time.LocalDateTime;
import java.util.Optional;

/**
 * @author Alexandru Paraschiv
 */
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class ModuleNTT implements IIdRs<Long>, IHistoricizationFields {

	private Long id;
	private String module_code;
	private Long sector_id;
	private String workflow_code;
	private String user_id_insert;
	private String user_id_delete;
	private LocalDateTime dt_insert;
	private LocalDateTime dt_delete;
	private Integer fl_amend_module;
	private Integer fl_child_module;

	@Override
	public Optional<Long> getKey() {
		return Optional.ofNullable(getId());
	}

	@Override
	public void setKey(Long id) {
		setId(id);
	}
}
