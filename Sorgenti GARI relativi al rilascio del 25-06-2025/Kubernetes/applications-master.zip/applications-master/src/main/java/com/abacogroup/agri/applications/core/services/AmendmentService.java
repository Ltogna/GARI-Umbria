package com.abacogroup.agri.applications.core.services;

import com.abacogroup.agri.applications.core.exceptions.ApplicationNotFoundRuntimeException;
import com.abacogroup.agri.applications.core.exceptions.ObjectNotFoundException;
import com.abacogroup.agri.applications.core.exceptions.ObjectNotFoundRuntimeException;
import com.abacogroup.agri.applications.core.model.AbsoluteDate;
import com.abacogroup.agri.applications.core.model.dto.AmendableModuleDTO;
import com.abacogroup.agri.applications.core.model.dto.ApplicationDetailsDTO;
import com.abacogroup.agri.applications.core.model.dto.ModuleDTO;
import com.abacogroup.agri.applications.core.model.dto.ModuleWithDetailDTO;
import com.abacogroup.agri.applications.core.model.dto.publics.ApplicationDTO;
import com.abacogroup.agri.applications.core.model.dto.publics.ApplicationWithDetailsDTO;
import com.abacogroup.agri.applications.core.services.crud.AmendableModuleCrudService;
import com.abacogroup.agri.applications.core.services.crud.ApplicationDetailsCrudService;
import com.abacogroup.agri.applications.core.services.crud.ApplicationsCrudService;
import com.abacogroup.agri.applications.core.services.crud.ModuleCrudService;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.jdbi.paging.impl.InfiniteListResultsImpl;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import jakarta.ws.rs.core.SecurityContext;

import java.text.MessageFormat;
import java.time.LocalDate;
import java.util.Collection;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * The type Amendment service.
 *
 * @author Mattia Perini
 * @author Samuele Sbarbaro
 * @author Mauro Pozzana
 * @author Carlo Sindico
 */
@Slf4j
public class AmendmentService {
    // TODO move constants to dedicated class - better move to a table, child of amendable module table
    private static final String PROCESS_STATUS_DELETED = "DELETED";
    private static final String PROCESS_STATUS_PROTOCOLED = "PROTOCOLED";
    private static final String PROCESS_STATUS_COMPLIANT = "COMPLIANT";
    private static final Integer FIND_ONLY_AMEND_MODULES = 1;

    private final ApplicationsCrudService applicationsCrudService;
    private final ModuleCrudService moduleCrudService;
    private final AmendableModuleCrudService amendableModuleCrudService;
    private final ApplicationDetailsCrudService applicationDetailsCrudService;

    public AmendmentService(ModuleCrudService moduleCrudService,
                            ApplicationsCrudService applicationsCrudService,
                            AmendableModuleCrudService amendableModuleCrudService,
                            ApplicationDetailsCrudService applicationDetailsCrudService) {
        this.moduleCrudService = moduleCrudService;
        this.amendableModuleCrudService = amendableModuleCrudService;
        this.applicationsCrudService = applicationsCrudService;
        this.applicationDetailsCrudService = applicationDetailsCrudService;
    }

    public InfiniteListResults<ModuleWithDetailDTO> getAmendmentModules(final String tenant, final Long applicationId, String nextKey, SecurityContext sc) {
        ApplicationDTO applicationDTO = applicationsCrudService.findById(applicationId)
                .orElseThrow(() -> new ApplicationNotFoundRuntimeException(MessageFormat.format("Application with id {0} not found", applicationId)));

        List<AmendableModuleDTO> amendableModules = amendableModuleCrudService.findByAmendableModuleId(tenant, applicationDTO.getModuleId());
        List<Long> amendableModuleIds = amendableModules.stream().map(AmendableModuleDTO::getModuleId).collect(Collectors.toList());

        log.info("Found {} amendable modules with the module id {}", amendableModules.size(), applicationDTO.getModuleId());

        List<ModuleWithDetailDTO> moduleWithDetails = moduleCrudService.findModulesWithDetailByModuleIds(tenant, amendableModuleIds,
                        FIND_ONLY_AMEND_MODULES, new AbsoluteDate(LocalDate.now())).stream()
                .filter(x -> StringUtils.isAllBlank(x.getContextFunction()) || Optional.ofNullable(sc)
                        .map(xsc -> xsc.isUserInRole(x.getContextFunction()))
                        .orElse(true))
                .collect(Collectors.toList());

        return new InfiniteListResultsImpl<>(moduleWithDetails, nextKey);
    }

    public Long getOriginalAmendedApplicationId(ApplicationWithDetailsDTO application, String tenant) {

        if (application.getAmendedApplicationId() != null) {
            do {
                application = applicationsCrudService.findWithDetailsByApplicationId(tenant, application.getAmendedApplicationId());
            } while (application.getAmendedApplicationId() != null);
            return application.getApplicationId();
        } else {
            return null;
        }
    }

    public Boolean checkAmendmentStatus(String tenant, String moduleCode) {
        Optional<ModuleDTO> module = moduleCrudService.findByCode(tenant, moduleCode);

        // verify module fl amendable status
        boolean isAmendModule = false;
        if (module.isPresent()) {
            //check if exist a valid amend module for this module
            List<AmendableModuleDTO> amendableModules = amendableModuleCrudService.findByAmendableModuleId(tenant, module.get().getModuleId());
            isAmendModule = amendableModules.stream().anyMatch(m -> isAmendModule(tenant, m.getModuleId()));
        }

        return isAmendModule;
    }

    public List<ModuleWithDetailDTO> getAmendableModulesByApplicationId(String tenant, Long applicationId,
                                                                        SecurityContext securityContext) throws ObjectNotFoundException {
        var app = applicationsCrudService.findWithDetailsByApplicationId(tenant, applicationId);
        return amendableModuleCrudService.findByAmendableModuleId(tenant, app.getModuleId())
                .stream()
                .filter(x -> isAmendModule(tenant, x.getModuleId()))
                .map(x -> moduleCrudService.findValidAmendModulesWithDetailByModuleId(tenant, x.getModuleId(), 1, new AbsoluteDate(LocalDate.now())))
                .flatMap(Collection::stream)
                .filter(x -> securityContext == null || x.getContextFunction() == null || securityContext.isUserInRole(x.getContextFunction()))
                .collect(Collectors.toList());
    }

    public Boolean isApplicationAmendable(String tenant, Long amendmentApplicationId) {
        try {
            ApplicationWithDetailsDTO applicationWithDetailsDTO = applicationsCrudService.findWithDetailsByApplicationId(tenant, amendmentApplicationId);

            return Optional.ofNullable(applicationWithDetailsDTO).isPresent() && !PROCESS_STATUS_DELETED.equals(applicationWithDetailsDTO.getProcessStatus());
        } catch (ApplicationNotFoundRuntimeException e) {
            return false;
        }
    }

    public Boolean isAmendModule(String tenant, Long moduleId) {
        List<ModuleWithDetailDTO> amendModules = moduleCrudService.findValidAmendModulesWithDetailByModuleId(tenant, moduleId,
                FIND_ONLY_AMEND_MODULES, new AbsoluteDate(LocalDate.now()));

        return !amendModules.isEmpty();
    }
}
