package com.abacogroup.agri.applications.core.mappers;

import com.abacogroup.agri.applications.core.model.dto.ChildModuleDTO;
import com.abacogroup.agri.applications.db.ntt.ChildModuleNTT;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

@Mapper
public interface ChildModuleMapper extends EntityMapper<ChildModuleDTO, ChildModuleNTT> {

	ChildModuleMapper INSTANCE = Mappers.getMapper(ChildModuleMapper.class);

	@InheritInverseConfiguration()
	ChildModuleDTO entityToDto(ChildModuleNTT entity);

	@Mapping(source = "pkid", target = "pkid")
	@Mapping(source = "moduleId", target = "module_id")
	@Mapping(source = "parentModuleId", target = "parent_module_id")
	@Mapping(source = "userIdInsert", target = "user_id_insert")
	@Mapping(source = "userIdDelete", target = "user_id_delete")
	@Mapping(source = "dtInsert", target = "dt_insert")
	@Mapping(source = "dtDelete", target = "dt_delete")
    ChildModuleNTT dtoToEntity(ChildModuleDTO dto);

}
