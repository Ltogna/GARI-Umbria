package com.abacogroup.agri.applications.db.ntt;

import com.abacogroup.agri.applications.db.ntt.applications.IIdRs;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.time.LocalDateTime;
import java.util.Optional;

/**
 * @author Alexandru Paraschiv
 */
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class ApplicationGeneratedCalculationNTT implements IIdRs<Long> {

	private Long pkid;
	private Long application_id;
	private String calculation_code;
	private String calculation_description;
	private String process_status;
	private LocalDateTime calculation_date;
	private String calculation_job_uuid;
	private String username;
	private String status;
	private String notes;

	@Override public void setKey(Long id) {
		this.pkid = id;
	}

	@Override public Optional<Long> getKey() {
		return Optional.ofNullable(this.pkid);
	}
}
