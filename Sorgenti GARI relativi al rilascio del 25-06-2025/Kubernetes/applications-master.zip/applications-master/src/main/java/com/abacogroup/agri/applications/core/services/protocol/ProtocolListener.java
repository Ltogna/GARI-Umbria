package com.abacogroup.agri.applications.core.services.protocol;

import com.abacogroup.agri.applications.core.model.dto.ProtocolsPayload;
import com.abacogroup.agri.applications.core.model.dto.publics.ApplicationProtocolsDTO;
import com.abacogroup.agri.applications.core.services.crud.ApplicationProtocolsCrudService;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.rabbitmq.client.*;
import lombok.extern.slf4j.Slf4j;
import org.jdbi.v3.core.Jdbi;

import java.io.IOException;
import java.time.LocalDateTime;
import java.util.HashMap;

/**
 * @author Gennaro Tamburrelli
 */
@Slf4j
public class ProtocolListener {

	private final Channel channel;
	public static final String PROTOCOL_EXCHANGE = "protocols-exchange";
	public static final String QUEUE_NAME = "applications-protocols";
	public static final String ROUTING_KEY_TEMPLATE = "applicationId.*";

	private final ApplicationProtocolsCrudService applicationProtocolsCrudService;
	private final Jdbi jdbi;

	public ProtocolListener(Connection rabbitMQConnection, ObjectMapper objectMapper,
			ApplicationProtocolsCrudService applicationProtocolsCrudService, Jdbi jdbi) throws IOException {
		this.channel = rabbitMQConnection.createChannel();
		this.applicationProtocolsCrudService = applicationProtocolsCrudService;
		this.jdbi = jdbi;

		this.channel.exchangeDeclare(PROTOCOL_EXCHANGE, BuiltinExchangeType.TOPIC, true);

		this.channel.queueDeclare(QUEUE_NAME, true, false, false, new HashMap<>());
		this.channel.queueBind(QUEUE_NAME, PROTOCOL_EXCHANGE, ROUTING_KEY_TEMPLATE);

		this.channel.basicQos(1);
		this.channel.basicConsume(QUEUE_NAME, false, (consumerTag, delivery) -> {
			handleProtocolMessage(objectMapper, delivery);
		}, consumerTag -> {
		});
	}

	private void handleProtocolMessage(ObjectMapper objectMapper, Delivery delivery) throws IOException {
		Envelope envelope = delivery.getEnvelope();
		String routingKey = envelope.getRoutingKey();
		long deliveryTag = envelope.getDeliveryTag();
		log.info("[PROTOCOL-LISTENER] received message with routing key '{}'", routingKey);

		try {
			ProtocolsPayload res = objectMapper.readValue(delivery.getBody(), ProtocolsPayload.class);
			log.info("[PROTOCOL-LISTENER] obtained message {}", res);
			jdbi.useTransaction(handle -> {
				ApplicationProtocolsDTO protocol = applicationProtocolsCrudService.findAll(res.getTenant(), res.getApplication_id()).stream().findFirst()
						.orElseThrow();
				protocol.setProtocol(res.getProtocol());
				protocol.setDtResponse(LocalDateTime.parse(res.getDt_protocol()));
				applicationProtocolsCrudService.update(protocol.getPkid(), protocol, "LISTENER");
			});

			this.channel.basicAck(deliveryTag, false);

			log.info("[PROTOCOL-LISTENER] processed message with routing key '{}'", routingKey);
			log.trace("[PROTOCOL-LISTENER] channel: {}", channel.getChannelNumber());
		} catch (Exception e) {
			log.warn("[PROTOCOL-LISTENER] Got error during consumption of with routing key: " + routingKey, e);
			this.channel.basicNack(deliveryTag, false, false);
		}
	}

}
