package com.abacogroup.agri.applications.core.model.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.time.LocalDateTime;

/**
 * @author Alexandru Paraschiv
 */
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class ApplicationGeneratedCalculationDTO {

	@JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
	private Long pkid;
	@JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
	private Long applicationId;
	@Schema(description = "the application's process status at calculation date")
	private String processStatus;
	@Schema(description = "the application's process status description at calculation date")
	private String processDescription;
	@Schema(description = "the calculation code")
	private String calculationCode;
	@Schema(description = "the calculation description")
	private String calculationDescription;
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	@Schema(description = "the calculation date")
	private LocalDateTime calculationDate;
	@Schema(description = "the calculation job uuid")
	private String calculationJobUuid;
	@Schema(description = "the user who generated the calculator")
	private String username;
	@Schema(description = "the calculation status: can be ERROR or READY")
	private String calculationStatus;
	@Schema(description = "the calculation notes")
	private String notes;

}
