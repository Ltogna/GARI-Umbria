package com.abacogroup.agri.applications.core.caller;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author Alexandru Paraschiv
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class GetPartiesOutput {

	private Long partyId;
	private String code; // Correspond to cuaa
	private String description;
}
