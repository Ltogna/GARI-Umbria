package com.abacogroup.agri.applications.utils;

import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.jdbi.paging.impl.InfiniteListResultsImpl;
import jakarta.ws.rs.core.SecurityContext;
import org.apache.commons.lang3.NotImplementedException;

import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.function.BiFunction;
import java.util.function.Function;
import java.util.function.Supplier;
import java.util.stream.Collectors;

public final class GenericUtility {

	private GenericUtility() {
	}

	public static final Supplier<NotImplementedException> throwNotImplementedException = () -> new NotImplementedException("not in use");

	public static <T> T getValueFromInIfIsNotNull(Supplier<T> inGetter, Supplier<T> actualGetter) {
		return Optional.ofNullable(inGetter.get())
				.orElseGet(actualGetter);
	}

	public static <O, I> InfiniteListResults<O> returnInfiniteResults(InfiniteListResults<I> infiniteListResults, Function<I, O> mapper) {
		return new InfiniteListResultsImpl<>(
				infiniteListResults.getRecords()
						.stream()
						.map(mapper)
						.collect(Collectors.toList()),
				infiniteListResults.getNextKey());
	}

	public static <O, I, T> InfiniteListResults<O> returnInfiniteResults(InfiniteListResults<I> infiniteListResults, T secondType, BiFunction<I, T, O> mapper) {
		return new InfiniteListResultsImpl<>(
				infiniteListResults.getRecords()
						.stream()
						.map(i -> mapper.apply(i, secondType))
						.collect(Collectors.toList()),
				infiniteListResults.getNextKey());
	}

	public static <I, O> Optional<O> returnOptionalFromList(List<I> input, Function<I, O> mapper) {
		return Optional.ofNullable(input)
				.orElseGet(Collections::emptyList)
				.stream()
				.findFirst()
				.map(mapper);
	}

	public static <I, O> List<O> returnMappedList(List<I> input, Function<I, O> mapper) {
		return Optional.ofNullable(input)
				.orElseGet(Collections::emptyList)
				.stream()
				.map(mapper)
				.collect(Collectors.toList());
	}

	public static String conditionallyOverrideUserId(String userId, SecurityContext sc) {
		if (sc != null && sc.isUserInRole("APPLICATIONS|MUST_NOT_SEE_USERID_HISTORY")) {
			return "***";
		} else {
			return userId;
		}
	}

}
