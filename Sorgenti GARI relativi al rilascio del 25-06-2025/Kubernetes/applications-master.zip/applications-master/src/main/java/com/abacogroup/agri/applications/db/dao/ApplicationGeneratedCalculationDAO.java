package com.abacogroup.agri.applications.db.dao;

import com.abacogroup.agri.applications.db.ntt.ApplicationGeneratedCalculationNTT;
import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.customizer.BindBean;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;

import java.util.List;

/**
 * @author Alexandru Paraschiv
 */
public interface ApplicationGeneratedCalculationDAO extends IGenericDAO<ApplicationGeneratedCalculationNTT, Long> {

	@Override
	@SqlQuery("§select_nextval(apps_applications_generated_calculations_seq_id)§")
	Long nextSequenceVal();

	@Override
	@SqlUpdate("INSERT INTO APPS_APPLICATIONS_GENERATED_CALCULATIONS " +
			"(pkid, " +
			"application_id, " +
			"process_status, " +
			"calculation_code, " +
			"calculation_date, " +
			"calculation_job_uuid, " +
			"username," +
			"notes, " +
			"status) " +
			"VALUES(:pkid, :application_id, :process_status, :calculation_code, :calculation_date, :calculation_job_uuid, :username, :notes, :status)")
	void insert(@BindBean ApplicationGeneratedCalculationNTT ntt);

	@SqlQuery("select a.pkid, " +
			"  a.application_id, " +
			"  a.process_status, " +
			"  a.calculation_code, " +
			"  a.calculation_date, " +
			"  a.calculation_job_uuid, " +
			"  a.username, " +
			"  a.notes, " +
			"  a.status " +
			" from APPS_APPLICATIONS_GENERATED_CALCULATIONS a" +
			" where a.pkid = :id")
	@RegisterBeanMapper(ApplicationGeneratedCalculationNTT.class)
	List<ApplicationGeneratedCalculationNTT> findById(@Bind("id") Long pkid);

	@SqlUpdate("UPDATE APPS_APPLICATIONS_GENERATED_CALCULATIONS " +
			"  SET application_id = :application_id , " +
			"  process_status = :process_status, " +
			"  calculation_code = :calculation_code, " +
			"  calculation_date = :calculation_date, " +
			"  calculation_job_uuid = :calculation_job_uuid, " +
			"  username = :username, " +
			"  notes = :notes, " +
			"  status = :status " +
			" where pkid = :pkid")
	void update(@BindBean ApplicationGeneratedCalculationNTT anomaly);

	@SqlUpdate("DELETE FROM APPS_APPLICATIONS_GENERATED_CALCULATIONS a " +
			" where a.pkid = :pkid")
	void deleteById(@Bind("pkid") Long pkid);

	@SqlQuery("select a.pkid, " +
			"  a.application_id, " +
			"  a.process_status, " +
			"  a.calculation_code, " +
			"  §i18n(:tenant_id, 'apps_module_calculation_configs', 'calculation_code', a.calculation_code, :lang)§ as calculation_description," +
			"  a.calculation_date, " +
			"  a.calculation_job_uuid, " +
			"  a.username, " +
			"  a.notes, " +
			"  a.status " +
			" from APPS_APPLICATIONS_GENERATED_CALCULATIONS a INNER JOIN APPS_APPLICATIONS aa ON a.application_id = aa.id " +
			" INNER JOIN APPS_MODULES am on am.id = aa.module_id " +
			" INNER JOIN APPS_SECTORS s on s.id = am.sector_id " +
			" where s.tenant_id = :tenant_id " +
			" and aa.id = :application_id " +
			" and (a.status = 'READY' or a.status = 'ERROR') " +
			" and §current_timestamp§ between am.dt_insert and am.dt_delete " +
			" ORDER BY a.calculation_date DESC")
	@RegisterBeanMapper(ApplicationGeneratedCalculationNTT.class)
	List<ApplicationGeneratedCalculationNTT> findCompletedCalculationsByApplicationId(@Bind("tenant_id") String tenant,
			@Bind("application_id") Long applicationId,
			@Bind("lang") String lang);

	@SqlQuery("select a.pkid, " +
			"  a.application_id, " +
			"  a.process_status, " +
			"  a.calculation_code, " +
			"  §i18n(:tenant_id, 'apps_module_calculation_configs', 'calculation_code', a.calculation_code, :lang)§ as calculation_description," +
			"  a.calculation_date, " +
			"  a.calculation_job_uuid, " +
			"  a.username, " +
			"  a.notes, " +
			"  a.status " +
			" from APPS_APPLICATIONS_GENERATED_CALCULATIONS a INNER JOIN APPS_APPLICATIONS aa ON a.application_id = aa.id " +
			" INNER JOIN APPS_MODULES am on am.id = aa.module_id " +
			" INNER JOIN APPS_SECTORS s on s.id = am.sector_id " +
			" where s.tenant_id = :tenant_id " +
			" and aa.id = :application_id " +
			" and a.calculation_job_uuid = :calculation_job_uuid " +
			" and a.status = :status " +
			" and §current_timestamp§ between am.dt_insert and am.dt_delete ")
	@RegisterBeanMapper(ApplicationGeneratedCalculationNTT.class)
	List<ApplicationGeneratedCalculationNTT> findCalculationByApplicationIdAndJobUuid(@Bind("tenant_id") String tenant,
			@Bind("application_id") Long applicationId,
			@Bind("lang") String lang, @Bind("calculation_job_uuid") String calculationJobUuid, @Bind("status") String status);

	@SqlQuery("select a.pkid, " +
			"  a.application_id, " +
			"  a.process_status, " +
			"  a.calculation_code, " +
			"  §i18n(:tenant_id, 'apps_module_calculation_configs', 'calculation_code', a.calculation_code, :lang)§ as calculation_description," +
			"  a.calculation_date, " +
			"  a.calculation_job_uuid, " +
			"  a.username, " +
			"  a.notes, " +
			"  a.status " +
			" from APPS_APPLICATIONS_GENERATED_CALCULATIONS a INNER JOIN APPS_APPLICATIONS aa ON a.application_id = aa.id " +
			" INNER JOIN APPS_MODULES am on am.id = aa.module_id " +
			" INNER JOIN APPS_SECTORS s on s.id = am.sector_id " +
			" where s.tenant_id = :tenant_id " +
			" and aa.id = :application_id " +
			" and a.calculation_job_uuid = :calculation_job_uuid " +
			" and §current_timestamp§ between am.dt_insert and am.dt_delete ")
	@RegisterBeanMapper(ApplicationGeneratedCalculationNTT.class)
	List<ApplicationGeneratedCalculationNTT> findCalculationByApplicationIdAndJobUuid(@Bind("tenant_id") String tenant,
			@Bind("application_id") Long applicationId,
			@Bind("lang") String lang, @Bind("calculation_job_uuid") String calculationJobUuid);

	@SqlQuery("select a.pkid, " +
			"  a.application_id, " +
			"  a.process_status, " +
			"  a.calculation_code, " +
			"  §i18n(:tenant_id, 'apps_module_calculation_configs', 'calculation_code', a.calculation_code, :lang)§ as calculation_description," +
			"  a.calculation_date, " +
			"  a.calculation_job_uuid, " +
			"  a.username, " +
			"  a.notes, " +
			"  a.status " +
			" from APPS_APPLICATIONS_GENERATED_CALCULATIONS a INNER JOIN APPS_APPLICATIONS aa ON a.application_id = aa.id " +
			" INNER JOIN APPS_MODULES am on am.id = aa.module_id " +
			" INNER JOIN APPS_SECTORS s on s.id = am.sector_id " +
			" where s.tenant_id = :tenant_id " +
			" and aa.id = :application_id " +
			" and a.calculation_code = :calculation_code " +
			" and ((:ongoing = 0 and a.status is not null) or (:ongoing = 1 and a.status is null)) " +
			" and §current_timestamp§ between am.dt_insert and am.dt_delete " +
			" and a.calculation_date = (select MAX(calculation_date) " +
			"                        from APPS_APPLICATIONS_GENERATED_CALCULATIONS " +
			"                        where application_id = :application_id " +
			"                        and calculation_code =:calculation_code " +
			"                        and (:ongoing = 0 or :ongoing = 1))")
	@RegisterBeanMapper(ApplicationGeneratedCalculationNTT.class)
	List<ApplicationGeneratedCalculationNTT> findLastGeneratedCalculationByCode(@Bind("tenant_id") String tenant, @Bind("application_id") Long applicationId,
			@Bind("calculation_code") String calculationCode, @Bind("lang") String lang, @Bind("ongoing") Integer ongoing);

	@SqlQuery("select a.pkid, " +
			"  a.application_id, " +
			"  a.process_status, " +
			"  a.calculation_code, " +
			"  a.calculation_date, " +
			"  a.calculation_job_uuid, " +
			"  a.username, " +
			"  a.notes, " +
			"  a.status " +
			" from APPS_APPLICATIONS_GENERATED_CALCULATIONS a" +
			" where a.calculation_job_uuid = :calculation_job_uuid")
	@RegisterBeanMapper(ApplicationGeneratedCalculationNTT.class)
	ApplicationGeneratedCalculationNTT findByUuid(@Bind("calculation_job_uuid") String uuid);
}
