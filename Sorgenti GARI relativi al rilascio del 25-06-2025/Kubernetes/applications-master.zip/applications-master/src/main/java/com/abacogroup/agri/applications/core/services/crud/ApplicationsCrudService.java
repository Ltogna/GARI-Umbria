package com.abacogroup.agri.applications.core.services.crud;

import com.abacogroup.agri.applications.core.exceptions.ApplicationNotFoundRuntimeException;
import com.abacogroup.agri.applications.core.exceptions.ObjectNotFoundException;
import com.abacogroup.agri.applications.core.mappers.ApplicationMapper;
import com.abacogroup.agri.applications.core.mappers.ApplicationWithDetailMapper;
import com.abacogroup.agri.applications.core.mappers.ApplicationsByPartyAndYearMapper;
import com.abacogroup.agri.applications.core.model.dto.publics.AppByPartyAndYearDTO;
import com.abacogroup.agri.applications.core.model.dto.publics.ApplicationDTO;
import com.abacogroup.agri.applications.core.model.dto.publics.ApplicationWithDetailsDTO;
import com.abacogroup.agri.applications.db.dao.ApplicationDAO;
import com.abacogroup.agri.applications.db.ntt.ApplicationByPartyAndYearNTT;
import com.abacogroup.agri.applications.db.ntt.ApplicationNTT;
import com.abacogroup.jaxrsutils.filter.MDCPreFilter;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import jakarta.ws.rs.core.SecurityContext;
import lombok.extern.slf4j.Slf4j;
import org.jdbi.v3.core.result.ResultIterator;
import org.slf4j.MDC;

import java.text.MessageFormat;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.function.Supplier;
import java.util.stream.Collectors;

import static com.abacogroup.agri.applications.utils.PagingParamsFactory.DEFAULT_PAGE_SIZE;

/**
 * @author Alexandru Paraschiv
 * @author Gennaro Tamburrelli
 */
@Slf4j
public class ApplicationsCrudService extends AbstractHistoricizationFieldsCrudService<ApplicationNTT, Long, ApplicationDTO, ApplicationMapper, Long> {

	public ApplicationsCrudService(ApplicationDAO dao, ApplicationMapper mapper) {
		super(dao, mapper);
	}

	@Override
	protected boolean hasPrimaryKey() {
		return true;
	}

	@Override
	protected Long retrieveCustomKeyByResultSet(ApplicationNTT rs) {
		return null;
	}

	@Override
	protected ApplicationNTT adjustR(ApplicationNTT rs) {
		return rs;
	}

	@Override
	protected Optional<ApplicationNTT> findRsByCustomKey(Long customKey) {
		return Optional.ofNullable(dao.findById(customKey))
				.orElseGet(Collections::emptyList)
				.stream().findFirst();
	}

	@Override
	protected Long retrieveKey(Long customKey) {
		return Optional.ofNullable(customKey)
				.orElse(super.retrieveKey(null));
	}

	public Optional<ApplicationDTO> findById(Long applicationId) {
		return returnOptionalRecord(dao.findById(applicationId));
	}

	public ApplicationDTO findByCode(String tenant, String applicationCode) throws ObjectNotFoundException {
		return ((ApplicationDAO) this.dao).findByCode(tenant, applicationCode).stream()
				.findFirst()
				.map(mapper::entityToDto)
				.orElseThrow(AbstractCrudService.OBJECT_NOT_FOUND_EXCEPTION_SUPPLIER);
	}

	public ApplicationDTO findById(String tenant, Long applicationId) throws ObjectNotFoundException {
		return ((ApplicationDAO) this.dao).findById(tenant, applicationId).stream()
				.findFirst()
				.map(mapper::entityToDto)
				.orElseThrow(AbstractCrudService.OBJECT_NOT_FOUND_EXCEPTION_SUPPLIER);
	}

	public ApplicationDTO findByProcessId(Long processId) throws ObjectNotFoundException {
		return ((ApplicationDAO) this.dao).findByProcessId(processId).stream()
				.findFirst()
				.map(mapper::entityToDto)
				.orElseThrow(AbstractCrudService.OBJECT_NOT_FOUND_EXCEPTION_SUPPLIER);
	}

	public ApplicationDTO findByIdAlsoExpired(String tenant, Long applicationId) throws ObjectNotFoundException {
		return ((ApplicationDAO) this.dao).findByIdAlsoExpired(tenant, applicationId).stream()
				.findFirst()
				.map(mapper::entityToDto)
				.orElseThrow(AbstractCrudService.OBJECT_NOT_FOUND_EXCEPTION_SUPPLIER);
	}

	public ApplicationDTO insert(ApplicationDTO in, String username) {
		log.info("Invoking insert with params in: {} username: {}", in, username);
		return this.insert(in, username, in.getApplicationId(), this.dao.getCurrentTimestamp());
	}

	public ApplicationDTO update(Long key, ApplicationDTO in, String username) {
		log.info("Invoking update with params key: {} in: {} username: {}", key, in, username);
		return this.update(key, in, username, null);
	}

	public void updateProcessId(Long id, Long processId) {
		((ApplicationDAO) this.dao).updateProcessId(id, processId);
	}

	public void delete(Long key, String username) {
		log.info("Invoking delete with params key: {} username: {}", key, username);
		this.delete(key, username, null);
	}

	public ApplicationWithDetailsDTO findWithDetailsByApplicationCode(String tenantId, String applicationCode) {
		return this.findWithDetailsByApplicationCode(tenantId, applicationCode, MDC.get(MDCPreFilter.LOCALE));
	}

	public ApplicationWithDetailsDTO findWithDetailsByApplicationCode(String tenantId, String applicationCode, String locale) {
		return ((ApplicationDAO) this.dao).findWithDetailByCode(tenantId, applicationCode, locale)
				.stream()
				.map(ApplicationWithDetailMapper.INSTANCE::entityToDto)
				.findFirst()
				.orElseThrow(() -> new ApplicationNotFoundRuntimeException(
						MessageFormat.format("Application not found by tenant: {0} code: {1}", tenantId, applicationCode)));
	}

	public ApplicationWithDetailsDTO findWithDetailsByApplicationId(String tenantId, Long applicationId) {
		return this.findWithDetailsByApplicationId(tenantId, applicationId, MDC.get(MDCPreFilter.LOCALE));
	}

	public ApplicationWithDetailsDTO findWithDetailsByApplicationId(String tenantId, Long applicationId, String locale) {
		return ((ApplicationDAO) this.dao).findWithDetailById(tenantId, applicationId, locale)
				.stream()
				.map(ApplicationWithDetailMapper.INSTANCE::entityToDto)
				.findFirst()
				.orElseThrow(() -> new ApplicationNotFoundRuntimeException(
						MessageFormat.format("Application not found by tenant: {0} id: {1}", tenantId, applicationId)));
	}

	public List<ApplicationDTO> findAllByPartyId(String tenant, Long partyId) {
		log.info("Invoking find with params tenant: {} partyId: {}", tenant, partyId);
		return ((ApplicationDAO) dao).findAllByPartyId(tenant, partyId).stream()
				.map(mapper::entityToDto)
				.collect(Collectors.toList());

	}

	/**
	 * Find by party id, year
	 *
	 * @param tenant
	 * 		current tenant
	 * @param partyId
	 * 		the party id
	 * @param year
	 * 		the specified year
	 * @param nextKey
	 * 		for pagination
	 * @return the partial list of result
	 */
	public InfiniteListResults<AppByPartyAndYearDTO> find(String tenant, Long partyId, Integer year, String nextKey) {
		return returnInfiniteResults(
				this.dao.infinite(() -> ((ApplicationDAO) this.dao).find(tenant, partyId, year, MDC.get(MDCPreFilter.LOCALE)),
						nextKey,
						DEFAULT_PAGE_SIZE),
				ApplicationsByPartyAndYearMapper.INSTANCE::entityToDto);
	}

	public InfiniteListResults<AppByPartyAndYearDTO> find(String tenant, SecurityContext sc, Long partyId, Integer year, String nextKey) {
		return returnInfiniteResults(
				this.dao.infinite(() -> ((ApplicationDAO) this.dao).find(tenant, partyId, year, MDC.get(MDCPreFilter.LOCALE)),
						(x) -> x.getContext_function() == null || Optional.ofNullable(sc).map(y -> y.isUserInRole(x.getContext_function())).orElse(false),
						nextKey,
						DEFAULT_PAGE_SIZE),
				ApplicationsByPartyAndYearMapper.INSTANCE::entityToDto);
	}

	/**
	 * Find by party id, year, module code
	 *
	 * @param tenant
	 * 		current tenant
	 * @param partyId
	 * 		the party id
	 * @param year
	 * 		the specified year
	 * @param moduleCode
	 * 		the specified module code
	 * @return the list of result
	 */
	public List<AppByPartyAndYearDTO> findWithModuleCode(String tenant, Long partyId, Integer year, String moduleCode) {
		return ((ApplicationDAO) this.dao).find(tenant, partyId, year, moduleCode, MDC.get(MDCPreFilter.LOCALE))
				.stream()
				.map(ApplicationsByPartyAndYearMapper.INSTANCE::entityToDto)
				.collect(Collectors.toList());
	}

	public InfiniteListResults<AppByPartyAndYearDTO> findInfiniteResults(String tenant, String moduleCode, Long partyId,
			List<Integer> yearList, String processStatus, List<Long> applicationIdList, String nextKey, String lang, Integer pageSize) {
		return returnInfiniteResults(
				this.dao.infinite(conditionallyLaunchFindInfinite(tenant, moduleCode, partyId, yearList, processStatus, applicationIdList, lang),
						nextKey,
						Optional.ofNullable(pageSize).orElse(DEFAULT_PAGE_SIZE)),
				ApplicationsByPartyAndYearMapper.INSTANCE::entityToDto);
	}

	public InfiniteListResults<Long> findInfiniteApplicationIds(String tenant, String moduleCode, String nextKey, Integer pageSize) {
		return this.dao.infinite(
				() -> ((ApplicationDAO) this.dao).findInfiniteApplicationIds(tenant, moduleCode),
				nextKey,
				Optional.ofNullable(pageSize).orElse(DEFAULT_PAGE_SIZE)
		);
	}

	private Supplier<ResultIterator<ApplicationByPartyAndYearNTT>> conditionallyLaunchFindInfinite(String tenant, String moduleCode, Long partyId,
			List<Integer> yearList, String processStatus, List<Long> applicationIdList, String lang) {
		return () -> ((ApplicationDAO) this.dao)
				.findInfinite(tenant, partyId,
						handleEmptyList(yearList, Integer.class),
						skipListEvaluation(yearList),
						moduleCode,
						processStatus,
						handleEmptyList(applicationIdList, Long.class),
						skipListEvaluation(applicationIdList),
						lang);
	}

	public Long countApplications(String tenant, String moduleCode, Long partyId,
			List<Integer> yearList, String processStatus, List<Long> applicationIdList) {
		return ((ApplicationDAO) this.dao).countApplications(tenant,
				partyId,
				handleEmptyList(yearList, Integer.class),
				skipListEvaluation(yearList),
				moduleCode,
				processStatus,
				handleEmptyList(applicationIdList, Long.class),
				skipListEvaluation(applicationIdList));
	}

	@SuppressWarnings("unchecked")
	private <T> List<T> handleEmptyList(List<T> l, Class<T> clazz) { // ugly workaround to handle empty lists..cannot make jdbi null list works..
		if (skipListEvaluation(l) == 1) {
			if (clazz.equals(String.class))
				return (List<T>) List.of(" ");
			if (clazz.equals(Integer.class))
				return (List<T>) List.of(-1);
			if (clazz.equals(Long.class))
				return (List<T>) List.of(-1L);
		}
		return l;
	}

	private int skipListEvaluation(List<?> list) {
		return (list == null || list.isEmpty()) ? 1 : 0;
	}

	public List<ApplicationDTO> findAllByModuleId(String tenant, Long moduleId) {
		log.info("Invoking findAllByModuleId with params tenant: {} partyId: {}", tenant, moduleId);
		return ((ApplicationDAO) dao).findAllByModuleId(tenant, moduleId).stream()
				.map(mapper::entityToDto)
				.collect(Collectors.toList());
	}

	public List<ApplicationWithDetailsDTO> findAllByModuleIdAndPartyIdAndReferredYear(String tenant, Long moduleId, Long partyId, Integer referredYear) {
		log.info("Invoking findAllByModuleIdAndPartyId with params tenant: {} moduleId: {} partyId: {}", tenant, moduleId, partyId);
		return ((ApplicationDAO) dao).findAllByModuleIdAndPartyIdAndReferredYear(tenant, moduleId, partyId, referredYear).stream()
				.map(ApplicationWithDetailMapper.INSTANCE::entityToDto)
				.collect(Collectors.toList());
	}

	public List<ApplicationWithDetailsDTO> findAllByPartyIdAndModuleCodeAndProcessStatus(String tenant, Long partyId, String moduleCode, String processStatus) {
		log.info("Invoking findAllByModuleIdAndPartyId with params tenant: {} moduleCode: {} partyId: {} processStatus:{}", tenant, moduleCode, partyId,
				processStatus);
		return ((ApplicationDAO) dao).findAllByPartyIdAndModuleCodeAndProcessStatus(tenant, partyId, moduleCode, processStatus).stream()
				.map(ApplicationWithDetailMapper.INSTANCE::entityToDto)
				.collect(Collectors.toList());
	}

	public static final boolean FIND_EXPIRED = true;
	public static final boolean FIND_NOT_EXPIRED = false;

	public void getApplicationAndUpdateProcessId(String tenant, Long applicationId, Long processId, boolean findExpired) throws ObjectNotFoundException {
		// get application
		ApplicationDTO application;
		if (findExpired == FIND_NOT_EXPIRED) {
			application = this.findById(tenant, applicationId);
		} else {
			application = this.findByIdAlsoExpired(tenant, applicationId);
		}

		// update application
		this.updateProcessId(application.getApplicationId(), processId);
	}
}
