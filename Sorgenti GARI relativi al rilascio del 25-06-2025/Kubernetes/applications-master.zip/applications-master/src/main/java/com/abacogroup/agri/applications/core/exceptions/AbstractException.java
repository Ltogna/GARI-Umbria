package com.abacogroup.agri.applications.core.exceptions;

import lombok.Data;

import jakarta.ws.rs.WebApplicationException;
import jakarta.ws.rs.core.Response;

public abstract class AbstractException extends WebApplicationException {
	private final String code;
	private final String message;

	protected AbstractException(Response.Status status, ExceptionErrorBody body, String message) {
		super(message,
				Response.status(status).entity(new ApplicationsExceptionBody(body.getErrorCode(), message)).build());
		this.code = body.getErrorCode();
		this.message = message;
	}

	public interface ExceptionErrorBody {
		String getErrorCode();
	}

	@Data
	public static class ApplicationsExceptionBody {

		private String errorCode;
		private String message;

		public ApplicationsExceptionBody(String errorCode, String message) {
			this.errorCode = errorCode;
			this.message = message;
		}
	}
}
