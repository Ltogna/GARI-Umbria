package com.abacogroup.agri.applications.core.mappers;

import com.abacogroup.agri.applications.core.model.WorkflowNodePublic;
import com.abacogroup.workflow.server.model.WorkflowNode;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

@Mapper
public interface WorkflowNodePublicMapper extends EntityMapper<WorkflowNodePublic, WorkflowNode> {

	WorkflowNodePublicMapper INSTANCE = Mappers.getMapper(WorkflowNodePublicMapper.class);

	@InheritInverseConfiguration()
	WorkflowNodePublic entityToDto(WorkflowNode entity);

	@Mapping(source = "name", target = "name")
	@Mapping(source = "description", target = "description")
	WorkflowNode dtoToEntity(WorkflowNodePublic dto);

}
