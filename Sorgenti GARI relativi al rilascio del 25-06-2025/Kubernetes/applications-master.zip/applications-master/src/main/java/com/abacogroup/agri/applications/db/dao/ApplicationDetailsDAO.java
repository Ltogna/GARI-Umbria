package com.abacogroup.agri.applications.db.dao;

import com.abacogroup.agri.applications.db.ntt.ApplicationDetailsNTT;
import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.customizer.BindBean;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;

import java.time.LocalDateTime;
import java.util.List;

/**
 * @author Mauro Pozzana
 */
public interface ApplicationDetailsDAO extends IGenericHistoricizationFieldsDAO<ApplicationDetailsNTT, Long, Void> {

	@Override
	@SqlQuery("§select_nextval(apps_application_details_id_seq)§")
	Long nextSequenceVal();

	@Override
	@SqlUpdate("INSERT INTO apps_application_details (pkid, application_id, application_code, process_status, dt_presentation, " +
			" amended_by_id, amend_of_id, dt_insert, dt_delete, user_id_insert, user_id_delete, fl_in_transition) " +
			"VALUES(:pkid, :application_id, :application_code, :process_status, " +
			"       :dt_presentation, :amended_by_id, :amend_of_id, :current_timestamp, " +
			"       TO_TIMESTAMP('9999-12-3123:59:59','YYYY-MM-DDHH24:MI:SS'), :user_id, NULL, :fl_in_transition)")
	void insert(@BindBean ApplicationDetailsNTT rs, @Bind("user_id") String userId, @Bind("current_timestamp") LocalDateTime currentTimestamp);

	@Override
	@SqlQuery("SELECT pkid, " +
			"application_id, " +
			"application_code, " +
			"process_status, " +
			"dt_presentation, " +
			"amended_by_id, " +
			"amend_of_id, " +
			"dt_insert, " +
			"dt_delete, " +
			"user_id_insert, " +
			"user_id_delete, " +
			"fl_in_transition " +
			"FROM apps_application_details " +
			"WHERE pkid = :id")
	@RegisterBeanMapper(ApplicationDetailsNTT.class)
	List<ApplicationDetailsNTT> findById(@Bind("id") Long id);

	@SqlQuery("SELECT ad.pkid, " +
			"ad.application_id, " +
			"ad.application_code, " +
			"ad.process_status, " +
			"ad.dt_presentation, " +
			"amended_by_id, " +
			"amend_of_id, " +
			"ad.dt_insert, " +
			"ad.dt_delete, " +
			"ad.user_id_insert, " +
			"ad.user_id_delete, " +
			"fl_in_transition " +
			"FROM apps_application_details ad " +
			"LEFT JOIN apps_applications a ON ad.application_id = a.id " +
			"LEFT JOIN apps_modules m ON a.module_id = m.id " +
			"LEFT JOIN apps_sectors s ON m.sector_id = s.id " +
			"WHERE ad.application_code = :code AND s.tenant_id = :tenant " +
			"and §current_timestamp§ between a.dt_insert and a.dt_delete " +
			"and §current_timestamp§ between ad.dt_insert and ad.dt_delete " +
			"and §current_timestamp§ between m.dt_insert and m.dt_delete")
	@RegisterBeanMapper(ApplicationDetailsNTT.class)
	List<ApplicationDetailsNTT> findByCode(@Bind("tenant") String tenant, @Bind("code") String code);

	@SqlQuery("SELECT ad.pkid, " +
			"ad.application_id, " +
			"ad.application_code, " +
			"ad.process_status, " +
			"ad.dt_presentation, " +
			"ad.amended_by_id, " +
			"ad.amend_of_id, " +
			"ad.dt_insert, " +
			"ad.dt_delete, " +
			"ad.user_id_insert, " +
			"ad.user_id_delete, " +
			"fl_in_transition " +
			"FROM apps_application_details ad " +
			"LEFT JOIN apps_applications a ON ad.application_id = a.id " +
			"LEFT JOIN apps_modules m ON a.module_id = m.id " +
			"LEFT JOIN apps_sectors s ON m.sector_id = s.id " +
			"WHERE a.id = :app_id AND s.tenant_id = :tenant " +
			"and §current_timestamp§ between a.dt_insert and a.dt_delete " +
			"and §current_timestamp§ between ad.dt_insert and ad.dt_delete " +
			"and §current_timestamp§ between m.dt_insert and m.dt_delete")
	@RegisterBeanMapper(ApplicationDetailsNTT.class)
	List<ApplicationDetailsNTT> findByApplicationId(@Bind("tenant") String tenant, @Bind("app_id") Long appId);

	@SqlQuery("SELECT ad.pkid, " +
			"ad.application_id, " +
			"ad.application_code, " +
			"ad.process_status, " +
			"ad.dt_presentation, " +
			"ad.amended_by_id, " +
			"ad.amend_of_id, " +
			"ad.dt_insert, " +
			"ad.dt_delete, " +
			"ad.user_id_insert, " +
			"ad.user_id_delete, " +
			"fl_in_transition " +
			"FROM apps_application_details ad " +
			"LEFT JOIN apps_applications a ON ad.application_id = a.id " +
			"LEFT JOIN apps_modules m ON a.module_id = m.id " +
			"LEFT JOIN apps_sectors s ON m.sector_id = s.id " +
			"WHERE a.id = :app_id AND s.tenant_id = :tenant " +
			"and §current_timestamp§ between ad.dt_insert and ad.dt_delete " +
			"and §current_timestamp§ between m.dt_insert and m.dt_delete")
	@RegisterBeanMapper(ApplicationDetailsNTT.class)
	List<ApplicationDetailsNTT> findByApplicationIdAlsoExpired(@Bind("tenant") String tenant, @Bind("app_id") Long appId);

	@SqlQuery("SELECT MIN(ad.dt_insert) " +
			"FROM apps_application_details ad " +
			"LEFT JOIN apps_applications a ON ad.application_id = a.id " +
			"LEFT JOIN apps_modules m ON a.module_id = m.id " +
			"LEFT JOIN apps_sectors s ON m.sector_id = s.id " +
			"WHERE a.id = :app_id AND s.tenant_id = :tenant " +
			"and §current_timestamp§ between a.dt_insert and a.dt_delete " +
			"and §current_timestamp§ between m.dt_insert and m.dt_delete")
	LocalDateTime findFirstDtInsert(@Bind("tenant") String tenant, @Bind("app_id") Long appId);

	@Override
	@SqlUpdate("UPDATE apps_application_details SET " +
			"user_id_delete = :user_id_delete, dt_delete = :current_timestamp " +
			"WHERE pkid = :id " +
			"and §current_timestamp§ between dt_insert and dt_delete")
	void logicallyDeleteById(@Bind("id") Long id, @Bind("user_id_delete") String userDelete, @Bind("current_timestamp") LocalDateTime currentTimestamp);
}
