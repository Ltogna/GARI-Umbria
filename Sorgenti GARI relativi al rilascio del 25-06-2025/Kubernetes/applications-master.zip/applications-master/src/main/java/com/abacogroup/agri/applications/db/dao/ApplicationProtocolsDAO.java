package com.abacogroup.agri.applications.db.dao;

import java.time.LocalDateTime;
import java.util.List;

import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.customizer.BindBean;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;

import com.abacogroup.agri.applications.db.ntt.ApplicationProtocolsNTT;

/**
 * @author Samuele Sbarbaro
 */
public interface ApplicationProtocolsDAO extends IGenericHistoricizationFieldsDAO<ApplicationProtocolsNTT, Long, Void> {

	@Override
	@SqlQuery("§select_nextval(apps_application_protocols_id_seq)§")
	Long nextSequenceVal();

	@Override
	@SqlUpdate("INSERT INTO APPS_APPLICATION_PROTOCOLS " +
			"(pkid, " +
			"application_id, " +
			"dt_request, " +
			"dt_response, " +
			"protocol, " +
			"user_id_insert, " +
			"user_id_delete, " +
			"dt_insert, " +
			"dt_delete) " +
			"VALUES(:pkid, :application_id, :dt_request, :dt_response, :protocol, :user_id, NULL, :current_timestamp, TO_TIMESTAMP('9999-12-3123:59:59','YYYY-MM-DDHH24:MI:SS'))")
	void insert(@BindBean ApplicationProtocolsNTT ntt, @Bind("user_id") String userId, @Bind("current_timestamp") LocalDateTime currentTimestamp);

	@Override
	@SqlQuery("SELECT pkid, " +
			"application_id, " +
			"dt_request, " +
			"dt_response, " +
			"protocol,  " +
			"dt_insert, " +
			"dt_delete, " +
			"user_id_insert, " +
			"user_id_delete " +
			"FROM APPS_APPLICATION_PROTOCOLS " +
			"WHERE pkid = :id")
	@RegisterBeanMapper(ApplicationProtocolsNTT.class)
	List<ApplicationProtocolsNTT> findById(@Bind("id") Long id);

	@Override
	@SqlUpdate("UPDATE APPS_APPLICATION_PROTOCOLS SET " +
			"user_id_delete = :user_id_delete, dt_delete = :current_timestamp " +
			"WHERE pkid = :id " +
			"and §current_timestamp§ between dt_insert and dt_delete")
	void logicallyDeleteById(@Bind("id") Long id, @Bind("user_id_delete") String userDelete, @Bind("current_timestamp") LocalDateTime currentTimestamp);

	@SqlQuery("SELECT ap.pkid, " +
			"ap.application_id, " +
			"dt_request, " +
			"dt_response, " +
			"ap.protocol, " +
			"ap.dt_insert, " +
			"ap.dt_delete, " +
			"ap.user_id_insert, " +
			"ap.user_id_delete " +
			"FROM APPS_APPLICATION_PROTOCOLS ap " +
			"LEFT JOIN apps_applications a ON ap.application_id = a.id " +
			"LEFT JOIN apps_application_details ad ON ad.application_id = a.id " +
			"LEFT JOIN apps_modules m ON a.module_id = m.id " +
			"LEFT JOIN apps_sectors s ON m.sector_id = s.id " +
			"WHERE a.id = :app_id AND s.tenant_id = :tenantId " +
			"and §current_timestamp§ between ap.dt_insert and ap.dt_delete " +
			"and §current_timestamp§ between a.dt_insert and a.dt_delete " +
			"and §current_timestamp§ between ad.dt_insert and ad.dt_delete " +
			"and §current_timestamp§ between m.dt_insert and m.dt_delete")
	@RegisterBeanMapper(ApplicationProtocolsNTT.class)
	List<ApplicationProtocolsNTT> find(@Bind("tenantId") String tenant, @Bind("app_id") Long appId);

}
