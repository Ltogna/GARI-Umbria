package com.abacogroup.agri.applications.core.mappers;

import com.abacogroup.agri.applications.core.model.dto.FormGroupDTO;
import com.abacogroup.applicationworkflowsdk.model.io.output.FormGroupPublicDTO;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

@Mapper
public interface FormGroupPublicMapper {

	FormGroupPublicMapper INSTANCE = Mappers.getMapper(FormGroupPublicMapper.class);

	@InheritInverseConfiguration()
	FormGroupDTO fromPublic(FormGroupPublicDTO entity);

	@Mapping(source = "formGroupCode", target = "groupCode")
	@Mapping(source = "formGroupDescription", target = "groupName")
	FormGroupPublicDTO toPublic(FormGroupDTO dto);
}
