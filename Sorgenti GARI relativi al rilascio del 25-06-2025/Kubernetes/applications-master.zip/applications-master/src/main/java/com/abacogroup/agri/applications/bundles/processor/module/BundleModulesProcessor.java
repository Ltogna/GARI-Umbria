package com.abacogroup.agri.applications.bundles.processor.module;

import com.abacogroup.agri.applications.bundles.model.module.BundleModulesMessage;
import com.abacogroup.agri.applications.bundles.processor.AbstractBundleApplicationsProcessor;
import com.abacogroup.bundles.listener.configdata.ConfigDataMessage;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.jdbi.v3.core.Jdbi;

import java.nio.file.Path;

/**
 * @author Alexandru Paraschiv
 */
@Slf4j
public class BundleModulesProcessor extends AbstractBundleApplicationsProcessor<BundleModulesMessage> {

	protected final ModulesBundleWorker modulesBundleWorker;

	public BundleModulesProcessor(ObjectMapper mapper, ModulesBundleWorker sectorsBundleWorker, Jdbi jdbi) {
		super(mapper, jdbi);
		this.modulesBundleWorker = sectorsBundleWorker;
	}

	@Override
	public String getDomainName() {
		return "modules";
	}

	@Override
	protected TypeReference<BundleModulesMessage> getTypeReference() {
		return new TypeReference<>() {
		};
	}

	@Override
	public void onMessageInTransaction(ConfigDataMessage message) {
		log.info("onMessageInTransaction: proccessing file with tenant {}", message.getTenantId());
		message.getConfigFiles().stream()
				.map(Path::toFile)
				.filter(file -> file.getAbsolutePath().endsWith(".json"))
				.forEach(file -> processFile(message.getTenantId(), file));
	}

	@Override
	protected void delete(String tenantId, BundleModulesMessage message) {
		modulesBundleWorker.deleteBundleModules(tenantId, message);
	}

	@Override
	protected void doInsertOrUpdate(String tenantId, BundleModulesMessage message) {
		modulesBundleWorker.insertBundleModules(tenantId, message);
	}

}
