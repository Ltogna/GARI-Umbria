package com.abacogroup.agri.applications.core.services.print;

import java.time.LocalDateTime;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import com.abacogroup.agri.applications.core.model.dto.publics.DescriptionReplacer;
import com.abacogroup.agri.applications.core.services.ForceReadOnlyContextCheckerService;
import com.abacogroup.agri.applications.core.services.PartyService;
import com.abacogroup.agri.applications.utils.DescriptionReplacerUtility;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.MDC;

import com.abacogroup.agri.applications.core.caller.CreatePrintJobCaller;
import com.abacogroup.agri.applications.core.caller.CreatePrintJobInput;
import com.abacogroup.agri.applications.core.exceptions.ActionNotAuthorizedRuntimeException;
import com.abacogroup.agri.applications.core.exceptions.ApplicationNotFoundRuntimeException;
import com.abacogroup.agri.applications.core.exceptions.ObjectNotFoundException;
import com.abacogroup.agri.applications.core.exceptions.ObjectNotFoundRuntimeException;
import com.abacogroup.agri.applications.core.mappers.PrintDetailsOutMapper;
import com.abacogroup.agri.applications.core.model.dto.ApplicationGeneratedPrintDTO;
import com.abacogroup.agri.applications.core.model.dto.ModulePrintConfigParamDTO;
import com.abacogroup.agri.applications.core.model.dto.publics.LastPrintDTO;
import com.abacogroup.agri.applications.core.model.dto.publics.PrintDetailsOutDTO;
import com.abacogroup.agri.applications.core.services.CheckPartyService;
import com.abacogroup.agri.applications.core.services.FileStoreService;
import com.abacogroup.agri.applications.core.services.crud.ApplicationGeneratedPrintCrudService;
import com.abacogroup.agri.applications.core.services.crud.ApplicationsCrudService;
import com.abacogroup.agri.applications.core.services.crud.CrudServiceContainer;
import com.abacogroup.agri.applications.core.services.crud.ModuleCrudService;
import com.abacogroup.agri.applications.core.services.crud.ModulePrintConfigParamCrudService;
import com.abacogroup.agri.applications.core.services.crud.ModulePrintConfigsCrudService;
import com.abacogroup.agri.applications.core.services.workflow.ApplicationsWorkflowService;
import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.filestore.client.auth.Sso2Authenticator;
import com.abacogroup.jaxrsutils.filter.MDCPreFilter;

import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.core.SecurityContext;
import lombok.extern.slf4j.Slf4j;

import static com.abacogroup.agri.applications.utils.GenericUtility.conditionallyOverrideUserId;

/**
 * @author Gennaro Tamburrelli
 */
@Slf4j
public class PrintService {

	private final ApplicationsCrudService applicationsCrudService;
	private final CheckPartyService checkPartyService;
	private final ModuleCrudService moduleCrudService;
	private final ApplicationsWorkflowService applicationsWorkflowService;
	private final ModulePrintConfigsCrudService modulePrintConfigsCrudService;
	private final ModulePrintConfigParamCrudService modulePrintConfigParamCrudService;
	private final ApplicationGeneratedPrintCrudService applicationGeneratedPrintCrudService;
	private final CreatePrintJobCaller createPrintJobCaller;
	private final FileStoreService fileStoreService;
	private final String printBucketName;
	private final String printEngineUrl;
	private final ForceReadOnlyContextCheckerService forceReadOnlyContextCheckerService;
	private final PartyService partyService;

	public static final String PRINT_DESTINATION = "applications-prints-destination";

	public PrintService(CrudServiceContainer crudServiceContainer,
			CheckPartyService checkPartyService,
			ApplicationsWorkflowService applicationsWorkflowService,
			CreatePrintJobCaller createPrintJobCaller, FileStoreService fileStoreService, String printBucketName,
			String printEngineUrl, ForceReadOnlyContextCheckerService forceReadOnlyContextCheckerService,
			PartyService partyService) {
		this.applicationsCrudService = crudServiceContainer.getApplicationsCrudService();
		this.checkPartyService = checkPartyService;
		this.moduleCrudService = crudServiceContainer.getModuleCrudService();
		this.applicationsWorkflowService = applicationsWorkflowService;
		this.modulePrintConfigsCrudService = crudServiceContainer.getModulePrintConfigsCrudService();
		this.modulePrintConfigParamCrudService = crudServiceContainer.getModulePrintConfigParamCrudService();
		this.applicationGeneratedPrintCrudService = crudServiceContainer.getApplicationGeneratedPrintCrudService();
		this.createPrintJobCaller = createPrintJobCaller;
		this.fileStoreService = fileStoreService;
		this.printBucketName = printBucketName;
		this.printEngineUrl = printEngineUrl;
        this.forceReadOnlyContextCheckerService = forceReadOnlyContextCheckerService;
		this.partyService = partyService;
	}

	public ApplicationGeneratedPrintDTO startPrintJob(String tenant, Long applicationId, Long partyId, String processStatus,
			List<PrintDetailsOutDTO> modulesPrint, String printCode, User user) {
		return this.startPrintJob(tenant, applicationId, partyId, processStatus, modulesPrint, printCode, user, MDC.get(MDCPreFilter.LOCALE));
	}

	public ApplicationGeneratedPrintDTO startPrintJob(String tenant, Long applicationId, Long partyId, String processStatus,
			List<PrintDetailsOutDTO> modulesPrint,
			String printCode, User user, String locale) {
		forceReadOnlyContextCheckerService.checkForReadOnlyContextFunctionByApplicationId(user, applicationId);
		if (modulesPrint.stream().noneMatch(x -> x.getPrintCode().equals(printCode))) {
			throw new RuntimeException("print code not valid");
		}
		return this.startPrintJob(tenant, applicationId, partyId, processStatus, printCode, user, locale,
				convertMap(modulesPrint.stream()
						.findFirst()
						.map(PrintDetailsOutDTO::getParams)
						.orElse(null)));
	}

	private Map<String, Object> convertMap(Map<String, String> map) {
        return new HashMap<>(Optional.ofNullable(map)
                .orElseGet(Collections::emptyMap));
	}

	public ApplicationGeneratedPrintDTO startPrintJob(String tenant, Long applicationId, Long partyId, String processStatus,
				String printCode, User user, String locale, Map<String, Object> params) {
		try {
			var paramMap = Optional.ofNullable(params).orElseGet(HashMap::new);
			paramMap.put("applicationId", applicationId);
			paramMap.put("partyId", partyId);
			var uuid = createPrintJobCaller.makeCall(CreatePrintJobInput.builder()
					.url(this.printEngineUrl)
					.bucketName(this.printBucketName)
					.destination(PRINT_DESTINATION)
					.printCode(printCode)
					.tenant(tenant)
					.token("JWT " + user.getAuthToken())
					.locale(locale)
					.params(paramMap)
					.build());
			return applicationGeneratedPrintCrudService.insert(ApplicationGeneratedPrintDTO.builder()
					.applicationId(applicationId)
					.printCode(printCode)
					.printDate(LocalDateTime.now())
					.processStatus(processStatus)
					.printJobUuid(uuid.getUuid())
					.username(user.getUserId())
					.build());
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			throw e;
		}

	}

	public Response getPrintFromFileStore(String tenant, Long applicationId, String fileId, User user) {
		Optional<ApplicationGeneratedPrintDTO> optApplicationGeneratedPrint = applicationGeneratedPrintCrudService
				.findPrintByApplicationIdAndFileId(tenant, applicationId, fileId);
		if (optApplicationGeneratedPrint.isPresent()) {

			DescriptionReplacerUtility.processDescriptionReplacer(applicationsCrudService, partyService, user, optApplicationGeneratedPrint.get(), tenant, applicationId);

			return this.fileStoreService
					.getFileForDownload(tenant, fileId, this.printBucketName, optApplicationGeneratedPrint.get().getPrintDescription(), user,
							new Sso2Authenticator(user));
		} else {
			throw new ObjectNotFoundRuntimeException("print not found");
		}
	}

	public List<PrintDetailsOutDTO> getPrintsByModuleIdAndProcessStatus(String tenant, Long applicationId, Long moduleId, String processStatus,
			List<String> profileCodeList, SecurityContext sc) {

		return modulePrintConfigsCrudService
				.find(tenant, moduleId, processStatus, profileCodeList)
				.stream()
				.filter(x -> StringUtils.isAllBlank(x.getContextFunction()) || sc.isUserInRole(x.getContextFunction()))
				.map(PrintDetailsOutMapper.INSTANCE::toPublicDTO)
				.map(x -> {
					x.setParams(modulePrintConfigParamCrudService.find(tenant, x.getPrintConfigId())
							.stream()
							.collect(Collectors
									.toMap(ModulePrintConfigParamDTO::getParameterName,
											ModulePrintConfigParamDTO::getParameterValue)));
					var lastPrint = applicationGeneratedPrintCrudService.findLastGeneratedPrintByCode(tenant, applicationId, x.getPrintCode());
					lastPrint.ifPresent(y -> x.setLastPrint(LastPrintDTO.builder()
							.printDate(y.getPrintDate())
							.fileId(y.getFileId())
							.build()));
					DescriptionReplacerUtility.processDescriptionReplacer(applicationsCrudService, partyService, (User) sc.getUserPrincipal(), x, tenant, applicationId);

					return x;
				})
				.collect(Collectors.toList());
	}

	public List<PrintDetailsOutDTO> getSystemPrintsByModuleId(String tenant, Long moduleId,
															  List<String> profileCodeList, String locale, SecurityContext sc) {

		return modulePrintConfigsCrudService
				.findSystemPrints(tenant, moduleId, profileCodeList, locale)
				.stream()
				.filter(x -> StringUtils.isAllBlank(x.getContextFunction()) || sc.isUserInRole(x.getContextFunction()))
				.map(PrintDetailsOutMapper.INSTANCE::toPublicDTO)
				.map(x -> {
					x.setParams(modulePrintConfigParamCrudService.find(tenant, x.getPrintConfigId())
							.stream()
							.collect(Collectors
									.toMap(ModulePrintConfigParamDTO::getParameterName,
											ModulePrintConfigParamDTO::getParameterValue)));
					return x;
				})
				.collect(Collectors.toList());
	}

	public List<ApplicationGeneratedPrintDTO> getApplicationPrintsByApplicationId(String tenant, Long applicationId, User user, SecurityContext sc) {
		return getApplicationPrintsByApplicationId(tenant, applicationId, null, user, sc);
	}

	public List<ApplicationGeneratedPrintDTO> getApplicationPrintsByApplicationId(String tenant, Long applicationId,
																				  String printCode, User user, SecurityContext sc) {
		try {
			var application = applicationsCrudService.findById(tenant, applicationId);
			try {
				this.checkPartyService.checkCanReadParty(tenant, application.getPartyId(), user);
			} catch (ActionNotAuthorizedRuntimeException e) {
				return Collections.emptyList();
			}
			var module = moduleCrudService.findById(application.getModuleId()).orElseThrow(() -> new ObjectNotFoundRuntimeException("module not found"));
			var printList = applicationGeneratedPrintCrudService.findAllGeneratedPrintsByPrintCode(tenant, applicationId, printCode);
			printList.stream()
					.forEach(x -> {
						x.setProcessStatus(
							applicationsWorkflowService.getWorkflowNode(tenant, module.getWorkflowCode(), x.getProcessStatus()).getDescription());
						DescriptionReplacerUtility.processDescriptionReplacer(applicationsCrudService, partyService, user, x, tenant, applicationId);
						x.setUsername(conditionallyOverrideUserId(x.getUsername(), sc));
					});

			return printList;
		} catch (ObjectNotFoundException e) {
			throw new ApplicationNotFoundRuntimeException("application not found");
		}
	}
}
