package com.abacogroup.agri.applications.core.exceptions;

import io.swagger.v3.oas.annotations.media.Schema;

import jakarta.ws.rs.core.Response;

public class ProfileCodeNotExistsRuntimeException extends AbstractException {

	private static final ProfileCodeNotExistsRuntimeException.ErrorBody BODY = new ProfileCodeNotExistsRuntimeException.ErrorBody();

	public ProfileCodeNotExistsRuntimeException(String message) {
		super(Response.Status.BAD_REQUEST, BODY, message);
	}

	public ProfileCodeNotExistsRuntimeException() {
		super(Response.Status.NOT_FOUND, BODY, "Profile code not exist");
	}

	@Schema(name = "ProfileCodeNotExistsRuntimeErrorBody")
	public static class ErrorBody implements ExceptionErrorBody {
		private static final String ERR = "PROFILE_CODE_NOT_EXISTS";

		@Override
		@Schema(allowableValues = ERR)
		public String getErrorCode() {
			return ERR;
		}
	}
}
