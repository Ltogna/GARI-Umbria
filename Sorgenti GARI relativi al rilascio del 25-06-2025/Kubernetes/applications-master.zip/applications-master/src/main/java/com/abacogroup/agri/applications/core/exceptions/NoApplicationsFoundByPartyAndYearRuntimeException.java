package com.abacogroup.agri.applications.core.exceptions;

import io.swagger.v3.oas.annotations.media.Schema;

import jakarta.ws.rs.core.Response;

public class NoApplicationsFoundByPartyAndYearRuntimeException extends AbstractException {

	private static final NoApplicationsFoundByPartyAndYearRuntimeException.ErrorBody BODY = new NoApplicationsFoundByPartyAndYearRuntimeException.ErrorBody();

	public NoApplicationsFoundByPartyAndYearRuntimeException(String message) {
		super(Response.Status.NOT_FOUND, BODY, message);
	}

	public NoApplicationsFoundByPartyAndYearRuntimeException() {
		super(Response.Status.NOT_FOUND, BODY, "No applications found");
	}

	@Schema(name = "NoApplicationsFoundByPartyAndYearExceptionErrorBody")
	public static class ErrorBody implements ExceptionErrorBody {
		private static final String ERR = "NO_APPLICATIONS_FOUND_BY_PARTY_AND_YEAR";

		@Override
		@Schema(allowableValues = ERR)
		public String getErrorCode() {
			return ERR;
		}
	}
}
