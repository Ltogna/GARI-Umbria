package com.abacogroup.agri.applications.core.model.dto;

import com.abacogroup.agri.applications.core.model.dto.publics.DescriptionReplacer;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.time.LocalDateTime;

/**
 * @author Gennaro Tamburrelli
 */
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class ApplicationGeneratedPrintDTO implements DescriptionReplacer {

	@JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
	private Long pkid;
	@JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
	private Long applicationId;
	@Schema(description = "the application's process status at print date")
	private String processStatus;
	@Schema(description = "the print code")
	private String printCode;
	@Schema(description = "the print description")
	private String printDescription;
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	@Schema(description = "the print date")
	private LocalDateTime printDate;
	@Schema(description = "the print job uuid")
	private String printJobUuid;
	@Schema(description = "the print file id for download")
	private String fileId;
	@Schema(description = "the user who generated the print")
	private String username;
	@Schema(description = "the print status: can be ERROR or READY")
	private String printStatus;

	@Override public String getDescription() {
		return printDescription;
	}

	@Override public void setDescription(String parsedDescription) {
		printDescription = parsedDescription;
	}
}
