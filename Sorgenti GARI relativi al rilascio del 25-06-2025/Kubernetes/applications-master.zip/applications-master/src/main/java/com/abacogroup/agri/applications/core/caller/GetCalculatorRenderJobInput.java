package com.abacogroup.agri.applications.core.caller;

import com.abacogroup.jaxrsutils.callerv2.ICallerInput;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Map;

import static com.abacogroup.jaxrsutils.GenericCallerService.GET_METHOD;

/**
 * @author Alexandru Paraschiv
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class GetCalculatorRenderJobInput implements ICallerInput {

	private String url;
	private String tenant;
	private String uuid;
	private String token;
	private String locale;

	@Override
	public Map<String, Object> getPathVariablesMap() {
		return Map.of("TENANT_ID", this.tenant,
				"UUID", this.uuid);
	}

	@Override
	public String provideAuthToken() {
		return this.token;
	}

	@Override
	public String getUrl() {
		return this.url + "/{TENANT_ID}/public/v1/jobs/{UUID}/results/render";
	}

	@Override
	public String getHttpMethod() {
		return GET_METHOD;
	}

	@Override public String locale() {
		return this.locale;
	}
}
