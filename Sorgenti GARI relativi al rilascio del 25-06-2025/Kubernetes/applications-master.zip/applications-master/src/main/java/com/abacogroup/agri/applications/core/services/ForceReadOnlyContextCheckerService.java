package com.abacogroup.agri.applications.core.services;

import com.abacogroup.agri.applications.core.exceptions.ActionNotAuthorizedRuntimeException;
import com.abacogroup.agri.applications.core.exceptions.ObjectNotFoundException;
import com.abacogroup.agri.applications.core.services.crud.ApplicationsCrudService;
import com.abacogroup.agri.applications.core.services.crud.ModuleCrudService;
import com.abacogroup.dropwizard.auth.sso2.Sso2Client;
import com.abacogroup.dropwizard.auth.sso2.User;
import io.dropwizard.auth.AuthenticationException;
import jakarta.ws.rs.core.SecurityContext;

/**
 * @author Gennaro Tamburrelli
 */
public class ForceReadOnlyContextCheckerService {

    private final ApplicationsCrudService applicationsCrudService;
    private final ModuleCrudService moduleCrudService;
    private final Sso2Client sso2Client;

    public ForceReadOnlyContextCheckerService(ApplicationsCrudService applicationsCrudService, ModuleCrudService moduleCrudService, Sso2Client sso2Client) {
        this.applicationsCrudService = applicationsCrudService;
        this.moduleCrudService = moduleCrudService;
        this.sso2Client = sso2Client;
    }

    public void checkForReadOnlyContextFunctionByApplicationId(User user, Long applicationId) {
        try {
            this.checkForReadOnlyContextFunctionByModuleId(user, applicationsCrudService.findById(user.getTenant(), applicationId).getModuleId());
        } catch (ObjectNotFoundException e) {
            throw new RuntimeException(e);
        }

    }

    public void checkForReadOnlyContextFunctionByModuleId(User user, Long moduleId) {
        if(this.moduleHasReadOnlyAndUserHasIt(user, moduleId)) {
            throw new ActionNotAuthorizedRuntimeException("user has read only context function");
        }
    }

    public boolean moduleHasReadOnlyAndUserHasIt(User user, Long moduleId) {
        var moduleWithDetails = moduleCrudService.findModuleWithDetail(moduleId);
        if(moduleWithDetails.getForceReadOnlyContextFunction() != null) {
            try {
                SecurityContext sc = sso2Client.createSecurityContextFromUserId(user.getTenant(), user.getUserId());
                return sc.isUserInRole(moduleWithDetails.getForceReadOnlyContextFunction());
            } catch (AuthenticationException e) {
                throw new RuntimeException(e);
            }
        }
        return false;
    }

    public boolean moduleHasReadOnlyAndUserHasIt(SecurityContext sc, Long moduleId) {
        var moduleWithDetails = moduleCrudService.findModuleWithDetail(moduleId);
        if(moduleWithDetails.getForceReadOnlyContextFunction() != null) {
            return sc.isUserInRole(moduleWithDetails.getForceReadOnlyContextFunction());
        }
        return false;
    }
}
