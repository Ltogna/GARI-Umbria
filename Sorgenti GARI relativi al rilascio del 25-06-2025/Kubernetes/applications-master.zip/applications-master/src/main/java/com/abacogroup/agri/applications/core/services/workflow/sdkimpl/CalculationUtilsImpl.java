package com.abacogroup.agri.applications.core.services.workflow.sdkimpl;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import com.abacogroup.agri.applications.core.model.dto.ApplicationProfileDTO;
import com.abacogroup.agri.applications.core.model.dto.CalculationJobStatus;
import com.abacogroup.agri.applications.core.model.dto.publics.ApplicationCalculationRenderPublicDTO;
import com.abacogroup.agri.applications.core.model.dto.publics.CalculationDetailsOutDTO;
import com.abacogroup.agri.applications.core.services.ApplicationsService;
import com.abacogroup.agri.applications.core.services.calculation.CalculationService;
import com.abacogroup.agri.applications.core.services.crud.ApplicationProfilesCrudService;
import com.abacogroup.agri.applications.core.services.crud.ApplicationsCrudService;
import com.abacogroup.applicationworkflowsdk.model.CalculationRender;
import com.abacogroup.applicationworkflowsdk.model.GeneratedCalculationDTO;
import com.abacogroup.applicationworkflowsdk.model.GeneratedCalculationWithResultsDTO;
import com.abacogroup.applicationworkflowsdk.service.CalculationUtils;
import com.abacogroup.dropwizard.auth.sso2.Sso2Client;
import com.abacogroup.dropwizard.auth.sso2.User;
import com.fasterxml.jackson.databind.ObjectMapper;

import io.dropwizard.auth.AuthenticationException;
import lombok.extern.slf4j.Slf4j;

/**
 * @author Gennaro Tamburrelli
 */
@Slf4j
public class CalculationUtilsImpl implements CalculationUtils {

	private final ApplicationsCrudService applicationsCrudService;
	private final ApplicationProfilesCrudService applicationProfilesCrudService;
	private final CalculationService calculationService;
	private final Sso2Client sso2Client;
	private final ObjectMapper objectMapper;

	public CalculationUtilsImpl(ApplicationsCrudService applicationsCrudService,
			ApplicationProfilesCrudService applicationProfilesCrudService, CalculationService calculationService, Sso2Client sso2Client,
			ObjectMapper objectMapper) {
		this.applicationsCrudService = applicationsCrudService;
		this.applicationProfilesCrudService = applicationProfilesCrudService;
		this.calculationService = calculationService;
		this.sso2Client = sso2Client;
		this.objectMapper = objectMapper;
	}

	@Override
	public void startCalculation(String tenant, Long applicationId, String calculationCode, String locale, User user, boolean forceProcessStatus,
			String processStatus) throws AuthenticationException {
		var app = applicationsCrudService.findWithDetailsByApplicationId(tenant, applicationId);
		app.setProfileList(applicationProfilesCrudService.findAll(tenant, app.getApplicationId(), locale));
		ApplicationsService.computeApplicationProfilesDescription(app.getProfileList()).ifPresent(app::setApplicationProfilesDescription);

		List<String> requiredProfileCodes = app.getProfileList()
				.stream()
				.map(ApplicationProfileDTO::getProfileCode)
				.collect(Collectors.toList());

		List<CalculationDetailsOutDTO> modulesCalc = calculationService
				.getCalculationsByModuleIdAndProcessStatus(tenant,
						applicationId,
						app.getModuleId(),
						forceProcessStatus ? processStatus : app.getProcessStatus(),
						requiredProfileCodes.isEmpty() ? new ArrayList<>(List.of("")) : requiredProfileCodes,
						sso2Client.createSecurityContextFromUserName(tenant, user.getName()));
		if (modulesCalc.isEmpty()) {
			log.info("calc not found");
		} else {
			calculationService
					.startCalculatorJob(tenant, applicationId, app.getProcessStatus(), modulesCalc, calculationCode, user, locale);
		}

	}

	@Override
	public List<GeneratedCalculationDTO> retrieveCalculationHistory(String tenant, Long applicationId, User user) {
		return calculationService.getApplicationCalculationsByApplicationId(tenant, applicationId, user, null)
				.stream()
				.map(x -> GeneratedCalculationDTO.builder()
						.pkid(x.getPkid())
						.applicationId(x.getApplicationId())
						.processStatus(x.getProcessStatus())
						.calculationCode(x.getCalculationCode())
						.calculationDescription(x.getCalculationDescription())
						.calculationDate(x.getCalculationDate())
						.username(x.getUsername())
						.calculationJobUuid(x.getCalculationJobUuid())
						.calculationStatus(x.getCalculationStatus())
						.notes(x.getNotes())
						.build())
				.collect(Collectors.toList());
	}

	public <T> Optional<GeneratedCalculationWithResultsDTO<T>> retrieveLastCalculation(String tenant, Long applicationId, String calcCode, User user,
			Class<T> type) {
		Optional<GeneratedCalculationDTO> optResult = this.retrieveCalculationHistory(tenant, applicationId, user).stream()
				.filter(x -> x.getCalculationCode().equals(calcCode))
				.filter(x -> x.getCalculationStatus().equals(CalculationJobStatus.READY.name()))
				.max(Comparator.comparing(GeneratedCalculationDTO::getCalculationDate));
		if (optResult.isEmpty()) {
			return Optional.empty();
		} else {
			var result = optResult.get();
			GeneratedCalculationWithResultsDTO<T> calcWithResult = new GeneratedCalculationWithResultsDTO<>(
					GeneratedCalculationDTO.builder()
							.pkid(result.getPkid())
							.applicationId(result.getApplicationId())
							.processStatus(result.getProcessStatus())
							.processDescription(result.getProcessDescription())
							.calculationCode(result.getCalculationCode())
							.calculationDescription(result.getCalculationDescription())
							.calculationDate(result.getCalculationDate())
							.calculationJobUuid(result.getCalculationJobUuid())
							.username(result.getUsername())
							.calculationStatus(result.getCalculationStatus())
							.build(),
					parseResult(
							calculationService.getCalculationRawByJobUuidReadyStatus(tenant, applicationId, user, result.getCalculationJobUuid()).getResult(),
							type, objectMapper),
					getRendered(calculationService.getCalculationRenderByJobUuidReadyStatus(tenant, applicationId, user, result.getCalculationJobUuid())));
			return Optional.of(calcWithResult);
		}
	}

	private CalculationRender getRendered(ApplicationCalculationRenderPublicDTO calculationRenderByJobUuidReadyStatus) {
		return CalculationRender.builder()
				.sections(calculationRenderByJobUuidReadyStatus.getResult().getSections())
				.tagLabels(calculationRenderByJobUuidReadyStatus.getResult().getTagLabels())
				.build();
	}

	public <T> T parseResult(String s, Class<T> clazz, ObjectMapper objectMapper) {
		try {
			return objectMapper.readValue(s, clazz);
		} catch (Exception e) {
			throw new RuntimeException(e.getMessage(), e);
		}
	}
}
