package com.abacogroup.agri.applications.core.mappers;

import com.abacogroup.applicationworkflowsdk.model.DetailedSdkTransitionLog;
import com.abacogroup.workflow.server.model.DetailedTransitionLog;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper
public interface DetailLogMapper extends EntityMapper<DetailedSdkTransitionLog, DetailedTransitionLog> {

	DetailLogMapper INSTANCE = Mappers.getMapper(DetailLogMapper.class);

	@InheritInverseConfiguration()
	DetailedSdkTransitionLog entityToDto(DetailedTransitionLog entity);

	DetailedTransitionLog dtoToEntity(DetailedSdkTransitionLog dto);

}
