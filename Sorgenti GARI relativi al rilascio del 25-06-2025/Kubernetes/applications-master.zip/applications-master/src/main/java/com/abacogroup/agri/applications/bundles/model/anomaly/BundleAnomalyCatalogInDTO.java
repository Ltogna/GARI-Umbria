package com.abacogroup.agri.applications.bundles.model.anomaly;

import com.abacogroup.agri.applications.bundles.model.I18nPair;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * @author Gennaro Tamburrelli
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class BundleAnomalyCatalogInDTO {
	private String anomalyCode;
	private String severity;
	private String moduleCode;
	private List<I18nPair> i18n;

}
