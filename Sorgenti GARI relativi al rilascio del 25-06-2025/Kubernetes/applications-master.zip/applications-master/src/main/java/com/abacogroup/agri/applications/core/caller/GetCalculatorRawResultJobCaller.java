package com.abacogroup.agri.applications.core.caller;

import com.abacogroup.jaxrsutils.GenericCallerService;
import com.abacogroup.jaxrsutils.callerv2.AbacoDtoCaller;

/**
 * @author Alexandru Paraschiv
 */
public class GetCalculatorRawResultJobCaller extends AbacoDtoCaller<GetCalculatorRawJobInput, String> {

	public GetCalculatorRawResultJobCaller(GenericCallerService genericCallerService) {
		super(genericCallerService);
	}

}
