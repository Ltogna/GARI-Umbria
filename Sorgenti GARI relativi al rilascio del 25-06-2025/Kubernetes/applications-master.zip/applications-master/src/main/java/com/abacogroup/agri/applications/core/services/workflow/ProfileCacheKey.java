package com.abacogroup.agri.applications.core.services.workflow;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author Gennaro Tamburrelli
 */
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Data
public class ProfileCacheKey {

	private String tenant;
	private Long applicationId;
}
