package com.abacogroup.agri.applications.db.ntt;

import com.abacogroup.agri.applications.db.ntt.applications.IIdRs;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.util.Optional;

/**
 * @author Mattia Perini
 */
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class ModuleCalculationConfigsNTT implements IIdRs<Long> {

	private Long id;
	private Long module_id;
	private String process_status;
	private String calculation_code;
	private String calculation_description;
	private Integer sort_order;
	private String context_function;

	@Override
	public Optional<Long> getKey() {
		return Optional.ofNullable(this.id);
	}

	@Override
	public void setKey(Long id) {
		this.id = id;
	}
}
