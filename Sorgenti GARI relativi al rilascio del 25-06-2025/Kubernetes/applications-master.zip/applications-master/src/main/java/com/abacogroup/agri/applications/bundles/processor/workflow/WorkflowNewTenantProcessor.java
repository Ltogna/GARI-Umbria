package com.abacogroup.agri.applications.bundles.processor.workflow;

import com.abacogroup.bundles.listener.tenant.TenantMessage;
import com.abacogroup.bundles.listener.tenant.TenantMessageProcessor;
import lombok.extern.slf4j.Slf4j;
import org.jdbi.v3.core.Jdbi;

import static com.abacogroup.agri.applications.bundles.BundleConstants.TENANT_TEMPLATE_CODE;

/**
 * @author Gennaro Tamburrelli
 */
@Slf4j
public class WorkflowNewTenantProcessor implements TenantMessageProcessor {

	protected final Jdbi jdbi;
	protected final WorkflowsBundleWorker workflowsBundleWorker;

	public WorkflowNewTenantProcessor(Jdbi jdbi, WorkflowsBundleWorker workflowsBundleWorker) {
		this.jdbi = jdbi;
		this.workflowsBundleWorker = workflowsBundleWorker;
	}

	@Override
	public void onMessage(TenantMessage message) {
		jdbi.useTransaction(handle -> {
			log.info("WorkflowNewTenantProcessor got new tenant {}", message.getTenantId());
			checkAndInsertWorkflows(message.getTenantId());
			log.info("WorkflowNewTenantProcessor end working with new tenant {}", message.getTenantId());
		});
	}

	private void checkAndInsertWorkflows(String tenantId) {
		log.info("WorkflowNewTenantProcessor check and insert new tenant {}", tenantId);
		var service = workflowsBundleWorker.exposeApplicationsWorkflowService();
		service.getWorkflowFilesByTenantAndInsertThem(TENANT_TEMPLATE_CODE, tenantId);
	}

}
