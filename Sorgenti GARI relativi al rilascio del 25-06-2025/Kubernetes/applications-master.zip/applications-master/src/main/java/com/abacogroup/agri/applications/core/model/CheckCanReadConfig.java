package com.abacogroup.agri.applications.core.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
public class CheckCanReadConfig {
	private Boolean active;
	private String key;
	private Boolean override;
	private String overriddenUrl;
}
