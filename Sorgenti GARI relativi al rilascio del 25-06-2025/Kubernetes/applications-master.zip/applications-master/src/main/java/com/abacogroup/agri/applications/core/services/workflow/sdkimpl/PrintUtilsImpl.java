package com.abacogroup.agri.applications.core.services.workflow.sdkimpl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import com.abacogroup.agri.applications.core.model.dto.ApplicationProfileDTO;
import com.abacogroup.agri.applications.core.model.dto.publics.PrintDetailsOutDTO;
import com.abacogroup.agri.applications.core.services.ApplicationsService;
import com.abacogroup.agri.applications.core.services.crud.ApplicationProfilesCrudService;
import com.abacogroup.agri.applications.core.services.crud.ApplicationsCrudService;
import com.abacogroup.agri.applications.core.services.print.PrintService;
import com.abacogroup.applicationworkflowsdk.model.GeneratedPrintDTO;
import com.abacogroup.applicationworkflowsdk.service.PrintUtils;
import com.abacogroup.dropwizard.auth.sso2.Sso2Client;
import com.abacogroup.dropwizard.auth.sso2.User;

import io.dropwizard.auth.AuthenticationException;
import lombok.extern.slf4j.Slf4j;

/**
 * @author Gennaro Tamburrelli
 */
@Slf4j
public class PrintUtilsImpl implements PrintUtils {

	private final ApplicationsCrudService applicationsCrudService;
	private final ApplicationProfilesCrudService applicationProfilesCrudService;
	private final PrintService printService;
	private final Sso2Client sso2Client;

	public PrintUtilsImpl(ApplicationsCrudService applicationsCrudService,
			ApplicationProfilesCrudService applicationProfilesCrudService, PrintService printService, Sso2Client sso2Client) {
		this.applicationsCrudService = applicationsCrudService;
		this.applicationProfilesCrudService = applicationProfilesCrudService;
		this.printService = printService;
		this.sso2Client = sso2Client;
	}

	@Override
	public void startPrint(String tenant, Long applicationId, String printCode, String locale, User user, boolean forceProcessStatus,
			String processStatus) throws AuthenticationException {
		var app = applicationsCrudService.findWithDetailsByApplicationId(tenant, applicationId);
		app.setProfileList(applicationProfilesCrudService.findAll(tenant, app.getApplicationId(), locale));
		ApplicationsService.computeApplicationProfilesDescription(app.getProfileList()).ifPresent(app::setApplicationProfilesDescription);

		List<String> requiredProfileCodes = app.getProfileList()
				.stream()
				.map(ApplicationProfileDTO::getProfileCode)
				.collect(Collectors.toList());
		List<PrintDetailsOutDTO> modulesPrint = printService
				.getPrintsByModuleIdAndProcessStatus(tenant,
						applicationId,
						app.getModuleId(),
						forceProcessStatus ? processStatus : app.getProcessStatus(),
						requiredProfileCodes.isEmpty() ? new ArrayList<>(List.of("")) : requiredProfileCodes,
						sso2Client.createSecurityContextFromUserName(tenant, user.getName()));
		executePrint(tenant, applicationId, printCode, locale, user, modulesPrint, app.getPartyId(), app.getProcessStatus());

	}

	private void executePrint(String tenant, Long applicationId, String printCode, String locale, User user,
							  List<PrintDetailsOutDTO> modulesPrint, Long partyId, String processStatus) {
		if (modulesPrint.isEmpty()) {
			log.info("print not found");
		} else {
			printService
					.startPrintJob(tenant, applicationId, partyId, processStatus, modulesPrint, printCode, user, locale);
		}
	}

	@Override
	public void startSystemPrint(String tenant, Long applicationId, String printCode, String processStatus,
								 String locale, User user) throws AuthenticationException {
		var app = applicationsCrudService.findWithDetailsByApplicationId(tenant, applicationId);
		List<String> requiredProfileCodes = applicationProfilesCrudService.findAll(tenant, applicationId, locale)
				.stream()
				.map(ApplicationProfileDTO::getProfileCode)
				.collect(Collectors.toList());

		List<PrintDetailsOutDTO> modulesPrint = printService
				.getSystemPrintsByModuleId(tenant,
						app.getModuleId(),
						requiredProfileCodes.isEmpty() ? new ArrayList<>(List.of("")) : requiredProfileCodes,
						locale,
						sso2Client.createSecurityContextFromUserName(tenant, user.getName()));

		executePrint(tenant, applicationId, printCode, locale, user, modulesPrint, app.getPartyId(),
				Optional.ofNullable(processStatus).orElse(app.getProcessStatus()));
	}

	@Override
	public List<GeneratedPrintDTO> retrievePrintHistory(String tenant, Long applicationId, User user) {
		return printService.getApplicationPrintsByApplicationId(tenant, applicationId, user, null)
				.stream()
				.map(x -> GeneratedPrintDTO.builder()
						.pkid(x.getPkid())
						.applicationId(x.getApplicationId())
						.processStatus(x.getProcessStatus())
						.printCode(x.getPrintCode())
						.printDescription(x.getPrintDescription())
						.printDate(x.getPrintDate())
						.fileId(x.getFileId())
						.username(x.getUsername())
						.printJobUuid(x.getPrintJobUuid())
						.processStatus(x.getPrintStatus())
						.build())
				.collect(Collectors.toList());
	}
}
