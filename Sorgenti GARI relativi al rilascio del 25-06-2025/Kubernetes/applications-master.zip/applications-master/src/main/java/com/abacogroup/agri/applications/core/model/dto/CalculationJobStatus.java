package com.abacogroup.agri.applications.core.model.dto;

public enum CalculationJobStatus {

	ACKNOWLEDGE,
	PROGRESS,
	ERROR,
	READY
}
