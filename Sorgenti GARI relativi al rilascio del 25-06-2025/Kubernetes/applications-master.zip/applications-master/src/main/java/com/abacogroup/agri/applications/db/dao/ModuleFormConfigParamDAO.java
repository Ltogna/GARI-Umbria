package com.abacogroup.agri.applications.db.dao;

import com.abacogroup.agri.applications.db.ntt.ModuleFormConfigParamNTT;
import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.customizer.BindBean;
import org.jdbi.v3.sqlobject.customizer.BindList;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;

import java.util.List;

/**
 * @author Gennaro Tamburrelli
 */
public interface ModuleFormConfigParamDAO extends IGenericDAO<ModuleFormConfigParamNTT, Void> {

	@Override
	@SqlQuery("not implemented")
	Void nextSequenceVal();

	@SqlUpdate("INSERT INTO apps_module_form_config_params " +
			"(module_form_config_id, parameter_name, parameter_value) " +
			"VALUES(:module_form_config_id, :parameter_name, :parameter_value)")
	void insert(@BindBean ModuleFormConfigParamNTT formGroup);

	@SqlQuery("SELECT p.module_form_config_id," +
			"p.parameter_name, " +
			"p.parameter_value " +
			"FROM apps_module_form_config_params p " +
			"WHERE p.module_form_config_id=:module_form_config_id and p.parameter_name = :parameter_name " +
			"and :tenant_id in " +
			"(SELECT s.tenant_id " +
			" FROM apps_sectors s INNER JOIN apps_modules m ON s.id = m.sector_id" +
			"      INNER JOIN apps_module_form_configs c ON m.id = c.module_id " +
			" WHERE p.module_form_config_id = c.id" +
			" and §current_timestamp§ between m.dt_insert and m.dt_delete)")
	@RegisterBeanMapper(ModuleFormConfigParamNTT.class)
	List<ModuleFormConfigParamNTT> findById(@Bind("tenant_id") String tenantId, @Bind("module_form_config_id") Long moduleFormConfigId,
			@Bind("parameter_name") String parameterName);

	@SqlQuery("SELECT p.module_form_config_id," +
			"p.parameter_name, " +
			"p.parameter_value " +
			"FROM apps_module_form_config_params p " +
			"WHERE p.module_form_config_id=:module_form_config_id AND p.parameter_name = :parameter_name")
	@RegisterBeanMapper(ModuleFormConfigParamNTT.class)
	List<ModuleFormConfigParamNTT> findById(@Bind("module_form_config_id") Long moduleFormConfigId,
			@Bind("parameter_name") String parameterName);

	@SqlQuery("SELECT p.module_form_config_id," +
			"p.parameter_name, " +
			"p.parameter_value " +
			"FROM apps_module_form_config_params p " +
			"WHERE p.module_form_config_id=:module_form_config_id AND " +
			":tenant_id in " +
			"(SELECT s.tenant_id " +
			" FROM apps_sectors s INNER JOIN apps_modules m ON s.id = m.sector_id" +
			"      INNER JOIN apps_module_form_configs c ON m.id = c.module_id " +
			" WHERE p.module_form_config_id = c.id" +
			" and §current_timestamp§ between m.dt_insert and m.dt_delete)")
	@RegisterBeanMapper(ModuleFormConfigParamNTT.class)
	List<ModuleFormConfigParamNTT> find(@Bind("tenant_id") String tenantId, @Bind("module_form_config_id") Long moduleFormConfigId);

	@SqlUpdate("UPDATE apps_module_form_config_params SET " +
			"parameter_value=:parameter_value " +
			"where module_form_config_id=:module_form_config_id and parameter_name=:parameter_name")
	void update(@BindBean ModuleFormConfigParamNTT sector);

	@SqlUpdate("DELETE FROM apps_module_form_config_params p " +
			"WHERE p.module_form_config_id=:module_form_config_id AND p.parameter_name = :parameter_name")
	void deleteById(@Bind("module_form_config_id") Long moduleFormConfigId,
			@Bind("parameter_name") String parameterName);

	@SqlUpdate("DELETE FROM apps_module_form_config_params p " +
			"WHERE p.module_form_config_id=:module_form_config_id")
	void deleteByModuleFormConfigId(@Bind("module_form_config_id") Long moduleFormConfigId);

	@SqlQuery("SELECT p.parameter_value " +
			" FROM apps_module_form_config_params p " +
			" WHERE p.module_form_config_id IN (<module_form_config_ids>)")
	List<String> findOptionCodesByModuleFormConfigIds(@BindList("module_form_config_ids") List<Long> moduleFormConfigId);

	@SqlUpdate("DELETE FROM APPS_MODULE_FORM_CONFIG_PARAMS amfcp " +
			"WHERE amfcp.MODULE_FORM_CONFIG_ID IN ( " +
			"  SELECT param.MODULE_FORM_CONFIG_ID  " +
			"  FROM APPS_MODULE_FORM_CONFIG_PARAMS param  " +
			"  JOIN APPS_MODULE_FORM_CONFIGS amfc ON param.MODULE_FORM_CONFIG_ID = amfc.ID  " +
			"  WHERE amfc.MODULE_ID  = :moduleId)")
	void bulkDeleteByModuleId(@Bind("moduleId") Long moduleId);
}
