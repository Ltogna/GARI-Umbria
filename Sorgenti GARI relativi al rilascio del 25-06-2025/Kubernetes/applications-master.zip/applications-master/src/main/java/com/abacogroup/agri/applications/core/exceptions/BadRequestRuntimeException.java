package com.abacogroup.agri.applications.core.exceptions;

import io.swagger.v3.oas.annotations.media.Schema;

import jakarta.ws.rs.core.Response;

public class BadRequestRuntimeException extends AbstractException {

	private static final BadRequestRuntimeException.ErrorBody BODY = new BadRequestRuntimeException.ErrorBody();

	public BadRequestRuntimeException(String message) {
		super(Response.Status.BAD_REQUEST, BODY, message);
	}

	@Schema(name = "BadRequestRuntimeExceptionErrorBody")
	public static class ErrorBody implements ExceptionErrorBody {
		private static final String ERR = "BAD_REQUEST_ERROR";

		@Override
		@Schema(allowableValues = ERR)
		public String getErrorCode() {
			return ERR;
		}
	}
}
