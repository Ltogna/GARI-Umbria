package com.abacogroup.agri.applications.core.model.dto;

public enum PrintJobStatus {

	ACKNOWLEDGE,
	PROGRESS,
	ERROR,
	READY
}
