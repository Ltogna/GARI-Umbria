package com.abacogroup.agri.applications.core.mappers;

import com.abacogroup.agri.applications.core.model.dto.ModuleDetailsDTO;
import com.abacogroup.agri.applications.db.ntt.ModuleDetailsNTT;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

@Mapper(uses = AbsoluteDateMapper.class)
public interface ModuleDetailsMapper extends EntityMapper<ModuleDetailsDTO, ModuleDetailsNTT> {

	ModuleDetailsMapper INSTANCE = Mappers.getMapper(ModuleDetailsMapper.class);

	@InheritInverseConfiguration()
	ModuleDetailsDTO entityToDto(ModuleDetailsNTT entity);

	@Mapping(source = "pkid", target = "pkid")
	@Mapping(source = "moduleId", target = "module_id")
	@Mapping(source = "annuality", target = "annuality")
	@Mapping(source = "contextFunction", target = "context_function")
	@Mapping(source = "forceReadOnlyContextFunction", target = "force_read_only_context_function")
	@Mapping(source = "dtValidityStart", target = "dt_validity_start")
	@Mapping(source = "dtValidityEnd", target = "dt_validity_end")
	ModuleDetailsNTT dtoToEntity(ModuleDetailsDTO dto);

}
