package com.abacogroup.agri.applications.core.mappers;

import com.abacogroup.agri.applications.core.model.dto.ModulePrintConfigProfileDTO;
import com.abacogroup.agri.applications.db.ntt.ModulePrintConfigProfileNTT;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

@Mapper(uses = AbsoluteDateMapper.class)
public interface ModulePrintConfigProfileMapper extends EntityMapper<ModulePrintConfigProfileDTO, ModulePrintConfigProfileNTT> {

	ModulePrintConfigProfileMapper INSTANCE = Mappers.getMapper(ModulePrintConfigProfileMapper.class);

	@InheritInverseConfiguration()
	ModulePrintConfigProfileDTO entityToDto(ModulePrintConfigProfileNTT entity);

	@Mapping(source = "modulePrintConfigId", target = "module_print_config_id")
	@Mapping(source = "requiredProfileCode", target = "required_profile_code")
	ModulePrintConfigProfileNTT dtoToEntity(ModulePrintConfigProfileDTO dto);

}
