package com.abacogroup.agri.applications.core.services.embededqueue;

import static com.abacogroup.embeddedqueue.QueueErrorListener.ErrorAction.DELETE_FROM_QUEUE;

import com.abacogroup.agri.applications.core.exceptions.ObjectNotFoundException;
import com.abacogroup.agri.applications.core.model.ProcessTransitionEnum;
import com.abacogroup.agri.applications.core.services.crud.ApplicationDetailsCrudService;
import com.abacogroup.agri.applications.core.services.embededqueue.model.QueueWorkflowParams;
import com.abacogroup.agri.applications.core.services.workflow.ApplicationsWorkflowService;
import com.abacogroup.embeddedqueue.QueueErrorListener;
import com.abacogroup.embeddedqueue.WorkQueue;
import com.abacogroup.embeddedqueue.db.JdbiRepository;
import com.abacogroup.workflow.sdk.beans.ProcessData;
import com.codahale.metrics.MetricRegistry;
import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.extern.slf4j.Slf4j;

/**
 * @author Gennaro Tamburrelli
 */
@Slf4j
public class UpdateProcessQueue extends WorkQueue<QueueWorkflowParams> {

	private ApplicationsWorkflowService applicationsWorkflowService;
	private ApplicationDetailsCrudService applicationDetailsCrudService;

	public UpdateProcessQueue(JdbiRepository repo, ObjectMapper objectMapper, MetricRegistry registry,
			ApplicationsWorkflowService applicationsWorkflowService, ApplicationDetailsCrudService applicationDetailsCrudService,
			int numThreads, long timeoutMs) {
		super("app-update-process", repo, numThreads, timeoutMs);
		this.applicationsWorkflowService = applicationsWorkflowService;
		this.applicationDetailsCrudService = applicationDetailsCrudService;
		this.setObjectMapper(objectMapper);
		this.setMetricRegistry(registry);
		this.setConsumer(this::consumer);
		this.setErrorListener(handleError);
		this.start();
	}

	public void executeTransition(QueueWorkflowParams queueWorkflowParams, ProcessData parentProcessData) throws Exception {
		consumer(queueWorkflowParams, parentProcessData);
	}

	@Override
	protected Class<QueueWorkflowParams> getJobClass() {
		return QueueWorkflowParams.class;
	}

	private void consumer(QueueWorkflowParams appParams) throws ObjectNotFoundException {
		consumer(appParams, null);
	}

	private void consumer(QueueWorkflowParams appParams, ProcessData parentProcessData) throws ObjectNotFoundException {
		try {
			if (parentProcessData != null) {
				applicationsWorkflowService
						.executeProcessTransitionWithParentProcessData(appParams.getTenant(),
								appParams.getApplicationId(),
								appParams.getProcessId(),
								appParams.getTransitionId(),
								appParams.getUserid(),
								appParams.getLocale(),
								appParams.getScope(),
								appParams.getNotes(),
								parentProcessData);
			} else {
				applicationsWorkflowService
						.executeProcessTransition(appParams.getTenant(),
								appParams.getApplicationId(),
								appParams.getProcessId(),
								appParams.getTransitionId(),
								appParams.getUserid(),
								appParams.getLocale(),
								appParams.getScope(),
								appParams.getNotes());
			}
		} catch (Exception e) {
			applicationDetailsCrudService.updateFlTransition(appParams.getTenant(), appParams.getApplicationId(),
					appParams.getUserid(),
					ProcessTransitionEnum.NOT_IN_TRANSITION);
			throw e;
		}
	}

	private final QueueErrorListener<QueueWorkflowParams> handleError = (appParams, exp) -> {
		try {
			applicationDetailsCrudService.updateFlTransition(appParams.getTenant(),
					appParams.getApplicationId(),
					appParams.getUserid(),
					ProcessTransitionEnum.NOT_IN_TRANSITION);
		} catch (ObjectNotFoundException e) {
			log.error(e.getMessage(), e);
		}
		return DELETE_FROM_QUEUE;
	};

}
