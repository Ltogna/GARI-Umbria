package com.abacogroup.agri.applications.core.model.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

/**
 * @author Mauro Pozzana
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@SuperBuilder
public class RolesVerifierUserRoleDTO {
	@Schema(description = "The role to verify")
	private String role;
	@Schema(description = "True if the role is owned")
	private Boolean isOwned;
}
