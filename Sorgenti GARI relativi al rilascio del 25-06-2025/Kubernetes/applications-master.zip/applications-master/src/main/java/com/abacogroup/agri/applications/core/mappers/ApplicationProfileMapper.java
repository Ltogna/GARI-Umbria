package com.abacogroup.agri.applications.core.mappers;

import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import com.abacogroup.agri.applications.core.model.dto.ApplicationProfileDTO;
import com.abacogroup.agri.applications.db.ntt.ApplicationProfileNTT;

@Mapper
public interface ApplicationProfileMapper extends EntityMapper<ApplicationProfileDTO, ApplicationProfileNTT> {

	ApplicationProfileMapper INSTANCE = Mappers.getMapper(ApplicationProfileMapper.class);

	@InheritInverseConfiguration()
	ApplicationProfileDTO entityToDto(ApplicationProfileNTT entity);

	@Mapping(source = "pkid", target = "pkid")
	@Mapping(source = "applicationId", target = "application_id")
	@Mapping(source = "profileCode", target = "profile_code")
	@Mapping(source = "profileCodeDescription", target = "profile_code_description")
	@Mapping(source = "profileLabelExposed", target = "fl_label_exposed")
	ApplicationProfileNTT dtoToEntity(ApplicationProfileDTO dto);

	default Boolean map(Integer value) {
		if (value != null)
			return value.intValue() != 0;
		return null;
	}

	default Integer map(Boolean value) {
		if (value != null)
			return value ? 1 : 0;

		return null;
	}

}
