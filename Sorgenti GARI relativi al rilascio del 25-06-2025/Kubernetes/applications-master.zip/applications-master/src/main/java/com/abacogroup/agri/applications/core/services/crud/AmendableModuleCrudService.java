package com.abacogroup.agri.applications.core.services.crud;

import static com.abacogroup.agri.applications.core.services.crud.AbstractCrudService.OBJECT_NOT_FOUND_EXCEPTION_SUPPLIER;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import com.abacogroup.agri.applications.core.exceptions.ObjectNotFoundException;
import com.abacogroup.agri.applications.core.mappers.AmendableModuleMapper;
import com.abacogroup.agri.applications.core.model.dto.AmendableModuleDTO;
import com.abacogroup.agri.applications.db.dao.AmendableModuleDAO;
import com.abacogroup.agri.applications.db.ntt.AmendableModuleNTT;

import lombok.extern.slf4j.Slf4j;

/**
 * @author Samuele Sbarbaro
 */
@Slf4j
public class AmendableModuleCrudService
		extends AbstractHistoricizationFieldsCrudService<AmendableModuleNTT, Long, AmendableModuleDTO, AmendableModuleMapper, Void> {

	public AmendableModuleCrudService(AmendableModuleDAO dao, AmendableModuleMapper mapper) {
		super(dao, mapper);
	}

	@Override
	protected boolean hasPrimaryKey() {
		return true;
	}

	@Override
	protected Void retrieveCustomKeyByResultSet(AmendableModuleNTT rs) {
		return null;
	}

	@Override
	protected AmendableModuleNTT adjustR(AmendableModuleNTT rs) throws Exception {
		return rs;
	}

	@Override
	protected Optional<AmendableModuleNTT> findRsByCustomKey(Void customKey) {
		return Optional.empty();
	}

	public AmendableModuleDTO findById(Long key) throws ObjectNotFoundException {
		log.info("Invoking find by  with params key: {}", key);
		return this.findOutDtoByPrimaryKey(key);
	}

	public List<AmendableModuleDTO> findByModuleId(Long moduleId) {
		return ((AmendableModuleDAO) this.dao).findByModuleId(moduleId).stream()
				.map(mapper::entityToDto)
				.collect(Collectors.toList());
	}

	public List<AmendableModuleDTO> findByAmendableModuleId(String tenant, Long amendableModuleId) {
		return ((AmendableModuleDAO) this.dao).findByAmendableModuleId(tenant, amendableModuleId).stream()
				.map(mapper::entityToDto)
				.collect(Collectors.toList());
	}

	public AmendableModuleDTO insert(AmendableModuleDTO in, String username) {
		log.info("Invoking insert with params in: {} username: {}", in, username);
		return this.insert(in, username, null, this.dao.getCurrentTimestamp());
	}

	public AmendableModuleDTO update(Long key, AmendableModuleDTO in, String username) {
		log.info("Invoking update with params key: {} in: {} username: {}", key, in, username);
		return this.update(key, in, username, null);
	}

	public void delete(Long key, String username) {
		log.info("Invoking delete with params key: {} username: {}", key, username);
		this.delete(key, username, null);
	}

	public AmendableModuleDTO findByModuleIdAndAmendableModuleId(Long moduleId, Long amendableModuleId) throws ObjectNotFoundException {
		return findOptByModuleIdAndAmendableModuleId(moduleId, amendableModuleId).orElseThrow(OBJECT_NOT_FOUND_EXCEPTION_SUPPLIER);
	}

	public Optional<AmendableModuleDTO> findOptByModuleIdAndAmendableModuleId(Long moduleId, Long amendableModuleId) {
		return Optional.ofNullable(((AmendableModuleDAO) this.dao).findByModuleIdAndAmendableModuleId(amendableModuleId, moduleId))
				.map(mapper::entityToDto);
	}

	public List<AmendableModuleDTO> findAllByTenant(String tenant) {
		return ((AmendableModuleDAO) this.dao).findAllByTenant(tenant).stream()
				.map(mapper::entityToDto)
				.collect(Collectors.toList());
	}

}
