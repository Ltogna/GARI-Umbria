package com.abacogroup.agri.applications.core.caller;

import com.abacogroup.agri.applications.core.model.dto.CreatePrintJobOutDTO;
import com.abacogroup.jaxrsutils.GenericCallerService;
import com.abacogroup.jaxrsutils.callerv2.AbacoDtoCaller;

/**
 * @author Gennaro Tamburrelli
 */
public class CreatePrintJobCaller extends AbacoDtoCaller<CreatePrintJobInput, CreatePrintJobOutDTO> {

	public CreatePrintJobCaller(GenericCallerService genericCallerService) {
		super(genericCallerService);
	}

}
