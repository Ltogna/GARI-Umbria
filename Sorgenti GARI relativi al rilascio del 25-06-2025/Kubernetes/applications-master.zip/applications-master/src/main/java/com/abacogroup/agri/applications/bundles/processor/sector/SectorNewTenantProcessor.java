package com.abacogroup.agri.applications.bundles.processor.sector;

import com.abacogroup.agri.applications.bundles.model.I18nPair;
import com.abacogroup.agri.applications.bundles.model.sector.BundleSectorInDTO;
import com.abacogroup.agri.applications.bundles.model.sector.BundleSectorsMessage;
import com.abacogroup.agri.applications.core.model.dto.SectorDTO;
import com.abacogroup.agri.applications.core.services.crud.SectorsCrudService;
import com.abacogroup.agri.applications.db.ntt.applications.RsI18N;
import com.abacogroup.bundles.listener.tenant.TenantMessage;
import com.abacogroup.bundles.listener.tenant.TenantMessageProcessor;
import lombok.extern.slf4j.Slf4j;
import org.jdbi.v3.core.Jdbi;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import static com.abacogroup.agri.applications.bundles.BundleConstants.TENANT_TEMPLATE_CODE;

/**
 * @author Alexandru Paraschiv
 */
@Slf4j
public class SectorNewTenantProcessor implements TenantMessageProcessor {

	protected final Jdbi jdbi;
	protected final SectorsBundleWorker sectorsBundleWorker;

	public SectorNewTenantProcessor(Jdbi jdbi, SectorsBundleWorker sectorsBundleWorker) {
		this.jdbi = jdbi;
		this.sectorsBundleWorker = sectorsBundleWorker;
	}

	@Override
	public void onMessage(TenantMessage message) {
		jdbi.useTransaction(handle -> {
			log.info("SectorNewTenantProcessor got new tenant {}", message.getTenantId());
			checkAndInsertSectors(message.getTenantId());
			log.info("SectorNewTenantProcessor end working with new tenant {}", message.getTenantId());
		});
	}

	private void checkAndInsertSectors(String tenantId) {
		log.info("SectorNewTenantProcessor check and insert new tenant {}", tenantId);
		SectorsCrudService sectorsCrudService = sectorsBundleWorker.exposeSectorsCrudService();
		List<SectorDTO> asteriskSectors = sectorsCrudService.findAllSectors(TENANT_TEMPLATE_CODE);
		sectorsBundleWorker.upsertBundleSectors(tenantId,
				BundleSectorsMessage.builder()
						.sectors(asteriskSectors
								.stream()
								.map(sector -> BundleSectorInDTO.builder()
										.sectorCode(sector.getSectorCode())
										.i18n(mapI18NList(TENANT_TEMPLATE_CODE, sector.getSectorCode()))
										.build())
								.collect(Collectors.toList()))
						.build());
	}

	private List<I18nPair> mapI18NList(String tenantId, String sectorCode) {
		var mapLang = sectorsBundleWorker.exposeSectorsCrudService()
				.getAllSectorI18NByTenantAndCode(tenantId, sectorCode)
				.stream()
				.collect(Collectors.groupingBy(RsI18N::getLang));
		List<I18nPair> records = new ArrayList<>();
		mapLang.forEach((lang, item) -> records.add(I18nPair.builder()
				.lang(lang)
				.description(extractI18NText(item, SectorsCrudService.SECTOR_I18N.SECTOR_CODE.getCode()))
				.build()));

		return records;
	}

	private String extractI18NText(List<RsI18N> items, String field) {
		return items
				.stream()
				.filter(x -> field.equals(x.getField_name()))
				.findFirst()
				.map(RsI18N::getI18n_text)
				.orElse(null);
	}
}
