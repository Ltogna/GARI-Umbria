package com.abacogroup.agri.applications.core.services.appexchange;

import com.abacogroup.agri.applications.core.services.embededqueue.NotifyApplicationsEventQueue;
import com.abacogroup.agri.applications.core.services.embededqueue.model.ApplicationsEventModel;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.rabbitmq.client.*;
import lombok.extern.slf4j.Slf4j;

import java.io.IOException;
import java.util.HashMap;

/**
 * @author Gennaro Tamburrelli
 */
@Slf4j
public class ApplicationsMessageListener {

	private final Channel channel;
	public static final String EXCHANGE_NAME = "applications-exchange";
	public static final String QUEUE_NAME = "application-events";
	public static final String ROUTING_KEY_TEMPLATE = "applications-events.*.*";

	private final NotifyApplicationsEventQueue notifyApplicationsEventQueue;

	public ApplicationsMessageListener(Connection rabbitMQConnection, ObjectMapper objectMapper,
									   NotifyApplicationsEventQueue notifyApplicationsEventQueue) throws IOException {
		this.channel = rabbitMQConnection.createChannel();
		this.notifyApplicationsEventQueue = notifyApplicationsEventQueue;

		this.channel.exchangeDeclare(EXCHANGE_NAME, BuiltinExchangeType.TOPIC, true);

		this.channel.queueDeclare(QUEUE_NAME, true, false, false, new HashMap<>());
		this.channel.queueBind(QUEUE_NAME, EXCHANGE_NAME, ROUTING_KEY_TEMPLATE);

		this.channel.basicQos(1);
		this.channel.basicConsume(QUEUE_NAME, false, (consumerTag, delivery) -> {
			handleCalculationMessage(objectMapper, delivery);
		}, consumerTag -> {
		});
	}

	private void handleCalculationMessage(ObjectMapper objectMapper, Delivery delivery) throws IOException {
		Envelope envelope = delivery.getEnvelope();
		String routingKey = envelope.getRoutingKey();
		long deliveryTag = envelope.getDeliveryTag();
		log.info("[APPLICATIONS-EVENTS-LISTENER] received message with routing key '{}'", routingKey);

		try {
			ApplicationsEventModel res = objectMapper.readValue(delivery.getBody(), new TypeReference<>() {});
			log.info("[APPLICATIONS-EVENTS-LISTENER] obtained message {}", res);
			notifyApplicationsEventQueue.add(res, System.currentTimeMillis());
			this.channel.basicAck(deliveryTag, false);

			log.info("[APPLICATIONS-EVENTS-LISTENER] processed message with routing key '{}'", routingKey);
			log.trace("[APPLICATIONS-EVENTS-LISTENER] channel: {}", channel.getChannelNumber());
		} catch (Exception e) {
			log.warn("[APPLICATIONS-EVENTS-LISTENER] Got error during consumption of with routing key: " + routingKey, e);
			this.channel.basicNack(deliveryTag, false, false);
		}
	}

}
