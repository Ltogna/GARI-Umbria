package com.abacogroup.agri.applications.core.model.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.experimental.SuperBuilder;

/**
 * @author Mauro Pozzana
 */
@Data
@AllArgsConstructor
@SuperBuilder
public class RolesVerifierUserRoleOutDTO extends RolesVerifierUserRoleDTO {
}
