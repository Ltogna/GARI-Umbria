package com.abacogroup.agri.applications.core.mappers;

import com.abacogroup.agri.applications.core.model.dto.publics.ApplicationDTO;
import com.abacogroup.agri.applications.db.ntt.ApplicationNTT;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

@Mapper(uses = AbsoluteDateMapper.class)
public interface ApplicationMapper extends EntityMapper<ApplicationDTO, ApplicationNTT> {

	ApplicationMapper INSTANCE = Mappers.getMapper(ApplicationMapper.class);

	@InheritInverseConfiguration()
	ApplicationDTO entityToDto(ApplicationNTT entity);

	@Mapping(source = "applicationId", target = "id")
	@Mapping(source = "partyId", target = "party_id")
	@Mapping(source = "referredYear", target = "referred_year")
	@Mapping(source = "moduleId", target = "module_id")
	@Mapping(source = "processId", target = "process_id")
	@Mapping(source = "userIdInsert", target = "user_id_insert")
	@Mapping(source = "userIdDelete", target = "user_id_delete")
	@Mapping(source = "dtInsert", target = "dt_insert")
	@Mapping(source = "dtDelete", target = "dt_delete")
	ApplicationNTT dtoToEntity(ApplicationDTO dto);

}
