package com.abacogroup.agri.applications.db.dao;

import com.abacogroup.agri.applications.db.ntt.ApplicationCompileStatusNTT;
import org.jdbi.v3.core.result.ResultIterator;
import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.customizer.BindBean;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;

import java.time.LocalDateTime;
import java.util.List;

/**
 * @author Mauro Pozzana
 */
public interface ApplicationCompileStatusDAO extends IGenericHistoricizationFieldsDAO<ApplicationCompileStatusNTT, Long, Void> {

	@Override
	@SqlQuery("§select_nextval(apps_applications_compile_status_id)§")
	Long nextSequenceVal();

	@Override
	@SqlUpdate("INSERT INTO apps_applications_compile_status (pkid, application_id, compile_status_identifier, status, " +
			"dt_insert, dt_delete, user_id_insert, user_id_delete) " +
			"VALUES(:pkid, :application_id, :compile_status_identifier, :status, " +
			":current_timestamp, TO_TIMESTAMP('9999-12-3123:59:59','YYYY-MM-DDHH24:MI:SS'), :user_id, NULL)")
	void insert(@BindBean ApplicationCompileStatusNTT rs, @Bind("user_id") String userId,
			@Bind("current_timestamp") LocalDateTime currentTimestamp);

	@Override
	@SqlQuery("SELECT pkid, " +
			"application_id, " +
			"compile_status_identifier, " +
			"status " +
			"FROM apps_applications_compile_status " +
			"WHERE pkid = :id")
	@RegisterBeanMapper(ApplicationCompileStatusNTT.class)
	List<ApplicationCompileStatusNTT> findById(@Bind("id") Long id);

	@SqlUpdate("UPDATE apps_applications_compile_status SET " +
			"compile_status_identifier=:compile_status_identifier, " +
			"status=:status " +
			"where pkid=:pkid")
	void update(@BindBean ApplicationCompileStatusNTT rs);

	@Override
	@SqlUpdate("UPDATE apps_applications_compile_status SET " +
			"user_id_delete = :user_id_delete, dt_delete = :current_timestamp " +
			"WHERE pkid = :id " +
			"and §current_timestamp§ between dt_insert and dt_delete")
	void logicallyDeleteById(@Bind("id") Long id, @Bind("user_id_delete") String userDelete, @Bind("current_timestamp") LocalDateTime currentTimestamp);

	@SqlQuery("SELECT acs.pkid, " +
			"acs.application_id, " +
			"acs.compile_status_identifier, " +
			"acs.status, " +
			"FROM apps_applications_compile_status acs " +
			"LEFT JOIN apps_applications a ON acs.application_id = a.id " +
			"LEFT JOIN apps_application_details ad ON a.id = ad.application_id " +
			"LEFT JOIN apps_modules m ON a.module_id = m.id " +
			"LEFT JOIN apps_sectors s ON s.id = m.sector_id " +
			"WHERE s.tenant_id = :tenant " +
			"and ad.application_code = :application_code " +
			"and §current_timestamp§ between a.dt_insert and a.dt_delete " +
			"and §current_timestamp§ between ad.dt_insert and ad.dt_delete " +
			"and §current_timestamp§ between acs.dt_insert and acs.dt_delete " +
			"and §current_timestamp§ between m.dt_insert and m.dt_delete ")

	@RegisterBeanMapper(ApplicationCompileStatusNTT.class)
	ResultIterator<ApplicationCompileStatusNTT> findByApplicationCode(@Bind("tenant") String tenant, @Bind("application_code") String applicationCode,
			@Bind("lang") String lang);

	@SqlQuery("SELECT acs.pkid, " +
			"acs.application_id, " +
			"acs.compile_status_identifier, " +
			"acs.status " +
			"FROM apps_applications_compile_status acs " +
			"LEFT JOIN apps_applications a ON acs.application_id = a.id " +
			"LEFT JOIN apps_application_details ad ON a.id = ad.application_id " +
			"LEFT JOIN apps_modules m ON a.module_id = m.id " +
			"LEFT JOIN apps_sectors s ON s.id = m.sector_id " +
			"WHERE s.tenant_id = :tenant " +
			"and a.id = :application_id " +
			"and §current_timestamp§ between a.dt_insert and a.dt_delete " +
			"and §current_timestamp§ between ad.dt_insert and ad.dt_delete " +
			"and §current_timestamp§ between acs.dt_insert and acs.dt_delete " +
			"and §current_timestamp§ between m.dt_insert and m.dt_delete ")
	@RegisterBeanMapper(ApplicationCompileStatusNTT.class)
	ResultIterator<ApplicationCompileStatusNTT> findByApplicationId(@Bind("tenant") String tenant, @Bind("application_id") Long applicationId,
			@Bind("lang") String lang);

	@SqlQuery("SELECT acs.pkid, " +
			"acs.application_id, " +
			"acs.compile_status_identifier, " +
			"acs.status " +
			"FROM apps_applications_compile_status acs " +
			"LEFT JOIN apps_applications a ON acs.application_id = a.id " +
			"LEFT JOIN apps_application_details ad ON ad.application_id = a.id " +
			"LEFT JOIN apps_modules m on a.module_id = m.id " +
			"LEFT JOIN apps_sectors s on m.sector_id = s.id " +
			"WHERE a.id = :application_id " +
			"and s.tenant_id = :tenant " +
			"and §current_timestamp§ between a.dt_insert and a.dt_delete " +
			"and §current_timestamp§ between ad.dt_insert and ad.dt_delete " +
			"and §current_timestamp§ between acs.dt_insert and acs.dt_delete " +
			"and §current_timestamp§ between m.dt_insert and m.dt_delete ")
	@RegisterBeanMapper(ApplicationCompileStatusNTT.class)
	List<ApplicationCompileStatusNTT> findByApplicationId(@Bind("tenant") String tenant, @Bind("application_id") Long applicationId);

	@SqlQuery("SELECT acs.pkid, " +
			"acs.application_id, " +
			"acs.compile_status_identifier, " +
			"acs.status " +
			"FROM apps_applications_compile_status acs " +
			"LEFT JOIN apps_applications a ON acs.application_id = a.id " +
			"LEFT JOIN apps_modules m on a.module_id = m.id " +
			"LEFT JOIN apps_sectors s on m.sector_id = s.id " +
			"WHERE acs.pkid = :pkid " +
			"and s.tenant_id = :tenant " +
			"and §current_timestamp§ between a.dt_insert and a.dt_delete " +
			"and §current_timestamp§ between acs.dt_insert and acs.dt_delete " +
			"and §current_timestamp§ between m.dt_insert and m.dt_delete ")
	@RegisterBeanMapper(ApplicationCompileStatusNTT.class)
	List<ApplicationCompileStatusNTT> findByTenantAndId(@Bind("tenant") String tenant, @Bind("pkid") Long pkid);

	@SqlQuery("SELECT acs.pkid, " +
			"acs.application_id, " +
			"acs.compile_status_identifier, " +
			"acs.status " +
			"FROM apps_applications_compile_status acs " +
			"LEFT JOIN apps_applications a ON acs.application_id = a.id " +
			"LEFT JOIN apps_application_details ad ON a.id = ad.application_id " +
			"LEFT JOIN apps_modules m ON a.module_id = m.id " +
			"LEFT JOIN apps_sectors s ON s.id = m.sector_id " +
			"WHERE s.tenant_id = :tenant " +
			"and acs.compile_status_identifier = :app_compile_status_identifier " +
			"and a.id = :application_id " +
			"and §current_timestamp§ between a.dt_insert and a.dt_delete " +
			"and §current_timestamp§ between ad.dt_insert and ad.dt_delete " +
			"and §current_timestamp§ between acs.dt_insert and acs.dt_delete " +
			"and §current_timestamp§ between m.dt_insert and m.dt_delete ")
	@RegisterBeanMapper(ApplicationCompileStatusNTT.class)
	List<ApplicationCompileStatusNTT> findByApplicationIdAndCompileStatus(@Bind("tenant") String tenant, @Bind("application_id") Long applicationId,
			@Bind("app_compile_status_identifier") String compileStatusIdentifier);
}
