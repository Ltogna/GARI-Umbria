package com.abacogroup.agri.applications.db.ntt;

import com.abacogroup.agri.applications.db.ntt.applications.IIdRs;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.time.LocalDateTime;
import java.util.Optional;

/**
 * @author Gennaro Tamburrelli
 */
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class ApplicationGeneratedPrintNTT implements IIdRs<Long> {

	private Long pkid;
	private Long application_id;
	private String print_code;
	private String print_description;
	private String process_status;
	private LocalDateTime print_date;
	private String print_job_uuid;
	private String file_id;
	private String username;
	private String status;

	@Override public void setKey(Long id) {
		this.pkid = id;
	}

	@Override public Optional<Long> getKey() {
		return Optional.ofNullable(this.pkid);
	}
}
