package com.abacogroup.agri.applications.core.model.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Map;

/**
 * @author Gennaro Tamburrelli
 */
@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
public class PartyRegistryDTO {
	private Long id;
	private String partyType;
	private String lastName;
	private String firstName;
	private String taxCode;
	private String vatNumber;
	private String code;
	private String birthDate; //Absolute date YYYYMMDD
	private String deathDate; //Absolute date YYYYMMDD
	private String birthMunicipality;
	private Map<String, Object> birthMunicipalityDetail;
	private String nationality;
	private Map<String, Object> addressResidential;
	private Boolean isArchived;
}
