package com.abacogroup.agri.applications.bundles.model.module;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.List;

/**
 * @author Alexandru Paraschiv
 * @author Gennaro Tamburrelli
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class BundleModulesMessage {
	@Builder.Default
	private List<BundleModuleInDTO> modules = new ArrayList<>();
}
