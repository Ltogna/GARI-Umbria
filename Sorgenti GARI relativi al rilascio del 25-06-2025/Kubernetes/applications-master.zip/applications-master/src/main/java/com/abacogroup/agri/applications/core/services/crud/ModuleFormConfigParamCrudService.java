package com.abacogroup.agri.applications.core.services.crud;

import java.util.List;
import java.util.Optional;

import com.abacogroup.agri.applications.core.exceptions.ObjectNotFoundException;
import com.abacogroup.agri.applications.core.mappers.ModuleFormConfigParamMapper;
import com.abacogroup.agri.applications.core.model.dto.ModuleFormConfigParamDTO;
import com.abacogroup.agri.applications.db.dao.ModuleFormConfigParamDAO;
import com.abacogroup.agri.applications.db.ntt.ModuleFormConfigParamNTT;
import com.abacogroup.agri.applications.db.ntt.compoundkeys.FormConfigParamKey;

import lombok.extern.slf4j.Slf4j;

/**
 * @author Gennaro Tamburrelli
 */
@Slf4j
public class ModuleFormConfigParamCrudService
		extends AbstractCrudService<ModuleFormConfigParamNTT, Void, ModuleFormConfigParamDTO, ModuleFormConfigParamMapper, FormConfigParamKey> {

	public ModuleFormConfigParamCrudService(ModuleFormConfigParamDAO dao, ModuleFormConfigParamMapper mapper) {
		super(dao, mapper);
	}

	@Override
	protected boolean hasPrimaryKey() {
		return false;
	}

	@Override
	protected Void retrievePrimaryKey(FormConfigParamKey customKey) {
		return null;
	}

	@Override
	protected Optional<ModuleFormConfigParamNTT> findRsByCustomKey(FormConfigParamKey customKey) {
		return ((ModuleFormConfigParamDAO) this.dao).findById(customKey.getModule_form_config_id(), customKey.getParameter_name())
				.stream()
				.findFirst();
	}

	@Override
	protected void deleteByCustomKey(FormConfigParamKey customKey) {
		((ModuleFormConfigParamDAO) this.dao).deleteById(customKey.getModule_form_config_id(), customKey.getParameter_name());
	}

	@Override
	protected void setCustomSearchKey(ModuleFormConfigParamNTT rs, FormConfigParamKey customKey) {
		rs.setModule_form_config_id(customKey.getModule_form_config_id());
		rs.setParameter_name(customKey.getParameter_name());
	}

	public ModuleFormConfigParamDTO insert(ModuleFormConfigParamDTO in) {
		log.info("Invoking insert with params in: {}", in);
		return this.insert(in, FormConfigParamKey.builder()
				.module_form_config_id(in.getModuleFormConfigId())
				.parameter_name(in.getParameterName())
				.build());
	}

	public ModuleFormConfigParamDTO update(ModuleFormConfigParamDTO in) {
		log.info("Invoking update with params in: {}", in);
		return this.update(null, in, FormConfigParamKey.builder()
				.module_form_config_id(in.getModuleFormConfigId())
				.parameter_name(in.getParameterName())
				.build());
	}

	public void delete(FormConfigParamKey key) {
		log.info("Invoking delete with params key: {}", key);
		this.delete(null, key);
	}

	public void deleteByModuleFormConfigId(Long moduleFormConfigId) {
		((ModuleFormConfigParamDAO) this.dao).deleteByModuleFormConfigId(moduleFormConfigId);
	}

	public void bulkDeleteByModuleId(Long moduleId) {
		((ModuleFormConfigParamDAO) this.dao).bulkDeleteByModuleId(moduleId);
	}

	public ModuleFormConfigParamDTO findById(String tenant, FormConfigParamKey id) throws ObjectNotFoundException {
		log.info("Invoking findById with params tenant: {} id: {}", tenant, id);
		return returnOptionalRecord(((ModuleFormConfigParamDAO) this.dao).findById(tenant, id.getModule_form_config_id(), id.getParameter_name()))
				.orElseThrow(OBJECT_NOT_FOUND_EXCEPTION_SUPPLIER);
	}

	public List<ModuleFormConfigParamDTO> find(String tenant, Long formConfig) {
		log.info("Invoking findById with params tenant: {} formConfigId: {}", tenant, formConfig);
		return returnMappedList(((ModuleFormConfigParamDAO) this.dao).find(tenant, formConfig));
	}

	public List<String> findOptionCodesByModuleFormConfigIds(List<Long> formConfigIds) {
		return ((ModuleFormConfigParamDAO) this.dao).findOptionCodesByModuleFormConfigIds(formConfigIds);
	}

}
