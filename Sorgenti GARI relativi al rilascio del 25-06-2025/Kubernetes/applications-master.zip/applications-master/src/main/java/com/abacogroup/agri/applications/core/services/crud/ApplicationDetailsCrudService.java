package com.abacogroup.agri.applications.core.services.crud;

import com.abacogroup.agri.applications.core.exceptions.ObjectNotFoundException;
import com.abacogroup.agri.applications.core.mappers.ApplicationDetailsMapper;
import com.abacogroup.agri.applications.core.model.ProcessTransitionEnum;
import com.abacogroup.agri.applications.core.model.dto.ApplicationDetailsDTO;
import com.abacogroup.agri.applications.db.dao.ApplicationDetailsDAO;
import com.abacogroup.agri.applications.db.ntt.ApplicationDetailsNTT;
import lombok.extern.slf4j.Slf4j;

import java.time.LocalDateTime;
import java.util.Optional;

/**
 * @author Mauro Pozzana
 */
@Slf4j
public class ApplicationDetailsCrudService
		extends AbstractHistoricizationFieldsCrudService<ApplicationDetailsNTT, Long, ApplicationDetailsDTO, ApplicationDetailsMapper, Void> {

	public ApplicationDetailsCrudService(ApplicationDetailsDAO dao, ApplicationDetailsMapper mapper) {
		super(dao, mapper);
	}

	@Override protected boolean hasPrimaryKey() {
		return true;
	}

	@Override protected Void retrieveCustomKeyByResultSet(ApplicationDetailsNTT rs) {
		return null;
	}

	@Override protected ApplicationDetailsNTT adjustR(ApplicationDetailsNTT rs) throws Exception {
		return rs;
	}

	@Override protected Optional<ApplicationDetailsNTT> findRsByCustomKey(Void customKey) {
		return Optional.empty();
	}

	public ApplicationDetailsDTO insert(ApplicationDetailsDTO in, String username) {
		log.info("Invoking insert with params in: {} username: {}", in, username);
		return this.insert(in, username, null, this.dao.getCurrentTimestamp());
	}

	public ApplicationDetailsDTO update(Long key, ApplicationDetailsDTO in, String username) {
		log.info("Invoking update with params key: {} in: {} username: {}", key, in, username);
		return this.update(key, in, username, null);
	}

	public void delete(Long key, String username) {
		log.info("Invoking delete with params key: {} username: {}", key, username);
		this.delete(key, username, null);
	}

	public ApplicationDetailsDTO findApplicationDetailByCode(String tenant, String applicationDetailCode) throws ObjectNotFoundException {
		log.info("Invoking findApplicationDetailByCode with params tenant: {} applicationDetailCode: {}", tenant, applicationDetailCode);
		return returnOptionalRecord(((ApplicationDetailsDAO) this.dao).findByCode(tenant, applicationDetailCode))
				.orElseThrow(AbstractCrudService.OBJECT_NOT_FOUND_EXCEPTION_SUPPLIER);
	}

	public ApplicationDetailsDTO findApplicationDetailById(String tenant, Long applicationId) throws ObjectNotFoundException {
		log.info("Invoking findApplicationDetailByCode with params tenant: {} applicationId: {}", tenant, applicationId);
		var res = returnOptionalRecord(((ApplicationDetailsDAO) this.dao).findByApplicationId(tenant, applicationId))
				.orElseThrow(AbstractCrudService.OBJECT_NOT_FOUND_EXCEPTION_SUPPLIER);
		res.setDtInsert(this.findFirstCreationDate(tenant, applicationId));
		return res;
	}

	public ApplicationDetailsDTO findApplicationDetailByIdAlsoExpired(String tenant, Long applicationId) throws ObjectNotFoundException {
		log.info("Invoking findApplicationDetailByCode with params tenant: {} applicationId: {}", tenant, applicationId);
		var res = returnOptionalRecord(((ApplicationDetailsDAO) this.dao).findByApplicationIdAlsoExpired(tenant, applicationId))
				.orElseThrow(AbstractCrudService.OBJECT_NOT_FOUND_EXCEPTION_SUPPLIER);
		res.setDtInsert(this.findFirstCreationDate(tenant, applicationId));
		return res;
	}

	public LocalDateTime findFirstCreationDate(String tenant, Long applicationId) {
		return ((ApplicationDetailsDAO) this.dao).findFirstDtInsert(tenant, applicationId);
	}

	public void updateProcessStatusAndFlTransition(String tenant, Long applicationId, String processStatus, String username,
			ProcessTransitionEnum inTransitionFl) throws ObjectNotFoundException {
		//get application details
		var appDetails = this.findApplicationDetailByIdAlsoExpired(tenant, applicationId);
		//update application details
		appDetails.setProcessStatus(processStatus);
		appDetails.setFlInTransition(inTransitionFl.getFl());
		this.update(appDetails.getPkid(), appDetails, username);
	}

	public void updateFlTransition(String tenant, Long applicationId, String username,
			ProcessTransitionEnum inTransitionFl) throws ObjectNotFoundException {
		//get application details
		var appDetails = this.findApplicationDetailById(tenant, applicationId);
		//update application details
		appDetails.setFlInTransition(inTransitionFl.getFl());
		appDetails.setProcessStatus(appDetails.getProcessStatus());
		this.update(appDetails.getPkid(), appDetails, username);
	}

	public void cancelAmendedBy(String tenant, Long applicationId, String username) throws ObjectNotFoundException {
		var appDetails = this.findApplicationDetailById(tenant, applicationId);
		appDetails.setAmendedById(null);
		this.update(appDetails.getPkid(), appDetails, username);
	}
}
