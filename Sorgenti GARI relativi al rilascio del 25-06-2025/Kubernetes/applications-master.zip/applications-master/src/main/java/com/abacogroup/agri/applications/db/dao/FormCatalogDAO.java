package com.abacogroup.agri.applications.db.dao;

import com.abacogroup.agri.applications.db.ntt.FormCatalogNTT;
import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.customizer.BindBean;
import org.jdbi.v3.sqlobject.customizer.BindList;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;

import java.util.List;

/**
 * @author Alexandru Paraschiv
 */
public interface FormCatalogDAO extends IGenericDAO<FormCatalogNTT, Long> {

	@Override
	@SqlQuery("§select_nextval(apps_form_catalog_id_seq)§")
	Long nextSequenceVal();

	@SqlUpdate("INSERT INTO apps_form_catalog " +
			"(id, tenant_id, form_code, software_url, router_url) " +
			"VALUES(:id, :tenant_id, :form_code, :software_url, :router_url)")
	void insert(@BindBean FormCatalogNTT formCatalog);

	@SqlQuery("select f.id, " +
			" f.tenant_id, " +
			" f.form_code, " +
			" f.router_url, " +
			" f.software_url, " +
			" §i18n(:tenantId, 'apps_form_catalog', 'form_code', f.form_code, :lang)§ as form_catalog_description " +
			" from apps_form_catalog f " +
			" where f.tenant_id=:tenantId")
	@RegisterBeanMapper(FormCatalogNTT.class)
	List<FormCatalogNTT> findAllFormCatalogsByTenant(@Bind("tenantId") String tenant, @Bind("lang") String lang);

	@SqlQuery("select f.id, " +
			" f.tenant_id, " +
			" f.form_code, " +
			" f.router_url, " +
			" f.software_url, " +
			" §i18n(:tenantId, 'apps_form_catalog', 'form_code', f.form_code, :lang)§ as form_catalog_description " +
			" from apps_form_catalog f " +
			" where f.tenant_id=:tenantId " +
			" and f.id in (<formIdList>)")
	@RegisterBeanMapper(FormCatalogNTT.class)
	List<FormCatalogNTT> findAllFormCatalogs(@Bind("tenantId") String tenant, @BindList("formIdList") List<Long> formIdList, @Bind("lang") String lang);

	@SqlQuery("select f.id, " +
			" f.tenant_id, " +
			" f.form_code, " +
			" f.router_url, " +
			" f.software_url " +
			" from apps_form_catalog f " +
			" where f.id = :id")
	@RegisterBeanMapper(FormCatalogNTT.class)
	List<FormCatalogNTT> findById(@Bind("id") Long id);

	@SqlQuery("select f.id, " +
			" f.tenant_id, " +
			" f.form_code, " +
			" f.software_url, " +
			" f.router_url, " +
			" §i18n(:tenantId, 'apps_form_catalog', 'form_code', f.form_code, :lang)§ as form_catalog_description" +
			" from apps_form_catalog f " +
			" where f.tenant_id=:tenantId" +
			" and f.id = :id")
	@RegisterBeanMapper(FormCatalogNTT.class)
	List<FormCatalogNTT> findById(@Bind("tenantId") String tenant, @Bind("id") Long id, @Bind("lang") String lang);

	@SqlQuery("select f.id, " +
			" f.tenant_id, " +
			" f.form_code, " +
			" f.software_url " +
			" from apps_form_catalog f " +
			" where f.tenant_id=:tenantId" +
			" and f.form_code = :code")
	@RegisterBeanMapper(FormCatalogNTT.class)
	List<FormCatalogNTT> findByCode(@Bind("tenantId") String tenant, @Bind("code") String formCode);

	@SqlUpdate("UPDATE apps_form_catalog SET " +
			"form_code=:form_code, " +
			"software_url=:software_url, " +
			"router_url=:router_url, " +
			"tenant_id=:tenant_id " +
			"WHERE id=:id")
	void update(@BindBean FormCatalogNTT formCatalog);

	@SqlUpdate("DELETE FROM apps_form_catalog " +
			"WHERE id=:id")
	void deleteById(@Bind("id") Long id);

}
