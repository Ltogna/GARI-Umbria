package com.abacogroup.agri.applications.core.model.dto.publics;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.time.LocalDateTime;

/**
 * @author Samuele Sbarbaro
 */
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class ApplicationProtocolsDTO {
	private Long pkid;
	private Long applicationId;
	private LocalDateTime dtRequest;
	private LocalDateTime dtResponse;
	private String protocol;
}
