package com.abacogroup.agri.applications.core.caller;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class CallerContainer {
	private GetPartiesCaller getPartiesCaller;
	private GetPartyByPartyIdCaller getPartyByPartyIdCaller;
	private GetPartiesRegistryCaller getPartiesRegistryCaller;
	private GetPartyRegistryByPartyIdCaller getPartyRegistryByPartyIdCaller;
	private CreatePrintJobCaller createPrintJobCaller;
	private CreateCalculatorJobCaller createCalculatorJobCaller;
	private GetCalculatorRawResultJobCaller getCalculatorRawResultJobCaller;
	private GetCalculatorRenderResultJobCaller getCalculatorRenderResultJobCaller;
	private CheckCanReadPartyCaller checkCanReadPartyCaller;
	private CreateCustomApplicationIdCaller createCustomApplicationIdCaller;
}
