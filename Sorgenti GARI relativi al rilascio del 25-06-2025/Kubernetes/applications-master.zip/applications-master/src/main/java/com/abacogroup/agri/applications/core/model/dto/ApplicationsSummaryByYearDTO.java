package com.abacogroup.agri.applications.core.model.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author Mauro Pozzana
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ApplicationsSummaryByYearDTO {
	private Integer year;
	private Integer applicationsNumber;
}
