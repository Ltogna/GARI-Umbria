package com.abacogroup.agri.applications.core.services.crud;

import com.abacogroup.agri.applications.core.exceptions.ObjectNotFoundException;
import com.abacogroup.agri.applications.core.exceptions.ObjectNotFoundRuntimeException;
import com.abacogroup.agri.applications.core.mappers.ChildModuleMapper;
import com.abacogroup.agri.applications.core.model.dto.ChildModuleDTO;
import com.abacogroup.agri.applications.db.dao.ChildrenModulesDAO;
import com.abacogroup.agri.applications.db.ntt.ChildModuleNTT;
import lombok.extern.slf4j.Slf4j;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * @author Mattia Perini
 */
@Slf4j
public class ChildModuleCrudService
		extends AbstractHistoricizationFieldsCrudService<ChildModuleNTT, Long, ChildModuleDTO, ChildModuleMapper, Void> {

	public ChildModuleCrudService(ChildrenModulesDAO dao, ChildModuleMapper mapper) {
		super(dao, mapper);
	}

	@Override
	protected boolean hasPrimaryKey() {
		return true;
	}

	@Override
	protected Void retrieveCustomKeyByResultSet(ChildModuleNTT rs) {
		return null;
	}

	@Override
	protected ChildModuleNTT adjustR(ChildModuleNTT rs) throws Exception {
		return rs;
	}

	@Override
	protected Optional<ChildModuleNTT> findRsByCustomKey(Void customKey) {
		return Optional.empty();
	}

	public ChildModuleDTO findById(Long key) throws ObjectNotFoundException {
		log.info("Invoking find by  with params key: {}", key);
		return this.findOutDtoByPrimaryKey(key);
	}

	public List<ChildModuleDTO> findByModuleId(Long moduleId) {
		log.info("Invoking findByModuleId  with params moduleId: {}", moduleId);
		return ((ChildrenModulesDAO) this.dao).findByModuleId(moduleId).stream()
				.map(mapper::entityToDto)
				.collect(Collectors.toList());
	}

	public List<ChildModuleDTO> findByParentModuleId(Long parentModuleId) {
		log.info("Invoking findByParentModuleId  with params moduleId: {}", parentModuleId);
		return ((ChildrenModulesDAO) this.dao).findByParentModuleId(parentModuleId).stream()
				.map(mapper::entityToDto)
				.collect(Collectors.toList());
	}

	public ChildModuleDTO insert(ChildModuleDTO in, String username) {
		log.info("Invoking insert with params in: {} username: {}", in, username);
		return this.insert(in, username, null, this.dao.getCurrentTimestamp());
	}

	public ChildModuleDTO update(Long key, ChildModuleDTO in, String username) {
		log.info("Invoking update with params key: {} in: {} username: {}", key, in, username);
		return this.update(key, in, username, null);
	}

	public void delete(Long key, String username) {
		log.info("Invoking delete with params key: {} username: {}", key, username);
		this.delete(key, username, null);
	}

	public ChildModuleDTO findByModuleIdAndParentModuleId(Long moduleId, Long parentModuleId) {
		log.info("Invoking findByModuleIdAndParentModuleId  with params moduleId: {} parentModuleId: {}", moduleId, parentModuleId);
		return findOptByModuleIdAndParentModuleId(moduleId, parentModuleId).orElseThrow(ObjectNotFoundRuntimeException::new);
	}

	public Optional<ChildModuleDTO> findOptByModuleIdAndParentModuleId(Long moduleId, Long parentModuleId) {
		log.info("Invoking findOptByModuleIdAndParentModuleId  with params moduleId: {} parentModuleId: {}", moduleId, parentModuleId);
		return Optional.ofNullable(((ChildrenModulesDAO) this.dao).findByModuleIdAndParentModuleId(moduleId, parentModuleId)).map(mapper::entityToDto);
	}

	public List<ChildModuleDTO> findAllByTenant(String tenant) {
		return ((ChildrenModulesDAO) this.dao).findAllByTenant(tenant).stream()
				.map(mapper::entityToDto)
				.collect(Collectors.toList());
	}

}
