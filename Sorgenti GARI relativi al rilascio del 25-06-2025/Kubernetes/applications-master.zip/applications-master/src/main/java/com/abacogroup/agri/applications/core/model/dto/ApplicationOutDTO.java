package com.abacogroup.agri.applications.core.model.dto;

import com.abacogroup.agri.applications.core.model.dto.publics.ApplicationDTO;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author Mauro Pozzana
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ApplicationOutDTO {
	private ApplicationDTO application;
	private ApplicationDetailsDTO applicationDetail;
}
