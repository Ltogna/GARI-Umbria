package com.abacogroup.agri.applications.db.dao;

import com.abacogroup.agri.applications.db.ntt.ModuleCalculationConfigsNTT;
import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.customizer.BindBean;
import org.jdbi.v3.sqlobject.customizer.BindList;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;

import java.util.List;

/**
 * @author Mattia Perini
 */
public interface ModuleCalculationConfigsDAO extends IGenericDAO<ModuleCalculationConfigsNTT, Long> {

	@Override
	@SqlQuery("§select_nextval(apps_module_calculation_configs_id_seq)§")
	Long nextSequenceVal();

	@Override
	@SqlUpdate("INSERT INTO apps_module_calculation_configs " +
			"(id, module_id, process_status, calculation_code, sort_order, context_function) " +
			"VALUES(:id, :module_id, :process_status, :calculation_code, :sort_order, :context_function)")
	void insert(@BindBean ModuleCalculationConfigsNTT moduleFormConfigs);

	@SqlQuery("select mcc.id, " +
			" mcc.module_id, " +
			" mcc.process_status, " +
			" mcc.calculation_code, " +
			" mcc.sort_order, " +
			" mcc.context_function " +
			" from apps_module_calculation_configs mcc " +
			" left join apps_modules am on am.id = mcc.module_id " +
			" left join apps_sectors s on s.id = am.sector_id " +
			" where s.tenant_id=:tenantId " +
			" and §current_timestamp§ between am.dt_insert and am.dt_delete")
	@RegisterBeanMapper(ModuleCalculationConfigsNTT.class)
	List<ModuleCalculationConfigsNTT> findAllModuleCalculationConfigsByTenant(@Bind("tenantId") String tenant);

	@SqlQuery("select mcc.id, " +
			" mcc.module_id, " +
			" mcc.process_status, " +
			" mcc.calculation_code, " +
			" mcc.sort_order, " +
			" mcc.context_function " +
			" from apps_module_calculation_configs mcc " +
			" left join apps_modules am on am.id = mcc.module_id " +
			" left join apps_sectors s on s.id = am.sector_id " +
			" where s.tenant_id=:tenantId " +
			" and mcc.module_id=:moduleId " +
			" and §current_timestamp§ between am.dt_insert and am.dt_delete")
	@RegisterBeanMapper(ModuleCalculationConfigsNTT.class)
	List<ModuleCalculationConfigsNTT> findAllModuleCalculationConfigs(@Bind("tenantId") String tenant, @Bind("moduleId") Long moduleId);

	@SqlQuery("select mcc.id, " +
			" mcc.module_id, " +
			" mcc.process_status, " +
			" mcc.calculation_code, " +
			" §i18n(s.tenant_id, 'apps_module_calculation_configs', 'calculation_code', mcc.calculation_code, :lang)§ as calculation_description," +
			" mcc.sort_order, " +
			" mcc.context_function " +
			" from apps_module_calculation_configs mcc " +
			" left join apps_modules am on am.id = mcc.module_id " +
			" left join apps_sectors s on s.id = am.sector_id " +
			" where mcc.module_id=:moduleId " +
			" and §current_timestamp§ between am.dt_insert and am.dt_delete")
	@RegisterBeanMapper(ModuleCalculationConfigsNTT.class)
	List<ModuleCalculationConfigsNTT> findAllModuleCalculationConfigsByModuleId(@Bind("moduleId") Long moduleId, @Bind("lang") String lang);

	@Override
	@SqlQuery("select mcc.id, " +
			" mcc.module_id, " +
			" mcc.process_status, " +
			" mcc.calculation_code, " +
			" mcc.sort_order, " +
			" mcc.context_function " +
			" from apps_module_calculation_configs mcc " +
			" where mcc.id=:id ")
	@RegisterBeanMapper(ModuleCalculationConfigsNTT.class)
	List<ModuleCalculationConfigsNTT> findById(@Bind("id") Long id);

	@SqlQuery("select mcc.id, " +
			" mcc.module_id, " +
			" mcc.process_status, " +
			" mcc.calculation_code, " +
			" §i18n(:tenantId, 'apps_module_calculation_configs', 'calculation_code', mcc.calculation_code, :lang)§ as calculation_description," +
			" mcc.sort_order, " +
			" mcc.context_function " +
			" from apps_module_calculation_configs mcc " +
			" left join apps_modules am on am.id = mcc.module_id " +
			" left join apps_sectors s on s.id = am.sector_id " +
			" where s.tenant_id=:tenantId and " +
			" mcc.id = :id " +
			" and §current_timestamp§ between am.dt_insert and am.dt_delete")
	@RegisterBeanMapper(ModuleCalculationConfigsNTT.class)
	List<ModuleCalculationConfigsNTT> findById(@Bind("tenantId") String tenant, @Bind("id") Long id, @Bind("lang") String lang);

	@SqlQuery("select mcc.id, " +
			" mcc.module_id, " +
			" mcc.process_status, " +
			" mcc.calculation_code, " +
			" §i18n(:tenantId, 'apps_module_calculation_configs', 'calculation_code', mcc.calculation_code, :lang)§ as calculation_description," +
			" mcc.sort_order, " +
			" mcc.context_function " +
			" from apps_module_calculation_configs mcc " +
			" left join apps_modules am on am.id = mcc.module_id " +
			" left join apps_sectors s on s.id = am.sector_id " +
			"  WHERE s.tenant_id = :tenantId  " +
			"  and mcc.module_id = :module_id " +
			"  and mcc.process_status = :process_status" +
			"  and §current_timestamp§ BETWEEN am.dt_insert AND am.dt_delete " +
			"  and (" +
			"        NOT EXISTS (" +
			"            SELECT 1 " +
			"            FROM apps_module_calculation_config_profiles " +
			"            WHERE module_calculation_config_id = mcc.id" +
			"        )" +
			"        OR EXISTS (" +
			"            SELECT 1 " +
			"            FROM apps_module_calculation_config_profiles " +
			"            WHERE module_calculation_config_id = mcc.id " +
			"              AND required_profile_code IN (<app_profile_list>)" +
			"        )" +
			"    )")
	@RegisterBeanMapper(ModuleCalculationConfigsNTT.class)
	List<ModuleCalculationConfigsNTT> find(@Bind("tenantId") String tenant,
			@Bind("module_id") Long moduleId,
			@Bind("process_status") String processStatus,
			@BindList("app_profile_list") List<String> appProfileList,
			@Bind("lang") String lang);

	@SqlQuery("select mcc.id, " +
			" mcc.module_id, " +
			" mcc.process_status, " +
			" mcc.calculation_code, " +
			" mcc.sort_order, " +
			" mcc.context_function " +
			" from apps_module_calculation_configs mcc " +
			" left join apps_modules am on am.id = mcc.module_id " +
			" left join apps_sectors s on s.id = am.sector_id " +
			" where s.tenant_id=:tenantId  " +
			" AND mcc.module_id = :module_id " +
			" AND mcc.calculation_code=:calculation_code " +
			" AND mcc.process_status=:process_status " +
			" AND §current_timestamp§ between am.dt_insert and am.dt_delete ")
	@RegisterBeanMapper(ModuleCalculationConfigsNTT.class)
	List<ModuleCalculationConfigsNTT> find(@Bind("tenantId") String tenant,
			@Bind("module_id") Long moduleId,
			@Bind("calculation_code") String calculationCode,
			@Bind("process_status") String processStatus);

	@SqlQuery("select mcc.id, " +
					" mcc.module_id, " +
					" mcc.process_status, " +
					" mcc.calculation_code, " +
					" mcc.sort_order, " +
					" mcc.context_function " +
					" from apps_module_calculation_configs mcc " +
					" left join apps_modules am on am.id = mcc.module_id " +
					" left join apps_sectors s on s.id = am.sector_id " +
					" where s.tenant_id=:tenantId  " +
					" AND mcc.module_id = :module_id " +
					" AND mcc.calculation_code=:calculation_code " +
					" AND mcc.process_status=:process_status " +
					" AND (mcc.context_function = :context_function OR (:context_function IS NULL AND mcc.context_function IS NULL)) " +
					" AND §current_timestamp§ between am.dt_insert and am.dt_delete ")
	@RegisterBeanMapper(ModuleCalculationConfigsNTT.class)
	List<ModuleCalculationConfigsNTT> find(@Bind("tenantId") String tenant,
																				 @Bind("module_id") Long moduleId,
																				 @Bind("calculation_code") String calculationCode,
																				 @Bind("process_status") String processStatus,
																				 @Bind("context_function") String contextFunction);

	@SqlQuery("select mcc.id, " +
			" mcc.module_id, " +
			" mcc.process_status, " +
			" mcc.calculation_code, " +
			" mcc.sort_order, " +
			" mcc.context_function " +
			" from apps_module_calculation_configs mcc " +
			" left join apps_modules am on am.id = mcc.module_id " +
			" left join apps_sectors s on s.id = am.sector_id " +
			" where s.tenant_id=:tenantId and " +
			" mcc.calculation_code = :calculation_code")
	@RegisterBeanMapper(ModuleCalculationConfigsNTT.class)
	List<ModuleCalculationConfigsNTT> findByCalculationCode(@Bind("tenantId") String tenant, @Bind("calculation_code") String calculationCode);

	@Override
	@SqlUpdate("UPDATE apps_module_calculation_configs SET " +
			"module_id=:module_id, " +
			"process_status=:process_status, " +
			"calculation_code=:calculation_code, " +
			"sort_order=:sort_order, " +
			"context_function=:context_function " +
			"WHERE id=:id")
	void update(@BindBean ModuleCalculationConfigsNTT sector);

	@Override
	@SqlUpdate("DELETE FROM apps_module_calculation_configs " +
			"WHERE id=:id")
	void deleteById(@Bind("id") Long id);

}
