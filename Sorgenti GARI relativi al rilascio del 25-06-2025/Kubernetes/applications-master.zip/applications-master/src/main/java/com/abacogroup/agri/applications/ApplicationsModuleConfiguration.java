package com.abacogroup.agri.applications;

import com.abacogroup.agri.applications.bundles.model.BundleConfig;
import com.abacogroup.agri.applications.core.model.*;
import com.fasterxml.jackson.annotation.JsonProperty;

import io.dropwizard.client.JerseyClientConfiguration;
import io.dropwizard.core.Configuration;
import io.dropwizard.db.DataSourceFactory;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;

public class ApplicationsModuleConfiguration extends Configuration {
	@Valid
	@NotNull
	private DataSourceFactory database;

	@Valid
	@NotNull
	private DataSourceFactory databaseForms;

	@NotEmpty
	private String additionalDatabases;

	private boolean secureAuth;

	private String sso2Url;

	private String sso2TokenSecretAuth;

	private String applicationsUrl;

	private String applicationFormsUrl;

	private String printEngineUrl;

	private String calculatorEngineUrl;

	private String fileStoreUrl;

	private OverridePartyHostConfig overridePartyHostConfig;

	private String printsBucket;

	private String userRole;

	private Boolean devUser;
	private RabbitMqConfig rabbitmqConfig;

	private Boolean activateMonitoringExchangeListener;
	private String techUserId;

	private String bundleServiceId;

	private Boolean activateBundleConfig;
	private BundleConfig bundleConfig;

	private QueueProcessorConfig queueProcessorConfig;

	private String environmentId;

	private CheckCanReadConfig checkCanReadConfig;

	private CheckCanReadConfig checkCanReadAllPartiesConfig;

	private CustomApplicationIdGenerationConfig customApplicationIdGenerationConfig;

	@JsonProperty("database")
	public DataSourceFactory getDatabase() {
		return database;
	}

	@JsonProperty("databaseForms")
	public DataSourceFactory getDatabaseForms() {
		return databaseForms;
	}

	@Valid
	@NotNull
	private JerseyClientConfiguration jerseyClient = new JerseyClientConfiguration();

	@JsonProperty("jerseyClient")
	public JerseyClientConfiguration getJerseyClientConfiguration() {
		return jerseyClient;
	}

	@JsonProperty("jerseyClient")
	public void setJerseyClientConfiguration(JerseyClientConfiguration jerseyClient) {
		this.jerseyClient = jerseyClient;
	}

	@JsonProperty("database")
	public void setDatabase(DataSourceFactory database) {
		this.database = database;
	}

	@JsonProperty("databaseForms")
	public void setDatabaseForms(DataSourceFactory database) {
		this.databaseForms = database;
	}

	public boolean isSecureAuth() {
		return secureAuth;
	}

	public void setSecureAuth(boolean secureAuth) {
		this.secureAuth = secureAuth;
	}

	public String getSso2Url() {
		return sso2Url;
	}

	public void setSso2Url(String sso2Url) {
		this.sso2Url = sso2Url;
	}

	public String getUserRole() {
		return userRole;
	}

	public void setUserRole(String userRole) {
		this.userRole = userRole;
	}

	public Boolean getDevUser() {
		return devUser;
	}

	public void setDevUser(Boolean devUser) {
		this.devUser = devUser;
	}

	public RabbitMqConfig getRabbitmqConfig() {
		return rabbitmqConfig;
	}

	public void setRabbitmqConfig(RabbitMqConfig rabbitmqConfig) {
		this.rabbitmqConfig = rabbitmqConfig;
	}

	public BundleConfig getBundleConfig() {
		return bundleConfig;
	}

	public void setBundleConfig(BundleConfig bundleConfig) {
		this.bundleConfig = bundleConfig;
	}

	public String getBundleServiceId() {
		return bundleServiceId;
	}

	public void setBundleServiceId(String bundleServiceId) {
		this.bundleServiceId = bundleServiceId;
	}

	public Boolean getActivateBundleConfig() {
		return activateBundleConfig;
	}

	public void setActivateBundleConfig(Boolean activateBundleConfig) {
		this.activateBundleConfig = activateBundleConfig;
	}

	public String getApplicationsUrl() {
		return applicationsUrl;
	}

	public void setApplicationsUrl(String applicationsUrl) {
		this.applicationsUrl = applicationsUrl;
	}

	public String getSso2TokenSecretAuth() {
		return sso2TokenSecretAuth;
	}

	public void setSso2TokenSecretAuth(String sso2TokenSecretAuth) {
		this.sso2TokenSecretAuth = sso2TokenSecretAuth;
	}

	public String getFileStoreUrl() {
		return fileStoreUrl;
	}

	public void setFileStoreUrl(String fileStoreUrl) {
		this.fileStoreUrl = fileStoreUrl;
	}

	public String getPrintsBucket() {
		return printsBucket;
	}

	public void setPrintsBucket(String printsBucket) {
		this.printsBucket = printsBucket;
	}

	public String getPrintEngineUrl() {
		return printEngineUrl;
	}

	public void setPrintEngineUrl(String printEngineUrl) {
		this.printEngineUrl = printEngineUrl;
	}

	public String getCalculatorEngineUrl() {
		return calculatorEngineUrl;
	}

	public void setCalculatorEngineUrl(String calculatorEngineUrl) {
		this.calculatorEngineUrl = calculatorEngineUrl;
	}

	public QueueProcessorConfig getQueueProcessorConfig() {
		return queueProcessorConfig;
	}

	public void setQueueProcessorConfig(QueueProcessorConfig queueProcessorConfig) {
		this.queueProcessorConfig = queueProcessorConfig;
	}

	public String getApplicationFormsUrl() {
		return applicationFormsUrl;
	}

	public void setApplicationFormsUrl(String applicationFormsUrl) {
		this.applicationFormsUrl = applicationFormsUrl;
	}

	public String getEnvironmentId() {
		return environmentId;
	}

	public void setEnvironmentId(String environmentId) {
		this.environmentId = environmentId;
	}

	public CheckCanReadConfig getCheckCanReadConfig() {
		return checkCanReadConfig;
	}

	public void setCheckCanReadConfig(CheckCanReadConfig checkCanReadConfig) {
		this.checkCanReadConfig = checkCanReadConfig;
	}

	public OverridePartyHostConfig getOverridePartyHostConfig() {
		return overridePartyHostConfig;
	}

	public void setOverridePartyHostConfig(OverridePartyHostConfig overridePartyHostConfig) {
		this.overridePartyHostConfig = overridePartyHostConfig;
	}

	public CheckCanReadConfig getCheckCanReadAllPartiesConfig() {
		return checkCanReadAllPartiesConfig;
	}

	public void setCheckCanReadAllPartiesConfig(CheckCanReadConfig checkCanReadAllPartiesConfig) {
		this.checkCanReadAllPartiesConfig = checkCanReadAllPartiesConfig;
	}

	public CustomApplicationIdGenerationConfig getCustomApplicationIdGenerationConfig() {
		return customApplicationIdGenerationConfig;
	}

	public void setCustomApplicationIdGenerationConfig(CustomApplicationIdGenerationConfig customApplicationIdGenerationConfig) {
		this.customApplicationIdGenerationConfig = customApplicationIdGenerationConfig;
	}

	public Boolean getActivateMonitoringExchangeListener() {
		return activateMonitoringExchangeListener;
	}

	public void setActivateMonitoringExchangeListener(Boolean activateMonitoringExchangeListener) {
		this.activateMonitoringExchangeListener = activateMonitoringExchangeListener;
	}

	public String getTechUserId() {
		return techUserId;
	}

	public void setTechUserId(String techUserId) {
		this.techUserId = techUserId;
	}

	public String getAdditionalDatabases() {
		return additionalDatabases;
	}

	public void setAdditionalDatabases(String additionalDatabases) {
		this.additionalDatabases = additionalDatabases;
	}
}
