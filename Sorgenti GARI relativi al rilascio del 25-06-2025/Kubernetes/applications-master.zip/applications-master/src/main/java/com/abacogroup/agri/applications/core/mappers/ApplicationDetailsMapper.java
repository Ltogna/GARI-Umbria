package com.abacogroup.agri.applications.core.mappers;

import com.abacogroup.agri.applications.core.model.dto.ApplicationDetailsDTO;
import com.abacogroup.agri.applications.db.ntt.ApplicationDetailsNTT;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

@Mapper
public interface ApplicationDetailsMapper extends EntityMapper<ApplicationDetailsDTO, ApplicationDetailsNTT> {

	ApplicationDetailsMapper INSTANCE = Mappers.getMapper(ApplicationDetailsMapper.class);

	@InheritInverseConfiguration()
	ApplicationDetailsDTO entityToDto(ApplicationDetailsNTT entity);

	@Mapping(source = "pkid", target = "pkid")
	@Mapping(source = "applicationId", target = "application_id")
	@Mapping(source = "applicationCode", target = "application_code")
	@Mapping(source = "processStatus", target = "process_status")
	@Mapping(source = "amendedById", target = "amended_by_id")
	@Mapping(source = "amendOfId", target = "amend_of_id")
	@Mapping(source = "dtPresentation", target = "dt_presentation")
	@Mapping(source = "flInTransition", target = "fl_in_transition")
	ApplicationDetailsNTT dtoToEntity(ApplicationDetailsDTO dto);

}
