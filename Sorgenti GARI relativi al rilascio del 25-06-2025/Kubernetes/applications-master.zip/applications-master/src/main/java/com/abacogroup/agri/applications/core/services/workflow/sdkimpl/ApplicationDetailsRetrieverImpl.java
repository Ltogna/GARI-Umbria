package com.abacogroup.agri.applications.core.services.workflow.sdkimpl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import com.abacogroup.agri.applications.core.exceptions.NoApplicationsFoundByPartyAndYearRuntimeException;
import com.abacogroup.agri.applications.core.mappers.ApplicationDetailsPublicMapper;
import com.abacogroup.agri.applications.core.model.dto.publics.AppByPartyAndYearDTO;
import com.abacogroup.agri.applications.core.services.ApplicationsService;
import com.abacogroup.agri.applications.core.services.crud.ApplicationsCrudService;
import com.abacogroup.applicationworkflowsdk.model.GetApplicationFilters;
import com.abacogroup.applicationworkflowsdk.model.io.output.AppByPartyAndYearSdkDTO;
import com.abacogroup.applicationworkflowsdk.model.io.output.ApplicationDetailsPublicDTO;
import com.abacogroup.applicationworkflowsdk.service.ApplicationDetailsRetriever;
import com.abacogroup.dropwizard.auth.sso2.Sso2Client;
import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.jdbi.datatype.AbsoluteDate;

import jakarta.ws.rs.core.SecurityContext;
import lombok.extern.slf4j.Slf4j;

/**
 * @author Gennaro Tamburrelli
 */
@Slf4j
public class ApplicationDetailsRetrieverImpl implements ApplicationDetailsRetriever {

	private final ApplicationsCrudService applicationsCrudService;
	private final ApplicationsService applicationsService;
	private final Sso2Client sso2Client;

	public ApplicationDetailsRetrieverImpl(ApplicationsCrudService applicationsCrudService,
			ApplicationsService applicationsService, Sso2Client sso2Client) {
		this.applicationsCrudService = applicationsCrudService;
		this.applicationsService = applicationsService;
		this.sso2Client = sso2Client;
	}

	@Override
	public ApplicationDetailsPublicDTO retrieveApplicationDetails(String tenant, Long applicationId, User user) throws Exception {
		var res = applicationsService
				.getDetailedApplicationById(tenant, applicationId, user, sso2Client.createSecurityContextFromUserId(tenant, user.getUserId()));
		return ApplicationDetailsPublicMapper.INSTANCE.entityToDto(res);
	}

	@Override
	public Long countApplications(String tenantId, String moduleCode, Long partyId, List<Integer> yearList, String processStatus, User user)
			throws Exception {
		return applicationsCrudService.countApplications(tenantId, moduleCode, partyId, yearList, processStatus, null);
	}

	@Override
	public List<AppByPartyAndYearSdkDTO> getApplicationsByPartyIdAndYear(String tenant, Long partyId, Integer year, User user) throws Exception {
		List<AppByPartyAndYearDTO> list = new ArrayList<>();
		SecurityContext sc = sso2Client.createSecurityContextFromUserId(tenant, user.getUserId());
		String nextKey = null;
		do {
			try {
				var res = applicationsService.doGetApplicationsByPartyAndYear(tenant, partyId, year, nextKey, user, sc);
				list.addAll(res.getRecords());
				nextKey = res.getNextKey();
			} catch (NoApplicationsFoundByPartyAndYearRuntimeException e) {
				nextKey = null;
			}

		} while (nextKey != null);

		return list.stream()
				.map(x -> AppByPartyAndYearSdkDTO.builder()
						.partyId(x.getPartyId())
						.year(x.getYear())
						.sectorCode(x.getSectorCode())
						.sectorDescription(x.getSectorDescription())
						.moduleCode(x.getModuleCode())
						.moduleDescription(x.getModuleDescription())
						.applicationId(x.getApplicationId())
						.applicationCode(x.getApplicationCode())
						.processId(x.getProcessId())
						.processStatus(x.getProcessStatus())
						.processStatusDescription(x.getProcessStatusDescription())
						.dtPresentation(Optional.ofNullable(x.getDtPresentation()).map(y -> AbsoluteDate.of(y.toString())).orElse(null))
						.isClosed(x.getIsClosed())
						.flAmendable(x.getFlAmendable())
						.dtProtocol(Optional.ofNullable(x.getDtProtocol()).map(y -> AbsoluteDate.of(y.toString())).orElse(null))
						.protocol(x.getProtocol())
						.amendedById(x.getAmendedById())
						.amendOfId(x.getAmendOfId())
						.build())
				.collect(Collectors.toList());
	}

	@Override
	public List<ApplicationDetailsPublicDTO> getApplicationsByParty(String tenant, Long partyId, GetApplicationFilters filters, User user) throws Exception {
		SecurityContext sc = sso2Client.createSecurityContextFromUserId(user.getTenant(), user.getUserId());
		return applicationsService.getApplicationsByPartyId(tenant, partyId, user, filters.getModuleCode(), filters.getProcessStatus(), sc);
	}
}
