package com.abacogroup.agri.applications.db.dao;

import com.abacogroup.agri.applications.db.ntt.ModuleCalculationConfigProfileNTT;
import com.abacogroup.agri.applications.db.ntt.compoundkeys.CalculationConfigProfileKey;
import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.customizer.BindBean;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;

import java.util.List;

/**
 * @author Mattia Perini
 */
public interface ModuleCalculationConfigProfileDAO extends IGenericDAO<ModuleCalculationConfigProfileNTT, CalculationConfigProfileKey> {

	@SqlUpdate("INSERT INTO apps_module_calculation_config_profiles " +
			"(module_calculation_config_id, required_profile_code) " +
			"VALUES(:module_calculation_config_id, :required_profile_code)")
	void insert(@BindBean ModuleCalculationConfigProfileNTT formGroup);

	@SqlQuery("SELECT p.module_calculation_config_id," +
			"p.required_profile_code " +
			"FROM apps_module_calculation_config_profiles p " +
			"WHERE p.module_calculation_config_id=:module_calculation_config_id " +
			"AND p.required_profile_code = :required_profile_code " +
			"AND :tenant_id in " +
			"(SELECT s.tenant_id " +
			" FROM apps_module_calculation_configs mfc" +
			" INNER JOIN apps_modules am on am.id = mfc.module_id " +
			" INNER JOIN apps_sectors s on s.id = am.sector_id " +
			" WHERE p.module_calculation_config_id = mfc.id)")
	@RegisterBeanMapper(ModuleCalculationConfigProfileNTT.class)
	List<ModuleCalculationConfigProfileNTT> findById(@Bind("tenant_id") String tenantId,
													 @BindBean CalculationConfigProfileKey key);

	@Override
	@SqlQuery("SELECT p.module_calculation_config_id," +
			"p.required_profile_code " +
			"FROM apps_module_calculation_config_profiles p " +
			"WHERE p.module_calculation_config_id=:module_calculation_config_id " +
			"AND p.required_profile_code = :required_profile_code")
	@RegisterBeanMapper(ModuleCalculationConfigProfileNTT.class)
	List<ModuleCalculationConfigProfileNTT> findById(@BindBean CalculationConfigProfileKey key);

	@SqlQuery("SELECT p.module_calculation_config_id," +
			"p.required_profile_code " +
			"FROM apps_module_calculation_config_profiles p " +
			"WHERE p.module_calculation_config_id=:module_calculation_config_id AND " +
			":tenant_id in " +
			"(SELECT s.tenant_id " +
			" FROM apps_module_calculation_configs mfc" +
			" INNER JOIN apps_modules am on am.id = mfc.module_id " +
			" INNER JOIN apps_sectors s on s.id = am.sector_id " +
			" WHERE p.module_calculation_config_id = mfc.id)")
	@RegisterBeanMapper(ModuleCalculationConfigProfileNTT.class)
	List<ModuleCalculationConfigProfileNTT> find(@Bind("tenant_id") String tenantId,
												 @Bind("module_calculation_config_id") Long moduleFormConfigId);

	@Override
	@SqlUpdate("DELETE FROM apps_module_calculation_config_profiles p " +
			"WHERE p.module_calculation_config_id=:module_calculation_config_id " +
			"AND p.required_profile_code = :required_profile_code")
	void deleteById(@BindBean CalculationConfigProfileKey key);

	@SqlUpdate("DELETE FROM apps_module_calculation_config_profiles p " +
			"WHERE p.module_calculation_config_id=:module_calculation_config_id")
	void deleteByModuleCalculationConfigId(@Bind("module_calculation_config_id") Long moduleFormConfigId);

}
