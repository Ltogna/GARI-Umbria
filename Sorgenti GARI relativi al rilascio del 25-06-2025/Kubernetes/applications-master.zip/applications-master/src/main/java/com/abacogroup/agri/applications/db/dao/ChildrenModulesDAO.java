package com.abacogroup.agri.applications.db.dao;

import com.abacogroup.agri.applications.db.ntt.ChildModuleNTT;
import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.customizer.BindBean;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;

import java.time.LocalDateTime;
import java.util.List;

/**
 * @author Mattia Perini
 */
public interface ChildrenModulesDAO extends IGenericHistoricizationFieldsDAO<ChildModuleNTT, Long, Void> {

	@Override
	@SqlQuery("§select_nextval(apps_children_modules_seq_id)§")
	Long nextSequenceVal();

	@Override
	@SqlUpdate("INSERT INTO apps_children_modules " +
			" (pkid, " +
			" module_id, " +
			" parent_module_id, " +
			" dt_insert, " +
			" dt_delete, " +
			" user_id_insert, " +
			" user_id_delete) " +
			" VALUES(:pkid, :module_id, :parent_module_id, :current_timestamp, " +
			"       TO_TIMESTAMP('9999-12-3123:59:59','YYYY-MM-DDHH24:MI:SS'), :user_id, NULL)")
	void insert(@BindBean ChildModuleNTT rs, @Bind("user_id") String userId, @Bind("current_timestamp") LocalDateTime currentTimestamp);

	@Override
	@SqlQuery("SELECT pkid, " +
			" module_id, " +
			" parent_module_id, " +
			" dt_insert, " +
			" dt_delete, " +
			" user_id_insert, " +
			" user_id_delete " +
			" FROM apps_children_modules " +
			" WHERE pkid = :id")
	@RegisterBeanMapper(ChildModuleNTT.class)
	List<ChildModuleNTT> findById(@Bind("id") Long id);

	@SqlQuery("SELECT pkid, " +
			" module_id, " +
			" parent_module_id, " +
			" dt_insert, " +
			" dt_delete, " +
			" user_id_insert, " +
			" user_id_delete " +
			" FROM apps_children_modules " +
			" WHERE module_id = :module_id " +
			" AND parent_module_id = :parent_module_id " +
			" AND §current_timestamp§ BETWEEN dt_insert AND dt_delete ")
	@RegisterBeanMapper(ChildModuleNTT.class)
	ChildModuleNTT findByModuleIdAndParentModuleId(@Bind("module_id") Long moduleId, @Bind("parent_module_id") Long parentModuleId);

	@SqlQuery("SELECT pkid, " +
			" module_id, " +
			" parent_module_id, " +
			" dt_insert, " +
			" dt_delete, " +
			" user_id_insert, " +
			" user_id_delete " +
			" FROM apps_children_modules " +
			" WHERE module_id = :module_id " +
			" AND §current_timestamp§ BETWEEN dt_insert AND dt_delete")
	@RegisterBeanMapper(ChildModuleNTT.class)
	List<ChildModuleNTT> findByModuleId(@Bind("module_id") Long moduleId);

	@SqlQuery("SELECT pkid, " +
			" module_id, " +
			" parent_module_id, " +
			" dt_insert, " +
			" dt_delete, " +
			" user_id_insert, " +
			" user_id_delete " +
			" FROM apps_children_modules " +
			" WHERE parent_module_id = :parent_module_id " +
			" AND §current_timestamp§ BETWEEN dt_insert AND dt_delete")
	@RegisterBeanMapper(ChildModuleNTT.class)
	List<ChildModuleNTT> findByParentModuleId(@Bind("parent_module_id") Long parentModuleId);

	@SqlQuery("SELECT acm.pkid, " +
			" acm.module_id, " +
			" acm.parent_module_id, " +
			" acm.dt_insert, " +
			" acm.dt_delete, " +
			" acm.user_id_insert, " +
			" acm.user_id_delete " +
			" FROM apps_children_modules acm " +
			" left join apps_modules m on acm.module_id = m.id " +
			" left join apps_sectors s on m.sector_id = s.id " +
			" WHERE s.tenant_id = :tenant_id " +
			" AND §current_timestamp§ BETWEEN acm.dt_insert AND acm.dt_delete ")
	@RegisterBeanMapper(ChildModuleNTT.class)
	List<ChildModuleNTT> findAllByTenant(@Bind("tenant_id") String tenant);

	@Override
	@SqlUpdate("UPDATE apps_children_modules SET " +
			" user_id_delete = :user_id_delete, dt_delete = :current_timestamp " +
			" WHERE pkid = :id " +
			" AND §current_timestamp§ BETWEEN dt_insert AND dt_delete")
	void logicallyDeleteById(@Bind("id") Long id, @Bind("user_id_delete") String userDelete, @Bind("current_timestamp") LocalDateTime currentTimestamp);
}
