package com.abacogroup.agri.applications.core.model;

public enum CalculationResultType {

	RENDER,
	RAW
}
