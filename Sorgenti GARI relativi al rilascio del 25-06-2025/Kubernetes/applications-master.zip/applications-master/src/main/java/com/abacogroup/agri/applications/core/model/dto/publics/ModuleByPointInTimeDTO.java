package com.abacogroup.agri.applications.core.model.dto.publics;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author Gennaro Tamburrelli
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class ModuleByPointInTimeDTO {
	@Schema(description = "The module's year of validity")
	private Integer year;
	@Schema(description = "The module's code")
	private String moduleCode;
	@Schema(description = "The module's short description")
	private String moduleShortDescription;
	@Schema(description = "The sector's code")
	private String sectorCode;
	@Schema(description = "The sector's description")
	private String sectorShortDescription;
	@Schema(description = "The fl amend flag")
	private Integer flAmendModule;
	@Schema(description = "The fl child flag")
	private Integer flChildModule;
	@JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
	private String contextFunction;
	@JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
	private String forceReadOnlyContextFunction;
}
