package com.abacogroup.agri.applications.bundles.processor.workflow;

import com.abacogroup.agri.applications.core.services.workflow.ApplicationsWorkflowService;
import lombok.extern.slf4j.Slf4j;

import java.io.File;

/**
 * @author Gennaro Tamburrelli
 */
@Slf4j
public class WorkflowsBundleWorker {

	private final ApplicationsWorkflowService applicationsWorkflowService;

	public WorkflowsBundleWorker(ApplicationsWorkflowService applicationsWorkflowService) {
		this.applicationsWorkflowService = applicationsWorkflowService;
	}

	public ApplicationsWorkflowService exposeApplicationsWorkflowService() {
		return this.applicationsWorkflowService;
	}

	public void insertBundleWorkflow(String tenantId, File workFlowFile) {
		log.info("WorkflowsBundleWorker: processing file with tenant {}", tenantId);
		applicationsWorkflowService.addOrUpdateWorkflowFromFile(tenantId, workFlowFile);
		log.info("WorkflowsBundleWorker: processing file with tenant {} END", tenantId);
	}
}
