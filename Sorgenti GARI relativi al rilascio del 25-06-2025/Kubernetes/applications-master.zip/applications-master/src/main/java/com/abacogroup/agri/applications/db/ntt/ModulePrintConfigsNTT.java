package com.abacogroup.agri.applications.db.ntt;

import com.abacogroup.agri.applications.db.ntt.applications.IIdRs;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.util.Optional;

/**
 * @author Gennaro Tamburrelli
 */
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class ModulePrintConfigsNTT implements IIdRs<Long> {

	private Long id;
	private Long module_id;
	private String process_status;
	private Integer fl_available_to_user;
	private String print_code;
	private String print_description;
	private Integer sort_order;
	private String context_function;

	@Override
	public Optional<Long> getKey() {
		return Optional.ofNullable(this.id);
	}

	@Override
	public void setKey(Long id) {
		this.id = id;
	}
}
