package com.abacogroup.agri.applications.core.model.dto.publics;

import com.abacogroup.agri.applications.core.model.AbsoluteDate;
import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

/**
 * @author Gennaro Tamburrelli
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AppByPartyAndYearDTO {
	@Schema(description = "The party id owner of this application")
	private Long partyId;
	@Schema(description = "The application's year")
	private Integer year;
	@Schema(description = "The application's sector code")
	private String sectorCode;
	@Schema(description = "The application's sector description")
	private String sectorDescription;
	@Schema(description = "The application's module code")
	private String moduleCode;
	@Schema(description = "The application's module description")
	private String moduleDescription;
	@Schema(description = "The application's id")
	private Long applicationId;
	@Schema(description = "The application's code")
	private String applicationCode;
	@JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
	private Long processId;
	@Schema(description = "The application's status")
	private String processStatus;
	@Schema(description = "The application's status description")
	private String processStatusDescription;
	@Schema(description = "The application's presentation date")
	private AbsoluteDate dtPresentation;
	@Schema(description = "The application's closure status")
	private Boolean isClosed;
	@Schema(description = "The application's flag for check if application is amendable")
	private Boolean flAmendable;
	@Schema(description = "The application's protocol date")
	private AbsoluteDate dtProtocol;
	@Schema(description = "The application's protocol timestamp")
	private LocalDateTime dtProtocolTimestamp;
	@Schema(description = "The application's protocol code")
	private String protocol;
	@Schema(description = "The application's amendend by id")
	private Long amendedById;
	@Schema(description = "The application's amend of id")
	private Long amendOfId;
	@Schema(description = "the application's profiles exposed description")
	private String applicationProfilesDescription;

}
