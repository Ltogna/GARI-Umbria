package com.abacogroup.agri.applications.core.exceptions;

import io.swagger.v3.oas.annotations.media.Schema;

import jakarta.ws.rs.core.Response;

public class InsertExceptionRuntimeException extends AbstractException {

	private static final InsertExceptionRuntimeException.ErrorBody BODY = new InsertExceptionRuntimeException.ErrorBody();

	public InsertExceptionRuntimeException(String message) {
		super(Response.Status.INTERNAL_SERVER_ERROR, BODY, message);
	}

	public InsertExceptionRuntimeException() {
		super(Response.Status.INTERNAL_SERVER_ERROR, BODY, "Error during insert");
	}

	@Schema(name = "InsertExceptionRuntimeErrorBody")
	public static class ErrorBody implements ExceptionErrorBody {
		private static final String ERR = "INSERT_ERROR";

		@Override
		@Schema(allowableValues = ERR)
		public String getErrorCode() {
			return ERR;
		}
	}
}
