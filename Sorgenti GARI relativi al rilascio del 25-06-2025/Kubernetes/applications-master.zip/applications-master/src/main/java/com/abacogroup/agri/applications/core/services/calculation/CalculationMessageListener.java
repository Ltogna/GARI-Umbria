package com.abacogroup.agri.applications.core.services.calculation;

import com.abacogroup.agri.applications.core.model.dto.CalculationJobResponse;
import com.abacogroup.agri.applications.core.model.dto.CalculationJobStatus;
import com.abacogroup.agri.applications.core.services.crud.ApplicationGeneratedCalculationCrudService;
import com.abacogroup.agri.applications.core.services.embededqueue.NotifyCalculationEventQueue;
import com.abacogroup.applicationworkflowsdk.model.CalculationResult;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.rabbitmq.client.*;
import lombok.extern.slf4j.Slf4j;
import org.jdbi.v3.core.Jdbi;

import java.io.IOException;
import java.util.HashMap;

/**
 * @author Alexandru Paraschiv
 */
@Slf4j
public class CalculationMessageListener {

	private final Channel channel;
	public static final String CALCULATOR_EXCHANGE = "clc-engine-exchange";
	public static final String QUEUE_NAME = "calc-engine-process";
	public static final String ROUTING_KEY_TEMPLATE = "calculator-engine-job.%s.*";

	private final ApplicationGeneratedCalculationCrudService applicationGeneratedCalculationCrudService;
	private final Jdbi jdbi;
	private final NotifyCalculationEventQueue notifyCalculationEventQueue;

	public CalculationMessageListener(Connection rabbitMQConnection, String destination, ObjectMapper objectMapper,
			ApplicationGeneratedCalculationCrudService applicationGeneratedCalculationCrudService, Jdbi jdbi,
			NotifyCalculationEventQueue notifyCalculationEventQueue) throws IOException {
		this.channel = rabbitMQConnection.createChannel();
		this.applicationGeneratedCalculationCrudService = applicationGeneratedCalculationCrudService;
		this.jdbi = jdbi;
		this.notifyCalculationEventQueue = notifyCalculationEventQueue;

		this.channel.exchangeDeclare(CALCULATOR_EXCHANGE, BuiltinExchangeType.TOPIC, true);

		String routingKey = String.format(ROUTING_KEY_TEMPLATE, destination);
		this.channel.queueDeclare(QUEUE_NAME, true, false, false, new HashMap<>());
		this.channel.queueBind(QUEUE_NAME, CALCULATOR_EXCHANGE, routingKey);

		this.channel.basicQos(1);
		this.channel.basicConsume(QUEUE_NAME, false, (consumerTag, delivery) -> {
			handleCalculationMessage(objectMapper, delivery);
		}, consumerTag -> {
		});
	}

	private void handleCalculationMessage(ObjectMapper objectMapper, Delivery delivery) throws IOException {
		Envelope envelope = delivery.getEnvelope();
		String routingKey = envelope.getRoutingKey();
		long deliveryTag = envelope.getDeliveryTag();
		log.info("[CALCULATION-LISTENER] received message with routing key '{}'", routingKey);

		try {
			CalculationJobResponse res = objectMapper.readValue(delivery.getBody(), CalculationJobResponse.class);
			log.info("[CALCULATION-LISTENER] obtained message {}", res);
			jdbi.useTransaction(handle -> {
				var appCalculation = this.applicationGeneratedCalculationCrudService.findByUuid(res.getUuid());
				if (appCalculation == null) {
					log.warn("[CALCULATION-LISTENER] calculation not found for message: {}", res);
				} else {
					if (res.getStatus().equals(CalculationJobStatus.READY)) {
						appCalculation.setCalculationStatus(CalculationJobStatus.READY.name());
						log.info("[CALCULATION-LISTENER] updated file id");

					} else if (res.getStatus().equals(CalculationJobStatus.ERROR)) {
						appCalculation.setCalculationStatus(CalculationJobStatus.ERROR.name());
						log.info("[CALCULATION-LISTENER] has error...");
					}
					this.applicationGeneratedCalculationCrudService.update(appCalculation.getPkid(), appCalculation);
					notifyCalculationEventQueue.add(CalculationResult.builder()
							.calculationCode(appCalculation.getCalculationCode())
							.applicationId(appCalculation.getApplicationId())
							.result(res.getStatus().name())
							.user(appCalculation.getUsername())
							.uuid(appCalculation.getCalculationJobUuid())
							.build(), System.currentTimeMillis());
				}
			});

			this.channel.basicAck(deliveryTag, false);

			log.info("[CALCULATION-LISTENER] processed message with routing key '{}'", routingKey);
			log.trace("[CALCULATION-LISTENER] channel: {}", channel.getChannelNumber());
		} catch (Exception e) {
			log.warn("[CALCULATION-LISTENER] Got error during consumption of with routing key: " + routingKey, e);
			this.channel.basicNack(deliveryTag, false, false);
		}
	}

}
