package com.abacogroup.agri.applications.core.mappers;

import com.abacogroup.agri.applications.core.model.dto.ModuleCalculationConfigParamDTO;
import com.abacogroup.agri.applications.db.ntt.ModuleCalculationConfigParamNTT;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

@Mapper(uses = AbsoluteDateMapper.class)
public interface ModuleCalculationConfigParamMapper extends EntityMapper<ModuleCalculationConfigParamDTO, ModuleCalculationConfigParamNTT> {

	ModuleCalculationConfigParamMapper INSTANCE = Mappers.getMapper(ModuleCalculationConfigParamMapper.class);

	@InheritInverseConfiguration()
	ModuleCalculationConfigParamDTO entityToDto(ModuleCalculationConfigParamNTT entity);

	@Mapping(source = "moduleCalculationConfigId", target = "module_calculation_config_id")
	@Mapping(source = "parameterName", target = "parameter_name")
	@Mapping(source = "parameterValue", target = "parameter_value")
	ModuleCalculationConfigParamNTT dtoToEntity(ModuleCalculationConfigParamDTO dto);

}
