package com.abacogroup.agri.applications.core.services.crud;

import com.abacogroup.agri.applications.core.exceptions.ObjectNotFoundException;
import com.abacogroup.agri.applications.core.mappers.ModuleCalculationConfigsMapper;
import com.abacogroup.agri.applications.core.model.dto.ModuleCalculationConfigsDTO;
import com.abacogroup.agri.applications.core.services.I18NService;
import com.abacogroup.agri.applications.db.dao.ModuleCalculationConfigsDAO;
import com.abacogroup.agri.applications.db.ntt.ModuleCalculationConfigsNTT;
import com.abacogroup.agri.applications.db.ntt.applications.RsI18N;
import com.abacogroup.jaxrsutils.filter.MDCPreFilter;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.NotImplementedException;
import org.slf4j.MDC;

import java.util.List;
import java.util.Optional;

/**
 * @author Gennaro Tamburrelli
 */
@Slf4j
public class ModuleCalculationConfigsCrudService extends AbstractCrudService<ModuleCalculationConfigsNTT, Long, ModuleCalculationConfigsDTO, ModuleCalculationConfigsMapper, Void> {

	public static final String I18N_APPLICATION_CALCULATION_TABLE = "apps_module_calculation_configs";
	private final I18NService i18NService;

	public ModuleCalculationConfigsCrudService(ModuleCalculationConfigsDAO dao, ModuleCalculationConfigsMapper mapper, I18NService i18NService) {
		super(dao, mapper);
		this.i18NService = i18NService;
	}

	@Override
	protected boolean hasPrimaryKey() {
		return true;
	}

	@Override
	protected Optional<ModuleCalculationConfigsNTT> findRsByCustomKey(Void customKey) {
		return Optional.empty();
	}

	@Override
	protected void deleteByCustomKey(Void customKey) {
		throw new NotImplementedException("Not implemented.");
	}

	@Override
	protected void setCustomSearchKey(ModuleCalculationConfigsNTT rs, Void customKey) {
		throw new NotImplementedException("Not implemented.");
	}

	public List<ModuleCalculationConfigsDTO> findAllModuleCalculationConfigsByTenant(String tenantId) {
		return returnMappedList(((ModuleCalculationConfigsDAO) this.dao).findAllModuleCalculationConfigsByTenant(tenantId));
	}

	public List<ModuleCalculationConfigsDTO> findAllModuleCalculationConfigs(String tenantId, Long moduleId) {
		return returnMappedList(((ModuleCalculationConfigsDAO) this.dao).findAllModuleCalculationConfigs(tenantId, moduleId));
	}

	public ModuleCalculationConfigsDTO insert(ModuleCalculationConfigsDTO in) {
		log.info("Invoking insert with params in: {}", in);
		return this.insert(in, null);
	}

	public ModuleCalculationConfigsDTO update(Long key, ModuleCalculationConfigsDTO in) {
		log.info("Invoking update with params key: {} in: {}", key, in);
		return this.update(key, in, null);
	}

	public void delete(Long key) {
		log.info("Invoking delete with params key: {}", key);
		this.delete(key, null);
	}

	public ModuleCalculationConfigsDTO findById(String tenant, Long id) throws ObjectNotFoundException {
		log.info("Invoking findById with params tenant: {} id: {}", tenant, id);
		return returnOptionalRecord(((ModuleCalculationConfigsDAO) this.dao).findById(tenant, id, MDC.get(MDCPreFilter.LOCALE)))
				.orElseThrow(OBJECT_NOT_FOUND_EXCEPTION_SUPPLIER);
	}

	public List<ModuleCalculationConfigsDTO> find(String tenant, Long moduleId, String processStatus, List<String> profileCodeList) {
		return returnMappedList(((ModuleCalculationConfigsDAO) this.dao).find(tenant, moduleId, processStatus, profileCodeList, MDC.get(MDCPreFilter.LOCALE)));
	}

	public Optional<ModuleCalculationConfigsDTO> find(String tenant, Long moduleId, String calculationCode, String processStatus) {
		return returnOptionalRecord(((ModuleCalculationConfigsDAO) this.dao).find(tenant, moduleId, calculationCode, processStatus));
	}

	public Optional<ModuleCalculationConfigsDTO> find(String tenant, Long moduleId, String calculationCode, String processStatus, String contextFunction) {
		List<ModuleCalculationConfigsNTT> moduleCalculationConfigsNTTS = ((ModuleCalculationConfigsDAO) this.dao).find(tenant, moduleId, calculationCode, processStatus, contextFunction);
		return returnOptionalRecord(moduleCalculationConfigsNTTS);
	}


	public void insertCalculationCodeI18N(String tenant, String code, String lang, String description) {
		this.i18NService.insertI18N(tenant, I18N_APPLICATION_CALCULATION_TABLE, CALCULATION_CODE_I18N.PROFILE_CODE.code, lang, code, description);
	}

	public void deleteCalculationCodeI18N(String tenant, String code, String lang) {
		this.i18NService.deleteI18N(tenant, I18N_APPLICATION_CALCULATION_TABLE, CALCULATION_CODE_I18N.PROFILE_CODE.code, code, lang);
	}

	public List<RsI18N> getAllCalculationCodeI18NByTenantAndCode(String tenant, String code) {
		return this.i18NService.getAllI18NbyCode(tenant, I18N_APPLICATION_CALCULATION_TABLE, code);
	}

	public enum CALCULATION_CODE_I18N {
		PROFILE_CODE("calculation_code");

		private final String code;

		CALCULATION_CODE_I18N(String val) {
			this.code = val;
		}

		public String getCode() {
			return this.code;
		}
	}

}
