package com.abacogroup.agri.applications.core.model.dto;

public enum VariableKind {
	STRING,
	NUMBER_LONG,
	NUMBER_DOUBLE,
	DATE,
	DATE_TIME,
	AREA_SQM,
	LENGTH_MT,
	MONEY,
	PERCENTAGE
}
