package com.abacogroup.agri.applications.db.ntt;

import com.abacogroup.agri.applications.db.ntt.applications.IIdRs;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Optional;

/**
 * @author Gennaro Tamburrelli
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ModulePrintConfigProfileNTT implements IIdRs<Void> {

	private Long module_print_config_id;
	private String required_profile_code;

	@Override public Optional<Void> getKey() {
		return Optional.empty();
	}

	@Override public void setKey(Void id) {
		// not in use
	}

}
