package com.abacogroup.agri.applications.core.services;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.text.MessageFormat;
import java.util.Optional;

import com.abacogroup.agri.applications.core.exceptions.FileStoreIORuntimeException;
import com.abacogroup.agri.applications.core.exceptions.FileStoreMetadataNotFoundException;
import com.abacogroup.agri.applications.core.model.dto.FileDTO;
import com.abacogroup.agri.applications.core.model.dto.SavedFileDTO;
import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.filestore.client.FileStoreClient;
import com.abacogroup.filestore.client.auth.Authenticator;
import com.abacogroup.filestore.client.auth.Sso2Authenticator;
import com.abacogroup.filestore.client.request.FileToAddMetadata;
import com.abacogroup.filestore.client.response.AddFileResponse;
import com.abacogroup.filestore.client.response.FileMetadata;

import jakarta.ws.rs.core.Response;
import lombok.extern.slf4j.Slf4j;

/**
 * @author Mauro Pozzana
 * @author Alexandru Paraschiv
 */
@Slf4j
public class FileStoreService {

	private static final String APP_OCTET_STREAM_MIME_TYPE = "application/octet-stream";
	private FileStoreClient fileStoreClient;

	public FileStoreService(FileStoreClient fileStoreClient) {
		this.fileStoreClient = fileStoreClient;
	}

	public FileDTO getFile(String tenantId, String fileId, String bucketId, User user, Authenticator authenticator) throws FileStoreMetadataNotFoundException {

		ByteArrayOutputStream outputStream = new ByteArrayOutputStream();

		FileMetadata fileMetadata = null;

		try {
			fileMetadata = fileStoreClient.getFileMetadata(authenticator, tenantId, bucketId, fileId);
			fileStoreClient.getFileContent(authenticator, tenantId, bucketId, fileId, outputStream);
		} catch (IOException e) {
			log.error(e.getMessage(), e);
			throw new FileStoreIORuntimeException(e.getMessage());
		}

		if (Optional.ofNullable(fileMetadata).isEmpty()) {
			throw new FileStoreMetadataNotFoundException(MessageFormat.format(
					"File metadata not found for user: {0} tenant: {1} fileId: {2} bucketId: {3}",
					user.getUserId(), tenantId, fileId, bucketId));
		}

		byte[] content = outputStream.toByteArray();
		return FileDTO.builder()
				.name(fileMetadata.getName())
				.id(fileId)
				.bucketId(bucketId)
				.content(content)
				.build();
	}

	public Response getFileForDownload(String tenantId, String fileId, String bucketId, String fileName, User user, Authenticator authenticator) {
		log.info("getFileForDownload from file store started with tenantId: {} fileId: {} bucketId: {} username: {}",
				tenantId, fileId, bucketId, user.getUserId());
		try {
			return fileStoreClient.jaxrs().proxyFileResponse(authenticator, tenantId, bucketId, fileId,fileName);
		} catch (IOException e) {
			throw new FileStoreIORuntimeException("Cannot retrieve file");
		} finally {
			log.info("getFileForDownload from File Store ended");
		}
	}

	public SavedFileDTO saveFile(String tenantId, String bucketId, InputStream inputStream, String fileName, User user,
			Authenticator authenticator) {
		log.info("Saving file to File Store with tenantId: {} bucketId: {} fileName: {} username: {}",
				tenantId, bucketId, fileName, user.getUserId());
		FileToAddMetadata fileToAddMetadata = new FileToAddMetadata(fileName, APP_OCTET_STREAM_MIME_TYPE);
		AddFileResponse response = null;
		try {
			response = fileStoreClient.addFile(new Sso2Authenticator(user), tenantId, bucketId, fileToAddMetadata, inputStream);
		} catch (IOException e) {
			throw new FileStoreIORuntimeException("Cannot add file");
		}
		log.info("Successfully saved file to File Store with id {}", response.getId());

		return SavedFileDTO.builder()
				.fileId(response.getId())
				.build();
	}

	public void deleteFile(String tenantId, String fileId, String bucketId, User user, Authenticator authenticator) {
		log.info("deleting file on file server with user: {} tenant: {} fileId: {} bucketId: {}",
				user.getUserId(), tenantId, fileId, bucketId);
		log.warn("Skipping attachment deletion on File Store: functionality not supported");
	}

}
