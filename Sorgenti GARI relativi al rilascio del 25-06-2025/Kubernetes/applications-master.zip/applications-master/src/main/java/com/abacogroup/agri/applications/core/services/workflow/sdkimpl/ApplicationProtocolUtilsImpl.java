package com.abacogroup.agri.applications.core.services.workflow.sdkimpl;

import java.time.LocalDateTime;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import com.abacogroup.agri.applications.core.model.dto.ApplicationGeneratedPrintDTO;
import com.abacogroup.agri.applications.core.model.dto.publics.ApplicationProtocolsDTO;
import com.abacogroup.agri.applications.core.services.HistoryService;
import com.abacogroup.agri.applications.core.services.crud.ApplicationGeneratedPrintCrudService;
import com.abacogroup.agri.applications.core.services.crud.ApplicationProtocolsCrudService;
import com.abacogroup.agri.applications.core.services.crud.ApplicationsCrudService;
import com.abacogroup.agri.applications.core.services.crud.CrudServiceContainer;
import com.abacogroup.applicationworkflowsdk.model.DetailedSdkTransitionLog;
import com.abacogroup.applicationworkflowsdk.model.io.output.ApplicationProtocol;
import com.abacogroup.applicationworkflowsdk.service.ApplicationProtocolUtils;
import com.abacogroup.dropwizard.auth.sso2.User;
import lombok.extern.slf4j.Slf4j;

/**
 * @author Gennaro Tamburrelli
 */
@Slf4j
public class ApplicationProtocolUtilsImpl implements ApplicationProtocolUtils {

	private final ApplicationsCrudService applicationsCrudService;
	private final ApplicationProtocolsCrudService applicationProtocolsCrudService;
	private final ApplicationGeneratedPrintCrudService applicationGeneratedPrintCrudService;
	private final HistoryService historyService;

	public ApplicationProtocolUtilsImpl(CrudServiceContainer crudServiceContainer,
			HistoryService historyService) {
		this.applicationsCrudService = crudServiceContainer.getApplicationsCrudService();
		this.applicationProtocolsCrudService = crudServiceContainer.getApplicationProtocolsCrudService();
		this.applicationGeneratedPrintCrudService = crudServiceContainer.getApplicationGeneratedPrintCrudService();
		this.historyService = historyService;
	}

	@Override
	public String retrievePrintId(String tenant, Long applicationId, String printCode, User user) {
		return this.applicationGeneratedPrintCrudService.findAllGeneratedPrints(tenant, applicationId)
				.stream()
				.filter(x -> printCode == null || x.getPrintCode().equals(printCode))
				.max(Comparator.comparing(ApplicationGeneratedPrintDTO::getPrintDate))
				.map(ApplicationGeneratedPrintDTO::getFileId)
				.orElseThrow(() -> new RuntimeException("print not found"));
	}

	@Override
	public List<DetailedSdkTransitionLog> retrieveHistoryLog(String tenant, Long applicationId, User user) {
		return historyService.getApplicationHistoryByApplicationId(tenant, applicationId, user)
				.stream()
				.map(x -> DetailedSdkTransitionLog.builder()
						.id(x.getId())
						.startDate(x.getStartDate())
						.endDate(x.getEndDate())
						.userId(x.getUserId())
						.processId(x.getProcessId())
						.transitionId(x.getTransitionId())
						.notes(x.getNotes())
						.failed(x.isFailed())
						.description(x.getDescription())
						.fromNode(x.getFromNode())
						.fromNodeDescription(x.getFromNodeDescription())
						.toNode(x.getToNode())
						.toNodeDescription(x.getToNodeDescription())
						.messages(x.getMessages())
						.build())
				.collect(Collectors.toList());
	}

	@Override
	public String retrieveSectorDescription(String tenant, Long applicationId, User user, String locale) {
		var appDetails = this.applicationsCrudService.findWithDetailsByApplicationId(tenant, applicationId, locale);
		return appDetails.getSectorDescription();
	}

	@Override
	public String retrieveModuleDescription(String tenant, Long applicationId, User user, String locale) {
		var appDetails = this.applicationsCrudService.findWithDetailsByApplicationId(tenant, applicationId, locale);
		return appDetails.getModuleDescription();
	}

	@Override
	public void insertProtocolRequest(String tenant, Long applicationId, User user) {
		log.info("Inserting protocol request...");
		ApplicationProtocolsDTO appProtocol = ApplicationProtocolsDTO.builder()
				.applicationId(applicationId)
				.dtRequest(applicationProtocolsCrudService.getCurrentTimestamp())
				.build();
		applicationProtocolsCrudService.insert(appProtocol, user.getUserId());
		log.info("inserted protocol request {}", appProtocol);
	}

	@Override
	public void insertProtocolCodeAndDate(String tenant, Long applicationId, String protocolCode, LocalDateTime protocolDate, User user) {
		log.info("Finding protocol instances for application id {}", applicationId);
		ApplicationProtocolsDTO protocol = applicationProtocolsCrudService.findAll(tenant, applicationId)
				.stream()
				.filter(x -> x.getProtocol() == null)
				.findFirst()
				.orElseThrow();
		log.info("found protocol instances {}", protocol);
		protocol.setProtocol(protocolCode);
		protocol.setDtResponse(protocolDate != null ? protocolDate : applicationProtocolsCrudService.getCurrentTimestamp());
		log.info("updating to {}", protocol);
		applicationProtocolsCrudService.update(protocol.getPkid(), protocol, user.getUserId());
	}

	@Override
	public Optional<ApplicationProtocol> retrieveProtocol(String tenant, Long applicationId) {
		return applicationProtocolsCrudService.findAll(tenant, applicationId)
				.stream()
				.filter(x -> x.getProtocol() != null)
				.findFirst()
				.map(x -> ApplicationProtocol.builder()
						.applicationId(x.getApplicationId())
						.protocol(x.getProtocol())
						.dtRequest(x.getDtRequest())
						.dtResponse(x.getDtResponse())
						.build());
	}

}
