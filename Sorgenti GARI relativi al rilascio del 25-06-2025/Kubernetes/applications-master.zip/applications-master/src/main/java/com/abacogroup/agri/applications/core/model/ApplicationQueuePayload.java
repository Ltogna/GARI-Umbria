package com.abacogroup.agri.applications.core.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author Gennaro Tamburrelli
 */

@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
public class ApplicationQueuePayload {
    private String tenant;
    private Long applicationId;
    private String sectorCode;
    private String moduleCode;
    private String currentStatus;
    private String transitionCode;
    private String userId;
}
