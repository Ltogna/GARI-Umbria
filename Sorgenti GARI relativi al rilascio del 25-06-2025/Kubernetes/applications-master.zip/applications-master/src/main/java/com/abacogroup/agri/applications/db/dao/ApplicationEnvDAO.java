package com.abacogroup.agri.applications.db.dao;

import com.abacogroup.agri.applications.db.ntt.ApplicationEnvNTT;
import com.abacogroup.agri.applications.db.ntt.compoundkeys.ApplicationEnvKey;
import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.customizer.BindBean;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;

import java.util.List;

/**
 * The interface Application env dao.
 *
 * @author Carlo Sindico
 */
public interface ApplicationEnvDAO extends IGenericDAO<ApplicationEnvNTT, ApplicationEnvKey> {

	@Override
	@SqlUpdate("INSERT INTO apps_config " +
			"(tenant_id, key, value, fl_client) " +
			"VALUES(:tenant_id, :key_, :value, :fl_client)")
	void insert(@BindBean ApplicationEnvNTT ntt);

	@Override
	@SqlUpdate("UPDATE apps_config SET " +
			"tenant_id=:tenant_id, " +
			"key=:key_, " +
			"value=:value, " +
			"fl_client=:fl_client " +
			"WHERE tenant_id=:tenant_id AND key=:key_ AND fl_client=:fl_client")
	void update(@BindBean ApplicationEnvNTT ntt);

	@Override
	@SqlUpdate("DELETE FROM apps_config " +
			"WHERE tenant_id=:tenant_id AND key=:key_ AND fl_client=:fl_client")
	void deleteById(@BindBean() ApplicationEnvKey key);

	@Override
	@SqlQuery("SELECT ac.tenant_id, " +
			" ac.key, " +
			" ac.value, " +
			" ac.fl_client " +
			" FROM apps_config ac " +
			" WHERE ac.tenant_id=:tenant_id AND ac.key=:key_ AND fl_client=:fl_client")
	@RegisterBeanMapper(ApplicationEnvNTT.class)
	List<ApplicationEnvNTT> findById(@BindBean ApplicationEnvKey key);

	@SqlQuery("SELECT ac.tenant_id, " +
			" ac.key as key_, " +
			" ac.value, " +
			" ac.fl_client " +
			" FROM apps_config ac " +
			" WHERE ac.tenant_id=:tenant_id AND ac.key=:key_ AND ac.fl_client=:fl_client")
	@RegisterBeanMapper(ApplicationEnvNTT.class)
	ApplicationEnvNTT findByKey(@BindBean ApplicationEnvKey key);

	@SqlQuery("SELECT ac.tenant_id, " +
			" ac.key as key_, " +
			" ac.value, " +
			" ac.fl_client " +
			" FROM apps_config ac " +
			" WHERE ac.tenant_id=:tenant_id AND ac.key=:key_")
	@RegisterBeanMapper(ApplicationEnvNTT.class)
	ApplicationEnvNTT findByKeyWithoutFlClient(@BindBean ApplicationEnvKey key);

	@SqlQuery("SELECT ac.tenant_id, " +
			" ac.key as key_, " +
			" ac.value, " +
			" ac.fl_client " +
			" FROM apps_config ac " +
			" WHERE ac.tenant_id=:tenant")
	@RegisterBeanMapper(ApplicationEnvNTT.class)
	List<ApplicationEnvNTT> findAll(@Bind("tenant") String tenant);

}
