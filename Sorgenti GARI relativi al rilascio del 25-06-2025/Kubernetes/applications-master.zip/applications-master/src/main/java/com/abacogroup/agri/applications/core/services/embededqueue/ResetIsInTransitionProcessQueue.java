package com.abacogroup.agri.applications.core.services.embededqueue;

import com.abacogroup.agri.applications.core.model.ProcessTransitionEnum;
import com.abacogroup.agri.applications.core.services.crud.ApplicationDetailsCrudService;
import com.abacogroup.agri.applications.core.services.embededqueue.model.ResetInTransitionParams;
import com.abacogroup.embeddedqueue.QueueErrorListener;
import com.abacogroup.embeddedqueue.ThrowingConsumer;
import com.abacogroup.embeddedqueue.WorkQueue;
import com.abacogroup.embeddedqueue.db.JdbiRepository;
import com.codahale.metrics.MetricRegistry;
import com.fasterxml.jackson.databind.ObjectMapper;

import static com.abacogroup.embeddedqueue.QueueErrorListener.ErrorAction.DELETE_FROM_QUEUE;

/**
 * @author Gennaro Tamburrelli
 */
public class ResetIsInTransitionProcessQueue extends WorkQueue<ResetInTransitionParams> {

	private ApplicationDetailsCrudService applicationDetailsCrudService;

	public ResetIsInTransitionProcessQueue(JdbiRepository repo, ObjectMapper objectMapper, MetricRegistry registry,
			ApplicationDetailsCrudService applicationDetailsCrudService, int numThreads, long timeoutMs) {
		super("app-reset-tran-proc", repo, numThreads, timeoutMs);
		this.applicationDetailsCrudService = applicationDetailsCrudService;
		this.setObjectMapper(objectMapper);
		this.setMetricRegistry(registry);
		this.setConsumer(doTheJob);
		this.setErrorListener(handleError);
		this.start();
	}

	@Override
	protected Class<ResetInTransitionParams> getJobClass() {
		return ResetInTransitionParams.class;
	}

	private final ThrowingConsumer<ResetInTransitionParams> doTheJob = appParams ->
			applicationDetailsCrudService.updateFlTransition(appParams.getTenant(),
					appParams.getApplicationId(),
					appParams.getUserid(),
					ProcessTransitionEnum.NOT_IN_TRANSITION);

	private final QueueErrorListener<ResetInTransitionParams> handleError = (appParams, exp) -> {
		return DELETE_FROM_QUEUE;
	};

}
