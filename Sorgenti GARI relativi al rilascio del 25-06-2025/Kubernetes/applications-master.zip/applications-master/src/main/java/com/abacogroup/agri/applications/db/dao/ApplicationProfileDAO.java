package com.abacogroup.agri.applications.db.dao;

import java.time.LocalDateTime;
import java.util.List;

import org.jdbi.v3.core.result.ResultIterator;
import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.customizer.BindBean;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;

import com.abacogroup.agri.applications.db.ntt.ApplicationProfileNTT;

/**
 * @author Gennaro Tamburrelli
 */
public interface ApplicationProfileDAO extends IGenericHistoricizationFieldsDAO<ApplicationProfileNTT, Long, Void> {

	@Override
	@SqlQuery("§select_nextval(apps_application_profiles_id_seq)§")
	Long nextSequenceVal();

	@Override
	@SqlUpdate("INSERT INTO apps_application_profiles (pkid, application_id, profile_code, dt_insert, dt_delete, user_id_insert, user_id_delete) " +
			"VALUES(:pkid, :application_id, :profile_code, :current_timestamp, " +
			"TO_TIMESTAMP('9999-12-3123:59:59','YYYY-MM-DDHH24:MI:SS'), :user_id, NULL)")
	void insert(@BindBean ApplicationProfileNTT rs, @Bind("user_id") String userId, @Bind("current_timestamp") LocalDateTime currentTimestamp);

	@Override
	@SqlQuery("SELECT pkid, " +
			"application_id, " +
			"profile_code, " +
			"dt_insert, " +
			"dt_delete, " +
			"user_id_insert, " +
			"user_id_delete " +
			"FROM apps_application_profiles " +
			"WHERE pkid = :id")
	@RegisterBeanMapper(ApplicationProfileNTT.class)
	List<ApplicationProfileNTT> findById(@Bind("id") Long id);

	@SqlQuery("SELECT ap.pkid, " +
			"ap.application_id, " +
			"ap.profile_code, " +
			"§i18n(:tenantId, 'apps_module_profiles', 'profile_code', ap.profile_code, :lang)§ as profile_code_description, " +
			"ap.dt_insert, " +
			"ap.dt_delete, " +
			"ap.user_id_insert, " +
			"ap.user_id_delete " +
			"FROM apps_application_profiles ap " +
			"LEFT JOIN apps_applications a ON ap.application_id = a.id " +
			"LEFT JOIN apps_application_details ad ON ad.application_id = a.id " +
			"LEFT JOIN apps_modules m ON a.module_id = m.id " +
			"LEFT JOIN apps_sectors s ON m.sector_id = s.id " +
			"WHERE ad.application_code = :code AND s.tenant_id = :tenantId " +
			"and §current_timestamp§ between ap.dt_insert and ap.dt_delete " +
			"and §current_timestamp§ between a.dt_insert and a.dt_delete " +
			"and §current_timestamp§ between ad.dt_insert and ad.dt_delete " +
			"and §current_timestamp§ between m.dt_insert and m.dt_delete")
	@RegisterBeanMapper(ApplicationProfileNTT.class)
	ResultIterator<ApplicationProfileNTT> findInfinite(@Bind("tenantId") String tenant, @Bind("code") String code, @Bind("lang") String lang);

	@SqlQuery("SELECT ap.pkid, " +
			"ap.application_id, " +
			"ap.profile_code, " +
			"§i18n(:tenantId, 'apps_module_profiles', 'profile_code', ap.profile_code, :lang)§ as profile_code_description, " +
			"ap.dt_insert, " +
			"ap.dt_delete, " +
			"ap.user_id_insert, " +
			"ap.user_id_delete " +
			"FROM apps_application_profiles ap " +
			"LEFT JOIN apps_applications a ON ap.application_id = a.id " +
			"LEFT JOIN apps_application_details ad ON ad.application_id = a.id " +
			"LEFT JOIN apps_modules m ON a.module_id = m.id " +
			"LEFT JOIN apps_sectors s ON m.sector_id = s.id " +
			"WHERE a.id = :app_id AND s.tenant_id = :tenantId " +
			"and (:date_time between ap.dt_insert and ap.dt_delete) " +
			"and (:date_time between a.dt_insert and a.dt_delete) " +
			"and (:date_time between ad.dt_insert and ad.dt_delete) " +
			"and (:date_time between m.dt_insert and m.dt_delete) ")
	@RegisterBeanMapper(ApplicationProfileNTT.class)
	ResultIterator<ApplicationProfileNTT> findInfinite(@Bind("tenantId") String tenant, @Bind("app_id") Long appId,
													   @Bind("date_time") LocalDateTime dateTime, @Bind("lang") String lang);

	@SqlQuery("SELECT ap.pkid, " +
			"ap.application_id, " +
			"ap.profile_code, " +
			"§i18n(:tenantId, 'apps_module_profiles', 'profile_code', ap.profile_code, :lang)§ as profile_code_description, " +
			"ap.dt_insert, " +
			"ap.dt_delete, " +
			"ap.user_id_insert, " +
			"ap.user_id_delete " +
			"FROM apps_application_profiles ap " +
			"LEFT JOIN apps_applications a ON ap.application_id = a.id " +
			"LEFT JOIN apps_application_details ad ON ad.application_id = a.id " +
			"LEFT JOIN apps_modules m ON a.module_id = m.id " +
			"LEFT JOIN apps_sectors s ON m.sector_id = s.id " +
			"WHERE ad.application_code = :code AND s.tenant_id = :tenantId " +
			"and §current_timestamp§ between ap.dt_insert and ap.dt_delete " +
			"and §current_timestamp§ between a.dt_insert and a.dt_delete " +
			"and §current_timestamp§ between ad.dt_insert and ad.dt_delete " +
			"and §current_timestamp§ between m.dt_insert and m.dt_delete")
	@RegisterBeanMapper(ApplicationProfileNTT.class)
	List<ApplicationProfileNTT> find(@Bind("tenantId") String tenant, @Bind("code") String code, @Bind("lang") String lang);

	@SqlQuery("SELECT ap.pkid, " +
			"ap.application_id, " +
			"ap.profile_code, " +
			"ap.dt_insert, " +
			"ap.dt_delete, " +
			"ap.user_id_insert, " +
			"ap.user_id_delete " +
			"FROM apps_application_profiles ap " +
			"LEFT JOIN apps_applications a ON ap.application_id = a.id " +
			"LEFT JOIN apps_application_details ad ON ad.application_id = a.id " +
			"LEFT JOIN apps_modules m ON a.module_id = m.id " +
			"LEFT JOIN apps_sectors s ON m.sector_id = s.id " +
			"WHERE a.id = :app_id AND s.tenant_id = :tenantId " +
			"and §current_timestamp§ between ap.dt_insert and ap.dt_delete " +
			"and §current_timestamp§ between a.dt_insert and a.dt_delete " +
			"and §current_timestamp§ between ad.dt_insert and ad.dt_delete " +
			"and §current_timestamp§ between m.dt_insert and m.dt_delete")
	@RegisterBeanMapper(ApplicationProfileNTT.class)
	List<ApplicationProfileNTT> find(@Bind("tenantId") String tenant, @Bind("app_id") Long appId);

	@SqlQuery("SELECT ap.pkid, " +
			"ap.application_id, " +
			"ap.profile_code, " +
			"ap.dt_insert, " +
			"ap.dt_delete, " +
			"ap.user_id_insert, " +
			"ap.user_id_delete " +
			"FROM apps_application_profiles ap " +
			"LEFT JOIN apps_applications a ON ap.application_id = a.id " +
			"LEFT JOIN apps_application_details ad ON ad.application_id = a.id " +
			"LEFT JOIN apps_modules m ON a.module_id = m.id " +
			"LEFT JOIN apps_sectors s ON m.sector_id = s.id " +
			"WHERE a.id = :app_id AND s.tenant_id = :tenantId " +
			"and ap.profile_code = :profile_code " +
			"and §current_timestamp§ between ap.dt_insert and ap.dt_delete " +
			"and §current_timestamp§ between a.dt_insert and a.dt_delete " +
			"and §current_timestamp§ between ad.dt_insert and ad.dt_delete " +
			"and §current_timestamp§ between m.dt_insert and m.dt_delete")
	@RegisterBeanMapper(ApplicationProfileNTT.class)
	List<ApplicationProfileNTT> findByUnique(@Bind("tenantId") String tenant, @Bind("app_id") Long appId, @Bind("profile_code") String profileCode);

	@SqlQuery("SELECT ap.pkid, " +
			"ap.application_id, " +
			"ap.profile_code, " +
			"§i18n(:tenantId, 'apps_module_profiles', 'profile_code', ap.profile_code, :lang)§ as profile_code_description, " +
			"ap.dt_insert, " +
			"ap.dt_delete, " +
			"ap.user_id_insert, " +
			"ap.user_id_delete, " +
			"amp.fl_label_exposed " +
			"FROM apps_application_profiles ap " +
			"LEFT JOIN apps_applications a ON ap.application_id = a.id " +
			"LEFT JOIN apps_application_details ad ON ad.application_id = a.id " +
			"LEFT JOIN apps_modules m ON a.module_id = m.id " +
			"LEFT JOIN apps_sectors s ON m.sector_id = s.id " +
			"LEFT JOIN apps_module_profiles amp on amp.module_id = m.id and amp.profile_code=ap.profile_code " +
			"WHERE a.id = :app_id AND s.tenant_id = :tenantId " +
			"and §current_timestamp§ between ap.dt_insert and ap.dt_delete " +
			"and §current_timestamp§ between a.dt_insert and a.dt_delete " +
			"and §current_timestamp§ between ad.dt_insert and ad.dt_delete " +
			"and §current_timestamp§ between m.dt_insert and m.dt_delete " +
			"and §current_timestamp§ between amp.dt_insert and amp.dt_delete ")
	@RegisterBeanMapper(ApplicationProfileNTT.class)
	List<ApplicationProfileNTT> find(@Bind("tenantId") String tenant, @Bind("app_id") Long appId, @Bind("lang") String lang);

	@Override
	@SqlUpdate("UPDATE apps_application_profiles SET " +
			"user_id_delete = :user_id_delete, dt_delete = :current_timestamp " +
			"WHERE pkid = :id " +
			"and §current_timestamp§ between dt_insert and dt_delete")
	void logicallyDeleteById(@Bind("id") Long id, @Bind("user_id_delete") String userDelete, @Bind("current_timestamp") LocalDateTime currentTimestamp);

	@SqlUpdate("UPDATE apps_application_profiles SET " +
			"  user_id_delete = :user_id_delete, dt_delete = §current_timestamp§ " +
			"  WHERE pkid in " +
			"(SELECT ap.pkid " +
			" FROM apps_application_profiles ap " +
			" LEFT JOIN apps_applications a ON ap.application_id = a.id " +
			" LEFT JOIN apps_application_details ad ON ad.application_id = a.id " +
			" LEFT JOIN apps_modules m ON a.module_id = m.id " +
			" LEFT JOIN apps_sectors s ON m.sector_id = s.id " +
			" WHERE ad.application_code = :application_code AND s.tenant_id = :tenant " +
			" and §current_timestamp§ between a.dt_insert and a.dt_delete " +
			" and §current_timestamp§ between ad.dt_insert and ad.dt_delete " +
			" and §current_timestamp§ between m.dt_insert and m.dt_delete " +
			" and §current_timestamp§ between ap.dt_insert and ap.dt_delete)")
	void bulkLogicallyDeleteByApplicationCode(@Bind("tenant") String tenant, @Bind("application_code") String applicationCode,
			@Bind("user_id_delete") String userIdDelete);

	@SqlUpdate("UPDATE apps_application_profiles SET " +
			"  user_id_delete = :user_id_delete, dt_delete = §current_timestamp§ " +
			"  WHERE pkid in " +
			"(SELECT ap.pkid " +
			" FROM apps_application_profiles ap " +
			" LEFT JOIN apps_applications a ON ap.application_id = a.id " +
			" LEFT JOIN apps_application_details ad ON ad.application_id = a.id " +
			" LEFT JOIN apps_modules m ON a.module_id = m.id " +
			" LEFT JOIN apps_sectors s ON m.sector_id = s.id " +
			" WHERE a.id = :app_id AND s.tenant_id = :tenant " +
			" and §current_timestamp§ between a.dt_insert and a.dt_delete " +
			" and §current_timestamp§ between ad.dt_insert and ad.dt_delete " +
			" and §current_timestamp§ between m.dt_insert and m.dt_delete " +
			" and §current_timestamp§ between ap.dt_insert and ap.dt_delete)")
	void bulkLogicallyDeleteByApplicationId(@Bind("tenant") String tenant, @Bind("app_id") Long appId,
			@Bind("user_id_delete") String userIdDelete);
}
