package com.abacogroup.agri.applications.core.model.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

/**
 * @author Mattia Perini
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ApplicationsRelationDTO {
	private Long pkid;
	private Long parentApplicationId;
	private Long childApplicationId;
	private String userIdInsert;
	private String userIdDelete;
	private LocalDateTime dtInsert;
	private LocalDateTime dtDelete;
}
