package com.abacogroup.agri.applications.core.model.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

/**
 * @author Mattia Perini
 */
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class ModuleCalculationConfigsDTO {
	private Long id;
	private Long moduleId;
	private String processStatus;
	private String calculationCode;
	private String calculationDescription;
	private Integer sortOrder;
	private String contextFunction;
}
