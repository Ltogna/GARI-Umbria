package com.abacogroup.agri.applications.bundles.processor.sector;

import com.abacogroup.agri.applications.bundles.model.sector.BundleSectorsMessage;
import com.abacogroup.agri.applications.bundles.processor.AbstractBundleApplicationsProcessor;
import com.abacogroup.bundles.listener.configdata.ConfigDataMessage;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.jdbi.v3.core.Jdbi;

import java.nio.file.Path;

/**
 * @author Alexandru Paraschiv
 */
@Slf4j
public class BundleSectorsProcessor extends AbstractBundleApplicationsProcessor<BundleSectorsMessage> {

	protected final SectorsBundleWorker sectorsBundleWorker;

	public BundleSectorsProcessor(ObjectMapper mapper, SectorsBundleWorker sectorsBundleWorker, Jdbi jdbi) {
		super(mapper, jdbi);
		this.sectorsBundleWorker = sectorsBundleWorker;
	}

	@Override
	public String getDomainName() {
		return "sectors";
	}

	@Override
	protected TypeReference<BundleSectorsMessage> getTypeReference() {
		return new TypeReference<>() {
		};
	}

	@Override
	public void onMessageInTransaction(ConfigDataMessage message) {
		log.info("onMessageInTransaction: proccessing file with tenant {}", message.getTenantId());
		message.getConfigFiles().stream()
				.map(Path::toFile)
				.filter(file -> file.getAbsolutePath().endsWith(".json"))
				.forEach(file -> processFile(message.getTenantId(), file));
	}

	@Override
	protected void delete(String tenantId, BundleSectorsMessage message) {
		sectorsBundleWorker.deleteBundleSectors(tenantId, message);
	}

	@Override
	protected void doInsertOrUpdate(String tenantId, BundleSectorsMessage message) {
		sectorsBundleWorker.upsertBundleSectors(tenantId, message);
	}

}
