package com.abacogroup.agri.applications.db.dao;

import com.abacogroup.agri.applications.db.ntt.ModuleCalculationConfigParamNTT;
import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.customizer.BindBean;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;

import java.util.List;

/**
 * @author Mauro Pozzana
 */
public interface ModuleCalculationConfigParamDAO extends IGenericDAO<ModuleCalculationConfigParamNTT, Void> {

	@Override
	@SqlQuery("not implemented")
	Void nextSequenceVal();

	@SqlUpdate("INSERT INTO apps_module_calculation_config_params " +
			"(module_calculation_config_id, parameter_name, parameter_value) " +
			"VALUES(:module_calculation_config_id, :parameter_name, :parameter_value)")
	void insert(@BindBean ModuleCalculationConfigParamNTT formGroup);

	@SqlQuery("SELECT p.module_calculation_config_id," +
			"p.parameter_name, " +
			"p.parameter_value " +
			"FROM apps_module_calculation_config_params p " +
			"WHERE p.module_calculation_config_id=:module_calculation_config_id and p.parameter_name = :parameter_name " +
			"and :tenant_id in " +
			"(SELECT s.tenant_id " +
			" FROM apps_sectors s INNER JOIN apps_modules m ON s.id = m.sector_id" +
			"      INNER JOIN apps_module_calculation_configs c ON m.id = c.module_id " +
			" WHERE p.module_calculation_config_id = c.id" +
			" and §current_timestamp§ between m.dt_insert and m.dt_delete)")
	@RegisterBeanMapper(ModuleCalculationConfigParamNTT.class)
	List<ModuleCalculationConfigParamNTT> findById(@Bind("tenant_id") String tenantId, @Bind("module_calculation_config_id") Long moduleFormConfigId,
			@Bind("parameter_name") String parameterName);

	@SqlQuery("SELECT p.module_calculation_config_id," +
			"p.parameter_name, " +
			"p.parameter_value " +
			"FROM apps_module_calculation_config_params p " +
			"WHERE p.module_calculation_config_id=:module_calculation_config_id AND p.parameter_name = :parameter_name")
	@RegisterBeanMapper(ModuleCalculationConfigParamNTT.class)
	List<ModuleCalculationConfigParamNTT> findById(@Bind("module_calculation_config_id") Long moduleFormConfigId,
			@Bind("parameter_name") String parameterName);

	@SqlQuery("SELECT p.module_calculation_config_id," +
			"p.parameter_name, " +
			"p.parameter_value " +
			"FROM apps_module_calculation_config_params p " +
			"WHERE p.module_calculation_config_id=:module_calculation_config_id AND " +
			":tenant_id in " +
			"(SELECT s.tenant_id " +
			" FROM apps_sectors s INNER JOIN apps_modules m ON s.id = m.sector_id" +
			"      INNER JOIN apps_module_calculation_configs c ON m.id = c.module_id " +
			" WHERE p.module_calculation_config_id = c.id" +
			" and §current_timestamp§ between m.dt_insert and m.dt_delete)")
	@RegisterBeanMapper(ModuleCalculationConfigParamNTT.class)
	List<ModuleCalculationConfigParamNTT> find(@Bind("tenant_id") String tenantId, @Bind("module_calculation_config_id") Long moduleFormConfigId);

	@SqlUpdate("UPDATE apps_module_calculation_config_params SET " +
			"parameter_value=:parameter_value " +
			"where module_calculation_config_id=:module_calculation_config_id and parameter_name=:parameter_name")
	void update(@BindBean ModuleCalculationConfigParamNTT sector);

	@SqlUpdate("DELETE FROM apps_module_calculation_config_params p " +
			"WHERE p.module_calculation_config_id=:module_calculation_config_id AND p.parameter_name = :parameter_name")
	void deleteById(@Bind("module_calculation_config_id") Long moduleFormConfigId,
			@Bind("parameter_name") String parameterName);

	@SqlUpdate("DELETE FROM apps_module_calculation_config_params p " +
			"WHERE p.module_calculation_config_id=:module_calculation_config_id")
	void deleteByModuleCalculationConfigId(@Bind("module_calculation_config_id") Long moduleFormConfigId);

}
