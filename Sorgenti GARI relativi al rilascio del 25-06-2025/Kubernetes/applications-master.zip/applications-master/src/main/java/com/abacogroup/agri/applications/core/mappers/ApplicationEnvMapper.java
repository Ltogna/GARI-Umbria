package com.abacogroup.agri.applications.core.mappers;

import com.abacogroup.agri.applications.core.model.dto.ApplicationEnvDTO;
import com.abacogroup.agri.applications.db.ntt.ApplicationEnvNTT;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

/**
 * The interface Application env mapper.
 * @author Carlo Sindico
 */
@Mapper
public interface ApplicationEnvMapper extends EntityMapper<ApplicationEnvDTO, ApplicationEnvNTT> {

    ApplicationEnvMapper INSTANCE = Mappers.getMapper(ApplicationEnvMapper.class);

    @InheritInverseConfiguration()
    ApplicationEnvDTO entityToDto(ApplicationEnvNTT entity);

    @Mapping(source = "tenant", target = "tenant_id")
    @Mapping(source = "key", target = "key_")
    @Mapping(source = "value", target = "value")
    @Mapping(source = "flClient", target = "fl_client")
    ApplicationEnvNTT dtoToEntity(ApplicationEnvDTO dto);

}
