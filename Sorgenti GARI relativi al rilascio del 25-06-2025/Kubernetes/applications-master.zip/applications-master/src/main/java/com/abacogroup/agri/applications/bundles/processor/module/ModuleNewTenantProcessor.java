package com.abacogroup.agri.applications.bundles.processor.module;

import static com.abacogroup.agri.applications.bundles.BundleConstants.TENANT_TEMPLATE_CODE;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.jdbi.v3.core.Jdbi;

import com.abacogroup.agri.applications.bundles.model.I18nPair;
import com.abacogroup.agri.applications.bundles.model.form.BundleFormCatalogInDTO;
import com.abacogroup.agri.applications.bundles.model.form.BundleFormGroupInDTO;
import com.abacogroup.agri.applications.bundles.model.form.BundleFormsInDTO;
import com.abacogroup.agri.applications.bundles.model.form.BundleModuleCalculationInDTO;
import com.abacogroup.agri.applications.bundles.model.form.BundleModuleFormConfigsInDTO;
import com.abacogroup.agri.applications.bundles.model.form.BundleModulePrintInDTO;
import com.abacogroup.agri.applications.bundles.model.form.BundleModuleProfileInDTO;
import com.abacogroup.agri.applications.bundles.model.module.BundleModuleInDTO;
import com.abacogroup.agri.applications.bundles.model.module.BundleModulesMessage;
import com.abacogroup.agri.applications.core.exceptions.ObjectNotFoundException;
import com.abacogroup.agri.applications.core.exceptions.ObjectNotFoundRuntimeException;
import com.abacogroup.agri.applications.core.model.dto.FormCatalogDTO;
import com.abacogroup.agri.applications.core.model.dto.FormGroupDTO;
import com.abacogroup.agri.applications.core.model.dto.ModuleCalculationConfigParamDTO;
import com.abacogroup.agri.applications.core.model.dto.ModuleCalculationConfigProfileDTO;
import com.abacogroup.agri.applications.core.model.dto.ModuleCalculationConfigsDTO;
import com.abacogroup.agri.applications.core.model.dto.ModuleFormConfigParamDTO;
import com.abacogroup.agri.applications.core.model.dto.ModuleFormConfigProfileDTO;
import com.abacogroup.agri.applications.core.model.dto.ModuleFormConfigsDTO;
import com.abacogroup.agri.applications.core.model.dto.ModulePrintConfigParamDTO;
import com.abacogroup.agri.applications.core.model.dto.ModulePrintConfigProfileDTO;
import com.abacogroup.agri.applications.core.model.dto.ModulePrintConfigsDTO;
import com.abacogroup.agri.applications.core.model.dto.ModuleWithDetailDTO;
import com.abacogroup.agri.applications.core.services.crud.FormCatalogsCrudService;
import com.abacogroup.agri.applications.core.services.crud.FormGroupsCrudService;
import com.abacogroup.agri.applications.core.services.crud.ModuleCalculationConfigParamCrudService;
import com.abacogroup.agri.applications.core.services.crud.ModuleCalculationConfigProfilesCrudService;
import com.abacogroup.agri.applications.core.services.crud.ModuleCalculationConfigsCrudService;
import com.abacogroup.agri.applications.core.services.crud.ModuleCrudService;
import com.abacogroup.agri.applications.core.services.crud.ModuleFormConfigParamCrudService;
import com.abacogroup.agri.applications.core.services.crud.ModuleFormConfigProfilesCrudService;
import com.abacogroup.agri.applications.core.services.crud.ModuleFormConfigsCrudService;
import com.abacogroup.agri.applications.core.services.crud.ModulePrintConfigParamCrudService;
import com.abacogroup.agri.applications.core.services.crud.ModulePrintConfigProfilesCrudService;
import com.abacogroup.agri.applications.core.services.crud.ModulePrintConfigsCrudService;
import com.abacogroup.agri.applications.core.services.crud.ModuleProfilesCrudService;
import com.abacogroup.agri.applications.core.services.crud.SectorsCrudService;
import com.abacogroup.agri.applications.db.ntt.applications.RsI18N;
import com.abacogroup.bundles.listener.tenant.TenantMessage;
import com.abacogroup.bundles.listener.tenant.TenantMessageProcessor;

import lombok.extern.slf4j.Slf4j;

/**
 * @author Alexandru Paraschiv
 * @author Gennaro Tamburrelli
 */
@Slf4j
public class ModuleNewTenantProcessor implements TenantMessageProcessor {

	protected final Jdbi jdbi;
	protected final ModulesBundleWorker modulesBundleWorker;

	public ModuleNewTenantProcessor(Jdbi jdbi, ModulesBundleWorker modulesBundleWorker) {
		this.jdbi = jdbi;
		this.modulesBundleWorker = modulesBundleWorker;
	}

	@Override
	public void onMessage(TenantMessage message) {
		jdbi.useTransaction(handle -> {
			log.info("ModuleNewTenantProcessor got new tenant {}", message.getTenantId());
			this.checkAndInsertModules(message.getTenantId());
			log.info("ModuleNewTenantProcessor end working with new tenant {}", message.getTenantId());
		});
	}

	private void checkAndInsertModules(String tenantId) {
		log.info("ModuleNewTenantProcessor check and insert new tenant {}", tenantId);
		ModuleCrudService moduleCrudService = modulesBundleWorker.exposeModuleCrudService();
		SectorsCrudService sectorCrudService = modulesBundleWorker.exposeSectorsCrudService();
		FormCatalogsCrudService formCatalogsCrudService = modulesBundleWorker.exposeFormCatalogsCrudService();
		FormGroupsCrudService formGroupsCrudService = modulesBundleWorker.exposeFormGroupsCrudService();
		ModuleFormConfigsCrudService moduleFormConfigsCrudService = modulesBundleWorker.exposeModuleFormConfigsCrudService();
		ModulePrintConfigsCrudService modulePrintConfigsCrudService = modulesBundleWorker.exposeModulePrintConfigsCrudService();
		ModuleCalculationConfigsCrudService moduleCalculationConfigsCrudService = modulesBundleWorker.exposeModuleCalculationConfigsCrudService();

		List<ModuleWithDetailDTO> asteriskModules = moduleCrudService.findModulesWithDetail(TENANT_TEMPLATE_CODE);

		modulesBundleWorker.insertBundleModules(tenantId,
				BundleModulesMessage.builder()
						.modules(asteriskModules
								.stream()
								.map(module -> {
									List<ModuleFormConfigsDTO> asteriskModuleFormConfigs = moduleFormConfigsCrudService
											.findAllModuleFormConfigs(TENANT_TEMPLATE_CODE, module.getModuleId());
									List<FormCatalogDTO> asteriskFormCatalogs = formCatalogsCrudService.findAllFormCatalogs(TENANT_TEMPLATE_CODE,
											asteriskModuleFormConfigs
													.stream()
													.map(ModuleFormConfigsDTO::getFormId)
													.collect(Collectors.toList()));
									List<FormGroupDTO> asteriskFormGroups = formGroupsCrudService.findAllFormGroupsWithNoParent(TENANT_TEMPLATE_CODE,
											asteriskModuleFormConfigs
													.stream()
													.map(ModuleFormConfigsDTO::getFormGroupId)
													.collect(Collectors.toList()));

									List<ModulePrintConfigsDTO> asteriskModulePrintConfigs = modulePrintConfigsCrudService
											.findAllModulePrintConfigs(TENANT_TEMPLATE_CODE, module.getModuleId());

									List<ModuleCalculationConfigsDTO> asteriskModuleCalculationConfigs = moduleCalculationConfigsCrudService
											.findAllModuleCalculationConfigs(TENANT_TEMPLATE_CODE, module.getModuleId());
									try {
										//setting module
										return buildBundleModuleInDTO(sectorCrudService, formCatalogsCrudService, formGroupsCrudService, module,
												asteriskModuleFormConfigs, asteriskFormCatalogs, asteriskFormGroups, asteriskModulePrintConfigs,
												asteriskModuleCalculationConfigs);
									} catch (ObjectNotFoundException e) {
										throw new ObjectNotFoundRuntimeException(e.getMessage());
									}
								})
								.collect(Collectors.toList()))
						.build());
	}

	private BundleModuleInDTO buildBundleModuleInDTO(SectorsCrudService sectorCrudService, FormCatalogsCrudService formCatalogsCrudService,
			FormGroupsCrudService formGroupsCrudService, ModuleWithDetailDTO module, List<ModuleFormConfigsDTO> asteriskModuleFormConfigs,
			List<FormCatalogDTO> asteriskFormCatalogs, List<FormGroupDTO> asteriskFormGroups, List<ModulePrintConfigsDTO> asteriskModulePrintConfigs,
			List<ModuleCalculationConfigsDTO> asteriskModuleCalculationConfigs) throws ObjectNotFoundException {
		return BundleModuleInDTO.builder()
				.moduleCode(module.getModuleCode())
				.workflowCode(module.getWorkflowCode())
				.annuality(module.getAnnuality())
				.contextFunction(module.getContextFunction())
				.forceReadOnlyContextFunction(module.getForceReadOnlyContextFunction())
				.sectorCode(sectorCrudService.findById(TENANT_TEMPLATE_CODE, module.getSectorId()).getSectorCode())
				.dtValidityStart(module.getDtValidityStart())
				.dtValidityEnd(module.getDtValidityEnd())
				.i18n(mapModuleI18NList(TENANT_TEMPLATE_CODE, module.getModuleCode()))
				.flAmendModule(module.getFlAmendModule())
				//setting forms
				.forms(buildBundleFormsInDTO(formCatalogsCrudService, formGroupsCrudService, module, asteriskModuleFormConfigs,
						asteriskFormCatalogs, asteriskFormGroups))
				.moduleProfiles(
						this.mapModuleProfiles(TENANT_TEMPLATE_CODE, module.getModuleId()))
				.modulePrints(asteriskModulePrintConfigs.stream()
						.map(printConfig -> {
							return buildModulePrintInDTO(printConfig);
						})
						.collect(Collectors.toList()))
				.moduleCalculations(asteriskModuleCalculationConfigs.stream()
						.map(calculationConfig -> {
							return buildModuleCalculationInDTO(calculationConfig);
						})
						.collect(Collectors.toList()))
				.build();
	}

	private BundleFormsInDTO buildBundleFormsInDTO(FormCatalogsCrudService formCatalogsCrudService, FormGroupsCrudService formGroupsCrudService,
			ModuleWithDetailDTO module, List<ModuleFormConfigsDTO> asteriskModuleFormConfigs, List<FormCatalogDTO> asteriskFormCatalogs,
			List<FormGroupDTO> asteriskFormGroups) {
		return BundleFormsInDTO.builder()
				//setting form catalogs
				.formCatalogs(asteriskFormCatalogs
						.stream()
						.map(formCatalogDTO -> buildBundleFormCatalogInDTO(formCatalogDTO)).collect(Collectors.toList()))
				//setting form groups
				.formGroups(asteriskFormGroups
						.stream()
						.map(formGroup -> buildBundleFromGroupInDTO(formGroup)).collect(Collectors.toList()))
				//setting module form configs
				.moduleFormConfigs(asteriskModuleFormConfigs
						.stream()
						.map(moduleFormConfigs -> {
							try {
								return buildModuleFormConfigsInDTO(formCatalogsCrudService, formGroupsCrudService,
										module, moduleFormConfigs);
							} catch (ObjectNotFoundException e) {
								throw new ObjectNotFoundRuntimeException(e.getMessage());
							}
						}).collect(Collectors.toList()))
				.build();
	}

	private BundleFormGroupInDTO buildBundleFromGroupInDTO(FormGroupDTO formGroup) {
		return BundleFormGroupInDTO.builder()
				.formGroupCode(formGroup.getFormGroupCode())
				.formGroupChildren(mapFormGroupChilds(TENANT_TEMPLATE_CODE, formGroup.getId()))
				.i18n(mapFormGroupI18NList(TENANT_TEMPLATE_CODE, formGroup.getFormGroupCode()))
				.build();
	}

	private BundleFormCatalogInDTO buildBundleFormCatalogInDTO(FormCatalogDTO formCatalogDTO) {
		return BundleFormCatalogInDTO.builder()
				.formCode(formCatalogDTO.getFormCode())
				.softwareUrl(formCatalogDTO.getSoftwareUrl())
				.routerUrl(formCatalogDTO.getRouterUrl())
				.i18n(mapFormCatalogI18NList(TENANT_TEMPLATE_CODE, formCatalogDTO.getFormCode()))
				.build();
	}

	private BundleModuleCalculationInDTO buildModuleCalculationInDTO(ModuleCalculationConfigsDTO calculationConfig) {
		return BundleModuleCalculationInDTO.builder()
				.calculationCode(calculationConfig.getCalculationCode())
				.processStatus(calculationConfig.getProcessStatus())
				.sortOrder(calculationConfig.getSortOrder())
				.contextFunction(calculationConfig.getContextFunction())
				.params(mapBundleModuleCalculationConfigsParams(TENANT_TEMPLATE_CODE, calculationConfig.getId()))
				.requiredProfiles(mapModuleCalculationConfigProfiles(TENANT_TEMPLATE_CODE, calculationConfig.getId()))
				.i18n(mapCalculationConfigI18NList(TENANT_TEMPLATE_CODE, calculationConfig.getCalculationCode()))
				.build();
	}

	private BundleModulePrintInDTO buildModulePrintInDTO(ModulePrintConfigsDTO printConfig) {
		return BundleModulePrintInDTO.builder()
				.printCode(printConfig.getPrintCode())
				.processStatus(printConfig.getProcessStatus())
				.sortOrder(printConfig.getSortOrder())
				.contextFunction(printConfig.getContextFunction())
				.params(mapBundleModulePrintConfigsParams(TENANT_TEMPLATE_CODE, printConfig.getId()))
				.requiredProfiles(mapModulePrintConfigProfiles(TENANT_TEMPLATE_CODE, printConfig.getId()))
				.i18n(mapPrintConfigI18NList(TENANT_TEMPLATE_CODE, printConfig.getPrintCode(), printConfig.getProcessStatus()))
				.build();
	}

	private BundleModuleFormConfigsInDTO buildModuleFormConfigsInDTO(FormCatalogsCrudService formCatalogsCrudService,
			FormGroupsCrudService formGroupsCrudService, ModuleWithDetailDTO module, ModuleFormConfigsDTO moduleFormConfigs) throws ObjectNotFoundException {
		return BundleModuleFormConfigsInDTO.builder()
				.moduleCode(module.getModuleCode())
				.formCode(formCatalogsCrudService
						.findById(TENANT_TEMPLATE_CODE, moduleFormConfigs.getFormId())
						.getFormCode())
				.formGroupCode(formGroupsCrudService
						.findById(TENANT_TEMPLATE_CODE, moduleFormConfigs.getFormGroupId())
						.getFormGroupCode())
				.processStatus(moduleFormConfigs.getProcessStatus())
				.contextFunction(moduleFormConfigs.getContextFunction())
				.forceReadOnlyContextFunction(moduleFormConfigs.getForceReadOnlyContextFunction())
				.sortOrder(moduleFormConfigs.getSortOrder())
				.params(this.mapBundleModuleFormConfigsParams(TENANT_TEMPLATE_CODE,
						moduleFormConfigs.getId()))
				//setting profile codes
				.requiredProfiles(
						this.mapModuleFormConfigProfiles(TENANT_TEMPLATE_CODE,
								moduleFormConfigs.getId()))
				.flReadOnly(moduleFormConfigs.getFlReadOnly())
				.compileStatusIdentifier(moduleFormConfigs.getCompileStatusIdentifier())
				.build();
	}

	private List<BundleModuleProfileInDTO> mapModuleProfiles(String tenantId, Long moduleId) {
		ModuleProfilesCrudService moduleProfilesCrudService = modulesBundleWorker.exposeModuleProfilesCrudService();

		return moduleProfilesCrudService.find(tenantId, moduleId)
				.stream()
				.map(p -> BundleModuleProfileInDTO.builder()
						.prfCode(p.getProfileCode())
						.i18n(this.mapModuleProfileI18NList(tenantId, p.getProfileCode()))
						.labelExposed(p.getLabelExposed())
						.build()).collect(Collectors.toList());
	}

	private List<String> mapModulePrintConfigProfiles(String tenantId, Long modulePrintConfigId) {
		ModulePrintConfigProfilesCrudService moduleFormConfigProfilesCrudService = modulesBundleWorker.exposeModulePrintConfigProfilesCrudService();
		return moduleFormConfigProfilesCrudService.find(tenantId, modulePrintConfigId)
				.stream()
				.map(ModulePrintConfigProfileDTO::getRequiredProfileCode)
				.collect(Collectors.toList());
	}

	private List<String> mapModuleCalculationConfigProfiles(String tenantId, Long moduleCalculationConfigId) {
		ModuleCalculationConfigProfilesCrudService moduleFormConfigProfilesCrudService = modulesBundleWorker.exposeModuleCalculationConfigProfilesCrudService();
		return moduleFormConfigProfilesCrudService.find(tenantId, moduleCalculationConfigId)
				.stream()
				.map(ModuleCalculationConfigProfileDTO::getRequiredProfileCode)
				.collect(Collectors.toList());
	}

	private List<String> mapModuleFormConfigProfiles(String tenantId, Long moduleFormConfigId) {
		ModuleFormConfigProfilesCrudService moduleFormConfigProfilesCrudService = modulesBundleWorker.exposeModuleFormConfigProfilesCrudService();
		return moduleFormConfigProfilesCrudService.find(tenantId, moduleFormConfigId)
				.stream()
				.map(ModuleFormConfigProfileDTO::getRequiredProfileCode)
				.collect(Collectors.toList());
	}

	private List<I18nPair> mapModuleI18NList(String tenantId, String sectorCode) {
		var mapLang = modulesBundleWorker.exposeModuleCrudService()
				.getAllModuleI18NByTenantAndCode(tenantId, sectorCode)
				.stream()
				.collect(Collectors.groupingBy(RsI18N::getLang));
		List<I18nPair> records = new ArrayList<>();
		mapLang.forEach((lang, item) -> records.add(I18nPair.builder()
				.lang(lang)
				.description(extractI18NText(item, ModuleCrudService.MODULE_I18N.MODULE_CODE.getCode()))
				.build()));

		return records;
	}

	private List<I18nPair> mapFormCatalogI18NList(String tenantId, String formCode) {
		var mapLang = modulesBundleWorker.exposeFormCatalogsCrudService()
				.getAllFormCatalogI18NByTenantAndCode(tenantId, formCode)
				.stream()
				.collect(Collectors.groupingBy(RsI18N::getLang));
		List<I18nPair> records = new ArrayList<>();
		mapLang.forEach((lang, item) -> records.add(I18nPair.builder()
				.lang(lang)
				.description(extractI18NText(item, FormCatalogsCrudService.FORM_CATALOG_I18N.FORM_CODE.getCode()))
				.build()));

		return records;
	}

	private List<I18nPair> mapFormGroupI18NList(String tenantId, String formCode) {
		var mapLang = modulesBundleWorker.exposeFormGroupsCrudService()
				.getAllFormGroupI18NByTenantAndCode(tenantId, formCode)
				.stream()
				.collect(Collectors.groupingBy(RsI18N::getLang));
		List<I18nPair> records = new ArrayList<>();
		mapLang.forEach((lang, item) -> records.add(I18nPair.builder()
				.lang(lang)
				.description(extractI18NText(item, FormGroupsCrudService.FORM_GROUPS_I18N.FORM_GROUP_CODE.getCode()))
				.build()));

		return records;
	}

	private List<I18nPair> mapPrintConfigI18NList(String tenantId, String printCode, String processStatus) {	
		
		final String fieldName = StringUtils.isNotBlank(processStatus) ? ModulePrintConfigsCrudService.PRINT_CODE_I18N.PROFILE_CODE_WITH_STATUS.getCode() : ModulePrintConfigsCrudService.PRINT_CODE_I18N.PROFILE_CODE.getCode();
		String i18nCode = StringUtils.isNotBlank(processStatus) ? printCode + ":" + processStatus : printCode;
		
		var mapLang = modulesBundleWorker.exposeModulePrintConfigsCrudService()
				.getAllPrintCodeI18NByTenantAndCode(tenantId, i18nCode)
				.stream()
				.collect(Collectors.groupingBy(RsI18N::getLang));
		List<I18nPair> records = new ArrayList<>();
		mapLang.forEach((lang, item) -> records.add(I18nPair.builder()
				.lang(lang)
				.description(extractI18NText(item, fieldName))
				.build()));

		return records;
	}
	
	private List<I18nPair> mapCalculationConfigI18NList(String tenantId, String calculationCode) {
		var mapLang = modulesBundleWorker.exposeModuleCalculationConfigsCrudService()
				.getAllCalculationCodeI18NByTenantAndCode(tenantId, calculationCode)
				.stream()
				.collect(Collectors.groupingBy(RsI18N::getLang));
		List<I18nPair> records = new ArrayList<>();
		mapLang.forEach((lang, item) -> records.add(I18nPair.builder()
				.lang(lang)
				.description(extractI18NText(item, ModuleCalculationConfigsCrudService.CALCULATION_CODE_I18N.PROFILE_CODE.getCode()))
				.build()));

		return records;
	}

	private List<I18nPair> mapModuleProfileI18NList(String tenantId, String requiredProfileCode) {
		var mapLang = modulesBundleWorker.exposeModuleProfilesCrudService()
				.getAllModuleProfileI18NByTenantAndCode(tenantId, requiredProfileCode)
				.stream()
				.collect(Collectors.groupingBy(RsI18N::getLang));
		List<I18nPair> records = new ArrayList<>();
		mapLang.forEach((lang, item) -> records.add(I18nPair.builder()
				.lang(lang)
				.description(extractI18NText(item, ModuleProfilesCrudService.APPLICATION_PROFILES_I18N.PROFILE_CODE.getCode()))
				.build()));

		return records;
	}

	private String extractI18NText(List<RsI18N> items, String field) {
		return items
				.stream()
				.filter(x -> field.equals(x.getField_name()))
				.findFirst()
				.map(RsI18N::getI18n_text)
				.orElse(null);
	}

	private Map<String, String> mapBundleModuleFormConfigsParams(String tenantId, Long moduleFormConfigsId) {
		ModuleFormConfigParamCrudService moduleFormConfigParamCrudService = modulesBundleWorker.exposeModuleFormConfigParamCrudService();

		List<ModuleFormConfigParamDTO> moduleFormConfigParams = moduleFormConfigParamCrudService.find(tenantId, moduleFormConfigsId);
		Map<String, String> params = new HashMap<>();
		moduleFormConfigParams.forEach(moduleFormConfigParam -> {
			params.put(moduleFormConfigParam.getParameterName(), moduleFormConfigParam.getParameterValue());
		});
		return params;
	}

	private Map<String, String> mapBundleModulePrintConfigsParams(String tenantId, Long modulePrintConfigsId) {
		ModulePrintConfigParamCrudService modulePrintConfigParamCrudService = modulesBundleWorker.exposeModulePrintConfigParamCrudService();

		List<ModulePrintConfigParamDTO> modulePrintConfigParams = modulePrintConfigParamCrudService.find(tenantId, modulePrintConfigsId);
		Map<String, String> params = new HashMap<>();
		modulePrintConfigParams.forEach(moduleFormConfigParam -> {
			params.put(moduleFormConfigParam.getParameterName(), moduleFormConfigParam.getParameterValue());
		});
		return params;
	}

	private Map<String, String> mapBundleModuleCalculationConfigsParams(String tenantId, Long moduleCalculationConfigsId) {
		ModuleCalculationConfigParamCrudService moduleCalculationConfigParamCrudService = modulesBundleWorker.exposeModuleCalculationConfigParamCrudService();

		List<ModuleCalculationConfigParamDTO> moduleCalculationConfigParams = moduleCalculationConfigParamCrudService.find(tenantId, moduleCalculationConfigsId);
		Map<String, String> params = new HashMap<>();
		moduleCalculationConfigParams.forEach(moduleFormConfigParam -> {
			params.put(moduleFormConfigParam.getParameterName(), moduleFormConfigParam.getParameterValue());
		});
		return params;
	}

	private List<BundleFormGroupInDTO> mapFormGroupChilds(String tenantId, Long parentGroupId) {
		if (Optional.ofNullable(parentGroupId).isEmpty()) {
			return Collections.emptyList();
		}
		FormGroupsCrudService formGroupsCrudService = modulesBundleWorker.exposeFormGroupsCrudService();
		return formGroupsCrudService.findFormGroupsByParentId(tenantId, parentGroupId) // children
				.stream()
				.map(child -> {
					try {
						return BundleFormGroupInDTO.builder()
								.formGroupCode(child.getFormGroupCode())
								.i18n(mapFormGroupI18NList(tenantId, child.getFormGroupCode()))
								.formGroupChildren(
										this.mapFormGroupChilds(tenantId,
												formGroupsCrudService.findFormGroupByCode(tenantId, child.getFormGroupCode()).getId()))
								.build();
					} catch (ObjectNotFoundException e) {
						throw new ObjectNotFoundRuntimeException(e.getMessage());
					}
				}).collect(Collectors.toList());
	}
}
