package com.abacogroup.agri.applications.core.services.embededqueue.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author Gennaro Tamburrelli
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class ApplicationsEventModel {

    private Long applicationId;
    private String userId;
    private String eventType;
    private Object payload;
}
