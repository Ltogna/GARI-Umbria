package com.abacogroup.agri.applications.core.mappers;

import com.abacogroup.agri.applications.core.model.AbsoluteDate;

import java.time.LocalDate;

public class AbsoluteDateMapper {

	public String asString(AbsoluteDate date) {
		if (date == null)
			return null;

		try {
			return date.toString();
		} catch (Exception e) {
		}

		return null;
	}

	public LocalDate asLocalDate(AbsoluteDate date) {
		if (date == null) {
			return null;
		}
		try {
			return date.get();
		} catch (Exception e) {
		}
		return null;
	}

	public AbsoluteDate asAbsoluteDate(String date) {
		if (date == null || date.isBlank())
			return null;

		try {
			return new AbsoluteDate(date);
		} catch (Exception e) {
		}
		return null;
	}

	public AbsoluteDate asAbsoluteDate(LocalDate date) {
		if (date == null)
			return null;

		try {
			return new AbsoluteDate(date);
		} catch (Exception e) {
		}
		return null;
	}

}
