package com.abacogroup.agri.applications.core.services.workflow.sdkimpl;

import com.abacogroup.agri.applications.core.services.AnomaliesService;
import com.abacogroup.agri.applications.core.services.crud.ApplicationsCrudService;
import com.abacogroup.agri.applications.core.services.crud.ModuleCrudService;
import com.abacogroup.applicationworkflowsdk.service.CheckForMultipleApplications;

/**
 * @author Gennaro Tamburrelli
 */
public class CheckForMultipleApplicationImpl implements CheckForMultipleApplications {

	private final AnomaliesService anomaliesService;
	private final ApplicationsCrudService applicationsCrudService;
	private final ModuleCrudService moduleCrudService;

	public CheckForMultipleApplicationImpl(AnomaliesService anomaliesService,
			ApplicationsCrudService applicationsCrudService,
			ModuleCrudService moduleCrudService) {
		this.anomaliesService = anomaliesService;
		this.applicationsCrudService = applicationsCrudService;
		this.moduleCrudService = moduleCrudService;
	}

	@Override
	public boolean checkForMultipleApplications(String tenant, Long applicationId, Long partyId, Integer referredYear) {
		var app = applicationsCrudService.findWithDetailsByApplicationId(tenant, applicationId);
		var moduleDto = moduleCrudService.findById(app.getModuleId());
		if (moduleDto.isPresent()) {
			return anomaliesService.checkForMultipleApplication(tenant, moduleDto.get(), partyId, referredYear, applicationId).isEmpty();
		} else {
			return false;
		}
	}
}
