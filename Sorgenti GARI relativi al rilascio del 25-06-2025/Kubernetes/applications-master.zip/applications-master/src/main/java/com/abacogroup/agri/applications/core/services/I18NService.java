package com.abacogroup.agri.applications.core.services;

import com.abacogroup.agri.applications.db.dao.I18NDAO;
import com.abacogroup.agri.applications.db.ntt.applications.RsI18N;

import java.util.List;

/**
 * @author Gennaro Tamburrelli
 */
public class I18NService {

	private final I18NDAO i18NDAO;

	public I18NService(I18NDAO i18NDAO) {
		this.i18NDAO = i18NDAO;
	}

	public void insertI18N(String tenant, String table, String fieldName, String lang, String typeCode, String i18nText) {
		this.i18NDAO.insertI18N(tenant, table, fieldName, typeCode, lang, i18nText);
	}

	public void deleteI18N(String tenant, String table, String fieldName, String typeCode, String lang) {
		this.i18NDAO.deleteI18N(tenant, table, fieldName, typeCode, lang);
	}

	public RsI18N getI18NByLang(String tenant, String table, String fieldName, String lang, String typeCode) {
		return this.i18NDAO.getI18NByLang(tenant, table, fieldName, typeCode, lang)
				.stream()
				.findFirst()
				.orElse(null);
	}

	public List<RsI18N> getAllI18NbyCode(String tenant, String table, String typeCode) {
		return this.i18NDAO.getAllI18N(tenant, table, typeCode);
	}

	public boolean isI18NPresent(String tenant, String table, String fieldName, String typeCode, String lang, String text) {
		return !this.i18NDAO.getI18NByAllFields(tenant, table, fieldName, typeCode, lang, text).isEmpty();
	}
}
