package com.abacogroup.agri.applications.bundles.model.form;

import java.util.List;

import com.abacogroup.agri.applications.bundles.model.I18nPair;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author Alexandru Paraschiv
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class BundleModuleProfileInDTO {
	private String prfCode;
	private List<I18nPair> i18n;
	private Boolean labelExposed;

}
