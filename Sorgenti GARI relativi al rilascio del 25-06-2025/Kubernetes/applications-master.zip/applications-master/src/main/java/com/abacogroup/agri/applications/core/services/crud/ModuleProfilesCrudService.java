package com.abacogroup.agri.applications.core.services.crud;

import com.abacogroup.agri.applications.core.exceptions.ObjectNotFoundException;
import com.abacogroup.agri.applications.core.mappers.ModuleProfileMapper;
import com.abacogroup.agri.applications.core.model.AbsoluteDate;
import com.abacogroup.agri.applications.core.services.I18NService;
import com.abacogroup.agri.applications.db.dao.ModuleProfileDAO;
import com.abacogroup.agri.applications.db.ntt.ModuleProfileNTT;
import com.abacogroup.agri.applications.db.ntt.applications.RsI18N;
import com.abacogroup.applicationworkflowsdk.model.io.output.ModuleProfileDTO;
import com.abacogroup.jaxrsutils.filter.MDCPreFilter;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.MDC;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import static com.abacogroup.agri.applications.utils.PagingParamsFactory.DEFAULT_PAGE_SIZE;

/**
 * @author Gennaro Tamburrelli
 */
@Slf4j
public class ModuleProfilesCrudService
		extends AbstractHistoricizationFieldsCrudService<ModuleProfileNTT, Long, ModuleProfileDTO, ModuleProfileMapper, Void> {

	public static final String I18N_APPLICATION_PROFILES_TABLE = "apps_module_profiles";
	private final I18NService i18NService;

	public ModuleProfilesCrudService(ModuleProfileDAO dao, ModuleProfileMapper mapper,
			I18NService i18NService) {
		super(dao, mapper);
		this.i18NService = i18NService;
	}

	@Override protected boolean hasPrimaryKey() {
		return true;
	}

	@Override protected Void retrieveCustomKeyByResultSet(ModuleProfileNTT rs) {
		return null;
	}

	@Override protected ModuleProfileNTT adjustR(ModuleProfileNTT rs) throws Exception {
		return rs;
	}

	@Override protected Optional<ModuleProfileNTT> findRsByCustomKey(Void customKey) {
		return Optional.empty();
	}

	public ModuleProfileDTO insert(ModuleProfileDTO in, String username) {
		log.info("Invoking insert with params in: {} username: {}", in, username);
		return this.insert(in, username, null, this.dao.getCurrentTimestamp());
	}

	public ModuleProfileDTO update(Long key, ModuleProfileDTO in, String username) {
		log.info("Invoking update with params key: {} in: {} username: {}", key, in, username);
		return this.update(key, in, username, null);
	}

	public void delete(Long key, String username) {
		log.info("Invoking delete with params key: {} username: {}", key, username);
		this.delete(key, username, null);
	}

	public void deleteByModuleId(Long moduleId, String username) {
		log.info("Invoking delete with params moduleId: {} username: {}", moduleId, username);
		((ModuleProfileDAO) dao).logicallyDeleteByModuleId(moduleId, username, LocalDateTime.now());
	}

	public void insertModuleProfileI18N(String tenant, String code, String lang, String description) {
		this.i18NService.insertI18N(tenant, I18N_APPLICATION_PROFILES_TABLE, APPLICATION_PROFILES_I18N.PROFILE_CODE.code, lang, code, description);
	}

	public boolean verifyI18NIsPresent(String tenant, String code, String lang, String description) {
		return this.i18NService.isI18NPresent(tenant, I18N_APPLICATION_PROFILES_TABLE, APPLICATION_PROFILES_I18N.PROFILE_CODE.code, code, lang, description);
	}

	public void deleteModuleProfileI18N(String tenant, String code, String lang) {
		this.i18NService.deleteI18N(tenant, I18N_APPLICATION_PROFILES_TABLE, APPLICATION_PROFILES_I18N.PROFILE_CODE.code, code, lang);
	}

	public List<RsI18N> getAllModuleProfileI18NByTenantAndCode(String tenant, String code) {
		return this.i18NService.getAllI18NbyCode(tenant, I18N_APPLICATION_PROFILES_TABLE, code);
	}

	public ModuleProfileDTO findById(Long id) throws ObjectNotFoundException {
		log.info("Invoking find by  with params key: {}", id);
		return this.findOutDtoByPrimaryKey(id);
	}

	/**
	 * get all active profiles by sector code and module code
	 *
	 * @param tenant     current tenant
	 * @param sectorCode the sector code
	 * @param moduleCode the module code
	 * @return the profile list
	 */
	public InfiniteListResults<ModuleProfileDTO> find(String tenant, String sectorCode, String moduleCode, AbsoluteDate pointInTime, String nextKey) {
		log.info("Invoking find with params tenant: {} sectorCode: {} moduleCode: {} pointInTime: {}", tenant, sectorCode, moduleCode, pointInTime);
		return returnInfiniteResults(
				this.dao.infinite(() -> ((ModuleProfileDAO) this.dao).find(tenant, sectorCode, moduleCode, pointInTime, MDC.get(MDCPreFilter.LOCALE)),
						nextKey,
						DEFAULT_PAGE_SIZE),
				mapper::entityToDto);
	}

	/**
	 * get all profiles by module id
	 *
	 * @param tenant   current tenant
	 * @param moduleId the application's code
	 * @return the profiles list
	 */
	public List<ModuleProfileDTO> find(String tenant, Long moduleId) {
		log.info("Invoking find with params tenant: {} moduleId: {}", tenant, moduleId);
		return returnMappedList(((ModuleProfileDAO) this.dao).findByModuleId(tenant, moduleId, MDC.get(MDCPreFilter.LOCALE)));
	}

	/**
	 * get all profiles by module id
	 *
	 * @param tenant   current tenant
	 * @param moduleId the application's code
	 * @param locale   the user's locale
	 * @return the profiles list
	 */
	public List<ModuleProfileDTO> findWithLocale(String tenant, Long moduleId, String locale) {
		log.info("Invoking find with params tenant: {} moduleId: {} locale: {}", tenant, moduleId, locale);
		return returnMappedList(((ModuleProfileDAO) this.dao).findByModuleId(tenant, moduleId, locale));
	}

	/**
	 * get profile by module id and profile code
	 *
	 * @param tenant   current tenant
	 * @param moduleId the application's code
	 * @return the profiles list
	 */
	public ModuleProfileDTO find(String tenant, Long moduleId, String profileCode) {
		log.info("Invoking find with params tenant: {} moduleId: {}", tenant, moduleId);
		return returnOptionalRecord(((ModuleProfileDAO) this.dao).findByModuleIdAndProfileCode(tenant, moduleId, profileCode))
				.orElse(null);
	}

	public enum APPLICATION_PROFILES_I18N {
		PROFILE_CODE("profile_code");

		private final String code;

		APPLICATION_PROFILES_I18N(String val) {
			this.code = val;
		}

		public String getCode() {
			return this.code;
		}
	}
}
