package com.abacogroup.agri.applications.bundles.processor.env;

import com.abacogroup.agri.applications.bundles.model.env.BundleApplicationEnvInDTO;
import com.abacogroup.agri.applications.bundles.model.env.BundleApplicationEnvMessage;
import com.abacogroup.agri.applications.core.model.dto.ApplicationEnvDTO;
import com.abacogroup.agri.applications.core.services.crud.ApplicationEnvCrudService;
import com.abacogroup.bundles.listener.tenant.TenantMessage;
import com.abacogroup.bundles.listener.tenant.TenantMessageProcessor;
import lombok.extern.slf4j.Slf4j;
import org.jdbi.v3.core.Jdbi;

import java.util.List;
import java.util.stream.Collectors;

import static com.abacogroup.agri.applications.bundles.BundleConstants.TENANT_TEMPLATE_CODE;

/**
 * The type Application env new tenant processor.
 * @author Carlo Sindico
 */
@Slf4j
public class ApplicationEnvNewTenantProcessor implements TenantMessageProcessor {

    protected final Jdbi jdbi;
    protected final ApplicationEnvBundleWorker applicationEnvBundleWorker;
    public ApplicationEnvNewTenantProcessor(Jdbi jdbi, ApplicationEnvBundleWorker applicationEnvBundleWorker) {
        this.jdbi = jdbi;
        this.applicationEnvBundleWorker = applicationEnvBundleWorker;
    }

    @Override
    public void onMessage(TenantMessage message) {
        jdbi.useTransaction(handle -> {
            log.info("ApplicationEnvNewTenantProcessor got new tenant {}", message.getTenantId());
            checkAndInsertApplicationEnvironments(message.getTenantId());
            log.info("ApplicationEnvNewTenantProcessor end working with new tenant {}", message.getTenantId());
        });
    }

    private void checkAndInsertApplicationEnvironments(final String tenantId) {
        log.info("ApplicationEnvNewTenantProcessor check and insert new tenant {}", tenantId);
        ApplicationEnvCrudService applicationEnvCrudService = applicationEnvBundleWorker.exposeApplicationEnvCrudService();

        List<ApplicationEnvDTO> environmentDTOs = applicationEnvCrudService.findAllByTenant(TENANT_TEMPLATE_CODE);

        List<BundleApplicationEnvInDTO> bundleApplicationEnvInDTOs = environmentDTOs.stream()
                .map(env -> BundleApplicationEnvInDTO.builder()
                        .key(env.getKey())
                        .value(env.getValue())
                        .flClient(env.getFlClient())
                        .build())
                .collect(Collectors.toList());

        applicationEnvBundleWorker.upsertApplicationEnvironments(tenantId,
                BundleApplicationEnvMessage.builder()
                        .bundleApplicationEnvInDTOList(bundleApplicationEnvInDTOs)
                        .build()
        );
    }
}
