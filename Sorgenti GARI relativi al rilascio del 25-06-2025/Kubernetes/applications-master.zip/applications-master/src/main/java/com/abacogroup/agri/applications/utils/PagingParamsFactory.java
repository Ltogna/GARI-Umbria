package com.abacogroup.agri.applications.utils;

import com.abacogroup.jdbi.paging.PagingParams;

/**
 * @author Gennaro Tamburrelli
 */
public class PagingParamsFactory {

	public static final int DEFAULT_OFFSET = 0;
	public static final int DEFAULT_LIMIT = 300;
	public static final int DEFAULT_PAGE_SIZE = 10;
	public static final int DEFAULT_PAGE_SIZE_FOR_OTHER_CASES = 5;

	public PagingParams getPagingParams(int offset, int limit) {
		return new PagingParams(offset, limit);
	}
}
