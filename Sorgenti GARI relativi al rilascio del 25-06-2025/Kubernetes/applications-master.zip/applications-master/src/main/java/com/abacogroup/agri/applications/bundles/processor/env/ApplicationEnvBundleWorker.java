package com.abacogroup.agri.applications.bundles.processor.env;

import com.abacogroup.agri.applications.bundles.model.env.BundleApplicationEnvMessage;
import com.abacogroup.agri.applications.core.exceptions.ObjectNotFoundException;
import com.abacogroup.agri.applications.core.model.dto.ApplicationEnvDTO;
import com.abacogroup.agri.applications.core.services.crud.ApplicationEnvCrudService;
import com.abacogroup.agri.applications.db.ntt.compoundkeys.ApplicationEnvKey;
import lombok.extern.slf4j.Slf4j;

/**
 * The type Application env bundle worker.
 *
 * @author Carlo Sindico
 */
@Slf4j
public class ApplicationEnvBundleWorker {

    private final ApplicationEnvCrudService applicationEnvCrudService;

    public ApplicationEnvBundleWorker(ApplicationEnvCrudService applicationEnvCrudService) {
        this.applicationEnvCrudService = applicationEnvCrudService;
    }

    public ApplicationEnvCrudService exposeApplicationEnvCrudService() {
        return this.applicationEnvCrudService;
    }

    public void upsertApplicationEnvironments(final String tenantId, BundleApplicationEnvMessage message) {
        log.info("ApplicationEnvBundleWorker: processing file with tenant {}", tenantId);
        message.getBundleApplicationEnvInDTOList()
                .forEach(env -> {
                    try {
                        ApplicationEnvKey key = ApplicationEnvKey.builder()
                                .tenant_id(tenantId)
                                .key_(env.getKey())
                                .fl_client(env.getFlClient())
                                .build();

                        applicationEnvCrudService.findEnvironmentByKey(key);

                        log.info("Environment already existing: skipping insert");

                        ApplicationEnvDTO applicationEnvDTO = ApplicationEnvDTO.builder()
                                .tenant(tenantId)
                                .key(env.getKey())
                                .value(env.getValue())
                                .flClient(env.getFlClient())
                                .build();

                        applicationEnvCrudService.update(key, applicationEnvDTO);
                    } catch (ObjectNotFoundException e) {
                        log.info("ApplicationEnvBundleWorker: inserting environment with tenant {} and name {}", tenantId, env.getKey());

                        ApplicationEnvDTO applicationEnvDTO = ApplicationEnvDTO.builder()
                                .tenant(tenantId)
                                .key(env.getKey())
                                .value(env.getValue())
                                .flClient(env.getFlClient())
                                .build();

                        applicationEnvCrudService.insert(applicationEnvDTO);
                    }
                });
    }

    public void deleteApplicationEnvironments(final String tenantId, BundleApplicationEnvMessage message) {
        log.info("ApplicationEnvBundleWorker: processing delete file with tenant {}", tenantId);
        message.getBundleApplicationEnvInDTOList()
                .forEach(env -> {
                    try {
                        ApplicationEnvKey key = ApplicationEnvKey.builder()
                                .tenant_id(tenantId)
                                .key_(env.getKey())
                                .build();

                        applicationEnvCrudService.findEnvironmentByKey(key);
                        log.info("Deleting sector {}", env.getKey());
                        applicationEnvCrudService.delete(key);
                        log.info("Environment deleted");
                    } catch (ObjectNotFoundException e) {
                        log.info("Environment not found: cannot be deleted");
                    }
                });
    }
}
