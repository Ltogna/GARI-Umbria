package com.abacogroup.agri.applications.core.model.dto.publics;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

/**
 * @author Alexandru Paraschiv
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class LastCalculationDTO {

	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	@Schema(description = "the calculation date")
	private LocalDateTime calculationDate;
	@Schema(description = "the calculation uuid")
	private String calculationJobUuid;
	@Schema(description = "the calculation status")
	private String calculationStatus;

}
