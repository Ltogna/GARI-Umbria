package com.abacogroup.agri.applications.core.model.dto.publics;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

/**
 * @author Mattia Perini
 */
@EqualsAndHashCode(callSuper = true)
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class CreateAmendmentApplicationOutDTO extends CreateApplicationOutDTO {
	private Long amendmentApplicationId;
}
