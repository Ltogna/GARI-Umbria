package com.abacogroup.agri.applications.core.services;

import com.abacogroup.agri.applications.core.caller.*;
import com.abacogroup.agri.applications.core.exceptions.CallPartyServicesErrorRuntimeException;
import com.abacogroup.agri.applications.core.exceptions.PartyNotFoundRuntimeException;
import com.abacogroup.agri.applications.core.mappers.PartyMapper;
import com.abacogroup.agri.applications.core.mappers.PartyRegistryMapper;
import com.abacogroup.agri.applications.core.model.OverridePartyHostConfig;
import com.abacogroup.agri.applications.core.model.dto.PartyDTO;
import com.abacogroup.agri.applications.core.model.dto.publics.ApplicationEnvPublicDTO;
import com.abacogroup.dropwizard.auth.sso2.User;
import lombok.extern.slf4j.Slf4j;

import jakarta.ws.rs.NotAuthorizedException;

import java.util.List;
import java.util.Optional;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

/**
 * @author Alexandru Paraschiv
 * @author Gennaro Tamburrelli
 */
@Slf4j
public class PartyService {
	public static final String JWT = "JWT ";
	public static final String PARTY_SERVICE_NOT_AUTHORIZED = "Party Services: not authorized";
	public static final String PARTY_REGISTRY_DIRECTORY_URL = "party_registry_directory_url";
	public static final String PARTY_REGISTRY_DIRECTORY_SEARCH_URL = "party_registry_directory_search_url";
	public static final String LEGACY = "legacy";
	public static final String NEW_PARTY = "party-registry";
	private final ConfigService configService;
	private final GetPartiesCaller getPartiesCaller;
	private final GetPartyByPartyIdCaller getPartyByPartyIdCaller;
	private final GetPartiesRegistryCaller getPartiesRegistryCaller;
	private final GetPartyRegistryByPartyIdCaller getPartyRegistryByPartyIdCaller;
	private final OverridePartyHostConfig overridePartyHostConfig;

	public PartyService(ConfigService configService,
			GetPartiesCaller getPartiesCaller, GetPartyByPartyIdCaller getPartyByPartyIdCaller,
			GetPartiesRegistryCaller getPartiesRegistryCaller,
			GetPartyRegistryByPartyIdCaller getPartyRegistryByPartyIdCaller, OverridePartyHostConfig overridePartyHostConfig) {
		this.configService = configService;
		this.getPartiesCaller = getPartiesCaller;
		this.getPartyByPartyIdCaller = getPartyByPartyIdCaller;
		this.getPartiesRegistryCaller = getPartiesRegistryCaller;
		this.getPartyRegistryByPartyIdCaller = getPartyRegistryByPartyIdCaller;
		this.overridePartyHostConfig = overridePartyHostConfig;
	}

	public List<PartyDTO> getPartiesByCodeOrDesc(String tenant, Long partyId, String searchCode, String searchDescription, User user) {
		try {
			var config = configService.getConfig(tenant, PARTY_REGISTRY_DIRECTORY_SEARCH_URL, 0);
			if (checkCondition(config, PARTY_REGISTRY_DIRECTORY_SEARCH_URL, LEGACY)) {
				log.info("retrieving parties for tenant: {}  searchCode: {} searchDescription: {}", tenant, searchCode, searchDescription);
				var input = new GetPartiesInput(tenant, partyId, JWT + user.getAuthToken(),
						getResourceUrl(config, PARTY_REGISTRY_DIRECTORY_SEARCH_URL, LEGACY), searchCode, searchDescription);
				return getPartiesCaller.makeCall(input)
						.getRecords()
						.stream()
						.map(PartyMapper.INSTANCE::callerOutToDTO)
						.collect(Collectors.toList());
			} else {
				var input = new GetPartiesRegistryInput(tenant, partyId, JWT + user.getAuthToken(), searchCode, searchDescription,
						getResourceUrl(config, PARTY_REGISTRY_DIRECTORY_SEARCH_URL, NEW_PARTY), "");
				return getPartiesRegistryCaller.makeCall(input)
						.getRecords()
						.stream()
						.map(PartyRegistryMapper.INSTANCE::callerOutToDTO)
						.collect(Collectors.toList());
			}

		} catch (RuntimeException e) {
			log.error(e.getMessage(), e);
			if (e.getCause() instanceof NotAuthorizedException) {
				throw new CallPartyServicesErrorRuntimeException(PARTY_SERVICE_NOT_AUTHORIZED);
			} else {
				throw new CallPartyServicesErrorRuntimeException("Party Services: error calling get parties by cuaa or desc");
			}
		}

	}

	public PartyDTO getPartyByPartyId(String tenant, Long partyId, User user) {
		try {
			var config = configService.getConfig(tenant, PARTY_REGISTRY_DIRECTORY_URL, 0);
			if (checkCondition(config, PARTY_REGISTRY_DIRECTORY_URL, LEGACY)) {
				log.info("Invoking getPartyByPartyId for tenant: {}  partyId: {}", tenant, partyId);
				var input = new GetPartyByPartyIdInput(tenant, partyId, JWT + user.getAuthToken(),
						getResourceUrl(config, PARTY_REGISTRY_DIRECTORY_URL, LEGACY));
				return Optional.ofNullable(getPartyByPartyIdCaller.makeCall(input))
						.map(PartyMapper.INSTANCE::callerOutToDTO)
						.orElseThrow(PartyNotFoundRuntimeException::new);
			} else {
				var input = new GetPartyRegistryByPartyIdInput(tenant, partyId, JWT + user.getAuthToken(),
						getResourceUrl(config, PARTY_REGISTRY_DIRECTORY_URL, NEW_PARTY), "");
				return Optional.ofNullable(getPartyRegistryByPartyIdCaller.makeCall(input))
						.map(PartyRegistryMapper.INSTANCE::callerOutToDTO)
						.orElseThrow(PartyNotFoundRuntimeException::new);
			}
		} catch (RuntimeException e) {
			log.error(e.getMessage(), e);
			if (e.getCause() instanceof NotAuthorizedException) {
				throw new CallPartyServicesErrorRuntimeException(PARTY_SERVICE_NOT_AUTHORIZED);
			} else {
				throw new CallPartyServicesErrorRuntimeException("Party Services: error calling get party by partyId");
			}
		}

	}

	private boolean checkCondition(List<ApplicationEnvPublicDTO> config, String key, String cond) {
		return config.isEmpty() || config.stream().anyMatch(x -> key.equals(x.getKey()) && x.getValue().contains(cond));
	}

	private final Pattern REGEX = Pattern.compile("(http|https)://(.*)(:[0-9]+)/", Pattern.CASE_INSENSITIVE);

	private String getResourceUrl(List<ApplicationEnvPublicDTO> config, String key, String newParty) {
		var url = config.stream().filter(x -> checkCondition(config, key, newParty)).findFirst()
				.map(ApplicationEnvPublicDTO::getValue).orElse("");

		if (Boolean.TRUE.equals(this.overridePartyHostConfig.getActive())) {
			Matcher matcher = REGEX.matcher(url);
			if (matcher.find()) {
				url = url.replaceAll(REGEX.pattern(), this.overridePartyHostConfig.getOverriddenHost());
			}
		}
		return url;
	}
}
