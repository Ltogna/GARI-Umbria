package com.abacogroup.agri.applications.utils;

import java.security.Principal;

import io.dropwizard.auth.Authorizer;
import jakarta.annotation.Priority;
import jakarta.ws.rs.container.ContainerRequestContext;

/**
 * @author Gennaro Tamburrelli
 */
@Priority(1000)
public class DevAuthorizer<P extends Principal> implements Authorizer<P> {

	private final boolean isAuthorized;

	public DevAuthorizer(boolean isAuthorized) {
		this.isAuthorized = isAuthorized;
	}

	public boolean authorize(P p, String s) {
		return this.isAuthorized;
	}

	@Override
	public boolean authorize(P principal, String role, ContainerRequestContext requestContext) {
		return this.isAuthorized;
	}
}
