package com.abacogroup.agri.applications.core.services;

import java.util.Comparator;
import java.util.Objects;
import java.util.Optional;

import com.abacogroup.agri.applications.core.exceptions.ApplicationAlreadyInTransactionRuntimeException;
import org.jdbi.v3.core.Jdbi;
import org.slf4j.MDC;

import com.abacogroup.agri.applications.core.exceptions.ApplicationNotFoundRuntimeException;
import com.abacogroup.agri.applications.core.exceptions.NoTransitionFoundRuntimeException;
import com.abacogroup.agri.applications.core.exceptions.ObjectNotFoundException;
import com.abacogroup.agri.applications.core.model.ProcessTransitionEnum;
import com.abacogroup.agri.applications.core.model.ProgressTypeEnum;
import com.abacogroup.agri.applications.core.model.dto.publics.ApplicationDTO;
import com.abacogroup.agri.applications.core.model.dto.publics.ProgressApplicationDTO;
import com.abacogroup.agri.applications.core.services.crud.ApplicationDetailsCrudService;
import com.abacogroup.agri.applications.core.services.crud.ApplicationsCrudService;
import com.abacogroup.agri.applications.core.services.embededqueue.UpdateProcessQueue;
import com.abacogroup.agri.applications.core.services.embededqueue.model.QueueWorkflowParams;
import com.abacogroup.agri.applications.core.services.workflow.ApplicationsWorkflowService;
import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.jaxrsutils.filter.MDCPreFilter;
import com.abacogroup.workflow.sdk.beans.ProcessData;
import com.abacogroup.workflow.sdk.beans.WorkflowMessage;
import com.abacogroup.workflow.server.model.DetailedTransitionLog;
import com.abacogroup.workflow.server.model.Transition;

import lombok.extern.slf4j.Slf4j;

/**
 * @author Gennaro Tamburrelli
 */
@Slf4j
public class ProgressService {

	private final Jdbi jdbi;
	private final ApplicationsWorkflowService applicationsWorkflowService;
	private final ApplicationsCrudService applicationsCrudService;
	private final ApplicationDetailsCrudService applicationDetailsCrudService;
	private final UpdateProcessQueue updateProcessQueue;
	private final ForceReadOnlyContextCheckerService forceReadOnlyContextCheckerService;

	public ProgressService(Jdbi jdbi,
                           ApplicationsWorkflowService applicationsWorkflowService,
                           ApplicationsCrudService applicationsCrudService,
                           ApplicationDetailsCrudService applicationDetailsCrudService,
                           UpdateProcessQueue updateProcessQueue, ForceReadOnlyContextCheckerService forceReadOnlyContextCheckerService) {
		this.jdbi = jdbi;
		this.applicationsWorkflowService = applicationsWorkflowService;
		this.applicationsCrudService = applicationsCrudService;
		this.applicationDetailsCrudService = applicationDetailsCrudService;
        this.updateProcessQueue = updateProcessQueue;
        this.forceReadOnlyContextCheckerService = forceReadOnlyContextCheckerService;
    }

	public void progress(String tenant, Long applicationId, String tagName, User user, String scope, ProgressApplicationDTO progressApplicationDTO,
			ProgressTypeEnum progressType) {
		this.progress(tenant, applicationId, tagName, user, scope, progressApplicationDTO, progressType, null);

	}

	public void progress(String tenant, Long applicationId, String tagName, User user, String scope, ProgressApplicationDTO progressApplicationDTO,
			ProgressTypeEnum progressType, ProcessData parentProcessData) {
		ApplicationDTO application = getApplication(tenant, applicationId);
		Optional<Integer> optTransitionId = applicationsWorkflowService.getUserAvailableTransitions(tenant, applicationId, application.getProcessId(), user, scope)
				.stream()
				.filter(x -> x.getTags().contains(tagName))
				.findFirst()
				.map(Transition::getId);
		optTransitionId.ifPresentOrElse(transitionId -> {
			try {
				progress(tenant, applicationId, transitionId, user, scope, progressApplicationDTO, progressType, parentProcessData);
			} catch (Exception e) {
				throw new RuntimeException(e.getMessage(), e);
			}
		},
				() -> {
					throw new NoTransitionFoundRuntimeException();
				});
	}

	private ApplicationDTO getApplication(String tenant, Long applicationId) {
		ApplicationDTO application;
		try {
			application = applicationsCrudService.findById(tenant, applicationId);
		} catch (ObjectNotFoundException e) {
			throw new ApplicationNotFoundRuntimeException("application not found");
		}
		return application;
	}

	public void progress(String tenant, Long applicationId, Integer transitionId, User user, String scope, ProgressApplicationDTO progressApplicationDTO,
			ProgressTypeEnum progressType) throws Exception {
		progress(tenant, applicationId, transitionId, user, scope, progressApplicationDTO, progressType, null);
	}

	public void progress(String tenant, Long applicationId, Integer transitionId, User user, String scope, ProgressApplicationDTO progressApplicationDTO,
			ProgressTypeEnum progressType, ProcessData parentProcessData) throws Exception {
		jdbi.useTransaction(handle -> {
			try {
				// get application
				var application = applicationsCrudService.findById(tenant, applicationId);
				var applicationDetails = applicationDetailsCrudService.findApplicationDetailById(tenant, applicationId);

				forceReadOnlyContextCheckerService.checkForReadOnlyContextFunctionByModuleId(user, application.getModuleId());

				if(Objects.equals(ProcessTransitionEnum.IN_TRANSITION.getFl(), applicationDetails.getFlInTransition())) {
					throw new ApplicationAlreadyInTransactionRuntimeException(String.format("application id %s already in transaction", application.getApplicationId()));
				}
				// get transition
				Transition wantendTransition = findTransitionByProcessIdAndTransitionId(tenant, applicationId, user, application.getProcessId(), scope, transitionId);
				// update application detail
				applicationDetailsCrudService.updateProcessStatusAndFlTransition(tenant, applicationId, applicationDetails.getProcessStatus(), user.getUserId(),
						ProcessTransitionEnum.IN_TRANSITION);
				QueueWorkflowParams queueWorkflowParams = QueueWorkflowParams.builder()
						.processId(application.getProcessId())
						.applicationId(applicationId)
						.tenant(tenant)
						.transitionId(wantendTransition.getId())
						.username(user.getName())
						.userid(user.getUserId())
						.locale(Optional.ofNullable(MDC.get(MDCPreFilter.LOCALE)).orElse("it"))
						.scope(scope)
						.notes(progressApplicationDTO.getNotes())
						.build();
				switch (progressType) {
				case ASYNC:
					// execute progress process asynchronously
					updateProcessQueue.add(queueWorkflowParams, System.currentTimeMillis());
					break;
				case SYNC:
					// execute progress process synchronously
					updateProcessQueue.executeTransition(queueWorkflowParams, parentProcessData);
					break;
				default:
					throw new RuntimeException("sync type not valid");
				}

			} catch (ObjectNotFoundException e) {
				throw new ApplicationNotFoundRuntimeException(e.getMessage());
			}
		});
	}

	private Transition findTransitionByProcessIdAndTransitionId(String tenant, Long applicationId, User user, Long processId, String scope, Integer transitionId) {
		log.info("Searching transition by processId: {}", processId);
		return applicationsWorkflowService.getUserAvailableTransitions(tenant, applicationId, processId, user, scope)
				.stream()
				.filter(t -> t.getId().equals(transitionId))
				.findFirst()
				.orElseThrow(NoTransitionFoundRuntimeException::new);
	}

	public boolean lastTransitionHasError(String tenant, Long applicationId, User user) {
		var app = getApplication(tenant, applicationId);
		return applicationsWorkflowService.getProcessTransitionHistory(tenant, app.getProcessId(), user)
				.stream()
				.max(Comparator.comparing(DetailedTransitionLog::getEndDate))
				.map(x -> x.getMessages().stream().anyMatch(y -> y.getType().equals(WorkflowMessage.Type.ERROR)))
				.orElse(false);
	}
}
