package com.abacogroup.agri.applications.core.caller;

import com.abacogroup.jaxrsutils.GenericCallerService;
import com.abacogroup.jaxrsutils.callerv2.AbacoDtoCaller;
import com.abacogroup.jdbi.paging.impl.InfiniteListResultsImpl;

/**
 * @author Alexandru Paraschiv
 */
public class GetPartiesCaller extends AbacoDtoCaller<GetPartiesInput, InfiniteListResultsImpl<GetPartiesOutput>> {

	public GetPartiesCaller(GenericCallerService genericCallerService) {
		super(genericCallerService);
	}

	@Override
	public InfiniteListResultsImpl<GetPartiesOutput> makeCall(GetPartiesInput arg) {
		return super.makeCall(arg);
	}

}
