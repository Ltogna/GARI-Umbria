package com.abacogroup.agri.applications.bundles.processor.childmodule;

import com.abacogroup.agri.applications.bundles.model.chilldmodule.BundleChildrenModulesMessage;
import com.abacogroup.agri.applications.bundles.processor.AbstractBundleApplicationsProcessor;
import com.abacogroup.bundles.listener.configdata.ConfigDataMessage;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.jdbi.v3.core.Jdbi;

import java.nio.file.Path;

/**
 * @author Mattia Perini
 */
@Slf4j
public class BundleChildrenModulesProcessor extends AbstractBundleApplicationsProcessor<BundleChildrenModulesMessage> {

	protected final ChildrenModulesBundleWorker childrenModulesBundleWorker;

	public BundleChildrenModulesProcessor(ObjectMapper mapper, ChildrenModulesBundleWorker childrenModulesBundleWorker, Jdbi jdbi) {
		super(mapper, jdbi);
		this.childrenModulesBundleWorker = childrenModulesBundleWorker;
	}

	@Override
	public String getDomainName() {
		return "children-modules";
	}

	@Override
	protected TypeReference<BundleChildrenModulesMessage> getTypeReference() {
		return new TypeReference<>() {
		};
	}

	@Override
	public void onMessageInTransaction(ConfigDataMessage message) {
		log.info("onMessageInTransaction: processing file with tenant {}", message.getTenantId());
		message.getConfigFiles().stream()
				.map(Path::toFile)
				.filter(file -> file.getAbsolutePath().endsWith(".json"))
				.forEach(file -> processFile(message.getTenantId(), file));
	}

	@Override
	protected void delete(String tenantId, BundleChildrenModulesMessage message) {
		childrenModulesBundleWorker.deleteBundleChildrenModules(tenantId, message);
	}

	@Override
	protected void doInsertOrUpdate(String tenantId, BundleChildrenModulesMessage message) {
		childrenModulesBundleWorker.upsertBundleChildrenModules(tenantId, message);
	}

}
