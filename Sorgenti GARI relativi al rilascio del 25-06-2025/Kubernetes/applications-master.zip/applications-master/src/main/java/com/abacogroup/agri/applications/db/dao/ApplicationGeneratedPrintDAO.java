package com.abacogroup.agri.applications.db.dao;

import com.abacogroup.agri.applications.db.ntt.ApplicationGeneratedPrintNTT;
import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.customizer.BindBean;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;

import java.util.List;

/**
 * @author Gennaro Tamburrelli
 */
public interface ApplicationGeneratedPrintDAO extends IGenericDAO<ApplicationGeneratedPrintNTT, Long> {

	@Override
	@SqlQuery("§select_nextval(apps_applications_generated_prints_seq_id)§")
	Long nextSequenceVal();

	@Override
	@SqlUpdate("INSERT INTO APPS_APPLICATIONS_GENERATED_PRINTS " +
			"(pkid, " +
			"application_id, " +
			"process_status, " +
			"print_code, " +
			"print_date, " +
			"print_job_uuid, " +
			"file_id," +
			"username," +
			"status) " +
			"VALUES(:pkid, :application_id, :process_status, :print_code, §current_timestamp§, :print_job_uuid, :file_id, :username, :status)")
	void insert(@BindBean ApplicationGeneratedPrintNTT ntt);

	@SqlQuery("select a.pkid, " +
			"  a.application_id, " +
			"  a.process_status, " +
			"  a.print_code, " +
			"  a.print_date, " +
			"  a.print_job_uuid, " +
			"  a.username, " +
			"  a.status, " +
			"  a.file_id " +
			" from APPS_APPLICATIONS_GENERATED_PRINTS a" +
			" where a.pkid = :id")
	@RegisterBeanMapper(ApplicationGeneratedPrintNTT.class)
	List<ApplicationGeneratedPrintNTT> findById(@Bind("id") Long pkid);

	@SqlUpdate("UPDATE APPS_APPLICATIONS_GENERATED_PRINTS " +
			"  SET application_id = :application_id , " +
			"  process_status = :process_status, " +
			"  print_code = :print_code, " +
			"  print_date = :print_date, " +
			"  print_job_uuid = :print_job_uuid, " +
			"  username = :username, " +
			"  status = :status, " +
			"  file_id = :file_id " +
			" where pkid = :pkid")
	void update(@BindBean ApplicationGeneratedPrintNTT anomaly);

	@SqlUpdate("DELETE FROM APPS_APPLICATIONS_GENERATED_PRINTS a " +
			" where a.pkid = :pkid")
	void deleteById(@Bind("pkid") Long pkid);

	@SqlQuery("select a.pkid, " +
			"  a.application_id, " +
			"  a.process_status, " +
			"  a.print_code, " +
			" coalesce(§i18n(:tenant_id, 'apps_module_print_configs', 'print_code:process_status', a.print_code || ':' || a.process_status, :lang)§, " +
    		"    §i18n(:tenant_id, 'apps_module_print_configs', 'print_code', a.print_code, :lang)§) as print_description, " + 
			"  a.print_date, " +
			"  a.print_job_uuid, " +
			"  a.username, " +
			"  a.status, " +
			"  a.file_id " +
			" from APPS_APPLICATIONS_GENERATED_PRINTS a INNER JOIN APPS_APPLICATIONS aa ON a.application_id = aa.id " +
			" INNER JOIN APPS_MODULES am on am.id = aa.module_id " +
			" INNER JOIN APPS_SECTORS s on s.id = am.sector_id " +
			" where s.tenant_id = :tenant_id " +
			" and aa.id = :application_id " +
			" and ((a.file_id is not null and a.status = 'READY') or (a.file_id is null and a.status = 'ERROR')) " +
			" and (:print_code IS NULL OR a.print_code = :print_code) " +
			" and §current_timestamp§ between am.dt_insert and am.dt_delete " +
			" ORDER BY a.print_date DESC")
	@RegisterBeanMapper(ApplicationGeneratedPrintNTT.class)
	List<ApplicationGeneratedPrintNTT> findCompletedPrintsByApplicationIdAndPrintCode(@Bind("tenant_id") String tenant, @Bind("application_id") Long applicationId,
			@Bind("lang") String lang, @Bind("print_code") String printCode);

	@SqlQuery("select a.pkid, " +
			"  a.application_id, " +
			"  a.process_status, " +
			"  a.print_code, " +
			" coalesce(§i18n(:tenant_id, 'apps_module_print_configs', 'print_code:process_status', a.print_code || ':' || a.process_status, :lang)§, " +
    		"    §i18n(:tenant_id, 'apps_module_print_configs', 'print_code', a.print_code, :lang)§) as print_description, " + 
			"  a.print_date, " +
			"  a.print_job_uuid, " +
			"  a.username, " +
			"  a.status, " +
			"  a.file_id " +
			" from APPS_APPLICATIONS_GENERATED_PRINTS a INNER JOIN APPS_APPLICATIONS aa ON a.application_id = aa.id " +
			" INNER JOIN APPS_MODULES am on am.id = aa.module_id " +
			" INNER JOIN APPS_SECTORS s on s.id = am.sector_id " +
			" where s.tenant_id = :tenant_id " +
			" and aa.id = :application_id " +
			" and a.file_id = :file_id " +
			" and §current_timestamp§ between am.dt_insert and am.dt_delete ")
	@RegisterBeanMapper(ApplicationGeneratedPrintNTT.class)
	List<ApplicationGeneratedPrintNTT> findByApplicationIdAndFileId(@Bind("tenant_id") String tenant, @Bind("application_id") Long applicationId,
			@Bind("lang") String lang, @Bind("file_id") String fileId);

	@SqlQuery("select a.pkid, " +
			"  a.application_id, " +
			"  a.process_status, " +
			"  a.print_code, " +
			" coalesce(§i18n(:tenant_id, 'apps_module_print_configs', 'print_code:process_status', a.print_code || ':' || a.process_status, :lang)§, " +
    		"    §i18n(:tenant_id, 'apps_module_print_configs', 'print_code', a.print_code, :lang)§) as print_description, " + 
			"  a.print_date, " +
			"  a.print_job_uuid, " +
			"  a.username, " +
			"  a.status, " +
			"  a.file_id " +
			" from APPS_APPLICATIONS_GENERATED_PRINTS a INNER JOIN APPS_APPLICATIONS aa ON a.application_id = aa.id " +
			" INNER JOIN APPS_MODULES am on am.id = aa.module_id " +
			" INNER JOIN APPS_SECTORS s on s.id = am.sector_id " +
			" where s.tenant_id = :tenant_id " +
			" and aa.id = :application_id " +
			" and a.print_code = :print_code " +
			" and ((:ongoing = 0 and a.status is not null) or (:ongoing = 1 and a.file_id is null and a.status is null)) " +
			" and §current_timestamp§ between am.dt_insert and am.dt_delete " +
			" and a.print_date = (select MAX(print_date) " +
			"                        from APPS_APPLICATIONS_GENERATED_PRINTS " +
			"                        where application_id = :application_id " +
			"                        and print_code =:print_code " +
			"                        and ((:ongoing = 0 and a.file_id is not null) or (:ongoing = 1 and a.file_id is null)))")
	@RegisterBeanMapper(ApplicationGeneratedPrintNTT.class)
	List<ApplicationGeneratedPrintNTT> findLastGeneratedPrintByCode(@Bind("tenant_id") String tenant, @Bind("application_id") Long applicationId,
			@Bind("print_code") String printCode, @Bind("lang") String lang, @Bind("ongoing") Integer ongoing);

	@SqlQuery("select a.pkid, " +
			"  a.application_id, " +
			"  a.process_status, " +
			"  a.print_code, " +
			"  a.print_date, " +
			"  a.print_job_uuid, " +
			"  a.username, " +
			"  a.status, " +
			"  a.file_id " +
			" from APPS_APPLICATIONS_GENERATED_PRINTS a" +
			" where a.print_job_uuid = :print_job_uuid")
	@RegisterBeanMapper(ApplicationGeneratedPrintNTT.class)
	ApplicationGeneratedPrintNTT findByUuid(@Bind("print_job_uuid") String uuid);
}
