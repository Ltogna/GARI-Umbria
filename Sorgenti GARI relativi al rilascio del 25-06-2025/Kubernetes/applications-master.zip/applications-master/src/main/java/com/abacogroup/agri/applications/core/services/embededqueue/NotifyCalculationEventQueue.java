package com.abacogroup.agri.applications.core.services.embededqueue;

import static com.abacogroup.embeddedqueue.QueueErrorListener.ErrorAction.RESCHEDULE;

import com.abacogroup.agri.applications.core.model.dto.publics.ApplicationDTO;
import com.abacogroup.agri.applications.core.services.crud.ApplicationProfilesCrudService;
import com.abacogroup.agri.applications.core.services.crud.ApplicationsCrudService;
import com.abacogroup.agri.applications.core.services.crud.SectorsCrudService;
import com.abacogroup.agri.applications.core.services.workflow.ApplicationProfilesManager;
import com.abacogroup.agri.applications.core.services.workflow.AuthContextFactory;
import com.abacogroup.applicationworkflowsdk.model.CalculationResult;
import com.abacogroup.applicationworkflowsdk.v2.IAgriProcedureEnvironment;
import com.abacogroup.embeddedqueue.QueueErrorListener;
import com.abacogroup.embeddedqueue.ThrowingConsumer;
import com.abacogroup.embeddedqueue.WorkQueue;
import com.abacogroup.embeddedqueue.db.JdbiRepository;
import com.abacogroup.workflow.server.NotifyEventParams;
import com.abacogroup.workflow.server.services.ProcessService;
import com.codahale.metrics.MetricRegistry;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * @author Gennaro Tamburrelli
 */
public class NotifyCalculationEventQueue extends WorkQueue<CalculationResult> {

	public static final String APP_CALC_DONE_EVENT = "app-calc-done-event";
	private ProcessService<IAgriProcedureEnvironment> processService;
	private AuthContextFactory authContextFactory;
	private ApplicationsCrudService applicationsCrudService;
	private ApplicationProfilesCrudService applicationProfilesCrudService;
	private SectorsCrudService sectorsCrudService;

	public static final String CALC_DONE_PREFIX = "CALC_DONE_";

	public NotifyCalculationEventQueue(JdbiRepository repo, ObjectMapper objectMapper, MetricRegistry registry,
			int numThreads, long timeoutMs, ProcessService<IAgriProcedureEnvironment> processService,
			AuthContextFactory authContextFactory, ApplicationsCrudService applicationsCrudService,
			ApplicationProfilesCrudService applicationProfilesCrudService,
			SectorsCrudService sectorsCrudService) {
		super(APP_CALC_DONE_EVENT, repo, numThreads, timeoutMs);
		this.processService = processService;
		this.authContextFactory = authContextFactory;
		this.applicationsCrudService = applicationsCrudService;
		this.applicationProfilesCrudService = applicationProfilesCrudService;
		this.sectorsCrudService = sectorsCrudService;
		this.setObjectMapper(objectMapper);
		this.setMetricRegistry(registry);
		this.setConsumer(doTheJob);
		this.setErrorListener(handleError);
		this.start();
	}

	@Override
	protected Class<CalculationResult> getJobClass() {
		return CalculationResult.class;
	}

	private final ThrowingConsumer<CalculationResult> doTheJob = input -> {
		ApplicationDTO application = applicationsCrudService.findById(input.getApplicationId()).orElseThrow();
		String tenant = sectorsCrudService.findTenantByModuleId(application.getModuleId());
		processService.notifyEvent(NotifyEventParams.builder()
				.processId(application.getProcessId())
				.authContext(authContextFactory.createAuthContextByUserid(tenant, input.getUser(), "it"))
				.eventType(CALC_DONE_PREFIX + input.getCalculationCode())
				.profilesManager(new ApplicationProfilesManager(tenant, input.getApplicationId(), applicationProfilesCrudService))
				.payload(input)
				.build());
	};

	private final QueueErrorListener<CalculationResult> handleError = (appParams, exp) -> {
		return RESCHEDULE;
	};

}
