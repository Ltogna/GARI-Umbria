package com.abacogroup.agri.applications.core.services.crud;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import com.abacogroup.agri.applications.core.exceptions.ObjectNotFoundException;
import com.abacogroup.agri.applications.core.mappers.ApplicationProtocolsMapper;
import com.abacogroup.agri.applications.core.model.dto.publics.ApplicationProtocolsDTO;
import com.abacogroup.agri.applications.db.dao.ApplicationProtocolsDAO;
import com.abacogroup.agri.applications.db.ntt.ApplicationProtocolsNTT;

import lombok.extern.slf4j.Slf4j;

/**
 * @author Samuele Sbarbaro
 */
@Slf4j
public class ApplicationProtocolsCrudService
		extends AbstractHistoricizationFieldsCrudService<ApplicationProtocolsNTT, Long, ApplicationProtocolsDTO, ApplicationProtocolsMapper, Void> {

	public ApplicationProtocolsCrudService(ApplicationProtocolsDAO dao, ApplicationProtocolsMapper mapper) {
		super(dao, mapper);
	}

	@Override
	protected boolean hasPrimaryKey() {
		return true;
	}

	@Override
	protected Void retrieveCustomKeyByResultSet(ApplicationProtocolsNTT rs) {
		return null;
	}

	@Override
	protected ApplicationProtocolsNTT adjustR(ApplicationProtocolsNTT rs) throws Exception {
		return rs;
	}

	@Override
	protected Optional<ApplicationProtocolsNTT> findRsByCustomKey(Void customKey) {
		return Optional.empty();
	}

	public ApplicationProtocolsDTO findById(Long id) throws ObjectNotFoundException {
		log.info("Invoking find by with params key: {}", id);
		return this.findOutDtoByPrimaryKey(id);
	}

	/**
	 * get all protocols by application id
	 *
	 * @param tenant
	 *            current tenant
	 * @param applicationId
	 *            the application's id
	 * @return the protocols list
	 */
	public List<ApplicationProtocolsDTO> findAll(String tenant, Long applicationId) {
		log.info("Invoking findAll with params tenant: {} applicationId: {}", tenant, applicationId);
		return returnMappedList(((ApplicationProtocolsDAO) this.dao).find(tenant, applicationId));
	}

	public ApplicationProtocolsDTO insert(ApplicationProtocolsDTO in, String username) {
		log.info("Invoking insert with params in: {} username: {}", in, username);
		return this.insert(in, username, null, this.dao.getCurrentTimestamp());
	}

	public ApplicationProtocolsDTO update(Long key, ApplicationProtocolsDTO in, String username) {
		log.info("Invoking update with params key: {} in: {} username: {}", key, in, username);
		return this.update(key, in, username, null);
	}

	public void logicallyDeleteByApplicationId(Long id, String username) {
		(this.dao).logicallyDeleteById(id, username, LocalDateTime.now());
	}

	public LocalDateTime getCurrentTimestamp() {
		return this.dao.getCurrentTimestamp();
	}
}
