package com.abacogroup.agri.applications.db.ntt;

import com.abacogroup.agri.applications.db.ntt.applications.IIdRs;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.util.Optional;

/**
 * @author Alexandru Paraschiv
 */
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class ModuleFormConfigsNTT implements IIdRs<Long> {

	private Long id;
	private Long module_id;
	private String process_status;
	private Long form_id;
	private Long form_group_id;
	private Integer sort_order;
	private Integer fl_readonly;
	private String compile_status_identifier;
	private String context_function;
	private String force_read_only_context_function;

	@Override
	public Optional<Long> getKey() {
		return Optional.ofNullable(this.id);
	}

	@Override
	public void setKey(Long id) {
		this.id = id;
	}
}
