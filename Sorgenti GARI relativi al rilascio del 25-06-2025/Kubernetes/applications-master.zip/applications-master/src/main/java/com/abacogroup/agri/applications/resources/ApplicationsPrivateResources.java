package com.abacogroup.agri.applications.resources;

import com.abacogroup.agri.applications.core.model.AbsoluteDate;
import com.abacogroup.agri.applications.core.model.ProgressTypeEnum;
import com.abacogroup.agri.applications.core.model.dto.ApplicationGeneratedCalculationDTO;
import com.abacogroup.agri.applications.core.model.dto.ApplicationGeneratedPrintDTO;
import com.abacogroup.agri.applications.core.model.dto.ApplicationProfileDTO;
import com.abacogroup.agri.applications.core.model.dto.ModuleWithDetailDTO;
import com.abacogroup.agri.applications.core.model.dto.publics.*;
import com.abacogroup.agri.applications.core.services.AmendmentService;
import com.abacogroup.agri.applications.core.services.ApplicationsService;
import com.abacogroup.agri.applications.core.services.ConfigService;
import com.abacogroup.agri.applications.core.services.FormConfigService;
import com.abacogroup.agri.applications.core.services.calculation.CalculationService;
import com.abacogroup.agri.applications.core.services.print.PrintService;
import com.abacogroup.agri.applications.core.services.workflow.sdkimpl.AnomalyHandlerImpl;
import com.abacogroup.applicationworkflowsdk.model.CreateProcessType;
import com.abacogroup.applicationworkflowsdk.model.DetailedSdkTransitionLog;
import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.jaxrsutils.filter.MDCPreFilter;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.workflow.server.model.Transition;
import com.codahale.metrics.annotation.Timed;
import io.dropwizard.auth.Auth;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import jakarta.annotation.security.PermitAll;
import jakarta.annotation.security.RolesAllowed;
import jakarta.validation.Valid;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.Context;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.core.SecurityContext;
import org.slf4j.MDC;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Timed
@Path("/{tenant}/api-priv/v1/")
@PermitAll
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
@RolesAllowed("APPLICATIONS|USER")
public class ApplicationsPrivateResources {

	public static final String MODULES_PRIVATE_RESOURCES = "Modules Private Resources";
	public static final String APPLICATIONS_PRIVATE_RESOURCES = "Applications Private Resources";
	public static final String ANOMALIES_TAG = "Anomalies Private Resources";
	public static final String AMENDMENT_TAG = "Amendment Private Resources";
	public static final String APPLICATIONS_RESOURCES_SCOPE = "applications";

	private final ApplicationsService applicationsService;
	private final ConfigService configService;
	private final FormConfigService formConfigService;
	private final PrintService printService;
	private final AnomalyHandlerImpl anomalyHandler;
	private final AmendmentService amendmentService;
	private final CalculationService calculationService;

	public ApplicationsPrivateResources(ApplicationsService applicationsService,
			ConfigService configService, FormConfigService formConfigService, PrintService printService,
			AnomalyHandlerImpl anomalyHandler, AmendmentService amendmentService,
			CalculationService calculationService) {
		this.applicationsService = applicationsService;
		this.configService = configService;
		this.formConfigService = formConfigService;
		this.printService = printService;
		this.anomalyHandler = anomalyHandler;
		this.amendmentService = amendmentService;
		this.calculationService = calculationService;
	}

	@GET
	@Path("/modules")
	@Operation(description = "Returns the list of modules, given the date", tags = { MODULES_PRIVATE_RESOURCES })
	@ApiResponse(description = "The list of modules")
	@ApiResponse(responseCode = "404", description = "No modules found at date - ErrCode: NO_MODULES_FOUND_AT_DATE")
	public InfiniteListResults<ModuleByPointInTimeDTO> getModulesByPointInTime(@Parameter(description = "Current Tenant") @PathParam("tenant") String tenant,
			@Parameter(description = "The absolute date used in search, if null or empty, will be calculated as today") @QueryParam("point_in_time") AbsoluteDate pointInTime,
			@Parameter(description = "Next key for infinite list") @QueryParam("nextKey") String nextKey,
			@Parameter(description = "The amend flag") @QueryParam("flAmend") @DefaultValue("0") Integer flAmend,
			@Parameter(hidden = true) @Auth User user,
			@Context SecurityContext sc) {
		return applicationsService.getModulesByPointInTime(tenant, pointInTime, flAmend, nextKey, sc);
	}

	@GET
	@Path("/sectors/{sector_code}/modules/{module_code}/profiles")
	@Operation(description = "Returns the list of modules, given the date", tags = { MODULES_PRIVATE_RESOURCES })
	@ApiResponse(description = "The list of modules")
	@ApiResponse(responseCode = "404", description = "No profiles with sector and module code, at date - " +
			"ErrCode: NO_PROFILES_FOUND_WITH_SECTOR_AND_MODULE_AT_DATE")
	public InfiniteListResults<ModuleProfilePublicDTO> getModuleProfilesBySectorCodeAndModuleCode(
			@Parameter(description = "Current Tenant") @PathParam("tenant") String tenant,
			@Parameter(description = "The sector code") @PathParam("sector_code") String sectorCode,
			@Parameter(description = "The module code") @PathParam("module_code") String moduleCode,
			@Parameter(description = "The absolute date used in search, if null or empty, will be calculated as today") @QueryParam("point_in_time") AbsoluteDate pointInTime,
			@Parameter(description = "Next key for infinite list") @QueryParam("nextKey") String nextKey,
			@Parameter(hidden = true) @Auth User user,
			@Context SecurityContext sc) {
		return applicationsService.getProfilesByModuleAndSector(tenant, sectorCode, moduleCode, pointInTime, nextKey);
	}

	@GET
	@Path("/applications/environments")
	@Operation(description = "Returns the list of environment configs, given the environment name", tags = { APPLICATIONS_PRIVATE_RESOURCES })
	@ApiResponse(description = "The list of environment configs")
	@ApiResponse(responseCode = "404", description = "No environment found - ErrCode: ENVIRONMENT_NOT_FOUND_ERROR")
	public List<ApplicationEnvPublicDTO> getEnvironments(@Parameter(description = "Current Tenant") @PathParam("tenant") String tenant,
			@Parameter(description = "Environment name", required = false) @QueryParam("environment") String environment,
			@Parameter(hidden = true) @Auth User user,
			@Context SecurityContext sc) {
		return configService.getConfig(tenant, environment);
	}

	@GET
	@Path("/applications/{application_id}")
	@Operation(description = "Returns the detail of the application", tags = { APPLICATIONS_PRIVATE_RESOURCES })
	@ApiResponse(description = "The detail of the application")
	@ApiResponse(responseCode = "404", description = "No application found - ErrCode: APPLICATION_NOT_FOUND_ERROR")
	@ApiResponse(responseCode = "500", description = "Workflow generic error - ErrCode: WORKFLOW_GENERIC_ERROR")
	public ApplicationWithDetailsDTO getApplicationDetail(@Parameter(description = "Current Tenant") @PathParam("tenant") String tenant,
			@Parameter(description = "The application id") @PathParam("application_id") Long applicationId,
			@Parameter(hidden = true) @Auth User user,
			@Context SecurityContext sc) {
		var res = applicationsService.getApplicationWithDetailsById(tenant, applicationId, user, sc);

		List<String> requiredProfileCodes = res.getProfileList()
				.stream()
				.map(ApplicationProfileDTO::getProfileCode)
				.collect(Collectors.toList());

		res.setForms(formConfigService
				.getFormsByModuleIdAndProcessStatus(tenant,
						res.getModuleId(),
						res.getProcessStatus(),
						res.getCompileStatus(),
						requiredProfileCodes.isEmpty() ? new ArrayList<>(List.of("")) : requiredProfileCodes,
						sc,
						MDC.get(MDCPreFilter.LOCALE)));
		res.setPrints(applicationsService
				.getPrintsByModuleIdAndProcessStatus(tenant,
						applicationId,
						res.getModuleId(),
						res.getProcessStatus(),
						requiredProfileCodes.isEmpty() ? new ArrayList<>(List.of("")) : requiredProfileCodes,
						sc));
		res.setIsClosed(applicationsService.isApplicationClosed(tenant, res));
		res.setOriginalAmendedApplicationId(amendmentService.getOriginalAmendedApplicationId(res, tenant));

		res.setCalculations(applicationsService.getCalculationsByModuleIdAndProcessStatus(tenant,
				applicationId,
				res.getModuleId(),
				res.getProcessStatus(),
				requiredProfileCodes.isEmpty() ? new ArrayList<>(List.of("")) : requiredProfileCodes,
				sc));

		return res;
	}

	@GET
	@Path("/applications/parties/{partyId}/summary")
	@Operation(description = "Returns the list of years and applications count of a party, given his id", tags = { APPLICATIONS_PRIVATE_RESOURCES })
	@ApiResponse(description = "The list of years and applications count")
	@ApiResponse(responseCode = "400", description = "If partyId is not specified as query parameter")
	@ApiResponse(responseCode = "404", description = "No applications found - ErrCode: NO_APPLICATION_SUMMARY_FOUND")
	public ApplicationsSummaryByYearOutDTO getApplicationsSummary(
			@Parameter(description = "Current Tenant") @PathParam("tenant") String tenant,
			@Parameter(description = "the Party Id") @PathParam("partyId") Long partyId,
			@Parameter(hidden = true) @Auth User user,
			@Context SecurityContext sc) {
		return applicationsService.getApplicationsSummaryByYear(tenant, partyId, user, sc);
	}

	@POST
	@Path("/applications-async")
	@Operation(description = "Creates a new application", tags = { APPLICATIONS_PRIVATE_RESOURCES })
	@ApiResponse(description = "The application code created and the anomalies found")
	@ApiResponse(responseCode = "409", description = "At least one severe anomaly occurred")
	public CreateApplicationOutDTO createApplicationAsync(
			@Parameter(description = "Current Tenant") @PathParam("tenant") String tenant,
			@Parameter(hidden = true) @Auth User user,
			@Valid CreateApplicationInDTO payload,
			@Context SecurityContext sc) {
		return applicationsService.createApplication(tenant, user, payload, CreateProcessType.ASYNC, MDC.get(MDCPreFilter.LOCALE));
	}

	@POST
	@Path("/applications-async/amendment-application")
	@Operation(description = "Creates a new application", tags = { APPLICATIONS_PRIVATE_RESOURCES })
	@ApiResponse(description = "The application code created and the anomalies found")
	@ApiResponse(responseCode = "409", description = "At least one severe anomaly occurred")
	public CreateAmendmentApplicationOutDTO createAmendmentApplicationAsync(
			@Parameter(description = "Current Tenant") @PathParam("tenant") String tenant,
			@Parameter(hidden = true) @Auth User user,
			@Valid CreateApplicationInDTO payload,
			@Context SecurityContext sc) {
		return applicationsService.createAmendmentApplicationAsync(tenant, user, payload, MDC.get(MDCPreFilter.LOCALE));
	}

	@GET
	@Path("/applications/parties/{partyId}/years/{year}")
	@Operation(description = "Returns the list of applications, given the party id and the year", tags = { APPLICATIONS_PRIVATE_RESOURCES })
	@ApiResponse(description = "The list of applications")
	@ApiResponse(responseCode = "404", description = "No applications found for party or year - ErrCode: NO_APPLICATIONS_FOUND_BY_PARTY_AND_YEAR")
	public InfiniteListResults<AppByPartyAndYearDTO> getApplicationsByPartyAndYear(
			@Parameter(description = "Current Tenant") @PathParam("tenant") String tenant,
			@Parameter(description = "The specific party id") @PathParam("partyId") Long partyId,
			@Parameter(description = "The specific year") @PathParam("year") Integer year,
			@Parameter(description = "Next key for infinite list") @QueryParam("nextKey") String nextKey,
			@Parameter(hidden = true) @Auth User user,
			@Context SecurityContext sc) {
		return applicationsService.getApplicationsByPartyAndYear(tenant, partyId, year, nextKey, user, sc);
	}

	@Deprecated(forRemoval = true)
	@GET
	@Path("/applications/{application_id}/history")
	@Operation(description = "Returns the application's history, given the application id", tags = { APPLICATIONS_PRIVATE_RESOURCES })
	@ApiResponse(description = "The application's history")
	@ApiResponse(responseCode = "404", description = "Application does not exists - ErrCode: APPLICATION_NOT_FOUND_ERROR")
	public List<DetailedSdkTransitionLog> getHistoryByApplicationCode(@Parameter(description = "Current Tenant") @PathParam("tenant") String tenant,
																	  @Parameter(description = "The application id") @PathParam("application_id") Long applicationId,
																	  @Parameter(hidden = true) @Auth User user,
																	  @Context SecurityContext sc) {
		return applicationsService.getApplicationHistoryByApplicationId(tenant, applicationId, user, sc, false);
	}

	@GET
	@Path("/applications/{application_id}/movement-history")
	@Operation(description = "Returns the application's history, given the application id", tags = { APPLICATIONS_PRIVATE_RESOURCES })
	@ApiResponse(description = "The application's history")
	@ApiResponse(responseCode = "404", description = "Application does not exists - ErrCode: APPLICATION_NOT_FOUND_ERROR")
	public List<DetailedSdkTransitionLog> getMovementHistoryByApplicationCode(@Parameter(description = "Current Tenant") @PathParam("tenant") String tenant,
																	  @Parameter(description = "The application id") @PathParam("application_id") Long applicationId,
																	  @Parameter(hidden = true) @Auth User user,
																	  @Context SecurityContext sc) {
		return applicationsService.getApplicationHistoryByApplicationId(tenant, applicationId, user, sc, true);
	}

	@GET
	@Path("/applications/{application_id}/print-history")
	@Operation(description = "Returns the application's prints, given the application id", tags = { APPLICATIONS_PRIVATE_RESOURCES })
	@ApiResponse(description = "The application's generated prints")
	@ApiResponse(responseCode = "404", description = "Application does not exists - ErrCode: APPLICATION_NOT_FOUND_ERROR")
	public List<ApplicationGeneratedPrintDTO> getPrintsByApplicationCode(@Parameter(description = "Current Tenant") @PathParam("tenant") String tenant,
			@Parameter(description = "The application id") @PathParam("application_id") Long applicationId,
			@Parameter(hidden = true) @Auth User user,
			@Context SecurityContext sc) {
		return printService.getApplicationPrintsByApplicationId(tenant, applicationId, user, sc);
	}

	@GET
	@Path("/applications/{application_id}/calculation-history")
	@Operation(description = "Returns the application's calculations, given the application id", tags = { APPLICATIONS_PRIVATE_RESOURCES })
	@ApiResponse(description = "The application's generated calculations")
	@ApiResponse(responseCode = "404", description = "Application does not exists - ErrCode: APPLICATION_NOT_FOUND_ERROR")
	public List<ApplicationGeneratedCalculationDTO> getCalculationsByApplicationCode(
			@Parameter(description = "Current Tenant") @PathParam("tenant") String tenant,
			@Parameter(description = "The application id") @PathParam("application_id") Long applicationId,
			@Parameter(hidden = true) @Auth User user,
			@Context SecurityContext sc) {
		return calculationService.getApplicationCalculationsByApplicationId(tenant, applicationId, user, sc);
	}

	@GET
	@Path("/applications/{application_id}/on-going-prints")
	@Operation(description = "Returns the application's print job status list, given the application id", tags = { APPLICATIONS_PRIVATE_RESOURCES })
	@ApiResponse(description = "The application's generated prints")
	@ApiResponse(responseCode = "404", description = "Application does not exists - ErrCode: APPLICATION_NOT_FOUND_ERROR")
	public List<ApplicationGeneratedPrintDTO> getOngoingPrints(@Parameter(description = "Current Tenant") @PathParam("tenant") String tenant,
			@Parameter(description = "The application id") @PathParam("application_id") Long applicationId,
			@Parameter(hidden = true) @Auth User user,
			@Context SecurityContext sc) {
		var res = applicationsService.getApplicationWithDetailsById(tenant, applicationId, user, sc);
		List<String> requiredProfileCodes = res.getProfileList()
				.stream()
				.map(ApplicationProfileDTO::getProfileCode)
				.collect(Collectors.toList());
		List<PrintDetailsOutDTO> modulesPrint = applicationsService
				.getPrintsByModuleIdAndProcessStatus(tenant,
						applicationId,
						res.getModuleId(),
						res.getProcessStatus(),
						requiredProfileCodes.isEmpty() ? new ArrayList<>(List.of("")) : requiredProfileCodes,
						sc);
		return applicationsService
				.checkForOngoingPrints(tenant, applicationId, modulesPrint.stream().map(PrintDetailsOutDTO::getPrintCode).collect(Collectors.toList()));
	}

	@GET
	@Path("/applications/{application_id}/on-going-calculations")
	@Operation(description = "Returns the application's calculations job status list, given the application id", tags = { APPLICATIONS_PRIVATE_RESOURCES })
	@ApiResponse(description = "The application's generated prints")
	@ApiResponse(responseCode = "404", description = "Application does not exists - ErrCode: APPLICATION_NOT_FOUND_ERROR")
	public List<ApplicationGeneratedCalculationDTO> getOngoingCalculations(@Parameter(description = "Current Tenant") @PathParam("tenant") String tenant,
			@Parameter(description = "The application id") @PathParam("application_id") Long applicationId,
			@Parameter(hidden = true) @Auth User user,
			@Context SecurityContext sc) {
		var res = applicationsService.getApplicationWithDetailsById(tenant, applicationId, user, sc);
		List<String> requiredProfileCodes = res.getProfileList()
				.stream()
				.map(ApplicationProfileDTO::getProfileCode)
				.collect(Collectors.toList());
		List<CalculationDetailsOutDTO> modulesCalculation = applicationsService
				.getCalculationsByModuleIdAndProcessStatus(tenant,
						applicationId,
						res.getModuleId(),
						res.getProcessStatus(),
						requiredProfileCodes.isEmpty() ? new ArrayList<>(List.of("")) : requiredProfileCodes,
						sc);
		return applicationsService
				.checkForOngoingCalculations(tenant, applicationId,
						modulesCalculation.stream().map(CalculationDetailsOutDTO::getCalculationCode).collect(Collectors.toList()));
	}

	@POST
	@Path("/applications/{application_id}/prints/{print_code}")
	@Operation(description = "Start the creation print job", tags = { APPLICATIONS_PRIVATE_RESOURCES })
	@ApiResponse(description = "The application's generated prints")
	@ApiResponse(responseCode = "404", description = "Application does not exists - ErrCode: APPLICATION_NOT_FOUND_ERROR")
	public ApplicationGeneratedPrintDTO createPrintJob(@Parameter(description = "Current Tenant") @PathParam("tenant") String tenant,
			@Parameter(description = "The application id") @PathParam("application_id") Long applicationId,
			@Parameter(description = "The print code to print") @PathParam("print_code") String printCode,
			@Parameter(hidden = true) @Auth User user,
			@Context SecurityContext sc) {
		var res = applicationsService.getApplicationWithDetailsById(tenant, applicationId, user, sc);
		List<String> requiredProfileCodes = res.getProfileList()
				.stream()
				.map(ApplicationProfileDTO::getProfileCode)
				.collect(Collectors.toList());
		List<PrintDetailsOutDTO> modulesPrint = applicationsService
				.getPrintsByModuleIdAndProcessStatus(tenant,
						applicationId,
						res.getModuleId(),
						res.getProcessStatus(),
						requiredProfileCodes.isEmpty() ? new ArrayList<>(List.of("")) : requiredProfileCodes,
						sc);
		return printService
				.startPrintJob(tenant, applicationId, res.getPartyId(), res.getProcessStatus(), modulesPrint, printCode, user);
	}

	@POST
	@Path("/applications/{application_id}/calculations/{calculator_code}")
	@Operation(description = "Start the creation calculation job", tags = { APPLICATIONS_PRIVATE_RESOURCES })
	@ApiResponse(description = "The application's generated calculations")
	@ApiResponse(responseCode = "404", description = "Application does not exists - ErrCode: APPLICATION_NOT_FOUND_ERROR")
	public ApplicationGeneratedCalculationDTO createCalculationJob(@Parameter(description = "Current Tenant") @PathParam("tenant") String tenant,
			@Parameter(description = "The application id") @PathParam("application_id") Long applicationId,
			@Parameter(description = "The calculation code to calculate") @PathParam("calculator_code") String calculatorCode,
			@Parameter(hidden = true) @Auth User user,
			@Context SecurityContext sc) {
		var res = applicationsService.getApplicationWithDetailsById(tenant, applicationId, user, sc);
		List<String> requiredProfileCodes = res.getProfileList()
				.stream()
				.map(ApplicationProfileDTO::getProfileCode)
				.collect(Collectors.toList());
		List<CalculationDetailsOutDTO> modulesCalculation = applicationsService
				.getCalculationsByModuleIdAndProcessStatus(tenant,
						applicationId,
						res.getModuleId(),
						res.getProcessStatus(),
						requiredProfileCodes.isEmpty() ? new ArrayList<>(List.of("")) : requiredProfileCodes,
						sc);
		return calculationService
				.startCalculatorJob(tenant, applicationId, res.getProcessStatus(), modulesCalculation, calculatorCode, user);
	}

	@GET
	@Path("/applications/{application_id}/prints/{file_id}")
	@Produces({ MediaType.APPLICATION_OCTET_STREAM, MediaType.APPLICATION_JSON })
	@Operation(description = "Returns the generated print ", tags = { APPLICATIONS_PRIVATE_RESOURCES })
	@ApiResponse(description = "The attached file")
	public Response getAttachment(@Parameter(description = "Current Tenant") @PathParam("tenant") String tenant,
			@Parameter(description = "The application id") @PathParam("application_id") Long applicationId,
			@Parameter(description = "The attachment id") @PathParam("file_id") String fileId,
			@Parameter(hidden = true) @Auth User user,
			@Context SecurityContext sc) {
		return printService.getPrintFromFileStore(tenant, applicationId, fileId, user);
	}

	@GET
	@Path("/applications/{application_id}/calculations/{calculation_job_uuid}/render")
	@Operation(description = "Returns the generated calculation ", tags = { APPLICATIONS_PRIVATE_RESOURCES })
	@ApiResponse(description = "The calculation content")
	public ApplicationCalculationRenderPublicDTO getCalculationRender(@Parameter(description = "Current Tenant") @PathParam("tenant") String tenant,
			@Parameter(description = "The application id") @PathParam("application_id") Long applicationId,
			@Parameter(description = "The calculation job uuid") @PathParam("calculation_job_uuid") String calculationJobUuid,
			@Parameter(hidden = true) @Auth User user,
			@Context SecurityContext sc) {
		return calculationService.getCalculationRenderByJobUuidReadyStatus(tenant, applicationId, user, calculationJobUuid);
	}

	@GET
	@Path("/applications/{application_id}/calculations/{calculation_job_uuid}/raw")
	@Operation(description = "Returns the generated calculation ", tags = { APPLICATIONS_PRIVATE_RESOURCES })
	@ApiResponse(description = "The calculation content")
	public ApplicationCalculationRawPublicDTO getCalculation(@Parameter(description = "Current Tenant") @PathParam("tenant") String tenant,
			@Parameter(description = "The application id") @PathParam("application_id") Long applicationId,
			@Parameter(description = "The calculation job uuid") @PathParam("calculation_job_uuid") String calculationJobUuid,
			@Parameter(hidden = true) @Auth User user,
			@Context SecurityContext sc) {
		return calculationService.getCalculationRawByJobUuidReadyStatus(tenant, applicationId, user, calculationJobUuid);
	}

	@GET
	@Path("/applications/{application_id}/transitions")
	@Operation(description = "Returns the application's available transitions, given the application code", tags = { APPLICATIONS_PRIVATE_RESOURCES })
	@ApiResponse(description = "The available transitions")
	@ApiResponse(responseCode = "404", description = "Application does not exists - ErrCode: APPLICATION_NOT_FOUND_ERROR")
	public List<Transition> getAvailableTransitionByApplicationCode(@Parameter(description = "Current Tenant") @PathParam("tenant") String tenant,
			@Parameter(description = "The application id") @PathParam("application_id") Long applicationId,
			@Parameter(hidden = true) @Auth User user,
			@Context SecurityContext sc) {
		return applicationsService.getAvailableTransitionListByProcessId(tenant, applicationId, user, APPLICATIONS_RESOURCES_SCOPE);
	}

	@GET
	@Path("/applications/{application_id}/is-in-transition")
	@Operation(description = "Returns the application' in transition flag", tags = { APPLICATIONS_PRIVATE_RESOURCES })
	@ApiResponse(description = "The current flag")
	@ApiResponse(responseCode = "404", description = "Application does not exists - ErrCode: APPLICATION_NOT_FOUND_ERROR")
	public ApplicationInTransitionDTO getApplicationTransitionFlag(@Parameter(description = "Current Tenant") @PathParam("tenant") String tenant,
			@Parameter(description = "The application id") @PathParam("application_id") Long applicationId,
			@Parameter(hidden = true) @Auth User user,
			@Context SecurityContext sc) {
		return applicationsService.getApplicationInTransition(tenant, applicationId, user);
	}

	@PATCH
	@Path("/applications/{application_id}/progress/{transition_id}")
	@Operation(description = "Updates the process status of the application", tags = { APPLICATIONS_PRIVATE_RESOURCES })
	@ApiResponse(description = "The process status of the task instance has been updated")
	@ApiResponse(responseCode = "404", description = "Application not found - ErrCode: APPLICATION_NOT_FOUND_ERROR")
	@ApiResponse(responseCode = "404", description = "Transition not found - ErrCode: TRANSITION_NOT_FOUND_ERROR")
	@ApiResponse(responseCode = "500", description = "Error progressing Application - errorCode: PROGRESS_WORKFLOW_ERROR")
	public Response patchProgressApplication(ProgressApplicationDTO payload,
			@Parameter(description = "Current Tenant") @PathParam("tenant") String tenant,
			@Parameter(description = "The application id") @PathParam("application_id") Long applicationId,
			@Parameter(description = "Id of the transition") @PathParam("transition_id") Integer transitionId,
			@Parameter(hidden = true) @Auth User user,
			@Context SecurityContext sc) throws Exception {
		applicationsService.progress(tenant, applicationId, transitionId, user, APPLICATIONS_RESOURCES_SCOPE, payload, ProgressTypeEnum.ASYNC);
		return Response.ok().build();
	}

	@PUT
	@Path("/applications/{application_id}/progress/{transition_id}")
	@Operation(description = "Updates the process status of the application. Same API of PATCH", tags = { APPLICATIONS_PRIVATE_RESOURCES })
	@ApiResponse(description = "The process status of the task instance has been updated")
	@ApiResponse(responseCode = "404", description = "Application not found - ErrCode: APPLICATION_NOT_FOUND_ERROR")
	@ApiResponse(responseCode = "404", description = "Transition not found - ErrCode: TRANSITION_NOT_FOUND_ERROR")
	@ApiResponse(responseCode = "500", description = "Error progressing Application - errorCode: PROGRESS_WORKFLOW_ERROR")
	public Response putProgressApplication(ProgressApplicationDTO payload,
										@Parameter(description = "Current Tenant") @PathParam("tenant") String tenant,
										@Parameter(description = "The application id") @PathParam("application_id") Long applicationId,
										@Parameter(description = "Id of the transition") @PathParam("transition_id") Integer transitionId,
										@Parameter(hidden = true) @Auth User user,
										@Context SecurityContext sc) throws Exception {
		applicationsService.progress(tenant, applicationId, transitionId, user, APPLICATIONS_RESOURCES_SCOPE, payload, ProgressTypeEnum.ASYNC);
		return Response.ok().build();
	}

	@GET
	@Path("/applications/{application_id}/anomalies")
	@Operation(description = "Returns the list of application's anomalies", tags = { ANOMALIES_TAG })
	@ApiResponse(description = "The list of application's compile statuses")
	public List<AnomalyDTO> getApplicationCompileStatusById(
			@Parameter(description = "Current Tenant") @PathParam("tenant") String tenant,
			@Parameter(description = "The application id") @PathParam("application_id") Long applicationId,
			@Parameter(hidden = true) @Auth User user) {
		return anomalyHandler.getAnomaliesForApp(tenant, applicationId);
	}

	@GET
	@Path("/applications/{application_id}/amendment/modules")
	@Operation(description = "Returns the list of amendable modules", tags = { AMENDMENT_TAG })
	@ApiResponse(description = "The list of amendable modules")
	public InfiniteListResults<ModuleWithDetailDTO> getAmendmentModules(@Parameter(description = "Current Tenant") @PathParam("tenant") String tenant,
			@Parameter(description = "The application id") @PathParam("application_id") Long applicationId,
			@Parameter(description = "The next key") @QueryParam("next_key") String nextKey,
			@Parameter(hidden = true) @Auth User user,
			@Context SecurityContext sc) {
		return amendmentService.getAmendmentModules(tenant, applicationId, nextKey, sc);
	}
}
