package com.abacogroup.agri.applications.bundles.model.chilldmodule;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.List;

/**
 * @author Mattia Perini
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class BundleChildrenModulesMessage {
	@Builder.Default
	private List<BundleChildModuleInDTO> childrenModules = new ArrayList<>();
}
