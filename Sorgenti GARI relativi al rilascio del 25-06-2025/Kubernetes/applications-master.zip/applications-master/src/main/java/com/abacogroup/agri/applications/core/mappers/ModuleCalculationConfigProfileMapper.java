package com.abacogroup.agri.applications.core.mappers;

import com.abacogroup.agri.applications.core.model.dto.ModuleCalculationConfigProfileDTO;
import com.abacogroup.agri.applications.db.ntt.ModuleCalculationConfigProfileNTT;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

@Mapper(uses = AbsoluteDateMapper.class)
public interface ModuleCalculationConfigProfileMapper extends EntityMapper<ModuleCalculationConfigProfileDTO, ModuleCalculationConfigProfileNTT> {

	ModuleCalculationConfigProfileMapper INSTANCE = Mappers.getMapper(ModuleCalculationConfigProfileMapper.class);

	@InheritInverseConfiguration()
	ModuleCalculationConfigProfileDTO entityToDto(ModuleCalculationConfigProfileNTT entity);

	@Mapping(source = "moduleCalculationConfigId", target = "module_calculation_config_id")
	@Mapping(source = "requiredProfileCode", target = "required_profile_code")
	ModuleCalculationConfigProfileNTT dtoToEntity(ModuleCalculationConfigProfileDTO dto);

}
