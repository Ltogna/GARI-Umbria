package com.abacogroup.agri.applications.db.ntt;

import java.util.Optional;

import com.abacogroup.agri.applications.db.ntt.applications.IIdRs;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author Gennaro Tamburrelli
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ModuleFormConfigParamNTT implements IIdRs<Void> {

	private Long module_form_config_id;
	private String parameter_name;
	private String parameter_value;

	@Override
	public void setKey(Void id) {
		// not in use
	}

	@Override
	public Optional<Void> getKey() {
		return Optional.empty();
	}

}
