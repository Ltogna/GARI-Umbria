package com.abacogroup.agri.applications.core.mappers;

import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import com.abacogroup.agri.applications.db.ntt.ModuleProfileNTT;
import com.abacogroup.applicationworkflowsdk.model.io.output.ModuleProfileDTO;

@Mapper
public interface ModuleProfileMapper extends EntityMapper<ModuleProfileDTO, ModuleProfileNTT> {

	ModuleProfileMapper INSTANCE = Mappers.getMapper(ModuleProfileMapper.class);

	@InheritInverseConfiguration()
	ModuleProfileDTO entityToDto(ModuleProfileNTT entity);

	@Mapping(source = "pkid", target = "pkid")
	@Mapping(source = "moduleId", target = "module_id")
	@Mapping(source = "profileCode", target = "profile_code")
	@Mapping(source = "profileCodeDescription", target = "profile_code_description")
	@Mapping(source = "labelExposed", target = "fl_label_exposed")
	ModuleProfileNTT dtoToEntity(ModuleProfileDTO dto);

	default Boolean map(Integer value) {
		if (value != null)
			return value.intValue() != 0;
		return null;
	}

	default Integer map(Boolean value) {
		if (value != null)
			return value ? 1 : 0;

		return null;
	}

}
