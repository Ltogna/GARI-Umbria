package com.abacogroup.agri.applications.core.exceptions;

/**
 * @author Mauro Pozzana
 */
public class FileStoreMetadataNotFoundException extends Exception {
	public FileStoreMetadataNotFoundException(String message) {
		super(message);
	}
}
