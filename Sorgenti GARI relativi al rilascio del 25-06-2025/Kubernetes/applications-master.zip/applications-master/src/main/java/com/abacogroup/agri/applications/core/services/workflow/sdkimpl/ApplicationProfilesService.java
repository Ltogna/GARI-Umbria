package com.abacogroup.agri.applications.core.services.workflow.sdkimpl;

import java.util.List;
import java.util.stream.Collectors;

import org.jdbi.v3.core.Jdbi;

import com.abacogroup.agri.applications.core.exceptions.ProfileCodeNotExistsRuntimeException;
import com.abacogroup.agri.applications.core.model.dto.ApplicationProfileDTO;
import com.abacogroup.agri.applications.core.services.crud.ApplicationProfilesCrudService;
import com.abacogroup.agri.applications.core.services.crud.ApplicationsCrudService;
import com.abacogroup.agri.applications.core.services.crud.CrudServiceContainer;
import com.abacogroup.agri.applications.core.services.crud.ModuleProfilesCrudService;
import com.abacogroup.applicationworkflowsdk.model.io.output.ModuleProfileDTO;
import com.abacogroup.applicationworkflowsdk.service.UpsertApplicationProfiles;
import com.abacogroup.dropwizard.auth.sso2.User;

import lombok.extern.slf4j.Slf4j;

/**
 * @author Gennaro Tamburrelli
 */
@Slf4j
public class ApplicationProfilesService implements UpsertApplicationProfiles {
	private final Jdbi jdbi;
	private final ApplicationsCrudService applicationsCrudService;
	private final ApplicationProfilesCrudService applicationProfilesCrudService;
	private final ModuleProfilesCrudService moduleProfilesCrudService;

	public ApplicationProfilesService(Jdbi jdbi, CrudServiceContainer crudServiceContainer) {
		this.jdbi = jdbi;
		this.applicationsCrudService = crudServiceContainer.getApplicationsCrudService();
		this.applicationProfilesCrudService = crudServiceContainer.getApplicationProfilesCrudService();
		this.moduleProfilesCrudService = crudServiceContainer.getModuleProfilesCrudService();
	}

	public List<ModuleProfileDTO> getModuleProfileByModuleId(String tenant, Long moduleId) {
		return moduleProfilesCrudService.find(tenant, moduleId);
	}

	public void putApplicationProfiles(String tenant, Long applicationId, List<String> profileCodeList, User user) {
		putApplicationProfiles(tenant, applicationId, profileCodeList, user, false);
	}

	public void deleteAndAddpplicationProfiles(String tenant, Long applicationId, List<String> toRemove, List<String> toAdd, User user) {
		jdbi.useTransaction(h -> {
			if (toRemove != null) {
				toRemove.forEach(profileCode -> deleteApplicationProfile(tenant, applicationId, profileCode, user));
			}

			if (toAdd != null) {
				doAddProfiles(tenant, applicationId, toAdd, user, true);
			}
		});
	}

	public void putApplicationProfiles(String tenant, Long applicationId, List<String> profileCodeList, User user,
			boolean upsert) {
		jdbi.useTransaction(handle -> {
			if (!upsert) {
				log.info("logically delete all profiles...");
				applicationProfilesCrudService.bulkLogicallyDeleteByApplicationId(tenant, applicationId, user.getUserId());
				log.info("logically delete all profiles...done");
			}

			doAddProfiles(tenant, applicationId, profileCodeList, user, upsert);
		});
	}

	private void doAddProfiles(String tenant, Long applicationId, List<String> profileCodeList, User user, boolean upsert) {
		log.info("insert by profile code list...");
		var application = applicationsCrudService.findWithDetailsByApplicationId(tenant, applicationId);
		var moduleProfileList = getModuleProfileByModuleId(tenant, application.getModuleId())
				.stream()
				.map(ModuleProfileDTO::getProfileCode)
				.collect(Collectors.toList());
		profileCodeList.forEach(code -> {
			if (moduleProfileList.contains(code)) {
				if (upsert) { // this will only update dates
					var optAppProfile = applicationProfilesCrudService.findByUnique(tenant, applicationId, code);
					if (optAppProfile.isPresent()) {
						var appProfile = optAppProfile.get();
						applicationProfilesCrudService.update(appProfile.getPkid(), appProfile, user.getUserId());
					} else {
						applicationProfilesCrudService.insert(ApplicationProfileDTO.builder()
								.profileCode(code)
								.applicationId(application.getApplicationId())
								.build(), user.getUserId());
					}
				} else { // else insert
					applicationProfilesCrudService.insert(ApplicationProfileDTO.builder()
							.profileCode(code)
							.applicationId(application.getApplicationId())
							.build(), user.getUserId());
				}
			} else {
				throw new ProfileCodeNotExistsRuntimeException();
			}
		});
	}

	@Override
	public void upsertApplicationProfiles(String tenant, Long applicationId, List<String> profileCodeList, User user) {
		this.putApplicationProfiles(tenant, applicationId, profileCodeList, user, true);
	}

	@Override
	public void deleteApplicationProfile(String tenant, Long applicationId, String profileCode, User user) {
		applicationProfilesCrudService.findByUnique(tenant, applicationId, profileCode)
				.ifPresent(prf -> applicationProfilesCrudService.delete(prf.getPkid(), user.getUserId()));
	}

}
