package com.abacogroup.agri.applications.core.services.crud;

import com.abacogroup.agri.applications.core.exceptions.ObjectNotFoundException;
import com.abacogroup.agri.applications.core.mappers.ModulePrintConfigProfileMapper;
import com.abacogroup.agri.applications.core.model.dto.ModulePrintConfigProfileDTO;
import com.abacogroup.agri.applications.db.dao.ModulePrintConfigProfileDAO;
import com.abacogroup.agri.applications.db.ntt.ModulePrintConfigProfileNTT;
import com.abacogroup.agri.applications.db.ntt.compoundkeys.PrintConfigProfileKey;
import lombok.extern.slf4j.Slf4j;

import java.util.List;
import java.util.Optional;

/**
 * @author Gennaro Tamburrelli
 */
@Slf4j
public class ModulePrintConfigProfilesCrudService
		extends AbstractCrudService<ModulePrintConfigProfileNTT, Void, ModulePrintConfigProfileDTO, ModulePrintConfigProfileMapper, PrintConfigProfileKey> {

	public ModulePrintConfigProfilesCrudService(ModulePrintConfigProfileDAO dao, ModulePrintConfigProfileMapper mapper) {
		super(dao, mapper);
	}

	@Override
	protected boolean hasPrimaryKey() {
		return false;
	}

	@Override
	protected Void retrievePrimaryKey(PrintConfigProfileKey customKey) {
		return null;
	}

	@Override
	protected Optional<ModulePrintConfigProfileNTT> findRsByCustomKey(PrintConfigProfileKey customKey) {
		return ((ModulePrintConfigProfileDAO) this.dao).findById(customKey.getModule_print_config_id(), customKey.getRequired_profile_code())
				.stream()
				.findFirst();
	}

	@Override
	protected void deleteByCustomKey(PrintConfigProfileKey customKey) {
		((ModulePrintConfigProfileDAO) this.dao).deleteById(customKey.getModule_print_config_id(), customKey.getRequired_profile_code());
	}

	@Override
	protected void setCustomSearchKey(ModulePrintConfigProfileNTT rs, PrintConfigProfileKey customKey) {
		rs.setModule_print_config_id(customKey.getModule_print_config_id());
		rs.setRequired_profile_code(customKey.getRequired_profile_code());
	}

	public ModulePrintConfigProfileDTO insert(ModulePrintConfigProfileDTO in) {
		log.info("Invoking insert with params in: {}", in);
		return this.insert(in, PrintConfigProfileKey.builder()
				.module_print_config_id(in.getModulePrintConfigId())
				.required_profile_code(in.getRequiredProfileCode())
				.build());
	}

	public ModulePrintConfigProfileDTO update(ModulePrintConfigProfileDTO in) {
		log.info("Invoking update with params in: {}", in);
		return this.update(null, in, PrintConfigProfileKey.builder()
				.module_print_config_id(in.getModulePrintConfigId())
				.required_profile_code(in.getRequiredProfileCode())
				.build());
	}

	public void delete(PrintConfigProfileKey key) {
		log.info("Invoking delete with params key: {}", key);
		this.delete(null, key);
	}

	public void deleteByModulePrintConfigId(Long modulePrintConfigId) {
		((ModulePrintConfigProfileDAO) this.dao).deleteByModulePrintConfigId(modulePrintConfigId);
	}

	public ModulePrintConfigProfileDTO findById(String tenant, PrintConfigProfileKey id) throws ObjectNotFoundException {
		log.info("Invoking findById with params tenant: {} id: {}", tenant, id);
		return returnOptionalRecord(((ModulePrintConfigProfileDAO) this.dao).findById(tenant, id.getModule_print_config_id(), id.getRequired_profile_code()))
				.orElseThrow(OBJECT_NOT_FOUND_EXCEPTION_SUPPLIER);
	}

	public List<ModulePrintConfigProfileDTO> find(String tenant, Long formConfig) {
		log.info("Invoking findById with params tenant: {} formConfigId: {}", tenant, formConfig);
		return returnMappedList(((ModulePrintConfigProfileDAO) this.dao).find(tenant, formConfig));
	}

}
