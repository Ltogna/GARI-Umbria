package com.abacogroup.agri.applications.core.model;

/**
 * @author Gennaro Tamburrelli
 */
public enum CompileStatusEnum {
	PROGRESS,
	COMPLETED
}
