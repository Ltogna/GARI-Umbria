package com.abacogroup.agri.applications.core.model;

import lombok.Getter;

/**
 * @author Gennaro Tamburrelli
 */
@Getter
public enum ProcessTransitionEnum {
	IN_TRANSITION(1),
	NOT_IN_TRANSITION(0);

	private final int fl;

	ProcessTransitionEnum(int i) {
		this.fl = i;
	}

}
