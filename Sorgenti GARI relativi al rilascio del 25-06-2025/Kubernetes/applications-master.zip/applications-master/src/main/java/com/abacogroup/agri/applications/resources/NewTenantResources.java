package com.abacogroup.agri.applications.resources;

import jakarta.annotation.security.PermitAll;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

import com.abacogroup.agri.applications.bundles.processor.amendable.AmendableModuleNewTenantProcessor;
import com.abacogroup.agri.applications.bundles.processor.anomaly.AnomalyCatalogNewTenantProcessor;
import com.abacogroup.agri.applications.bundles.processor.env.ApplicationEnvNewTenantProcessor;
import com.abacogroup.agri.applications.bundles.processor.module.ModuleNewTenantProcessor;
import com.abacogroup.agri.applications.bundles.processor.sector.SectorNewTenantProcessor;
import com.abacogroup.agri.applications.bundles.processor.workflow.WorkflowNewTenantProcessor;
import com.abacogroup.bundles.listener.tenant.TenantMessage;
import com.abacogroup.dropwizard.auth.sso2.User;
import com.codahale.metrics.annotation.Timed;

import io.dropwizard.auth.Auth;
import io.swagger.v3.oas.annotations.Parameter;

@Timed
@Path("{tenant}/api-priv/v1/newTenant")
@PermitAll
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class NewTenantResources {

	private final WorkflowNewTenantProcessor workflowNewTenantProcessor;
	private final SectorNewTenantProcessor sectorNewTenantProcessor;
	private final ModuleNewTenantProcessor moduleNewTenantProcessor;
	private final AnomalyCatalogNewTenantProcessor anomalyCatalogNewTenantProcessor;
	private final ApplicationEnvNewTenantProcessor applicationEnvNewTenantProcessor;
	private final AmendableModuleNewTenantProcessor amendableModuleNewTenantProcessor;

	public NewTenantResources(WorkflowNewTenantProcessor workflowNewTenantProcessor,
			SectorNewTenantProcessor sectorNewTenantProcessor,
			ModuleNewTenantProcessor moduleNewTenantProcessor,
			AnomalyCatalogNewTenantProcessor anomalyCatalogNewTenantProcessor, ApplicationEnvNewTenantProcessor applicationEnvNewTenantProcessor,
			AmendableModuleNewTenantProcessor amendableModuleNewTenantProcessor) {
		this.workflowNewTenantProcessor = workflowNewTenantProcessor;
		this.sectorNewTenantProcessor = sectorNewTenantProcessor;
		this.moduleNewTenantProcessor = moduleNewTenantProcessor;
		this.anomalyCatalogNewTenantProcessor = anomalyCatalogNewTenantProcessor;
		this.applicationEnvNewTenantProcessor = applicationEnvNewTenantProcessor;
		this.amendableModuleNewTenantProcessor = amendableModuleNewTenantProcessor;

	}

	@GET
	public Response replicateTenant(@PathParam("tenant") String tenant,
			@Parameter(hidden = true) @Auth User user) {
		TenantMessage tm = new TenantMessage();
		tm.setTenantId(tenant);
		workflowNewTenantProcessor.onMessage(tm);
		sectorNewTenantProcessor.onMessage(tm);
		moduleNewTenantProcessor.onMessage(tm);
		anomalyCatalogNewTenantProcessor.onMessage(tm);
		applicationEnvNewTenantProcessor.onMessage(tm);
		amendableModuleNewTenantProcessor.onMessage(tm);

		return Response.noContent()
				.status(Response.Status.OK)
				.build();
	}

}
