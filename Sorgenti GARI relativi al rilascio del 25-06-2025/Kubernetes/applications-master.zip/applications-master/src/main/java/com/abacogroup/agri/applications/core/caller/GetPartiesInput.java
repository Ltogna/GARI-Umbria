package com.abacogroup.agri.applications.core.caller;

import com.abacogroup.applicationsupport.model.io.callerinput.companyfile.BaseCompanyFileInput;
import com.abacogroup.jaxrsutils.callerv2.ICallerInput;

import jakarta.validation.constraints.NotNull;

import java.util.Map;
import java.util.Objects;

/**
 * @author Alexandru Paraschiv
 */
public class GetPartiesInput extends BaseCompanyFileInput implements ICallerInput {
	public static final String RESOURCE = "/{TENANT}/public/v1/parties/directory";
	private final String searchCode;
	private final String searchDescription;
	private final String legacyUrl;

	public GetPartiesInput(@NotNull String tenant, @NotNull Long partyId, @NotNull String authToken,
			@NotNull String legacyUrl, @NotNull String searchCode, @NotNull String searchDescription) {
		super(tenant, partyId, authToken, legacyUrl);
		this.searchCode = searchCode;
		this.searchDescription = searchDescription;
		this.legacyUrl = legacyUrl;
	}

	@Override
	public Map<String, Object> getPathVariablesMap() {
		return Map.of("TENANT", this.tenant);
	}

	@Override
	public String provideAuthToken() {
		return this.authToken;
	}

	@Override
	public Map<String, Object> getQueryParamsMap() {
		return Map.of("search_code", this.searchCode,
				"search_description", this.searchDescription);
	}

	@Override
	public String getUrl() {
		if (this.legacyUrl.contains(RESOURCE)) {
			return this.legacyUrl;
		} else {
			return this.legacyUrl + RESOURCE;
		}
	}

	@Override
	public String getHttpMethod() {
		return "GET";
	}

	@Override
	public boolean equals(Object o) {
		if (this == o)
			return true;
		if (!(o instanceof GetPartiesInput))
			return false;

		GetPartiesInput getPartiesInput = (GetPartiesInput) o;

		return Objects.equals(tenant, getPartiesInput.tenant) &&
				Objects.equals(partyId, getPartiesInput.partyId) &&
				Objects.equals(searchCode, getPartiesInput.searchCode) &&
				Objects.equals(searchDescription, getPartiesInput.searchDescription);
	}

	@Override
	public int hashCode() {
		return Objects.hash(searchCode, searchDescription);
	}
}
