package com.abacogroup.agri.applications.bundles.model.chilldmodule;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author Mattia Perini
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class BundleChildModuleInDTO {
	private String sectorCode;
	private String moduleCode;
	private String parentModuleCode;
	private String oldParentModuleCode;
}
