package com.abacogroup.agri.applications.core.services;

import static com.abacogroup.applicationworkflowsdk.model.Constants.AUTHORIZATION_PREFIX;

import java.util.Optional;
import java.util.concurrent.TimeUnit;

import com.abacogroup.agri.applications.core.caller.CheckCanReadPartyCaller;
import com.abacogroup.agri.applications.core.caller.CheckCanReadPartyInput;
import com.abacogroup.agri.applications.core.exceptions.ActionNotAuthorizedRuntimeException;
import com.abacogroup.agri.applications.core.exceptions.ObjectNotFoundException;
import com.abacogroup.agri.applications.core.model.CheckCanReadConfig;
import com.abacogroup.agri.applications.core.model.CheckCanReadDTO;
import com.abacogroup.agri.applications.core.model.CheckCanReadKey;
import com.abacogroup.agri.applications.core.model.dto.ApplicationEnvDTO;
import com.abacogroup.agri.applications.core.services.crud.ApplicationEnvCrudService;
import com.abacogroup.agri.applications.db.ntt.compoundkeys.ApplicationEnvKey;
import com.abacogroup.dropwizard.auth.sso2.User;
import com.github.benmanes.caffeine.cache.Cache;
import com.github.benmanes.caffeine.cache.Caffeine;

/**
 * @author Gennaro Tamburrelli
 */
public class CheckPartyService {

	private final CheckCanReadPartyCaller checkCanReadPartyCaller;
	private final ApplicationEnvCrudService applicationEnvCrudService;
	private final Cache<CheckCanReadKey, CheckCanReadDTO> checkCache;

	private final CheckCanReadConfig checkCanReadConfig;
	private final CheckCanReadConfig checkCanReadAllPartiesConfig;

	public CheckPartyService(CheckCanReadPartyCaller checkCanReadPartyCaller,
			ApplicationEnvCrudService applicationEnvCrudService,
			CheckCanReadConfig checkCanReadConfig, CheckCanReadConfig checkCanReadAllPartiesConfig) {
		this.checkCanReadPartyCaller = checkCanReadPartyCaller;
		this.applicationEnvCrudService = applicationEnvCrudService;
		this.checkCanReadConfig = checkCanReadConfig;
		this.checkCanReadAllPartiesConfig = checkCanReadAllPartiesConfig;
		this.checkCache = Caffeine.newBuilder()
				.maximumSize(100L)
				.expireAfterAccess(10, TimeUnit.MINUTES)
				.build();
	}

	private CheckCanReadDTO makeCall(String tenant, Long partyId, User user) {
		try {
			ApplicationEnvDTO conf = ApplicationEnvDTO.builder()
					.value(this.checkCanReadConfig.getOverriddenUrl())
					.build();
			if (Boolean.FALSE.equals(this.checkCanReadConfig.getOverride())) {
				conf = applicationEnvCrudService.findEnvironmentByKey(ApplicationEnvKey.builder()
						.key_(this.checkCanReadConfig.getKey())
						.tenant_id(tenant)
						.fl_client(0)
						.build());
			}
			var input = CheckCanReadPartyInput.builder()
					.authToken(AUTHORIZATION_PREFIX + user.getAuthToken())
					.partyId(partyId)
					.url(conf.getValue())
					.tenant(tenant)
					.build();
			return this.checkCanReadPartyCaller.makeCall(input);
		} catch (Exception e) {
			throw new RuntimeException(e.getMessage(), e);
		}
	}

	public void checkCanReadParty(String tenant, Long partyId, User user) {
		if (Boolean.TRUE.equals(this.checkCanReadConfig.getActive())) {
			var result = this.checkCache.get(CheckCanReadKey.builder()
					.partyId(partyId)
					.tenant(tenant)
					.username(user.getUserId())
					.build(),
					key -> this.makeCall(key.getTenant(), key.getPartyId(), user));
			if (!Boolean.TRUE.equals(Optional.ofNullable(result).map(CheckCanReadDTO::getCanRead).orElse(false))) {
				throw new ActionNotAuthorizedRuntimeException("");
			}
		}
	}

	private CheckCanReadDTO verifyCanReadAllParties(String tenant, User user) throws ObjectNotFoundException {
		ApplicationEnvDTO conf = ApplicationEnvDTO.builder()
				.value(this.checkCanReadAllPartiesConfig.getOverriddenUrl())
				.build();
		if (Boolean.FALSE.equals(this.checkCanReadAllPartiesConfig.getOverride())) {
			conf = applicationEnvCrudService.findEnvironmentByKey(ApplicationEnvKey.builder()
					.key_(this.checkCanReadAllPartiesConfig.getKey())
					.tenant_id(tenant)
					.fl_client(0)
					.build());
		}
		var input = CheckCanReadPartyInput.builder()
				.authToken(AUTHORIZATION_PREFIX + user.getAuthToken())
				.url(conf.getValue())
				.partyId(-1L) // needed for Map.of
				.tenant(tenant)
				.build();
		return this.checkCanReadPartyCaller.makeCall(input);
	}

	public void canReadAllParties(String tenant, User user) throws ObjectNotFoundException {
		if (Boolean.TRUE.equals(this.checkCanReadAllPartiesConfig.getActive())) {
			var result = verifyCanReadAllParties(tenant, user);
			if (!Boolean.TRUE.equals(Optional.ofNullable(result).map(CheckCanReadDTO::getCanRead).orElse(false))) {
				throw new ActionNotAuthorizedRuntimeException("");
			}
		}
	}
}
