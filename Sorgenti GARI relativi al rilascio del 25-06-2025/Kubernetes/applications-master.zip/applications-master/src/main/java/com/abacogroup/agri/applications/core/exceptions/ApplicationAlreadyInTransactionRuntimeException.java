package com.abacogroup.agri.applications.core.exceptions;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.ws.rs.core.Response;

public class ApplicationAlreadyInTransactionRuntimeException extends AbstractException {

	private static final ErrorBody BODY = new ErrorBody();

	public ApplicationAlreadyInTransactionRuntimeException(String message) {
		super(Response.Status.CONFLICT, BODY, message);
	}

	@Schema(name = "CApplicationAlreadyInTransactionRuntimeExceptionErrorBody")
	public static class ErrorBody implements ExceptionErrorBody {
		private static final String ERR = "APPLICATION_ALREADY_IN_TRANSACTION_ERROR";

		@Override
		@Schema(allowableValues = ERR)
		public String getErrorCode() {
			return ERR;
		}
	}
}
