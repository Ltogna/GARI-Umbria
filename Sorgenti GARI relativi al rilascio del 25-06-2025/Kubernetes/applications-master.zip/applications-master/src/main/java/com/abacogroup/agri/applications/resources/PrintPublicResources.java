package com.abacogroup.agri.applications.resources;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import com.abacogroup.agri.applications.core.model.dto.ApplicationGeneratedPrintDTO;
import com.abacogroup.agri.applications.core.model.dto.ApplicationProfileDTO;
import com.abacogroup.agri.applications.core.model.dto.publics.PrintDetailsOutDTO;
import com.abacogroup.agri.applications.core.services.ApplicationsService;
import com.abacogroup.agri.applications.core.services.print.PrintService;
import com.abacogroup.dropwizard.auth.sso2.User;
import com.codahale.metrics.annotation.Timed;

import io.dropwizard.auth.Auth;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import jakarta.annotation.security.PermitAll;
import jakarta.annotation.security.RolesAllowed;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.Context;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.core.SecurityContext;

@Timed
@Path("/{tenant}/public/v1/")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
@PermitAll
@RolesAllowed("APPLICATIONS|USER")
public class PrintPublicResources {

	public static final String PRINT_TAG = "Prints Public Resources";

	final private ApplicationsService applicationsService;
	final private PrintService printService;

	public PrintPublicResources(ApplicationsService applicationsService, PrintService printService) {
		this.applicationsService = applicationsService;
		this.printService = printService;
	}

	@POST
	@Path("/applications/{application_id}/prints/{print_code}")
	@Operation(description = "Start the creation print job", tags = { PRINT_TAG })
	@ApiResponse(description = "The application's generated prints")
	@ApiResponse(responseCode = "404", description = "Application does not exists - ErrCode: APPLICATION_NOT_FOUND_ERROR")
	public ApplicationGeneratedPrintDTO createPrintJob(@Parameter(description = "Current Tenant") @PathParam("tenant") String tenant,
			@Parameter(description = "The application id") @PathParam("application_id") Long applicationId,
			@Parameter(description = "The print code to print") @PathParam("print_code") String printCode,
			@Parameter(hidden = true) @Auth User user,
			@Context SecurityContext sc) {
		var res = applicationsService.getApplicationWithDetailsById(tenant, applicationId, user, sc);
		List<String> requiredProfileCodes = res.getProfileList()
				.stream()
				.map(ApplicationProfileDTO::getProfileCode)
				.collect(Collectors.toList());
		List<PrintDetailsOutDTO> modulesPrint = applicationsService
				.getPrintsByModuleIdAndProcessStatus(tenant,
						applicationId,
						res.getModuleId(),
						res.getProcessStatus(),
						requiredProfileCodes.isEmpty() ? new ArrayList<>(List.of("")) : requiredProfileCodes,
						sc);
		return printService
				.startPrintJob(tenant, applicationId, res.getPartyId(), res.getProcessStatus(), modulesPrint, printCode, user);
	}

	@GET
	@Path("/applications/{application_id}/on-going-prints")
	@Operation(description = "Returns the application's print job status list, given the application id", tags = { PRINT_TAG })
	@ApiResponse(description = "The application's generated prints")
	@ApiResponse(responseCode = "404", description = "Application does not exists - ErrCode: APPLICATION_NOT_FOUND_ERROR")
	public List<ApplicationGeneratedPrintDTO> getOngoingPrints(@Parameter(description = "Current Tenant") @PathParam("tenant") String tenant,
			@Parameter(description = "The application id") @PathParam("application_id") Long applicationId,
			@Parameter(hidden = true) @Auth User user,
			@Context SecurityContext sc) {
		var res = applicationsService.getApplicationWithDetailsById(tenant, applicationId, user, sc);
		List<String> requiredProfileCodes = res.getProfileList()
				.stream()
				.map(ApplicationProfileDTO::getProfileCode)
				.collect(Collectors.toList());
		List<PrintDetailsOutDTO> modulesPrint = applicationsService
				.getPrintsByModuleIdAndProcessStatus(tenant,
						applicationId,
						res.getModuleId(),
						res.getProcessStatus(),
						requiredProfileCodes.isEmpty() ? new ArrayList<>(List.of("")) : requiredProfileCodes,
						sc);
		return applicationsService
				.checkForOngoingPrints(tenant, applicationId, modulesPrint.stream().map(PrintDetailsOutDTO::getPrintCode).collect(Collectors.toList()));
	}

	@GET
	@Path("/applications/{application_id}/prints/{file_id}")
	@Produces({ MediaType.APPLICATION_OCTET_STREAM, MediaType.APPLICATION_JSON })
	@Operation(description = "Returns the generated print ", tags = { PRINT_TAG })
	@ApiResponse(description = "The attached file")
	public Response getAttachment(@Parameter(description = "Current Tenant") @PathParam("tenant") String tenant,
			@Parameter(description = "The application id") @PathParam("application_id") Long applicationId,
			@Parameter(description = "The attachment id") @PathParam("file_id") String fileId,
			@Parameter(hidden = true) @Auth User user,
			@Context SecurityContext sc) {
		return printService.getPrintFromFileStore(tenant, applicationId, fileId, user);
	}

	@GET
	@Path("/applications/{application_id}/print-history")
	@Operation(description = "Returns the application's prints, given the application id", tags = { PRINT_TAG })
	@ApiResponse(description = "The application's generated prints")
	@ApiResponse(responseCode = "404", description = "Application does not exists - ErrCode: APPLICATION_NOT_FOUND_ERROR")
	public List<ApplicationGeneratedPrintDTO> getPrintsByApplicationCodeAndPrintCode(
			@Parameter(description = "Current Tenant") @PathParam("tenant") String tenant,
			@Parameter(description = "The application id") @PathParam("application_id") Long applicationId,
			@Parameter(description = "Print code filter") @QueryParam("print_code") String printCode,
			@Parameter(hidden = true) @Auth User user,
			@Context SecurityContext sc) {
		return printService.getApplicationPrintsByApplicationId(tenant, applicationId, printCode, user, sc);
	}
}
