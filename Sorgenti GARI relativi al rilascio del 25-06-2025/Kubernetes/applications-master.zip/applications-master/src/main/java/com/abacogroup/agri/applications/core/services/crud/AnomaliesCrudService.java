package com.abacogroup.agri.applications.core.services.crud;

import com.abacogroup.agri.applications.core.exceptions.ObjectNotFoundException;
import com.abacogroup.agri.applications.core.mappers.AnomalyMapper;
import com.abacogroup.agri.applications.core.model.dto.publics.AnomalyDTO;
import com.abacogroup.agri.applications.db.dao.AnomalyDAO;
import com.abacogroup.agri.applications.db.ntt.AnomalyNTT;
import com.abacogroup.jaxrsutils.filter.MDCPreFilter;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.MDC;

import java.util.List;
import java.util.Optional;

/**
 * @author Gennaro Tamburrelli
 */
@Slf4j
public class AnomaliesCrudService extends AbstractHistoricizationFieldsCrudService<AnomalyNTT, Long, AnomalyDTO, AnomalyMapper, Void> {

	public AnomaliesCrudService(AnomalyDAO dao, AnomalyMapper mapper) {
		super(dao, mapper);
	}

	@Override
	protected boolean hasPrimaryKey() {
		return true;
	}

	@Override protected Void retrieveCustomKeyByResultSet(AnomalyNTT rs) {
		return null;
	}

	@Override protected AnomalyNTT adjustR(AnomalyNTT rs) {
		return rs;
	}

	@Override
	protected Optional<AnomalyNTT> findRsByCustomKey(Void customKey) {
		return Optional.empty();
	}

	/**
	 * find by application id
	 *
	 * @param tenant        current tenant
	 * @param applicationId application's id
	 * @return the anomaly list by application id
	 */
	public List<AnomalyDTO> find(String tenant, Long applicationId) {
		return returnMappedList(((AnomalyDAO) this.dao).find(tenant, applicationId, MDC.get(MDCPreFilter.LOCALE)));
	}

	/**
	 * find by application id and anomaly code
	 *
	 * @param tenant        current tenant
	 * @param applicationId application's id
	 * @param anomalyCode   anomaly's code
	 * @return the optional anomaly
	 */
	public Optional<AnomalyDTO> find(String tenant, Long applicationId, String anomalyCode) {
		return returnOptionalRecord(((AnomalyDAO) this.dao).find(tenant, applicationId, anomalyCode, MDC.get(MDCPreFilter.LOCALE)));
	}

	public Optional<AnomalyDTO> findWithoutJoiningCatalog(String tenant, Long applicationId, String anomalyCode) {
		return returnOptionalRecord(((AnomalyDAO) this.dao).findWithoutJoiningCatalog(tenant, applicationId, anomalyCode, MDC.get(MDCPreFilter.LOCALE)));
	}

	public AnomalyDTO findById(Long pkId) throws ObjectNotFoundException {
		return this.dao.findById(pkId).stream()
				.findFirst()
				.map(mapper::entityToDto)
				.orElseThrow(AbstractCrudService.OBJECT_NOT_FOUND_EXCEPTION_SUPPLIER);
	}

	public AnomalyDTO insert(AnomalyDTO in, String username) {
		log.info("Invoking insert with params in: {} username: {}", in, username);
		return this.insert(in, username, null, this.dao.getCurrentTimestamp());
	}

	public AnomalyDTO update(Long key, AnomalyDTO in, String username) {
		log.info("Invoking update with params key: {} in: {} username: {}", key, in, username);
		return this.update(key, in, username, null);
	}

	public void delete(Long key, String username) {
		log.info("Invoking delete with params key: {} username: {}", key, username);
		this.delete(key, username, null);
	}

	public void deleteByAnomalyCode(String tenant, Long applicationId, String anomalyCode, String username) {
		this.findWithoutJoiningCatalog(tenant, applicationId, anomalyCode)
				.ifPresent(x -> this.delete(x.getPkid(), username));
	}

}
