package com.abacogroup.agri.applications.core.services;

import com.abacogroup.agri.applications.core.caller.CreateCustomApplicationIdCaller;
import com.abacogroup.agri.applications.core.caller.CreateCustomApplicationIdInput;
import com.abacogroup.agri.applications.core.exceptions.*;
import com.abacogroup.agri.applications.core.mappers.*;
import com.abacogroup.agri.applications.core.model.*;
import com.abacogroup.agri.applications.core.model.dto.PartyDTO;
import com.abacogroup.agri.applications.core.model.dto.*;
import com.abacogroup.agri.applications.core.model.dto.publics.*;
import com.abacogroup.agri.applications.core.services.calculation.CalculationService;
import com.abacogroup.agri.applications.core.services.crud.*;
import com.abacogroup.agri.applications.core.services.embededqueue.CreateProcessQueue;
import com.abacogroup.agri.applications.core.services.print.PrintService;
import com.abacogroup.agri.applications.core.services.workflow.ApplicationsWorkflowService;
import com.abacogroup.agri.applications.utils.DescriptionReplacerUtility;
import com.abacogroup.applicationworkflowsdk.model.ApplicationsWorkflowParams;
import com.abacogroup.applicationworkflowsdk.model.CreateProcessType;
import com.abacogroup.applicationworkflowsdk.model.DetailedSdkTransitionLog;
import com.abacogroup.applicationworkflowsdk.model.io.output.*;
import com.abacogroup.applicationworkflowsdk.service.CreateApplicationUtils;
import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.jaxrsutils.filter.MDCPreFilter;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.jdbi.paging.impl.InfiniteListResultsImpl;
import com.abacogroup.workflow.server.model.DetailedTransitionLog;
import com.abacogroup.workflow.server.model.NodeType;
import com.abacogroup.workflow.server.model.Transition;
import com.abacogroup.workflow.server.model.WorkflowNode;
import com.abacogroup.workflow.server.services.exceptions.WorkflowNotFoundException;
import jakarta.ws.rs.core.SecurityContext;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.jdbi.v3.core.Jdbi;
import org.slf4j.MDC;

import java.text.MessageFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.Year;
import java.util.*;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.stream.Collectors;

import static com.abacogroup.agri.applications.core.model.ProcessTransitionEnum.IN_TRANSITION;
import static com.abacogroup.agri.applications.utils.GenericUtility.conditionallyOverrideUserId;
import static com.abacogroup.applicationworkflowsdk.model.Constants.AUTHORIZATION_PREFIX;
import static com.abacogroup.applicationworkflowsdk.model.Constants.WORKFLOW_CLOSED_KEY;
import static java.util.stream.Collectors.groupingBy;

/**
 * @author Gennaro Tamburrelli
 * @author Mauro Pozzana
 * @author Alexandru Paraschiv
 */
@Slf4j
public class ApplicationsService implements CreateApplicationUtils {
	private final Jdbi jdbi;
	private final ApplicationsWorkflowService applicationsWorkflowService;
	private final PartyService partyService;
	private final CheckPartyService checkPartyService;

	private final ModuleCrudService moduleCrudService;
	private final ModuleDetailsCrudService moduleDetailsCrudService;
	private final ApplicationsCrudService applicationsCrudService;
	private final ApplicationDetailsCrudService applicationDetailsCrudService;
	private final ApplicationProfilesCrudService applicationProfilesCrudService;
	private final ApplicationCompileStatusCrudService applicationCompileStatusCrudService;
	private final ModuleFormConfigsCrudService moduleFormConfigsCrudService;
	private final ModuleProfilesCrudService moduleProfilesCrudService;
	private final CreateProcessQueue createProcessQueue;
	private final ProgressService progressService;
	private final ApplicationGeneratedPrintCrudService applicationGeneratedPrintCrudService;
	private final ApplicationProtocolsCrudService applicationProtocolsCrudService;
	private AnomaliesService anomaliesService;
	private final SectorsCrudService sectorsCrudService;
	private final FormConfigService formConfigService;
	private final AmendmentService amendmentService;
	private final PrintService printService;
	private final HistoryService historyService;
	private final CalculationService calculationService;
	private final ApplicationGeneratedCalculationCrudService applicationGeneratedCalculationCrudService;
	private final CustomApplicationIdGenerationConfig customApplicationIdGenerationConfig;
	private final CreateCustomApplicationIdCaller createCustomApplicationIdCaller;
	private final ModuleFormConfigParamCrudService moduleFormConfigParamCrudService;
	private final ApplicationsRelationCrudService applicationsRelationCrudService;
	private final ChildModuleCrudService childModuleCrudService;
	private final ForceReadOnlyContextCheckerService forceReadOnlyContextCheckerService;

	public ApplicationsService(
			Jdbi jdbi,
			ApplicationsWorkflowService applicationsWorkflowService,
			CheckPartyService checkPartyService,
			PartyService partyService,
			CrudServiceContainer crudServiceContainer,
			CreateProcessQueue createProcessQueue,
			ProgressService progressService,
			FormConfigService formConfigService,
			AmendmentService amendmentService, PrintService printService, HistoryService historyService,
			CalculationService calculationService,
			CustomApplicationIdGenerationConfig customApplicationIdGenerationConfig,
			CreateCustomApplicationIdCaller createCustomApplicationIdCaller, ForceReadOnlyContextCheckerService forceReadOnlyContextCheckerService) {
		this.jdbi = jdbi;
		this.applicationsWorkflowService = applicationsWorkflowService;
		this.partyService = partyService;
		this.checkPartyService = checkPartyService;
		this.moduleCrudService = crudServiceContainer.getModuleCrudService();
		this.moduleDetailsCrudService = crudServiceContainer.getModuleDetailsCrudService();
		this.applicationsCrudService = crudServiceContainer.getApplicationsCrudService();
		this.applicationDetailsCrudService = crudServiceContainer.getApplicationDetailsCrudService();
		this.applicationProfilesCrudService = crudServiceContainer.getApplicationProfilesCrudService();
		this.applicationCompileStatusCrudService = crudServiceContainer.getApplicationCompileStatusCrudService();
		this.moduleFormConfigsCrudService = crudServiceContainer.getModuleFormConfigsCrudService();
		this.moduleProfilesCrudService = crudServiceContainer.getModuleProfilesCrudService();
		this.createProcessQueue = createProcessQueue;
		this.progressService = progressService;
		this.applicationGeneratedPrintCrudService = crudServiceContainer.getApplicationGeneratedPrintCrudService();
		this.applicationProtocolsCrudService = crudServiceContainer.getApplicationProtocolsCrudService();
		this.sectorsCrudService = crudServiceContainer.getSectorsCrudService();
		this.formConfigService = formConfigService;
		this.amendmentService = amendmentService;
		this.printService = printService;
		this.historyService = historyService;
		this.calculationService = calculationService;
		this.applicationGeneratedCalculationCrudService = crudServiceContainer.getApplicationGeneratedCalculationCrudService();
		this.customApplicationIdGenerationConfig = customApplicationIdGenerationConfig;
		this.createCustomApplicationIdCaller = createCustomApplicationIdCaller;
		this.anomaliesService = new AnomaliesService(this, crudServiceContainer);
		this.moduleFormConfigParamCrudService = crudServiceContainer.getModuleFormConfigParamCrudService();
		this.applicationsRelationCrudService = crudServiceContainer.getApplicationsRelationCrudService();
		this.childModuleCrudService = crudServiceContainer.getChildModuleCrudService();
		this.forceReadOnlyContextCheckerService = forceReadOnlyContextCheckerService;
	}

	public void setAnomaliesService(AnomaliesService anomaliesService) {
		this.anomaliesService = anomaliesService;
	}

	public InfiniteListResults<ModuleByPointInTimeDTO> getModulesByPointInTime(String tenant, AbsoluteDate pointInTime, Integer flAmend, String nextKey,
			SecurityContext sc) {
		AbsoluteDate dateToUse = getDefaultAbsoluteDate(pointInTime);
		var res = moduleCrudService.findParentModules(tenant, dateToUse, flAmend);
		if (nextKey == null && res.isEmpty()) {
			throw new NoModulesFoundAtDateRuntimeException(MessageFormat.format("no modules found at date {0}", dateToUse));
		} else {
			return new InfiniteListResultsImpl<>(
					res.stream()
							.filter(x -> verifyContextFunction(sc, x.getContextFunction()))
							.filter(x -> verifyForceReadOnlyContextFunction(sc, x.getForceReadOnlyContextFunction()))
							.collect(Collectors.toList()),
					null);
		}
	}

	public List<ModuleWithDetailDTO> getModulesBySectorCode(String tenant, String sectorCode, SecurityContext sc) {
		try {
			SectorDTO sector = sectorsCrudService.findSectorByCode(tenant, sectorCode);
			return moduleCrudService.findAllModulesWithDetailBySectorId(tenant, sector.getSectorId()).stream()
					.filter(x -> verifyContextFunction(sc, x.getContextFunction()))
					.filter(x -> verifyForceReadOnlyContextFunction(sc, x.getForceReadOnlyContextFunction()))
					.collect(Collectors.toList());
		} catch (ObjectNotFoundException e) {
			throw new ObjectNotFoundRuntimeException(MessageFormat.format("No sectors found for this sector code {0}", sectorCode));
		}
	}

	private boolean verifyContextFunction(SecurityContext sc, String contextFunction) {
		return StringUtils.isAllBlank(contextFunction) || Optional.ofNullable(sc)
				.map(xsc -> xsc.isUserInRole(contextFunction))
				.orElse(true);
	}

	private boolean verifyForceReadOnlyContextFunction(SecurityContext sc, String contextFunction) {
		return StringUtils.isAllBlank(contextFunction) ||
				Optional.ofNullable(sc)
						.map(xsc -> !xsc.isUserInRole(contextFunction)) // if user has read only context function then it returns false
						.orElse(true);
	}

	public InfiniteListResults<ModuleProfilePublicDTO> getProfilesByModuleAndSector(String tenant, String sectorCode, String moduleCode,
			AbsoluteDate pointInTime, String nextKey) {
		AbsoluteDate dateToUse = getDefaultAbsoluteDate(pointInTime);
		var res = moduleProfilesCrudService.find(tenant, sectorCode, moduleCode, dateToUse, nextKey);
		if (nextKey == null && res.getRecords().isEmpty()) {
			throw new NoProfilesFoundAtDateRuntimeException(MessageFormat.format("no modules found at date {0}", dateToUse));
		} else {
			return new InfiniteListResultsImpl<>(res.getRecords().stream().map(ModuleProfilePublicMapper.INSTANCE::dtoToPublic).collect(Collectors.toList()),
					res.getNextKey());
		}
	}

	public InfiniteListResults<SectorPublicDTO> getSectorsByTenant(String tenant, String nextKey) {
		InfiniteListResults<SectorDTO> sectors = sectorsCrudService.findInfiniteAllSectors(tenant, nextKey);
		if (nextKey == null && sectors.getRecords().isEmpty()) {
			throw new NoSectorsFoundAtDateRuntimeException(MessageFormat.format("No sectors found for tenant {0}", tenant));
		}

		return new InfiniteListResultsImpl<>(sectors.getRecords().stream().map(SectorPublicMapper.INSTANCE::dtoToPublic).collect(Collectors.toList()),
				nextKey);
	}

	public List<WorkflowNodePublic> getStatusNodes(String tenant, String moduleCode) {
		ModuleDTO moduleDTO = moduleCrudService.findByCode(tenant, moduleCode)
				.orElseThrow(() -> new ObjectNotFoundRuntimeException(MessageFormat.format("Module with code: {0} not found", moduleCode)));

		List<WorkflowNode> workflowNodes = applicationsWorkflowService.getWorkflowNodesByType(tenant, moduleDTO.getWorkflowCode(), NodeType.status);

		return workflowNodes.stream()
				.sorted(Comparator.comparing(WorkflowNode::getId))
				.map(WorkflowNodePublicMapper.INSTANCE::entityToDto)
				.collect(Collectors.toList());

	}

	private AbsoluteDate getDefaultAbsoluteDate(AbsoluteDate pointInTime) {
		return Optional.ofNullable(pointInTime).orElseGet(() -> new AbsoluteDate(LocalDate.now()));
	}

	public List<ApplicationDetailsPublicDTO> getApplicationsByPartyId(String tenant, Long partyId, User user, String moduleCode, String processStatus,
			SecurityContext sc) {

		return applicationsCrudService.findAllByPartyIdAndModuleCodeAndProcessStatus(tenant, partyId, moduleCode, processStatus)
				.stream()
				.filter(x -> Optional.ofNullable(x.getProcessId()).isPresent())
				.map(x -> getDetailedApplicationById(tenant, x.getApplicationId(), user, sc))
				.map(ApplicationDetailsPublicMapper.INSTANCE::entityToDto)
				.collect(Collectors.toList());
	}

	public ApplicationsSummaryByYearOutDTO getApplicationsSummaryByYear(String tenant, Long partyId, User user, SecurityContext sc) {
		if (Optional.ofNullable(partyId).isEmpty()) {
			throw new NoMandatoryInputPartyIdRuntimeException("Party id is mandatory");
		}

		try {
			this.checkPartyService.checkCanReadParty(tenant, partyId, user);
		} catch (ActionNotAuthorizedRuntimeException e) {
			return ApplicationsSummaryByYearOutDTO.builder()
					.partyId(partyId)
					.applicationsSummaryByYear(Collections.emptyList())
					.build();
		}

		List<ApplicationDTO> applications = applicationsCrudService.findAllByPartyId(tenant, partyId)
				.stream()
				.filter(x -> {
					String cf = Optional.ofNullable(moduleDetailsCrudService.findByModuleId(tenant, x.getModuleId())).map(ModuleDetailsDTO::getContextFunction).orElse(null);
					return cf == null || Optional.ofNullable(sc).map(y -> y.isUserInRole(cf)).orElse(false);
				})
				.toList();

		Map<Integer, List<ApplicationDTO>> applicationsByYear = applications.stream()
				.sorted(Comparator.comparing(ApplicationDTO::getReferredYear))
				.collect(groupingBy(ApplicationDTO::getReferredYear));

		ApplicationsSummaryByYearOutDTO results = ApplicationsSummaryByYearOutDTO.builder()
				.partyId(partyId)
				.build();

		applicationsByYear.keySet().stream()
				.forEach(year -> results.getApplicationsSummaryByYear().add(
						ApplicationsSummaryByYearDTO.builder()
								.year(year)
								.applicationsNumber(applicationsByYear.get(year).size())
								.build()));

		if (results.getApplicationsSummaryByYear().isEmpty()) {
			throw new NoApplicationSummaryFoundRuntimeException(
					MessageFormat.format("No application summary found for tenant: {0} partyId: {1}", tenant, partyId));
		}

		return results;
	}

	public CreateApplicationOutDTO createApplication(String tenant, User user, CreateApplicationInDTO payload, CreateProcessType progressTypeEnum,
													 String locale) {
		ModuleDTO module = getModule(tenant, payload);
		ModuleDetailsDTO moduleDetails = getModuleDetails(tenant, module.getModuleId());

		forceReadOnlyContextCheckerService.checkForReadOnlyContextFunctionByModuleId(user, moduleDetails.getModuleId());

		payload.setYear(moduleDetails.getAnnuality() != null ? moduleDetails.getAnnuality() : Year.now().getValue());

		List<ApplicationAnomaly> applicationAnomalies = checkForAnomalies(tenant, payload, module);

		if (!applicationAnomalies.isEmpty()) {
			return CreateApplicationOutDTO.builder()
					.anomalies(applicationAnomalies)
					.build();
		}
		ApplicationOutDTO newApplication = doInsertApplication(tenant, user, payload, module, progressTypeEnum, locale);

		return CreateApplicationOutDTO.builder()
				.applicationId(newApplication.getApplication().getApplicationId())
				.applicationCode(newApplication.getApplicationDetail().getApplicationCode())
				.build();
	}

	public CreateAmendmentApplicationOutDTO createAmendmentApplicationAsync(String tenant, User user, CreateApplicationInDTO payload, String locale) {
		if (Optional.ofNullable(payload.getAmendmentApplicationId()).isEmpty()) {
			throw new BadRequestRuntimeException("No amendment application id found");
		}

		ModuleDTO module = getModule(tenant, payload);

		forceReadOnlyContextCheckerService.checkForReadOnlyContextFunctionByModuleId(user, module.getModuleId());

		List<ApplicationAnomaly> applicationAnomalies = checkForAnomalies(tenant, payload, module);
		applicationAnomalies.addAll(anomaliesService.checkForAmendmentModule(module));
		applicationAnomalies.addAll(anomaliesService.checkForApplicationNotAmended(tenant, payload.getAmendmentApplicationId()));
		applicationAnomalies.addAll(anomaliesService.checkForApplicationWaived(tenant, payload.getAmendmentApplicationId()));

		if (!applicationAnomalies.isEmpty()) {
			return CreateAmendmentApplicationOutDTO.builder()
					.anomalies(applicationAnomalies)
					.build();
		}

		return jdbi.inTransaction(handle -> {
			ApplicationOutDTO newApplication = doInsertApplication(tenant, user, payload, module, CreateProcessType.ASYNC, locale);

			updateAmendedByApplicationId(tenant, payload.getAmendmentApplicationId(),
					newApplication.getApplication().getApplicationId(),
					user.getUserId());

			return CreateAmendmentApplicationOutDTO.builder()
					.applicationId(newApplication.getApplication().getApplicationId())
					.applicationCode(newApplication.getApplicationDetail().getApplicationCode())
					.amendmentApplicationId(newApplication.getApplicationDetail().getAmendOfId())
					.build();
		});
	}

	public void updateAmendedByApplicationId(String tenant, Long applicationId, Long amendedById, String userId) {
		jdbi.useTransaction(handle -> {
			try {
				ApplicationDetailsDTO applicationDetails = applicationDetailsCrudService.findApplicationDetailById(tenant, applicationId);

				applicationDetails.setAmendedById(amendedById);

				applicationDetailsCrudService.update(applicationDetails.getPkid(), applicationDetails, userId);
			} catch (ObjectNotFoundException e) {
				throw new ApplicationNotFoundRuntimeException(MessageFormat.format("Application with id {0} not found", applicationId));
			}
		});
	}

	public void updateAmendOfApplicationId(String tenant, Long applicationId, Long amendOfId, String userId) {
		jdbi.useTransaction(handle -> {
			try {
				ApplicationDetailsDTO applicationDetails = applicationDetailsCrudService.findApplicationDetailById(tenant, applicationId);

				applicationDetails.setAmendOfId(amendOfId);

				applicationDetailsCrudService.update(applicationDetails.getPkid(), applicationDetails, userId);
			} catch (ObjectNotFoundException e) {
				throw new ApplicationNotFoundRuntimeException(MessageFormat.format("Application with id {0} not found", applicationId));
			}
		});
	}

	private ModuleDTO getModule(String tenant, CreateApplicationInDTO payload) {
		Optional<ModuleDTO> optModule = moduleCrudService.findByModuleCodeAndSectorCode(tenant, payload.getModuleCode(), payload.getSectorCode());

		if (optModule.isEmpty()) {
			throw new NoModulesFoundAtDateRuntimeException("Module not found");
		}

		return optModule.get();
	}

	private ModuleDetailsDTO getModuleDetails(String tenantId, Long moduleId) {
		ModuleDetailsDTO existingModuleDetail = moduleDetailsCrudService.findByModuleId(tenantId, moduleId);

		if (existingModuleDetail == null) {
			throw new NoModulesFoundAtDateRuntimeException("Module not found");
		}

		return existingModuleDetail;
	}

	private List<ApplicationAnomaly> checkForAnomalies(String tenant, CreateApplicationInDTO payload, ModuleDTO module) {
		ModuleDetailsDTO moduleDetailsDTO = moduleDetailsCrudService.findByModuleId(tenant, module.getModuleId());
		List<ApplicationAnomaly> applicationAnomalies = anomaliesService.checkForModuleDateValidity(moduleDetailsDTO);

		applicationAnomalies.addAll(anomaliesService.checkForMultipleApplication(tenant, module, payload.getPartyId(),
				payload.getYear(), null));
		return applicationAnomalies;
	}

	public ApplicationOutDTO doInsertApplication(String tenant, User user, CreateApplicationInDTO payload, ModuleDTO module,
			CreateProcessType progressTypeEnum, String locale) {
		return jdbi.inTransaction(handle -> {
			var application = createVanillaApplicationWithDetails(tenant, user, payload, module);
			// creo il processo
			log.info("Creating process with tenant: {} workflowCode: {}", tenant, module.getWorkflowCode());
			String workflowCode = module.getWorkflowCode();
			switch (progressTypeEnum) {
				case SYNC:
					applicationsWorkflowService
							.createProcess(tenant, application.getApplication().getApplicationId(),
									user.getUserId(), workflowCode, locale,
									Map.of(ApplicationsWorkflowParams.KEY, ApplicationsWorkflowParams.builder()
											.applicationId(application.getApplication().getApplicationId())
											.applicationCode(application.getApplicationDetail().getApplicationCode())
											.amendedApplicationId(application.getApplicationDetail().getAmendOfId())
											.tenant(tenant)
											.username(user.getName())
											.userid(user.getUserId())
											.locale(locale)
											.partyId(application.getApplication().getPartyId())
											.workflowCode(workflowCode)
											.referredYear(application.getApplication().getReferredYear())
											.build()));
					break;
				case ASYNC:
				default:
					// execute create process asynchronously
					createProcessQueue.add(ApplicationsWorkflowParams.builder()
							.applicationId(application.getApplication().getApplicationId())
							.applicationCode(application.getApplicationDetail().getApplicationCode())
							.amendedApplicationId(application.getApplicationDetail().getAmendOfId())
							.tenant(tenant)
							.username(user.getName())
							.userid(user.getUserId())
							.locale(locale)
							.partyId(application.getApplication().getPartyId())
							.workflowCode(workflowCode)
							.referredYear(application.getApplication().getReferredYear())
							.build(), System.currentTimeMillis());
			}

			return application;
		});
	}

	/**
	 * Create application's record without process id and status
	 *
	 * @param user
	 *            the user
	 * @param payload
	 *            the application's detail
	 * @param module
	 *            the module's detail
	 * @return the created record
	 */
	public ApplicationOutDTO createVanillaApplicationWithDetails(String tenant, User user, CreateApplicationInDTO payload, ModuleDTO module) {
		return jdbi.inTransaction(x -> {

			ApplicationDTO in = ApplicationDTO.builder()
					.partyId(payload.getPartyId())
					.referredYear(payload.getYear())
					.moduleId(module.getModuleId())
					.userIdInsert(user.getUserId())
					.build();

			if (Boolean.TRUE.equals(customApplicationIdGenerationConfig.getActive())) {
				var moduleDetails = moduleDetailsCrudService.findByModuleId(tenant, module.getModuleId());
				in.setApplicationId(createCustomApplicationIdCaller.makeCall(CreateCustomApplicationIdInput.builder()
						.url(customApplicationIdGenerationConfig.getUrl())
						.tenant(tenant)
						.partyId(payload.getPartyId())
						.sectorCode(payload.getSectorCode())
						.moduleCode(payload.getModuleCode())
						.referredYear(moduleDetails.getAnnuality())
						.token(AUTHORIZATION_PREFIX + user.getAuthToken())
						.build())
						.getApplicationId());
			}

			// restituisco l'application creata
			log.info("Inserting application");
			ApplicationDTO insertedApplication = applicationsCrudService.insert(in, user.getUserId());
			log.info("Application inserted");
			ApplicationDetailsDTO detailsIn = ApplicationDetailsDTO.builder()
					.applicationId(insertedApplication.getApplicationId())
					.applicationCode(generateApplicationCode(insertedApplication.getApplicationId()))
					.flInTransition(ProcessTransitionEnum.NOT_IN_TRANSITION.getFl())
					.amendOfId(payload.getAmendmentApplicationId())
					.build();
			log.info("Inserting application details");
			ApplicationDetailsDTO insertedDetails = applicationDetailsCrudService.insert(detailsIn, user.getUserId());
			log.info("Application details Inserted");

			// gestione child application
			conditionallyInsertApplicatioRelation(tenant, insertedApplication, payload, user);

			return ApplicationOutDTO.builder()
					.application(insertedApplication)
					.applicationDetail(insertedDetails)
					.build();
		});
	}

	private void conditionallyInsertApplicatioRelation(String tenant, ApplicationDTO insertedApplication,
			CreateApplicationInDTO payload, User user) {
		Optional.ofNullable(payload.getParentApplicationId())
				.ifPresent(parentApplicationId -> {
					try {
						log.info("looking for parent application with id {}", parentApplicationId);
						var parentApplication = applicationsCrudService.findById(tenant, parentApplicationId);
						childModuleCrudService.findOptByModuleIdAndParentModuleId(insertedApplication.getModuleId(), parentApplication.getModuleId())
								.ifPresentOrElse(childModuleRelation -> {
									log.info("found relation between parent and child application's module, inserting into application relations tables..");
									applicationsRelationCrudService.insert(ApplicationsRelationDTO.builder()
											.parentApplicationId(parentApplicationId)
											.childApplicationId(insertedApplication.getApplicationId())
											.build(),
											user.getUserId());
								},
										() -> {
											log.error("there is no relation between parent and child application's module!");
											throw new ChildRelationRuntimeException("no relation between parent and child application's module");
										});
					} catch (Exception e) {
						throw new RuntimeException(e);
					}
				});
	}

	public String generateApplicationCode(Long applicationId) {
		return Optional.ofNullable(applicationId).map(Objects::toString).orElse(null);
	}

	public ApplicationWithDetailsDTO getDetailedApplicationByChildApplicationId(String tenant, Long childApplicationId, User user, SecurityContext sc) {
		ApplicationsRelationDTO applicationRelation = applicationsRelationCrudService.findByChildApplicationId(childApplicationId);

		return getDetailedApplicationById(tenant, applicationRelation.getParentApplicationId(), user, sc);
	}

	public ApplicationWithDetailsDTO getDetailedApplicationByParentApplicationId(String tenant, Long parentApplicationId, String moduleCode,
			User user, SecurityContext sc) {
		ApplicationsRelationDTO applicationRelation = applicationsRelationCrudService.findByParentApplicationIdAndModuleCode(parentApplicationId, moduleCode);

		return getDetailedApplicationById(tenant, applicationRelation.getChildApplicationId(), user, sc);
	}

	public ApplicationWithDetailsDTO getDetailedApplicationById(String tenant, Long applicationId, User user, SecurityContext sc) {
		ApplicationWithDetailsDTO res = getApplicationWithDetailsById(tenant, applicationId, user, sc);

		res.setOriginalAmendedApplicationId(amendmentService.getOriginalAmendedApplicationId(res, tenant));

		List<String> requiredProfileCodes = res.getProfileList()
				.stream()
				.map(ApplicationProfileDTO::getProfileCode)
				.collect(Collectors.toList());

		res.setForms(formConfigService.getFormsByModuleIdAndProcessStatus(tenant,
				res.getModuleId(),
				res.getProcessStatus(),
				res.getCompileStatus(),
				requiredProfileCodes.isEmpty() ? new ArrayList<>(List.of("")) : requiredProfileCodes,
				sc,
				MDC.get(MDCPreFilter.LOCALE)));

		res.setPrints(getPrintsByModuleIdAndProcessStatus(tenant,
				applicationId,
				res.getModuleId(),
				res.getProcessStatus(),
				requiredProfileCodes.isEmpty() ? new ArrayList<>(List.of("")) : requiredProfileCodes,
				sc));

		res.setIsClosed(isApplicationClosed(tenant, res));

		res.setParty(partyService.getPartyByPartyId(tenant, res.getPartyId(), user));
		return res;
	}

	public static final Boolean RETRIEVE_ALL_DETAILS = true;
	public static final Boolean DO_NOT_RETRIEVE_ALL_DETAILS = false;

	public ApplicationWithDetailsDTO getApplicationWithDetailsById(String tenant, Long applicationId, User user, SecurityContext sc) {
		return getApplicationWithDetailsById(tenant, applicationId, user, sc, RETRIEVE_ALL_DETAILS);
	}

	public ApplicationWithDetailsDTO getApplicationWithDetailsById(String tenant, Long applicationId, User user, SecurityContext sc,
			boolean retrieveAllDetails) {
		var res = Optional.of(applicationsCrudService.findWithDetailsByApplicationId(tenant, applicationId))
				.filter(app -> {
					var moduleDetails = moduleDetailsCrudService.findByModuleId(tenant, app.getModuleId());
					if (moduleDetails.getContextFunction() == null) {
						return true;
					}
					var userCanSeeModule = sc.isUserInRole(moduleDetails.getContextFunction());
					if (userCanSeeModule) {
						return true;
					} else {
						throw new ActionNotAuthorizedRuntimeException("user cannot see applications of this module");
					}
				})
				.map(app -> {
					if (retrieveAllDetails) {
						try {
							app.setProcessStatusDescription(applicationsWorkflowService.getProcessStatusDescription(tenant, app.getProcessId(), user));
						} catch (WorkflowNotFoundException e) {
							throw new WorkflowGenericRuntimeException(e.getMessage());
						}
					}
					return app;
				})
				.map(app -> {
					app.setProfileList(applicationProfilesCrudService.findAll(tenant, app.getApplicationId(), MDC.get(MDCPreFilter.LOCALE)));
					app.setCompileStatus(applicationCompileStatusCrudService.find(tenant, app.getApplicationId()));
					if (retrieveAllDetails) {
						app.setDtInsert(applicationDetailsCrudService.findFirstCreationDate(tenant, applicationId));
						computeApplicationProfilesDescription(app.getProfileList()).ifPresent(app::setApplicationProfilesDescription);
						app.setLastMovement(extractInformationFromLastMovement(tenant, user, app, DetailedTransitionLog::getDescription));
						app.setLastMovementUserIdExecutor(extractInformationFromLastMovement(tenant, user, app, DetailedTransitionLog::getUserId));
						setProtocol(tenant, applicationId, (protocol) -> {
							app.setDtProtocolRequest(protocol.getDtRequest());
							app.setDtProtocolResponse(protocol.getDtResponse());
							app.setProtocolCode(protocol.getProtocol());
						});
					}
					return app;
				})
				.orElse(ApplicationWithDetailsDTO.builder().build());
		conditionallyThrowApplicationNotFound(tenant, user, res.getPartyId());
		return res;
	}

	private void setProtocol(String tenant, Long applicationId, Consumer<ApplicationProtocolsDTO> consumer) {
		applicationProtocolsCrudService.findAll(tenant, applicationId)
				.stream()
				.max(Comparator.comparing(ApplicationProtocolsDTO::getDtRequest))
				.ifPresent(consumer);
	}

	private String extractInformationFromLastMovement(String tenant, User user, ApplicationWithDetailsDTO app, Function<DetailedTransitionLog, String> getter) {
		return applicationsWorkflowService.getProcessTransitionHistory(tenant, app.getProcessId(), user)
				.stream()
				.min(Comparator.comparing(DetailedTransitionLog::getEndDate).reversed())
				.map(getter)
				.orElse(null);
	}

	// private Boolean isAmendmentApplicationIdViewable(String tenant, ApplicationWithDetailsDTO applicationWithDetails) {
	// if (Optional.ofNullable(applicationWithDetails.getAmendmentApplicationId()).isEmpty()) {
	// return false;
	// }
	//
	// ApplicationWithDetailsDTO amendmentApplicationWithDetails =
	// applicationsCrudService.findWithDetailsByApplicationId(tenant, applicationWithDetails.getAmendmentApplicationId());
	//
	// return Boolean.TRUE.equals(amendmentService.isApplicationAmendable(tenant, applicationWithDetails.getAmendmentApplicationId()) &&
	// amendmentService.isAmendModule(tenant, amendmentApplicationWithDetails.getModuleId()));
	// }
	//
	// private Boolean isAmendedApplicationIdViewable(String tenant, ApplicationWithDetailsDTO applicationWithDetails) {
	// if (Optional.ofNullable(applicationWithDetails.getAmendedApplicationId()).isEmpty()) {
	// return false;
	// }
	//
	// return Boolean.TRUE.equals(amendmentService.isAmendModule(tenant, applicationWithDetails.getModuleId()));
	// }

	private Boolean isAmendableApplication(final String tenant, final Long applicationId, final String applicationCode,
			final String moduleCode, SecurityContext securityContext) {
		Optional<Boolean> isAmendable = Optional.ofNullable((Boolean) checkForMetadata(tenant, applicationCode).get("isAmendable"));
		return isAmendable.isPresent() && isAmendable.get() && amendmentService.checkAmendmentStatus(tenant, moduleCode)
				&& this.hasAmendableModules(tenant, applicationId, securityContext);
	}

	private boolean hasAmendableModules(String tenant, Long applicationId, SecurityContext securityContext) {
		try {
			return !amendmentService.getAmendableModulesByApplicationId(tenant, applicationId,
					securityContext).isEmpty();
		} catch (ObjectNotFoundException e) {
			throw new ObjectNotFoundRuntimeException(e.getMessage());
		}
	}

	public List<PrintDetailsOutDTO> getPrintsByModuleIdAndProcessStatus(String tenant, Long applicationId, Long moduleId, String processStatus,
			List<String> profileCodeList, SecurityContext sc) {
		if(forceReadOnlyContextCheckerService.moduleHasReadOnlyAndUserHasIt(sc, moduleId)) {
			return Collections.emptyList();
		} else {
			List<PrintDetailsOutDTO> printDetailsOutDTOList = this.printService.getPrintsByModuleIdAndProcessStatus(tenant, applicationId, moduleId, processStatus, profileCodeList, sc);

			DescriptionReplacerUtility.replaceDescriptionFromList(printDetailsOutDTOList, applicationId);

			return printDetailsOutDTOList;
		}
	}

	public List<CalculationDetailsOutDTO> getCalculationsByModuleIdAndProcessStatus(String tenant, Long applicationId, Long moduleId, String processStatus,
			List<String> profileCodeList, SecurityContext sc) {
		if(forceReadOnlyContextCheckerService.moduleHasReadOnlyAndUserHasIt(sc, moduleId)) {
			return Collections.emptyList();
		} else {
			return this.calculationService.getCalculationsByModuleIdAndProcessStatus(tenant, applicationId, moduleId, processStatus, profileCodeList, sc);
		}
	}

	public InfiniteListResults<AppByPartyAndYearDTO> getApplicationsByPartyAndYear(String tenant, Long partyId, Integer year, String nextKey,
			User user, SecurityContext securityContext) {
		try {
			this.checkPartyService.checkCanReadParty(tenant, partyId, user);
		} catch (ActionNotAuthorizedRuntimeException e) {
			return new InfiniteListResultsImpl<>();
		}
		return doGetApplicationsByPartyAndYear(tenant, partyId, year, nextKey, user, securityContext);
	}

	public InfiniteListResults<AppByPartyAndYearDTO> doGetApplicationsByPartyAndYear(String tenant, Long partyId, Integer year, String nextKey, User user,
            SecurityContext securityContext) {
		var res = applicationsCrudService.find(tenant, securityContext, partyId, year, nextKey);
		if (nextKey == null && res.getRecords().isEmpty()) {
			throw new NoApplicationsFoundByPartyAndYearRuntimeException(
					MessageFormat.format("no applications found for partyId {0} and year {1}", partyId, year));
		} else {
			res.getRecords().stream()
					.forEachOrdered(application -> {
						try {
							application.setProcessStatusDescription(
									applicationsWorkflowService.getProcessStatusDescription(tenant, application.getProcessId(), user));
							application.setIsClosed(isApplicationClosed(tenant, application.getModuleCode(), application.getProcessStatus()));
							// Evaluate amendable status for application
							if(forceReadOnlyContextCheckerService.moduleHasReadOnlyAndUserHasIt(securityContext,
									moduleCrudService.findByCode(tenant, application.getModuleCode())
											.map(ModuleDTO::getModuleId)
											.orElseThrow())) {
								application.setFlAmendable(false);
							} else {
								application.setFlAmendable(isAmendableApplication(tenant, application.getApplicationId(), application.getApplicationCode(),
										application.getModuleCode(), securityContext));
							}
							setProtocol(tenant, application.getApplicationId(), (protocol) -> {
								application
										.setDtProtocol(Optional.ofNullable(protocol.getDtRequest()).map(x -> new AbsoluteDate(x.toLocalDate())).orElse(null));
								application.setDtProtocolTimestamp(protocol.getDtRequest());
								application.setProtocol(protocol.getProtocol());
							});

							List<ApplicationProfileDTO> profiles = applicationProfilesCrudService.findAll(tenant, application.getApplicationId(),
									MDC.get(MDCPreFilter.LOCALE));
							computeApplicationProfilesDescription(profiles).ifPresent(application::setApplicationProfilesDescription);

						} catch (Exception e) {
							application.setProcessStatusDescription("ERROR");
							application.setIsClosed(true);
						}
					});
			return res;
		}
	}

	public List<AppByPartyAndYearDTO> getApplicationsByPartyYearAndModuleCode(String tenant, Long partyId, Integer year, String moduleCode,
			User user) {
		return applicationsCrudService.findWithModuleCode(tenant, partyId, year, moduleCode)
				.stream()
				.map(x -> {
					x.setProcessStatusDescription(applicationsWorkflowService.getProcessStatusDescription(tenant, x.getProcessId(), user));
					x.setIsClosed(isApplicationClosed(tenant, x.getModuleCode(), x.getProcessStatus()));
					return x;
				})
				.collect(Collectors.toList());
	}

	public InfiniteListResults<AppByPartyAndYearDTO> getApplicationsByModuleCode(String tenant, String moduleCode, String partyCode, List<Integer> yearList,
			String processStatus, List<Long> applicationIdList, String nextKey, User user, SecurityContext sc, Integer flLightResponse,
			Integer pageSize) {
		List<Long> partyIds = getPartyIdsByCode(tenant, partyCode, user);

		Long partyId = partyIds.stream().findFirst().orElse(null);

		var partialResult = applicationsCrudService.findInfiniteResults(tenant, moduleCode, partyId, yearList, processStatus,
				applicationIdList, nextKey, MDC.get(MDCPreFilter.LOCALE), pageSize);

		var partialList = partialResult.getRecords();
		var nextNextKey = partialResult.getNextKey();

		return new InfiniteListResultsImpl<>(partialList.stream()
				.map(x -> {
					if (flLightResponse.equals(0)) {
						x.setIsClosed(isApplicationClosed(tenant, moduleCode, x.getProcessStatus()));
						if(forceReadOnlyContextCheckerService.moduleHasReadOnlyAndUserHasIt(sc,
								moduleCrudService.findByCode(tenant, moduleCode)
								                 .map(ModuleDTO::getModuleId)
										         .orElseThrow())) {
							x.setFlAmendable(false);
						} else {
							x.setFlAmendable(isAmendableApplication(tenant, x.getApplicationId(), x.getApplicationCode(),
									x.getModuleCode(), sc));
						}
						x.setProcessStatusDescription(applicationsWorkflowService.getProcessStatusDescription(tenant, x.getProcessId(), user));
					}
					return x;
				}).collect(Collectors.toList()), nextNextKey);
	}

	public InfiniteListResults<Long> getApplicationIdsByModuleCode(String tenant, String moduleCode, String nextKey, Integer pageSize) {
		return applicationsCrudService.findInfiniteApplicationIds(tenant, moduleCode, nextKey, pageSize);
	}

	public InfiniteListResults<AppByPartyAndYearDTO> getApplicationsByPartyCode(String tenant, String code, String moduleCode, List<Integer> yearList,
			String processStatus, String nextKey, User user) {
		List<Long> partyIds = getPartyIdsByCode(tenant, code, user);

		Long partyId = partyIds.stream().findFirst().orElseThrow(PartyNotFoundRuntimeException::new);

		return applicationsCrudService.findInfiniteResults(tenant, moduleCode, partyId, yearList, processStatus, null,
				nextKey, MDC.get(MDCPreFilter.LOCALE), null);
	}

	public Long countGetApplicationsByPartyCode(String tenant, String code, String moduleCode, List<Integer> yearList, List<Long> applicationIdList,
			String processStatus, User user) {
		List<Long> partyIds = getPartyIdsByCode(tenant, code, user);

		Long partyId = partyIds.stream().findFirst().orElseThrow(PartyNotFoundRuntimeException::new);

		return applicationsCrudService.countApplications(tenant, moduleCode, partyId, yearList, processStatus, applicationIdList);
	}

	private List<Long> getPartyIdsByCode(String tenant, String code, User user) {
		if (Optional.ofNullable(code).isEmpty()) {
			return Collections.emptyList();
		}

		return partyService.getPartiesByCodeOrDesc(tenant, -1L /* partyId not required for calling endpoint */, code, "", user).stream()
				.map(PartyDTO::getPartyId)
				.collect(Collectors.toList());
	}

	public InfiniteListResults<ApplicationProfilePublicDTO> getApplicationProfiles(String tenant, Long applicationId,
																				   LocalDateTime dateTime, String nextKey, User user) {
		var res = applicationProfilesCrudService.find(tenant, applicationId, dateTime, nextKey);
		return new InfiniteListResultsImpl<>(res.getRecords()
				.stream()
				.map(ApplicationProfilePublicMapper.INSTANCE::dtoToPublic)
				.collect(Collectors.toList()),
				res.getNextKey());
	}

	public Map<String, Object> checkForMetadata(String tenant, String applicationCode) {
		return checkForMetadata(tenant, applicationsCrudService.findWithDetailsByApplicationCode(tenant, applicationCode));
	}

	public Map<String, Object> checkForMetadata(String tenant, ApplicationWithDetailsDTO app) {
		if (app == null || app.getProcessStatus() == null) {
			return Map.of();
		}

		var module = moduleCrudService.findById(app.getModuleId()).orElseThrow(() -> new ObjectNotFoundRuntimeException("module not found"));
		return applicationsWorkflowService.getNodeMetadata(tenant, module.getWorkflowCode(), app.getProcessStatus());
	}

	public Map<String, Object> checkForMetadata(String tenant, String moduleCode, String processStatus) {
		var module = moduleCrudService.findByCode(tenant, moduleCode).orElseThrow(() -> new ObjectNotFoundRuntimeException("module not found"));
		return applicationsWorkflowService.getNodeMetadata(tenant, module.getWorkflowCode(), processStatus);
	}

	public boolean isApplicationClosed(String tenant, Long applicationId, User user, SecurityContext sc) {
		var application = getApplicationWithDetailsById(tenant, applicationId, user, sc);
		return isApplicationClosed(tenant, application);
	}

	public boolean isApplicationClosed(String tenant, ApplicationWithDetailsDTO app) {
		var metadata = checkForMetadata(tenant, app);
		return isWorkflowClosed(metadata);
	}

	public boolean isApplicationClosed(String tenant, String moduleCode, String processStatus) {
		var metadata = checkForMetadata(tenant, moduleCode, processStatus);
		return isWorkflowClosed(metadata);
	}

	private static Boolean isWorkflowClosed(Map<String, Object> metadata) {
		return Optional.ofNullable(metadata.get(WORKFLOW_CLOSED_KEY))
				.map(entry -> {
					try {
						return (boolean) entry;
					} catch (ClassCastException e) {
						throw new IllegalStateException("The entry is not valid, boolean value is expected");
					}
				})
				.orElse(false);
	}

	public ReadOnlyDto findReadOnly(String tenant, Long applicationId, Long formConfigId, User user, SecurityContext sc) {
		try {
			boolean readOnlyValue;
			boolean isApplicationClosed = this.isApplicationClosed(tenant, applicationId, user, sc);
			boolean isApplicationInTransition = Objects
					.equals(applicationDetailsCrudService.findApplicationDetailById(tenant, applicationId).getFlInTransition(), IN_TRANSITION.getFl());
			if (isApplicationClosed || isApplicationInTransition) { // if application is closed or in transition: return true for read only status
				readOnlyValue = true;
			} else { // else, if application is open, return the value of form
				readOnlyValue = Optional.ofNullable(moduleFormConfigsCrudService.findById(tenant, formConfigId))
						.map(x -> {
							if (x.getForceReadOnlyContextFunction() != null && sc.isUserInRole(x.getForceReadOnlyContextFunction())) {
								x.setFlReadOnly(1); // forcing read only
							}
							return x;
						})
						.map(ModuleFormConfigsDTO::getFlReadOnly)
						.map(x -> x == 1)
						.orElse(true);
			}
			return ReadOnlyDto.builder()
					.readOnly(readOnlyValue)
					.build();
		} catch (ObjectNotFoundException e) {
			throw new ObjectNotFoundRuntimeException("form config not found");
		}
	}

	public InfiniteListResults<ApplicationCompileStatusDTO> findCompileStatus(String tenant, Long applicationId, String nextKey) {
		return applicationCompileStatusCrudService.find(tenant, applicationId, nextKey);
	}

	public ApplicationCompileStatusDTO updateCompileStatus(String tenant, Long applicationId, String compileStatusIdentifier,
			ApplicationCompileStatusPayloadDTO appCompileStatusInput, String userid) {
		try {
			applicationsCrudService.findById(tenant, applicationId);
		} catch (ObjectNotFoundException e) {
			throw new ApplicationNotFoundRuntimeException("Application not found");
		}

		ApplicationCompileStatusDTO currentAppCompileStatus;
		try {
			currentAppCompileStatus = applicationCompileStatusCrudService.findByCompileStatusIdentifier(tenant, applicationId, compileStatusIdentifier);
			currentAppCompileStatus.setStatus(appCompileStatusInput.getStatus());
			return applicationCompileStatusCrudService.update(currentAppCompileStatus.getPkid(), currentAppCompileStatus, userid);
		} catch (ObjectNotFoundException e) {
			log.info("compile status not found, inserting it");
			ApplicationCompileStatusDTO toInsert = ApplicationCompileStatusDTO.builder()
					.applicationId(applicationId)
					.compileStatusIdentifier(compileStatusIdentifier)
					.status(appCompileStatusInput.getStatus())
					.build();
			return applicationCompileStatusCrudService.insert(toInsert, userid);
		}
	}

	public void deleteCompileStatus(String tenant, Long applicationId, String compileStatusIdentifier, String username) throws ObjectNotFoundException {
		try {
			applicationsCrudService.findById(tenant, applicationId);
		} catch (ObjectNotFoundException e) {
			log.error("Application not found");
			return;
		}
		try {
			ApplicationCompileStatusDTO currentAppCompileStatus = applicationCompileStatusCrudService
					.findByCompileStatusIdentifier(tenant, applicationId, compileStatusIdentifier);
			applicationCompileStatusCrudService.delete(currentAppCompileStatus.getPkid(), username);
		} catch (Exception e) {
			log.error("error trying to delete compile status");
		}

	}

	public List<DetailedSdkTransitionLog> getApplicationHistoryByApplicationId(String tenant, Long applicationId, User user, SecurityContext sc,
																			   boolean conditionallyHideUser) {
		return historyService.getApplicationHistoryByApplicationId(tenant, applicationId, user)
				.stream()
				.map(x -> {
					var log = DetailLogMapper.INSTANCE.entityToDto(x);
					if (conditionallyHideUser) {
						log.setUserId(conditionallyOverrideUserId(log.getUserId(), sc));
					}
					return log;
				})
				.toList();
	}

	public List<Transition> getAvailableTransitionListByProcessId(String tenant, Long applicationId, User user, String scope) {
		try {
			var application = applicationsCrudService.findById(tenant, applicationId);
			conditionallyThrowApplicationNotFound(tenant, user, application.getPartyId());
			if (forceReadOnlyContextCheckerService.moduleHasReadOnlyAndUserHasIt(user, application.getModuleId())) {
				return Collections.emptyList();
			}
			return applicationsWorkflowService.getUserAvailableTransitions(tenant,applicationId,application.getProcessId(), user, scope);
		} catch (ObjectNotFoundException e) {
			throw new ApplicationNotFoundRuntimeException(e.getMessage());
		}
	}

	public ApplicationInTransitionDTO getApplicationInTransition(String tenant, Long applicationId, User user) {
		try {
			var application = applicationsCrudService.findByIdAlsoExpired(tenant, applicationId);
			conditionallyThrowApplicationNotFound(tenant, user, application.getPartyId());
			if (application.getProcessId() != null) {
				var applicationDetails = applicationDetailsCrudService.findApplicationDetailByIdAlsoExpired(tenant, applicationId);
				var historyLog = this.getApplicationHistoryByApplicationId(tenant, applicationId, user, null, true);
				return ApplicationInTransitionDTO.builder()
						.inTransition(applicationDetails.getFlInTransition() == 1)
						.lastTransitionLog(historyLog.stream().max(Comparator.comparing(DetailedSdkTransitionLog::getStartDate)).orElse(null))
						.build();
			} else {
				return ApplicationInTransitionDTO.builder()
						.inTransition(true)
						.build();
			}
		} catch (ObjectNotFoundException e) {
			throw new ApplicationNotFoundRuntimeException(e.getMessage());
		}
	}

	private void conditionallyThrowApplicationNotFound(String tenant, User user, Long partyId) {
		try {
			this.checkPartyService.checkCanReadParty(tenant, partyId, user);
		} catch (ActionNotAuthorizedRuntimeException e) {
			throw new ApplicationNotFoundRuntimeException("not found");
		}
	}

	public void checkCanReadByAppId(String tenant, Long applicationId, User user) {
		var application = applicationsCrudService.findWithDetailsByApplicationId(tenant, applicationId);
		this.checkCanRead(tenant, application.getPartyId(), user);
	}

	public void checkCanRead(String tenant, Long partyId, User user) {
		this.checkPartyService.checkCanReadParty(tenant, partyId, user);
	}

	public void progress(String tenant, Long applicationId, String tagName, User user, String scope, ProgressApplicationDTO progressApplicationDTO,
			ProgressTypeEnum progressType) throws ObjectNotFoundException {
		var application = applicationsCrudService.findById(tenant, applicationId);
		conditionallyThrowApplicationNotFound(tenant, user, application.getPartyId());
		progressService.progress(tenant, applicationId, tagName, user, scope, progressApplicationDTO, progressType);
	}

	public void progress(String tenant, Long applicationId, Integer transitionId, User user, String scope, ProgressApplicationDTO progressApplicationDTO,
			ProgressTypeEnum progressType) throws Exception {
		var application = applicationsCrudService.findById(tenant, applicationId);
		conditionallyThrowApplicationNotFound(tenant, user, application.getPartyId());
		jdbi.useTransaction(handle -> {
			progressService.progress(tenant, applicationId, transitionId, user, scope, progressApplicationDTO, progressType);
		});
	}

	public List<ApplicationGeneratedPrintDTO> checkForOngoingPrints(String tenant, Long applicationId, List<String> printCodeList) {
		return printCodeList.stream()
				.map(printCode -> this.applicationGeneratedPrintCrudService.findOngoingPrintByCode(tenant, applicationId, printCode))
				.flatMap(Collection::stream)
				.collect(Collectors.toList());
	}

	public List<ApplicationGeneratedCalculationDTO> checkForOngoingCalculations(String tenant, Long applicationId, List<String> calculationCodeList) {
		return calculationCodeList.stream()
				.map(printCode -> this.applicationGeneratedCalculationCrudService.findOngoingCalculationByCode(tenant, applicationId, printCode))
				.flatMap(Collection::stream)
				.collect(Collectors.toList());
	}

	public ModuleWithParamsPublicDTO getModuleFormConfigsByModuleCode(String tenant, String moduleCode) {
		return formConfigService.findModuleFormConfigsByModuleCode(tenant, moduleCode);
	}

	public List<String> getOptionCodesByTenantAndModule(String tenant, String moduleCode) {

		List<ModuleFormConfigsDTO> moduleFormConfigs = moduleFormConfigsCrudService.findByModuleCodeAndTenant(tenant, moduleCode);

		List<String> optionCodes = moduleFormConfigParamCrudService.findOptionCodesByModuleFormConfigIds(
				moduleFormConfigs
						.stream()
						.map(ModuleFormConfigsDTO::getId)
						.collect(Collectors.toList()));
		return optionCodes.stream().map(x -> x.split(",")).flatMap(Arrays::stream).collect(Collectors.toList());
	}

	public static Optional<String> computeApplicationProfilesDescription(List<ApplicationProfileDTO> profileList) {
		StringBuffer applicationProfilesDescription = new StringBuffer("");
		if (profileList != null) {
			profileList.forEach(p -> {
				if (p.getProfileLabelExposed() != null && p.getProfileLabelExposed() && p.getProfileCodeDescription() != null) {
					if (applicationProfilesDescription.length() > 0)
						applicationProfilesDescription.append(", ");
					applicationProfilesDescription.append(p.getProfileCodeDescription());
				}
			});
		}
		return Optional.ofNullable(applicationProfilesDescription.length() > 0 ? applicationProfilesDescription.toString() : null);
	}

	public void logicallyDeleteApplications(List<Long> applicationIdList, User user) {
		jdbi.useTransaction(handle -> {
			applicationIdList.forEach(applicationId -> {
				deleteApplicationChildren(toString(), applicationId, user); // delete child
				applicationsCrudService.delete(applicationId, user.getUserId()); // delete parent
			});
		});
	}

	@Override
	public CreateApplicationOutSdkDTO createApplication(String tenant, User user, CreateApplicationInSdkDTO payload, CreateProcessType createProcessType) {
		var result = this.createApplication(tenant, user, CreateApplicationInDTO.builder()
				.partyId(payload.getPartyId())
				.sectorCode(payload.getSectorCode())
				.moduleCode(payload.getModuleCode())
				.amendmentApplicationId(payload.getAmendmentApplicationId())
				.parentApplicationId(payload.getParentApplicationId())
				.build(), createProcessType, payload.getLocale());

		return CreateApplicationOutSdkDTO.builder()
				.applicationId(result.getApplicationId())
				.applicationCode(result.getApplicationCode())
				.anomalies(result.getAnomalies()
						.stream()
						.map(x -> {
							Map<String, Object> map = new HashMap<>();
							map.put("code", x.getCode());
							map.put("message", x.getMessage());
							return map;
						})
						.collect(Collectors.toList()))
				.build();
	}

	@Override
	public void deleteApplication(String tenant, Long applicationId, User user) {
		this.logicallyDeleteApplications(List.of(applicationId), user);
	}

	@Override
	public void deleteApplicationChildren(String tenant, Long applicationId, User user) {
		applicationsRelationCrudService.findByParentApplicationId(applicationId)
				.forEach(relation -> {
					applicationsRelationCrudService.delete(relation.getPkid(), user.getUserId());
					applicationsCrudService.delete(relation.getChildApplicationId(), user.getUserId());
				});
	}
}
