package com.abacogroup.agri.applications.bundles.processor.amendable;

import com.abacogroup.agri.applications.bundles.model.amendable.BundleAmendableModuleInDTO;
import com.abacogroup.agri.applications.bundles.model.amendable.BundleAmendableModulesMessage;
import com.abacogroup.agri.applications.core.exceptions.ObjectNotFoundRuntimeException;
import com.abacogroup.agri.applications.core.model.dto.AmendableModuleDTO;
import com.abacogroup.agri.applications.core.model.dto.ModuleDTO;
import com.abacogroup.agri.applications.core.services.crud.AmendableModuleCrudService;
import com.abacogroup.agri.applications.core.services.crud.ModuleCrudService;
import com.abacogroup.bundles.listener.tenant.TenantMessage;
import com.abacogroup.bundles.listener.tenant.TenantMessageProcessor;
import lombok.extern.slf4j.Slf4j;
import org.jdbi.v3.core.Jdbi;

import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import static com.abacogroup.agri.applications.bundles.BundleConstants.TENANT_TEMPLATE_CODE;

/**
 * @author Samuele Sbarbaro
 */
@Slf4j
public class AmendableModuleNewTenantProcessor implements TenantMessageProcessor {

    protected final Jdbi jdbi;
    protected final AmendableModulesBundleWorker amendableModulesBundleWorker;
    public AmendableModuleNewTenantProcessor(Jdbi jdbi, AmendableModulesBundleWorker amendableModulesBundleWorker) {
        this.jdbi = jdbi;
        this.amendableModulesBundleWorker = amendableModulesBundleWorker;
    }

    @Override
    public void onMessage(TenantMessage message) {
        jdbi.useTransaction(handle -> {
            log.info("AmendableModuleNewTenantProcessor got new tenant {}", message.getTenantId());
            checkAndInsertAmendableModules(message.getTenantId());
            log.info("AmendableModuleNewTenantProcessor end working with new tenant {}", message.getTenantId());
        });
    }



    private void checkAndInsertAmendableModules(final String tenantId) {
        log.info("AmendableModuleNewTenantProcessor check and insert new tenant {}", tenantId);
        AmendableModuleCrudService amendableModuleCrudService = amendableModulesBundleWorker.exposeAmendableModuleCrudService();
        ModuleCrudService moduleCrudService = amendableModulesBundleWorker.exposeModuleCrudService();

        List<BundleAmendableModuleInDTO> bundleAmendableModuleInDTOS = new ArrayList<>();

        List<AmendableModuleDTO> amendableModuleDTOS = amendableModuleCrudService.findAllByTenant(TENANT_TEMPLATE_CODE).stream()
                .distinct()
                .collect(Collectors.toList());


        amendableModuleDTOS.forEach(amendableModuleDTO -> {
            ModuleDTO moduleToAmend = moduleCrudService.findById(amendableModuleDTO.getAmendableModuleId())
                    .orElseThrow(() -> new ObjectNotFoundRuntimeException(MessageFormat.format("Module with code: {0} not found", amendableModuleDTO.getAmendableModuleId())));


            ModuleDTO module = moduleCrudService.findById(amendableModuleDTO.getModuleId())
                    .orElseThrow(() -> new ObjectNotFoundRuntimeException(MessageFormat.format("Module with code: {0} not found", amendableModuleDTO.getAmendableModuleId())));

            bundleAmendableModuleInDTOS.add(BundleAmendableModuleInDTO.builder()
                            .sectorCode(getSectorCode(module))
                            .moduleCode(module.getModuleCode())
                            .amendableModuleCode(moduleToAmend.getModuleCode())
                    .build());

        });
        amendableModulesBundleWorker.upsertBundleModules(tenantId, BundleAmendableModulesMessage.builder()
                        .amendableModules(bundleAmendableModuleInDTOS)
                .build());

    }

    private String getSectorCode(ModuleDTO module) {
        try {
            return amendableModulesBundleWorker.exposeSectorCrudService()
                    .findById(TENANT_TEMPLATE_CODE, module.getSectorId())
                    .getSectorCode();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}
