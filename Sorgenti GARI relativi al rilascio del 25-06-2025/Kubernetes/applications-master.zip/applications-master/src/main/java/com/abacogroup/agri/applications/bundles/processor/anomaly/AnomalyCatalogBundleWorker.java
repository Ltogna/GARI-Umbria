package com.abacogroup.agri.applications.bundles.processor.anomaly;

import com.abacogroup.agri.applications.bundles.model.anomaly.BundleAnomalyCatalogMessage;
import com.abacogroup.agri.applications.core.exceptions.ObjectNotFoundException;
import com.abacogroup.agri.applications.core.exceptions.ObjectNotFoundRuntimeException;
import com.abacogroup.agri.applications.core.model.dto.publics.AnomalyCatalogDTO;
import com.abacogroup.agri.applications.core.services.crud.AnomalyCatalogCrudService;
import com.abacogroup.agri.applications.core.services.crud.ModuleCrudService;
import com.abacogroup.agri.applications.db.ntt.compoundkeys.AnomalyCatalogKey;
import lombok.extern.slf4j.Slf4j;

/**
 * @author Gennaro Tamburrelli
 */
@Slf4j
public class AnomalyCatalogBundleWorker {

	protected final AnomalyCatalogCrudService anomalyCatalogCrudService;
	protected final ModuleCrudService moduleCrudService;

	public AnomalyCatalogBundleWorker(AnomalyCatalogCrudService anomalyCatalogCrudService,
			ModuleCrudService moduleCrudService) {
		this.anomalyCatalogCrudService = anomalyCatalogCrudService;
		this.moduleCrudService = moduleCrudService;
	}

	public AnomalyCatalogCrudService exposeAnomalyCatalogCrudService() {
		return this.anomalyCatalogCrudService;
	}

	public void upsertBundleAnomalyCatalog(String tenantId, BundleAnomalyCatalogMessage message) {
		log.info("AnomalyCatalogBundleWorker: processing file with tenant {}", tenantId);
		message.getAnomalies()
				.stream()
				.forEachOrdered(anomaly -> {
					try {
						log.info("AnomalyCatalogBundleWorker: inserting type with tenant {} and code {}", tenantId, anomaly.getAnomalyCode());
						moduleCrudService.findByCode(tenantId, anomaly.getModuleCode())
								.ifPresentOrElse(moduleDTO -> {
									try {
										var existingAnomaly = anomalyCatalogCrudService.findById(AnomalyCatalogKey.builder()
												.anomaly_code(anomaly.getAnomalyCode())
												.module_id(moduleDTO.getModuleId())
												.build());
										log.info("found existing anomaly {}", anomaly.getAnomalyCode());
										log.info("deleting i18n for reinserting later");
										anomaly.getI18n().forEach(
												x -> anomalyCatalogCrudService.deleteAnomalyCatalogI18N(tenantId, anomaly.getAnomalyCode(), x.getLang()));
										log.info("deleted");
									} catch (ObjectNotFoundException e) {
										log.info("inserting");
										anomalyCatalogCrudService.insert(AnomalyCatalogDTO.builder()
												.anomalyCode(anomaly.getAnomalyCode())
												.moduleId(moduleDTO.getModuleId())
												.severity(anomaly.getSeverity())
												.build());
										log.info("inserted");
									}

									log.info("AnomalyCatalogBundleWorker: inserting i18n with tenant {} and code {}", tenantId, anomaly.getAnomalyCode());
									anomaly.getI18n()
											.stream()
											.forEachOrdered(val -> anomalyCatalogCrudService.insertAnomalyCatalogI18N(tenantId,
													anomaly.getAnomalyCode(),
													val.getLang(),
													val.getDescription()));
								}, () -> {
									throw new ObjectNotFoundRuntimeException("module code not found");
								});
					} catch (Exception e) {
						log.error("error while inserting anomaly catalog");
					}

				});
	}

	public void deleteAnomalyCatalog(String tenantId, BundleAnomalyCatalogMessage message) {
		log.info("AnomalyCatalogBundleWorker: processing file with tenant {}", tenantId);
		message.getAnomalies()
				.stream()
				.forEachOrdered(anomaly -> {
					log.info("AnomalyCatalogBundleWorker: deleting type with tenant {} and code {}", tenantId, anomaly.getAnomalyCode());
					moduleCrudService.findByCode(tenantId, anomaly.getModuleCode())
							.ifPresentOrElse(moduleDTO -> {
								try {
									anomalyCatalogCrudService.deleteByIdAndModuleId(anomaly.getAnomalyCode(), moduleDTO.getModuleId());
									log.info("AnomalyCatalogBundleWorker: deleting i18n with tenant {} and code {}", tenantId, anomaly.getAnomalyCode());
									anomalyCatalogCrudService.getAllAnomalyCatalogI18NByTenantAndCode(tenantId, anomaly.getAnomalyCode())
											.stream()
											.forEachOrdered(val -> anomalyCatalogCrudService.deleteAnomalyCatalogI18N(tenantId,
													anomaly.getAnomalyCode(),
													val.getLang()));
								} catch (Exception e) {
									log.error("error trying to delete anomaly catalog", e);
								}
							}, () -> {
								throw new ObjectNotFoundRuntimeException("module code not found");
							});

				});
	}
}
