package com.abacogroup.agri.applications.core.model.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author Gennaro Tamburrelli
 */
@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
public class CountDTO {
	private Long count;
}
