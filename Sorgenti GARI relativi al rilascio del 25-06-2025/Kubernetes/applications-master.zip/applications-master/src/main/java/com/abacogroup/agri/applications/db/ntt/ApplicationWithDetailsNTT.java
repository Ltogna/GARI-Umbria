package com.abacogroup.agri.applications.db.ntt;

import java.time.LocalDateTime;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

/**
 * @author Alexandru Paraschiv
 */
@EqualsAndHashCode(callSuper = true)
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class ApplicationWithDetailsNTT extends ApplicationNTT {

	private String application_code;
	private String process_status;
	private LocalDateTime dt_presentation;
	private String sector_code;
	private String sector_description;
	private String module_code;
	private String module_description;
	private Long amended_by_id;
	private Long amend_of_id;
	private Integer module_year;
}
