package com.abacogroup.agri.applications.utils;

public class DbUtils {

	private DbUtils() {
	}

	public static Boolean mainDbIsPostgres;
}
