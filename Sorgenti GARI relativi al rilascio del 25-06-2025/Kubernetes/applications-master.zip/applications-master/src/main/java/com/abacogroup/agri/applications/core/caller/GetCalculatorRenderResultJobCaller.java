package com.abacogroup.agri.applications.core.caller;

import com.abacogroup.agri.applications.core.model.dto.CalculatorRenderResponse;
import com.abacogroup.jaxrsutils.GenericCallerService;
import com.abacogroup.jaxrsutils.callerv2.AbacoDtoCaller;

/**
 * @author Alexandru Paraschiv
 */
public class GetCalculatorRenderResultJobCaller extends AbacoDtoCaller<GetCalculatorRenderJobInput, CalculatorRenderResponse> {

	public GetCalculatorRenderResultJobCaller(GenericCallerService genericCallerService) {
		super(genericCallerService);
	}

}
