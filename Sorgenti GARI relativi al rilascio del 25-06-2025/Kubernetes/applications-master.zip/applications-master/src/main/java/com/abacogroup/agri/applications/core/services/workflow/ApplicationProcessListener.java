package com.abacogroup.agri.applications.core.services.workflow;

import static com.abacogroup.agri.applications.core.services.crud.ApplicationsCrudService.FIND_EXPIRED;

import java.util.Map;

import com.abacogroup.agri.applications.core.model.ProcessTransitionEnum;
import com.abacogroup.agri.applications.core.services.crud.ApplicationDetailsCrudService;
import com.abacogroup.agri.applications.core.services.crud.ApplicationsCrudService;
import com.abacogroup.applicationworkflowsdk.model.ApplicationsWorkflowParams;
import com.abacogroup.workflow.server.model.ProcessTransitionResult;
import com.abacogroup.workflow.server.services.ProcessListener;

import lombok.extern.slf4j.Slf4j;

/**
 * @author Gennaro Tamburrelli
 */
@Slf4j
public class ApplicationProcessListener implements ProcessListener {

	private final ApplicationsCrudService applicationsCrudService;
	private final ApplicationDetailsCrudService applicationDetailsCrudService;
	private final ApplicationExchangePublisher applicationExchangePublisher;

	public ApplicationProcessListener(ApplicationsCrudService applicationsCrudService,
                                      ApplicationDetailsCrudService applicationDetailsCrudService, ApplicationExchangePublisher applicationExchangePublisher) {
		this.applicationsCrudService = applicationsCrudService;
		this.applicationDetailsCrudService = applicationDetailsCrudService;
        this.applicationExchangePublisher = applicationExchangePublisher;
    }

	private void callOnUpdate(ProcessTransitionResult processTransitionResult) {
		try {
			Map<String, Object> globalVars = processTransitionResult.getGlobalVars();
			ApplicationsWorkflowParams params = (ApplicationsWorkflowParams) globalVars.get(ApplicationsWorkflowParams.KEY);
			log.debug("updating details...");
			applicationDetailsCrudService.updateProcessStatusAndFlTransition(params.getTenant(),
					params.getApplicationId(), processTransitionResult.getCurrentNode(),
					processTransitionResult.getLastTransitionLog().getUserId(), ProcessTransitionEnum.NOT_IN_TRANSITION);

			if(!processTransitionResult.getLastTransitionLog().isFailed()) {
				applicationExchangePublisher.addQueue(params, processTransitionResult);
				// TOPIC: `transition.${codSettore}.${codModulo}.${transitionCode ?? 'NONE'}`
				// payload //id domanda, codice settore, codice modulo, nuovo stato, codice transizione (prendo nuovo campo code in arrivo da processTransitionResult della prima transizione .get(0))
			}
			log.debug("updating details...done");
		} catch (Exception e) {
			log.error(e.getMessage(), e);
		}
	}

	private void callOnCompleted(ProcessTransitionResult processTransitionResult) {
		try {
			Map<String, Object> globalVars = processTransitionResult.getGlobalVars();
			ApplicationsWorkflowParams params = (ApplicationsWorkflowParams) globalVars.get(ApplicationsWorkflowParams.KEY);
			log.debug("is creation, updating process id");
			applicationsCrudService.getApplicationAndUpdateProcessId(params.getTenant(), params.getApplicationId(),
					processTransitionResult.getProcessId(), FIND_EXPIRED);
			log.debug("is creation, updating process id...done");
		} catch (Exception e) {
			log.error(e.getMessage(), e);
		}
	}

	@Override
	public void onProcessCreated(ProcessTransitionResult processTransitionResult) {
		log.debug("executing onProcessCreated");
		this.callOnCompleted(processTransitionResult);
		log.debug("executing onProcessCreated...done");
	}

	@Override
	public void onTransitionCompleted(ProcessTransitionResult processTransitionResult) {
		log.debug("executing onTransitionCompleted");
		this.callOnUpdate(processTransitionResult);
		log.debug("executing onTransitionCompleted...done");
	}
}
