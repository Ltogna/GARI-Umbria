package com.abacogroup.agri.applications.core.mappers;

import com.abacogroup.agri.applications.core.model.dto.ApplicationProfileDTO;
import com.abacogroup.applicationworkflowsdk.model.io.output.ApplicationProfilePublicDTO;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

@Mapper
public interface ApplicationProfilePublicMapper {

	ApplicationProfilePublicMapper INSTANCE = Mappers.getMapper(ApplicationProfilePublicMapper.class);

	@InheritInverseConfiguration()
	ApplicationProfileDTO publicToDto(ApplicationProfilePublicDTO entity);

	@Mapping(source = "profileCode", target = "profileCode")
	@Mapping(source = "profileCodeDescription", target = "profileCodeDescription")
	ApplicationProfilePublicDTO dtoToPublic(ApplicationProfileDTO dto);

}
