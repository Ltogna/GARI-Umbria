package com.abacogroup.agri.applications.bundles.processor.childmodule;

import com.abacogroup.agri.applications.bundles.BundleConstants;
import com.abacogroup.agri.applications.bundles.model.chilldmodule.BundleChildModuleInDTO;
import com.abacogroup.agri.applications.bundles.model.chilldmodule.BundleChildrenModulesMessage;
import com.abacogroup.agri.applications.core.exceptions.ObjectNotFoundRuntimeException;
import com.abacogroup.agri.applications.core.model.dto.ChildModuleDTO;
import com.abacogroup.agri.applications.core.model.dto.ModuleDTO;
import com.abacogroup.agri.applications.core.services.crud.ChildModuleCrudService;
import com.abacogroup.agri.applications.core.services.crud.ModuleCrudService;
import com.abacogroup.agri.applications.core.services.crud.SectorsCrudService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import java.text.MessageFormat;
import java.util.Optional;

/**
 * @author Mattia Perini
 */
@Slf4j
public class ChildrenModulesBundleWorker {

    private final ChildModuleCrudService childModuleCrudService;
    private final ModuleCrudService moduleCrudService;
    private final SectorsCrudService sectorsCrudService;

    public ChildrenModulesBundleWorker(ChildModuleCrudService childModuleCrudService,
                                       ModuleCrudService moduleCrudService, SectorsCrudService sectorsCrudService) {
        this.childModuleCrudService = childModuleCrudService;
        this.moduleCrudService = moduleCrudService;
        this.sectorsCrudService = sectorsCrudService;
    }

    public ChildModuleCrudService exposeChildModuleCrudService() {
        return this.childModuleCrudService;
    }

    public ModuleCrudService exposeModuleCrudService() {
        return this.moduleCrudService;
    }

    public SectorsCrudService exposeSectorCrudService() {
        return this.sectorsCrudService;
    }

    public void upsertBundleChildrenModules(String tenantId, BundleChildrenModulesMessage message) {
        log.info("ChildrenModulesBundleWorker: processing file with tenant {}", tenantId);
        message.getChildrenModules().forEach(childModule -> {
            try {
                getChildModuleDTO(tenantId, childModule, Boolean.TRUE).ifPresentOrElse(
                        childModuleToUpdate -> {
                            log.info("ChildrenModulesBundleWorker: updating child module with tenant {} and moduleCode {} and parentModuleCode {}", tenantId, childModule.getModuleCode(), childModule.getOldParentModuleCode());

                            ModuleDTO newParentModule = findModuleByCode(tenantId, childModule.getParentModuleCode());

                            ChildModuleDTO childModuleUpdated = ChildModuleDTO.builder()
                                    .moduleId(childModuleToUpdate.getModuleId())
                                    .parentModuleId(newParentModule.getModuleId())
                                    .build();

                            childModuleCrudService.update(childModuleToUpdate.getPkid(), childModuleUpdated, BundleConstants.BUNDLE_SYSTEM_USERNAME);
                        },
                        () -> {
                            log.info("ChildrenModulesBundleWorker: inserting child module with tenant {} and moduleCode {} and parentModuleCode {}", tenantId, childModule.getModuleCode(), childModule.getParentModuleCode());

                            ModuleDTO moduleIdToInsert = findModuleByCode(tenantId, childModule.getModuleCode());
                            ModuleDTO parentModuleIdToInsert = findModuleByCode(tenantId, childModule.getParentModuleCode());

                            ChildModuleDTO childModuleToInsert = ChildModuleDTO.builder()
                                    .moduleId(moduleIdToInsert.getModuleId())
                                    .parentModuleId(parentModuleIdToInsert.getModuleId())
                                    .build();

                            childModuleCrudService.insert(childModuleToInsert, BundleConstants.BUNDLE_SYSTEM_USERNAME);
                        });
            } catch (Exception e) {
                log.error("ChildrenModulesBundleWorker: error while inserting child module");
                throw e;
            }
        });
    }

    public void deleteBundleChildrenModules(String tenantId, BundleChildrenModulesMessage message) {
        log.info("ChildrenModulesBundleWorker: processing delete file with tenant {}", tenantId);
        message.getChildrenModules().forEach(childModule ->
                getChildModuleDTO(tenantId, childModule, Boolean.FALSE)
                        .ifPresentOrElse(
                                childModuleToDelete -> {
                                    log.info("ChildrenModulesBundleWorker: deleting childModule {}", childModuleToDelete.getPkid());
                                    childModuleCrudService.delete(childModuleToDelete.getPkid(), BundleConstants.BUNDLE_SYSTEM_USERNAME);
                                    log.info("ChildrenModulesBundleWorker: childModule {} deleted", childModuleToDelete.getPkid());
                                },
                                () -> {
                                    log.info("ChildrenModulesBundleWorker: childModule with module code {} and parent module code {} not found: cannot be deleted", childModule.getModuleCode(), childModule.getParentModuleCode());
                                    throw new ObjectNotFoundRuntimeException();
                                })
        );
    }

    public Optional<ChildModuleDTO> getChildModuleDTO(String tenantId, BundleChildModuleInDTO childModule, Boolean useOldCode) {
        if (Boolean.TRUE.equals(useOldCode) && StringUtils.isAllBlank(childModule.getOldParentModuleCode())) {
            log.debug("ChildrenModulesBundleWorker: no old parent module code passed, skip the search for old child module to update");
            return Optional.empty();
        }

        String parentModuleCodeToSearch = Boolean.TRUE.equals(useOldCode) ? childModule.getOldParentModuleCode() : childModule.getParentModuleCode();

        log.info("ChildrenModulesBundleWorker: search for child module with module code {} and parent module code {}", childModule.getModuleCode(), parentModuleCodeToSearch);

        ModuleDTO moduleDTO;
        ModuleDTO parentModuleDTO;

        if(childModule.getSectorCode() != null) {
            moduleDTO = findBySectorCodeAndModuleCode(tenantId, childModule.getSectorCode(), childModule.getModuleCode());
            parentModuleDTO = findBySectorCodeAndModuleCode(tenantId, childModule.getSectorCode(), parentModuleCodeToSearch);
        } else { // for retrocompatibility
            moduleDTO = findModuleByCode(tenantId, childModule.getModuleCode());
            parentModuleDTO = findModuleByCode(tenantId, parentModuleCodeToSearch);
        }


        return childModuleCrudService.findOptByModuleIdAndParentModuleId(moduleDTO.getModuleId(), parentModuleDTO.getModuleId());

    }

    private ModuleDTO findBySectorCodeAndModuleCode(String tenant, String sectorCode, String moduleCode) {
        return moduleCrudService.findByModuleCodeAndSectorCode(tenant, sectorCode, moduleCode)
                .orElseThrow(() -> new ObjectNotFoundRuntimeException(MessageFormat.format("AmendableModulesBundleWorker: module with code: {0} and sector code {1} not found", moduleCode, sectorCode)));
    }

    private ModuleDTO findModuleByCode(String tenant, String moduleCode) {
        return moduleCrudService.findByCode(tenant, moduleCode)
                .orElseThrow(() -> new ObjectNotFoundRuntimeException(MessageFormat.format("ChildrenModulesBundleWorker: module with code: {0} not found", moduleCode)));
    }
}
