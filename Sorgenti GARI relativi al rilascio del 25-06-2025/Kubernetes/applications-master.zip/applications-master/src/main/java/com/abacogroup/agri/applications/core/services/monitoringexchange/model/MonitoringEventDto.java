package com.abacogroup.agri.applications.core.services.monitoringexchange.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author Gennaro Tamburrelli
 */
@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
public class MonitoringEventDto {
    private String group_code;
    private Boolean has_error;
}
