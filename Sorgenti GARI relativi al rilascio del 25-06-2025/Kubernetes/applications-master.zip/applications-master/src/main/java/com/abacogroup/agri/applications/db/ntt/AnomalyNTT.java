package com.abacogroup.agri.applications.db.ntt;

import com.abacogroup.agri.applications.db.ntt.applications.IHistoricizationFields;
import com.abacogroup.agri.applications.db.ntt.applications.IIdRs;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.time.LocalDateTime;
import java.util.Optional;

/**
 * @author Gennaro Tamburrelli
 */
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class AnomalyNTT implements IIdRs<Long>, IHistoricizationFields {

	private Long pkid;
	private Long application_id;
	private String anomaly_code;
	private String anomaly_desc;
	private String severity;
	private String user_id_insert;
	private String user_id_delete;
	private LocalDateTime dt_insert;
	private LocalDateTime dt_delete;

	@Override
	public Optional<Long> getKey() {
		return Optional.ofNullable(this.pkid);
	}

	@Override
	public void setKey(Long id) {
		this.pkid = id;
	}
}
