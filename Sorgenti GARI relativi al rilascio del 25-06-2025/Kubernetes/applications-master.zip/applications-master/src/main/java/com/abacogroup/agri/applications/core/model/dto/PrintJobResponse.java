package com.abacogroup.agri.applications.core.model.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true) // tolerate foreign APIs evolution
public class PrintJobResponse {

	private String uuid;
	private PrintJobStatus status;
	private String fileStoreId;
	private String bucket;
	private String dest;
}
