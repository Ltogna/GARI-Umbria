package com.abacogroup.agri.applications.core.services.crud;

import com.abacogroup.agri.applications.core.exceptions.ObjectNotFoundException;
import com.abacogroup.agri.applications.core.mappers.ModuleDetailsMapper;
import com.abacogroup.agri.applications.core.model.dto.ModuleDetailsDTO;
import com.abacogroup.agri.applications.db.dao.ModuleDetailsDAO;
import com.abacogroup.agri.applications.db.ntt.ModuleDetailsNTT;
import lombok.extern.slf4j.Slf4j;

import java.time.LocalDateTime;
import java.util.Optional;

/**
 * @author Gennaro Tamburrelli
 */
@Slf4j
public class ModuleDetailsCrudService extends AbstractHistoricizationFieldsCrudService<ModuleDetailsNTT, Long, ModuleDetailsDTO, ModuleDetailsMapper, Void> {

	public ModuleDetailsCrudService(ModuleDetailsDAO dao, ModuleDetailsMapper mapper) {
		super(dao, mapper);
	}

	@Override protected boolean hasPrimaryKey() {
		return true;
	}

	@Override protected Void retrieveCustomKeyByResultSet(ModuleDetailsNTT rs) {
		return null;
	}

	@Override protected ModuleDetailsNTT adjustR(ModuleDetailsNTT rs) throws Exception {
		return rs;
	}

	@Override protected Optional<ModuleDetailsNTT> findRsByCustomKey(Void customKey) {
		return Optional.empty();
	}

	public ModuleDetailsDTO insert(ModuleDetailsDTO in, String username) {
		log.info("Invoking insert with params in: {} username: {}", in, username);
		return this.insert(in, username, null, this.dao.getCurrentTimestamp());
	}

	public ModuleDetailsDTO update(Long key, ModuleDetailsDTO in, String username) {
		log.info("Invoking update with params key: {} in: {} username: {}", key, in, username);
		return this.update(key, in, username, null);
	}

	public void delete(Long key, String username) {
		log.info("Invoking delete with params key: {} username: {}", key, username);
		this.delete(key, username, null);
	}

	public void deleteByModuleId(Long moduleId, String username) {
		log.info("Invoking delete with params key: {} username: {}", moduleId, username);
		((ModuleDetailsDAO) dao).logicallyDeleteByModuleId(moduleId, username, LocalDateTime.now());
	}

	public ModuleDetailsDTO findById(Long key) throws ObjectNotFoundException {
		log.info("Invoking find by  with params key: {}", key);
		return this.findOutDtoByPrimaryKey(key);
	}

	public ModuleDetailsDTO findByModuleId(String tenantId, Long moduleId) {
		log.info("Invoking findByModuleId by  with params moduleId: {}", moduleId);
		return returnOptionalRecord(((ModuleDetailsDAO) this.dao).findByModuleId(tenantId, moduleId))
				.orElse(null);
	}

	public ModuleDetailsDTO findByModuleCode(String tenantId, String moduleCode) {
		log.info("Invoking findByModuleCode by  with params moduleCode: {}", moduleCode);
		return returnOptionalRecord(((ModuleDetailsDAO) this.dao).findByModuleCode(tenantId, moduleCode))
				.orElse(null);
	}

	public ModuleDetailsDTO checkValidityByPkId(Long pkId) {
		return returnOptionalRecord(((ModuleDetailsDAO) this.dao).findByPkIdCheckingDtValidity(pkId))
				.orElse(null);
	}

}
