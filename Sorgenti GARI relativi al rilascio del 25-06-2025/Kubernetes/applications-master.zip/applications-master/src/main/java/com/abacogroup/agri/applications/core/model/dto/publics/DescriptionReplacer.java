package com.abacogroup.agri.applications.core.model.dto.publics;

public interface DescriptionReplacer {
	String getDescription();
	void setDescription(String parsedDescription);
}
