package com.abacogroup.agri.applications.core.caller;

import com.abacogroup.jaxrsutils.callerv2.ICallerInput;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.HashMap;
import java.util.Map;

import static com.abacogroup.jaxrsutils.GenericCallerService.GET_METHOD;

/**
 * @author Gennaro Tamburrelli
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class CreateCustomApplicationIdInput implements ICallerInput {

	private String url;
	private String tenant;
	private String token;
	private Long partyId;
	private String sectorCode;
	private String moduleCode;
	private Integer referredYear;

	@Override
	public Map<String, Object> getPathVariablesMap() {
		return Map.of("TENANT_ID", this.tenant,
				"PARTY_ID", this.partyId,
				"SECTOR_CODE", this.sectorCode,
				"MODULE_CODE", this.moduleCode);
	}

	@Override
	public Map<String, Object> getQueryParamsMap() {
		var map = new HashMap<String, Object>();
		map.put("referredYear", this.referredYear);
		return map;
	}

	@Override
	public String provideAuthToken() {
		return this.token;
	}

	@Override
	public String getUrl() {
		return this.url; // http://localhost:28080/agea-legacy/{TENANT_ID}/public/v1/parties/{PARTY_ID}/custom-app-id-generation
	}

	@Override
	public String getHttpMethod() {
		return GET_METHOD;
	}
}
