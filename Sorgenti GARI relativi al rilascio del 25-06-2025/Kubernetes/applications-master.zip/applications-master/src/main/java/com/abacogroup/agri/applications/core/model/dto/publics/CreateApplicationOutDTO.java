package com.abacogroup.agri.applications.core.model.dto.publics;

import com.abacogroup.agri.applications.core.model.ApplicationAnomaly;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.util.ArrayList;
import java.util.List;

/**
 * @author Mauro Pozzana
 * @author Gennaro Tamburrelli
 */
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class CreateApplicationOutDTO {
	private Long applicationId;
	private String applicationCode;
	@Builder.Default
	private List<ApplicationAnomaly> anomalies = new ArrayList<>();
}
