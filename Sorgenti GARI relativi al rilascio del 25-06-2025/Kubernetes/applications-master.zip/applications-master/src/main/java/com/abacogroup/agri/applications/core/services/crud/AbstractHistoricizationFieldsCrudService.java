package com.abacogroup.agri.applications.core.services.crud;

import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.Optional;
import java.util.function.Function;
import java.util.stream.Collectors;

import org.jdbi.v3.core.statement.StatementException;

import com.abacogroup.agri.applications.core.exceptions.AgriApplicationsRuntimeException;
import com.abacogroup.agri.applications.core.exceptions.InsertExceptionRuntimeException;
import com.abacogroup.agri.applications.core.exceptions.ObjectNotFoundException;
import com.abacogroup.agri.applications.core.exceptions.ObjectNotFoundRuntimeException;
import com.abacogroup.agri.applications.core.exceptions.StatementExceptionRuntimeException;
import com.abacogroup.agri.applications.core.mappers.EntityMapper;
import com.abacogroup.agri.applications.db.dao.IGenericHistoricizationFieldsDAO;
import com.abacogroup.agri.applications.db.ntt.applications.IHistoricizationFields;
import com.abacogroup.agri.applications.db.ntt.applications.IIdRs;
import com.abacogroup.agri.applications.utils.GenericUtility;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.jdbi.paging.PagedResults;
import com.abacogroup.jdbi.paging.impl.InfiniteListResultsImpl;
import com.abacogroup.jdbi.paging.impl.PagedResultsImpl;

import lombok.extern.slf4j.Slf4j;

/**
 * @author Gennaro Tamburrelli
 */
@Slf4j
public abstract class AbstractHistoricizationFieldsCrudService<R extends IHistoricizationFields & IIdRs<K>, K, D, M extends EntityMapper<D, R>, C> {

	// 9999-12-31@23:59:59
	protected static final LocalDateTime DEFAULT_NOT_DELETED_DATE = LocalDateTime.ofInstant(Instant.ofEpochSecond(253402300799L), ZoneOffset.UTC);

	protected final IGenericHistoricizationFieldsDAO<R, K, C> dao;
	protected final M mapper;

	protected AbstractHistoricizationFieldsCrudService(IGenericHistoricizationFieldsDAO<R, K, C> dao, M mapper) {
		this.dao = dao;
		this.mapper = mapper;
	}

	protected K retrieveKey(C customKey) {
		// default implementation is retrieve id from sequence
		return this.dao.nextSequenceVal();
	}

	protected abstract boolean hasPrimaryKey();

	protected abstract C retrieveCustomKeyByResultSet(R rs);

	protected abstract R adjustR(R rs) throws Exception;

	protected D insert(D dto, String userId, C customKey) {
		return this.insert(dto, userId, customKey, null);
	}

	protected D insert(D dtoIn, String userId, C customKey, LocalDateTime currentTimestamp) {
		return dao.inTransaction(handle -> {
			try {
				K key = this.retrieveKey(customKey);
				R rs = mapper.dtoToEntity(dtoIn);
				rs.setKey(key);
				rs = adjustR(rs);
				dao.insert(rs, userId, Optional.ofNullable(currentTimestamp).orElseGet(dao::getCurrentTimestamp));
				if (hasPrimaryKey() && Optional.ofNullable(customKey).isEmpty()) {
					return findOutDtoByPrimaryKey(key);
				} else {
					return findOutDtoByCustom(customKey);
				}
			} catch (StatementException e) {
				log.error(e.getMessage(), e);
				throw new InsertExceptionRuntimeException("error during insert");
			} catch (ObjectNotFoundException e) {
				throw new ObjectNotFoundRuntimeException();
			} catch (Exception e) {
				throw new AgriApplicationsRuntimeException(e.getMessage());
			}
		});
	}

	protected D findOutDtoByPrimaryKey(K key) throws ObjectNotFoundException {
		return this.findRsByPrimaryKey(key)
				.filter(this::isNotLogicallyDeleted)
				.map(mapper::entityToDto)
				.orElseThrow(AbstractCrudService.OBJECT_NOT_FOUND_EXCEPTION_SUPPLIER);
	}

	protected D findOutDtoByCustom(C customKey) throws ObjectNotFoundException {
		return this.findRsByCustomKey(customKey)
				.filter(this::isNotLogicallyDeleted)
				.map(mapper::entityToDto)
				.orElseThrow(AbstractCrudService.OBJECT_NOT_FOUND_EXCEPTION_SUPPLIER);
	}

	protected Optional<R> findRsByPrimaryKey(K key) {
		return dao.findById(key)
				.stream()
				.filter(this::isNotLogicallyDeleted)
				.findFirst();
	}

	protected abstract Optional<R> findRsByCustomKey(C customKey);

	protected void delete(K key, String userId, C customKey) {
		this.delete(key, userId, customKey, null);
	}

	protected void delete(K key, String userId, C customKey, LocalDateTime logicalDeletionTimestamp) {
		LocalDateTime currentTimestamp;
		if (logicalDeletionTimestamp == null) {
			currentTimestamp = dao.getCurrentTimestamp().minus(1, ChronoUnit.MILLIS);
		} else {
			currentTimestamp = logicalDeletionTimestamp;
		}

		dao.useTransaction(handle -> {
			try {

				if (hasPrimaryKey() && Optional.ofNullable(customKey).isEmpty()) {
					dao.logicallyDeleteById(key, userId, currentTimestamp);
				} else {
					dao.logicallyDeleteByCustomKey(customKey, userId, currentTimestamp);
				}

			} catch (StatementException e) {
				log.error(e.getMessage(), e);
				throw new StatementExceptionRuntimeException("error during delete");
			} catch (ObjectNotFoundRuntimeException e) {
				throw new ObjectNotFoundRuntimeException();
			} catch (Exception e) {
				throw new AgriApplicationsRuntimeException(e.getMessage());
			}
		});
	}

	protected D update(K key, D newRecord, String userId, C customKey) {
		return dao.inTransaction(handle -> {
			assert (userId != null);
			LocalDateTime now = this.dao.getCurrentTimestamp();
			LocalDateTime deleteTime = now.minus(1, ChronoUnit.MILLIS);
			this.delete(key, userId, customKey, deleteTime);
			return this.insert(newRecord, userId, customKey, now);
		});
	}

	protected PagedResults<D> returnPagedResults(PagedResults<R> pagedResult) {
		List<D> records = pagedResult.getRecords()
				.stream()
				.filter(this::isNotLogicallyDeleted)
				.map(mapper::entityToDto)
				.collect(Collectors.toList());

		return new PagedResultsImpl<>(records.size(),
				pagedResult.getOffset(),
				records);
	}

	protected <Y, A> InfiniteListResults<A> returnInfiniteResults(InfiniteListResults<Y> infiniteListResults, Function<Y, A> customMapper) {
		return new InfiniteListResultsImpl<>(
				infiniteListResults.getRecords()
						.stream()
						.map(customMapper)
						.collect(Collectors.toList()),
				infiniteListResults.getNextKey());
	}

	protected InfiniteListResults<D> returnInfiniteResults(InfiniteListResults<R> infiniteListResults) {
		return GenericUtility.returnInfiniteResults(infiniteListResults, mapper::entityToDto);
	}

	protected List<D> returnMappedList(List<R> recordList) {
		return GenericUtility.returnMappedList(recordList, mapper::entityToDto);
	}

	protected Optional<D> returnOptionalRecord(List<R> recordList) {
		return GenericUtility.returnOptionalFromList(recordList, mapper::entityToDto);
	}

	protected boolean isNotLogicallyDeleted(R rec) {
		return Optional.ofNullable(rec.getDt_delete()).isPresent() &&
				DEFAULT_NOT_DELETED_DATE.compareTo(rec.getDt_delete()) == 0 ||
				Optional.ofNullable(rec.getUser_id_delete()).isEmpty();
	}
}
