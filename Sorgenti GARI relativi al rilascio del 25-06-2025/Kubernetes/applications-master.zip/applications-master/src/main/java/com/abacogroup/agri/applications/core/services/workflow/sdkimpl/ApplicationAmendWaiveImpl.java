package com.abacogroup.agri.applications.core.services.workflow.sdkimpl;

import com.abacogroup.agri.applications.core.exceptions.ObjectNotFoundException;
import com.abacogroup.agri.applications.core.exceptions.ObjectNotFoundRuntimeException;
import com.abacogroup.agri.applications.core.model.ProgressTypeEnum;
import com.abacogroup.agri.applications.core.model.dto.publics.ProgressApplicationDTO;
import com.abacogroup.agri.applications.core.services.ProgressService;
import com.abacogroup.agri.applications.core.services.crud.ApplicationDetailsCrudService;
import com.abacogroup.applicationworkflowsdk.model.exception.AmendException;
import com.abacogroup.applicationworkflowsdk.service.AmendApplication;
import com.abacogroup.applicationworkflowsdk.service.WaiveApplication;
import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.workflow.sdk.beans.ProcessData;

/**
 * @author Gennaro Tamburrelli
 */
public class ApplicationAmendWaiveImpl implements AmendApplication, WaiveApplication {

	private final ProgressService progressService;
	private final ApplicationDetailsCrudService applicationDetailsCrudService;

	public ApplicationAmendWaiveImpl(ProgressService progressService,
									 ApplicationDetailsCrudService applicationDetailsCrudService) {
		this.progressService = progressService;
		this.applicationDetailsCrudService = applicationDetailsCrudService;
	}

	@Override
	public void amendApplication(String tenant, Long applicationId, User user, String tagName, String scope, ProcessData currentProcessData)
			throws AmendException {
		try {
			progressService.progress(tenant, applicationId, tagName, user, scope, new ProgressApplicationDTO(), ProgressTypeEnum.SYNC,
					currentProcessData);
			if (progressService.lastTransitionHasError(tenant, applicationId, user)) {
				throw new AmendException("last transition log has error");
			}
		} catch (Exception e) {
			throw new AmendException(e.getMessage(), e);
		}

	}

	@Override
	public void cancelAmendedById(String tenant, Long originalApplicationId, User user) {
		try {
			applicationDetailsCrudService.cancelAmendedBy(tenant, originalApplicationId, user.getUserId());
		} catch (ObjectNotFoundException e) {
			throw new ObjectNotFoundRuntimeException(e.getMessage());
		}
	}

	@Override
	public void waiveApplication(String tenant, Long applicationId, User user, String tagName, String scope, ProcessData currentProcessData) throws AmendException {
		try {
			progressService.progress(tenant, applicationId, tagName, user, scope, new ProgressApplicationDTO(), ProgressTypeEnum.SYNC,
					currentProcessData);
			if (progressService.lastTransitionHasError(tenant, applicationId, user)) {
				throw new AmendException("last transition log has error");
			}
		} catch (Exception e) {
			throw new AmendException(e.getMessage(), e);
		}
	}

	@Override
	public void cancelWaivedById(String tenant, Long originalApplicationId, User user) {
		try {
			applicationDetailsCrudService.cancelAmendedBy(tenant, originalApplicationId, user.getUserId());
		} catch (ObjectNotFoundException e) {
			throw new ObjectNotFoundRuntimeException(e.getMessage());
		}
	}
}
