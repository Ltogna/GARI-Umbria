package com.abacogroup.agri.applications.db.ntt.compoundkeys;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author Mattia Perini
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class CalculationConfigProfileKey {

	private Long module_calculation_config_id;
	private String required_profile_code;
}
