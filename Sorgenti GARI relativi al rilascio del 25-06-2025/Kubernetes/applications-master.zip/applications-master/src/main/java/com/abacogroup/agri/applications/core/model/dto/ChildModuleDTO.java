package com.abacogroup.agri.applications.core.model.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

/**
 * @author Mattia Perini
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ChildModuleDTO {
	private Long pkid;
	private Long moduleId;
	private Long parentModuleId;
	private String userIdInsert;
	private String userIdDelete;
	private LocalDateTime dtInsert;
	private LocalDateTime dtDelete;
}
