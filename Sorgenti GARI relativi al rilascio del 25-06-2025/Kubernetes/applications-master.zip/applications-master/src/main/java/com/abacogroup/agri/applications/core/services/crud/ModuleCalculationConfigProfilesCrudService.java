package com.abacogroup.agri.applications.core.services.crud;

import com.abacogroup.agri.applications.core.exceptions.ObjectNotFoundException;
import com.abacogroup.agri.applications.core.mappers.ModuleCalculationConfigProfileMapper;
import com.abacogroup.agri.applications.core.model.dto.ModuleCalculationConfigProfileDTO;
import com.abacogroup.agri.applications.db.dao.ModuleCalculationConfigProfileDAO;
import com.abacogroup.agri.applications.db.ntt.ModuleCalculationConfigProfileNTT;
import com.abacogroup.agri.applications.db.ntt.compoundkeys.CalculationConfigProfileKey;
import lombok.extern.slf4j.Slf4j;

import java.util.List;
import java.util.Optional;

/**
 * @author Mattia Perini
 */
@Slf4j
public class ModuleCalculationConfigProfilesCrudService
		extends AbstractCrudService<ModuleCalculationConfigProfileNTT, CalculationConfigProfileKey, ModuleCalculationConfigProfileDTO, ModuleCalculationConfigProfileMapper, CalculationConfigProfileKey> {

	public ModuleCalculationConfigProfilesCrudService(ModuleCalculationConfigProfileDAO dao, ModuleCalculationConfigProfileMapper mapper) {
		super(dao, mapper);
	}

	@Override
	protected boolean hasPrimaryKey() {
		return false;
	}

	@Override
	protected CalculationConfigProfileKey retrievePrimaryKey(CalculationConfigProfileKey customKey) {
		return customKey;
	}

	@Override
	protected Optional<ModuleCalculationConfigProfileNTT> findRsByCustomKey(CalculationConfigProfileKey customKey) {
		return ((ModuleCalculationConfigProfileDAO) this.dao).findById(customKey)
				.stream()
				.findFirst();
	}

	@Override
	protected void deleteByCustomKey(CalculationConfigProfileKey customKey) {
		this.dao.deleteById(customKey);
	}

	@Override
	protected void setCustomSearchKey(ModuleCalculationConfigProfileNTT rs, CalculationConfigProfileKey customKey) {
		rs.setModule_calculation_config_id(customKey.getModule_calculation_config_id());
		rs.setRequired_profile_code(customKey.getRequired_profile_code());
	}

	public ModuleCalculationConfigProfileDTO insert(ModuleCalculationConfigProfileDTO in) {
		log.info("Invoking insert with params in: {}", in);
		return this.insert(in, CalculationConfigProfileKey.builder()
				.module_calculation_config_id(in.getModuleCalculationConfigId())
				.required_profile_code(in.getRequiredProfileCode())
				.build());
	}

	public ModuleCalculationConfigProfileDTO update(ModuleCalculationConfigProfileDTO in) {
		log.info("Invoking update with params in: {}", in);
		return this.update(null, in, CalculationConfigProfileKey.builder()
				.module_calculation_config_id(in.getModuleCalculationConfigId())
				.required_profile_code(in.getRequiredProfileCode())
				.build());
	}

	public void delete(CalculationConfigProfileKey key) {
		log.info("Invoking delete with params key: {}", key);
		this.delete(null, key);
	}

	public void deleteByModuleCalculationConfigId(Long moduleCalculationConfigId) {
		((ModuleCalculationConfigProfileDAO) this.dao).deleteByModuleCalculationConfigId(moduleCalculationConfigId);
	}

	public ModuleCalculationConfigProfileDTO findById(String tenant, CalculationConfigProfileKey id) throws ObjectNotFoundException {
		log.info("Invoking findById with params tenant: {} id: {}", tenant, id);
		return returnOptionalRecord(((ModuleCalculationConfigProfileDAO) this.dao).findById(tenant, id))
				.orElseThrow(OBJECT_NOT_FOUND_EXCEPTION_SUPPLIER);
	}

	public List<ModuleCalculationConfigProfileDTO> find(String tenant, Long formConfig) {
		log.info("Invoking findById with params tenant: {} formConfigId: {}", tenant, formConfig);
		return returnMappedList(((ModuleCalculationConfigProfileDAO) this.dao).find(tenant, formConfig));
	}

}
