package com.abacogroup.agri.applications.core.services;

import java.util.Collections;
import java.util.List;

import com.abacogroup.agri.applications.core.exceptions.ActionNotAuthorizedRuntimeException;
import com.abacogroup.agri.applications.core.exceptions.ApplicationNotFoundRuntimeException;
import com.abacogroup.agri.applications.core.exceptions.ObjectNotFoundException;
import com.abacogroup.agri.applications.core.services.crud.ApplicationsCrudService;
import com.abacogroup.agri.applications.core.services.workflow.ApplicationsWorkflowService;
import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.workflow.server.model.DetailedTransitionLog;

/**
 * @author Gennaro Tamburrelli
 */
public class HistoryService {

	private final ApplicationsCrudService applicationsCrudService;
	private final CheckPartyService checkPartyService;
	private final ApplicationsWorkflowService applicationsWorkflowService;

	public HistoryService(ApplicationsCrudService applicationsCrudService, CheckPartyService checkPartyService,
			ApplicationsWorkflowService applicationsWorkflowService) {
		this.applicationsCrudService = applicationsCrudService;
		this.checkPartyService = checkPartyService;
		this.applicationsWorkflowService = applicationsWorkflowService;
	}

	public List<DetailedTransitionLog> getApplicationHistoryByApplicationId(String tenant, Long applicationId, User user) {
		try {
			var application = applicationsCrudService.findByIdAlsoExpired(tenant, applicationId);
			try {
				this.checkPartyService.checkCanReadParty(tenant, application.getPartyId(), user);
			} catch (ActionNotAuthorizedRuntimeException e) {
				return Collections.emptyList();
			}
			return applicationsWorkflowService.getProcessTransitionHistory(tenant, application.getProcessId(), user);
		} catch (ObjectNotFoundException e) {
			throw new ApplicationNotFoundRuntimeException(e.getMessage());
		}
	}
}
