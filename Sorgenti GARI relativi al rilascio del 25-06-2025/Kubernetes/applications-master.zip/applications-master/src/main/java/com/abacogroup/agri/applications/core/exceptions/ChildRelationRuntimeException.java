package com.abacogroup.agri.applications.core.exceptions;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.ws.rs.core.Response;

public class ChildRelationRuntimeException extends AbstractException {

	public ChildRelationRuntimeException(String message) {
		super(Response.Status.INTERNAL_SERVER_ERROR, BODY, message);
	}

	private static final ChildRelationRuntimeException.ErrorBody BODY = new ChildRelationRuntimeException.ErrorBody();

	@Schema(name = "ChildRelationRuntimeExceptionErrorBody")
	public static class ErrorBody implements ExceptionErrorBody {
		private static final String ERR = "CHILD_RELATION_ERROR";

		@Override
		@Schema(allowableValues = ERR)
		public String getErrorCode() {
			return ERR;
		}
	}

}
