package com.abacogroup.agri.applications.resources;

import static com.abacogroup.agri.applications.core.services.ApplicationsService.DO_NOT_RETRIEVE_ALL_DETAILS;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import com.abacogroup.applicationworkflowsdk.model.DetailedSdkTransitionLog;
import org.apache.commons.collections4.CollectionUtils;
import org.slf4j.MDC;

import com.abacogroup.agri.applications.core.exceptions.ObjectNotFoundException;
import com.abacogroup.agri.applications.core.mappers.ApplicationDetailsPublicMapper;
import com.abacogroup.agri.applications.core.model.ProgressTypeEnum;
import com.abacogroup.agri.applications.core.model.WorkflowNodePublic;
import com.abacogroup.agri.applications.core.model.dto.ApplicationGeneratedCalculationDTO;
import com.abacogroup.agri.applications.core.model.dto.ApplicationProfileDTO;
import com.abacogroup.agri.applications.core.model.dto.CountDTO;
import com.abacogroup.agri.applications.core.model.dto.CreateAnomalyDTO;
import com.abacogroup.agri.applications.core.model.dto.ModuleWithDetailDTO;
import com.abacogroup.agri.applications.core.model.dto.PostProfilesDTO;
import com.abacogroup.agri.applications.core.model.dto.UpsertCalculationNotesDTO;
import com.abacogroup.agri.applications.core.model.dto.publics.*;
import com.abacogroup.agri.applications.core.services.ApplicationsService;
import com.abacogroup.agri.applications.core.services.CheckPartyService;
import com.abacogroup.agri.applications.core.services.FormConfigService;
import com.abacogroup.agri.applications.core.services.calculation.CalculationService;
import com.abacogroup.agri.applications.core.services.workflow.sdkimpl.AnomalyHandlerImpl;
import com.abacogroup.agri.applications.core.services.workflow.sdkimpl.ApplicationProfilesService;
import com.abacogroup.agri.applications.core.services.workflow.sdkimpl.CalculationUtilsImpl;
import com.abacogroup.agri.applications.core.services.workflow.sdkimpl.SetPresentationDateServiceImpl;
import com.abacogroup.applicationworkflowsdk.model.CreateProcessType;
import com.abacogroup.applicationworkflowsdk.model.GeneratedCalculationWithResultsDTO;
import com.abacogroup.applicationworkflowsdk.model.io.output.ApplicationCompileStatusDTO;
import com.abacogroup.applicationworkflowsdk.model.io.output.ApplicationCompileStatusPayloadDTO;
import com.abacogroup.applicationworkflowsdk.model.io.output.ApplicationDetailsPublicDTO;
import com.abacogroup.applicationworkflowsdk.model.io.output.ApplicationProfilePublicDTO;
import com.abacogroup.applicationworkflowsdk.model.io.output.FormWithGroupHierarchyPublicDTO;
import com.abacogroup.applicationworkflowsdk.model.io.output.ModuleProfileDTO;
import com.abacogroup.applicationworkflowsdk.model.io.output.ReadOnlyDto;
import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.jaxrsutils.filter.MDCPreFilter;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.workflow.server.model.Transition;
import com.codahale.metrics.annotation.Timed;

import io.dropwizard.auth.Auth;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.parameters.RequestBody;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import jakarta.annotation.security.PermitAll;
import jakarta.annotation.security.RolesAllowed;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.Context;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.core.SecurityContext;

@Timed
@Path("/{tenant}/public/v1/")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
@PermitAll
@RolesAllowed("APPLICATIONS|USER")
public class ApplicationsPublicResources {

	public static final String PROFILES_TAG = "Applications Profiles Public Resources";
	public static final String FORM_CONFIGS_TAG = "Form Configs Public Resources";
	public static final String COMPILE_STATUSES_TAG = "Compile Statuses Public Resources";
	public static final String ANOMALIES_TAG = "Anomalies Public Resources";
	public static final String WORKFLOWS_TAG = "Workflows Public Resources";
	public static final String APPLICATIONS_TAG = "Applications Public Resources";
	public static final String MODULES_PRIVATE_RESOURCES = "Modules Private Resources";
	public static final String APPLICATIONS_RESOURCES_SCOPE = "APPLICATIONS_RESOURCES_SCOPE";

	private final ApplicationsService applicationsService;
	private final ApplicationProfilesService applicationProfilesService;
	private final FormConfigService formConfigService;
	private final AnomalyHandlerImpl anomalyHandler;
	private final SetPresentationDateServiceImpl setPresentationDateService;
	private final CheckPartyService checkPartyService;
	private final CalculationService calculationService;
	private final CalculationUtilsImpl calculationUtils;

	public ApplicationsPublicResources(ApplicationsService applicationsService,
			ApplicationProfilesService applicationProfilesService, FormConfigService formConfigService,
			AnomalyHandlerImpl anomalyHandler,
			SetPresentationDateServiceImpl setPresentationDateService, CheckPartyService checkPartyService,
			CalculationService calculationService, CalculationUtilsImpl calculationUtils) {
		this.applicationsService = applicationsService;
		this.applicationProfilesService = applicationProfilesService;
		this.formConfigService = formConfigService;
		this.anomalyHandler = anomalyHandler;
		this.setPresentationDateService = setPresentationDateService;
		this.checkPartyService = checkPartyService;
		this.calculationService = calculationService;
		this.calculationUtils = calculationUtils;
	}

	@GET
	@Path("/applications/{application_id}/profiles")
	@Operation(description = "Returns the list of application's profiles, given the application's id", tags = { PROFILES_TAG })
	@ApiResponse(description = "The list of application's profiles")
	public InfiniteListResults<ApplicationProfilePublicDTO> getApplicationProfiles(
			@Parameter(description = "Current Tenant") @PathParam("tenant") String tenant,
			@Parameter(description = "The application id") @PathParam("application_id") Long applicationId,
			@Parameter(description = "The referred date") @QueryParam("dateTime") String dateTime,
			@QueryParam("nextKey") String nextKey,
			@Parameter(hidden = true) @Auth User user,
			@Context SecurityContext sc) {
		applicationsService.checkCanReadByAppId(tenant, applicationId, user);
		return applicationsService.getApplicationProfiles(tenant, applicationId, dateTime != null ? LocalDateTime.parse(dateTime) : null, nextKey, user);
	}

	@PUT
	@Path("/applications/{application_id}/profiles")
	@Operation(description = "Bulk updates the list of application's profiles, given the application's id", tags = { PROFILES_TAG })
	@ApiResponse(responseCode = "400", description = "At least one of the profile code list is not valid - ErrCode: PROFILE_CODE_NOT_EXISTS")
	public void putApplicationProfiles(
			@Parameter(description = "Current Tenant") @PathParam("tenant") String tenant,
			@Parameter(description = "The application id") @PathParam("application_id") Long applicationId,
			List<String> profileCodeList,
			@Parameter(hidden = true) @Auth User user,
			@Context SecurityContext sc) {
		applicationsService.checkCanReadByAppId(tenant, applicationId, user);
		applicationProfilesService.putApplicationProfiles(tenant, applicationId, profileCodeList, user);
	}

	@PATCH
	@Path("/applications/{application_id}/profiles")
	@Operation(description = "Upserts the list of application's profiles, given the application's id", tags = { PROFILES_TAG })
	@ApiResponse(responseCode = "400", description = "At least one of the profile code list is not valid - ErrCode: PROFILE_CODE_NOT_EXISTS")
	public void patchApplicationProfiles(
			@Parameter(description = "Current Tenant") @PathParam("tenant") String tenant,
			@Parameter(description = "The application id") @PathParam("application_id") Long applicationId,
			List<String> profileCodeList,
			@Parameter(hidden = true) @Auth User user,
			@Context SecurityContext sc) {
		applicationsService.checkCanReadByAppId(tenant, applicationId, user);
		applicationProfilesService.upsertApplicationProfiles(tenant, applicationId, profileCodeList, user);
	}

	@PUT
	@Path("/applications/{application_id}/profiles/patch")
	@Operation(description = "Upserts the list of application's profiles, given the application's id. Same API of PATCH", tags = { PROFILES_TAG })
	@ApiResponse(responseCode = "400", description = "At least one of the profile code list is not valid - ErrCode: PROFILE_CODE_NOT_EXISTS")
	public void patchViaPutApplicationProfiles(
			@Parameter(description = "Current Tenant") @PathParam("tenant") String tenant,
			@Parameter(description = "The application id") @PathParam("application_id") Long applicationId,
			List<String> profileCodeList,
			@Parameter(hidden = true) @Auth User user,
			@Context SecurityContext sc) {
		applicationsService.checkCanReadByAppId(tenant, applicationId, user);
		applicationProfilesService.upsertApplicationProfiles(tenant, applicationId, profileCodeList, user);
	}

	@POST
	@Path("/applications/{application_id}/profiles")
	@Operation(description = "Edit the list of application's profiles, given the posted data. It is guaranteed that seletion happens before addition", tags = {
			PROFILES_TAG })
	@ApiResponse(responseCode = "400", description = "At least one of the profile code list is not valid - ErrCode: PROFILE_CODE_NOT_EXISTS")
	public void postApplicationProfiles(
			@Parameter(description = "Current Tenant") @PathParam("tenant") String tenant,
			@Parameter(description = "The application id") @PathParam("application_id") Long applicationId,
			@NotNull @Valid PostProfilesDTO data,
			@Parameter(hidden = true) @Auth User user,
			@Context SecurityContext sc) {
		applicationsService.checkCanReadByAppId(tenant, applicationId, user);
		applicationProfilesService.deleteAndAddpplicationProfiles(tenant, applicationId, data.getToRemove(), data.getToAdd(), user);
	}

	@DELETE
	@Path("/applications/{application_id}/profiles/{profileCode}")
	@Operation(description = "Delete the profile code, given the application's id", tags = { PROFILES_TAG })
	public Response deleteProfileByApplicationId(
			@Parameter(description = "Current Tenant") @PathParam("tenant") String tenant,
			@Parameter(description = "The application id") @PathParam("application_id") Long applicationId,
			@Parameter(description = "The profile code") @PathParam("profileCode") String profileCode,
			@Parameter(hidden = true) @Auth User user,
			@Context SecurityContext sc) {
		applicationsService.checkCanReadByAppId(tenant, applicationId, user);
		applicationProfilesService.deleteApplicationProfile(tenant, applicationId, profileCode, user);
		return Response.ok().build();
	}

	@GET
	@Path("/applications/{application_id}/module/profiles")
	@Operation(description = "Returns the list of application's module profiles, given the application's id", tags = { PROFILES_TAG })
	@ApiResponse(description = "The list of moduòe's profiles")
	public List<ModuleProfileDTO> getModuleProfilesByApplicationId(
			@Parameter(description = "Current Tenant") @PathParam("tenant") String tenant,
			@Parameter(description = "The application id") @PathParam("application_id") Long applicationId,
			@Parameter(hidden = true) @Auth User user,
			@Context SecurityContext sc) {
		applicationsService.checkCanReadByAppId(tenant, applicationId, user);
		var application = applicationsService.getApplicationWithDetailsById(tenant, applicationId, user, sc);
		return applicationProfilesService.getModuleProfileByModuleId(tenant, application.getModuleId());
	}

	@GET
	@Path("/applications/{application_id}/form-configs/{config_id}/read-only")
	@Operation(description = "Returns the readonly status of form config, given the application id and the form config id", tags = {
			FORM_CONFIGS_TAG })
	@ApiResponse(description = "The readonly status. Returns true if form is in read only or application is closed")
	public ReadOnlyDto getFormConfigReadOnly(
			@Parameter(description = "Current Tenant") @PathParam("tenant") String tenant,
			@Parameter(description = "The application id") @PathParam("application_id") Long applicationId,
			@Parameter(description = "The form code") @PathParam("config_id") Long configId,
			@Parameter(hidden = true) @Auth User user,
			@Context SecurityContext sc) {
		applicationsService.checkCanReadByAppId(tenant, applicationId, user);
		return applicationsService.findReadOnly(tenant, applicationId, configId, user, sc);
	}

	@GET
	@Path("/applications/{application_id}/form-configs")
	@Operation(description = "Returns the the form configs", tags = {
			FORM_CONFIGS_TAG })
	@ApiResponse(description = "The form config list")
	public List<FormWithGroupHierarchyPublicDTO> getFormConfigList(
			@Parameter(description = "Current Tenant") @PathParam("tenant") String tenant,
			@Parameter(description = "The application id") @PathParam("application_id") Long applicationId,
			@Parameter(hidden = true) @Auth User user,
			@Context SecurityContext sc) {
		var res = applicationsService.getApplicationWithDetailsById(tenant, applicationId, user, sc, DO_NOT_RETRIEVE_ALL_DETAILS);

		List<String> requiredProfileCodes = res.getProfileList()
				.stream()
				.map(ApplicationProfileDTO::getProfileCode)
				.collect(Collectors.toList());
		return formConfigService
				.getFormsByModuleIdAndProcessStatus(tenant,
						res.getModuleId(),
						res.getProcessStatus(),
						res.getCompileStatus(),
						requiredProfileCodes.isEmpty() ? new ArrayList<>(List.of("")) : requiredProfileCodes,
						sc,
						MDC.get(MDCPreFilter.LOCALE));
	}

	@GET
	@Path("/applications/{application_id}/form-configs/process-statuses/{process_status}")
	@Operation(description = "Returns the the form configs", tags = {
			FORM_CONFIGS_TAG })
	@ApiResponse(description = "The form config list")
	public List<FormWithGroupHierarchyPublicDTO> getFormConfigListByProcessStatus(
			@Parameter(description = "Current Tenant") @PathParam("tenant") String tenant,
			@Parameter(description = "The application id") @PathParam("application_id") Long applicationId,
			@Parameter(description = "The process status") @PathParam("process_status") String processStatus,
			@Parameter(description = "The profile code") @QueryParam("profile_code") List<String> profileCodes,
			@Parameter(hidden = true) @Auth User user,
			@Context SecurityContext sc) {
		var res = applicationsService.getApplicationWithDetailsById(tenant, applicationId, user, sc, DO_NOT_RETRIEVE_ALL_DETAILS);

		List<String> requiredProfileCodes = !CollectionUtils.isEmpty(profileCodes)
				? profileCodes
				: res.getProfileList().stream().map(ApplicationProfileDTO::getProfileCode).collect(Collectors.toList());
		return formConfigService
				.getFormsByModuleIdAndProcessStatus(tenant,
						res.getModuleId(),
						processStatus,
						res.getCompileStatus(),
						requiredProfileCodes.isEmpty() ? new ArrayList<>(List.of("")) : requiredProfileCodes,
						sc,
						MDC.get(MDCPreFilter.LOCALE));
	}

	@GET
	@Path("/applications/{application_id}/compile-statuses")
	@Operation(description = "Returns the list of application compile statuses, given the application's id", tags = { COMPILE_STATUSES_TAG })
	@ApiResponse(description = "The list of application's compile statuses")
	public InfiniteListResults<ApplicationCompileStatusDTO> getApplicationCompileStatusById(
			@Parameter(description = "Current Tenant") @PathParam("tenant") String tenant,
			@Parameter(description = "The application id") @PathParam("application_id") Long applicationId,
			@QueryParam("nextKey") String nextKey,
			@Parameter(hidden = true) @Auth User user,
			@Context SecurityContext sc) {
		applicationsService.checkCanReadByAppId(tenant, applicationId, user);
		return applicationsService.findCompileStatus(tenant, applicationId, nextKey);
	}

	@PUT
	@Path("/applications/{application_id}/compile-statuses/{compileStatusIdentifier}")
	@Operation(description = "Updates the application compile status, given the application's id and compile status id. If compileStatusIdentifier does not exist, "
			+
			"it will be created", tags = { COMPILE_STATUSES_TAG })
	@ApiResponse(description = "The list of application's compile statuses")
	@ApiResponse(responseCode = "404", description = "Application not found - ErrCode: APPLICATION_NOT_FOUND_ERROR")
	@ApiResponse(responseCode = "404", description = "Application not found - ErrCode: COMPILE_STATUS_NOT_FOUND_ERROR")
	public ApplicationCompileStatusDTO updateApplicationCompileStatusById(@PathParam("tenant") String tenant,
			@PathParam("application_id") Long applicationId,
			@PathParam("compileStatusIdentifier") String compileStatusIdentifier,
			@RequestBody ApplicationCompileStatusPayloadDTO appCompileStatusDTO,
			@Parameter(hidden = true) @Auth User user) {
		applicationsService.checkCanReadByAppId(tenant, applicationId, user);
		return applicationsService.updateCompileStatus(tenant, applicationId, compileStatusIdentifier, appCompileStatusDTO,
				user.getUserId());
	}

	@DELETE
	@Path("/applications/{application_id}/compile-statuses/{compileStatusIdentifier}")
	@Operation(description = "Updates the application compile status, given the application's id and compile status id. If compileStatusIdentifier does not exist, "
			+
			"it will be created", tags = { COMPILE_STATUSES_TAG })
	@ApiResponse(description = "The list of application's compile statuses")
	@ApiResponse(responseCode = "404", description = "Application not found - ErrCode: APPLICATION_NOT_FOUND_ERROR")
	@ApiResponse(responseCode = "404", description = "Application not found - ErrCode: COMPILE_STATUS_NOT_FOUND_ERROR")
	public Response deleteApplicationCompileStatusById(@PathParam("tenant") String tenant,
			@PathParam("application_id") Long applicationId,
			@PathParam("compileStatusIdentifier") String compileStatusIdentifier,
			@Parameter(hidden = true) @Auth User user) throws ObjectNotFoundException {
		applicationsService.checkCanReadByAppId(tenant, applicationId, user);
		applicationsService.deleteCompileStatus(tenant, applicationId, compileStatusIdentifier, user.getUserId());
		return Response.ok().build();
	}

	@PATCH
	@Path("/applications/{application_id}/progress/transitions/{transition_id}")
	@Operation(description = "Updates the process status of the application", tags = { WORKFLOWS_TAG })
	@ApiResponse(description = "The process status of the task instance has been updated")
	@ApiResponse(responseCode = "404", description = "Application not found - ErrCode: APPLICATION_NOT_FOUND_ERROR")
	@ApiResponse(responseCode = "404", description = "Transition not found - ErrCode: TRANSITION_NOT_FOUND_ERROR")
	@ApiResponse(responseCode = "500", description = "Error progressing Application - errorCode: PROGRESS_WORKFLOW_ERROR")
	public Response patchProgressApplication(ProgressApplicationDTO payload,
			@Parameter(description = "Current Tenant") @PathParam("tenant") String tenant,
			@Parameter(description = "The application id") @PathParam("application_id") Long applicationId,
			@Parameter(description = "Id of the transition") @PathParam("transition_id") Integer transitionId,
			@Parameter(description = "The wanted scope") @QueryParam("scope") String scope,
			@Parameter(hidden = true) @Auth User user,
			@Context SecurityContext sc) throws Exception {
		applicationsService.checkCanReadByAppId(tenant, applicationId, user);
		applicationsService.progress(tenant, applicationId, transitionId, user, Optional.ofNullable(scope).orElse(APPLICATIONS_RESOURCES_SCOPE), payload,
				ProgressTypeEnum.ASYNC);
		return Response.ok().build();
	}

	@PUT
	@Path("/applications/{application_id}/progress/transitions/{transition_id}")
	@Operation(description = "Updates the process status of the application. Same API of PATCH", tags = { WORKFLOWS_TAG })
	@ApiResponse(description = "The process status of the task instance has been updated")
	@ApiResponse(responseCode = "404", description = "Application not found - ErrCode: APPLICATION_NOT_FOUND_ERROR")
	@ApiResponse(responseCode = "404", description = "Transition not found - ErrCode: TRANSITION_NOT_FOUND_ERROR")
	@ApiResponse(responseCode = "500", description = "Error progressing Application - errorCode: PROGRESS_WORKFLOW_ERROR")
	public Response putProgressApplication(ProgressApplicationDTO payload,
			@Parameter(description = "Current Tenant") @PathParam("tenant") String tenant,
			@Parameter(description = "The application id") @PathParam("application_id") Long applicationId,
			@Parameter(description = "Id of the transition") @PathParam("transition_id") Integer transitionId,
			@Parameter(description = "The wanted scope") @QueryParam("scope") String scope,
			@Parameter(hidden = true) @Auth User user,
			@Context SecurityContext sc) throws Exception {
		applicationsService.checkCanReadByAppId(tenant, applicationId, user);
		applicationsService.progress(tenant, applicationId, transitionId, user, Optional.ofNullable(scope).orElse(APPLICATIONS_RESOURCES_SCOPE), payload,
				ProgressTypeEnum.ASYNC);
		return Response.ok().build();
	}

	@PATCH
	@Path("/applications/{application_id}/progress/tags/{tag_name}")
	@Operation(description = "Updates the process status of the application", tags = { WORKFLOWS_TAG })
	@ApiResponse(description = "The process status of the task instance has been updated")
	@ApiResponse(responseCode = "404", description = "Application not found - ErrCode: APPLICATION_NOT_FOUND_ERROR")
	@ApiResponse(responseCode = "404", description = "Transition not found - ErrCode: TRANSITION_NOT_FOUND_ERROR")
	@ApiResponse(responseCode = "500", description = "Error progressing Application - errorCode: PROGRESS_WORKFLOW_ERROR")
	public Response patchProgressApplication(ProgressApplicationDTO payload,
			@Parameter(description = "Current Tenant") @PathParam("tenant") String tenant,
			@Parameter(description = "The application id") @PathParam("application_id") Long applicationId,
			@Parameter(description = "Tag name") @PathParam("tag_name") String tagName,
			@Parameter(description = "The wanted scope") @QueryParam("scope") String scope,
			@Parameter(hidden = true) @Auth User user,
			@Context SecurityContext sc) throws ObjectNotFoundException {
		applicationsService.checkCanReadByAppId(tenant, applicationId, user);
		applicationsService.progress(tenant, applicationId, tagName, user, Optional.ofNullable(scope).orElse(APPLICATIONS_RESOURCES_SCOPE), payload,
				ProgressTypeEnum.ASYNC);
		return Response.ok().build();
	}

	@PUT
	@Path("/applications/{application_id}/progress/tags/{tag_name}")
	@Operation(description = "Updates the process status of the application. Same API of PATCH", tags = { WORKFLOWS_TAG })
	@ApiResponse(description = "The process status of the task instance has been updated")
	@ApiResponse(responseCode = "404", description = "Application not found - ErrCode: APPLICATION_NOT_FOUND_ERROR")
	@ApiResponse(responseCode = "404", description = "Transition not found - ErrCode: TRANSITION_NOT_FOUND_ERROR")
	@ApiResponse(responseCode = "500", description = "Error progressing Application - errorCode: PROGRESS_WORKFLOW_ERROR")
	public Response putProgressApplication(ProgressApplicationDTO payload,
			@Parameter(description = "Current Tenant") @PathParam("tenant") String tenant,
			@Parameter(description = "The application id") @PathParam("application_id") Long applicationId,
			@Parameter(description = "Tag name") @PathParam("tag_name") String tagName,
			@Parameter(description = "The wanted scope") @QueryParam("scope") String scope,
			@Parameter(hidden = true) @Auth User user,
			@Context SecurityContext sc) throws ObjectNotFoundException {
		applicationsService.checkCanReadByAppId(tenant, applicationId, user);
		applicationsService.progress(tenant, applicationId, tagName, user, Optional.ofNullable(scope).orElse(APPLICATIONS_RESOURCES_SCOPE), payload,
				ProgressTypeEnum.ASYNC);
		return Response.ok().build();
	}

	@GET
	@Path("/applications/{application_id}/anomalies")
	@Operation(description = "Returns the list of application's anomalies", tags = { ANOMALIES_TAG })
	@ApiResponse(description = "The list of application's compile statuses")
	public List<AnomalyDTO> getApplicationCompileStatusById(
			@Parameter(description = "Current Tenant") @PathParam("tenant") String tenant,
			@Parameter(description = "The application id") @PathParam("application_id") Long applicationId,
			@Parameter(hidden = true) @Auth User user) {
		applicationsService.checkCanReadByAppId(tenant, applicationId, user);
		return anomalyHandler.getAnomaliesForApp(tenant, applicationId);
	}

	@POST
	@Path("/applications/{application_id}/anomalies")
	@Operation(description = "Create an anomaly", tags = { ANOMALIES_TAG })
	@ApiResponse(responseCode = "204", description = "Anomaly was created")
	public Response createAnomaly(
			@Parameter(description = "Current Tenant") @PathParam("tenant") String tenant,
			@Parameter(description = "The application id") @PathParam("application_id") Long applicationId,
			@RequestBody CreateAnomalyDTO payload,
			@Parameter(hidden = true) @Auth User user) {
		applicationsService.checkCanReadByAppId(tenant, applicationId, user);
		anomalyHandler.insertAnomaly(tenant, applicationId, payload.getCode(), user.getUserId());
		return Response.noContent().build();
	}

	@DELETE
	@Path("/applications/{application_id}/anomalies/{anomaly_code}")
	@Operation(description = "Create an anomaly", tags = { ANOMALIES_TAG })
	@ApiResponse(description = "The anomaly was deleted")
	public Response createAnomaly(
			@Parameter(description = "Current Tenant") @PathParam("tenant") String tenant,
			@Parameter(description = "The application id") @PathParam("application_id") Long applicationId,
			@Parameter(description = "The anomaly code") @PathParam("anomaly_code") String anomalyCode,
			@Parameter(hidden = true) @Auth User user) {
		applicationsService.checkCanReadByAppId(tenant, applicationId, user);
		anomalyHandler.deleteAnomaly(tenant, applicationId, anomalyCode, user.getUserId());
		return Response.noContent().build();
	}

	@GET
	@Path("/applications/{application_id}/details")
	@Operation(description = "Returns the detail of the application", tags = { APPLICATIONS_TAG })
	@ApiResponse(description = "The detail of the application")
	@ApiResponse(responseCode = "404", description = "No application found - ErrCode: APPLICATION_NOT_FOUND_ERROR")
	@ApiResponse(responseCode = "500", description = "Workflow generic error - ErrCode: WORKFLOW_GENERIC_ERROR")
	public ApplicationDetailsPublicDTO getApplicationDetail(@Parameter(description = "Current Tenant") @PathParam("tenant") String tenant,
			@Parameter(description = "The application id") @PathParam("application_id") Long applicationId,
			@Parameter(hidden = true) @Auth User user,
			@Context SecurityContext sc) {
		applicationsService.checkCanReadByAppId(tenant, applicationId, user);
		var res = applicationsService.getApplicationWithDetailsById(tenant, applicationId, user, sc);
		res.setIsClosed(applicationsService.isApplicationClosed(tenant, res));
		return ApplicationDetailsPublicMapper.INSTANCE.entityToDto(res);
	}

	@POST
	@Path("/applications/{application_id}/presentation-date")
	@Operation(description = "Set the presentation date, if is the first the first time", tags = { APPLICATIONS_TAG })
	@ApiResponse(description = "The detail of the application")
	@ApiResponse(responseCode = "404", description = "No application found - ErrCode: APPLICATION_NOT_FOUND_ERROR")
	public Response setPresentationDate(@Parameter(description = "Current Tenant") @PathParam("tenant") String tenant,
			@Parameter(description = "The application id") @PathParam("application_id") Long applicationId,
			@Parameter(hidden = true) @Auth User user,
			@Context SecurityContext sc) {
		applicationsService.checkCanReadByAppId(tenant, applicationId, user);
		setPresentationDateService.conditionallySetPresentationDate(tenant, applicationId, user.getUserId());
		return Response.ok().build();
	}

	@GET
	@Path("/applications/parties/{partyId}/years/{year}/modules/{moduleCode}")
	@Operation(description = "Returns the list of applications, given the party id and the year", tags = { APPLICATIONS_TAG })
	@ApiResponse(description = "The list of applications")
	@ApiResponse(responseCode = "404", description = "No applications found for party or year - ErrCode: NO_APPLICATIONS_FOUND_BY_PARTY_AND_YEAR")
	public List<AppByPartyAndYearDTO> getApplicationsByPartyAndYear(
			@Parameter(description = "Current Tenant") @PathParam("tenant") String tenant,
			@Parameter(description = "The specific party id") @PathParam("partyId") Long partyId,
			@Parameter(description = "The specific year") @PathParam("year") Integer year,
			@PathParam("moduleCode") String moduleCode,
			@Parameter(hidden = true) @Auth User user,
			@Context SecurityContext sc) {
		applicationsService.checkCanRead(tenant, partyId, user);
		return applicationsService.getApplicationsByPartyYearAndModuleCode(tenant, partyId, year, moduleCode, user);
	}

	@GET
	@Path("/sectors/{sector_code}/modules")
	@Operation(description = "Returns the list of modules, given the date", tags = { MODULES_PRIVATE_RESOURCES })
	@ApiResponse(description = "The list of modules")
	@ApiResponse(responseCode = "404", description = "No sectors found for this sector code - ErrCode: OBJECT_NOT_FOUND_ERROR")
	public List<ModuleWithDetailDTO> getModulesByPointInTime(@Parameter(description = "Current Tenant") @PathParam("tenant") String tenant,
			@Parameter(description = "The sector code to be used in search") @PathParam("sector_code") String sectorCode,
			@Parameter(hidden = true) @Auth User user,
			@Context SecurityContext sc) {
		return applicationsService.getModulesBySectorCode(tenant, sectorCode, sc);
	}

	@GET
	@Path("/sectors")
	@Operation(description = "Returns the list of sectors, given the date", tags = { MODULES_PRIVATE_RESOURCES })
	@ApiResponse(description = "The list of sectors")
	@ApiResponse(responseCode = "404", description = "No profiles with sector and module code, at date - " +
			"ErrCode: NO_PROFILES_FOUND_WITH_SECTOR_AND_MODULE_AT_DATE")
	public InfiniteListResults<SectorPublicDTO> getSectorsByTenant(
			@Parameter(description = "Current Tenant") @PathParam("tenant") String tenant,
			@Parameter(description = "Next key for infinite list") @QueryParam("nextKey") String nextKey,
			@Parameter(hidden = true) @Auth User user,
			@Context SecurityContext sc) {
		return applicationsService.getSectorsByTenant(tenant, nextKey);
	}

	@GET
	@Path("/modules/{module_code}/statuses")
	@Operation(description = "Returns the list of module's statuses")
	@ApiResponse(description = "The list of module's statuses")
	@ApiResponse(responseCode = "404", description = "No Module was found")
	public List<WorkflowNodePublic> getModuleStatuses(@Parameter(description = "Current Tenant") @PathParam("tenant") String tenant,
			@Parameter(description = "The module code") @PathParam("module_code") String moduleCode,
			@Parameter(hidden = true) @Auth User user,
			@Context SecurityContext sc) {
		return applicationsService.getStatusNodes(tenant, moduleCode);
	}

	@GET
	@Path("/applications/modules/{module_code}")
	@Operation(description = "Returns the list of applications, given the module code", tags = { APPLICATIONS_TAG })
	@ApiResponse(description = "The list of applications")
	@ApiResponse(responseCode = "404", description = "No applications found for module code - ErrCode: NO_APPLICATIONS_FOUND_BY_MODULE_CODE")
	public InfiniteListResults<AppByPartyAndYearDTO> getModuleFormConfigsByModuleCode(
			@Parameter(description = "Current Tenant") @PathParam("tenant") String tenant,
			@Parameter(description = "The specific module code") @PathParam("module_code") String moduleCode,
			@Parameter(description = "The optional party code") @QueryParam("party_code") String partyCode,
			@Parameter(description = "The optional year") @QueryParam("year") List<Integer> yearList,
			@Parameter(description = "The optional process status") @QueryParam("process_status") String processStatus,
			@Parameter(description = "The optional application ids") @QueryParam("application_id") List<Long> applicationIdList,
			@Parameter(description = "if value is 1, only partial info will be returned") @QueryParam("light_response") @DefaultValue("0") Integer flLigthResponse,
			@Parameter(description = "Next key for infinite list") @QueryParam("nextKey") String nextKey,
			@Parameter(description = "The optional page size") @QueryParam("pageSize") Integer pageSize,
			@Parameter(hidden = true) @Auth User user,
			@Context SecurityContext sc) throws ObjectNotFoundException {
		checkPartyService.canReadAllParties(tenant, user);
		return applicationsService.getApplicationsByModuleCode(tenant, moduleCode, partyCode, yearList, processStatus,
				applicationIdList, nextKey, user, sc, flLigthResponse, pageSize);
	}

	@GET
	@Path("/applications/modules/{module_code}/application-ids")
	@Operation(description = "Returns the list of application's ids, given the module code", tags = { APPLICATIONS_TAG })
	@ApiResponse(description = "The list of application's ids")
	@ApiResponse(responseCode = "404", description = "No application's ids found for module code - ErrCode: NO_APPLICATIONS_FOUND_BY_MODULE_CODE")
	public InfiniteListResults<Long> getApplicationIdsByModuleCode(
			@Parameter(description = "Current Tenant") @PathParam("tenant") String tenant,
			@Parameter(description = "The specific module code") @PathParam("module_code") String moduleCode,
			@Parameter(description = "Next key for infinite list") @QueryParam("nextKey") String nextKey,
			@Parameter(description = "The optional page size") @QueryParam("pageSize") Integer pageSize,
			@Parameter(hidden = true) @Auth User user) throws ObjectNotFoundException {
		checkPartyService.canReadAllParties(tenant, user);
		return applicationsService.getApplicationIdsByModuleCode(tenant, moduleCode, nextKey, pageSize);
	}

	@GET
	@Path("/applications/partyCode/{partyCode}")
	@Operation(description = "Returns the list of applications, given the code", tags = { APPLICATIONS_TAG })
	@ApiResponse(description = "The list of applications")
	@ApiResponse(responseCode = "404", description = "No applications found for code - ErrCode: NO_APPLICATIONS_FOUND_BY_CODE")
	public InfiniteListResults<AppByPartyAndYearDTO> getApplicationsByCode(
			@Parameter(description = "Current Tenant") @PathParam("tenant") String tenant,
			@Parameter(description = "The specific party code") @PathParam("partyCode") String partyCode,
			@Parameter(description = "The optional module code") @QueryParam("module_code") String moduleCode,
			@Parameter(description = "The optional year") @QueryParam("year") List<Integer> yearList,
			@Parameter(description = "The optional process status") @QueryParam("process_status") String processStatus,
			@Parameter(description = "Next key for infinite list") @QueryParam("nextKey") String nextKey,
			@Parameter(hidden = true) @Auth User user,
			@Context SecurityContext sc) {
		return applicationsService.getApplicationsByPartyCode(tenant, partyCode, moduleCode, yearList, processStatus, nextKey, user);
	}

	@GET
	@Path("/applications/partyCode/{partyCode}/count")
	@Operation(description = "Returns the list of applications, given the code", tags = { APPLICATIONS_TAG })
	@ApiResponse(description = "The list of applications")
	@ApiResponse(responseCode = "404", description = "No applications found for code - ErrCode: NO_APPLICATIONS_FOUND_BY_CODE")
	public CountDTO countGetApplicationsByCode(
			@Parameter(description = "Current Tenant") @PathParam("tenant") String tenant,
			@Parameter(description = "The specific party code") @PathParam("partyCode") String partyCode,
			@Parameter(description = "The optional module code") @QueryParam("module_code") String moduleCode,
			@Parameter(description = "The optional year") @QueryParam("year") List<Integer> yearList,
			@Parameter(description = "The optional process status") @QueryParam("process_status") String processStatus,
			@Parameter(description = "The optional application ids") @QueryParam("application_id") List<Long> applicationIdList,
			@Parameter(hidden = true) @Auth User user,
			@Context SecurityContext sc) {
		return CountDTO.builder()
				.count(applicationsService.countGetApplicationsByPartyCode(tenant, partyCode, moduleCode, yearList, applicationIdList,
						processStatus, user))
				.build();
	}

	@GET
	@Path("/applications/{application_id}")
	@Operation(description = "Returns the detail of the application", tags = { APPLICATIONS_TAG })
	@ApiResponse(description = "The detail of the application")
	@ApiResponse(responseCode = "404", description = "No application found - ErrCode: APPLICATION_NOT_FOUND_ERROR")
	@ApiResponse(responseCode = "500", description = "Workflow generic error - ErrCode: WORKFLOW_GENERIC_ERROR")
	public ApplicationWithDetailsDTO getDetailedApplication(@Parameter(description = "Current Tenant") @PathParam("tenant") String tenant,
			@Parameter(description = "The application id") @PathParam("application_id") Long applicationId,
			@Parameter(hidden = true) @Auth User user,
			@Context SecurityContext sc) {
		return applicationsService.getDetailedApplicationById(tenant, applicationId, user, sc);
	}

	@GET
	@Path("/child-applications/{child_application_id}")
	@Operation(description = "Returns the detail of the application", tags = { APPLICATIONS_TAG })
	@ApiResponse(description = "The detail of the application")
	@ApiResponse(responseCode = "404", description = "No application found - ErrCode: APPLICATION_NOT_FOUND_ERROR")
	@ApiResponse(responseCode = "500", description = "Workflow generic error - ErrCode: WORKFLOW_GENERIC_ERROR")
	public ApplicationWithDetailsDTO getDetailedApplicationByChildApplicationId(@Parameter(description = "Current Tenant") @PathParam("tenant") String tenant,
			@Parameter(description = "The application id") @PathParam("child_application_id") Long childApplicationId,
			@Parameter(hidden = true) @Auth User user,
			@Context SecurityContext sc) {
		return applicationsService.getDetailedApplicationByChildApplicationId(tenant, childApplicationId, user, sc);
	}

	@GET
	@Path("/parent-applications/{parent_application_id}/modules/{module_code}")
	@Operation(description = "Returns the detail of the application", tags = { APPLICATIONS_TAG })
	@ApiResponse(description = "The detail of the application")
	@ApiResponse(responseCode = "404", description = "No application found - ErrCode: APPLICATION_NOT_FOUND_ERROR")
	@ApiResponse(responseCode = "500", description = "Workflow generic error - ErrCode: WORKFLOW_GENERIC_ERROR")
	public Response getDetailedApplicationByParentApplicationId(@Parameter(description = "Current Tenant") @PathParam("tenant") String tenant,
			@Parameter(description = "The application id") @PathParam("parent_application_id") Long parentApplicationId,
			@Parameter(description = "The specific module code") @PathParam("module_code") String moduleCode,
			@Parameter(hidden = true) @Auth User user,
			@Context SecurityContext sc) {
		return Response.status(Response.Status.OK).entity(applicationsService.getDetailedApplicationByParentApplicationId(tenant, parentApplicationId, moduleCode, user, sc)).build();
	}

	@GET
	@Path("/modules/{module_code}")
	@Operation(description = "Returns the configurations related to the module code", tags = { APPLICATIONS_TAG })
	@ApiResponse(description = "The module configurations")
	@ApiResponse(responseCode = "404", description = "Module not found by code - ErrCode: OBJECT_NOT_FOUND_ERROR")
	public ModuleWithParamsPublicDTO getModuleFormConfigsByModuleCode(
			@Parameter(description = "Current Tenant") @PathParam("tenant") String tenant,
			@Parameter(description = "The specific module code") @PathParam("module_code") String moduleCode,
			@Parameter(hidden = true) @Auth User user,
			@Context SecurityContext sc) {
		return applicationsService.getModuleFormConfigsByModuleCode(tenant, moduleCode);
	}

	@Deprecated
	@GET
	@Path("/applications/{application_id}/history")
	@Operation(description = "Returns the application's history, given the application id", tags = { APPLICATIONS_TAG })
	@ApiResponse(description = "The application's history")
	@ApiResponse(responseCode = "404", description = "Application does not exists - ErrCode: APPLICATION_NOT_FOUND_ERROR")
	public List<DetailedSdkTransitionLog> getHistoryByApplicationCode(@Parameter(description = "Current Tenant") @PathParam("tenant") String tenant,
																	  @Parameter(description = "The application id") @PathParam("application_id") Long applicationId,
																	  @Parameter(hidden = true) @Auth User user,
																	  @Context SecurityContext sc) {
		return applicationsService.getApplicationHistoryByApplicationId(tenant, applicationId, user, sc, false);
	}

	@GET
	@Path("/applications/{application_id}/movement-history")
	@Operation(description = "Returns the application's history, given the application id", tags = { APPLICATIONS_TAG })
	@ApiResponse(description = "The application's history")
	@ApiResponse(responseCode = "404", description = "Application does not exists - ErrCode: APPLICATION_NOT_FOUND_ERROR")
	public List<DetailedSdkTransitionLog> getMovementHistoryByApplicationCode(@Parameter(description = "Current Tenant") @PathParam("tenant") String tenant,
																	  @Parameter(description = "The application id") @PathParam("application_id") Long applicationId,
																	  @Parameter(hidden = true) @Auth User user,
																	  @Context SecurityContext sc) {
		return applicationsService.getApplicationHistoryByApplicationId(tenant, applicationId, user, sc, true);
	}

	@GET
	@Path("/applications/{application_id}/calculations/{calculation_job_uuid}/render")
	@Operation(description = "Returns the generated calculation ", tags = { APPLICATIONS_TAG })
	@ApiResponse(description = "The calculation content")
	public ApplicationCalculationRenderPublicDTO getCalculationRender(@Parameter(description = "Current Tenant") @PathParam("tenant") String tenant,
			@Parameter(description = "The application id") @PathParam("application_id") Long applicationId,
			@Parameter(description = "The calculation job uuid") @PathParam("calculation_job_uuid") String calculationJobUuid,
			@Parameter(hidden = true) @Auth User user,
			@Context SecurityContext sc) {
		applicationsService.checkCanReadByAppId(tenant, applicationId, user);
		return calculationService.getCalculationRenderByJobUuidReadyStatus(tenant, applicationId, user, calculationJobUuid);
	}

	@GET
	@Path("/applications/{application_id}/calculations/{calculation_job_uuid}/raw")
	@Operation(description = "Returns the generated calculation ", tags = { APPLICATIONS_TAG })
	@ApiResponse(description = "The calculation content")
	public ApplicationCalculationRawPublicDTO getCalculation(@Parameter(description = "Current Tenant") @PathParam("tenant") String tenant,
			@Parameter(description = "The application id") @PathParam("application_id") Long applicationId,
			@Parameter(description = "The calculation job uuid") @PathParam("calculation_job_uuid") String calculationJobUuid,
			@Parameter(hidden = true) @Auth User user,
			@Context SecurityContext sc) {
		applicationsService.checkCanReadByAppId(tenant, applicationId, user);
		return calculationService.getCalculationRawByJobUuidReadyStatus(tenant, applicationId, user, calculationJobUuid);
	}

	@GET
	@Path("/applications/{application_id}/calculation-codes/{calculation_code}/last-calculation")
	@Operation(description = "Returns the generated calculation ", tags = { APPLICATIONS_TAG })
	@ApiResponse(description = "The calculation content")
	public Map<String, Object> getLastCalculation(@Parameter(description = "Current Tenant") @PathParam("tenant") String tenant,
			@Parameter(description = "The application id") @PathParam("application_id") Long applicationId,
			@Parameter(description = "The calculation code") @PathParam("calculation_code") String calculationCode,
			@Parameter(hidden = true) @Auth User user,
			@Context SecurityContext sc) {
		applicationsService.checkCanReadByAppId(tenant, applicationId, user);
		Optional<GeneratedCalculationWithResultsDTO<Map>> res = calculationUtils.retrieveLastCalculation(tenant, applicationId, calculationCode, user,
				Map.class);

		if (res.isPresent()) {
			Map<String, Object> rawResult = res.get().getRawResult();
			rawResult.put("calculationJobUuid", res.get().getCalculationData().getCalculationJobUuid());
			return rawResult;
		}

		return Map.of();
	}

	@GET
	@Path("/applications/{application_id}/calculation-history")
	@Operation(description = "Returns the application's calculations, given the application id", tags = { APPLICATIONS_TAG })
	@ApiResponse(description = "The application's generated calculations")
	@ApiResponse(responseCode = "404", description = "Application does not exists - ErrCode: APPLICATION_NOT_FOUND_ERROR")
	public List<ApplicationGeneratedCalculationDTO> getCalculationsByApplicationCode(
			@Parameter(description = "Current Tenant") @PathParam("tenant") String tenant,
			@Parameter(description = "The application id") @PathParam("application_id") Long applicationId,
			@Parameter(hidden = true) @Auth User user,
			@Context SecurityContext sc) {
		return calculationService.getApplicationCalculationsByApplicationId(tenant, applicationId, user, sc);
	}

	@PUT
	@Path("/applications/{application_id}/calculations/{calculation_job_uuid}/notes")
	@Operation(description = "Returns the application's calculations, given the application id", tags = { APPLICATIONS_TAG })
	@ApiResponse(description = "The application's generated calculations")
	@ApiResponse(responseCode = "404", description = "Application does not exists - ErrCode: APPLICATION_NOT_FOUND_ERROR")
	public void updateNotes(
			@Parameter(description = "Current Tenant") @PathParam("tenant") String tenant,
			@Parameter(description = "The application id") @PathParam("application_id") Long applicationId,
			@Parameter(description = "The calculation job uuid") @PathParam("calculation_job_uuid") String calculationJobUuid,
			@RequestBody UpsertCalculationNotesDTO notes,
			@Parameter(hidden = true) @Auth User user,
			@Context SecurityContext sc) throws ObjectNotFoundException {
		calculationService.updateNotes(tenant, applicationId, calculationJobUuid, notes.getNotes(), user);
	}

	@GET
	@Path("/applications/{application_id}/is-in-transition")
	@Operation(description = "Returns the application' in transition flag", tags = { APPLICATIONS_TAG })
	@ApiResponse(description = "The current flag")
	@ApiResponse(responseCode = "404", description = "Application does not exists - ErrCode: APPLICATION_NOT_FOUND_ERROR")
	public ApplicationInTransitionDTO getApplicationTransitionFlag(@Parameter(description = "Current Tenant") @PathParam("tenant") String tenant,
			@Parameter(description = "The application id") @PathParam("application_id") Long applicationId,
			@Parameter(hidden = true) @Auth User user,
			@Context SecurityContext sc) {
		return applicationsService.getApplicationInTransition(tenant, applicationId, user);
	}

	@GET
	@Path("/applications/{application_id}/on-going-calculations")
	@Operation(description = "Returns the application's calculations job status list, given the application id", tags = { APPLICATIONS_TAG })
	@ApiResponse(description = "The application's generated prints")
	@ApiResponse(responseCode = "404", description = "Application does not exists - ErrCode: APPLICATION_NOT_FOUND_ERROR")
	public List<ApplicationGeneratedCalculationDTO> getOngoingCalculations(@Parameter(description = "Current Tenant") @PathParam("tenant") String tenant,
			@Parameter(description = "The application id") @PathParam("application_id") Long applicationId,
			@Parameter(hidden = true) @Auth User user,
			@Context SecurityContext sc) {
		var res = applicationsService.getApplicationWithDetailsById(tenant, applicationId, user, sc);
		List<String> requiredProfileCodes = res.getProfileList()
				.stream()
				.map(ApplicationProfileDTO::getProfileCode)
				.collect(Collectors.toList());
		List<CalculationDetailsOutDTO> modulesCalculation = applicationsService
				.getCalculationsByModuleIdAndProcessStatus(tenant,
						applicationId,
						res.getModuleId(),
						res.getProcessStatus(),
						requiredProfileCodes.isEmpty() ? new ArrayList<>(List.of("")) : requiredProfileCodes,
						sc);
		return applicationsService
				.checkForOngoingCalculations(tenant, applicationId,
						modulesCalculation.stream().map(CalculationDetailsOutDTO::getCalculationCode).collect(Collectors.toList()));
	}

	@GET
	@Path("/modules/{module_code}/option-codes")
	@Operation(description = "Returns the list of active option codes in a module", tags = { APPLICATIONS_TAG })
	@ApiResponse(description = "The active option codes in a module")
	public List<String> getOptionCodesByTenantAndModule(@Parameter(description = "Current Tenant") @PathParam("tenant") String tenant,
			@Parameter(description = "The module code") @PathParam("module_code") String moduleCode,
			@Parameter(hidden = true) @Auth User user,
			@Context SecurityContext sc) {
		return applicationsService.getOptionCodesByTenantAndModule(tenant, moduleCode);
	}

	@GET
	@Path("/parties/{partyId}/years/{year}")
	@Operation(description = "Returns the list of applications, given the party id and the year", tags = { APPLICATIONS_TAG })
	@ApiResponse(description = "The list of applications")
	@ApiResponse(responseCode = "404", description = "No applications found for party or year - ErrCode: NO_APPLICATIONS_FOUND_BY_PARTY_AND_YEAR")
	public InfiniteListResults<AppByPartyAndYearDTO> getApplicationsInfiniteListByPartyAndYear(
			@Parameter(description = "Current Tenant") @PathParam("tenant") String tenant,
			@Parameter(description = "The specific party id") @PathParam("partyId") Long partyId,
			@Parameter(description = "The specific year") @PathParam("year") Integer year,
			@Parameter(description = "Next key for infinite list") @QueryParam("nextKey") String nextKey,
			@Parameter(hidden = true) @Auth User user,
			@Context SecurityContext sc) {
		return applicationsService.getApplicationsByPartyAndYear(tenant, partyId, year, nextKey, user, sc);
	}

	@GET
	@Path("/applications/parties/{partyId}")
	@Operation(description = "Returns the list of applications by partyId", tags = { APPLICATIONS_TAG })
	@ApiResponse(description = "The list of applications")
	@ApiResponse(responseCode = "400", description = "If partyId is not specified as query parameter")
	@ApiResponse(responseCode = "404", description = "No applications found - ErrCode: NO_APPLICATION_SUMMARY_FOUND")
	public List<ApplicationDetailsPublicDTO> getApplicationsByPartyId(
			@Parameter(description = "Current Tenant") @PathParam("tenant") String tenant,
			@Parameter(description = "the Party Id") @PathParam("partyId") Long partyId,
			@Parameter(description = "Filter by module code") @QueryParam("module_code") String moduleCode,
			@Parameter(description = "Filter by process status") @QueryParam("process_status") String processStatus,
			@Parameter(hidden = true) @Auth User user,
			@Context SecurityContext sc) {
		return applicationsService.getApplicationsByPartyId(tenant, partyId, user, moduleCode, processStatus, sc);
	}

	@POST
	@Path("/applications")
	@Operation(description = "Creates a new application", tags = { APPLICATIONS_TAG })
	@ApiResponse(description = "The application code created and the anomalies found")
	@ApiResponse(responseCode = "409", description = "At least one severe anomaly occurred")
	public CreateApplicationOutDTO createApplicationAsync(
			@Parameter(description = "Current Tenant") @PathParam("tenant") String tenant,
			@Parameter(hidden = true) @Auth User user,
			@Valid CreateApplicationInDTO payload,
			@Context SecurityContext sc) {
		return applicationsService.createApplication(tenant, user, payload, CreateProcessType.ASYNC, MDC.get(MDCPreFilter.LOCALE));
	}

	@POST
	@Path("/applications-sync")
	@Operation(description = "Creates sync a new application", tags = { APPLICATIONS_TAG })
	@ApiResponse(description = "The application code created and the anomalies found")
	@ApiResponse(responseCode = "409", description = "At least one severe anomaly occurred")
	public CreateApplicationOutDTO createApplicationSync(
			@Parameter(description = "Current Tenant") @PathParam("tenant") String tenant,
			@Parameter(hidden = true) @Auth User user,
			@Valid CreateApplicationInDTO payload,
			@Context SecurityContext sc) {
		return applicationsService.createApplication(tenant, user, payload, CreateProcessType.SYNC, MDC.get(MDCPreFilter.LOCALE));
	}

	@DELETE
	@Path("/applications")
	@Operation(description = "Logically delete applications", tags = { APPLICATIONS_TAG })
	@ApiResponse(description = "The result of operation")
	public void logicallyDeleteApplications(
			@Parameter(description = "Current Tenant") @PathParam("tenant") String tenant,
			@Parameter(hidden = true) @Auth User user,
			@QueryParam("application_id") List<Long> applicationIdList,
			@Context SecurityContext sc) {
		applicationsService.logicallyDeleteApplications(applicationIdList, user);
	}

	@PUT
	@Path("/applications/{application_id}/amend-of/{amend_application_id}")
	@Operation(description = "Update amend of application id of an application", tags = { APPLICATIONS_TAG })
	@ApiResponse(description = "The result of operation")
	public Response updateAmendOfApplicationId(
			@Parameter(description = "Current Tenant") @PathParam("tenant") String tenant,
			@Parameter(description = "The application id") @PathParam("application_id") Long applicationId,
			@Parameter(description = "The amend application id") @PathParam("amend_application_id") Long amendApplicationId,
			@Parameter(hidden = true) @Auth User user,
			@Context SecurityContext sc) {
		applicationsService.updateAmendOfApplicationId(tenant, applicationId, amendApplicationId, user.getUserId());
		return Response.ok().build();
	}

	@PUT
	@Path("/applications/{application_id}/amended-by/{amended_application_id}")
	@Operation(description = "Update amended by application id of an application", tags = { APPLICATIONS_TAG })
	@ApiResponse(description = "The result of operation")
	public Response updateAmendedByApplicationId(
			@Parameter(description = "Current Tenant") @PathParam("tenant") String tenant,
			@Parameter(description = "The application id") @PathParam("application_id") Long applicationId,
			@Parameter(description = "The amended application id") @PathParam("amended_application_id") Long amendedApplicationId,
			@Parameter(hidden = true) @Auth User user,
			@Context SecurityContext sc) {
		applicationsService.updateAmendedByApplicationId(tenant, applicationId, amendedApplicationId, user.getUserId());
		return Response.ok().build();
	}

	@GET
	@Path("/applications/{application_id}/transitions")
	@Operation(description = "Returns the application's available transitions, given the application code and scope", tags = { APPLICATIONS_TAG })
	@ApiResponse(description = "The available transitions")
	@ApiResponse(responseCode = "404", description = "Application does not exists - ErrCode: APPLICATION_NOT_FOUND_ERROR")
	public List<Transition> getAvailableTransitionsByApplicationCode(@Parameter(description = "Current Tenant") @PathParam("tenant") String tenant,
			@Parameter(description = "The application id") @PathParam("application_id") Long applicationId,
			@Parameter(description = "Filter by scope") @QueryParam("scope") String scope,
			@Parameter(hidden = true) @Auth User user,
			@Context SecurityContext sc) {
		return applicationsService.getAvailableTransitionListByProcessId(tenant, applicationId, user, scope != null ? scope : APPLICATIONS_RESOURCES_SCOPE);
	}

}
