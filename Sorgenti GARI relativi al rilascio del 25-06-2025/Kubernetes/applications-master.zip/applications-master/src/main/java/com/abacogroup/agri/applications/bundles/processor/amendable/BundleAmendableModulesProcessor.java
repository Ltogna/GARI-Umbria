package com.abacogroup.agri.applications.bundles.processor.amendable;

import com.abacogroup.agri.applications.bundles.model.amendable.BundleAmendableModulesMessage;
import com.abacogroup.agri.applications.bundles.processor.AbstractBundleApplicationsProcessor;
import com.abacogroup.bundles.listener.configdata.ConfigDataMessage;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.jdbi.v3.core.Jdbi;

import java.nio.file.Path;

/**
 * @author Samuele Sbarbaro
 */
@Slf4j
public class BundleAmendableModulesProcessor extends AbstractBundleApplicationsProcessor<BundleAmendableModulesMessage> {

	protected final AmendableModulesBundleWorker amendableModulesBundleWorker;

	public BundleAmendableModulesProcessor(ObjectMapper mapper, AmendableModulesBundleWorker sectorsBundleWorker, Jdbi jdbi) {
		super(mapper, jdbi);
		this.amendableModulesBundleWorker = sectorsBundleWorker;
	}

	@Override
	public String getDomainName() {
		return "amendable-modules";
	}

	@Override
	protected TypeReference<BundleAmendableModulesMessage> getTypeReference() {
		return new TypeReference<>() {
		};
	}

	@Override
	public void onMessageInTransaction(ConfigDataMessage message) {
		log.info("onMessageInTransaction: proccessing file with tenant {}", message.getTenantId());
		message.getConfigFiles().stream()
				.map(Path::toFile)
				.filter(file -> file.getAbsolutePath().endsWith(".json"))
				.forEach(file -> processFile(message.getTenantId(), file));
	}

	@Override
	protected void delete(String tenantId, BundleAmendableModulesMessage message) {
		amendableModulesBundleWorker.deleteBundleAmendableModules(tenantId, message);
	}

	@Override
	protected void doInsertOrUpdate(String tenantId, BundleAmendableModulesMessage message) {
		amendableModulesBundleWorker.upsertBundleModules(tenantId, message);
	}

}
