package com.abacogroup.agri.applications.core.mappers;

import com.abacogroup.agri.applications.db.ntt.ApplicationCompileStatusNTT;
import com.abacogroup.applicationworkflowsdk.model.io.output.ApplicationCompileStatusDTO;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

@Mapper
public interface ApplicationCompileStatusMapper extends EntityMapper<ApplicationCompileStatusDTO, ApplicationCompileStatusNTT> {

	ApplicationCompileStatusMapper INSTANCE = Mappers.getMapper(ApplicationCompileStatusMapper.class);

	@InheritInverseConfiguration()
	ApplicationCompileStatusDTO entityToDto(ApplicationCompileStatusNTT entity);

	@Mapping(source = "pkid", target = "pkid")
	@Mapping(source = "applicationId", target = "application_id")
	@Mapping(source = "compileStatusIdentifier", target = "compile_status_identifier")
	@Mapping(source = "status", target = "status")
	ApplicationCompileStatusNTT dtoToEntity(ApplicationCompileStatusDTO dto);

}
