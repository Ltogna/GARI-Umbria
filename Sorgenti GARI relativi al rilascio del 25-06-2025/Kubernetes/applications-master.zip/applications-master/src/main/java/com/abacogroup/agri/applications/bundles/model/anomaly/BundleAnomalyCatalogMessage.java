package com.abacogroup.agri.applications.bundles.model.anomaly;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.List;

/**
 * @author Gennaro Tamburrelli
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class BundleAnomalyCatalogMessage {
	@Builder.Default
	private List<BundleAnomalyCatalogInDTO> anomalies = new ArrayList<>();
}
