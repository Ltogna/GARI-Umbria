package com.abacogroup.agri.applications.core.caller;

import com.abacogroup.jaxrsutils.GenericCallerService;
import com.abacogroup.jaxrsutils.callerv2.AbacoDtoCaller;

/**
 * @author Alexandru Paraschiv
 */
public class GetPartyByPartyIdCaller extends AbacoDtoCaller<GetPartyByPartyIdInput, GetPartiesOutput> {

	public GetPartyByPartyIdCaller(GenericCallerService genericCallerService) {
		super(genericCallerService);
	}

	@Override
	public GetPartiesOutput makeCall(GetPartyByPartyIdInput arg) {
		return super.makeCall(arg);
	}

}
