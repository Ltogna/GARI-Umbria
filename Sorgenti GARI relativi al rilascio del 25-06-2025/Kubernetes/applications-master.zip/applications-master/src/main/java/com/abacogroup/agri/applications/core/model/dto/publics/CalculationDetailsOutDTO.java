package com.abacogroup.agri.applications.core.model.dto.publics;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Map;

/**
 * @author Alexandru Paraschiv
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class CalculationDetailsOutDTO {

	@JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
	private Long calculationConfigId;
	private String calculationCode;
	private String calculationDescription;
	private Integer sortOrder;
	private Map<String, String> params;
	private LastCalculationDTO lastCalculation;
}
