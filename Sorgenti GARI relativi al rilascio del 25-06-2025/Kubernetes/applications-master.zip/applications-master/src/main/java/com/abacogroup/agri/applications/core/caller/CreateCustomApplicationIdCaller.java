package com.abacogroup.agri.applications.core.caller;

import com.abacogroup.agri.applications.core.model.dto.CustomApplicationIdDTO;
import com.abacogroup.jaxrsutils.GenericCallerService;
import com.abacogroup.jaxrsutils.callerv2.AbacoDtoCaller;

/**
 * @author Gennaro Tamburrelli
 */
public class CreateCustomApplicationIdCaller extends AbacoDtoCaller<CreateCustomApplicationIdInput, CustomApplicationIdDTO> {

	public CreateCustomApplicationIdCaller(GenericCallerService genericCallerService) {
		super(genericCallerService);
	}

}
