package com.abacogroup.agri.applications.db.ntt;

import com.abacogroup.agri.applications.db.ntt.applications.IHistoricizationFields;
import com.abacogroup.agri.applications.db.ntt.applications.IIdRs;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.time.LocalDateTime;
import java.util.Optional;

/**
 * @author Samuele Sbarbaro
 */
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class ApplicationProtocolsNTT implements IIdRs<Long>, IHistoricizationFields {

	private Long pkid;
	private Long application_id;
	private LocalDateTime dt_request;
	private LocalDateTime dt_response;
	private String protocol;
	private String user_id_insert;
	private String user_id_delete;
	private LocalDateTime dt_insert;
	private LocalDateTime dt_delete;

	@Override
	public void setKey(Long id) {
		this.pkid = id;
	}

	@Override
	public Optional<Long> getKey() {
		return Optional.ofNullable(this.pkid);
	}
}
