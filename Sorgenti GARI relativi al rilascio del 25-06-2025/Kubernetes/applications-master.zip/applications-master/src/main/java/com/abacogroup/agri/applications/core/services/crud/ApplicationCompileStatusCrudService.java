package com.abacogroup.agri.applications.core.services.crud;

import com.abacogroup.agri.applications.core.exceptions.ObjectNotFoundException;
import com.abacogroup.agri.applications.core.mappers.ApplicationCompileStatusMapper;
import com.abacogroup.agri.applications.db.dao.ApplicationCompileStatusDAO;
import com.abacogroup.agri.applications.db.ntt.ApplicationCompileStatusNTT;
import com.abacogroup.applicationworkflowsdk.model.io.output.ApplicationCompileStatusDTO;
import com.abacogroup.jaxrsutils.filter.MDCPreFilter;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.MDC;

import java.util.List;
import java.util.Optional;

import static com.abacogroup.agri.applications.utils.PagingParamsFactory.DEFAULT_PAGE_SIZE;

/**
 * @author Mauro Pozzana
 */
@Slf4j
public class ApplicationCompileStatusCrudService
		extends AbstractHistoricizationFieldsCrudService<ApplicationCompileStatusNTT, Long, ApplicationCompileStatusDTO, ApplicationCompileStatusMapper, Void> {

	public static final String TO_BE_COMPILED = "TO_BE_COMPILED";

	public ApplicationCompileStatusCrudService(ApplicationCompileStatusDAO dao, ApplicationCompileStatusMapper mapper) {
		super(dao, mapper);
	}

	@Override protected boolean hasPrimaryKey() {
		return true;
	}

	@Override
	protected Void retrieveCustomKeyByResultSet(ApplicationCompileStatusNTT rs) {
		return null;
	}

	@Override
	protected ApplicationCompileStatusNTT adjustR(ApplicationCompileStatusNTT rs) throws Exception {
		return rs;
	}

	@Override protected Optional<ApplicationCompileStatusNTT> findRsByCustomKey(Void customKey) {
		return Optional.empty();
	}

	public ApplicationCompileStatusDTO insert(ApplicationCompileStatusDTO in, String userId) {
		log.info("Invoking insert with params in: {} userid: {}", in, userId);
		return this.insert(in, userId, null);
	}

	public ApplicationCompileStatusDTO update(Long key, ApplicationCompileStatusDTO in, String userId) {
		log.info("Invoking update with params key: {} in: {} userId: {}", key, in, userId);
		return this.update(key, in, userId, null);
	}

	public void delete(Long key, String userId) {
		log.info("Invoking delete with params key: {} userId: {}", key, userId);
		this.delete(key, userId, null);
	}

	public ApplicationCompileStatusDTO findById(Long key) throws ObjectNotFoundException {
		return findOutDtoByPrimaryKey(key);
	}

	/**
	 * find all compile status by application id
	 *
	 * @param tenant currrent tenant
	 * @param appId  the application id
	 * @return all compile status
	 */
	public List<ApplicationCompileStatusDTO> find(String tenant, Long appId) {
		return returnMappedList(((ApplicationCompileStatusDAO) this.dao).findByApplicationId(tenant, appId));
	}

	/**
	 * find partial compile status by application code
	 *
	 * @param tenant          current tenant
	 * @param applicationCode the application code
	 * @param nextKey         the next key for pagination
	 * @return partial compile status
	 */
	public InfiniteListResults<ApplicationCompileStatusDTO> find(String tenant, String applicationCode, String nextKey) {
		return returnInfiniteResults(
				this.dao.infinite(() -> ((ApplicationCompileStatusDAO) this.dao).findByApplicationCode(tenant, applicationCode, MDC.get(MDCPreFilter.LOCALE)),
						nextKey,
						DEFAULT_PAGE_SIZE));
	}

	/**
	 * find partial compile status by application id
	 *
	 * @param tenant        current tenant
	 * @param applicationId the application id
	 * @param nextKey       the next key for pagination
	 * @return partial compile status
	 */
	public InfiniteListResults<ApplicationCompileStatusDTO> find(String tenant, Long applicationId, String nextKey) {
		return returnInfiniteResults(
				this.dao.infinite(() -> ((ApplicationCompileStatusDAO) this.dao).findByApplicationId(tenant, applicationId, MDC.get(MDCPreFilter.LOCALE)),
						nextKey,
						DEFAULT_PAGE_SIZE));
	}

	public ApplicationCompileStatusDTO findById(String tenant, Long id) throws ObjectNotFoundException {
		return findOutDtoByPrimaryKey(id);
	}

	/**
	 * find App compile status by tenant, application id, compile status identifier
	 *
	 * @param tenant                  current tenant
	 * @param applicationId           the application id
	 * @param compileStatusIdentifier the compile status identifier to filter with
	 * @return the app compile status
	 */
	public ApplicationCompileStatusDTO findByCompileStatusIdentifier(String tenant, Long applicationId, String compileStatusIdentifier)
			throws ObjectNotFoundException {
		return ((ApplicationCompileStatusDAO) this.dao)
				.findByApplicationIdAndCompileStatus(tenant, applicationId, compileStatusIdentifier)
				.stream()
				.filter(this::isNotLogicallyDeleted)
				.map(mapper::entityToDto)
				.findFirst()
				.orElseThrow(AbstractCrudService.OBJECT_NOT_FOUND_EXCEPTION_SUPPLIER);
	}

	protected ApplicationCompileStatusDTO findByTenantAndPrimaryKey(String tenant, Long key) throws ObjectNotFoundException {
		return ((ApplicationCompileStatusDAO) this.dao).findByTenantAndId(tenant, key)
				.stream()
				.filter(this::isNotLogicallyDeleted)
				.map(mapper::entityToDto)
				.findFirst()
				.orElseThrow(AbstractCrudService.OBJECT_NOT_FOUND_EXCEPTION_SUPPLIER);
	}
}
