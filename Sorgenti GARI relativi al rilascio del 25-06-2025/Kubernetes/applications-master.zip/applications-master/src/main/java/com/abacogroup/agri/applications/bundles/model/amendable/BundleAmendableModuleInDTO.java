package com.abacogroup.agri.applications.bundles.model.amendable;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author Samuele Sbarbaro
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class BundleAmendableModuleInDTO {
	private String sectorCode;
	private String moduleCode;
	private String amendableModuleCode;
	private String oldAmendableModuleCode;
}
