package com.abacogroup.agri.applications.bundles.processor.anomaly;

import com.abacogroup.agri.applications.bundles.model.anomaly.BundleAnomalyCatalogMessage;
import com.abacogroup.agri.applications.bundles.processor.AbstractBundleApplicationsProcessor;
import com.abacogroup.bundles.listener.configdata.ConfigDataMessage;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.jdbi.v3.core.Jdbi;

import java.nio.file.Path;

/**
 * @author Gennaro Tamburrelli
 */
@Slf4j
public class BundleAnomalyCatalogProcessor extends AbstractBundleApplicationsProcessor<BundleAnomalyCatalogMessage> {

	protected final AnomalyCatalogBundleWorker anomalyCatalogBundleWorker;

	public BundleAnomalyCatalogProcessor(ObjectMapper mapper, AnomalyCatalogBundleWorker anomalyCatalogBundleWorker, Jdbi jdbi) {
		super(mapper, jdbi);
		this.anomalyCatalogBundleWorker = anomalyCatalogBundleWorker;
	}

	@Override
	public String getDomainName() {
		return "anomaly-catalog";
	}

	@Override
	protected TypeReference<BundleAnomalyCatalogMessage> getTypeReference() {
		return new TypeReference<>() {
		};
	}

	@Override
	public void onMessageInTransaction(ConfigDataMessage message) {
		log.info("onMessageInTransaction: proccessing file with tenant {}", message.getTenantId());
		message.getConfigFiles().stream()
				.map(Path::toFile)
				.filter(file -> file.getAbsolutePath().endsWith(".json"))
				.forEach(file -> processFile(message.getTenantId(), file));
	}

	@Override
	protected void delete(String tenantId, BundleAnomalyCatalogMessage message) {
		this.anomalyCatalogBundleWorker.deleteAnomalyCatalog(tenantId, message);
	}

	@Override
	protected void doInsertOrUpdate(String tenantId, BundleAnomalyCatalogMessage message) {
		anomalyCatalogBundleWorker.upsertBundleAnomalyCatalog(tenantId, message);
	}

}
