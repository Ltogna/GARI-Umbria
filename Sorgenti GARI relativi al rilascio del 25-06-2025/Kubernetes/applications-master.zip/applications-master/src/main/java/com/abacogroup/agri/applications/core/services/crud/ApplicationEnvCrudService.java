package com.abacogroup.agri.applications.core.services.crud;

import com.abacogroup.agri.applications.core.exceptions.ObjectNotFoundException;
import com.abacogroup.agri.applications.core.mappers.ApplicationEnvMapper;
import com.abacogroup.agri.applications.core.model.dto.ApplicationEnvDTO;
import com.abacogroup.agri.applications.db.dao.ApplicationEnvDAO;
import com.abacogroup.agri.applications.db.ntt.ApplicationEnvNTT;
import com.abacogroup.agri.applications.db.ntt.compoundkeys.ApplicationEnvKey;
import lombok.extern.slf4j.Slf4j;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * The type Application env crud service.
 *
 * @author Carlo Sindico
 */
@Slf4j
public class ApplicationEnvCrudService
		extends AbstractCrudService<ApplicationEnvNTT, ApplicationEnvKey, ApplicationEnvDTO, ApplicationEnvMapper, ApplicationEnvKey> {

	public ApplicationEnvCrudService(ApplicationEnvDAO dao, ApplicationEnvMapper mapper) {
		super(dao, mapper);
	}

	@Override
	protected boolean hasPrimaryKey() {
		return true;
	}

	@Override
	protected ApplicationEnvDTO findOutDtoByPrimaryKey(ApplicationEnvKey key) throws ObjectNotFoundException {
		return Optional.ofNullable(((ApplicationEnvDAO) this.dao).findByKey(key))
				.map(mapper::entityToDto)
				.orElseThrow(OBJECT_NOT_FOUND_EXCEPTION_SUPPLIER);
	}

	@Override
	protected ApplicationEnvKey retrievePrimaryKey(ApplicationEnvKey customKey) {
		return customKey;
	}

	@Override
	protected Optional<ApplicationEnvNTT> findRsByCustomKey(ApplicationEnvKey customKey) {
		return Optional.ofNullable(((ApplicationEnvDAO) this.dao).findByKey(customKey));
	}

	@Override
	protected void deleteByCustomKey(ApplicationEnvKey key) {
		this.dao.deleteById(key);
	}

	@Override
	protected void setCustomSearchKey(ApplicationEnvNTT rs, ApplicationEnvKey key) {
		rs.setKey(key);
	}

	public ApplicationEnvDTO insert(ApplicationEnvDTO in) {
		log.info("Invoking insert with params in: {}", in);
		return this.insert(in, ApplicationEnvKey.builder()
				.tenant_id(in.getTenant())
				.fl_client(in.getFlClient())
				.key_(in.getKey())
				.build()
		);
	}

	public ApplicationEnvDTO update(ApplicationEnvKey key, ApplicationEnvDTO in) {
		log.info("Invoking update with params in: {}", in);
		return this.update(key, in, null);
	}

	public void delete(ApplicationEnvKey key) {
		log.info("Invoking delete with params key: {}", key);
		this.delete(key, null);
	}

	public ApplicationEnvDTO findEnvironmentByKey(ApplicationEnvKey key) throws ObjectNotFoundException {
		log.info("Invoking findByKey with params tenant: {} key: {}", key.getTenant_id(), key.getKey_());
		ApplicationEnvNTT applicationEnvNTT = ((ApplicationEnvDAO) this.dao).findByKey(key);

		return Optional.ofNullable(applicationEnvNTT)
				.map(mapper::entityToDto)
				.orElseThrow(OBJECT_NOT_FOUND_EXCEPTION_SUPPLIER);
	}

	public ApplicationEnvDTO findByKeyWithoutFlClient(ApplicationEnvKey key) throws ObjectNotFoundException {
		log.info("Invoking findByKey with params tenant: {} key: {}", key.getTenant_id(), key.getKey_());
		ApplicationEnvNTT applicationEnvNTT = ((ApplicationEnvDAO) this.dao).findByKeyWithoutFlClient(key);

		return Optional.ofNullable(applicationEnvNTT)
				.map(mapper::entityToDto)
				.orElseThrow(OBJECT_NOT_FOUND_EXCEPTION_SUPPLIER);
	}

	public List<ApplicationEnvDTO> findAllByTenant(final String tenant) {
		log.info("Invoking findAllByBy with params tenant: {}", tenant);
		return ((ApplicationEnvDAO) this.dao).findAll(tenant).stream()
				.map(mapper::entityToDto)
				.collect(Collectors.toList());
	}

}
