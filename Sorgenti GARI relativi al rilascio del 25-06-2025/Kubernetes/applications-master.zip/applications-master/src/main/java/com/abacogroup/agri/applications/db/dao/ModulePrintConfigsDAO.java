package com.abacogroup.agri.applications.db.dao;

import com.abacogroup.agri.applications.db.ntt.ModulePrintConfigsNTT;
import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.customizer.BindBean;
import org.jdbi.v3.sqlobject.customizer.BindList;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;

import java.util.List;

/**
 * @author Gennaro Tamburrelli
 */
public interface ModulePrintConfigsDAO extends IGenericDAO<ModulePrintConfigsNTT, Long> {

	@Override
	@SqlQuery("§select_nextval(apps_module_print_configs_id_seq)§")
	Long nextSequenceVal();

	@Override
	@SqlUpdate("INSERT INTO apps_module_print_configs " +
			"(id, module_id, process_status, fl_available_to_user, print_code, sort_order, context_function) " +
			"VALUES(:id, :module_id, :process_status, :fl_available_to_user, :print_code, :sort_order, :context_function)")
	void insert(@BindBean ModulePrintConfigsNTT moduleFormConfigs);

	@SqlQuery("select mpc.id, " +
			" mpc.module_id, " +
			" mpc.process_status, " +
			" mpc.fl_available_to_user, " +
			" mpc.print_code, " +
			" mpc.sort_order, " +
			" mpc.context_function " +
			" from apps_module_print_configs mpc " +
			" left join apps_modules am on am.id = mpc.module_id " +
			" left join apps_sectors s on s.id = am.sector_id " +
			" where s.tenant_id=:tenantId " +
			" AND mpc.fl_available_to_user = 1 " +
			" and §current_timestamp§ between am.dt_insert and am.dt_delete")
	@RegisterBeanMapper(ModulePrintConfigsNTT.class)
	List<ModulePrintConfigsNTT> findAllModulePrintConfigsByTenant(@Bind("tenantId") String tenant);

	@SqlQuery("select mpc.id, " +
			" mpc.module_id, " +
			" mpc.process_status, " +
			" mpc.fl_available_to_user, " +
			" mpc.print_code, " +
			" mpc.sort_order, " +
			" mpc.context_function " +
			" from apps_module_print_configs mpc " +
			" left join apps_modules am on am.id = mpc.module_id " +
			" left join apps_sectors s on s.id = am.sector_id " +
			" where s.tenant_id=:tenantId " +
			" and mpc.module_id=:moduleId " +
			" AND mpc.fl_available_to_user = 1 " +
			" and §current_timestamp§ between am.dt_insert and am.dt_delete")
	@RegisterBeanMapper(ModulePrintConfigsNTT.class)
	List<ModulePrintConfigsNTT> findAllModulePrintConfigs(@Bind("tenantId") String tenant, @Bind("moduleId") Long moduleId);

	@SqlQuery("select mpc.id, " +
			" mpc.module_id, " +
			" mpc.process_status, " +
			" mpc.fl_available_to_user, " +
			" mpc.print_code, " +
		    " coalesce(§i18n(s.tenant_id, 'apps_module_print_configs', 'print_code:process_status', mpc.print_code || ':' || mpc.process_status, :lang)§, " +
		    "    §i18n(s.tenant_id, 'apps_module_print_configs', 'print_code', mpc.print_code, :lang)§) as print_description, " + 
			" mpc.sort_order, " +
			" mpc.context_function " +
			" from apps_module_print_configs mpc " +
			" left join apps_modules am on am.id = mpc.module_id " +
			" left join apps_sectors s on s.id = am.sector_id " +
			" where mpc.module_id=:moduleId " +
			" AND mpc.fl_available_to_user = 1 " +
			" and §current_timestamp§ between am.dt_insert and am.dt_delete")
	@RegisterBeanMapper(ModulePrintConfigsNTT.class)
	List<ModulePrintConfigsNTT> findAllModulePrintConfigsByModuleId(@Bind("moduleId") Long moduleId, @Bind("lang") String lang);

	@Override
	@SqlQuery("select mpc.id, " +
			" mpc.module_id, " +
			" mpc.process_status, " +
			" mpc.fl_available_to_user, " +
			" mpc.print_code, " +
			" mpc.sort_order, " +
			" mpc.context_function " +
			" from apps_module_print_configs mpc " +
			" where mpc.id=:id ")
	@RegisterBeanMapper(ModulePrintConfigsNTT.class)
	List<ModulePrintConfigsNTT> findById(@Bind("id") Long id);

	@SqlQuery("select mpc.id, " +
			" mpc.module_id, " +
			" mpc.process_status, " +
			" mpc.fl_available_to_user, " +
			" mpc.print_code, " +
			" coalesce(§i18n(:tenantId, 'apps_module_print_configs', 'print_code:process_status', mpc.print_code || ':' || mpc.process_status, :lang)§, " +
	    	"    §i18n(:tenantId, 'apps_module_print_configs', 'print_code', mpc.print_code, :lang)§) as print_description, " + 
			" mpc.sort_order, " +
			" mpc.context_function " +
			" from apps_module_print_configs mpc " +
			" left join apps_modules am on am.id = mpc.module_id " +
			" left join apps_sectors s on s.id = am.sector_id " +
			" where s.tenant_id=:tenantId and " +
			" mpc.id = :id " +
			" and §current_timestamp§ between am.dt_insert and am.dt_delete")
	@RegisterBeanMapper(ModulePrintConfigsNTT.class)
	List<ModulePrintConfigsNTT> findById(@Bind("tenantId") String tenant, @Bind("id") Long id, @Bind("lang") String lang);

	@SqlQuery("select mpc.id, " +
			" mpc.module_id, " +
			" mpc.process_status, " +
			" mpc.fl_available_to_user, " +
			" mpc.print_code, " +
			" coalesce(§i18n(:tenantId, 'apps_module_print_configs', 'print_code:process_status', mpc.print_code || ':' || :process_status, :lang)§, " +
    		"    §i18n(:tenantId, 'apps_module_print_configs', 'print_code', mpc.print_code, :lang)§) as print_description, " + 
			" mpc.sort_order, " +
			" mpc.context_function " +
			" from apps_module_print_configs mpc " +
			" left join apps_modules am on am.id = mpc.module_id " +
			" left join apps_sectors s on s.id = am.sector_id " +
			" where s.tenant_id=:tenantId  " +
			" AND mpc.module_id = :module_id " +
			" AND mpc.process_status=:process_status" +
			" AND mpc.fl_available_to_user = 1 " +
			" AND §current_timestamp§ between am.dt_insert and am.dt_delete " +
			" AND ((SELECT required_profile_code " +
			"      FROM apps_module_print_config_profiles " +
			"      WHERE module_print_config_id = mpc.id) is null OR " +
			"      (SELECT required_profile_code " +
			"      FROM apps_module_print_config_profiles " +
			"      WHERE module_print_config_id = mpc.id) IN (<app_profile_list>))")
	@RegisterBeanMapper(ModulePrintConfigsNTT.class)
	List<ModulePrintConfigsNTT> find(@Bind("tenantId") String tenant,
			@Bind("module_id") Long moduleId,
			@Bind("process_status") String processStatus,
			@BindList("app_profile_list") List<String> appProfileList,
			@Bind("lang") String lang);

	@SqlQuery("select mpc.id, " +
			" mpc.module_id, " +
			" mpc.process_status, " +
			" mpc.fl_available_to_user, " +
			" mpc.print_code, " +
			" mpc.sort_order, " +
			" mpc.context_function " +
			" from apps_module_print_configs mpc " +
			" left join apps_modules am on am.id = mpc.module_id " +
			" left join apps_sectors s on s.id = am.sector_id " +
			" where s.tenant_id=:tenantId  " +
			" AND mpc.module_id = :module_id " +
			" AND mpc.print_code=:print_code " +
			" AND mpc.process_status=:process_status " +
			" AND mpc.fl_available_to_user = 1 " +
			" AND §current_timestamp§ between am.dt_insert and am.dt_delete ")
	@RegisterBeanMapper(ModulePrintConfigsNTT.class)
	List<ModulePrintConfigsNTT> find(@Bind("tenantId") String tenant,
			@Bind("module_id") Long moduleId,
			@Bind("print_code") String printCode,
			@Bind("process_status") String processStatus);

	@SqlQuery("select mpc.id, " +
			" mpc.module_id, " +
			" mpc.process_status, " +
			" mpc.fl_available_to_user, " +
			" mpc.print_code, " +
			" mpc.sort_order, " +
			" mpc.context_function " +
			" from apps_module_print_configs mpc " +
			" left join apps_modules am on am.id = mpc.module_id " +
			" left join apps_sectors s on s.id = am.sector_id " +
			" where s.tenant_id=:tenantId  " +
			" AND mpc.module_id = :module_id " +
			" AND mpc.print_code=:print_code " +
			" AND ((:process_status IS NULL AND mpc.process_status IS NULL) OR (mpc.process_status=:process_status)) " +
			" AND mpc.fl_available_to_user = :fl_available_to_user " +
			" AND (mpc.context_function = :context_function OR (:context_function IS NULL AND mpc.context_function IS NULL)) " +
			" AND §current_timestamp§ between am.dt_insert and am.dt_delete ")
	@RegisterBeanMapper(ModulePrintConfigsNTT.class)
	List<ModulePrintConfigsNTT> find(@Bind("tenantId") String tenant,
			@Bind("module_id") Long moduleId,
			@Bind("print_code") String printCode,
			@Bind("process_status") String processStatus,
			@Bind("fl_available_to_user") Integer flAvailableToUser,
			@Bind("context_function") String contextFunction);

	@SqlQuery("select mpc.id, " +
			" mpc.module_id, " +
			" mpc.process_status, " +
			" mpc.fl_available_to_user, " +
			" mpc.print_code, " +
			" mpc.sort_order, " +
			" mpc.context_function " +
			" from apps_module_print_configs mpc " +
			" left join apps_modules am on am.id = mpc.module_id " +
			" left join apps_sectors s on s.id = am.sector_id " +
			" where s.tenant_id=:tenantId " +
			" and mpc.print_code = :print_code " +
			" and fl_available_to_user = 1")
	@RegisterBeanMapper(ModulePrintConfigsNTT.class)
	List<ModulePrintConfigsNTT> findByPrintCode(@Bind("tenantId") String tenant, @Bind("print_code") String printCode);

	@Override
	@SqlUpdate("UPDATE apps_module_print_configs SET " +
			"module_id=:module_id, " +
			"process_status=:process_status, " +
			"fl_available_to_user=:fl_available_to_user, " +
			"print_code=:print_code, " +
			"sort_order=:sort_order, " +
			"context_function=:context_function " +
			"WHERE id=:id")
	void update(@BindBean ModulePrintConfigsNTT sector);

	@Override
	@SqlUpdate("DELETE FROM apps_module_print_configs " +
			"WHERE id=:id")
	void deleteById(@Bind("id") Long id);


	@SqlQuery("select mpc.id, " +
			" mpc.module_id, " +
			" mpc.process_status, " +
			" mpc.print_code, " +
			" coalesce(§i18n(:tenantId, 'apps_module_print_configs', 'print_code:process_status', mpc.print_code || ':' || mpc.process_status, :lang)§, " +
    		"    §i18n(:tenantId, 'apps_module_print_configs', 'print_code', mpc.print_code, :lang)§) as print_description, " + 
			" mpc.sort_order, " +
			" mpc.context_function " +
			" from apps_module_print_configs mpc " +
			" left join apps_modules am on am.id = mpc.module_id " +
			" left join apps_sectors s on s.id = am.sector_id " +
			" where s.tenant_id=:tenantId  " +
			" AND mpc.module_id = :module_id " +
			" AND §current_timestamp§ between am.dt_insert and am.dt_delete " +
			" AND mpc.fl_available_to_user = 0 " +
			" AND ((SELECT required_profile_code " +
			"      FROM apps_module_print_config_profiles " +
			"      WHERE module_print_config_id = mpc.id) is null OR " +
			"      (SELECT required_profile_code " +
			"      FROM apps_module_print_config_profiles " +
			"      WHERE module_print_config_id = mpc.id) IN (<app_profile_list>))")
	@RegisterBeanMapper(ModulePrintConfigsNTT.class)
	List<ModulePrintConfigsNTT> findSystemPrints(@Bind("tenantId") String tenant,
									 @Bind("module_id") Long moduleId,
									 @BindList("app_profile_list") List<String> appProfileList,
									 @Bind("lang") String lang);
}
