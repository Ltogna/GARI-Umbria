package com.abacogroup.agri.applications.bundles.model.form;

import com.abacogroup.agri.applications.bundles.model.I18nPair;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * @author Alexandru Paraschiv
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class BundleFormGroupInDTO {
	private String formGroupCode;
	private List<BundleFormGroupInDTO> formGroupChildren;
	private List<I18nPair> i18n;

}
