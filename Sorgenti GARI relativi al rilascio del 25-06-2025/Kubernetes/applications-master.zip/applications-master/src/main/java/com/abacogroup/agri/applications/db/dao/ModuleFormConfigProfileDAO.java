package com.abacogroup.agri.applications.db.dao;

import com.abacogroup.agri.applications.db.ntt.ModuleFormConfigProfileNTT;
import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.customizer.BindBean;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;

import java.util.List;

/**
 * @author Alexandru Paraschiv
 */
public interface ModuleFormConfigProfileDAO extends IGenericDAO<ModuleFormConfigProfileNTT, Void> {

	@Override
	@SqlQuery("not implemented")
	Void nextSequenceVal();

	@SqlUpdate("INSERT INTO apps_module_form_config_profiles " +
			"(module_form_config_id, required_profile_code) " +
			"VALUES(:module_form_config_id, :required_profile_code)")
	void insert(@BindBean ModuleFormConfigProfileNTT formGroup);

	@SqlQuery("SELECT p.module_form_config_id," +
			"p.required_profile_code " +
			"FROM apps_module_form_config_profiles p " +
			"WHERE p.module_form_config_id=:module_form_config_id AND p.required_profile_code = :required_profile_code AND " +
			":tenant_id in " +
			"(SELECT s.tenant_id " +
			" FROM apps_module_form_configs mfc" +
			" INNER JOIN apps_modules am on am.id = mfc.module_id " +
			" INNER JOIN apps_sectors s on s.id = am.sector_id " +
			" WHERE p.module_form_config_id = mfc.id)")
	@RegisterBeanMapper(ModuleFormConfigProfileNTT.class)
	List<ModuleFormConfigProfileNTT> findById(@Bind("tenant_id") String tenantId, @Bind("module_form_config_id") Long moduleFormConfigId,
			@Bind("required_profile_code") String requiredProfileCode);

	@SqlQuery("SELECT p.module_form_config_id," +
			"p.required_profile_code " +
			"FROM apps_module_form_config_profiles p " +
			"WHERE p.module_form_config_id=:module_form_config_id AND p.required_profile_code = :required_profile_code")
	@RegisterBeanMapper(ModuleFormConfigProfileNTT.class)
	List<ModuleFormConfigProfileNTT> findById(@Bind("module_form_config_id") Long moduleFormConfigId,
			@Bind("required_profile_code") String requiredProfileCode);

	@SqlQuery("SELECT p.module_form_config_id," +
			"p.required_profile_code " +
			"FROM apps_module_form_config_profiles p " +
			"WHERE p.module_form_config_id=:module_form_config_id AND " +
			":tenant_id in " +
			"(SELECT s.tenant_id " +
			" FROM apps_module_form_configs mfc" +
			" INNER JOIN apps_modules am on am.id = mfc.module_id " +
			" INNER JOIN apps_sectors s on s.id = am.sector_id " +
			" WHERE p.module_form_config_id = mfc.id)")
	@RegisterBeanMapper(ModuleFormConfigProfileNTT.class)
	List<ModuleFormConfigProfileNTT> find(@Bind("tenant_id") String tenantId, @Bind("module_form_config_id") Long moduleFormConfigId);

	@SqlUpdate("UPDATE apps_module_form_config_profiles SET " +
			"required_profile_code=:required_profile_code " +
			"where module_form_config_id=:module_form_config_id")
	void update(@BindBean ModuleFormConfigProfileNTT moduleFormConfig);

	@SqlUpdate("DELETE FROM apps_module_form_config_profiles p " +
			"WHERE p.module_form_config_id=:module_form_config_id AND p.required_profile_code = :required_profile_code")
	void deleteById(@Bind("module_form_config_id") Long moduleFormConfigId,
			@Bind("required_profile_code") String requiredProfileCode);

	@SqlUpdate("DELETE FROM apps_module_form_config_profiles p " +
			"WHERE p.module_form_config_id=:module_form_config_id")
	void deleteByModuleFormConfigId(@Bind("module_form_config_id") Long moduleFormConfigId);

	@SqlUpdate("DELETE FROM apps_module_form_config_profiles amfcp " +
			"WHERE amfcp.MODULE_FORM_CONFIG_ID IN ( " +
			"   SELECT profiles.MODULE_FORM_CONFIG_ID  " +
			"   FROM apps_module_form_config_profiles profiles  " +
			"   JOIN APPS_MODULE_FORM_CONFIGS amfc ON profiles.MODULE_FORM_CONFIG_ID = amfc.ID  " +
			"   WHERE amfc.MODULE_ID  = :moduleId)")
	void bulkDeleteByModuleId(@Bind("moduleId") Long moduleId);
}
