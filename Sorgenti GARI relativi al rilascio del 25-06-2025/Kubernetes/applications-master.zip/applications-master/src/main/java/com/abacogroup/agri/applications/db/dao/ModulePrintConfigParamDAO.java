package com.abacogroup.agri.applications.db.dao;

import com.abacogroup.agri.applications.db.ntt.ModulePrintConfigParamNTT;
import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.customizer.BindBean;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;

import java.util.List;

/**
 * @author Gennaro Tamburrelli
 */
public interface ModulePrintConfigParamDAO extends IGenericDAO<ModulePrintConfigParamNTT, Void> {

	@Override
	@SqlQuery("not implemented")
	Void nextSequenceVal();

	@SqlUpdate("INSERT INTO apps_module_print_config_params " +
			"(module_print_config_id, parameter_name, parameter_value) " +
			"VALUES(:module_print_config_id, :parameter_name, :parameter_value)")
	void insert(@BindBean ModulePrintConfigParamNTT formGroup);

	@SqlQuery("SELECT p.module_print_config_id," +
			"p.parameter_name, " +
			"p.parameter_value " +
			"FROM apps_module_print_config_params p " +
			"WHERE p.module_print_config_id=:module_print_config_id and p.parameter_name = :parameter_name " +
			"and :tenant_id in " +
			"(SELECT s.tenant_id " +
			" FROM apps_sectors s INNER JOIN apps_modules m ON s.id = m.sector_id" +
			"      INNER JOIN apps_module_print_configs c ON m.id = c.module_id " +
			" WHERE p.module_print_config_id = c.id" +
			" and §current_timestamp§ between m.dt_insert and m.dt_delete)")
	@RegisterBeanMapper(ModulePrintConfigParamNTT.class)
	List<ModulePrintConfigParamNTT> findById(@Bind("tenant_id") String tenantId, @Bind("module_print_config_id") Long moduleFormConfigId,
			@Bind("parameter_name") String parameterName);

	@SqlQuery("SELECT p.module_print_config_id," +
			"p.parameter_name, " +
			"p.parameter_value " +
			"FROM apps_module_print_config_params p " +
			"WHERE p.module_print_config_id=:module_print_config_id AND p.parameter_name = :parameter_name")
	@RegisterBeanMapper(ModulePrintConfigParamNTT.class)
	List<ModulePrintConfigParamNTT> findById(@Bind("module_print_config_id") Long moduleFormConfigId,
			@Bind("parameter_name") String parameterName);

	@SqlQuery("SELECT p.module_print_config_id," +
			"p.parameter_name, " +
			"p.parameter_value " +
			"FROM apps_module_print_config_params p " +
			"WHERE p.module_print_config_id=:module_print_config_id AND " +
			":tenant_id in " +
			"(SELECT s.tenant_id " +
			" FROM apps_sectors s INNER JOIN apps_modules m ON s.id = m.sector_id" +
			"      INNER JOIN apps_module_print_configs c ON m.id = c.module_id " +
			" WHERE p.module_print_config_id = c.id" +
			" and §current_timestamp§ between m.dt_insert and m.dt_delete)")
	@RegisterBeanMapper(ModulePrintConfigParamNTT.class)
	List<ModulePrintConfigParamNTT> find(@Bind("tenant_id") String tenantId, @Bind("module_print_config_id") Long moduleFormConfigId);

	@SqlUpdate("UPDATE apps_module_print_config_params SET " +
			"parameter_value=:parameter_value " +
			"where module_print_config_id=:module_print_config_id and parameter_name=:parameter_name")
	void update(@BindBean ModulePrintConfigParamNTT sector);

	@SqlUpdate("DELETE FROM apps_module_print_config_params p " +
			"WHERE p.module_print_config_id=:module_print_config_id AND p.parameter_name = :parameter_name")
	void deleteById(@Bind("module_print_config_id") Long moduleFormConfigId,
			@Bind("parameter_name") String parameterName);

	@SqlUpdate("DELETE FROM apps_module_print_config_params p " +
			"WHERE p.module_print_config_id=:module_print_config_id")
	void deleteByModulePrintConfigId(@Bind("module_print_config_id") Long moduleFormConfigId);

}
