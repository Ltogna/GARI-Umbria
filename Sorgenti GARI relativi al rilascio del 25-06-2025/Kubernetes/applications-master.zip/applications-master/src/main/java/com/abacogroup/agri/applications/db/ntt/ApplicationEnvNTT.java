package com.abacogroup.agri.applications.db.ntt;

import com.abacogroup.agri.applications.db.ntt.applications.IIdRs;
import com.abacogroup.agri.applications.db.ntt.compoundkeys.ApplicationEnvKey;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.util.Optional;

/**
 * The type Application env ntt.
 *
 * @author Carlo Sindico
 */
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class ApplicationEnvNTT implements IIdRs<ApplicationEnvKey> {

    private String tenant_id;
    private String key_;
    private String value;
    private Integer fl_client;


    public Optional<ApplicationEnvKey> getKey() {
        return Optional.ofNullable(ApplicationEnvKey.builder()
                .tenant_id(tenant_id)
                .key_(key_)
                        .fl_client(fl_client)
                .build()
        );
    }

    public void setKey(ApplicationEnvKey key) {
        this.tenant_id = key.getTenant_id();
        this.key_ = key.getKey_();
        this.fl_client = key.getFl_client();
    }

}
