package com.abacogroup.agri.applications.bundles.processor.amendable;

import com.abacogroup.agri.applications.bundles.BundleConstants;
import com.abacogroup.agri.applications.bundles.model.amendable.BundleAmendableModuleInDTO;
import com.abacogroup.agri.applications.bundles.model.amendable.BundleAmendableModulesMessage;
import com.abacogroup.agri.applications.core.exceptions.ObjectNotFoundRuntimeException;
import com.abacogroup.agri.applications.core.model.dto.AmendableModuleDTO;
import com.abacogroup.agri.applications.core.model.dto.ModuleDTO;
import com.abacogroup.agri.applications.core.services.crud.AmendableModuleCrudService;
import com.abacogroup.agri.applications.core.services.crud.ModuleCrudService;
import com.abacogroup.agri.applications.core.services.crud.SectorsCrudService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import java.text.MessageFormat;
import java.util.Optional;

/**
 * @author Samuele Sbarbaro
 */
@Slf4j
public class AmendableModulesBundleWorker {

    private final AmendableModuleCrudService amendableModuleCrudService;
    private final ModuleCrudService moduleCrudService;
    private final SectorsCrudService sectorsCrudService;

    public AmendableModulesBundleWorker(AmendableModuleCrudService amendableModuleCrudService,
                                        ModuleCrudService moduleCrudService, SectorsCrudService sectorsCrudService) {
        this.amendableModuleCrudService = amendableModuleCrudService;
        this.moduleCrudService = moduleCrudService;
        this.sectorsCrudService = sectorsCrudService;
    }

    public AmendableModuleCrudService exposeAmendableModuleCrudService() {
        return this.amendableModuleCrudService;
    }

    public ModuleCrudService exposeModuleCrudService() {
        return this.moduleCrudService;
    }

    public SectorsCrudService exposeSectorCrudService() {
        return this.sectorsCrudService;
    }

    public void upsertBundleModules(final String tenantId, BundleAmendableModulesMessage message) {
        log.info("AmendableModulesBundleWorker: processing file with tenant {}", tenantId);
        message.getAmendableModules().forEach(amendableModule -> {
            try {
                getAmendableModuleDTO(tenantId, amendableModule, Boolean.TRUE).ifPresentOrElse(
                        amendableModuleToUpdate -> {
                            log.info("AmendableModulesBundleWorker: updating amendable module with tenant {} and moduleCode {} and amendableModuleCode {}", tenantId, amendableModule.getModuleCode(), amendableModule.getOldAmendableModuleCode());

                            ModuleDTO newAmendableModule = findModuleByCode(tenantId, amendableModule.getAmendableModuleCode());

                            AmendableModuleDTO amendableModuleUpdated = AmendableModuleDTO.builder()
                                    .moduleId(amendableModuleToUpdate.getModuleId())
                                    .amendableModuleId(newAmendableModule.getModuleId())
                                    .build();

                            amendableModuleCrudService.update(amendableModuleToUpdate.getPkid(), amendableModuleUpdated, BundleConstants.BUNDLE_SYSTEM_USERNAME);
                        },
                        () -> {
                            log.info("AmendableModulesBundleWorker: inserting amendable module with tenant {} and moduleCode {} and amendableModuleCode {}", tenantId, amendableModule.getModuleCode(), amendableModule.getAmendableModuleCode());

                            ModuleDTO moduleIdToInsert = findModuleByCode(tenantId, amendableModule.getModuleCode());
                            ModuleDTO amendableModuleIdToInsert = findModuleByCode(tenantId, amendableModule.getAmendableModuleCode());

                            AmendableModuleDTO amendableModuleToInsert = AmendableModuleDTO.builder()
                                    .moduleId(moduleIdToInsert.getModuleId())
                                    .amendableModuleId(amendableModuleIdToInsert.getModuleId())
                                    .build();

                            amendableModuleCrudService.insert(amendableModuleToInsert, BundleConstants.BUNDLE_SYSTEM_USERNAME);
                        });
            } catch (Exception e) {
                log.error("AmendableModulesBundleWorker: error while inserting amendable module");
                throw e;
            }
        });
    }

    public void deleteBundleAmendableModules(String tenantId, BundleAmendableModulesMessage message) {
        log.info("AmendableModulesBundleWorker: processing delete file with tenant {}", tenantId);
        message.getAmendableModules().forEach(amendableModule ->
            getAmendableModuleDTO(tenantId, amendableModule, Boolean.FALSE)
                    .ifPresentOrElse(
                            amendableModuleToDelete -> {
                                log.info("AmendableModulesBundleWorker: deleting amendableModule {}", amendableModuleToDelete.getPkid());
                                amendableModuleCrudService.delete(amendableModuleToDelete.getPkid(), BundleConstants.BUNDLE_SYSTEM_USERNAME);
                                log.info("AmendableModulesBundleWorker: amendableModule {} deleted", amendableModuleToDelete.getPkid());
                            },
                            () -> {
                                log.info("AmendableModulesBundleWorker: amendableModule with module code {} and amendable module code {} not found: cannot be deleted", amendableModule.getModuleCode(), amendableModule.getAmendableModuleCode());
                                throw new ObjectNotFoundRuntimeException();
                            })
        );
    }

    public Optional<AmendableModuleDTO> getAmendableModuleDTO(String tenantId, BundleAmendableModuleInDTO amendableModule, Boolean useOldCode) {
        if (Boolean.TRUE.equals(useOldCode) && StringUtils.isAllBlank(amendableModule.getOldAmendableModuleCode())) {
            log.debug("AmendableModulesBundleWorker: no old parent module code passed, skip the search for old amendable module to update");
            return Optional.empty();
        }

        String amendableModuleCodeToSearch = Boolean.TRUE.equals(useOldCode) ? amendableModule.getOldAmendableModuleCode() : amendableModule.getAmendableModuleCode();

        log.info("AmendableModulesBundleWorker: search for amendable module with module code {} and parent module code {}", amendableModule.getModuleCode(), amendableModuleCodeToSearch);
        ModuleDTO moduleDTO;
        ModuleDTO amendableModuleDTO;
        if(amendableModule.getSectorCode() != null) {
            moduleDTO = findBySectorCodeAndModuleCode(tenantId, amendableModule.getSectorCode(), amendableModule.getModuleCode());
            amendableModuleDTO = findBySectorCodeAndModuleCode(tenantId, amendableModule.getSectorCode(), amendableModuleCodeToSearch);
        } else { // for retrocompatibility
            moduleDTO = findModuleByCode(tenantId, amendableModule.getModuleCode());
            amendableModuleDTO = findModuleByCode(tenantId, amendableModuleCodeToSearch);
        }

        return amendableModuleCrudService.findOptByModuleIdAndAmendableModuleId(moduleDTO.getModuleId(), amendableModuleDTO.getModuleId());

    }

    private ModuleDTO findBySectorCodeAndModuleCode(String tenant, String sectorCode, String moduleCode) {
        return moduleCrudService.findByModuleCodeAndSectorCode(tenant, sectorCode, moduleCode)
                .orElseThrow(() -> new ObjectNotFoundRuntimeException(MessageFormat.format("AmendableModulesBundleWorker: module with code: {0} and sector code {1} not found", moduleCode, sectorCode)));
    }

    private ModuleDTO findModuleByCode(String tenant, String moduleCode) {
        return moduleCrudService.findByCode(tenant, moduleCode)
                .orElseThrow(() -> new ObjectNotFoundRuntimeException(MessageFormat.format("AmendableModulesBundleWorker: module with code: {0} not found", moduleCode)));
    }

}
