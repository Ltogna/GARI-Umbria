package com.abacogroup.agri.applications.core.model.dto.publics;

import com.abacogroup.agri.applications.core.model.dto.PartyDTO;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * @author Alexandru Paraschiv
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PartiesPublicOutDTO {
	private List<PartyDTO> parties;

}
