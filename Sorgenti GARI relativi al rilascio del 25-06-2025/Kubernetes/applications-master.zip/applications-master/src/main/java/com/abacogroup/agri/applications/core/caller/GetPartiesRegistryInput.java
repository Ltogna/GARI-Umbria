package com.abacogroup.agri.applications.core.caller;

import com.abacogroup.applicationsupport.model.io.callerinput.companyfile.BaseCompanyFileInput;
import com.abacogroup.jaxrsutils.callerv2.ICallerInput;

import jakarta.validation.constraints.NotNull;

import java.util.HashMap;
import java.util.Map;

/**
 * @author Gennaro Tamburrelli
 */
public class GetPartiesRegistryInput extends BaseCompanyFileInput implements ICallerInput {

	private final String resourceUrl;
	private final String searchCode;
	private final String searchDescription;
	private final String partyRegistryUrl;

	public GetPartiesRegistryInput(@NotNull String tenant, @NotNull Long partyId, @NotNull String authToken,
			String searchCode, String searchDescription,
			@NotNull String partyRegistryUrl, @NotNull String resourceUrl) {
		super(tenant, partyId, authToken, partyRegistryUrl);
		this.resourceUrl = resourceUrl;
		this.searchCode = searchCode;
		this.searchDescription = searchDescription;
		this.partyRegistryUrl = partyRegistryUrl;
	}

	@Override
	public Map<String, Object> getPathVariablesMap() {
		return Map.of("tenant", this.tenant);
	}

	@Override
	public String provideAuthToken() {
		return this.authToken;
	}

	@Override
	public Map<String, Object> getQueryParamsMap() {
		Map<String, Object> m = new HashMap<>();
		if (this.searchCode != null) {
			m.put("code", this.searchCode);
		}
		if (this.searchDescription != null) {
			m.put("fullName", this.searchDescription);
		}
		return m;
	}

	@Override
	public String getUrl() {
		return this.partyRegistryUrl + resourceUrl;
	}

	@Override
	public String getHttpMethod() {
		return "GET";
	}

}
