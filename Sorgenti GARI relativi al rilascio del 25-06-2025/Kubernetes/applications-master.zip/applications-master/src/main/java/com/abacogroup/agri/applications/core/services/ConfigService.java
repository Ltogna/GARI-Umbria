package com.abacogroup.agri.applications.core.services;

import com.abacogroup.agri.applications.core.exceptions.ObjectNotFoundException;
import com.abacogroup.agri.applications.core.exceptions.ObjectNotFoundRuntimeException;
import com.abacogroup.agri.applications.core.model.dto.ApplicationEnvDTO;
import com.abacogroup.agri.applications.core.model.dto.publics.ApplicationEnvPublicDTO;
import com.abacogroup.agri.applications.core.services.crud.ApplicationEnvCrudService;
import com.abacogroup.agri.applications.db.ntt.compoundkeys.ApplicationEnvKey;

import java.util.List;
import java.util.stream.Collectors;

/**
 * @author Gennaro Tamburrelli
 */
public class ConfigService {

	private final ApplicationEnvCrudService applicationEnvCrudService;

	public ConfigService(ApplicationEnvCrudService applicationEnvCrudService) {
		this.applicationEnvCrudService = applicationEnvCrudService;
	}

	public List<ApplicationEnvPublicDTO> getConfig(final String tenant, final String searchKey) {
		return getConfig(tenant, searchKey, 1);

	}

	public List<ApplicationEnvPublicDTO> getConfig(final String tenant, final String searchKey, Integer flClient) {
		List<ApplicationEnvDTO> result = null;
		try {
			if (searchKey != null) {
				ApplicationEnvKey key = ApplicationEnvKey.builder()
						.tenant_id(tenant)
						.key_(searchKey)
						.fl_client(flClient)
						.build();

				return List.of(applicationEnvCrudService.findEnvironmentByKey(key))
						.stream()
						.map(env -> ApplicationEnvPublicDTO.builder()
								.key(env.getKey())
								.value(env.getValue())
								.build()
						)
						.collect(Collectors.toList());
			} else {
				result = applicationEnvCrudService.findAllByTenant(tenant);
			}

			return result.stream()
					.filter(env -> env.getFlClient() != 0)
					.map(env -> ApplicationEnvPublicDTO.builder()
							.key(env.getKey())
							.value(env.getValue())
							.build()
					)
					.collect(Collectors.toList());
		} catch (ObjectNotFoundException e) {
			throw new ObjectNotFoundRuntimeException();
		}
	}
}
