package com.abacogroup.agri.applications.core.mappers;

import com.abacogroup.agri.applications.core.model.dto.ModulePrintConfigsDTO;
import com.abacogroup.agri.applications.db.ntt.ModulePrintConfigsNTT;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

@Mapper(uses = AbsoluteDateMapper.class)
public interface ModulePrintConfigsMapper extends EntityMapper<ModulePrintConfigsDTO, ModulePrintConfigsNTT> {

	ModulePrintConfigsMapper INSTANCE = Mappers.getMapper(ModulePrintConfigsMapper.class);

	@InheritInverseConfiguration()
	ModulePrintConfigsDTO entityToDto(ModulePrintConfigsNTT entity);

	@Mapping(source = "id", target = "id")
	@Mapping(source = "moduleId", target = "module_id")
	@Mapping(source = "processStatus", target = "process_status")
	@Mapping(source = "flAvailableToUser", target = "fl_available_to_user")
	@Mapping(source = "printCode", target = "print_code")
	@Mapping(source = "printDescription", target = "print_description")
	@Mapping(source = "sortOrder", target = "sort_order")
	@Mapping(source = "contextFunction", target = "context_function")
	ModulePrintConfigsNTT dtoToEntity(ModulePrintConfigsDTO dto);

}
