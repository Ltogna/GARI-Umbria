package com.abacogroup.agri.applications.core.model.dto.publics;

import java.util.Map;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author Gennaro Tamburrelli
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class PrintDetailsOutDTO implements DescriptionReplacer{

	@JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
	private Long printConfigId;
	private String printCode;
	private String printDescription;
	private Integer sortOrder;
	private Map<String, String> params;
	private LastPrintDTO lastPrint;

	@Override public String getDescription() {
		return printDescription;
	}

	@Override public void setDescription(String parsedDescription) {
		this.printDescription = parsedDescription;
	}
}
