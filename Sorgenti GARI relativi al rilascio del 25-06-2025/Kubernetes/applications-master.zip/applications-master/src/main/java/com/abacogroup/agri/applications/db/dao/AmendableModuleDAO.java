package com.abacogroup.agri.applications.db.dao;

import com.abacogroup.agri.applications.db.ntt.AmendableModuleNTT;
import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.customizer.BindBean;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;

import java.time.LocalDateTime;
import java.util.List;

/**
 * @author Samuele Sbarbaro
 */
public interface AmendableModuleDAO extends IGenericHistoricizationFieldsDAO<AmendableModuleNTT, Long, Void> {

	@Override
	@SqlQuery("§select_nextval(apps_amendable_modules_id_seq)§")
	Long nextSequenceVal();

	@Override
	@SqlUpdate("INSERT INTO apps_amendable_modules " +
			" (pkid, " +
			" module_id, " +
			" amendable_module_id, " +
			" dt_insert, " +
			" dt_delete, " +
			" user_id_insert, " +
			" user_id_delete) " +
			" VALUES(:pkid, :module_id, :amendable_module_id, :current_timestamp, " +
			"       TO_TIMESTAMP('9999-12-3123:59:59','YYYY-MM-DDHH24:MI:SS'), :user_id, NULL)")
	void insert(@BindBean AmendableModuleNTT rs, @Bind("user_id") String userId, @Bind("current_timestamp") LocalDateTime currentTimestamp);

	@Override
	@SqlQuery("SELECT pkid, " +
			" module_id, " +
			" amendable_module_id, " +
			" dt_insert, " +
			" dt_delete, " +
			" user_id_insert, " +
			" user_id_delete " +
			" FROM apps_amendable_modules " +
			" WHERE pkid = :id")
	@RegisterBeanMapper(AmendableModuleNTT.class)
	List<AmendableModuleNTT> findById(@Bind("id") Long id);

	@SqlQuery("SELECT pkid, " +
			" module_id, " +
			" amendable_module_id, " +
			" dt_insert, " +
			" dt_delete, " +
			" user_id_insert, " +
			" user_id_delete " +
			" FROM apps_amendable_modules " +
			" WHERE amendable_module_id = :amendable_module_id " +
			" AND module_id = :module_id " +
			" AND §current_timestamp§ BETWEEN dt_insert AND dt_delete ")
	@RegisterBeanMapper(AmendableModuleNTT.class)
	AmendableModuleNTT findByModuleIdAndAmendableModuleId(@Bind("amendable_module_id") Long amendableModuleId, @Bind("module_id") Long moduleId);

	@SqlQuery("SELECT pkid, " +
			" module_id, " +
			" amendable_module_id, " +
			" dt_insert, " +
			" dt_delete, " +
			" user_id_insert, " +
			" user_id_delete " +
			" FROM apps_amendable_modules " +
			" WHERE module_id = :module_id " +
			" AND §current_timestamp§ BETWEEN dt_insert AND dt_delete")
	@RegisterBeanMapper(AmendableModuleNTT.class)
	List<AmendableModuleNTT> findByModuleId(@Bind("module_id") Long moduleId);

	@SqlQuery("SELECT am.pkid, " +
			" am.module_id, " +
			" am.amendable_module_id, " +
			" am.dt_insert, " +
			" am.dt_delete, " +
			" am.user_id_insert, " +
			" am.user_id_delete " +
			" FROM apps_amendable_modules am " +
			" left join apps_module_details md on am.module_id = md.module_id " +
			" left join apps_modules m on md.module_id = m.id " +
			" left join apps_sectors s on m.sector_id = s.id " +
			" WHERE am.amendable_module_id = :amendable_module_id " +
			" AND s.tenant_id = :tenant_id " +
			" AND §current_timestamp§ BETWEEN am.dt_insert AND am.dt_delete")
	@RegisterBeanMapper(AmendableModuleNTT.class)
	List<AmendableModuleNTT> findByAmendableModuleId(@Bind("tenant_id") String tenant ,@Bind("amendable_module_id") Long amendableModuleId);

	@SqlQuery("SELECT am.pkid, " +
			" am.module_id, " +
			" am.amendable_module_id, " +
			" am.dt_insert, " +
			" am.dt_delete, " +
			" am.user_id_insert, " +
			" am.user_id_delete " +
			" FROM apps_amendable_modules am " +
			" left join apps_module_details md on am.module_id = md.module_id " +
			" left join apps_modules m on md.module_id = m.id " +
			" left join apps_sectors s on m.sector_id = s.id " +
			" WHERE s.tenant_id = :tenant_id " +
			" AND §current_timestamp§ BETWEEN am.dt_insert AND am.dt_delete ")
	@RegisterBeanMapper(AmendableModuleNTT.class)
	List<AmendableModuleNTT> findAllByTenant(@Bind("tenant_id") String tenant);

	@Override
	@SqlUpdate("UPDATE apps_amendable_modules SET " +
			" user_id_delete = :user_id_delete, dt_delete = :current_timestamp " +
			" WHERE pkid = :id " +
			" AND §current_timestamp§ BETWEEN dt_insert AND dt_delete")
	void logicallyDeleteById(@Bind("id") Long id, @Bind("user_id_delete") String userDelete, @Bind("current_timestamp") LocalDateTime currentTimestamp);
}
