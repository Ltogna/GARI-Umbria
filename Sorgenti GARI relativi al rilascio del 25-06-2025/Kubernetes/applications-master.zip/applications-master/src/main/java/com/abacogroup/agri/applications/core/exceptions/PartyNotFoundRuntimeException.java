package com.abacogroup.agri.applications.core.exceptions;

import io.swagger.v3.oas.annotations.media.Schema;

import jakarta.ws.rs.core.Response;

public class PartyNotFoundRuntimeException extends AbstractException {

	private static final PartyNotFoundRuntimeException.ErrorBody BODY = new PartyNotFoundRuntimeException.ErrorBody();

	public PartyNotFoundRuntimeException(String message) {
		super(Response.Status.NOT_FOUND, BODY, message);
	}

	public PartyNotFoundRuntimeException() {
		super(Response.Status.NOT_FOUND, BODY, "Party not found");
	}

	@Schema(name = "PartyNotFoundRuntimeExceptionErrorBody")
	public static class ErrorBody implements ExceptionErrorBody {
		private static final String ERR = "NO_PARTY_FOUND_EXCEPTION";

		@Override
		@Schema(allowableValues = ERR)
		public String getErrorCode() {
			return ERR;
		}
	}
}
