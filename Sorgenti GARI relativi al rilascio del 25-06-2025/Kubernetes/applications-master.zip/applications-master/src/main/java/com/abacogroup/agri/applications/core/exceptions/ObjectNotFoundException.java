package com.abacogroup.agri.applications.core.exceptions;

public class ObjectNotFoundException extends AgriApplicationsException {

	/**
	 * 
	 */
	private static final long serialVersionUID = -5253740675913336764L;

	public ObjectNotFoundException(String errorMessage, Throwable err) {
		super(errorMessage, err);
	}

	public ObjectNotFoundException(String errorMessage) {
		super(errorMessage);
	}

	public ObjectNotFoundException(Throwable err) {
		super(err);
	}
}
