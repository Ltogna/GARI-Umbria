package com.abacogroup.agri.applications.core.model.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author Gennaro Tamburrelli
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ApplicationProfileDTO {
	@JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
	private Long pkid;
	@JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
	private Long applicationId;
	@Schema(description = "the profile code")
	private String profileCode;
	@Schema(description = "the profile description")
	private String profileCodeDescription;
	@JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
	@Schema(description = "determines whether the profile should be exposed to the user")
	private Boolean profileLabelExposed;
}
