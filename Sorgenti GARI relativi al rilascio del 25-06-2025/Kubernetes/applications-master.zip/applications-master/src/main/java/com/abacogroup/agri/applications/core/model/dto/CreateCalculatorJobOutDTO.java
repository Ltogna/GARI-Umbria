package com.abacogroup.agri.applications.core.model.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author Alexandru Paraschiv
 */
@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
public class CreateCalculatorJobOutDTO {

	private String uuid;
}
