package com.abacogroup.agri.applications.db.dao;

import com.abacogroup.agri.applications.db.ntt.ApplicationsRelationNTT;
import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.customizer.BindBean;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;

import java.time.LocalDateTime;
import java.util.List;

/**
 * @author Mattia Perini
 */
public interface ApplicationsRelationsDAO extends IGenericHistoricizationFieldsDAO<ApplicationsRelationNTT, Long, Void> {

	@Override
	@SqlQuery("§select_nextval(apps_applications_relations_seq_id)§")
	Long nextSequenceVal();

	@Override
	@SqlUpdate("INSERT INTO apps_applications_relations " +
			" (pkid, " +
			" parent_application_id, " +
			" child_application_id, " +
			" dt_insert, " +
			" dt_delete, " +
			" user_id_insert, " +
			" user_id_delete) " +
			" VALUES(:pkid, :parent_application_id, :child_application_id, :current_timestamp, " +
			"       TO_TIMESTAMP('9999-12-3123:59:59','YYYY-MM-DDHH24:MI:SS'), :user_id, NULL)")
	void insert(@BindBean ApplicationsRelationNTT rs, @Bind("user_id") String userId, @Bind("current_timestamp") LocalDateTime currentTimestamp);

	@Override
	@SqlQuery("SELECT pkid, " +
			" parent_application_id, " +
			" child_application_id, " +
			" dt_insert, " +
			" dt_delete, " +
			" user_id_insert, " +
			" user_id_delete " +
			" FROM apps_applications_relations " +
			" WHERE pkid = :id")
	@RegisterBeanMapper(ApplicationsRelationNTT.class)
	List<ApplicationsRelationNTT> findById(@Bind("id") Long id);

	@SqlQuery("SELECT pkid, " +
			" parent_application_id, " +
			" child_application_id, " +
			" dt_insert, " +
			" dt_delete, " +
			" user_id_insert, " +
			" user_id_delete " +
			" FROM apps_applications_relations " +
			" WHERE parent_application_id = :parent_application_id " +
			" AND child_application_id = :child_application_id " +
			" AND §current_timestamp§ BETWEEN dt_insert AND dt_delete ")
	@RegisterBeanMapper(ApplicationsRelationNTT.class)
	List<ApplicationsRelationNTT> findByParentApplicationIdAndChildApplicationId(@Bind("parent_application_id") Long parentApplicationId,
																				 @Bind("child_application_id") Long childApplicationId);

	@SqlQuery("SELECT pkid, " +
			" parent_application_id, " +
			" child_application_id, " +
			" dt_insert, " +
			" dt_delete, " +
			" user_id_insert, " +
			" user_id_delete " +
			" FROM apps_applications_relations " +
			" WHERE parent_application_id = :parent_application_id " +
			" AND §current_timestamp§ BETWEEN dt_insert AND dt_delete")
	@RegisterBeanMapper(ApplicationsRelationNTT.class)
	List<ApplicationsRelationNTT> findByParentApplicationId(@Bind("parent_application_id") Long parentApplicationId);

	@SqlQuery("SELECT aar.pkid, " +
			" aar.parent_application_id, " +
			" aar.child_application_id, " +
			" aar.dt_insert, " +
			" aar.dt_delete, " +
			" aar.user_id_insert, " +
			" aar.user_id_delete " +
			" FROM apps_applications_relations aar " +
			" JOIN apps_applications aa ON aa.id = aar.child_application_id " +
			" JOIN apps_modules am ON am.id = aa.module_id " +
			" WHERE aar.parent_application_id = :parent_application_id " +
			" AND am.module_code = :module_code " +
			" AND §current_timestamp§ between aar.dt_insert AND aar.dt_delete " +
			" AND §current_timestamp§ between aa.dt_insert AND aa.dt_delete " +
			" AND §current_timestamp§ between am.dt_insert AND am.dt_delete")
	@RegisterBeanMapper(ApplicationsRelationNTT.class)
	List<ApplicationsRelationNTT> findByParentApplicationIdAndModuleCode(@Bind("parent_application_id") Long parentApplicationId,
																		 @Bind("module_code") String moduleCode);

	@SqlQuery("SELECT pkid, " +
			" parent_application_id, " +
			" child_application_id, " +
			" dt_insert, " +
			" dt_delete, " +
			" user_id_insert, " +
			" user_id_delete " +
			" FROM apps_applications_relations " +
			" WHERE child_application_id = :child_application_id " +
			" AND §current_timestamp§ BETWEEN dt_insert AND dt_delete")
	@RegisterBeanMapper(ApplicationsRelationNTT.class)
	List<ApplicationsRelationNTT> findByChildApplicationId(@Bind("child_application_id") Long childApplicationId);

	@Override
	@SqlUpdate("UPDATE apps_applications_relations SET " +
			" user_id_delete = :user_id_delete, dt_delete = :current_timestamp " +
			" WHERE pkid = :id " +
			" AND §current_timestamp§ BETWEEN dt_insert AND dt_delete")
	void logicallyDeleteById(@Bind("id") Long id, @Bind("user_id_delete") String userDelete, @Bind("current_timestamp") LocalDateTime currentTimestamp);
}
