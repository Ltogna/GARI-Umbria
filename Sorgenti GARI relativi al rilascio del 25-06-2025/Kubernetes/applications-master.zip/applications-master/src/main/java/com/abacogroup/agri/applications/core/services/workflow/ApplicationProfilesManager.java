package com.abacogroup.agri.applications.core.services.workflow;

import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

import com.abacogroup.agri.applications.core.exceptions.ObjectNotFoundException;
import com.abacogroup.agri.applications.core.model.dto.ApplicationProfileDTO;
import com.abacogroup.agri.applications.core.services.crud.ApplicationProfilesCrudService;
import com.abacogroup.agri.applications.core.services.crud.ApplicationsCrudService;
import com.abacogroup.workflow.sdk.profiles.ProfilesManager;
import com.abacogroup.workflow.server.services.timer.TimerQueueJob;
import com.github.benmanes.caffeine.cache.Caffeine;
import com.github.benmanes.caffeine.cache.LoadingCache;

/**
 * @author Gennaro Tamburrelli
 */
public class ApplicationProfilesManager implements ProfilesManager {

	private LoadingCache<ProfileCacheKey, List<String>> applicationProfilesCache;
	private String tenant;
	private Long applicationId;

	private ApplicationProfilesCrudService applicationProfilesCrudService;

	public ApplicationProfilesManager(String tenant, Long applicationId, ApplicationProfilesCrudService applicationProfilesCrudService) {
		init(tenant, applicationId, applicationProfilesCrudService);
	}

	public ApplicationProfilesManager(TimerQueueJob job, ApplicationsCrudService applicationsCrudService,
			ApplicationProfilesCrudService applicationProfilesCrudService) {
		try {
			var app = applicationsCrudService.findByProcessId(job.getProcessId());
			init(job.getTenantId(), app.getApplicationId(), applicationProfilesCrudService);
		} catch (ObjectNotFoundException e) {
			throw new IllegalArgumentException("No applications found for the supplied job: " + job, e);
		}
	}

	private void init(String tenant, Long applicationId, ApplicationProfilesCrudService applicationProfilesCrudService) {
		this.tenant = tenant;
		this.applicationId = applicationId;
		this.applicationProfilesCrudService = applicationProfilesCrudService;
		this.applicationProfilesCache = Caffeine.newBuilder()
				.build(key -> this.getAllProfiles(key.getTenant(), key.getApplicationId()));
	}

	private List<String> createList(String... strings) {
		return Arrays.asList(strings);
	}

	private ProfileCacheKey createKey() {
		return ProfileCacheKey.builder()
				.tenant(this.tenant)
				.applicationId(this.applicationId)
				.build();
	}

	@Override
	public boolean haveAnyOf(String... strings) {
		List<String> anyOf = this.createList(strings);
		return Objects.requireNonNull(this.applicationProfilesCache.get(this.createKey()))
				.stream()
				.anyMatch(anyOf::contains);
	}

	@Override
	public boolean haveAllOf(String... strings) {
		List<String> allOf = this.createList(strings);

		return Objects.requireNonNull(this.applicationProfilesCache.get(this.createKey())).containsAll(allOf);
	}

	public List<String> getAllProfiles(String tenant, Long applicationId) {
		return applicationProfilesCrudService.find(tenant, applicationId)
				.stream()
				.map(ApplicationProfileDTO::getProfileCode)
				.collect(Collectors.toList());
	}

}
