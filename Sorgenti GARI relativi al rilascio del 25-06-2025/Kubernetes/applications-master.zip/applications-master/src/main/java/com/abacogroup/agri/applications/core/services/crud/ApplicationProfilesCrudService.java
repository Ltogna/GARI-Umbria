package com.abacogroup.agri.applications.core.services.crud;

import com.abacogroup.agri.applications.core.exceptions.ObjectNotFoundException;
import com.abacogroup.agri.applications.core.mappers.ApplicationProfileMapper;
import com.abacogroup.agri.applications.core.services.I18NService;
import com.abacogroup.agri.applications.db.dao.ApplicationProfileDAO;
import com.abacogroup.agri.applications.db.ntt.ApplicationProfileNTT;
import com.abacogroup.agri.applications.core.model.dto.ApplicationProfileDTO;
import com.abacogroup.jaxrsutils.filter.MDCPreFilter;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.MDC;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import static com.abacogroup.agri.applications.utils.PagingParamsFactory.DEFAULT_PAGE_SIZE;

/**
 * @author Gennaro Tamburrelli
 */
@Slf4j
public class ApplicationProfilesCrudService
		extends AbstractHistoricizationFieldsCrudService<ApplicationProfileNTT, Long, ApplicationProfileDTO, ApplicationProfileMapper, Void> {

	public static final String I18N_APPLICATION_PROFILES_TABLE = "apps_application_profiles";
	private final I18NService i18NService;

	public ApplicationProfilesCrudService(ApplicationProfileDAO dao, ApplicationProfileMapper mapper,
			I18NService i18NService) {
		super(dao, mapper);
		this.i18NService = i18NService;
	}

	@Override protected boolean hasPrimaryKey() {
		return true;
	}

	@Override protected Void retrieveCustomKeyByResultSet(ApplicationProfileNTT rs) {
		return null;
	}

	@Override protected ApplicationProfileNTT adjustR(ApplicationProfileNTT rs) throws Exception {
		return rs;
	}

	@Override protected Optional<ApplicationProfileNTT> findRsByCustomKey(Void customKey) {
		return Optional.empty();
	}

	public ApplicationProfileDTO insert(ApplicationProfileDTO in, String username) {
		log.info("Invoking insert with params in: {} username: {}", in, username);
		return this.insert(in, username, null, this.dao.getCurrentTimestamp());
	}

	public ApplicationProfileDTO update(Long key, ApplicationProfileDTO in, String username) {
		log.info("Invoking update with params key: {} in: {} username: {}", key, in, username);
		return this.update(key, in, username, null);
	}

	public void delete(Long key, String username) {
		log.info("Invoking delete with params key: {} username: {}", key, username);
		this.delete(key, username, null);
	}

	public void insertModuleI18N(String tenant, String code, String lang, String description) {
		this.i18NService.insertI18N(tenant, I18N_APPLICATION_PROFILES_TABLE, APPLICATION_PROFILES_I18N.DESCRIPTION.code, lang, code, description);
	}

	public ApplicationProfileDTO findById(Long id) throws ObjectNotFoundException {
		log.info("Invoking find by  with params key: {}", id);
		return this.findOutDtoByPrimaryKey(id);
	}

	public void bulkLogicallyDeleteByApplicationCode(String tenant, String applicationCode, String username) {
		log.info("Invoking bulk delete with params tenant: {} applicationCode: {} username: {}", tenant, applicationCode, username);
		((ApplicationProfileDAO) this.dao).bulkLogicallyDeleteByApplicationCode(tenant, applicationCode, username);
	}

	public void bulkLogicallyDeleteByApplicationId(String tenant, Long applicationId, String username) {
		log.info("Invoking bulk delete with params tenant: {} applicationId: {} username: {}", tenant, applicationId, username);
		((ApplicationProfileDAO) this.dao).bulkLogicallyDeleteByApplicationId(tenant, applicationId, username);
	}

	public enum APPLICATION_PROFILES_I18N {
		DESCRIPTION("description");

		private final String code;

		APPLICATION_PROFILES_I18N(String val) {
			this.code = val;
		}

		public String getCode() {
			return this.code;
		}
	}

	/**
	 * get all profiles by application code
	 *
	 * @param tenant          current tenant
	 * @param applicationCode the application's code
	 * @return the profiles list
	 */
	public List<ApplicationProfileDTO> find(String tenant, String applicationCode) {
		log.info("Invoking findCategoryByTenantAndCode with params tenant: {} applicationCode: {}", tenant, applicationCode);
		return returnMappedList(((ApplicationProfileDAO) this.dao).find(tenant, applicationCode, MDC.get(MDCPreFilter.LOCALE)));
	}

	public Optional<ApplicationProfileDTO> findByUnique(String tenant, Long applicationId, String profileCode) {
		return returnOptionalRecord(((ApplicationProfileDAO) this.dao).findByUnique(tenant, applicationId, profileCode));
	}

	/**
	 * get all profiles by application id
	 *
	 * @param tenant        current tenant
	 * @param applicationId the application's id
	 * @return the profiles list
	 */
	public List<ApplicationProfileDTO> find(String tenant, Long applicationId) {
		log.info("Invoking findCategoryByTenantAndCode with params tenant: {} applicationId: {}", tenant, applicationId);
		return returnMappedList(((ApplicationProfileDAO) this.dao).find(tenant, applicationId));
	}

	/**
	 * get all profiles by application id
	 *
	 * @param tenant        current tenant
	 * @param applicationId the application's id
	 * @param locale        the locale
	 * @return the profiles list
	 */
	public List<ApplicationProfileDTO> findAll(String tenant, Long applicationId, String locale) {
		log.info("Invoking findCategoryByTenantAndCode with params tenant: {} applicationId: {}", tenant, applicationId);
		return returnMappedList(((ApplicationProfileDAO) this.dao).find(tenant, applicationId, locale));
	}

	/**
	 * get profiles by application code
	 *
	 * @param tenant          current tenant
	 * @param applicationCode the application's code
	 * @param nextKey         the nextKey
	 * @return the profiles list
	 */
	public InfiniteListResults<ApplicationProfileDTO> find(String tenant, String applicationCode, String nextKey) {
		log.info("Invoking find with params tenant: {} applicationCode: {}", tenant, applicationCode);
		return returnInfiniteResults(
				this.dao.infinite(() -> ((ApplicationProfileDAO) this.dao).findInfinite(tenant, applicationCode, MDC.get(MDCPreFilter.LOCALE)),
						nextKey,
						DEFAULT_PAGE_SIZE
				),
				mapper::entityToDto);
	}

	/**
	 * get profiles by application id
	 *
	 * @param tenant        current tenant
	 * @param applicationId the application's id
	 * @param nextKey       the nextKey
	 * @return the profiles list
	 */
	public InfiniteListResults<ApplicationProfileDTO> find(String tenant, Long applicationId, LocalDateTime dateTime, String nextKey) {
		log.info("Invoking find with params tenant: {} applicationId: {} dateTime: {}", tenant, applicationId, dateTime);

		LocalDateTime timestamp;
		if (dateTime == null) {
			timestamp = this.dao.getCurrentTimestamp();
		} else {
			timestamp = dateTime;
		}

		return returnInfiniteResults(
				this.dao.infinite(() -> ((ApplicationProfileDAO) this.dao).findInfinite(tenant, applicationId, timestamp, MDC.get(MDCPreFilter.LOCALE)),
						nextKey,
						DEFAULT_PAGE_SIZE
				),
				mapper::entityToDto);
	}
}
