package com.abacogroup.agri.applications.core.caller;

import java.util.Collections;
import java.util.Map;

import jakarta.validation.constraints.NotNull;

import com.abacogroup.applicationsupport.model.io.callerinput.companyfile.BaseCompanyFileInput;
import com.abacogroup.jaxrsutils.callerv2.ICallerInput;

/**
 * @author Gennaro Tamburrelli
 */
public class GetPartyRegistryByPartyIdInput extends BaseCompanyFileInput implements ICallerInput {

	private final String resourceUrl;

	public GetPartyRegistryByPartyIdInput(@NotNull String tenant, @NotNull Long partyId, @NotNull String authToken,
			@NotNull String partyRegistryUrl, @NotNull String resourceUrl) {
		super(tenant, partyId, authToken, partyRegistryUrl);
		this.resourceUrl = resourceUrl;
	}

	@Override
	public Map<String, Object> getPathVariablesMap() {
		return Map.of("tenant", this.tenant,
				"partyId", this.partyId);
	}

	@Override
	public String provideAuthToken() {
		return this.authToken;
	}

	@Override
	public Map<String, Object> getQueryParamsMap() {
		return Collections.emptyMap();
	}

	@Override
	public String getUrl() {
		return this.avepaLegacyBaseUrl + resourceUrl;
	}

	@Override
	public String getHttpMethod() {
		return "GET";
	}

}
