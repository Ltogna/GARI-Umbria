package com.abacogroup.agri.applications.core.mappers;

import com.abacogroup.agri.applications.core.model.dto.ModulePrintConfigsDTO;
import com.abacogroup.agri.applications.core.model.dto.publics.PrintDetailsOutDTO;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

@Mapper
public interface PrintDetailsOutMapper {
	PrintDetailsOutMapper INSTANCE = Mappers.getMapper(PrintDetailsOutMapper.class);

	@Mapping(source = "id", target = "printConfigId")
	@Mapping(source = "printCode", target = "printCode")
	@Mapping(source = "printDescription", target = "printDescription")
	@Mapping(source = "sortOrder", target = "sortOrder")
	PrintDetailsOutDTO toPublicDTO(ModulePrintConfigsDTO dto);
}
