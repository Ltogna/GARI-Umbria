package com.abacogroup.agri.applications.core.services.workflow;

import java.security.Principal;

import com.abacogroup.dropwizard.auth.sso2.Sso2Client;
import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.dropwizard.auth.sso2.UserFunction;
import com.abacogroup.workflow.sdk.auth.AuthContext;
import com.auth0.jwt.JWT;
import com.auth0.jwt.interfaces.DecodedJWT;

import io.dropwizard.auth.AuthenticationException;
import jakarta.ws.rs.client.Client;
import jakarta.ws.rs.client.ClientRequestFilter;
import jakarta.ws.rs.client.WebTarget;
import jakarta.ws.rs.core.SecurityContext;
import lombok.extern.slf4j.Slf4j;

/**
 * @author Gennaro Tamburrelli
 */
@Slf4j
public class AuthContextFactory {

	private final Sso2Client sso2Client;

	public AuthContextFactory(Sso2Client sso2Client) {
		this.sso2Client = sso2Client;
	}

	public AuthContext createAuthContext(User user, String locale) throws AuthenticationException {
		return new MyAuthContext(user, locale);
	}

	private class MyAuthContext implements AuthContext {

		private User user;
		private String locale;
		private DecodedJWT jwt = null;

		public MyAuthContext(User user, String locale) {
			this.user = user;
			this.locale = locale;

			if (user.getAuthToken() != null && !user.getAuthToken().isBlank())
				jwt = JWT.decode(user.getAuthToken());
		}

		@Override
		public synchronized String getUserId() {
			return user.getUserId();
		}

		@Override
		public synchronized Principal getPrincipal() {
			// renew token because someone use this method to get auth token
			if (jwt != null && jwt.getExpiresAt().getTime() < System.currentTimeMillis() + 5 * 60_000L) {
				try {
					user = (User) sso2Client.createSecurityContextFromUserId(user.getTenant(), user.getUserId()).getUserPrincipal();
					jwt = JWT.decode(user.getAuthToken());
				} catch (AuthenticationException e) {
					log.error(e.getMessage(), e);
				}
			}
			return user;
		}

		@Override
		public String getLocaleCode() {
			return locale;
		}

		@Override
		public boolean isFunctionEnabled(String context, String function) {
			return sso2Client.isFunctionEnabled(user, new UserFunction(context, function));
		}

		@Override
		public WebTarget getAuthenticatedWebTarget(Client client, String url) {
			// used ((User) getPrincipal()).getAuthToken() to ensure token is not expired
			return client.target(url).register(
					(ClientRequestFilter) requestContext -> requestContext.getHeaders().add("Authorization", "JWT " + ((User) getPrincipal()).getAuthToken()));
		}
	}

	public AuthContext createAuthContext(String tenant, String usernameOrId, String locale) throws AuthenticationException {
		SecurityContext sc;
		try {
			sc = sso2Client.createSecurityContextFromUserName(tenant, usernameOrId);
		} catch (Exception e) {
			sc = sso2Client.createSecurityContextFromUserId(tenant, usernameOrId);
		}
		User user = (User) sc.getUserPrincipal();
		return createAuthContext(user, locale);
	}

	public AuthContext createAuthContextByUsername(String tenant, String username, String locale) throws AuthenticationException {
		SecurityContext sc = sso2Client.createSecurityContextFromUserName(tenant, username);
		User user = (User) sc.getUserPrincipal();
		return createAuthContext(user, locale);
	}

	public AuthContext createAuthContextByUserid(String tenant, String userid, String locale) throws AuthenticationException {
		SecurityContext sc = sso2Client.createSecurityContextFromUserId(tenant, userid);
		User user = (User) sc.getUserPrincipal();
		return createAuthContext(user, locale);
	}

}
