package com.abacogroup.agri.applications.bundles.model.env;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.List;

/**
 * The type Bundle application env message.
 * @author Carlo Sindico
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class BundleApplicationEnvMessage {

    @Builder.Default
    private List<BundleApplicationEnvInDTO> bundleApplicationEnvInDTOList = new ArrayList<>();
}
