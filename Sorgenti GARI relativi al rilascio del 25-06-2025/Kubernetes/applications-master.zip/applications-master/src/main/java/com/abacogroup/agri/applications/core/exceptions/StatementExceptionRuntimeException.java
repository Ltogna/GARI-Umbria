package com.abacogroup.agri.applications.core.exceptions;

import io.swagger.v3.oas.annotations.media.Schema;

import jakarta.ws.rs.core.Response;

public class StatementExceptionRuntimeException extends AbstractException {

	private static final StatementExceptionRuntimeException.ErrorBody BODY = new StatementExceptionRuntimeException.ErrorBody();

	public StatementExceptionRuntimeException(String message) {
		super(Response.Status.INTERNAL_SERVER_ERROR, BODY, message);
	}

	public StatementExceptionRuntimeException() {
		super(Response.Status.INTERNAL_SERVER_ERROR, BODY, "generic error");
	}

	@Schema(name = "StatementExceptionRuntimeExceptionErrorBody")
	public static class ErrorBody implements ExceptionErrorBody {
		private static final String ERR = "STATEMENT_ERROR";

		@Override
		@Schema(allowableValues = ERR)
		public String getErrorCode() {
			return ERR;
		}
	}
}
