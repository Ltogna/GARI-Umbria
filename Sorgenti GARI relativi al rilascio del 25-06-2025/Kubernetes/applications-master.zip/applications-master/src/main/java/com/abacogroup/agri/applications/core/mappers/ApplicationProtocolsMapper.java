package com.abacogroup.agri.applications.core.mappers;

import com.abacogroup.agri.applications.core.model.dto.publics.ApplicationProtocolsDTO;
import com.abacogroup.agri.applications.db.ntt.ApplicationProtocolsNTT;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

@Mapper(uses = AbsoluteDateMapper.class)
public interface ApplicationProtocolsMapper extends EntityMapper<ApplicationProtocolsDTO, ApplicationProtocolsNTT> {

	ApplicationProtocolsMapper INSTANCE = Mappers.getMapper(ApplicationProtocolsMapper.class);

	@InheritInverseConfiguration()
	ApplicationProtocolsDTO entityToDto(ApplicationProtocolsNTT entity);

	@Mapping(source = "pkid", target = "pkid")
	@Mapping(source = "applicationId", target = "application_id")
	@Mapping(source = "dtRequest", target = "dt_request")
	@Mapping(source = "dtResponse", target = "dt_response")
	@Mapping(source = "protocol", target = "protocol")
	ApplicationProtocolsNTT dtoToEntity(ApplicationProtocolsDTO dto);

}
