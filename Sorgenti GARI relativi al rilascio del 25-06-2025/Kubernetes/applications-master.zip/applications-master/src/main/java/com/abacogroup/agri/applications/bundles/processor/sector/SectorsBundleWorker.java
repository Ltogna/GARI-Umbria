package com.abacogroup.agri.applications.bundles.processor.sector;

import com.abacogroup.agri.applications.bundles.model.sector.BundleSectorsMessage;
import com.abacogroup.agri.applications.core.exceptions.ObjectNotFoundException;
import com.abacogroup.agri.applications.core.model.dto.SectorDTO;
import com.abacogroup.agri.applications.core.services.crud.SectorsCrudService;
import lombok.extern.slf4j.Slf4j;

/**
 * @author Alexandru Paraschiv
 */
@Slf4j
public class SectorsBundleWorker {

	protected final SectorsCrudService sectorsCrudService;

	public SectorsBundleWorker(SectorsCrudService sectorsCrudService) {
		this.sectorsCrudService = sectorsCrudService;
	}

	public SectorsCrudService exposeSectorsCrudService() {
		return this.sectorsCrudService;
	}

	public void upsertBundleSectors(String tenantId, BundleSectorsMessage message) {
		log.info("SectorsBundleWorker: processing file with tenant {}", tenantId);
		message.getSectors()
				.stream()
				.forEachOrdered(sector -> {
					try {
						log.info("sector already existing: skipping insert");
						var existingSector = sectorsCrudService.findSectorByCode(tenantId, sector.getSectorCode());
						log.info("deleting i18n");
						sector.getI18n().stream().forEachOrdered(x -> {
							sectorsCrudService.deleteModuleI18N(tenantId, existingSector.getSectorCode(), x.getLang());
						});
						log.info("deleted i18n");
					} catch (ObjectNotFoundException e) {
						log.info("SectorsBundleWorker: inserting type with tenant {} and code {}", tenantId, sector.getSectorCode());
						sectorsCrudService.insert(SectorDTO.builder()
								.sectorCode(sector.getSectorCode())
								.tenantId(tenantId)
								.build());
					}
					log.info("SectorsBundleWorker: inserting i18n with tenant {} and code {}", tenantId, sector.getSectorCode());
					sector.getI18n()
							.stream()
							.forEachOrdered(val -> sectorsCrudService.insertSectorI18N(tenantId,
									sector.getSectorCode(),
									val.getLang(),
									val.getDescription()));
				});
	}

	public void deleteBundleSectors(String tenantId, BundleSectorsMessage message) {
		log.info("SectorsBundleWorker: processing delete file with tenant {}", tenantId);
		message.getSectors()
				.stream()
				.forEachOrdered(sector -> {
					try {
						var existingSector = sectorsCrudService.findSectorByCode(tenantId, sector.getSectorCode());
						log.info("deleting sector {}", existingSector.getSectorCode());
						sectorsCrudService.delete(existingSector.getSectorId());
						log.info("deleted sector");
						log.info("deleting i18n");
						sector.getI18n().stream().forEachOrdered(x -> {
							sectorsCrudService.deleteModuleI18N(tenantId, existingSector.getSectorCode(), x.getLang());
						});
						log.info("deleted i18n");
					} catch (ObjectNotFoundException e) {
						log.info("secort not found: cannot be deleted");
					}
				});
	}
}
