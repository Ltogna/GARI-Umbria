package com.abacogroup.agri.applications.core.model.dto.publics;

import com.abacogroup.applicationworkflowsdk.model.DetailedSdkTransitionLog;
import com.abacogroup.workflow.server.model.DetailedTransitionLog;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author Gennaro Tamburrelli
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ApplicationInTransitionDTO {
	private Boolean inTransition;
	private DetailedSdkTransitionLog lastTransitionLog;
}
