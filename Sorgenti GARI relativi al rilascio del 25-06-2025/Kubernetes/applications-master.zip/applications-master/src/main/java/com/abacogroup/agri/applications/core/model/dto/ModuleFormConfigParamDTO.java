package com.abacogroup.agri.applications.core.model.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

/**
 * @author Gennaro Tamburrelli
 */
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class ModuleFormConfigParamDTO {
	private Long moduleFormConfigId;
	private String parameterName;
	private String parameterValue;

}
