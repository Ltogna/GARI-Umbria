package com.abacogroup.agri.applications.core.model;

/**
 * @author Gennaro Tamburrelli
 */
public enum ProgressTypeEnum {

	SYNC,
	ASYNC;
}
