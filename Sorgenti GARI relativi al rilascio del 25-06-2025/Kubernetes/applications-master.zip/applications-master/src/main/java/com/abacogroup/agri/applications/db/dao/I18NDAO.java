package com.abacogroup.agri.applications.db.dao;

import com.abacogroup.agri.applications.db.ntt.applications.RsI18N;
import com.abacogroup.jdbi.EnhancedSqlObject;
import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;
import org.jdbi.v3.sqlobject.transaction.Transactional;

import java.util.List;

/**
 * @author Gennaro Tamburrelli
 */
public interface I18NDAO extends EnhancedSqlObject, Transactional<I18NDAO> {

	@SqlUpdate("INSERT INTO APPS_I18N_VALUES " +
			"(TENANT_ID, TABLE_NAME, FIELD_NAME, I18N_VALUE, LANG, I18N_TEXT) " +
			"VALUES(:tenant, :table, :field_name, :type_code, :lang, :i18n_text)")
	void insertI18N(@Bind("tenant") String tenant, @Bind("table") String table, @Bind("field_name") String fieldName,
			@Bind("type_code") String typeCode, @Bind("lang") String lang, @Bind("i18n_text") String i18ntext);

	@SqlQuery("select i18n_text " +
			"from (§i18n(:tenant, :table, :field_name, :type_code, :lang)§) ")
	@RegisterBeanMapper(RsI18N.class)
	List<RsI18N> getI18NByLang(@Bind("tenant") String tenant, @Bind("table") String table, @Bind("field_name") String fieldName,
			@Bind("type_code") String typeCode, @Bind("lang") String lang);

	@SqlQuery("SELECT TENANT_ID, TABLE_NAME, FIELD_NAME, I18N_VALUE, LANG, I18N_TEXT " +
			"  FROM APPS_I18N_VALUES " +
			"  WHERE tenant_id = :tenant " +
			"  AND table_name =:table" +
			"  AND field_name =:field_name" +
			"  AND i18n_value =:type_code" +
			"  AND lang =:lang" +
			"  AND i18n_text =:i18n_text")
	@RegisterBeanMapper(RsI18N.class)
	List<RsI18N> getI18NByAllFields(@Bind("tenant") String tenant, @Bind("table") String table, @Bind("field_name") String fieldName,
			@Bind("type_code") String typeCode, @Bind("lang") String lang, @Bind("i18n_text") String text);

	@SqlQuery("select * " +
			"from APPS_I18N_VALUES " +
			"where tenant_id=:tenant " +
			"and table_name=:table " +
			"and i18n_value=:type_code")
	@RegisterBeanMapper(RsI18N.class)
	List<RsI18N> getAllI18N(@Bind("tenant") String tenant, @Bind("table") String table, @Bind("type_code") String typeCode);

	@SqlUpdate("delete from APPS_I18N_VALUES  " +
			"  where tenant_id = :tenant " +
			"  and table_name = :table " +
			"  and field_name = :field_name " +
			"  and i18n_value = :type_code " +
			"  and lang = :lang ")
	void deleteI18N(@Bind("tenant") String tenant, @Bind("table") String table, @Bind("field_name") String fieldName,
			@Bind("type_code") String typeCode, @Bind("lang") String lang);
}
