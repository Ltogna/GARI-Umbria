package com.abacogroup.agri.applications.core.services.crud;

import com.abacogroup.agri.applications.core.exceptions.ObjectNotFoundException;
import com.abacogroup.agri.applications.core.mappers.SectorMapper;
import com.abacogroup.agri.applications.core.model.dto.SectorDTO;
import com.abacogroup.agri.applications.core.services.I18NService;
import com.abacogroup.agri.applications.db.dao.SectorDAO;
import com.abacogroup.agri.applications.db.ntt.SectorNTT;
import com.abacogroup.agri.applications.db.ntt.applications.RsI18N;
import com.abacogroup.jaxrsutils.filter.MDCPreFilter;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.NotImplementedException;
import org.slf4j.MDC;

import java.util.List;
import java.util.Optional;

import static com.abacogroup.agri.applications.utils.PagingParamsFactory.DEFAULT_PAGE_SIZE;

/**
 * @author Mauro Pozzana
 */
@Slf4j
public class SectorsCrudService extends AbstractCrudService<SectorNTT, Long, SectorDTO, SectorMapper, Long> {

	public static final String I18N_SECTORS_TABLE = "apps_sectors";

	private final I18NService i18NService;

	public SectorsCrudService(SectorDAO dao, SectorMapper mapper, I18NService i18NService) {
		super(dao, mapper);
		this.i18NService = i18NService;
	}

	public List<SectorDTO> findAllSectors(String tenantId) {
		return returnMappedList(((SectorDAO) this.dao).findAllSectors(tenantId));
	}

	public InfiniteListResults<SectorDTO> findInfiniteAllSectors(String tenantId, String nextKey) {
		return returnInfiniteResults(this.dao.infinite(() -> ((SectorDAO) this.dao).findInfiniteAllSectors(tenantId, MDC.get(MDCPreFilter.LOCALE)),
				nextKey,
				DEFAULT_PAGE_SIZE));
	}

	@Override
	protected boolean hasPrimaryKey() {
		return true;
	}

	@Override
	protected Optional<SectorNTT> findRsByCustomKey(Long customKey) {
		return Optional.empty();
	}

	@Override
	protected void deleteByCustomKey(Long customKey) {
		throw new NotImplementedException("Not implemented.");
	}

	@Override
	protected void setCustomSearchKey(SectorNTT rs, Long customKey) {
		throw new NotImplementedException("Not implemented.");
	}

	public SectorDTO insert(SectorDTO in) {
		log.info("Invoking insert with params in: {}", in);
		return this.insert(in, null);
	}

	public SectorDTO update(Long key, SectorDTO in) {
		log.info("Invoking update with params key: {} in: {}", key, in);
		return this.update(key, in, null);
	}

	public void delete(Long key) {
		log.info("Invoking delete with params key: {}", key);
		this.delete(key, null);
	}

	public SectorDTO findById(String tenant, Long id) throws ObjectNotFoundException {
		log.info("Invoking findById with params tenant: {} id: {}", tenant, id);
		return returnOptionalRecord(((SectorDAO) this.dao).findById(tenant, id))
				.orElseThrow(OBJECT_NOT_FOUND_EXCEPTION_SUPPLIER);
	}

	public SectorDTO findSectorByCode(String tenant, String sectorCode) throws ObjectNotFoundException {
		log.info("Invoking findSectorByCode with params tenant: {} sectorCode: {}", tenant, sectorCode);
		return returnOptionalRecord(((SectorDAO) this.dao).findByCode(tenant, sectorCode))
				.orElseThrow(OBJECT_NOT_FOUND_EXCEPTION_SUPPLIER);
	}

	public void insertSectorI18N(String tenant, String code, String lang, String description) {
		this.i18NService.insertI18N(tenant, I18N_SECTORS_TABLE, SECTOR_I18N.SECTOR_CODE.code, lang, code, description);
	}

	public void deleteModuleI18N(String tenant, String code, String lang) {
		this.i18NService.deleteI18N(tenant, I18N_SECTORS_TABLE, SECTOR_I18N.SECTOR_CODE.code, code, lang);
	}

	public List<RsI18N> getAllSectorI18NByTenantAndCode(String tenant, String code) {
		return this.i18NService.getAllI18NbyCode(tenant, I18N_SECTORS_TABLE, code);
	}

	public String findTenantByModuleId(Long moduleId) {
		return ((SectorDAO) this.dao).findTenantByModuleId(moduleId);
	}

	public enum SECTOR_I18N {
		SECTOR_CODE("sector_code");

		private final String code;

		SECTOR_I18N(String val) {
			this.code = val;
		}

		public String getCode() {
			return this.code;
		}
	}
}
