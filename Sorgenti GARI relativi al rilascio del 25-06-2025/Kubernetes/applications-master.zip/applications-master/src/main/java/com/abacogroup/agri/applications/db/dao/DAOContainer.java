package com.abacogroup.agri.applications.db.dao;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class DAOContainer {
	private I18NDAO i18NDAO;
	private SectorDAO sectorDAO;
	private ModuleDAO moduleDAO;
	private ModuleDetailsDAO moduleDetailsDAO;
	private ApplicationDetailsDAO applicationDetailsDAO;
	private ApplicationDAO applicationDAO;
	private FormCatalogDAO formCatalogDAO;
	private ModuleFormConfigsDAO moduleFormConfigsDAO;
	private FormGroupDAO formGroupDAO;
	private ModuleFormConfigParamDAO moduleFormConfigParamDAO;
	private ApplicationProfileDAO applicationProfileDAO;
	private ModuleFormConfigProfileDAO moduleFormConfigProfileDAO;
	private ModuleProfileDAO moduleProfilesDAO;
	private ApplicationCompileStatusDAO applicationCompileStatusDAO;
	private AnomalyDAO anomalyDAO;
	private AnomalyCatalogDAO anomalyCatalogDAO;
	private ModulePrintConfigsDAO modulePrintConfigsDAO;
	private ModulePrintConfigParamDAO modulePrintConfigParamDAO;
	private ModulePrintConfigProfileDAO modulePrintConfigProfileDAO;
	private ApplicationGeneratedPrintDAO applicationGeneratedPrintDAO;
	private ApplicationGeneratedCalculationDAO applicationGeneratedCalculationDAO;
	private ApplicationEnvDAO applicationEnvDAO;
	private ApplicationProtocolsDAO applicationProtocolsDAO;
	private AmendableModuleDAO amendableModuleDAO;
	private ChildrenModulesDAO childrenModulesDAO;
	private ModuleCalculationConfigsDAO moduleCalculationConfigsDAO;
	private ModuleCalculationConfigParamDAO moduleCalculationConfigParamDAO;
	private ModuleCalculationConfigProfileDAO moduleCalculationConfigProfileDAO;
	private ApplicationsRelationsDAO applicationsRelationsDAO;
}
