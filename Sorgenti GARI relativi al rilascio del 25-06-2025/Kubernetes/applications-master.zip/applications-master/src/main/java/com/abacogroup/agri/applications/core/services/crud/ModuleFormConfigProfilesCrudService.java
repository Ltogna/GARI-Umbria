package com.abacogroup.agri.applications.core.services.crud;

import com.abacogroup.agri.applications.core.exceptions.ObjectNotFoundException;
import com.abacogroup.agri.applications.core.mappers.ModuleFormConfigProfileMapper;
import com.abacogroup.agri.applications.core.model.dto.ModuleFormConfigProfileDTO;
import com.abacogroup.agri.applications.db.dao.ModuleFormConfigProfileDAO;
import com.abacogroup.agri.applications.db.ntt.ModuleFormConfigProfileNTT;
import com.abacogroup.agri.applications.db.ntt.compoundkeys.FormConfigProfileKey;
import lombok.extern.slf4j.Slf4j;

import java.util.List;
import java.util.Optional;

/**
 * @author Alexandru Paraschiv
 */
@Slf4j
public class ModuleFormConfigProfilesCrudService
		extends AbstractCrudService<ModuleFormConfigProfileNTT, Void, ModuleFormConfigProfileDTO, ModuleFormConfigProfileMapper, FormConfigProfileKey> {

	public ModuleFormConfigProfilesCrudService(ModuleFormConfigProfileDAO dao, ModuleFormConfigProfileMapper mapper) {
		super(dao, mapper);
	}

	@Override
	protected boolean hasPrimaryKey() {
		return false;
	}

	@Override
	protected Void retrievePrimaryKey(FormConfigProfileKey customKey) {
		return null;
	}

	@Override
	protected Optional<ModuleFormConfigProfileNTT> findRsByCustomKey(FormConfigProfileKey customKey) {
		return ((ModuleFormConfigProfileDAO) this.dao).findById(customKey.getModule_form_config_id(), customKey.getRequired_profile_code())
				.stream()
				.findFirst();
	}

	@Override
	protected void deleteByCustomKey(FormConfigProfileKey customKey) {
		((ModuleFormConfigProfileDAO) this.dao).deleteById(customKey.getModule_form_config_id(), customKey.getRequired_profile_code());
	}

	@Override
	protected void setCustomSearchKey(ModuleFormConfigProfileNTT rs, FormConfigProfileKey customKey) {
		rs.setModule_form_config_id(customKey.getModule_form_config_id());
		rs.setRequired_profile_code(customKey.getRequired_profile_code());
	}

	public ModuleFormConfigProfileDTO insert(ModuleFormConfigProfileDTO in) {
		log.info("Invoking insert with params in: {}", in);
		return this.insert(in, FormConfigProfileKey.builder()
				.module_form_config_id(in.getModuleFormConfigId())
				.required_profile_code(in.getRequiredProfileCode())
				.build());
	}

	public ModuleFormConfigProfileDTO update(ModuleFormConfigProfileDTO in) {
		log.info("Invoking update with params in: {}", in);
		return this.update(null, in, FormConfigProfileKey.builder()
				.module_form_config_id(in.getModuleFormConfigId())
				.required_profile_code(in.getRequiredProfileCode())
				.build());
	}

	public void delete(FormConfigProfileKey key) {
		log.info("Invoking delete with params key: {}", key);
		this.delete(null, key);
	}

	public void deleteByModuleFormConfigId(Long moduleFormConfigId) {
		((ModuleFormConfigProfileDAO) this.dao).deleteByModuleFormConfigId(moduleFormConfigId);
	}

	public ModuleFormConfigProfileDTO findById(String tenant, FormConfigProfileKey id) throws ObjectNotFoundException {
		log.info("Invoking findById with params tenant: {} id: {}", tenant, id);
		return returnOptionalRecord(((ModuleFormConfigProfileDAO) this.dao).findById(tenant, id.getModule_form_config_id(), id.getRequired_profile_code()))
				.orElseThrow(OBJECT_NOT_FOUND_EXCEPTION_SUPPLIER);
	}

	public List<ModuleFormConfigProfileDTO> find(String tenant, Long formConfig) {
		log.info("Invoking findById with params tenant: {} formConfigId: {}", tenant, formConfig);
		return returnMappedList(((ModuleFormConfigProfileDAO) this.dao).find(tenant, formConfig));
	}

    public void bulkDeleteByModuleId(Long moduleId) {
		((ModuleFormConfigProfileDAO) this.dao).bulkDeleteByModuleId(moduleId);
    }
}
