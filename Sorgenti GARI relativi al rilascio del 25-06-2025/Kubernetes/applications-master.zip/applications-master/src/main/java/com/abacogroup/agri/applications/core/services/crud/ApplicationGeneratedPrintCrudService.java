package com.abacogroup.agri.applications.core.services.crud;

import java.util.List;
import java.util.Optional;

import org.apache.commons.lang3.NotImplementedException;
import org.slf4j.MDC;

import com.abacogroup.agri.applications.core.mappers.ApplicationGeneratedPrintMapper;
import com.abacogroup.agri.applications.core.model.dto.ApplicationGeneratedPrintDTO;
import com.abacogroup.agri.applications.db.dao.ApplicationGeneratedPrintDAO;
import com.abacogroup.agri.applications.db.ntt.ApplicationGeneratedPrintNTT;
import com.abacogroup.jaxrsutils.filter.MDCPreFilter;

import lombok.extern.slf4j.Slf4j;

/**
 * @author Gennaro Tamburrelli
 */
@Slf4j
public class ApplicationGeneratedPrintCrudService
		extends AbstractCrudService<ApplicationGeneratedPrintNTT, Long, ApplicationGeneratedPrintDTO, ApplicationGeneratedPrintMapper, Void> {

	public ApplicationGeneratedPrintCrudService(ApplicationGeneratedPrintDAO dao, ApplicationGeneratedPrintMapper mapper) {
		super(dao, mapper);
	}

	@Override
	protected Long retrievePrimaryKey(Void customKey) {
		return this.dao.nextSequenceVal();
	}

	@Override
	protected boolean hasPrimaryKey() {
		return true;
	}

	@Override
	protected Optional<ApplicationGeneratedPrintNTT> findRsByCustomKey(Void customKey) {
		return Optional.empty();
	}

	@Override
	protected void deleteByCustomKey(Void customKey) {
		throw new NotImplementedException("Not implemented.");
	}

	@Override
	protected void setCustomSearchKey(ApplicationGeneratedPrintNTT rs, Void customKey) {
		throw new NotImplementedException("Not implemented.");
	}

	public ApplicationGeneratedPrintDTO insert(ApplicationGeneratedPrintDTO in) {
		log.info("Invoking insert with params in: {}", in);
		return this.insert(in, null);
	}

	public ApplicationGeneratedPrintDTO update(Long key, ApplicationGeneratedPrintDTO in) {
		log.info("Invoking update with params key: {} in: {}", key, in);
		return this.update(key, in, null);
	}

	public void delete(Long key) {
		log.info("Invoking delete with params key: {}", key);
		this.delete(key, null);
	}

	public List<ApplicationGeneratedPrintDTO> findAllGeneratedPrints(String tenantId, Long applicationId) {
		return returnMappedList(getDao().findCompletedPrintsByApplicationIdAndPrintCode(tenantId, applicationId,
				MDC.get(MDCPreFilter.LOCALE), null));
	}

	public List<ApplicationGeneratedPrintDTO> findAllGeneratedPrintsByPrintCode(String tenantId, Long applicationId, String printCode) {
		return returnMappedList(getDao().findCompletedPrintsByApplicationIdAndPrintCode(tenantId, applicationId,
				MDC.get(MDCPreFilter.LOCALE), printCode));
	}

	public Optional<ApplicationGeneratedPrintDTO> findPrintByApplicationIdAndFileId(String tenantId, Long applicationId, String fileId) {
		return returnOptionalRecord(getDao().findByApplicationIdAndFileId(tenantId, applicationId, MDC.get(MDCPreFilter.LOCALE), fileId));
	}

	public static final Integer ON_GOING_PRINT = 1;
	public static final Integer DEFINITIVE_PRINT = 0;

	public Optional<ApplicationGeneratedPrintDTO> findLastGeneratedPrintByCode(String tenantId, Long applicationId, String printCode) {
		return returnOptionalRecord(getDao().findLastGeneratedPrintByCode(tenantId, applicationId, printCode, MDC.get(MDCPreFilter.LOCALE), DEFINITIVE_PRINT));
	}

	public List<ApplicationGeneratedPrintDTO> findOngoingPrintByCode(String tenantId, Long applicationId, String printCode) {
		return returnMappedList(getDao().findLastGeneratedPrintByCode(tenantId, applicationId, printCode, MDC.get(MDCPreFilter.LOCALE), ON_GOING_PRINT));
	}

	public ApplicationGeneratedPrintDTO findByUuid(String uuid) {
		return this.mapper.entityToDto(getDao().findByUuid(uuid));
	}

	private ApplicationGeneratedPrintDAO getDao() {
		return (ApplicationGeneratedPrintDAO) this.dao;
	}

}
