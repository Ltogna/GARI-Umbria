package com.abacogroup.agri.applications.core.services.crud;

import com.abacogroup.agri.applications.core.mappers.ApplicationGeneratedCalculationMapper;
import com.abacogroup.agri.applications.core.model.dto.ApplicationGeneratedCalculationDTO;
import com.abacogroup.agri.applications.db.dao.ApplicationGeneratedCalculationDAO;
import com.abacogroup.agri.applications.db.ntt.ApplicationGeneratedCalculationNTT;
import com.abacogroup.jaxrsutils.filter.MDCPreFilter;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.NotImplementedException;
import org.slf4j.MDC;

import java.util.List;
import java.util.Optional;

/**
 * @author Alexandru Paraschiv
 */
@Slf4j
public class ApplicationGeneratedCalculationCrudService
		extends AbstractCrudService<ApplicationGeneratedCalculationNTT, Long, ApplicationGeneratedCalculationDTO, ApplicationGeneratedCalculationMapper, Void> {

	public static final Integer ON_GOING_CALCULATION = 1;
	public static final Integer DEFINITIVE_CALCULATION = 0;

	public ApplicationGeneratedCalculationCrudService(ApplicationGeneratedCalculationDAO dao, ApplicationGeneratedCalculationMapper mapper) {
		super(dao, mapper);
	}

	@Override
	protected Long retrievePrimaryKey(Void customKey) {
		return this.dao.nextSequenceVal();
	}

	@Override
	protected boolean hasPrimaryKey() {
		return true;
	}

	@Override
	protected Optional<ApplicationGeneratedCalculationNTT> findRsByCustomKey(Void customKey) {
		return Optional.empty();
	}

	@Override
	protected void deleteByCustomKey(Void customKey) {
		throw new NotImplementedException("Not implemented.");
	}

	@Override
	protected void setCustomSearchKey(ApplicationGeneratedCalculationNTT rs, Void customKey) {
		throw new NotImplementedException("Not implemented.");
	}

	public ApplicationGeneratedCalculationDTO insert(ApplicationGeneratedCalculationDTO in) {
		log.info("Invoking insert with params in: {}", in);
		return this.insert(in, null);
	}

	public ApplicationGeneratedCalculationDTO update(Long key, ApplicationGeneratedCalculationDTO in) {
		log.info("Invoking update with params key: {} in: {}", key, in);
		return this.update(key, in, null);
	}

	public void delete(Long key) {
		log.info("Invoking delete with params key: {}", key);
		this.delete(key, null);
	}

	public List<ApplicationGeneratedCalculationDTO> findAllGeneratedCalculations(String tenantId, Long applicationId) {
		return returnMappedList(getDao().findCompletedCalculationsByApplicationId(tenantId, applicationId, MDC.get(MDCPreFilter.LOCALE)));
	}

	public Optional<ApplicationGeneratedCalculationDTO> findCalculationByApplicationIdAndJobUuidAndStatus(String tenantId, Long applicationId, String jobUuid,
			String status) {
		return returnOptionalRecord(getDao().findCalculationByApplicationIdAndJobUuid(tenantId, applicationId, MDC.get(MDCPreFilter.LOCALE), jobUuid,
				status));
	}

	public Optional<ApplicationGeneratedCalculationDTO> findCalculationByApplicationIdAndJobUuid(String tenantId, Long applicationId, String jobUuid) {
		return returnOptionalRecord(getDao().findCalculationByApplicationIdAndJobUuid(tenantId, applicationId, MDC.get(MDCPreFilter.LOCALE), jobUuid));
	}

	public Optional<ApplicationGeneratedCalculationDTO> findLastGeneratedCalculationByCode(String tenantId, Long applicationId, String calculationCode) {
		return returnOptionalRecord(
				getDao().findLastGeneratedCalculationByCode(tenantId, applicationId, calculationCode, MDC.get(MDCPreFilter.LOCALE), DEFINITIVE_CALCULATION));
	}

	public List<ApplicationGeneratedCalculationDTO> findOngoingCalculationByCode(String tenantId, Long applicationId, String calculationCode) {
		return returnMappedList(
				getDao().findLastGeneratedCalculationByCode(tenantId, applicationId, calculationCode, MDC.get(MDCPreFilter.LOCALE), ON_GOING_CALCULATION));
	}

	public ApplicationGeneratedCalculationDTO findByUuid(String uuid) {
		return this.mapper.entityToDto(getDao().findByUuid(uuid));
	}

	private ApplicationGeneratedCalculationDAO getDao() {
		return (ApplicationGeneratedCalculationDAO) this.dao;
	}

}
