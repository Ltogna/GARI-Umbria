package com.abacogroup.agri.applications.core.mappers;

import com.abacogroup.agri.applications.core.model.dto.ModuleCalculationConfigsDTO;
import com.abacogroup.agri.applications.core.model.dto.publics.CalculationDetailsOutDTO;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

@Mapper
public interface CalculationDetailsOutMapper {
	CalculationDetailsOutMapper INSTANCE = Mappers.getMapper(CalculationDetailsOutMapper.class);

	@Mapping(source = "id", target = "calculationConfigId")
	@Mapping(source = "calculationCode", target = "calculationCode")
	@Mapping(source = "calculationDescription", target = "calculationDescription")
	@Mapping(source = "sortOrder", target = "sortOrder")
	CalculationDetailsOutDTO toPublicDTO(ModuleCalculationConfigsDTO dto);
}
