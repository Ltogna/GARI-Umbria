package com.abacogroup.agri.applications.core.services.workflow.sdkimpl;

import com.abacogroup.agri.applications.core.services.crud.ApplicationsCrudService;
import com.abacogroup.applicationworkflowsdk.service.LogicallyDeleteApplication;
import com.abacogroup.dropwizard.auth.sso2.User;
import lombok.extern.slf4j.Slf4j;

/**
 * @author Gennaro Tamburrelli
 */
@Slf4j
public class LogicallyDeleteApplicationImpl implements LogicallyDeleteApplication {

	private final ApplicationsCrudService applicationsCrudService;

	public LogicallyDeleteApplicationImpl(ApplicationsCrudService applicationsCrudService) {
		this.applicationsCrudService = applicationsCrudService;
	}

	@Override
	public void logicallyDeleteApplication(String tenant, Long applicationId, User user) {
		applicationsCrudService.delete(applicationId, user.getUserId());
		log.info("logically deleted application id {}", applicationId);
	}
}
