package com.abacogroup.agri.applications.core.services.workflow.sdkimpl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import com.abacogroup.agri.applications.core.model.dto.ApplicationProfileDTO;
import com.abacogroup.agri.applications.core.services.FormConfigService;
import com.abacogroup.agri.applications.core.services.crud.ApplicationCompileStatusCrudService;
import com.abacogroup.agri.applications.core.services.crud.ApplicationProfilesCrudService;
import com.abacogroup.agri.applications.core.services.crud.ApplicationsCrudService;
import com.abacogroup.applicationworkflowsdk.model.io.output.FormWithGroupHierarchyPublicDTO;
import com.abacogroup.applicationworkflowsdk.service.GetFormConfigs;
import com.abacogroup.dropwizard.auth.sso2.Sso2Client;
import com.abacogroup.dropwizard.auth.sso2.User;

/**
 * @author Gennaro Tamburrelli
 */
public class GetFormConfigsImpl implements GetFormConfigs {

	private final ApplicationsCrudService applicationsCrudService;
	private final ApplicationProfilesCrudService applicationProfilesCrudService;
	private final ApplicationCompileStatusCrudService applicationCompileStatusCrudService;
	private final FormConfigService formConfigService;
	private final Sso2Client sso2Client;

	public GetFormConfigsImpl(ApplicationsCrudService applicationsCrudService,
			ApplicationProfilesCrudService applicationProfilesCrudService,
			ApplicationCompileStatusCrudService applicationCompileStatusCrudService,
			FormConfigService formConfigService, Sso2Client sso2Client) {
		this.applicationsCrudService = applicationsCrudService;
		this.applicationProfilesCrudService = applicationProfilesCrudService;
		this.applicationCompileStatusCrudService = applicationCompileStatusCrudService;
		this.formConfigService = formConfigService;
		this.sso2Client = sso2Client;
	}

	@Override
	public List<FormWithGroupHierarchyPublicDTO> getForms(String tenant, Long applicationId, User user, String locale) throws Exception {
		return this.getFormsByProcessStatus(tenant, applicationId, null, user, locale);
	}

	@Override
	public List<FormWithGroupHierarchyPublicDTO> getFormsByProcessStatus(String tenant, Long applicationId, String processStatus, User user, String locale)
			throws Exception {
		var res = applicationsCrudService.findWithDetailsByApplicationId(tenant, applicationId);
		res.setCompileStatus(applicationCompileStatusCrudService.find(tenant, res.getApplicationId()));
		var profileList = applicationProfilesCrudService.findAll(tenant, res.getApplicationId(), locale);
		List<String> requiredProfileCodes = profileList
				.stream()
				.map(ApplicationProfileDTO::getProfileCode)
				.collect(Collectors.toList());
		return formConfigService
				.getFormsByModuleIdAndProcessStatus(tenant,
						res.getModuleId(),
						Optional.ofNullable(processStatus).orElse(res.getProcessStatus()),
						res.getCompileStatus(),
						requiredProfileCodes.isEmpty() ? new ArrayList<>(List.of("")) : requiredProfileCodes,
						sso2Client.createSecurityContextFromUserId(tenant, user.getUserId()),
						locale);
	}
}
