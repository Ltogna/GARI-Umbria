package com.abacogroup.agri.applications.utils;

import jakarta.ws.rs.core.SecurityContext;

import java.security.Principal;
import java.util.Optional;

public final class UserUtility {

	private UserUtility() {
	}

	public static Optional<String> getUserIdFromSecurityContext(SecurityContext context) {
		return Optional.ofNullable(Optional.ofNullable(Optional.ofNullable(context)
				.map(SecurityContext::getUserPrincipal)
				.orElseGet(() -> null)).map(Principal::getName)
				.orElseGet(() -> null));
	}
}
