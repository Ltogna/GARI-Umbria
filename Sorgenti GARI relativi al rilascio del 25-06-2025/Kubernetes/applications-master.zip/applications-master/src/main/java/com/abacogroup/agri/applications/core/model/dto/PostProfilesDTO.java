package com.abacogroup.agri.applications.core.model.dto;

import java.util.List;

import jakarta.validation.constraints.NotEmpty;
import lombok.Data;

@Data
public class PostProfilesDTO {
	private List<@NotEmpty String> toRemove;
	private List<@NotEmpty String> toAdd;
}
