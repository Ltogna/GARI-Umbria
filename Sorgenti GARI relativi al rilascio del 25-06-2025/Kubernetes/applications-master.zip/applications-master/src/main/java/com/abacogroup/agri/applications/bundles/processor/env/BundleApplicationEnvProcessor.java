package com.abacogroup.agri.applications.bundles.processor.env;

import com.abacogroup.agri.applications.bundles.model.env.BundleApplicationEnvMessage;
import com.abacogroup.agri.applications.bundles.processor.AbstractBundleApplicationsProcessor;
import com.abacogroup.bundles.listener.configdata.ConfigDataMessage;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.jdbi.v3.core.Jdbi;

import java.nio.file.Path;

/**
 * The type Bundle application env processor.
 *
 * @author Carlo Sindico
 */
@Slf4j
public class BundleApplicationEnvProcessor extends AbstractBundleApplicationsProcessor<BundleApplicationEnvMessage> {

    private final ApplicationEnvBundleWorker applicationEnvBundleWorker;

    public BundleApplicationEnvProcessor(ObjectMapper objectMapper, ApplicationEnvBundleWorker applicationEnvBundleWorker, Jdbi jdbi) {
        super(objectMapper, jdbi);
        this.applicationEnvBundleWorker = applicationEnvBundleWorker;
    }

    @Override
    protected TypeReference<BundleApplicationEnvMessage> getTypeReference() {
        return new TypeReference<>() {};
    }

    @Override
    protected void onMessageInTransaction(ConfigDataMessage message) {
        log.info("onMessageInTransaction: proccessing file with tenant {}", message.getTenantId());
        message.getConfigFiles().stream()
                .map(Path::toFile)
                .filter(file -> file.getAbsolutePath().endsWith(".json"))
                .forEach(file -> processFile(message.getTenantId(), file));
    }

    @Override
    protected void delete(String tenantId, BundleApplicationEnvMessage message) {
        applicationEnvBundleWorker.deleteApplicationEnvironments(tenantId, message);
    }

    @Override
    protected void doInsertOrUpdate(String tenantId, BundleApplicationEnvMessage message) {
        applicationEnvBundleWorker.upsertApplicationEnvironments(tenantId, message);
    }

    @Override
    public String getDomainName() {
        return "application-env";
    }

}
