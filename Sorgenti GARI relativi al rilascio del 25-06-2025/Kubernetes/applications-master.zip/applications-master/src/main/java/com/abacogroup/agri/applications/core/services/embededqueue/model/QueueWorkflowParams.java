package com.abacogroup.agri.applications.core.services.embededqueue.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author Gennaro Tamburrelli
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class QueueWorkflowParams {
	private Long processId;
	private Long applicationId;
	private Integer transitionId;
	private String tenant;
	private String username;
	private String userid;
	private String locale;
	private String scope;
	private String notes;
}
