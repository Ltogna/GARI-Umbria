package com.abacogroup.agri.applications.core.services.calculation;

import java.time.LocalDateTime;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import com.abacogroup.agri.applications.core.services.ForceReadOnlyContextCheckerService;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.MDC;

import com.abacogroup.agri.applications.core.caller.CreateCalculatorJobCaller;
import com.abacogroup.agri.applications.core.caller.CreateCalculatorJobInput;
import com.abacogroup.agri.applications.core.caller.GetCalculatorRawJobInput;
import com.abacogroup.agri.applications.core.caller.GetCalculatorRawResultJobCaller;
import com.abacogroup.agri.applications.core.caller.GetCalculatorRenderJobInput;
import com.abacogroup.agri.applications.core.caller.GetCalculatorRenderResultJobCaller;
import com.abacogroup.agri.applications.core.exceptions.ActionNotAuthorizedRuntimeException;
import com.abacogroup.agri.applications.core.exceptions.ApplicationNotFoundRuntimeException;
import com.abacogroup.agri.applications.core.exceptions.ObjectNotFoundException;
import com.abacogroup.agri.applications.core.exceptions.ObjectNotFoundRuntimeException;
import com.abacogroup.agri.applications.core.mappers.CalculationDetailsOutMapper;
import com.abacogroup.agri.applications.core.model.dto.ApplicationGeneratedCalculationDTO;
import com.abacogroup.agri.applications.core.model.dto.CalculationJobStatus;
import com.abacogroup.agri.applications.core.model.dto.CalculatorRenderResponse;
import com.abacogroup.agri.applications.core.model.dto.ModuleCalculationConfigParamDTO;
import com.abacogroup.agri.applications.core.model.dto.publics.ApplicationCalculationRawPublicDTO;
import com.abacogroup.agri.applications.core.model.dto.publics.ApplicationCalculationRenderPublicDTO;
import com.abacogroup.agri.applications.core.model.dto.publics.CalculationDetailsOutDTO;
import com.abacogroup.agri.applications.core.model.dto.publics.LastCalculationDTO;
import com.abacogroup.agri.applications.core.services.CheckPartyService;
import com.abacogroup.agri.applications.core.services.crud.ApplicationGeneratedCalculationCrudService;
import com.abacogroup.agri.applications.core.services.crud.ApplicationsCrudService;
import com.abacogroup.agri.applications.core.services.crud.CrudServiceContainer;
import com.abacogroup.agri.applications.core.services.crud.ModuleCalculationConfigParamCrudService;
import com.abacogroup.agri.applications.core.services.crud.ModuleCalculationConfigsCrudService;
import com.abacogroup.agri.applications.core.services.crud.ModuleCrudService;
import com.abacogroup.agri.applications.core.services.workflow.ApplicationsWorkflowService;
import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.jaxrsutils.filter.MDCPreFilter;

import jakarta.ws.rs.core.SecurityContext;
import lombok.extern.slf4j.Slf4j;

import static com.abacogroup.agri.applications.utils.GenericUtility.conditionallyOverrideUserId;

/**
 * @author Alexandru Paraschiv
 */
@Slf4j
public class CalculationService {
	public static final String JWT = "JWT ";
	public static final String CALCULATOR_DESTINATION = "applications-calculators-destination";
	public static final String CALCULATOR_RESULT_TYPE_RENDER = "RENDER";
	public static final String CALCULATOR_RESULT_TYPE_RAW = "RAW";
	private final ApplicationsCrudService applicationsCrudService;
	private final CheckPartyService checkPartyService;
	private final ModuleCrudService moduleCrudService;
	private final ApplicationsWorkflowService applicationsWorkflowService;
	private final ModuleCalculationConfigsCrudService moduleCalculationConfigsCrudService;
	private final ModuleCalculationConfigParamCrudService moduleCalculationConfigParamCrudService;
	private final ApplicationGeneratedCalculationCrudService applicationGeneratedCalculationCrudService;
	private final CreateCalculatorJobCaller createCalculatorJobCaller;
	private final GetCalculatorRawResultJobCaller getCalculatorRawResultJobCaller;
	private final GetCalculatorRenderResultJobCaller getCalculatorRenderResultJobCaller;
	private final String calculationEngineUrl;
	private final ForceReadOnlyContextCheckerService forceReadOnlyContextCheckerService;

	public CalculationService(CrudServiceContainer crudServiceContainer,
                              CheckPartyService checkPartyService,
                              ApplicationsWorkflowService applicationsWorkflowService,
                              CreateCalculatorJobCaller createCalculatorJobCaller,
                              GetCalculatorRawResultJobCaller getCalculatorRawResultJobCaller,
                              GetCalculatorRenderResultJobCaller getCalculatorRenderResultJobCaller, String calculationEngineUrl, ForceReadOnlyContextCheckerService forceReadOnlyContextCheckerService) {
		this.applicationsCrudService = crudServiceContainer.getApplicationsCrudService();
		this.checkPartyService = checkPartyService;
		this.moduleCrudService = crudServiceContainer.getModuleCrudService();
		this.applicationsWorkflowService = applicationsWorkflowService;
		this.moduleCalculationConfigsCrudService = crudServiceContainer.getModuleCalculationConfigsCrudService();
		this.moduleCalculationConfigParamCrudService = crudServiceContainer.getModuleCalculationConfigParamCrudService();
		this.applicationGeneratedCalculationCrudService = crudServiceContainer.getApplicationGeneratedCalculationCrudService();
		this.createCalculatorJobCaller = createCalculatorJobCaller;
		this.getCalculatorRawResultJobCaller = getCalculatorRawResultJobCaller;
		this.getCalculatorRenderResultJobCaller = getCalculatorRenderResultJobCaller;
		this.calculationEngineUrl = calculationEngineUrl;
        this.forceReadOnlyContextCheckerService = forceReadOnlyContextCheckerService;
    }

	public ApplicationGeneratedCalculationDTO startCalculatorJob(String tenant, Long applicationId, String processStatus,
			List<CalculationDetailsOutDTO> modulesCalculation, String calculatorCode, User user) {
		return this.startCalculatorJob(tenant, applicationId, processStatus, modulesCalculation, calculatorCode, user, MDC.get(MDCPreFilter.LOCALE));
	}

	public ApplicationGeneratedCalculationDTO startCalculatorJob(String tenant, Long applicationId, String processStatus,
			List<CalculationDetailsOutDTO> modulesCalculation,
			String calculatorCode, User user, String locale) {
		forceReadOnlyContextCheckerService.checkForReadOnlyContextFunctionByApplicationId(user, applicationId);
		if (modulesCalculation.stream().noneMatch(x -> x.getCalculationCode().equals(calculatorCode))) {
			throw new RuntimeException("calculation code not valid");
		}
		try {
			var uuid = createCalculatorJobCaller.makeCall(CreateCalculatorJobInput.builder()
					.url(this.calculationEngineUrl)
					.destination(CALCULATOR_DESTINATION)
					.calculatorCode(calculatorCode)
					.tenant(tenant)
					.token(JWT + user.getAuthToken())
					.locale(locale)
					.params(Map.of("applicationId", applicationId,
							"tenant", tenant))
					.build());
			var application = applicationsCrudService.findById(tenant, applicationId);
			var insertedJob = applicationGeneratedCalculationCrudService.insert(ApplicationGeneratedCalculationDTO.builder()
					.applicationId(applicationId)
					.calculationCode(calculatorCode)
					.calculationDate(LocalDateTime.now())
					.processStatus(processStatus)
					.calculationJobUuid(uuid.getUuid())
					.username(user.getUserId())
					.build());
			insertedJob.setProcessDescription(applicationsWorkflowService
					.getWorkflowNode(tenant, moduleCrudService.findById(application.getModuleId()).orElseThrow().getWorkflowCode(),
							insertedJob.getProcessStatus()).getDescription());
			return insertedJob;
		} catch (ObjectNotFoundException e) {
			throw new RuntimeException(e.getMessage(), e);
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			throw e;
		}

	}

	public List<CalculationDetailsOutDTO> getCalculationsByModuleIdAndProcessStatus(String tenant, Long applicationId, Long moduleId, String processStatus,
			List<String> profileCodeList, SecurityContext sc) {

		return moduleCalculationConfigsCrudService
				.find(tenant, moduleId, processStatus, profileCodeList)
				.stream()
				.filter(x -> StringUtils.isAllBlank(x.getContextFunction()) || sc.isUserInRole(x.getContextFunction()))
				.map(CalculationDetailsOutMapper.INSTANCE::toPublicDTO)
				.map(x -> {
					x.setParams(moduleCalculationConfigParamCrudService.find(tenant, x.getCalculationConfigId())
							.stream()
							.collect(Collectors
									.toMap(ModuleCalculationConfigParamDTO::getParameterName,
											ModuleCalculationConfigParamDTO::getParameterValue)));
					var lastCalculation = applicationGeneratedCalculationCrudService.findLastGeneratedCalculationByCode(tenant, applicationId,
							x.getCalculationCode());
					lastCalculation.ifPresent(y -> x.setLastCalculation(LastCalculationDTO.builder()
							.calculationDate(y.getCalculationDate())
							.calculationJobUuid(y.getCalculationJobUuid())
							.calculationStatus(y.getCalculationStatus())
							.build()));

					return x;
				})
				.collect(Collectors.toList());
	}

	public List<ApplicationGeneratedCalculationDTO> getApplicationCalculationsByApplicationId(String tenant, Long applicationId, User user, SecurityContext sc) {
		try {
			var application = applicationsCrudService.findById(tenant, applicationId);
			try {
				this.checkPartyService.checkCanReadParty(tenant, application.getPartyId(), user);
			} catch (ActionNotAuthorizedRuntimeException e) {
				return Collections.emptyList();
			}
			var module = moduleCrudService.findById(application.getModuleId()).orElseThrow(() -> new ObjectNotFoundRuntimeException("module not found"));
			var calculationList = applicationGeneratedCalculationCrudService.findAllGeneratedCalculations(tenant, applicationId);
			calculationList.stream()
					.forEach(x -> {
						x.setProcessDescription(
								applicationsWorkflowService.getWorkflowNode(tenant, module.getWorkflowCode(), x.getProcessStatus()).getDescription());
						x.setUsername(conditionallyOverrideUserId(x.getUsername(), sc));
					});
			return calculationList;
		} catch (ObjectNotFoundException e) {
			throw new ApplicationNotFoundRuntimeException("application not found");
		}
	}

	public void updateNotes(String tenant, Long applicationId, String calcUuid, String notes, User user) throws ObjectNotFoundException {
		var application = applicationsCrudService.findById(tenant, applicationId);
		this.checkPartyService.checkCanReadParty(tenant, application.getPartyId(), user);
		applicationGeneratedCalculationCrudService.findCalculationByApplicationIdAndJobUuid(tenant, applicationId, calcUuid)
				.ifPresent(x -> {
					x.setNotes(notes);
					applicationGeneratedCalculationCrudService.update(x.getPkid(), x);
				});
	}

	/*
	 * CALCULATION RENDERER
	 */

	public ApplicationCalculationRenderPublicDTO getCalculationRenderByJobUuidReadyStatus(String tenant, Long applicationId, User user, String jobId) {

		ApplicationGeneratedCalculationDTO calculation = applicationGeneratedCalculationCrudService.findCalculationByApplicationIdAndJobUuidAndStatus(
				tenant, applicationId, jobId, CalculationJobStatus.READY.name())
				.orElseThrow(() -> new ObjectNotFoundRuntimeException("Calculation not found or not ready"));

		String authToken = JWT + user.getAuthToken();

		return doGetCalculationRenderByJobUuid(tenant, authToken, MDC.get(MDCPreFilter.LOCALE), calculation.getCalculationJobUuid());
	}

	private ApplicationCalculationRenderPublicDTO doGetCalculationRenderByJobUuid(String tenant, String authToken, String locale, String uuid) {

		CalculatorRenderResponse result = getCalculatorRenderResultJobCaller.makeCall(GetCalculatorRenderJobInput.builder()
				.url(this.calculationEngineUrl)
				.tenant(tenant)
				.token(authToken)
				.locale(locale)
				.uuid(uuid)
				.build());

		return ApplicationCalculationRenderPublicDTO.builder()
				.result(result)
				.build();
	}


	/*
	 * CALCULATION RAW
	 */

	public ApplicationCalculationRawPublicDTO getCalculationRawByJobUuidReadyStatus(String tenant, Long applicationId, User user, String jobId) {

		ApplicationGeneratedCalculationDTO calculation = applicationGeneratedCalculationCrudService.findCalculationByApplicationIdAndJobUuidAndStatus(
				tenant, applicationId, jobId, CalculationJobStatus.READY.name())
				.orElseThrow(() -> new ObjectNotFoundRuntimeException("Calculation not found or not ready"));

		String authToken = JWT + user.getAuthToken();

		return doGetCalculationRawByJobUuid(tenant, authToken, MDC.get(MDCPreFilter.LOCALE), calculation.getCalculationJobUuid());
	}

	private ApplicationCalculationRawPublicDTO doGetCalculationRawByJobUuid(String tenant, String authToken, String locale, String uuid) {

		String result = getCalculatorRawResultJobCaller.makeCall(GetCalculatorRawJobInput.builder()
				.url(this.calculationEngineUrl)
				.tenant(tenant)
				.token(authToken)
				.locale(locale)
				.uuid(uuid)
				.build());

		return ApplicationCalculationRawPublicDTO.builder()
				.result(result)
				.build();
	}
}
