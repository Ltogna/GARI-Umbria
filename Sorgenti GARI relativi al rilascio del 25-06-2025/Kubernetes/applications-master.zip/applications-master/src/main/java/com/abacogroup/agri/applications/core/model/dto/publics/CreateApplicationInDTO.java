package com.abacogroup.agri.applications.core.model.dto.publics;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author Mauro Pozzana
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CreateApplicationInDTO {
	private Long partyId;
	private Integer year;
	private String sectorCode;
	private String moduleCode;
	private Long amendmentApplicationId;
	private Long parentApplicationId;
}
