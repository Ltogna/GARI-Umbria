package com.abacogroup.agri.applications.bundles.processor.module;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import com.abacogroup.agri.applications.core.model.dto.*;
import com.abacogroup.agri.applications.core.services.crud.*;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;

import com.abacogroup.agri.applications.bundles.BundleConstants;
import com.abacogroup.agri.applications.bundles.model.form.BundleFormCatalogInDTO;
import com.abacogroup.agri.applications.bundles.model.form.BundleFormGroupInDTO;
import com.abacogroup.agri.applications.bundles.model.form.BundleFormsInDTO;
import com.abacogroup.agri.applications.bundles.model.form.BundleModuleCalculationInDTO;
import com.abacogroup.agri.applications.bundles.model.form.BundleModuleFormConfigsInDTO;
import com.abacogroup.agri.applications.bundles.model.form.BundleModulePrintInDTO;
import com.abacogroup.agri.applications.bundles.model.module.BundleModuleInDTO;
import com.abacogroup.agri.applications.bundles.model.module.BundleModulesMessage;
import com.abacogroup.agri.applications.core.exceptions.ObjectNotFoundException;
import com.abacogroup.agri.applications.core.exceptions.ObjectNotFoundRuntimeException;
import com.abacogroup.agri.applications.core.services.FormConfigService;
import com.abacogroup.applicationworkflowsdk.model.io.output.ModuleProfileDTO;

import lombok.extern.slf4j.Slf4j;

/**
 * @author Alexandru Paraschiv
 * @author Gennaro Tamburrelli
 */
@Slf4j
public class ModulesBundleWorker {

	protected final ModuleCrudService moduleCrudService;
	private final SectorsCrudService sectorsCrudService;
	private final ModuleDetailsCrudService moduleDetailsCrudService;

	private final FormCatalogsCrudService formCatalogsCrudService;
	private final FormGroupsCrudService formGroupsCrudService;
	private final ModuleFormConfigsCrudService moduleFormConfigsCrudService;
	private final ModuleFormConfigParamCrudService moduleFormConfigParamCrudService;
	private final ModuleFormConfigProfilesCrudService moduleFormConfigProfilesCrudService;

	private final ModulePrintConfigsCrudService modulePrintConfigsCrudService;
	private final ModulePrintConfigParamCrudService modulePrintConfigParamCrudService;
	private final ModulePrintConfigProfilesCrudService modulePrintConfigProfilesCrudService;

	private final ModuleCalculationConfigsCrudService moduleCalculationConfigsCrudService;
	private final ModuleCalculationConfigParamCrudService moduleCalculationConfigParamCrudService;
	private final ModuleCalculationConfigProfilesCrudService moduleCalculationConfigProfilesCrudService;

	private final ModuleProfilesCrudService moduleProfilesCrudService;
	private final FormConfigService formConfigService;
	private final AmendableModuleCrudService amendableModuleCrudService;
	private final ChildModuleCrudService childModuleCrudService;

	public ModulesBundleWorker(CrudServiceContainer crudServiceContainer,
			FormConfigService formConfigService) {
		this.moduleCrudService = crudServiceContainer.getModuleCrudService();
		this.moduleDetailsCrudService = crudServiceContainer.getModuleDetailsCrudService();
		this.sectorsCrudService = crudServiceContainer.getSectorsCrudService();
		this.formCatalogsCrudService = crudServiceContainer.getFormCatalogsCrudService();
		this.formGroupsCrudService = crudServiceContainer.getFormGroupsCrudService();
		this.moduleFormConfigsCrudService = crudServiceContainer.getModuleFormConfigsCrudService();
		this.moduleFormConfigParamCrudService = crudServiceContainer.getModuleFormConfigParamCrudService();
		this.moduleFormConfigProfilesCrudService = crudServiceContainer.getModuleFormConfigProfilesCrudService();
		this.modulePrintConfigsCrudService = crudServiceContainer.getModulePrintConfigsCrudService();
		this.modulePrintConfigParamCrudService = crudServiceContainer.getModulePrintConfigParamCrudService();
		this.modulePrintConfigProfilesCrudService = crudServiceContainer.getModulePrintConfigProfilesCrudService();
		this.moduleCalculationConfigsCrudService = crudServiceContainer.getModuleCalculationConfigsCrudService();
		this.moduleCalculationConfigParamCrudService = crudServiceContainer
				.getModuleCalculationConfigParamCrudService();
		this.moduleCalculationConfigProfilesCrudService = crudServiceContainer
				.getModuleCalculationConfigProfilesCrudService();
		this.moduleProfilesCrudService = crudServiceContainer.getModuleProfilesCrudService();
		this.formConfigService = formConfigService;
		this.amendableModuleCrudService = crudServiceContainer.getAmendableModuleCrudService();
		this.childModuleCrudService = crudServiceContainer.getChildModuleCrudService();
	}

	public SectorsCrudService exposeSectorsCrudService() {
		return this.sectorsCrudService;
	}

	public ModuleCrudService exposeModuleCrudService() {
		return this.moduleCrudService;
	}

	public FormCatalogsCrudService exposeFormCatalogsCrudService() {
		return this.formCatalogsCrudService;
	}

	public FormGroupsCrudService exposeFormGroupsCrudService() {
		return this.formGroupsCrudService;
	}

	public ModuleFormConfigsCrudService exposeModuleFormConfigsCrudService() {
		return this.moduleFormConfigsCrudService;
	}

	public ModuleFormConfigParamCrudService exposeModuleFormConfigParamCrudService() {
		return this.moduleFormConfigParamCrudService;
	}

	public ModuleFormConfigProfilesCrudService exposeModuleFormConfigProfilesCrudService() {
		return this.moduleFormConfigProfilesCrudService;
	}

	public ModuleProfilesCrudService exposeModuleProfilesCrudService() {
		return this.moduleProfilesCrudService;
	}

	public ModulePrintConfigsCrudService exposeModulePrintConfigsCrudService() {
		return this.modulePrintConfigsCrudService;
	}

	public ModulePrintConfigParamCrudService exposeModulePrintConfigParamCrudService() {
		return this.modulePrintConfigParamCrudService;
	}

	public ModulePrintConfigProfilesCrudService exposeModulePrintConfigProfilesCrudService() {
		return this.modulePrintConfigProfilesCrudService;
	}

	public ModuleCalculationConfigsCrudService exposeModuleCalculationConfigsCrudService() {
		return this.moduleCalculationConfigsCrudService;
	}

	public ModuleCalculationConfigParamCrudService exposeModuleCalculationConfigParamCrudService() {
		return this.moduleCalculationConfigParamCrudService;
	}

	public ModuleCalculationConfigProfilesCrudService exposeModuleCalculationConfigProfilesCrudService() {
		return this.moduleCalculationConfigProfilesCrudService;
	}

	public void insertBundleModules(String tenantId, BundleModulesMessage message) {
		log.info("ModulesBundleWorker: processing file with tenant {}", tenantId);
		message.getModules()
				.stream()
				.forEachOrdered(module -> {
					this.insertOrUpdateModule(tenantId, module);
				});
	}

	private void insertOrUpdateModule(String tenantId, BundleModuleInDTO bundleModuleInDTO) {
		log.info("ModulesBundleWorker: inserting module with tenant {} and code {}", tenantId,
				bundleModuleInDTO.getModuleCode());
		ModuleDTO module = this.insertModule(tenantId, bundleModuleInDTO);
		this.upsertModuleDetail(tenantId, bundleModuleInDTO, module.getModuleId());
		this.upsertModuleProfile(tenantId, bundleModuleInDTO, module.getModuleId());
		this.deleteOldConfigAndPrintsAndCalculation(tenantId, module.getModuleId());
		this.upsertForms(tenantId, bundleModuleInDTO.getForms(), module.getModuleId());
		this.upsertPrints(tenantId, bundleModuleInDTO.getModulePrints(), module.getModuleId());
		this.upsertCalculations(tenantId, bundleModuleInDTO.getModuleCalculations(), module.getModuleId());
	}

	private void deleteOldConfigAndPrintsAndCalculation(String tenantId, Long moduleId) {
		try {
			log.info("deleting old config params");
			modulePrintConfigsCrudService.findAllModulePrintConfigs(tenantId, moduleId)
					.forEach(x -> {
						modulePrintConfigParamCrudService.deleteByModulePrintConfigId(x.getId());
						modulePrintConfigProfilesCrudService.deleteByModulePrintConfigId(x.getId());
						modulePrintConfigsCrudService.delete(x.getId());
					});
			moduleCalculationConfigsCrudService.findAllModuleCalculationConfigs(tenantId, moduleId)
					.forEach(x -> {
						moduleCalculationConfigParamCrudService.deleteByModuleCalculationConfigId(x.getId());
						moduleCalculationConfigProfilesCrudService.deleteByModuleCalculationConfigId(x.getId());
						moduleCalculationConfigsCrudService.delete(x.getId());
					});

			moduleFormConfigParamCrudService.bulkDeleteByModuleId(moduleId);
			moduleFormConfigProfilesCrudService.bulkDeleteByModuleId(moduleId);
			moduleFormConfigsCrudService.bulkDeleteByModuleId(moduleId);

		} catch (Exception e) {
			log.error("error deleting ");
		}
	}

	private void upsertPrints(String tenantId, List<BundleModulePrintInDTO> modulePrintConfigs, Long moduleId) {
		log.info("Invoking upsertModulePrintConfigs with params tenantId: {} modulePrintConfigs: {} createModuleId: {}",
				tenantId,
				modulePrintConfigs, moduleId);
		Optional.ofNullable(modulePrintConfigs)
				.ifPresent(mfc -> mfc
						.stream()
						.forEachOrdered(modulePrintConfig -> {
							checkIfProcessStatusAndProcessStatusListArePresentAtSameTime(modulePrintConfig);
							List<String> processStatusToUse = new ArrayList<>();
							if (modulePrintConfig.getProcessStatus() != null) {
								processStatusToUse.add(modulePrintConfig.getProcessStatus());
							} else {
								processStatusToUse.addAll(Optional.ofNullable(modulePrintConfig.getProcessStatusList())
										.orElseGet(Collections::emptyList));
							}
							checkFlAvailableToUser(modulePrintConfig, processStatusToUse);
							if (CollectionUtils.isEmpty(processStatusToUse)) {
								processStatusToUse.add(null);
							}
							insertOrUpdatePrints(tenantId, moduleId, modulePrintConfig, processStatusToUse);
						}));
	}

	private void checkIfProcessStatusAndProcessStatusListArePresentAtSameTime(
			BundleModulePrintInDTO modulePrintConfig) {
		if (modulePrintConfig.getProcessStatus() != null
				&& (modulePrintConfig.getProcessStatusList() != null && !modulePrintConfig
						.getProcessStatusList().isEmpty())) {
			throw new IllegalStateException(
					"invalid input: cannot be present at same time process status and process status list!");
		}
	}

	private void checkFlAvailableToUser(BundleModulePrintInDTO modulePrintConfig, List<String> processStatusToUse) {
		if (CollectionUtils.isEmpty(processStatusToUse)
				&& (modulePrintConfig.getFlAvailableToUser() == null
						|| modulePrintConfig.getFlAvailableToUser() == 1)) {
			throw new IllegalStateException(
					"invalid input: processStatusList must contain values if flAvailableToUser is null or zero");
		}
	}

	private void insertOrUpdatePrints(String tenantId, Long moduleId, BundleModulePrintInDTO modulePrintConfig,
			List<String> processStatusToUse) {
		for (String currentProcessStatus : processStatusToUse) {
			ModulePrintConfigsDTO placeHolder;
			var bundleEntity = ModulePrintConfigsDTO.builder()
					.moduleId(moduleId)
					.printCode(modulePrintConfig.getPrintCode())
					.processStatus(currentProcessStatus)
					.sortOrder(modulePrintConfig.getSortOrder())
					.contextFunction(modulePrintConfig.getContextFunction())
					.flAvailableToUser(Optional.ofNullable(modulePrintConfig.getFlAvailableToUser()).orElse(1))
					.build();
			var existentPrintsConfig = modulePrintConfigsCrudService.find(tenantId, moduleId,
					bundleEntity.getPrintCode(), currentProcessStatus,
					bundleEntity.getFlAvailableToUser(), bundleEntity.getContextFunction())
					.orElse(null);

			boolean checkForProfiles = formConfigService
					.checkForModulePrintConfigProfiles(tenantId, existentPrintsConfig,
							modulePrintConfig.getRequiredProfiles());

			if (Optional.ofNullable(existentPrintsConfig).isPresent() && checkForProfiles) {
				placeHolder = modulePrintConfigsCrudService.update(existentPrintsConfig.getId(), bundleEntity);
			} else {
				// Creating new instance for ModuleFormConfigs
				placeHolder = modulePrintConfigsCrudService.insert(bundleEntity);
			}
			this.insertOrUpdateModulePrintConfigParams(modulePrintConfig.getParams(), placeHolder.getId());
			this.insertOrUpdatePrintConfigProfiles(modulePrintConfig.getRequiredProfiles(), placeHolder.getId());
			Optional.ofNullable(modulePrintConfig.getI18n())
					.ifPresent(i18n -> i18n
							.stream()
							.forEachOrdered(val -> {

								String fieldName = ModulePrintConfigsCrudService.PRINT_CODE_I18N.PROFILE_CODE.getCode();
								String i18nCode = bundleEntity.getPrintCode();
								if (StringUtils.isNotBlank(bundleEntity.getProcessStatus())) {
									fieldName = ModulePrintConfigsCrudService.PRINT_CODE_I18N.PROFILE_CODE_WITH_STATUS
											.getCode();
									i18nCode = bundleEntity.getPrintCode() + ":" + bundleEntity.getProcessStatus();
								}

								modulePrintConfigsCrudService
										.deletePrintCodeI18N(tenantId, fieldName, i18nCode, val.getLang());

								modulePrintConfigsCrudService.insertPrintCodeI18N(tenantId,
										fieldName,
										i18nCode,
										val.getLang(),
										val.getDescription());
							}));
		}
	}

	private void upsertCalculations(String tenantId, List<BundleModuleCalculationInDTO> moduleCalculationConfigs,
			Long moduleId) {
		log.info(
				"Invoking upsertModulePrintConfigs with params tenantId: {} moduleCalculationConfigs: {} createModuleId: {}",
				tenantId,
				moduleCalculationConfigs, moduleId);
		Optional.ofNullable(moduleCalculationConfigs)
				.ifPresent(mfc -> mfc
						.stream()
						.forEachOrdered(moduleCalculationConfig -> {
							if (moduleCalculationConfig.getProcessStatus() != null && (moduleCalculationConfig
									.getProcessStatusList() != null
									&& !moduleCalculationConfig
											.getProcessStatusList().isEmpty())) {
								throw new IllegalStateException(
										"invalid input: cannot be present at same time process status and process status list!");
							}
							List<String> processStatusToUse = new ArrayList<>();
							if (moduleCalculationConfig.getProcessStatus() != null) {
								processStatusToUse.add(moduleCalculationConfig.getProcessStatus());
							} else {
								processStatusToUse.addAll(moduleCalculationConfig.getProcessStatusList());
							}
							processingStatuses(tenantId, moduleId, moduleCalculationConfig, processStatusToUse);
						}));
	}

	private void processingStatuses(String tenantId, Long moduleId,
			BundleModuleCalculationInDTO moduleCalculationConfig, List<String> processStatusToUse) {
		for (String currentProcessStatus : processStatusToUse) {
			ModuleCalculationConfigsDTO placeHolder;
			var bundleEntity = ModuleCalculationConfigsDTO.builder()
					.moduleId(moduleId)
					.calculationCode(moduleCalculationConfig.getCalculationCode())
					.processStatus(currentProcessStatus)
					.sortOrder(moduleCalculationConfig.getSortOrder())
					.contextFunction(moduleCalculationConfig.getContextFunction())
					.build();
			var existentCalculationsConfig = moduleCalculationConfigsCrudService.find(tenantId, moduleId,
					moduleCalculationConfig.getCalculationCode(), currentProcessStatus,
					moduleCalculationConfig.getContextFunction())
					.orElse(null);

			boolean checkForProfiles = formConfigService
					.checkForModuleCalculationConfigProfiles(tenantId, existentCalculationsConfig,
							moduleCalculationConfig.getRequiredProfiles());

			if (Optional.ofNullable(existentCalculationsConfig).isPresent() && checkForProfiles) {
				placeHolder = moduleCalculationConfigsCrudService.update(existentCalculationsConfig.getId(),
						bundleEntity);
			} else {
				// Creating new instance for ModuleFormConfigs
				placeHolder = moduleCalculationConfigsCrudService.insert(bundleEntity);
			}
			this.insertOrUpdateModuleCalculationConfigParams(moduleCalculationConfig.getParams(), placeHolder.getId());
			this.insertOrUpdateCalculationConfigProfiles(moduleCalculationConfig.getRequiredProfiles(),
					placeHolder.getId());
			Optional.ofNullable(moduleCalculationConfig.getI18n())
					.ifPresent(i18n -> i18n
							.stream()
							.forEachOrdered(val -> {
								moduleCalculationConfigsCrudService
										.deleteCalculationCodeI18N(tenantId,
												moduleCalculationConfig.getCalculationCode(), val.getLang());
								moduleCalculationConfigsCrudService.insertCalculationCodeI18N(tenantId,
										moduleCalculationConfig.getCalculationCode(),
										val.getLang(),
										val.getDescription());
							}));
		}
	}

	private void upsertForms(String tenantId, BundleFormsInDTO forms, Long moduleId) {
		log.info("upsertForms: insertForms with tenant: {} forms: {} createdModuleId: {}", tenantId, forms, moduleId);
		// FORM-CATALOGS
		this.upsertFormCatalogs(tenantId, forms.getFormCatalogs());
		// FORM-GROUPS
		this.upsertRecursiveFormGroups(tenantId, forms.getFormGroups(), null);
		// MODULE-FORM-CONFIG and PROFILES related
		this.upsertModuleFormConfigs(tenantId, forms.getModuleFormConfigs(), moduleId);
	}

	private ModuleDTO insertModule(String tenantId, BundleModuleInDTO module) {
		log.info("Invoking insertOrUpdateModuleWithDetail with params tenantId: {} module: {}", tenantId, module);
		try {
			Optional<ModuleDTO> existingModule = moduleCrudService.findByModuleCodeAndSectorCode(tenantId,
					module.getModuleCode(), module.getSectorCode());
			log.info("insertModule: existingModule: {}", existingModule);

			log.info("ModulesBundleWorker: inserting i18n with tenant {} and code {}", tenantId,
					module.getSectorCode());
			module.getI18n()
					.stream()
					.forEachOrdered(val -> {
						existingModule.ifPresent(moduleDTO -> moduleCrudService.deleteModuleI18N(tenantId,
								module.getModuleCode(), val.getLang()));
						moduleCrudService.insertModuleI18N(tenantId,
								module.getModuleCode(),
								val.getLang(),
								val.getDescription());
					});

			if (existingModule.isEmpty()) {
				return moduleCrudService.insert(ModuleDTO.builder()
						.moduleCode(module.getModuleCode())
						.workflowCode(module.getWorkflowCode())
						.sectorId(sectorsCrudService.findSectorByCode(tenantId, module.getSectorCode()).getSectorId())
						.flAmendModule(Optional.ofNullable(module.getFlAmendModule()).orElse(false))
						.flChildModule(Optional.ofNullable(module.getFlChildModule()).orElse(false))
						.build(), BundleConstants.BUNDLE_SYSTEM_USERNAME);
			} else {
				var mod = existingModule.get();
				moduleCrudService.updateWorkflwoCode(mod.getModuleId(), module.getWorkflowCode());
				moduleCrudService.updateFlAmendable(mod.getModuleId(),
						Boolean.TRUE.equals(module.getFlAmendModule()) ? 1 : 0);
				moduleCrudService.updateFlChild(mod.getModuleId(),
						Boolean.TRUE.equals(module.getFlChildModule()) ? 1 : 0);
				return mod;
			}

		} catch (ObjectNotFoundException e) {
			log.error(e.getMessage(), e);
			throw new ObjectNotFoundRuntimeException(e.getMessage());
		}
	}

	private void upsertModuleDetail(String tenantId, BundleModuleInDTO module, Long moduleId) {

		ModuleDetailsDTO existingModuleDetail = moduleDetailsCrudService.findByModuleId(tenantId, moduleId);
		if (Optional.ofNullable(existingModuleDetail).isPresent()) {
			moduleDetailsCrudService.update(existingModuleDetail.getPkid(),
					ModuleDetailsDTO.builder()
							.moduleId(moduleId)
							.annuality(module.getAnnuality())
							.contextFunction(module.getContextFunction())
							.forceReadOnlyContextFunction(module.getForceReadOnlyContextFunction())
							.dtValidityStart(module.getDtValidityStart())
							.dtValidityEnd(module.getDtValidityEnd())
							.build(),
					BundleConstants.BUNDLE_SYSTEM_USERNAME);
		} else {
			moduleDetailsCrudService.insert(ModuleDetailsDTO.builder()
					.moduleId(moduleId)
					.annuality(module.getAnnuality())
					.contextFunction(module.getContextFunction())
					.forceReadOnlyContextFunction(module.getForceReadOnlyContextFunction())
					.dtValidityStart(module.getDtValidityStart())
					.dtValidityEnd(module.getDtValidityEnd())
					.build(), BundleConstants.BUNDLE_SYSTEM_USERNAME);
		}

	}

	private void upsertModuleProfile(String tenantId, BundleModuleInDTO module, Long moduleId) {
		Optional.ofNullable(module.getModuleProfiles()).ifPresent(rpc -> rpc.forEach(profile -> {
			ModuleProfileDTO existingModuleProfile = moduleProfilesCrudService.find(tenantId, moduleId,
					profile.getPrfCode());

			if (Optional.ofNullable(existingModuleProfile).isEmpty()) {
				moduleProfilesCrudService.insert(ModuleProfileDTO.builder()
						.moduleId(moduleId)
						.profileCode(profile.getPrfCode())
						.labelExposed(profile.getLabelExposed())
						.build(), BundleConstants.BUNDLE_SYSTEM_USERNAME);
			} else {
				moduleProfilesCrudService.update(existingModuleProfile.getPkid(), ModuleProfileDTO.builder()
						.moduleId(moduleId)
						.profileCode(profile.getPrfCode())
						.labelExposed(profile.getLabelExposed())
						.build(), BundleConstants.BUNDLE_SYSTEM_USERNAME);
			}

			profile.getI18n()
					.stream()
					.forEachOrdered(val -> {
						Optional.ofNullable(existingModuleProfile).ifPresent(f -> {
							moduleProfilesCrudService.deleteModuleProfileI18N(tenantId, f.getProfileCode(),
									val.getLang());
						});
						if (!moduleProfilesCrudService.verifyI18NIsPresent(tenantId, profile.getPrfCode(),
								val.getLang(), val.getDescription())) {
							moduleProfilesCrudService.insertModuleProfileI18N(tenantId,
									profile.getPrfCode(),
									val.getLang(),
									val.getDescription());
						} else {
							log.warn("translation was already present");
						}

					});
		}));
	}

	private void upsertFormCatalogs(String tenantId, List<BundleFormCatalogInDTO> formCatalogs) {
		log.info("Invoking upsertFormCatalogs with params tenantId: {} formCatalogs: {}", tenantId, formCatalogs);
		Optional.ofNullable(formCatalogs)
				.ifPresent(fc -> fc.stream().forEachOrdered(formCatalog -> {
					FormCatalogDTO existingFormCatalog = formCatalogsCrudService.findByCodeNullable(tenantId,
							formCatalog.getFormCode());
					if (Optional.ofNullable(existingFormCatalog).isPresent()) {
						formCatalogsCrudService.update(existingFormCatalog.getId(), FormCatalogDTO
								.builder()
								.formCode(formCatalog.getFormCode())
								.softwareUrl(formCatalog.getSoftwareUrl())
								.routerUrl(formCatalog.getRouterUrl())
								.tenantId(tenantId)
								.build());
					} else {
						formCatalogsCrudService.insert(FormCatalogDTO.builder()
								.tenantId(tenantId)
								.formCode(formCatalog.getFormCode())
								.softwareUrl(formCatalog.getSoftwareUrl())
								.routerUrl(formCatalog.getRouterUrl())
								.build());
					}

					Optional.ofNullable(formCatalog.getI18n())
							.ifPresent(i18n -> i18n
									.stream()
									.forEachOrdered(val -> {
										Optional.ofNullable(existingFormCatalog).ifPresent(
												formCatalogI18n -> formCatalogsCrudService.deleteFormCatalogI18N(
														tenantId, formCatalog.getFormCode(),
														val.getLang()));
										formCatalogsCrudService.insertFormCatalogI18N(tenantId,
												formCatalog.getFormCode(),
												val.getLang(),
												val.getDescription());
									}));
				}));
	}

	/*
	 * Creating recursively new instances for FormGroups following a tree-like
	 * hierarchy:
	 * Basic case: the node does not have any childs (formGroupChilds)
	 * Inductive case: calling insertRecursiveFormGroups with the current tenantId,
	 * node's formGroupChilds and the newly created form group's id as parentId
	 */
	private void upsertRecursiveFormGroups(String tenantId, List<BundleFormGroupInDTO> formGroups, Long parentGroupId) {
		log.info("ModulesBundleWorker: upsertRecursiveFormGroups with tenant {} and formGroups {} parentGroupId: {}",
				tenantId, formGroups,
				parentGroupId);
		if (Optional.ofNullable(formGroups).isPresent()) {
			formGroups
					.stream()
					.forEachOrdered(formGroup -> {
						Long newParentGroupId;
						FormGroupDTO existingFormGroup = formGroupsCrudService.findFormGroupByCodeNullable(tenantId,
								formGroup.getFormGroupCode());
						if (Optional.ofNullable(existingFormGroup).isPresent()) {
							formGroupsCrudService.update(existingFormGroup.getId(), FormGroupDTO.builder()
									.tenantId(tenantId)
									.formGroupCode(existingFormGroup.getFormGroupCode())
									.parentFormGroupId(parentGroupId)
									.build());
							newParentGroupId = existingFormGroup.getId();
						} else {
							FormGroupDTO createdFormGroup = formGroupsCrudService.insert(FormGroupDTO.builder()
									.tenantId(tenantId)
									.formGroupCode(formGroup.getFormGroupCode())
									.parentFormGroupId(parentGroupId)
									.build());
							newParentGroupId = createdFormGroup.getId();

						}
						formGroup.getI18n()
								.stream()
								.forEachOrdered(val -> {
									Optional.ofNullable(existingFormGroup).ifPresent(f -> {
										formGroupsCrudService.deleteFormGroupI18N(tenantId, f.getFormGroupCode(),
												val.getLang());
									});
									formGroupsCrudService.insertFormGroupI18N(tenantId,
											formGroup.getFormGroupCode(),
											val.getLang(),
											val.getDescription());
								});
						this.upsertRecursiveFormGroups(tenantId, formGroup.getFormGroupChildren(), newParentGroupId);
					});
		}
	}

	private void upsertModuleFormConfigs(String tenantId, List<BundleModuleFormConfigsInDTO> moduleFormConfigs,
			Long moduleId) {
		log.info("Invoking upsertModuleFormConfigs with params tenantId: {} moduleFormConfigs: {} createModuleId: {}",
				tenantId,
				moduleFormConfigs, moduleId);
		Optional.ofNullable(moduleFormConfigs)
				.ifPresent(mfc -> mfc.forEach(moduleFormConfig -> {
					try {
						if (moduleFormConfig.getProcessStatus() != null
								&& (moduleFormConfig.getProcessStatusList() != null && !moduleFormConfig
										.getProcessStatusList().isEmpty())) {
							throw new IllegalStateException(
									"invalid input: cannot be present at same time process status and process status list!");
						}
						List<String> processStatusToUse = new ArrayList<>();
						if (moduleFormConfig.getProcessStatus() != null) {
							processStatusToUse.add(moduleFormConfig.getProcessStatus());
						} else {
							processStatusToUse.addAll(moduleFormConfig.getProcessStatusList());
						}
						insertOrUpdateModuleFormConfigs(tenantId, moduleId, moduleFormConfig, processStatusToUse);

					} catch (ObjectNotFoundException e) {
						throw new ObjectNotFoundRuntimeException(e.getMessage());
					}
				}));
	}

	private void insertOrUpdateModuleFormConfigs(String tenantId, Long moduleId,
			BundleModuleFormConfigsInDTO moduleFormConfig, List<String> processStatusToUse)
			throws ObjectNotFoundException {
		List<String> contextFunctionList = new ArrayList<>();
		if (moduleFormConfig.getContextFunctionList() != null && !moduleFormConfig.getContextFunctionList().isEmpty()) {
			log.info("context function list is not empty: will loop nxm by process status and context function");
			contextFunctionList.addAll(moduleFormConfig.getContextFunctionList());
			if (moduleFormConfig.getContextFunction() != null) {
				throw new IllegalStateException("both context function and context function list are present!");
			}
		}
		for (String currentProcessStatus : processStatusToUse) {
			if (!contextFunctionList.isEmpty()) {
				for (String currentContextFunction : moduleFormConfig.getContextFunctionList()) {
					moduleFormConfig.setContextFunction(currentContextFunction);
					upsertSingleModuleFormConfig(tenantId, moduleId, moduleFormConfig, currentProcessStatus);
				}
			} else {
				upsertSingleModuleFormConfig(tenantId, moduleId, moduleFormConfig, currentProcessStatus);
			}
		}
	}

	private void upsertSingleModuleFormConfig(String tenantId, Long moduleId,
			BundleModuleFormConfigsInDTO moduleFormConfig, String currentProcessStatus) throws ObjectNotFoundException {
		var formId = formCatalogsCrudService.findByCode(tenantId, moduleFormConfig.getFormCode()).getId();
		var formGroupId = formGroupsCrudService.findFormGroupByCode(tenantId, moduleFormConfig.getFormGroupCode())
				.getId();
		var bundleEntity = ModuleFormConfigsDTO.builder()
				.formId(formId)
				.formGroupId(formGroupId)
				.moduleId(moduleId)
				.processStatus(currentProcessStatus)
				.sortOrder(moduleFormConfig.getSortOrder())
				.flReadOnly(moduleFormConfig.getFlReadOnly())
				.compileStatusIdentifier(moduleFormConfig.getCompileStatusIdentifier())
				.contextFunction(moduleFormConfig.getContextFunction())
				.forceReadOnlyContextFunction(moduleFormConfig.getForceReadOnlyContextFunction())
				.build();

		ModuleFormConfigsDTO placeHolderToUse = moduleFormConfigsCrudService.insert(bundleEntity);

		// Creating new instances for ModuleFormConfigsParams
		this.insertOrUpdateModuleFormConfigParams(moduleFormConfig.getParams(), placeHolderToUse.getId());
		// Creating new instances for ModuleConfigProfiles
		this.insertOrUpdateModuleConfigProfiles(moduleFormConfig.getRequiredProfiles(), placeHolderToUse.getId());
	}

	private void insertOrUpdateModulePrintConfigParams(Map<String, String> params, Long modulePrintConfigId) {
		log.info("Invoking insertOrUpdateModulePrintConfigParams with params: {} modulePrintConfigId: {}", params,
				modulePrintConfigId);

		modulePrintConfigParamCrudService.deleteByModulePrintConfigId(modulePrintConfigId);
		Optional.ofNullable(params)
				.ifPresent(map -> map.forEach((key,
						value) -> modulePrintConfigParamCrudService.insert(ModulePrintConfigParamDTO.builder()
								.modulePrintConfigId(modulePrintConfigId)
								.parameterName(key)
								.parameterValue(value)
								.build())));
	}

	private void insertOrUpdateModuleCalculationConfigParams(Map<String, String> params,
			Long moduleCalculationConfigId) {
		log.info("Invoking insertOrUpdateModulePrintConfigParams with params: {} moduleCalculationConfigId: {}", params,
				moduleCalculationConfigId);

		moduleCalculationConfigParamCrudService.deleteByModuleCalculationConfigId(moduleCalculationConfigId);
		Optional.ofNullable(params)
				.ifPresent(map -> map.forEach((key, value) -> moduleCalculationConfigParamCrudService
						.insert(ModuleCalculationConfigParamDTO.builder()
								.moduleCalculationConfigId(moduleCalculationConfigId)
								.parameterName(key)
								.parameterValue(value)
								.build())));
	}

	private void insertOrUpdateModuleFormConfigParams(Map<String, String> params, Long createdModuleFormConfigId) {
		log.info("Invoking insertOrUpdateModuleFormConfigParams with params: {} createdModuleFormConfigId: {}", params,
				createdModuleFormConfigId);

		moduleFormConfigParamCrudService.deleteByModuleFormConfigId(createdModuleFormConfigId);
		Optional.ofNullable(params)
				.ifPresent(map -> map.forEach((key,
						value) -> moduleFormConfigParamCrudService.insert(ModuleFormConfigParamDTO.builder()
								.moduleFormConfigId(createdModuleFormConfigId)
								.parameterName(key)
								.parameterValue(value)
								.build())));
	}

	private void insertOrUpdatePrintConfigProfiles(List<String> requiredProfiles, Long modulePrintConfigId) {
		log.info("Invoking insertOrUpdatePrintConfigProfiles with params requiredProfiles: {} modulePrintConfigId: {}",
				requiredProfiles,
				modulePrintConfigId);
		modulePrintConfigProfilesCrudService.deleteByModulePrintConfigId(modulePrintConfigId);
		Optional.ofNullable(requiredProfiles).ifPresent(rpc -> rpc.forEach(profileCode -> {
			// Creating new instances for ModuleFormConfigsProfiles
			modulePrintConfigProfilesCrudService.insert(ModulePrintConfigProfileDTO.builder()
					.modulePrintConfigId(modulePrintConfigId)
					.requiredProfileCode(profileCode)
					.build());

		}));
	}

	private void insertOrUpdateCalculationConfigProfiles(List<String> requiredProfiles,
			Long moduleCalculationConfigId) {
		log.info(
				"Invoking insertOrUpdatePrintConfigProfiles with params requiredProfiles: {} moduleCalculationConfigId: {}",
				requiredProfiles,
				moduleCalculationConfigId);
		moduleCalculationConfigProfilesCrudService.deleteByModuleCalculationConfigId(moduleCalculationConfigId);
		Optional.ofNullable(requiredProfiles).ifPresent(rpc -> rpc.forEach(profileCode -> {
			// Creating new instances for ModuleFormConfigsProfiles
			moduleCalculationConfigProfilesCrudService.insert(ModuleCalculationConfigProfileDTO.builder()
					.moduleCalculationConfigId(moduleCalculationConfigId)
					.requiredProfileCode(profileCode)
					.build());

		}));
	}

	private void insertOrUpdateModuleConfigProfiles(List<String> requiredProfiles, Long createdModuleFormConfigId) {
		log.info(
				"Invoking insertOrUpdateModuleConfigProfiles with params requiredProfiles: {} createdModuleFormConfigId: {}",
				requiredProfiles,
				createdModuleFormConfigId);
		if (requiredProfiles != null && requiredProfiles.size() > 1) {
			System.out.println("qui");
		}
		moduleFormConfigProfilesCrudService.deleteByModuleFormConfigId(createdModuleFormConfigId);
		Optional.ofNullable(requiredProfiles).ifPresent(rpc -> rpc.forEach(profileCode -> {
			// Creating new instances for ModuleFormConfigsProfiles
			moduleFormConfigProfilesCrudService.insert(ModuleFormConfigProfileDTO.builder()
					.moduleFormConfigId(createdModuleFormConfigId)
					.requiredProfileCode(profileCode)
					.build());

		}));
	}

	public void deleteBundleModules(String tenantId, BundleModulesMessage message) {
		log.info("ModulesBundleWorker: processing file with tenant {}", tenantId);
		message.getModules()
				.stream()
				.forEachOrdered(module -> this.deleteModuleAndRelationships(tenantId, module));
	}

	private void deleteModuleAndRelationships(String tenantId, BundleModuleInDTO module) {
		moduleCrudService.findByModuleCodeAndSectorCode(tenantId, module.getModuleCode(), module.getSectorCode())
				.ifPresent(moduleDTO -> {
					amendableModuleCrudService.findByModuleId(moduleDTO.getModuleId())
							.forEach(x -> amendableModuleCrudService.delete(x.getPkid(),
									BundleConstants.BUNDLE_SYSTEM_USERNAME));
					amendableModuleCrudService.findByAmendableModuleId(tenantId, moduleDTO.getModuleId())
							.forEach(x -> amendableModuleCrudService.delete(x.getPkid(),
									BundleConstants.BUNDLE_SYSTEM_USERNAME));
					childModuleCrudService.findByModuleId(moduleDTO.getModuleId()).forEach(
							x -> childModuleCrudService.delete(x.getPkid(), BundleConstants.BUNDLE_SYSTEM_USERNAME));
					childModuleCrudService.findByParentModuleId(moduleDTO.getModuleId()).forEach(
							x -> childModuleCrudService.delete(x.getPkid(), BundleConstants.BUNDLE_SYSTEM_USERNAME));
					moduleCrudService.delete(moduleDTO.getModuleId(), BundleConstants.BUNDLE_SYSTEM_USERNAME);
					moduleDetailsCrudService.deleteByModuleId(moduleDTO.getModuleId(),
							BundleConstants.BUNDLE_SYSTEM_USERNAME);
					moduleProfilesCrudService.deleteByModuleId(moduleDTO.getModuleId(),
							BundleConstants.BUNDLE_SYSTEM_USERNAME);
					moduleFormConfigProfilesCrudService.bulkDeleteByModuleId(moduleDTO.getModuleId());
					moduleFormConfigParamCrudService.bulkDeleteByModuleId(moduleDTO.getModuleId());
					moduleFormConfigsCrudService.bulkDeleteByModuleId(moduleDTO.getModuleId());
				});
	}

}
