package com.abacogroup.agri.applications.bundles.model.module;

import com.abacogroup.agri.applications.bundles.model.I18nPair;
import com.abacogroup.agri.applications.bundles.model.form.BundleFormsInDTO;
import com.abacogroup.agri.applications.bundles.model.form.BundleModuleCalculationInDTO;
import com.abacogroup.agri.applications.bundles.model.form.BundleModulePrintInDTO;
import com.abacogroup.agri.applications.bundles.model.form.BundleModuleProfileInDTO;
import com.abacogroup.agri.applications.core.model.AbsoluteDate;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * @author Alexandru Paraschiv
 * @author Gennaro Tamburrelli
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class BundleModuleInDTO {
	private String moduleCode;
	private String sectorCode;
	private String workflowCode;
	private Integer annuality;
	private String contextFunction;
	private String forceReadOnlyContextFunction;
	private AbsoluteDate dtValidityStart;
	private AbsoluteDate dtValidityEnd;
	private List<I18nPair> i18n;
	private BundleFormsInDTO forms;
	private List<BundleModuleProfileInDTO> moduleProfiles;
	private List<BundleModulePrintInDTO> modulePrints;
	private List<BundleModuleCalculationInDTO> moduleCalculations;
	private Boolean flAmendModule;
	private Boolean flChildModule;
}
