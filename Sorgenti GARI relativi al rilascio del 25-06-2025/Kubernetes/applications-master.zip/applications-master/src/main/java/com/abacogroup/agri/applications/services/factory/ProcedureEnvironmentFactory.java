package com.abacogroup.agri.applications.services.factory;

import java.util.Map;
import java.util.function.Function;

import org.jdbi.v3.core.Jdbi;

import com.abacogroup.applicationworkflowsdk.environment.AgriProcedureEnvironment;
import com.abacogroup.applicationworkflowsdk.v2.IAgriProcedureEnvironment;
import com.abacogroup.workflow.sdk.beans.ProcessData;
import com.abacogroup.workflow.server.services.ProcessService;

import jakarta.ws.rs.client.Client;

/**
 * @author Gennaro Tamburrelli
 */
public class ProcedureEnvironmentFactory {

	private final Jdbi jdbi;
	private Map<String, Jdbi> procedureEnironmentJdbis;
	private final Client client;
	private final String environmentId;

	public ProcedureEnvironmentFactory(Jdbi jdbi, Map<String, Jdbi> procedureEnironmentJdbis, Client client, String environmentId) {
		this.jdbi = jdbi;
		this.procedureEnironmentJdbis = procedureEnironmentJdbis;
		this.client = client;
		this.environmentId = environmentId;
	}

	// Visible for testing
	IAgriProcedureEnvironment createProcedureEnvironment(Map<String, Object> utils) {
		return new AgriProcedureEnvironment(procedureEnironmentJdbis, client, utils, environmentId);
	}

	public ProcessService<IAgriProcedureEnvironment> createProcessService(Map<String, Object> utils) {
		Function<ProcessData, IAgriProcedureEnvironment> dummyFunc = data -> this.createProcedureEnvironment(utils);
		return new ProcessService<>(this.jdbi, IAgriProcedureEnvironment.class, dummyFunc);
	}
}
