package com.abacogroup.agri.applications.db.ntt;

import com.abacogroup.agri.applications.db.ntt.applications.IHistoricizationFields;
import com.abacogroup.agri.applications.db.ntt.applications.IIdRs;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.Optional;

/**
 * @author Mauro Pozzana
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ApplicationCompileStatusNTT implements IIdRs<Long>, IHistoricizationFields {

	private Long pkid;
	private Long application_id;
	private String compile_status_identifier;
	private String status;
	private String user_id_insert;
	private String user_id_delete;
	private LocalDateTime dt_insert;
	private LocalDateTime dt_delete;

	@Override
	public void setKey(Long id) {
		this.pkid = id;
	}

	@Override
	public Optional<Long> getKey() {
		return Optional.ofNullable(this.pkid);
	}

}
