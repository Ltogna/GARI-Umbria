package com.abacogroup.agri.applications.core.mappers;

import com.abacogroup.agri.applications.core.model.dto.ApplicationsRelationDTO;
import com.abacogroup.agri.applications.db.ntt.ApplicationsRelationNTT;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

@Mapper
public interface ApplicationsRelationMapper extends EntityMapper<ApplicationsRelationDTO, ApplicationsRelationNTT> {

	ApplicationsRelationMapper INSTANCE = Mappers.getMapper(ApplicationsRelationMapper.class);

	@InheritInverseConfiguration()
	ApplicationsRelationDTO entityToDto(ApplicationsRelationNTT entity);

	@Mapping(source = "pkid", target = "pkid")
	@Mapping(source = "parentApplicationId", target = "parent_application_id")
	@Mapping(source = "childApplicationId", target = "child_application_id")
	@Mapping(source = "userIdInsert", target = "user_id_insert")
	@Mapping(source = "userIdDelete", target = "user_id_delete")
	@Mapping(source = "dtInsert", target = "dt_insert")
	@Mapping(source = "dtDelete", target = "dt_delete")
    ApplicationsRelationNTT dtoToEntity(ApplicationsRelationDTO dto);

}
