package com.abacogroup.agri.applications.core.exceptions;

import io.swagger.v3.oas.annotations.media.Schema;

import jakarta.ws.rs.core.Response;

public class NoModulesFoundAtDateRuntimeException extends AbstractException {

	private static final NoModulesFoundAtDateRuntimeException.ErrorBody BODY = new NoModulesFoundAtDateRuntimeException.ErrorBody();

	public NoModulesFoundAtDateRuntimeException(String message) {
		super(Response.Status.NOT_FOUND, BODY, message);
	}

	public NoModulesFoundAtDateRuntimeException() {
		super(Response.Status.NOT_FOUND, BODY, "No modules found");
	}

	@Schema(name = "NoModulesFoundAtDateRuntimeExceptionErrorBody")
	public static class ErrorBody implements ExceptionErrorBody {
		private static final String ERR = "NO_MODULES_FOUND_AT_DATE";

		@Override
		@Schema(allowableValues = ERR)
		public String getErrorCode() {
			return ERR;
		}
	}
}
