package com.abacogroup.agri.applications;

import static com.abacogroup.agri.applications.core.services.calculation.CalculationService.CALCULATOR_DESTINATION;
import static com.abacogroup.agri.applications.core.services.print.PrintService.PRINT_DESTINATION;
import static com.abacogroup.applicationworkflowsdk.model.Constants.GENERIC_CALLER_SERVICE_KEY;

import java.io.IOException;
import java.net.URI;
import java.sql.DatabaseMetaData;
import java.util.Arrays;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeoutException;

import com.abacogroup.agri.applications.core.model.ApplicationQueuePayload;
import com.abacogroup.agri.applications.core.services.appexchange.ApplicationsExchangeFactory;
import com.abacogroup.agri.applications.core.services.appexchange.ApplicationsMessageListener;
import com.abacogroup.agri.applications.core.services.embededqueue.*;
import com.abacogroup.agri.applications.core.services.monitoringexchange.MonitoringMessageListener;
import com.abacogroup.agri.applications.core.services.workflow.*;
import org.apache.commons.lang3.StringUtils;
import org.eclipse.jetty.servlets.CrossOriginFilter;
import org.glassfish.jersey.media.multipart.MultiPartFeature;
import org.jdbi.v3.core.Jdbi;
import org.jdbi.v3.core.statement.Slf4JSqlLogger;
import org.jdbi.v3.sqlobject.SqlObjectPlugin;
import org.locationtech.jts.geom.Geometry;

import com.abacogroup.agri.applications.bundles.model.BundleConfig;
import com.abacogroup.agri.applications.bundles.processor.amendable.AmendableModuleNewTenantProcessor;
import com.abacogroup.agri.applications.bundles.processor.amendable.AmendableModulesBundleWorker;
import com.abacogroup.agri.applications.bundles.processor.amendable.BundleAmendableModulesProcessor;
import com.abacogroup.agri.applications.bundles.processor.anomaly.AnomalyCatalogBundleWorker;
import com.abacogroup.agri.applications.bundles.processor.anomaly.AnomalyCatalogNewTenantProcessor;
import com.abacogroup.agri.applications.bundles.processor.anomaly.BundleAnomalyCatalogProcessor;
import com.abacogroup.agri.applications.bundles.processor.childmodule.BundleChildrenModulesProcessor;
import com.abacogroup.agri.applications.bundles.processor.childmodule.ChildModuleNewTenantProcessor;
import com.abacogroup.agri.applications.bundles.processor.childmodule.ChildrenModulesBundleWorker;
import com.abacogroup.agri.applications.bundles.processor.env.ApplicationEnvBundleWorker;
import com.abacogroup.agri.applications.bundles.processor.env.ApplicationEnvNewTenantProcessor;
import com.abacogroup.agri.applications.bundles.processor.env.BundleApplicationEnvProcessor;
import com.abacogroup.agri.applications.bundles.processor.module.BundleModulesProcessor;
import com.abacogroup.agri.applications.bundles.processor.module.ModuleNewTenantProcessor;
import com.abacogroup.agri.applications.bundles.processor.module.ModulesBundleWorker;
import com.abacogroup.agri.applications.bundles.processor.sector.BundleSectorsProcessor;
import com.abacogroup.agri.applications.bundles.processor.sector.SectorNewTenantProcessor;
import com.abacogroup.agri.applications.bundles.processor.sector.SectorsBundleWorker;
import com.abacogroup.agri.applications.bundles.processor.workflow.BundleWorkflowsProcessor;
import com.abacogroup.agri.applications.bundles.processor.workflow.WorkflowNewTenantProcessor;
import com.abacogroup.agri.applications.bundles.processor.workflow.WorkflowsBundleWorker;
import com.abacogroup.agri.applications.core.caller.*;
import com.abacogroup.agri.applications.core.mappers.*;
import com.abacogroup.agri.applications.core.model.QueueProcessorConfig;
import com.abacogroup.agri.applications.core.model.RabbitMqConfig;
import com.abacogroup.agri.applications.core.services.*;
import com.abacogroup.agri.applications.core.services.calculation.CalculationMessageListener;
import com.abacogroup.agri.applications.core.services.calculation.CalculationService;
import com.abacogroup.agri.applications.core.services.crud.*;
import com.abacogroup.agri.applications.core.services.print.PrintMessageListener;
import com.abacogroup.agri.applications.core.services.print.PrintService;
import com.abacogroup.agri.applications.core.services.protocol.ProtocolListener;
import com.abacogroup.agri.applications.core.services.workflow.sdkimpl.*;
import com.abacogroup.agri.applications.db.dao.*;
import com.abacogroup.agri.applications.resources.ApplicationsPrivateResources;
import com.abacogroup.agri.applications.resources.ApplicationsPublicResources;
import com.abacogroup.agri.applications.resources.PrintPublicResources;
import com.abacogroup.agri.applications.services.factory.ProcedureEnvironmentFactory;
import com.abacogroup.agri.applications.utils.DbUtils;
import com.abacogroup.agri.applications.utils.DevAuthenticator;
import com.abacogroup.agri.applications.utils.DevAuthorizer;
import com.abacogroup.agri.applications.utils.DevFilter;
import com.abacogroup.agri.applications.utils.WKTGeometryDeserializer;
import com.abacogroup.agri.applications.utils.WKTGeometrySerializer;
import com.abacogroup.applicationworkflowsdk.caller.factory.CallerFactory;
import com.abacogroup.applicationworkflowsdk.service.*;
import com.abacogroup.applicationworkflowsdk.v2.IAgriProcedureEnvironment;
import com.abacogroup.bundles.initializer.BundleInitServiceBuilder;
import com.abacogroup.bundles.listener.ListenerBuilder;
import com.abacogroup.bundles.listener.configdata.ProcessorOrderPolicyEnum;
import com.abacogroup.bundles.listener.configdata.builder.ConfigDataConsumerBuilder;
import com.abacogroup.bundles.listener.tenant.builder.NewTenantEventConsumerBuilder;
import com.abacogroup.dropwizard.auth.sso2.AuthUtils;
import com.abacogroup.dropwizard.auth.sso2.Sso2Client;
import com.abacogroup.dropwizard.auth.sso2.SsoAuthorizer;
import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.embeddedqueue.db.JdbiRepository;
import com.abacogroup.filestore.client.FileStoreClient;
import com.abacogroup.jaxrsutils.GenericCallerService;
import com.abacogroup.jaxrsutils.filter.MDCPostFilter;
import com.abacogroup.jaxrsutils.filter.MDCPreFilter;
import com.abacogroup.jaxrsutils.model.AbacoTechUser;
import com.abacogroup.jdbi.OraJdbiPlugin;
import com.abacogroup.jdbi.PgJdbiPlugin;
import com.abacogroup.jdbi.config.AbacoJdbiConfig;
import com.abacogroup.tracing.dropwizard.AbacoApplication;
import com.abacogroup.workflow.server.services.ProcessService;
import com.abacogroup.workflow.server.services.TimerScheduledQueue;
import com.abacogroup.workflow.server.services.WorkflowService;
import com.fasterxml.jackson.core.Version;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.databind.module.SimpleModule;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;

import io.dropwizard.auth.AuthValueFactoryProvider;
import io.dropwizard.auth.AuthenticationException;
import io.dropwizard.client.JerseyClientBuilder;
import io.dropwizard.client.JerseyClientConfiguration;
import io.dropwizard.configuration.EnvironmentVariableSubstitutor;
import io.dropwizard.configuration.SubstitutingSourceProvider;
import io.dropwizard.core.setup.Bootstrap;
import io.dropwizard.core.setup.Environment;
import io.dropwizard.db.DataSourceFactory;
import io.dropwizard.jdbi3.JdbiFactory;
import io.dropwizard.jdbi3.bundles.JdbiExceptionsBundle;
import io.dropwizard.migrations.MigrationsBundle;
import io.swagger.v3.jaxrs2.integration.resources.OpenApiResource;
import io.swagger.v3.oas.integration.ClasspathOpenApiConfigurationLoader;
import io.swagger.v3.oas.integration.api.OpenAPIConfiguration;
import jakarta.servlet.DispatcherType;
import jakarta.servlet.FilterRegistration.Dynamic;
import jakarta.ws.rs.client.Client;
import lombok.extern.slf4j.Slf4j;
import oracle.jdbc.OracleConnection;

@Slf4j
public class ApplicationsModuleApplication extends AbacoApplication<ApplicationsModuleConfiguration> {
	private static final String FORMS_DB_NAME = "FORMS";

	public static void main(String[] args) {
		try {
			new ApplicationsModuleApplication().run(args);
		} catch (Exception e) {
			log.error("Error during run applications app: ", e);
			System.exit(1);
		}
	}

	@Override
	public void initialize(Bootstrap<ApplicationsModuleConfiguration> bootstrap) {
		bootstrap.addBundle(new JdbiExceptionsBundle());
		bootstrap.addBundle(new MigrationsBundle<>() {
			@Override
			public DataSourceFactory getDataSourceFactory(ApplicationsModuleConfiguration configuration) {
				return configuration.getDatabase();
			}
		});
		SubstitutingSourceProvider provider = new SubstitutingSourceProvider(bootstrap.getConfigurationSourceProvider(),
				new EnvironmentVariableSubstitutor(false));
		bootstrap.setConfigurationSourceProvider(provider);
	}

	@Override
	public void doRun(ApplicationsModuleConfiguration config, Environment environment) throws Exception {
		ObjectMapper objectMapper = environment.getObjectMapper();
		configure(objectMapper);

		final Jdbi jdbi = getJdbi(config.getDatabase(), environment, "applications", "apps", true);

		Map<String, Jdbi> procedureEnironmentJdbis = new HashMap<>();
		if (!"DISABLED".equals(config.getDatabaseForms().getUrl())) {
			final Jdbi jdbiForms = getJdbi(config.getDatabaseForms(), environment, FORMS_DB_NAME, null, false);
			procedureEnironmentJdbis.put(FORMS_DB_NAME, jdbiForms);
		}

		createAdditionalDatabases(config.getAdditionalDatabases(), environment, procedureEnironmentJdbis);

		// DAOs Initialization
		DAOContainer daoContainer = buildDAOContainer(jdbi);

		// build http client
		JerseyClientConfiguration clientConfig = config.getJerseyClientConfiguration();
		final Client client = new JerseyClientBuilder(environment).using(clientConfig)
				.build(getName());

		// SSO2 Client
		Sso2Client sso2Client = new Sso2Client(config.getSso2TokenSecretAuth(), client.target(config.getSso2Url()));

		initBundlesListenerAndResources(config, environment, objectMapper, jdbi, procedureEnironmentJdbis, daoContainer, client, sso2Client);

		environment.jersey().register(new MDCPreFilter());
		environment.jersey().register(new MDCPostFilter());
		environment.jersey().register(MultiPartFeature.class);

		registerAuthFilters(sso2Client, config, environment);

		// register cors filter
		setupCORS(environment);

		// init open api
		initOpenApi(environment);

	}

	private void createAdditionalDatabases(String additionalDatabases, Environment environment, Map<String, Jdbi> procedureEnironmentJdbis) {
		if (additionalDatabases == null || additionalDatabases.isBlank() || additionalDatabases.equalsIgnoreCase("NONE")) {
			log.info("No additional databases defined.");
			return;
		}

		String[] databases = additionalDatabases.split("\\,");
		Arrays.stream(databases)
				.map(String::trim)
				.filter(s -> !s.isEmpty())
				.map(String::toUpperCase)
				.forEach(dbName -> {
					if (FORMS_DB_NAME.equals(dbName)) {
						throw new IllegalArgumentException("Cannot have an additional DB named: " + FORMS_DB_NAME);
					}

					DataSourceFactory factory = new DataSourceFactory();
					factory.setDriverClass(System.getenv("JDBC_DRIVER_" + dbName));
					factory.setUrl(System.getenv("JDBC_URL_" + dbName));
					factory.setUser(System.getenv("JDBC_USER_" + dbName));
					factory.setPassword(System.getenv("JDBC_PASSWORD_" + dbName));
					factory.setValidationQuery(System.getenv("JDBC_VALIDATION_QUERY_" + dbName));
					factory.setMinSize(1);
					factory.setInitialSize(1);

					log.info("Preparing additional database {}.", dbName);
					final Jdbi jdbi = getJdbi(factory, environment, dbName, null, false);
					procedureEnironmentJdbis.put(dbName, jdbi);
					log.info("Additional database {} prepared.", dbName);
				});
	}

	private void initBundlesListenerAndResources(ApplicationsModuleConfiguration config, Environment environment, ObjectMapper objectMapper, final Jdbi jdbi,
			Map<String, Jdbi> procedureEnironmentJdbis, DAOContainer daoContainer, final Client client, Sso2Client sso2Client) throws IOException {
		GenericCallerService genericCallerService = new GenericCallerService(client, new AbacoTechUser());

		FileStoreClient fileStoreClient = new FileStoreClient(URI.create(config.getFileStoreUrl()), objectMapper);
		FileStoreService fileStoreService = new FileStoreService(fileStoreClient);

		AuthContextFactory authContextFactory = new AuthContextFactory(sso2Client);
		FileFactory fileFactory = new FileFactory();

		// caller
		CallerContainer callerContainer = buildCallerContainer(genericCallerService);

		CrudServiceContainer crudServiceContainer = buildCrudServiceContainer(daoContainer);

		// Service init
		ConfigService configService = new ConfigService(crudServiceContainer.getApplicationEnvCrudService());
		PartyService partyService = new PartyService(configService, callerContainer.getGetPartiesCaller(), callerContainer.getGetPartyByPartyIdCaller(),
				callerContainer.getGetPartiesRegistryCaller(), callerContainer.getGetPartyRegistryByPartyIdCaller(), config.getOverridePartyHostConfig());

		// ResetIsInTransitionProcessQueue resetIsInTransitionProcessQueue = new ResetIsInTransitionProcessQueue(jdbiRepository, objectMapper,
		// environment.metrics(),
		// applicationDetailsCrudService, queueProcessorConfig.getNumThreads(), queueProcessorConfig.getTimeoutMs());

		AmendmentService amendmentService = new AmendmentService(crudServiceContainer.getModuleCrudService(), crudServiceContainer.getApplicationsCrudService(),
				crudServiceContainer.getAmendableModuleCrudService(), crudServiceContainer.getApplicationDetailsCrudService());

		FormConfigService formConfigService = new FormConfigService(crudServiceContainer);
		// Workflow
		WorkflowService workflowService = new WorkflowService(jdbi);
		ProcedureEnvironmentFactory procedureEnvironmentFactory = new ProcedureEnvironmentFactory(jdbi, procedureEnironmentJdbis, client,
				config.getEnvironmentId());

		// Workflow services
		ApplicationProfilesService applicationProfilesService = new ApplicationProfilesService(jdbi, crudServiceContainer);

		CheckPartyService checkPartyService = new CheckPartyService(callerContainer.getCheckCanReadPartyCaller(),
				crudServiceContainer.getApplicationEnvCrudService(), config.getCheckCanReadConfig(), config.getCheckCanReadAllPartiesConfig());

		Map<String, Object> utilsMap = buildUtilsMap(sso2Client, crudServiceContainer, genericCallerService, formConfigService, workflowService,
				applicationProfilesService);

		ProcessService<IAgriProcedureEnvironment> processService = procedureEnvironmentFactory.createProcessService(utilsMap); // listener is added later

		ApplicationsWorkflowService applicationsWorkflowService = new ApplicationsWorkflowService(workflowService, processService, authContextFactory,
				fileFactory, crudServiceContainer.getApplicationProfilesCrudService());

		ForceReadOnlyContextCheckerService forceReadOnlyContextCheckerService = new ForceReadOnlyContextCheckerService(
				crudServiceContainer.getApplicationsCrudService(),
				crudServiceContainer.getModuleCrudService(), sso2Client);

		PrintService printService = new PrintService(crudServiceContainer, checkPartyService, applicationsWorkflowService,
				callerContainer.getCreatePrintJobCaller(), fileStoreService, config.getPrintsBucket(), config.getPrintEngineUrl(),
				forceReadOnlyContextCheckerService, partyService);
		PrintUtilsImpl printUtils = new PrintUtilsImpl(crudServiceContainer.getApplicationsCrudService(),
				crudServiceContainer.getApplicationProfilesCrudService(), printService, sso2Client);
		utilsMap.put(PrintUtils.KEY, printUtils); // put in utils map

		CalculationService calculationService = new CalculationService(crudServiceContainer, checkPartyService,
				applicationsWorkflowService, callerContainer.getCreateCalculatorJobCaller(),
				callerContainer.getGetCalculatorRawResultJobCaller(), callerContainer.getGetCalculatorRenderResultJobCaller(), config.getCalculatorEngineUrl(),
				forceReadOnlyContextCheckerService);

		CalculationUtilsImpl calculationUtilsImpl = new CalculationUtilsImpl(crudServiceContainer.getApplicationsCrudService(),
				crudServiceContainer.getApplicationProfilesCrudService(), calculationService, sso2Client, objectMapper);
		utilsMap.put(CalculationUtils.KEY, calculationUtilsImpl); // put in utils map

		HistoryService historyService = new HistoryService(crudServiceContainer.getApplicationsCrudService(), checkPartyService, applicationsWorkflowService);
		ApplicationProtocolUtilsImpl applicationProtocolUtils = new ApplicationProtocolUtilsImpl(crudServiceContainer, historyService);
		utilsMap.put(ApplicationProtocolUtils.KEY, applicationProtocolUtils); // put in utils map

		QueueContainer queueContainer = buildQueueContainer(jdbi, config, environment, objectMapper, authContextFactory, crudServiceContainer,
				applicationsWorkflowService, processService);

		ProgressService progressService = new ProgressService(jdbi, applicationsWorkflowService, crudServiceContainer.getApplicationsCrudService(),
				crudServiceContainer.getApplicationDetailsCrudService(), queueContainer.getUpdateProcessQueue(),
				forceReadOnlyContextCheckerService);

		ApplicationAmendWaiveImpl applicationAmend = new ApplicationAmendWaiveImpl(progressService, crudServiceContainer.getApplicationDetailsCrudService());
		utilsMap.put(AmendApplication.KEY, applicationAmend); // put in utils map
		utilsMap.put(WaiveApplication.KEY, applicationAmend); // put in utils map

		ApplicationsService applicationsService = new ApplicationsService(jdbi, applicationsWorkflowService, checkPartyService, partyService,
				crudServiceContainer, queueContainer.getCreateProcessQueue(), progressService, formConfigService, amendmentService, printService,
				historyService, calculationService, config.getCustomApplicationIdGenerationConfig(), callerContainer.getCreateCustomApplicationIdCaller(),
				forceReadOnlyContextCheckerService);
		AnomaliesService anomaliesService = new AnomaliesService(applicationsService, crudServiceContainer);

		applicationsService.setAnomaliesService(anomaliesService);

		utilsMap.put(CreateApplicationUtils.KEY, applicationsService); // put in utils map

		ApplicationDetailsRetrieverImpl applicationDetailsRetriever = new ApplicationDetailsRetrieverImpl(crudServiceContainer.getApplicationsCrudService(),
				applicationsService,
				sso2Client);
		utilsMap.put(ApplicationDetailsRetriever.KEY, applicationDetailsRetriever); // put in utils map

		CheckForMultipleApplicationImpl checkForMultipleApplication = new CheckForMultipleApplicationImpl(anomaliesService,
				crudServiceContainer.getApplicationsCrudService(),
				crudServiceContainer.getModuleCrudService());
		utilsMap.put(CheckForMultipleApplications.KEY, checkForMultipleApplication); // put in utils map

		initBundlesAndListener(config, objectMapper, jdbi, crudServiceContainer, formConfigService, applicationsWorkflowService, queueContainer, processService,
				environment);

		// Resources Registration
		initResources(environment, configService, amendmentService, formConfigService, applicationProfilesService, checkPartyService, utilsMap, printService,
				calculationService, calculationUtilsImpl, applicationsService);
	}

	private CrudServiceContainer buildCrudServiceContainer(DAOContainer daoContainer) {
		I18NService i18NService = new I18NService(daoContainer.getI18NDAO());

		return CrudServiceContainer.builder()
				.sectorsCrudService(new SectorsCrudService(daoContainer.getSectorDAO(), SectorMapper.INSTANCE, i18NService))
				.moduleCrudService(new ModuleCrudService(daoContainer.getModuleDAO(), ModuleMapper.INSTANCE, i18NService))
				.moduleDetailsCrudService(new ModuleDetailsCrudService(daoContainer.getModuleDetailsDAO(), ModuleDetailsMapper.INSTANCE))
				.applicationDetailsCrudService(new ApplicationDetailsCrudService(daoContainer.getApplicationDetailsDAO(), ApplicationDetailsMapper.INSTANCE))
				.applicationsCrudService(new ApplicationsCrudService(daoContainer.getApplicationDAO(), ApplicationMapper.INSTANCE))
				.applicationEnvCrudService(new ApplicationEnvCrudService(daoContainer.getApplicationEnvDAO(), ApplicationEnvMapper.INSTANCE))
				.applicationProfilesCrudService(
						new ApplicationProfilesCrudService(daoContainer.getApplicationProfileDAO(), ApplicationProfileMapper.INSTANCE, i18NService))
				.formCatalogsCrudService(new FormCatalogsCrudService(daoContainer.getFormCatalogDAO(), FormCatalogMapper.INSTANCE, i18NService))
				.moduleFormConfigsCrudService(new ModuleFormConfigsCrudService(daoContainer.getModuleFormConfigsDAO(), ModuleFormConfigsMapper.INSTANCE))
				.formGroupsCrudService(new FormGroupsCrudService(daoContainer.getFormGroupDAO(), FormGroupMapper.INSTANCE, i18NService))
				.moduleFormConfigParamCrudService(
						new ModuleFormConfigParamCrudService(daoContainer.getModuleFormConfigParamDAO(), ModuleFormConfigParamMapper.INSTANCE))
				.moduleProfilesCrudService(new ModuleProfilesCrudService(daoContainer.getModuleProfilesDAO(), ModuleProfileMapper.INSTANCE, i18NService))
				.applicationCompileStatusCrudService(
						new ApplicationCompileStatusCrudService(daoContainer.getApplicationCompileStatusDAO(), ApplicationCompileStatusMapper.INSTANCE))
				.anomaliesCrudService(new AnomaliesCrudService(daoContainer.getAnomalyDAO(), AnomalyMapper.INSTANCE))
				.anomalyCatalogCrudService(new AnomalyCatalogCrudService(daoContainer.getAnomalyCatalogDAO(), AnomalyCatalogMapper.INSTANCE, i18NService))
				.modulePrintConfigsCrudService(
						new ModulePrintConfigsCrudService(daoContainer.getModulePrintConfigsDAO(), ModulePrintConfigsMapper.INSTANCE, i18NService))
				.modulePrintConfigProfilesCrudService(
						new ModulePrintConfigProfilesCrudService(daoContainer.getModulePrintConfigProfileDAO(), ModulePrintConfigProfileMapper.INSTANCE))
				.modulePrintConfigParamCrudService(
						new ModulePrintConfigParamCrudService(daoContainer.getModulePrintConfigParamDAO(), ModulePrintConfigParamMapper.INSTANCE))
				.applicationGeneratedPrintCrudService(
						new ApplicationGeneratedPrintCrudService(daoContainer.getApplicationGeneratedPrintDAO(), ApplicationGeneratedPrintMapper.INSTANCE))
				.moduleCalculationConfigsCrudService(new ModuleCalculationConfigsCrudService(daoContainer.getModuleCalculationConfigsDAO(),
						ModuleCalculationConfigsMapper.INSTANCE, i18NService))
				.moduleCalculationConfigParamCrudService(new ModuleCalculationConfigParamCrudService(daoContainer.getModuleCalculationConfigParamDAO(),
						ModuleCalculationConfigParamMapper.INSTANCE))
				.moduleCalculationConfigProfilesCrudService(new ModuleCalculationConfigProfilesCrudService(
						daoContainer.getModuleCalculationConfigProfileDAO(), ModuleCalculationConfigProfileMapper.INSTANCE))
				.applicationGeneratedCalculationCrudService(new ApplicationGeneratedCalculationCrudService(
						daoContainer.getApplicationGeneratedCalculationDAO(), ApplicationGeneratedCalculationMapper.INSTANCE))
				.applicationProtocolsCrudService(
						new ApplicationProtocolsCrudService(daoContainer.getApplicationProtocolsDAO(), ApplicationProtocolsMapper.INSTANCE))
				.amendableModuleCrudService(new AmendableModuleCrudService(daoContainer.getAmendableModuleDAO(), AmendableModuleMapper.INSTANCE))
				.moduleFormConfigProfilesCrudService(
						new ModuleFormConfigProfilesCrudService(daoContainer.getModuleFormConfigProfileDAO(), ModuleFormConfigProfileMapper.INSTANCE))
				.childModuleCrudService(new ChildModuleCrudService(daoContainer.getChildrenModulesDAO(), ChildModuleMapper.INSTANCE))
				.applicationsRelationCrudService(
						new ApplicationsRelationCrudService(daoContainer.getApplicationsRelationsDAO(), ApplicationsRelationMapper.INSTANCE))
				.build();

	}

	private void initResources(Environment environment, ConfigService configService, AmendmentService amendmentService, FormConfigService formConfigService,
			ApplicationProfilesService applicationProfilesService, CheckPartyService checkPartyService, Map<String, Object> utilsMap, PrintService printService,
			CalculationService calculationService, CalculationUtilsImpl calculationUtilsImpl, ApplicationsService applicationsService) {
		environment.jersey().register(
				new ApplicationsPublicResources(applicationsService, applicationProfilesService, formConfigService,
						(AnomalyHandlerImpl) utilsMap.get(AnomalyHandler.KEY),
						(SetPresentationDateServiceImpl) utilsMap.get(SetApplicationPresentationDate.KEY),
						checkPartyService, calculationService, calculationUtilsImpl));
		environment.jersey().register(new PrintPublicResources(applicationsService, printService));
		environment.jersey()
				.register(new ApplicationsPrivateResources(applicationsService, configService, formConfigService, printService,
						(AnomalyHandlerImpl) utilsMap.get(AnomalyHandler.KEY), amendmentService, calculationService));
	}

	private void initBundlesAndListener(ApplicationsModuleConfiguration config, ObjectMapper objectMapper, final Jdbi jdbi,
			CrudServiceContainer crudServiceContainer, FormConfigService formConfigService,
			ApplicationsWorkflowService applicationsWorkflowService, QueueContainer queueContainer, ProcessService<?> processService, Environment environment)
			throws IOException {

		// RabbitMQ queue configuration
		WorkflowsBundleWorker workflowsBundleWorker = new WorkflowsBundleWorker(applicationsWorkflowService);
		SectorsBundleWorker sectorsBundleWorker = new SectorsBundleWorker(crudServiceContainer.getSectorsCrudService());
		ModulesBundleWorker modulesBundleWorker = new ModulesBundleWorker(crudServiceContainer, formConfigService);
		AnomalyCatalogBundleWorker anomalyCatalogBundleWorker = new AnomalyCatalogBundleWorker(crudServiceContainer.getAnomalyCatalogCrudService(),
				crudServiceContainer.getModuleCrudService());
		ApplicationEnvBundleWorker applicationEnvBundleWorker = new ApplicationEnvBundleWorker(crudServiceContainer.getApplicationEnvCrudService());
		AmendableModulesBundleWorker amendableModulesBundleWorker = new AmendableModulesBundleWorker(crudServiceContainer.getAmendableModuleCrudService(),
				crudServiceContainer.getModuleCrudService(), crudServiceContainer.getSectorsCrudService());
		ChildrenModulesBundleWorker childrenModulesBundleWorker = new ChildrenModulesBundleWorker(crudServiceContainer.getChildModuleCrudService(),
				crudServiceContainer.getModuleCrudService(),
				crudServiceContainer.getSectorsCrudService());
		if (!"DISABLED".equals(config.getRabbitmqConfig().getHost())) {
			Connection rabbitMQConnection = createRabbitmqConnection(config.getRabbitmqConfig());
			createBundleInfrastructure(config.getActivateBundleConfig(), rabbitMQConnection, jdbi, objectMapper,
					workflowsBundleWorker, sectorsBundleWorker, modulesBundleWorker, anomalyCatalogBundleWorker,
					applicationEnvBundleWorker, config.getBundleConfig(), config.getBundleServiceId(),
					amendableModulesBundleWorker, childrenModulesBundleWorker);

			// async print listener
			@SuppressWarnings("unused")
			PrintMessageListener printMessageListener = new PrintMessageListener(rabbitMQConnection, PRINT_DESTINATION, objectMapper,
					crudServiceContainer.getApplicationGeneratedPrintCrudService(), jdbi, queueContainer.getNotifyPrintEventQueue());

			// async calculation listener
			@SuppressWarnings("unused")
			CalculationMessageListener calculationMessageListener = new CalculationMessageListener(rabbitMQConnection, CALCULATOR_DESTINATION, objectMapper,
					crudServiceContainer.getApplicationGeneratedCalculationCrudService(), jdbi, queueContainer.getNotifyCalculationEventQueue());

			// async applications listener
			@SuppressWarnings("unused")
			ApplicationsMessageListener applicationsMessageListener = new ApplicationsMessageListener(rabbitMQConnection,
					objectMapper, queueContainer.getNotifyApplicationsEventQueue());

			// async protocol listener
			@SuppressWarnings("unused")
			ProtocolListener protocolListener = new ProtocolListener(rabbitMQConnection, objectMapper,
					crudServiceContainer.getApplicationProtocolsCrudService(),
					jdbi);

			// async monitoring listener
			if (Boolean.TRUE.equals(config.getActivateMonitoringExchangeListener())) {
				@SuppressWarnings("unused")
				MonitoringMessageListener monitoringMessageListener = new MonitoringMessageListener(rabbitMQConnection, objectMapper,
						queueContainer.getNotifyApplicationsEventQueue(), config.getTechUserId());
			}

			JdbiRepository jdbiRepository = new JdbiRepository(jdbi);
			var queue = ApplicationsExchangeFactory.getQueue(jdbiRepository,
					environment.metrics(), rabbitMQConnection, ApplicationQueuePayload.class, ApplicationExchangePublisher.routingKeySupplier);
			queue.start();
			ApplicationExchangePublisher applicationExchangePublisher = new ApplicationExchangePublisher(queue,
					crudServiceContainer.getApplicationsCrudService());
			processService.addProcessListener(
					new ApplicationProcessListener(crudServiceContainer.getApplicationsCrudService(), crudServiceContainer.getApplicationDetailsCrudService(),
							applicationExchangePublisher));
		}
	}

	private QueueContainer buildQueueContainer(Jdbi jdbi, ApplicationsModuleConfiguration config, Environment environment, ObjectMapper objectMapper,
			AuthContextFactory authContextFactory, CrudServiceContainer crudServiceContainer, ApplicationsWorkflowService applicationsWorkflowService,
			ProcessService<IAgriProcedureEnvironment> processService) {

		JdbiRepository jdbiRepository = new JdbiRepository(jdbi);
		QueueProcessorConfig queueProcessorConfig = config.getQueueProcessorConfig();

		CreateProcessQueue createProcessQueue = new CreateProcessQueue(jdbiRepository, objectMapper, environment.metrics(), applicationsWorkflowService,
				queueProcessorConfig.getNumThreads(), queueProcessorConfig.getTimeoutMs());
		UpdateProcessQueue updateProcessQueue = new UpdateProcessQueue(jdbiRepository, objectMapper, environment.metrics(), applicationsWorkflowService,
				crudServiceContainer.getApplicationDetailsCrudService(), queueProcessorConfig.getNumThreads(), queueProcessorConfig.getTimeoutMs());

		NotifyCalculationEventQueue notifyCalculationEventQueue = new NotifyCalculationEventQueue(jdbiRepository, objectMapper, environment.metrics(),
				queueProcessorConfig.getNumThreads(), queueProcessorConfig.getTimeoutMs(), processService, authContextFactory,
				crudServiceContainer.getApplicationsCrudService(),
				crudServiceContainer.getApplicationProfilesCrudService(), crudServiceContainer.getSectorsCrudService());
		NotifyPrintEventQueue notifyPrintEventQueue = new NotifyPrintEventQueue(jdbiRepository, objectMapper, environment.metrics(),
				queueProcessorConfig.getNumThreads(), queueProcessorConfig.getTimeoutMs(), processService, authContextFactory,
				crudServiceContainer.getApplicationsCrudService(),
				crudServiceContainer.getApplicationProfilesCrudService(), crudServiceContainer.getSectorsCrudService());
		NotifyApplicationsEventQueue notifyApplicationsEventQueue = new NotifyApplicationsEventQueue(jdbiRepository, objectMapper,
				environment.metrics(), queueProcessorConfig.getNumThreads(), queueProcessorConfig.getTimeoutMs(), processService, authContextFactory,
				crudServiceContainer.getApplicationsCrudService(), crudServiceContainer.getApplicationProfilesCrudService(),
				crudServiceContainer.getSectorsCrudService());
		// This queue is need to have workflow timers to work
		TimerScheduledQueue timerQueue = TimerScheduledQueue.builder("wf-timers", jdbiRepository, processService)
				.withAuthContextSupplier(job -> {
					try {
						return authContextFactory.createAuthContext(job.getTenantId(), job.getUserId(), job.getLocaleCode());
					} catch (AuthenticationException e) {
						throw new IllegalStateException("Cannot create an auth context fot job: " + job, e);
					}
				})
				.withMetricsRegistry(environment.metrics())
				.withNumThreads(10)
				.withProfilesManagerSupplier(
						job -> new ApplicationProfilesManager(job, crudServiceContainer.getApplicationsCrudService(),
								crudServiceContainer.getApplicationProfilesCrudService()))
				.withTimeoutMs(20 * 60_000L)
				.build();
		timerQueue.start();

		return QueueContainer.builder()
				.createProcessQueue(createProcessQueue)
				.updateProcessQueue(updateProcessQueue)
				.notifyCalculationEventQueue(notifyCalculationEventQueue)
				.notifyPrintEventQueue(notifyPrintEventQueue)
				.notifyApplicationsEventQueue(notifyApplicationsEventQueue)
				.build();
	}

	private Map<String, Object> buildUtilsMap(Sso2Client sso2Client, CrudServiceContainer crudServiceContainer, GenericCallerService genericCallerService,
			FormConfigService formConfigService, WorkflowService workflowService, ApplicationProfilesService applicationProfilesService) {

		CallerFactory callerFactory = new CallerFactory();
		AnomalyHandler anomalyHandler = new AnomalyHandlerImpl(crudServiceContainer.getAnomaliesCrudService());
		CheckCompileStatus checkCompileStatus = new CheckCompileStatusImpl(crudServiceContainer.getApplicationCompileStatusCrudService());
		GetFormConfigs getFormConfigs = new GetFormConfigsImpl(crudServiceContainer.getApplicationsCrudService(),
				crudServiceContainer.getApplicationProfilesCrudService(), crudServiceContainer.getApplicationCompileStatusCrudService(),
				formConfigService, sso2Client);

		GetApplicationProfiles getApplicationProfiles = new GetApplicationProfilesImpl(crudServiceContainer.getApplicationsCrudService(),
				crudServiceContainer.getModuleProfilesCrudService(),
				crudServiceContainer.getApplicationProfilesCrudService());
		CheckApplicationProfiles checkApplicationProfiles = new CheckApplicationProfiles(getApplicationProfiles);
		SetApplicationPresentationDate setPresentationDateService = new SetPresentationDateServiceImpl(crudServiceContainer.getApplicationDetailsCrudService());

		StopTransitionService stopTransitionService = new StopTransitionService();

		ApplicationsWorkflowUtils applicationsWorkflowUtils = new ApplicationsWorkflowUtils(workflowService);

		LogicallyDeleteApplicationImpl logicallyDeleteApplication = new LogicallyDeleteApplicationImpl(crudServiceContainer.getApplicationsCrudService());

		Map<String, Object> utilsMap = new HashMap<>();
		utilsMap.put(CheckCompileStatus.KEY, checkCompileStatus);
		utilsMap.put(GetFormConfigs.KEY, getFormConfigs);
		utilsMap.put(GetApplicationProfiles.KEY, getApplicationProfiles);
		utilsMap.put(CheckApplicationProfiles.KEY, checkApplicationProfiles);
		utilsMap.put(GENERIC_CALLER_SERVICE_KEY, genericCallerService);
		utilsMap.put(AnomalyHandler.KEY, anomalyHandler);
		utilsMap.put(CallerFactory.KEY, callerFactory);
		utilsMap.put(StopTransitionService.KEY, stopTransitionService);
		utilsMap.put(WorkflowUtils.KEY, applicationsWorkflowUtils);
		utilsMap.put(SetApplicationPresentationDate.KEY, setPresentationDateService);
		utilsMap.put(LogicallyDeleteApplication.KEY, logicallyDeleteApplication);
		utilsMap.put(UpsertApplicationProfiles.KEY, applicationProfilesService);
		return utilsMap;
	}

	private CallerContainer buildCallerContainer(GenericCallerService genericCallerService) {
		return CallerContainer.builder()
				.getPartiesCaller(new GetPartiesCaller(genericCallerService))
				.getPartyByPartyIdCaller(new GetPartyByPartyIdCaller(genericCallerService))
				.getPartiesRegistryCaller(new GetPartiesRegistryCaller(genericCallerService))
				.getPartyRegistryByPartyIdCaller(new GetPartyRegistryByPartyIdCaller(genericCallerService))
				.createPrintJobCaller(new CreatePrintJobCaller(genericCallerService))
				.createCalculatorJobCaller(new CreateCalculatorJobCaller(genericCallerService))
				.getCalculatorRawResultJobCaller(new GetCalculatorRawResultJobCaller(genericCallerService))
				.getCalculatorRenderResultJobCaller(new GetCalculatorRenderResultJobCaller(genericCallerService))
				.checkCanReadPartyCaller(new CheckCanReadPartyCaller(genericCallerService))
				.createCustomApplicationIdCaller(new CreateCustomApplicationIdCaller(genericCallerService))
				.build();
	}

	private DAOContainer buildDAOContainer(Jdbi jdbi) {
		return DAOContainer.builder()
				.i18NDAO(jdbi.onDemand(I18NDAO.class))
				.sectorDAO(jdbi.onDemand(SectorDAO.class))
				.moduleDAO(jdbi.onDemand(ModuleDAO.class))
				.moduleDetailsDAO(jdbi.onDemand(ModuleDetailsDAO.class))
				.applicationDetailsDAO(jdbi.onDemand(ApplicationDetailsDAO.class))
				.applicationDAO(jdbi.onDemand(ApplicationDAO.class))
				.formCatalogDAO(jdbi.onDemand(FormCatalogDAO.class))
				.moduleFormConfigsDAO(jdbi.onDemand(ModuleFormConfigsDAO.class))
				.formGroupDAO(jdbi.onDemand(FormGroupDAO.class))
				.moduleFormConfigParamDAO(jdbi.onDemand(ModuleFormConfigParamDAO.class))
				.applicationProfileDAO(jdbi.onDemand(ApplicationProfileDAO.class))
				.moduleFormConfigProfileDAO(jdbi.onDemand(ModuleFormConfigProfileDAO.class))
				.moduleProfilesDAO(jdbi.onDemand(ModuleProfileDAO.class))
				.applicationCompileStatusDAO(jdbi.onDemand(ApplicationCompileStatusDAO.class))
				.anomalyDAO(jdbi.onDemand(AnomalyDAO.class))
				.anomalyCatalogDAO(jdbi.onDemand(AnomalyCatalogDAO.class))
				.modulePrintConfigsDAO(jdbi.onDemand(ModulePrintConfigsDAO.class))
				.modulePrintConfigParamDAO(jdbi.onDemand(ModulePrintConfigParamDAO.class))
				.modulePrintConfigProfileDAO(jdbi.onDemand(ModulePrintConfigProfileDAO.class))
				.applicationGeneratedPrintDAO(jdbi.onDemand(ApplicationGeneratedPrintDAO.class))
				.applicationGeneratedCalculationDAO(jdbi.onDemand(ApplicationGeneratedCalculationDAO.class))
				.applicationEnvDAO(jdbi.onDemand(ApplicationEnvDAO.class))
				.applicationProtocolsDAO(jdbi.onDemand(ApplicationProtocolsDAO.class))
				.amendableModuleDAO(jdbi.onDemand(AmendableModuleDAO.class))
				.moduleCalculationConfigsDAO(jdbi.onDemand(ModuleCalculationConfigsDAO.class))
				.moduleCalculationConfigParamDAO(jdbi.onDemand(ModuleCalculationConfigParamDAO.class))
				.moduleCalculationConfigProfileDAO(jdbi.onDemand(ModuleCalculationConfigProfileDAO.class))
				.childrenModulesDAO(jdbi.onDemand(ChildrenModulesDAO.class))
				.applicationsRelationsDAO(jdbi.onDemand(ApplicationsRelationsDAO.class))
				.build();
	}

	private Jdbi getJdbi(DataSourceFactory dataSourceFactory, Environment environment, String dbname, String tablePrefix, boolean mainDb) {

		JdbiFactory factory = new JdbiFactory();
		final Jdbi jdbi = factory.build(environment, dataSourceFactory, dbname);
		jdbi.setSqlLogger(new Slf4JSqlLogger());
		boolean isPostgres = jdbi.withHandle(h -> {
			String db = h.queryMetadata(DatabaseMetaData::getDatabaseProductName);
			log.info("Database connection is '{}'", db);
			return db.toLowerCase().contains("postgresql");
		});

		if (mainDb) {
			DbUtils.mainDbIsPostgres = isPostgres;
		}

		// jdbi database configuration
		jdbi.installPlugin(new SqlObjectPlugin());
		if (isPostgres) {
			jdbi.installPlugin(new PgJdbiPlugin());
		} else {
			var params = new OraJdbiPlugin.OraJdbiPluginParams(cnn -> cnn.unwrap(OracleConnection.class), true);
			jdbi.installPlugin(new OraJdbiPlugin(params));
		}

		if (tablePrefix != null) {
			jdbi.configure(AbacoJdbiConfig.class, cfg -> cfg.setTablesPrefix(tablePrefix));
		}

		return jdbi;
	}

	private void registerAuthFilters(Sso2Client client, ApplicationsModuleConfiguration config, Environment environment) {
		if (config.isSecureAuth()) {
			AuthUtils.installAuthFilter(environment, client, new SsoAuthorizer(client));
		} else {
			environment.jersey().register(new DevFilter.Builder<User>()
					.setAuthenticator(new DevAuthenticator())
					.setAuthorizer(new DevAuthorizer<>(config.getDevUser()))
					.setRealm("DEV Env")
					.buildAuthFilter());
			environment.jersey().register(new AuthValueFactoryProvider.Binder<>(User.class));
		}

	}

	private void initOpenApi(Environment environment) throws IOException {
		OpenAPIConfiguration oasConfig = new ClasspathOpenApiConfigurationLoader()
				.load("openapi-configuration.yaml");

		environment.jersey().register(new OpenApiResource()
				.openApiConfiguration(oasConfig));
	}

	private void configure(ObjectMapper objectMapper) {
		objectMapper.disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);
		objectMapper.disable(DeserializationFeature.ADJUST_DATES_TO_CONTEXT_TIME_ZONE);
		// objectMapper.registerModule(new JavaTimeModule());

		SimpleModule module = new SimpleModule("custom-deserializers", Version.unknownVersion());
		module.addSerializer(Geometry.class, new WKTGeometrySerializer());
		module.addDeserializer(Geometry.class, new WKTGeometryDeserializer());

		objectMapper.registerModule(module);
	}

	private void setupCORS(Environment environment) {
		log.info("CORS is enabled");

		Dynamic cors = environment.servlets().addFilter("CORS", CrossOriginFilter.class);
		cors.setInitParameter(CrossOriginFilter.ALLOWED_ORIGINS_PARAM, "*");
		cors.setInitParameter(CrossOriginFilter.ALLOWED_HEADERS_PARAM, "*");
		cors.setInitParameter(CrossOriginFilter.ALLOWED_METHODS_PARAM, "GET,PUT,POST,PATCH,DELETE");

		// OPTIONS pre-flight request will be served by the filter ONLY and not passed ahead
		// cors.setInitParameter(CrossOriginFilter.CHAIN_PREFLIGHT_PARAM, "false");

		// Add URL mapping
		cors.addMappingForUrlPatterns(EnumSet.allOf(DispatcherType.class), false, "*");
	}

	protected Connection createRabbitmqConnection(RabbitMqConfig rabbitmqConfig) {
		if (rabbitmqConfig == null) {
			return null;
		}

		if (StringUtils.isBlank(rabbitmqConfig.getHost())) {
			return null;
		}

		ConnectionFactory factory = new ConnectionFactory();

		// The maxInboundMessageBodySize was lowered to 64M in versions greater than 5.15
		factory.setMaxInboundMessageBodySize(120 * 1024 * 1024); // This is the biggest allowed bundle sizedefault)
		factory.setHost(rabbitmqConfig.getHost());

		if (!StringUtils.isBlank(rabbitmqConfig.getUser())) {
			factory.setUsername(rabbitmqConfig.getUser());
		}
		if (!StringUtils.isBlank(rabbitmqConfig.getPassword())) {
			factory.setPassword(rabbitmqConfig.getPassword());
		}
		if (!StringUtils.isBlank(rabbitmqConfig.getVirtualhost())) {
			factory.setVirtualHost(rabbitmqConfig.getVirtualhost());
		}
		if (rabbitmqConfig.getPort() != null) {
			factory.setPort(rabbitmqConfig.getPort());
		}
		factory.setAutomaticRecoveryEnabled(true);

		try {
			return factory.newConnection();
		} catch (IOException | TimeoutException e) {
			throw new IllegalStateException("Cannot connect to rabbit mq", e);
		}
	}

	private void createBundleInfrastructure(boolean activateBundleConfig, Connection rabbitMQConnection, Jdbi jdbi, ObjectMapper objectMapper,
			WorkflowsBundleWorker workflowsBundleWorker,
			SectorsBundleWorker sectorsBundleWorker,
			ModulesBundleWorker modulesBundleWorker,
			AnomalyCatalogBundleWorker anomalyCatalogBundleWorker,
			ApplicationEnvBundleWorker applicationEnvBundleWorker,
			BundleConfig bundleConfig, String serviceName,
			AmendableModulesBundleWorker amendableModulesBundleWorker,
			ChildrenModulesBundleWorker childrenModulesBundleWorker) {

		if (rabbitMQConnection == null) {
			throw new IllegalStateException("Connection to RabbitMQ instance failed but needed");
		}
		if (activateBundleConfig) {
			try {
				// Listener
				ListenerBuilder.newBuilder(rabbitMQConnection)
						.withConfigDataConsumer(ConfigDataConsumerBuilder.newBuilder(jdbi, rabbitMQConnection)
								.route(serviceName)
								.processors(
										new BundleWorkflowsProcessor(workflowsBundleWorker, jdbi),
										new BundleSectorsProcessor(objectMapper, sectorsBundleWorker, jdbi),
										new BundleModulesProcessor(objectMapper, modulesBundleWorker, jdbi),
										new BundleAnomalyCatalogProcessor(objectMapper, anomalyCatalogBundleWorker, jdbi),
										new BundleApplicationEnvProcessor(objectMapper, applicationEnvBundleWorker, jdbi),
										new BundleAmendableModulesProcessor(objectMapper, amendableModulesBundleWorker, jdbi),
										new BundleChildrenModulesProcessor(objectMapper, childrenModulesBundleWorker, jdbi))
								.withOrderPolicy(ProcessorOrderPolicyEnum.PROCESSOR)
								.build())
						.withNewTenantEventConsumer(NewTenantEventConsumerBuilder.newBuilder(jdbi)
								.route(serviceName)
								.processors(
										new WorkflowNewTenantProcessor(jdbi, workflowsBundleWorker),
										new SectorNewTenantProcessor(jdbi, sectorsBundleWorker),
										new ModuleNewTenantProcessor(jdbi, modulesBundleWorker),
										new AnomalyCatalogNewTenantProcessor(jdbi, anomalyCatalogBundleWorker),
										new ApplicationEnvNewTenantProcessor(jdbi, applicationEnvBundleWorker),
										new AmendableModuleNewTenantProcessor(jdbi, amendableModulesBundleWorker),
										new ChildModuleNewTenantProcessor(jdbi, childrenModulesBundleWorker))
								.build())
						.buildListener()
						.start();

			} catch (Exception e) {
				throw new IllegalStateException("Error starting rabbitmq listener", e);
			}
			try {
				// Producer
				BundleInitServiceBuilder.producer(rabbitMQConnection)
						.configLocation(bundleConfig.getConfigLocation())
						.build()
						.start();

			} catch (Exception e) {
				throw new IllegalStateException("Error starting rabbitmq producer", e);
			}
		}
	}

}
