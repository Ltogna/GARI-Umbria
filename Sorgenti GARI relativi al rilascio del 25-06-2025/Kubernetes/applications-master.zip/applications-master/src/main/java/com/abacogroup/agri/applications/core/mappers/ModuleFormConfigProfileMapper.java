package com.abacogroup.agri.applications.core.mappers;

import com.abacogroup.agri.applications.core.model.dto.ModuleFormConfigProfileDTO;
import com.abacogroup.agri.applications.db.ntt.ModuleFormConfigProfileNTT;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

@Mapper(uses = AbsoluteDateMapper.class)
public interface ModuleFormConfigProfileMapper extends EntityMapper<ModuleFormConfigProfileDTO, ModuleFormConfigProfileNTT> {

	ModuleFormConfigProfileMapper INSTANCE = Mappers.getMapper(ModuleFormConfigProfileMapper.class);

	@InheritInverseConfiguration()
	ModuleFormConfigProfileDTO entityToDto(ModuleFormConfigProfileNTT entity);

	@Mapping(source = "moduleFormConfigId", target = "module_form_config_id")
	@Mapping(source = "requiredProfileCode", target = "required_profile_code")
	ModuleFormConfigProfileNTT dtoToEntity(ModuleFormConfigProfileDTO dto);

}
