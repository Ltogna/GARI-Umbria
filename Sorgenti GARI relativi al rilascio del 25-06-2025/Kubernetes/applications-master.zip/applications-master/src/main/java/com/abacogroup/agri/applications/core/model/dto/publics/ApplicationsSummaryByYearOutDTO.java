package com.abacogroup.agri.applications.core.model.dto.publics;

import com.abacogroup.agri.applications.core.model.dto.ApplicationsSummaryByYearDTO;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.List;

/**
 * @author Mauro Pozzana
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ApplicationsSummaryByYearOutDTO {
	private Long partyId;

	@Builder.Default
	private List<ApplicationsSummaryByYearDTO> applicationsSummaryByYear = new ArrayList<>();
}
