package com.abacogroup.agri.applications.core.model.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author Alexandru Paraschiv
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class WorkflowMessageOutDTO {

	@Schema(description = "Code")
	private String code;
	@Schema(description = "Description")
	private String description;
	@Schema(description = "Indicates if the operation is successful or not")
	private boolean success;
}
