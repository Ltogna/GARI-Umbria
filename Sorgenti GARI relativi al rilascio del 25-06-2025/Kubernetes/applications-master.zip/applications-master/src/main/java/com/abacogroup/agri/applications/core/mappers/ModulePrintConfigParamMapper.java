package com.abacogroup.agri.applications.core.mappers;

import com.abacogroup.agri.applications.core.model.dto.ModulePrintConfigParamDTO;
import com.abacogroup.agri.applications.db.ntt.ModulePrintConfigParamNTT;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

@Mapper(uses = AbsoluteDateMapper.class)
public interface ModulePrintConfigParamMapper extends EntityMapper<ModulePrintConfigParamDTO, ModulePrintConfigParamNTT> {

	ModulePrintConfigParamMapper INSTANCE = Mappers.getMapper(ModulePrintConfigParamMapper.class);

	@InheritInverseConfiguration()
	ModulePrintConfigParamDTO entityToDto(ModulePrintConfigParamNTT entity);

	@Mapping(source = "modulePrintConfigId", target = "module_print_config_id")
	@Mapping(source = "parameterName", target = "parameter_name")
	@Mapping(source = "parameterValue", target = "parameter_value")
	ModulePrintConfigParamNTT dtoToEntity(ModulePrintConfigParamDTO dto);

}
