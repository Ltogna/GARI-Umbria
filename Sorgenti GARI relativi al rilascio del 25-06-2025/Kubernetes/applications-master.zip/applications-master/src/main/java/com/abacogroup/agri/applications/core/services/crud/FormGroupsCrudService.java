package com.abacogroup.agri.applications.core.services.crud;

import com.abacogroup.agri.applications.core.exceptions.ObjectNotFoundException;
import com.abacogroup.agri.applications.core.mappers.FormGroupMapper;
import com.abacogroup.agri.applications.core.model.dto.FormGroupDTO;
import com.abacogroup.agri.applications.core.services.I18NService;
import com.abacogroup.agri.applications.db.dao.FormGroupDAO;
import com.abacogroup.agri.applications.db.ntt.FormGroupNTT;
import com.abacogroup.agri.applications.db.ntt.applications.RsI18N;
import com.abacogroup.jaxrsutils.filter.MDCPreFilter;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.NotImplementedException;
import org.slf4j.MDC;

import java.util.List;
import java.util.Optional;

/**
 * @author Gennaro Tamburrelli
 */
@Slf4j
public class FormGroupsCrudService extends AbstractCrudService<FormGroupNTT, Long, FormGroupDTO, FormGroupMapper, Long> {

	public static final String I18N_FORM_GROUPS_TABLE = "apps_form_groups";

	private final I18NService i18NService;

	public FormGroupsCrudService(FormGroupDAO dao, FormGroupMapper mapper, I18NService i18NService) {
		super(dao, mapper);
		this.i18NService = i18NService;
	}

	@Override
	protected boolean hasPrimaryKey() {
		return true;
	}

	@Override
	protected Optional<FormGroupNTT> findRsByCustomKey(Long customKey) {
		return Optional.empty();
	}

	@Override
	protected void deleteByCustomKey(Long customKey) {
		throw new NotImplementedException("Not implemented.");
	}

	@Override
	protected void setCustomSearchKey(FormGroupNTT rs, Long customKey) {
		throw new NotImplementedException("Not implemented.");
	}

	public List<FormGroupDTO> findAllFormGroups(String tenantId) {
		return returnMappedList(((FormGroupDAO) this.dao).findAllFormGroups(tenantId, MDC.get(MDCPreFilter.LOCALE)));
	}

	public List<FormGroupDTO> findAllFormGroupsWithNoParentByTenant(String tenantId) {
		return returnMappedList(((FormGroupDAO) this.dao).findAllFormGroupsWithNoParentByTenant(tenantId, MDC.get(MDCPreFilter.LOCALE)));
	}

	public List<FormGroupDTO> findAllFormGroupsWithNoParent(String tenantId, List<Long> formGroupIdList) {
		return returnMappedList(((FormGroupDAO) this.dao).findAllFormGroupsWithNoParent(tenantId, formGroupIdList, MDC.get(MDCPreFilter.LOCALE)));
	}

	public List<FormGroupDTO> findFormGroupsByParentId(String tenantId, Long parentGroupId) {
		return returnMappedList(((FormGroupDAO) this.dao).findFormCatalogsByParentId(tenantId, parentGroupId));
	}

	public FormGroupDTO insert(FormGroupDTO in) {
		log.info("Invoking insert with params in: {}", in);
		return this.insert(in, null);
	}

	public FormGroupDTO update(Long key, FormGroupDTO in) {
		log.info("Invoking update with params key: {} in: {}", key, in);
		return this.update(key, in, null);
	}

	public void delete(Long key) {
		log.info("Invoking delete with params key: {}", key);
		this.delete(key, null);
	}

	public FormGroupDTO findById(String tenant, Long id) throws ObjectNotFoundException {
		log.info("Invoking findById with params tenant: {} id: {}", tenant, id);
		return returnOptionalRecord(((FormGroupDAO) this.dao).findById(tenant, id, MDC.get(MDCPreFilter.LOCALE)))
				.orElseThrow(OBJECT_NOT_FOUND_EXCEPTION_SUPPLIER);
	}

	public Optional<FormGroupDTO> findByIdNoExp(String tenant, Long id) {
		try {
			return Optional.of(this.findById(tenant, id));
		} catch (ObjectNotFoundException e) {
			return Optional.empty();
		}
	}

	public FormGroupDTO findFormGroupByCode(String tenant, String formGroupCode) throws ObjectNotFoundException {
		log.info("Invoking findFormGroupByCode with params tenant: {} formGroupCode: {}", tenant, formGroupCode);
		return returnOptionalRecord(((FormGroupDAO) this.dao).findByCode(tenant, formGroupCode, MDC.get(MDCPreFilter.LOCALE)))
				.orElseThrow(OBJECT_NOT_FOUND_EXCEPTION_SUPPLIER);
	}

	public FormGroupDTO findFormGroupByCodeNullable(String tenant, String formGroupCode) {
		log.info("Invoking findFormGroupByCode with params tenant: {} formGroupCode: {}", tenant, formGroupCode);
		return returnOptionalRecord(((FormGroupDAO) this.dao).findByCode(tenant, formGroupCode, MDC.get(MDCPreFilter.LOCALE)))
				.orElse(null);
	}

	public void insertFormGroupI18N(String tenant, String code, String lang, String description) {
		this.i18NService.insertI18N(tenant, I18N_FORM_GROUPS_TABLE, FORM_GROUPS_I18N.FORM_GROUP_CODE.code, lang, code, description);
	}

	public void deleteFormGroupI18N(String tenant, String code, String lang) {
		this.i18NService.deleteI18N(tenant, I18N_FORM_GROUPS_TABLE, FORM_GROUPS_I18N.FORM_GROUP_CODE.code, code, lang);
	}

	public List<RsI18N> getAllFormGroupI18NByTenantAndCode(String tenant, String code) {
		return this.i18NService.getAllI18NbyCode(tenant, I18N_FORM_GROUPS_TABLE, code);
	}

	public enum FORM_GROUPS_I18N {
		FORM_GROUP_CODE("form_group_code");

		private final String code;

		FORM_GROUPS_I18N(String val) {
			this.code = val;
		}

		public String getCode() {
			return this.code;
		}
	}
}
