package com.abacogroup.agri.applications.core.services.workflow.sdkimpl;

import com.abacogroup.agri.applications.core.model.dto.publics.AnomalyDTO;
import com.abacogroup.agri.applications.core.services.crud.AnomaliesCrudService;
import com.abacogroup.applicationworkflowsdk.model.io.output.AnomalyOutDTO;
import com.abacogroup.applicationworkflowsdk.service.AnomalyHandler;
import lombok.extern.slf4j.Slf4j;

import java.util.List;
import java.util.stream.Collectors;

/**
 * @author Gennaro Tamburrelli
 */
@Slf4j
public class AnomalyHandlerImpl implements AnomalyHandler {

	private final AnomaliesCrudService anomaliesCrudService;

	public AnomalyHandlerImpl(AnomaliesCrudService anomaliesCrudService) {
		this.anomaliesCrudService = anomaliesCrudService;
	}

	@Override
	public void insertAnomaly(String tenant, Long applicationId, String anomalyCode, String username) {
		var insertAnomaly = AnomalyDTO.builder()
				.anomalyCode(anomalyCode)
				.applicationId(applicationId)
				.build();
		var existingAnomaly = this.anomaliesCrudService.findWithoutJoiningCatalog(tenant, applicationId, anomalyCode);
		try {
			existingAnomaly.ifPresentOrElse(x -> {
						log.info("anomaly already present, updating it");
						this.anomaliesCrudService.update(x.getPkid(), insertAnomaly, username);
					},
					() -> this.anomaliesCrudService.insert(AnomalyDTO.builder()
							.anomalyCode(anomalyCode)
							.applicationId(applicationId)
							.build(), username));
		} catch (Exception e) {
			log.error("error during updating anomaly");
		}

	}

	@Override
	public void deleteAnomaly(String tenant, Long applicationId, String anomalyCode, String username) {
		log.info("called delete anomaly for applicationid {} anomaly code {} username {}", applicationId, anomalyCode, username);
		this.anomaliesCrudService.deleteByAnomalyCode(tenant, applicationId, anomalyCode, username);
	}

	@Override
	public List<AnomalyOutDTO> getAnomalies(String tenant, Long applicationId) {
		return this.anomaliesCrudService.find(tenant, applicationId)
				.stream()
				.map(x -> AnomalyOutDTO.builder()
						.pkid(x.getPkid())
						.severity(x.getSeverity())
						.anomalyCode(x.getAnomalyCode())
						.anomalyDesc(x.getAnomalyDesc())
						.build())
				.collect(Collectors.toList());
	}

	public List<AnomalyDTO> getAnomaliesForApp(String tenant, Long applicationId) {
		return this.anomaliesCrudService.find(tenant, applicationId);
	}
}
