package com.abacogroup.agri.applications.core.model.dto.publics;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import com.abacogroup.agri.applications.core.model.dto.ApplicationProfileDTO;
import com.abacogroup.agri.applications.core.model.dto.PartyDTO;
import com.abacogroup.applicationworkflowsdk.model.io.output.ApplicationCompileStatusDTO;
import com.abacogroup.applicationworkflowsdk.model.io.output.FormWithGroupHierarchyPublicDTO;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

/**
 * @author Alexandru Paraschiv
 * @author Gennaro Tamburrelli
 */
@EqualsAndHashCode(callSuper = true)
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class ApplicationWithDetailsDTO extends ApplicationDTO {
	@Schema(description = "the application's code")
	private String applicationCode;
	@Schema(description = "the application's process status code")
	private String processStatus;
	@Schema(description = "the application's process status optional description")
	private String processStatusDescription;
	@Schema(description = "the application's process date of presentation")
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	private LocalDateTime dtPresentation;
	@Schema(description = "the application's process date of protocol request")
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	private LocalDateTime dtProtocolRequest;
	@Schema(description = "the application's process date of protocol response")
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	private LocalDateTime dtProtocolResponse;
	@Schema(description = "the application's protocol code")
	private String protocolCode;
	@Schema(description = "the application's sector code")
	private String sectorCode;
	@Schema(description = "the application's sector description")
	private String sectorDescription;
	@Schema(description = "the application's module code")
	private String moduleCode;
	@Schema(description = "the application's module description")
	private String moduleDescription;
	@Schema(description = "the application's module year")
	private Integer moduleYear;
	@Schema(description = "the application's related forms")
	private List<FormWithGroupHierarchyPublicDTO> forms;
	@Schema(description = "the application's related prints")
	private List<PrintDetailsOutDTO> prints;
	@JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
	private List<ApplicationCompileStatusDTO> compileStatus;
	@Schema(description = "the application's related profile list")
	@Builder.Default
	private List<ApplicationProfileDTO> profileList = new ArrayList<>();
	@Schema(description = "the application's last movement")
	private String lastMovement;
	@Schema(description = "the user id who executed last movement ")
	private String lastMovementUserIdExecutor;
	@Schema(description = "say if the application is closed")
	private Boolean isClosed;
	@Schema(description = "the party dto")
	private PartyDTO party;
	@Schema(description = "The amend application id")
	private Long amendmentApplicationId;
	@Schema(description = "The amended application id")
	private Long amendedApplicationId;
	@Schema(description = "The origin application id")
	private Long originalAmendedApplicationId;
	@Schema(description = "the application's related calculations")
	private List<CalculationDetailsOutDTO> calculations;
	@Schema(description = "the application's profiles exposed description")
	private String applicationProfilesDescription;

}
