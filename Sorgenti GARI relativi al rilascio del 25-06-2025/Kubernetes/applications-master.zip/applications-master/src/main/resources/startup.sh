#!/bin/sh
umask 0002 && \
java -XX:MaxRAMPercentage=75 -XshowSettings:vm -jar original-${project.build.finalName}.jar server config.yml
