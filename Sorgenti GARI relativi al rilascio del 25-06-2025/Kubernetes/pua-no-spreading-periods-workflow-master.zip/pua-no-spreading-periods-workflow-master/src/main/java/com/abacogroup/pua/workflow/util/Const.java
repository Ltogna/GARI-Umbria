package com.abacogroup.pua.workflow.util;

/**
 * 
 * @author Emanuele Crocilla
 *
 */
public final class Const {
 
	public static final String PUA_DICHIARAZIONE_QUINQUENNALE = "PUA_DICHIARAZIONE_QUINQUENNALE";
	public static final String PUA_DICHIARAZIONE_FINALE = "PUA_DICHIARAZIONE_FINALE";
	public static final String PUA_FIRMA = "PUA_FIRMA";

	public static final String PUA_NO_SPREADING_PERIOD_INCOMPLETED = "PUA_NO_SPREADING_PERIOD_INCOMPLETED";
	public static final String PUA_DICHIARAZIONE_QUINQUENNALE_INCOMPLETED = "PUA_DICHIARAZIONE_QUINQUENNALE_INCOMPLETED";
	public static final String PUA_FINAL_DECLARATION_INCOMPLETED = "PUA_FINAL_DECLARATION_INCOMPLETED";
	public static final String PUA_FIRMA_INCOMPLETED = "PUA_FIRMA_INCOMPLETED";

	public static final String PUA_UNHANDLED_ERROR = "PUA_UNHANDLED_ERROR";
	
	private Const() {
	}

}
