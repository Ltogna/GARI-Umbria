package com.abacogroup.pua.workflow.proc;

import java.util.List;
import java.util.Optional;

import com.abacogroup.applicationworkflowsdk.environment.IAgriProcedureEnvironment;
import com.abacogroup.applicationworkflowsdk.model.ApplicationsWorkflowParams;
import com.abacogroup.pua.workflow.model.TipologiaDichirazione;
import com.abacogroup.pua.workflow.model.NoSpreadingPeriodDTO;
import com.abacogroup.workflow.sdk.beans.ProcessData;
import com.abacogroup.workflow.sdk.beans.WorkflowMessage;
import com.abacogroup.workflow.sdk.proc.StopTransitionException;

import lombok.extern.slf4j.Slf4j;

import org.jdbi.v3.core.Jdbi;

/**
 * 
 * @author Emanuele Crocilla
 *
 */
@Slf4j
public class DeleteNoSpreadingPeriodLatestInsertsData extends BaseProcedure {

	public static final String PUA_APP_FORMS = "PUA_APP_FORMS";

	@Override
	protected void doExecute(ProcessData processData, IAgriProcedureEnvironment env) throws Exception {

		try {

			log.debug("Starting execution of DeleteNoSpreadingPeriodLatestInsertsData");

			ApplicationsWorkflowParams params = this.getApplicationsWorkflowParams();
			log.debug("Retrieved workflow parameters: {}", params);

			Long amendedApplicationId = params.getAmendedApplicationId();
			log.debug("AmendedApplicationId: {}", amendedApplicationId);

			if (amendedApplicationId == null) {
				log.debug("AmendedApplicationId is null, returning early");
				return;
			}

			Jdbi jdbi = env.getJdbi(PUA_APP_FORMS).orElseThrow();
			log.debug("Retrieved JDBI for database: {}", PUA_APP_FORMS);
			
			TipologiaDichirazione amendedApplicationTipologiaDichiarazione = 
					puaAppRequest(TipologiaDichirazione.class, "tipologia-dichiarazione", amendedApplicationId);
			log.debug("Retrieved (for amended application) TipologiaDichirazione: {}", amendedApplicationTipologiaDichiarazione);

			int year = amendedApplicationTipologiaDichiarazione.getYear();
			log.debug("Year from amended Application Tipologia dichiarazione: {}", year);

			Long partyId = params.getPartyId();
			log.debug("PartyId: {}", partyId); 

			// remove all existing
			log.debug("Removing existing no spreading periods for year: {} and partyId: {}", year, partyId);
			int i = removeNoSpreadingPeriodsLatestInsert(jdbi, year, partyId);
			log.debug("Removed successfully " + i + " no spreading periods items");

			log.debug("DeleteNoSpreadingPeriodLatestInsertsData execution completed successfully");

		} catch (Exception e) {
			
			log.error("Unhandled error in DeleteNoSpreadingPeriodLatestInsertsData", e);
			
			String message = "Impossibile completare l'inserimento perchè il sistema non è riuscito ad aggiornare le date di divieto";

			log.debug("Error: no records inserted. Error message: {}", message);

			processData.getWorkflowMessages().add(new WorkflowMessage("UNABLE_TO_DELETE_NO_SPREADING_LATEST_PERIOD_DATA", message,
					WorkflowMessage.Type.ERROR));

			throw new StopTransitionException();
		}
	}
}
