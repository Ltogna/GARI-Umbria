package com.abacogroup.pua.workflow.util;

import com.fasterxml.jackson.annotation.JsonCreator;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Objects;

public final class AbsoluteDate implements Comparable<AbsoluteDate> {

	private static final DateTimeFormatter FORMATTER = DateTimeFormatter.ofPattern("yyyyMMdd");

	private final String value;
	private final LocalDate dt;

	@JsonCreator
	public AbsoluteDate(String value) {
		Objects.requireNonNull(value, "Date string must not be null");
		this.dt = LocalDate.parse(value, FORMATTER);
		this.value = value;
	}

	public AbsoluteDate(LocalDate dt) {
		Objects.requireNonNull(dt, "LocalDate must not be null");
		this.dt = dt;
		this.value = dt.format(FORMATTER);
	}

	public LocalDate toLocalDate() {
		return this.dt;
	}

	public LocalDate get() {
		return dt;
	}

	@Override
	public String toString() {
		return value;
	}

	@Override
	public int hashCode() {
		return Objects.hash(dt, value);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null || getClass() != obj.getClass()) return false;
		AbsoluteDate other = (AbsoluteDate) obj;
		return Objects.equals(this.dt, other.dt) && Objects.equals(this.value, other.value);
	}

	@Override
	public int compareTo(AbsoluteDate other) {
		return this.dt.compareTo(other.dt);
	}
}
