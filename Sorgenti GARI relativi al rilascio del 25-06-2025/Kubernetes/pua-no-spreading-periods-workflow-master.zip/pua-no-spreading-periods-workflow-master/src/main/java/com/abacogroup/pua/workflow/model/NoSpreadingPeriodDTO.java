package com.abacogroup.pua.workflow.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.time.OffsetDateTime;

@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class NoSpreadingPeriodDTO {

	@JsonProperty("pkId")
	private Long pkId;

	@JsonProperty("applicationId")
	private Long applicationId;

	@JsonProperty("effluent")
	private String effluent;

	@JsonProperty("dayFrom")
	private String dayFrom;

	@JsonProperty("dayTo")
	private String dayTo;

	@JsonProperty("dtInsert")
	private OffsetDateTime dtInsert;

	@JsonProperty("dtDelete")
	private OffsetDateTime dtDelete;

	@JsonProperty("userIdInsert")
	private String userIdInsert;

	@JsonProperty("userIdDelete")
	private String userIdDelete;
}
