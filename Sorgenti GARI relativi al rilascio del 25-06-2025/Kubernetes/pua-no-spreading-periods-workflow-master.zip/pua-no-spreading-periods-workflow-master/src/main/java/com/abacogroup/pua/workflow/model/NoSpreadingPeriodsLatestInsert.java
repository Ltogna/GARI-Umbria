package com.abacogroup.pua.workflow.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

/**
 * @author Emanuele Crocilla
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@SuperBuilder
public class NoSpreadingPeriodsLatestInsert {
    private Long applicationId;
    private Long partyId;
    private String effluent;
    private Integer year;
    private String dayFrom;
    private String dayTo;
}
