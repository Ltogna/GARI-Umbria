package com.abacogroup.pua.workflow.proc;

import java.util.List;
import java.util.Optional;

import com.abacogroup.applicationworkflowsdk.environment.IAgriProcedureEnvironment;
import com.abacogroup.applicationworkflowsdk.model.ApplicationsWorkflowParams;
import com.abacogroup.applicationworkflowsdk.model.GetApplicationFilters;
import com.abacogroup.applicationworkflowsdk.model.io.output.ApplicationDetailsPublicDTO;
import com.abacogroup.applicationworkflowsdk.v2.procedures.ApplicationProcedure;
import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.pua.workflow.model.TipologiaDichirazione;
import com.abacogroup.workflow.sdk.beans.ProcessData;
import com.abacogroup.workflow.sdk.beans.WorkflowMessage;
import com.abacogroup.workflow.sdk.proc.StopTransitionException;

import jakarta.ws.rs.client.Client;
import jakarta.ws.rs.client.WebTarget;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class CheckOneApplicationPerYear extends ApplicationProcedure {

    private static final String APP_MODULE_CODE = "NO_SPREADING_PERIODS";
    private static final String APP_MODULE_CODE_RECTIFIED = "NO_SPREADING_PERIODS_RECTIFIED";

    @Override
    protected void doExecute(ProcessData processData, IAgriProcedureEnvironment env) throws Exception {
        
        Optional<TipologiaDichirazione> tipologiaDichirazione = 
        		processData.<TipologiaDichirazione>getGlobalVar(TipologiaDichirazione.KEY);

        if(tipologiaDichirazione.isEmpty()){
            processData.getWorkflowMessages().add(new WorkflowMessage("MISSING_FORM", "Quadro anno di campagna non compilato",
                    WorkflowMessage.Type.ERROR));
            throw new StopTransitionException();
        }
        
        int thisAppYear = tipologiaDichirazione.get().getYear();
        log.debug("Retrieved TipologiaDichiarazione with year: {}", thisAppYear);

        ApplicationsWorkflowParams params = getApplicationsWorkflowParams();
        
        Long amendedApplicationId = params.getAmendedApplicationId();
        log.debug("Amended application ID: {}", amendedApplicationId);

        if(amendedApplicationId != null){
			
            log.debug("Current application year: {}", thisAppYear);

    		int amendedAppYear = 
    				loadTipologiaDichiarazione(amendedApplicationId, processData, env).get(); // rectified App
		    
            log.debug("Amended application year: {}", amendedAppYear);
		
			if ( thisAppYear != amendedAppYear ) {
                log.debug("Year mismatch detected - current: {}, amended: {}", thisAppYear, amendedAppYear);
				String code = "APP_YEAR_CANNOT_BE_DIFFERENT_AS_RECTIFIED";
				String description = "Non puoi inserire un anno differente rispetto a l'anno della domanda che stai rettificando (%s).";
				var workflowMessage = new WorkflowMessage(code, String.format(description, amendedAppYear), WorkflowMessage.Type.ERROR);
				processData.getWorkflowMessages().add(workflowMessage);
			} else {
                log.debug("Year validation passed for amended application");
            }
		}
        
        String currentModuleCode = env.getApplicationDetailsService().retrieveApplicationDetails(processData.getTenantId(),
                params.getApplicationId(), (User) processData.getAuthContext().getPrincipal()).getModuleCode();
        
        log.debug("Current application module code: {}", currentModuleCode);

        if(APP_MODULE_CODE_RECTIFIED.equals(currentModuleCode)){
        	return;
        }

        List<ApplicationDetailsPublicDTO> apps = env.getApplicationDetailsService().getApplicationsByParty(processData.getTenantId(), params.getPartyId(),
                GetApplicationFilters.builder().moduleCode(APP_MODULE_CODE).build(),
                (User) processData.getAuthContext().getPrincipal());

        boolean found = apps.stream()
                .filter(a -> !a.getApplicationId().equals(params.getApplicationId())) // Not the current app
                .filter(a -> "PROTOCOLLED".equals(a.getProcessStatus()) || "RECTIFIED".equals(a.getProcessStatus()))
                .anyMatch(a -> eq(thisAppYear, loadTipologiaDichiarazione(a.getApplicationId(), processData, env)));

        if (found) {
            processData.getWorkflowMessages()
                    .add(new WorkflowMessage("APP_ALREADY_EXIST", "Esiste già una domanda per l'anno selezionato", WorkflowMessage.Type.ERROR));
        }
    }

    private boolean eq(Integer year, Optional<Integer> other) {
        
        if (year == null && other.isEmpty()) {
            return true;
        }

        if (year == null || other.isEmpty()) {
            return false;
        }

        return year.equals(other.get());
    }

    public Optional<Integer> loadTipologiaDichiarazione(Long applicationId, ProcessData processData, IAgriProcedureEnvironment env) {
        
        String url = env.getProperty("puaAppFormsUrl").orElseThrow().toString();

        Client client = env.getJerseyClient().orElseThrow();
        WebTarget target = processData.getAuthContext()
                .getAuthenticatedWebTarget(client, url)
                .path("/master/v1/applications/")
                .path(applicationId.toString())
                .path("tipologia-dichiarazione");
        
        try (Response response = target.request(MediaType.APPLICATION_JSON).get()) {
            int status = response.getStatus();
            
            if (status == 404) {
                return Optional.empty();
            }

            if (status < 200 || status > 299) {
                throw new IllegalStateException("Got a bad response loading 'tipologia dichiarazione' for app" + applicationId + "; status is: " + status);
            }

            TipologiaDichirazione tipologiaDichirazione = response.readEntity(TipologiaDichirazione.class);
            return Optional.ofNullable(tipologiaDichirazione.getYear());
        } catch (Exception e) {
            log.error("Exception during loading of tipologia dichiarazione for app {}: {}", applicationId, e.getMessage(), e);
            throw e;
        }
    }
}
