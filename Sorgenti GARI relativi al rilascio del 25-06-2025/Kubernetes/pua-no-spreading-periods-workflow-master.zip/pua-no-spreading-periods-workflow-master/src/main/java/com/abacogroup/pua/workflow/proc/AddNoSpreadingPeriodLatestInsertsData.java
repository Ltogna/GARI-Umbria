package com.abacogroup.pua.workflow.proc;

import java.util.List;
import java.util.Optional;
 
import com.abacogroup.applicationworkflowsdk.environment.IAgriProcedureEnvironment;
import com.abacogroup.applicationworkflowsdk.model.ApplicationsWorkflowParams;
import com.abacogroup.pua.workflow.model.TipologiaDichirazione;
import com.abacogroup.pua.workflow.model.NoSpreadingPeriodDTO;
import com.abacogroup.workflow.sdk.beans.ProcessData;
import com.abacogroup.workflow.sdk.beans.WorkflowMessage;
import com.abacogroup.workflow.sdk.proc.StopTransitionException;

import lombok.extern.slf4j.Slf4j;

import org.jdbi.v3.core.Jdbi;

/**
 * 
 * @author Emanuele Crocilla
 *
 */
@Slf4j
public class AddNoSpreadingPeriodLatestInsertsData extends BaseProcedure {

	public static final String PUA_APP_FORMS = "PUA_APP_FORMS";

	@Override
	protected void doExecute(ProcessData processData, IAgriProcedureEnvironment env) throws Exception {

		try {

			log.debug("Starting execution of AddNoSpreadingPeriodLatestInsertsData");

			Jdbi jdbi = env.getJdbi(PUA_APP_FORMS).orElseThrow();
			log.debug("Retrieved JDBI for database: {}", PUA_APP_FORMS);

			ApplicationsWorkflowParams params = getApplicationsWorkflowParams();
			log.debug("Retrieved workflow parameters: {}", params);

			Optional<TipologiaDichirazione> tipologiaDichirazione = processData.<TipologiaDichirazione>getGlobalVar(TipologiaDichirazione.KEY);
			int year = tipologiaDichirazione.get().getYear();
			log.debug("Year from tipologia dichiarazione: {}", year);

			Long applicationId = params.getApplicationId();
			Long partyId = params.getPartyId();
			log.debug("ApplicationId: {}, PartyId: {}", applicationId, partyId);

			String effluent = null;
			String dayFrom = null;
			String dayTo = null;
			int inserted = 0;

			List<NoSpreadingPeriodDTO> loadNoSpreadingPeriods = loadNoSpreadingPeriods(applicationId, processData, env);
			log.debug("Loaded {} no spreading periods", loadNoSpreadingPeriods != null ? loadNoSpreadingPeriods.size() : 0);

			if (loadNoSpreadingPeriods == null || loadNoSpreadingPeriods.isEmpty()) {
				log.debug("No spreading periods found");
			}

			for (NoSpreadingPeriodDTO dto : loadNoSpreadingPeriods) {
				effluent = dto.getEffluent();
				dayFrom = dto.getDayFrom();
				dayTo = dto.getDayTo();

				log.debug("Processing period: effluent={}, dayFrom={}, dayTo={}", effluent, dayFrom, dayTo);

				int currentInserted = writeNoSpreadingPeriodsLatestInsert(jdbi, applicationId, year, partyId, effluent, dayFrom, dayTo);
				inserted += currentInserted;

				log.debug("Inserted {} records for this period. Total inserted so far: {}", currentInserted, inserted);
			}

			log.debug("Process completed. Total records inserted: {}", inserted);

			if (inserted < 1) {
				String message = "Impossibile completare l'inserimento perchè il sistema non è riuscito ad inserire le date di divieto";

				log.debug("Error: no records inserted. Error message: {}", message);

				processData.getWorkflowMessages().add(new WorkflowMessage("UNABLE_TO_INSERT_NO_SPREADING_LATEST_PERIOD_DATA", message,
						WorkflowMessage.Type.ERROR));

				throw new StopTransitionException();
			}

			log.debug("AddNoSpreadingPeriodLatestInsertsData execution completed successfully");

		} catch (Exception e) {

			log.error("Unhandled error in AddNoSpreadingPeriodLatestInsertsData", e);
			
			throw e;
		}
	}
}
