package com.abacogroup.pua.workflow.proc;

import com.abacogroup.applicationworkflowsdk.environment.IAgriProcedureEnvironment;
import com.abacogroup.applicationworkflowsdk.model.ApplicationsWorkflowParams;
import com.abacogroup.pua.workflow.model.NoSpreadingPeriodDTO;
import com.abacogroup.pua.workflow.util.AbsoluteDate;
import com.abacogroup.workflow.sdk.beans.ProcessData;
import com.abacogroup.workflow.sdk.beans.WorkflowMessage;
import lombok.extern.slf4j.Slf4j;

import java.time.LocalDate;
import java.time.Year;

@Slf4j
public class CheckNoSpreadingPeriodApplicationCompiled extends BaseProcedure {

    @Override
    protected void doExecute(ProcessData processData, IAgriProcedureEnvironment env) throws Exception {
        ApplicationsWorkflowParams params = getApplicationsWorkflowParams();
        var noSpreadingPeriods  = loadNoSpreadingPeriods(params.getApplicationId(), processData, env);
        if (noSpreadingPeriods == null || noSpreadingPeriods.isEmpty()) {
            processData.getWorkflowMessages()
                    .add(new WorkflowMessage("PUA_NO_SPREADING_PERIOD_INCOMPLETED", "il periodo di divieto Spandimenti è vuoto", WorkflowMessage.Type.ERROR));
        } else {
            for (NoSpreadingPeriodDTO period : noSpreadingPeriods) {
                ValidateDates(processData, period);
            }
        }
    }

    public static void ValidateDates(ProcessData processData, NoSpreadingPeriodDTO period) {
        String dayFromStr = period.getDayFrom();
        String dayToStr = period.getDayTo();

        if (dayFromStr == null || dayToStr == null) {
            processData.getWorkflowMessages().add(
                    new WorkflowMessage("PUA_NO_SPREADING_PERIOD_INCOMPLETED",
                            "Periodo di Divieto Spandimento, problema tra data inizio e data fine",
                            WorkflowMessage.Type.ERROR));
            return;
        }

        AbsoluteDate dayFrom;
        AbsoluteDate dayTo;
        try {
            dayFrom = new AbsoluteDate(dayFromStr);
            dayTo = new AbsoluteDate(dayToStr);
        } catch (Exception e) {
            processData.getWorkflowMessages().add(
                    new WorkflowMessage("PUA_NO_SPREADING_PERIOD_INCOMPLETED",
                            "Formato data non valido. Atteso: yyyyMMdd",
                            WorkflowMessage.Type.ERROR));
            return;
        }

        var fromDate = dayFrom.toLocalDate();
        var toDate = dayTo.toLocalDate();

        if (toDate.isBefore(fromDate)) {
            processData.getWorkflowMessages().add(
                    new WorkflowMessage("PUA_NO_SPREADING_PERIOD_INCOMPLETED",
                            "Il giorno di fine deve essere uguale o successivo al giorno di inizio",
                            WorkflowMessage.Type.ERROR));
            return;
        }

        long daysBetween = java.time.temporal.ChronoUnit.DAYS.between(fromDate, toDate);
        if (daysBetween < 90) {
            processData.getWorkflowMessages().add(
                    new WorkflowMessage("PUA_NO_SPREADING_PERIOD_INCOMPLETED",
                            "Periodo di Divieto Spandimento, durata inferiore a 90 giorni",
                            WorkflowMessage.Type.ERROR));
        }

        LocalDate minStart = LocalDate.of(fromDate.getYear(), 10, 1);

        int endYear = (toDate.getMonthValue() <= 2) ? toDate.getYear() : toDate.getYear() + 1;
        boolean isLeapYear = Year.isLeap(endYear);
        LocalDate maxEnd = LocalDate.of(endYear, 2, isLeapYear ? 29 : 28);

        if (fromDate.isBefore(minStart) || toDate.isAfter(maxEnd)) {
            processData.getWorkflowMessages().add(
                    new WorkflowMessage("PUA_NO_SPREADING_PERIOD_INCOMPLETED",
                            "Periodo di Divieto Spandimento, Problema su data inizio e data fine: il periodo selezionato deve iniziare dal 1 ottobre e terminare entro il 28/29 febbraio",
                            WorkflowMessage.Type.ERROR));
        }
    }
 
}
