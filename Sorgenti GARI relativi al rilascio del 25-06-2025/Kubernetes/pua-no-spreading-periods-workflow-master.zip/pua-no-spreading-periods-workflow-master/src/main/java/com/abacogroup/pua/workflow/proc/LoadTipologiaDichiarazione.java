package com.abacogroup.pua.workflow.proc;

import com.abacogroup.applicationworkflowsdk.environment.IAgriProcedureEnvironment;
import com.abacogroup.pua.workflow.model.TipologiaDichirazione;
import com.abacogroup.workflow.sdk.beans.ProcessData;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class LoadTipologiaDichiarazione extends BaseProcedure {

	@Override
	protected void doExecute(ProcessData processData, IAgriProcedureEnvironment env) throws Exception {
		log.debug("[no-spreading-periods-workflow] LoadTipologiaDichiarazione started");

		TipologiaDichirazione tipologiaDichiarazione = puaAppRequest(TipologiaDichirazione.class, "tipologia-dichiarazione");

		processData.getGlobalVars().put(TipologiaDichirazione.KEY, tipologiaDichiarazione);
		log.debug("[no-spreading-periods-workflow] Setting global var {} = {}", TipologiaDichirazione.KEY, tipologiaDichiarazione);
	}
}
