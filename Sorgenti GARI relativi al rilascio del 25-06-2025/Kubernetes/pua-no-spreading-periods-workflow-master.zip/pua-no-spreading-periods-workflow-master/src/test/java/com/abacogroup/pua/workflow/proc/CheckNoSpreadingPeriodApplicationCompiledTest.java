package com.abacogroup.pua.workflow.proc;

import com.abacogroup.applicationworkflowsdk.environment.IAgriProcedureEnvironment;
import com.abacogroup.pua.workflow.model.NoSpreadingPeriodDTO;
import com.abacogroup.pua.workflow.util.AbsoluteDate;
import com.abacogroup.workflow.sdk.beans.ProcessData;
import com.abacogroup.workflow.sdk.beans.WorkflowMessage;
import com.abacogroup.workflow.sdk.beans.WorkflowMessage.Type;
import com.abacogroup.workflow.sdk.beans.testsupport.ProcessDataTestSupport;
import org.junit.jupiter.api.Test;

import java.time.LocalDate;
import java.util.List;

import static org.hamcrest.CoreMatchers.containsString;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.mock;

class CheckNoSpreadingPeriodApplicationCompiledTest {

	@Test
	void testValidPeriod_ShouldNotAddErrorMessage() {
		CheckNoSpreadingPeriodApplicationCompiled proc = mockValidPeriodProcessor("20251001", "20251230");
		ProcessData processData = new ProcessDataTestSupport();
		IAgriProcedureEnvironment env = mock(IAgriProcedureEnvironment.class);

		validateNoSpreadingPeriods(1L, processData, env, proc);
		assertEquals(0, processData.getWorkflowMessages().size());
	}

	@Test
	void testTooShortPeriod_ShouldAddError() {
		CheckNoSpreadingPeriodApplicationCompiled proc = mockValidPeriodProcessor("20251001", "20251101");
		ProcessData processData = new ProcessDataTestSupport();
		IAgriProcedureEnvironment env = mock(IAgriProcedureEnvironment.class);

		validateNoSpreadingPeriods(1L, processData, env, proc);
		assertThat(processData.getWorkflowMessages().get(0).getDescription(), containsString("durata inferiore a 90 giorni"));
	}

//	@Test
//	void testInvalidDateBounds_ShouldAddError() {
//		CheckNoSpreadingPeriodApplicationCompiled proc = mockValidPeriodProcessor("20250929", "20260301");
//		ProcessData processData = new ProcessDataTestSupport();
//		IAgriProcedureEnvironment env = mock(IAgriProcedureEnvironment.class);
//
//		validateNoSpreadingPeriods(1L, processData, env, proc);
//		assertThat(processData.getWorkflowMessages().get(0).getDescription(), containsString("issue on dayFrom and dayTo"));
//	}

	private CheckNoSpreadingPeriodApplicationCompiled mockValidPeriodProcessor(String startYyyyMMdd, String endYyyyMMdd) {
		return new CheckNoSpreadingPeriodApplicationCompiled() {
			@Override
			public List<NoSpreadingPeriodDTO> loadNoSpreadingPeriods(Long applicationId, ProcessData processData, IAgriProcedureEnvironment env) {
				NoSpreadingPeriodDTO dto = new NoSpreadingPeriodDTO();
				dto.setDayFrom(String.valueOf(new AbsoluteDate(startYyyyMMdd)));
				dto.setDayTo(String.valueOf(new AbsoluteDate(endYyyyMMdd)));
				return List.of(dto);
			}
		};
	}

	public void validateNoSpreadingPeriods(Long applicationId, ProcessData processData, IAgriProcedureEnvironment env, CheckNoSpreadingPeriodApplicationCompiled proc) {
		var noSpreadingPeriods = proc.loadNoSpreadingPeriods(applicationId, processData, env);

		if (noSpreadingPeriods == null || noSpreadingPeriods.isEmpty()) {
			processData.getWorkflowMessages().add(
					new WorkflowMessage("PUA_NO_SPREADING_PERIOD_INCOMPLETED",
							"Il Periodo di Non Spandimento è vuoto",
							Type.ERROR));
			return;
		}
		for (NoSpreadingPeriodDTO period : noSpreadingPeriods) {
			CheckNoSpreadingPeriodApplicationCompiled.ValidateDates(processData,period);
		}
	}
}
