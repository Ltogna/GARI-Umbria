package com.abacogroup.printengine.sdk.proc;

import static com.abacogroup.printengine.sdk.Constants.DEFAULT_REPORT_CONNECTION;

import java.io.File;
import java.nio.file.Path;
import java.sql.Connection;
import java.util.Map;

import org.apache.commons.io.FileUtils;
import org.hamcrest.CoreMatchers;
import org.hamcrest.MatcherAssert;
import org.junit.jupiter.api.Test;

import com.abacogroup.printengine.sdk.ProcEnvConstants;
import com.abacogroup.workflow.sdk.beans.testsupport.ProcedureEnvironmentTestSupport;
import com.abacogroup.workflow.sdk.beans.testsupport.ProcessDataTestSupport;

import lombok.SneakyThrows;

class H2ProcedureTest {

	@Test
	@SneakyThrows
	void test_H2_proc() {

		String tenantId = "tenant_t";
		String WF_CODE = "wk_t";

		File workDir = new File("target/test").getAbsoluteFile();
		FileUtils.deleteQuietly(new File(workDir, "h2"));
		File sourceDir = new File(this.getClass().getResource(this.getClass().getSimpleName()).getFile());

		Path wd = Path.of(workDir.getAbsolutePath());
		try (H2Procedure h2Procedure = new H2Procedure()) {

			ProcessDataTestSupport processData = ProcessDataTestSupport.builder()
					.tenantId(tenantId)
					.processId(1L)
					.workflowCode(WF_CODE)
					.build();

			ProcedureEnvironmentTestSupport env = new ProcedureEnvironmentTestSupport(
					Map.of(),
					null,
					Map.of(
							ProcEnvConstants.PROPERTY_WORK_DIR, wd.toFile().getAbsolutePath(),
							ProcEnvConstants.PROPERTY_SOURCE_DIR, sourceDir.getAbsolutePath()));

			h2Procedure.execute(processData, env);

			MatcherAssert.assertThat(h2Procedure.getH2Folder(),
					CoreMatchers.is(Path.of(workDir.toString(), "h2", String.format("%s_%s_%s", tenantId, WF_CODE, "1"))));
			// MatcherAssert.assertThat(processData.getGlobalVars().get(H2Procedure.H2_DIR),
			// CoreMatchers.is(Path.of(workDir.toString(), "h2", tenantId, WF_CODE, "1").toFile().getAbsolutePath()));

			MatcherAssert.assertThat(processData.getGlobalVars().get(DEFAULT_REPORT_CONNECTION),
					CoreMatchers.is(CoreMatchers.notNullValue()));

			MatcherAssert.assertThat(((Connection) processData.getGlobalVars().get(DEFAULT_REPORT_CONNECTION)).isClosed(),
					CoreMatchers.is(false));

			MatcherAssert.assertThat(processData.getGlobalVars().get(H2Procedure.JDBI_H2_CONNECTION),
					CoreMatchers.is(CoreMatchers.notNullValue()));
		}
	}
}
