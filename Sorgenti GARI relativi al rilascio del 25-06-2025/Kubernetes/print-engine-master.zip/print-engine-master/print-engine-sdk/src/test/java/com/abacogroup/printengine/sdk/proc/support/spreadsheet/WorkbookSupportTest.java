package com.abacogroup.printengine.sdk.proc.support.spreadsheet;

import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.IOException;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.junit.jupiter.api.Test;

class WorkbookSupportTest {

	@Test
	void test_create_new_workbook() throws IOException, InvalidFormatException {
		try (WorkbookSupport support = new WorkbookSupport(null, "target/file2.xlsx")) {
		}

		assertTrue(true);
	}
}
