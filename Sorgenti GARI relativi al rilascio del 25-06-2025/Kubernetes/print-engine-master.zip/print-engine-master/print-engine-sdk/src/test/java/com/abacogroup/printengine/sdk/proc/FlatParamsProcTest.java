package com.abacogroup.printengine.sdk.proc;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.Test;

import com.abacogroup.printengine.sdk.model.ListParam;
import com.abacogroup.printengine.sdk.model.PrintEngineInput;
import com.abacogroup.workflow.sdk.beans.testsupport.ProcedureEnvironmentTestSupport;
import com.abacogroup.workflow.sdk.beans.testsupport.ProcessDataTestSupport;

import lombok.SneakyThrows;

class FlatParamsProcTest {

	private final FlatParamsProc proc = new FlatParamsProc();

	// ----- execute -----
	@Test
	@SneakyThrows
	void test_execute_ok() {
		Map<String, Object> inputParams = new HashMap<>(Map.of(
				"p1", "val1",
				"p2", List.of("val2_1", "val2_2"),
				"p3", List.of("val3"),
				"p4", List.of("val4", "ignored_val4")));
		PrintEngineInput input = PrintEngineInput.builder().setParams(inputParams).build();
		Map<String, Object> globalVars = new HashMap<>(Map.of(
				PrintEngineInput.PARAM_NAME, input));
		ProcessDataTestSupport processData = ProcessDataTestSupport.builder()
				.globalVars(globalVars)
				.procedureParameter(ListParam.builder().setList(List.of("p3", "p4")).build())
				.build();

		proc.execute(processData, new ProcedureEnvironmentTestSupport());

		assertThat(input.getParams()).hasSize(4)
				.isEqualTo(Map.of(
						"p1", "val1",
						"p2", List.of("val2_1", "val2_2"),
						"p3", "val3",
						"p4", "val4"));
	}

	@Test
	@SneakyThrows
	void test_givenEmptyParams_execute_ok() {
		Map<String, Object> inputParams = new HashMap<>();
		PrintEngineInput input = PrintEngineInput.builder().setParams(inputParams).build();
		Map<String, Object> globalVars = new HashMap<>(Map.of(
				PrintEngineInput.PARAM_NAME, input));
		ProcessDataTestSupport processData = ProcessDataTestSupport.builder()
				.globalVars(globalVars)
				.procedureParameter(ListParam.builder().setList(List.of("p3")).build())
				.build();

		proc.execute(processData, new ProcedureEnvironmentTestSupport());

		assertThat(input.getParams()).isEmpty();
	}

	@Test
	@SneakyThrows
	void test_givenNoParamsToFlat_execute_ok() {
		Map<String, Object> inputParams = new HashMap<>(Map.of(
				"p1", "val1",
				"p2", List.of("val2_1", "val2_2"),
				"p3", List.of("val3")));
		PrintEngineInput input = PrintEngineInput.builder().setParams(inputParams).build();
		Map<String, Object> globalVars = new HashMap<>(Map.of(
				PrintEngineInput.PARAM_NAME, input));
		ProcessDataTestSupport processData = ProcessDataTestSupport.builder()
				.globalVars(globalVars)
				.procedureParameter(ListParam.builder().build())
				.build();

		proc.execute(processData, new ProcedureEnvironmentTestSupport());

		assertThat(input.getParams()).hasSize(3)
				.isSameAs(inputParams);
	}

	@Test
	@SneakyThrows
	void test_givenNotExistingParamName_execute_ok() {
		Map<String, Object> inputParams = new HashMap<>(Map.of(
				"p1", "val1",
				"p2", List.of("val2_1", "val2_2"),
				"p3", List.of("val3")));
		PrintEngineInput input = PrintEngineInput.builder().setParams(inputParams).build();
		Map<String, Object> globalVars = new HashMap<>(Map.of(
				PrintEngineInput.PARAM_NAME, input));
		ProcessDataTestSupport processData = ProcessDataTestSupport.builder()
				.globalVars(globalVars)
				.procedureParameter(ListParam.builder().setList(List.of("p5", "p6")).build())
				.build();

		proc.execute(processData, new ProcedureEnvironmentTestSupport());

		assertThat(input.getParams()).hasSize(3)
				.isSameAs(inputParams);
	}

	@Test
	@SneakyThrows
	void test_givenAlreadyFlatParamName_execute_ok() {
		Map<String, Object> inputParams = new HashMap<>(Map.of(
				"p1", "val1",
				"p2", List.of("val2_1", "val2_2"),
				"p3", List.of("val3")));
		PrintEngineInput input = PrintEngineInput.builder().setParams(inputParams).build();
		Map<String, Object> globalVars = new HashMap<>(Map.of(
				PrintEngineInput.PARAM_NAME, input));
		ProcessDataTestSupport processData = ProcessDataTestSupport.builder()
				.globalVars(globalVars)
				.procedureParameter(ListParam.builder().setList(List.of("p1")).build())
				.build();

		proc.execute(processData, new ProcedureEnvironmentTestSupport());

		assertThat(input.getParams()).hasSize(3)
				.isSameAs(inputParams);
	}

	@Test
	@SneakyThrows
	void test_givenEmptyParamName_execute_ok() {
		Map<String, Object> inputParams = new HashMap<>(Map.of(
				"p1", "val1",
				"p2", List.of("val2_1", "val2_2"),
				"p3", List.of()));
		PrintEngineInput input = PrintEngineInput.builder().setParams(inputParams).build();
		Map<String, Object> globalVars = new HashMap<>(Map.of(
				PrintEngineInput.PARAM_NAME, input));
		ProcessDataTestSupport processData = ProcessDataTestSupport.builder()
				.globalVars(globalVars)
				.procedureParameter(ListParam.builder().setList(List.of("p3")).build())
				.build();

		proc.execute(processData, new ProcedureEnvironmentTestSupport());

		assertThat(input.getParams()).hasSize(3)
				.isSameAs(inputParams);
	}
}
