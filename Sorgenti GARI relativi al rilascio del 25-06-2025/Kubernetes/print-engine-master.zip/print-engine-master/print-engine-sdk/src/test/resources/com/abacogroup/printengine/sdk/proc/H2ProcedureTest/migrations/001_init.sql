drop table if exists tmp_test;

create table tmp_test
(
    id         bigserial not null,
    process_id bigint    not null,
    code       varchar,

    CONSTRAINT tmp_test_pk PRIMARY KEY (id)
);
