package com.abacogroup.printengine.sdk.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder(setterPrefix = "set")
@NoArgsConstructor
@AllArgsConstructor
public class PrintParameter {

	private String mainTemplate;
	private String path;
	private Integer numPagesInMemory;

}
