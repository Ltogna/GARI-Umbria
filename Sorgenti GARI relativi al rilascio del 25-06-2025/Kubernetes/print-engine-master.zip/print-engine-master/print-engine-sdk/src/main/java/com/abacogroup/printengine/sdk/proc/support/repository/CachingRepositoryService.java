package com.abacogroup.printengine.sdk.proc.support.repository;

import java.util.concurrent.ConcurrentHashMap;

import com.abacogroup.printengine.sdk.exceptions.PrintEngineException;

import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.JasperReportsContext;
import net.sf.jasperreports.engine.util.JRLoader;
import net.sf.jasperreports.repo.DefaultRepositoryService;
import net.sf.jasperreports.repo.ReportResource;
import net.sf.jasperreports.repo.RepositoryService;
import net.sf.jasperreports.repo.Resource;

public class CachingRepositoryService implements RepositoryService {

	private DefaultRepositoryService defService;

	private ConcurrentHashMap<String, JasperReport> cache;

	public CachingRepositoryService(JasperReportsContext jasperReportsContext) {
		defService = new DefaultRepositoryService(jasperReportsContext);
		cache = new ConcurrentHashMap<>();
	}

	@Override
	public Resource getResource(String uri) {
		return defService.getResource(uri);
	}

	@Override
	public void saveResource(String uri, Resource resource) {
		defService.saveResource(uri, resource);
	}

	@Override
	@SuppressWarnings("unchecked")
	public <K extends Resource> K getResource(String uri, Class<K> resourceType) {
		if (!resourceType.isAssignableFrom(ReportResource.class)) {
			return defService.getResource(uri, resourceType);
		}

		JasperReport report = cache.computeIfAbsent(uri, this::loadJasper);
		if (report == null) {
			return defService.getResource(uri, resourceType);
		}

		ReportResource ret = new ReportResource();
		ret.setReport(report);
		return (K) ret;
	}

	private JasperReport loadJasper(String uri) {
		Object report;
		try {
			report = JRLoader.loadObjectFromFile(uri);
		} catch (JRException e) {
			throw new PrintEngineException(e);
		}

		if (report instanceof JasperReport) {
			return (JasperReport) report;
		}

		return null;
	}

}
