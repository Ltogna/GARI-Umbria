package com.abacogroup.printengine.sdk;

public interface ProcEnvConstants {

	// getProperty

	/**
	 * folder temporanea che coincide con con printEngineConfiguration.initBaseTempDir
	 */
	String PROPERTY_WORK_DIR = "workDir";

	/**
	 * folder dove viene scompattato il jar del workflow e compilati i jasper
	 */
	String PROPERTY_SOURCE_DIR = "sourceDir";

	/**
	 * absolute path del file in output (es: /tmp/repo/demo.pdf)
	 */
	String PROPERTY_FILE_NAME = "fileName";
	String PROPERTY_HELPER_CONNECTION = "helperConnection";
	String PROPERTY_OBJECT_MAPPER = "objectMapper";
	String PROPERTY_PROFILE = "profile";

	// getJdbi
	String JDBI_HELPER = "helper";
	@Deprecated
	String JDBI_PRINT_ENGINE = "print_engine";
}
