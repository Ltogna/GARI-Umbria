package com.abacogroup.printengine.sdk.proc.support.spreadsheet;

import java.io.BufferedWriter;
import java.io.Closeable;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.UUID;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVPrinter;
import org.apache.commons.io.FileUtils;

public class CsvSupport implements Closeable, ExportSupport {

	private final CSVPrinter csvPrinter;
	private final File csvFile;

	public CsvSupport(File workDir) throws IOException {
		this(workDir, CSVFormat.DEFAULT);
	}

	public CsvSupport(File workDir, CSVFormat csvFormat) throws IOException {
		csvFile = new File(workDir, UUID.randomUUID().toString());
		BufferedWriter appendable = new BufferedWriter(new FileWriter(csvFile));
		csvPrinter = new CSVPrinter(appendable, csvFormat);
	}

	@Override
	public void fillRows(ResultSet resultSet) throws SQLException, IOException {
		csvPrinter.printHeaders(resultSet);
		csvPrinter.printRecords(resultSet);
	}

	@Override
	public void print(String fileName) throws IOException {
		csvPrinter.flush();
		FileUtils.moveFile(csvFile, new File(fileName));
	}

	@Override
	public void close() throws IOException {
		csvPrinter.close();
		FileUtils.deleteQuietly(csvFile);
	}
}
