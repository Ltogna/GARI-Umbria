package com.abacogroup.printengine.sdk.proc.support.spreadsheet;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;

public interface ExportSupport {
	void fillRows(ResultSet resultSet) throws SQLException, IOException;

	void print(String fileName) throws IOException;
}
