package com.abacogroup.printengine.sdk.util;

import static com.abacogroup.printengine.sdk.Constants.DEFAULT_REPORT_CONNECTION;

import com.abacogroup.printengine.sdk.ProcEnvConstants;
import com.abacogroup.workflow.sdk.beans.ProcessData;
import com.abacogroup.workflow.sdk.proc.ProcedureEnvironment;
import java.sql.Connection;
import org.apache.commons.io.FilenameUtils;
import org.jdbi.v3.core.Jdbi;

public class ProcUtils {

	public static String getFileName(ProcessData processData, ProcedureEnvironment env, String extension) {
		String fileName = env.<String>getProperty(ProcEnvConstants.PROPERTY_FILE_NAME)
				.map(FilenameUtils::removeExtension)
				.map(fn -> String.format("%s.%s", fn, extension))
				.orElseGet(() -> String.format("%s/%s.%s", System.getProperty("java.io.tmpdir"), processData.getProcessId(), extension));
		return fileName;
	}

	public static String getFileName(ProcessData processData, ProcedureEnvironment env) {
		String fileName = env.<String>getProperty(ProcEnvConstants.PROPERTY_FILE_NAME)
				.map(FilenameUtils::removeExtension)
				.orElseGet(() -> String.format("%s/%s", System.getProperty("java.io.tmpdir"), processData.getProcessId()));
		return fileName;
	}

	public static Jdbi getJdbi(ProcessData processData, ProcedureEnvironment env) {
		return Jdbi.create(getConnection(processData, env));
	}

	public static Connection getConnection(ProcessData processData, ProcedureEnvironment env) {
		if (processData.getGlobalVars().containsKey(DEFAULT_REPORT_CONNECTION)) {
			return (Connection) processData.getGlobalVars().get(DEFAULT_REPORT_CONNECTION);
		} else {
			return env.<Connection>getProperty(ProcEnvConstants.PROPERTY_HELPER_CONNECTION).orElseThrow();
		}
	}

}
