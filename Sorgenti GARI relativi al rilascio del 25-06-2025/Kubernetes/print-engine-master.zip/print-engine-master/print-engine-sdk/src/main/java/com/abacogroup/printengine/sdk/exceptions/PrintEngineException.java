package com.abacogroup.printengine.sdk.exceptions;

public class PrintEngineException extends RuntimeException {

	private static final long serialVersionUID = -628498800347427877L;

	public PrintEngineException() {
		super();
	}

	public PrintEngineException(String message) {
		super(message);
	}

	public PrintEngineException(String message, Throwable cause) {
		super(message, cause);
	}

	public PrintEngineException(Throwable cause) {
		super(cause);
	}
}
