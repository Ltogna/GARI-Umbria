package com.abacogroup.printengine.sdk.proc;

import static com.abacogroup.printengine.sdk.Constants.DEFAULT_REPORT_CONNECTION;

import java.io.File;
import java.nio.file.Path;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Arrays;
import java.util.Objects;
import java.util.Optional;

import org.apache.commons.io.FileUtils;
import org.jdbi.v3.core.Jdbi;

import com.abacogroup.printengine.sdk.ProcEnvConstants;
import com.abacogroup.workflow.sdk.beans.ProcessData;
import com.abacogroup.workflow.sdk.proc.EnvironmentAwareProcedure;
import com.abacogroup.workflow.sdk.proc.ProcedureEnvironment;

import liquibase.Liquibase;
import liquibase.resource.DirectoryResourceAccessor;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;

/**
 * Procedure per l'utilizzo di un database h2.
 * <p>
 * <b>L'utilizzo di questa proc determina che la connessione al report sarà quella a questo datasource</b>, e non come default, al db-helper.
 * <p>
 * Questa proc aggiunge tre entry alle globalVars:
 * <ul>
 * <li><code>H2Procedure.JDBI_H2_CONNECTION</code>: un jdbi pronto per elaborazioni sul db</li>
 * <li><code>H2Procedure.H2_DIR</code>: il path su disco della dir che contiene il db h2</li>
 * <li><code>Constants.DEFAULT_REPORT_CONNECTION</code>: Questa property è usata da CreateJasperReports per determinare la connection da associare al
 * report</li>
 * </ul>
 * <p>
 * Per le migrazioni, è necessario produrre un file h2.xml (per differenziarsi dal migrations.xml usato dall'helper)
 */
@Slf4j
public class H2Procedure implements EnvironmentAwareProcedure, AutoCloseable {

	private static final Object GLOBAL_H2_MUTEX = new Object();

	@Getter
	private Path h2Folder = null;

	private File fileName;
	private Connection connection;

	public static final String JDBI_H2_CONNECTION = "jdbi_h2_conn";

	// public static final String H2_DIR = "h2_dir";
	private static final String H2_MIGRATION = "h2.xml";
	private static final String H2_FOLDER_NAME = "h2";

	public String getConnectionOptions() {
		return "IGNORECASE=TRUE;MODE=Postgresql";
	}

	@Override
	public void execute(ProcessData processData, ProcedureEnvironment env) {
		String tenantId = processData.getTenantId();
		var workDir = env.<String>getProperty(ProcEnvConstants.PROPERTY_WORK_DIR).orElse(System.getProperty("java.io.tmpdir"));
		var workflowCode = processData.getWorkflowCode();

		var path = env.<String>getProperty(ProcEnvConstants.PROPERTY_SOURCE_DIR).orElse(System.getProperty("java.io.tmpdir"));

		var h2Dir = Path.of(workDir, H2_FOLDER_NAME, String.format("%s_%s_%s", tenantId, workflowCode, processData.getProcessId().toString()));
		String dbName = String.format("%s_%s", processData.getWorkflowCode(), processData.getProcessId()).toLowerCase();

		connection = this.createConnection(h2Dir, dbName);
		log.info("h2 created in {} with name {}", h2Dir, dbName);

		this.h2Folder = h2Dir;
		this.fileName = new File(h2Dir.toFile(), dbName);

		processData.getGlobalVars().put(DEFAULT_REPORT_CONNECTION, connection);
		processData.getGlobalVars().put(JDBI_H2_CONNECTION, Jdbi.create(connection));

		// createConnection duplicato in quanto il 'try (Connection connection..' della procedura di migrazione chiude la connessione
		this.installMigrations(createConnection(h2Dir, dbName), Path.of(path));
	}

	protected Connection createConnection(Path path, String name) {
		String conn = String.format("jdbc:h2:file:%s;%s", Path.of(path.toString(), name), getConnectionOptions());
		try {
			return DriverManager.getConnection(conn);
		} catch (SQLException e) {
			throw new RuntimeException("error creating h2 db " + conn, e);
		}
	}

	protected void installMigrations(Connection conn, Path workDir) {
		log.info("search h2 migrations.. {}", workDir);
		Optional<File> migration = Arrays.stream(
				Objects.requireNonNull(workDir.toFile()
						.listFiles((dir1, name) -> name.equalsIgnoreCase(H2_MIGRATION))))
				.findFirst();

		migration.ifPresentOrElse(m -> {
			log.info("executing h2 migration: {}", m.getAbsolutePath());

			/*
			 * TOM: It looks like liquibase is not thread safe by default. We could install a ThreadLocalScopeManager as described in
			 * https://github.com/liquibase/liquibase/pull/3240 but I am unsure about future evolution and possible side effects of this in other
			 * classes/databases we could use in the future.
			 *
			 * Given that print migrations are really fast, I prefer to synchronize them and have one migration running at a time.
			 */
			synchronized (GLOBAL_H2_MUTEX) {
				try (Connection connection = conn) {
					var accessor = new DirectoryResourceAccessor(workDir);
					Liquibase migrator = new Liquibase(m.getName(), accessor, new liquibase.database.jvm.JdbcConnection(connection));
					migrator.update("");
					log.info("h2 migration successfully applied");
				} catch (Throwable t) {
					throw new RuntimeException(String.format("error in liquibase migration %s for h2 db %s ", m.getAbsolutePath(), workDir), t);
				}
			}
		}, () -> log.info("no h2 migration found with name {} in folder {}", H2_MIGRATION, workDir));
	}

	protected File getFileName() {
		return fileName;
	}

	@Override
	public void close() throws Exception {
		if (connection != null) {
			connection.close();
			onConnectionClosed(fileName);
		}

		Optional.ofNullable(this.h2Folder)
				.map(Path::toFile)
				.filter(File::exists)
				.ifPresent(FileUtils::deleteQuietly);
	}

	protected void onConnectionClosed(File fileName) throws Exception {
		// NoOp
	}
}
