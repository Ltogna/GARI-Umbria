package com.abacogroup.printengine.sdk.model;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.HashMap;
import java.util.Map;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Builder.Default;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder(setterPrefix = "set")
public class PrintEngineInput {

	public static final String PARAM_NAME = "input";

	@JsonProperty("_params")
	@JsonAnyGetter
	@JsonAnySetter
	@Default
	private Map<String, Object> params = new HashMap<>();

}
