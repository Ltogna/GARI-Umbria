package com.abacogroup.printengine.sdk.proc;

import static com.abacogroup.printengine.sdk.proc.support.spreadsheet.WorkbookSupport.MAX_COLUMS;
import static com.abacogroup.printengine.sdk.proc.support.spreadsheet.WorkbookSupport.MAX_ROWS;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

import org.apache.commons.lang3.StringUtils;
import org.jdbi.v3.core.Handle;
import org.jdbi.v3.core.Jdbi;
import org.jdbi.v3.core.statement.Query;
import org.jdbi.v3.core.statement.SqlStatements;
import org.jdbi.v3.core.statement.StatementContext;
import org.jdbi.v3.core.statement.StatementCustomizer;

import com.abacogroup.printengine.sdk.ProcEnvConstants;
import com.abacogroup.printengine.sdk.exceptions.PrintEngineException;
import com.abacogroup.printengine.sdk.model.PrintEngineInput;
import com.abacogroup.printengine.sdk.model.PrintParameter;
import com.abacogroup.printengine.sdk.model.SpreadsheetParameter;
import com.abacogroup.printengine.sdk.proc.support.spreadsheet.WorkbookSupport;
import com.abacogroup.printengine.sdk.util.ProcUtils;
import com.abacogroup.workflow.sdk.beans.ProcessData;
import com.abacogroup.workflow.sdk.proc.EnvironmentAwareProcedure;
import com.abacogroup.workflow.sdk.proc.ProcedureEnvironment;

public class CreateSpreadsheets extends AbstractFileProcedure implements EnvironmentAwareProcedure {

	@Override
	protected String getExtension() {
		return "xlsx";
	}

	@Override
	protected void writeFile(ProcessData processData, ProcedureEnvironment env, String destFileName, PrintEngineInput input) {
		try {
			SpreadsheetParameter printParameter = processData.getProcedureParameter(SpreadsheetParameter.class);

			Jdbi jdbi = ProcUtils.getJdbi(processData, env);
			jdbi.getConfig().get(SqlStatements.class).setUnusedBindingAllowed(true);

			HashMap<String, Object> params = new HashMap<>(Map.of(
					PROCESS_ID, processData.getProcessId()));
			params.putAll(input.getParams());
			// TODO add from global vars

			String queryName = printParameter.getQueryString();
			try (
					WorkbookSupport workbookSupport = new WorkbookSupport(this.getTemplatePath(env, printParameter).orElse(null), destFileName);
					Handle handle = jdbi.open();
					Query query = handle.createQuery(queryName)) {
				workbookSupport.newActiveSheet();

				query.bindMap(params)
						.setMaxFieldSize(MAX_COLUMS)
						.setMaxRows(MAX_ROWS - 1)
						.addCustomizer(new StatementCustomizer() {
							@Override
							public void beforeExecution(PreparedStatement stmt, StatementContext ctx) throws SQLException {
								workbookSupport.fillHeader(stmt.getMetaData());
							}
						})
						.execute((statementSupplier, ctx) -> {
							try (ResultSet resultSet = statementSupplier.get().executeQuery()) {
								workbookSupport.fillRows(resultSet);
							}
							return null;
						});

				workbookSupport.print(destFileName);
			}
		} catch (Exception ex) {
			throw new PrintEngineException("error building file " + destFileName, ex);
		}
	}

	private Optional<String> getTemplatePath(ProcedureEnvironment env, PrintParameter printParameter) {
		var sourceDir = env.<String>getProperty(ProcEnvConstants.PROPERTY_SOURCE_DIR).orElse(System.getProperty("java.io.tmpdir"));

		String subPath = printParameter.getPath();
		String templateParentPath = StringUtils.isBlank(subPath) ? sourceDir
				: String.format("%s/%s", sourceDir, StringUtils.removeStart(subPath, "/"));

		return Optional.ofNullable(printParameter.getMainTemplate()).filter(StringUtils::isNotBlank)
				.map(templateName -> String.format("%s/%s", templateParentPath, templateName));
	}

}
