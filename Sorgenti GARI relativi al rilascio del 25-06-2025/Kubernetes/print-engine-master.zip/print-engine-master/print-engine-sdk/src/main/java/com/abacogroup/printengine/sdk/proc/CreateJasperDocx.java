package com.abacogroup.printengine.sdk.proc;

import java.io.File;

import com.abacogroup.printengine.sdk.exceptions.PrintEngineException;
import com.abacogroup.printengine.sdk.model.PrintEngineInput;
import com.abacogroup.workflow.sdk.beans.ProcessData;
import com.abacogroup.workflow.sdk.proc.ProcedureEnvironment;

import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.SimpleJasperReportsContext;
import net.sf.jasperreports.engine.export.ooxml.JRDocxExporter;
import net.sf.jasperreports.export.DocxExporterConfiguration;
import net.sf.jasperreports.export.DocxReportConfiguration;
import net.sf.jasperreports.export.Exporter;
import net.sf.jasperreports.export.ExporterInput;
import net.sf.jasperreports.export.OutputStreamExporterOutput;
import net.sf.jasperreports.export.SimpleExporterInput;
import net.sf.jasperreports.export.SimpleOutputStreamExporterOutput;

public class CreateJasperDocx extends AbstractJRProcedure {

	@Override
	protected String getExtension() {
		return "docx";
	}

	@Override
	protected void exportReportToFile(SimpleJasperReportsContext context, JasperPrint jasperPrint, String fileName) {
		try {
			Exporter<ExporterInput, DocxReportConfiguration, DocxExporterConfiguration, OutputStreamExporterOutput> exporter = new JRDocxExporter();
			exporter.setExporterInput(new SimpleExporterInput(jasperPrint));
			File exportReportFile = new File(fileName);
			exporter.setExporterOutput(new SimpleOutputStreamExporterOutput(exportReportFile));
			exporter.exportReport();
		} catch (Exception ex) {
			String msg = String.format("error creating %s (%s)", getExtension(), fileName);
			throw new PrintEngineException(msg, ex);
		}
	}

	@Override
	protected void customizeJasperContext(SimpleJasperReportsContext context, ProcessData processData, ProcedureEnvironment env, String destFileName,
			PrintEngineInput input) {

		env.getProperty(JASPER_METADATA_TITLE)
				.map(Object::toString)
				.ifPresent(v -> context.setProperty(DocxExporterConfiguration.PROPERTY_METADATA_TITLE, v));

		env.getProperty(JASPER_METADATA_SUBJECT)
				.map(Object::toString)
				.ifPresent(v -> context.setProperty(DocxExporterConfiguration.PROPERTY_METADATA_SUBJECT, v));

		env.getProperty(JASPER_METADATA_AUTHOR)
				.map(Object::toString)
				.ifPresent(v -> context.setProperty(DocxExporterConfiguration.PROPERTY_METADATA_AUTHOR, v));

		env.getProperty(JASPER_METADATA_KEYWORDS)
				.map(Object::toString)
				.ifPresent(v -> context.setProperty(DocxExporterConfiguration.PROPERTY_METADATA_KEYWORDS, v));
	}

}
