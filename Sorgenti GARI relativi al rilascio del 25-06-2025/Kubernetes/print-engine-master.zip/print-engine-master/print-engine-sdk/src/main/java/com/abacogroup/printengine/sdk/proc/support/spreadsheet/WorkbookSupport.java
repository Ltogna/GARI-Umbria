package com.abacogroup.printengine.sdk.proc.support.spreadsheet;

import java.io.Closeable;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.Date;
import java.util.Optional;
import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.sl.draw.geom.Formula;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row.MissingCellPolicy;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class WorkbookSupport implements Closeable, ExportSupport {

	public static final int MAX_COLUMS = 16_384;
	public static final int MAX_ROWS = 1_048_576;

	private final XSSFWorkbook workbook;

	private CellStyle dateStyle;
	private XSSFSheet activeSheet;
	private Integer currentIndex = -1;

	public WorkbookSupport(String sourcePath, String destPath) throws IOException, InvalidFormatException {
		if (sourcePath != null) {
			File source = Optional.of(sourcePath)
					.filter(StringUtils::isNotBlank)
					.map(File::new)
					.filter(File::exists)
					.filter(File::isFile)
					.orElseThrow(() -> new IllegalStateException(String.format("invalid template path '%s'", sourcePath)));

			FileUtils.copyFile(source, new File(destPath));
			File tempFile = new File(destPath);
			workbook = new XSSFWorkbook(tempFile);
		} else {
			workbook = new XSSFWorkbook();
		}
		dateStyle = buildDefaultCellDateStyle(workbook);
	}

	public void newActiveSheet() {
		if (workbook.getNumberOfSheets() > currentIndex + 1) {
			currentIndex++;
			activeSheet = workbook.getSheetAt(currentIndex);
		} else {
			activeSheet = workbook.createSheet();
			currentIndex++;
		}
	}

	public void fillHeader(ResultSetMetaData metaData) throws SQLException {
		if (activeSheet == null) {
			this.newActiveSheet();
		}

		XSSFRow row = getOrCreateRow(0);
		int cc = metaData.getColumnCount();
		for (int i = 1; i <= cc; i++) {
			String columnName = metaData.getColumnName(i);
			XSSFCell cell = getOrCreateCell(row, i - 1);
			cell.setCellValue(columnName);
		}
	}

	@Override
	public void fillRows(ResultSet resultSet) throws SQLException {
		if (activeSheet == null) {
			this.newActiveSheet();
		}

		ResultSetMetaData metaData = resultSet.getMetaData();
		int cc = metaData.getColumnCount();
		int i = 1;
		while (resultSet.next()) {
			XSSFRow row = getOrCreateRow(i);
			for (int j = 1; j <= cc; j++) {
				Object value = resultSet.getObject(j);
				XSSFCell cell = getOrCreateCell(row, j - 1);
				this.setCellValue(value, cell);
			}
			i++;
		}
	}

	private XSSFRow getOrCreateRow(int i) {
		return Optional.ofNullable(activeSheet.getRow(i))
				.orElseGet(() -> activeSheet.createRow(i));
	}

	private XSSFCell getOrCreateCell(XSSFRow row, int i) {
		return row.getCell(i, MissingCellPolicy.CREATE_NULL_AS_BLANK);
	}

	@Override
	public void print(String fileName) throws IOException {
		FileOutputStream out = FileUtils.openOutputStream(new File(fileName));
		workbook.write(out);
		out.close();
	}

	private void setCellValue(Object value, XSSFCell cell) {
		if (value != null) {
			if (value instanceof Date) {
				if (cell.getCellStyle().getDataFormat() == 0) {
					cell.setCellStyle(dateStyle);
				}
				cell.setCellValue((Date) value);
			} else if (value instanceof Boolean) {
				cell.setCellValue((Boolean) value);
			} else if (value instanceof Number) {
				cell.setCellValue(((Number) value).doubleValue());
			} else if (value instanceof Formula) {
				cell.setCellType(CellType.FORMULA);
				cell.setCellFormula(value.toString());
			} else {
				cell.setCellValue(value.toString());
			}
		}
	}

	private CellStyle buildDefaultCellDateStyle(XSSFWorkbook workbook) {
		CellStyle dateStyle = workbook.createCellStyle();
		dateStyle.setDataFormat((short) 14);
		return dateStyle;
	}

	@Override
	public void close() throws IOException {
		workbook.close();
	}
}
