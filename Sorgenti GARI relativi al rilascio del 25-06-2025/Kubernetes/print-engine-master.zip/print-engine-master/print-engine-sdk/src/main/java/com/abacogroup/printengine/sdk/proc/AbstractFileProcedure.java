package com.abacogroup.printengine.sdk.proc;

import static com.abacogroup.printengine.sdk.model.PrintEngineInput.PARAM_NAME;

import com.abacogroup.printengine.sdk.Constants;
import com.abacogroup.printengine.sdk.model.PrintEngineInput;
import com.abacogroup.printengine.sdk.util.ProcUtils;
import com.abacogroup.workflow.sdk.beans.ProcessData;
import com.abacogroup.workflow.sdk.proc.EnvironmentAwareProcedure;
import com.abacogroup.workflow.sdk.proc.ProcedureEnvironment;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public abstract class AbstractFileProcedure implements EnvironmentAwareProcedure {

	protected static final String PROCESS_ID = "PROCESS_ID";

	protected abstract String getExtension();

	@Override
	public final void execute(ProcessData processData, ProcedureEnvironment env) throws Exception {

		String fileName = ProcUtils.getFileName(processData, env, this.getExtension());
		PrintEngineInput input = processData.<PrintEngineInput>getGlobalVar(PARAM_NAME).orElseThrow();

		this.writeFile(processData, env, fileName, input);

		processData.getGlobalVars().put(Constants.OUTPUT_PATH, fileName);
		log.info("file created: {}", fileName);
	}

	protected abstract void writeFile(ProcessData processData, ProcedureEnvironment env, String destFileName, PrintEngineInput input);
}
