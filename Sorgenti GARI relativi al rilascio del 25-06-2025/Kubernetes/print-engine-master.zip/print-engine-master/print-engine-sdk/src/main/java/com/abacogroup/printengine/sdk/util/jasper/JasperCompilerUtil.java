package com.abacogroup.printengine.sdk.util.jasper;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.stream.Stream;

import org.apache.commons.io.FilenameUtils;

import com.abacogroup.printengine.sdk.Constants;

import jakarta.validation.constraints.NotNull;
import lombok.extern.slf4j.Slf4j;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperCompileManager;

@Slf4j
public class JasperCompilerUtil {

	public static void compileAll(@NotNull Path workDir) {
		try {
			try (Stream<Path> files = Files
					.walk(workDir)
					.filter(x -> x.getFileName().toString().toLowerCase().endsWith(Constants.JRXML));) {
				files.forEach(JasperCompilerUtil::compile);
			}

		} catch (IOException ex) {
			log.error("error in compile", ex);
			throw new RuntimeException("error in compile", ex);
		}
	}

	private static void compile(Path path) {
		try {
			File jrxmlFile = path.toFile();
			String extension = FilenameUtils.getExtension(jrxmlFile.getAbsolutePath());
			var jasper = jrxmlFile.getAbsolutePath().replace(extension, Constants.JASPER);
			compile(jrxmlFile, new FileOutputStream(jasper));
		} catch (FileNotFoundException ex) {
			throw new RuntimeException("error in compile " + path, ex);
		}
	}

	private static void compile(File jasper, OutputStream out) {
		try {
			JasperCompileManager.compileReportToStream(new FileInputStream(jasper.getAbsolutePath()), out);
		} catch (JRException | FileNotFoundException e) {
			log.error("error in compile", e);
			throw new RuntimeException("error in compile");
		}
	}
}
