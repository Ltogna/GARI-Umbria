package com.abacogroup.printengine.sdk.proc;

import java.io.File;
import java.io.IOException;
import java.sql.ResultSet;
import java.util.HashMap;
import java.util.Map;

import org.jdbi.v3.core.Handle;
import org.jdbi.v3.core.Jdbi;
import org.jdbi.v3.core.statement.Query;
import org.jdbi.v3.core.statement.SqlStatements;

import com.abacogroup.printengine.sdk.ProcEnvConstants;
import com.abacogroup.printengine.sdk.exceptions.PrintEngineException;
import com.abacogroup.printengine.sdk.model.CsvParameter;
import com.abacogroup.printengine.sdk.model.PrintEngineInput;
import com.abacogroup.printengine.sdk.proc.support.spreadsheet.CsvSupport;
import com.abacogroup.printengine.sdk.util.ProcUtils;
import com.abacogroup.workflow.sdk.beans.ProcessData;
import com.abacogroup.workflow.sdk.proc.EnvironmentAwareProcedure;
import com.abacogroup.workflow.sdk.proc.ProcedureEnvironment;

public class CreateCsv extends AbstractFileProcedure implements EnvironmentAwareProcedure {

	@Override
	protected String getExtension() {
		return "csv";
	}

	@Override
	protected void writeFile(ProcessData processData, ProcedureEnvironment env, String destFileName, PrintEngineInput input) {
		try {
			Jdbi jdbi = ProcUtils.getJdbi(processData, env);
			jdbi.getConfig().get(SqlStatements.class).setUnusedBindingAllowed(true);

			var workDir = env.<String>getProperty(ProcEnvConstants.PROPERTY_WORK_DIR).orElse(System.getProperty("java.io.tmpdir"));

			HashMap<String, Object> params = new HashMap<>(Map.of(
					PROCESS_ID, processData.getProcessId()));
			params.putAll(input.getParams());
			// TODO add from global vars

			CsvParameter printParameter = processData.getProcedureParameter(CsvParameter.class);
			String queryName = printParameter.getQueryString();
			try (
					CsvSupport csvSupport = new CsvSupport(new File(workDir));
					Handle handle = jdbi.open();
					Query query = handle.createQuery(queryName)) {
				query.bindMap(params)
						.execute((statementSupplier, ctx) -> {
							try (ResultSet resultSet = statementSupplier.get().executeQuery()) {
								csvSupport.fillRows(resultSet);
							} catch (IOException e) {
								throw new RuntimeException(e);
							}
							return null;
						});

				csvSupport.print(destFileName);
			}
		} catch (Exception ex) {
			throw new PrintEngineException("error building file " + destFileName, ex);
		}
	}

}
