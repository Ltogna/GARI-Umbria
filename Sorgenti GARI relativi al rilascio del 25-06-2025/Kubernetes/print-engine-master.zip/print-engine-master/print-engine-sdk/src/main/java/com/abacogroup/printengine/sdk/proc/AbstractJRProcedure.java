package com.abacogroup.printengine.sdk.proc;

import static com.abacogroup.printengine.sdk.Constants.JASPER;

import java.io.Closeable;
import java.io.File;
import java.io.IOException;
import java.nio.file.Path;
import java.sql.Connection;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.StringUtils;

import com.abacogroup.printengine.sdk.ProcEnvConstants;
import com.abacogroup.printengine.sdk.exceptions.PrintEngineException;
import com.abacogroup.printengine.sdk.model.PrintEngineInput;
import com.abacogroup.printengine.sdk.model.PrintParameter;
import com.abacogroup.printengine.sdk.proc.support.repository.CachingRepositoryService;
import com.abacogroup.printengine.sdk.util.ProcUtils;
import com.abacogroup.workflow.sdk.beans.ProcessData;
import com.abacogroup.workflow.sdk.proc.ProcedureEnvironment;

import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import net.sf.jasperreports.engine.DefaultJasperReportsContext;
import net.sf.jasperreports.engine.JRParameter;
import net.sf.jasperreports.engine.JRVirtualizer;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.SimpleJasperReportsContext;
import net.sf.jasperreports.engine.fill.JRSwapFileVirtualizer;
import net.sf.jasperreports.engine.util.JRSwapFile;
import net.sf.jasperreports.repo.RepositoryService;

@Slf4j
public abstract class AbstractJRProcedure extends AbstractFileProcedure implements Closeable {

	public static final String JASPER_METADATA_TITLE = "jasper-metadata.title";
	public static final String JASPER_METADATA_SUBJECT = "jasper-metadata.subject";
	public static final String JASPER_METADATA_AUTHOR = "jasper-metadata.author";
	public static final String JASPER_METADATA_KEYWORDS = "jasper-metadata.keywords";

	protected static final String SUBREPORT_DIR = "SUBREPORT_DIR";

	private static final CachingRepositoryService REPOSITORY_SERVICE = new CachingRepositoryService(DefaultJasperReportsContext.getInstance());

	@Getter
	protected Path swapFolder = null;

	private JRVirtualizer virtualizer;

	@Override
	protected void writeFile(ProcessData processData, ProcedureEnvironment env, String destFileName, PrintEngineInput input) {
		try {
			PrintParameter printParameter = processData.getProcedureParameter(PrintParameter.class);
			String templateName = printParameter.getMainTemplate();

			Integer numPagesInMemory = printParameter.getNumPagesInMemory();
			if (numPagesInMemory == null || numPagesInMemory <= 0) {
				numPagesInMemory = 10;
			}

			String reportSourcePath = this.getReportPath(env, printParameter.getPath());
			String mainJasperPath = String.format("%s%s.%s", reportSourcePath, templateName, JASPER);

			String workDir = env.<String>getProperty(ProcEnvConstants.PROPERTY_WORK_DIR).orElse(System.getProperty("java.io.tmpdir"));

			HashMap<String, Object> params = new HashMap<>(Map.of(
					SUBREPORT_DIR, reportSourcePath,
					PROCESS_ID, processData.getProcessId()));

			params.putAll(input.getParams());

			SimpleJasperReportsContext context = new SimpleJasperReportsContext();
			context.setExtensions(RepositoryService.class, Arrays.asList(REPOSITORY_SERVICE));

			customizeJasperContext(context, processData, env, destFileName, input);
			JasperFillManager jasperFillManager = JasperFillManager.getInstance(context);

			virtualizer = this.getJrVirtualizer(context, workDir, processData.getProcessId(), numPagesInMemory);
			params.put(JRParameter.REPORT_VIRTUALIZER, virtualizer);
			params.put(JRParameter.REPORT_LOCALE, new Locale(processData.getAuthContext().getLocaleCode()));

			Connection helperConnection = ProcUtils.getConnection(processData, env);
			JasperPrint jasperPrint = jasperFillManager.fill(mainJasperPath, params, helperConnection);

			this.exportReportToFile(context, jasperPrint, destFileName);
		} catch (Exception ex) {
			throw new PrintEngineException("error building file " + destFileName, ex);
		}
	}

	protected void customizeJasperContext(SimpleJasperReportsContext context,
			ProcessData processData, ProcedureEnvironment env,
			String destFileName, PrintEngineInput input) {
		log.trace("nothing to do");
	}

	protected abstract void exportReportToFile(SimpleJasperReportsContext context, JasperPrint jasperPrint, String fileName);

	/**
	 * @param env
	 * @param subPath
	 * @return report source path ending with '/'
	 */
	protected String getReportPath(ProcedureEnvironment env, String subPath) {
		var sourceDir = env.<String>getProperty(ProcEnvConstants.PROPERTY_SOURCE_DIR).orElse(System.getProperty("java.io.tmpdir"));

		String reportPath = StringUtils.isBlank(subPath) ? sourceDir
				: String.format("%s/%s", sourceDir, StringUtils.removeStart(subPath, "/"));

		return StringUtils.appendIfMissing(reportPath, "/");
	}

	protected JRVirtualizer getJrVirtualizer(SimpleJasperReportsContext context, String workDir, Long processId, int numPagesInRam) {
		File swapDir = buildSwapDir(workDir, processId);
		JRSwapFile swapFile = new JRSwapFile(context, swapDir.getAbsolutePath(), 4096, 256);
		return new JRSwapFileVirtualizer(numPagesInRam, swapFile);
	}

	protected File buildSwapDir(String workDir, Long processId) {
		File swapDir = new File(String.format("%s/.jr_swap/%d", workDir, processId));
		swapDir.mkdirs();
		this.swapFolder = swapDir.toPath();
		log.trace("swap dir: {}", swapDir.getAbsolutePath());
		return swapDir;
	}

	@Override
	public void close() throws IOException {
		if (virtualizer != null) {
			virtualizer.cleanup();
		}

		Optional.ofNullable(this.swapFolder)
				.map(Path::toFile)
				.filter(File::exists)
				.ifPresent(FileUtils::deleteQuietly);
	}
}
