package com.abacogroup.printengine.sdk.proc;

import com.abacogroup.printengine.sdk.exceptions.PrintEngineException;
import com.abacogroup.printengine.sdk.model.PrintEngineInput;
import com.abacogroup.workflow.sdk.beans.ProcessData;
import com.abacogroup.workflow.sdk.proc.ProcedureEnvironment;

import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.SimpleJasperReportsContext;
import net.sf.jasperreports.export.PdfExporterConfiguration;

public class CreateJasperReports extends AbstractJRProcedure {

	@Override
	protected String getExtension() {
		return "pdf";
	}

	@Override
	protected void exportReportToFile(SimpleJasperReportsContext context, JasperPrint jasperPrint, String fileName) {
		try {
			JasperExportManager jasperExportManager = JasperExportManager.getInstance(context);
			jasperExportManager.exportToPdfFile(jasperPrint, fileName);
		} catch (Exception ex) {
			String msg = String.format("error creating %s (%s)", getExtension(), fileName);
			throw new PrintEngineException(msg, ex);
		}
	}

	@Override
	protected void customizeJasperContext(SimpleJasperReportsContext context, ProcessData processData, ProcedureEnvironment env, String destFileName,
			PrintEngineInput input) {

		env.getProperty(JASPER_METADATA_TITLE)
				.map(Object::toString)
				.ifPresent(v -> context.setProperty(PdfExporterConfiguration.PROPERTY_METADATA_TITLE, v));

		env.getProperty(JASPER_METADATA_SUBJECT)
				.map(Object::toString)
				.ifPresent(v -> context.setProperty(PdfExporterConfiguration.PROPERTY_METADATA_SUBJECT, v));

		env.getProperty(JASPER_METADATA_AUTHOR)
				.map(Object::toString)
				.ifPresent(v -> context.setProperty(PdfExporterConfiguration.PROPERTY_METADATA_AUTHOR, v));

		env.getProperty(JASPER_METADATA_KEYWORDS)
				.map(Object::toString)
				.ifPresent(v -> context.setProperty(PdfExporterConfiguration.PROPERTY_METADATA_KEYWORDS, v));
	}

}
