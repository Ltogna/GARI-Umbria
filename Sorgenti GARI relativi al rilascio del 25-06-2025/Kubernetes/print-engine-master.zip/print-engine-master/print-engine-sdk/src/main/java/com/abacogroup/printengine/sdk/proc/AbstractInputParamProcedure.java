package com.abacogroup.printengine.sdk.proc;

import java.util.Map;

import com.abacogroup.printengine.sdk.ProcEnvConstants;
import com.abacogroup.printengine.sdk.exceptions.PrintEngineException;
import com.abacogroup.printengine.sdk.model.PrintEngineInput;
import com.abacogroup.workflow.sdk.beans.ProcessData;
import com.abacogroup.workflow.sdk.proc.EnvironmentAwareProcedure;
import com.abacogroup.workflow.sdk.proc.ProcedureEnvironment;
import com.fasterxml.jackson.databind.ObjectMapper;

import jakarta.validation.ConstraintViolationException;
import jakarta.validation.Validation;
import jakarta.validation.Validator;
import jakarta.validation.ValidatorFactory;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public abstract class AbstractInputParamProcedure<T> implements EnvironmentAwareProcedure {

	protected String getParamDto() {
		return "paramDto";
	}

	@Override
	public void execute(ProcessData processData, ProcedureEnvironment procedureEnvironment) {
		log.debug("executing validation procedure {}", this.getClass());

		PrintEngineInput input = (PrintEngineInput) processData.getGlobalVar(PrintEngineInput.PARAM_NAME).orElseThrow();
		ObjectMapper mapper = (ObjectMapper) procedureEnvironment.getProperty(ProcEnvConstants.PROPERTY_OBJECT_MAPPER).orElseThrow();
		T paramDto = getReportParamDto(mapper, input.getParams());
		processData.getGlobalVars().put(getParamDto(), paramDto);
	}

	protected T getReportParamDto(ObjectMapper mapper, Map<String, Object> params) {
		T paramDto = convertDto(mapper, params);
		ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
		Validator validator = factory.getValidator();

		var violations = validator.validate(paramDto);
		if (!violations.isEmpty()) {
			throw new PrintEngineException("invalid payload", new ConstraintViolationException(violations));
		}
		return paramDto;
	}

	public abstract T convertDto(ObjectMapper mapper, Map<String, Object> params);

}
