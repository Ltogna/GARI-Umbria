package com.abacogroup.printengine.sdk.proc;

import static com.abacogroup.printengine.sdk.model.PrintEngineInput.PARAM_NAME;

import com.abacogroup.printengine.sdk.model.ListParam;
import com.abacogroup.printengine.sdk.model.PrintEngineInput;
import com.abacogroup.workflow.sdk.beans.ProcessData;
import com.abacogroup.workflow.sdk.proc.EnvironmentAwareProcedure;
import com.abacogroup.workflow.sdk.proc.ProcedureEnvironment;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Optional;
import java.util.stream.Collectors;

public class FlatParamsProc implements EnvironmentAwareProcedure {

	@Override
	public void execute(ProcessData processData, ProcedureEnvironment procedureEnvironment) throws Exception {
		List<?> paramsToFlat = Optional.ofNullable(processData.getProcedureParameter(ListParam.class).getList()).orElse(new ArrayList<>());

		PrintEngineInput input = processData.<PrintEngineInput>getGlobalVar(PARAM_NAME).orElseThrow();

		Map<String, Object> singleValuesMap = input.getParams().entrySet().stream()
				.filter(e -> paramsToFlat.contains(e.getKey()))
				.filter(e -> e.getValue() instanceof List<?>)
				.filter(e -> !((List<?>) e.getValue()).isEmpty())
				.map(e -> {
					Object singleValue = ((List<?>) e.getValue()).get(0);
					return Map.entry(e.getKey(), singleValue);
				}).collect(Collectors.toMap(Entry::getKey, Entry::getValue));

		input.getParams().putAll(singleValuesMap);

	}
}
