package com.abacogroup.printengine.sdk;

public interface Constants {

	String DEFAULT_REPORT_CONNECTION = "default_report_connection";
	String OUTPUT_PATH = "output_path";

	String JRXML = "jrxml";

	String JASPER = "jasper";
}
