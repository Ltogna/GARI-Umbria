package com.abacogroup.printengine.core.service.impl;

import com.abacogroup.printengine.api.PrintJobResponse;
import com.abacogroup.printengine.core.service.PrintJobEventProducer.JobEventType;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Value;

@Value
public class PrintJobMessage {
	private final String tenant;
	private final PrintJobResponse message;
	private final JobEventType eventType;

	@JsonCreator
	public PrintJobMessage(@JsonProperty("tenant") String tenant,
			@JsonProperty("message") PrintJobResponse message,
			@JsonProperty("eventType") JobEventType eventType) {
		super();
		this.tenant = tenant;
		this.message = message;
		this.eventType = eventType;
	}

	public String getRoutingKey() {
		return eventType.getTopic(message.getDest());
	}
}
