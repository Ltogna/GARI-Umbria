package com.abacogroup.printengine.api;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder(setterPrefix = "set")
@NoArgsConstructor
public class CreatePrintJobResponse {

	private String uuid;

}
