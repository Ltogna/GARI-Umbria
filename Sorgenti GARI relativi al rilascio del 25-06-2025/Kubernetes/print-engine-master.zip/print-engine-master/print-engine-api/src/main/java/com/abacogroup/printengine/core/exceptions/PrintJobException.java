package com.abacogroup.printengine.core.exceptions;

import io.swagger.v3.oas.annotations.media.Schema;

public class PrintJobException extends AbstractAppException {

	private static final long serialVersionUID = 8576761590901517085L;

	public PrintJobException(PrintJobException.ErrEnum code, String message) {
		super(new PrintJobException.ErrorBody(code.name(), message));
	}

	public enum ErrEnum {
		GENERIC,
		PRINT_JOB_ERROR,
		PRINT_JOB_NOT_FOUND
	}

	@Schema(name = "PrintJobExceptionErrorBody")
	public static class ErrorBody implements ExceptionErrorBody {
		private final String code;
		private final String message;

		public ErrorBody(String code, String message) {
			this.code = code;
			this.message = message;
		}

		@Override
		@Schema(allowableValues = { "GENERIC", "PRINT_JOB_ERROR", "PRINT_JOB_NOT_FOUND" })
		public String getErrorCode() {
			return code;
		}

		@Override
		@Schema
		public String getMessage() {
			return message;
		}
	}
}
