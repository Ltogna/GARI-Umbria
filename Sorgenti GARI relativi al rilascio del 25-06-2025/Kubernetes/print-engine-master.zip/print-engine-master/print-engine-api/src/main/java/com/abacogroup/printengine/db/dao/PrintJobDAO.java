package com.abacogroup.printengine.db.dao;

import com.abacogroup.jdbi.EnhancedSqlObject;
import com.abacogroup.printengine.api.PrintJobStatus;
import com.abacogroup.printengine.db.ntt.PrintJobEntity;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.customizer.BindBean;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;
import org.jdbi.v3.sqlobject.transaction.Transactional;

public interface PrintJobDAO extends Transactional<PrintJobDAO>, EnhancedSqlObject, BasicDAO {

	@SqlUpdate("insert into pre_print_jobs (uuid, report_id, status, file_store_id,dt_insert,bucket,dest) "
			+ "values (:uuid, :reportId, :status, :fileStoreId, :dtInsert, :bucket, :dest)")
	void insert(@BindBean PrintJobEntity entity);

	@SqlUpdate("update pre_print_jobs set status = :status ,dt_insert = :dtInsert where uuid = :uuid")
	void updateStatus(
			@Bind("uuid") String uuid,
			@Bind("status") PrintJobStatus status,
			@Bind("dtInsert") LocalDateTime dtInsert);

	@SqlUpdate("update pre_print_jobs set status = :status ,dt_insert = :dtInsert, file_store_id = :fileStoreId where uuid = :uuid")
	void updateStatus(@Bind("uuid") String uuid,
			@Bind("status") PrintJobStatus status,
			@Bind("fileStoreId") String fileStoreId,
			@Bind("dtInsert") LocalDateTime dtInsert);

	@SqlQuery("select uuid,report_id,status,file_store_id,dt_insert,bucket,dest from pre_print_jobs where uuid = :uuid")
	@RegisterBeanMapper(PrintJobEntity.class)
	Optional<PrintJobEntity> findByUUID(@Bind("uuid") String uuid);

	@SqlQuery("select j.uuid, j.report_id, j.status, j.file_store_id ,j.dt_insert ,j.bucket ,j.dest from pre_print_jobs j "
			+ " inner join pre_jasper_reports r on r.id = j.report_id "
			+ " where r.workflow_code = :workflowCode and r.tenant_id = :tenantId and j.uuid = :uuid")
	@RegisterBeanMapper(PrintJobEntity.class)
	Optional<PrintJobEntity> findByTenantAndWorkFlowCodeAndUUID(
			@Bind("tenantId") String tenantId,
			@Bind("workflowCode") String workflowCode,
			@Bind("uuid") String uuid);

	@SqlQuery("select j.uuid, j.report_id, j.status, j.file_store_id ,j.dt_insert, j.bucket, j.dest from pre_print_jobs j "
			+ " inner join pre_jasper_reports r on r.id = j.report_id "
			+ " where  r.tenant_id = :tenantId and j.uuid = :uuid")
	@RegisterBeanMapper(PrintJobEntity.class)
	Optional<PrintJobEntity> findByTenantAndUUID(
			@Bind("tenantId") String tenantId,
			@Bind("uuid") String uuid);

	@SqlQuery("select j.uuid, j.report_id, j.status, j.file_store_id , j.dt_insert , j.bucket , j.dest from pre_print_jobs j "
			+ " inner join pre_jasper_reports r on r.id = j.report_id "
			+ " where r.workflow_code = :workflowCode and r.tenant_id = :tenantId")
	@RegisterBeanMapper(PrintJobEntity.class)
	List<PrintJobEntity> findAllByTenantAndWorkFlowCode(
			@Bind("tenantId") String tenantId,
			@Bind("workflowCode") String workflowCode);

}
