package com.abacogroup.printengine.db.dao;

import com.abacogroup.jdbi.EnhancedSqlObject;
import java.time.LocalDateTime;
import org.jdbi.v3.sqlobject.statement.SqlQuery;

interface BasicDAO extends EnhancedSqlObject {

	@SqlQuery("§select_from_dual(§current_timestamp§)§")
	LocalDateTime getCurrentTimestamp();

}
