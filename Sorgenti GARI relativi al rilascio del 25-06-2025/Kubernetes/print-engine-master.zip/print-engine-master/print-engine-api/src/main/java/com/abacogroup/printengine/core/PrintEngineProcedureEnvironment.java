package com.abacogroup.printengine.core;

import static com.abacogroup.printengine.sdk.ProcEnvConstants.PROPERTY_PROFILE;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Properties;

import javax.sql.DataSource;

import org.apache.commons.lang3.StringUtils;
import org.jdbi.v3.core.Jdbi;

import com.abacogroup.printengine.PrintEngineConfig.PrintEngineConfiguration;
import com.abacogroup.printengine.core.exceptions.PrintJobException;
import com.abacogroup.printengine.core.exceptions.PrintJobException.ErrEnum;
import com.abacogroup.printengine.sdk.PrintEngineUtils;
import com.abacogroup.printengine.sdk.ProcEnvConstants;
import com.abacogroup.workflow.sdk.beans.ProcessData;
import com.abacogroup.workflow.sdk.proc.ProcedureEnvironment;
import com.fasterxml.jackson.databind.ObjectMapper;

import jakarta.ws.rs.client.Client;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class PrintEngineProcedureEnvironment implements ProcedureEnvironment, AutoCloseable {
	public static final String BASE_PROPERTIES_FILE_NAME = "application";
	private final Client client;
	private final Jdbi jdbiHelper;
	private final DataSource helperDataSource;
	private final ObjectMapper objectMapper;
	private final PrintEngineConfiguration printEngineConfiguration;

	private final String workDir;
	private final String sourceDir;
	private final String outputFileName;
	private final Properties propertiesMap;

	private final List<AutoCloseable> closeables;

	public PrintEngineProcedureEnvironment(ProcessData processData, Client client, Jdbi jdbiHelper, DataSource helperDataSource,
			ObjectMapper objectMapper, PrintEngineConfiguration printEngineConfiguration) {
		this.client = client;
		this.jdbiHelper = jdbiHelper;
		this.helperDataSource = helperDataSource;
		this.objectMapper = objectMapper;
		this.printEngineConfiguration = Optional.ofNullable(printEngineConfiguration).orElse(new PrintEngineConfiguration());

		// paths
		String tenantId = processData.getTenantId();
		String workflowCode = processData.getWorkflowCode();
		String workflowHash = processData.getWorkflowHash();
		Long processId = processData.getProcessId();

		this.workDir = this.printEngineConfiguration.getInitBaseTempDir();
		this.sourceDir = PrintEngineUtils.getSourceDir(this.workDir, tenantId, workflowCode, workflowHash)
				.toFile().getAbsolutePath();
		this.outputFileName = String.format("%s/%s.pdf", this.workDir, processId);
		this.propertiesMap = this.retrieveProperties(sourceDir, this.printEngineConfiguration, processData);
		this.closeables = new ArrayList<>();
	}

	@Override
	@SuppressWarnings("unchecked")
	public <T> Optional<T> getProperty(String name) {

		Object ret = null;
		switch (name) {
		case ProcEnvConstants.PROPERTY_WORK_DIR:
			ret = workDir;
			break;
		case ProcEnvConstants.PROPERTY_SOURCE_DIR:
			ret = sourceDir;
			break;
		case ProcEnvConstants.PROPERTY_FILE_NAME:
			ret = outputFileName;
			break;
		case ProcEnvConstants.PROPERTY_HELPER_CONNECTION:
			try {
				Connection cnn = helperDataSource.getConnection();
				closeables.add(cnn);
				ret = cnn;
			} catch (SQLException e) {
				log.error("Error retrieving helper DB connection", e);
				throw new PrintJobException(ErrEnum.GENERIC, "Error retrieving helper DB connection");
			}
			break;
		case ProcEnvConstants.PROPERTY_OBJECT_MAPPER:
			ret = objectMapper;
			break;
		case PROPERTY_PROFILE:
			ret = printEngineConfiguration.getWorkFlowEnvironmentId();
			break;
		default:
			ret = propertiesMap.get(name);
			break;
		}

		return Optional.ofNullable((T) ret);
	}

	@Override
	public Optional<Client> getJerseyClient() {
		return Optional.ofNullable(client);
	}

	@Override
	public Optional<Jdbi> getJdbi(String datasourceName) {
		if (ProcEnvConstants.JDBI_HELPER.equals(datasourceName)) {
			return Optional.of(jdbiHelper);
		}
		if (ProcEnvConstants.JDBI_PRINT_ENGINE.equals(datasourceName)) {
			log.warn("this jdbi is not allowed");
			return Optional.empty();
		}
		return Optional.empty();
	}

	// TODO ENABLE
	// @Override
	// public String getEnvironmentId() {
	// return printEngineConfiguration.getProfile();
	// }

	@Override
	public void close() throws Exception {
		Exception ex = null;
		for (AutoCloseable c : closeables) {
			try {
				c.close();
			} catch (Exception e) {
				log.error(e.getMessage(), e);
				ex = e;
			}
		}

		if (ex != null) {
			throw ex;
		}
	}

	private Properties retrieveProperties(String sourceDir, PrintEngineConfiguration printEngineConfiguration, ProcessData processData) {
		String envId = printEngineConfiguration.getWorkFlowEnvironmentId();
		String workflowCode = processData.getWorkflowCode();
		String tenantId = processData.getTenantId();

		log.info("active envId: {}", envId);
		List<String> propertySources;
		String externalPropertiesDir = printEngineConfiguration.getExternalPropertiesDir();
		if (StringUtils.isNotBlank(externalPropertiesDir)) {
			externalPropertiesDir = StringUtils.removeEnd(externalPropertiesDir, "/");
			propertySources = List.of(
					sourceDir,
					externalPropertiesDir,
					String.format("%s/%s", externalPropertiesDir, tenantId),
					String.format("%s/%s/%s", externalPropertiesDir, tenantId, workflowCode));
		} else {
			propertySources = List.of(sourceDir);
		}

		Properties properties = new Properties();
		for (String propertySource : propertySources) {
			log.debug("scan {} properties in {}", workflowCode, propertySource);
			properties = PrintEngineUtils.retrieveProperties(properties, propertySource, BASE_PROPERTIES_FILE_NAME, envId);
		}

		var props = PrintEngineUtils.resolveProperties(properties, properties);
		log.debug("current properties: {}", props);
		return props;
	}
}
