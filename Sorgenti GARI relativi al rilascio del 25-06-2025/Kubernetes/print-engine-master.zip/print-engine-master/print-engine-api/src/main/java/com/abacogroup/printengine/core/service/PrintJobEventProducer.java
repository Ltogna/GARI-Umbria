package com.abacogroup.printengine.core.service;

import com.abacogroup.printengine.api.PrintJobResponse;
import java.io.IOException;

public interface PrintJobEventProducer {

	void pushEvent(PrintJobResponse message, String tenant, JobEventType eventType) throws IOException;

	enum JobEventType {

		READY("ready"),
		ERROR("error");

		private final String topic;

		JobEventType(String topicName) {
			this.topic = topicName;
		}

		public String getTopic(String dest) {
			return String.format("print-engine-job.%s.%s", dest, topic);
		}
	}
}
