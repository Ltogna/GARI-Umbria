package com.abacogroup.printengine.bundle;

public class BundleConstants {
	public static final String PRINT_FLOW = "print-flow";
}
