package com.abacogroup.printengine.api;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder(setterPrefix = "set")
@NoArgsConstructor
public class PrintJobResponse {

	private String uuid;
	private PrintJobStatus status;
	private String fileStoreId;
	private String bucket;
	private String dest;
}
