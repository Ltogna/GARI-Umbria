package com.abacogroup.printengine.core.service;

import java.io.File;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Path;

import net.sf.jasperreports.engine.JasperReport;

public interface JasperCompiler {

	JasperReport compile(File jasper, ClassLoader classLoader);

	void compile(File jasper, OutputStream out, ClassLoader classLoader);

	void compile(InputStream jasper, OutputStream out, ClassLoader classLoader);

	void compileAll(Path workDir, ClassLoader classLoader);
}
