package com.abacogroup.printengine.core.service.impl;

import java.io.IOException;
import java.util.Map;
import java.util.Objects;

import org.jdbi.v3.core.Jdbi;

import com.abacogroup.embeddedqueue.db.JdbiRepository;
import com.abacogroup.embeddedqueue.rabbitmq.RabbitMqPublisher;
import com.abacogroup.embeddedqueue.rabbitmq.RabbitMqPublisherWorkQueue;
import com.abacogroup.printengine.api.PrintJobResponse;
import com.abacogroup.printengine.core.service.PrintJobEventProducer;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.rabbitmq.client.Connection;

import io.dropwizard.core.setup.Environment;

public class PublishToRabbitMq extends RabbitMqPublisherWorkQueue<PrintJobMessage> implements PrintJobEventProducer {

	public static final String EXCHANGE = "print-engine-exchange";

	public PublishToRabbitMq(Environment environment, Jdbi jdbi, Connection connection, ObjectMapper mapper) throws IOException {
		super("publish-to-rabbitmq", new JdbiRepository(jdbi));

		var publisher = new RabbitMqPublisher<PrintJobMessage>(Objects.requireNonNull(connection)) {
			@Override
			protected String getExchangeName() {
				return EXCHANGE;
			}

			@Override
			protected String getRoutingKey(PrintJobMessage element) {
				return element.getRoutingKey();
			}

			@Override
			protected Map<String, Object> getMessageHeaders(PrintJobMessage element) {
				return Map.of("tenant", element.getTenant());
			}

			@Override
			protected byte[] getPayload(PrintJobMessage element) throws Exception {
				return getObjectMapper().writeValueAsBytes(element.getMessage());
			}
		};

		setConsumer(publisher);
		setMetricRegistry(environment.metrics());
		setObjectMapper(mapper);

		start();
	}

	@Override
	public void pushEvent(PrintJobResponse message, String tenant, JobEventType eventType) throws IOException {
		add(new PrintJobMessage(tenant, message, eventType), System.currentTimeMillis());
	}

	@Override
	protected Class<PrintJobMessage> getJobClass() {
		return PrintJobMessage.class;
	}

}
