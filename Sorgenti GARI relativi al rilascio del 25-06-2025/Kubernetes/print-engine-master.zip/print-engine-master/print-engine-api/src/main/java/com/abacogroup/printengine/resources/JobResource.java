package com.abacogroup.printengine.resources;

import static com.abacogroup.printengine.resources.ResourceConstants.API_PUB;

import java.util.Locale;

import com.abacogroup.printengine.api.PrintJobResponse;
import com.abacogroup.printengine.core.exceptions.PrintJobException;
import com.abacogroup.printengine.core.service.ReportService;
import com.codahale.metrics.annotation.Timed;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.annotation.security.PermitAll;
import jakarta.inject.Inject;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DefaultValue;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.HeaderParam;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.Context;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.SecurityContext;

@Path(API_PUB)
@PermitAll
@Timed
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
@Tag(name = "print job", description = "Operations related to the print job")
public class JobResource {

	private final ReportService reportService;

	@Inject
	public JobResource(ReportService reportService) {
		this.reportService = reportService;
	}

	@Operation(summary = "get print job status", description = " returns the current status of a print job")
	@ApiResponses({
			@ApiResponse(responseCode = "200", description = "successfully, the status of job is returned", content = @Content(mediaType = "application/json", schema = @Schema(implementation = PrintJobResponse.class))),
			@ApiResponse(responseCode = "404", description = "invalid Print job uuid ", content = @Content(schema = @Schema(implementation = PrintJobException.ErrorBody.class)))
	})
	@GET
	@Path("/jobs/{uuid}")
	public PrintJobResponse print(
			@Parameter(in = ParameterIn.HEADER, schema = @Schema(implementation = String.class)) @HeaderParam("Accept-Language") @DefaultValue("en") Locale locale,
			@Parameter(description = "tenant ID") @PathParam("tenant") String tenantId,
			@Parameter(description = "print job ID") @PathParam("uuid") String uuid,
			@Parameter(hidden = true) @Context SecurityContext security) {
		return reportService.getJobStatus(tenantId, uuid);
	}
}
