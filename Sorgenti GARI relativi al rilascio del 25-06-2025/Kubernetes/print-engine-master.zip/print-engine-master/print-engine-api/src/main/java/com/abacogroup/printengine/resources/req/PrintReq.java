package com.abacogroup.printengine.resources.req;

import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import jakarta.ws.rs.DefaultValue;
import jakarta.ws.rs.QueryParam;
import lombok.Data;
import lombok.experimental.Accessors;

@Data
@Accessors(chain = true)
public class PrintReq {

	public static final String DEFAULT_BUCKET_NAME = "print-engine";

	@Parameter(in = ParameterIn.QUERY, description = "file store bucket name. If the bucket name is not passed as a query parameter so the default bucket will be used, the file will be saved temporarily")
	@QueryParam("bucket")
	@DefaultValue(DEFAULT_BUCKET_NAME)
	private String bucket = DEFAULT_BUCKET_NAME;

	@Parameter(in = ParameterIn.QUERY, description = "custom word in print job event topic: `print-engine-job.<dest>.<ready|error>`. default dest value is {printTypeCode}")
	@QueryParam("dest")
	private String dest;

}
