package com.abacogroup.printengine.resources;

public interface ResourceConstants {

	String API_PRIV = "/{tenant}/api-priv/v1";
	String API_PUB = "/{tenant}/public/v1";

	int PAGE_SIZE = 10;
}
