package com.abacogroup.printengine.core.service;

import com.abacogroup.printengine.api.PrintJobResponse;
import com.abacogroup.printengine.api.PrintJobStatus;
import com.abacogroup.printengine.db.ntt.PrintJobEntity;
import com.abacogroup.printengine.db.ntt.ReportEntity;
import com.abacogroup.printengine.resources.req.PrintReq;
import com.abacogroup.printengine.sdk.model.PrintEngineInput;
import com.abacogroup.workflow.server.model.ProcessTransitionResult;

import jakarta.ws.rs.core.SecurityContext;

public interface ReportService {

	String SCOPE = "print-engine";

	PrintJobEntity initPrintJob(String tenantId, String printTypeCode, PrintReq printReq);

	PrintJobResponse getJobStatus(String tenantId, String uuid);

	// ------- used in bundle
	void add(ReportEntity entity); // add or update

	// -------- used in queue

	ProcessTransitionResult startPrintFlow(String workflowCode, PrintEngineInput input, SecurityContext securityContext, String locale,
			String tenantId);

	void updateJobStatus(String jobUuid, PrintJobStatus status);

	void markAsReady(String jobUuid, String fileStoreId);
}
