package com.abacogroup.printengine.core.service.impl;

import static com.abacogroup.printengine.sdk.model.PrintEngineInput.PARAM_NAME;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;

import org.apache.commons.io.FileUtils;

import com.abacogroup.bundles.initializer.impl.FileSupport;
import com.abacogroup.printengine.PrintEngineConfig;
import com.abacogroup.printengine.api.PrintJobResponse;
import com.abacogroup.printengine.api.PrintJobStatus;
import com.abacogroup.printengine.api.mapper.PrintJobMapper;
import com.abacogroup.printengine.core.exceptions.PrintJobException;
import com.abacogroup.printengine.core.exceptions.ReportException;
import com.abacogroup.printengine.core.exceptions.ReportException.ErrEnum;
import com.abacogroup.printengine.core.service.JasperCompiler;
import com.abacogroup.printengine.core.service.ReportService;
import com.abacogroup.printengine.db.dao.PrintJobDAO;
import com.abacogroup.printengine.db.dao.ReportDAO;
import com.abacogroup.printengine.db.ntt.PrintJobEntity;
import com.abacogroup.printengine.db.ntt.ReportEntity;
import com.abacogroup.printengine.resources.req.PrintReq;
import com.abacogroup.printengine.sdk.PrintEngineUtils;
import com.abacogroup.printengine.sdk.model.AuthContextImpl;
import com.abacogroup.printengine.sdk.model.PrintEngineInput;
import com.abacogroup.workflow.sdk.auth.AuthContext;
import com.abacogroup.workflow.server.model.CreateProcessParams;
import com.abacogroup.workflow.server.model.ProcessTransitionResult;
import com.abacogroup.workflow.server.model.WorkflowVersion;
import com.abacogroup.workflow.server.services.CacheSwitch;
import com.abacogroup.workflow.server.services.ProcessService;
import com.abacogroup.workflow.server.services.WorkflowService;
import com.abacogroup.workflow.server.services.classloader.WorkflowClassLoader;

import jakarta.ws.rs.core.SecurityContext;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class ReportServiceImpl implements ReportService {

	private static final Object INIT_MUTEX = new Object();

	private static final String READY_MARKER_FILE_NAME = ".print-engine-" + UUID.randomUUID().toString();

	private final ReportDAO reportDAO;

	private final PrintJobDAO printJobDAO;

	private final WorkflowService workflowService;

	private final JasperCompiler jasperCompiler;

	private final PrintEngineConfig configuration;
	private final ProcessService<?> processService;

	public ReportServiceImpl(ReportDAO reportDAO, PrintJobDAO printJobDAO, WorkflowService workflowService, JasperCompiler jasperCompiler,
			PrintEngineConfig configuration, ProcessService<?> processService) {
		this.reportDAO = reportDAO;
		this.printJobDAO = printJobDAO;
		this.workflowService = workflowService;
		this.processService = processService;
		this.jasperCompiler = jasperCompiler;
		this.configuration = configuration;
	}

	@Override
	public PrintJobEntity initPrintJob(String tenantId, String printTypeCode, PrintReq printReq) {
		ReportEntity reportEntity = this.getReportEntity(tenantId, printTypeCode);
		this.setupSourceDir(tenantId, printTypeCode);

		PrintJobEntity entity = PrintJobEntity.builder()
				.setUuid(UUID.randomUUID().toString())
				.setReportId(reportEntity.getId())
				.setStatus(PrintJobStatus.ACKNOWLEDGE)
				.setDtInsert(printJobDAO.getCurrentTimestamp())
				.setBucket(printReq.getBucket())
				.setDest(printReq.getDest())
				.build();
		printJobDAO.insert(entity);
		return entity;
	}

	@Override
	public void add(ReportEntity entity) {
		reportDAO.findByTenantAndCode(entity.getTenantId(), entity.getWorkflowCode())
				.ifPresentOrElse(
						reportEntity -> log.debug("report entity present"),
						() -> reportDAO.insert(entity));
	}

	@Override
	public PrintJobResponse getJobStatus(String tenantId, String uuid) {
		PrintJobEntity entity = printJobDAO.findByTenantAndUUID(tenantId, uuid)
				.orElseThrow(() -> new PrintJobException(PrintJobException.ErrEnum.PRINT_JOB_NOT_FOUND,
						String.format("no job found for this UUID : %s ", uuid)));

		return PrintJobMapper.INSTANCE.entityToResponse(entity);
	}

	public List<ReportEntity> getList(String tenant) {
		return reportDAO.findByTenant(tenant);
	}

	@Override
	public void updateJobStatus(String jobUuid, PrintJobStatus status) {
		this.printJobDAO.updateStatus(jobUuid, status, printJobDAO.getCurrentTimestamp());
	}

	@Override
	public void markAsReady(String jobUuid, String fileStoreId) {
		this.printJobDAO.updateStatus(jobUuid, PrintJobStatus.READY, fileStoreId, printJobDAO.getCurrentTimestamp());
	}

	@Override
	public ProcessTransitionResult startPrintFlow(String workflowCode, PrintEngineInput input, SecurityContext securityContext, String locale,
			String tenantId) {
		try {
			AuthContext authContext = new AuthContextImpl(securityContext, locale);

			log.info("starting print flow {}", workflowCode);
			ProcessTransitionResult result = processService.createProcess(CreateProcessParams.builder()
					.authContext(authContext)
					.scope(SCOPE)
					.tenantId(tenantId)
					.workflowCode(workflowCode)
					.globalVars(new HashMap<>(Map.of(
							PARAM_NAME, input)))
					.returnGlobalVars(true)
					.build());

			if (result.getLastTransitionLog().isFailed()) {
				log.error("print {} failed. process id: {}", workflowCode, result.getProcessId());
				throw new ReportException(ErrEnum.PRINT_FLOW_ERROR, String.format("print failed. process id: %s, notes: %s",
						result.getProcessId(), result.getLastTransitionLog().getNotes()));
			}

			log.info("print flow {} completed! process id: {}", workflowCode, result.getProcessId());

			return result;

		} catch (IOException e) {
			log.error("print {} failed: {}", workflowCode, e.getMessage(), e);
			throw new ReportException(ErrEnum.PRINT_FLOW_ERROR, String.format("print failed. %s",
					e.getLocalizedMessage())); // TODO exception with my uuid
		}
	}

	public ReportEntity getReportEntity(String tenant, String workflowCode) {
		return this.getOne(tenant, workflowCode).orElseThrow(() -> new ReportException(ErrEnum.PRINT_FLOW_NOT_FOUND,
				String.format("print flow %s does not exist", workflowCode)));
	}

	public Optional<ReportEntity> getOne(String tenant, String workflowCode) {
		return reportDAO.findByTenantAndCode(tenant, workflowCode);
	}

	public void setupSourceDir(String tenantId, String workflowCode) {
		try {
			WorkflowVersion workflowVersion = workflowService.getWorkflowVersion(tenantId, workflowCode);
			// check if exists and not empty
			Path sourceDir = PrintEngineUtils.getSourceDir(configuration.getPrintEngineConfiguration().getInitBaseTempDir(),
					tenantId, workflowCode, workflowVersion.getHash());

			synchronized (INIT_MUTEX) {
				File sourceDirFile = sourceDir.toFile();
				boolean exists = sourceDirFile.exists() && sourceDirFile.isDirectory();
				if (exists) {
					File file = new File(sourceDirFile, READY_MARKER_FILE_NAME);
					exists = file.exists();
				}
				if (!exists) {
					// pick the jar
					Path jarPath = Path.of(sourceDir + ".jar");
					FileOutputStream out = FileUtils.openOutputStream(jarPath.toFile());
					workflowService.getWorkflowPackage(tenantId, workflowCode, out);

					FileSupport.unzip(new FileInputStream(jarPath.toFile()), sourceDir);

					WorkflowClassLoader classLoader = processService.getWorkflowClassLoader(tenantId, workflowCode, CacheSwitch.INVALIDATE_CACHE_FIRST);
					jasperCompiler.compileAll(sourceDir, classLoader);

					FileUtils.touch(new File(sourceDirFile, READY_MARKER_FILE_NAME));
				}
			}

		} catch (IOException ex) {
			String msg = String.format("error creating report workdir for tenant %s and report %s", tenantId, workflowCode);
			log.error(msg, ex);
			throw new ReportException(ErrEnum.GENERIC, msg);
		}
	}

}
