package com.abacogroup.printengine;

import java.io.IOException;
import java.net.URI;
import java.sql.DatabaseMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.EnumSet;
import java.util.List;
import java.util.Optional;
import java.util.TimeZone;
import java.util.concurrent.TimeoutException;

import javax.sql.DataSource;

import org.eclipse.jetty.servlets.CrossOriginFilter;
import org.jdbi.v3.core.Jdbi;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.abacogroup.bundles.Constants;
import com.abacogroup.bundles.initializer.BundleInitServiceBuilder;
import com.abacogroup.bundles.initializer.InitService;
import com.abacogroup.bundles.initializer.impl.BundleInitServiceProducer;
import com.abacogroup.bundles.listener.ListenerBuilder;
import com.abacogroup.bundles.listener.RabbitListener;
import com.abacogroup.bundles.listener.configdata.ConfigDataLogProducer;
import com.abacogroup.bundles.listener.configdata.ProcessorOrderPolicyEnum;
import com.abacogroup.bundles.listener.configdata.builder.ConfigDataConsumerBuilder;
import com.abacogroup.dropwizard.auth.multitenant.MultitenantFilter;
import com.abacogroup.dropwizard.auth.sso2.AuthUtils;
import com.abacogroup.dropwizard.auth.sso2.Sso2Client;
import com.abacogroup.embeddedqueue.db.JdbiRepository;
import com.abacogroup.filestore.client.FileStoreClient;
import com.abacogroup.jdbi.OraJdbiPlugin;
import com.abacogroup.jdbi.OraJdbiPlugin.OraJdbiPluginParams;
import com.abacogroup.jdbi.PgJdbiPlugin;
import com.abacogroup.printengine.PrintEngineConfig.BundleConfig;
import com.abacogroup.printengine.PrintEngineConfig.RabbitmqConfig;
import com.abacogroup.printengine.bundle.config.PrintFlowConfigMessageProcessor;
import com.abacogroup.printengine.core.PrintEngineProcedureEnvironment;
import com.abacogroup.printengine.core.service.JasperCompiler;
import com.abacogroup.printengine.core.service.PrintJobEventProducer;
import com.abacogroup.printengine.core.service.ReportService;
import com.abacogroup.printengine.core.service.embededqueue.PrintQueue;
import com.abacogroup.printengine.core.service.impl.JasperCompilerImpl;
import com.abacogroup.printengine.core.service.impl.PublishToRabbitMq;
import com.abacogroup.printengine.core.service.impl.ReportServiceImpl;
import com.abacogroup.printengine.db.dao.PrintJobDAO;
import com.abacogroup.printengine.db.dao.ReportDAO;
import com.abacogroup.printengine.resources.JobResource;
import com.abacogroup.printengine.resources.PrintResource;
import com.abacogroup.tracing.dropwizard.AbacoApplication;
import com.abacogroup.tracing.jaxrs.client.AddRequestId;
import com.abacogroup.workflow.sdk.proc.ProcedureEnvironment;
import com.abacogroup.workflow.server.services.ProcessService;
import com.abacogroup.workflow.server.services.WorkflowService;
import com.codahale.metrics.MetricRegistry;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;

import io.dropwizard.client.JerseyClientBuilder;
import io.dropwizard.configuration.EnvironmentVariableSubstitutor;
import io.dropwizard.configuration.SubstitutingSourceProvider;
import io.dropwizard.core.setup.Bootstrap;
import io.dropwizard.core.setup.Environment;
import io.dropwizard.db.DataSourceFactory;
import io.dropwizard.jdbi3.JdbiFactory;
import io.dropwizard.jersey.setup.JerseyEnvironment;
import io.dropwizard.migrations.MigrationsBundle;
import io.swagger.v3.jaxrs2.integration.resources.OpenApiResource;
import io.swagger.v3.oas.integration.ClasspathOpenApiConfigurationLoader;
import io.swagger.v3.oas.integration.api.OpenAPIConfiguration;
import jakarta.servlet.DispatcherType;
import jakarta.servlet.FilterRegistration.Dynamic;
import jakarta.ws.rs.client.Client;
import oracle.jdbc.OracleConnection;

public class PrintEngineApp extends AbacoApplication<PrintEngineConfig> {
	private static final Logger log = LoggerFactory.getLogger(PrintEngineApp.class);

	private Jdbi jdbiHelper;
	private Jdbi jdbi;

	public static void main(String[] args) {
		try {
			new PrintEngineApp().run(args);
		} catch (Exception e) {
			log.error("Error during run print-engine app: ", e);
		}
	}

	@Override
	public String getName() {
		return "print-engine";
	}

	@Override
	public void initialize(Bootstrap<PrintEngineConfig> bootstrap) {
		bootstrap.addBundle(new MigrationsBundle<>() {
			@Override
			public DataSourceFactory getDataSourceFactory(PrintEngineConfig configuration) {
				return configuration.getDatabase();
			}
		});

		SubstitutingSourceProvider provider = new SubstitutingSourceProvider(bootstrap.getConfigurationSourceProvider(),
				new EnvironmentVariableSubstitutor(false));
		bootstrap.setConfigurationSourceProvider(provider);
	}

	@Override
	public void doRun(PrintEngineConfig configuration, Environment environment) throws Exception {
		ObjectMapper objectMapper = environment.getObjectMapper();
		configureObjectMapper(objectMapper);

		initJdbi(configuration, environment);
		DataSource helperDataSource = this.createDatasource(configuration.getHelperDatabase(), environment.metrics(), "helper-ds");

		Client client = createJaxRsClient(configuration, environment);

		Connection rabbitmqConnection = this.createRabbitmqConnection(configuration);

		final Sso2Client sso2Client = this.initSso2Client(configuration, environment);
		this.initAuth(environment, sso2Client);

		this.initMultiTenant(environment);
		this.initOpenApi(environment.jersey());
		this.setupCORS(configuration, environment);

		FileStoreClient fileStoreClient = new FileStoreClient(URI.create(configuration.getFileStoreConfig().getUrl()), objectMapper);

		WorkflowService workflowService = this.register(new WorkflowService(jdbi));
		ProcessService<ProcedureEnvironment> processService = this
				.register(new ProcessService<ProcedureEnvironment>(jdbi, processData -> new PrintEngineProcedureEnvironment(processData, client,
						this.jdbiHelper, helperDataSource, objectMapper, configuration.getPrintEngineConfiguration())));

		final PrintJobEventProducer printJobEventProducer = this.register(createPrintJobEventProducer(environment, objectMapper, rabbitmqConnection));

		final ReportDAO reportDAO = jdbi.onDemand(ReportDAO.class);
		final PrintJobDAO printJobDAO = jdbi.onDemand(PrintJobDAO.class);
		final JasperCompiler jasperCompiler = this.register(new JasperCompilerImpl());
		final ReportService reportService = this.register(
				new ReportServiceImpl(reportDAO, printJobDAO, workflowService, jasperCompiler, configuration, processService));

		PrintQueue printQueue = this.register(new PrintQueue(new JdbiRepository(jdbi), environment.metrics(), reportService,
				sso2Client, fileStoreClient, printJobEventProducer, configuration.getPrintEngineConfiguration()));

		List<Object> resources = new ArrayList<>();

		// public
		resources.add(new PrintResource(reportService, printQueue));
		resources.add(new JobResource(reportService));

		resources.forEach(environment.jersey()::register);

		// ---------------------------------------------------------------------------

		RabbitListener rabbitListener = ListenerBuilder
				.newBuilder(rabbitmqConnection)
				.withConfigDataConsumer(this.register(ConfigDataConsumerBuilder.newBuilder(jdbi, rabbitmqConnection)
						.route(this.getName())
						.processor(
								this.register(new PrintFlowConfigMessageProcessor(
										reportService, configuration.getHelperDatabase(),
										environment.metrics(), workflowService, processService, jasperCompiler, configuration)))

						.configLogProducer(configDataLogProducerBean(objectMapper, rabbitmqConnection))
						.withOrderPolicy(ProcessorOrderPolicyEnum.PROCESSOR)
						.build()))
				.buildListener();

		BundleConfig bundleConfig = Optional.ofNullable(configuration.getBundleConfig()).orElseGet(BundleConfig::new);
		InitService bundleInitService = BundleInitServiceBuilder
				.producer(this.register(new BundleInitServiceProducer(rabbitmqConnection)))
				.configLocation(bundleConfig.getConfigLocation())
				// .baseTempDir()
				.build();

		this.startRabbitConsumerAndProducers(bundleInitService, rabbitListener);

		// ---------------------------------------------------------------------------

		this.afterServicesUp();
	}

	protected PrintJobEventProducer createPrintJobEventProducer(Environment environment, ObjectMapper objectMapper, Connection rabbitmqConnection)
			throws IOException {
		return new PublishToRabbitMq(environment, jdbi, rabbitmqConnection, objectMapper);
	}

	protected DataSource createDatasource(DataSourceFactory database, MetricRegistry metrics, String name) throws SQLException {
		return database.build(metrics, name);
	}

	protected void startRabbitConsumerAndProducers(InitService initService, RabbitListener rabbitListener) throws Exception {
		rabbitListener.start();
		if (initService != null) {
			initService.start();
		}
	}

	protected void afterServicesUp() {
		log.debug("application started");
	}

	protected <T> T register(T service) {
		return service;
	}

	protected ConfigDataLogProducer configDataLogProducerBean(ObjectMapper objectMapper, Connection rabbitmqConnection) {
		return this.register(new ConfigDataLogProducer(objectMapper, rabbitmqConnection, Constants.DEFAULT_EXCHANGE_NAME));
	}

	protected void initAuth(Environment environment, Sso2Client sso2Cli) {
		AuthUtils.installAuthFilter(environment, sso2Cli);
	}

	private Sso2Client initSso2Client(PrintEngineConfig configuration, Environment environment) {
		final Client client = new JerseyClientBuilder(environment)
				.using(configuration.getJerseyClient())
				.build("sso2-client");
		client.register(new AddRequestId());
		return new Sso2Client(configuration.getSso2Config().getTasksAuthPhrase(), client.target(configuration.getSso2Config().getUrl()));
	}

	private Client createJaxRsClient(PrintEngineConfig configuration, Environment environment) {
		final Client client = new JerseyClientBuilder(environment)
				.using(configuration.getJerseyClient())
				.build(this.getName());
		client.register(new AddRequestId());
		return client;
	}

	protected void initJdbi(PrintEngineConfig config, Environment environment) throws Exception {
		final JdbiFactory factory = new JdbiFactory();
		jdbi = initJdbi(config, environment, factory);
		jdbiHelper = initJdbiHelper(config, environment, factory);
	}

	protected Jdbi initJdbi(PrintEngineConfig config, Environment environment, JdbiFactory factory) throws Exception {
		return installAbacoJdbi(environment, factory, config.getDatabase(), "mainDb");
	}

	protected Jdbi initJdbiHelper(PrintEngineConfig config, Environment environment, JdbiFactory factory) {
		return installAbacoJdbi(environment, factory, config.getHelperDatabase(), "helperDB");
	}

	private Jdbi installAbacoJdbi(Environment environment, JdbiFactory factory, DataSourceFactory dataSourceFactory, String name) {
		Jdbi jdbi = factory.build(environment, dataSourceFactory, name);
		var isPostgres = jdbi.withHandle(h -> {
			String db = h.queryMetadata(DatabaseMetaData::getDatabaseProductName);
			log.info("Database connection is '{}'", db);
			return db.toLowerCase().contains("postgresql");
		});

		if (isPostgres) {
			jdbi.installPlugin(new PgJdbiPlugin());
		} else {
			var params = new OraJdbiPluginParams(cnn -> cnn.unwrap(OracleConnection.class), true);
			jdbi.installPlugin(new OraJdbiPlugin(params));
		}
		return jdbi;
	}

	protected Connection createRabbitmqConnection(PrintEngineConfig configuration)
			throws IOException, TimeoutException {
		RabbitmqConfig rabbitmqConfig = configuration.getRabbitmqConfig();

		ConnectionFactory factory = new ConnectionFactory();

		if (rabbitmqConfig.getHost() != null) {
			factory.setHost(rabbitmqConfig.getHost());
		}
		if (rabbitmqConfig.getUser() != null) {
			factory.setUsername(rabbitmqConfig.getUser());
		}
		if (rabbitmqConfig.getPassword() != null) {
			factory.setPassword(rabbitmqConfig.getPassword());
		}
		if (rabbitmqConfig.getVirtualhost() != null) {
			factory.setVirtualHost(rabbitmqConfig.getVirtualhost());
		}
		if (rabbitmqConfig.getPort() != null) {
			factory.setPort(rabbitmqConfig.getPort());
		}
		factory.setAutomaticRecoveryEnabled(true);

		Connection connection = factory.newConnection();
		return connection;
	}

	protected void configureObjectMapper(ObjectMapper objectMapper) {
		objectMapper.registerModule(new JavaTimeModule());
		objectMapper
				.setTimeZone(TimeZone.getDefault())
				.disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);
	}

	protected void initOpenApi(JerseyEnvironment jersey) throws IOException {
		OpenAPIConfiguration oasConfig = new ClasspathOpenApiConfigurationLoader()
				.load("openapi-configuration.yaml");

		jersey.register(new OpenApiResource()
				.openApiConfiguration(oasConfig));
	}

	private void setupCORS(PrintEngineConfig configuration, Environment environment) {
		if (!configuration.isCors()) {
			log.info("CORS is disabled");
			return;
		}

		log.info("CORS is enabled");

		Dynamic cors = environment.servlets().addFilter("CORS", CrossOriginFilter.class);
		cors.setInitParameter(CrossOriginFilter.ALLOWED_ORIGINS_PARAM, "*");
		cors.setInitParameter(CrossOriginFilter.ALLOWED_HEADERS_PARAM, "*");
		cors.setInitParameter(CrossOriginFilter.ALLOWED_METHODS_PARAM, "GET,PUT,POST,DELETE");

		// OPTIONS pre-flight request will be served by the filter ONLY and not
		// passed ahead
		// cors.setInitParameter(CrossOriginFilter.CHAIN_PREFLIGHT_PARAM,
		// "false");

		// Add URL mapping
		cors.addMappingForUrlPatterns(EnumSet.allOf(DispatcherType.class), false, "*");
	}

	private void initMultiTenant(Environment environment) {
		environment.jersey().register(new MultitenantFilter("tenant"));
	}

}
