package com.abacogroup.printengine.api.mapper;

import com.abacogroup.printengine.api.PrintJobResponse;
import com.abacogroup.printengine.db.ntt.PrintJobEntity;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper
public interface PrintJobMapper {

	PrintJobMapper INSTANCE = Mappers.getMapper(PrintJobMapper.class);

	PrintJobResponse entityToResponse(PrintJobEntity entity);

}
