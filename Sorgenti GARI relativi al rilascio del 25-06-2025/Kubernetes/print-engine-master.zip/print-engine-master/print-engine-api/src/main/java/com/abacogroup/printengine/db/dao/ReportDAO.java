package com.abacogroup.printengine.db.dao;

import com.abacogroup.jdbi.EnhancedSqlObject;
import com.abacogroup.printengine.db.ntt.ReportEntity;
import java.util.List;
import java.util.Optional;
import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.customizer.BindBean;
import org.jdbi.v3.sqlobject.statement.GetGeneratedKeys;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;
import org.jdbi.v3.sqlobject.transaction.Transactional;

public interface ReportDAO extends Transactional<ReportDAO>, EnhancedSqlObject {

	@SqlUpdate("INSERT INTO pre_jasper_reports (tenant_id, workflow_code) "
			+ " values (:tenantId, :workflowCode)")
	@GetGeneratedKeys("id")
	Long insert(@BindBean ReportEntity entity);

	@SqlQuery("SELECT id, tenant_id, workflow_code "
			+ "FROM pre_jasper_reports "
			+ " WHERE tenant_id = :tenantId "
			+ " AND workflow_code = :code ")
	@RegisterBeanMapper(ReportEntity.class)
	Optional<ReportEntity> findByTenantAndCode(@Bind("tenantId") String tenantId,
			@Bind("code") String code);

	@SqlQuery("SELECT id, tenant_id, workflow_code "
			+ "FROM pre_jasper_reports "
			+ " WHERE tenant_id = :tenantId ")
	@RegisterBeanMapper(ReportEntity.class)
	List<ReportEntity> findByTenant(@Bind("tenantId") String tenantId);

}
