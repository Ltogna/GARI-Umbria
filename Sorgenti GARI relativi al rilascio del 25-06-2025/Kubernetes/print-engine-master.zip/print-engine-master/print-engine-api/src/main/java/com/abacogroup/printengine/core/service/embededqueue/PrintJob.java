package com.abacogroup.printengine.core.service.embededqueue;

import com.abacogroup.printengine.resources.req.PrintReq;
import com.abacogroup.printengine.sdk.model.PrintEngineInput;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Builder.Default;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder(setterPrefix = "set")
@AllArgsConstructor
@NoArgsConstructor
public class PrintJob {

	private String jobUuid;
	private String userName;
	private String locale;
	private String tenantId;
	private String workflowCode;
	private PrintEngineInput input;
	@Default
	private PrintReq printReq = new PrintReq();

}
