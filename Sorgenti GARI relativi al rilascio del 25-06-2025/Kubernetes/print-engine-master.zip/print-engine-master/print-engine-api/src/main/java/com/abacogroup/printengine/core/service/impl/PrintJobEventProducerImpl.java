package com.abacogroup.printengine.core.service.impl;

import java.io.IOException;
import java.util.Map;
import java.util.UUID;

import com.abacogroup.printengine.api.PrintJobResponse;
import com.abacogroup.printengine.core.service.PrintJobEventProducer;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.rabbitmq.client.AMQP;
import com.rabbitmq.client.BuiltinExchangeType;
import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;

import jakarta.ws.rs.core.MediaType;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class PrintJobEventProducerImpl implements PrintJobEventProducer {

	public static final String EXCHANGE = "print-engine-exchange";
	private final Connection connection;
	private final ObjectMapper objectMapper;
	private Channel singleChannel;

	public PrintJobEventProducerImpl(Connection connection, ObjectMapper objectMapper) {
		this.connection = connection;
		this.objectMapper = objectMapper;
	}

	@Override
	public void pushEvent(PrintJobResponse message, String tenant, JobEventType eventType) throws IOException {
		String topic = eventType.getTopic(message.getDest());

		this.sendMessage(message, tenant, topic);
	}

	private synchronized void sendMessage(PrintJobResponse message, String tenant, String topic) throws IOException {
		Map<String, Object> headers = Map.of("tenant", tenant);
		AMQP.BasicProperties properties = new AMQP.BasicProperties.Builder()
				.deliveryMode(2) // persistent
				.correlationId(UUID.randomUUID().toString())
				.contentType(MediaType.APPLICATION_JSON)
				.headers(headers)
				.build();
		byte[] body = objectMapper.writeValueAsBytes(message);

		Channel channel = this.getOrCreateChannel();
		channel.basicPublish(EXCHANGE, topic, properties, body);

		log.debug("'{}' pushed to exchange {} with topic {} and headers {}", message, EXCHANGE, topic, headers);
	}

	private synchronized Channel getOrCreateChannel() {
		if (singleChannel == null) {
			try {
				Channel channel = connection.createChannel();
				channel.exchangeDeclare(EXCHANGE, BuiltinExchangeType.TOPIC);
				this.singleChannel = channel;
				return this.singleChannel;
			} catch (IOException ex) {
				throw new RuntimeException("error creating channel for exchange " + EXCHANGE, ex);
			}
		}
		return this.singleChannel;
	}
}
