package com.abacogroup.printengine.api;

public enum PrintJobStatus {

	ACKNOWLEDGE,
	PROGRESS,
	ERROR,
	READY
}
