package com.abacogroup.printengine.bundle.config;

import static java.util.stream.Collectors.toList;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.file.Path;
import java.sql.Connection;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;

import com.abacogroup.bundles.initializer.impl.FileSupport;
import com.abacogroup.bundles.initializer.impl.exceptions.BundleException;
import com.abacogroup.bundles.listener.configdata.ConfigDataMessage;
import com.abacogroup.bundles.listener.configdata.ConfigMessageProcessor;
import com.abacogroup.printengine.PrintEngineConfig;
import com.abacogroup.printengine.bundle.BundleConstants;
import com.abacogroup.printengine.core.service.JasperCompiler;
import com.abacogroup.printengine.core.service.ReportService;
import com.abacogroup.printengine.db.ntt.ReportEntity;
import com.abacogroup.printengine.sdk.PrintEngineUtils;
import com.abacogroup.workflow.server.model.NodeType;
import com.abacogroup.workflow.server.services.CacheSwitch;
import com.abacogroup.workflow.server.services.ProcessService;
import com.abacogroup.workflow.server.services.WorkflowDefinition;
import com.abacogroup.workflow.server.services.WorkflowDefinition.Node;
import com.abacogroup.workflow.server.services.WorkflowService;
import com.abacogroup.workflow.server.services.classloader.WorkflowClassLoader;
import com.codahale.metrics.MetricRegistry;

import io.dropwizard.db.DataSourceFactory;
import io.dropwizard.db.ManagedDataSource;
import jakarta.validation.constraints.NotNull;
import liquibase.Liquibase;
import liquibase.database.jvm.JdbcConnection;
import liquibase.resource.DirectoryResourceAccessor;

public class PrintFlowConfigMessageProcessor implements ConfigMessageProcessor {

	private final ReportService reportService;

	private final DataSourceFactory dataSourceFactory;
	private final MetricRegistry metrics;

	private final WorkflowService workflowService;
	private final ProcessService<?> processService;
	private final JasperCompiler jasperCompiler;

	private final PrintEngineConfig configuration;

	public PrintFlowConfigMessageProcessor(ReportService reportService, DataSourceFactory dataSourceFactory, MetricRegistry metrics,
			WorkflowService workflowService, ProcessService<?> processService,
			JasperCompiler jasperCompiler, PrintEngineConfig configuration) {
		this.reportService = reportService;
		this.dataSourceFactory = dataSourceFactory;
		this.metrics = metrics;
		this.workflowService = workflowService;
		this.processService = processService;
		this.jasperCompiler = jasperCompiler;
		this.configuration = configuration;
	}

	@Override
	public String getDomainName() {
		return BundleConstants.PRINT_FLOW;
	}

	@Override
	public void onMessage(ConfigDataMessage message) {
		String tenantId = message.getTenantId();

		List<Path> jarPaths = message.getConfigFiles()
				.stream()
				.filter(p -> FilenameUtils.isExtension(p.getFileName().toString(), "jar"))
				.collect(toList());

		jarPaths.forEach(p -> this.processJar(tenantId, p));

	}

	private void processJar(String tenantId, Path jarPath) {
		try {
			File jar = jarPath.toFile();
			WorkflowDefinition workflowDefinition = workflowService.addOrUpdateWorkflow(tenantId, jar);

			this.validateWkNodeTypes(workflowDefinition);

			String wfCode = workflowDefinition.getCode();
			String hash = workflowDefinition.getMd5();

			Path sourceDir = PrintEngineUtils.getSourceDir(configuration.getPrintEngineConfiguration().getInitBaseTempDir(), tenantId, wfCode, hash);
			FileUtils.deleteQuietly(sourceDir.toFile());

			FileSupport.unzip(new FileInputStream(jarPath.toFile()), sourceDir);

			WorkflowClassLoader classLoader = processService.getWorkflowClassLoader(tenantId, wfCode, CacheSwitch.INVALIDATE_CACHE_FIRST);
			jasperCompiler.compileAll(sourceDir, classLoader);

			this.installMigrations(sourceDir);

			var reportEntity = ReportEntity.builder()
					.setTenantId(tenantId)
					.setWorkflowCode(wfCode)
					.build();
			reportService.add(reportEntity);

		} catch (IOException e) {
			throw new BundleException(String.format("error creating print workflow from file %s", jarPath), e);
		}

	}

	protected void validateWkNodeTypes(WorkflowDefinition workflowDefinition) {
		List<String> statusNodes = workflowDefinition.getNodes()
				.stream()
				.filter(i -> NodeType.status.equals(i.getType()))
				.map(Node::getName)
				.collect(toList());

		if (!statusNodes.isEmpty()) {
			throw new BundleException(String.format("invalid nods %s of type %s in workflow %s",
					statusNodes, NodeType.status, workflowDefinition.getCode()));
		}

	}

	protected void installMigrations(@NotNull Path workDir) {
		Optional<File> migration = Arrays.stream(
				Objects.requireNonNull(workDir.toFile().listFiles((dir1, name) -> name.startsWith("migrations") && name.endsWith(".xml"))))
				.findFirst();
		migration.ifPresent(m -> {
			System.out.println("-------- EXEC_PRINT_MIGRATIONS -----------");
			ManagedDataSource managedDataSource = dataSourceFactory
					.build(metrics, "helper-ds");
			try (Connection connection = managedDataSource.getConnection()) {
				var accessor = new DirectoryResourceAccessor(workDir);
				Liquibase migrator = new Liquibase(m.getName(), accessor, new JdbcConnection(connection));
				migrator.update("");
			} catch (Throwable t) {
				throw new BundleException("error in  liquibase migration for " + workDir, t);
			}
			System.out.println("-------- EXEC_PRINT_MIGRATIONS_END -----------");
		});
	}

}
