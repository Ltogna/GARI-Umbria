package com.abacogroup.printengine.core.service.embededqueue;

import static com.abacogroup.embeddedqueue.QueueErrorListener.ErrorAction.MARK_AS_ERRORED;
import static com.abacogroup.printengine.resources.req.PrintReq.DEFAULT_BUCKET_NAME;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.URLConnection;
import java.nio.file.Path;

import org.apache.commons.io.FileUtils;

import com.abacogroup.dropwizard.auth.sso2.Sso2Client;
import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.embeddedqueue.QueueErrorListener;
import com.abacogroup.embeddedqueue.ThrowingConsumer;
import com.abacogroup.embeddedqueue.WorkQueue;
import com.abacogroup.embeddedqueue.db.JdbiRepository;
import com.abacogroup.filestore.client.FileStoreClient;
import com.abacogroup.filestore.client.auth.Sso2Authenticator;
import com.abacogroup.filestore.client.request.FileToAddMetadata;
import com.abacogroup.filestore.client.response.AddFileResponse;
import com.abacogroup.printengine.PrintEngineConfig.PrintEngineConfiguration;
import com.abacogroup.printengine.api.PrintJobResponse;
import com.abacogroup.printengine.api.PrintJobStatus;
import com.abacogroup.printengine.core.service.PrintJobEventProducer;
import com.abacogroup.printengine.core.service.PrintJobEventProducer.JobEventType;
import com.abacogroup.printengine.core.service.ReportService;
import com.abacogroup.printengine.sdk.Constants;
import com.abacogroup.workflow.server.model.ProcessTransitionResult;
import com.codahale.metrics.MetricRegistry;

import jakarta.ws.rs.core.SecurityContext;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class PrintQueue extends WorkQueue<PrintJob> {
	private static final String Q_ID = "print-engine-process";
	private static final Integer DEFAULT_LIFESPAN = 60 * 12;
	private ReportService reportService;
	private final Sso2Client sso2Client;
	private final FileStoreClient fileStoreClient;
	private final PrintJobEventProducer eventProducer;

	private final PrintEngineConfiguration printEngineConfiguration;

	public PrintQueue(JdbiRepository repo, MetricRegistry registry, ReportService reportService, Sso2Client sso2Client, FileStoreClient fileStoreClient,
			PrintJobEventProducer eventProducer, PrintEngineConfiguration config) {
		super(Q_ID, repo, config.getQueueThreads(), config.getQueueTimeoutMs());

		this.reportService = reportService;
		this.sso2Client = sso2Client;
		this.fileStoreClient = fileStoreClient;
		this.eventProducer = eventProducer;
		this.printEngineConfiguration = config;

		this.setMetricRegistry(registry);

		ThrowingConsumer<PrintJob> consumer = createConsumer();
		this.setConsumer(consumer);
		QueueErrorListener<PrintJob> errorListener = createErrorListener();
		this.setErrorListener(errorListener);

		this.start();
	}

	@Override
	protected Class<PrintJob> getJobClass() {
		return PrintJob.class;
	}

	private ThrowingConsumer<PrintJob> createConsumer() {
		return printJob -> {
			reportService.updateJobStatus(printJob.getJobUuid(), PrintJobStatus.PROGRESS);
			var securityContext = sso2Client.createSecurityContextFromUserName(printJob.getTenantId(), printJob.getUserName());

			var processTransitionResult = reportService.startPrintFlow(
					printJob.getWorkflowCode(),
					printJob.getInput(),
					securityContext,
					printJob.getLocale(),
					printJob.getTenantId());

			if (!processTransitionResult.getLastTransitionLog().isFailed()) {
				AddFileResponse fileResponse = storeFile(printJob, securityContext, processTransitionResult);
				reportService.markAsReady(printJob.getJobUuid(), fileResponse.getId());
				if (!printEngineConfiguration.isKeepTempFile()) {
					File pdf = Path.of((String) processTransitionResult.getGlobalVars().get(Constants.OUTPUT_PATH)).toFile();
					FileUtils.deleteQuietly(pdf);
				}
			}
			this.sendEvent(printJob);
		};
	}

	private QueueErrorListener<PrintJob> createErrorListener() {
		return (printJob, exp) -> {
			reportService.updateJobStatus(printJob.getJobUuid(), PrintJobStatus.ERROR);
			this.sendEvent(printJob);
			return MARK_AS_ERRORED;
		};
	}

	private void sendEvent(PrintJob printJob) {
		PrintJobResponse jobStatus = reportService.getJobStatus(printJob.getTenantId(), printJob.getJobUuid());
		JobEventType eventType = jobStatus.getStatus().equals(PrintJobStatus.READY) ? JobEventType.READY : JobEventType.ERROR;
		try {
			eventProducer.pushEvent(jobStatus, printJob.getTenantId(), eventType);
		} catch (IOException e) {
			log.error("cannot send print {} event: {}", eventType, e.getMessage(), e);
		}
	}

	private AddFileResponse storeFile(PrintJob printJob, SecurityContext securityContext, ProcessTransitionResult processTransitionResult)
			throws IOException {
		File pdf = Path.of((String) processTransitionResult.getGlobalVars().get(Constants.OUTPUT_PATH)).toFile();

		var bucket = printJob.getPrintReq().getBucket();

		FileToAddMetadata fileToAddMetadata = buildFileToAddMetadata(bucket, pdf);
		AddFileResponse fileResponse = this.fileStoreClient.addFile(
				new Sso2Authenticator((User) securityContext.getUserPrincipal()),
				printJob.getTenantId(),
				bucket,
				fileToAddMetadata,
				new FileInputStream(pdf));
		return fileResponse;
	}

	private FileToAddMetadata buildFileToAddMetadata(String bucket, File pdf) {
		String mime = URLConnection.guessContentTypeFromName(pdf.getName());
		if (mime == null) {
			mime = "application/octet-stream";
		}
		
		if (bucket.equalsIgnoreCase(DEFAULT_BUCKET_NAME)) {
			return new FileToAddMetadata(pdf.getName(), mime, DEFAULT_LIFESPAN);
		} else {
			return new FileToAddMetadata(pdf.getName(), mime);
		}
	}
}
