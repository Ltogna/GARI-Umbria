package com.abacogroup.printengine.resources;

import static com.abacogroup.printengine.resources.ResourceConstants.API_PUB;
import static com.abacogroup.printengine.resources.req.PrintReq.DEFAULT_BUCKET_NAME;

import java.io.IOException;
import java.util.Locale;
import java.util.Optional;

import org.apache.commons.lang3.StringUtils;

import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.printengine.api.CreatePrintJobResponse;
import com.abacogroup.printengine.core.exceptions.ReportException;
import com.abacogroup.printengine.core.service.ReportService;
import com.abacogroup.printengine.core.service.embededqueue.PrintJob;
import com.abacogroup.printengine.core.service.embededqueue.PrintQueue;
import com.abacogroup.printengine.resources.req.PrintReq;
import com.abacogroup.printengine.sdk.model.PrintEngineInput;
import com.codahale.metrics.annotation.Timed;

import io.dropwizard.auth.Auth;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.parameters.RequestBody;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.annotation.security.PermitAll;
import jakarta.inject.Inject;
import jakarta.validation.Valid;
import jakarta.ws.rs.BeanParam;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DefaultValue;
import jakarta.ws.rs.HeaderParam;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.Context;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.SecurityContext;

@Path(API_PUB)
@PermitAll
@Timed
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
@Tag(name = "report", description = "Operations on reports")
public class PrintResource {

	private final ReportService reportService;
	private final PrintQueue printQueue;

	@Inject
	public PrintResource(ReportService reportService, PrintQueue printQueue) {
		this.reportService = reportService;
		this.printQueue = printQueue;
	}

	@Operation(summary = "print report", description = "print a specific report by code")
	@RequestBody(description = "map that contains print job parameters", content = @Content(schema = @Schema(type = "object"), additionalPropertiesSchema = @Schema(type = "object"), mediaType = MediaType.APPLICATION_JSON))
	@ApiResponses({
			@ApiResponse(responseCode = "200", description = "Successfully, the report is created and ready to be printed", content = @Content(mediaType = "application/json", array = @ArraySchema(schema = @Schema(implementation = CreatePrintJobResponse.class)))),
			@ApiResponse(responseCode = "404", description = "print flow not found ", content = @Content(schema = @Schema(implementation = ReportException.ErrorBody.class)))
	})
	@POST
	@Path("/{printTypeCode}")
	public CreatePrintJobResponse print(
			@Parameter(description = "print type CODE") @PathParam("printTypeCode") String printTypeCode,
			@Parameter(description = "tenant ID") @PathParam("tenant") String tenantId,
			@Parameter(hidden = true) @Context SecurityContext security,
			@Parameter(hidden = true) @Auth User user,
			@Parameter(in = ParameterIn.HEADER, schema = @Schema(implementation = String.class)) @HeaderParam("Accept-Language") @DefaultValue("en") Locale locale,
			@Valid PrintEngineInput inputPayload,
			@BeanParam PrintReq printReq)
			throws IOException {

		validatePrintReq(printReq, printTypeCode);

		var job = reportService.initPrintJob(tenantId, printTypeCode, printReq);
		PrintJob printJob = PrintJob.builder()
				.setPrintReq(printReq)
				.setJobUuid(job.getUuid())
				.setLocale(locale.getLanguage())
				.setTenantId(tenantId)
				.setWorkflowCode(printTypeCode)
				.setInput(Optional.ofNullable(inputPayload).orElse(new PrintEngineInput()))
				.setUserName(user.getName())
				.build();

		printQueue.add(printJob, System.currentTimeMillis());

		return CreatePrintJobResponse.builder()
				.setUuid(job.getUuid())
				.build();
	}

	private void validatePrintReq(PrintReq printReq, String defaultDest) {
		printReq.setBucket(evl(printReq.getBucket(), DEFAULT_BUCKET_NAME));
		printReq.setDest(evl(printReq.getDest(), defaultDest));
	}

	private String evl(String value, String defaultValue) {
		if (value == null) {
			return defaultValue;
		}

		value = value.trim();
		if (value.isEmpty()) {
			return defaultValue;
		}

		return value;
	}
}
