package com.abacogroup.printengine.core.service.impl;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.function.Supplier;
import java.util.stream.Stream;

import org.apache.commons.io.FilenameUtils;

import com.abacogroup.printengine.core.exceptions.JasperException;
import com.abacogroup.printengine.core.exceptions.JasperException.ErrEnum;
import com.abacogroup.printengine.core.service.JasperCompiler;
import com.abacogroup.printengine.sdk.Constants;

import jakarta.validation.constraints.NotNull;
import lombok.extern.slf4j.Slf4j;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperReport;

@Slf4j
public class JasperCompilerImpl implements JasperCompiler {

	@Override
	public JasperReport compile(File jasper, ClassLoader classLoader) {
		return withClassLoader(classLoader, () -> {
			JasperReport jasperReport = null;
			try {
				jasperReport = JasperCompileManager.compileReport(jasper.getAbsolutePath());
				log.info("jasper created " + jasperReport.getName());
			} catch (JRException e) {
				log.error("error in compile", e);
				throw new JasperException(ErrEnum.COMPILE_ERR, "error in compile");
			}
			return jasperReport;
		});
	}

	@Override
	public void compile(File jasper, OutputStream out, ClassLoader classLoader) {
		withClassLoader(classLoader, () -> {
			try {
				JasperCompileManager.compileReportToStream(new FileInputStream(jasper.getAbsolutePath()), out);
			} catch (JRException | FileNotFoundException e) {
				log.error("error in compile", e);
				throw new JasperException(ErrEnum.COMPILE_ERR, "error in compile");
			}
			return null;
		});
	}

	@Override
	public void compile(InputStream jasper, OutputStream out, ClassLoader classLoader) {
		withClassLoader(classLoader, () -> {
			try {
				JasperCompileManager.compileReportToStream(jasper, out);
			} catch (JRException e) {
				log.error("error in compile", e);
				throw new JasperException(ErrEnum.COMPILE_ERR, "error in compile");
			}
			return null;
		});
	}

	@Override
	public void compileAll(@NotNull Path workDir, ClassLoader classLoader) {
		withClassLoader(classLoader, () -> {
			try {
				try (Stream<Path> files = Files
						.walk(workDir)
						.filter(x -> x.getFileName().toString().toLowerCase().endsWith(Constants.JRXML));) {
					files.forEach(this::compile);
				}

			} catch (IOException e) {
				log.error("error in compile", e);
				throw new JasperException(ErrEnum.COMPILE_ERR, "error in compile");
			}
			return null;
		});
	}

	private void compile(Path path) {
		try {
			File jrxmlFile = path.toFile();
			String extension = FilenameUtils.getExtension(jrxmlFile.getAbsolutePath());
			var jasper = jrxmlFile.getAbsolutePath().replace(extension, Constants.JASPER);
			compile(jrxmlFile, new FileOutputStream(jasper), null);
		} catch (FileNotFoundException ex) {
			throw new JasperException(JasperException.ErrEnum.COMPILE_ERR, "error in compile " + path);
		}
	}

	private <T> T withClassLoader(ClassLoader classLoader, Supplier<T> supplier) {
		if (classLoader == null) {
			return supplier.get();
		}

		ClassLoader original = Thread.currentThread().getContextClassLoader();
		try {
			Thread.currentThread().setContextClassLoader(classLoader);
			return supplier.get();
		} finally {
			Thread.currentThread().setContextClassLoader(original);
		}
	}

}
