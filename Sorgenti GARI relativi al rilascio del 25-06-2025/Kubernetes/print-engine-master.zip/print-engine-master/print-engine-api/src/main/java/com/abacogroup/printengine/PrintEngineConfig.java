package com.abacogroup.printengine;

import java.util.Optional;

import org.apache.commons.lang3.StringUtils;

import io.dropwizard.client.JerseyClientConfiguration;
import io.dropwizard.core.Configuration;
import io.dropwizard.db.DataSourceFactory;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = true)
public class PrintEngineConfig extends Configuration {

	private boolean cors = true;

	@Valid
	@NotNull
	private DataSourceFactory database;

	@Valid
	@NotNull
	private DataSourceFactory helperDatabase;

	private RabbitmqConfig rabbitmqConfig;

	@Valid
	@NotNull
	private JerseyClientConfiguration jerseyClient = new JerseyClientConfiguration();

	@Valid
	private BundleConfig bundleConfig = new BundleConfig();

	@Valid
	private Sso2Config sso2Config;

	@Valid
	private FileStoreConfig fileStoreConfig;

	private PrintEngineConfiguration printEngineConfiguration = new PrintEngineConfiguration();

	@Data
	public static class RabbitmqConfig {

		private String host;
		private String user;
		private String password;
		private String virtualhost;
		private Integer port;
	}

	@Data
	public static class PrintEngineConfiguration {

		private String initBaseTempDir;
		private String externalPropertiesDir;
		private boolean keepTempFile = false;
		private long queueTimeoutMs = 1_000L * 60 * 60 * 3; // 3 hours
		private int queueThreads = 20;
		private String workFlowEnvironmentId;

		public String getInitBaseTempDir() {
			return Optional.ofNullable(initBaseTempDir)
					.map(workDir -> StringUtils.removeEnd(workDir, "/"))
					.orElse(System.getProperty("java.io.tmpdir"));
		}
	}

	@Data
	public static class BundleConfig {

		private String configLocation;

		private String initBaseTempDir;

	}

	@Data
	public static class Sso2Config {
		private String url;
		private String tasksAuthPhrase;
	}

	@Data
	public static class FileStoreConfig {
		private String url;
	}

}
