package com.abacogroup.printengine.core.exceptions;

import io.swagger.v3.oas.annotations.media.Schema;

public class ReportException extends AbstractAppException {

	private static final long serialVersionUID = -699181286143764968L;

	public enum ErrEnum {
		GENERIC,
		PRINT_FLOW_ERROR,
		PRINT_FLOW_NOT_FOUND
	}

	public ReportException(ErrEnum code, String message) {
		super(new ErrorBody(code.name(), message));
	}

	@Schema(name = "ReportExceptionErrorBody")
	public static class ErrorBody implements ExceptionErrorBody {
		private final String code;
		private final String message;

		public ErrorBody(String code, String message) {
			this.code = code;
			this.message = message;
		}

		@Override
		@Schema(allowableValues = { "GENERIC", "PRINT_FLOW_ERROR", "PRINT_FLOW_NOT_FOUND" })
		public String getErrorCode() {
			return code;
		}

		@Override
		@Schema
		public String getMessage() {
			return message;
		}
	}
}
