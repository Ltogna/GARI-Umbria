package com.abacogroup.printengine.db.ntt;

import com.abacogroup.printengine.api.PrintJobStatus;
import java.time.LocalDateTime;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder(setterPrefix = "set")
@NoArgsConstructor
public class PrintJobEntity {

	private String uuid;
	private Long reportId;
	private PrintJobStatus status;
	private String fileStoreId;
	private LocalDateTime dtInsert;
	private String bucket;
	private String dest;
}
