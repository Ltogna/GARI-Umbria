package com.abacogroup.printengine.core;

import com.abacogroup.printengine.PrintEngineConfig.PrintEngineConfiguration;
import com.abacogroup.workflow.sdk.beans.testsupport.ProcessDataTestSupport;
import java.util.stream.Stream;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;

class PrintEngineProcedureEnvironmentTest {

	// ----- getProperty -----
	@ParameterizedTest
	@MethodSource
	void test_getProperty_ok(String workflowCode, String envId, String external, String propertyName, Object expectedValue) {
		PrintEngineConfiguration printEngineConfiguration = new PrintEngineConfiguration();
		printEngineConfiguration.setInitBaseTempDir("src/test/resources/com/abacogroup/printengine/core/PrintEngineProcedureEnvironmentTest");
		printEngineConfiguration.setWorkFlowEnvironmentId(envId);
		printEngineConfiguration.setExternalPropertiesDir(external == null ? null
				: "src/test/resources/com/abacogroup/printengine/core/PrintEngineProcedureEnvironmentTest/" + external);
		ProcessDataTestSupport processData = ProcessDataTestSupport.builder()
				.tenantId("test_tenant")
				.workflowCode(workflowCode)
				.workflowHash("xxxxxxxxxxxxx_hash_xxxxxxxxxxxxx")
				.build();
		PrintEngineProcedureEnvironment printEngineProcedureEnvironment = new PrintEngineProcedureEnvironment(
				processData, null, null, null, null, printEngineConfiguration);

		Assertions.assertThat(printEngineProcedureEnvironment.getProperty(propertyName).orElse(null)).isEqualTo(expectedValue);
	}

	static Stream<Arguments> test_getProperty_ok() {
		// @formatter:off
		return Stream.of(Arguments.of("wf_test1", null, null, "my-property", null), Arguments.of("wf_test1", "my-profile", null, "my-property", null)

				, Arguments.of("wf_test2", null, null, "root", null), Arguments.of("wf_test2", null, null, "root.child2", "two"),
				Arguments.of("wf_test2", null, null, "my-property", "applValue"),
				Arguments.of("wf_test2", "my-profile", null, "my-property", "overwrittenValue"),
				Arguments.of("wf_test2", "my-other-profile", null, "my-property", "applValue"),
				Arguments.of("wf_test2", "my-profile", null, "my-not-modified-property", "still ok"),
				Arguments.of("wf_test2", null, null, "my-custom-property", null),
				Arguments.of("wf_test2", null, "property-source-empty", "my-property", "applValue"),
				Arguments.of("wf_test2", "my-profile", "property-source-empty", "my-property", "overwrittenValue"),
				Arguments.of("wf_test2", null, "property-source-1", "my-property", "source 1 default"),
				Arguments.of("wf_test2", "my-profile", "property-source-1", "my-property", "source 1 dev"),
				Arguments.of("wf_test2", null, "property-source-2", "my-property", "source 2 tenant default"),
				Arguments.of("wf_test2", "my-profile", "property-source-2", "my-property", "source 2 tenant dev"),
				Arguments.of("wf_test2", null, "property-source-3", "my-property", "source 3 wf_test2 default"),
				Arguments.of("wf_test2", "my-profile", "property-source-3", "my-property", "source 3 wf_test2 dev")

				, Arguments.of("wf_test3", null, null, "my-property", null), Arguments.of("wf_test3", "my-profile", null, "my-property", "value only here")

				, Arguments.of("wf_test4", null, null, "my-property-compose", "this is default value"),
				Arguments.of("wf_test4", "my-profile", null, "my-property-compose", "this is my value"),
				Arguments.of("wf_test4", null, "property-source-1", "my-property-compose", "this is source 1 default"),
				Arguments.of("wf_test4", "my-profile", "property-source-1", "my-property-compose", "this is source 1 dev"),
				Arguments.of("wf_test4", null, "property-source-2", "my-property-compose", "this is source 2 tenant default"),
				Arguments.of("wf_test4", "my-profile", "property-source-2", "my-property-compose", "this is source 2 tenant dev"),
				Arguments.of("wf_test4", null, "property-source-3", "my-property-compose", "this is source 3 wf_test4 default"),
				Arguments.of("wf_test4", "my-profile", "property-source-3", "my-property-compose", "this is source 3 wf_test4 dev"));
		// @formatter:on
	}
}
