package com.abacogroup.printengine.db.dao;

import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.Optional;
import java.util.UUID;

import org.hamcrest.CoreMatchers;
import org.hamcrest.MatcherAssert;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

import com.abacogroup.printengine.api.PrintJobStatus;
import com.abacogroup.printengine.common.core.JdbiTest;
import com.abacogroup.printengine.db.ntt.PrintJobEntity;
import com.abacogroup.printengine.db.ntt.PrintJobEntity.PrintJobEntityBuilder;

import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;

@ExtendWith(DropwizardExtensionsSupport.class)
class PrintJobDAOTest extends JdbiTest {

	private static final String TEST_UUID = "360c577a-2859-494e-9caf-2e96283863a6";
	private final PrintJobDAO printJobDAO = this.getDAO(PrintJobDAO.class);
	private final ReportDAO reportDAO = this.getDAO(ReportDAO.class);

	public PrintJobEntityBuilder<?, ?> printJobEntityBuilder(UUID uuid) {
		return PrintJobEntity.builder()
				.setUuid(Optional.ofNullable(uuid).map(java.util.UUID::toString).orElse(java.util.UUID.randomUUID().toString()))
				.setStatus(PrintJobStatus.ACKNOWLEDGE);

	}

	@Test
	void testAdd() {
		getJdbi().useHandle(handle -> {
			handle.begin();

			handle.execute("insert into pre_jasper_reports (id,tenant_id,workflow_code) "
					+ "values (-1, 'master', 'w_code')");

			printJobDAO.insert(
					printJobEntityBuilder(null)
							.setReportId(-1L)
							.setDtInsert(printJobDAO.getCurrentTimestamp())
							.setBucket("bucket_name")
							.setDest("dest")
							.build());

			handle.rollback();
		});

		assertTrue(true);
	}

	@Test
	void testUpdateStatus() {
		getJdbi().useHandle(handle -> {
			handle.begin();

			handle.execute("insert into pre_jasper_reports (id,tenant_id,workflow_code) "
					+ "values (-1, 'master', 'w_code')");

			handle.execute("insert into pre_print_jobs (uuid, report_id, status, file_store_id,dt_insert,bucket,dest) "
					+ "values (?, -1, ?, null,?,?,?)", TEST_UUID, PrintJobStatus.ACKNOWLEDGE, printJobDAO.getCurrentTimestamp(), "bucket_name", "dest");

			printJobDAO.updateStatus(TEST_UUID, PrintJobStatus.PROGRESS, printJobDAO.getCurrentTimestamp());

			Optional<PrintJobEntity> jobEntity = printJobDAO
					.findByTenantAndWorkFlowCodeAndUUID("master", "w_code", TEST_UUID);

			MatcherAssert.assertThat(jobEntity.isPresent(), CoreMatchers.is(true));

			handle.rollback();
		});

	}
}
