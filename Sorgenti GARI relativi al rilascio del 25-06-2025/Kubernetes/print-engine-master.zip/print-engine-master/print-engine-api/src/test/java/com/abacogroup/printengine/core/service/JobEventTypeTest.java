package com.abacogroup.printengine.core.service;

import static org.assertj.core.api.Assertions.assertThat;

import com.abacogroup.printengine.core.service.PrintJobEventProducer.JobEventType;
import org.junit.jupiter.api.Test;

public class JobEventTypeTest {

	// ----- getTopic -----
	@Test
	void test_getTopic_ok() {
		assertThat(JobEventType.READY.getTopic("xyz")).isEqualTo("print-engine-job.xyz.ready");
		assertThat(JobEventType.ERROR.getTopic("xyz")).isEqualTo("print-engine-job.xyz.error");
	}
}
