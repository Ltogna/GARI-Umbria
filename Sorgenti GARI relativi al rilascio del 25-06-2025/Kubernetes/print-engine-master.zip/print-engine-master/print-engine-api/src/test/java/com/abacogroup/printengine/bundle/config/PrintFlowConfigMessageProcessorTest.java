package com.abacogroup.printengine.bundle.config;

import static java.util.stream.Collectors.toList;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.stream.Collectors;

import org.apache.commons.io.FileUtils;
import org.hamcrest.CoreMatchers;
import org.hamcrest.MatcherAssert;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mockito;

import com.abacogroup.bundles.initializer.impl.exceptions.BundleException;
import com.abacogroup.bundles.listener.configdata.ConfigDataMessage;
import com.abacogroup.printengine.common.core.JdbiTest;
import com.abacogroup.printengine.core.service.JasperCompiler;
import com.abacogroup.printengine.core.service.ReportService;
import com.abacogroup.printengine.core.service.impl.JasperCompilerImpl;
import com.abacogroup.printengine.core.service.impl.ReportServiceImpl;
import com.abacogroup.printengine.db.ntt.ReportEntity;
import com.abacogroup.printengine.sdk.Constants;
import com.abacogroup.printengine.sdk.PrintEngineUtils;
import com.abacogroup.workflow.server.model.NodeType;
import com.abacogroup.workflow.server.services.WorkflowDefinition;
import com.abacogroup.workflow.server.services.WorkflowDefinition.Node;
import com.abacogroup.workflow.server.services.WorkflowService;
import com.abacogroup.workflow.server.services.classloader.WorkflowClassLoader;

import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;
import lombok.SneakyThrows;

@ExtendWith(DropwizardExtensionsSupport.class)
class PrintFlowConfigMessageProcessorTest extends JdbiTest {

	private final PrintFlowConfigMessageProcessor processor = getService(PrintFlowConfigMessageProcessor.class);

	@Test
	@SneakyThrows
	void test_install_bundle() {

		getJdbi().useTransaction(handle -> {

			final String tenant = "master";

			String baseWorkDir = JdbiTest.getConfiguration().getPrintEngineConfiguration().getInitBaseTempDir();

			Path sourceDir = PrintEngineUtils.getSourceDir(baseWorkDir, tenant, "lol-sample-report", "2c0f1854c595b3efc960ed710a7ca16e");

			FileUtils.deleteQuietly(sourceDir.toFile());

			WorkflowService workflowServiceSpy = Mockito.spy(getService(WorkflowService.class));
			ReportService reportServiceSpy = Mockito.spy(getService(ReportServiceImpl.class));

			JasperCompiler jasperCompilerSpy = Mockito.spy(getService(JasperCompilerImpl.class));

			injectMock(processor, workflowServiceSpy);
			injectMock(processor, reportServiceSpy);
			injectMock(processor, jasperCompilerSpy);

			var path = Path.of("src/test/resources",
					this.getClass().getPackageName().replaceAll("\\.", "/"),
					"xxx");

			processor.onMessage(new ConfigDataMessage()
					.setTenantId(tenant)
					.setConfigFiles(Files.list(path)
							.collect(Collectors.toList())));

			ArgumentCaptor<File> captor = ArgumentCaptor.forClass(File.class);
			Mockito.verify(workflowServiceSpy, Mockito.times(1))
					.addOrUpdateWorkflow(Mockito.eq(tenant), captor.capture());
			File file = captor.getValue();
			MatcherAssert.assertThat(file.getName(), CoreMatchers.is("lol-sample-report-1.0.0-SNAPSHOT.jar"));

			ArgumentCaptor<ReportEntity> reportEntityCaptor = ArgumentCaptor.forClass(ReportEntity.class);
			Mockito.verify(reportServiceSpy, Mockito.times(1))
					.add(reportEntityCaptor.capture());

			var reportEntity = reportEntityCaptor.getValue();
			MatcherAssert.assertThat(reportEntity.getWorkflowCode(), CoreMatchers.is("lol-sample-report"));
			MatcherAssert.assertThat(reportEntity.getTenantId(), CoreMatchers.is(tenant));

			// test extracted...

			Path sourceDirPath = sourceDir;
			assertTrue(sourceDirPath.toFile().exists());

			Mockito.verify(jasperCompilerSpy, Mockito.times(1))
					.compileAll(eq(sourceDirPath), any(WorkflowClassLoader.class));

			List<Path> files = Files.walk(sourceDirPath)
					.filter(x -> x.getFileName().toString().toLowerCase().endsWith(Constants.JRXML))
					.collect(toList());

			assertThat(files.size(), CoreMatchers.is(3));

			// test jasper...
			List<Path> jasperFiles = Files.walk(sourceDirPath)
					.filter(x -> x.getFileName().toString().toLowerCase().endsWith(Constants.JASPER))
					.collect(toList());

			assertThat(jasperFiles.size(), CoreMatchers.is(3));
			handle.rollback();
		});
	}

	@Test
	@SneakyThrows
	void test_validate_wk_node_types_OK() {
		WorkflowDefinition wfd = new WorkflowDefinition();
		wfd.setCode("test-wf");
		wfd.setNodes(List.of(
				givenNode(NodeType.start, "the start"),
				givenNode(NodeType.proc, "proc 1"),
				givenNode(NodeType.proc, "proc 2"),
				givenNode(NodeType.proc, "proc 3"),
				givenNode(NodeType.end, "the end")));

		assertDoesNotThrow(() -> processor.validateWkNodeTypes(wfd));
	}

	@Test
	@SneakyThrows
	void test_validate_wk_node_types_KO() {
		WorkflowDefinition wfd = new WorkflowDefinition();
		wfd.setCode("test-wf");
		wfd.setNodes(List.of(
				givenNode(NodeType.start, "the start"),
				givenNode(NodeType.proc, "proc 1"),
				givenNode(NodeType.status, "status 1"),
				givenNode(NodeType.proc, "proc 2"),
				givenNode(NodeType.proc, "proc 3"),
				givenNode(NodeType.status, "status 2"),
				givenNode(NodeType.end, "the end")));

		assertThrows(BundleException.class, () -> processor.validateWkNodeTypes(wfd));
	}

	private static Node givenNode(NodeType status, String name) {
		Node node = new Node();
		node.setType(status);
		node.setName(name);
		return node;
	}
}
