package com.abacogroup.printengine.core.service.impl;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLClassLoader;
import java.nio.file.Files;
import java.nio.file.Path;

import org.hamcrest.CoreMatchers;
import org.junit.jupiter.api.Test;

import com.abacogroup.printengine.core.exceptions.JasperException;

import net.sf.jasperreports.engine.JasperReport;

class JasperCompilerImplTest {

	private static final JasperCompilerImpl jasperCompiler = new JasperCompilerImpl();

	private static final File input = getFullPath("/input/example.jrxml").toFile();

	private static final Path output;

	static {
		File parent = new File("target/test/" + JasperCompilerImplTest.class.getSimpleName() + "/report");
		parent.mkdirs();
		output = new File(parent, "/report.jasper").toPath();
	}

	private static Path getFullPath(String subPath) {
		return Path.of("src/test/resources",
				JasperCompilerImplTest.class.getName().replaceAll("\\.", "/"),
				subPath);
	}

	@Test
	void compile() {
		JasperReport report = jasperCompiler.compile(input, null);

		assertThat(report.getName(), CoreMatchers.is("Blank_A4"));
	}

	@Test
	void test_compile_with_out() throws IOException {

		var out = new ByteArrayOutputStream();

		jasperCompiler.compile(input, out, null);

		assertFalse(out.size() == 0);

		// CHECK the output folder
		Files.write(output, out.toByteArray());

	}

	@Test
	void test_compile_with_in_and_out() throws IOException {

		InputStream inputStream = new FileInputStream(input);

		var outputStream = new ByteArrayOutputStream();

		jasperCompiler.compile(inputStream, outputStream, null);

		// CHECK the output folder
		Files.write(output, outputStream.toByteArray());

		assertTrue(true);
	}

	@Test
	void test_compile_with_classloader() throws MalformedURLException, IOException {
		File file = new File("src/test/resources/bundles/standard/print-engine/pte-001/print-flow/print-with-class-1.0.0-SNAPSHOT.jar");
		assertTrue(file.exists());
		try (URLClassLoader loader = new URLClassLoader(new URL[] { file.toURI().toURL() }, getClass().getClassLoader())) {
			try (InputStream in = loader.getResourceAsStream("test1/main.jrxml")) {
				assertNotNull(in);
				assertThrows(JasperException.class, () -> jasperCompiler.compile(in, new ByteArrayOutputStream(), null));
			}

			try (InputStream in = loader.getResourceAsStream("test1/main.jrxml")) {
				assertDoesNotThrow(() -> jasperCompiler.compile(in, new ByteArrayOutputStream(), loader));
			}
		}
	}
}
