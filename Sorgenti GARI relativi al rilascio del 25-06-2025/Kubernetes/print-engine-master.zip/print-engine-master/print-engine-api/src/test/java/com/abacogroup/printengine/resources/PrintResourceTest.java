package com.abacogroup.printengine.resources;

import static com.abacogroup.printengine.resources.req.PrintReq.DEFAULT_BUCKET_NAME;
import static org.hamcrest.Matchers.is;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.abacogroup.printengine.core.service.ReportService;
import com.abacogroup.printengine.core.service.embededqueue.PrintJob;
import com.abacogroup.printengine.core.service.embededqueue.PrintQueue;
import com.abacogroup.printengine.core.service.impl.ReportServiceImpl;
import com.abacogroup.printengine.db.ntt.PrintJobEntity;
import com.abacogroup.printengine.resources.req.PrintReq;
import com.abacogroup.workflow.server.model.ProcessTransitionResult;
import com.abacogroup.workflow.server.model.ProcessTransitionResult.TransitionLog;
import com.abacogroup.workflow.server.services.ProcessService;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;
import io.dropwizard.testing.junit5.ResourceExtension;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import org.hamcrest.CoreMatchers;
import org.hamcrest.MatcherAssert;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mockito;

@ExtendWith(DropwizardExtensionsSupport.class)
class PrintResourceTest {

	private final ProcessService processService = Mockito.mock(ProcessService.class);
	private final ReportService reportService = Mockito.mock(ReportServiceImpl.class);
	private final PrintQueue printQueue = Mockito.mock(PrintQueue.class);

	private final ResourceExtension EXT = WebCliHelper
			.createEXT(new PrintResource(reportService, printQueue));

	@Test
	void test_post() throws IOException {
		given(processService.createProcess(Mockito.any())).willReturn(ProcessTransitionResult.builder()
				.processId(1L)
				.currentNode("a-node")
				.lastTransitionLog(Mockito.mock(TransitionLog.class))
				.messages(new ArrayList<>())
				.build());

		when(reportService.initPrintJob(Mockito.anyString(), Mockito.anyString(), Mockito.any(PrintReq.class)))
				.thenReturn(PrintJobEntity.builder().setUuid(UUID.randomUUID().toString()).build());
		// ----

		String path = String.format("/master/public/v1" + "/a-code");
		Map<String, Object> beanMap = new HashMap<>();
		beanMap.put("foo", "bar");

		WebCliHelper.executePost(EXT, path, beanMap, WebCliHelper.BASIC_CREDENTIALS, String.class);

		// verify(reportService).getReportEntity("master", "a-code");
		// verify(reportService).setupWorkDir("master", "a-code");

		ArgumentCaptor<PrintJob> argumentCaptor = ArgumentCaptor.forClass(PrintJob.class);
		verify(printQueue, times(1)).add(argumentCaptor.capture(), Mockito.anyLong());

		PrintJob printJob = argumentCaptor.getValue();
		MatcherAssert.assertThat(printJob.getTenantId(), CoreMatchers.is("master"));
		MatcherAssert.assertThat(printJob.getLocale(), CoreMatchers.is("en"));
		MatcherAssert.assertThat(printJob.getWorkflowCode(), CoreMatchers.is("a-code"));
		MatcherAssert.assertThat(printJob.getUserName(), CoreMatchers.is("test-user@example"));
		System.out.println(printJob.getInput().getParams());
		MatcherAssert.assertThat(printJob.getInput().getParams().get("foo"),
				is("bar"));

		MatcherAssert.assertThat(printJob.getPrintReq().getBucket(), CoreMatchers.is(DEFAULT_BUCKET_NAME));
	}

	@Test
	void test_post_with_permanent_store() throws IOException {
		given(processService.createProcess(Mockito.any())).willReturn(ProcessTransitionResult.builder()
				.processId(1L)
				.currentNode("a-node")
				.lastTransitionLog(Mockito.mock(TransitionLog.class))
				.messages(new ArrayList<>())
				.build());

		when(reportService.initPrintJob(Mockito.anyString(), Mockito.anyString(), Mockito.any(PrintReq.class)))
				.thenReturn(PrintJobEntity.builder().setUuid(UUID.randomUUID().toString()).build());
		// ----

		String path = String.format("%s%s", "/master/public/v1", "/a-code");

		Map<String, Object> payloadMap = new HashMap<>();
		payloadMap.put("foo", "bar");

		PrintReq req = new PrintReq()
				.setBucket("bbb");
		var queryParamsMap = new ObjectMapper().convertValue(req, Map.class);

		WebCliHelper.executePostNoBody(EXT, path, payloadMap, queryParamsMap, WebCliHelper.BASIC_CREDENTIALS, Map.class);

		ArgumentCaptor<PrintJob> argumentCaptor = ArgumentCaptor.forClass(PrintJob.class);
		verify(printQueue, times(1)).add(argumentCaptor.capture(), Mockito.anyLong());

		PrintJob printJob = argumentCaptor.getValue();
		MatcherAssert.assertThat(printJob.getTenantId(), CoreMatchers.is("master"));
		MatcherAssert.assertThat(printJob.getLocale(), CoreMatchers.is("en"));
		MatcherAssert.assertThat(printJob.getWorkflowCode(), CoreMatchers.is("a-code"));
		MatcherAssert.assertThat(printJob.getUserName(), CoreMatchers.is("test-user@example"));

		MatcherAssert.assertThat(printJob.getPrintReq().getBucket(), CoreMatchers.is("bbb"));

	}
}
