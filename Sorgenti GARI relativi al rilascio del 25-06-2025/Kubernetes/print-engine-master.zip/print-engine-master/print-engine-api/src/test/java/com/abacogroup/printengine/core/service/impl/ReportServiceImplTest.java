package com.abacogroup.printengine.core.service.impl;

import static com.abacogroup.printengine.core.service.ReportService.SCOPE;
import static java.util.stream.Collectors.toList;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Instant;
import java.time.OffsetDateTime;
import java.time.ZoneId;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import org.hamcrest.CoreMatchers;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;

import com.abacogroup.bundles.listener.configdata.ConfigDataMessage;
import com.abacogroup.printengine.bundle.config.PrintFlowConfigMessageProcessor;
import com.abacogroup.printengine.common.core.JdbiTest;
import com.abacogroup.printengine.core.exceptions.ReportException;
import com.abacogroup.printengine.core.exceptions.ReportException.ErrEnum;
import com.abacogroup.printengine.core.service.ReportService;
import com.abacogroup.printengine.db.ntt.ReportEntity;
import com.abacogroup.printengine.sdk.Constants;
import com.abacogroup.printengine.sdk.PrintEngineUtils;
import com.abacogroup.printengine.sdk.model.PrintEngineInput;
import com.abacogroup.workflow.server.db.ntt.WorLogTransitionEntity;
import com.abacogroup.workflow.server.model.CreateProcessParams;
import com.abacogroup.workflow.server.model.ProcessTransitionResult;
import com.abacogroup.workflow.server.model.ProcessTransitionResult.TransitionLog;
import com.abacogroup.workflow.server.services.ProcessService;
import com.abacogroup.workflow.server.services.exceptions.WorkflowNotFoundException;

import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;
import jakarta.ws.rs.core.SecurityContext;
import lombok.SneakyThrows;

@ExtendWith(DropwizardExtensionsSupport.class)
class ReportServiceImplTest extends JdbiTest {

	private static final String TENANT_ID = "test_tenant";
	private static final String CODE = "sample-report";
	private final ReportService service = getService(ReportServiceImpl.class);
	private PrintFlowConfigMessageProcessor processor = getService(PrintFlowConfigMessageProcessor.class);
	private ProcessService processService;

	private static Path getFullPath(String subPath) {
		return Path.of("src/test/resources",
				ReportServiceImplTest.class.getName().replaceAll("\\.", "/"),
				subPath);
	}

	@BeforeEach
	void setUp() {
		processService = mock(ProcessService.class);
		this.injectMock(service, processService);
	}

	@Test
	void test_add_getOne() {
		getJdbi().useHandle(handle -> {
			handle.begin();
			// insert report
			ReportEntity entity = ReportEntity.builder()
					.setTenantId(TENANT_ID).setWorkflowCode(CODE)
					.build();

			service.add(entity);

			Optional<ReportEntity> report = ((ReportServiceImpl) service).getOne(TENANT_ID, CODE);
			assertTrue(report.isPresent());

			handle.rollback();

		});
	}

	// ----- checkPrintFlowCode -----
	@Test
	void test_checkPrintFlowCode_ko() {
		ReportException reportException = assertThrows(ReportException.class, () -> ((ReportServiceImpl) service).getReportEntity(
				TENANT_ID, "boom"));

		org.assertj.core.api.Assertions.assertThat(reportException).isNotNull()
				.extracting(ReportException::getCode).isEqualTo(ErrEnum.PRINT_FLOW_NOT_FOUND.toString());
	}

	@Test
	void test_getList() {
		getJdbi().useHandle(handle -> {
			handle.begin();

			// insert reports
			ReportEntity entity1 = ReportEntity.builder()
					.setTenantId(TENANT_ID).setWorkflowCode("WK_1")
					.build();

			ReportEntity entity2 = ReportEntity.builder()
					.setTenantId(TENANT_ID).setWorkflowCode("WK_2")
					.build();

			ReportEntity entity3 = ReportEntity.builder()
					.setTenantId(TENANT_ID).setWorkflowCode("WK_3")
					.build();

			String NEW_TENANT = "another_tenant";
			ReportEntity entity4 = ReportEntity.builder()
					.setTenantId(NEW_TENANT).setWorkflowCode("WK_4")
					.build();

			service.add(entity1);
			service.add(entity2);
			service.add(entity3);
			service.add(entity4);

			List<ReportEntity> reports = ((ReportServiceImpl) service).getList(TENANT_ID);
			assertThat(reports.size(), CoreMatchers.is(3));

			reports = ((ReportServiceImpl) service).getList(NEW_TENANT);
			assertThat(reports.size(), CoreMatchers.is(1));
			handle.rollback();
		});
	}

	@Test
	void test_setup_workdir() throws IOException {
		getJdbi().useHandle(handle -> {
			handle.begin();
			Path jarPath = getFullPath("/bundle/");

			String baseWorkDir = JdbiTest.getConfiguration().getPrintEngineConfiguration().getInitBaseTempDir();
			Path sourceDirPath = PrintEngineUtils.getSourceDir(baseWorkDir, TENANT_ID, CODE, "0fbf51b61c01fdf2dc0a482e1ebe055c");

			// install bundle
			processor.onMessage(new ConfigDataMessage().setTenantId(TENANT_ID)
					.setConfigFiles(Files.list(jarPath).collect(Collectors.toList())));

			// asserts
			assertTrue(sourceDirPath.toFile().exists());

			List<Path> files = Files.walk(sourceDirPath)
					.filter(x -> x.getFileName().toString().toLowerCase().endsWith(Constants.JRXML))
					.collect(toList());
			assertThat(files.size(), CoreMatchers.is(3));

			List<Path> jasperFiles = Files.walk(sourceDirPath)
					.filter(x -> x.getFileName().toString().toLowerCase().endsWith(Constants.JASPER))
					.collect(toList());
			assertThat(jasperFiles.size(), CoreMatchers.is(3));

			System.out.println("-----");
			// when the wf is not found : wrong tenantId
			Assertions.assertThrows(WorkflowNotFoundException.class,
					() -> {
						((ReportServiceImpl) service).setupSourceDir("xx", CODE);
					});
			System.out.println("-----");

			((ReportServiceImpl) service).setupSourceDir(TENANT_ID, CODE);

			// check if the jasper files still exist
			assertTrue(sourceDirPath.toFile().exists());
			assertThat(jasperFiles.size(), CoreMatchers.is(3));

			handle.rollback();
		});
	}

	// ----- startPrintFlow -----
	@Test
	@SneakyThrows
	void test_startPrintFlow_ok() {
		SecurityContext securityContext = mock(SecurityContext.class);
		PrintEngineInput printEngineInput = PrintEngineInput.builder()
				.setParams(Map.of("key", "value"))
				.build();
		String workflowCode = "the_code";
		String lang = "en";
		ProcessTransitionResult processTransitionResult = ProcessTransitionResult.builder()
				.processId(123L)
				.lastTransitionLog(buildLastTransitionLog(false))
				.currentNode("end")
				.messages(List.of())
				.build();
		given(processService.createProcess(any())).willReturn(processTransitionResult);

		ProcessTransitionResult result = service.startPrintFlow(
				workflowCode,
				printEngineInput,
				securityContext,
				lang,
				TENANT_ID);

		org.assertj.core.api.Assertions.assertThat(result).isNotNull().isSameAs(processTransitionResult);
		ArgumentCaptor<CreateProcessParams> processParamsCaptor = ArgumentCaptor.forClass(CreateProcessParams.class);
		verify(processService).createProcess(processParamsCaptor.capture());
		CreateProcessParams CreateProcessParams = processParamsCaptor.getValue();
		org.assertj.core.api.Assertions.assertThat(CreateProcessParams).isNotNull();
		org.assertj.core.api.Assertions.assertThat(CreateProcessParams.getTenantId()).isEqualTo(TENANT_ID);
		org.assertj.core.api.Assertions.assertThat(CreateProcessParams.getScope()).isEqualTo(SCOPE);
		org.assertj.core.api.Assertions.assertThat(CreateProcessParams.getWorkflowCode()).isEqualTo(workflowCode);
		org.assertj.core.api.Assertions.assertThat(CreateProcessParams.getGlobalVars()).isEqualTo(Map.of(
				PrintEngineInput.PARAM_NAME, printEngineInput));
		org.assertj.core.api.Assertions.assertThat(CreateProcessParams.getAuthContext()).isNotNull();

	}

	@Test
	@SneakyThrows
	void test_givenProcessFailed_startPrintFlow_ko() {
		SecurityContext securityContext = mock(SecurityContext.class);
		PrintEngineInput printEngineInput = PrintEngineInput.builder()
				.setParams(Map.of("key", "value"))
				.build();
		String workflowCode = "the_code";
		String lang = "en";
		ProcessTransitionResult processTransitionResult = ProcessTransitionResult.builder()
				.processId(123L)
				.lastTransitionLog(buildLastTransitionLog(true))
				.currentNode("end")
				.messages(List.of())
				.build();
		given(processService.createProcess(any())).willReturn(processTransitionResult);

		ReportException reportException = assertThrows(ReportException.class, () -> service.startPrintFlow(
				workflowCode,
				printEngineInput,
				securityContext,
				lang,
				TENANT_ID));

		org.assertj.core.api.Assertions.assertThat(reportException).isNotNull()
				.extracting(ReportException::getCode).isEqualTo(ErrEnum.PRINT_FLOW_ERROR.toString());
		ArgumentCaptor<CreateProcessParams> processParamsCaptor = ArgumentCaptor.forClass(CreateProcessParams.class);
		verify(processService).createProcess(processParamsCaptor.capture());
		CreateProcessParams CreateProcessParams = processParamsCaptor.getValue();
		org.assertj.core.api.Assertions.assertThat(CreateProcessParams).isNotNull();
		org.assertj.core.api.Assertions.assertThat(CreateProcessParams.getTenantId()).isEqualTo(TENANT_ID);
		org.assertj.core.api.Assertions.assertThat(CreateProcessParams.getScope()).isEqualTo(SCOPE);
		org.assertj.core.api.Assertions.assertThat(CreateProcessParams.getWorkflowCode()).isEqualTo(workflowCode);
		org.assertj.core.api.Assertions.assertThat(CreateProcessParams.getGlobalVars()).isEqualTo(Map.of(
				PrintEngineInput.PARAM_NAME, printEngineInput));
		org.assertj.core.api.Assertions.assertThat(CreateProcessParams.getAuthContext()).isNotNull();

	}

	private static TransitionLog buildLastTransitionLog(boolean fail) {
		WorLogTransitionEntity ntt = new WorLogTransitionEntity();
		ntt.setId(999L);
		ntt.setWor_workflow_transition_id(888L);
		ntt.setIs_failed(fail ? 1 : 0);
		ntt.setNotes("Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.");
		ntt.setStart_date(OffsetDateTime.ofInstant(Instant.now().minus(1, ChronoUnit.MINUTES), ZoneId.systemDefault()));
		ntt.setEnd_date(OffsetDateTime.ofInstant(Instant.now(), ZoneId.systemDefault()));
		ntt.setUser_id("user1");

		return new TransitionLog(ntt);
	}

}
