package com.abacogroup.printengine.sdk.proc;

import static com.abacogroup.printengine.sdk.model.PrintEngineInput.PARAM_NAME;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import com.abacogroup.bundles.listener.configdata.ConfigDataMessage;
import com.abacogroup.printengine.bundle.config.PrintFlowConfigMessageProcessor;
import com.abacogroup.printengine.common.core.JdbiTest;
import com.abacogroup.printengine.core.PrintEngineProcedureEnvironment;
import com.abacogroup.printengine.sdk.ProcEnvConstants;
import com.abacogroup.printengine.sdk.model.PrintEngineInput;
import com.abacogroup.printengine.sdk.model.PrintParameter;
import com.abacogroup.workflow.sdk.auth.AuthContext;
import com.abacogroup.workflow.sdk.beans.testsupport.AuthContextTestSupport;
import com.abacogroup.workflow.sdk.beans.testsupport.ProcessDataTestSupport;
import com.abacogroup.workflow.sdk.proc.ProcedureEnvironment;
import com.abacogroup.workflow.server.services.WorkflowService;
import com.abacogroup.workflow.server.services.testsupport.ProcessServiceTestSupport;
import com.codahale.metrics.NoopMetricRegistry;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.dropwizard.db.ManagedDataSource;
import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;
import java.io.File;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.jdbi.v3.core.Handle;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

@Slf4j
@ExtendWith(DropwizardExtensionsSupport.class)
class CreateJasperReportsTest extends JdbiTest {
	private static final AuthContext SUPERUSER = new AuthContextTestSupport();

	private static ProcessServiceTestSupport processServiceTestSupport;
	private static WorkflowService workflowService;

	// @BeforeEach
	@AfterEach
	void tearDown() {
		Handle handleHelper = getJdbiHelper().open();

		handleHelper.execute("delete from tmp_items");
		handleHelper.execute("delete from tmp_parties");

	}

	@SneakyThrows
	@Test
	void test_pdf() {
		String tenantId = "CreateJasperReportsTest_t";
		long processId = 123L;

		getJdbi().useTransaction(handle -> {

			PrintFlowConfigMessageProcessor printFlowConfigMessageProcessor = this.getService(PrintFlowConfigMessageProcessor.class);
			printFlowConfigMessageProcessor.onMessage(new ConfigDataMessage()
					.setTenantId(tenantId)
					.setConfigFiles(List.of(Path.of("src/test/resources",
							"bundles/standard/print-engine/pte-001/print-flow",
							"sample-report-1.0.0-SNAPSHOT.jar"))));

			getJdbiHelper().useHandle(handleHelper -> {
				String sqlPrt = "insert into tmp_parties (id, process_id, first_name) values (?, ?, ?)";
				handleHelper.execute(sqlPrt, 1L, processId, "Gianni");
				handleHelper.execute(sqlPrt, 2L, processId, "Rosa");
				handleHelper.execute(sqlPrt, 3L, processId, "Marco");
				handleHelper.execute(sqlPrt, 4L, processId, "Anna");
				handleHelper.execute(sqlPrt, 5L, processId, "Andrea");
				handleHelper.execute(sqlPrt, 6L, 999L, "ignore me");

				String sqlRei = "insert into tmp_items (id, process_id, item_name, party_id) values (?, ?, ?, ?)";
				handleHelper.execute(sqlRei, 1L, processId, "Casa di Gianni", 1L);
				handleHelper.execute(sqlRei, 2L, processId, "Terreno di Gianni", 1L);
				handleHelper.execute(sqlRei, 3L, processId, "Stanza di Marco", 3L);
				handleHelper.execute(sqlRei, 4L, processId, "Estintore di Anna", 4L);
				handleHelper.execute(sqlRei, 6L, 999L, "ignored by ignore me", 6L);
			});

			CreateJasperReports proc = new CreateJasperReports();

			Map<String, Object> inputParams = new HashMap<>();
			inputParams.put("foo", "bar");
			PrintEngineInput input = PrintEngineInput.builder()
					.setParams(inputParams)
					.build();

			String workflowCode = "sample-report";
			ProcessDataTestSupport processData = ProcessDataTestSupport.builder()
					.tenantId(tenantId)
					.globalVars(new HashMap<>(
							Map.of(PARAM_NAME, input)))
					.procedureParameter(PrintParameter.builder()
							.setMainTemplate("main")
							.setPath("test1")
							.build())
					.processId(processId)
					.workflowCode(workflowCode)
					.workflowHash("c7fcc5f5977e1c3b5974220f8e9c52e6")
					.authContext(AuthContextTestSupport.builder().localeCode("de").build())
					.build();

			ManagedDataSource helperDataSource = getConfiguration().getHelperDatabase().build(new NoopMetricRegistry(), "test_helper_ds");
			ProcedureEnvironment env = new PrintEngineProcedureEnvironment(processData, null, getJdbiHelper(), helperDataSource,
					new ObjectMapper(), getConfiguration().getPrintEngineConfiguration());

			String fileNme = env.<String>getProperty(ProcEnvConstants.PROPERTY_FILE_NAME).get();
			File expectedPdfFile = new File(fileNme);
			expectedPdfFile.delete();
			assertFalse(expectedPdfFile.exists());

			proc.execute(processData, env);

			assertTrue(expectedPdfFile.exists());

			handle.rollback();
		});
	}

}
