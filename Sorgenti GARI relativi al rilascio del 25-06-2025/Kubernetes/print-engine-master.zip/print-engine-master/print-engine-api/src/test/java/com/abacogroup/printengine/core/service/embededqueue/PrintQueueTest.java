package com.abacogroup.printengine.core.service.embededqueue;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.Principal;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

import org.apache.commons.io.FileUtils;
import org.assertj.core.api.Assertions;
import org.hamcrest.CoreMatchers;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mockito;

import com.abacogroup.dropwizard.auth.sso2.Sso2Client;
import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.filestore.client.FileStoreClient;
import com.abacogroup.filestore.client.auth.Sso2Authenticator;
import com.abacogroup.filestore.client.request.FileToAddMetadata;
import com.abacogroup.filestore.client.response.AddFileResponse;
import com.abacogroup.printengine.api.PrintJobResponse;
import com.abacogroup.printengine.api.PrintJobStatus;
import com.abacogroup.printengine.common.core.JdbiTest;
import com.abacogroup.printengine.core.exceptions.ReportException;
import com.abacogroup.printengine.core.exceptions.ReportException.ErrEnum;
import com.abacogroup.printengine.core.service.PrintJobEventProducer;
import com.abacogroup.printengine.core.service.PrintJobEventProducer.JobEventType;
import com.abacogroup.printengine.core.service.ReportService;
import com.abacogroup.printengine.sdk.Constants;
import com.abacogroup.printengine.sdk.model.PrintEngineInput;
import com.abacogroup.workflow.server.model.ProcessTransitionResult;
import com.abacogroup.workflow.server.model.ProcessTransitionResult.TransitionLog;

import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;
import jakarta.ws.rs.core.SecurityContext;
import lombok.SneakyThrows;

@ExtendWith(DropwizardExtensionsSupport.class)
class PrintQueueTest extends JdbiTest {

	private static final String TENANT_ID = "PrintQueueTest_t";

	private final PrintQueue printQueue = getService(PrintQueue.class);

	private final ReportService reportService = Mockito.mock(ReportService.class);
	private final Sso2Client sso2Client = Mockito.mock(Sso2Client.class);
	private final FileStoreClient fileStoreClient = Mockito.mock(FileStoreClient.class);
	private final PrintJobEventProducer eventProducer = mock(PrintJobEventProducer.class);

	@AfterEach
	void tearDown() {
		getJdbi().useHandle(h -> h.execute("delete from equ_jobs"));
	}

	@BeforeEach
	void setUp() {
		injectMock(printQueue, reportService);
		injectMock(printQueue, sso2Client);
		injectMock(printQueue, fileStoreClient);
		injectMock(printQueue, eventProducer);
	}

	@Test
	@SneakyThrows
	void test_queue_ok() {
		if (System.getProperty("os.name").toLowerCase().startsWith("win")) {
			// Files.deleteQuietly() is not working on windows, probably because the file is still locked by us
			// but I don't really know...
			return;
		}

		String jobUuid = "0000";
		String fileStoreId = "__OK__";

		// #### given
		given(sso2Client.createSecurityContextFromUserName(anyString(), anyString()))
				.willAnswer(invocationOnMock -> new DummySecurityContext(invocationOnMock.getArgument(0), invocationOnMock.getArgument(1)));

		// ok result
		Path mockFilePath = Path.of("src/test/resources/misc/pdf1.pdf");
		FileUtils.deleteQuietly(mockFilePath.toFile());
		Files.createDirectories(mockFilePath.getParent());
		Files.createFile(mockFilePath);
		ProcessTransitionResult dummyTransitionResult = dummyProcessTransitionResult(false,
				Map.of(Constants.OUTPUT_PATH, mockFilePath.toString()));
		given(reportService.startPrintFlow(anyString(), any(), any(SecurityContext.class), anyString(), anyString()))
				.willReturn(dummyTransitionResult);

		AddFileResponse addFileResponse = new AddFileResponse();
		addFileResponse.setId(fileStoreId);
		given(fileStoreClient.addFile(
				Mockito.any(Sso2Authenticator.class),
				anyString(),
				Mockito.eq("print-engine"),
				any(FileToAddMetadata.class),
				any(InputStream.class)))
						.willReturn(addFileResponse);

		PrintJobResponse printJobResponse = PrintJobResponse.builder()
				.setUuid(jobUuid)
				.setStatus(PrintJobStatus.READY)
				.setFileStoreId(fileStoreId)
				.build();
		given(reportService.getJobStatus(anyString(), anyString()))
				.willReturn(printJobResponse);

		PrintEngineInput input = PrintEngineInput.builder().build();
		PrintJob printJob = PrintJob.builder()
				.setJobUuid(jobUuid)
				.setLocale("en")
				.setTenantId(TENANT_ID)
				.setWorkflowCode("a-sample-report")
				.setInput(input)
				.setUserName("admin@example.com")
				.build();

		// #### when
		printQueue.add(printJob, System.currentTimeMillis());
		Thread.sleep(1000);

		// #### then
		ArgumentCaptor<SecurityContext> securityContextCaptor = ArgumentCaptor.forClass(SecurityContext.class);
		Mockito.verify(reportService, Mockito.times(1)).startPrintFlow(
				eq("a-sample-report"), eq(input), securityContextCaptor.capture(), eq("en"), eq(TENANT_ID));
		Assertions.assertThat(securityContextCaptor.getValue()).isNotNull();

		verify(fileStoreClient).addFile(any(), eq(TENANT_ID), eq("print-engine"), any(), any(InputStream.class));

		ArgumentCaptor<PrintJobStatus> captor = ArgumentCaptor.forClass(PrintJobStatus.class);
		Mockito.verify(reportService, Mockito.times(1))
				.updateJobStatus(Mockito.anyString(), captor.capture());
		var allValues = captor.getAllValues();
		assertThat(allValues, CoreMatchers.hasItems(PrintJobStatus.PROGRESS));

		verify(reportService, Mockito.times(1))
				.markAsReady(Mockito.anyString(), Mockito.eq(addFileResponse.getId()));

		System.out.println(">>>>>>>>>>>>>> " + mockFilePath.toFile().getAbsolutePath());
		assertThat("keepTempFile is false and the file is deleted", mockFilePath.toFile().exists(), CoreMatchers.is(false));

		verify(reportService).getJobStatus(TENANT_ID, jobUuid);

		verify(eventProducer).pushEvent(eq(printJobResponse), eq(TENANT_ID), eq(JobEventType.READY));

		// cleanup
		FileUtils.deleteQuietly(mockFilePath.toFile());
	}

	@Test
	@SneakyThrows
	void test_givenProcessFailed_queue_sendError() {

		String jobUuid = "0000";
		String fileStoreId = "__OK__";

		// #### given
		given(sso2Client.createSecurityContextFromUserName(anyString(), anyString()))
				.willAnswer(invocationOnMock -> new DummySecurityContext(invocationOnMock.getArgument(0), invocationOnMock.getArgument(1)));

		given(reportService.startPrintFlow(anyString(), any(), any(SecurityContext.class), anyString(), anyString()))
				.willThrow(new ReportException(ErrEnum.PRINT_FLOW_ERROR, "oooooooops!"));

		PrintJobResponse printJobResponse = PrintJobResponse.builder()
				.setUuid(jobUuid)
				.setStatus(PrintJobStatus.ERROR)
				.setFileStoreId(fileStoreId)
				.build();
		given(reportService.getJobStatus(anyString(), anyString()))
				.willReturn(printJobResponse);

		PrintEngineInput input = PrintEngineInput.builder().build();
		PrintJob printJob = PrintJob.builder()
				.setJobUuid(jobUuid)
				.setLocale("en")
				.setTenantId(TENANT_ID)
				.setWorkflowCode("a-sample-report")
				.setInput(input)
				.setUserName("admin@example.com")
				.build();

		// #### when
		printQueue.add(printJob, System.currentTimeMillis());
		Thread.sleep(1000);

		// #### then
		ArgumentCaptor<SecurityContext> securityContextCaptor = ArgumentCaptor.forClass(SecurityContext.class);
		Mockito.verify(reportService, Mockito.times(1)).startPrintFlow(
				eq("a-sample-report"), eq(input), securityContextCaptor.capture(), eq("en"), eq(TENANT_ID));
		Assertions.assertThat(securityContextCaptor.getValue()).isNotNull();

		verifyNoInteractions(fileStoreClient);

		ArgumentCaptor<PrintJobStatus> captor = ArgumentCaptor.forClass(PrintJobStatus.class);
		Mockito.verify(reportService, Mockito.times(2))
				.updateJobStatus(Mockito.anyString(), captor.capture());
		Assertions.assertThat(captor.getAllValues())
				.containsExactly(PrintJobStatus.PROGRESS, PrintJobStatus.ERROR);

		Mockito.verify(reportService, never()).markAsReady(any(), any());
		verify(reportService).getJobStatus(TENANT_ID, jobUuid);
		verify(eventProducer).pushEvent(eq(printJobResponse), eq(TENANT_ID), eq(JobEventType.ERROR));
	}

	@Test
	@SneakyThrows
	void test_givenFileStoreError_queue_sendError() {

		String jobUuid = "0000";
		String fileStoreId = "__OK__";

		// #### given
		given(sso2Client.createSecurityContextFromUserName(anyString(), anyString()))
				.willAnswer(invocationOnMock -> new DummySecurityContext(invocationOnMock.getArgument(0), invocationOnMock.getArgument(1)));

		// ok result
		Path mockFilePath = Path.of("src/test/resources/misc/pdf2.pdf");
		FileUtils.deleteQuietly(mockFilePath.toFile());
		Files.createDirectories(mockFilePath.getParent());
		Files.createFile(mockFilePath);

		ProcessTransitionResult dummyTransitionResult = dummyProcessTransitionResult(false,
				Map.of(Constants.OUTPUT_PATH, mockFilePath.toString()));
		given(reportService.startPrintFlow(anyString(), any(), any(SecurityContext.class), anyString(), anyString()))
				.willReturn(dummyTransitionResult);

		AddFileResponse addFileResponse = new AddFileResponse();
		addFileResponse.setId(fileStoreId);
		given(fileStoreClient.addFile(
				Mockito.any(Sso2Authenticator.class),
				anyString(),
				Mockito.eq("print-engine"),
				any(FileToAddMetadata.class),
				any(InputStream.class)))
						.willThrow(new IOException("this_is_a_fileStoreClient_exception"));

		PrintJobResponse printJobResponse = PrintJobResponse.builder()
				.setUuid(jobUuid)
				.setStatus(PrintJobStatus.ERROR)
				.setFileStoreId(fileStoreId)
				.build();
		given(reportService.getJobStatus(anyString(), anyString()))
				.willReturn(printJobResponse);

		PrintEngineInput input = PrintEngineInput.builder().build();
		PrintJob printJob = PrintJob.builder()
				.setJobUuid(jobUuid)
				.setLocale("en")
				.setTenantId(TENANT_ID)
				.setWorkflowCode("a-sample-report")
				.setInput(input)
				.setUserName("admin@example.com")
				.build();

		// #### when
		printQueue.add(printJob, System.currentTimeMillis());
		Thread.sleep(1000);

		// #### then
		ArgumentCaptor<SecurityContext> securityContextCaptor = ArgumentCaptor.forClass(SecurityContext.class);
		Mockito.verify(reportService, Mockito.times(1)).startPrintFlow(
				eq("a-sample-report"), eq(input), securityContextCaptor.capture(), eq("en"), eq(TENANT_ID));
		Assertions.assertThat(securityContextCaptor.getValue()).isNotNull();

		verify(fileStoreClient).addFile(any(), eq(TENANT_ID), eq("print-engine"), any(), any(InputStream.class));

		ArgumentCaptor<PrintJobStatus> captor = ArgumentCaptor.forClass(PrintJobStatus.class);
		Mockito.verify(reportService, Mockito.times(2))
				.updateJobStatus(Mockito.anyString(), captor.capture());
		Assertions.assertThat(captor.getAllValues())
				.containsExactly(PrintJobStatus.PROGRESS, PrintJobStatus.ERROR);

		Mockito.verify(reportService, never()).markAsReady(any(), any());

		assertThat("keepTempFile is false and the file is deleted", mockFilePath.toFile().exists(), CoreMatchers.is(true));

		verify(reportService).getJobStatus(TENANT_ID, jobUuid);

		verify(eventProducer).pushEvent(eq(printJobResponse), eq(TENANT_ID), eq(JobEventType.ERROR));

		// cleanup
		FileUtils.deleteQuietly(mockFilePath.toFile());

	}

	private class DummySecurityContext implements SecurityContext {

		private final String tenant;
		private final String userId;

		public DummySecurityContext(String tenant, String userId) {
			this.tenant = tenant;
			this.userId = userId;
		}

		@Override
		public Principal getUserPrincipal() {
			return new User(userId, tenant);
		}

		@Override
		public boolean isUserInRole(String role) {
			return false;
		}

		@Override
		public boolean isSecure() {
			return false;
		}

		@Override
		public String getAuthenticationScheme() {
			return null;
		}
	}

	private ProcessTransitionResult dummyProcessTransitionResult(boolean failed, Map<String, Object> globalVars) {
		TransitionLog mockTransitionLog = Mockito.mock(TransitionLog.class);
		given(mockTransitionLog.isFailed()).willReturn(failed);
		ProcessTransitionResult dummyTransitionResult = ProcessTransitionResult.builder()
				.processId(-1L)
				.currentNode("")
				.lastTransitionLog(mockTransitionLog)
				.globalVars(Optional.ofNullable(globalVars)
						.map(g -> (Map<String, Object>) new HashMap<>(g)).orElse(new HashMap<>()))
				.messages(Collections.emptyList())
				.build();
		return dummyTransitionResult;
	}
}
