drop table if exists tmp_parties;


create table tmp_parties
(
    id         bigserial not null,
    process_id bigint    not null,
    first_name varchar
);
