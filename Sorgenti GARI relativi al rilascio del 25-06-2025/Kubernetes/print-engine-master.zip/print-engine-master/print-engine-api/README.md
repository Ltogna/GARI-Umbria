# ✨ Print-engine ✨ #

[TOC]

---

This project represents the hosting software which uses :

- the abaco **workflow engine** library to develop a workflow.
- **print-engine-sdk** is a module that contains all the needed ( procedures , methods, utilities..) to create a print workflow.
- **print-engine-api** module that runs a particular bundle to generate Jasper reports for printing. </br>
  It's possible to **print** the report generated as **PDF** , **XLS** , **CSV** or **DOCX**.

---

## 1. print workflow as a bundle

in the following example, we will provide all the details on how to develop a print workflow as a bundle.

---

### 1.1 bundle structure

The application module id is  `print-engine` and the changeset domain is `print-flow`:

es:

```
.
└── bundle-folder
    ├── bundles.config.json
    └── print-engine
        └── <client-id>-<nnnn>
            └── print-flow
                ├── sample-csv-1.1.0.jar
                └── sample-spreadsheet-1.1.0.jar

```

To develop a print-workflow, the bundle has to contain :

- **workflow definition**
- **Procedures**
- **Migrations**
- **JRXML Definition** ( **NOT MANDATORY** just if you need it )

#### 1.1.1 workflow definition :

it's a json file, named `abaco-workflow.json` which describes the workflow.

![](docs/workflow.png)

**Workflow variables** must be defined as follows:
```json
"variables": [
    {
      "name": "input",
      "fl_persist": 1,
      "is_list": 0,
      "type": "com.abacogroup.printengine.sdk.model.PrintEngineInput"
    }
  ]
```

**The workflow version** is a variable that corresponds to the project version. </br>
It has to be declared in abaco-workflow.json in this way :

```json 
  "version": "${project.version}"
 ``` 

Then, we have to add the resources in the POM to get the **"${project.version}"** value substituted when we build our bundle.

```xml 
<build>
    <resources>
      <resource>
        <directory>src/main/resources</directory>
        <filtering>true</filtering>
        <includes>
          <include>abaco-workflow.json</include>
        </includes>
      </resource>
      <resource>
        <!-- This is needed or unfiltered resources will not be copied over -->
        <directory>src/main/resources</directory>
        <filtering>false</filtering>
        <excludes>
          <exclude>abaco-workflow.json</exclude>
        </excludes>
      </resource>
    </resources>
</build>
 ``` 

---

A basic print workflow is made of these nodes:

- start node
- load data node
- run-report node
- end node

> - The flow is always to firstly create the H2 db then, to | **load data into db** | and finally to print the report.
> - To create an H2 database, it is mandatory to append the defined **H2Procedure** in the workflow.
> - It's up to the developer to add/specify all the required procedures to load the required data for the report.

---

**input Data Validation** </br>
it's possible to validate the input parameters passed by the user and to convert them into a valid object (DTO).</br>
To do that, just create a class that extends **AbstractInputParamProcedure** also pass the concrete DTO.
then, all what you need is to implement the method **convertDto**, also, you can overwrite the method **getParamDto** (to use a custom parameter name)

```java
public class ValidateParamProcedure extends AbstractInputParamProcedure<ReportParamDto> {

	public static final String PARAM_NAME = "myCustomObject";

	@Override
	public ReportParamDto convertDto(ObjectMapper mapper, Map<String, Object> params) {
		return mapper.convertValue(params, ReportParamDto.class);
	}

	@Override
	protected String getParamDto() {
		return PARAM_NAME;
	}
}
```

---

- For now, the possible formats of printing a report are : PDF , CSV , DOCX and XLS.
    - **IF** the developer needs to use another format to print reports for example TXT format:
      > - First, he has to create a single class **CreateJasperTxt** which extends **AbstractJRProcedure** under **print-engine-sdk**
          and then he just need to provide destFileName to write a file .

```java
public class CreateTxt extends AbstractFileProcedure {
	@Override
	protected String getExtension() {
		return "txt";
	}

	@Override
	protected void writeFile(ProcessData processData, ProcedureEnvironment env, String destFileName, PrintEngineInput input) {
		try {

			HashMap<String, Object> params = new HashMap<>(Map.of(
					PROCESS_ID, processData.getProcessId()
			));
			params.putAll(input.getParams());

			ObjectMapper mapper = getObjectMapper(env);
			StringBuffer content = new StringBuffer("this is a demo procedure:");
			content.append("\ninputParams:\n");
			content.append(mapper.writerWithDefaultPrettyPrinter().writeValueAsString(params));

			FileUtils.write(new File(destFileName), content, StandardCharsets.UTF_8);
		} catch (Exception ex) {
			throw new RuntimeException("", ex);
		}
	}

	private static ObjectMapper getObjectMapper(ProcedureEnvironment env) {
		return (ObjectMapper) env.getProperty(ProcEnvConstants.PROPERTY_OBJECT_MAPPER).orElseThrow();
	}
}
```

---

#### 1.1.2 Procedures :

in this print bundle example, `load-data` node contains 2 procedures :

- H2Procedure : this procedure is already defined .It has to be used for creating a custom H2 database to store the data into it.
- LoadData :  this procedure has to be implemented by the developer to load the data required for the print.

```yml
{
  "name": "load-data",
  "type": "proc",
  "procedures": [
    {
      "class_name": "com.abacogroup.printengine.sdk.proc.H2Procedure"
    },
    {
      "class_name": "your_package_name.LoadData"
    }
  ]
}
```

- `run-report` node , by default executes the **standard** print procedure `CreateJasperReports` to print PDF reports. Also, it includes 2 parameters
    - mainTemplate is the name of the main jrxml definition file
    - path is the name of the folder which contains all the jrxml files ,images..(Japser report can comprise sub reports)

```yml
        {
  "class_name": "com.abacogroup.printengine.sdk.proc.CreateJasperReports",
  "param": {
    "mainTemplate": "main",
    "path": "test1"
  }
}
```

#### 1.1.2.1 Procedures environment :

- jdbi:
    - helper database jdbi. _not recommended_ (use h2 instead)  
      `env.getJdbi(com.abacogroup.printengine.sdk.ProcEnvConstants.JDBI_HELPER);`
- client: `env.getJerseyClient();`
- properties:
    - workDir: path of temporary folder defined by `print-engine-api`. **DO NOT DELETE**  
      `env.<String>getProperty(ProcEnvConstants.PROPERTY_WORK_DIR);`
    - sourceDir: path of folder containing all sources from bundle jar. **DO NOT DELETE**  
      `env.<String>getProperty(ProcEnvConstants.PROPERTY_SOURCE_DIR);`
    - fileName: path of expected output file.  
      `env.<String>getProperty(ProcEnvConstants.PROPERTY_FILE_NAME);`
    - helperConnection: connection to helper database. _not recommended_ (use h2 instead)  
      `env.<java.sql.Connection>getProperty(ProcEnvConstants.PROPERTY_HELPER_CONNECTION);`
    - objectMapper: object mapper from `print-engine-api`  
      `env.<ObjectMapper>getProperty(ProcEnvConstants.PROPERTY_OBJECT_MAPPER);`
    - profile: profile in use by `print-engine-api`. see [1.3 bundle profiles](#13-bundle-profiles)  
      `env.<String>getProperty(ProcEnvConstants.PROPERTY_PROFILE);`
    - properties from `applications-{profile}.properties`: all properties, resolved using profile, are accessible as properties of the environment.  
      `env.<String>getProperty("my-property");`

#### 1.1.2.2 Procedures process data :

- global vars:
    - from `H2Procedure`:
        - default_report_connection: connection to h2 database.  
          `processData.<java.sql.Connection>getGlobalVar(com.abacogroup.printengine.sdk.Constants.DEFAULT_REPORT_CONNECTION);`
        - jdbi_h2_conn: h2 database jdbi.  
          `processData.<Jdbi>getGlobalVar(H2Procedure.JDBI_H2_CONNECTION);`

#### 1.1.3 Migrations :

The bundle needs a h2 database, in order to persist the required data for creating a report.
The developer have to store this data into :

- the custom `H2 database` by using the H2Procedure.
  The bundle contains a file `h2.xml` with the relative `com.abacogroup.printengine.sdk.proc.H2Procedure`, the related migrations will be executed into a
  temporary h2 database

#### 1.1.4 JRXML Definition :</br>

If we need to use jasper Reports for print, ( for example in case we want to print a PDF) </br>
the bundle has to include under a specific path (which is indicated in the wk definition) a folder that contains all the things needed ( JRXML definitions +
images .. ) to generate the jasper report.
( in this example : the path is test1 )

---

### 1.2 build the bundle ( as JAR )

1. Run `mvn clean compile package`
   Once this JAR bundle is ready, **print-engine-api** module will execute this bundle to generate
   the jasper reports that correspond to this bundle.

---

### 1.3 bundle profiles

A bundle can have several **profile property files** in the form of application-{profile}.properties.</br>
the profile property file should contain </br>

- Properties :  that a bundle should need during his process.(Example: - Url, password , username to reach an external endpoint(load the data)) </br>
- variables : var= ${my-property} </br>
  </br>

In the print-engine-api, we have to define this three config properties in the config.yml :

- initBaseTempDir : main path of the property profile files .
- profile : the current profile to use [dev , prod , test.. ]
- externalPropertiesDir : main path of all the external property profile files.

```yaml
printEngineConfiguration:
  initBaseTempDir: /tmp/AAA_pe
  profile: dev
  externalPropertiesDir: bundles-config/
```

> **Example** : [ **bundleName** :  sample-print / **tenant** :  master ]

Each bundle will have his particular paths where to store his profile property files. </br>

For this example :

- The principal path of properties is made up of : **initBaseTempDir / tenantName / workflowCode**  </br>

  > /tmp/AAA_pe/master/sample-print/

- The possible paths of the external properties are :

  > - /bundles-config/
  > - /bundles-config/master/
  > - /bundles-config/master/sample-print/

---

### 1.4 Testing

It's possible to test a report before deploying the bundle into the print-engine microservice
see this example under sample-report-h2: `anomaly.core.procedure.CreateJasperReportsAnomaliesTest.full_integration_test_pdf`

```java
@Test
void full_integration_test_pdf(){
		File expectedPdfFile=new File("target/sample-report.pdf");

		ProcessTransitionResult transitionResult=PrintFlowTestSupport.buildFlow(WORKFLOW_CODE,TENANT_ID)
		.withDbConnection("jdbc:postgresql://localhost:35433/print_engine_test","postgres","postgres")
		.withExpectedFile(expectedPdfFile)
		.putInputParam("FROM_USER","user_foo")
		.setUp()
		.execute();
		.....
		}
```

- In your test, you have to provide a DB connection to load the data like in the example below.

---

## 2 How to consume a bundle

### 2.1 APIS

[openapi.yaml](docs/openapi.yaml)

---

- ##### To print a report of a particular type :
    * **Parameters** :
        - `{printTypeCode}` :  path parameter
        - `bucket` : queryParam ( **not mandatory** / defaults to print-engine)
        - `dest` : queryParam ( **not mandatory** / defaults to print-type-name)

The payload is a json serialization of a `Map<String, Object>` that contains the wanted parameters

    * **API** : <br/>
      **`POST`** [http://localhost:8080/print-engine/master/public/v1/{printTypeCode}](#post-print) <br/>

    * **Response** :  <br/>
      this endpoint will return the **UUID** of the print job as response

```json
{
  "uuid": "44e128a5-ac7a-4c9a-be4c-224b6bf81b20"
} 
```

---

- ##### To check the status of the print job
    * **Parameters** :
        - UUID of the print job : path parameter

    * **API** : <br/>
      **`GET`** [http://localhost:8080/print-engine/master/public/v1/jobs/{UUID}](#get-print-job-status) <br/>

    * **Response** :  <br/>
      this endpoint will return the status of the print job and other details.

```json
      {
  "uuid": "44e128a5-ac7a-4c9a-be4c-224b6bf81b20",
  "status": "READY",
  "fileStoreId": 5454541,
  "bucket": "print-engine",
  "dest": "sample-report"
} 
```

**Statuses** :

- **ACKNOWLGED** : the print job exists, and it is waiting to be processed.
- **PROGRESS** : the print job is in process.
- **ERROR** : the print job has an error during its process.
- **READY** : the print job is finished and the report is ready for print.

---

- ##### retrieve and download a report from the store using the file-store Microservice :
    * **Parameters** :
        - bucket-name : path parameter (the container where you stored your file)
        - file-id : path parameter
    * **API** : <br/>
      **`GET`** [http://localhost:10599/file-store/master/public/v1/files/{bucket-name}/{file-id}](#get-file) <br/>

---

### 2.2 file-store

File store is an external microservice. It allows to store and to retrieve of files organized in buckets.

- **Bucket** : it's just like a namespace/container where you store your files, also it has to be unique.

- The files may be stored **temporarily** and **permanently**.
  In our case :

    - If the bucket name is not passed as a query parameter so the default bucket will be used , the file will be saved temporarily (the duration depends upon
      the file store service).
    - Else, if you specify a bucket name, the file will be stored permanently .

In this project, we are using file-store-client to communicate with the file-store-server.

---

### 2.3 Rabbit Topic

To publish **report completed** events, we are using an embedded queue for messaging.
So, when the print job is done and the report file is stored correctly,
the print-engine-event-producer will send a message through an exchange named `print-engine-exchange`  to the corresponding topic of this print job in Rabbit MQ
. </br>

The topic name is composed of : **print-engine-job.[destination].[job-status]**

- **destination** is passed as query param (else it uses the default value)
- **job status** : could be [ error / ready ] relative to the response of the print job.

---

### 3 How to start the print-engine application

1. Run `mvn clean compile` to build sample report module
1. Run `mvn clean compile` to build your application
1. Start application with :

```shell
 java -jar target/sample-report-1.0.0-SNAPSHOT.jar server config.yml
 ```

4. To check that your application is running enter url `http://localhost:8080`

***
