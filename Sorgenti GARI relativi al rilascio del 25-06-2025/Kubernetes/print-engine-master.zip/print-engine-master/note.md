# TAG A NEW PRINT-ENGINE VERSION

mvn versions:set -DnewVersion=X.X.X

mvn versions:commit