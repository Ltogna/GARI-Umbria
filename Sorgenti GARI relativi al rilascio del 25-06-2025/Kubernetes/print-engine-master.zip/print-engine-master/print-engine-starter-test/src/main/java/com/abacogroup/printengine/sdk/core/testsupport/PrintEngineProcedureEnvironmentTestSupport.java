package com.abacogroup.printengine.sdk.core.testsupport;

import java.sql.Connection;
import java.util.HashMap;
import java.util.Map;

import org.jdbi.v3.core.Jdbi;

import com.abacogroup.printengine.sdk.ProcEnvConstants;
import com.abacogroup.workflow.sdk.beans.testsupport.ProcedureEnvironmentTestSupport;
import com.fasterxml.jackson.databind.ObjectMapper;

import jakarta.ws.rs.client.Client;

public class PrintEngineProcedureEnvironmentTestSupport extends ProcedureEnvironmentTestSupport {

	@Deprecated(forRemoval = true)
	public PrintEngineProcedureEnvironmentTestSupport() {
		this(null, null, null, null, new ObjectMapper(),
				"target/test", "target/test/sources", "target/test/out.pdf", null);
	}

	public PrintEngineProcedureEnvironmentTestSupport(String workDir, String sourceDir, String fileName) {
		this(null, null, null, null, new ObjectMapper(),
				workDir, sourceDir, fileName, null);
	}

	public PrintEngineProcedureEnvironmentTestSupport(Jdbi jdbiHelper, Connection helperConnection,
			String workDir, String sourceDir, String fileName) {
		this(null, jdbiHelper, null, helperConnection, new ObjectMapper(),
				workDir, sourceDir, fileName, null);
	}

	public PrintEngineProcedureEnvironmentTestSupport(Client client, Jdbi jdbiHelper, Jdbi jdbi, Connection helperConnection,
			ObjectMapper objectMapper, String workDir, String sourceDir, String fileName) {
		this(client, jdbiHelper, jdbi, helperConnection, objectMapper, workDir, sourceDir, fileName, null);
	}

	public PrintEngineProcedureEnvironmentTestSupport(Client client, Jdbi jdbiHelper, Jdbi jdbi, Connection helperConnection,
			ObjectMapper objectMapper, String workDir, String sourceDir, String fileName, String envId) {
		super(
				buildJdbiMap(jdbiHelper, jdbi),
				client,
				buildProperties(helperConnection, objectMapper, workDir, sourceDir, fileName), envId);
	}

	@SuppressWarnings("deprecation")
	private static Map<String, Jdbi> buildJdbiMap(Jdbi jdbiHelper, Jdbi jdbi) {
		Map<String, Jdbi> props = new HashMap<>();

		props.put(ProcEnvConstants.JDBI_HELPER, jdbiHelper);
		props.put(ProcEnvConstants.JDBI_PRINT_ENGINE, jdbi);

		return props;

	}

	private static Map<String, Object> buildProperties(Connection helperConnection,
			ObjectMapper objectMapper, String workDir, String sourceDir, String fileName) {
		Map<String, Object> props = new HashMap<>();

		props.put(ProcEnvConstants.PROPERTY_WORK_DIR, workDir);
		props.put(ProcEnvConstants.PROPERTY_SOURCE_DIR, sourceDir);
		props.put(ProcEnvConstants.PROPERTY_FILE_NAME, fileName);

		props.put(ProcEnvConstants.PROPERTY_HELPER_CONNECTION, helperConnection);
		props.put(ProcEnvConstants.PROPERTY_OBJECT_MAPPER, objectMapper);

		return props;
	}
}
