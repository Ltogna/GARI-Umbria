package com.abacogroup.printengine.sdk.core.testsupport;

import java.io.File;
import java.nio.file.Path;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.io.FileUtils;
import org.jdbi.v3.core.Jdbi;
import org.jdbi.v3.sqlobject.SqlObjectPlugin;
import org.junit.jupiter.api.Assertions;

import com.abacogroup.jdbi.PgJdbiPlugin;
import com.abacogroup.printengine.sdk.model.PrintEngineInput;
import com.abacogroup.workflow.sdk.auth.AuthContext;
import com.abacogroup.workflow.sdk.beans.testsupport.AuthContextTestSupport;
import com.abacogroup.workflow.sdk.proc.ProcedureEnvironment;
import com.abacogroup.workflow.server.model.CreateProcessParams;
import com.abacogroup.workflow.server.model.ProcessTransitionResult;
import com.abacogroup.workflow.server.services.WorkflowService;
import com.abacogroup.workflow.server.services.testsupport.ProcessServiceTestSupport;
import com.fasterxml.jackson.databind.ObjectMapper;

import jakarta.ws.rs.client.Client;
import liquibase.Liquibase;
import liquibase.database.jvm.JdbcConnection;
import liquibase.exception.LiquibaseException;
import liquibase.resource.ClassLoaderResourceAccessor;
import liquibase.resource.DirectoryResourceAccessor;
import lombok.SneakyThrows;

public class PrintFlowTestSupport implements PrintFlowTestStepA, PrintFlowTestStepB {

	private static final String DB_MIGRATIONS_PATH = "migrations-workflow.xml";

	private ProcessServiceTestSupport<ProcedureEnvironment> processService;

	private AuthContext authContext;
	private String scope;

	private final String wfCode;
	private final String tenantId;

	private File workDir;
	private File expectedFile;
	private File sourceDir;

	private String connectionUrl;
	private String connectionUsr;
	private String connectionPsw;

	private String helperConnectionUrl;
	private String helperConnectionUsr;
	private String helperConnectionPsw;

	private Jdbi jdbi;
	private Jdbi jdbiHelper;
	private Client client;
	private ObjectMapper objectMapper;

	private final Map<String, Object> inputParams;
	private CreateProcessParams params;
	private String envId;

	@SneakyThrows()
	private PrintFlowTestSupport(String wfCode, String tenantId) {
		this.wfCode = wfCode;
		this.tenantId = tenantId;

		this.authContext = new AuthContextTestSupport();
		this.scope = null;

		this.workDir = new File("target/test").getAbsoluteFile();
		this.sourceDir = null;
		this.expectedFile = new File(workDir, "out.pdf");

		this.connectionUrl = "jdbc:postgresql://localhost:5432/test";
		this.connectionUsr = "test";
		this.connectionPsw = "password";

		this.helperConnectionUrl = "jdbc:h2:mem:test;DB_CLOSE_DELAY=-1;IGNORECASE=TRUE;MODE=Postgresql";
		this.helperConnectionUsr = null;
		this.helperConnectionPsw = null;

		this.jdbi = null;
		this.client = null;
		this.objectMapper = new ObjectMapper();

		this.inputParams = new HashMap<>();
	}

	public static PrintFlowTestStepA buildFlow(String wfCode, String tenantId) {
		return new PrintFlowTestSupport(wfCode, tenantId);
	}

	@Override
	public PrintFlowTestStepA withAuthContext(AuthContext authContext) {
		this.authContext = authContext;
		return this;
	}

	@Override
	public PrintFlowTestStepA withScope(String scope) {
		this.scope = scope;
		return this;
	}

	@Override
	public PrintFlowTestStepA withEnv(String envId) {
		this.envId = envId;
		return this;
	}

	@Override
	public PrintFlowTestStepA withClient(Client client) {
		this.client = client;
		return this;
	}

	@Override
	public PrintFlowTestStepA withObjectMapper(ObjectMapper objectMapper) {
		this.objectMapper = objectMapper;
		return this;
	}

	@Override
	public PrintFlowTestStepA withWorkDir(File workDir) {
		this.workDir = workDir;
		return this;
	}

	@Override
	public PrintFlowTestStepA withExpectedFile(File expectedFile) {
		this.expectedFile = expectedFile;
		return this;
	}

	@Override
	public PrintFlowTestStepA withDbConnection(String url, String user, String password) {
		this.connectionUrl = url;
		this.connectionUsr = user;
		this.connectionPsw = password;
		return this;
	}

	@Override
	public PrintFlowTestStepA withDbHelperConnection(String url, String user, String password) {
		this.helperConnectionUrl = url;
		this.helperConnectionUsr = user;
		this.helperConnectionPsw = password;
		return this;
	}

	@Override
	public PrintFlowTestStepA putInputParam(String key, Object value) {
		this.inputParams.put(key, value);
		return this;
	}

	@Override
	public PrintFlowTestStepA putAllInputParams(Map<String, Object> inputParams) {
		this.inputParams.putAll(inputParams);
		return this;
	}

	@SneakyThrows
	@Override
	public PrintFlowTestStepB setUp() {
		migrateWorkflow(getConnection());
		Connection connection = getConnection();
		jdbi = Jdbi.create(connection);
		jdbi.installPlugin(new PgJdbiPlugin());
		jdbi.installPlugin(new SqlObjectPlugin());

		migrateHelper(getHelperConnection());
		Connection helperConnection = getHelperConnection();
		jdbiHelper = Jdbi.create(helperConnection);
		jdbiHelper.installPlugin(new PgJdbiPlugin());
		jdbiHelper.installPlugin(new SqlObjectPlugin());

		sourceDir = Utils.createSourceDirAndSetupJasper(workDir, tenantId, wfCode);

		WorkflowService workflowService = new WorkflowService(jdbi);
		workflowService.addOrUpdateWorkflow(tenantId, Path.of(sourceDir.getAbsolutePath(), "abaco-workflow.json").toFile());

		processService = new ProcessServiceTestSupport<>(jdbi, processData -> new PrintEngineProcedureEnvironmentTestSupport(
				client, jdbiHelper, jdbi, helperConnection, objectMapper,
				workDir.getAbsolutePath(),
				sourceDir.getAbsolutePath(),
				expectedFile.getAbsolutePath(),
				envId));

		FileUtils.deleteQuietly(expectedFile);
		Assertions.assertFalse(expectedFile.exists());

		PrintEngineInput input = PrintEngineInput.builder()
				.setParams(inputParams)
				.build();

		Map<String, Object> globalVars = new HashMap<>();
		globalVars.put(PrintEngineInput.PARAM_NAME, input);

		params = CreateProcessParams.builder()
				.scope(scope)
				.authContext(authContext)
				.globalVars(globalVars)
				.tenantId(tenantId)
				.workflowCode(wfCode)
				.build();

		return this;
	}

	@Override
	public CreateProcessParams getProcessParams() {
		return params;
	}

	@Override
	public ProcessServiceTestSupport<ProcedureEnvironment> getProcessService() {
		return processService;
	}

	@SneakyThrows
	@Override
	public ProcessTransitionResult execute() {
		return processService.createProcess(params);
	}

	@SuppressWarnings("deprecation")
	private void migrateWorkflow(Connection connection) throws LiquibaseException, SQLException {
		try (Liquibase migrator = new Liquibase(DB_MIGRATIONS_PATH, new ClassLoaderResourceAccessor(), new JdbcConnection(connection))) {
			migrator.update("");
		}
	}

	@SuppressWarnings("deprecation")
	private void migrateHelper(Connection connection) throws Exception {
		try (var accessor = new DirectoryResourceAccessor(new File("src/main/resources").getAbsoluteFile())) {
			File changelogFile = new File("src/main/resources/migrations.xml");
			if (changelogFile.exists()) {
				try (Liquibase migrator = new Liquibase(changelogFile.getName(), accessor, new JdbcConnection(connection))) {
					migrator.update("");
				}
			}
		} catch (Exception e) {
			throw e;
		}
	}

	private Connection getConnection() throws SQLException {
		return DriverManager.getConnection(connectionUrl, connectionUsr, connectionPsw);
	}

	private Connection getHelperConnection() throws SQLException {
		return DriverManager.getConnection(helperConnectionUrl, helperConnectionUsr, helperConnectionPsw);
	}

}
