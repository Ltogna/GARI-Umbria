package com.abacogroup.printengine.sdk.core.testsupport;

import java.io.File;
import java.util.Map;

import com.abacogroup.workflow.sdk.auth.AuthContext;
import com.fasterxml.jackson.databind.ObjectMapper;

import jakarta.ws.rs.client.Client;

public interface PrintFlowTestStepA {
	PrintFlowTestStepA withAuthContext(AuthContext authContext);

	PrintFlowTestStepA withScope(String scope);

	@Deprecated(forRemoval = true)
	default PrintFlowTestStepA withProfile(String profile) {
		return withEnv(profile);
	}

	PrintFlowTestStepA withEnv(String env);

	PrintFlowTestStepA withClient(Client client);

	PrintFlowTestStepA withObjectMapper(ObjectMapper objectMapper);

	PrintFlowTestStepA withWorkDir(File workDir);

	PrintFlowTestStepA withExpectedFile(File expectedPdfFile);

	PrintFlowTestStepA withDbConnection(String url, String user, String password);

	PrintFlowTestStepA withDbHelperConnection(String url, String user, String password);

	PrintFlowTestStepA putInputParam(String key, Object value);

	PrintFlowTestStepA putAllInputParams(Map<String, Object> inputParams);

	PrintFlowTestStepB setUp();
}
