package com.abacogroup.printengine.sdk.core.testsupport;

import static org.junit.jupiter.api.Assertions.fail;

import com.abacogroup.printengine.sdk.PrintEngineUtils;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import net.sf.jasperreports.engine.JasperCompileManager;
import org.apache.commons.io.FileUtils;

public class Utils {

	public static File createSourceDirAndSetupJasper(File workDir, String tenantId, String wfCode) throws IOException {
		FileUtils.deleteQuietly(workDir);
		File reportDir = PrintEngineUtils.getSourceDir(workDir.getAbsolutePath(), tenantId, wfCode, "xxxxxxxxxxxxx_hash_xxxxxxxxxxxxx").toFile();
		// new File("src/main/resources")
		FileUtils.copyDirectory(new File("target/classes").getAbsoluteFile(), reportDir);

		try (var paths = Files.walk(reportDir.toPath())) {
			paths.filter(x -> x.getFileName().toString().toLowerCase().endsWith(".jrxml"))
					.forEach(jrxml -> {
						try {
							JasperCompileManager.compileReportToFile(jrxml.toFile().getAbsolutePath());
						} catch (Exception e) {
							fail(e);
						}
					});
		}
		
		return reportDir;
	}
}
