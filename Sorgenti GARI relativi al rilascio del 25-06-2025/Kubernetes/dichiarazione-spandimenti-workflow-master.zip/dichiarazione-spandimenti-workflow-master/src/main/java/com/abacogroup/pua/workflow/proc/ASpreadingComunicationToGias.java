package com.abacogroup.pua.workflow.proc;

import java.util.Optional;
import com.abacogroup.applicationworkflowsdk.environment.IAgriProcedureEnvironment;
import com.abacogroup.applicationworkflowsdk.v2.procedures.ApplicationProcedure;
import com.abacogroup.workflow.sdk.beans.ProcessData;
import com.abacogroup.workflow.sdk.beans.WorkflowMessage;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.ws.rs.client.Client;
import jakarta.ws.rs.client.WebTarget;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import lombok.extern.slf4j.Slf4j;

/**
 * 
 * @author Emanuele Crocilla
 *
 */
@Slf4j
public abstract class ASpreadingComunicationToGias extends ApplicationProcedure {
	
	protected static final String QdC_NON_AGGIORNATO = "Non è stato possibile aggiornare il Quaderno di Campagna";
	 
	protected static final String PLEASE_UPD_QdC_MANUALLY = ", si prega di aggiornare manualmente.";

	protected static final String QdC_NON_AGGIORNATO_ERR_CODE = "QdC_NON_AGGIORNATO_ERR_CODE";
    
    protected void handleWriting(ProcessData processData, IAgriProcedureEnvironment env) throws Exception {
    	
    	log.debug("[dichiarazione-spandimenti-workflow] "
    			+ "Check if the procedure SendSpreadingComunicationToGias has to be executed " 
    			+ "considering the value of 'call.organic.fert.gias' environment property");
    	
    	boolean callOrganicFertGias = mustCallOrganicFertGias(env);
    	
    	log.debug("[dichiarazione-spandimenti-workflow] callOrganicFertGias value: {}", callOrganicFertGias);
    	
    	if (callOrganicFertGias) {
    		
    		log.debug("[dichiarazione-spandimenti-workflow] SendSpreadingComunicationToGias started");
            String url = env.getProperty("puaAppFormsUrl").orElseThrow().toString();
            log.debug("[dichiarazione-spandimenti-workflow] Using puaAppFormsUrl: {}", url);

            Client client = env.getJerseyClient().orElseThrow();
            log.debug("[dichiarazione-spandimenti-workflow] Client obtained successfully");
            
            log.debug("[dichiarazione-spandimenti-workflow] Building WebTarget with applicationId: {} and partyId: {}", 
                    getApplicationsWorkflowParams().getApplicationId(), 
                    getApplicationsWorkflowParams().getPartyId());
            
            WebTarget target = processData.getAuthContext()
                    .getAuthenticatedWebTarget(client, url)
                    .path("/master/v1/applications/")
                    .path(getApplicationsWorkflowParams().getApplicationId().toString())
                    .path("fert-spreading-declarations")
//                    .path(getApplicationsWorkflowParams().getPartyId().toString())
                    .path("import-organic-fert-gias");

            log.debug("[dichiarazione-spandimenti-workflow] WebTarget prepared: {}", target.getUri());
           
            try (Response response = target.request(MediaType.APPLICATION_JSON).get()) {
                
            	int status = response.getStatus();
                log.debug("[dichiarazione-spandimenti-workflow] Response status: {}", status);
                
            	if (status < 200 || status > 299) {
					String errorBody = response.readEntity(String.class);
					try {
						ObjectMapper objectMapper = new ObjectMapper();
						JsonNode errorJson = objectMapper.readTree(errorBody);

						if (errorJson.hasNonNull("errorCode") && errorJson.hasNonNull("message")) {
							String errorCode = errorJson.get("errorCode").asText();
							String message = errorJson.get("message").asText();

							processData.getWorkflowMessages().add(new WorkflowMessage(
									errorCode,
									message,
									WorkflowMessage.Type.ERROR
							));
						} else {
							throw new IllegalStateException("[dichiarazione-spandimenti-workflow] "
									+ "Unable to write data in Quaderno di Campagna. "
									+ "Got a bad response; status is: " + status);
						}
					} catch (Exception parseEx) {
						log.error("[dichiarazione-spandimenti-workflow] Failed to parse error response JSON", parseEx);
						throw new IllegalStateException("[dichiarazione-spandimenti-workflow] "
								+ "Unable to write data in Quaderno di Campagna. "
								+ "Got a bad response; status is: " + status);
					}
                }
                log.debug("[dichiarazione-spandimenti-workflow] Successfully wrote data to Quaderno di Campagna");
            }
    	} else {
    	    log.debug("[dichiarazione-spandimenti-workflow] SendSpreadingComunicationToGias skipped due to configuration");
    	}
    }

	protected void handleDeletion(ProcessData processData, IAgriProcedureEnvironment env) throws Exception {

    	log.debug("[dichiarazione-spandimenti-workflow] "
    			+ "Check if the procedure SendSpreadingComunicationToGias has to be executed " 
    			+ "considering the value of 'call.organic.fert.gias' environment property");
    	
    	boolean callOrganicFertGias = mustCallOrganicFertGias(env);
    	
    	log.debug("[dichiarazione-spandimenti-workflow] callOrganicFertGias value for deletion: {}", callOrganicFertGias);
    	
    	if (callOrganicFertGias) {

            log.debug("[dichiarazione-spandimenti-workflow] SendSpreadingDeletionComunicationToGias started");
            String url = env.getProperty("puaAppFormsUrl").orElseThrow().toString();
            log.debug("[dichiarazione-spandimenti-workflow] Using puaAppFormsUrl for deletion: {}", url);

            Client client = env.getJerseyClient().orElseThrow();
            log.debug("[dichiarazione-spandimenti-workflow] Client for deletion obtained successfully");
            
            log.debug("[dichiarazione-spandimenti-workflow] Building WebTarget for deletion with applicationId: {} and partyId: {}", 
                    getApplicationsWorkflowParams().getApplicationId(), 
                    getApplicationsWorkflowParams().getPartyId());
            
            WebTarget target = processData.getAuthContext()
                    .getAuthenticatedWebTarget(client, url)
                    .path("/master/v1/applications/")
                    .path(getApplicationsWorkflowParams().getApplicationId().toString())
                    .path("fert-spreading-declarations")
//                    .path(getApplicationsWorkflowParams().getPartyId().toString())
                    .path("remove-organic-fert-gias");

            log.debug("[dichiarazione-spandimenti-workflow] Deletion WebTarget prepared: {}", target.getUri());
            
            try (Response response = target.request(MediaType.APPLICATION_JSON).get()) {
               
            	int status = response.getStatus();
                log.debug("[dichiarazione-spandimenti-workflow] Deletion response status: {}", status);
                 
                if (status < 200 || status > 299) {
                	log.error("[dichiarazione-spandimenti-workflow] Bad deletion response status: {}", status);
                    throw new IllegalStateException("[dichiarazione-spandimenti-workflow] "
                    		+ "Unable to delete all elements in Quaderno di Campagna. "
                    		+ "Got a bad response; status is: " + status);
                }
                
                log.debug("[dichiarazione-spandimenti-workflow] Successfully deleted data from Quaderno di Campagna");
            }
    	} else {
    	    log.debug("[dichiarazione-spandimenti-workflow] SendSpreadingDeletionComunicationToGias skipped due to configuration");
    	}
    }
	
	private boolean mustCallOrganicFertGias(IAgriProcedureEnvironment env) throws Exception {
    	
    	log.debug("[dichiarazione-spandimenti-workflow] Attempting to retrieve 'call.organic.fert.gias' property");
    	
    	// retrieve the value of env property "call.organic.fert.gias" 
    	try {
    		Optional<String> prop = env.getProperty("call.organic.fert.gias");
    		String propVal = prop.orElse("false");
    		log.debug("[dichiarazione-spandimenti-workflow] Vaue of 'call.organic.fert.gias' property: '{}'", propVal);
        	return "true".equalsIgnoreCase(propVal.trim());
		} 
    	catch (Exception e) {
			String systemErrorMsg = "[dichiarazione-spandimenti-workflow] "
					+ "Unable to fetch value of the environment property 'call.organic.fert.gias', " 
					+ "so the procedure SendSpreadingComunicationToGias will not be executed";
			
			log.error(systemErrorMsg, e);
			
			throw new Exception(systemErrorMsg, e);
		}
	}
}
