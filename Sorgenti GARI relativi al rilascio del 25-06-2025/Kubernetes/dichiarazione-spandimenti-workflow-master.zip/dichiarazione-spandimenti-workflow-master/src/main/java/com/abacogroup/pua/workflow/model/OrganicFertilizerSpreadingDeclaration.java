package com.abacogroup.pua.workflow.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.OffsetDateTime;
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class OrganicFertilizerSpreadingDeclaration {
	private Long pkid;
	private Long applicationId;
	private Long id;
	private Long partyId;
	private String expectedDate;
	private String livestockEffluents;
	private String livestockEffluentsCodeUom;
	private String livestockEffluentsDescriptionUom;
	private BigDecimal livestockEffluentsQty;
	private String cropPlanVersion;
	private String sectorCode;
	private OffsetDateTime dtInsert;
	private OffsetDateTime dtDelete;
	private String userIdInsert;
	private String userIdDelete;
	private String giasFertilizerCode;
}
