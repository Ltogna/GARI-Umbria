package com.abacogroup.pua.workflow.util;

/**
 * 
 * @author Emanuele Crocilla
 *
 */
public final class Const {
 
	public static final String PUA_DICHIARAZIONE_SPANDIMENTI = "PUA_DICHIARAZIONE_SPANDIMENTI";
	public static final String PUA_DICHIARAZIONE_FINALE = "PUA_DICHIARAZIONE_FINALE";
	public static final String PUA_FIRMA = "PUA_FIRMA";
	
	public static final String PUA_DICHIARAZIONE_SPANDIMENTI_INCOMPLETED = "PUA_DICHIARAZIONE_SPANDIMENTI_INCOMPLETED";
	public static final String PUA_FINAL_DECLARATION_INCOMPLETED = "PUA_FINAL_DECLARATION_INCOMPLETED";
	public static final String PUA_FIRMA_INCOMPLETED = "PUA_FIRMA_INCOMPLETED";
	
	public static final String PUA_UNHANDLED_ERROR = "PUA_UNHANDLED_ERROR";
	
	private Const() {
	}

}
