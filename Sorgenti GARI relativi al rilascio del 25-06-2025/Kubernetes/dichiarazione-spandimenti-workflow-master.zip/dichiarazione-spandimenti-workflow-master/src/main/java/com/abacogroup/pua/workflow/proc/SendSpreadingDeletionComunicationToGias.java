package com.abacogroup.pua.workflow.proc;

import com.abacogroup.applicationworkflowsdk.environment.IAgriProcedureEnvironment;
import com.abacogroup.workflow.sdk.beans.ProcessData;
import com.abacogroup.workflow.sdk.beans.WorkflowMessage;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class SendSpreadingDeletionComunicationToGias extends ASpreadingComunicationToGias {

    @Override
    protected void doExecute(ProcessData processData, IAgriProcedureEnvironment env) throws Exception {
        log.debug("[dichiarazione-spandimenti-workflow] Starting execution of SendSpreadingDeletionComunicationToGias");
        
        try {
            log.debug("[dichiarazione-spandimenti-workflow] Attempting to handle deletion operation");
            handleDeletion(processData, env);
            log.debug("[dichiarazione-spandimenti-workflow] Deletion operation completed successfully");
        } catch (Exception e) {
            log.error("[dichiarazione-spandimenti-workflow] "
                    + "Cannot finish execution of SendSpreadingDeletionComunicationToGias due errors", e);
            
            log.debug("[dichiarazione-spandimenti-workflow] Adding error message to workflow messages");
            processData.getWorkflowMessages()
                    .add(new WorkflowMessage(QdC_NON_AGGIORNATO_ERR_CODE, QdC_NON_AGGIORNATO +
                    PLEASE_UPD_QdC_MANUALLY, WorkflowMessage.Type.ERROR));
            log.debug("[dichiarazione-spandimenti-workflow] Error message added to workflow messages");
        }
        
        log.debug("[dichiarazione-spandimenti-workflow] Completed execution of SendSpreadingDeletionComunicationToGias");
    }

}
