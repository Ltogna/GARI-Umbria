package com.abacogroup.pua.workflow.proc;

import com.abacogroup.applicationworkflowsdk.environment.IAgriProcedureEnvironment;
import com.abacogroup.applicationworkflowsdk.v2.procedures.ApplicationProcedure;
import com.abacogroup.pua.workflow.model.NoSpreadingPeriodLatestInsertNTT;
import com.abacogroup.pua.workflow.model.OrganicFertilizerSpreadingDeclaration;
import com.abacogroup.pua.workflow.model.TipologiaDichirazione;
import com.abacogroup.workflow.sdk.beans.ProcessData;
import com.abacogroup.workflow.sdk.beans.WorkflowMessage;
import lombok.extern.slf4j.Slf4j;
import org.jdbi.v3.core.Jdbi;

import java.time.LocalDate;
import java.time.Year;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Optional;

@Slf4j
public class CheckDichiarazioneSpandimentiDates extends ApplicationProcedure {
    public static final String PUA_APP_FORMS = "PUA_APP_FORMS";
    @Override
    protected void doExecute(ProcessData processData, IAgriProcedureEnvironment env) throws Exception {
        log.debug("[dichiarazione-spandimenti-workflow] CheckDichiarazioneSpandimentiDates started");
        var params = getApplicationsWorkflowParams();
        Optional<TipologiaDichirazione> tipologiaOpt = processData.<TipologiaDichirazione>getGlobalVar(TipologiaDichirazione.KEY);
        TipologiaDichirazione tipologia = tipologiaOpt.get();
        int year = tipologia.getYear();
        int partyId = (params.getPartyId()).intValue();
        log.debug("[dichiarazione-spandimenti-workflow] Getting Details");
        var noSpreadings = getNoSpreadingPeriodLastInserted(env, partyId,params.getApplicationId(), year);
        log.debug("[dichiarazione-spandimenti-workflow] getNoSpreadingPeriodLastInserted");
        var organicFertilizer = getOrganicFertilizer(env, params.getApplicationId(), partyId);
        log.debug("[dichiarazione-spandimenti-workflow] getOrganicFertilizer");

        if (organicFertilizer != null && !organicFertilizer.isEmpty()) {
            for (OrganicFertilizerSpreadingDeclaration data : organicFertilizer) {

                var currentNoSP = noSpreadings != null
                        ? noSpreadings.stream()
                        .filter(x -> x.getEffluent() != null && x.getEffluent().equals(data.getLivestockEffluents()))
                        .findFirst()
                        .orElse(null)
                        : null;

                try {
                    if (!ValidateDates(processData, currentNoSP, data.getExpectedDate())) {
                        processData.getWorkflowMessages().add(new WorkflowMessage(
                                "NO_SPREADING_PERIOD_EXCEPTION",
                                "Cannot continue because spreading is not allowed on this date: " + data.getExpectedDate(),
                                WorkflowMessage.Type.ERROR
                        ));
                    }
                } catch (Exception e) {
                    log.error("Error validating spreading date for expectedDate={}, effluent={}", data.getExpectedDate(), data.getLivestockEffluents(), e);
                    processData.getWorkflowMessages().add(new WorkflowMessage(
                            "VALIDATION_EXCEPTION",
                            "Unexpected error during validation of date: " + data.getExpectedDate(),
                            WorkflowMessage.Type.ERROR
                    ));
                }
            }
        }
    }


    private static List<NoSpreadingPeriodLatestInsertNTT> getNoSpreadingPeriodLastInserted(IAgriProcedureEnvironment env, Integer partyId,Long applicationId, Integer year) {
        Jdbi jdbi = env.getJdbi(PUA_APP_FORMS).orElseThrow();
         return   jdbi.withHandle(h ->
                    h.createQuery("""
                                    SELECT party_id, effluent, year, day_from, day_to
                                    FROM appfpua_no_spreading_periods_latest_insert
                                    WHERE application_id = :applicationId
                                    AND party_id = :partyId
                                    AND year = :year
                                    """)
                            .bind("applicationId", applicationId)
                            .bind("partyId", partyId)
                            .bind("year", year)
                            .mapToBean(NoSpreadingPeriodLatestInsertNTT.class)
                            .list()
            );
    }
    private static List<OrganicFertilizerSpreadingDeclaration> getOrganicFertilizer(IAgriProcedureEnvironment env, Long applicationId, Integer partyId) {
        Jdbi jdbi = env.getJdbi(PUA_APP_FORMS).orElseThrow();
        return   jdbi.withHandle(h ->
                h.createQuery("""
                                select * 
                                from appfpua_organic_fert_spreading_declaration 
                                WHERE application_id = :applicationId 
                                AND party_id = :partyId
                                AND dt_delete > §current_timestamp§
                                order by id
                                    """)
                        .bind("applicationId", applicationId)
                        .bind("partyId", partyId)
                        .mapToBean(OrganicFertilizerSpreadingDeclaration.class)
                        .list()
        );
    }
    public static boolean ValidateDates(ProcessData processData, NoSpreadingPeriodLatestInsertNTT nospreading, String expectedDateString) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyMMdd");
        LocalDate expectedDate = LocalDate.parse(expectedDateString, formatter);

        if (nospreading == null) {
            int year = expectedDate.getYear();
            LocalDate defaultStart = LocalDate.of(year, 12, 1);
            LocalDate defaultEnd = Year.isLeap(year + 1)
                    ? LocalDate.of(year + 1, 2, 29)
                    : LocalDate.of(year + 1, 2, 28);

            return expectedDate.isBefore(defaultStart) || expectedDate.isAfter(defaultEnd);
        }
        LocalDate from = LocalDate.parse(nospreading.getDayFrom(), formatter);
        LocalDate to = LocalDate.parse(nospreading.getDayTo(), formatter);
        return expectedDate.isBefore(from) || expectedDate.isAfter(to);
    }


}
