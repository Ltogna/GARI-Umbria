package com.abacogroup.pua.workflow.model;


import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class NoSpreadingPeriodLatestInsertNTT {
	private Long applicationId;
	private Integer partyId;
	private String effluent;
	private Integer year;
	private String dayFrom;
	private String dayTo;
}
