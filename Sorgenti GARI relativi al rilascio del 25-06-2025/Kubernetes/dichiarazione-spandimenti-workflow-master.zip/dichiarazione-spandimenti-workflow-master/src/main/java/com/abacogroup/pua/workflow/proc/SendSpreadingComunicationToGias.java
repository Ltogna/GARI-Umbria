package com.abacogroup.pua.workflow.proc;

import com.abacogroup.applicationworkflowsdk.environment.IAgriProcedureEnvironment;
import com.abacogroup.workflow.sdk.beans.ProcessData;
import com.abacogroup.workflow.sdk.beans.WorkflowMessage;
import com.abacogroup.workflow.sdk.proc.StopTransitionException;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class SendSpreadingComunicationToGias extends ASpreadingComunicationToGias {
	 
	protected void doExecute(ProcessData processData, IAgriProcedureEnvironment env) throws Exception {
	   
		log.debug("[dichiarazione-spandimenti-workflow] Starting execution of SendSpreadingComunicationToGias");
	    
	    try {
	    	
	        log.debug("[dichiarazione-spandimenti-workflow] Attempting to handle writing operation");
	       
	        handleWriting(processData, env);
	        
	        log.debug("[dichiarazione-spandimenti-workflow] Writing operation completed successfully");
	        
	        return;
	        
	    } catch (Exception e) {
	    	
	        log.error("[dichiarazione-spandimenti-workflow] "
	                + "Cannot finish execution of SendSpreadingComunicationToGias due errors, "
	                + "the system is going to try to delete elements already written in Quaderno di Campagna", e);
	        
			processData.getWorkflowMessages()
					.add(new WorkflowMessage(QdC_NON_AGGIORNATO_ERR_CODE, QdC_NON_AGGIORNATO, WorkflowMessage.Type.ERROR));

	        try {
	        	
	            log.debug("[dichiarazione-spandimenti-workflow] Attempting deletion of elements already written");
	            
	            handleDeletion(processData, env);
	            
	            log.debug("[dichiarazione-spandimenti-workflow] Deletion completed successfully");
	            
	        } catch (Exception e2) {
	           
	        	log.error("[dichiarazione-spandimenti-workflow] Deletion failed with exception", e2);
	        }
	        
	        log.debug("[dichiarazione-spandimenti-workflow] Throwing StopTransitionException");
	        throw new StopTransitionException();
	    }
	}
}
