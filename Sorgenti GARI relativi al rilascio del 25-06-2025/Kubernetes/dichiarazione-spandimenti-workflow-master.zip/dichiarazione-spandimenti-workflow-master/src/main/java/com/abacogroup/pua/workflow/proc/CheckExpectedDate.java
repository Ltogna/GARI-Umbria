package com.abacogroup.pua.workflow.proc;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import com.abacogroup.applicationworkflowsdk.environment.IAgriProcedureEnvironment;
import com.abacogroup.applicationworkflowsdk.model.io.output.ApplicationDetailsPublicDTO;
import com.abacogroup.applicationworkflowsdk.v2.procedures.ApplicationProcedure;
import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.pua.workflow.model.OrganicFertilizerSpreadingDeclarationDTO;
import com.abacogroup.workflow.sdk.beans.ProcessData;
import com.abacogroup.workflow.sdk.beans.WorkflowMessage;
import com.abacogroup.workflow.sdk.proc.StopTransitionException;

import lombok.extern.slf4j.Slf4j;

/**
 * Check if expected date is forty-eight hours after declaration completed
 * 
 * @author Emanuele Crocilla
 *
 */
@Slf4j
public class CheckExpectedDate extends ApplicationProcedure {

	private DateFormat expectedDateSDF_0 = new SimpleDateFormat("yyyyMMdd");
	private DateFormat expectedDateSDF_1 = new SimpleDateFormat("dd/MM/yyyy");

	@Override
	protected void doExecute(ProcessData processData, IAgriProcedureEnvironment env) throws Exception {

		String expectedDate = null;
		
		List<OrganicFertilizerSpreadingDeclarationDTO> organicFertilizerSpreadingDeclarations = 
				(List<OrganicFertilizerSpreadingDeclarationDTO>) processData.getGlobalVars()
					.get(OrganicFertilizerSpreadingDeclarationDTO.KEY);
		
		for (OrganicFertilizerSpreadingDeclarationDTO item : organicFertilizerSpreadingDeclarations) {

			// retrieve the user given parameters 
			expectedDate = item.getExpectedDate();

			if ( !validate(expectedDate) ) {
				Date date = expectedDateSDF_0.parse(expectedDate);
				processData.getWorkflowMessages().add(new WorkflowMessage("UNAVAILABLE_EXPECTED_DATE", String.format("""
						Impossibile passare la domanda allo stato 'Controllata'.
						La data prevista con valore '%s' e' inferiore alle 48 ore".""", expectedDateSDF_1.format(date)), WorkflowMessage.Type.ERROR));

				throw new StopTransitionException();
			}
		}
		
		if (log.isDebugEnabled()) {
			log.debug("OrganicFertilizerSpreadingDeclarations have a valid expected date ");
		}
	}
	protected boolean validate(String expectedDate) {
		try {
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyMMdd");
			LocalDate expected = LocalDate.parse(expectedDate, formatter);
			LocalDate today = LocalDate.now();

			// The date must be strictly after tomorrow (i.e., at least day after tomorrow)
			return expected.isAfter(today.plusDays(1));

		} catch (Exception e) {
			log.error("Invalid date format or comparison failed: " + e.getMessage());
			return false;
		}
	}


	ApplicationDetailsPublicDTO getApplicationDetailsPublicDTO(ProcessData processData, IAgriProcedureEnvironment env,
			Long applicationId) throws Exception {
		return env.getApplicationDetailsService()
				.retrieveApplicationDetails(processData.getTenantId(), applicationId,
						(User) processData.getAuthContext().getPrincipal());
	}

}
