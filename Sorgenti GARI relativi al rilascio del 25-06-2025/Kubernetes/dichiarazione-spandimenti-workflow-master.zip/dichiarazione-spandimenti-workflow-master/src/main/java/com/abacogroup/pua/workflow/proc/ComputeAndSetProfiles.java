package com.abacogroup.pua.workflow.proc;

import com.abacogroup.applicationworkflowsdk.environment.IAgriProcedureEnvironment;
import com.abacogroup.applicationworkflowsdk.model.io.output.ModuleProfileDTO;
import com.abacogroup.applicationworkflowsdk.v2.procedures.ApplicationProcedure;
import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.pua.workflow.model.TipologiaDichirazione;
import com.abacogroup.workflow.sdk.beans.ProcessData;
import com.abacogroup.workflow.sdk.beans.WorkflowMessage;
import com.abacogroup.workflow.sdk.proc.StopTransitionException;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

public class ComputeAndSetProfiles extends ApplicationProcedure {

    private static Set<String> allowedYearProfiles;

    @Override
    protected void doExecute(ProcessData processData, IAgriProcedureEnvironment env) throws Exception {
        Optional<TipologiaDichirazione> formData = processData.<TipologiaDichirazione>getGlobalVar(
                TipologiaDichirazione.KEY);

        if(formData.isEmpty()){
            processData.getWorkflowMessages().add(new WorkflowMessage("MISSING_FORM", "Quadro anno campagna non compilato",
                    WorkflowMessage.Type.ERROR));
            throw new StopTransitionException();
        }
        var yearProfiles = getYearProfiles(processData, env);

        var profiles = computeProfiles(formData.get(), yearProfiles);
        applyApplicationProfiles(profiles, processData, env);
    }

    // Visible for testing
    List<String> computeProfiles(TipologiaDichirazione formData, Set<String> yearProfiles) {
        List<String> profiles = new ArrayList<>();

        // Add years profiles
        String year = "Y" + formData.getYear();
        if (!yearProfiles.contains(year)) {
            throw new IllegalStateException("There is no profile for year " + formData.getYear());
        }

        profiles.add(year);

        return profiles;
    }

    private void applyApplicationProfiles(List<String> profiles, ProcessData processData, IAgriProcedureEnvironment env) {
        // adds/removes profiles to the application
        env.getApplicationProfilesService()
                .upsertApplicationProfiles(processData.getTenantId(), getApplicationsWorkflowParams().getApplicationId(), profiles,
                        (User) processData.getAuthContext().getPrincipal());
    }

    private synchronized Set<String> getYearProfiles(ProcessData processData, IAgriProcedureEnvironment env) {
        if (allowedYearProfiles != null) {
            return allowedYearProfiles;
        }

        var params = getApplicationsWorkflowParams();
        List<ModuleProfileDTO> allProfiles = env.getApplicationProfilesService().getAllModuleProfiles(processData.getTenantId(),
                params.getApplicationId(), params.getLocale());

        return allProfiles.stream()
                .map(ModuleProfileDTO::getProfileCode)
                .filter(p -> p.startsWith("Y") && p.length() == 5)
                .filter(p -> {
                    try {
                        Integer.valueOf(p.substring(1));
                        return true;
                    } catch (NumberFormatException e) {
                        return false;
                    }
                })
                .collect(Collectors.toSet());
    }
}
