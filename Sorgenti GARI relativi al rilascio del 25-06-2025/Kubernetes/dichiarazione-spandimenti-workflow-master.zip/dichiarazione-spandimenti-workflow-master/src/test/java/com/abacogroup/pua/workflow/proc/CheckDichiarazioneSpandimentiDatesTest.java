package com.abacogroup.pua.workflow.proc;

import com.abacogroup.applicationworkflowsdk.environment.IAgriProcedureEnvironment;
import com.abacogroup.applicationworkflowsdk.model.ApplicationsWorkflowParams;
import com.abacogroup.pua.workflow.model.NoSpreadingPeriodLatestInsertNTT;
import com.abacogroup.pua.workflow.model.OrganicFertilizerSpreadingDeclaration;
import com.abacogroup.pua.workflow.model.TipologiaDichirazione;
import com.abacogroup.workflow.sdk.beans.ProcessData;
import com.abacogroup.workflow.sdk.beans.WorkflowMessage;
import com.abacogroup.workflow.sdk.beans.testsupport.ProcessDataTestSupport;
import org.jdbi.v3.core.Jdbi;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class CheckDichiarazioneSpandimentiDatesTest {

	private CheckDichiarazioneSpandimentiDates procedure;
	private IAgriProcedureEnvironment env;
	private ProcessData processData;
	private Jdbi jdbi;

	@BeforeEach
	void setUp() {
		procedure = new CheckDichiarazioneSpandimentiDates();
		env = mock(IAgriProcedureEnvironment.class);
		processData = new ProcessDataTestSupport();
		jdbi = mock(Jdbi.class);

		// Set up global variables
		TipologiaDichirazione tipologia = new TipologiaDichirazione();
		tipologia.setYear(2025);
		processData.getGlobalVars().put(TipologiaDichirazione.KEY, tipologia);


	}
	@Test
	void testValidateDatesInsidePeriod_shouldReturnFalse() {
		NoSpreadingPeriodLatestInsertNTT period = new NoSpreadingPeriodLatestInsertNTT();
		period.setDayFrom("20241201");
		period.setDayTo("20250228");

		boolean result = CheckDichiarazioneSpandimentiDates.ValidateDates(processData, period, "20250110");
		assertFalse(result); // Expected date is inside no-spreading period
	}

	@Test
	void testValidateDatesOutsidePeriod_shouldReturnTrue() {
		NoSpreadingPeriodLatestInsertNTT period = new NoSpreadingPeriodLatestInsertNTT();
		period.setDayFrom("20241201");
		period.setDayTo("20250228");

		boolean result = CheckDichiarazioneSpandimentiDates.ValidateDates(processData, period, "20250310");
		assertTrue(result); // Expected date is outside no-spreading period
	}

	@Test
	void testValidateDatesWithNullPeriod_shouldUseDefaultWindow() {
		boolean resultBefore = CheckDichiarazioneSpandimentiDates.ValidateDates(processData, null, "20241130");
		boolean resultInside = CheckDichiarazioneSpandimentiDates.ValidateDates(processData, null, "20241215");
		boolean resultAfter = CheckDichiarazioneSpandimentiDates.ValidateDates(processData, null, "20250301");

		assertTrue(resultBefore);
		assertFalse(resultInside);
		assertTrue(resultAfter);
	}
}
