package com.abacogroup.pua.workflow.proc;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

/**
 * Unit tests for CheckExpectedDate
 */
@ExtendWith(MockitoExtension.class)
class CheckExpectedDateTest {

	private static final String YYYYMMDD = "yyyyMMdd";

	@InjectMocks
	CheckExpectedDate proc;

	@Test
	void testGetUnavailableArea_KO() throws Exception {
		DateFormat sdf0 = new SimpleDateFormat(YYYYMMDD);
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.HOUR, 25); // less than 48 hours
		String expectedDate = sdf0.format(cal.getTime());

		assertFalse(proc.validate(expectedDate));
	}

	@Test
	void testGetUnavailableArea_OK() throws Exception {
		DateFormat sdf0 = new SimpleDateFormat(YYYYMMDD);
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.HOUR, 70); // more than 48 hours
		String expectedDate = sdf0.format(cal.getTime());

		assertTrue(proc.validate(expectedDate));
	}
}
