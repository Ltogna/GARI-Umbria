package com.abacogroup.pua.workflow.proc;

import java.util.List;
import java.util.Set;

import org.junit.jupiter.api.Test;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.*;
import com.abacogroup.pua.workflow.model.TipologiaDichirazione;
import static org.hamcrest.collection.IsIterableContainingInAnyOrder.containsInAnyOrder;
import static org.junit.jupiter.api.Assertions.assertThrows;

public class ComputeAndSetProfilesTest {

    @Test
    void testComputeProfiles() {
        ComputeAndSetProfiles proc = new ComputeAndSetProfiles();
        TipologiaDichirazione td;
        List<String> profiles;

        td = new TipologiaDichirazione(2024);
        profiles = proc.computeProfiles(td, Set.of("Y2024"));
        assertThat(profiles, containsInAnyOrder("Y2024"));
    }

    @Test
    void testErrorWhenYearProfileIsMissing() {
        ComputeAndSetProfiles proc = new ComputeAndSetProfiles();
        TipologiaDichirazione td = new TipologiaDichirazione(2025);
        assertThrows(IllegalStateException.class, () -> proc.computeProfiles(td, Set.of("Y2024")));
    }
}
