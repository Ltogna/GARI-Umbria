package com.abacogroup.pua.workflow.proc;

import static org.hamcrest.CoreMatchers.containsString;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.collection.IsIterableContainingInAnyOrder.containsInAnyOrder;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;

import java.util.List;

import org.junit.jupiter.api.Test;

import com.abacogroup.pua.workflow.util.Const;
import com.abacogroup.workflow.sdk.beans.WorkflowMessage;
import com.abacogroup.workflow.sdk.beans.WorkflowMessage.Type;

/**
 * 
 * @author Emanuele Crocilla
 *
 */
class CheckDichiarazioneSpandimentiCompiledTest {

    @Test
    void testCheckDichiarazioneSpandimentiCompiled_OK() {
    	
    	CheckDichiarazioneSpandimentiCompiled proc = new CheckDichiarazioneSpandimentiCompiled();
        
        List<String> profiles = proc.getFormCodesToCheck();
        
        assertThat(profiles, containsInAnyOrder(
        		 Const.PUA_DICHIARAZIONE_SPANDIMENTI, Const.PUA_DICHIARAZIONE_FINALE));

//        Set<String> allowedProfiles = proc.getAllowedProfiles();
//        assertThat(allowedProfiles, containsInAnyOrder(Const.SEMPLICE));
        
        WorkflowMessage workflowMessage = proc.createMessage( Const.PUA_DICHIARAZIONE_SPANDIMENTI, 
        		Const.PUA_DICHIARAZIONE_SPANDIMENTI, null, null);
        
        assertThat(workflowMessage.getCode(), containsString(Const.PUA_DICHIARAZIONE_SPANDIMENTI_INCOMPLETED));
        assertThat(workflowMessage.getDescription(), containsString("Dichiarazione spandimenti incompleta"));
        assertEquals(workflowMessage.getType(), Type.ERROR);
         
    }
    
    @Test
    void testCheckDichiarazioneSpandimentiCompiled_KO() {
    	
    	CheckDichiarazioneSpandimentiCompiled proc = new CheckDichiarazioneSpandimentiCompiled();
        
        WorkflowMessage workflowMessage = proc.createMessage( Const.PUA_DICHIARAZIONE_SPANDIMENTI, 
        		Const.PUA_DICHIARAZIONE_SPANDIMENTI, null, null);
        
        assertNotEquals(workflowMessage.getCode(), "wannafail");
    }
 
}
