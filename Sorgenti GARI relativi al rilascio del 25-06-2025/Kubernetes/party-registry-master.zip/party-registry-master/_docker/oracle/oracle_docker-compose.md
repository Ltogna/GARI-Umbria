# Oracle Docker Compose

### Configuration
For testing purpose, please use the following version of ojdbc8 dependency in pom.xml:
```
    <dependency>
      <groupId>com.oracle.database.jdbc</groupId>
      <artifactId>ojdbc8</artifactId>
      <version>12.2.0.1</version>
    </dependency>
```

In JdbiTest.java use  
```
test_config_ora_local.yml 
```
as configuration file.

### Orale docker compose

For terminal:
```
sudo docker login docker-registry.fe.abacogroup.eu
```

The terminal will ask for user and password.
Please, give your Abaco maven credentials 
(you probably have them in
```
/home/<your-user>/.m2
```
folder, in settings.xml file)

```
sudo docker-compose -f oracle_docker-compose.yml up
``` 

Once the "compose" is up,  connect with a database client (Dbeaver for example)
```
Host: localhost
Port: 31521
Database: ORCLPDB1 (Service Name)
Authentication: Oracle Database Native
Username: test
Password: test
```

Tentantivo di lancio delle migrazioni su Oracle locale:
```
--install bundle project from intellij
mvn clean install -DskipTest
-- package party project from intellij) 
mvn clean package -DskipTest
-- migrate 
java -jar target/party-registry-1.0.0-SNAPSHOT.jar db migrate config-oracle-local.yml
```


