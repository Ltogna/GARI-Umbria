# common docker-compose #

:warning: temporaneo su party-registry! spostare in un progetto root/common

## rabbit ##

[management home](http://localhost:15672)