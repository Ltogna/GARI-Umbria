# Changelog

[README](README.md)

### [v4.4.0](https://gitlab.fe.abacogroup.eu/patri-renew/party-registry/compare/v4.3.0...v4.4.0) (2024-03-26)

### Added
 
 * :sparkles: add delete tags processor

### Fixed

  * :bug: fixed i18n query for tags

### [v4.2.11](https://gitlab.fe.abacogroup.eu/patri-renew/party-registry/compare/v4.2.10...v4.2.11) (2024-09-26)

### Fixes
* :bug: fix hasMandates in party relation apis, closes [#151426](https://abacogroup.easyredmine.com/issues/151426)


### [v4.2.10](https://gitlab.fe.abacogroup.eu/patri-renew/party-registry/compare/v4.2.9...v4.2.10) (2024-09-26)

### Features
* :sparkles: added hasMandate to PartyRelationParty, closes [#151426](https://abacogroup.easyredmine.com/issues/151426)


## [v4.2.9](https://gitlab.fe.abacogroup.eu/patri-renew/party-registry/compare/v4.2.8...v4.2.9) (2024-08-19)

### Fixes
* **acl:** :bug: fix error code for ACL NOT AUTHORIZED exception, closes [#149432](https://abacogroup.easyredmine.com/issues/149432)


### [v4.2.8](https://gitlab.fe.abacogroup.eu/patri-renew/party-registry/compare/v4.2.7...v4.2.8) (2024-08-01)

### Other
* **deps:** :arrow_up: upgrade proxies-cache lib to version v4.2.4


### [v4.2.7](https://gitlab.fe.abacogroup.eu/patri-renew/party-registry/compare/v4.2.6...v4.2.7) (2024-05-03)

### Fixes
* :bug: fixed bug in archive party, closes [#127781](https://abacogroup.easyredmine.com/issues/127781)


### [v4.2.6](https://gitlab.fe.abacogroup.eu/patri-renew/party-registry/compare/v4.2.5...v4.2.6) (2024-04-17)

### Features
* :sparkles: Updated get check-existence with pathparam instead of payload


### [v4.2.5](https://gitlab.fe.abacogroup.eu/patri-renew/party-registry/compare/v4.2.4...v4.2.5) (2024-04-15)

### Fixes
* **acl:** :bug: fix canWrite check
* :bug: updated canWrite check of AclService


### [v4.2.4](https://gitlab.fe.abacogroup.eu/patri-renew/party-registry/compare/v4.2.3...v4.2.4) (2024-04-04)

### Features
* :sparkles: permit withManage in public party detail api, closes [#135540](https://abacogroup.easyredmine.com/issues/135540)
* :sparkles: added star mandate check in AclServiceImpl, closes [#135090](https://abacogroup.easyredmine.com/issues/135090)
* :sparkles: added acl skip check, closes [#135081](https://abacogroup.easyredmine.com/issues/135081)
* :sparkles: added new api to get user's permissions, closes [#135090](https://abacogroup.easyredmine.com/issues/135090)
* **ACL:** :sparkles: implement acl skip for private party search

### Fixes
* :bug: fix issue with oracle acl queries

### Other
* :recycle: refactor
* **deps:** :arrow_up: upgrade proxies-cache lib to version v4.2.3
* :fire: remove deprecated insert party function code
* :memo: add openapi description for new user permission api
* :green_heart: add automatic release on tag
* :recycle: restore commented code


### [v4.2.3](https://gitlab.fe.abacogroup.eu/patri-renew/party-registry/compare/v4.2.2...v4.2.3) (2024-03-26)

### Features
* add taxcode and birth informations to PartyRelationParty api, closes [#134606](https://abacogroup.easyredmine.com/issues/134606)

### Fixes
* **lau-client:** :bug: fix issue in lau service for not authenticated calls

### [v4.2.2](https://gitlab.fe.abacogroup.eu/patri-renew/party-registry/compare/v4.2.1...v4.2.2) (2024-03-26)

### [v4.2.1](https://gitlab.fe.abacogroup.eu/patri-renew/party-registry/compare/v4.2.0...v4.2.1) (2024-03-08)

## [v4.2.0](https://gitlab.fe.abacogroup.eu/patri-renew/party-registry/compare/v4.1.7...v4.2.0) (2024-03-08)

### [v4.1.7](https://gitlab.fe.abacogroup.eu/patri-renew/party-registry/compare/v4.1.6...v4.1.7) (2024-03-05)

### [v4.1.6](https://gitlab.fe.abacogroup.eu/patri-renew/party-registry/compare/v4.1.5...v4.1.6) (2024-02-29)

### [v4.1.5](https://gitlab.fe.abacogroup.eu/patri-renew/party-registry/compare/v4.1.4...v4.1.5) (2024-02-29)

### [v4.1.4](https://gitlab.fe.abacogroup.eu/patri-renew/party-registry/compare/v4.1.3...v4.1.4) (2024-02-29)

### [v4.1.3](https://gitlab.fe.abacogroup.eu/patri-renew/party-registry/compare/v4.1.2...v4.1.3) (2024-02-29)

### [v4.1.2](https://gitlab.fe.abacogroup.eu/patri-renew/party-registry/compare/v4.1.1...v4.1.2) (2024-02-28)

### [v4.1.1](https://gitlab.fe.abacogroup.eu/patri-renew/party-registry/compare/v4.1.0...v4.1.1) (2024-02-27)

## [v4.1.0](https://gitlab.fe.abacogroup.eu/patri-renew/party-registry/compare/v4.0.5...v4.1.0) (2024-02-26)

### [v4.0.5](https://gitlab.fe.abacogroup.eu/patri-renew/party-registry/compare/v4.0.4...v4.0.5) (2024-02-07)

### [v4.0.4](https://gitlab.fe.abacogroup.eu/patri-renew/party-registry/compare/v4.0.3...v4.0.4) (2024-02-06)

#### Other
* **deps:** :arrow_up: upgrade proxies-cache lib to version v4.2.2

### [v4.0.3](https://gitlab.fe.abacogroup.eu/patri-renew/party-registry/compare/v4.0.2...v4.0.3) (2024-01-24)

#### Other
* **deps:** :arrow_up: upgrade proxies-cache lib to version v4.2.1, closes [#126309](https://abacogroup.easyredmine.com/issues/126309)

### [v4.0.2](https://gitlab.fe.abacogroup.eu/patri-renew/party-registry/compare/v4.0.1...v4.0.2) (2023-12-06)

### [v4.0.1](https://gitlab.fe.abacogroup.eu/patri-renew/party-registry/compare/v4.0.0...v4.0.1) (2023-12-06)

## [v4.0.0](https://gitlab.fe.abacogroup.eu/patri-renew/party-registry/compare/v1.9.0...v4.0.0) (2023-11-22)

## [v1.9.0](https://gitlab.fe.abacogroup.eu/patri-renew/party-registry/compare/v1.8.0...v1.9.0) (2023-11-20)

## [v1.8.0](https://gitlab.fe.abacogroup.eu/patri-renew/party-registry/compare/v1.7.0...v1.8.0) (2023-11-17)

## [v1.7.0](https://gitlab.fe.abacogroup.eu/patri-renew/party-registry/compare/v1.6.0...v1.7.0) (2023-11-07)

## [v1.6.0](https://gitlab.fe.abacogroup.eu/patri-renew/party-registry/compare/v1.4.4...v1.6.0) (2023-10-13)

### [v1.4.4](https://gitlab.fe.abacogroup.eu/patri-renew/party-registry/compare/v1.4.3...v1.4.4) (2023-09-13)

### [v1.4.3](https://gitlab.fe.abacogroup.eu/patri-renew/party-registry/compare/v1.4.2...v1.4.3) (2023-07-26)

### [v1.4.2](https://gitlab.fe.abacogroup.eu/patri-renew/party-registry/compare/v1.4.1...v1.4.2) (2023-07-04)

#### Fixes
* fix issue in parties acl server url configuration in config doker file

### [v1.4.1](https://gitlab.fe.abacogroup.eu/patri-renew/party-registry/compare/v1.4.0...v1.4.1) (2023-07-03)

#### Fixes
* set default value for ignoreACL to true

#### Other
* add ignore_acl flag in deployment template

## [v1.4.0](https://gitlab.fe.abacogroup.eu/patri-renew/party-registry/compare/v1.3.8...v1.4.0) (2023-06-30)

### [v1.3.8](https://gitlab.fe.abacogroup.eu/patri-renew/party-registry/compare/v1.3.7...v1.3.8) (2023-06-28)

### [v1.3.7](https://gitlab.fe.abacogroup.eu/patri-renew/party-registry/compare/v1.3.6...v1.3.7) (2023-06-08)

### [v1.3.6](https://gitlab.fe.abacogroup.eu/patri-renew/party-registry/compare/v1.3.5...v1.3.6) (2023-05-22)

### [v1.3.5](https://gitlab.fe.abacogroup.eu/patri-renew/party-registry/compare/v1.3.4...v1.3.5) (2023-05-22)

### [v1.3.4](https://gitlab.fe.abacogroup.eu/patri-renew/party-registry/compare/v1.3.3...v1.3.4) (2023-05-02)

### [v1.3.3](https://gitlab.fe.abacogroup.eu/patri-renew/party-registry/compare/v1.3.2...v1.3.3) (2023-04-04)

### [v1.3.2](https://gitlab.fe.abacogroup.eu/patri-renew/party-registry/compare/v1.3.1...v1.3.2) (2023-03-13)

### [v1.3.1](https://gitlab.fe.abacogroup.eu/patri-renew/party-registry/compare/v1.3.0...v1.3.1) (2023-03-13)

## v1.3.0 (2023-03-03)
