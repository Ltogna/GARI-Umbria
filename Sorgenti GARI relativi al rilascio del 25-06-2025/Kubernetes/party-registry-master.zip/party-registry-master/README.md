# PARTY REGISTRY #
_version: v4.2.12_

## [party-registry-api](party-registry-api/README.md) ##

- ### [Bundles Infrastructure integration](party-registry-api/README.md#bundles-infrastructure-integration) ###
- ### [openapi.yaml](party-registry-api/doc/openapi.yaml)

## [party-registry-cli](party-registry-cli/README.md) ##
- ### 🚨🚨 NEW [external source party pojo](party-registry-cli%2Fsrc%2Fmain%2Fjava%2Fcom%2Fabacogroup%2Fpartyregistry%2Fdto%2Fv1%2FExternalSourceDtoV1.java) 🚨🚨
