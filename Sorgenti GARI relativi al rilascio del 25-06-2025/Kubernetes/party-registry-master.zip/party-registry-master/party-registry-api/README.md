# party-registry-api

[TOC]

---

## How to start the party-registry application

1. Run `mvn clean install` to build your application
1. execute migrations with `java -jar target/party-registry-1.0.0-SNAPSHOT.jar db migrate config.yml`
1. Start application with `java -jar target/party-registry-1.0.0-SNAPSHOT.jar server config.yml`
1. To check that your application is running enter url `http://localhost:8080/party-registry`

### Health Check

To see your applications health enter url `http://localhost:8081/healthcheck`

### OpenAPI

- openapi file json statico: [doc/openapi.json](doc/openapi.json)
- openapi file yaml statico: [doc/openapi.yaml](doc/openapi.yaml)


- openapi file json da server: [{party-registry-url}/openapi.json](http://localhost:8080/party-registry/openapi.json)   
- openapi file yaml da server: [{party-registry-url}/openapi.yaml](http://localhost:8080/party-registry/openapi.yaml)   
- swagger sul server: [{party-registry-url}/swagger](http://localhost:8080/party-registry/swagger)


### ACL
Party registry can be configured with ACL check, but when active, if a user create a party it abviously doesn't have any mandate on it, 
to avoid this problem, when ACL is enabled if the user have IGNORE_ACL_FUNCTION can create new parties and can see all the parties avoiding ACL check

*documentation on ACL to be improved*


## Bundles Infrastructure integration

The application must be connected to a RabbitMQ instance.

The bundles infrastructure will automatically set up to allow automatic configuration.

The application module id is `party-registry-api` and the supported changeset domains are:

```
📂 party-registry-api
┗━📂 <client-id>-<nnnnn>
  ┣━📂 app_config
  ┃ ┣━📜 <any file>.json
  ┃ ┗━📜 <.*>delete<.*>.json
  ┣━📂 citizenship
  ┃ ┗━📜 <any file>.jsonl
  ┣━📂 legal_status
  ┃ ┗━📜 <any file>.jsonl
  ┣━📂 dynamic_documents
  ┃ ┣━📜 <any file>.json
  ┃ ┣━📜 settings<.*>.json
  ┃ ┗━📜 settings<.*>delete<.*>.json
  ┣━📂 relations
  ┃ ┣━📜 <any file>.json
  ┃ ┗━📜 <.*>delete<.*>.json
  ┣━📂 external_sources
  ┃ ┣━📜 <any file>.json
  ┃ ┗━📜 <.*>delete<.*>.json
  ┗━📂 tags
    ┗━📜 <any file>.jsonl
    ┗━📜 <.*>delete<.*>.json

```

### app_config

The `app_config` file(s) are used to insert/update custom application properties.  
JSON file(s) must have the following structure:

```json5
[
  {
    "configurationKey": "the_key",
    // mandatory
    "configuration": {
      // custom json, mandatory
      "k1": true,
      "k2": "v2",
      "k3": {
        "k3_1": "v3_1",
        // [...]
      },
      //[...]
    }
  },
  // [...]
]
```

`app_config` file(s) containing `delete` in its name are used to delete configurations.  
JSON file(s) must have the following structure:

```json5
[
  {
    "configurationKey": "the_key" // mandatory
  },
  // [...]
]
```

#### code

configure code field in party creation/update. if no configuration is present, the value of code will be ignored when
creating/editing a party

```json5
[
  {
    "configurationKey": "code",
    "configuration": {
      "mandatory": false, // boolean, defines whether the code is mandatory or not
      "editable": true // boolean, defines whether or not the code can be modified
    }
  }
]
```

#### party_type

configure if `party_type`, natural or legal, can be updated. The default behaviour is true.

```json5
[
  {
    "configurationKey": "party_type",
    "configuration": {
      "editable": false
    }
  }
]
```

#### code_validation, taxCode_validation, vatNumber_validation

Configure regexes to validate `taxCode`, `vatNumber` and `code` fields for `partyType` natural (`N`) and legal (`L`).

Different regexes can be defined for each party type and are evaluated in or
```json5
[
  {
    "configurationKey": "vatNumber_validation",
    "configuration": {
      "L": [ // regexes for vat number of legal entity
        "^\\d{11}$"
      ],
      "N": [ // regexes for vat number of natural entity
        "^\\d{11}$"
      ]
    }
  },
  {
    "configurationKey": "taxCode_validation",
    "configuration": {
      "L": [ // regexes for tax code of legal entity
        "^\\d{11}$"
      ],
      "N": [ // regexes for tax code of natural entity
        "^[a-zA-Z]{6}\\d{2}[a-zA-Z]{1}\\d{2}[a-zA-Z]{1}\\d{3}[a-zA-Z]{1}$"
      ]
    }
  },
  {
    "configurationKey": "code_validation",
    "configuration": {
      "L": [ // regexes for code of legal entity
        "^\\d{11}$"
      ],
      "N": [ // regexes for code of natural entity
        "^[a-zA-Z]{6}\\d{2}[a-zA-Z]{1}\\d{2}[a-zA-Z]{1}\\d{3}[a-zA-Z]{1}$"
      ]
    }
  }
]

```

### citizenship

The `citizenship` file(s) are used to insert/update citizenships and their translations.  
JSONL file(s) must have the following structure:

```jsonl
{ "code": "000", "description": { "en": "Other", "it": "Altro", [...] } }
```

- `code`: citizenship code, ex. `ITA`
- `description`: map < iso lang code - translation >

### legal_status

The `legal_status` file(s) are used to insert/update legal_status and their translations.  
JSONL file(s) must have the following structure:

```jsonl
{ "code": "000", "description": { "en": "Other", "it": "Altro", [...] } }
```

- `code`: legal_status code, ex. `ITA`
- `description`: map < iso lang code - translation >

if the `jsonl` file name contains the word `delete`, than the system will delete all the entries present in the file (legal status and i18n)
that are not used by the parties stored in the db

### dynamic_documents

The `dynamic_documents` file(s) are used to insert/update dynamic document schemas.  
JSON file(s) must have the following structure:

#### dynamic doc definitions

(see dynamic document documentation)

#### settings

The application handles `dynamic documents` (abbr: _DD_)

A sample configuration can be found at `bundles-patri-italia/standard/party-registry-api/prt-0002/dynamic_documents`

The system will assume as definition file **any** `json` in the directory except those whose names begin
with `settings` (e.g.: _settings_01.json_)

When loading a `DD` definition the i18n labels of the DD will be automatically created.

The settings file is used to define the usage of the _DD_ on the portal.   
An example of a settings file:

```json

{
  "groups": [
    {
      "value": "anag",
      "description": {
        "it": "Documenti persona fisica",
        "en": "Documenti persona fisica"
      }
    }
  ],
  "documents": [
    {
      "docType": "ID",
      "types": [
        "N"
      ],
      "docGroup": "anag"
    },
    {
      "docType": "BANK",
      "types": [
        "L",
        "N"
      ],
      "docGroup": "anag",
      "tags": [
        "INQUILINO",
        "FORNITORE"
      ]
    }
  ]
}
```

The `group` element defines a field to group in the UI DD's that belong to the same group.  
The description is internationalised according to the I18N standard

The presence of this element adds **exclusively** i18N labels

The relationship between a DD and the group is defined, along with other configurations, in the `documents` block.

For each type of DD you can specify:

- the `docGroup` for grouping the DD in the UI
- the `types` array representing the discriminants for associating a `DD` to a party type
- the `tags` array (in or) representing the list of tags the party must have in order to use the document.
  - If a DD setting does not contain a list of tags, the DD is considered available regardless of the tags associated
    with the party.
  - The tags specified in this configuration must already be present on the portal.

This project classifies parties by type:

- `L` legal (legal person)
- `N` natural (natural person)

In the example above, ID will be available for natural persons, while BANK will be available for both natural and legal
persons

#### delete settings

`dynamic_documents` files starting with `settings` and containing `delete` in the name (ex. 'settings_0001.delete.json')
are used to delete settings related to
the specified docTypes. The DDs will no longer be visualised by the FE but remain in the db and can be reactivated by a
new settings file. JSON file(s) must
have the following structure:

```json5
[
  {
    "docType": "String" // mandatory, doc type to remove
  },
  //[...]
]
```

### relations

The `relations` file(s) are used to insert/update relations types and their roles as well as their descriptions.  
JSON file(s) must have the following structure:

```json5
[
  {
    "type": "String",
    // mandatory, relation type code
    "multiple": false,
    "description": {
      // relation type description
      "en": "String",
      "it": "String",
      // [...]
    },
    "roles": [
      // relation roles
      {
        "code": "String",
        // mandatory, role code
        "description": {
          // relation role description
          "en": "String",
          "it": "String",
          // [...]
        }
      },
      // [...]
    ]
  },
  // [...]
]
```

`relations` file(s) containing `delete` in its name are used to delete relations types and/or their roles.  
JSON file(s) must have the following structure:

```json5
[
  {
    "type": "AAA",
    "roles": [
      {
        "code": "AAA_1" // deletes AAA_1 role but not AAA type
      },
      //[...]
    ]
  },
  {
    "type": "BBB" // deletes BBB type and all its roles
  },
  //[...]
]
```

### external_sources

The `external_sources` file(s) are used to insert/update external party sources as well as their descriptions.  
JSON file(s) must have the following structure:

```json5
[
  {
    "code": "CODE", // unique code
    "url": "http://external/source/{code}", // source url, must contain string `{code}`
    "allowManual": true, // allow party insert if no party found on source (FE)
    "description": { // i18n
      "it": "test",
      "en": "test"
    }
  },
  //[...]
]
```

`external_sources` file(s) containing `delete` in its name are used to delete **unused** external sources.  
JSON file(s) must have the following structure:

```json5
[
  {
    "code": "CODE" // code of existing source to delete
  },
  //[...]
]
```


### tags

The `tags` file(s) are used to insert/update tags and their translations.  
JSONL file(s) must have the following structure:

```jsonl
{ "code": "String", "description": { "en": "String", "it": "String", [...] } }
```

- `code`: tag code
- `description`: map < iso lang code - translation >

The `tags` file(s) containing 'delete' in its name are used to delete unused external sources.
JSON file(s) must have the following structure:
 
```jsonl
{ "code": "String", "description": { "en": "String", "it": "String", [...] } }
```

If the tag 'code'  is used, it cannot be deleted (the process will give an error)


## sso2-functions

The application defines the following `functions`:

- READ
- WRITE
- DELETE

```json5
{
  "functions": [
    {
      "context": "PARTY-REGISTRY",
      "code": "READ",
      "description": "READ OPERATION"
    },
    {
      "context": "PARTY-REGISTRY",
      "code": "WRITE",
      "description": "WRITE OPERATIONS"
    },
    {
      "context": "PARTY-REGISTRY",
      "code": "DELETE",
      "description": "DELETE OPERATIONS"
    }
  ]
}
```

These definitions can be found in `bundles/standard/sso-server-2/prt-0001/functions/functions.json`.

The `bundles/standard` directory is the default one, so these configurations are installed automatically at startup.

A *hypothetical* configuration of `roles` would be:

- role: `admin` with functions `read, write, delete`
- role: `supervisor` with functions `read, write`
- role: `guest` with functions `read`

```json5
{
  "roles": [
    {
      "code": "ADMIN",
      "description": "ADMIN ROLE"
    },
    {
      "code": "SUPERVISOR",
      "description": "SUPERVISOR ROLE"
    },
    {
      "code": "GUEST",
      "description": "GUEST ROLE"
    }
  ],
  "roleFunctions": [
    {
      "roleCode": "ADMIN",
      "functions": [
        {
          "context": "PARTY-REGISTRY",
          "code": "READ"
        },
        {
          "context": "PARTY-REGISTRY",
          "code": "WRITE"
        },
        {
          "context": "PARTY-REGISTRY",
          "code": "DELETE"
        }
      ]
    },
    {
      "roleCode": "SUPERVISOR",
      "functions": [
        {
          "context": "PARTY-REGISTRY",
          "code": "READ"
        },
        {
          "context": "PARTY-REGISTRY",
          "code": "WRITE"
        }
      ]
    },
    {
      "roleCode": "GUEST",
      "functions": [
        {
          "context": "PARTY-REGISTRY",
          "code": "READ"
        }
      ]
    }
  ]
}

```

## events

party-registry launches events for the following actions:
- party creation: topic `party.new-party`
- party editing: topic `party.update-party`
- party archiving: topic `party.archive-party`
- delete party: topic `party.delete-party`

exchange: `party-exchange`

