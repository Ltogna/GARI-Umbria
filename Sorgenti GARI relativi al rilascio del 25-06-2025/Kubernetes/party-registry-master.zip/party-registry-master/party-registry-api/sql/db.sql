-- TODO COMMENTI --

create table prt_citizenship
(
    tenant_id varchar(100) not null,
    code      varchar(3)   not null,
    constraint prt_citizenship_pk primary key (tenant_id, code)
);

-- no versionamento, gestito dal parent
create table prt_addresses
(
    id           bigserial,
    country      varchar(100),-- //ITA
    region       varchar(100),
    district     varchar(100), -- MI
    municipality varchar(100),-- //milano
    locality     varchar(100),-- //borgo x  --localita
    street       varchar(100),-- //via del bug
    house_number varchar(10),-- // 1b
    postcode     varchar(20),-- //00000,
    details      varchar(4000),
    note         varchar(4000), -- indirizzo del figlio
    constraint prt_addresses_pk primary key (id)
);


create table prt_parties
(
    id        bigint,
    tenant_id varchar(100) not null,
    constraint prt_parties_pk primary key (id),
    constraint prt_parties_uk1 unique (tenant_id, id)
);

create sequence my_prt_parties_detail_pkid_seq;
create table prt_parties_detail
(
    pkid                   bigint default nextval('my_prt_parties_detail_pkid_seq'),
    party_id               bigint        not null,

    party_type             varchar(1)    NOT NULL,                  -- (NATURAL / LEGAL)
    gender                 varchar(1),

    last_name              varchar(4000) not null,
    first_name             varchar(4000),

    tax_code               varchar(100),
    vat_number             varchar(100),

    --DatiNascita    datiNascita,
    birth_date             date,
    birth_country          varchar(100),-- //ITA
    birth_region           varchar(100),
    birth_district         varchar(100),                            -- mi
    birth_municipality     varchar(100),                            -- milano
    nationality            varchar(3),                              -- TODO: reference to prt_citizenship table

    fk_address_residential bigint,                                  --residenza
    fk_address_home        bigint,                                  --domicilio
    fk_address_billing     bigint,                                  --fatturazione

    fl_archived            int           not null,                  --0 / 1
    dt_insert              timestamp     NOT NULL,
    user_id_insert         varchar(100)  NOT NULL,
    dt_delete              timestamp     NOT NULL,
    user_id_delete         varchar(100),

    constraint parties_detail_pk primary key (pkid),
    constraint parties_detail_fk1 foreign key (party_id) references prt_parties (id),
    constraint parties_detail_fk2 foreign key (fk_address_residential) references prt_addresses (id),
    constraint parties_detail_fk3 foreign key (fk_address_home) references prt_addresses (id),
    constraint parties_detail_fk4 foreign key (fk_address_billing) references prt_addresses (id),
    constraint parties_detail_ck1 check (fl_archived in (0, 1)),    --
    constraint parties_detail_ck2 check (party_type in ('N', 'L')), --
    constraint parties_detail_ck3 check (gender in ('M', 'F')),     --
    constraint parties_detail_uk1 unique (party_id, dt_delete)
);
create index parties_detail_idx1 ON prt_parties_detail (fk_address_residential);
create index parties_detail_idx2 ON prt_parties_detail (fk_address_home);
create index parties_detail_idx3 ON prt_parties_detail (fk_address_billing);

-- pkid -> mai referenziato su altre tabelle
--  id  -> sempre referenziato

create table prt_parties_contacts
(
    pkid           bigserial,
    party_id       bigint       not null,
    contact_type   varchar(100) not null, -- / email / pec / phone
    sub_type       varchar(100) not null, -- / [email lavoro | privata ]  [casa | ufficio...]
    contact_value  varchar(100) not null,
    note           varchar(4000),

    dt_insert      timestamp    NOT NULL,
    user_id_insert varchar(100) NOT NULL,
    dt_delete      timestamp    NOT NULL, -- dappertutto con default sw 31/12/9999
    user_id_delete varchar(100),
    constraint prt_parties_contacts_pk primary key (pkid),
    constraint prt_parties_contacts_fk1 foreign key (party_id) references prt_parties (id)
);
create index prt_parties_contacts_idx1 ON prt_parties_contacts (party_id);


create table prt_tags
(
    id        bigserial    not null,
    tag_code  varchar(20)  not null, -- FOR|
    tenant_id varchar(100) not null,
    constraint prt_tags_pk primary key (id),
    constraint prt_tags_uk1 unique (tenant_id, tag_code)
);

create table prt_parties_tags
(
    pkid           bigserial,
    party_id       bigint       not null,
    tag_id         bigint       not null,

    dt_insert      timestamp    NOT NULL,
    user_id_insert varchar(100) NOT NULL,
    dt_delete      timestamp    NOT NULL,
    user_id_delete varchar(100),
    constraint prt_parties_tags_pk primary key (pkid),
    constraint prt_parties_tags_fk1 foreign key (tag_id) references prt_tags (id),
    constraint prt_parties_tags_fk2 foreign key (party_id) references prt_parties (id)
);
create index prt_parties_tags_idx1 ON prt_parties_tags (party_id, tag_id);
create index prt_parties_tags_idx2 ON prt_parties_tags (tag_id);


/* TODO
create table schede_aggiuntive
(
--dipende da come sono fatte
    id bigserial primary key

);

create table soggetto_schede_aggiuntive
(
--dipende da come sono fatte
    id          bigserial primary key,
    soggetto_id bigint not null,
    archived_at date, --
    scheda_type character varying,
    scheda_ref  bigint not null
--auditing
);
*/


create table prt_relation_types
(
    id             bigserial    not null,
    tenant_id      varchar(100) not null,
    code           varchar(100) not null,
    fl_multiple    int          not null, -- possibilità di specificare 2 nuclei familiari

    dt_insert      timestamp    NOT NULL,
    user_id_insert varchar(100) NOT NULL,
    dt_delete      timestamp    NOT NULL,
    user_id_delete varchar(100),

    constraint prt_relation_types_pk primary key (id),
    constraint prt_relation_types_uk1 unique (tenant_id, code),
    constraint prt_relation_types_ck1 check (fl_multiple in (0, 1))
);


create table prt_relation_roles
(
    id             bigserial    not null,
    type_id        bigint       not null,
    code           varchar(100) not null,

    dt_insert      timestamp    NOT NULL,
    user_id_insert varchar(100) NOT NULL,
    dt_delete      timestamp    NOT NULL,
    user_id_delete varchar(100),
    constraint prt_relation_roles_pk primary key (id),
    constraint prt_relation_roles_uk1 unique (type_id, code),
    constraint prt_relation_roles_fk1 foreign key (type_id) references prt_relation_types (id)
);


create table prt_party_relations
(
    id               bigint       not null, --
    party_id         bigint       not null, --tizio
    relation_type_id bigint       not null, -- ha una relazione di tipo NUCLEO FAMILIARE
    dt_insert        timestamp    NOT NULL,
    user_id_insert   varchar(100) NOT NULL,
    dt_delete        timestamp    NOT NULL,
    user_id_delete   varchar(100),
    constraint prt_party_relations_pk primary key (id),
    constraint prt_party_relations_fk1 foreign key (party_id) references prt_parties (id),
    constraint prt_party_relations_fk2 foreign key (relation_type_id) references prt_relation_types (id)
);

create sequence prt_party_rel_parties_pkid_seq;
create table prt_party_relation_parties
(
    pkid              bigint default nextval('prt_party_rel_parties_pkid_seq'),
    party_relation_id bigint       not null, --pk nucleo familiare
    party_id          bigint       not null, --tizio
    relation_role_id  bigint       not null, --pk
    dt_start          varchar(8)   not null,
    dt_end            varchar(8)   not null,

    dt_insert         timestamp    NOT NULL,
    user_id_insert    varchar(100) NOT NULL,
    dt_delete         timestamp    NOT NULL,
    user_id_delete    varchar(100),

    constraint prt_party_relation_parties_pk primary key (pkid),
    constraint prt_party_relation_parties_uk1 unique (party_relation_id, party_id, relation_role_id, dt_delete),
    constraint prt_party_relation_parties_fk1 foreign key (party_relation_id) references prt_party_relations (id),
    constraint prt_party_relation_parties_fk2 foreign key (relation_role_id) references prt_relation_roles (id),
    constraint prt_party_relation_parties_fk3 foreign key (party_id) references prt_parties (id)
);

create table prt_party_relation_details
(
    pkid              bigserial    not null,
    party_relation_id bigint       not null,
    note              varchar(4000),
    dt_insert         timestamp    NOT NULL,
    user_id_insert    varchar(100) NOT NULL,
    dt_delete         timestamp    NOT NULL,
    user_id_delete    varchar(100),
    constraint prt_party_relation_details_pk primary key (pkid),
    constraint prt_party_relation_details_fk1 foreign key (party_relation_id) references prt_party_relations (id)
);

create table prt_i18n_values
(
    tenant_id  varchar(100)  not null,
    table_name varchar(100)  not null, --//prt_tags
    field_name varchar(100)  not null, --//tag_code
    i18n_value varchar(4000) not null, --//FOR
    lang       varchar(20)   not null, --//it_ch
    i18n_text  varchar(4000) not null, --//fornitore
    constraint prt_i18n_values_pk primary key (tenant_id, table_name, field_name, i18n_value, lang)
);

create table prt_parties_documents
(
    pkid            bigserial,
    tenant_id       varchar(100) not null,
    party_id        bigint       not null,
    definition_code varchar(100) not null,
    document_id     bigint       not null,
    dt_insert       timestamp    NOT NULL,
    user_id_insert  varchar(100) NOT NULL,
    dt_delete       timestamp    NOT NULL,
    user_id_delete  varchar(100),
    constraint prt_parties_documents_pk primary key (pkid),
    constraint prt_parties_documents_uk1 unique (tenant_id, document_id, dt_delete),
    constraint prt_parties_documents_fk1 foreign key (party_id) references prt_parties (id)

);

create table prt_doc_type
(
    id             bigserial    not null,
    tenant_id      varchar(100) not null,
    doc_type       varchar(100) not null,

    dt_insert      timestamp    not null,
    user_id_insert varchar(100) not null,
    dt_delete      timestamp    not null,
    user_id_delete varchar(100),

    constraint prt_doc_type_pk primary key (id),
    constraint prt_doc_type_uk1 unique (tenant_id, doc_type, dt_delete)
);
