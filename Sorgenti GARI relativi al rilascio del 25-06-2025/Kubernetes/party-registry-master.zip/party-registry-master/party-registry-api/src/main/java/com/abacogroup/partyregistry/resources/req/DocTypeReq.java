package com.abacogroup.partyregistry.resources.req;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

@Data
@NoArgsConstructor
@Accessors(chain = true)
public class DocTypeReq {

	private static final String DOC_TYPE_REGEXP = "^[A-Z\\d_]{1,100}$";

	@NotNull
	@Pattern(regexp = DOC_TYPE_REGEXP)
	private String docType;
}
