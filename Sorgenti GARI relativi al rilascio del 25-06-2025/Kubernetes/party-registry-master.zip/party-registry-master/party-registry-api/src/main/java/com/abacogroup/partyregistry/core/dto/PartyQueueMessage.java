package com.abacogroup.partyregistry.core.dto;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.time.LocalDateTime;
import lombok.Data;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder(setterPrefix = "set")
public class PartyQueueMessage {

	private final String tenant;
	private final String username;
	private final String lang;
	private final Long partyId;
	private final LocalDateTime date;

	private final PartyEventType eventType;

	@JsonCreator
	public PartyQueueMessage(@JsonProperty("tenant") String tenant,
			@JsonProperty("username") String username,
			@JsonProperty("lang") String lang,
			@JsonProperty("partyId") Long partyId,
			@JsonProperty("date") LocalDateTime date,
			@JsonProperty("eventType") PartyEventType eventType) {
		this.tenant = tenant;
		this.username = username;
		this.lang = lang;
		this.partyId = partyId;
		this.date = date;
		this.eventType = eventType;
	}

	public String getRoutingKey() {
		return eventType.getTopic();
	}

}
