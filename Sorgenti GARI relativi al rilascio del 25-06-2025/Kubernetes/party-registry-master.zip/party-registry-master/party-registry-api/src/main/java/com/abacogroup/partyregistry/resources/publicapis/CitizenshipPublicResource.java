package com.abacogroup.partyregistry.resources.publicapis;

import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.partyregistry.api.v1.CitizenshipResponseV1;
import com.abacogroup.partyregistry.api.v1.req.CitizenshipSearchRequestV1;
import com.abacogroup.partyregistry.core.CitizenshipV1Service;
import com.abacogroup.partyregistry.resources.PublicResourceConstants;
import com.abacogroup.partyregistry.resources.req.ReqContext;
import io.dropwizard.auth.Auth;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.ws.rs.BeanParam;
import jakarta.ws.rs.DefaultValue;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.HeaderParam;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.MediaType;

@SuppressWarnings("UnresolvedRestParam")
@Path(PublicResourceConstants.API_V1_PUB + "/citizenships")
@Produces(MediaType.APPLICATION_JSON)
@Tag(name = "Citizenship", description = "Operations on citizenships")
public class CitizenshipPublicResource {
	
	private CitizenshipV1Service citizenshipV1Service;
	
	public CitizenshipPublicResource (CitizenshipV1Service citizenshipV1Service) {
		this.citizenshipV1Service = citizenshipV1Service;
	}
    
	@GET
	public InfiniteListResults<CitizenshipResponseV1> search(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "tenant ID") @PathParam("tenant") String tenantId,
			@Parameter(description = "Can be supplied to obtain the records that follows those obtained by a previous call") @QueryParam("nextKey") String nextKey,
			@BeanParam CitizenshipSearchRequestV1 searchRequest) {

		
		ReqContext reqContext = new ReqContext(user, lang);
		return citizenshipV1Service.search(reqContext, searchRequest, nextKey);
	}
	
	@GET
	@Path("/{code}")
	public CitizenshipResponseV1 getByCode(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "tenant ID") @PathParam("tenant") String tenantId,
			@Parameter(description = "the citizenship CODE") @PathParam("code") String code
	) {

		ReqContext reqContext = new ReqContext(user, lang);
		return citizenshipV1Service.getByCode(reqContext, code)
				.orElse(null);
	}
	
}
