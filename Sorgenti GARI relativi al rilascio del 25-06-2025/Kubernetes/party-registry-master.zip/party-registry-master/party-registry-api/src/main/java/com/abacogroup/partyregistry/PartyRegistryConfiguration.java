package com.abacogroup.partyregistry;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.dropwizard.client.JerseyClientConfiguration;
import io.dropwizard.core.Configuration;
import io.dropwizard.db.DataSourceFactory;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Data
public class PartyRegistryConfiguration extends Configuration {

	private boolean cors = true;

	@Valid
	@NotNull
	private DataSourceFactory database;

	private RabbitmqConfig rabbitmqConfig;

	@JsonProperty("lau-url")
	private String lauUrl;

	@Valid
	private Sso2Config sso2Config;

	@Valid
	private BundleConfig bundleConfig;

	@Valid
	private FileStoreConfig fileStoreConfig;

	@Valid
	private AclConfig aclConfig;

	private String dynamicDocumentsBucket;

	@JsonProperty("devtools-enabled")
	private boolean devToolsEnabled = false;

	private SwaggerConfig swagger = new SwaggerConfig();

	@Valid
	@NotNull
	@Getter
	@Setter
	private JerseyClientConfiguration jerseyClient = new JerseyClientConfiguration();

	@Valid
	@NotNull
	@Getter
	@Setter
	private JerseyClientConfiguration externalServiceJerseyClient = new JerseyClientConfiguration();

	@Data
	public static class RabbitmqConfig {

		private String host;
		private String user;
		private String password;
		private String virtualhost;
		private Integer port;
	}

	@Data
	public static class FileStoreConfig {
		private String url;
	}

	@Data
	public static class Sso2Config {
		private String url;
		private String tasksAuthPhrase;
	}
	
	@Data
	public static class AclConfig {
		private String url;
		private String rabbitQueue;
		private boolean ignoreAcl = true;
	}

	@Data
	public static class SwaggerConfig {
		private boolean enabled = true;
		private boolean includeSwaggerResource = true;
//		private boolean readAllResources = true;
		private String contextRoot = "/";
		private String openapiConfigurationLocation = "openapi-configuration.yaml";
	}

}
