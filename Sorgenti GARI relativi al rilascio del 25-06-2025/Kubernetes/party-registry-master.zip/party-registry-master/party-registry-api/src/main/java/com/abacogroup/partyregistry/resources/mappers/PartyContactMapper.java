package com.abacogroup.partyregistry.resources.mappers;

import com.abacogroup.partyregistry.api.PartyContact;
import com.abacogroup.partyregistry.db.ntt.PartyContactEntity;
import com.abacogroup.partyregistry.dto.v1.PartyContactExternalDtoV1;
import com.abacogroup.partyregistry.resources.req.PartyContactReq;
import org.mapstruct.Mapper;
import org.mapstruct.MappingTarget;
import org.mapstruct.factory.Mappers;

@Mapper
public interface PartyContactMapper {

	PartyContactMapper INSTANCE = Mappers.getMapper(PartyContactMapper.class);

	PartyContact entityToDto(PartyContactEntity entity);

	PartyContactEntity dtoToEntity(PartyContact dto);

	PartyContactEntity requestToEntity(PartyContactReq dto);

	PartyContactReq externalToReq(PartyContactExternalDtoV1 externalDto);

	void updateEntity(PartyContactReq dto, @MappingTarget PartyContactEntity targetEntity);
}
