package com.abacogroup.partyregistry.resources.req;

import com.abacogroup.jdbi.criteria.Criteria;
import com.abacogroup.jdbi.criteria.CriteriaBuilder;
import com.abacogroup.jdbi.orderby.OrderBy;
import com.abacogroup.jdbi.orderby.OrderByBuilder;
import com.abacogroup.jdbi.orderby.OrderByElement;
import com.abacogroup.jdbi.orderby.SortDirection;
import com.abacogroup.partyregistry.resources.ResourceConstants;
import com.fasterxml.jackson.annotation.JsonIgnore;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.ws.rs.DefaultValue;
import jakarta.ws.rs.QueryParam;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;
import org.apache.commons.lang3.StringUtils;

@Data
@NoArgsConstructor
@Accessors(chain = true)
public class PartySearchReq implements BaseSearchReq {

	@Parameter(in = ParameterIn.QUERY, description = "last name")
	@QueryParam("lastName")
	private String lastName;

	@Parameter(in = ParameterIn.QUERY, description = "first name")
	@QueryParam("firstName")
	private String firstName;

	@Parameter(in = ParameterIn.QUERY, description = "TAX code")
	@QueryParam("taxCode")
	private String taxCode;
	
	@Parameter(in = ParameterIn.QUERY, description = "party type")
	@QueryParam("partyType")
	private String partyType;

	@Parameter(in = ParameterIn.QUERY, description = "VAT number")
	@QueryParam("vatNumber")
	private String vatNumber;

	@Parameter(in = ParameterIn.QUERY, description = "vat number / tax code")
	@QueryParam("taxOrVat")
	private String taxOrVat;

	@Parameter(in = ParameterIn.QUERY, description = "code")
	@QueryParam("code")
	private String code;

	@Parameter(in = ParameterIn.QUERY, description = "hasCode")
	@QueryParam("hasCode")
	private Boolean hasCode;

	@Parameter(in = ParameterIn.QUERY, description = "fullName")
	@QueryParam("fullName")
	private String fullName;

	@Parameter(in = ParameterIn.QUERY, description = "fullNameOrCode")
	@QueryParam("fullNameOrCode")
	private String fullNameOrCode;

	@Parameter(in = ParameterIn.QUERY, description = "list of tags")
	@QueryParam("tag")
	private List<String> tag;

	@Parameter(in = ParameterIn.QUERY, description = "archived status")
	@DefaultValue("not_archived")
	@QueryParam("archived")
	private ArchivedEnum archived;

	@Override
	@JsonIgnore
	@Schema(hidden = true)
	public int getPageSize() {
		return ResourceConstants.PAGE_SIZE;
	}

	@JsonIgnore
	@Schema(hidden = true)
	@Override
	public Criteria getCriteria(ReqContext reqContext) {
		List<Criteria> specs = new ArrayList<>();
		//specs.add(CriteriaBuilder.string("m.tenant_id").eq(reqContext.getTenantId()));

		Optional.ofNullable(getArchived())
				.ifPresentOrElse(v -> {
							switch (v) {
							case all:
								break;
							case not_archived:
								specs.add(CriteriaBuilder.number("fl_archived").eq(0));
								break;
							case only_archived:
								specs.add(CriteriaBuilder.number("fl_archived").eq(1));
								break;
							}
						},
						() -> specs.add(CriteriaBuilder.number("fl_archived").eq(0))
				);

		//like
		Optional.ofNullable(getLastName())
				.ifPresent(v -> specs.add(CriteriaBuilder.string("last_name").contains(v.toUpperCase())));

		Optional.ofNullable(getFirstName())
				.ifPresent(v -> specs.add(CriteriaBuilder.string("first_name").contains(v.toUpperCase())));

		//eq
		Optional.ofNullable(getCode())
				.ifPresent(v -> specs.add(CriteriaBuilder.string("code").eq(v.toUpperCase())));

		Optional.ofNullable(getTaxCode())
				.ifPresent(v -> specs.add(CriteriaBuilder.string("tax_code").eq(v.toUpperCase())));

		Optional.ofNullable(getVatNumber())
				.ifPresent(v -> specs.add(CriteriaBuilder.string("vat_number").eq(v.toUpperCase())));

		Optional.ofNullable(getHasCode())
				.filter(b -> b)
				.ifPresent(v -> specs.add(CriteriaBuilder.string("code").isNotNull()));

		Optional.ofNullable(getTaxOrVat())
				.ifPresent(v -> specs.add(
						CriteriaBuilder.or(
								CriteriaBuilder.string("tax_code").contains(v.toUpperCase()),
								CriteriaBuilder.string("vat_number").contains(v.toUpperCase())
						)
				));

		Optional.ofNullable(getFullNameOrCode())
				.ifPresent(v -> specs.add(
						CriteriaBuilder.or(
								CriteriaBuilder.string("fullname").contains(v.toUpperCase()),
								CriteriaBuilder.string("code").eq(v.toUpperCase())
						)
				));

		Optional.ofNullable(getFullName())
				.ifPresent(v -> specs.add(CriteriaBuilder.string("fullname").contains(v.toUpperCase())));
		
		
		Optional.ofNullable(getPartyType())
		.ifPresent(v -> specs.add(CriteriaBuilder.string("party_type").eq(v)));

		return CriteriaBuilder.and(specs.toArray(new Criteria[0]));
	}

	@JsonIgnore
	@Schema(hidden = true)
	public Criteria getInnerCriteria(ReqContext reqContext) {
		List<Criteria> specs = new ArrayList<>();
		if (null != getTag() && !getTag().isEmpty()) {
			specs.add(CriteriaBuilder.string("tag_code").in(tag));
		}
		return CriteriaBuilder.and(specs.toArray(new Criteria[0]));
	}

	@Override
	@JsonIgnore
	@Schema(hidden = true)
	public OrderByElement getSort() {
		return OrderByBuilder
				.field("last_name")
				.direction(SortDirection.ASC);
	}

	@JsonIgnore
	@Schema(hidden = true)
	public OrderBy getSortList() {
		return OrderByBuilder.from(
				OrderByBuilder
						.field("last_name")
						.direction(SortDirection.ASC),
				OrderByBuilder
						.field("first_name")
						.direction(SortDirection.ASC),
				OrderByBuilder
						.field("id")
						.direction(SortDirection.ASC)
		);

	}

	@JsonIgnore
	@Schema(hidden = true)
	public boolean isValid() {
		boolean isEmpty = this.getTag().isEmpty()
				&& StringUtils.isBlank(this.getFirstName())
				&& StringUtils.isBlank(this.getLastName())
				&& StringUtils.isBlank(this.getCode())
				&& StringUtils.isBlank(this.getTaxCode())
				&& StringUtils.isBlank(this.getVatNumber())
				&& StringUtils.isBlank(this.getTaxOrVat());
		return !isEmpty;
	}

}
