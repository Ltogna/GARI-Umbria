package com.abacogroup.partyregistry.core;

import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.partyregistry.api.PartyRelationParty;
import com.abacogroup.partyregistry.resources.req.PartyRelationPartySearchReq;
import com.abacogroup.partyregistry.resources.req.ReqContext;
import com.abacogroup.partyregistry.resources.req.rel.PartyRelationItemReq;
import java.util.List;
import java.util.Optional;

public interface PartyRelationPartyService {

	InfiniteListResults<PartyRelationParty> search(ReqContext context, Long partyId, Long relationId,
			PartyRelationPartySearchReq searchReq, String nextKey);

	PartyRelationParty insert(ReqContext context, Long partyId, Long relationId,
			PartyRelationItemReq req);

	void insertAll(ReqContext context, Long partyId, Long relationId, List<PartyRelationItemReq> reqs, boolean sendEvent);

	PartyRelationParty update(ReqContext context, Long partyId, Long relationId, Long pkid, PartyRelationItemReq req);

	void expireRelationParty(ReqContext context, Long partyId, Long relationId, Long pkId);

	// @Override
	Optional<PartyRelationParty> getRelationPartyById(ReqContext reqContext, Long partyId, Long relationId, Long pkId);

}
