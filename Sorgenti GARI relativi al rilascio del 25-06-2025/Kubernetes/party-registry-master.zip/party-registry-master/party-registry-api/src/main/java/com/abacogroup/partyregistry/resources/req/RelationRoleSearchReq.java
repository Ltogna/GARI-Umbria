package com.abacogroup.partyregistry.resources.req;

import com.abacogroup.jdbi.criteria.Criteria;
import com.abacogroup.jdbi.criteria.CriteriaBuilder;
import com.abacogroup.jdbi.orderby.OrderByBuilder;
import com.abacogroup.jdbi.orderby.OrderByElement;
import com.abacogroup.jdbi.orderby.SortDirection;
import com.abacogroup.partyregistry.resources.ResourceConstants;
import com.fasterxml.jackson.annotation.JsonIgnore;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.QueryParam;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;
import org.apache.commons.lang3.StringUtils;

@Data
@NoArgsConstructor
@Accessors(chain = true)
public class RelationRoleSearchReq implements BaseSearchReq {

	@Parameter(in = ParameterIn.PATH, description = "relation type Code")
	@PathParam("relationTypeCode")
	private String relationTypeCode;

	@Parameter(in = ParameterIn.QUERY, description = "relation role code")
	@QueryParam("code")
	private String code;

	@Parameter(in = ParameterIn.QUERY, description = "relation role i18n")
	@QueryParam("i18nCode")
	private String i18nCode;

	@Override
	@JsonIgnore
	@Schema(hidden = true)
	public int getPageSize() {
		return ResourceConstants.PAGE_SIZE;
	}

	@Override
	@JsonIgnore
	@Schema(hidden = true)
	public Criteria getCriteria(ReqContext context) {
		List<Criteria> specs = new ArrayList<>();

		Optional.ofNullable(getCode())
				.ifPresent(v -> specs.add(CriteriaBuilder.string("code").eq(v.toUpperCase())));

		Optional.ofNullable(this.getI18nCode())
				.filter(StringUtils::isNotBlank)
				.ifPresent(v -> specs.add(CriteriaBuilder.string("i18n_code").caseInsensitiveContains(v)));

		Optional.ofNullable(getRelationTypeCode())
				.ifPresent(v -> specs.add(CriteriaBuilder.string("relation_type_code").eq(getRelationTypeCode().toUpperCase())));

		return CriteriaBuilder.and(specs.toArray(new Criteria[0]));
	}

	@Override
	@JsonIgnore
	@Schema(hidden = true)
	public OrderByElement getSort() {
		return OrderByBuilder.field("i18n_code").direction(SortDirection.ASC);
	}

}
