package com.abacogroup.partyregistry.core.exceptions;

import io.swagger.v3.oas.annotations.media.Schema;

public class InvalidPayloadException extends AbstractPartyException {

	public InvalidPayloadException(String code, String message) {
		super(new InvalidPayloadException.ErrorBody(code, message));
	}

	@Schema(name = "InvalidPayloadExceptionErrorBody")
	public static class ErrorBody implements ExceptionErrorBody {
		private final String code;
		private final String message;

		public ErrorBody(String code, String message) {
			this.code = code;
			this.message = message;
		}

		@Override
		@Schema(allowableValues = { ErrCodes.INVALID_PAYLOAD })
		public String getErrorCode() {
			return code;
		}

		@Override
		@Schema
		public String getMessage() {
			return message;
		}
	}

}
