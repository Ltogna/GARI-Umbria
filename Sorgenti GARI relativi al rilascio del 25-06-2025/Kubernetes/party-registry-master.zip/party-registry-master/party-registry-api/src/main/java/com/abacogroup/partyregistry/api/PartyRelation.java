package com.abacogroup.partyregistry.api;

import jakarta.validation.constraints.NotNull;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder(setterPrefix = "set")
@NoArgsConstructor
public class PartyRelation {

	private Long id;

	@NotNull
	private Long partyId;

	private String relationTypeCode;

	private String relationTypeI18nCode;

	private String note;

}
