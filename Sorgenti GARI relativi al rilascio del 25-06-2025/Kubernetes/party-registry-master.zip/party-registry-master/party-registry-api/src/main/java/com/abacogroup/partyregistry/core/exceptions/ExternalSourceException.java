package com.abacogroup.partyregistry.core.exceptions;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.ws.rs.core.Response.Status;

public class ExternalSourceException extends AbstractPartyException {

	public ExternalSourceException(ErrEnum code, String message) {
		super(new ErrorBody(code.name(), message), code.statusCode);
	}

	public ExternalSourceException(ErrEnum code, String message, Throwable throwable) {
		super(new ErrorBody(code.name(), message), code.statusCode, throwable);
	}

	public enum ErrEnum {
		SOURCE_CODE_NOT_FOUND(Status.BAD_REQUEST.getStatusCode()),
		PARTY_NOT_FOUND(Status.NOT_FOUND.getStatusCode()),
		PAYLOAD_NOT_READEABLE(Status.BAD_GATEWAY.getStatusCode()),
		;

		private final int statusCode;

		ErrEnum(int statusCode) {
			this.statusCode = statusCode;
		}
	}

	@Schema(name = "ExternalSourceExceptionErrorBody")
	public static class ErrorBody implements ExceptionErrorBody {
		private final String code;
		private final String message;

		public ErrorBody(String code, String message) {
			this.code = code;
			this.message = message;
		}

		@Override
		@Schema(allowableValues = {
				"SOURCE_CODE_NOT_FOUND",
				"PARTY_NOT_FOUND",
				"PAYLOAD_NOT_READEABLE",
		})
		public String getErrorCode() {
			return code;
		}

		@Override
		public String getMessage() {
			return message;
		}
	}

}
