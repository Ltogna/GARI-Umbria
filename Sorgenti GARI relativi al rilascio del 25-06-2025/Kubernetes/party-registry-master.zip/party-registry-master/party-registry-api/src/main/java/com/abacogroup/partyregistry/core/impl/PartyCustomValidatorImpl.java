package com.abacogroup.partyregistry.core.impl;

import com.abacogroup.partyregistry.core.PartyCustomValidator;
import com.abacogroup.partyregistry.core.PartyFieldValidator;
import com.abacogroup.partyregistry.db.dao.AppConfigDAO;
import com.abacogroup.partyregistry.db.ntt.AppConfigEntity;
import com.abacogroup.partyregistry.db.ntt.PartyEntity;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.function.BiConsumer;
import java.util.stream.Collectors;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class PartyCustomValidatorImpl implements PartyCustomValidator {

	private final AppConfigDAO appConfigDAO;
	private final Map<String, PartyFieldValidator> validatorMap;

	public PartyCustomValidatorImpl(AppConfigDAO appConfigDAO, List<PartyFieldValidator> validators) {
		this.appConfigDAO = appConfigDAO;
		this.validatorMap = Optional.ofNullable(validators)
				.stream().flatMap(Collection::stream)
				.peek(pfv -> log.debug("party field validator '{}' for field '{}'", pfv.getClass().getSimpleName(), pfv.getFieldName()))
				.collect(Collectors.toMap(PartyFieldValidator::getFieldName, pfv -> pfv));
	}

	@Override
	public void validateOnInsert(PartyEntity party, String tenant) {
		this.validate(party, tenant, (validationConfig, partyFieldValidator) -> partyFieldValidator.validateOnInsert(party, validationConfig));
	}

	@Override
	public void validateOnUpdate(PartyEntity party, String tenant) {
		this.validate(party, tenant, (validationConfig, partyFieldValidator) -> partyFieldValidator.validateOnUpdate(party, validationConfig));
	}

	private void validate(PartyEntity party, String tenant, BiConsumer<AppConfigEntity, PartyFieldValidator> validator) {
		Set<String> validatorKeys = validatorMap.keySet();
		if (!validatorKeys.isEmpty()) {
			Set<String> unusedValidators = new HashSet<>(validatorKeys);
			List<AppConfigEntity> appConfigs = appConfigDAO.findByConfigKeyIn(tenant, validatorKeys);

			for (AppConfigEntity appConfig : appConfigs) {
				String fieldName = appConfig.getConfigurationKey();
				PartyFieldValidator partyFieldValidator = validatorMap.get(fieldName);

				validator.accept(appConfig, partyFieldValidator);
				unusedValidators.remove(fieldName);
			}

			for (String unusedValidator : unusedValidators) {
				validatorMap.get(unusedValidator).resetField(party);
			}
		}
	}

}
