package com.abacogroup.partyregistry.api;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder(setterPrefix = "set")
@NoArgsConstructor
public class AppConfig {

	private String configurationKey;
	private String configuration;
}
