package com.abacogroup.partyregistry.api;

import java.util.Map;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder(setterPrefix = "set")
@NoArgsConstructor
public class AppConfigRes {

	private String configurationKey;
	private Map<String, Object> configuration;
}
