package com.abacogroup.partyregistry.resources.req.rel;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

@Data
@NoArgsConstructor
@Accessors(chain = true)
public class CreatePartyRelationReq {

	//private Long partyId;
	private String relationTypeCode;
	private String note;

	private PartyRelationItemReq relationItemReq;

}
