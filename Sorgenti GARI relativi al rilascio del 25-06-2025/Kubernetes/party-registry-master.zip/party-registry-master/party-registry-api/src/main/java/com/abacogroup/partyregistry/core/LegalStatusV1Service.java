package com.abacogroup.partyregistry.core;

import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.partyregistry.api.v1.LegalStatusResponseV1;
import com.abacogroup.partyregistry.api.v1.req.LegalStatusSearchRequestV1;
import com.abacogroup.partyregistry.resources.req.ReqContext;
import java.util.Optional;

public interface LegalStatusV1Service {

	InfiniteListResults<LegalStatusResponseV1> search(ReqContext reqContext, LegalStatusSearchRequestV1 searchRequest, String nextKey);

	Optional<LegalStatusResponseV1> getByCode(ReqContext reqContext, String code);

}
