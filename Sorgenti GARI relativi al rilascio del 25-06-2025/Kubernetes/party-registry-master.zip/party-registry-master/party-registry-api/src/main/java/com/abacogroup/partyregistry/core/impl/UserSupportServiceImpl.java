package com.abacogroup.partyregistry.core.impl;

import com.abacogroup.partyregistry.api.UserPermissions;
import com.abacogroup.partyregistry.core.AclService;
import com.abacogroup.partyregistry.core.UserSupportService;
import com.abacogroup.partyregistry.resources.req.ReqContext;
import com.abacogroup.proxies.cache.core.exception.ResourceNotAuthorizedException;

public class UserSupportServiceImpl implements UserSupportService {

	private final AclService aclService;

	public UserSupportServiceImpl(AclService aclService) {
		this.aclService = aclService;
	}

	@Override
	public UserPermissions getUserPermissions(ReqContext context) {
		boolean canCreateParties = true;
		
		try {
			aclService.canAdd(context);
		} catch (ResourceNotAuthorizedException e) {
			canCreateParties = false;
		} catch (Exception e) {
			throw e;
		}

		return UserPermissions.builder()
				.canCreateParties(canCreateParties)
				.build();
	}
}
