package com.abacogroup.partyregistry.core.exceptions;

import jakarta.ws.rs.WebApplicationException;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.core.Response.Status;
import lombok.Data;

@Data
public abstract class AbstractPartyException extends WebApplicationException {

	private ExceptionErrorBody errorBody;

	protected AbstractPartyException() {
	}

	AbstractPartyException(ExceptionErrorBody body) {
		this(body, Status.BAD_REQUEST.getStatusCode());
	}

	AbstractPartyException(ExceptionErrorBody body, Integer status) {
		super(body.getMessage(),
				Response.status(status)
						.entity(body)
						.build());
		this.errorBody = body;
	}

	AbstractPartyException(ExceptionErrorBody body, Integer status, Throwable throwable) {
		super(body.getMessage(),
				throwable,
				Response.status(status)
						.entity(body)
						.build());
		this.errorBody = body;
	}

	public String getCode() {
		return getErrorBody().getErrorCode();
	}

	public interface ExceptionErrorBody {
		String getErrorCode();

		default String getMessage() {
			return "TODO";
		}
	}

}
