package com.abacogroup.partyregistry.bundle.tenant;

import static com.abacogroup.bundles.Constants.ALL_TENANTS;

import com.abacogroup.bundles.listener.tenant.TenantMessage;
import com.abacogroup.bundles.listener.tenant.TenantMessageProcessor;
import com.abacogroup.partyregistry.core.BundleConstants;
import com.abacogroup.partyregistry.core.impl.AuditHelper;
import com.abacogroup.partyregistry.db.dao.RelationRoleDAO;
import com.abacogroup.partyregistry.db.dao.RelationTypeDAO;
import com.abacogroup.partyregistry.db.ntt.RelationRoleEntity;
import com.abacogroup.partyregistry.db.ntt.RelationTypeEntity;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class RelationsTenantMessageProcessor implements TenantMessageProcessor {

	private final RelationTypeDAO relationTypeDAO;
	private final RelationRoleDAO relationRoleDAO;

	public RelationsTenantMessageProcessor(RelationTypeDAO relationTypeDAO, RelationRoleDAO relationRoleDAO) {
		this.relationTypeDAO = relationTypeDAO;
		this.relationRoleDAO = relationRoleDAO;
	}

	@Override
	public void onMessage(TenantMessage message) {
		String tenantId = message.getTenantId();
		if (relationTypeDAO.countAll(tenantId) > 0L) {
			log.warn("relations already present for tenant {}", tenantId);
			return;
		}
		RelationTypeEntity auditType = new RelationTypeEntity();
		AuditHelper.setAuditForInsert(BundleConstants.SYSTEM_USER, relationTypeDAO, auditType);
		relationTypeDAO.insertNewTenant(ALL_TENANTS, tenantId, auditType);

		RelationRoleEntity auditRole = new RelationRoleEntity();
		AuditHelper.setAuditForInsert(BundleConstants.SYSTEM_USER, relationRoleDAO, auditRole);
		relationRoleDAO.insertNewTenant(ALL_TENANTS, tenantId, auditRole);

	}

}
