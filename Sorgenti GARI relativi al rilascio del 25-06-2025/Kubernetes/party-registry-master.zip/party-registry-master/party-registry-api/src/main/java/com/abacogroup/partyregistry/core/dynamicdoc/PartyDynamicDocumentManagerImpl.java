package com.abacogroup.partyregistry.core.dynamicdoc;

import static com.abacogroup.partyregistry.core.exceptions.ErrCodes.DYNAMIC_DOCUMENT_FILE_NOT_FOUND;

import com.abacogroup.dynamicdocuments.bean.Document;
import com.abacogroup.dynamicdocuments.bean.DocumentDefinition;
import com.abacogroup.dynamicdocuments.bean.InsertDocument;
import com.abacogroup.dynamicdocuments.bean.documentdefinition.fieldset.field.FieldType;
import com.abacogroup.dynamicdocuments.exceptions.UnknownDocumentException;
import com.abacogroup.dynamicdocuments.services.DocumentService;
import com.abacogroup.dynamicdocuments.services.DocumentTypeService;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.partyregistry.api.PartyDocument;
import com.abacogroup.partyregistry.api.PartyDocumentDefinition;
import com.abacogroup.partyregistry.core.PartyEventProducer;
import com.abacogroup.partyregistry.core.PartyService;
import com.abacogroup.partyregistry.core.dto.PartyEventType;
import com.abacogroup.partyregistry.core.exceptions.ErrCodes;
import com.abacogroup.partyregistry.core.exceptions.InvalidDocumentException;
import com.abacogroup.partyregistry.core.exceptions.InvalidPartyException;
import com.abacogroup.partyregistry.core.impl.AuditHelper;
import com.abacogroup.partyregistry.core.impl.PartyDocumentMapper;
import com.abacogroup.partyregistry.db.dao.PartyDocumentDAO;
import com.abacogroup.partyregistry.db.ntt.PartyDocumentEntity;
import com.abacogroup.partyregistry.db.ntt.PartyEntity;
import com.abacogroup.partyregistry.resources.mappers.PartyDocumentDefinitionMapper;
import com.abacogroup.partyregistry.resources.req.DocumentSearchReq;
import com.abacogroup.partyregistry.resources.req.ReqContext;
import jakarta.ws.rs.core.Response;
import java.time.OffsetDateTime;
import java.util.Collection;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class PartyDynamicDocumentManagerImpl implements PartyDynamicDocumentManager {

	private final DocumentTypeService documentTypeService;
	private final DocumentService documentService;

	private final PartyService partyService;

	private final PartyDocumentDAO partyDocumentDAO;

	private final DocumentValidatorFactory validatorFactory;

	private final PartyEventProducer partyEventProducer;

	private final FileStoreProxyClient fileStoreProxyClient;
	private final String dynamicDocumentsBucket;

	public PartyDynamicDocumentManagerImpl(DocumentTypeService documentTypeService, DocumentService documentService,
			PartyDocumentDAO partyDocumentDAO, PartyService partyService,
			DocumentValidatorFactory validatorFactory, PartyEventProducer partyEventProducer,
			FileStoreProxyClient fileStoreProxyClient, String dynamicDocumentsBucket) {
		this.documentTypeService = documentTypeService;
		this.documentService = documentService;
		this.partyDocumentDAO = partyDocumentDAO;
		this.partyService = partyService;
		this.validatorFactory = validatorFactory;
		this.partyEventProducer = partyEventProducer;
		this.fileStoreProxyClient = fileStoreProxyClient;
		this.dynamicDocumentsBucket = dynamicDocumentsBucket;
	}

	@Override
	public InfiniteListResults<PartyDocument> searchByDocType(ReqContext reqContext, DocumentSearchReq searchRequest, String nextKey) {
		return partyDocumentDAO.infinite(
				() -> partyDocumentDAO.searchByPartyIdAndDefinitionCode(searchRequest.getPartyId(), searchRequest.getDefinitionCode(), reqContext),
				nextKey, searchRequest.getPageSize()).map(pd ->
				PartyDocumentMapper.addSummaryFields(reqContext, pd, documentTypeService, documentService, dynamicDocumentsBucket));
	}

	@Override
	public PartyDocument getByDocumentIdAndCode(ReqContext reqContext, Long documentId, String definitionCode) {
		return Optional.of(partyDocumentDAO.getByDocumentIdAndCode(documentId, definitionCode, reqContext))
				.map(partyDocument -> PartyDocumentMapper.addData(reqContext, partyDocument, documentTypeService, documentService, dynamicDocumentsBucket))
				.orElseThrow(() -> new InvalidDocumentException(ErrCodes.DYNAMIC_DOCUMENT_NOT_FOUND, "Document not found"));
	}

	@Override
	public PartyDocumentDefinition getDefinition(ReqContext reqContext, String definitionCode) {
		return documentTypeService.getDocumentDefinition(reqContext.getTenantId(), definitionCode)
				.map(PartyDocumentDefinitionMapper.INSTANCE::toPartyDocumentDefinition)
				.map(partyDocumentDefinition -> partyDocumentDefinition.setBucketName(dynamicDocumentsBucket))
				.orElseThrow(
						() -> new InvalidDocumentException(ErrCodes.DYNAMIC_DOCUMENT_ERR, String.format("error loading definition for %s", definitionCode)));
	}

	@Override
	public List<Document> getByPartyIdAndCode(ReqContext reqContext, Long partyId, String code) {
		return partyDocumentDAO.findEntitiesByDocumentDefCodeAndPartyId(partyId, code, reqContext)
				.stream().map(d -> documentService.getDocumentFromId(d.getDocumentId())).collect(Collectors.toList());
	}

	@Override
	public Response getDocumentFileContent(ReqContext reqContext, Long partyId, Long documentId, String fileId) {
		this.validateCanReadFile(reqContext, partyId, documentId, fileId);

		return fileStoreProxyClient.getFileContent(reqContext.getLang(), reqContext.getUser(), dynamicDocumentsBucket, fileId);
	}

	@Override
	public Response getDocumentFileMetadata(ReqContext reqContext, Long partyId, Long documentId, String fileId) {
		this.validateCanReadFile(reqContext, partyId, documentId, fileId);

		return fileStoreProxyClient.getFileMetadata(reqContext.getLang(), reqContext.getUser(), dynamicDocumentsBucket, fileId);
	}

	private void validateCanReadFile(ReqContext reqContext, Long partyId, Long documentId, String fileId) {
		PartyDocumentEntity partyDocumentEntity = partyDocumentDAO.findEntityByDocumentIdAndPartyId(partyId, documentId, reqContext)
				.orElseThrow(() -> new InvalidDocumentException(ErrCodes.DYNAMIC_DOCUMENT_NOT_FOUND, "Document not found"));

		Document document;
		try {
			document = documentService.getDocumentFromId(partyDocumentEntity.getDocumentId());
		} catch (UnknownDocumentException ude) {
			throw new InvalidDocumentException(ErrCodes.DYNAMIC_DOCUMENT_NOT_FOUND, ude.getMessage());
		}
		DocumentDefinition definition = this.getDefinition(reqContext, partyDocumentEntity.getDefinitionCode());

		boolean containsFileId = definition.getFieldSets().stream()
				.flatMap(fieldSet -> fieldSet.getFields().stream())
				.filter(field -> FieldType.FILE.equals(field.getType()))
				.map(field -> document.getFields().get(field.getCode()))
				.filter(Objects::nonNull)
				.flatMap(fieldValue -> fieldValue instanceof Collection ? ((Collection<?>) fieldValue).stream() : Stream.of(fieldValue))
				.anyMatch(fileId::equals);

		if (!containsFileId) {
			throw new InvalidDocumentException(DYNAMIC_DOCUMENT_FILE_NOT_FOUND,
					String.format("document '%s' of party '%s' does not contain file with id '%s'",
							documentId, partyId, fileId));
		}
	}

	@Override
	public PartyDocument save(ReqContext reqContext, Long partyId, String definitionCode, InsertDocument document, boolean sendEvent) {
		loadCurrentParty(reqContext.getTenantId(), partyId);
		document.setDefCode(definitionCode);
		document.setBusinessId(partyId);
		validatorFactory.getValidator(definitionCode).ifPresent(v -> {
			v.validate(document, this, reqContext);
		});
		PartyDocumentEntity entity = new PartyDocumentEntity();
		entity.setTenantId(reqContext.getTenantId());
		entity.setPartyId(partyId);
		entity.setDefinitionCode(definitionCode);

		Long documentId = partyDocumentDAO.inTransaction(handle -> {
			Long id = store(document.getDoc(), reqContext.getTenantId(), definitionCode, reqContext.getUser().getUserId(),
					document.getBusinessId(), document.getLabel());
			entity.setDocumentId(id);
			AuditHelper.setAuditForInsert(entity, reqContext.getUsername(), partyDocumentDAO);
			this.partyDocumentDAO.insert(entity);

			if (sendEvent) {
				partyEventProducer.pushPartyEvent(reqContext, partyId, PartyEventType.UPDATE_PARTY);
			}
			return id;
		});
		return getByDocumentIdAndCode(reqContext, documentId, definitionCode);
	}

	private Long store(Document document, String tenantId, String definitionCode, String userID, Long partyId,
			String label) {
		document.setValidFrom(OffsetDateTime.now());
		document.setValidTo(Optional.ofNullable(document.getValidTo()).orElse(INFINITY));
		return documentService.insertDocument(tenantId, definitionCode, document, userID, partyId, label);
	}

	@Override
	public PartyDocument update(ReqContext reqContext, Long partyId, Long documentId, Document updateReq) {
		loadCurrentParty(reqContext.getTenantId(), partyId);
		PartyDocumentEntity entity = partyDocumentDAO.findEntityByDocumentId(documentId, reqContext)
				.filter(d -> Objects.equals(d.getPartyId(), partyId))
				.orElseThrow(() -> new InvalidPartyException(ErrCodes.PARTY_NOT_FOUND, "Party not found"));

		Document doc = Optional.of(documentService.getDocumentFromId(documentId))
				.orElseThrow(() -> new InvalidDocumentException(ErrCodes.DYNAMIC_DOCUMENT_NOT_FOUND, "Document not found"));
		doc.setValidFrom(Optional.ofNullable(updateReq.getValidFrom()).orElse(doc.getValidFrom()));
		doc.setValidTo(Optional.ofNullable(updateReq.getValidTo()).orElse(doc.getValidTo()));
		doc.setFields(Optional.ofNullable(updateReq.getFields()).orElse(doc.getFields()));
		entity.setTenantId(reqContext.getTenantId());
		entity.setPartyId(partyId);
		entity.setDocumentId(documentId);

		Long pkId = partyDocumentDAO.inTransaction(handle -> {
			documentService.updateDocument(documentId, doc, reqContext.getUser().getUserId());
			Consumer<PartyDocumentEntity> expire = handle::expireRow;
			Function<PartyDocumentEntity, Long> insert = handle::insert;
			Long id = AuditHelper.update(entity, reqContext.getUsername(), expire, insert, handle.getCurrentTimestamp());

			partyEventProducer.pushPartyEvent(reqContext, partyId, PartyEventType.UPDATE_PARTY);
			return id;
		});

		return getByDocumentIdAndCode(reqContext, documentId, entity.getDefinitionCode());

	}

	@Override
	public void expire(ReqContext reqContext, Long partyId, Long documentId) {
		loadCurrentParty(reqContext.getTenantId(), partyId);
		PartyDocumentEntity entity = partyDocumentDAO.findEntityByDocumentId(documentId, reqContext)
				.filter(d -> Objects.equals(d.getPartyId(), partyId))
				.orElseThrow(() -> new InvalidDocumentException(ErrCodes.DYNAMIC_DOCUMENT_NOT_FOUND, "Party not found"));
		partyDocumentDAO.useTransaction(handle -> {
			this.doExpire(reqContext, entity);
			partyEventProducer.pushPartyEvent(reqContext, partyId, PartyEventType.UPDATE_PARTY);
		});
	}

	@Override
	public void expireAll(ReqContext reqContext, Long partyId, String defCode, boolean sendEvent) {
		loadCurrentParty(reqContext.getTenantId(), partyId);
		partyDocumentDAO.useTransaction(handle -> {
			partyDocumentDAO.findEntitiesByDocumentDefCodeAndPartyId(partyId, defCode, reqContext)
					.forEach(entity -> this.doExpire(reqContext, entity));
			if (sendEvent) {
				partyEventProducer.pushPartyEvent(reqContext, partyId, PartyEventType.UPDATE_PARTY);
			}
		});
	}

	private void doExpire(ReqContext reqContext, PartyDocumentEntity entity) {
		Document doc = Optional.of(documentService.getDocumentFromId(entity.getDocumentId()))
				.orElseThrow(() -> new InvalidDocumentException(ErrCodes.DYNAMIC_DOCUMENT_NOT_FOUND, "Document not found"));

		doc.setValidTo(OffsetDateTime.now());
		documentService.updateDocument(entity.getDocumentId(), doc, reqContext.getUser().getUserId());

		Consumer<PartyDocumentEntity> expire = partyDocumentDAO::expireRow;
		AuditHelper.expire(entity, reqContext.getUsername(), expire, partyDocumentDAO.getCurrentTimestamp());
	}

	private PartyEntity loadCurrentParty(String tenantId, Long id) {
		return partyService.loadEntity(tenantId, id)
				.orElseThrow(() -> new InvalidPartyException(ErrCodes.PARTY_NOT_FOUND, String.format("party %s not found", id)));
	}

}
