package com.abacogroup.partyregistry.resources.publicapis.mapper;

import com.abacogroup.partyregistry.api.v1.lau.MunicipalityResponseV1;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper
public interface MunicipalityResMapper {

	MunicipalityResMapper INSTANCE = Mappers.getMapper(MunicipalityResMapper.class);

	MunicipalityResponseV1 fromLau(com.abacogroup.lau.api.v1.MunicipalityResponseV1 lauMunicipalityResponseV1);

}
