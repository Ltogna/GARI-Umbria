package com.abacogroup.partyregistry.core;

import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.partyregistry.api.v1.PartyResponseV1;
import com.abacogroup.partyregistry.api.v1.PartySearchResponseV1;
import com.abacogroup.partyregistry.api.v1.req.PartyByIdInSearchRequestV1;
import com.abacogroup.partyregistry.api.v1.req.PartySearchRequestV1;
import com.abacogroup.partyregistry.resources.req.ReqContext;
import java.util.List;
import java.util.Optional;

public interface PartyV1Service extends PublicService {

	InfiniteListResults<PartySearchResponseV1> publicSearch(ReqContext reqContext, PartySearchRequestV1 partySearchReq, Integer withManage, String nextKey);

	List<PartySearchResponseV1> getPartyResponseByIdIn(ReqContext reqContext, PartyByIdInSearchRequestV1 partySearchReq, Integer withManage);

	Optional<PartyResponseV1> getPartyResponseById(ReqContext reqContext, Long id);

	Optional<PartyResponseV1> getPartyResponseByCode(ReqContext reqContext, String code);

}
