package com.abacogroup.partyregistry.resources.req;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@NoArgsConstructor
@SuperBuilder(setterPrefix = "set")
public class RelationRoleReq {

	private static final String CODE_REGEXP_1_100 = "^[A-Z\\d_]{1,100}$";

	@NotNull
	@Pattern(regexp = CODE_REGEXP_1_100)
	private String code;

	//  @NotNull
	//  @Pattern(regexp = CODE_REGEXP_1_100)
	private String typeCode;
}
