package com.abacogroup.partyregistry.bundle.config;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.apache.commons.lang3.StringUtils;

import com.abacogroup.bundles.initializer.impl.exceptions.BundleException;
import com.abacogroup.bundles.listener.configdata.ConfigDataMessage;
import com.abacogroup.bundles.listener.configdata.ConfigMessageProcessor;
import com.abacogroup.dynamicdocuments.bean.Document;
import com.abacogroup.dynamicdocuments.bean.InsertDocument;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.partyregistry.api.GenderEnum;
import com.abacogroup.partyregistry.api.PartyDocument;
import com.abacogroup.partyregistry.api.PartyRelation;
import com.abacogroup.partyregistry.api.PartyRelationParty;
import com.abacogroup.partyregistry.api.PartyRes;
import com.abacogroup.partyregistry.api.PartyTypeEnum;
import com.abacogroup.partyregistry.core.BundleConstants;
import com.abacogroup.partyregistry.core.PartyRelationPartyService;
import com.abacogroup.partyregistry.core.PartyRelationService;
import com.abacogroup.partyregistry.core.dynamicdoc.PartyDynamicDocumentManager;
import com.abacogroup.partyregistry.core.impl.PartyServiceImpl;
import com.abacogroup.partyregistry.resources.req.PartyCreateReq;
import com.abacogroup.partyregistry.resources.req.ReqContext;
import com.abacogroup.partyregistry.resources.req.rel.CreatePartyRelationReq;
import com.abacogroup.partyregistry.resources.req.rel.PartyRelationItemReq;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.Data;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Deprecated
public class PartyConfigMessageProcessor implements ConfigMessageProcessor {

	private static final String NO_EXTERNAL_SOURCE_CODE = null;
	
	//	private final PartyDAO partyDAO;

	private final PartyServiceImpl partyService;
	private final PartyRelationService partyRelationService;
	private final PartyRelationPartyService partyRelationPartyService;
	private final PartyDynamicDocumentManager partyDynamicDocumentManager;
	private final ObjectMapper mapper = new ObjectMapper()
			.disable(DeserializationFeature.FAIL_ON_IGNORED_PROPERTIES)
			.findAndRegisterModules();

	public PartyConfigMessageProcessor(PartyServiceImpl partyService, PartyRelationService partyRelationService,
			PartyRelationPartyService partyRelationPartyService, PartyDynamicDocumentManager partyDynamicDocumentManager) {
		this.partyService = partyService;
		this.partyRelationPartyService = partyRelationPartyService;
		this.partyRelationService = partyRelationService;
		this.partyDynamicDocumentManager = partyDynamicDocumentManager;
	}

	@Override public String getDomainName() {
		return BundleConstants.PARTY;
	}

	@Override
	public void onMessage(ConfigDataMessage message) {
		String tenantId = message.getTenantId();
		message.getConfigFiles().forEach(path -> {
			addContent(tenantId, path);
		});
	}

	private ReqContext getReqContext(String tenantId) {
		return new ReqContext(tenantId, "admin", "it");
	}

	protected void addContent(String tenantId, Path path) {
		try {
			List<IPartyEntry> entries = readEntities(tenantId, path);

			Map<EntryType, List<IPartyEntry>> entriesMap = entries.stream()
					.collect(Collectors.groupingBy(
							IPartyEntry::getEntryType, HashMap::new, Collectors.toCollection(ArrayList::new))
					);

			//List<PartyEntry> parties = entriesMap.get(EntryType.PARTY)
			entriesMap.getOrDefault(EntryType.PARTY, Collections.emptyList())
					.stream()
					.map(x -> (PartyEntry) x)
					.forEach(x -> storePartyVoid(tenantId, x));

			entriesMap.getOrDefault(EntryType.PARTY_TAGS, Collections.emptyList())
					.stream()
					.map(x -> (PartyTagEntry) x)
					.forEach(x -> storeTagVoid(entriesMap, tenantId, x));

			entriesMap.getOrDefault(EntryType.PARTY_RELATIONS, Collections.emptyList())
					.stream()
					.map(x -> (PartyRelationsEntry) x)
					.forEach(x -> storeRelationsVoid(entriesMap, tenantId, x));

			entriesMap.getOrDefault(EntryType.PARTY_RELATION, Collections.emptyList())
					.stream()
					.map(x -> (PartyRelationEntry) x)
					.forEach(x -> storeRelationVoid(entriesMap, tenantId, x));

			entriesMap.getOrDefault(EntryType.DYN_DOC, Collections.emptyList())
					.stream()
					.map(x -> (PartyDynDocEntry) x)
					.forEach(x -> storeDynamicDoc(entriesMap, tenantId, x));

		} catch (Exception e) {
			throw new BundleException(String.format("error saving file %s", path), e);
		}
	}

	private void storePartyVoid(String tenantId, PartyEntry entry) {
		var partyCreateRequest = toPartyRequest(entry);
		PartyRes party = partyService.insert(getReqContext(tenantId), partyCreateRequest, NO_EXTERNAL_SOURCE_CODE);
		entry.setId(party.getId());
	}

	private void storeTagVoid(Map<EntryType, List<IPartyEntry>> entriesMap, String tenantId, PartyTagEntry tagEntry) {
		Long partyId = Optional.ofNullable(tagEntry.getPartyId())
				.orElseGet(() -> entriesMap.get(EntryType.PARTY).stream()
						.map(e -> (PartyEntry) e)
						.filter(e -> e.getFlyId().equals(tagEntry.getPartyRef()))
						.map(PartyEntry::getId)
						.findFirst()
						.orElseThrow(() -> new RuntimeException("party not found for tag entry- " + tagEntry))
				);
		Arrays.stream(tagEntry.getCode().split(","))
				.map(String::strip)
				.forEach(code -> this.partyService.attachTag(getReqContext(tenantId), partyId, code));
		//.collect(Collectors.toList());
		//this.partyService.attachTag(getReqContext(tenantId), partyId, tagEntry.getCode());
	}

	private void storeRelationsVoid(Map<EntryType, List<IPartyEntry>> entriesMap, String tenantId, PartyRelationsEntry entry) {
		Long partyId = Optional.ofNullable(entry.getPartyId())
				.orElseGet(() -> entriesMap.get(EntryType.PARTY).stream()
						.map(e -> (PartyEntry) e)
						.filter(e -> e.getFlyId().equals(entry.getPartyRef()))
						.map(PartyEntry::getId)
						.findFirst()
						.orElseThrow(() -> new RuntimeException("party not found for realtions - " + entry))
				);
		PartyRelation partyRelation = this.partyRelationService.save(getReqContext(tenantId),
				partyId, new CreatePartyRelationReq()
						.setRelationTypeCode(entry.getRelationType())
						.setNote(entry.getNote()));
		entry.setId(partyRelation.getId());
		entry.setPartyId(partyId);
	}

	private void storeRelationVoid(Map<EntryType, List<IPartyEntry>> entriesMap, String tenantId, PartyRelationEntry entry) {
		Long partyId = null;
		Long relationId = null;
		if (entry.getRelationId() != null) {
			var rel = this.partyRelationService
					.getRelationById(getReqContext(tenantId), entry.getPartyId(), entry.getRelationId()).orElseThrow();
			partyId = rel.getPartyId();
			relationId = rel.getId();
		} else {
			PartyRelationsEntry relationsEntry = entriesMap.get(EntryType.PARTY_RELATIONS).stream()
					.map(e -> (PartyRelationsEntry) e)
					.filter(e -> e.getFlyId().equals(entry.getRelationRef()))
					.findFirst().orElseThrow();
			partyId = relationsEntry.getPartyId();
			relationId = relationsEntry.getId();
		}

		Long relatedPartyId = Optional.ofNullable(entry.getPartyId())
				.orElseGet(() -> entriesMap.get(EntryType.PARTY).stream()
						.map(e -> (PartyEntry) e)
						.filter(e -> e.getFlyId().equals(entry.getPartyRef()))
						.map(PartyEntry::getId)
						.findFirst()
						.orElseThrow(() -> new RuntimeException("party not found for relation - " + entry))
				);

		PartyRelationParty partyRelation = this.partyRelationPartyService.insert(getReqContext(tenantId),
				partyId,
				relationId,
				new PartyRelationItemReq()
						.setRelatedPartyId(relatedPartyId)
						.setRelatedRoleCode(entry.getRole())
						.setDtStart(AbsoluteDate.of(entry.getDtStart()))
						.setDtEnd(AbsoluteDate.of(entry.getDtEnd())));

		entry.setPkId(partyRelation.getPkid());
	}

	private void storeDynamicDoc(Map<EntryType, List<IPartyEntry>> entriesMap, String tenantId, PartyDynDocEntry entry) {
		Long partyId = Optional.ofNullable(entry.getPartyId())
				.orElseGet(() -> entriesMap.get(EntryType.PARTY).stream()
						.map(e -> (PartyEntry) e)
						.filter(e -> e.getFlyId().equals(entry.getPartyRef()))
						.map(PartyEntry::getId)
						.findFirst()
						.orElseThrow(() -> new RuntimeException("party not found for tag entry- " + entry))
				);

		PartyDocument partyDocument = partyDynamicDocumentManager.save(
				getReqContext(tenantId), partyId, entry.getDefinitionCode(), entry.createInsertDocument(partyId));
		entry.setDocumentId(partyDocument.getDocumentId());

	}

	private PartyCreateReq toPartyRequest(PartyEntry entry) {
		return PartyCreateReq.builder()
				.setPartyType(entry.getPartyType())
				.setLastName(StringUtils.upperCase(entry.getLastName()))
				.setFirstName(StringUtils.upperCase(entry.getFirstName()))
				.setGender(entry.getGender())
				.setTaxCode(entry.getTaxCode())
				.setVatNumber(entry.getVatNumber())
				.setBirthDate(entry.getBirthDate())
				.setBirthMunicipality(entry.getBirthMunicipality())
				.setNationality(entry.getNationality())
				.setArchived(entry.isArchived())
				.build();
	}

	private List<IPartyEntry> readEntities(String tenantId, Path path) throws IOException {
		try (Stream<String> input = Files.lines(path, StandardCharsets.UTF_8)) {
			List<IPartyEntry> entities = input
					.map(String::strip)
					.filter(s -> !StringUtils.isBlank(s))
					.filter(s -> !s.startsWith(BundleConstants.JSONL_COMMENT))
					.map(jsonLine -> mapEntry(tenantId, jsonLine))
					.collect(Collectors.toList());
			return entities;
		}
	}

	protected IPartyEntry mapEntry(String tenantId, String jsonLine) {
		try {
			IPartyEntry entry;
			if (StringUtils.contains(jsonLine, "\"_type\": \"PARTY\"")) {
				entry = mapPartyEntry(jsonLine);
			} else if (StringUtils.contains(jsonLine, "\"_type\": \"PARTY_TAGS\"")) {
				entry = mapPartyTag(jsonLine);
			} else if (StringUtils.contains(jsonLine, "\"_type\": \"PARTY_RELATIONS\"")) {
				entry = mapPartyRelations(jsonLine);
			} else if (StringUtils.contains(jsonLine, "\"_type\": \"PARTY_RELATION\"")) {
				entry = mapPartyRelation(jsonLine);
			} else if (StringUtils.contains(jsonLine, "\"_type\": \"DYN_DOC\"")) {
				entry = mapPartyDinDoc(jsonLine);
			} else {
				throw new BundleException("entry not found for json " + jsonLine);
			}
			return entry;
		} catch (Exception e) {
			throw new BundleException("error in deserialization json " + jsonLine, e);
		}
	}

	private IPartyEntry mapPartyEntry(String jsonLine) throws JsonProcessingException {
		PartyEntry entry = mapper.readValue(jsonLine, PartyEntry.class);
		if (StringUtils.isBlank(entry.getFlyId()) && entry.getId() == null) {
			log.warn("party invalido. devi specificare _id  {}", jsonLine);
			throw new BundleException("missing pk. id or ref are required ");
		}
		return entry;
	}

	private IPartyEntry mapPartyTag(String jsonLine) throws JsonProcessingException {
		PartyTagEntry entry = mapper.readValue(jsonLine, PartyTagEntry.class);
		if (StringUtils.isBlank(entry.getPartyRef()) && null == entry.getPartyId()) {
			log.warn("entry invalido. devi specificare un valore tra party_id e party_ref {}", jsonLine);
			throw new BundleException("error");
		}
		return entry;
	}

	private IPartyEntry mapPartyRelations(String jsonLine) throws JsonProcessingException {
		PartyRelationsEntry entry = mapper.readValue(jsonLine, PartyRelationsEntry.class);
		if (StringUtils.isBlank(entry.getFlyId())) {
			log.warn("entry invalido. devi specificare un valore {}", jsonLine);
			throw new BundleException("error");
		}
		return entry;
	}

	private IPartyEntry mapPartyRelation(String jsonLine) throws JsonProcessingException {
		PartyRelationEntry entry = mapper.readValue(jsonLine, PartyRelationEntry.class);
		if (StringUtils.isBlank(entry.getRelationRef()) && null == entry.getRelationId()) {
			log.warn("entry invalido. devi specificare un valore {}", jsonLine);
			throw new BundleException("error");
		}
		return entry;
	}

	private IPartyEntry mapPartyDinDoc(String jsonLine) throws JsonProcessingException {
		PartyDynDocEntry entry = mapper.readValue(jsonLine, PartyDynDocEntry.class);
		if (StringUtils.isBlank(entry.getPartyRef()) && null == entry.getPartyId()) {
			log.warn("entry invalido. devi specificare un valore tra party_id e party_ref {}", jsonLine);
			throw new BundleException("error");
		}
		return entry;
	}

	protected enum EntryType {
		PARTY,
		PARTY_TAGS,
		PARTY_RELATIONS,
		PARTY_RELATION,
		DYN_DOC,

		CONTACT
	}

	protected interface IPartyEntry {
		EntryType getEntryType();
	}

	@Data
	@JsonIgnoreProperties(ignoreUnknown = true)
	public static class PartyEntry implements IPartyEntry {

		@JsonProperty("_type")
		private EntryType entryType;

		@JsonProperty("_id")
		private String flyId;

		private Long id;
		private PartyTypeEnum partyType;
		private GenderEnum gender;
		private String lastName;
		private String firstName;
		private String taxCode;
		private String vatNumber;

		private AbsoluteDate birthDate;
		private String birthMunicipality;
		private String nationality;

		private boolean archived = false;
	}

	@Data
	@JsonIgnoreProperties(ignoreUnknown = true)
	protected static class PartyTagEntry implements IPartyEntry {

		@JsonProperty("_type")
		private EntryType entryType;

		@JsonProperty("party_ref")
		private String partyRef;

		@JsonProperty("party_id")
		private Long partyId;

		private String code;
	}

	@Data
	@JsonIgnoreProperties(ignoreUnknown = true)
	protected static class PartyRelationsEntry implements IPartyEntry {

		@JsonProperty("_type")
		private EntryType entryType;

		@JsonProperty("_id")
		private String flyId;

		private Long id;

		@JsonProperty("party_ref")
		private String partyRef;

		@JsonProperty("party_id")
		private Long partyId;

		@JsonProperty("relation_type")
		private String relationType;

		private String note;
	}

	@Data
	@JsonIgnoreProperties(ignoreUnknown = true)
	protected static class PartyRelationEntry implements IPartyEntry {

		@JsonProperty("_type")
		private EntryType entryType;

		@JsonProperty("relation_ref")
		private String relationRef;

		private Long pkId;

		@JsonProperty("relation_id")
		private Long relationId;

		@JsonProperty("party_ref")
		private String partyRef;

		@JsonProperty("party_id")
		private Long partyId;

		private String role;

		@JsonProperty("dt_start")
		private String dtStart;

		@JsonProperty("dt_end")
		private String dtEnd = "99991231";
	}

	@Data
	@JsonIgnoreProperties(ignoreUnknown = true)
	protected static class PartyDynDocEntry implements IPartyEntry {

		@JsonProperty("_type")
		private EntryType entryType;

		@JsonProperty("party_ref")
		private String partyRef;

		@JsonProperty("party_id")
		private Long partyId;

		private Long documentId;

		private Map<String, Map<String, Object>> doc;

		protected String getDefinitionCode() {
			if (null == doc) {
				return null;
			}
			return doc.keySet().stream().findFirst().orElse(null);
		}

		protected Map<String, Object> getFields() {
			String defCode = getDefinitionCode();
			if (null == defCode) {
				return null;
			}
			return doc.get(defCode);
		}

		protected InsertDocument createInsertDocument(Long partyId) {
			Document doc = new Document();

			//Map<String, Object> fields = DynamicDocumentUtils.createMultiDoc(getFields());
			doc.setFields(getFields());
			InsertDocument insertDocument = new InsertDocument();
			insertDocument.setDefCode(getDefinitionCode());
			insertDocument.setDoc(doc);
			insertDocument.setBusinessId(partyId);
			return insertDocument;
		}
	}

}
