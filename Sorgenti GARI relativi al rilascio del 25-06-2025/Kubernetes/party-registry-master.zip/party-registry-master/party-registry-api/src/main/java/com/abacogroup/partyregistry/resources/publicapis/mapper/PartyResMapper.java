package com.abacogroup.partyregistry.resources.publicapis.mapper;

import com.abacogroup.partyregistry.api.PartyRes;
import com.abacogroup.partyregistry.api.PartySearchRes;
import com.abacogroup.partyregistry.api.v1.PartyResponseV1;
import com.abacogroup.partyregistry.api.v1.PartySearchResponseV1;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper
public interface PartyResMapper {

	PartyResMapper INSTANCE = Mappers.getMapper(PartyResMapper.class);

	PartySearchResponseV1 toV1(PartySearchRes partySearchRes);

	PartyResponseV1 toV1(PartyRes party);
}
