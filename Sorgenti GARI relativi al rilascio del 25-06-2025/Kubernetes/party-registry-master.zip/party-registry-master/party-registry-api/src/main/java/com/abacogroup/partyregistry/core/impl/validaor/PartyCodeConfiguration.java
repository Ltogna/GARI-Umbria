package com.abacogroup.partyregistry.core.impl.validaor;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;
import lombok.experimental.SuperBuilder;

@Data
@Accessors(chain = true)
@SuperBuilder(setterPrefix = "set")
@AllArgsConstructor
@NoArgsConstructor
public class PartyCodeConfiguration {

	private boolean mandatory = false;
	private boolean editable = true;

}
