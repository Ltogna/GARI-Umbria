package com.abacogroup.partyregistry.db.dao;

public interface Auditable {

}
