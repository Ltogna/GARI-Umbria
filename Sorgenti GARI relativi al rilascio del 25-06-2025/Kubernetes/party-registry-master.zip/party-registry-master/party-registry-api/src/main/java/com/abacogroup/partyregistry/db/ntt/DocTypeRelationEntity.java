package com.abacogroup.partyregistry.db.ntt;

import com.abacogroup.jdbi.model.AuditEntity;
import com.abacogroup.partyregistry.api.PartyTypeEnum;
import java.time.LocalDateTime;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder(setterPrefix = "set")
@NoArgsConstructor
public class DocTypeRelationEntity implements AuditEntity {

	private Long pkId;
	private Long docTypeId;
	private PartyTypeEnum partyType;

	private LocalDateTime dtInsert;
	private String userIdInsert;
	private LocalDateTime dtDelete;
	private String userIdDelete;
}
