package com.abacogroup.partyregistry.db.dao;

import com.abacogroup.jdbi.EnhancedSqlObject;
import com.abacogroup.jdbi.model.AuditEntity;
import com.abacogroup.partyregistry.api.ExternalSourceRes;
import com.abacogroup.partyregistry.db.ntt.ExternalSourceEntity;
import com.abacogroup.partyregistry.resources.req.ReqContext;
import java.util.List;
import java.util.Optional;
import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.customizer.BindBean;
import org.jdbi.v3.sqlobject.statement.GetGeneratedKeys;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;
import org.jdbi.v3.sqlobject.transaction.Transactional;

public interface ExternalSourceDAO extends Transactional<ExternalSourceDAO>, EnhancedSqlObject {

	String I18N = " \n, coalesce (§i18n(:tenantId, 'prt_external_sources', 'code', code, :lang)§, code) as description\n ";

	@SqlUpdate("insert into prt_external_sources (tenant_id, code, url, fl_allow_manual, dt_insert, user_id_insert, dt_delete, user_id_delete) " +
			"values (:tenantId, UPPER(:code), :url, :flAllowManual, :dtInsert, :userIdInsert, :dtDelete, :userIdDelete)")
	@GetGeneratedKeys("pkid")
	Long insert(@BindBean ExternalSourceEntity entity);

	@SqlUpdate("insert into prt_external_sources (tenant_id, code, url, fl_allow_manual, dt_insert, user_id_insert, dt_delete, user_id_delete) " +
			"select :newTenantId as tenant_id, code, url, fl_allow_manual, :dtInsert, :userIdInsert, :dtDelete, :userIdDelete " +
			"from prt_external_sources " +
			"where tenant_id = :sourceTenant " +
			"AND (§current_timestamp§ between dt_insert and dt_delete) ")
	void insertNewTenant(
			@Bind("sourceTenant") String sourceTenant,
			@Bind("newTenantId") String newTenantId,
			@BindBean AuditEntity audit);

	@SqlUpdate("update prt_external_sources set dt_delete= :dtDelete, user_id_delete= :userIdDelete WHERE pkid= :pkid")
	void expireRow(@BindBean ExternalSourceEntity entity);

	@SqlQuery("select count(*) FROM prt_external_sources where tenant_id = :tenantId ")
	Long countAll(@Bind("tenantId") String tenantId);

	@SqlQuery("select pkid, tenant_id, code, url, fl_allow_manual, dt_insert, user_id_insert, dt_delete, user_id_delete " +
			"from prt_external_sources pes " +
			"where pes.tenant_id = :tenantId  " +
			"AND (§current_timestamp§ between pes.dt_insert and pes.dt_delete)")
	@RegisterBeanMapper(ExternalSourceEntity.class)
	List<ExternalSourceEntity> findAll(@Bind("tenantId") String tenantId);

	@SqlQuery("select pkid, tenant_id, code, url, fl_allow_manual, dt_insert, user_id_insert, dt_delete, user_id_delete " +
			"from prt_external_sources pes " +
			"where pes.tenant_id = :tenantId  " +
			"AND UPPER(pes.code) = UPPER(:code) " +
			"AND (§current_timestamp§ between pes.dt_insert and pes.dt_delete)")
	@RegisterBeanMapper(ExternalSourceEntity.class)
	Optional<ExternalSourceEntity> findByCode(@Bind("tenantId") String tenantId, @Bind("code") String code);

	@SqlQuery("select pkid, tenant_id, code, url, fl_allow_manual, dt_insert, user_id_insert, dt_delete, user_id_delete "
			+ I18N
			+ "from prt_external_sources pes "
			+ "where pes.tenant_id = :tenantId  "
			+ "and pes.code = :code  "
			+ "AND (§current_timestamp§ between pes.dt_insert and pes.dt_delete)")
	@RegisterBeanMapper(ExternalSourceRes.class)
	Optional<ExternalSourceRes> getByCode(@Bind("code") String code, @BindBean ReqContext ctx);

	@SqlQuery("select code, fl_allow_manual " + I18N
			+ " from prt_external_sources"
			+ " where tenant_id = :tenantId "
			+ " AND (§current_timestamp§ between dt_insert and dt_delete)")
	@RegisterBeanMapper(ExternalSourceRes.class)
	List<ExternalSourceRes> getAllAsList(@BindBean ReqContext ctx);

}
