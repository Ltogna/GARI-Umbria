package com.abacogroup.partyregistry.core.impl;

import com.abacogroup.lau.api.v1.CountryResponseV1;
import com.abacogroup.lau.api.v1.DistrictResponseV1;
import com.abacogroup.lau.api.v1.MunicipalityResponseV1;
import com.abacogroup.lau.api.v1.RegionResponseV1;
import com.abacogroup.lau.core.cli.v1.CountryClientV1;
import com.abacogroup.lau.core.cli.v1.DistrictClientV1;
import com.abacogroup.lau.core.cli.v1.MunicipalityClientV1;
import com.abacogroup.lau.core.cli.v1.RegionClientV1;
import com.abacogroup.partyregistry.api.AddressRes;
import com.abacogroup.partyregistry.api.PartySearchRes;
import com.abacogroup.partyregistry.api.v1.PartyResponseV1;
import com.abacogroup.partyregistry.api.v1.PartySearchResponseV1;
import com.abacogroup.partyregistry.resources.publicapis.mapper.MunicipalityResMapper;
import com.abacogroup.partyregistry.resources.req.ReqContext;
import java.util.Optional;
import java.util.function.Consumer;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

@Slf4j
public class LauMapper {

	private final CountryClientV1 countryClient;
	private final RegionClientV1 regionClient;
	private final DistrictClientV1 districtClient;
	private final MunicipalityClientV1 municipalityClient;

	public LauMapper(CountryClientV1 countryClient, RegionClientV1 regionClient, DistrictClientV1 districtClient, MunicipalityClientV1 municipalityClient) {
		this.countryClient = countryClient;
		this.regionClient = regionClient;
		this.districtClient = districtClient;
		this.municipalityClient = municipalityClient;
	}

	public PartySearchRes resolvePartySearchResponseAddress(PartySearchRes response, ReqContext reqContext) {
		AddressRes address = response.getAddressResidential();
		if (address == null) {
			return response;
		}

		String munCode = address.getMunicipality();

		if (!StringUtils.isBlank(munCode)) {
			getLauMunicipality(reqContext, munCode).ifPresent(mun -> {
				address.setMunicipalityI18nCode(mun.getI18nName());
				address.setDistrictShortDescr(mun.getDistrict().getShortDescr());
			});
		}
		return response;
	}

	public PartyResponseV1 resolvePartyResponseV1(PartyResponseV1 response, ReqContext reqContext) {

		this.fillMunicipality(response.getBirthMunicipality(), response::setBirthMunicipalityDetail, reqContext);

		Optional.ofNullable(response.getAddressResidential())
				.ifPresent(address -> this.fillMunicipality(address.getMunicipality(), address::setMunicipalityDetail, reqContext));

		Optional.ofNullable(response.getAddressHome())
				.ifPresent(address -> this.fillMunicipality(address.getMunicipality(), address::setMunicipalityDetail, reqContext));

		Optional.ofNullable(response.getAddressBilling())
				.ifPresent(address -> this.fillMunicipality(address.getMunicipality(), address::setMunicipalityDetail, reqContext));

		return response;
	}

	public PartySearchResponseV1 resolvePartySearchResponseV1(PartySearchResponseV1 response, ReqContext reqContext) {

		this.fillMunicipality(response.getBirthMunicipality(), response::setBirthMunicipalityDetail, reqContext);

		Optional.ofNullable(response.getAddressResidential())
				.ifPresent(address -> this.fillMunicipality(address.getMunicipality(), address::setMunicipalityDetail, reqContext));

		return response;
	}

	private Optional<CountryResponseV1> getLauCountry(ReqContext reqContext, String countryCode) {
		try {
			return Optional.ofNullable(this.countryClient.getByCode(
					reqContext.getLang(),
					reqContext.getUser(),
					countryCode));
		} catch (Exception e) {
			log.error("cannot fetch Country with code '{}': {}", countryCode, e.getMessage(), e);
			return Optional.empty();
		}
	}

	private Optional<RegionResponseV1> getLauRegion(ReqContext reqContext, String regionCode) {
		try {
			return Optional.ofNullable(this.regionClient.getByCode(
					reqContext.getLang(),
					reqContext.getUser(),
					regionCode));
		} catch (Exception e) {
			log.error("cannot fetch Region with code '{}': {}", regionCode, e.getMessage(), e);
			return Optional.empty();
		}
	}

	private Optional<DistrictResponseV1> getLauDistrict(ReqContext reqContext, String districtCode) {
		try {
			return Optional.ofNullable(this.districtClient.getByCode(
					reqContext.getLang(),
					reqContext.getUser(),
					districtCode));
		} catch (Exception e) {
			log.error("cannot fetch District with code '{}': {}", districtCode, e.getMessage(), e);
			return Optional.empty();
		}
	}

	private Optional<MunicipalityResponseV1> getLauMunicipality(ReqContext reqContext, String munCode) {
		try {
			// TODO cache
			return Optional.ofNullable(this.municipalityClient.getByCode(
					reqContext.getLang(),
					reqContext.getUser(),
					munCode));
		} catch (Exception e) {
			log.error("cannot fetch Municipality with code '{}': {}", munCode, e.getMessage(), e);
			return Optional.empty();
		}
	}

	private String getLauCountryI18nCode(ReqContext reqContext, String countryCode) {
		return getLauCountry(reqContext, countryCode)
				.map(CountryResponseV1::getI18nName)
				.orElse(null);
	}

	private void fillMunicipality(
			String municipalityCode,
			Consumer<com.abacogroup.partyregistry.api.v1.lau.MunicipalityResponseV1> municipalitySetter,
			ReqContext reqContext
	) {
		if (StringUtils.isNotBlank(municipalityCode)) {
			getLauMunicipality(reqContext, municipalityCode)
					.map(MunicipalityResMapper.INSTANCE::fromLau)
					.ifPresent(municipalitySetter);
		}
	}

}
