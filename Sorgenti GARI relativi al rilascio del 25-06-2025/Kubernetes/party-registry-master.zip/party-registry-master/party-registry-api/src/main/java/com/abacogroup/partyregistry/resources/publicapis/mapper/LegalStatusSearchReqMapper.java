package com.abacogroup.partyregistry.resources.publicapis.mapper;

import com.abacogroup.partyregistry.api.v1.req.LegalStatusSearchRequestV1;
import com.abacogroup.partyregistry.resources.req.LegalStatusSearchReq;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper
public interface LegalStatusSearchReqMapper {

	LegalStatusSearchReqMapper INSTANCE = Mappers.getMapper(LegalStatusSearchReqMapper.class);

	LegalStatusSearchReq fromV1(LegalStatusSearchRequestV1 req);
}
