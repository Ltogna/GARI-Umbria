package com.abacogroup.partyregistry.db.dao;

import com.abacogroup.partyregistry.api.I18n;
import com.abacogroup.partyregistry.db.ntt.I18nEntity;
import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.customizer.BindBean;
import org.jdbi.v3.sqlobject.statement.SqlBatch;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;
import org.jdbi.v3.sqlobject.transaction.Transactional;
import java.util.Optional;

public interface I18nDAO extends Transactional<I18nDAO> {

	@SqlQuery("select tenant_id, table_name, field_name, i18n_value, lang, i18n_text "
			+ "from prt_i18n_values "
			+ "where tenant_id= :tenantId and table_name= :tableName and field_name= :fieldName and i18n_value= :i18nValue and lang= :lang ")
	@RegisterBeanMapper(I18nEntity.class)
	Optional<I18nEntity> findOne(
			@Bind("tenantId") String tenantId,
			@Bind("tableName") String tableName,
			@Bind("fieldName") String fieldName,
			@Bind("i18nValue") String i18nValue,
			@Bind("lang") String lang
	);

	@SqlQuery("select tenant_id, table_name, field_name, i18n_value, lang, i18n_text "
			+ "from prt_i18n_values "
			+ "where tenant_id= :tenantId and table_name= :tableName and field_name= :fieldName and i18n_value= :i18nValue and lang= :lang ")
	@RegisterBeanMapper(I18n.class)
	Optional<I18n> searchOne(
			@Bind("tenantId") String tenantId,
			@Bind("tableName") String tableName,
			@Bind("fieldName") String fieldName,
			@Bind("i18nValue") String i18nValue,
			@Bind("lang") String lang
	);

	@SqlQuery("select i18n_text "
			+ "from prt_i18n_values "
			+ "where tenant_id= :tenantId and table_name= :tableName and field_name= :fieldName and i18n_value= :i18nValue and lang= :lang ")
		//@RegisterBeanMapper(String.class)
	String searchLabel(
			@Bind("tenantId") String tenantId,
			@Bind("tableName") String tableName,
			@Bind("fieldName") String fieldName,
			@Bind("i18nValue") String i18nValue,
			@Bind("lang") String lang
	);

	//	@SqlQuery("select * from prt_i18n_values "
	//			+ " where upper(tenant_id) = upper(:tenantId)")
	//	@RegisterBeanMapper(I18nEntity.class)
	//	List<I18nEntity> loadAllByTenant(@Bind("tenantId") String tenantId);
	//
	//	@SqlQuery("select * from prt_i18n_values "
	//			+ " where upper(tenant_id) = upper(:tenantId) "
	//			+ " and upper(table_name) = upper(:tableName) "
	//			+ " and upper(field_name) = upper(:fieldName) "
	//			+ " and lang in (<lang>)")
	//	@RegisterBeanMapper(I18nEntity.class)
	//	List<I18nEntity> loadByTenantValueLang(
	//			@Bind("tenantId") String tenantId,
	//			@Bind("tableName") String tableName,
	//			@Bind("fieldName") String fieldName,
	//			@BindList(value = "lang", onEmpty = EmptyHandling.VOID) List<String> lang);

	@SqlUpdate("insert into prt_i18n_values (tenant_id, table_name, field_name, i18n_value, lang, i18n_text) "
			+ " values (:tenantId, :tableName, :fieldName, :i18nValue, :lang, :i18nText) ")
	void insert(@BindBean I18nEntity entity);

	@SqlBatch("insert into prt_i18n_values (tenant_id, table_name, field_name, i18n_value, lang, i18n_text) "
			+ " values (:tenantId, :tableName, :fieldName, :i18nValue, :lang, :i18nText) ")
	void insert(@BindBean I18nEntity... entity);

	@SqlBatch("delete from prt_i18n_values "
			+ " where tenant_id = :tenantId "
			+ "and table_name = :tableName "
			+ "and field_name = :fieldName "
			+ "and i18n_value = :i18nValue "
			+ "and lang = :lang ")
	void deleteBatch(@BindBean I18nEntity... entity);

	/**
	 * elimina tutte le etichette per un determinato tenant, tabella, field e value.
	 * <p>
	 * Cancella tutte le lang
	 */
	@SqlUpdate("delete from prt_i18n_values "
			+ " where tenant_id = :tenantId "
			+ "and table_name = :tableName "
			+ "and field_name = :fieldName "
			+ "and i18n_value = :i18nValue ")
	void deleteByValue(@BindBean I18nEntity entity);


	@SqlQuery("select count(*) FROM prt_i18n_values where tenant_id = :tenantId ")
	Long countAll(@Bind("tenantId") String tenantId);

	@SqlUpdate("INSERT INTO prt_i18n_values (tenant_id, table_name, field_name, i18n_value, lang, i18n_text) " +
			" select :newTenantId as tenant_id, table_name, field_name, i18n_value, lang, i18n_text " +
			" FROM prt_i18n_values  where tenant_id = :sourceTenant ")
	void insertNewTenant(@Bind("sourceTenant") String sourceTenant,
						 @Bind("newTenantId") String newTenantId);


}
