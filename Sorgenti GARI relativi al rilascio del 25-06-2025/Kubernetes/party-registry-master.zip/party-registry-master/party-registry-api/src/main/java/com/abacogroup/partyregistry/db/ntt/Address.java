package com.abacogroup.partyregistry.db.ntt;

import java.io.Serializable;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder(setterPrefix = "set")
@NoArgsConstructor
public class Address implements Serializable {

	private Long id;
	private String municipality;
	private String locality;
	private String street;
	private String houseNumber;
	private String postcode;
	private String details;
	private String note;
}
