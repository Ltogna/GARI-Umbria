package com.abacogroup.partyregistry.resources;

import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.partyregistry.api.Citizenship;
import com.abacogroup.partyregistry.core.CitizenshipService;
import com.abacogroup.partyregistry.resources.req.CitizenshipSearchReq;
import com.abacogroup.partyregistry.resources.req.ReqContext;
import io.dropwizard.auth.Auth;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.annotation.security.RolesAllowed;
import jakarta.ws.rs.BeanParam;
import jakarta.ws.rs.DefaultValue;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.HeaderParam;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.MediaType;

@Path(ResourceConstants.API_PRIV + "/citizenships")
@Produces(MediaType.APPLICATION_JSON)
@Tag(name = "Citizenship", description = "Operations on citizenships")
public class CitizenshipResource {

	private final CitizenshipService citizenshipService;

	public CitizenshipResource(CitizenshipService citizenshipService) {
		this.citizenshipService = citizenshipService;
	}

	@Operation(summary = "List of citizenship", description = "Get list of citizenship filtered with criteria")
	@ApiResponses({
			@ApiResponse(responseCode = "200", description = "Successfully, returns a list of citizenship (sorted/filtered)",
					content = @Content(mediaType = "application/json", schema = @Schema(ref = "#/components/schemas/InfiniteListResultsCitizenship")))
	})
	@GET
	@RolesAllowed("PARTY-REGISTRY|READ")
	public InfiniteListResults<Citizenship> search(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "tenant ID") @PathParam("tenant") String tenantId,
			@Parameter(description = "Can be supplied to obtain the records that follows those obtained by a previous call") @QueryParam("nextKey") String nextKey,
			@BeanParam CitizenshipSearchReq searchRequest) {

		ReqContext reqContext = new ReqContext(user, lang);
		return citizenshipService.search(reqContext, searchRequest, nextKey);
	}

	@Operation(summary = "Find a citizenship by CODE", description = "Returns a citizenship based on its CODE")
	@ApiResponses({
			@ApiResponse(responseCode = "200", description = "Successfully, a citizenship is found",
					content = @Content(mediaType = "application/json", schema = @Schema(implementation = Citizenship.class))),
	})
	@GET
	@RolesAllowed("PARTY-REGISTRY|READ")
	@Path("/{code}")
	public Citizenship getByCode(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "tenant ID") @PathParam("tenant") String tenantId,
			@Parameter(description = "the citizenship CODE") @PathParam("code") String code
	) {
		ReqContext reqContext = new ReqContext(user, lang);
		return this.citizenshipService.getByCode(reqContext, code)
				.orElse(null);
	}

	/*@Operation(summary = "Create a citizenship", description = "Insert a new citizenship")
	@ApiResponses({
			@ApiResponse(responseCode = "200", description = "Successfully, the new citizenship is created",
					content = @Content(mediaType = "application/json", schema = @Schema(implementation = Citizenship.class))),
			@ApiResponse(responseCode = "400", description = "Citizenship already exist", content = @Content(schema = @Schema(implementation = InvalidCitizenshipException.ErrorBody.class)))
	})
	@POST
	@RolesAllowed("PARTY-REGISTRY|WRITE")
	public Citizenship insert(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "tenant ID") @PathParam("tenant") String tenantId,
			@NotNull @Valid CitizenshipReq citizenship) {

		ReqContext reqContext = new ReqContext(user, lang);
		return citizenshipService.save(reqContext, citizenship);
	}*/

}
