package com.abacogroup.partyregistry;

import com.abacogroup.partyregistry.core.exceptions.AbstractPartyException;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.ext.ExceptionMapper;

//@Provider
@Produces(MediaType.APPLICATION_JSON)
public class PartyExceptionMapper implements ExceptionMapper<AbstractPartyException> {

	@Override public Response toResponse(AbstractPartyException abstractPartyException) {
		System.out.println("**********************************");
		System.out.println("**********************************");
		System.out.println("**********************************");
		System.out.println("**********************************");

		return abstractPartyException.getResponse();
		//		return Response
		//				.status(Status.BAD_REQUEST)
		//				//.entity(abstractPartyException.getBody())
		//				.build();
	}

}

