package com.abacogroup.partyregistry.core;

import com.abacogroup.partyregistry.core.exceptions.InvalidPartyException;
import com.abacogroup.partyregistry.db.ntt.AppConfigEntity;
import com.abacogroup.partyregistry.db.ntt.PartyEntity;

public interface PartyFieldValidator {
	String getFieldName();

	/**
	 * operation on party if no configuration present
	 * @param party
	 */
	void resetField(PartyEntity party);

	void validateOnInsert(PartyEntity party, AppConfigEntity validationConfig) throws InvalidPartyException;

	void validateOnUpdate(PartyEntity party, AppConfigEntity validationConfig) throws InvalidPartyException;
}
