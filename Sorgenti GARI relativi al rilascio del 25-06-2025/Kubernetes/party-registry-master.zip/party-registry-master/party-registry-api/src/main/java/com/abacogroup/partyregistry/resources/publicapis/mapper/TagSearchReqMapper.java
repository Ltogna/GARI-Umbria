package com.abacogroup.partyregistry.resources.publicapis.mapper;

import com.abacogroup.partyregistry.api.v1.req.TagSearchRequestV1;
import com.abacogroup.partyregistry.resources.req.TagSearchReq;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper
public interface TagSearchReqMapper {

	TagSearchReqMapper INSTANCE = Mappers.getMapper(TagSearchReqMapper.class);

	TagSearchReq fromV1(TagSearchRequestV1 searchRequest);
}
