package com.abacogroup.partyregistry.core.impl;

import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.partyregistry.api.v1.PartyResponseV1;
import com.abacogroup.partyregistry.api.v1.PartySearchResponseV1;
import com.abacogroup.partyregistry.api.v1.req.PartyByIdInSearchRequestV1;
import com.abacogroup.partyregistry.api.v1.req.PartySearchRequestV1;
import com.abacogroup.partyregistry.core.PartyService;
import com.abacogroup.partyregistry.core.PartyV1Service;
import com.abacogroup.partyregistry.resources.publicapis.mapper.PartyResMapper;
import com.abacogroup.partyregistry.resources.publicapis.mapper.PartySearchReqMapper;
import com.abacogroup.partyregistry.resources.req.PartySearchReq;
import com.abacogroup.partyregistry.resources.req.ReqContext;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class PartyV1ServiceImpl implements PartyV1Service {

	private final PartyService partyService;
	private final LauMapper lauMapper;

	public PartyV1ServiceImpl(PartyService partyService, LauMapper lauMapper) {
		this.partyService = partyService;
		this.lauMapper = lauMapper;
	}

	@Override
	public InfiniteListResults<PartySearchResponseV1> publicSearch(ReqContext reqContext, PartySearchRequestV1 partySearchReq, Integer withManage, String nextKey) {
		PartySearchReq searchReq = PartySearchReqMapper.INSTANCE.fromV1(partySearchReq);
		return partyService.doSearch(reqContext, searchReq, withManage , nextKey)
				.map(PartyResMapper.INSTANCE::toV1)
				.map(response -> lauMapper.resolvePartySearchResponseV1(response, reqContext));
	}

	@Override
	public Optional<PartyResponseV1> getPartyResponseById(ReqContext reqContext, Long id) {
		return partyService.getPartyById(reqContext, id)
				.map(PartyResMapper.INSTANCE::toV1)
				.map(response -> lauMapper.resolvePartyResponseV1(response, reqContext));
	}

	@Override
	public Optional<PartyResponseV1> getPartyResponseByCode(ReqContext reqContext, String code) {
		return partyService.getPartyByCode(reqContext, code)
				.map(PartyResMapper.INSTANCE::toV1)
				.map(response -> lauMapper.resolvePartyResponseV1(response, reqContext));
	}

	@Override
	public List<PartySearchResponseV1> getPartyResponseByIdIn(ReqContext reqContext, PartyByIdInSearchRequestV1 partySearchReq, Integer withManage) {
		return partyService.searchByIdIn(reqContext, partySearchReq.getIds(), withManage)
				.stream()
				.map(PartyResMapper.INSTANCE::toV1)
				.map(response -> lauMapper.resolvePartySearchResponseV1(response, reqContext))
				.collect(Collectors.toList());
	}
}
