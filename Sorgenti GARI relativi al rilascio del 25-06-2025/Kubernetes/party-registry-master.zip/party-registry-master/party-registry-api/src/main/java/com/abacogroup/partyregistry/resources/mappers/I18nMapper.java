package com.abacogroup.partyregistry.resources.mappers;

import com.abacogroup.partyregistry.db.ntt.I18nEntity;
import com.abacogroup.partyregistry.resources.req.I18nReq;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper
public interface I18nMapper {

	I18nMapper INSTANCE = Mappers.getMapper(I18nMapper.class);

	I18nEntity reqToEntity(I18nReq dto);

}
