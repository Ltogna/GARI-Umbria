package com.abacogroup.partyregistry.core.impl;

import java.util.List;
import java.util.Optional;

import com.abacogroup.jdbi.criteria.Criteria;
import com.abacogroup.jdbi.orderby.OrderBy;
import com.abacogroup.jdbi.orderby.OrderByBuilder;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.partyregistry.api.Tag;
import com.abacogroup.partyregistry.core.TagService;
import com.abacogroup.partyregistry.db.dao.TagDAO;
import com.abacogroup.partyregistry.db.ntt.TagEntity;
import com.abacogroup.partyregistry.resources.req.ReqContext;
import com.abacogroup.partyregistry.resources.req.TagSearchReq;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class TagServiceImpl implements TagService {

	private final TagDAO tagDAO;

	public TagServiceImpl(TagDAO tagDAO) {
		this.tagDAO = tagDAO;
	}

	@Override
	public Optional<TagEntity> findTagByCode(String tenantId, String code) {
		return tagDAO.findByCode(tenantId, code);
	}

	@Override
	public InfiniteListResults<Tag> searchTags(ReqContext reqContext, TagSearchReq searchRequest, String nextKey) {
		Criteria criteria = searchRequest.getCriteria(reqContext);
		OrderBy sort = OrderByBuilder.from(searchRequest.getSort(), OrderByBuilder.field("id"));

		InfiniteListResults<Tag> tags = tagDAO.infinite(() ->
						tagDAO.searchAll(criteria, sort, reqContext),
				nextKey, searchRequest.getPageSize());
		return tags;
	}

	@Override
	public List<Tag> searchTagList(ReqContext reqContext, TagSearchReq searchRequest) {
		Criteria criteria = searchRequest.getCriteria(reqContext);
		OrderBy sort = OrderByBuilder.from(searchRequest.getSort(), OrderByBuilder.field("id"));

		List<Tag> tags = tagDAO.searchList(criteria, sort, reqContext);
		return tags;
	}

	@Override
	public Optional<Tag> getTagById(ReqContext reqContext, Long id) {
		return tagDAO.searchById(id, reqContext);
	}

	@Override
	public Optional<Tag> getTagByCode(ReqContext reqContext, String code) {
		return tagDAO.searchByCode(code, reqContext);
	}

}
