package com.abacogroup.partyregistry.api;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder(setterPrefix = "set")
@NoArgsConstructor
public class ContactSearchResponse {

	private Long pkid;
	private Long partyId;
	private ContactTypeEnum contactType;
	private String subType;
	private String contactValue;
	private String note;
}
