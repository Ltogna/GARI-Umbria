package com.abacogroup.partyregistry.db.ntt;

import com.abacogroup.jdbi.model.AuditEntity;
import java.time.LocalDateTime;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder(setterPrefix = "set")
@NoArgsConstructor
public class RelationRoleEntity implements AuditEntity {

	private Long id;
	private Long typeId;
	private String code;
	private LocalDateTime dtInsert;
	private String userIdInsert;
	private LocalDateTime dtDelete;
	private String userIdDelete;

	/**
	 * relation type loaded from query
	 */
	private String relationTypeCode;
}
