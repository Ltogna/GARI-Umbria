package com.abacogroup.partyregistry.core.impl.validaor;

import com.abacogroup.partyregistry.core.PartyFieldValidator;
import com.abacogroup.partyregistry.core.exceptions.ErrCodes;
import com.abacogroup.partyregistry.core.exceptions.InvalidPartyException;
import com.abacogroup.partyregistry.db.ntt.AppConfigEntity;
import com.abacogroup.partyregistry.db.ntt.PartyEntity;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import java.util.List;
import java.util.regex.Pattern;

@Slf4j
public abstract class AbstractRegexCodeValidator implements PartyFieldValidator {

	protected final ObjectMapper objectMapper;

	public AbstractRegexCodeValidator(ObjectMapper objectMapper) {
		this.objectMapper = objectMapper;
	}

	/**
	 * get field name for log and exceptions
	 *
	 * @return validated field name
	 */
	protected abstract String getCodeDescription();

	/**
	 * adjust value and get
	 *
	 * @param party
	 * @return the adjusted value
	 */
	protected abstract String getCode(PartyEntity party);

	@Override
	public void resetField(PartyEntity party) {
		getCode(party);
	}

	@Override
	public void validateOnInsert(PartyEntity party, AppConfigEntity validationConfig) throws InvalidPartyException {
		doValidate(party, validationConfig);
	}

	@Override
	public void validateOnUpdate(PartyEntity party, AppConfigEntity validationConfig) throws InvalidPartyException {
		doValidate(party, validationConfig);
	}

	private void doValidate(PartyEntity party, AppConfigEntity validationConfig) {
		String code = getCode(party);
		if (code == null) {
			return;
		}

		RegexCodeConfiguration configuration = this.getConfiguration(validationConfig);

		List<String> regexes = configuration.getRegexes(party.getPartyType());
		if (null == regexes || regexes.isEmpty()) {
			log.info("no regex configuration found for party {} and config {}", party.getPartyType(), validationConfig.getConfigurationKey());
			return;
		}
		if (regexes.stream().noneMatch(regex -> Pattern.matches(regex, code))) {
			throw new InvalidPartyException(ErrCodes.INVALID_PAYLOAD,
					String.format("%s format not valid. it must match at least one of these regexes: %s", getCodeDescription(),
							String.join(",", regexes)));
		}
	}

	private RegexCodeConfiguration getConfiguration(AppConfigEntity validationConfig) {
		try {
			return objectMapper.readValue(validationConfig.getConfiguration(), RegexCodeConfiguration.class);
		} catch (JsonProcessingException e) {
			throw new RuntimeException(e);
		}
	}
}
