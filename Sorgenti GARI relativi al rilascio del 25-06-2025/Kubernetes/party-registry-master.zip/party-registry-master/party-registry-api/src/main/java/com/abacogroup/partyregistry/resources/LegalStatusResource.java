package com.abacogroup.partyregistry.resources;

import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.partyregistry.api.LegalStatus;
import com.abacogroup.partyregistry.core.LegalStatusService;
import com.abacogroup.partyregistry.resources.req.LegalStatusSearchReq;
import com.abacogroup.partyregistry.resources.req.ReqContext;
import io.dropwizard.auth.Auth;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.annotation.security.RolesAllowed;
import jakarta.ws.rs.BeanParam;
import jakarta.ws.rs.DefaultValue;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.HeaderParam;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.MediaType;

@Path(ResourceConstants.API_PRIV + "/legal-status")
@Produces(MediaType.APPLICATION_JSON)
@Tag(name = "LegalStatus", description = "Operations on legal-status")
public class LegalStatusResource {

	private final LegalStatusService legalStatusService;

	public LegalStatusResource(LegalStatusService legalStatusService) {
		this.legalStatusService = legalStatusService;
	}

	@Operation(summary = "List of legal status", description = "Get list of legal status filtered with criteria")
	@ApiResponses({
			@ApiResponse(responseCode = "200", description = "Successfully, returns a list of legal status (sorted/filtered)",
					content = @Content(mediaType = "application/json", schema = @Schema(ref = "#/components/schemas/InfiniteListResultsLegalStatus")))
	})
	@GET
	@RolesAllowed("PARTY-REGISTRY|READ")
	public InfiniteListResults<LegalStatus> search(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "tenant ID") @PathParam("tenant") String tenantId,
			@Parameter(description = "Can be supplied to obtain the records that follows those obtained by a previous call") @QueryParam("nextKey") String nextKey,
			@BeanParam LegalStatusSearchReq searchRequest) {

		ReqContext reqContext = new ReqContext(user, lang);
		return legalStatusService.search(reqContext, searchRequest, nextKey);
	}

	@Operation(summary = "Find a legal status by CODE", description = "Returns a legal status based on its CODE")
	@ApiResponses({
			@ApiResponse(responseCode = "200", description = "Successfully, a legal status is found",
					content = @Content(mediaType = "application/json", schema = @Schema(implementation = LegalStatus.class))),
	})
	@GET
	@RolesAllowed("PARTY-REGISTRY|READ")
	@Path("/{code}")
	public LegalStatus getByCode(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "tenant ID") @PathParam("tenant") String tenantId,
			@Parameter(description = "the legal status CODE") @PathParam("code") String code
	) {
		ReqContext reqContext = new ReqContext(user, lang);
		return this.legalStatusService.getByCode(reqContext, code)
				.orElse(null);
	}


}
