package com.abacogroup.partyregistry.core;

import com.abacogroup.partyregistry.db.ntt.I18nEntity;
import com.abacogroup.partyregistry.resources.req.ReqContext;
import java.util.Optional;

public interface I18nService {
	Optional<I18nEntity> findOne(ReqContext reqContext, String tableName, String fieldName, String i18nValue, String lang);

	//I18n save(ReqContext reqContext, I18nReq req);
}
