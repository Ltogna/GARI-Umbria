package com.abacogroup.partyregistry.resources.mappers;

import com.abacogroup.partyregistry.db.ntt.TagEntity;
import com.abacogroup.partyregistry.resources.req.TagReq;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper
public interface TagMapper {

	TagMapper INSTANCE = Mappers.getMapper(TagMapper.class);

	TagEntity reqToEntity(TagReq dto);

}
