package com.abacogroup.partyregistry.core.exceptions;

import io.swagger.v3.oas.annotations.media.Schema;

public class InvalidTagException extends AbstractPartyException {

	public InvalidTagException(String code, String message) {
		super(new ErrorBody(code, message));
	}

	@Schema(name = "InvalidTagExceptionErrorBody")
	public static class ErrorBody implements ExceptionErrorBody {
		private final String code;
		private final String message;

		public ErrorBody(String code, String message) {
			this.code = code;
			this.message = message;
		}

		@Override
		@Schema(allowableValues = { ErrCodes.TAG_NOT_FOUND })
		public String getErrorCode() {
			return code;
		}

		@Override
		@Schema
		public String getMessage() {
			return message;
		}
	}

}
