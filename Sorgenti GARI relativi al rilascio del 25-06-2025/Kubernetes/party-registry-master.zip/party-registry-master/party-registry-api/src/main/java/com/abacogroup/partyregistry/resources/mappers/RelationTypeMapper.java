package com.abacogroup.partyregistry.resources.mappers;

import com.abacogroup.partyregistry.db.ntt.RelationTypeEntity;
import com.abacogroup.partyregistry.resources.req.RelationTypeReq;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

@Mapper
public interface RelationTypeMapper {

	RelationTypeMapper INSTANCE = Mappers.getMapper(RelationTypeMapper.class);

	@Mapping(target = "flMultiple", expression = "java(req.isMultiple() ? 1 : 0)")
	RelationTypeEntity reqToEntity(RelationTypeReq req);

}
