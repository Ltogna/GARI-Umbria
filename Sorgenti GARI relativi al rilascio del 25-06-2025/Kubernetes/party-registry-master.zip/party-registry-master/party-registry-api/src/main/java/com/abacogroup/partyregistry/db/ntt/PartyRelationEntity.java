package com.abacogroup.partyregistry.db.ntt;

import com.abacogroup.jdbi.model.AuditEntity;
import java.time.LocalDateTime;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder(setterPrefix = "set")
@NoArgsConstructor
public class PartyRelationEntity implements AuditEntity {

	private Long id;
	private Long partyId;
	private Long relationTypeId;

	/**
	 * //   * in lettura //
	 */
	private String relationTypeCode;

	/**
	 * in lettura
	 */
	private String detailNote;

	private LocalDateTime dtInsert;
	private String userIdInsert;
	private LocalDateTime dtDelete;
	private String userIdDelete;
}
