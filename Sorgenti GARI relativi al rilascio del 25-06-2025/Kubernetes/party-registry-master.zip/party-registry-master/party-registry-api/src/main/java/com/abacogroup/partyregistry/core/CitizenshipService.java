package com.abacogroup.partyregistry.core;

import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.partyregistry.api.Citizenship;
import com.abacogroup.partyregistry.db.ntt.CitizenshipEntity;
import com.abacogroup.partyregistry.resources.req.CitizenshipSearchReq;
import com.abacogroup.partyregistry.resources.req.ReqContext;
import java.util.Optional;

public interface CitizenshipService {

	InfiniteListResults<Citizenship> search(ReqContext reqContext, CitizenshipSearchReq searchRequest, String nextKey);

	Optional<Citizenship> getByCode(ReqContext reqContext, String code);

	Optional<CitizenshipEntity> findEntityByCode(String tenantId, String code);

	//Citizenship save(ReqContext context, CitizenshipReq citizenshipReq);

}
