package com.abacogroup.partyregistry.resources.publicapis.mapper;

import com.abacogroup.partyregistry.api.PartyRelation;
import com.abacogroup.partyregistry.api.v1.PartyRelationResponseV1;
import com.abacogroup.partyregistry.api.v1.req.PartyRelationTypeSearchRequestV1;
import com.abacogroup.partyregistry.resources.req.PartyRelationTypeSearchReq;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper
public interface RelationPublicMapper {

	RelationPublicMapper INSTANCE = Mappers.getMapper(RelationPublicMapper.class);

	PartyRelationResponseV1 toResponseV1(PartyRelation res);

	PartyRelationTypeSearchReq fromSearchRequestV1(PartyRelationTypeSearchRequestV1 requestV1);


}
