package com.abacogroup.partyregistry.resources.publicapis.mapper;

import com.abacogroup.partyregistry.api.v1.req.PartySearchRequestV1;
import com.abacogroup.partyregistry.resources.req.PartySearchReq;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper
public interface PartySearchReqMapper {

	PartySearchReqMapper INSTANCE = Mappers.getMapper(PartySearchReqMapper.class);

	PartySearchReq fromV1(PartySearchRequestV1 searchRequestV1);

}
