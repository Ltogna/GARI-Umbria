package com.abacogroup.partyregistry.bundle.tenant;

import static com.abacogroup.bundles.Constants.ALL_TENANTS;

import com.abacogroup.bundles.listener.tenant.TenantMessage;
import com.abacogroup.bundles.listener.tenant.TenantMessageProcessor;
import com.abacogroup.partyregistry.db.dao.TagDAO;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class TagTenantMessageProcessor implements TenantMessageProcessor {

	private final TagDAO tagDAO;

	public TagTenantMessageProcessor(TagDAO tagDAO) {
		this.tagDAO = tagDAO;
	}

	@Override
	public void onMessage(TenantMessage message) {
		String tenantId = message.getTenantId();
		if (tagDAO.countAll(tenantId) > 0L) {
			log.warn("tags already present for tenant {}", tenantId);
		} else {
			tagDAO.insertNewTenant(ALL_TENANTS, tenantId);
		}
	}

}
