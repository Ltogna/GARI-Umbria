package com.abacogroup.partyregistry.api;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder(setterPrefix = "set")
@NoArgsConstructor
public class PartyTag {

	private Long pkid;
	private Long partyId;
	private Long tagId;
	private String tagCode;
	private String tagI18nCode;
}
