package com.abacogroup.partyregistry.core.impl;

import com.abacogroup.dynamicdocuments.bean.DocumentDefinition;
import com.abacogroup.dynamicdocuments.services.DocumentTypeService;
import com.abacogroup.partyregistry.api.DocType;
import com.abacogroup.partyregistry.resources.req.ReqContext;
import java.util.Optional;

public class DocTypeMapper {

	public static DocType addDefinitionMetaData(ReqContext reqContext, DocType docType, DocumentTypeService documentTypeService) {
		Optional<DocumentDefinition> def = documentTypeService.getDocumentDefinition(reqContext.getTenantId(), docType.getDocType());

		def.ifPresent(d -> {
			docType.setMultiple(d.getMetadata().getMaxOccurs() != null && d.getMetadata().getMaxOccurs() > 1);
			docType.setSummaryFieldDefinitions(documentTypeService.getSummaryFields(def.get(), reqContext.getLang()));
		});
		return docType;
	}

}
