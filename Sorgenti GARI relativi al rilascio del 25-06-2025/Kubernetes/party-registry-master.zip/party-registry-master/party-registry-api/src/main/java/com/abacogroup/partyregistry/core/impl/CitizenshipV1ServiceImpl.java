package com.abacogroup.partyregistry.core.impl;

import java.util.Optional;

import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.partyregistry.api.v1.CitizenshipResponseV1;
import com.abacogroup.partyregistry.api.v1.req.CitizenshipSearchRequestV1;
import com.abacogroup.partyregistry.core.CitizenshipService;
import com.abacogroup.partyregistry.core.CitizenshipV1Service;
import com.abacogroup.partyregistry.resources.publicapis.mapper.CitizenshipRespMapper;
import com.abacogroup.partyregistry.resources.publicapis.mapper.CitizenshipSearchReqMapper;
import com.abacogroup.partyregistry.resources.req.CitizenshipSearchReq;
import com.abacogroup.partyregistry.resources.req.ReqContext;

public class CitizenshipV1ServiceImpl implements CitizenshipV1Service {

	private CitizenshipService citizenshipService; 
	
	public CitizenshipV1ServiceImpl (CitizenshipService citizenshipService) {
		this.citizenshipService = citizenshipService;
	}
	
	@Override
	public InfiniteListResults<CitizenshipResponseV1> search(ReqContext reqContext,
			CitizenshipSearchRequestV1 searchRequest, String nextKey) {
		
		 CitizenshipSearchReq req = CitizenshipSearchReqMapper.INSTANCE.fromV1(searchRequest);
		 return citizenshipService.search(reqContext, req, nextKey).map(CitizenshipRespMapper.INSTANCE::toV1);
		 
	}

	@Override
	public Optional<CitizenshipResponseV1> getByCode(ReqContext reqContext, String code) {
		
		return citizenshipService.getByCode(reqContext, code).map(CitizenshipRespMapper.INSTANCE::toV1);
	}

}
