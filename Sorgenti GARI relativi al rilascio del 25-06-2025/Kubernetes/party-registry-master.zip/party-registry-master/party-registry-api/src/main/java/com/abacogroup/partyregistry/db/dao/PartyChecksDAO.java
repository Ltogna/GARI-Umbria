package com.abacogroup.partyregistry.db.dao;

import com.abacogroup.jdbi.EnhancedSqlObject;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.partyregistry.api.RoleCountDTO;
import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.customizer.BindList;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.transaction.Transactional;

import java.util.List;

public interface PartyChecksDAO extends Transactional<PartyChecksDAO>, EnhancedSqlObject {



	@SqlQuery("with partyDetails as ( " +
			" select * " +
			" from prt_parties_detail partyDetails " +
			" where §current_timestamp§ between partyDetails.dt_insert and partyDetails.dt_delete " +
			" and partyDetails.code = :partyCode " +
			") " +
			"select  " +
			" relationRoles.code as code, " +
			" §i18n(:tenantId, 'prt_relation_roles', 'code', relationRoles.code, :lang)§ as description, " +
			" count(*) as \"count\" " +
			"from prt_party_relation_parties relationParties " +
			"join prt_relation_roles relationRoles on relationparties.relation_role_id = relationroles.id  " +
			"join prt_relation_types relationTypes on relationroles.type_id = relationtypes.id " +
			"join partyDetails on partyDetails.party_id = relationParties.party_id " +
			"where §current_timestamp§ between relationparties.dt_insert and relationparties.dt_delete  " +
			"and §current_timestamp§ between relationroles.dt_insert and relationroles.dt_delete  " +
			"and §current_timestamp§ between relationtypes.dt_insert and relationtypes.dt_delete  " +
			"and relationroles.code in (<roleCodeList>) " +
			"and relationtypes.code = :relationType " +
			"and :referenceDate between relationparties.dt_start and relationparties.dt_end " +
			"group by relationRoles.code ")
	@RegisterBeanMapper(RoleCountDTO.class)
	List<RoleCountDTO> countPartyRelationRoles(@Bind("partyCode") String partyCode,
											   @BindList("roleCodeList") List<String> roleCodeList,
											   @Bind("relationType") String relationType,
											   @Bind("referenceDate") AbsoluteDate referenceDate,
											   @Bind("tenantId") String tenant,
											   @Bind("lang") String lang);

}
