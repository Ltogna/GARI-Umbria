package com.abacogroup.partyregistry.core;

public interface BundleConstants {

	String DOMAIN_TAGS = "tags";
	String CITIZENSHIP = "citizenship";
	String DOMAIN_DYNAMIC_DOCUMENTS = "dynamic_documents";

	String DOMAIN_I18N = "i18n";
	String SYSTEM_USER = "system";
	String DOMAIN_RELATIONS = "relations";

	String DOMAIN_APP_CONFIG = "app_config";

	String DOMAIN_EXTERNAL_SOURCES = "external_sources";

	String JSONL_COMMENT = "--";

	/*test only*/
	@Deprecated
	String PARTY = "party";


	/**
	 * natura giuridica
	 */
	String LEGAL_STATUS = "legal_status";
}
