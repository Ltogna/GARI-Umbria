package com.abacogroup.partyregistry.core.dynamicdoc;

import com.abacogroup.dynamicdocuments.bean.Document;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class DynamicDocumentUtils {

	/**
	 * aggrega le singole mappe in una sola con values come ArrayList preservando l'ordinamento dei null
	 */
	@SuppressWarnings({ "all" })
	@SafeVarargs
	public static Map<String, Object> createMultiDoc(Map<String, Object>... items) {
		Map<String, Object> fields = new HashMap<>();
		for (int j = 0; j < items.length; j++) {
			Map<String, Object> item = items[j];
			for (Entry<String, Object> entry : item.entrySet()) {
				String key = entry.getKey();
				Object value = entry.getValue();
				if (fields.containsKey(key)) {
					List<Object> values = (List<Object>) fields.get(key);
					values.set(j, value);
				} else {
					List<Object> values = IntStream.range(0, items.length).mapToObj(i -> null)
							.collect(Collectors.toList());
					values.set(j, value);
					fields.put(key, values);
				}
			}
		}
		return fields;
	}

	//	public static void updateField(Document doc, String key, Object value) {
	//		//ATTENZIONE: SONO SEMPRE ARRAY
	//		List<Object> values = new ArrayList<>();
	//		values.add(value);
	//		doc.getFields().put(key, values);
	//	}

	//TODO to improve
	@SuppressWarnings({ "all" })
	public static Map<String, Object> createDoc(Map<String, Object> item) {
		Map<String, Object> fields = new HashMap<>();
		for (Entry<String, Object> entry : item.entrySet()) {
			String key = entry.getKey();
			Object value = entry.getValue();
			fields.put(key, value);
		}
		return fields;
	}

	public static void updateField(Document doc, String key, Object value) {
		doc.getFields().put(key, value);
	}

	//
}
