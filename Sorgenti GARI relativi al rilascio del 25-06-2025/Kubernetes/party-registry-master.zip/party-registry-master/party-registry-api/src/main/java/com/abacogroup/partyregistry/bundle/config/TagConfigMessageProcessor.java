package com.abacogroup.partyregistry.bundle.config;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.apache.commons.lang3.StringUtils;

import com.abacogroup.bundles.initializer.impl.exceptions.BundleException;
import com.abacogroup.bundles.listener.configdata.ConfigDataMessage;
import com.abacogroup.bundles.listener.configdata.ConfigMessageProcessor;
import com.abacogroup.partyregistry.bundle.config.i18n.I18nAware;
import com.abacogroup.partyregistry.bundle.config.i18n.I18nEntry;
import com.abacogroup.partyregistry.bundle.config.i18n.I18nHelper;
import com.abacogroup.partyregistry.bundle.config.i18n.I18nMap;
import com.abacogroup.partyregistry.bundle.utils.FileOperationEnum;
import com.abacogroup.partyregistry.core.BundleConstants;
import com.abacogroup.partyregistry.db.dao.I18nDAO;
import com.abacogroup.partyregistry.db.dao.TagDAO;
import com.abacogroup.partyregistry.db.ntt.TagEntity;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.Data;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class TagConfigMessageProcessor implements ConfigMessageProcessor {

	private final TagDAO tagDAO;

	private final I18nHelper i18nHelper;
	private final ObjectMapper mapper = new ObjectMapper();

	public TagConfigMessageProcessor(TagDAO tagDAO, I18nDAO i18nDAO) {
		this.tagDAO = tagDAO;
		this.i18nHelper = new I18nHelper(i18nDAO);
	}

	@Override
	public String getDomainName() {
		return BundleConstants.DOMAIN_TAGS;
	}

	@Override
	public void onMessage(ConfigDataMessage message) {

		String tenantId = message.getTenantId();

		Function<String, FileOperationEnum> groupingPredicate = x -> {
			if (StringUtils.containsIgnoreCase(x, "delete")) {
				return FileOperationEnum.DELETE;
			} else {
				return FileOperationEnum.DEFAULT;
			}
		};

		List<Path> paths = message.getConfigFiles();
		var map = paths.stream()
				.collect(Collectors.groupingBy(x -> groupingPredicate.apply(x.toString()),
						Collectors.toCollection(ArrayList::new)));

		map.getOrDefault(FileOperationEnum.DEFAULT, new ArrayList<>()).forEach(path -> addContent(tenantId, path));
		map.getOrDefault(FileOperationEnum.DELETE, new ArrayList<>()).forEach(path -> removeContent(tenantId, path));
		
	}

	private void removeContent(String tenantId, Path path) {
	    try (Stream<String> lines = Files.lines(path, StandardCharsets.UTF_8)) {

	        lines.map(String::trim)
	             .filter(s -> !s.isEmpty() && !s.startsWith(BundleConstants.JSONL_COMMENT))
	             .map(this::mapEntity)
	             .forEach(tagEntry -> {
	                 tagDAO.deleteByTenantAndTag(tenantId, tagEntry.getCode());
	                 i18nHelper.deleteUnused(tenantId, "prt_tags", "code", tagEntry.getCode());
	             });

	    } catch (IOException e) {
	        throw new BundleException(String.format("Error reading file: %s", path), e);
	    }
	}
	
	private void addContent(String tenantId, Path path) {
		try {
			try (Stream<String> input = Files.lines(path, StandardCharsets.UTF_8)) {

				List<TagEntry> entries = input
						.map(String::strip)
						.filter(s -> !StringUtils.isBlank(s))
						.filter(s -> !s.startsWith(BundleConstants.JSONL_COMMENT))
						.map(jsonLine -> mapEntity(jsonLine))
						.distinct()
						.collect(Collectors.toList());

				TagEntity[] entities = entries.stream()
						.map(e -> TagEntity.builder()
								.setTenantId(tenantId)
								.setCode(e.getCode())
								.build())
						.toArray(TagEntity[]::new);
				tagDAO.insertIdempotent(entities);
				i18nHelper.upsert(tenantId, "prt_tags", "code", entries);
			}
		} catch (Exception e) {
			throw new BundleException(String.format("error saving file %s", path), e);
		}
	}

	private TagEntry mapEntity(String jsonLine) {
		try {
			TagEntry entry = mapper.readValue(jsonLine, TagEntry.class);
			return entry;
		} catch (Exception e) {
			throw new BundleException("error in deserialization json " + jsonLine, e);
		}
	}

	@Data
	protected static class TagEntry implements I18nAware {
		private String code;

		private I18nMap description;

		@Override
		@JsonIgnore
		public String getI18nCode() {
			return getCode();
		}

		@Override
		@JsonIgnore
		public Set<I18nEntry> getI18n() {
			return getDescription().getI18n();
		}
	}
}
