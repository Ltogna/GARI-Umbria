package com.abacogroup.partyregistry.db.dao;

import com.abacogroup.jdbi.EnhancedSqlObject;
import com.abacogroup.jdbi.criteria.BindCriteria;
import com.abacogroup.jdbi.criteria.Criteria;
import com.abacogroup.jdbi.model.AuditEntity;
import com.abacogroup.jdbi.orderby.DefineOrder;
import com.abacogroup.jdbi.orderby.OrderBy;
import com.abacogroup.partyregistry.api.RelationType;
import com.abacogroup.partyregistry.db.ntt.RelationTypeEntity;
import com.abacogroup.partyregistry.resources.req.ReqContext;
import java.util.Optional;
import org.jdbi.v3.core.result.ResultIterator;
import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.customizer.BindBean;
import org.jdbi.v3.sqlobject.statement.GetGeneratedKeys;
import org.jdbi.v3.sqlobject.statement.SqlBatch;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;
import org.jdbi.v3.sqlobject.transaction.Transactional;

public interface RelationTypeDAO extends Transactional<RelationTypeDAO>, EnhancedSqlObject, Auditable {

	String FIELDS = " id,tenant_id,fl_multiple, fl_multiple as multiple,code ";
	String BASE_SELECT = "select " + FIELDS + " FROM prt_relation_types ";
	String CURRENT_RECORD = " AND (§current_timestamp§ between dt_insert and dt_delete) ";
	String WHERE_TENANT_ID_AND_CODE = " where tenant_id = :tenantId and code = :code ";
	String I18NRelType = ", coalesce (§i18n(:tenantId, 'prt_relation_types', 'code', code, :lang)§, code) as i18n_code\n ";

	@SqlQuery(BASE_SELECT + WHERE_TENANT_ID_AND_CODE + CURRENT_RECORD)
	@RegisterBeanMapper(RelationTypeEntity.class)
	Optional<RelationTypeEntity> findOne(
			@Bind("tenantId") String tenantId,
			@Bind("code") String code);

	//--------------

	@SqlQuery(BASE_SELECT + WHERE_TENANT_ID_AND_CODE)
	@RegisterBeanMapper(RelationTypeEntity.class)
	Optional<RelationTypeEntity> findOneIncludeDeleted(
			@Bind("tenantId") String tenantId,
			@Bind("code") String code);

	@SqlQuery("select * from ("
			+ "SELECT "
			+ FIELDS + I18NRelType + " FROM prt_relation_types where tenant_id = :tenantId " + CURRENT_RECORD + ") inner_result "
			+ "where <criteria> "
			+ "ORDER BY <orderBy>")
	@RegisterBeanMapper(RelationType.class)
	ResultIterator<RelationType> searchAll(
			@BindCriteria Criteria criteria,
			@DefineOrder OrderBy orderBy,
			@BindBean ReqContext ctx);

	@SqlQuery("SELECT " + FIELDS + I18NRelType + "FROM prt_relation_types \n"
			+ "where tenant_id = :tenantId and code = :code " + CURRENT_RECORD)
	@RegisterBeanMapper(RelationType.class)
	Optional<RelationType> searchByCode(
			@Bind("code") String code,
			@BindBean ReqContext ctx);

	//--------------

	@SqlUpdate(
			"INSERT INTO prt_relation_types (tenant_id, code, fl_multiple, dt_insert, user_id_insert, dt_delete, user_id_delete) "
					+ " VALUES (:tenantId, :code, :flMultiple, :dtInsert, :userIdInsert, :dtDelete, :userIdDelete)")
	@GetGeneratedKeys("id")
	Long insert(@BindBean RelationTypeEntity entity);

	@SqlBatch(
			"INSERT INTO prt_relation_types (tenant_id, code, fl_multiple, dt_insert, user_id_insert, dt_delete, user_id_delete) "
					+ " §select_from_dual (:tenantId, :code, :flMultiple, :dtInsert, :userIdInsert, :dtDelete, :userIdDelete)§"
					+ " where not exists("
					+ " select code "
					+ " from prt_relation_types "
					+ " where tenant_id = :tenantId and code = :code AND (§current_timestamp§ between dt_insert and dt_delete))")
	void insertBatchIdempotent(@BindBean RelationTypeEntity... entity);

	@SqlUpdate("update prt_relation_types set dt_delete =:dtDelete, user_id_delete=:userIdDelete where id = :id")
	void expireRow(@BindBean RelationTypeEntity entity);

	@SqlUpdate("UPDATE prt_relation_types SET code = :code, fl_multiple= :flMultiple  WHERE id = :id")
	void update(@BindBean RelationTypeEntity entity);

	@SqlQuery("select count(*) FROM prt_relation_types where tenant_id = :tenantId ")
	Long countAll(@Bind("tenantId") String tenantId);

	@SqlUpdate("INSERT INTO prt_relation_types (tenant_id, code, fl_multiple, dt_insert, user_id_insert, dt_delete, user_id_delete ) " +
			" select :newTenantId as tenant_id, code, fl_multiple, :dtInsert, :userIdInsert, :dtDelete, :userIdDelete " +
			" FROM prt_relation_types prt where prt.tenant_id = :sourceTenant AND (§current_timestamp§ between prt.dt_insert and prt.dt_delete) ")
	void insertNewTenant(
			@Bind("sourceTenant") String sourceTenant,
			@Bind("newTenantId") String newTenantId,
			@BindBean AuditEntity audit);

}


