package com.abacogroup.partyregistry.resources.publicapis.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import com.abacogroup.partyregistry.api.Citizenship;
import com.abacogroup.partyregistry.api.v1.CitizenshipResponseV1;

@Mapper
public interface CitizenshipRespMapper {
	CitizenshipRespMapper INSTANCE = Mappers.getMapper(CitizenshipRespMapper.class);
	
	CitizenshipResponseV1 toV1(Citizenship resp);
}
