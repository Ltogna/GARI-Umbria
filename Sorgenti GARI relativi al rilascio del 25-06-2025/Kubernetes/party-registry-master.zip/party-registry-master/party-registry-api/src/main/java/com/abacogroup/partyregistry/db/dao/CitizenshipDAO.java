package com.abacogroup.partyregistry.db.dao;

import com.abacogroup.jdbi.EnhancedSqlObject;
import com.abacogroup.jdbi.criteria.BindCriteria;
import com.abacogroup.jdbi.criteria.Criteria;
import com.abacogroup.jdbi.orderby.DefineOrder;
import com.abacogroup.jdbi.orderby.OrderBy;
import com.abacogroup.partyregistry.api.Citizenship;
import com.abacogroup.partyregistry.db.ntt.CitizenshipEntity;
import com.abacogroup.partyregistry.resources.req.ReqContext;
import java.util.List;
import java.util.Optional;
import org.jdbi.v3.core.result.ResultIterator;
import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.customizer.BindBean;
import org.jdbi.v3.sqlobject.statement.SqlBatch;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;
import org.jdbi.v3.sqlobject.transaction.Transactional;

public interface CitizenshipDAO extends Transactional<CitizenshipDAO>, EnhancedSqlObject, Auditable {

	String FIELDS = " tenant_id, code ";
	String BASE_SELECT = "select " + FIELDS + " FROM prt_citizenship ";
	String WHERE_TENANT_ID_AND_CODE = " where tenant_id = :tenantId and code = :code ";
	String I18NRelType = ", coalesce (§i18n(:tenantId, 'prt_citizenship', 'code', code, :lang)§, code) as i18n_code\n ";

	@SqlQuery(BASE_SELECT + WHERE_TENANT_ID_AND_CODE)
	@RegisterBeanMapper(CitizenshipEntity.class)
	Optional<CitizenshipEntity> findOne(
			@Bind("tenantId") String tenantId,
			@Bind("code") String code);

	@SqlQuery(BASE_SELECT + " where tenant_id = :tenantId")
	@RegisterBeanMapper(CitizenshipEntity.class)
	List<CitizenshipEntity> findAll(
			@Bind("tenantId") String tenantId);

	@SqlQuery("select * from ("
			+ "SELECT "
			+ FIELDS + I18NRelType + " FROM prt_citizenship where tenant_id = :tenantId ) inner_result "
			+ "where <criteria> "
			+ "ORDER BY <orderBy>")
	@RegisterBeanMapper(Citizenship.class)
	ResultIterator<Citizenship> searchAll(
			@BindCriteria Criteria criteria,
			@DefineOrder OrderBy orderBy,
			@BindBean ReqContext ctx);

	@SqlQuery("SELECT " + FIELDS + I18NRelType + "FROM prt_citizenship \n"
			+ WHERE_TENANT_ID_AND_CODE)
	@RegisterBeanMapper(Citizenship.class)
	Optional<Citizenship> searchByCode(
			@Bind("code") String code,
			@BindBean ReqContext ctx);

	@SqlQuery("select count(*) FROM prt_citizenship where tenant_id = :tenantId ")
	Long countAll(@Bind("tenantId") String tenantId);

	@SqlUpdate("INSERT INTO prt_citizenship (tenant_id, code) VALUES (:tenantId, :code) ")
	void insert(@BindBean CitizenshipEntity entity);

	@SqlBatch("insert into prt_citizenship (tenant_id, code) "
			+ "§select_from_dual(:tenantId, :code)§ "
			+ "where not exists (select code from prt_citizenship where tenant_id = :tenantId and code = :code )")
	void insertIdempotent(@BindBean CitizenshipEntity... entity);

	@SqlUpdate("INSERT INTO prt_citizenship (tenant_id, code) " +
			" select :newTenantId as tenant_id, code " +
			" FROM prt_citizenship  where tenant_id = :sourceTenant ")
	void insertNewTenant(@Bind("sourceTenant") String sourceTenant,
			@Bind("newTenantId") String newTenantId);
}


