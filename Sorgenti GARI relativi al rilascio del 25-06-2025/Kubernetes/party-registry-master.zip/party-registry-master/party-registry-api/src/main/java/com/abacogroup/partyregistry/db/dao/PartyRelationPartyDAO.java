package com.abacogroup.partyregistry.db.dao;

import java.util.List;
import java.util.Optional;

import org.jdbi.v3.core.result.ResultIterator;
import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.customizer.BindBean;
import org.jdbi.v3.sqlobject.statement.GetGeneratedKeys;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;
import org.jdbi.v3.sqlobject.transaction.Transactional;

import com.abacogroup.jdbi.EnhancedSqlObject;
import com.abacogroup.jdbi.criteria.BindCriteria;
import com.abacogroup.jdbi.criteria.Criteria;
import com.abacogroup.jdbi.orderby.DefineOrder;
import com.abacogroup.jdbi.orderby.OrderBy;
import com.abacogroup.partyregistry.api.PartyRelationParty;
import com.abacogroup.partyregistry.db.ntt.PartyRelationPartyEntity;
import com.abacogroup.partyregistry.resources.req.ReqContext;

public interface PartyRelationPartyDAO extends Transactional<PartyRelationPartyDAO>, EnhancedSqlObject {

	String I18NRelType = " coalesce (§i18n(:tenantId, 'prt_relation_types', 'code', rel_type.code, :lang)§, rel_type.code) \n ";
	String I18NRelRole = " coalesce (§i18n(:tenantId, 'prt_relation_roles', 'code', rel_role.code, :lang)§, rel_role.code) \n ";

	String RESPONSE_BASE_SELECT =
			"select party_rel.pkid, \n"
					+ "       party_rel.party_id as related_party_id,\n"
					+ "       ppd_rel.first_name,\n"
					+ "       ppd_rel.last_name,\n"
					+ "       ppd_rel.tax_code, \n"
					+ "       ppd_rel.birth_date, \n"
					+ "       party_rel.dt_start,\n"
					+ "       party_rel.dt_end,\n"
					+ "\n"
					+ "       party_rels.id        as party_relation_id,\n"
					+ "       party_rels.party_id  as party_relation_party_id,\n"
					+ "       pprd.note            as party_relation_note,\n"
					+ "\n"
					+ "       rel_role.id         as relation_role_id,\n"
					+ "       rel_role.code       as related_role_code,\n"
					//+ "       rel_role.type_id    as relation_role_type_id,\n"
					+ I18NRelRole + "      as relation_role_i18n_code,\n"
					+ "\n"
					//+ "       rel_type.id          as party_relation_relation_type_id,\n"
					+ "       rel_type.code        as party_relation_relation_type_code,\n"
					//+ "       rel_type.fl_multiple as party_relation_relation_type_multiple,\n"
					+ I18NRelType + "       as party_relation_relation_type_i18n_code\n"
					+ "\n"
					+ "from prt_party_relation_parties party_rel\n"
					+ "         inner join prt_party_relations party_rels on party_rels.id = party_rel.party_relation_id and (§current_timestamp§ between party_rels.dt_insert and party_rels.dt_delete)\n"
					+ "         inner join prt_relation_roles rel_role on party_rel.relation_role_id = rel_role.id and (§current_timestamp§ between rel_role.dt_insert and rel_role.dt_delete)\n"
					+ "         inner join prt_relation_types rel_type on rel_type.id = party_rels.relation_type_id and (§current_timestamp§ between rel_type.dt_insert and rel_type.dt_delete)\n"
					+ "         left join prt_party_relation_details pprd on pprd.party_relation_id = party_rels.id AND §current_timestamp§ between pprd.dt_insert and pprd.dt_delete\n"

					//check party
					+ "inner join prt_parties pp_rel on pp_rel.id = party_rel.party_id \n"
					+ "inner join prt_parties_detail ppd_rel on pp_rel.id = ppd_rel.party_id AND §current_timestamp§ between ppd_rel.dt_insert and ppd_rel.dt_delete \n"
					+ "inner join prt_parties pp_rels on pp_rels.id = party_rels.party_id \n"
					+ "inner join prt_parties_detail ppd_rels on pp_rels.id = ppd_rels.party_id AND §current_timestamp§ between ppd_rels.dt_insert and ppd_rels.dt_delete \n"

					+ " and (§current_timestamp§ between party_rel.dt_insert and party_rel.dt_delete) \n"
					+ "AND rel_type.tenant_id = :tenantId ";

	String SEARCH_BY_ID =
			RESPONSE_BASE_SELECT
					+ " and party_rel.pkid = :pkid and party_rels.party_id = :partyId "
					+ " and party_rel.party_relation_id = :partyRelationId \n";
	String BASE_SELECT =
			"select party_rel.pkid, party_rel.party_relation_id, party_rel.party_id, party_rel.relation_role_id, party_rel.dt_start, party_rel.dt_end "

					+ "from prt_party_relation_parties party_rel\n"
					+ "         inner join prt_party_relations party_rels on party_rels.id = party_rel.party_relation_id and (§current_timestamp§ between party_rels.dt_insert and party_rels.dt_delete)\n"
					+ "         inner join prt_relation_roles rel_role on party_rel.relation_role_id = rel_role.id and (§current_timestamp§ between rel_role.dt_insert and rel_role.dt_delete)\n"
					+ "         inner join prt_relation_types rel_type on rel_type.id = party_rels.relation_type_id and (§current_timestamp§ between rel_type.dt_insert and rel_type.dt_delete)\n"
					+ "         left join prt_party_relation_details pprd on pprd.party_relation_id = party_rels.id AND §current_timestamp§ between pprd.dt_insert and pprd.dt_delete\n"
					//check party
					+ "inner join prt_parties pp_rel on pp_rel.id = party_rel.party_id \n"
					+ "inner join prt_parties_detail ppd_rel on pp_rel.id = ppd_rel.party_id AND §current_timestamp§ between ppd_rel.dt_insert and ppd_rel.dt_delete \n"
					+ "inner join prt_parties pp_rels on pp_rels.id = party_rels.party_id \n"
					+ "inner join prt_parties_detail ppd_rels on pp_rels.id = ppd_rels.party_id AND §current_timestamp§ between ppd_rels.dt_insert and ppd_rels.dt_delete \n"
					;

	@SqlQuery("select * from ( " + RESPONSE_BASE_SELECT
			+ " AND party_rels.party_id = :partyId and party_rel.party_relation_id = :partyRelationId"
			+ " ) inner_result where <criteria> ORDER BY <orderBy>")
	@RegisterBeanMapper(PartyRelationParty.class)
	ResultIterator<PartyRelationParty> searchAll(
			@Bind("partyId") Long ownerPartyId,
			@Bind("partyRelationId") Long partyRelationId,
			@BindCriteria Criteria criteria,
			@DefineOrder OrderBy orderBy,
			@BindBean ReqContext ctx);

	//-------------------------

	@SqlQuery(SEARCH_BY_ID)
	@RegisterBeanMapper(PartyRelationParty.class)
	Optional<PartyRelationParty> getById(
			@Bind("partyId") Long partyId,
			@Bind("partyRelationId") Long partyRelationId,
			@Bind("pkid") Long pkid,
			@BindBean ReqContext ctx);

	@SqlQuery(BASE_SELECT
			+ "WHERE rel_type.tenant_id = :tenantId "
			+ " and party_rel.pkid = :id "
			+ " and party_rels.party_id = :partyId "
			+ " and party_rel.party_relation_id = :partyRelationId "
			+ " and (§current_timestamp§ between party_rel.dt_insert and party_rel.dt_delete) ")
	@RegisterBeanMapper(PartyRelationPartyEntity.class)
	Optional<PartyRelationPartyEntity> findById(
			@Bind("tenantId") String tenantId,
			@Bind("partyId") Long partyId,
			@Bind("partyRelationId") Long partyRelationId,
			@Bind("id") Long id
	);

	@SqlQuery(BASE_SELECT
			+ "WHERE rel_type.tenant_id = :tenantId "
			+ " and party_rels.party_id = :partyId "
			+ " and party_rel.party_relation_id = :partyRelationId "
			+ " and (§current_timestamp§ between party_rel.dt_insert and party_rel.dt_delete) ")
	@RegisterBeanMapper(PartyRelationPartyEntity.class)
	List<PartyRelationPartyEntity> findByRelationId(
			@Bind("tenantId") String tenantId,
			@Bind("partyId") Long partyId,
			@Bind("partyRelationId") Long partyRelationId
	);

	@Deprecated
	@SqlQuery("SELECT pkid,party_relation_id,party_id,relation_role_id "
			+ ",dt_start,dt_end,dt_insert,user_id_insert,dt_delete,user_id_delete "
			+ "FROM prt_party_relation_parties  "
			+ "WHERE party_id = :partyId and party_relation_id = :partyRelationId and relation_role_id = :relationRoleId "
			+ "and (§current_timestamp§ between dt_insert and dt_delete) ")
	@RegisterBeanMapper(PartyRelationPartyEntity.class)
	Optional<PartyRelationPartyEntity> find(
			@BindBean ReqContext context,
			@Bind("partyRelationId") Long partyRelationId,
			@Bind("partyId") Long partyId,
			@Bind("relationRoleId") Long relationRoleId);

	@SqlUpdate("update prt_party_relation_parties set dt_delete =:dtDelete, user_id_delete=:userIdDelete where pkid = :pkid")
	void expirePartyRelationParty(@BindBean PartyRelationPartyEntity partyRelationPartyEntity);

	@SqlUpdate("update prt_party_relation_parties set dt_delete =:dtDelete, user_id_delete=:userIdDelete where party_relation_id = :partyRelationId "
			+ " and dt_delete >= TO_DATE('9999-12-31','YYYY-MM-DD')")
	void expirePartyRelationPartyByRelationId(@BindBean PartyRelationPartyEntity partyRelationPartyEntity);

	@SqlUpdate(
			"INSERT INTO prt_party_relation_parties (pkid, party_relation_id, party_id, relation_role_id, dt_start, dt_end, dt_insert, user_id_insert, dt_delete, user_id_delete) "
					+ "VALUES (:sequenceId, :partyRelationId, :partyId, :relationRoleId, :dtStart, :dtEnd, :dtInsert, :userIdInsert, :dtDelete, :userIdDelete )")
	void insertPartyRelParty(@BindBean PartyRelationPartyEntity entity, @Bind("sequenceId") Long id);

	@SqlUpdate(
			"INSERT INTO prt_party_relation_parties (party_relation_id, party_id, relation_role_id, dt_start, dt_end, dt_insert, user_id_insert, dt_delete, user_id_delete) "
					+ "VALUES (:partyRelationId, :partyId, :relationRoleId, :dtStart, :dtEnd, :dtInsert, :userIdInsert, :dtDelete, :userIdDelete )")
	@GetGeneratedKeys("pkid")
	long insertPartyRelParty(@BindBean PartyRelationPartyEntity entity);

}
