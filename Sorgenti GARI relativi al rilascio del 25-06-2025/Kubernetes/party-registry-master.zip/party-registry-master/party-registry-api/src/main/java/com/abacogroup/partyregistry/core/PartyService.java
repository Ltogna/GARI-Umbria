package com.abacogroup.partyregistry.core;

import java.util.List;
import java.util.Map;
import java.util.Optional;

import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.partyregistry.api.PartyRes;
import com.abacogroup.partyregistry.api.PartySearchRes;
import com.abacogroup.partyregistry.db.ntt.PartyEntity;
import com.abacogroup.partyregistry.resources.req.PartyCheckReq;
import com.abacogroup.partyregistry.resources.req.PartyCodeCheckReq;
import com.abacogroup.partyregistry.resources.req.PartyCreateReq;
import com.abacogroup.partyregistry.resources.req.PartySearchReq;
import com.abacogroup.partyregistry.resources.req.PartyUpdateReq;
import com.abacogroup.partyregistry.resources.req.ReqContext;

public interface PartyService {

	PartyRes insert(ReqContext reqContext, PartyCreateReq party, String sourceCode);

	default PartyRes update(ReqContext reqContext, Long id, PartyUpdateReq party) {
		return update(reqContext, id, party, null);
	}

	PartyRes update(ReqContext reqContext, Long id, PartyUpdateReq party, String sourceCode);

	InfiniteListResults<PartySearchRes> search(ReqContext reqContext, PartySearchReq searchRequest, Integer withManage, String nextKey);

	InfiniteListResults<PartySearchRes> doSearch(ReqContext reqContext, PartySearchReq searchRequest, Integer withManage, String nextKey);

	Optional<PartyRes> getPartyById(ReqContext reqContext, Long id);

	Optional<PartyRes> getPartyByCode(ReqContext reqContext, String code);

	PartyRes archive(ReqContext reqContext, Long id, boolean archiveStatus);

	void expire(ReqContext reqContext, Long id);

	List<PartyEntity> loadDuplicates(String tenantId, PartyCheckReq partyCheckReq);

	Map<String,Boolean> loadDuplicatesDetail(String tenantId, PartyCheckReq partyCheckReq);


	List<PartyEntity> loadDuplicatesCode(String tenantId, PartyCodeCheckReq partyCodeCheckReq);

	Optional<PartyEntity> loadEntity(String tenantId, Long id);

	List<PartySearchRes> searchByIdIn(ReqContext reqContext, List<Long> ids, Integer withManage);

}
