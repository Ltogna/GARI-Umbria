package com.abacogroup.partyregistry.db.ntt;

import com.abacogroup.jdbi.model.AuditEntity;
import java.time.LocalDateTime;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder(setterPrefix = "set")
@NoArgsConstructor
public class PartyRelationDetailEntity implements AuditEntity {

	private Long pkid;
	private Long partyRelationId;
	private String note;

	private LocalDateTime dtInsert;
	private String userIdInsert;
	private LocalDateTime dtDelete;
	private String userIdDelete;
}
