package com.abacogroup.partyregistry.resources;

import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.partyregistry.api.Tag;
import com.abacogroup.partyregistry.core.TagService;
import com.abacogroup.partyregistry.resources.req.ReqContext;
import com.abacogroup.partyregistry.resources.req.TagSearchReq;
import io.dropwizard.auth.Auth;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import jakarta.annotation.security.RolesAllowed;
import jakarta.ws.rs.BeanParam;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DefaultValue;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.HeaderParam;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.MediaType;
import java.util.List;

@SuppressWarnings("UnresolvedRestParam")
@Path(ResourceConstants.API_PRIV + "/tags")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
@io.swagger.v3.oas.annotations.tags.Tag(name = "tags", description = "Operations on tags")
public class TagResource {

	private final TagService tagService;

	public TagResource(TagService tagService) {
		this.tagService = tagService;
	}

	@Operation(summary = "List of tags", description = "Get list of tags filtered with criteria")
	@ApiResponses({
			@ApiResponse(responseCode = "200", description = "Successfully, returns a list of tags (sorted/filtered)",
					content = @Content(mediaType = "application/json", schema = @Schema(ref = "#/components/schemas/InfiniteListResultsTag")))
	})
	@GET
	@RolesAllowed("PARTY-REGISTRY|READ")
	public InfiniteListResults<Tag> search(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "tenant ID") @PathParam("tenant") String tenantId,
			@Parameter(description = "Can be supplied to obtain the records that follows those obtained by a previous call") @QueryParam("nextKey") String nextKey,
			@BeanParam TagSearchReq searchRequest) {
		ReqContext reqContext = new ReqContext(user, lang);
		return tagService.searchTags(reqContext, searchRequest, nextKey);
	}

	@Operation(summary = "List of tags", description = "Get list of tags filtered with criteria")
	@ApiResponses({
			@ApiResponse(responseCode = "200", description = "Successful, returns a list of tags (sorted/filtered)",
					content = @Content(mediaType = "application/json", array = @ArraySchema(
							schema = @Schema(implementation = Tag.class))))
	})
	@GET
	@RolesAllowed("PARTY-REGISTRY|READ")
	@Path("/list")
	public List<Tag> searchList(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "tenant ID") @PathParam("tenant") String tenantId,
			@BeanParam TagSearchReq searchRequest) {
		ReqContext reqContext = new ReqContext(user, lang);
		return tagService.searchTagList(reqContext, searchRequest);
	}

}
