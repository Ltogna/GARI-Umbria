package com.abacogroup.partyregistry.resources.publicapis.mapper;

import com.abacogroup.partyregistry.api.AppConfigRes;
import com.abacogroup.partyregistry.api.v1.AppConfigResponseV1;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper
public interface AppConfigResMapper {

	AppConfigResMapper INSTANCE = Mappers.getMapper(AppConfigResMapper.class);

	AppConfigResponseV1 toV1(AppConfigRes appConfigRes);

}
