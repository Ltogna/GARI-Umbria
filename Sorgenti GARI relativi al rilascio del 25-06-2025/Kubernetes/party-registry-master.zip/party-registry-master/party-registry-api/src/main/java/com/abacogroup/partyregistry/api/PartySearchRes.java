package com.abacogroup.partyregistry.api;

import com.abacogroup.jdbi.datatype.AbsoluteDate;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;
import org.jdbi.v3.core.mapper.Nested;
import org.jdbi.v3.core.mapper.reflect.ColumnName;

@Data
@SuperBuilder(setterPrefix = "set")
@NoArgsConstructor

public class PartySearchRes {

	private Long id;
	private PartyTypeEnum partyType;

	private String lastName;
	private String firstName;

	private String taxCode;
	private String vatNumber;
	private String code;
	private String legalStatus;

	private AbsoluteDate birthDate;
	private AbsoluteDate deathDate;

	private String birthMunicipality;
	private String nationality;

	@Nested("address")
	private AddressRes addressResidential;

	@ColumnName("fl_archived")
	private boolean archived = false;

}
