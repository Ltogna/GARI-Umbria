package com.abacogroup.partyregistry.resources;

import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.partyregistry.api.ExternalSourceRes;
import com.abacogroup.partyregistry.core.ExternalSourceService;
import com.abacogroup.partyregistry.resources.req.ReqContext;
import io.dropwizard.auth.Auth;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.annotation.security.RolesAllowed;
import jakarta.ws.rs.DefaultValue;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.HeaderParam;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import java.util.List;

@Path(ResourceConstants.API_PRIV + "/external-sources")
@Produces(MediaType.APPLICATION_JSON)
@Tag(name = "external sources", description = "Operations on external sources")
public class ExternalSourceResource {

	private final ExternalSourceService externalSourceService;

	public ExternalSourceResource(ExternalSourceService externalSourceService) {
		this.externalSourceService = externalSourceService;
	}

	@Operation(summary = "List of external sources", description = "Get list of all external sources")
	@ApiResponses({
			@ApiResponse(responseCode = "200", description = "Successful, returns a list of external sources", useReturnTypeSchema = true)
	})
	@GET
	@RolesAllowed("PARTY-REGISTRY|READ")
	public List<ExternalSourceRes> searchList(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "tenant ID") @PathParam("tenant") String tenantId) {
		ReqContext reqContext = new ReqContext(user, lang);
		return externalSourceService.getAll(reqContext);
	}

}
