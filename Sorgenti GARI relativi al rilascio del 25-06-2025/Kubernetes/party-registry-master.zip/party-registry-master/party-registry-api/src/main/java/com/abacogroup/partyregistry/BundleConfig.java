package com.abacogroup.partyregistry;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Data
public class BundleConfig {

	@NotBlank
	private String configLocation;

	private String initBaseTempDir;

	private Long initialResendDelayMs = 30_000L;
	private Long listenerTimeoutMs = 300_000L;

}
