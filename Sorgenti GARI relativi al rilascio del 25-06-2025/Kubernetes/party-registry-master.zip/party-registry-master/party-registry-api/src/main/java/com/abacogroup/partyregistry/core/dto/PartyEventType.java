package com.abacogroup.partyregistry.core.dto;

public enum PartyEventType {

	NEW_PARTY("new-party"),
	UPDATE_PARTY("update-party"),
	ARCHIVE_PARTY("archive-party"),
	DELETE_PARTY("delete-party"),
	;

	public static final String TOPIC_PREFIX = "party";

	private final String topic;

	PartyEventType(String topicName) {
		this.topic = topicName;
	}

	public String getTopic() {
		return String.format("%s.%s", TOPIC_PREFIX, topic);
	}
}
