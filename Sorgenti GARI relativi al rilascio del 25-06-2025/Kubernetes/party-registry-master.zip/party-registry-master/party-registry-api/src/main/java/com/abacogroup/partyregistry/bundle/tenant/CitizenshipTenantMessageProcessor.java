package com.abacogroup.partyregistry.bundle.tenant;

import static com.abacogroup.bundles.Constants.ALL_TENANTS;

import com.abacogroup.bundles.listener.tenant.TenantMessage;
import com.abacogroup.bundles.listener.tenant.TenantMessageProcessor;
import com.abacogroup.partyregistry.db.dao.CitizenshipDAO;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class CitizenshipTenantMessageProcessor implements TenantMessageProcessor {

	private final CitizenshipDAO citizenshipDAO;

	public CitizenshipTenantMessageProcessor(CitizenshipDAO citizenshipDAO) {
		this.citizenshipDAO = citizenshipDAO;
	}

	@Override
	public void onMessage(TenantMessage message) {
		String tenantId = message.getTenantId();
		if (citizenshipDAO.countAll(tenantId) > 0L) {
			log.warn("citizenships already present for tenant {}", tenantId);
		} else {
			citizenshipDAO.insertNewTenant(ALL_TENANTS, tenantId);
		}
	}

}
