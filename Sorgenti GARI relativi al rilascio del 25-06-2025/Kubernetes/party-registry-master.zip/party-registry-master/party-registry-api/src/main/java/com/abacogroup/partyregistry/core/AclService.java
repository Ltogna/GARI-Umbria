package com.abacogroup.partyregistry.core;

import com.abacogroup.partyregistry.resources.req.ReqContext;

public interface AclService {

	// XXX hasManage, if -1 skip check, 0 must have almost one read manadate, 1 must have almost one manage mandate
	static final int MANAGE_READ = 0;
	static final int MANAGE_FULL = 1;
	static final int MANAGE_SKIP = -1;

	boolean ignoreACL(ReqContext reqContext);
	
	void canWrite(ReqContext reqContext, Long partyId);
	
	default void canRead(ReqContext reqContext, Long partyId) {
		canRead(reqContext, partyId, false);
	}

	/**
	 * Check if the user can read data for the partyId, otherwise throw an exception
	 * if skipIfIgnoreACL is true skip the check when the user has the IGNORE_PARTIES_ACL function
	 * and, of course, acl is enabled 
	 * @param reqContext: request context of the call
	 * @param partyId: the party id
	 * @param skipIfIgnoreACL: boolean true if try to skip
	 */
	void canRead(ReqContext reqContext, Long partyId, boolean skipIfIgnoreACL);
	
	void canAdd(ReqContext reqContext);

	void isAuthorized(ReqContext reqContext, Long partyId, Integer withManage);

	void isAuthorized(ReqContext reqContext, Object party, Integer withManage);

	void isAuthorized(ReqContext reqContext, Object party, String idFieldName, Integer withManage);

	boolean hasMandates(ReqContext reqContext, Long partyId);
}
