package com.abacogroup.partyregistry.db.dao;

import com.abacogroup.partyregistry.db.ntt.Address;
import java.util.Optional;
import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.customizer.BindBean;
import org.jdbi.v3.sqlobject.statement.GetGeneratedKeys;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;
import org.jdbi.v3.sqlobject.transaction.Transactional;

public interface AddressDAO extends Transactional<AddressDAO> {

	@SqlUpdate(
			"INSERT INTO prt_addresses ( municipality, locality, street, house_number, postcode, details, note) "
					+ "VALUES (:municipality, :locality, :street, :houseNumber, :postcode, :details, :note)")
	@GetGeneratedKeys("id")
	Long insert(@BindBean Address address);

	@SqlQuery("select * from prt_addresses where id = :id")
	@RegisterBeanMapper(Address.class)
	Optional<Address> loadById(@Bind("id") Long id);
}
