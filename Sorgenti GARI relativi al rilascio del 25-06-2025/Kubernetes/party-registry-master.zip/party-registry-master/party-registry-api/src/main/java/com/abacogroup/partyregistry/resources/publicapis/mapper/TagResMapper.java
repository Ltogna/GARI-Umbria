package com.abacogroup.partyregistry.resources.publicapis.mapper;

import com.abacogroup.partyregistry.api.Tag;
import com.abacogroup.partyregistry.api.v1.TagResponseV1;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper
public interface TagResMapper {

	TagResMapper INSTANCE = Mappers.getMapper(TagResMapper.class);

	TagResponseV1 toV1(Tag tag);
}
