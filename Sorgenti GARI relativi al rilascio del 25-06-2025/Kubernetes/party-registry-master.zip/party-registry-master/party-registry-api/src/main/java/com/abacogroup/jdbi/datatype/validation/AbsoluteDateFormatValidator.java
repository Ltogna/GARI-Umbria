package com.abacogroup.jdbi.datatype.validation;

import static com.abacogroup.jdbi.datatype.AbsoluteDate.DATE_PATTERN;

import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.regex.Pattern;
import org.hibernate.validator.internal.engine.constraintvalidation.ConstraintValidatorContextImpl;

public class AbsoluteDateFormatValidator implements ConstraintValidator<AbsoluteDateFormat, String> {

	public static final String DATE_DEFAULT_STR = "99991231";
	public static final String DATE_REGEXP = "(?<!\\d)(?:(?:(?:1[6-9]|[2-9]\\d)?\\d{2})(?:(?:(?:0[13578]|1[02])31)|(?:(?:0[1,3-9]|1[0-2])(?:29|30)))|(?:(?:(?:(?:1[6-9]|[2-9]\\d)?(?:0[48]|[2468][048]|[13579][26])|(?:(?:16|[2468][048]|[3579][26])00)))0229)|(?:(?:1[6-9]|[2-9]\\d)?\\d{2})(?:(?:0?[1-9])|(?:1[0-2]))(?:0?[1-9]|1\\d|2[0-8]))(?!\\d)";

	@Override
	public void initialize(AbsoluteDateFormat constraintAnnotation) {
		ConstraintValidator.super.initialize(constraintAnnotation);
	}

	@Override
	public boolean isValid(String value, ConstraintValidatorContext context) {
		if (value == null) {
			return true;
		}

		DateTimeFormatter formatter = DateTimeFormatter.ofPattern(DATE_PATTERN);
		((ConstraintValidatorContextImpl) context).addMessageParameter("dateFormat", DATE_PATTERN);
		try {
			LocalDate.parse(value, formatter);
			Pattern pattern = Pattern.compile(DATE_REGEXP);
			if (pattern.matcher(value).matches()) {
				return true;
			} else {
				((ConstraintValidatorContextImpl) context).addMessageParameter("errorMessage",
						String.format("Text '%s' could not be parsed: Invalid value for DayOfMonth", value));
				return false;
			}
		} catch (DateTimeParseException dtpe) {
			((ConstraintValidatorContextImpl) context).addMessageParameter("errorMessage", dtpe.getMessage());
			return false;
		}
	}

}
