package com.abacogroup.partyregistry.bundle.tenant;

import static com.abacogroup.bundles.Constants.ALL_TENANTS;

import com.abacogroup.bundles.listener.tenant.TenantMessage;
import com.abacogroup.bundles.listener.tenant.TenantMessageProcessor;
import com.abacogroup.partyregistry.core.BundleConstants;
import com.abacogroup.partyregistry.core.impl.AuditHelper;
import com.abacogroup.partyregistry.db.dao.ExternalSourceDAO;
import com.abacogroup.partyregistry.db.ntt.ExternalSourceEntity;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class ExternalSourceTenantMessageProcessor implements TenantMessageProcessor {

	private final ExternalSourceDAO externalSourceDAO;

	public ExternalSourceTenantMessageProcessor(ExternalSourceDAO externalSourceDAO) {
		this.externalSourceDAO = externalSourceDAO;
	}

	@Override
	public void onMessage(TenantMessage tenantMessage) {
		String tenantId = tenantMessage.getTenantId();
		if (externalSourceDAO.countAll(tenantId) > 0L) {
			log.warn("external sources already present for tenant {}", tenantId);
		} else {
			ExternalSourceEntity auditSource = new ExternalSourceEntity();
			AuditHelper.setAuditForInsert(BundleConstants.SYSTEM_USER, externalSourceDAO, auditSource);
			externalSourceDAO.insertNewTenant(ALL_TENANTS, tenantId, auditSource);
		}
	}
}
