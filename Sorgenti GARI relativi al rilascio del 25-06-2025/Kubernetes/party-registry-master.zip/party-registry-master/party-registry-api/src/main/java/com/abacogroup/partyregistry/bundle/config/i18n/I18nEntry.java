package com.abacogroup.partyregistry.bundle.config.i18n;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder(setterPrefix = "set")
@NoArgsConstructor
public class I18nEntry {

	private String lang;

	private String code;

}
