package com.abacogroup.partyregistry.resources;

import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.partyregistry.api.ContactSearchResponse;
import com.abacogroup.partyregistry.api.PartyContact;
import com.abacogroup.partyregistry.core.AclService;
import com.abacogroup.partyregistry.core.ContactService;
import com.abacogroup.partyregistry.core.exceptions.ErrCodes;
import com.abacogroup.partyregistry.core.exceptions.InvalidPartyException;
import com.abacogroup.partyregistry.core.exceptions.InvalidPayloadException;
import com.abacogroup.partyregistry.resources.req.ContactSearchReq;
import com.abacogroup.partyregistry.resources.req.PartyContactReq;
import com.abacogroup.partyregistry.resources.req.ReqContext;

import io.dropwizard.auth.Auth;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.annotation.security.RolesAllowed;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import jakarta.ws.rs.BeanParam;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.DefaultValue;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.HeaderParam;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Path(ResourceConstants.API_PRIV + "/parties/{partyId}/contacts")
@Produces(MediaType.APPLICATION_JSON)
@Tag(name = "party contacts", description = "Operations on party contacts")
public class PartyContactsResource {
	
	private static final boolean SKIP_ACL_IF_CAN_IGNORE = true;

	private final AclService aclService;
	private final ContactService contactService;

	public PartyContactsResource(AclService aclService, ContactService contactService) {
		this.aclService = aclService;
		this.contactService = contactService;
	}

	@GET
	@RolesAllowed("PARTY-REGISTRY|READ")
	@Operation(summary = "List of party contacts", description = "Get list of party contacts filtered with criteria")
	@ApiResponses({
			@ApiResponse(responseCode = "200", description = "Successfully, returns a list of party contacts (sorted/filtered)",
					content = @Content(mediaType = "application/json",
							schema = @Schema(ref = "#/components/schemas/InfiniteListResultsContactSearchResponse"))) })
	public InfiniteListResults<ContactSearchResponse> search(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "the tenant ID") @PathParam("tenant") String tenantId,
			@Parameter(description = "Can be supplied to obtain the records that follows those obtained by a previous call") @QueryParam("nextKey") String nextKey,
			@BeanParam ContactSearchReq contactSearchReq
	) {

		ReqContext reqContext = new ReqContext(user, lang);
		aclService.canRead(reqContext, contactSearchReq.getPartyId(), SKIP_ACL_IF_CAN_IGNORE);
		return contactService.search(reqContext, contactSearchReq, nextKey);
	}

	@Operation(summary = "Create contact party", description = "Insert a new contact for a party")
	@ApiResponses({
			@ApiResponse(responseCode = "200", description = "Successfully, the contact party has been correctly created",
					content = @Content(mediaType = "application/json", schema = @Schema(implementation = PartyContact.class))),
			@ApiResponse(responseCode = "400", description = "party not found or Invalid payload [PartyContactReq]",
					content = @Content(mediaType = "application/json", schema = @Schema(anyOf = {
							InvalidPartyException.ErrorBody.class,
							InvalidPayloadException.ErrorBody.class
					})))
	})
	@POST
	@RolesAllowed("PARTY-REGISTRY|WRITE")
	public PartyContact addContact(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "the tenant ID") @PathParam("tenant") String tenantId,

			@Parameter(description = "the party ID") @PathParam("partyId") Long partyId,
			@NotNull @Valid PartyContactReq contact
	) {
		ReqContext reqContext = new ReqContext(user, lang);
		aclService.canWrite(reqContext, partyId);
		if (!contact.isValid()) {
			throw new InvalidPayloadException(ErrCodes.INVALID_PAYLOAD,
					String.format("The value %s for contact type %s is invalid.", contact.getContactValue(), contact.getContactType()));
		}
		PartyContact partyContact = contactService.insert(reqContext, partyId, contact, true);
		return partyContact;
	}

	@Operation(summary = "Update contact party", description = "Update an existing contact party")
	@ApiResponses({
			@ApiResponse(responseCode = "200", description = "Successfully, the party is updated",
					content = @Content(mediaType = "application/json", schema = @Schema(implementation = PartyContact.class))),
			@ApiResponse(responseCode = "400", description = "party not found or Invalid payload [PartyContactReq]",
					content = @Content(mediaType = "application/json", schema = @Schema(anyOf = {
							InvalidPartyException.ErrorBody.class,
							InvalidPayloadException.ErrorBody.class
					})))
	})
	@PUT
	@RolesAllowed("PARTY-REGISTRY|WRITE")
	@Path("/{id}")
	public PartyContact updateContact(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "the tenant ID") @PathParam("tenant") String tenantId,

			@Parameter(description = "the party ID") @PathParam("partyId") Long partyId,
			@Parameter(description = "the contract ID") @PathParam("id") Long pkId,
			@NotNull @Valid PartyContactReq contact
	) {

		ReqContext reqContext = new ReqContext(user, lang);
		aclService.canWrite(reqContext, partyId);
		if (!contact.isValid()) {
			throw new InvalidPayloadException(ErrCodes.INVALID_PAYLOAD,
					String.format("The value %s' for contact type %s is invalid.", contact.getContactValue(), contact.getContactType()));
		}
		PartyContact partyContact = contactService.update(reqContext, partyId, pkId, contact);
		return partyContact;
	}

	@Operation(summary = "delete contact party", description = "delete an existing contact party by setting it as expired")
	@ApiResponses({
			@ApiResponse(responseCode = "200", description = "Contact party deleted (Expired)"),
			@ApiResponse(responseCode = "400", description = "Invalid party", content = @Content(schema = @Schema(implementation = InvalidPartyException.ErrorBody.class)))
	})
	@DELETE
	@RolesAllowed("PARTY-REGISTRY|DELETE")
	@Path("/{id}")
	public Response expireContact(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "the tenant ID") @PathParam("tenant") String tenantId,

			@Parameter(description = "the party ID") @PathParam("partyId") Long partyId,
			@Parameter(description = "the contract ID") @PathParam("id") Long pkId
	) {
		ReqContext reqContext = new ReqContext(user, lang);
		aclService.canWrite(reqContext, partyId);
		contactService.expireContact(reqContext, partyId, pkId);
		return Response.ok().build();
	}

}

