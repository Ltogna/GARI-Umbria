package com.abacogroup.partyregistry.resources.publicapis;

import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.partyregistry.api.v1.PartyRelationResponseV1;
import com.abacogroup.partyregistry.api.v1.req.PartyRelationTypeSearchRequestV1;
import com.abacogroup.partyregistry.core.AclService;
import com.abacogroup.partyregistry.core.PartyRelationService;
import com.abacogroup.partyregistry.resources.PublicResourceConstants;
import com.abacogroup.partyregistry.resources.publicapis.mapper.RelationPublicMapper;
import com.abacogroup.partyregistry.resources.req.ReqContext;
import io.dropwizard.auth.Auth;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.ws.rs.BeanParam;
import jakarta.ws.rs.DefaultValue;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.HeaderParam;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.MediaType;

@Path(PublicResourceConstants.API_V1_PUB + "/parties/{partyId}/relation-types")
@Produces(MediaType.APPLICATION_JSON)
@Tag(name = "party relation types", description = "Operations on party relation types")
public class PartyRelationPublicResource {

	private final AclService aclService;
	private final PartyRelationService partyRelationService;

	public PartyRelationPublicResource(AclService aclService, PartyRelationService partyRelationService) {
		this.aclService = aclService;
		this.partyRelationService = partyRelationService;
	}

	@Operation(summary = "List of party relation types", description = "Get list of relation types of a party filtered with criteria")
	@ApiResponses({
			@ApiResponse(responseCode = "200", description = "Successfully, returns a list relation types (sorted/filtered)",
					content = @Content(mediaType = "application/json",
							schema = @Schema(ref = "#/components/schemas/InfiniteListResultsPartyRelationResponseV1")))
	})
	@GET
//	@RolesAllowed("PARTY-REGISTRY|READ")
	public InfiniteListResults<PartyRelationResponseV1> search(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@PathParam("tenant") String tenantId,

			@Parameter(description = "the party ID") @PathParam("partyId") Long partyId,
			@Parameter(description = "Can be supplied to obtain the records that follows those obtained by a previous call") @QueryParam("nextKey") String nextKey,
			@BeanParam PartyRelationTypeSearchRequestV1 searchRequest) {

		ReqContext reqContext = new ReqContext(user, lang);
		aclService.canRead(reqContext, partyId);
		return partyRelationService.search(reqContext, partyId, RelationPublicMapper.INSTANCE.fromSearchRequestV1(searchRequest), nextKey)
				.map(RelationPublicMapper.INSTANCE::toResponseV1);
	}

}

