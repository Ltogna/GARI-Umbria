package com.abacogroup.partyregistry.db.dao;

import com.abacogroup.jdbi.EnhancedSqlObject;
import com.abacogroup.jdbi.criteria.BindCriteria;
import com.abacogroup.jdbi.criteria.Criteria;
import com.abacogroup.jdbi.model.AuditEntity;
import com.abacogroup.jdbi.orderby.DefineOrder;
import com.abacogroup.jdbi.orderby.OrderBy;
import com.abacogroup.partyregistry.api.DocType;
import com.abacogroup.partyregistry.db.ntt.DocTypeEntity;
import com.abacogroup.partyregistry.db.ntt.DocTypeRelationEntity;
import com.abacogroup.partyregistry.db.ntt.DocTypeTagRelationEntity;
import com.abacogroup.partyregistry.resources.req.ReqContext;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.customizer.BindBean;
import org.jdbi.v3.sqlobject.customizer.BindList;
import org.jdbi.v3.sqlobject.customizer.BindList.EmptyHandling;
import org.jdbi.v3.sqlobject.statement.SqlBatch;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;
import org.jdbi.v3.sqlobject.transaction.Transactional;

public interface DocTypeDAO extends Transactional<DocTypeDAO>, EnhancedSqlObject {

	String FIELDS = " pdt.id, pdt.tenant_id, pdt.doc_type, pdt.doc_group, pdt.dt_insert, pdt.user_id_insert, pdt.dt_delete, pdt.user_id_delete ";

	String I18N_DOC_TYPE = ", coalesce (§i18n(:tenantId, 'prt_doc_type', 'doc_type', doc_type, :lang)§, doc_type) AS i18n_doc_type ";

	String I18N_DOC_GROUP = ", coalesce (§i18n(:tenantId, 'prt_doc_type', 'doc_group', doc_group, :lang)§, doc_group) AS i18n_doc_group ";

	String CURRENT_RECORD = " AND (§current_timestamp§ between pdt.dt_insert and pdt.dt_delete) ";

	@SqlQuery(
			"select * from ( select distinct(pdt.id), pdt.tenant_id, pdt.doc_type, pdt.doc_group, pdt.dt_insert, pdt.user_id_insert, pdt.dt_delete, pdt.user_id_delete "
					+ I18N_DOC_TYPE
					+ I18N_DOC_GROUP
					+ " from prt_doc_type pdt "
					+ " inner join prt_doc_type_relations rel on rel.doc_type_id =  pdt.id  "
					+ " left outer join prt_doc_type_tags pdtt on pdt.id = pdtt.doc_type_id AND (§current_timestamp§ between pdtt.dt_insert and pdtt.dt_delete)"
					+ " where pdt.tenant_id = :tenantId "
					+ " AND rel.party_type in (<partyTypes>) "
					+ " AND  pdtt.tag_id is null"
					+ " AND (§current_timestamp§ between pdt.dt_insert and pdt.dt_delete)"
					+ " ) inner_result "
					+ " where <criteria> ORDER BY <orderBy> ")

	@RegisterBeanMapper(DocType.class)
	List<DocType> searchAsList(
			@BindBean ReqContext ctx,
			@BindList("partyTypes") Set<String> partyTypes,
			@BindCriteria Criteria criteria,
			@DefineOrder OrderBy orderBy);

	@SqlQuery(
			"select * from ( select distinct(pdt.id), pdt.tenant_id, pdt.doc_type, pdt.doc_group, pdt.dt_insert, pdt.user_id_insert, pdt.dt_delete, pdt.user_id_delete "
					+ I18N_DOC_TYPE
					+ I18N_DOC_GROUP
					+ " from prt_doc_type pdt "
					+ " inner join prt_doc_type_relations rel on rel.doc_type_id =  pdt.id  "
					+ " left outer join prt_doc_type_tags pdtt on pdt.id = pdtt.doc_type_id AND (§current_timestamp§ between pdtt.dt_insert and pdtt.dt_delete)"
					+ " where pdt.tenant_id = :tenantId "
					+ " AND rel.party_type in (<partyTypes>) "
					+ " AND (pdtt.tag_id in (<tags>) or pdtt.tag_id is null)"
					+ " AND (§current_timestamp§ between pdt.dt_insert and pdt.dt_delete)"

					+ " ) inner_result "
					+ " where <criteria> ORDER BY <orderBy> ")

	@RegisterBeanMapper(DocType.class)
	List<DocType> searchAsList(
			@BindBean ReqContext ctx,
			@BindList(value = "tags", onEmpty = EmptyHandling.NULL_VALUE) List<Long> tags,
			@BindList("partyTypes") Set<String> partyTypes,
			@BindCriteria Criteria criteria,
			@DefineOrder OrderBy orderBy);

	@SqlQuery("select " + FIELDS
			+ I18N_DOC_TYPE
			+ I18N_DOC_GROUP
			+ "from prt_doc_type pdt "
			+ "where pdt.tenant_id = :tenantId AND pdt.doc_type = :docType " + CURRENT_RECORD)
	@RegisterBeanMapper(DocType.class)
	Optional<DocType> searchByDocType(
			@BindBean ReqContext ctx,
			@Bind("docType") String docType);

	@SqlBatch("insert into prt_doc_type (tenant_id, doc_type, doc_group, dt_insert, user_id_insert, dt_delete, user_id_delete) "
			+ "§select_from_dual(:tenantId, :docType, :docGroup, :dtInsert, :userIdInsert, :dtDelete, :userIdDelete)§"
			+ " where not exists ("
			+ "		select doc_type from prt_doc_type "
			+ "		where tenant_id = :tenantId "
			+ "		and doc_type = :docType "
			+ "		AND (§current_timestamp§ between dt_insert and dt_delete) )")
	void insertIdempotent(@BindBean DocTypeEntity... entity);

	@SqlUpdate("update prt_doc_type set dt_delete= :dtDelete, user_id_delete= :userIdDelete WHERE id= :id")
	void expireRow(@BindBean DocTypeEntity entity);

	@SqlUpdate("UPDATE prt_doc_type SET dt_delete = :dtDelete, user_id_delete = :userIdDelete "
			+ " WHERE doc_type in (<doc_types>) "
			+ " and tenant_id = :tenantId "
			+ " AND (§current_timestamp§ between dt_insert and dt_delete)")
	void expireRowsByCode(
			@BindBean AuditEntity audit,
			@Bind("tenantId") String tenantId,
			@BindList("doc_types") Set<String> docTypes);

	@SqlQuery("select " + FIELDS + " from prt_doc_type pdt " +
			" where pdt.tenant_id = :tenantId  " + CURRENT_RECORD)
	@RegisterBeanMapper(DocTypeEntity.class)
	List<DocTypeEntity> findAll(@Bind("tenantId") String tenantId);

	@SqlUpdate("INSERT INTO prt_doc_type (tenant_id, doc_type, doc_group, dt_insert, user_id_insert, dt_delete, user_id_delete ) " +
			" select :newTenantId as tenant_id, doc_type, doc_group, :dtInsert, :userIdInsert, :dtDelete, :userIdDelete " +
			" FROM prt_doc_type pdt where pdt.tenant_id = :sourceTenant " + CURRENT_RECORD)
	void insertNewTenant(
			@Bind("sourceTenant") String sourceTenant,
			@Bind("newTenantId") String newTenantId,
			@BindBean AuditEntity audit);

	@SqlBatch("insert into prt_doc_type_relations (doc_type_id, party_type, dt_insert, user_id_insert, dt_delete, user_id_delete) "
			+ "select  t.id, :partyType "
			+ "     , :dtInsert,  :userIdInsert,  :dtDelete,  :userIdDelete "
			+ "from prt_doc_type t "
			+ "where "
			+ "    t.tenant_id = :tenantId "
			+ "    and t.doc_type = :docType "
			+ " AND (§current_timestamp§ between t.dt_insert and t.dt_delete) "

			+ "    and NOT EXISTS("
			+ "        SELECT pkid from prt_doc_type_relations "
			+ "        where doc_type_id = t.id "
			+ "        and party_type = :partyType "
			+ "        and §current_timestamp§ between dt_insert and dt_delete ) "
	)
	void insertRelationsIdempotent(
			@BindBean DocTypeRelationEntity audit,
			@Bind("tenantId") String tenantId,
			@Bind("docType") String docType,
			@Bind("partyType") String... partyType);

	@SqlBatch("insert into prt_doc_type_tags (doc_type_id, tag_id, dt_insert, user_id_insert, dt_delete, user_id_delete) "
			+ "select  t.id, :tagId "
			+ "     , :dtInsert,  :userIdInsert,  :dtDelete,  :userIdDelete "
			+ "from prt_doc_type t "
			+ "where "
			+ "    t.tenant_id = :tenantId "
			+ "    and t.doc_type = :docType "
			+ " AND (§current_timestamp§ between t.dt_insert and t.dt_delete) "

			+ "    and NOT EXISTS("
			+ "        SELECT pkid from prt_doc_type_tags "
			+ "        where doc_type_id = t.id "
			+ "        and tag_id = :tagId "
			+ "        and §current_timestamp§ between dt_insert and dt_delete ) "
	)
	void insertTagRelationsIdempotent(
			@Bind("tenantId") String tenantId,
			@BindBean DocTypeTagRelationEntity... entities);

	@SqlUpdate("UPDATE prt_doc_type_relations SET dt_delete = :dtDelete, user_id_delete = :userIdDelete "
			+ " WHERE doc_type_id in (select id from prt_doc_type where doc_type in (<doc_types>) and tenant_id = :tenantId) "
			+ " AND (§current_timestamp§ between dt_insert and dt_delete)")
	void expireTypeRelationsByCode(
			@BindBean AuditEntity audit,
			@Bind("tenantId") String tenantId,
			@BindList("doc_types") Set<String> docTypes);

	@SqlUpdate("UPDATE prt_doc_type_tags SET dt_delete = :dtDelete, user_id_delete = :userIdDelete "
			+ " WHERE doc_type_id in (select id from prt_doc_type where doc_type in (<doc_types>) and tenant_id = :tenantId) "
			+ " AND (§current_timestamp§ between dt_insert and dt_delete)")
	void expireTagRelationsByCode(
			@BindBean AuditEntity audit,
			@Bind("tenantId") String tenantId,
			@BindList("doc_types") Set<String> docTypes);

	@SqlUpdate("insert into prt_doc_type_relations (doc_type_id, party_type, dt_insert, user_id_insert, dt_delete, user_id_delete)\n"
			+ "select dest_dt.id as dest_doc_type_id, rel.party_type as dest_type_id, "
			+ "       :dtInsert, :userIdInsert, :dtDelete, :userIdDelete "
			+ "from prt_doc_type_relations rel "

			+ "inner join prt_doc_type src_dt on src_dt.id = rel.doc_type_id "
			+ "inner join prt_doc_type dest_dt on dest_dt.doc_type = src_dt.doc_type and dest_dt.tenant_id = :newTenantId "

			+ "where src_dt.tenant_id =  :sourceTenant "
			+ "and (§current_timestamp§ between rel.dt_insert and rel.dt_delete) "
			+ "and (§current_timestamp§ between src_dt.dt_insert and src_dt.dt_delete) "

			+ "    and NOT EXISTS("
			+ "        SELECT pkid from prt_doc_type_relations "
			+ "        where doc_type_id = dest_dt.id "
			+ "        and party_type = rel.party_type "
			+ "        and §current_timestamp§ between dt_insert and dt_delete ) "
	)
	void insertRelationsNewTenant(
			@Bind("sourceTenant") String sourceTenant,
			@Bind("newTenantId") String newTenantId,
			@BindBean AuditEntity audit);

	@SqlUpdate("insert into prt_doc_type_tags (doc_type_id, tag_id, dt_insert, user_id_insert, dt_delete, user_id_delete)\n"
			+ "select dest_dt.id as dest_doc_type_id, dest_t.id as dest_tag_id, "
			+ "       :dtInsert, :userIdInsert, :dtDelete, :userIdDelete "
			+ "from prt_doc_type_tags rel "

			+ "inner join prt_doc_type src_dt on src_dt.id = rel.doc_type_id "
			+ "inner join prt_doc_type dest_dt on dest_dt.doc_type = src_dt.doc_type and dest_dt.tenant_id = :newTenantId "

			+ "inner join prt_tags src_t on src_t.id = rel.tag_id and src_t.tenant_id = :sourceTenant "
			+ "inner join prt_tags dest_t on dest_t.tag_code = src_t.tag_code and dest_t.tenant_id = :newTenantId "

			+ "where src_dt.tenant_id =  :sourceTenant "
			+ "and (§current_timestamp§ between rel.dt_insert and rel.dt_delete) "
			+ "and (§current_timestamp§ between src_dt.dt_insert and src_dt.dt_delete) "

			+ "    and NOT EXISTS("
			+ "        SELECT pkid from prt_doc_type_tags "
			+ "        where doc_type_id = dest_dt.id "
			+ "        and tag_id = dest_t.id "
			+ "        and §current_timestamp§ between dt_insert and dt_delete ) "
	)
	void insertTagRelationsNewTenant(
			@Bind("sourceTenant") String sourceTenant,
			@Bind("newTenantId") String newTenantId,
			@BindBean AuditEntity audit);
}
