package com.abacogroup.partyregistry.resources;

import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.partyregistry.api.PartyRelationParty;
import com.abacogroup.partyregistry.core.AclService;
import com.abacogroup.partyregistry.core.PartyRelationPartyService;
import com.abacogroup.partyregistry.core.exceptions.InvalidPartyException;
import com.abacogroup.partyregistry.core.exceptions.InvalidPartyRelationException;
import com.abacogroup.partyregistry.resources.req.PartyRelationPartySearchReq;
import com.abacogroup.partyregistry.resources.req.ReqContext;
import com.abacogroup.partyregistry.resources.req.rel.PartyRelationItemReq;

import io.dropwizard.auth.Auth;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.annotation.security.RolesAllowed;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.DefaultValue;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.HeaderParam;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.MediaType;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Path(ResourceConstants.API_PRIV + "/parties/{partyId}/relation-types/{relationId}/relations")
@Produces(MediaType.APPLICATION_JSON)
@Tag(name = "party relations", description = "Operations on party relation items")
public class PartyRelationPartiesResource {

	private static final boolean SKIP_ACL_IF_CAN_IGNORE = true;
	
	private final AclService aclService;
	private final PartyRelationPartyService partyRelationPartyService;

	public PartyRelationPartiesResource(AclService aclService, PartyRelationPartyService partyRelationPartyService) {
		this.aclService = aclService;
		this.partyRelationPartyService = partyRelationPartyService;
	}

	@GET
	@RolesAllowed("PARTY-REGISTRY|READ")
	@Operation(summary = "List of party's relations", description = "Get the list of party's relations for a given relation type")
	@ApiResponses({
			@ApiResponse(responseCode = "200", description = "Successfully, returns a list of party's relations for a given relation type (sorted/filtered)",
					content = @Content(mediaType = "application/json",
							schema = @Schema(ref = "#/components/schemas/InfiniteListResultsPartyRelationParty")))
	})
	public InfiniteListResults<PartyRelationParty> search(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "the tenant ID") @PathParam("tenant") String tenantId,

			@Parameter(description = "the party ID") @PathParam("partyId") Long partyId,
			@Parameter(description = "the relation ID") @PathParam("relationId") Long relationId,
			@Parameter(description = "Can be supplied to obtain the records that follows those obtained by a previous call")
			@QueryParam("nextKey") String nextKey) {
		//      @BeanParam PartyRelationPartySearchReq searchReq) {

		ReqContext reqContext = new ReqContext(user, lang);
		aclService.canRead(reqContext, partyId, SKIP_ACL_IF_CAN_IGNORE);
		return this.partyRelationPartyService.search(reqContext, partyId, relationId, new PartyRelationPartySearchReq(),
				nextKey);
	}

	@GET
	@RolesAllowed("PARTY-REGISTRY|READ")
	@Operation(summary = "Find relation of party by item ID", description = "Returns relation party info based on item ID")
	@ApiResponses({
			@ApiResponse(responseCode = "200", description = "Successfully, relation party is found",
					content = @Content(mediaType = "application/json", schema = @Schema(implementation = PartyRelationParty.class))),
	})
	@Path("/{pkid}")
	public PartyRelationParty getById(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "the tenant ID") @PathParam("tenant") String tenantId,

			@Parameter(description = "the party ID") @PathParam("partyId") Long partyId,
			@Parameter(description = "the relation type of the party ID") @PathParam("relationId") Long relationId,
			@Parameter(description = "the relation item ID") @PathParam("pkid") Long relationItemId) {

		ReqContext reqContext = new ReqContext(user, lang);
		aclService.canRead(reqContext, partyId, SKIP_ACL_IF_CAN_IGNORE);
		return this.partyRelationPartyService.getRelationPartyById(reqContext, partyId, relationId, relationItemId).orElse(null);
	}

	@Operation(summary = "Add new relation party item", description = "Insert a new relation party of a given relation type")
	@ApiResponses({
			@ApiResponse(responseCode = "200", description = "Successfully, the new relation party is created",
					content = @Content(mediaType = "application/json", schema = @Schema(implementation = PartyRelationParty.class))),
			@ApiResponse(responseCode = "400", description = "relation party creation error",
					content = @Content(mediaType = "application/json", schema = @Schema(anyOf = {
							InvalidPartyException.ErrorBody.class,
							InvalidPartyRelationException.ErrorBody.class
					})))
	})
	@POST
	@RolesAllowed("PARTY-REGISTRY|WRITE")
	public PartyRelationParty addRelationParty(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "the tenant ID") @PathParam("tenant") String tenantId,

			@Parameter(description = "the party ID") @PathParam("partyId") Long partyId,
			@Parameter(description = "the relation ID") @PathParam("relationId") Long relationId,
			@NotNull @Valid PartyRelationItemReq partyRelationItemReq) {

		ReqContext reqContext = new ReqContext(user, lang);
		aclService.canWrite(reqContext, partyId );
		return partyRelationPartyService.insert(reqContext, partyId, relationId, partyRelationItemReq);
	}

	@Operation(summary = "Update relation party", description = "Update an existing relation party item")
	@ApiResponses({
			@ApiResponse(responseCode = "200", description = "Successfully, the relation party is updated",
					content = @Content(mediaType = "application/json", schema = @Schema(implementation = PartyRelationParty.class))),
			@ApiResponse(responseCode = "400", description = "relation party update error",
					content = @Content(mediaType = "application/json", schema = @Schema(anyOf = {
							InvalidPartyException.ErrorBody.class,
							InvalidPartyRelationException.ErrorBody.class
					})))
	})
	@PUT
	@RolesAllowed("PARTY-REGISTRY|WRITE")
	@Path("/{pkid}")
	public PartyRelationParty updateRelationParty(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "the tenant ID") @PathParam("tenant") String tenantId,

			@Parameter(description = "the party ID") @PathParam("partyId") Long partyId,
			@Parameter(description = "the relation type of the party ID") @PathParam("relationId") Long relationId,
			@Parameter(description = "the relation item ID") @PathParam("pkid") Long relationItemId,
			@NotNull @Valid PartyRelationItemReq partyRelationItemReq) {

		ReqContext reqContext = new ReqContext(user, lang);
		aclService.canWrite(reqContext, partyId);
		return partyRelationPartyService.update(reqContext, partyId, relationId, relationItemId, partyRelationItemReq);
	}

	@Operation(summary = "delete relation party", description = "delete a relation from a party by setting it as expired")
	@ApiResponses({
			@ApiResponse(responseCode = "200", description = "relation party deleted (Expired)"),
			@ApiResponse(responseCode = "404", description = "relation party not found",
					content = @Content(schema = @Schema(implementation = InvalidPartyRelationException.ErrorBody.class)))
	})
	@DELETE
	@RolesAllowed("PARTY-REGISTRY|DELETE")
	@Path("/{pkid}")
	public void expireRelationParty(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "the tenant ID") @PathParam("tenant") String tenantId,

			@Parameter(description = "the party ID") @PathParam("partyId") Long partyId,
			@Parameter(description = "the relation type of the party ID") @PathParam("relationId") Long relationId,
			@Parameter(description = "the relation item ID") @PathParam("pkid") Long relationItemId) {

		ReqContext reqContext = new ReqContext(user, lang);
		aclService.canWrite(reqContext, partyId);
		this.partyRelationPartyService.expireRelationParty(reqContext, partyId, relationId, relationItemId);
	}

}

