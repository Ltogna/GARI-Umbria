package com.abacogroup.partyregistry.api;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;
import org.jdbi.v3.core.mapper.Nested;
import org.jdbi.v3.core.mapper.reflect.ColumnName;

@Data
@NoArgsConstructor
@SuperBuilder(setterPrefix = "set")
public class RelationRole {

	private String code;

	@ColumnName("i18n_code")
	private String i18nCode;

	@Nested("relation_type")
	private RelationType relationType;

}
