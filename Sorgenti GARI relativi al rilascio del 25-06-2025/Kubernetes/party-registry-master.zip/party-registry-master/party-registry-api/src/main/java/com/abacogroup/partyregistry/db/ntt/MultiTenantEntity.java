package com.abacogroup.partyregistry.db.ntt;

public interface MultiTenantEntity<T> {

	T getTenantId();
}
