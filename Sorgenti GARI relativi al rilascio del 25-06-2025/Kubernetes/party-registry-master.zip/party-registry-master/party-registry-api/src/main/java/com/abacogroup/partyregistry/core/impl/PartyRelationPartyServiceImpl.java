package com.abacogroup.partyregistry.core.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.function.Consumer;
import java.util.function.Function;

import com.abacogroup.jdbi.criteria.Criteria;
import com.abacogroup.jdbi.orderby.OrderBy;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.partyregistry.api.PartyRelationParty;
import com.abacogroup.partyregistry.core.AclService;
import com.abacogroup.partyregistry.core.PartyEventProducer;
import com.abacogroup.partyregistry.core.PartyRelationPartyService;
import com.abacogroup.partyregistry.core.PartyRelationService;
import com.abacogroup.partyregistry.core.PartyService;
import com.abacogroup.partyregistry.core.RelationRoleService;
import com.abacogroup.partyregistry.core.dto.PartyEventType;
import com.abacogroup.partyregistry.core.exceptions.ErrCodes;
import com.abacogroup.partyregistry.core.exceptions.InvalidPartyException;
import com.abacogroup.partyregistry.core.exceptions.InvalidPartyRelationException;
import com.abacogroup.partyregistry.db.dao.PartyRelationPartyDAO;
import com.abacogroup.partyregistry.db.ntt.PartyRelationEntity;
import com.abacogroup.partyregistry.db.ntt.PartyRelationPartyEntity;
import com.abacogroup.partyregistry.db.ntt.RelationRoleEntity;
import com.abacogroup.partyregistry.resources.mappers.PartyRelationPartyMapper;
import com.abacogroup.partyregistry.resources.req.PartyRelationPartySearchReq;
import com.abacogroup.partyregistry.resources.req.ReqContext;
import com.abacogroup.partyregistry.resources.req.rel.PartyRelationItemReq;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class PartyRelationPartyServiceImpl implements PartyRelationPartyService {

	private final PartyRelationService partyRelationService;
	private final PartyRelationPartyMapper partyRelationPartyMapper;
	private final PartyRelationPartyDAO partyRelationPartyDAO;
	private final PartyService partyService;
	private final RelationRoleService relationRoleService;
	private final AclService aclService;

	private final PartyEventProducer partyEventProducer;

	public PartyRelationPartyServiceImpl(PartyRelationService partyRelationService,
			PartyRelationPartyMapper partyRelationPartyMapper, PartyRelationPartyDAO partyRelationPartyDAO,
			PartyService partyService, RelationRoleService relationRoleService, PartyEventProducer partyEventProducer,
			AclService aclService) {
		this.partyRelationService = partyRelationService;
		this.partyRelationPartyMapper = partyRelationPartyMapper;
		this.partyRelationPartyDAO = partyRelationPartyDAO;
		this.partyService = partyService;
		this.relationRoleService = relationRoleService;
		this.partyEventProducer = partyEventProducer;
		this.aclService = aclService;
	}

	@Override
	public InfiniteListResults<PartyRelationParty> search(ReqContext reqContext, Long partyId, Long relationId,
			PartyRelationPartySearchReq searchReq, String nextKey) {
		Criteria criteria = searchReq.getCriteria(reqContext);
		OrderBy sort = searchReq.getSort();

		return partyRelationPartyDAO.infinite(() ->
						partyRelationPartyDAO.searchAll(partyId, relationId, criteria, sort, reqContext),
				nextKey, searchReq.getPageSize())
				.map(rel -> {
					rel.setHasMandates(aclService.hasMandates(reqContext, rel.getRelatedPartyId()));
					return rel;
				});
	}

	@Override
	public PartyRelationParty insert(ReqContext context, Long partyId, Long relationId, PartyRelationItemReq req) {

		PartyRelationEntity relation = this.getRelation(context, partyId, relationId);

		RelationRoleEntity relationRoleEntity = this.getRole(context, relation.getRelationTypeId(), req.getRelatedRoleCode());

		this.validateItem(context, relationId, relationRoleEntity, req);
		Long pkid = partyRelationPartyDAO.inTransaction(handle -> {

			long newpk = this.doInsert(context, relation, relationRoleEntity, req);

			partyEventProducer.pushPartyEvent(context, partyId, PartyEventType.UPDATE_PARTY);
			return newpk;
		});

		return this.getRelationPartyById(context, partyId, relationId, pkid).orElse(null);
	}

	@Override
	public void insertAll(ReqContext context, Long partyId, Long relationId, List<PartyRelationItemReq> reqs, boolean sendEvent) {

		PartyRelationEntity relation = this.getRelation(context, partyId, relationId);

		Map<String, RelationRoleEntity> roleCache = new HashMap<>();

		partyRelationPartyDAO.useTransaction(handle -> {
			for (PartyRelationItemReq req : reqs) {
				RelationRoleEntity relationRoleEntity = roleCache.computeIfAbsent(req.getRelatedRoleCode(),
						roleCode -> this.getRole(context, relation.getRelationTypeId(), req.getRelatedRoleCode()));

				this.validateItem(context, relationId, relationRoleEntity, req);
				this.doInsert(context, relation, relationRoleEntity, req);
			}
			if (sendEvent && !reqs.isEmpty()) {
				partyEventProducer.pushPartyEvent(context, partyId, PartyEventType.UPDATE_PARTY);
			}
		});
	}

	@Override
	public PartyRelationParty update(ReqContext context, Long partyId, Long relationId, Long pkid, PartyRelationItemReq req) {

		PartyRelationEntity relation = this.getRelation(context, partyId, relationId);

		RelationRoleEntity relationRoleEntity = this.getRole(context, relation.getRelationTypeId(), req.getRelatedRoleCode());

		partyRelationPartyDAO.find(context, relationId, req.getRelatedPartyId(), relationRoleEntity.getId())
				.filter(r -> !r.getPkid().equals(pkid))
				.ifPresent(r -> {
					throw new InvalidPartyRelationException(ErrCodes.RELATION_PARTY_ALREADY_DEFINED, "relation present");
				});

		PartyRelationPartyEntity entity = partyRelationPartyMapper.convertForUpdate(context.getTenantId(), relation, relationRoleEntity, pkid, req);
		partyRelationPartyDAO.useTransaction(handle -> {
			Consumer<PartyRelationPartyEntity> expire = handle::expirePartyRelationParty;
			Function<PartyRelationPartyEntity, Long> insert = handle::insertPartyRelParty;
			long currentPkId = AuditHelper.update(entity, context.getUsername(), expire, insert, handle.getCurrentTimestamp());
			entity.setPkid(currentPkId);

			partyEventProducer.pushPartyEvent(context, partyId, PartyEventType.UPDATE_PARTY);
		});

		return this.getRelationPartyById(context, partyId, relationId, entity.getPkid()).orElse(null);
	}

	@Override
	public void expireRelationParty(ReqContext context, Long partyId, Long relationId, Long pkId) {
		partyRelationPartyDAO.findById(context.getTenantId(), partyId, relationId, pkId)
				.ifPresent(partyRelationParty -> {
					partyRelationPartyDAO.useTransaction(handle -> {
						Consumer<PartyRelationPartyEntity> expireFun = handle::expirePartyRelationParty;
						AuditHelper.expire(partyRelationParty, context.getUsername(), expireFun, handle.getCurrentTimestamp());

						partyEventProducer.pushPartyEvent(context, partyId, PartyEventType.UPDATE_PARTY);
					});
				});
	}

	@Override
	public Optional<PartyRelationParty> getRelationPartyById(ReqContext reqContext, Long partyId, Long relationId, Long pkId) {
		return partyRelationPartyDAO.getById(partyId, relationId, pkId, reqContext)
				.map(rel -> {
					rel.setHasMandates(aclService.hasMandates(reqContext, rel.getRelatedPartyId()));
					return rel;
				});
	}

	private long doInsert(ReqContext context, PartyRelationEntity relation, RelationRoleEntity relationRoleEntity, PartyRelationItemReq req) {
		PartyRelationPartyEntity partyRelationPartyEntity = partyRelationPartyMapper
				.convert(context.getTenantId(), relation, relationRoleEntity, req);

		AuditHelper.setAuditForInsert(partyRelationPartyEntity, context.getUsername(), partyRelationPartyDAO);
		return partyRelationPartyDAO.insertPartyRelParty(partyRelationPartyEntity);
	}

	private void validateItem(ReqContext context, Long relationId, RelationRoleEntity relationRoleEntity, PartyRelationItemReq req) {
		partyRelationPartyDAO.find(context, relationId, req.getRelatedPartyId(), relationRoleEntity.getId())
				.ifPresent(r -> {
					throw new InvalidPartyRelationException(ErrCodes.RELATION_PARTY_ALREADY_DEFINED, "relation present");
				});

		partyService.loadEntity(context.getTenantId(), req.getRelatedPartyId()).orElseThrow(
				() -> new InvalidPartyException(ErrCodes.PARTY_NOT_FOUND, "the party target not found")
		);
	}

	private PartyRelationEntity getRelation(ReqContext context, Long partyId, Long relationId) {
		return partyRelationService.findById(context.getTenantId(), partyId, relationId)
				.orElseThrow(() -> new InvalidPartyRelationException(ErrCodes.RELATION_NOT_FOUND, "relation not found"));
	}

	private RelationRoleEntity getRole(ReqContext context, Long relationTypeId, String relatedRoleCode) {
		return relationRoleService.loadEntityActiveByCode(context.getTenantId(), relationTypeId, relatedRoleCode)
				.orElseThrow(() -> new InvalidPartyRelationException(ErrCodes.RELATION_ROLE_NOT_FOUND, "role not found "));
	}

}
