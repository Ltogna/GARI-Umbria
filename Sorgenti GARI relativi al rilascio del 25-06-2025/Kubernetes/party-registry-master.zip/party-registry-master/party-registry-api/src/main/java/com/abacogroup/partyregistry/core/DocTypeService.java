package com.abacogroup.partyregistry.core;

import com.abacogroup.partyregistry.api.DocType;
import com.abacogroup.partyregistry.api.PartyTypeEnum;
import com.abacogroup.partyregistry.resources.req.DocTypeSearchReq;
import com.abacogroup.partyregistry.resources.req.ReqContext;
import java.util.List;
import java.util.Optional;

public interface DocTypeService {

	List<DocType> search(ReqContext reqContext, DocTypeSearchReq searchRequest, List<Long> tags, PartyTypeEnum... partyTypeEnum);

	List<DocType> search(ReqContext reqContext, Long partyId, DocTypeSearchReq searchRequest);

	Optional<DocType> getByDocType(ReqContext reqContext, String docType);

}
