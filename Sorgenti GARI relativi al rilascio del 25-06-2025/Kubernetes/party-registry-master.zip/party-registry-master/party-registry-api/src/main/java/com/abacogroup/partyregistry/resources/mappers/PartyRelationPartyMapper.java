package com.abacogroup.partyregistry.resources.mappers;

import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.jdbi.model.AuditEntity;
import com.abacogroup.partyregistry.core.RelationRoleService;
import com.abacogroup.partyregistry.core.exceptions.ErrCodes;
import com.abacogroup.partyregistry.core.exceptions.InvalidRelationPartyException;
import com.abacogroup.partyregistry.core.exceptions.InvalidRelationRoleException;
import com.abacogroup.partyregistry.db.dao.PartyRelationPartyDAO;
import com.abacogroup.partyregistry.db.ntt.PartyRelationEntity;
import com.abacogroup.partyregistry.db.ntt.PartyRelationPartyEntity;
import com.abacogroup.partyregistry.db.ntt.RelationRoleEntity;
import com.abacogroup.partyregistry.resources.req.rel.PartyRelationItemReq;
import java.util.Optional;

public class PartyRelationPartyMapper {

	private final RelationRoleService relationRoleService;
	private final PartyRelationPartyDAO partyRelationPartyDAO;

	public PartyRelationPartyMapper(RelationRoleService relationRoleService, PartyRelationPartyDAO partyRelationPartyDAO) {
		this.relationRoleService = relationRoleService;
		this.partyRelationPartyDAO = partyRelationPartyDAO;
	}

	public PartyRelationPartyEntity convert(String tenantId, PartyRelationEntity relation, RelationRoleEntity relationRoleEntity,
			PartyRelationItemReq req) {
		PartyRelationPartyEntity partyRelationPartyEntity =
				PartyRelationPartyEntity.builder()
						.setPartyRelationId(relation.getId())
						.setPartyId(req.getRelatedPartyId())
						.setRelationRoleId(relationRoleEntity.getId())
						.setDtStart(req.getDtStart())
						.setDtEnd(Optional.ofNullable(req.getDtEnd()).orElse(AbsoluteDate.of(AuditEntity.dateActive)))
						.build();
		return partyRelationPartyEntity;
	}

	public PartyRelationPartyEntity createPartyRelationPartyEntity(String tenantId, Long typeId, PartyRelationItemReq req) {
		return PartyRelationPartyEntity.builder()
				//.setPartyRelationId(Optional.ofNullable(relation).map(PartyRelationType::getId).orElse(null))
				.setPartyId(req.getRelatedPartyId())
				.setRelationRoleId(getRelationRoleEntity(tenantId, req.getRelatedRoleCode())
						.filter(role -> role.getTypeId().equals(typeId))
						.map(RelationRoleEntity::getId)
						.orElseThrow(() -> new InvalidRelationRoleException(ErrCodes.RELATION_ROLE_NOT_FOUND, "role not found")))
				.setDtStart(req.getDtStart())
				.setDtEnd(Optional.ofNullable(req.getDtEnd()).orElse(AbsoluteDate.of(AuditEntity.dateActive)))
				.build();
	}

	public PartyRelationPartyEntity convertForUpdate(String tenantId, PartyRelationEntity relation, RelationRoleEntity relationRoleEntity, Long itemPkId,
			PartyRelationItemReq req) {

		//validate
		PartyRelationPartyEntity partyRelationParty = this.getRelationPartyById(tenantId,
						relation.getPartyId(), relation.getId(), itemPkId)
				.filter(dto -> dto.getPartyRelationId().equals(relation.getId()))
				///////////.filter(dto -> dto.getPartyRelationPartyId().equals(relation.getPartyId()))
				.orElseThrow(() -> new InvalidRelationPartyException(ErrCodes.RELATION_PARTY_NOT_FOUND, "no item found"));

		return PartyRelationPartyEntity.builder()
				.setPkid(itemPkId)
				.setPartyRelationId(relation.getId())

				.setPartyId(req.getRelatedPartyId())
				.setRelationRoleId(relationRoleEntity.getId())
				.setDtStart(req.getDtStart())
				.setDtEnd(Optional.ofNullable(req.getDtEnd()).orElse(AbsoluteDate.of(AuditEntity.dateActive)))
				.build();

	}

	private Optional<RelationRoleEntity> getRelationRoleEntity(String tenantId, String roleCode) {
		return relationRoleService.loadEntityActiveByCode(tenantId, roleCode);
	}

	public Optional<PartyRelationPartyEntity> getRelationPartyById(String tenantId, Long partyId, Long relationId, Long pkId) {
		return partyRelationPartyDAO.findById(tenantId, partyId, relationId, pkId);
	}
}
