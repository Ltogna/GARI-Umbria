package com.abacogroup.partyregistry.resources.req;

import com.fasterxml.jackson.annotation.JsonIgnore;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.ws.rs.QueryParam;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;
import org.apache.commons.lang3.StringUtils;

@Data
@NoArgsConstructor
@Accessors(chain = true)
public class PartyCheckReq {

	@Parameter(in = ParameterIn.QUERY, description = "party ID")
	@QueryParam("id")
	private Long id;

	@Parameter(in = ParameterIn.QUERY, description = "VAT number of the party")
	@QueryParam("vatNumber")
	private String vatNumber;

	@Parameter(in = ParameterIn.QUERY, description = "TAX code of the party")
	@QueryParam("taxCode")
	private String taxCode;

	@JsonIgnore
	@Schema(hidden = true)
	public boolean isValid() {
		boolean isEmpty = StringUtils.isBlank(this.getTaxCode())
				&& StringUtils.isBlank(this.getVatNumber());
		return !isEmpty;
	}
}
