package com.abacogroup.partyregistry.resources.req;

import com.abacogroup.jdbi.criteria.Criteria;
import com.abacogroup.jdbi.criteria.CriteriaBuilder;
import com.abacogroup.jdbi.orderby.OrderByBuilder;
import com.abacogroup.jdbi.orderby.OrderByElement;
import com.abacogroup.jdbi.orderby.SortDirection;
import com.abacogroup.partyregistry.resources.ResourceConstants;
import com.fasterxml.jackson.annotation.JsonIgnore;
import io.swagger.v3.oas.annotations.media.Schema;
import java.util.ArrayList;
import java.util.List;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

@Data
@NoArgsConstructor
//@RequiredArgsConstructor
@Accessors(chain = true)
public class PartyRelationPartySearchReq implements BaseSearchReq {

	@Override
	@JsonIgnore
	@Schema(hidden = true)
	public int getPageSize() {
		return ResourceConstants.PAGE_SIZE;
	}

	@Override
	@JsonIgnore
	@Schema(hidden = true)
	public Criteria getCriteria(ReqContext ctx) {
		List<Criteria> specs = new ArrayList<>();

		return CriteriaBuilder.and(specs.toArray(new Criteria[0]));
	}

	@Override
	@JsonIgnore
	@Schema(hidden = true)
	public OrderByElement getSort() {
		return OrderByBuilder
				.field("relation_role_i18n_code")
				.direction(SortDirection.ASC);
	}
}
