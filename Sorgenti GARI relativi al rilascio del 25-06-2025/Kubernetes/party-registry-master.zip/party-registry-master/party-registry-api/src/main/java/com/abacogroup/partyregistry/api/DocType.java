package com.abacogroup.partyregistry.api;

import com.abacogroup.dynamicdocuments.bean.SummaryFieldDefinition;
import jakarta.validation.constraints.NotNull;
import java.util.List;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder(setterPrefix = "set")
@NoArgsConstructor
public class DocType {

	@NotNull
	private String docType;

	private String i18nDocType;

	private String docGroup;

	private String i18nDocGroup;

	private boolean multiple;

	private List<SummaryFieldDefinition> summaryFieldDefinitions;
}
