package com.abacogroup.partyregistry.bundle.config;

import com.abacogroup.bundles.initializer.impl.exceptions.BundleException;
import com.abacogroup.partyregistry.bundle.config.AppConfigMessageProcessor.AppConfigMixin;
import com.abacogroup.partyregistry.core.impl.validaor.PartyCodeConfiguration;
import com.abacogroup.partyregistry.core.impl.validaor.PartyCodeRegexValidatorImpl;
import com.abacogroup.partyregistry.core.impl.validaor.PartyCodeValidatorImpl;
import com.abacogroup.partyregistry.core.impl.validaor.PartyTaxCodeRegexValidatorImpl;
import com.abacogroup.partyregistry.core.impl.validaor.PartyTypeConfiguration;
import com.abacogroup.partyregistry.core.impl.validaor.PartyTypeValidatorImpl;
import com.abacogroup.partyregistry.core.impl.validaor.PartyVatNumberRegexValidatorImpl;
import com.abacogroup.partyregistry.core.impl.validaor.RegexCodeConfiguration;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.IOException;

public class AppConfigFormatValidator {

	private final ObjectMapper mapper;

	public AppConfigFormatValidator(ObjectMapper mapper) {
		this.mapper = mapper;
	}

	public void validate(AppConfigMixin x) {
		try {
			switch (x.getConfigurationKey()) {
			case PartyCodeValidatorImpl.CONFIG_KEY:
				mapper.readerFor(PartyCodeConfiguration.class).readValue(x.getConfiguration());
				break;
			case PartyTypeValidatorImpl.CONFIG_KEY:
				mapper.readerFor(PartyTypeConfiguration.class).readValue(x.getConfiguration());
				break;
			case PartyTaxCodeRegexValidatorImpl.CONFIG_KEY:
			case PartyVatNumberRegexValidatorImpl.CONFIG_KEY:
			case PartyCodeRegexValidatorImpl.CONFIG_KEY:
				mapper.readerFor(RegexCodeConfiguration.class).readValue(x.getConfiguration());
				break;
			}
		} catch (IOException ioe) {
			throw new BundleException(String.format("configuration format not valid for key '%s': %s", x.getConfigurationKey(), ioe.getMessage()), ioe);
		}
	}

}
