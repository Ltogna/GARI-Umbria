package com.abacogroup.partyregistry.resources;

import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.partyregistry.api.DocType;
import com.abacogroup.partyregistry.core.AclService;
import com.abacogroup.partyregistry.core.DocTypeService;
import com.abacogroup.partyregistry.resources.req.DocTypeSearchReq;
import com.abacogroup.partyregistry.resources.req.ReqContext;
import io.dropwizard.auth.Auth;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.annotation.security.RolesAllowed;
import jakarta.ws.rs.BeanParam;
import jakarta.ws.rs.DefaultValue;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.HeaderParam;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import java.util.List;

@Path(ResourceConstants.API_PRIV + "/doc-types/{partyId}")
@Produces(MediaType.APPLICATION_JSON)
@Tag(name = "document types", description = "Operations on document types")
public class DocTypeResource {

	private static final boolean SKIP_ACL_IF_CAN_IGNORE = true;
	private final AclService aclService;
	private final DocTypeService docTypeService;

	public DocTypeResource(AclService aclService, DocTypeService docTypeService) {
		this.aclService = aclService;
		this.docTypeService = docTypeService;
	}

	@Operation(summary = "List of document types", description = "Get list of document types filtered with criteria")
	@ApiResponses({
			@ApiResponse(responseCode = "200", description = "Successfully, returns a list of document types (sorted/filtered)",
					content = @Content(mediaType = "application/json", array = @ArraySchema(schema = @Schema(implementation = DocType.class))))
	})
	@GET
	@RolesAllowed("PARTY-REGISTRY|READ")
	public List<DocType> search(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "tenant ID") @PathParam("tenant") String tenantId,
			@Parameter(description = "party ID") @PathParam("partyId") Long partyId,
			@BeanParam DocTypeSearchReq searchRequest) {

		ReqContext reqContext = new ReqContext(user, lang);
		aclService.canRead(reqContext, partyId, SKIP_ACL_IF_CAN_IGNORE);
		return docTypeService.search(reqContext, partyId, searchRequest);
	}
}
