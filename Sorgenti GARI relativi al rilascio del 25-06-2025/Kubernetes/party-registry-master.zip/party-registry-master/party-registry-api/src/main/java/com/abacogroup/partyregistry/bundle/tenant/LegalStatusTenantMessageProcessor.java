package com.abacogroup.partyregistry.bundle.tenant;

import static com.abacogroup.bundles.Constants.ALL_TENANTS;

import com.abacogroup.bundles.listener.tenant.TenantMessage;
import com.abacogroup.bundles.listener.tenant.TenantMessageProcessor;
import com.abacogroup.partyregistry.db.dao.LegalStatusDAO;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class LegalStatusTenantMessageProcessor implements TenantMessageProcessor {

    private final LegalStatusDAO legalStatusDAO;

    public LegalStatusTenantMessageProcessor(LegalStatusDAO legalStatusDAO) {
        this.legalStatusDAO = legalStatusDAO;
    }

    @Override
    public void onMessage(TenantMessage message) {
        String tenantId = message.getTenantId();
        if (legalStatusDAO.countAll(tenantId) > 0L) {
            log.warn("legal_status already present for tenant {}", tenantId);
        } else {
            legalStatusDAO.insertNewTenant(ALL_TENANTS, tenantId);
        }
    }

}
