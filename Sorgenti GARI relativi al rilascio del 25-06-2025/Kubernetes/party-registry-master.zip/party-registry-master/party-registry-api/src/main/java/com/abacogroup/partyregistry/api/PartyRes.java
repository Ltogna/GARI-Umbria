package com.abacogroup.partyregistry.api;

import com.abacogroup.jdbi.datatype.AbsoluteDate;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import java.util.List;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;
import org.jdbi.v3.core.mapper.reflect.ColumnName;

@Data
@NoArgsConstructor
@Accessors(chain = true)
public class PartyRes {

	private Long id;

	@NotNull
	private PartyTypeEnum partyType;

	private GenderEnum gender;
	@NotEmpty
	private String lastName;

	private String firstName;
	private String taxCode;
	private String vatNumber;
	private String code;
	private String legalStatus;
	private AbsoluteDate birthDate;
	private AbsoluteDate deathDate;

	private String birthMunicipality;
	private String nationality;

	private AddressRes addressResidential;
	private AddressRes addressHome;
	private AddressRes addressBilling;

	private List<Tag> tags;

	@ColumnName("fl_archived")
	private boolean archived = false;

	private ExternalSourceRes externalSource;
}
