package com.abacogroup.partyregistry.core;

import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.partyregistry.api.LegalStatus;
import com.abacogroup.partyregistry.db.ntt.LegalStatusEntity;
import com.abacogroup.partyregistry.resources.req.LegalStatusSearchReq;
import com.abacogroup.partyregistry.resources.req.ReqContext;
import java.util.Optional;

public interface LegalStatusService {

	InfiniteListResults<LegalStatus> search(ReqContext reqContext, LegalStatusSearchReq searchRequest, String nextKey);

	Optional<LegalStatus> getByCode(ReqContext reqContext, String code);

	Optional<LegalStatusEntity> findEntityByCode(String tenantId, String code);

}
