package com.abacogroup.partyregistry.resources.publicapis.mapper;

import com.abacogroup.partyregistry.api.RelationRole;
import com.abacogroup.partyregistry.api.v1.RelationRoleResponseV1;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper
public interface RelationRoleResMapper {

	RelationRoleResMapper INSTANCE = Mappers.getMapper(RelationRoleResMapper.class);

	RelationRoleResponseV1 toV1(RelationRole res);
}
