package com.abacogroup.partyregistry.core.impl.validaor;

import com.abacogroup.partyregistry.db.ntt.Address;
import org.apache.commons.lang3.StringUtils;

public class AddressValidator {

	public static Address validateAddress(Address address) {
		if (null == address) {
			return null;
		}
		if (!hasValue(address)) {
			return null;
		}
		return address;
	}

	private static boolean hasValue(Address address) {
		boolean hasMunicipality = null != StringUtils.trimToNull(address.getMunicipality());
		boolean hasLocality = null != StringUtils.trimToNull(address.getLocality());
		boolean hasStreet = null != StringUtils.trimToNull(address.getStreet());
		boolean hasHouseNumber = null != StringUtils.trimToNull(address.getHouseNumber());
		boolean hasPostcode = null != StringUtils.trimToNull(address.getPostcode());
		boolean hasDetails = null != StringUtils.trimToNull(address.getDetails());
		boolean hasNote = null != StringUtils.trimToNull(address.getNote());

		return hasMunicipality
				|| hasLocality
				|| hasStreet
				|| hasHouseNumber
				|| hasPostcode
				|| hasDetails
				|| hasNote;
	}
}
