package com.abacogroup.partyregistry.resources;

import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.partyregistry.api.RelationRole;
import com.abacogroup.partyregistry.core.RelationRoleService;
import com.abacogroup.partyregistry.resources.req.RelationRoleSearchReq;
import com.abacogroup.partyregistry.resources.req.ReqContext;
import io.dropwizard.auth.Auth;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.annotation.security.RolesAllowed;
import jakarta.ws.rs.BeanParam;
import jakarta.ws.rs.DefaultValue;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.HeaderParam;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.MediaType;

@Path(ResourceConstants.API_PRIV + "/relation-types/{relationTypeCode}/roles")
@Produces(MediaType.APPLICATION_JSON)
@Tag(name = "relation roles", description = "Operations on relation roles")
public class RelationRoleResource {

	private final RelationRoleService relationRoleService;

	public RelationRoleResource(RelationRoleService relationRoleService) {
		this.relationRoleService = relationRoleService;
	}

	@Operation(summary = "List of relation roles", description = "Get list of relation roles filtered with criteria")
	@ApiResponses({
			@ApiResponse(responseCode = "200", description = "Successfully, returns a list of relation roles (sorted/filtered)",
					content = @Content(mediaType = "application/json", schema = @Schema(ref = "#/components/schemas/InfiniteListResultsRelationRole")))
	})
	@GET
	@RolesAllowed("PARTY-REGISTRY|READ")
	public InfiniteListResults<RelationRole> search(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@PathParam("tenant") String tenantId,
			@Parameter(description = "Can be supplied to obtain the records that follows those obtained by a previous call") @QueryParam("nextKey") String nextKey,
			@BeanParam RelationRoleSearchReq searchRequest) {

		ReqContext reqContext = new ReqContext(user, lang);
		return relationRoleService.search(reqContext, searchRequest, nextKey);
	}

	@Operation(summary = "Find relation role by code", description = "Returns relation role based on its Code")
	@ApiResponses({
			@ApiResponse(responseCode = "200", description = "Successfully, relation role is found",
					content = @Content(mediaType = "application/json", schema = @Schema(implementation = RelationRole.class)))
	})
	@GET
	@RolesAllowed("PARTY-REGISTRY|READ")
	@Path("/{code}")
	public RelationRole getByCode(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "the tenant ID") @PathParam("tenant") String tenantId,

			@Parameter(description = "the relation type CODE") @PathParam("relationTypeCode") String relationTypeCode,
			@PathParam("code") String code) {
		ReqContext reqContext = new ReqContext(user, lang);
		return this.relationRoleService.getByCodeAndType(reqContext, relationTypeCode, code)
				.orElse(null);
	}



}

