package com.abacogroup.partyregistry.resources.publicapis.mapper;

import com.abacogroup.partyregistry.api.RelationType;
import com.abacogroup.partyregistry.api.v1.RelationTypeResponseV1;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper
public interface RelationTypeResMapper {

	RelationTypeResMapper INSTANCE = Mappers.getMapper(RelationTypeResMapper.class);

	RelationTypeResponseV1 toV1(RelationType res);
}
