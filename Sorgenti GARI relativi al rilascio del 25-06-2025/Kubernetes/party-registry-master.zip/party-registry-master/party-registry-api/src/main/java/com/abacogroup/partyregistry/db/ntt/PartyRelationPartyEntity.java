package com.abacogroup.partyregistry.db.ntt;

import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.jdbi.model.AuditEntity;
import java.time.LocalDateTime;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder(setterPrefix = "set", toBuilder = true)
@NoArgsConstructor
public class PartyRelationPartyEntity implements AuditEntity {

	private Long pkid;

	//references the id of the relation, field id of table prt_party_relations
	private Long partyRelationId;

	/**
	 * the target
	 */
	private Long partyId;
	//references the id of the role in the relation, field id of table prt_relation_roles
	private Long relationRoleId;
	private AbsoluteDate dtStart;
	private AbsoluteDate dtEnd;

	private LocalDateTime dtInsert;
	private String userIdInsert;
	private LocalDateTime dtDelete;
	private String userIdDelete;
}
