package com.abacogroup.partyregistry.resources.req;

import java.time.OffsetDateTime;
import java.util.Map;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

@Data
@NoArgsConstructor
@Accessors(chain = true)
public class UpdateDocumentReq {

	//TODO: chiedere se va aggiunto filtro in search validFrom e validTo o cancella ?
	private OffsetDateTime validFrom;
	private OffsetDateTime validTo;
	private Map<String, Object> fields;
}
