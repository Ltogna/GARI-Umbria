package com.abacogroup.partyregistry.core.impl;

import com.abacogroup.jdbi.criteria.Criteria;
import com.abacogroup.jdbi.orderby.OrderBy;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.partyregistry.api.Citizenship;
import com.abacogroup.partyregistry.core.CitizenshipService;
import com.abacogroup.partyregistry.db.dao.CitizenshipDAO;
import com.abacogroup.partyregistry.db.ntt.CitizenshipEntity;
import com.abacogroup.partyregistry.resources.req.CitizenshipSearchReq;
import com.abacogroup.partyregistry.resources.req.ReqContext;
import java.util.Optional;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class CitizenshipServiceImpl implements CitizenshipService {

	private final CitizenshipDAO citizenshipDAO;

	public CitizenshipServiceImpl(CitizenshipDAO citizenshipDAO) {
		this.citizenshipDAO = citizenshipDAO;
	}

	@Override
	public InfiniteListResults<Citizenship> search(ReqContext reqContext, CitizenshipSearchReq searchRequest,
			String nextKey) {
		Criteria criteria = searchRequest.getCriteria(reqContext);
		OrderBy sort = searchRequest.getSort();
		return citizenshipDAO.infinite(
				() -> citizenshipDAO.searchAll(criteria, sort, reqContext),
				nextKey, searchRequest.getPageSize());
	}

	@Override
	public Optional<Citizenship> getByCode(ReqContext context, String code) {
		return citizenshipDAO.searchByCode(code, context);
	}

	/*@Override
	public Citizenship save(ReqContext context, CitizenshipReq citizenshipReq) {
		Optional<CitizenshipEntity> dbEntity = findEntityByCode(context.getTenantId(), citizenshipReq.getCode());
		if (dbEntity.isEmpty()) {
			CitizenshipEntity entity = CitizenshipMapper.INSTANCE.reqToEntity(citizenshipReq);
			entity.setTenantId(context.getTenantId());
			return insert(context, entity);
		}
		log.warn("Trying to save a record with code {}, but the same code already exists: tenantId = {}, code = {}",
				citizenshipReq.getCode(), dbEntity.get().getTenantId(), citizenshipReq.getCode());

		throw new InvalidCitizenshipException(String.format("the relation %s exists", citizenshipReq.getCode()));
	}*/

	@Override
	public Optional<CitizenshipEntity> findEntityByCode(String tenantId, String code) {
		return citizenshipDAO.findOne(tenantId, code);
	}

	private Citizenship insert(ReqContext context, CitizenshipEntity entity) {
		citizenshipDAO.insert(entity);
		return getByCode(context, entity.getCode())
				.orElse(null);
	}

}
