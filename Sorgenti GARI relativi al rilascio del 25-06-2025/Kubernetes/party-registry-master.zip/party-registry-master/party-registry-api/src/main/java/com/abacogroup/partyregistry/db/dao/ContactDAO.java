package com.abacogroup.partyregistry.db.dao;

import com.abacogroup.jdbi.EnhancedSqlObject;
import com.abacogroup.jdbi.criteria.BindCriteria;
import com.abacogroup.jdbi.criteria.Criteria;
import com.abacogroup.jdbi.orderby.DefineOrder;
import com.abacogroup.jdbi.orderby.OrderBy;
import com.abacogroup.partyregistry.api.ContactSearchResponse;
import com.abacogroup.partyregistry.db.ntt.PartyContactEntity;
import com.abacogroup.partyregistry.resources.req.ReqContext;
import java.util.List;
import java.util.Optional;
import org.jdbi.v3.core.result.ResultIterator;
import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.customizer.BindBean;
import org.jdbi.v3.sqlobject.statement.GetGeneratedKeys;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;
import org.jdbi.v3.sqlobject.transaction.Transactional;

public interface ContactDAO extends Transactional<ContactDAO>, EnhancedSqlObject {

	@SqlUpdate(
			"INSERT INTO prt_parties_contacts (party_id, contact_type, sub_type, contact_value, note, dt_insert, user_id_insert, dt_delete, user_id_delete) "
					+ " VALUES (:partyId, :contactType, :subType, :contactValue, :note, :dtInsert, :userIdInsert, :dtDelete, :userIdDelete)")
	@GetGeneratedKeys("pkid")
	long insertContactRow(@BindBean PartyContactEntity entity);

	@SqlUpdate("update prt_parties_contacts set dt_delete =:dtDelete, user_id_delete=:userIdDelete where pkid = :pkid")
	void expireRow(@BindBean PartyContactEntity entity);

	@SqlQuery(
			"select co.pkid, co.party_id, co.contact_type, co.sub_type, co.contact_value, co.note, co.dt_insert, co.user_id_insert, co.dt_delete, co.user_id_delete "
					+ " from prt_parties_contacts co "
					+ " join prt_parties p on p.id = co.party_id "
					+ " join prt_parties_detail pd on p.id = pd.party_id and (§current_timestamp§ between pd.dt_insert and pd.dt_delete)"
					+ " WHERE p.tenant_id = :tenantId and <criteria> "
					+ " and (§current_timestamp§ between co.dt_insert and co.dt_delete) "
					+ " ORDER BY <orderBy> ")
	@RegisterBeanMapper(ContactSearchResponse.class)
	ResultIterator<ContactSearchResponse> search(
			@BindCriteria Criteria criteria,
			@DefineOrder OrderBy orderBy,
			@BindBean ReqContext ctx);

	@SqlQuery(
			"select co.pkid, co.party_id, co.contact_type, co.sub_type, co.contact_value, co.note, co.dt_insert, co.user_id_insert, co.dt_delete, co.user_id_delete "
					+ " from prt_parties_contacts co "
					+ " join prt_parties p on p.id = co.party_id and p.tenant_id = :tenantId "
					+ " join prt_parties_detail pd on p.id = pd.party_id and (§current_timestamp§ between pd.dt_insert and pd.dt_delete)"
					+ " where co.pkid = :pkid and co.party_id = :partyId "
					+ " and (§current_timestamp§ between co.dt_insert and co.dt_delete) ")
	@RegisterBeanMapper(PartyContactEntity.class)
	Optional<PartyContactEntity> loadContact(
			@Bind("tenantId") String tenantId,
			@Bind("partyId") Long partyId,
			@Bind("pkid") Long pkid
	);

	@SqlQuery(
			"select co.pkid, co.party_id, co.contact_type, co.sub_type, co.contact_value, co.note, co.dt_insert, co.user_id_insert, co.dt_delete, co.user_id_delete "
					+ " from prt_parties_contacts co "
					+ " join prt_parties p on p.id = co.party_id and p.tenant_id = :tenantId "
					+ " join prt_parties_detail pd on p.id = pd.party_id and (§current_timestamp§ between pd.dt_insert and pd.dt_delete)"
					+ " where co.party_id = :partyId "
					+ " and co.contact_type = :type "
					+ " and (§current_timestamp§ between co.dt_insert and co.dt_delete) ")
	@RegisterBeanMapper(PartyContactEntity.class)
	List<PartyContactEntity> loadContactsByTypeAndPartyId(
			@Bind("tenantId") String tenantId,
			@Bind("partyId") Long partyId,
			@Bind("type") String contactType
	);
}
