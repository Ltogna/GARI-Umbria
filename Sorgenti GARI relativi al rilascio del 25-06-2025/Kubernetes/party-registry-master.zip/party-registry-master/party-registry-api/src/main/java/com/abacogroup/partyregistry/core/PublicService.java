package com.abacogroup.partyregistry.core;

public interface PublicService {
}
