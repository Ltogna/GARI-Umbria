package com.abacogroup.partyregistry.resources.publicapis.mapper;

import com.abacogroup.partyregistry.api.v1.req.RelationTypeSearchRequestV1;
import com.abacogroup.partyregistry.resources.req.RelationTypeSearchReq;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper
public interface RelationTypeSearchReqMapper {

	RelationTypeSearchReqMapper INSTANCE = Mappers.getMapper(RelationTypeSearchReqMapper.class);

	RelationTypeSearchReq fromV1(RelationTypeSearchRequestV1 req);

}
