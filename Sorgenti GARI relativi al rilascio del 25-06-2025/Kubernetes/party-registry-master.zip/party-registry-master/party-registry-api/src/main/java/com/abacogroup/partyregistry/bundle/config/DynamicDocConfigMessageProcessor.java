package com.abacogroup.partyregistry.bundle.config;

import com.abacogroup.bundles.initializer.impl.exceptions.BundleException;
import com.abacogroup.bundles.listener.configdata.ConfigDataMessage;
import com.abacogroup.bundles.listener.configdata.ConfigMessageProcessor;
import com.abacogroup.dynamicdocuments.bean.DocumentDefinition;
import com.abacogroup.dynamicdocuments.services.DocumentTypeService;
import com.abacogroup.dynamicdocuments.services.SavedDocumentType;
import com.abacogroup.partyregistry.api.PartyTypeEnum;
import com.abacogroup.partyregistry.bundle.config.i18n.I18nAware;
import com.abacogroup.partyregistry.bundle.config.i18n.I18nEntry;
import com.abacogroup.partyregistry.bundle.config.i18n.I18nHelper;
import com.abacogroup.partyregistry.bundle.config.i18n.I18nMap;
import com.abacogroup.partyregistry.core.BundleConstants;
import com.abacogroup.partyregistry.core.impl.AuditHelper;
import com.abacogroup.partyregistry.db.dao.DocTypeDAO;
import com.abacogroup.partyregistry.db.dao.I18nDAO;
import com.abacogroup.partyregistry.db.dao.TagDAO;
import com.abacogroup.partyregistry.db.ntt.DocTypeEntity;
import com.abacogroup.partyregistry.db.ntt.DocTypeRelationEntity;
import com.abacogroup.partyregistry.db.ntt.DocTypeTagRelationEntity;
import com.abacogroup.partyregistry.db.ntt.TagEntity;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.jayway.jsonpath.JsonPath;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang3.StringUtils;

@Slf4j
public class DynamicDocConfigMessageProcessor implements ConfigMessageProcessor {

	private static final boolean assumeNoConfigAsAddAll = true;

	private final DocTypeDAO docTypeDAO;
	private final DocumentTypeService documentTypeService;
	private final I18nHelper i18nHelper;

	private final TagDAO tagDAO;

	private final ObjectMapper objectMapper = new ObjectMapper();

	public DynamicDocConfigMessageProcessor(DocTypeDAO docTypeDAO, DocumentTypeService documentTypeService, I18nDAO i18nDAO, TagDAO tagDAO) {
		this.docTypeDAO = docTypeDAO;
		this.documentTypeService = documentTypeService;
		this.i18nHelper = new I18nHelper(i18nDAO);
		this.tagDAO = tagDAO;
	}

	@Override
	public String getDomainName() {
		return BundleConstants.DOMAIN_DYNAMIC_DOCUMENTS;
	}

	@Override
	public void onMessage(ConfigDataMessage message) {
		String tenantId = message.getTenantId();

		List<Path> paths = message.getConfigFiles();
		var map = paths.stream()
				.filter(p -> FilenameUtils.isExtension(p.getFileName().toString(), "json"))
				.collect(Collectors.groupingBy(x -> {
							if (StringUtils.startsWithIgnoreCase(x.getFileName().toString(), "settings")) {
								if (StringUtils.containsIgnoreCase(x.getFileName().toString(), "delete")) {
									return "delete";
								} else {
									return "settings";
								}
							} else {
								return "DD";
							}
						},
						Collectors.toCollection(ArrayList::new)));

		map.getOrDefault("delete", new ArrayList<>()).forEach(path -> this.deleteSettings(tenantId, path));
		map.getOrDefault("DD", new ArrayList<>()).forEach(path -> this.saveDocumentType(tenantId, path));
		map.getOrDefault("settings", new ArrayList<>()).forEach(path -> this.saveSettings(tenantId, path));
	}

	private void deleteSettings(String tenantId, Path path) {
		log.info("removing DD settings from bundle file: {}", path);
		Set<String> docTypes = this.deserializeDocTypeCodes(path);

		AuditHelper.expire(new DocTypeRelationEntity(), BundleConstants.SYSTEM_USER,
				a -> docTypeDAO.expireTypeRelationsByCode(a, tenantId, docTypes),
				docTypeDAO.getCurrentTimestamp());

		AuditHelper.expire(new DocTypeEntity(), BundleConstants.SYSTEM_USER,
				a -> docTypeDAO.expireRowsByCode(a, tenantId, docTypes),
				docTypeDAO.getCurrentTimestamp());

	}

	private SavedDocumentType saveDocumentType(String tenantId, Path path) {
		log.info("processing DD from bundle file: {}", path);
		try {
			String jsonContent = Files.readString(path);
			//			log.error("{}: {}", path, jsonContent);
			return documentTypeService.saveDocumentType(tenantId, jsonContent, BundleConstants.SYSTEM_USER);
		} catch (IOException e) {
			throw new BundleException(String.format("error saving %s", path), e);
		}
	}

	private void saveSettings(String tenantId, Path path) {
		log.info("processing DD settings from bundle file: {}", path);

		try {
			String json = Files.readString(path);
			DocumentSettingEntry settings = objectMapper.readValue(json, new TypeReference<>() {
			});

			List<DocTypeEntity> docTypeEntitiesToSave = new ArrayList<>();
			Map<String, Set<PartyTypeEnum>> typeRelationMap = new HashMap<>();
			Map<String, Set<String>> tagsRelationMap = new HashMap<>();

			this.processSettings(tenantId, settings,
					docTypeEntitiesToSave, typeRelationMap, tagsRelationMap);

			this.savePartyDocumentType(docTypeEntitiesToSave.toArray(DocTypeEntity[]::new), tenantId);
			this.storePartyTypeRelations(tenantId, typeRelationMap);
			this.storeTagsRelations(tenantId, tagsRelationMap);

			settings.getGroups().forEach(entry -> i18nHelper.upsert(tenantId, "prt_doc_type", "doc_group", entry));

		} catch (Exception e) {
			throw new BundleException(String.format("error processing DD settings from bundle file '%s': '%s'", path, e.getMessage()), e);
		}
	}

	private void processSettings(String tenantId, DocumentSettingEntry settings,
			List<DocTypeEntity> docTypeEntitiesToSave, Map<String, Set<PartyTypeEnum>> typesRelationMap, Map<String, Set<String>> tagsRelationMap) {

		for (DocSettingEntry documentSetting : settings.getDocuments()) {
			DocumentDefinition documentDefinition = this.getDocumentDefinition(tenantId, documentSetting);

			docTypeEntitiesToSave.add(DocTypeEntity.builder()
					.setTenantId(tenantId)
					.setDocType(documentDefinition.getCode())
					.setDocGroup(documentSetting.getDocGroup())
					.build());

			typesRelationMap.compute(documentSetting.getDocType(),
					(docType, types) -> {
						Set<PartyTypeEnum> set = Optional.ofNullable(types).orElseGet(HashSet::new);
						set.addAll(documentSetting.getTypesList());
						return set;
					});

			tagsRelationMap.compute(documentSetting.getDocType(),
					(docType, tags) -> Optional.ofNullable(documentSetting.getTags())
							.stream().flatMap(Collection::stream)
							.map(StringUtils::trim)
							.filter(StringUtils::isNotBlank)
							.map(StringUtils::upperCase)
							.collect(Collectors.toCollection(
									() -> Optional.ofNullable(tags).orElseGet(HashSet::new)))
			);

			i18nHelper.upsert(tenantId, "prt_doc_type", "doc_type", new DocTypeI18nAware(documentDefinition));
		}
	}

	private void savePartyDocumentType(DocTypeEntity[] docTypeEntities, String tenantId) {
		if (docTypeEntities.length > 0) {
			Set<String> codes = Stream.of(docTypeEntities).map(DocTypeEntity::getDocType).collect(Collectors.toSet());
			AuditHelper.expire(new DocTypeEntity(), BundleConstants.SYSTEM_USER,
					a -> docTypeDAO.expireRowsByCode(a, tenantId, codes),
					docTypeDAO.getCurrentTimestamp());

			AuditHelper.setAuditForInsert(BundleConstants.SYSTEM_USER, docTypeDAO, docTypeEntities);
			docTypeDAO.insertIdempotent(docTypeEntities);
		}
	}

	protected void storePartyTypeRelations(String tenantId, Map<String, Set<PartyTypeEnum>> typesRelationMapMap) {
		if (!typesRelationMapMap.isEmpty()) {
			Set<String> codes = typesRelationMapMap.keySet();
			AuditHelper.expire(new DocTypeRelationEntity(), BundleConstants.SYSTEM_USER,
					a -> docTypeDAO.expireTypeRelationsByCode(a, tenantId, codes),
					docTypeDAO.getCurrentTimestamp());

			DocTypeRelationEntity audit = DocTypeRelationEntity.builder().build();
			AuditHelper.setAuditForInsert(audit, BundleConstants.SYSTEM_USER, docTypeDAO);

			typesRelationMapMap.entrySet()
					.stream()
					.filter(e -> e.getKey() != null)
					.filter(e -> !e.getValue().isEmpty())
					.forEach(e -> docTypeDAO.insertRelationsIdempotent(audit, tenantId, e.getKey(),
							e.getValue().stream()
									.map(Enum::name)
									.toArray(String[]::new)));
		}
	}

	private void storeTagsRelations(String tenantId, Map<String, Set<String>> tagsRelationMap) {
		if (!tagsRelationMap.isEmpty()) {
			Set<String> codes = tagsRelationMap.keySet();
			AuditHelper.expire(new DocTypeTagRelationEntity(), BundleConstants.SYSTEM_USER,
					a -> docTypeDAO.expireTagRelationsByCode(a, tenantId, codes),
					docTypeDAO.getCurrentTimestamp());

			Set<String> allTags = tagsRelationMap.values().stream()
					.flatMap(Collection::stream)
					.collect(Collectors.toSet());
			Map<String, Long> tagIdMap = Optional.of(allTags)
					.filter(t -> !t.isEmpty())
					.map(t -> tagDAO.findByCodeIn(tenantId, t))
					.stream().flatMap(Collection::stream)
					.collect(Collectors.toMap(TagEntity::getCode, TagEntity::getId));

			if (!allTags.equals(tagIdMap.keySet())) {
				allTags.removeAll(tagIdMap.keySet());
				throw new BundleException(String.format("tags %s do not exist", allTags));
			}

			DocTypeTagRelationEntity[] docTypeTagRelationEntities = tagsRelationMap.entrySet()
					.stream()
					.filter(e -> e.getKey() != null)
					.filter(e -> !e.getValue().isEmpty())
					.flatMap(e -> e.getValue().stream()
							.map(tag -> DocTypeTagRelationEntity.builder()
									.setDocType(e.getKey())
									.setTagId(tagIdMap.get(tag))
									.build()))
					.toArray(DocTypeTagRelationEntity[]::new);

			AuditHelper.setAuditForInsert(BundleConstants.SYSTEM_USER, docTypeDAO, docTypeTagRelationEntities);
			docTypeDAO.insertTagRelationsIdempotent(tenantId, docTypeTagRelationEntities);
		}

	}

	private DocumentDefinition getDocumentDefinition(String tenantId, DocSettingEntry documentSetting) {
		DocumentDefinition documentDefinition = documentTypeService.getDocumentDefinition(tenantId, documentSetting.getDocType())
				.orElseThrow(() -> new BundleException(String.format("docType '%s' does not exists", documentSetting.getDocType())));
		return documentDefinition;
	}


	private Set<String> deserializeDocTypeCodes(Path path) {
		try {
			String jsonContent = Files.readString(path);

			return new HashSet<>(JsonPath.parse(jsonContent).read("$[*].docType"));

		} catch (IOException e) {
			throw new BundleException(String.format("error saving %s", path), e);
		}
	}

	// #################################################################################################

	/**
	 * determina come deve comportarsi il parser in casi come
	 * <p><code>{"docType": "EINVOICING"}</code></p>
	 * dove non vengono specificate le discriminanti per un tipo di documento
	 * <p>
	 * Le possibili strategie sono includere tutto (tutti i tipi di party), oppure nulla
	 */
	protected static List<String> getDefaultTypes() {
		if (assumeNoConfigAsAddAll) {
			return Arrays.stream(PartyTypeEnum.values())
					.map(Enum::name)
					.collect(Collectors.toList());
		} else {
			return Collections.emptyList();
		}
	}

	@Data
	@JsonInclude(value = Include.NON_NULL)
	protected static class DocumentSettingEntry {

		private List<DocGroupEntry> groups = new ArrayList();
		private List<DocSettingEntry> documents = new ArrayList();

	}

	@Data
	protected static class DocGroupEntry implements I18nAware {
		private String value;
		private I18nMap description = new I18nMap();

		@Override
		public String getI18nCode() {
			return value;
		}

		@Override
		public Set<I18nEntry> getI18n() {
			return description.getI18n();
		}
	}

	@Data
	protected static class DocSettingEntry {

		private String docType;

		private List<String> types;
		private List<String> tags;

		private String docGroup;

		public List<PartyTypeEnum> getTypesList() {

			return Optional.ofNullable(types).or(() -> Optional.of(getDefaultTypes()))
					.stream().flatMap(Collection::stream)
					.filter(Objects::nonNull)
					.filter(StringUtils::isNotBlank)
					.map(PartyTypeEnum::valueOf)
					.distinct()
					.sorted()
					.collect(Collectors.toList());
		}
	}

	private static class DocTypeI18nAware implements I18nAware {
		private final DocumentDefinition documentDefinition;

		public DocTypeI18nAware(DocumentDefinition documentDefinition) {
			this.documentDefinition = documentDefinition;
		}

		@Override
		public String getI18nCode() {
			return documentDefinition.getCode();
		}

		@Override
		public Set<I18nEntry> getI18n() {
			return new I18nMap(documentDefinition.getTitle()).getI18n();
		}
	}
}
