package com.abacogroup.partyregistry.resources;

import java.util.List;

import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.partyregistry.api.PartyTag;
import com.abacogroup.partyregistry.core.AclService;
import com.abacogroup.partyregistry.core.PartyTagService;
import com.abacogroup.partyregistry.core.exceptions.InvalidPartyException;
import com.abacogroup.partyregistry.core.exceptions.InvalidTagException;
import com.abacogroup.partyregistry.resources.req.CodeReq;
import com.abacogroup.partyregistry.resources.req.ReqContext;

import io.dropwizard.auth.Auth;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.annotation.security.RolesAllowed;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.DefaultValue;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.HeaderParam;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

@SuppressWarnings("UnresolvedRestParam")
@Path(ResourceConstants.API_PRIV + "/parties/{partyId}/tags")
@Produces(MediaType.APPLICATION_JSON)
@Tag(name = "party tags", description = "Operations on party tags")
public class PartyTagResource {
	
	private static final boolean SKIP_ACL_IF_CAN_IGNORE = true;

	private final AclService aclService;
	private final PartyTagService partyTagService;

	public PartyTagResource(AclService aclService, PartyTagService partyTagService) {
		this.aclService = aclService;
		this.partyTagService = partyTagService;
	}

	@Operation(summary = "List of party tags", description = "Get list of tags of a specific party")
	@ApiResponses({
			@ApiResponse(responseCode = "200", description = "Successfully, returns a list of party tags (sorted/filtered)",
					content = @Content(mediaType = "application/json", array = @ArraySchema(
							schema = @Schema(implementation = PartyTag.class))))
	})
	@GET
	@RolesAllowed("PARTY-REGISTRY|READ")
	public List<PartyTag> search(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "the tenant ID") @PathParam("tenant") String tenantId,
			@Parameter(description = "the party ID") @PathParam("partyId") Long partyId
	) {
		ReqContext reqContext = new ReqContext(user, lang);
		aclService.canRead(reqContext, partyId, SKIP_ACL_IF_CAN_IGNORE);
		return partyTagService.getPartyTags(reqContext, partyId);
	}

	@Operation(summary = "Create a party tag", description = "Attach a Tag to a party")
	@ApiResponses({
			@ApiResponse(responseCode = "200", description = "Successfully, the tag is attached to the party",
					content = @Content(mediaType = "application/json", schema = @Schema(implementation = com.abacogroup.partyregistry.api.Tag.class))),
			@ApiResponse(responseCode = "400", description = "attach tag error",
					content = @Content(mediaType = "application/json", schema = @Schema(anyOf = {
							InvalidPartyException.ErrorBody.class,
							InvalidTagException.ErrorBody.class
					})))
	})
	@POST
	@RolesAllowed("PARTY-REGISTRY|WRITE")
	public com.abacogroup.partyregistry.api.Tag add(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "the tenant ID") @PathParam("tenant") String tenantId,
			@Parameter(description = "the party ID") @PathParam("partyId") Long partyId,
			@NotNull @Valid CodeReq codeReq
	) {
		ReqContext reqContext = new ReqContext(user, lang);
		aclService.canWrite(reqContext, partyId);
		return partyTagService.attachTag(reqContext, partyId, codeReq.getCode());
	}

	@Operation(summary = "Delete a party tag", description = "Detach a Tag from a party")
	@ApiResponses({
			@ApiResponse(responseCode = "200", description = "Successfully, the tag is detached from the party"),
			@ApiResponse(responseCode = "400", description = "invalid party", content = @Content(schema = @Schema(implementation = InvalidPartyException.ErrorBody.class))),
	})
	@DELETE
	@RolesAllowed("PARTY-REGISTRY|DELETE")
	@Path("/{tagCode}")
	public Response delete(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "the tenant ID") @PathParam("tenant") String tenantId,
			@Parameter(description = "the party ID") @PathParam("partyId") Long partyId,
			@Parameter(description = "the tag CODE") @PathParam("tagCode") String tagCode
	) {
		ReqContext reqContext = new ReqContext(user, lang);
		aclService.canWrite(reqContext, partyId);
		partyTagService.detachTag(reqContext, partyId, tagCode);
		return Response.ok().build();
	}

}
