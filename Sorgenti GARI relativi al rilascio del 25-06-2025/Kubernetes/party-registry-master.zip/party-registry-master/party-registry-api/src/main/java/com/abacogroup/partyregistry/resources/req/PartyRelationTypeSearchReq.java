package com.abacogroup.partyregistry.resources.req;

import com.abacogroup.jdbi.criteria.Criteria;
import com.abacogroup.jdbi.criteria.CriteriaBuilder;
import com.abacogroup.jdbi.orderby.OrderBy;
import com.abacogroup.jdbi.orderby.OrderByBuilder;
import com.abacogroup.jdbi.orderby.OrderByElement;
import com.abacogroup.jdbi.orderby.SortDirection;
import com.abacogroup.partyregistry.resources.ResourceConstants;
import com.fasterxml.jackson.annotation.JsonIgnore;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.ws.rs.QueryParam;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

@Data
@NoArgsConstructor
@Accessors(chain = true)
public class PartyRelationTypeSearchReq implements BaseSearchReq {

	@Parameter(in = ParameterIn.QUERY, description = "relation type Code")
	@QueryParam("relationTypeCode")
	private String relationTypeCode;

	@Parameter(in = ParameterIn.QUERY, description = "note")
	@QueryParam("note")
	private String note;

	@Override
	@JsonIgnore
	@Schema(hidden = true)
	public int getPageSize() {
		return ResourceConstants.PAGE_SIZE;
	}

	@Override
	@JsonIgnore
	@Schema(hidden = true)
	public Criteria getCriteria(ReqContext ctx) {
		List<Criteria> specs = new ArrayList<>();

		Optional.ofNullable(getRelationTypeCode())
				.ifPresent(v -> specs.add(CriteriaBuilder.string("relation_type_code").eq(v.toUpperCase())));

		//like
		Optional.ofNullable(getNote())
				.ifPresent(v -> specs.add(CriteriaBuilder.string("note").caseInsensitiveContains(v)));

		return CriteriaBuilder.and(specs.toArray(new Criteria[0]));
	}

	@Override
	@JsonIgnore
	@Schema(hidden = true)
	public OrderByElement getSort() {
		return OrderByBuilder.field("relation_type_i18n_code").direction(SortDirection.ASC);
	}

	@JsonIgnore
	@Schema(hidden = true)
	public OrderBy getDefaultSort() {
		return OrderByBuilder.from(getSort(), OrderByBuilder.field("id").direction(SortDirection.ASC));
	}

}
