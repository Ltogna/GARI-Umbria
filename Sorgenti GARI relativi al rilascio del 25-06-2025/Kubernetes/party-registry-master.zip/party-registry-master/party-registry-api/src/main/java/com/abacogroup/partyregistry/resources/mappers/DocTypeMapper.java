package com.abacogroup.partyregistry.resources.mappers;

import com.abacogroup.partyregistry.api.DocType;
import com.abacogroup.partyregistry.db.ntt.DocTypeEntity;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper
public interface DocTypeMapper {

	DocTypeMapper INSTANCE = Mappers.getMapper(DocTypeMapper.class);

	DocTypeEntity dtoToEntity(DocType dto);

	DocType entityToDto(DocTypeEntity entity);
}
