package com.abacogroup.partyregistry.api;

import com.abacogroup.dynamicdocuments.bean.DocumentDefinition;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.experimental.Accessors;

@Data
@EqualsAndHashCode(callSuper = true)
@ToString(callSuper = true)
@AllArgsConstructor
@NoArgsConstructor
@Accessors(chain = true)
public class PartyDocumentDefinition extends DocumentDefinition {

	private String bucketName;

}
