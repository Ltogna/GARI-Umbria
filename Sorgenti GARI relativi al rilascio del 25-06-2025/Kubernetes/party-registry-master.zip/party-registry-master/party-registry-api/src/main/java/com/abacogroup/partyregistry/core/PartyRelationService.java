package com.abacogroup.partyregistry.core;

import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.partyregistry.api.PartyRelation;
import com.abacogroup.partyregistry.db.ntt.PartyRelationEntity;
import com.abacogroup.partyregistry.resources.req.PartyRelationTypeSearchReq;
import com.abacogroup.partyregistry.resources.req.ReqContext;
import com.abacogroup.partyregistry.resources.req.rel.CreatePartyRelationReq;
import com.abacogroup.partyregistry.resources.req.rel.PartyRelationDetailRequest;
import java.util.Optional;

public interface PartyRelationService {

	/**
	 * Aggiunge una relazione (prt_party_relations) e se sono presenti dati.. anche un record su prt_party_relation_parties
	 *
	 * @param partyId
	 * @param createPartyRelationReq
	 * @return
	 */
	default PartyRelation save(ReqContext reqContext, Long partyId, CreatePartyRelationReq createPartyRelationReq) {
		return save(reqContext, partyId, createPartyRelationReq, true);
	}

	/**
	 * Aggiunge una relazione (prt_party_relations) e se sono presenti dati.. anche un record su prt_party_relation_parties
	 *
	 * @param partyId
	 * @param createPartyRelationReq
	 * @param sendEvent
	 * @return
	 */
	PartyRelation save(ReqContext reqContext, Long partyId, CreatePartyRelationReq createPartyRelationReq, boolean sendEvent);

	void expireAll(ReqContext context, Long partyId, String relationTypeCode, boolean sendEvent);

	/**
	 * inserisce o aggiorna (inserendo un altro record) un dettaglio prt_party_relation_details
	 */
	PartyRelation saveDetail(ReqContext reqContext, Long partyId, Long partyRelId,
			PartyRelationDetailRequest detailRequest);

	InfiniteListResults<PartyRelation> search(ReqContext context, Long partyId, PartyRelationTypeSearchReq searchReq,
			String nextKey);

	Optional<PartyRelation> getRelationById(ReqContext context, Long partyId, Long id);

	Optional<PartyRelationEntity> findById(String tenantId, Long partyId, Long id);

	void expire(ReqContext context, Long partyId, Long id);

}
