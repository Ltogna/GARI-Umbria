package com.abacogroup.partyregistry.resources.req.rel;

import static com.abacogroup.jdbi.datatype.validation.AbsoluteDateFormatValidator.DATE_DEFAULT_STR;
import static com.abacogroup.jdbi.datatype.validation.AbsoluteDateFormatValidator.DATE_REGEXP;

import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.jdbi.model.AuditEntity;
import com.fasterxml.jackson.annotation.JsonSetter;
import com.fasterxml.jackson.annotation.Nulls;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

@Data
@NoArgsConstructor
@Accessors(chain = true)
public class PartyRelationItemReq {

	@NotNull
	private Long relatedPartyId;
	@NotEmpty
	private String relatedRoleCode;
	@Schema(pattern = DATE_REGEXP, maxLength = 8, minLength = 5)
	@NotNull
	@Valid
	private AbsoluteDate dtStart;
	@Schema(defaultValue = DATE_DEFAULT_STR, pattern = DATE_REGEXP, maxLength = 8, minLength = 5)
	@JsonSetter(nulls = Nulls.SKIP)
	@Valid
	private AbsoluteDate dtEnd = AbsoluteDate.of(AuditEntity.dateActive);
}

