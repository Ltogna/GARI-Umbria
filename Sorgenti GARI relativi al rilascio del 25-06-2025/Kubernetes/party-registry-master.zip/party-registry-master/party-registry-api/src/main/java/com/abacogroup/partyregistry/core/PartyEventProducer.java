package com.abacogroup.partyregistry.core;

import com.abacogroup.partyregistry.core.dto.PartyEventType;
import com.abacogroup.partyregistry.resources.req.ReqContext;

public interface PartyEventProducer {
	void pushPartyEvent(ReqContext reqContext, Long partyId, PartyEventType eventType);

	void pushPartyEvent(String tenant, String username, String lang, Long partyId, PartyEventType eventType);
}
