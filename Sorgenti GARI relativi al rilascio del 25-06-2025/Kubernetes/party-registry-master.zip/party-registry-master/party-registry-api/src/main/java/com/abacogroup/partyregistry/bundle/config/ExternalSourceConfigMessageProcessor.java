package com.abacogroup.partyregistry.bundle.config;

import com.abacogroup.bundles.initializer.impl.exceptions.BundleException;
import com.abacogroup.bundles.listener.configdata.ConfigDataMessage;
import com.abacogroup.bundles.listener.configdata.ConfigMessageProcessor;
import com.abacogroup.partyregistry.bundle.config.i18n.I18nAware;
import com.abacogroup.partyregistry.bundle.config.i18n.I18nEntry;
import com.abacogroup.partyregistry.bundle.config.i18n.I18nHelper;
import com.abacogroup.partyregistry.bundle.config.i18n.I18nMap;
import com.abacogroup.partyregistry.bundle.utils.FileOperationEnum;
import com.abacogroup.partyregistry.core.BundleConstants;
import com.abacogroup.partyregistry.core.impl.AuditHelper;
import com.abacogroup.partyregistry.db.dao.ExternalSourceDAO;
import com.abacogroup.partyregistry.db.dao.I18nDAO;
import com.abacogroup.partyregistry.db.dao.PartyDAO;
import com.abacogroup.partyregistry.db.ntt.ExternalSourceEntity;
import com.abacogroup.partyregistry.db.ntt.PartyEntity;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.stream.Collectors;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

@Slf4j
public class ExternalSourceConfigMessageProcessor implements ConfigMessageProcessor {

	private static final String CODE_PATH_PARAM = "{code}";
	private final ExternalSourceDAO externalSourceDAO;
	private final PartyDAO partyDAO;
	private final ObjectMapper mapper = new ObjectMapper();

	private final I18nHelper i18nHelper;

	public ExternalSourceConfigMessageProcessor(ExternalSourceDAO externalSourceDAO, PartyDAO partyDAO, I18nDAO i18nDAO) {
		this.externalSourceDAO = externalSourceDAO;
		this.partyDAO = partyDAO;
		this.i18nHelper = new I18nHelper(i18nDAO);
	}

	@Override
	public void onMessage(ConfigDataMessage message) {
		String tenantId = message.getTenantId();
		Function<String, FileOperationEnum> groupingPredicate = x -> {
			if (StringUtils.containsIgnoreCase(x, "delete")) {
				return FileOperationEnum.DELETE;
			} else {
				return FileOperationEnum.DEFAULT;
			}
		};
		List<Path> paths = message.getConfigFiles();
		var map = paths.stream()
				.collect(Collectors.groupingBy(x -> groupingPredicate.apply(x.toString()),
						Collectors.toCollection(ArrayList::new)));

		map.getOrDefault(FileOperationEnum.DELETE, new ArrayList<>()).forEach(path -> removeContent(tenantId, path));
		map.getOrDefault(FileOperationEnum.DEFAULT, new ArrayList<>()).forEach(path -> addContent(tenantId, path));
	}

	private void removeContent(String tenantId, Path path) {
		List<ExternalSourceEntry> entries = readFileToMap(path);
		deleteExternalSources(entries, tenantId);
	}

	private void deleteExternalSources(List<ExternalSourceEntry> entries, String tenantId) {
		entries.forEach(toDelete ->
				externalSourceDAO.useTransaction(handle -> {
					handle.findByCode(tenantId, toDelete.getCode())
							.ifPresentOrElse(e -> {
										checkSourceCodeUsageInParty(tenantId, e.getCode());
										Consumer<ExternalSourceEntity> expireFun = handle::expireRow;
										AuditHelper.expire(e, BundleConstants.SYSTEM_USER, expireFun, handle.getCurrentTimestamp());
									},
									() -> log.warn("cannot remove external source {} : already deleted!",
											toDelete.getCode()));
				}));
	}

	private void addContent(String tenantId, Path path) {
		List<ExternalSourceEntry> entries = readFileToMap(path);
		storeExternalSources(tenantId, entries);
	}

	private void storeExternalSources(String tenantId, List<ExternalSourceEntry> entries) {
		List<ExternalSourceEntity> entities = mapExternalSources(tenantId, entries);
		entities.forEach(e ->
				upsertExternalSource(e, tenantId)
		);
		entries.forEach(externalSourceEntry -> i18nHelper.upsert(tenantId, "prt_external_sources", "code", externalSourceEntry));
	}

	private List<ExternalSourceEntity> mapExternalSources(String tenantId, List<ExternalSourceEntry> entries) {
		return entries.stream()
				.filter(Objects::nonNull)
				.filter(e -> !e.getCode().isEmpty())
				.map(entry -> {
					ExternalSourceEntity entity = new ExternalSourceEntity();
					entity.setTenantId(tenantId);
					entity.setCode(entry.getCode());
					entity.setUrl(entry.getUrl());
					entity.setFlAllowManual(entry.isAllowManual() ? 1 : 0);
					return entity;
				})
				.collect(Collectors.toList());
	}

	private void upsertExternalSource(ExternalSourceEntity entity, String tenant) {
		externalSourceDAO.useTransaction(handle -> {
			handle.findByCode(tenant, entity.getCode())
					.ifPresentOrElse(existing -> {
								//update
								if (StringUtils.isNotEmpty(entity.getUrl())) {
									validateExternalSourceUrl(entity);
								}
								existing.setUrl(Optional.ofNullable(entity.getUrl())
										.orElse(existing.getUrl()));
								existing.setFlAllowManual(Optional.ofNullable(entity.getFlAllowManual())
										.orElse(existing.getFlAllowManual()));
								Consumer<ExternalSourceEntity> expire = handle::expireRow;
								Function<ExternalSourceEntity, Long> insert = handle::insert;
								Long pkid = AuditHelper.update(existing, BundleConstants.SYSTEM_USER, expire, insert, handle.getCurrentTimestamp());
								log.trace("external source {} updated! new id {}", entity.getCode(), pkid);

							},
							() -> {
								//insert new
								if (StringUtils.isEmpty(entity.getUrl())) {
									throw new BundleException(String.format("error saving externalSource %s, url is required'", entity.getCode()));
								}
								validateExternalSourceUrl(entity);
								AuditHelper.setAuditForInsert(BundleConstants.SYSTEM_USER, externalSourceDAO, entity);
								externalSourceDAO.insert(entity);
							});
		});
	}

	private void validateExternalSourceUrl(ExternalSourceEntity e) {
		if (!e.getUrl().contains(CODE_PATH_PARAM)) {
			throw new BundleException(String.format("error saving externalSource invalid URL : '%s' missing param '%s' ", e.getUrl(), CODE_PATH_PARAM));
		}
	}

	private void checkSourceCodeUsageInParty(String tenantId, String code) {
		List<PartyEntity> parties = partyDAO.findByTenantAndSourceCode(tenantId, code);
		if (parties != null && !parties.isEmpty()) {
			throw new BundleException(String.format("Error deleting externalSource ' %s ': it is already in use", code));
		}
	}

	protected List<ExternalSourceEntry> readFileToMap(Path path) {
		try {
			String json = Files.readString(path);
			return mapper.readValue(json, new TypeReference<>() {
			});

		} catch (IOException e) {
			throw new BundleException(String.format("error reading file %s", path), e);
		}
	}

	@Override
	public String getDomainName() {
		return BundleConstants.DOMAIN_EXTERNAL_SOURCES;
	}

	@Data
	protected static class ExternalSourceEntry implements I18nAware {
		private String code;
		private String url;
		private boolean allowManual;

		private I18nMap description = new I18nMap();

		public String getCode() {
			return code.toUpperCase();
		}

		@Override
		public String getI18nCode() {
			return code.toUpperCase();
		}

		@Override
		public Set<I18nEntry> getI18n() {
			return description.getI18n();
		}
	}
}
