package com.abacogroup.partyregistry.core.impl.validaor;

import com.abacogroup.partyregistry.core.PartyFieldValidator;
import com.abacogroup.partyregistry.db.ntt.PartyEntity;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.commons.lang3.StringUtils;

public class PartyTaxCodeRegexValidatorImpl extends AbstractRegexCodeValidator implements PartyFieldValidator {

	public static final String CONFIG_KEY = "taxCode_validation";

	public PartyTaxCodeRegexValidatorImpl(ObjectMapper objectMapper) {
		super(objectMapper);
	}

	@Override
	public String getFieldName() {
		return CONFIG_KEY;
	}

	@Override
	protected String getCodeDescription() {
		return "TAX CODE";
	}

	@Override
	protected String getCode(PartyEntity party) {
		party.setTaxCode(StringUtils.upperCase(StringUtils.trim(party.getTaxCode())));
		return party.getTaxCode();
	}

}
