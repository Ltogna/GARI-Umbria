package com.abacogroup.partyregistry.core.impl;

import com.abacogroup.dynamicdocuments.bean.InsertDocument;
import com.abacogroup.partyregistry.api.ExternalSourceRes;
import com.abacogroup.partyregistry.api.PartyRelation;
import com.abacogroup.partyregistry.api.PartyRes;
import com.abacogroup.partyregistry.core.AclService;
import com.abacogroup.partyregistry.core.ContactService;
import com.abacogroup.partyregistry.core.PartyRelationPartyService;
import com.abacogroup.partyregistry.core.PartyRelationService;
import com.abacogroup.partyregistry.core.PartyService;
import com.abacogroup.partyregistry.core.client.ExternalSourceClientV1;
import com.abacogroup.partyregistry.core.dynamicdoc.PartyDynamicDocumentManager;
import com.abacogroup.partyregistry.core.exceptions.ExternalSourceException;
import com.abacogroup.partyregistry.core.exceptions.ExternalSourceException.ErrEnum;
import com.abacogroup.partyregistry.db.dao.ExternalSourceDAO;
import com.abacogroup.partyregistry.dto.v1.ExternalSourceDtoV1;
import com.abacogroup.partyregistry.dto.v1.PartyContactExternalDtoV1;
import com.abacogroup.partyregistry.dto.v1.PartyExternalDtoV1;
import com.abacogroup.partyregistry.dto.v1.PartyRelationExternalDtoV1;
import com.abacogroup.partyregistry.dto.v1.PartyRelationItemExternalDtoV1;
import com.abacogroup.partyregistry.resources.mappers.PartyContactMapper;
import com.abacogroup.partyregistry.resources.mappers.PartyMapper;
import com.abacogroup.partyregistry.resources.mappers.PartyRelationsMapper;
import com.abacogroup.partyregistry.resources.req.PartyCreateReq;
import com.abacogroup.partyregistry.resources.req.PartyExternalReq;
import com.abacogroup.partyregistry.resources.req.PartyUpdateReq;
import com.abacogroup.partyregistry.resources.req.ReqContext;
import com.abacogroup.partyregistry.resources.req.rel.CreatePartyRelationReq;
import com.abacogroup.partyregistry.resources.req.rel.PartyRelationItemReq;
import jakarta.validation.ConstraintViolation;
import jakarta.validation.ConstraintViolationException;
import jakarta.validation.Validation;
import jakarta.validation.Validator;
import jakarta.validation.ValidatorFactory;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

public class ExternalSourceServiceImpl implements com.abacogroup.partyregistry.core.ExternalSourceService {

	private final ExternalSourceDAO externalSourceDAO;
	private final ExternalSourceClientV1 externalSourceClient;
	private final PartyService partyService;
	private final PartyDynamicDocumentManager documentManager;
	private final PartyRelationService partyRelationService;
	private final PartyRelationPartyService partyRelationPartyService;
	private final ContactService contactService;
	private final AclService aclService;

	public ExternalSourceServiceImpl(ExternalSourceDAO externalSourceDAO, ExternalSourceClientV1 externalSourceClient,
			PartyService partyService, PartyDynamicDocumentManager documentManager,
			PartyRelationService partyRelationService, PartyRelationPartyService partyRelationPartyService,
			ContactService contactService, AclService aclService) {
		this.externalSourceDAO = externalSourceDAO;
		this.externalSourceClient = externalSourceClient;
		this.partyService = partyService;
		this.documentManager = documentManager;
		this.partyRelationService = partyRelationService;
		this.partyRelationPartyService = partyRelationPartyService;
		this.contactService = contactService;
		this.aclService = aclService;
	}

	@Override
	public List<ExternalSourceRes> getAll(ReqContext reqContext) {
		return externalSourceDAO.getAllAsList(reqContext);
	}

	@Override
	public ExternalSourceRes getByCode(ReqContext reqContext, String code) {
		return externalSourceDAO.getByCode(code, reqContext).orElse(null);
	}

	@Override
	public PartyRes upsertParty(ReqContext reqContext, PartyExternalReq req) {
		ExternalSourceDtoV1 externalSourceDto = externalSourceClient.getExternalPartyByCode(reqContext.getLang(), reqContext.getUser(),
				req.getSourceCode(), req.getPartyCode());

		this.validatePayload(req, externalSourceDto);

		return externalSourceDAO.inTransaction(h -> {
			PartyRes partyRes = this.doUpsertParty(reqContext, req.getSourceCode(), externalSourceDto.getPartyData());
			Long partyId = partyRes.getId();

			this.doUpsertDocuments(reqContext, partyId, externalSourceDto.getDocuments());
			this.doUpsertRelations(reqContext, req.getSourceCode(), partyRes, externalSourceDto.getRelations());
			this.doUpsertContacts(reqContext, partyId, externalSourceDto.getContacts());

			return partyRes;
		});
	}

    @Override
    public boolean checkPartyExistenceOnExternalSourceByCode(ReqContext reqContext, PartyExternalReq req) {
        try {
            ExternalSourceDtoV1 externalSourceDto = externalSourceClient.getExternalPartyByCode(reqContext.getLang(), reqContext.getUser(),
                    req.getSourceCode(), req.getPartyCode());
            this.validatePayload(req, externalSourceDto);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

	private void doUpsertContacts(ReqContext reqContext, Long partyId, List<PartyContactExternalDtoV1> contacts) {
		Optional.ofNullable(contacts)
				.ifPresent(list -> list.stream()
						.collect(Collectors.groupingBy(PartyContactExternalDtoV1::getContactType))
						.forEach((type, contactList) -> {
							contactService.expireContactsByType(reqContext, type, partyId);
							contactList.forEach(contact -> {
								contactService.insert(reqContext, partyId, PartyContactMapper.INSTANCE.externalToReq(contact), false);
							});
						}));
	}

	private void doUpsertRelations(ReqContext reqContext, String sourceCode, PartyRes party, List<PartyRelationExternalDtoV1> relations) {
		Map<String, List<PartyRelationExternalDtoV1>> relationsByRelationCode = Optional.ofNullable(relations).stream()
				.flatMap(Collection::stream)
				.collect(Collectors.groupingBy(PartyRelationExternalDtoV1::getRelationCode, Collectors.toList()));

		Map<String, PartyRes> partyCache = new HashMap<>();
		partyCache.put(party.getCode(), party);

		relationsByRelationCode.forEach((relationCode, rels) -> {
			partyRelationService.expireAll(reqContext, party.getId(), relationCode, false);

			rels.forEach(rel -> {
				CreatePartyRelationReq createReq = PartyRelationsMapper.INSTANCE.relationExternalToCreateReq(rel);
				PartyRelation partyRelation = partyRelationService.save(reqContext, party.getId(), createReq, false);

				this.insertRelationParties(reqContext, sourceCode, party.getId(), partyRelation.getId(), partyCache, rel.getParties());
			});
		});
	}

	private void insertRelationParties(ReqContext reqContext, String sourceCode, Long partyId, Long relationId,
			Map<String, PartyRes> partyCache, List<PartyRelationItemExternalDtoV1> relParties) {
		List<PartyRelationItemReq> partyRelationItemReqs = relParties.stream()
				.map(relParty -> {
					PartyRes partyRes = partyCache.computeIfAbsent(relParty.getPartyData().getCode(),
							code -> this.doUpsertParty(reqContext, sourceCode, relParty.getPartyData()));

					return PartyRelationsMapper.INSTANCE.relationItemExternalToCreateReq(relParty, partyRes.getId());
				}).distinct()
				.collect(Collectors.toList());

		partyRelationPartyService.insertAll(reqContext, partyId, relationId, partyRelationItemReqs, false);
	}

	private void doUpsertDocuments(ReqContext reqContext, Long partyId, List<InsertDocument> documents) {
		Map<String, List<InsertDocument>> documentsByDefCode = Optional.ofNullable(documents).stream()
				.flatMap(Collection::stream)
				.collect(Collectors.groupingBy(InsertDocument::getDefCode, Collectors.toList()));

		documentsByDefCode.forEach((defCode, docs) -> {
			documentManager.expireAll(reqContext, partyId, defCode, false);

			docs.forEach(doc -> documentManager.save(reqContext, partyId, defCode, doc, false));
		});
	}

	private PartyRes doUpsertParty(ReqContext reqContext, String sourceCode, PartyExternalDtoV1 externalParty) {
		// TODO manage same party from different source
		PartyRes partyRes = partyService.getPartyByCode(reqContext, externalParty.getCode()).orElse(null);

		if (null != partyRes) {
			aclService.canWrite(reqContext, partyRes.getId());

			PartyUpdateReq updateReq = PartyMapper.INSTANCE.externalToUpdateReq(externalParty, partyRes);

			return partyService.update(reqContext, partyRes.getId(), updateReq, sourceCode);
		} else {
			PartyCreateReq createReq = PartyMapper.INSTANCE.externalToCreateReq(externalParty);

			return partyService.insert(reqContext, createReq, sourceCode);
		}
	}

	private void validatePayload(PartyExternalReq req, ExternalSourceDtoV1 externalSourceDto) {
		try (ValidatorFactory validatorFactory = Validation.buildDefaultValidatorFactory()) {

			Validator validator = validatorFactory.getValidator();
			Set<ConstraintViolation<ExternalSourceDtoV1>> constraintViolations = validator.validate(externalSourceDto);

			if (!constraintViolations.isEmpty()) {
				throw new ConstraintViolationException(constraintViolations);
			}
		} catch (ConstraintViolationException cve) {
			throw new ExternalSourceException(ErrEnum.PAYLOAD_NOT_READEABLE,
					String.format("source '%s' returned a not valid payload: [%s]", req.getSourceCode(), cve.getLocalizedMessage()),
					cve);
		}
	}

}
