package com.abacogroup.partyregistry.resources.publicapis;

import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.partyregistry.api.v1.RelationRoleResponseV1;
import com.abacogroup.partyregistry.api.v1.req.RelationRoleSearchRequestV1;
import com.abacogroup.partyregistry.core.RelationRoleV1Service;
import com.abacogroup.partyregistry.resources.PublicResourceConstants;
import com.abacogroup.partyregistry.resources.req.ReqContext;
import io.dropwizard.auth.Auth;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.ws.rs.BeanParam;
import jakarta.ws.rs.DefaultValue;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.HeaderParam;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.MediaType;

@Path(PublicResourceConstants.API_V1_PUB + "/relation-types/{relationTypeCode}/roles")
@Produces(MediaType.APPLICATION_JSON)
@Tag(name = "relation roles", description = "Operations on relation roles")
public class RelationRolePublicResource {

	private final RelationRoleV1Service relationRoleService;

	public RelationRolePublicResource(RelationRoleV1Service relationRoleService) {
		this.relationRoleService = relationRoleService;
	}

	@Operation(summary = "List of relation roles", description = "Get list of relation roles filtered with criteria")
	@ApiResponses({
			@ApiResponse(responseCode = "200", description = "Successfully, returns a list of relation roles (sorted/filtered)",
					content = @Content(mediaType = "application/json", schema = @Schema(ref = "#/components/schemas/InfiniteListResultsRelationRoleResponseV1")))
	})
	@GET
	//@RolesAllowed("")
	public InfiniteListResults<RelationRoleResponseV1> search(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@PathParam("tenant") String tenantId,
			@Parameter(description = "Can be supplied to obtain the records that follows those obtained by a previous call") @QueryParam("nextKey") String nextKey,
			@Parameter(description = "the relation type CODE") @PathParam("relationTypeCode") String relationTypeCode,
			@BeanParam RelationRoleSearchRequestV1 searchRequest) {

		ReqContext reqContext = new ReqContext(user, lang);
		return relationRoleService.search(reqContext, searchRequest, relationTypeCode, nextKey);
	}

	@Operation(summary = "Find relation role by code", description = "Returns relation role based on its Code")
	@ApiResponses({
			@ApiResponse(responseCode = "200", description = "Successfully, relation role is found",
					content = @Content(mediaType = "application/json", schema = @Schema(implementation = RelationRoleResponseV1.class)))
	})
	@GET
	//@RolesAllowed("")
	@Path("/{code}")
	public RelationRoleResponseV1 getByCode(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "the tenant ID") @PathParam("tenant") String tenantId,

			@Parameter(description = "the relation type CODE") @PathParam("relationTypeCode") String relationTypeCode,
			@PathParam("code") String code) {
		ReqContext reqContext = new ReqContext(user, lang);
		return this.relationRoleService.getByCodeAndType(reqContext, relationTypeCode, code)
				.orElse(null);
	}

}
