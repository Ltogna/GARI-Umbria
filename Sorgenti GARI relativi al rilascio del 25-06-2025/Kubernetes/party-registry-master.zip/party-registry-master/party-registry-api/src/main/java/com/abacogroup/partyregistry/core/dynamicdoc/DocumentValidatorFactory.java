package com.abacogroup.partyregistry.core.dynamicdoc;

import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

public class DocumentValidatorFactory {

	public Map<String, DocumentValidator> validators;

	public DocumentValidatorFactory(List<DocumentValidator> list) {
		this.initValidators(list);
	}

	private void initValidators(List<DocumentValidator> list) {
		validators = list.stream().collect(Collectors.toMap(DocumentValidator::getDefinitionCode, v -> v));
	}

	public Optional<DocumentValidator> getValidator(String definitionCode) {
		return Optional.ofNullable(validators.get(definitionCode));
	}

}
