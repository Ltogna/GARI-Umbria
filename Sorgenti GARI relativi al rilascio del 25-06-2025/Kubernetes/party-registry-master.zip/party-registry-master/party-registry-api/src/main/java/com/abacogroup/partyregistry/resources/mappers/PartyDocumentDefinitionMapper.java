package com.abacogroup.partyregistry.resources.mappers;

import com.abacogroup.dynamicdocuments.bean.DocumentDefinition;
import com.abacogroup.partyregistry.api.PartyDocumentDefinition;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper
public interface PartyDocumentDefinitionMapper {

	PartyDocumentDefinitionMapper INSTANCE = Mappers.getMapper(PartyDocumentDefinitionMapper.class);

	PartyDocumentDefinition toPartyDocumentDefinition(DocumentDefinition dd);

}
