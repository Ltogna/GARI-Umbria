package com.abacogroup.partyregistry.core;

import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.partyregistry.api.RoleCountDTO;
import com.abacogroup.partyregistry.resources.req.ReqContext;

import java.util.List;

public interface PartyChecksService {

	List<RoleCountDTO> countPartyRelationRoles(ReqContext reqContext, String partyCode, List<String> roleCodeList,
											   String relationType, AbsoluteDate referenceDate);

}
