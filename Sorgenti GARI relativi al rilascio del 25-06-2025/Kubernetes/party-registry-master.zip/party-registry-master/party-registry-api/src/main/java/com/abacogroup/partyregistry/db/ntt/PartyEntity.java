package com.abacogroup.partyregistry.db.ntt;

import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.jdbi.model.AuditEntity;
import com.abacogroup.partyregistry.api.GenderEnum;
import com.abacogroup.partyregistry.api.PartyTypeEnum;
import java.time.LocalDateTime;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder(setterPrefix = "set")
@NoArgsConstructor
public class PartyEntity implements MultiTenantEntity<String>, AuditEntity {

	private Long id;
	private String tenantId;
	private Long pkid;
	private PartyTypeEnum partyType;
	private GenderEnum gender;
	private String lastName;
	private String firstName;
	private String taxCode;
	private String vatNumber;
	private String code;
	private String legalStatus;

	private AbsoluteDate birthDate;
	private AbsoluteDate deathDate;

	private String birthMunicipality;
	private String nationality;

	private Long fkAddressResidential;
	private Long fkAddressHome;
	private Long fkAddressBilling;

	private Address addressResidential;
	private Address addressHome;
	private Address addressBilling;

	private int flArchived;

	private String sourceCode;

	private LocalDateTime dtInsert;
	private String userIdInsert;
	private LocalDateTime dtDelete;
	private String userIdDelete;

}
