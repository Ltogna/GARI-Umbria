package com.abacogroup.partyregistry.core.impl;

import java.lang.reflect.Field;
import java.util.Optional;

import com.abacogroup.dropwizard.auth.sso2.Sso2Client;
import com.abacogroup.dropwizard.auth.sso2.UserFunction;
import com.abacogroup.partyregistry.core.AclService;
import com.abacogroup.partyregistry.core.exceptions.ErrCodes;
import com.abacogroup.partyregistry.db.dao.PartyDAO;
import com.abacogroup.partyregistry.db.ntt.PartyEntity;
import com.abacogroup.partyregistry.resources.req.ReqContext;
import com.abacogroup.proxies.cache.core.exception.ResourceNotAuthorizedException;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class AclServiceImpl implements AclService {
	
	static final String CONTEXT_ID_PARTY_REGISTRY = "PARTY-REGISTRY";
	static final String FUNCTION_IGNORE_PARTIES_ACL = "IGNORE_PARTIES_ACL";
	
	private final PartyDAO partyDAO;
	private final Sso2Client sso2Client;
	private final boolean disableAcl;

	public AclServiceImpl(PartyDAO partyDAO, Sso2Client sso2Client, boolean disableAcl) {
		this.partyDAO = partyDAO;
		this.sso2Client = sso2Client;
		this.disableAcl = disableAcl;

		log.info("acl enabled: {}", !disableAcl);
	}


	@Override
	public boolean ignoreACL(ReqContext reqContext) {
		if (disableAcl) {
			return true;
		}
		
		return userHaveIgnoreACLFunction(reqContext);
	}
	
	@Override
	public void canWrite(ReqContext reqContext, Long partyId) {
		if (disableAcl) {
			return;
		}
		
		if(userHaveIgnoreACLFunction(reqContext)) {
			return;
		}
		
		this.isAuthorized(reqContext, partyId, MANAGE_FULL); // default must have manage
	}

	@Override
	public void canRead(ReqContext reqContext, Long partyId, boolean skipIfIgnoreACL) {
		
		if (disableAcl) {
			return;
		}
		
		if(skipIfIgnoreACL && userHaveIgnoreACLFunction(reqContext)) {
			return;
		}
		
		this.isAuthorized(reqContext, partyId, MANAGE_READ); // default must have manage
	}
		
	@Override
	public void canAdd(ReqContext reqContext) {
		
		if (disableAcl) {
			return;
		}
		
		if(partyDAO.hasStarMandate(reqContext)) {
			return;
		}
		
		if(!userHaveIgnoreACLFunction(reqContext)) {
			log.debug("user does not have function {}", CONTEXT_ID_PARTY_REGISTRY + "|" + FUNCTION_IGNORE_PARTIES_ACL);
			throw new ResourceNotAuthorizedException(ErrCodes.ACL_USER_NOT_AUTHORIZED, "not authorized");
		}
	}
		
	@Override
	public void isAuthorized(ReqContext reqContext, Long partyId, Integer withManage) {
		if (disableAcl) {
			return;
		}
		
		Optional<PartyEntity> party = partyDAO.loadOneByIdAndTenantId(reqContext.getTenantId(), partyId);
		if (party.isPresent()) {
			
			if(partyDAO.hasStarMandate(reqContext)) {
				return;
			}
			
			boolean isAuth = partyDAO.isAuthorized(reqContext, partyId, withManage); 
			if (!isAuth) {
				throw new ResourceNotAuthorizedException(ErrCodes.ACL_USER_NOT_AUTHORIZED, "not authorized");
			}
		} else {
			log.debug("party {} not found", partyId);
		}
	}

	@Override
	public void isAuthorized(ReqContext reqContext, Object party, Integer withManage) {
		this.isAuthorized(reqContext, party, "id", withManage);
	}

	@Override
	public void isAuthorized(ReqContext reqContext, Object party, String idFieldName, Integer withManage) {
		if (disableAcl) {
			return;
		}
		
		if(partyDAO.hasStarMandate(reqContext)) {
			return;
		}

		if (null == party) {
			log.debug("party null");
			return;
		}

		Long partyId = null;
		try {
			Field idField = party.getClass().getDeclaredField(idFieldName);
			idField.setAccessible(true);

			partyId = (Long) idField.get(party);
		} catch (NoSuchFieldException | IllegalAccessException e) {
			log.error("cannot extract partyId: {}", e.getMessage(), e);
		}

		if (null == partyId) {
			log.warn("party without id!");
			return;
		}

		boolean isAuth = partyDAO.isAuthorized(reqContext, partyId, withManage); 
		if (!isAuth) {
			throw new ResourceNotAuthorizedException(ErrCodes.ACL_USER_NOT_AUTHORIZED, "not authorized");
		}
	}
	
	@Override
	public boolean hasMandates(ReqContext reqContext, Long partyId) {
		try {
			canRead(reqContext, partyId);
			return true;
		} catch (Exception e) {
			return false;
		}
	}

	private boolean userHaveIgnoreACLFunction(ReqContext reqContext) {
		return (sso2Client != null && sso2Client.isFunctionEnabled(reqContext.getUser(), new UserFunction(CONTEXT_ID_PARTY_REGISTRY, FUNCTION_IGNORE_PARTIES_ACL)));
	}
}
