package com.abacogroup.partyregistry.bundle.config;

import static com.abacogroup.partyregistry.core.BundleConstants.DOMAIN_APP_CONFIG;

import com.abacogroup.bundles.initializer.impl.exceptions.BundleException;
import com.abacogroup.bundles.listener.configdata.ConfigDataMessage;
import com.abacogroup.bundles.listener.configdata.ConfigMessageProcessor;
import com.abacogroup.partyregistry.bundle.utils.FileOperationEnum;
import com.abacogroup.partyregistry.core.BundleConstants;
import com.abacogroup.partyregistry.core.impl.AuditHelper;
import com.abacogroup.partyregistry.db.dao.AppConfigDAO;
import com.abacogroup.partyregistry.db.ntt.AppConfigEntity;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.jayway.jsonpath.JsonPath;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Function;
import java.util.stream.Collectors;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

@Slf4j
public class AppConfigMessageProcessor implements ConfigMessageProcessor {

	private final AppConfigDAO appConfigDAO;
	private final ObjectMapper mapper;
	private final AppConfigFormatValidator configFormatValidator;

	public AppConfigMessageProcessor(AppConfigDAO appConfigDAO) {
		this.appConfigDAO = appConfigDAO;

		this.mapper = new ObjectMapper();
		this.configFormatValidator = new AppConfigFormatValidator(this.mapper);
	}

	@Override
	public String getDomainName() {
		return DOMAIN_APP_CONFIG;
	}

	@Override
	public void onMessage(ConfigDataMessage message) {
		String tenantId = message.getTenantId();

		Function<String, FileOperationEnum> groupingPredicate = x -> {
			if (StringUtils.containsIgnoreCase(x, "delete")) {
				return FileOperationEnum.DELETE;
			} else {
				return FileOperationEnum.DEFAULT;
			}
		};

		List<Path> paths = message.getConfigFiles();
		var map = paths.stream()
				.collect(Collectors.groupingBy(x -> groupingPredicate.apply(x.toString()),
						Collectors.toCollection(ArrayList::new)));

		map.getOrDefault(FileOperationEnum.DELETE, new ArrayList<>()).forEach(path -> removeContent(tenantId, path));
		map.getOrDefault(FileOperationEnum.DEFAULT, new ArrayList<>()).forEach(path -> addContent(tenantId, path));
	}

	private void removeContent(String tenantId, Path path) {
		try {
			String jsonContent = Files.readString(path);
			List<String> keys = JsonPath.parse(jsonContent).read("$[*].configurationKey");
			AuditHelper.expire(new AppConfigEntity(), BundleConstants.SYSTEM_USER,
					a -> appConfigDAO.expireRowsByKey(a, tenantId, keys),
					appConfigDAO.getCurrentTimestamp());
		} catch (IOException e) {
			throw new BundleException(String.format("error reading %s", path), e);
		}
	}

	private void addContent(String tenantId, Path path) {
		try {
			String jsonContent = Files.readString(path);

			List<String> keys = JsonPath.parse(jsonContent).read("$[*].configurationKey");
			AuditHelper.expire(new AppConfigEntity(), BundleConstants.SYSTEM_USER,
					a -> appConfigDAO.expireRowsByKey(a, tenantId, keys),
					appConfigDAO.getCurrentTimestamp());

			AppConfigEntity[] entities = mapEntities(tenantId, jsonContent);
			AuditHelper.setAuditForInsert(BundleConstants.SYSTEM_USER, appConfigDAO, entities);
			appConfigDAO.insertIdempotent(entities);

		} catch (IOException e) {
			throw new BundleException(String.format("error reading %s", path), e);
		}
	}

	private AppConfigEntity[] mapEntities(String tenantId, String jsonContent) {
		try {
			List<AppConfigMixin> list = mapper.readValue(jsonContent, new TypeReference<List<AppConfigMixin>>() {
			});

			List<AppConfigEntity> entities = new ArrayList<>();
			for (AppConfigMixin x : list) {

				configFormatValidator.validate(x);

				entities.add(AppConfigEntity.builder()
						.setTenantId(tenantId)
						.setConfigurationKey(x.getConfigurationKey())
						.setConfiguration(x.getConfigurationAsString())
						.build());
			}

			return entities.toArray(AppConfigEntity[]::new);
		} catch (BundleException be) {
			throw be;
		} catch (Exception e) {
			throw new BundleException("error in deserialization json ", e);
		}
	}

	@Data
	public static class AppConfigMixin {
		@JsonProperty("configurationKey")
		private String configurationKey;

		@JsonProperty("configuration")
		private JsonNode configuration;

		String getConfigurationAsString() {
			if (configuration.isEmpty() || configuration.isNull()) {
				return null;
			}
			return configuration.toString();
		}
	}

}
