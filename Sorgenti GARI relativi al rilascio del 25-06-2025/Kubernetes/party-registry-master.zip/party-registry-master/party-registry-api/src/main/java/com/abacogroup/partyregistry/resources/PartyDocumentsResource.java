package com.abacogroup.partyregistry.resources;

import java.util.Optional;

import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.dynamicdocuments.bean.Document;
import com.abacogroup.dynamicdocuments.bean.InsertDocument;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.partyregistry.api.PartyDocument;
import com.abacogroup.partyregistry.api.PartyDocumentDefinition;
import com.abacogroup.partyregistry.core.AclService;
import com.abacogroup.partyregistry.core.dynamicdoc.PartyDynamicDocumentManager;
import com.abacogroup.partyregistry.core.exceptions.InvalidDocumentException;
import com.abacogroup.partyregistry.core.exceptions.InvalidPartyException;
import com.abacogroup.partyregistry.resources.req.DocumentSearchReq;
import com.abacogroup.partyregistry.resources.req.ReqContext;

import io.dropwizard.auth.Auth;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.annotation.security.RolesAllowed;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import jakarta.ws.rs.BeanParam;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.DefaultValue;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.HEAD;
import jakarta.ws.rs.HeaderParam;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Path(ResourceConstants.API_PRIV + "/parties/{partyId}/documents/type/{definitionCode}")
@Produces(MediaType.APPLICATION_JSON)
@Tag(name = "party documents by type", description = "Operations on party documents")
public class PartyDocumentsResource {
	
	private static final boolean SKIP_ACL_IF_CAN_IGNORE = true;

	private final AclService aclService;

	private final PartyDynamicDocumentManager partyDynamicDocumentManager;

	public PartyDocumentsResource(AclService aclService, PartyDynamicDocumentManager partyDynamicDocumentManager) {
		this.aclService = aclService;
		this.partyDynamicDocumentManager = partyDynamicDocumentManager;
	}

	@Operation(summary = "List of documents of a specific type", description = "Get list of documents filtered with criteria")
	@ApiResponses({
			@ApiResponse(responseCode = "200", description = "Successfully, returns a list of documents (sorted/filtered)",
					content = @Content(mediaType = "application/json", schema = @Schema(ref = "#/components/schemas/InfiniteListResultsPartyDocument"))),
	})
	@GET
	@RolesAllowed("PARTY-REGISTRY|READ")
	public InfiniteListResults<PartyDocument> search(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@PathParam("tenant") String tenantId,
			@Parameter(description = "Can be supplied to obtain the records that follows those obtained by a previous call") @QueryParam("nextKey") String nextKey,
			@BeanParam DocumentSearchReq searchRequest) {

		ReqContext reqContext = new ReqContext(user, lang);
		aclService.canRead(reqContext, searchRequest.getPartyId(), SKIP_ACL_IF_CAN_IGNORE);
		return partyDynamicDocumentManager.searchByDocType(reqContext, searchRequest, nextKey);
	}

	@Operation(summary = "document definition", description = "Get document definition by its code")
	@ApiResponses({
			@ApiResponse(responseCode = "200", description = "Successfully, returns a document definition", useReturnTypeSchema = true),
	})
	@GET
	@RolesAllowed("PARTY-REGISTRY|READ")
	@Path("/definition")
	public PartyDocumentDefinition getDefinition(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@PathParam("tenant") String tenantId,
			@Parameter(description = "the party ID") @PathParam("partyId") Long partyId,
			@PathParam("definitionCode") String definitionCode) {

		ReqContext reqContext = new ReqContext(user, lang);
		aclService.canRead(reqContext, partyId, SKIP_ACL_IF_CAN_IGNORE);
		return partyDynamicDocumentManager.getDefinition(reqContext, definitionCode);
	}

	@Operation(summary = "Find document by code and id", description = "Returns document based on its definition code and document id")
	@ApiResponses({
			@ApiResponse(responseCode = "200", description = "Document successfully found",
					content = @Content(mediaType = "application/json", schema = @Schema(implementation = PartyDocument.class))),
			@ApiResponse(responseCode = "400", description = "The document does not exist",
					content = @Content(schema = @Schema(implementation = InvalidDocumentException.ErrorBody.class)))
	})
	@GET
	@RolesAllowed("PARTY-REGISTRY|READ")
	@Path("/{documentId}")
	public PartyDocument getByDocumentId(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@PathParam("tenant") String tenantId,
			@PathParam("partyId") Long partyId,
			@PathParam("definitionCode") String definitionCode,
			@PathParam("documentId") Long documentId) {
		ReqContext reqContext = new ReqContext(user, lang);
		aclService.canRead(reqContext, partyId, SKIP_ACL_IF_CAN_IGNORE);
		return Optional.of(this.partyDynamicDocumentManager.getByDocumentIdAndCode(reqContext, documentId, definitionCode)).orElse(null);
	}

	@Operation(summary = "get document attachment content", description = "Returns document attachment content")
	@ApiResponses({
			@ApiResponse(responseCode = "200", description = "The file bytes",
					content = @Content(mediaType = MediaType.APPLICATION_OCTET_STREAM, schema = @Schema(type = "string", format = "binary"))),
			@ApiResponse(responseCode = "400", description = "The document does not exist",
					content = @Content(schema = @Schema(implementation = InvalidDocumentException.ErrorBody.class)))
	})
	@GET
	@RolesAllowed("PARTY-REGISTRY|READ")
	@Path("/{documentId}/attachments/{bucket}/{fileId}")
	public Response getDocumentFileContent(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@PathParam("tenant") String tenantId,
			@PathParam("partyId") Long partyId,
			@PathParam("definitionCode") String definitionCode,
			@PathParam("documentId") Long documentId,
			@PathParam("bucket") String bucket,
			@PathParam("fileId") String fileId) {
		ReqContext reqContext = new ReqContext(user, lang);
		aclService.canRead(reqContext, partyId, SKIP_ACL_IF_CAN_IGNORE);
		return partyDynamicDocumentManager.getDocumentFileContent(reqContext, partyId, documentId, fileId);
	}

	@Operation(summary = "get document attachment metadata", description = "Returns document attachment metadata in header")
	@ApiResponses({
			@ApiResponse(responseCode = "200", description = "The file metadata in header"),
			@ApiResponse(responseCode = "400", description = "The document does not exist",
					content = @Content(schema = @Schema(implementation = InvalidDocumentException.ErrorBody.class)))
	})
	@HEAD
	@RolesAllowed("PARTY-REGISTRY|READ")
	@Path("/{documentId}/attachments/{bucket}/{fileId}")
	public Response getDocumentFileMetadata(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@PathParam("tenant") String tenantId,
			@PathParam("partyId") Long partyId,
			@PathParam("definitionCode") String definitionCode,
			@PathParam("documentId") Long documentId,
			@PathParam("bucket") String bucket,
			@PathParam("fileId") String fileId) {
		ReqContext reqContext = new ReqContext(user, lang);
		aclService.canRead(reqContext, partyId, SKIP_ACL_IF_CAN_IGNORE);
		return partyDynamicDocumentManager.getDocumentFileMetadata(reqContext, partyId, documentId, fileId);
	}

	@Operation(summary = "Create document", description = "Insert a new document")
	@ApiResponses({
			@ApiResponse(responseCode = "200", description = "Successfully, the document has been correctly created",
					content = @Content(mediaType = "application/json", schema = @Schema(implementation = PartyDocument.class))),
			@ApiResponse(responseCode = "400", description = "The requested party does not exist", content = @Content(schema = @Schema(implementation = InvalidPartyException.ErrorBody.class)))
	})
	@POST
	@RolesAllowed("PARTY-REGISTRY|WRITE")
	public PartyDocument insert(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@PathParam("tenant") String tenantId,
			@PathParam("partyId") Long partyId,
			@PathParam("definitionCode") String definitionCode,
			@NotNull @Valid InsertDocument document) {
		ReqContext reqContext = new ReqContext(user, lang);
		aclService.canWrite(reqContext, partyId);
		return partyDynamicDocumentManager.save(reqContext, partyId, definitionCode, document);
	}

	@Operation(summary = "update document", description = "update an existing document")
	@ApiResponses({
			@ApiResponse(responseCode = "200", description = "document updated",
					content = @Content(mediaType = "application/json", schema = @Schema(implementation = PartyDocument.class))),
			@ApiResponse(responseCode = "404", description = "document update error",
					content = @Content(mediaType = "application/json", schema = @Schema(anyOf = {
							InvalidDocumentException.ErrorBody.class,
							InvalidPartyException.ErrorBody.class
					})))
	})
	@PUT
	@RolesAllowed("PARTY-REGISTRY|WRITE")
	@Path("/{documentId}")
	public PartyDocument update(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@PathParam("tenant") String tenantId,
			@PathParam("partyId") Long partyId,
			@PathParam("definitionCode") String definitionCode,
			@PathParam("documentId") Long documentId,
			@NotNull @Valid Document updateReq) {
		ReqContext reqContext = new ReqContext(user, lang);
		aclService.canWrite(reqContext, partyId);
		return this.partyDynamicDocumentManager.update(reqContext, partyId, documentId, updateReq);
	}

	@Operation(summary = "delete document", description = "delete an existing document by expiring it")
	@ApiResponses({
			@ApiResponse(responseCode = "200", description = "document expired"),
			@ApiResponse(responseCode = "404", description = "document delete error",
					content = @Content(mediaType = "application/json", schema = @Schema(anyOf = {
							InvalidDocumentException.ErrorBody.class,
							InvalidPartyException.ErrorBody.class
					})))
	})
	@DELETE
	@RolesAllowed("PARTY-REGISTRY|DELETE")
	@Path("/{documentId}")
	public Response delete(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@PathParam("tenant") String tenantId,
			@PathParam("partyId") Long partyId,
			@PathParam("definitionCode") String definitionCode,
			@PathParam("documentId") Long documentId) {
		ReqContext reqContext = new ReqContext(user, lang);
		aclService.canWrite(reqContext, partyId);
		this.partyDynamicDocumentManager.expire(reqContext, partyId, documentId);
		return Response.ok().build();
	}
}
