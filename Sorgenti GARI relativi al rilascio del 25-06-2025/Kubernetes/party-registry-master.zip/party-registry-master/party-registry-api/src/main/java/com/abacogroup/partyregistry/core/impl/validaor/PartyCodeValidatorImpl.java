package com.abacogroup.partyregistry.core.impl.validaor;

import com.abacogroup.partyregistry.core.PartyFieldValidator;
import com.abacogroup.partyregistry.core.exceptions.ErrCodes;
import com.abacogroup.partyregistry.core.exceptions.InvalidPartyException;
import com.abacogroup.partyregistry.db.dao.PartyDAO;
import com.abacogroup.partyregistry.db.ntt.AppConfigEntity;
import com.abacogroup.partyregistry.db.ntt.PartyEntity;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.commons.lang3.StringUtils;

public class PartyCodeValidatorImpl implements PartyFieldValidator {

	public static final String CONFIG_KEY = "code";

	private final PartyDAO partyDAO;
	private final ObjectMapper objectMapper;

	public PartyCodeValidatorImpl(PartyDAO partyDAO, ObjectMapper objectMapper) {
		this.partyDAO = partyDAO;
		this.objectMapper = objectMapper;
	}

	@Override
	public String getFieldName() {
		return CONFIG_KEY;
	}

	@Override
	public void resetField(PartyEntity party) {
		party.setCode(null);
	}

	@Override
	public void validateOnInsert(PartyEntity entity, AppConfigEntity validationConfig) throws InvalidPartyException {
		PartyCodeConfiguration configuration = this.getConfiguration(validationConfig);
		entity.setCode(StringUtils.trimToNull(StringUtils.upperCase(entity.getCode())));

		doValidateCode(entity, configuration, validationConfig.getTenantId());

	}

	@Override
	public void validateOnUpdate(PartyEntity party, AppConfigEntity validationConfig) throws InvalidPartyException {
		PartyCodeConfiguration configuration = this.getConfiguration(validationConfig);
		party.setCode(StringUtils.trimToNull(StringUtils.upperCase(party.getCode())));

		if (!configuration.isEditable() && codeHasChanged(party, validationConfig.getTenantId())) {
			throw new InvalidPartyException(ErrCodes.INVALID_PAYLOAD, "CUAA cannot be modified");
		} else {
			this.doValidateCode(party, configuration, validationConfig.getTenantId());
		}

	}

	private boolean codeHasChanged(PartyEntity party, String tenantId) {
		String actualCode = partyDAO.findCodeById(tenantId, party.getId());
		return actualCode != null && !actualCode.equalsIgnoreCase(party.getCode());
	}

	private void doValidateCode(PartyEntity entity, PartyCodeConfiguration configuration, String tenantId) {
		if (StringUtils.isBlank(entity.getCode())) {
			if (configuration.isMandatory()) {
				throw new InvalidPartyException(ErrCodes.INVALID_PAYLOAD, "CODE is null");
			}
		} else {
			this.validateUniqueCode(tenantId, entity);
		}
	}

	private void validateUniqueCode(String tenantId, PartyEntity entity) {
		if (partyDAO.findByTenantAndCode(tenantId, entity.getCode())
				.filter(dbEntity -> !dbEntity.getId().equals(entity.getId()))
				.isPresent()) {
			throw new InvalidPartyException(ErrCodes.INVALID_PAYLOAD,
					String.format("CODE : %s is already present", entity.getCode()));
		}
	}

	private PartyCodeConfiguration getConfiguration(AppConfigEntity validationConfig) {
		try {
			return objectMapper.readValue(validationConfig.getConfiguration(), PartyCodeConfiguration.class);
		} catch (JsonProcessingException e) {
			throw new RuntimeException(e);
		}
	}
}
