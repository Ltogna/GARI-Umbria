package com.abacogroup.partyregistry.api;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

@Data
@NoArgsConstructor
@Accessors(chain = true)
public class PartyCheckResponse {

	private boolean isDuplicated;
}
