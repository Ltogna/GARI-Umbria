package com.abacogroup.partyregistry.resources.publicapis.mapper;

import com.abacogroup.partyregistry.api.LegalStatus;
import com.abacogroup.partyregistry.api.v1.LegalStatusResponseV1;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper
public interface LegalStatusResMapper {
	LegalStatusResMapper INSTANCE = Mappers.getMapper(LegalStatusResMapper.class);

	LegalStatusResponseV1 toV1(LegalStatus res);
}
