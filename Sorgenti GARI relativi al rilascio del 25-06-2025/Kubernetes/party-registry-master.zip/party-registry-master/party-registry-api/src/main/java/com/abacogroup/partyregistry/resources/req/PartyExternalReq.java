package com.abacogroup.partyregistry.resources.req;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder(setterPrefix = "set")
@NoArgsConstructor
@Accessors(chain = true)
public class PartyExternalReq {

	@NotBlank
	private String partyCode;

	@NotBlank
	private String sourceCode;

}
