package com.abacogroup.partyregistry.bundle.tenant;

import static com.abacogroup.bundles.Constants.ALL_TENANTS;

import com.abacogroup.bundles.initializer.impl.exceptions.BundleException;
import com.abacogroup.bundles.listener.tenant.TenantMessage;
import com.abacogroup.bundles.listener.tenant.TenantMessageProcessor;
import com.abacogroup.dynamicdocuments.bean.DocumentDefinition;
import com.abacogroup.dynamicdocuments.services.DocumentTypeService;
import com.abacogroup.partyregistry.core.BundleConstants;
import com.abacogroup.partyregistry.core.impl.AuditHelper;
import com.abacogroup.partyregistry.db.dao.DocTypeDAO;
import com.abacogroup.partyregistry.db.ntt.DocTypeEntity;
import com.fasterxml.jackson.core.JsonProcessingException;
import java.io.IOException;
import java.util.Optional;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class DynamicDocTenantMessageProcessor implements TenantMessageProcessor {

	private final DocTypeDAO docTypeDAO;

	private final DocumentTypeService documentTypeService;

	public DynamicDocTenantMessageProcessor(DocTypeDAO docTypeDAO, DocumentTypeService documentTypeService) {
		this.docTypeDAO = docTypeDAO;
		this.documentTypeService = documentTypeService;
	}

	@Override
	public void onMessage(TenantMessage message) {
		String tenantId = message.getTenantId();

		int actualCount = docTypeDAO.findAll(tenantId).size();
		if (actualCount > 0L) {
			log.warn("docTypes already present for tenant {}", tenantId);
			return;
		} else {
			DocTypeEntity entity = new DocTypeEntity();
			entity.setTenantId(ALL_TENANTS);
			AuditHelper.setAuditForInsert(BundleConstants.SYSTEM_USER, docTypeDAO, entity);
			docTypeDAO.insertNewTenant(ALL_TENANTS, tenantId, entity);
			docTypeDAO.insertRelationsNewTenant(ALL_TENANTS, tenantId, entity);
			docTypeDAO.insertTagRelationsNewTenant(ALL_TENANTS, tenantId, entity);

			documentTypeService.getDocumentDefinitionCodes(ALL_TENANTS)
					.forEach(typeCode -> storeDocDefinition(tenantId, typeCode));

		}
	}

	private void storeDocDefinition(String tenantId, String typeCode) {
		try {
			Optional<DocumentDefinition> documentDefinition =
					documentTypeService.getDocumentDefinition(ALL_TENANTS, typeCode);
			if (documentDefinition.isPresent()) {
				documentTypeService.saveDocumentType(tenantId, documentDefinition.get(), BundleConstants.SYSTEM_USER);
			}

		} catch (JsonProcessingException e) {
			throw new BundleException("error in doc serialization", e);
		} catch (IOException e) {
			throw new BundleException("error saving doctype", e);
		}
	}

}
