package com.abacogroup.partyregistry.core.dynamicdoc;

import com.abacogroup.dynamicdocuments.bean.InsertDocument;
import com.abacogroup.partyregistry.resources.req.ReqContext;

public interface DocumentValidator {

	void validate(InsertDocument document,
			PartyDynamicDocumentManager documentManager,
			ReqContext reqContext);

	String getDefinitionCode();

}
