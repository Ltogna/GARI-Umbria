package com.abacogroup.partyregistry.resources.req;

import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.partyregistry.api.GenderEnum;
import com.abacogroup.partyregistry.api.PartyTypeEnum;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import java.util.List;
import lombok.Builder.Default;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;
import lombok.experimental.FieldNameConstants;
import lombok.experimental.SuperBuilder;

@FieldNameConstants
@Data
@SuperBuilder(setterPrefix = "set")
@NoArgsConstructor
@Accessors(chain = true)
public class PartyUpdateReq {

	@NotNull
	private PartyTypeEnum partyType;
	private GenderEnum gender;

	@NotEmpty
	private String lastName;
	private String firstName;

	private String taxCode;
	private String vatNumber;

	private String code;
	private String legalStatus;


	private AbsoluteDate birthDate;
	private AbsoluteDate deathDate;

	private String birthMunicipality;
	@Size(max = 3)
	private String nationality;

	private AddressReq addressResidential;
	private AddressReq addressHome;
	private AddressReq addressBilling;

	private List<String> tags;

	@Default
	private boolean archived = false;
}
