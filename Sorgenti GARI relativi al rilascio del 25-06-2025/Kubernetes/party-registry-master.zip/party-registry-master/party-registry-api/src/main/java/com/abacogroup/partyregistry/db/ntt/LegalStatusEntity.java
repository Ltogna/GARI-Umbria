package com.abacogroup.partyregistry.db.ntt;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder(setterPrefix = "set")
@NoArgsConstructor
public class LegalStatusEntity implements MultiTenantEntity<String> {

	private String tenantId;
	private String code;

}
