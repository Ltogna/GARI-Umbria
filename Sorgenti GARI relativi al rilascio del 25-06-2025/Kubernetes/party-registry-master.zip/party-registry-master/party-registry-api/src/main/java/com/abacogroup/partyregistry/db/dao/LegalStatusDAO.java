package com.abacogroup.partyregistry.db.dao;

import com.abacogroup.jdbi.EnhancedSqlObject;
import com.abacogroup.jdbi.criteria.BindCriteria;
import com.abacogroup.jdbi.criteria.Criteria;
import com.abacogroup.jdbi.orderby.DefineOrder;
import com.abacogroup.jdbi.orderby.OrderBy;
import com.abacogroup.partyregistry.api.LegalStatus;
import com.abacogroup.partyregistry.db.ntt.LegalStatusEntity;
import com.abacogroup.partyregistry.resources.req.ReqContext;
import org.jdbi.v3.core.result.ResultIterator;
import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.customizer.BindBean;
import org.jdbi.v3.sqlobject.statement.SqlBatch;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;
import org.jdbi.v3.sqlobject.transaction.Transactional;
import java.util.List;
import java.util.Optional;


public interface LegalStatusDAO extends Transactional<LegalStatusDAO>, EnhancedSqlObject, Auditable {

	String FIELDS = " tenant_id, code ";
	String BASE_SELECT = "select " + FIELDS + " FROM prt_legal_status ";
	String WHERE_TENANT_ID_AND_CODE = " where tenant_id = :tenantId and code = :code ";
	String I18NRelType = ", coalesce (§i18n(:tenantId, 'prt_legal_status', 'code', code, :lang)§, code) as i18n_code\n ";

	@SqlQuery(BASE_SELECT + WHERE_TENANT_ID_AND_CODE)
	@RegisterBeanMapper(LegalStatusEntity.class)
	Optional<LegalStatusEntity> findOne(
			@Bind("tenantId") String tenantId,
			@Bind("code") String code);

	@SqlQuery(BASE_SELECT + " where tenant_id = :tenantId")
	@RegisterBeanMapper(LegalStatusEntity.class)
	List<LegalStatusEntity> findAll(
			@Bind("tenantId") String tenantId);

	@SqlQuery("select * from ("
			+ "SELECT "
			+ FIELDS + I18NRelType + " FROM prt_legal_status where tenant_id = :tenantId ) inner_result "
			+ "where <criteria> "
			+ "ORDER BY <orderBy>")
	@RegisterBeanMapper(LegalStatus.class)
	ResultIterator<LegalStatus> searchAll(
			@BindCriteria Criteria criteria,
			@DefineOrder OrderBy orderBy,
			@BindBean ReqContext ctx);

	@SqlQuery("SELECT " + FIELDS + I18NRelType + "FROM prt_legal_status \n"
			+ WHERE_TENANT_ID_AND_CODE)
	@RegisterBeanMapper(LegalStatus.class)
	Optional<LegalStatus> searchByCode(
			@Bind("code") String code,
			@BindBean ReqContext ctx);

	@SqlQuery("select count(*) FROM prt_legal_status where tenant_id = :tenantId ")
	Long countAll(@Bind("tenantId") String tenantId);

	@SqlUpdate("INSERT INTO prt_legal_status (tenant_id, code) VALUES (:tenantId, :code) ")
	void insert(@BindBean LegalStatusEntity entity);

	@SqlBatch("insert into prt_legal_status (tenant_id, code) "
			+ "§select_from_dual(:tenantId, :code)§ "
			+ "where not exists (select code from prt_legal_status where tenant_id = :tenantId and code = :code )")
	void insertIdempotent(@BindBean LegalStatusEntity... entity);

	@SqlUpdate("INSERT INTO prt_legal_status (tenant_id, code) " +
			" select :newTenantId as tenant_id, code " +
			" FROM prt_legal_status  where tenant_id = :sourceTenant ")
	void insertNewTenant(@Bind("sourceTenant") String sourceTenant,
						 @Bind("newTenantId") String newTenantId);

	@SqlUpdate("delete from prt_legal_status where tenant_id = :tenantId AND code = :code " +
			" AND code NOT IN (SELECT distinct(d.legal_status) FROM prt_parties_detail d inner join prt_parties p on p.id = d.party_id where p.tenant_id = :tenantId and legal_status = :code )")
	int deleteUnused(@Bind("tenantId") String tenantId, @Bind("code") String code);
}


