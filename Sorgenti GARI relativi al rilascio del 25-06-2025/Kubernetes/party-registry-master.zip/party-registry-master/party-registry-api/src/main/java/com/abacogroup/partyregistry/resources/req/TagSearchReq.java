package com.abacogroup.partyregistry.resources.req;

import com.abacogroup.jdbi.criteria.Criteria;
import com.abacogroup.jdbi.criteria.CriteriaBuilder;
import com.abacogroup.jdbi.orderby.OrderByBuilder;
import com.abacogroup.jdbi.orderby.OrderByElement;
import com.abacogroup.jdbi.orderby.SortDirection;
import com.abacogroup.partyregistry.resources.ResourceConstants;
import com.fasterxml.jackson.annotation.JsonIgnore;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.ws.rs.QueryParam;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.function.Function;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;
import org.apache.commons.lang3.StringUtils;

@Data
@NoArgsConstructor
@Accessors(chain = true)
public class TagSearchReq implements BaseSearchReq {

	@Parameter(in = ParameterIn.QUERY, description = "tag ID")
	@QueryParam("id")
	private Long id;

	@Parameter(in = ParameterIn.QUERY, description = "tag code")
	@QueryParam("code")
	private String code;

	@Parameter(in = ParameterIn.QUERY, description = "tag code i18n")
	@QueryParam("i18nCode")
	private String i18nCode;

	@Override
	@JsonIgnore
	@Schema(hidden = true)
	public int getPageSize() {
		return ResourceConstants.PAGE_SIZE;
	}

	@Override
	public Criteria getCriteria(ReqContext ctx) {
		Function<Long, Criteria> BY_ID = v -> CriteriaBuilder.number("id").eq(v);
		Function<String, Criteria> BY_TAG_CODE = v -> CriteriaBuilder.string("tag_code").eq(v);

		List<Criteria> specs = new ArrayList<>();

		Optional.ofNullable(this.getId())
				.ifPresent(v -> specs.add(BY_ID.apply(v)));

		Optional.ofNullable(this.getCode())
				.ifPresent(v -> specs.add(BY_TAG_CODE.apply(v.toUpperCase())));

		Optional.ofNullable(this.getI18nCode())
				.filter(StringUtils::isNotBlank)
				.ifPresent(v -> specs.add(CriteriaBuilder.string("i18n_code").caseInsensitiveContains(v)));

		return CriteriaBuilder.and(specs.toArray(new Criteria[0]));
	}

	@Override
	public OrderByElement getSort() {
		return OrderByBuilder.field("i18n_code").direction(SortDirection.ASC);
	}

}
