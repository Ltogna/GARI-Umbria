package com.abacogroup.partyregistry.core.impl;

import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.partyregistry.api.v1.LegalStatusResponseV1;
import com.abacogroup.partyregistry.api.v1.req.LegalStatusSearchRequestV1;
import com.abacogroup.partyregistry.core.LegalStatusService;
import com.abacogroup.partyregistry.core.LegalStatusV1Service;
import com.abacogroup.partyregistry.resources.publicapis.mapper.LegalStatusResMapper;
import com.abacogroup.partyregistry.resources.publicapis.mapper.LegalStatusSearchReqMapper;
import com.abacogroup.partyregistry.resources.req.LegalStatusSearchReq;
import com.abacogroup.partyregistry.resources.req.ReqContext;
import java.util.Optional;

public class LegalStatusV1ServiceImpl implements LegalStatusV1Service {

	private final LegalStatusService legalStatusService;

	public LegalStatusV1ServiceImpl(LegalStatusService legalStatusService) {
		this.legalStatusService = legalStatusService;
	}

	@Override
	public InfiniteListResults<LegalStatusResponseV1> search(ReqContext reqContext, LegalStatusSearchRequestV1 searchRequest, String nextKey) {
		LegalStatusSearchReq req = LegalStatusSearchReqMapper.INSTANCE.fromV1(searchRequest);
		return legalStatusService.search(reqContext, req, nextKey).map(LegalStatusResMapper.INSTANCE::toV1);
	}

	@Override
	public Optional<LegalStatusResponseV1> getByCode(ReqContext reqContext, String code) {
		return legalStatusService.getByCode(reqContext, code).map(LegalStatusResMapper.INSTANCE::toV1);
	}
}
