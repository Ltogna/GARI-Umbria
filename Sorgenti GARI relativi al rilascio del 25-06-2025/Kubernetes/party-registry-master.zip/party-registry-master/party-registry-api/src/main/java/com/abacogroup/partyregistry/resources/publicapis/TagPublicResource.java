package com.abacogroup.partyregistry.resources.publicapis;

import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.partyregistry.api.v1.TagResponseV1;
import com.abacogroup.partyregistry.api.v1.req.TagSearchRequestV1;
import com.abacogroup.partyregistry.core.TagV1Service;
import com.abacogroup.partyregistry.resources.PublicResourceConstants;
import com.abacogroup.partyregistry.resources.req.ReqContext;
import io.dropwizard.auth.Auth;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import jakarta.ws.rs.BeanParam;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DefaultValue;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.HeaderParam;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.MediaType;
import java.util.List;

@SuppressWarnings("UnresolvedRestParam")
@Path(PublicResourceConstants.API_V1_PUB + "/tags")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
@io.swagger.v3.oas.annotations.tags.Tag(name = "tags", description = "Operations on tags")
public class TagPublicResource {

	private final TagV1Service tagService;

	public TagPublicResource(TagV1Service tagService) {
		this.tagService = tagService;
	}

	@Operation(summary = "List of tags", description = "Get list of tags filtered with criteria")
	@ApiResponses({
			@ApiResponse(responseCode = "200", description = "Successfully, returns a list of tags (sorted/filtered)",
					content = @Content(mediaType = "application/json", schema = @Schema(ref = "#/components/schemas/InfiniteListResultsTagResponseV1")))
	})
	@GET
	//@RolesAllowed()
	public InfiniteListResults<TagResponseV1> search(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "tenant ID") @PathParam("tenant") String tenantId,
			@Parameter(description = "Can be supplied to obtain the records that follows those obtained by a previous call") @QueryParam("nextKey") String nextKey,
			@BeanParam TagSearchRequestV1 searchRequest) {
		ReqContext reqContext = new ReqContext(user, lang);
		return tagService.searchTags(reqContext, searchRequest, nextKey);
	}

	@Operation(summary = "List of tags", description = "Get list of tags filtered with criteria")
	@ApiResponses({
			@ApiResponse(responseCode = "200", description = "Successful, returns a list of tags (sorted/filtered)",
					content = @Content(mediaType = "application/json", array = @ArraySchema(
							schema = @Schema(implementation = TagResponseV1.class))))
	})
	@GET
	//@RolesAllowed()
	@Path("/list")
	public List<TagResponseV1> searchList(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "tenant ID") @PathParam("tenant") String tenantId,
			@BeanParam TagSearchRequestV1 searchRequest) {
		ReqContext reqContext = new ReqContext(user, lang);
		return tagService.searchTagList(reqContext, searchRequest);
	}

}
