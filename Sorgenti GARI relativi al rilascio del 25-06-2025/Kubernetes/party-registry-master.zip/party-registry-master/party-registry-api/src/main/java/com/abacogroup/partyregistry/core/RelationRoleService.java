package com.abacogroup.partyregistry.core;

import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.partyregistry.api.RelationRole;
import com.abacogroup.partyregistry.db.ntt.RelationRoleEntity;
import com.abacogroup.partyregistry.resources.req.RelationRoleSearchReq;
import com.abacogroup.partyregistry.resources.req.ReqContext;
import java.util.Optional;

public interface RelationRoleService {

	InfiniteListResults<RelationRole> search(ReqContext reqContext, RelationRoleSearchReq searchRequest, String nextKey);

	//  Optional<RelationRole> getById(Long id);

	Optional<RelationRole> getByCode(ReqContext reqContext, String code);

	Optional<RelationRole> getByCodeAndType(ReqContext reqContext, String typeCode, String code);

	/*RelationRole save(ReqContext context, RelationRoleReq relationRoleReq);

	//  void expire(String currentUser, Long id);

	void expire(ReqContext reqContext, String code);*/

	Optional<RelationRoleEntity> loadEntityActiveByCode(String tenantId, String code);

	Optional<RelationRoleEntity> loadEntityActiveByCode(String tenantId, Long typeId, String code);
}
