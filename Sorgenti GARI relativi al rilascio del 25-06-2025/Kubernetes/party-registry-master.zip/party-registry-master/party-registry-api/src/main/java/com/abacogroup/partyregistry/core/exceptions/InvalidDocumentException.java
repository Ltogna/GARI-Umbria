package com.abacogroup.partyregistry.core.exceptions;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
public class InvalidDocumentException extends AbstractPartyException {

	public InvalidDocumentException(String code, String message) {
		super(new InvalidDocumentException.ErrorBody(code, message));
	}

	@Schema(name = "InvalidDocumentExceptionErrorBody")
	public static class ErrorBody implements ExceptionErrorBody {
		private final String code;
		private final String message;

		public ErrorBody(String code, String message) {
			this.code = code;
			this.message = message;
		}

		@Override
		@Schema(allowableValues = { ErrCodes.DYNAMIC_DOCUMENT_ERR, ErrCodes.DYNAMIC_DOCUMENT_NOT_FOUND })
		public String getErrorCode() {
			return code;
		}

		@Override
		@Schema
		public String getMessage() {
			return message;
		}
	}

}
