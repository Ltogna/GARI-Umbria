package com.abacogroup.partyregistry.db.dao;

import com.abacogroup.jdbi.EnhancedSqlObject;
import com.abacogroup.partyregistry.api.PartyDocument;
import com.abacogroup.partyregistry.db.ntt.PartyDocumentEntity;
import com.abacogroup.partyregistry.resources.req.ReqContext;
import java.util.List;
import java.util.Optional;
import org.jdbi.v3.core.result.ResultIterator;
import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.customizer.BindBean;
import org.jdbi.v3.sqlobject.statement.GetGeneratedKeys;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;
import org.jdbi.v3.sqlobject.transaction.Transactional;

public interface PartyDocumentDAO extends Transactional<PartyDocumentDAO>, EnhancedSqlObject, Auditable {

	String FIELDS = " r.pkid, r.tenant_id, r.party_id, r.definition_code, r.document_id, r.dt_insert, r.user_id_insert, r.dt_delete, r.user_id_delete\n";

	String I18N = " ,\n coalesce (§i18n(:tenantId, 'prt_parties_documents', 'definition_code', definition_code, :lang)§, definition_code) as definitionCodei18n\n ";

	String CURRENT_RECORD = " AND (§current_timestamp§ between r.dt_insert and r.dt_delete) ";

	@SqlQuery(
			"select " + FIELDS + I18N
					+ " FROM prt_parties_documents r \n"
					+ " where r.party_id = :partyId "
					+ " and r.definition_code = :definitionCode "
					+ " and r.tenant_id = :tenantId"
					+ CURRENT_RECORD)
	@RegisterBeanMapper(PartyDocument.class)
	ResultIterator<PartyDocument> searchByPartyIdAndDefinitionCode(
			@Bind("partyId") Long partyId,
			@Bind("definitionCode") String definitionCode,
			@BindBean ReqContext ctx);

	@SqlQuery(
			"select " + FIELDS + I18N
					+ " FROM prt_parties_documents r \n"
					+ " where r.document_id = :documentId "
					+ " and r.tenant_id = :tenantId"
					+ CURRENT_RECORD)
	@RegisterBeanMapper(PartyDocument.class)
	PartyDocument getByDocumentId(
			@Bind("documentId") Long documentId,
			@BindBean ReqContext ctx);

	@SqlQuery(
			"select " + FIELDS + I18N
					+ " FROM prt_parties_documents r \n"
					+ " where r.document_id = :documentId "
					+ " and r.definition_code = :definitionCode "
					+ " and r.tenant_id = :tenantId"
					+ CURRENT_RECORD)
	@RegisterBeanMapper(PartyDocument.class)
	PartyDocument getByDocumentIdAndCode(
			@Bind("documentId") Long documentId,
			@Bind("definitionCode") String definitionCode,
			@BindBean ReqContext ctx);

	@SqlQuery(
			"select " + FIELDS + I18N
					+ " FROM prt_parties_documents r \n"
					+ " where r.party_id = :partyId "
					+ " and r.definition_code = :definitionCode "
					+ " and r.tenant_id = :tenantId"
					+ CURRENT_RECORD)
	@RegisterBeanMapper(PartyDocument.class)
	List<PartyDocument> getByPartIdAndCode(
			@Bind("partyId") Long partyId,
			@Bind("definitionCode") String code,
			@BindBean ReqContext ctx);

	@SqlQuery("select " + FIELDS
			+ " FROM prt_parties_documents r \n"
			+ " where r.document_id = :documentId "
			+ " and r.tenant_id = :tenantId"
			+ CURRENT_RECORD)
	@RegisterBeanMapper(PartyDocumentEntity.class)
	Optional<PartyDocumentEntity> findEntityByDocumentId(
			@Bind("documentId") Long documentId,
			@BindBean ReqContext ctx);

	@SqlQuery("select " + FIELDS
			+ " FROM prt_parties_documents r \n"
			+ " where r.document_id = :documentId "
			+ " and r.party_id = :partyId "
			+ " and r.tenant_id = :tenantId"
			+ CURRENT_RECORD)
	@RegisterBeanMapper(PartyDocumentEntity.class)
	Optional<PartyDocumentEntity> findEntityByDocumentIdAndPartyId(
			@Bind("partyId") Long partyId,
			@Bind("documentId") Long documentId,
			@BindBean ReqContext ctx);

	@SqlQuery("select " + FIELDS
			+ " FROM prt_parties_documents r \n"
			+ " where r.definition_code = :definitionCode "
			+ " and r.party_id = :partyId "
			+ " and r.tenant_id = :tenantId"
			+ CURRENT_RECORD)
	@RegisterBeanMapper(PartyDocumentEntity.class)
	List<PartyDocumentEntity> findEntitiesByDocumentDefCodeAndPartyId(
			@Bind("partyId") Long partyId,
			@Bind("definitionCode") String definitionCode,
			@BindBean ReqContext ctx);

	@SqlUpdate(
			"INSERT INTO prt_parties_documents (tenant_id, party_id, definition_code, document_id, dt_insert, user_id_insert, dt_delete, user_id_delete) "
					+ " VALUES (:tenantId, :partyId, :definitionCode, :documentId, §current_timestamp§, :userIdInsert, TO_DATE('9999-12-31','YYYY-MM-DD'), :userIdDelete)")
	@GetGeneratedKeys("pkid")
	Long insert(@BindBean PartyDocumentEntity entity);

	@SqlUpdate("update prt_parties_documents set dt_delete =:dtDelete, user_id_delete=:userIdDelete where pkid = :pkid")
	void expireRow(@BindBean PartyDocumentEntity entity);

}


