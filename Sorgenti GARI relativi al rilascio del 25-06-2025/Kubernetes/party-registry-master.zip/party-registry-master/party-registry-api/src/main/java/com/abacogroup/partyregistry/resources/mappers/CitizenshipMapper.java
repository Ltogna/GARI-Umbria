package com.abacogroup.partyregistry.resources.mappers;

import com.abacogroup.partyregistry.db.ntt.CitizenshipEntity;
import com.abacogroup.partyregistry.resources.req.CitizenshipReq;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper
public interface CitizenshipMapper {

	CitizenshipMapper INSTANCE = Mappers.getMapper(CitizenshipMapper.class);

	CitizenshipEntity reqToEntity(CitizenshipReq req);

}
