package com.abacogroup.partyregistry.core;

import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.partyregistry.api.Tag;
import com.abacogroup.partyregistry.db.ntt.TagEntity;
import com.abacogroup.partyregistry.resources.req.ReqContext;
import com.abacogroup.partyregistry.resources.req.TagSearchReq;
import java.util.List;
import java.util.Optional;

public interface TagService {

	Optional<TagEntity> findTagByCode(String tenantId, String code);
	//-------

	InfiniteListResults<Tag> searchTags(ReqContext reqContext, TagSearchReq searchRequest, String nextKey);

	List<Tag> searchTagList(ReqContext reqContext, TagSearchReq searchRequest);

	Optional<Tag> getTagById(ReqContext reqContext, Long id);

	Optional<Tag> getTagByCode(ReqContext reqContext, String code);

	//Tag save(ReqContext reqContext, TagReq tagReq);

}
