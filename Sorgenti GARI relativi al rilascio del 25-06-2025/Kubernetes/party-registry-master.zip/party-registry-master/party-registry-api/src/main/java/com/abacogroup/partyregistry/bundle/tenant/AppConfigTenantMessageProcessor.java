package com.abacogroup.partyregistry.bundle.tenant;

import static com.abacogroup.bundles.Constants.ALL_TENANTS;

import com.abacogroup.bundles.listener.tenant.TenantMessage;
import com.abacogroup.bundles.listener.tenant.TenantMessageProcessor;
import com.abacogroup.partyregistry.core.BundleConstants;
import com.abacogroup.partyregistry.core.impl.AuditHelper;
import com.abacogroup.partyregistry.db.dao.AppConfigDAO;
import com.abacogroup.partyregistry.db.ntt.AppConfigEntity;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class AppConfigTenantMessageProcessor implements TenantMessageProcessor {

	private final AppConfigDAO appConfigDAO;

	public AppConfigTenantMessageProcessor(AppConfigDAO appConfigDAO) {
		this.appConfigDAO = appConfigDAO;
	}

	@Override
	public void onMessage(TenantMessage tenantMessage) {
		String tenantId = tenantMessage.getTenantId();
		if (appConfigDAO.countAll(tenantId) > 0L) {
			log.warn("app configurations already present for tenant {}", tenantId);
		} else {
			AppConfigEntity auditApp = new AppConfigEntity();
			AuditHelper.setAuditForInsert(BundleConstants.SYSTEM_USER, appConfigDAO, auditApp);
			appConfigDAO.insertNewTenant(ALL_TENANTS, tenantId, auditApp);
		}
	}

}
