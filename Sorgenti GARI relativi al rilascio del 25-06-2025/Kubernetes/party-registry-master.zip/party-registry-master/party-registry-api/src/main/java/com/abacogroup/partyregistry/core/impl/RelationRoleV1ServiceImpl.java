package com.abacogroup.partyregistry.core.impl;

import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.partyregistry.api.v1.RelationRoleResponseV1;
import com.abacogroup.partyregistry.api.v1.req.RelationRoleSearchRequestV1;
import com.abacogroup.partyregistry.core.RelationRoleService;
import com.abacogroup.partyregistry.core.RelationRoleV1Service;
import com.abacogroup.partyregistry.resources.publicapis.mapper.RelationRoleResMapper;
import com.abacogroup.partyregistry.resources.publicapis.mapper.RelationRoleSearchReqMapper;
import com.abacogroup.partyregistry.resources.req.RelationRoleSearchReq;
import com.abacogroup.partyregistry.resources.req.ReqContext;
import java.util.Optional;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class RelationRoleV1ServiceImpl implements RelationRoleV1Service {

	private final RelationRoleService relationRoleService;

	public RelationRoleV1ServiceImpl(RelationRoleService relationRoleService) {
		this.relationRoleService = relationRoleService;
	}

	@Override
	public InfiniteListResults<RelationRoleResponseV1> search(ReqContext reqContext, RelationRoleSearchRequestV1 searchRequest, String relationTypeCode,
			String nextKey) {
		RelationRoleSearchReq searchReq = RelationRoleSearchReqMapper.INSTANCE.fromV1(searchRequest);
		searchReq.setRelationTypeCode(relationTypeCode);

		return relationRoleService.search(reqContext, searchReq, nextKey).map(
				RelationRoleResMapper.INSTANCE::toV1);
	}

	@Override
	public Optional<RelationRoleResponseV1> getByCodeAndType(ReqContext reqContext, String typeCode, String code) {
		return relationRoleService.getByCodeAndType(reqContext, typeCode, code).map(
				RelationRoleResMapper.INSTANCE::toV1);
	}

}
