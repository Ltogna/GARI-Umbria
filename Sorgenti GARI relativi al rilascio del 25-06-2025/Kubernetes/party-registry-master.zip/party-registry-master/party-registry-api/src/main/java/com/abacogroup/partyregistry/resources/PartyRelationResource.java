package com.abacogroup.partyregistry.resources;

import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.partyregistry.api.PartyRelation;
import com.abacogroup.partyregistry.core.AclService;
import com.abacogroup.partyregistry.core.PartyRelationService;
import com.abacogroup.partyregistry.core.exceptions.InvalidPartyException;
import com.abacogroup.partyregistry.core.exceptions.InvalidPartyRelationException;
import com.abacogroup.partyregistry.core.exceptions.InvalidRelationTypeException;
import com.abacogroup.partyregistry.resources.req.PartyRelationTypeSearchReq;
import com.abacogroup.partyregistry.resources.req.ReqContext;
import com.abacogroup.partyregistry.resources.req.rel.CreatePartyRelationReq;
import com.abacogroup.partyregistry.resources.req.rel.PartyRelationDetailRequest;
import io.dropwizard.auth.Auth;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.annotation.security.RolesAllowed;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import jakarta.ws.rs.BeanParam;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.DefaultValue;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.HeaderParam;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.MediaType;

@Path(ResourceConstants.API_PRIV + "/parties/{partyId}/relation-types")
@Produces(MediaType.APPLICATION_JSON)
@Tag(name = "party relation types", description = "Operations on party relation types")
public class PartyRelationResource {
	
	private static final boolean SKIP_ACL_IF_CAN_IGNORE = true;

	private final AclService aclService;
	private final PartyRelationService partyRelationService;

	public PartyRelationResource(AclService aclService, PartyRelationService partyRelationService) {
		this.aclService = aclService;
		this.partyRelationService = partyRelationService;
	}

	@Operation(summary = "List of party relation types", description = "Get list of relation types of a party filtered with criteria")
	@ApiResponses({
			@ApiResponse(responseCode = "200", description = "Successfully, returns a list relation types (sorted/filtered)",
					content = @Content(mediaType = "application/json",
							schema = @Schema(ref = "#/components/schemas/InfiniteListResultsPartyRelation")))
	})
	@GET
	@RolesAllowed("PARTY-REGISTRY|READ")
	public InfiniteListResults<PartyRelation> search(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@PathParam("tenant") String tenantId,

			@Parameter(description = "the party ID") @PathParam("partyId") Long partyId,
			@Parameter(description = "Can be supplied to obtain the records that follows those obtained by a previous call") @QueryParam("nextKey") String nextKey,
			@BeanParam PartyRelationTypeSearchReq searchRequest) {

		ReqContext reqContext = new ReqContext(user, lang);
		aclService.canRead(reqContext, partyId, SKIP_ACL_IF_CAN_IGNORE);
		return partyRelationService.search(reqContext, partyId, searchRequest, nextKey);
	}

	@Operation(summary = "Find relation of party by ID", description = "Returns relation party info based on its ID")
	@ApiResponses({
			@ApiResponse(responseCode = "200", description = "Successfully, relation party is found",
					content = @Content(mediaType = "application/json", schema = @Schema(implementation = PartyRelation.class))),
	})
	@GET
	@RolesAllowed("PARTY-REGISTRY|READ")
	@Path("/{relationId}")
	public PartyRelation getRelationById(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@PathParam("tenant") String tenantId,

			@Parameter(description = "the party ID") @PathParam("partyId") Long partyId,
			@Parameter(description = "the relation type of the party ID") @PathParam("relationId") Long relationId) {
		ReqContext reqContext = new ReqContext(user, lang);
		aclService.canRead(reqContext, partyId, SKIP_ACL_IF_CAN_IGNORE);
		return this.partyRelationService.getRelationById(reqContext, partyId, relationId).orElse(null);
	}

	@Operation(summary = "Add relation type for a party", description = "Insert a new relation type for a party")
	@ApiResponses({
			@ApiResponse(responseCode = "200", description = "Successfully, the new party relation type is created",
					content = @Content(mediaType = "application/json", schema = @Schema(implementation = PartyRelation.class))),
			@ApiResponse(responseCode = "400", description = "add relation type error",
					content = @Content(mediaType = "application/json", schema = @Schema(anyOf = {
							InvalidRelationTypeException.ErrorBody.class,
							InvalidPartyException.ErrorBody.class
					})))
	})
	@POST
	@RolesAllowed("PARTY-REGISTRY|WRITE")
	public PartyRelation addRelation(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@PathParam("tenant") String tenantId,

			@Parameter(description = "the party ID") @PathParam("partyId") Long partyId,
			@NotNull @Valid CreatePartyRelationReq createPartyRelationReq) {
		ReqContext reqContext = new ReqContext(user, lang);
		aclService.canWrite(reqContext, partyId);
		return this.partyRelationService.save(reqContext, partyId, createPartyRelationReq);
	}

	@Operation(summary = "Update relation party details", description = "Update an existing party relation")
	@ApiResponses({
			@ApiResponse(responseCode = "200", description = "Successfully, the relation party details is updated",
					content = @Content(mediaType = "application/json", schema = @Schema(implementation = PartyRelation.class))),
			@ApiResponse(responseCode = "400", description = "party not found",
					content = @Content(schema = @Schema(implementation = InvalidPartyException.ErrorBody.class)))
	})
	@PUT
	@RolesAllowed("PARTY-REGISTRY|WRITE")
	@Path("/{relationId}")
	public PartyRelation updateDetails(
			//TODO TESTAMI
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@PathParam("tenant") String tenantId,

			@Parameter(description = "the party ID") @PathParam("partyId") Long partyId,
			@Parameter(description = "the relation type of the party ID") @PathParam("relationId") Long relationId,
			@NotNull @Valid PartyRelationDetailRequest partyRelationDetailRequest) {
		ReqContext reqContext = new ReqContext(user, lang);
		aclService.canWrite(reqContext, partyId);
		return this.partyRelationService.saveDetail(reqContext, partyId, relationId, partyRelationDetailRequest);
	}

	@Operation(summary = "delete relation party", description = "delete a relation from a party by setting it as expired")
	@ApiResponses({
			@ApiResponse(responseCode = "200", description = "relation party deleted (Expired)"),
			@ApiResponse(responseCode = "404", description = "relation party not found", content = @Content(schema = @Schema(implementation = InvalidPartyRelationException.ErrorBody.class)))
	})
	@DELETE
	@RolesAllowed("PARTY-REGISTRY|DELETE")
	@Path("/{relationId}")
	public void expireRelation(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "the tenant ID") @PathParam("tenant") String tenantId,

			@Parameter(description = "the party ID") @PathParam("partyId") Long partyId,
			@Parameter(description = "the relation type of the party ID") @PathParam("relationId") Long relationId) {
		ReqContext reqContext = new ReqContext(user, lang);
		aclService.canWrite(reqContext, partyId);
		this.partyRelationService.expire(reqContext, partyId, relationId);
	}

}

