package com.abacogroup.partyregistry.core.impl;

import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.partyregistry.api.v1.TagResponseV1;
import com.abacogroup.partyregistry.api.v1.req.TagSearchRequestV1;
import com.abacogroup.partyregistry.core.TagService;
import com.abacogroup.partyregistry.core.TagV1Service;
import com.abacogroup.partyregistry.resources.publicapis.mapper.TagResMapper;
import com.abacogroup.partyregistry.resources.publicapis.mapper.TagSearchReqMapper;
import com.abacogroup.partyregistry.resources.req.ReqContext;
import com.abacogroup.partyregistry.resources.req.TagSearchReq;
import java.util.List;
import java.util.stream.Collectors;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class TagV1ServiceImpl implements TagV1Service {

	private final TagService tagService;

	public TagV1ServiceImpl(TagService tagService) {
		this.tagService = tagService;
	}

	@Override
	public InfiniteListResults<TagResponseV1> searchTags(ReqContext reqContext, TagSearchRequestV1 searchRequest, String nextKey) {
		TagSearchReq searchReq = TagSearchReqMapper.INSTANCE.fromV1(searchRequest);
		return tagService.searchTags(reqContext, searchReq, nextKey)
				.map(TagResMapper.INSTANCE::toV1);

	}

	@Override public List<TagResponseV1> searchTagList(ReqContext reqContext, TagSearchRequestV1 searchRequest) {
		TagSearchReq searchReq = TagSearchReqMapper.INSTANCE.fromV1(searchRequest);
		return tagService.searchTagList(reqContext, searchReq)
				.stream()
				.map(TagResMapper.INSTANCE::toV1)
				.collect(Collectors.toList());
	}
}
