package com.abacogroup.partyregistry.bundle.config;

import com.abacogroup.bundles.initializer.impl.exceptions.BundleException;
import com.abacogroup.bundles.listener.configdata.ConfigDataMessage;
import com.abacogroup.bundles.listener.configdata.ConfigMessageProcessor;
import com.abacogroup.partyregistry.bundle.config.i18n.I18nAware;
import com.abacogroup.partyregistry.bundle.config.i18n.I18nEntry;
import com.abacogroup.partyregistry.bundle.config.i18n.I18nHelper;
import com.abacogroup.partyregistry.bundle.config.i18n.I18nMap;
import com.abacogroup.partyregistry.bundle.utils.FileOperationEnum;
import com.abacogroup.partyregistry.core.BundleConstants;
import com.abacogroup.partyregistry.core.RelationTypeService;
import com.abacogroup.partyregistry.core.impl.AuditHelper;
import com.abacogroup.partyregistry.db.dao.I18nDAO;
import com.abacogroup.partyregistry.db.dao.RelationRoleDAO;
import com.abacogroup.partyregistry.db.dao.RelationTypeDAO;
import com.abacogroup.partyregistry.db.ntt.RelationRoleEntity;
import com.abacogroup.partyregistry.db.ntt.RelationTypeEntity;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.stream.Collectors;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

@Slf4j
public class RelationsConfigMessageProcessor implements ConfigMessageProcessor {

	private final RelationTypeDAO relationTypeDAO;
	private final RelationTypeService relationTypeService;
	private final RelationRoleDAO relationRoleDAO;
	private final ObjectMapper mapper = new ObjectMapper()
			.disable(DeserializationFeature.FAIL_ON_IGNORED_PROPERTIES);

	private final I18nHelper i18nHelper;

	public RelationsConfigMessageProcessor(RelationTypeDAO relationTypeDAO, RelationTypeService relationTypeService, RelationRoleDAO relationRoleDAO,
			I18nDAO i18nDAO) {
		this.relationTypeDAO = relationTypeDAO;
		this.relationTypeService = relationTypeService;
		this.relationRoleDAO = relationRoleDAO;
		this.i18nHelper = new I18nHelper(i18nDAO);
	}

	@Override
	public String getDomainName() {
		return BundleConstants.DOMAIN_RELATIONS;
	}

	@Override
	public void onMessage(ConfigDataMessage message) {
		String tenantId = message.getTenantId();

		Function<String, FileOperationEnum> groupingPredicate = x -> {
			if (StringUtils.containsIgnoreCase(x, "delete")) {
				return FileOperationEnum.DELETE;
			} else {
				return FileOperationEnum.DEFAULT;
			}
		};

		List<Path> paths = message.getConfigFiles();
		var map = paths.stream()
				.collect(Collectors.groupingBy(x -> groupingPredicate.apply(x.toString()),
						Collectors.toCollection(ArrayList::new)));

		map.getOrDefault(FileOperationEnum.DELETE, new ArrayList<>()).forEach(path -> removeContent(tenantId, path));
		map.getOrDefault(FileOperationEnum.DEFAULT, new ArrayList<>()).forEach(path -> addContent(tenantId, path));
	}

	private void addContent(String tenantId, Path path) {

		List<RelationEntry> entries = readFileToMap(path);
		storeTypes(tenantId, entries);
		storeRoles(tenantId, entries);
	}

	private void removeContent(String tenantId, Path path) {

		List<RelationEntry> entries = readFileToMap(path);
		deleteRoles(tenantId, entries);
		deleteTypesInCascade(tenantId, entries);
	}

	private void storeTypes(String tenantId, List<RelationEntry> entries) {
		List<RelationTypeEntity> entities = entries
				.stream()
				.filter(Objects::nonNull)

				.map(entry -> RelationTypeEntity.builder()
						.setTenantId(tenantId)
						.setCode(entry.getType())
						.setFlMultiple(entry.isMultiple() ? 1 : 0)
						.build())
				.collect(Collectors.toList());
		var entitiesArray = entities.toArray(RelationTypeEntity[]::new);

		//TODO expire batch (anche per multiple)
		AuditHelper.setAuditForInsert(BundleConstants.SYSTEM_USER, relationTypeDAO, entitiesArray);
		relationTypeDAO.insertBatchIdempotent(entitiesArray);
		entries.forEach(relationEntry -> i18nHelper.upsert(tenantId, "prt_relation_types", "code", relationEntry));
	}

	private void storeRoles(String tenantId, List<RelationEntry> entries) {
		getRelationRolesByType(entries)
				.forEach((relTypeCode, relRoleEntities) -> {
					AuditHelper.setAuditForInsert(BundleConstants.SYSTEM_USER, relationRoleDAO, relRoleEntities);
					relationRoleDAO.insertRolesIdempotent(tenantId, relTypeCode, relRoleEntities);
				});

		entries.forEach(relationEntry -> {
			relationEntry.getRoles().forEach(roleEntry -> {
				i18nHelper.upsert(tenantId, "prt_relation_roles", "code", roleEntry);
			});
		});
	}

	private void deleteTypesInCascade(String tenantId, List<RelationEntry> entries) {
		entries
				.stream()
				.filter(x -> x.getRoles().isEmpty())
				.map(r -> r.getType())
				.forEach(t -> relationTypeService.expireInCascade(tenantId, t));
	}

	private void deleteRoles(String tenantId, List<RelationEntry> entries) {
		getRelationRoles(entries).forEach(toDelete ->
				relationRoleDAO.useTransaction(handle -> {
					handle.findEntityByCode(tenantId, toDelete.getCode())
							.ifPresentOrElse(e -> {
										Consumer<RelationRoleEntity> expireFun = handle::expireRow;
										AuditHelper.expire(e, BundleConstants.SYSTEM_USER, expireFun, handle.getCurrentTimestamp());
									},
									() -> log.warn("cannot remove relation role {}.{}: role in use or already deleted!",
											toDelete.getCode()));
				}));
	}

	private List<RelationRoleEntity> getRelationRoles(List<RelationEntry> entries) {
		return entries
				.stream()
				.filter(x -> !x.getRoles().isEmpty())
				.flatMap(t -> t.getRoles().stream())
				.map(x -> RelationRoleEntity.builder()
						.setCode(x.code)
						.build())
				.collect(Collectors.toList());
	}

	private Map<String, RelationRoleEntity[]> getRelationRolesByType(List<RelationEntry> entries) {
		return entries.stream().collect(Collectors.toMap(RelationEntry::getType,
				v -> v.getRoles().stream()
						.map(x -> RelationRoleEntity.builder()
								.setCode(x.code)
								.build())
						.toArray(RelationRoleEntity[]::new)));
	}

	protected List<RelationEntry> readFileToMap(Path path) {
		try {
			String json = Files.readString(path);
			return mapper.readValue(json, new TypeReference<>() {
			});

		} catch (IOException e) {
			throw new BundleException(String.format("error reading file %s", path), e);
		}
	}

	@Data
	protected static class RelationEntry implements I18nAware {
		private String type;
		private boolean multiple;

		private I18nMap description = new I18nMap();
		private Set<RoleEntry> roles = new HashSet<>();

		@Override
		public String getI18nCode() {
			return type;
		}

		@Override
		public Set<I18nEntry> getI18n() {
			return description.getI18n();
		}
	}

	@Data
	protected static class RoleEntry implements I18nAware {
		private String code;
		private I18nMap description = new I18nMap();

		@Override
		public String getI18nCode() {
			return code;
		}

		@Override
		public Set<I18nEntry> getI18n() {
			return description.getI18n();
		}
	}

}
