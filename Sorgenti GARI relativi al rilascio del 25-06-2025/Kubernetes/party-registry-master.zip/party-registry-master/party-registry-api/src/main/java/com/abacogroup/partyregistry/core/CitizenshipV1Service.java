package com.abacogroup.partyregistry.core;

import java.util.Optional;

import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.partyregistry.api.v1.CitizenshipResponseV1;
import com.abacogroup.partyregistry.api.v1.req.CitizenshipSearchRequestV1;
import com.abacogroup.partyregistry.resources.req.ReqContext;

public interface CitizenshipV1Service {

	InfiniteListResults<CitizenshipResponseV1> search(ReqContext reqContext, CitizenshipSearchRequestV1 searchRequest, String nextKey);

	Optional<CitizenshipResponseV1> getByCode(ReqContext reqContext, String code);

}
