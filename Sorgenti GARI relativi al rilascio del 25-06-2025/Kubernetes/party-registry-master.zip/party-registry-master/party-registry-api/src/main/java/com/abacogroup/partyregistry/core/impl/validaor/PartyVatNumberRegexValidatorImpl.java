package com.abacogroup.partyregistry.core.impl.validaor;

import com.abacogroup.partyregistry.core.PartyFieldValidator;
import com.abacogroup.partyregistry.db.ntt.PartyEntity;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.commons.lang3.StringUtils;

public class PartyVatNumberRegexValidatorImpl extends AbstractRegexCodeValidator implements PartyFieldValidator {

	public static final String CONFIG_KEY = "vatNumber_validation";

	public PartyVatNumberRegexValidatorImpl(ObjectMapper objectMapper) {
		super(objectMapper);
	}

	@Override
	public String getFieldName() {
		return CONFIG_KEY;
	}

	@Override
	protected String getCodeDescription() {
		return "VAT NUMBER";
	}

	@Override
	protected String getCode(PartyEntity party) {
		party.setVatNumber(StringUtils.upperCase(StringUtils.trim(party.getVatNumber())));
		return party.getVatNumber();
	}

}
