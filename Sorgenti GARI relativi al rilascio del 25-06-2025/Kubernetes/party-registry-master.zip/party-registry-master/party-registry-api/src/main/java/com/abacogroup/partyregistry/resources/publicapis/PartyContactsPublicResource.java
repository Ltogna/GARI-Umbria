package com.abacogroup.partyregistry.resources.publicapis;

import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.partyregistry.api.v1.ContactSearchResponseV1;
import com.abacogroup.partyregistry.api.v1.req.ContactSearchRequestV1;
import com.abacogroup.partyregistry.core.AclService;
import com.abacogroup.partyregistry.core.ContactService;
import com.abacogroup.partyregistry.resources.PublicResourceConstants;
import com.abacogroup.partyregistry.resources.publicapis.mapper.ContactPublicMapper;
import com.abacogroup.partyregistry.resources.req.ReqContext;
import io.dropwizard.auth.Auth;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.ws.rs.BeanParam;
import jakarta.ws.rs.DefaultValue;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.HeaderParam;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.MediaType;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Path(PublicResourceConstants.API_V1_PUB + "/parties/{partyId}/contacts")
@Produces(MediaType.APPLICATION_JSON)
@Tag(name = "party contacts", description = "Operations on party contacts")
public class PartyContactsPublicResource {

	private final AclService aclService;
	private final ContactService contactService;

	public PartyContactsPublicResource(AclService aclService, ContactService contactService) {
		this.aclService = aclService;
		this.contactService = contactService;
	}

	@GET
//	@RolesAllowed("PARTY-REGISTRY|READ")
	@Operation(summary = "List of party contacts", description = "Get list of party contacts filtered with criteria")
	@ApiResponses({
			@ApiResponse(responseCode = "200", description = "Successfully, returns a list of party contacts (sorted/filtered)",
					content = @Content(mediaType = "application/json",
							schema = @Schema(ref = "#/components/schemas/InfiniteListResultsContactSearchResponseV1"))) })
	public InfiniteListResults<ContactSearchResponseV1> search(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "the tenant ID") @PathParam("tenant") String tenantId,
			@Parameter(description = "Can be supplied to obtain the records that follows those obtained by a previous call") @QueryParam("nextKey") String nextKey,
			@BeanParam ContactSearchRequestV1 contactSearchReq
	) {

		ReqContext reqContext = new ReqContext(user, lang);
		aclService.canRead(reqContext, contactSearchReq.getPartyId());
		return contactService.search(reqContext, ContactPublicMapper.INSTANCE.fromSearchRequestV1(contactSearchReq), nextKey)
				.map(ContactPublicMapper.INSTANCE::toSearchResponseV1);
	}

}

