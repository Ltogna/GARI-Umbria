package com.abacogroup.partyregistry.resources.publicapis;

import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.partyregistry.api.v1.RelationTypeResponseV1;
import com.abacogroup.partyregistry.api.v1.req.RelationTypeSearchRequestV1;
import com.abacogroup.partyregistry.core.RelationTypeV1Service;
import com.abacogroup.partyregistry.resources.PublicResourceConstants;
import com.abacogroup.partyregistry.resources.req.ReqContext;
import io.dropwizard.auth.Auth;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.ws.rs.BeanParam;
import jakarta.ws.rs.DefaultValue;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.HeaderParam;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.MediaType;

@Path(PublicResourceConstants.API_V1_PUB + "/relation-types")
@Produces(MediaType.APPLICATION_JSON)
@Tag(name = "relation types", description = "Operations on relation types")
public class RelationTypePublicResource {

	private final RelationTypeV1Service relationTypeService;

	public RelationTypePublicResource(RelationTypeV1Service relationTypeService) {
		this.relationTypeService = relationTypeService;
	}

	@Operation(summary = "List of relation types", description = "Get list of relation types filtered with criteria")
	@ApiResponses({
			@ApiResponse(responseCode = "200", description = "Successfully, returns a list of relation types (sorted/filtered)",
					content = @Content(mediaType = "application/json", schema = @Schema(ref = "#/components/schemas/InfiniteListResultsRelationTypeResponseV1")))
	})
	@GET
	//@RolesAllowed("")
	public InfiniteListResults<RelationTypeResponseV1> search(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "tenant ID") @PathParam("tenant") String tenantId,

			@Parameter(description = "Can be supplied to obtain the records that follows those obtained by a previous call") @QueryParam("nextKey") String nextKey,
			@BeanParam RelationTypeSearchRequestV1 searchRequest) {

		ReqContext reqContext = new ReqContext(user, lang);
		return relationTypeService.search(reqContext, searchRequest, nextKey);
	}

	@Operation(summary = "Find relation type by ID", description = "Returns relation type based on its ID")
	@ApiResponses({
			@ApiResponse(responseCode = "200", description = "Successfully, relation type is found",
					content = @Content(mediaType = "application/json", schema = @Schema(implementation = RelationTypeResponseV1.class))),
	})
	@GET
	//@RolesAllowed("")
	@Path("/{code}")
	public RelationTypeResponseV1 getById(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "tenant ID") @PathParam("tenant") String tenantId,

			@Parameter(description = "the relation type CODE") @PathParam("code") String code
	) {
		ReqContext reqContext = new ReqContext(user, lang);
		return this.relationTypeService.getByCode(reqContext, code)
				.orElse(null);
	}

}
