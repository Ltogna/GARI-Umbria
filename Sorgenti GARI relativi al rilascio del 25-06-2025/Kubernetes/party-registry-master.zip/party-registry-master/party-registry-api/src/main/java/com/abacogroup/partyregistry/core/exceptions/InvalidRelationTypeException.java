package com.abacogroup.partyregistry.core.exceptions;


import io.swagger.v3.oas.annotations.media.Schema;

public class InvalidRelationTypeException extends AbstractPartyException {

	public InvalidRelationTypeException(String code, String message) {
		super(new ErrorBody(code, message));
	}

	@Schema(name = "InvalidRelationTypeExceptionErrorBody")
	public static class ErrorBody implements ExceptionErrorBody {
		private final String code;
		private final String message;

		public ErrorBody(String code, String message) {
			this.code = code;
			this.message = message;
		}

		@Override
		@Schema(allowableValues = { ErrCodes.RELATION_TYPE_MULTIPLE_INSTANCES_NOT_ALLOWED, ErrCodes.RELATION_TYPE_NOT_FOUND })
		public String getErrorCode() {
			return code;
		}

		@Override
		@Schema
		public String getMessage() {
			return message;
		}
	}

}
