package com.abacogroup.partyregistry;

import java.io.IOException;
import java.net.URI;
import java.time.Clock;
import java.util.ArrayList;
import java.util.EnumSet;
import java.util.List;
import java.util.Optional;
import java.util.TimeZone;
import java.util.concurrent.TimeoutException;

import com.abacogroup.partyregistry.core.*;
import com.abacogroup.partyregistry.core.impl.*;
import com.abacogroup.partyregistry.db.dao.*;
import com.abacogroup.partyregistry.resources.publicapis.*;
import org.eclipse.jetty.servlets.CrossOriginFilter;
import org.jdbi.v3.core.Jdbi;

import com.abacogroup.bundles.Constants;
import com.abacogroup.bundles.initializer.BundleInitServiceBuilder;
import com.abacogroup.bundles.initializer.InitService;
import com.abacogroup.bundles.initializer.impl.BundleInitServiceProducer;
import com.abacogroup.bundles.listener.ListenerBuilder;
import com.abacogroup.bundles.listener.RabbitListener;
import com.abacogroup.bundles.listener.configdata.ConfigDataLogProducer;
import com.abacogroup.bundles.listener.configdata.ProcessorOrderPolicyEnum;
import com.abacogroup.bundles.listener.configdata.builder.ConfigDataConsumerBuilder;
import com.abacogroup.bundles.listener.tenant.builder.NewTenantEventConsumerBuilder;
import com.abacogroup.dropwizard.auth.multitenant.MultitenantFilter;
import com.abacogroup.dropwizard.auth.sso2.AuthUtils;
import com.abacogroup.dropwizard.auth.sso2.Sso2Client;
import com.abacogroup.dropwizard.auth.sso2.SsoAuthorizer;
import com.abacogroup.dynamicdocuments.auth.impl.Sso2AuthenticatorProvider;
import com.abacogroup.dynamicdocuments.files.AbacoFileStore;
import com.abacogroup.dynamicdocuments.files.FileStoreSupport;
import com.abacogroup.dynamicdocuments.http.JaxRsClient;
import com.abacogroup.dynamicdocuments.http.RestClient;
import com.abacogroup.dynamicdocuments.http.Sso2AuthenticationProvider;
import com.abacogroup.dynamicdocuments.services.DocumentService;
import com.abacogroup.dynamicdocuments.services.DocumentTypeService;
import com.abacogroup.filestore.client.FileStoreClient;
import com.abacogroup.jdbi.OraJdbiPlugin;
import com.abacogroup.jdbi.PgJdbiPlugin;
import com.abacogroup.jdbi.config.AbacoJdbiConfig;
import com.abacogroup.lau.core.cli.impl.TokenRelayStrategy;
import com.abacogroup.lau.core.cli.v1.CountryClientV1;
import com.abacogroup.lau.core.cli.v1.CountryClientV1Impl;
import com.abacogroup.lau.core.cli.v1.DistrictClientV1;
import com.abacogroup.lau.core.cli.v1.DistrictClientV1Impl;
import com.abacogroup.lau.core.cli.v1.MunicipalityClientV1;
import com.abacogroup.lau.core.cli.v1.MunicipalityClientV1Impl;
import com.abacogroup.lau.core.cli.v1.RegionClientV1;
import com.abacogroup.lau.core.cli.v1.RegionClientV1Impl;
import com.abacogroup.partyregistry.PartyRegistryConfiguration.RabbitmqConfig;
import com.abacogroup.partyregistry.bundle.config.AppConfigMessageProcessor;
import com.abacogroup.partyregistry.bundle.config.CitizenshipConfigMessageProcessor;
import com.abacogroup.partyregistry.bundle.config.DynamicDocConfigMessageProcessor;
import com.abacogroup.partyregistry.bundle.config.ExternalSourceConfigMessageProcessor;
import com.abacogroup.partyregistry.bundle.config.I18nConfigMessageProcessor;
import com.abacogroup.partyregistry.bundle.config.LegalStatusConfigMessageProcessor;
import com.abacogroup.partyregistry.bundle.config.PartyConfigMessageProcessor;
import com.abacogroup.partyregistry.bundle.config.RelationsConfigMessageProcessor;
import com.abacogroup.partyregistry.bundle.config.TagConfigMessageProcessor;
import com.abacogroup.partyregistry.bundle.tenant.AppConfigTenantMessageProcessor;
import com.abacogroup.partyregistry.bundle.tenant.CitizenshipTenantMessageProcessor;
import com.abacogroup.partyregistry.bundle.tenant.DynamicDocTenantMessageProcessor;
import com.abacogroup.partyregistry.bundle.tenant.ExternalSourceTenantMessageProcessor;
import com.abacogroup.partyregistry.bundle.tenant.I18nTenantMessageProcessor;
import com.abacogroup.partyregistry.bundle.tenant.LegalStatusTenantMessageProcessor;
import com.abacogroup.partyregistry.bundle.tenant.RelationsTenantMessageProcessor;
import com.abacogroup.partyregistry.bundle.tenant.TagTenantMessageProcessor;
import com.abacogroup.partyregistry.core.client.ExternalSourceClientV1;
import com.abacogroup.partyregistry.core.dynamicdoc.DocumentValidator;
import com.abacogroup.partyregistry.core.dynamicdoc.DocumentValidatorFactory;
import com.abacogroup.partyregistry.core.dynamicdoc.FileStoreProxyClient;
import com.abacogroup.partyregistry.core.dynamicdoc.PartyDynamicDocumentManager;
import com.abacogroup.partyregistry.core.dynamicdoc.PartyDynamicDocumentManagerImpl;
import com.abacogroup.partyregistry.core.dynamicdoc.validators.EarningsValidator;
import com.abacogroup.partyregistry.core.impl.validaor.PartyCodeRegexValidatorImpl;
import com.abacogroup.partyregistry.core.impl.validaor.PartyCodeValidatorImpl;
import com.abacogroup.partyregistry.core.impl.validaor.PartyTaxCodeRegexValidatorImpl;
import com.abacogroup.partyregistry.core.impl.validaor.PartyTypeValidatorImpl;
import com.abacogroup.partyregistry.core.impl.validaor.PartyVatNumberRegexValidatorImpl;
import com.abacogroup.partyregistry.resources.CitizenshipResource;
import com.abacogroup.partyregistry.resources.DevtoolsResource;
import com.abacogroup.partyregistry.resources.DocTypeResource;
import com.abacogroup.partyregistry.resources.ExternalSourceResource;
import com.abacogroup.partyregistry.resources.LegalStatusResource;
import com.abacogroup.partyregistry.resources.PartyContactsResource;
import com.abacogroup.partyregistry.resources.PartyDocumentsResource;
import com.abacogroup.partyregistry.resources.PartyRelationPartiesResource;
import com.abacogroup.partyregistry.resources.PartyRelationResource;
import com.abacogroup.partyregistry.resources.PartyResource;
import com.abacogroup.partyregistry.resources.PartyTagResource;
import com.abacogroup.partyregistry.resources.RelationRoleResource;
import com.abacogroup.partyregistry.resources.RelationTypeResource;
import com.abacogroup.partyregistry.resources.TagResource;
import com.abacogroup.partyregistry.resources.UserSupportResource;
import com.abacogroup.partyregistry.resources.mappers.PartyRelationPartyMapper;
import com.abacogroup.proxies.cache.ProxiesCache;
import com.abacogroup.proxies.cache.core.models.ProxiesCacheConfig;
import com.abacogroup.tracing.dropwizard.AbacoApplication;
import com.abacogroup.tracing.httpclient5.AddRequestId;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;

import io.dropwizard.client.JerseyClientBuilder;
import io.dropwizard.configuration.EnvironmentVariableSubstitutor;
import io.dropwizard.configuration.SubstitutingSourceProvider;
import io.dropwizard.core.setup.Bootstrap;
import io.dropwizard.core.setup.Environment;
import io.dropwizard.db.DataSourceFactory;
import io.dropwizard.forms.MultiPartBundle;
import io.dropwizard.jdbi3.JdbiFactory;
import io.dropwizard.migrations.MigrationsBundle;
import io.federecio.dropwizard.swagger.SwaggerBundle;
import io.federecio.dropwizard.swagger.SwaggerBundleConfiguration;
import io.swagger.v3.oas.integration.ClasspathOpenApiConfigurationLoader;
import io.swagger.v3.oas.integration.SwaggerConfiguration;
import io.swagger.v3.oas.integration.api.OpenAPIConfiguration;
import jakarta.servlet.DispatcherType;
import jakarta.servlet.FilterRegistration.Dynamic;
import jakarta.ws.rs.client.Client;
import jakarta.ws.rs.client.WebTarget;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class PartyRegistryApplication extends AbacoApplication<PartyRegistryConfiguration> {

	private static final String APP_NAME = "party-registry-api";

	public static void main(final String[] args) throws Exception {
		new PartyRegistryApplication().run(args);
	}

	@Override
	public String getName() {
		return APP_NAME;
	}

	@Override
	public void initialize(final Bootstrap<PartyRegistryConfiguration> bootstrap) {
		bootstrap.addBundle(new MigrationsBundle<>() {
			@Override
			public DataSourceFactory getDataSourceFactory(PartyRegistryConfiguration configuration) {
				return configuration.getDatabase();
			}
		});

		SubstitutingSourceProvider provider = new SubstitutingSourceProvider(bootstrap.getConfigurationSourceProvider(),
				new EnvironmentVariableSubstitutor(false));
		bootstrap.setConfigurationSourceProvider(provider);

		bootstrap.addBundle(new MultiPartBundle());

		bootstrap.addBundle(new SwaggerBundle<>() {
			@Override
			protected SwaggerBundleConfiguration getSwaggerBundleConfiguration(PartyRegistryConfiguration configuration) {
				return new SwaggerBundleConfiguration() {

					@Override
					public boolean isEnabled() {
						return configuration.getSwagger().isEnabled();
					}

					@Override
					public boolean isIncludeSwaggerResource() {
						return configuration.getSwagger().isIncludeSwaggerResource();
					}

					@Override
					public String getContextRoot() {
						return configuration.getSwagger().getContextRoot();
					}

					@Override
					public SwaggerConfiguration build() {
						try {
							OpenAPIConfiguration oasConfig = new ClasspathOpenApiConfigurationLoader()
									.load(configuration.getSwagger().getOpenapiConfigurationLocation());
							return (SwaggerConfiguration) oasConfig;
						} catch (IOException e) {
							throw new RuntimeException(e);
						}
					}
				};
			}
		});
	}

	@Override
	protected void doRun(final PartyRegistryConfiguration configuration, final Environment environment) throws Exception {
		Clock appClock = Clock.systemDefaultZone();
		ObjectMapper objectMapper = environment.getObjectMapper();
		configureObjectMapper(objectMapper);

		Jdbi jdbi = jdbi(configuration, environment);
		Connection rabbitmqConnection = this.createRabbitmqConnection(configuration);

		final WebTarget lauTarget = this.initLauTarget(configuration, environment);
		final Sso2Client sso2Client = this.initSso2Client(configuration, environment);

		final CountryClientV1 countryClient = this.register(new CountryClientV1Impl(lauTarget, new TokenRelayStrategy()));
		final RegionClientV1 regionClient = this.register(new RegionClientV1Impl(lauTarget, new TokenRelayStrategy()));
		final DistrictClientV1 districtClient = this.register(new DistrictClientV1Impl(lauTarget, new TokenRelayStrategy()));
		final MunicipalityClientV1 municipalityClient = this.register(new MunicipalityClientV1Impl(lauTarget, new TokenRelayStrategy()));
		final LauMapper lauMapper = this.register(new LauMapper(countryClient, regionClient, districtClient, municipalityClient));
		FileStoreClient fileStoreClient = new FileStoreClient(URI.create(configuration.getFileStoreConfig().getUrl()), objectMapper);
		final FileStoreProxyClient fileStoreProxyClient = this.register(new FileStoreProxyClient(this.initFileStoreTarget(configuration, environment)));

		final DocumentTypeService documentTypeService = register(new DocumentTypeService(jdbi));

		RestClient restClient = this.initRestClient(configuration, environment, sso2Client);
		FileStoreSupport fileStoreSupport = this.register(new AbacoFileStore(fileStoreClient, new Sso2AuthenticatorProvider(sso2Client)));
		final DocumentService documentService = register(
				DocumentService.create(documentTypeService, restClient, fileStoreSupport, configuration.getDynamicDocumentsBucket()));

		final I18nDAO i18nDAO = jdbi.onDemand(I18nDAO.class);
		final DocTypeDAO docTypeDAO = jdbi.onDemand(DocTypeDAO.class);
		final TagDAO tagDAO = jdbi.onDemand(TagDAO.class);
		final ContactDAO contactDAO = jdbi.onDemand(ContactDAO.class);
		final PartyDAO partyDAO = jdbi.onDemand(PartyDAO.class);
		final AddressDAO addressDAO = jdbi.onDemand(AddressDAO.class);
		final RelationTypeDAO relationTypeDAO = jdbi.onDemand(RelationTypeDAO.class);
		final RelationRoleDAO relationRoleDAO = jdbi.onDemand(RelationRoleDAO.class);
		final CitizenshipDAO citizenshipDAO = jdbi.onDemand(CitizenshipDAO.class);
		final PartyDocumentDAO partyDocumentDAO = jdbi.onDemand(PartyDocumentDAO.class);
		final AppConfigDAO appConfigDAO = jdbi.onDemand(AppConfigDAO.class);
		final LegalStatusDAO legalStatusDAO = jdbi.onDemand(LegalStatusDAO.class);
		final ExternalSourceDAO externalSourceDAO = jdbi.onDemand(ExternalSourceDAO.class);

		final PartyRelationTypeDAO partyRelationTypeDAO = jdbi.onDemand(PartyRelationTypeDAO.class);
		final PartyRelationPartyDAO partyRelationPartyDAO = jdbi.onDemand(PartyRelationPartyDAO.class);
		final PartyChecksDAO partyChecksDAO = jdbi.onDemand(PartyChecksDAO.class);

		Client externalServiceClient = this.initExternalServiceClient(configuration, environment);
		final ExternalSourceClientV1 externalSourceClient = this.register(new ExternalSourceClientV1(externalServiceClient, externalSourceDAO));

		final PartyEventProducer partyEventProducer = this.register(this.buildPartyEventProducer(environment, jdbi, objectMapper, rabbitmqConnection,
				partyDAO, appClock));
		final AclService aclService = this.register(new AclServiceImpl(partyDAO, sso2Client, configuration.getAclConfig().isIgnoreAcl()));

		final TagService tagService = this.register(new TagServiceImpl(tagDAO));
		final TagV1Service tagV1Service = this.register(new TagV1ServiceImpl(tagService));

		final RelationTypeService relationTypeService = this.register(new RelationTypeServiceImpl(relationTypeDAO));
		final RelationRoleService relationRoleService = this.register(
				new RelationRoleServiceImpl(relationRoleDAO, relationTypeService));

		final PartyCodeValidatorImpl partyCodeValidator = this.register(new PartyCodeValidatorImpl(partyDAO, objectMapper));
		final PartyTypeValidatorImpl partyTypeValidator = this.register(new PartyTypeValidatorImpl(partyDAO, objectMapper));
		final PartyFieldValidator partyTaxCodeRegexValidator = this.register(new PartyTaxCodeRegexValidatorImpl(objectMapper));
		final PartyFieldValidator partyVatNumberRegexValidator = this.register(new PartyVatNumberRegexValidatorImpl(objectMapper));
		final PartyFieldValidator partyCodeRegexValidator = this.register(new PartyCodeRegexValidatorImpl(objectMapper));
		final PartyCustomValidator partyCustomValidator = this.register(new PartyCustomValidatorImpl(appConfigDAO, List.of(
				partyCodeValidator,
				partyTypeValidator,
				partyTaxCodeRegexValidator,
				partyVatNumberRegexValidator,
				partyCodeRegexValidator)));

		final PartyServiceImpl partyService = this.register(new PartyServiceImpl(tagService, partyDAO, addressDAO, legalStatusDAO, externalSourceDAO,
				lauMapper, partyCustomValidator, partyEventProducer, configuration.getAclConfig()));
		final PartyV1ServiceImpl partyV1Service = this.register(new PartyV1ServiceImpl(partyService, lauMapper));

		final PartyTagService partyTagService = this.register(partyService);
		final ContactService contactService = this.register(new ContactServiceImpl(contactDAO, partyService, partyEventProducer));

		final CitizenshipService citizenshipService = this.register(new CitizenshipServiceImpl(citizenshipDAO));
		final CitizenshipV1Service citizenshipV1Service = this.register(new CitizenshipV1ServiceImpl(citizenshipService));

		final LegalStatusService legalStatusService = this.register(new LegalStatusServiceImpl(legalStatusDAO));
		final LegalStatusV1Service legalStatusV1Service = this.register(new LegalStatusV1ServiceImpl(legalStatusService));

		final DocTypeService docTypeService = register(new DocTypeServiceImpl(docTypeDAO, partyService, documentTypeService));

		final PartyRelationPartyMapper partyRelationPartyMapper = this.register(new PartyRelationPartyMapper(relationRoleService,
				partyRelationPartyDAO));

		final PartyRelationService partyRelationService = this.register(
				new PartyRelationServiceImpl(partyRelationTypeDAO, partyRelationPartyDAO, partyService, relationTypeService, partyEventProducer,
						partyRelationPartyMapper));

		final PartyRelationPartyService partyRelationPartyService = this.register(
				new PartyRelationPartyServiceImpl(partyRelationService, partyRelationPartyMapper, partyRelationPartyDAO,
						partyService, relationRoleService, partyEventProducer, aclService));

		final AppConfigV1Service appConfigV1Service = this.register(new AppConfigV1ServiceImpl(appConfigDAO));

		final DocumentValidator earningsValidator = this.register(new EarningsValidator());
		final DocumentValidatorFactory validatorFactory = this.register(
				new DocumentValidatorFactory(List.of(earningsValidator)));

		final PartyDynamicDocumentManager partyDynamicDocumentManager = register(
				new PartyDynamicDocumentManagerImpl(documentTypeService, documentService,
						jdbi.onDemand(PartyDocumentDAO.class), partyService, validatorFactory, partyEventProducer,
						fileStoreProxyClient, configuration.getDynamicDocumentsBucket()));

		final ExternalSourceService externalSourceService = this.register(new ExternalSourceServiceImpl(externalSourceDAO, externalSourceClient,
				partyService, partyDynamicDocumentManager,
				partyRelationService, partyRelationPartyService,
				contactService, aclService));
		
		final UserSupportService userSupportService = this.register(new UserSupportServiceImpl(aclService));

		final PartyChecksService partyChecksService = this.register(new PartyChecksServiceImpl(partyChecksDAO));

		List<Object> resources = new ArrayList<>();

		// private
		resources.add(this.register(new TagResource(tagService)));
		resources.add(new RelationTypeResource(relationTypeService));
		resources.add(new RelationRoleResource(relationRoleService));
		resources.add(new PartyResource(aclService, partyService, externalSourceService));
		resources.add(new PartyContactsResource(aclService, contactService));
		resources.add(new PartyTagResource(aclService, partyTagService));
		resources.add(new PartyRelationResource(aclService, partyRelationService));
		resources.add(new PartyRelationPartiesResource(aclService, partyRelationPartyService));
		resources.add(new DocTypeResource(aclService, docTypeService));
		resources.add(new PartyDocumentsResource(aclService, partyDynamicDocumentManager));
		resources.add(new CitizenshipResource(citizenshipService));
		resources.add(new ExternalSourceResource(externalSourceService));
		resources.add(new LegalStatusResource(legalStatusService));
		resources.add(new UserSupportResource(userSupportService));

		// public
		resources.add(new PartyPublicResource(partyV1Service, aclService,appConfigV1Service));
		resources.add(new PartyTagPublicResource(partyTagService));
		resources.add(new TagPublicResource(tagV1Service));
		resources.add(new PartyContactsPublicResource(aclService, contactService));
		resources.add(new PartyChecksPublicResource(partyChecksService));
		resources.add(new PartyRelationPublicResource(aclService, partyRelationService));
		resources.add(new PartyRelationPartiesPublicResource(aclService, partyRelationPartyService));
		resources.add(new AppConfigPublicResource(appConfigV1Service));
		resources.add(new LegalStatusPublicResource(legalStatusV1Service));

		resources.add(new CitizenshipPublicResource(citizenshipV1Service));
		if (configuration.isDevToolsEnabled()) {
			resources.add(new DevtoolsResource(rabbitmqConnection, jdbi));
		}

		// XXX XXX XXX XXX XXX XXX XXX XXX XXX XXX XXX XXX XXX
		Client proxiesClient = this.initProxiesClient(configuration, environment);
		initProxiesCache(configuration, environment, objectMapper, jdbi, rabbitmqConnection, proxiesClient);
		// XXX XXX XXX XXX XXX XXX XXX XXX XXX XXX XXX XXX XXX

		// environment.jersey().register(new PartyExceptionMapper());
		resources.forEach(environment.jersey()::register);

		this.initAuth(environment, sso2Client);
		this.initMultiTenant(environment);
		this.setupCORS(configuration, environment);

		log.info("creating CONSUMERS rabbitConsumerManager");

		RabbitListener rabbitListener = ListenerBuilder
				.newBuilder(rabbitmqConnection)
				.withConfigDataConsumer(this.register(ConfigDataConsumerBuilder.newBuilder(jdbi, rabbitmqConnection)
						.route(APP_NAME)
						.processor(this.register(new CitizenshipConfigMessageProcessor(citizenshipDAO, jdbi.onDemand(I18nDAO.class))))
						.processor(this.register(new TagConfigMessageProcessor(tagDAO, i18nDAO)))
						.processor(this.register(new DynamicDocConfigMessageProcessor(docTypeDAO, documentTypeService, i18nDAO, tagDAO)))
						.processor(this.register(new I18nConfigMessageProcessor(i18nDAO)))
						.processor(this.register(new RelationsConfigMessageProcessor(relationTypeDAO, relationTypeService, relationRoleDAO, i18nDAO)))
						.processor(this.register(new AppConfigMessageProcessor(appConfigDAO)))
						.processor(this.register(new LegalStatusConfigMessageProcessor(legalStatusDAO, i18nDAO)))
						.processor(this.register(new PartyConfigMessageProcessor(partyService, partyRelationService,
								partyRelationPartyService, partyDynamicDocumentManager)))
						.processor(this.register(new ExternalSourceConfigMessageProcessor(externalSourceDAO, partyDAO, i18nDAO)))
						.configLogProducer(configDataLogProducerBean(objectMapper, rabbitmqConnection))
						.withOrderPolicy(ProcessorOrderPolicyEnum.PROCESSOR)
						.build()))

				.withNewTenantEventConsumer(NewTenantEventConsumerBuilder.newBuilder(jdbi)
						.route(APP_NAME)
						.processor(this.register(new CitizenshipTenantMessageProcessor(citizenshipDAO)))
						.processor(this.register(new TagTenantMessageProcessor(tagDAO)))
						.processor(this.register(new DynamicDocTenantMessageProcessor(docTypeDAO, documentTypeService)))
						.processor(this.register(new RelationsTenantMessageProcessor(relationTypeDAO, relationRoleDAO)))
						.processor(this.register(new LegalStatusTenantMessageProcessor(legalStatusDAO)))
						.processor(this.register(new AppConfigTenantMessageProcessor(appConfigDAO)))
						.processor(this.register(new ExternalSourceTenantMessageProcessor(externalSourceDAO)))
						.processor(this.register(new I18nTenantMessageProcessor(i18nDAO)))
						.build())
				.buildListener();

		log.info("creating INITIALIZERS");
		BundleConfig bundleConfig = configuration.getBundleConfig();

		InitService bundleInitService = BundleInitServiceBuilder
				.producer(this.register(new BundleInitServiceProducer(rabbitmqConnection,
						bundleConfig.getInitialResendDelayMs(),
						bundleConfig.getListenerTimeoutMs())))
				.configLocation(bundleConfig.getConfigLocation())
				// .baseTempDir()
				.build();
		
		this.startRabbitConsumerAndProducers(bundleInitService, rabbitListener);
		this.afterServicesUp();

	}

	protected void initProxiesCache(PartyRegistryConfiguration configuration, Environment environment, ObjectMapper objectMapper, Jdbi jdbi,
			Connection rabbitmqConnection, Client proxiesClient) throws TimeoutException, IOException {
		ProxiesCacheConfig proxiesCacheConfig = ProxiesCacheConfig.builder()
				.partiesACLBaseURL(configuration.getAclConfig().getUrl())
				.queueId(configuration.getAclConfig().getRabbitQueue())
				.ignoreACL(configuration.getAclConfig().isIgnoreAcl())
				.build();
		ProxiesCache proxiesCache = this.register(new ProxiesCache(proxiesCacheConfig, environment, jdbi, proxiesClient, rabbitmqConnection, objectMapper));
		proxiesCache.initDWTask();
	}

	protected void afterServicesUp() {
		log.debug("application started");
	}

	protected ConfigDataLogProducer configDataLogProducerBean(ObjectMapper objectMapper, Connection rabbitmqConnection) {
		return this.register(new ConfigDataLogProducer(objectMapper, rabbitmqConnection, Constants.DEFAULT_EXCHANGE_NAME));
	}

	private Client initExternalServiceClient(PartyRegistryConfiguration configuration, Environment environment) {
		final Client client = new JerseyClientBuilder(environment)
				.using(configuration.getExternalServiceJerseyClient())
				.build("external-service-client")
				.register(new AddRequestId());
		return client;
	}

	private WebTarget initLauTarget(PartyRegistryConfiguration configuration, Environment environment) {
		final Client client = new JerseyClientBuilder(environment)
				.using(configuration.getJerseyClient())
				.build("lau-client")
				.register(new AddRequestId());
		WebTarget lau = client.target(configuration.getLauUrl());
		return lau;
	}

	private WebTarget initFileStoreTarget(PartyRegistryConfiguration configuration, Environment environment) {
		final Client client = new JerseyClientBuilder(environment)
				.using(configuration.getJerseyClient())
				.build("file-store-client")
				.register(new AddRequestId());
		WebTarget target = client.target(configuration.getFileStoreConfig().getUrl());
		return target;
	}

	private Sso2Client initSso2Client(PartyRegistryConfiguration configuration, Environment environment) {
		final Client client = new JerseyClientBuilder(environment)
				.using(configuration.getJerseyClient())
				.build("sso2-client")
				.register(new AddRequestId());

		WebTarget webTarget = client.target(configuration.getSso2Config().getUrl());
		Sso2Client sso2Cli = new Sso2Client(configuration.getSso2Config().getTasksAuthPhrase(), webTarget);
		return sso2Cli;
	}

	private Client initProxiesClient(PartyRegistryConfiguration configuration, Environment environment) {
		return new JerseyClientBuilder(environment)
				.using(configuration.getJerseyClient())
				.build("proxies-client")
				.register(new AddRequestId());
	}

	private RestClient initRestClient(PartyRegistryConfiguration configuration, Environment environment, Sso2Client sso2Client) {
		final Client client = new JerseyClientBuilder(environment)
				.using(configuration.getJerseyClient())
				.build("restclient")
				.register(new AddRequestId());
		RestClient restClient = new JaxRsClient(client, new Sso2AuthenticationProvider(sso2Client));
		return restClient;
	}

	protected void startRabbitConsumerAndProducers(InitService initService, RabbitListener rabbitListener) throws Exception {
		rabbitListener.start();
		initService.start();
	}

	protected PartyEventProducer buildPartyEventProducer(Environment environment, Jdbi jdbi, ObjectMapper objectMapper,
			Connection rabbitmqConnection, PartyDAO partyDAO, Clock appClock) throws IOException {

		PartyEventRabbitPublisher publisher = new PartyEventRabbitPublisher(rabbitmqConnection, objectMapper, partyDAO);

		PartyEventProducerImpl eventProducer = new PartyEventProducerImpl(environment, jdbi, objectMapper, publisher, appClock);

		eventProducer.start();

		return eventProducer;
	}

	protected Connection createRabbitmqConnection(PartyRegistryConfiguration configuration)
			throws IOException, TimeoutException {
		RabbitmqConfig rabbitmqConfig = configuration.getRabbitmqConfig();

		ConnectionFactory factory = new ConnectionFactory();

		if (rabbitmqConfig.getHost() != null) {
			factory.setHost(rabbitmqConfig.getHost());
		}
		if (rabbitmqConfig.getUser() != null) {
			factory.setUsername(rabbitmqConfig.getUser());
		}
		if (rabbitmqConfig.getPassword() != null) {
			factory.setPassword(rabbitmqConfig.getPassword());
		}
		if (rabbitmqConfig.getVirtualhost() != null) {
			factory.setVirtualHost(rabbitmqConfig.getVirtualhost());
		}
		if (rabbitmqConfig.getPort() != null) {
			factory.setPort(rabbitmqConfig.getPort());
		}
		factory.setAutomaticRecoveryEnabled(true);

		Connection connection = factory.newConnection();
		return connection;
	}

	protected void configureObjectMapper(ObjectMapper objectMapper) {
		objectMapper.registerModule(new JavaTimeModule());
		objectMapper
				.setTimeZone(TimeZone.getDefault())
				.disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);
	}

	protected void initAuth(Environment environment, Sso2Client sso2Cli) {
		AuthUtils.installAuthFilter(environment, sso2Cli, new SsoAuthorizer(sso2Cli));
	}

	protected Jdbi jdbi(final PartyRegistryConfiguration configuration, final Environment environment) {
		final JdbiFactory factory = new JdbiFactory();
		final Jdbi jdbi = factory.build(environment, configuration.getDatabase(), "PartyRegistryApplication");

		jdbi.configure(AbacoJdbiConfig.class, cfg -> cfg.setTablesPrefix("prt"));

		String driverClassName = Optional.ofNullable(configuration.getDatabase()
						.getDriverClass())
				.orElse("");

		if (driverClassName.equalsIgnoreCase("org.postgresql.Driver")) {
			jdbi.installPlugin(new PgJdbiPlugin());
		} else {
			jdbi.installPlugin(new OraJdbiPlugin());
		}
		return jdbi;
	}

	protected <T> T register(T service) {
		return service;
	}

	private void setupCORS(PartyRegistryConfiguration configuration, Environment environment) {
		if (!configuration.isCors()) {
			log.info("CORS is disabled");
			return;
		}

		log.info("CORS is enabled");

		Dynamic cors = environment.servlets().addFilter("CORS", CrossOriginFilter.class);
		cors.setInitParameter(CrossOriginFilter.ALLOWED_ORIGINS_PARAM, "*");
		cors.setInitParameter(CrossOriginFilter.ALLOWED_HEADERS_PARAM, "*");
		cors.setInitParameter(CrossOriginFilter.ALLOWED_METHODS_PARAM, "GET,PUT,POST,DELETE");

		// OPTIONS pre-flight request will be served by the filter ONLY and not
		// passed ahead
		// cors.setInitParameter(CrossOriginFilter.CHAIN_PREFLIGHT_PARAM,
		// "false");

		// Add URL mapping
		cors.addMappingForUrlPatterns(EnumSet.allOf(DispatcherType.class), false, "*");
	}

	private void initMultiTenant(Environment environment) {
		environment.jersey().register(new MultitenantFilter("tenant"));
	}
}
