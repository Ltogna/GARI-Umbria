package com.abacogroup.partyregistry.api;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@NoArgsConstructor
@SuperBuilder(setterPrefix = "set")
public class Citizenship {

	private String code;
	private String i18nCode;
}
