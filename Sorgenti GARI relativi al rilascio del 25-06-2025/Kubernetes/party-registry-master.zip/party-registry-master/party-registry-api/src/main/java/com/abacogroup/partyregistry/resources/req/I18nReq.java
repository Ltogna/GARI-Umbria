package com.abacogroup.partyregistry.resources.req;

import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.validation.constraints.NotNull;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder(setterPrefix = "set")
@NoArgsConstructor
public class I18nReq {

	@NotNull
	@JsonProperty("tenant_id")
	private String tenantId; // TODO: tenantId should be here because it is in the i18n.jsonl file.
	@NotNull
	@JsonProperty("table_name")
	private String tableName;
	@NotNull
	@JsonProperty("field_name")
	private String fieldName;
	@NotNull
	@JsonProperty("i18n_value")
	private String i18nValue;
	@NotNull
	@JsonProperty("lang")
	private String lang;
	@NotNull
	@JsonProperty("i18n_text")
	private String i18nText;
}
