package com.abacogroup.partyregistry.resources.publicapis.mapper;

import com.abacogroup.partyregistry.api.PartyRelationParty;
import com.abacogroup.partyregistry.api.v1.PartyRelationPartyResponseV1;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper
public interface RelationPartiesPublicMapper {

	RelationPartiesPublicMapper INSTANCE = Mappers.getMapper(RelationPartiesPublicMapper.class);

	PartyRelationPartyResponseV1 toResponseV1(PartyRelationParty res);

}
