package com.abacogroup.partyregistry.core.impl;

import com.abacogroup.embeddedqueue.rabbitmq.RabbitMqPublisher;
import com.abacogroup.partyregistry.core.dto.PartyQueueMessage;
import com.abacogroup.partyregistry.db.dao.PartyDAO;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.rabbitmq.client.Connection;
import java.io.IOException;
import java.util.Objects;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class PartyEventRabbitPublisher extends RabbitMqPublisher<PartyQueueMessage> {

	public static final String EXCHANGE = "party-exchange";
	private final PartyDAO partyDAO;

	public PartyEventRabbitPublisher(Connection connection, ObjectMapper objectMapper, PartyDAO partyDAO) throws IOException {
		super(Objects.requireNonNull(connection));
		this.partyDAO = partyDAO;

		super.setObjectMapper(objectMapper);
	}

	@Override
	protected String getExchangeName() {
		return EXCHANGE;
	}

	@Override
	protected String getRoutingKey(PartyQueueMessage element) {
		return element.getRoutingKey();
	}


	@Override
	protected byte[] getPayload(PartyQueueMessage element) throws Exception {
		return super.getPayload(element);
	}

}
