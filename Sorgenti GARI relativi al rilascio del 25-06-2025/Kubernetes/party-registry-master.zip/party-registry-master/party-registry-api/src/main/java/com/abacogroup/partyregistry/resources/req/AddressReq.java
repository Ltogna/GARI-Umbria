package com.abacogroup.partyregistry.resources.req;

import java.io.Serializable;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder(setterPrefix = "set")
@NoArgsConstructor
@Accessors(chain = true)
public class AddressReq implements Serializable {

	private String municipality;
	private String locality;
	private String street;
	private String houseNumber;
	private String postcode;
	private String details;
	private String note;
}
