package com.abacogroup.partyregistry.core;

import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.partyregistry.api.v1.TagResponseV1;
import com.abacogroup.partyregistry.api.v1.req.TagSearchRequestV1;
import com.abacogroup.partyregistry.resources.req.ReqContext;
import java.util.List;

public interface TagV1Service extends PublicService {

	InfiniteListResults<TagResponseV1> searchTags(ReqContext reqContext, TagSearchRequestV1 searchRequest, String nextKey);

	List<TagResponseV1> searchTagList(ReqContext reqContext, TagSearchRequestV1 searchRequest);
}
