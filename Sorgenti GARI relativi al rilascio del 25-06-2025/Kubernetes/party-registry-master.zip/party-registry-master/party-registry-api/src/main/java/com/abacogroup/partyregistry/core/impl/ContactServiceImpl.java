package com.abacogroup.partyregistry.core.impl;

import com.abacogroup.jdbi.criteria.Criteria;
import com.abacogroup.jdbi.orderby.OrderBy;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.partyregistry.api.ContactSearchResponse;
import com.abacogroup.partyregistry.api.ContactTypeEnum;
import com.abacogroup.partyregistry.api.PartyContact;
import com.abacogroup.partyregistry.core.ContactService;
import com.abacogroup.partyregistry.core.PartyEventProducer;
import com.abacogroup.partyregistry.core.PartyService;
import com.abacogroup.partyregistry.core.dto.PartyEventType;
import com.abacogroup.partyregistry.core.exceptions.ErrCodes;
import com.abacogroup.partyregistry.core.exceptions.InvalidPartyContactException;
import com.abacogroup.partyregistry.core.exceptions.InvalidPartyException;
import com.abacogroup.partyregistry.db.dao.ContactDAO;
import com.abacogroup.partyregistry.db.ntt.PartyContactEntity;
import com.abacogroup.partyregistry.db.ntt.PartyEntity;
import com.abacogroup.partyregistry.resources.mappers.PartyContactMapper;
import com.abacogroup.partyregistry.resources.req.ContactSearchReq;
import com.abacogroup.partyregistry.resources.req.PartyContactReq;
import com.abacogroup.partyregistry.resources.req.ReqContext;
import java.util.function.Consumer;
import java.util.function.Function;
import lombok.extern.slf4j.Slf4j;
import org.mapstruct.factory.Mappers;

@Slf4j
public class ContactServiceImpl implements ContactService {

	private final ContactDAO contactDAO;
	private final PartyService partyService;

	private final PartyEventProducer partyEventProducer;

	private PartyContactMapper contactMapper = Mappers.getMapper(PartyContactMapper.class);

	public ContactServiceImpl(ContactDAO contactDAO, PartyService partyService, PartyEventProducer partyEventProducer) {
		this.contactDAO = contactDAO;
		this.partyService = partyService;
		this.partyEventProducer = partyEventProducer;
	}

	@Override
	public PartyContact insert(ReqContext reqContext, Long partyId, PartyContactReq contact, boolean sendEvent) {
		loadCurrentParty(reqContext.getTenantId(), partyId);

		PartyContactEntity contactEntity = contactMapper.requestToEntity(contact);
		contactEntity.setPartyId(partyId);

		Long id = contactDAO.inTransaction(h -> {
			AuditHelper.setAuditForInsert(contactEntity, reqContext.getUsername(), contactDAO);

			Long pkid = contactDAO.insertContactRow(contactEntity);
			if (sendEvent) {
				partyEventProducer.pushPartyEvent(reqContext, partyId, PartyEventType.UPDATE_PARTY);
			}
			return pkid;
		});

		return contactDAO.loadContact(reqContext.getTenantId(), partyId, id)
				.map(contactMapper::entityToDto)
				.orElse(null);
	}

	@Override
	public PartyContact update(ReqContext reqContext, Long partyId, Long pkid, PartyContactReq contact) {
		loadCurrentParty(reqContext.getTenantId(), partyId);
		PartyContactEntity entity = contactDAO.loadContact(reqContext.getTenantId(), partyId, pkid)
				.map(partyContactEntity -> {
					contactMapper.updateEntity(contact, partyContactEntity);
					return partyContactEntity;
				})
				.orElseThrow(() -> new InvalidPartyContactException(ErrCodes.PARTY_CONTACT_NOT_FOUND, String.format("contact with id %d not found in party %d",
						pkid, partyId)));

		Long newPkid = contactDAO.inTransaction(handle -> {
			Consumer<PartyContactEntity> expire = handle::expireRow;
			Function<PartyContactEntity, Long> insert = handle::insertContactRow;
			Long id = AuditHelper.update(entity, reqContext.getUsername(), expire, insert, handle.getCurrentTimestamp());

			partyEventProducer.pushPartyEvent(reqContext, partyId, PartyEventType.UPDATE_PARTY);
			return id;
		});

		entity.setPkid(newPkid);
		return contactMapper.entityToDto(entity);
	}

	@Override
	public void expireContact(ReqContext reqContext, Long partyId, Long pkId) {
		loadCurrentParty(reqContext.getTenantId(), partyId);
		contactDAO.useTransaction(handle ->
				handle.loadContact(reqContext.getTenantId(), partyId, pkId)
						.ifPresent(e -> {
							Consumer<PartyContactEntity> expire = handle::expireRow;
							AuditHelper.expire(e, reqContext.getUsername(), expire, handle.getCurrentTimestamp());

							partyEventProducer.pushPartyEvent(reqContext, partyId, PartyEventType.UPDATE_PARTY);
						}));
	}

	@Override
	public void expireContactsByType(ReqContext reqContext, ContactTypeEnum contactType, Long partyId) {
		loadCurrentParty(reqContext.getTenantId(), partyId);
		contactDAO.useTransaction(handle -> {
			handle.loadContactsByTypeAndPartyId(reqContext.getTenantId(), partyId, contactType.name())
					.forEach(contact -> {
						Consumer<PartyContactEntity> expire = handle::expireRow;
						AuditHelper.expire(contact, reqContext.getUsername(), expire, handle.getCurrentTimestamp());
					});
		});
	}

	@Override
	public InfiniteListResults<ContactSearchResponse> search(ReqContext reqContext, ContactSearchReq searchRequest,
			String nextKey) {
		Criteria criteria = searchRequest.getCriteria(reqContext);
		OrderBy sort = searchRequest.getDefaultSort();
		InfiniteListResults<ContactSearchResponse> contacts = contactDAO.infinite(
				() -> contactDAO.search(criteria, sort, reqContext),
				nextKey, searchRequest.getPageSize());
		return contacts;
	}

	private PartyEntity loadCurrentParty(String tenantId, Long id) {
		return partyService.loadEntity(tenantId, id)
				.orElseThrow(() -> new InvalidPartyException(ErrCodes.PARTY_NOT_FOUND, String.format("party %s not found", id)));
	}

}
