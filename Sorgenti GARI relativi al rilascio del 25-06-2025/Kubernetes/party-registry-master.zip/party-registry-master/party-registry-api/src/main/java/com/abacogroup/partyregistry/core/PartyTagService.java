package com.abacogroup.partyregistry.core;

import com.abacogroup.partyregistry.api.PartyTag;
import com.abacogroup.partyregistry.api.Tag;
import com.abacogroup.partyregistry.resources.req.ReqContext;
import java.util.List;

public interface PartyTagService {

	List<PartyTag> getPartyTags(ReqContext reqContext, Long partyId);

	Tag attachTag(ReqContext reqContext, Long partyId, String tagCode);

	void detachTag(ReqContext reqContext, Long partyId, String tagCode);
}
