package com.abacogroup.partyregistry.core.impl;

import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.partyregistry.api.RoleCountDTO;
import com.abacogroup.partyregistry.core.PartyChecksService;
import com.abacogroup.partyregistry.db.dao.PartyChecksDAO;
import com.abacogroup.partyregistry.resources.req.ReqContext;

import java.util.List;

public class PartyChecksServiceImpl implements PartyChecksService {

	private final PartyChecksDAO partyChecksDAO;

	public PartyChecksServiceImpl(PartyChecksDAO partyChecksDAO) {
        this.partyChecksDAO = partyChecksDAO;
    }

	@Override
	public List<RoleCountDTO> countPartyRelationRoles(ReqContext reqContext, String partyCode, List<String> roleCodeList, String relationType, AbsoluteDate referenceDate) {
		return partyChecksDAO.countPartyRelationRoles(partyCode, roleCodeList, relationType, referenceDate, reqContext.getTenantId(), reqContext.getLang());
	}
}