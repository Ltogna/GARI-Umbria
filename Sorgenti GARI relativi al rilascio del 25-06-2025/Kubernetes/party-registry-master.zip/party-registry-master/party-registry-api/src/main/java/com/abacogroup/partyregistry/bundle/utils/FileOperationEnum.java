package com.abacogroup.partyregistry.bundle.utils;

public enum FileOperationEnum {
	DELETE,
	DEFAULT,
}
