package com.abacogroup.partyregistry.resources.publicapis;

import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.partyregistry.api.v1.PartyRelationPartyResponseV1;
import com.abacogroup.partyregistry.core.AclService;
import com.abacogroup.partyregistry.core.PartyRelationPartyService;
import com.abacogroup.partyregistry.resources.PublicResourceConstants;
import com.abacogroup.partyregistry.resources.publicapis.mapper.RelationPartiesPublicMapper;
import com.abacogroup.partyregistry.resources.req.PartyRelationPartySearchReq;
import com.abacogroup.partyregistry.resources.req.ReqContext;
import io.dropwizard.auth.Auth;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.annotation.security.RolesAllowed;
import jakarta.ws.rs.DefaultValue;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.HeaderParam;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.MediaType;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Path(PublicResourceConstants.API_V1_PUB + "/parties/{partyId}/relation-types/{relationId}/relations")
@Produces(MediaType.APPLICATION_JSON)
@Tag(name = "party relations", description = "Operations on party relation items")
public class PartyRelationPartiesPublicResource {

	private final AclService aclService;
	private final PartyRelationPartyService partyRelationPartyService;

	public PartyRelationPartiesPublicResource(AclService aclService, PartyRelationPartyService partyRelationPartyService) {
		this.aclService = aclService;
		this.partyRelationPartyService = partyRelationPartyService;
	}

	@GET
	@RolesAllowed("PARTY-REGISTRY|READ")
	@Operation(summary = "List of party's relations", description = "Get the list of party's relations for a given relation type")
	@ApiResponses({
			@ApiResponse(responseCode = "200", description = "Successfully, returns a list of party's relations for a given relation type (sorted/filtered)",
					content = @Content(mediaType = "application/json",
							schema = @Schema(ref = "#/components/schemas/InfiniteListResultsPartyRelationPartyResponseV1")))
	})
	public InfiniteListResults<PartyRelationPartyResponseV1> search(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "the tenant ID") @PathParam("tenant") String tenantId,

			@Parameter(description = "the party ID") @PathParam("partyId") Long partyId,
			@Parameter(description = "the relation ID") @PathParam("relationId") Long relationId,
			@Parameter(description = "Can be supplied to obtain the records that follows those obtained by a previous call")
			@QueryParam("nextKey") String nextKey) {
		//      @BeanParam PartyRelationPartySearchReq searchReq) {

		ReqContext reqContext = new ReqContext(user, lang);
		aclService.canRead(reqContext, partyId);
		return this.partyRelationPartyService.search(reqContext, partyId, relationId, new PartyRelationPartySearchReq(), nextKey)
				.map(RelationPartiesPublicMapper.INSTANCE::toResponseV1);
	}


}

