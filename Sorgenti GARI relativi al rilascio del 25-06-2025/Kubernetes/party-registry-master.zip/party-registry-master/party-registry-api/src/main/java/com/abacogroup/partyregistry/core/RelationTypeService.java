package com.abacogroup.partyregistry.core;

import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.partyregistry.api.RelationType;
import com.abacogroup.partyregistry.db.ntt.RelationTypeEntity;
import com.abacogroup.partyregistry.resources.req.RelationTypeSearchReq;
import com.abacogroup.partyregistry.resources.req.ReqContext;
import java.util.Optional;

public interface RelationTypeService {

	InfiniteListResults<RelationType> search(ReqContext reqContext, RelationTypeSearchReq searchRequest, String nextKey);

	Optional<RelationType> getByCode(ReqContext reqContext, String code);

	Optional<RelationTypeEntity> findActiveEntityByCode(String tenantId, String code);

	void expireInCascade(String tenantId, String code);

	/**
	 * Non è previsto update
	 *
	 * @param relationTypeReq
	 * @return
	 */
	/*RelationType save(ReqContext context, RelationTypeReq relationTypeReq);

	void expire(ReqContext context, String code);*/

}
