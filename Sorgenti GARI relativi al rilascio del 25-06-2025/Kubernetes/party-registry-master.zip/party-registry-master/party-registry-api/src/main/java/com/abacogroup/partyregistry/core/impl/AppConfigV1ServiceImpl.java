package com.abacogroup.partyregistry.core.impl;

import com.abacogroup.partyregistry.api.v1.AppConfigResponseV1;
import com.abacogroup.partyregistry.core.AppConfigV1Service;
import com.abacogroup.partyregistry.db.dao.AppConfigDAO;
import com.abacogroup.partyregistry.resources.mappers.AppConfigMapper;
import com.abacogroup.partyregistry.resources.publicapis.mapper.AppConfigResMapper;
import com.abacogroup.partyregistry.resources.req.ReqContext;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

public class AppConfigV1ServiceImpl implements AppConfigV1Service {

	private final AppConfigDAO dao;

	public AppConfigV1ServiceImpl(AppConfigDAO dao) {
		this.dao = dao;
	}

	@Override
	public List<AppConfigResponseV1> searchAll(ReqContext reqContext) {
		return dao.searchAll(reqContext.getTenantId())
				.stream()
				.map(AppConfigMapper.INSTANCE::toConfigRes)
				.map(AppConfigResMapper.INSTANCE::toV1).collect(Collectors.toList());
	}

	@Override
	public Optional<AppConfigResponseV1> searchByKey(ReqContext reqContext, String key) {
		return dao.searchAll(reqContext.getTenantId())
				.stream()
				.map(AppConfigMapper.INSTANCE::toConfigRes)
				.map(AppConfigResMapper.INSTANCE::toV1)
				.filter(k -> k.getConfigurationKey().equalsIgnoreCase(key))
				.findFirst();
	}
}
