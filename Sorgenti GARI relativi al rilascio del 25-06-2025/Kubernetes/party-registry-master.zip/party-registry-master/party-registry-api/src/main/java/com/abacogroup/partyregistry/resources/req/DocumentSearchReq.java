package com.abacogroup.partyregistry.resources.req;

import com.abacogroup.jdbi.criteria.Criteria;
import com.abacogroup.jdbi.criteria.CriteriaBuilder;
import com.abacogroup.jdbi.orderby.OrderByBuilder;
import com.abacogroup.jdbi.orderby.OrderByElement;
import com.abacogroup.jdbi.orderby.SortDirection;
import com.abacogroup.partyregistry.resources.ResourceConstants;
import com.fasterxml.jackson.annotation.JsonIgnore;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.QueryParam;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

@Data
@NoArgsConstructor
@Accessors(chain = true)
public class DocumentSearchReq implements BaseSearchReq {

	@Parameter(in = ParameterIn.PATH, description = "party ID")
	@PathParam("partyId")
	private Long partyId;

	@Parameter(in = ParameterIn.PATH, description = "definition code")
	@PathParam("definitionCode")
	private String definitionCode;

	@Parameter(in = ParameterIn.QUERY, description = "document ID")
	@QueryParam("documentId")
	private Long documentId;

	@Override
	@JsonIgnore
	@Schema(hidden = true)
	public int getPageSize() {
		return ResourceConstants.PAGE_SIZE;
	}

	@Override
	@JsonIgnore
	@Schema(hidden = true)
	public Criteria getCriteria(ReqContext reqContext) {
		List<Criteria> specs = new ArrayList<>();

		specs.add(CriteriaBuilder.number("party_id").eq(partyId));
		specs.add(CriteriaBuilder.string("definition_code").eq(definitionCode));

		Optional.ofNullable(getDocumentId())
				.ifPresent(v -> specs.add(CriteriaBuilder.number("document_id").eq(v)));

		return CriteriaBuilder.and(specs.toArray(new Criteria[0]));
	}

	@Override
	@JsonIgnore
	@Schema(hidden = true)
	public OrderByElement getSort() {
		return OrderByBuilder
				.field("definition_code")
				.direction(SortDirection.ASC);
	}

}
