package com.abacogroup.partyregistry.resources.mappers;

import com.abacogroup.partyregistry.dto.v1.PartyRelationExternalDtoV1;
import com.abacogroup.partyregistry.dto.v1.PartyRelationItemExternalDtoV1;
import com.abacogroup.partyregistry.resources.req.rel.CreatePartyRelationReq;
import com.abacogroup.partyregistry.resources.req.rel.PartyRelationItemReq;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

@Mapper
public interface PartyRelationsMapper {

	PartyRelationsMapper INSTANCE = Mappers.getMapper(PartyRelationsMapper.class);

	@Mapping(target = "relationTypeCode", source = "relationCode")
	@Mapping(target = "relationItemReq", ignore = true)
	CreatePartyRelationReq relationExternalToCreateReq(PartyRelationExternalDtoV1 externalDto);

	@Mapping(target = "relatedPartyId", source = "partyId")
	@Mapping(target = "relatedRoleCode", source = "externalDto.roleCode")
	PartyRelationItemReq relationItemExternalToCreateReq(PartyRelationItemExternalDtoV1 externalDto, Long partyId);

}
