package com.abacogroup.partyregistry.core.dynamicdoc.validators;

import com.abacogroup.dynamicdocuments.bean.Document;
import com.abacogroup.dynamicdocuments.bean.InsertDocument;
import com.abacogroup.partyregistry.core.dynamicdoc.DocumentValidator;
import com.abacogroup.partyregistry.core.dynamicdoc.PartyDynamicDocumentManager;
import com.abacogroup.partyregistry.core.exceptions.ErrCodes;
import com.abacogroup.partyregistry.core.exceptions.InvalidDocumentException;
import com.abacogroup.partyregistry.resources.req.ReqContext;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.time.OffsetDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

public class EarningsValidator implements DocumentValidator {

	public static final String EARNINGS = "EARNINGS";

	@Override
	public void validate(InsertDocument document,
			PartyDynamicDocumentManager documentManager,
			ReqContext reqContext) {
		List<Document> documents = documentManager.getByPartyIdAndCode(reqContext, document.getBusinessId(),
				document.getDefCode());
		ObjectMapper mapper = new ObjectMapper();
		OffsetDateTime startIns = document.getDoc().getValidFrom();
		OffsetDateTime endIns = document.getDoc().getValidTo();
		if ((startIns.isAfter(endIns))) {
			throw new InvalidDocumentException(ErrCodes.DYNAMIC_DOCUMENT_ERR, "Invalid dates");
		}
		documents.forEach(d -> {
			OffsetDateTime start = convertDate(
					mapper.convertValue(d.getValidFrom(), new TypeReference<ArrayList<String>>() {
					}).get(0)
			);
			OffsetDateTime end = convertDate(
					mapper.convertValue(d.getValidTo(), new TypeReference<ArrayList<String>>() {
					}).get(0)
			);
			if ((startIns.equals(start) || endIns.equals(end)) ||
					(startIns.isBefore(start) && endIns.isAfter(end)) ||
					(startIns.isAfter(start) && endIns.isBefore(end)) ||
					(startIns.isBefore(start) && endIns.isAfter(start) && endIns.isBefore(end)) ||
					(startIns.isAfter(start) && startIns.isBefore(end) && endIns.isAfter(end))) {
				throw new InvalidDocumentException(ErrCodes.DYNAMIC_DOCUMENT_ERR, "Earnings already recorded for this period");
			}
		});

	}

	@Override
	public String getDefinitionCode() {
		return EARNINGS;
	}

	private OffsetDateTime convertDate(String date) {
		if (null != date) {
			return OffsetDateTime.parse(date, DateTimeFormatter.ISO_OFFSET_DATE_TIME);
		} else {
			throw new InvalidDocumentException(ErrCodes.DYNAMIC_DOCUMENT_ERR, "Invalid dates");
		}

	}
}
