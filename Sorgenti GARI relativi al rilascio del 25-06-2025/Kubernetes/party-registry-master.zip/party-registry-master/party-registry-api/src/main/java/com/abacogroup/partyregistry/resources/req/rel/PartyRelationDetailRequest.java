package com.abacogroup.partyregistry.resources.req.rel;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

@Data
@NoArgsConstructor
@Accessors(chain = true)
public class PartyRelationDetailRequest {

	private String note;

}
