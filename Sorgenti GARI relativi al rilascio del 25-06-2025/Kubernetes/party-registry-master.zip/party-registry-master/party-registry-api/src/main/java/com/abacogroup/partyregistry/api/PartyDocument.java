package com.abacogroup.partyregistry.api;

import com.abacogroup.dynamicdocuments.bean.SummaryFieldDefinition;
import java.util.LinkedHashMap;
import java.util.List;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@NoArgsConstructor
@SuperBuilder(setterPrefix = "set")
public class PartyDocument {

	private String tenantId;
	private Long partyId;
	private String definitionCode;
	private Long documentId;
	private String definitionCodeI18n;
	private String bucketName;

	private List<SummaryFieldDefinition> summaryFieldDefinitions;
	private LinkedHashMap<String, Object> data;

}
