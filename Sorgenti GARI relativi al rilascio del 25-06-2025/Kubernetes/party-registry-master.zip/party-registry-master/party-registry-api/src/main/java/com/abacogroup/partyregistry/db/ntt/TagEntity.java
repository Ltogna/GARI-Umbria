package com.abacogroup.partyregistry.db.ntt;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;
import org.jdbi.v3.core.mapper.reflect.ColumnName;

@Data
@SuperBuilder(setterPrefix = "set")
@NoArgsConstructor
public class TagEntity implements MultiTenantEntity<String> {

	private Long id;
	private String tenantId;

	@ColumnName("tag_code")
	private String code;
}
