package com.abacogroup.partyregistry.core.impl.validaor;

import com.abacogroup.partyregistry.api.PartyTypeEnum;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.ArrayList;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder.Default;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;
import lombok.experimental.SuperBuilder;

@Data
@Accessors(chain = true)
@SuperBuilder(setterPrefix = "set")
@AllArgsConstructor
@NoArgsConstructor
public class RegexCodeConfiguration {

	@JsonProperty("L")
	@Default
	private List<String> legal = new ArrayList<>();

	@JsonProperty("N")
	@Default
	private List<String> natural = new ArrayList<>();

	public List<String> getRegexes(PartyTypeEnum partyType) {
		switch (partyType) {
		case L: {
			return getLegal();
		}
		case N: {
			return getNatural();
		}
		default: {
			// TODO error? null?
			return List.of();
		}
		}
	}

}
