package com.abacogroup.partyregistry.core.impl;

import com.abacogroup.jdbi.criteria.Criteria;
import com.abacogroup.jdbi.orderby.OrderBy;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.partyregistry.api.RelationType;
import com.abacogroup.partyregistry.core.BundleConstants;
import com.abacogroup.partyregistry.core.RelationTypeService;
import com.abacogroup.partyregistry.db.dao.RelationRoleDAO;
import com.abacogroup.partyregistry.db.dao.RelationTypeDAO;
import com.abacogroup.partyregistry.db.ntt.RelationRoleEntity;
import com.abacogroup.partyregistry.db.ntt.RelationTypeEntity;
import com.abacogroup.partyregistry.resources.req.RelationTypeSearchReq;
import com.abacogroup.partyregistry.resources.req.ReqContext;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.Optional;
import java.util.function.Consumer;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class RelationTypeServiceImpl implements RelationTypeService {

	private final RelationTypeDAO relationTypeDAO;
	private ObjectMapper mapper = new ObjectMapper();

	public RelationTypeServiceImpl(RelationTypeDAO relationTypeDAO) {
		this.relationTypeDAO = relationTypeDAO;
	}

	@Override
	public InfiniteListResults<RelationType> search(ReqContext reqContext, RelationTypeSearchReq searchRequest,
			String nextKey) {
		Criteria criteria = searchRequest.getCriteria(reqContext);
		OrderBy sort = searchRequest.getSort();
		return relationTypeDAO.infinite(
				() -> relationTypeDAO.searchAll(criteria, sort, reqContext),
				nextKey, searchRequest.getPageSize());
	}

	@Override
	public Optional<RelationType> getByCode(ReqContext context, String code) {
		return relationTypeDAO.searchByCode(code, context);
	}

	/*@Override
	public RelationType save(ReqContext context, RelationTypeReq relationTypeReq) {
		Optional<RelationTypeEntity> dbEntity = loadByCode(context.getTenantId(), relationTypeReq.getCode(), true);
		if (dbEntity.isEmpty()) {
			RelationTypeEntity entity = RelationTypeMapper.INSTANCE.reqToEntity(relationTypeReq);
			entity.setTenantId(context.getTenantId());
			return insert(context, entity);
		}
		log.warn("Trying to save a record with code {}, but the same code already exists: id = {}, dt_delete = {}",
				relationTypeReq.getCode(), dbEntity.get().getId(), dbEntity.get().getDtDelete());

		throw new InvalidRelationTypeException(String.format("the relation %s exists", relationTypeReq.getCode()));
	}

	@Override
	public void expire(ReqContext context, String code) {
		relationTypeDAO.useTransaction(handle -> {
			handle.findOne(context.getTenantId(), code)
					.ifPresent(e -> {
						Consumer<RelationTypeEntity> expireFun = handle::expireRow;
						AuditHelper.expire(e, context.getUsername(), expireFun, handle.getCurrentTimestamp());
					});
		});
	}*/

	protected Optional<RelationTypeEntity> loadByCode(String tenantId, String code, Boolean includeDeleted) {
		if (includeDeleted) {
			return relationTypeDAO.findOneIncludeDeleted(tenantId, code);
		}
		return findActiveEntityByCode(tenantId, code);
	}

	@Override
	public Optional<RelationTypeEntity> findActiveEntityByCode(String tenantId, String code) {
		return relationTypeDAO.findOne(tenantId, code);
	}

	private RelationType insert(ReqContext context, RelationTypeEntity entity) {
		AuditHelper.setAuditForInsert(entity, context.getUsername(), relationTypeDAO);
		Long id = relationTypeDAO.insert(entity);
		entity.setId(id);
		return getByCode(context, entity.getCode())
				.orElse(null);
	}

	@Override
	public void expireInCascade(String tenantId, String code) {
		relationTypeDAO.useTransaction(handle -> {
			handle.findOne(tenantId, code)
					.ifPresent(e -> {
						RelationRoleDAO relationRoleDAO = handle.getHandle().attach(RelationRoleDAO.class);
						deleteAllRoles(tenantId, e.getCode(), relationRoleDAO);

						Consumer<RelationTypeEntity> expireFun = handle::expireRow;
						AuditHelper.expire(e, BundleConstants.SYSTEM_USER, expireFun, handle.getCurrentTimestamp());
					});
		});
	}

	protected void deleteAllRoles(String tenantId, String relationTypeCode, RelationRoleDAO relationRoleDAO) {
		relationRoleDAO.findByTypeCode(tenantId, relationTypeCode)
				.forEach(role -> {
					Consumer<RelationRoleEntity> expireFun = relationRoleDAO::expireRow;
					AuditHelper.expire(role, BundleConstants.SYSTEM_USER, expireFun, relationRoleDAO.getCurrentTimestamp());
				});
	}
}
