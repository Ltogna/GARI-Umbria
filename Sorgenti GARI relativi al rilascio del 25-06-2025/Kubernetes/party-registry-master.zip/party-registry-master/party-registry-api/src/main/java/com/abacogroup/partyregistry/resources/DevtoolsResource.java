package com.abacogroup.partyregistry.resources;

import static com.abacogroup.bundles.Constants.TOPIC_PREFIX;

import com.abacogroup.bundles.Constants;
import com.abacogroup.bundles.db.dao.RegistryDAO;
import com.abacogroup.bundles.initializer.BundleInitServiceBuilder;
import com.abacogroup.bundles.initializer.impl.BundleInitServiceProducer;
import com.abacogroup.bundles.initializer.impl.FileSupport;
import com.abacogroup.bundles.initializer.impl.exceptions.BundleException;
import com.abacogroup.dynamicdocuments.bean.Document;
import com.abacogroup.dynamicdocuments.bean.InsertDocument;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.partyregistry.api.ContactTypeEnum;
import com.abacogroup.partyregistry.api.GenderEnum;
import com.abacogroup.partyregistry.api.PartyTypeEnum;
import com.abacogroup.partyregistry.core.dynamicdoc.DynamicDocumentUtils;
import com.abacogroup.partyregistry.dto.v1.AddressExternalDtoV1;
import com.abacogroup.partyregistry.dto.v1.ExternalSourceDtoV1;
import com.abacogroup.partyregistry.dto.v1.PartyContactExternalDtoV1;
import com.abacogroup.partyregistry.dto.v1.PartyExternalDtoV1;
import com.abacogroup.partyregistry.dto.v1.PartyRelationExternalDtoV1;
import com.abacogroup.partyregistry.dto.v1.PartyRelationItemExternalDtoV1;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.rabbitmq.client.AMQP;
import com.rabbitmq.client.BuiltinExchangeType;
import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import io.swagger.v3.oas.annotations.Hidden;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.TimeoutException;
import lombok.Data;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.glassfish.jersey.media.multipart.FormDataContentDisposition;
import org.glassfish.jersey.media.multipart.FormDataParam;
import org.jdbi.v3.core.Jdbi;

@Hidden
@Path("/devtools")
@Produces(MediaType.APPLICATION_JSON)
@Slf4j
public class DevtoolsResource {

	private final ObjectMapper objectMapper = new ObjectMapper();
	private final Connection rabbitmqConnection;
	private final Jdbi jdbi;

	public DevtoolsResource(Connection rabbitmqConnection, Jdbi jdbi) {
		this.rabbitmqConnection = rabbitmqConnection;
		this.jdbi = jdbi;
	}

	public static void flushTenant(Jdbi jdbi, String newTenant) {
		jdbi.useTransaction(handle -> {

			handle.execute("delete from doc_document_content where doc_document_id in (select id from doc_document where tenant_id = ?)", newTenant);
			handle.execute("delete from doc_document where tenant_id = ?", newTenant);
			handle.execute("delete from doc_type_spec where doc_type_id in (select id from doc_type where tenant_id = ?)", newTenant);
			handle.execute("delete from doc_type where tenant_id = ?", newTenant);

			handle.execute("delete from prt_parties_documents where tenant_id = ?", newTenant);
			handle.execute("delete from prt_doc_type where tenant_id = ?", newTenant);

			handle.execute("delete from prt_citizenship where tenant_id = ?", newTenant);
			handle.execute("delete from prt_parties_tags where party_id in (select id from prt_parties where tenant_id = ?)", newTenant);

			handle.execute("delete from prt_party_relation_parties where party_relation_id in ("
					+ "select id from prt_party_relations where party_id in ("
					+ "select id from prt_parties where tenant_id = ? ))   ", newTenant);

			handle.execute("delete from prt_party_relation_details where party_relation_id in ("
					+ "select id from prt_party_relations where party_id in ("
					+ "select id from prt_parties where tenant_id = ? ))   ", newTenant);

			handle.execute("delete from prt_party_relations where party_id in (select id from prt_parties where tenant_id = ? )  ", newTenant);

			handle.execute("delete from prt_relation_roles where type_id in (select id from prt_relation_types where tenant_id = ?)  ", newTenant);
			handle.execute("delete from prt_relation_types where tenant_id = ? ", newTenant);

			handle.execute("delete from prt_parties_detail where party_id in (select id from prt_parties where tenant_id = ?)", newTenant);
			handle.execute("delete from prt_parties where tenant_id = ?", newTenant);

			handle.execute("delete from prt_relation_roles where type_id in (select id from prt_relation_types where tenant_id = ?)", newTenant);
			handle.execute("delete from prt_relation_types where tenant_id = ?", newTenant);

			handle.execute("delete from prt_tags where tenant_id = ?", newTenant);
			handle.execute("delete from prt_i18n_values where tenant_id = ?", newTenant);

			handle.execute("delete from prt_addresses where id not in ("
					+ "select fk_address_residential from prt_parties_detail "
					+ "union aLL "
					+ "select fk_address_home from prt_parties_detail "
					+ "union aLL "
					+ "select fk_address_billing from prt_parties_detail "
					+ ")");

			handle.execute("delete from bnd_registry where tenant_id = ?", newTenant);
			handle.execute("delete from bnd_tenant where tenant_id = ?", newTenant);
		});
	}

	@SneakyThrows
	@POST
	@Path("/bundle/install")
	public Object install(@NotNull @Valid BundleInstallReq bundleInstallReq) {
		String bundlePath = bundleInstallReq.getPath();
		return doInstall(bundlePath);
	}

	@POST
	@Consumes(MediaType.MULTIPART_FORM_DATA)
	@Path("/bundle/install")
	@SneakyThrows
	public Object install(
			@FormDataParam("bundle") final InputStream fileInputStream,
			@FormDataParam("bundle") final FormDataContentDisposition contentDispositionHeader) {
		java.nio.file.Path workDir = createWorkDir(String.format("%s/bundles/devtools", System.getProperty("java.io.tmpdir")));

		FileSupport.unzip(fileInputStream, workDir);

		String bundlePath = workDir.toFile().listFiles()[0].getAbsolutePath();
		return doInstall(bundlePath);
	}

	@SneakyThrows
	@GET
	@Path("/bundle/registry")
	public Object getRegistry() {
		RegistryDAO registryDAO = jdbi.onDemand(RegistryDAO.class);

		return registryDAO.findAll();
	}

	@SneakyThrows
	@POST
	@Path("/tenants/{newTenant}")
	public Object newTenant(@PathParam("newTenant") String newTenant) {
		this.pushNewTenantEvent(newTenant);
		return Map.of("result", "ok");
	}

	@SneakyThrows
	@DELETE
	@Path("/tenants/{newTenant}")
	public Object deleteTenant(@PathParam("newTenant") String newTenant) {

		flushTenant(jdbi, newTenant);

		return Map.of("result", "ok");
	}

	@SneakyThrows
	@GET
	@Path("/external/{code}")
	public ExternalSourceDtoV1 mockExternalSource(@PathParam("code") String code) {
		if (StringUtils.isNumeric(code)) {
			return ExternalSourceDtoV1.builder()
					.setPartyData(
							PartyExternalDtoV1.builder()
									.setPartyType(PartyTypeEnum.L)
									.setGender(null)
									.setLastName("TEST PARTY")
									.setFirstName(null)
									.setTaxCode(code)
									.setVatNumber(code)
									.setCode(code)
									.setLegalStatus("ALTRI")
									.setBirthDate(AbsoluteDate.of("19500521"))
									.setDeathDate(AbsoluteDate.of("99991231"))
									.setBirthMunicipality("ITA_12_058091")
									.setNationality("ITA")
									.setAddressResidential(AddressExternalDtoV1.builder()
											.setMunicipality("ITA_12_058091")
											.setLocality("Loc. Abcd")
											.setStreet("via Roma")
											.setHouseNumber("99")
											.setPostcode("12345")
											.setDetails("details")
											.setNote("note")
											.build())
									.build())
					.setDocuments(getMockedDocuments(code))
					.setRelations(getMockedPartyRelations(code))
					.setContacts(getMockedPartyContacts(code))
					.build();
		} else {
			return ExternalSourceDtoV1.builder()
					.setPartyData(PartyExternalDtoV1.builder()
							.setPartyType(PartyTypeEnum.N)
							.setGender(GenderEnum.F)
							.setLastName("TEST")
							.setFirstName("PARTY")
							.setTaxCode(code)
							.setVatNumber(null)
							.setCode(code)
							.setLegalStatus("ASSOCIAZIONI")
							.setBirthDate(AbsoluteDate.of("19890530"))
							.setDeathDate(AbsoluteDate.of("99991231"))
							.setBirthMunicipality("ITA_12_058091")
							.setNationality("ITA")
							.setAddressResidential(AddressExternalDtoV1.builder()
									.setMunicipality("ITA_12_058091")
									.setLocality("Loc. Abcd")
									.setStreet("via Roma")
									.setHouseNumber("99")
									.setPostcode("12345")
									.setDetails("details")
									.setNote("note")
									.build())
							.build())
					.setDocuments(getMockedDocuments(code))
					.setRelations(getMockedPartyRelations(code))
					.setContacts(getMockedPartyContacts(code))
					.build();
		}
	}

	private List<InsertDocument> getMockedDocuments(String code) {
		List<InsertDocument> insertDocuments = new ArrayList<>();
		Document doc = new Document();
		InsertDocument ins = new InsertDocument();
		Map<String, Object> fields = new HashMap<>();
		if (StringUtils.isNumeric(code)) {
			Map<String, Object> idDoc = Map.of(
					"id_type", "id_card", //ID_CARD
					"release_agent", "Comune di Verona",
					"release_date", "2011-12-03T09:06:00+02:00",
					"expiration_date", "2050-12-09T09:06:00+02:00",
					"number", "2"
			);
			fields = DynamicDocumentUtils.createDoc(idDoc);
			doc.setFields(fields);
			ins.setDefCode("ID");
			ins.setDoc(doc);
			ins.setBusinessId(1L); //will be replaced
			insertDocuments.add(ins);
		} else {
			Map<String, Object> passportDoc = Map.of(
					"id_type", "passport", //ID_CARD
					"release_agent", "Comune di Verona",
					"release_date", "2011-12-03T09:06:00+02:00",
					"expiration_date", "2050-12-09T09:06:00+02:00",
					"number", "2"
			);
			fields = DynamicDocumentUtils.createDoc(passportDoc);
			doc.setFields(fields);
			ins.setDefCode("ID");
			ins.setDoc(doc);
			ins.setBusinessId(1L); //will be replaced
			insertDocuments.add(ins);
		}
		return insertDocuments;
	}

	private List<PartyRelationExternalDtoV1> getMockedPartyRelations(String code) {
		List<PartyRelationExternalDtoV1> mockedRelations = new ArrayList<>();
		if (StringUtils.isNumeric(code)) {
			PartyRelationExternalDtoV1 relation1 = new PartyRelationExternalDtoV1();
			relation1.setRelationCode("RIFERIMENTI_CONTATTI");
			relation1.setNote("Riferimenti contatti");

			List<PartyRelationItemExternalDtoV1> parties1 = new ArrayList<>();

			PartyRelationItemExternalDtoV1 party1 = new PartyRelationItemExternalDtoV1();
			String codeN = "MMMRRR96A11B654L0";
			party1.setPartyData(getMockedPartyData(codeN, PartyTypeEnum.N, "ROSSI", "MARIO", null, codeN));
			party1.setRoleCode("CONTATTO_AMMINISTRATIVO");
			party1.setDtStart(AbsoluteDate.of(LocalDateTime.now()));
			party1.setDtEnd(AbsoluteDate.of("20251231"));
			parties1.add(party1);

			relation1.setParties(parties1);
			mockedRelations.add(relation1);
		} else {
			PartyRelationExternalDtoV1 relation2 = new PartyRelationExternalDtoV1();
			relation2.setRelationCode("NUCLEO_FAMILIARE");
			relation2.setNote("la mia famiglia");

			List<PartyRelationItemExternalDtoV1> parties2 = new ArrayList<>();
			String codeL = "11223344550";
			PartyRelationItemExternalDtoV1 party2 = new PartyRelationItemExternalDtoV1();
			party2.setPartyData(getMockedPartyData(codeL, PartyTypeEnum.L, "SOCIETA", null, codeL, codeL));
			party2.setRoleCode("MOGLIE");
			party2.setDtStart(AbsoluteDate.of(LocalDateTime.now()));
			parties2.add(party2);

			PartyRelationItemExternalDtoV1 party3 = new PartyRelationItemExternalDtoV1();
			party3.setPartyData(getMockedPartyData(code, PartyTypeEnum.N, "SAME", "GUY", null, code));
			party3.setRoleCode("ALTRO");
			party3.setDtStart(AbsoluteDate.of(LocalDateTime.now()));
			parties2.add(party3);

			relation2.setParties(parties2);
			mockedRelations.add(relation2);
		}

		return mockedRelations;
	}

	private List<PartyContactExternalDtoV1> getMockedPartyContacts(String code) {
		List<PartyContactExternalDtoV1> mockedContacts = new ArrayList<>();

		PartyContactExternalDtoV1 contact1 = new PartyContactExternalDtoV1();
		contact1.setContactType(ContactTypeEnum.PEC);
		contact1.setSubType("WORK");
		contact1.setContactValue("work@pec.it");
		contact1.setNote("Work email");

		PartyContactExternalDtoV1 contact2 = new PartyContactExternalDtoV1();
		contact2.setContactType(ContactTypeEnum.PEC);
		contact2.setSubType("INTERNSHIP");
		contact2.setContactValue("internship@pec.it");
		contact2.setNote("Internship email");

		PartyContactExternalDtoV1 contact3 = new PartyContactExternalDtoV1();
		contact3.setContactType(ContactTypeEnum.PHONE);
		contact3.setSubType("PROFESSIONAL");
		contact3.setContactValue("654654545");
		contact3.setNote("PRO PHONE");

		mockedContacts.add(contact1);

		if (StringUtils.isNumeric(code)) {
			mockedContacts.add(contact2);
			mockedContacts.add(contact3);
		}
		return mockedContacts;
	}

	private PartyExternalDtoV1 getMockedPartyData(String code, PartyTypeEnum partyType, String lastName, String firstName, String vatNumber, String taxCode) {
		return PartyExternalDtoV1.builder()
				.setPartyType(partyType)
				.setGender(null)
				.setLastName(lastName)
				.setFirstName(firstName)
				.setTaxCode(taxCode)
				.setVatNumber(vatNumber)
				.setCode(code)
				.setLegalStatus("ALTRI")
				.setBirthDate(AbsoluteDate.of("19800101"))
				.setDeathDate(AbsoluteDate.of("99991231"))
				.setBirthMunicipality("ITA_12_058091")
				.setNationality("ITA")
				.build();
	}
	//---

	private java.nio.file.Path createWorkDir(String baseDir) {
		try {
			String wd = Optional.ofNullable(baseDir)
					.orElse(System.getProperty("java.io.tmpdir"));
			new File(wd).mkdirs();
			java.nio.file.Path workingDir = Files.createTempDirectory(java.nio.file.Path.of(wd), "bundle_");
			log.info("devtools work directory created: {}", workingDir);
			return workingDir;
		} catch (Exception ex) {
			throw new BundleException("error creating devtools work dir in " + baseDir, ex);
		}
	}

	private Map<String, String> doInstall(String bundlePath) {
		log.info("BUILDING CUSTOM INIT SERIVICE FOR {}", bundlePath);
		var initService = BundleInitServiceBuilder
				.producer(new BundleInitServiceProducer(rabbitmqConnection, 30_000, 5_000))
				.configLocation(bundlePath)
				.build();

		log.info("STARTING INIT SERVICE {}", bundlePath);
		initService.start();
		log.info("END INIT SERVICE {}", bundlePath);

		return Map.of("result", "ok");
	}

	public void pushNewTenantEvent(String tenant) {
		String exchangeName = Constants.DEFAULT_EXCHANGE_NAME;

		try (Channel channel = rabbitmqConnection.createChannel()) {
			channel.exchangeDeclare(exchangeName, BuiltinExchangeType.TOPIC);

			String topic = String.format("%s.%s", TOPIC_PREFIX, "newtenant");

			Map<String, Object> headers = Map.of("tenant", tenant);
			AMQP.BasicProperties properties = new AMQP.BasicProperties.Builder()
					.deliveryMode(2) // persistent
					.correlationId(UUID.randomUUID().toString())
					.contentType("application/octet-stream")
					.headers(headers)
					.build();
			channel.basicPublish(exchangeName, topic, properties, tenant.getBytes(StandardCharsets.UTF_8));
			log.info("'{}' pushed to exchange {} with topic {} and headers {}", tenant, exchangeName, topic, headers);
		} catch (TimeoutException | IOException e) {
			throw new RuntimeException(e);
		}
	}

	@Data
	protected static class BundleInstallReq {

		@NotNull
		private String path;

	}

}

