package com.abacogroup.partyregistry.core.impl;

import com.abacogroup.jdbi.criteria.Criteria;
import com.abacogroup.jdbi.orderby.OrderBy;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.partyregistry.api.RelationRole;
import com.abacogroup.partyregistry.core.RelationRoleService;
import com.abacogroup.partyregistry.core.RelationTypeService;
import com.abacogroup.partyregistry.db.dao.RelationRoleDAO;
import com.abacogroup.partyregistry.db.ntt.RelationRoleEntity;
import com.abacogroup.partyregistry.resources.req.RelationRoleSearchReq;
import com.abacogroup.partyregistry.resources.req.ReqContext;
import java.util.Optional;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class RelationRoleServiceImpl implements RelationRoleService {

	private final RelationRoleDAO relationRoleDAO;
	private final RelationTypeService relationTypeService;

	public RelationRoleServiceImpl(RelationRoleDAO relationRoleDAO, RelationTypeService relationTypeService) {
		this.relationRoleDAO = relationRoleDAO;
		this.relationTypeService = relationTypeService;
	}

	@Override
	public InfiniteListResults<RelationRole> search(ReqContext reqContext, RelationRoleSearchReq searchRequest,
			String nextKey) {
		Criteria criteria = searchRequest.getCriteria(reqContext);
		OrderBy sort = searchRequest.getSort();
		InfiniteListResults<RelationRole> roles = relationRoleDAO.infinite(
				() -> relationRoleDAO.searchAll(criteria, sort, reqContext),
				nextKey, searchRequest.getPageSize());
		return roles;
	}

	@Override
	public Optional<RelationRole> getByCode(ReqContext reqContext, String code) {
		return relationRoleDAO.searchByCode(code, reqContext);
	}

	@Override
	public Optional<RelationRole> getByCodeAndType(ReqContext reqContext, String typeCode, String code) {
		return relationRoleDAO.searchByCodeAndType(code, typeCode, reqContext);
	}

	/*@Override
	public RelationRole save(ReqContext context, RelationRoleReq relationRoleReq) {
		RelationTypeEntity type = relationTypeService.findActiveEntityByCode(context.getTenantId(),
						relationRoleReq.getTypeCode())
				.orElseThrow(() -> new InvalidRelationTypeException(
						String.format("the relation type %s does not exist", relationRoleReq.getTypeCode())));

		Optional<RelationRoleEntity> dbEntity = loadEntityByCode(context.getTenantId(), relationRoleReq.getCode(), true);
		if (dbEntity.isEmpty()) {
			RelationRoleEntity entity = RelationRoleMapper.INSTANCE.reqToEntity(relationRoleReq, type.getId());
			return insert(context, entity);
		}
		log.warn("Trying to save a record with code {}, but the same code already exists: id = {}, dt_delete = {}",
				relationRoleReq.getCode(), dbEntity.get().getId(), dbEntity.get().getDtDelete());

		throw new InvalidRelationRoleException(String.format("the relation {} exists", relationRoleReq.getCode()));
	}

	private RelationRole insert(ReqContext reqContext, RelationRoleEntity entity) {
		AuditHelper.setAuditForInsert(entity, reqContext.getUsername(), relationRoleDAO);
		Long id = relationRoleDAO.insert(entity);
		entity.setId(id);
		log.info("Created entity with id {}", id);
		return getByCode(reqContext, entity.getCode()).orElse(null);
	}

	@Override
	public void expire(ReqContext reqContext, String code) {
		relationRoleDAO.useTransaction(handle -> {
			handle.findEntityByCode(reqContext.getTenantId(), code)
					.ifPresent(e -> {
						Consumer<RelationRoleEntity> expireFun = handle::expireRow;
						AuditHelper.expire(e, reqContext.getUsername(), expireFun, handle.getCurrentTimestamp());
					});
		});
	}
*/
	//--------
	protected Optional<RelationRoleEntity> loadEntityByCode(String tenantId, String code, Boolean includeDeleted) {
		if (includeDeleted) {
			return relationRoleDAO.findEntityByCodeIncludeDeleted(tenantId, code);
		}
		return loadEntityActiveByCode(tenantId, code);
	}

	@Override
	public Optional<RelationRoleEntity> loadEntityActiveByCode(String tenantId, String code) {
		return relationRoleDAO.findEntityByCode(tenantId, code);
	}

	@Override
	public Optional<RelationRoleEntity> loadEntityActiveByCode(String tenantId, Long typeId, String code) {
		return relationRoleDAO.findEntityByTypeIdAndCode(tenantId, typeId, code);
	}

}
