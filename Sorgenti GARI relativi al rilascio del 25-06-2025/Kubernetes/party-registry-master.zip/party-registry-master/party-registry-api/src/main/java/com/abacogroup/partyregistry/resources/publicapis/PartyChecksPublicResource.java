package com.abacogroup.partyregistry.resources.publicapis;

import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.partyregistry.api.RoleCountDTO;
import com.abacogroup.partyregistry.core.AclService;
import com.abacogroup.partyregistry.core.PartyChecksService;
import com.abacogroup.partyregistry.resources.PublicResourceConstants;
import com.abacogroup.partyregistry.resources.publicapis.mapper.RelationPublicMapper;
import com.abacogroup.partyregistry.resources.req.ReqContext;
import io.dropwizard.auth.Auth;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;

import java.util.List;

@Path(PublicResourceConstants.API_V1_PUB + "/checks")
@Produces(MediaType.APPLICATION_JSON)
@Tag(name = "Checks", description = "Checks on parties")
public class PartyChecksPublicResource {

	private final PartyChecksService partyChecksService;

	public PartyChecksPublicResource(PartyChecksService partyChecksService) {
		this.partyChecksService = partyChecksService;
	}

	@GET
	@Path("/parties/{partyCode}/checks")
	public List<RoleCountDTO> countPartyRelationRoles(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@PathParam("tenant") String tenantId,
			@Parameter(description = "the party code to check") @PathParam("partyCode") String partyCode,
			@Parameter(description = "The party role list") @QueryParam("roleCode") List<String> roleCodeList,
			@Parameter(description = "The party relation type") @QueryParam("relationType") String relationType,
			@Parameter(description = "The reference date") @QueryParam("referenceDate") AbsoluteDate referenceDate) {

		ReqContext reqContext = new ReqContext(user, lang);
		return partyChecksService.countPartyRelationRoles(reqContext, partyCode, roleCodeList, relationType, referenceDate);
	}

}

