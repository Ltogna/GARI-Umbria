package com.abacogroup.partyregistry.resources.req;

import com.abacogroup.partyregistry.api.ContactTypeEnum;
import com.fasterxml.jackson.annotation.JsonIgnore;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder
@NoArgsConstructor
@Accessors(chain = true)
public class PartyContactReq {
	private static final String EMAIL_REGEXP = "^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$";
	private static final String PHONE_REGEXP =  "^\\+?[0-9]+$"; // pattern for phone number - with optional plus sign and only numbers allowed

	@NotNull
	private ContactTypeEnum contactType;
	@NotBlank
	private String subType;
	@NotBlank
	private String contactValue;
	private String note;


	public static boolean validatePhoneNumber(String phoneNumber) {
		return phoneNumber.matches(PHONE_REGEXP);
	}

	public static boolean validateEmailAddress(String emailAddress) {
		return emailAddress.matches(EMAIL_REGEXP);
	}

	@JsonIgnore
	@Schema(hidden = true)
	public  boolean isValid() {
		if (this.getContactType() != null && this.getContactValue() != null){
			if (this.getContactType() == ContactTypeEnum.EMAIL||this.getContactType()==ContactTypeEnum.PEC) {
				return validateEmailAddress(this.getContactValue());
			} else if (this.getContactType() == ContactTypeEnum.PHONE) {
				return validatePhoneNumber(this.getContactValue());
			}
		}
		return false;
	}
}
