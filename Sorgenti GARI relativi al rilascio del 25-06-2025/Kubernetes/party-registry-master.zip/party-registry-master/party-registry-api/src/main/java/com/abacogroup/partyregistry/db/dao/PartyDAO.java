package com.abacogroup.partyregistry.db.dao;

import com.abacogroup.jdbi.EnhancedSqlObject;
import com.abacogroup.jdbi.criteria.BindCriteria;
import com.abacogroup.jdbi.criteria.Criteria;
import com.abacogroup.jdbi.orderby.DefineOrder;
import com.abacogroup.jdbi.orderby.OrderBy;
import com.abacogroup.partyregistry.api.PartySearchRes;
import com.abacogroup.partyregistry.api.PartyTag;
import com.abacogroup.partyregistry.db.ntt.PartyEntity;
import com.abacogroup.partyregistry.db.ntt.PartyTagEntity;
import com.abacogroup.partyregistry.resources.req.ReqContext;
import java.util.List;
import java.util.Optional;
import org.jdbi.v3.core.result.ResultIterator;
import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.customizer.BindBean;
import org.jdbi.v3.sqlobject.customizer.BindList;
import org.jdbi.v3.sqlobject.statement.GetGeneratedKeys;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;
import org.jdbi.v3.sqlobject.transaction.Transactional;

public interface PartyDAO extends Transactional<PartyDAO>, EnhancedSqlObject {

	String CURRENT_RECORD = " AND (§current_timestamp§ between dt_insert and dt_delete) ";
	String I18N = " \n, coalesce (§i18n(:tenantId, 'prt_tags', 'code', t.tag_code, :lang)§, t.tag_code) as tag_i18n_code\n ";

	@SqlQuery("§select_nextval(my_prt_parties_detail_pkid_seq)§")
	Long issuePk();

	@SqlQuery(
			"select * from prt_parties m inner join prt_parties_detail d on  m.id = d.party_id  WHERE <criteria>" + CURRENT_RECORD)
	@RegisterBeanMapper(PartyEntity.class)
	Optional<PartyEntity> loadOne(@BindCriteria Criteria criteria);

	@SqlQuery(
			"select * from prt_parties m inner join prt_parties_detail d on  m.id = d.party_id"
					+ " WHERE tenant_id = :tenantId "
					+ " AND ( ( d.vat_number= :vat_number or d.tax_code = :vat_number) OR  ( d.vat_number = :tax_code or d.tax_code = :tax_code ) )"
					+ " AND ( :id IS NULL OR m.id != :id)"
					+ CURRENT_RECORD)
	@RegisterBeanMapper(PartyEntity.class)
	List<PartyEntity> loadDuplicates(@Bind("tenantId") String tenantId, @Bind("id") Long id, @Bind("vat_number") String vatNumber,
			@Bind("tax_code") String taxCode);

	@SqlQuery(
			"select * from prt_parties m inner join prt_parties_detail d on  m.id = d.party_id"
					+ " WHERE tenant_id = :tenantId "
					+ " AND d.code= :code "
					+ " AND ( :id IS NULL OR m.id != :id)"
					+ CURRENT_RECORD)
	@RegisterBeanMapper(PartyEntity.class)
	List<PartyEntity> loadDuplicatesCode(@Bind("tenantId") String tenantId, @Bind("id") Long id,
			@Bind("code") String code);

	@SqlQuery("select d.code " +
			"from prt_parties m " +
			"inner join prt_parties_detail d on  m.id = d.party_id " +
			" WHERE tenant_id = :tenantId " +
			" AND m.id = :id " +
			CURRENT_RECORD)
	String findCodeById(@Bind("tenantId") String tenantId, @Bind("id") Long id);

	@SqlQuery(
			//"select * from prt_parties m inner join prt_parties_detail d on  m.id = d.party_id  WHERE (tenant_id = :tenantId OR '*' = :tenantId) and id = :id"
			"select * from prt_parties m inner join prt_parties_detail d on  m.id = d.party_id  WHERE tenant_id = :tenantId and id = :id"
					+ CURRENT_RECORD)
	@RegisterBeanMapper(PartyEntity.class)
	Optional<PartyEntity> loadOneByIdAndTenantId(@Bind("tenantId") String tenantId, @Bind("id") Long id);

	@SqlQuery(
			"select * from prt_parties m "
					+ " inner join prt_parties_detail d on  m.id = d.party_id  "
					+ " WHERE tenant_id = :tenantId and "
					+ " d.code = :code "
					+ CURRENT_RECORD)
	@RegisterBeanMapper(PartyEntity.class)
	Optional<PartyEntity> findByTenantAndCode(@Bind("tenantId") String tenantId, @Bind("code") String code);

	@SqlQuery(
			"select * from prt_parties m "
					+ " inner join prt_parties_detail d on  m.id = d.party_id  "
					+ " WHERE tenant_id = :tenantId and "
					+ " d.source_code = :sourceCode "
					+ CURRENT_RECORD)
	@RegisterBeanMapper(PartyEntity.class)
	List<PartyEntity> findByTenantAndSourceCode(@Bind("tenantId") String tenantId, @Bind("sourceCode") String sourceCode);

	@SqlUpdate("INSERT INTO prt_parties (id, tenant_id ) VALUES (:sequenceId, :tenantId)")
	void insertMasterRow(@Bind("sequenceId") Long id, @BindBean PartyEntity entity);

	/**
	 * usato in creazione
	 * <p>
	 * unica e sola differenza tra insertDetailRow e insertVersionRow è che la prima conosce già la pk da inserire come pkid e come party_id
	 */
	@SqlUpdate(
			"INSERT INTO prt_parties_detail (pkid, party_id, party_type, gender, last_name, first_name, tax_code, vat_number,code, legal_status, "
					+ "birth_date, death_date, birth_municipality, nationality, "
					+ "fk_address_residential, fk_address_home, fk_address_billing, source_code, "
					+ "fl_archived, dt_insert, user_id_insert, dt_delete, user_id_delete) "
					+ "VALUES (:pkid, :party_id, :partyType, :gender, :lastName, :firstName, :taxCode, :vatNumber, :code, :legalStatus, "
					+ ":birthDate, :deathDate, :birthMunicipality, :nationality, "
					+ ":fkAddressResidential, :fkAddressHome, :fkAddressBilling, :sourceCode, "
					+ ":flArchived, :dtInsert, :userIdInsert, :dtDelete, :userIdDelete)")
	void insertDetailRow(@BindBean PartyEntity entity, @Bind("pkid") Long pkid, @Bind("party_id") Long partyId);

	/**
	 * usato in aggiornamento
	 */
	@SqlUpdate(
			"INSERT INTO prt_parties_detail (party_id, party_type, gender, last_name, first_name, tax_code, vat_number,code, legal_status, "
					+ "birth_date, death_date, birth_municipality, nationality,  "
					+ "fk_address_residential, fk_address_home, fk_address_billing, source_code, "
					+ "fl_archived, dt_insert, user_id_insert, dt_delete, user_id_delete) "
					+ "VALUES (:id, :partyType, :gender, :lastName, :firstName, :taxCode, :vatNumber, :code, :legalStatus, "
					+ ":birthDate, :deathDate, :birthMunicipality, :nationality, "
					+ ":fkAddressResidential, :fkAddressHome, :fkAddressBilling, :sourceCode, "
					+ ":flArchived, :dtInsert, :userIdInsert, :dtDelete, :userIdDelete)")
	@GetGeneratedKeys("pkid")
	long insertVersionRow(@BindBean PartyEntity entity);

	@SqlUpdate("update prt_parties_detail set dt_delete =:dtDelete, user_id_delete=:userIdDelete where pkid = :pkid")
	void expireRow(@BindBean PartyEntity entity);

	@SqlQuery(
			"select * from (select distinct m.id, d.pkid, party_type, last_name, first_name, upper(coalesce(last_name, '') || ' ' || coalesce(first_name, '')) as fullname, tax_code, vat_number,code, legal_status,\n"
					+ "       birth_date, death_date, birth_municipality, fl_archived, source_code, \n" // TODO i18n source code
					+ "       address.id as address_id, address.municipality as address_municipality, "
					+ "       address.locality as address_locality, address.street as address_street, "
					+ "       address.house_number as address_house_number, address.postcode as address_postcode, "
					+ "       address.details as address_details, address.note as address_note\n"
					+ "from prt_parties m\n"
					+ "    inner join prt_parties_detail d on m.id = d.party_id AND §current_timestamp§ between d.dt_insert and d.dt_delete \n"
					+ "    left join prt_parties_tags ppt on m.id = ppt.party_id and §current_timestamp§ between ppt.dt_insert and ppt.dt_delete \n"
					+ "    left join prt_tags t on ppt.tag_id = t.id and t.tenant_id = m.tenant_id\n"
					+ "    left join prt_addresses address on address.id = d.fk_address_residential \n"
					+ "    where m.tenant_id = :tenantId "
					+ "    and (:ignoreAcl = 1 or §check_proxies(:tenantId, :user.userId, m.id, :withManage, null)§) "
					+ "and <inner_criteria>) inner_result \n"
					+ "WHERE <criteria> "
					+ "ORDER BY <orderBy>")
	@RegisterBeanMapper(PartySearchRes.class)
	ResultIterator<PartySearchRes> search(
			@BindCriteria(value = "inner_criteria") Criteria innerCriteria,
			@BindCriteria Criteria criteria,
			@DefineOrder OrderBy orderBy,
			@BindBean ReqContext ctx,
			@Bind("ignoreAcl") int ignoreAcl,
			@Bind("withManage") Integer withManage
	);

	@SqlQuery(
			"select * from (select distinct m.id, d.pkid, party_type, last_name, first_name, tax_code, vat_number,code, legal_status,\n"
					+ "       birth_date, death_date, birth_municipality, fl_archived, source_code, \n" // TODO i18n source code
					+ "       address.id as address_id, address.municipality as address_municipality, "
					+ "       address.locality as address_locality, address.street as address_street, "
					+ "       address.house_number as address_house_number, address.postcode as address_postcode, "
					+ "       address.details as address_details, address.note as address_note\n"
					+ "from prt_parties m\n"
					+ "    inner join prt_parties_detail d on m.id = d.party_id AND §current_timestamp§ between d.dt_insert and d.dt_delete \n"
					+ "    left join prt_parties_tags ppt on m.id = ppt.party_id and §current_timestamp§ between ppt.dt_insert and ppt.dt_delete \n"
					+ "    left join prt_tags t on ppt.tag_id = t.id and t.tenant_id = m.tenant_id\n"
					+ "    left join prt_addresses address on address.id = d.fk_address_residential \n"

					+ "where m.tenant_id = :tenantId and m.id in (<ids>) "
					+ "    and (:ignoreAcl = 1 or §check_proxies(:tenantId, :user.userId, m.id, :withManage, null)§) "
					+ ") inner_result \n"
					+ "ORDER BY id")
	@RegisterBeanMapper(PartySearchRes.class)
	List<PartySearchRes> searchByIdIn(
			@BindBean ReqContext ctx,
			@BindList("ids") List<Long> ids,
			@Bind("ignoreAcl") int ignoreAcl,
			@Bind("withManage") Integer withManage
	);

	@SqlQuery(
			"select ppt.pkid, ppt.party_id, ppt.tag_id, ppt.dt_insert, ppt.user_id_insert,ppt.dt_delete,ppt.user_id_delete,\n"
					+ "  t.tag_code\n"
					+ " from prt_parties_tags ppt\n"
					+ "         inner join prt_parties_detail ppd on ppd.party_id = ppt.party_id\n"
					+ "         inner join prt_tags t on  ppt.tag_id = t.id\n"
					+ "where <criteria>\n"
					+ "and  §current_timestamp§ between ppt.dt_insert and ppt.dt_delete\n"
					+ "order by <orderBy>\n"
	)
	@RegisterBeanMapper(PartyTagEntity.class)
	List<PartyTagEntity> getPartyTags(@BindCriteria Criteria criteria, @DefineOrder OrderBy orderBy);

	@SqlUpdate(
			"INSERT INTO prt_parties_tags (party_id, tag_id, dt_insert, user_id_insert, dt_delete, user_id_delete) VALUES (:partyId, :tagId, :dtInsert, :userIdInsert, :dtDelete, :userIdDelete)")
	void insertTag(@BindBean PartyTagEntity entity);

	@SqlUpdate("update prt_parties_tags set dt_delete =:dtDelete, user_id_delete=:userIdDelete where pkid = :pkid")
		//void expireRow(@BindBean PartyTagEntity entity);
	void expireTagRow(@BindBean PartyTagEntity entity);

	@SqlQuery("select ppt.pkid, ppt.party_id, ppt.tag_id as tag_id ,t.tag_code"
			+ I18N
			+ "from prt_parties_tags ppt\n"
			+ "inner join prt_parties_detail ppd on ppd.party_id = ppt.party_id  and §current_timestamp§ between ppd.dt_insert and ppd.dt_delete \n"
			+ "inner join prt_tags t on  ppt.tag_id = t.id\n"
			+ "where <criteria> \n"
			+ " and §current_timestamp§ between ppt.dt_insert and ppt.dt_delete \n "
			+ "order by <orderBy> ")
	@RegisterBeanMapper(PartyTag.class)
	List<PartyTag> searchPartyTags(
			@BindCriteria Criteria criteria,
			@DefineOrder OrderBy orderBy,
			@Bind("tenantId") String tenantId, @Bind("lang") String lang);

	@SqlQuery("§select_from_dual(case when §check_proxies(:tenantId, :user.userId, :partyId, :withManage, null)§      then 1 else 0 end)§ ") // the space before "then" is needed because there is some issue with function rewriter
	boolean isAuthorized(@BindBean ReqContext ctx, @Bind("partyId") Long partyId, @Bind("withManage") Integer withManage);

	@SqlQuery("§select_from_dual(case when §check_proxies(:tenantId, :user.userId, '*', 0, null)§      then 1 else 0 end)§ ") // the space before "then" is needed because there is some issue with function rewriter
	boolean hasStarMandate(@BindBean ReqContext ctx);

}
