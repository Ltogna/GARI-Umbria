package com.abacogroup.partyregistry.resources.publicapis;

import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.partyregistry.api.PartyTag;
import com.abacogroup.partyregistry.core.PartyTagService;
import com.abacogroup.partyregistry.resources.PublicResourceConstants;
import com.abacogroup.partyregistry.resources.req.ReqContext;
import io.dropwizard.auth.Auth;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.ws.rs.DefaultValue;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.HeaderParam;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import java.util.List;

@SuppressWarnings("UnresolvedRestParam")
@Path(PublicResourceConstants.API_V1_PUB + "/parties/{partyId}/tags")
@Produces(MediaType.APPLICATION_JSON)
@Tag(name = "party tags", description = "Operations on party tags")
@Deprecated
public class PartyTagPublicResource {

	private final PartyTagService partyTagService;

	public PartyTagPublicResource(PartyTagService partyTagService) {
		this.partyTagService = partyTagService;
	}

	@Operation(summary = "List of party tags", description = "Get list of tags of a specific party")
	@ApiResponses({
			@ApiResponse(responseCode = "200", description = "Successfully, returns a list of party tags (sorted/filtered)",
					content = @Content(mediaType = "application/json", array = @ArraySchema(
							schema = @Schema(implementation = PartyTag.class))))
	})
	@GET
	//@RolesAllowed()
	public List<PartyTag> search(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "the tenant ID") @PathParam("tenant") String tenantId,
			@Parameter(description = "the party ID") @PathParam("partyId") Long partyId
	) {
		ReqContext reqContext = new ReqContext(user, lang);
		return partyTagService.getPartyTags(reqContext, partyId);
	}

}
