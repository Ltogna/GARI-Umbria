package com.abacogroup.partyregistry.core.impl;

import com.abacogroup.jdbi.criteria.Criteria;
import com.abacogroup.jdbi.criteria.CriteriaBuilder;
import com.abacogroup.jdbi.orderby.OrderBy;
import com.abacogroup.jdbi.orderby.OrderByBuilder;
import com.abacogroup.jdbi.orderby.SortDirection;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.partyregistry.PartyRegistryConfiguration.AclConfig;
import com.abacogroup.partyregistry.api.ExternalSourceRes;
import com.abacogroup.partyregistry.api.PartyRes;
import com.abacogroup.partyregistry.api.PartySearchRes;
import com.abacogroup.partyregistry.api.PartyTag;
import com.abacogroup.partyregistry.api.Tag;
import com.abacogroup.partyregistry.core.PartyCustomValidator;
import com.abacogroup.partyregistry.core.PartyEventProducer;
import com.abacogroup.partyregistry.core.PartyService;
import com.abacogroup.partyregistry.core.PartyTagService;
import com.abacogroup.partyregistry.core.TagService;
import com.abacogroup.partyregistry.core.dto.PartyEventType;
import com.abacogroup.partyregistry.core.exceptions.ErrCodes;
import com.abacogroup.partyregistry.core.exceptions.InvalidPartyException;
import com.abacogroup.partyregistry.core.exceptions.InvalidTagException;
import com.abacogroup.partyregistry.core.impl.validaor.AddressValidator;
import com.abacogroup.partyregistry.db.dao.AddressDAO;
import com.abacogroup.partyregistry.db.dao.ExternalSourceDAO;
import com.abacogroup.partyregistry.db.dao.LegalStatusDAO;
import com.abacogroup.partyregistry.db.dao.PartyDAO;
import com.abacogroup.partyregistry.db.ntt.PartyEntity;
import com.abacogroup.partyregistry.db.ntt.PartyTagEntity;
import com.abacogroup.partyregistry.resources.mappers.PartyMapper;
import com.abacogroup.partyregistry.resources.req.PartyCheckReq;
import com.abacogroup.partyregistry.resources.req.PartyCodeCheckReq;
import com.abacogroup.partyregistry.resources.req.PartyCreateReq;
import com.abacogroup.partyregistry.resources.req.PartySearchReq;
import com.abacogroup.partyregistry.resources.req.PartyUpdateReq;
import com.abacogroup.partyregistry.resources.req.PartyUpdateReq.Fields;
import com.abacogroup.partyregistry.resources.req.ReqContext;
import jakarta.ws.rs.InternalServerErrorException;
import java.lang.reflect.Field;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

@Slf4j
public class PartyServiceImpl implements PartyService, PartyTagService {

	private static final List<String> PARTY_READ_ONLY_FIELDS = List.of(
			Fields.partyType,
			Fields.gender,
			Fields.lastName,
			Fields.firstName,
			Fields.taxCode,
			Fields.vatNumber,
			Fields.code,
			Fields.legalStatus,
			Fields.birthDate,
			Fields.deathDate,
			Fields.birthMunicipality,
			Fields.nationality,
			Fields.addressResidential
			//				Fields.addressHome,
			//				Fields.addressBilling,
			//				Fields.tags,
			//				Fields.archived
	);

	private final TagService tagService;
	private final PartyDAO partyDAO;
	private final AddressDAO addressDAO;
	private final LegalStatusDAO legalStatusDAO;
	private final ExternalSourceDAO externalSourceDAO;
	private final LauMapper lauMapper;
	private final PartyCustomValidator partyCustomValidator;
	private final PartyEventProducer partyEventProducer;

	private final AclConfig aclConfig;

	public PartyServiceImpl(TagService tagService, PartyDAO partyDAO, AddressDAO addressDAO, LegalStatusDAO legalStatusDAO, ExternalSourceDAO externalSourceDAO,
			LauMapper lauMapper, PartyCustomValidator partyCustomValidator, PartyEventProducer partyEventProducer, AclConfig aclConfig) {
		this.tagService = tagService;
		this.partyDAO = partyDAO;
		this.addressDAO = addressDAO;
		this.legalStatusDAO = legalStatusDAO;
		this.externalSourceDAO = externalSourceDAO;
		this.lauMapper = lauMapper;
		this.partyCustomValidator = partyCustomValidator;
		this.partyEventProducer = partyEventProducer;
		this.aclConfig = aclConfig;
	}

	@Override
	public PartyRes insert(ReqContext reqContext, PartyCreateReq party, String sourceCode) {
		PartyEntity entity = PartyMapper.INSTANCE.requestToEntity(party);
		entity.setTenantId(reqContext.getTenantId());
		entity.setSourceCode(StringUtils.upperCase(StringUtils.trimToNull(sourceCode)));

		this.checkSourceCode(entity);
		this.validateDeathDate(entity);
		this.validateLegalStatus(entity, reqContext);
		partyCustomValidator.validateOnInsert(entity, reqContext.getTenantId());

		partyDAO.useTransaction(h -> {
			this.insertRecord(reqContext, entity, party.getTags());

			partyEventProducer.pushPartyEvent(reqContext, entity.getId(), PartyEventType.NEW_PARTY);
			if (party.isArchived()) {
				partyEventProducer.pushPartyEvent(reqContext, entity.getId(), PartyEventType.ARCHIVE_PARTY);
			}
		});
		return getPartyById(reqContext, entity.getId()).orElse(null);
	}

	@Override
	public PartyRes update(ReqContext reqContext, Long id, PartyUpdateReq party, String sourceCode) {
		PartyEntity entity = loadEntityWithAddresses(reqContext.getTenantId(), id)
				.orElseThrow(() -> new InvalidPartyException(ErrCodes.PARTY_NOT_FOUND, String.format("party %s not found", id)));
		List<PartyTag> existingPartyTags = this.getPartyTags(reqContext, entity.getId());
		boolean actualArchived = entity.getFlArchived() > 0;

		this.checkReadOnlyFields(party, entity, existingPartyTags, sourceCode);

		PartyMapper.INSTANCE.updateEntity(party, entity);
		if (StringUtils.isNotBlank(sourceCode)) {
			// TODO manage party from different source
			entity.setSourceCode(StringUtils.upperCase(sourceCode));
		}

		this.validateDeathDate(entity);
		this.validateLegalStatus(entity, reqContext);
		partyCustomValidator.validateOnUpdate(entity, reqContext.getTenantId());

		partyDAO.useTransaction(h -> {
			this.updateRecordWithTags(entity, existingPartyTags, reqContext, party.getTags());

			partyEventProducer.pushPartyEvent(reqContext, entity.getId(),
					!actualArchived && party.isArchived() ? PartyEventType.ARCHIVE_PARTY : PartyEventType.UPDATE_PARTY);
		});

		return getPartyById(reqContext, entity.getId()).orElse(null);
	}

	@Override
	public InfiniteListResults<PartySearchRes> search(ReqContext reqContext, PartySearchReq searchRequest, Integer withManage, String nextKey) {
		InfiniteListResults<PartySearchRes> parties = doSearch(reqContext, searchRequest, withManage, nextKey)
				.map(p -> lauMapper.resolvePartySearchResponseAddress(p, reqContext));

		return parties;
	}

	@Override
	public List<PartySearchRes> searchByIdIn(ReqContext reqContext, List<Long> ids, Integer withManage) {
		// XXX FIXME
		int skipACL = aclConfig.isIgnoreAcl() ? 1 : 0;
		// XXX hasManage, if -1 skip check, 0 must have almost one read manadate, 1 must have almost one manage mandate
		//Integer hasManage = w;

		List<PartySearchRes> list = partyDAO.searchByIdIn(reqContext, ids, skipACL, withManage);
		return list.stream()
				.sorted(Comparator.comparing(x -> ids.indexOf(x.getId())))
				.map(PartyMapper.INSTANCE::clean)
				.map(p -> lauMapper.resolvePartySearchResponseAddress(p, reqContext))
				.collect(Collectors.toList());
	}

	@Override
	public InfiniteListResults<PartySearchRes> doSearch(ReqContext reqContext, PartySearchReq searchRequest, Integer withManage, String nextKey) {
		Criteria criteria = searchRequest.getCriteria(reqContext);
		OrderBy sort = searchRequest.getSortList();

		// XXX FIXME
		int skipACL = aclConfig.isIgnoreAcl() ? 1 : 0;
		// XXX hasManage, if -1 skip check, 0 must have almost one read manadate, 1 must have almost one manage mandate
		//Integer hasManage = -1;

		InfiniteListResults<PartySearchRes> parties = partyDAO.infinite(
						() -> partyDAO.search(searchRequest.getInnerCriteria(reqContext), criteria, sort, reqContext, skipACL, withManage),
						nextKey, searchRequest.getPageSize())
				.map(PartyMapper.INSTANCE::clean);
		return parties;
	}

	@Override
	public Optional<PartyRes> getPartyById(ReqContext reqContext, Long id) {
		Optional<PartyRes> party = loadEntityWithAddresses(reqContext.getTenantId(), id)
				.map(PartyMapper.INSTANCE::entityToDto)
				.map(prt -> this.getAndPutTags(reqContext, prt))
				.map(prt -> this.getAndPutExternalSource(reqContext, prt));
		return party;
	}

	@Override
	public Optional<PartyRes> getPartyByCode(ReqContext reqContext, String code) {
		Optional<PartyRes> party = partyDAO.findByTenantAndCode(reqContext.getTenantId(), code)
				.map(this::loadAndPutAddresses)
				.map(PartyMapper.INSTANCE::entityToDto)
				.map(prt -> this.getAndPutTags(reqContext, prt))
				.map(prt -> this.getAndPutExternalSource(reqContext, prt));

		return party;
	}

	@Override
	public PartyRes archive(ReqContext reqContext, Long id, boolean archiveStatus) {
		PartyEntity entity = this.loadEntityWithAddresses(reqContext.getTenantId(), id)
				.orElseThrow(() -> new InvalidPartyException(ErrCodes.PARTY_NOT_FOUND, "Party not found"));
		int newStatus = archiveStatus ? 1 : 0;
		if (newStatus != entity.getFlArchived()) {
			partyDAO.useTransaction(h -> {
				entity.setFlArchived(newStatus);
				updateRecord(reqContext.getUsername(), entity);

				partyEventProducer.pushPartyEvent(reqContext, entity.getId(),
						archiveStatus ? PartyEventType.ARCHIVE_PARTY : PartyEventType.UPDATE_PARTY); // TODO restore status?
			});
		}
		return getPartyById(reqContext, id)
				.orElse(null);
	}

	@Override
	public void expire(ReqContext reqContext, Long id) {
		//TODO #1 test
		//TODO #2 expire cascade
		partyDAO.useTransaction(handle -> {
			handle.loadOneByIdAndTenantId(reqContext.getTenantId(), id)
					.ifPresent(e -> {
						Consumer<PartyEntity> expireFun = handle::expireRow;
						AuditHelper.expire(e, reqContext.getUsername(), expireFun, handle.getCurrentTimestamp());

						partyEventProducer.pushPartyEvent(reqContext, id, PartyEventType.DELETE_PARTY);
					});
		});
	}

	@Override
	public List<PartyEntity> loadDuplicates(String tenantId, PartyCheckReq partyCheckReq) {
		return partyDAO.loadDuplicates(tenantId, partyCheckReq.getId(), partyCheckReq.getVatNumber(), partyCheckReq.getTaxCode());
	}

	@Override
	public Map<String, Boolean> loadDuplicatesDetail(String tenantId, PartyCheckReq partyCheckReq) {
		List<PartyEntity> entities = partyDAO.loadDuplicates(tenantId, partyCheckReq.getId(), partyCheckReq.getVatNumber(), partyCheckReq.getTaxCode());

		Map<String, Boolean> resultMap = new HashMap<>();
		if (StringUtils.isNotBlank(partyCheckReq.getVatNumber())) {
			resultMap.putAll(mapDuplicates(entities, "partitaIva", x -> StringUtils.equals(x.getVatNumber(), partyCheckReq.getVatNumber())));
		}
		if (StringUtils.isNotBlank(partyCheckReq.getTaxCode())) {
			resultMap.putAll(mapDuplicates(entities, "codiceFiscale", x -> StringUtils.equals(x.getTaxCode(), partyCheckReq.getTaxCode())));
		}
		return resultMap;
	}

	private Map<String, Boolean> mapDuplicates(List<PartyEntity> entities, String keyName, Predicate<PartyEntity> predicate) {
		return entities.stream()
				.filter(predicate)
				.collect(Collectors.collectingAndThen(
						Collectors.toList(),
						list -> Collections.singletonMap(keyName, !list.isEmpty())));
	}

	@Override
	public List<PartyEntity> loadDuplicatesCode(String tenantId, PartyCodeCheckReq partyCodeCheckReq) {
		return partyDAO.loadDuplicatesCode(tenantId, partyCodeCheckReq.getId(), partyCodeCheckReq.getCode().toUpperCase());
	}

	@Override
	public Optional<PartyEntity> loadEntity(String tenantId, Long id) {
		return partyDAO.loadOneByIdAndTenantId(tenantId, id);
	}

	public Optional<PartyEntity> loadEntityWithAddresses(String tenantId, Long id) {
		return this.loadEntity(tenantId, id)
				.map(this::loadAndPutAddresses);
	}

	@Override
	public List<PartyTag> getPartyTags(ReqContext reqContext, Long partyId) {
		Criteria criteria = CriteriaBuilder.and(List.of(
				CriteriaBuilder.number("ppd.party_id").eq(partyId),
				CriteriaBuilder.string("t.tenant_id").eq(reqContext.getTenantId())
		).toArray(new Criteria[0]));
		OrderBy sort = OrderByBuilder.field("t.tag_code").direction(SortDirection.ASC);
		return partyDAO.searchPartyTags(criteria, sort, reqContext.getTenantId(), reqContext.getLang());
	}

	@Override
	public Tag attachTag(ReqContext reqContext, Long partyId, String tagCode) {
		this.loadEntity(reqContext.getTenantId(), partyId)
				.orElseThrow(() -> new InvalidPartyException(ErrCodes.PARTY_NOT_FOUND, "party not found " + partyId));
		return partyDAO.inTransaction(h -> {
			Tag tag = doAttachTag(reqContext, partyId, tagCode);
			partyEventProducer.pushPartyEvent(reqContext, partyId, PartyEventType.UPDATE_PARTY);

			return tag;
		});
	}

	private Tag doAttachTag(ReqContext reqContext, Long partyId, String tagCode) {
		Tag tag = tagService.getTagByCode(reqContext, tagCode)
				.orElseThrow(() -> new InvalidTagException(ErrCodes.TAG_NOT_FOUND, "tag not found " + tagCode));

		PartyTagEntity partyTagEntity = PartyTagEntity.builder()
				.setPartyId(partyId)
				.setTagId(tag.getId())
				.build();
		AuditHelper.setAuditForInsert(partyTagEntity, reqContext.getUsername(), partyDAO);
		partyDAO.insertTag(partyTagEntity);
		return tag;
	}

	@Override
	public void detachTag(ReqContext reqContext, Long partyId, String tagCode) {
		this.loadEntity(reqContext.getTenantId(), partyId)
				.orElseThrow(() -> new InvalidPartyException(ErrCodes.PARTY_NOT_FOUND, "party not found " + partyId));
		partyDAO.useTransaction(h -> {
			if (this.doDetachTag(reqContext, partyId, tagCode)) {
				partyEventProducer.pushPartyEvent(reqContext, partyId, PartyEventType.UPDATE_PARTY);
			}
		});
	}

	private boolean doDetachTag(ReqContext reqContext, Long partyId, String tagCode) {
		Optional<PartyTagEntity> tag = getPartyTagEntity(reqContext.getTenantId(), partyId)
				.stream()
				.filter(t -> t.getTagCode().equalsIgnoreCase(tagCode))
				.findFirst();
		return partyDAO.inTransaction(handle ->
				tag.map(e -> {
					Consumer<PartyTagEntity> expire = handle::expireTagRow;
					AuditHelper.expire(e, reqContext.getUsername(), expire, handle.getCurrentTimestamp());

					return true;
				}).orElse(false)
		);
	}

	//----

	protected void insertRecord(ReqContext reqContext, PartyEntity entity, List<String> tags) {
		partyDAO.useTransaction(handle -> {
			AddressDAO addressDAO = handle.getHandle().attach(AddressDAO.class);
			saveAddresses(entity, addressDAO);

			AuditHelper.setAuditForInsert(entity, reqContext.getUsername(), partyDAO);
			long pk = partyDAO.issuePk();
			handle.insertMasterRow(pk, entity);

			handle.insertDetailRow(entity, pk, pk);

			entity.setId(pk);
			entity.setPkid(pk);

			if (tags != null) {
				tags.forEach(x -> doAttachTag(reqContext, entity.getId(), x));
			}
		});
	}

	protected void updateRecord(String currentUser, PartyEntity entity) {
		partyDAO.useTransaction(handle -> {

			AddressDAO addressDAO = handle.getHandle().attach(AddressDAO.class);
			saveAddresses(entity, addressDAO);

			Consumer<PartyEntity> expire = handle::expireRow;
			Function<PartyEntity, Long> insert = handle::insertVersionRow;

			long currentPkId = AuditHelper.update(entity, currentUser, expire, insert, handle.getCurrentTimestamp());
			entity.setPkid(currentPkId);
		});
	}

	protected void updateRecordWithTags(PartyEntity entity, List<PartyTag> existingPartyTags, ReqContext reqContext, List<String> newTags) {
		Long partyId = entity.getId();

		partyDAO.useTransaction(handle -> {
			AddressDAO addressDAO = handle.getHandle().attach(AddressDAO.class);
			saveAddresses(entity, addressDAO);

			Consumer<PartyEntity> expire = handle::expireRow;
			Function<PartyEntity, Long> insert = handle::insertVersionRow;

			long currentPkId = AuditHelper.update(entity, reqContext.getUsername(), expire, insert, handle.getCurrentTimestamp());
			entity.setPkid(currentPkId);

			updateTags(reqContext, partyId, newTags, existingPartyTags);
		});
	}

	private void updateTags(ReqContext reqContext, Long partyId, List<String> newTags, List<PartyTag> existingPartyTags) {
		if (newTags != null) {
			// attach new tags to party
			List<String> existingTagCodes = existingPartyTags.stream()
					.map(PartyTag::getTagCode).collect(Collectors.toList());
			List<String> listTagsToAdd =
					newTags.stream()
							.filter(x -> !existingTagCodes.contains(x)).collect(Collectors.toList());
			listTagsToAdd.forEach(x -> doAttachTag(reqContext, partyId, x));

			// detach tags from party
			List<PartyTag> listTagsToDelete =
					existingPartyTags.stream().filter(x -> !newTags.contains(x.getTagCode())).collect(Collectors.toList());
			listTagsToDelete.forEach(x ->
					doDetachTag(reqContext, partyId, x.getTagCode()));
		} else {
			//if the list of new tags is null ( detach all the existing tags ! )
			if (existingPartyTags != null) {
				existingPartyTags.forEach(x -> doDetachTag(reqContext, partyId, x.getTagCode()));
			}
		}
	}

	protected void saveAddresses(PartyEntity party, AddressDAO addressDAO) {

		Optional.ofNullable(AddressValidator.validateAddress(party.getAddressHome())).ifPresentOrElse(
				address -> party.setFkAddressHome(address.getId() == null ? addressDAO.insert(address) : address.getId()),
				() -> party.setFkAddressHome(null));

		Optional.ofNullable(AddressValidator.validateAddress(party.getAddressBilling())).ifPresentOrElse(
				address -> party.setFkAddressBilling(address.getId() == null ? addressDAO.insert(address) : address.getId()),
				() -> party.setFkAddressBilling(null));

		Optional.ofNullable(AddressValidator.validateAddress(party.getAddressResidential())).ifPresentOrElse(
				address -> party.setFkAddressResidential(address.getId() == null ? addressDAO.insert(address) : address.getId()),
				() -> party.setFkAddressResidential(null));
	}

	private PartyRes getAndPutTags(ReqContext reqContext, PartyRes prt) {
		// Caricare Tags
		List<Tag> partyTags = this.getPartyTags(
						reqContext, prt.getId()).stream()
				.map(pt -> new Tag(pt.getTagId(), pt.getTagCode(), pt.getTagI18nCode()))
				.collect(Collectors.toList());

		return prt.setTags((partyTags));
	}

	private PartyRes getAndPutExternalSource(ReqContext reqContext, PartyRes prt) {
		Optional.of(prt).map(PartyRes::getExternalSource)
				.map(ExternalSourceRes::getCode)
				.map(String::toUpperCase)
				.flatMap(code -> externalSourceDAO.getByCode(code, reqContext))
				.ifPresent(prt::setExternalSource);

		return prt;
	}

	private PartyEntity loadAndPutAddresses(PartyEntity partyEntity) {
		Optional.ofNullable(partyEntity.getFkAddressBilling())
				.flatMap(addressDAO::loadById)
				.ifPresent(partyEntity::setAddressBilling);
		Optional.ofNullable(partyEntity.getFkAddressHome())
				.flatMap(addressDAO::loadById)
				.ifPresent(partyEntity::setAddressHome);
		Optional.ofNullable(partyEntity.getFkAddressResidential())
				.flatMap(addressDAO::loadById)
				.ifPresent(partyEntity::setAddressResidential);
		return partyEntity;
	}

	protected List<PartyTagEntity> getPartyTagEntity(String tenantId, Long partyId) {
		Criteria criteria = CriteriaBuilder.and(List.of(
				CriteriaBuilder.number("ppd.party_id").eq(partyId),
				CriteriaBuilder.string("t.tenant_id").eq(tenantId)
		).toArray(new Criteria[0]));
		OrderBy sort = OrderByBuilder.field("t.tag_code").direction(SortDirection.ASC);
		return partyDAO.getPartyTags(criteria, sort);
	}

	private void checkReadOnlyFields(PartyUpdateReq party, PartyEntity entity, List<PartyTag> existingPartyTags, String sourceCode) {
		if (StringUtils.isBlank(entity.getSourceCode())
				|| StringUtils.equalsIgnoreCase(entity.getSourceCode(), sourceCode)) {
			return;
		}

		PartyUpdateReq actualParty = PartyMapper.INSTANCE.entityToUpdateReq(entity, existingPartyTags);

		for (String property : PARTY_READ_ONLY_FIELDS) {
			boolean isEqual = true;
			try {
				Field field = actualParty.getClass().getDeclaredField(property);
				field.setAccessible(true);
				Object value1 = field.get(actualParty);
				Object value2 = field.get(party);

				if (value1 == null && value2 == null) {
					continue;
				}
				if (value1 == null || value2 == null) {
					isEqual = false;
				}
				if (!Objects.equals(value1, value2)) {
					isEqual = false;
				}
			} catch (NoSuchFieldException | IllegalAccessException e) {
				throw new InternalServerErrorException(String.format("cannot check party read only properties (%s)", property), e);
			}

			if (!isEqual) {
				throw new InvalidPartyException(ErrCodes.INVALID_PARTY_READ_ONLY, String.format("party property '%s' cannot be updated", property));
			}
		}
	}

	private void checkSourceCode(PartyEntity entity) {
		if (null != entity.getSourceCode()) {
			externalSourceDAO.findByCode(entity.getTenantId(), entity.getSourceCode())
					.orElseThrow(() -> new InvalidPartyException(ErrCodes.INVALID_PAYLOAD,
							String.format("external source code '%s' not found", entity.getSourceCode())));
		}
	}

	private void validateDeathDate(PartyEntity entity) {
		if (entity.getDeathDate() != null && entity.getBirthDate() != null) {
			if (entity.getDeathDate().toLocalDate().isBefore(entity.getBirthDate().toLocalDate()) ||
					entity.getDeathDate().toLocalDate().isEqual(entity.getBirthDate().toLocalDate())) {
				throw new InvalidPartyException(ErrCodes.INVALID_PAYLOAD,
						String.format("deathDate %s is before the birthdate %s", entity.getDeathDate().toString(),
								entity.getBirthDate().toString()));
			}
		}
	}


	private void validateLegalStatus(PartyEntity entity, ReqContext reqContext) {
		boolean isLegalStatusActive = legalStatusDAO.countAll(reqContext.getTenantId()) > 0;
		String legalStatusCode = StringUtils.trimToNull(entity.getLegalStatus());
		if (isLegalStatusActive) {
			if (legalStatusCode == null) {
				throw new InvalidPartyException(ErrCodes.INVALID_PAYLOAD,
						"legalStatus is mandatory");
			}
			var legalStatus = legalStatusDAO.findOne(reqContext.getTenantId(), legalStatusCode)
					.orElseThrow(() -> new InvalidPartyException(ErrCodes.INVALID_PAYLOAD,
							String.format("legalStatus '%s' not found", legalStatusCode)));
			//sonarqube
			log.trace("validated legalStatus {}", legalStatus.getCode());
		} else {
			if (legalStatusCode != null) {
				//per scelta non c'è nessuna validazione e non si resetta il campo!
				log.warn("payload contains legalStatus {}, but should be null", legalStatusCode);
			}
		}
	}


}
