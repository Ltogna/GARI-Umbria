package com.abacogroup.partyregistry.core.impl;

import com.abacogroup.dynamicdocuments.services.DocumentTypeService;
import com.abacogroup.jdbi.criteria.Criteria;
import com.abacogroup.jdbi.orderby.OrderBy;
import com.abacogroup.partyregistry.api.DocType;
import com.abacogroup.partyregistry.api.PartyTypeEnum;
import com.abacogroup.partyregistry.api.Tag;
import com.abacogroup.partyregistry.core.DocTypeService;
import com.abacogroup.partyregistry.core.PartyService;
import com.abacogroup.partyregistry.db.dao.DocTypeDAO;
import com.abacogroup.partyregistry.resources.req.DocTypeSearchReq;
import com.abacogroup.partyregistry.resources.req.ReqContext;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class DocTypeServiceImpl implements DocTypeService {

	private final DocTypeDAO docTypeDAO;
	private final PartyService partyService;
	private final DocumentTypeService documentTypeService;

	public DocTypeServiceImpl(DocTypeDAO DocTypeDAO, PartyService partyService, DocumentTypeService documentTypeService) {
		this.docTypeDAO = DocTypeDAO;
		this.partyService = partyService;
		this.documentTypeService = documentTypeService;
	}

	@Override
	public List<DocType> search(ReqContext reqContext, DocTypeSearchReq searchRequest, List<Long> tagIds, PartyTypeEnum... partyTypeEnum) {
		Criteria criteria = searchRequest.getCriteria(reqContext);
		OrderBy sort = searchRequest.getSort();

		if (null == tagIds || tagIds.isEmpty()) {
			return docTypeDAO.searchAsList(reqContext,
							Arrays.stream(partyTypeEnum).map(Enum::name).collect(Collectors.toSet()),
							criteria,
							sort)
					.stream()
					.map(docType -> DocTypeMapper.addDefinitionMetaData(reqContext, docType, documentTypeService)
					).collect(Collectors.toList());
		} else {
			return docTypeDAO.searchAsList(reqContext,
							tagIds,
							Arrays.stream(partyTypeEnum).map(Enum::name).collect(Collectors.toSet()),
							criteria,
							sort)
					.stream()
					.map(docType -> DocTypeMapper.addDefinitionMetaData(reqContext, docType, documentTypeService)
					).collect(Collectors.toList());
		}

	}

	@Override
	public List<DocType> search(ReqContext reqContext, Long partyId, DocTypeSearchReq searchRequest) {
		var party = partyService.getPartyById(reqContext, partyId).orElseThrow();
		PartyTypeEnum partyTypeEnum = party.getPartyType();
		var tags = party.getTags().stream().map(Tag::getId).collect(Collectors.toList());
		return search(reqContext, searchRequest, tags, partyTypeEnum);
	}

	@Override
	public Optional<DocType> getByDocType(ReqContext reqContext, String docType) {
		return docTypeDAO.searchByDocType(reqContext, docType);
	}

}
