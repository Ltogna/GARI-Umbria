package com.abacogroup.partyregistry.resources;

import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.partyregistry.api.UserPermissions;
import com.abacogroup.partyregistry.core.UserSupportService;
import com.abacogroup.partyregistry.resources.req.ReqContext;

import io.dropwizard.auth.Auth;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.annotation.security.RolesAllowed;
import jakarta.ws.rs.DefaultValue;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.HeaderParam;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;

@Path(ResourceConstants.API_PRIV + "/user")
@Produces(MediaType.APPLICATION_JSON)
@Tag(name = "Users", description = "Operations on users")
public class UserSupportResource {

	private final UserSupportService userSupportService;

	public UserSupportResource(UserSupportService userSupportService) {
		this.userSupportService = userSupportService;
	}

	@Operation(summary = "Get user's permissions", description = "Get user's permissions")
	@ApiResponse(responseCode = "200", description = "Successfully, returns user's permissions",
					content = @Content(mediaType = "application/json", schema = @Schema(implementation = UserPermissions.class)))
	@GET
	@RolesAllowed("PARTY-REGISTRY|READ")
	@Path("/permissions")
	public UserPermissions getUserPermissions(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "the tenant ID") @PathParam("tenant") String tenantId) {
		
		return userSupportService.getUserPermissions(new ReqContext(user, lang));
	}
}
