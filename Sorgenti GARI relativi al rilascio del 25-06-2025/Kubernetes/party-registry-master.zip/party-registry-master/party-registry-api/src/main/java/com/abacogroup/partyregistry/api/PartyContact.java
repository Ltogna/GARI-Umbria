package com.abacogroup.partyregistry.api;

import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

@Data
@NoArgsConstructor
@Accessors(chain = true)
public class PartyContact {

	private Long pkid;
	private Long partyId;
	@NotNull
	private ContactTypeEnum contactType;
	@NotNull
	private String subType;
	@NotEmpty
	private String contactValue;
	private String note;

}
