package com.abacogroup.partyregistry.core.exceptions;

import io.swagger.v3.oas.annotations.media.Schema;

public class InvalidPartyRelationException extends AbstractPartyException {

	public InvalidPartyRelationException(String code, String message) {
		super(new ErrorBody(code, message));
	}

	@Schema(name = "InvalidPartyRelationExceptionErrorBody")
	public static class ErrorBody implements ExceptionErrorBody {
		private final String code;
		private final String message;

		public ErrorBody(String code, String message) {
			this.code = code;
			this.message = message;
		}

		@Override
		@Schema(allowableValues = { ErrCodes.RELATION_NOT_FOUND, ErrCodes.RELATION_ROLE_NOT_FOUND, ErrCodes.RELATION_PARTY_NOT_FOUND,
				ErrCodes.RELATION_PARTY_ALREADY_DEFINED })
		public String getErrorCode() {
			return code;
		}

		@Override
		@Schema
		public String getMessage() {
			return message;
		}
	}

}
