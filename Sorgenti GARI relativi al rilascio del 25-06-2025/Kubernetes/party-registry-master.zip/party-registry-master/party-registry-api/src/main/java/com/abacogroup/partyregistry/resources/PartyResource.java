package com.abacogroup.partyregistry.resources;

import java.util.Map;

import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.partyregistry.api.PartyCheckResponse;
import com.abacogroup.partyregistry.api.PartyRes;
import com.abacogroup.partyregistry.api.PartySearchRes;
import com.abacogroup.partyregistry.core.AclService;
import com.abacogroup.partyregistry.core.ExternalSourceService;
import com.abacogroup.partyregistry.core.PartyService;
import com.abacogroup.partyregistry.core.exceptions.ErrCodes;
import com.abacogroup.partyregistry.core.exceptions.ExternalSourceException;
import com.abacogroup.partyregistry.core.exceptions.InvalidPartyException;
import com.abacogroup.partyregistry.core.exceptions.InvalidPayloadException;
import com.abacogroup.partyregistry.resources.req.PartyCheckReq;
import com.abacogroup.partyregistry.resources.req.PartyCodeCheckReq;
import com.abacogroup.partyregistry.resources.req.PartyCreateReq;
import com.abacogroup.partyregistry.resources.req.PartyExternalReq;
import com.abacogroup.partyregistry.resources.req.PartySearchReq;
import com.abacogroup.partyregistry.resources.req.PartyUpdateReq;
import com.abacogroup.partyregistry.resources.req.ReqContext;

import io.dropwizard.auth.Auth;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.annotation.security.RolesAllowed;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import jakarta.ws.rs.BeanParam;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.DefaultValue;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.HeaderParam;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

@SuppressWarnings("UnresolvedRestParam")
@Path(ResourceConstants.API_PRIV + "/parties")
@Produces(MediaType.APPLICATION_JSON)
@Tag(name = "parties", description = "Operations on parties")
public class PartyResource {


	private static final boolean SKIP_ACL_IF_CAN_IGNORE = true;
	private static final String NO_EXTERNAL_SOURCE_CODE = null;

	private final AclService aclService;
	private final PartyService partyService;
	private final ExternalSourceService externalSourceService;

	public PartyResource(AclService aclService, PartyService partyService, ExternalSourceService externalSourceService) {
		this.aclService = aclService;
		this.partyService = partyService;
		this.externalSourceService = externalSourceService;
	}

	@Operation(summary = "List of parties", description = "Get list of parties filtered with criteria")
	@ApiResponses({
			@ApiResponse(responseCode = "200", description = "Successfully, returns a list of parties (sorted/filtered)",
					content = @Content(mediaType = "application/json", schema = @Schema(ref = "#/components/schemas/InfiniteListResultsPartySearchRes"))),
			@ApiResponse(responseCode = "400", description = "Invalid searchRequest, at least one criteria should be specified",
					content = @Content(schema = @Schema(implementation = InvalidPayloadException.ErrorBody.class)))
	})
	@GET
	@RolesAllowed("PARTY-REGISTRY|READ")
	public InfiniteListResults<PartySearchRes> search(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "the tenant ID") @PathParam("tenant") String tenantId,
			@Parameter(description = "Can be supplied to obtain the records that follows those obtained by a previous call") @QueryParam("nextKey") String nextKey,
			@BeanParam @Valid PartySearchReq partySearchReq
	) {
		if (!partySearchReq.isValid()) {
			throw new InvalidPayloadException(ErrCodes.INVALID_PAYLOAD, "at least one field is required");
		}
		ReqContext reqContext = new ReqContext(user, lang);
		
		int aclManageLevel = aclService.ignoreACL(reqContext) ? AclService.MANAGE_SKIP : AclService.MANAGE_FULL;
		
		return partyService.search(reqContext, partySearchReq, aclManageLevel, nextKey);
	}

	@Operation(summary = "Find party by ID", description = "Get party info based on its ID")
	@ApiResponses({
			@ApiResponse(responseCode = "200", description = "Successfully, party is found",
					content = @Content(mediaType = "application/json", schema = @Schema(implementation = PartyRes.class))) })
	@GET
	@RolesAllowed("PARTY-REGISTRY|READ")
	@Path("/{id}")
	public PartyRes getById(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "the tenant ID") @PathParam("tenant") String tenantId,

			@Parameter(description = "the party ID") @PathParam("id") Long id
	) {
		ReqContext reqContext = new ReqContext(user, lang);
		
		// skip ACL check if enabled and user has IGNORE_PARTIES_ACL function
		aclService.canRead(reqContext, id, SKIP_ACL_IF_CAN_IGNORE);
		
		return this.partyService.getPartyById(reqContext, id)
				.orElse(null);
	}

	@Operation(summary = "Create Party", description = "Insert a new party")
	@ApiResponses({
			@ApiResponse(responseCode = "200", description = "Successfully, the new party is created",
					content = @Content(mediaType = "application/json", schema = @Schema(implementation = PartyRes.class)))
	})
	@POST
	@RolesAllowed("PARTY-REGISTRY|WRITE")
	public PartyRes add(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "the tenant ID") @PathParam("tenant") String tenantId,

			@NotNull @Valid PartyCreateReq party
	) {
		//TODO valutare pojo apposito
		ReqContext reqContext = new ReqContext(user, lang);
		
		// if ACL is enabled check if the user have IGNORE_ACL_FUNCTION so create new parties 
		aclService.canAdd(reqContext);
		
		return partyService.insert(reqContext, party, NO_EXTERNAL_SOURCE_CODE);

	}

	@Operation(summary = "Create or Update Party from External source",
			description = "Create or Update Party from External source given a party code")
	@ApiResponses({
			@ApiResponse(responseCode = "200", description = "Successfully, the new party is created or updated", useReturnTypeSchema = true),
			@ApiResponse(responseCode = "404", description = "Party code not found on external source",
					content = @Content(mediaType = MediaType.APPLICATION_JSON, schema = @Schema(implementation = ExternalSourceException.ErrorBody.class))),
			@ApiResponse(responseCode = "400", description = "Source code not found",
					content = @Content(mediaType = MediaType.APPLICATION_JSON, schema = @Schema(implementation = ExternalSourceException.ErrorBody.class))),
			@ApiResponse(responseCode = "502", description = "external service payload error",
					content = @Content(mediaType = MediaType.APPLICATION_JSON, schema = @Schema(implementation = ExternalSourceException.ErrorBody.class)))
	})
	@PUT
	@Path("/external")
	@RolesAllowed("PARTY-REGISTRY|WRITE")
	public PartyRes addFromExternalSource(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "the tenant ID") @PathParam("tenant") String tenantId,
			@NotNull @Valid PartyExternalReq req
	) {
		ReqContext reqContext = new ReqContext(user, lang);
		
		// XXX ???? va fatto anche qui?
		
		return externalSourceService.upsertParty(reqContext, req);
	}

    @Operation(summary = "Check Party Existence on external source",
            description = "Check Party Existence on external source")
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "Success", useReturnTypeSchema = true)
    })
    @GET
    @Path("/external/check-existence/source/{sourceCode}/party/{partyCode}")
    @RolesAllowed("PARTY-REGISTRY|WRITE")
    public boolean checkPartyExistenceOnExternalSourceByCode(
            @HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(description = "The source code") @PathParam("sourceCode") String sourceCode,
			@Parameter(description = "The party code") @PathParam("partyCode") String partyCode,
            @Parameter(hidden = true) @Auth User user
			) {
        ReqContext reqContext = new ReqContext(user, lang);
        return externalSourceService.checkPartyExistenceOnExternalSourceByCode(reqContext, PartyExternalReq.builder()
						.setPartyCode(partyCode)
						.setSourceCode(sourceCode)
				.build());
    }

	@Operation(summary = "Check duplicated parties", description = "check if the same subject already exists")
	@ApiResponses({
			@ApiResponse(responseCode = "200", description = "Successfully, return if the same party exists or not",
					content = @Content(mediaType = "application/json", schema = @Schema(implementation = PartyCheckResponse.class))),
			@ApiResponse(responseCode = "400", description = "Invalid checkRequest, VAT/TAX should be specified",
					content = @Content(schema = @Schema(implementation = InvalidPayloadException.ErrorBody.class)))
	})
	@GET
	@RolesAllowed("PARTY-REGISTRY|READ")
	@Path("/duplicates")
	@Deprecated
	public PartyCheckResponse checkDuplicated(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "the tenant ID") @PathParam("tenant") String tenantId,
			@BeanParam @Valid PartyCheckReq partyCheckRequest) {

		if (!partyCheckRequest.isValid()) {
			throw new InvalidPayloadException(ErrCodes.INVALID_PAYLOAD, "one between TaxCode and vat number is required");
		}
		PartyCheckResponse checkResponse = new PartyCheckResponse().setDuplicated(false);

		//true == duplicate presente
		if (partyService.loadDuplicates(tenantId, partyCheckRequest).size() > 0) {
			return checkResponse.setDuplicated(true);
		}
		return checkResponse;
	}

	@Operation(summary = "Check duplicated parties", description = "check if the same subject already exists")
	@ApiResponses({
			@ApiResponse(responseCode = "200", description = "Successfully, return if the same party exists, specifying the redundant field",
					content = @Content(mediaType = "application/json", schema = @Schema(implementation = PartyCheckResponse.class))),
			@ApiResponse(responseCode = "400", description = "Invalid checkRequest, VAT/TAX should be specified",
					content = @Content(schema = @Schema(implementation = InvalidPayloadException.ErrorBody.class)))
	})
	@GET
	@RolesAllowed("PARTY-REGISTRY|READ")
	@Path("/duplicates_detailed")
	public Map<String,Boolean> checkMultipleDuplicated(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "the tenant ID") @PathParam("tenant") String tenantId,
			@BeanParam @Valid PartyCheckReq partyCheckRequest) {
		if (!partyCheckRequest.isValid()) {
			throw new InvalidPayloadException(ErrCodes.INVALID_PAYLOAD, "at least, one between TaxCode and vat number is required");
		}
		return partyService.loadDuplicatesDetail(tenantId,partyCheckRequest);
	}

	@Operation(summary = "Check duplicated code", description = "check if there is parties with the same code")
	@ApiResponses({
			@ApiResponse(responseCode = "200", description = "Successfully, return if the same code exists or not",
					content = @Content(mediaType = "application/json", schema = @Schema(implementation = PartyCheckResponse.class))),
			@ApiResponse(responseCode = "400", description = "Invalid checkRequest, code should be specified",
					content = @Content(schema = @Schema(implementation = InvalidPayloadException.ErrorBody.class)))
	})
	@GET
	@RolesAllowed("PARTY-REGISTRY|READ")
	@Path("/duplicates_code")
	public PartyCheckResponse checkDuplicatedCode(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "the tenant ID") @PathParam("tenant") String tenantId,
			@BeanParam @Valid PartyCodeCheckReq partyCodeCheckReq) {

		PartyCheckResponse checkResponse = new PartyCheckResponse().setDuplicated(false);

		if (partyService.loadDuplicatesCode(tenantId, partyCodeCheckReq).size() > 0) {
			return checkResponse.setDuplicated(true);
		}
		return checkResponse;
	}

	@Operation(summary = "Update Party", description = "Update an existing party")
	@ApiResponses({
			@ApiResponse(responseCode = "200", description = "Successfully, the party is updated",
					content = @Content(mediaType = "application/json", schema = @Schema(implementation = PartyRes.class))),
			@ApiResponse(responseCode = "400", description = "this party does not exist",
					content = @Content(schema = @Schema(implementation = InvalidPartyException.ErrorBody.class)))
	})
	@PUT
	@RolesAllowed("PARTY-REGISTRY|WRITE")
	@Path("/{id}")
	public PartyRes update(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "the tenant ID") @PathParam("tenant") String tenantId,

			@Parameter(description = "the party ID") @PathParam("id") Long id,
			@NotNull @Valid PartyUpdateReq party) {
		ReqContext reqContext = new ReqContext(user, lang);
		aclService.canWrite(reqContext, id);
		return partyService.update(reqContext, id, party);
	}

	@Operation(summary = "archive a party", description = "Set the status archived to true")
	@ApiResponses({
			@ApiResponse(responseCode = "200", description = "Successfully, the party was archived",
					content = @Content(mediaType = "application/json", schema = @Schema(implementation = PartyRes.class))),
			@ApiResponse(responseCode = "400", description = "party not found",
					content = @Content(schema = @Schema(implementation = InvalidPartyException.ErrorBody.class)))

	})
	@PUT
	@RolesAllowed("PARTY-REGISTRY|WRITE")
	@Path("/{id}/archived_flag")
	public PartyRes archivePut(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "the tenant ID") @PathParam("tenant") String tenantId,

			@Parameter(description = "the party ID") @PathParam("id") Long id
	) {
		ReqContext reqContext = new ReqContext(user, lang);
		aclService.canWrite(reqContext, id);
		return partyService.archive(reqContext, id, true);
	}

	@Operation(summary = "unarchive a party", description = "Set the status archived to false")
	@ApiResponses({
			@ApiResponse(responseCode = "200", description = "Successfully, the party was unarchived",
					content = @Content(mediaType = "application/json", schema = @Schema(implementation = PartyRes.class))),
			@ApiResponse(responseCode = "400", description = "party not found", content = @Content(schema = @Schema(implementation = InvalidPartyException.ErrorBody.class)))
	})
	@DELETE
	@RolesAllowed("PARTY-REGISTRY|WRITE")
	@Path("/{id}/archived_flag")
	public PartyRes archiveRestore(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "the tenant ID") @PathParam("tenant") String tenantId,

			@Parameter(description = "the party ID") @PathParam("id") Long id
	) {
		ReqContext reqContext = new ReqContext(user, lang);
		aclService.canWrite(reqContext, id);
		return partyService.archive(reqContext, id, false);
	}

	@Operation(summary = "delete party", description = "delete an existing party by setting it as expired")
	@ApiResponses({
			@ApiResponse(responseCode = "200", description = "Party deleted (Expired)"),
			@ApiResponse(responseCode = "400", description = "Party not found", content = @Content(schema = @Schema(implementation = InvalidPartyException.ErrorBody.class)))
	})
	@DELETE
	@RolesAllowed("PARTY-REGISTRY|DELETE")
	@Path("/{id}")
	public Response expire(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "the tenant ID") @PathParam("tenant") String tenantId,

			@Parameter(description = "the party ID") @PathParam("id") Long id) {
		ReqContext reqContext = new ReqContext(user, lang);
		aclService.canWrite(reqContext, id);
		this.partyService.expire(reqContext, id);
		return Response.ok().build();
	}

}
