package com.abacogroup.partyregistry.bundle.config;

import com.abacogroup.bundles.initializer.impl.exceptions.BundleException;
import com.abacogroup.bundles.listener.configdata.ConfigDataMessage;
import com.abacogroup.bundles.listener.configdata.ConfigMessageProcessor;
import com.abacogroup.partyregistry.bundle.config.i18n.I18nAware;
import com.abacogroup.partyregistry.bundle.config.i18n.I18nEntry;
import com.abacogroup.partyregistry.bundle.config.i18n.I18nHelper;
import com.abacogroup.partyregistry.bundle.config.i18n.I18nMap;
import com.abacogroup.partyregistry.core.BundleConstants;
import com.abacogroup.partyregistry.db.dao.CitizenshipDAO;
import com.abacogroup.partyregistry.db.dao.I18nDAO;
import com.abacogroup.partyregistry.db.ntt.CitizenshipEntity;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

@Slf4j
public class CitizenshipConfigMessageProcessor implements ConfigMessageProcessor {
	private final CitizenshipDAO citizenshipDAO;
	private final ObjectMapper mapper = new ObjectMapper();
	private final I18nHelper i18nHelper;

	public CitizenshipConfigMessageProcessor(CitizenshipDAO citizenshipDAO, I18nDAO i18nDAO) {
		this.citizenshipDAO = citizenshipDAO;
		this.i18nHelper = new I18nHelper(i18nDAO);

	}

	@Override
	public String getDomainName() {
		return BundleConstants.CITIZENSHIP;
	}

	@Override
	public void onMessage(ConfigDataMessage message) {
		String tenantId = message.getTenantId();
		message.getConfigFiles().forEach(path -> {
			addContent(tenantId, path);
		});
	}

	private void addContent(String tenantId, Path path) {
		try {
			try (Stream<String> input = Files.lines(path, StandardCharsets.UTF_8)) {

				List<CitizenshipEntry> entries = input
						.map(String::strip)
						.filter(s -> !StringUtils.isBlank(s))
						.filter(s -> !s.startsWith(BundleConstants.JSONL_COMMENT))
						.map(jsonLine -> mapEntity(tenantId, jsonLine))
						.distinct()
						.collect(Collectors.toList());

				CitizenshipEntity[] entities = entries
						.stream()
						.map(e -> CitizenshipEntity.builder()
								.setTenantId(tenantId)
								.setCode(e.getCode())
								.build())
						.toArray(CitizenshipEntity[]::new);

				citizenshipDAO.insertIdempotent(entities);

				i18nHelper.upsert(tenantId, "prt_citizenship", "code", entries);

			}
		} catch (Exception e) {
			throw new BundleException(String.format("error saving file %s", path), e);
		}
	}

	private CitizenshipEntry mapEntity(String tenantId, String jsonLine) {
		try {
			CitizenshipEntry entry = mapper.readValue(jsonLine, CitizenshipEntry.class);
			return entry;
		} catch (Exception e) {
			throw new BundleException("error in deserialization json " + jsonLine, e);
		}
	}

	@Data
	protected static class CitizenshipEntry implements I18nAware {
		private String code;

		private I18nMap description;

		@JsonIgnore
		@Override
		public String getI18nCode() {
			return getCode();
		}

		@JsonIgnore
		@Override
		public Set<I18nEntry> getI18n() {
			return getDescription().getI18n();
		}

	}
}
