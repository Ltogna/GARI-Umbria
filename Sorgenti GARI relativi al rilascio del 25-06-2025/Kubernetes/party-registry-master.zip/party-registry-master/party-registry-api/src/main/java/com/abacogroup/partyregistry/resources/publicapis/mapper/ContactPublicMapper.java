package com.abacogroup.partyregistry.resources.publicapis.mapper;

import com.abacogroup.partyregistry.api.ContactSearchResponse;
import com.abacogroup.partyregistry.api.v1.ContactSearchResponseV1;
import com.abacogroup.partyregistry.api.v1.req.ContactSearchRequestV1;
import com.abacogroup.partyregistry.resources.req.ContactSearchReq;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper
public interface ContactPublicMapper {

	ContactPublicMapper INSTANCE = Mappers.getMapper(ContactPublicMapper.class);

	ContactSearchResponseV1 toSearchResponseV1(ContactSearchResponse res);

	ContactSearchReq fromSearchRequestV1(ContactSearchRequestV1 requestV1);


}
