package com.abacogroup.partyregistry.resources.publicapis;

import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.partyregistry.api.v1.LegalStatusResponseV1;
import com.abacogroup.partyregistry.api.v1.req.LegalStatusSearchRequestV1;
import com.abacogroup.partyregistry.core.LegalStatusV1Service;
import com.abacogroup.partyregistry.resources.PublicResourceConstants;
import com.abacogroup.partyregistry.resources.req.ReqContext;
import io.dropwizard.auth.Auth;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.ws.rs.BeanParam;
import jakarta.ws.rs.DefaultValue;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.HeaderParam;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.MediaType;

@Path(PublicResourceConstants.API_V1_PUB + "/legal-status")
@Produces(MediaType.APPLICATION_JSON)
@Tag(name = "LegalStatus", description = "Operations on legal-status")
public class LegalStatusPublicResource {

	private final LegalStatusV1Service legalStatusService;

	public LegalStatusPublicResource(LegalStatusV1Service legalStatusService) {
		this.legalStatusService = legalStatusService;
	}

	@Operation(summary = "List of legal status", description = "Get list of legal status filtered with criteria")
	@ApiResponses({
			@ApiResponse(responseCode = "200", description = "Successfully, returns a list of legal status (sorted/filtered)",
					content = @Content(mediaType = "application/json", schema = @Schema(ref = "#/components/schemas/InfiniteListResultsLegalStatusResponseV1")))
	})
	@GET
	public InfiniteListResults<LegalStatusResponseV1> search(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "tenant ID") @PathParam("tenant") String tenantId,
			@Parameter(description = "Can be supplied to obtain the records that follows those obtained by a previous call") @QueryParam("nextKey") String nextKey,
			@BeanParam LegalStatusSearchRequestV1 searchRequest) {

		ReqContext reqContext = new ReqContext(user, lang);
		return legalStatusService.search(reqContext, searchRequest, nextKey);
	}

	@Operation(summary = "Find a legal status by CODE", description = "Returns a legal status based on its CODE")
	@ApiResponses({
			@ApiResponse(responseCode = "200", description = "Successfully, a legal status is found",
					content = @Content(mediaType = "application/json", schema = @Schema(implementation = LegalStatusResponseV1.class))),
	})
	@GET
	@Path("/{code}")
	public LegalStatusResponseV1 getByCode(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "tenant ID") @PathParam("tenant") String tenantId,
			@Parameter(description = "the legal status CODE") @PathParam("code") String code
	) {
		ReqContext reqContext = new ReqContext(user, lang);
		return this.legalStatusService.getByCode(reqContext, code)
				.orElse(null);
	}

}
