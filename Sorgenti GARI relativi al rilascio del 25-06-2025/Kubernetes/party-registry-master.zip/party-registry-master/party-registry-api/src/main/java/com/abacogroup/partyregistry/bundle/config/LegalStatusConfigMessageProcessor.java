package com.abacogroup.partyregistry.bundle.config;

import com.abacogroup.bundles.initializer.impl.exceptions.BundleException;
import com.abacogroup.bundles.listener.configdata.ConfigDataMessage;
import com.abacogroup.bundles.listener.configdata.ConfigMessageProcessor;
import com.abacogroup.partyregistry.bundle.config.i18n.I18nAware;
import com.abacogroup.partyregistry.bundle.config.i18n.I18nEntry;
import com.abacogroup.partyregistry.bundle.config.i18n.I18nHelper;
import com.abacogroup.partyregistry.bundle.config.i18n.I18nMap;
import com.abacogroup.partyregistry.bundle.utils.FileOperationEnum;
import com.abacogroup.partyregistry.core.BundleConstants;
import com.abacogroup.partyregistry.db.dao.I18nDAO;
import com.abacogroup.partyregistry.db.dao.LegalStatusDAO;
import com.abacogroup.partyregistry.db.ntt.LegalStatusEntity;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@Slf4j
public class LegalStatusConfigMessageProcessor implements ConfigMessageProcessor {
	private final LegalStatusDAO legalStatusDAO;
	private final ObjectMapper mapper = new ObjectMapper();
	private final I18nHelper i18nHelper;

	public LegalStatusConfigMessageProcessor(LegalStatusDAO legalStatusDAO, I18nDAO i18nDAO) {
		this.legalStatusDAO = legalStatusDAO;
		this.i18nHelper = new I18nHelper(i18nDAO);

	}

	@Override
	public String getDomainName() {
		return BundleConstants.LEGAL_STATUS;
	}

	@Override
	public void onMessage(ConfigDataMessage message) {
		String tenantId = message.getTenantId();

		Function<String, FileOperationEnum> groupingPredicate = x -> {
			if (StringUtils.containsIgnoreCase(x, "delete")) {
				return FileOperationEnum.DELETE;
			} else {
				return FileOperationEnum.DEFAULT;
			}
		};

		List<Path> paths = message.getConfigFiles();
		var map = paths.stream()
				.collect(Collectors.groupingBy(x -> groupingPredicate.apply(x.toString()),
						Collectors.toCollection(ArrayList::new)));

		map.getOrDefault(FileOperationEnum.DELETE, new ArrayList<>()).forEach(path -> removeContent(tenantId, path));
		map.getOrDefault(FileOperationEnum.DEFAULT, new ArrayList<>()).forEach(path -> addContent(tenantId, path));

//		message.getConfigFiles().forEach(path -> {
//			addContent(tenantId, path);
//		});
	}

	private void addContent(String tenantId, Path path) {
		try {
			try (Stream<String> input = Files.lines(path, StandardCharsets.UTF_8)) {

				List<LegalStatusEntry> entries = input
						.map(String::strip)
						.filter(s -> !StringUtils.isBlank(s))
						.filter(s -> !s.startsWith(BundleConstants.JSONL_COMMENT))
						.map(jsonLine -> mapEntity(tenantId, jsonLine))
						.distinct()
						.collect(Collectors.toList());

				LegalStatusEntity[] entities = entries
						.stream()
						.map(e -> LegalStatusEntity.builder()
								.setTenantId(tenantId)
								.setCode(e.getCode())
								.build())
						.toArray(LegalStatusEntity[]::new);

				legalStatusDAO.insertIdempotent(entities);

				i18nHelper.upsert(tenantId, "prt_legal_status", "code", entries);

			}
		} catch (Exception e) {
			throw new BundleException(String.format("error saving file %s", path), e);
		}
	}

	private void removeContent(String tenantId, Path path) {
		try {
			try (Stream<String> input = Files.lines(path, StandardCharsets.UTF_8)) {

				List<LegalStatusEntry> entries = input
						.map(String::strip)
						.filter(s -> !StringUtils.isBlank(s))
						.filter(s -> !s.startsWith(BundleConstants.JSONL_COMMENT))
						.map(jsonLine -> mapEntity(tenantId, jsonLine))
						.distinct()
						.collect(Collectors.toList());

				entries.forEach(e -> {
					int delete = legalStatusDAO.deleteUnused(tenantId, e.getCode());
					if (delete > 0) {
						i18nHelper.deleteUnused(tenantId, "prt_legal_status", "code", e.getCode());
					} else {
						log.warn("cannot delete {} due to references", e.getCode());
					}
				});

			}
		} catch (Exception e) {
			throw new BundleException(String.format("error deleting entries from file %s", path), e);
		}
	}

	private LegalStatusEntry mapEntity(String tenantId, String jsonLine) {
		try {
			LegalStatusEntry entry = mapper.readValue(jsonLine, LegalStatusEntry.class);
			return entry;
		} catch (Exception e) {
			throw new BundleException("error in deserialization json " + jsonLine, e);
		}
	}

	@Data
	protected static class LegalStatusEntry implements I18nAware {
		private String code;

		private I18nMap description;

		@JsonIgnore
		@Override
		public String getI18nCode() {
			return getCode();
		}

		@JsonIgnore
		@Override
		public Set<I18nEntry> getI18n() {
			return getDescription().getI18n();
		}

	}
}
