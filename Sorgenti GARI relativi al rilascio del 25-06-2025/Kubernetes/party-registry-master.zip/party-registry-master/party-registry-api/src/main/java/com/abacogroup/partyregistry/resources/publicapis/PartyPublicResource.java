package com.abacogroup.partyregistry.resources.publicapis;

import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.partyregistry.api.v1.AppConfigResponseV1;
import com.abacogroup.partyregistry.api.v1.PartyResponseV1;
import com.abacogroup.partyregistry.api.v1.PartySearchResponseV1;
import com.abacogroup.partyregistry.api.v1.req.PartyByIdInSearchRequestV1;
import com.abacogroup.partyregistry.api.v1.req.PartySearchRequestV1;
import com.abacogroup.partyregistry.core.AclService;
import com.abacogroup.partyregistry.core.AppConfigV1Service;
import com.abacogroup.partyregistry.core.PartyV1Service;
import com.abacogroup.partyregistry.core.exceptions.ErrCodes;
import com.abacogroup.partyregistry.core.exceptions.InvalidPayloadException;
import com.abacogroup.partyregistry.resources.PublicResourceConstants;
import com.abacogroup.partyregistry.resources.req.ReqContext;
import io.dropwizard.auth.Auth;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import jakarta.ws.rs.BeanParam;
import jakarta.ws.rs.DefaultValue;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.HeaderParam;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.MediaType;
import java.util.List;
import java.util.Optional;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

@SuppressWarnings("UnresolvedRestParam")
@Path(PublicResourceConstants.API_V1_PUB + "/parties")
@Produces(MediaType.APPLICATION_JSON)
@Tag(name = "parties", description = "Operations on parties")
@Slf4j
public class PartyPublicResource {

	private static final String WITH_MANAGE_PARAM_DESCRIPTION = "acl value to access the resource: -1 skip check, 0 must have almost one read mandate, 1 must have almost one manage mandate";
	private final PartyV1Service partyV1Service;
	private final AclService aclService;

	private final AppConfigV1Service appConfigV1Service;

	public PartyPublicResource(PartyV1Service partyV1Service, AclService aclService, AppConfigV1Service appConfigV1Service) {
		this.partyV1Service = partyV1Service;
		this.aclService = aclService;
		this.appConfigV1Service = appConfigV1Service;
	}

	@Operation(summary = "List of parties", description = "Get list of parties filtered with criteria")
	@ApiResponses({
			@ApiResponse(responseCode = "200", description = "Successfully, returns a list of parties (sorted/filtered)", content = @Content(mediaType = "application/json", schema = @Schema(ref = "#/components/schemas/InfiniteListResultsPartySearchResponseV1"))),
			@ApiResponse(responseCode = "400", description = "Invalid searchRequest, at least one criteria should be specified", content = @Content(schema = @Schema(implementation = InvalidPayloadException.ErrorBody.class)))
	})
	@GET
	//@RolesAllowed()
	public InfiniteListResults<PartySearchResponseV1> search(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "the tenant ID") @PathParam("tenant") String tenantId,
			@Parameter(description = "Can be supplied to obtain the records that follows those obtained by a previous call") @QueryParam("nextKey") String nextKey,
			@Parameter(description = WITH_MANAGE_PARAM_DESCRIPTION) @DefaultValue("1") @QueryParam("withManage") Integer withManage,
			@BeanParam @Valid PartySearchRequestV1 partySearchReq) {
		if (!isValid(partySearchReq)) {
			throw new InvalidPayloadException(ErrCodes.INVALID_PAYLOAD, "at least one field is required");
		}

		ReqContext reqContext = new ReqContext(user, lang);

		if (!StringUtils.isBlank(partySearchReq.getCode())) {
			//! ISSUE: substituting code to taxCode for special configuration
			//? STATUS : Solved
			Optional<AppConfigResponseV1> appConfigResponseV1 = appConfigV1Service.searchByKey(reqContext, "code");

			if (appConfigResponseV1.isEmpty()) {
				partySearchReq.setTaxOrVat(partySearchReq.getCode());
				partySearchReq.setCode(null);
			}
		}

		return partyV1Service.publicSearch(reqContext, partySearchReq, withManage, nextKey);
	}

	@Operation(summary = "Find party by ID", description = "Get party info based on its ID")
	@ApiResponses({
			@ApiResponse(responseCode = "200", description = "Successfully, party is found", content = @Content(mediaType = "application/json", schema = @Schema(implementation = PartyResponseV1.class))) })
	@GET
	@Path("/{id}")
	//@RolesAllowed()
	public PartyResponseV1 getById(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "the tenant ID") @PathParam("tenant") String tenantId,
			@Parameter(description = "the party ID") @PathParam("id") Long id,
			@Parameter(description = WITH_MANAGE_PARAM_DESCRIPTION) @DefaultValue("1") @QueryParam("withManage") Integer withManage) {
		ReqContext reqContext = new ReqContext(user, lang);

		//  when withManage is -1 the canRead is skipped
		if (withManage == null || !withManage.equals(-1)) {
			aclService.canRead(reqContext, id);
		}

		return this.partyV1Service.getPartyResponseById(reqContext, id)
				.orElse(null);
	}

	@Operation(summary = "List of parties", description = "Get list of parties by a list of ID")
	@ApiResponse(responseCode = "200", description = "Successfully, returns a list of parties", content = @Content(mediaType = "application/json", array = @ArraySchema(schema = @Schema(implementation = PartySearchResponseV1.class))))
	@POST
	//@RolesAllowed()
	public List<PartySearchResponseV1> getByIdIn(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "the tenant ID") @PathParam("tenant") String tenantId,
			@Parameter(description = WITH_MANAGE_PARAM_DESCRIPTION) @DefaultValue("1") @QueryParam("withManage") Integer withManage,
			@NotNull @Valid PartyByIdInSearchRequestV1 partySearchReq) {
		ReqContext reqContext = new ReqContext(user, lang);
		return partyV1Service.getPartyResponseByIdIn(reqContext, partySearchReq, withManage);
	}

	@Operation(summary = "Find party by Code", description = "Get party info based on its code")
	@ApiResponses({
			@ApiResponse(responseCode = "200", description = "Successfully, party is found", content = @Content(mediaType = "application/json", schema = @Schema(implementation = PartyResponseV1.class))) })
	@GET
	@Path("/code/{code}")
	//@RolesAllowed()
	public PartyResponseV1 getByCode(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "the tenant ID") @PathParam("tenant") String tenantId,
			@Parameter(description = "the party code") @PathParam("code") String code,
			@Parameter(description = "must have manage flag, -1 no acl check, 0 can read, 1 must have manage, default = 1") @QueryParam("has_manage") @DefaultValue("1") Integer hasManage) {
		ReqContext reqContext = new ReqContext(user, lang);

		return this.partyV1Service.getPartyResponseByCode(reqContext, code)
				.map(p -> {
					aclService.isAuthorized(reqContext, p, hasManage);
					return p;
				})
				.orElse(null);
	}

	private boolean isValid(PartySearchRequestV1 searchReq) {
		boolean isEmpty = searchReq.getTag().isEmpty()
				&& StringUtils.isBlank(searchReq.getFirstName())
				&& StringUtils.isBlank(searchReq.getLastName())
				&& StringUtils.isBlank(searchReq.getTaxCode())
				&& StringUtils.isBlank(searchReq.getVatNumber())
				&& StringUtils.isBlank(searchReq.getTaxOrVat())
				&& StringUtils.isBlank(searchReq.getCode())
				&& StringUtils.isBlank(searchReq.getFullName())
				&& StringUtils.isBlank(searchReq.getFullNameOrCode())
				&& (null == searchReq.getHasCode() || !searchReq.getHasCode());
		return !isEmpty;
	}
}
