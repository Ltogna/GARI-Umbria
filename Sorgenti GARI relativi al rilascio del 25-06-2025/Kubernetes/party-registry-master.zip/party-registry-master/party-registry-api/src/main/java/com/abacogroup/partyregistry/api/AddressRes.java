package com.abacogroup.partyregistry.api;

import com.abacogroup.partyregistry.db.ntt.Address;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.experimental.SuperBuilder;

@Data
@EqualsAndHashCode(callSuper = true)
@ToString(callSuper = true)
@SuperBuilder(setterPrefix = "set")
@NoArgsConstructor
public class AddressRes extends Address {

	private String districtShortDescr;

	private String municipalityI18nCode;
}
