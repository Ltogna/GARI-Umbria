package com.abacogroup.partyregistry.core;

import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.partyregistry.api.v1.RelationTypeResponseV1;
import com.abacogroup.partyregistry.api.v1.req.RelationTypeSearchRequestV1;
import com.abacogroup.partyregistry.resources.req.ReqContext;
import java.util.Optional;

public interface RelationTypeV1Service {

	InfiniteListResults<RelationTypeResponseV1> search(ReqContext reqContext, RelationTypeSearchRequestV1 searchRequest, String nextKey);

	Optional<RelationTypeResponseV1> getByCode(ReqContext reqContext, String code);
}
