package com.abacogroup.partyregistry.api;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
public class RoleCountDTO {
    private String code;
    private String description;
    private Integer count;
}
