package com.abacogroup.partyregistry.resources.publicapis.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import com.abacogroup.partyregistry.api.v1.req.CitizenshipSearchRequestV1;
import com.abacogroup.partyregistry.resources.req.CitizenshipSearchReq;

@Mapper
public interface CitizenshipSearchReqMapper {
	
	CitizenshipSearchReqMapper INSTANCE = Mappers.getMapper(CitizenshipSearchReqMapper.class);
	
	CitizenshipSearchReq fromV1(CitizenshipSearchRequestV1 req);

}
