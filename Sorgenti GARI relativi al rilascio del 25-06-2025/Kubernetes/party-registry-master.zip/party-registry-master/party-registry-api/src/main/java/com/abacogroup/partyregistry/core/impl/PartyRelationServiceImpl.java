package com.abacogroup.partyregistry.core.impl;

import com.abacogroup.jdbi.criteria.Criteria;
import com.abacogroup.jdbi.orderby.OrderBy;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.partyregistry.api.PartyRelation;
import com.abacogroup.partyregistry.core.PartyEventProducer;
import com.abacogroup.partyregistry.core.PartyRelationService;
import com.abacogroup.partyregistry.core.PartyService;
import com.abacogroup.partyregistry.core.RelationTypeService;
import com.abacogroup.partyregistry.core.dto.PartyEventType;
import com.abacogroup.partyregistry.core.exceptions.ErrCodes;
import com.abacogroup.partyregistry.core.exceptions.InvalidPartyException;
import com.abacogroup.partyregistry.core.exceptions.InvalidRelationTypeException;
import com.abacogroup.partyregistry.db.dao.PartyRelationPartyDAO;
import com.abacogroup.partyregistry.db.dao.PartyRelationTypeDAO;
import com.abacogroup.partyregistry.db.ntt.PartyEntity;
import com.abacogroup.partyregistry.db.ntt.PartyRelationDetailEntity;
import com.abacogroup.partyregistry.db.ntt.PartyRelationEntity;
import com.abacogroup.partyregistry.db.ntt.PartyRelationPartyEntity;
import com.abacogroup.partyregistry.db.ntt.RelationTypeEntity;
import com.abacogroup.partyregistry.resources.mappers.PartyRelationPartyMapper;
import com.abacogroup.partyregistry.resources.req.PartyRelationTypeSearchReq;
import com.abacogroup.partyregistry.resources.req.ReqContext;
import com.abacogroup.partyregistry.resources.req.rel.CreatePartyRelationReq;
import com.abacogroup.partyregistry.resources.req.rel.PartyRelationDetailRequest;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.function.Consumer;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class PartyRelationServiceImpl implements PartyRelationService {

	private final PartyRelationTypeDAO partyRelationTypeDAO;

	private final PartyRelationPartyDAO partyRelationPartyDAO;

	private final PartyService partyService;
	private final RelationTypeService relationTypeService;

	private final PartyEventProducer partyEventProducer;

	private final PartyRelationPartyMapper partyRelationPartyMapper;

	public PartyRelationServiceImpl(PartyRelationTypeDAO partyRelationTypeDAO,
			PartyRelationPartyDAO partyRelationPartyDAO,
			PartyService partyService,
			RelationTypeService relationTypeService, PartyEventProducer partyEventProducer, PartyRelationPartyMapper partyRelationPartyMapper
	) {
		this.partyRelationTypeDAO = partyRelationTypeDAO;
		this.partyRelationPartyDAO = partyRelationPartyDAO;
		this.partyService = partyService;
		this.relationTypeService = relationTypeService;
		this.partyEventProducer = partyEventProducer;

		this.partyRelationPartyMapper = partyRelationPartyMapper;
	}

	@Override
	public Optional<PartyRelation> getRelationById(ReqContext reqContext, Long partyId, Long id) {
		return partyRelationTypeDAO.searchOne(reqContext.getTenantId(), partyId, id, reqContext);
	}

	@Override
	public Optional<PartyRelationEntity> findById(String tenantId, Long partyId, Long id) {
		return partyRelationTypeDAO.findEntity(tenantId, partyId, id);
	}

	@Override
	public InfiniteListResults<PartyRelation> search(ReqContext context, Long partyId,
			PartyRelationTypeSearchReq searchReq,
			String nextKey) {
		Criteria criteria = searchReq.getCriteria(context);
		OrderBy sort = searchReq.getDefaultSort();

		this.loadCurrentParty(context.getTenantId(), partyId);
		return partyRelationTypeDAO.infinite(() -> partyRelationTypeDAO.search(partyId, criteria, sort, context), nextKey, searchReq.getPageSize());
	}

	protected List<PartyRelationEntity> findByRelationType(ReqContext context, Long partyId, Long relationTypeId) {
		return partyRelationTypeDAO.findByRelationType(context.getTenantId(), partyId, relationTypeId);
	}

	@Override
	public PartyRelation save(ReqContext reqContext, Long partyId, CreatePartyRelationReq req, boolean sendEvent) {

		partyService.loadEntity(reqContext.getTenantId(), partyId)
				.orElseThrow(() -> new InvalidPartyException(ErrCodes.PARTY_NOT_FOUND, "party not found"));

		RelationTypeEntity relationType = relationTypeService.findActiveEntityByCode(reqContext.getTenantId(),
						req.getRelationTypeCode())
				.orElseThrow(() -> new InvalidRelationTypeException(ErrCodes.RELATION_TYPE_NOT_FOUND, "invalid relation type"));

		boolean forbidMultipleInstances = Optional.ofNullable(relationType.getFlMultiple()).orElse(0).equals(0);
		if (forbidMultipleInstances) {
			int instancesByRelationType = findByRelationType(reqContext, partyId, relationType.getId()).size();
			if (instancesByRelationType > 0) {
				throw new InvalidRelationTypeException(ErrCodes.RELATION_TYPE_MULTIPLE_INSTANCES_NOT_ALLOWED,
						"more than one relation of type : " + relationType.getCode());
			}
		}
		PartyRelationEntity partyRelationEntity = new PartyRelationEntity();
		partyRelationEntity.setPartyId(partyId);
		partyRelationEntity.setRelationTypeId(relationType.getId());

		Optional<PartyRelationPartyEntity> partyRelationPartyEntity =
				Optional.ofNullable(req.getRelationItemReq())
						.map(x -> partyRelationPartyMapper
								.createPartyRelationPartyEntity(reqContext.getTenantId(), relationType.getId(), req.getRelationItemReq()));

		Optional<PartyRelationDetailEntity> partyRelationDetailEntity =
				Optional.ofNullable(req.getNote())
						.map(x -> PartyRelationDetailEntity.builder()
								.setNote(x)
								.build());

		Long id = partyRelationTypeDAO.inTransaction(handle -> {
			Long recordId = this.insertRecord(reqContext.getUsername(), partyRelationEntity, partyRelationPartyEntity,
					partyRelationDetailEntity);

			if (sendEvent) {
				partyEventProducer.pushPartyEvent(reqContext, partyId, PartyEventType.UPDATE_PARTY);
			}

			return recordId;
		});

		return getRelationById(reqContext, partyId, id).orElseThrow();
	}

	private Long insertRecord(String currentUser, PartyRelationEntity relationTypeEntity,
			Optional<PartyRelationPartyEntity> partyRelationPartyEntity,
			Optional<PartyRelationDetailEntity> partyRelationDetailEntity) {

		partyRelationTypeDAO.useTransaction(handle -> {

			AuditHelper.setAuditForInsert(currentUser, handle,
					relationTypeEntity,
					partyRelationPartyEntity.orElse(null),
					partyRelationDetailEntity.orElse(null)
			);

			long pk = handle.issuePk();
			handle.insertMasterRow(pk, relationTypeEntity);
			relationTypeEntity.setId(pk);

			PartyRelationPartyDAO partyRelationPartyDAO = handle.getHandle().attach(PartyRelationPartyDAO.class);
			//opzionalmente scrive su prt_party_relation_parties
			partyRelationPartyEntity.ifPresent(partyRelParty -> {
				partyRelParty.setPartyRelationId(pk);
				partyRelationPartyDAO.insertPartyRelParty(partyRelParty, pk);
				partyRelParty.setPkid(pk);
			});

			//opzionalmente scrive su prt_party_relation_details
			partyRelationDetailEntity.ifPresent(detailEntity -> {
				detailEntity.setPartyRelationId(pk);
				partyRelationTypeDAO.insertPartyRelDetail(detailEntity);
			});
		});

		return relationTypeEntity.getId();
	}

	@Override
	public void expire(ReqContext context, Long partyId, Long relationId) {
		partyRelationTypeDAO.useTransaction(handle -> {
			handle.findEntity(context.getTenantId(), partyId, relationId)
					.ifPresent(e -> {
						LocalDateTime now = handle.getCurrentTimestamp();
						Consumer<PartyRelationEntity> expireFun = handle::expireRow;
						AuditHelper.expire(e, context.getUsername(), expireFun, now);

						expireRelationParties(context.getUsername(), partyId, relationId, handle, now);

						partyEventProducer.pushPartyEvent(context, partyId, PartyEventType.UPDATE_PARTY);
					});

		});
	}

	@Override
	public void expireAll(ReqContext context, Long partyId, String relationTypeCode, boolean sendEvent) {
		relationTypeService.findActiveEntityByCode(context.getTenantId(), relationTypeCode)
				.ifPresent(relationTypeEntity -> partyRelationTypeDAO.useTransaction(handle -> {
					int expiredCount = 0;
					for (PartyRelationEntity e : handle.findByRelationType(context.getTenantId(), partyId, relationTypeEntity.getId())) {
						LocalDateTime now = handle.getCurrentTimestamp();
						Consumer<PartyRelationEntity> expireFun = handle::expireRow;
						AuditHelper.expire(e, context.getUsername(), expireFun, now);

						expireRelationParties(context.getUsername(), partyId, e.getId(), handle, now);
						expiredCount++;
					}

					if (sendEvent && expiredCount > 0) {
						partyEventProducer.pushPartyEvent(context, partyId, PartyEventType.UPDATE_PARTY);
					}

				}));
	}

	private void expireRelationParties(String currentUser, Long partyId, Long relationId, PartyRelationTypeDAO handle,
			LocalDateTime now) {
		PartyRelationPartyEntity dummy = PartyRelationPartyEntity.builder()
				.setPartyId(partyId)
				.setPartyRelationId(relationId)
				.build();
		PartyRelationPartyDAO partyRelationPartyDAO = handle.getHandle().attach(PartyRelationPartyDAO.class);
		Consumer<PartyRelationPartyEntity> expireFun2 = partyRelationPartyDAO::expirePartyRelationPartyByRelationId;
		AuditHelper.expire(dummy, currentUser, expireFun2, now);
	}

	private PartyEntity loadCurrentParty(String tenantId, Long partyId) {
		return partyService.loadEntity(tenantId, partyId)
				//.filter(party1 -> party1.getFlArchived() == 0)
				.orElseThrow(() -> new InvalidPartyException(ErrCodes.PARTY_NOT_FOUND, "Party not found"));
	}

	private Optional<PartyRelationDetailEntity> loadPartyRelationDetail(Long partyId, Long partyRelId) {
		return partyRelationTypeDAO.loadEntityDetails(partyId, partyRelId);
	}

	@Override
	public PartyRelation saveDetail(ReqContext reqContext, Long partyId, Long partyRelId,
			PartyRelationDetailRequest detailRequest) {
		this.loadCurrentParty(reqContext.getTenantId(), partyId);

		Optional<PartyRelationDetailEntity> optDetail = this.loadPartyRelationDetail(partyId, partyRelId);
		partyRelationPartyDAO.useTransaction(handle -> {
			optDetail.ifPresent(oldDetail -> {
				Consumer<PartyRelationDetailEntity> expireFun = partyRelationTypeDAO::expirePartyRelDetail;
				AuditHelper.expire(oldDetail, reqContext.getUsername(), expireFun, partyRelationTypeDAO.getCurrentTimestamp());
			});

			PartyRelationDetailEntity partyRelationDetailEntity =
					PartyRelationDetailEntity.builder().setNote(detailRequest.getNote()).setPartyRelationId(partyRelId).build();
			AuditHelper.setAuditForInsert(reqContext.getUsername(), partyRelationTypeDAO, partyRelationDetailEntity);
			partyRelationTypeDAO.insertPartyRelDetail(partyRelationDetailEntity);

			partyEventProducer.pushPartyEvent(reqContext, partyId, PartyEventType.UPDATE_PARTY);
		});
		return getRelationById(reqContext, partyId, partyRelId).orElseThrow();
	}
}
