package com.abacogroup.partyregistry.core;

import com.abacogroup.partyregistry.api.ExternalSourceRes;
import com.abacogroup.partyregistry.api.PartyRes;
import com.abacogroup.partyregistry.resources.req.PartyExternalReq;
import com.abacogroup.partyregistry.resources.req.ReqContext;

import java.util.List;

public interface ExternalSourceService {
    List<ExternalSourceRes> getAll(ReqContext reqContext);

    ExternalSourceRes getByCode(ReqContext reqContext, String code);

    PartyRes upsertParty(ReqContext reqContext, PartyExternalReq req);

    boolean checkPartyExistenceOnExternalSourceByCode(ReqContext reqContext, PartyExternalReq req);
}
