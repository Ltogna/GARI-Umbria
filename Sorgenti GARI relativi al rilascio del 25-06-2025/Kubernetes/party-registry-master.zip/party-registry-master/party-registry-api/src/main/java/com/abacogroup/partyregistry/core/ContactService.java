package com.abacogroup.partyregistry.core;

import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.partyregistry.api.ContactSearchResponse;
import com.abacogroup.partyregistry.api.ContactTypeEnum;
import com.abacogroup.partyregistry.api.PartyContact;
import com.abacogroup.partyregistry.resources.req.ContactSearchReq;
import com.abacogroup.partyregistry.resources.req.PartyContactReq;
import com.abacogroup.partyregistry.resources.req.ReqContext;

public interface ContactService {

	PartyContact insert(ReqContext reqContext, Long partyId, PartyContactReq contact, boolean sendEvent);

	PartyContact update(ReqContext reqContext, Long partyId, Long pkid, PartyContactReq contact);

	InfiniteListResults<ContactSearchResponse> search(ReqContext reqContext, ContactSearchReq searchRequest, String nextKey);

	void expireContact(ReqContext reqContext, Long partyId, Long pkId);

	void expireContactsByType(ReqContext reqContext, ContactTypeEnum contactType, Long partyId);
}
