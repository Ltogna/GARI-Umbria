package com.abacogroup.partyregistry.db.dao;

import com.abacogroup.jdbi.EnhancedSqlObject;
import com.abacogroup.jdbi.criteria.BindCriteria;
import com.abacogroup.jdbi.criteria.Criteria;
import com.abacogroup.jdbi.orderby.DefineOrder;
import com.abacogroup.jdbi.orderby.OrderBy;
import com.abacogroup.partyregistry.api.PartyRelation;
import com.abacogroup.partyregistry.db.ntt.PartyRelationDetailEntity;
import com.abacogroup.partyregistry.db.ntt.PartyRelationEntity;
import com.abacogroup.partyregistry.resources.req.ReqContext;
import java.util.List;
import java.util.Optional;
import org.jdbi.v3.core.result.ResultIterator;
import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.customizer.BindBean;
import org.jdbi.v3.sqlobject.statement.GetGeneratedKeys;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;
import org.jdbi.v3.sqlobject.transaction.Transactional;

public interface PartyRelationTypeDAO extends Transactional<PartyRelationTypeDAO>, EnhancedSqlObject {

	String I18NRelType = ", coalesce (§i18n(:tenantId, 'prt_relation_types', 'code', prt.code, :lang)§, prt.code) as relation_type_i18n_code\n ";

	String ABSTRACT_RESPONSE_SELECT =
			//"select ppr.id, ppr.party_id, ppr.relation_type_id, prt.code as relation_type_code, prt.fl_multiple as relation_type_multiple  "
			"select ppr.id, ppr.party_id, prt.code as relation_type_code "
					+ I18NRelType
					+ ", pprd.note \n"
					+ "from prt_party_relations ppr \n"
					+ "inner join prt_relation_types prt on prt.id = ppr.relation_type_id AND §current_timestamp§ between prt.dt_insert and prt.dt_delete \n"
					+ "left join prt_party_relation_details pprd on ppr.id = pprd.party_relation_id and (§current_timestamp§ between pprd.dt_insert and pprd.dt_delete)\n"
					+ "inner join prt_parties pp on pp.id = ppr.party_id and pp.tenant_id = prt.tenant_id \n"
					+ "inner join prt_parties_detail ppd on pp.id = ppd.party_id AND §current_timestamp§ between ppd.dt_insert and ppd.dt_delete \n"
					+ "WHERE prt.tenant_id= :tenantId and ppr.party_id = :partyId "
					+ "and (§current_timestamp§ between ppr.dt_insert and ppr.dt_delete)\n";

	String ONE_RESPONSE_SELECT =
			ABSTRACT_RESPONSE_SELECT + " and ppr.id = :id\n";
	String BASE_SELECT =
			"select ppr.id, ppr.party_id, ppr.relation_type_id, ppr.dt_insert, ppr.user_id_insert, ppr.dt_delete, ppr.user_id_delete, prt.code as relation_type_code, pprd.note as detail_note\n"
					+ "from prt_party_relations ppr\n"
					+ "inner join prt_relation_types prt on prt.id = ppr.relation_type_id AND §current_timestamp§ between prt.dt_insert and prt.dt_delete \n"
					+ "left join prt_party_relation_details pprd on ppr.id = pprd.party_relation_id and (§current_timestamp§ between pprd.dt_insert and pprd.dt_delete)\n"
					+ "inner join prt_parties pp on pp.id = ppr.party_id and pp.tenant_id = prt.tenant_id \n"
					+ "inner join prt_parties_detail ppd on pp.id = ppd.party_id AND §current_timestamp§ between ppd.dt_insert and ppd.dt_delete \n"
					+ "WHERE prt.tenant_id= :tenantId and ppr.party_id = :partyId and ppr.id = :id\n"
					+ "and (§current_timestamp§ between ppr.dt_insert and ppr.dt_delete)\n";

	String BASE_SELECT_BY_RELATION_TYPE =
			"select ppr.id, ppr.party_id, ppr.relation_type_id, ppr.dt_insert, ppr.user_id_insert, ppr.dt_delete, ppr.user_id_delete \n"
					+ "from prt_party_relations ppr\n"
					+ "inner join prt_relation_types prt on prt.id = :relationTypeId AND §current_timestamp§ between prt.dt_insert and prt.dt_delete \n"
					+ "WHERE prt.tenant_id= :tenantId and ppr.party_id = :partyId and ppr.relation_type_id= :relationTypeId\n"
					+ "and (§current_timestamp§ between ppr.dt_insert and ppr.dt_delete)\n";

	String CURRENT_RECORD_RELATIONS = " AND (§current_timestamp§ between pr.dt_insert and pr.dt_delete) ";
	String CURRENT_RECORD_DETAILS = " AND (§current_timestamp§ between prd.dt_insert and prd.dt_delete) ";
	// TODO: join with prt_party_relations to guarantee that the detail has a related relation.
	String SELECT_DETAILS =
			"select prd.pkid, prd.party_relation_id, prd.note, prd.dt_insert, prd.user_id_insert, prd.dt_delete, prd.user_id_delete "
					+ " from prt_party_relation_details prd "
					+ " join prt_party_relations pr on prd.party_relation_id = pr.id " + CURRENT_RECORD_RELATIONS
					+ " where party_relation_id = :partyRelationId "
					+ " AND pr.party_id = :partyId ";

	@SqlQuery("select * from (" + ABSTRACT_RESPONSE_SELECT + ") inner_result where <criteria> order by <orderBy>")
	@RegisterBeanMapper(PartyRelation.class)
	ResultIterator<PartyRelation> search(
			@Bind("partyId") Long partyId,
			@BindCriteria Criteria criteria,
			@DefineOrder OrderBy orderBy,
			@BindBean ReqContext reqContext
	);

	@SqlQuery(ONE_RESPONSE_SELECT)
	@RegisterBeanMapper(PartyRelation.class)
	Optional<PartyRelation> searchOne(
			@Bind("tenantId") String tenantId,
			@Bind("partyId") Long partyId,
			@Bind("id") Long id,
			@BindBean ReqContext reqContext
	);

	@SqlQuery(BASE_SELECT)
	@RegisterBeanMapper(PartyRelationEntity.class)
	Optional<PartyRelationEntity> findEntity(
			@Bind("tenantId") String tenantId,
			@Bind("partyId") Long partyId,
			@Bind("id") Long id);

	@SqlQuery(BASE_SELECT_BY_RELATION_TYPE)
	@RegisterBeanMapper(PartyRelationEntity.class)
	List<PartyRelationEntity> findByRelationType(
			@Bind("tenantId") String tenantId,
			@Bind("partyId") Long partyId,
			@Bind("relationTypeId") Long relationTypeId);

	@SqlQuery("§select_nextval(prt_party_rel_parties_pkid_seq)§")
	Long issuePk();

	@SqlUpdate(
			"INSERT INTO prt_party_relations (id, party_id, relation_type_id, dt_insert, user_id_insert, dt_delete, user_id_delete ) "
					+ "VALUES (:sequenceId, :partyId, :relationTypeId, :dtInsert, :userIdInsert, :dtDelete, :userIdDelete)")
	void insertMasterRow(@Bind("sequenceId") Long id, @BindBean PartyRelationEntity relationTypeEntity);

	@SqlUpdate("update prt_party_relations set dt_delete =:dtDelete, user_id_delete=:userIdDelete where id = :id")
	void expireRow(@BindBean PartyRelationEntity entity);

	@SqlQuery(SELECT_DETAILS + CURRENT_RECORD_DETAILS)
	@RegisterBeanMapper(PartyRelationDetailEntity.class)
	Optional<PartyRelationDetailEntity> loadEntityDetails(
			@Bind("partyId") Long partyId,
			@Bind("partyRelationId") Long partyRelationId);

	@SqlUpdate(
			"INSERT INTO prt_party_relation_details (party_relation_id, note, dt_insert, user_id_insert, dt_delete, user_id_delete) "
					+ "VALUES (:partyRelationId, :note, :dtInsert, :userIdInsert, :dtDelete, :userIdDelete )")
	@GetGeneratedKeys("pkid")
	long insertPartyRelDetail(@BindBean PartyRelationDetailEntity partyRelationDetailEntity);

	@SqlUpdate("update prt_party_relation_details set dt_delete =:dtDelete, user_id_delete=:userIdDelete where party_relation_id = :partyRelationId")
	void expirePartyRelDetail(@BindBean PartyRelationDetailEntity partyRelationDetailEntity);

}

