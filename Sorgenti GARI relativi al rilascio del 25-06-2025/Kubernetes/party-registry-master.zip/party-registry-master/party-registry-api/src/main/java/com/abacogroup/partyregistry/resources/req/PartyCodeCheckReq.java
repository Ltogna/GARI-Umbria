package com.abacogroup.partyregistry.resources.req;

import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import jakarta.validation.constraints.NotBlank;
import jakarta.ws.rs.QueryParam;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

@Data
@NoArgsConstructor
@Accessors(chain = true)
public class PartyCodeCheckReq {

	@Parameter(in = ParameterIn.QUERY, description = "party ID")
	@QueryParam("id")
	private Long id;

	@Parameter(in = ParameterIn.QUERY, description = "code")
	@QueryParam("code")
	@NotBlank
	private String code;

}
