package com.abacogroup.partyregistry.resources.mappers;

import com.abacogroup.partyregistry.api.ExternalSourceRes;
import com.abacogroup.partyregistry.api.PartyRes;
import com.abacogroup.partyregistry.api.PartySearchRes;
import com.abacogroup.partyregistry.api.PartyTag;
import com.abacogroup.partyregistry.api.Tag;
import com.abacogroup.partyregistry.db.ntt.Address;
import com.abacogroup.partyregistry.db.ntt.PartyEntity;
import com.abacogroup.partyregistry.dto.v1.PartyExternalDtoV1;
import com.abacogroup.partyregistry.resources.req.AddressReq;
import com.abacogroup.partyregistry.resources.req.PartyCreateReq;
import com.abacogroup.partyregistry.resources.req.PartyUpdateReq;
import java.util.List;
import java.util.stream.Collectors;
import org.apache.commons.lang3.StringUtils;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.factory.Mappers;

@Mapper
public abstract class PartyMapper {

	public static PartyMapper INSTANCE = Mappers.getMapper(PartyMapper.class);

	/**
	 * ok solo perchè non ci sono lang coinvolte
	 */
	@Mapping(target = "archived", expression = "java(entity.getFlArchived() > 0)")
	@Mapping(target = "externalSource", expression = "java(sourceCodeToExternalSourceRes(entity.getSourceCode()))")
	public abstract PartyRes entityToDto(PartyEntity entity);

	protected ExternalSourceRes sourceCodeToExternalSourceRes(String sourceCode) {
		if (null == sourceCode) {
			return null;
		} else {
			return ExternalSourceRes.builder().setCode(StringUtils.upperCase(sourceCode)).build();
		}

	}

	public abstract PartyCreateReq externalToCreateReq(PartyExternalDtoV1 partyExternal);

	@Mapping(target = "partyType", source = "partyExternal.partyType")
	@Mapping(target = "gender", source = "partyExternal.gender")
	@Mapping(target = "lastName", source = "partyExternal.lastName")
	@Mapping(target = "firstName", source = "partyExternal.firstName")
	@Mapping(target = "taxCode", source = "partyExternal.taxCode")
	@Mapping(target = "vatNumber", source = "partyExternal.vatNumber")
	@Mapping(target = "code", source = "partyExternal.code")
	@Mapping(target = "legalStatus", source = "partyExternal.legalStatus")
	@Mapping(target = "birthDate", source = "partyExternal.birthDate")
	@Mapping(target = "deathDate", source = "partyExternal.deathDate")
	@Mapping(target = "birthMunicipality", source = "partyExternal.birthMunicipality")
	@Mapping(target = "nationality", source = "partyExternal.nationality")
	@Mapping(target = "addressResidential", source = "partyExternal.addressResidential")
	@Mapping(target = "addressHome", source = "partyRes.addressHome")
	@Mapping(target = "addressBilling", source = "partyExternal.addressBilling")
	@Mapping(target = "tags", source = "partyRes.tags")
	@Mapping(target = "archived", source = "partyRes.archived")
	public abstract PartyUpdateReq externalToUpdateReq(PartyExternalDtoV1 partyExternal, PartyRes partyRes);

	protected List<String> tagsToCodes(List<Tag> tags) {
		if (null == tags) {
			return null;
		} else {
			return tags.stream().map(Tag::getCode).collect(Collectors.toList());
		}
	}

	@Mapping(target = "archived", expression = "java(entity.getFlArchived() > 0)")
	public abstract PartyUpdateReq entityToUpdateReq(PartyEntity entity, List<PartyTag> tags);

	protected List<String> partyTagsToCodes(List<PartyTag> tags) {
		if (null == tags) {
			return null;
		} else {
			return tags.stream().map(PartyTag::getTagCode).collect(Collectors.toList());
		}
	}

	@Mapping(target = "flArchived", expression = "java(dto.isArchived() ? 1 : 0)")
	@Mapping(target = "tenantId", ignore = true)
	@Mapping(target = "firstName", expression = "java(java.util.Optional.ofNullable(dto.getFirstName()).map(x -> x.toUpperCase()).orElse(null))")
	@Mapping(target = "lastName", expression = "java(java.util.Optional.ofNullable(dto.getLastName()).map(x -> x.toUpperCase()).orElse(null))")
	@Mapping(target = "vatNumber", expression = "java(java.util.Optional.ofNullable(dto.getVatNumber()).map(x -> x.toUpperCase()).orElse(null))")
	@Mapping(target = "taxCode", expression = "java(java.util.Optional.ofNullable(dto.getTaxCode()).map(x -> x.toUpperCase()).orElse(null))")
	@Mapping(target = "code", expression = "java(java.util.Optional.ofNullable(dto.getCode()).map(x -> x.toUpperCase()).orElse(null))")
	public abstract PartyEntity dtoToEntity(PartyRes dto);

	@Mapping(target = "flArchived", expression = "java(dto.isArchived() ? 1 : 0)")
	@Mapping(target = "tenantId", ignore = true)
	@Mapping(target = "firstName", expression = "java(java.util.Optional.ofNullable(dto.getFirstName()).map(x -> x.toUpperCase()).orElse(null))")
	@Mapping(target = "lastName", expression = "java(java.util.Optional.ofNullable(dto.getLastName()).map(x -> x.toUpperCase()).orElse(null))")
	@Mapping(target = "vatNumber", expression = "java(java.util.Optional.ofNullable(dto.getVatNumber()).map(x -> x.toUpperCase()).orElse(null))")
	@Mapping(target = "taxCode", expression = "java(java.util.Optional.ofNullable(dto.getTaxCode()).map(x -> x.toUpperCase()).orElse(null))")
	@Mapping(target = "code", expression = "java(java.util.Optional.ofNullable(dto.getCode()).map(x -> x.toUpperCase()).orElse(null))")
	public abstract PartyEntity requestToEntity(PartyCreateReq dto);

	public PartySearchRes clean(PartySearchRes response) {

		if (response.getAddressResidential() != null) {
			if (response.getAddressResidential().getId() == null) {
				response.setAddressResidential(null);
			}
		}
		return response;
	}

	@Mapping(target = "flArchived", expression = "java(dto.isArchived() ? 1 : 0)")
	@Mapping(target = "firstName", expression = "java(java.util.Optional.ofNullable(dto.getFirstName()).map(x -> x.toUpperCase()).orElse(null))")
	@Mapping(target = "lastName", expression = "java(java.util.Optional.ofNullable(dto.getLastName()).map(x -> x.toUpperCase()).orElse(null))")
	@Mapping(target = "vatNumber", expression = "java(java.util.Optional.ofNullable(dto.getVatNumber()).map(x -> x.toUpperCase()).orElse(null))")
	@Mapping(target = "taxCode", expression = "java(java.util.Optional.ofNullable(dto.getTaxCode()).map(x -> x.toUpperCase()).orElse(null))")
	public abstract void updateEntity(PartyRes dto, @MappingTarget PartyEntity targetEntity);

	@Mapping(target = "flArchived", expression = "java(dto.isArchived() ? 1 : 0)")
	@Mapping(target = "firstName", expression = "java(java.util.Optional.ofNullable(dto.getFirstName()).map(x -> x.toUpperCase()).orElse(null))")
	@Mapping(target = "lastName", expression = "java(java.util.Optional.ofNullable(dto.getLastName()).map(x -> x.toUpperCase()).orElse(null))")
	@Mapping(target = "vatNumber", expression = "java(java.util.Optional.ofNullable(dto.getVatNumber()).map(x -> x.toUpperCase()).orElse(null))")
	@Mapping(target = "taxCode", expression = "java(java.util.Optional.ofNullable(dto.getTaxCode()).map(x -> x.toUpperCase()).orElse(null))")
	@Mapping(target = "addressResidential", expression = "java(updateAddress(dto.getAddressResidential(), targetEntity.getAddressResidential()))")
	@Mapping(target = "addressHome", expression = "java(updateAddress(dto.getAddressHome(), targetEntity.getAddressHome()))")
	@Mapping(target = "addressBilling", expression = "java(updateAddress(dto.getAddressBilling(), targetEntity.getAddressBilling()))")
	public abstract void updateEntity(PartyUpdateReq dto, @MappingTarget PartyEntity targetEntity);

	public abstract Address addressReqToAddress(AddressReq req);

	protected Address updateAddress(AddressReq addressReq, Address addressActual) {
		if (addressReq != null) {
			Address addressNew = addressReqToAddress(addressReq);

			if (addressActual != null) {
				addressNew.setId(addressActual.getId());
				if (!addressActual.equals(addressNew)) {
					addressNew.setId(null);
				}
			}
			return addressNew;
		}
		return null;
	}
}
