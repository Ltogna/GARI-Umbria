package com.abacogroup.partyregistry.bundle.tenant;

import static com.abacogroup.bundles.Constants.ALL_TENANTS;

import com.abacogroup.bundles.listener.tenant.TenantMessage;
import com.abacogroup.bundles.listener.tenant.TenantMessageProcessor;
import com.abacogroup.partyregistry.db.dao.I18nDAO;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class I18nTenantMessageProcessor implements TenantMessageProcessor {

	private final I18nDAO i18nDAO;

	public I18nTenantMessageProcessor(I18nDAO i18nDAO) {
		this.i18nDAO = i18nDAO;
	}

	@Override
	public void onMessage(TenantMessage message) {
		String tenantId = message.getTenantId();
		if (i18nDAO.countAll(tenantId) > 0L) {
			log.warn("i18n already present for tenant {}", tenantId);
		} else {
			i18nDAO.insertNewTenant(ALL_TENANTS, tenantId);
		}
	}
}
