package com.abacogroup.partyregistry.api;

import org.jdbi.v3.core.mapper.Nested;

import com.abacogroup.jdbi.datatype.AbsoluteDate;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder(setterPrefix = "set")
@NoArgsConstructor
public class PartyRelationParty {

	private Long pkid;

	private Long partyRelationId;  //PK
	private Long relatedPartyId; //PK / the relation target
	private String firstName;
	private String lastName;
	
	private String taxCode;
	private AbsoluteDate birthDate;
	
	private Long relationRoleId; //PK

	private AbsoluteDate dtStart;
	private AbsoluteDate dtEnd;

	private Long relationTypeId; // dto  //1 AZIENDA

	/**
	 * the relation owner
	 */
	private Long partyRelationPartyId; // the relation owner

	private String relatedRoleCode; //dto // azienda_SOCIO
	private String relationRoleI18nCode;

	private String relationTypeCode; //    //AZIENDA
	private String relationTypeI18nCode;

	private Boolean hasMandates;
	@Nested("party_relation")
	private PartyRelation partyRelation;

/*	@Nested("relation_role")
	private RelationRole relationRole;*/
	
}
