package com.abacogroup.partyregistry.db.dao;

import com.abacogroup.jdbi.EnhancedSqlObject;
import com.abacogroup.jdbi.criteria.BindCriteria;
import com.abacogroup.jdbi.criteria.Criteria;
import com.abacogroup.jdbi.model.AuditEntity;
import com.abacogroup.jdbi.orderby.DefineOrder;
import com.abacogroup.jdbi.orderby.OrderBy;
import com.abacogroup.partyregistry.api.RelationRole;
import com.abacogroup.partyregistry.db.ntt.RelationRoleEntity;
import com.abacogroup.partyregistry.resources.req.ReqContext;
import java.util.List;
import java.util.Optional;
import org.jdbi.v3.core.result.ResultIterator;
import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.customizer.BindBean;
import org.jdbi.v3.sqlobject.statement.GetGeneratedKeys;
import org.jdbi.v3.sqlobject.statement.SqlBatch;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;
import org.jdbi.v3.sqlobject.transaction.Transactional;

public interface RelationRoleDAO extends Transactional<RelationRoleDAO>, EnhancedSqlObject, Auditable {

	String FIELDS = " r.id, r.type_id, r.code, t.code as relation_type_code, t.fl_multiple as relation_type_multiple  ";

	String CURRENT_RECORD = " AND (§current_timestamp§ between r.dt_insert and r.dt_delete) ";

	String I18NRelType = ", coalesce (§i18n(:tenantId, 'prt_relation_types', 'code', t.code, :lang)§, t.code) as relation_type_i18n_code  ";
	String I18NRelRole = ", coalesce (§i18n(:tenantId, 'prt_relation_roles', 'code', r.code, :lang)§, r.code) as i18n_code  ";

	@SqlQuery("select * from ("
			+ "select " + FIELDS + I18NRelRole + I18NRelType
			+ " FROM prt_relation_roles r  "
			+ " inner join prt_relation_types t on r.type_id = t.id AND (§current_timestamp§ between t.dt_insert and t.dt_delete)  "
			+ " where t.tenant_id = :tenantId" + CURRENT_RECORD + ") inner_result  "
			+ " where <criteria> "
			+ " order by <orderBy>")
	@RegisterBeanMapper(RelationRole.class)
	ResultIterator<RelationRole> searchAll(
			@BindCriteria Criteria criteria,
			@DefineOrder OrderBy orderBy,
			@BindBean ReqContext ctx
	);

	@SqlQuery(
			"select " + FIELDS + I18NRelRole + I18NRelType
					+ " FROM prt_relation_roles r "
					+ " inner join prt_relation_types t on r.type_id = t.id AND (§current_timestamp§ between t.dt_insert and t.dt_delete)  "
					+ " where r.code = :code "
					+ CURRENT_RECORD
					+ " and t.tenant_id = :tenantId ")
	@RegisterBeanMapper(RelationRole.class)
	Optional<RelationRole> searchByCode(
			@Bind("code") String code,
			@BindBean ReqContext ctx);

	@SqlQuery(
			"select " + FIELDS + I18NRelRole + I18NRelType
					+ " FROM prt_relation_roles r "
					+ " inner join prt_relation_types t on r.type_id = t.id AND (§current_timestamp§ between t.dt_insert and t.dt_delete)  "
					+ " where r.code = :code and t.code = :type "
					+ CURRENT_RECORD
					+ " and t.tenant_id = :tenantId ")
	@RegisterBeanMapper(RelationRole.class)
	Optional<RelationRole> searchByCodeAndType(
			@Bind("code") String code,
			@Bind("type") String type,
			@BindBean ReqContext ctx);

	//------------------

	@SqlQuery("select " + FIELDS
			+ " FROM prt_relation_roles r  "
			+ " inner join prt_relation_types t on r.type_id = t.id  "
			+ " where r.code = :code "
			+ " AND (§current_timestamp§ between r.dt_insert and r.dt_delete) "
			+ " AND (§current_timestamp§ between t.dt_insert and t.dt_delete) "
			+ " and t.id = :typeId "
			+ " and t.tenant_id = :tenantId ")
	@RegisterBeanMapper(RelationRoleEntity.class)
	Optional<RelationRoleEntity> findEntityByTypeIdAndCode(
			@Bind("tenantId") String tenantId,
			@Bind("typeId") Long typeId,
			@Bind("code") String code);

	@SqlQuery("select " + FIELDS
			+ " FROM prt_relation_roles r  "
			+ " inner join prt_relation_types t on r.type_id = t.id  "
			+ " where r.code = :code "
			+ " AND (§current_timestamp§ between r.dt_insert and r.dt_delete) "
			+ " AND (§current_timestamp§ between t.dt_insert and t.dt_delete) "
			+ " and t.tenant_id = :tenantId ")
	@RegisterBeanMapper(RelationRoleEntity.class)
	Optional<RelationRoleEntity> findEntityByCode(
			@Bind("tenantId") String tenantId,
			@Bind("code") String code);

	@SqlQuery("select " + FIELDS
			+ " FROM prt_relation_roles r  "
			+ " inner join prt_relation_types t on r.type_id = t.id  "
			+ " where r.code = :code "
			+ " AND (§current_timestamp§ between t.dt_insert and t.dt_delete)"
			+ " and t.tenant_id = :tenantId ")
	@RegisterBeanMapper(RelationRoleEntity.class)
	Optional<RelationRoleEntity> findEntityByCodeIncludeDeleted(
			@Bind("tenantId") String tenantId,
			@Bind("code") String code);

	@SqlUpdate("INSERT INTO prt_relation_roles (type_id, code, dt_insert, user_id_insert, dt_delete, user_id_delete) "
			+ " VALUES (:typeId, :code, §current_timestamp§, :userIdInsert, TO_DATE('9999-12-31','YYYY-MM-DD'), :userIdDelete)")
	@GetGeneratedKeys("id")
	Long insert(@BindBean RelationRoleEntity entity);

	@SqlBatch("insert into prt_relation_roles (type_id, code, dt_insert, user_id_insert, dt_delete, user_id_delete)"
			+ " select  t.id, :code, :dtInsert,  :userIdInsert,  :dtDelete,  :userIdDelete "
			+ " from prt_relation_types t "
			+ " where t.tenant_id = :tenantId and t.code = :type "
			+ " and not exists("
			+ " select code from prt_relation_roles where type_id = t.id and code = :code  and (§current_timestamp§ between dt_insert and dt_delete)"
			+ ")")
	void insertRolesIdempotent(
			@Bind("tenantId") String tenantId,
			@Bind("type") String type,
			@BindBean RelationRoleEntity... role);

	@SqlUpdate("update prt_relation_roles set dt_delete =:dtDelete, user_id_delete=:userIdDelete where id = :id")
	void expireRow(@BindBean RelationRoleEntity entity);

	@SqlUpdate("UPDATE prt_relation_roles SET type_id = :typeId, code = :code  WHERE id=:id")
	void update(@BindBean RelationRoleEntity entity);

	@SqlQuery("select count(*) FROM prt_relation_roles where type_id IN "
			+ " ( select id from prt_relation_types where tenant_id = :tenantId )")
	Long countAll(@Bind("tenantId") String tenantId);

	@SqlUpdate("insert into prt_relation_roles ( type_id, code, dt_insert, user_id_insert, dt_delete, user_id_delete) "
			+ "select t_new.id, r.code, :dtInsert, :userIdInsert, :dtDelete, :userIdDelete "
			+ "from prt_relation_roles r "
			+ "inner join prt_relation_types  t_source on r.type_id = t_source.id "
			+ "inner join prt_relation_types t_new on t_source.code = t_new.code "
			+ "where t_new.tenant_id = :newTenantId and t_source.tenant_id = :sourceTenant")
	void insertNewTenant(
			@Bind("sourceTenant") String sourceTenant,
			@Bind("newTenantId") String newTenantId,
			@BindBean AuditEntity audit);

	@SqlQuery("select " + FIELDS
			+ " FROM prt_relation_roles r  "
			+ " inner join prt_relation_types t on r.type_id = t.id  "
			+ " where t.code = :code "
			+ " AND (§current_timestamp§ between r.dt_insert and r.dt_delete) "
			+ " AND (§current_timestamp§ between t.dt_insert and t.dt_delete) "
			+ " and t.tenant_id = :tenantId ")
	@RegisterBeanMapper(RelationRoleEntity.class)
	List<RelationRoleEntity> findByTypeCode(
			@Bind("tenantId") String tenantId,
			@Bind("code") String code);
}


