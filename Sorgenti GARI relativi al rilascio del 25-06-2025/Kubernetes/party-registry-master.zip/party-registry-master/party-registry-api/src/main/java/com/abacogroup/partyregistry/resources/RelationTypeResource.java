package com.abacogroup.partyregistry.resources;

import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.partyregistry.api.RelationType;
import com.abacogroup.partyregistry.core.RelationTypeService;
import com.abacogroup.partyregistry.resources.req.RelationTypeSearchReq;
import com.abacogroup.partyregistry.resources.req.ReqContext;
import io.dropwizard.auth.Auth;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.annotation.security.RolesAllowed;
import jakarta.ws.rs.BeanParam;
import jakarta.ws.rs.DefaultValue;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.HeaderParam;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.MediaType;

@Path(ResourceConstants.API_PRIV + "/relation-types")
@Produces(MediaType.APPLICATION_JSON)
@Tag(name = "relation types", description = "Operations on relation types")
public class RelationTypeResource {

	private final RelationTypeService relationTypeService;

	public RelationTypeResource(RelationTypeService relationTypeService) {
		this.relationTypeService = relationTypeService;
	}

	@Operation(summary = "List of relation types", description = "Get list of relation types filtered with criteria")
	@ApiResponses({
			@ApiResponse(responseCode = "200", description = "Successfully, returns a list of relation types (sorted/filtered)",
					content = @Content(mediaType = "application/json", schema = @Schema(ref = "#/components/schemas/InfiniteListResultsRelationType")))
	})
	@GET
	@RolesAllowed("PARTY-REGISTRY|READ")
	public InfiniteListResults<RelationType> search(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "tenant ID") @PathParam("tenant") String tenantId,

			@Parameter(description = "Can be supplied to obtain the records that follows those obtained by a previous call") @QueryParam("nextKey") String nextKey,
			@BeanParam RelationTypeSearchReq searchRequest) {

		ReqContext reqContext = new ReqContext(user, lang);
		return relationTypeService.search(reqContext, searchRequest, nextKey);
	}

	@Operation(summary = "Find relation type by ID", description = "Returns relation type based on its ID")
	@ApiResponses({
			@ApiResponse(responseCode = "200", description = "Successfully, relation type is found",
					content = @Content(mediaType = "application/json", schema = @Schema(implementation = RelationType.class))),
	})
	@GET
	@RolesAllowed("PARTY-REGISTRY|READ")
	@Path("/{code}")
	public RelationType getById(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "tenant ID") @PathParam("tenant") String tenantId,

			@Parameter(description = "the relation type CODE") @PathParam("code") String code
	) {
		ReqContext reqContext = new ReqContext(user, lang);
		return this.relationTypeService.getByCode(reqContext, code)
				.orElse(null);
	}

}
