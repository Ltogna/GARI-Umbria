package com.abacogroup.partyregistry.core.impl;

import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.partyregistry.api.v1.RelationTypeResponseV1;
import com.abacogroup.partyregistry.api.v1.req.RelationTypeSearchRequestV1;
import com.abacogroup.partyregistry.core.RelationTypeService;
import com.abacogroup.partyregistry.core.RelationTypeV1Service;
import com.abacogroup.partyregistry.resources.publicapis.mapper.RelationTypeResMapper;
import com.abacogroup.partyregistry.resources.publicapis.mapper.RelationTypeSearchReqMapper;
import com.abacogroup.partyregistry.resources.req.RelationTypeSearchReq;
import com.abacogroup.partyregistry.resources.req.ReqContext;
import java.util.Optional;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class RelationTypeV1ServiceImpl implements RelationTypeV1Service {

	private final RelationTypeService relationTypeService;

	public RelationTypeV1ServiceImpl(RelationTypeService relationTypeService) {
		this.relationTypeService = relationTypeService;
	}

	@Override
	public InfiniteListResults<RelationTypeResponseV1> search(ReqContext reqContext, RelationTypeSearchRequestV1 searchRequest, String nextKey) {
		RelationTypeSearchReq req = RelationTypeSearchReqMapper.INSTANCE.fromV1(searchRequest);
		return relationTypeService.search(reqContext, req, nextKey).map(RelationTypeResMapper.INSTANCE::toV1);
	}

	@Override
	public Optional<RelationTypeResponseV1> getByCode(ReqContext reqContext, String code) {
		return relationTypeService.getByCode(reqContext, code)
				.map(RelationTypeResMapper.INSTANCE::toV1);
	}
}
