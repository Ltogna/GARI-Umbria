package com.abacogroup.partyregistry.core;

import com.abacogroup.partyregistry.api.v1.AppConfigResponseV1;
import com.abacogroup.partyregistry.resources.req.ReqContext;
import java.util.List;
import java.util.Optional;

public interface AppConfigV1Service extends PublicService {

	List<AppConfigResponseV1> searchAll(ReqContext reqContext);

	Optional<AppConfigResponseV1> searchByKey(ReqContext reqContext, String key);

}
