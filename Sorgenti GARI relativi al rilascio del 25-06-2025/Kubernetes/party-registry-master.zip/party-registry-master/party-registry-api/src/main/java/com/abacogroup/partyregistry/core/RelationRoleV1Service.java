package com.abacogroup.partyregistry.core;

import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.partyregistry.api.v1.RelationRoleResponseV1;
import com.abacogroup.partyregistry.api.v1.req.RelationRoleSearchRequestV1;
import com.abacogroup.partyregistry.resources.req.ReqContext;
import java.util.Optional;

public interface RelationRoleV1Service {

	InfiniteListResults<RelationRoleResponseV1> search(ReqContext reqContext, RelationRoleSearchRequestV1 searchRequest, String relationTypeCode,
			String nextKey);

	Optional<RelationRoleResponseV1> getByCodeAndType(ReqContext reqContext, String typeCode, String code);
}
