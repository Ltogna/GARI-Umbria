package com.abacogroup.partyregistry.api;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;
import org.jdbi.v3.core.mapper.reflect.ColumnName;

@Data
@SuperBuilder(setterPrefix = "set")
@NoArgsConstructor
public class ExternalSourceRes {

	private String code;

	@ColumnName("fl_allow_manual")
	private Boolean allowManual;

	private String description;

}
