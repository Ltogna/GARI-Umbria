package com.abacogroup.partyregistry.resources.req;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder(setterPrefix = "set")
@NoArgsConstructor
public class CitizenshipReq {

	private static final String CODE_REGEXP_1_3 = "^[A-Z\\d_]{1,3}$"; // TODO: check regex for citizenship ITA, FRA, DEU, GBR

	@NotNull
	@Pattern(regexp = CODE_REGEXP_1_3)
	private String code;

}
