package com.abacogroup.partyregistry.resources.mappers;

import com.abacogroup.partyregistry.db.ntt.RelationRoleEntity;
import com.abacogroup.partyregistry.resources.req.RelationRoleReq;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper
public interface RelationRoleMapper {

	RelationRoleMapper INSTANCE = Mappers.getMapper(RelationRoleMapper.class);

	RelationRoleEntity reqToEntity(RelationRoleReq dto, Long typeId);

}
