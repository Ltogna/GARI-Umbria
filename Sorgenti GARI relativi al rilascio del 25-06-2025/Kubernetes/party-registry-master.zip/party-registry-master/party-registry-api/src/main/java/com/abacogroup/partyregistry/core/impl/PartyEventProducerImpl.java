package com.abacogroup.partyregistry.core.impl;

import com.abacogroup.embeddedqueue.db.JdbiRepository;
import com.abacogroup.embeddedqueue.rabbitmq.RabbitMqPublisherWorkQueue;
import com.abacogroup.partyregistry.core.PartyEventProducer;
import com.abacogroup.partyregistry.core.dto.PartyEventType;
import com.abacogroup.partyregistry.core.dto.PartyQueueMessage;
import com.abacogroup.partyregistry.resources.req.ReqContext;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.dropwizard.core.setup.Environment;
import java.time.Clock;
import java.time.LocalDateTime;
import lombok.extern.slf4j.Slf4j;
import org.jdbi.v3.core.Jdbi;

@Slf4j
public class PartyEventProducerImpl implements PartyEventProducer {

	private final Clock appClock;
	private final RabbitMqPublisherWorkQueue<PartyQueueMessage> q;

	public PartyEventProducerImpl(Environment environment, Jdbi jdbi, ObjectMapper mapper,
			PartyEventRabbitPublisher eventPublisher, Clock appClock) {

		this.appClock = appClock;

		this.q = RabbitMqPublisherWorkQueue.builder("party-events", new JdbiRepository(jdbi), PartyQueueMessage.class)
				.withConsumer(eventPublisher)
				.withMetricsRegistry(environment.metrics())
				.build();

		this.q.setObjectMapper(mapper);

	}

	public void start() {
		q.start();
	}

	public void stop() throws Exception {
		q.stop();
	}

	@Override
	public void pushPartyEvent(ReqContext reqContext, Long partyId, PartyEventType eventType) {
		this.pushPartyEvent(reqContext.getTenantId(), reqContext.getUsername(), reqContext.getLang(), partyId, eventType);
	}

	@Override
	public void pushPartyEvent(String tenant, String username, String lang, Long partyId, PartyEventType eventType) {
		q.add(new PartyQueueMessage(tenant, username, lang, partyId, LocalDateTime.now(appClock), eventType), appClock.millis());
	}

}
