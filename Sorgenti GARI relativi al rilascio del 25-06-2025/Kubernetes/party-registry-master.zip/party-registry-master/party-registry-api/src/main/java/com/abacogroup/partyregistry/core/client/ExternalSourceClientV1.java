package com.abacogroup.partyregistry.core.client;

import static jakarta.ws.rs.core.HttpHeaders.ACCEPT_LANGUAGE;
import static jakarta.ws.rs.core.HttpHeaders.AUTHORIZATION;

import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.partyregistry.core.cli.impl.TokenRelayStrategy;
import com.abacogroup.partyregistry.core.exceptions.ExternalSourceException;
import com.abacogroup.partyregistry.core.exceptions.ExternalSourceException.ErrEnum;
import com.abacogroup.partyregistry.db.dao.ExternalSourceDAO;
import com.abacogroup.partyregistry.db.ntt.ExternalSourceEntity;
import com.abacogroup.partyregistry.dto.v1.ExternalSourceDtoV1;
import io.github.resilience4j.retry.RetryConfig;
import io.github.resilience4j.retry.RetryRegistry;
import jakarta.ws.rs.NotFoundException;
import jakarta.ws.rs.ProcessingException;
import jakarta.ws.rs.ServerErrorException;
import jakarta.ws.rs.WebApplicationException;
import jakarta.ws.rs.client.Client;
import jakarta.ws.rs.client.WebTarget;
import jakarta.ws.rs.core.GenericType;
import jakarta.ws.rs.core.MediaType;
import java.time.Duration;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class ExternalSourceClientV1 {

	private final Client client;
	private final ExternalSourceDAO externalSourceDAO;

	private final RetryRegistry retryRegistry;
	private final TokenRelayStrategy authorizationStrategy;

	public ExternalSourceClientV1(Client client, ExternalSourceDAO externalSourceDAO) {
		this.client = client;
		this.externalSourceDAO = externalSourceDAO;

		this.retryRegistry = RetryRegistry.of(RetryConfig.custom()
				.maxAttempts(2)
				.waitDuration(Duration.ofMillis(500))
				.failAfterMaxAttempts(true)
				.retryExceptions(ProcessingException.class, ServerErrorException.class)
				.build());
		authorizationStrategy = new TokenRelayStrategy();
	}


	public ExternalSourceDtoV1 getExternalPartyByCode(String lang, User user, String sourceCode, String partyCode) {

		String url = externalSourceDAO.findByCode(user.getTenant(), sourceCode)
				.map(ExternalSourceEntity::getUrl)
				.orElseThrow(() -> new ExternalSourceException(ErrEnum.SOURCE_CODE_NOT_FOUND,
						String.format("no configuration for external code '%s'", sourceCode)));

		WebTarget webTarget = client.target(url)
				.resolveTemplate("code", partyCode);

		try {
			log.debug("call external service '{}' to get party with code '{}'. url: '{}'", sourceCode, partyCode, webTarget.getUri().toString());
			ExternalSourceDtoV1 result = retryRegistry.retry(webTarget.getUri().toString())
					.executeSupplier(() -> webTarget
							.request(MediaType.APPLICATION_JSON_TYPE)
							.header(ACCEPT_LANGUAGE, lang)
							.header(AUTHORIZATION, authorizationStrategy.getAuthorization(user))
							.get(new GenericType<>() {
							}));

			return result;
		} catch (NotFoundException nfe) {
			throw new ExternalSourceException(ErrEnum.PARTY_NOT_FOUND,
					String.format("no party with code '%s' found on source with code '%s'", partyCode, sourceCode),
					nfe);
		} catch (WebApplicationException wae) {
			throw wae;
		} catch (ProcessingException pe) {
			log.error("cannot read response from source with code '{}'. url: '{}'", sourceCode, webTarget.getUri().toString(), pe);
			throw new ExternalSourceException(ErrEnum.PAYLOAD_NOT_READEABLE,
					String.format("cannot read response from source with code '%s'", sourceCode),
					pe);
		}
	}


}
