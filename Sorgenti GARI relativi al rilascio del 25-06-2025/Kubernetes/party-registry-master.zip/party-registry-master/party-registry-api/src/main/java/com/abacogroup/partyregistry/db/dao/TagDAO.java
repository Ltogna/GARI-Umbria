package com.abacogroup.partyregistry.db.dao;

import com.abacogroup.jdbi.EnhancedSqlObject;
import com.abacogroup.jdbi.criteria.BindCriteria;
import com.abacogroup.jdbi.criteria.Criteria;
import com.abacogroup.jdbi.orderby.DefineOrder;
import com.abacogroup.jdbi.orderby.OrderBy;
import com.abacogroup.partyregistry.api.Tag;
import com.abacogroup.partyregistry.db.ntt.TagEntity;
import com.abacogroup.partyregistry.resources.req.ReqContext;
import java.util.Collection;
import java.util.List;
import java.util.Optional;
import org.jdbi.v3.core.result.ResultIterator;
import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.customizer.BindBean;
import org.jdbi.v3.sqlobject.customizer.BindList;
import org.jdbi.v3.sqlobject.statement.GetGeneratedKeys;
import org.jdbi.v3.sqlobject.statement.SqlBatch;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;
import org.jdbi.v3.sqlobject.transaction.Transactional;

public interface TagDAO extends Transactional<TagDAO>, EnhancedSqlObject {

	String FIELDS = " id, tag_code, tenant_id ";
	String I18N = " \n, coalesce (§i18n(:tenantId, 'prt_tags', 'code', tag_code, :lang)§, tag_code) as i18n_code\n ";

	@SqlQuery("select" + FIELDS + "from prt_tags where <criteria> ORDER BY <orderBy>")
	@RegisterBeanMapper(TagEntity.class)
	List<TagEntity> findAll(@BindCriteria Criteria criteria,
			@DefineOrder OrderBy orderBy);

	@SqlQuery("select " + FIELDS + "from prt_tags where tenant_id = :tenantId and tag_code = :code")
	@RegisterBeanMapper(TagEntity.class)
	Optional<TagEntity> findByCode(
			@Bind("tenantId") String tenantId,
			@Bind("code") String code
	);

	@SqlQuery("select " + FIELDS + "from prt_tags where tenant_id = :tenantId and tag_code in (<codes>)")
	@RegisterBeanMapper(TagEntity.class)
	List<TagEntity> findByCodeIn(
			@Bind("tenantId") String tenantId,
			@BindList("codes") Collection<String> codes
	);

	//--- responses

	@SqlUpdate("insert into prt_tags (tag_code, tenant_id) values (:code, :tenantId)")
	@GetGeneratedKeys("id")
	Long insert(@BindBean TagEntity entity);

	@SqlBatch("insert into prt_tags (tag_code, tenant_id) "
			+ "§select_from_dual(:code, :tenantId)§ "
			+ "where not exists (select tag_code from prt_tags where tenant_id = :tenantId and tag_code = :code )")
	void insertIdempotent(@BindBean TagEntity... entity);

	@SqlQuery("select * from (select " + FIELDS + I18N
			+ " from prt_tags  where tenant_id = :tenantId) inner_result where <criteria> ORDER BY <orderBy>")
	@RegisterBeanMapper(Tag.class)
	ResultIterator<Tag> searchAll(
			@BindCriteria Criteria criteria,
			@DefineOrder OrderBy orderBy,
			@BindBean ReqContext ctx);

	@SqlQuery("select * from (select " + FIELDS + I18N
			+ " from prt_tags  where tenant_id = :tenantId) inner_result where <criteria> ORDER BY <orderBy>")
	@RegisterBeanMapper(Tag.class)
	List<Tag> searchList(
			@BindCriteria Criteria criteria,
			@DefineOrder OrderBy orderBy,
			@BindBean ReqContext ctx);

	@SqlQuery("select " + FIELDS + I18N + "from prt_tags where tag_code = :code and tenant_id = :tenantId")
	@RegisterBeanMapper(Tag.class)
	Optional<Tag> searchByCode(
			@Bind("code") String code,
			@BindBean ReqContext ctx);

	@SqlQuery("select " + FIELDS + I18N + "from prt_tags where id = :id and tenant_id = :tenantId")
	@RegisterBeanMapper(Tag.class)
	Optional<Tag> searchById(
			@Bind("id") Long id,
			@BindBean ReqContext ctx);

	@SqlQuery("select count(*) FROM prt_tags where tenant_id = :tenantId ")
	Long countAll(@Bind("tenantId") String tenantId);

	@SqlUpdate("INSERT INTO prt_tags (tag_code, tenant_id) " +
			" select tag_code, :newTenantId as tenant_id " +
			" FROM prt_tags  where tenant_id = :sourceTenant ")
	void insertNewTenant(@Bind("sourceTenant") String sourceTenant,
			@Bind("newTenantId") String newTenantId);
	
	@SqlUpdate("DELETE from prt_tags where tenant_id = :tenantId and tag_code = :tagCode")
	void deleteByTenantAndTag(@Bind("tenantId") String tenantId, @Bind("tagCode") String tagCode);
	
}
