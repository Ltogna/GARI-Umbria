package com.abacogroup.partyregistry.core.impl;

import com.abacogroup.dynamicdocuments.bean.Document;
import com.abacogroup.dynamicdocuments.bean.DocumentDefinition;
import com.abacogroup.dynamicdocuments.bean.SummaryFieldDefinition;
import com.abacogroup.dynamicdocuments.bean.SummaryFieldValue;
import com.abacogroup.dynamicdocuments.services.DocumentService;
import com.abacogroup.dynamicdocuments.services.DocumentTypeService;
import com.abacogroup.partyregistry.api.PartyDocument;
import com.abacogroup.partyregistry.core.exceptions.ErrCodes;
import com.abacogroup.partyregistry.core.exceptions.InvalidDocumentException;
import com.abacogroup.partyregistry.resources.req.ReqContext;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Optional;

public class PartyDocumentMapper {

	public static PartyDocument addSummaryFields(ReqContext reqContext, PartyDocument partyDocument,
			DocumentTypeService documentTypeService, DocumentService documentService, String dynamicDocumentsBucket) {
		Document document = documentService.getDocumentFromId(partyDocument.getDocumentId());
		Optional<DocumentDefinition> def = documentTypeService
				.getDocumentDefinition(reqContext.getTenantId(), partyDocument.getDefinitionCode());

		List<SummaryFieldDefinition> summaryFields = null;
		if (def.isPresent()) {
			summaryFields = documentTypeService.getSummaryFields(def.get(), reqContext.getLang());

			List<SummaryFieldValue> listValues = documentService.getSummaryValues(def.get(), document, reqContext.getLang());
			LinkedHashMap<String, Object> summaryFieldsData = new LinkedHashMap<>();
			listValues.forEach(
					summaryFieldValue -> summaryFieldsData.put(summaryFieldValue.getCode(), summaryFieldValue.getValue())
			);
			partyDocument.setSummaryFieldDefinitions(summaryFields);
			partyDocument.setData(summaryFieldsData);
			partyDocument.setBucketName(dynamicDocumentsBucket);
		}
		return partyDocument;
	}

	public static PartyDocument addData(ReqContext reqContext, PartyDocument partyDocument, DocumentTypeService documentTypeService,
			DocumentService documentService, String dynamicDocumentsBucket) {
		Document document = Optional.ofNullable(documentService.getDocumentFromId(partyDocument.getDocumentId()))
				.orElseThrow(() -> new InvalidDocumentException(ErrCodes.DYNAMIC_DOCUMENT_NOT_FOUND, "doc not found " + partyDocument.getDocumentId()));
		partyDocument.setData(new LinkedHashMap<>(document.getFields()));
		partyDocument.setBucketName(dynamicDocumentsBucket);

		return partyDocument;
	}

}
