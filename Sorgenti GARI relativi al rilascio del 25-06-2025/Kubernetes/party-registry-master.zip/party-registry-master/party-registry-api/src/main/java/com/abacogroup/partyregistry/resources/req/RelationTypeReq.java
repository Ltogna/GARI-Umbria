package com.abacogroup.partyregistry.resources.req;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder(setterPrefix = "set")
@NoArgsConstructor
public class RelationTypeReq {

	private static final String CODE_REGEXP_1_100 = "^[A-Z\\d_]{1,100}$";

	//private Long id;

	@NotNull
	@Pattern(regexp = CODE_REGEXP_1_100)
	private String code;

	private boolean multiple;

}
