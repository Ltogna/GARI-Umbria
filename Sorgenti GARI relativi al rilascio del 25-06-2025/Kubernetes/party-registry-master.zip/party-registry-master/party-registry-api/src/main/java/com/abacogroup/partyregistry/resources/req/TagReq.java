package com.abacogroup.partyregistry.resources.req;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder(setterPrefix = "set")
@NoArgsConstructor
public class TagReq {

	private static final String CODE_REGEXP_1_20 = "^[A-Z\\d_]{1,20}$";

	@NotNull
	@Pattern(regexp = CODE_REGEXP_1_20)
	private String code;

}
