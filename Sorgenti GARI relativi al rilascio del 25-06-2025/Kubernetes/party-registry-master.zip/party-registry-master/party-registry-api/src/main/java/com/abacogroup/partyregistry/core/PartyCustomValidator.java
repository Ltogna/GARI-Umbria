package com.abacogroup.partyregistry.core;

import com.abacogroup.partyregistry.db.ntt.PartyEntity;

public interface PartyCustomValidator {
	void validateOnInsert(PartyEntity party, String tenant);

	void validateOnUpdate(PartyEntity party, String tenant);
}
