package com.abacogroup.partyregistry.core;

import com.abacogroup.partyregistry.api.UserPermissions;
import com.abacogroup.partyregistry.resources.req.ReqContext;

public interface UserSupportService {

	UserPermissions getUserPermissions(ReqContext context);

}
