package com.abacogroup.partyregistry.core.dynamicdoc;

import com.abacogroup.dynamicdocuments.bean.Document;
import com.abacogroup.dynamicdocuments.bean.InsertDocument;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.partyregistry.api.PartyDocument;
import com.abacogroup.partyregistry.api.PartyDocumentDefinition;
import com.abacogroup.partyregistry.resources.req.DocumentSearchReq;
import com.abacogroup.partyregistry.resources.req.ReqContext;
import jakarta.ws.rs.core.Response;
import java.time.OffsetDateTime;
import java.util.List;

public interface PartyDynamicDocumentManager {

	OffsetDateTime INFINITY = OffsetDateTime.of(9999, 12, 31, 0, 0, 0, 0, OffsetDateTime.now().getOffset());

	String TYPE_BANK_DATA = "BANK";

	String TYPE_EINVOICING = "EINVOICING";

	String TYPE_EARNINGS = "EARNINGS";

	String TYPE_ID_DATA = "ID";

	InfiniteListResults<PartyDocument> searchByDocType(ReqContext reqContext, DocumentSearchReq searchRequest, String nextKey);

	Response getDocumentFileContent(ReqContext reqContext, Long partyId, Long documentId, String fileId);

	Response getDocumentFileMetadata(ReqContext reqContext, Long partyId, Long documentId, String fileId);

	default PartyDocument save(ReqContext reqContext, Long partyId, String definitionCode, InsertDocument document) {
		return save(reqContext, partyId, definitionCode, document, true);
	}

	PartyDocument save(ReqContext reqContext, Long partyId, String definitionCode, InsertDocument document, boolean sendEvent);

	void expire(ReqContext reqContext, Long partyId, Long documentId);

	//TODO CONTROLLARE

	//	PartyDocument getByDocumentId(ReqContext reqContext, Long documentId);

	PartyDocument getByDocumentIdAndCode(ReqContext reqContext, Long documentId, String definitionCode);

	PartyDocumentDefinition getDefinition(ReqContext reqContext, String definitionCode);

	List<Document> getByPartyIdAndCode(ReqContext reqContext, Long businessId, String code);
	//
	//	Document loadDocById(Long id);

	PartyDocument update(ReqContext reqContext, Long partyId, Long documentId, Document updateReq);

	void expireAll(ReqContext reqContext, Long partyId, String defCode, boolean sendEvent);
}
