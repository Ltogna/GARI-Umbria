package com.abacogroup.partyregistry.resources.mappers;

import com.abacogroup.partyregistry.api.AppConfig;
import com.abacogroup.partyregistry.api.AppConfigRes;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.Map;
import java.util.Objects;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;
import org.mapstruct.factory.Mappers;

@Mapper
public interface AppConfigMapper {

	AppConfigMapper INSTANCE = Mappers.getMapper(AppConfigMapper.class);

	@Mapping(source = "configuration", target = "configuration", qualifiedByName = "fromStrJsonToMap")
	AppConfigRes toConfigRes(AppConfig appConfig);

	@Named("fromStrJsonToMap")
	default Map<String, Object> fromStrJsonToMap(String config) {
		if (Objects.nonNull(config)) {
			ObjectMapper objectMapper = new ObjectMapper();
			Map<String, Object> result = null;
			try {
				result = objectMapper.readValue(config, new TypeReference<Map<String, Object>>() {
				});
			} catch (JsonProcessingException e) {
				throw new RuntimeException(String.format("cannot convert String json : %s to Map", config), e);
			}
			return result;
		}
		return null;
	}

}
