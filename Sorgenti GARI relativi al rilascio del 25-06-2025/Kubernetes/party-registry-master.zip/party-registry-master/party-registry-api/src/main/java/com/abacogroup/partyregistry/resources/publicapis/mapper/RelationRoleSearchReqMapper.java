package com.abacogroup.partyregistry.resources.publicapis.mapper;

import com.abacogroup.partyregistry.api.v1.req.RelationRoleSearchRequestV1;
import com.abacogroup.partyregistry.resources.req.RelationRoleSearchReq;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper
public interface RelationRoleSearchReqMapper {

	RelationRoleSearchReqMapper INSTANCE = Mappers.getMapper(RelationRoleSearchReqMapper.class);

	RelationRoleSearchReq fromV1(RelationRoleSearchRequestV1 req);

}
