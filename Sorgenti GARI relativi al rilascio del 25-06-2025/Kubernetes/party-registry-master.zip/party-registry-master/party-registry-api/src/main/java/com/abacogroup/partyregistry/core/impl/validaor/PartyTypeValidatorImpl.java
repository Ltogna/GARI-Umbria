package com.abacogroup.partyregistry.core.impl.validaor;

import com.abacogroup.partyregistry.api.PartyTypeEnum;
import com.abacogroup.partyregistry.core.PartyFieldValidator;
import com.abacogroup.partyregistry.core.exceptions.ErrCodes;
import com.abacogroup.partyregistry.core.exceptions.InvalidPartyException;
import com.abacogroup.partyregistry.db.dao.PartyDAO;
import com.abacogroup.partyregistry.db.ntt.AppConfigEntity;
import com.abacogroup.partyregistry.db.ntt.PartyEntity;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.Optional;

public class PartyTypeValidatorImpl implements PartyFieldValidator {

	public static final String CONFIG_KEY = "party_type";


	private final PartyDAO partyDAO;
	private final ObjectMapper objectMapper;

	public PartyTypeValidatorImpl(PartyDAO partyDAO, ObjectMapper objectMapper) {
		this.partyDAO = partyDAO;
		this.objectMapper = objectMapper;
	}

	@Override
	public String getFieldName() {
		return CONFIG_KEY;
	}

	@Override
	public void resetField(PartyEntity party) {

	}

	@Override
	public void validateOnInsert(PartyEntity entity, AppConfigEntity validationConfig) throws InvalidPartyException {
		return;
	}

	@Override
	public void validateOnUpdate(PartyEntity party, AppConfigEntity validationConfig) throws InvalidPartyException {
		PartyTypeConfiguration configuration = this.getConfiguration(validationConfig);
		if (!configuration.isEditable()) {
			Optional<PartyTypeEnum> currentVal  = partyDAO.loadOneByIdAndTenantId(party.getTenantId(), party.getId()).map(PartyEntity::getPartyType);
			if (currentVal.isPresent()) {
				if (!currentVal.get().equals(party.getPartyType())) {
					throw new InvalidPartyException(ErrCodes.INVALID_PAYLOAD,
							String.format("%s cannot be changed", CONFIG_KEY));
				}
			}
		}
	}

	private PartyTypeConfiguration getConfiguration(AppConfigEntity validationConfig) {
		try {
			return objectMapper.readValue(validationConfig.getConfiguration(), PartyTypeConfiguration.class);
		} catch (JsonProcessingException e) {
			throw new RuntimeException(e);
		}
	}

}
