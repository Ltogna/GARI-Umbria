package com.abacogroup.partyregistry.resources.req;

import com.abacogroup.jdbi.criteria.Criteria;
import com.abacogroup.jdbi.criteria.CriteriaBuilder;
import com.abacogroup.jdbi.orderby.OrderBy;
import com.abacogroup.jdbi.orderby.OrderByBuilder;
import com.abacogroup.jdbi.orderby.OrderByElement;
import com.abacogroup.jdbi.orderby.SortDirection;
import com.abacogroup.partyregistry.api.ContactTypeEnum;
import com.abacogroup.partyregistry.resources.ResourceConstants;
import com.fasterxml.jackson.annotation.JsonIgnore;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.QueryParam;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

@Data
@NoArgsConstructor
@Accessors(chain = true)
public class ContactSearchReq implements BaseSearchReq {

	@Parameter(in = ParameterIn.PATH, description = "the party ID")
	@PathParam("partyId")
	private Long partyId;

	@Parameter(in = ParameterIn.QUERY, description = "the contact type")
	@QueryParam("contactType")
	private ContactTypeEnum contactType;

	@Parameter(in = ParameterIn.QUERY, description = "the sub type of contact")
	@QueryParam("subType")
	private String subType;

	@Parameter(in = ParameterIn.QUERY, description = "the contact value")
	@QueryParam("contactValue")
	private String contactValue;

	@Override
	@JsonIgnore
	@Schema(hidden = true)
	public int getPageSize() {
		return ResourceConstants.PAGE_SIZE;
	}

	@JsonIgnore
	@Schema(hidden = true)
	@Override
	public Criteria getCriteria(ReqContext reqContext) {
		List<Criteria> specs = new ArrayList<>();

		//eq
		Optional.ofNullable(getPartyId())
				.ifPresent(v -> specs.add(CriteriaBuilder.number("co.party_id").eq(v)));

		//like
		Optional.ofNullable(getContactType())
				.ifPresent(v -> specs.add(CriteriaBuilder.string("co.contact_type").contains(v.toString().toUpperCase())));

		Optional.ofNullable(getSubType())
				.ifPresent(v -> specs.add(CriteriaBuilder.string("co.sub_type").contains(v.toUpperCase())));

		Optional.ofNullable(getContactValue())
				.ifPresent(v -> specs.add(CriteriaBuilder.string("co.contact_value").contains(v.toUpperCase())));

		return CriteriaBuilder.and(specs.toArray(new Criteria[0]));
	}

	@Override
	public OrderByElement getSort() {
		return OrderByBuilder.field("co.contact_type").direction(SortDirection.ASC);
	}

	@JsonIgnore
	@Schema(hidden = true)
	public OrderBy getDefaultSort() {
		return OrderByBuilder.from(
				this.getSort(),
				OrderByBuilder.field("co.sub_type").direction(SortDirection.ASC),
				OrderByBuilder.field("co.contact_value").direction(SortDirection.ASC),
				OrderByBuilder.field("co.pkid").direction(SortDirection.ASC)
		);
	}
}
