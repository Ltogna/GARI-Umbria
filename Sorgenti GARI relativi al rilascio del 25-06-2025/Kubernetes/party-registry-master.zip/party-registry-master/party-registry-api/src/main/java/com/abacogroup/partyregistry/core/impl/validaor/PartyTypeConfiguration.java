package com.abacogroup.partyregistry.core.impl.validaor;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;
import lombok.experimental.SuperBuilder;

@Data
@Accessors(chain = true)
@SuperBuilder(setterPrefix = "set")
@AllArgsConstructor
@NoArgsConstructor
public class PartyTypeConfiguration {

	@Builder.Default
	private boolean editable = true;
}
