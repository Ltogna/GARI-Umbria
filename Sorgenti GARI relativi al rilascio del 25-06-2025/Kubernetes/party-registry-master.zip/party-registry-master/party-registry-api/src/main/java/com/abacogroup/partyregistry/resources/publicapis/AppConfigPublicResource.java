package com.abacogroup.partyregistry.resources.publicapis;

import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.partyregistry.api.v1.AppConfigResponseV1;
import com.abacogroup.partyregistry.core.AppConfigV1Service;
import com.abacogroup.partyregistry.resources.PublicResourceConstants;
import com.abacogroup.partyregistry.resources.req.ReqContext;
import io.dropwizard.auth.Auth;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.ws.rs.DefaultValue;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.HeaderParam;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import java.util.List;

@Path(PublicResourceConstants.API_V1_PUB + "/configurations")
@Produces(MediaType.APPLICATION_JSON)
@Tag(name = "configurations", description = "Operations on the application configurations")
public class AppConfigPublicResource {

	private final AppConfigV1Service appConfigService;

	public AppConfigPublicResource(AppConfigV1Service appConfigService) {
		this.appConfigService = appConfigService;
	}

	@Operation(summary = "List of configurations", description = "Get list of all the app configurations")
	@ApiResponses({
			@ApiResponse(responseCode = "200", description = "Successfully, returns a list of configurations",
					content = @Content(mediaType = "application/json",
							array = @ArraySchema(schema = @Schema(implementation = AppConfigResponseV1.class))))
	})
	@GET
	public List<AppConfigResponseV1> search(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "tenant ID") @PathParam("tenant") String tenantId) {

		ReqContext reqContext = new ReqContext(user, lang);
		return appConfigService.searchAll(reqContext);
	}

	@Operation(summary = "Find configuration by key", description = "Get a specific configuration by key")
	@ApiResponses({
			@ApiResponse(responseCode = "200", description = "Successfully, configuration is found",
					content = @Content(mediaType = "application/json", schema = @Schema(implementation = AppConfigResponseV1.class))),
			@ApiResponse(responseCode = "204", description = "no configuration is found")
	})
	@GET
	@Path("/{key}")
	public AppConfigResponseV1 getByKey(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "tenant ID") @PathParam("tenant") String tenantId,
			@Parameter(description = "the configuration key") @PathParam("key") String key) {

		ReqContext reqContext = new ReqContext(user, lang);
		return appConfigService.searchByKey(reqContext, key).orElse(null);
	}

}
