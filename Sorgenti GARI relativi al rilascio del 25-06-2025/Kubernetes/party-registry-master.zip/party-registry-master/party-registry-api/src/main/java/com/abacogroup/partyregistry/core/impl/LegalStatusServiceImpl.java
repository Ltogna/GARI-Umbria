package com.abacogroup.partyregistry.core.impl;

import com.abacogroup.jdbi.criteria.Criteria;
import com.abacogroup.jdbi.orderby.OrderBy;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.partyregistry.api.LegalStatus;
import com.abacogroup.partyregistry.core.LegalStatusService;
import com.abacogroup.partyregistry.db.dao.LegalStatusDAO;
import com.abacogroup.partyregistry.db.ntt.LegalStatusEntity;
import com.abacogroup.partyregistry.resources.req.LegalStatusSearchReq;
import com.abacogroup.partyregistry.resources.req.ReqContext;
import lombok.extern.slf4j.Slf4j;
import java.util.Optional;

@Slf4j
public class LegalStatusServiceImpl implements LegalStatusService {

	private final LegalStatusDAO legalStatusDAO;

	public LegalStatusServiceImpl(LegalStatusDAO legalStatusDAO) {
		this.legalStatusDAO = legalStatusDAO;
	}

	@Override
	public InfiniteListResults<LegalStatus> search(ReqContext reqContext, LegalStatusSearchReq searchRequest,
												   String nextKey) {
		Criteria criteria = searchRequest.getCriteria(reqContext);
		OrderBy sort = searchRequest.getSort();
		return legalStatusDAO.infinite(
				() -> legalStatusDAO.searchAll(criteria, sort, reqContext),
				nextKey, searchRequest.getPageSize());
	}

	@Override
	public Optional<LegalStatus> getByCode(ReqContext context, String code) {
		return legalStatusDAO.searchByCode(code, context);
	}

	@Override
	public Optional<LegalStatusEntity> findEntityByCode(String tenantId, String code) {
		return legalStatusDAO.findOne(tenantId, code);
	}

//	private LegalStatus insert(ReqContext context, LegalStatusEntity entity) {
//		legalStatusDAO.insert(entity);
//		return getByCode(context, entity.getCode())
//				.orElse(null);
//	}

}
