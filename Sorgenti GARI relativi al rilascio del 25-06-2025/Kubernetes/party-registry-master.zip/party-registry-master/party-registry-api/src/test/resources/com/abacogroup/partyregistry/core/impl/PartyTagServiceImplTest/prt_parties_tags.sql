--liquibase formatted sql
--changeset realt:PartyTagServiceImplTest002

INSERT INTO prt_parties (id, tenant_id)
VALUES (-1, :test_tenant);
INSERT INTO prt_parties (id, tenant_id)
VALUES (-2, :test_tenant);
INSERT INTO prt_parties (id, tenant_id)
VALUES (-3, :test_tenant);


INSERT INTO prt_parties_detail (party_id, party_type, last_name, first_name, tax_code, vat_number,
                                birth_date, death_date, birth_municipality,
                                fl_archived, dt_insert, user_id_insert, dt_delete)
VALUES (-1, 'N', 'REALT', 'DEMO', '000', '111', '20010131', '99991231', 'Verona',
        0, TO_DATE('2022-01-01', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'));
INSERT INTO prt_parties_detail (party_id, party_type, last_name, first_name, tax_code, vat_number,
                                birth_date, death_date, birth_municipality,
                                fl_archived, dt_insert, user_id_insert, dt_delete)
VALUES (-2, 'N', 'DEMO_COMPANY', 'SPA', 'DMC', 'DMC', '20010131', '99991231', 'Milano',
        1, TO_DATE('2022-01-01', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'));
INSERT INTO prt_parties_detail (party_id, party_type, last_name, first_name, tax_code, vat_number,
                                birth_date, death_date, birth_municipality,
                                fl_archived, dt_insert, user_id_insert, dt_delete)
VALUES (-3, 'N', 'REALT_TECHNOLOGY', 'SPA', '222', '333', '20010131', '99991231', 'Cagliari',
        0, TO_DATE('2022-01-01', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'));

INSERT INTO prt_tags (id, tag_code, tenant_id)
VALUES (-1, 'BUG', :test_tenant);
INSERT INTO prt_tags (id, tag_code, tenant_id)
VALUES (-2, 'LOL', :test_tenant);


INSERT INTO prt_i18n_values (tenant_id, table_name, field_name, i18n_value, lang, i18n_text)
VALUES (:test_tenant, 'prt_tags', 'tag_code', 'BUG', 'en', '-');
INSERT INTO prt_i18n_values (tenant_id, table_name, field_name, i18n_value, lang, i18n_text)
VALUES (:test_tenant, 'prt_tags', 'tag_code', 'LOL', 'en', '-');

insert into prt_i18n_values (tenant_id, table_name, field_name, i18n_value, lang, i18n_text)
select tenant_id, table_name, field_name, i18n_value, 'it', i18n_text
from prt_i18n_values
where tenant_id = :test_tenant
  and lang = 'en';

update prt_i18n_values
set i18n_text = lower(i18n_value) || '_' || lang
where tenant_id = :test_tenant;



insert into prt_parties_tags(pkid, party_id, tag_id, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-10, -1, -1, TO_DATE('2022-01-01', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);
insert into prt_parties_tags(pkid, party_id, tag_id, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-11, -1, -2, TO_DATE('2022-01-01', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);
insert into prt_parties_tags(pkid, party_id, tag_id, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-12, -2, -1, TO_DATE('2022-01-01', 'YYYY-MM-DD'), :user_id, TO_DATE('2022-01-02', 'YYYY-MM-DD'),
        :user_id);
insert into prt_parties_tags(pkid, party_id, tag_id, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-13, -2, -2, TO_DATE('2022-01-01', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);


