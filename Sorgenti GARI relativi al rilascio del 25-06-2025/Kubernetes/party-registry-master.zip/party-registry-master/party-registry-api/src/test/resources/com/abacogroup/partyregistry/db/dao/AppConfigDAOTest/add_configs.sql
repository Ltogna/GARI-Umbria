insert into prt_app_configuration (id, tenant_id, configuration_key, configuration, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-1, 'all_tenants', 'test1', '{"show": true}', TO_DATE('2022-01-01', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), NULL);
insert into prt_app_configuration (id, tenant_id, configuration_key, configuration, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-2, 'all_tenants', 'test2', '{"show": false}', TO_DATE('2022-01-01', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), NULL);

insert into prt_app_configuration (id, tenant_id, configuration_key, configuration, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-1001, :test_tenant, 'test1', '{"show": true}', TO_DATE('2022-01-01', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), NULL);
insert into prt_app_configuration (id, tenant_id, configuration_key, configuration, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-1003, :test_tenant, 'test3', '{"show": false}', TO_DATE('2022-01-01', 'YYYY-MM-DD'), :user_id, TO_DATE('2022-12-31', 'YYYY-MM-DD'), :user_id);
