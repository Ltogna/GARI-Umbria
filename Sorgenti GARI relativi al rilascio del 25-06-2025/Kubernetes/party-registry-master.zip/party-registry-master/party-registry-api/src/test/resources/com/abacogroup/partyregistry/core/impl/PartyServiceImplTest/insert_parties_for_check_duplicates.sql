--liquibase formatted sql

INSERT INTO prt_parties (id, tenant_id)
VALUES (-12, :test_tenant);

INSERT INTO prt_parties (id, tenant_id)
VALUES (-13, :test_tenant);

INSERT INTO prt_parties (id, tenant_id)
VALUES (-14, :test_tenant);


INSERT INTO prt_addresses (id, municipality, locality, street, house_number, postcode, details,
                           note)
VALUES (-2, 'ITA_20_292_009', 'Pirri', 'via Ruggero Bacone', '4', '09134',
        'details test', 'note test');


--- taxCode = null / vatNumber = 111
INSERT INTO prt_parties_detail (party_id, party_type, last_name, first_name, vat_number,
                                birth_date, death_date, birth_municipality,
                                fk_address_residential, fl_archived, dt_insert, user_id_insert, dt_delete)
VALUES (-12, 'N', 'REALT', 'DEMO', '111', '20010131', '99991231', 'Verona',
        null, 0, TO_DATE('2022-01-01', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'));

--- taxCode = null / taxCode = 222
INSERT INTO prt_parties_detail (party_id, party_type, last_name, first_name, tax_code,
                                birth_date, death_date, birth_municipality,
                                fk_address_residential, fl_archived, dt_insert, user_id_insert, dt_delete)
VALUES (-13, 'N', 'DEMO_COMPANY', 'SPA', '222', '20010131', '99991231', 'Milano',
        null, 1, TO_DATE('2022-01-01', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'));

--- taxCode = 333 / vatNumber = 444
INSERT INTO prt_parties_detail (party_id, party_type, last_name, first_name, tax_code, vat_number,
                                birth_date, death_date, birth_municipality,
                                fk_address_residential, fl_archived, dt_insert, user_id_insert, dt_delete)
VALUES (-14, 'N', 'REALT_TECHNOLOGY', 'SPA', '222', '333', '20010131', '99991231', 'Cagliari',
        -2, 0, TO_DATE('2022-01-01', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'));

