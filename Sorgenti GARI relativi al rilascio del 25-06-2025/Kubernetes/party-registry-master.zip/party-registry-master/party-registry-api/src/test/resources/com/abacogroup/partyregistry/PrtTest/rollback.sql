--liquibase formatted sql
--changeset realt:PrtTest001

delete
from prt_doc_type
where tenant_id = :test_tenant;

delete
from prt_i18n_values
where tenant_id = :test_tenant;

delete
from prt_parties_documents
where tenant_id = :test_tenant;

delete
from doc_document_content
where doc_document_id in (select id from doc_document where tenant_id = :test_tenant);

delete
from doc_document
where tenant_id = :test_tenant;

delete
from doc_type_spec
where doc_type_id in (select id from doc_type where tenant_id = :test_tenant);

delete
from doc_type
where tenant_id = :test_tenant;

delete
from prt_parties_tags
where party_id in (select id from prt_parties where tenant_id = :test_tenant);

delete
from prt_parties_detail
where party_id in (select id from prt_parties where tenant_id = :test_tenant);

delete
from prt_parties
where tenant_id = :test_tenant;

delete
from prt_relation_roles
where type_id in (select id from prt_relation_types where tenant_id = :test_tenant);

delete
from prt_relation_types
where tenant_id = :test_tenant;

delete
from prt_tags
where tenant_id = :test_tenant;

delete
from prt_citizenship
where tenant_id = :test_tenant;

delete
from bnd_registry
where tenant_id = :test_tenant;

delete
from bnd_tenant
where tenant_id = :test_tenant;


delete
from prt_addresses
where id not in (select fk_address_residential
                 from prt_parties_detail
                 where party_id in (select id from prt_parties where tenant_id = :test_tenant)
                 union aLL
                 select fk_address_home
                 from prt_parties_detail
                 union aLL
                 select fk_address_billing
                 from prt_parties_detail)
