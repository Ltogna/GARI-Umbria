--liquibase formatted sql
--changeset realt:TagServiceImplTest002

insert into prt_tags (id, tag_code, tenant_id)
values (-111, 'BUG', :test_tenant);
insert into prt_tags (id, tag_code, tenant_id)
values (-112, 'LOL', :test_tenant);


insert into prt_i18n_values (tenant_id, table_name, field_name, i18n_value, lang, i18n_text)
values (:test_tenant, 'prt_tags', 'code', 'BUG', 'en', '-');
insert into prt_i18n_values (tenant_id, table_name, field_name, i18n_value, lang, i18n_text)
values (:test_tenant, 'prt_tags', 'code', 'LOL', 'en', '-');


-- insert into prt_i18n_values (tenant_id, table_name, field_name, i18n_value, lang, i18n_text)
-- values (:test_tenant2, 'prt_tags', 'tag_code', 'BUG', 'en', '-');

insert into prt_i18n_values (tenant_id, table_name, field_name, i18n_value, lang, i18n_text)
select tenant_id, table_name, field_name, i18n_value, 'it', i18n_text
from prt_i18n_values
where tenant_id in (:test_tenant)
  and lang = 'en';
--
update prt_i18n_values
set i18n_text = lower(i18n_value) || '_' || lang
where tenant_id in (:test_tenant);

