insert into prt_tags (id, tag_code, tenant_id)
values (-111, 'BUG', :test_tenant);
insert into prt_tags (id, tag_code, tenant_id)
values (-112, 'LOL', :test_tenant);
insert into prt_tags (id, tag_code, tenant_id)
values (-113, 'FOO', :test_tenant);
insert into prt_tags (id, tag_code, tenant_id)
values (-114, 'BAR', :test_tenant);


