--liquibase formatted sql
--changeset realt:PartyDAOTest001

INSERT INTO prt_parties
    (id, tenant_id)
VALUES (-777, :test_tenant);


INSERT INTO prt_parties_detail
(pkid, party_id, party_type, gender, last_name, first_name, tax_code, vat_number, death_date, fk_address_residential, fk_address_home,
 fk_address_billing, fl_archived, dt_insert, user_id_insert, dt_delete, user_id_delete)
VALUES (-777, -777, 'N', NULL, 'REALT', 'SUPER_DEMO', '000', '111', '99991231', NULL, NULL, NULL, 0,
        TO_DATE('2022-01-01', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), NULL);


