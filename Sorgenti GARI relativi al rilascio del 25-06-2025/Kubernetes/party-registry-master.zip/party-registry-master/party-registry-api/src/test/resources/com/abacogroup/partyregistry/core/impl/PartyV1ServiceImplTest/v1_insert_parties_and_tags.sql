--liquibase formatted sql
--changeset realt:PartyServiceImplTest001

INSERT INTO prt_tags (id, tag_code, tenant_id)
VALUES (-3, 'BUG', :test_tenant);
INSERT INTO prt_tags (id, tag_code, tenant_id)
VALUES (-4, 'LOL', :test_tenant);

INSERT INTO prt_tags (tag_code, tenant_id)
VALUES ('AA', :test_tenant);
INSERT INTO prt_tags (tag_code, tenant_id)
VALUES ('BB', :test_tenant);

----------------------------------------------------------------------------------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------------------------------------------------------------------------


--- 666 --------------------------------------------------------------------------------------------------------------------------------------------------------
INSERT INTO prt_parties (id, tenant_id)
VALUES (-666, :test_tenant);
INSERT INTO prt_parties_detail (party_id, party_type, last_name, first_name, tax_code, vat_number,
                                birth_date, death_date, birth_municipality,
                                fk_address_residential, fl_archived, dt_insert, user_id_insert, dt_delete)
VALUES (-666, 'N', 'REALT', 'DEMO', '000', '111', '20010131', '99991231', 'Verona',
        null, 0, TO_DATE('2022-01-01', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'));
insert into prt_parties_tags(pkid, party_id, tag_id, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-5, -666, -3, TO_DATE('2022-01-01', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);
insert into prt_parties_tags(pkid, party_id, tag_id, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-6, -666, -4, TO_DATE('2022-01-01', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);
--- --- --------------------------------------------------------------------------------------------------------------------------------------------------------

--- 555 --------------------------------------------------------------------------------------------------------------------------------------------------------
INSERT INTO prt_parties (id, tenant_id)
VALUES (-555, :test_tenant);
INSERT INTO prt_parties_detail (party_id, party_type, last_name, first_name, tax_code, vat_number,
                                birth_date, death_date, birth_municipality,
                                fk_address_residential, fl_archived, dt_insert, user_id_insert, dt_delete)
VALUES (-555, 'N', 'DEMO_COMPANY', 'SPA', 'DMC', 'DMC', '20010131', '99991231', 'Milano',
        null, 1, TO_DATE('2022-01-01', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'));
insert into prt_parties_tags(pkid, party_id, tag_id, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-7, -555, -3, TO_DATE('2022-01-01', 'YYYY-MM-DD'), :user_id, TO_DATE('2022-01-02', 'YYYY-MM-DD'),
        :user_id);
insert into prt_parties_tags(pkid, party_id, tag_id, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-8, -555, -4, TO_DATE('2022-01-01', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);
--- --- --------------------------------------------------------------------------------------------------------------------------------------------------------

--- 444 --------------------------------------------------------------------------------------------------------------------------------------------------------
INSERT INTO prt_parties (id, tenant_id)
VALUES (-444, :test_tenant);

INSERT INTO prt_addresses (id, municipality, locality, street, house_number, postcode, details, note)
VALUES (-2, 'ITA_20_292_009', 'Pirri', 'via Ruggero Bacone', '4', '09134', 'details test', 'note test');

INSERT INTO prt_parties_detail (party_id, party_type, last_name, first_name, tax_code, vat_number,
                                birth_date, death_date, birth_municipality, fk_address_residential,
                                fl_archived, dt_insert, user_id_insert, dt_delete)
VALUES (-444, 'N', 'REALT_TECHNOLOGY', 'SPA', '222', '333',
        '20010131', '20231031', 'ITA_20_095038', -2,
        0, TO_DATE('2022-01-01', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'));

insert into prt_parties_tags(pkid, party_id, tag_id, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-9, -444, -3, TO_DATE('2022-01-01', 'YYYY-MM-DD'), :user_id, TO_DATE('2022-01-02', 'YYYY-MM-DD'), :user_id);
insert into prt_parties_tags(pkid, party_id, tag_id, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-10, -444, -4, TO_DATE('2022-01-01', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);
--- --- --------------------------------------------------------------------------------------------------------------------------------------------------------

--- 333 --------------------------------------------------------------------------------------------------------------------------------------------------------
INSERT INTO prt_parties (id, tenant_id)
VALUES (-333, :test_tenant);

INSERT INTO prt_addresses (id, municipality, locality, street, house_number, postcode, details, note)
VALUES (-33301, 'ITA_01_001001', 'Loc 1', 'via Roma', '4', '11111', 'details test', 'note test');
INSERT INTO prt_addresses (id, municipality, locality, street, house_number, postcode, details, note)
VALUES (-33302, 'ITA_01_001002', 'Loc 2', 'via Napoli', '66', '22222', 'details test', 'note test');
INSERT INTO prt_addresses (id, municipality, locality, street, house_number, postcode, details, note)
VALUES (-33303, 'ITA_01_001003', null, 'via Sicilia', '1', '33333', 'details test', 'note test');

INSERT INTO prt_parties_detail (party_id, party_type, last_name, first_name, tax_code, vat_number, birth_date, death_date,
                                birth_municipality, fk_address_residential, fk_address_home, fk_address_billing,
                                fl_archived, dt_insert, user_id_insert, dt_delete)
VALUES (-333, 'L', 'ROSSI', 'MARIO', 'RSSMR', '0001233', '20010131', '20401231',
        'ITA_01_001001', -33301, -33302, -33303,
        0, TO_DATE('2022-01-01', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'));

insert into prt_parties_tags(pkid, party_id, tag_id, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-11, -333, -3, TO_DATE('2022-01-01', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);
insert into prt_parties_tags(pkid, party_id, tag_id, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-12, -333, -4, TO_DATE('2022-01-01', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);
--- --- --------------------------------------------------------------------------------------------------------------------------------------------------------

--- 222 --------------------------------------------------------------------------------------------------------------------------------------------------------
INSERT INTO prt_parties (id, tenant_id)
VALUES (-222, :test_tenant);

INSERT INTO prt_parties_detail (party_id, party_type, last_name, first_name, tax_code, vat_number,
                                birth_date, death_date, birth_municipality,
                                fk_address_residential, fl_archived, dt_insert, user_id_insert, dt_delete)
VALUES (-222, 'N', 'DEMO_COMPANY_2', 'SPA', 'DMC', 'DMC', '20010131', '20500131', 'Trentino-Alto Adige',
        null, 0, TO_DATE('2022-01-01', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'));
--- --- --------------------------------------------------------------------------------------------------------------------------------------------------------



















