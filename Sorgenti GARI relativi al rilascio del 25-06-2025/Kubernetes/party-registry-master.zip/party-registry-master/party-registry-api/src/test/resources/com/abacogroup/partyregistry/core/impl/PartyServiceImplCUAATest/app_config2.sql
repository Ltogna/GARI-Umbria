insert into prt_app_configuration (id, tenant_id, configuration_key, configuration, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-100, :test_tenant, 'code', '{"mandatory":false,"editable":false}',
        TO_DATE('2022-01-01', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), NULL);
