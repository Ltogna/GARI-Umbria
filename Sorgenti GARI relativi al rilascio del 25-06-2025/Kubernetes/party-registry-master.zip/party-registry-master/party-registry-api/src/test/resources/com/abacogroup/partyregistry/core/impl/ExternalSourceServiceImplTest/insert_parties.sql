
--- TAGS ---
INSERT INTO prt_tags (id, tag_code, tenant_id)
VALUES (-3, 'BUG', :test_tenant);
INSERT INTO prt_tags (id, tag_code, tenant_id)
VALUES (-4, 'LOL', :test_tenant);

INSERT INTO prt_tags (tag_code, tenant_id)
VALUES ('AA', :test_tenant);
INSERT INTO prt_tags (tag_code, tenant_id)
VALUES ('BB', :test_tenant);


--- PARTIES ---

-- 222 -----
-- addr
INSERT INTO prt_addresses (id, municipality, locality, street, house_number, postcode, details, note)
VALUES (-22201, 'ITA_20_292_009', 'Pirri', 'via Italia', '1', '09134', 'details test', 'note test');

-- party
INSERT INTO prt_parties (id, tenant_id)
VALUES (-222, :test_tenant);
INSERT INTO prt_parties_detail (party_id, party_type, last_name, first_name, tax_code, vat_number, code,
                                birth_date, death_date, birth_municipality, nationality, source_code,
                                fk_address_residential, fk_address_billing, fl_archived, dt_insert, user_id_insert, dt_delete)
VALUES (-222, 'L', 'REALT-TECHNOLOGY', null, '01234567890', '01234567890', '01234567890',
        '20170101', '99991231', 'ITA_20_292_009', null, null,
        -22201, null, 0, TO_DATE('2022-01-01', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'));

-- tags
insert into prt_parties_tags(pkid, party_id, tag_id, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-2220301, -222, -3, TO_DATE('2022-01-01', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);
-- 222 -----

-- 333 -----
-- party
INSERT INTO prt_parties (id, tenant_id)
VALUES (-333, :test_tenant);
INSERT INTO prt_parties_detail (party_id, party_type, last_name, first_name, tax_code, vat_number, code,
                                birth_date, death_date, birth_municipality, nationality, source_code,
                                fk_address_residential, fk_address_billing, fl_archived, dt_insert, user_id_insert, dt_delete)
VALUES (-333, 'L', 'LEGAL 333', null, '00000000333', '00000000333', '00000000333',
        '20170101', '99991231', 'ITA_20_292_009', null, null,
        null, null, 0, TO_DATE('2022-01-01', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'));
-- 333 -----

-- 444 -----
-- addr
INSERT INTO prt_addresses (id, municipality, locality, street, house_number, postcode, details, note)
VALUES (-44401, 'ITA_20_292_009', null, 'via Napoli', '444', '09134', 'details test', 'note test');

-- party
INSERT INTO prt_parties (id, tenant_id)
VALUES (-444, :test_tenant);
INSERT INTO prt_parties_detail (party_id, party_type, last_name, first_name, tax_code, vat_number, code,
                                birth_date, death_date, birth_municipality, nationality, source_code,
                                fk_address_residential, fk_address_billing, fl_archived, dt_insert, user_id_insert, dt_delete)
VALUES (-444, 'N', 'QUATTRO', 'MARIO', 'QTTMRA44L04B354X', null, 'QTTMRA44L04B354X',
        '19440404', '99991231', 'ITA_20_292_009', 'ITA', 'SOURCE3',
        -44401, null, 0, TO_DATE('2022-01-01', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'));

-- contacts
insert into prt_parties_contacts (pkid, party_id, contact_type, sub_type, contact_value,
                                  dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-44401, -444, 'PHONE', 'test', '000-4440444',
        TO_DATE('2022-01-01', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);
insert into prt_parties_contacts (pkid, party_id, contact_type, sub_type, contact_value,
                                  dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-44402, -444, 'EMAIL', 'test', 'test444@example.com',
        TO_DATE('2022-01-01', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);
-- 444 -----

-- 111 -----
-- addr
INSERT INTO prt_addresses (id, municipality, locality, street, house_number, postcode, details, note)
VALUES (-11101, 'ITA_20_292_009', 'Pirri', 'via Ruggero Bacone', '4', '09134', 'details test', 'note test');
INSERT INTO prt_addresses (id, municipality, locality, street, house_number, postcode, details, note)
VALUES (-11102, 'ITA_20_292_009', 'Pirri', 'via Ruggero Bacone', '4/a', '09134', 'billing', 'note test');

-- party
INSERT INTO prt_parties (id, tenant_id)
VALUES (-111, :test_tenant);
INSERT INTO prt_parties_detail (party_id, party_type, last_name, first_name, tax_code, vat_number, code,
                                birth_date, death_date, birth_municipality, nationality, source_code,
                                fk_address_residential, fk_address_billing, fl_archived, dt_insert, user_id_insert, dt_delete)
VALUES (-111, 'N', 'ROSSI', 'MARIO', 'RSSMRA73L09B354X', null, 'RSSMRA73L09B354X',
        '19731109', '99991231', 'ITA_20_292_009', 'ITA', 'SOURCE3',
        -11101, -11102, 0, TO_DATE('2022-01-01', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'));

-- tags
insert into prt_parties_tags(pkid, party_id, tag_id, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-1110401, -111, -4, TO_DATE('2022-01-01', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);

-- docs
insert into prt_parties_documents (pkid, tenant_id, party_id, definition_code, document_id,
                                   dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-1110101, :test_tenant, -111, 'DEF_TEST_1', 9999901,
        TO_DATE('2022-01-01', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);
insert into prt_parties_documents (pkid, tenant_id, party_id, definition_code, document_id,
                                   dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-1110102, :test_tenant, -111, 'DEF_TEST_1', 9999903,
        TO_DATE('2022-01-01', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);
insert into prt_parties_documents (pkid, tenant_id, party_id, definition_code, document_id,
                                   dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-1110301, :test_tenant, -111, 'DEF_TEST_3', 9999902,
        TO_DATE('2022-01-01', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);

-- rel
insert into prt_party_relations (id, party_id, relation_type_id, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-1110101, -111, -1, TO_DATE('2022-01-01', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);
insert into prt_party_relation_parties (pkid, party_relation_id, party_id, relation_role_id, dt_start, dt_end,
                                        dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-111010101, -1110101, -222, -101, '20220101', '99991231',
        TO_DATE('2022-01-01', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);
insert into prt_party_relation_parties (pkid, party_relation_id, party_id, relation_role_id, dt_start, dt_end,
                                        dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-111010102, -1110101, -333, -101, '20220101', '99991231',
        TO_DATE('2022-01-01', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);

insert into prt_party_relations (id, party_id, relation_type_id, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-1110301, -111, -3, TO_DATE('2022-01-01', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);
insert into prt_party_relation_parties (pkid, party_relation_id, party_id, relation_role_id, dt_start, dt_end,
                                        dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-111030101, -1110301, -222, -302, '20220101', '99991231',
        TO_DATE('2022-01-01', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);

-- contacts
insert into prt_parties_contacts (pkid, party_id, contact_type, sub_type, contact_value,
                                  dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-11101, -111, 'PEC', 'test', 'test111@pec.it',
        TO_DATE('2022-01-01', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);
insert into prt_parties_contacts (pkid, party_id, contact_type, sub_type, contact_value,
                                  dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-11102, -111, 'EMAIL', 'test', 'test111@example.com',
        TO_DATE('2022-01-01', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);
-- 111 -----

