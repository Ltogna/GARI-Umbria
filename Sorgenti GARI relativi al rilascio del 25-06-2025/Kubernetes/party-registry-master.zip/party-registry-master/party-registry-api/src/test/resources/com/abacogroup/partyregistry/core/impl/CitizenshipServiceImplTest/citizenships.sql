--liquibase formatted sql
--changeset realt:CitizenshipServiceImplTest002

INSERT INTO prt_citizenship (tenant_id, code)
VALUES (:test_tenant, 'ITA');
INSERT INTO prt_citizenship (tenant_id, code)
VALUES (:test_tenant, 'TUN');
INSERT INTO prt_citizenship (tenant_id, code)
VALUES (:test_tenant, 'FRA');
INSERT INTO prt_citizenship (tenant_id, code)
VALUES (:test_tenant, 'GBR');
INSERT INTO prt_citizenship (tenant_id, code)
VALUES (:test_tenant, 'DEU');

INSERT INTO prt_citizenship (tenant_id, code)
VALUES ('myTenant008', 'ITA');
INSERT INTO prt_citizenship (tenant_id, code)
VALUES ('myTenant008', 'EST');
INSERT INTO prt_citizenship (tenant_id, code)
VALUES ('myTenant008', 'SWE');
INSERT INTO prt_citizenship (tenant_id, code)
VALUES ('myTenant008', 'FIN');
INSERT INTO prt_citizenship (tenant_id, code)
VALUES ('myTenant008', 'NOR');
INSERT INTO prt_citizenship (tenant_id, code)
VALUES ('myTenant008', 'LTU');

INSERT INTO prt_i18n_values (tenant_id, table_name, field_name, i18n_value, lang, i18n_text)
VALUES (:test_tenant, 'prt_citizenship', 'code', 'ITA', 'en', '-');
INSERT INTO prt_i18n_values (tenant_id, table_name, field_name, i18n_value, lang, i18n_text)
VALUES (:test_tenant, 'prt_citizenship', 'code', 'TUN', 'en', '-');
INSERT INTO prt_i18n_values (tenant_id, table_name, field_name, i18n_value, lang, i18n_text)
VALUES (:test_tenant, 'prt_citizenship', 'code', 'FRA', 'en', '-');
INSERT INTO prt_i18n_values (tenant_id, table_name, field_name, i18n_value, lang, i18n_text)
VALUES (:test_tenant, 'prt_citizenship', 'code', 'GBR', 'en', '-');
INSERT INTO prt_i18n_values (tenant_id, table_name, field_name, i18n_value, lang, i18n_text)
VALUES (:test_tenant, 'prt_citizenship', 'code', 'DEU', 'en', '-');

INSERT INTO prt_i18n_values (tenant_id, table_name, field_name, i18n_value, lang, i18n_text)
VALUES ('myTenant008', 'prt_citizenship', 'code', 'ITA', 'en', '-');
INSERT INTO prt_i18n_values (tenant_id, table_name, field_name, i18n_value, lang, i18n_text)
VALUES ('myTenant008', 'prt_citizenship', 'code', 'EST', 'en', '-');
INSERT INTO prt_i18n_values (tenant_id, table_name, field_name, i18n_value, lang, i18n_text)
VALUES ('myTenant008', 'prt_citizenship', 'code', 'SWE', 'en', '-');
INSERT INTO prt_i18n_values (tenant_id, table_name, field_name, i18n_value, lang, i18n_text)
VALUES ('myTenant008', 'prt_citizenship', 'code', 'FIN', 'en', '-');
INSERT INTO prt_i18n_values (tenant_id, table_name, field_name, i18n_value, lang, i18n_text)
VALUES ('myTenant008', 'prt_citizenship', 'code', 'NOR', 'en', '-');
INSERT INTO prt_i18n_values (tenant_id, table_name, field_name, i18n_value, lang, i18n_text)
VALUES ('myTenant008', 'prt_citizenship', 'code', 'LTU', 'en', '-');

insert into prt_i18n_values (tenant_id, table_name, field_name, i18n_value, lang, i18n_text)
select tenant_id, table_name, field_name, i18n_value, 'it', i18n_text
from prt_i18n_values
where tenant_id IN (:test_tenant, 'myTenant008')
  and lang = 'en';

update prt_i18n_values
set i18n_text = lower(i18n_value) || '_' || lang
where tenant_id IN (:test_tenant, 'myTenant008');
