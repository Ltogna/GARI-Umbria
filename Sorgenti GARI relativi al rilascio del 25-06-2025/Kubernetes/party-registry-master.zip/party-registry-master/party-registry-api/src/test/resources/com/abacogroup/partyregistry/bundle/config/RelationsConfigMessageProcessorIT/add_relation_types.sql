---     Relation types    ---

insert into prt_relation_types (id, tenant_id, code, fl_multiple, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-11, :test_tenant, 'RIFERIMENTI_CONTATTI', 0,
        TO_DATE('2022-05-11', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'),
        :user_id);

insert into prt_relation_types (id, tenant_id, code, fl_multiple, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-12, :test_tenant, 'NUCLEO_FAMILIARE', 1,
        TO_DATE('2022-05-11', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), :user_id);


insert into prt_relation_types (id, tenant_id, code, fl_multiple, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-13, :test_tenant, 'AZIENDA', 1,
        TO_DATE('2022-05-11', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), :user_id);

insert into prt_relation_types (id, tenant_id, code, fl_multiple, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-14, :test_tenant, 'OTHER_TYPE', 1,
        TO_DATE('2022-05-11', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), :user_id);
