insert into prt_relation_roles (id, type_id, code, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-97, -1003, 'MOGLIE', TO_DATE('2022-05-11', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), :user_id);
insert into prt_relation_roles (id, type_id, code, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-98, -1003, 'MOGLIE_A_CARICO', TO_DATE('2022-05-11', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'),
        :user_id);
insert into prt_relation_roles (id, type_id, code, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-99, -1003, 'MARITO', TO_DATE('2022-05-11', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), :user_id);
