INSERT INTO prt_parties (id, tenant_id)
VALUES (-1, :test_tenant);
INSERT INTO prt_parties_detail
(party_id, party_type, last_name, first_name, tax_code, vat_number, birth_date, death_date, birth_municipality,
 fk_address_residential, fl_archived,
 dt_insert, user_id_insert, dt_delete)
VALUES (-1, 'N', 'UNO', 'DEMO', '000', '111', '20010131', '99991231', 'Verona',
        null, 0, TO_DATE('2022-01-01', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'));

INSERT INTO prt_parties (id, tenant_id)
VALUES (-2, :test_tenant);
INSERT INTO prt_parties_detail
(party_id, party_type, last_name, first_name, tax_code, vat_number, birth_date, death_date, birth_municipality,
 fk_address_residential, fl_archived,
 dt_insert, user_id_insert, dt_delete)
VALUES (-2, 'N', 'DUE', 'DEMO', '000', '111', '20010131', '99991231', 'Verona',
        null, 0, TO_DATE('2022-01-01', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'));

INSERT INTO prt_parties (id, tenant_id)
VALUES (-3, :test_tenant);
INSERT INTO prt_parties_detail
(party_id, party_type, last_name, first_name, tax_code, vat_number, birth_date, death_date, birth_municipality,
 fk_address_residential, fl_archived, dt_insert, user_id_insert, dt_delete)
VALUES ( -3, 'N', 'TRE', 'DEMO', '000', '111', '20010131', '99991231', 'Verona'
       , null, 0, TO_DATE('2022-01-01', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'));



INSERT INTO prt_relation_types
(id, tenant_id, code, fl_multiple,
 dt_insert, user_id_insert, dt_delete, user_id_delete)
VALUES (-100, :test_tenant, 'DELETED_TYPE', 1, TO_DATE('2022-01-01', 'YYYY-MM-DD'), :user_id, TO_DATE('2022-04-01', 'YYYY-MM-DD'), :user_id);

INSERT INTO prt_relation_types
(id, tenant_id, code, fl_multiple,
 dt_insert, user_id_insert, dt_delete, user_id_delete)
VALUES (-130, :test_tenant, 'REL_TYPE_130', 1,
        TO_DATE('2022-01-01', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);

INSERT INTO prt_relation_types
(id, tenant_id, code, fl_multiple,
 dt_insert, user_id_insert, dt_delete, user_id_delete)
VALUES (-140, :test_tenant, 'REL_TYPE_140', 0,
        TO_DATE('2022-01-01', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);

INSERT INTO prt_relation_types
(id, tenant_id, code, fl_multiple,
 dt_insert, user_id_insert, dt_delete, user_id_delete)
VALUES (-150, :test_tenant, 'REL_TYPE_150', 0,
        TO_DATE('2022-01-01', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);


INSERT INTO prt_relation_roles
(id, type_id, code,
 dt_insert, user_id_insert, dt_delete, user_id_delete)
VALUES (-101, -100, 'DELETED_ROLE',
        TO_DATE('2022-05-11', 'YYYY-MM-DD'), :user_id, TO_DATE('2022-01-02', 'YYYY-MM-DD'), :user_id);

INSERT INTO prt_relation_roles
(id, type_id, code,
 dt_insert, user_id_insert, dt_delete, user_id_delete)
VALUES (-102, -100, 'NOT_DELETED',
        TO_DATE('2022-01-01', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), :user_id);


INSERT INTO prt_relation_roles
(id, type_id, code,
 dt_insert, user_id_insert, dt_delete, user_id_delete)
VALUES (-1500, -150, 'REL_TYPE_150_1',
        TO_DATE('2022-01-01', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), :user_id);

INSERT INTO prt_relation_roles
(id, type_id, code,
 dt_insert, user_id_insert, dt_delete, user_id_delete)
VALUES (-1502, -150, 'REL_TYPE_150_2',
        TO_DATE('2022-01-01', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), :user_id);



INSERT INTO prt_party_relations
(id, party_id, relation_type_id,
 dt_insert, user_id_insert, dt_delete)
VALUES (-1001, -1, -130,
        TO_DATE('2022-01-01', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'));

INSERT INTO prt_party_relations
(id, party_id, relation_type_id,
 dt_insert, user_id_insert, dt_delete)
VALUES (-1002, -1, -140,
        TO_DATE('2022-01-01', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'));


INSERT INTO prt_party_relations
(id, party_id, relation_type_id,
 dt_insert, user_id_insert, dt_delete)
VALUES (-1003, -2, -100,
        TO_DATE('2022-01-01', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'));


INSERT INTO prt_party_relations
(id, party_id, relation_type_id,
 dt_insert, user_id_insert, dt_delete)
VALUES (-1004, -3, -130,
        TO_DATE('2022-01-01', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'));


INSERT INTO prt_party_relation_details
(party_relation_id, note,
 dt_insert, user_id_insert, dt_delete)
VALUES (-1001, 'Nucleo familiare di realt',
        TO_DATE('2022-01-01', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'));

INSERT INTO prt_party_relation_details
(party_relation_id, note,
 dt_insert, user_id_insert, dt_delete)
VALUES (-1002, 'Azienda in cui realt è assunto',
        TO_DATE('2022-01-01', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'));

INSERT INTO prt_party_relation_details
(party_relation_id, note,
 dt_insert, user_id_insert, dt_delete)
VALUES (-1003, 'deleted type',
        TO_DATE('2022-01-01', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'));

INSERT INTO prt_party_relation_details
(party_relation_id, note,
 dt_insert, user_id_insert, dt_delete)
VALUES (-1004, 'Famiglia di realt',
        TO_DATE('2022-01-01', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'));




