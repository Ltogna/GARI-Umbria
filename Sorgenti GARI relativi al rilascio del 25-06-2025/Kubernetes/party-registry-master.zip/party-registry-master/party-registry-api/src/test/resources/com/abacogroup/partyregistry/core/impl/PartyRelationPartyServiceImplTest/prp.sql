--Party

INSERT INTO prt_parties (id, tenant_id)
VALUES (-1, :test_tenant);
INSERT INTO prt_parties_detail
(party_id, party_type, last_name, first_name, tax_code, vat_number, birth_date, death_date, birth_municipality,
 fk_address_residential, fl_archived,
 dt_insert, user_id_insert, dt_delete)
VALUES (-1, 'N', 'REALT', 'DEMO', '000', '111', '20010131', '99991231', 'Verona', null, 0,
        TO_DATE('2022-01-01', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'));


INSERT INTO prt_parties (id, tenant_id)
VALUES (-2, :test_tenant);
INSERT INTO prt_parties_detail
(party_id, party_type, last_name, first_name, tax_code, vat_number, birth_date, death_date, birth_municipality,
 fk_address_residential, fl_archived,
 dt_insert, user_id_insert, dt_delete)
VALUES (-2, 'N', 'ROSSI', 'MARIO', 'RSSMR', '0001233', '20010131', '99991231', 'Firenze',
        null, 0, TO_DATE('2022-01-01', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'));


INSERT INTO prt_parties (id, tenant_id)
VALUES (-3, :test_tenant);
INSERT INTO prt_parties_detail
(party_id, party_type, last_name, first_name, tax_code, vat_number, fl_archived, death_date,
 dt_insert, user_id_insert, dt_delete, user_id_delete)
VALUES (-3, 'N', 'DELE', 'TED', '123', '321', 1, '99991231',
        TO_DATE('2022-01-01', 'YYYY-MM-DD'), :user_id, TO_DATE('2022-01-02', 'YYYY-MM-DD'), :user_id);

INSERT INTO prt_parties (id, tenant_id)
VALUES (-4, :test_tenant);
INSERT INTO prt_parties_detail
(party_id, party_type, last_name, first_name, tax_code, vat_number, fl_archived, death_date,
 dt_insert, user_id_insert, dt_delete, user_id_delete)
VALUES (-4, 'N', 'MINATO', 'ELI', '456', '654', 0, '99991231',
        TO_DATE('2022-01-01', 'YYYY-MM-DD'), :user_id, TO_DATE('2022-01-02', 'YYYY-MM-DD'), :user_id);


INSERT INTO prt_parties (id, tenant_id)
VALUES (-5, :test_tenant);
INSERT INTO prt_parties_detail
(party_id, party_type, last_name, first_name, tax_code, vat_number, birth_date, death_date, birth_municipality,
 fk_address_residential, fl_archived,
 dt_insert, user_id_insert, dt_delete)
VALUES (-5, 'N', 'REALT_TECHNOLOGY', 'SPA', '222', '333', '20010131', '99991231', 'Cagliari', null, 0,
        TO_DATE('2022-01-01', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'));



INSERT INTO prt_relation_types
(id, tenant_id, code, fl_multiple,
 dt_insert, user_id_insert, dt_delete, user_id_delete)
VALUES (-13, :test_tenant, 'NUCLEO_FAMILIARE', 1,
        TO_DATE('2022-05-11', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);

INSERT INTO prt_relation_types
(id, tenant_id, code, fl_multiple,
 dt_insert, user_id_insert, dt_delete, user_id_delete)
VALUES (-14, :test_tenant, 'AZIENDA', 1,
        TO_DATE('2022-05-11', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);


INSERT INTO prt_relation_types
(id, tenant_id, code, fl_multiple,
 dt_insert, user_id_insert, dt_delete, user_id_delete)
VALUES (-200, :test_tenant, 'DELETED_TYPE_', 1,
        TO_DATE('2022-01-01', 'YYYY-MM-DD'), :user_id, TO_DATE('2022-04-01', 'YYYY-MM-DD'), :user_id);



INSERT INTO prt_relation_roles
(id, type_id, code,
 dt_insert, user_id_insert, dt_delete, user_id_delete)
VALUES (-15, -14, 'SORELLASTRA',
        TO_DATE('2022-01-01', 'YYYY-MM-DD'), :user_id, TO_DATE('2022-01-02', 'YYYY-MM-DD'), :user_id);

INSERT INTO prt_relation_roles
(id, type_id, code,
 dt_insert, user_id_insert, dt_delete, user_id_delete)
VALUES (-3, -13, 'MARITO',
        TO_DATE('2022-05-11', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);

INSERT INTO prt_relation_roles
(id, type_id, code,
 dt_insert, user_id_insert, dt_delete, user_id_delete)
VALUES (-1301, -13, 'XXX',
        TO_DATE('2022-05-11', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);

INSERT INTO prt_relation_roles
(id, type_id, code,
 dt_insert, user_id_insert, dt_delete, user_id_delete)
VALUES (-14, -14, 'SORELLA',
        TO_DATE('2022-01-01', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);

INSERT INTO prt_relation_roles
(id, type_id, code,
 dt_insert, user_id_insert, dt_delete, user_id_delete)
VALUES (-201, -200, 'DELETED_ROLE',
        TO_DATE('2022-05-11', 'YYYY-MM-DD'), :user_id, TO_DATE('2022-01-02', 'YYYY-MM-DD'), :user_id);

INSERT INTO prt_relation_roles
(id, type_id, code,
 dt_insert, user_id_insert, dt_delete, user_id_delete)
VALUES (-202, -200, 'NOT_DELETED',
        TO_DATE('2022-01-01', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);



INSERT INTO prt_party_relations
(id, party_id, relation_type_id,
 dt_insert, user_id_insert, dt_delete, user_id_delete)
VALUES (-2001, -4, -13,
        TO_DATE('2022-01-01', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);

INSERT INTO prt_party_relations
(id, party_id, relation_type_id,
 dt_insert, user_id_insert, dt_delete, user_id_delete)
VALUES (-2002, -4, -14,
        TO_DATE('2022-01-01', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);

INSERT INTO prt_party_relations
(id, party_id, relation_type_id,
 dt_insert, user_id_insert, dt_delete, user_id_delete)
VALUES (-2003, -1, -200,
        TO_DATE('2022-01-01', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);


INSERT INTO prt_party_relations
(id, party_id, relation_type_id,
 dt_insert, user_id_insert, dt_delete, user_id_delete)
VALUES (-2005, -1, -14,
        TO_DATE('2022-01-01', 'YYYY-MM-DD'), :user_id, TO_DATE('2022-01-02', 'YYYY-MM-DD'), :user_id);

INSERT INTO prt_party_relations
(id, party_id, relation_type_id,
 dt_insert, user_id_insert, dt_delete)
VALUES (-879, -1, -13,
        TO_DATE('2022-01-01', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'));

INSERT INTO prt_party_relations
(id, party_id, relation_type_id,
 dt_insert, user_id_insert, dt_delete)
VALUES (-889, -1, -14,
        TO_DATE('2022-01-01', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'));



INSERT INTO prt_party_relation_parties
(pkid, party_relation_id, party_id, relation_role_id, dt_start, dt_end,
 dt_insert, user_id_insert, dt_delete, user_id_delete)
VALUES (-2001, -879, -5, -3, '20220101', '99991231',
        TO_DATE('2022-01-01', 'YYYY-MM-DD'), :user_id, TO_DATE('2022-01-02', 'YYYY-MM-DD'), :user_id);


INSERT INTO prt_party_relation_parties
(pkid, party_relation_id, party_id, relation_role_id, dt_start, dt_end,
 dt_insert, user_id_insert, dt_delete, user_id_delete)
VALUES (-2002, -879, -3, -3, '20220101', '99991231',
        TO_DATE('2022-01-01', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);

INSERT INTO prt_party_relation_parties
(pkid, party_relation_id, party_id, relation_role_id, dt_start, dt_end,
 dt_insert, user_id_insert, dt_delete, user_id_delete)
VALUES (-2003, -889, -5, -14, '20220101', '99991231',
        TO_DATE('2022-01-01', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);

INSERT INTO prt_party_relation_parties
(pkid, party_relation_id, party_id, relation_role_id, dt_start, dt_end,
 dt_insert, user_id_insert, dt_delete, user_id_delete)
VALUES (-2004, -889, -2, -15, '20220101', '99991231',
        TO_DATE('2022-01-01', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);

INSERT INTO prt_party_relation_parties
(pkid, party_relation_id, party_id, relation_role_id, dt_start, dt_end,
 dt_insert, user_id_insert, dt_delete, user_id_delete)
VALUES (-2005, -2005, -5, -14, '20220101', '99991231',
        TO_DATE('2022-01-01', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);

-- INSERT INTO prt_party_relation_parties
-- (pkid, party_relation_id, party_id, relation_role_id, dt_start, dt_end,
--  dt_insert, user_id_insert, dt_delete, user_id_delete)
-- VALUES (-2006, -2003, -5, -201, '20220101', '99991231',
--         TO_DATE('2022-01-01', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);

INSERT INTO prt_party_relation_parties
(pkid, party_relation_id, party_id, relation_role_id, dt_start, dt_end,
 dt_insert, user_id_insert, dt_delete, user_id_delete)
VALUES (-2007, -2003, -2, -202, '20220101', '99991231',
        TO_DATE('2022-01-01', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);

-- INSERT INTO prt_party_relation_parties
-- (pkid, party_relation_id, party_id, relation_role_id, dt_start, dt_end,
--  dt_insert, user_id_insert, dt_delete, user_id_delete)
-- VALUES (-2008, -2002, -5, -14, '20220101', '99991231',
--         TO_DATE('2022-01-01', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);


INSERT INTO prt_party_relation_parties
(party_relation_id, party_id, relation_role_id, dt_start, dt_end,
 dt_insert, user_id_insert, dt_delete)
VALUES (-879, -2, -3, '20220101', '99991231',
        TO_DATE('2022-01-01', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'));

INSERT INTO prt_party_relation_parties
(party_relation_id, party_id, relation_role_id, dt_start, dt_end,
 dt_insert, user_id_insert, dt_delete)
VALUES (-889, -5, -3, '20220101', '99991231',
        TO_DATE('2022-01-01', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'));


INSERT INTO prt_party_relation_details
(party_relation_id, note,
 dt_insert, user_id_insert, dt_delete)
VALUES (-889, 'Azienda in cui realt è assunto',
        TO_DATE('2022-01-01', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'));
