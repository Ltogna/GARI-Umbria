insert into prt_app_configuration (id, tenant_id, configuration_key, configuration, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-2001, :test_tenant, 'test1', '{"show": true}', TO_DATE('2022-01-01', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), NULL);
insert into prt_app_configuration (id, tenant_id, configuration_key, configuration, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-2002, :test_tenant, 'test2', '{"show": true}', TO_DATE('2022-01-01', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), NULL);
insert into prt_app_configuration (id, tenant_id, configuration_key, configuration, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-2003, :test_tenant, 'test3', '{"show": true}', TO_DATE('2022-01-01', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), NULL);
insert into prt_app_configuration (id, tenant_id, configuration_key, configuration, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-2004, :test_tenant, 'test4', '{"show": true}', TO_DATE('2022-01-01', 'YYYY-MM-DD'), :user_id, TO_DATE('2023-02-01', 'YYYY-MM-DD'), :user_id);
