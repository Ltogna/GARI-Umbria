
--- APP CFG ---
insert into prt_app_configuration (id, tenant_id, configuration_key, configuration,
                                   dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-100, :test_tenant, 'code', '{"mandatory":false,"editable":false}',
        TO_DATE('2022-01-01', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), NULL);

--- LEGAL STATUS ---
INSERT INTO prt_legal_status (tenant_id, code)
VALUES (:test_tenant, 'OTHER');

--- CITIZ. ---
INSERT INTO prt_citizenship (tenant_id, code)
VALUES (:test_tenant, 'ITA');
INSERT INTO prt_citizenship (tenant_id, code)
VALUES (:test_tenant, 'XXX');

--- DOC TYPES ---
insert into prt_doc_type (id, tenant_id, doc_type, dt_insert, user_id_insert, dt_delete, user_id_delete, doc_group)
values (-1, :test_tenant, 'DEF_TEST_1', TO_DATE('19700101', 'YYYYMMDD'), :user_id, TO_DATE('99991231', 'YYYYMMDD'), null, 'test');
insert into prt_doc_type_relations (pkid, doc_type_id, party_type, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-101, -1, 'L', TO_DATE('19700101', 'YYYYMMDD'), :user_id, TO_DATE('99991231', 'YYYYMMDD'), null);
insert into prt_doc_type_relations (pkid, doc_type_id, party_type, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-102, -1, 'N', TO_DATE('19700101', 'YYYYMMDD'), :user_id, TO_DATE('99991231', 'YYYYMMDD'), null);

insert into prt_doc_type (id, tenant_id, doc_type, dt_insert, user_id_insert, dt_delete, user_id_delete, doc_group)
values (-2, :test_tenant, 'DEF_TEST_2', TO_DATE('19700101', 'YYYYMMDD'), :user_id, TO_DATE('99991231', 'YYYYMMDD'), null, 'test');
insert into prt_doc_type_relations (pkid, doc_type_id, party_type, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-201, -2, 'L', TO_DATE('19700101', 'YYYYMMDD'), :user_id, TO_DATE('99991231', 'YYYYMMDD'), null);
insert into prt_doc_type_relations (pkid, doc_type_id, party_type, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-202, -2, 'N', TO_DATE('19700101', 'YYYYMMDD'), :user_id, TO_DATE('99991231', 'YYYYMMDD'), null);

insert into prt_doc_type (id, tenant_id, doc_type, dt_insert, user_id_insert, dt_delete, user_id_delete, doc_group)
values (-3, :test_tenant, 'DEF_TEST_3', TO_DATE('19700101', 'YYYYMMDD'), :user_id, TO_DATE('99991231', 'YYYYMMDD'), null, 'test');
insert into prt_doc_type_relations (pkid, doc_type_id, party_type, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-301, -3, 'L', TO_DATE('19700101', 'YYYYMMDD'), :user_id, TO_DATE('99991231', 'YYYYMMDD'), null);
insert into prt_doc_type_relations (pkid, doc_type_id, party_type, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-302, -3, 'N', TO_DATE('19700101', 'YYYYMMDD'), :user_id, TO_DATE('99991231', 'YYYYMMDD'), null);

--- RELATIONS ---
insert into prt_relation_types (id, tenant_id, code, fl_multiple, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-1, :test_tenant, 'REL_T1', 1, TO_DATE('19700101', 'YYYYMMDD'), :user_id, TO_DATE('99991231', 'YYYYMMDD'), null);
insert into prt_relation_roles (id, type_id, code, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-101, -1, 'REL_T1_R1', TO_DATE('19700101', 'YYYYMMDD'), :user_id, TO_DATE('99991231', 'YYYYMMDD'), null);
insert into prt_relation_roles (id, type_id, code, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-102, -1, 'REL_T1_R2', TO_DATE('19700101', 'YYYYMMDD'), :user_id, TO_DATE('99991231', 'YYYYMMDD'), null);

insert into prt_relation_types (id, tenant_id, code, fl_multiple, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-2, :test_tenant, 'REL_T2', 0, TO_DATE('19700101', 'YYYYMMDD'), :user_id, TO_DATE('99991231', 'YYYYMMDD'), null);
insert into prt_relation_roles (id, type_id, code, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-201, -2, 'REL_T2_R1', TO_DATE('19700101', 'YYYYMMDD'), :user_id, TO_DATE('99991231', 'YYYYMMDD'), null);
insert into prt_relation_roles (id, type_id, code, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-202, -2, 'REL_T2_R2', TO_DATE('19700101', 'YYYYMMDD'), :user_id, TO_DATE('99991231', 'YYYYMMDD'), null);

insert into prt_relation_types (id, tenant_id, code, fl_multiple, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-3, :test_tenant, 'REL_T3', 0, TO_DATE('19700101', 'YYYYMMDD'), :user_id, TO_DATE('99991231', 'YYYYMMDD'), null);
insert into prt_relation_roles (id, type_id, code, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-301, -3, 'REL_T3_R1', TO_DATE('19700101', 'YYYYMMDD'), :user_id, TO_DATE('99991231', 'YYYYMMDD'), null);
insert into prt_relation_roles (id, type_id, code, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-302, -3, 'REL_T3_R2', TO_DATE('19700101', 'YYYYMMDD'), :user_id, TO_DATE('99991231', 'YYYYMMDD'), null);

--- EXTERNAL SOURCES ---
insert into prt_external_sources(pkid,tenant_id, code, url, fl_allow_manual, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-100,:test_tenant,'SOURCE3','http://source3/{code}',1,TO_DATE('2023-02-12', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), NULL);
INSERT INTO prt_i18n_values (tenant_id, table_name, field_name, i18n_value, lang, i18n_text)
VALUES (:test_tenant, 'prt_external_sources', 'code', 'SOURCE3', 'en', 'Source3 En');

