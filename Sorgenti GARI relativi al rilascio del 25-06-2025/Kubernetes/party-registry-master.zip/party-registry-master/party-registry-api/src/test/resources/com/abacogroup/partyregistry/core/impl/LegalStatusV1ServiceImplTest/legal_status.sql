INSERT INTO prt_legal_status (tenant_id, code)
VALUES (:test_tenant, 'ACTIVE');
INSERT INTO prt_legal_status (tenant_id, code)
VALUES (:test_tenant, 'INACTIVE');
INSERT INTO prt_legal_status (tenant_id, code)
VALUES (:test_tenant, 'SUSPENDED');
INSERT INTO prt_legal_status (tenant_id, code)
VALUES (:test_tenant, 'DISSOLVED');
INSERT INTO prt_legal_status (tenant_id, code)
VALUES (:test_tenant, 'LIQUIDATED');


INSERT INTO prt_i18n_values (tenant_id, table_name, field_name, i18n_value, lang, i18n_text)
VALUES (:test_tenant, 'prt_legal_status', 'code', 'ACTIVE', 'en', '-');
INSERT INTO prt_i18n_values (tenant_id, table_name, field_name, i18n_value, lang, i18n_text)
VALUES (:test_tenant, 'prt_legal_status', 'code', 'INACTIVE', 'en', '-');
INSERT INTO prt_i18n_values (tenant_id, table_name, field_name, i18n_value, lang, i18n_text)
VALUES (:test_tenant, 'prt_legal_status', 'code', 'SUSPENDED', 'en', '-');
INSERT INTO prt_i18n_values (tenant_id, table_name, field_name, i18n_value, lang, i18n_text)
VALUES (:test_tenant, 'prt_legal_status', 'code', 'DISSOLVED', 'en', '-');
INSERT INTO prt_i18n_values (tenant_id, table_name, field_name, i18n_value, lang, i18n_text)
VALUES (:test_tenant, 'prt_legal_status', 'code', 'LIQUIDATED', 'en', '-');

insert into prt_i18n_values (tenant_id, table_name, field_name, i18n_value, lang, i18n_text)
select tenant_id, table_name, field_name, i18n_value, 'it', i18n_text
from prt_i18n_values
where tenant_id IN (:test_tenant)
  and lang = 'en';

update prt_i18n_values
set i18n_text = lower(i18n_value) || '_' || lang
where tenant_id IN (:test_tenant);
