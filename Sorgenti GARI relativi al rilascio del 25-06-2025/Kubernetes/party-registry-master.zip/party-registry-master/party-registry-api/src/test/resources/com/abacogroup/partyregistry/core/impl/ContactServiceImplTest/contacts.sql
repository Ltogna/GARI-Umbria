INSERT INTO prt_parties (id, tenant_id)
VALUES (-1, :test_tenant);

INSERT INTO prt_parties_detail
(pkid, party_id, party_type, gender, last_name, first_name,death_date, tax_code, vat_number, fk_address_residential, fk_address_home, fk_address_billing, fl_archived,
 dt_insert, user_id_insert, dt_delete, user_id_delete)
VALUES (-1, -1, 'N', NULL, 'ONE', 'ONE','99991231', '000', '111', NULL, NULL, NULL, 0,
        TO_DATE('2022-01-01', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), NULL);

INSERT INTO prt_parties (id, tenant_id)
VALUES (-2, :test_tenant);

INSERT INTO prt_parties_detail
(pkid, party_id, party_type, gender, last_name, first_name, death_date,tax_code, vat_number, fk_address_residential, fk_address_home, fk_address_billing, fl_archived,
 dt_insert, user_id_insert, dt_delete, user_id_delete)
VALUES (-2, -2, 'N', NULL, 'TWO', 'TWO','99991231', '000', '111', NULL, NULL, NULL, 0,
        TO_DATE('2022-01-01', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), NULL);


-- contatti per -1
INSERT INTO prt_parties_contacts (pkid, party_id, contact_type, sub_type, contact_value, note,
                                  dt_insert, user_id_insert, dt_delete, user_id_delete)
VALUES (-7, -1, 'EMAIL', 'priv', 'scaduto@example.com', 'test note',
        TO_DATE('2022-05-24', 'YYYY-MM-DD'), :user_id, TO_DATE('2022-05-25', 'YYYY-MM-DD'), :user_id);

INSERT INTO prt_parties_contacts (pkid, party_id, contact_type, sub_type, contact_value, note,
                                  dt_insert, user_id_insert, dt_delete, user_id_delete)
VALUES (-8, -1, 'EMAIL', 'priv', 'mario1@example.com', 'test note',
        TO_DATE('2022-05-24', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);


-- contatti per -2
INSERT INTO prt_parties_contacts (pkid, party_id, contact_type, sub_type, contact_value, note,
                                  dt_insert, user_id_insert, dt_delete, user_id_delete)
VALUES (-11, -2, 'EMAIL', 'priv', 'name@example.com', 'tst note -11',
        TO_DATE('2022-05-24', 'YYYY-MM-DD'), 'test_user', TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);

INSERT INTO prt_parties_contacts (pkid, party_id, contact_type, sub_type, contact_value, note,
                                  dt_insert, user_id_insert, dt_delete, user_id_delete)
VALUES (-12, -2, 'PHONE', 'lavoro', '#02112233', 'tst note -12',
        TO_DATE('2022-05-24', 'YYYY-MM-DD'), 'test_user', TO_DATE('2022-05-25', 'YYYY-MM-DD'), 'test_user');

INSERT INTO prt_parties_contacts (pkid, party_id, contact_type, sub_type, contact_value, note,
                                  dt_insert, user_id_insert, dt_delete, user_id_delete)
VALUES (-13, -2, 'PHONE', 'lavoro', '02112233', 'tst note -13',
        TO_DATE('2022-05-25', 'YYYY-MM-DD'), 'test_user', TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);

INSERT INTO prt_parties_contacts (pkid, party_id, contact_type, sub_type, contact_value, note, dt_insert, user_id_insert,
                                  dt_delete, user_id_delete)
VALUES (-14, -2, 'PHONE', 'cellulare', '333221144', 'tst note -14',
        TO_DATE('2022-05-24', 'YYYY-MM-DD'), 'test_user', TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);


