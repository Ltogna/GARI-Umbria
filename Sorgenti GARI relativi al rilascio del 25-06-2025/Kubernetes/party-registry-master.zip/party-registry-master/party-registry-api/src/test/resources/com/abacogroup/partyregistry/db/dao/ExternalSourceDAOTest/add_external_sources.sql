insert into prt_external_sources(pkid, tenant_id, code, url, fl_allow_manual, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-1, 'all_tenants', 'SOURCE1', 'http://source1', 0, TO_DATE('2023-01-01', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), NULL);

insert into prt_external_sources(pkid, tenant_id, code, url, fl_allow_manual, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-2, 'all_tenants', 'SOURCE2', 'http://source2', 0, TO_DATE('2023-02-01', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), NULL);

insert into prt_external_sources(pkid, tenant_id, code, url, fl_allow_manual, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-3, :test_tenant, 'SOURCE3', 'http://source3', 1, TO_DATE('2023-02-12', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), NULL);

insert into prt_external_sources(pkid, tenant_id, code, url, fl_allow_manual, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-4, :test_tenant, 'SOURCE4', 'http://source4', 0, TO_DATE('2023-02-20', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), NULL);
