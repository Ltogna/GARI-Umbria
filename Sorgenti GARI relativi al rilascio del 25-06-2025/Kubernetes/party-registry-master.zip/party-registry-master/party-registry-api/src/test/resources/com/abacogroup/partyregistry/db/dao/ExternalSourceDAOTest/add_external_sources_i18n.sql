insert into prt_i18n_values (tenant_id, table_name, field_name, i18n_value, lang, i18n_text)
values (:test_tenant, 'prt_external_sources', 'code', 'SOURCE3', 'en', '-');

insert into prt_i18n_values (tenant_id, table_name, field_name, i18n_value, lang, i18n_text)
values (:test_tenant, 'prt_external_sources', 'code', 'SOURCE4', 'en', '-');


insert into prt_i18n_values (tenant_id, table_name, field_name, i18n_value, lang, i18n_text)
select tenant_id, table_name, field_name, i18n_value, 'it', i18n_text
from prt_i18n_values
where tenant_id in (:test_tenant)
  and lang = 'en';
--
update prt_i18n_values
set i18n_text = lower(i18n_value) || '_' || lang
where tenant_id in (:test_tenant);
