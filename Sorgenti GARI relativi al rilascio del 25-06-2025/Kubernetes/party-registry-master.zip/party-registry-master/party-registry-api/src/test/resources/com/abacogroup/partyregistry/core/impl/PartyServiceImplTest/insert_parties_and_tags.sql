--liquibase formatted sql
--changeset realt:PartyServiceImplTest001

--- APP CFG ---
insert into prt_app_configuration (id, tenant_id, configuration_key, configuration,
                                   dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-100, :test_tenant, 'code', '{"mandatory":false,"editable":false}',
        TO_DATE('2022-01-01', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), NULL);



--- EXTERNAL SOURCES ---
insert into prt_external_sources(pkid,tenant_id, code, url, fl_allow_manual, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-100,:test_tenant,'SOURCE3','http://source3/{code}',1,TO_DATE('2023-02-12', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), NULL);
INSERT INTO prt_i18n_values (tenant_id, table_name, field_name, i18n_value, lang, i18n_text)
VALUES (:test_tenant, 'prt_external_sources', 'code', 'SOURCE3', 'en', 'Source3 En');



--- TAGS ---
INSERT INTO prt_tags (id, tag_code, tenant_id)
VALUES (-3, 'BUG', :test_tenant);
INSERT INTO prt_tags (id, tag_code, tenant_id)
VALUES (-4, 'LOL', :test_tenant);

INSERT INTO prt_tags (tag_code, tenant_id)
VALUES ('AA', :test_tenant);
INSERT INTO prt_tags (tag_code, tenant_id)
VALUES ('BB', :test_tenant);



--- PARTIES ---

-- 666
INSERT INTO prt_parties (id, tenant_id)
VALUES (-666, :test_tenant);
INSERT INTO prt_parties_detail (party_id, party_type, last_name, first_name, tax_code, vat_number,
                                birth_date, death_date, birth_municipality,
                                fk_address_residential, fl_archived, dt_insert, user_id_insert, dt_delete)
VALUES (-666, 'N', 'REALT', 'DEMO', '000', '111', '20010131', '99991231', 'Verona',
        null, 0, TO_DATE('2022-01-01', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'));

insert into prt_parties_tags(pkid, party_id, tag_id, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-6660301, -666, -3, TO_DATE('2022-01-01', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);
insert into prt_parties_tags(pkid, party_id, tag_id, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-6660401, -666, -4, TO_DATE('2022-01-01', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);
--

-- 555
INSERT INTO prt_parties (id, tenant_id)
VALUES (-555, :test_tenant);
INSERT INTO prt_parties_detail (party_id, party_type, last_name, first_name, tax_code, vat_number,
                                birth_date, death_date, birth_municipality,
                                fk_address_residential, fl_archived, dt_insert, user_id_insert, dt_delete)
VALUES (-555, 'N', 'DEMO_COMPANY', 'SPA', 'DMC', 'DMC', '20010131', '99991231', 'Milano',
        null, 1, TO_DATE('2022-01-01', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'));

insert into prt_parties_tags(pkid, party_id, tag_id, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-5550301, -555, -3, TO_DATE('2022-01-01', 'YYYY-MM-DD'), :user_id, TO_DATE('2022-01-02', 'YYYY-MM-DD'), :user_id);
insert into prt_parties_tags(pkid, party_id, tag_id, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-5550401, -555, -4, TO_DATE('2022-01-01', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);
--

-- 444
INSERT INTO prt_addresses (id, municipality, locality, street, house_number, postcode, details,
                           note)
VALUES (-44401, 'ITA_20_292_009', 'Pirri', 'via Ruggero Bacone', '4', '09134',
        'details test', 'note test');

INSERT INTO prt_parties (id, tenant_id)
VALUES (-444, :test_tenant);
INSERT INTO prt_parties_detail (party_id, party_type, last_name, first_name, tax_code, vat_number,
                                birth_date, death_date, birth_municipality, source_code,
                                fk_address_residential, fl_archived, dt_insert, user_id_insert, dt_delete)
VALUES (-444, 'N', 'REALT_TECHNOLOGY', 'SPA', '222', '333', '20010131', '99991231', 'Cagliari', null,
        -44401, 0, TO_DATE('2022-01-01', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'));

insert into prt_parties_tags(pkid, party_id, tag_id, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-4440301, -444, -3, TO_DATE('2022-01-01', 'YYYY-MM-DD'), :user_id, TO_DATE('2022-01-02', 'YYYY-MM-DD'), :user_id);
insert into prt_parties_tags(pkid, party_id, tag_id, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-4440401, -444, -4, TO_DATE('2022-01-01', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);
--

-- 333
INSERT INTO prt_parties (id, tenant_id)
VALUES (-333, :test_tenant);
INSERT INTO prt_parties_detail (party_id, party_type, last_name, first_name, tax_code, vat_number, code,
                                birth_date, death_date, birth_municipality,
                                fk_address_residential, fl_archived, dt_insert, user_id_insert, dt_delete)
VALUES (-333, 'N', 'ROSSI', 'MARIO', 'RSSMR', '0001233', 'THE_CODE1', '20010131', '99991231', 'Firenze',
        null, 0, TO_DATE('2022-01-01', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'));
--

-- 222
INSERT INTO prt_parties (id, tenant_id)
VALUES (-222, :test_tenant);
INSERT INTO prt_parties_detail (party_id, party_type, last_name, first_name, tax_code, vat_number, code,
                                birth_date, death_date, birth_municipality,
                                fk_address_residential, fl_archived, dt_insert, user_id_insert, dt_delete)
VALUES (-222, 'N', 'DEMO_COMPANY_2', 'SPA', 'DMC', 'DMC', 'THE_CODE2', '20010131', '99991231', 'Trento',
        null, 0, TO_DATE('2022-01-01', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'));
--

-- 111
INSERT INTO prt_addresses (id, municipality, locality, street, house_number, postcode, details,
                           note)
VALUES (-11101, 'ITA_20_292_009', 'Pirri', 'via Ruggero Bacone', '4', '09134',
        'details test', 'note test');
INSERT INTO prt_addresses (id, municipality, locality, street, house_number, postcode, details,
                           note)
VALUES (-11102, 'ITA_20_292_009', 'Pirri', 'via Ruggero Bacone', '4/a', '09134',
        'billing', 'note test');

INSERT INTO prt_parties (id, tenant_id)
VALUES (-111, :test_tenant);
INSERT INTO prt_parties_detail (party_id, party_type, last_name, first_name, tax_code, vat_number, code,
                                birth_date, death_date, birth_municipality, source_code,
                                fk_address_residential, fk_address_billing, fl_archived, dt_insert, user_id_insert, dt_delete)
VALUES (-111, 'N', 'REALT_TECHNOLOGY', 'SPA', '222', '333', '222', '20010131', '99991231', 'Cagliari', 'SOURCE3',
        -11101, -11102, 0, TO_DATE('2022-01-01', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'));

insert into prt_parties_tags(pkid, party_id, tag_id, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-1110401, -111, -4, TO_DATE('2022-01-01', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);
--



