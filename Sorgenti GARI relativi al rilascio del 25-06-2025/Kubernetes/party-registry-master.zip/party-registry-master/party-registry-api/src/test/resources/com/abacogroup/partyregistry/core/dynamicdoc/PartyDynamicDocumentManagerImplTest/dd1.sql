--liquibase formatted sql
--changeset realt:PartyDynamicDocumentManagerImplTest001


insert into doc_type
    (code, tenant_id, user_insert, user_delete, dt_insert, dt_delete)
select code, :test_tenant, :user_id, :user_id, TO_DATE('2022-01-01', 'YYYY-MM-DD'), TO_DATE('9999-12-31', 'YYYY-MM-DD')
from doc_type
where tenant_id = '*';


insert into doc_type_spec
(doc_type_id, version, description, definition, parent_id, user_insert, user_delete, dt_insert, dt_delete)
select (select dt2.id
        from doc_type dt1,
             doc_type dt2
        where dt1.code = dt2.code
          and dt1.tenant_id = '*'
          and dt2.tenant_id = :test_tenant
          and dt1.id = sp.doc_type_id) as doc_type_id,
       sp.version,
       sp.description,
       sp.definition,
       sp.parent_id,
       :user_id,
       :user_id,
       TO_DATE('2022-01-01', 'YYYY-MM-DD'),
       TO_DATE('9999-12-31', 'YYYY-MM-DD')
from doc_type_spec sp
where id in (select id from doc_type where tenant_id = '*');



INSERT INTO prt_parties (id, tenant_id)
VALUES (-1111, :test_tenant);

INSERT INTO prt_parties_detail (party_id, party_type, last_name, first_name, tax_code, vat_number,
                                birth_date, death_date, birth_municipality,
                                fk_address_residential, fl_archived, dt_insert, user_id_insert, dt_delete)
VALUES (-1111, 'N', 'REALT', 'DEMO', '000', '111', '20010131', '20300131', 'Verona',
        null, 0, TO_DATE('2022-01-01', 'YYYY-MM-DD'), 'test_insert', TO_DATE('9999-12-31', 'YYYY-MM-DD'));
