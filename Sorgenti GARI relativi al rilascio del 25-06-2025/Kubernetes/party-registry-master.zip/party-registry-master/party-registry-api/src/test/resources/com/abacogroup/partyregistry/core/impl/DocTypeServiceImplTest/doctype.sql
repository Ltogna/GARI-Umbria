/*
 I18N DOC_TYPE
*/
INSERT INTO prt_i18n_values (tenant_id, table_name, field_name, i18n_value, lang, i18n_text)
VALUES (:test_tenant, 'prt_doc_type', 'doc_type', 'BANK', 'en', '-');
INSERT INTO prt_i18n_values (tenant_id, table_name, field_name, i18n_value, lang, i18n_text)
VALUES (:test_tenant, 'prt_doc_type', 'doc_type', 'EARNINGS', 'en', '-');
INSERT INTO prt_i18n_values (tenant_id, table_name, field_name, i18n_value, lang, i18n_text)
VALUES (:test_tenant, 'prt_doc_type', 'doc_type', 'EINVOICING', 'en', '-');
INSERT INTO prt_i18n_values (tenant_id, table_name, field_name, i18n_value, lang, i18n_text)
VALUES (:test_tenant, 'prt_doc_type', 'doc_type', 'ID', 'en', '-');

/* I18N DOC_GROUP */
INSERT INTO prt_i18n_values (tenant_id, table_name, field_name, i18n_value, lang, i18n_text)
VALUES (:test_tenant, 'prt_doc_type', 'doc_group', 'finanziaria', 'en', '-');

INSERT INTO prt_i18n_values (tenant_id, table_name, field_name, i18n_value, lang, i18n_text)
VALUES (:test_tenant, 'prt_doc_type', 'doc_group', 'commercial', 'en', '-');

insert into prt_i18n_values (tenant_id, table_name, field_name, i18n_value, lang, i18n_text)
select tenant_id, table_name, field_name, i18n_value, 'it', i18n_text
from prt_i18n_values
where tenant_id = :test_tenant
  and lang = 'en';

update prt_i18n_values
set i18n_text = lower(i18n_value) || '_' || lang
where tenant_id = :test_tenant;
