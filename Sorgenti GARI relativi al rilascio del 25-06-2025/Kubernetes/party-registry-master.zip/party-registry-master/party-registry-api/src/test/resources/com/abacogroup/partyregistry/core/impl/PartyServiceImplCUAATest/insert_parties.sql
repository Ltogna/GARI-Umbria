--liquibase formatted sql

INSERT INTO prt_parties (id, tenant_id)
VALUES (-666, :test_tenant);

INSERT INTO prt_parties (id, tenant_id)
VALUES (-555, :test_tenant);


INSERT INTO prt_parties_detail (party_id, party_type, last_name, first_name, code,
                                birth_date, death_date, birth_municipality,
                                fk_address_residential, fl_archived, dt_insert, user_id_insert, dt_delete)
VALUES (-666, 'N', 'REALT', 'DEMO', 'PNLCR120', '20010131', '99991231', 'Verona',
        null, 0, TO_DATE('2022-01-01', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'));
INSERT INTO prt_parties_detail (party_id, party_type, last_name, first_name, code,
                                birth_date, death_date, birth_municipality,
                                fk_address_residential, fl_archived, dt_insert, user_id_insert, dt_delete)
VALUES (-555, 'N', 'DEMO_COMPANY', 'SPA', 'VRKCL140', '20010131', '99991231', 'Milano',
        null, 0, TO_DATE('2022-01-01', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'));

