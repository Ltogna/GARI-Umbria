--liquibase formatted sql
--changeset realt:RelationTypeDAOTest001

INSERT INTO prt_relation_types
    (id, tenant_id, code, fl_multiple, dt_insert, user_id_insert, dt_delete, user_id_delete)
VALUES (-778, 'my778Tenant', 'AZIENDA778', 1, TO_DATE('2022-05-11', 'YYYY-MM-DD'), :user_id,
        TO_DATE('2022-05-12', 'YYYY-MM-DD'), 'test_delete');

INSERT INTO prt_relation_types
    (id, tenant_id, code, fl_multiple, dt_insert, user_id_insert, dt_delete, user_id_delete)
VALUES (-779, 'my779Tenant', 'AZIENDA779', 1, TO_DATE('2022-05-11', 'YYYY-MM-DD'), :user_id,
        TO_DATE('9999-12-31', 'YYYY-MM-DD'), :user_id);
