INSERT INTO prt_parties (id, tenant_id)
VALUES (-1, :test_tenant);

INSERT INTO prt_parties_detail
(pkid, party_id, party_type, gender, last_name, first_name, tax_code, vat_number, death_date, fk_address_residential, fk_address_home,
 fk_address_billing, fl_archived, dt_insert, user_id_insert, dt_delete, user_id_delete)
VALUES (-1, -1, 'N', NULL, 'LEFT', 'LEFT', '000', '111', '99991231', NULL, NULL, NULL, 0,
        TO_DATE('2022-01-01', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), NULL);


INSERT INTO prt_parties (id, tenant_id)
VALUES (-2, :test_tenant);

INSERT INTO prt_parties_detail
(pkid, party_id, party_type, gender, last_name, first_name, tax_code, vat_number, death_date, fk_address_residential, fk_address_home,
 fk_address_billing, fl_archived, dt_insert, user_id_insert, dt_delete, user_id_delete)
VALUES (-2, -2, 'N', NULL, 'RIGHT', 'RIGHT', '000', '111', '99991231', NULL, NULL, NULL, 0,
        TO_DATE('2022-01-01', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), NULL);



INSERT INTO prt_relation_types
    (id, tenant_id, code, fl_multiple, dt_insert, user_id_insert, dt_delete, user_id_delete)
VALUES (-200, :test_tenant, 'DELETED_TYPE_', 1, TO_DATE('2022-01-01', 'YYYY-MM-DD'), :user_id,
        TO_DATE('2022-04-01', 'YYYY-MM-DD'),
        :user_id);

INSERT INTO prt_relation_types
    (id, tenant_id, code, fl_multiple, dt_insert, user_id_insert, dt_delete, user_id_delete)
VALUES (-100, :test_tenant, 'OK_REL', 1,
        TO_DATE('2022-01-01', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);



INSERT INTO prt_relation_roles
    (id, type_id, code, dt_insert, user_id_insert, dt_delete, user_id_delete)
VALUES (-201, -200, 'DELETED_ROLE',
        TO_DATE('2022-05-11', 'YYYY-MM-DD'), :user_id, TO_DATE('2022-01-02', 'YYYY-MM-DD'), :user_id);

INSERT INTO prt_relation_roles
    (id, type_id, code, dt_insert, user_id_insert, dt_delete, user_id_delete)
VALUES (-202, -200, 'NOT_DELETED',
        TO_DATE('2022-01-01', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);

INSERT INTO prt_relation_roles (id, type_id, code, dt_insert, user_id_insert, dt_delete, user_id_delete)
VALUES (-301, -100, 'SORELLA',
        TO_DATE('2022-01-01', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);

INSERT INTO prt_relation_roles (id, type_id, code, dt_insert, user_id_insert, dt_delete, user_id_delete)
VALUES (-302, -100, 'GONE_TYPE',
        TO_DATE('2022-01-01', 'YYYY-MM-DD'), :user_id, TO_DATE('2022-01-01', 'YYYY-MM-DD'), :user_id);


--left ha una rel di tipo 200 (scaduta)
INSERT INTO prt_party_relations
    (id, party_id, relation_type_id, dt_insert, user_id_insert, dt_delete, user_id_delete)
VALUES (-401, -1, -200,
        TO_DATE('2022-01-01', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);

--left ha una rel di tipo 100 (valida)
INSERT INTO prt_party_relations (id, party_id, relation_type_id, dt_insert, user_id_insert, dt_delete)
VALUES (-402, -1, -100,
        TO_DATE('2022-01-01', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'));



INSERT INTO prt_party_relation_parties
(pkid, party_relation_id, party_id, relation_role_id, dt_start, dt_end, dt_insert, user_id_insert, dt_delete, user_id_delete)
VALUES (-501, -402, -2, -301, '20220101', '99991231',
        TO_DATE('2022-01-01', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);
