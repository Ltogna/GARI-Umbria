INSERT INTO prt_parties
    (id, tenant_id)
VALUES (-1, :test_tenant);


INSERT INTO prt_parties_detail
(pkid, party_id, party_type, last_name, first_name, fl_archived, dt_insert, user_id_insert, dt_delete, user_id_delete, source_code)
VALUES (-1, -1, 'N', 'REALT', 'SUPER_DEMO', 0,
        TO_DATE('2022-01-01', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), NULL, 'PAYMENT');


