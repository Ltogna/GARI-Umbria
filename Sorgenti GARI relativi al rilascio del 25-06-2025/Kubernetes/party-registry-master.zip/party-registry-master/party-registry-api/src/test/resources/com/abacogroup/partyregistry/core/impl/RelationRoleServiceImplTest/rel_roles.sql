--liquibase formatted sql
--changeset realt:RelationRoleServiceImplTest002

insert into prt_i18n_values (tenant_id, table_name, field_name, i18n_value, lang, i18n_text)
values (:test_tenant, 'prt_relation_types', 'code', 'ASSETTI_SOCIETARI', 'en', '-');
insert into prt_i18n_values (tenant_id, table_name, field_name, i18n_value, lang, i18n_text)
values (:test_tenant, 'prt_relation_types', 'code', 'RIFERIMENTI_CONTATTI', 'en', '-');
insert into prt_i18n_values (tenant_id, table_name, field_name, i18n_value, lang, i18n_text)
values (:test_tenant, 'prt_relation_types', 'code', 'NUCLEO_DEL_CONDUTTORE', 'en', '-');
insert into prt_i18n_values (tenant_id, table_name, field_name, i18n_value, lang, i18n_text)
values (:test_tenant, 'prt_relation_types', 'code', 'NUCLEO_FAMILIARE', 'en', '-');
insert into prt_i18n_values (tenant_id, table_name, field_name, i18n_value, lang, i18n_text)
values (:test_tenant, 'prt_relation_types', 'code', 'AZIENDA', 'en', '-');


insert into prt_i18n_values (tenant_id, table_name, field_name, i18n_value, lang, i18n_text)
values (:test_tenant, 'prt_relation_roles', 'code', 'MOGLIE', 'en', '-');
insert into prt_i18n_values (tenant_id, table_name, field_name, i18n_value, lang, i18n_text)
values (:test_tenant, 'prt_relation_roles', 'code', 'MOGLIE_A_CARICO', 'en', '-');
insert into prt_i18n_values (tenant_id, table_name, field_name, i18n_value, lang, i18n_text)
values (:test_tenant, 'prt_relation_roles', 'code', 'MARITO', 'en', '-');
insert into prt_i18n_values (tenant_id, table_name, field_name, i18n_value, lang, i18n_text)
values (:test_tenant, 'prt_relation_roles', 'code', 'MARITO_A_CARICO', 'en', '-');
insert into prt_i18n_values (tenant_id, table_name, field_name, i18n_value, lang, i18n_text)
values (:test_tenant, 'prt_relation_roles', 'code', 'ALTRO', 'en', '-');
insert into prt_i18n_values (tenant_id, table_name, field_name, i18n_value, lang, i18n_text)
values (:test_tenant, 'prt_relation_roles', 'code', 'ALTRO_A_CARICO', 'en', '-');
insert into prt_i18n_values (tenant_id, table_name, field_name, i18n_value, lang, i18n_text)
values (:test_tenant, 'prt_relation_roles', 'code', 'CONTATTO_AMMINISTRATIVO', 'en', '-');
insert into prt_i18n_values (tenant_id, table_name, field_name, i18n_value, lang, i18n_text)
values (:test_tenant, 'prt_relation_roles', 'code', 'CONTATTO_TECNICO', 'en', '-');
insert into prt_i18n_values (tenant_id, table_name, field_name, i18n_value, lang, i18n_text)
values (:test_tenant, 'prt_relation_roles', 'code', 'RAPPRESENTANTE_LEGALE', 'en', '-');
insert into prt_i18n_values (tenant_id, table_name, field_name, i18n_value, lang, i18n_text)
values (:test_tenant, 'prt_relation_roles', 'code', 'RAPPRESENTANTE_DI_MINORE', 'en', '-');
insert into prt_i18n_values (tenant_id, table_name, field_name, i18n_value, lang, i18n_text)
values (:test_tenant, 'prt_relation_roles', 'code', 'CURATORE_FALLIMENTARE', 'en', '-');
insert into prt_i18n_values (tenant_id, table_name, field_name, i18n_value, lang, i18n_text)
values (:test_tenant, 'prt_relation_roles', 'code', 'FRATELLO', 'en', '-');
insert into prt_i18n_values (tenant_id, table_name, field_name, i18n_value, lang, i18n_text)
values (:test_tenant, 'prt_relation_roles', 'code', 'SORELLA', 'en', '-');
insert into prt_i18n_values (tenant_id, table_name, field_name, i18n_value, lang, i18n_text)
values (:test_tenant, 'prt_relation_roles', 'code', 'SORELLASTRA', 'en', '-');


insert into prt_i18n_values (tenant_id, table_name, field_name, i18n_value, lang, i18n_text)
select tenant_id, table_name, field_name, i18n_value, 'it', i18n_text
from prt_i18n_values
where tenant_id = :test_tenant and lang = 'en';

update prt_i18n_values
set i18n_text = lower(i18n_value) || '_' || lang
where tenant_id = :test_tenant;



insert into prt_relation_types (id, tenant_id, code, fl_multiple, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-101, :test_tenant, 'ASSETTI_SOCIETARI', 1,
        TO_DATE('2022-01-01', 'YYYY-MM-DD'), :user_id, TO_DATE('2022-04-01', 'YYYY-MM-DD'),
        :user_id);
insert into prt_relation_types (id, tenant_id, code, fl_multiple, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-111, :test_tenant, 'RIFERIMENTI_CONTATTI', 0,
        TO_DATE('2022-05-11', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'),
        :user_id);
insert into prt_relation_types (id, tenant_id, code, fl_multiple, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-121, :test_tenant, 'NUCLEO_DEL_CONDUTTORE', 1,
        TO_DATE('2022-05-11', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), :user_id);


insert into prt_relation_types (id, tenant_id, code, fl_multiple, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-131, :test_tenant, 'NUCLEO_FAMILIARE', 1,
        TO_DATE('2022-05-11', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), :user_id);


insert into prt_relation_types (id, tenant_id, code, fl_multiple, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-141, :test_tenant, 'AZIENDA', 1,
        TO_DATE('2022-05-11', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), :user_id);



insert into prt_relation_roles (id, type_id, code, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-111, -131, 'MOGLIE', TO_DATE('2022-05-11', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), :user_id);
insert into prt_relation_roles (id, type_id, code, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-112, -131, 'MOGLIE_A_CARICO', TO_DATE('2022-05-11', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'),
        :user_id);
insert into prt_relation_roles (id, type_id, code, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-113, -131, 'MARITO', TO_DATE('2022-05-11', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), :user_id);
insert into prt_relation_roles (id, type_id, code, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-114, -131, 'MARITO_A_CARICO', TO_DATE('2022-05-11', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'),
        :user_id);
insert into prt_relation_roles (id, type_id, code, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-115, -131, 'ALTRO', TO_DATE('2022-05-11', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), :user_id);
insert into prt_relation_roles (id, type_id, code, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-116, -131, 'ALTRO_A_CARICO', TO_DATE('2022-05-11', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'),
        :user_id);
insert into prt_relation_roles (id, type_id, code, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-117, -111, 'CONTATTO_AMMINISTRATIVO', TO_DATE('2022-05-11', 'YYYY-MM-DD'), :user_id,
        to_dATE('9999-12-31', 'YYYY-MM-DD'),
        :user_id);
insert into prt_relation_roles (id, type_id, code, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-118, -111, 'CONTATTO_TECNICO', TO_DATE('2022-05-11', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'),
        :user_id);
insert into prt_relation_roles (id, type_id, code, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-119, -141, 'MARITO', TO_DATE('2022-01-01', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), :user_id);
insert into prt_relation_roles (id, type_id, code, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-120, -111, 'RAPPRESENTANTE_LEGALE', TO_DATE('2022-01-01', 'YYYY-MM-DD'), :user_id,
        to_dATE('9999-12-31', 'YYYY-MM-DD'),
        :user_id);
insert into prt_relation_roles (id, type_id, code, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-121, -111, 'RAPPRESENTANTE_DI_MINORE', TO_DATE('2022-01-01', 'YYYY-MM-DD'), :user_id,
        to_dATE('9999-12-31', 'YYYY-MM-DD'),
        :user_id);
insert into prt_relation_roles (id, type_id, code, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-122, -111, 'CURATORE_FALLIMENTARE', TO_DATE('2022-01-01', 'YYYY-MM-DD'), :user_id,
        to_dATE('9999-12-31', 'YYYY-MM-DD'),
        :user_id);
insert into prt_relation_roles (id, type_id, code, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-123, -141, 'FRATELLO', TO_DATE('2022-01-01', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'),
        :user_id);
insert into prt_relation_roles (id, type_id, code, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-124, -141, 'SORELLA', TO_DATE('2022-01-01', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'),
        :user_id);
insert into prt_relation_roles (id, type_id, code, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-125, -141, 'SORELLASTRA', TO_DATE('2022-01-01', 'YYYY-MM-DD'), :user_id, TO_DATE('2022-01-02', 'YYYY-MM-DD'),
        :user_id);


