--liquibase formatted sql
--changeset realt:RelationTypeServiceImplTest002

INSERT INTO prt_relation_types (id, tenant_id, code, fl_multiple, dt_insert, user_id_insert, dt_delete, user_id_delete)
VALUES (-1000, :test_tenant, 'ASSETTI_SOCIETARI', 1, TO_DATE('2022-01-01', 'YYYY-MM-DD'), :user_id,
        TO_DATE('2022-04-01', 'YYYY-MM-DD'),
        'testuser');
INSERT INTO prt_relation_types (id, tenant_id, code, fl_multiple, dt_insert, user_id_insert, dt_delete, user_id_delete)
VALUES (-1001, :test_tenant, 'RIFERIMENTI_CONTATTI', 0, TO_DATE('2022-05-11', 'YYYY-MM-DD'), :user_id,
        TO_DATE('9999-12-31', 'YYYY-MM-DD'),
        :user_id);
INSERT INTO prt_relation_types (id, tenant_id, code, fl_multiple, dt_insert, user_id_insert, dt_delete, user_id_delete)
VALUES (-1002, :test_tenant, 'NUCLEO_DEL_CONDUTTORE', 1, TO_DATE('2022-05-11', 'YYYY-MM-DD'), :user_id,
        TO_DATE('9999-12-31', 'YYYY-MM-DD'),
        :user_id);
INSERT INTO prt_relation_types (id, tenant_id, code, fl_multiple, dt_insert, user_id_insert, dt_delete, user_id_delete)
VALUES (-1003, :test_tenant, 'NUCLEO_FAMILIARE', 1, TO_DATE('2022-05-11', 'YYYY-MM-DD'), :user_id,
        TO_DATE('9999-12-31', 'YYYY-MM-DD'),
        :user_id);
INSERT INTO prt_relation_types (id, tenant_id, code, fl_multiple, dt_insert, user_id_insert, dt_delete, user_id_delete)
VALUES (-1004, :test_tenant, 'AZIENDA', 1, TO_DATE('2022-05-11', 'YYYY-MM-DD'), 'test_insert', TO_DATE('9999-12-31', 'YYYY-MM-DD'),
        :user_id);

/*
 I18N
*/
INSERT INTO prt_i18n_values (tenant_id, table_name, field_name, i18n_value, lang, i18n_text)
VALUES (:test_tenant, 'prt_relation_types', 'code', 'ASSETTI_SOCIETARI', 'en', '-');
INSERT INTO prt_i18n_values (tenant_id, table_name, field_name, i18n_value, lang, i18n_text)
VALUES (:test_tenant, 'prt_relation_types', 'code', 'RIFERIMENTI_CONTATTI', 'en', '-');
INSERT INTO prt_i18n_values (tenant_id, table_name, field_name, i18n_value, lang, i18n_text)
VALUES (:test_tenant, 'prt_relation_types', 'code', 'NUCLEO_DEL_CONDUTTORE', 'en', '-');
INSERT INTO prt_i18n_values (tenant_id, table_name, field_name, i18n_value, lang, i18n_text)
VALUES (:test_tenant, 'prt_relation_types', 'code', 'NUCLEO_FAMILIARE', 'en', '-');
INSERT INTO prt_i18n_values (tenant_id, table_name, field_name, i18n_value, lang, i18n_text)
VALUES (:test_tenant, 'prt_relation_types', 'code', 'AZIENDA', 'en', '-');


insert into prt_i18n_values (tenant_id, table_name, field_name, i18n_value, lang, i18n_text)
select tenant_id, table_name, field_name, i18n_value, 'it', i18n_text
from prt_i18n_values
where tenant_id = :test_tenant
  and lang = 'en';

update prt_i18n_values
set i18n_text = lower(i18n_value) || '_' || lang
where tenant_id = :test_tenant;
