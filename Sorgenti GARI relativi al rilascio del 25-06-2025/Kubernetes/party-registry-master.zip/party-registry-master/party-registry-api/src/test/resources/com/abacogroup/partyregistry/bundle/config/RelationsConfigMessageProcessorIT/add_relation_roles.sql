---   Relation roles ---

insert into prt_relation_roles (id, type_id, code, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-24, -11, 'RAPPRESENTANTE_DI_MINORE', TO_DATE('2022-01-01', 'YYYY-MM-DD'), :user_id,
        to_dATE('9999-12-31', 'YYYY-MM-DD'), null);
insert into prt_relation_roles (id, type_id, code, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-25, -11, 'CONTROLLATA', TO_DATE('2022-01-01', 'YYYY-MM-DD'), :user_id,
        to_dATE('9999-12-31', 'YYYY-MM-DD'),
        null);

insert into prt_relation_roles (id, type_id, code, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-22, -12, 'MOGLIE', TO_DATE('2022-05-11', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), :user_id);
insert into prt_relation_roles (id, type_id, code, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-23, -12, 'MOGLIE_A_CARICO', TO_DATE('2022-05-11', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'),
        null);

insert into prt_relation_roles (id, type_id, code, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-26, -13, 'FRATELLO', TO_DATE('2022-01-01', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'),
        null);
insert into prt_relation_roles (id, type_id, code, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-27, -13, 'SORELLA', TO_DATE('2022-01-01', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'),
        null);
