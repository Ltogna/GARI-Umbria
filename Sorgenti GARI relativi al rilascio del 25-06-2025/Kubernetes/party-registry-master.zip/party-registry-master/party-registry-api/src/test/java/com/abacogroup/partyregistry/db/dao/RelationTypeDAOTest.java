package com.abacogroup.partyregistry.db.dao;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;

import com.abacogroup.partyregistry.JdbiTest;
import com.abacogroup.partyregistry.db.ntt.RelationTypeEntity;
import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

@ExtendWith(DropwizardExtensionsSupport.class)
public class RelationTypeDAOTest extends JdbiTest {

	private static final String tenantId = "RelationTypeDAOTest_t";
	private static final String userId = "RelationTypeDAOTest_u";

	private static final Map<String, Object> testScriptParams = Map.of(
			"test_tenant", tenantId,
			"user_id", userId
	);

	private final RelationTypeDAO dao = getDAO(RelationTypeDAO.class);

	@Test
	void test_find_one_include_deleted() {

		getJdbi().useHandle(handle -> {
			handle.begin();

			List<String> initScripts = List.of("add_relation_types");
			execSqlFiles(this.getClass(), initScripts, testScriptParams);

			String tenantId1 = "my778Tenant";
			String code1 = "AZIENDA778";

			Optional<RelationTypeEntity> result = dao.findOneIncludeDeleted(tenantId1, code1);
			assertThat(result.isPresent(), is(true));
			assertThat(result.get().getTenantId(), is(tenantId1));
			assertThat(result.get().getCode(), is(code1));

			String tenantId2 = "my779Tenant";
			String code2 = "AZIENDA779";

			Optional<RelationTypeEntity> result2 = dao.findOneIncludeDeleted(tenantId2, code2);
			assertThat(result2.isPresent(), is(true));
			assertThat(result2.get().getTenantId(), is(tenantId2));
			assertThat(result2.get().getCode(), is(code2));

			handle.rollback();
		});

	}

	@Test
	void test_find_one() {

		getJdbi().useHandle(handle -> {
			handle.begin();

			List<String> initScripts = List.of("add_relation_types");
			execSqlFiles(this.getClass(), initScripts, testScriptParams);

			String tenantId = "my779Tenant";
			String code = "AZIENDA779";

			Optional<RelationTypeEntity> result = dao.findOne(tenantId, code);
			assertThat(result.isPresent(), is(true));
			assertThat(result.get().getTenantId(), is(tenantId));
			assertThat(result.get().getCode(), is(code));

			handle.rollback();
		});

	}

	@Test
	void test_find_one_not_found_expired() {
		String tenantId1 = "my778Tenant";
		String code1 = "AZIENDA778";

		Optional<RelationTypeEntity> result = dao.findOne(tenantId1, code1);
		assertThat(result.isPresent(), is(false));
	}

}
