package com.abacogroup.partyregistry.resources;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.containsInAnyOrder;

import com.abacogroup.jdbi.paging.impl.InfiniteListResultsImpl;
import com.abacogroup.partyregistry.PrtTest;
import com.abacogroup.partyregistry.api.PartyRes;
import com.abacogroup.partyregistry.api.v1.req.PartySearchRequestV1;
import com.abacogroup.partyregistry.core.AclService;
import com.abacogroup.partyregistry.core.ExternalSourceService;
import com.abacogroup.partyregistry.core.PartyService;
import com.abacogroup.partyregistry.core.impl.PartyServiceImpl;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;
import io.dropwizard.testing.junit5.ResourceExtension;
import jakarta.ws.rs.ClientErrorException;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.Mockito;

@Slf4j
@ExtendWith(DropwizardExtensionsSupport.class)
class PartyResourceValidationTest {

	private final AclService aclService = Mockito.mock(AclService.class);
	private final PartyService partyService = Mockito.mock(PartyServiceImpl.class);
	private final ExternalSourceService externalSourceService = Mockito.mock(ExternalSourceService.class);

	private final ResourceExtension EXT = WebCliHelper.createEXT(new PartyResource(aclService, partyService, externalSourceService));

	private ObjectMapper mapper = new ObjectMapper();

	protected static Stream<Arguments> test_validate_party_insert() {
		return Stream.of(
				Arguments.of("empty_req", new PartyRes()
						, List.of("partyType", "lastName"))

				, Arguments.of("test1", new PartyRes()
						, List.of("partyType", "lastName"))

				, Arguments.of("test2", new PartyRes()
						, List.of("partyType", "lastName"))

				, Arguments.of("empty_req", new PartyRes()
						, List.of("partyType", "lastName"))

				, Arguments.of("empty_req", new PartyRes()
						, List.of("partyType", "lastName"))

		);
	}

	protected static Stream<Arguments> test_validate_partyReq_search() {
		return Stream.of(
				Arguments.of("empty_req", new PartySearchRequestV1()
						, List.of("INVALID_PAYLOAD"))
				, Arguments.of("valid", new PartySearchRequestV1().setFirstName("ste")
						, List.of())
		);
	}

	@ParameterizedTest
	@MethodSource
	void test_validate_party_insert(String ignoredTitle, PartyRes party, List<String> expErrors) {

		String path = String.format(PrtTest.MASTER_PATH + "/parties");
		ClientErrorException ex = Assertions.assertThrows(ClientErrorException.class, () -> {
			WebCliHelper.executePost(EXT, path, party, WebCliHelper.BASIC_CREDENTIALS, String.class);
		});
		List<String> errors = extractErrorFieldNames(ex);
		assertThat(errors, containsInAnyOrder(expErrors.toArray()));
	}

	@ParameterizedTest
	@MethodSource
	void test_validate_partyReq_search(String ignoredTitle, PartySearchRequestV1 partySearchReq, List<String> expErrors) {
		String path = String.format(PrtTest.MASTER_PATH + "/parties");
		Map<String, Object> beanMap = mapper.convertValue(partySearchReq, Map.class);

		if (expErrors.isEmpty()) {
			WebCliHelper.executeGet(EXT, path, beanMap, WebCliHelper.BASIC_CREDENTIALS, InfiniteListResultsImpl.class);
			return;
		}

		ClientErrorException ex = Assertions.assertThrows(ClientErrorException.class, () -> {
			WebCliHelper.executeGet(EXT, path, beanMap, WebCliHelper.BASIC_CREDENTIALS, InfiniteListResultsImpl.class);
		});

		List<String> errors = extractErrorFieldNames(ex);
		assertThat(errors, containsInAnyOrder(expErrors.toArray()));
	}

	@SuppressWarnings("unchecked")
	private List<String> extractErrorFieldNames(ClientErrorException ex) {
		Map<String, Object> responseMap = ex.getResponse().readEntity(Map.class);
		if (responseMap.containsKey("errors")) {
			//constraints...
			List<String> list = (List<String>) responseMap.get("errors");
			return list
					.stream()
					.map(msg -> List.of(msg.split(" ")))
					.map(tokens -> tokens.get(0))
					.collect(Collectors.toList());
		} else if (responseMap.containsKey("errorCode")) {
			return List.of((String) responseMap.get("errorCode"));
		}
		throw new UnsupportedOperationException("response inattesa");
	}

}
