package com.abacogroup.partyregistry.core.impl;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.containsInAnyOrder;
import static org.junit.jupiter.api.Assertions.assertTrue;

import com.abacogroup.partyregistry.JdbiTest;
import com.abacogroup.partyregistry.PrtTest;
import com.abacogroup.partyregistry.api.RelationType;
import com.abacogroup.partyregistry.core.RelationTypeService;
import com.abacogroup.partyregistry.db.dao.RelationRoleDAO;
import com.abacogroup.partyregistry.db.dao.RelationTypeDAO;
import com.abacogroup.partyregistry.resources.req.RelationTypeSearchReq;
import com.abacogroup.partyregistry.resources.req.ReqContext;
import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;

@Slf4j
@ExtendWith(DropwizardExtensionsSupport.class)
class RelationTypeServiceImplTest extends JdbiTest {

	private static final String currentUser = "RelationTypeServiceImplTest_u";
	private static final String tenantId = "RelationTypeServiceImplTest_t";

	private static final Map<String, Object> testScriptParams = Map.of(
			"test_tenant", tenantId,
			"user_id", currentUser
	);

	private static final ReqContext reqContext =
			new ReqContext(tenantId, currentUser, "en");

	private final RelationTypeService service = new RelationTypeServiceImpl(getDAO(RelationTypeDAO.class));
	private final RelationRoleDAO roleDAO = getDAO(RelationRoleDAO.class);

	@BeforeAll
	@AfterAll
	public static void beforeAll() {
		List<String> initScripts = List.of("rollback");
		execSqlFiles(PrtTest.class, initScripts, testScriptParams);
	}

	@ParameterizedTest
	@MethodSource
	public void test_search(String ignoredTitle, RelationTypeSearchReq request, List<Long> results) {
		setUnusedBindingAllowed(true);
		getJdbi().useHandle(handle -> {
			handle.begin();

			List<String> initScripts = List.of("rel_types");
			execSqlFiles(this.getClass(), initScripts, testScriptParams);

			List<RelationType> list = this.service
					.search(reqContext, request, null)
					.getRecords();
			List<String> actual = list.stream()
					.map(RelationType::getCode)
					.collect(Collectors.toList());
			assertThat(actual, containsInAnyOrder(results.toArray()));

			handle.rollback();
		});

	}

	private static Stream<Arguments> test_search() {
		return Stream.of(
				Arguments.of("just_tenant", new RelationTypeSearchReq()
						, List.of("AZIENDA", "NUCLEO_DEL_CONDUTTORE", "NUCLEO_FAMILIARE", "RIFERIMENTI_CONTATTI"))

				, Arguments.of("by_code", new RelationTypeSearchReq()
								.setCode("NUCLEO_FAMILIARE"),
						List.of("NUCLEO_FAMILIARE"))

				, Arguments.of("by_i18n", new RelationTypeSearchReq()
								.setI18nCode("nucleo_familiare_en"),
						List.of("NUCLEO_FAMILIARE"))
		);
	}

	@Test
	void test_getById() {

		setUnusedBindingAllowed(true);
		getJdbi().useHandle(handle -> {
			handle.begin();

			List<String> initScripts = List.of("rel_types");
			execSqlFiles(this.getClass(), initScripts, testScriptParams);

			RelationType relationType = this.service.getByCode(reqContext, "NUCLEO_FAMILIARE")
					.orElseThrow();
			assertThat(relationType.getCode(), is("NUCLEO_FAMILIARE"));

			Optional<RelationType> elapsed = this.service.getByCode(reqContext, "ASSETTI_SOCIETARI");
			assertThat(elapsed.isEmpty(), is(true));

			Optional<RelationType> invalid = this.service.getByCode(reqContext, "11111111");
			assertThat(invalid.isEmpty(), is(true));

			handle.rollback();
		});

	}

	@Test
	void test_getByCode() {

		setUnusedBindingAllowed(true);
		getJdbi().useHandle(handle -> {
			handle.begin();

			List<String> initScripts = List.of("rel_types");
			execSqlFiles(this.getClass(), initScripts, testScriptParams);

			RelationType relationType = this.service.getByCode(reqContext, "NUCLEO_FAMILIARE").orElseThrow();
			assertThat(relationType.getCode(), is("NUCLEO_FAMILIARE"));
			assertThat(relationType.getI18nCode(), is("NUCLEO_FAMILIARE_en".toLowerCase()));

			Optional<RelationType> elapsed = this.service.getByCode(reqContext, "ASSETTI_SOCIETARI");
			assertThat("is elapsed", elapsed.isEmpty(), is(true));

			handle.rollback();
		});

	}

	@Test
	void test_delete_type_in_cascade() {

		setUnusedBindingAllowed(true);
		getJdbi().useHandle(handle -> {
			handle.begin();

			List<String> initScripts = List.of("rel_types", "rel_roles");
			execSqlFiles(this.getClass(), initScripts, testScriptParams);

			assertTrue(service.findActiveEntityByCode(tenantId, "NUCLEO_FAMILIARE").isPresent());

			assertThat(roleDAO.countAll(tenantId), is(3L));
			assertThat(roleDAO.findByTypeCode(tenantId, "NUCLEO_FAMILIARE").size(), is(3));

			service.expireInCascade(tenantId, "NUCLEO_FAMILIARE");

			assertTrue(service.findActiveEntityByCode(tenantId, "NUCLEO_FAMILIARE").isEmpty());
			assertThat(roleDAO.findByTypeCode(tenantId, "NUCLEO_FAMILIARE").size(), is(0));

			handle.rollback();
		});

	}
}
