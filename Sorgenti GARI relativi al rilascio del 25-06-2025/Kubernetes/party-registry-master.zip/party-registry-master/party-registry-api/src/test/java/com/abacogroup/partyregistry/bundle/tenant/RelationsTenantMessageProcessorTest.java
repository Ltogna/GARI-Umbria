package com.abacogroup.partyregistry.bundle.tenant;

import static com.abacogroup.bundles.Constants.ALL_TENANTS;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.greaterThan;

import com.abacogroup.bundles.listener.tenant.TenantMessage;
import com.abacogroup.partyregistry.JdbiTest;
import com.abacogroup.partyregistry.db.dao.RelationRoleDAO;
import com.abacogroup.partyregistry.db.dao.RelationTypeDAO;
import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;
import org.hamcrest.CoreMatchers;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

@ExtendWith(DropwizardExtensionsSupport.class)
class RelationsTenantMessageProcessorTest extends JdbiTest {

	private final RelationsTenantMessageProcessor processor = getService(RelationsTenantMessageProcessor.class);

	@Test
	public void testOnMessage() {
		RelationTypeDAO relationTypeDAO = getDAO(RelationTypeDAO.class);
		RelationRoleDAO relationRoleDAO = getDAO(RelationRoleDAO.class);

		long types = relationTypeDAO.countAll(ALL_TENANTS);
		long roles = relationRoleDAO.countAll(ALL_TENANTS);
		assertThat(types, greaterThan(0L));
		assertThat(roles, greaterThan(0L));

		getJdbi().useHandle(handle -> {
			handle.begin();
			String newTenant = "tnt";

			processor.onMessage(new TenantMessage()
					.setTenantId(newTenant));

			assertThat(relationTypeDAO.countAll(newTenant), CoreMatchers.is(types));
			assertThat(relationRoleDAO.countAll(newTenant), CoreMatchers.is(roles));
			handle.rollback();
		});
	}
}
