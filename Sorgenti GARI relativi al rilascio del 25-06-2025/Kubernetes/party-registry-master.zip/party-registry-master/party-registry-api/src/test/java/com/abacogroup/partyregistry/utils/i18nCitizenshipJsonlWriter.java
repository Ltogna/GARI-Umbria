package com.abacogroup.partyregistry.utils;

import com.abacogroup.bundles.initializer.impl.exceptions.BundleException;
import com.abacogroup.partyregistry.db.ntt.I18nEntity;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.validation.constraints.NotNull;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.SortedMap;
import java.util.TreeMap;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.SneakyThrows;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;

@Disabled

public class i18nCitizenshipJsonlWriter {

	//https://it.wikipedia.org/wiki/ISO_3166-1_alpha-3
	//https://en.wikipedia.org/wiki/ISO_3166-1_alpha-3
	public final Path I18N_JSONL_PATH = Paths.get("src/test/resources/bundles/standard/party-registry/prt-0001/i18n/i18n-citizenship.jsonl");
	public final Path I18N_TXT = Path.of("src/test/resources/com/abacogroup/partyregistry/utils/FileResourcesUtilsTest/i18n.txt");
	private final ObjectMapper mapper = new ObjectMapper().addMixIn(I18nEntity.class, I18nMixin.class);

	/**/
	@Test
	void writei18n() throws IOException {
		Files.write(
				I18N_JSONL_PATH,
				"".getBytes(),
				StandardOpenOption.TRUNCATE_EXISTING);

		try {
			Map<String, I18nCSV> map = this.readTxt();
			StringBuilder builder = new StringBuilder();

			for (Map.Entry<String, I18nCSV> entry : map.entrySet()) {
				I18nEntity it = mapEntity(entry.getValue(), "it");
				builder.append(mapper.writeValueAsString(it)).append(System.lineSeparator());
				I18nEntity en = mapEntity(entry.getValue(), "en");
				builder.append(mapper.writeValueAsString(en)).append(System.lineSeparator());
			}
			String buffer = builder.toString();
			try {
				Files.write(
						I18N_JSONL_PATH,
						(buffer).getBytes(),
						StandardOpenOption.APPEND);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		} catch (Exception e) {
			throw new BundleException(String.format("error saving file %s", I18N_JSONL_PATH), e);
		}

	}

	private I18nEntity mapEntity(I18nCSV csv, String lang) {
		I18nEntity i18n = new I18nEntity();
		i18n.setTableName("prt_citizenship");
		i18n.setFieldName("code");
		i18n.setI18nValue(csv.getCode());

		i18n.setLang(lang);
		if ("en".equals(lang)) {
			i18n.setI18nText(csv.getEn());
		}
		if ("it".equals(lang)) {
			i18n.setI18nText(csv.getIt());
		}
		return i18n;
	}

	@SneakyThrows
	protected SortedMap<String, I18nCSV> readTxt() {
		List<I18nCSV> list = new ArrayList<>();
		try (Stream<String> input = Files.lines(I18N_TXT, StandardCharsets.UTF_8)) {
			input.map(this::mapBean)
					.forEach(list::add);
		}
		Map<String, I18nCSV> unsorted = list.stream()
				.collect(Collectors.toMap(I18nCSV::getCode, Function.identity()));
		return new TreeMap<>(unsorted);
	}

	private I18nCSV mapBean(String x) {
		String[] vals = x.split("\\|");
		if (vals.length != 3) {
			System.out.println("");
		}
		return new I18nCSV(vals[0], vals[1], vals[2]);
	}

	@Data
	@AllArgsConstructor
	@NoArgsConstructor
	protected static class I18nCSV {
		String code;
		String en;
		String it;
	}

	private abstract static class I18nMixin {

		@JsonIgnore
		private String tenantId;

		@NotNull
		@JsonProperty("table_name")
		private String tableName;

		@NotNull
		@JsonProperty("field_name")
		private String fieldName;

		@NotNull
		@JsonProperty("i18n_value")
		private String i18nValue;

		@NotNull
		@JsonProperty("lang")
		private String lang;

		@NotNull
		@JsonProperty("i18n_text")
		private String i18nText;
	}
}
