package com.abacogroup.partyregistry.bundle.config;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.nio.file.Path;
import java.util.List;

import org.hamcrest.CoreMatchers;
import org.jdbi.v3.core.Jdbi;
import org.jdbi.v3.core.statement.UnableToExecuteStatementException;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

import com.abacogroup.bundles.initializer.impl.FileSupport;
import com.abacogroup.bundles.listener.configdata.ConfigDataMessage;
import com.abacogroup.partyregistry.JdbiTest;
import com.abacogroup.partyregistry.core.impl.TagServiceImpl;
import com.abacogroup.partyregistry.db.dao.I18nDAO;
import com.abacogroup.partyregistry.db.dao.TagDAO;
import com.abacogroup.partyregistry.resources.req.ReqContext;
import com.abacogroup.partyregistry.resources.req.TagSearchReq;

import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;

@ExtendWith(DropwizardExtensionsSupport.class)
public class TagConfigMessageProcessorTest extends JdbiTest {

	private final TagServiceImpl service = getService(TagServiceImpl.class);
	private final TagConfigMessageProcessor init = getService(TagConfigMessageProcessor.class);
	private final I18nDAO i18nDao = getJdbi().onDemand(I18nDAO.class);
	private final TagDAO tagDAO = getJdbi().onDemand(TagDAO.class);

	private void clearBundles() {

		Jdbi jdbi = getJdbi();
		jdbi.useTransaction(handle -> {
			handle.execute("delete from prt_tags where tenant_id = ? ", "tagBundleTenant");
			handle.execute("delete from bnd_registry where tenant_id = ? ", "tagBundleTenant");
		});
	}

	@Test
	public void testOnMessage() {
		String tenantId = "tagBundleTenant";
		List<Path> paths = FileSupport.listFilesRecursive(
				Path.of("src/test/resources/bundles/standard/party-registry/prt-0001/tags"));
		ConfigDataMessage msg = new ConfigDataMessage();
		msg.setConfigFiles(paths);
		msg.setTenantId(tenantId);

		getJdbi().useHandle(handle -> {
			handle.begin();

			init.onMessage(msg);

			assertThat(service.searchTags(
							new ReqContext(msg.getTenantId(), "user", "it"),
							new TagSearchReq(), null)
					.getCount(), is(2));

			String label = this.i18nDao.searchLabel(tenantId, "prt_tags", "code", "FORNITORE", "en");
			assertThat(label, CoreMatchers.is("Fornitore"));

			handle.commit();
		});

	}

	@Test
	public void test_givenSameMessageMultipleTimes_onMessage_thenIdempotent() {
		List<Path> paths = FileSupport.listFilesRecursive(
				Path.of("src/test/resources/bundles/standard/party-registry/prt-0001/tags"));
		ConfigDataMessage msg = new ConfigDataMessage();
		msg.setConfigFiles(paths);
		msg.setTenantId("tagBundleTenant");

		getJdbi().useHandle(handle -> {
			handle.begin();
			init.onMessage(msg);
			init.onMessage(msg);
			init.onMessage(msg);

			assertThat(service.searchTags(
							new ReqContext(msg.getTenantId(), "user", "it"),
							new TagSearchReq(), null)
					.getCount(), is(2));

			handle.rollback();
		});

	}

	
	@Test
	public void test_givenLanguageEs_whenSearchTags_thenReturnCode() {
		List<Path> paths = FileSupport.listFilesRecursive(
				Path.of("src/test/resources/bundles/standard/party-registry/prt-0001/tags"));
		ConfigDataMessage msg = new ConfigDataMessage();
		msg.setConfigFiles(paths);
		msg.setTenantId("tagBundleTenant");

	    getJdbi().useHandle(handle -> {
	        handle.begin();
	        init.onMessage(msg);

	        var result = service.searchTags(
	                new ReqContext(msg.getTenantId(), "user", "es"),
	                new TagSearchReq(), null);

	        assertThat(result.getCount(), is(2));
	        assertThat(result.getRecords().get(0).getCode(), CoreMatchers.is("FORNITORE"));
	        assertThat(result.getRecords().get(1).getCode(), CoreMatchers.is("INQUILINO"));

	        handle.rollback();
	    });
	}
	
	@Test
	public void test_givenLanguageIt_whenSearchTags_thenReturnTranslatedTag() {
		List<Path> paths = FileSupport.listFilesRecursive(
				Path.of("src/test/resources/bundles/standard/party-registry/prt-0001/tags"));
		ConfigDataMessage msg = new ConfigDataMessage();
		msg.setConfigFiles(paths);
		msg.setTenantId("tagBundleTenant");

	    getJdbi().useHandle(handle -> {
	        handle.begin();
	        init.onMessage(msg);

	        var result = service.searchTags(
	                new ReqContext(msg.getTenantId(), "user", "it"),
	                new TagSearchReq(), null);

	        assertThat(result.getCount(), is(2));
	        assertThat(result.getRecords().get(0).getI18nCode(), CoreMatchers.is("Fornitore"));
	        assertThat(result.getRecords().get(1).getI18nCode(), CoreMatchers.is("Inquilino"));

	        handle.rollback();
	    });
	}

	@Test
	void onMessage_delete() {

		List<Path> paths = FileSupport
				.listFilesRecursive(Path.of("src/test/resources/bundles/standard/party-registry/prt-0001/tags_to_del"));
		ConfigDataMessage msg = new ConfigDataMessage();
		msg.setConfigFiles(paths);
		msg.setTenantId("tagBundleTenant");

		getJdbi().useHandle(handle -> {
			handle.begin();
			init.onMessage(msg);

			var result = service.searchTags(new ReqContext(msg.getTenantId(), "user", "it"), new TagSearchReq(), null);
			assertThat(result.getCount(), is(1));

			handle.rollback();
		});

	}

	@Test
	void onMessage_delete_KO_foreingKey() {
		getJdbi().useHandle(handle -> {
			handle.begin();
			assertThrows(UnableToExecuteStatementException.class, () -> {
				this.tagDAO.deleteByTenantAndTag("*", "FORNITORE");
			});
			handle.rollback();
		});
	}
}
