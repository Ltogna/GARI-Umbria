package com.abacogroup.partyregistry.db.dao;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;

import com.abacogroup.partyregistry.JdbiTest;
import com.abacogroup.partyregistry.db.ntt.PartyRelationPartyEntity;
import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;
import java.util.List;
import java.util.Map;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

@ExtendWith(DropwizardExtensionsSupport.class)
class PartyRelationPartyDAOTest extends JdbiTest {

	private static final String tenantId = "PartyDAOTest_t";
	private static final String userId = "PartyDAOTest_u";
	private static final Map<String, Object> testScriptParams = Map.of(
			"test_tenant", tenantId,
			"user_id", userId
	);

	private final PartyRelationPartyDAO dao = getDAO(PartyRelationPartyDAO.class);

	@Test
	void test_findById() {

		getJdbi().useHandle(handle -> {
			handle.begin();

			List<String> initScripts = List.of("insert_deleted_relations");
			execSqlFiles(this.getClass(), initScripts, testScriptParams);

			PartyRelationPartyEntity x = dao.findById(tenantId, -1L, -402L, -501L).orElseThrow();
			assertThat(x.getPartyRelationId(), is(-402L));

			handle.rollback();
		});

	}
}
