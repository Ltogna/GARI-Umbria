package com.abacogroup.partyregistry.resources.publicapis;

import static com.abacogroup.partyregistry.PrtTest.TENANT_DEFAULT_CODE;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.jdbi.paging.impl.InfiniteListResultsImpl;
import com.abacogroup.partyregistry.PrtTest;
import com.abacogroup.partyregistry.api.PartyRelation;
import com.abacogroup.partyregistry.api.v1.PartyRelationResponseV1;
import com.abacogroup.partyregistry.core.AclService;
import com.abacogroup.partyregistry.core.PartyRelationService;
import com.abacogroup.partyregistry.core.impl.PartyRelationServiceImpl;
import com.abacogroup.partyregistry.resources.WebCliHelper;
import com.abacogroup.partyregistry.resources.req.PartyRelationTypeSearchReq;
import com.abacogroup.partyregistry.resources.req.ReqContext;
import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;
import io.dropwizard.testing.junit5.ResourceExtension;
import jakarta.ws.rs.core.GenericType;
import jakarta.ws.rs.core.UriBuilder;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.assertj.core.api.Assertions;
import org.hamcrest.Matchers;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mockito;

@ExtendWith(DropwizardExtensionsSupport.class)
class PartyRelationPublicResourceTest {

	private final AclService aclService = Mockito.mock(AclService.class);
	private final PartyRelationService partyRelationService = Mockito.mock(PartyRelationServiceImpl.class);

	private final PartyRelationPublicResource resource = new PartyRelationPublicResource(aclService, partyRelationService);
	private final ResourceExtension EXT = WebCliHelper.createEXT(resource);

	// ----- search -----
	@Test
	void test_search_ok() {

		Long partyId = PrtTest.PARTY999;

		var request = new PartyRelationTypeSearchReq()
				.setNote("note")
				.setRelationTypeCode("TYPE");

		var mockRes = PartyRelation.builder()
				.setPartyId(partyId)
				.setRelationTypeCode("TYPE")
				.setRelationTypeI18nCode("Type")
				.setNote("note")
				.build();
		given(partyRelationService.search(any(), anyLong(), any(), any()))
				.willReturn(new InfiniteListResultsImpl<>(List.of(mockRes), null));

		Map<String, Object> queryMap = new HashMap<>(EXT.getObjectMapper().convertValue(request, Map.class));
		queryMap.put("nextKey", "111");

		UriBuilder uriBuilder = UriBuilder.fromResource(resource.getClass());//.path(resource.getClass(), "search");
		queryMap.forEach(uriBuilder::queryParam);
		String uri = uriBuilder.build(TENANT_DEFAULT_CODE, partyId).toString();
		System.out.println(uri);

		InfiniteListResultsImpl<PartyRelationResponseV1> res = EXT.getJerseyTest().client()
				.target(UriBuilder.fromUri(uri))
				.request()
				.header("Authorization", WebCliHelper.BASIC_CREDENTIALS)
				.get(new GenericType<>() {
				});

		Assertions.assertThat(res).isNotNull()
				.extracting(InfiniteListResults::getRecords)
				.asList().hasSize(1)
				.element(0)
				.usingRecursiveComparison()
				.isEqualTo(mockRes);

		ArgumentCaptor<ReqContext> reqCtxCaptor = ArgumentCaptor.forClass(ReqContext.class);
		ArgumentCaptor<PartyRelationTypeSearchReq> argumentCaptor = ArgumentCaptor.forClass(PartyRelationTypeSearchReq.class);
		verify(partyRelationService, times(1)).
				search(reqCtxCaptor.capture(), eq(partyId), argumentCaptor.capture(), eq("111"));
		PartyRelationTypeSearchReq searchRequest = argumentCaptor.getValue();

		assertThat(searchRequest.getNote(), is("note"));
		assertThat(searchRequest.getRelationTypeCode(), is("TYPE"));

		ReqContext reqContext = reqCtxCaptor.getValue();
		assertThat(reqContext.getTenantId(), Matchers.is("master"));
		assertThat(reqContext.getLang(), Matchers.is("en"));
		assertThat(reqContext.getUsername(), Matchers.is(WebCliHelper.BASIC_USERNAME));

	}
}
