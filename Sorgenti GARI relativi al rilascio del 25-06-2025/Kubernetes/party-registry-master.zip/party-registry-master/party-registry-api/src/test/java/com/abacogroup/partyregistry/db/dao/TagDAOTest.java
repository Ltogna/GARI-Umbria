package com.abacogroup.partyregistry.db.dao;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.notNullValue;

import com.abacogroup.partyregistry.JdbiTest;
import com.abacogroup.partyregistry.PrtTest;
import com.abacogroup.partyregistry.db.ntt.TagEntity;
import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;
import java.util.List;
import java.util.Map;
import org.jdbi.v3.core.statement.UnableToExecuteStatementException;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

@ExtendWith(DropwizardExtensionsSupport.class)
class TagDAOTest extends JdbiTest {

	private static final String tenantId = "TagDAOTest_t";

	private static final Map<String, Object> testScriptParams = Map.of(
			"test_tenant", tenantId
	);

	private final TagDAO dao = getDAO(TagDAO.class);

	@BeforeAll
	@AfterAll
	public static void beforeAll() {
		List<String> initScripts = List.of("rollback");
		execSqlFiles(PrtTest.class, initScripts, testScriptParams);
	}

	@Test
	public void test_insert_same_code_different_tenant() {
		TagEntity entity = TagEntity.builder()
				.setTenantId(tenantId)
				.setCode("some-code")
				.build();
		dao.useTransaction(handle -> {

			handle.begin();

			dao.insert(entity);

			entity.setTenantId("another-tenant");
			dao.insert(entity);

			TagEntity tagEntity1 = dao.findByCode(tenantId, "some-code").orElse(null);
			assert tagEntity1 != null;
			assertThat(tagEntity1.getCode(), is(entity.getCode()));
			assertThat(tagEntity1.getTenantId(), is(tenantId));

			TagEntity tagEntity2 = dao.findByCode("another-tenant", "some-code").orElse(null);
			assert tagEntity2 != null;
			assertThat(tagEntity2.getCode(), is(entity.getCode()));
			assertThat(tagEntity2.getTenantId(), is("another-tenant"));

			handle.rollback();
		});
	}

	@Test
	@Disabled
	public void test_insert_duplicate() {
		dao.useTransaction(handle -> {
			handle.begin();
			TagEntity tagEntity = TagEntity.builder()
					.setTenantId(tenantId)
					.setCode("some-code")
					.build();

			dao.insert(tagEntity);

			UnableToExecuteStatementException thrown = Assertions
					.assertThrows(UnableToExecuteStatementException.class, () -> dao.insert(tagEntity));
			assertThat(thrown, notNullValue());
			handle.rollback();
		});
	}

}
