package com.abacogroup.partyregistry.bundle.config;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.containsInAnyOrder;
import static org.junit.jupiter.api.Assertions.assertThrows;

import com.abacogroup.bundles.initializer.impl.FileSupport;
import com.abacogroup.bundles.initializer.impl.exceptions.BundleException;
import com.abacogroup.bundles.listener.configdata.ConfigDataMessage;
import com.abacogroup.partyregistry.JdbiTest;
import com.abacogroup.partyregistry.db.dao.ExternalSourceDAO;
import com.abacogroup.partyregistry.db.ntt.ExternalSourceEntity;
import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;
import java.io.File;
import java.nio.file.Path;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import lombok.extern.slf4j.Slf4j;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

@Slf4j
@ExtendWith(DropwizardExtensionsSupport.class)
class ExternalSourceConfigMessageProcessorTest extends JdbiTest {

	private static final String TENANT_ID = ExternalSourceConfigMessageProcessorTest.class.getSimpleName() + "_t";
	private static final String CURRENT_USER = ExternalSourceConfigMessageProcessorTest.class.getSimpleName() + "_u";
	private static final Map<String, Object> testScriptParams = Map.of(
			"test_tenant", TENANT_ID,
			"user_id", CURRENT_USER
	);

	private final ExternalSourceConfigMessageProcessor processor = getService(ExternalSourceConfigMessageProcessor.class);

	public final String BUNDLE_PATH =
			"src/test/resources/com/abacogroup/partyregistry/bundle/config/" + this.getClass().getSimpleName() + File.separator + processor.getDomainName();

	@Test
	public void testOnMessage() {
		List<Path> paths = FileSupport.listFilesRecursive(Path.of(BUNDLE_PATH, "external_sources_01.json"));
		ConfigDataMessage msg = new ConfigDataMessage();
		msg.setConfigFiles(paths);
		msg.setTenantId(TENANT_ID);

		getJdbi().useHandle(handle -> {
			handle.begin();

			ExternalSourceDAO dao = handle.attach(ExternalSourceDAO.class);
			assertThat(dao.countAll(TENANT_ID), is(0L));
			processor.onMessage(msg);
			assertThat(dao.countAll(TENANT_ID), is(3L));

			assertThat(dao.findAll(TENANT_ID).stream().map(ExternalSourceEntity::getCode).collect(Collectors.toList()),
					containsInAnyOrder("CUSTOMER", "AUTH", "PAYMENT"));

			handle.rollback();
		});
	}

	@Test
	public void testOnMessage_update() {
		List<Path> paths = FileSupport.listFilesRecursive(Path.of(BUNDLE_PATH, "external_sources_01.json"));
		List<Path> updatePaths = FileSupport.listFilesRecursive(Path.of(BUNDLE_PATH, "external_sources_02.json"));
		ConfigDataMessage msg = new ConfigDataMessage();
		msg.setTenantId(TENANT_ID);

		getJdbi().useHandle(handle -> {
			handle.begin();
			ExternalSourceDAO dao = handle.attach(ExternalSourceDAO.class);

			Assertions.assertThat(dao.findAll(TENANT_ID)).hasSize(0);

			msg.setConfigFiles(paths);
			processor.onMessage(msg);

			Assertions.assertThat(dao.findAll(TENANT_ID)).hasSize(3)
					.extracting(ExternalSourceEntity::getCode)
					.containsExactlyInAnyOrder("CUSTOMER", "AUTH", "PAYMENT");
			Assertions.assertThat(dao.findByCode(TENANT_ID, "customer").get().getUrl())
					.isEqualTo("https://customer/v1/{code}");
			Assertions.assertThat(dao.findByCode(TENANT_ID, "auth").get().getFlAllowManual())
					.isEqualTo(1);

			msg.setConfigFiles(updatePaths);
			processor.onMessage(msg);

			Assertions.assertThat(dao.findAll(TENANT_ID)).hasSize(3)
					.extracting(ExternalSourceEntity::getCode)
					.containsExactlyInAnyOrder("CUSTOMER", "AUTH", "PAYMENT");

			Assertions.assertThat(dao.findByCode(TENANT_ID, "customer").get().getUrl())
					.isEqualTo("https://customer/v3/{code}");
			Assertions.assertThat(dao.findByCode(TENANT_ID, "auth").get().getFlAllowManual())
					.isEqualTo(0);

			handle.rollback();
		});
	}

	@Test
	public void testOnMessage_delete() {
		List<Path> paths = FileSupport.listFilesRecursive(Path.of(BUNDLE_PATH, "external_sources_01.json"));
		List<Path> deletePaths = FileSupport.listFilesRecursive(Path.of(BUNDLE_PATH, "external_sources.delete.json"));
		ConfigDataMessage msg = new ConfigDataMessage();
		msg.setTenantId(TENANT_ID);

		getJdbi().useHandle(handle -> {
			handle.begin();
			ExternalSourceDAO dao = handle.attach(ExternalSourceDAO.class);

			Assertions.assertThat(dao.findAll(TENANT_ID)).hasSize(0);

			msg.setConfigFiles(paths);
			processor.onMessage(msg);

			Assertions.assertThat(dao.findAll(TENANT_ID)).hasSize(3)
					.extracting(ExternalSourceEntity::getCode)
					.containsExactlyInAnyOrder("CUSTOMER", "AUTH", "PAYMENT");

			msg.setConfigFiles(deletePaths);
			processor.onMessage(msg);

			Assertions.assertThat(dao.findAll(TENANT_ID)).hasSize(1)
					.extracting(ExternalSourceEntity::getCode)
					.containsExactlyInAnyOrder("CUSTOMER");

			handle.rollback();
		});
	}

	@Test
	public void testOnMessage_invalidUrl_then_KO() {
		List<Path> paths = FileSupport.listFilesRecursive(Path.of(BUNDLE_PATH, "external_source_invalid_url.json"));
		ConfigDataMessage msg = new ConfigDataMessage();
		msg.setTenantId(TENANT_ID);

		getJdbi().useHandle(handle -> {
			handle.begin();
			ExternalSourceDAO dao = handle.attach(ExternalSourceDAO.class);

			Assertions.assertThat(dao.findAll(TENANT_ID)).hasSize(0);

			msg.setConfigFiles(paths);

			BundleException bundleException = assertThrows(BundleException.class, () -> processor.onMessage(msg));
			Assertions.assertThat(bundleException.getMessage()).contains("invalid URL");
			System.out.println(bundleException.getMessage());
			Assertions.assertThat(dao.findAll(TENANT_ID)).hasSize(0);

			handle.rollback();
		});
	}

	@Test
	public void testOnMessage_delete_whenSourceIsUsedInParty_thenNotDeleted() {
		List<Path> paths = FileSupport.listFilesRecursive(Path.of(BUNDLE_PATH, "external_sources_01.json"));
		List<Path> deletePaths = FileSupport.listFilesRecursive(Path.of(BUNDLE_PATH, "external_sources.delete.json"));
		ConfigDataMessage msg = new ConfigDataMessage();
		msg.setTenantId(TENANT_ID);

		getJdbi().useHandle(handle -> {
			handle.begin();
			// add party with source PAYMENT
			List<String> initScripts = List.of("add_party");
			execSqlFiles(this.getClass(), initScripts, testScriptParams);

			ExternalSourceDAO dao = handle.attach(ExternalSourceDAO.class);
			Assertions.assertThat(dao.findAll(TENANT_ID)).hasSize(0);

			msg.setConfigFiles(paths);
			processor.onMessage(msg);

			Assertions.assertThat(dao.findAll(TENANT_ID)).hasSize(3)
					.extracting(ExternalSourceEntity::getCode)
					.containsExactlyInAnyOrder("CUSTOMER", "AUTH", "PAYMENT");

			msg.setConfigFiles(deletePaths);

			BundleException bundleException = assertThrows(BundleException.class, () -> processor.onMessage(msg));
			Assertions.assertThat(bundleException.getMessage()).contains("already in use");
			System.out.println(bundleException.getMessage());

			Assertions.assertThat(dao.findAll(TENANT_ID)).hasSize(3);

			handle.rollback();
		});
	}

}
