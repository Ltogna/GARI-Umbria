package com.abacogroup.partyregistry.core.impl.validaor;

import static com.abacogroup.partyregistry.core.impl.validaor.PartyCodeRegexValidatorImpl.CONFIG_KEY;
import static org.junit.jupiter.api.Assertions.assertThrows;

import com.abacogroup.partyregistry.PartyRegistryApplicationTest;
import com.abacogroup.partyregistry.api.PartyTypeEnum;
import com.abacogroup.partyregistry.core.PartyFieldValidator;
import com.abacogroup.partyregistry.core.exceptions.ErrCodes;
import com.abacogroup.partyregistry.core.exceptions.InvalidPartyException;
import com.abacogroup.partyregistry.db.ntt.AppConfigEntity;
import com.abacogroup.partyregistry.db.ntt.PartyEntity;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.List;
import org.apache.commons.lang3.StringUtils;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.Test;

class PartyTaxCodeRegexValidatorImplTest {

	public static final String TENANT = "test_tenant";

//	private PartyDAO partyDAO = mock(PartyDAO.class);
	private ObjectMapper objectMapper = PartyRegistryApplicationTest.getObjectMapper();

	private PartyFieldValidator validator = new PartyTaxCodeRegexValidatorImpl(objectMapper);

	// ----- resetField -----
	@Test
	void test_resetField_ok() {

		PartyEntity partyEntity = PartyEntity.builder().setTaxCode("the_taxCode").build();

		validator.resetField(partyEntity);

		Assertions.assertThat(partyEntity.getTaxCode()).isEqualTo("THE_TAXCODE");

	}


	// ----- validateOnInsert -----
	@Test
	void test_validateOnInsert_defaultConfigOk() throws JsonProcessingException {
		String taxCode = "the_taxCode";
		PartyEntity partyEntity = PartyEntity.builder().setPartyType(PartyTypeEnum.N).setTaxCode(taxCode).build();
		RegexCodeConfiguration configuration = new RegexCodeConfiguration();
		AppConfigEntity validationConfig = AppConfigEntity.builder()
				.setTenantId(TENANT)
				.setConfigurationKey(CONFIG_KEY)
				.setConfiguration(objectMapper.writeValueAsString(configuration))
				.build();

		validator.validateOnInsert(partyEntity, validationConfig);

		Assertions.assertThat(partyEntity.getTaxCode()).isEqualTo("THE_TAXCODE");
	}

	@Test
	void test_validateOnInsert_legalConfigOk() throws JsonProcessingException {
		String taxCode = "01234567890";
		PartyEntity partyEntity = PartyEntity.builder().setPartyType(PartyTypeEnum.L).setTaxCode(taxCode).build();
		RegexCodeConfiguration configuration = RegexCodeConfiguration.builder()
				.setLegal(List.of("^\\d{11}$"))
				.setNatural(List.of("^[a-zA-Z]{6}\\d{2}[a-zA-Z]{1}\\d{2}[a-zA-Z]{1}\\d{3}[a-zA-Z]{1}$"))
				.build();
		AppConfigEntity validationConfig = AppConfigEntity.builder()
				.setTenantId(TENANT)
				.setConfigurationKey(CONFIG_KEY)
				.setConfiguration(objectMapper.writeValueAsString(configuration))
				.build();

		validator.validateOnInsert(partyEntity, validationConfig);

		Assertions.assertThat(partyEntity.getTaxCode()).isEqualTo(taxCode);
	}

	@Test
	void test_validateOnInsert_legalConfigKo() throws JsonProcessingException {
		String taxCode = "ko!";
		PartyEntity partyEntity = PartyEntity.builder().setPartyType(PartyTypeEnum.L).setTaxCode(taxCode).build();
		RegexCodeConfiguration configuration = RegexCodeConfiguration.builder()
				.setLegal(List.of("^\\d{11}$"))
				.setNatural(List.of("^[a-zA-Z]{6}\\d{2}[a-zA-Z]{1}\\d{2}[a-zA-Z]{1}\\d{3}[a-zA-Z]{1}$"))
				.build();
		AppConfigEntity validationConfig = AppConfigEntity.builder()
				.setTenantId(TENANT)
				.setConfigurationKey(CONFIG_KEY)
				.setConfiguration(objectMapper.writeValueAsString(configuration))
				.build();

		InvalidPartyException invalidPartyException = assertThrows(InvalidPartyException.class,
				() -> validator.validateOnInsert(partyEntity, validationConfig));

		Assertions.assertThat(invalidPartyException)
				.satisfies(ex -> System.out.println(ex.getMessage()))
				.extracting("code")
				.isEqualTo(ErrCodes.INVALID_PAYLOAD);
	}

	@Test
	void test_validateOnInsert_naturalConfigOk() throws JsonProcessingException {
		String taxCode = "ACVFFF22a11b236t";
		PartyEntity partyEntity = PartyEntity.builder().setPartyType(PartyTypeEnum.N).setTaxCode(taxCode).build();
		RegexCodeConfiguration configuration = RegexCodeConfiguration.builder()
				.setLegal(List.of("^\\d{11}$"))
				.setNatural(List.of("^[a-zA-Z]{6}\\d{2}[a-zA-Z]{1}\\d{2}[a-zA-Z]{1}\\d{3}[a-zA-Z]{1}$"))
				.build();
		AppConfigEntity validationConfig = AppConfigEntity.builder()
				.setTenantId(TENANT)
				.setConfigurationKey(CONFIG_KEY)
				.setConfiguration(objectMapper.writeValueAsString(configuration))
				.build();

		validator.validateOnInsert(partyEntity, validationConfig);

		Assertions.assertThat(partyEntity.getTaxCode()).isEqualTo(StringUtils.upperCase(taxCode));
	}

	@Test
	void test_validateOnInsert_naturalConfigKo() throws JsonProcessingException {
		String taxCode = "ACV12322a11b236t";
		PartyEntity partyEntity = PartyEntity.builder().setPartyType(PartyTypeEnum.N).setTaxCode(taxCode).build();
		RegexCodeConfiguration configuration = RegexCodeConfiguration.builder()
				.setLegal(List.of("^\\d{11}$"))
				.setNatural(List.of("^[a-zA-Z]{6}\\d{2}[a-zA-Z]{1}\\d{2}[a-zA-Z]{1}\\d{3}[a-zA-Z]{1}$"))
				.build();
		AppConfigEntity validationConfig = AppConfigEntity.builder()
				.setTenantId(TENANT)
				.setConfigurationKey(CONFIG_KEY)
				.setConfiguration(objectMapper.writeValueAsString(configuration))
				.build();

		InvalidPartyException invalidPartyException = assertThrows(InvalidPartyException.class,
				() -> validator.validateOnInsert(partyEntity, validationConfig));

		Assertions.assertThat(invalidPartyException)
				.satisfies(ex -> System.out.println(ex.getMessage()))
				.extracting("code")
				.isEqualTo(ErrCodes.INVALID_PAYLOAD);
	}

	// ----- validateOnUpdate -----
	@Test
	void test_validateOnUpdate_ok() throws JsonProcessingException {
				String taxCode = "ACVFFF22a11b236t   ";
		PartyEntity partyEntity = PartyEntity.builder().setPartyType(PartyTypeEnum.N).setTaxCode(taxCode).build();
		RegexCodeConfiguration configuration = RegexCodeConfiguration.builder()
				.setLegal(List.of("^\\d{11}$"))
				.setNatural(List.of("^[a-zA-Z]{6}\\d{2}[a-zA-Z]{1}\\d{2}[a-zA-Z]{1}\\d{3}[a-zA-Z]{1}$"))
				.build();
		AppConfigEntity validationConfig = AppConfigEntity.builder()
				.setTenantId(TENANT)
				.setConfigurationKey(CONFIG_KEY)
				.setConfiguration(objectMapper.writeValueAsString(configuration))
				.build();

		validator.validateOnUpdate(partyEntity, validationConfig);

		Assertions.assertThat(partyEntity.getTaxCode()).isEqualTo(StringUtils.upperCase(StringUtils.trim(taxCode)));
	}

	@Test
	void test_validateOnUpdate_ko() throws JsonProcessingException {
		String taxCode = "012345678900";
		PartyEntity partyEntity = PartyEntity.builder().setPartyType(PartyTypeEnum.L).setTaxCode(taxCode).build();
		RegexCodeConfiguration configuration = RegexCodeConfiguration.builder()
				.setLegal(List.of("^\\d{11}$"))
				.setNatural(List.of("^[a-zA-Z]{6}\\d{2}[a-zA-Z]{1}\\d{2}[a-zA-Z]{1}\\d{3}[a-zA-Z]{1}$"))
				.build();
		AppConfigEntity validationConfig = AppConfigEntity.builder()
				.setTenantId(TENANT)
				.setConfigurationKey(CONFIG_KEY)
				.setConfiguration(objectMapper.writeValueAsString(configuration))
				.build();

		InvalidPartyException invalidPartyException = assertThrows(InvalidPartyException.class,
				() -> validator.validateOnUpdate(partyEntity, validationConfig));

		Assertions.assertThat(invalidPartyException)
				.satisfies(ex -> System.out.println(ex.getMessage()))
				.extracting("code")
				.isEqualTo(ErrCodes.INVALID_PAYLOAD);
	}
}
