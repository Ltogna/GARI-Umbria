package com.abacogroup.partyregistry.resources.publicapis;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.hasSize;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import com.abacogroup.partyregistry.PrtTest;
import com.abacogroup.partyregistry.api.PartyTag;
import com.abacogroup.partyregistry.api.v1.TagResponseV1;
import com.abacogroup.partyregistry.core.PartyTagService;
import com.abacogroup.partyregistry.core.impl.PartyServiceImpl;
import com.abacogroup.partyregistry.resources.WebCliHelper;
import com.abacogroup.partyregistry.resources.req.ReqContext;
import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;
import io.dropwizard.testing.junit5.ResourceExtension;
import java.util.List;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mockito;

@Slf4j
@ExtendWith(DropwizardExtensionsSupport.class)
@Deprecated
class PartyTagPublicResourceTest {

	private final PartyTagService partyService = Mockito.mock(PartyServiceImpl.class);

	private final ResourceExtension EXT = WebCliHelper.createEXT(new PartyTagPublicResource(partyService));

	@Test
	@SuppressWarnings("unchecked")
	void test_list_party_tags() {
		String path = String.format(PrtTest.MASTER_PUBLIC_PATH + "/parties/1/tags");

		given(partyService.getPartyTags(any(ReqContext.class), anyLong())).willReturn(List.of(
				PartyTag.builder()
						.setTagId(1L)
						.setTagCode("A")
						.build(),

				PartyTag.builder()
						.setTagId(2L)
						.setTagCode("B")
						.build()
		));

		List<TagResponseV1> mockList = WebCliHelper.executeGet(EXT, path, null, WebCliHelper.BASIC_CREDENTIALS, List.class);

		ArgumentCaptor<ReqContext> reqCtxCaptor = ArgumentCaptor.forClass(ReqContext.class);
		verify(partyService, times(1))
				.getPartyTags(reqCtxCaptor.capture(), eq(1L));

		assertThat(mockList, hasSize(2));
	}

}
