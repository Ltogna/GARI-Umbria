package com.abacogroup.partyregistry.core.impl;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.mock;

import com.abacogroup.lau.api.v1.CountryResponseV1;
import com.abacogroup.lau.api.v1.DistrictResponseV1;
import com.abacogroup.lau.api.v1.MunicipalityResponseV1;
import com.abacogroup.lau.api.v1.RegionResponseV1;
import com.abacogroup.lau.core.cli.v1.MunicipalityClientV1;
import com.abacogroup.partyregistry.JdbiTest;
import com.abacogroup.partyregistry.api.v1.AddressResponseV1;
import com.abacogroup.partyregistry.api.v1.PartySearchResponseV1;
import com.abacogroup.partyregistry.api.v1.TagResponseV1;
import com.abacogroup.partyregistry.api.v1.req.PartySearchRequestV1;
import com.abacogroup.partyregistry.core.AclService;
import com.abacogroup.partyregistry.core.PartyService;
import com.abacogroup.partyregistry.core.PartyV1Service;
import com.abacogroup.partyregistry.resources.req.ReqContext;
import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;
import java.util.List;
import java.util.Map;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

@ExtendWith(DropwizardExtensionsSupport.class)
class PartyV1ServiceImplTest extends JdbiTest {

	private static final String currentUser = "PartyV1ServiceImplTest_u";
	private static final String tenantId = "PartyV1ServiceImplTest_t";

	private static final Map<String, Object> testScriptParams = Map.of(
			"test_tenant", tenantId,
			"user_id", currentUser
	);

	private static final ReqContext reqContext =
			new ReqContext(tenantId, currentUser, "en");

	private PartyV1Service service;
	private MunicipalityClientV1 municipalityClientV1;

	@BeforeEach
	public void beforeEach() {

		PartyService partyService = getService(PartyServiceImpl.class);
		LauMapper lauMapper = getService(LauMapper.class);
		this.municipalityClientV1 = mock(MunicipalityClientV1.class);

		injectMock(lauMapper, municipalityClientV1);
		injectMock(partyService, lauMapper);

		service = new PartyV1ServiceImpl(partyService, lauMapper);
	}

	@Test
	void test_search_mappingOk() {
		setUnusedBindingAllowed(true);
		getJdbi().useHandle(handle -> {
			handle.begin();

			List<String> initScripts = List.of("v1_insert_parties_and_tags");
			execSqlFiles(this.getClass(), initScripts, testScriptParams);

			MunicipalityResponseV1 cagliari = buildCagliari();
			MunicipalityResponseV1 oristano = buildOristano();
			given(municipalityClientV1.getByCode(anyString(), any(), eq("ITA_20_292_009"))).willReturn(cagliari);
			given(municipalityClientV1.getByCode(anyString(), any(), eq("ITA_20_095038"))).willReturn(oristano);

			PartySearchRequestV1 request = new PartySearchRequestV1().setTaxCode("222");
			List<PartySearchResponseV1> list = this.service.publicSearch(reqContext, request, AclService.MANAGE_READ,null).getRecords();

			Assertions.assertThat(list).hasSize(1)
					.element(0).satisfies(p -> {
						assertThat(p.getId(), is(-444L));
						assertFalse(p.isArchived());
						Assertions.assertThat(p.getBirthMunicipalityDetail()).isNotNull()
								.usingRecursiveComparison()
								.isEqualTo(oristano);
						Assertions.assertThat(p.getAddressResidential()).isNotNull()
								.usingRecursiveComparison()
								.ignoringFields("municipalityDetail")
								.isEqualTo(AddressResponseV1.builder()
										.setId(-2L)
										.setMunicipality("ITA_20_292_009")
										.setLocality("Pirri")
										.setStreet("via Ruggero Bacone")
										.setHouseNumber("4")
										.setPostcode("09134")
										.setDetails("details test")
										.setNote("note test")
										.build());
						Assertions.assertThat(p.getAddressResidential().getMunicipalityDetail()).isNotNull()
								.usingRecursiveComparison()
								.isEqualTo(cagliari);
					});

			handle.rollback();
		});
	}

	// ----- getPartyResponseById -----
	@Test
	void test_getPartyResponseById_ok() {
		setUnusedBindingAllowed(true);
		getJdbi().useHandle(handle -> {
			handle.begin();

			List<String> initScripts = List.of("v1_insert_parties_and_tags");
			execSqlFiles(this.getClass(), initScripts, testScriptParams);

			MunicipalityResponseV1 agile = buildAgile();
			MunicipalityResponseV1 airasca = buildAirasca();
			MunicipalityResponseV1 alaDiStura = buildAlaDiStura();
			given(municipalityClientV1.getByCode(anyString(), any(), eq("ITA_01_001001"))).willReturn(agile);
			given(municipalityClientV1.getByCode(anyString(), any(), eq("ITA_01_001002"))).willReturn(airasca);
			given(municipalityClientV1.getByCode(anyString(), any(), eq("ITA_01_001003"))).willReturn(alaDiStura);

			long id = -333L;
			var party = this.service.getPartyResponseById(reqContext, id);

			Assertions.assertThat(party).isPresent()
					.get().satisfies(p -> {
						assertThat(p.getId(), is(id));
						assertFalse(p.isArchived());
						Assertions.assertThat(p.getTags()).hasSize(2)
								.extracting(TagResponseV1::getCode)
								.containsExactlyInAnyOrder("BUG", "LOL");
						Assertions.assertThat(p.getBirthMunicipalityDetail()).isNotNull()
								.usingRecursiveComparison()
								.isEqualTo(agile);

						Assertions.assertThat(p.getAddressResidential()).isNotNull()
								.usingRecursiveComparison()
								.ignoringFields("municipalityDetail", "id")
								.isEqualTo(AddressResponseV1.builder()
										.setMunicipality(agile.getCode())
										.setLocality("Loc 1")
										.setStreet("via Roma")
										.setHouseNumber("4")
										.setPostcode("11111")
										.setDetails("details test")
										.setNote("note test")
										.build());
						Assertions.assertThat(p.getAddressResidential().getMunicipalityDetail()).isNotNull()
								.usingRecursiveComparison()
								.isEqualTo(agile);

						Assertions.assertThat(p.getAddressHome()).isNotNull()
								.usingRecursiveComparison()
								.ignoringFields("municipalityDetail", "id")
								.isEqualTo(AddressResponseV1.builder()
										.setMunicipality(airasca.getCode())
										.setLocality("Loc 2")
										.setStreet("via Napoli")
										.setHouseNumber("66")
										.setPostcode("22222")
										.setDetails("details test")
										.setNote("note test")
										.build());
						Assertions.assertThat(p.getAddressHome().getMunicipalityDetail()).isNotNull()
								.usingRecursiveComparison()
								.isEqualTo(airasca);

						Assertions.assertThat(p.getAddressBilling()).isNotNull()
								.usingRecursiveComparison()
								.ignoringFields("municipalityDetail", "id")
								.isEqualTo(AddressResponseV1.builder()
										.setMunicipality(alaDiStura.getCode())
										.setLocality(null)
										.setStreet("via Sicilia")
										.setHouseNumber("1")
										.setPostcode("33333")
										.setDetails("details test")
										.setNote("note test")
										.build());
						Assertions.assertThat(p.getAddressBilling().getMunicipalityDetail()).isNotNull()
								.usingRecursiveComparison()
								.isEqualTo(alaDiStura);
					});

			handle.rollback();
		});
	}

	// ###################################################################################################################################################### //

	private static MunicipalityResponseV1 buildCagliari() {
		return MunicipalityResponseV1.builder()
				.setCode("ITA_20_292_009")
				.setI18nName("Cagliari")
				.setDistrict(DistrictResponseV1.builder()
						.setCode("ITA_20_292")
						.setI18nName("Città Metropolitana di Cagliari")
						.setRegion(buildSardegna())
						.build())
				.build();
	}

	private static MunicipalityResponseV1 buildOristano() {
		return MunicipalityResponseV1.builder()
				.setCode("ITA_20_095038")
				.setI18nName("Oristano")
				.setDistrict(DistrictResponseV1.builder()
						.setCode("ITA_20_095")
						.setI18nName("Provincia di Oristano")
						.setRegion(buildSardegna())
						.build())
				.build();
	}

	private static MunicipalityResponseV1 buildAgile() {
		return MunicipalityResponseV1.builder()
				.setCode("ITA_01_001001")
				.setI18nName("Agliè")
				.setDistrict(buildTorino())
				.build();
	}

	private static MunicipalityResponseV1 buildAirasca() {
		return MunicipalityResponseV1.builder()
				.setCode("ITA_01_001002")
				.setI18nName("Airasca")
				.setDistrict(buildTorino())
				.build();
	}

	private static MunicipalityResponseV1 buildAlaDiStura() {
		return MunicipalityResponseV1.builder()
				.setCode("ITA_01_001003")
				.setI18nName("Ala di Stura")
				.setDistrict(buildTorino())
				.build();
	}

	private static DistrictResponseV1 buildTorino() {
		return DistrictResponseV1.builder()
				.setCode("ITA_01_001")
				.setI18nName("Provincia di Torino")
				.setRegion(RegionResponseV1.builder()
						.setCode("ITA_01")
						.setI18nName("Piemonte")
						.setCountry(buildItalia())
						.build())
				.build();
	}

	private static RegionResponseV1 buildSardegna() {
		return RegionResponseV1.builder()
				.setCode("ITA_20")
				.setI18nName("Sardegna")
				.setCountry(buildItalia())
				.build();
	}

	private static CountryResponseV1 buildItalia() {
		return CountryResponseV1.builder()
				.setCode("ITA")
				.setI18nName("Italia")
				.build();
	}

}
