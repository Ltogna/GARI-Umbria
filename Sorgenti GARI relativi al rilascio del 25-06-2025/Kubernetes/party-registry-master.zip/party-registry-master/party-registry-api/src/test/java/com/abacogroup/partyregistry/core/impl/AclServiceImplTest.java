package com.abacogroup.partyregistry.core.impl;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.BDDMockito.given;

import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import com.abacogroup.dropwizard.auth.sso2.Sso2Client;
import com.abacogroup.partyregistry.api.PartyRes;
import com.abacogroup.partyregistry.core.AclService;
import com.abacogroup.partyregistry.db.dao.PartyDAO;
import com.abacogroup.partyregistry.resources.req.ReqContext;
import com.abacogroup.proxies.cache.core.exception.ResourceNotAuthorizedException;

class AclServiceImplTest {

	private PartyDAO dao = Mockito.mock(PartyDAO.class);
	private Sso2Client sso2Client = Mockito.mock(Sso2Client.class);

	private AclService aclService = new AclServiceImpl(dao, sso2Client, false);

	// ----- isAuthorized -----
	@Test
	void test_isAuthorized_ok() {
		ReqContext reqContext = new ReqContext("test-tenant", "usr");
		given(dao.isAuthorized(any(), any(), any()))
				.willReturn(true);

		aclService.isAuthorized(reqContext, new PartyRes().setId(99L), 1);

		aclService.isAuthorized(reqContext, new PartyRes().setId(null), 1);

		aclService.isAuthorized(reqContext, null, AclService.MANAGE_READ);

	}

	@Test
	void test_isAuthorized_ok403() {
		ReqContext reqContext = new ReqContext("test-tenant", "usr");
		given(dao.isAuthorized(any(), any(), any()))
				.willReturn(false);

		ResourceNotAuthorizedException resourceNotAuthorizedException = assertThrows(ResourceNotAuthorizedException.class,
				() -> aclService.isAuthorized(reqContext, new PartyRes().setId(99L), 1));


	}
}
