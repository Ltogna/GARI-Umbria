package com.abacogroup.partyregistry.resources;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import com.abacogroup.partyregistry.PrtTest;
import com.abacogroup.partyregistry.core.AclService;
import com.abacogroup.partyregistry.core.DocTypeService;
import com.abacogroup.partyregistry.core.impl.DocTypeServiceImpl;
import com.abacogroup.partyregistry.resources.req.DocTypeSearchReq;
import com.abacogroup.partyregistry.resources.req.ReqContext;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;
import io.dropwizard.testing.junit5.ResourceExtension;
import java.util.List;
import java.util.Map;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mockito;

@Slf4j
@ExtendWith(DropwizardExtensionsSupport.class)
class DocTypeResourceTest {

	private final AclService aclService = Mockito.mock(AclService.class);
	private final DocTypeService docTypeService = Mockito.mock(DocTypeServiceImpl.class);

	private final ResourceExtension EXT = WebCliHelper.createEXT(new DocTypeResource(aclService, docTypeService));

	@Test
	@SuppressWarnings("unchecked")
	void test_search() {
		String i18nDocType = "type1";

		String path = String.format(PrtTest.MASTER_PATH + "/doc-types/1");
		DocTypeSearchReq searchParams = new DocTypeSearchReq()
				.setI18nDocType(i18nDocType);

		ObjectMapper mapper = new ObjectMapper();

		Map<String, Object> beanMap = mapper.convertValue(searchParams, Map.class);

		WebCliHelper.executeGet(EXT, path, beanMap, WebCliHelper.BASIC_CREDENTIALS, List.class);

		ArgumentCaptor<ReqContext> reqCtxCaptor = ArgumentCaptor.forClass(ReqContext.class);
		ArgumentCaptor<DocTypeSearchReq> requestArgumentCaptor = ArgumentCaptor.forClass(
				DocTypeSearchReq.class);

		verify(docTypeService, times(1))
				.search(reqCtxCaptor.capture(), eq(1L), requestArgumentCaptor.capture());

		DocTypeSearchReq searchRequest = requestArgumentCaptor.getValue();
		assertThat(searchRequest.getI18nDocType(), is(i18nDocType));

		ReqContext reqContext = reqCtxCaptor.getValue();
		assertThat(reqContext.getTenantId(), is("master"));
		assertThat(reqContext.getLang(), is("en"));
		assertThat(reqContext.getUsername(), is(WebCliHelper.BASIC_USERNAME));

	}
}
