package com.abacogroup.partyregistry.resources;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import com.abacogroup.partyregistry.PrtTest;
import com.abacogroup.partyregistry.core.ExternalSourceService;
import com.abacogroup.partyregistry.resources.req.ReqContext;
import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;
import io.dropwizard.testing.junit5.ResourceExtension;
import java.util.List;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mockito;

@Slf4j
@ExtendWith(DropwizardExtensionsSupport.class)
class ExternalSourceResourceTest {

	private final ExternalSourceService externalSourceService = Mockito.mock(ExternalSourceService.class);
	private final ResourceExtension EXT = WebCliHelper.createEXT(new ExternalSourceResource(externalSourceService));

	@Test
	void test_list() {
		String path = String.format(PrtTest.MASTER_PATH + "/external-sources");

		WebCliHelper.executeGet(EXT, path, null, WebCliHelper.BASIC_CREDENTIALS, List.class);

		ArgumentCaptor<ReqContext> reqCtxCaptor = ArgumentCaptor.forClass(ReqContext.class);

		verify(externalSourceService, times(1))
				.getAll(reqCtxCaptor.capture());

		ReqContext reqContext = reqCtxCaptor.getValue();
		assertThat(reqContext.getTenantId(), is("master"));
		assertThat(reqContext.getLang(), is("en"));
		assertThat(reqContext.getUsername(), is(WebCliHelper.BASIC_USERNAME));
	}
}
