package com.abacogroup.partyregistry.resources;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import com.abacogroup.jdbi.paging.impl.InfiniteListResultsImpl;
import com.abacogroup.partyregistry.PrtTest;
import com.abacogroup.partyregistry.core.impl.TagServiceImpl;
import com.abacogroup.partyregistry.resources.req.ReqContext;
import com.abacogroup.partyregistry.resources.req.TagReq;
import com.abacogroup.partyregistry.resources.req.TagSearchReq;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;
import io.dropwizard.testing.junit5.ResourceExtension;
import java.util.List;
import java.util.Map;
import java.util.stream.Stream;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.provider.Arguments;
import org.mockito.ArgumentCaptor;
import org.mockito.Mockito;

@ExtendWith(DropwizardExtensionsSupport.class)
class TagResourceTest {

	private final TagServiceImpl tagService = Mockito.mock(TagServiceImpl.class);
	private final ResourceExtension EXT = WebCliHelper.createEXT(new TagResource(tagService));

	private final ObjectMapper mapper = new ObjectMapper();

	protected static Stream<Arguments> test_validate_tag_to_insert() {
		String INVALID_CODE_LOWER_CASE = "code_01"; // contains lowerCase
		String INVALID_CODE_MORE_THAN_20 = "code_1875421325478CODE"; // size more than 20

		TagReq invalid_tag_lower_case = TagReq.builder().setCode(INVALID_CODE_LOWER_CASE).build();
		TagReq invalid_tag_over_size = TagReq.builder().setCode(INVALID_CODE_MORE_THAN_20).build();
		return Stream.of(
				Arguments.of("invalid_tag_lower_case", invalid_tag_lower_case, new String[] { "code" }),
				Arguments.of("invalid_tag_over_size", invalid_tag_over_size, new String[] { "code" })
		);
	}

	@Test
	@SuppressWarnings("unchecked")
	void test_search() {
		String path = String.format(PrtTest.MASTER_PATH + "/tags");
		TagSearchReq searchParams = new TagSearchReq()
				.setCode("lol");
		Map<String, Object> beanMap = mapper.convertValue(searchParams, Map.class);

		WebCliHelper.executeGet(EXT, path, beanMap, WebCliHelper.BASIC_CREDENTIALS, InfiniteListResultsImpl.class);

		ArgumentCaptor<ReqContext> reqCtxCaptor = ArgumentCaptor.forClass(ReqContext.class);
		ArgumentCaptor<TagSearchReq> searchReqArgumentCaptor = ArgumentCaptor.forClass(TagSearchReq.class);
		verify(tagService, times(1))
				.searchTags(reqCtxCaptor.capture(), searchReqArgumentCaptor.capture(), eq(null));

		TagSearchReq searchRequest = searchReqArgumentCaptor.getValue();
		assertThat(searchRequest.getCode(), is("lol"));

		ReqContext reqContext = reqCtxCaptor.getValue();
		assertThat(reqContext.getTenantId(), is("master"));
		assertThat(reqContext.getLang(), is("en"));
		assertThat(reqContext.getUsername(), is(WebCliHelper.BASIC_USERNAME));
	}

	@Test
	void test_list() {
		String path = String.format(PrtTest.MASTER_PATH  + "/tags/list");

		TagSearchReq searchParams = new TagSearchReq()
				.setCode("lol");
		Map<String, Object> beanMap = mapper.convertValue(searchParams, Map.class);

		WebCliHelper.executeGet(EXT, path, beanMap, WebCliHelper.BASIC_CREDENTIALS, List.class);

		ArgumentCaptor<ReqContext> reqCtxCaptor = ArgumentCaptor.forClass(ReqContext.class);
		ArgumentCaptor<TagSearchReq> searchReqArgumentCaptor = ArgumentCaptor.forClass(TagSearchReq.class);
		verify(tagService, times(1))
				.searchTagList(reqCtxCaptor.capture(), searchReqArgumentCaptor.capture());

		TagSearchReq searchRequest = searchReqArgumentCaptor.getValue();
		assertThat(searchRequest.getCode(), is("lol"));

		ReqContext reqContext = reqCtxCaptor.getValue();
		assertThat(reqContext.getTenantId(), is("master"));
		assertThat(reqContext.getLang(), is("en"));
		assertThat(reqContext.getUsername(), is(WebCliHelper.BASIC_USERNAME));
	}

/*	@Test
	void test_insertTag() {
		TagReq tagReq = TagReq.builder()
				.setCode("DEV")
				.build();
		given(tagService.save(Mockito.any(), Mockito.any()))
				.willReturn(Tag.builder().setCode("DEV").setId(-123L).build());

		String uri = PrtTest.MASTER_PATH + "/tags";
		Tag response = WebCliHelper.executePost(EXT, uri, tagReq, WebCliHelper.BASIC_CREDENTIALS, Tag.class);

		ArgumentCaptor<ReqContext> reqCtxCaptor = ArgumentCaptor.forClass(ReqContext.class);
		verify(tagService, times(1))
				.save(reqCtxCaptor.capture(), eq(tagReq));

		ReqContext reqContext = reqCtxCaptor.getValue();
		assertThat(reqContext.getTenantId(), is("master"));
		assertThat(reqContext.getLang(), is("en"));
		assertThat(reqContext.getUsername(), is(WebCliHelper.BASIC_USERNAME));
	}*/

	/*@ParameterizedTest
	@MethodSource
	void test_validate_tag_to_insert(String ignoredTitle, TagReq tagReq, String... fields) {
		String uri = PrtTest.MASTER_PATH + "/tags";
		ClientErrorException ex = Assertions.assertThrows(ClientErrorException.class, () -> {
			WebCliHelper.executePost(EXT, uri, tagReq, WebCliHelper.BASIC_CREDENTIALS, Tag.class);
		});

		List<String> errors = FieldErrorUtils.extractErrorFieldNames(ex);
		assertThat(errors, containsInAnyOrder(fields));
		//assertTrue(responseMap.containsKey("errors"));
	}*/
}
