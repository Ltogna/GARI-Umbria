package com.abacogroup.partyregistry.core.impl;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.containsInAnyOrder;

import com.abacogroup.partyregistry.JdbiTest;
import com.abacogroup.partyregistry.PrtTest;
import com.abacogroup.partyregistry.api.RelationRole;
import com.abacogroup.partyregistry.core.RelationRoleService;
import com.abacogroup.partyregistry.resources.req.RelationRoleSearchReq;
import com.abacogroup.partyregistry.resources.req.ReqContext;
import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;

@Slf4j
@ExtendWith(DropwizardExtensionsSupport.class)
class RelationRoleServiceImplTest extends JdbiTest {

	private static final String currentUser = "RelationRoleServiceImplTest_u";
	private static final String tenantId = "RelationRoleServiceImplTest_t";

	private static final Map<String, Object> testScriptParams = Map.of(
			"test_tenant", tenantId,
			"user_id", currentUser
	);

	private static final ReqContext reqContext =
			new ReqContext(tenantId, currentUser, "en");

	private final RelationRoleService service = getService(RelationRoleServiceImpl.class);

	@BeforeAll
	@AfterAll
	public static void beforeAll() {
		List<String> initScripts = List.of("rollback");
		execSqlFiles(PrtTest.class, initScripts, testScriptParams);
	}

	@ParameterizedTest
	@MethodSource
	void test_search(String ignoredTitle, RelationRoleSearchReq request, List<String> results) {

		setUnusedBindingAllowed(true);
		getJdbi().useHandle(handle -> {
			handle.begin();

			List<String> initScripts = List.of("rel_roles");
			execSqlFiles(this.getClass(), initScripts, testScriptParams);

			List<RelationRole> list = this.service
					.search(reqContext, request, null)
					.getRecords();
			List<String> actual = list.stream()
					.map(rel -> String.format("%s_%s", rel.getRelationType().getCode(), rel.getCode()))
					.collect(Collectors.toList());
			assertThat(actual, containsInAnyOrder(results.toArray()));

			handle.rollback();
		});

	}

	private static Stream<Arguments> test_search() {
		return Stream.of(
				Arguments.of("search_by_code", new RelationRoleSearchReq()
								.setCode("MARITO")
						, List.of("NUCLEO_FAMILIARE_MARITO", "AZIENDA_MARITO"))
				, Arguments.of("search_by_typeCode", new RelationRoleSearchReq()
								.setRelationTypeCode("RIFERIMENTI_CONTATTI"),
						List.of(
								"RIFERIMENTI_CONTATTI_CONTATTO_AMMINISTRATIVO",
								"RIFERIMENTI_CONTATTI_CONTATTO_TECNICO",
								"RIFERIMENTI_CONTATTI_CURATORE_FALLIMENTARE",
								"RIFERIMENTI_CONTATTI_RAPPRESENTANTE_DI_MINORE",
								"RIFERIMENTI_CONTATTI_RAPPRESENTANTE_LEGALE"))
				, Arguments.of("search_by_typeCode_and_code", new RelationRoleSearchReq()
								.setCode("CONTATTO_AMMINISTRATIVO")
								.setRelationTypeCode("RIFERIMENTI_CONTATTI"),
						List.of("RIFERIMENTI_CONTATTI_CONTATTO_AMMINISTRATIVO"))
		);
	}

	@Test
	void test_getByCode() {

		setUnusedBindingAllowed(true);
		getJdbi().useHandle(handle -> {
			handle.begin();

			List<String> initScripts = List.of("rel_roles");
			execSqlFiles(this.getClass(), initScripts, testScriptParams);

			RelationRole relationRole = this.service.getByCode(reqContext, "FRATELLO")
					.orElseThrow();
			assertThat(relationRole.getCode(), is("FRATELLO"));
			assertThat(relationRole.getI18nCode(), is("FRATELLO_en".toLowerCase()));
			assertThat(relationRole.getRelationType().getCode(), is("AZIENDA"));
			assertThat(relationRole.getRelationType().getI18nCode(), is("AZIENDA_en".toLowerCase()));

			assertThat(
					this.service.getByCodeAndType(reqContext, "AZIENDA", "FRATELLO").orElseThrow(),
					is(relationRole));

			Optional<RelationRole> elapsed = this.service.getByCode(reqContext, "SORELLASTRA");
			assertThat(elapsed.isEmpty(), is(true));
			assertThat(
					this.service.getByCodeAndType(reqContext, "AZIENDA", "SORELLASTRA"),
					is(elapsed));

			Optional<RelationRole> invalid = this.service.getByCode(reqContext, "11111111L");
			assertThat(invalid.isEmpty(), is(true));

			handle.rollback();
		});

	}


}
