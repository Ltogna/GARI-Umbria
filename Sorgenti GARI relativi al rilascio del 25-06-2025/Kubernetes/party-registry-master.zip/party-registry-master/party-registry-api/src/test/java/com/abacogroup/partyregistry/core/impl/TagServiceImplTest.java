package com.abacogroup.partyregistry.core.impl;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;

import com.abacogroup.partyregistry.JdbiTest;
import com.abacogroup.partyregistry.api.Tag;
import com.abacogroup.partyregistry.resources.req.ReqContext;
import com.abacogroup.partyregistry.resources.req.TagSearchReq;
import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;

@ExtendWith(DropwizardExtensionsSupport.class)
class TagServiceImplTest extends JdbiTest {

	private static final String currentUser = "TagServiceImplTest_u";
	private static final String tenantId = "TagServiceImplTest_t";
	private static final Map<String, Object> testScriptParams = Map.of(
			"test_tenant", tenantId,
			"user_id", currentUser
	);
	private static final ReqContext reqContext =
			new ReqContext(tenantId, currentUser, "en");

	private final TagServiceImpl service = getService(TagServiceImpl.class);

	@ParameterizedTest
	@MethodSource
	public void test_search_dto(String ignoredTitle, ReqContext ctx, TagSearchReq request, List<Long> results) {

		setUnusedBindingAllowed(true);
		getJdbi().useHandle(handle -> {
			handle.begin();

			List<String> initScripts = List.of("tag_service");
			execSqlFiles(this.getClass(), initScripts, testScriptParams);

			List<Tag> list = this.service.searchTags(ctx,
							request, null)
					.getRecords();
			List<Long> actual = list.stream()
					.map(Tag::getId)
					.collect(Collectors.toList());
			assertThat(actual, is(results));

			handle.rollback();
		});
	}

	private static Stream<Arguments> test_search_dto() {
		return Stream.of(
				Arguments.of("with_code", reqContext, new TagSearchReq()
								.setI18nCode("l_e")
								.setCode("lol")
						, List.of(-112L)

				),
				Arguments.of("by_i18n_code", reqContext, new TagSearchReq()
								.setI18nCode("bug_en")
						, List.of(-111L)

				),
				Arguments.of("empty", reqContext, new TagSearchReq()
						, List.of(-111L, -112L))
		);
	}

	//	@Test
	//	void test_getById() {
	//
	//		setUnusedBindingAllowed(true);
	//		getJdbi().useHandle(handle -> {
	//			handle.begin();
	//
	//			List<String> initScripts = List.of("tag_service");
	//			execSqlFiles(this.getClass(), initScripts, testScriptParams);
	//
	//			Tag tag = this.service.getTagById(reqContext, -111L).orElseThrow();
	//			assertThat(tag.getCode(), is("BUG"));
	//			assertThat(tag.getI18nCode(), is("bug_en"));
	//
	//			Optional<Tag> noTag = this.service.getTagById(reqContext, -11111111L);
	//			assertThat(noTag.isEmpty(), is(true));
	//
	//			handle.rollback();
	//		});
	//
	//	}
	//
	//	@Test
	//	void test_getByCode() {
	//
	//		setUnusedBindingAllowed(true);
	//		getJdbi().useHandle(handle -> {
	//			handle.begin();
	//
	//			List<String> initScripts = List.of("tag_service");
	//			execSqlFiles(this.getClass(), initScripts, testScriptParams);
	//
	//			Tag tag = this.service.getTagByCode(reqContext, "BUG").orElseThrow();
	//			assertThat(tag.getCode(), is("BUG"));
	//			assertThat(tag.getI18nCode(), is("bug_en"));
	//
	//			Optional<Tag> noTag = this.service.getTagByCode(reqContext, "bug");
	//			assertThat(noTag.isEmpty(), is(true));
	//
	//			handle.rollback();
	//		});
	//
	//	}

}
