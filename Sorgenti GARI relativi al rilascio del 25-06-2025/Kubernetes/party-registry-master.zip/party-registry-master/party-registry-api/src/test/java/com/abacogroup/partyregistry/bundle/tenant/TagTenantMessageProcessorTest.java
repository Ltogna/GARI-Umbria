package com.abacogroup.partyregistry.bundle.tenant;

import static com.abacogroup.bundles.Constants.ALL_TENANTS;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.greaterThanOrEqualTo;

import com.abacogroup.bundles.listener.tenant.TenantMessage;
import com.abacogroup.partyregistry.JdbiTest;
import com.abacogroup.partyregistry.db.dao.TagDAO;
import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

@Slf4j
@ExtendWith(DropwizardExtensionsSupport.class)
class TagTenantMessageProcessorTest extends JdbiTest {

	private final TagTenantMessageProcessor service = getService(TagTenantMessageProcessor.class);

	@Test
	public void testOnMessage() {
		TagDAO dao = getDAO(TagDAO.class);
		Long defaultCount = dao.countAll(ALL_TENANTS);
		assertThat(defaultCount, greaterThanOrEqualTo(0L));

		getJdbi().useHandle(handle -> {
			handle.begin();
			String newTenant = "tnt";

			service.onMessage(new TenantMessage()
					.setTenantId(newTenant));

			assertThat(dao.countAll(ALL_TENANTS), is(defaultCount));
			handle.rollback();
		});
	}

}
