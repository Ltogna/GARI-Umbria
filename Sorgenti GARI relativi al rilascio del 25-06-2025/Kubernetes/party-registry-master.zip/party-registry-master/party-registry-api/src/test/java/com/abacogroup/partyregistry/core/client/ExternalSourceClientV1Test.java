package com.abacogroup.partyregistry.core.client;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.atLeastOnce;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.reset;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;

import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.partyregistry.PartyRegistryApplicationTest;
import com.abacogroup.partyregistry.core.exceptions.ExternalSourceException;
import com.abacogroup.partyregistry.core.exceptions.ExternalSourceException.ErrEnum;
import com.abacogroup.partyregistry.db.dao.ExternalSourceDAO;
import com.abacogroup.partyregistry.db.ntt.ExternalSourceEntity;
import com.abacogroup.partyregistry.dto.v1.ExternalSourceDtoV1;
import com.abacogroup.partyregistry.dto.v1.PartyExternalDtoV1;
import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;
import io.dropwizard.testing.junit5.ResourceExtension;
import jakarta.ws.rs.DefaultValue;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.HeaderParam;
import jakarta.ws.rs.NotFoundException;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.Optional;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

@ExtendWith({ DropwizardExtensionsSupport.class })
class ExternalSourceClientV1Test {


	private static final User USER = new User("test_user", "master");
	private static final PingResource mockResource = spy(new PingResource());
	private static final ResourceExtension EXT = ResourceExtension.builder()
			.setMapper(PartyRegistryApplicationTest.getObjectMapper())
			.addResource(mockResource)
			.build();

	private ExternalSourceDAO externalSourceDAO;
	private ExternalSourceClientV1 externalSourceClientV1;

	@BeforeEach
	void setUp() {
		reset(mockResource);

		externalSourceDAO = mock(ExternalSourceDAO.class);

		externalSourceClientV1 = new ExternalSourceClientV1(EXT.client(), externalSourceDAO);
	}

	// ----- getExternalPartyByCode -----
	@Test
	void test_getExternalPartyByCode_pathParamOk() {
		String sourceCode = "ES_ONE";
		String partyCode = "01234567890";

		given(externalSourceDAO.findByCode(anyString(), anyString()))
				.willReturn(Optional.of(ExternalSourceEntity.builder()
						.setCode(sourceCode)
						.setUrl("http://localhost:0/external/one/parties/{code}")
						.build()));

		ExternalSourceDtoV1 party = externalSourceClientV1.getExternalPartyByCode("it", USER, sourceCode, partyCode);

		assertThat(party).isNotNull()
				.extracting(ExternalSourceDtoV1::getPartyData)
				.extracting(PartyExternalDtoV1::getCode)
				.isEqualTo(partyCode);

		verify(mockResource).getParty1("it", partyCode);
	}

	@Test
	void test_getExternalPartyByCode_queryParamOk() {
		String sourceCode = "ES_TWO";
		String partyCode = "01234567890";

		given(externalSourceDAO.findByCode(anyString(), anyString()))
				.willReturn(Optional.of(ExternalSourceEntity.builder()
						.setCode(sourceCode)
						.setUrl("http://localhost:0/external/two/parties?code={code}")
						.build()));

		ExternalSourceDtoV1 party = externalSourceClientV1.getExternalPartyByCode("it", USER, sourceCode, partyCode);

		assertThat(party).isNotNull()
				.extracting(ExternalSourceDtoV1::getPartyData)
				.extracting(PartyExternalDtoV1::getCode)
				.isEqualTo(partyCode);

		verify(mockResource).getParty2("it", partyCode);
	}

	@Test
	void test_getExternalPartyByCode_sourceCodeNotFound() {
		String sourceCode = "ES_ONE";
		String partyCode = "01234567890";

		given(externalSourceDAO.findByCode(anyString(), anyString()))
				.willReturn(Optional.empty());

		ExternalSourceException externalSourceException = assertThrows(ExternalSourceException.class,
				() -> externalSourceClientV1.getExternalPartyByCode("it", USER, sourceCode, partyCode));

		assertThat(externalSourceException).isNotNull()
				.extracting(ExternalSourceException::getCode).isEqualTo(ErrEnum.SOURCE_CODE_NOT_FOUND.toString());

		verifyNoInteractions(mockResource);
	}

	@Test
	void test_getExternalPartyByCode_partyNotFound() {
		String sourceCode = "ES_ONE";
		String partyCode = "01234567890";

		given(externalSourceDAO.findByCode(anyString(), anyString()))
				.willReturn(Optional.of(ExternalSourceEntity.builder()
						.setCode(sourceCode)
						.setUrl("http://localhost:0/external/one/parties/{code}")
						.build()));

		given(mockResource.getParty1(anyString(), anyString()))
				.willThrow(new NotFoundException("test"));

		ExternalSourceException externalSourceException = assertThrows(ExternalSourceException.class,
				() -> externalSourceClientV1.getExternalPartyByCode("it", USER, sourceCode, partyCode));

		assertThat(externalSourceException).isNotNull()
				.extracting(ExternalSourceException::getCode).isEqualTo(ErrEnum.PARTY_NOT_FOUND.toString());

		verify(mockResource).getParty1("it", partyCode);
	}

	@Test
	void test_getExternalPartyByCode_readError() {
		String sourceCode = "ES_THREE";
		String partyCode = "01234567890";

		given(externalSourceDAO.findByCode(anyString(), anyString()))
				.willReturn(Optional.of(ExternalSourceEntity.builder()
						.setCode(sourceCode)
						.setUrl("http://localhost:0/external/three/parties/{code}")
						.build()));

		ExternalSourceException externalSourceException = assertThrows(ExternalSourceException.class,
				() -> externalSourceClientV1.getExternalPartyByCode("it", USER, sourceCode, partyCode));

		assertThat(externalSourceException).isNotNull()
				.extracting(ExternalSourceException::getCode).isEqualTo(ErrEnum.PAYLOAD_NOT_READEABLE.toString());

		verify(mockResource, atLeastOnce()).getParty3("it", partyCode);
	}



	@Path("/")
	public static class PingResource {

		@GET
		@Path("/external/one/parties/{code}")
		public ExternalSourceDtoV1 getParty1(
				@HeaderParam("accept-language") @DefaultValue("en") String lang,
				@PathParam("code") String code) {
			return ExternalSourceDtoV1.builder()
					.setPartyData(PartyExternalDtoV1.builder()
							.setCode(code)
							.setLastName("ONE")
							.build())
					.build();
		}

		@GET
		@Path("/external/two/parties")
		public ExternalSourceDtoV1 getParty2(
				@HeaderParam("accept-language") @DefaultValue("en") String lang,
				@QueryParam("code") String code) {
			return ExternalSourceDtoV1.builder()
					.setPartyData(PartyExternalDtoV1.builder()
							.setCode(code)
							.setLastName("TWO")
							.build())
					.build();
		}

		@GET
		@Path("/external/three/parties/{code}")
		public Response getParty3(
				@HeaderParam("accept-language") @DefaultValue("en") String lang,
				@PathParam("code") String code) {
			return Response.ok("ooook", MediaType.TEXT_PLAIN_TYPE).build();
		}
	}

}
