package com.abacogroup.partyregistry.resources.publicapis;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import com.abacogroup.jdbi.paging.impl.InfiniteListResultsImpl;
import com.abacogroup.partyregistry.PrtTest;
import com.abacogroup.partyregistry.api.v1.LegalStatusResponseV1;
import com.abacogroup.partyregistry.api.v1.req.LegalStatusSearchRequestV1;
import com.abacogroup.partyregistry.core.LegalStatusV1Service;
import com.abacogroup.partyregistry.core.impl.LegalStatusV1ServiceImpl;
import com.abacogroup.partyregistry.resources.WebCliHelper;
import com.abacogroup.partyregistry.resources.req.ReqContext;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;
import io.dropwizard.testing.junit5.ResourceExtension;
import java.util.Map;
import java.util.Optional;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mockito;

@Slf4j
@ExtendWith(DropwizardExtensionsSupport.class)
class LegalStatusPublicResourceTest {

	private final LegalStatusV1Service legalStatusV1Service = Mockito.mock(LegalStatusV1ServiceImpl.class);
	private final ResourceExtension EXT = WebCliHelper.createEXT(new LegalStatusPublicResource(legalStatusV1Service));

	private final ObjectMapper mapper = new ObjectMapper();

	@Test
	@SuppressWarnings("unchecked")
	void test_search() {
		String path = String.format(PrtTest.MASTER_PUBLIC_PATH + "/legal-status");
		LegalStatusSearchRequestV1 searchParams = new LegalStatusSearchRequestV1()
				.setCode("active");
		Map<String, Object> beanMap = mapper.convertValue(searchParams, Map.class);

		WebCliHelper.executeGet(EXT, path, beanMap, WebCliHelper.BASIC_CREDENTIALS, InfiniteListResultsImpl.class);

		ArgumentCaptor<ReqContext> reqCtxCaptor = ArgumentCaptor.forClass(ReqContext.class);
		ArgumentCaptor<LegalStatusSearchRequestV1> searchReqArgumentCaptor = ArgumentCaptor.forClass(LegalStatusSearchRequestV1.class);
		verify(legalStatusV1Service, times(1))
				.search(reqCtxCaptor.capture(), searchReqArgumentCaptor.capture(), eq(null));

		LegalStatusSearchRequestV1 searchRequest = searchReqArgumentCaptor.getValue();
		assertThat(searchRequest.getCode(), is("active"));

		ReqContext reqContext = reqCtxCaptor.getValue();
		assertThat(reqContext.getTenantId(), is("master"));
		assertThat(reqContext.getLang(), is("en"));
		assertThat(reqContext.getUsername(), is(WebCliHelper.BASIC_USERNAME));
	}

	@Test
	void test_getByCode() {
		String code = "active";
		String path = String.format(PrtTest.MASTER_PUBLIC_PATH + "/legal-status/" + code);

		given(legalStatusV1Service.getByCode(Mockito.any(ReqContext.class), Mockito.anyString()))
				.willReturn(Optional.of(LegalStatusResponseV1.builder()
						.setCode(code)
						.setI18nCode("").build()
				));

		LegalStatusResponseV1 response = WebCliHelper.executeGet(EXT, path, null, WebCliHelper.BASIC_CREDENTIALS, LegalStatusResponseV1.class);
		ArgumentCaptor<ReqContext> reqCtxCaptor = ArgumentCaptor.forClass(ReqContext.class);
		verify(legalStatusV1Service, times(1))
				.getByCode(reqCtxCaptor.capture(), eq(code));

		ReqContext reqContext = reqCtxCaptor.getValue();
		assertThat(reqContext.getTenantId(), is("master"));
		assertThat(reqContext.getLang(), is("en"));
		assertThat(reqContext.getUsername(), is(WebCliHelper.BASIC_USERNAME));

		assertThat(response.getCode(), is(code));

	}

}
