package com.abacogroup.partyregistry.resources.publicapis;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import com.abacogroup.jdbi.paging.impl.InfiniteListResultsImpl;
import com.abacogroup.partyregistry.PrtTest;
import com.abacogroup.partyregistry.api.v1.req.TagSearchRequestV1;
import com.abacogroup.partyregistry.core.TagV1Service;
import com.abacogroup.partyregistry.core.impl.TagV1ServiceImpl;
import com.abacogroup.partyregistry.resources.WebCliHelper;
import com.abacogroup.partyregistry.resources.req.ReqContext;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;
import io.dropwizard.testing.junit5.ResourceExtension;
import java.util.List;
import java.util.Map;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mockito;

@Slf4j
@ExtendWith(DropwizardExtensionsSupport.class)
class TagPublicResourceTest {

	private final TagV1Service tagService = Mockito.mock(TagV1ServiceImpl.class);
	private final ResourceExtension EXT = WebCliHelper.createEXT(new TagPublicResource(tagService));

	private final ObjectMapper mapper = new ObjectMapper();

	@Test
	@SuppressWarnings("unchecked")
	void test_search() {
		String path = String.format(PrtTest.MASTER_PUBLIC_PATH + "/tags");
		TagSearchRequestV1 searchParams = new TagSearchRequestV1()
				.setCode("lol");
		Map<String, Object> beanMap = mapper.convertValue(searchParams, Map.class);

		WebCliHelper.executeGet(EXT, path, beanMap, WebCliHelper.BASIC_CREDENTIALS, InfiniteListResultsImpl.class);

		ArgumentCaptor<ReqContext> reqCtxCaptor = ArgumentCaptor.forClass(ReqContext.class);
		ArgumentCaptor<TagSearchRequestV1> searchReqArgumentCaptor = ArgumentCaptor.forClass(TagSearchRequestV1.class);
		verify(tagService, times(1))
				.searchTags(reqCtxCaptor.capture(), searchReqArgumentCaptor.capture(), eq(null));

		TagSearchRequestV1 searchRequest = searchReqArgumentCaptor.getValue();
		assertThat(searchRequest.getCode(), is("lol"));

		ReqContext reqContext = reqCtxCaptor.getValue();
		assertThat(reqContext.getTenantId(), is("master"));
		assertThat(reqContext.getLang(), is("en"));
		assertThat(reqContext.getUsername(), is(WebCliHelper.BASIC_USERNAME));
	}

  @Test
  void test_list() {
	  String path = String.format(PrtTest.MASTER_PUBLIC_PATH + "/tags/list");

	  TagSearchRequestV1 searchParams = new TagSearchRequestV1()
			  .setCode("lol");
	  Map<String, Object> beanMap = mapper.convertValue(searchParams, Map.class);

	  WebCliHelper.executeGet(EXT, path, beanMap, WebCliHelper.BASIC_CREDENTIALS, List.class);

	  ArgumentCaptor<ReqContext> reqCtxCaptor = ArgumentCaptor.forClass(ReqContext.class);
	  ArgumentCaptor<TagSearchRequestV1> searchReqArgumentCaptor = ArgumentCaptor.forClass(TagSearchRequestV1.class);
	  verify(tagService, times(1))
			  .searchTagList(reqCtxCaptor.capture(), searchReqArgumentCaptor.capture());

	  TagSearchRequestV1 searchRequest = searchReqArgumentCaptor.getValue();
	  assertThat(searchRequest.getCode(), is("lol"));

	  ReqContext reqContext = reqCtxCaptor.getValue();
	  assertThat(reqContext.getTenantId(), is("master"));
	  assertThat(reqContext.getLang(), is("en"));
	  assertThat(reqContext.getUsername(), is(WebCliHelper.BASIC_USERNAME));
  }

}
