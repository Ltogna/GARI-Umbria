package com.abacogroup.partyregistry.core.impl;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.mock;

import com.abacogroup.partyregistry.PartyRegistryApplicationTest;
import com.abacogroup.partyregistry.core.dto.PartyEventType;
import com.abacogroup.partyregistry.core.dto.PartyQueueMessage;
import com.abacogroup.partyregistry.db.dao.PartyDAO;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import java.io.IOException;
import java.time.LocalDateTime;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class PartyEventRabbitPublisherTest {

	private final ObjectMapper objectMapper = PartyRegistryApplicationTest.getObjectMapper();
	private PartyEventRabbitPublisher paymentEventPublisher;

	@BeforeEach
	void setUp() throws IOException {
		Connection connection = mock(Connection.class);
		PartyDAO partyDAO = mock(PartyDAO.class);
		given(connection.createChannel()).willReturn(mock(Channel.class));
		paymentEventPublisher = new PartyEventRabbitPublisher(connection, objectMapper, partyDAO);
	}

	// ----- getPayload -----
	@Test
	void test_getPayload_ok() throws Exception {

		var msg = PartyQueueMessage.builder()
				.setTenant("the_tenant")
				.setUsername("the_user")
				.setLang("en")
				.setPartyId(555L)
				.setDate(LocalDateTime.now())
				.setEventType(PartyEventType.NEW_PARTY)
				.build();

		assertThat(paymentEventPublisher.getPayload(msg))
				.isEqualTo(objectMapper.writeValueAsBytes(msg));

	}
}
