package com.abacogroup.partyregistry.core.impl.validaor;

import static com.abacogroup.partyregistry.core.impl.validaor.PartyCodeValidatorImpl.CONFIG_KEY;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;

import com.abacogroup.partyregistry.PartyRegistryApplicationTest;
import com.abacogroup.partyregistry.core.exceptions.ErrCodes;
import com.abacogroup.partyregistry.core.exceptions.InvalidPartyException;
import com.abacogroup.partyregistry.db.dao.PartyDAO;
import com.abacogroup.partyregistry.db.ntt.AppConfigEntity;
import com.abacogroup.partyregistry.db.ntt.PartyEntity;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.Optional;
import lombok.SneakyThrows;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.Test;

class CuaaValidatorImplTest {

	public static final String TENANT = "test_tenant";

	private PartyDAO partyDAO = mock(PartyDAO.class);
	private ObjectMapper objectMapper = PartyRegistryApplicationTest.getObjectMapper();

	private PartyCodeValidatorImpl cuaaValidator = new PartyCodeValidatorImpl(partyDAO, objectMapper);

	// ----- resetField -----
	@Test
	void test_resetField_ok() {

		PartyEntity partyEntity = PartyEntity.builder().setCode("the_cuaa").build();

		cuaaValidator.resetField(partyEntity);

		Assertions.assertThat(partyEntity.getCode()).isNull();

	}

	// ----- validateOnInsert -----
	@Test
	@SneakyThrows
	void test_validateOnInsert_defaultConfigOk() {

		String cuaa = "the_cuaa";
		PartyEntity partyEntity = PartyEntity.builder().setCode(cuaa).build();
		PartyCodeConfiguration cuuaConfiguration = new PartyCodeConfiguration();
		AppConfigEntity validationConfig = AppConfigEntity.builder()
				.setTenantId(TENANT)
				.setConfigurationKey(CONFIG_KEY)
				.setConfiguration(objectMapper.writeValueAsString(cuuaConfiguration))
				.build();
		given(partyDAO.findByTenantAndCode(anyString(), any())).willReturn(Optional.empty());

		cuaaValidator.validateOnInsert(partyEntity, validationConfig);

		verify(partyDAO).findByTenantAndCode(TENANT, cuaa.toUpperCase());

	}

	@Test
	@SneakyThrows
	void test_validateOnInsert_uniqueKo() {

		String cuaa = "the_cuaa";
		PartyEntity partyEntity = PartyEntity.builder().setCode(cuaa).build();
		PartyCodeConfiguration cuuaConfiguration = new PartyCodeConfiguration();
		AppConfigEntity validationConfig = AppConfigEntity.builder()
				.setTenantId(TENANT)
				.setConfigurationKey(CONFIG_KEY)
				.setConfiguration(objectMapper.writeValueAsString(cuuaConfiguration))
				.build();
		given(partyDAO.findByTenantAndCode(anyString(), any()))
				.willReturn(Optional.of(PartyEntity.builder().setId(555L).setCode(cuaa).build()));

		InvalidPartyException invalidPartyException = assertThrows(InvalidPartyException.class,
				() -> cuaaValidator.validateOnInsert(partyEntity, validationConfig));

		Assertions.assertThat(invalidPartyException)
				.extracting("code")
				.isEqualTo(ErrCodes.INVALID_PAYLOAD);
		verify(partyDAO).findByTenantAndCode(TENANT, cuaa.toUpperCase());

	}

	@Test
	@SneakyThrows
	void test_validateOnInsert_mandatoryOk() {

		String cuaa = "the_cuaa";
		PartyEntity partyEntity = PartyEntity.builder().setCode(cuaa).build();
		PartyCodeConfiguration cuuaConfiguration = new PartyCodeConfiguration().setMandatory(true);
		AppConfigEntity validationConfig = AppConfigEntity.builder()
				.setTenantId(TENANT)
				.setConfigurationKey(CONFIG_KEY)
				.setConfiguration(objectMapper.writeValueAsString(cuuaConfiguration))
				.build();
		given(partyDAO.findByTenantAndCode(anyString(), any())).willReturn(Optional.empty());

		cuaaValidator.validateOnInsert(partyEntity, validationConfig);

		verify(partyDAO).findByTenantAndCode(TENANT, cuaa.toUpperCase());
	}

	@Test
	@SneakyThrows
	void test_validateOnInsert_mandatoryKo() {

		String cuaa = null;
		PartyEntity partyEntity = PartyEntity.builder().setCode(cuaa).build();
		PartyCodeConfiguration cuuaConfiguration = new PartyCodeConfiguration().setMandatory(true);
		AppConfigEntity validationConfig = AppConfigEntity.builder()
				.setTenantId(TENANT)
				.setConfigurationKey(CONFIG_KEY)
				.setConfiguration(objectMapper.writeValueAsString(cuuaConfiguration))
				.build();

		InvalidPartyException invalidPartyException = assertThrows(InvalidPartyException.class,
				() -> cuaaValidator.validateOnInsert(partyEntity, validationConfig));

		Assertions.assertThat(invalidPartyException)
				.extracting("code")
				.isEqualTo(ErrCodes.INVALID_PAYLOAD);
		verifyNoInteractions(partyDAO);
	}


	// ----- validateOnUpdate -----
	@Test
	@SneakyThrows
	void test_validateOnUpdate_defaultConfigOk() {
		String cuaa = "the_cuaa";
		PartyEntity partyEntity = PartyEntity.builder().setId(555L).setCode(cuaa).build();
		PartyCodeConfiguration cuuaConfiguration = new PartyCodeConfiguration();
		AppConfigEntity validationConfig = AppConfigEntity.builder()
				.setTenantId(TENANT)
				.setConfigurationKey(CONFIG_KEY)
				.setConfiguration(objectMapper.writeValueAsString(cuuaConfiguration))
				.build();
		given(partyDAO.findCodeById(anyString(), any())).willReturn("ccccc");
		given(partyDAO.findByTenantAndCode(anyString(), any())).willReturn(Optional.empty());

		cuaaValidator.validateOnUpdate(partyEntity, validationConfig);

		verify(partyDAO).findByTenantAndCode(TENANT, cuaa.toUpperCase());
	}

	@Test
	@SneakyThrows
	void test_validateOnUpdate_notEditableOk() {
		String cuaa = "the_cuaa";
		PartyEntity partyEntity = PartyEntity.builder().setId(555L).setCode(cuaa).build();
		PartyCodeConfiguration cuuaConfiguration = new PartyCodeConfiguration().setEditable(false);
		AppConfigEntity validationConfig = AppConfigEntity.builder()
				.setTenantId(TENANT)
				.setConfigurationKey(CONFIG_KEY)
				.setConfiguration(objectMapper.writeValueAsString(cuuaConfiguration))
				.build();
		given(partyDAO.findCodeById(anyString(), any())).willReturn(cuaa);

		cuaaValidator.validateOnUpdate(partyEntity, validationConfig);

		verify(partyDAO).findCodeById(TENANT, 555L);
	}

	@Test
	@SneakyThrows
	void test_validateOnUpdate_notEditableWithActualNullOk() {
		String cuaa = "the_cuaa";
		PartyEntity partyEntity = PartyEntity.builder().setId(555L).setCode(cuaa).build();
		PartyCodeConfiguration cuuaConfiguration = new PartyCodeConfiguration().setEditable(false);
		AppConfigEntity validationConfig = AppConfigEntity.builder()
				.setTenantId(TENANT)
				.setConfigurationKey(CONFIG_KEY)
				.setConfiguration(objectMapper.writeValueAsString(cuuaConfiguration))
				.build();
		given(partyDAO.findCodeById(anyString(), any())).willReturn(null);

		cuaaValidator.validateOnUpdate(partyEntity, validationConfig);

		verify(partyDAO).findCodeById(TENANT, 555L);
	}

	@Test
	@SneakyThrows
	void test_validateOnUpdate_notEditableKo() {
		String cuaa = "the_cuaa";
		PartyEntity partyEntity = PartyEntity.builder().setId(555L).setCode(cuaa).build();
		PartyCodeConfiguration cuuaConfiguration = new PartyCodeConfiguration().setEditable(false);
		AppConfigEntity validationConfig = AppConfigEntity.builder()
				.setTenantId(TENANT)
				.setConfigurationKey(CONFIG_KEY)
				.setConfiguration(objectMapper.writeValueAsString(cuuaConfiguration))
				.build();
		given(partyDAO.findCodeById(anyString(), any())).willReturn("ccccc");

		InvalidPartyException invalidPartyException = assertThrows(InvalidPartyException.class,
				() -> cuaaValidator.validateOnUpdate(partyEntity, validationConfig));

		Assertions.assertThat(invalidPartyException)
				.extracting("code")
				.isEqualTo(ErrCodes.INVALID_PAYLOAD);
		verify(partyDAO).findCodeById(TENANT, 555L);
	}
}
