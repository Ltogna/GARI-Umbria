package com.abacogroup.partyregistry.core.dynamicdoc;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.hasSize;
import static org.mockito.Mockito.mock;

import com.abacogroup.bundles.listener.tenant.TenantMessage;
import com.abacogroup.dynamicdocuments.bean.Document;
import com.abacogroup.dynamicdocuments.bean.InsertDocument;
import com.abacogroup.dynamicdocuments.files.FileStoreSupport;
import com.abacogroup.dynamicdocuments.services.DocumentService;
import com.abacogroup.partyregistry.JdbiTest;
import com.abacogroup.partyregistry.api.PartyDocument;
import com.abacogroup.partyregistry.api.PartyRes;
import com.abacogroup.partyregistry.api.PartyTypeEnum;
import com.abacogroup.partyregistry.bundle.tenant.DynamicDocTenantMessageProcessor;
import com.abacogroup.partyregistry.core.impl.PartyServiceImpl;
import com.abacogroup.partyregistry.resources.req.DocumentSearchReq;
import com.abacogroup.partyregistry.resources.req.PartyCreateReq;
import com.abacogroup.partyregistry.resources.req.ReqContext;
import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;
import java.util.List;
import java.util.Map;
import lombok.SneakyThrows;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

@ExtendWith(DropwizardExtensionsSupport.class)
public class DynamicDocumentIDTest extends JdbiTest {

	private static final String NO_EXTERNAL_SOURCE_CODE = null;
	
	private static final ReqContext reqContext = new ReqContext("some_tenant", "user", "it");
	
	private final PartyDynamicDocumentManager partyDynamicDocumentManager = this.getService(PartyDynamicDocumentManagerImpl.class);
	private final DynamicDocTenantMessageProcessor dynamicDocTenantMessageProcessor = getService(DynamicDocTenantMessageProcessor.class);

	@BeforeEach
	@SneakyThrows
	void setUp() {
		DocumentService documentService = this.getService(DocumentService.class);
		var fileStoreSupport = mock(FileStoreSupport.class);

		this.injectMock(documentService, fileStoreSupport);
		this.injectMock(partyDynamicDocumentManager, documentService);
	}

	@Test
	void testInsertId() {

		getJdbi().useHandle(handle -> {
			handle.begin();

			PartyCreateReq massiveDynReq = (PartyCreateReq) new PartyCreateReq()
					.setPartyType(PartyTypeEnum.L)
					.setLastName("Massive Dynamic".toUpperCase());

			PartyRes party = this.getService(PartyServiceImpl.class).insert(reqContext, massiveDynReq, NO_EXTERNAL_SOURCE_CODE);

			dynamicDocTenantMessageProcessor
					.onMessage(new TenantMessage()
							.setTenantId(reqContext.getTenantId())
					);
			Long partyId = party.getId();

			//-------

			Map<String, Object> passaporto = Map.of(
					"id_type", "passport",
					"release_agent", "Comune di Palermo",
					"release_date", "2021-12-03T00:00:00+02:00",
					"expiration_date", "2031-12-03T00:00:00+02:00",
					"number", "XXXXXXXXXX"
			);
			Document doc = new Document();
			Map<String, Object> fields = DynamicDocumentUtils.createDoc(passaporto);
			doc.setFields(fields);
			InsertDocument insertDocument = new InsertDocument();
			insertDocument.setDoc(doc);
			insertDocument.setBusinessId(partyId);

			PartyDocument partyDocument = partyDynamicDocumentManager.save(reqContext, partyId, PartyDynamicDocumentManager.TYPE_ID_DATA, insertDocument);

			DocumentSearchReq documentSearchReq = new DocumentSearchReq().setPartyId(partyId).setDefinitionCode(PartyDynamicDocumentManager.TYPE_ID_DATA);
			List<PartyDocument> docs = partyDynamicDocumentManager
					.searchByDocType(reqContext, documentSearchReq, null).getRecords();
			assertThat(docs, hasSize(1));

			partyDynamicDocumentManager.expire(reqContext, partyId, partyDocument.getDocumentId());

			assertThat("just expired",
					partyDynamicDocumentManager.searchByDocType(reqContext, documentSearchReq, null).getRecords(),
					hasSize(0));

			//-------------
			handle.rollback();
		});
	}
}
