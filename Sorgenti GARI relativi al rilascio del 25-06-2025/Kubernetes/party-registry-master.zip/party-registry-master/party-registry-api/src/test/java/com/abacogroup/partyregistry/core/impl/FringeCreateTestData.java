package com.abacogroup.partyregistry.core.impl;

import com.abacogroup.partyregistry.JdbiTest;
import com.abacogroup.partyregistry.core.PartyService;
import com.abacogroup.partyregistry.core.PartyTagService;
import com.abacogroup.partyregistry.core.RelationRoleService;
import com.abacogroup.partyregistry.core.RelationTypeService;
import com.abacogroup.partyregistry.db.dao.RelationTypeDAO;
import com.abacogroup.partyregistry.resources.req.ReqContext;
import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.extension.ExtendWith;

@Slf4j
@ExtendWith(DropwizardExtensionsSupport.class)
public class FringeCreateTestData extends JdbiTest {

	private static final String CURRENT_USER = "walternative";
	private static final String TENANT_ID = "fringe";

	private static final ReqContext reqContext =
			new ReqContext(TENANT_ID, CURRENT_USER, "en");

	private final TagServiceImpl tagService = getService(TagServiceImpl.class);

	private final PartyTagService partyTagService = getService(PartyServiceImpl.class);

	private final PartyService partyService = getService(PartyServiceImpl.class);
	private final RelationTypeService relationTypeService = new RelationTypeServiceImpl(getDAO(RelationTypeDAO.class));

	private final RelationRoleService relationRoleService = getService(RelationRoleServiceImpl.class);

	void testMe() {
/*
		PartyCreateRequest massiveDynReq = (PartyCreateRequest) new PartyCreateRequest()
				.setPartyType(PartyTypeEnum.L)
				.setLastName("Massive Dynamic".toUpperCase());

		PartyCreateRequest massiveTechReq = (PartyCreateRequest) new PartyCreateRequest()
				.setPartyType(PartyTypeEnum.L)
				.setLastName("Massive Tech".toUpperCase());

		PartyCreateRequest nasaReq = (PartyCreateRequest) new PartyCreateRequest()
				.setPartyType(PartyTypeEnum.L)
				.setLastName("NASA");

		PartyCreateRequest willBellReq = (PartyCreateRequest) new PartyCreateRequest()
				.setPartyType(PartyTypeEnum.N)
				.setFirstName("WILLIAM")
				.setLastName("BELL")
				.setGender(GenderEnum.M);

		PartyCreateRequest ninaSharpReq = (PartyCreateRequest) new PartyCreateRequest()
				.setPartyType(PartyTypeEnum.N)
				.setFirstName("NINA")
				.setLastName("SHARP")
				.setGender(GenderEnum.F);

		PartyCreateRequest emp_1Req = (PartyCreateRequest) new PartyCreateRequest()
				.setPartyType(PartyTypeEnum.N)
				.setFirstName("JUST")
				.setLastName("AN EMPLOEE")
				.setGender(GenderEnum.M);

		Party massiveDyn = this.partyService.insert(reqContext, massiveDynReq);
		Party massiveTech = this.partyService.insert(reqContext, massiveTechReq);
		Party nasa = this.partyService.insert(reqContext, nasaReq);
		Party willBell = this.partyService.insert(reqContext, willBellReq);
		Party ninaSharp = this.partyService.insert(reqContext, ninaSharpReq);
		Party emp_1 = this.partyService.insert(reqContext, emp_1Req);

		RelationTypeReq employee = RelationTypeReq.builder()
				.setCode("TYPE_EMPLOYEE")
				// .setFlMultiple(0)
				.build();
		RelationTypeReq company = RelationTypeReq.builder()
				.setCode("TYPE_COMPANY")
				// .setFlMultiple(0)
				.build();

		this.relationTypeService.save(reqContext, employee);
		this.relationTypeService.save(reqContext, company);

		RelationRoleReq ceo = RelationRoleReq.builder()
				.setCode("ROLE_CEO")
				.setTypeCode("TYPE_EMPLOYEE")
				.build();

		RelationRoleReq cto = RelationRoleReq.builder()
				.setCode("ROLE_CTO")
				.setTypeCode("TYPE_EMPLOYEE")
				.build();

		RelationRoleReq manager = RelationRoleReq.builder()
				.setCode("ROLE_MANAGER")
				.setTypeCode("TYPE_EMPLOYEE")
				.build();

		RelationRoleReq supplier = RelationRoleReq.builder()
				.setCode("ROLE_SUPPLIER")
				.setTypeCode("TYPE_COMPANY")
				.build();

		RelationRoleReq subsidiary = RelationRoleReq.builder()
				.setCode("role_subsidiary".toUpperCase())
				.setTypeCode("TYPE_COMPANY")
				.build();

		relationRoleService.save(reqContext, ceo);
		relationRoleService.save(reqContext, cto);
		relationRoleService.save(reqContext, manager);
		relationRoleService.save(reqContext, supplier);
		relationRoleService.save(reqContext, subsidiary);

		String tagTECH = "TECH";
		String tagFinance = "FINANCE";
		String tagRTW = "RULE_THE_WORLD";
		String tagSpace = "SPACE";

		ReqContext reqContext = new ReqContext(TENANT_ID, CURRENT_USER, "en");

		tagService.save(reqContext, TagReq.builder()
				.setCode(tagTECH)
				.build());
		tagService.save(reqContext, TagReq.builder()
				.setCode(tagFinance)
				.build());
		tagService.save(reqContext, TagReq.builder()
				.setCode(tagRTW)
				.build());
		tagService.save(reqContext, TagReq.builder()
				.setCode(tagSpace)
				.build());

		partyTagService.attachTag(reqContext, massiveDyn.getId(), tagRTW);
		partyTagService.attachTag(reqContext, massiveDyn.getId(), tagTECH);
		partyTagService.attachTag(reqContext, massiveDyn.getId(), tagFinance);

		partyTagService.attachTag(reqContext, massiveTech.getId(), tagTECH);
		partyTagService.attachTag(reqContext, nasa.getId(), tagSpace);

		partyTagService.attachTag(reqContext, willBell.getId(), tagRTW);
		partyTagService.attachTag(reqContext, ninaSharp.getId(), tagFinance);*/

	}
}
