package com.abacogroup.partyregistry.bundle.tenant;

import static com.abacogroup.bundles.Constants.ALL_TENANTS;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.greaterThanOrEqualTo;
import static org.hamcrest.Matchers.notNullValue;
import static org.junit.jupiter.api.Assertions.assertTrue;

import com.abacogroup.bundles.listener.tenant.TenantMessage;
import com.abacogroup.dynamicdocuments.services.DocumentTypeService;
import com.abacogroup.partyregistry.JdbiTest;
import com.abacogroup.partyregistry.api.DocType;
import com.abacogroup.partyregistry.core.BundleConstants;
import com.abacogroup.partyregistry.core.impl.DocTypeServiceImpl;
import com.abacogroup.partyregistry.db.dao.DocTypeDAO;
import com.abacogroup.partyregistry.resources.req.ReqContext;
import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;
import java.util.Optional;
import lombok.extern.slf4j.Slf4j;
import org.hamcrest.Matchers;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

@Slf4j
@ExtendWith(DropwizardExtensionsSupport.class)
class DynamicDocTenantMessageProcessorTest extends JdbiTest {

	private final DynamicDocTenantMessageProcessor processor = getService(DynamicDocTenantMessageProcessor.class);
	private final TagTenantMessageProcessor tagProcessor = getService(TagTenantMessageProcessor.class);
	private final DocumentTypeService documentTypeService = getService(DocumentTypeService.class);
	private final DocTypeServiceImpl docTypeService = getService(DocTypeServiceImpl.class);

	@Test
	public void testOnMessage() {

		assertThat(processor, notNullValue());
		DocTypeDAO dao = getDAO(DocTypeDAO.class);
		int defaultCount = dao.findAll(ALL_TENANTS).size();
		assertThat(defaultCount, greaterThanOrEqualTo(0));

		getJdbi().useHandle(handle -> {
			handle.begin();
			String newTenant = "tnt";
			TenantMessage tenantMessage = new TenantMessage().setTenantId(newTenant);
			tagProcessor.onMessage(tenantMessage);

			processor.onMessage(tenantMessage);

			assertThat(dao.findAll(newTenant).size(), is(defaultCount));
			assertThat(documentTypeService.getDocumentDefinition(newTenant, "ID"), is(notNullValue()));

			ReqContext ctx = new ReqContext(newTenant, BundleConstants.SYSTEM_USER);

			Optional<DocType> docType = docTypeService.getByDocType(ctx, "BANK");
			assertTrue(docType.isPresent());
			assertThat(docType.get().getDocGroup(), Matchers.is("finanziaria"));

			String sqlTags = "select t.tag_code " +
					"from prt_doc_type_tags rel " +
					"join prt_doc_type pdt on pdt.id = rel.doc_type_id " +
					"join prt_tags t on t.id = rel.tag_id " +
					"where pdt.doc_type = ? " +
					"and pdt.tenant_id = ?" +
					"and (§current_timestamp§ between pdt.dt_insert and pdt.dt_delete) " +
					"and (§current_timestamp§ between rel.dt_insert and rel.dt_delete) ";
			org.assertj.core.api.Assertions.assertThat(handle.select(sqlTags, "ID", newTenant).mapTo(String.class).list())
					.containsExactlyInAnyOrder("INQUILINO", "FORNITORE");
			org.assertj.core.api.Assertions.assertThat(handle.select(sqlTags, "BANK", newTenant).mapTo(String.class).list())
					.containsExactlyInAnyOrder("INQUILINO");
			org.assertj.core.api.Assertions.assertThat(handle.select(sqlTags, "EARNINGS", newTenant).mapTo(String.class).list()).isEmpty();
			org.assertj.core.api.Assertions.assertThat(handle.select(sqlTags, "EINVOICING", newTenant).mapTo(String.class).list()).isEmpty();

			String sqlTypes = "select rel.party_type " +
					"from prt_doc_type_relations rel " +
					"join prt_doc_type pdt on pdt.id = rel.doc_type_id " +
					"where pdt.doc_type = ? " +
					"and pdt.tenant_id = ?" +
					"and (§current_timestamp§ between pdt.dt_insert and pdt.dt_delete) " +
					"and (§current_timestamp§ between rel.dt_insert and rel.dt_delete) ";
			org.assertj.core.api.Assertions.assertThat(handle.select(sqlTypes, "ID", newTenant).mapTo(String.class).list())
					.containsExactlyInAnyOrder("N");
			org.assertj.core.api.Assertions.assertThat(handle.select(sqlTypes, "BANK", newTenant).mapTo(String.class).list())
					.containsExactlyInAnyOrder("N", "L");
			org.assertj.core.api.Assertions.assertThat(handle.select(sqlTypes, "EARNINGS", newTenant).mapTo(String.class).list())
					.containsExactlyInAnyOrder("N", "L");
			org.assertj.core.api.Assertions.assertThat(handle.select(sqlTypes, "EINVOICING", newTenant).mapTo(String.class).list())
					.containsExactlyInAnyOrder("N", "L");

			handle.rollback();
		});
	}

}
