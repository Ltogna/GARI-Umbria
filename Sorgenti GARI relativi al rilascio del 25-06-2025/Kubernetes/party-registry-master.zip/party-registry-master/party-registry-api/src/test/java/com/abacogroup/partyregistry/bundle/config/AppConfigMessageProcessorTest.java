package com.abacogroup.partyregistry.bundle.config;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.containsInAnyOrder;
import static org.junit.jupiter.api.Assertions.assertThrows;

import com.abacogroup.bundles.initializer.impl.FileSupport;
import com.abacogroup.bundles.initializer.impl.exceptions.BundleException;
import com.abacogroup.bundles.listener.configdata.ConfigDataMessage;
import com.abacogroup.partyregistry.JdbiTest;
import com.abacogroup.partyregistry.db.dao.AppConfigDAO;
import com.abacogroup.partyregistry.db.ntt.AppConfigEntity;
import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;
import java.nio.file.Path;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;
import lombok.extern.slf4j.Slf4j;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

@Slf4j
@ExtendWith(DropwizardExtensionsSupport.class)
class AppConfigMessageProcessorTest extends JdbiTest {

	public static final String TENANT = "appConfigBundleTenant";
	public static final String BUNDLE_PATH = "src/test/resources/com/abacogroup/partyregistry/bundle/config/AppConfigMessageProcessorTest";

	private final AppConfigMessageProcessor processor = getService(AppConfigMessageProcessor.class);

	@Test
	public void testOnMessage() {
		List<Path> paths = FileSupport.listFilesRecursive(Path.of(BUNDLE_PATH, "app_configs_01.json"));
		ConfigDataMessage msg = new ConfigDataMessage();
		msg.setConfigFiles(paths);
		msg.setTenantId(TENANT);

		getJdbi().useHandle(handle -> {
			handle.begin();

			AppConfigDAO dao = handle.attach(AppConfigDAO.class);
			assertThat(dao.countAll(TENANT), is(0L));
			processor.onMessage(msg);
			assertThat(dao.countAll(TENANT), is(2L));

			assertThat(dao.findAll(TENANT).stream().map(AppConfigEntity::getConfigurationKey).collect(Collectors.toList()),
					containsInAnyOrder("conf1", "conf2"));

			assertThat("config of confKey code is saved as string",
					dao.findByConfigKeyIn(TENANT, Set.of("conf1")).stream().findFirst().get().getConfiguration(),
					is("{\"k1\":\"v1\"}"));
			handle.rollback();
		});
	}

	@Test
	public void testOnMessage_update() {
		List<Path> paths = FileSupport.listFilesRecursive(Path.of(BUNDLE_PATH, "app_configs_01.json"));
		List<Path> updatePaths = FileSupport.listFilesRecursive(Path.of(BUNDLE_PATH, "app_configs_02.json"));
		ConfigDataMessage msg = new ConfigDataMessage();
		msg.setTenantId(TENANT);

		getJdbi().useHandle(handle -> {
			handle.begin();
			AppConfigDAO dao = handle.attach(AppConfigDAO.class);

			Assertions.assertThat(dao.findAll(TENANT)).hasSize(0);

			msg.setConfigFiles(paths);
			processor.onMessage(msg);

			Assertions.assertThat(dao.findAll(TENANT)).hasSize(2)
					.extracting(AppConfigEntity::getConfigurationKey)
					.containsExactlyInAnyOrder("conf1", "conf2");
			Assertions.assertThat(dao.findByConfigKeyIn(TENANT, List.of("conf2")))
					.element(0)
					.extracting(AppConfigEntity::getConfiguration)
					.isEqualTo("{\"foo\":\"bar\"}");

			msg.setConfigFiles(updatePaths);
			processor.onMessage(msg);

			Assertions.assertThat(dao.findAll(TENANT)).hasSize(3)
					.extracting(AppConfigEntity::getConfigurationKey)
					.containsExactlyInAnyOrder("conf1", "conf2", "conf3");
			Assertions.assertThat(dao.findByConfigKeyIn(TENANT, List.of("conf2")))
					.element(0)
					.extracting(AppConfigEntity::getConfiguration)
					.isEqualTo("{\"newFoo\":\"newBar\"}");

			handle.rollback();
		});
	}

	@Test
	public void testOnMessage_delete() {
		List<Path> paths = FileSupport.listFilesRecursive(Path.of(BUNDLE_PATH, "app_configs_01.json"));
		List<Path> deletePaths = FileSupport.listFilesRecursive(Path.of(BUNDLE_PATH, "app_configs_01.delete.json"));
		ConfigDataMessage msg = new ConfigDataMessage();
		msg.setTenantId(TENANT);

		getJdbi().useHandle(handle -> {
			handle.begin();
			AppConfigDAO dao = handle.attach(AppConfigDAO.class);

			Assertions.assertThat(dao.findAll(TENANT)).hasSize(0);

			msg.setConfigFiles(paths);
			processor.onMessage(msg);

			Assertions.assertThat(dao.findAll(TENANT)).hasSize(2)
					.extracting(AppConfigEntity::getConfigurationKey)
					.containsExactlyInAnyOrder("conf1", "conf2");

			msg.setConfigFiles(deletePaths);
			processor.onMessage(msg);

			Assertions.assertThat(dao.findAll(TENANT)).hasSize(1)
					.extracting(AppConfigEntity::getConfigurationKey)
					.containsExactlyInAnyOrder("conf2");

			handle.rollback();
		});
	}

	@Test
	public void test_onMessage_valid() {
		List<Path> paths = FileSupport.listFilesRecursive(Path.of(BUNDLE_PATH, "app_configs_regex_ok.json"));
		ConfigDataMessage msg = new ConfigDataMessage();
		msg.setConfigFiles(paths);
		msg.setTenantId(TENANT);

		getJdbi().useHandle(handle -> {
			handle.begin();

			AppConfigDAO dao = handle.attach(AppConfigDAO.class);
			assertThat(dao.countAll(TENANT), is(0L));
			processor.onMessage(msg);
			assertThat(dao.countAll(TENANT), is(3L));

			assertThat(dao.findAll(TENANT).stream().map(AppConfigEntity::getConfigurationKey).collect(Collectors.toList()),
					containsInAnyOrder(
							"code_validation",
							"taxCode_validation",
							"vatNumber_validation"
					));

			assertThat("config of confKey code is saved as string",
					dao.findByConfigKeyIn(TENANT, Set.of("code_validation")).stream().findFirst().get().getConfiguration(),
					is("{\"L\":[\"^\\\\d{11}$\"],\"N\":[\"^[a-zA-Z]{6}\\\\d{2}[a-zA-Z]{1}\\\\d{2}[a-zA-Z]{1}\\\\d{3}[a-zA-Z]{1}$\"]}"));
			handle.rollback();
		});
	}

	@Test
	public void test_onMessage_notValid() {
		List<Path> paths = FileSupport.listFilesRecursive(Path.of(BUNDLE_PATH, "app_configs_regex_ko.json"));
		ConfigDataMessage msg = new ConfigDataMessage();
		msg.setConfigFiles(paths);
		msg.setTenantId(TENANT);

		getJdbi().useHandle(handle -> {
			handle.begin();

			AppConfigDAO dao = handle.attach(AppConfigDAO.class);
			assertThat(dao.countAll(TENANT), is(0L));

			BundleException bundleException = assertThrows(BundleException.class, () -> processor.onMessage(msg));
			System.out.println(bundleException.getMessage());

			assertThat(dao.countAll(TENANT), is(0L));

			handle.rollback();
		});
	}
}
