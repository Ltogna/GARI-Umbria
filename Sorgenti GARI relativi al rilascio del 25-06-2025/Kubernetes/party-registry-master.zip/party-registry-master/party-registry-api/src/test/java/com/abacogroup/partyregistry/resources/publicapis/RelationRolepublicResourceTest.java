package com.abacogroup.partyregistry.resources.publicapis;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import com.abacogroup.jdbi.paging.impl.InfiniteListResultsImpl;
import com.abacogroup.partyregistry.PrtTest;
import com.abacogroup.partyregistry.api.v1.RelationRoleResponseV1;
import com.abacogroup.partyregistry.api.v1.req.RelationRoleSearchRequestV1;
import com.abacogroup.partyregistry.core.RelationRoleV1Service;
import com.abacogroup.partyregistry.core.impl.RelationRoleV1ServiceImpl;
import com.abacogroup.partyregistry.resources.WebCliHelper;
import com.abacogroup.partyregistry.resources.req.ReqContext;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;
import io.dropwizard.testing.junit5.ResourceExtension;
import java.util.Map;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mockito;

@ExtendWith(DropwizardExtensionsSupport.class)
class RelationRolepublicResourceTest {

	private final RelationRoleV1Service relationRoleService = Mockito.mock(RelationRoleV1ServiceImpl.class);

	private final ResourceExtension EXT = WebCliHelper.createEXT(new RelationRolePublicResource(relationRoleService));

	private final ObjectMapper mapper = new ObjectMapper();

	@Test
	@SuppressWarnings("unchecked")
	void test_search() {
		String path = String.format(PrtTest.MASTER_PUBLIC_PATH + "/relation-types/TYPE/roles");
		RelationRoleSearchRequestV1 searchParams = new RelationRoleSearchRequestV1()
				.setCode("MOGLIE");
		Map<String, Object> beanMap = mapper.convertValue(searchParams, Map.class);

		WebCliHelper.executeGet(EXT, path, beanMap, WebCliHelper.BASIC_CREDENTIALS, InfiniteListResultsImpl.class);

		ArgumentCaptor<ReqContext> reqCtxCaptor = ArgumentCaptor.forClass(ReqContext.class);
		ArgumentCaptor<RelationRoleSearchRequestV1> requestArgumentCaptor = ArgumentCaptor.forClass(
				RelationRoleSearchRequestV1.class);
		verify(relationRoleService, times(1))
				.search(reqCtxCaptor.capture(), requestArgumentCaptor.capture(), eq("TYPE"), eq(null));

		RelationRoleSearchRequestV1 searchRequest = requestArgumentCaptor.getValue();
		assertThat(searchRequest.getCode(), is("MOGLIE"));

		ReqContext reqContext = reqCtxCaptor.getValue();
		assertThat(reqContext.getTenantId(), is("master"));
		assertThat(reqContext.getLang(), is("en"));
		assertThat(reqContext.getUsername(), is(WebCliHelper.BASIC_USERNAME));

	}

	@Test
	void test_getByCode() {
		String path = String.format(PrtTest.MASTER_PUBLIC_PATH + "/relation-types/TYPE/roles/ROLE");
		RelationRoleResponseV1 relationRole = WebCliHelper.executeGet(EXT, path, null, WebCliHelper.BASIC_CREDENTIALS, RelationRoleResponseV1.class);

		ArgumentCaptor<ReqContext> reqCtxCaptor = ArgumentCaptor.forClass(ReqContext.class);
		verify(relationRoleService, times(1))
				.getByCodeAndType(reqCtxCaptor.capture(), eq("TYPE"), eq("ROLE"));

		ReqContext reqContext = reqCtxCaptor.getValue();
		assertThat(reqContext.getTenantId(), is("master"));
		assertThat(reqContext.getLang(), is("en"));
		assertThat(reqContext.getUsername(), is(WebCliHelper.BASIC_USERNAME));
	}
}
