package com.abacogroup.partyregistry.resources.mappers;

import com.abacogroup.partyregistry.api.AppConfig;
import com.abacogroup.partyregistry.api.AppConfigRes;
import lombok.SneakyThrows;
import org.hamcrest.CoreMatchers;
import org.hamcrest.MatcherAssert;
import org.junit.jupiter.api.Test;
import org.mapstruct.factory.Mappers;

class AppConfigMapperTest {

	@Test
	@SneakyThrows
	void test_appConfigToAppConfigRes() {
		AppConfigMapper appConfigTestMapper = Mappers.getMapper(AppConfigMapper.class);

		AppConfig appConfig = AppConfig.
				builder()
				.setConfigurationKey("key1")
				.setConfiguration("{\"show\": false,\"unique\": true,\"mandatory\": false,\"nbr\": 6,\"default\": \"no value\"}")
				.build();

		AppConfigRes res = appConfigTestMapper.toConfigRes(appConfig);
		MatcherAssert.assertThat(res, CoreMatchers.notNullValue());
		MatcherAssert.assertThat(res.getConfigurationKey(), CoreMatchers.is("key1"));
		MatcherAssert.assertThat(res.getConfiguration().size(), CoreMatchers.is(5));
		MatcherAssert.assertThat(res.getConfiguration().get("show"), CoreMatchers.is(false));
		MatcherAssert.assertThat(res.getConfiguration().get("unique"), CoreMatchers.is(true));
		MatcherAssert.assertThat(res.getConfiguration().get("mandatory"), CoreMatchers.is(false));
		MatcherAssert.assertThat(res.getConfiguration().get("nbr"), CoreMatchers.is(6));
		MatcherAssert.assertThat(res.getConfiguration().get("default"), CoreMatchers.is("no value"));

	}

}
