package com.abacogroup.partyregistry.resources.publicapis;

import static com.abacogroup.partyregistry.PrtTest.TENANT_DEFAULT_CODE;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.jdbi.paging.impl.InfiniteListResultsImpl;
import com.abacogroup.partyregistry.PrtTest;
import com.abacogroup.partyregistry.api.ContactSearchResponse;
import com.abacogroup.partyregistry.api.ContactTypeEnum;
import com.abacogroup.partyregistry.api.v1.ContactSearchResponseV1;
import com.abacogroup.partyregistry.core.AclService;
import com.abacogroup.partyregistry.core.impl.ContactServiceImpl;
import com.abacogroup.partyregistry.resources.WebCliHelper;
import com.abacogroup.partyregistry.resources.req.ContactSearchReq;
import com.abacogroup.partyregistry.resources.req.ReqContext;
import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;
import io.dropwizard.testing.junit5.ResourceExtension;
import jakarta.ws.rs.core.GenericType;
import jakarta.ws.rs.core.UriBuilder;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.assertj.core.api.Assertions;
import org.hamcrest.Matchers;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mockito;

@ExtendWith(DropwizardExtensionsSupport.class)
class PartyContactsPublicResourceTest {

	private final AclService aclService = Mockito.mock(AclService.class);
	private final ContactServiceImpl contactService = Mockito.mock(ContactServiceImpl.class);

	private final PartyContactsPublicResource resource = new PartyContactsPublicResource(aclService, contactService);
	private final ResourceExtension EXT = WebCliHelper.createEXT(resource);

	// ----- search -----
	@Test
	void test_search_ok() {

		Long partyId = PrtTest.PARTY999;

		ContactSearchReq request = new ContactSearchReq()
				.setPartyId(partyId)
				.setSubType("xyz")
				.setContactType(ContactTypeEnum.PHONE)
				.setContactValue("11");

		var mockRes = ContactSearchResponse.builder()
				.setPartyId(partyId)
				.setContactType(ContactTypeEnum.PHONE)
				.setContactValue("555-321321")
				.build();
		given(contactService.search(any(), any(), any()))
				.willReturn(new InfiniteListResultsImpl<>(List.of(mockRes), null));

		Map<String, Object> queryMap = new HashMap<>(EXT.getObjectMapper().convertValue(request, Map.class));
		queryMap.put("nextKey", "111");

		UriBuilder uriBuilder = UriBuilder.fromResource(resource.getClass());//.path(resource.getClass(), "search");
		queryMap.forEach(uriBuilder::queryParam);
		String uri = uriBuilder.build(TENANT_DEFAULT_CODE, partyId).toString();
		System.out.println(uri);

		InfiniteListResultsImpl<ContactSearchResponseV1> res = EXT.getJerseyTest().client()
				.target(UriBuilder.fromUri(uri))
				.request()
				.header("Authorization", WebCliHelper.BASIC_CREDENTIALS)
				.get(new GenericType<>() {
				});

		Assertions.assertThat(res).isNotNull()
				.extracting(InfiniteListResults::getRecords)
				.asList().hasSize(1)
				.element(0)
				.usingRecursiveComparison()
				.isEqualTo(mockRes);

		ArgumentCaptor<ReqContext> reqCtxCaptor = ArgumentCaptor.forClass(ReqContext.class);
		ArgumentCaptor<ContactSearchReq> argumentCaptor = ArgumentCaptor.forClass(ContactSearchReq.class);
		verify(contactService, times(1)).
				search(reqCtxCaptor.capture(), argumentCaptor.capture(), eq("111"));
		ContactSearchReq searchRequest = argumentCaptor.getValue();

		assertThat(searchRequest.getContactType(), is(ContactTypeEnum.PHONE));
		assertThat(searchRequest.getContactValue(), is("11"));
		assertThat(searchRequest.getPartyId(), is(partyId));

		ReqContext reqContext = reqCtxCaptor.getValue();
		assertThat(reqContext.getTenantId(), Matchers.is("master"));
		assertThat(reqContext.getLang(), Matchers.is("en"));
		assertThat(reqContext.getUsername(), Matchers.is(WebCliHelper.BASIC_USERNAME));

	}
}
