package com.abacogroup.partyregistry.resources;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import com.abacogroup.dynamicdocuments.bean.Document;
import com.abacogroup.dynamicdocuments.bean.InsertDocument;
import com.abacogroup.jdbi.paging.impl.InfiniteListResultsImpl;
import com.abacogroup.partyregistry.JdbiTest;
import com.abacogroup.partyregistry.PrtTest;
import com.abacogroup.partyregistry.api.PartyDocument;
import com.abacogroup.partyregistry.core.AclService;
import com.abacogroup.partyregistry.core.dynamicdoc.PartyDynamicDocumentManager;
import com.abacogroup.partyregistry.core.dynamicdoc.PartyDynamicDocumentManagerImpl;
import com.abacogroup.partyregistry.resources.req.DocumentSearchReq;
import com.abacogroup.partyregistry.resources.req.ReqContext;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;
import io.dropwizard.testing.junit5.ResourceExtension;
import jakarta.ws.rs.core.Response;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.util.Map;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mockito;

@Slf4j
@ExtendWith(DropwizardExtensionsSupport.class)
class PartyDocumentsResourceTest extends JdbiTest {

	private final AclService aclService = Mockito.mock(AclService.class);
	private final PartyDynamicDocumentManager documentManager = Mockito.mock(PartyDynamicDocumentManagerImpl.class);

	private final ResourceExtension EXT = WebCliHelper.createEXT(new PartyDocumentsResource(aclService, documentManager));

	@Test
	void test_execute_search() {
		String path = String.format(PrtTest.MASTER_PATH + "/parties/-999/documents/type/BANK");
		DocumentSearchReq documentSearchReq = new DocumentSearchReq()
				.setDocumentId(1L);

		ObjectMapper mapper = new ObjectMapper();
		Map<String, Object> beanMap = mapper.convertValue(documentSearchReq, Map.class);

		WebCliHelper.executeGet(EXT, path, beanMap, WebCliHelper.BASIC_CREDENTIALS, InfiniteListResultsImpl.class);

		ArgumentCaptor<ReqContext> reqCtxCaptor = ArgumentCaptor.forClass(ReqContext.class);
		ArgumentCaptor<DocumentSearchReq> requestArgumentCaptor = ArgumentCaptor.forClass(DocumentSearchReq.class);
		verify(documentManager, times(1))
				.searchByDocType(reqCtxCaptor.capture(), requestArgumentCaptor.capture(), eq(null));

		DocumentSearchReq searchRequest = requestArgumentCaptor.getValue();
		assertThat(searchRequest.getDocumentId(), is(1L));
		assertThat(searchRequest.getPartyId(), is(-999L));
		assertThat(searchRequest.getDefinitionCode(), is("BANK"));

		ReqContext reqContext = reqCtxCaptor.getValue();
		assertThat(reqContext.getTenantId(), is("master"));
		assertThat(reqContext.getLang(), is("en"));
		assertThat(reqContext.getUsername(), is(WebCliHelper.BASIC_USERNAME));
	}

	@Test
	void test_get_by_documentId() {
		String path = String.format(PrtTest.MASTER_PATH + "/parties/-999/documents/type/BANK/1");
		given(documentManager.getByDocumentIdAndCode(Mockito.any(), Mockito.any(), Mockito.any()))
				.willReturn(new PartyDocument());
		WebCliHelper.executeGet(EXT, path, null, WebCliHelper.BASIC_CREDENTIALS, InfiniteListResultsImpl.class);
		ArgumentCaptor<ReqContext> reqCtxCaptor = ArgumentCaptor.forClass(ReqContext.class);
		verify(documentManager, times(1))
				.getByDocumentIdAndCode(reqCtxCaptor.capture(), eq(1L), eq("BANK"));

		ReqContext reqContext = reqCtxCaptor.getValue();
		assertThat(reqContext.getTenantId(), is("master"));
		assertThat(reqContext.getLang(), is("en"));
		assertThat(reqContext.getUsername(), is(WebCliHelper.BASIC_USERNAME));
	}

	@Test
	void test_add() {
		Document reqDoc = new Document();
		LocalDate localDate = LocalDate.parse("2020-01-01");
		LocalTime localTime = LocalTime.parse("00:00:00");
		OffsetDateTime date = OffsetDateTime.of(localDate, localTime, ZoneOffset.UTC);
		reqDoc.setValidFrom(date);
		InsertDocument req = new InsertDocument();
		req.setDoc(reqDoc);
		String path = String.format(PrtTest.MASTER_PATH + "/parties/-999/documents/type/BANK");
		given(documentManager.save(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
				.willReturn(PartyDocument.builder()
						.setDocumentId(-1L)
						.build());
		PartyDocument res = WebCliHelper.executePost(EXT, path, req, WebCliHelper.BASIC_CREDENTIALS, PartyDocument.class);

		ArgumentCaptor<ReqContext> reqCtxCaptor = ArgumentCaptor.forClass(ReqContext.class);
		ArgumentCaptor<InsertDocument> docArgumentCaptor = ArgumentCaptor.forClass(InsertDocument.class);
		verify(documentManager, times(1))
				.save(reqCtxCaptor.capture(), eq(-999L), eq("BANK"), docArgumentCaptor.capture());

		InsertDocument doc = docArgumentCaptor.getValue();
		assertThat(doc.getDoc().getValidFrom().toInstant().atOffset(ZoneOffset.UTC), is(date));

		ReqContext reqContext = reqCtxCaptor.getValue();
		assertThat(reqContext.getTenantId(), is("master"));
		assertThat(reqContext.getLang(), is("en"));
		assertThat(reqContext.getUsername(), is(WebCliHelper.BASIC_USERNAME));
	}

	@Test
	void test_put() {
		Document req = new Document();
		LocalDate localDate = LocalDate.parse("2020-01-01");
		LocalTime localTime = LocalTime.parse("00:00:00");
		OffsetDateTime from = OffsetDateTime.of(localDate, localTime, ZoneOffset.UTC);
		req.setValidFrom(from);
		localDate = LocalDate.parse("9999-12-31");
		localTime = LocalTime.parse("00:00:00");
		OffsetDateTime to = OffsetDateTime.of(localDate, localTime, ZoneOffset.UTC);
		req.setValidTo(to);
		String path = String.format(PrtTest.MASTER_PATH + "/parties/-999/documents/type/BANK/1");
		given(documentManager.update(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
				.willReturn(new PartyDocument());
		PartyDocument res = WebCliHelper.executePut(EXT, path, req, WebCliHelper.BASIC_CREDENTIALS, PartyDocument.class);

		ArgumentCaptor<ReqContext> reqCtxCaptor = ArgumentCaptor.forClass(ReqContext.class);
		ArgumentCaptor<Document> docArgumentCaptor = ArgumentCaptor.forClass(Document.class);
		verify(documentManager, times(1))
				.update(reqCtxCaptor.capture(), eq(-999L), eq(1L), docArgumentCaptor.capture());

		Document request = docArgumentCaptor.getValue();
		assertThat(request.getValidFrom().toInstant().atOffset(ZoneOffset.UTC), is(from));
		assertThat(request.getValidTo().toInstant().atOffset(ZoneOffset.UTC), is(to));

		ReqContext reqContext = reqCtxCaptor.getValue();
		assertThat(reqContext.getTenantId(), is("master"));
		assertThat(reqContext.getLang(), is("en"));
		assertThat(reqContext.getUsername(), is(WebCliHelper.BASIC_USERNAME));
	}

	@Test
	void test_delete() {

		String path = String.format(PrtTest.MASTER_PATH + "/parties/-999/documents/type/BANK/1");
		WebCliHelper.executeDelete(EXT, path, WebCliHelper.BASIC_CREDENTIALS, Response.class);
		ArgumentCaptor<ReqContext> reqCtxCaptor = ArgumentCaptor.forClass(ReqContext.class);
		verify(documentManager, times(1))
				.expire(reqCtxCaptor.capture(), eq(-999L), eq(1L));
		ReqContext reqContext = reqCtxCaptor.getValue();
		assertThat(reqContext.getTenantId(), is("master"));
		assertThat(reqContext.getLang(), is("en"));
		assertThat(reqContext.getUsername(), is(WebCliHelper.BASIC_USERNAME));
	}
}



