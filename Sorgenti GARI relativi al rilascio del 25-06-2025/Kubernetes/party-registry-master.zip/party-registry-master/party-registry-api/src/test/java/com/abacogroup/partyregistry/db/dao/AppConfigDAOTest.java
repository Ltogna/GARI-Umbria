package com.abacogroup.partyregistry.db.dao;

import static org.junit.jupiter.api.Assertions.assertThrows;

import com.abacogroup.partyregistry.JdbiTest;
import com.abacogroup.partyregistry.core.impl.AuditHelper;
import com.abacogroup.partyregistry.db.ntt.AppConfigEntity;
import com.abacogroup.partyregistry.db.ntt.AppConfigEntity.AppConfigEntityBuilder;
import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.assertj.core.api.Assertions;
import org.jdbi.v3.core.statement.UnableToExecuteStatementException;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

@ExtendWith(DropwizardExtensionsSupport.class)
class AppConfigDAOTest extends JdbiTest {

	private static final String TENANT_ID = String.format("%s_t", AppConfigDAOTest.class.getSimpleName());
	private static final String USER_ID = String.format("%s_u", AppConfigDAOTest.class.getSimpleName());
	private static final Map<String, Object> testScriptParams = Map.of(
			"test_tenant", TENANT_ID,
			"user_id", USER_ID
	);

	private final AppConfigDAO dao = getDAO(AppConfigDAO.class);

	// ----- insert -----
	@Test
	void test_insert_ok() {
		getJdbi().useHandle(handle -> {
			handle.begin();

			List<String> initScripts = List.of("add_configs");
			execSqlFiles(AppConfigDAOTest.class, initScripts, testScriptParams);

			AppConfigEntity entity = appConfigEntityBuilder("test2").build();
			AuditHelper.setAuditForInsert(entity, USER_ID, dao);

			Long id = dao.insert(entity);

			Assertions.assertThat(dao.findById(TENANT_ID, id)).isPresent().get()
					.usingRecursiveComparison()
					.ignoringFields("id")
					.isEqualTo(entity);

			handle.rollback();
		});
	}

	@Test
	void test_insert_uniqueKo() {
		getJdbi().useHandle(handle -> {
			handle.begin();

			List<String> initScripts = List.of("add_configs");
			execSqlFiles(AppConfigDAOTest.class, initScripts, testScriptParams);

			AppConfigEntity entity = appConfigEntityBuilder("test1").build();
			AuditHelper.setAuditForInsert(entity, USER_ID, dao);

			assertThrows(UnableToExecuteStatementException.class, () -> dao.insert(entity));

			handle.rollback();
		});
	}

	// ----- insertIdempotent -----
	@Test
	void test_insertIdempotent_ok() {
		getJdbi().useHandle(handle -> {
			handle.begin();

			List<String> initScripts = List.of("add_configs");
			execSqlFiles(AppConfigDAOTest.class, initScripts, testScriptParams);

			AppConfigEntity entity1 = appConfigEntityBuilder("test1").setConfiguration("{\"show\": false}").build();
			AppConfigEntity entity2a = appConfigEntityBuilder("test2").build();
			AppConfigEntity entity2b = appConfigEntityBuilder("test2").setConfiguration("{}").build();
			AppConfigEntity entity3 = appConfigEntityBuilder("test3").build();
			AuditHelper.setAuditForInsert(USER_ID, dao, entity1, entity2a, entity2b, entity3);

			dao.insertIdempotent(entity1, entity2a, entity2b, entity3);

			Assertions.assertThat(dao.findAll(TENANT_ID)).hasSize(3)
					.usingRecursiveFieldByFieldElementComparatorIgnoringFields("id")
					.containsExactlyInAnyOrder(
							dao.findById(TENANT_ID, -1001L).get(),
							entity2a,
							entity3
					);

			handle.rollback();
		});
	}

	// ----- insertNewTenant -----
	@Test
	void test_insertNewTenant_ok() {
		String newTenantId = TENANT_ID + "_new";
		getJdbi().useHandle(handle -> {
			handle.begin();

			List<String> initScripts = List.of("add_configs");
			execSqlFiles(AppConfigDAOTest.class, initScripts, testScriptParams);

			AppConfigEntity entity = appConfigEntityBuilder("only for audit fields").build();
			AuditHelper.setAuditForInsert(entity, USER_ID, dao);

			dao.insertNewTenant("all_tenants", newTenantId, entity);

			AppConfigEntity orig1 = dao.findById("all_tenants", -1L).get();
			AppConfigEntity orig2 = dao.findById("all_tenants", -2L).get();
			Assertions.assertThat(dao.findAll(newTenantId)).hasSize(2)
					.usingRecursiveFieldByFieldElementComparatorIgnoringFields("id")
					.containsExactlyInAnyOrder(
							AppConfigEntity.builder().setConfigurationKey(orig1.getConfigurationKey()).setConfiguration(orig1.getConfiguration())
									.setTenantId(newTenantId).setUserIdInsert(entity.getUserIdInsert())
									.setDtInsert(entity.getDtInsert()).setDtDelete(entity.getDtDelete()).build(),
							AppConfigEntity.builder().setConfigurationKey(orig2.getConfigurationKey()).setConfiguration(orig2.getConfiguration())
									.setTenantId(newTenantId).setUserIdInsert(entity.getUserIdInsert())
									.setDtInsert(entity.getDtInsert()).setDtDelete(entity.getDtDelete()).build()
					);

			handle.rollback();
		});
	}

	// ----- findByConfigKeyIn -----
	@Test
	void test_findByConfigKeyIn_ok() {
		getJdbi().useHandle(handle -> {
			handle.begin();

			List<String> initScripts = List.of("add_multiple_configs");
			execSqlFiles(AppConfigDAOTest.class, initScripts, testScriptParams);

			Assertions.assertThat(dao.findByConfigKeyIn(TENANT_ID, Set.of("test1", "test4", "test5", "test6")))
					.hasSize(4)
					.extracting("id")
					.containsExactlyInAnyOrder(-2001L, -2004L, -2005L, -2006L);

			handle.rollback();
		});
	}

	// ----- searchAll -----
	@Test
	void test_searchAll_ok() {
		getJdbi().useHandle(handle -> {
			handle.begin();

			List<String> initScripts = List.of("add_multiple_configs");
			execSqlFiles(AppConfigDAOTest.class, initScripts, testScriptParams);

			Assertions.assertThat(dao.searchAll(TENANT_ID))
					.hasSize(6);

			handle.rollback();
		});
	}

	// ##################################################################################

	private static AppConfigEntityBuilder<?, ?> appConfigEntityBuilder(String fieldName) {
		return AppConfigEntity.builder()
				.setTenantId(TENANT_ID)
				.setConfigurationKey(fieldName)
				.setConfiguration("{\"show\": true}");
	}

}
