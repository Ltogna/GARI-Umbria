package com.abacogroup.partyregistry.core.dynamicdoc;

import static com.abacogroup.partyregistry.core.dynamicdoc.DynamicDocumentUtils.createDoc;
import static org.hamcrest.CoreMatchers.containsString;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.hasSize;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.mock;

import com.abacogroup.bundles.listener.tenant.TenantMessage;
import com.abacogroup.dynamicdocuments.bean.Document;
import com.abacogroup.dynamicdocuments.bean.InsertDocument;
import com.abacogroup.dynamicdocuments.exceptions.DocumentValidationException;
import com.abacogroup.dynamicdocuments.exceptions.UnknownFieldException;
import com.abacogroup.dynamicdocuments.files.FileStoreSupport;
import com.abacogroup.dynamicdocuments.services.DocumentService;
import com.abacogroup.partyregistry.JdbiTest;
import com.abacogroup.partyregistry.api.PartyDocument;
import com.abacogroup.partyregistry.api.PartyRes;
import com.abacogroup.partyregistry.api.PartyTypeEnum;
import com.abacogroup.partyregistry.bundle.tenant.DynamicDocTenantMessageProcessor;
import com.abacogroup.partyregistry.core.DocTypeService;
import com.abacogroup.partyregistry.core.impl.DocTypeServiceImpl;
import com.abacogroup.partyregistry.core.impl.PartyServiceImpl;
import com.abacogroup.partyregistry.resources.req.DocumentSearchReq;
import com.abacogroup.partyregistry.resources.req.PartyCreateReq;
import com.abacogroup.partyregistry.resources.req.ReqContext;
import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;
import java.time.OffsetDateTime;
import java.util.List;
import java.util.Map;
import lombok.SneakyThrows;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

@ExtendWith(DropwizardExtensionsSupport.class)
public class DynamicDocumentEINVOICINGTest extends JdbiTest {

	private static final String NO_EXTERNAL_SOURCE_CODE = null;
	
	private static final ReqContext reqContext = new ReqContext("some_tenant", "user", "it");
	private final PartyDynamicDocumentManager partyDynamicDocumentManager = this.getService(PartyDynamicDocumentManagerImpl.class);
	private final DynamicDocTenantMessageProcessor dynamicDocTenantMessageProcessor = getService(DynamicDocTenantMessageProcessor.class);

	private final DocTypeService typeService = getService(DocTypeServiceImpl.class);

	@BeforeEach
	@SneakyThrows
	void setUp() {
		DocumentService documentService = this.getService(DocumentService.class);
		var fileStoreSupport = mock(FileStoreSupport.class);

		this.injectMock(documentService, fileStoreSupport);
		this.injectMock(partyDynamicDocumentManager, documentService);
	}

	@Test
	void testInsertExpireEInvoicing() {

		getJdbi().useHandle(handle -> {
			handle.begin();

			PartyCreateReq massiveDynReq = (PartyCreateReq) new PartyCreateReq()
					.setPartyType(PartyTypeEnum.L)
					.setLastName("Massive Dynamic".toUpperCase());

			PartyRes party = this.getService(PartyServiceImpl.class).insert(reqContext, massiveDynReq, NO_EXTERNAL_SOURCE_CODE);

			dynamicDocTenantMessageProcessor
					.onMessage(new TenantMessage()
							.setTenantId(reqContext.getTenantId())
					);
			Long partyId = party.getId();

			assertTrue(typeService.getByDocType(reqContext, PartyDynamicDocumentManager.TYPE_EINVOICING).isPresent());
			assertThat(typeService.getByDocType(reqContext, PartyDynamicDocumentManager.TYPE_EINVOICING).get().isMultiple(), is(false));

			//-------------

			Map<String, Object> invoice = Map.of(
					"recipient_code", "XXXXXXXX",
					"intent_declaration_code", "Intent_Code",
					"declaration_date", "2021-12-03T09:06:00+02:00",
					"decl_expiration_date", "2031-12-03T09:06:00+02:00",
					"country_id", "IT",
					"sender_id", "12345",
					"tax_regime_type", "IT"
			);
			Document doc = new Document();
			InsertDocument ins = new InsertDocument();
			Map<String, Object> fields = createDoc(invoice);
			doc.setFields(fields);
			doc.setValidFrom(OffsetDateTime.now());
			ins.setBusinessId(partyId);
			ins.setDoc(doc);

			PartyDocument partyDocument = partyDynamicDocumentManager.save(reqContext, partyId, PartyDynamicDocumentManager.TYPE_EINVOICING, ins);

			DocumentSearchReq documentSearchReq = new DocumentSearchReq().setPartyId(partyId).setDefinitionCode(PartyDynamicDocumentManager.TYPE_EINVOICING);
			List<PartyDocument> docs = partyDynamicDocumentManager
					.searchByDocType(reqContext, documentSearchReq, null).getRecords();
			assertThat(docs, hasSize(1));

			partyDynamicDocumentManager.expire(reqContext, partyId, partyDocument.getDocumentId());

			assertThat("just expired",
					partyDynamicDocumentManager.searchByDocType(reqContext, documentSearchReq, null).getRecords(),
					hasSize(0));

			//-------------
			handle.rollback();
		});
	}

	@Test
	void testValidationEInvoicing() {
		getJdbi().useHandle(handle -> {
			handle.begin();

			PartyCreateReq massiveDynReq = (PartyCreateReq) new PartyCreateReq()
					.setPartyType(PartyTypeEnum.L)
					.setLastName("Massive Dynamic".toUpperCase());

			PartyRes party = this.getService(PartyServiceImpl.class).insert(reqContext, massiveDynReq, NO_EXTERNAL_SOURCE_CODE);

			dynamicDocTenantMessageProcessor
					.onMessage(new TenantMessage()
							.setTenantId(reqContext.getTenantId())
					);
			Long partyId = party.getId();

			assertTrue(typeService.getByDocType(reqContext, PartyDynamicDocumentManager.TYPE_EINVOICING).isPresent());
			assertThat(typeService.getByDocType(reqContext, PartyDynamicDocumentManager.TYPE_EINVOICING).get().isMultiple(), is(false));

			//-------------

			Map<String, Object> invoice = Map.of(
					"recipient_code", "XXXXXXXX",
					"intent_declaration_code", "Intent_Code",
					"country_id", "IT",
					"sender_id", "12345",
					"tax_regime_type", "IT"
			);
			Document doc = new Document();
			InsertDocument ins = new InsertDocument();
			Map<String, Object> fields = createDoc(invoice);
			doc.setFields(fields);
			doc.setValidFrom(OffsetDateTime.now());
			ins.setBusinessId(partyId);
			ins.setDoc(doc);
			UnknownFieldException ex1 = Assertions.assertThrows(UnknownFieldException.class, () -> {
				partyDynamicDocumentManager
						.save(reqContext, partyId, PartyDynamicDocumentManager.TYPE_EINVOICING, ins);
			});
			assertThat(ex1.getMessage(), containsString("field intent_declaration_code refer to field declaration_date"));
			DynamicDocumentUtils.updateField(doc, "declaration_date", "2021-12-03T09:06:00+02:00");

			//-------------
			ex1 = Assertions.assertThrows(UnknownFieldException.class, () -> {
				partyDynamicDocumentManager
						.save(reqContext, partyId, PartyDynamicDocumentManager.TYPE_EINVOICING, ins);
			});
			assertThat(ex1.getMessage(), containsString("field intent_declaration_code refer to field decl_expiration_date"));
			DynamicDocumentUtils.updateField(doc, "decl_expiration_date", "2031-12-03T09:06:00+02:00");

			//-------------
			DynamicDocumentUtils.updateField(doc, "country_id", "XXX");
			DocumentValidationException ex = Assertions.assertThrows(DocumentValidationException.class, () -> {
				partyDynamicDocumentManager
						.save(reqContext, partyId, PartyDynamicDocumentManager.TYPE_EINVOICING, ins);
			});
			assertThat(ex.getMessage(), containsString(" field country_id contains an invalid value: XXX"));
			DynamicDocumentUtils.updateField(doc, "country_id", "IT");

			//-------------
			DynamicDocumentUtils.updateField(doc, "tax_regime_type", "XXX");
			ex = Assertions.assertThrows(DocumentValidationException.class, () -> {
				partyDynamicDocumentManager
						.save(reqContext, partyId, PartyDynamicDocumentManager.TYPE_EINVOICING, ins);
			});
			assertThat(ex.getMessage(), containsString(" field tax_regime_type contains an invalid value: XXX"));
			DynamicDocumentUtils.updateField(doc, "tax_regime_type", "IT");

			PartyDocument partyDocument = partyDynamicDocumentManager.save(reqContext, partyId, PartyDynamicDocumentManager.TYPE_EINVOICING, ins);

			DocumentSearchReq documentSearchReq = new DocumentSearchReq().setPartyId(partyId).setDefinitionCode(PartyDynamicDocumentManager.TYPE_EINVOICING);
			List<PartyDocument> docs = partyDynamicDocumentManager
					.searchByDocType(reqContext, documentSearchReq, null).getRecords();
			assertThat(docs, hasSize(1));

			partyDynamicDocumentManager.expire(reqContext, partyId, partyDocument.getDocumentId());

			assertThat("just expired",
					partyDynamicDocumentManager.searchByDocType(reqContext, documentSearchReq, null).getRecords(),
					hasSize(0));

			//-------------
			handle.rollback();
		});
	}
}
