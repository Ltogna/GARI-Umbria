package com.abacogroup.partyregistry.resources;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.nullValue;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import com.abacogroup.jdbi.paging.impl.InfiniteListResultsImpl;
import com.abacogroup.partyregistry.PrtTest;
import com.abacogroup.partyregistry.api.Citizenship;
import com.abacogroup.partyregistry.core.impl.CitizenshipServiceImpl;
import com.abacogroup.partyregistry.resources.req.CitizenshipSearchReq;
import com.abacogroup.partyregistry.resources.req.ReqContext;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;
import io.dropwizard.testing.junit5.ResourceExtension;
import java.util.Map;
import java.util.Optional;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mockito;

@ExtendWith(DropwizardExtensionsSupport.class)
@Slf4j
class CitizenshipResourceTest {

	private final CitizenshipServiceImpl citizenshipService = Mockito.mock(CitizenshipServiceImpl.class);

	private final ResourceExtension EXT = WebCliHelper.createEXT(new CitizenshipResource(citizenshipService));

	private final ObjectMapper mapper = new ObjectMapper();


	@Test
	@SuppressWarnings("unchecked")
	void test_search() {
		String path = String.format(PrtTest.MASTER_PATH + "/citizenships");
		CitizenshipSearchReq searchParams = new CitizenshipSearchReq()
				.setCode("TST");
		Map<String, Object> beanMap = mapper.convertValue(searchParams, Map.class);

		WebCliHelper.executeGet(EXT, path, beanMap, WebCliHelper.BASIC_CREDENTIALS, InfiniteListResultsImpl.class);

		ArgumentCaptor<ReqContext> reqCtxCaptor = ArgumentCaptor.forClass(ReqContext.class);

		ArgumentCaptor<CitizenshipSearchReq> requestArgumentCaptor = ArgumentCaptor.forClass(
				CitizenshipSearchReq.class);

		verify(citizenshipService, times(1))
				.search(reqCtxCaptor.capture(), requestArgumentCaptor.capture(), eq(null));

		ReqContext reqContext = reqCtxCaptor.getValue();
		assertThat(reqContext.getTenantId(), is("master"));
		assertThat(reqContext.getLang(), is("en"));
		assertThat(reqContext.getUsername(), is(WebCliHelper.BASIC_USERNAME));

		CitizenshipSearchReq searchRequest = requestArgumentCaptor.getValue();
		assertThat(searchRequest.getCode(), is("TST"));
	}

	@Test
	void test_getByCode() {
		String path = String.format(PrtTest.MASTER_PATH + "/citizenships/TST");
		WebCliHelper.executeGet(EXT, path, null, WebCliHelper.BASIC_CREDENTIALS, Citizenship.class);

		ArgumentCaptor<ReqContext> reqCtxCaptor = ArgumentCaptor.forClass(ReqContext.class);

		verify(citizenshipService, times(1))
				.getByCode(reqCtxCaptor.capture(), eq("TST"));

		ReqContext reqContext = reqCtxCaptor.getValue();
		assertThat(reqContext.getTenantId(), is("master"));
		assertThat(reqContext.getLang(), is("en"));
		assertThat(reqContext.getUsername(), is(WebCliHelper.BASIC_USERNAME));
	}

	@Test
	void test_getByCode_null() {

		ArgumentCaptor<ReqContext> reqCtxCaptor = ArgumentCaptor.forClass(ReqContext.class);

		given(citizenshipService.getByCode(reqCtxCaptor.capture(), eq("XXX")))
				.willReturn(Optional.empty());
		String path = String.format(PrtTest.MASTER_PATH + "/citizenships/XXX");
		Citizenship citizenship = WebCliHelper.executeGet(EXT, path, null, WebCliHelper.BASIC_CREDENTIALS, Citizenship.class);

		ReqContext reqContext = reqCtxCaptor.getValue();
		assertThat(reqContext.getTenantId(), is("master"));
		assertThat(reqContext.getLang(), is("en"));
		assertThat(reqContext.getUsername(), is(WebCliHelper.BASIC_USERNAME));

		ArgumentCaptor<ReqContext> reqCtxCaptor1 = ArgumentCaptor.forClass(ReqContext.class);
		verify(citizenshipService, times(1))
				.getByCode(reqCtxCaptor1.capture(), eq("XXX"));

		assertThat(citizenship, nullValue());

		ReqContext reqContext1 = reqCtxCaptor1.getValue();
		assertThat(reqContext1.getTenantId(), is("master"));
		assertThat(reqContext1.getLang(), is("en"));
		assertThat(reqContext1.getUsername(), is(WebCliHelper.BASIC_USERNAME));
	}

	/*
	@Test
	void test_insert() {
		CitizenshipReq citizenshipReq = CitizenshipReq.builder()
				.setCode("DEV")
				.build();

		String uri = PrtTest.MASTER_PATH + "/citizenships";

		Citizenship response = WebCliHelper.executePost(EXT, uri, citizenshipReq, WebCliHelper.BASIC_CREDENTIALS,
				Citizenship.class);

		ArgumentCaptor<ReqContext> reqCtxCaptor = ArgumentCaptor.forClass(ReqContext.class);
		verify(citizenshipService, times(1))
				.save(reqCtxCaptor.capture(), eq(citizenshipReq));

		ReqContext reqContext = reqCtxCaptor.getValue();
		assertThat(reqContext.getTenantId(), is("master"));
		assertThat(reqContext.getLang(), is("en"));
		assertThat(reqContext.getUsername(), is(WebCliHelper.BASIC_USERNAME));
	}

	@Test
	void test_update() {
		assertThat("there is no update", true, is(true));
	}

	@Test
	void test_delete() {
		assertThat("there is no delete", true, is(true));
	}

	@ParameterizedTest
	@MethodSource
	void test_validate_input(String ignoredTitle, Citizenship req, List<String> expErrors) {
		String uri = PrtTest.MASTER_PATH + "/citizenships";
		Function<Citizenship, Citizenship> exec = x -> WebCliHelper.executePost(EXT, uri, x,
				WebCliHelper.BASIC_CREDENTIALS,
				Citizenship.class);

		if (expErrors.isEmpty()) {
			exec.apply(req);
			return;
		}

		ClientErrorException ex = Assertions.assertThrows(ClientErrorException.class, () -> {
			exec.apply(req);
		});
		List<String> errors = FieldErrorUtils.extractErrorFieldNames(ex);
		assertThat(errors, containsInAnyOrder(expErrors.toArray()));
	}

		private static Stream<Arguments> test_validate_input() {
		return Stream.of(
				Arguments.of("empty_req", new Citizenship()
						, List.of("code"))

				, Arguments.of("empty_req2", Citizenship.builder()
								.setCode("  ")
								.build()
						, List.of("code"))

				, Arguments.of("invalid chars aaa", Citizenship.builder()
								.setCode("aaa")
								.build()
						, List.of("code"))

				, Arguments.of("invalid chars AA@", Citizenship.builder()
								.setCode("AA@")
								.build()
						, List.of("code"))

				, Arguments.of("ko length", Citizenship.builder()
								.setCode(StringUtils.repeat("A", 4))
								.build()
						, List.of("code"))

				, Arguments.of("ok length", Citizenship.builder()
								.setCode("AAA")
								.build()
						, List.of())
		);
	}

	*/

}
