package com.abacogroup.partyregistry.resources;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.nullValue;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import com.abacogroup.jdbi.paging.impl.InfiniteListResultsImpl;
import com.abacogroup.partyregistry.PrtTest;
import com.abacogroup.partyregistry.api.RelationType;
import com.abacogroup.partyregistry.core.impl.RelationTypeServiceImpl;
import com.abacogroup.partyregistry.resources.req.RelationTypeSearchReq;
import com.abacogroup.partyregistry.resources.req.ReqContext;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;
import io.dropwizard.testing.junit5.ResourceExtension;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Stream;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.provider.Arguments;
import org.mockito.ArgumentCaptor;
import org.mockito.Mockito;

@ExtendWith(DropwizardExtensionsSupport.class)
@Slf4j
class RelationTypeResourceTest {

	private final RelationTypeServiceImpl relationTypeService = Mockito.mock(RelationTypeServiceImpl.class);

	private final ResourceExtension EXT = WebCliHelper.createEXT(new RelationTypeResource(relationTypeService));

	private final ObjectMapper mapper = new ObjectMapper();

	private static Stream<Arguments> test_validate_input() {
		return Stream.of(
				Arguments.of("empty_req", new RelationType()
						, List.of("code"))

				, Arguments.of("empty_req2", RelationType.builder()
								.setCode("")
								.build()
						, List.of("code"))

				, Arguments.of("invalid chars aaa", RelationType.builder()
								.setCode("aaa")
								.setMultiple(true)
								.build()
						, List.of("code"))

				, Arguments.of("invalid chars AA@", RelationType.builder()
								.setCode("AA@")
								.setMultiple(true)
								.build()
						, List.of("code"))

				, Arguments.of("ko length", RelationType.builder()
								.setCode(StringUtils.repeat("A", 101))
								.setMultiple(true)
								.build()
						, List.of("code"))

				, Arguments.of("ok length", RelationType.builder()
								.setCode(StringUtils.repeat("A", 20))
								.setMultiple(true)
								.build()
						, List.of())

				, Arguments.of("multiple invalid", RelationType.builder()
								.setCode("AA")
								.setMultiple(true)
								.build()
						, List.of())

		);
	}

	@Test
	@SuppressWarnings("unchecked")
	void test_search() {
		String path = String.format(PrtTest.MASTER_PATH + "/relation-types");
		RelationTypeSearchReq searchParams = new RelationTypeSearchReq()
				.setCode("lol")
				.setFlMultiple(1);
		Map<String, Object> beanMap = mapper.convertValue(searchParams, Map.class);

		// FIXME
		WebCliHelper.executeGet(EXT, path, beanMap, WebCliHelper.BASIC_CREDENTIALS, InfiniteListResultsImpl.class);

		ArgumentCaptor<RelationTypeSearchReq> requestArgumentCaptor = ArgumentCaptor.forClass(
				RelationTypeSearchReq.class);

		ArgumentCaptor<ReqContext> reqCtxCaptor = ArgumentCaptor.forClass(ReqContext.class);

		verify(relationTypeService, times(1))
				.search(reqCtxCaptor.capture(), requestArgumentCaptor.capture(), eq(null));

		RelationTypeSearchReq searchRequest = requestArgumentCaptor.getValue();
		assertThat(searchRequest.getCode(), is("lol"));
		assertThat(searchRequest.getFlMultiple(), is(1));

		ReqContext reqContext = reqCtxCaptor.getValue();
		assertThat(reqContext.getTenantId(), is("master"));
		assertThat(reqContext.getLang(), is("en"));
		assertThat(reqContext.getUsername(), is(WebCliHelper.BASIC_USERNAME));
	}

	@Test
	void test_getById() {
		String path = String.format(PrtTest.MASTER_PATH + "/relation-types/THE_ROLE");
		RelationType relationType = WebCliHelper.executeGet(EXT, path, null, WebCliHelper.BASIC_CREDENTIALS, RelationType.class);

		ArgumentCaptor<ReqContext> reqCtxCaptor = ArgumentCaptor.forClass(ReqContext.class);

		verify(relationTypeService, times(1))
				.getByCode(reqCtxCaptor.capture(), eq("THE_ROLE"));

		ReqContext reqContext = reqCtxCaptor.getValue();
		assertThat(reqContext.getTenantId(), is("master"));
		assertThat(reqContext.getLang(), is("en"));
		assertThat(reqContext.getUsername(), is(WebCliHelper.BASIC_USERNAME));
	}

	@Test
	void test_getById_null() {

		ArgumentCaptor<ReqContext> reqCtxCaptor = ArgumentCaptor.forClass(ReqContext.class);

		given(relationTypeService.getByCode(reqCtxCaptor.capture(), eq("ROLE")))
				.willReturn(Optional.empty());
		String path = String.format(PrtTest.MASTER_PATH + "/relation-types/ROLE");
		RelationType relationType = WebCliHelper.executeGet(EXT, path, null, WebCliHelper.BASIC_CREDENTIALS, RelationType.class);

		ReqContext reqContext = reqCtxCaptor.getValue();
		assertThat(reqContext.getTenantId(), is("master"));
		assertThat(reqContext.getLang(), is("en"));
		assertThat(reqContext.getUsername(), is(WebCliHelper.BASIC_USERNAME));

		//---

		ArgumentCaptor<ReqContext> reqCtxCaptor1 = ArgumentCaptor.forClass(ReqContext.class);
		verify(relationTypeService, times(1))
				.getByCode(reqCtxCaptor1.capture(), eq("ROLE"));

		assertThat(relationType, nullValue());

		ReqContext reqContext1 = reqCtxCaptor1.getValue();
		assertThat(reqContext1.getTenantId(), is("master"));
		assertThat(reqContext1.getLang(), is("en"));
		assertThat(reqContext1.getUsername(), is(WebCliHelper.BASIC_USERNAME));
	}

	/*@Test
	void test_insert() {
		RelationTypeReq relationTypeReq = RelationTypeReq.builder()
				.setCode("DEV")
				.setMultiple(true)
				.build();

		String uri = PrtTest.MASTER_PATH + "/relation-types";

		RelationType response = WebCliHelper.executePost(EXT, uri, relationTypeReq, WebCliHelper.BASIC_CREDENTIALS,
				RelationType.class);

		ArgumentCaptor<ReqContext> reqCtxCaptor = ArgumentCaptor.forClass(ReqContext.class);
		verify(relationTypeService, times(1))
				.save(reqCtxCaptor.capture(), eq(relationTypeReq));

		ReqContext reqContext = reqCtxCaptor.getValue();
		assertThat(reqContext.getTenantId(), is("master"));
		assertThat(reqContext.getLang(), is("en"));
		assertThat(reqContext.getUsername(), is(WebCliHelper.BASIC_USERNAME));
	}*/

	@Test
	void test_update() {
		assertThat("there is no update", true, is(true));
	}

	/*@Test
	void test_delete() {
		String uri = PrtTest.MASTER_PATH + "/relation-types/ROLE";
		WebCliHelper.executeDelete(EXT, uri, WebCliHelper.BASIC_CREDENTIALS,
				Response.class);
		ArgumentCaptor<ReqContext> reqCtxCaptor = ArgumentCaptor.forClass(ReqContext.class);

		verify(relationTypeService, times(1))
				.expire(reqCtxCaptor.capture(), eq("ROLE"));

		ReqContext reqContext = reqCtxCaptor.getValue();
		assertThat(reqContext.getTenantId(), is("master"));
		assertThat(reqContext.getLang(), is("en"));
		assertThat(reqContext.getUsername(), is(WebCliHelper.BASIC_USERNAME));
	}*/

	/*@ParameterizedTest
	@MethodSource
	void test_validate_input(String ignoredTitle, RelationType req, List<String> expErrors) {
		String uri = PrtTest.MASTER_PATH + "/relation-types";
		Function<RelationType, RelationType> exec = x -> WebCliHelper.executePost(EXT, uri, x,
				WebCliHelper.BASIC_CREDENTIALS,
				RelationType.class);

		if (expErrors.isEmpty()) {
			exec.apply(req);
			return;
		}

		ClientErrorException ex = Assertions.assertThrows(ClientErrorException.class, () -> {
			exec.apply(req);
		});
		List<String> errors = FieldErrorUtils.extractErrorFieldNames(ex);
		assertThat(errors, containsInAnyOrder(expErrors.toArray()));
	}*/

}
