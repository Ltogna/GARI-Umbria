package com.abacogroup.partyregistry.core.impl;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.nullValue;
import static org.hamcrest.CoreMatchers.startsWith;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.greaterThan;
import static org.hamcrest.Matchers.hasItems;
import static org.hamcrest.Matchers.hasSize;
import static org.hamcrest.Matchers.notNullValue;
import static org.junit.jupiter.api.Assertions.assertTrue;

import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.partyregistry.JdbiTest;
import com.abacogroup.partyregistry.PrtTest;
import com.abacogroup.partyregistry.api.PartyRelation;
import com.abacogroup.partyregistry.api.PartyRelationParty;
import com.abacogroup.partyregistry.core.PartyRelationPartyService;
import com.abacogroup.partyregistry.core.PartyRelationService;
import com.abacogroup.partyregistry.core.exceptions.InvalidPartyRelationException;
import com.abacogroup.partyregistry.core.exceptions.InvalidRelationTypeException;
import com.abacogroup.partyregistry.db.ntt.PartyRelationEntity;
import com.abacogroup.partyregistry.resources.req.PartyRelationPartySearchReq;
import com.abacogroup.partyregistry.resources.req.PartyRelationTypeSearchReq;
import com.abacogroup.partyregistry.resources.req.ReqContext;
import com.abacogroup.partyregistry.resources.req.rel.CreatePartyRelationReq;
import com.abacogroup.partyregistry.resources.req.rel.PartyRelationDetailRequest;
import com.abacogroup.partyregistry.resources.req.rel.PartyRelationItemReq;
import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;

@Slf4j
@ExtendWith(DropwizardExtensionsSupport.class)
public class PartyRelationServiceImplTest extends JdbiTest {

	private static final String currentUser = "PartyRelationServiceImplTest_u";
	private static final String tenantId = "PartyRelationServiceImplTest_t";

	private static final ReqContext reqContext = new ReqContext(tenantId, currentUser, "en");

	private static final Map<String, Object> testScriptParams = Map.of(
			"test_tenant", tenantId,
			"user_id", currentUser
	);

	private final PartyRelationService relService = getService(PartyRelationServiceImpl.class);

	private final PartyRelationPartyService relPartyService = getService(PartyRelationPartyServiceImpl.class);

	@BeforeAll
	@AfterAll
	public static void beforeAll() {
		List<String> initScripts = List.of("rollback");
		execSqlFiles(PrtTest.class, initScripts, testScriptParams);
	}

	@ParameterizedTest
	@MethodSource
	protected void test_search(String ignoredTitle, Long partyId, PartyRelationTypeSearchReq request, List<Long> results) {

		getJdbi().useHandle(handle -> {
			handle.begin();

			List<String> initScripts = List.of("prt_rels");
			execSqlFiles(this.getClass(), initScripts, testScriptParams);

			List<PartyRelation> list = this.relService.search(reqContext, partyId, request, null)
					.getRecords();
			List<Long> actual = list.stream()
					.map(PartyRelation::getId)
					.collect(Collectors.toList());
			assertThat(actual, is(results));

			handle.rollback();
		});

	}

	private static Stream<Arguments> test_search() {
		return Stream.of(
				Arguments.of("search_by_partyId", -1L, new PartyRelationTypeSearchReq()

						, List.of(-1001L, -1002L))
				, Arguments.of("search_by_partyId_relationType", -1L, new PartyRelationTypeSearchReq()

								.setRelationTypeCode("REL_TYPE_130"),
						List.of(-1001L))
				, Arguments.of("search_by_typeId_and_note", -1L, new PartyRelationTypeSearchReq()
								.setNote("Nucleo"),
						List.of(-1001L))
		);
	}

	@Test
	void test_get_byId() {

		getJdbi().useHandle(handle -> {
			handle.begin();

			List<String> initScripts = List.of("prt_rels");
			execSqlFiles(this.getClass(), initScripts, testScriptParams);

			PartyRelation partyRelation =
					relService.getRelationById(reqContext, -1L, -1001L).orElseThrow();
			assertThat(partyRelation.getRelationTypeCode(), is("REL_TYPE_130"));
			assertThat(partyRelation.getRelationTypeI18nCode(), is("REL_TYPE_130"));
			assertThat(partyRelation.getNote(), startsWith("Nucleo"));

			handle.rollback();
		});

	}

	@Test
	void test_get_by_relationType() {

		getJdbi().useHandle(handle -> {
			handle.begin();

			List<String> initScripts = List.of("prt_rels");
			execSqlFiles(this.getClass(), initScripts, testScriptParams);

			List<PartyRelationEntity> partyRelations =
					((PartyRelationServiceImpl) relService)
							.findByRelationType(reqContext, -1L, -130L);
			assertThat(partyRelations
					.stream()
					.map(PartyRelationEntity::getId)
					.collect(Collectors.toList()), hasItems(-1001L));

			handle.rollback();
		});

	}

	@Test
	void test_insert_simple() {

		getJdbi().useHandle(handle -> {
			handle.begin();

			List<String> initScripts = List.of("prt_rels");
			execSqlFiles(this.getClass(), initScripts, testScriptParams);

			Long partyId = -1L;

			CreatePartyRelationReq relationReq = new CreatePartyRelationReq()
					.setRelationTypeCode("REL_TYPE_130");
			PartyRelation partyRelation = relService.save(reqContext, partyId, relationReq);
			assertThat(partyRelation.getPartyId(), is(partyId));
			assertThat(partyRelation.getRelationTypeCode(), is("REL_TYPE_130"));
			assertThat(partyRelation.getNote(), is(nullValue()));

			handle.rollback();
		});

	}

	@Test
	void test_insert_moreThanOne_relation_when_relationType_notMultiple_then_exception() {

		getJdbi().useHandle(handle -> {
			handle.begin();

			List<String> initScripts = List.of("prt_rels");
			execSqlFiles(this.getClass(), initScripts, testScriptParams);

			Long partyId = -1L;

			CreatePartyRelationReq relationReq = new CreatePartyRelationReq()
					.setRelationTypeCode("REL_TYPE_150");
			PartyRelation partyRelation = relService.save(reqContext, partyId, relationReq);
			assertThat(partyRelation.getPartyId(), is(partyId));
			assertThat(partyRelation.getRelationTypeCode(), is("REL_TYPE_150"));
			assertThat(partyRelation.getNote(), is(nullValue()));

			CreatePartyRelationReq relationReq2 = new CreatePartyRelationReq()
					.setRelationTypeCode("REL_TYPE_150");

			Exception ex = Assertions.assertThrows(InvalidRelationTypeException.class, () -> {
				relService.save(reqContext, partyId, relationReq2);
			});
			assertTrue(ex.getMessage().contains("more than one"));

			handle.rollback();
		});

	}

	@Test
	void test_insert_with_relation() {

		getJdbi().useHandle(handle -> {
			handle.begin();

			List<String> initScripts = List.of("prt_rels");
			execSqlFiles(this.getClass(), initScripts, testScriptParams);

			Long partyId = -1L;

			CreatePartyRelationReq relationReq = new CreatePartyRelationReq()
					.setRelationTypeCode("REL_TYPE_150")
					.setRelationItemReq(new PartyRelationItemReq()
							.setRelatedPartyId(-2L)
							.setRelatedRoleCode("REL_TYPE_150_1")
							.setDtStart(AbsoluteDate.of("20211202"))
					);

			PartyRelation partyRelation = relService.save(reqContext, partyId, relationReq);
			assertThat(partyRelation.getPartyId(), is(partyId));
			assertThat(partyRelation.getRelationTypeCode(), is("REL_TYPE_150"));
			assertThat(partyRelation.getNote(), is(nullValue()));

			List<PartyRelationParty> list = relPartyService
					.search(reqContext, partyId, partyRelation.getId(), new PartyRelationPartySearchReq(), null)
					.getRecords();

			assertThat(list, hasSize(1));
			PartyRelationParty partyRelationParty = list.get(0);
			assertThat("owner", partyRelationParty.getPartyRelation().getPartyId(), is(partyId));
			assertThat("target", partyRelationParty.getRelatedPartyId(), is(relationReq.getRelationItemReq().getRelatedPartyId()));
			assertThat("prt_party_relation_parties ID", partyRelationParty.getPartyRelationId(), is(partyRelation.getId()));
			assertThat(partyRelationParty.getRelationRoleId(), is(-1500L));
			assertThat(partyRelationParty.getRelatedRoleCode(), is("REL_TYPE_150_1"));
			assertThat(partyRelationParty.getRelationRoleI18nCode(), is("REL_TYPE_150_1"));
			//assertThat(partyRelationParty.getPartyRelation().getRelationType().getId(), is(-11L));
			assertThat(partyRelationParty.getPartyRelation().getRelationTypeCode(), is("REL_TYPE_150"));
			assertThat(partyRelationParty.getPartyRelation().getRelationTypeI18nCode(),
					is("REL_TYPE_150"));

			//---------
			//add another relation
			PartyRelationItemReq item = new PartyRelationItemReq()
					.setRelatedPartyId(-3L)
					.setRelatedRoleCode("REL_TYPE_150_1")
					.setDtStart(AbsoluteDate.of("20211202"));

			relPartyService.insert(reqContext, partyId, partyRelation.getId(), item);

			InvalidPartyRelationException ex = Assertions.assertThrows(InvalidPartyRelationException.class, () -> {
				relPartyService.insert(reqContext, partyId, partyRelation.getId(), item);
			});
			assertThat(ex.getMessage(), is("relation present"));

			list = relPartyService
					.search(reqContext, partyId, partyRelation.getId(), new PartyRelationPartySearchReq(), null)
					.getRecords();
			assertThat(list, hasSize(2));

			//-----
			//delete (expire) a specific relation
			relPartyService.expireRelationParty(reqContext, partyId, partyRelation.getId(), list.get(1).getPkid());
			list = relPartyService
					.search(reqContext, partyId, partyRelation.getId(), new PartyRelationPartySearchReq(), null)
					.getRecords();
			assertThat(list, hasSize(1));

			//update a specific relation

			PartyRelationItemReq item1 = new PartyRelationItemReq()
					.setRelatedPartyId(-3L)
					.setRelatedRoleCode("REL_TYPE_150_2")
					.setDtStart(AbsoluteDate.of("20211202"))
					.setDtEnd(AbsoluteDate.of("20301231"));

			Long pkid = list.get(0).getPkid();
			PartyRelationParty partyRelationPartyUpdated = relPartyService.update(reqContext, partyId, partyRelation.getId(), pkid, item1);
			assertThat(partyRelationPartyUpdated, notNullValue());
			assertThat(partyRelationPartyUpdated.getPkid(), greaterThan(pkid));
			list = relPartyService
					.search(reqContext, partyId, partyRelation.getId(), new PartyRelationPartySearchReq(), null)
					.getRecords();
			assertThat(list, hasSize(1));

			partyRelationParty = list.get(0);
			assertThat("owner", partyRelationParty.getPartyRelation().getPartyId(), is(partyId));
			assertThat("target", partyRelationParty.getRelatedPartyId(), is(item1.getRelatedPartyId()));
			assertThat("prt_party_relation_parties ID", partyRelationParty.getPartyRelationId(), is(partyRelation.getId()));
			assertThat(partyRelationParty.getRelationRoleId(), is(-1502L));
			assertThat(partyRelationParty.getRelatedRoleCode(), is("REL_TYPE_150_2"));
			//assertThat(partyRelationParty.getPartyRelation().getRelationType().getId(), is(-11L));
			assertThat(partyRelationParty.getPartyRelation().getRelationTypeCode(), is("REL_TYPE_150"));
			assertThat(partyRelationParty.getPartyRelation().getRelationTypeI18nCode(), is("REL_TYPE_150"));

			//questa chiamata deve cancellare solo le relazioni attive per settare un dt_delete univoco
			relService.expire(reqContext, partyId, partyRelation.getId());

			handle.rollback();
		});

	}

	@Test
	void test_expire() {

		getJdbi().useHandle(handle -> {
			handle.begin();

			List<String> initScripts = List.of("prt_rels");
			execSqlFiles(this.getClass(), initScripts, testScriptParams);

			Long partyId = -1L;
			CreatePartyRelationReq relationReq = new CreatePartyRelationReq()
					.setRelationTypeCode("REL_TYPE_150")
					.setRelationItemReq(new PartyRelationItemReq()
							.setRelatedPartyId(-2L)
							.setRelatedRoleCode("REL_TYPE_150_1")
							.setDtStart(AbsoluteDate.of("20211202"))
					);

			PartyRelation partyRelation = relService.save(reqContext, partyId, relationReq);

			List<PartyRelation> relations = relService.search(reqContext, partyId,
							new PartyRelationTypeSearchReq(), null)
					.getRecords();
			assertThat(relations, hasSize(3));

			List<PartyRelationParty> list = relPartyService
					.search(reqContext, partyId, partyRelation.getId(), new PartyRelationPartySearchReq(), null)
					.getRecords();

			assertThat(list, hasSize(1));

			//---------
			//add another relation
			PartyRelationItemReq item = new PartyRelationItemReq()
					.setRelatedPartyId(-2L)
					.setRelatedRoleCode("REL_TYPE_150_2")
					.setDtStart(AbsoluteDate.of("20211202"));

			relPartyService.insert(reqContext, partyId, partyRelation.getId(), item);

			list = relPartyService
					.search(reqContext, partyId, partyRelation.getId(), new PartyRelationPartySearchReq(), null)
					.getRecords();
			assertThat(list, hasSize(2));

			//-----
			//delete (expire) cascade
			relService.expire(reqContext, partyId, partyRelation.getId());
			relations = relService.search(reqContext, partyId, new PartyRelationTypeSearchReq(), null)
					.getRecords();
			assertThat(relations, hasSize(2));

			list = relPartyService
					.search(reqContext, partyId, partyRelation.getId(), new PartyRelationPartySearchReq(), null)
					.getRecords();
			assertThat(list, hasSize(0));

			handle.rollback();
		});

	}

	@Test
	void test_insert_with_relation_and_notes() {

		getJdbi().useHandle(handle -> {
			handle.begin();

			List<String> initScripts = List.of("prt_rels");
			execSqlFiles(this.getClass(), initScripts, testScriptParams);

			Long partyId = -1L;
			CreatePartyRelationReq relationReq = new CreatePartyRelationReq()
					.setRelationTypeCode("REL_TYPE_150")
					.setNote("lol note")
					.setRelationItemReq(new PartyRelationItemReq()
							.setRelatedPartyId(-2L)
							.setRelatedRoleCode("REL_TYPE_150_1")
							.setDtStart(AbsoluteDate.of("20211202"))
					);

			PartyRelation partyRelation = relService.save(reqContext, partyId, relationReq);
			assertThat(partyRelation.getPartyId(), is(partyId));
			assertThat(partyRelation.getRelationTypeCode(), is("REL_TYPE_150"));
			assertThat(partyRelation.getNote(), is("lol note"));

			handle.rollback();
		});

	}

	@Test
	void test_insert_update_version_note() {

		getJdbi().useHandle(handle -> {
			handle.begin();

			List<String> initScripts = List.of("prt_rels");
			execSqlFiles(this.getClass(), initScripts, testScriptParams);

			Long partyId = -1L;
			String relationTypeCode = "REL_TYPE_150";
			String note1 = "nota1";
			String note2 = "nota2";

			// build a relation without a note
			CreatePartyRelationReq relationReq = new CreatePartyRelationReq()
					.setRelationTypeCode(relationTypeCode);

			// save the relation
			PartyRelation partyRelation = relService.save(reqContext, partyId, relationReq);
			// assert that everything is ok
			assertThat(partyRelation.getPartyId(), is(partyId));
			assertThat(partyRelation.getRelationTypeCode(), is(relationTypeCode));

			//add a note 1
			PartyRelationDetailRequest request = new PartyRelationDetailRequest()
					.setNote(note1);
			PartyRelation partyRelation1 = relService.saveDetail(reqContext, partyId, partyRelation.getId(),
					request);

			//asserts that everything is ok
			assertThat(partyRelation1.getPartyId(), is(partyId));
			assertThat(partyRelation1.getRelationTypeCode(), is(relationTypeCode));
			assertThat(partyRelation1.getNote(), is(note1));

			//add a note 2
			PartyRelationDetailRequest request2 = new PartyRelationDetailRequest()
					.setNote(note2);
			PartyRelation partyRelation2 = relService.saveDetail(reqContext, partyId, partyRelation.getId(),
					request2);

			//asserts that everything is ok
			assertThat(partyRelation2.getPartyId(), is(partyId));
			assertThat(partyRelation2.getRelationTypeCode(), is(relationTypeCode));
			assertThat(partyRelation2.getNote(), is(note2));

			handle.rollback();
		});

	}

}
