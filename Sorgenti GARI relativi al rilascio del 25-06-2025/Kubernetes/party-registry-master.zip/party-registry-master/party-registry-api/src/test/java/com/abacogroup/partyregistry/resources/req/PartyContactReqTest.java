package com.abacogroup.partyregistry.resources.req;

import com.abacogroup.partyregistry.api.ContactTypeEnum;
import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;
import org.hamcrest.CoreMatchers;
import org.hamcrest.MatcherAssert;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

@ExtendWith(DropwizardExtensionsSupport.class)
class PartyContactReqTest {

	@Test
	void test_isValid_for_contactType_EMAIL_or_PEC() {

		PartyContactReq partyContactReq = new PartyContactReq()
				.setContactType(ContactTypeEnum.EMAIL)
				.setSubType("subtype1");

		// when null
		MatcherAssert.assertThat(partyContactReq.isValid(), CoreMatchers.is(false));

		partyContactReq.setContactValue("foo.alice@gmail.com");
		MatcherAssert.assertThat(partyContactReq.isValid(), CoreMatchers.is(true));

		partyContactReq.setContactValue("alice.foo.com");
		MatcherAssert.assertThat(partyContactReq.isValid(), CoreMatchers.is(false));

		partyContactReq.setContactValue("alice@hotmail");
		MatcherAssert.assertThat(partyContactReq.isValid(), CoreMatchers.is(false));

		partyContactReq.setContactValue("alice.foo.99@gmail.it");
		MatcherAssert.assertThat(partyContactReq.isValid(), CoreMatchers.is(true));

		partyContactReq.setContactValue("somethingverylong@hereandthereseemore-sd.com");
		MatcherAssert.assertThat(partyContactReq.isValid(), CoreMatchers.is(true));

		// validate PEC
		partyContactReq
				.setContactType(ContactTypeEnum.PEC)
				.setContactValue("alice@foo.pec.it");

		MatcherAssert.assertThat(partyContactReq.isValid(), CoreMatchers.is(true));

		partyContactReq.setContactValue("alice.pec.tn");
		MatcherAssert.assertThat(partyContactReq.isValid(), CoreMatchers.is(false));

		partyContactReq.setContactValue("alice@pec@it");
		MatcherAssert.assertThat(partyContactReq.isValid(), CoreMatchers.is(false));

	}

	@Test
	void test_isValid_for_contactType_PHONE() {
		PartyContactReq partyContactReq = new PartyContactReq()
				.setContactValue("+44123444533")
				.setContactType(ContactTypeEnum.PHONE)
				.setSubType("subtype1");

		MatcherAssert.assertThat(partyContactReq.isValid(), CoreMatchers.is(true));

		partyContactReq.setContactValue("123444533");
		MatcherAssert.assertThat(partyContactReq.isValid(), CoreMatchers.is(true));

		partyContactReq.setContactValue("AB1234445");
		MatcherAssert.assertThat(partyContactReq.isValid(), CoreMatchers.is(false));

		partyContactReq.setContactValue("++123444533");
		MatcherAssert.assertThat(partyContactReq.isValid(), CoreMatchers.is(false));

	}

}
