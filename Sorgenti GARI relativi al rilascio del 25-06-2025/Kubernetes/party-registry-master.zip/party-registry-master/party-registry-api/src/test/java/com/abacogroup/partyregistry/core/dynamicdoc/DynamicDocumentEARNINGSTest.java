package com.abacogroup.partyregistry.core.dynamicdoc;

import static org.hamcrest.CoreMatchers.containsString;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.hasSize;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.mock;

import com.abacogroup.bundles.listener.tenant.TenantMessage;
import com.abacogroup.dropwizard.auth.sso2.Sso2Client;
import com.abacogroup.dynamicdocuments.bean.Document;
import com.abacogroup.dynamicdocuments.bean.InsertDocument;
import com.abacogroup.dynamicdocuments.services.DocumentService;
import com.abacogroup.partyregistry.JdbiTest;
import com.abacogroup.partyregistry.api.PartyDocument;
import com.abacogroup.partyregistry.api.PartyRes;
import com.abacogroup.partyregistry.api.PartyTypeEnum;
import com.abacogroup.partyregistry.bundle.tenant.DynamicDocTenantMessageProcessor;
import com.abacogroup.partyregistry.core.DummySecurityContext;
import com.abacogroup.partyregistry.core.exceptions.InvalidDocumentException;
import com.abacogroup.partyregistry.core.impl.PartyServiceImpl;
import com.abacogroup.partyregistry.resources.req.DocumentSearchReq;
import com.abacogroup.partyregistry.resources.req.PartyCreateReq;
import com.abacogroup.partyregistry.resources.req.ReqContext;
import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;
import java.util.List;
import java.util.Map;
import lombok.SneakyThrows;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

@ExtendWith(DropwizardExtensionsSupport.class)
@Disabled
public class DynamicDocumentEARNINGSTest extends JdbiTest {

	private static final String NO_EXTERNAL_SOURCE_CODE = null;
	
	private static final ReqContext reqContext = new ReqContext("some_tenant", "user", "it");
	private final PartyDynamicDocumentManager partyDynamicDocumentManager = this.getService(PartyDynamicDocumentManagerImpl.class);
	private final DynamicDocTenantMessageProcessor dynamicDocTenantMessageProcessor = getService(DynamicDocTenantMessageProcessor.class);

	@BeforeEach
	@SneakyThrows
	void setUp() {
		DocumentService documentService = this.getService(DocumentService.class);
		var sso2Client = mock(Sso2Client.class);
		given(sso2Client.createSecurityContextFromUserName(anyString(), anyString()))
				.willAnswer(invocationOnMock -> new DummySecurityContext(invocationOnMock.getArgument(0), invocationOnMock.getArgument(1)));

		this.injectMock(documentService, sso2Client);
		this.injectMock(partyDynamicDocumentManager, documentService);
	}

	@Test
	void testInsertUpdateExpireEarnings() {

		getJdbi().useHandle(handle -> {
			handle.begin();

			PartyCreateReq massiveDynReq = (PartyCreateReq) new PartyCreateReq()
					.setPartyType(PartyTypeEnum.L)
					.setLastName("Massive Dynamic".toUpperCase());

			PartyRes party = this.getService(PartyServiceImpl.class).insert(reqContext, massiveDynReq, NO_EXTERNAL_SOURCE_CODE);

			dynamicDocTenantMessageProcessor
					.onMessage(new TenantMessage()
							.setTenantId(reqContext.getTenantId())
					);
			Long partyId = party.getId();

			//-------

			Map<String, Object> reddito = Map.of(
					"year", "2011",
					"start_date", "2011-12-03T09:06:00+02:00",
					"end_date", "2011-12-09T09:06:00+02:00",
					"employee_earning", "2000",
					"retiree_earning", "0",
					"self-employed_earning", "0",
					"ISE_ERP", "2000",
					"ISEE_ERP", "4000"
			);
			Document doc = new Document();
			Map<String, Object> fields = DynamicDocumentUtils.createDoc(reddito);
			doc.setFields(fields);
			InsertDocument ins = new InsertDocument();
			ins.setDoc(doc);
			ins.setBusinessId(partyId);

			PartyDocument partyDocument = partyDynamicDocumentManager.save(reqContext, partyId, PartyDynamicDocumentManager.TYPE_EARNINGS, ins);

			DocumentSearchReq documentSearchReq = new DocumentSearchReq().setPartyId(partyId).setDefinitionCode(PartyDynamicDocumentManager.TYPE_EARNINGS);
			List<PartyDocument> docs = partyDynamicDocumentManager
					.searchByDocType(reqContext, documentSearchReq, null).getRecords();
			assertThat(docs, hasSize(1));

			partyDynamicDocumentManager.expire(reqContext, partyId, partyDocument.getDocumentId());

			assertThat("just expired",
					partyDynamicDocumentManager.searchByDocType(reqContext, documentSearchReq, null).getRecords(),
					hasSize(0));

			//-------------
			handle.rollback();
		});
	}

	@Test
	void testValidationEarnings() {

		getJdbi().useHandle(handle -> {
			handle.begin();

			PartyCreateReq massiveDynReq = (PartyCreateReq) new PartyCreateReq()
					.setPartyType(PartyTypeEnum.L)
					.setLastName("Massive Dynamic".toUpperCase());

			PartyRes party = this.getService(PartyServiceImpl.class).insert(reqContext, massiveDynReq, NO_EXTERNAL_SOURCE_CODE);

			dynamicDocTenantMessageProcessor
					.onMessage(new TenantMessage()
							.setTenantId(reqContext.getTenantId())
					);
			Long partyId = party.getId();

			//-------

			Map<String, Object> reddito = Map.of(
					"year", "2011",
					"start_date", "2011-12-03T09:06:00+02:00",
					"end_date", "2011-12-09T09:06:00+02:00",
					"employee_earning", "2000",
					"retiree_earning", "0",
					"self-employed_earning", "0",
					"ISE_ERP", "2000",
					"ISEE_ERP", "4000"
			);
			Document doc = new Document();
			Map<String, Object> fields = DynamicDocumentUtils.createDoc(reddito);
			doc.setFields(fields);
			InsertDocument ins = new InsertDocument();
			ins.setDoc(doc);
			ins.setBusinessId(partyId);

			PartyDocument partyDocument = partyDynamicDocumentManager.save(reqContext, partyId, PartyDynamicDocumentManager.TYPE_EARNINGS, ins);

			DocumentSearchReq documentSearchReq = new DocumentSearchReq().setPartyId(partyId).setDefinitionCode(PartyDynamicDocumentManager.TYPE_EARNINGS);
			List<PartyDocument> docs = partyDynamicDocumentManager
					.searchByDocType(reqContext, documentSearchReq, null).getRecords();
			assertThat(docs, hasSize(1));

			InvalidDocumentException ex = Assertions.assertThrows(InvalidDocumentException.class, () -> {
				partyDynamicDocumentManager
						.save(reqContext, partyId, PartyDynamicDocumentManager.TYPE_EARNINGS, ins);
			});
			assertThat(ex.getMessage(), containsString("Earnings already recorded for this period"));

			DynamicDocumentUtils.updateField(doc, "start_date", "2010-12-03T09:06:00+02:00");
			DynamicDocumentUtils.updateField(doc, "end_date", "2012-12-03T09:06:00+02:00");
			ins.setDoc(doc);
			ex = Assertions.assertThrows(InvalidDocumentException.class, () -> {
				partyDynamicDocumentManager
						.save(reqContext, partyId, PartyDynamicDocumentManager.TYPE_EARNINGS, ins);
			});
			assertThat(ex.getMessage(), containsString("Earnings already recorded for this period"));

			DynamicDocumentUtils.updateField(doc, "start_date", "2011-12-04T09:06:00+02:00");
			DynamicDocumentUtils.updateField(doc, "end_date", "2011-12-08T09:06:00+02:00");
			ins.setDoc(doc);
			ex = Assertions.assertThrows(InvalidDocumentException.class, () -> {
				partyDynamicDocumentManager
						.save(reqContext, partyId, PartyDynamicDocumentManager.TYPE_EARNINGS, ins);
			});
			assertThat(ex.getMessage(), containsString("Earnings already recorded for this period"));

			partyDynamicDocumentManager.expire(reqContext, partyId, partyDocument.getDocumentId());

			assertThat("just expired",
					partyDynamicDocumentManager.searchByDocType(reqContext, documentSearchReq, null).getRecords(),
					hasSize(0));

			//-------------
			handle.rollback();
		});
	}
}
