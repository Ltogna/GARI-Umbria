package com.abacogroup.partyregistry.core.impl;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;

import com.abacogroup.partyregistry.JdbiTest;
import com.abacogroup.partyregistry.api.v1.TagResponseV1;
import com.abacogroup.partyregistry.api.v1.req.TagSearchRequestV1;
import com.abacogroup.partyregistry.core.TagV1Service;
import com.abacogroup.partyregistry.resources.req.ReqContext;
import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;

@ExtendWith(DropwizardExtensionsSupport.class)
class TagV1ServiceImplTest extends JdbiTest {

	private static final String currentUser = "TagV1ServiceImplTest_u";
	private static final String tenantId = "TagV1ServiceImplTest_t";

	private static final Map<String, Object> testScriptParams = Map.of(
			"test_tenant", tenantId,
			"user_id", currentUser
	);

	private static final ReqContext reqContext =
			new ReqContext(tenantId, currentUser, "en");

	private final TagV1Service tagV1Service = this.getService(TagV1ServiceImpl.class);

	@ParameterizedTest
	@MethodSource
	public void test_searchTags(String ignoredTitle, ReqContext ctx, TagSearchRequestV1 request, List<Long> results) {

		setUnusedBindingAllowed(true);
		getJdbi().useHandle(handle -> {
			handle.begin();

			List<String> initScripts = List.of("tag_v1_service");
			execSqlFiles(this.getClass(), initScripts, testScriptParams);

			List<TagResponseV1> list = this.tagV1Service.searchTags(ctx,
							request, null)
					.getRecords();
			List<Long> actual = list.stream()
					.map(TagResponseV1::getId)
					.collect(Collectors.toList());
			assertThat(actual, is(results));

			handle.rollback();
		});
	}

	private static Stream<Arguments> test_searchTags() {
		return Stream.of(
				Arguments.of("with_code", reqContext, new TagSearchRequestV1()
								.setI18nCode("l_e")
								.setCode("lol")
						, List.of(-112L)

				),
				Arguments.of("by_i18n_code", reqContext, new TagSearchRequestV1()
								.setI18nCode("bug_en")
						, List.of(-111L)

				),
				Arguments.of("empty", reqContext, new TagSearchRequestV1()
						, List.of(-111L, -112L))
		);
	}

	@ParameterizedTest
	@MethodSource
	public void test_searchTagList(String ignoredTitle, ReqContext ctx, TagSearchRequestV1 request, List<Long> results) {

		setUnusedBindingAllowed(true);
		getJdbi().useHandle(handle -> {
			handle.begin();

			List<String> initScripts = List.of("tag_v1_service");
			execSqlFiles(this.getClass(), initScripts, testScriptParams);

			List<TagResponseV1> list = this.tagV1Service.searchTagList(ctx, request);

			List<Long> actual = list.stream()
					.map(TagResponseV1::getId)
					.collect(Collectors.toList());
			assertThat(actual, is(results));

			handle.rollback();
		});
	}

	private static Stream<Arguments> test_searchTagList() {
		return Stream.of(
				Arguments.of("with_code", reqContext, new TagSearchRequestV1()
								.setI18nCode("l_e")
								.setCode("lol")
						, List.of(-112L)

				),
				Arguments.of("by_i18n_code", reqContext, new TagSearchRequestV1()
								.setI18nCode("bug_en")
						, List.of(-111L)

				),
				Arguments.of("empty", reqContext, new TagSearchRequestV1()
						, List.of(-111L, -112L))
		);
	}

}
