package com.abacogroup.partyregistry.core.impl;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.junit.jupiter.api.Assertions.assertTrue;

import com.abacogroup.partyregistry.JdbiTest;
import com.abacogroup.partyregistry.api.v1.LegalStatusResponseV1;
import com.abacogroup.partyregistry.api.v1.req.LegalStatusSearchRequestV1;
import com.abacogroup.partyregistry.core.LegalStatusV1Service;
import com.abacogroup.partyregistry.resources.req.ReqContext;
import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;

@Slf4j
@ExtendWith(DropwizardExtensionsSupport.class)
class LegalStatusV1ServiceImplTest extends JdbiTest {

	private static final String tenantId = "LegalStatusV1ServiceImplTest_t";
	private static final String currentUser = "LegalStatusV1ServiceImplTest_u";

	private static final ReqContext reqContext =
			new ReqContext(tenantId, currentUser, "en");

	private static final Map<String, Object> testScriptParams = Map.of(
			"test_tenant", tenantId,
			"user_id", currentUser
	);

	private final LegalStatusV1Service service = getService(LegalStatusV1ServiceImpl.class);

	@ParameterizedTest
	@MethodSource
	void test_search(String ignoredTitle, LegalStatusSearchRequestV1 request, List<Long> results) {
		setUnusedBindingAllowed(true);
		getJdbi().useHandle(handle -> {
			handle.begin();

			List<String> initScripts = List.of("legal_status");
			execSqlFiles(this.getClass(), initScripts, testScriptParams);

			List<LegalStatusResponseV1> list = this.service
					.search(reqContext, request, null)
					.getRecords();
			List<String> actual = list.stream()
					.map(LegalStatusResponseV1::getCode)
					.collect(Collectors.toList());
			assertThat(actual, is(results));

			handle.rollback();
		});

	}

	private static Stream<Arguments> test_search() {
		return Stream.of(
				Arguments.of("just_tenant", new LegalStatusSearchRequestV1()
						, List.of("ACTIVE", "DISSOLVED", "INACTIVE", "LIQUIDATED", "SUSPENDED"))

				, Arguments.of("by_code", new LegalStatusSearchRequestV1()
								.setCode("INACTIVE"),
						List.of("INACTIVE"))

				, Arguments.of("by_i18n", new LegalStatusSearchRequestV1()
								.setI18nCode("active_en"),
						List.of("ACTIVE", "INACTIVE"))
		);
	}

	@Test
	void test_getByCode() {
		setUnusedBindingAllowed(true);
		getJdbi().useHandle(handle -> {
			handle.begin();

			List<String> initScripts = List.of("legal_status");
			execSqlFiles(this.getClass(), initScripts, testScriptParams);

			LegalStatusResponseV1 legalStatus = this.service.getByCode(reqContext, "ACTIVE")
					.orElseThrow();
			assertThat(legalStatus.getCode(), is("ACTIVE"));
			assertThat(legalStatus.getI18nCode(), is("active_en"));

			Optional<LegalStatusResponseV1> notFound = this.service.getByCode(reqContext, "XX");
			assertTrue(notFound.isEmpty());

			handle.rollback();
		});

	}

}
