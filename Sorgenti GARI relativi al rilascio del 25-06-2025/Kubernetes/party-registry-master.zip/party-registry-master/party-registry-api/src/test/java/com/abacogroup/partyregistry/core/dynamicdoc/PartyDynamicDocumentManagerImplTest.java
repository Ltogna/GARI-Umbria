package com.abacogroup.partyregistry.core.dynamicdoc;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.mockito.Mockito.mock;

import com.abacogroup.dynamicdocuments.bean.Document;
import com.abacogroup.dynamicdocuments.bean.InsertDocument;
import com.abacogroup.dynamicdocuments.files.FileStoreSupport;
import com.abacogroup.dynamicdocuments.services.DocumentService;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.partyregistry.JdbiTest;
import com.abacogroup.partyregistry.PrtTest;
import com.abacogroup.partyregistry.api.PartyDocument;
import com.abacogroup.partyregistry.resources.req.DocumentSearchReq;
import com.abacogroup.partyregistry.resources.req.ReqContext;
import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;
import java.time.OffsetDateTime;
import java.util.List;
import java.util.Map;
import lombok.SneakyThrows;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

@ExtendWith(DropwizardExtensionsSupport.class)
public class PartyDynamicDocumentManagerImplTest extends JdbiTest {

	private static final String tenantId = "PartyDynamicDocumentManagerImplTest_t";
	private static final String currentUser = "PartyDynamicDocumentManagerImplTest_u";

	private static final ReqContext reqContext =
			new ReqContext(tenantId, currentUser, "en");

	private static final Map<String, Object> testScriptParams = Map.of(
			"test_tenant", tenantId,
			"user_id", currentUser
	);

	private static final Long PARTY_ID = -1111L;

	private final PartyDynamicDocumentManager service = getService(PartyDynamicDocumentManagerImpl.class);

	@BeforeAll
	@AfterAll
	public static void beforeAll() {
		List<String> initScripts = List.of("rollback");
		execSqlFiles(PrtTest.class, initScripts, testScriptParams);
	}

	@BeforeEach
	@SneakyThrows
	void setUp() {
		DocumentService documentService = this.getService(DocumentService.class);
		var fileStoreSupport = mock(FileStoreSupport.class);

		this.injectMock(documentService, fileStoreSupport);
		this.injectMock(service, documentService);
	}

	@Test
	public void test_searchAllByDocType() {

		setUnusedBindingAllowed(true);
		getJdbi().useHandle(handle -> {
			handle.begin();

			List<String> initScripts = List.of("dd1");
			execSqlFiles(this.getClass(), initScripts, testScriptParams);

			//   BANK DATA
			ReqContext reqContext = new ReqContext(tenantId, currentUser, "it");
			Map<String, Object> bankDoc = Map.of(
					"bank_name", "CITI",
					"iban", "IT16T0200809440000004925167",
					"cuc", "cuc1",
					"swift", "125454"
			);

			InsertDocument ins = new InsertDocument();
			Document doc = new Document();
			Map<String, Object> fields = DynamicDocumentUtils.createDoc(bankDoc);
			doc.setFields(fields);
			doc.setValidFrom(OffsetDateTime.now());
			ins.setDoc(doc);
			service.save(reqContext, PARTY_ID, PartyDynamicDocumentManager.TYPE_BANK_DATA, ins);
			DocumentSearchReq searchReq = new DocumentSearchReq().setPartyId(PARTY_ID).setDefinitionCode(PartyDynamicDocumentManager.TYPE_BANK_DATA);
			InfiniteListResults<PartyDocument> docs = this.service.searchByDocType(reqContext, searchReq, null);
			assertThat(docs.getRecords().size(), is(1));
			assertThat(docs.getRecords().get(0).getData().get("bank_name"), is("CITI"));
			assertThat(docs.getRecords().get(0).getData().get("iban"), is("IT16T0200809440000004925167"));
			assertThat(docs.getRecords().get(0).getData().get("swift"), is("125454"));

			// ID DATA PASSAPORTO
			Map<String, Object> passaporto = Map.of(
					"id_type", "passport",
					"release_agent", "Comune di Palermo",
					"release_date", "2021-12-03T00:00:00+02:00",
					"expiration_date", "2031-12-03T00:00:00+02:00",
					"number", "XXXXXXXXXX"
			);

			fields = DynamicDocumentUtils.createDoc(passaporto);
			doc.setFields(fields);
			doc.setValidFrom(OffsetDateTime.now());
			ins.setDoc(doc);
			this.service.save(reqContext, PARTY_ID, PartyDynamicDocumentManager.TYPE_ID_DATA, ins);
			searchReq = new DocumentSearchReq().setPartyId(PARTY_ID).setDefinitionCode(PartyDynamicDocumentManager.TYPE_ID_DATA);
			docs = this.service.searchByDocType(reqContext, searchReq, null);
			assertThat(docs.getRecords().size(), is(1));
			assertThat(docs.getRecords().get(0).getData().get("id_type"), is("passaporto"));

			// E INVOICING DOC

			Map<String, Object> invoicingDoc = Map.ofEntries(
					Map.entry("recipient_code", "XXXXXXXX"),
					Map.entry("intent_declaration_code", "Intent_Code"),
					Map.entry("declaration_date", "2021-12-03T09:06:00+02:00"),
					Map.entry("decl_expiration_date", "2031-12-03T09:06:00+02:00"),
					Map.entry("country_id", "IT"),
					Map.entry("sender_id", "12345"),
					Map.entry("tax_regime_type", "IT"));

			fields = DynamicDocumentUtils.createDoc(invoicingDoc);
			doc.setFields(fields);
			doc.setValidFrom(OffsetDateTime.now());
			ins.setDoc(doc);
			service.save(reqContext, PARTY_ID, PartyDynamicDocumentManager.TYPE_EINVOICING, ins);
			searchReq = new DocumentSearchReq().setPartyId(PARTY_ID).setDefinitionCode(PartyDynamicDocumentManager.TYPE_EINVOICING);
			docs = this.service.searchByDocType(reqContext, searchReq, null);
			assertThat(docs.getRecords().size(), is(1));
			assertThat(docs.getRecords().get(0).getData().get("recipient_code"), is("XXXXXXXX"));

			// EARNINGS DOC

			Map<String, Object> reddito = Map.of(
					"year", "2011",
					"start_date", "2011-12-03T09:06:00+02:00",
					"end_date", "2011-12-04T09:06:00+02:00",
					"employee_earning", "2000",
					"retiree_earning", "0",
					"self-employed_earning", "0",
					"ISE_ERP", "2000",
					"ISEE_ERP", "4000"
			);
			fields = DynamicDocumentUtils.createDoc(reddito);
			doc.setFields(fields);
			doc.setValidFrom(OffsetDateTime.now());
			ins.setDoc(doc);
			service.save(reqContext, PARTY_ID, PartyDynamicDocumentManager.TYPE_EARNINGS, ins);
			searchReq = new DocumentSearchReq().setPartyId(PARTY_ID).setDefinitionCode(PartyDynamicDocumentManager.TYPE_EARNINGS);
			docs = this.service.searchByDocType(reqContext, searchReq, null);
			assertThat(docs.getRecords().size(), is(1));
			assertThat(docs.getRecords().get(0).getData().get("start_date"), is(OffsetDateTime.parse("2011-12-03T09:06+02:00")));
			handle.rollback();
		});

	}

	@Test
	public void given_field_using_lookup_then_return_i18n_value_of_lookup_code_used() {
		setUnusedBindingAllowed(true);
		getJdbi().useHandle(handle -> {
			handle.begin();

			List<String> initScripts = List.of("dd1");
			execSqlFiles(this.getClass(), initScripts, testScriptParams);

			// ID DATA PASSAPORTO
			Map<String, Object> passaporto = Map.of(
					"id_type", "id_card",
					"release_agent", "Comune di Palermo",
					"release_date", "2021-12-03T00:00:00+02:00",
					"expiration_date", "2031-12-03T00:00:00+02:00",
					"number", "XXXXXXXXXX"
			);

			InsertDocument ins = new InsertDocument();
			Document doc = new Document();
			Map<String, Object> fields = DynamicDocumentUtils.createDoc(passaporto);
			doc.setFields(fields);
			doc.setValidFrom(OffsetDateTime.now());
			ins.setDoc(doc);

			this.service.save(reqContext, PARTY_ID, PartyDynamicDocumentManager.TYPE_ID_DATA, ins);

			DocumentSearchReq searchReq = new DocumentSearchReq().setPartyId(PARTY_ID).setDefinitionCode(PartyDynamicDocumentManager.TYPE_ID_DATA);

			// id_card code in (EN)
			InfiniteListResults<PartyDocument> docs = this.service.searchByDocType(reqContext, searchReq, null);

			assertThat(docs.getRecords().size(), is(1));
			assertThat(docs.getRecords().get(0).getData().get("id_type"), is("id card"));

			// id_card code in (IT)
			reqContext.setLang("it");
			docs = this.service.searchByDocType(reqContext, searchReq, null);

			assertThat(docs.getRecords().size(), is(1));
			assertThat(docs.getRecords().get(0).getData().get("id_type"), is("carta identita"));

			handle.rollback();
		});

	}

}
