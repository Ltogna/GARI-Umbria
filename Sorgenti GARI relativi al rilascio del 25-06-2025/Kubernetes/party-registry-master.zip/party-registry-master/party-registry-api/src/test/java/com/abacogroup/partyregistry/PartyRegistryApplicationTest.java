package com.abacogroup.partyregistry;

import com.abacogroup.bundles.initializer.InitService;
import com.abacogroup.bundles.initializer.impl.BundleInitServiceProducer;
import com.abacogroup.bundles.listener.RabbitListener;
import com.abacogroup.bundles.listener.configdata.ConfigDataLogProducer;
import com.abacogroup.dropwizard.auth.sso2.Sso2Client;
import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.parti.testing.ApplicationTestSupport;
import com.abacogroup.parti.testing.TestApplication;
import com.abacogroup.partyregistry.core.PartyEventProducer;
import com.abacogroup.partyregistry.core.dto.PartyEventType;
import com.abacogroup.partyregistry.db.dao.PartyDAO;
import com.abacogroup.partyregistry.resources.req.ReqContext;
import com.abacogroup.proxies.cache.ProxiesCache;
import com.abacogroup.proxies.cache.jdbi.ProxiesCachePlugin;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.collect.ImmutableMap;
import com.google.common.collect.ImmutableSet;
import com.rabbitmq.client.Connection;
import io.dropwizard.auth.AuthFilter;
import io.dropwizard.auth.PolymorphicAuthDynamicFeature;
import io.dropwizard.auth.PolymorphicAuthValueFactoryProvider;
import io.dropwizard.auth.basic.BasicCredentialAuthFilter;
import io.dropwizard.auth.chained.ChainedAuthFilter;
import io.dropwizard.core.setup.Environment;
import jakarta.ws.rs.client.Client;
import java.io.IOException;
import java.lang.reflect.Field;
import java.time.Clock;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.TimeoutException;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.reflect.FieldUtils;
import org.jdbi.v3.core.Jdbi;
import org.jdbi.v3.core.statement.Slf4JSqlLogger;
import org.mockito.Mockito;

@Slf4j
public class PartyRegistryApplicationTest extends PartyRegistryApplication implements TestApplication {

	public static Jdbi jdbi;

	private ApplicationTestSupport applicationTestSupport = new ApplicationTestSupport();

	public static ObjectMapper getObjectMapper() {
		ObjectMapper mapper = new ObjectMapper();
		mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		//brutto, ma consente di accentrare la configurazione senza snaturare application
		new PartyRegistryApplication().configureObjectMapper(mapper);
		return mapper;
	}

	public static Jdbi getLol() {
		return jdbi;
	}

	@Override
	public ApplicationTestSupport getAppTestSupport() {
		return applicationTestSupport;
	}

	@Override
	public Jdbi getJdbi() {
		return jdbi;
	}

	@Override
	protected Jdbi jdbi(PartyRegistryConfiguration configuration, Environment environment) {
		Jdbi jdbi = super.jdbi(configuration, environment);
		jdbi.setSqlLogger(new Slf4JSqlLogger());
		PartyRegistryApplicationTest.jdbi = jdbi;

		applicationTestSupport.execMigrations(environment, configuration.getDatabase());
		return jdbi;
	}

	@Override
	protected <T> T register(T service) {
		if (isBetterToMock(service)) {
			service = (T) Mockito.mock(service.getClass());
		}

		applicationTestSupport.register(service);
		return super.register(service);
	}

	@Override
	protected ConfigDataLogProducer configDataLogProducerBean(ObjectMapper objectMapper, com.rabbitmq.client.Connection rabbitmqConnection) {
		if (!applicationTestSupport.isInitRabbit()) {
			return Mockito.mock(ConfigDataLogProducer.class);
		}
		return super.configDataLogProducerBean(objectMapper, rabbitmqConnection);
	}

	@Override
	protected void initAuth(Environment environment, Sso2Client sso2Cli) {
		List<AuthFilter<?, ? extends User>> filters = new ArrayList<>();
		filters.add(new BasicCredentialAuthFilter.Builder<User>()
				.setAuthenticator(credentials -> Optional.of(new User(credentials.getUsername(), "master")))
				.setAuthorizer((principal, role, x) -> {
					return true;
				})
				.setRealm("GUEST authenticator")
				.buildAuthFilter());

		ChainedAuthFilter usersFilter = new ChainedAuthFilter(filters);

		final PolymorphicAuthDynamicFeature<? extends User> feature = new PolymorphicAuthDynamicFeature<>(
				ImmutableMap.of(User.class, usersFilter));

		PolymorphicAuthValueFactoryProvider.Binder<? extends User> binder = new PolymorphicAuthValueFactoryProvider.Binder<>(
				ImmutableSet.of(User.class));

		environment.jersey().register(feature);
		environment.jersey().register(binder);
		//*/
	}

	@Override
	protected void startRabbitConsumerAndProducers(InitService initService, RabbitListener rabbitListener) throws Exception {
		if (!applicationTestSupport.isInitRabbit()) {
			System.out.println("startup producers and consumers OFF");
		} else {
			super.startRabbitConsumerAndProducers(initService, rabbitListener);
		}
	}

	@Override
	protected PartyEventProducer buildPartyEventProducer(Environment environment, Jdbi jdbi, ObjectMapper objectMapper, Connection rabbitmqConnection,
			PartyDAO partyDAO, Clock appClock) throws IOException {
		return new PartyEventProducer() {
			@Override
			public void pushPartyEvent(ReqContext reqContext, Long partyId, PartyEventType eventType) {
				this.pushPartyEvent(reqContext.getTenantId(), reqContext.getUsername(), reqContext.getLang(), partyId, eventType);
			}

			@Override
			public void pushPartyEvent(String tenant, String username, String lang, Long partyId, PartyEventType eventType) {
				log.info("MOCK {} event for partyId: {}", eventType, partyId);
			}
		};
	}

	@Override
	@SneakyThrows
	protected void afterServicesUp() {
		if (!applicationTestSupport.isExecMigrations()) {
			return;
		}
		applicationTestSupport.installBundle(jdbi, "party-registry-bundle-00001.zip");
	}

	@Override
	protected void initProxiesCache(PartyRegistryConfiguration configuration, Environment environment, ObjectMapper objectMapper, Jdbi jdbi,
			Connection rabbitmqConnection, Client proxiesClient) throws TimeoutException, IOException {

		if (applicationTestSupport.isInitRabbit()) {
			super.initProxiesCache(configuration, environment, objectMapper, jdbi, rabbitmqConnection, proxiesClient);
		} else {
			log.info("ProxiesCache mocked ");
			jdbi.installPlugin(new ProxiesCachePlugin(configuration.getAclConfig().isIgnoreAcl()));
			this.register(Mockito.mock(ProxiesCache.class));
		}
	}

	protected static <T, M> void injectMockByField(T target, String filedName) {
		try {
			Class<T> targetClazz = (Class<T>) target.getClass();
			Field field = Arrays.stream(FieldUtils.getAllFields(targetClazz))
					.filter(f -> f.getName().equals(filedName))
					.findFirst()
					.orElseThrow();

			FieldUtils.writeField(target, field.getName(), Mockito.mock(field.getType()), true);
		} catch (IllegalAccessException ex) {
			throw new RuntimeException("errore in inject", ex);
		}
	}

	@Override
	protected com.rabbitmq.client.Connection createRabbitmqConnection(PartyRegistryConfiguration configuration) throws IOException, TimeoutException {
		if (applicationTestSupport.isInitRabbit()) {
			return super.createRabbitmqConnection(configuration);
		} else {
			log.info("RABBIT CONNECTION DISABLED");
			return null;
		}
	}

	private <T> boolean isBetterToMock(T service) {
		return (
				service instanceof ConfigDataLogProducer
						|| service instanceof BundleInitServiceProducer
		) && !applicationTestSupport.isInitRabbit();
	}
}
