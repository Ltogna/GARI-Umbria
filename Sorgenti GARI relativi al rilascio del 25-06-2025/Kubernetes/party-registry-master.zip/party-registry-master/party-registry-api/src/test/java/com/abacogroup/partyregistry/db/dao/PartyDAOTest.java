package com.abacogroup.partyregistry.db.dao;

import static com.abacogroup.jdbi.datatype.validation.AbsoluteDateFormatValidator.DATE_DEFAULT_STR;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.greaterThanOrEqualTo;
import static org.hamcrest.Matchers.is;

import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.partyregistry.JdbiTest;
import com.abacogroup.partyregistry.api.PartyTypeEnum;
import com.abacogroup.partyregistry.core.impl.AuditHelper;
import com.abacogroup.partyregistry.db.ntt.PartyEntity;
import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

@ExtendWith(DropwizardExtensionsSupport.class)
class PartyDAOTest extends JdbiTest {

	private static final String tenantId = "PartyDAOTest_t";
	private static final String userId = "PartyDAOTest_u";
	private static final Map<String, Object> testScriptParams = Map.of(
			"test_tenant", tenantId,
			"user_id", userId
	);

	private final PartyDAO dao = getDAO(PartyDAO.class);

	@Test
	void test_issue_pk() {
		assertThat(dao.issuePk(), greaterThanOrEqualTo(1L));
	}

	@Test
	void test_load_by_id_and_tenant_id() {

		long id = -777L;

		getJdbi().useHandle(handle -> {
			handle.begin();

			List<String> initScripts = List.of("add_party");
			execSqlFiles(PartyDAOTest.class, initScripts, testScriptParams);

			Optional<PartyEntity> result = dao.loadOneByIdAndTenantId(tenantId, id);
			assertThat(result.isPresent(), is(true));
			assertThat(result.get().getTenantId(), is(tenantId));
			assertThat(result.get().getId(), is(id));

			handle.rollback();
		});
	}

	// ----- findCuaaById -----
	@Test
	void test_findCuaaById_ok() {
		getJdbi().useHandle(handle -> {
			handle.begin();

			String cuaa = "test_cuaa";
			long id = 555L;
			PartyEntity partyEntity = PartyEntity.builder()
					.setTenantId(tenantId)
					.setCode(cuaa)
					.setPartyType(PartyTypeEnum.N)
					.setLastName("xxx")
					.setDeathDate(AbsoluteDate.of(DATE_DEFAULT_STR))
					.build();
			AuditHelper.setAuditForInsert(userId, dao, partyEntity);
			dao.insertMasterRow(id, partyEntity);
			dao.insertDetailRow(partyEntity, id, id);

			Assertions.assertThat(dao.findCodeById(tenantId, id))
					.isEqualTo(cuaa);

			handle.rollback();
		});
	}

	@Test
	void test_findCuaaById_null() {
		getJdbi().useHandle(handle -> {
			handle.begin();

			String cuaa = null;
			long id = 555L;
			PartyEntity partyEntity = PartyEntity.builder()
					.setTenantId(tenantId)
					.setCode(cuaa)
					.setPartyType(PartyTypeEnum.N)
					.setLastName("xxx")
					.setDeathDate(AbsoluteDate.of(DATE_DEFAULT_STR))
					.build();
			AuditHelper.setAuditForInsert(userId, dao, partyEntity);
			dao.insertMasterRow(id, partyEntity);
			dao.insertDetailRow(partyEntity, id, id);

			Assertions.assertThat(dao.findCodeById(tenantId, id))
					.isNull();

			handle.rollback();
		});
	}
}
