package com.abacogroup.partyregistry.resources;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.startsWith;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import com.abacogroup.jdbi.paging.impl.InfiniteListResultsImpl;
import com.abacogroup.partyregistry.PrtTest;
import com.abacogroup.partyregistry.api.ContactTypeEnum;
import com.abacogroup.partyregistry.api.PartyContact;
import com.abacogroup.partyregistry.core.AclService;
import com.abacogroup.partyregistry.core.impl.ContactServiceImpl;
import com.abacogroup.partyregistry.resources.req.ContactSearchReq;
import com.abacogroup.partyregistry.resources.req.PartyContactReq;
import com.abacogroup.partyregistry.resources.req.ReqContext;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;
import io.dropwizard.testing.junit5.ResourceExtension;
import jakarta.ws.rs.BadRequestException;
import java.util.Map;
import lombok.extern.slf4j.Slf4j;
import org.hamcrest.Matchers;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mockito;

@Slf4j
@ExtendWith(DropwizardExtensionsSupport.class)
public class PartyContactsResourceTest {

	private final ObjectMapper mapper = new ObjectMapper();

	private final AclService aclService = Mockito.mock(AclService.class);
	private final ContactServiceImpl contactService = Mockito.mock(ContactServiceImpl.class);

	private final ResourceExtension EXT = WebCliHelper.createEXT(new PartyContactsResource(aclService, contactService));

	@Test
	@SuppressWarnings("unchecked")
	void test_list() {
		Long partyId = PrtTest.PARTY999;
		String uri = String.format("/parties/%s/contacts", partyId);

		String path = PrtTest.MASTER_PATH + uri;

		ContactSearchReq request = new ContactSearchReq()
				.setContactType(ContactTypeEnum.PHONE)
				.setContactValue("11");

		Map<String, Object> beanMap = mapper.convertValue(request, Map.class);
		WebCliHelper.executeGet(EXT, path, beanMap, WebCliHelper.BASIC_CREDENTIALS, InfiniteListResultsImpl.class);

		ArgumentCaptor<ReqContext> reqCtxCaptor = ArgumentCaptor.forClass(ReqContext.class);
		ArgumentCaptor<ContactSearchReq> argumentCaptor = ArgumentCaptor.forClass(ContactSearchReq.class);
		verify(contactService, times(1)).
				search(reqCtxCaptor.capture(), argumentCaptor.capture(), eq(null));
		ContactSearchReq searchRequest = argumentCaptor.getValue();

		assertThat(searchRequest.getContactType(), is(ContactTypeEnum.PHONE));
		assertThat(searchRequest.getContactValue(), is("11"));
		assertThat(searchRequest.getPartyId(), is(partyId));

		ReqContext reqContext = reqCtxCaptor.getValue();
		assertThat(reqContext.getTenantId(), Matchers.is("master"));
		assertThat(reqContext.getLang(), Matchers.is("en"));
		assertThat(reqContext.getUsername(), Matchers.is(WebCliHelper.BASIC_USERNAME));

	}

	@Test
	void test_insert() {
		Long partyId = 1L;
		String uri = String.format(PrtTest.MASTER_PATH + "/parties/%s/contacts", partyId);

		PartyContact contact = new PartyContact()
				.setContactType(ContactTypeEnum.EMAIL)
				.setSubType("TEST")
				.setContactValue("user@example.com");

		PartyContact ignored = WebCliHelper
				.executePost(EXT, uri, contact, WebCliHelper.BASIC_CREDENTIALS, PartyContact.class);

		ArgumentCaptor<PartyContactReq> argumentCaptor = ArgumentCaptor.forClass(PartyContactReq.class);

		ArgumentCaptor<ReqContext> reqCtxCaptor = ArgumentCaptor.forClass(ReqContext.class);
		verify(contactService, times(1)).
				insert(reqCtxCaptor.capture(), eq(partyId), argumentCaptor.capture(), eq(true));
		PartyContactReq partyContact = argumentCaptor.getValue();
		assertThat(partyContact.getContactType(), is(ContactTypeEnum.EMAIL));
		assertThat(partyContact.getSubType(), is("TEST"));
		assertThat(partyContact.getContactValue(), startsWith("user"));

		ReqContext reqContext = reqCtxCaptor.getValue();
		assertThat(reqContext.getTenantId(), Matchers.is("master"));
		assertThat(reqContext.getLang(), Matchers.is("en"));
		assertThat(reqContext.getUsername(), Matchers.is(WebCliHelper.BASIC_USERNAME));

	}

	@Test
	@SuppressWarnings("all")
	void test_insert_with_invalid_contact_type() {
		Long partyId = 1L;
		String uri = String.format(PrtTest.MASTER_PATH + "/parties/%s/contacts", partyId);

		PartyContact contact = new PartyContact()
				.setContactType(ContactTypeEnum.EMAIL)
				.setSubType("TEST")
				.setContactValue("user@example.com");

		Map<String, Object> contactMap = mapper.convertValue(contact, Map.class);
		contactMap.put("contactType", "XXX");

		BadRequestException exception = Assertions.assertThrows(BadRequestException.class, () -> {
			WebCliHelper
					.executePost(EXT, uri, contactMap, WebCliHelper.BASIC_CREDENTIALS, String.class);
		});
		String exceptionReason = exception.getResponse().readEntity(String.class);
		assertTrue(exceptionReason.contains("JSON"));

		ArgumentCaptor<PartyContactReq> argumentCaptor = ArgumentCaptor.forClass(PartyContactReq.class);
		ArgumentCaptor<ReqContext> reqCtxCaptor = ArgumentCaptor.forClass(ReqContext.class);
		verify(contactService, times(0)).
				insert(reqCtxCaptor.capture(), eq(partyId), argumentCaptor.capture(), eq(true));
	}

	@Test
	void test_update() {
		Long partyId = 1L;
		Long pkid = 10L;
		String uri = String.format(PrtTest.MASTER_PATH + "/parties/%s/contacts/%d", partyId, pkid);

		PartyContactReq contact = new PartyContactReq()
				.setContactType(ContactTypeEnum.EMAIL)
				.setSubType("TEST")
				.setContactValue("user@example.com");

		PartyContact ignored = WebCliHelper
				.executePut(EXT, uri, contact, WebCliHelper.BASIC_CREDENTIALS, PartyContact.class);

		ArgumentCaptor<ReqContext> reqCtxCaptor = ArgumentCaptor.forClass(ReqContext.class);
		ArgumentCaptor<PartyContactReq> argumentCaptor = ArgumentCaptor.forClass(PartyContactReq.class);
		verify(contactService, times(1)).
				update(reqCtxCaptor.capture(), eq(partyId), eq(pkid), argumentCaptor.capture());
		PartyContactReq partyContact = argumentCaptor.getValue();

		assertThat(partyContact.getContactType(), is(ContactTypeEnum.EMAIL));
		assertThat(partyContact.getSubType(), is("TEST"));
		assertThat(partyContact.getContactValue(), startsWith("user"));

		ReqContext reqContext = reqCtxCaptor.getValue();
		assertThat(reqContext.getTenantId(), Matchers.is("master"));
		assertThat(reqContext.getLang(), Matchers.is("en"));
		assertThat(reqContext.getUsername(), Matchers.is(WebCliHelper.BASIC_USERNAME));

	}

	@Test
	void test_expire() {
		Long partyId = 1L;
		String uri = String.format(PrtTest.MASTER_PATH + "/parties/%s/contacts/10", partyId);

		PartyContact contact = new PartyContact()
				.setContactType(ContactTypeEnum.EMAIL)
				.setSubType("TEST")
				.setContactValue("user@example.com");

		PartyContact ignored = WebCliHelper
				.executeDelete(EXT, uri, WebCliHelper.BASIC_CREDENTIALS, PartyContact.class);
		ArgumentCaptor<ReqContext> reqCtxCaptor = ArgumentCaptor.forClass(ReqContext.class);
		verify(contactService, times(1)).
				expireContact(reqCtxCaptor.capture(), eq(partyId), eq(10L));

		ReqContext reqContext = reqCtxCaptor.getValue();
		assertThat(reqContext.getTenantId(), Matchers.is("master"));
		assertThat(reqContext.getLang(), Matchers.is("en"));
		assertThat(reqContext.getUsername(), Matchers.is(WebCliHelper.BASIC_USERNAME));

	}

}
