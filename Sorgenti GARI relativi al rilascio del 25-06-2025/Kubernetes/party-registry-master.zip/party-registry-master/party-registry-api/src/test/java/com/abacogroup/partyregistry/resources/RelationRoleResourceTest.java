package com.abacogroup.partyregistry.resources;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import com.abacogroup.jdbi.paging.impl.InfiniteListResultsImpl;
import com.abacogroup.partyregistry.PrtTest;
import com.abacogroup.partyregistry.api.RelationRole;
import com.abacogroup.partyregistry.core.impl.RelationRoleServiceImpl;
import com.abacogroup.partyregistry.resources.req.RelationRoleSearchReq;
import com.abacogroup.partyregistry.resources.req.ReqContext;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;
import io.dropwizard.testing.junit5.ResourceExtension;
import java.util.Map;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mockito;

@ExtendWith(DropwizardExtensionsSupport.class)
class RelationRoleResourceTest {

	private final RelationRoleServiceImpl relationRoleService = Mockito.mock(RelationRoleServiceImpl.class);

	private final ResourceExtension EXT = WebCliHelper.createEXT(new RelationRoleResource(relationRoleService));

	private final ObjectMapper mapper = new ObjectMapper();

	@Test
	@SuppressWarnings("unchecked")
	void test_search() {
		String path = String.format(PrtTest.MASTER_PATH + "/relation-types/TYPE/roles");
		RelationRoleSearchReq searchParams = new RelationRoleSearchReq()
				.setCode("MOGLIE");
		Map<String, Object> beanMap = mapper.convertValue(searchParams, Map.class);

		WebCliHelper.executeGet(EXT, path, beanMap, WebCliHelper.BASIC_CREDENTIALS, InfiniteListResultsImpl.class);

		ArgumentCaptor<ReqContext> reqCtxCaptor = ArgumentCaptor.forClass(ReqContext.class);
		ArgumentCaptor<RelationRoleSearchReq> requestArgumentCaptor = ArgumentCaptor.forClass(
				RelationRoleSearchReq.class);
		verify(relationRoleService, times(1))
				.search(reqCtxCaptor.capture(), requestArgumentCaptor.capture(), eq(null));

		RelationRoleSearchReq searchRequest = requestArgumentCaptor.getValue();
		assertThat(searchRequest.getRelationTypeCode(), is("TYPE"));
		assertThat(searchRequest.getCode(), is("MOGLIE"));

		ReqContext reqContext = reqCtxCaptor.getValue();
		assertThat(reqContext.getTenantId(), is("master"));
		assertThat(reqContext.getLang(), is("en"));
		assertThat(reqContext.getUsername(), is(WebCliHelper.BASIC_USERNAME));

	}

	@Test
	void test_getByCode() {
		String path = String.format(PrtTest.MASTER_PATH + "/relation-types/TYPE/roles/ROLE");
		RelationRole relationRole = WebCliHelper.executeGet(EXT, path, null, WebCliHelper.BASIC_CREDENTIALS, RelationRole.class);

		ArgumentCaptor<ReqContext> reqCtxCaptor = ArgumentCaptor.forClass(ReqContext.class);
		verify(relationRoleService, times(1))
				.getByCodeAndType(reqCtxCaptor.capture(), eq("TYPE"), eq("ROLE"));

		ReqContext reqContext = reqCtxCaptor.getValue();
		assertThat(reqContext.getTenantId(), is("master"));
		assertThat(reqContext.getLang(), is("en"));
		assertThat(reqContext.getUsername(), is(WebCliHelper.BASIC_USERNAME));
	}

/*	@Test
	void test_insert() {
		RelationRoleReq relationRole = RelationRoleReq.builder()
				.setCode("TEST")
				.build();

		String path = String.format(PrtTest.MASTER_PATH + "/relation-types/TYPE/roles");
		WebCliHelper.executePost(EXT, path, relationRole, WebCliHelper.BASIC_CREDENTIALS,
				RelationRole.class);

		ArgumentCaptor<ReqContext> reqCtxCaptor = ArgumentCaptor.forClass(ReqContext.class);
		ArgumentCaptor<RelationRoleReq> argumentCaptor = ArgumentCaptor.forClass(RelationRoleReq.class);
		verify(relationRoleService, times(1))
				.save(reqCtxCaptor.capture(), argumentCaptor.capture());

		RelationRoleReq value = argumentCaptor.getValue();
		assertThat(value.getCode(), is("TEST"));
		assertThat(value.getTypeCode(), is("TYPE"));

		ReqContext reqContext = reqCtxCaptor.getValue();
		assertThat(reqContext.getTenantId(), is("master"));
		assertThat(reqContext.getLang(), is("en"));
		assertThat(reqContext.getUsername(), is(WebCliHelper.BASIC_USERNAME));
	}

	@Test
	void test_insert_with_null_code() {
		RelationRoleReq req = RelationRoleReq.builder()
				.setCode(null)
				.build();

		String path = String.format(PrtTest.MASTER_PATH + "/relation-types/TYPE/roles");

		ClientErrorException exception = Assertions.assertThrows(ClientErrorException.class, () -> {
			WebCliHelper.executePost(EXT, path, req, WebCliHelper.BASIC_CREDENTIALS,
					RelationRole.class);
		});

		String exceptionReason = exception.getResponse().readEntity(String.class);
		assertTrue(exceptionReason.contains("code"));

		ArgumentCaptor<ReqContext> reqCtxCaptor = ArgumentCaptor.forClass(ReqContext.class);
		ArgumentCaptor<RelationRoleReq> argumentCaptor = ArgumentCaptor.forClass(RelationRoleReq.class);
		verify(relationRoleService, times(0))
				.save(reqCtxCaptor.capture(), argumentCaptor.capture());

	}*/

	@Test
	void test_update() {
		assertThat("there is no update", true, is(true));
	}

/*	@Test
	void test_delete() {
		String path = String.format(PrtTest.MASTER_PATH + "/relation-types/TYPE/roles/ROLE");

		ArgumentCaptor<ReqContext> reqCtxCaptor = ArgumentCaptor.forClass(ReqContext.class);
		WebCliHelper.executeDelete(EXT, path, WebCliHelper.BASIC_CREDENTIALS,
				Response.class);
		verify(relationRoleService, times(1))
				.expire(reqCtxCaptor.capture(), eq("ROLE"));

		ReqContext reqContext = reqCtxCaptor.getValue();
		assertThat(reqContext.getTenantId(), is("master"));
		assertThat(reqContext.getLang(), is("en"));
		assertThat(reqContext.getUsername(), is(WebCliHelper.BASIC_USERNAME));
	}*/

}
