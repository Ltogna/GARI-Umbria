package com.abacogroup.partyregistry.bundle.config;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.containsInAnyOrder;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.notNullValue;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import com.abacogroup.bundles.initializer.impl.exceptions.BundleException;
import com.abacogroup.bundles.listener.configdata.ConfigDataMessage;
import com.abacogroup.partyregistry.JdbiTest;
import com.abacogroup.partyregistry.api.DocType;
import com.abacogroup.partyregistry.api.PartyTypeEnum;
import com.abacogroup.partyregistry.core.BundleConstants;
import com.abacogroup.partyregistry.core.impl.DocTypeServiceImpl;
import com.abacogroup.partyregistry.db.dao.I18nDAO;
import com.abacogroup.partyregistry.resources.req.DocTypeSearchReq;
import com.abacogroup.partyregistry.resources.req.ReqContext;
import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;
import org.hamcrest.CoreMatchers;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.MockedStatic;
import org.mockito.Mockito;

@ExtendWith(DropwizardExtensionsSupport.class)
class DynamicDocConfigMessageProcessorTest extends JdbiTest {

	private static final String tenantId = "DynamicDocConfigMessageProcessorTest_t";

	private static final String specificSettingsFilesPath = "src/test/resources/com/abacogroup/partyregistry/bundle/config/DynamicDocConfigMessageProcessorTest";

	private static final Map<String, Object> testScriptParams = Map.of(
			"test_tenant", tenantId
	);

	private final DocTypeServiceImpl docTypeService = getService(DocTypeServiceImpl.class);

	private final DynamicDocConfigMessageProcessor processor = getService(DynamicDocConfigMessageProcessor.class);

	private final I18nDAO dao = getJdbi().onDemand(I18nDAO.class);

	private final List<Long> allTags = List.of(-111L, -112L, -113L, -114L);
	@Test
	void test_process_bundle_files() {

		getJdbi().useHandle(handle -> {
			handle.begin();

			List<String> initScripts = List.of("tags");
			execSqlFiles(this.getClass(), initScripts, testScriptParams);

			ReqContext ctx = new ReqContext(tenantId, BundleConstants.SYSTEM_USER);
			ConfigDataMessage configDataMessage = new ConfigDataMessage();
			configDataMessage.setTenantId(tenantId);

			configDataMessage.setConfigFiles(List.of(
					Path.of(specificSettingsFilesPath, "def_bank_data.json"),
					Path.of(specificSettingsFilesPath, "def_e-invoicing.json"),
					Path.of(specificSettingsFilesPath, "settings001.json"),
					Path.of(specificSettingsFilesPath, "def_earnings.json"),
					Path.of(specificSettingsFilesPath, "def_id_doc.json")
			));
			processor.onMessage(configDataMessage);

			List<DocType> docTypes = docTypeService.search(ctx, new DocTypeSearchReq(), allTags, PartyTypeEnum.values());
			assertThat(docTypes.size(), is(4));
			assertThat(docTypes.stream().map(DocType::getDocType).collect(Collectors.toList()),
					containsInAnyOrder("BANK", "EARNINGS", "EINVOICING", "ID"));

			Optional<DocType> docType = docTypeService.getByDocType(ctx, "EINVOICING");
			assertTrue(docType.isPresent());
			assertThat(docType.get().getDocGroup(), is("commercial"));

			String sql = "select t.tag_code " +
					"from prt_doc_type_tags rel " +
					"join prt_doc_type pdt on pdt.id = rel.doc_type_id " +
					"join prt_tags t on t.id = rel.tag_id " +
					"where pdt.doc_type = ? " +
					"and pdt.tenant_id = ?" +
					"and (§current_timestamp§ between pdt.dt_insert and pdt.dt_delete) " +
					"and (§current_timestamp§ between rel.dt_insert and rel.dt_delete) ";
			org.assertj.core.api.Assertions.assertThat(handle.select(sql, "ID", tenantId).mapTo(String.class).list())
					.containsExactlyInAnyOrder("FOO", "BAR");
			org.assertj.core.api.Assertions.assertThat(handle.select(sql, "BANK", tenantId).mapTo(String.class).list())
					.containsExactlyInAnyOrder("LOL", "BAR");
			org.assertj.core.api.Assertions.assertThat(handle.select(sql, "EARNINGS", tenantId).mapTo(String.class).list()).isEmpty();
			org.assertj.core.api.Assertions.assertThat(handle.select(sql, "EINVOICING", tenantId).mapTo(String.class).list()).isEmpty();

			handle.rollback();
		});
	}

	@Test
	void given_multiple_i18nTexts_for_the_same_i18n_value_then_the_last_one_defined_always_wins() {

		getJdbi().useHandle(handle -> {
			handle.begin();

			ConfigDataMessage configDataMessage = new ConfigDataMessage();
			configDataMessage.setTenantId(tenantId);

			List<Path> list = new ArrayList<>();
			list.add(Path.of(specificSettingsFilesPath + "/def_bank_data.json"));
			list.add(Path.of(specificSettingsFilesPath + "/def_id_doc.json"));
			list.add(Path.of(specificSettingsFilesPath + "/def_earnings.json"));

			// this setting file contains multiple i18n definitions for the same docGroup (general)
			// in the same lang (en) :  general / GEEENERAL
			list.add(Path.of(specificSettingsFilesPath + "/settings_bad_case.json"));
			list.add(Path.of(specificSettingsFilesPath + "/settings_4_bad_case.json"));

			configDataMessage.setConfigFiles(list);

			processor.onMessage(configDataMessage);

			String label = this.dao.searchLabel(tenantId, "prt_doc_type", "doc_group", "general", "en");
			assertThat("multiple_i18nTexts_for_docGroup_general", label, CoreMatchers.is("GEEENERAL"));

			handle.rollback();
		});
	}

	@Test
	void given_different_values_and_duplicated_definitions_for_the_same_object_then_the_last_definition_always_wins() {

		getJdbi().useHandle(handle -> {
			handle.begin();

			ReqContext ctx = new ReqContext(tenantId, BundleConstants.SYSTEM_USER);

			ConfigDataMessage configDataMessage = new ConfigDataMessage();
			configDataMessage.setTenantId(tenantId);

			List<Path> list = new ArrayList<>();
			list.add(Path.of(specificSettingsFilesPath + "/def_bank_data.json"));
			list.add(Path.of(specificSettingsFilesPath + "/def_id_doc.json"));
			list.add(Path.of(specificSettingsFilesPath + "/def_earnings.json"));

			//  in this setting files, the docType ( BANK) is defined several times with different values
			// for docType : BANK , docGroup : general ,general2 ,general3
			list.add(Path.of(specificSettingsFilesPath + "/settings_bad_case.json"));
			list.add(Path.of(specificSettingsFilesPath + "/settings_2_bad_case.json"));
			list.add(Path.of(specificSettingsFilesPath + "/settings_3_bad_case.json"));
			configDataMessage.setConfigFiles(list);
			processor.onMessage(configDataMessage);

			Optional<DocType> docType = docTypeService.getByDocType(ctx, "BANK");
			assertTrue(docType.isPresent());
			assertThat(docType.get().getDocGroup(), is("general3"));

			handle.rollback();
		});

	}

	@Test
	@Disabled("!!! ora settings sono obbligatori per mappare i DD")
	void test_process_bundle_files_with_default() {

		getJdbi().useHandle(handle -> {
			handle.begin();

			ReqContext ctx = new ReqContext(tenantId, BundleConstants.SYSTEM_USER);
			ConfigDataMessage configDataMessage = new ConfigDataMessage();
			configDataMessage.setTenantId(tenantId);

			configDataMessage.setConfigFiles(List.of(
					Path.of(specificSettingsFilesPath, "def_bank_data.json"),
					Path.of(specificSettingsFilesPath, "def_e-invoicing.json"),
					Path.of(specificSettingsFilesPath, "def_earnings.json"),
					Path.of(specificSettingsFilesPath, "def_id_doc.json")
			));

			processor.onMessage(configDataMessage);

			List<DocType> docTypes = docTypeService.search(ctx, new DocTypeSearchReq(), allTags, PartyTypeEnum.values());
			assertThat(docTypes.size(), is(4));
			assertThat(docTypes.stream().map(DocType::getDocType).collect(Collectors.toList()),
					containsInAnyOrder("BANK", "EARNINGS", "EINVOICING", "ID"));

			handle.rollback();
		});
	}

	@Test
	void test_givenNewSettingWithDifferentTypes_whenProcessBundle_thenUpdateRelations() {

		getJdbi().useHandle(handle -> {
			handle.begin();

			ReqContext ctx = new ReqContext(tenantId, BundleConstants.SYSTEM_USER);
			ConfigDataMessage configDataMessage = new ConfigDataMessage();
			configDataMessage.setTenantId(tenantId);
			configDataMessage.setConfigFiles(List.of(
					Path.of(specificSettingsFilesPath + "/def_id_doc.json"),
					Path.of(specificSettingsFilesPath + "/settings_id_types_1.json")
			));

			processor.onMessage(configDataMessage);

			String sql = "select rel.party_type " +
					"from prt_doc_type_relations rel " +
					"join prt_doc_type pdt on pdt.id = rel.doc_type_id " +
					"where pdt.doc_type = ? " +
					"and pdt.tenant_id = ?" +
					"and (§current_timestamp§ between pdt.dt_insert and pdt.dt_delete) " +
					"and (§current_timestamp§ between rel.dt_insert and rel.dt_delete) ";
			org.assertj.core.api.Assertions.assertThat(handle.select(sql, "ID", tenantId).mapTo(String.class).list())
					.containsExactlyInAnyOrder("N");

			// change settings

			configDataMessage.setConfigFiles(List.of(
					Path.of(specificSettingsFilesPath + "/settings_id_types_2.json")
			));

			processor.onMessage(configDataMessage);

			org.assertj.core.api.Assertions.assertThat(handle.select(sql, "ID", tenantId).mapTo(String.class).list())
					.containsExactlyInAnyOrder("L");

			handle.rollback();
		});
	}

	@Test
	void test_givenNewSettingWithNoTags_whenProcessBundle_thenRemoveTags() {

		getJdbi().useHandle(handle -> {
			handle.begin();

			List<String> initScripts = List.of("tags");
			execSqlFiles(this.getClass(), initScripts, testScriptParams);

			ReqContext ctx = new ReqContext(tenantId, BundleConstants.SYSTEM_USER);
			ConfigDataMessage configDataMessage = new ConfigDataMessage();
			configDataMessage.setTenantId(tenantId);
			configDataMessage.setConfigFiles(List.of(
					Path.of(specificSettingsFilesPath + "/def_id_doc.json"),
					Path.of(specificSettingsFilesPath + "/settings_id_tags_1.json")
			));

			processor.onMessage(configDataMessage);

			String sql = "select t.tag_code " +
					"from prt_doc_type_tags rel " +
					"join prt_doc_type pdt on pdt.id = rel.doc_type_id " +
					"join prt_tags t on t.id = rel.tag_id " +
					"where pdt.doc_type = ? " +
					"and pdt.tenant_id = ?" +
					"and (§current_timestamp§ between pdt.dt_insert and pdt.dt_delete) " +
					"and (§current_timestamp§ between rel.dt_insert and rel.dt_delete) ";
			org.assertj.core.api.Assertions.assertThat(handle.select(sql, "ID", tenantId).mapTo(String.class).list())
					.containsExactlyInAnyOrder("FOO", "BAR");

			// change settings

			configDataMessage.setConfigFiles(List.of(
					Path.of(specificSettingsFilesPath + "/settings_id_tags_2.json")
			));

			processor.onMessage(configDataMessage);

			org.assertj.core.api.Assertions.assertThat(handle.select(sql, "ID", tenantId).mapTo(String.class).list())
					.isEmpty();

			handle.rollback();
		});
	}

	@Test
	void test_givenSettingWithNotExistingTags_whenProcessBundle_thenERROR() {

		getJdbi().useHandle(handle -> {
			handle.begin();

			List<String> initScripts = List.of("tags");
			execSqlFiles(this.getClass(), initScripts, testScriptParams);

			ReqContext ctx = new ReqContext(tenantId, BundleConstants.SYSTEM_USER);
			ConfigDataMessage configDataMessage = new ConfigDataMessage();
			configDataMessage.setTenantId(tenantId);
			configDataMessage.setConfigFiles(List.of(
					Path.of(specificSettingsFilesPath + "/def_id_doc.json"),
					Path.of(specificSettingsFilesPath + "/def_bank_data.json"),
					Path.of(specificSettingsFilesPath + "/settings_not_existing_tags.json")
			));

			BundleException bundleException = assertThrows(BundleException.class, () -> processor.onMessage(configDataMessage));

			org.assertj.core.api.Assertions.assertThat(bundleException.getMessage())
					.containsIgnoringCase("not_existing_1")
					.containsIgnoringCase("not_existing_2")
					.doesNotContainIgnoringCase("foo", "bar", "lol");
			System.out.println(bundleException.getMessage());

			handle.rollback();
		});
	}

	@Test
	void test_givenDeleteSettingsFile_whenProcessBundle_thenExpireSettings() {

		getJdbi().useHandle(handle -> {
			handle.begin();

			List<String> initScripts = List.of("tags");
			execSqlFiles(this.getClass(), initScripts, testScriptParams);

			ReqContext ctx = new ReqContext(tenantId, BundleConstants.SYSTEM_USER);
			ConfigDataMessage configDataMessage = new ConfigDataMessage();
			configDataMessage.setTenantId(tenantId);

			configDataMessage.setConfigFiles(List.of(
					Path.of(specificSettingsFilesPath, "def_bank_data.json"),
					Path.of(specificSettingsFilesPath, "def_e-invoicing.json"),
					Path.of(specificSettingsFilesPath, "settings001.json"),
					Path.of(specificSettingsFilesPath, "def_earnings.json"),
					Path.of(specificSettingsFilesPath, "def_id_doc.json")
			));
			processor.onMessage(configDataMessage);

			org.assertj.core.api.Assertions.assertThat(docTypeService.search(ctx, new DocTypeSearchReq(), allTags, PartyTypeEnum.values()))
					.hasSize(4)
					.extracting(DocType::getDocType)
					.containsExactlyInAnyOrder("BANK", "EARNINGS", "EINVOICING", "ID");

			configDataMessage.setConfigFiles(List.of(
					Path.of(specificSettingsFilesPath, "settings001.delete.json")
			));
			processor.onMessage(configDataMessage);

			org.assertj.core.api.Assertions.assertThat(docTypeService.search(ctx, new DocTypeSearchReq(), allTags, PartyTypeEnum.values()))
					.hasSize(2)
					.extracting(DocType::getDocType)
					.containsExactlyInAnyOrder("BANK", "ID");

			handle.rollback();
		});
	}

	@Test
	void when_getDefaultTypes_returns_null_then_getTypesList_throw_nullPointerException() {
		DynamicDocConfigMessageProcessor.DocSettingEntry documentSettingEntry = new DynamicDocConfigMessageProcessor.DocSettingEntry();
		try (
				MockedStatic<DynamicDocConfigMessageProcessor> theMock = Mockito.mockStatic(DynamicDocConfigMessageProcessor.class)) {
			theMock.when(() -> DynamicDocConfigMessageProcessor.getDefaultTypes())
					.thenReturn(null);

			assertThat(DynamicDocConfigMessageProcessor.getDefaultTypes(), CoreMatchers.nullValue());
			NullPointerException thrown = Assertions
					.assertThrows(NullPointerException.class, () -> documentSettingEntry.getTypesList());
			assertThat(thrown, notNullValue());
		}
	}

	@Test
	void test_when_getDefaultTypes_returns_emptyList() {
		DynamicDocConfigMessageProcessor.DocSettingEntry documentSettingEntry = new DynamicDocConfigMessageProcessor.DocSettingEntry();
		try (
				MockedStatic<DynamicDocConfigMessageProcessor> theMock = Mockito.mockStatic(DynamicDocConfigMessageProcessor.class)) {
			theMock.when(() -> DynamicDocConfigMessageProcessor.getDefaultTypes())
					.thenReturn(Collections.emptyList());
			assertThat(documentSettingEntry.getTypesList(), is(Collections.emptyList()));
			assertThat(documentSettingEntry.getTypesList().size(), is(0));
		}
	}

	@Test
	void test_DocumentSettingEntry_getTypesList() {
		DynamicDocConfigMessageProcessor.DocSettingEntry entry = new DynamicDocConfigMessageProcessor.DocSettingEntry();
		entry.setTypes(null);

		assertThat("Default PartyTypeEnum contains 2 items", entry.getTypesList().size(), CoreMatchers.is(2));
		assertThat(entry.getTypesList().stream().collect(Collectors.toList()),
				containsInAnyOrder(PartyTypeEnum.N, PartyTypeEnum.L));

		entry.setTypes(List.of("N"));
		assertThat(entry.getTypesList().size(), CoreMatchers.is(1));
		assertThat(entry.getTypesList().stream().collect(Collectors.toList()),
				containsInAnyOrder(PartyTypeEnum.N));
	}
}
