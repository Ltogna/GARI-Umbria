package com.abacogroup.partyregistry.resources;

import static com.abacogroup.partyregistry.PrtTest.TENANT_DEFAULT_CODE;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.hasItems;
import static org.hamcrest.Matchers.is;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.jdbi.paging.impl.InfiniteListResultsImpl;
import com.abacogroup.partyregistry.PrtTest;
import com.abacogroup.partyregistry.api.PartyCheckResponse;
import com.abacogroup.partyregistry.api.PartyRes;
import com.abacogroup.partyregistry.api.PartyTypeEnum;
import com.abacogroup.partyregistry.api.v1.req.PartySearchRequestV1;
import com.abacogroup.partyregistry.core.AclService;
import com.abacogroup.partyregistry.core.ExternalSourceService;
import com.abacogroup.partyregistry.core.PartyService;
import com.abacogroup.partyregistry.core.impl.PartyServiceImpl;
import com.abacogroup.partyregistry.resources.req.ArchivedEnum;
import com.abacogroup.partyregistry.resources.req.PartyCheckReq;
import com.abacogroup.partyregistry.resources.req.PartyCodeCheckReq;
import com.abacogroup.partyregistry.resources.req.PartyCreateReq;
import com.abacogroup.partyregistry.resources.req.PartyExternalReq;
import com.abacogroup.partyregistry.resources.req.PartySearchReq;
import com.abacogroup.partyregistry.resources.req.PartyUpdateReq;
import com.abacogroup.partyregistry.resources.req.ReqContext;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;
import io.dropwizard.testing.junit5.ResourceExtension;
import jakarta.ws.rs.ClientErrorException;
import jakarta.ws.rs.client.Entity;
import jakarta.ws.rs.core.GenericType;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.core.UriBuilder;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mockito;

@Slf4j
@ExtendWith(DropwizardExtensionsSupport.class)
class PartyResourceTest {

	private final AclService aclService = Mockito.mock(AclService.class);
	private final PartyService partyService = Mockito.mock(PartyServiceImpl.class);
	private final ExternalSourceService externalSourceService = Mockito.mock(ExternalSourceService.class);

	private final PartyResource resource = new PartyResource(aclService, partyService, externalSourceService);
	private final ResourceExtension EXT = WebCliHelper.createEXT(resource);

	@Test
	@SuppressWarnings("unchecked")
	void test_execute_search() {
		Long partyId = -500L;
		String path = String.format(PrtTest.MASTER_PATH + "/parties");
		PartySearchRequestV1 partySearchReq = new PartySearchRequestV1()
				.setFirstName("gino")
				.setTag(List.of("a", "b"));

		ObjectMapper mapper = new ObjectMapper();
		Map<String, Object> beanMap = mapper.convertValue(partySearchReq, Map.class);

		WebCliHelper.executeGet(EXT, path, beanMap, WebCliHelper.BASIC_CREDENTIALS, InfiniteListResultsImpl.class);

		ArgumentCaptor<ReqContext> reqCtxCaptor = ArgumentCaptor.forClass(ReqContext.class);
		ArgumentCaptor<PartySearchReq> requestArgumentCaptor = ArgumentCaptor.forClass(PartySearchReq.class);
		verify(partyService, times(1))
				.search(reqCtxCaptor.capture(), requestArgumentCaptor.capture(), any(), eq(null));

		PartySearchReq searchRequest = requestArgumentCaptor.getValue();
		assertThat(searchRequest.getArchived(), is(ArchivedEnum.not_archived));
		assertThat(searchRequest.getFirstName(), is("gino"));
		assertThat(searchRequest.getTag(), hasItems("a", "b"));

		ReqContext reqContext = reqCtxCaptor.getValue();
		assertThat(reqContext.getTenantId(), is("master"));
		assertThat(reqContext.getLang(), is("en"));
		assertThat(reqContext.getUsername(), is(WebCliHelper.BASIC_USERNAME));

	}

	@Test
	void test_get_by_id() {
		String path = String.format(PrtTest.MASTER_PATH + "/parties/1");

		given(partyService.getPartyById(Mockito.any(ReqContext.class), Mockito.anyLong()))
				.willReturn(Optional.of(new PartyRes()
						.setLastName("Acme")
						.setBirthDate(AbsoluteDate.of("19891231"))
				));

		String party = WebCliHelper.executeGet(EXT, path, null, WebCliHelper.BASIC_CREDENTIALS, String.class);
		ArgumentCaptor<ReqContext> reqCtxCaptor = ArgumentCaptor.forClass(ReqContext.class);
		verify(partyService, times(1))
				.getPartyById(reqCtxCaptor.capture(), eq(1L));

		ReqContext reqContext = reqCtxCaptor.getValue();
		assertThat(reqContext.getTenantId(), is("master"));
		assertThat(reqContext.getLang(), is("en"));
		assertThat(reqContext.getUsername(), is(WebCliHelper.BASIC_USERNAME));

		assertTrue(party.contains("\"birthDate\":\"19891231\""), "check serializzazione localdate");

	}

	@Test
	void test_add() {
		PartyCreateReq req = (PartyCreateReq) new PartyCreateReq()
				.setPartyType(PartyTypeEnum.N)
				.setLastName("new_acme")
				.setArchived(false);
		String path = String.format(PrtTest.MASTER_PATH + "/parties");

		PartyRes ignored = WebCliHelper.executePost(EXT, path, req, WebCliHelper.BASIC_CREDENTIALS, PartyRes.class);

		ArgumentCaptor<ReqContext> reqCtxCaptor = ArgumentCaptor.forClass(ReqContext.class);
		ArgumentCaptor<PartyCreateReq> partyArgumentCaptor = ArgumentCaptor.forClass(PartyCreateReq.class);
		verify(partyService, times(1))
				.insert(reqCtxCaptor.capture(), partyArgumentCaptor.capture(), any());

		PartyCreateReq party = partyArgumentCaptor.getValue();
		assertThat(party.getLastName(), is("new_acme"));
		assertFalse(party.isArchived());

		ReqContext reqContext = reqCtxCaptor.getValue();
		assertThat(reqContext.getTenantId(), is("master"));
		assertThat(reqContext.getLang(), is("en"));
		assertThat(reqContext.getUsername(), is(WebCliHelper.BASIC_USERNAME));

	}

	@Test
	void test_put() {
		PartyUpdateReq req = new PartyUpdateReq()
				.setPartyType(PartyTypeEnum.N)
				.setLastName("new_acme")
				.setArchived(false);
		long id = 1L;
		String path = String.format("%s/parties/%d", PrtTest.MASTER_PATH, id);

		PartyRes ignored = WebCliHelper.executePut(EXT, path, req, WebCliHelper.BASIC_CREDENTIALS, PartyRes.class);

		ArgumentCaptor<ReqContext> reqCtxCaptor = ArgumentCaptor.forClass(ReqContext.class);
		ArgumentCaptor<PartyUpdateReq> partyArgumentCaptor = ArgumentCaptor.forClass(PartyUpdateReq.class);
		verify(partyService, times(1))
				.update(reqCtxCaptor.capture(), eq(id), partyArgumentCaptor.capture());

		PartyUpdateReq party = partyArgumentCaptor.getValue();
		assertThat(party.getLastName(), is("new_acme"));
		assertFalse(party.isArchived());

		ReqContext reqContext = reqCtxCaptor.getValue();
		assertThat(reqContext.getTenantId(), is("master"));
		assertThat(reqContext.getLang(), is("en"));
		assertThat(reqContext.getUsername(), is(WebCliHelper.BASIC_USERNAME));

	}

	@Test
	void test_execute_archive() {
		Long partyId = -500L;
		String URI = String.format(PrtTest.MASTER_PATH + "/parties/%s/archived_flag", partyId);
		WebCliHelper.executePut(EXT, URI, "", WebCliHelper.BASIC_CREDENTIALS, String.class);

		ArgumentCaptor<ReqContext> reqCtxCaptor = ArgumentCaptor.forClass(ReqContext.class);
		verify(partyService, times(1))
				.archive(reqCtxCaptor.capture(), eq(partyId), eq(true));

		ReqContext reqContext = reqCtxCaptor.getValue();
		assertThat(reqContext.getTenantId(), is("master"));
		assertThat(reqContext.getLang(), is("en"));
		assertThat(reqContext.getUsername(), is(WebCliHelper.BASIC_USERNAME));

	}

	@Test
	void test_execute_removeFromArchive() {
		Long partyId = -500L;
		String URI = String.format(PrtTest.MASTER_PATH + "/parties/%s/archived_flag", partyId);
		WebCliHelper.executeDelete(EXT, URI, WebCliHelper.BASIC_CREDENTIALS, String.class);

		ArgumentCaptor<ReqContext> reqCtxCaptor = ArgumentCaptor.forClass(ReqContext.class);
		verify(partyService, times(1))
				.archive(reqCtxCaptor.capture(), eq(partyId), eq(false));

		ReqContext reqContext = reqCtxCaptor.getValue();
		assertThat(reqContext.getTenantId(), is("master"));
		assertThat(reqContext.getLang(), is("en"));
		assertThat(reqContext.getUsername(), is(WebCliHelper.BASIC_USERNAME));

	}

	@Test
	void test_duplicates_parties() {
		String taxCode = "11";
		String VatNumber = "12";
		String path = String.format(PrtTest.MASTER_PATH + "/parties/duplicates");

		PartyCheckReq partyCheckRequest = new PartyCheckReq()
				.setTaxCode(taxCode)
				.setVatNumber(VatNumber)
				.setId(1L);

		ObjectMapper mapper = new ObjectMapper();
		Map<String, Object> beanMap = mapper.convertValue(partyCheckRequest, Map.class);

		WebCliHelper.executeGet(EXT, path, beanMap, WebCliHelper.BASIC_CREDENTIALS, PartyCheckResponse.class);

		ArgumentCaptor<PartyCheckReq> requestArgumentCaptor = ArgumentCaptor.forClass(PartyCheckReq.class);

		verify(partyService, times(1))
				.loadDuplicates(eq("master"), requestArgumentCaptor.capture());

		PartyCheckReq checkRequest = requestArgumentCaptor.getValue();
		assertThat(checkRequest.getTaxCode(), is(taxCode));
		assertThat(checkRequest.getVatNumber(), is(VatNumber));
		assertThat(checkRequest.getId(), is(1L));
	}

	@Test
	void test_duplicates_parties_without_vat_and_tax() {
		String path = String.format(PrtTest.MASTER_PATH + "/parties/duplicates");

		PartyCheckReq partyCheckRequest = new PartyCheckReq()
				.setId(1L);

		ObjectMapper mapper = new ObjectMapper();
		Map<String, Object> beanMap = mapper.convertValue(partyCheckRequest, Map.class);

		ClientErrorException ex = Assertions.assertThrows(ClientErrorException.class, () -> {
			WebCliHelper.executeGet(EXT, path, beanMap, WebCliHelper.BASIC_CREDENTIALS, PartyCheckResponse.class);
		});
	}

	@Test
	void test_duplicates_cuaa() {
		String CUAA = "Z5458WK54";
		String path = String.format(PrtTest.MASTER_PATH + "/parties/duplicates_code");

		PartyCodeCheckReq partyCuaaCheckRequest = new PartyCodeCheckReq()
				.setCode(CUAA)
				.setId(1L);

		ObjectMapper mapper = new ObjectMapper();
		Map<String, Object> beanMap = mapper.convertValue(partyCuaaCheckRequest, Map.class);

		WebCliHelper.executeGet(EXT, path, beanMap, WebCliHelper.BASIC_CREDENTIALS, PartyCheckResponse.class);

		ArgumentCaptor<PartyCodeCheckReq> requestArgumentCaptor = ArgumentCaptor.forClass(PartyCodeCheckReq.class);

		verify(partyService, times(1))
				.loadDuplicatesCode(eq("master"), requestArgumentCaptor.capture());

		PartyCodeCheckReq checkRequest = requestArgumentCaptor.getValue();
		assertThat(checkRequest.getCode(), is(CUAA));
		assertThat(checkRequest.getId(), is(1L));
	}

	@Test
	void test_duplicates_parties_detailed() {
		String taxCode = "11";
		String VatNumber = "12";
		String path = String.format(PrtTest.MASTER_PATH + "/parties/duplicates_detailed");

		PartyCheckReq partyCheckRequest = new PartyCheckReq()
				.setTaxCode(taxCode)
				.setVatNumber(VatNumber)
				.setId(1L);

		ObjectMapper mapper = new ObjectMapper();
		Map<String, Object> beanMap = mapper.convertValue(partyCheckRequest, Map.class);

		WebCliHelper.executeGet(EXT, path, beanMap, WebCliHelper.BASIC_CREDENTIALS, Map.class);

		ArgumentCaptor<PartyCheckReq> requestArgumentCaptor = ArgumentCaptor.forClass(PartyCheckReq.class);

		verify(partyService, times(1))
				.loadDuplicatesDetail(eq("master"), requestArgumentCaptor.capture());

		PartyCheckReq checkRequest = requestArgumentCaptor.getValue();
		assertThat(checkRequest.getTaxCode(), is(taxCode));
		assertThat(checkRequest.getVatNumber(), is(VatNumber));
		assertThat(checkRequest.getId(), is(1L));
	}

	@Test
	void test_delete() {
		String uri = PrtTest.MASTER_PATH + "/parties/123";
		WebCliHelper.executeDelete(EXT, uri, WebCliHelper.BASIC_CREDENTIALS,
				Response.class);
		ArgumentCaptor<ReqContext> reqCtxCaptor = ArgumentCaptor.forClass(ReqContext.class);
		verify(partyService, times(1))
				.expire(reqCtxCaptor.capture(), eq(123L));
		ReqContext reqContext = reqCtxCaptor.getValue();
		assertThat(reqContext.getTenantId(), is("master"));
		assertThat(reqContext.getLang(), is("en"));
		assertThat(reqContext.getUsername(), is(WebCliHelper.BASIC_USERNAME));

	}

	// ----- addFromExternalSource -----
	@Test
	void test_addFromExternalSource_ok() {

		String partyCode = "01234567890";
		String sourceCode = "EXT_TEST";
		PartyExternalReq req = PartyExternalReq.builder()
				.setSourceCode(sourceCode)
				.setPartyCode(partyCode)
				.build();

		PartyRes mockRes = new PartyRes().setId(555L).setCode(partyCode);
		given(externalSourceService.upsertParty(any(), any())).willReturn(mockRes);

		UriBuilder uriBuilder = UriBuilder.fromResource(resource.getClass()).path(resource.getClass(), "addFromExternalSource");
		String uri = uriBuilder.build(TENANT_DEFAULT_CODE).toString();
		System.out.println(uri);

		PartyRes res = EXT.getJerseyTest().client()
				.target(UriBuilder.fromUri(uri))
				.request()
				.header("Authorization", WebCliHelper.BASIC_CREDENTIALS)
				.put(Entity.json(req), new GenericType<>() {});

		org.assertj.core.api.Assertions.assertThat(res)
				.isEqualTo(mockRes);

		verify(externalSourceService).upsertParty(any(ReqContext.class), eq(req));
	}
}
