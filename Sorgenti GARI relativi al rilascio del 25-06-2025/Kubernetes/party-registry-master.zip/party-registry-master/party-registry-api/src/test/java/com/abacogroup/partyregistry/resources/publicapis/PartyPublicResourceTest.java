package com.abacogroup.partyregistry.resources.publicapis;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.hasItems;
import static org.hamcrest.Matchers.is;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.jdbi.paging.impl.InfiniteListResultsImpl;
import com.abacogroup.partyregistry.PrtTest;
import com.abacogroup.partyregistry.api.v1.AppConfigResponseV1;
import com.abacogroup.partyregistry.api.v1.PartyResponseV1;
import com.abacogroup.partyregistry.api.v1.req.PartySearchRequestV1;
import com.abacogroup.partyregistry.core.AclService;
import com.abacogroup.partyregistry.core.AppConfigV1Service;
import com.abacogroup.partyregistry.core.PartyV1Service;
import com.abacogroup.partyregistry.core.impl.AppConfigV1ServiceImpl;
import com.abacogroup.partyregistry.core.impl.PartyV1ServiceImpl;
import com.abacogroup.partyregistry.resources.WebCliHelper;
import com.abacogroup.partyregistry.resources.req.ArchivedEnum;
import com.abacogroup.partyregistry.resources.req.ReqContext;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;
import io.dropwizard.testing.junit5.ResourceExtension;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mockito;

@Slf4j
@ExtendWith(DropwizardExtensionsSupport.class)
class PartyPublicResourceTest {

	private final PartyV1Service partyService = Mockito.mock(PartyV1ServiceImpl.class);
	private final AclService aclService = Mockito.mock(AclService.class);
	private final AppConfigV1Service appConfigV1Service = Mockito.mock(AppConfigV1ServiceImpl.class);

	private final ResourceExtension EXT = WebCliHelper.createEXT(new PartyPublicResource(partyService, aclService,appConfigV1Service));

	@Test
	@SuppressWarnings("unchecked")
	void test_execute_search() {
		Long partyId = -500L;
		String path = String.format(PrtTest.MASTER_PUBLIC_PATH + "/parties");
		PartySearchRequestV1 partySearchReq = new PartySearchRequestV1()
				.setFirstName("gino")
				.setTag(List.of("a", "b"));

		ObjectMapper mapper = new ObjectMapper();
		Map<String, Object> beanMap = mapper.convertValue(partySearchReq, Map.class);

		WebCliHelper.executeGet(EXT, path, beanMap, WebCliHelper.BASIC_CREDENTIALS, InfiniteListResultsImpl.class);

		ArgumentCaptor<ReqContext> reqCtxCaptor = ArgumentCaptor.forClass(ReqContext.class);
		ArgumentCaptor<PartySearchRequestV1> requestArgumentCaptor = ArgumentCaptor.forClass(PartySearchRequestV1.class);
		verify(partyService, times(1))
				.publicSearch(reqCtxCaptor.capture(), requestArgumentCaptor.capture(), any(), eq(null));

		PartySearchRequestV1 searchRequest = requestArgumentCaptor.getValue();
		assertThat(searchRequest.getArchived(), is(ArchivedEnum.not_archived));
		assertThat(searchRequest.getFirstName(), is("gino"));
		assertThat(searchRequest.getTag(), hasItems("a", "b"));

		ReqContext reqContext = reqCtxCaptor.getValue();
		assertThat(reqContext.getTenantId(), is("master"));
		assertThat(reqContext.getLang(), is("en"));
		assertThat(reqContext.getUsername(), is(WebCliHelper.BASIC_USERNAME));

	}

	@Test
	void test_get_by_id() {
		String path = String.format(PrtTest.MASTER_PUBLIC_PATH + "/parties/1");

		given(partyService.getPartyResponseById(Mockito.any(ReqContext.class), Mockito.anyLong()))
				.willReturn(Optional.of(new PartyResponseV1()
						.setLastName("Acme")
						.setBirthDate(AbsoluteDate.of("19891231"))
				));

		String party = WebCliHelper.executeGet(EXT, path, null, WebCliHelper.BASIC_CREDENTIALS, String.class);
		ArgumentCaptor<ReqContext> reqCtxCaptor = ArgumentCaptor.forClass(ReqContext.class);
		verify(partyService, times(1))
				.getPartyResponseById(reqCtxCaptor.capture(), eq(1L));

		ReqContext reqContext = reqCtxCaptor.getValue();
		assertThat(reqContext.getTenantId(), is("master"));
		assertThat(reqContext.getLang(), is("en"));
		assertThat(reqContext.getUsername(), is(WebCliHelper.BASIC_USERNAME));

		assertTrue(party.contains("\"birthDate\":\"19891231\""), "check serializzazione localdate");

	}

	// ----- getByCuaa -----
	@Test
	void test_getByCuaa_ok() {
		String cuaa = "ABCDE";
		String path = PrtTest.MASTER_PUBLIC_PATH + "/parties/code/" + cuaa;

		given(partyService.getPartyResponseByCode(Mockito.any(ReqContext.class), Mockito.anyString()))
				.willReturn(Optional.of(new PartyResponseV1()
						.setLastName("Acme")
						.setBirthDate(AbsoluteDate.of("19891231"))
				));

		String party = WebCliHelper.executeGet(EXT, path, null, WebCliHelper.BASIC_CREDENTIALS, String.class);
		ArgumentCaptor<ReqContext> reqCtxCaptor = ArgumentCaptor.forClass(ReqContext.class);
		verify(partyService, times(1))
				.getPartyResponseByCode(reqCtxCaptor.capture(), eq(cuaa));

		ReqContext reqContext = reqCtxCaptor.getValue();
		assertThat(reqContext.getTenantId(), is("master"));
		assertThat(reqContext.getLang(), is("en"));
		assertThat(reqContext.getUsername(), is(WebCliHelper.BASIC_USERNAME));

		assertTrue(party.contains("\"birthDate\":\"19891231\""), "check serializzazione localdate");
	}


	// ----- code2taxCode -----
	@Test
	void test_config_code_withConfig() {
		String path = PrtTest.MASTER_PUBLIC_PATH + "/parties";


		AppConfigResponseV1 appConfigResponseV1 = new AppConfigResponseV1();
		appConfigResponseV1.setConfiguration(Map.of("mandatory",false,"editable",false));


		PartySearchRequestV1 partySearchReq = new PartySearchRequestV1()
				.setCode("abc")
				.setFirstName("tonic");

		ObjectMapper mapper = new ObjectMapper();
		Map<String, Object> beanMap = mapper.convertValue(partySearchReq, Map.class);

		given(appConfigV1Service.searchByKey(Mockito.any(ReqContext.class), Mockito.anyString()))
				.willReturn(Optional.of(
						appConfigResponseV1
						)
				);


		WebCliHelper.executeGet(EXT, path, beanMap, WebCliHelper.BASIC_CREDENTIALS, InfiniteListResultsImpl.class);

		ArgumentCaptor<ReqContext> reqCtxCaptor = ArgumentCaptor.forClass(ReqContext.class);
		ArgumentCaptor<PartySearchRequestV1> requestArgumentCaptor = ArgumentCaptor.forClass(PartySearchRequestV1.class);
		ArgumentCaptor<String> requestCodeCaptor = ArgumentCaptor.forClass(String.class);
		verify(partyService, times(1))
				.publicSearch(reqCtxCaptor.capture(), requestArgumentCaptor.capture(), any(), eq(null));
		verify(appConfigV1Service, times(1))
				.searchByKey(reqCtxCaptor.capture(), requestCodeCaptor.capture());

		PartySearchRequestV1 searchRequest = requestArgumentCaptor.getValue();
		assertThat(searchRequest.getArchived(), is(ArchivedEnum.not_archived));
		//! critical test condition
		assertNull(searchRequest.getTaxOrVat());
		assertEquals(searchRequest.getCode(),partySearchReq.getCode());
		assertThat(searchRequest.getFirstName(), is("tonic"));
		assertThat(requestCodeCaptor.getValue(), is("code"));

	}


	@Test
	void test_config_code_configMissing() {
		String path = PrtTest.MASTER_PUBLIC_PATH + "/parties";


		AppConfigResponseV1 appConfigResponseV1 = new AppConfigResponseV1();
		appConfigResponseV1.setConfiguration(Map.of("mandatory",true,"editable",false));


		PartySearchRequestV1 partySearchReq = new PartySearchRequestV1()
				.setCode("abc")
				.setFirstName("tonic");

		ObjectMapper mapper = new ObjectMapper();
		Map<String, Object> beanMap = mapper.convertValue(partySearchReq, Map.class);

		given(appConfigV1Service.searchByKey(Mockito.any(ReqContext.class), Mockito.anyString()))
				.willReturn(Optional.ofNullable(null)
				);


		WebCliHelper.executeGet(EXT, path, beanMap, WebCliHelper.BASIC_CREDENTIALS, InfiniteListResultsImpl.class);

		ArgumentCaptor<ReqContext> reqCtxCaptor = ArgumentCaptor.forClass(ReqContext.class);
		ArgumentCaptor<PartySearchRequestV1> requestArgumentCaptor = ArgumentCaptor.forClass(PartySearchRequestV1.class);
		ArgumentCaptor<String> requestCodeCaptor = ArgumentCaptor.forClass(String.class);
		verify(partyService, times(1))
				.publicSearch(reqCtxCaptor.capture(), requestArgumentCaptor.capture(), any(), eq(null));
		verify(appConfigV1Service, times(1))
				.searchByKey(reqCtxCaptor.capture(), requestCodeCaptor.capture());

		PartySearchRequestV1 searchRequest = requestArgumentCaptor.getValue();
		assertThat(searchRequest.getArchived(), is(ArchivedEnum.not_archived));
		assertThat(searchRequest.getFirstName(), is("tonic"));
		//! critical test condition
		assertThat(searchRequest.getTaxOrVat(),is(partySearchReq.getCode()));
		assertNull(searchRequest.getCode());
		assertThat(requestCodeCaptor.getValue(), is("code"));
	}
}
