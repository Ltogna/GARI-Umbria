package com.abacogroup.partyregistry;

import static org.assertj.core.api.Assertions.assertThat;

import com.abacogroup.bundles.initializer.impl.BundleInitServiceImpl;
import com.abacogroup.bundles.initializer.impl.BundleInitServiceProducer;
import com.abacogroup.dynamicdocuments.dao.DocumentTypeDAO;
import com.abacogroup.jdbi.orderby.OrderByBuilder;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.partyregistry.db.dao.CitizenshipDAO;
import com.abacogroup.partyregistry.db.dao.RelationRoleDAO;
import com.abacogroup.partyregistry.db.dao.RelationTypeDAO;
import com.abacogroup.partyregistry.db.dao.TagDAO;
import com.abacogroup.partyregistry.resources.req.ReqContext;
import com.rabbitmq.client.Connection;
import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;
import java.io.IOException;
import java.time.OffsetDateTime;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeoutException;
import lombok.SneakyThrows;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

// need execMigrations=true
// need initRabbit=true
@Disabled
@ExtendWith(DropwizardExtensionsSupport.class)
class ConfigDataConsumerIT extends JdbiTest {

	public static final String TENANT = "test_*";

	@BeforeEach
		//@AfterEach
	void clean() {
		execSqlFiles(PrtTest.class, List.of("rollback"), Map.of("test_tenant", TENANT));
	}

	@Test
	@SneakyThrows
	void test_receive_ok() {
		pushConfig("src/test/resources/com/abacogroup/partyregistry/ConfigDataConsumerIT/test_receive_ok");

		Thread.sleep(500);

		System.out.println("*********");
		assertThat(super.getDAO(CitizenshipDAO.class).countAll(TENANT)).isEqualTo(3);
		assertThat(super.getDAO(DocumentTypeDAO.class).selectDocTypeFromCodeAndTenant(TENANT, "BANK", OffsetDateTime.now())).isPresent();
		assertThat(super.getDAO(RelationTypeDAO.class).infinite(() -> super.getDAO(RelationTypeDAO.class)
				.searchAll(null, OrderByBuilder.field("id"), new ReqContext(TENANT, "")), null, 100))
				.extracting(InfiniteListResults::getCount).isEqualTo(1);
		assertThat(super.getDAO(RelationRoleDAO.class).infinite(() -> super.getDAO(RelationRoleDAO.class)
				.searchAll(null, OrderByBuilder.field("id"), new ReqContext(TENANT, "")), null, 100))
				.extracting(InfiniteListResults::getCount).isEqualTo(1);
		assertThat(super.getDAO(TagDAO.class).infinite(() -> super.getDAO(TagDAO.class)
				.searchAll(null, OrderByBuilder.field("id"), new ReqContext(TENANT, "")), null, 100))
				.extracting(InfiniteListResults::getCount).isEqualTo(2);

	}

	@Test
	@SneakyThrows
	void test_receive_koAndRollback() {
		pushConfig("src/test/resources/com/abacogroup/partyregistry/ConfigDataConsumerIT/test_receive_ko");

		Thread.sleep(500);

		System.out.println("*********");
		assertThat(super.getDAO(CitizenshipDAO.class).countAll(TENANT)).isEqualTo(0);
		assertThat(super.getDAO(DocumentTypeDAO.class).selectDocTypeFromCodeAndTenant(TENANT, "BANK", OffsetDateTime.now())).isNotPresent();
		assertThat(super.getDAO(RelationTypeDAO.class).infinite(() -> super.getDAO(RelationTypeDAO.class)
				.searchAll(null, OrderByBuilder.field("id"), new ReqContext(TENANT, "")), null, 100))
				.extracting(InfiniteListResults::getCount).isEqualTo(0);
		assertThat(super.getDAO(RelationRoleDAO.class).infinite(() -> super.getDAO(RelationRoleDAO.class)
				.searchAll(null, OrderByBuilder.field("id"), new ReqContext(TENANT, "")), null, 100))
				.extracting(InfiniteListResults::getCount).isEqualTo(0);
		assertThat(super.getDAO(TagDAO.class).infinite(() -> super.getDAO(TagDAO.class)
				.searchAll(null, OrderByBuilder.field("id"), new ReqContext(TENANT, "")), null, 100))
				.extracting(InfiniteListResults::getCount).isEqualTo(0);

	}

	private void pushConfig(String configLocation) throws IOException, TimeoutException {
		System.out.println("##########");
		System.out.println("##########");
		PartyRegistryConfiguration configuration = EXT.getConfiguration();
		Connection connection = ((PartyRegistryApplicationTest) EXT.getApplication()).createRabbitmqConnection(configuration);

		//attenzione che va sulle conf rabbit di dev
		BundleInitServiceProducer producer = new BundleInitServiceProducer(connection);
		BundleInitServiceImpl initService = new BundleInitServiceImpl(producer, configLocation,
				configuration.getBundleConfig().getInitBaseTempDir());
		initService.start();
		System.out.println("##########");
		System.out.println("##########");
	}
}
