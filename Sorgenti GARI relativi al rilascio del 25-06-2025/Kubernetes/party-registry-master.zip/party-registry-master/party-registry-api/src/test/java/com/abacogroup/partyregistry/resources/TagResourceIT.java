package com.abacogroup.partyregistry.resources;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.hasSize;

import com.abacogroup.jdbi.paging.impl.InfiniteListResultsImpl;
import com.abacogroup.partyregistry.JdbiTest;
import com.abacogroup.partyregistry.PrtTest;
import com.abacogroup.partyregistry.api.Tag;
import com.abacogroup.partyregistry.resources.req.TagSearchReq;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;
import java.util.List;
import java.util.Map;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

@Slf4j
@ExtendWith(DropwizardExtensionsSupport.class)
class TagResourceIT extends JdbiTest {

	private final ObjectMapper mapper = new ObjectMapper();

	@Test
	@SuppressWarnings("all")
	void test_list() {
		String path = String.format(PrtTest.MASTER_PATH + "/tags");
		TagSearchReq searchParams = new TagSearchReq()
				//.setCode("lol")
				;
		Map<String, Object> beanMap = mapper.convertValue(searchParams, Map.class);

		InfiniteListResultsImpl<Tag> list = WebCliHelper.executeGet(EXT, path, beanMap, WebCliHelper.BASIC_CREDENTIALS,
				InfiniteListResultsImpl.class);

		assertThat(list.getRecords(), hasSize(0));

	}

	@Test
	@SuppressWarnings("all")
	void test_searchList() {
		String path = String.format(PrtTest.MASTER_PATH + "/tags/list");
		TagSearchReq searchParams = new TagSearchReq();
		Map<String, Object> beanMap = mapper.convertValue(searchParams, Map.class);

		List<Tag> list = WebCliHelper.executeGet(EXT, path, beanMap, WebCliHelper.BASIC_CREDENTIALS,
				List.class);

		assertThat(list, hasSize(0));

	}

}



