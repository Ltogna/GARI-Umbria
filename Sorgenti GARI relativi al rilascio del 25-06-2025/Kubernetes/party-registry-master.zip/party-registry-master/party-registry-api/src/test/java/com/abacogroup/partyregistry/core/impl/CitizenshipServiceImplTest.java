package com.abacogroup.partyregistry.core.impl;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;

import com.abacogroup.partyregistry.JdbiTest;
import com.abacogroup.partyregistry.PrtTest;
import com.abacogroup.partyregistry.api.Citizenship;
import com.abacogroup.partyregistry.core.CitizenshipService;
import com.abacogroup.partyregistry.db.dao.CitizenshipDAO;
import com.abacogroup.partyregistry.resources.req.CitizenshipSearchReq;
import com.abacogroup.partyregistry.resources.req.ReqContext;
import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;

@Slf4j
@ExtendWith(DropwizardExtensionsSupport.class)
class CitizenshipServiceImplTest extends JdbiTest {

	private static final String tenantId = "CitizenshipServiceImplTest_t";
	private static final String currentUser = "CitizenshipServiceImplTest_u";

	private static final ReqContext reqContext =
			new ReqContext(tenantId, currentUser, "en");

	private static final Map<String, Object> testScriptParams = Map.of(
			"test_tenant", tenantId,
			"user_id", currentUser
	);
	private final CitizenshipDAO dao = getDAO(CitizenshipDAO.class);
	private final CitizenshipService service = new CitizenshipServiceImpl(dao);

	@BeforeAll
	@AfterAll
	public static void beforeAll() {
		List<String> initScripts = List.of("rollback");
		execSqlFiles(PrtTest.class, initScripts, testScriptParams);
	}

	@ParameterizedTest
	@MethodSource
	void test_search(String ignoredTitle, CitizenshipSearchReq request, List<Long> results) {
		setUnusedBindingAllowed(true);
		getJdbi().useHandle(handle -> {
			handle.begin();

			List<String> initScripts = List.of("citizenships");
			execSqlFiles(this.getClass(), initScripts, testScriptParams);

			List<Citizenship> list = this.service
					.search(reqContext, request, null)
					.getRecords();
			List<String> actual = list.stream()
					.map(Citizenship::getCode)
					.collect(Collectors.toList());
			assertThat(actual, is(results));

			handle.rollback();
		});

	}

	private static Stream<Arguments> test_search() {
		return Stream.of(
				Arguments.of("just_tenant", new CitizenshipSearchReq()
						, List.of("DEU", "FRA", "GBR", "ITA", "TUN"))

				, Arguments.of("by_code", new CitizenshipSearchReq()
								.setCode("ITA"),
						List.of("ITA"))

				, Arguments.of("by_i18n", new CitizenshipSearchReq()
								.setI18nCode("deu_en"),
						List.of("DEU"))
		);
	}

	@Test
	void test_getByCode() {

		setUnusedBindingAllowed(true);
		getJdbi().useHandle(handle -> {
			handle.begin();

			List<String> initScripts = List.of("citizenships");
			execSqlFiles(this.getClass(), initScripts, testScriptParams);

			Citizenship citizenship = this.service.getByCode(reqContext, "GBR")
					.orElseThrow();
			assertThat("a citizenship of this tenant", citizenship.getCode(), is("GBR"));
			assertThat(citizenship.getI18nCode(), is("gbr_en"));

			Citizenship bothTenantCitizenship = this.service.getByCode(reqContext, "ITA")
					.orElseThrow();
			assertThat("both tenants citizenship", bothTenantCitizenship.getCode(), is("ITA"));
			assertThat(bothTenantCitizenship.getI18nCode(), is("ita_en"));

			Optional<Citizenship> otherTenantCitizenship = this.service.getByCode(reqContext, "LTU");
			assertThat("other tenant citizenship", otherTenantCitizenship.isEmpty(), is(true));

			Optional<Citizenship> notFound = this.service.getByCode(reqContext, "YYY");
			assertThat("not found", notFound.isEmpty(), is(true));

			handle.rollback();
		});

	}

}
