package com.abacogroup.partyregistry.core.impl;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.hasSize;
import static org.junit.jupiter.api.Assertions.assertFalse;

import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.hamcrest.Matchers;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.partyregistry.JdbiTest;
import com.abacogroup.partyregistry.PrtTest;
import com.abacogroup.partyregistry.api.GenderEnum;
import com.abacogroup.partyregistry.api.PartyRes;
import com.abacogroup.partyregistry.api.PartySearchRes;
import com.abacogroup.partyregistry.api.PartyTypeEnum;
import com.abacogroup.partyregistry.core.AclService;
import com.abacogroup.partyregistry.core.PartyService;
import com.abacogroup.partyregistry.core.exceptions.ErrCodes;
import com.abacogroup.partyregistry.core.exceptions.InvalidPartyException;
import com.abacogroup.partyregistry.resources.req.PartyCreateReq;
import com.abacogroup.partyregistry.resources.req.PartyCreateReq.PartyCreateReqBuilder;
import com.abacogroup.partyregistry.resources.req.PartySearchReq;
import com.abacogroup.partyregistry.resources.req.ReqContext;

import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@ExtendWith(DropwizardExtensionsSupport.class)
public class PartyServiceImplCUAATest extends JdbiTest {

	private static final String NO_EXTERNAL_SOURCE_CODE = null;
	
	private static final String currentUser = "PartyServiceImplCUAATest_u";
	private static final String tenantId = "PartyServiceImplCUAATest_t";

	private static final Map<String, Object> testScriptParams = Map.of(
			"test_tenant", tenantId,
			"user_id", currentUser
	);

	private static final ReqContext reqContext =
			new ReqContext(tenantId, currentUser, "en");
	private final PartyService service = getService(PartyServiceImpl.class);

	@BeforeAll
	@AfterAll
	public static void beforeAll() {
		List<String> initScripts = List.of("rollback");
		execSqlFiles(PrtTest.class, initScripts, testScriptParams);
	}

	@Test
	void test_insert_with_existent_CUAA() {
		setUnusedBindingAllowed(true);
		getJdbi().useHandle(handle -> {
			handle.begin();

			String existentCUAA = "PNLCR120";
			List<String> initScripts = List.of("insert_parties", "app_config1");
			execSqlFiles(this.getClass(), initScripts, testScriptParams);

			PartyCreateReq request = givenCreateRequest().setCode(existentCUAA).build();

			InvalidPartyException exception = Assertions.assertThrows(InvalidPartyException.class, () -> {
				this.service.insert(reqContext, request, NO_EXTERNAL_SOURCE_CODE);
			});

			assertThat("CUAA already exists", exception.getCode(), Matchers.is(ErrCodes.INVALID_PAYLOAD));

			handle.rollback();
		});
	}

	@Test
	void test_update_addExistingCode() {
		setUnusedBindingAllowed(true);
		getJdbi().useHandle(handle -> {
			handle.begin();

			String existentCode = "PNLCR120";
			List<String> initScripts = List.of("insert_parties", "app_config2");
			execSqlFiles(this.getClass(), initScripts, testScriptParams);

			PartyCreateReq request = givenCreateRequest().setCode(null).build();

			PartyRes created = this.service.insert(reqContext, request, NO_EXTERNAL_SOURCE_CODE);

			request.setCode(existentCode);

			InvalidPartyException exception = Assertions.assertThrows(InvalidPartyException.class, () -> {
				this.service.update(reqContext, created.getId(), request);
			});

			assertThat("CUAA already exists", exception.getCode(), Matchers.is(ErrCodes.INVALID_PAYLOAD));

			handle.rollback();
		});
	}

	@Test
	void test_search_by_CUAA_mapping_ok() {
		setUnusedBindingAllowed(true);
		getJdbi().useHandle(handle -> {
			handle.begin();
			handle.begin();

			String CUAA_lowerCase = "pnlcr120";
			String CUAA_upperCase = "VRKCL140";

			List<String> initScripts = List.of("insert_parties", "app_config1");
			execSqlFiles(this.getClass(), initScripts, testScriptParams);

			PartySearchReq request = new PartySearchReq().setCode(CUAA_lowerCase);
			List<PartySearchRes> list1 = this.service.search(reqContext, request, AclService.MANAGE_READ, null).getRecords();

			assertThat(list1, hasSize(1));
			assertThat(list1.get(0).getId(), is(-666L));
			assertFalse(list1.get(0).isArchived());

			List<PartySearchRes> list2 = this.service.search(reqContext, request.setCode(CUAA_upperCase),  AclService.MANAGE_READ,null).getRecords();

			assertThat(list2, hasSize(1));
			assertThat(list2.get(0).getId(), is(-555L));
			assertFalse(list2.get(0).isArchived());

			handle.rollback();
		});

	}

	// ----- getPartyByCuaa -----
	@Test
	void test_getPartyByCuaa_ok() {
		setUnusedBindingAllowed(true);
		getJdbi().useHandle(handle -> {
			handle.begin();
			handle.begin();

			String CUAA_upperCase = "VRKCL140";

			List<String> initScripts = List.of("insert_parties", "app_config1");
			execSqlFiles(this.getClass(), initScripts, testScriptParams);

			Optional<PartyRes> partyByCuaa = service.getPartyByCode(reqContext, CUAA_upperCase);

			org.assertj.core.api.Assertions.assertThat(partyByCuaa).isPresent().get()
					.extracting(PartyRes::getId).isEqualTo(-555L);

			handle.rollback();
		});
	}

	//*****************************************************

	private PartyCreateReqBuilder<?, ?> givenCreateRequest() {
		return PartyCreateReq.builder()
				.setPartyType(PartyTypeEnum.N)
				.setGender(GenderEnum.M)
				.setLastName("acme")
				.setFirstName("json")
				.setBirthDate(AbsoluteDate.of("19490917"))
				.setDeathDate(AbsoluteDate.of("20500917"))
				.setBirthMunicipality("ITA_00_000_000")
				.setNationality("ITA")
				.setArchived(false);
	}

}
