package com.abacogroup.partyregistry.bundle.tenant;

import static com.abacogroup.bundles.Constants.ALL_TENANTS;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.greaterThanOrEqualTo;

import com.abacogroup.bundles.listener.tenant.TenantMessage;
import com.abacogroup.partyregistry.JdbiTest;
import com.abacogroup.partyregistry.db.dao.AppConfigDAO;
import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

@Slf4j
@ExtendWith(DropwizardExtensionsSupport.class)
class AppConfigTenantMessageProcessorTest extends JdbiTest {

	private final AppConfigTenantMessageProcessor service = getService(AppConfigTenantMessageProcessor.class);

	@Test
	public void testOnMessage() {
		AppConfigDAO dao = getDAO(AppConfigDAO.class);
		int defaultCount = dao.findAll(ALL_TENANTS).size();
		assertThat(defaultCount, greaterThanOrEqualTo(0));

		getJdbi().useHandle(handle -> {
			handle.begin();
			String newTenant = "tnt";

			service.onMessage(new TenantMessage()
					.setTenantId(newTenant));

			assertThat(dao.findAll(newTenant).size(), is(defaultCount));
			handle.rollback();
		});
	}
}
