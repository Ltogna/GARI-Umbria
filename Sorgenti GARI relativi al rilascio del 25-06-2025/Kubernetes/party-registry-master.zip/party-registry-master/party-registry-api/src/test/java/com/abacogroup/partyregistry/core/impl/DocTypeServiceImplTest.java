package com.abacogroup.partyregistry.core.impl;

import static org.assertj.core.api.Assertions.assertThat;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;

import com.abacogroup.bundles.listener.tenant.TenantMessage;
import com.abacogroup.dynamicdocuments.bean.SummaryFieldDefinition;
import com.abacogroup.partyregistry.JdbiTest;
import com.abacogroup.partyregistry.api.DocType;
import com.abacogroup.partyregistry.api.PartyTypeEnum;
import com.abacogroup.partyregistry.api.Tag;
import com.abacogroup.partyregistry.bundle.tenant.DynamicDocTenantMessageProcessor;
import com.abacogroup.partyregistry.bundle.tenant.TagTenantMessageProcessor;
import com.abacogroup.partyregistry.core.DocTypeService;
import com.abacogroup.partyregistry.core.TagService;
import com.abacogroup.partyregistry.resources.req.DocTypeSearchReq;
import com.abacogroup.partyregistry.resources.req.ReqContext;
import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.tuple.Pair;
import org.assertj.core.groups.Tuple;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;

@Slf4j
@ExtendWith(DropwizardExtensionsSupport.class)
public class DocTypeServiceImplTest extends JdbiTest {

	private static final String currentUser = "U_tst49";
	private static final String tenant = "T_tst49";
	private static final ReqContext context = new ReqContext(tenant, currentUser);
	private static final Map<String, Object> testScriptParams = Map.of(
			"test_tenant", tenant,
			"user_id", currentUser
	);
	private final DocTypeService service = getService(DocTypeServiceImpl.class);
	private final DynamicDocTenantMessageProcessor tenantMessageProcessor = getService(DynamicDocTenantMessageProcessor.class);
	private final TagService tagService = getService(TagServiceImpl.class);

	private final TagTenantMessageProcessor tagProcessor = getService(TagTenantMessageProcessor.class);

	@Test
	void testSearch_ByTags() {
		getJdbi().useHandle(handle -> {
			handle.begin();

			TenantMessage tenantMessage = new TenantMessage();
			tenantMessage.setTenantId(tenant);
			tagProcessor.onMessage(tenantMessage);
			tenantMessageProcessor.onMessage(tenantMessage);
			//
			//			execSqlFiles(this.getClass(), List.of("custom_doc_type_relations"), testScriptParams);

			long forn = tagService.getTagByCode(context, "FORNITORE").map(Tag::getId).orElseThrow();
			long inqu = tagService.getTagByCode(context, "INQUILINO").map(Tag::getId).orElseThrow();

			List<DocType> list = this.service
					.search(context, new DocTypeSearchReq(), new ArrayList<>(), PartyTypeEnum.values());
			list.forEach(System.out::println);

			assertThat(list).hasSize(2)
					.extracting(DocType::getDocType)
					.containsExactlyInAnyOrder("EARNINGS", "EINVOICING");

			assertThat(this.service.search(context, new DocTypeSearchReq(), List.of(forn), PartyTypeEnum.values()))
					.hasSize(3)
					.extracting(DocType::getDocType)
					.containsExactlyInAnyOrder("EARNINGS", "EINVOICING", "ID");

			assertThat(this.service.search(context, new DocTypeSearchReq(), List.of(inqu), PartyTypeEnum.values()))
					.extracting(DocType::getDocType)
					.containsExactlyInAnyOrder("EARNINGS", "EINVOICING", "ID", "BANK");

			assertThat(this.service.search(context, new DocTypeSearchReq(), List.of(forn, inqu), PartyTypeEnum.values()))
					.extracting(DocType::getDocType)
					.containsExactlyInAnyOrder("EARNINGS", "EINVOICING", "ID", "BANK");

			handle.rollback();
			//handle.commit();

		});

	}

	@ParameterizedTest
	@MethodSource
	public void test_search(String ignoredTitle, DocTypeSearchReq request, List<Long> results) {

		getJdbi().useHandle(handle -> {
			handle.begin();

			execSqlFiles(this.getClass(), List.of("doctype"), testScriptParams);

			TenantMessage tenantMessage = new TenantMessage();
			tenantMessage.setTenantId(tenant);
			tenantMessageProcessor.onMessage(tenantMessage);

			List<DocType> list = this.service.search(context, request, List.of(), PartyTypeEnum.values());
			List<String> actual = list.stream()
					.map(DocType::getDocType)
					.collect(Collectors.toList());
			assertThat(actual, is(results));

			handle.rollback();
		});

	}

	private static Stream<Arguments> test_search() {
		return Stream.of(
				Arguments.of("search_all", new DocTypeSearchReq()
						, List.of("BANK", "EARNINGS", "EINVOICING", "ID"))

				, Arguments.of("by_doc_type", new DocTypeSearchReq()
								.setDocType("EARNINGS"),
						List.of("EARNINGS"))

				, Arguments.of("by_doc_type_expired", new DocTypeSearchReq()
								.setDocType("EXPIRED"),
						List.of())

				, Arguments.of("by_i18n_doc_type", new DocTypeSearchReq()
								.setI18nDocType("id_en"),
						List.of("ID"))

				, Arguments.of("by_doc_type_and_i18N", new DocTypeSearchReq()
								.setI18nDocType("bank_en")
								.setDocType("BANK"),
						List.of("BANK"))

				, Arguments.of("by_doc_type_and_i18N_exp", new DocTypeSearchReq()
								.setI18nDocType("expired_en")
								.setDocType("EXPIRED"),
						List.of())

				, Arguments.of("inconsistent_filters", new DocTypeSearchReq()
								.setI18nDocType("bank_en")
								.setDocType("IDENTITY_CARD"),
						List.of())
		);
	}

	@Test
	void test_search_with_summaries() {

		getJdbi().useHandle(handle -> {
			handle.begin();

			execSqlFiles(this.getClass(), List.of("doctype"), testScriptParams);

			TenantMessage tenantMessage = new TenantMessage();
			tenantMessage.setTenantId(tenant);
			tenantMessageProcessor.onMessage(tenantMessage);

			DocTypeSearchReq req = new DocTypeSearchReq()
					.setDocType("BANK");

			List<DocType> list = this.service.search(context, req, List.of(), PartyTypeEnum.values());
			assertThat(list.get(0).getSummaryFieldDefinitions()).hasSize(3)
					.extracting(SummaryFieldDefinition::getCode, SummaryFieldDefinition::getDescription)
					.containsExactlyInAnyOrder(
							Tuple.tuple("bank_name", "bank name"),
							Tuple.tuple("iban", "iban"),
							Tuple.tuple("swift", "swift")
					);

			handle.rollback();
		});

	}

	@ParameterizedTest
	@MethodSource
	void test_get_by_doc_type(String ignoredTitle, String docTypeParam, Pair<String, String> expectedType, Pair<String, String> expectedGroup) {

		getJdbi().useHandle(handle -> {
			handle.begin();

			execSqlFiles(this.getClass(), List.of("doctype"), testScriptParams);

			TenantMessage tenantMessage = new TenantMessage();
			tenantMessage.setTenantId(tenant);
			tenantMessageProcessor.onMessage(tenantMessage);

			Optional<DocType> actual = this.service.getByDocType(context, docTypeParam);

			String expectedDocType = Optional.ofNullable(expectedType).map(x -> x.getLeft()).orElse(null);
			String expectedI18NDocType = Optional.ofNullable(expectedType).map(x -> x.getRight()).orElse(null);
			String actualDocType = actual.map(x -> x.getDocType()).orElse(null);
			String actualI18NDocType = actual.map(x -> x.getI18nDocType()).orElse(null);

			assertThat(actualDocType, is(expectedDocType));
			assertThat(actualI18NDocType, is(expectedI18NDocType));

			String expectedDocGroup = Optional.ofNullable(expectedGroup).map(x -> x.getLeft()).orElse(null);
			String expectedI18NDocGroup = Optional.ofNullable(expectedGroup).map(x -> x.getRight()).orElse(null);
			String actualDocGroup = actual.map(x -> x.getDocGroup()).orElse(null);
			String actualI18NDocGroup = actual.map(x -> x.getI18nDocGroup()).orElse(null);

			assertThat(actualDocGroup, is(expectedDocGroup));
			assertThat(actualI18NDocGroup, is(expectedI18NDocGroup));

			handle.rollback();
		});

	}

	private static Stream<Arguments> test_get_by_doc_type() {

		return Stream.of(
				Arguments.of("by_doc_type_existing_1", "BANK", Pair.of("BANK", "bank_en"), Pair.of("finanziaria", "finanziaria_en")),
				Arguments.of("by_doc_type_existing_2", "ID", Pair.of("ID", "id_en"), Pair.of(null, null)),
				Arguments.of("by_doc_type_existing_3", "EINVOICING", Pair.of("EINVOICING", "einvoicing_en"), Pair.of("commercial", "commercial_en")),
				Arguments.of("by_doc_type_non_existing_1", "NON_EXISTING_1", null, Pair.of(null, null)),
				Arguments.of("by_doc_type_non_existing_2", "NON_EXISTING_2", null, Pair.of(null, null)),
				Arguments.of("by_doc_type_expired", "EXPIRED", null, Pair.of(null, null))

		);
	}

	@ParameterizedTest
	@MethodSource
	void test_searchAsList_isMultiple_docType(String ignoredTitle, DocTypeSearchReq request, boolean multipleExpected) {

		getJdbi().useHandle(handle -> {
			handle.begin();

			execSqlFiles(this.getClass(), List.of("doctype"), testScriptParams);

			TenantMessage tenantMessage = new TenantMessage();
			tenantMessage.setTenantId(tenant);
			tenantMessageProcessor.onMessage(tenantMessage);

			List<DocType> list = this.service.search(context, request, List.of(), PartyTypeEnum.values());
			assertThat(list.get(0).isMultiple(), is(multipleExpected));

			handle.rollback();
		});

	}

	private static Stream<Arguments> test_searchAsList_isMultiple_docType() {
		return Stream.of(Arguments.of("bank docType", new DocTypeSearchReq()
						.setDocType("BANK"), true)

				, Arguments.of(" earnings ", new DocTypeSearchReq()
						.setDocType("EARNINGS"), true)

				, Arguments.of(" invoicing ", new DocTypeSearchReq()
						.setDocType("EINVOICING"), false)

				, Arguments.of(" identity ", new DocTypeSearchReq()
						.setDocType("ID"), true)
		);
	}
}
