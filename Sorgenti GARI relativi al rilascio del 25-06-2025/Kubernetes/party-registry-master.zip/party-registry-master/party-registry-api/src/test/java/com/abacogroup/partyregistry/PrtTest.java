package com.abacogroup.partyregistry;

import java.time.LocalDate;
import java.time.LocalDateTime;

public class PrtTest {

	public static final String TENANT_DEFAULT_CODE = "master";

	public static final String CURRENT_USER = "testUser";
	public static final String TEST_TENANT = "testTenant";

	public static final String TAG_BUG = "BUG";

	public static final Long RELATION_TYPE_NUCLEO_FAM = -13L;
	public static final Long RELATION_TYPE_RIF_CONTATTI = -11L;

	public static final String MASTER_PATH = String.format("/%s/api-priv/v1", TENANT_DEFAULT_CODE);
	public static final String MASTER_PUBLIC_PATH = String.format("/%s/public/v1", TENANT_DEFAULT_CODE);

	public static final LocalDateTime active = LocalDate.of(9999, 12, 31).atTime(23, 59, 59, 9);

	public static final Long PARTY999 = -999L;
}
