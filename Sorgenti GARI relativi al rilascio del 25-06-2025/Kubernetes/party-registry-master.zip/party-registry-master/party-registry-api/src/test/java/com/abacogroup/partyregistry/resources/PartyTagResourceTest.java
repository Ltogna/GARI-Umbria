package com.abacogroup.partyregistry.resources;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.hasSize;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.startsWith;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import com.abacogroup.partyregistry.PrtTest;
import com.abacogroup.partyregistry.api.PartyTag;
import com.abacogroup.partyregistry.api.Tag;
import com.abacogroup.partyregistry.core.AclService;
import com.abacogroup.partyregistry.core.PartyTagService;
import com.abacogroup.partyregistry.core.exceptions.ErrCodes;
import com.abacogroup.partyregistry.core.exceptions.InvalidTagException;
import com.abacogroup.partyregistry.core.impl.PartyServiceImpl;
import com.abacogroup.partyregistry.resources.req.CodeReq;
import com.abacogroup.partyregistry.resources.req.ReqContext;
import com.abacogroup.testutils.FieldErrorUtils;
import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;
import io.dropwizard.testing.junit5.ResourceExtension;
import jakarta.ws.rs.ClientErrorException;
import jakarta.ws.rs.core.Response;
import java.util.List;
import java.util.Map;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mockito;

@ExtendWith(DropwizardExtensionsSupport.class)
class PartyTagResourceTest {

	private final AclService aclService = Mockito.mock(AclService.class);
	private final PartyTagService partyService = Mockito.mock(PartyServiceImpl.class);

	private final ResourceExtension EXT = WebCliHelper.createEXT(new PartyTagResource(aclService, partyService));

	@Test
	@SuppressWarnings("unchecked")
	void test_list_party_tags() {
		String path = String.format(PrtTest.MASTER_PATH + "/parties/1/tags");

		given(partyService.getPartyTags(any(ReqContext.class), anyLong())).willReturn(List.of(
				PartyTag.builder()
						.setTagId(1L)
						.setTagCode("A")
						.build(),

				PartyTag.builder()
						.setTagId(2L)
						.setTagCode("B")
						.build()
		));

		List<Tag> mockList = WebCliHelper.executeGet(EXT, path, null, WebCliHelper.BASIC_CREDENTIALS, List.class);

		ArgumentCaptor<ReqContext> reqCtxCaptor = ArgumentCaptor.forClass(ReqContext.class);
		verify(partyService, times(1))
				.getPartyTags(reqCtxCaptor.capture(), eq(1L));

		assertThat(mockList, hasSize(2));
	}

	@Test
	void test_attach_tag() {
		String path = String.format(PrtTest.MASTER_PATH + "/parties/1/tags");

		Tag ignored = WebCliHelper.executePost(EXT, path, new CodeReq().setCode("SOME_TAG"), WebCliHelper.BASIC_CREDENTIALS,
				Tag.class);

		ArgumentCaptor<ReqContext> reqCtxCaptor = ArgumentCaptor.forClass(ReqContext.class);
		verify(partyService, times(1))
				.attachTag(reqCtxCaptor.capture(), eq(1L), eq("SOME_TAG"));

		ReqContext reqContext = reqCtxCaptor.getValue();
		assertThat(reqContext.getTenantId(), is("master"));
		assertThat(reqContext.getLang(), is("en"));
		assertThat(reqContext.getUsername(), is(WebCliHelper.BASIC_USERNAME));
	}

	@Test
	void test_attach_tag_err() {
		String path = String.format(PrtTest.MASTER_PATH + "/parties/1/tags");

		given(partyService.attachTag(any(ReqContext.class), anyLong(), anyString())).willThrow(
				new InvalidTagException(ErrCodes.TAG_NOT_FOUND, "invalid tag x"));

		ClientErrorException ex = Assertions.assertThrows(ClientErrorException.class, () -> {
			Tag ignored = WebCliHelper.executePostNoBody(EXT, path, null, Map.of("tag", "SOME_TAG"),
					WebCliHelper.BASIC_CREDENTIALS,
					Tag.class);
		});

	}

	@Test
	void test_attach_tag_with_empty_tag_code() {
		String path = String.format(PrtTest.MASTER_PATH + "/parties/1/tags");

		ClientErrorException ex = Assertions.assertThrows(ClientErrorException.class, () -> {
			WebCliHelper.executePost(EXT, path, new CodeReq().setCode(null),
					WebCliHelper.BASIC_CREDENTIALS, Tag.class);
		});

		List<String> errors = FieldErrorUtils.extractErrorFieldNames(ex);
		assertThat(errors, hasSize(1));
		assertThat(errors.get(0), startsWith("code"));
	}

	@Test
	void test_detach_tag() {
		String path = String.format(PrtTest.MASTER_PATH + "/parties/1/tags/SOME_TAG");

		WebCliHelper.executeDelete(EXT, path, WebCliHelper.BASIC_CREDENTIALS, Response.class);

		ArgumentCaptor<ReqContext> reqCtxCaptor = ArgumentCaptor.forClass(ReqContext.class);
		verify(partyService, times(1))
				.detachTag(reqCtxCaptor.capture(), eq(1L), eq("SOME_TAG"));

		ReqContext reqContext = reqCtxCaptor.getValue();
		assertThat(reqContext.getTenantId(), is("master"));
		assertThat(reqContext.getLang(), is("en"));
		assertThat(reqContext.getUsername(), is(WebCliHelper.BASIC_USERNAME));

	}

}
