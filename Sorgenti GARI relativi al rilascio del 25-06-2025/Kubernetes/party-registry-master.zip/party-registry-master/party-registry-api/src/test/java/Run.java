import com.abacogroup.partyregistry.PartyRegistryApplication;

public class Run {
    public static void main(String[] args) throws Exception {
        PartyRegistryApplication.main(new String[] { "server", "party-registry-api/config.yml" });
    }
}
