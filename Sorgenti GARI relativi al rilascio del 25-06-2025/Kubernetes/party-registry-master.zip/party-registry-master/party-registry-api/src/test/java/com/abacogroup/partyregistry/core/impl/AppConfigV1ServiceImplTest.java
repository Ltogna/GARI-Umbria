package com.abacogroup.partyregistry.core.impl;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.junit.jupiter.api.Assertions.assertTrue;

import com.abacogroup.partyregistry.JdbiTest;
import com.abacogroup.partyregistry.api.v1.AppConfigResponseV1;
import com.abacogroup.partyregistry.core.AppConfigV1Service;
import com.abacogroup.partyregistry.resources.req.ReqContext;
import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

@ExtendWith(DropwizardExtensionsSupport.class)
class AppConfigV1ServiceImplTest extends JdbiTest {

	private static final String tenantId = "AppConfigV1ServiceImplTest_t";
	private static final String currentUser = "AppConfigV1ServiceImplTest_u";

	private static final ReqContext reqContext =
			new ReqContext(tenantId, currentUser, "en");

	private static final Map<String, Object> testScriptParams = Map.of(
			"test_tenant", tenantId,
			"user_id", currentUser
	);
	private final AppConfigV1Service appConfigV1Service = this.getService(AppConfigV1ServiceImpl.class);

	@Test
	void searchAll() {
		setUnusedBindingAllowed(true);
		getJdbi().useHandle(handle -> {
			handle.begin();

			List<String> initScripts = List.of("add_app_configs");
			execSqlFiles(this.getClass(), initScripts, testScriptParams);

			List<AppConfigResponseV1> list = this.appConfigV1Service.searchAll(reqContext);
			assertThat(list.size(), is(3));

			handle.rollback();
		});
	}

	@Test
	void searchByKey() {
		setUnusedBindingAllowed(true);
		getJdbi().useHandle(handle -> {
			handle.begin();

			List<String> initScripts = List.of("add_app_configs");
			execSqlFiles(this.getClass(), initScripts, testScriptParams);

			Optional<AppConfigResponseV1> res = this.appConfigV1Service.searchByKey(reqContext, "test1");
			assertTrue(res.isPresent());
			assertThat(res.get().getConfigurationKey(), is("test1"));
			assertThat(res.get().getConfiguration(), is(Map.of("show", true)));

			handle.rollback();
		});

	}
}
