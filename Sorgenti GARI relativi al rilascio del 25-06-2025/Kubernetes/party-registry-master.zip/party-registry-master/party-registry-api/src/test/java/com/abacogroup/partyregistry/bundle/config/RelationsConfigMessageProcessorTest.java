package com.abacogroup.partyregistry.bundle.config;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.hasItems;
import static org.hamcrest.Matchers.hasSize;
import static org.hamcrest.Matchers.is;

import com.abacogroup.bundles.initializer.impl.FileSupport;
import com.abacogroup.bundles.listener.configdata.ConfigDataMessage;
import com.abacogroup.partyregistry.JdbiTest;
import com.abacogroup.partyregistry.bundle.config.RelationsConfigMessageProcessor.RelationEntry;
import com.abacogroup.partyregistry.bundle.config.RelationsConfigMessageProcessor.RoleEntry;
import com.abacogroup.partyregistry.core.BundleConstants;
import com.abacogroup.partyregistry.core.RelationRoleService;
import com.abacogroup.partyregistry.core.RelationTypeService;
import com.abacogroup.partyregistry.core.impl.RelationRoleServiceImpl;
import com.abacogroup.partyregistry.core.impl.RelationTypeServiceImpl;
import com.abacogroup.partyregistry.resources.req.ReqContext;
import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;
import java.nio.file.Path;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

@Slf4j
@ExtendWith(DropwizardExtensionsSupport.class)
class RelationsConfigMessageProcessorTest extends JdbiTest {
	private final RelationTypeService typeService = getService(RelationTypeServiceImpl.class);
	private final RelationRoleService roleService = getService(RelationRoleServiceImpl.class);
	private final RelationsConfigMessageProcessor processor = getService(RelationsConfigMessageProcessor.class);

	@Test
	@SneakyThrows
	void testReadFileTOMap() {
		var path = Path.of(Objects.requireNonNull(
				this.getClass().getResource(Path.of("relations", "relations_sample2.json").toString())
		).toURI());
		List<RelationEntry> map = processor.readFileToMap(path);
		RelationEntry assettiSoc = map
				.stream()
				.filter(x -> x.getType().equals("ASSETTI_SOCIETARI"))
				.findFirst().orElse(null);

		assertThat(assettiSoc.getRoles().stream().map(RoleEntry::getCode).collect(Collectors.toList()), hasItems("CONTROLLANTE", "CONTROLLATA"));
		assertThat(map.size(), is(4));

		var entry = map.stream().filter(x -> x.getType().equals("NUCLEO_FAMILIARE")).findFirst().orElseThrow();
		assertThat(entry.getRoles(), hasSize(8));
		assertThat(entry.getI18n(), hasSize(2));
	}

	@Test
	@SneakyThrows
	void test_process_bundle_files() {
		ConfigDataMessage msg = new ConfigDataMessage();
		String tenantBundle = "RelationsConfigMessageProcessorTest_tenant";
		msg.setTenantId(tenantBundle);
		ReqContext reqContext = new ReqContext(tenantBundle, BundleConstants.SYSTEM_USER);

		var path = Path.of(this.getClass().getResource("relations").toURI());
		msg.setConfigFiles(FileSupport.listFilesRecursive(path));

		getJdbi().useHandle(handle -> {
			handle.begin();

			processor.onMessage(msg);

			var assetti = typeService.getByCode(reqContext, "ASSETTI_SOCIETARI").orElseThrow();
			assertThat(assetti.isMultiple(), is(false));

			var nucleo = typeService.getByCode(reqContext, "NUCLEO_FAMILIARE").orElseThrow();
			assertThat(nucleo.isMultiple(), is(true));

			var role = roleService.getByCode(reqContext, "MARITO_A_CARICO").orElseThrow();
			assertThat(role.getRelationType().getCode(), is("NUCLEO_FAMILIARE"));

			handle.rollback();
		});

	}


}

