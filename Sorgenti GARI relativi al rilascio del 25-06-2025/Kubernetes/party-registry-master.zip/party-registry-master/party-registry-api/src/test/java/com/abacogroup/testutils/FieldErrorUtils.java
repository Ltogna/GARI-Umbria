package com.abacogroup.testutils;

import jakarta.ws.rs.ClientErrorException;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class FieldErrorUtils {

	@SuppressWarnings("unchecked")
	public static List<String> extractErrorFieldNames(ClientErrorException ex) {
		Map<String, Object> responseMap = ex.getResponse().readEntity(Map.class);
		if (responseMap.containsKey("errors")) {
			//constraints...
			List<String> list = (List<String>) responseMap.get("errors");
			return list
					.stream()
					.map(msg -> List.of(msg.split(" ")))
					.map(tokens -> tokens.get(0))
					.collect(Collectors.toList());
		} else if (responseMap.containsKey("errorCode")) {
			return List.of((String) responseMap.get("errorCode"));
		}
		throw new UnsupportedOperationException("response inattesa");
	}
}
