package com.abacogroup.partyregistry.bundle.config;

import com.abacogroup.bundles.initializer.impl.FileSupport;
import com.abacogroup.bundles.listener.configdata.ConfigDataMessage;
import com.abacogroup.bundles.listener.tenant.TenantMessage;
import com.abacogroup.partyregistry.JdbiTest;
import com.abacogroup.partyregistry.bundle.tenant.DynamicDocTenantMessageProcessor;
import com.abacogroup.partyregistry.bundle.tenant.RelationsTenantMessageProcessor;
import com.abacogroup.partyregistry.bundle.tenant.TagTenantMessageProcessor;
import com.abacogroup.partyregistry.core.impl.PartyServiceImpl;
import com.abacogroup.partyregistry.resources.DevtoolsResource;
import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;
import java.nio.file.Path;
import java.util.List;
import lombok.extern.slf4j.Slf4j;
import org.jdbi.v3.core.Jdbi;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

@Slf4j
@ExtendWith(DropwizardExtensionsSupport.class)
@Disabled
class PartyConfigMessageProcessorTest extends JdbiTest {
	private static final String TENANT = "ttt";

	private final TagTenantMessageProcessor tagTenantMessageProcessor = getService(TagTenantMessageProcessor.class);

	private final PartyServiceImpl partyService = getService(PartyServiceImpl.class);

	private final DynamicDocTenantMessageProcessor dynamicDocTenantMessageProcessor = getService(DynamicDocTenantMessageProcessor.class);
	private final PartyConfigMessageProcessor processor = getService(PartyConfigMessageProcessor.class);
	private final RelationsTenantMessageProcessor relationsTenantMessageProcessor = getService(RelationsTenantMessageProcessor.class);

	private void clearBundles() {
		Jdbi jdbi = getJdbi();
		DevtoolsResource.flushTenant(jdbi, TENANT);
	}

	@Test
	void test_process_bundle_files() {
		try {
			clearBundles();

			TenantMessage tenantMessage = new TenantMessage();
			tenantMessage.setTenantId(TENANT);
			tagTenantMessageProcessor.onMessage(tenantMessage);
			relationsTenantMessageProcessor.onMessage(tenantMessage);
			dynamicDocTenantMessageProcessor.onMessage(tenantMessage);

			ConfigDataMessage configDataMessage = new ConfigDataMessage();
			configDataMessage.setTenantId(TENANT);
			String domainPathString = "src/test/resources/bundles/dev_master/party-registry/prt-0099/party";
			Path domainPath = Path.of(domainPathString);
			List<Path> paths = FileSupport.listFilesRecursive(domainPath);
			configDataMessage.setConfigFiles(paths);
			processor.onMessage(configDataMessage);

			//			String label = this.dao.searchLabel(tenantIdStar, "prt_relation_roles", "code", "RAPPRESENTANTE_LEGALE", "it");
			//			assertThat(label, CoreMatchers.is("rappresentante_legale"));
		} finally {
			this.clearBundles();
		}
	}
}

