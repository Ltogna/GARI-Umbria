package com.abacogroup.partyregistry.core.impl;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.greaterThan;
import static org.hamcrest.Matchers.hasSize;
import static org.hamcrest.Matchers.notNullValue;
import static org.hamcrest.Matchers.nullValue;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.BDDMockito.given;

import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.hamcrest.CoreMatchers;
import org.hamcrest.Matchers;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.Mockito;

import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.parti.testing.IntegrationTestSupport;
import com.abacogroup.partyregistry.JdbiTest;
import com.abacogroup.partyregistry.PrtTest;
import com.abacogroup.partyregistry.api.AddressRes;
import com.abacogroup.partyregistry.api.ExternalSourceRes;
import com.abacogroup.partyregistry.api.GenderEnum;
import com.abacogroup.partyregistry.api.PartyRes;
import com.abacogroup.partyregistry.api.PartySearchRes;
import com.abacogroup.partyregistry.api.PartyTypeEnum;
import com.abacogroup.partyregistry.api.Tag;
import com.abacogroup.partyregistry.core.AclService;
import com.abacogroup.partyregistry.core.TagService;
import com.abacogroup.partyregistry.core.exceptions.ErrCodes;
import com.abacogroup.partyregistry.core.exceptions.InvalidPartyException;
import com.abacogroup.partyregistry.db.dao.LegalStatusDAO;
import com.abacogroup.partyregistry.db.ntt.LegalStatusEntity;
import com.abacogroup.partyregistry.db.ntt.PartyEntity;
import com.abacogroup.partyregistry.resources.mappers.PartyMapper;
import com.abacogroup.partyregistry.resources.req.AddressReq;
import com.abacogroup.partyregistry.resources.req.ArchivedEnum;
import com.abacogroup.partyregistry.resources.req.PartyCheckReq;
import com.abacogroup.partyregistry.resources.req.PartyCreateReq;
import com.abacogroup.partyregistry.resources.req.PartyCreateReq.PartyCreateReqBuilder;
import com.abacogroup.partyregistry.resources.req.PartySearchReq;
import com.abacogroup.partyregistry.resources.req.PartyUpdateReq;
import com.abacogroup.partyregistry.resources.req.PartyUpdateReq.PartyUpdateReqBuilder;
import com.abacogroup.partyregistry.resources.req.ReqContext;

import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@ExtendWith(DropwizardExtensionsSupport.class)
class PartyServiceImplTest extends JdbiTest {

	private static final String NO_EXTERNAL_SOURCE_CODE = null;
	
	private static final String currentUser = "PartyServiceImplTest_u";
	private static final String tenantId = "PartyServiceImplTest_t";

	private static final Map<String, Object> testScriptParams = Map.of(
			"test_tenant", tenantId,
			"user_id", currentUser
	);

	private static final ReqContext reqContext =
			new ReqContext(tenantId, currentUser, "en");
	
	
	private final LegalStatusDAO legalStatusDAOMock = Mockito.mock(LegalStatusDAO.class);
	private final PartyServiceImpl service = getService(PartyServiceImpl.class);
	private final TagService tagService = getService(TagServiceImpl.class);

	@BeforeAll
	@AfterAll
	public static void beforeAll() {
		List<String> initScripts = List.of("rollback");
		execSqlFiles(PrtTest.class, initScripts, testScriptParams);
	}

	private static Stream<Arguments> test_search() {
		return Stream.of(
				Arguments.of("just_tenant", new PartySearchReq()
						, List.of(-222L, -666L, -444L, -111L, -333L))
				, Arguments.of("only_archived", new PartySearchReq()
								.setArchived(ArchivedEnum.only_archived),
						List.of(-555L))
				, Arguments.of("all_archived", new PartySearchReq()
								.setArchived(ArchivedEnum.all),
						List.of(-555L, -222L, -666L, -444L, -111L, -333L))
				, Arguments.of("first_name", new PartySearchReq()
								.setFirstName("ma"),
						List.of(-333L))
				, Arguments.of("last_name", new PartySearchReq()
								.setLastName("real"),
						List.of(-666L, -444L, -111L))
				, Arguments.of("first_last_name", new PartySearchReq()
								.setLastName("real")
								.setFirstName("spa"),
						List.of(-444L, -111L))
				, Arguments.of("tax_code_partial", new PartySearchReq()
								.setTaxCode("2"),
						List.of())
				, Arguments.of("tax_code_full", new PartySearchReq()
								.setTaxCode("222"),
						List.of(-444L, -111L))
				, Arguments.of("vat", new PartySearchReq()
								.setVatNumber("111"),
						List.of(-666L))

				, Arguments.of("tax_or_vat", new PartySearchReq()
								.setTaxOrVat("111"),
						List.of(-666L))
				, Arguments.of("tax_or_vat", new PartySearchReq()
								.setTaxOrVat("DMC"),
						List.of(-222L))

				, Arguments.of("tax_or_vat", new PartySearchReq()
								.setTaxOrVat("000"),
						List.of(-666L, -333L))

				// il -666   ha bug e lol
				// il -555  ha solo lol perchè bug è scaduto (ma è archived!)
				, Arguments.of("by_tag_1", new PartySearchReq()
								.setTag(List.of("LOL", "BUG")),
						List.of(-666L, -444L, -111L))
				, Arguments.of("by_tag_2", new PartySearchReq()
								.setArchived(ArchivedEnum.all)
								.setTag(List.of("LOL")),
						List.of(-555L, -666L, -444L, -111L))
				, Arguments.of("by_tag_3", new PartySearchReq()
								.setArchived(ArchivedEnum.all)
								.setTag(List.of("BUG")),
						List.of(-666L))

				, Arguments.of("withCuaa", new PartySearchReq()
								.setHasCode(true),
						List.of(-222L, -111L, -333L))
				, Arguments.of("code", new PartySearchReq()
								.setCode("THE_CODE1"),
						List.of(-333L))
		);
	}


	// ----- search ----- //
	@ParameterizedTest
	@MethodSource
	void test_search(String ignoredTitle, PartySearchReq request, List<Long> results) {

		setUnusedBindingAllowed(true);
		getJdbi().useHandle(handle -> {
			handle.begin();

			List<String> initScripts = List.of("insert_parties_and_tags");
			execSqlFiles(this.getClass(), initScripts, testScriptParams);

			LauMapper lauMapperMock = Mockito.mock(LauMapper.class);
			given(lauMapperMock.resolvePartySearchResponseAddress(Mockito.any(PartySearchRes.class), Mockito.any(ReqContext.class)))
					.willAnswer(invocationOnMock -> invocationOnMock.getArgument(0));
			IntegrationTestSupport.injectMock(service, lauMapperMock);
			List<PartySearchRes> list = this.service.search(reqContext, request, AclService.MANAGE_READ, null
					)
					.getRecords();
			List<Long> actual = list.stream()
					.map(PartySearchRes::getId)
					.collect(Collectors.toList());
			assertThat(actual, is(results));

			handle.rollback();
		});

	}

	@Test
	void test_search_mappingOk() {
		setUnusedBindingAllowed(true);
		getJdbi().useHandle(handle -> {
			handle.begin();

			List<String> initScripts = List.of("insert_parties_and_tags");
			execSqlFiles(this.getClass(), initScripts, testScriptParams);

			LauMapper lauMapperMock = Mockito.mock(LauMapper.class);
			given(lauMapperMock.resolvePartySearchResponseAddress(Mockito.any(PartySearchRes.class), Mockito.any(ReqContext.class)))
					.willAnswer(invocationOnMock -> invocationOnMock.getArgument(0));
			IntegrationTestSupport.injectMock(service, lauMapperMock);

			PartySearchReq request = new PartySearchReq().setCode("222");
			List<PartySearchRes> list = this.service.search(reqContext, request, AclService.MANAGE_READ, null).getRecords();

			assertThat(list, hasSize(1));
			assertThat(list.get(0).getId(), is(-111L));
			assertFalse(list.get(0).isArchived());
			assertThat(list.get(0).getAddressResidential(), is(AddressRes.builder()
					.setId(-11101L)
					.setMunicipality("ITA_20_292_009")
					.setLocality("Pirri")
					.setStreet("via Ruggero Bacone")
					.setHouseNumber("4")
					.setPostcode("09134")
					.setDetails("details test")
					.setNote("note test")
					.build()));

			handle.rollback();
		});

	}

	@Test
	void test_search_mapping2Ok() {
		setUnusedBindingAllowed(true);
		getJdbi().useHandle(handle -> {
			handle.begin();

			List<String> initScripts = List.of("insert_parties_and_tags");
			execSqlFiles(this.getClass(), initScripts, testScriptParams);

			LauMapper lauMapperMock = Mockito.mock(LauMapper.class);
			given(lauMapperMock.resolvePartySearchResponseAddress(Mockito.any(PartySearchRes.class), Mockito.any(ReqContext.class)))
					.willAnswer(invocationOnMock -> invocationOnMock.getArgument(0));
			IntegrationTestSupport.injectMock(service, lauMapperMock);

			PartySearchReq request = new PartySearchReq().setTaxCode("000");
			List<PartySearchRes> list = this.service.search(reqContext, request, AclService.MANAGE_READ, null).getRecords();

			assertThat(list, hasSize(1));
			assertThat(list.get(0).getId(), is(-666L));
			assertThat(list.get(0).getBirthDate(), is(AbsoluteDate.of("20010131")));
			assertThat(list.get(0).getBirthMunicipality(), is("Verona"));

			handle.rollback();
		});
	}

	@Test
	void test_search_mappingArchivedOk() {
		setUnusedBindingAllowed(true);
		getJdbi().useHandle(handle -> {
			handle.begin();

			List<String> initScripts = List.of("insert_parties_and_tags");
			execSqlFiles(this.getClass(), initScripts, testScriptParams);

			PartySearchReq request = new PartySearchReq().setArchived(ArchivedEnum.only_archived);
			List<PartySearchRes> list = this.service.search(reqContext, request, AclService.MANAGE_READ, null).getRecords();

			assertThat(list, hasSize(1));
			assertThat(list.get(0).getId(), is(-555L));
			assertTrue(list.get(0).isArchived());

			handle.rollback();
		});
	}

	// ----- archive ----- //
	@Test
	void test_archive() {
		setUnusedBindingAllowed(true);
		getJdbi().useHandle(handle -> {
			handle.begin();

			List<String> initScripts = List.of("insert_parties_and_tags");
			execSqlFiles(this.getClass(), initScripts, testScriptParams);

			ReqContext context = new ReqContext("delete_me", "delete_me");
			PartyCreateReq request = givenCreateRequest().build();
			Long id = Optional.of(
							this.service.insert(context, request, NO_EXTERNAL_SOURCE_CODE))
					.map(PartyRes::getId)
					.orElse(null);
			PartyRes party = service.getPartyById(context, id)
					.orElseThrow(() -> new RuntimeException("error"));

			service.archive(context, party.getId(), true);

			PartyEntity archivedParty = service.loadEntity("delete_me", party.getId())
					.orElseThrow(() -> new RuntimeException("error"));
			assertThat(archivedParty.getFlArchived(), is(1));
			assertThat(archivedParty.getPkid(), greaterThan(id));

			handle.rollback();
		});

	}

	// ----- loadEntity ----- //
	@Test
	void test_loadEntity() {
		setUnusedBindingAllowed(true);
		getJdbi().useHandle(handle -> {
			handle.begin();

			List<String> initScripts = List.of("insert_parties_and_tags");
			execSqlFiles(this.getClass(), initScripts, testScriptParams);

			Optional<PartyEntity> emptyParty = service.loadEntity("xx", -1L);
			assertThat(emptyParty.isEmpty(), is(true));

			Optional<PartyEntity> party = service.loadEntity(tenantId, -666L);
			assertThat(party.isEmpty(), is(false));

			handle.rollback();
		});
	}

	// ----- loadDupllicates ----- //
	@Test
	void test_loadDuplicates() {

		setUnusedBindingAllowed(true);
		getJdbi().useHandle(handle -> {
			handle.begin();

			List<String> initScripts = List.of("insert_parties_and_tags");
			execSqlFiles(this.getClass(), initScripts, testScriptParams);

			// case 1 ( where vatNumber = 000 )
			PartyCheckReq checkRequest = new PartyCheckReq().setTaxCode(null).setVatNumber("000").setId(null);
			List<PartyEntity> parties = service.loadDuplicates(tenantId, checkRequest);
			assertThat(parties.size(), is(1));
			assertThat(parties.get(0).getId(), is(-666L));
			assertThat(parties.get(0).getVatNumber(), is("111"));
			assertThat(parties.get(0).getTaxCode(), is("000"));

			// case 2  ( where vatNumber = 0001233 )
			PartyCheckReq checkRequest2 = new PartyCheckReq()
					.setTaxCode(null).setVatNumber("0001233")
					.setId(null);
			List<PartyEntity> parties2 = service.loadDuplicates(tenantId, checkRequest2);
			assertThat(parties2.size(), is(1));

			// case 3   ( where TaxCode = 0001233 )
			PartyCheckReq checkRequest3 = new PartyCheckReq()
					.setTaxCode("0001233").setVatNumber(null).setId(null);
			List<PartyEntity> parties3 = service.loadDuplicates(tenantId, checkRequest3);
			assertThat(parties3.size(), is(1));

			// case 4 ( where vatNumber = 000 and taxCode = 111)
			PartyCheckReq checkRequest4 = new PartyCheckReq()
					.setTaxCode("111").setVatNumber("000").setId(null);
			List<PartyEntity> parties4 = service.loadDuplicates(tenantId, checkRequest4);
			assertThat(parties4.size(), is(1));
			assertThat(parties4.get(0).getId(), is(-666L));

			// case 6 ( where taxCode = 000 AND id = -999)
			PartyCheckReq checkRequest6 = new PartyCheckReq()
					.setVatNumber(null).setTaxCode("000").setId(-666L);
			List<PartyEntity> parties6 = service.loadDuplicates(tenantId, checkRequest6);
			assertThat(parties6.size(), is(0));

			handle.rollback();
		});

	}

	@Test
	void test_Duplicates() {
		setUnusedBindingAllowed(true);
		getJdbi().useHandle(handle -> {
			handle.begin();

			List<String> initScripts = List.of("insert_parties_and_tags");
			execSqlFiles(this.getClass(), initScripts, testScriptParams);

			boolean duplicated = false;
			PartyCheckReq checkRequest4 = new PartyCheckReq()
					.setTaxCode("111")
					.setVatNumber("000")
					.setId(null);
			int nbrDuplicates = service.loadDuplicates(tenantId, checkRequest4).size();
			if (nbrDuplicates > 0) {
				duplicated = true;
			}
			assertTrue(duplicated);

			handle.rollback();
		});

	}

	@Test
	void test_Duplicates_detail() {
		setUnusedBindingAllowed(true);
		getJdbi().useHandle(handle -> {
			handle.begin();
			String taxCode = "000";
			String vatNumber = "111";
			List<String> initScripts = List.of("insert_parties_and_tags");
			execSqlFiles(this.getClass(), initScripts, testScriptParams);

			PartyCheckReq checkRequest = new PartyCheckReq()
					.setTaxCode(taxCode)
					.setVatNumber(vatNumber);

			Map<String, Boolean> resultMap = service.loadDuplicatesDetail(tenantId, checkRequest);

			assertTrue(resultMap.get("partitaIva"));
			assertTrue(resultMap.get("codiceFiscale"));

			checkRequest.setId(-666L);
			resultMap = service.loadDuplicatesDetail(tenantId, checkRequest);
			assertFalse(resultMap.get("partitaIva"));
			assertFalse(resultMap.get("codiceFiscale"));

			PartyCheckReq checkRequest2 = new PartyCheckReq()
					.setTaxCode(taxCode)
					.setVatNumber("404");
			resultMap = service.loadDuplicatesDetail(tenantId, checkRequest2);

			assertFalse(resultMap.get("partitaIva"));
			assertTrue(resultMap.get("codiceFiscale"));

			checkRequest2.setTaxCode("XX");
			resultMap = service.loadDuplicatesDetail(tenantId, checkRequest2);

			assertFalse(resultMap.get("partitaIva"));
			assertFalse(resultMap.get("codiceFiscale"));

			handle.rollback();
		});

	}

	@Test
	void test_Duplicates_detail_given_just_taxCode() {
		setUnusedBindingAllowed(true);
		getJdbi().useHandle(handle -> {
			handle.begin();
			String taxCode = "000";
			List<String> initScripts = List.of("insert_parties_and_tags");
			execSqlFiles(this.getClass(), initScripts, testScriptParams);

			PartyCheckReq checkRequest4 = new PartyCheckReq()
					.setTaxCode(taxCode)
					.setId(null);

			Map<String, Boolean> resultMap = service.loadDuplicatesDetail(tenantId, checkRequest4);

			assertTrue(resultMap.get("codiceFiscale"));
			org.assertj.core.api.Assertions.assertThat(resultMap).doesNotContainKey("partitaIva");

			handle.rollback();
		});
	}

	@Test
	void test_Duplicates_detail_when_entities_have_some_null_values() {
		setUnusedBindingAllowed(true);
		getJdbi().useHandle(handle -> {
			handle.begin();
			String taxCode = "222";
			String vatNumber = "111";
			List<String> initScripts = List.of("insert_parties_for_check_duplicates");
			execSqlFiles(this.getClass(), initScripts, testScriptParams);

			PartyCheckReq checkRequest4 = new PartyCheckReq()
					.setTaxCode(taxCode)
					.setVatNumber(vatNumber)
					.setId(null);

			Map<String, Boolean> resultMap = service.loadDuplicatesDetail(tenantId, checkRequest4);

			assertTrue(resultMap.get("partitaIva"));
			assertTrue(resultMap.get("codiceFiscale"));

			handle.rollback();
		});

	}

	// ----- getPartyById -----
	@Test
	void test_getPartyById_mappingOk() {
		setUnusedBindingAllowed(true);
		getJdbi().useHandle(handle -> {
			handle.begin();

			List<String> initScripts = List.of("insert_parties_and_tags");
			execSqlFiles(this.getClass(), initScripts, testScriptParams);

			Optional<PartyRes> party = this.service.getPartyById(reqContext, -111L);
			assertTrue(party.isPresent());
			assertThat(party.get().getId(), is(-111L));
			assertFalse(party.get().isArchived());
			assertThat(party.get().getAddressResidential(), is(AddressRes.builder()
					.setId(-11101L)
					.setMunicipality("ITA_20_292_009")
					.setLocality("Pirri")
					.setStreet("via Ruggero Bacone")
					.setHouseNumber("4")
					.setPostcode("09134")
					.setDetails("details test")
					.setNote("note test")
					.build()));
			assertThat(party.get().getExternalSource(), is(ExternalSourceRes.builder()
					.setCode("SOURCE3")
					.setDescription("Source3 En")
					.setAllowManual(true)
					.build()));

			handle.rollback();
		});

	}

	@Test
	void test_getPartyById_mappingArchivedOk() {
		setUnusedBindingAllowed(true);
		getJdbi().useHandle(handle -> {
			handle.begin();

			List<String> initScripts = List.of("insert_parties_and_tags");
			execSqlFiles(this.getClass(), initScripts, testScriptParams);

			Optional<PartyRes> party = this.service.getPartyById(reqContext, -555L);
			assertTrue(party.isPresent());
			assertThat(party.get().getId(), is(-555L));
			assertTrue(party.get().isArchived());

			handle.rollback();
		});

	}

	@Test
	void test_getPartyById_with_tags() {

		setUnusedBindingAllowed(true);
		getJdbi().useHandle(handle -> {
			handle.begin();

			List<String> initScripts = List.of("insert_parties_and_tags");
			execSqlFiles(this.getClass(), initScripts, testScriptParams);

			Optional<PartyRes> party = this.service.getPartyById(reqContext, -666L);
			assertTrue(party.isPresent());
			assertThat(party.get().getId(), is(-666L));
			assertThat(party.get().getTags().size(), is(2));

			Optional<PartyRes> party2 = this.service.getPartyById(reqContext, -555L);
			assertTrue(party2.isPresent());
			assertThat(party2.get().getId(), is(-555L));
			assertThat(party2.get().getTags().size(), is(1));

			Optional<PartyRes> party3 = this.service.getPartyById(reqContext, -444L);
			assertTrue(party3.isPresent());
			assertThat(party3.get().getId(), is(-444L));
			assertThat(party3.get().getTags().size(), is(1));

			handle.rollback();
		});

	}

	// ----- insert ----- //
	@Test
	void test_insert_ok() {
		Mockito.reset(legalStatusDAOMock);
		setUnusedBindingAllowed(true);
		getJdbi().useHandle(handle -> {
			handle.begin();

			List<String> initScripts = List.of("insert_parties_and_tags");
			execSqlFiles(this.getClass(), initScripts, testScriptParams);

			PartyCreateReq request = givenCreateRequest().build();

			Long id = Optional.of(
							this.service.insert(reqContext, request, NO_EXTERNAL_SOURCE_CODE))
					.map(PartyRes::getId)
					.orElse(null);

			PartyEntity saved = service.loadEntity(tenantId, id).orElseThrow(() -> new RuntimeException("error"));
			assertThat("in inserimento, sono identici", saved.getPkid(), is(saved.getId()));
			assertThat(saved.getGender(), is(GenderEnum.M));
			assertThat(saved.getFkAddressBilling(), notNullValue());
			assertThat(saved.getFkAddressHome(), notNullValue());
			assertThat(saved.getFkAddressResidential(), notNullValue());

			PartyRes party = PartyMapper.INSTANCE.entityToDto(saved);
			assertThat(party.getGender(), is(GenderEnum.M));
			assertThat(party.getPartyType(), is(PartyTypeEnum.N));

			assertThat(party.getFirstName(), is("JSON"));
			assertThat(party.getLastName(), is("ACME"));

			handle.rollback();
		});

	}

	@Test
	void test_insert_validate_legal_status() {

		try {
			injectMock(service, legalStatusDAOMock);

			given(legalStatusDAOMock.countAll(anyString())).willReturn(1L);

			given(legalStatusDAOMock.findOne(anyString(), eq("AAA")))
					.willReturn(Optional.of(LegalStatusEntity.builder()
							.setCode("AAA")
							.build()
					));
			given(legalStatusDAOMock.findOne(anyString(), eq("XXX")))
					.willReturn(Optional.empty());

			setUnusedBindingAllowed(true);
			getJdbi().useHandle(handle -> {
				handle.begin();

				List<String> initScripts = List.of("insert_parties_and_tags");
				execSqlFiles(this.getClass(), initScripts, testScriptParams);

				PartyCreateReq request = givenCreateRequest().build();

				var invalidEx1 = assertThrows(
						InvalidPartyException.class, () -> this.service.insert(reqContext, request, NO_EXTERNAL_SOURCE_CODE)
				);
				assertThat(invalidEx1.getErrorBody().getMessage(), is("legalStatus is mandatory"));

				request.setLegalStatus("XXX");
				var invalidEx2 = assertThrows(
						InvalidPartyException.class, () -> this.service.insert(reqContext, request, NO_EXTERNAL_SOURCE_CODE)
				);
				assertThat(invalidEx2.getErrorBody().getMessage(), is("legalStatus 'XXX' not found"));


				request.setLegalStatus("AAA");
				Long id = Optional.of(
								this.service.insert(reqContext, request, NO_EXTERNAL_SOURCE_CODE))
						.map(PartyRes::getId)
						.orElse(null);

				PartyEntity saved = service.loadEntity(tenantId, id).orElseThrow(() -> new RuntimeException("error"));
				assertThat(saved.getLegalStatus(), is("AAA"));

				handle.rollback();
			});

		} finally {
			Mockito.reset(legalStatusDAOMock);
		}
	}

	@Test
	void test_insert_party_with_tags_ok() {

		setUnusedBindingAllowed(true);
		getJdbi().useHandle(handle -> {
			handle.begin();

			List<String> initScripts = List.of("insert_parties_and_tags");
			execSqlFiles(this.getClass(), initScripts, testScriptParams);

			// list of tags
			Optional<Tag> tag1 = tagService.getTagByCode(reqContext, "AA");
			Optional<Tag> tag2 = tagService.getTagByCode(reqContext, "BB");
			assertTrue(tag1.isPresent());
			assertTrue(tag2.isPresent());

			PartyCreateReq request = givenCreateRequest().build();

			// set list of tags for this party ( 2 tags )
			request.setTags(List.of(tag1.get().getCode(), tag2.get().getCode()));
			request.setAddressResidential(new AddressReq());
			request.setAddressHome(new AddressReq());
			request.setAddressBilling(new AddressReq());

			//insert party
			PartyRes party = Optional.of(this.service.insert(reqContext, request, NO_EXTERNAL_SOURCE_CODE))
					.orElse(null);

			// assert that tags are inserted too
			assertThat(party.getTags().size(), is(2));
			List<String> codes = party.getTags().stream().map(Tag::getCode).collect(Collectors.toList());
			assertTrue(codes.contains("AA"));
			assertTrue(codes.contains("BB"));

			handle.rollback();
		});

	}

	@Test
	void test_givenArchivedFlagTrue_insert_ok() {
		setUnusedBindingAllowed(true);
		getJdbi().useHandle(handle -> {
			handle.begin();

			List<String> initScripts = List.of("insert_parties_and_tags");
			execSqlFiles(this.getClass(), initScripts, testScriptParams);

			PartyCreateReq request = givenCreateRequest().setArchived(true).build();

			Long id = Optional.of(
							this.service.insert(reqContext, request, NO_EXTERNAL_SOURCE_CODE))
					.map(PartyRes::getId)
					.orElse(null);

			PartyEntity saved = service.loadEntity(tenantId, id).orElseThrow(() -> new RuntimeException("error"));
			assertThat("in inserimento, sono identici", saved.getPkid(), is(saved.getId()));
			assertThat(saved.getFlArchived(), is(1));

			handle.rollback();
		});

	}

	// ----- update ----- //
	@Test
	void test_update_ok() {
		setUnusedBindingAllowed(true);
		getJdbi().useHandle(handle -> {
			handle.begin();

			List<String> initScripts = List.of("insert_parties_and_tags");
			execSqlFiles(this.getClass(), initScripts, testScriptParams);

			PartyCreateReq createRequest = givenCreateRequest().build();
			PartyRes actual = this.service.insert(reqContext, createRequest, NO_EXTERNAL_SOURCE_CODE);
			Long id = actual.getId();
			PartyUpdateReq request = givenUpdateRequest().build();

			PartyRes response = service.update(reqContext, id, request);

			assertThat(response, notNullValue());
			PartyEntity saved = service.loadEntity(tenantId, id).orElseThrow(() -> new RuntimeException("error"));
			assertThat(saved.getPkid(), greaterThan(saved.getId()));
			assertThat(saved.getGender(), is(GenderEnum.F));
			assertThat(saved.getFkAddressBilling(), notNullValue());
			assertThat(saved.getFkAddressBilling(), CoreMatchers.not(actual.getAddressBilling().getId()));
			assertThat(saved.getFkAddressHome(), notNullValue());
			assertThat(saved.getFkAddressHome(), CoreMatchers.not(actual.getAddressHome().getId()));
			assertThat(saved.getFkAddressResidential(), notNullValue());
			assertThat(saved.getFkAddressResidential(), CoreMatchers.not(actual.getAddressResidential().getId()));

			PartyRes party = PartyMapper.INSTANCE.entityToDto(saved);
			assertThat(party.getGender(), is(GenderEnum.F));
			assertThat(party.getPartyType(), is(PartyTypeEnum.L));

			assertThat(party.getFirstName(), is("JSON UPD"));
			assertThat(party.getLastName(), is("ACME UPD"));

			handle.rollback();
		});

	}

	@Test
	@SneakyThrows
	void test_update_party_and_partyTags() {
		setUnusedBindingAllowed(true);
		getJdbi().useHandle(handle -> {
			handle.begin();

			List<String> initScripts = List.of("insert_parties_and_tags");
			execSqlFiles(this.getClass(), initScripts, testScriptParams);

			// insert party with 2 tags
			Optional<Tag> tag1 = tagService.getTagByCode(reqContext, "AA");
			Optional<Tag> tag2 = tagService.getTagByCode(reqContext, "BB");
			assertTrue(tag1.isPresent());
			assertTrue(tag2.isPresent());

			PartyUpdateReq requestUpdate = givenUpdateRequest().build();
			requestUpdate.setTags(List.of("AA", "BB"));

			PartyCreateReq requestCreate = givenCreateRequest().build();
			List<String> listTags = List.of(tag1.get().getCode(), tag2.get().getCode());
			requestCreate.setTags(listTags);
			PartyRes party = Optional.of(this.service.insert(reqContext, requestCreate, NO_EXTERNAL_SOURCE_CODE))
					.orElse(null);

			assertThat(party.getTags().size(), is(2));
			//				List<String> codes = party.getTags().stream().map(Tag::getCode).collect(Collectors.toList());
			//				assertTrue(codes.contains("AA"));
			//				assertTrue(codes.contains("BB"));

			//case 1 : update with same list ( list of the same 2 tags again)
			//				PartyUpdateRequest requestUpdate = givenUpdateRequest().build();
			//				requestUpdate.setTags(listTags);

			long party666 = -666L;
			PartyRes updatedParty666 = service.update(reqContext, party666, givenUpdateRequest()
					.setTags(List.of("BUG", "LOL"))
					.build());

			var codes = service.getPartyById(reqContext, party666)
					.map(PartyRes::getTags)
					.stream().flatMap(Collection::stream)
					.map(Tag::getCode)
					.collect(Collectors.toList());

			assertThat("same tags", updatedParty666.getTags().size(), is(2));
			codes = updatedParty666.getTags().stream().map(Tag::getCode).collect(Collectors.toList());
			assertTrue(codes.contains("BUG"));
			assertTrue(codes.contains("LOL"));

			//case 2 : update with just AA tag --> delete BB tag and keep AA tag

			PartyUpdateReq requestUpdate2 = givenUpdateRequest()
					.setTags(List.of("BUG"))
					.build();
			//requestUpdate2.setTags(List.of(tag1.get().getCode()));
			PartyRes updatedParty555 = service.update(reqContext, -555L, requestUpdate2);
			assertThat("delete 1 tag", updatedParty555.getTags().size(), is(1));
			assertThat(updatedParty555.getTags().size(), is(1));
			codes = updatedParty555.getTags().stream().map(Tag::getCode).collect(Collectors.toList());
			assertTrue(codes.contains("BUG"));

			//case 3 : update with null list of tags --> delete all the existing tags
			PartyUpdateReq requestUpdate3 = givenUpdateRequest().build();
			requestUpdate.setTags(null);
			PartyRes updatedParty444 = service.update(reqContext, -444L, requestUpdate3);
			assertThat("no tags", updatedParty444.getTags().size(), is(0));

			handle.rollback();
		});

	}

	@Test
	void test_givenArchivedFlagTrue_update_ok() {
		setUnusedBindingAllowed(true);
		getJdbi().useHandle(handle -> {
			handle.begin();

			List<String> initScripts = List.of("insert_parties_and_tags");
			execSqlFiles(this.getClass(), initScripts, testScriptParams);

			PartyCreateReq createRequest = givenCreateRequest().build();
			PartyRes actual = this.service.insert(reqContext, createRequest, NO_EXTERNAL_SOURCE_CODE);
			Long id = actual.getId();
			PartyUpdateReq request = givenUpdateRequest().setArchived(true).build();

			PartyRes response = service.update(reqContext, id, request);

			assertThat(response, notNullValue());
			PartyEntity saved = service.loadEntity(tenantId, id).orElseThrow(() -> new RuntimeException("error"));
			assertThat(saved.getPkid(), greaterThan(saved.getId()));
			assertThat(saved.getFlArchived(), is(1));

			handle.rollback();
		});

	}

	@Test
	void test_givenSameAddresses_update_ok() {
		getJdbi().useTransaction(handle -> {

			PartyCreateReq createRequest = givenCreateRequest().build();
			PartyRes actual = this.service.insert(reqContext, createRequest, NO_EXTERNAL_SOURCE_CODE);
			Long id = actual.getId();

			PartyUpdateReq request = givenUpdateRequest()
					.setAddressBilling(createRequest.getAddressBilling())
					.setAddressResidential(createRequest.getAddressResidential())
					.setAddressHome(null)
					.build();

			PartyRes response = service.update(reqContext, id, request);

			assertThat(response, notNullValue());
			PartyEntity saved = service.loadEntity(tenantId, id).orElseThrow();
			assertThat(saved.getPkid(), greaterThan(saved.getId()));
			assertThat(saved.getGender(), is(GenderEnum.F));
			assertThat(saved.getFkAddressBilling(), notNullValue());
			assertThat("fails if address.equals() fails", saved.getFkAddressBilling(), is(actual.getAddressBilling().getId()));
			assertThat(saved.getFkAddressHome(), nullValue());
			assertThat(saved.getFkAddressResidential(), notNullValue());
			assertThat(saved.getFkAddressResidential(), is(actual.getAddressResidential().getId()));

			PartyRes party = PartyMapper.INSTANCE.entityToDto(saved);
			assertThat(party.getGender(), is(GenderEnum.F));
			assertThat(party.getPartyType(), is(PartyTypeEnum.L));

			assertThat(party.getFirstName(), is("JSON UPD"));
			assertThat(party.getLastName(), is("ACME UPD"));

			handle.rollback();
		});
	}

	@Test
	void test_update_external_ok() {
		setUnusedBindingAllowed(true);
		getJdbi().useHandle(handle -> {
			handle.begin();

			List<String> initScripts = List.of("insert_parties_and_tags");
			execSqlFiles(this.getClass(), initScripts, testScriptParams);

			Long id = -111L;
			PartyUpdateReq request = PartyUpdateReq.builder()
					.setPartyType(PartyTypeEnum.N)
					.setGender(null)
					.setLastName("REALT_TECHNOLOGY")
					.setFirstName("SPA")
					.setTaxCode("222")
					.setVatNumber("333")
					.setCode("222")
					.setLegalStatus(null)
					.setBirthDate(AbsoluteDate.of("20010131"))
					.setDeathDate(AbsoluteDate.of("99991231"))
					.setBirthMunicipality("Cagliari")
					.setNationality(null)
					.setAddressResidential(AddressReq.builder()
							.setMunicipality("ITA_20_292_009")
							.setLocality("Pirri")
							.setStreet("via Ruggero Bacone")
							.setHouseNumber("4")
							.setPostcode("09134")
							.setDetails("details test")
							.setNote("note test")
							.build())
					.setAddressHome(AddressReq.builder()
							.setMunicipality("ITA_20_292_009")
							.setLocality("Pirri")
							.setStreet("via Italia")
							.setHouseNumber("99")
							.setPostcode("09134")
							.setDetails("home")
							.setNote("note test")
							.build())
					.build();

			PartyRes response = service.update(reqContext, id, request);

			assertThat(response, notNullValue());
			PartyEntity saved = service.loadEntityWithAddresses(tenantId, id).orElseThrow(() -> new RuntimeException("error"));

			PartyUpdateReq updated = PartyMapper.INSTANCE.entityToUpdateReq(saved, null);
			org.assertj.core.api.Assertions.assertThat(updated)
							.isEqualTo(request);

			handle.rollback();
		});

	}

	@Test
	void test_update_external_Ko() {
		setUnusedBindingAllowed(true);
		getJdbi().useHandle(handle -> {
			handle.begin();

			List<String> initScripts = List.of("insert_parties_and_tags");
			execSqlFiles(this.getClass(), initScripts, testScriptParams);

			Long id = -111L;
			PartyUpdateReq request = PartyUpdateReq.builder()
					.setPartyType(PartyTypeEnum.N)
					.setGender(null)
					.setLastName("REALT_TECHNOLOGY")
					.setFirstName("*** CHANGED ***")
					.setTaxCode("222")
					.setVatNumber("333")
					.setCode("222")
					.setLegalStatus(null)
					.setBirthDate(AbsoluteDate.of("20010131"))
					.setDeathDate(AbsoluteDate.of("99991231"))
					.setBirthMunicipality("Cagliari")
					.setNationality(null)
					.setAddressResidential(AddressReq.builder()
							.setMunicipality("ITA_20_292_009")
							.setLocality("Pirri")
							.setStreet("via Ruggero Bacone")
							.setHouseNumber("4")
							.setPostcode("09134")
							.setDetails("details test")
							.setNote("note test")
							.build())
					.setAddressHome(AddressReq.builder()
							.setMunicipality("ITA_20_292_009")
							.setLocality("Pirri")
							.setStreet("via Italia")
							.setHouseNumber("99")
							.setPostcode("09134")
							.setDetails("home")
							.setNote("note test")
							.build())
					.build();

			InvalidPartyException invalidPartyException = assertThrows(InvalidPartyException.class, () -> service.update(reqContext, id, request));

			org.assertj.core.api.Assertions.assertThat(invalidPartyException.getCode())
							.isEqualTo(ErrCodes.INVALID_PARTY_READ_ONLY);

			handle.rollback();
		});

	}

	@Test
	void test_insert_when_deathDate_is_invalid() {
		setUnusedBindingAllowed(true);
		getJdbi().useHandle(handle -> {
			handle.begin();

			List<String> initScripts = List.of("insert_parties_and_tags");
			execSqlFiles(this.getClass(), initScripts, testScriptParams);

			PartyCreateReq request = givenCreateRequest().setDeathDate(AbsoluteDate.of("19480917")).build();
			InvalidPartyException exception = Assertions.assertThrows(InvalidPartyException.class, () -> {
				this.service.insert(reqContext, request, NO_EXTERNAL_SOURCE_CODE);
			});

			assertThat("BirthD: 1949-09-17 < deathD: 1948-09-17 ", exception.getCode(), Matchers.is(ErrCodes.INVALID_PAYLOAD));

			PartyCreateReq request2 = givenCreateRequest().setDeathDate(AbsoluteDate.of("19490917")).build();
			exception = Assertions.assertThrows(InvalidPartyException.class, () -> {
				this.service.insert(reqContext, request2, NO_EXTERNAL_SOURCE_CODE);
			});

			assertThat("BirthD and deathD are equals", exception.getCode(), Matchers.is(ErrCodes.INVALID_PAYLOAD));

			PartyCreateReq request3 = givenCreateRequest().setDeathDate(null).build();
			Long id = Optional.of(
							this.service.insert(reqContext, request3, NO_EXTERNAL_SOURCE_CODE))
					.map(PartyRes::getId)
					.orElse(null);

			PartyEntity saved = service.loadEntity(tenantId, id).orElseThrow(() -> new RuntimeException("error"));
			assertThat("deathDate = null", saved.getDeathDate(), nullValue());

			handle.rollback();
		});
	}

	// ##################################################################################################################### //

	private PartyCreateReqBuilder<?, ?> givenCreateRequest() {
		return PartyCreateReq.builder()
				.setPartyType(PartyTypeEnum.N)
				.setGender(GenderEnum.M)
				.setLastName("acme")
				.setFirstName("json")
				.setTaxCode("111")
				.setVatNumber("222")
				.setBirthDate(AbsoluteDate.of("19490917"))
				.setBirthMunicipality("ITA_00_000_000")
				.setNationality("ITA")
				.setAddressResidential(AddressReq.builder()
						.setMunicipality("ITA_01_001_001")
						.setLocality("loc 1")
						.setStreet("via uno")
						.setHouseNumber("1")
						.setPostcode("10101")
						.setDetails("det 1")
						.setNote("test note 1")
						.build())
				.setAddressHome(AddressReq.builder()
						.setMunicipality("ITA_02_002_002")
						.setLocality("loc 2")
						.setStreet("via due")
						.setHouseNumber("2")
						.setPostcode("20202")
						.setDetails("det 2")
						.setNote("test note 2")
						.build())
				.setAddressBilling(AddressReq.builder()
						.setMunicipality("ITA_03_003_003")
						.setLocality("loc 3")
						.setStreet("via tre")
						.setHouseNumber("3")
						.setPostcode("30303")
						.setDetails("det 3")
						.setNote("test note 3")
						.build())
				.setArchived(false);
	}

	private PartyUpdateReqBuilder<?, ?> givenUpdateRequest() {
		return PartyUpdateReq.builder()
				.setPartyType(PartyTypeEnum.L)
				.setGender(GenderEnum.F)
				.setLastName("acme upd")
				.setFirstName("json upd")
				.setTaxCode("333")
				.setVatNumber("444")
				.setBirthDate(AbsoluteDate.of("20000101"))
				.setBirthMunicipality("ITA_11_111_111")
				.setNationality("ITA")
				.setAddressResidential(AddressReq.builder()
						.setMunicipality("ITA_11_001_001")
						.setLocality("loc 11")
						.setStreet("via uno unp")
						.setHouseNumber("11")
						.setPostcode("01010")
						.setDetails("det 11")
						.setNote("test note 11")
						.build())
				.setAddressHome(AddressReq.builder()
						.setMunicipality("ITA_12_002_002")
						.setLocality("loc 12")
						.setStreet("via due due")
						.setHouseNumber("12")
						.setPostcode("02020")
						.setDetails("det 12")
						.setNote("test note 12")
						.build())
				.setAddressBilling(AddressReq.builder()
						.setMunicipality("ITA_13_003_003")
						.setLocality("loc 13")
						.setStreet("via tre tre")
						.setHouseNumber("13")
						.setPostcode("03030")
						.setDetails("det 13")
						.setNote("test note 13")
						.build())
				.setArchived(false)
				.setTags(null);
	}

}
