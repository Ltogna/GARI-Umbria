package com.abacogroup.partyregistry.db.dao;

import com.abacogroup.partyregistry.JdbiTest;
import com.abacogroup.partyregistry.api.ExternalSourceRes;
import com.abacogroup.partyregistry.core.impl.AuditHelper;
import com.abacogroup.partyregistry.db.ntt.ExternalSourceEntity;
import com.abacogroup.partyregistry.resources.req.ReqContext;
import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;
import java.util.List;
import java.util.Map;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

@ExtendWith(DropwizardExtensionsSupport.class)
class ExternalSourceDAOTest extends JdbiTest {

	private static final String TENANT_ID = String.format("%s_t", ExternalSourceDAOTest.class.getSimpleName());
	private static final String USER_ID = String.format("%s_u", ExternalSourceDAOTest.class.getSimpleName());
	private static final Map<String, Object> testScriptParams = Map.of(
			"test_tenant", TENANT_ID,
			"user_id", USER_ID
	);
	private static final ReqContext reqContext =
			new ReqContext(TENANT_ID, USER_ID, "en");
	private final ExternalSourceDAO dao = getDAO(ExternalSourceDAO.class);

	@Test
	void test_insert_ok() {
		getJdbi().useHandle(handle -> {
			handle.begin();

			List<String> initScripts = List.of("add_external_sources");
			execSqlFiles(ExternalSourceDAOTest.class, initScripts, testScriptParams);
			String code = "NEWSOURCE";
			ExternalSourceEntity entity =
					ExternalSourceEntity.builder()
							.setCode(code)
							.setUrl("http://" + code)
							.setFlAllowManual(1)
							.setTenantId(TENANT_ID)
							.build();
			AuditHelper.setAuditForInsert(entity, USER_ID, dao);

			dao.insert(entity);

			Assertions.assertThat(dao.findByCode(TENANT_ID, code)).isPresent().get()
					.usingRecursiveComparison()
					.ignoringFields("pkid")
					.isEqualTo(entity);

			handle.rollback();
		});
	}

	// ----- insertNewTenant -----
	@Test
	void test_insertNewTenant_ok() {
		String newTenantId = TENANT_ID + "_new";
		getJdbi().useHandle(handle -> {
			handle.begin();
			String allTenants = "all_tenants";
			List<String> initScripts = List.of("add_external_sources");
			execSqlFiles(ExternalSourceDAOTest.class, initScripts, testScriptParams);

			ExternalSourceEntity entity = ExternalSourceEntity.builder().build();
			AuditHelper.setAuditForInsert(entity, USER_ID, dao);

			dao.insertNewTenant(allTenants, newTenantId, entity);

			ExternalSourceEntity s1 = dao.findByCode(allTenants, "SOURCE1").get();
			ExternalSourceEntity s2 = dao.findByCode(allTenants, "SOURCE2").get();
			Assertions.assertThat(dao.findAll(newTenantId)).hasSize(2)
					.usingRecursiveFieldByFieldElementComparatorIgnoringFields("pkid")
					.containsExactlyInAnyOrder(
							ExternalSourceEntity.builder().setCode(s1.getCode()).setUrl(s1.getUrl())
									.setTenantId(newTenantId).setFlAllowManual(s1.getFlAllowManual()).setUserIdInsert(entity.getUserIdInsert())
									.setDtInsert(entity.getDtInsert()).setDtDelete(entity.getDtDelete()).build(),
							ExternalSourceEntity.builder().setCode(s2.getCode()).setUrl(s2.getUrl())
									.setTenantId(newTenantId).setFlAllowManual(s2.getFlAllowManual()).setUserIdInsert(entity.getUserIdInsert())
									.setDtInsert(entity.getDtInsert()).setDtDelete(entity.getDtDelete()).build()
					);

			handle.rollback();
		});
	}

	@Test
	void test_findAll_ok() {
		getJdbi().useHandle(handle -> {
			handle.begin();
			List<String> initScripts = List.of("add_external_sources");
			execSqlFiles(ExternalSourceDAOTest.class, initScripts, testScriptParams);

			Assertions.assertThat(dao.findAll(TENANT_ID))
					.hasSize(2)
					.extracting(externalSourceEntity -> externalSourceEntity.getCode())
					.contains("SOURCE3", "SOURCE4");
			handle.rollback();
		});
	}

	@Test
	void test_getAllAsList_ok() {
		getJdbi().useHandle(handle -> {
			handle.begin();
			List<String> initScripts = List.of("add_external_sources", "add_external_sources_i18n");
			execSqlFiles(ExternalSourceDAOTest.class, initScripts, testScriptParams);

			Assertions.assertThat(dao.getAllAsList(reqContext))
					.hasSize(2)
					.contains(ExternalSourceRes.builder().setCode("SOURCE3")
									.setDescription("source3_en")
									.setAllowManual(true).build(),
							ExternalSourceRes.builder()
									.setCode("SOURCE4")
									.setDescription("source4_en")
									.setAllowManual(false).build());

			handle.rollback();
		});
	}
}
