package com.abacogroup.partyregistry.core;

import com.abacogroup.dropwizard.auth.sso2.User;
import jakarta.ws.rs.core.SecurityContext;
import java.security.Principal;

public class DummySecurityContext implements SecurityContext {

	private final String tenant;
	private final String userId;

	public DummySecurityContext(String tenant, String userId) {
		this.tenant = tenant;
		this.userId = userId;
	}

	@Override
	public Principal getUserPrincipal() {
		return new User(userId, tenant);
	}

	@Override
	public boolean isUserInRole(String role) {
		return false;
	}

	@Override
	public boolean isSecure() {
		return false;
	}

	@Override
	public String getAuthenticationScheme() {
		return null;
	}
}
