package com.abacogroup.partyregistry.bundle.tenant;

import static com.abacogroup.bundles.Constants.ALL_TENANTS;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.greaterThanOrEqualTo;

import com.abacogroup.bundles.listener.tenant.TenantMessage;
import com.abacogroup.partyregistry.JdbiTest;
import com.abacogroup.partyregistry.db.dao.I18nDAO;
import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

@Slf4j
@ExtendWith(DropwizardExtensionsSupport.class)
class I18nTenantMessageProcessorTest extends JdbiTest {

	private final I18nTenantMessageProcessor service = getService(I18nTenantMessageProcessor.class);

	@Test
	public void testOnMessage() {
		I18nDAO dao = getDAO(I18nDAO.class);
		Long defaultCount = dao.countAll(ALL_TENANTS);
		assertThat(defaultCount, greaterThanOrEqualTo(0L));

		getJdbi().useHandle(handle -> {
			handle.begin();
			String newTenant = "tnt";

			service.onMessage(new TenantMessage()
					.setTenantId(newTenant));

			assertThat(dao.countAll(newTenant), is(defaultCount));
			handle.rollback();
		});
	}

}
