package com.abacogroup.partyregistry.core.impl;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.containsString;
import static org.hamcrest.Matchers.hasSize;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.notNullValue;

import com.abacogroup.partyregistry.JdbiTest;
import com.abacogroup.partyregistry.PrtTest;
import com.abacogroup.partyregistry.api.PartyTag;
import com.abacogroup.partyregistry.api.Tag;
import com.abacogroup.partyregistry.core.PartyTagService;
import com.abacogroup.partyregistry.core.exceptions.ErrCodes;
import com.abacogroup.partyregistry.core.exceptions.InvalidPartyException;
import com.abacogroup.partyregistry.core.exceptions.InvalidTagException;
import com.abacogroup.partyregistry.resources.req.ReqContext;
import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;
import java.util.List;
import java.util.Map;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

@Slf4j
@ExtendWith(DropwizardExtensionsSupport.class)
class PartyTagServiceImplTest extends JdbiTest {

	private static final String currentUser = "PartyTagServiceImplTest_u";
	private static final String tenantId = "PartyTagServiceImplTest_t";

	private static final Map<String, Object> testScriptParams = Map.of(
			"test_tenant", tenantId,
			"user_id", currentUser
	);

	private static final ReqContext reqContext =
			new ReqContext(tenantId, currentUser, "en");

	private final PartyTagService service = getService(PartyServiceImpl.class);

	@BeforeAll
	@AfterAll
	public static void beforeAll() {
		List<String> initScripts = List.of("rollback");
		execSqlFiles(PrtTest.class, initScripts, testScriptParams);
	}

	@Test
	void testPartyTags() {

		setUnusedBindingAllowed(true);
		getJdbi().useHandle(handle -> {
			handle.begin();

			List<String> initScripts = List.of("prt_parties_tags");
			execSqlFiles(this.getClass(), initScripts, testScriptParams);

			List<PartyTag> tags = service.getPartyTags(reqContext, -1L);
			assertThat(tags, hasSize(2));
			assertThat(tags.get(0).getTagCode(), notNullValue());
			assertThat(tags.get(0).getTagI18nCode(), notNullValue());

			handle.rollback();
		});

	}

	@Test
	void test_attach_detach_tag() {

		setUnusedBindingAllowed(true);
		getJdbi().useHandle(handle -> {
			handle.begin();

			List<String> initScripts = List.of("prt_parties_tags");
			execSqlFiles(this.getClass(), initScripts, testScriptParams);

			Long partyId = -3L;

			Tag tag = service.attachTag(reqContext, partyId, "LOL");
			assertThat(tag.getCode(), is("LOL"));
			assertThat(tag.getId(), is(-2L));

			service.detachTag(reqContext, partyId, "STO_TAG");
			assertThat(service.getPartyTags(reqContext, partyId), hasSize(1));

			service.detachTag(reqContext, partyId, "LOL");
			assertThat(service.getPartyTags(reqContext, partyId), hasSize(0));

			handle.rollback();
		});

	}

	@Test
	void test_attach_tag_when_tag_is_invalid() {
		setUnusedBindingAllowed(true);
		getJdbi().useHandle(handle -> {
			handle.begin();

			List<String> initScripts = List.of("prt_parties_tags");
			execSqlFiles(this.getClass(), initScripts, testScriptParams);

			Long partyId = -3L;
			String INVALID_TAG_CODE = "XXX";

			InvalidTagException exception = Assertions.assertThrows(InvalidTagException.class, () -> {
				service.attachTag(reqContext,
						partyId, INVALID_TAG_CODE);
			});
			assertThat(exception.getCode(), is(ErrCodes.TAG_NOT_FOUND));
			assertThat(exception.getMessage(), containsString("tag not found " + INVALID_TAG_CODE));

			handle.rollback();
		});
	}

	@Test
	void test_detach_tag_when_party_is_invalid() {
		setUnusedBindingAllowed(true);
		getJdbi().useHandle(handle -> {
			handle.begin();

			List<String> initScripts = List.of("prt_parties_tags");
			execSqlFiles(this.getClass(), initScripts, testScriptParams);

			Long INVALID_PARTY_ID = -404L;

			InvalidPartyException exception = Assertions.assertThrows(InvalidPartyException.class, () -> {
				service.detachTag(reqContext,
						INVALID_PARTY_ID, "LOL");
			});
			assertThat(exception.getCode(), is(ErrCodes.PARTY_NOT_FOUND));
			assertThat(exception.getMessage(), containsString("party not found " + INVALID_PARTY_ID));

			handle.rollback();
		});

	}

	@Test
	void test_detach_a_non_existent_invalid_tag_then_NOTHING() {

		setUnusedBindingAllowed(true);
		getJdbi().useHandle(handle -> {
			handle.begin();

			List<String> initScripts = List.of("prt_parties_tags");
			execSqlFiles(this.getClass(), initScripts, testScriptParams);

			Long partyId = -1L;
			String INVALID_TAG_CODE = "XXX";

			assertThat(service.getPartyTags(reqContext, partyId), hasSize(2));

			service.detachTag(reqContext, partyId, INVALID_TAG_CODE);

			assertThat(service.getPartyTags(reqContext, partyId), hasSize(2));

			handle.rollback();
		});

	}
}
