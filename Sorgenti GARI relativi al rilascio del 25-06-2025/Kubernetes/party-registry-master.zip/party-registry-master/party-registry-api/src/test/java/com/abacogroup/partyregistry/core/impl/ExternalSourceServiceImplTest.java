package com.abacogroup.partyregistry.core.impl;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.mock;

import com.abacogroup.dynamicdocuments.bean.Document;
import com.abacogroup.dynamicdocuments.bean.InsertDocument;
import com.abacogroup.dynamicdocuments.services.DocumentService;
import com.abacogroup.dynamicdocuments.services.DocumentTypeService;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.parti.testing.ReqContextUtils;
import com.abacogroup.partyregistry.JdbiTest;
import com.abacogroup.partyregistry.api.ContactTypeEnum;
import com.abacogroup.partyregistry.api.GenderEnum;
import com.abacogroup.partyregistry.api.PartyRes;
import com.abacogroup.partyregistry.api.PartyTypeEnum;
import com.abacogroup.partyregistry.api.Tag;
import com.abacogroup.partyregistry.core.ExternalSourceService;
import com.abacogroup.partyregistry.core.client.ExternalSourceClientV1;
import com.abacogroup.partyregistry.core.dynamicdoc.PartyDynamicDocumentManager;
import com.abacogroup.partyregistry.core.dynamicdoc.PartyDynamicDocumentManagerImpl;
import com.abacogroup.partyregistry.core.exceptions.ExternalSourceException;
import com.abacogroup.partyregistry.core.exceptions.ExternalSourceException.ErrEnum;
import com.abacogroup.partyregistry.db.dao.ContactDAO;
import com.abacogroup.partyregistry.db.dao.PartyDAO;
import com.abacogroup.partyregistry.db.dao.PartyDocumentDAO;
import com.abacogroup.partyregistry.db.dao.PartyRelationPartyDAO;
import com.abacogroup.partyregistry.db.dao.PartyRelationTypeDAO;
import com.abacogroup.partyregistry.db.ntt.Address;
import com.abacogroup.partyregistry.db.ntt.PartyContactEntity;
import com.abacogroup.partyregistry.db.ntt.PartyEntity;
import com.abacogroup.partyregistry.db.ntt.PartyRelationEntity;
import com.abacogroup.partyregistry.db.ntt.PartyRelationPartyEntity;
import com.abacogroup.partyregistry.dto.v1.AddressExternalDtoV1;
import com.abacogroup.partyregistry.dto.v1.ExternalSourceDtoV1;
import com.abacogroup.partyregistry.dto.v1.PartyContactExternalDtoV1;
import com.abacogroup.partyregistry.dto.v1.PartyContactExternalDtoV1.PartyContactExternalDtoV1Builder;
import com.abacogroup.partyregistry.dto.v1.PartyExternalDtoV1;
import com.abacogroup.partyregistry.dto.v1.PartyExternalDtoV1.PartyExternalDtoV1Builder;
import com.abacogroup.partyregistry.dto.v1.PartyRelationExternalDtoV1;
import com.abacogroup.partyregistry.dto.v1.PartyRelationExternalDtoV1.PartyRelationExternalDtoV1Builder;
import com.abacogroup.partyregistry.dto.v1.PartyRelationItemExternalDtoV1;
import com.abacogroup.partyregistry.dto.v1.PartyRelationItemExternalDtoV1.PartyRelationItemExternalDtoV1Builder;
import com.abacogroup.partyregistry.resources.req.PartyExternalReq;
import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ThreadLocalRandom;
import java.util.stream.Collectors;
import lombok.extern.slf4j.Slf4j;
import org.assertj.core.groups.Tuple;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

@Slf4j
@ExtendWith(DropwizardExtensionsSupport.class)
class ExternalSourceServiceImplTest extends JdbiTest {

	private final ReqContextUtils ctx = new ReqContextUtils(this.getClass());

	private final ExternalSourceClientV1 externalSourceClient = mock(ExternalSourceClientV1.class);
	private final DocumentTypeService documentTypeService = mock(DocumentTypeService.class);
	private final DocumentService documentService = mock(DocumentService.class);

	private final PartyDynamicDocumentManager partyDynamicDocumentManager = getService(PartyDynamicDocumentManagerImpl.class);

	private final ExternalSourceService service = getService(ExternalSourceServiceImpl.class);

	@BeforeEach
	void setUp() {
		this.injectMock(partyDynamicDocumentManager, documentService);
		this.injectMock(partyDynamicDocumentManager, documentTypeService);
		this.injectMock(service, externalSourceClient);
	}

	// ----- upsertParty -----
	@Test
	void test_upsertParty_insertOk() {
		setUnusedBindingAllowed(true);
		getJdbi().useHandle(handle -> {
			handle.begin();

			List<String> initScripts = List.of("insert_external_sources", "insert_parties");
			execSqlFiles(this.getClass(), initScripts, ctx.getTestScriptParams());

			String sourceCode = "SOURCE3";
			String partyCode = "XXXYYY11A22B333C";

			PartyExternalDtoV1 partyExternal = givenExternalParty(partyCode, PartyTypeEnum.N, partyCode, null).build();
			InsertDocument doc1 = givenInsertDocument("DEF_TEST_1");
			InsertDocument doc2 = givenInsertDocument("DEF_TEST_2");
			PartyExternalDtoV1 p111 = givenExternalParty("XXXYYY11A22B111R"/* new */, PartyTypeEnum.N, null, null).build();
			PartyExternalDtoV1 p121 = givenExternalParty("00000000121"/*      new */, PartyTypeEnum.L, null, null).build();
			PartyExternalDtoV1 p122 = givenExternalParty("XXXYYY11A22B122R"/* new */, PartyTypeEnum.N, null, null).build();
			PartyExternalDtoV1 p211 = givenExternalParty("XXXYYY11A22B211R"/* new */, PartyTypeEnum.N, null, null).build();
			PartyExternalDtoV1 p221 = givenExternalParty("XXXYYY11A22B221R"/* new */, PartyTypeEnum.N, null, null).build();
			PartyContactExternalDtoV1 c1Pec = givenContact(ContactTypeEnum.PEC, "xxx.yyy@ccc-pec.it").build();
			PartyContactExternalDtoV1 c2Tel = givenContact(ContactTypeEnum.PHONE, "000-123456").build();
			PartyContactExternalDtoV1 c3Pec = givenContact(ContactTypeEnum.PEC, "xxx.yyy.other@ccc-pec.it").build();
			ExternalSourceDtoV1 externalSourceDto = ExternalSourceDtoV1.builder()
					.setPartyData(partyExternal)
					.setDocuments(List.of(doc1, doc2))
					.setRelations(List.of(
							givenRel("REL_T1",
									givenRelParty("REL_T1_R1", p111).build()
							).build(),
							givenRel("REL_T2",
									givenRelParty("REL_T2_R2", p221).build(),
									givenRelParty("REL_T2_R1", p211).build()
							).build(),
							givenRel("REL_T1",
									givenRelParty("REL_T1_R2", p121).build(),
									givenRelParty("REL_T1_R2", p122).build()
							).build()
					))
					.setContacts(List.of(c1Pec, c2Tel, c3Pec))
					.build();
			given(externalSourceClient.getExternalPartyByCode(anyString(), any(), anyString(), anyString()))
					.willReturn(externalSourceDto);

			given(documentService.insertDocument(anyString(), any(), any(), anyString(), any(), any()))
					.willAnswer(i -> ThreadLocalRandom.current().nextLong(1, 100000));
			given(documentService.getDocumentFromId(any()))
					.willReturn(Document.empty());

			PartyExternalReq req = PartyExternalReq.builder()
					.setSourceCode(sourceCode)
					.setPartyCode(partyCode)
					.build();

			// test
			PartyRes partyRes = service.upsertParty(ctx.getReqContext(), req);

			assertThat(partyRes).isNotNull()
					.hasFieldOrPropertyWithValue("externalSource.code", sourceCode)
					.usingRecursiveComparison()
					.ignoringFields("id", "externalSource", "addressHome", "addressBilling", "tags", "archived",
							"addressResidential.id", "addressResidential.districtShortDescr", "addressResidential.municipalityI18nCode")
					.isEqualTo(partyExternal);

			PartyDAO partyDAO = handle.attach(PartyDAO.class);
			Optional<PartyEntity> p111_opt = partyDAO.findByTenantAndCode(ctx.getTenantId(), p111.getCode());
			Optional<PartyEntity> p121_opt = partyDAO.findByTenantAndCode(ctx.getTenantId(), p121.getCode());
			Optional<PartyEntity> p122_opt = partyDAO.findByTenantAndCode(ctx.getTenantId(), p122.getCode());
			Optional<PartyEntity> p211_opt = partyDAO.findByTenantAndCode(ctx.getTenantId(), p211.getCode());
			Optional<PartyEntity> p221_opt = partyDAO.findByTenantAndCode(ctx.getTenantId(), p221.getCode());
			assertThat(p111_opt).isPresent().get()
					.hasFieldOrPropertyWithValue("sourceCode", sourceCode)
					.usingRecursiveComparison()
					.ignoringFields("id", "addressResidential", "addressHome", "addressBilling", "tags", "archived",
							"pkid", "fkAddressResidential", "fkAddressHome", "fkAddressBilling", "flArchived", "sourceCode",
							"userIdInsert", "dtInsert", "userIdDelete", "dtDelete", "tenantId")
					.isEqualTo(p111);
			assertThat(p121_opt).isPresent();
			assertThat(p122_opt).isPresent();
			assertThat(p211_opt).isPresent();
			assertThat(p221_opt).isPresent();

			PartyDocumentDAO partyDocumentDAO = handle.attach(PartyDocumentDAO.class);
			assertThat(partyDocumentDAO.findEntitiesByDocumentDefCodeAndPartyId(partyRes.getId(), doc1.getDefCode(), ctx.getReqContext()))
					.hasSize(1);
			assertThat(partyDocumentDAO.findEntitiesByDocumentDefCodeAndPartyId(partyRes.getId(), doc2.getDefCode(), ctx.getReqContext()))
					.hasSize(1);

			PartyRelationTypeDAO relationDAO = handle.attach(PartyRelationTypeDAO.class);
			List<PartyRelationEntity> relsT1 = relationDAO.findByRelationType(ctx.getTenantId(), partyRes.getId(), -1L);
			List<PartyRelationEntity> relsT2 = relationDAO.findByRelationType(ctx.getTenantId(), partyRes.getId(), -2L);
			assertThat(relsT1).hasSize(2);
			assertThat(relsT2).hasSize(1);

			PartyRelationPartyDAO relationPartyDAO = handle.attach(PartyRelationPartyDAO.class);
			List<PartyRelationPartyEntity> relT1Parties = relsT1.stream()
					.map(rel -> relationPartyDAO.findByRelationId(ctx.getTenantId(), partyRes.getId(), rel.getId()))
					.flatMap(Collection::stream)
					.collect(Collectors.toList());
			assertThat(relT1Parties).hasSize(3)
					.extracting(PartyRelationPartyEntity::getPartyId, PartyRelationPartyEntity::getRelationRoleId)
					.containsExactlyInAnyOrder(
							Tuple.tuple(p111_opt.get().getId(), -101L),
							Tuple.tuple(p121_opt.get().getId(), -102L),
							Tuple.tuple(p122_opt.get().getId(), -102L)
					);
			List<PartyRelationPartyEntity> relT2Parties = relsT2.stream()
					.map(rel -> relationPartyDAO.findByRelationId(ctx.getTenantId(), partyRes.getId(), rel.getId()))
					.flatMap(Collection::stream)
					.collect(Collectors.toList());
			assertThat(relT2Parties).hasSize(2)
					.extracting(PartyRelationPartyEntity::getPartyId, PartyRelationPartyEntity::getRelationRoleId)
					.containsExactlyInAnyOrder(
							Tuple.tuple(p211_opt.get().getId(), -201L),
							Tuple.tuple(p221_opt.get().getId(), -202L)
					);

			ContactDAO contactDAO = handle.attach(ContactDAO.class);
			assertThat(contactDAO.loadContactsByTypeAndPartyId(ctx.getTenantId(), partyRes.getId(), ContactTypeEnum.PEC.name())).hasSize(2)
					.extracting(PartyContactEntity::getContactValue).containsExactlyInAnyOrder(c1Pec.getContactValue(), c3Pec.getContactValue());
			assertThat(contactDAO.loadContactsByTypeAndPartyId(ctx.getTenantId(), partyRes.getId(), ContactTypeEnum.PHONE.name())).hasSize(1)
					.extracting(PartyContactEntity::getContactValue).containsExactlyInAnyOrder(c2Tel.getContactValue());
			assertThat(contactDAO.loadContactsByTypeAndPartyId(ctx.getTenantId(), partyRes.getId(), ContactTypeEnum.EMAIL.name())).isEmpty();

			handle.rollback();
		});
	}

	@Test
	void test_upsertParty_updateExternalOk() {
		setUnusedBindingAllowed(true);
		getJdbi().useHandle(handle -> {
			handle.begin();

			List<String> initScripts = List.of("insert_external_sources", "insert_parties");
			execSqlFiles(this.getClass(), initScripts, ctx.getTestScriptParams());

			String sourceCode = "SOURCE3";
			String partyCode = "RSSMRA73L09B354X";

			PartyExternalDtoV1 partyExternal = givenExternalParty(partyCode, PartyTypeEnum.N, partyCode, null).build();
			InsertDocument doc1 = givenInsertDocument("DEF_TEST_1");
			InsertDocument doc2 = givenInsertDocument("DEF_TEST_2");
			PartyExternalDtoV1 p111 = givenExternalParty("XXXYYY11A22B111R"/* new */, PartyTypeEnum.N, null, null).build();
			PartyExternalDtoV1 p211 = givenExternalParty("00000000333"/*      333 */, PartyTypeEnum.L, "00000000333", "00000000333").build();
			PartyExternalDtoV1 p221 = givenExternalParty("QTTMRA44L04B354X"/* 444 */, PartyTypeEnum.N, "QTTMRA44L04B354X", null).build();
			PartyContactExternalDtoV1 c1Pec = givenContact(ContactTypeEnum.PEC, "mario.rossi@ccc-pec.it").build();
			PartyContactExternalDtoV1 c2Tel = givenContact(ContactTypeEnum.PHONE, "000-1110111").build();
			PartyContactExternalDtoV1 c3Pec = givenContact(ContactTypeEnum.PEC, "mario.rossi.other@ccc-pec.it").build();
			ExternalSourceDtoV1 externalSourceDto = ExternalSourceDtoV1.builder()
					.setPartyData(partyExternal)
					.setDocuments(List.of(doc1, doc2))
					.setRelations(List.of(
							givenRel("REL_T1",
									givenRelParty("REL_T1_R1", p111).build()
							).build(),
							givenRel("REL_T2",
									givenRelParty("REL_T2_R2", p221).build(),
									givenRelParty("REL_T2_R1", p211).build()
							).build()
					))
					.setContacts(List.of(c1Pec, c2Tel, c3Pec))
					.build();
			given(externalSourceClient.getExternalPartyByCode(anyString(), any(), anyString(), anyString()))
					.willReturn(externalSourceDto);

			given(documentService.insertDocument(anyString(), any(), any(), anyString(), any(), any()))
					.willAnswer(i -> ThreadLocalRandom.current().nextLong(1, 100000));
			given(documentService.getDocumentFromId(any()))
					.willReturn(Document.empty());

			PartyExternalReq req = PartyExternalReq.builder()
					.setSourceCode(sourceCode)
					.setPartyCode(partyCode)
					.build();

			// test
			PartyRes partyRes = service.upsertParty(ctx.getReqContext(), req);

			assertThat(partyRes).isNotNull()
					.hasFieldOrPropertyWithValue("externalSource.code", sourceCode)
					.usingRecursiveComparison()
					.ignoringFields("id", "externalSource", "addressHome", "addressBilling", "tags", "archived",
							"addressResidential.id", "addressResidential.districtShortDescr", "addressResidential.municipalityI18nCode")
					.isEqualTo(partyExternal);

			assertThat(partyRes.getTags()).isNotNull()
					.hasSize(1)
					.extracting(Tag::getCode)
					.containsExactly("LOL");

			PartyDAO partyDAO = handle.attach(PartyDAO.class);
			Optional<PartyEntity> p111_opt = partyDAO.findByTenantAndCode(ctx.getTenantId(), p111.getCode());
			Optional<PartyEntity> p211_opt = partyDAO.findByTenantAndCode(ctx.getTenantId(), p211.getCode());
			Optional<PartyEntity> p221_opt = partyDAO.findByTenantAndCode(ctx.getTenantId(), p221.getCode());
			assertThat(p111_opt).isPresent();
			assertThat(p211_opt).isPresent().get()
					.hasFieldOrPropertyWithValue("sourceCode", sourceCode)
					.usingRecursiveComparison()
					.ignoringFields("id", "addressResidential", "addressHome", "addressBilling", "tags", "archived",
							"pkid", "fkAddressResidential", "fkAddressHome", "fkAddressBilling", "flArchived", "sourceCode",
							"userIdInsert", "dtInsert", "userIdDelete", "dtDelete", "tenantId")
					.isEqualTo(p211);
			assertThat(p221_opt).isPresent().get()
					.hasFieldOrPropertyWithValue("sourceCode", sourceCode)
					.usingRecursiveComparison()
					.ignoringFields("id", "addressResidential", "addressHome", "addressBilling", "tags", "archived",
							"pkid", "fkAddressResidential", "fkAddressHome", "fkAddressBilling", "flArchived", "sourceCode",
							"userIdInsert", "dtInsert", "userIdDelete", "dtDelete", "tenantId")
					.isEqualTo(p221);

			PartyDocumentDAO partyDocumentDAO = handle.attach(PartyDocumentDAO.class);
			assertThat(partyDocumentDAO.findEntitiesByDocumentDefCodeAndPartyId(partyRes.getId(), doc1.getDefCode(), ctx.getReqContext()))
					.hasSize(1);
			assertThat(partyDocumentDAO.findEntitiesByDocumentDefCodeAndPartyId(partyRes.getId(), doc2.getDefCode(), ctx.getReqContext()))
					.hasSize(1);
			assertThat(partyDocumentDAO.findEntitiesByDocumentDefCodeAndPartyId(partyRes.getId(), "DEF_TEST_3", ctx.getReqContext()))
					.hasSize(1);

			PartyRelationTypeDAO relationDAO = handle.attach(PartyRelationTypeDAO.class);
			List<PartyRelationEntity> relsT1 = relationDAO.findByRelationType(ctx.getTenantId(), partyRes.getId(), -1L);
			List<PartyRelationEntity> relsT2 = relationDAO.findByRelationType(ctx.getTenantId(), partyRes.getId(), -2L);
			List<PartyRelationEntity> relsT3 = relationDAO.findByRelationType(ctx.getTenantId(), partyRes.getId(), -3L);
			assertThat(relsT1).hasSize(1);
			assertThat(relsT2).hasSize(1);
			assertThat(relsT3).hasSize(1);

			PartyRelationPartyDAO relationPartyDAO = handle.attach(PartyRelationPartyDAO.class);
			List<PartyRelationPartyEntity> relT1Parties = relsT1.stream()
					.map(rel -> relationPartyDAO.findByRelationId(ctx.getTenantId(), partyRes.getId(), rel.getId()))
					.flatMap(Collection::stream)
					.collect(Collectors.toList());
			assertThat(relT1Parties).hasSize(1)
					.extracting(PartyRelationPartyEntity::getPartyId, PartyRelationPartyEntity::getRelationRoleId)
					.containsExactlyInAnyOrder(
							Tuple.tuple(p111_opt.get().getId(), -101L)
					);
			List<PartyRelationPartyEntity> relT2Parties = relsT2.stream()
					.map(rel -> relationPartyDAO.findByRelationId(ctx.getTenantId(), partyRes.getId(), rel.getId()))
					.flatMap(Collection::stream)
					.collect(Collectors.toList());
			assertThat(relT2Parties).hasSize(2)
					.extracting(PartyRelationPartyEntity::getPartyId, PartyRelationPartyEntity::getRelationRoleId)
					.containsExactlyInAnyOrder(
							Tuple.tuple(-333L, -201L),
							Tuple.tuple(-444L, -202L)
					);
			List<PartyRelationPartyEntity> relT3Parties = relsT3.stream()
					.map(rel -> relationPartyDAO.findByRelationId(ctx.getTenantId(), partyRes.getId(), rel.getId()))
					.flatMap(Collection::stream)
					.collect(Collectors.toList());
			assertThat(relT3Parties).hasSize(1)
					.extracting(PartyRelationPartyEntity::getPartyId, PartyRelationPartyEntity::getRelationRoleId)
					.containsExactlyInAnyOrder(
							Tuple.tuple(-222L, -302L)
					);

			ContactDAO contactDAO = handle.attach(ContactDAO.class);
			assertThat(contactDAO.loadContactsByTypeAndPartyId(ctx.getTenantId(), partyRes.getId(), ContactTypeEnum.PEC.name())).hasSize(2)
					.extracting(PartyContactEntity::getContactValue).containsExactlyInAnyOrder(c1Pec.getContactValue(), c3Pec.getContactValue());
			assertThat(contactDAO.loadContactsByTypeAndPartyId(ctx.getTenantId(), partyRes.getId(), ContactTypeEnum.PHONE.name())).hasSize(1)
					.extracting(PartyContactEntity::getContactValue).containsExactlyInAnyOrder(c2Tel.getContactValue());
			assertThat(contactDAO.loadContactsByTypeAndPartyId(ctx.getTenantId(), partyRes.getId(), ContactTypeEnum.EMAIL.name())).hasSize(1)
					.extracting(PartyContactEntity::getContactValue).containsExactlyInAnyOrder("test111@example.com");

			assertThat(contactDAO.loadContactsByTypeAndPartyId(ctx.getTenantId(), -444L, ContactTypeEnum.PHONE.name())).hasSize(1)
					.extracting(PartyContactEntity::getContactValue).containsExactlyInAnyOrder("000-4440444");
			assertThat(contactDAO.loadContactsByTypeAndPartyId(ctx.getTenantId(), -444L, ContactTypeEnum.EMAIL.name())).hasSize(1)
					.extracting(PartyContactEntity::getContactValue).containsExactlyInAnyOrder("test444@example.com");


			handle.rollback();
		});
	}

	@Test
	void test_upsertParty_updateManualOk() {
		setUnusedBindingAllowed(true);
		getJdbi().useHandle(handle -> {
			handle.begin();

			List<String> initScripts = List.of("insert_external_sources", "insert_parties");
			execSqlFiles(this.getClass(), initScripts, ctx.getTestScriptParams());

			String sourceCode = "SOURCE3";
			String partyCode = "01234567890";

			PartyExternalDtoV1 partyExternal = givenExternalParty(partyCode, PartyTypeEnum.L, partyCode, partyCode).build();
			ExternalSourceDtoV1 externalSourceDto = ExternalSourceDtoV1.builder().setPartyData(partyExternal).build();
			given(externalSourceClient.getExternalPartyByCode(anyString(), any(), anyString(), anyString()))
					.willReturn(externalSourceDto);

			PartyExternalReq req = PartyExternalReq.builder()
					.setSourceCode(sourceCode)
					.setPartyCode(partyCode)
					.build();

			PartyRes partyRes = service.upsertParty(ctx.getReqContext(), req);

			assertThat(partyRes).isNotNull()
					.hasFieldOrPropertyWithValue("externalSource.code", sourceCode)
					.usingRecursiveComparison()
					.ignoringFields("id", "externalSource", "addressHome", "addressBilling", "tags", "archived",
							"addressResidential.id", "addressResidential.districtShortDescr", "addressResidential.municipalityI18nCode")
					.isEqualTo(partyExternal);

			assertThat(partyRes.getTags()).isNotNull()
					.hasSize(1)
					.extracting(Tag::getCode)
					.containsExactly("BUG");

			handle.rollback();
		});
	}

	@Test
	void test_upsertParty_payloadKo() {
		setUnusedBindingAllowed(true);
		getJdbi().useHandle(handle -> {
			handle.begin();

			List<String> initScripts = List.of("insert_external_sources", "insert_parties");
			execSqlFiles(this.getClass(), initScripts, ctx.getTestScriptParams());

			String sourceCode = "SOURCE3";
			String partyCode = "XXXYYY11A22B333C";

			PartyExternalDtoV1 partyExternal = givenExternalParty(null, null, null, null).build();
			InsertDocument doc1 = givenInsertDocument("DEF_TEST_1");
			InsertDocument doc2 = givenInsertDocument("DEF_TEST_2");
			PartyExternalDtoV1 p111 = givenExternalParty("      "/* new */, null, null, null).build();
			PartyContactExternalDtoV1 c1Pec = givenContact(null, "xxx.yyy@ccc-pec.it").build();
			PartyContactExternalDtoV1 c2Tel = givenContact(ContactTypeEnum.PHONE, "   ").build();
			PartyContactExternalDtoV1 c3Pec = givenContact(ContactTypeEnum.PEC, "xxx.yyy.other@ccc-pec.it").setSubType(null).build();
			ExternalSourceDtoV1 externalSourceDto = ExternalSourceDtoV1.builder()
					.setPartyData(partyExternal)
					.setDocuments(List.of(doc1, doc2))
					.setRelations(List.of(
							givenRel("REL_T1").build(),
							givenRel("",
									givenRelParty("", null).build(),
									givenRelParty("REL_T1_R1", p111).setDtStart(null).build()
							).build()
					))
					.setContacts(List.of(c1Pec, c2Tel, c3Pec))
					.build();
			given(externalSourceClient.getExternalPartyByCode(anyString(), any(), anyString(), anyString()))
					.willReturn(externalSourceDto);

			PartyExternalReq req = PartyExternalReq.builder()
					.setSourceCode(sourceCode)
					.setPartyCode(partyCode)
					.build();

			ExternalSourceException externalSourceException = assertThrows(ExternalSourceException.class,
					() -> service.upsertParty(ctx.getReqContext(), req));

			assertThat(externalSourceException).isNotNull()
					//.satisfies(ex -> System.out.println(ex.getErrorBody().getMessage()))
					.extracting(ExternalSourceException::getCode).isEqualTo(ErrEnum.PAYLOAD_NOT_READEABLE.toString());

			handle.rollback();
		});
	}


	// ##################################################################################################################### //

	private PartyContactExternalDtoV1Builder<?, ?> givenContact(ContactTypeEnum pec, String mail) {
		return PartyContactExternalDtoV1.builder()
				.setContactType(pec)
				.setSubType("test")
				.setContactValue(mail);
	}

	private PartyRelationItemExternalDtoV1Builder<?, ?> givenRelParty(String roleCode, PartyExternalDtoV1 partyData) {
		return PartyRelationItemExternalDtoV1.builder()
				.setDtStart(AbsoluteDate.of("19700101"))
				.setRoleCode(roleCode)
				.setPartyData(partyData);
	}

	private PartyRelationExternalDtoV1Builder<?, ?> givenRel(String relationCode, PartyRelationItemExternalDtoV1... relParties) {
		return PartyRelationExternalDtoV1.builder()
				.setRelationCode(relationCode)
				.setParties(List.of(relParties));
	}

	private InsertDocument givenInsertDocument(String defCode) {
		Document document = Document.empty();
		document.setFields(Map.of(
				"foo", "bar "+defCode,
				defCode.toLowerCase(), 999
		));

		InsertDocument insertDocument = new InsertDocument();
		insertDocument.setBusinessId(-1L);
		insertDocument.setDefCode(defCode);
		insertDocument.setLabel("Test " + defCode);
		insertDocument.setDoc(document);

		return insertDocument;
	}

	private PartyExternalDtoV1Builder<?, ?> givenExternalParty(String partyCode, PartyTypeEnum partyType, String taxCode, String vatNumber) {
		return PartyExternalDtoV1.builder()
				.setPartyType(partyType)
				.setGender(GenderEnum.M)
				.setLastName("PALLAZZO")
				.setFirstName("ENRICO")
				.setTaxCode(taxCode)
				.setVatNumber(vatNumber)
				.setCode(partyCode)
				.setLegalStatus("OTHER")
				.setBirthDate(AbsoluteDate.of("19500521"))
				.setDeathDate(AbsoluteDate.of("99991231"))
				.setBirthMunicipality("XXX_00_000_000")
				.setNationality("XXX")
				.setAddressResidential(AddressExternalDtoV1.builder()
						.setMunicipality("XXX_00_000_000")
						.setLocality("Loc. Abcd")
						.setStreet("via Roma")
						.setHouseNumber("99")
						.setPostcode("12345")
						.setDetails("details")
						.setNote("note")
						.build());
	}

}
