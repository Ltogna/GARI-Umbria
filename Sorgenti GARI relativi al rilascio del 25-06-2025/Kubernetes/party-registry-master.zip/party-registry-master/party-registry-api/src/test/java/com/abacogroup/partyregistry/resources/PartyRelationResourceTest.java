package com.abacogroup.partyregistry.resources;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.hamcrest.CoreMatchers.nullValue;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.jdbi.paging.impl.InfiniteListResultsImpl;
import com.abacogroup.partyregistry.PrtTest;
import com.abacogroup.partyregistry.api.PartyRelation;
import com.abacogroup.partyregistry.core.AclService;
import com.abacogroup.partyregistry.core.PartyRelationService;
import com.abacogroup.partyregistry.core.impl.PartyRelationServiceImpl;
import com.abacogroup.partyregistry.resources.req.PartyRelationTypeSearchReq;
import com.abacogroup.partyregistry.resources.req.ReqContext;
import com.abacogroup.partyregistry.resources.req.rel.CreatePartyRelationReq;
import com.abacogroup.partyregistry.resources.req.rel.PartyRelationDetailRequest;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;
import io.dropwizard.testing.junit5.ResourceExtension;
import jakarta.ws.rs.core.Response;
import java.util.Map;
import lombok.extern.slf4j.Slf4j;
import org.hamcrest.Matchers;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mockito;

@Slf4j
@ExtendWith({ DropwizardExtensionsSupport.class })
class PartyRelationResourceTest {

	private final AclService aclService = Mockito.mock(AclService.class);
	private final PartyRelationService partyRelationService = Mockito.mock(PartyRelationServiceImpl.class);

	private final ResourceExtension EXT = WebCliHelper
			.createEXT(new PartyRelationResource(aclService, partyRelationService));

	@Test
	void test_list() {
		//deve vedere tutti i tipi di rel di un soggetto
		String path = String.format(PrtTest.MASTER_PATH + "/parties/1/relation-types");
		PartyRelationTypeSearchReq partyRelationTypeSearchRequest = new PartyRelationTypeSearchReq();
		ObjectMapper mapper = new ObjectMapper();
		Map<String, Object> beanMap = mapper.convertValue(partyRelationTypeSearchRequest, Map.class);

		InfiniteListResults<PartyRelation> ignored = WebCliHelper.executeGet(EXT, path, beanMap,
				WebCliHelper.BASIC_CREDENTIALS, InfiniteListResultsImpl.class);

		ArgumentCaptor<PartyRelationTypeSearchReq> requestArgumentCaptor = ArgumentCaptor.forClass(
				PartyRelationTypeSearchReq.class);
		ArgumentCaptor<ReqContext> reqCtxCaptor = ArgumentCaptor.forClass(ReqContext.class);
		verify(partyRelationService, times(1))
				.search(reqCtxCaptor.capture(), eq(1L), requestArgumentCaptor.capture(), eq(null));

		PartyRelationTypeSearchReq searchRequest = requestArgumentCaptor.getValue();
		assertThat(searchRequest, notNullValue());

		ReqContext reqContext = reqCtxCaptor.getValue();
		assertThat(reqContext.getTenantId(), is(PrtTest.TENANT_DEFAULT_CODE));
		assertThat(reqContext.getLang(), is("en"));
		assertThat(reqContext.getUsername(), is(WebCliHelper.BASIC_USERNAME));
	}

	@Test
	void test_list_2() {
		//deve vedere tutti i tipi di rel di un soggetto
		String path = String.format(PrtTest.MASTER_PATH + "/parties/1/relation-types");

		PartyRelationTypeSearchReq partyRelationTypeSearchRequest = new PartyRelationTypeSearchReq()
				.setRelationTypeCode("TYPE");

		ObjectMapper mapper = new ObjectMapper();
		Map<String, Object> beanMap = mapper.convertValue(partyRelationTypeSearchRequest, Map.class);

		WebCliHelper.executeGet(EXT, path, beanMap, WebCliHelper.BASIC_CREDENTIALS, InfiniteListResultsImpl.class);

		ArgumentCaptor<PartyRelationTypeSearchReq> requestArgumentCaptor = ArgumentCaptor.forClass(
				PartyRelationTypeSearchReq.class);
		ArgumentCaptor<ReqContext> reqCtxCaptor = ArgumentCaptor.forClass(ReqContext.class);
		verify(partyRelationService, times(1))
				.search(reqCtxCaptor.capture(), eq(1L), requestArgumentCaptor.capture(), eq(null));

		PartyRelationTypeSearchReq searchRequest = requestArgumentCaptor.getValue();
		assertThat(searchRequest.getRelationTypeCode(), is("TYPE"));

		ReqContext reqContext = reqCtxCaptor.getValue();
		assertThat(reqContext.getTenantId(), is(PrtTest.TENANT_DEFAULT_CODE));
		assertThat(reqContext.getLang(), is("en"));
		assertThat(reqContext.getUsername(), is(WebCliHelper.BASIC_USERNAME));
	}

	@Test
	void test_getById() {
		String path = String.format(PrtTest.MASTER_PATH + "/parties/1/relation-types/2");
		WebCliHelper.executeGet(EXT, path, null, WebCliHelper.BASIC_CREDENTIALS, PartyRelation.class);

		ArgumentCaptor<PartyRelationTypeSearchReq> requestArgumentCaptor = ArgumentCaptor.forClass(
				PartyRelationTypeSearchReq.class);

		ArgumentCaptor<ReqContext> reqCtxCaptor = ArgumentCaptor.forClass(ReqContext.class);
		verify(partyRelationService, times(1))
				.getRelationById(reqCtxCaptor.capture(), eq(1L), eq(2L));

		ReqContext reqContext = reqCtxCaptor.getValue();
		assertThat(reqContext.getTenantId(), is(PrtTest.TENANT_DEFAULT_CODE));
		assertThat(reqContext.getLang(), is("en"));
		assertThat(reqContext.getUsername(), is(WebCliHelper.BASIC_USERNAME));
	}

	@Test
	void test_insert() {
		String path = String.format(PrtTest.MASTER_PATH + "/parties/1/relation-types");

		CreatePartyRelationReq createPartyRelationReq = new CreatePartyRelationReq()
				.setRelationTypeCode("AZIENDA")
				.setNote("LOL");

		WebCliHelper.executePost(EXT, path, createPartyRelationReq, WebCliHelper.BASIC_CREDENTIALS,
				PartyRelation.class);

		ArgumentCaptor<ReqContext> reqCtxCaptor = ArgumentCaptor.forClass(ReqContext.class);
		ArgumentCaptor<CreatePartyRelationReq> argumentCaptor =
				ArgumentCaptor.forClass(CreatePartyRelationReq.class);

		verify(partyRelationService, times(1))
				.save(
						reqCtxCaptor.capture(),
						eq(1L),
						argumentCaptor.capture());

		CreatePartyRelationReq in = argumentCaptor.getValue();
		assertThat(in.getRelationTypeCode(), is("AZIENDA"));
		assertThat(in.getNote(), is("LOL"));
		assertThat(in.getRelationItemReq(), is(nullValue()));

		ReqContext reqContext = reqCtxCaptor.getValue();
		assertThat(reqContext.getTenantId(), is(PrtTest.TENANT_DEFAULT_CODE));
		assertThat(reqContext.getLang(), is("en"));
		assertThat(reqContext.getUsername(), is(WebCliHelper.BASIC_USERNAME));
	}

	@Test
	void test_expire() {
		String path = String.format(PrtTest.MASTER_PATH + "/parties/1/relation-types/2");

		ArgumentCaptor<ReqContext> reqCtxCaptor = ArgumentCaptor.forClass(ReqContext.class);
		WebCliHelper.executeDelete(EXT, path, WebCliHelper.BASIC_CREDENTIALS, Response.class);
		verify(partyRelationService, times(1))
				.expire(
						reqCtxCaptor.capture(),
						eq(1L),
						eq(2L));

		ReqContext reqContext = reqCtxCaptor.getValue();
		assertThat(reqContext.getTenantId(), Matchers.is("master"));
		assertThat(reqContext.getLang(), Matchers.is("en"));
		assertThat(reqContext.getUsername(), Matchers.is(WebCliHelper.BASIC_USERNAME));

	}

	@Test
	void test_update_detail() {

		final long partyId = 12L;
		final long relationId = 15L;
		final String note1Txt = "note1";

		String path = String.format(PrtTest.MASTER_PATH + "/parties/%d/relation-types/%d", partyId, relationId);
		ArgumentCaptor<ReqContext> reqCtxCaptor = ArgumentCaptor.forClass(ReqContext.class);

		PartyRelationDetailRequest detailRequest = new PartyRelationDetailRequest().setNote(note1Txt);
		WebCliHelper.executePut(EXT, path, detailRequest, WebCliHelper.BASIC_CREDENTIALS, PartyRelation.class);

		verify(partyRelationService, times(1))
				.saveDetail(
						reqCtxCaptor.capture(),
						eq(partyId),
						eq(relationId),
						eq(detailRequest));

		ReqContext reqContext = reqCtxCaptor.getValue();
		assertThat(reqContext.getTenantId(), Matchers.is("master"));
		assertThat(reqContext.getLang(), Matchers.is("en"));
		assertThat(reqContext.getUsername(), Matchers.is(WebCliHelper.BASIC_USERNAME));
	}

}



