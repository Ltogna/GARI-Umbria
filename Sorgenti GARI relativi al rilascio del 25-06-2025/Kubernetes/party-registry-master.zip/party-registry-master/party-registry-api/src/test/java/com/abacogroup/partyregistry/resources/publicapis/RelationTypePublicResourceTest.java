package com.abacogroup.partyregistry.resources.publicapis;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import com.abacogroup.jdbi.paging.impl.InfiniteListResultsImpl;
import com.abacogroup.partyregistry.PrtTest;
import com.abacogroup.partyregistry.api.v1.RelationTypeResponseV1;
import com.abacogroup.partyregistry.api.v1.req.RelationTypeSearchRequestV1;
import com.abacogroup.partyregistry.core.RelationTypeV1Service;
import com.abacogroup.partyregistry.core.impl.RelationTypeV1ServiceImpl;
import com.abacogroup.partyregistry.resources.WebCliHelper;
import com.abacogroup.partyregistry.resources.req.ReqContext;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;
import io.dropwizard.testing.junit5.ResourceExtension;
import java.util.Map;
import java.util.Optional;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mockito;

@Slf4j
@ExtendWith(DropwizardExtensionsSupport.class)
class RelationTypePublicResourceTest {

	private final RelationTypeV1Service relationTypeV1Service = Mockito.mock(RelationTypeV1ServiceImpl.class);
	private final ResourceExtension EXT = WebCliHelper.createEXT(new RelationTypePublicResource(relationTypeV1Service));

	private final ObjectMapper mapper = new ObjectMapper();

	@Test
	@SuppressWarnings("unchecked")
	void test_search() {
		String path = String.format(PrtTest.MASTER_PUBLIC_PATH + "/relation-types");
		RelationTypeSearchRequestV1 searchParams = new RelationTypeSearchRequestV1()
				.setCode("FAMILTY");
		Map<String, Object> beanMap = mapper.convertValue(searchParams, Map.class);

		WebCliHelper.executeGet(EXT, path, beanMap, WebCliHelper.BASIC_CREDENTIALS, InfiniteListResultsImpl.class);

		ArgumentCaptor<ReqContext> reqCtxCaptor = ArgumentCaptor.forClass(ReqContext.class);
		ArgumentCaptor<RelationTypeSearchRequestV1> searchReqArgumentCaptor = ArgumentCaptor.forClass(RelationTypeSearchRequestV1.class);
		verify(relationTypeV1Service, times(1))
				.search(reqCtxCaptor.capture(), searchReqArgumentCaptor.capture(), eq(null));

		RelationTypeSearchRequestV1 searchRequest = searchReqArgumentCaptor.getValue();
		assertThat(searchRequest.getCode(), is("FAMILTY"));

		ReqContext reqContext = reqCtxCaptor.getValue();
		assertThat(reqContext.getTenantId(), is("master"));
		assertThat(reqContext.getLang(), is("en"));
		assertThat(reqContext.getUsername(), is(WebCliHelper.BASIC_USERNAME));
	}

	@Test
	void test_getByCode() {
		String code = "FAMILTY";
		String path = String.format(PrtTest.MASTER_PUBLIC_PATH + "/relation-types/" + code);

		given(relationTypeV1Service.getByCode(Mockito.any(ReqContext.class), Mockito.anyString()))
				.willReturn(Optional.of(RelationTypeResponseV1.builder()
						.setCode(code)
						.setI18nCode("").build()
				));

		RelationTypeResponseV1 response = WebCliHelper.executeGet(EXT, path, null, WebCliHelper.BASIC_CREDENTIALS, RelationTypeResponseV1.class);
		ArgumentCaptor<ReqContext> reqCtxCaptor = ArgumentCaptor.forClass(ReqContext.class);
		verify(relationTypeV1Service, times(1))
				.getByCode(reqCtxCaptor.capture(), eq(code));

		ReqContext reqContext = reqCtxCaptor.getValue();
		assertThat(reqContext.getTenantId(), is("master"));
		assertThat(reqContext.getLang(), is("en"));
		assertThat(reqContext.getUsername(), is(WebCliHelper.BASIC_USERNAME));

		assertThat(response.getCode(), is(code));

	}

}
