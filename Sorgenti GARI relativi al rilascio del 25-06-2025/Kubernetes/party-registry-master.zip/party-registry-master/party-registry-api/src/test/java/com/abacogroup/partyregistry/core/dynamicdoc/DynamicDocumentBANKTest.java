package com.abacogroup.partyregistry.core.dynamicdoc;

import static com.abacogroup.partyregistry.core.dynamicdoc.DynamicDocumentUtils.createDoc;
import static org.hamcrest.CoreMatchers.containsString;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.hasSize;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.mock;

import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

import com.abacogroup.bundles.listener.tenant.TenantMessage;
import com.abacogroup.dropwizard.auth.sso2.Sso2Client;
import com.abacogroup.dynamicdocuments.bean.Document;
import com.abacogroup.dynamicdocuments.bean.InsertDocument;
import com.abacogroup.dynamicdocuments.exceptions.DocumentValidationException;
import com.abacogroup.dynamicdocuments.services.DocumentService;
import com.abacogroup.partyregistry.JdbiTest;
import com.abacogroup.partyregistry.api.PartyDocument;
import com.abacogroup.partyregistry.api.PartyRes;
import com.abacogroup.partyregistry.api.PartyTypeEnum;
import com.abacogroup.partyregistry.bundle.tenant.DynamicDocTenantMessageProcessor;
import com.abacogroup.partyregistry.core.DummySecurityContext;
import com.abacogroup.partyregistry.core.exceptions.AbstractPartyException;
import com.abacogroup.partyregistry.core.impl.PartyServiceImpl;
import com.abacogroup.partyregistry.resources.req.DocumentSearchReq;
import com.abacogroup.partyregistry.resources.req.PartyCreateReq;
import com.abacogroup.partyregistry.resources.req.ReqContext;

import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;
import lombok.SneakyThrows;

@ExtendWith(DropwizardExtensionsSupport.class)
public class DynamicDocumentBANKTest extends JdbiTest {

	private static final String NO_EXTERNAL_SOURCE_CODE = null;
	
	private static final ReqContext reqContext = new ReqContext("some_tenant", "user", "it");
	private final PartyDynamicDocumentManager partyDynamicDocumentManager = this.getService(PartyDynamicDocumentManagerImpl.class);
	private final DynamicDocTenantMessageProcessor dynamicDocTenantMessageProcessor = getService(DynamicDocTenantMessageProcessor.class);

	@BeforeEach
	@SneakyThrows
	void setUp() {
		DocumentService documentService = this.getService(DocumentService.class);
		var sso2Client = mock(Sso2Client.class);
		given(sso2Client.createSecurityContextFromUserName(anyString(), anyString()))
				.willAnswer(invocationOnMock -> new DummySecurityContext(invocationOnMock.getArgument(0), invocationOnMock.getArgument(1)));

		this.injectMock(documentService, sso2Client);
		this.injectMock(partyDynamicDocumentManager, documentService);
	}

	@Test
	@Disabled
	void testInsertId() {

		getJdbi().useHandle(handle -> {
			handle.begin();

			PartyCreateReq massiveDynReq = (PartyCreateReq) new PartyCreateReq()
					.setPartyType(PartyTypeEnum.L)
					.setLastName("Massive Dynamic".toUpperCase());

			PartyRes party = this.getService(PartyServiceImpl.class).insert(reqContext, massiveDynReq, NO_EXTERNAL_SOURCE_CODE);

			dynamicDocTenantMessageProcessor
					.onMessage(new TenantMessage()
							.setTenantId(reqContext.getTenantId())
					);
			Long partyId = party.getId();

			//-------

			Map<String, Object> passaporto = Map.of(
					//"bank_name", "REQUIRED",
					//"iban", "IT16T0200809440000004925167",
					"cuc", "optional",
					"cod_sia", "optional",
					"swift", "optional"
			);
			Document doc = new Document();
			Map<String, Object> fields = createDoc(passaporto);
			doc.setFields(fields);
			InsertDocument insertDocument = new InsertDocument();
			insertDocument.setDoc(doc);
			insertDocument.setBusinessId(partyId);

			DocumentValidationException ex = Assertions.assertThrows(DocumentValidationException.class, () -> {
				partyDynamicDocumentManager
						.save(reqContext, partyId, PartyDynamicDocumentManager.TYPE_BANK_DATA, insertDocument);
			});
			assertThat(ex.getMessage(), containsString("field bank_name is required"));
			DynamicDocumentUtils.updateField(doc, "bank_name", "CITI");

			ex = Assertions.assertThrows(DocumentValidationException.class, () -> {
				partyDynamicDocumentManager
						.save(reqContext, partyId, PartyDynamicDocumentManager.TYPE_BANK_DATA, insertDocument);
			});
			assertThat(ex.getMessage(), containsString("field iban is required"));
			DynamicDocumentUtils.updateField(doc, "iban", "LOLLIBAN");

			AbstractPartyException invalidDocumentException = Assertions.assertThrows(AbstractPartyException.class, () -> {
				partyDynamicDocumentManager
						.save(reqContext, partyId, PartyDynamicDocumentManager.TYPE_BANK_DATA, insertDocument);
			});
			assertThat(invalidDocumentException.getMessage(), containsString("Invalid iban"));
			DynamicDocumentUtils.updateField(doc, "iban", "IT16T0200809440000004925167");

			PartyDocument prtId = partyDynamicDocumentManager
					.save(reqContext, partyId, PartyDynamicDocumentManager.TYPE_BANK_DATA, insertDocument);

			DocumentSearchReq documentSearchReq = new DocumentSearchReq().setPartyId(partyId).setDefinitionCode(PartyDynamicDocumentManager.TYPE_BANK_DATA);
			List<PartyDocument> docs = partyDynamicDocumentManager
					.searchByDocType(reqContext, documentSearchReq, null).getRecords();
			assertThat(docs, hasSize(1));

			PartyDocument prtId2 = partyDynamicDocumentManager
					.save(reqContext, partyId, PartyDynamicDocumentManager.TYPE_BANK_DATA, insertDocument);

			assertThat("multiple", partyDynamicDocumentManager
							.searchByDocType(reqContext, documentSearchReq, null).getRecords(),
					hasSize(2));

			partyDynamicDocumentManager.expire(reqContext, partyId, prtId2.getDocumentId());

			assertThat("one expired, one ok",
					partyDynamicDocumentManager.searchByDocType(reqContext, documentSearchReq, null).getRecords(),
					hasSize(1));

			//-------------
			handle.rollback();
		});
	}
}
