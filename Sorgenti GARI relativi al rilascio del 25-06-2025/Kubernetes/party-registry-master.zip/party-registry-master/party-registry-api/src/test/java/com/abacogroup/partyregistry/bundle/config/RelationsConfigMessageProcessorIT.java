package com.abacogroup.partyregistry.bundle.config;

import static org.hamcrest.Matchers.containsInAnyOrder;

import java.nio.file.Path;
import java.util.List;
import java.util.Map;
import java.util.function.Supplier;

import org.hamcrest.CoreMatchers;
import org.hamcrest.MatcherAssert;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

import com.abacogroup.bundles.initializer.impl.FileSupport;
import com.abacogroup.bundles.listener.configdata.ConfigDataMessage;
import com.abacogroup.partyregistry.JdbiTest;

import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@ExtendWith(DropwizardExtensionsSupport.class)
class RelationsConfigMessageProcessorIT extends JdbiTest {
	private static final String TENANT_ID = RelationsConfigMessageProcessorIT.class.getSimpleName() + "_t";
	private static final String CURRENT_USER = RelationsConfigMessageProcessorIT.class.getSimpleName() + "_u";

	private static final Map<String, Object> testScriptParams = Map.of(
			"test_tenant", TENANT_ID,
			"user_id", CURRENT_USER
	);

	private final RelationsConfigMessageProcessor processor = getService(RelationsConfigMessageProcessor.class);

	private final Supplier<Path> bundlePath = () -> Path.of(
			"src/test/resources",
			(this.getClass().getName() + "." + processor.getDomainName()).replaceAll("\\.", "/"));

	@Test
	@SneakyThrows
	void given_delete_files_process_bundle() {
		ConfigDataMessage msg = new ConfigDataMessage();
		msg.setTenantId(TENANT_ID);

		List<Path> paths = FileSupport.listFilesRecursive(bundlePath.get());
		msg.setConfigFiles(paths);

		getJdbi().useHandle(handle -> {
			handle.begin();

			List<String> initScripts = List.of("add_relation_types", "add_relation_roles");
			execSqlFiles(this.getClass(), initScripts, testScriptParams);

			List<Long> actualRelationTypes = handle.select(
							"select id from prt_relation_types"
									+ " where tenant_id = ?"
									+ " AND CURRENT_TIMESTAMP between dt_insert and dt_delete", TENANT_ID)
					.mapTo(Long.class)
					.list();
			MatcherAssert.assertThat(actualRelationTypes.size(), CoreMatchers.is(4));
			MatcherAssert.assertThat(actualRelationTypes, containsInAnyOrder(-11l, -12l, -13l, -14l));

			List<Long> actualRelationRoles = handle.select(
							"select r.id from prt_relation_roles r "
									+ " inner join prt_relation_types t on t.id = r.type_id "
									+ " where t.tenant_id= ?"
									+ " and CURRENT_TIMESTAMP between r.dt_insert and r.dt_delete", TENANT_ID)
					.mapTo(Long.class)
					.list();
			MatcherAssert.assertThat(actualRelationRoles.size(), CoreMatchers.is(6));
			MatcherAssert.assertThat(actualRelationRoles, containsInAnyOrder(-22l, -23l, -24l, -25l, -26l, -27l));

			// process the bundle
			processor.onMessage(msg);

			//asserts
			List<Long> typesDeleted = handle.select(
							"select id from prt_relation_types "
									+ "where tenant_id = ?"
									+ "AND CURRENT_TIMESTAMP > dt_delete", TENANT_ID)
					.mapTo(Long.class)
					.list();
			MatcherAssert.assertThat(typesDeleted.size(), CoreMatchers.is(2));
			MatcherAssert.assertThat(typesDeleted, containsInAnyOrder(-11l, -14l));

			List<Long> rolesDeleted = handle.select(
							"select r.id from prt_relation_roles r "
									+ " inner join prt_relation_types t on t.id = r.type_id "
									+ " where t.tenant_id= ?"
									+ " and CURRENT_TIMESTAMP > r.dt_delete", TENANT_ID)
					.mapTo(Long.class)
					.list();
			MatcherAssert.assertThat(rolesDeleted.size(), CoreMatchers.is(3));
			MatcherAssert.assertThat(rolesDeleted, containsInAnyOrder(-24l, -25l, -27l));

			handle.rollback();
		});
	}

}
