package com.abacogroup.partyregistry.resources.publicapis;

import static com.abacogroup.partyregistry.PrtTest.TENANT_DEFAULT_CODE;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.jdbi.paging.impl.InfiniteListResultsImpl;
import com.abacogroup.partyregistry.PrtTest;
import com.abacogroup.partyregistry.api.PartyRelation;
import com.abacogroup.partyregistry.api.PartyRelationParty;
import com.abacogroup.partyregistry.api.v1.PartyRelationPartyResponseV1;
import com.abacogroup.partyregistry.core.AclService;
import com.abacogroup.partyregistry.core.PartyRelationPartyService;
import com.abacogroup.partyregistry.core.impl.PartyRelationPartyServiceImpl;
import com.abacogroup.partyregistry.resources.WebCliHelper;
import com.abacogroup.partyregistry.resources.req.PartyRelationPartySearchReq;
import com.abacogroup.partyregistry.resources.req.ReqContext;
import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;
import io.dropwizard.testing.junit5.ResourceExtension;
import jakarta.ws.rs.core.GenericType;
import jakarta.ws.rs.core.UriBuilder;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.assertj.core.api.Assertions;
import org.hamcrest.Matchers;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mockito;

@ExtendWith(DropwizardExtensionsSupport.class)
class PartyRelationPartiesPublicResourceTest {

	private final AclService aclService = Mockito.mock(AclService.class);
	private final PartyRelationPartyService partyRelationPartyService = Mockito.mock(PartyRelationPartyServiceImpl.class);

	private final PartyRelationPartiesPublicResource resource = new PartyRelationPartiesPublicResource(aclService, partyRelationPartyService);
	private final ResourceExtension EXT = WebCliHelper.createEXT(resource);

	// ----- search -----
	@Test
	void test_search_ok() {

		Long partyId = PrtTest.PARTY999;
		Long partyRelationId = 123L;

		var request = new PartyRelationPartySearchReq();

		var mockRes = PartyRelationParty.builder()
				.setPkid(11111L)
				.setPartyRelationId(partyRelationId)
				.setRelatedPartyId(555L)
				.setFirstName("First")
				.setLastName("Last")
				.setRelationRoleId(456L)
				.setDtStart(AbsoluteDate.of("19700101"))
				.setDtEnd(AbsoluteDate.of("99991231"))
				.setRelationTypeId(22222L)
				.setPartyRelationPartyId(partyId)
				.setRelatedRoleCode("ROLE")
				.setRelationRoleI18nCode("Role")
				.setRelationTypeCode("TYPE")
				.setRelationTypeI18nCode("Type")
				.setPartyRelation(PartyRelation.builder()
						.setId(22222L)
						.setPartyId(partyId)
						.setRelationTypeCode("TYPE")
						.setRelationTypeI18nCode("Type")
						.setNote("note")
						.build())
				.build();
		given(partyRelationPartyService.search(any(), anyLong(), anyLong(), any(), any()))
				.willReturn(new InfiniteListResultsImpl<>(List.of(mockRes), null));

		Map<String, Object> queryMap = new HashMap<>();
		queryMap.put("nextKey", "111");

		UriBuilder uriBuilder = UriBuilder.fromResource(resource.getClass());//.path(resource.getClass(), "search");
		queryMap.forEach(uriBuilder::queryParam);
		String uri = uriBuilder.build(TENANT_DEFAULT_CODE, partyId, partyRelationId).toString();
		System.out.println(uri);

		InfiniteListResultsImpl<PartyRelationPartyResponseV1> res = EXT.getJerseyTest().client()
				.target(UriBuilder.fromUri(uri))
				.request()
				.header("Authorization", WebCliHelper.BASIC_CREDENTIALS)
				.get(new GenericType<>() {
				});

		Assertions.assertThat(res).isNotNull()
				.extracting(InfiniteListResults::getRecords)
				.asList().hasSize(1)
				.element(0)
				.usingRecursiveComparison()
				.isEqualTo(mockRes);

		ArgumentCaptor<ReqContext> reqCtxCaptor = ArgumentCaptor.forClass(ReqContext.class);
		verify(partyRelationPartyService, times(1)).
				search(reqCtxCaptor.capture(), eq(partyId), eq(partyRelationId), eq(request), eq("111"));

		ReqContext reqContext = reqCtxCaptor.getValue();
		assertThat(reqContext.getTenantId(), Matchers.is("master"));
		assertThat(reqContext.getLang(), Matchers.is("en"));
		assertThat(reqContext.getUsername(), Matchers.is(WebCliHelper.BASIC_USERNAME));

	}
}
