package com.abacogroup.partyregistry.resources;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.jdbi.paging.impl.InfiniteListResultsImpl;
import com.abacogroup.partyregistry.PrtTest;
import com.abacogroup.partyregistry.api.PartyRelation;
import com.abacogroup.partyregistry.api.PartyRelationParty;
import com.abacogroup.partyregistry.core.AclService;
import com.abacogroup.partyregistry.core.PartyRelationPartyService;
import com.abacogroup.partyregistry.core.impl.PartyRelationPartyServiceImpl;
import com.abacogroup.partyregistry.resources.req.PartyRelationPartySearchReq;
import com.abacogroup.partyregistry.resources.req.ReqContext;
import com.abacogroup.partyregistry.resources.req.rel.PartyRelationItemReq;
import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;
import io.dropwizard.testing.junit5.ResourceExtension;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import org.hamcrest.Matchers;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mockito;

@ExtendWith(DropwizardExtensionsSupport.class)
public class PartyRelationPartiesResourceTest {

	private final AclService aclService = Mockito.mock(AclService.class);
	private final PartyRelationPartyService partyRelationPartyService = Mockito.mock(PartyRelationPartyServiceImpl.class);

	private final ResourceExtension EXT = WebCliHelper
			.createEXT(new PartyRelationPartiesResource(aclService, partyRelationPartyService));

	@Test
	void test_list() {
		String path = String.format(PrtTest.MASTER_PATH + "/parties/1/relation-types/2/relations");

		PartyRelationPartySearchReq searchRequest = new PartyRelationPartySearchReq();
		//    ObjectMapper mapper = new ObjectMapper();
		//    Map<String, Object> beanMap = mapper.convertValue(searchRequest, Map.class);
		Map<String, Object> beanMap = new HashMap<>();

		InfiniteListResults<PartyRelationParty> ignored = WebCliHelper.executeGet(EXT, path, beanMap,
				WebCliHelper.BASIC_CREDENTIALS, InfiniteListResultsImpl.class);

		ArgumentCaptor<ReqContext> reqCtxCaptor = ArgumentCaptor.forClass(ReqContext.class);
		ArgumentCaptor<PartyRelationPartySearchReq> requestArgumentCaptor = ArgumentCaptor.forClass(
				PartyRelationPartySearchReq.class);
		verify(partyRelationPartyService, times(1))
				.search(
						reqCtxCaptor.capture(),
						eq(1L), eq(2L), eq(searchRequest),
						eq(null)
				);

		ReqContext reqContext = reqCtxCaptor.getValue();
		assertThat(reqContext.getTenantId(), Matchers.is(PrtTest.TENANT_DEFAULT_CODE));
		assertThat(reqContext.getLang(), Matchers.is("en"));
		assertThat(reqContext.getUsername(), Matchers.is(WebCliHelper.BASIC_USERNAME));

		//    PartyRelationPartySearchReq req = requestArgumentCaptor.getValue();
	}

	@Test
	void test_get_1() {
		String path = String.format(PrtTest.MASTER_PATH + "/parties/1/relation-types/2/relations/3");

		given(partyRelationPartyService.getRelationPartyById(Mockito.any(ReqContext.class), anyLong(), anyLong(), anyLong()))
				.willReturn(Optional.of(PartyRelationParty.builder()
						.setRelatedPartyId(1L)
						.setPartyRelation(PartyRelation.builder().build())
						.setDtStart(AbsoluteDate.of(LocalDateTime.now()))
						.setDtEnd(AbsoluteDate.of(LocalDateTime.now()))
						.build()
				));

		String res = WebCliHelper.executeGet(EXT, path, null,
				WebCliHelper.BASIC_CREDENTIALS, String.class);

		System.out.println(res);

		String regExp = ".*\"dtStart\":\"\\d{8}\".*";
		assertThat("deve contenere una stringa dtStart con un valore di 8 caratteri", res.matches(regExp));

		ArgumentCaptor<ReqContext> reqCtxCaptor = ArgumentCaptor.forClass(ReqContext.class);

		verify(partyRelationPartyService, times(1))
				.getRelationPartyById(
						reqCtxCaptor.capture(),
						eq(1L), eq(2L), eq(3L)
				);
		ReqContext reqContext = reqCtxCaptor.getValue();
		assertThat(reqContext.getTenantId(), Matchers.is(PrtTest.TENANT_DEFAULT_CODE));
		assertThat(reqContext.getLang(), Matchers.is("en"));
		assertThat(reqContext.getUsername(), Matchers.is(WebCliHelper.BASIC_USERNAME));

	}

	@Test
	void test_add_relation() {
		String path = String.format(PrtTest.MASTER_PATH + "/parties/1/relation-types/2/relations");

		long otherParty = 3L;
		PartyRelationItemReq partyRelationItemReq = new PartyRelationItemReq()
				.setRelatedPartyId(otherParty)
				.setDtStart(AbsoluteDate.of("20211202"))
				.setRelatedRoleCode("THIS_ROLE_BELONGS_TO_2_RELATION-TYPE_ROLES");

		WebCliHelper.executePost(EXT, path, partyRelationItemReq, WebCliHelper.BASIC_CREDENTIALS,
				PartyRelation.class);

		ArgumentCaptor<PartyRelationItemReq> argumentCaptor =
				ArgumentCaptor.forClass(PartyRelationItemReq.class);

		ArgumentCaptor<ReqContext> reqCtxCaptor = ArgumentCaptor.forClass(ReqContext.class);
		verify(partyRelationPartyService, times(1))
				.insert(
						reqCtxCaptor.capture(),
						eq(1L),
						eq(2L),
						argumentCaptor.capture());

		PartyRelationItemReq in = argumentCaptor.getValue();
		assertThat(in, is(notNullValue()));

		ReqContext reqContext = reqCtxCaptor.getValue();
		assertThat(reqContext.getTenantId(), Matchers.is(PrtTest.TENANT_DEFAULT_CODE));
		assertThat(reqContext.getLang(), Matchers.is("en"));
		assertThat(reqContext.getUsername(), Matchers.is(WebCliHelper.BASIC_USERNAME));
	}

	@Test
	void test_update_relation() {
		String path = String.format(PrtTest.MASTER_PATH + "/parties/1/relation-types/2/relations/3");

		long otherParty = 4L;
		PartyRelationItemReq partyRelationItemReq = new PartyRelationItemReq()
				.setRelatedPartyId(otherParty)
				.setDtStart(AbsoluteDate.of("20211202"))
				.setRelatedRoleCode("THIS_ROLE_BELONGS_TO_2_RELATION-TYPE_ROLES");

		WebCliHelper.executePut(EXT, path, partyRelationItemReq, WebCliHelper.BASIC_CREDENTIALS,
				PartyRelation.class);

		ArgumentCaptor<PartyRelationItemReq> argumentCaptor =
				ArgumentCaptor.forClass(PartyRelationItemReq.class);

		ArgumentCaptor<ReqContext> reqCtxCaptor = ArgumentCaptor.forClass(ReqContext.class);

		verify(partyRelationPartyService, times(1))
				.update(
						reqCtxCaptor.capture(),
						eq(1L),
						eq(2L),
						eq(3L),
						argumentCaptor.capture());

		PartyRelationItemReq in = argumentCaptor.getValue();

		ReqContext reqContext = reqCtxCaptor.getValue();
		assertThat(reqContext.getTenantId(), is(PrtTest.TENANT_DEFAULT_CODE));
		assertThat(reqContext.getLang(), is("en"));
		assertThat(reqContext.getUsername(), is(WebCliHelper.BASIC_USERNAME));
	}

	@Test
	void test_expire_relation() {
		String path = String.format(PrtTest.MASTER_PATH + "/parties/1/relation-types/2/relations/3");

		long otherParty = 4L;
		PartyRelationItemReq partyRelationItemReq = new PartyRelationItemReq()
				.setRelatedPartyId(otherParty)
				.setDtStart(AbsoluteDate.of("20211202"))
				.setRelatedRoleCode("THIS_ROLE_BELONGS_TO_2_RELATION-TYPE_ROLES");

		WebCliHelper.executeDelete(EXT, path, WebCliHelper.BASIC_CREDENTIALS,
				PartyRelation.class);

		ArgumentCaptor<ReqContext> reqCtxCaptor = ArgumentCaptor.forClass(ReqContext.class);
		verify(partyRelationPartyService, times(1))
				.expireRelationParty(
						reqCtxCaptor.capture(),
						eq(1L),
						eq(2L),
						eq(3L));

		ReqContext reqContext = reqCtxCaptor.getValue();
		assertThat(reqContext.getTenantId(), is(PrtTest.TENANT_DEFAULT_CODE));
		assertThat(reqContext.getLang(), is("en"));
		assertThat(reqContext.getUsername(), is(WebCliHelper.BASIC_USERNAME));
	}

}



