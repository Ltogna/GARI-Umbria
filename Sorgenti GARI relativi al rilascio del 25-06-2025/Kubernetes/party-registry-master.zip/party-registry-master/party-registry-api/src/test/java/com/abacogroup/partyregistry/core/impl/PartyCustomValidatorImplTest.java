package com.abacogroup.partyregistry.core.impl;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anySet;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.BDDMockito.given;
import static org.mockito.BDDMockito.willThrow;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;

import com.abacogroup.partyregistry.core.PartyCustomValidator;
import com.abacogroup.partyregistry.core.PartyFieldValidator;
import com.abacogroup.partyregistry.core.exceptions.ErrCodes;
import com.abacogroup.partyregistry.core.exceptions.InvalidPartyException;
import com.abacogroup.partyregistry.db.dao.AppConfigDAO;
import com.abacogroup.partyregistry.db.ntt.AppConfigEntity;
import com.abacogroup.partyregistry.db.ntt.PartyEntity;
import java.util.List;
import java.util.Set;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class PartyCustomValidatorImplTest {

	public static final String TENANT = "test_tenant";
	private PartyFieldValidator pfv1 = mock(PartyFieldValidator.class);
	private PartyFieldValidator pfv2 = mock(PartyFieldValidator.class);
	private PartyFieldValidator pfv3 = mock(PartyFieldValidator.class);

	private AppConfigDAO appConfigDAO = mock(AppConfigDAO.class);

	private PartyCustomValidator partyCustomValidator;

	@BeforeEach
	void setUp() {
		given(pfv1.getFieldName()).willReturn("field1");
		given(pfv2.getFieldName()).willReturn("field2");
		given(pfv3.getFieldName()).willReturn("field3");

		partyCustomValidator = new PartyCustomValidatorImpl(appConfigDAO, List.of(pfv1, pfv2, pfv3));
	}

	// ----- validateOnInsert -----
	@Test
	void test_validateOnInsert_ok() {
		PartyEntity party = new PartyEntity();
		AppConfigEntity pvc1 = AppConfigEntity.builder().setConfigurationKey("field1").build();
		AppConfigEntity pvc3 = AppConfigEntity.builder().setConfigurationKey("field3").build();
		given(appConfigDAO.findByConfigKeyIn(anyString(), anySet())).willReturn(List.of(pvc1, pvc3));

		partyCustomValidator.validateOnInsert(party, TENANT);

		verify(appConfigDAO).findByConfigKeyIn(TENANT, Set.of("field1", "field2", "field3"));
		verify(pfv1).validateOnInsert(party, pvc1);
		verify(pfv3).validateOnInsert(party, pvc3);
		verify(pfv2).resetField(party);

	}

	@Test
	void test_validateOnInsert_error() {
		PartyEntity party = new PartyEntity();
		AppConfigEntity pvc1 = AppConfigEntity.builder().setConfigurationKey("field1").build();
		AppConfigEntity pvc3 = AppConfigEntity.builder().setConfigurationKey("field3").build();
		given(appConfigDAO.findByConfigKeyIn(anyString(), anySet())).willReturn(List.of(pvc1, pvc3));
		InvalidPartyException partyException = new InvalidPartyException(ErrCodes.INVALID_PAYLOAD, "field3 error");
		willThrow(partyException).given(pfv3).validateOnInsert(any(), any());

		InvalidPartyException exception = assertThrows(InvalidPartyException.class, () -> partyCustomValidator.validateOnInsert(party, TENANT));

		assertThat(exception).isSameAs(partyException);
		verify(appConfigDAO).findByConfigKeyIn(TENANT, Set.of("field1", "field2", "field3"));
		verify(pfv1).validateOnInsert(party, pvc1);
		verify(pfv3).validateOnInsert(party, pvc3);

	}

	// ----- validateOnUpdate -----
	@Test
	void test_validateOnUpdate_ok() {
		PartyEntity party = new PartyEntity();
		AppConfigEntity pvc1 = AppConfigEntity.builder().setConfigurationKey("field1").build();
		AppConfigEntity pvc2 = AppConfigEntity.builder().setConfigurationKey("field2").build();
		given(appConfigDAO.findByConfigKeyIn(anyString(), anySet())).willReturn(List.of(pvc1, pvc2));

		partyCustomValidator.validateOnUpdate(party, TENANT);

		verify(appConfigDAO).findByConfigKeyIn(TENANT, Set.of("field1", "field2", "field3"));
		verify(pfv1).validateOnUpdate(party, pvc1);
		verify(pfv2).validateOnUpdate(party, pvc2);
		verify(pfv3).resetField(party);
	}
}
