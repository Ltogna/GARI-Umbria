package com.abacogroup.partyregistry.bundle.config;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.nullValue;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.argThat;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import java.nio.file.Path;
import java.util.Optional;
import java.util.concurrent.atomic.AtomicLong;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;

import com.abacogroup.bundles.initializer.impl.exceptions.BundleException;
import com.abacogroup.dynamicdocuments.bean.InsertDocument;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.partyregistry.api.GenderEnum;
import com.abacogroup.partyregistry.api.PartyDocument;
import com.abacogroup.partyregistry.api.PartyRelation;
import com.abacogroup.partyregistry.api.PartyRelationParty;
import com.abacogroup.partyregistry.api.PartyRes;
import com.abacogroup.partyregistry.api.PartyTypeEnum;
import com.abacogroup.partyregistry.bundle.config.PartyConfigMessageProcessor.EntryType;
import com.abacogroup.partyregistry.bundle.config.PartyConfigMessageProcessor.PartyDynDocEntry;
import com.abacogroup.partyregistry.bundle.config.PartyConfigMessageProcessor.PartyEntry;
import com.abacogroup.partyregistry.bundle.config.PartyConfigMessageProcessor.PartyRelationEntry;
import com.abacogroup.partyregistry.bundle.config.PartyConfigMessageProcessor.PartyRelationsEntry;
import com.abacogroup.partyregistry.bundle.config.PartyConfigMessageProcessor.PartyTagEntry;
import com.abacogroup.partyregistry.core.PartyRelationPartyService;
import com.abacogroup.partyregistry.core.PartyRelationService;
import com.abacogroup.partyregistry.core.dynamicdoc.PartyDynamicDocumentManager;
import com.abacogroup.partyregistry.core.dynamicdoc.PartyDynamicDocumentManagerImpl;
import com.abacogroup.partyregistry.core.impl.PartyRelationPartyServiceImpl;
import com.abacogroup.partyregistry.core.impl.PartyRelationServiceImpl;
import com.abacogroup.partyregistry.core.impl.PartyServiceImpl;
import com.abacogroup.partyregistry.resources.req.PartyCreateReq;
import com.abacogroup.partyregistry.resources.req.ReqContext;
import com.abacogroup.partyregistry.resources.req.rel.CreatePartyRelationReq;
import com.abacogroup.partyregistry.resources.req.rel.PartyRelationItemReq;

import lombok.extern.slf4j.Slf4j;

@Slf4j
class PartyConfigMessageProcessorSimpleTest {

	private final PartyServiceImpl partyServiceMock = mock(PartyServiceImpl.class);
	private final PartyRelationService partyRelationServiceMock = mock(PartyRelationServiceImpl.class);
	private final PartyRelationPartyService partyRelationPartyServiceMock = mock(PartyRelationPartyServiceImpl.class);
	private final PartyDynamicDocumentManager partyDynamicDocumentManagerMock = mock(PartyDynamicDocumentManagerImpl.class);

	private final PartyConfigMessageProcessor processor = new PartyConfigMessageProcessor(partyServiceMock, partyRelationServiceMock,
			partyRelationPartyServiceMock, partyDynamicDocumentManagerMock);

	@Test
	void testMapParty() {
		String body =
				"{ \"_type\": \"PARTY\", \"_id\": \"mario_rossi_1\",  \"partyType\" : \"N\", \"gender\" : \"M\", \"lastName\" : \"ROSSI\", \"firstName\" : \"MARIO\", \"taxCode\" : \"RSSMRA80A01H501U\", \"vatNumber\" : \"86334519757\", \"birthDate\" : \"19800101\", \"nationality\" : \"AUT\", \"birthCountry\" : \"ITA\", \"birthRegion\" : \"ITA_12\", \"birthDistrict\" : \"ITA_12_058\", \"birthMunicipality\" : \"ITA_12_058091\" } \n"
						+
						"{ \"_type\": \"PARTY\", \"id\": 10,  \"partyType\" : \"N\", \"gender\" : \"M\", \"lastName\" : \"VERDI\", \"firstName\" : \"GIUSEPPE\", \"taxCode\" : \"VRDGPP85E05C294Z\", \"vatNumber\" : \"39517120125\", \"birthDate\" : \"19850505\", \"nationality\" : \"GBR\", \"birthCountry\" : \"ITA\", \"birthRegion\" : \"ITA_12\", \"birthDistrict\" : \"ITA_02_007\", \"birthMunicipality\" : \"ITA_02_007020\" } \n "
						+
						"{ \"_type\": \"PARTY\", \"partyType\" : \"N\", \"gender\" : \"M\", \"lastName\" : \"ROSSI\", \"firstName\" : \"MARIO\", \"taxCode\" : \"RSSMRA80A01H501U\", \"vatNumber\" : \"86334519757\", \"birthDate\" : \"19800101\", \"nationality\" : \"AUT\", \"birthCountry\" : \"ITA\", \"birthRegion\" : \"ITA_12\", \"birthDistrict\" : \"ITA_12_058\", \"birthMunicipality\" : \"ITA_12_058091\" }";

		String[] bodies = body.split("\n");

		PartyEntry line1 = (PartyEntry) processor.mapEntry("x", bodies[0]);
		assertThat(line1.getEntryType(), is(EntryType.PARTY));
		assertThat(line1.getId(), nullValue());
		assertThat(line1.getFlyId(), is("mario_rossi_1"));
		assertThat(line1.getPartyType(), is(PartyTypeEnum.N));
		assertThat(line1.getGender(), is(GenderEnum.M));
		assertThat(line1.getLastName(), is("ROSSI"));
		assertThat(line1.getFirstName(), is("MARIO"));
		assertThat(line1.getTaxCode(), is("RSSMRA80A01H501U"));
		assertThat(line1.getVatNumber(), is("86334519757"));
		assertThat(line1.getBirthDate(), is(AbsoluteDate.of("19800101")));
		assertThat(line1.getBirthMunicipality(), is("ITA_12_058091"));
		assertThat(line1.getNationality(), is("AUT"));
		assertThat(line1.isArchived(), is(false));

		BundleException ex = Assertions.assertThrows(BundleException.class, () -> {
			PartyEntry line2 = (PartyEntry) processor.mapEntry("x", bodies[2]);
		});
	}

	@Test
	void testMapTags() {
		String body =
				"{\"_type\": \"PARTY_TAGS\" , \"party_ref\": \"mario_rossi_1\", \"code\":\"BUG\"}\n"
						+ "{\"_type\": \"PARTY_TAGS\" , \"party_id\": 10, \"code\":\"BUG\"}";

		String[] bodies = body.split("\n");

		PartyTagEntry line0 = (PartyTagEntry) processor.mapEntry("x", bodies[0]);
		assertThat(line0.getEntryType(), is(EntryType.PARTY_TAGS));
		assertThat(line0.getPartyRef(), is("mario_rossi_1"));
		assertThat(line0.getCode(), is("BUG"));

		PartyTagEntry line1 = (PartyTagEntry) processor.mapEntry("x", bodies[1]);
		assertThat(line1.getEntryType(), is(EntryType.PARTY_TAGS));
		assertThat(line1.getPartyRef(), is(nullValue()));
		assertThat(line1.getPartyId(), is(10L));
		assertThat(line1.getCode(), is("BUG"));

	}

	@Test
	void testMapRelations() {
		String body =
				"{\"_type\": \"PARTY_RELATIONS\", \"_id\":\"relazione_assetti_mario\", \"party_ref\": \"mario_rossi_1\" , \"relation_type\":\"ASSETTI_SOCIETARI\", \"note\":\"lorem ipsum\"}\n"
						+ "{\"_type\": \"PARTY_RELATIONS\", \"_id\":\"relazione_assetti_mario\", \"party_id\": 10 , \"relation_type\":\"ASSETTI_SOCIETARI\", \"note\":\"lorem ipsum\"}\n";

		String[] bodies = body.split("\n");

		PartyRelationsEntry line0 = (PartyRelationsEntry) processor.mapEntry("x", bodies[0]);
		assertThat(line0.getEntryType(), is(EntryType.PARTY_RELATIONS));
		assertThat(line0.getPartyRef(), is("mario_rossi_1"));
		assertThat(line0.getFlyId(), is("relazione_assetti_mario"));

		PartyRelationsEntry line1 = (PartyRelationsEntry) processor.mapEntry("x", bodies[1]);
		assertThat(line1.getEntryType(), is(EntryType.PARTY_RELATIONS));
		assertThat(line1.getPartyRef(), is(nullValue()));
		assertThat(line1.getPartyId(), is(10L));
		assertThat(line0.getFlyId(), is("relazione_assetti_mario"));
	}

	@Test
	void testMapRelation() {
		String body =
				"{\"_type\": \"PARTY_RELATION\" , \"relation_ref\":  \"relazione_assetti_mario\", \"role\": \"RAPPRESENTANTE_LEGALE\", \"party_ref\": \"mario_rossi_1\", \"dt_start\": \"19991225\"}\n"
						+ "{\"_type\": \"PARTY_RELATION\" , \"relation_id\":  22, \"role\": \"RAPPRESENTANTE_LEGALE\", \"party_id\": 10,  \"dt_start\": \"19991225\"}";

		String[] bodies = body.split("\n");

		PartyRelationEntry line0 = (PartyRelationEntry) processor.mapEntry("x", bodies[0]);
		assertThat(line0.getEntryType(), is(EntryType.PARTY_RELATION));
		assertThat(line0.getRole(), is("RAPPRESENTANTE_LEGALE"));

		assertThat(line0.getRelationRef(), is("relazione_assetti_mario"));
		assertThat(line0.getPartyRef(), is("mario_rossi_1"));
		assertThat(line0.getDtStart(), is("19991225"));

		PartyRelationEntry line1 = (PartyRelationEntry) processor.mapEntry("x", bodies[1]);

		assertThat(line1.getPartyId(), is(10L));
		assertThat(line1.getRelationId(), is(22L));
	}

	@Test
	void testMapDynDoc() {
		String body =
				"{\"_type\": \"DYN_DOC\",  \"party_ref\": \"mario_rossi_1\", \"doc\": {\"BANK\":{\"cuc\":[\"optional\"],\"cod_sia\":[\"optional\"],\"iban\":[\"IT16T0200809440000004925167\"],\"bank_name\":[\"CITI\"],\"swift\":[\"optional\"]}}}\n";

		String[] bodies = body.split("\n");

		PartyDynDocEntry line0 = (PartyDynDocEntry) processor.mapEntry("x", bodies[0]);
		assertThat(line0.getEntryType(), is(EntryType.DYN_DOC));
		assertThat(line0.getPartyRef(), is("mario_rossi_1"));
		assertThat(line0.getDefinitionCode(), is("BANK"));
		assertThat(line0.getFields().size(), is(5));
	}

	@Test
	void testInsert() {
		Long fakeId = 58_923L;
		given(partyServiceMock.insert(any(ReqContext.class), any(PartyCreateReq.class), any()))
				.willAnswer(invocationOnMock -> new PartyRes().setId(fakeId));

		given(partyRelationServiceMock.save(any(ReqContext.class), anyLong(), any(CreatePartyRelationReq.class)))
				.willAnswer(invocationOnMock -> PartyRelation.builder()
						.setId(fakeId)
						.setPartyId((long) invocationOnMock.getArgument(1).hashCode())
						.build()
				);

		given(partyRelationServiceMock.getRelationById(any(ReqContext.class), anyLong(), eq(22L)))
				.willAnswer(invocationOnMock ->
						Optional.of(PartyRelation.builder()
								.setId(invocationOnMock.getArgument(2))
								.setPartyId(100L)
								.build())
				);

		given(partyRelationPartyServiceMock.insert(any(ReqContext.class), anyLong(), eq(22L), any(PartyRelationItemReq.class)))
				.willAnswer(invocationOnMock -> PartyRelationParty.builder()
						.setPkid((long) invocationOnMock.getArgument(1).hashCode())
						.setRelatedPartyId(((PartyRelationItemReq) invocationOnMock.getArgument(3)).getRelatedPartyId())
						.setPartyRelationId(invocationOnMock.getArgument(2))
						.build()
				);
		given(partyRelationPartyServiceMock.insert(any(ReqContext.class), anyLong(), eq(fakeId), any(PartyRelationItemReq.class)))
				.willAnswer(invocationOnMock -> PartyRelationParty.builder()
						.setPkid((long) invocationOnMock.getArgument(1).hashCode())
						.setRelatedPartyId(((PartyRelationItemReq) invocationOnMock.getArgument(3)).getRelatedPartyId())
						.setPartyRelationId(invocationOnMock.getArgument(2))
						.build()
				);

		processor.addContent("lol", Path.of("src/test/resources/bundlesDev/party-registry/prt-7777/parties/parties.jsonl"));

		//TAGS
		verify(partyServiceMock, times(1))
				.attachTag(any(ReqContext.class), eq(10L), eq("DEV"));
		verify(partyServiceMock, times(1))
				.attachTag(any(ReqContext.class), anyLong(), eq("BUG"));

		//RELS
		verify(partyRelationServiceMock, times(1))
				.save(any(ReqContext.class), eq(10L),
						eq(new CreatePartyRelationReq()
								.setNote("lorem ipsum 2")
								.setRelationTypeCode("RIFERIMENTI_CONTATTI")
						));
		verify(partyRelationServiceMock, times(1))
				.save(any(ReqContext.class), anyLong(),
						eq(new CreatePartyRelationReq()
								.setNote("lorem ipsum")
								.setRelationTypeCode("ASSETTI_SOCIETARI")
						));

		//REL
		verify(partyRelationPartyServiceMock, times(1))
				.insert(any(ReqContext.class),
						eq(100L),
						eq(22L),
						eq(new PartyRelationItemReq()
								.setRelatedPartyId(12L)
								.setRelatedRoleCode("CONTATTO_TECNICO")
								.setDtStart(AbsoluteDate.of("19991225"))
								.setDtEnd(AbsoluteDate.of("99991231"))
						));
		verify(partyRelationPartyServiceMock, times(1))
				.insert(any(ReqContext.class),
						eq(fakeId),
						eq(fakeId),
						eq(new PartyRelationItemReq()
								.setRelatedPartyId(fakeId)
								.setRelatedRoleCode("RAPPRESENTANTE_LEGALE")
								.setDtStart(AbsoluteDate.of("19991225"))
						));
	}

	@Test
	void testInsertTags() {
		Long marioId = 58_923L;
		Long giovanniId = 610_00L;
		AtomicLong partyDocId = new AtomicLong(1);

		given(partyServiceMock.insert(any(ReqContext.class),
				argThat(argument -> argument.getLastName().equalsIgnoreCase("mario")), 
				any()))
			.willAnswer(invocationOnMock -> new PartyRes().setId(marioId));

		given(partyServiceMock.insert(any(ReqContext.class),
				argThat(argument -> argument.getLastName().equalsIgnoreCase("giovanni")), 
				any()))
				.willAnswer(invocationOnMock -> new PartyRes().setId(giovanniId));

		processor.addContent("lol", Path.of("src/test/resources/bundlesDev/party-registry/prt-7777/parties/parties_and_tags.jsonl"));

		ArgumentCaptor<PartyCreateReq> partyCreateRequestArgumentCaptor = ArgumentCaptor.forClass(PartyCreateReq.class);
		verify(partyServiceMock, times(2))
				.insert(any(ReqContext.class), partyCreateRequestArgumentCaptor.capture(), any());

		verify(partyServiceMock, times(1))
				.attachTag(any(ReqContext.class), eq(marioId), eq("BUG"));
		verify(partyServiceMock, times(1))
				.attachTag(any(ReqContext.class), eq(marioId), eq("DEV"));

		verify(partyServiceMock, times(1))
				.attachTag(any(ReqContext.class), eq(giovanniId), eq("DEV"));

		verify(partyServiceMock, times(1))
				.attachTag(any(ReqContext.class), eq(10L), eq("DEV"));

	}

	@Test
	@Disabled("TODO")
	void testInsertContacts() {
		Long marioId = 58_923L;
		Long giovanniId = 610_00L;
		AtomicLong partyDocId = new AtomicLong(1);

		given(partyServiceMock.insert(any(ReqContext.class),
				argThat(argument -> argument.getLastName().equalsIgnoreCase("mario")), 
				any()))
			.willAnswer(invocationOnMock -> new PartyRes().setId(marioId));

		given(partyServiceMock.insert(any(ReqContext.class),
				argThat(argument -> argument.getLastName().equalsIgnoreCase("giovanni")), 
				any()))
			.willAnswer(invocationOnMock -> new PartyRes().setId(giovanniId));

		processor.addContent("lol", Path.of("src/test/resources/bundlesDev/party-registry/prt-7777/parties/parties_and_contacts.jsonl"));

		ArgumentCaptor<PartyCreateReq> partyCreateRequestArgumentCaptor = ArgumentCaptor.forClass(PartyCreateReq.class);
		verify(partyServiceMock, times(2))
				.insert(any(ReqContext.class), partyCreateRequestArgumentCaptor.capture(), any());

		//fail();
	}

	@Test
	void testInsertDynamicDoc() {
		Long rossiId = 58_923L;
		Long verdiId = 610_00L;
		AtomicLong partyDocId = new AtomicLong(1);

		given(partyServiceMock.insert(any(ReqContext.class),
				argThat(argument -> argument.getLastName().equalsIgnoreCase("rossi")), 
				any()))
			.willAnswer(invocationOnMock -> new PartyRes().setId(rossiId));

		given(partyServiceMock.insert(any(ReqContext.class),
				argThat(argument -> argument.getLastName().equalsIgnoreCase("verdi")), 
				any()))
			.willAnswer(invocationOnMock -> new PartyRes().setId(verdiId));

		given(partyDynamicDocumentManagerMock.save(any(ReqContext.class), anyLong(), anyString(), any(InsertDocument.class)))
				.willAnswer(invocationOnMock -> PartyDocument.builder()
						.setPartyId(invocationOnMock.getArgument(1))
						.setDefinitionCode(invocationOnMock.getArgument(2))
						.setDocumentId(partyDocId.getAndIncrement())
						.build());

		processor.addContent("lol", Path.of("src/test/resources/bundlesDev/party-registry/prt-7777/parties/parties_and_dyndoc.jsonl"));

		//doc

		verify(partyDynamicDocumentManagerMock, times(11))
				.save(any(ReqContext.class), eq(rossiId), eq("BANK"), any(InsertDocument.class));

		verify(partyDynamicDocumentManagerMock, times(1))
				.save(any(ReqContext.class), eq(rossiId), eq("EINVOICING"), any(InsertDocument.class));

		ArgumentCaptor<InsertDocument> argumentCaptor = ArgumentCaptor.forClass(InsertDocument.class);
		verify(partyDynamicDocumentManagerMock, times(3))
				.save(any(ReqContext.class), eq(verdiId), eq("EINVOICING"), argumentCaptor.capture());

		InsertDocument insertDocument = argumentCaptor.getValue();
		//TODO asserts
		//System.out.println(insertDocument);
	}

}

