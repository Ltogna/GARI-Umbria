package com.abacogroup.partyregistry.core.impl;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.hasSize;
import static org.junit.jupiter.api.Assertions.assertThrows;

import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.partyregistry.JdbiTest;
import com.abacogroup.partyregistry.PrtTest;
import com.abacogroup.partyregistry.api.PartyRelation;
import com.abacogroup.partyregistry.api.PartyRelationParty;
import com.abacogroup.partyregistry.core.PartyRelationPartyService;
import com.abacogroup.partyregistry.core.exceptions.ErrCodes;
import com.abacogroup.partyregistry.core.exceptions.InvalidPartyRelationException;
import com.abacogroup.partyregistry.resources.req.PartyRelationPartySearchReq;
import com.abacogroup.partyregistry.resources.req.ReqContext;
import com.abacogroup.partyregistry.resources.req.rel.PartyRelationItemReq;
import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;

@Slf4j
@ExtendWith(DropwizardExtensionsSupport.class)
public
class PartyRelationPartyServiceImplTest extends JdbiTest {

	private static final String tenantId = "PartyRelationPartyServiceImplTest_t";
	private static final String currentUser = "delete_me";

	private static final ReqContext reqContext = new ReqContext(tenantId, currentUser, "en");

	private static final Map<String, Object> testScriptParams = Map.of(
			"test_tenant", tenantId,
			"user_id", currentUser
	);

	private final PartyRelationPartyService service = getService(PartyRelationPartyServiceImpl.class);

	@BeforeAll
	@AfterAll
	public static void beforeAll() {
		List<String> initScripts = List.of("rollback");
		execSqlFiles(PrtTest.class, initScripts, testScriptParams);
	}

	@Test
	void test_load() {

		getJdbi().useHandle(handle -> {
			handle.begin();

			setUnusedBindingAllowed(true);
			List<String> initScripts = List.of("prp");
			execSqlFiles(this.getClass(), initScripts, testScriptParams);

			PartyRelationParty prp = this.service.getRelationPartyById(reqContext, -1L, -889L, -2003L).orElseThrow();
			assertThat(prp.getPkid(), is(-2003L));
			assertThat(prp.getRelatedPartyId(), is(-5L));
			assertThat(prp.getFirstName(), is("SPA"));
			assertThat(prp.getLastName(), is("REALT_TECHNOLOGY"));

			PartyRelation partyRelation = prp.getPartyRelation();
			assertThat(partyRelation.getId(), is(-889L));
			assertThat(partyRelation.getPartyId(), is(-1L));
			assertThat(partyRelation.getPartyId(), is(-1L));
			assertThat(partyRelation.getNote(), is("Azienda in cui realt è assunto"));

			assertThat(partyRelation.getRelationTypeCode(), is("AZIENDA"));

			assertThat(prp.getRelatedRoleCode(), is("SORELLA"));

			handle.rollback();
		});

	}

	@ParameterizedTest
	@MethodSource
	void test_search(String ignoredTitle, Long partyId, Long relationId, PartyRelationPartySearchReq request, int results) {

		getJdbi().useHandle(handle -> {
			handle.begin();

			setUnusedBindingAllowed(true);
			List<String> initScripts = List.of("prp");
			execSqlFiles(this.getClass(), initScripts, testScriptParams);

			List<PartyRelationParty> list = this.service.search(reqContext, partyId, relationId, request, null)
					.getRecords();
			List<Long> actual = list.stream()
					.map(PartyRelationParty::getPkid)
					.peek(System.out::println)
					.collect(Collectors.toList());
			assertThat(actual, hasSize(results));

			handle.rollback();
		});

	}

	private static Stream<Arguments> test_search() {
		return Stream.of(
				Arguments.of("search_by_partyId", -1L, -879L, new PartyRelationPartySearchReq(), 1),
				Arguments.of("search_by_partyId 2", -1L, -889L, new PartyRelationPartySearchReq(), 2),
				Arguments.of("search_by_deleted_relation", -1L, -2003L, new PartyRelationPartySearchReq(), 0),
				Arguments.of("search_by_deleted_party", -4L, -2002L, new PartyRelationPartySearchReq(), 0)
		);
	}

	@Test
	void test_insert() {
		getJdbi().useHandle(handle -> {
			handle.begin();

			setUnusedBindingAllowed(true);
			List<String> initScripts = List.of("prp");
			execSqlFiles(this.getClass(), initScripts, testScriptParams);

			Long partyId = -1L;
			Long partyRelationId = -879L;

			PartyRelationItemReq partyRelationReq = new PartyRelationItemReq()
					.setRelatedPartyId(-2L)
					.setRelatedRoleCode("XXX")
					.setDtStart(AbsoluteDate.of("20230102"))
					.setDtEnd(AbsoluteDate.of("20231202"));

			PartyRelationParty inserted = service.insert(reqContext, partyId, partyRelationId, partyRelationReq);
			assertThat(inserted.getRelatedPartyId(), is(-2L));
			assertThat(inserted.getPartyRelationId(), is(partyRelationId));
			assertThat(inserted.getDtStart(), is(AbsoluteDate.of("20230102")));
			assertThat(inserted.getDtEnd(), is(AbsoluteDate.of("20231202")));

			handle.rollback();
		});

	}

	@Test
	void test_insert_when_partyRelationParty_exists_then_exception() {
		getJdbi().useHandle(handle -> {
			handle.begin();

			setUnusedBindingAllowed(true);
			List<String> initScripts = List.of("prp");
			execSqlFiles(this.getClass(), initScripts, testScriptParams);

			Long partyId = -1L;
			Long partyRelationId = -879L;

			PartyRelationItemReq partyRelationReq = new PartyRelationItemReq()
					.setRelatedPartyId(-2L)
					.setRelatedRoleCode("MARITO")
					.setDtStart(AbsoluteDate.of("20230102"))
					.setDtEnd(AbsoluteDate.of("20231202"));

			InvalidPartyRelationException exception =
					assertThrows(InvalidPartyRelationException.class, () -> service.insert(reqContext, partyId, partyRelationId, partyRelationReq));

			assertThat(exception.getCode(), is(ErrCodes.RELATION_PARTY_ALREADY_DEFINED));

			handle.rollback();
		});
	}

	@Test
	void test_update() {
		getJdbi().useHandle(handle -> {
			handle.begin();

			setUnusedBindingAllowed(true);
			List<String> initScripts = List.of("prp");
			execSqlFiles(this.getClass(), initScripts, testScriptParams);

			Long partyId = -1L;
			Long partyRelationId = -889L;
			Long pkid = -2003L;

			PartyRelationParty prp = this.service.getRelationPartyById(reqContext, partyId, partyRelationId, pkid).orElseThrow();
			assertThat(prp.getPkid(), is(-2003L));
			assertThat(prp.getRelatedPartyId(), is(-5L));
			assertThat(prp.getFirstName(), is("SPA"));
			assertThat(prp.getLastName(), is("REALT_TECHNOLOGY"));

			PartyRelationItemReq partyRelationReq = new PartyRelationItemReq()
					.setRelatedPartyId(-5L)
					.setRelatedRoleCode("SORELLA")
					.setDtStart(AbsoluteDate.of("20230102"))
					.setDtEnd(AbsoluteDate.of("20231202"));

			PartyRelationParty updated =
					service.update(reqContext, partyId, partyRelationId, pkid, partyRelationReq);

			assertThat(updated.getRelatedPartyId(), is(-5L));
			assertThat(updated.getPartyRelationId(), is(partyRelationId));
			assertThat(updated.getDtStart(), is(AbsoluteDate.of("20230102")));
			assertThat(updated.getDtEnd(), is(AbsoluteDate.of("20231202")));

			handle.rollback();
		});

	}

}
