package com.abacogroup.partyregistry;

import com.abacogroup.parti.testing.IntegrationTestSupport;
import io.dropwizard.testing.ResourceHelpers;
import io.dropwizard.testing.junit5.DropwizardAppExtension;
import java.util.List;
import java.util.Map;
import org.jdbi.v3.core.Jdbi;

public class JdbiTest {

	protected static DropwizardAppExtension<PartyRegistryConfiguration> EXT = new DropwizardAppExtension<>(
			PartyRegistryApplicationTest.class,
			ResourceHelpers.resourceFilePath(System.getProperty("test_config_file", "test_config.yml"))
	);

	protected final IntegrationTestSupport testSupport = new IntegrationTestSupport(EXT);

	public static void execSqlFiles(Class clazz, List<String> scripts, Map<String, Object> args) {
		Jdbi jdbi = ((PartyRegistryApplicationTest) EXT.getApplication()).getJdbi();
		IntegrationTestSupport.execSqlFiles(jdbi, clazz, scripts, args);
	}

	//-------- per comodità ----
	public <T> T getService(Class<T> clazz) {
		return testSupport.getService(clazz);
	}

	public <T> T getDAO(Class<T> classDAO) {
		return testSupport.getDAO(classDAO);
	}

	public void setUnusedBindingAllowed(boolean allowed) {
		testSupport.setUnusedBindingAllowed(allowed);
	}

	public Jdbi getJdbi() {
		return testSupport.getJdbi();
	}

	public <T, M> void injectMock(T target, M mock) {
		IntegrationTestSupport.injectMock(target, mock);
	}

}
