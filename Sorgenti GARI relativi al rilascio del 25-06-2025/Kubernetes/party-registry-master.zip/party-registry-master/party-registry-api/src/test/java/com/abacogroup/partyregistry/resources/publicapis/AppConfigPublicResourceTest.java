package com.abacogroup.partyregistry.resources.publicapis;

import static com.abacogroup.partyregistry.PrtTest.TENANT_DEFAULT_CODE;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.hasSize;
import static org.hamcrest.Matchers.is;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import com.abacogroup.partyregistry.PrtTest;
import com.abacogroup.partyregistry.api.v1.AppConfigResponseV1;
import com.abacogroup.partyregistry.core.AppConfigV1Service;
import com.abacogroup.partyregistry.core.impl.AppConfigV1ServiceImpl;
import com.abacogroup.partyregistry.resources.WebCliHelper;
import com.abacogroup.partyregistry.resources.req.ReqContext;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;
import io.dropwizard.testing.junit5.ResourceExtension;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mockito;

@Slf4j
@ExtendWith(DropwizardExtensionsSupport.class)
class AppConfigPublicResourceTest {

	private final AppConfigV1Service appConfigV1Service = Mockito.mock(AppConfigV1ServiceImpl.class);
	private final ResourceExtension EXT = WebCliHelper.createEXT(new AppConfigPublicResource(appConfigV1Service));

	private final ObjectMapper mapper = new ObjectMapper();

	@Test
	@SuppressWarnings("unchecked")
	void test_search() {
		String path = String.format(PrtTest.MASTER_PUBLIC_PATH + "/configurations");

		List<AppConfigResponseV1> list = WebCliHelper.executeGet(EXT, path, null, WebCliHelper.BASIC_CREDENTIALS,
				List.class);
		ArgumentCaptor<ReqContext> reqCtxCaptor = ArgumentCaptor.forClass(ReqContext.class);
		verify(appConfigV1Service, times(1))
				.searchAll(reqCtxCaptor.capture());

		ReqContext reqContext = reqCtxCaptor.getValue();
		assertThat(reqContext.getTenantId(), is(TENANT_DEFAULT_CODE));
		assertThat(reqContext.getLang(), is("en"));
		assertThat(reqContext.getUsername(), is(WebCliHelper.BASIC_USERNAME));
		assertThat(list, hasSize(0));
	}

	@Test
	void test_SearchByKey() {
		String key = "code";
		String path = String.format(PrtTest.MASTER_PUBLIC_PATH + "/configurations/" + key);

		given(appConfigV1Service.searchByKey(Mockito.any(ReqContext.class), Mockito.anyString()))
				.willReturn(Optional.of(AppConfigResponseV1.builder()
						.setConfigurationKey("code")
						.setConfiguration(Map.of("show", "true")).build()
				));

		AppConfigResponseV1 response = WebCliHelper.executeGet(EXT, path, null, WebCliHelper.BASIC_CREDENTIALS, AppConfigResponseV1.class);
		ArgumentCaptor<ReqContext> reqCtxCaptor = ArgumentCaptor.forClass(ReqContext.class);
		verify(appConfigV1Service, times(1))
				.searchByKey(reqCtxCaptor.capture(), eq(key));

		ReqContext reqContext = reqCtxCaptor.getValue();
		assertThat(reqContext.getTenantId(), is("master"));
		assertThat(reqContext.getLang(), is("en"));
		assertThat(reqContext.getUsername(), is(WebCliHelper.BASIC_USERNAME));

		assertThat(response.getConfigurationKey(), is(key));

	}
}
