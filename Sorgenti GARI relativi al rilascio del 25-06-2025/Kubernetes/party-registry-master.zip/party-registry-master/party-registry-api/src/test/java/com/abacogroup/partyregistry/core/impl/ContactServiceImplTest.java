package com.abacogroup.partyregistry.core.impl;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.greaterThan;
import static org.hamcrest.Matchers.greaterThanOrEqualTo;
import static org.hamcrest.Matchers.hasSize;
import static org.hamcrest.Matchers.is;

import com.abacogroup.partyregistry.JdbiTest;
import com.abacogroup.partyregistry.PrtTest;
import com.abacogroup.partyregistry.api.ContactSearchResponse;
import com.abacogroup.partyregistry.api.ContactTypeEnum;
import com.abacogroup.partyregistry.api.PartyContact;
import com.abacogroup.partyregistry.core.exceptions.ErrCodes;
import com.abacogroup.partyregistry.core.exceptions.InvalidPartyException;
import com.abacogroup.partyregistry.resources.req.ContactSearchReq;
import com.abacogroup.partyregistry.resources.req.PartyContactReq;
import com.abacogroup.partyregistry.resources.req.ReqContext;
import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;

@Slf4j
@ExtendWith(DropwizardExtensionsSupport.class)
class ContactServiceImplTest extends JdbiTest {

	private static final String tenantId = "ContactServiceImplTest_t";
	private static final String currentUser = "ContactServiceImplTest_u";

	private static final ReqContext reqContext =
			new ReqContext(tenantId, currentUser, "en");

	private static final Map<String, Object> testScriptParams = Map.of(
			"test_tenant", tenantId,
			"user_id", currentUser
	);

	private final ContactServiceImpl contactService = getService(ContactServiceImpl.class);

	@BeforeAll
	@AfterAll
	public static void beforeAll() {
		List<String> initScripts = List.of("rollback");
		execSqlFiles(PrtTest.class, initScripts, testScriptParams);
	}

	@Test
	void test_add_update_expire_contact() throws InterruptedException {

		setUnusedBindingAllowed(true);
		getJdbi().useHandle(handle -> {
			handle.begin();

			List<String> initScripts = List.of("contacts");
			execSqlFiles(this.getClass(), initScripts, testScriptParams);

			List<ContactSearchResponse> initContacts = contactService.search(reqContext,
					new ContactSearchReq().setPartyId(-1L), null
			).getRecords();
			assertThat(initContacts, hasSize(1));

			PartyContact partyContact = this.contactService.insert(reqContext, -1L, new PartyContactReq()
							.setContactType(ContactTypeEnum.EMAIL)
							.setSubType("PERSONAL")
							.setContactValue("json@example.com")
							.setNote("test note example"),
					true
			);
			assertThat(partyContact.getPkid(), greaterThanOrEqualTo(1L));
			assertThat(partyContact.getContactType(), is(ContactTypeEnum.EMAIL));
			assertThat(partyContact.getSubType(), is("PERSONAL"));
			assertThat(partyContact.getContactValue(), is("json@example.com"));
			assertThat(partyContact.getNote(), is("test note example"));

			List<ContactSearchResponse> contacts = contactService.search(reqContext,
					new ContactSearchReq().setPartyId(partyContact.getPartyId()), null
			).getRecords();
			assertThat(contacts, hasSize(2));

			ContactSearchResponse resp = contacts.stream().filter(c -> c.getContactValue()
							.equalsIgnoreCase("mario1@example.com"))
					.findFirst().orElseThrow();

			assertThat(resp.getContactType(), is(ContactTypeEnum.EMAIL));
			assertThat(resp.getSubType(), is("priv"));
			assertThat(resp.getContactValue(), is("mario1@example.com"));
			assertThat(resp.getNote(), is("test note"));

			PartyContactReq contact = new PartyContactReq()
					.setContactType(resp.getContactType())
					.setSubType(resp.getSubType())
					.setContactValue(resp.getContactValue())
					.setNote("test note example 2, it is a long note");

			PartyContact updatedContact = contactService
					.update(reqContext, resp.getPartyId(), resp.getPkid(), contact);

			long pkid = updatedContact.getPkid();
			assertThat(pkid, greaterThan(resp.getPkid()));
			assertThat(updatedContact.getContactType(), is(resp.getContactType()));
			assertThat(updatedContact.getSubType(), is(resp.getSubType()));
			assertThat(updatedContact.getContactValue(), is(resp.getContactValue()));
			assertThat(updatedContact.getNote(), is("test note example 2, it is a long note"));

			contacts = contactService.search(reqContext,
					new ContactSearchReq().setPartyId(partyContact.getPartyId()), null
			).getRecords();
			assertThat("2 perchè carica il record corrente", contacts, hasSize(2));

			contactService.expireContact(reqContext, partyContact.getPartyId(), pkid);

			List<ContactSearchResponse> records = contactService.search(reqContext, new ContactSearchReq()
							.setPartyId(partyContact.getPartyId()), null
					)
					.getRecords();

			assertThat("1 perchè l'ultimo è stato expired manually", records, hasSize(1));

			handle.rollback();
		});

	}

	@Test
	void test_add_contact_when_party_is_invalid() {
		Long INVALID_PARTY_ID = -404L;
		InvalidPartyException exception = Assertions.assertThrows(InvalidPartyException.class, () -> {
			this.contactService.insert(reqContext, INVALID_PARTY_ID, new PartyContactReq()
					.setContactType(ContactTypeEnum.EMAIL), true);
		});
		assertThat(exception.getCode(), is(ErrCodes.PARTY_NOT_FOUND));
	}

	@Test
	void test_expire_contacts_byType() {
		setUnusedBindingAllowed(true);
		getJdbi().useHandle(handle -> {
			handle.begin();

			List<String> initScripts = List.of("contacts");
			execSqlFiles(this.getClass(), initScripts, testScriptParams);

			Long partyId = -2L;
			ContactTypeEnum contactType = ContactTypeEnum.PHONE;

			ContactSearchReq request = new ContactSearchReq().setContactType(contactType).setPartyId(partyId);
			List<ContactSearchResponse> contacts = this.contactService.search(reqContext, request, null)
					.getRecords();
			assertThat(contacts.size(), is(2));

			// expire
			contactService.expireContactsByType(reqContext, contactType, partyId);

			// asserts
			List<ContactSearchResponse> contactsAfterDelete = this.contactService.search(reqContext, request, null)
					.getRecords();
			assertThat(contactsAfterDelete.size(), is(0));

			handle.rollback();
		});
	}

	@ParameterizedTest
	@MethodSource
	void test_search(String ignoredTitle, ContactSearchReq request, List<Long> expected) {

		setUnusedBindingAllowed(true);
		getJdbi().useHandle(handle -> {
			handle.begin();

			List<String> initScripts = List.of("contacts");
			execSqlFiles(this.getClass(), initScripts, testScriptParams);

			List<ContactSearchResponse> list = this.contactService.search(reqContext, request, null)
					.getRecords();
			List<Long> actual = list.stream()
					.map(ContactSearchResponse::getPkid)
					.collect(Collectors.toList());
			assertThat(actual, is(expected));

			handle.rollback();
		});

	}

	private static Stream<Arguments> test_search() {
		return Stream.of(
				Arguments.of("all", new ContactSearchReq(), List.of(
						-8L,
						-11L,
						-14L,
						-13L
				)),
				Arguments.of("by party active", new ContactSearchReq().setPartyId(-2L), List.of(-11L, -14L, -13L)),
				Arguments.of("by party active 1L", new ContactSearchReq().setPartyId(-1L), List.of(-8L))
		);
	}
}
