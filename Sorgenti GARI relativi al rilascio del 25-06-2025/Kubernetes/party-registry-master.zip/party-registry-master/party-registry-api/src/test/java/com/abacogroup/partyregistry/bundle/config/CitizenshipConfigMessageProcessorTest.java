package com.abacogroup.partyregistry.bundle.config;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;

import com.abacogroup.bundles.initializer.impl.FileSupport;
import com.abacogroup.bundles.listener.configdata.ConfigDataMessage;
import com.abacogroup.partyregistry.JdbiTest;
import com.abacogroup.partyregistry.db.dao.CitizenshipDAO;
import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;
import java.nio.file.Path;
import java.util.List;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

@Slf4j
@ExtendWith(DropwizardExtensionsSupport.class)
class CitizenshipConfigMessageProcessorTest extends JdbiTest {

	public static final String TENANT = "citizenshipBundleTenant";

	private final CitizenshipConfigMessageProcessor processor = getService(CitizenshipConfigMessageProcessor.class);

	@Test
	public void testOnMessage() {
		List<Path> paths = FileSupport.listFilesRecursive(
				Path.of("src/test/resources/bundles/standard/party-registry/prt-0001/citizenship"));
		ConfigDataMessage msg = new ConfigDataMessage();
		msg.setConfigFiles(paths);
		msg.setTenantId(TENANT);

		getJdbi().useHandle(handle -> {
			handle.begin();

			CitizenshipDAO dao = handle.attach(CitizenshipDAO.class);
			assertThat(dao.countAll(TENANT), is(0L));
			processor.onMessage(msg);
			assertThat(dao.countAll(TENANT), is(250L));

			handle.rollback();
		});

	}

}
