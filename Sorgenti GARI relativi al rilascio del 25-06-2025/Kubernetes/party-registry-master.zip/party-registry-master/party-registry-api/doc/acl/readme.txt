
config-realt.yml -> è quello di parties-acl-server con le conf per dev party
vite.config.ts -> punta a party registry dev locale


----

lanciare questo per install del bundle

###
POST http://localhost:8080/party-registry/devtools/bundle/install
Content-Type: application/json

{
  "path": "bundles-iacs-italia/acl-master"
}
