# devtools

è una resource che espone i seguenti endpoint

- **creazione** di un _tenant_
- **eliminazione** di un _tenant_, il che equivale alla
- **install** di un _bundle_ da path su disco

vedi la collection `party-bundles.postman_collection.json`

## Utilizzo:

Allo startup, party genera i bundle di installazione per se stesso e per gli altri miicroservizi
e li pubblica si rabbit.
Sono configurati per avere come tenant template `*`
In questo progetto i bundle sono in `bundles/standard/`

quindi,

- al tempo t0, l'app ha solo le tabelle vuote
- al tempo t1, il bundle si installa in automatico e vengono scritti i dati per il tenant _template_

> A questo punto **non è ancora possibile** lavorare con il portale, perchè ci manca un tenant.

- t2, creazione di un tenant con devtools (POST > `http://localhost:8080/party-registry/devtools/tenants/master`)

> ora che il bundle è installato e abbiamo creato un tenant, abbiamo db pronto a lavorare per il tenant

- t3, installazione dei dati specifici del tenant. Con la chiamata per installare un bundle, possiamo ora installare i dati preconfigurati. Il pacchetto
  è `bundles/dev_master`.
  ```
  POST http://localhost:8080/party-registry/devtools/bundle/install
  Content-Type: application/json
  
  {
    "path": "bundles/dev_master"
  }
  ```

-----
Caso d'uso:
facciamo un pasticcio e vogliamo revertare tutto (a caldo):

- cancella il bundle con (DELETE > `http://localhost:8080/party-registry/devtools/tenants/master`

> se cancelli il tenant master, devi ricreare il tenant (t2) e reinstallare il bundle (t3 con `bundles/dev_master`)

> se cancelli ANCHE `*` allora ci sono 2 vie. t3 puntando a  `bundles/standard/` oppure restart della applicazione, poi creare il tenant e applicare il bundle
> specifico

```
bundles/standard/
├── bundles.config.json
├── lau-registry
│ └── lau-0001
│     ├── i18n
│     └── lau
├── party-registry
│ └── prt-0001
│     ├── citizenship
│     ├── dynamic_documents
│     ├── i18n
│     ├── relations
│     └── tags
└── sso-server-2
    └── prt-0001
        └── functions

```

