package com.abacogroup.partyregistry.core.exceptions;

import jakarta.ws.rs.WebApplicationException;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.core.Response.Status;
import lombok.Data;

@Data
public abstract class AbstractAppException extends WebApplicationException {

	private String code;
	private String message;

	AbstractAppException(ExceptionErrorBody body, String message) {
		super(message,
				Response.status(Status.BAD_REQUEST).entity(body).build());
		this.code = body.getErrorCode();
		this.message = message;
	}

	public interface ExceptionErrorBody {

		String getErrorCode();
	}
}
