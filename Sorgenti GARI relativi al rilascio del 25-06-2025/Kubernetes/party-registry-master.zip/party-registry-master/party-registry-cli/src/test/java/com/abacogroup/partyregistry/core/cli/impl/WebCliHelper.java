package com.abacogroup.partyregistry.core.cli.impl;

import com.abacogroup.dropwizard.auth.multitenant.MultitenantFilter;
import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.partyregistry.MockCredentialsAuthFilter;
import io.dropwizard.auth.AuthDynamicFeature;
import io.dropwizard.auth.AuthValueFactoryProvider;
import io.dropwizard.testing.junit5.ResourceExtension;
import java.util.Base64;
import java.util.Optional;
import org.glassfish.jersey.server.filter.RolesAllowedDynamicFeature;

public abstract class WebCliHelper {

	public static final String BASIC_USERNAME = "test-user@example";
	public static final String BASIC_CREDENTIALS =
			"Basic " + Base64.getEncoder().encodeToString(String.format("%s:secret", BASIC_USERNAME).getBytes());

	public static ResourceExtension createEXT(Object resource) {

		return ResourceExtension.builder()
				//        .setMapper(new ObjectMapper())
				.addProvider(new AuthDynamicFeature(new MockCredentialsAuthFilter.Builder<User>()
						.setAuthenticator(credentials -> Optional.of(new User(credentials.getUsername(), "master")))
						.setAuthorizer((principal, role, x) -> {
							return true;
						})
						.buildAuthFilter()))
				.addProvider(RolesAllowedDynamicFeature.class)
				.addProvider(new AuthValueFactoryProvider.Binder<>(User.class))
				.addProvider(new MultitenantFilter("tenant"))
				.addResource(resource)
				.build();
	}

}
