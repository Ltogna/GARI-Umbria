package com.abacogroup.partyregistry.core.exceptions;

public class TestException extends AbstractAppException {

	private static final ErrorBody BODY = new ErrorBody();

	public TestException(String msg) {
		super(BODY, msg);
	}

	public static class ErrorBody implements ExceptionErrorBody {

		private static final String ERR = "TEST_ERROR";

		@Override
		public String getErrorCode() {
			return ERR;
		}
	}

}
