package com.abacogroup.partyregistry.core.cli.impl;

import static org.assertj.core.api.Assertions.assertThat;

import com.abacogroup.dropwizard.auth.sso2.User;
import org.junit.jupiter.api.Test;

class TokenRelayStrategyTest {

	private TokenRelayStrategy strategy = new TokenRelayStrategy();

	// ----- getAuthorization -----
	@Test
	void test_getAuthorization_ok() {
		User user = new User("test_user", "the_token", "master", "user_id");

		String authorization = strategy.getAuthorization(user);

		assertThat(authorization).isNotNull()
				.isEqualTo("JWT the_token");
	}

	@Test
	void test_givenNoToken_getAuthorization_null() {
		User user = new User("test_user", "master");

		String authorization = strategy.getAuthorization(user);

		assertThat(authorization).isNull();
	}
}
