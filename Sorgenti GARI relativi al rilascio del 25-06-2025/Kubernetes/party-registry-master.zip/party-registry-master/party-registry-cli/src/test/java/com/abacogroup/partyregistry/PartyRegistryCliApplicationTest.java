package com.abacogroup.partyregistry;

import com.abacogroup.dropwizard.auth.multitenant.MultitenantFilter;
import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.partyregistry.core.cli.impl.NoopAuthorizationStrategy;
import com.abacogroup.partyregistry.core.cli.v1.PartyClientV1;
import com.abacogroup.partyregistry.core.cli.v1.PartyClientV1Impl;
import com.google.common.collect.ImmutableMap;
import com.google.common.collect.ImmutableSet;
import io.dropwizard.auth.AuthFilter;
import io.dropwizard.auth.PolymorphicAuthDynamicFeature;
import io.dropwizard.auth.PolymorphicAuthValueFactoryProvider;
import io.dropwizard.auth.chained.ChainedAuthFilter;
import io.dropwizard.client.JerseyClientBuilder;
import io.dropwizard.core.Application;
import io.dropwizard.core.setup.Bootstrap;
import io.dropwizard.core.setup.Environment;
import jakarta.servlet.DispatcherType;
import jakarta.servlet.FilterRegistration.Dynamic;
import jakarta.ws.rs.client.Client;
import jakarta.ws.rs.client.WebTarget;
import java.util.ArrayList;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import lombok.extern.slf4j.Slf4j;
import org.eclipse.jetty.servlets.CrossOriginFilter;

@Slf4j
public class PartyRegistryCliApplicationTest extends Application<PartyRegistryCliConfiguration> {

	private Map<Class<?>, Object> services = new HashMap<>();

	public Map<Class<?>, Object> getServices() {
		return services;
	}

	public <T> T getService(Class<T> clazz) {
		return Optional
				.ofNullable(this.getServices().get(clazz))
				.map(clazz::cast)
				.orElseThrow(() -> new RuntimeException(
						String.format("Error loading %s! Did you call by interface? Implementation required", clazz.getSimpleName())));
	}

	//  public static void main(final String[] args) throws Exception {
	//    new LauCliApplicationTest().run(args);
	//  }

	@Override
	public String getName() {
		return "prt-cli-test";
	}

	@Override
	public void initialize(final Bootstrap<PartyRegistryCliConfiguration> bootstrap) {
		// TODO: application initialization
	}

	@Override
	public void run(final PartyRegistryCliConfiguration configuration, final Environment environment) {
		// /api/tentant/{}/
		// environment.jersey().
		// TODO: implement application

		WebTarget webTarget = this.initPrtTarget(configuration, environment);

		PartyClientV1 partyClient = this.register(new PartyClientV1Impl(webTarget, new NoopAuthorizationStrategy()));

		this.initAuth(environment);
		this.initMultiTenant(environment);
		this.setupCORS(configuration, environment);
	}

	protected WebTarget initPrtTarget(PartyRegistryCliConfiguration configuration, Environment environment) {
		final Client client = new JerseyClientBuilder(environment).using(configuration.getJerseyClient()).build("prt-client");
		WebTarget prt = client.target("http://localhost:8080/party-registry");
		return prt;
	}

	protected void initAuth(Environment environment) {
		List<AuthFilter<?, ? extends User>> filters = new ArrayList();
		filters.add(new MockCredentialsAuthFilter.Builder<User>()
				.setAuthenticator(credentials -> Optional.of(new User(credentials.getUsername(), "master")))
				.setAuthorizer((principal, role, x) -> {
					return true;
				})
				.setRealm("GUEST authenticator")
				.buildAuthFilter());

		ChainedAuthFilter usersFilter = new ChainedAuthFilter(filters);

		final PolymorphicAuthDynamicFeature<? extends User> feature = new PolymorphicAuthDynamicFeature<>(
				ImmutableMap.of(User.class, usersFilter /*
				 * , ApiKeyUser.class,
				 * apiKeyFilter
				 */));

		PolymorphicAuthValueFactoryProvider.Binder<? extends User> binder = new PolymorphicAuthValueFactoryProvider.Binder<>(
				ImmutableSet.of(User.class /* , ApiKeyUser.class */));

		environment.jersey().register(feature);
		environment.jersey().register(binder);
		//
	}

	protected <T> T register(T service) {
		services.put(service.getClass(), service);
		return service;
	}

	private void setupCORS(PartyRegistryCliConfiguration configuration, Environment environment) {
		if (!configuration.isCors()) {
			log.info("CORS is disabled");
			return;
		}

		log.info("CORS is enabled");

		Dynamic cors = environment.servlets().addFilter("CORS", CrossOriginFilter.class);
		cors.setInitParameter(CrossOriginFilter.ALLOWED_ORIGINS_PARAM, "*");
		cors.setInitParameter(CrossOriginFilter.ALLOWED_HEADERS_PARAM, "*");
		cors.setInitParameter(CrossOriginFilter.ALLOWED_METHODS_PARAM, "GET,PUT,POST,DELETE");

		// OPTIONS pre-flight request will be served by the filter ONLY and not
		// passed ahead
		// cors.setInitParameter(CrossOriginFilter.CHAIN_PREFLIGHT_PARAM,
		// "false");

		// Add URL mapping
		cors.addMappingForUrlPatterns(EnumSet.allOf(DispatcherType.class), false, "*");
	}

	private void initMultiTenant(Environment environment) {
		environment.jersey().register(new MultitenantFilter("tenant"));
	}

}
