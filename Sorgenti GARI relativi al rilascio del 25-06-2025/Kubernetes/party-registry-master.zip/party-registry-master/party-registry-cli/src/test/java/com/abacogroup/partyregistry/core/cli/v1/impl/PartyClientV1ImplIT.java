package com.abacogroup.partyregistry.core.cli.v1.impl;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;

import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.partyregistry.PartyRegistryCliApplicationTest;
import com.abacogroup.partyregistry.PartyRegistryCliConfiguration;
import com.abacogroup.partyregistry.api.v1.PartyResponseV1;
import com.abacogroup.partyregistry.api.v1.PartySearchResponseV1;
import com.abacogroup.partyregistry.api.v1.req.PartySearchRequestV1;
import com.abacogroup.partyregistry.core.cli.v1.PartyClientV1;
import com.abacogroup.partyregistry.core.cli.v1.PartyClientV1Impl;
import io.dropwizard.testing.ResourceHelpers;
import io.dropwizard.testing.junit5.DropwizardAppExtension;
import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;
import jakarta.ws.rs.BadRequestException;
import org.assertj.core.groups.Tuple;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

@Disabled("needs party-registry up and dev_master data (see party-registry/doc/devtools.readme.md")
@ExtendWith(DropwizardExtensionsSupport.class)
class PartyClientV1ImplIT {

	protected static DropwizardAppExtension<PartyRegistryCliConfiguration> EXT = new DropwizardAppExtension<>(
			PartyRegistryCliApplicationTest.class,
			ResourceHelpers.resourceFilePath("test_config.yml")
	);

	private final PartyRegistryCliApplicationTest app = EXT.getApplication();
	private final PartyClientV1 partyClient = app.getService(PartyClientV1Impl.class);
	private final long partyId = 6L; // MARIO ROSSI id

	// ----- search -----
	@Test
	void test_givenNoParams_search_ko() {
		BadRequestException badRequestException = assertThrows(BadRequestException.class,
				() -> partyClient.search("it", new User("test", "master"), null, new PartySearchRequestV1()));

		System.out.println(badRequestException.getMessage());
	}

	@Test
	void test_givenParams_search_ok() {
		InfiniteListResults<PartySearchResponseV1> results = partyClient.search("en", new User("test", "master"), null,
				new PartySearchRequestV1().setLastName("massive"));

		assertThat(results).isNotNull();
		assertThat(results.getRecords()).hasSize(1)
				.extracting(PartySearchResponseV1::getLastName, PartySearchResponseV1::getFirstName)
				.containsExactlyInAnyOrder(
						Tuple.tuple("MASSIVE DYNAMIC", null)
				);

	}

	// ----- getById -----
	@Test
	void test_getById_ok() {
		PartyResponseV1 result = partyClient.getById("it", new User("test", "master"), partyId);

		assertThat(result).isNotNull()
				.extracting(PartyResponseV1::getLastName, PartyResponseV1::getFirstName)
				.containsExactly("ROSSI", "MARIO");
	}

	@Test
	void test_getByCode_204() {
		PartyResponseV1 result = partyClient.getById("it", new User("test", "master"), -1000L);

		assertThat(result).isNull();
	}
}
