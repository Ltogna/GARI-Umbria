package com.abacogroup.partyregistry.api;

public enum PartyTypeEnum {

	/**
	 * natural
	 */
	N,

	/**
	 * legal
	 */
	L
}
