package com.abacogroup.partyregistry.dto.v1;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import java.util.List;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder(setterPrefix = "set")
@NoArgsConstructor
@Accessors(chain = true)
public class PartyRelationExternalDtoV1 {

	@NotBlank
	private String relationCode;
	private String note;

	@Valid
	@NotEmpty
	private List<PartyRelationItemExternalDtoV1> parties;

}
