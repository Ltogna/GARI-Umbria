package com.abacogroup.partyregistry.core.cli.v1;

import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.partyregistry.api.v1.RelationTypeResponseV1;
import com.abacogroup.partyregistry.api.v1.req.RelationTypeSearchRequestV1;

public interface RelationTypeClientV1 {

	InfiniteListResults<RelationTypeResponseV1> search(String lang, User user, String nextKey, RelationTypeSearchRequestV1 searchRequest);

	RelationTypeResponseV1 getByCode(String lang, User user, String code);
}
