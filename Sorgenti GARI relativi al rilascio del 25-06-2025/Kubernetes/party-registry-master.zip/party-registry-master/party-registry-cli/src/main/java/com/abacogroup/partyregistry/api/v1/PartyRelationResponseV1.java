package com.abacogroup.partyregistry.api.v1;

import jakarta.validation.constraints.NotNull;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder(setterPrefix = "set")
@NoArgsConstructor
public class PartyRelationResponseV1 {

	private Long id;

	@NotNull
	private Long partyId;

	private String relationTypeCode;

	private String relationTypeI18nCode;

	private String note;

}
