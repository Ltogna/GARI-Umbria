package com.abacogroup.partyregistry.api;

import com.fasterxml.jackson.annotation.JsonIgnore;

public interface InfiniteSearchRequest {

	int PAGE_SIZE = 20;

	@JsonIgnore
		//@Schema(hidden = true)
	int getPageSize();

}
