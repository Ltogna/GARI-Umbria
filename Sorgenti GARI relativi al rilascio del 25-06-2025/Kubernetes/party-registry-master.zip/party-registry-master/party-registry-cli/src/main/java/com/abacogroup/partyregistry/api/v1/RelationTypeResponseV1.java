package com.abacogroup.partyregistry.api.v1;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder(setterPrefix = "set")
@NoArgsConstructor
public class RelationTypeResponseV1 {

	private Long id;
	private String code;
	private boolean multiple;
	private String i18nCode;
}
