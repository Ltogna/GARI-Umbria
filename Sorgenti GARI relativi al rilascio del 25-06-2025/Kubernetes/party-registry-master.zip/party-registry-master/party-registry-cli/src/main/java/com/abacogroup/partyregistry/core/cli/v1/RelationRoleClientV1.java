package com.abacogroup.partyregistry.core.cli.v1;

import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.partyregistry.api.v1.RelationRoleResponseV1;
import com.abacogroup.partyregistry.api.v1.req.RelationRoleSearchRequestV1;

public interface RelationRoleClientV1 {

	InfiniteListResults<RelationRoleResponseV1> search(String lang, User user, String nextKey, String relationTypeCode,
			RelationRoleSearchRequestV1 searchRequest);

	RelationRoleResponseV1 getByCode(String lang, User user, String typeCode, String code);
}
