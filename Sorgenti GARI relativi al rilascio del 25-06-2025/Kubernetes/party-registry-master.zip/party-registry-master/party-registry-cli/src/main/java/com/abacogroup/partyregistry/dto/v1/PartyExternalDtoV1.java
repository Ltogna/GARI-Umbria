package com.abacogroup.partyregistry.dto.v1;

import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.partyregistry.api.GenderEnum;
import com.abacogroup.partyregistry.api.PartyTypeEnum;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder(setterPrefix = "set")
@NoArgsConstructor
@Accessors(chain = true)
public class PartyExternalDtoV1 {

	@NotNull
	private PartyTypeEnum partyType;
	private GenderEnum gender;

	@NotEmpty
	private String lastName;
	private String firstName;

	private String taxCode;
	private String vatNumber;

	@NotBlank
	private String code;
	/**
	 * code from /{tenant}/public/v1/legal-status
	 */
	private String legalStatus;


	private AbsoluteDate birthDate;
	private AbsoluteDate deathDate;

	/**
	 * code from /{tenant}/public/v1/municipalities in lau-service
	 */
	private String birthMunicipality;
	/**
	 * code from /{tenant}/public/v1/citizenships
	 */
	@Size(max = 3)
	private String nationality;

	private AddressExternalDtoV1 addressResidential;

	private AddressExternalDtoV1 addressBilling;

}
