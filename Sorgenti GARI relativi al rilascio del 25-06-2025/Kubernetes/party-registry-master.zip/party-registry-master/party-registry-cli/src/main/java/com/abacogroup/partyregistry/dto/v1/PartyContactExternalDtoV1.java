package com.abacogroup.partyregistry.dto.v1;

import com.abacogroup.partyregistry.api.ContactTypeEnum;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder(setterPrefix = "set")
@NoArgsConstructor
@Accessors(chain = true)
public class PartyContactExternalDtoV1 {

	@NotNull
	private ContactTypeEnum contactType;
	@NotBlank
	private String subType;
	@NotBlank
	private String contactValue;
	private String note;

}
