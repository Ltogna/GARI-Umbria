package com.abacogroup.partyregistry.core.cli.impl;

import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.partyregistry.core.cli.AuthorizationStrategy;

public class NoopAuthorizationStrategy implements AuthorizationStrategy {

	@Override
	public String getAuthorization(User user) {
		return null;
	}

}
