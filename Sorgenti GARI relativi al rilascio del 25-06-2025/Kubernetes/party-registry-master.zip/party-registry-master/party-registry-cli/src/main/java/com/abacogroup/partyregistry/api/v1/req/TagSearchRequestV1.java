package com.abacogroup.partyregistry.api.v1.req;

import com.abacogroup.partyregistry.api.InfiniteSearchRequest;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.ws.rs.QueryParam;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

@Data
@NoArgsConstructor
@Accessors(chain = true)
public class TagSearchRequestV1 implements InfiniteSearchRequest {

	//	@Parameter(in = ParameterIn.QUERY, description = "tag ID")
	@QueryParam("id")
	private Long id;

	//	@Parameter(in = ParameterIn.QUERY, description = "tag code")
	@QueryParam("code")
	private String code;

	//	@Parameter(in = ParameterIn.QUERY, description = "tag code i18n")
	@QueryParam("i18nCode")
	private String i18nCode;

	@Override
	@JsonIgnore
	public int getPageSize() {
		return PAGE_SIZE;
	}

}
