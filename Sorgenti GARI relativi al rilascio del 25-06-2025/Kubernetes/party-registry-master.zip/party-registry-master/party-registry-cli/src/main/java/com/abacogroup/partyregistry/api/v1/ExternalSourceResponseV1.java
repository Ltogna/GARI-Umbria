package com.abacogroup.partyregistry.api.v1;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder(setterPrefix = "set")
@NoArgsConstructor
public class ExternalSourceResponseV1 {

	private String code;

	private Boolean allowManual;

	private String description;

}
