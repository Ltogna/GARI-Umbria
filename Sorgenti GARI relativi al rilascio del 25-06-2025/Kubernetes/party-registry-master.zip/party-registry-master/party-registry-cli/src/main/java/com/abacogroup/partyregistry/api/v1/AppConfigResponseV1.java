package com.abacogroup.partyregistry.api.v1;

import java.util.Map;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder(setterPrefix = "set")
@NoArgsConstructor
public class AppConfigResponseV1 {

	private String configurationKey;
	private Map<String, Object> configuration;
}
