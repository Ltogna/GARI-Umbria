package com.abacogroup.partyregistry.api.v1.lau;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;
import lombok.experimental.SuperBuilder;

@Data
@Accessors(chain = true)
@SuperBuilder(setterPrefix = "set")
@NoArgsConstructor
public class RegionResponseV1 {

	private String code;
	private String tenantId;
	private String countryCode;
	private String shortDescr;
	private boolean active = true;

	private String i18nName;

	private CountryResponseV1 country;

}
