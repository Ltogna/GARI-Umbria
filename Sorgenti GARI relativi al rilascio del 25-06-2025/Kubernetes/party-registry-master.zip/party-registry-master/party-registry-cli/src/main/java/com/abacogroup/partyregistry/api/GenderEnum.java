package com.abacogroup.partyregistry.api;

public enum GenderEnum {

	/**
	 * male
	 */
	M,

	/**
	 * female
	 */
	F

}
