package com.abacogroup.partyregistry.api.v1;

import com.abacogroup.partyregistry.api.v1.lau.MunicipalityResponseV1;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

/**
 * V1
 */
@Data
@SuperBuilder(setterPrefix = "set")
@NoArgsConstructor
public class AddressResponseV1 {

	private Long id;
	private String municipality;
	private String locality;
	private String street;
	private String houseNumber;
	private String postcode;
	private String details;
	private String note;

	@Deprecated(forRemoval = true)
	private String municipalityI18nCode;
	private MunicipalityResponseV1 municipalityDetail;
}
