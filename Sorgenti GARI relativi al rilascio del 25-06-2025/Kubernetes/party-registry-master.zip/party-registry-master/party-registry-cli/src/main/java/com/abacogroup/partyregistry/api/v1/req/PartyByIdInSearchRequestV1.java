package com.abacogroup.partyregistry.api.v1.req;

import jakarta.validation.constraints.NotEmpty;
import java.util.List;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

@Data
@NoArgsConstructor
@Accessors(chain = true)
public class PartyByIdInSearchRequestV1 {

	@NotEmpty
	private List<Long> ids;
}
