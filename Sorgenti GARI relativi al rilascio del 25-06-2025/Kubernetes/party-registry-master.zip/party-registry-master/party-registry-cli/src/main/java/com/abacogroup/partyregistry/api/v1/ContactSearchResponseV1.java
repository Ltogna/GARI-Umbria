package com.abacogroup.partyregistry.api.v1;

import com.abacogroup.partyregistry.api.ContactTypeEnum;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder(setterPrefix = "set")
@NoArgsConstructor
public class ContactSearchResponseV1 {

	private Long pkid;
	private Long partyId;
	private ContactTypeEnum contactType;
	private String subType;
	private String contactValue;
	private String note;
}
