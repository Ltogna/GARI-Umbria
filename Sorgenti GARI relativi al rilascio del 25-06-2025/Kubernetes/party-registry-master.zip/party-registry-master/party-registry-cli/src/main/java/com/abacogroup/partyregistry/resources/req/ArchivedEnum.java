package com.abacogroup.partyregistry.resources.req;

public enum ArchivedEnum {
	all,
	only_archived,
	not_archived
}
