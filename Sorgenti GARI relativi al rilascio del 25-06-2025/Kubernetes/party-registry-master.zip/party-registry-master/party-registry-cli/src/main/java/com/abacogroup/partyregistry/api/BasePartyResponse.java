package com.abacogroup.partyregistry.api;

public interface BasePartyResponse {

	Long getId();

	String getPartyType();

	String getGender();

	String getLastName();

	String getFirstName();

	String getTaxCode();

	String getVatNumber();

	String getCode();
}
