package com.abacogroup.partyregistry.core.cli.v1;

import static com.abacogroup.partyregistry.resources.PublicResourceConstants.API_V1_PUB;
import static jakarta.ws.rs.core.HttpHeaders.ACCEPT_LANGUAGE;
import static jakarta.ws.rs.core.HttpHeaders.AUTHORIZATION;

import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.jdbi.paging.impl.InfiniteListResultsImpl;
import com.abacogroup.partyregistry.api.v1.RelationRoleResponseV1;
import com.abacogroup.partyregistry.api.v1.req.RelationRoleSearchRequestV1;
import com.abacogroup.partyregistry.core.cli.AuthorizationStrategy;
import com.abacogroup.partyregistry.core.cli.impl.TokenRelayStrategy;
import com.abacogroup.partyregistry.utils.ClientUtils;
import io.github.resilience4j.retry.RetryConfig;
import io.github.resilience4j.retry.RetryRegistry;
import jakarta.ws.rs.ProcessingException;
import jakarta.ws.rs.ServerErrorException;
import jakarta.ws.rs.client.WebTarget;
import jakarta.ws.rs.core.GenericType;
import jakarta.ws.rs.core.MediaType;
import java.time.Duration;

public class RelationRoleClientV1Impl implements RelationRoleClientV1 {

	private final WebTarget relationRoleTarget;
	private final AuthorizationStrategy authorizationStrategy;

	private RetryRegistry retryRegistry;

	public RelationRoleClientV1Impl(WebTarget prtBaseTarget, AuthorizationStrategy authorizationStrategy) {
		this.relationRoleTarget = prtBaseTarget.path(String.format("%s/%s", API_V1_PUB, "relation-types/{relationTypeCode}/roles"));
		this.authorizationStrategy = authorizationStrategy;

		this.retryRegistry = RetryRegistry.of(RetryConfig.custom()
				.maxAttempts(2)
				.waitDuration(Duration.ofMillis(500))
				.failAfterMaxAttempts(true)
				.retryExceptions(ProcessingException.class, ServerErrorException.class)
				.build());
	}

	public RelationRoleClientV1Impl(WebTarget prtBaseTarget) {
		this(prtBaseTarget, new TokenRelayStrategy());
	}

	@Override
	public InfiniteListResults<RelationRoleResponseV1> search(String lang, User user, String nextKey, String relationTypeCode,
			RelationRoleSearchRequestV1 searchRequest) {
		String tenantId = user.getTenant();

		WebTarget webTarget = relationRoleTarget
				.resolveTemplate("tenant", tenantId)
				.resolveTemplate("relationTypeCode", relationTypeCode);

		WebTarget finalWebTarget = ClientUtils.addQueryParams(nextKey, searchRequest, webTarget);

		return retryRegistry.retry(webTarget.getUri().toString())
				.executeSupplier(() -> finalWebTarget
						.request(MediaType.APPLICATION_JSON_TYPE)
						.header(ACCEPT_LANGUAGE, lang)
						.header(AUTHORIZATION, authorizationStrategy.getAuthorization(user))
						.get(new GenericType<InfiniteListResultsImpl<RelationRoleResponseV1>>() {
						}));
	}

	@Override
	public RelationRoleResponseV1 getByCode(String lang, User user, String typeCode, String code) {
		String tenantId = user.getTenant();

		WebTarget webTarget = relationRoleTarget.path("/{code}")
				.resolveTemplate("tenant", tenantId)
				.resolveTemplate("relationTypeCode", typeCode)
				.resolveTemplate("code", code);

		return retryRegistry.retry(webTarget.getUri().toString())
				.executeSupplier(() -> webTarget
						.request(MediaType.APPLICATION_JSON_TYPE)
						.header(ACCEPT_LANGUAGE, lang)
						.header(AUTHORIZATION, authorizationStrategy.getAuthorization(user))
						.get(new GenericType<>() {
						}));
	}
}
