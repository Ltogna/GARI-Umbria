package com.abacogroup.partyregistry.api.v1.req;

import jakarta.ws.rs.QueryParam;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

@Data
@NoArgsConstructor
@Accessors(chain = true)
public class RelationTypeSearchRequestV1 {

	@QueryParam("code")
	private String code;

	@QueryParam("i18nCode")
	private String i18nCode;

	@QueryParam("flMultiple")
	private Integer flMultiple;
}
