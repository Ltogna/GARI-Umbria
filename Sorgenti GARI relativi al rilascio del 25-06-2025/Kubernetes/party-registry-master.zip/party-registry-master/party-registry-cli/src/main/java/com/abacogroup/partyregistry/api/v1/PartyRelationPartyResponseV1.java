package com.abacogroup.partyregistry.api.v1;

import com.abacogroup.jdbi.datatype.AbsoluteDate;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;
import org.jdbi.v3.core.mapper.Nested;

@Data
@SuperBuilder(setterPrefix = "set")
@NoArgsConstructor
public class PartyRelationPartyResponseV1 {

	private Long pkid;

	private Long partyRelationId;  //PK
	private Long relatedPartyId; //PK / the relation target
	private String firstName;
	private String lastName;
	private Long relationRoleId; //PK

	private AbsoluteDate dtStart;
	private AbsoluteDate dtEnd;

	private Long relationTypeId; // dto  //1 AZIENDA

	/**
	 * the relation owner
	 */
	private Long partyRelationPartyId; // the relation owner

	private String relatedRoleCode; //dto // azienda_SOCIO
	private String relationRoleI18nCode;

	private String relationTypeCode; //    //AZIENDA
	private String relationTypeI18nCode;
	private Boolean hasMandates;
	
	@Nested("party_relation")
	private PartyRelationResponseV1 partyRelation;

/*	@Nested("relation_role")
	private RelationRole relationRole;*/
}
