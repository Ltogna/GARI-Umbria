package com.abacogroup.partyregistry.core.cli.v1;

import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.partyregistry.api.v1.PartyResponseV1;
import com.abacogroup.partyregistry.api.v1.PartySearchResponseV1;
import com.abacogroup.partyregistry.api.v1.req.PartySearchRequestV1;
import java.util.List;

public interface PartyClientV1 {

	InfiniteListResults<PartySearchResponseV1> search(String lang, User user, String nextKey, PartySearchRequestV1 searchRequest);

	PartyResponseV1 getById(String lang, User user, Long id);

	List<PartyResponseV1> getByIds(String lang, User user, List<Long> ids);

	PartyResponseV1 getByCode(String lang, User user, String code);
}
