package com.abacogroup.partyregistry.api.v1;

import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.partyregistry.api.v1.lau.MunicipalityResponseV1;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

/**
 * v1
 */
@Data
@SuperBuilder(setterPrefix = "set")
@NoArgsConstructor
public class PartySearchResponseV1 {

	private Long id;
	private String partyType;

	private String lastName;
	private String firstName;

	private String taxCode;
	private String vatNumber;
	private String code;
	private String legalStatus;

	private AbsoluteDate birthDate;
	private AbsoluteDate deathDate;

	private String birthMunicipality;
	private MunicipalityResponseV1 birthMunicipalityDetail;
	private String nationality;

	private AddressResponseV1 addressResidential;

	private boolean archived = false;

}
