package com.abacogroup.partyregistry.api.v1;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

/**
 * V1
 */
@Data
@SuperBuilder(setterPrefix = "set")
@NoArgsConstructor
@AllArgsConstructor
public class TagResponseV1 {

	private Long id;
	private String code;
	private String i18nCode;
}
