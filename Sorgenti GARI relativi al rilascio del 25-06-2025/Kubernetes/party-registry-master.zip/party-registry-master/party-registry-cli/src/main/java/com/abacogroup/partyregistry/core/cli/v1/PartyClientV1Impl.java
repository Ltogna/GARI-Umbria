package com.abacogroup.partyregistry.core.cli.v1;

import static com.abacogroup.partyregistry.resources.PublicResourceConstants.API_V1_PUB;
import static jakarta.ws.rs.core.HttpHeaders.ACCEPT_LANGUAGE;
import static jakarta.ws.rs.core.HttpHeaders.AUTHORIZATION;

import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.jdbi.paging.impl.InfiniteListResultsImpl;
import com.abacogroup.partyregistry.api.v1.PartyResponseV1;
import com.abacogroup.partyregistry.api.v1.PartySearchResponseV1;
import com.abacogroup.partyregistry.api.v1.req.PartyByIdInSearchRequestV1;
import com.abacogroup.partyregistry.api.v1.req.PartySearchRequestV1;
import com.abacogroup.partyregistry.core.cli.AuthorizationStrategy;
import com.abacogroup.partyregistry.core.cli.impl.TokenRelayStrategy;
import com.abacogroup.partyregistry.utils.ClientUtils;
import io.github.resilience4j.retry.RetryConfig;
import io.github.resilience4j.retry.RetryRegistry;
import jakarta.ws.rs.ProcessingException;
import jakarta.ws.rs.ServerErrorException;
import jakarta.ws.rs.client.Entity;
import jakarta.ws.rs.client.WebTarget;
import jakarta.ws.rs.core.GenericType;
import jakarta.ws.rs.core.MediaType;
import java.time.Duration;
import java.util.List;

public class PartyClientV1Impl implements PartyClientV1 {

	private final WebTarget partyTarget;
	private final AuthorizationStrategy authorizationStrategy;

	private RetryRegistry retryRegistry;

	public PartyClientV1Impl(WebTarget prtBaseTarget, AuthorizationStrategy authorizationStrategy) {
		this.partyTarget = prtBaseTarget.path(String.format("%s/%s", API_V1_PUB, "parties"));
		this.authorizationStrategy = authorizationStrategy;

		this.retryRegistry = RetryRegistry.of(RetryConfig.custom()
				.maxAttempts(2)
				.waitDuration(Duration.ofMillis(500))
				.failAfterMaxAttempts(true)
				.retryExceptions(ProcessingException.class, ServerErrorException.class)
				.build());
	}

	public PartyClientV1Impl(WebTarget prtBaseTarget) {
		this(prtBaseTarget, new TokenRelayStrategy());
	}

	@Override
	public InfiniteListResults<PartySearchResponseV1> search(String lang, User user, String nextKey,
			PartySearchRequestV1 searchRequest) {

		String tenantId = user.getTenant();

		WebTarget webTarget = partyTarget.resolveTemplate("tenant", tenantId);

		WebTarget finalWebTarget = ClientUtils.addQueryParams(nextKey, searchRequest, webTarget);

		InfiniteListResultsImpl<PartySearchResponseV1> results = retryRegistry.retry(webTarget.getUri().toString())
				.executeSupplier(() -> finalWebTarget
						.request(MediaType.APPLICATION_JSON_TYPE)
						.header(ACCEPT_LANGUAGE, lang)
						.header(AUTHORIZATION, authorizationStrategy.getAuthorization(user))
						.get(new GenericType<>() {
						}));

		return results;
	}

	@Override
	public PartyResponseV1 getById(String lang, User user, Long id) {

		String tenantId = user.getTenant();

		WebTarget webTarget = partyTarget.path("{id}")
				.resolveTemplate("tenant", tenantId)
				.resolveTemplate("id", id);

		PartyResponseV1 result = retryRegistry.retry(webTarget.getUri().toString())
				.executeSupplier(() -> webTarget
						.request(MediaType.APPLICATION_JSON_TYPE)
						.header(ACCEPT_LANGUAGE, lang)
						.header(AUTHORIZATION, authorizationStrategy.getAuthorization(user))
						.get(new GenericType<>() {
						}));

		return result;
	}

	@Override
	public List<PartyResponseV1> getByIds(String lang, User user, List<Long> ids) {
		String tenantId = user.getTenant();

		WebTarget webTarget = partyTarget.path("")
				.resolveTemplate("tenant", tenantId);

		List<PartyResponseV1> result = retryRegistry.retry(webTarget.getUri().toString())
				.executeSupplier(() -> webTarget
						.request(MediaType.APPLICATION_JSON_TYPE)
						.header(ACCEPT_LANGUAGE, lang)
						.header(AUTHORIZATION, authorizationStrategy.getAuthorization(user))
						.post(Entity.json(new PartyByIdInSearchRequestV1().setIds(ids)),
								new GenericType<>() {
								}
						));
		return result;
	}

	@Override
	public PartyResponseV1 getByCode(String lang, User user, String code) {

		String tenantId = user.getTenant();

		WebTarget webTarget = partyTarget.path("code/{code}")
				.resolveTemplate("tenant", tenantId)
				.resolveTemplate("code", code);

		PartyResponseV1 result = retryRegistry.retry(webTarget.getUri().toString())
				.executeSupplier(() -> webTarget
						.request(MediaType.APPLICATION_JSON_TYPE)
						.header(ACCEPT_LANGUAGE, lang)
						.header(AUTHORIZATION, authorizationStrategy.getAuthorization(user))
						.get(new GenericType<>() {
						}));

		return result;
	}
}
