package com.abacogroup.partyregistry.dto.v1;

import com.abacogroup.dynamicdocuments.bean.InsertDocument;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import java.util.List;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder(setterPrefix = "set")
@NoArgsConstructor
@Accessors(chain = true)
public class ExternalSourceDtoV1 {

	@NotNull
	@Valid
	private PartyExternalDtoV1 partyData;

	@Valid
	private List<InsertDocument> documents;

	@Valid
	private List<PartyRelationExternalDtoV1> relations;

	@Valid
	private List<PartyContactExternalDtoV1> contacts;

}
