package com.abacogroup.partyregistry.core.cli.v1;

import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.partyregistry.api.v1.LegalStatusResponseV1;
import com.abacogroup.partyregistry.api.v1.req.LegalStatusSearchRequestV1;

public interface LegalStatusClientV1 {

	InfiniteListResults<LegalStatusResponseV1> search(String lang, User user, String nextKey, LegalStatusSearchRequestV1 searchRequest);

	LegalStatusResponseV1 getByCode(String lang, User user, String code);
}
