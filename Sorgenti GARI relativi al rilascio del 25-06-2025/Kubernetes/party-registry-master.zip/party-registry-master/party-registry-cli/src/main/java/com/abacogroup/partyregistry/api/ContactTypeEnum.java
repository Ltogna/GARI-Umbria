package com.abacogroup.partyregistry.api;

public enum ContactTypeEnum {
	EMAIL,
	PEC,
	PHONE
}

