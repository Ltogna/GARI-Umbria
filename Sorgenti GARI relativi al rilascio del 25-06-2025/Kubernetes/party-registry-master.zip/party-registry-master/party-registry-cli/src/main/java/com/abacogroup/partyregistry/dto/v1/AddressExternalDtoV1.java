package com.abacogroup.partyregistry.dto.v1;

import java.io.Serializable;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder(setterPrefix = "set")
@NoArgsConstructor
@Accessors(chain = true)
public class AddressExternalDtoV1 implements Serializable {

	/**
	 * code from /{tenant}/public/v1/municipalities in lau-service
	 */
	private String municipality;
	private String locality;
	private String street;
	private String houseNumber;
	private String postcode;
	private String details;
	private String note;
}
