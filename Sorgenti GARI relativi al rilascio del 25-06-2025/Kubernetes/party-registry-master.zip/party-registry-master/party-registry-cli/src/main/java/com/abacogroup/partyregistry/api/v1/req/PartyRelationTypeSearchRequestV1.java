package com.abacogroup.partyregistry.api.v1.req;

import jakarta.ws.rs.QueryParam;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

@Data
@NoArgsConstructor
@Accessors(chain = true)
public class PartyRelationTypeSearchRequestV1 {

//	@Parameter(in = ParameterIn.QUERY, description = "relation type Code")
	@QueryParam("relationTypeCode")
	private String relationTypeCode;

//	@Parameter(in = ParameterIn.QUERY, description = "note")
	@QueryParam("note")
	private String note;

}
