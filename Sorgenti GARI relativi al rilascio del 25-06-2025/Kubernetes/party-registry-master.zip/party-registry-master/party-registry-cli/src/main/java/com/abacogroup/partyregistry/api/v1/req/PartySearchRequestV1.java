package com.abacogroup.partyregistry.api.v1.req;

import com.abacogroup.partyregistry.api.InfiniteSearchRequest;
import com.abacogroup.partyregistry.resources.req.ArchivedEnum;
import com.fasterxml.jackson.annotation.JsonIgnore;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import jakarta.ws.rs.DefaultValue;
import jakarta.ws.rs.QueryParam;
import java.util.List;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

@Data
@NoArgsConstructor
@Accessors(chain = true)
public class PartySearchRequestV1 implements InfiniteSearchRequest {

	@Parameter(in = ParameterIn.QUERY, description = "last name")
	@QueryParam("lastName")
	private String lastName;

	@Parameter(in = ParameterIn.QUERY, description = "first name")
	@QueryParam("firstName")
	private String firstName;
	
	@Parameter(in = ParameterIn.QUERY, description = "party type")
	@QueryParam("partyType")
	private String partyType;

	@Parameter(in = ParameterIn.QUERY, description = "TAX code")
	@QueryParam("taxCode")
	private String taxCode;

	@Parameter(in = ParameterIn.QUERY, description = "VAT number")
	@QueryParam("vatNumber")
	private String vatNumber;

	@Parameter(in = ParameterIn.QUERY, description = "vat number / tax code")
	@QueryParam("taxOrVat")
	private String taxOrVat;

	@Parameter(in = ParameterIn.QUERY, description = "code, if code is not supported by the configuration, this parameter overrides taxOrVat")
	@QueryParam("code")
	private String code;

	@Parameter(in = ParameterIn.QUERY, description = "hasCode")
	@QueryParam("hasCode")
	private Boolean hasCode;

	@Parameter(in = ParameterIn.QUERY, description = "fullName")
	@QueryParam("fullName")
	private String fullName;
	@Parameter(in = ParameterIn.QUERY, description = "fullNameOrCode")
	@QueryParam("fullNameOrCode")
	private String fullNameOrCode;

	@Parameter(in = ParameterIn.QUERY, description = "list of tags")
	@QueryParam("tag")
	private List<String> tag;

	@Parameter(in = ParameterIn.QUERY, description = "archived status")
	@DefaultValue("not_archived")
	@QueryParam("archived")
	private ArchivedEnum archived;

	@Override
	@JsonIgnore
	public int getPageSize() {
		return PAGE_SIZE;
	}

}
