package com.abacogroup.partyregistry.api.v1.req;

import com.abacogroup.partyregistry.api.ContactTypeEnum;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.QueryParam;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

@Data
@NoArgsConstructor
@Accessors(chain = true)
public class ContactSearchRequestV1 {

//	@Parameter(in = ParameterIn.PATH, description = "the party ID")
	@PathParam("partyId")
	private Long partyId;

//	@Parameter(in = ParameterIn.QUERY, description = "the contact type")
	@QueryParam("contactType")
	private ContactTypeEnum contactType;

//	@Parameter(in = ParameterIn.QUERY, description = "the sub type of contact")
	@QueryParam("subType")
	private String subType;

//	@Parameter(in = ParameterIn.QUERY, description = "the contact value")
	@QueryParam("contactValue")
	private String contactValue;
}
