package com.abacogroup.partyregistry.core.cli.v1;

import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.partyregistry.api.v1.CitizenshipResponseV1;
import com.abacogroup.partyregistry.api.v1.req.CitizenshipSearchRequestV1;

public interface CitizenshipClientV1 {
	InfiniteListResults<CitizenshipResponseV1> search(String lang, User user, String nextKey, CitizenshipSearchRequestV1 searchRequest);
	
	CitizenshipResponseV1 getByCode(String lang, User user, String code);
}
