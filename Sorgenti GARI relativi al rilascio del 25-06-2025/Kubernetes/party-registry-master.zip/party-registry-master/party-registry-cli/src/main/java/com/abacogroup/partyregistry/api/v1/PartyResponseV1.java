package com.abacogroup.partyregistry.api.v1;

import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.partyregistry.api.BasePartyResponse;
import com.abacogroup.partyregistry.api.v1.lau.MunicipalityResponseV1;
import java.util.List;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

/**
 * PARTY V1
 */
@Data
@NoArgsConstructor
@Accessors(chain = true)
public class PartyResponseV1 implements BasePartyResponse {

	private Long id;
	private String partyType;
	private String gender;
	private String lastName;
	private String firstName;
	private String taxCode;
	private String vatNumber;
	private String code;
	private String legalStatus;
	private AbsoluteDate birthDate;
	private AbsoluteDate deathDate;
	private String birthMunicipality;
	private MunicipalityResponseV1 birthMunicipalityDetail;
	private String nationality;
	private AddressResponseV1 addressResidential;
	private AddressResponseV1 addressHome;
	private AddressResponseV1 addressBilling;

	private List<TagResponseV1> tags;

	//TODO DISCUTERE @ColumnName("fl_archived")
	private boolean archived = false;

	private ExternalSourceResponseV1 externalSource;
}
