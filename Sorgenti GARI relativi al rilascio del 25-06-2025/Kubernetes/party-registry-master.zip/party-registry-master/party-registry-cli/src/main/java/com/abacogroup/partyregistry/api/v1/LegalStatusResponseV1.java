package com.abacogroup.partyregistry.api.v1;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@NoArgsConstructor
@SuperBuilder(setterPrefix = "set")
public class LegalStatusResponseV1 {

	private String code;
	private String i18nCode;
}
