package com.abacogroup.partyregistry.core.cli;

import com.abacogroup.dropwizard.auth.sso2.User;

public interface AuthorizationStrategy {

	String getAuthorization(User user);
}
