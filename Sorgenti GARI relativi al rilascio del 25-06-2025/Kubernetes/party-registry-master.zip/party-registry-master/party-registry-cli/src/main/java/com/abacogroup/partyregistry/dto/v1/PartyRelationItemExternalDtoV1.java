package com.abacogroup.partyregistry.dto.v1;

import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.jdbi.model.AuditEntity;
import com.fasterxml.jackson.annotation.JsonSetter;
import com.fasterxml.jackson.annotation.Nulls;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder(setterPrefix = "set")
@NoArgsConstructor
@Accessors(chain = true)
public class PartyRelationItemExternalDtoV1 {

	@NotBlank
	private String roleCode;

	@NotNull
	@Valid
	private AbsoluteDate dtStart;

	@JsonSetter(nulls = Nulls.SKIP)
	@Valid
	private AbsoluteDate dtEnd = AbsoluteDate.of(AuditEntity.dateActive);

	@NotNull
	@Valid
	private PartyExternalDtoV1 partyData;
}

