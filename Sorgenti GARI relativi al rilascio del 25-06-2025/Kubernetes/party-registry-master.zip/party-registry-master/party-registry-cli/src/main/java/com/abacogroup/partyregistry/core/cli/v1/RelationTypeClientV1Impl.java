package com.abacogroup.partyregistry.core.cli.v1;

import static com.abacogroup.partyregistry.resources.PublicResourceConstants.API_V1_PUB;
import static jakarta.ws.rs.core.HttpHeaders.ACCEPT_LANGUAGE;
import static jakarta.ws.rs.core.HttpHeaders.AUTHORIZATION;

import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.jdbi.paging.impl.InfiniteListResultsImpl;
import com.abacogroup.partyregistry.api.v1.RelationTypeResponseV1;
import com.abacogroup.partyregistry.api.v1.req.RelationTypeSearchRequestV1;
import com.abacogroup.partyregistry.core.cli.AuthorizationStrategy;
import com.abacogroup.partyregistry.core.cli.impl.TokenRelayStrategy;
import com.abacogroup.partyregistry.utils.ClientUtils;
import io.github.resilience4j.retry.RetryConfig;
import io.github.resilience4j.retry.RetryRegistry;
import jakarta.ws.rs.ProcessingException;
import jakarta.ws.rs.ServerErrorException;
import jakarta.ws.rs.client.WebTarget;
import jakarta.ws.rs.core.GenericType;
import jakarta.ws.rs.core.MediaType;
import java.time.Duration;

public class RelationTypeClientV1Impl implements RelationTypeClientV1 {

	private final WebTarget relationTypeTarget;
	private final AuthorizationStrategy authorizationStrategy;

	private RetryRegistry retryRegistry;

	public RelationTypeClientV1Impl(WebTarget prtBaseTarget, AuthorizationStrategy authorizationStrategy) {
		this.relationTypeTarget = prtBaseTarget.path(String.format("%s/%s", API_V1_PUB, "relation-types"));
		this.authorizationStrategy = authorizationStrategy;

		this.retryRegistry = RetryRegistry.of(RetryConfig.custom()
				.maxAttempts(2)
				.waitDuration(Duration.ofMillis(500))
				.failAfterMaxAttempts(true)
				.retryExceptions(ProcessingException.class, ServerErrorException.class)
				.build());
	}

	public RelationTypeClientV1Impl(WebTarget prtBaseTarget) {
		this(prtBaseTarget, new TokenRelayStrategy());
	}

	@Override
	public InfiniteListResults<RelationTypeResponseV1> search(String lang, User user, String nextKey, RelationTypeSearchRequestV1 searchRequest) {
		String tenantId = user.getTenant();

		WebTarget webTarget = relationTypeTarget.resolveTemplate("tenant", tenantId);
		WebTarget finalWebTarget = ClientUtils.addQueryParams(nextKey, searchRequest, webTarget);

		return retryRegistry.retry(webTarget.getUri().toString())
				.executeSupplier(() -> finalWebTarget
						.request(MediaType.APPLICATION_JSON_TYPE)
						.header(ACCEPT_LANGUAGE, lang)
						.header(AUTHORIZATION, authorizationStrategy.getAuthorization(user))
						.get(new GenericType<InfiniteListResultsImpl<RelationTypeResponseV1>>() {
						}));
	}

	@Override
	public RelationTypeResponseV1 getByCode(String lang, User user, String code) {
		String tenantId = user.getTenant();

		WebTarget webTarget = relationTypeTarget.path("/{code}")
				.resolveTemplate("tenant", tenantId)
				.resolveTemplate("code", code);

		return retryRegistry.retry(webTarget.getUri().toString())
				.executeSupplier(() -> webTarget
						.request(MediaType.APPLICATION_JSON_TYPE)
						.header(ACCEPT_LANGUAGE, lang)
						.header(AUTHORIZATION, authorizationStrategy.getAuthorization(user))
						.get(new GenericType<>() {
						}));
	}
}
