package com.abacogroup.partyregistry.resources;

public interface PublicResourceConstants {

	String API_V1_PUB = "/{tenant}/public/v1";

}
