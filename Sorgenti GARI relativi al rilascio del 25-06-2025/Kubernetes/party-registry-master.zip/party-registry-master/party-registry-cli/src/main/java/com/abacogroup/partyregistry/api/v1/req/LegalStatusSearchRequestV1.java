package com.abacogroup.partyregistry.api.v1.req;

import jakarta.ws.rs.QueryParam;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

@Data
@NoArgsConstructor
@Accessors(chain = true)
public class LegalStatusSearchRequestV1 {

	//@Parameter(in = ParameterIn.QUERY, description = "Legal Status code")
	@QueryParam("code")
	private String code;

	//@Parameter(in = ParameterIn.QUERY, description = "Legal Status i18n code ")
	@QueryParam("i18nCode")
	private String i18nCode;
}
