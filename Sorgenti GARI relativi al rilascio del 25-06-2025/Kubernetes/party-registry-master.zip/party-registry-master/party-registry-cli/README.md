# party-registry-cli

[TOC]

## Usage

define client in configuration

```java
import io.dropwizard.Configuration;

public class MyServiceConfiguration extends Configuration {

	@Valid
	@NotNull
	@Getter
	@Setter
	private JerseyClientConfiguration jerseyClient = new JerseyClientConfiguration();

}
```

create prt client in Application

```java
public class MyServiceApplication extends Application<MyServiceConfiguration> {

	// [...]

	@Override
	public void run(final MyServiceConfiguration configuration, final Environment environment) {

		// [...]

		WebTarget webTarget = this.initPrtTarget(configuration, environment);

		PartyClientV1 partyClient = this.register(new PartyClientV1Impl(webTarget, new NoopAuthorizationStrategy())); // 1
		PartyClientV1 partyTokenRelayClient = this.register(new PartyClientV1Impl(webTarget, new TokenRelayStrategy())); // 2

		CitizenshipClientV1 citizenshipClientV1 = this.register(new CitizenshipClientV1Impl(webTarget, new TokenRelayStrategy()));
		LegalStatusClientV1 legalStatusClientV1 = this.register(new LegalStatusClientV1Impl(webTarget, new TokenRelayStrategy()));

		// [...]
	}

	protected WebTarget initPrtTarget(MyServiceConfiguration configuration, Environment environment) {
		final Client client = new JerseyClientBuilder(environment).using(configuration.getJerseyClient()).build("prt-client");
		WebTarget prt = client.target("http://localhost:8080/party-registry");
		return prt;
	}

	// [...]
}
```

1. `NoopAuthorizationStrategy` -> make calls without Authorization header
2. `TokenRelayStrategy` -> propagate current user's token

## Available clients

### PartyClientV1

- GET `/{tenant}/public/v1/parties` search party
- GET `/{tenant}/public/v1/parties/{id}` party by id
- GET `/{tenant}/public/v1/parties/code/{code}` party by code
- POST `/{tenant}/public/v1/parties` get parties by id list

### CitizenshipClientV1

- GET `/{tenant}/public/v1/citizenships` search Citizenship
- GET `/{tenant}/public/v1/citizenships/{code}` Citizenship by code

### LegalStatusClientV1

- GET `/{tenant}/public/v1/legal-status` search LegalStatus
- GET `/{tenant}/public/v1/legal-status/{code}` LegalStatus by code

### RelationTypeClientV1

- GET `/{tenant}/public/v1/relation-types` search RelationType
- GET `/{tenant}/public/v1/relation-types/{code}` RelationType by code

### RelationRoleClientV1

- GET `/{tenant}/public/v1/relation-types/{relationTypeCode}/roles` search RelationRole
- GET `/{tenant}/public/v1/relation-types/{relationTypeCode}/roles/{code}` RelationRole by code
