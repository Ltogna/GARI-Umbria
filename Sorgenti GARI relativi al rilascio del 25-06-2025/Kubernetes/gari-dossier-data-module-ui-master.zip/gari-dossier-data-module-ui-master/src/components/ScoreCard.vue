<script setup lang="ts">
import { inject, onMounted, ref } from "vue";
import BiProgressIndicator from "@abaco/bootstrap-italia-components/src/components/BiProgressIndicator/BiProgressIndicator.vue";
import BiButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiButton.vue";
import useColors from "@abaco/bootstrap-italia-components/src/composables/useColors";
import { useI18n } from "vue-i18n";
import { useUnificataFormsStore } from "@/stores/unificataFormsStore";
import type {
	SaveScoreCardModel,
	ScoreCardDeclarationModel,
	ScoreCardDefinitionModel,
	ScoreCardGroupModel,
} from "@/models/unificataForms";
import BiRadiobutton from "@abaco/bootstrap-italia-components/src/components/form/BiRadiobutton.vue";
import BiAlert from "@abaco/bootstrap-italia-components/src/components/BiAlert/BiAlert.vue";
import BiCheckbox from "@abaco/bootstrap-italia-components/src/components/form/BiCheckbox.vue";

const { getColor } = useColors();
const { t } = useI18n({});
const emit = defineEmits(["changePage"]);
const unificataFormsStore = useUnificataFormsStore();

const loadingData = ref<boolean>(false);
const isValid = ref<boolean>(true);
const moduleId = inject("moduleId");
const scoreCardDefinition = ref<ScoreCardDefinitionModel>();

const declarationsNumber = ref<number>(0);
const choicesList = ref<Record<string, string>>({});

const yesTranslation = ref<string>(t(`${moduleId}.general.yes`));
const noTranslation = ref<string>(t(`${moduleId}.general.no`));

const noScoreSelected = ref<boolean>(false);

const props = defineProps<{
	isReadOnly: boolean;
	compileStatusIdentifier: string;
	formCode: string;
	optionCode: string;
	optionDescription: string;
}>();

onMounted(async () => {
	loadData();
});

function changePage(back: boolean) {
	if (back) emit("changePage", "commits-from-start");
}

async function loadData() {
	loadingData.value = true;
	declarationsNumber.value = 0;

	await unificataFormsStore.loadScoreCardDefinition(props.optionCode);
	scoreCardDefinition.value = unificataFormsStore.getScoreCardDefinition;

	if (scoreCardDefinition.value)
		scoreCardDefinition.value.forEach(group => {
			declarationsNumber.value += group.scoreList.length;
			group.scoreList.forEach(decl => {
				if (decl.selected) choicesList.value[decl.code] = yesTranslation.value;
				else if (decl.selected === false)
					choicesList.value[decl.code] = noTranslation.value;
			});
		});

	calculateNoScore();
	loadingData.value = false;
}

function calculateNoScore() {
	const choicesListValues = Object.values(choicesList.value);

	noScoreSelected.value =
		Object.keys(choicesList.value).length === 0 ||
		(choicesListValues.findIndex(choice => choice === yesTranslation.value) ===
			-1 &&
			choicesListValues.length === declarationsNumber.value);
}

function saveScoreCard() {
	const choicesListCodes = Object.keys(choicesList.value);
	if (
		choicesListCodes.length !== declarationsNumber.value &&
		!noScoreSelected.value
	) {
		isValid.value = false;
		return;
	}
	isValid.value = true;
	const listToSave: SaveScoreCardModel = [];
	choicesListCodes.forEach(key => {
		const choice = {
			scoreCode: key,
			value:
				choicesList.value[key] === t(`${moduleId}.general.yes`) ? true : false,
		};

		listToSave.push(choice);
	});

	unificataFormsStore.saveScoreCard(
		props.optionCode,
		listToSave,
		props.compileStatusIdentifier,
		props.formCode
	);
}

function setExclusivity(
	value: string,
	declaration: ScoreCardDeclarationModel,
	group: ScoreCardGroupModel
) {
	if (value === t(`${moduleId}.general.yes`)) {
		group.scoreList.forEach(decl => {
			if (decl.code !== declaration.code)
				choicesList.value[decl.code] = t(`${moduleId}.general.no`);
		});
	}
	calculateNoScore();
}

function setNoScore() {
	choicesList.value = {};
	noScoreSelected.value = true;
}
</script>
<style scoped>
.score-width {
	min-width: 70px;
}

.declaration-width {
	flex-grow: 1;
	align-self: center;
}

.radio-width {
	width: min-content;
	display: inline-flex;
}

.bg-head {
	background-color: rgb(233, 230, 242);
}

.pointer-events-none {
	pointer-events: none;
}
</style>
<template>
	<div class="row my-2 align-items-center">
		<div class="my-3">
			<h4 class="title" :class="getColor('text', 'primary')">
				{{ optionDescription }}
			</h4>
		</div>
	</div>
	<div v-if="loadingData" class="d-flex row justify-content-center mb-3 mt-5">
		<div class="d-flex col-2 justify-content-center px-0">
			<BiProgressIndicator type="spinner"></BiProgressIndicator>
		</div>
	</div>
	<div v-else>
		<div
			v-for="(group, groupIndex) in scoreCardDefinition"
			:key="group.code"
			class="border"
			:class="!!group.title && groupIndex !== 0 ? 'mt-4' : 'mt-2'">
			<div class="bg-head">
				<div v-if="!!group.title" class="border-bottom p-2 text-center">
					<h5>
						<strong>{{ group.title }}</strong>
					</h5>
				</div>
				<div class="border-bottom d-flex justify-content-between">
					<span class="px-2 py-1 declaration-width">
						<strong>{{ group.subtitle }}</strong>
					</span>
					<span class="px-2 py-1 text-uppercase border-start score-width">
						<strong>{{ t(`${moduleId}.helpStandardForm.points`) }}</strong>
					</span>
				</div>
			</div>

			<div
				v-for="(declaration, index) in group.scoreList"
				:key="group.code + '-' + declaration.code"
				class="d-flex"
				:class="index !== 0 ? 'border-top' : ''">
				<div class="ps-2 border-end radio-width">
					<BiRadiobutton
						v-model="choicesList[declaration.code]"
						:name="group.code + '-' + declaration.code"
						@update:model-value="
							value => {
								setExclusivity(value, declaration, group);
							}
						"
						:label="t(`${moduleId}.general.yes`)"
						:value="t(`${moduleId}.general.yes`)"
						:is-inline="true"
						:is-disabled="isReadOnly" />
					<BiRadiobutton
						v-model="choicesList[declaration.code]"
						:name="group.code + '-' + declaration.code"
						@update:model-value="
							value => {
								setExclusivity(value, declaration, group);
							}
						"
						:label="t(`${moduleId}.general.no`)"
						:value="t(`${moduleId}.general.no`)"
						:is-inline="true"
						:is-disabled="isReadOnly" />
				</div>
				<div class="declaration-width px-2">
					<strong>{{ declaration.subCode }}</strong>
					<span class="ps-2 text-break">{{ declaration.description }}</span>
				</div>
				<div class="px-2 border-start w-5 text-center score-width">
					<div class="d-flex flex-column justify-content-center h-100">
						<strong>{{ declaration.score }}</strong>
					</div>
				</div>
			</div>
		</div>
		<BiCheckbox
			:model-value="noScoreSelected"
			:is-disabled="isReadOnly"
			:label="t(`${moduleId}.helpStandardForm.noScore`)"
			:class="noScoreSelected ? 'pointer-events-none' : ''"
			@update:model-value="setNoScore"></BiCheckbox>
		<BiAlert isError v-if="isValid === false">
			<template #body>
				{{ t(`${moduleId}.helpStandardForm.requirements`) }}
			</template>
		</BiAlert>
		<div class="mb-5 mt-3 pt-3 d-flex justify-content-center">
			<BiButton
				v-if="!unificataFormsStore.loading"
				isPrimary
				class="mx-1"
				:class="getColor('button', 'primary', 'outline')"
				@click="changePage(true)">
				{{ t(`${moduleId}.standardForm.backToOptions`) }}
			</BiButton>
			<BiButton
				v-if="!isReadOnly && !unificataFormsStore.loading"
				type="submit"
				form="declarationsForm"
				class="mx-1"
				:class="getColor('button', 'success')"
				@click="saveScoreCard()">
				{{ t(`${moduleId}.general.saveCard`) }}
			</BiButton>
			<BiProgressIndicator
				v-if="unificataFormsStore.loading"
				type="spinner"></BiProgressIndicator>
		</div>
	</div>
</template>
