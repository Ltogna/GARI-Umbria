<script setup lang="ts">
import type { AskForConfirmation } from "@abaco/micro-frontend/src/model";
import { inject } from "vue";
import { useI18n } from "vue-i18n";
import TMModalComponent from "./TMModalComponent.vue";

defineProps<{
	ask: AskForConfirmation;
}>();

const { t } = useI18n({});
const moduleId = inject("moduleId");

const emit = defineEmits<{
	(e: "confirm", ok: boolean): void;
}>();

function confirm(ok: boolean) {
	emit("confirm", ok);
}

function confirmOk() {
	confirm(true);
}

function confirmKo() {
	confirm(false);
}
</script>

<template>
	<div>
		<TMModalComponent
			:open-modal="true"
			:is-loading="false"
			:ariaLabelledBy="'askConfirm'"
			:modal-title-text="ask.title ?? ''"
			:cancel-button-text="t(`${moduleId}.micro.child.cancel`)"
			:confirm-button-text="t(`${moduleId}.micro.child.confirm`)"
			:confirm-function="confirmOk"
			:cancel-function="confirmKo"
			:prevent-dismiss="true">
			<template v-slot:body>
				{{ ask.message }}
			</template>
		</TMModalComponent>
	</div>
</template>
