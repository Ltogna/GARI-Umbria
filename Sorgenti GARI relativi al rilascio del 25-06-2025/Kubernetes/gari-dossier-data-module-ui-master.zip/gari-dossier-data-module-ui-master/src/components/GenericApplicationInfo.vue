<script setup lang="ts">
import { inject } from "vue";
import { useI18n } from "vue-i18n";
import BiIcon from "@abaco/bootstrap-italia-components/src/components/BiIcon/BiIcon.vue";
import { getFormattedDate } from "@/utils/dateUtils";
import useColors from "@abaco/bootstrap-italia-components/src/composables/useColors";
import type { WithdrawalApplicationDetailsModel } from "@/models/unificataForms";

const moduleId = inject("moduleId");
const { getColor } = useColors();
const { t } = useI18n({});
defineProps<{
	application: WithdrawalApplicationDetailsModel | undefined;
}>();
</script>
<style scoped>
.sub-title-dim {
	font-size: 1.111em;
}

.cursor-pointer {
	cursor: pointer;
}
</style>
<template>
	<div class="container">
		<div class="mt-3">
			<h4 class="fw-bold" :class="getColor('text', 'primary')">
				<BiIcon icon="file-lines" size="lg" />
				{{
					t(`${moduleId}.withdrawalApplication.genericDetail.applicationForm`)
				}}
			</h4>
		</div>
		<div>
			<strong class="text-secondary me-1">
				{{ t(`${moduleId}.withdrawalApplication.genericDetail.cuaa`) }}:
			</strong>
			<span class="text-secondary">{{ application?.cuaa }}</span>
		</div>
		<div>
			<strong class="text-secondary me-1">
				{{ t(`${moduleId}.withdrawalApplication.genericDetail.name`) }}:
			</strong>
			<span class="text-secondary">{{ application?.denomination }}</span>
		</div>
		<div>
			<strong class="text-secondary me-1">
				{{ t(`${moduleId}.withdrawalApplication.genericDetail.sector`) }}:
			</strong>
			<span class="text-secondary">{{ application?.sectorDescription }}</span>
		</div>
		<div>
			<strong class="text-secondary me-1">
				{{ t(`${moduleId}.withdrawalApplication.genericDetail.module`) }}:
			</strong>
			<span class="text-secondary">{{ application?.moduleDescription }}</span>
		</div>
		<div>
			<strong class="text-secondary me-1">
				{{ t(`${moduleId}.withdrawalApplication.genericDetail.year`) }}:
			</strong>
			<span class="text-secondary">{{ application?.referredYear }}</span>
		</div>
		<!-- Detail information -->
		<div class="mb-2 mt-5">
			<h4 class="fw-bold" :class="getColor('text', 'primary')">
				<BiIcon icon="file-lines" size="lg" />
				{{
					t(
						`${moduleId}.withdrawalApplication.genericDetail.detailedInformation`
					)
				}}
			</h4>
		</div>
		<div>
			<strong class="text-secondary me-1">
				{{
					t(`${moduleId}.withdrawalApplication.genericDetail.submissionDate`)
				}}:
			</strong>
			<span class="text-secondary">
				{{
					application?.dtPresentation
						? getFormattedDate(application?.dtPresentation, true)
						: ""
				}}
			</span>
		</div>
		<div>
			<strong class="text-secondary me-1">
				{{ t(`${moduleId}.withdrawalApplication.genericDetail.protocolDate`) }}:
			</strong>
			<span class="text-secondary">
				{{
					application?.dtProtocol
						? getFormattedDate(application?.dtProtocol, false)
						: ""
				}}
			</span>
		</div>
		<div>
			<strong class="text-secondary me-1">
				{{
					t(`${moduleId}.withdrawalApplication.genericDetail.protocolNuber`)
				}}:
			</strong>
			<span class="text-secondary">{{ application?.protocolId }}</span>
		</div>
	</div>
</template>
