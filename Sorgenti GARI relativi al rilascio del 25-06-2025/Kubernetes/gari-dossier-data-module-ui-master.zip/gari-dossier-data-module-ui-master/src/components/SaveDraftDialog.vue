<script setup lang="ts">
import BiAlert from "@abaco/bootstrap-italia-components/src/components/BiAlert/BiAlert.vue";
import { inject } from "vue";
import { useI18n } from "vue-i18n";
import TMModalComponent from "./TMModalComponent.vue";

const { t } = useI18n({});
const moduleId = inject("moduleId");

defineProps<{
	closeModal: boolean;
}>();

const emit = defineEmits<{
	(e: "confirm", ok: boolean): void;
}>();

function confirm(ok: boolean) {
	emit("confirm", ok);
}

function confirmOk() {
	confirm(true);
}

function confirmKo() {
	confirm(false);
}
</script>

<template>
	<div>
		<TMModalComponent
			:open-modal="closeModal"
			:is-loading="false"
			:ariaLabelledBy="'askConfirm'"
			:modal-title-text="t(`${moduleId}.saveDraft.title`)"
			:cancel-button-text="t(`${moduleId}.saveDraft.cancel`)"
			:confirm-button-text="t(`${moduleId}.saveDraft.confirm`)"
			:confirm-function="confirmOk"
			:cancel-function="confirmKo"
			:prevent-dismiss="true">
			<template v-slot:body>
				<BiAlert isWarn>
					<template #body>
						{{ t(`${moduleId}.saveDraft.message`) }}
					</template>
				</BiAlert>
			</template>
		</TMModalComponent>
	</div>
</template>
