<script setup lang="ts">
// Vue
import { useApplicationFormsStore } from "@/stores/applicationFormsStore";
import { computed, inject, onMounted, ref } from "vue";
import { useI18n } from "vue-i18n";

// sso
import { userHasPermission } from "@abaco/safe-rest/src/sso2";

//Boootstrap Italia components
import BiButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiButton.vue";
import BiProgressIndicator from "@abaco/bootstrap-italia-components/src/components/BiProgressIndicator/BiProgressIndicator.vue";
import useColors from "@abaco/bootstrap-italia-components/src/composables/useColors";

// Boootstrap Italia components
import BiAlert from "@abaco/bootstrap-italia-components/src/components/BiAlert/BiAlert.vue";

// Store
import { useQueryFieldsStore } from "@/stores/queryFieldsStore";
import { useRouter } from "vue-router";

export interface IListMap {
	[key: string]: string;
}

const applicationFormStore = useApplicationFormsStore();
const QueryFieldsStore = useQueryFieldsStore();

const moduleId = inject("moduleId");
const { getColor } = useColors();
const { t } = useI18n({});
const isLoadingExistGraphicCropPlan = ref<boolean>(true);
const existGraphicCropPlan = computed(
	() => applicationFormStore.getLoadGraphicCropPlan
);

const existGraphicCropPlanRequestId = computed(
	() => applicationFormStore.getLoadGraphicCropPlan[0]?.requestId
);

const importGraphicCropPlanRequestId = computed(
	() => applicationFormStore.graphicCropPlanPendingRequest?.requestId
);

const importLogResponse = computed(
	() => applicationFormStore.importLogResponse
);

const isReadOnly = computed(() => QueryFieldsStore.getReadOnly === 1);
const cuaa = computed(() => QueryFieldsStore.getPartyCode);
const currentYear = new Date().getFullYear();
const delay = ref<number>(5000);
const detailLink = ref<string>("");
const isImportStatusError = ref<boolean>(false);
const importButtonVisibility = ref<boolean>(false);

onMounted(async () => {
	QueryFieldsStore.populateState();
	buildDetailLink();
	await applicationFormStore.loadGraphicCropPlan(cuaa.value);

	if (existGraphicCropPlan.value.length === 0) {
		isLoadingExistGraphicCropPlan.value = false;
	} else {
		pollingGraphicCropPlanRequestId();
		isLoadingExistGraphicCropPlan.value = false;
	}

	if (userHasPermission("DOSSIERS", "IMPORT_CROP_PLAN")) {
		importButtonVisibility.value = true;
	}
});

function buildDetailLink() {
	detailLink.value = "/crop-plan-client?";
	detailLink.value +=
		"businessId=" + useRouter().currentRoute.value.query.partyId + "&";
	detailLink.value +=
		"backUrl=" + encodeURIComponent(useRouter().currentRoute.value.fullPath);
}

async function importData() {
	isImportStatusError.value = false;
	await applicationFormStore.importGraphicCropPlan(cuaa.value, currentYear);
	pollingGraphicCropPlanRequestId();
}

function pollingGraphicCropPlanRequestId() {
	if (
		(existGraphicCropPlanRequestId.value &&
			existGraphicCropPlanRequestId.value) ||
		(importGraphicCropPlanRequestId.value &&
			importGraphicCropPlanRequestId.value)
	) {
		isLoadingExistGraphicCropPlan.value = true;

		polling();
	}
}

function polling() {
	delay.value = 5000;
	loop();
}

function loop() {
	setTimeout(async () => {
		// Your logic here

		const requestId =
			existGraphicCropPlanRequestId.value && existGraphicCropPlanRequestId.value
				? existGraphicCropPlanRequestId.value
				: importGraphicCropPlanRequestId.value &&
					  importGraphicCropPlanRequestId.value
					? importGraphicCropPlanRequestId.value
					: "";

		await applicationFormStore.importGraphicCropPlanPolling(
			requestId,
			cuaa.value
		);

		const graphicCropPlanFile = applicationFormStore.graphicCropPlanPolling;

		if (
			graphicCropPlanFile &&
			graphicCropPlanFile.requestId &&
			graphicCropPlanFile.flStatus !== "PENDING"
		) {
			if (graphicCropPlanFile.flStatus === "ERROR") {
				isImportStatusError.value = true;
			}
			if (graphicCropPlanFile.flStatus === "DONE") {
				await applicationFormStore.importLog(cuaa.value, requestId);
			}

			isLoadingExistGraphicCropPlan.value = false;
		} else {
			loop();
		}

		if (delay.value < 40000) {
			delay.value += 5000;
		}
	}, delay.value);
}
</script>
<template>
	<div class="container">
		<div class="row my-3 justify-content-start">
			<div class="col-12">
				<div v-if="isLoadingExistGraphicCropPlan">
					<div class="d-flex container">
						<BiProgressIndicator type="spinner"></BiProgressIndicator>

						<span class="align-content-end px-2">
							{{ t(`${moduleId}.graphicCropPlan.loading`) }}
						</span>
					</div>
				</div>

				<div class="row my-3 justify-content-start">
					<div class="col-12 row">
						<BiAlert :isError="true" v-if="isImportStatusError">
							<template #body>
								<div>
									{{ t(`${moduleId}.graphicCropPlan.alert.importError`) }}
								</div>
							</template>
						</BiAlert>
					</div>
				</div>

				<div class="row my-3 justify-content-start">
					<div class="col-12 my-3 row">
						<BiAlert isInfo v-if="!isLoadingExistGraphicCropPlan">
							<template #body>
								<div>
									{{
										t(
											`${moduleId}.graphicCropPlan.alert.openGraphicCropPlanDetail`
										)
									}}
								</div>
								<div v-if="!isReadOnly && importButtonVisibility">
									{{ t(`${moduleId}.graphicCropPlan.alert.importDetail`) }}
								</div>
							</template>
						</BiAlert>

						<BiAlert
							:isInfo="true"
							v-if="
								importLogResponse &&
								importLogResponse.response_body &&
								importLogResponse.response_body.length > 0
							">
							<template #body>
								<div>
									{{ importLogResponse.response_body }}
								</div>
							</template>
						</BiAlert>

						<div
							class="mb-5 mt-5 d-flex justify-content-center"
							v-if="!isLoadingExistGraphicCropPlan">
							<div class="d-flex justify-content-start">
								<a
									:href="detailLink"
									class="btn mx-1 mb-4"
									:class="getColor('button', 'success')">
									{{ t(`${moduleId}.graphicCropPlan.button.openDetail`) }}
									<i class="fa-solid fa-arrow-up-right-from-square"></i>
								</a>
							</div>

							<div class="d-flex justify-content-start" v-if="!isReadOnly">
								<BiButton
									v-if="importButtonVisibility"
									class="mx-1 mb-4"
									:class="getColor('button', 'success')"
									@click.stop="importData()">
									{{ t(`${moduleId}.graphicCropPlan.button.import`) }}
								</BiButton>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</template>
<style scoped>
.autocomplete-after-search-template {
	padding: 5px 10px;
	font-size: 15px;
	font-weight: normal;
}

.btn.btn-primary[disabled] {
	background-color: lightslategrey;
}

.fa-arrow-up-right-from-square {
	margin-left: 5px;
}
</style>
