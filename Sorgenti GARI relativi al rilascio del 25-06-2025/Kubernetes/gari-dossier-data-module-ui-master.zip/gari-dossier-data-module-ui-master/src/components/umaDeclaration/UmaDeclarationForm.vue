<script setup lang="ts">
// Vue
import { useApplicationFormsStore } from "@/stores/applicationFormsStore";
import { computed, inject, onMounted, ref } from "vue";
import { useI18n } from "vue-i18n";

//Boootstrap Italia components
import BiAlert from "@abaco/bootstrap-italia-components/src/components/BiAlert/BiAlert.vue";
import BiProgressIndicator from "@abaco/bootstrap-italia-components/src/components/BiProgressIndicator/BiProgressIndicator.vue";
import useColors from "@abaco/bootstrap-italia-components/src/composables/useColors";

// Boootstrap Italia components
// Store
import { useQueryFieldsStore } from "@/stores/queryFieldsStore";

const applicationFormsStore = useApplicationFormsStore();
const QueryFieldsStore = useQueryFieldsStore();

const moduleId = inject("moduleId");
const { getColor } = useColors();
const { t } = useI18n({});

const cuaa = computed(() => QueryFieldsStore.getPartyCode);
const giasUsername = computed(
	() => applicationFormsStore.getGiasUsernameResponse?.username
);
const giasRedirectLink = ref<string>("");
const giasRedirectLinkErrorInBuild = ref<boolean>(false);

onMounted(async () => {
	QueryFieldsStore.populateState();
});

async function buildAndOpenGiasRedirectLink() {
	if (applicationFormsStore.giasToken != null) {
		giasRedirectLinkErrorInBuild.value = false;
		giasRedirectLink.value = applicationFormsStore.giasToken.baseURL;
		giasRedirectLink.value += `/Agenda/index.aspx?token=${applicationFormsStore.giasToken.token}&cuaa=${cuaa.value}&username=${giasUsername.value}`;
		window.open(giasRedirectLink.value, "GIAS");
	} else {
		giasRedirectLinkErrorInBuild.value = true;
	}
}

async function openGiasUrl() {
	await applicationFormsStore.getGiasUsername();
	await applicationFormsStore.getGiasToken(cuaa.value);
	await buildAndOpenGiasRedirectLink();
}
</script>
<template>
	<div class="container">
		<div
			v-if="applicationFormsStore.getLoading"
			class="d-flex row justify-content-center mb-3 mt-5">
			<div class="d-flex col-2 justify-content-center px-0">
				<BiProgressIndicator type="spinner"></BiProgressIndicator>
			</div>
		</div>
		<div v-else class="pb-3 pt-3">
			<BiAlert isError v-if="giasRedirectLinkErrorInBuild">
				<template #body>
					{{ t(`${moduleId}.umaDeclaration.errors.GIAS_TOKEN_NULL`) }}
				</template>
			</BiAlert>
			<div class="row my-3 justify-content-start">
				<div class="col-12">
					<div class="row my-3 justify-content-start">
						<div class="col-12 my-3 row">
							<div class="mb-5 mt-5 d-flex justify-content-center">
								<div class="d-flex justify-content-start">
									<a
										@click.prevent="openGiasUrl()"
										target="GIAS"
										class="btn mx-1 mb-4"
										:class="getColor('button', 'success')">
										{{
											t(
												`${moduleId}.umaDeclaration.button.giasRedirectLinkLabel`
											)
										}}
										<i class="fa-solid fa-arrow-up-right-from-square"></i>
									</a>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</template>
<style scoped>
.autocomplete-after-search-template {
	padding: 5px 10px;
	font-size: 15px;
	font-weight: normal;
}

.btn.btn-primary[disabled] {
	background-color: lightslategrey;
}

.fa-arrow-up-right-from-square {
	margin-left: 5px;
}
</style>
