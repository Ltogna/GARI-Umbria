<script setup lang="ts">
import type {
	AdditionalDeclarationsModel,
	ConfirmationApplicationModel,
	SupportOptionModel,
} from "@/models/unificataForms";
import { useUnificataFormsStore } from "@/stores/unificataFormsStore";
import { extendDOMInputFieldsOnChange } from "@/utils/formUtils";
import type {
	StandardOptionModel,
	StandardTab,
} from "@/utils/standardTabUtils";
import BiButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiButton.vue";
import BiProgressIndicator from "@abaco/bootstrap-italia-components/src/components/BiProgressIndicator/BiProgressIndicator.vue";
import useColors from "@abaco/bootstrap-italia-components/src/composables/useColors";
import DocumentBuilder, {
	type DocumentDataDocSchemaType,
	type DocumentSchemaType,
} from "@abaco/dynamic-documents/src";
import { getUserData } from "@abaco/safe-rest/src/sso2";
import { inject, onMounted, onUpdated, ref } from "vue";
import { useI18n } from "vue-i18n";

const { getColor } = useColors();
const { t } = useI18n({});
const emit = defineEmits(["changePage", "changeTitle"]);
const unificataFormsStore = useUnificataFormsStore();

const loadingData = ref<boolean>(false);
const additionalDeclarations = ref<DocumentSchemaType>();
const additionalDeclarationsFields = ref<DocumentDataDocSchemaType>();
// const additionalDeclarationsFields = computed(
//   () => unificataFormsStore.getDocumentDeclaration,
// );
const isCompiled = ref<boolean>(false);
const isValid = ref<boolean>(false);
const showErrors = ref<boolean>(false);
const optionTitle = ref<string>("");
const moduleId = inject("moduleId");
const additionalDeclarationsStatus = ref([
	t(`${moduleId}.standardForm.Compiled`),
	t(`${moduleId}.standardForm.toBeCompiled`),
]);
const optionCodesArray = ["10.1.7", "SRA14"];

const props = withDefaults(
	defineProps<{
		isReadOnly: boolean;
		standardClass: StandardTab;
		compileStatusIdentifier: string;
		formCode: string;
		activePage?: string;
		option:
			| StandardOptionModel
			| SupportOptionModel
			| ConfirmationApplicationModel;
		dynamicDocument: AdditionalDeclarationsModel;
		pageName?: string;
		parentForm?: string;
		fromConfirmation?: boolean;
		takeoverId?: number;
	}>(),
	{ pageName: "commits-from-selection" }
);

const fileUploadConfig = {
	writeUrl: "/application-forms",
	readUrl: `/application-forms/${
		getUserData()?.tenant
	}/public/v1/${props.standardClass?.getApplicationId()}/additional-declarations`,
	bucketName: "application-forms-attachment",
	tenantId: getUserData()?.tenant as string,
};

onUpdated(() => {
	extendDOMInputFieldsOnChange(document);
});

function changePage(back: boolean) {
	if (back)
		emit("changePage", props.pageName, props.option, props.dynamicDocument);
}

async function loadData() {
	loadingData.value = true;

	const user = getUserData();

	additionalDeclarations.value = undefined;
	additionalDeclarationsFields.value = undefined;

	if (
		props.dynamicDocument &&
		props.dynamicDocument.documentDefinition &&
		user
	) {
		additionalDeclarations.value = props.dynamicDocument
			.documentDefinition as DocumentSchemaType;
		additionalDeclarationsFields.value =
			(props.dynamicDocument.document as DocumentDataDocSchemaType) ??
			undefined;
		optionTitle.value =
			props.dynamicDocument.documentDefinition.title[user.locale] ?? "";
		isCompiled.value = !!props.dynamicDocument.document;
		if (isCompiled.value && !props.isReadOnly) showErrors.value = true;
	} else {
		console.error(
			"Error in AdditionalDeclarations! 'dynamicDocument' or 'user' not valid"
		);
	}

	loadingData.value = false;
}

onMounted(async () => {
	if (props.standardClass) {
		if (props.standardClass.isConfirmation()) {
			emit(
				"changeTitle",
				props.option.optionDescription,
				props.activePage === "additional-declarations"
					? "additionalDeclarations"
					: "waiverDeclarations"
			);
		}
	}
	await loadData();
});

async function saveAdditionalDeclarations() {
	showErrors.value = true;
	if (
		additionalDeclarations.value?.code &&
		additionalDeclarationsFields.value &&
		isValid.value
	) {
		const definitionFieldCodes = additionalDeclarations.value.fieldSets.flatMap(
			fieldSet => fieldSet.fields.map(field => field.code)
		);
		const filteredFields = Object.fromEntries(
			Object.entries(additionalDeclarationsFields.value.fields).filter(
				([key]) => definitionFieldCodes.includes(key)
			)
		);
		const documentToSave = {
			validFrom: new Date().toISOString().split(".")[0] + "Z",
			validTo: "9999-12-31T00:00:00Z",
			fields: filteredFields,
		};
		if (
			props.standardClass?.isVersion(2) &&
			optionCodesArray.includes(props.option.optionCode)
		) {
			await unificataFormsStore.saveAdditionalDeclarationsV2(
				props.formCode,
				additionalDeclarations.value?.code,
				props.option.optionCode,
				{
					document: documentToSave,
				},
				props.compileStatusIdentifier,
				props.takeoverId ?? undefined
			);
		} else {
			await unificataFormsStore.saveAdditionalDeclarations(
				props.formCode,
				additionalDeclarations.value?.code,
				props.option.optionCode,
				{
					document: documentToSave,
				},
				props.compileStatusIdentifier,
				props.parentForm,
				props.takeoverId ?? undefined
			);
		}
		unificataFormsStore.setDocumentDeclaration(
			props.option.optionCode,
			props.dynamicDocument.documentDefinition?.code,
			props.standardClass.tabType,
			props.takeoverId,
			documentToSave
		);
		isCompiled.value = !!additionalDeclarationsFields.value;
	}
}
</script>
<template>
	<div
		v-if="!props.fromConfirmation && !loadingData"
		class="row my-2 align-items-center">
		<div class="col-12 col-md-8 my-3">
			<h4 class="title" :class="getColor('text', 'primary')">
				{{ optionTitle }}
			</h4>
		</div>
		<div class="col-12 col-md-4 my-3 d-flex justify-content-end">
			<h4 class="title" :class="getColor('text', 'primary')">
				{{
					t(`${moduleId}.standardForm.additionalDeclarationsStatus`, {
						placeholder: isCompiled
							? additionalDeclarationsStatus[0]
							: additionalDeclarationsStatus[1],
					})
				}}
			</h4>
		</div>
	</div>
	<div v-if="loadingData" class="d-flex row justify-content-center mb-3 mt-5">
		<div class="d-flex col-2 justify-content-center px-0">
			<BiProgressIndicator type="spinner"></BiProgressIndicator>
		</div>
	</div>
	<DocumentBuilder
		class="mt-3"
		v-if="additionalDeclarations"
		v-model="additionalDeclarationsFields"
		:lang="getUserData()?.locale || 'it'"
		:schema="additionalDeclarations"
		:show-errors="showErrors"
		:docTitleHide="true"
		:file-upload-config="fileUploadConfig"
		:readonly="isReadOnly"
		@update:valid="
			value => {
				isValid = value;
			}
		" />
	<div class="mb-5 mt-3 pt-3 d-flex justify-content-center">
		<BiButton
			v-if="!unificataFormsStore.loading"
			isPrimary
			class="mx-1"
			:class="getColor('button', 'primary', 'outline')"
			@click="changePage(true)">
			{{ t(`${moduleId}.standardForm.backToOptions`) }}
		</BiButton>
		<BiButton
			v-if="!isReadOnly && !unificataFormsStore.loading"
			type="submit"
			form="declarationsForm"
			class="mx-1"
			:class="getColor('button', 'success')"
			@click="saveAdditionalDeclarations">
			{{ t(`${moduleId}.general.saveCard`) }}
		</BiButton>
		<BiProgressIndicator
			v-if="unificataFormsStore.loading"
			type="spinner"></BiProgressIndicator>
	</div>
</template>

<style scoped>
.title {
	font-size: 1.111em;
}
</style>
