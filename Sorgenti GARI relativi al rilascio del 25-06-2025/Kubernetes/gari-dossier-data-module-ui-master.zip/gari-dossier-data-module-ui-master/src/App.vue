<script setup lang="ts">
import RootAlerts from "@abaco/bootstrap-italia-components/src/components/Alerts/RootAlerts.vue";
import BiProgressIndicator from "@abaco/bootstrap-italia-components/src/components/BiProgressIndicator/BiProgressIndicator.vue";
import { getUserData } from "@abaco/safe-rest/src/sso2";
import moment from "moment";
import { inject, onMounted, ref } from "vue";
import { RouterView, useRouter } from "vue-router";
import { loadLocaleMessages } from "./i18n";
import { httpPlus as http } from "./resources/api/http";
import { login } from "./resources/api/login";
import { resetDirtyState } from "./stores/formDirtyStore";
import { resetValidationStore } from "./stores/validationStore";

const isDev = inject("isDev");
const router = useRouter();
const isLoading = ref(true);
router.beforeEach(() => {
	resetDirtyState();
	resetValidationStore();
});

onMounted(async () => {
	try {
		if (isDev) {
			await login({
				tenant: "master",
				username: "admin",
				password: "welcome!",
			});
		}
		await loadLocaleMessages(getUserData()?.locale || "it");
		http.setLanguage(getUserData()?.locale || "it");
		moment.locale(getUserData()?.locale || "it");
		if (isDev) {
			// goLastRoute(); // use this function when run project standAlone
		}
		isLoading.value = false;
	} catch (err) {
		console.error(err);
	}
});

/* 
	// use this function when run project standAlone
	
	function goLastRoute() {
		router.push({
			name: "GraphicCropPlan",
			query: {
				applicationId: 1,
				readOnly: 0,
				compileStatusIdentifier: "UMA_DECLARATION_TYPE_CHOICE",
				formConfigId: 81,
				formCode: "UMA_DECLARATION_TYPE_CHOICE",
				partyCode: "PPPDRD38A03A302S",
			},
		});
	}
*/
</script>

<template>
	<div class="application-module">
		<RootAlerts :dismissOnRouteChange="true"></RootAlerts>
		<RouterView v-if="!isLoading"></RouterView>
		<div v-if="isLoading" class="d-flex justify-content-center mb-2 mt-2">
			<BiProgressIndicator type="spinner" />
		</div>
	</div>
</template>
