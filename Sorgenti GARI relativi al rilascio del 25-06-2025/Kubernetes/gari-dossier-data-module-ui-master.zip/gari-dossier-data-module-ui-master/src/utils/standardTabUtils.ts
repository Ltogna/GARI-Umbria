import { MonitoringResultFlagColorCodes } from "@/models/resource";
import type {
	AdditionalColumnModel,
	AdditionalDeclarationsModel,
	OptionDetailDeclarationGeom,
	OptionDetailsInfiniteListModel,
	SaveEngagementArrayModel,
	SaveEngagementZootechnicsModel,
	StandardDetailsModel,
	TerritoryFiltersModel,
	ZootechnicFiltersModel,
	ZootechnicInterventionResponseModel,
	ZootechnicInterventionSummaryModel,
	ZootechnicsDeclarationsListModel,
	ZootechnicsDeclarationsListResponse,
} from "@/models/unificataForms";
import { OptionType } from "@/models/unificataForms";
import { useUnificataFormsStore } from "@/stores/unificataFormsStore";

export interface StandardOptionModel {
	optionCode: string;
	optionDescription: string;
	minimumRequestableNumber?: number;
	requestableNumber: number;
	engagedNumber: number | null;
	showSurfaceDetail?: boolean | null;
	showWaivedArea?: boolean | null;
	waivedArea?: number | null;
	waiverAdditionalDeclaration?: AdditionalDeclarationsModel | null;
	flSelected: boolean | null;
	optionType: string | null;
	udm: string | null;
	additionalDeclaration: AdditionalDeclarationsModel | null;
	gsaaFlag: boolean | null;
	isMultyEligibility: boolean | null | undefined;
	scoreFlag: boolean | null;
	additionalColumn?: AdditionalColumnModel[];
	numberToConfirm?: number | null;
}

export enum TabType {
	"SURFACES",
	"ZOOTECH",
	"CONFIRMATION",
	"SUPPORT",
	"SRB01",
	"BCAA8",
}

export function formatArea(area: number | null) {
	if (area) {
		return (area / 10000).toFixed(4).replace(".", ",");
	} else {
		return parseInt("0").toFixed(4).replace(".", ",");
	}
}

export function formatLength(length: number | null | undefined) {
	if (length) {
		return length.toString().replace(".", ",");
	} else {
		return 0;
	}
}

export function formatInducedAreaDAR(inducedArea: number | null | undefined) {
	return inducedArea !== null && inducedArea !== 0
		? inducedArea?.toString().replace(".", ",")
		: formatArea(0);
}

abstract class StandardOptionTab {
	private unificataFormsStoreStandard = useUnificataFormsStore();

	applicationId: number;
	formCode: string;
	compileStatusIdentifier: string;
	optionsCodes: string;
	public tabType: TabType;
	selectedOptionChildrenOptions?: string;
	selectedOptionTakeoverId?: number;
	version: number;

	constructor(
		applicationId: number,
		formCode: string,
		compileStatusIdentifier: string,
		optionsCodes: string,
		tabType: TabType,
		version?: number
	) {
		this.applicationId = applicationId;
		this.formCode = formCode;
		this.compileStatusIdentifier = compileStatusIdentifier;
		this.tabType = tabType;
		this.version = version ?? 1;
		this.optionsCodes =
			optionsCodes !== ""
				? "option_code=" + optionsCodes.split(",").join("&option_code=")
				: "";
	}

	setChildrenOptions(childrenOptionCodes?: string[]) {
		this.selectedOptionChildrenOptions =
			childrenOptionCodes && childrenOptionCodes.length > 0
				? childrenOptionCodes.join("&option_code=")
				: undefined;
	}

	setTakeoverId(takeoverId?: number) {
		this.selectedOptionTakeoverId = takeoverId;
	}

	abstract loadOptions(): void;

	abstract getOptions(selected?: boolean): StandardOptionModel[];

	abstract saveSelectedOptions(optionsList: string[]): void;

	abstract deleteOption(optionCode: string, optionType?: OptionType): void;

	abstract saveEngagement(
		engagementArray: SaveEngagementArrayModel,
		action?: "ENGAGE_ALL" | "DISENGAGE_ALL",
		optionType?: OptionType
	): void;

	abstract loadOptionDetails(
		optionCode: string,
		nextKey?: string | null,
		councilCode?: string,
		sheet?: string,
		parcelCode?: string,
		engagement?: string,
		cropCode?: string
	): void;

	abstract getOptionDetails():
		| OptionDetailsInfiniteListModel
		| ZootechnicsDeclarationsListResponse;

	abstract loadStandardFilters(
		optionCode: string,
		optionType: OptionType,
		councilCode?: string,
		sheet?: string,
		parcelCode?: string,
		breedingCode?: string,
		subCodSpecies?: string
	): void;

	abstract getStandardFilters(
		optionType: OptionType
	): TerritoryFiltersModel | ZootechnicFiltersModel | undefined;

	async askComplementaryBeforeDelete(optionCodes: string[]) {
		await this.unificataFormsStoreStandard.askComplementaryBeforeDelete(
			this.formCode,
			optionCodes
		);
		return this.unificataFormsStoreStandard.getAskComplementaryResponse ?? [];
	}

	abstract saveOptionCommitmentsByFilters(
		optionCode: string,
		action: string,
		councilCode?: string,
		sheet?: string,
		parcelCode?: string,
		engagement?: string,
		cropCode?: string
	): void;

	abstract loadZootechnicInterventionList(
		optionCode: string,
		breedingCode?: string,
		earTag?: string,
		species?: string,
		nextKey?: string | null
	): void;

	abstract getZootechnicInterventionList(): ZootechnicInterventionResponseModel;

	abstract getOptionsCodes(): string;

	isSurfaces() {
		return this.tabType === TabType.SURFACES;
	}

	isZootech() {
		return this.tabType === TabType.ZOOTECH;
	}

	isConfirmation() {
		return this.tabType === TabType.CONFIRMATION;
	}

	isSupport() {
		return this.tabType === TabType.SUPPORT;
	}

	isSRB01() {
		return this.tabType === TabType.SRB01;
	}

	isBCAA8() {
		return this.tabType === TabType.BCAA8;
	}

	isVersion(v: number) {
		return this.version === v;
	}

	getVersion() {
		return this.version;
	}

	getApplicationId() {
		return this.applicationId;
	}
}

export class StandardSurfaceTab extends StandardOptionTab {
	private unificataFormsStore = useUnificataFormsStore();

	async loadOptions() {
		await this.unificataFormsStore.loadStandardOptionsList(this.formCode);
	}

	getOptions(selected?: boolean) {
		const transformedSurfaceOptionsList: StandardOptionModel[] =
			this.unificataFormsStore.getStandardOptionsList.map(op => {
				return {
					optionCode: op.optionCode,
					optionDescription: op.optionDescription,
					minimumRequestableNumber: op.optionMinimumRequestableArea,
					requestableNumber: op.requestableArea,
					engagedNumber: op.engagedArea,
					flSelected: op.flSelected,
					additionalDeclaration: op.additionalDeclaration,
					optionType: null,
					udm: null,
					waivedArea: op.waivedArea,
					showWaivedArea: op.showWaivedArea,
					waiverAdditionalDeclaration: op.waiverAdditionalDeclaration,
					showSurfaceDetail: op.showSurfaceDetail,
					gsaaFlag: op.gsaaFlag,
					isMultyEligibility: null,
					scoreFlag: null,
					numberToConfirm: op.areaToConfirm,
				};
			});
		return filterData(transformedSurfaceOptionsList, selected);
	}

	async saveSelectedOptions(optionsList: string[]) {
		await this.unificataFormsStore.saveSelectedOptions(
			optionsList,
			this.formCode,
			this.compileStatusIdentifier
		);
	}

	async deleteOption(optionCode: string) {
		await this.unificataFormsStore.deleteOption(
			optionCode,
			this.compileStatusIdentifier,
			this.formCode
		);
	}

	async saveEngagement(
		engagementArray: SaveEngagementArrayModel,
		action?: string
	) {
		await this.unificataFormsStore.saveSelectedOptionsCommitment(
			engagementArray,
			this.compileStatusIdentifier,
			this.formCode,
			action
		);
	}

	async loadOptionDetails(
		optionCode: string,
		nextKey?: string | null,
		councilCode?: string,
		sheet?: string,
		parcelCode?: string,
		engagement?: string,
		cropCode?: string
	) {
		return this.unificataFormsStore.loadOptionDetails(
			optionCode,
			nextKey,
			councilCode,
			sheet,
			parcelCode,
			engagement,
			cropCode
		);
	}

	getOptionDetails() {
		const optionDetailsList: OptionDetailsInfiniteListModel =
			this.unificataFormsStore.getOptionDetailsList;
		if (
			optionDetailsList &&
			optionDetailsList.count &&
			optionDetailsList.records
		)
			optionDetailsList.records.forEach(
				el => (el.engagedArea = el.engagedArea ?? 0)
			);
		return optionDetailsList;
	}

	async loadStandardFilters(
		optionCode: string,
		optionType: OptionType,
		councilCode?: string,
		sheet?: string,
		parcelCode?: string
	) {
		return this.unificataFormsStore.loadSurfacesFilters(
			optionCode,
			councilCode,
			sheet,
			parcelCode
		);
	}

	getStandardFilters() {
		return this.unificataFormsStore.getStandardSurfaceFilters;
	}

	async saveOptionCommitmentsByFilters(
		optionCode: string,
		action: string,
		councilCode?: string,
		sheet?: string,
		parcelCode?: string,
		engagement?: string,
		cropCode?: string
	) {
		await this.unificataFormsStore.saveOptionCommitmentsByFilters(
			this.formCode,
			optionCode,
			this.compileStatusIdentifier,
			action,
			councilCode,
			sheet,
			parcelCode,
			engagement,
			cropCode
		);
	}

	loadZootechnicInterventionList() {
		throw new Error("Surface tab doesn't contain this standard component");
	}

	getZootechnicInterventionList(): ZootechnicInterventionResponseModel {
		throw new Error("Surface tab doesn't contain this standard component");
	}

	getOptionsCodes() {
		return this.optionsCodes;
	}
}

export class StandardZootechnicTab extends StandardOptionTab {
	private unificataFormsStore = useUnificataFormsStore();

	async loadOptions() {
		return await this.unificataFormsStore.loadStandardZootechnicsList(
			this.formCode,
			this.compileStatusIdentifier
		);
	}

	getOptions(selected?: boolean | undefined): StandardOptionModel[] {
		const transformedZootechnicsOptionsList: StandardOptionModel[] =
			this.unificataFormsStore.getStandardZootechnicsList.map(op => {
				return {
					optionCode: op.optionCode,
					optionDescription: op.optionDescription,
					minimumRequestableNumber: 0,
					requestableNumber: op.requestableZootechnicsBreedingCount || 0,
					engagedNumber: op.engagedZootechnicsBreedingCount || 0,
					flSelected: op.flSelected,
					additionalDeclaration: op.additionalDeclaration,
					optionType: null,
					udm: null,
					gsaaFlag: null,
					isMultyEligibility: null,
					scoreFlag: null,
				};
			});
		return filterData(transformedZootechnicsOptionsList, selected);
	}

	async saveSelectedOptions(optionsList: string[]) {
		await this.unificataFormsStore.saveSelectedInterventions(
			optionsList,
			this.formCode,
			this.compileStatusIdentifier
		);
	}

	async deleteOption(optionCode: string) {
		await this.unificataFormsStore.deleteIntervention(
			optionCode,
			this.compileStatusIdentifier,
			this.formCode
		);
	}

	async saveEngagement(
		engagementArray: SaveEngagementZootechnicsModel,
		action?: "ENGAGE_ALL" | "DISENGAGE_ALL"
	) {
		await this.unificataFormsStore.saveSelectedOptionsZootechnicsCommitment(
			engagementArray,
			this.compileStatusIdentifier,
			this.formCode,
			action
		);
	}

	async loadOptionDetails(optionCode: string, nextKey?: string | null) {
		return await this.unificataFormsStore.loadStandardZootechnicsDeclarationsList(
			this.formCode,
			this.compileStatusIdentifier,
			optionCode,
			nextKey
		);
	}

	getOptionDetails() {
		return this.unificataFormsStore.getStandardZootechnicsDeclarationsList;
	}

	loadStandardFilters() {
		throw new Error("Zootechnic tab doesn't contain this standard component");
	}

	getStandardFilters(): TerritoryFiltersModel | undefined {
		throw new Error("Zootechnic tab doesn't contain this standard component");
	}

	saveOptionCommitmentsByFilters() {
		throw new Error("Zootechnic tab doesn't contain this standard component");
	}

	async saveBreedingDeclarations(
		breedingDeclarationList: ZootechnicsDeclarationsListModel
	) {
		await this.unificataFormsStore.saveSelectedBreedingDeclarations(
			breedingDeclarationList,
			this.formCode,
			this.compileStatusIdentifier
		);
	}

	loadZootechnicInterventionList() {
		throw new Error("Zootechnic tab doesn't contain this standard component");
	}

	getZootechnicInterventionList(): ZootechnicInterventionResponseModel {
		throw new Error("Zootechnic tab doesn't contain this standard component");
	}

	getOptionsCodes() {
		return this.optionsCodes;
	}
}

export class StandardConfirmationTab extends StandardOptionTab {
	private unificataFormsStore = useUnificataFormsStore();

	async loadOptions() {
		await this.unificataFormsStore.loadStandardOptionsList(
			this.formCode,
			this.selectedOptionTakeoverId,
			this.selectedOptionChildrenOptions ?? undefined
		);
	}

	getOptions(selected?: boolean) {
		const transformedConfirmationOptionsList: StandardOptionModel[] =
			this.unificataFormsStore.getStandardOptionsList.map(op => {
				return {
					optionCode: op.optionCode,
					optionDescription: op.optionDescription,
					minimumRequestableNumber: op.optionMinimumRequestableArea,
					requestableNumber: op.requestableArea,
					engagedNumber: op.engagedArea,
					flSelected: op.flSelected,
					additionalDeclaration: op.additionalDeclaration,
					optionType: OptionType.SURFACE,
					udm: "ha",
					gsaaFlag: op.gsaaFlag,
					isMultyEligibility: null,
					scoreFlag: null,
				};
			});
		return filterConfirmationData(transformedConfirmationOptionsList, selected);
	}

	saveSelectedOptions() {
		throw new Error("Confirmation tab doesn't contain this standard component");
	}

	deleteOption() {
		throw new Error("Confirmation tab doesn't contain this standard component");
	}

	async saveEngagement(
		engagementArray: SaveEngagementArrayModel,
		action?: "ENGAGE_ALL" | "DISENGAGE_ALL"
	) {
		await this.unificataFormsStore.saveConfirmationSelectedOptionsCommitment(
			engagementArray,
			this.compileStatusIdentifier,
			this.formCode,
			action,
			this.selectedOptionTakeoverId
		);
	}

	async loadOptionDetails(
		optionCode: string,
		nextKey?: string | null,
		councilCode?: string,
		sheet?: string,
		parcelCode?: string,
		engagement?: string,
		cropCode?: string
	) {
		return this.unificataFormsStore.loadConfirmationOptionDetails(
			optionCode,
			this.formCode,
			nextKey,
			councilCode,
			sheet,
			parcelCode,
			engagement,
			cropCode,
			this.selectedOptionTakeoverId
		);
	}

	getOptionDetails() {
		const optionDetailsList: OptionDetailsInfiniteListModel =
			this.unificataFormsStore.getOptionDetailsList;
		if (
			optionDetailsList &&
			optionDetailsList.count &&
			optionDetailsList.records
		)
			optionDetailsList.records.forEach(
				el => (el.engagedArea = el.engagedArea ?? 0)
			);
		return optionDetailsList;
	}

	async loadStandardFilters(
		optionCode: string,
		optionType: OptionType,
		councilCode?: string,
		sheet?: string,
		parcelCode?: string,
		breedingCode?: string,
		subCodSpecies?: string
	) {
		if (optionType === OptionType.SURFACE)
			await this.unificataFormsStore.loadSurfacesFilters(
				optionCode,
				councilCode,
				sheet,
				parcelCode
			);
		else
			await this.unificataFormsStore.loadZootechnicsFilters(
				optionCode,
				this.formCode,
				breedingCode,
				subCodSpecies,
				this.selectedOptionTakeoverId
			);
	}

	getStandardFilters(optionType: OptionType = OptionType.SURFACE) {
		if (optionType === OptionType.SURFACE)
			return this.unificataFormsStore.getStandardSurfaceFilters;
		else return this.unificataFormsStore.getStandardZootechnicFilters;
	}

	async saveOptionCommitmentsByFilters(
		optionCode: string,
		action: string,
		councilCode?: string,
		sheet?: string,
		parcelCode?: string,
		engagement?: string,
		cropCode?: string
	) {
		await this.unificataFormsStore.saveOptionCommitmentsByFilters(
			this.formCode,
			optionCode,
			this.compileStatusIdentifier,
			action,
			councilCode,
			sheet,
			parcelCode,
			engagement,
			cropCode,
			this.selectedOptionTakeoverId,
			this.selectedOptionChildrenOptions ?? undefined
		);
	}

	async loadZootechnicInterventionList(
		optionCode: string,
		breedingCode?: string,
		earTag?: string,
		species?: string,
		nextKey?: string | null | undefined
	) {
		await this.unificataFormsStore.loadZootechnicInterventionList(
			this.formCode,
			optionCode,
			breedingCode,
			earTag,
			species,
			this.selectedOptionTakeoverId,
			nextKey
		);
	}

	getZootechnicInterventionList(): ZootechnicInterventionResponseModel {
		return this.unificataFormsStore.zootechnicInterventionList;
	}

	async saveBreedingDeclarations(
		breedingDeclarationList: ZootechnicsDeclarationsListModel
	) {
		await this.unificataFormsStore.saveSelectedBreedingDeclarations(
			breedingDeclarationList,
			this.formCode,
			this.compileStatusIdentifier
		);
	}

	async loadStandardDetails(optionCode: string, tabType: TabType) {
		if (tabType === TabType.SURFACES) {
			await this.unificataFormsStore.loadStandardDetails(
				optionCode,
				this.formCode,
				this.selectedOptionTakeoverId
			);
		} else if (tabType === TabType.ZOOTECH) {
			await this.unificataFormsStore.loadZootechnicSummaryDetails(
				optionCode,
				this.formCode,
				this.selectedOptionTakeoverId
			);
		}
	}

	getStandardDetails(
		tabType: TabType
	): StandardDetailsModel | ZootechnicInterventionSummaryModel {
		return tabType === TabType.SURFACES
			? this.unificataFormsStore.getStandardDetails
			: this.unificataFormsStore.getZootechnicSummaryDetail;
	}

	getOptionsCodes() {
		return this.optionsCodes;
	}
}

export class StandardSupportTab extends StandardOptionTab {
	private unificataFormsStore = useUnificataFormsStore();

	async loadOptions() {
		return await this.unificataFormsStore.loadHelpApplicationList(
			this.formCode,
			this.compileStatusIdentifier
		);
	}

	getOptions(selected?: boolean | undefined): StandardOptionModel[] {
		const transformedSupportOptionsList: StandardOptionModel[] =
			this.unificataFormsStore.getHelpApplicationList.map(op => {
				return {
					optionCode: op.optionCode,
					optionDescription: op.optionDescription,
					minimumRequestableNumber: op.optionMinimumRequestableQuantity || 0,
					requestableNumber: op.requestableQuantity || 0,
					engagedNumber: op.engagedQuantity || 0,
					flSelected: op.flSelected,
					additionalDeclaration: op.additionalDeclaration,
					optionType: op.optionType,
					udm: op.optionType === OptionType.SURFACE ? "hectares" : "cattles",
					gsaaFlag: op.gsaaFlag,
					isMultyEligibility: op.isMultyElegibility,
					scoreFlag: op.scoreFlag || null,
					additionalColumn: op.additionalColumn || undefined,
				};
			});
		return filterData(transformedSupportOptionsList, selected);
	}

	async saveSelectedOptions(optionsList: string[]) {
		await this.unificataFormsStore.saveSelectedSupportInterventions(
			optionsList,
			this.formCode,
			this.compileStatusIdentifier
		);
	}

	async deleteOption(optionCode: string, optionType?: OptionType) {
		if (optionType === OptionType.SURFACE)
			await this.unificataFormsStore.deleteSupportOption(
				optionCode,
				this.compileStatusIdentifier,
				this.formCode
			);
		else
			await this.unificataFormsStore.deleteSupportOptionZootechnics(
				optionCode,
				this.compileStatusIdentifier,
				this.formCode
			);
	}

	async saveEngagement(
		engagementArray: SaveEngagementArrayModel,
		action?: "ENGAGE_ALL" | "DISENGAGE_ALL",
		optionType?: OptionType,
		optionCode?: string
	) {
		if (optionType === OptionType.SURFACE || (!optionType && !optionCode))
			await this.unificataFormsStore.saveSelectedSupportOptionsCommitment(
				engagementArray,
				this.compileStatusIdentifier,
				this.formCode,
				action
			);
		else {
			if (optionCode)
				await this.unificataFormsStore.saveSupportZootechnicsInterventionList(
					this.formCode,
					optionCode,
					this.compileStatusIdentifier,
					null,
					undefined,
					undefined,
					undefined,
					action,
					undefined
				);
		}
	}

	async loadOptionDetails(
		optionCode: string,
		nextKey?: string | null,
		councilCode?: string,
		sheet?: string,
		parcelCode?: string,
		engagement?: string,
		cropCode?: string
	) {
		return this.unificataFormsStore.loadOptionDetails(
			optionCode,
			nextKey,
			councilCode,
			sheet,
			parcelCode,
			engagement,
			cropCode
		);
	}

	getOptionDetails() {
		const optionDetailsList: OptionDetailsInfiniteListModel =
			this.unificataFormsStore.getOptionDetailsList;
		if (
			optionDetailsList &&
			optionDetailsList.count &&
			optionDetailsList.records
		)
			optionDetailsList.records.forEach(
				el => (el.engagedArea = el.engagedArea ?? 0)
			);
		return optionDetailsList;
	}

	async loadStandardFilters(
		optionCode: string,
		optionType: OptionType,
		councilCode?: string,
		sheet?: string,
		parcelCode?: string,
		breedingCode?: string,
		subCodSpecies?: string
	) {
		if (optionType === OptionType.SURFACE)
			await this.unificataFormsStore.loadSurfacesFilters(
				optionCode,
				councilCode,
				sheet,
				parcelCode
			);
		else
			await this.unificataFormsStore.loadSupportZootechnicsFilters(
				optionCode,
				this.formCode,
				breedingCode,
				subCodSpecies
			);
	}

	getStandardFilters(optionType: OptionType = OptionType.SURFACE) {
		if (optionType === OptionType.SURFACE)
			return this.unificataFormsStore.getStandardSurfaceFilters;
		else return this.unificataFormsStore.getSupportZootechnicFilters;
	}

	async saveOptionCommitmentsByFilters(
		optionCode: string,
		action: string,
		councilCode?: string,
		sheet?: string,
		parcelCode?: string,
		engagement?: string,
		cropCode?: string
	) {
		await this.unificataFormsStore.saveOptionSupportCommitmentsByFilters(
			this.formCode,
			optionCode,
			this.compileStatusIdentifier,
			action,
			councilCode,
			sheet,
			parcelCode,
			engagement,
			cropCode
		);
	}

	getOptionsCodes() {
		return this.optionsCodes;
	}

	getStandardZootechnicsDeclarationsList(): ZootechnicsDeclarationsListResponse {
		return this.unificataFormsStore.getStandardZootechnicsDeclarationsList;
	}

	async loadStandardZootechnicsDeclarationsList(
		optionCode: string,
		nextKey?: string
	) {
		return await this.unificataFormsStore.loadStandardZootechnicsDeclarationsList(
			this.formCode,
			this.compileStatusIdentifier,
			optionCode,
			nextKey
		);
	}

	async loadZootechnicInterventionList(
		optionCode: string,
		breedingCode?: string,
		earTag?: string,
		species?: string,
		nextKey?: string | null | undefined
	) {
		await this.unificataFormsStore.loadSupportZootechnicInterventionList(
			this.formCode,
			optionCode,
			breedingCode,
			earTag,
			species,
			this.selectedOptionTakeoverId,
			nextKey
		);
	}

	getZootechnicInterventionList(): ZootechnicInterventionResponseModel {
		return this.unificataFormsStore.getSupportZootechnicInterventionList;
	}

	async saveBreedingDeclarations(
		breedingDeclarationList: ZootechnicsDeclarationsListModel
	) {
		await this.unificataFormsStore.saveSelectedBreedingDeclarations(
			breedingDeclarationList,
			this.formCode,
			this.compileStatusIdentifier
		);
	}
}

export class StandardSRB01Tab extends StandardOptionTab {
	private unificataFormsStore = useUnificataFormsStore();

	async loadOptions() {
		await this.unificataFormsStore.loadStandardOptionsList(this.formCode);
	}

	getOptions(selected?: boolean) {
		const transformedSurfaceOptionsList: StandardOptionModel[] =
			this.unificataFormsStore.getStandardOptionsList.map(op => {
				return {
					optionCode: op.optionCode,
					optionDescription: op.optionDescription,
					minimumRequestableNumber: op.optionMinimumRequestableArea,
					requestableNumber: op.requestableArea,
					engagedNumber: op.engagedArea,
					flSelected: op.flSelected,
					additionalDeclaration: op.additionalDeclaration,
					optionType: null,
					udm: null,
					gsaaFlag: op.gsaaFlag,
					isMultyEligibility: op.isMultyEligibility,
					scoreFlag: null,
				};
			});
		return filterData(transformedSurfaceOptionsList, selected);
	}

	async saveSelectedOptions(optionsList: string[]) {
		await this.unificataFormsStore.saveSelectedOptions(
			optionsList,
			this.formCode,
			this.compileStatusIdentifier
		);
	}

	async deleteOption(optionCode: string) {
		await this.unificataFormsStore.deleteOption(
			optionCode,
			this.compileStatusIdentifier,
			this.formCode
		);
	}

	async saveEngagement(
		engagementArray: SaveEngagementArrayModel,
		action?: string
	) {
		await this.unificataFormsStore.saveSelectedSupportOptionsCommitment(
			engagementArray,
			this.compileStatusIdentifier,
			this.formCode,
			action
		);
	}

	async loadOptionDetails(
		optionCode: string,
		nextKey?: string | null,
		councilCode?: string,
		sheet?: string,
		parcelCode?: string,
		engagement?: string,
		cropCode?: string
	) {
		return this.unificataFormsStore.loadOptionDetails(
			optionCode,
			nextKey,
			councilCode,
			sheet,
			parcelCode,
			engagement,
			cropCode
		);
	}

	getOptionDetails() {
		const optionDetailsList: OptionDetailsInfiniteListModel =
			this.unificataFormsStore.getOptionDetailsList;
		if (
			optionDetailsList &&
			optionDetailsList.count &&
			optionDetailsList.records
		)
			optionDetailsList.records.forEach(
				el => (el.engagedArea = el.engagedArea ?? 0)
			);
		return optionDetailsList;
	}

	async loadStandardFilters(
		optionCode: string,
		optionType: OptionType,
		councilCode?: string,
		sheet?: string,
		parcelCode?: string,
		breedingCode?: string,
		subCodSpecies?: string
	) {
		if (optionType === OptionType.SURFACE)
			await this.unificataFormsStore.loadSurfacesFilters(
				optionCode,
				councilCode,
				sheet,
				parcelCode
			);
		else
			await this.unificataFormsStore.loadZootechnicsFilters(
				optionCode,
				this.formCode,
				breedingCode,
				subCodSpecies,
				undefined
			);
	}

	getStandardFilters(optionType: OptionType = OptionType.SURFACE) {
		if (optionType === OptionType.SURFACE)
			return this.unificataFormsStore.getStandardSurfaceFilters;
		else return this.unificataFormsStore.getStandardZootechnicFilters;
	}

	async saveOptionCommitmentsByFilters(
		optionCode: string,
		action: string,
		councilCode?: string,
		sheet?: string,
		parcelCode?: string,
		engagement?: string,
		cropCode?: string
	) {
		await this.unificataFormsStore.saveOptionSupportCommitmentsByFilters(
			this.formCode,
			optionCode,
			this.compileStatusIdentifier,
			action,
			councilCode,
			sheet,
			parcelCode,
			engagement,
			cropCode
		);
	}

	getOptionsCodes() {
		return this.optionsCodes;
	}

	getStandardZootechnicsDeclarationsList(): ZootechnicsDeclarationsListResponse {
		return this.unificataFormsStore.getStandardZootechnicsDeclarationsList;
	}

	async loadStandardZootechnicsDeclarationsList(
		optionCode: string,
		nextKey?: string
	) {
		return await this.unificataFormsStore.loadStandardZootechnicsDeclarationsList(
			this.formCode,
			this.compileStatusIdentifier,
			optionCode,
			nextKey
		);
	}

	async loadZootechnicInterventionList(
		optionCode: string,
		breedingCode?: string,
		earTag?: string,
		species?: string,
		nextKey?: string | null | undefined
	) {
		await this.unificataFormsStore.loadZootechnicInterventionList(
			this.formCode,
			optionCode,
			breedingCode,
			earTag,
			species,
			undefined,
			nextKey
		);
	}

	getZootechnicInterventionList(): ZootechnicInterventionResponseModel {
		return this.unificataFormsStore.zootechnicInterventionList;
	}

	async saveBreedingDeclarations(
		breedingDeclarationList: ZootechnicsDeclarationsListModel
	) {
		await this.unificataFormsStore.saveSelectedBreedingDeclarations(
			breedingDeclarationList,
			this.formCode,
			this.compileStatusIdentifier
		);
	}
}

export class StandardBCAA8Tab extends StandardOptionTab {
	private unificataFormsStore = useUnificataFormsStore();

	async loadOptions() {
		await this.unificataFormsStore.loadStandardOptionsList(this.formCode);
	}

	getOptions() {
		const transformedSurfaceOptionsList: StandardOptionModel[] =
			this.unificataFormsStore.getStandardOptionsList.map(op => {
				return {
					optionCode: op.optionCode,
					optionDescription: op.optionDescription,
					minimumRequestableNumber: op.optionMinimumRequestableArea,
					requestableNumber: op.requestableArea,
					engagedNumber: op.engagedArea,
					flSelected: op.flSelected,
					additionalDeclaration: op.additionalDeclaration,
					optionType: null,
					udm: null,
					waivedArea: op.waivedArea,
					showWaivedArea: op.showWaivedArea,
					waiverAdditionalDeclaration: op.waiverAdditionalDeclaration,
					showSurfaceDetail: op.showSurfaceDetail,
					gsaaFlag: op.gsaaFlag,
					isMultyEligibility: null,
					scoreFlag: null,
				};
			});
		return transformedSurfaceOptionsList;
	}

	async saveSelectedOptions(optionsList: string[]) {
		await this.unificataFormsStore.saveSelectedOptions(
			optionsList,
			this.formCode,
			this.compileStatusIdentifier
		);
	}

	async deleteOption(optionCode: string) {
		await this.unificataFormsStore.deleteOption(
			optionCode,
			this.compileStatusIdentifier,
			this.formCode
		);
	}

	async saveEngagement(
		engagementArray: SaveEngagementArrayModel,
		action?: string
	) {
		await this.unificataFormsStore.saveSelectedOptionsCommitment(
			engagementArray,
			this.compileStatusIdentifier,
			this.formCode,
			action
		);
	}

	async loadOptionDetails(
		optionCode: string,
		nextKey?: string | null,
		councilCode?: string,
		sheet?: string,
		parcelCode?: string,
		engagement?: string,
		cropCode?: string
	) {
		return this.unificataFormsStore.loadOptionDetails(
			optionCode,
			nextKey,
			councilCode,
			sheet,
			parcelCode,
			engagement,
			cropCode
		);
	}

	getOptionDetails() {
		const optionDetailsList: OptionDetailsInfiniteListModel =
			this.unificataFormsStore.getOptionDetailsList;
		if (
			optionDetailsList &&
			optionDetailsList.count &&
			optionDetailsList.records
		)
			optionDetailsList.records.forEach(
				el => (el.engagedArea = el.engagedArea ?? 0)
			);
		return optionDetailsList;
	}

	async loadStandardFilters(
		optionCode: string,
		optionType: OptionType,
		councilCode?: string,
		sheet?: string,
		parcelCode?: string
	) {
		return this.unificataFormsStore.loadSurfacesFilters(
			optionCode,
			councilCode,
			sheet,
			parcelCode
		);
	}

	getStandardFilters() {
		return this.unificataFormsStore.getStandardSurfaceFilters;
	}

	async saveOptionCommitmentsByFilters(
		optionCode: string,
		action: string,
		councilCode?: string,
		sheet?: string,
		parcelCode?: string,
		engagement?: string,
		cropCode?: string
	) {
		await this.unificataFormsStore.saveOptionCommitmentsByFilters(
			this.formCode,
			optionCode,
			this.compileStatusIdentifier,
			action,
			councilCode,
			sheet,
			parcelCode,
			engagement,
			cropCode
		);
	}

	loadZootechnicInterventionList() {
		throw new Error("Surface tab doesn't contain this standard component");
	}

	getZootechnicInterventionList(): ZootechnicInterventionResponseModel {
		throw new Error("Surface tab doesn't contain this standard component");
	}

	getOptionsCodes() {
		return this.optionsCodes;
	}
}

export function linkClassToGetMethods(
	applicationId: number,
	formCode: string,
	compileStatusIdentifier: string,
	optionsCodes: string,
	version?: number
) {
	switch (formCode) {
		case "UNIF_BASIC_AND_COMPLEMENTARY":
		case "UNIF_SURFACES_ECOLOGICAL_REGIMES":
		case "UNIF_COUPLED_SURFACES":
		case "UNIF_RESERVE_ACCESS":
		case "UNIF_DE_MINIMIS": {
			return new StandardSurfaceTab(
				applicationId,
				formCode,
				compileStatusIdentifier,
				optionsCodes,
				TabType.SURFACES,
				version
			);
		}
		case "UNIF_ZOOTECHNICS_ECOLOGICAL_REGIMES":
		case "UNIF_COUPLED_ZOOTECHNICS": {
			return new StandardZootechnicTab(
				applicationId,
				formCode,
				compileStatusIdentifier,
				optionsCodes,
				TabType.ZOOTECH,
				version
			);
		}
		case "UNIF_CONFIRMATION_APPLICATION":
		case "UNIF_CSR_CONFIRMATION_APPLICATION":
		case "UNIF_CSR_SRA10.1_CONFIRMATION_APPLICATION": {
			return new StandardConfirmationTab(
				applicationId,
				formCode,
				compileStatusIdentifier,
				optionsCodes,
				TabType.CONFIRMATION,
				version
			);
		}
		case "UNIF_SUPPORT_APPLICATION": {
			return new StandardSupportTab(
				applicationId,
				formCode,
				compileStatusIdentifier,
				optionsCodes,
				TabType.SUPPORT,
				version
			);
		}
		case "UNIF_OPTION_SRB01":
		case "UNIF_OPTION_MEASUREMENT_13": {
			return new StandardSRB01Tab(
				applicationId,
				formCode,
				compileStatusIdentifier,
				optionsCodes,
				TabType.SRB01,
				version
			);
		}
		case "UNIF_BCAA8": {
			return new StandardBCAA8Tab(
				applicationId,
				formCode,
				compileStatusIdentifier,
				optionsCodes,
				TabType.BCAA8,
				version
			);
		}
	}
}

function filterData(data: StandardOptionModel[], filterSelection?: boolean) {
	if (filterSelection === true || filterSelection === false) {
		return data.filter(el => el.flSelected === filterSelection);
	} else {
		return data;
	}
}

function filterConfirmationData(
	data: StandardOptionModel[],
	filterSelection?: boolean
) {
	if (filterSelection === true || filterSelection === false) {
		return data.filter(el => el.flSelected === filterSelection);
	} else {
		return data.filter(
			el => el.flSelected === true && el.requestableNumber > 0
		);
	}
}

/**
 * Returns monitoring flag style
 *
 * @param {string} val
 * @return {string}
 */
export function getMonitoringDataStyle(val: string): string {
	switch (val.toLocaleUpperCase()) {
		case MonitoringResultFlagColorCodes.Enum.RED:
			return "--fa-primary-color: #1e3050; --fa-secondary-color: red";
		case MonitoringResultFlagColorCodes.Enum.CHECKERED_BLUE:
			return "--fa-primary-color: #1e3050; --fa-secondary-color: blue";
		case MonitoringResultFlagColorCodes.Enum.CHECKERED_YELLOW:
			return "--fa-primary-color: #1e3050; --fa-secondary-color: yellow";
		case MonitoringResultFlagColorCodes.Enum.GREEN:
			return "--fa-primary-color: #1e3050; --fa-secondary-color: green";
		case MonitoringResultFlagColorCodes.Enum.WHITE:
			return "--fa-primary-color: #1e3050; --fa-secondary-color: white";
		case MonitoringResultFlagColorCodes.Enum.YELLOW:
			return "--fa-primary-color: #1e3050; --fa-secondary-color: rgb(230, 230, 0)";
	}
	return "";
}

/**
 * Returns a global monitoring style (flag color) based on flags[]
 *
 * @param {string[]} flags
 * @return {string}
 */
export function getGlobalMonitoringData(flags: string[]): string {
	if (flags.find(f => f == MonitoringResultFlagColorCodes.Enum.RED))
		return MonitoringResultFlagColorCodes.Enum.RED;
	if (flags.find(f => f == MonitoringResultFlagColorCodes.Enum.YELLOW))
		return MonitoringResultFlagColorCodes.Enum.YELLOW;
	if (flags.find(f => f == MonitoringResultFlagColorCodes.Enum.GREEN))
		return MonitoringResultFlagColorCodes.Enum.GREEN;
	if (flags.find(f => f == MonitoringResultFlagColorCodes.Enum.WHITE))
		return MonitoringResultFlagColorCodes.Enum.WHITE;
	return "";
}

export function monitoringResults(
	declarationGeomList: Array<OptionDetailDeclarationGeom> | undefined | null
): string[] {
	if (!declarationGeomList) return [];
	const monitoringResults: string[] = [];

	declarationGeomList
		.filter(
			g => g.monitoringData && g.monitoringData.monitoringResult !== undefined
		)
		.forEach(g => {
			if (g.monitoringData && g.monitoringData.monitoringResult)
				monitoringResults.push(
					g.monitoringData.monitoringResult.toLocaleUpperCase()
				);
		});
	return monitoringResults;
}

export type StandardTab =
	| StandardSurfaceTab
	| StandardZootechnicTab
	| StandardSupportTab
	| StandardConfirmationTab
	| StandardSRB01Tab
	| StandardBCAA8Tab;
