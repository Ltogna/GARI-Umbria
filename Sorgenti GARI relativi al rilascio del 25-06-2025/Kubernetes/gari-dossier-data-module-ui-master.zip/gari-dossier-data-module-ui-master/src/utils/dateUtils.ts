import { getUserData } from "@abaco/safe-rest/src/sso2";
import { format } from "date-fns";
import moment from "moment";

/**
 * @param dateString format: yyyyMMdd || yyyy-MM-dd || yyyy-MM-dd HH:mm:ss || timestamp
 * @param withTime add time to returned string (if provided in dateString)
 */
export function getFormattedDate(
	dateString: string | number,
	withTime?: boolean
) {
	const _dateString = dateString.toString();
	try {
		const _user = getUserData();
		if (!_user || !_user.dateFormat) {
			console.error(
				"Error in dateUtils>getFormattedDate, user does not have dateformat info"
			);
			return "error_date";
		}

		// date mask
		const _userDateFormat =
			_user.dateFormat.split("D").join("d").split("Y").join("y") ||
			"dd/MM/yyyy";
		let year: number;
		let month: number;
		let day: number;
		let hour: number;
		let min: number;
		let sec: number;

		if (_dateString.match(/[a-zA-Z]/)) {
			// dateString contains letters
			console.warn(
				"Warning in dateUtils>getFormattedDate, dateString is not in a valid format"
			);
			return _dateString;
		} else if (_dateString && _dateString.length === 8) {
			// dateString has yyyyMMdd format
			year = parseInt(_dateString.substring(0, 4));
			month = parseInt(_dateString.substring(4, 6));
			day = parseInt(_dateString.substring(6, 8));

			return format(new Date(year, month - 1, day), _userDateFormat);
		} else if (
			_dateString.length === 10 &&
			_dateString.charAt(4) === "-" &&
			_dateString.charAt(7) === "-"
		) {
			// dateString has yyyy-MM-dd format
			year = parseInt(_dateString.substring(0, 4));
			month = parseInt(_dateString.substring(5, 7));
			day = parseInt(_dateString.substring(8, 10));

			return format(new Date(year, month - 1, day), _userDateFormat);
		} else if (
			_dateString.length === 19 &&
			_dateString.charAt(4) === "-" &&
			_dateString.charAt(7) === "-" &&
			_dateString.charAt(10) === " " &&
			_dateString.charAt(13) === ":" &&
			_dateString.charAt(16) === ":"
		) {
			// dateString has yyyy-MM-dd HH:mm:ss format
			year = parseInt(_dateString.substring(0, 4));
			month = parseInt(_dateString.substring(5, 7));
			day = parseInt(_dateString.substring(8, 10));
			hour = parseInt(_dateString.substring(11, 13));
			min = parseInt(_dateString.substring(14, 16));
			sec = parseInt(_dateString.substring(17, 19));

			const _formattedDate = format(
				new Date(year, month - 1, day),
				_userDateFormat
			);

			if (withTime) {
				return `${_formattedDate} ${hour < 10 ? "0" + hour.toString() : hour}:${
					min < 10 ? "0" + min.toString() : min
				}:${sec < 10 ? "0" + sec.toString() : sec}`;
			} else {
				return _formattedDate;
			}
		} else if (_dateString.match(/\d+$/)) {
			// dateString is a timestamp
			return format(new Date(parseInt(_dateString)), _userDateFormat);
		}
	} catch (e) {
		console.error("Error in dateUtils>getFormattedDate");
		return "date_error";
	}
}

/**
 * @param dateString format: dd-MM-yyyy
 */
export function getFormattedMetadataDate(date?: string) {
	if (date) {
		return (
			date.substring(6, 10) +
			date.substring(2, 6) +
			date.substring(0, 2) +
			"T00:00:00Z"
		);
	} else {
		return "errorDate";
	}
}

export function splitDateAndHour(inputDateString: string): {
	date: string;
	hour: string;
} {
	const date = new Date(inputDateString);

	const splitDate = moment(date).format("YYYY-MM-DD");
	const splitHour = moment(date).format("HH:mm");

	return {
		date: splitDate,
		hour: splitHour,
	};
}
