export const BASE = "/ui/gari-dossier-data-module/";

export enum SanctionPercOptions {
	PERC_30 = "30",
	PERC_50 = "50",
	PERC_100 = "100",
}

export const NOTES_MAX_LENGTH = 4000;

export const RDIR_GIAS =
	"D3GD0GC9GCAGDAGD5GE1GD5GC8GCBGCCGCEGE2GE4GCDGD4GA6G178";
