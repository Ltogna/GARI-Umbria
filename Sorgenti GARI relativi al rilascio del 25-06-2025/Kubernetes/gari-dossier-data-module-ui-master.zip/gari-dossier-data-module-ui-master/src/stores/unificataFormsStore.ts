import type { GenericLayerModel } from "@/models/layer";
import type {
	AdditionalDeclarationsModel,
	AdditionalLayersModel,
	ConfirmationApplicationListModel,
	FlAllConfirmedModel,
	LivestockListModel,
	OptionDetailsInfiniteListModel,
	OptionsListModel,
	PartyListModel,
	PartyModel,
	PrizesChoiceModel,
	PsrApplicationsModel,
	RelatedOptionsModel,
	ReplaceLivestockModel,
	ReplaceLivestockResponseModel,
	ReplacementOrWaiverSurfaceListModel,
	ReplacementOrWaiverWithdrawnReasonListModel,
	SaveAdditionalDeclarationsModel,
	SaveEngagementArrayModel,
	SaveEngagementZootechnicsModel,
	SaveLivestockReplacementListModel,
	SavePrizesChoiceListModel,
	SaveReplacementOrWaiverSurfaceModel,
	SaveScoreCardModel,
	SaveSelectBreedingsListModel,
	SaveTakeOverListModel,
	SaveUnifiedDeclarationsModel,
	SaveYoungFarmerDataModel,
	SaveZootechnicsInterventionListModel,
	ScoreCardDefinitionModel,
	SelectBreedingsListResponse,
	StandardDetailsModel,
	SupportOptionsListModel,
	SurfaceDetailModel,
	TakeOverListModel,
	TerritoryFiltersModel,
	UnifiedDeclarationListResponse,
	WithdrawalApplicationDetailsModel,
	WithdrawalApplicationListModel,
	WithdrawalApplicationSummaryListModel,
	WithdrawnReasonListModel,
	YoungFarmerModel,
	ZootechnicFiltersModel,
	ZootechnicInterventionResponseModel,
	ZootechnicInterventionSummaryModel,
	ZootechnicsDeclarationsListModel,
	ZootechnicsDeclarationsListResponse,
	ZootechnicsOptionListModel,
} from "@/models/unificataForms";
import { handleApiErrorAndShowAlert, sendCompiledEvent } from "@/models/utils";
import {
	askComplementaryBeforeDeleteAPI,
	deleteConfirmationApplicationInterventionAPI,
	deleteInterventionAPI,
	deleteOptionAPI,
	deleteSupportOptionAPI,
	deleteSupportOptionZootechnicsAPI,
	loadAdditionalDeclarationsAPI,
	loadAdditionalLayersAPI,
	loadConfirmationApplicationListAPI,
	loadConfirmationSurfacesOptionDetailsAPI,
	loadHelpApplicationListAPI,
	loadOptionDetailsAPI,
	loadParties,
	loadPrizesChoice,
	loadPrizesChoiceV2,
	loadPSRApplicationsAPI,
	loadReplaceLivestockListAPI,
	loadReplacementOrWaiverSurfaceAPI,
	loadReplacementOrWaiverWithdrawnReasonAPI,
	loadReplaceOrWaiverLivestockListAPI,
	loadScoreCardDefinitionAPI,
	loadSelectBreedingsListAPI,
	loadStandardDetailsAPI,
	loadStandardOptionsListAPI,
	loadStandardZootechnicsDeclarationsListAPI,
	loadStandardZootechnicsListAPI,
	loadSupportZootechnicInterventionListAPI,
	loadSupportZootechnicsFiltersAPI,
	loadSurfaceDetailApi,
	loadSurfacesFiltersAPI,
	loadTakeOverListAPI,
	loadUnifiedDeclarationsAPI,
	loadWithdrawalApplicationAPI,
	loadWithdrawalApplicationDetailsAPI,
	loadWithdrawalApplicationSummaryAPI,
	loadWithdrawnReasonListAPI,
	loadYoungFarmerDataAPI,
	loadZootechnicAllConfirmedAPI,
	loadZootechnicInterventionListAPI,
	loadZootechnicInterventionSummaryAPI,
	loadZootechnicsFiltersAPI,
	saveAdditionalDeclarationsAPI,
	saveAdditionalDeclarationsV2API,
	saveConfirmationSelectedOptionsCommitmentAPI,
	saveOptionCommitmentsByFiltersAPI,
	saveOptionSupportCommitmentsByFiltersAPI,
	savePrizesChoice,
	saveReplacementOrWaiverSurfaceAPI,
	saveReplaceOrWaiverLivestockListAPI,
	saveScoreCardAPI,
	saveSelectBreedingsListAPI,
	saveSelectedBreedingDeclarationsAPI,
	saveSelectedInterventionsAPI,
	saveSelectedOptionsAPI,
	saveSelectedOptionsCommitmentAPI,
	saveSelectedOptionsCommitmentZootechnicsAPI,
	saveSelectedSupportInterventionsAPI,
	saveSelectedSupportOptionsCommitmentAPI,
	saveSupportZootechnicsInterventionListAPI,
	saveTakeOverListAPI,
	saveUnifiedDeclarationsAPI,
	saveYoungFarmerDataAPI,
	saveZootechnicsInterventionListAPI,
} from "@/resources/api/unificataFormsApi";
import {
	ErrorType,
	type HttpResponseError,
} from "@abaco/safe-rest/src/HTTPClient";
import { defineStore } from "pinia";
import { resetDirtyState } from "./formDirtyStore";
import type { DocumentDataDocSchemaType } from "@abaco/dynamic-documents/src";
import { TabType } from "@/utils/standardTabUtils";

interface State {
	loading: boolean;
	hasError: boolean;
	errorResponse?: HttpResponseError;
	standardOptionsList: OptionsListModel;
	askComplementaryResponse?: RelatedOptionsModel;
	prizesChoiceList: PrizesChoiceModel[];
	optionDetailsList: OptionDetailsInfiniteListModel;
	supportDetailsList: OptionDetailsInfiniteListModel;
	youngFarmerData: YoungFarmerModel;
	standardZootechnicsList: ZootechnicsOptionListModel;
	standardZootechnicsDeclarationsList: ZootechnicsDeclarationsListResponse;
	saveYoungFarmerData: SaveYoungFarmerDataModel;
	standardSurfaceFilters?: TerritoryFiltersModel;
	standardZootechnicFilters?: ZootechnicFiltersModel;
	supportZootechnicFilters?: ZootechnicFiltersModel;
	saveUnifiedDeclarations: SaveUnifiedDeclarationsModel;
	unifiedDeclarationsData: UnifiedDeclarationListResponse;
	additionalDeclarations?: AdditionalDeclarationsModel;
	confirmationApplicationList: ConfirmationApplicationListModel;
	subjectList: PartyListModel | null;
	selectedSubject: PartyModel | null;
	takeOverList: TakeOverListModel;
	zootechnicInterventionList: ZootechnicInterventionResponseModel;
	supportZootechnicInterventionList: ZootechnicInterventionResponseModel;
	replacementOrWaiverSurface: ReplacementOrWaiverSurfaceListModel;
	replacementOrWaiverWithdrawnReason: ReplacementOrWaiverWithdrawnReasonListModel;
	replaceOrWaiverLivestockList: LivestockListModel;
	replaceLivestockList: ReplaceLivestockResponseModel;
	selectedLivestock: ReplaceLivestockModel;
	helpApplicationList: SupportOptionsListModel;
	standardDetails: StandardDetailsModel;
	withdrawnReasonList: WithdrawnReasonListModel;
	srb01ApplicationList: SupportOptionsListModel;
	selectBreedingsList: SelectBreedingsListResponse;
	zootechnicSummaryDetail: ZootechnicInterventionSummaryModel;
	additionalLayers: AdditionalLayersModel;
	layerList: GenericLayerModel[];
	scoreCardDefinition?: ScoreCardDefinitionModel;
	psrApplicationsList?: PsrApplicationsModel;
	withdrawalApplicationList: WithdrawalApplicationListModel;
	withdrawalApplicationDetails?: WithdrawalApplicationDetailsModel;
	withdrawalApplicationSummaryList: WithdrawalApplicationSummaryListModel;
	surfaceDetail?: Array<SurfaceDetailModel>;
	flAllConfirmed?: FlAllConfirmedModel;
}

export const useUnificataFormsStore = defineStore({
	id: "unificataFormsStore",
	state: () =>
		({
			loading: false,
			hasError: false,
			errorResponse: undefined,
			standardOptionsList: [],
			askComplementaryResponse: [],
			youngFarmerData: null,
			saveYoungFarmerData: null,
			prizesChoiceList: [],
			savePrizesChoiceList: [],
			optionDetailsList: {
				count: 0,
				nextKey: null,
				records: null,
			},
			supportDetailsList: {
				count: 0,
				nextKey: null,
				records: null,
			},
			standardZootechnicsList: [],
			standardZootechnicsDeclarationsList: {
				count: 0,
				nextKey: null,
				records: null,
			},
			standardSurfaceFilters: undefined,
			standardZootechnicFilters: undefined,
			supportZootechnicFilters: undefined,
			saveUnifiedDeclarations: null,
			unifiedDeclarationsData: null,
			confirmationApplicationList: [],
			subjectList: null,
			selectedSubject: null,
			takeOverList: null,
			zootechnicInterventionList: null,
			supportZootechnicInterventionList: null,
			replacementOrWaiverSurface: [],
			replacementOrWaiverWithdrawnReason: null,
			replaceOrWaiverLivestockList: null,
			replaceLivestockList: {
				count: 0,
				nextKey: null,
				records: null,
			},
			selectedLivestock: null,
			helpApplicationList: [],
			standardDetails: null,
			withdrawnReasonList: null,
			srb01ApplicationList: [],
			selectBreedingsList: {
				count: 0,
				nextKey: null,
				records: null,
			},
			zootechnicSummaryDetail: null,
			additionalLayers: null,
			layerList: [],
			scoreCardDefinition: undefined,
			psrApplicationsList: undefined,
			withdrawalApplicationList: [],
			withdrawalApplicationDetails: undefined,
			withdrawalApplicationSummaryList: [],
			surfaceDetail: undefined,
			flAllConfirmed: undefined,
		}) as State,
	getters: {
		getLoading: (state: State) => {
			return state.loading;
		},
		getError: (state: State) => {
			return state.hasError;
		},
		getErrorResponse: (state: State) => {
			return state.errorResponse;
		},
		getStandardOptionsList: (state: State) => {
			return state.standardOptionsList;
		},
		getAskComplementaryResponse: (state: State) => {
			return state.askComplementaryResponse;
		},
		getPrizesChoiceList: (state: State) => {
			return state.prizesChoiceList;
		},
		getOptionDetailsList: (state: State) => {
			return state.optionDetailsList;
		},
		getStandardSurfaceFilters: (state: State) => {
			return state.standardSurfaceFilters;
		},
		getStandardZootechnicFilters: (state: State) => {
			return state.standardZootechnicFilters;
		},
		getSupportZootechnicFilters: (state: State) => {
			return state.supportZootechnicFilters;
		},
		getYoungFarmerData: (state: State) => {
			return state.youngFarmerData;
		},
		getUnifiedDeclarationsData: (state: State) => {
			return state.unifiedDeclarationsData;
		},
		getStandardZootechnicsList: (state: State) => {
			return state.standardZootechnicsList;
		},
		getStandardZootechnicsDeclarationsList: (state: State) => {
			return state.standardZootechnicsDeclarationsList;
		},
		getConfirmationApplicationList: (state: State) => {
			return state.confirmationApplicationList;
		},
		getSubjectList: (state: State) => {
			return state.subjectList?.records;
		},
		getSelectedSubject: (state: State) => {
			return state.selectedSubject;
		},
		getTakeoverList: (state: State) => {
			return state.takeOverList;
		},
		getZootechnicTakeOverList: (state: State) => {
			return state.zootechnicInterventionList;
		},
		getSupportZootechnicInterventionList: (state: State) => {
			return state.supportZootechnicInterventionList;
		},
		getReplacementOrWaiverSurface: (state: State) => {
			return state.replacementOrWaiverSurface;
		},
		getReplacementOrWaiverWithdrawnReason: (state: State) => {
			return state.replacementOrWaiverWithdrawnReason;
		},
		getReplaceOrWaiverLivestockList: (state: State) => {
			return state.replaceOrWaiverLivestockList;
		},
		getReplaceLivestockList: (state: State) => {
			return state.replaceLivestockList;
		},
		getSelectedLivestock: (state: State) => {
			return state.selectedLivestock;
		},
		getHelpApplicationList: (state: State) => {
			return state.helpApplicationList;
		},
		getStandardDetails: (state: State) => {
			return state.standardDetails;
		},
		getWithdrawnReasonList: (state: State) => {
			return state.withdrawnReasonList;
		},
		getSRB01ApplicationList: (state: State) => {
			return state.srb01ApplicationList;
		},
		getSelectBreedingsList: (state: State) => {
			return state.selectBreedingsList;
		},
		getZootechnicSummaryDetail: (state: State) => {
			return state.zootechnicSummaryDetail;
		},
		getAdditionalLayers: (state: State) => {
			return state.additionalLayers;
		},
		getLayerList: (state: State) => {
			return state.layerList;
		},
		getAdditionalDeclarations: (state: State) => {
			return state.additionalDeclarations;
		},
		getScoreCardDefinition: (state: State) => {
			return state.scoreCardDefinition;
		},
		getPSRApplications: (state: State) => {
			return state.psrApplicationsList;
		},
		getWithdrawalApplication: (state: State) => {
			return state.withdrawalApplicationList;
		},
		getWithdrawalApplicationDetails: (state: State) => {
			return state.withdrawalApplicationDetails;
		},
		getWithdrawalApplicationSummary: (state: State) => {
			return state.withdrawalApplicationSummaryList;
		},
		getSurfaceDetail: (state: State) => {
			return state.surfaceDetail;
		},
		getAllConfirmed: (state: State) => {
			return state.flAllConfirmed;
		},
	},
	actions: {
		clearOptionDetailsList() {
			this.optionDetailsList = {
				count: 0,
				nextKey: null,
				records: null,
			};
		},
		clearZootechnicsDeclarationsList() {
			this.standardZootechnicsDeclarationsList = {
				count: 0,
				nextKey: null,
				records: null,
			};
		},
		clearSupportOptionDetailsList() {
			this.supportDetailsList = {
				count: 0,
				nextKey: null,
				records: null,
			};
		},
		clearLayerList() {
			this.layerList = [];
		},
		setLayerVisibility(layer: GenericLayerModel, value: boolean) {
			if (
				this.layerList &&
				Array.isArray(this.layerList) &&
				this.layerList.length > 0
			) {
				const _currLay = this.layerList.find(l => l.name === layer.name);
				_currLay && (_currLay.visible = value);
			}
		},
		pushToLayerList(layer: GenericLayerModel) {
			if (Array.isArray(this.layerList) && layer) {
				this.layerList.push(layer);
			}
		},
		async loadStandardOptionsList(
			formCode: string,
			takeoverId?: number,
			overrideOptionCodes?: string
		) {
			this.loading = true;
			this.hasError = false;
			this.standardOptionsList = [];
			this.clearOptionDetailsList();
			const response = await loadStandardOptionsListAPI(
				formCode,
				takeoverId,
				overrideOptionCodes
			);
			if (response.errorType !== ErrorType.NONE) {
				this.handleError(response, true);
			} else {
				this.hasError = false;
				this.standardOptionsList = response.data;
			}
			this.loading = false;
		},
		async saveSelectedOptions(
			optionsList: string[],
			formCode: string,
			compileStatusIdentifier: string
		) {
			this.loading = true;
			this.hasError = false;
			const response = await saveSelectedOptionsAPI(
				formCode,
				optionsList,
				compileStatusIdentifier
			);
			if (response.errorType !== ErrorType.NONE) {
				this.handleError(response, false);
			} else {
				this.hasError = false;
				resetDirtyState();
				sendCompiledEvent();
			}
			this.loading = false;
		},
		async askComplementaryBeforeDelete(
			formCode: string,
			optionCodes: string[]
		) {
			this.loading = true;
			this.hasError = false;
			this.askComplementaryResponse = undefined;
			const response = await askComplementaryBeforeDeleteAPI(
				formCode,
				optionCodes
			);
			if (response.errorType !== ErrorType.NONE) {
				this.handleError(response, true);
			} else {
				this.hasError = false;
				this.askComplementaryResponse = response.data;
			}
			this.loading = false;
		},
		async deleteOption(
			optionCode: string,
			compileStatusIdentifier: string,
			formCode: string
		) {
			this.loading = true;
			this.hasError = false;
			const response = await deleteOptionAPI(
				optionCode,
				compileStatusIdentifier,
				formCode
			);
			if (response.errorType !== ErrorType.NONE) {
				this.handleError(response, true);
			} else {
				this.hasError = false;
				sendCompiledEvent();
			}
			this.loading = false;
		},
		async deleteSupportOption(
			optionCode: string,
			compileStatusIdentifier: string,
			formCode: string
		) {
			this.loading = true;
			this.hasError = false;
			const response = await deleteSupportOptionAPI(
				optionCode,
				compileStatusIdentifier,
				formCode
			);
			if (response.errorType !== ErrorType.NONE) {
				this.handleError(response, true);
			} else {
				this.hasError = false;
				sendCompiledEvent();
			}
			this.loading = false;
		},
		async deleteSupportOptionZootechnics(
			optionCode: string,
			compileStatusIdentifier: string,
			formCode: string
		) {
			this.loading = true;
			this.hasError = false;
			const response = await deleteSupportOptionZootechnicsAPI(
				optionCode,
				compileStatusIdentifier,
				formCode
			);
			if (response.errorType !== ErrorType.NONE) {
				this.handleError(response, true);
			} else {
				this.hasError = false;
				sendCompiledEvent();
			}
			this.loading = false;
		},
		async saveSelectedOptionsCommitment(
			engagementArray: SaveEngagementArrayModel,
			compileStatusIdentifier: string,
			formCode: string,
			action?: string
		) {
			this.loading = true;
			this.hasError = false;
			const response = await saveSelectedOptionsCommitmentAPI(
				engagementArray,
				compileStatusIdentifier,
				formCode,
				action
			);
			if (response.errorType !== ErrorType.NONE) {
				this.handleError(response, false);
			} else {
				this.hasError = false;
				resetDirtyState();
				sendCompiledEvent();
			}
			this.loading = false;
		},
		async saveSelectedSupportOptionsCommitment(
			engagementArray: SaveEngagementArrayModel,
			compileStatusIdentifier: string,
			formCode: string,
			action?: string
		) {
			this.loading = true;
			this.hasError = false;
			const response = await saveSelectedSupportOptionsCommitmentAPI(
				engagementArray,
				compileStatusIdentifier,
				formCode,
				action
			);
			if (response.errorType !== ErrorType.NONE) {
				this.handleError(response, false);
			} else {
				this.hasError = false;
				resetDirtyState();
				sendCompiledEvent();
			}
			this.loading = false;
		},
		async loadOptionDetails(
			optionCode: string,
			nextKey?: string | null,
			councilCode?: string,
			sheet?: string,
			parcelCode?: string,
			engagement?: string,
			cropCode?: string
		) {
			this.loading = true;
			this.hasError = false;
			this.clearOptionDetailsList();
			const response = await loadOptionDetailsAPI(
				optionCode,
				nextKey,
				councilCode,
				sheet,
				parcelCode,
				engagement,
				cropCode
			);
			if (response.errorType !== ErrorType.NONE) {
				this.handleError(response, true);
			} else {
				this.hasError = false;
				this.optionDetailsList = response.data;
			}
			this.loading = false;
		},
		async saveOptionCommitmentsByFilters(
			formCode: string,
			optionCode: string,
			compileStatusIdentifier: string,
			action: string,
			councilCode?: string,
			sheet?: string,
			parcelCode?: string,
			engagement?: string,
			cropCode?: string,
			takeoverId?: number,
			overrideOptionCodes?: string
		) {
			this.loading = true;
			this.hasError = false;
			const response = await saveOptionCommitmentsByFiltersAPI(
				formCode,
				optionCode,
				compileStatusIdentifier,
				action,
				councilCode,
				sheet,
				parcelCode,
				engagement,
				cropCode,
				takeoverId,
				overrideOptionCodes
			);
			if (response.errorType !== ErrorType.NONE) {
				this.handleError(response, false);
			} else {
				this.hasError = false;
				resetDirtyState();
				sendCompiledEvent();
			}
			this.loading = false;
		},
		async saveOptionSupportCommitmentsByFilters(
			formCode: string,
			optionCode: string,
			compileStatusIdentifier: string,
			action: string,
			councilCode?: string,
			sheet?: string,
			parcelCode?: string,
			engagement?: string,
			cropCode?: string,
			takeoverId?: number
		) {
			this.loading = true;
			this.hasError = false;
			const response = await saveOptionSupportCommitmentsByFiltersAPI(
				formCode,
				optionCode,
				compileStatusIdentifier,
				action,
				councilCode,
				sheet,
				parcelCode,
				engagement,
				cropCode,
				takeoverId
			);
			if (response.errorType !== ErrorType.NONE) {
				this.handleError(response, false);
			} else {
				this.hasError = false;
				resetDirtyState();
				sendCompiledEvent();
			}
			this.loading = false;
		},
		async getPrizesChoice(version?: "v2") {
			this.prizesChoiceList = [];
			this.loading = true;
			this.hasError = false;
			const response =
				version === "v2"
					? await loadPrizesChoiceV2()
					: await loadPrizesChoice();
			if (response.errorType !== ErrorType.NONE) {
				this.handleError(response, true);
			} else {
				this.hasError = false;
				this.prizesChoiceList = response.data;
			}
			this.loading = false;
		},
		async savePrizesChoice(
			choices: SavePrizesChoiceListModel,
			compileStatusIdentifier: string
		) {
			this.loading = true;
			this.hasError = false;
			const response = await savePrizesChoice(choices, compileStatusIdentifier);
			if (response.errorType !== ErrorType.NONE) {
				this.handleError(response, true);
			} else {
				this.hasError = false;
				resetDirtyState();
				sendCompiledEvent();
			}
			this.loading = false;
		},
		async loadYoungFarmerData(
			compileStatusIdentifier: string,
			dynamicDocumentCode: string
		) {
			this.loading = true;
			this.hasError = false;
			const response = await loadYoungFarmerDataAPI(
				compileStatusIdentifier,
				dynamicDocumentCode
			);
			if (response.errorType !== ErrorType.NONE) {
				this.handleError(response, false);
			} else {
				this.hasError = false;
				this.youngFarmerData = response.data;
			}
			this.loading = false;
		},
		async saveYoungFarmerData(
			compileStatusIdentifier: string,
			dynamicDocumentCode: string,
			youngFarmerData: SaveYoungFarmerDataModel
		) {
			this.loading = true;
			this.hasError = false;
			const response = await saveYoungFarmerDataAPI(
				compileStatusIdentifier,
				dynamicDocumentCode,
				youngFarmerData
			);
			if (response.errorType !== ErrorType.NONE) {
				this.handleError(response, true);
			} else {
				this.hasError = false;
				sendCompiledEvent();
				resetDirtyState();
			}
			this.loading = false;
		},
		async loadStandardZootechnicsList(
			formCode: string,
			compileStatusIdentifier: string
		) {
			this.loading = true;
			this.hasError = false;
			this.standardZootechnicsList = [];
			const response = await loadStandardZootechnicsListAPI(
				formCode,
				compileStatusIdentifier
			);
			if (response.errorType !== ErrorType.NONE) {
				this.handleError(response, true);
			} else {
				this.hasError = false;
				this.standardZootechnicsList = response.data;
			}
			this.loading = false;
		},
		async loadStandardZootechnicsDeclarationsList(
			formCode: string,
			compileStatusIdentifier: string,
			optionCode: string,
			nextKey?: string | null
		) {
			this.loading = true;
			this.hasError = false;
			this.clearZootechnicsDeclarationsList();
			const response = await loadStandardZootechnicsDeclarationsListAPI(
				formCode,
				compileStatusIdentifier,
				optionCode,
				nextKey
			);
			if (response.errorType !== ErrorType.NONE) {
				this.handleError(response, true);
			} else {
				this.hasError = false;
				this.standardZootechnicsDeclarationsList = response.data;
			}
			this.loading = false;
		},
		async saveSelectedInterventions(
			optionsList: string[],
			formCode: string,
			compileStatusIdentifier: string
		) {
			this.loading = true;
			this.hasError = false;
			const response = await saveSelectedInterventionsAPI(
				formCode,
				optionsList,
				compileStatusIdentifier
			);
			if (response.errorType !== ErrorType.NONE) {
				this.handleError(response, false);
			} else {
				this.hasError = false;
				resetDirtyState();
				sendCompiledEvent();
			}
			this.loading = false;
		},
		async saveSelectedSupportInterventions(
			optionsList: string[],
			formCode: string,
			compileStatusIdentifier: string
		) {
			this.loading = true;
			this.hasError = false;
			const response = await saveSelectedSupportInterventionsAPI(
				formCode,
				optionsList,
				compileStatusIdentifier
			);
			if (response.errorType !== ErrorType.NONE) {
				this.handleError(response, false);
			} else {
				this.hasError = false;
				resetDirtyState();
				sendCompiledEvent();
			}
			this.loading = false;
		},
		async saveSelectedBreedingDeclarations(
			optionsList: ZootechnicsDeclarationsListModel,
			formCode: string,
			compileStatusIdentifier: string
		) {
			this.loading = true;
			this.hasError = false;
			const response = await saveSelectedBreedingDeclarationsAPI(
				formCode,
				optionsList,
				compileStatusIdentifier
			);
			if (response.errorType !== ErrorType.NONE) {
				this.handleError(response, true);
			} else {
				this.hasError = false;
				resetDirtyState();
				sendCompiledEvent();
			}
			this.loading = false;
		},
		async deleteIntervention(
			optionCode: string,
			compileStatusIdentifier: string,
			formCode: string
		) {
			this.loading = true;
			this.hasError = false;
			const response = await deleteInterventionAPI(
				optionCode,
				compileStatusIdentifier,
				formCode
			);
			if (response.errorType !== ErrorType.NONE) {
				this.handleError(response, false);
			} else {
				this.hasError = false;
				sendCompiledEvent();
			}
			this.loading = false;
		},
		async saveSelectedOptionsZootechnicsCommitment(
			engagementArray: SaveEngagementZootechnicsModel,
			compileStatusIdentifier: string,
			formCode: string,
			action?: "ENGAGE_ALL" | "DISENGAGE_ALL"
		) {
			this.loading = true;
			this.hasError = false;
			const response = await saveSelectedOptionsCommitmentZootechnicsAPI(
				engagementArray,
				compileStatusIdentifier,
				formCode,
				action
			);
			if (response.errorType !== ErrorType.NONE) {
				this.handleError(response, true);
			} else {
				this.hasError = false;
				resetDirtyState();
				sendCompiledEvent();
			}
			this.loading = false;
		},
		async loadSurfacesFilters(
			optionCode: string,
			councilCode?: string,
			sheet?: string,
			parcelCode?: string
		) {
			this.loading = true;
			this.hasError = false;
			this.standardSurfaceFilters = undefined;
			const response = await loadSurfacesFiltersAPI(
				optionCode,
				councilCode,
				sheet,
				parcelCode
			);
			if (response.errorType !== ErrorType.NONE) {
				this.handleError(response, true);
			} else {
				this.hasError = false;
				this.standardSurfaceFilters = response.data;
			}
			this.loading = false;
		},
		async saveUnifiedDeclarations(
			document_code: string,
			unifiedDeclarations: SaveUnifiedDeclarationsModel,
			compileStatusIdentifier: string
		) {
			this.loading = true;
			this.hasError = false;
			const response = await saveUnifiedDeclarationsAPI(
				document_code,
				unifiedDeclarations,
				compileStatusIdentifier
			);
			if (response.errorType !== ErrorType.NONE) {
				this.handleError(response, true);
			} else {
				this.hasError = false;
				sendCompiledEvent();
				resetDirtyState();
			}
			this.loading = false;
		},
		async loadUnifiedDeclarationsData(documentCode: string) {
			this.loading = true;
			this.hasError = false;
			this.unifiedDeclarationsData = null;
			const response = await loadUnifiedDeclarationsAPI(documentCode);
			if (response.errorType !== ErrorType.NONE) {
				this.handleError(response, true);
			} else {
				this.hasError = false;
				this.unifiedDeclarationsData = response.data;
			}
			this.loading = false;
		},
		async saveAdditionalDeclarations(
			form_code: string,
			document_code: string,
			option_code: string,
			additionalDeclaration: SaveAdditionalDeclarationsModel,
			compileStatusIdentifier: string,
			parentForm?: string,
			takeoverId?: number
		) {
			this.loading = true;
			this.hasError = false;
			const response = await saveAdditionalDeclarationsAPI(
				form_code,
				document_code,
				option_code,
				additionalDeclaration,
				compileStatusIdentifier,
				parentForm,
				takeoverId
			);
			if (response.errorType !== ErrorType.NONE) {
				this.handleError(response, true);
			} else {
				sendCompiledEvent();
				this.hasError = false;
				sendCompiledEvent();
				resetDirtyState();
			}
			this.loading = false;
		},
		async saveAdditionalDeclarationsV2(
			form_code: string,
			document_code: string,
			option_code: string,
			additionalDeclaration: SaveAdditionalDeclarationsModel,
			compileStatusIdentifier: string,
			takeoverId?: number
		) {
			this.loading = true;
			this.hasError = false;
			const response = await saveAdditionalDeclarationsV2API(
				form_code,
				document_code,
				option_code,
				additionalDeclaration,
				compileStatusIdentifier,
				takeoverId
			);
			if (response.errorType !== ErrorType.NONE) {
				this.handleError(response, true);
			} else {
				sendCompiledEvent();
				this.hasError = false;
				sendCompiledEvent();
				resetDirtyState();
			}
			this.loading = false;
		},
		updateDeclaration(
			// eslint-disable-next-line @typescript-eslint/no-explicit-any
			option: any,
			optionCode: string,
			docCode: string | null | undefined,
			takeOverId?: number,
			document?: DocumentDataDocSchemaType
		) {
			if (
				optionCode &&
				option.optionCode === optionCode &&
				((takeOverId && option?.takeOver?.takeoverId === takeOverId) ||
					(!takeOverId && !option.takeOver)) &&
				(option.waiverAdditionalDeclaration || option.additionalDeclaration) &&
				document
			) {
				if (
					option.waiverAdditionalDeclaration &&
					option.waiverAdditionalDeclaration.documentDefinition?.code ===
						docCode
				) {
					option.waiverAdditionalDeclaration.document = document;
				} else if (
					option.additionalDeclaration &&
					option.additionalDeclaration.documentDefinition?.code === docCode
				) {
					option.additionalDeclaration.document = document;
				}
			}
		},
		setDocumentDeclaration(
			optionCode: string,
			docCode: string | null | undefined,
			tabType: TabType,
			takeOverId?: number,
			document?: DocumentDataDocSchemaType
		) {
			// eslint-disable-next-line @typescript-eslint/no-explicit-any
			let list: any = [];
			switch (tabType) {
				case TabType.SURFACES:
				case TabType.SRB01:
					list = this.standardOptionsList;
					break;
				case TabType.CONFIRMATION:
					list = this.confirmationApplicationList;
					break;
				case TabType.SUPPORT:
					list = this.helpApplicationList;
					break;
				case TabType.ZOOTECH:
					list = this.standardZootechnicsList;
					break;
				default:
					break;
			}
			// eslint-disable-next-line @typescript-eslint/no-explicit-any
			list.forEach((opt: any) =>
				this.updateDeclaration(opt, optionCode, docCode, takeOverId, document)
			);
		},
		async loadConfirmationApplicationList(
			formCode: string,
			geometryType?: string
		) {
			this.loading = true;
			this.hasError = false;
			this.confirmationApplicationList = [];
			const response = await loadConfirmationApplicationListAPI(
				formCode,
				geometryType
			);
			if (response.errorType !== ErrorType.NONE) {
				this.handleError(response, true);
			} else {
				this.hasError = false;
				this.confirmationApplicationList = response.data;
			}
			this.loading = false;
		},
		async searchSubjects(
			cuaa?: string | null,
			partyDesc?: string | null,
			resetList?: boolean
		) {
			this.loading = true;
			this.hasError = false;
			const useCuaa = cuaa?.trimEnd();
			const usePartyDesc = partyDesc?.trimEnd();
			const actualNextKey = this.subjectList?.nextKey;
			const response = await loadParties(useCuaa, usePartyDesc, actualNextKey);
			if (response.errorType !== ErrorType.NONE) {
				this.handleError(response, false);
			} else {
				if (!resetList && this.subjectList) {
					this.subjectList.records.push(...response.data.records);
					this.subjectList.nextKey = response.data.nextKey;
					this.subjectList.count = response.data.count;
				} else {
					this.subjectList = response.data;
					resetDirtyState();
				}
			}
			this.loading = false;
		},
		clearSubjectList() {
			this.subjectList = null;
		},
		clearSelectedSubject() {
			this.selectedSubject = null;
		},
		setSelectedSubject(subject: PartyModel | null) {
			this.selectedSubject = subject;
		},
		async loadTakeOverList(
			cuaa: string,
			partyId?: number,
			optionCode?: string
		) {
			this.loading = true;
			this.hasError = false;
			this.takeOverList = null;
			const response = await loadTakeOverListAPI(cuaa, partyId, optionCode);
			if (response.errorType !== ErrorType.NONE) {
				this.handleError(response, true);
			} else {
				this.hasError = false;
				this.takeOverList = response.data;
			}
			this.loading = false;
		},
		async saveTakeOverList(
			formCode: string,
			compileStatusIdentifier: string,
			takeOverList: SaveTakeOverListModel,
			partyId?: number
		) {
			this.loading = true;
			this.hasError = false;
			const response = await saveTakeOverListAPI(
				formCode,
				compileStatusIdentifier,
				takeOverList,
				partyId
			);
			if (response.errorType !== ErrorType.NONE) {
				this.handleError(response, true);
			} else {
				this.hasError = false;
				sendCompiledEvent();
				resetDirtyState();
			}
			this.loading = false;
		},
		async deleteConfirmationApplicationIntervention(
			optionCode: string,
			formCode: string,
			takeoverId: number,
			takeOverApplicationCode: string,
			compileStatusIdentifier: string
		) {
			this.loading = true;
			this.hasError = false;
			const response = await deleteConfirmationApplicationInterventionAPI(
				optionCode,
				formCode,
				takeoverId,
				takeOverApplicationCode,
				compileStatusIdentifier
			);
			if (response.errorType !== ErrorType.NONE) {
				this.handleError(response, true);
			} else {
				this.hasError = false;
				sendCompiledEvent();
			}
			this.loading = false;
		},
		async loadZootechnicInterventionList(
			formCode: string,
			optionCode: string,
			zootechnicsBreedingCode?: string,
			earTag?: string,
			species?: string,
			takeoverId?: number,
			nextKey?: string | null
		) {
			this.loading = true;
			this.hasError = false;
			const response = await loadZootechnicInterventionListAPI(
				formCode,
				optionCode,
				zootechnicsBreedingCode,
				earTag,
				species,
				takeoverId,
				nextKey
			);
			if (response.errorType !== ErrorType.NONE) {
				this.handleError(response, true);
			} else {
				this.hasError = false;
				this.zootechnicInterventionList = response.data;
			}
			this.loading = false;
		},
		async loadSupportZootechnicInterventionList(
			formCode: string,
			optionCode: string,
			zootechnicsBreedingCode?: string,
			earTag?: string,
			species?: string,
			takeoverId?: number,
			nextKey?: string | null
		) {
			this.loading = true;
			this.hasError = false;
			this.zootechnicInterventionList = null;
			const response = await loadSupportZootechnicInterventionListAPI(
				formCode,
				optionCode,
				zootechnicsBreedingCode,
				earTag,
				species,
				takeoverId,
				nextKey
			);
			if (response.errorType !== ErrorType.NONE) {
				this.handleError(response, true);
			} else {
				this.hasError = false;
				this.supportZootechnicInterventionList = response.data;
			}
			this.loading = false;
		},
		async loadReplacementOrWaiverSurface(
			optionCode: string,
			formCode: string,
			takeoverId?: number
		) {
			this.loading = true;
			this.hasError = false;
			this.replacementOrWaiverSurface = [];
			const response = await loadReplacementOrWaiverSurfaceAPI(
				optionCode,
				formCode,
				takeoverId
			);
			if (response.errorType !== ErrorType.NONE) {
				this.handleError(response, true);
			} else {
				this.hasError = false;
				this.replacementOrWaiverSurface = response.data;
			}
			this.loading = false;
		},
		async saveReplacementOrWaiverSurface(
			optionCode: string,
			formCode: string,
			compileStatusIdentifier: string,
			saveList: SaveReplacementOrWaiverSurfaceModel,
			takeoverId?: number
		) {
			this.loading = true;
			this.hasError = false;
			const response = await saveReplacementOrWaiverSurfaceAPI(
				optionCode,
				formCode,
				compileStatusIdentifier,
				saveList,
				takeoverId
			);
			if (response.errorType !== ErrorType.NONE) {
				this.handleError(response, true);
			} else {
				this.hasError = false;
				sendCompiledEvent();
				resetDirtyState();
			}
			this.loading = false;
		},
		async loadReplacementOrWaiverWithdrawnReason() {
			this.loading = true;
			this.hasError = false;
			this.replacementOrWaiverWithdrawnReason = null;
			const response = await loadReplacementOrWaiverWithdrawnReasonAPI();
			if (response.errorType !== ErrorType.NONE) {
				this.handleError(response, true);
			} else {
				this.hasError = false;
				this.replacementOrWaiverWithdrawnReason = response.data;
			}
			this.loading = false;
		},
		async loadReplaceOrWaiverLivestockList(
			optionCode: string,
			formCode: string,
			takeoverId?: number
		) {
			this.loading = true;
			this.hasError = false;
			this.replaceOrWaiverLivestockList = null;
			const response = await loadReplaceOrWaiverLivestockListAPI(
				optionCode,
				formCode,
				takeoverId
			);
			if (response.errorType !== ErrorType.NONE) {
				this.handleError(response, true);
			} else {
				this.hasError = false;
				this.replaceOrWaiverLivestockList = response.data;
			}
			this.loading = false;
		},
		async loadReplaceLivestockList(
			optionCode: string,
			formCode: string,
			resetList: boolean,
			takeoverId: number | null,
			earTag: string | null,
			aslCode: string | null
		) {
			this.loading = true;
			this.hasError = false;
			const actualNextKey = this.replaceLivestockList?.nextKey ?? null;
			this.replaceLivestockList = null;
			const response = await loadReplaceLivestockListAPI(
				optionCode,
				formCode,
				actualNextKey,
				takeoverId,
				earTag,
				aslCode
			);
			if (response.errorType !== ErrorType.NONE) {
				this.handleError(response, true);
			} else {
				this.hasError = false;
				this.replaceLivestockList = response.data;
			}
			this.loading = false;
		},
		clearReplaceLivestockList() {
			this.replaceLivestockList = null;
		},
		clearSelectedLivestock() {
			this.selectedLivestock = null;
		},
		setSelectedLivestock(livestock: ReplaceLivestockModel | null) {
			this.selectedLivestock = livestock;
		},
		async saveReplaceOrWaiverLivestockList(
			optionCode: string,
			formCode: string,
			list: SaveLivestockReplacementListModel,
			compileStatusIdentifier: string,
			takeoverId?: number
		) {
			this.loading = true;
			this.hasError = false;
			const response = await saveReplaceOrWaiverLivestockListAPI(
				optionCode,
				formCode,
				list,
				compileStatusIdentifier,
				takeoverId
			);
			if (response.errorType !== ErrorType.NONE) {
				this.handleError(response, true);
			} else {
				this.hasError = false;
				sendCompiledEvent();
				resetDirtyState();
			}
			this.loading = false;
		},
		async loadHelpApplicationList(
			formCode: string,
			compileStatusIdentifier: string
		) {
			this.loading = true;
			this.hasError = false;
			this.helpApplicationList = [];
			const response = await loadHelpApplicationListAPI(
				formCode,
				compileStatusIdentifier
			);
			if (response.errorType !== ErrorType.NONE) {
				this.handleError(response, true);
			} else {
				this.hasError = false;
				this.helpApplicationList = response.data;
			}
			this.loading = false;
		},
		async loadStandardDetails(
			optionCode: string,
			formCode: string,
			takeoverId?: number
		) {
			this.loading = true;
			this.hasError = false;
			this.standardDetails = null;
			const response = await loadStandardDetailsAPI(
				optionCode,
				formCode,
				takeoverId
			);
			if (response.errorType !== ErrorType.NONE) {
				this.handleError(response, true);
			} else {
				this.hasError = false;
				this.standardDetails = response.data;
			}
			this.loading = false;
		},
		async loadWithdrawnReasonList() {
			this.loading = true;
			this.hasError = false;
			this.withdrawnReasonList = null;
			const response = await loadWithdrawnReasonListAPI();
			if (response.errorType !== ErrorType.NONE) {
				this.handleError(response, true);
			} else {
				this.hasError = false;
				this.withdrawnReasonList = response.data;
			}
			this.loading = false;
		},
		async saveZootechnicsInterventionList(
			formCode: string,
			optionCode: string,
			compileStatusIdentifier: string,
			list: SaveZootechnicsInterventionListModel,
			breedingCode?: string,
			earTag?: string,
			species?: string,
			action?: string,
			takeoverId?: number,
			commitmentYear?: number
		) {
			this.loading = true;
			this.hasError = false;
			const response = await saveZootechnicsInterventionListAPI(
				formCode,
				optionCode,
				compileStatusIdentifier,
				list,
				breedingCode,
				earTag,
				species,
				action,
				takeoverId,
				commitmentYear
			);
			if (response.errorType !== ErrorType.NONE) {
				this.handleError(response, true);
			} else {
				this.hasError = false;
				sendCompiledEvent();
				resetDirtyState();
			}
			this.loading = false;
		},
		async saveSupportZootechnicsInterventionList(
			formCode: string,
			optionCode: string,
			compileStatusIdentifier: string,
			list: SaveZootechnicsInterventionListModel,
			breedingCode?: string,
			earTag?: string,
			species?: string,
			action?: string,
			takeoverId?: number
		) {
			this.loading = true;
			this.hasError = false;
			const response = await saveSupportZootechnicsInterventionListAPI(
				formCode,
				optionCode,
				compileStatusIdentifier,
				list,
				breedingCode,
				earTag,
				species,
				action,
				takeoverId
			);
			if (response.errorType !== ErrorType.NONE) {
				this.handleError(response, true);
			} else {
				this.hasError = false;
				sendCompiledEvent();
				resetDirtyState();
			}
			this.loading = false;
		},
		async loadZootechnicsFilters(
			optionCode: string,
			formCode: string,
			breedingCode?: string,
			subCodSpecies?: string,
			takeoverId?: number
		) {
			this.loading = true;
			this.hasError = false;
			this.standardZootechnicFilters = undefined;
			const response = await loadZootechnicsFiltersAPI(
				optionCode,
				formCode,
				breedingCode,
				subCodSpecies,
				takeoverId
			);
			if (response.errorType !== ErrorType.NONE) {
				this.handleError(response, true);
			} else {
				this.hasError = false;
				this.standardZootechnicFilters = response.data;
			}
			this.loading = false;
		},
		async loadSupportZootechnicsFilters(
			optionCode: string,
			formCode: string,
			breedingCode?: string,
			subCodSpecies?: string,
			takeoverId?: number
		) {
			this.loading = true;
			this.hasError = false;
			this.supportZootechnicFilters = undefined;
			const response = await loadSupportZootechnicsFiltersAPI(
				optionCode,
				formCode,
				breedingCode,
				subCodSpecies,
				takeoverId
			);
			if (response.errorType !== ErrorType.NONE) {
				this.handleError(response, true);
			} else {
				this.hasError = false;
				this.supportZootechnicFilters = response.data;
			}
			this.loading = false;
		},
		async loadZootechnicSummaryDetails(
			optionCode: string,
			formCode: string,
			takeoverId?: number
		) {
			this.loading = true;
			this.hasError = false;
			this.zootechnicSummaryDetail = null;
			const response = await loadZootechnicInterventionSummaryAPI(
				optionCode,
				formCode,
				takeoverId
			);
			if (response.errorType !== ErrorType.NONE) {
				this.handleError(response, true);
			} else {
				this.hasError = false;
				this.zootechnicSummaryDetail = response.data;
			}
			this.loading = false;
		},
		async loadSelectBreedingsList(
			formCode: string,
			optionCode: string,
			nextKey?: string | null
		) {
			this.loading = true;
			this.hasError = false;
			const response = await loadSelectBreedingsListAPI(
				formCode,
				optionCode,
				nextKey
			);
			if (response.errorType !== ErrorType.NONE) {
				this.handleError(response, true);
			} else {
				this.hasError = false;
				this.selectBreedingsList = response.data;
			}
			this.loading = false;
		},
		async saveSelectBreedingsList(
			formCode: string,
			compileStatusIdentifier: string,
			list: SaveSelectBreedingsListModel,
			action?: string
		) {
			this.loading = true;
			this.hasError = false;
			const response = await saveSelectBreedingsListAPI(
				formCode,
				compileStatusIdentifier,
				list,
				action
			);
			if (response.errorType !== ErrorType.NONE) {
				this.handleError(response, true);
			} else {
				this.hasError = false;
				this.selectBreedingsList = response.data;
				sendCompiledEvent();
				resetDirtyState();
			}
			this.loading = false;
		},
		async loadAdditionalLayers(moduleId: string, srs: string) {
			this.loading = true;
			this.hasError = false;
			const response = await loadAdditionalLayersAPI(moduleId, srs);
			if (response.errorType !== ErrorType.NONE) {
				this.handleError(response, true);
			} else {
				this.hasError = false;
				this.additionalLayers = response.data;
			}
			this.loading = false;
		},
		async loadConfirmationOptionDetails(
			optionCode: string,
			formCode: string,
			nextKey?: string | null,
			councilCode?: string,
			sheet?: string,
			parcelCode?: string,
			engagement?: string,
			cropCode?: string,
			takeoverId?: number
		) {
			this.loading = true;
			this.hasError = false;
			this.clearOptionDetailsList();
			const response = await loadConfirmationSurfacesOptionDetailsAPI(
				optionCode,
				formCode,
				nextKey,
				councilCode,
				sheet,
				parcelCode,
				engagement,
				cropCode,
				takeoverId
			);
			if (response.errorType !== ErrorType.NONE) {
				this.handleError(response, true);
			} else {
				this.hasError = false;
				this.optionDetailsList = response.data;
			}
			this.loading = false;
		},
		async saveConfirmationSelectedOptionsCommitment(
			engagementArray: SaveEngagementArrayModel,
			compileStatusIdentifier: string,
			formCode: string,
			action?: string,
			takeoverId?: number
		) {
			this.loading = true;
			this.hasError = false;
			const response = await saveConfirmationSelectedOptionsCommitmentAPI(
				engagementArray,
				compileStatusIdentifier,
				formCode,
				action,
				takeoverId
			);
			if (response.errorType !== ErrorType.NONE) {
				this.handleError(response, false);
			} else {
				this.hasError = false;
				resetDirtyState();
				sendCompiledEvent();
			}
			this.loading = false;
		},
		async loadAdditionalDeclarations(documentCode: string) {
			this.loading = true;
			this.hasError = false;
			this.unifiedDeclarationsData = null;
			const response = await loadAdditionalDeclarationsAPI(documentCode);
			if (response.errorType !== ErrorType.NONE) {
				this.handleError(response, true);
			} else {
				this.hasError = false;
				this.additionalDeclarations = response.data;
			}
			this.loading = false;
		},
		async loadScoreCardDefinition(optionCode: string) {
			this.loading = true;
			this.hasError = false;
			this.unifiedDeclarationsData = null;
			const response = await loadScoreCardDefinitionAPI(optionCode);
			if (response.errorType !== ErrorType.NONE) {
				this.handleError(response, true);
			} else {
				this.hasError = false;
				this.scoreCardDefinition = response.data;
			}
			this.loading = false;
		},
		async saveScoreCard(
			optionCode: string,
			choicesList: SaveScoreCardModel,
			compileStatusIdentifier: string,
			formCode: string
		) {
			this.loading = true;
			this.hasError = false;
			const response = await saveScoreCardAPI(
				optionCode,
				choicesList,
				compileStatusIdentifier,
				formCode
			);
			if (response.errorType !== ErrorType.NONE) {
				this.handleError(response, true);
			} else {
				this.hasError = false;
				sendCompiledEvent();
				resetDirtyState();
			}
			this.loading = false;
		},
		async loadPSRApplications() {
			this.loading = true;
			this.hasError = false;
			const response = await loadPSRApplicationsAPI();
			if (response.errorType !== ErrorType.NONE) {
				this.handleError(response, true);
			} else {
				this.psrApplicationsList = response.data;
			}
			this.loading = false;
		},
		handleError(response: unknown, showAlert: boolean) {
			this.hasError = true;
			this.errorResponse = response as HttpResponseError;
			if (showAlert) handleApiErrorAndShowAlert(response);
		},
		async loadWithdrawalApplication() {
			this.withdrawalApplicationList = [];
			this.loading = true;
			this.hasError = false;
			const response = await loadWithdrawalApplicationAPI();
			if (response.errorType !== ErrorType.NONE) {
				this.hasError = true;
				this.errorResponse = response as HttpResponseError;
				handleApiErrorAndShowAlert(response);
			} else {
				this.hasError = false;
				this.withdrawalApplicationList = response.data;
			}
			this.loading = false;
		},
		async loadWithdrawalApplicationDetails(withdrawedApplicationId: number) {
			this.loading = true;
			this.hasError = false;
			const response = await loadWithdrawalApplicationDetailsAPI(
				withdrawedApplicationId
			);
			if (response.errorType !== ErrorType.NONE) {
				this.hasError = true;
				this.errorResponse = response as HttpResponseError;
				handleApiErrorAndShowAlert(response);
			} else {
				this.hasError = false;
				this.withdrawalApplicationDetails = response.data;
			}
			this.loading = false;
		},
		async loadWithdrawalApplicationSummary(withdrawedApplicationId: number) {
			this.withdrawalApplicationSummaryList = [];
			this.loading = true;
			this.hasError = false;
			const response = await loadWithdrawalApplicationSummaryAPI(
				withdrawedApplicationId
			);
			if (response.errorType !== ErrorType.NONE) {
				this.hasError = true;
				this.errorResponse = response as HttpResponseError;
				handleApiErrorAndShowAlert(response);
			} else {
				this.hasError = false;
				this.withdrawalApplicationSummaryList = response.data;
			}
			this.loading = false;
		},
		async loadSurfaceDetail(formCode: string, optionCode: string) {
			this.surfaceDetail = undefined;
			this.loading = true;
			this.hasError = false;
			const response = await loadSurfaceDetailApi(formCode, optionCode);
			if (response.errorType !== ErrorType.NONE) {
				this.hasError = true;
				this.errorResponse = response as HttpResponseError;
				handleApiErrorAndShowAlert(response);
			} else {
				this.hasError = false;
				this.surfaceDetail = response.data;
			}
			this.loading = false;
		},
		async loadZootechnicAllConfirmed(
			formCode: string,
			optionCode: string,
			takeoverId?: number
		) {
			this.loading = true;
			this.hasError = false;
			const response = await loadZootechnicAllConfirmedAPI(
				formCode,
				optionCode,
				takeoverId
			);
			if (response.errorType !== ErrorType.NONE) {
				this.hasError = true;
				this.errorResponse = response as HttpResponseError;
				handleApiErrorAndShowAlert(response);
			} else {
				this.hasError = false;
				this.flAllConfirmed = response.data;
			}
			this.loading = false;
		},
	},
});
