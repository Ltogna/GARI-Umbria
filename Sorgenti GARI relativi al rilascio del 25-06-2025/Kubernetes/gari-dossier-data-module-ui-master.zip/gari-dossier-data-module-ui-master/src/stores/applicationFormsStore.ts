/* eslint-disable @typescript-eslint/no-unused-vars */
import type {
	AttachmentListResponse,
	AttachmentTypeModel,
	AttachmentTypeResponse,
	BuildingProcessingDetailsListModel,
	BuildingProcessingDetailsModel,
	BuildingProcessingListResponse,
	CheckMandatoryMachineryOrEquipmentModel,
	CheckMandatoryMachineryOrEquipmentResponseModel,
	ConsumptionDeclarationListModel,
	DeclarationListResponse,
	DeclarationTypeChoiceCompanyTypeResponse,
	DeclarationTypeChoiceListResponse,
	DeclarationTypeChoiceListResponseV2,
	EquipmentListModel,
	ExciseMotivationListModel,
	GasStationTakingsModel,
	getDeclarationTypeChoiceResponseV2,
	getGiasUsernameResponse,
	getGraphicCropPlanFromImportResponse,
	getGraphicCropPlanResponse,
	GiasTokenResponse,
	importLogResponse,
	LandUseListFromCodeResponse,
	LandUseListResponse,
	MachineryListModel,
	MunicipalityListFromCodeResponse,
	MunicipalityListResponse,
	RequirementListResponse,
	SaveAttachmentModel,
	SaveBuildingProcessingDetails,
	SaveDeclarationsModel,
	SaveDeclarationTypeChoiceModel,
	SaveDeclarationTypeChoiceModelV2,
	SaveDeclarationTypeChoiceResponse,
	SaveDeclarationTypeChoiceResponseV2,
	SaveEquipmentsModel,
	SaveEquipmentsResponseModel,
	SaveFuelConsumeListModel,
	SaveGraphicCropPlanModel,
	SaveGraphicCropPlanResponse,
	SaveMachineriesModel,
	SaveMachineriesResponseModel,
	SaveRequirementModel,
	ZootechnicalProcessingDetailModel,
	ZootechnicalProcessingDetailResponse,
	ZootechnicalProcessingRANModel,
	ZootechnicalSaveDetailModel,
} from "@/models/applicationForms";
import { handleApiErrorAndShowAlert, sendCompiledEvent } from "@/models/utils";
import {
	addAttachment,
	checkMachineriesOrEquipmentsAPI,
	deleteAttachment,
	deleteBuildingProcessingDetail,
	deleteZootechnicalProcessing,
	deleteZootechnicalProcessingDetailList,
	downloadAttachment,
	editAttachment,
	editDeclarationTypeChoiceV2,
	getApplicationPrintHistory,
	getAttachmentList,
	getAttachmentTypeList,
	getBuildingProcessingDetail,
	getBuildingProcessingList,
	getCompanyTypeList,
	getConsumptionDeclarationList,
	getDeclarationList,
	getDeclarationTypeChoiceList,
	getDeclarationTypeChoiceV2,
	getExciseMotivationList,
	getGiasToken,
	getGiasUsername,
	getGraphicCropPlanList,
	getLandUseChoiceList,
	getMunicipalityChoiceList,
	getPurchasedFuelDetails,
	getRequirementList,
	getStatusImportGraphicCropPlanPolling,
	getZootechnicalProcessingDetailList,
	getZootechnicalProcessingRANList,
	importGraphicCropPlan,
	importLog,
	loadEquipments,
	loadGraphicCropPlan,
	loadLandUseListFromCode,
	loadMachineries,
	loadMunicipalityListFromCode,
	saveBuildingProcessingDetail,
	saveDeclarations,
	saveDeclarationTypeChoice,
	saveDeclarationTypeChoiceV2,
	saveEquipments,
	saveFuelConsumeList,
	saveGraphicCropPlan,
	saveMachineries,
	saveRequirement,
	saveZootechnicalProcessingDetailList,
	saveZootechnicalProcessingRAN,
} from "@/resources/api/applicationFormsApi";
import {
	ErrorType,
	type HttpJsonResult,
	type HttpResponseError,
} from "@abaco/safe-rest/src/HTTPClient";
import { defineStore } from "pinia";
import { resetDirtyState } from "./formDirtyStore";

interface State {
	loading: boolean;
	hasError: boolean;
	errorResponse?: HttpResponseError;
	attachmentList: AttachmentListResponse;
	attachmentTypeList: AttachmentTypeResponse;
	declarationList: DeclarationListResponse;
	machineriesList: MachineryListModel;
	saveMachineriesResponse: SaveMachineriesResponseModel;
	equipmentsList: EquipmentListModel;
	saveEquipmentsResponse: SaveEquipmentsResponseModel;
	checkMachineriesOrEquipmentsResponse: CheckMandatoryMachineryOrEquipmentResponseModel;
	zootechnicalProcessingRANList?: ZootechnicalProcessingRANModel;
	zootechnicalProcessingDetailList: ZootechnicalProcessingDetailResponse;
	buildingProcessingList: BuildingProcessingListResponse;
	buildingProcessingDetail: BuildingProcessingDetailsListModel;
	saveBuildingProcessingResponse: BuildingProcessingDetailsModel[];
	declarationTypeChoiceList: DeclarationTypeChoiceListResponse;
	municipalityList: MunicipalityListResponse;
	municipalityListFromCodeResponse: MunicipalityListFromCodeResponse;
	landUseListFromCodeResponse: LandUseListFromCodeResponse;
	landUseList: LandUseListResponse;
	declarationTypeChoiceListV2: DeclarationTypeChoiceListResponseV2;
	saveDeclarationTypeChoiceResponse: SaveDeclarationTypeChoiceResponse;
	getDeclarationTypeChoiceResponseV2: getDeclarationTypeChoiceResponseV2;
	saveDeclarationTypeChoiceResponseV2: SaveDeclarationTypeChoiceResponseV2;
	editDeclarationTypeChoiceResponseV2: getDeclarationTypeChoiceResponseV2;
	graphicCropPlanList: getGraphicCropPlanResponse[];
	graphicCropPlanPendingRequest: getGraphicCropPlanFromImportResponse;
	getLoadGraphicCropPlan: getGraphicCropPlanFromImportResponse[];
	graphicCropPlanPolling: getGraphicCropPlanFromImportResponse;
	saveGraphicCropPlanResponse: SaveGraphicCropPlanResponse;
	giasToken: GiasTokenResponse;
	companyTypeList: DeclarationTypeChoiceCompanyTypeResponse;
	consumptionDeclarationList: ConsumptionDeclarationListModel;
	purchasedFuelDetails: GasStationTakingsModel;
	requirementList: RequirementListResponse;
	exciseMotivationList: ExciseMotivationListModel;
	canSignDocument: boolean | null;
	getGiasUsernameResponse: getGiasUsernameResponse;
	importLogResponse: importLogResponse;
}

export const useApplicationFormsStore = defineStore({
	id: "applicationFormsStore",
	state: () =>
		({
			loading: false,
			hasError: false,
			errorResponse: undefined,
			attachmentList: {
				records: [],
				nextKey: null,
				count: 0,
			},
			attachmentTypeList: null,
			declarationList: null,
			machineriesList: [],
			saveMachineriesResponse: [],
			equipmentsList: [],
			saveEquipmentsResponse: [],
			checkMachineriesOrEquipmentsResponse: null,
			zootechnicalProcessingDetailList: null,
			zootechnicalProcessingRANList: undefined,
			buildingProcessingList: null,
			buildingProcessingDetail: [],
			saveBuildingProcessingResponse: [],
			municipalityList: null,
			municipalityListFromCodeResponse: null,
			landUseListFromCodeResponse: null,
			landUseList: null,
			declarationTypeChoiceList: null,
			declarationTypeChoiceListV2: null,
			saveDeclarationTypeChoiceResponse: null,
			getDeclarationTypeChoiceResponseV2: null,
			saveDeclarationTypeChoiceResponseV2: null,
			editDeclarationTypeChoiceResponseV2: null,
			graphicCropPlanList: [],
			graphicCropPlanPendingRequest: null,
			getLoadGraphicCropPlan: [],
			graphicCropPlanPolling: null,
			saveGraphicCropPlanResponse: null,
			giasToken: null,
			companyTypeList: [],
			consumptionDeclarationList: [],
			purchasedFuelDetails: [],
			requirementList: null,
			exciseMotivationList: null,
			canSignDocument: null,
			importLogResponse: null,
			getGiasUsernameResponse: null,
		}) as State,
	getters: {
		getLoading: (state: State) => {
			return state.loading;
		},
		getAttachmentList: (state: State) => {
			return state.attachmentList;
		},
		getAttachmentTypeList: (state: State) => {
			return state.attachmentTypeList?.records ?? [];
		},
		getDeclarationList: (state: State) => {
			return state.declarationList;
		},
		getEquipmentsList: (state: State) => {
			return state.equipmentsList;
		},
		getMachineriesList: (state: State) => {
			return state.machineriesList;
		},
		getMandatoryMachineriesOrEquipments: (state: State) => {
			return state.checkMachineriesOrEquipmentsResponse;
		},
		getZootechnicalProcessingRANList: (state: State) => {
			return state.zootechnicalProcessingRANList;
		},
		getZootechnicalProcessingDetailList: (state: State) => {
			return state.zootechnicalProcessingDetailList;
		},
		getBuildingProcessingList: (state: State) => {
			return state.buildingProcessingList;
		},
		getBuildingProcessingDetail: (state: State) => {
			return state.buildingProcessingDetail;
		},
		getBuildingProcessingSaveResponse: (state: State) => {
			return state.saveBuildingProcessingResponse;
		},
		getDeclarationTypeChoiceList: (state: State) => {
			return state.declarationTypeChoiceList;
		},
		getCompanyTypeList: (state: State) => {
			return state.companyTypeList;
		},
		getConsumptionDeclarationList: (state: State) => {
			return state.consumptionDeclarationList;
		},
		getPurchasedFuelDetails: (state: State) => {
			return state.purchasedFuelDetails;
		},
		getRequirementList: (state: State) => {
			return state.requirementList;
		},
		getExciseMotivationList: (state: State) => {
			return state.exciseMotivationList;
		},
		getCanSignDocument: (state: State) => {
			return state.canSignDocument;
		},
		getErrorResponse: (state: State) => {
			return state.errorResponse;
		},
	},
	actions: {
		async loadAttachmentList(
			resetList: boolean | undefined | null,
			attachmentGroup: string
		) {
			this.attachmentList = {
				records: [],
				nextKey: null,
				count: 0,
			};
			this.loading = true;
			this.hasError = false;
			const response = await getAttachmentList(
				!resetList ? this.attachmentList?.nextKey ?? null : null,
				attachmentGroup
			);
			if (response.errorType !== ErrorType.NONE) {
				this.hasError = true;
				this.errorResponse = response as HttpResponseError;
				handleApiErrorAndShowAlert(response);
			} else {
				if (resetList) {
					this.attachmentList = response.data;
				} else {
					// concat records
					this.attachmentList.count = response.data.count;
					this.attachmentList.nextKey = response.data.nextKey;
					this.attachmentList && this.attachmentList.records
						? this.attachmentList.records.push(...(response.data.records || []))
						: (this.attachmentList.records = response.data.records);
				}
			}
			this.loading = false;
		},
		async addAttachment(
			attachmentObj: SaveAttachmentModel,
			compileStatusIdentifier: string
		) {
			this.loading = true;
			this.hasError = false;
			const response = await addAttachment(
				attachmentObj,
				compileStatusIdentifier
			);
			if (response.errorType !== ErrorType.NONE) {
				this.hasError = true;
				this.errorResponse = response as HttpResponseError;
				handleApiErrorAndShowAlert(response);
			}
			this.loading = false;
		},
		async editAttachment(
			attachmentId: string,
			attachmentObj: SaveAttachmentModel,
			compileStatusIdentifier: string
		) {
			this.loading = true;
			this.hasError = false;
			const response = await editAttachment(
				attachmentId,
				attachmentObj,
				compileStatusIdentifier
			);
			if (response.errorType !== ErrorType.NONE) {
				this.hasError = true;
				this.errorResponse = response as HttpResponseError;
				handleApiErrorAndShowAlert(response);
			}
			this.loading = false;
		},
		async deleteAttachment(
			attachmentId: string,
			compileStatusIdentifier: string
		) {
			this.loading = true;
			this.hasError = false;
			const response = await deleteAttachment(
				attachmentId,
				compileStatusIdentifier
			);
			if (response.errorType !== ErrorType.NONE) {
				this.hasError = true;
				this.errorResponse = response as HttpResponseError;
				handleApiErrorAndShowAlert(response);
			}
			this.loading = false;
		},
		async loadAttachmentTypeList(attachmentGroup: string) {
			this.attachmentTypeList = null;
			this.loading = true;
			this.hasError = false;
			let _tmpNextKey: string | null = "";
			const _tmpTypeArray: AttachmentTypeModel[] = [];
			let _tmpCount = 0;
			while (_tmpNextKey !== null && _tmpNextKey !== undefined) {
				const response: HttpJsonResult<AttachmentTypeResponse> =
					await getAttachmentTypeList(attachmentGroup, _tmpNextKey);
				if (response.errorType !== ErrorType.NONE) {
					this.hasError = true;
					this.errorResponse = response as HttpResponseError;
					handleApiErrorAndShowAlert(response);
					return;
				} else if (response.data && response.data.records) {
					_tmpNextKey = response.data.nextKey;
					_tmpCount = response.data.count;
					_tmpTypeArray.push(...response.data.records);
				}
			}
			this.attachmentTypeList = {
				records: _tmpTypeArray,
				count: _tmpCount,
				nextKey: _tmpNextKey,
			};
			this.loading = false;
		},
		async downloadAttachment(attachmentId: string) {
			this.hasError = false;
			const response = await downloadAttachment(attachmentId);

			if (response.errorType !== ErrorType.NONE) {
				this.hasError = true;
				this.errorResponse = response as HttpResponseError;
				handleApiErrorAndShowAlert(response);
			} else {
				const _blob = await response.response.blob();
				return URL.createObjectURL(_blob);
			}
		},
		async clearAttachmentListandTypeList() {
			this.attachmentTypeList = null;
			this.attachmentList = {
				records: [],
				nextKey: null,
				count: 0,
			};
		},
		async loadDeclarationList(documentCode: string) {
			this.declarationList = null;
			this.loading = true;
			this.hasError = false;
			const response = await getDeclarationList(documentCode);
			if (response.errorType !== ErrorType.NONE) {
				this.hasError = true;
				this.errorResponse = response as HttpResponseError;
				handleApiErrorAndShowAlert(response);
			} else {
				this.declarationList = response.data;
			}
			this.loading = false;
		},
		async loadMachineries(
			machineryClassCode?: string,
			functionalControl?: number
		) {
			this.loading = true;
			this.hasError = false;
			this.machineriesList = [];
			const response = await loadMachineries(
				machineryClassCode,
				functionalControl
			);
			if (response.errorType !== ErrorType.NONE) {
				this.hasError = true;
				this.errorResponse = response as HttpResponseError;
				handleApiErrorAndShowAlert(response);
			} else {
				this.machineriesList = response.data;
			}
			this.loading = false;
		},
		async saveMachineries(
			machineries: SaveMachineriesModel,
			classCode: string,
			functionalControl: string,
			compileStatusIdentifier: string
		) {
			this.loading = true;
			this.hasError = false;
			const response = await saveMachineries(
				machineries,
				classCode,
				functionalControl,
				compileStatusIdentifier
			);
			if (response.errorType !== ErrorType.NONE) {
				this.hasError = true;
				this.errorResponse = response as HttpResponseError;
				handleApiErrorAndShowAlert(response);
			} else {
				this.saveMachineriesResponse = response.data;
				resetDirtyState();
				sendCompiledEvent();
			}
			this.loading = false;
		},
		async loadEquipments(functionalControl?: number) {
			this.loading = true;
			this.hasError = false;
			this.equipmentsList = [];
			const response = await loadEquipments(functionalControl);
			if (response.errorType !== ErrorType.NONE) {
				this.hasError = true;
				this.errorResponse = response as HttpResponseError;
				handleApiErrorAndShowAlert(response);
			} else {
				this.equipmentsList = response.data;
			}
			this.loading = false;
		},
		async saveEquipments(
			equipments: SaveEquipmentsModel,
			functionalControl: string,
			compileStatusIdentifier: string
		) {
			this.loading = true;
			this.hasError = false;
			const response = await saveEquipments(
				equipments,
				functionalControl,
				compileStatusIdentifier
			);
			if (response.errorType !== ErrorType.NONE) {
				this.hasError = true;
				this.errorResponse = response as HttpResponseError;
				handleApiErrorAndShowAlert(response);
			} else {
				this.saveEquipmentsResponse = response.data;
				resetDirtyState();
				sendCompiledEvent();
			}
			this.loading = false;
		},
		async checkMachineriesOrEquipments(
			itemsToCheck: CheckMandatoryMachineryOrEquipmentModel,
			compileStatusIdentifier: string
		) {
			this.loading = true;
			this.hasError = false;
			const response = await checkMachineriesOrEquipmentsAPI(
				itemsToCheck,
				compileStatusIdentifier
			);
			if (response.errorType !== ErrorType.NONE) {
				this.hasError = true;
				this.errorResponse = response as HttpResponseError;
				handleApiErrorAndShowAlert(response);
			} else {
				this.checkMachineriesOrEquipmentsResponse = response.data;
			}
			this.loading = false;
		},
		async saveDeclarations(
			document_code: string,
			declarations: SaveDeclarationsModel,
			compileStatusIdentifier: string
		) {
			this.loading = true;
			this.hasError = false;
			const response = await saveDeclarations(
				document_code,
				declarations,
				compileStatusIdentifier
			);
			if (response.errorType !== ErrorType.NONE) {
				this.hasError = true;
				this.errorResponse = response as HttpResponseError;
				handleApiErrorAndShowAlert(response);
			} else {
				resetDirtyState();
				sendCompiledEvent();
			}
			this.loading = false;
		},
		async loadZootechnicalProcessingDetailList(
			speciesId: string,
			subSpeciesTypeCode?: string | null | undefined,
			workTypeCode?: string | null | undefined
		) {
			this.zootechnicalProcessingDetailList = null;
			this.loading = true;
			this.hasError = false;
			const response = await getZootechnicalProcessingDetailList(
				speciesId,
				subSpeciesTypeCode,
				workTypeCode
			);
			if (response.errorType !== ErrorType.NONE) {
				this.hasError = true;
				this.errorResponse = response as HttpResponseError;
				handleApiErrorAndShowAlert(response);
			} else {
				this.zootechnicalProcessingDetailList = response.data;
			}
			this.loading = false;
		},
		async saveZootechnicalProcessingDetailList(
			speciesId: string,
			list: Array<Partial<ZootechnicalProcessingDetailModel>>,
			compileStatusIdentifier: string
		) {
			this.loading = true;
			this.hasError = false;
			const response = await saveZootechnicalProcessingDetailList(
				speciesId,
				list,
				compileStatusIdentifier
			);
			if (response.errorType !== ErrorType.NONE) {
				this.hasError = true;
				this.errorResponse = response as HttpResponseError;
				handleApiErrorAndShowAlert(response);
			} else {
				resetDirtyState();
				sendCompiledEvent();
			}
			this.loading = false;
		},
		async deleteZootechnicalProcessingDetailList(
			speciesId: string,
			compileStatusIdentifier: string
		) {
			this.loading = true;
			this.hasError = false;
			const response = await deleteZootechnicalProcessingDetailList(
				speciesId,
				compileStatusIdentifier
			);
			if (response.errorType !== ErrorType.NONE) {
				this.hasError = true;
				this.errorResponse = response as HttpResponseError;
				handleApiErrorAndShowAlert(response);
			} else {
				resetDirtyState();
				sendCompiledEvent();
			}
			this.loading = false;
		},
		async loadZootechnicalProcessingRANList() {
			this.zootechnicalProcessingRANList = undefined;
			this.loading = true;
			this.hasError = false;
			const response = await getZootechnicalProcessingRANList();
			if (response.errorType !== ErrorType.NONE) {
				this.hasError = true;
				this.errorResponse = response as HttpResponseError;
				handleApiErrorAndShowAlert(response);
			} else {
				this.zootechnicalProcessingRANList = response.data;
			}
			this.loading = false;
		},
		async saveRAN(
			zootechnicalSaveDetail: ZootechnicalSaveDetailModel,
			compileStatusIdentifier: string
		) {
			this.loading = true;
			this.hasError = false;
			const response = await saveZootechnicalProcessingRAN(
				compileStatusIdentifier,
				zootechnicalSaveDetail
			);
			if (response.errorType !== ErrorType.NONE) {
				this.hasError = true;
				this.errorResponse = response as HttpResponseError;
				handleApiErrorAndShowAlert(response);
			} else {
				resetDirtyState();
				sendCompiledEvent();
			}
			this.loading = false;
		},
		async deleteZootechnicalProcessing(compileStatusIdentifier: string) {
			this.loading = true;
			this.hasError = false;
			const response = await deleteZootechnicalProcessing(
				compileStatusIdentifier
			);
			if (response.errorType !== ErrorType.NONE) {
				this.hasError = true;
				this.errorResponse = response as HttpResponseError;
				handleApiErrorAndShowAlert(response);
			} else {
				resetDirtyState();
				sendCompiledEvent();
			}
			this.loading = false;
		},
		async loadBuildingProcessingList() {
			this.buildingProcessingList = null;
			this.loading = true;
			this.hasError = false;
			const response = await getBuildingProcessingList();
			if (response.errorType !== ErrorType.NONE) {
				this.hasError = true;
				this.errorResponse = response as HttpResponseError;
				handleApiErrorAndShowAlert(response);
			} else {
				this.buildingProcessingList = response.data;
			}
			this.loading = false;
		},
		async loadBuildingProcessingDetail(buildingTypeId: string) {
			this.buildingProcessingDetail = [];
			this.loading = true;
			this.hasError = false;
			const response = await getBuildingProcessingDetail(buildingTypeId);
			if (response.errorType !== ErrorType.NONE) {
				this.hasError = true;
				this.errorResponse = response as HttpResponseError;
				handleApiErrorAndShowAlert(response);
			} else {
				this.buildingProcessingDetail = response.data;
			}
			this.loading = false;
		},
		async saveBuildingProcessing(
			buildingTypeId: string,
			buildingProcessings: SaveBuildingProcessingDetails,
			compileStatusIdentifier: string
		) {
			this.loading = true;
			this.hasError = false;
			const response = await saveBuildingProcessingDetail(
				buildingTypeId,
				buildingProcessings,
				compileStatusIdentifier
			);
			if (response.errorType !== ErrorType.NONE) {
				this.hasError = true;
				this.errorResponse = response as HttpResponseError;
				handleApiErrorAndShowAlert(response);
			} else {
				this.saveBuildingProcessingResponse = response.data;
				resetDirtyState();
				sendCompiledEvent();
			}
			this.loading = false;
		},
		async deleteBuildingProcessing(
			buildingTypeId: string,
			compileStatusIdentifier: string
		) {
			this.loading = true;
			this.hasError = false;
			const response = await deleteBuildingProcessingDetail(
				buildingTypeId,
				compileStatusIdentifier
			);
			if (response.errorType !== ErrorType.NONE) {
				this.hasError = true;
				this.errorResponse = response as HttpResponseError;
				handleApiErrorAndShowAlert(response);
			} else {
				resetDirtyState();
				sendCompiledEvent();
			}
			this.loading = false;
		},
		async loadDeclarationTypeChoiceList() {
			this.declarationTypeChoiceList = null;
			this.loading = true;
			this.hasError = false;
			const response = await getDeclarationTypeChoiceList();
			if (response.errorType !== ErrorType.NONE) {
				this.hasError = true;
				this.errorResponse = response as HttpResponseError;
				handleApiErrorAndShowAlert(response, false);
			} else {
				this.declarationTypeChoiceList = response.data;
			}
			this.loading = false;
		},
		async loadMunicipalityList(filter: string) {
			this.declarationTypeChoiceList = null;
			this.loading = true;
			this.hasError = false;
			const response = await getMunicipalityChoiceList(filter);
			if (response.errorType !== ErrorType.NONE) {
				this.hasError = true;
				this.errorResponse = response as HttpResponseError;
				handleApiErrorAndShowAlert(response, false);
			} else {
				this.municipalityList = response.data;
			}
			this.loading = false;
		},
		async loadLandUseList(filter: string) {
			this.declarationTypeChoiceList = null;
			this.loading = true;
			this.hasError = false;
			const response = await getLandUseChoiceList(filter);
			if (response.errorType !== ErrorType.NONE) {
				this.hasError = true;
				this.errorResponse = response as HttpResponseError;
				handleApiErrorAndShowAlert(response, false);
			} else {
				this.landUseList = response.data;
			}
			this.loading = false;
		},
		async saveDeclarationTypeChoice(
			declarationsTypeChoice: SaveDeclarationTypeChoiceModel,
			compileStatusIdentifier: string
		) {
			this.loading = true;
			this.hasError = false;
			const response = await saveDeclarationTypeChoice(
				declarationsTypeChoice,
				compileStatusIdentifier
			);
			if (response.errorType !== ErrorType.NONE) {
				this.hasError = true;
				this.errorResponse = response as HttpResponseError;
				handleApiErrorAndShowAlert(response);
			} else {
				this.saveDeclarationTypeChoiceResponse = response.data;
				resetDirtyState();
				sendCompiledEvent();
			}
			this.loading = false;
		},

		async getDeclarationTypeChoiceV2() {
			this.loading = true;
			this.hasError = false;
			const response = await getDeclarationTypeChoiceV2();
			if (response.errorType !== ErrorType.NONE) {
				this.hasError = true;
				this.errorResponse = response as HttpResponseError;
				handleApiErrorAndShowAlert(response);
			} else {
				this.getDeclarationTypeChoiceResponseV2 = response.data;
				resetDirtyState();
				sendCompiledEvent();
			}
			this.loading = false;
		},

		async saveDeclarationTypeChoiceV2(
			declarationsTypeChoiceV2: SaveDeclarationTypeChoiceModelV2
		) {
			this.loading = true;
			this.hasError = false;
			const response = await saveDeclarationTypeChoiceV2(
				declarationsTypeChoiceV2
			);
			if (response.errorType !== ErrorType.NONE) {
				this.hasError = true;
				this.errorResponse = response as HttpResponseError;
				handleApiErrorAndShowAlert(response);
			} else {
				this.saveDeclarationTypeChoiceResponseV2 = response.data;
				resetDirtyState();
				sendCompiledEvent();
			}
			this.loading = false;
		},
		async editDeclarationTypeChoiceV2(
			declarationsTypeChoiceV2: SaveDeclarationTypeChoiceModelV2
		) {
			this.loading = true;
			this.hasError = false;
			const response = await editDeclarationTypeChoiceV2(
				declarationsTypeChoiceV2
			);
			if (response.errorType !== ErrorType.NONE) {
				this.hasError = true;
				this.errorResponse = response as HttpResponseError;
				handleApiErrorAndShowAlert(response);
			} else {
				this.editDeclarationTypeChoiceResponseV2 = response.data;
				resetDirtyState();
				sendCompiledEvent();
			}
			this.loading = false;
		},

		async loadGraphicCropPlan(cuaa: string) {
			this.loading = true;
			this.getLoadGraphicCropPlan = [];
			this.hasError = false;
			const response = await loadGraphicCropPlan(cuaa);
			if (response.errorType !== ErrorType.NONE) {
				this.hasError = true;
				this.errorResponse = response as HttpResponseError;
				handleApiErrorAndShowAlert(response);
			} else {
				this.getLoadGraphicCropPlan = response.data;
			}
			this.loading = false;
		},

		async importGraphicCropPlan(cuaa: string, currentYear: number) {
			this.loading = true;
			this.graphicCropPlanPendingRequest = null;
			this.hasError = false;
			const response = await importGraphicCropPlan(cuaa, currentYear);
			if (response.errorType !== ErrorType.NONE) {
				this.hasError = true;
				this.errorResponse = response as HttpResponseError;
				handleApiErrorAndShowAlert(response);
			} else {
				this.graphicCropPlanPendingRequest = response.data;
			}
			this.loading = false;
		},
		async importLog(cuaa: string, requestId: string) {
			this.loading = true;
			this.importLogResponse = null;
			this.hasError = false;
			const response = await importLog(cuaa, requestId);
			if (response.errorType !== ErrorType.NONE) {
				this.hasError = true;
				this.errorResponse = response as HttpResponseError;
				handleApiErrorAndShowAlert(response);
			} else {
				this.importLogResponse = response.data;
			}
			this.loading = false;
		},

		async importGraphicCropPlanPolling(
			graphicCropPlanRequestId: string,
			cuaa: string
		) {
			this.loading = true;
			this.graphicCropPlanPolling = null;
			this.hasError = false;
			const response = await getStatusImportGraphicCropPlanPolling(
				graphicCropPlanRequestId,
				cuaa
			);
			if (response.errorType !== ErrorType.NONE) {
				this.hasError = true;
				this.errorResponse = response as HttpResponseError;
				handleApiErrorAndShowAlert(response);
			} else {
				this.graphicCropPlanPolling = response.data;
			}
			this.loading = false;
		},
		async loadGraphicCropPlanList() {
			this.loading = true;
			this.graphicCropPlanList = [];
			this.hasError = false;
			const response = await getGraphicCropPlanList();
			if (response.errorType !== ErrorType.NONE) {
				this.hasError = true;
				this.errorResponse = response as HttpResponseError;
				handleApiErrorAndShowAlert(response);
			} else {
				this.graphicCropPlanList = response.data;
			}
			this.loading = false;
		},
		async saveGraphicCropPlan(graphicCropPlan: SaveGraphicCropPlanModel) {
			this.loading = true;
			this.hasError = false;
			const response = await saveGraphicCropPlan(graphicCropPlan);
			if (response.errorType !== ErrorType.NONE) {
				this.hasError = true;
				this.errorResponse = response as HttpResponseError;
				handleApiErrorAndShowAlert(response);
			} else {
				this.saveGraphicCropPlanResponse = response.data;
				resetDirtyState();
				sendCompiledEvent();
			}
			this.loading = false;
		},

		async getGiasToken(cuaa: string) {
			this.giasToken = null;
			this.loading = true;
			this.hasError = false;
			const response = await getGiasToken(cuaa);
			if (response.errorType !== ErrorType.NONE) {
				this.errorResponse = response as HttpResponseError;
			} else {
				this.giasToken = response.data;
			}
			this.loading = false;
		},

		async loadLandUseListFromCode(landUseCodeList: string[]) {
			this.loading = true;
			this.hasError = false;
			const response = await loadLandUseListFromCode(landUseCodeList);
			if (response.errorType !== ErrorType.NONE) {
				this.hasError = true;
				this.errorResponse = response as HttpResponseError;
				handleApiErrorAndShowAlert(response);
			} else {
				this.landUseListFromCodeResponse = response.data;
			}
			this.loading = false;
		},

		async loadMunicipalityListFromCode(municipalityCodeList: string[]) {
			this.loading = true;
			this.hasError = false;
			const response = await loadMunicipalityListFromCode(municipalityCodeList);
			if (response.errorType !== ErrorType.NONE) {
				this.hasError = true;
				this.errorResponse = response as HttpResponseError;
				handleApiErrorAndShowAlert(response);
			} else {
				this.municipalityListFromCodeResponse = response.data;
				resetDirtyState();
				sendCompiledEvent();
			}
			this.loading = false;
		},

		async loadCompanyTypeList() {
			this.companyTypeList = [];
			this.loading = true;
			this.hasError = false;
			const response = await getCompanyTypeList();
			if (response.errorType !== ErrorType.NONE) {
				this.hasError = true;
				this.errorResponse = response as HttpResponseError;
				handleApiErrorAndShowAlert(response);
			} else {
				this.companyTypeList = response.data;
			}
			this.loading = false;
		},
		async loadConsumptionDeclarationList() {
			this.consumptionDeclarationList = [];
			this.loading = true;
			this.hasError = false;
			const response = await getConsumptionDeclarationList();
			if (response.errorType !== ErrorType.NONE) {
				this.hasError = true;
				this.errorResponse = response as HttpResponseError;
				handleApiErrorAndShowAlert(response);
			} else {
				this.consumptionDeclarationList = response.data;
			}
			this.loading = false;
		},
		async loadRequirementList() {
			this.requirementList = null;
			this.loading = true;
			this.hasError = false;
			const response = await getRequirementList();
			if (response.errorType !== ErrorType.NONE) {
				this.hasError = true;
				this.errorResponse = response as HttpResponseError;
				handleApiErrorAndShowAlert(response);
			} else {
				this.requirementList = response.data;
			}
			this.loading = false;
		},
		async saveRequirement(
			requirement: SaveRequirementModel,
			compileStatusIdentifier: string
		) {
			this.loading = true;
			this.hasError = false;
			const response = await saveRequirement(
				requirement,
				compileStatusIdentifier
			);
			if (response.errorType !== ErrorType.NONE) {
				this.hasError = true;
				this.errorResponse = response as HttpResponseError;
				handleApiErrorAndShowAlert(response);
			} else {
				resetDirtyState();
				sendCompiledEvent();
			}
			this.loading = false;
		},
		async loadPurchasedFuelDetails() {
			this.purchasedFuelDetails = [];
			this.loading = true;
			this.hasError = false;
			const response = await getPurchasedFuelDetails();
			if (response.errorType !== ErrorType.NONE) {
				this.hasError = true;
				this.errorResponse = response as HttpResponseError;
				handleApiErrorAndShowAlert(response);
			} else {
				this.purchasedFuelDetails = response.data;
			}
			this.loading = false;
		},
		async loadExciseMotivationList() {
			this.loading = true;
			this.hasError = false;
			const response = await getExciseMotivationList();
			if (response.errorType !== ErrorType.NONE) {
				this.hasError = true;
				this.errorResponse = response as HttpResponseError;
				handleApiErrorAndShowAlert(response);
			} else {
				this.exciseMotivationList = response.data;
			}
			this.loading = false;
		},
		async saveFuelConsumeList(
			compileStatusIdentifier: string,
			data: SaveFuelConsumeListModel
		) {
			this.loading = true;
			this.hasError = false;
			const response = await saveFuelConsumeList(compileStatusIdentifier, data);
			if (response.errorType !== ErrorType.NONE) {
				this.hasError = true;
				this.errorResponse = response as HttpResponseError;
				handleApiErrorAndShowAlert(response);
			} else {
				resetDirtyState();
				sendCompiledEvent();
			}
			this.loading = false;
		},
		async loadCanSignDocument() {
			this.loading = true;
			this.hasError = false;
			const response = await getApplicationPrintHistory();
			if (response.errorType !== ErrorType.NONE) {
				this.hasError = true;
				this.errorResponse = response as HttpResponseError;
				handleApiErrorAndShowAlert(response);
			} else {
				this.canSignDocument = response.data && response.data.length > 0;
			}
			this.loading = false;
		},

		async getGiasUsername() {
			this.loading = true;
			this.hasError = false;
			this.getGiasUsernameResponse = null;
			const response = await getGiasUsername();
			if (response.errorType !== ErrorType.NONE) {
				this.hasError = true;
				this.errorResponse = response as HttpResponseError;
				handleApiErrorAndShowAlert(response);
			} else {
				this.getGiasUsernameResponse = response.data;
				resetDirtyState();
				sendCompiledEvent();
			}
			this.loading = false;
		},
	},
});
