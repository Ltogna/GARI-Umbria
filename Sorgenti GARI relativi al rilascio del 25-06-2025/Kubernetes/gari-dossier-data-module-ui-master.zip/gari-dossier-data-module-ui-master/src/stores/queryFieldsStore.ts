import { defineStore } from "pinia";
import { useRoute } from "vue-router";

interface State {
	applicationId: number;
	compileStatusIdentifier: string;
	formConfigId: number;
	formCode: string;
	readOnly: number;
	hasBeenPrint: number;
	partyCode: string;
	version: number;
	params: Record<string, string>;
}

export const useQueryFieldsStore = defineStore({
	id: "queryFieldsStore",
	state: () =>
		({
			applicationId: 0,
			formConfigId: 0,
			compileStatusIdentifier: "",
			formCode: "",
			readOnly: 1,
			hasBeenPrint: 0,
			partyCode: "",
			version: 1,
			params: {},
		}) as State,
	getters: {
		getApplicationId: (state: State) => {
			return state.applicationId;
		},
		getFormConfigId: (state: State) => {
			return state.formConfigId;
		},
		getCompileStatusIdentifier: (state: State) => {
			return state.compileStatusIdentifier;
		},
		getFormCode: (state: State) => {
			return state.formCode;
		},
		getReadOnly: (state: State) => {
			return state.readOnly;
		},
		getHasBeenPrint: (state: State) => {
			return state.hasBeenPrint;
		},
		getPartyCode: (state: State) => {
			return state.partyCode;
		},
		getVersion: (state: State) => {
			return state.version;
		},
		getParams: (state: State) => {
			return state.params;
		},
		getParamByKey: (state: State) => {
			return (key: string) => state.params[key];
		},
	},
	actions: {
		resetState() {
			this.applicationId = 0;
			this.formCode = "";
			this.formConfigId = 0;
			this.readOnly = 1;
			this.hasBeenPrint = 0;
			this.partyCode = "";
			this.version = 1;
			this.params = {};
		},
		populateState() {
			this.resetState();
			const route = useRoute();
			this.readOnly = route.query?.readOnly === "1" ? 1 : 0;
			const applicationIdFnc = () => {
				let appId: string | number = route.params.applicationId as string;
				if (appId === undefined) {
					appId = parseInt(route.query.applicationId as string);
				}
				return parseInt(appId as string);
			};
			this.applicationId = applicationIdFnc();
			this.formCode = (route.query?.formCode as string) || "";
			this.formConfigId = parseInt(route.query?.formConfigId as string) || 0;
			this.compileStatusIdentifier =
				(route.query?.compileStatusIdentifier as string) || "";
			this.hasBeenPrint = route.query?.hasBeenPrint === "1" ? 1 : 0;
			this.partyCode = (route.query?.partyCode as string) || "";
			this.version = route.query.version
				? parseInt(route.query.version as string)
				: 1;
			const params: Record<string, string> = {};
			Object.keys(route.query)
				.filter(
					x =>
						![
							"readOnly",
							"formCode",
							"applicationId",
							"formConfigId",
							"compileStatusIdentifier",
							"partyCode",
							"version",
						].includes(x)
				)
				.forEach(x => {
					params[x] = route.query[x] as string;
				});
			this.params = params;
		},
	},
});
