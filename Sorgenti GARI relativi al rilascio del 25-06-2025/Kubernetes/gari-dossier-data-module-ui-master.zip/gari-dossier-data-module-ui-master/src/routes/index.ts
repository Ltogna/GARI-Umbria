import type { RouteRecordRaw } from "vue-router";

const routes: RouteRecordRaw[] = [];

routes.push(
	{
		path: "/graphic-crop-plan",
		name: "GraphicCropPlan",
		component: () =>
			import("../components/graphicCropPlan/GraphicCropPlanForm.vue"),
	},
	{
		path: "/uma-declaration",
		name: "UmaDeclaration",
		component: () =>
			import("../components/umaDeclaration/UmaDeclarationForm.vue"),
	}
);

export default routes;
