import { useQueryFieldsStore } from "@/stores/queryFieldsStore";
import {
	ErrorType,
	HTTPClient,
	type HTTPClientOptions,
	type HttpJsonResult,
	type HttpResult,
	type RequestConfig,
} from "@abaco/safe-rest/src/HTTPClient";
import {
	getUserData,
	installSso2RequestConfigProvider,
	type User,
} from "@abaco/safe-rest/src/sso2";
import type { z } from "zod";

// eslint-disable-next-line @typescript-eslint/no-explicit-any
const UNAUTHORIZED_USER_ERROR: any = {
	errorType: ErrorType.OTHER,
	err: 401,
};

export class HTTPClientPlus extends HTTPClient {
	constructor(config: HTTPClientOptions = {}) {
		super(config);
	}

	public async cleanGet(
		url: string,
		config?: RequestConfig
	): Promise<HttpResult> {
		return await super.get(url, config);
	}

	public async get(
		url: string,
		config: RequestConfig = {}
	): Promise<HttpResult> {
		const user = getUserData();
		if (!user) {
			return UNAUTHORIZED_USER_ERROR;
		}

		const urlWithOptionCodes = this.generateOptionsCodesQueryParams(
			config,
			url,
			user
		);

		const res = await super.get(urlWithOptionCodes, config);
		return res;
	}

	public async getJson<S extends z.ZodTypeAny>(
		schema: S,
		url: string,
		config: RequestConfig = {},
		overrideOptionCodes?: string
	): Promise<HttpJsonResult<z.infer<typeof schema>>> {
		const user = getUserData();
		if (!user) {
			return UNAUTHORIZED_USER_ERROR;
		}

		const urlWithOptionCodes = this.generateOptionsCodesQueryParams(
			config,
			url,
			user,
			overrideOptionCodes
		);

		const res = await super.getJson(schema, urlWithOptionCodes, config);
		return res;
	}

	public async postJson<S extends z.ZodTypeAny>(
		schema: S,
		url: string,
		data?: unknown,
		config: RequestConfig = {},
		overrideOptionCodes?: string
	): Promise<HttpJsonResult<z.infer<typeof schema>>> {
		const user = getUserData();
		if (!user) {
			return UNAUTHORIZED_USER_ERROR;
		}

		const urlWithOptionCodes = this.generateOptionsCodesQueryParams(
			config,
			url,
			user,
			overrideOptionCodes
		);

		const res = await super.postJson(schema, urlWithOptionCodes, data, config);
		return res;
	}

	public async putJson<S extends z.ZodTypeAny>(
		schema: S,
		url: string,
		data?: unknown,
		config: RequestConfig = {}
	): Promise<HttpJsonResult<z.infer<typeof schema>>> {
		const user = getUserData();
		if (!user) {
			return UNAUTHORIZED_USER_ERROR;
		}

		const urlWithOptionCodes = this.generateOptionsCodesQueryParams(
			config,
			url,
			user
		);

		const res = await super.putJson(schema, urlWithOptionCodes, data, config);
		return res;
	}

	public async delete(
		url: string,
		config: RequestConfig = {}
	): Promise<HttpResult> {
		const user = getUserData();
		if (!user) {
			return UNAUTHORIZED_USER_ERROR;
		}

		const urlWithOptionCodes = this.generateOptionsCodesQueryParams(
			config,
			url,
			user
		);

		const res = await super.delete(urlWithOptionCodes, config);
		return res;
	}

	public async post(
		url: string,
		data?: BodyInit,
		config: RequestConfig = {}
	): Promise<HttpResult> {
		const user = getUserData();
		if (!user) {
			return UNAUTHORIZED_USER_ERROR;
		}

		const urlWithOptionCodes = this.generateOptionsCodesQueryParams(
			config,
			url,
			user
		);

		const res = await super.post(urlWithOptionCodes, data, config);
		return res;
	}

	public async put(
		url: string,
		data?: BodyInit,
		config: RequestConfig = {}
	): Promise<HttpResult> {
		const user = getUserData();
		if (!user) {
			return UNAUTHORIZED_USER_ERROR;
		}

		const urlWithOptionCodes = this.generateOptionsCodesQueryParams(
			config,
			url,
			user
		);

		const res = await super.put(urlWithOptionCodes, data, config);
		return res;
	}

	public async patch(
		url: string,
		data?: BodyInit,
		config: RequestConfig = {}
	): Promise<HttpResult> {
		const user = getUserData();
		if (!user) {
			return UNAUTHORIZED_USER_ERROR;
		}

		const urlWithOptionCodes = this.generateOptionsCodesQueryParams(
			config,
			url,
			user
		);

		const res = await super.patch(urlWithOptionCodes, data, config);
		return res;
	}

	generateOptionsCodesQueryParams(
		config: RequestConfig,
		url: string,
		user: User,
		overrideOptionCodes?: string
	) {
		const queryFieldsStore = useQueryFieldsStore();
		const formConfigId = queryFieldsStore.getFormConfigId;
		const version = queryFieldsStore.getVersion;
		const compileStatusIdentifier = queryFieldsStore.compileStatusIdentifier;
		// const applicationId = queryFieldsStore.getApplicationId;
		const applicationId = Date.now(); // TODO review: data retrieve from back-end

		const optionsCodes: string =
			queryFieldsStore.getParamByKey("option_codes") || "";

		const regex = /pua-application-forms/;
		if (regex.test(url)) {
			this.enrichRequestConfigParams(
				config,
				formConfigId,
				version,
				compileStatusIdentifier
			);
		}

		const replacedPathParamsUrl = this.replacePathParams(
			url,
			applicationId,
			user
		);

		if (!overrideOptionCodes)
			overrideOptionCodes = optionsCodes.split(",").join("&option_code=");

		return optionsCodes !== ""
			? replacedPathParamsUrl + "?option_code=" + overrideOptionCodes
			: replacedPathParamsUrl + "";
	}

	enrichRequestConfigParams(
		config: RequestConfig,
		formConfigId: number,
		version: number,
		compileStatusIdentifier: string
	) {
		if (!config.params) {
			config.params = {
				formConfigId,
				form_config_id: formConfigId,
				version,
				compileStatusIdentifier,
			};
		} else {
			config.params = {
				...config.params,
				formConfigId,
				form_config_id: formConfigId,
				version,
				compileStatusIdentifier,
			};
		}

		this.removeNullsOrBlanksFromObject(config);
	}

	// eslint-disable-next-line @typescript-eslint/no-explicit-any
	removeNullsOrBlanksFromObject(obj: any) {
		if (obj) {
			Object.keys(obj).forEach(k => {
				if (obj && (obj[k] === "" || obj[k] == null)) {
					delete obj[k];
				}
			});
		}
	}

	replacePathParams(url: string, applicationId: number, user: User) {
		return url
			.replaceAll("{APPLICATION_ID}", applicationId.toString())
			.replaceAll("{APPLICATION_ID_SAME}", "2")
			.replaceAll("{CROPPLANTYPECODE}", "CROPPLAN")
			.replaceAll("{TENANT}", user.tenant);
	}
}

export const httpPlus = new HTTPClientPlus();
installSso2RequestConfigProvider(httpPlus, "/sso2");
