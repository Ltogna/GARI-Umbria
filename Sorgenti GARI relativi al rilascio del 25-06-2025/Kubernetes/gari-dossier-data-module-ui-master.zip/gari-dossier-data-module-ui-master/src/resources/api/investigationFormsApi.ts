import type {
	CorrectionSurfacesPrizesDetailsInfiniteListModel,
	CorrectionSurfacesPrizesListModel,
	InvestigationCoupledListModel,
	InvestigationDARModel,
	InvestigationDataModel,
	InvestigationModulationModel,
	InvestigationOverDeclarationListModel,
	InvestigationSurfaceEcoschemasModel,
	InvestigationSurfacesPrizesDetailsInfiniteListModel,
	InvestigationSurfacesPrizesListModel,
	InvestigationYoungFarmerModel,
	OptionsPaymentListModel,
	SaveCorrectionSurfacesPrizesDetailsModel,
	SaveInvestigationCoupledListModel,
	SaveInvestigationDARModel,
	SaveInvestigationOverDeclarationListModel,
	saveInvestigationSurfaceEcoschemasModel,
	SaveInvestigationSurfacesPrizesDetailsModel,
	SaveInvestigationSurfacesPrizesDetailsResponseModel,
	SaveOptionsPaymentModel,
} from "@/models/investigationForms";
import {
	CorrectionSurfacesPrizesDetailsInfiniteListSchema,
	CorrectionSurfacesPrizesListSchema,
	InvestigationCoupledListSchema,
	InvestigationDARSchema,
	InvestigationDataSchema,
	InvestigationModulationSchema,
	InvestigationOverdeclarationListSchema,
	InvestigationSurfaceEcoschemasSchema,
	InvestigationSurfacesPrizesDetailsInfiniteListSchema,
	InvestigationSurfacesPrizesListSchema,
	InvestigationYoungFarmerSchema,
	OptionsPaymentListSchema,
	SaveInvestigationSurfacesPrizesDetailsResponseSchema,
} from "@/models/investigationForms";
import { removeNullsOrBlanksFromObject } from "@/models/utils";
import {
	ErrorType,
	type HttpJsonResult,
	type HttpResult,
	type RequestConfig,
} from "@abaco/safe-rest/src/HTTPClient";
import { httpPlus as http } from "./http";
import {
	type TerritoryFiltersModel,
	TerritoryFiltersSchema,
} from "@/models/unificataForms";

// eslint-disable-next-line @typescript-eslint/no-explicit-any, @typescript-eslint/no-unused-vars
function standardMockResponse(data: any): HttpJsonResult<any> {
	return {
		response: {
			ok: true,
			redirected: false,
			status: 200,
			statusText: "OK",
			type: "default",
			url: "",
			// eslint-disable-next-line @typescript-eslint/no-explicit-any
			headers: null as any,
			// eslint-disable-next-line @typescript-eslint/no-explicit-any
			clone: null as any,
			body: null,
			bodyUsed: false,
			// eslint-disable-next-line @typescript-eslint/no-explicit-any
			arrayBuffer: null as any,
			// eslint-disable-next-line @typescript-eslint/no-explicit-any
			blob: null as any,
			// eslint-disable-next-line @typescript-eslint/no-explicit-any
			formData: null as any,
			// eslint-disable-next-line @typescript-eslint/no-explicit-any
			json: null as any,
			// eslint-disable-next-line @typescript-eslint/no-explicit-any
			text: null as any,
		},
		data: data,
		errorType: ErrorType.NONE,
	};
}

export const loadInvestigationSurfacesPrizesAPI = async (): Promise<
	HttpJsonResult<InvestigationSurfacesPrizesListModel>
> => {
	return http.getJson(
		InvestigationSurfacesPrizesListSchema,
		`/application-forms/{TENANT}/api-priv/v1/applications/{APPLICATION_ID}/investigation/surfaces/summary`
	);
};

export const loadInvestigationSurfacesPrizesDetailsAPI = async (
	optionCode: string,
	nextKey?: string | null,
	councilCode?: string,
	sheet?: string,
	parcelCode?: string,
	engagement?: string,
	cropCode?: string
): Promise<
	HttpJsonResult<InvestigationSurfacesPrizesDetailsInfiniteListModel>
> => {
	const requestConfig: RequestConfig = {};
	requestConfig.params = {
		councilCode,
		sheet,
		parcelCode,
		engagement,
		cropCode,
		nextKey,
	};

	removeNullsOrBlanksFromObject(requestConfig.params);

	return http.getJson(
		InvestigationSurfacesPrizesDetailsInfiniteListSchema,
		`/application-forms/{TENANT}/api-priv/v1/applications/{APPLICATION_ID}/investigation/surfaces/options/${optionCode}`,
		requestConfig
	);
};

export const saveInvestigationSurfacesPrizesDetailsAPI = async (
	option_code: string,
	investigationSurfacesPrizesDetailsList: SaveInvestigationSurfacesPrizesDetailsModel,
	compileStatusIdentifier: string
): Promise<
	HttpJsonResult<SaveInvestigationSurfacesPrizesDetailsResponseModel>
> => {
	const requestConfig: RequestConfig = {};
	requestConfig.params = {
		compile_status_identifier: compileStatusIdentifier,
	};

	return http.postJson(
		SaveInvestigationSurfacesPrizesDetailsResponseSchema,
		`/application-forms/{TENANT}/api-priv/v1/applications/{APPLICATION_ID}/investigation/surfaces/options/${option_code}`,
		investigationSurfacesPrizesDetailsList,
		requestConfig
	);
};

export const loadInvestigationSurfacesFiltersAPI = async (
	option_code: string,
	path: string,
	councilCode?: string,
	sheet?: string,
	parcelCode?: string
): Promise<HttpJsonResult<TerritoryFiltersModel>> => {
	const requestConfig: RequestConfig = {};
	requestConfig.params = {
		councilCode,
		sheet,
		parcelCode,
	};
	removeNullsOrBlanksFromObject(requestConfig.params);
	return http.getJson(
		TerritoryFiltersSchema,
		`/application-forms/{TENANT}/api-priv/v1/applications/{APPLICATION_ID}/investigation/${path}/options/${option_code}/territory-filters`,
		requestConfig
	);
};

export const loadInvestigationYoungFarmerAPI = async (): Promise<
	HttpJsonResult<InvestigationYoungFarmerModel>
> => {
	return http.getJson(
		InvestigationYoungFarmerSchema,
		`/application-forms/{TENANT}/api-priv/v1/applications/{APPLICATION_ID}/investigation/young-farmer`
	);
};

export const saveInvestigationYoungFarmerAPI = async (
	investigationYoungFarmerData: InvestigationYoungFarmerModel,
	compileStatusIdentifier: string
): Promise<HttpJsonResult<InvestigationYoungFarmerModel>> => {
	const requestConfig: RequestConfig = {};
	requestConfig.params = {
		compile_status_identifier: compileStatusIdentifier,
	};

	return http.postJson(
		InvestigationYoungFarmerSchema,
		`/application-forms/{TENANT}/api-priv/v1/applications/{APPLICATION_ID}/investigation/young-farmer`,
		investigationYoungFarmerData,
		requestConfig
	);
};

export const loadInvestigationDARAPI = async (): Promise<
	HttpJsonResult<InvestigationDARModel>
> => {
	return http.getJson(
		InvestigationDARSchema,
		`/application-forms/{TENANT}/api-priv/v1/applications/{APPLICATION_ID}/investigation/dars`
	);
};

export const saveInvestigationDARAPI = async (
	investigationDARData: SaveInvestigationDARModel,
	compileStatusIdentifier: string
): Promise<HttpJsonResult<InvestigationDARModel>> => {
	const requestConfig: RequestConfig = {};
	requestConfig.params = {
		compile_status_identifier: compileStatusIdentifier,
	};

	return http.postJson(
		InvestigationDARSchema,
		`/application-forms/{TENANT}/api-priv/v1/applications/{APPLICATION_ID}/investigation/dars`,
		investigationDARData,
		requestConfig
	);
};

export const updateInvestigationDARAPI = async (): Promise<HttpResult> => {
	return http.put(
		`/application-forms/{TENANT}/api-priv/v1/applications/{APPLICATION_ID}/investigation/dars`,
		undefined
	);
};

export const loadCorrectionSurfacesPrizesAPI = async (): Promise<
	HttpJsonResult<CorrectionSurfacesPrizesListModel>
> => {
	return http.getJson(
		CorrectionSurfacesPrizesListSchema,
		`/application-forms/{TENANT}/api-priv/v1/applications/{APPLICATION_ID}/investigation/waived/surfaces/summary`
	);
};

export const loadCorrectionSurfacesPrizesDetailsAPI = async (
	optionCode: string,
	nextKey?: string | null,
	councilCode?: string,
	sheet?: string,
	parcelCode?: string,
	engagement?: string,
	cropCode?: string
): Promise<
	HttpJsonResult<CorrectionSurfacesPrizesDetailsInfiniteListModel>
> => {
	const requestConfig: RequestConfig = {};
	requestConfig.params = {
		councilCode,
		sheet,
		parcelCode,
		engagement,
		cropCode,
		nextKey,
	};

	removeNullsOrBlanksFromObject(requestConfig.params);

	return http.getJson(
		CorrectionSurfacesPrizesDetailsInfiniteListSchema,
		`/application-forms/{TENANT}/api-priv/v1/applications/{APPLICATION_ID}/investigation/waived/surfaces/options/${optionCode}`,
		requestConfig
	);
};

export const saveCorrectionSurfacesPrizesDetailsAPI = async (
	option_code: string,
	correctionSurfacesPrizesDetailsList: SaveCorrectionSurfacesPrizesDetailsModel,
	compileStatusIdentifier: string
): Promise<
	HttpJsonResult<SaveInvestigationSurfacesPrizesDetailsResponseModel>
> => {
	const requestConfig: RequestConfig = {};
	requestConfig.params = {
		compile_status_identifier: compileStatusIdentifier,
	};

	return http.postJson(
		SaveInvestigationSurfacesPrizesDetailsResponseSchema,
		`/application-forms/{TENANT}/api-priv/v1/applications/{APPLICATION_ID}/investigation/waived/surfaces/options/${option_code}`,
		correctionSurfacesPrizesDetailsList,
		requestConfig
	);
};

export const loadInvestigationModulationAPI = async (): Promise<
	HttpJsonResult<InvestigationModulationModel>
> => {
	return http.getJson(
		InvestigationModulationSchema,
		`/application-forms/{TENANT}/api-priv/v1/applications/{APPLICATION_ID}/investigation/modulation/summary`
	);
};

export const loadOptionsPaymentAPI = async (): Promise<
	HttpJsonResult<OptionsPaymentListModel>
> => {
	return http.getJson(
		OptionsPaymentListSchema,
		`/application-forms/{TENANT}/api-priv/v1/applications/{APPLICATION_ID}/investigation/options/payments`
	);
};

export const saveOptionsPaymentAPI = async (
	choices: SaveOptionsPaymentModel,
	compile_status_identifier: string
): Promise<HttpResult> => {
	const requestConfig = {
		params: {
			compile_status_identifier,
		},
		headers: {
			"Content-Type": "application/json",
		},
	};
	removeNullsOrBlanksFromObject(requestConfig.params);
	return await http.post(
		`/application-forms/{TENANT}/api-priv/v1/applications/{APPLICATION_ID}/investigation/options/payments`,
		JSON.stringify(choices),
		requestConfig
	);
};

export const loadInvestigationCoupledAPI = async (): Promise<
	HttpJsonResult<InvestigationCoupledListModel>
> => {
	return http.getJson(
		InvestigationCoupledListSchema,
		`/application-forms/{TENANT}/api-priv/v1/applications/{APPLICATION_ID}/investigation/options/coupled`
	);
};

export const saveInvestigationCoupledAPI = async (
	investigationCoupledList: SaveInvestigationCoupledListModel,
	compile_status_identifier: string
): Promise<HttpResult> => {
	const requestConfig = {
		params: {
			compile_status_identifier,
		},
		headers: {
			"Content-Type": "application/json",
		},
	};
	removeNullsOrBlanksFromObject(requestConfig.params);
	return await http.post(
		`/application-forms/{TENANT}/api-priv/v1/applications/{APPLICATION_ID}/investigation/options/coupled`,
		JSON.stringify(investigationCoupledList),
		requestConfig
	);
};

export const loadInvestigationDataAPI = async (): Promise<
	HttpJsonResult<InvestigationDataModel>
> => {
	return http.getJson(
		InvestigationDataSchema,
		`/application-forms/{TENANT}/api-priv/v1/applications/{APPLICATION_ID}/investigation/data`
	);
};

export const saveInvestigationDataAPI = async (
	investigationData: InvestigationDataModel,
	compileStatusIdentifier: string
): Promise<HttpJsonResult<InvestigationDataModel>> => {
	const requestConfig: RequestConfig = {};
	requestConfig.params = {
		compile_status_identifier: compileStatusIdentifier,
	};

	return http.postJson(
		InvestigationDataSchema,
		`/application-forms/{TENANT}/api-priv/v1/applications/{APPLICATION_ID}/investigation/data`,
		investigationData,
		requestConfig
	);
};

export const loadInvestigationSurfaceEcoschemesAPI = async (): Promise<
	HttpJsonResult<InvestigationSurfaceEcoschemasModel>
> => {
	return http.getJson(
		InvestigationSurfaceEcoschemasSchema,
		`/application-forms/{TENANT}/api-priv/v1/applications/{APPLICATION_ID}/investigation/ecoschemas`
	);
};

export const saveInvestigationSurfaceEcoschemesAPI = async (
	investigationSurfaceEcoschemas: saveInvestigationSurfaceEcoschemasModel
): Promise<HttpResult> => {
	const requestConfig = {
		headers: {
			"Content-Type": "application/json",
		},
	};

	return http.put(
		`/application-forms/{TENANT}/api-priv/v1/applications/{APPLICATION_ID}/investigation/ecoschemas`,
		JSON.stringify(investigationSurfaceEcoschemas),
		requestConfig
	);
};

export const loadInvestigationOverdeclarationAPI = async (): Promise<
	HttpJsonResult<InvestigationOverDeclarationListModel>
> => {
	return http.getJson(
		InvestigationOverdeclarationListSchema,
		`/application-forms/{TENANT}/api-priv/v1/applications/{APPLICATION_ID}/investigation/overdeclaration`
	);
};

export const saveInvestigationOverdeclarationAPI = async (
	investigationOverdeclarationData: SaveInvestigationOverDeclarationListModel,
	compile_status_identifier: string
): Promise<HttpResult> => {
	const requestConfig = {
		params: {
			compile_status_identifier,
		},
		headers: {
			"Content-Type": "application/json",
		},
	};

	return http.post(
		`/application-forms/{TENANT}/api-priv/v1/applications/{APPLICATION_ID}/investigation/overdeclaration`,
		JSON.stringify(investigationOverdeclarationData),
		requestConfig
	);
};
