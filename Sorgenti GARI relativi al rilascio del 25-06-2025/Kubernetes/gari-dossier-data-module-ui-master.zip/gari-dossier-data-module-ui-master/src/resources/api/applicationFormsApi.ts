import type {
	AttachmentListResponse,
	AttachmentTypeResponse,
	BuildingProcessingDetailsListModel,
	BuildingProcessingListResponse,
	CheckMandatoryMachineryOrEquipmentModel,
	CheckMandatoryMachineryOrEquipmentResponseModel,
	ConsumptionDeclarationListModel,
	DeclarationListResponse,
	DeclarationTypeChoiceCompanyTypeResponse,
	DeclarationTypeChoiceListResponse,
	EquipmentListModel,
	ExciseMotivationListModel,
	GasStationTakingsModel,
	getGiasUsernameResponse,
	getGraphicCropPlanFromImportResponse,
	getGraphicCropPlanResponse,
	importLogResponse,
	LandUseListFromCodeResponse,
	LandUseListResponse,
	MachineryListModel,
	MunicipalityListFromCodeResponse,
	MunicipalityListResponse,
	PrintHistoryResponseModel,
	RequirementListResponse,
	SaveAttachmentModel,
	SaveBuildingProcessingDetails,
	SaveDeclarationsModel,
	SaveDeclarationTypeChoiceModel,
	SaveDeclarationTypeChoiceModelV2,
	SaveDeclarationTypeChoiceResponse,
	SaveDeclarationTypeChoiceResponseV2,
	SaveEquipmentsModel,
	SaveEquipmentsResponseModel,
	SaveFuelConsumeListModel,
	SaveGraphicCropPlanModel,
	SaveGraphicCropPlanResponse,
	SaveMachineriesModel,
	SaveMachineriesResponseModel,
	SaveRequirementModel,
	ZootechnicalProcessingDetailModel,
	ZootechnicalProcessingDetailResponse,
	ZootechnicalProcessingRANModel,
	ZootechnicalSaveDetailModel,
} from "@/models/applicationForms";
import {
	AttachmentListResponseSchema,
	AttachmentTypeResponseSchema,
	BuildingProcessingDetailsListSchema,
	BuildingProcessingListResponseSchema,
	CheckMandatoryMachineryOrEquipmentResponseSchema,
	ConsumptionDeclarationListModelSchema,
	DeclarationListResponseSchema,
	DeclarationTypeChoiceCompanyTypeResponseSchema,
	DeclarationTypeChoiceListResponseSchema,
	EquipmentListSchema,
	ExciseMotivationListModelSchema,
	GasStationTakingsModelSchema,
	getGiasUsernameResponseSchema,
	getGraphicCropPlanFromImportListResponseSchema,
	getGraphicCropPlanFromImportResponseSchema,
	getGraphicCropPlanListResponseSchema,
	GiasTokenResponseResponseSchema,
	importLogResponseSchema,
	LandUseListFromCodeResponseSchema,
	LandUseListResponseSchema,
	MachineryListSchema,
	MunicipalityListFromCodeResponseSchema,
	MunicipalityListResponseSchema,
	PrintHistoryResponseSchema,
	RequirementListResponseSchema,
	SaveDeclarationsSchema,
	SaveDeclarationTypeChoiceResponseSchema,
	SaveDeclarationTypeChoiceResponseSchemaV2,
	SaveEquipmentsResponseSchema,
	SaveGraphicCropPlanResponseSchema,
	SaveMachineriesResponseSchema,
	SaveRequirementModelSchema,
	ZootechnicalProcessingDetailResponseSchema,
	ZootechnicalProcessingRANModelSchema,
	ZootechnicalSaveDetail,
} from "@/models/applicationForms";
import { removeNullsOrBlanksFromObject } from "@/models/utils";
import {
	type HttpJsonResult,
	type HttpResult,
	type RequestConfig,
} from "@abaco/safe-rest/src/HTTPClient";

import { httpPlus as http } from "./http";

export const getAttachmentList = async (
	nextKey: string | undefined | null,
	attachmentGroup: string
): Promise<HttpJsonResult<AttachmentListResponse>> => {
	const requestConfig: RequestConfig = {};
	requestConfig.params = {
		nextKey: nextKey,
	};
	removeNullsOrBlanksFromObject(requestConfig.params);

	return http.getJson(
		AttachmentListResponseSchema,
		`/application-forms/{TENANT}/api-priv/v1/applications/{APPLICATION_ID}/attachments/groups/${attachmentGroup}`,
		requestConfig
	);
};

export const addAttachment = async (
	newAttachmentObj: SaveAttachmentModel,
	compileStatusIdentifier: string
): Promise<HttpResult> => {
	const requestConfig: RequestConfig = {};
	requestConfig.params = {
		compileStatusIdentifier,
	};

	const form = new FormData();

	form.append(
		"file",
		new Blob([newAttachmentObj.file]),
		newAttachmentObj.file.name
	);
	form.append(
		"payload",
		new Blob(
			[
				JSON.stringify({
					notes: newAttachmentObj.notes,
					typeCode: newAttachmentObj.typeCode,
					groupCode: newAttachmentObj.groupCode,
				}),
			],
			{
				type: "application/json",
			}
		)
	);

	return http.post(
		`/application-forms/{TENANT}/api-priv/v1/applications/{APPLICATION_ID}/attachments`,
		form,
		requestConfig
	);
};

export const editAttachment = async (
	attachmentId: string,
	editAttachmentObj: SaveAttachmentModel,
	compileStatusIdentifier: string
): Promise<HttpResult> => {
	const requestConfig: RequestConfig = {};
	requestConfig.headers = {
		"Content-Type": "application/json",
	};
	requestConfig.params = {
		compileStatusIdentifier,
	};

	return http.patch(
		`/application-forms/{TENANT}/api-priv/v1/applications/{APPLICATION_ID}/attachments/${attachmentId}`,
		JSON.stringify(editAttachmentObj),
		requestConfig
	);
};

export const deleteAttachment = async (
	attachmentId: string,
	compileStatusIdentifier: string
): Promise<HttpResult> => {
	const requestConfig: RequestConfig = {};
	requestConfig.params = {
		compileStatusIdentifier,
	};

	return await http.delete(
		`/application-forms/{TENANT}/api-priv/v1/applications/{APPLICATION_ID}/attachments/${attachmentId}`,
		requestConfig
	);
};

export const getAttachmentTypeList = async (
	attachmentGroup: string,
	nextKey?: string | undefined | null
): Promise<HttpJsonResult<AttachmentTypeResponse>> => {
	const requestConfig: RequestConfig = {};
	requestConfig.params = {
		nextKey: nextKey,
	};
	removeNullsOrBlanksFromObject(requestConfig.params);
	return http.getJson(
		AttachmentTypeResponseSchema,
		`/application-forms/{TENANT}/api-priv/v1/applications/attachment-types/${attachmentGroup}`,
		requestConfig
	);
};

export const downloadAttachment = async (
	attachmentId: string
	// eslint-disable-next-line @typescript-eslint/no-explicit-any
): Promise<any> => {
	return http.get(
		`/application-forms/{TENANT}/api-priv/v1/applications/{APPLICATION_ID}/attachments/${attachmentId}`
	);
};

export const getDeclarationList = async (
	documentCode: string
): Promise<HttpJsonResult<DeclarationListResponse>> => {
	return http.getJson(
		DeclarationListResponseSchema,
		`/application-forms/{TENANT}/api-priv/v1/applications/{APPLICATION_ID}/declarations/${documentCode}`
	);
};

export const saveDeclarations = async (
	document_code: string,
	declarations: SaveDeclarationsModel,
	compileStatusIdentifier: string
): Promise<HttpJsonResult<SaveDeclarationsModel>> => {
	const requestConfig: RequestConfig = {};
	requestConfig.params = {
		compileStatusIdentifier,
		compileStatus: "COMPLETED",
	};
	removeNullsOrBlanksFromObject(requestConfig.params);
	return http.postJson(
		SaveDeclarationsSchema,
		`/application-forms/{TENANT}/api-priv/v1/applications/{APPLICATION_ID}/declarations/${document_code}`,
		declarations,
		requestConfig
	);
};

export const saveEquipments = async (
	equipments: SaveEquipmentsModel,
	functionalControl: string,
	compileStatusIdentifier: string
): Promise<HttpJsonResult<SaveEquipmentsResponseModel>> => {
	const requestConfig: RequestConfig = {};
	requestConfig.params = {
		functionalControl: functionalControl,
		compileStatusIdentifier: compileStatusIdentifier,
	};
	removeNullsOrBlanksFromObject(requestConfig.params);
	return http.postJson(
		SaveEquipmentsResponseSchema,
		`/application-forms/{TENANT}/api-priv/v1/applications/{APPLICATION_ID}/equipments`,
		equipments,
		requestConfig
	);
};

export const loadEquipments = async (
	functionalControl?: number
): Promise<HttpJsonResult<EquipmentListModel>> => {
	const requestConfig: RequestConfig = {};
	requestConfig.params = {
		functionalControl: functionalControl,
	};
	removeNullsOrBlanksFromObject(requestConfig.params);

	return http.getJson(
		EquipmentListSchema,
		`/application-forms/{TENANT}/api-priv/v1/applications/{APPLICATION_ID}/equipments`,
		requestConfig
	);
};

export const loadMachineries = async (
	machineryClassCode?: string,
	functionalControl?: number
): Promise<HttpJsonResult<MachineryListModel>> => {
	const requestConfig: RequestConfig = {};
	requestConfig.params = {
		class: machineryClassCode,
		functionalControl: functionalControl,
	};
	removeNullsOrBlanksFromObject(requestConfig.params);

	return http.getJson(
		MachineryListSchema,
		`/application-forms/{TENANT}/api-priv/v1/applications/{APPLICATION_ID}/machineries`,
		requestConfig
	);
};

export const saveMachineries = async (
	machineries: SaveMachineriesModel,
	classCode: string,
	functionalControl: string,
	compileStatusIdentifier: string
): Promise<HttpJsonResult<SaveMachineriesResponseModel>> => {
	const requestConfig: RequestConfig = {};
	requestConfig.params = {
		classCode: classCode,
		functionalControl: functionalControl,
		compileStatusIdentifier: compileStatusIdentifier,
	};
	removeNullsOrBlanksFromObject(requestConfig.params);

	return http.postJson(
		SaveMachineriesResponseSchema,
		`/application-forms/{TENANT}/api-priv/v1/applications/{APPLICATION_ID}/machineries`,
		machineries,
		requestConfig
	);
};

export const checkMachineriesOrEquipmentsAPI = async (
	itemsToCheck: CheckMandatoryMachineryOrEquipmentModel,
	compileStatusIdentifier: string
): Promise<HttpJsonResult<CheckMandatoryMachineryOrEquipmentResponseModel>> => {
	const requestConfig: RequestConfig = {};
	requestConfig.params = {
		compileStatusIdentifier: compileStatusIdentifier,
	};
	removeNullsOrBlanksFromObject(requestConfig.params);

	return http.postJson(
		CheckMandatoryMachineryOrEquipmentResponseSchema,
		`/application-forms/{TENANT}/api-priv/v1/applications/{APPLICATION_ID}/check-mandatory-tools`,
		itemsToCheck,
		requestConfig
	);
};

export const getZootechnicalProcessingRANList = async (): Promise<
	HttpJsonResult<ZootechnicalProcessingRANModel>
> => {
	return http.getJson(
		ZootechnicalProcessingRANModelSchema,
		`/application-forms/{TENANT}/api-priv/v1/applications/{APPLICATION_ID}/zootechnics`
	);
};

export const saveZootechnicalProcessingRAN = async (
	compileStatusIdentifier: string,
	ranValue: ZootechnicalSaveDetailModel
): Promise<HttpJsonResult<ZootechnicalSaveDetailModel>> => {
	const requestConfig: RequestConfig = {};
	requestConfig.params = {
		compileStatusIdentifier: compileStatusIdentifier,
	};

	return http.postJson(
		ZootechnicalSaveDetail,
		`/application-forms/{TENANT}/api-priv/v1/applications/{APPLICATION_ID}/zootechnics/ran`,
		ranValue,
		requestConfig
	);
};

export const deleteZootechnicalProcessing = async (
	compileStatusIdentifier: string
): Promise<HttpResult> => {
	const requestConfig: RequestConfig = {};
	requestConfig.params = {
		compileStatusIdentifier,
	};

	return await http.delete(
		`/application-forms/{TENANT}/api-priv/v1/applications/{APPLICATION_ID}/zootechnics`,
		requestConfig
	);
};

export const getZootechnicalProcessingDetailList = async (
	speciesId: string,
	subSpeciesTypeCode?: string | null | undefined,
	workTypeCode?: string | null | undefined
): Promise<HttpJsonResult<ZootechnicalProcessingDetailResponse>> => {
	const requestConfig: RequestConfig = {};
	requestConfig.params = {
		sub_species: subSpeciesTypeCode,
		work_type: workTypeCode,
	};
	removeNullsOrBlanksFromObject(requestConfig.params);

	return http.getJson(
		ZootechnicalProcessingDetailResponseSchema,
		`/application-forms/{TENANT}/api-priv/v1/applications/{APPLICATION_ID}/zootechnics/${speciesId}/processings`,
		requestConfig
	);
};

export const saveZootechnicalProcessingDetailList = async (
	speciesId: string,
	list: Array<Partial<ZootechnicalProcessingDetailModel>>,
	compileStatusIdentifier: string
): Promise<HttpResult> => {
	const requestConfig: RequestConfig = {};
	requestConfig.params = {
		compileStatusIdentifier: compileStatusIdentifier,
	};
	requestConfig.headers = {
		"Content-type": "application/json",
	};
	removeNullsOrBlanksFromObject(requestConfig.params);

	return http.post(
		`/application-forms/{TENANT}/api-priv/v1/applications/{APPLICATION_ID}/zootechnics/${speciesId}/processings`,
		JSON.stringify(list),
		requestConfig
	);
};

export const deleteZootechnicalProcessingDetailList = async (
	speciesId: string,
	compileStatusIdentifier: string
): Promise<HttpResult> => {
	const requestConfig: RequestConfig = {};
	requestConfig.params = {
		compileStatusIdentifier: compileStatusIdentifier,
	};
	removeNullsOrBlanksFromObject(requestConfig.params);

	return http.delete(
		`/application-forms/{TENANT}/api-priv/v1/applications/{APPLICATION_ID}/zootechnics/${speciesId}/processings`,
		requestConfig
	);
};

export const getBuildingProcessingList = async (): Promise<
	HttpJsonResult<BuildingProcessingListResponse>
> => {
	return http.getJson(
		BuildingProcessingListResponseSchema,
		`/application-forms/{TENANT}/api-priv/v1/applications/{APPLICATION_ID}/buildings`
	);
};

export const getBuildingProcessingDetail = async (
	buildingTypeId: string
): Promise<HttpJsonResult<BuildingProcessingDetailsListModel>> => {
	return http.getJson(
		BuildingProcessingDetailsListSchema,
		`/application-forms/{TENANT}/api-priv/v1/applications/{APPLICATION_ID}/buildings/${buildingTypeId}/processings`
	);
};

export const deleteBuildingProcessingDetail = async (
	buildingTypeId: string,
	compileStatusIdentifier: string
): Promise<HttpResult> => {
	const requestConfig: RequestConfig = {};
	requestConfig.params = {
		compileStatusIdentifier: compileStatusIdentifier,
	};
	removeNullsOrBlanksFromObject(requestConfig.params);
	return http.delete(
		`/application-forms/{TENANT}/api-priv/v1/applications/{APPLICATION_ID}/buildings/${buildingTypeId}/processings/`,
		requestConfig
	);
};

export const saveBuildingProcessingDetail = async (
	buildingTypeId: string,
	buildingProcessings: SaveBuildingProcessingDetails,
	compileStatusIdentifier: string
): Promise<HttpJsonResult<BuildingProcessingDetailsListModel>> => {
	const requestConfig: RequestConfig = {};
	requestConfig.params = {
		compileStatusIdentifier: compileStatusIdentifier,
	};
	removeNullsOrBlanksFromObject(requestConfig.params);
	return http.postJson(
		BuildingProcessingDetailsListSchema,
		`/application-forms/{TENANT}/api-priv/v1/applications/{APPLICATION_ID}/buildings/${buildingTypeId}/processings`,
		buildingProcessings,
		requestConfig
	);
};

export const getDeclarationTypeChoiceList = async (): Promise<
	HttpJsonResult<DeclarationTypeChoiceListResponse>
> => {
	return http.getJson(
		DeclarationTypeChoiceListResponseSchema,
		`/application-forms/{TENANT}/api-priv/v1/applications/{APPLICATION_ID}/statements`
	);
};

export const getMunicipalityChoiceList = async (
	filter: string
): Promise<HttpJsonResult<MunicipalityListResponse>> => {
	const requestConfig: RequestConfig = {};
	requestConfig.params = {
		domainZones: "comuni",
		include_geometries: false,
		filter,
	};

	return http.getJson(
		MunicipalityListResponseSchema,
		`/lpis-server-api/{TENANT}/api-priv/v1/lpis/sectors`,
		requestConfig
	);
};

export const getLandUseChoiceList = async (
	filter: string
): Promise<HttpJsonResult<LandUseListResponse>> => {
	const requestConfig: RequestConfig = {};
	requestConfig.params = {
		filter,
	};
	return http.getJson(
		LandUseListResponseSchema,
		`/lpis-server-api/{TENANT}/public/v1/lpis/support/landuses-codes`,
		requestConfig
	);
};

export const saveDeclarationTypeChoice = async (
	declarationsTypeChoice: SaveDeclarationTypeChoiceModel,
	compileStatusIdentifier: string
): Promise<HttpJsonResult<SaveDeclarationTypeChoiceResponse>> => {
	const requestConfig: RequestConfig = {};
	requestConfig.params = {
		compileStatusIdentifier: compileStatusIdentifier,
	};
	return http.postJson(
		SaveDeclarationTypeChoiceResponseSchema,
		`/application-forms/{TENANT}/api-priv/v1/applications/{APPLICATION_ID}/statements`,
		declarationsTypeChoice,
		requestConfig
	);
};

export const getDeclarationTypeChoiceV2 = async (): Promise<
	HttpJsonResult<SaveDeclarationTypeChoiceResponseV2>
> => {
	return http.getJson(
		SaveDeclarationTypeChoiceResponseSchemaV2,
		`/pua-application-forms/{TENANT}/v1/applications/{APPLICATION_ID_SAME}/tipologia-dichiarazione`
	);
};

export const saveDeclarationTypeChoiceV2 = async (
	declarationsTypeChoiceV2: SaveDeclarationTypeChoiceModelV2
): Promise<HttpJsonResult<SaveDeclarationTypeChoiceResponseV2>> => {
	return http.postJson(
		SaveDeclarationTypeChoiceResponseSchemaV2,
		`/pua-application-forms/{TENANT}/v1/applications/{APPLICATION_ID_SAME}/tipologie-dichiarazione`,
		declarationsTypeChoiceV2
	);
};

export const editDeclarationTypeChoiceV2 = async (
	declarationsTypeChoiceV2: SaveDeclarationTypeChoiceModelV2
): Promise<HttpJsonResult<SaveDeclarationTypeChoiceResponseV2>> => {
	return http.putJson(
		SaveDeclarationTypeChoiceResponseSchemaV2,
		`/pua-application-forms/{TENANT}/v1/applications/{APPLICATION_ID_SAME}/tipologia-dichiarazione`,
		declarationsTypeChoiceV2
	);
};

export const saveGraphicCropPlan = async (
	graphicCropPlan: SaveGraphicCropPlanModel
): Promise<HttpJsonResult<SaveGraphicCropPlanResponse>> => {
	return http.postJson(
		SaveGraphicCropPlanResponseSchema,
		`/pua-application-forms/{TENANT}/v1/applications/{APPLICATION_ID_SAME}/declarations-on-sectors`,
		graphicCropPlan
	);
};

export const getGiasToken = async (cuaa: string): Promise<any> => {
	const requestConfig: RequestConfig = {};
	requestConfig.params = {
		cuaa: cuaa,
	};
	return http.getJson(
		GiasTokenResponseResponseSchema,
		`/get-gias-token`,
		requestConfig
	);
};

export const loadMunicipalityListFromCode = async (
	municipalityCodeList: string[]
): Promise<HttpJsonResult<MunicipalityListFromCodeResponse>> => {
	const requestConfig: RequestConfig = {};
	requestConfig.params = {
		include_geometries: false,
	};
	return http.postJson(
		MunicipalityListFromCodeResponseSchema,
		`/lpis-server-api/{TENANT}/public/v1/lpis/sectors`,
		{ codes: municipalityCodeList },
		requestConfig
	);
};

export const loadLandUseListFromCode = async (
	landUseCodeList: string[]
): Promise<HttpJsonResult<LandUseListFromCodeResponse>> => {
	return http.postJson(
		LandUseListFromCodeResponseSchema,
		`/lpis-server-api/{TENANT}/public/v1/lpis/support/landuses-codes`,
		{ landuse_codes: landUseCodeList }
	);
};

export const saveImportGraphicCropPlanFileMock = (): {
	id: string;
} | null => {
	if (Math.random() > 0.5) {
		return { id: "1234567890" };
	} else {
		return null;
	}
};

export const getStatusImportGraphicCropPlanPolling = async (
	graphicCropPlanRequestId: string,
	cuaa: string
): Promise<HttpJsonResult<getGraphicCropPlanFromImportResponse>> => {
	const requestConfig: RequestConfig = {};
	requestConfig.params = {};

	return http.getJson(
		getGraphicCropPlanFromImportResponseSchema,
		`/data-importer/{TENANT}/public/v1/import-crop-plan/${cuaa}/requests/${graphicCropPlanRequestId}`,
		requestConfig
	);
};

export const importGraphicCropPlan = async (
	cuaa: string,
	currentYear: number
): Promise<HttpJsonResult<getGraphicCropPlanFromImportResponse>> => {
	const campagna = currentYear;
	const requestConfig: RequestConfig = {};
	requestConfig.params = {
		campagna,
	};

	return http.getJson(
		getGraphicCropPlanFromImportResponseSchema,
		`/data-importer/{TENANT}/public/v1/import-crop-plan/${cuaa}/import`,
		requestConfig
	);
};

export const importLog = async (
	cuaa: string,
	requestId: string
): Promise<HttpJsonResult<importLogResponse>> => {
	const requestConfig: RequestConfig = {};
	requestConfig.params = {};

	return http.getJson(
		importLogResponseSchema,
		`/data-importer/{TENANT}/public/v1/import-crop-plan/${cuaa}/requests/${requestId}/log`,
		requestConfig
	);
};

export const loadGraphicCropPlan = async (
	cuaa: string
): Promise<HttpJsonResult<getGraphicCropPlanFromImportResponse[]>> => {
	return http.getJson(
		getGraphicCropPlanFromImportListResponseSchema,
		`/data-importer/{TENANT}/public/v1/import-crop-plan/${cuaa}/requests`
	);
};

export const getGraphicCropPlanList = async (): Promise<
	HttpJsonResult<getGraphicCropPlanResponse[]>
> => {
	return http.getJson(
		getGraphicCropPlanListResponseSchema,
		`/pua-application-forms/{TENANT}/v1/applications/{APPLICATION_ID_SAME}/declarations-on-sectors`
	);
};

export const getCompanyTypeList = async (): Promise<
	HttpJsonResult<DeclarationTypeChoiceCompanyTypeResponse>
> => {
	const requestConfig: RequestConfig = {};
	return http.getJson(
		DeclarationTypeChoiceCompanyTypeResponseSchema,
		`/application-forms/{TENANT}/api-priv/v1/applications/{APPLICATION_ID}/company/types`,
		requestConfig
	);
};

export const getRequirementList = async (): Promise<
	HttpJsonResult<RequirementListResponse>
> => {
	return http.getJson(
		RequirementListResponseSchema,
		`/application-forms/{TENANT}/api-priv/v1/applications/{APPLICATION_ID}/needs`
	);
};

export const saveRequirement = async (
	requirement: SaveRequirementModel,
	compileStatusIdentifier: string
): Promise<HttpJsonResult<SaveRequirementModel>> => {
	const requestConfig: RequestConfig = {};
	requestConfig.params = {
		compileStatusIdentifier,
	};

	return http.postJson(
		SaveRequirementModelSchema,
		`/application-forms/{TENANT}/api-priv/v1/applications/{APPLICATION_ID}/needs`,
		requirement,
		requestConfig
	);
};

export const getConsumptionDeclarationList = async (): Promise<
	HttpJsonResult<ConsumptionDeclarationListModel>
> => {
	return http.getJson(
		ConsumptionDeclarationListModelSchema,
		`/application-forms/{TENANT}/api-priv/v1/applications/{APPLICATION_ID}/consumes`
	);
};

export const getPurchasedFuelDetails = async (): Promise<
	HttpJsonResult<GasStationTakingsModel>
> => {
	return http.getJson(
		GasStationTakingsModelSchema,
		`/application-forms/{TENANT}/api-priv/v1/applications/{APPLICATION_ID}/gas-station-takings`
	);
};

export const getExciseMotivationList = async (): Promise<
	HttpJsonResult<ExciseMotivationListModel>
> => {
	return http.getJson(
		ExciseMotivationListModelSchema,
		`/application-forms/{TENANT}/api-priv/v1/excise-motivations`
	);
};

export const saveFuelConsumeList = async (
	compileStatusIdentifier: string,
	data: SaveFuelConsumeListModel
): Promise<HttpResult> => {
	const requestConfig: RequestConfig = {};
	requestConfig.params = {
		compileStatusIdentifier: compileStatusIdentifier,
	};
	requestConfig.headers = {
		"Content-type": "application/json",
	};
	removeNullsOrBlanksFromObject(requestConfig.params);

	return http.post(
		`/application-forms/{TENANT}/api-priv/v1/applications/{APPLICATION_ID}/consumes`,
		JSON.stringify(data),
		requestConfig
	);
};

export const getApplicationPrintHistory = async (): Promise<
	HttpJsonResult<PrintHistoryResponseModel>
> => {
	return http.getJson(
		PrintHistoryResponseSchema,
		`/applications/{TENANT}/api-priv/v1/applications/{APPLICATION_ID}/print-history`
	);
};

export const getGiasUsername = async (): Promise<
	HttpJsonResult<getGiasUsernameResponse>
> => {
	const requestConfig: RequestConfig = {};
	requestConfig.params = {};

	return http.getJson(
		getGiasUsernameResponseSchema,
		`/data-importer/{TENANT}/public/v1/gias/user`,
		requestConfig
	);
};
