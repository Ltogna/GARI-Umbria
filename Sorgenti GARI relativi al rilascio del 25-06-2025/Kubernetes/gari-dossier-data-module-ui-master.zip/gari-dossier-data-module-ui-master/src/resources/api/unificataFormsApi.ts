import type {
	AdditionalDeclarationsModel,
	AdditionalLayersModel,
	ConfirmationApplicationListModel,
	FlAllConfirmedModel,
	LivestockListModel,
	OptionDetailsInfiniteListModel,
	OptionDetailsListModel,
	OptionsListModel,
	PartyListModel,
	PrizesChoiceListModel,
	PsrApplicationsModel,
	RelatedOptionsModel,
	ReplaceLivestockResponseModel,
	ReplacementOrWaiverSurfaceListModel,
	ReplacementOrWaiverWithdrawnReasonListModel,
	SaveAdditionalDeclarationsModel,
	SaveEngagementArrayModel,
	SaveEngagementZootechnicsModel,
	SaveLivestockReplacementListModel,
	SavePrizesChoiceListModel,
	SaveReplacementOrWaiverSurfaceModel,
	SaveReplacementOrWaiverSurfaceResponseModel,
	SaveScoreCardModel,
	SaveSelectBreedingsListModel,
	SaveTakeOverListModel,
	SaveUnifiedDeclarationsModel,
	SaveYoungFarmerDataModel,
	SaveZootechnicsInterventionListModel,
	ScoreCardDefinitionModel,
	SelectBreedingsListResponse,
	StandardDetailsModel,
	SupportOptionsListModel,
	SurfaceDetailModel,
	TakeOverListModel,
	TerritoryFiltersModel,
	UnifiedDeclarationListResponse,
	WithdrawalApplicationDetailsModel,
	WithdrawalApplicationListModel,
	WithdrawalApplicationSummaryListModel,
	WithdrawnReasonListModel,
	YoungFarmerModel,
	ZootechnicFiltersModel,
	ZootechnicInterventionResponseModel,
	ZootechnicInterventionSummaryModel,
	ZootechnicsDeclarationsListModel,
	ZootechnicsDeclarationsListResponse,
	ZootechnicsOptionListModel,
} from "@/models/unificataForms";
import {
	AdditionalDeclarationsSchema,
	AdditionalLayersSchema,
	ConfirmationApplicationListSchema,
	FlAllConfirmedSchema,
	LivestockListSchema,
	OptionDetailsInfiniteListSchema,
	OptionDetailsListSchema,
	OptionsListSchema,
	PartyListModelSchema,
	PrizesChoiceListSchema,
	PsrApplicationsSchema,
	RelatedOptionsSchema,
	ReplaceLivestockResponseSchema,
	ReplacementOrWaiverSurfaceListSchema,
	ReplacementOrWaiverWithdrawnReasonListSchema,
	saveLivestockReplacementListSchema,
	SaveReplacementOrWaiverSurfaceResponseSchema,
	SaveTakeOverListSchema,
	SaveUnifiedDeclarationsSchema,
	SaveYoungFarmerDataSchema,
	ScoreCardDefinitionSchema,
	SelectBreedingsListResponseSchema,
	StandardDetailsSchema,
	SupportOptionsListSchema,
	SurfaceDetailListSchema,
	TakeOverListSchema,
	TerritoryFiltersSchema,
	UnifiedDeclarationListResponseSchema,
	WithdrawalApplicationDetailsSchema,
	WithdrawalApplicationListSchema,
	WithdrawalApplicationSummaryListSchema,
	WithdrawReasonListSchema,
	YoungFarmerModelSchema,
	ZootechnicFiltersSchema,
	ZootechnicInterventionResponseSchema,
	ZootechnicInterventionSummarySchema,
	ZootechnicsDeclarationsListResponseSchema,
	ZootechnicsOptionListSchema,
} from "@/models/unificataForms";
import { removeNullsOrBlanksFromObject } from "@/models/utils";
import {
	ErrorType,
	type HttpJsonResult,
	type HttpResult,
	type RequestConfig,
} from "@abaco/safe-rest/src/HTTPClient";
import { z } from "zod";
import { httpPlus as http } from "./http";

// eslint-disable-next-line @typescript-eslint/no-explicit-any, @typescript-eslint/no-unused-vars
function standardMockResponse(data: any): any {
	return new Promise(res => {
		setTimeout(() => {
			res({
				response: {
					ok: true,
					redirected: false,
					status: 200,
					statusText: "OK",
					type: "default",
					url: "",
					// eslint-disable-next-line @typescript-eslint/no-explicit-any
					headers: null as any,
					// eslint-disable-next-line @typescript-eslint/no-explicit-any
					clone: null as any,
					body: null,
					bodyUsed: false,
					// eslint-disable-next-line @typescript-eslint/no-explicit-any
					arrayBuffer: null as any,
					// eslint-disable-next-line @typescript-eslint/no-explicit-any
					blob: null as any,
					// eslint-disable-next-line @typescript-eslint/no-explicit-any
					formData: null as any,
					// eslint-disable-next-line @typescript-eslint/no-explicit-any
					json: null as any,
					// eslint-disable-next-line @typescript-eslint/no-explicit-any
					text: null as any,
				},
				data: data,
				errorType: ErrorType.NONE,
			});
		}, 1000);
	});
}

export const loadStandardOptionsListAPI = async (
	form_code: string,
	takeover_id?: number,
	overrideOptionCodes?: string
): Promise<HttpJsonResult<OptionsListModel>> => {
	const requestConfig: RequestConfig = {};
	requestConfig.params = {
		takeover_id,
	};
	removeNullsOrBlanksFromObject(requestConfig.params);

	return http.getJson(
		OptionsListSchema,
		`/application-forms/{TENANT}/api-priv/v1/applications/{APPLICATION_ID}/forms/${form_code}/options`,
		requestConfig,
		overrideOptionCodes
	);
};

export const saveSelectedOptionsAPI = async (
	form_code: string,
	optionCodeList: string[],
	compileStatusIdentifier: string
): Promise<HttpJsonResult<OptionsListModel | undefined>> => {
	const requestConfig: RequestConfig = {};
	requestConfig.params = {
		compileStatusIdentifier: compileStatusIdentifier,
	};
	return http.postJson(
		z.optional(OptionsListSchema),
		`/application-forms/{TENANT}/api-priv/v1/applications/{APPLICATION_ID}/forms/${form_code}/options/select`,
		optionCodeList,
		requestConfig
	);
};

export const askComplementaryBeforeDeleteAPI = async (
	formCode: string,
	optionCodes: string[]
): Promise<HttpJsonResult<RelatedOptionsModel>> => {
	return http.postJson(
		RelatedOptionsSchema,
		`/application-forms/{TENANT}/api-priv/v1/applications/{APPLICATION_ID}/forms/${formCode}/options/complementarity`,
		optionCodes
	);
};

export const deleteOptionAPI = async (
	optionCode: string,
	compileStatusIdentifier: string,
	formCode: string
): Promise<HttpResult> => {
	const requestConfig: RequestConfig = {};
	requestConfig.params = {
		compileStatusIdentifier,
	};
	return http.delete(
		`/application-forms/{TENANT}/api-priv/v1/applications/{APPLICATION_ID}/forms/${formCode}/options/${optionCode}`,
		requestConfig
	);
};

export const deleteSupportOptionAPI = async (
	optionCode: string,
	compileStatusIdentifier: string,
	formCode: string
): Promise<HttpResult> => {
	const requestConfig: RequestConfig = {};
	requestConfig.params = {
		compile_status_identifier: compileStatusIdentifier,
	};
	return http.delete(
		`/application-forms/{TENANT}/api-priv/v1/applications/{APPLICATION_ID}/rdp/forms/${formCode}/options/${optionCode}`,
		requestConfig
	);
};

export const deleteSupportOptionZootechnicsAPI = async (
	optionCode: string,
	compileStatusIdentifier: string,
	formCode: string
): Promise<HttpResult> => {
	const requestConfig: RequestConfig = {};
	requestConfig.params = {
		compile_status_identifier: compileStatusIdentifier,
	};
	return http.delete(
		`/application-forms/{TENANT}/api-priv/v1/applications/{APPLICATION_ID}/rdp/forms/${formCode}/zootechnics/options/${optionCode}`,
		requestConfig
	);
};

export const saveSelectedOptionsCommitmentAPI = async (
	engagementArray: SaveEngagementArrayModel,
	compileStatusIdentifier: string,
	formCode: string,
	action?: string
): Promise<HttpJsonResult<OptionDetailsListModel | undefined>> => {
	const requestConfig: RequestConfig = {};
	requestConfig.params = {
		compileStatusIdentifier,
		action,
	};
	removeNullsOrBlanksFromObject(requestConfig.params);
	return http.postJson(
		z.optional(OptionDetailsListSchema),
		`/application-forms/{TENANT}/api-priv/v1/applications/{APPLICATION_ID}/forms/${formCode}/options`,
		engagementArray,
		requestConfig
	);
};

export const saveSelectedSupportOptionsCommitmentAPI = async (
	engagementArray: SaveEngagementArrayModel,
	compileStatusIdentifier: string,
	formCode: string,
	action?: string
): Promise<HttpJsonResult<OptionDetailsListModel | undefined>> => {
	const requestConfig: RequestConfig = {};
	requestConfig.params = {
		compileStatusIdentifier,
		action,
	};
	removeNullsOrBlanksFromObject(requestConfig.params);
	return http.postJson(
		z.optional(OptionDetailsListSchema),
		`/application-forms/{TENANT}/api-priv/v1/applications/{APPLICATION_ID}/rdp/forms/${formCode}/options`,
		engagementArray,
		requestConfig
	);
};

export const saveOptionCommitmentsByFiltersAPI = async (
	formCode: string,
	optionCode: string,
	compileStatusIdentifier: string,
	action: string,
	councilCode?: string,
	sheet?: string,
	parcelCode?: string,
	engagement?: string,
	cropCode?: string,
	takeover_id?: number,
	overrideOptionCodes?: string
): Promise<HttpJsonResult<OptionDetailsInfiniteListModel | undefined>> => {
	const requestConfig: RequestConfig = {};
	requestConfig.params = {
		compileStatusIdentifier,
		action,
		councilCode,
		sheet,
		parcelCode,
		engagement,
		cropCode,
		takeover_id,
	};
	removeNullsOrBlanksFromObject(requestConfig.params);
	return http.postJson(
		z.optional(OptionDetailsInfiniteListSchema),
		`/application-forms/{TENANT}/api-priv/v1/applications/{APPLICATION_ID}/forms/${formCode}/options/${optionCode}/areas`,
		undefined,
		requestConfig,
		overrideOptionCodes
	);
};

export const saveOptionSupportCommitmentsByFiltersAPI = async (
	formCode: string,
	optionCode: string,
	compileStatusIdentifier: string,
	action: string,
	councilCode?: string,
	sheet?: string,
	parcelCode?: string,
	engagement?: string,
	cropCode?: string,
	takeover_id?: number
): Promise<HttpJsonResult<OptionDetailsInfiniteListModel | undefined>> => {
	const requestConfig: RequestConfig = {};
	requestConfig.params = {
		compileStatusIdentifier,
		action,
		councilCode,
		sheet,
		parcelCode,
		engagement,
		cropCode,
		takeover_id,
	};
	removeNullsOrBlanksFromObject(requestConfig.params);
	return http.postJson(
		z.optional(OptionDetailsInfiniteListSchema),
		`/application-forms/{TENANT}/api-priv/v1/applications/{APPLICATION_ID}/rdp/forms/${formCode}/options/${optionCode}/areas`,
		undefined,
		requestConfig
	);
};

export const saveSelectedInterventionsAPI = async (
	form_code: string,
	optionCodeList: string[],
	compileStatusIdentifier: string
): Promise<HttpJsonResult<ZootechnicsOptionListModel>> => {
	const requestConfig: RequestConfig = {};
	requestConfig.params = {
		compileStatusIdentifier: compileStatusIdentifier,
	};
	return http.postJson(
		ZootechnicsOptionListSchema,
		`/application-forms/{TENANT}/api-priv/v1/applications/{APPLICATION_ID}/forms/${form_code}/zootechnics/options/select`,
		optionCodeList,
		requestConfig
	);
};

export const saveSelectedSupportInterventionsAPI = async (
	form_code: string,
	optionCodeList: string[],
	compileStatusIdentifier: string
): Promise<HttpJsonResult<ZootechnicsOptionListModel>> => {
	const requestConfig: RequestConfig = {};
	requestConfig.params = {
		compile_status_identifier: compileStatusIdentifier,
	};
	return http.postJson(
		ZootechnicsOptionListSchema,
		`/application-forms/{TENANT}/api-priv/v1/applications/{APPLICATION_ID}/rdp/forms/${form_code}/options/select`,
		optionCodeList,
		requestConfig
	);
};

export const saveSelectedBreedingDeclarationsAPI = async (
	formCode: string,
	optionsList: ZootechnicsDeclarationsListModel,
	compileStatusIdentifier: string
): Promise<HttpJsonResult<ZootechnicsDeclarationsListResponse>> => {
	const requestConfig: RequestConfig = {};
	requestConfig.params = {
		compileStatusIdentifier: compileStatusIdentifier,
	};
	return http.postJson(
		ZootechnicsDeclarationsListResponseSchema,
		`/application-forms/{TENANT}/api-priv/v1/applications/{APPLICATION_ID}/zootechnics/forms/${formCode}/options`,
		optionsList,
		requestConfig
	);
};

export const deleteInterventionAPI = async (
	option_code: string,
	compileStatusIdentifier: string,
	form_code: string
): Promise<HttpResult> => {
	const requestConfig: RequestConfig = {};
	requestConfig.params = {
		compileStatusIdentifier,
	};
	return http.delete(
		`/application-forms/{TENANT}/api-priv/v1/applications/{APPLICATION_ID}/forms/${form_code}/zootechnics/options/${option_code}`,
		requestConfig
	);
};

export const loadOptionDetailsAPI = async (
	optionCode: string,
	nextKey?: string | null,
	councilCode?: string,
	sheet?: string,
	parcelCode?: string,
	engagement?: string,
	cropCode?: string
): Promise<HttpJsonResult<OptionDetailsInfiniteListModel>> => {
	const requestConfig: RequestConfig = {};
	if (nextKey === undefined) {
		return http.getJson(
			OptionDetailsInfiniteListSchema,
			`/application-forms/{TENANT}/api-priv/v1/applications/{APPLICATION_ID}/options/${optionCode}/crops`
		);
	} else {
		requestConfig.params = {
			councilCode,
			sheet,
			parcelCode,
			engagement,
			cropCode,
			nextKey,
		};
		removeNullsOrBlanksFromObject(requestConfig.params);

		return http.getJson(
			OptionDetailsInfiniteListSchema,
			`/application-forms/{TENANT}/api-priv/v1/applications/{APPLICATION_ID}/options/${optionCode}/areas`,
			requestConfig
		);
	}
};

export const loadPrizesChoice = async (): Promise<
	HttpJsonResult<PrizesChoiceListModel>
> => {
	return http.getJson(
		PrizesChoiceListSchema,
		`/application-forms/{TENANT}/api-priv/v1/applications/{APPLICATION_ID}/prize-choices`
	);
};

export const loadPrizesChoiceV2 = async (): Promise<
	HttpJsonResult<PrizesChoiceListModel>
> => {
	return http.getJson(
		PrizesChoiceListSchema,
		`/application-forms/{TENANT}/api-priv/v2/applications/{APPLICATION_ID}/prize-choices`
	);
};

export const savePrizesChoice = async (
	choices: SavePrizesChoiceListModel,
	compileStatusIdentifier: string
): Promise<HttpResult> => {
	const requestConfig = {
		params: {
			compileStatusIdentifier: compileStatusIdentifier,
		},
		headers: {
			"Content-Type": "application/json",
		},
	};
	removeNullsOrBlanksFromObject(requestConfig.params);
	return await http.post(
		`/application-forms/{TENANT}/api-priv/v1/applications/{APPLICATION_ID}/prize-choices`,
		JSON.stringify(choices),
		requestConfig
	);
};

export const loadYoungFarmerDataAPI = async (
	compileStatusIdentifier: string,
	dynamicDocumentCode: string
): Promise<HttpJsonResult<YoungFarmerModel>> => {
	const requestConfig = {
		params: {
			compileStatusIdentifier: compileStatusIdentifier,
		},
		headers: {
			"Content-Type": "application/json",
		},
	};
	removeNullsOrBlanksFromObject(requestConfig.params);

	return http.getJson(
		YoungFarmerModelSchema,
		`/application-forms/{TENANT}/api-priv/v1/applications/{APPLICATION_ID}/declarations/${dynamicDocumentCode}/young-farmer`
	);
};

export const saveYoungFarmerDataAPI = async (
	compileStatusIdentifier: string,
	dynamicDocumentCode: string,
	youngFarmerData: SaveYoungFarmerDataModel
): Promise<HttpJsonResult<SaveYoungFarmerDataModel>> => {
	const requestConfig: RequestConfig = {};
	requestConfig.params = {
		compileStatusIdentifier: compileStatusIdentifier,
	};
	removeNullsOrBlanksFromObject(requestConfig.params);

	return http.postJson(
		SaveYoungFarmerDataSchema,
		`/application-forms/{TENANT}/api-priv/v1/applications/{APPLICATION_ID}/declarations/${dynamicDocumentCode}/young-farmer`,
		youngFarmerData,
		requestConfig
	);
};

export const loadStandardZootechnicsListAPI = async (
	formCode: string,
	compileStatusIdentifier: string
): Promise<HttpJsonResult<ZootechnicsOptionListModel>> => {
	const requestConfig = {
		params: {
			compileStatusIdentifier: compileStatusIdentifier,
		},
		headers: {
			"Content-Type": "application/json",
		},
	};
	removeNullsOrBlanksFromObject(requestConfig.params);

	return http.getJson(
		ZootechnicsOptionListSchema,
		`/application-forms/{TENANT}/api-priv/v1/applications/{APPLICATION_ID}/forms/${formCode}/zootechnics/options`,
		requestConfig
	);
};

export const loadStandardZootechnicsDeclarationsListAPI = async (
	formCode: string,
	compileStatusIdentifier: string,
	optionCode: string,
	nextKey?: string | null
): Promise<HttpJsonResult<ZootechnicsDeclarationsListResponse>> => {
	const requestConfig: RequestConfig = {};
	requestConfig.params = {
		formCode,
		compileStatusIdentifier,
		nextKey,
	};

	removeNullsOrBlanksFromObject(requestConfig.params);

	return http.getJson(
		ZootechnicsDeclarationsListResponseSchema,
		`/application-forms/{TENANT}/api-priv/v1/applications/{APPLICATION_ID}/zootechnics/options/${optionCode}/breedings`,
		requestConfig
	);
};

export const saveSelectedOptionsCommitmentZootechnicsAPI = async (
	engagementArray: SaveEngagementZootechnicsModel,
	compileStatusIdentifier: string,
	formCode: string,
	action?: "ENGAGE_ALL" | "DISENGAGE_ALL"
): Promise<HttpJsonResult<ZootechnicsDeclarationsListResponse>> => {
	const requestConfig: RequestConfig = {};
	requestConfig.params = {
		compileStatusIdentifier,
		action,
	};
	removeNullsOrBlanksFromObject(requestConfig.params);
	return http.postJson(
		ZootechnicsDeclarationsListResponseSchema,
		`/application-forms/{TENANT}/api-priv/v1/applications/{APPLICATION_ID}/zootechnics/forms/${formCode}/options`,
		engagementArray,
		requestConfig
	);
};

export const loadSurfacesFiltersAPI = async (
	optionCode: string,
	councilCode?: string,
	sheet?: string,
	parcelCode?: string
): Promise<HttpJsonResult<TerritoryFiltersModel>> => {
	const requestConfig: RequestConfig = {};
	requestConfig.params = {
		councilCode,
		sheet,
		parcelCode,
	};
	removeNullsOrBlanksFromObject(requestConfig.params);
	return http.getJson(
		TerritoryFiltersSchema,
		`/application-forms/{TENANT}/api-priv/v1/applications/{APPLICATION_ID}/options/${optionCode}/territory-filters`,
		requestConfig
	);
};

export const saveUnifiedDeclarationsAPI = async (
	document_code: string,
	unifiedDeclarations: SaveUnifiedDeclarationsModel,
	compileStatusIdentifier: string
): Promise<HttpJsonResult<SaveUnifiedDeclarationsModel>> => {
	const requestConfig: RequestConfig = {};
	requestConfig.params = {
		compileStatusIdentifier,
		compileStatus: "COMPLETED",
	};
	return http.postJson(
		SaveUnifiedDeclarationsSchema,
		`/application-forms/{TENANT}/api-priv/v1/applications/{APPLICATION_ID}/declarations/${document_code}`,
		unifiedDeclarations,
		requestConfig
	);
};

export const loadUnifiedDeclarationsAPI = async (
	dynamic_document_code: string
): Promise<HttpJsonResult<UnifiedDeclarationListResponse>> => {
	return http.getJson(
		UnifiedDeclarationListResponseSchema,
		`/application-forms/{TENANT}/api-priv/v1/applications/{APPLICATION_ID}/declarations/${dynamic_document_code}`
	);
};

export const loadAdditionalDeclarationsAPI = async (
	dynamic_document_code: string
): Promise<HttpJsonResult<AdditionalDeclarationsModel>> => {
	return http.getJson(
		AdditionalDeclarationsSchema,
		`/application-forms/{TENANT}/api-priv/v1/applications/{APPLICATION_ID}/declarations/${dynamic_document_code}`
	);
};

export const saveAdditionalDeclarationsAPI = async (
	form_code: string,
	document_code: string,
	option_code: string,
	additionalDeclaration: SaveAdditionalDeclarationsModel,
	compileStatusIdentifier: string,
	parentForm?: string,
	takeoverId?: number
): Promise<HttpResult> => {
	const requestConfig = {
		params: {
			compileStatusIdentifier: compileStatusIdentifier,
			takeover_id: takeoverId,
		},
		headers: {
			"Content-Type": "application/json",
		},
	};
	removeNullsOrBlanksFromObject(requestConfig.params);

	return http.post(
		`/application-forms/{TENANT}/api-priv/v1/applications/{APPLICATION_ID}/forms/${form_code}/options/${option_code}${
			parentForm === "zootechnics" ? "/zootechnics/" : "/"
		}additional-declarations/${document_code}`,
		JSON.stringify(additionalDeclaration),
		requestConfig
	);
};

export const saveAdditionalDeclarationsV2API = async (
	form_code: string,
	document_code: string,
	option_code: string,
	additionalDeclaration: SaveAdditionalDeclarationsModel,
	compileStatusIdentifier: string,
	takeoverId?: number
): Promise<HttpResult> => {
	const requestConfig = {
		params: {
			compileStatusIdentifier: compileStatusIdentifier,
			takeover_id: takeoverId,
		},
		headers: {
			"Content-Type": "application/json",
		},
	};
	removeNullsOrBlanksFromObject(requestConfig.params);

	return http.post(
		`/application-forms/{TENANT}/api-priv/v1/applications/{APPLICATION_ID}/confirmation-applications/forms/${form_code}/options/${option_code}/zootechnics/additional-declarations/${document_code}`,
		JSON.stringify(additionalDeclaration),
		requestConfig
	);
};

export const loadConfirmationApplicationListAPI = async (
	formCode: string,
	geometryType?: string
): Promise<HttpJsonResult<ConfirmationApplicationListModel>> => {
	const requestConfig: RequestConfig = {};
	requestConfig.params = {
		form_code: formCode,
		geometry_type: geometryType,
	};
	removeNullsOrBlanksFromObject(requestConfig.params);
	return http.getJson(
		ConfirmationApplicationListSchema,
		`/application-forms/{TENANT}/api-priv/v1/applications/{APPLICATION_ID}/confirmation-applications`,
		requestConfig
	);
};

export const loadParties = async (
	cuaa?: string | null,
	partyDesc?: string | null,
	nextKey?: string | null
): Promise<HttpJsonResult<PartyListModel>> => {
	const requestConfig: RequestConfig = {};
	requestConfig.params = {
		search_code: cuaa && cuaa.replace(/-/g, ""),
		search_description: partyDesc,
		next_key: nextKey,
	};
	removeNullsOrBlanksFromObject(requestConfig.params);

	return http.getJson(
		PartyListModelSchema,
		`/avepa-legacy/{TENANT}/public/v1/parties/directory`,
		requestConfig
	);
};

export const loadTakeOverListAPI = async (
	cuaa: string,
	partyId?: number,
	optionCode?: string
): Promise<HttpJsonResult<TakeOverListModel>> => {
	const requestConfig: RequestConfig = {};
	requestConfig.params = {
		cuaa: cuaa,
		party_id: partyId,
		option_code: optionCode,
	};

	removeNullsOrBlanksFromObject(requestConfig.params);

	return http.getJson(
		TakeOverListSchema,
		`/application-forms/{TENANT}/api-priv/v1/applications/{APPLICATION_ID}/confirmation-applications/possible-takeovers`,
		requestConfig
	);
};

export const saveTakeOverListAPI = async (
	form_code: string,
	compileStatusIdentifier: string,
	takeOverList: SaveTakeOverListModel,
	partyId?: number
): Promise<HttpJsonResult<SaveTakeOverListModel>> => {
	const requestConfig: RequestConfig = {};
	requestConfig.params = {
		compile_status_identifier: compileStatusIdentifier,
		party_id: partyId,
	};

	removeNullsOrBlanksFromObject(requestConfig.params);

	return http.postJson(
		SaveTakeOverListSchema,
		`/application-forms/{TENANT}/api-priv/v1/applications/{APPLICATION_ID}/confirmation-applications/forms/${form_code}/takeovers`,
		takeOverList,
		requestConfig
	);
};

export const deleteConfirmationApplicationInterventionAPI = async (
	optionCode: string,
	formCode: string,
	takeoverId: number,
	takeOverApplicationCode: string,
	compileStatusIdentifier: string
): Promise<HttpResult> => {
	const requestConfig: RequestConfig = {};
	requestConfig.params = {
		takeover_application_code: takeOverApplicationCode,
		compile_status_identifier: compileStatusIdentifier,
	};

	return http.delete(
		`/application-forms/{TENANT}/api-priv/v1/applications/{APPLICATION_ID}/confirmation-applications/forms/${formCode}/options/${optionCode}/takeovers/${takeoverId}`,
		requestConfig
	);
};

export const loadZootechnicInterventionListAPI = async (
	formCode: string,
	optionCode: string,
	breedingCode?: string,
	earTag?: string,
	subCodSpecies?: string,
	takeoverId?: number,
	nextKey?: string | null
): Promise<HttpJsonResult<ZootechnicInterventionResponseModel>> => {
	const requestConfig: RequestConfig = {};
	requestConfig.params = {
		breeding_code: breedingCode,
		ear_tag: earTag,
		sub_cod_species: subCodSpecies,
		takeover_id: takeoverId,
		next_key: nextKey,
	};

	removeNullsOrBlanksFromObject(requestConfig.params);

	return http.getJson(
		ZootechnicInterventionResponseSchema,
		`/application-forms/{TENANT}/api-priv/v1/applications/{APPLICATION_ID}/confirmation-applications/forms/${formCode}/options/${optionCode}/zootechnic-options`,
		requestConfig
	);
};

export const loadZootechnicAllConfirmedAPI = async (
	formCode: string,
	optionCode: string,
	takeoverId?: number
): Promise<HttpJsonResult<FlAllConfirmedModel>> => {
	const requestConfig: RequestConfig = {};
	requestConfig.params = {
		takeover_id: takeoverId,
	};
	removeNullsOrBlanksFromObject(requestConfig.params);
	return http.getJson(
		FlAllConfirmedSchema,
		`/application-forms/{TENANT}/api-priv/v1/applications/{APPLICATION_ID}/confirmation-applications/forms/${formCode}/options/${optionCode}/zootechnic-options/check-all-selected`,
		requestConfig
	);
};

export const loadSupportZootechnicInterventionListAPI = async (
	formCode: string,
	optionCode: string,
	breedingCode?: string,
	earTag?: string,
	subCodSpecies?: string,
	takeoverId?: number,
	nextKey?: string | null
): Promise<HttpJsonResult<ZootechnicInterventionResponseModel>> => {
	const requestConfig: RequestConfig = {};
	requestConfig.params = {
		breeding_code: breedingCode,
		ear_tag: earTag,
		sub_cod_species: subCodSpecies,
		takeover_id: takeoverId,
		next_key: nextKey,
	};

	removeNullsOrBlanksFromObject(requestConfig.params);

	return http.getJson(
		ZootechnicInterventionResponseSchema,
		`/application-forms/{TENANT}/api-priv/v1/applications/{APPLICATION_ID}/rdp/forms/${formCode}/options/${optionCode}/zootechnic-options`,
		requestConfig
	);
};

export const loadReplacementOrWaiverSurfaceAPI = async (
	optionCode: string,
	formCode: string,
	takeoverId?: number
): Promise<HttpJsonResult<ReplacementOrWaiverSurfaceListModel>> => {
	const requestConfig: RequestConfig = {};
	requestConfig.params = {
		takeover_id: takeoverId,
	};
	removeNullsOrBlanksFromObject(requestConfig.params);

	// return standardMockResponse([
	//   {
	//     previousClaimPolygonId: 0,
	//     parcelCode: null,
	//     area: 0,
	//     withdrawnReasonCode: null,
	//     withdrawnReasonDescription: null,
	//     waiveredGeometry: {
	//       geometry:
	//         "POLYGON ((1243111.04000969 5708338.23356495, 1235490.45178413 5714460.2187216, 1224412.41800611 5717085.07851381, 1224412.41800611 5707085.07851381))",
	//       srs: "srs",
	//     },
	//     previousApplicationGeometry: {
	//       geometry:
	//         "POLYGON ((1245111.04000969 5708338.23356495, 1234412.41800611 5717085.07851381, 1244490.45178413 5714460.2187216))",
	//       srs: "srs",
	//     },
	//     currentCropPlanGeometry: {
	//       geometry:
	//         "POLYGON ((1245490.45178413 5714460.21872196, 1245534.62192769 5712884.20318376, 1245622.3938412 5712485.27800462, 1246290.53395084 5711938.76151696, 1246310.97030718 5709910.18236452, 1247375.6148013 5709613.28106124, 1247528.76466802 5709171.18145516, 1247869.42573309 5709014.38969025, 1248592.48549297 5709007.25698755, 1249645.72346231 5708568.7761297, 1249755.04000969 5708338.23356495, 1249790.24080354 5708740.74654236, 1250562.2347667 5708968.90098583, 1251283.48424893 5709511.79571367, 1251628.73862239 5710186.86503353, 1251909.65614877 5711257.3669874, 1251750.2101705 5711473.67424147, 1251937.91131431 5711707.43095668, 1251951.66145812 5712857.90786413, 1251743.21831202 5713722.71334655, 1251495.91069375 5713802.66993015, 1251687.89193618 5714501.6871162, 1251091.4136063 5714554.21100494, 1251098.30337507 5714949.19877132, 1250376.9288622 5714937.87852342, 1250392.06298519 5715271.0815452, 1250683.85856356 5715499.9067327, 1250050.78530426 5715682.98167395, 1250590.53786385 5715839.74317539, 1250766.90070521 5716484.95554986, 1250081.40715338 5716787.66998458, 1249242.65421197 5716653.50286249, 1248812.41800611 5717085.07851381, 1248681.81512794 5717842.78104492, 1248539.28029515 5718472.67515583, 1248256.61363896 5718479.79503236, 1248327.6492893 5718979.18293475, 1248113.35480788 5719285.94702135, 1248308.76782703 5720523.34287434, 1247149.84486227 5720650.66784973, 1247017.36096182 5720297.57340551, 1245987.58025558 5719655.42793164, 1246038.51297017 5719062.38780984, 1245796.79061546 5718640.71434408, 1246423.12126125 5717520.60908952, 1246523.3532867 5716904.86878154, 1246463.15892852 5715589.7528435, 1246020.41104011 5715323.40575548, 1245490.45178413 5714460.21872196, 1245490.45178413 5714460.21872196))",
	//       srs: "srs",
	//     },
	//     cropPlanVersion: "00CP1",
	//   },
	//   {
	//     previousClaimPolygonId: 1,
	//     parcelCode: null,
	//     area: 1,
	//     withdrawnReasonCode: null,
	//     withdrawnReasonDescription: null,
	//     waiveredGeometry: {
	//       geometry:
	//         "POLYGON ((1243311.04000969 5708538.23356495, 1235690.45278413 5714660.2191216, 1227412.41800611 5718085.07871381, 1227412.41800611 5707085.07831381))",
	//       srs: "srs",
	//     },
	//     previousApplicationGeometry: {
	//       geometry:
	//         "POLYGON ((1245111.04000969 5708338.23356495, 1234412.41800611 5717085.07851381, 1244490.45178413 5714460.2187216))",
	//       srs: "srs",
	//     },
	//     currentCropPlanGeometry: {
	//       geometry:
	//         "POLYGON ((1245490.45178413 5714460.21872196, 1245534.62192769 5712884.20318376, 1245622.3938412 5712485.27800462, 1246290.53395084 5711938.76151696, 1246310.97030718 5709910.18236452, 1247375.6148013 5709613.28106124, 1247528.76466802 5709171.18145516, 1247869.42573309 5709014.38969025, 1248592.48549297 5709007.25698755, 1249645.72346231 5708568.7761297, 1249755.04000969 5708338.23356495, 1249790.24080354 5708740.74654236, 1250562.2347667 5708968.90098583, 1251283.48424893 5709511.79571367, 1251628.73862239 5710186.86503353, 1251909.65614877 5711257.3669874, 1251750.2101705 5711473.67424147, 1251937.91131431 5711707.43095668, 1251951.66145812 5712857.90786413, 1251743.21831202 5713722.71334655, 1251495.91069375 5713802.66993015, 1251687.89193618 5714501.6871162, 1251091.4136063 5714554.21100494, 1251098.30337507 5714949.19877132, 1250376.9288622 5714937.87852342, 1250392.06298519 5715271.0815452, 1250683.85856356 5715499.9067327, 1250050.78530426 5715682.98167395, 1250590.53786385 5715839.74317539, 1250766.90070521 5716484.95554986, 1250081.40715338 5716787.66998458, 1249242.65421197 5716653.50286249, 1248812.41800611 5717085.07851381, 1248681.81512794 5717842.78104492, 1248539.28029515 5718472.67515583, 1248256.61363896 5718479.79503236, 1248327.6492893 5718979.18293475, 1248113.35480788 5719285.94702135, 1248308.76782703 5720523.34287434, 1247149.84486227 5720650.66784973, 1247017.36096182 5720297.57340551, 1245987.58025558 5719655.42793164, 1246038.51297017 5719062.38780984, 1245796.79061546 5718640.71434408, 1246423.12126125 5717520.60908952, 1246523.3532867 5716904.86878154, 1246463.15892852 5715589.7528435, 1246020.41104011 5715323.40575548, 1245490.45178413 5714460.21872196, 1245490.45178413 5714460.21872196))",
	//       srs: "srs",
	//     },
	//     cropPlanVersion: "00CP1",
	//   },
	// ]);

	return http.getJson(
		ReplacementOrWaiverSurfaceListSchema,
		`/application-forms/{TENANT}/api-priv/v1/applications/{APPLICATION_ID}/confirmation-applications/forms/${formCode}/options/${optionCode}/withdrawn-surface`,
		requestConfig
	);
};

export const saveReplacementOrWaiverSurfaceAPI = async (
	optionCode: string,
	formCode: string,
	compileStatusIdentifier: string,
	saveList: SaveReplacementOrWaiverSurfaceModel,
	takeoverId?: number
): Promise<HttpJsonResult<SaveReplacementOrWaiverSurfaceResponseModel>> => {
	const requestConfig: RequestConfig = {};
	requestConfig.params = {
		takeover_id: takeoverId,
		compile_status_identifier: compileStatusIdentifier,
	};

	removeNullsOrBlanksFromObject(requestConfig.params);

	return http.postJson(
		SaveReplacementOrWaiverSurfaceResponseSchema,
		`/application-forms/{TENANT}/api-priv/v1/applications/{APPLICATION_ID}/confirmation-applications/forms/${formCode}/options/${optionCode}/withdrawn-surface`,
		saveList,
		requestConfig
	);
};

export const loadReplacementOrWaiverWithdrawnReasonAPI = async (): Promise<
	HttpJsonResult<ReplacementOrWaiverWithdrawnReasonListModel>
> => {
	return http.getJson(
		ReplacementOrWaiverWithdrawnReasonListSchema,
		`/application-forms/{TENANT}/api-priv/v1/applications/{APPLICATION_ID}/confirmation-applications/withdraw-reasons`
	);
};

export const loadReplaceOrWaiverLivestockListAPI = async (
	optionCode: string,
	formCode: string,
	takeoverId?: number
): Promise<HttpJsonResult<LivestockListModel>> => {
	const requestConfig: RequestConfig = {};
	requestConfig.params = {
		takeover_id: takeoverId,
	};

	removeNullsOrBlanksFromObject(requestConfig.params);

	return http.getJson(
		LivestockListSchema,
		`/application-forms/{TENANT}/api-priv/v1/applications/{APPLICATION_ID}/confirmation-applications/forms/${formCode}/options/${optionCode}/zootechnic-takeovers`,
		requestConfig
	);
};

export const loadReplaceLivestockListAPI = async (
	optionCode: string,
	formCode: string,
	nextKey: string | null,
	takeoverId: number | null,
	earTag: string | null,
	aslCode: string | null
): Promise<HttpJsonResult<ReplaceLivestockResponseModel>> => {
	const requestConfig: RequestConfig = {};
	requestConfig.params = {
		takeover_id: takeoverId,
		ear_tag: earTag,
		asl_code: aslCode,
		next_key: nextKey,
	};

	removeNullsOrBlanksFromObject(requestConfig.params);

	return http.getJson(
		ReplaceLivestockResponseSchema,
		`/application-forms/{TENANT}/api-priv/v1/applications/{APPLICATION_ID}/confirmation-applications/forms/${formCode}/options/${optionCode}/zootechnic-takeovers/cattles`,
		requestConfig
	);
};

export const loadHelpApplicationListAPI = async (
	formCode: string,
	compileStatusIdentifier: string
): Promise<HttpJsonResult<SupportOptionsListModel>> => {
	const requestConfig: RequestConfig = {};
	requestConfig.params = {
		compile_status_identifier: compileStatusIdentifier,
	};

	return http.getJson(
		SupportOptionsListSchema,
		`/application-forms/{TENANT}/api-priv/v1/applications/{APPLICATION_ID}/rdp/forms/${formCode}/options`,
		requestConfig
	);
};

export const saveReplaceOrWaiverLivestockListAPI = async (
	optionCode: string,
	formCode: string,
	list: SaveLivestockReplacementListModel,
	compileStatusIdentifier: string,
	takeoverId?: number
): Promise<HttpJsonResult<SaveLivestockReplacementListModel>> => {
	const requestConfig: RequestConfig = {};
	requestConfig.params = {
		takeover_id: takeoverId,
		compile_status_identifier: compileStatusIdentifier,
	};
	removeNullsOrBlanksFromObject(requestConfig.params);

	return http.postJson(
		saveLivestockReplacementListSchema,
		`/application-forms/{TENANT}/api-priv/v1/applications/{APPLICATION_ID}/confirmation-applications/forms/${formCode}/options/${optionCode}/zootechnic-takeovers/cattles`,
		list,
		requestConfig
	);
};

export const loadStandardDetailsAPI = async (
	optionCode: string,
	formCode: string,
	takeoverId?: number
): Promise<HttpJsonResult<StandardDetailsModel>> => {
	const requestConfig: RequestConfig = {};
	requestConfig.params = {
		takeover_id: takeoverId,
	};
	removeNullsOrBlanksFromObject(requestConfig.params);

	return http.getJson(
		StandardDetailsSchema,
		`/application-forms/{TENANT}/api-priv/v1/applications/{APPLICATION_ID}/confirmation-applications/forms/${formCode}/options/${optionCode}/areas/detail`,
		requestConfig
	);
};

export const loadWithdrawnReasonListAPI = async (): Promise<
	HttpJsonResult<WithdrawnReasonListModel>
> => {
	return http.getJson(
		WithdrawReasonListSchema,
		`/application-forms/{TENANT}/api-priv/v1/applications/{APPLICATION_ID}/confirmation-applications/withdraw-reasons`
	);
};

export const saveZootechnicsInterventionListAPI = async (
	formCode: string,
	optionCode: string,
	compileStatusIdentifier: string,
	list: SaveZootechnicsInterventionListModel,
	breedingCode?: string,
	earTag?: string,
	subCodSpecies?: string,
	action?: string,
	takeoverId?: number,
	commitmentYear?: number
): Promise<HttpResult> => {
	const requestConfig: RequestConfig = {};
	requestConfig.params = {
		action: action,
		breeding_code: breedingCode,
		sub_cod_species: subCodSpecies,
		ear_tag: earTag,
		takeover_id: takeoverId,
		compile_status_identifier: compileStatusIdentifier,
		start_year: new Date().getFullYear() - (commitmentYear ?? 0) + 1,
	};

	removeNullsOrBlanksFromObject(requestConfig.params);

	return http.postJson(
		ZootechnicInterventionResponseSchema,
		`/application-forms/{TENANT}/api-priv/v1/applications/{APPLICATION_ID}/confirmation-applications/forms/${formCode}/options/${optionCode}/zootechnic-options`,
		action ? undefined : list,
		requestConfig
	);
};

export const saveSupportZootechnicsInterventionListAPI = async (
	formCode: string,
	optionCode: string,
	compileStatusIdentifier: string,
	list: SaveZootechnicsInterventionListModel,
	breedingCode?: string,
	earTag?: string,
	subCodSpecies?: string,
	action?: string,
	takeoverId?: number
): Promise<HttpResult> => {
	const requestConfig: RequestConfig = {};
	requestConfig.params = {
		action: action,
		breeding_code: breedingCode,
		sub_cod_species: subCodSpecies,
		ear_tag: earTag,
		takeover_id: takeoverId,
		compile_status_identifier: compileStatusIdentifier,
	};

	removeNullsOrBlanksFromObject(requestConfig.params);

	return http.postJson(
		ZootechnicInterventionResponseSchema,
		`/application-forms/{TENANT}/api-priv/v1/applications/{APPLICATION_ID}/rdp/forms/${formCode}/options/${optionCode}/zootechnic-options`,
		action ? undefined : list,
		requestConfig
	);
};

export const loadZootechnicsFiltersAPI = async (
	optionCode: string,
	formCode: string,
	zootechnicsBreedingCode?: string,
	subCodSpecies?: string,
	takeoverId?: number
): Promise<HttpJsonResult<ZootechnicFiltersModel>> => {
	const requestConfig: RequestConfig = {};
	requestConfig.params = {
		zootechnics_breeding_code: zootechnicsBreedingCode,
		sub_cod_species: subCodSpecies,
		takeover_id: takeoverId,
	};
	removeNullsOrBlanksFromObject(requestConfig.params);
	return http.getJson(
		ZootechnicFiltersSchema,
		`/application-forms/{TENANT}/api-priv/v1/applications/{APPLICATION_ID}/confirmation-applications/forms/${formCode}/options/${optionCode}/zootechnic-options/zootechnic-filters`,
		requestConfig
	);
};

export const loadSupportZootechnicsFiltersAPI = async (
	optionCode: string,
	formCode: string,
	zootechnicsBreedingCode?: string,
	subCodSpecies?: string,
	takeoverId?: number
): Promise<HttpJsonResult<ZootechnicFiltersModel>> => {
	const requestConfig: RequestConfig = {};
	requestConfig.params = {
		zootechnics_breeding_code: zootechnicsBreedingCode,
		sub_cod_species: subCodSpecies,
		takeover_id: takeoverId,
	};
	removeNullsOrBlanksFromObject(requestConfig.params);
	return http.getJson(
		ZootechnicFiltersSchema,
		`/application-forms/{TENANT}/api-priv/v1/applications/{APPLICATION_ID}/rdp/forms/${formCode}/options/${optionCode}/zootechnic-options/zootechnic-filters`,
		requestConfig
	);
};

export const loadZootechnicInterventionSummaryAPI = async (
	optionCode: string,
	formCode: string,
	takeoverId?: number
): Promise<HttpJsonResult<ZootechnicInterventionSummaryModel>> => {
	const requestConfig: RequestConfig = {};
	requestConfig.params = {
		takeover_id: takeoverId,
	};
	removeNullsOrBlanksFromObject(requestConfig.params);

	return http.getJson(
		ZootechnicInterventionSummarySchema,
		`/application-forms/{TENANT}/api-priv/v1/applications/{APPLICATION_ID}/confirmation-applications/forms/${formCode}/options/${optionCode}/zootechnic-options/detail`,
		requestConfig
	);
};

export const loadSelectBreedingsListAPI = async (
	form_code: string,
	option_code: string,
	nextKey?: string | null
): Promise<HttpJsonResult<SelectBreedingsListResponse>> => {
	const requestConfig: RequestConfig = {};
	requestConfig.params = {
		nextKey,
	};

	removeNullsOrBlanksFromObject(requestConfig.params);

	return http.getJson(
		SelectBreedingsListResponseSchema,
		`/application-forms/{TENANT}/api-priv/v1/applications/{APPLICATION_ID}/rdp/forms/${form_code}/options/${option_code}/breedings`,
		requestConfig
	);
};

export const saveSelectBreedingsListAPI = async (
	form_code: string,
	compileStatusIdentifier: string,
	list: SaveSelectBreedingsListModel,
	action?: string
): Promise<HttpJsonResult<SelectBreedingsListResponse>> => {
	const requestConfig: RequestConfig = {};
	requestConfig.params = {
		output_mode: "DETAIL",
		action: action,
		compile_status_identifier: compileStatusIdentifier,
	};

	removeNullsOrBlanksFromObject(requestConfig.params);

	return http.postJson(
		SelectBreedingsListResponseSchema,
		`/application-forms/{TENANT}/api-priv/v1/applications/{APPLICATION_ID}/rdp/forms/${form_code}/breedings`,
		list,
		requestConfig
	);
};

export const loadAdditionalLayersAPI = async (
	moduleId: string,
	srs: string
): Promise<HttpJsonResult<AdditionalLayersModel>> => {
	const requestConfig: RequestConfig = {};
	requestConfig.params = {
		module: moduleId,
		srs: srs,
	};
	removeNullsOrBlanksFromObject(requestConfig.params);

	return http.getJson(
		AdditionalLayersSchema,
		`/lpis-server-api/{TENANT}/public/v1/lpis/support/additional-layers`,
		requestConfig
	);
};

export const loadConfirmationSurfacesOptionDetailsAPI = async (
	optionCode: string,
	formCode: string,
	nextKey?: string | null,
	councilCode?: string,
	sheet?: string,
	parcelCode?: string,
	engagement?: string,
	cropCode?: string,
	takeoverId?: number
): Promise<HttpJsonResult<OptionDetailsInfiniteListModel>> => {
	const requestConfig: RequestConfig = {};
	if (nextKey === undefined) {
		requestConfig.params = {
			takeover_id: takeoverId,
		};
		removeNullsOrBlanksFromObject(requestConfig.params);
		return http.getJson(
			OptionDetailsInfiniteListSchema,
			`/application-forms/{TENANT}/api-priv/v1/applications/{APPLICATION_ID}/confirmation-applications/forms/${formCode}/options/${optionCode}/crops`,
			requestConfig
		);
	} else {
		requestConfig.params = {
			council_code: councilCode,
			sheet: sheet,
			parcel_code: parcelCode,
			engagement: engagement,
			crop_code: cropCode,
			takeover_id: takeoverId,
			next_key: nextKey,
		};
		removeNullsOrBlanksFromObject(requestConfig.params);
		return http.getJson(
			OptionDetailsInfiniteListSchema,
			`/application-forms/{TENANT}/api-priv/v1/applications/{APPLICATION_ID}/confirmation-applications/forms/${formCode}/options/${optionCode}/areas`,
			requestConfig
		);
	}
};

export const saveConfirmationSelectedOptionsCommitmentAPI = async (
	engagementArray: SaveEngagementArrayModel,
	compileStatusIdentifier: string,
	formCode: string,
	action?: string,
	takeover_id?: number
): Promise<HttpJsonResult<OptionDetailsListModel | undefined>> => {
	const requestConfig: RequestConfig = {};
	requestConfig.params = {
		action: action,
		compile_status_identifier: compileStatusIdentifier,
		takeover_id,
	};
	removeNullsOrBlanksFromObject(requestConfig.params);
	return http.postJson(
		z.optional(OptionDetailsListSchema),
		`/application-forms/{TENANT}/api-priv/v1/applications/{APPLICATION_ID}/confirmation-applications/forms/${formCode}/options`,
		engagementArray,
		requestConfig
	);
};

export const loadScoreCardDefinitionAPI = async (
	option_code: string
): Promise<HttpJsonResult<ScoreCardDefinitionModel>> => {
	return http.getJson(
		ScoreCardDefinitionSchema,
		`/application-forms/{TENANT}/api-priv/v1/applications/{APPLICATION_ID}/options/${option_code}/scores`
	);
};

export const saveScoreCardAPI = async (
	option_code: string,
	choicesList: SaveScoreCardModel,
	compileStatusIdentifier: string,
	formCode: string
): Promise<HttpJsonResult<ScoreCardDefinitionModel>> => {
	const requestConfig: RequestConfig = {};
	requestConfig.params = {
		compile_status_identifier: compileStatusIdentifier,
		form_code: formCode,
	};

	return http.postJson(
		ScoreCardDefinitionSchema,
		`/application-forms/{TENANT}/api-priv/v1/applications/{APPLICATION_ID}/options/${option_code}/scores`,
		choicesList,
		requestConfig
	);
};

export const loadPSRApplicationsAPI = async (): Promise<
	HttpJsonResult<PsrApplicationsModel>
> => {
	return http.getJson(
		PsrApplicationsSchema,
		`/application-forms/{TENANT}/api-priv/v1/applications/splitted-psr/{APPLICATION_ID}`
	);
};

export const loadWithdrawalApplicationAPI = async (): Promise<
	HttpJsonResult<WithdrawalApplicationListModel>
> => {
	return http.getJson(
		WithdrawalApplicationListSchema,
		`/application-forms/{TENANT}/api-priv/v1/applications/{APPLICATION_ID}/waiver/summary`
	);
};

export const loadWithdrawalApplicationDetailsAPI = async (
	withdrawed_application_id: number
): Promise<HttpJsonResult<WithdrawalApplicationDetailsModel>> => {
	return http.getJson(
		WithdrawalApplicationDetailsSchema,
		`/application-forms/{TENANT}/api-priv/v1/applications/{APPLICATION_ID}/waiver/${withdrawed_application_id}`
	);
};

export const loadWithdrawalApplicationSummaryAPI = async (
	withdrawed_application_id: number
): Promise<HttpJsonResult<WithdrawalApplicationSummaryListModel>> => {
	return http.getJson(
		WithdrawalApplicationSummaryListSchema,
		`/application-forms/{TENANT}/api-priv/v1/applications/{APPLICATION_ID}/waiver/${withdrawed_application_id}/options`
	);
};

export const loadSurfaceDetailApi = async (
	form_code: string,
	option_code: string
): Promise<HttpJsonResult<Array<SurfaceDetailModel>>> => {
	return http.getJson(
		SurfaceDetailListSchema,
		`/application-forms/{TENANT}/api-priv/v1/applications/{APPLICATION_ID}/forms/${form_code}/${option_code}/surface`
	);
};
