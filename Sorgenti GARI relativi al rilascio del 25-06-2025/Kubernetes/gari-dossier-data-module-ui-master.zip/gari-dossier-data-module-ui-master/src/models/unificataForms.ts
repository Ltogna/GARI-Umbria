import { z } from "zod";
import {
	DeclarationDocumentSchema,
	DeclarationListResponseSchema,
} from "./applicationForms";
import {
	DocumentDataDocSchema,
	DocumentSchema,
} from "@abaco/dynamic-documents/src";
import { MonitoringResultFlagColorCodes } from "./resource";
import { DateSchema } from "@abaco/safe-rest/src/Schemas";

export enum OptionType {
	ZOOTECHNIC = "ZOOTECHNIC",
	SURFACE = "SURFACE",
}

export interface ErrorRequirementsInformations {
	errorCode: string;
	message: string;
	options: [
		{
			optionCode1: string;
			optionDescription1: string;
			optionCode2: string;
			optionDescription2: string;
		},
	];
}

export const AdditionalDeclarationsSchema = z.object({
	documentDefinition: z.nullable(DocumentSchema),
	document: z.nullable(DocumentDataDocSchema),
	flMandatory: z.optional(z.boolean()),
});

export const OptionSchema = z.object({
	optionCode: z.string(),
	optionDescription: z.string(),
	optionMinimumRequestableArea: z.number(),
	requestableArea: z.number(),
	engagedArea: z.nullable(z.number()),
	flSelected: z.nullable(z.boolean()),
	additionalDeclaration: z.nullable(AdditionalDeclarationsSchema),
	gsaaFlag: z.nullable(z.boolean()),
	isMultyEligibility: z.nullable(z.boolean()).optional(),
	waivedArea: z.optional(z.nullable(z.number())),
	showWaivedArea: z.optional(z.nullable(z.boolean())),
	showSurfaceDetail: z.optional(z.nullable(z.boolean())),
	waiverAdditionalDeclaration: z.optional(
		z.nullable(AdditionalDeclarationsSchema)
	),
	areaToConfirm: z.number().nullish(),
});
export const OptionsListSchema = z.array(OptionSchema);

export const saveAdditionalDeclarationsSchema = z.object({
	document: DocumentDataDocSchema,
});

export const RelatedOptionsSchema = z.array(
	z.object({
		optionCode1: z.string(),
		optionDescription1: z.string(),
		optionCode2: z.string(),
		optionDescription2: z.string(),
	})
);

export const YoungFarmerRoleSchema = z.object({
	frnCode: z.string(),
	codRole: z.string().nullable(),
	descRole: z.string(),
	codFarmerType: z.string(),
	descFarmerType: z.string(),
});

export const YoungFarmerModelSchema = z.nullable(
	z.object({
		yfData: z.object({
			businessRegisterExemption: z.boolean(),
			registrationDate: z.nullable(z.string()),
			startDate: z.nullable(z.string()),
			businessCode: z.nullable(z.string()),
			role: z.nullable(z.string()),
			firstSettlementDate: z.string().nullable().optional(),
			etrpBirthDate: z.nullable(z.string()),
			choosenFrnCode: z.nullable(z.string()),
			adhesionType: z.string(),
			roleList: z.array(YoungFarmerRoleSchema),
		}),
		declarations: DeclarationListResponseSchema,
		referredYear: z.number(),
	})
);

export const PrizesChoiceSchema = z.object({
	groupCode: z.string(),
	groupDescription: z.string(),
	prizeCode: z.string(),
	prizeTitle: z.string(),
	prizeDescription: z.nullable(z.string()),
	value: z.nullable(z.boolean()),
	readOnly: z.boolean().nullish(),
});

export const PrizesChoiceListSchema = z.array(PrizesChoiceSchema);

export const SavePrizesChoiceSchema = z.array(
	z.object({
		prizeCode: z.string(),
		value: z.boolean(),
	})
);

export const MonitoringDataSchema = z.object({
	monitoringDate: DateSchema,
	monitoringResult: MonitoringResultFlagColorCodes,
	description: z.string(),
});

export const OptionDetailDeclarationGeomSchema = z.object({
	code: z.nullable(z.number()),
	flEngaged: z.nullable(z.number()),
	geom: z.nullable(z.string()),
	engagedArea: z.nullable(z.number()),
	requestableArea: z.nullable(z.number()),
	flEligible: z.nullable(z.number()),
	monitoringData: z.optional(z.nullable(MonitoringDataSchema)),
});

export const OptionDetailsSchema = z.object({
	declarationCode: z.nullable(z.string()),
	parcelCode: z.nullable(z.string()),
	parcelCouncilCode: z.nullable(z.string()),
	parcelCouncilDescription: z.nullable(z.string()),
	parcelSheet: z.nullable(z.string()),
	cropCode: z.string(),
	cropDescription: z.string(),
	requestableArea: z.number(),
	engagedArea: z.nullable(z.number()),
	requestableLength: z.number().nullish(),
	engagedLength: z.number().nullish(),
	flFullEngagement: z.optional(z.boolean()),
	particles: z.nullable(
		z.array(
			z.object({
				councilCode: z.string().nullish(),
				councilName: z.string().nullish(),
				sheet: z.string().nullish(),
				sub: z.string().nullish(),
				particleCode: z.string().nullish(),
				requestableArea: z.number().nullish(),
			})
		)
	),
	flIsValid: z.optional(z.nullable(z.boolean())),
	warningCode: z.nullable(z.string()),
	additionalColumn: z.optional(
		z.nullable(
			z.array(
				z.object({
					paramName: z.string(),
					paramValue: z.nullable(z.string()),
					readOnly: z.boolean().nullish(),
				})
			)
		)
	),
	declarationGeomList: z.optional(
		z.nullable(z.array(OptionDetailDeclarationGeomSchema))
	),
});
export const OptionDetailsListSchema = z.array(OptionDetailsSchema);

export const OptionDetailsInfiniteListSchema = z.object({
	records: z.nullable(OptionDetailsListSchema),
	nextKey: z.nullable(z.string()),
	count: z.number(),
});

export const TerritoryFiltersSchema = z.object({
	councils: z.array(
		z.object({
			councilCode: z.string(),
			councilDescription: z.nullable(z.string()),
		})
	),
	sheets: z.array(
		z.object({
			sheetNumber: z.string(),
		})
	),
	parcels: z.array(
		z.object({
			parcelCode: z.string(),
		})
	),
	crops: z.array(
		z.object({
			cropCode: z.string(),
			cropDescription: z.string(),
		})
	),
});

export const ZootechnicFiltersSchema = z.object({
	earTagsList: z.array(
		z.object({
			earTag: z.string(),
		})
	),
	zootechnicsBreedingCodeList: z.array(
		z.object({
			zootechnicsBreedingCode: z.string(),
		})
	),
	speciesList: z.array(
		z.object({
			species: z.string(),
			subCodSpecies: z.string(),
		})
	),
});

export const ZootechnicsOptionSchema = z.object({
	optionCode: z.string(),
	optionDescription: z.string(),
	requestableZootechnicsBreedingCount: z.nullable(z.number()),
	engagedZootechnicsBreedingCount: z.nullable(z.number()),
	flSelected: z.nullable(z.boolean()),
	additionalDeclaration: z.nullable(AdditionalDeclarationsSchema),
});

export const ZootechnicsOptionListSchema = z.array(ZootechnicsOptionSchema);

export const ZootechnicsDeclarationsSchema = z.object({
	optionCode: z.string(),
	optionDescription: z.string(),
	zootechnicsBreedingCode: z.nullable(z.string()),
	zootechnicsFarmId: z.nullable(z.number()),
	zootechnicsBreedingDescription: z.nullable(z.string()),
	zootechnicsSpeciesCode: z.nullable(z.string()),
	zootechnicsSpeciesSubCode: z.nullable(z.string()),
	zootechnicsSpeciesDescription: z.nullable(z.string()),
	zootechnicsBreedingCouncilCode: z.nullable(z.string()),
	zootechnicsBreedingCouncilDescription: z.nullable(z.string()),
	zootechnicsBreedingAddress: z.nullable(z.string()),
	zootechnicsBreedingCityName: z.nullable(z.string()),
	flSelected: z.nullable(z.boolean()),
	flIsValid: z.optional(z.nullable(z.boolean())),
	warningCode: z.nullable(z.string()),
});
export const ZootechnicsDeclarationsListSchema = z.nullable(
	z.array(ZootechnicsDeclarationsSchema)
);

export const ZootechnicsDeclarationsListResponseSchema = z.object({
	records: z.nullable(z.array(ZootechnicsDeclarationsSchema)),
	nextKey: z.nullable(z.string()),
	count: z.number(),
});

export const SaveYoungFarmerDataSchema = z.nullable(
	z.object({
		document: DeclarationDocumentSchema,
		firstSettlementDate: z.nullable(z.string()),
		frnCode: z.string(),
	})
);

export const UnifiedDeclarationsSchema = z.object({
	code: z.string(),
	required: z.boolean(),
	minOccurs: z.number().optional(),
	maxOccurs: z.number().optional(),
	label: z.record(z.string()),
	type: z.string(),
	style: z.nullable(z.string()),
	help: z.nullable(z.string()),
	lookupCode: z.nullable(z.string()),
	validation: z.nullable(z.string()),
});

export const UnifiedDeclarationDocumentSchema = z.object({
	fields: z.record(z.nullable(z.number().or(z.string()))),
	validTo: z.string().or(z.number()),
	validFrom: z.string().or(z.number()),
});

export const UnifiedDeclarationListResponseSchema = z.nullable(
	z.object({
		document: z.nullable(UnifiedDeclarationDocumentSchema),
		documentDefinition: z.object({
			code: z.string(),
			version: z.string(),
			description: z.string(),
			title: z.record(z.string()),
			metadata: z.object({
				maxOccurs: z.number(),
				timeOverlap: z.boolean(),
				defaultLocale: z.string(),
				startDateField: z.string(),
				endDateField: z.string(),
				summaryFields: z.nullable(z.string()),
			}),
			fieldSets: z.array(
				z.object({
					code: z.string(),
					minOccurs: z.number(),
					maxOccurs: z.number(),
					label: z.record(z.string()),
					fields: z.array(UnifiedDeclarationsSchema),
				})
			),
		}),
	})
);

export const SaveUnifiedDeclarationsSchema = z.nullable(
	z.object({
		document: z.nullable(UnifiedDeclarationDocumentSchema),
	})
);

export const SaveEngagementSchema = z.object({
	optionCode: z.string(),
	cropCode: z.optional(z.string()),
	engagedArea: z.optional(z.number()),
	parcelCode: z.optional(z.string()),
	declarationCode: z.optional(z.string()),
	engagedLength: z.optional(z.number()),
	additionalColumn: z.optional(
		z.array(
			z.object({
				paramName: z.string(),
				paramValue: z.union([z.string(), z.number()]),
			})
		)
	),
});

export const SaveEngagementArraySchema = z.array(SaveEngagementSchema);

export const SaveEngagementZootechnicsSchema = z.array(
	z.object({
		optionCode: z.string(),
		zootechnicsBreedingCode: z.optional(z.nullable(z.string())),
		flSelected: z.optional(z.nullable(z.boolean())),
	})
);

export const AdditionalColumnSchema = z.object({
	code: z.string(),
	type: z.string(),
});

export const ConfirmationApplicationSchema = z.object({
	previousYearApplication: z.string().nullish(),
	initialApplication: z.string(),
	commitmentYear: z.number(),
	optionCode: z.string(),
	optionType: z.nullable(z.enum([OptionType.SURFACE, OptionType.ZOOTECHNIC])),
	optionDescription: z.string(),
	previousYearQuantity: z.number(),
	confirmedQuantity: z.number(),
	takeOver: z.nullable(
		z.object({
			takeoverId: z.number(),
			partyDescription: z.string(),
			cuaa: z.string(),
			optionCode: z.string(),
			takeOverType: z.enum(["PARTIAL", "TOTAL", "AUTO"]),
		})
	),
	flOptionSubstitutions: z.boolean(),
	additionalDeclaration: z.nullable(AdditionalDeclarationsSchema),
	waiverAdditionalDeclaration: z.nullable(AdditionalDeclarationsSchema),
	childrenOptions: z.nullable(z.array(z.string())),
	additionalColumn: z.optional(z.nullable(z.array(AdditionalColumnSchema))),
	gsaaFlag: z.nullable(z.boolean()),
	scoreFlag: z.boolean().nullable().optional(),
	waivedArea: z.optional(z.nullable(z.number())),
	showWaivedArea: z.optional(z.nullable(z.boolean())),
});

export const ConfirmationApplicationListSchema = z.nullable(
	z.array(ConfirmationApplicationSchema)
);

export const PartyModelSchema = z
	.object({
		partyId: z.number(),
		code: z.string(),
		description: z.nullable(z.string()),
	})
	.passthrough();

export const PartyListModelSchema = z.object({
	count: z.number(),
	records: z.array(PartyModelSchema),
	nextKey: z.nullable(z.string()),
});

export const TakeOverSchema = z.object({
	partyDescription: z.string(),
	cuaa: z.string(),
	takeoverApplicationCode: z.nullable(z.string()),
	optionCode: z.string(),
	optionDescription: z.string(),
	takeoverType: z.enum(["PARTIAL", "TOTAL"]).optional(),
});

export const TakeOverListSchema = z.nullable(z.array(TakeOverSchema));

export const SaveTakeOverSchema = z.object({
	cuaa: z.string(),
	takeoverApplicationCode: z.string(),
	optionCode: z.string(),
	takeoverType: z.enum(["PARTIAL", "TOTAL"]),
});

export const SaveTakeOverListSchema = z.nullable(z.array(SaveTakeOverSchema));

export const ReplacementOrWaiverSurfaceSchema = z.object({
	area: z.number(),
	cropPlanVersion: z.string(),
	currentCropPlanGeometry: z.nullable(
		z.object({
			geometry: z.string(),
			srs: z.string(),
		})
	),
	parcelCode: z.nullable(z.string()),
	previousApplicationGeometry: z.nullable(
		z.object({
			geometry: z.string(),
			srs: z.string(),
		})
	),
	previousClaimPolygonId: z.number(),
	waiveredGeometry: z.nullable(
		z.object({
			geometry: z.string(),
			srs: z.string(),
		})
	),
	withdrawnReasonCode: z.nullable(z.string()),
	withdrawnReasonDescription: z.nullable(z.string()),
});

export const ReplacementOrWaiverSurfaceListSchema = z.array(
	z.nullable(ReplacementOrWaiverSurfaceSchema)
);

export const SaveReplacementOrWaiverSurfaceSchema = z.nullable(
	z.array(
		z.object({
			withdrawnReasonCode: z.string(),
			previousClaimPolygonId: z.number(),
		})
	)
);

export const SaveReplacementOrWaiverSurfaceResponseSchema = z.nullable(
	z.array(
		z.object({
			previousClaimPolygonId: z.number(),
			parcelCode: z.nullable(z.string()),
			area: z.number(),
			withdrawnReasonCode: z.nullable(z.string()),
			withdrawnReasonDescription: z.nullable(z.string()),
			waiveredGeometry: z.nullable(
				z.object({
					geometry: z.string(),
					srs: z.string(),
				})
			),
			previousApplicationGeometry: z.nullable(
				z.object({
					geometry: z.string(),
					srs: z.string(),
				})
			),
			currentCropPlanGeometry: z.nullable(
				z.object({
					geometry: z.string(),
					srs: z.string(),
				})
			),
			cropPlanVersion: z.string(),
		})
	)
);

export const ReplacementOrWaiverWithdrawnReasonSchema = z.object({
	withdrawReasonCode: z.optional(z.string()),
	withdrawReasonDescription: z.optional(z.string()),
});

export const ReplacementOrWaiverWithdrawnReasonListSchema = z.nullable(
	z.array(ReplacementOrWaiverWithdrawnReasonSchema)
);

export const ZootechnicInterventionSchema = z.nullable(
	z.object({
		age: z.number(),
		birthday: z.string(),
		coeffConvUba: z.number(),
		earTag: z.string(),
		flSelected: z.boolean(),
		gender: z.string(),
		race: z.string(),
		zootechnicsBreedingCode: z.nullable(z.string()),
		zootechnicsSpeciesCode: z.string(),
		zootechnicsSpeciesDescription: z.string(),
		zootechnicsSubSpeciesCode: z.optional(z.nullable(z.string())),
		flIsValid: z.optional(z.nullable(z.boolean())),
		warningCode: z.optional(z.nullable(z.string())),
		isConfirmation: z.boolean().nullish(),
	})
);

export const ZootechnicInterventionListSchema = z.nullable(
	z.array(ZootechnicInterventionSchema)
);

export const ZootechnicInterventionResponseSchema = z.nullable(
	z.object({
		records: ZootechnicInterventionListSchema,
		nextKey: z.nullable(z.string()),
		count: z.number(),
	})
);

export const LivestockSchema = z.object({
	earTag: z.string(),
	declarationTypeCode: z.nullable(z.string()),
	withdrawnReasonCode: z.nullable(z.string()),
	withdrawnReasonDescription: z.nullable(z.string()),
	replacedWithEarTag: z.nullable(z.string()),
});

export const saveLivestockReplacementListSchema = z.nullable(
	z.array(
		z.object({
			earTag: z.string(),
			declarationTypeCode: z.nullable(z.string()),
			withdrawnReasonCode: z.nullable(z.string()),
			replacedWithEarTag: z.nullable(z.string()),
		})
	)
);

export const LivestockListSchema = z.nullable(z.array(LivestockSchema));

export const ReplaceLivestockSchema = z.nullable(
	z.object({
		aslCode: z.string(),
		birthday: z.string(),
		earTag: z.string(),
		race: z.string(),
		speciesDescription: z.string(),
	})
);

export const ReplaceLivestockListSchema = z.nullable(
	z.array(ReplaceLivestockSchema)
);

export const ReplaceLivestockResponseSchema = z.nullable(
	z.object({
		records: ReplaceLivestockListSchema,
		nextKey: z.nullable(z.string()),
		count: z.number(),
	})
);

export const SupportOptionSchema = z.object({
	optionCode: z.string(),
	optionDescription: z.string(),
	actionDenomination: z.optional(z.string()),
	optionType: z.nullable(z.enum(["SURFACE", "ZOOTECHNIC"])),
	requestableQuantity: z.optional(z.nullable(z.number())),
	flSelected: z.nullable(z.boolean()),
	optionMinimumRequestableQuantity: z.nullable(z.number()),
	engagedQuantity: z.nullable(z.number()),
	cropPlanId: z.nullable(z.number()),
	cropPlanVersion: z.nullable(z.string()),
	gsaaFlag: z.nullable(z.boolean()),
	isMultyElegibility: z.nullable(z.boolean()),
	additionalDeclaration: z.nullable(AdditionalDeclarationsSchema),
	scoreFlag: z.boolean().nullable().optional(),
	additionalColumn: z.optional(z.nullable(z.array(AdditionalColumnSchema))),
});
export const SupportOptionsListSchema = z.array(SupportOptionSchema);

export const StandardDetailsSchema = z.nullable(
	z.object({
		totalRequestableArea: z.number(),
		totalPreviousYearArea: z.number(),
		totalEngagedArea: z.number(),
	})
);

export const WithdrawReasonSchema = z.object({
	withdrawReasonCode: z.string(),
	withdrawReasonDescription: z.string(),
});

export const WithdrawReasonListSchema = z.nullable(
	z.array(WithdrawReasonSchema)
);

export const SaveZootechnicsInterventionListSchema = z.nullable(
	z.array(
		z.object({
			zootechnicsBreedingCode: z.nullable(z.string()),
			flSelected: z.boolean(),
			earTag: z.nullable(z.string()),
		})
	)
);

export const SelectBreedingsSchema = z.object({
	optionCode: z.string(),
	optionDescription: z.string(),
	zootechnicsBreedingCode: z.string(),
	zootechnicsFarmId: z.nullable(z.number()),
	zootechnicsBreedingDescription: z.nullable(z.string()),
	zootechnicsSpeciesCode: z.string(),
	zootechnicsSpeciesSubCode: z.string(),
	zootechnicsSpeciesDescription: z.string(),
	zootechnicsBreedingCouncilCode: z.nullable(z.string()),
	zootechnicsBreedingDistrictCode: z.nullable(z.string()),
	zootechnicsBreedingCouncilDescription: z.nullable(z.string()),
	zootechnicsBreedingAddress: z.nullable(z.string()),
	zootechnicsBreedingCityName: z.nullable(z.string()),
	flSelected: z.boolean(),
	flIsValid: z.boolean(),
	warningCode: z.string(),
	cattles: z.array(
		z.object({
			zootechnicsSubSpeciesCode: z.string(),
			cattlesNumber: z.nullable(z.number()),
			uba: z.nullable(z.number()),
			averageConsistency: z.nullable(z.number()),
			zootechnicsSubSpeciesDescription: z.string(),
		})
	),
});

export const SelectBreedingsListSchema = z.array(SelectBreedingsSchema);

export const SelectBreedingsListResponseSchema = z.object({
	records: z.nullable(z.array(SelectBreedingsSchema)),
	nextKey: z.nullable(z.string()),
	count: z.number(),
});

export const SaveSelectBreedingsListSchema = z.nullable(
	z.array(
		z.object({
			optionCode: z.string(),
			zootechnicsBreedingCode: z.string(),
			zootechnicsSpeciesCode: z.string(),
			zootechnicsSpeciesSubCode: z.string(),
			flSelected: z.boolean(),
			cattles: z.array(
				z.object({
					zootechnicsSubSpeciesCode: z.string(),
					cattlesNumber: z.number(),
					uba: z.number(),
					averageConsistency: z.number(),
					zootechnicsSubSpeciesDescription: z.string(),
				})
			),
		})
	)
);

export const ZootechnicInterventionSummarySchema = z.nullable(
	z.object({
		totalPreviousYearCattles: z.nullable(z.number()),
		totalConfirmedCattles: z.nullable(z.number()),
		totalPreviousYearUba: z.nullable(z.number()),
		totalConfirmedUba: z.nullable(z.number()),
	})
);

export const WmtsLayerSchema = z.object({
	layer_id: z.string(),
	code: z.string(),
	description: z.string(),
	srs: z.string(),
	minResolution: z.nullable(z.number()),
	maxResolution: z.nullable(z.number()),
	on: z.boolean(),
	enabledInOverview: z.boolean(),
	legendOrder: z.number(),
	foregroundLevel: z.number(),
	url: z.string(),
	layer: z.string(),
	style: z.nullable(z.any()),
	version: z.string(),
	format: z.string(),
	tileMatrixSet: z.string(),
	tileMatrix: z.string(),
	publicLayerType: z.string(),
});

export const AdditionalLayersSchema = z.nullable(
	z.object({
		wmsLayers: z.any(),
		wmtsLayers: z.array(WmtsLayerSchema),
	})
);

export const ScoreCardDeclarationSchema = z.object({
	code: z.string(),
	subCode: z.string(),
	description: z.string(),
	score: z.number(),
	selected: z.boolean().nullable(),
	sortOrder: z.number(),
});

export const ScoreCardGroupSchema = z.object({
	code: z.string(),
	title: z.string().nullable(),
	subtitle: z.string(),
	sortOrder: z.number(),
	scoreList: z.array(ScoreCardDeclarationSchema),
});

export const ScoreCardDefinitionSchema = z.array(ScoreCardGroupSchema);

export const SaveScoreCardSchema = z.array(
	z.object({
		scoreCode: z.string(),
		value: z.boolean(),
	})
);

export const PsrApplicationSchema = z.object({
	optionCode: z.string(),
	optionDescription: z.string().nullable(),
	psrApplicationId: z.number(),
	applicationId: z.optional(z.number()),
	psrCode: z.optional(z.string()),
});
export const PsrApplicationsSchema = z.array(PsrApplicationSchema);

export const WithdrawalApplicationSchema = z.object({
	moduleDescription: z.string(),
	applicationId: z.number(),
	dtProtocol: z.string(),
	protocolId: z.number(),
});
export const WithdrawalApplicationListSchema = z.array(
	WithdrawalApplicationSchema
);

export const WithdrawalApplicationDetailsSchema = z.object({
	cuaa: z.string(),
	denomination: z.string(),
	sectorDescription: z.string(),
	moduleDescription: z.string().nullable(),
	referredYear: z.number(),
	dtPresentation: z.string(),
	dtProtocol: z.string(),
	protocolId: z.number(),
});

export const WithdrawalApplicationSummarySchema = z.object({
	optionDescription: z.string().nullable().optional(),
	requestedQt: z.number().nullable().optional(),
	waivedQt: z.number().nullable().optional(),
	engagedQt: z.number().nullable().optional(),
	type: z.string().nullable().optional(),
});

export const SurfaceDetailSchema = z.object({
	optionCode: z.string(),
	optionDescription: z.string(),
	layerCode: z.string(),
	engagedArea: z.nullable(z.number()),
});

export const SurfaceDetailListSchema = z.array(SurfaceDetailSchema);

export const WithdrawalApplicationSummaryListSchema = z.array(
	WithdrawalApplicationSummarySchema
);

export const FlAllConfirmedSchema = z.object({
	flAllConfirmed: z.boolean(),
});

export type OptionModel = z.infer<typeof OptionSchema>;
export type OptionsListModel = z.infer<typeof OptionsListSchema>;
export type RelatedOptionsModel = z.infer<typeof RelatedOptionsSchema>;
export type SaveAdditionalDeclarationsModel = z.infer<
	typeof saveAdditionalDeclarationsSchema
>;

export type YoungFarmerRoleModel = z.infer<typeof YoungFarmerRoleSchema>;
export type YoungFarmerModel = z.infer<typeof YoungFarmerModelSchema>;
export type UnifiedDeclarationsModel = z.infer<
	typeof UnifiedDeclarationsSchema
>;
export type UnifiedDeclarationListResponse = z.infer<
	typeof UnifiedDeclarationListResponseSchema
>;
export type UnifiedDeclarationDocumentResponse = z.infer<
	typeof UnifiedDeclarationDocumentSchema
>;
export type SaveYoungFarmerDataModel = z.infer<
	typeof SaveYoungFarmerDataSchema
>;
export type SaveUnifiedDeclarationsModel = z.infer<
	typeof SaveUnifiedDeclarationsSchema
>;

export type PrizesChoiceModel = z.infer<typeof PrizesChoiceSchema>;

export type PrizesChoiceListModel = z.infer<typeof PrizesChoiceListSchema>;

export type SavePrizesChoiceListModel = z.infer<typeof SavePrizesChoiceSchema>;

export type OptionDetailsModel = z.infer<typeof OptionDetailsSchema>;
export type ParticlesModel = z.infer<
	typeof OptionDetailsSchema.shape.particles
>;
export type OptionDetailsListModel = z.infer<typeof OptionDetailsListSchema>;
export type OptionDetailsInfiniteListModel = z.infer<
	typeof OptionDetailsInfiniteListSchema
>;
export type TerritoryFiltersModel = z.infer<typeof TerritoryFiltersSchema>;
export type ZootechnicFiltersModel = z.infer<typeof ZootechnicFiltersSchema>;

export type ZootechnicsOptionModel = z.infer<typeof ZootechnicsOptionSchema>;
export type ZootechnicsOptionListModel = z.infer<
	typeof ZootechnicsOptionListSchema
>;
export type ZootechnicsDeclarationsModel = z.infer<
	typeof ZootechnicsDeclarationsSchema
>;
export type ZootechnicsDeclarationsListModel = z.infer<
	typeof ZootechnicsDeclarationsListSchema
>;
export type ZootechnicsDeclarationsListResponse = z.infer<
	typeof ZootechnicsDeclarationsListResponseSchema
>;

export type SaveEngagementModel = z.infer<typeof SaveEngagementSchema>;
export type SaveEngagementArrayModel = z.infer<
	typeof SaveEngagementArraySchema
>;

export type SaveEngagementZootechnicsModel = z.infer<
	typeof SaveEngagementZootechnicsSchema
>;

export type ConfirmationApplicationModel = z.infer<
	typeof ConfirmationApplicationSchema
>;

export type ConfirmationApplicationListModel = z.infer<
	typeof ConfirmationApplicationListSchema
>;

export type PartyListModel = z.infer<typeof PartyListModelSchema>;

export type PartyModel = z.infer<typeof PartyModelSchema>;

export type TakeOverModel = z.infer<typeof TakeOverSchema>;

export type TakeOverListModel = z.infer<typeof TakeOverListSchema>;

export type SaveTakeOverModel = z.infer<typeof SaveTakeOverSchema>;

export type SaveTakeOverListModel = z.infer<typeof SaveTakeOverListSchema>;

export type ReplacementOrWaiverSurfaceModel = z.infer<
	typeof ReplacementOrWaiverSurfaceSchema
>;

export type ReplacementOrWaiverSurfaceListModel = z.infer<
	typeof ReplacementOrWaiverSurfaceListSchema
>;

export type SaveReplacementOrWaiverSurfaceModel = z.infer<
	typeof SaveReplacementOrWaiverSurfaceSchema
>;

export type SaveReplacementOrWaiverSurfaceResponseModel = z.infer<
	typeof SaveReplacementOrWaiverSurfaceResponseSchema
>;

export type ReplacementOrWaiverWithdrawnReasonModel = z.infer<
	typeof ReplacementOrWaiverWithdrawnReasonSchema
>;

export type ReplacementOrWaiverWithdrawnReasonListModel = z.infer<
	typeof ReplacementOrWaiverWithdrawnReasonListSchema
>;

export type ZootechnicTakeOverModel = z.infer<
	typeof ZootechnicInterventionSchema
>;

export type ZootechnicTakeOverListModel = z.infer<
	typeof ZootechnicInterventionListSchema
>;

export type ZootechnicInterventionResponseModel = z.infer<
	typeof ZootechnicInterventionResponseSchema
>;

export type LivestockModel = z.infer<typeof LivestockSchema>;

export type SaveLivestockReplacementListModel = z.infer<
	typeof saveLivestockReplacementListSchema
>;

export type LivestockListModel = z.infer<typeof LivestockListSchema>;

export type ReplaceLivestockModel = z.infer<typeof ReplaceLivestockSchema>;

export type ReplaceLivestockListModel = z.infer<
	typeof ReplaceLivestockListSchema
>;

export type ReplaceLivestockResponseModel = z.infer<
	typeof ReplaceLivestockResponseSchema
>;

export type SupportOptionModel = z.infer<typeof SupportOptionSchema>;
export type SupportOptionsListModel = z.infer<typeof SupportOptionsListSchema>;

export type StandardDetailsModel = z.infer<typeof StandardDetailsSchema>;

export type WithdrawnReasonModel = z.infer<typeof WithdrawReasonSchema>;

export type WithdrawnReasonListModel = z.infer<typeof WithdrawReasonListSchema>;

export type SaveZootechnicsInterventionListModel = z.infer<
	typeof SaveZootechnicsInterventionListSchema
>;

export type SelectBreedingsModel = z.infer<typeof SelectBreedingsSchema>;
export type SelectBreedingsListModel = z.infer<
	typeof SelectBreedingsListSchema
>;
export type SelectBreedingsListResponse = z.infer<
	typeof SelectBreedingsListResponseSchema
>;

export type SaveSelectBreedingsListModel = z.infer<
	typeof SaveSelectBreedingsListSchema
>;

export type ZootechnicInterventionSummaryModel = z.infer<
	typeof ZootechnicInterventionSummarySchema
>;

export type AdditionalLayersModel = z.infer<typeof AdditionalLayersSchema>;

export type AdditionalDeclarationsModel = z.infer<
	typeof AdditionalDeclarationsSchema
>;

export type ScoreCardDeclarationModel = z.infer<
	typeof ScoreCardDeclarationSchema
>;
export type ScoreCardGroupModel = z.infer<typeof ScoreCardGroupSchema>;
export type ScoreCardDefinitionModel = z.infer<
	typeof ScoreCardDefinitionSchema
>;
export type SaveScoreCardModel = z.infer<typeof SaveScoreCardSchema>;

export type AdditionalColumnModel = z.infer<typeof AdditionalColumnSchema>;

export type PsrApplicationsModel = z.infer<typeof PsrApplicationsSchema>;
export type MonitoringData = z.infer<typeof MonitoringDataSchema>;
export type OptionDetailDeclarationGeom = z.infer<
	typeof OptionDetailDeclarationGeomSchema
>;
export type WithdrawalApplicationListModel = z.infer<
	typeof WithdrawalApplicationListSchema
>;
export type WithdrawalApplicationModel = z.infer<
	typeof WithdrawalApplicationSchema
>;
export type WithdrawalApplicationDetailsModel = z.infer<
	typeof WithdrawalApplicationDetailsSchema
>;
export type WithdrawalApplicationSummaryListModel = z.infer<
	typeof WithdrawalApplicationSummaryListSchema
>;
export type WithdrawalApplicationSummaryModel = z.infer<
	typeof WithdrawalApplicationSummarySchema
>;
export type SurfaceDetailModel = z.infer<typeof SurfaceDetailSchema>;

export type FlAllConfirmedModel = z.infer<typeof FlAllConfirmedSchema>;
