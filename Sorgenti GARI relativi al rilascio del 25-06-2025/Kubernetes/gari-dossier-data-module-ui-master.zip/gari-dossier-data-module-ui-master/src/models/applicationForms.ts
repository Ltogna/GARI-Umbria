import { z } from "zod";

export enum FuelType {
	TOTAL_DIESEL = "TOTAL_DIESEL",
	DIESEL_THIRD_PARTIES = "DIESEL_THIRD_PARTIES",
	DIESEL_OWN_ACCOUNT = "DIESEL_OWN_ACCOUNT",
	GAS = "GAS",
	DIESEL_GREEN_HOUSES = "DIESEL_GREEN_HOUSES",
}

export const SaveAttachmentModelSchema = z.object({
	file: z.nullable(z.any()),
	typeCode: z.string(),
	groupCode: z.string(),
	notes: z.nullable(z.string()),
});

export const AttachmentModelSchema = z.object({
	applicationId: z.number(),
	attachmentId: z.string(),
	fileName: z.string(),
	notes: z.nullable(z.string()),
	type: z.object({
		code: z.nullable(z.string()),
		groupCode: z.nullable(z.string()),
		typeCode: z.nullable(z.string()),
	}),
});

export const AttachmentListResponseSchema = z.object({
	records: z.nullable(z.array(z.nullable(AttachmentModelSchema))),
	nextKey: z.nullable(z.string()),
	count: z.number(),
});

export const AttachmentTypeModelSchema = z.object({
	code: z.nullable(z.string()),
	groupCode: z.string(),
	typeCode: z.string(),
});

export const AttachmentTypeResponseSchema = z.nullable(
	z.object({
		records: z.nullable(z.array(AttachmentTypeModelSchema)),
		nextKey: z.nullable(z.string()),
		count: z.number(),
	})
);

export const DeclarationModelSchema = z.object({
	code: z.string(),
	required: z.boolean(),
	minOccurs: z.number().optional(),
	maxOccurs: z.number().optional(),
	label: z.record(z.string()),
	type: z.string(),
	style: z.nullable(z.string()),
	help: z.nullable(z.string()),
	format: z.nullable(z.string()),
	readonly: z.boolean(),
	lookupCode: z.nullable(z.string()),
	validation: z.nullable(z.string()),
});

export const DeclarationDocumentSchema = z.object({
	fields: z.record(z.nullable(z.number())),
	validTo: z.string().or(z.number()),
	validFrom: z.string().or(z.number()),
});

export const DeclarationListResponseSchema = z.nullable(
	z.object({
		document: z.nullable(DeclarationDocumentSchema),
		documentDefinition: z.object({
			code: z.string(),
			version: z.string(),
			description: z.string(),
			title: z.record(z.string()),
			metadata: z.object({
				maxOccurs: z.number(),
				timeOverlap: z.boolean(),
				defaultLocale: z.string(),
				startDateField: z.string(),
				endDateField: z.string(),
				summaryFields: z.nullable(z.string()),
			}),
			fieldSets: z.array(
				z.object({
					code: z.string(),
					minOccurs: z.number(),
					maxOccurs: z.number(),
					label: z.record(z.string()),
					fields: z.array(DeclarationModelSchema),
				})
			),
			lookups: z.nullable(z.string()),
			restLookups: z.nullable(z.string()),
			onSaveApiCalls: z.nullable(z.string()),
		}),
	})
);

export const SaveDeclarationsSchema = z.nullable(
	z.object({
		document: z.nullable(DeclarationDocumentSchema),
	})
);

export const MachinerySchema = z.object({
	machineryId: z.number(),
	machineryPlate: z.nullable(z.string()),
	machinerySerialNumber: z.nullable(z.string()),
	machineryDescription: z.nullable(z.string()),
	machineryClassCode: z.nullable(z.string()),
	machineryClassDescription: z.nullable(z.string()),
	machinerySubclassCode: z.nullable(z.string()),
	machinerySubclassDescription: z.nullable(z.string()),
	machineryBrand: z.nullable(z.string()),
	machineryFuelType: z.nullable(z.string()),
	machineryEngineType: z.nullable(z.string()),
	machineryEngineBrand: z.nullable(z.string()),
	machineryHp: z.nullable(z.number()),
	machineryKw: z.nullable(z.number()),
	flMachineryInCompanyFile: z.nullable(z.boolean()),
	isSelected: z.boolean(),
	ownership: z.nullable(z.string()),
	dtPurchase: z.nullable(z.string()),
	dtStartFunctionalCheck: z.nullable(z.string()),
	dtEndFunctionalCheck: z.nullable(z.string()),
});

export const MachineryListSchema = z.array(MachinerySchema);

export const SaveMachineriesSchema = z.array(
	z.object({
		applicationId: z.number(),
		machineryId: z.number(),
	})
);

export const SaveMachineriesResponseSchema = z.array(
	z.object({
		machineryId: z.number(),
		machineryPlate: z.nullable(z.string()),
		machinerySerialNumber: z.nullable(z.string()),
		machineryDescription: z.nullable(z.string()),
		machineryClassCode: z.nullable(z.string()),
		machineryClassDescription: z.nullable(z.string()),
		machinerySubclassCode: z.nullable(z.string()),
		machinerySubclassDescription: z.nullable(z.string()),
		machineryBrand: z.nullable(z.string()),
		machineryFuelType: z.nullable(z.string()),
		machineryEngineType: z.nullable(z.string()),
		machineryEngineBrand: z.nullable(z.string()),
		machineryHp: z.nullable(z.number()),
		machineryKw: z.nullable(z.number()),
		flMachineryInCompanyFile: z.nullable(z.boolean()),
		ownership: z.nullable(z.string()),
		dtPurchase: z.nullable(z.string()),
		dtStartFunctionalCheck: z.nullable(z.string()),
		dtEndFunctionalCheck: z.nullable(z.string()),
	})
);

export const EquipmentSchema = z.object({
	equipmentId: z.number(),
	description: z.nullable(z.string()),
	name: z.nullable(z.string()),
	serialNumber: z.nullable(z.string()),
	ownershipType: z.nullable(z.string()),
	dtLoad: z.nullable(z.string()),
	dtStartFunctionalCheck: z.nullable(z.string()),
	dtEndFunctionalCheck: z.nullable(z.string()),
	dtPurchase: z.nullable(z.string()),
	flInCompanyFile: z.nullable(z.boolean()),
	isSelected: z.boolean(),
});

export const EquipmentListSchema = z.array(EquipmentSchema);

export const SaveEquipmentsSchema = z.array(
	z.object({
		applicationId: z.number(),
		equipmentId: z.number(),
	})
);

export const SaveEquipmentsResponseSchema = z.array(
	z.object({
		equipmentId: z.number(),
		description: z.nullable(z.string()),
		name: z.nullable(z.string()),
		serialNumber: z.nullable(z.string()),
		ownershipType: z.nullable(z.string()),
		dtLoad: z.nullable(z.string()),
		dtStartFunctionalCheck: z.nullable(z.string()),
		dtEndFunctionalCheck: z.nullable(z.string()),
		dtPurchase: z.nullable(z.string()),
		flInCompanyFile: z.nullable(z.boolean()),
		isSelected: z.boolean(),
	})
);

export const CheckMandatoryMachineryOrEquipmentSchema = z.nullable(
	z.object({
		ignoreMachineryIds: z.nullable(z.array(z.number())),
		ignoreEquipmentIds: z.nullable(z.array(z.number())),
	})
);

export const CheckMandatoryMachineryOrEquipmentResponseSchema = z.nullable(
	z.object({
		flAllMandatoryToolsDeclared: z.boolean(),
	})
);

export const BuildingProcessingListModelSchema = z.object({
	buildingTypeId: z.string(),
	buildingTypeDescription: z.string(),
	buildingTypeProcessingsCount: z.number(),
	flCompiled: z.boolean().optional(),
	flInCompanyFile: z.boolean().optional(),
	flAllMandatoryToolsDeclared: z.boolean(),
	flMandatoryToolsInCompanyFile: z.boolean(),
});

export const BuildingProcessingListResponseSchema = z.nullable(
	z.array(BuildingProcessingListModelSchema)
);

export const BuildingProcessingModelSchema = z.object({
	buildingId: z.number(),
	buildingCouncilName: z.nullable(z.string()),
	buildingCoveredArea: z.number(),
	buildingRegionalAuthNumber: z.nullable(z.string()),
	buildingVolume: z.number(),
	flBuildingInCompanyFile: z.boolean(),
	flAllMandatoryToolsDeclared: z.nullable(z.boolean()),
	flMandatoryToolsInCompanyFile: z.boolean(),
	cultureName: z.nullable(z.string()),
	processingId: z.string(),
	processingDescription: z.string(),
	quantityUnitOfMeasure: z.string(),
	quantity: z.nullable(z.number()),
	maximumQuantity: z.nullable(z.number()),
	daysOfActivity: z.nullable(z.number()),
	maximumDaysOfActivity: z.nullable(z.number()),
	machineryIds: z.optional(z.nullable(z.array(z.number()))),
	machineryClassCode: z.string(),
	machineryClassDescription: z.optional(z.nullable(z.string())),
	machinerySubClassCode: z.string(),
	machinerySubclassDescription: z.optional(z.nullable(z.string())),
	equipmentCode: z.nullable(z.string()),
	equipmentDescription: z.optional(z.nullable(z.string())),
});

export const BuildingProcessingDetailsListSchema = z.array(
	BuildingProcessingModelSchema
);

export const SaveBuildingProcessingDetailsModelSchema = z.array(
	z.object({
		applicationId: z.number(),
		buildingTypeId: z.string(),
		buildingId: z.number(),
		buildingProcessingId: z.string(),
		quantity: z.nullable(z.number()),
		daysOfActivity: z.nullable(z.number()),
		dtInsert: z.nullable(z.string()),
		dtDelete: z.nullable(z.string()),
		userIdInsert: z.nullable(z.string()),
		userIdDelete: z.nullable(z.string()),
		machineryClassCode: z.string(),
		machinerySubClassCode: z.string(),
		equipmentCode: z.nullable(z.string()),
	})
);

export const ConsumeValueModelSchema = z.object({
	fuelType: z.string(),
	consumable: z.nullable(z.number()),
	available: z.nullable(z.number()),
	consumed: z.nullable(z.number()),
	residualAtEndOfYear: z.nullable(z.number()),
	exciseMotivationCode: z.nullable(z.string()),
	exciseMotivationDescription: z.nullable(z.string()),
	exciseDuty: z.nullable(z.number()),
	residualAtStartOfPreviousYear: z.nullable(z.number()),
	maximumAssigned: z.nullable(z.number()),
	assigned: z.nullable(z.number()),
	admitted: z.nullable(z.number()),
	received: z.nullable(z.number()),
	sold: z.nullable(z.number()),
	alternativeFuelUsed: z.nullable(z.number()),
	pickedUpFuel: z.nullable(z.number()),
});

export const ConsumptionDeclarationListModelSchema = z.array(
	ConsumeValueModelSchema
);

export const GasTakingModelSchema = z.object({
	gasStation: z.nullable(z.string()),
	takingDate: z.nullable(z.string()),
	delivered: z.nullable(z.boolean()),
	municipality: z.nullable(z.string()),
	address: z.nullable(z.string()),
	openingDate: z.nullable(z.string()),
	closingDate: z.nullable(z.string()),
	takingValues: z.array(
		z.object({
			fuelType: z.string(),
			quantity: z.number(),
		})
	),
});

export const GasStationTakingsModelSchema = z.array(GasTakingModelSchema);

export const RequirementListModelSchema = z.object({
	fuelType: z.string(),
	residualInitialYear: z.nullable(z.number()),
	transferred: z.number(),
	received: z.nullable(z.number()),
	alternativeFuelDeclared: z.nullable(z.number()),
	alternativeFuelUsed: z.nullable(z.number()),
	admissible: z.nullable(z.number()),
	grossAssigned: z.nullable(z.number()),
});

export const RequirementListResponseSchema = z.nullable(
	z.object({
		notes: z.nullable(z.string()),
		needValues: z.array(RequirementListModelSchema),
	})
);

export const SaveRequirementModelSchema = z.object({
	notes: z.nullable(z.string()),
	needValues: z.array(
		z.object({
			fuelType: z.string(),
			grossAssigned: z.number(),
		})
	),
});

export const DeclarationTypeChoiceListModelSchema = z
	.object({
		flDeclarationOfNeed: z.boolean(),
		flDeclarationOfConsumption: z.boolean(),
		companyTypeCode: z.nullable(z.string()),
		companyTypeDescription: z.nullable(z.string()),
		profileCodes: z.array(z.string()),
	})
	.passthrough();

export const DeclarationTypeChoiceListResponseSchema = z.nullable(
	DeclarationTypeChoiceListModelSchema
);

export const MunicipalityRecordListModelSchema = z
	.object({
		id: z.number(),
		description: z.string(),
		short_descr: z.string(),
		sector_code: z.string(),
		srs: z.string(),
		geom: z.string(),
		world_geom: z.string(),
	})
	.passthrough();

export const MunicipalityRecordListResponseSchema = z.nullable(
	MunicipalityRecordListModelSchema
);

export const MunicipalityListModelSchema = z
	.object({
		nextKey: z.nullable(z.string()),
		records: z.array(MunicipalityRecordListModelSchema),
		count: z.number(),
	})
	.passthrough();

export const MunicipalityListResponseSchema = z.nullable(
	MunicipalityListModelSchema
);

export const MunicipalityListFromCodeSubModelSchema = z
	.object({
		id: z.number(),
		description: z.string(),
		short_descr: z.string(),
		sector_code: z.string(),
		srs: z.nullable(z.string()),
		geom: z.nullable(z.string()),
		world_geom: z.nullable(z.string()),
	})
	.passthrough();

export const MunicipalityRecordListFromCodeSubResponseSchema = z.nullable(
	MunicipalityListFromCodeSubModelSchema
);

export const MunicipalityListFromCodeModelSchema = z
	.object({
		nextKey: z.nullable(z.string()),
		records: z.array(MunicipalityListFromCodeSubModelSchema),
		count: z.number(),
	})
	.passthrough();

export const MunicipalityListFromCodeResponseSchema = z.nullable(
	MunicipalityListFromCodeModelSchema
);

export const LandUseCodesListModelSchema = z
	.object({
		land_uses_code: z.string(),
		description: z.string(),
	})
	.passthrough();

export const LandUseCodesListResponseSchema = z.nullable(
	LandUseCodesListModelSchema
);

export const LandUseListFromCodeSchema = z
	.object({
		land_uses_codes_list: z.array(LandUseCodesListModelSchema),
	})
	.passthrough();

export const LandUseListFromCodeResponseSchema = z.nullable(
	LandUseListFromCodeSchema
);

export const LandUseRecordListModelSchema = z
	.object({
		land_uses_code: z.string(),
		description: z.string(),
	})
	.passthrough();

export const LandUseRecordListResponseSchema = z.nullable(
	LandUseRecordListModelSchema
);

export const LandUseListModelSchema = z
	.object({
		nextKey: z.nullable(z.string()),
		records: z.array(LandUseRecordListModelSchema),
		count: z.number(),
	})
	.passthrough();

export const LandUseListResponseSchema = z.nullable(LandUseListModelSchema);

export const SaveDeclarationTypeChoiceSchemaV2 = z.object({
	applicationId: z.number(),
	year: z.number(),
	flOrganicFert: z.boolean(),
	flLivestocks: z.nullable(z.boolean()),
});

export const DeclarationTypeChoiceListResponseSchemaV2 = z.nullable(
	SaveDeclarationTypeChoiceSchemaV2
);

export const SaveGraphicCropPlanSchema = z.object({
	sectorCode: z.string(),
	landUseCode: z.string(),
	areaSqm: z.number(),
	mas: z.number(),
});

export const GraphicCropPlanListResponseSchema = z.nullable(
	SaveGraphicCropPlanSchema
);

export const SaveDeclarationTypeChoiceSchema = z.object({
	applicationId: z.number(),
	flDeclarationOfNeed: z.boolean(),
	flDeclarationOfConsumption: z.boolean(),
	companyTypeCode: z.nullable(z.string()),
});

export const SaveDeclarationTypeChoiceResponseSchema = z.nullable(
	z.object({
		flDeclarationOfNeed: z.boolean(),
		flDeclarationOfConsumption: z.boolean(),
		companyTypeCode: z.nullable(z.string()),
		profileCodes: z.array(z.string()),
	})
);

export const SaveDeclarationTypeChoiceResponseSchemaV2 = z.nullable(
	z.object({
		applicationId: z.number(),
		year: z.number(),
		flOrganicFert: z.boolean(),
		flLivestocks: z.boolean(),
		dtInsert: z.string(),
		dtDelete: z.string(),
		userIdInsert: z.string(),
		userIdDelete: z.nullable(z.string()),
	})
);

export const getGraphicCropPlanFromImportResponseSchema = z.nullable(
	z.object({
		requestId: z.string(),
		userId: z.string(),
		cuaa: z.string(),
		campagna: z.string(),
		dtRequest: z.string(),
		flStatus: z.string(),
	})
);

export const getGraphicCropPlanFromImportListResponseSchema = z.array(
	getGraphicCropPlanFromImportResponseSchema
);

export const getGraphicCropPlanResponseSchema = z.nullable(
	z.object({
		id: z.number(),
		applicationId: z.number(),
		sectorCode: z.string(),
		sectorDescription: z.nullable(z.union([z.string(), z.undefined()])),
		landUseCode: z.string(),
		landUseDescription: z.nullable(z.union([z.string(), z.undefined()])),
		areaSqm: z.number(),
		mas: z.number(),
		dtInsert: z.string(),
		dtDelete: z.string(),
		userIdInsert: z.string(),
		userIdDelete: z.nullable(z.string()),
	})
);

export const getGraphicCropPlanListResponseSchema = z.array(
	getGraphicCropPlanResponseSchema
);

export const SaveGraphicCropPlanResponseSchema = z.nullable(
	z.object({
		id: z.number(),
		applicationId: z.number(),
		sectorCode: z.string(),
		landUseCode: z.string(),
		areaSqm: z.number(),
		mas: z.number(),
		dtInsert: z.string(),
		dtDelete: z.string(),
		userIdInsert: z.string(),
		userIdDelete: z.nullable(z.string()),
	})
);

export const GiasTokenResponseResponseSchema = z.nullable(
	z.object({
		message: z.string(),
		token: z.string(),
		baseURL: z.string(),
	})
);

export const DeclarationTypeChoiceCompanyTypeModelSchema = z.object({
	code: z.string(),
	name: z.string(),
});

export const DeclarationTypeChoiceCompanyTypeResponseSchema = z.array(
	DeclarationTypeChoiceCompanyTypeModelSchema
);

export const ZootechnicalProcessingRANModelSchema = z.object({
	ranInCompanyFile: z.number(),
	previousApplicationRan: z.number(),
	ranValue: z.nullable(z.number()),
	processingList: z.array(
		z.object({
			speciesId: z.string(),
			speciesDescription: z.nullable(z.string()),
			numberWorks: z.number(),
			flZootechnicProcessingInCompanyFile: z.boolean(),
			flSpeciesInCompanyFile: z.boolean(),
			flSubspeciesInCompanyFile: z.boolean(),
			flAllMandatoryToolsDeclared: z.boolean(),
			flCompiled: z.boolean(),
		})
	),
});

export const ZootechnicalSaveDetail = z.object({
	ranValue: z.number(),
});

export const ZootechnicalProcessingDetailModelSchema = z.object({
	speciesId: z.string(),
	speciesDescription: z.optional(z.nullable(z.string())),
	subSpeciesId: z.string(),
	subSpeciesDescription: z.nullable(z.string()),
	workTypeId: z.string(),
	workTypeDescription: z.nullable(z.string()),
	cattleNumber: z.nullable(z.number()),
	quantityAdmissible: z.nullable(z.number()),
	quantityValue: z.nullable(z.number()),
	unitOfMeasure: z.nullable(z.string()),
	machineryIds: z.nullable(z.array(z.number())),
	machineryDescription: z.nullable(z.string()),
	machineryClassDescription: z.nullable(z.string()),
	machinerySubclassDescription: z.nullable(z.string()),
	equipmentDescription: z.nullable(z.string()),
	machineryClassCode: z.nullable(z.string()),
	machinerySubclassCode: z.nullable(z.string()),
	equipmentCode: z.nullable(z.string()),
	daysOfActivity: z.nullable(z.number()),
	flZootechnicProcessingInCompanyFile: z.boolean(),
	flSpeciesInCompanyFile: z.boolean(),
	flSubspeciesInCompanyFile: z.boolean(),
	flAllMandatoryToolsDeclared: z.boolean(),
	flMandatoryToolsInCompanyFile: z.boolean(),
	flCompiled: z.boolean(),
});

export const ZootechnicalProcessingDetailResponseSchema = z.nullable(
	z.array(ZootechnicalProcessingDetailModelSchema)
);

export const ExciseMotivationListModelSchema = z.nullable(
	z.array(
		z.object({
			code: z.string(),
			description: z.string(),
		})
	)
);

export const SaveFuelConsumeModelSchema = z.object({
	fuelType: z.string(),
	consumed: z.number(),
	residualEndYear: z.number(),
	exciseDuty: z.number(),
});

export const SaveFuelConsumeListModelSchema = z.nullable(
	z.object({
		fuelTypeDetails: z.nullable(z.array(SaveFuelConsumeModelSchema)),
		exciseMotivationCode: z.nullable(z.string()),
	})
);

export const GeneratedPrintSchema = z.object({
	processStatus: z.string(),
	printCode: z.string(),
	printDescription: z.string(),
	printDate: z.number().or(z.string()),
	printJobUuid: z.nullable(z.string()),
	fileId: z.nullable(z.string()),
	username: z.string(),
});
export const PrintHistoryResponseSchema = z.array(GeneratedPrintSchema);

export type SaveAttachmentModel = z.infer<typeof SaveAttachmentModelSchema>;
export type AttachmentModel = z.infer<typeof AttachmentModelSchema>;
export type AttachmentListResponse = z.infer<
	typeof AttachmentListResponseSchema
>;
export type AttachmentTypeModel = z.infer<typeof AttachmentTypeModelSchema>;
export type AttachmentTypeResponse = z.infer<
	typeof AttachmentTypeResponseSchema
>;
export type DeclarationListResponse = z.infer<
	typeof DeclarationListResponseSchema
>;
export type DeclarationDocumentResponse = z.infer<
	typeof DeclarationDocumentSchema
>;
export type SaveDeclarationsModel = z.infer<typeof SaveDeclarationsSchema>;

export type MachineryModel = z.infer<typeof MachinerySchema>;
export type MachineryListModel = z.infer<typeof MachineryListSchema>;
export type SaveMachineriesModel = z.infer<typeof SaveMachineriesSchema>;
export type SaveMachineriesResponseModel = z.infer<
	typeof SaveMachineriesResponseSchema
>;
export type EquipmentModel = z.infer<typeof EquipmentSchema>;
export type EquipmentListModel = z.infer<typeof EquipmentListSchema>;
export type SaveEquipmentsModel = z.infer<typeof SaveEquipmentsSchema>;
export type SaveEquipmentsResponseModel = z.infer<
	typeof SaveEquipmentsResponseSchema
>;
export type CheckMandatoryMachineryOrEquipmentModel = z.infer<
	typeof CheckMandatoryMachineryOrEquipmentSchema
>;
export type CheckMandatoryMachineryOrEquipmentResponseModel = z.infer<
	typeof CheckMandatoryMachineryOrEquipmentResponseSchema
>;
export type ZootechnicalProcessingRANModel = z.infer<
	typeof ZootechnicalProcessingRANModelSchema
>;

export type ZootechnicalProcessingDetailModel = z.infer<
	typeof ZootechnicalProcessingDetailModelSchema
>;
export type ZootechnicalProcessingDetailResponse = z.infer<
	typeof ZootechnicalProcessingDetailResponseSchema
>;
export type BuildingProcessingListModel = z.infer<
	typeof BuildingProcessingListModelSchema
>;
export type BuildingProcessingListResponse = z.infer<
	typeof BuildingProcessingListResponseSchema
>;
export type BuildingProcessingDetailsModel = z.infer<
	typeof BuildingProcessingModelSchema
>;
export type BuildingProcessingDetailsListModel = z.infer<
	typeof BuildingProcessingDetailsListSchema
>;
export type SaveBuildingProcessingDetails = z.infer<
	typeof SaveBuildingProcessingDetailsModelSchema
>;
export type ConsumeValueModel = z.infer<typeof ConsumeValueModelSchema>;
export type ConsumptionDeclarationListModel = z.infer<
	typeof ConsumptionDeclarationListModelSchema
>;
export type GasTakingModel = z.infer<typeof GasTakingModelSchema>;
export type GasStationTakingsModel = z.infer<
	typeof GasStationTakingsModelSchema
>;
export type DeclarationTypeChoiceListModel = z.infer<
	typeof DeclarationTypeChoiceListModelSchema
>;
export type DeclarationTypeChoiceListResponse = z.infer<
	typeof DeclarationTypeChoiceListResponseSchema
>;

export type MunicipalityListResponse = z.infer<
	typeof MunicipalityListResponseSchema
>;

export type MunicipalityListFromCodeResponse = z.infer<
	typeof MunicipalityListFromCodeResponseSchema
>;

export type LandUseListFromCodeResponse = z.infer<
	typeof LandUseListFromCodeResponseSchema
>;

export type MunicipalityRecordListFromCodeResponse = z.infer<
	typeof MunicipalityListFromCodeResponseSchema
>;

export type MunicipalityRecordListFromCodeSubResponse = z.infer<
	typeof MunicipalityRecordListFromCodeSubResponseSchema
>;

export type MunicipalityRecordListResponse = z.infer<
	typeof MunicipalityRecordListResponseSchema
>;

export type LandUseListResponse = z.infer<typeof LandUseListResponseSchema>;

export type LandUseRecordListResponse = z.infer<
	typeof LandUseRecordListResponseSchema
>;

export type DeclarationTypeChoiceListResponseV2 = z.infer<
	typeof DeclarationTypeChoiceListResponseSchemaV2
>;

export type SaveDeclarationTypeChoiceModel = z.infer<
	typeof SaveDeclarationTypeChoiceSchema
>;

export type SaveDeclarationTypeChoiceModelV2 = z.infer<
	typeof SaveDeclarationTypeChoiceSchemaV2
>;

export type SaveGraphicCropPlanModel = z.infer<
	typeof SaveGraphicCropPlanSchema
>;

export type SaveGraphicCropPlanResponse = z.infer<
	typeof SaveGraphicCropPlanResponseSchema
>;

export type GiasTokenResponse = z.infer<typeof GiasTokenResponseResponseSchema>;

export type getGraphicCropPlanResponse = z.infer<
	typeof getGraphicCropPlanResponseSchema
>;

export type getGraphicCropPlanFromImportResponse = z.infer<
	typeof getGraphicCropPlanFromImportResponseSchema
>;
export type SaveDeclarationTypeChoiceResponse = z.infer<
	typeof SaveDeclarationTypeChoiceResponseSchema
>;

export type getDeclarationTypeChoiceResponseV2 = z.infer<
	typeof SaveDeclarationTypeChoiceResponseSchemaV2
>;

export type SaveDeclarationTypeChoiceResponseV2 = z.infer<
	typeof SaveDeclarationTypeChoiceResponseSchemaV2
>;
export type DeclarationTypeChoiceCompanyTypeModel = z.infer<
	typeof DeclarationTypeChoiceCompanyTypeModelSchema
>;
export type DeclarationTypeChoiceCompanyTypeResponse = z.infer<
	typeof DeclarationTypeChoiceCompanyTypeResponseSchema
>;
export type RequirementListModel = z.infer<typeof RequirementListModelSchema>;
export type RequirementListResponse = z.infer<
	typeof RequirementListResponseSchema
>;
export type ZootechnicalSaveDetailModel = z.infer<
	typeof ZootechnicalSaveDetail
>;
export type SaveRequirementModel = z.infer<typeof SaveRequirementModelSchema>;
export type ExciseMotivationListModel = z.infer<
	typeof ExciseMotivationListModelSchema
>;
export type SaveFuelConsumeModel = z.infer<typeof SaveFuelConsumeModelSchema>;
export type SaveFuelConsumeListModel = z.infer<
	typeof SaveFuelConsumeListModelSchema
>;
export type PrintHistoryResponseModel = z.infer<
	typeof PrintHistoryResponseSchema
>;

export const importLogModelSchema = z.object({
	request_id: z.nullable(z.string()),
	response_body: z.nullable(z.string()),
	request_time: z.nullable(z.string()),
});

export const importLogResponseSchema = z.nullable(importLogModelSchema);
export type importLogResponse = z.infer<typeof importLogResponseSchema>;

export const getGiasUsernameModelSchema = z.object({
	username: z.string(),
});

export const getGiasUsernameResponseSchema = z.nullable(
	getGiasUsernameModelSchema
);
export type getGiasUsernameResponse = z.infer<
	typeof getGiasUsernameResponseSchema
>;
