import { BASE } from "@/constants";
import { nextTick } from "vue";
import { createI18n } from "vue-i18n";
import { httpPlus as http } from "@/resources/api/http";
import {
	ErrorType,
	type HttpResponse,
	type HttpResult,
} from "@abaco/safe-rest/src/HTTPClient";

export const DEFAULT_LANGUAGE = "en";

const i18n = createI18n({
	legacy: false,
	locale: DEFAULT_LANGUAGE,
	fallbackLocale: DEFAULT_LANGUAGE,
});

export function setI18nLanguage(locale: string) {
	i18n.global.locale.value = locale;

	/**
	 * NOTE:
	 * If you need to specify the language setting for headers, such as the `fetch` API, set it here.
	 * The following is an example for axios.
	 *
	 * axios.defaults.headers.common['Accept-Language'] = locale
	 */
	document.querySelector("html")?.setAttribute("lang", locale);
}

function getAllLocales(locale: string): Set<string> {
	const ls = locale.split("-");
	const locales = new Set<string>([DEFAULT_LANGUAGE]);
	let loc = "";
	for (let i = 0; i < ls.length; i++) {
		loc += "-" + ls[i];
		locales.add(loc.slice(1));
	}
	return locales;
}

export async function loadLocaleMessages(locale: string) {
	for (const lc of getAllLocales(locale)) {
		let use = BASE;
		if (BASE.slice(-1) === "/") {
			use = BASE.slice(0, -1);
		}
		const res: HttpResult = await http.cleanGet(`${use}/locales/${lc}.json`);
		if (res.errorType === ErrorType.NONE) {
			const messages = await (res as HttpResponse).response.json();
			i18n.global.setLocaleMessage(lc, messages);
		}
	}
	setI18nLanguage(locale);
	return nextTick();
}

export default i18n;
