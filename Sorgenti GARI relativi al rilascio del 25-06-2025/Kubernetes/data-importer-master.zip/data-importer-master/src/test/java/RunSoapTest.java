import com.abacogroup.gari.dataimporter.soap.OprFascicoloFS6ServiceName;
import com.abacogroup.gari.dataimporter.soap.fascicolo.*;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.net.URL;

public class RunSoapTest {
	private static SOAPAutenticazione soapAutenticazione;

	public static void main(String[] args) throws JsonProcessingException {
		ObjectFactory objectFactory = new ObjectFactory();
		URL url = RunSoapTest.class.getResource("/wsdl/OprFascicoloFS6.wsdl");
		OprFascicoloFS6 oprFascicoloFS6_TEST = new OprFascicoloFS6(url);
		InterService serviceLocalWSDL = oprFascicoloFS6_TEST.getOprFascicoloFS6();
		soapAutenticazione = objectFactory.createSOAPAutenticazione();
		soapAutenticazione.setUsername("wspddusrrgmbrkron");
		soapAutenticazione.setPassword("krypto.739A");

		soapAutenticazione.setNomeServizio(OprFascicoloFS6ServiceName.TROVAFASCICOLOFS6);
		ISWSToOprResponse result = serviceLocalWSDL.trovaFascicoloFS6("CLTPTR49D17C745Z",
				soapAutenticazione);

		// soapAutenticazione.setNomeServizio(OprFascicoloFS6ServiceName.LEGGIALLEVAMENTIFS6);
		// ISWSToOprResponse result = serviceLocalWSDL.leggiAllevamentiFS6("03719120549",
		// soapAutenticazione);

		ObjectMapper mapper = new ObjectMapper();
		System.out.println(mapper.writeValueAsString(result));

	}
}
