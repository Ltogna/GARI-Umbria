import com.abacogroup.gari.dataimporter.DataImporterApplication;

public class RunDbMigrate {
    public static void main(String[] args) throws Exception {
        DataImporterApplication.main(new String[] { "db", "migrate", "config.yml" });
    }
}
