import com.abacogroup.gari.dataimporter.DataImporterApplication;

public class Run {
    public static void main(String[] args) throws Exception {
        DataImporterApplication.main(new String[] { "server", "config.yml" });
    }
}
