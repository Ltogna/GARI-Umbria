package com.abacogroup.gari.dataimporter.services;

import java.io.ByteArrayOutputStream;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.Month;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.util.Locale;
import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.filestore.client.auth.Sso2Authenticator;
import com.abacogroup.jdbi.paging.PagingParams;

/**
 * 
 * @author Emanuele Crocilla
 *
 */
public abstract class AbstractServiceTest {

	protected static final String TENANT = "master";
	protected static final int BUSINESS_ID = 2;
	protected static final String CUAA = "031390005453322"; //original =>03139000545 | test=> 031390005453322
	protected static final String CROP_PLAN_TYPE_CODE = "CROP_PLAN";
	protected static final int CROP_PLAN_ID = 18;

	protected static final String LOGGED_USER_ID = "user1";
	protected static final User LOGGED_USER = new User(LOGGED_USER_ID, TENANT);
	protected static final String MSG_EXC = "DON'T WORRY, THIS IS JUST A TEST TO VERIFY THAT AN EXCEPTION IS LAUNCHED";

	protected static final String AUTH_TOKEN = "Auth Token";
	protected static final String USERNAME = "Username";
	protected static final User USER = new User(USERNAME, AUTH_TOKEN, TENANT, USERNAME);
}
