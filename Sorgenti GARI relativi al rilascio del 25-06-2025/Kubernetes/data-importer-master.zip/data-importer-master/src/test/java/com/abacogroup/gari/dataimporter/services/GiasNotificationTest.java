package com.abacogroup.gari.dataimporter.services;

//MOCKITO

import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.io.OutputStream;
import java.net.InetSocketAddress;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.Mock.Strictness;
import org.mockito.junit.jupiter.MockitoExtension;

import com.abacogroup.dropwizard.auth.sso2.Sso2Client;
import com.abacogroup.gari.dataimporter.DataImporterConfiguration;
import com.abacogroup.gari.dataimporter.DTOs.PartyResponse;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sun.net.httpserver.HttpServer;

import jakarta.ws.rs.client.Client;
import jakarta.ws.rs.client.ClientBuilder;

@ExtendWith(MockitoExtension.class)
public class GiasNotificationTest extends AbstractServiceTest {
	private static final int SERVER_PORT = 8089;
	private static HttpServer httpServer;
	private static final String CUAA_ANA = "BNNMRZ59M19H501E";
	@Mock(strictness = Strictness.LENIENT)
	private static CropPlanService cropPlanService;

	@BeforeAll
	static void setUp() throws IOException {
		httpServer = HttpServer.create(new InetSocketAddress(SERVER_PORT), 0);
		httpServer.start();
		Client client = ClientBuilder.newClient();
		DataImporterConfiguration config = new DataImporterConfiguration();
		config.setCropPlanUrl("http://localhost:" + SERVER_PORT + "/mock-crop-plans");
		config.setPartyRegistry("http://localhost:" + SERVER_PORT + "/mock-party-registry");

		config.setSso2Url("https://umbria-dev.fe.abacogroup.eu/sso2");
		config.setSso2TokenSecretAuth("{SSO2_TOKENS_AUTH_SECRET:-f3831a034cfd85301170f6395d7c3386}");
		Sso2Client sso2Client = new Sso2Client(config.getSso2TokenSecretAuth(), client.target(config.getSso2Url()));
		cropPlanService = new CropPlanService(sso2Client, client, config, new ObjectMapper(), null);

	}

	@AfterAll
	static void tearDown() {
		httpServer.stop(0);
	}

	@Test
	void testGetAnagrafica_Success() throws Exception {
		when(cropPlanService.getAuthToken(TENANT)).thenReturn("");
		when(cropPlanService.getParty(TENANT, CUAA_ANA)).thenReturn(BM);
		when(cropPlanService.findAnagraficaByCuaa(USER, TENANT, CUAA_ANA)).thenCallRealMethod();
		httpServer.createContext("/mock-party-registry/" + TENANT + "/public/v1/parties/code/" + CUAA_ANA,
				exchange -> {
					String query = exchange.getRequestURI().toString();
					if (query != null && query.contains("/" + CUAA_ANA)) {
						exchange.getResponseHeaders().add("Content-Type", "application/json");
						exchange.sendResponseHeaders(200, BUSINESSMODAL.getBytes().length);
						OutputStream os = exchange.getResponseBody();
						os.write(BUSINESSMODAL.getBytes());
						os.close();
					} else {
						exchange.sendResponseHeaders(404, -1);
					}
				});

		var result = cropPlanService.findAnagraficaByCuaa(USER, TENANT, CUAA_ANA);
		// Asserts
		assertNotNull(result);
	}
	// @Test
	// void testGetAnagraficaList_Success() throws Exception {
	// httpServer.createContext("/mock-party-registry/" + TENANT + "/public/v1/parties/code/" + CUAA_ANA,
	// exchange -> {
	// String query = exchange.getRequestURI().toString();
	// if (query != null && query.contains("/"+CUAA_ANA)) {
	// exchange.getResponseHeaders().add("Content-Type", "application/json");
	// exchange.sendResponseHeaders(200, BUSINESSMODAL.getBytes().length);
	// OutputStream os = exchange.getResponseBody();
	// os.write(BUSINESSMODAL.getBytes());
	// os.close();
	// } else {
	// exchange.sendResponseHeaders(404, -1);
	// }
	// });
	// var result = cropPlanService.findAnagraficaListByCuaa(USER, TENANT, CUAA_ANA, null,null);
	// // Asserts
	// assertNotNull(result);
	// }

	public static final PartyResponse BM = PartyResponse.builder()
			.id(7)
			.partyType("N")
			.gender("M")
			.lastName("BENNATI")
			.firstName("MAURIZIO")
			.taxCode("BNNMRZ59M19H501E")
			.vatNumber(null)
			.code("BNNMRZ59M19H501E")
			.legalStatus("ALTRI")
			.birthDate("19590819")
			.deathDate(null)
			.birthMunicipality(null)
			.birthMunicipalityDetail(null)
			.nationality(null)
			.addressResidential(PartyResponse.Address.builder()
					.id(1)
					.municipality("ITA_10_054009")
					.locality(null)
					.street("LOCALITA' MERCANZIA N 27 B")
					.houseNumber(null)
					.postcode("06061")
					.details(null)
					.note(null)
					.municipalityI18nCode(null)
					.municipalityDetail(PartyResponse.MunicipalityDetail.builder()
							.code("ITA_10_054009")
							.tenantId("master")
							.districtCode("ITA_10_054")
							.shortDescr("C309")
							.active(true)
							.i18nName("Castiglione del Lago")
							.district(PartyResponse.MunicipalityDetail.District.builder()
									.code("ITA_10_054")
									.tenantId("master")
									.regionCode("ITA_10")
									.shortDescr("PG")
									.active(true)
									.i18nName("Perugia")
									.region(PartyResponse.MunicipalityDetail.District.Region.builder()
											.code("ITA_10")
											.tenantId("master")
											.countryCode("ITA")
											.shortDescr("10")
											.active(true)
											.i18nName("Umbria")
											.country(PartyResponse.MunicipalityDetail.District.Region.Country.builder()
													.code("ITA")
													.tenantId("master")
													.active(true)
													.i18nName("Italy")
													.build())
											.build())
									.build())
							.build())
					.build())
			.addressHome(null)
			.addressBilling(null)
			.archived(false)
			.externalSource(PartyResponse.ExternalSource.builder()
					.code("SIAN")
					.allowManual(true)
					.description("SIAN Parties registry")
					.build())
			.build();
	public static final String BUSINESSMODAL = "{\n"
			+ "  \"id\" : 7,\n"
			+ "  \"partyType\" : \"N\",\n"
			+ "  \"gender\" : \"M\",\n"
			+ "  \"lastName\" : \"BENNATI\",\n"
			+ "  \"firstName\" : \"MAURIZIO\",\n"
			+ "  \"taxCode\" : \"BNNMRZ59M19H501E\",\n"
			+ "  \"vatNumber\" : null,\n"
			+ "  \"code\" : \"BNNMRZ59M19H501E\",\n"
			+ "  \"legalStatus\" : \"ALTRI\",\n"
			+ "  \"birthDate\" : \"19590819\",\n"
			+ "  \"deathDate\" : null,\n"
			+ "  \"birthMunicipality\" : null,\n"
			+ "  \"birthMunicipalityDetail\" : null,\n"
			+ "  \"nationality\" : null,\n"
			+ "  \"addressResidential\" : {\n"
			+ "    \"id\" : 1,\n"
			+ "    \"municipality\" : \"ITA_10_054009\",\n"
			+ "    \"locality\" : null,\n"
			+ "    \"street\" : \"LOCALITA' MERCANZIA N 27 B\",\n"
			+ "    \"houseNumber\" : null,\n"
			+ "    \"postcode\" : \"06061\",\n"
			+ "    \"details\" : null,\n"
			+ "    \"note\" : null,\n"
			+ "    \"municipalityI18nCode\" : null,\n"
			+ "    \"municipalityDetail\" : {\n"
			+ "      \"code\" : \"ITA_10_054009\",\n"
			+ "      \"tenantId\" : \"master\",\n"
			+ "      \"districtCode\" : \"ITA_10_054\",\n"
			+ "      \"shortDescr\" : \"C309\",\n"
			+ "      \"active\" : true,\n"
			+ "      \"i18nName\" : \"Castiglione del Lago\",\n"
			+ "      \"district\" : {\n"
			+ "        \"code\" : \"ITA_10_054\",\n"
			+ "        \"tenantId\" : \"master\",\n"
			+ "        \"regionCode\" : \"ITA_10\",\n"
			+ "        \"shortDescr\" : \"PG\",\n"
			+ "        \"active\" : true,\n"
			+ "        \"i18nName\" : \"Perugia\",\n"
			+ "        \"region\" : {\n"
			+ "          \"code\" : \"ITA_10\",\n"
			+ "          \"tenantId\" : \"master\",\n"
			+ "          \"countryCode\" : \"ITA\",\n"
			+ "          \"shortDescr\" : \"10\",\n"
			+ "          \"active\" : true,\n"
			+ "          \"i18nName\" : \"Umbria\",\n"
			+ "          \"country\" : {\n"
			+ "            \"code\" : \"ITA\",\n"
			+ "            \"tenantId\" : \"master\",\n"
			+ "            \"active\" : true,\n"
			+ "            \"i18nName\" : \"Italy\"\n"
			+ "          }\n"
			+ "        }\n"
			+ "      }\n"
			+ "    }\n"
			+ "  },\n"
			+ "  \"addressHome\" : null,\n"
			+ "  \"addressBilling\" : null,\n"
			+ "  \"tags\" : [ ],\n"
			+ "  \"archived\" : false,\n"
			+ "  \"externalSource\" : {\n"
			+ "    \"code\" : \"SIAN\",\n"
			+ "    \"allowManual\" : true,\n"
			+ "    \"description\" : \"SIAN Parties registry\"\n"
			+ "  }\n"
			+ "}";

}
