package com.abacogroup.gari.dataimporter.services;

import com.abacogroup.gari.dataimporter.DataImporterConfiguration;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sun.net.httpserver.HttpServer;
import jakarta.ws.rs.client.Client;
import jakarta.ws.rs.client.ClientBuilder;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import java.io.IOException;
import java.io.OutputStream;
import java.net.InetSocketAddress;

import static org.junit.Assert.assertNotNull;

public class PCGServiceTest extends AbstractServiceTest {
	private static final int SERVER_PORT = 8089;
	private static HttpServer httpServer;
	private static final String CUAA_ANA = "BNNMRZ59M19H501E";

	private static CropPlanService cropPlanService;

	@BeforeAll
	static void setUp() throws IOException {
		httpServer = HttpServer.create(new InetSocketAddress(SERVER_PORT), 0);
		httpServer.start();
		Client client = ClientBuilder.newClient();
		DataImporterConfiguration config = new DataImporterConfiguration();
		config.setCropPlanUrl("http://localhost:" + SERVER_PORT + "/mock-crop-plans");
		config.setPartyRegistry("http://localhost:" + SERVER_PORT + "/mock-party-registry");
		cropPlanService = new CropPlanService(null, client, config, new ObjectMapper(), null	);
	}
	@AfterAll
	static void tearDown() {
		httpServer.stop(0);
	}
//
//	@Test
//	void testGetAnagrafica_Success() throws Exception {
//		httpServer.createContext("/mock-crop-plans/" + TENANT + "/public/v1/parties/code/" + CUAA_ANA,
//				exchange -> {
//					String query = exchange.getRequestURI().getQuery();
//					if (query != null && query.contains("anagrafica/"+CUAA_ANA)) {
//						String response = "{"
//								+ "\"cuaa\":\"BNNMRZ59M19H501E\","
//								+ "\"tipo_anagrafica\":\"P\","
//								+ "\"denominazione\":\"BENNATI MAURIZIO\","
//								+ "\"codice_fiscale\":\"BNNMRZ59M19H501E\","
//								+ "\"partita_iva\":null,"
//								+ "\"sede\":{"
//								+ "\"codice_belfiore\":\"C309\","
//								+ "\"comune\":\"Castiglione del Lago\","
//								+ "\"indirizzo\":\"LOCALITA' MERCANZIA N 27 B \","
//								+ "\"cap\":\"06061\""
//								+ "},"
//								+ "\"centro_aziendale\":null,"
//								+ "\"codice_op\":null,"
//								+ "\"codice_detentore\":null,"
//								+ "\"ultimo_aggiornamento\":null"
//								+ "}";
//
//						exchange.getResponseHeaders().add("Content-Type", "application/json");
//						exchange.sendResponseHeaders(200, response.getBytes().length);
//						OutputStream os = exchange.getResponseBody();
//						os.write(response.getBytes());
//						os.close();
//					} else {
//						exchange.sendResponseHeaders(404, -1);
//					}
//				});
//
//		var result = cropPlanService.findAnagraficaByCuaa(USER, TENANT, CUAA_ANA, null);
//		// Asserts
//		assertNotNull(result);
//	}
//	@Test
//	void testGetAnagraficaList_Success() throws Exception {
//		httpServer.createContext("/mock-crop-plans/" + TENANT + "/public/v1/parties/code/" + CUAA_ANA,
//				exchange -> {
//					String query = exchange.getRequestURI().getQuery();
//					if (query != null && query.contains("anagrafica/"+CUAA_ANA)) {
//						String response = "{"
//								+ "\"cuaa\":\"BNNMRZ59M19H501E\","
//								+ "\"tipo_anagrafica\":\"P\","
//								+ "\"denominazione\":\"BENNATI MAURIZIO\","
//								+ "\"codice_fiscale\":\"BNNMRZ59M19H501E\","
//								+ "\"partita_iva\":null,"
//								+ "\"sede\":{"
//								+ "\"codice_belfiore\":\"C309\","
//								+ "\"comune\":\"Castiglione del Lago\","
//								+ "\"indirizzo\":\"LOCALITA' MERCANZIA N 27 B \","
//								+ "\"cap\":\"06061\""
//								+ "},"
//								+ "\"centro_aziendale\":null,"
//								+ "\"codice_op\":null,"
//								+ "\"codice_detentore\":null,"
//								+ "\"ultimo_aggiornamento\":null"
//								+ "}";
//
//						exchange.getResponseHeaders().add("Content-Type", "application/json");
//						exchange.sendResponseHeaders(200, response.getBytes().length);
//						OutputStream os = exchange.getResponseBody();
//						os.write(response.getBytes());
//						os.close();
//					} else {
//						exchange.sendResponseHeaders(404, -1);
//					}
//				});
//
//		var result = cropPlanService.findAnagraficaListByCuaa(USER, TENANT, CUAA_ANA, null,null);
//		// Asserts
//		assertNotNull(result);
//	}

}