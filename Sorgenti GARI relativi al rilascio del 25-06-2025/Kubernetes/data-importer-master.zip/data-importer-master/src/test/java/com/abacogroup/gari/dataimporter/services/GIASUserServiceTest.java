package com.abacogroup.gari.dataimporter.services;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.mockStatic;

import java.io.IOException;
import java.net.InetSocketAddress;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.mockito.Mock.Strictness;

import com.abacogroup.dropwizard.auth.sso2.Sso2Client;
import com.abacogroup.gari.dataimporter.DataImporterConfiguration;
import com.abacogroup.gari.dataimporter.utils.GiasUsersResourceManager;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sun.net.httpserver.HttpServer;

import jakarta.ws.rs.client.Client;
import jakarta.ws.rs.client.ClientBuilder;

/**
 * Test unitari per la classe GIASService
 * 
 * @author Emanuele Crocilla
 *
 */
public class GIASUserServiceTest {

    private GIASUserService giasService;
    private GiasUsersResourceManager resourceManager;
    private static final int SERVER_PORT = 8089;
	private static HttpServer httpServer;
	private static final String CUAA_ANA = "BNNMRZ59M19H501E";
	@Mock(strictness = Strictness.LENIENT)
	private static CropPlanService cropPlanService;
	

//    @BeforeEach
    public void setUp() throws IOException {
    	httpServer = HttpServer.create(new InetSocketAddress(SERVER_PORT), 0);
    	httpServer.start();
    	Client client = ClientBuilder.newClient();
    	DataImporterConfiguration config = new DataImporterConfiguration();
    	config.setCropPlanUrl("http://localhost:" + SERVER_PORT + "/mock-crop-plans");
    	config.setPartyRegistry("http://localhost:" + SERVER_PORT + "/mock-party-registry");

    	config.setSso2Url("https://umbria-dev.fe.abacogroup.eu/sso2");
    	config.setSso2TokenSecretAuth("{SSO2_TOKENS_AUTH_SECRET:-f3831a034cfd85301170f6395d7c3386}");
    	Sso2Client sso2Client = new Sso2Client(config.getSso2TokenSecretAuth(), client.target(config.getSso2Url()));
    	cropPlanService = new CropPlanService(sso2Client, client, config, new ObjectMapper(), null);
        giasService = new GIASUserService(sso2Client, new ObjectMapper(), null, config, client);
        resourceManager = Mockito.mock(GiasUsersResourceManager.class);
    }

    /**
     * Test del caso in cui viene trovato un utente GIAS corrispondente all'utente AGRI
     */
//    @Test
    public void testGetGiasUser_whenGiasUserFound() {
        String agriUserName = "agriUser123";
        String expectedGiasUserName = "giasUser456";

        // Mock del singleton GiasUsersResourceManager
        try (MockedStatic<GiasUsersResourceManager> mockedResourceManager = mockStatic(GiasUsersResourceManager.class)) {

        	mockedResourceManager.when(GiasUsersResourceManager::getInstance).thenReturn(resourceManager);
            
            Mockito.when(resourceManager.getGiasUserByAgriUser(agriUserName)).thenReturn(expectedGiasUserName);

            String result = giasService.getGiasUserByAgriUser(agriUserName);

            assertEquals(expectedGiasUserName, result);
        }
    }

    /**
     * Test del caso in cui non viene trovato un utente GIAS corrispondente all'utente AGRI
     */
//    @Test
    public void testGetGiasUser_whenGiasUserNotFound() {
        String agriUserName = "agriUser123";

        // Mock del singleton GiasUsersResourceManager
        try (MockedStatic<GiasUsersResourceManager> mockedResourceManager = mockStatic(GiasUsersResourceManager.class)) {

        	mockedResourceManager.when(GiasUsersResourceManager::getInstance).thenReturn(resourceManager);

            Mockito.when(resourceManager.getGiasUserByAgriUser(agriUserName)).thenReturn(null);

            String result = giasService.getGiasUserByAgriUser(agriUserName);

            assertEquals(agriUserName, result);
        }
    }
  
}
