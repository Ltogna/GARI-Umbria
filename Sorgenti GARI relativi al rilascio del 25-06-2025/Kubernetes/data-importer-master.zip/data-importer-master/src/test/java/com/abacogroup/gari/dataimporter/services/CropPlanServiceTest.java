package com.abacogroup.gari.dataimporter.services;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.Month;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.util.Locale;

import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.filestore.client.auth.Sso2Authenticator;
import com.abacogroup.gari.dataimporter.DTOs.VersionRequest;
import com.abacogroup.gari.dataimporter.DataImporterConfiguration;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.jdbi.paging.PagingParams;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sun.net.httpserver.HttpServer;
import jakarta.ws.rs.client.Client;
import jakarta.ws.rs.client.ClientBuilder;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

public class CropPlanServiceTest extends AbstractServiceTest {
	private static final int SERVER_PORT = 8089;
	private static HttpServer httpServer;

	private static CropPlanService cropPlanService;

	@BeforeAll
	static void setUp() throws IOException {
		httpServer = HttpServer.create(new InetSocketAddress(SERVER_PORT), 0);
		httpServer.start();
		Client client = ClientBuilder.newClient();
		DataImporterConfiguration config = new DataImporterConfiguration();
		config.setCropPlanUrl("http://localhost:" + SERVER_PORT + "/mock-crop-plans");
		config.setPartyRegistry("http://localhost:" + SERVER_PORT + "/mock-party-registry");
		cropPlanService = new CropPlanService(null, client, config, new ObjectMapper(), null	);
	}
	@AfterAll
	static void tearDown() {
		httpServer.stop(0);
	}

//	@Test
//	void testGetCropPlans_Success() throws Exception {
//		httpServer.createContext("/mock-crop-plans/" + TENANT + "/public/v1/crop-plans/" + BUSINESS_ID + "/plans",
//				exchange -> {
//					String cropPlanTypeCode = exchange.getRequestURI().getQuery();
//					if (cropPlanTypeCode != null && cropPlanTypeCode.contains("cropPlanTypeCode="+CROP_PLAN_TYPE_CODE)) {
//						String response = "{\"count\":1,\"records\":[]}";
//						exchange.getResponseHeaders().add("Content-Type", "application/json");
//						exchange.sendResponseHeaders(200, response.getBytes().length);
//						OutputStream os = exchange.getResponseBody();
//						os.write(response.getBytes());
//						os.close();
//					} else {
//						exchange.sendResponseHeaders(404, -1);
//					}
//				});
//
//		var result = cropPlanService.getCropPlans(USER, TENANT, BUSINESS_ID, CROP_PLAN_TYPE_CODE);
//		// Asserts
//		assertNotNull(result);
//		assertEquals(1, result.getCount());
//	}
//	@Test
//	void testGetParty_Success() throws Exception {
//		httpServer.createContext("/mock-party-registry/" + TENANT + "/parties/code/" + CUAA ,
//				exchange -> {
//					String cropPlanTypeCode = exchange.getRequestURI().getQuery();
//					if (cropPlanTypeCode != null && cropPlanTypeCode.contains("cropPlanTypeCode="+CROP_PLAN_TYPE_CODE)) {
//						String response = "{\"id\":2,\"partyType\":1,\"vatNumber\":'031390005453322',\"code\":'Crop Plan UT'}";
//						exchange.getResponseHeaders().add("Content-Type", "application/json");
//						exchange.sendResponseHeaders(200, response.getBytes().length);
//						OutputStream os = exchange.getResponseBody();
//						os.write(response.getBytes());
//						os.close();
//					} else {
//						exchange.sendResponseHeaders(404, -1);
//					}
//				});
//		var result = cropPlanService.getParty(TENANT, CUAA);
//		// Asserts
//		assertNotNull(result);
//		assertEquals(2, result.getId());
//	}
//	@Test
//	void testGetVersionCropPlan_Success() throws Exception {
//		httpServer.createContext("/mock-crop-plans/" + TENANT + "/public/v1/crop-plans/" + BUSINESS_ID + "/plans/"+CROP_PLAN_ID+"/versions",
//				exchange -> {
//					String cropPlanTypeCode = exchange.getRequestURI().getQuery();
//					if (cropPlanTypeCode != null && cropPlanTypeCode.contains("cropPlanTypeCode="+CROP_PLAN_TYPE_CODE)) {
//						String response = "{\"count\":1,\"records\":[{\"version\":11,\"versionDate\":20241212,\"message\":'Hello World!'}]}";
//						exchange.getResponseHeaders().add("Content-Type", "application/json");
//						exchange.sendResponseHeaders(200, response.getBytes().length);
//						OutputStream os = exchange.getResponseBody();
//						os.write(response.getBytes());
//						os.close();
//					} else {
//						exchange.sendResponseHeaders(404, -1);
//					}
//				});
//		var result = cropPlanService.getVersionCropPlan(USER, TENANT, BUSINESS_ID,CROP_PLAN_ID,9999999);
//		// Asserts
//		assertNotNull(result);
//		assertEquals(1, result.getRecords());
//	}
//	@Test
//	void testCreateVersionCropPlan_Success() throws Exception {
//		httpServer.createContext("/mock-crop-plans/" + TENANT + "/public/v1/crop-plans/" + BUSINESS_ID + "/plans/"+CROP_PLAN_ID+"/versions",
//				exchange -> {
//					String cropPlanTypeCode = exchange.getRequestURI().getQuery();
//					if (cropPlanTypeCode != null && cropPlanTypeCode.contains("cropPlanTypeCode="+CROP_PLAN_TYPE_CODE)) {
//						String response = "{\"version\":11,\"versionDate\":20241212,\"message\":'Hello World!'}";
//						exchange.getResponseHeaders().add("Content-Type", "application/json");
//						exchange.sendResponseHeaders(200, response.getBytes().length);
//						OutputStream os = exchange.getResponseBody();
//						os.write(response.getBytes());
//						os.close();
//					} else {
//						exchange.sendResponseHeaders(404, -1);
//					}
//				});
//		VersionRequest versionRequest = VersionRequest.builder().message("Hello World!").havingAcknowledgedAnomalies(false)
//				.pointInTime(AbsoluteDate.of(LocalDate.now()).toString()).build();
//		var result = cropPlanService.createVersionCropPlan(USER, TENANT, BUSINESS_ID, CROP_PLAN_ID, versionRequest);
//		// Asserts
//		assertNotNull(result);
//		assertEquals("20241212", result.getVersion());
//	}
//	@Test
//	void testLockCropPlan_Success() throws Exception {
//		httpServer.createContext("/mock-crop-plans/" + TENANT + "/public/v1/crop-plans/" + BUSINESS_ID + "/plans/"+CROP_PLAN_ID+"/lock",
//				exchange -> {
//					String cropPlanTypeCode = exchange.getRequestURI().getQuery();
//					if (cropPlanTypeCode != null && cropPlanTypeCode.contains("cropPlanTypeCode="+CROP_PLAN_TYPE_CODE)) {
//						String response = "";
//						exchange.getResponseHeaders().add("Content-Type", "application/json");
//						exchange.sendResponseHeaders(200, response.getBytes().length);
//						OutputStream os = exchange.getResponseBody();
//						os.write(response.getBytes());
//						os.close();
//					} else {
//						exchange.sendResponseHeaders(404, -1);
//					}
//				});
//		var result = cropPlanService.lockCropPlan(TENANT, BUSINESS_ID,CROP_PLAN_ID);
//		// Asserts
//		assertNotNull(result);
//	}


}