package com.abacogroup.gari.dataimporter.services;

import com.abacogroup.gari.dataimporter.DTOs.VersionRequest;
import com.abacogroup.gari.dataimporter.DataImporterConfiguration;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sun.net.httpserver.HttpServer;
import jakarta.ws.rs.client.Client;
import jakarta.ws.rs.client.ClientBuilder;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import java.io.IOException;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.time.LocalDate;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

public class PartyRegistryTest extends AbstractServiceTest {
	private static final int SERVER_PORT = 8089;
	private static HttpServer httpServer;

	private static CropPlanService cropPlanService;

	@BeforeAll
	static void setUp() throws IOException {
		httpServer = HttpServer.create(new InetSocketAddress(SERVER_PORT), 0);
		httpServer.start();
		Client client = ClientBuilder.newClient();
		DataImporterConfiguration config = new DataImporterConfiguration();
		config.setCropPlanUrl("http://localhost:" + SERVER_PORT + "/mock-crop-plans");
		config.setPartyRegistry("http://localhost:" + SERVER_PORT + "/mock-party-registry");
		cropPlanService = new CropPlanService(null, client, config, new ObjectMapper(), null	);
	}
	@AfterAll
	static void tearDown() {
		httpServer.stop(0);
	}

}