package com.abacogroup.gari.dataimporter.controllers;

import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.gari.dataimporter.DTOs.SyncNotificationRequest;
import com.abacogroup.gari.dataimporter.DTOs.SyncNotificationResponse;
import com.abacogroup.gari.dataimporter.services.GIASNotificationService;
import io.dropwizard.auth.Auth;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;

@Path("/{tenant}/public/v1")
@Produces(MediaType.APPLICATION_JSON)
public class NotificationController {
	private final GIASNotificationService service;

	public NotificationController(GIASNotificationService _service) {
		this.service = _service;
	}

	@PUT
	@Path("/sync/{ulid}")
	public SyncNotificationResponse Sync(
			@Auth User user,
			@PathParam("tenant") String tenant,
			@PathParam("ulid") String ulid,
			SyncNotificationRequest request) {
		return service.sync(user, tenant, ulid, request);
	}
}
