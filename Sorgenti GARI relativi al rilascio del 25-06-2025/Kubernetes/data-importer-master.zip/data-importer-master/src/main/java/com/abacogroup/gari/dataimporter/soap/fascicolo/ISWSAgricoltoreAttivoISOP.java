
package com.abacogroup.gari.dataimporter.soap.fascicolo;

import javax.xml.datatype.XMLGregorianCalendar;
import jakarta.xml.bind.JAXBElement;
import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlElementRef;
import jakarta.xml.bind.annotation.XmlRootElement;
import jakarta.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="CUAA" type="{http://cooperazione.sian.it/schema/fascicolo}Cuaa"/&gt;
 *         &lt;element name="AnnoCampagna"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}gYear"&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="TipoSoggetto" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;enumeration value="B02"/&gt;
 *               &lt;enumeration value="I01"/&gt;
 *               &lt;enumeration value="I02"/&gt;
 *               &lt;enumeration value="I03"/&gt;
 *               &lt;enumeration value="I04"/&gt;
 *               &lt;enumeration value="I05"/&gt;
 *               &lt;enumeration value="I06"/&gt;
 *               &lt;enumeration value="I07"/&gt;
 *               &lt;enumeration value="I08"/&gt;
 *               &lt;enumeration value="I09"/&gt;
 *               &lt;enumeration value="I10"/&gt;
 *               &lt;enumeration value="I11"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="TipoEntePPAA" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;enumeration value="AA4a"/&gt;
 *               &lt;enumeration value="AA4b"/&gt;
 *               &lt;enumeration value="AA4c"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="AnnoFiscale"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}gYear"&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="ProventiTotNAg" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;maxLength value="8"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="ProventiTotAg" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;maxLength value="8"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="ProventiTotAgNAg" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;maxLength value="8"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="TipoControllo1" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;enumeration value="AA7"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="TipoControllo2" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;enumeration value="AA8"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "cuaa",
    "annoCampagna",
    "tipoSoggetto",
    "tipoEntePPAA",
    "annoFiscale",
    "proventiTotNAg",
    "proventiTotAg",
    "proventiTotAgNAg",
    "tipoControllo1",
    "tipoControllo2"
})
@XmlRootElement(name = "ISWSAgricoltoreAttivoISOP")
public class ISWSAgricoltoreAttivoISOP {

    @XmlElement(name = "CUAA", required = true)
    protected String cuaa;
    @XmlElement(name = "AnnoCampagna", required = true)
    protected XMLGregorianCalendar annoCampagna;
    @XmlElementRef(name = "TipoSoggetto", namespace = "http://cooperazione.sian.it/schema/fascicolo", type = JAXBElement.class, required = false)
    protected JAXBElement<String> tipoSoggetto;
    @XmlElementRef(name = "TipoEntePPAA", namespace = "http://cooperazione.sian.it/schema/fascicolo", type = JAXBElement.class, required = false)
    protected JAXBElement<String> tipoEntePPAA;
    @XmlElement(name = "AnnoFiscale", required = true)
    protected XMLGregorianCalendar annoFiscale;
    @XmlElementRef(name = "ProventiTotNAg", namespace = "http://cooperazione.sian.it/schema/fascicolo", type = JAXBElement.class, required = false)
    protected JAXBElement<String> proventiTotNAg;
    @XmlElementRef(name = "ProventiTotAg", namespace = "http://cooperazione.sian.it/schema/fascicolo", type = JAXBElement.class, required = false)
    protected JAXBElement<String> proventiTotAg;
    @XmlElementRef(name = "ProventiTotAgNAg", namespace = "http://cooperazione.sian.it/schema/fascicolo", type = JAXBElement.class, required = false)
    protected JAXBElement<String> proventiTotAgNAg;
    @XmlElementRef(name = "TipoControllo1", namespace = "http://cooperazione.sian.it/schema/fascicolo", type = JAXBElement.class, required = false)
    protected JAXBElement<String> tipoControllo1;
    @XmlElementRef(name = "TipoControllo2", namespace = "http://cooperazione.sian.it/schema/fascicolo", type = JAXBElement.class, required = false)
    protected JAXBElement<String> tipoControllo2;

    /**
     * Gets the value of the cuaa property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCUAA() {
        return cuaa;
    }

    /**
     * Sets the value of the cuaa property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCUAA(String value) {
        this.cuaa = value;
    }

    /**
     * Gets the value of the annoCampagna property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getAnnoCampagna() {
        return annoCampagna;
    }

    /**
     * Sets the value of the annoCampagna property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setAnnoCampagna(XMLGregorianCalendar value) {
        this.annoCampagna = value;
    }

    /**
     * Gets the value of the tipoSoggetto property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getTipoSoggetto() {
        return tipoSoggetto;
    }

    /**
     * Sets the value of the tipoSoggetto property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setTipoSoggetto(JAXBElement<String> value) {
        this.tipoSoggetto = value;
    }

    /**
     * Gets the value of the tipoEntePPAA property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getTipoEntePPAA() {
        return tipoEntePPAA;
    }

    /**
     * Sets the value of the tipoEntePPAA property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setTipoEntePPAA(JAXBElement<String> value) {
        this.tipoEntePPAA = value;
    }

    /**
     * Gets the value of the annoFiscale property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getAnnoFiscale() {
        return annoFiscale;
    }

    /**
     * Sets the value of the annoFiscale property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setAnnoFiscale(XMLGregorianCalendar value) {
        this.annoFiscale = value;
    }

    /**
     * Gets the value of the proventiTotNAg property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getProventiTotNAg() {
        return proventiTotNAg;
    }

    /**
     * Sets the value of the proventiTotNAg property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setProventiTotNAg(JAXBElement<String> value) {
        this.proventiTotNAg = value;
    }

    /**
     * Gets the value of the proventiTotAg property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getProventiTotAg() {
        return proventiTotAg;
    }

    /**
     * Sets the value of the proventiTotAg property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setProventiTotAg(JAXBElement<String> value) {
        this.proventiTotAg = value;
    }

    /**
     * Gets the value of the proventiTotAgNAg property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getProventiTotAgNAg() {
        return proventiTotAgNAg;
    }

    /**
     * Sets the value of the proventiTotAgNAg property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setProventiTotAgNAg(JAXBElement<String> value) {
        this.proventiTotAgNAg = value;
    }

    /**
     * Gets the value of the tipoControllo1 property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getTipoControllo1() {
        return tipoControllo1;
    }

    /**
     * Sets the value of the tipoControllo1 property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setTipoControllo1(JAXBElement<String> value) {
        this.tipoControllo1 = value;
    }

    /**
     * Gets the value of the tipoControllo2 property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getTipoControllo2() {
        return tipoControllo2;
    }

    /**
     * Sets the value of the tipoControllo2 property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setTipoControllo2(JAXBElement<String> value) {
        this.tipoControllo2 = value;
    }

}
