
package com.abacogroup.gari.dataimporter.soap.fascicolo;

import javax.xml.datatype.XMLGregorianCalendar;
import javax.xml.namespace.QName;
import jakarta.xml.bind.JAXBElement;
import jakarta.xml.bind.annotation.XmlElementDecl;
import jakarta.xml.bind.annotation.XmlRegistry;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.abacogroup.gari.dataimporter.soap.fascicolo package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _SOAPAutenticazione_QNAME = new QName("http://cooperazione.sian.it/schema/SoapAutenticazione", "SOAPAutenticazione");
    private final static QName _Cuaa_QNAME = new QName("http://cooperazione.sian.it/schema/fascicolo", "Cuaa");
    private final static QName _Giorni_QNAME = new QName("http://cooperazione.sian.it/schema/fascicolo", "Giorni");
    private final static QName _TipoVinc_QNAME = new QName("http://cooperazione.sian.it/schema/fascicolo", "TipoVinc");
    private final static QName _ISWSDatiFascicolo15AggiornaAnagrafe_QNAME = new QName("http://cooperazione.sian.it/schema/fascicolo", "aggiornaAnagrafe");
    private final static QName _ISWSDatiFascicolo15PEC_QNAME = new QName("http://cooperazione.sian.it/schema/fascicolo", "PEC");
    private final static QName _ISWSDatiFascicolo15Email_QNAME = new QName("http://cooperazione.sian.it/schema/fascicolo", "Email");
    private final static QName _ISWSDatiFascicolo15Telefono_QNAME = new QName("http://cooperazione.sian.it/schema/fascicolo", "Telefono");
    private final static QName _ISWSDatiFascicolo15TipoDocumento_QNAME = new QName("http://cooperazione.sian.it/schema/fascicolo", "TipoDocumento");
    private final static QName _ISWSDatiFascicolo15CUAADeteCont_QNAME = new QName("http://cooperazione.sian.it/schema/fascicolo", "CUAADeteCont");
    private final static QName _ISWSDatiFascicolo15TipoIncaricoDetentore_QNAME = new QName("http://cooperazione.sian.it/schema/fascicolo", "TipoIncaricoDetentore");
    private final static QName _ISWSDatiFascicolo15DataDeteCont_QNAME = new QName("http://cooperazione.sian.it/schema/fascicolo", "DataDeteCont");
    private final static QName _ISWSDatiFascicolo15TipoIdentificativoScheda_QNAME = new QName("http://cooperazione.sian.it/schema/fascicolo", "TipoIdentificativoScheda");
    private final static QName _ISWSDatiFascicolo15IdentificativoSchedaFascicolo_QNAME = new QName("http://cooperazione.sian.it/schema/fascicolo", "IdentificativoSchedaFascicolo");
    private final static QName _ISWSChiudiSocioTipoLegameAsso_QNAME = new QName("http://cooperazione.sian.it/schema/fascicolo", "TipoLegameAsso");
    private final static QName _DocuFascicoloFattispecie_QNAME = new QName("http://cooperazione.sian.it/schema/fascicolo", "Fattispecie");
    private final static QName _ISWSAgricoltoreAttivoISOPTipoSoggetto_QNAME = new QName("http://cooperazione.sian.it/schema/fascicolo", "TipoSoggetto");
    private final static QName _ISWSAgricoltoreAttivoISOPTipoEntePPAA_QNAME = new QName("http://cooperazione.sian.it/schema/fascicolo", "TipoEntePPAA");
    private final static QName _ISWSAgricoltoreAttivoISOPProventiTotNAg_QNAME = new QName("http://cooperazione.sian.it/schema/fascicolo", "ProventiTotNAg");
    private final static QName _ISWSAgricoltoreAttivoISOPProventiTotAg_QNAME = new QName("http://cooperazione.sian.it/schema/fascicolo", "ProventiTotAg");
    private final static QName _ISWSAgricoltoreAttivoISOPProventiTotAgNAg_QNAME = new QName("http://cooperazione.sian.it/schema/fascicolo", "ProventiTotAgNAg");
    private final static QName _ISWSAgricoltoreAttivoISOPTipoControllo1_QNAME = new QName("http://cooperazione.sian.it/schema/fascicolo", "TipoControllo1");
    private final static QName _ISWSAgricoltoreAttivoISOPTipoControllo2_QNAME = new QName("http://cooperazione.sian.it/schema/fascicolo", "TipoControllo2");
    private final static QName _SoggettoWSCodiSess_QNAME = new QName("http://cooperazione.sian.it/schema/fascicolo", "Codi_sess");
    private final static QName _LivelloCodiceLivello_QNAME = new QName("http://cooperazione.sian.it/schema/fascicolo", "CodiceLivello");
    private final static QName _LivelloCodiceMacrouso_QNAME = new QName("http://cooperazione.sian.it/schema/fascicolo", "CodiceMacrouso");
    private final static QName _LivelloSuperficieDichiarata_QNAME = new QName("http://cooperazione.sian.it/schema/fascicolo", "SuperficieDichiarata");
    private final static QName _LivelloSuperficieRiscontrata_QNAME = new QName("http://cooperazione.sian.it/schema/fascicolo", "SuperficieRiscontrata");
    private final static QName _ISWSToOprResponseRisposta0_QNAME = new QName("http://cooperazione.sian.it/schema/fascicolo", "risposta0");
    private final static QName _ISWSToOprResponseRisposta12_QNAME = new QName("http://cooperazione.sian.it/schema/fascicolo", "risposta12");
    private final static QName _ISWSToOprResponseRisposta15_QNAME = new QName("http://cooperazione.sian.it/schema/fascicolo", "risposta15");
    private final static QName _ISWSToOprResponseRisposta20_QNAME = new QName("http://cooperazione.sian.it/schema/fascicolo", "risposta20");
    private final static QName _ISWSToOprResponseRisposta24_QNAME = new QName("http://cooperazione.sian.it/schema/fascicolo", "risposta24");
    private final static QName _ISWSToOprResponseRisposta28_QNAME = new QName("http://cooperazione.sian.it/schema/fascicolo", "risposta28");
    private final static QName _ISWSToOprResponseRisposta37_QNAME = new QName("http://cooperazione.sian.it/schema/fascicolo", "risposta37");
    private final static QName _ISWSToOprResponseRisposta38_QNAME = new QName("http://cooperazione.sian.it/schema/fascicolo", "risposta38");
    private final static QName _ISWSRiep1TipoConduzione_QNAME = new QName("http://cooperazione.sian.it/schema/fascicolo", "TipoConduzione");
    private final static QName _ISWSRiep1DesConduzione_QNAME = new QName("http://cooperazione.sian.it/schema/fascicolo", "DesConduzione");
    private final static QName _ISWSRiep1NumParticelle_QNAME = new QName("http://cooperazione.sian.it/schema/fascicolo", "NumParticelle");
    private final static QName _ISWSRiep1SuperficieTotale_QNAME = new QName("http://cooperazione.sian.it/schema/fascicolo", "SuperficieTotale");
    private final static QName _ISWSRiepilogoSchedaPartTotaleCondAzienda_QNAME = new QName("http://cooperazione.sian.it/schema/fascicolo", "PartTotaleCondAzienda");
    private final static QName _ISWSRiepilogoSchedaSupTotaleCondAzienda_QNAME = new QName("http://cooperazione.sian.it/schema/fascicolo", "SupTotaleCondAzienda");
    private final static QName _ISWSRiepilogoSchedaSupTotaleOccuAzienda_QNAME = new QName("http://cooperazione.sian.it/schema/fascicolo", "SupTotaleOccuAzienda");
    private final static QName _ISWSRiepilogoSchedaSupTotaleRiscontrataAzienda_QNAME = new QName("http://cooperazione.sian.it/schema/fascicolo", "SupTotaleRiscontrataAzienda");
    private final static QName _ISWSSuoloSchedaCodBelfiore_QNAME = new QName("http://cooperazione.sian.it/schema/fascicolo", "CodBelfiore");
    private final static QName _ISWSSuoloSchedaCodiIstaProv_QNAME = new QName("http://cooperazione.sian.it/schema/fascicolo", "CodiIstaProv");
    private final static QName _ISWSSuoloSchedaCodiIstaComu_QNAME = new QName("http://cooperazione.sian.it/schema/fascicolo", "CodiIstaComu");
    private final static QName _ISWSSuoloSchedaComune_QNAME = new QName("http://cooperazione.sian.it/schema/fascicolo", "Comune");
    private final static QName _ISWSSuoloSchedaSezione_QNAME = new QName("http://cooperazione.sian.it/schema/fascicolo", "Sezione");
    private final static QName _ISWSSuoloSchedaFoglio_QNAME = new QName("http://cooperazione.sian.it/schema/fascicolo", "Foglio");
    private final static QName _ISWSSuoloSchedaParticella_QNAME = new QName("http://cooperazione.sian.it/schema/fascicolo", "Particella");
    private final static QName _ISWSSuoloSchedaSubalterno_QNAME = new QName("http://cooperazione.sian.it/schema/fascicolo", "Subalterno");
    private final static QName _ISWSSuoloSchedaCodiceOccupazioneSuolo_QNAME = new QName("http://cooperazione.sian.it/schema/fascicolo", "CodiceOccupazioneSuolo");
    private final static QName _ISWSSuoloSchedaCodiceDestinazioneUso_QNAME = new QName("http://cooperazione.sian.it/schema/fascicolo", "CodiceDestinazioneUso");
    private final static QName _ISWSSuoloSchedaCodiceUso_QNAME = new QName("http://cooperazione.sian.it/schema/fascicolo", "CodiceUso");
    private final static QName _ISWSSuoloSchedaCodiceQualita_QNAME = new QName("http://cooperazione.sian.it/schema/fascicolo", "CodiceQualita");
    private final static QName _ISWSSuoloSchedaCodiceOccupazioneVarieta_QNAME = new QName("http://cooperazione.sian.it/schema/fascicolo", "CodiceOccupazioneVarieta");
    private final static QName _ISWSSuoloSchedaAnnoImpianto_QNAME = new QName("http://cooperazione.sian.it/schema/fascicolo", "AnnoImpianto");
    private final static QName _ISWSSuoloSchedaTipoAllevamento_QNAME = new QName("http://cooperazione.sian.it/schema/fascicolo", "TipoAllevamento");
    private final static QName _ISWSSuoloSchedaSestoImpiantoSuFila_QNAME = new QName("http://cooperazione.sian.it/schema/fascicolo", "SestoImpiantoSuFila");
    private final static QName _ISWSSuoloSchedaSestoImpiantoTraFile_QNAME = new QName("http://cooperazione.sian.it/schema/fascicolo", "SestoImpiantoTraFile");
    private final static QName _ISWSSuoloSchedaNumeroPiante_QNAME = new QName("http://cooperazione.sian.it/schema/fascicolo", "NumeroPiante");
    private final static QName _ISWSSuoloSchedaSuperficieColtivata_QNAME = new QName("http://cooperazione.sian.it/schema/fascicolo", "SuperficieColtivata");
    private final static QName _ISWSSuoloSchedaDataInizColtivazione_QNAME = new QName("http://cooperazione.sian.it/schema/fascicolo", "DataInizColtivazione");
    private final static QName _ISWSSuoloSchedaDataFineColtivazione_QNAME = new QName("http://cooperazione.sian.it/schema/fascicolo", "DataFineColtivazione");
    private final static QName _ISWSSuoloSchedaEpoca_QNAME = new QName("http://cooperazione.sian.it/schema/fascicolo", "Epoca");
    private final static QName _ISWSSuoloSchedaTipoSemina_QNAME = new QName("http://cooperazione.sian.it/schema/fascicolo", "TipoSemina");
    private final static QName _ISWSSuoloSchedaColturaPrincipale_QNAME = new QName("http://cooperazione.sian.it/schema/fascicolo", "ColturaPrincipale");
    private final static QName _ISWSSuoloSchedaRotazColturale_QNAME = new QName("http://cooperazione.sian.it/schema/fascicolo", "RotazColturale");
    private final static QName _ISWSSuoloSchedaPotenzialeIrriguo_QNAME = new QName("http://cooperazione.sian.it/schema/fascicolo", "PotenzialeIrriguo");
    private final static QName _ISWSSuoloSchedaTipoIrrigazione_QNAME = new QName("http://cooperazione.sian.it/schema/fascicolo", "TipoIrrigazione");
    private final static QName _ISWSSuoloSchedaStruttureAziendali_QNAME = new QName("http://cooperazione.sian.it/schema/fascicolo", "StruttureAziendali");
    private final static QName _ISWSSuoloSchedaCriteriMantenimento_QNAME = new QName("http://cooperazione.sian.it/schema/fascicolo", "CriteriMantenimento");
    private final static QName _ISWSSuoloSchedaQuota_QNAME = new QName("http://cooperazione.sian.it/schema/fascicolo", "Quota");
    private final static QName _ISWSSuoloSchedaPendenza_QNAME = new QName("http://cooperazione.sian.it/schema/fascicolo", "Pendenza");
    private final static QName _ISWSParticelleSchedaFormaConduzione_QNAME = new QName("http://cooperazione.sian.it/schema/fascicolo", "FormaConduzione");
    private final static QName _ISWSParticelleSchedaProtocollo_QNAME = new QName("http://cooperazione.sian.it/schema/fascicolo", "Protocollo");
    private final static QName _ISWSParticelleSchedaProprietario_QNAME = new QName("http://cooperazione.sian.it/schema/fascicolo", "Proprietario");
    private final static QName _ISWSParticelleSchedaFlagCondParz_QNAME = new QName("http://cooperazione.sian.it/schema/fascicolo", "FlagCondParz");
    private final static QName _ISWSParticelleSchedaDataInizCond_QNAME = new QName("http://cooperazione.sian.it/schema/fascicolo", "DataInizCond");
    private final static QName _ISWSParticelleSchedaDataFineCond_QNAME = new QName("http://cooperazione.sian.it/schema/fascicolo", "DataFineCond");
    private final static QName _ISWSParticelleSchedaSupCatastale_QNAME = new QName("http://cooperazione.sian.it/schema/fascicolo", "SupCatastale");
    private final static QName _ISWSParticelleSchedaSupGrafica_QNAME = new QName("http://cooperazione.sian.it/schema/fascicolo", "SupGrafica");
    private final static QName _ISWSParticelleSchedaSupCondotta_QNAME = new QName("http://cooperazione.sian.it/schema/fascicolo", "SupCondotta");
    private final static QName _WsIdoneitaCodDenominazione_QNAME = new QName("http://cooperazione.sian.it/schema/fascicolo", "CodDenominazione");
    private final static QName _WsIdoneitaCodSottozona_QNAME = new QName("http://cooperazione.sian.it/schema/fascicolo", "CodSottozona");
    private final static QName _WsIdoneitaCodVarietale_QNAME = new QName("http://cooperazione.sian.it/schema/fascicolo", "CodVarietale");
    private final static QName _WsIdoneitaCodColore_QNAME = new QName("http://cooperazione.sian.it/schema/fascicolo", "CodColore");
    private final static QName _WsIdoneitaDenominazioneVino_QNAME = new QName("http://cooperazione.sian.it/schema/fascicolo", "DenominazioneVino");
    private final static QName _WsIdoneitaResaApplicata_QNAME = new QName("http://cooperazione.sian.it/schema/fascicolo", "ResaApplicata");
    private final static QName _WsIdoneitaSupeDettagliata_QNAME = new QName("http://cooperazione.sian.it/schema/fascicolo", "SupeDettagliata");
    private final static QName _WsIdoneitaNumeUNAR_QNAME = new QName("http://cooperazione.sian.it/schema/fascicolo", "NumeUNAR");
    private final static QName _WsIdoneitaQtaMaxUvaRivendicabile_QNAME = new QName("http://cooperazione.sian.it/schema/fascicolo", "QtaMaxUvaRivendicabile");
    private final static QName _WsUtilizzoTerraCaba7CodiceProdotto_QNAME = new QName("http://cooperazione.sian.it/schema/fascicolo", "CodiceProdotto");
    private final static QName _WsUtilizzoTerraCaba7CodiceVarieta_QNAME = new QName("http://cooperazione.sian.it/schema/fascicolo", "CodiceVarieta");
    private final static QName _WsUtilizzoTerraCaba7SuperficieEleggibile_QNAME = new QName("http://cooperazione.sian.it/schema/fascicolo", "SuperficieEleggibile");
    private final static QName _WsUtilizzoTerraCaba7CodiceColtivazioneBiologica_QNAME = new QName("http://cooperazione.sian.it/schema/fascicolo", "CodiceColtivazioneBiologica");
    private final static QName _WsUtilizzoTerraCaba7CodiceTipoSemina_QNAME = new QName("http://cooperazione.sian.it/schema/fascicolo", "CodiceTipoSemina");
    private final static QName _WsUtilizzoTerraCaba7CodiceTipoIrrigazione_QNAME = new QName("http://cooperazione.sian.it/schema/fascicolo", "CodiceTipoIrrigazione");
    private final static QName _WsUtilizzoTerraCaba7CodiceProtezioneColture_QNAME = new QName("http://cooperazione.sian.it/schema/fascicolo", "CodiceProtezioneColture");
    private final static QName _WsUtilizzoTerraCaba7CodiceFaseAllevamento_QNAME = new QName("http://cooperazione.sian.it/schema/fascicolo", "CodiceFaseAllevamento");
    private final static QName _WsUtilizzoTerraCaba7CodiceFormaAllevamento_QNAME = new QName("http://cooperazione.sian.it/schema/fascicolo", "CodiceFormaAllevamento");
    private final static QName _WsUtilizzoTerraCaba7FlagColtPrincipale_QNAME = new QName("http://cooperazione.sian.it/schema/fascicolo", "FlagColtPrincipale");
    private final static QName _WsUtilizzoTerraCaba7MantPratiPermanente_QNAME = new QName("http://cooperazione.sian.it/schema/fascicolo", "MantPratiPermanente");
    private final static QName _WsUtilizzoTerraCaba7MantenSupAgricola_QNAME = new QName("http://cooperazione.sian.it/schema/fascicolo", "MantenSupAgricola");
    private final static QName _WsUtilizzoTerraCaba7SuperficieEleggibileOP_QNAME = new QName("http://cooperazione.sian.it/schema/fascicolo", "SuperficieEleggibileOP");
    private final static QName _WsUtilizzoTerraCaba7TipoImpianto_QNAME = new QName("http://cooperazione.sian.it/schema/fascicolo", "TipoImpianto");
    private final static QName _WsUtilizzoTerraCaba7TipoCertificazione_QNAME = new QName("http://cooperazione.sian.it/schema/fascicolo", "TipoCertificazione");
    private final static QName _WsUtilizzoTerraCaba7Percentuale_QNAME = new QName("http://cooperazione.sian.it/schema/fascicolo", "Percentuale");
    private final static QName _WsUtilizzoTerraCaba7Menzione_QNAME = new QName("http://cooperazione.sian.it/schema/fascicolo", "Menzione");
    private final static QName _WsUtilizzoTerraCaba7TipoUtilizzoOlivo_QNAME = new QName("http://cooperazione.sian.it/schema/fascicolo", "TipoUtilizzoOlivo");
    private final static QName _WsUtilizzoTerraCaba7CapacitaProduttiva_QNAME = new QName("http://cooperazione.sian.it/schema/fascicolo", "CapacitaProduttiva");
    private final static QName _WsUtilizzoTerraCaba7Altitudine_QNAME = new QName("http://cooperazione.sian.it/schema/fascicolo", "Altitudine");
    private final static QName _WsUtilizzoTerraCaba7FlagProduzioneIntegrata_QNAME = new QName("http://cooperazione.sian.it/schema/fascicolo", "FlagProduzioneIntegrata");
    private final static QName _ISWSIndicatoriCodiceNormativa_QNAME = new QName("http://cooperazione.sian.it/schema/fascicolo", "CodiceNormativa");
    private final static QName _ISWSIndicatoriNormativaRiferimento_QNAME = new QName("http://cooperazione.sian.it/schema/fascicolo", "NormativaRiferimento");
    private final static QName _ISWSIndicatoriDescrizione_QNAME = new QName("http://cooperazione.sian.it/schema/fascicolo", "Descrizione");
    private final static QName _ISWSIndicatoriDataValidita_QNAME = new QName("http://cooperazione.sian.it/schema/fascicolo", "DataValidita");
    private final static QName _ISWSIndicatoriStatoIndicatore_QNAME = new QName("http://cooperazione.sian.it/schema/fascicolo", "StatoIndicatore");
    private final static QName _ISWSUtilizzoTerra15SuperficieEligibile_QNAME = new QName("http://cooperazione.sian.it/schema/fascicolo", "superficieEligibile");
    private final static QName _ISWSUtilizzoTerra15SuperficieEligibileOP_QNAME = new QName("http://cooperazione.sian.it/schema/fascicolo", "superficieEligibileOP");
    private final static QName _ISWSDettaglioUtilizzoTerra15SuperficieEligibile_QNAME = new QName("http://cooperazione.sian.it/schema/fascicolo", "SuperficieEligibile");
    private final static QName _ISWSDettaglioUtilizzoTerra15DataFineUtilizzo_QNAME = new QName("http://cooperazione.sian.it/schema/fascicolo", "DataFineUtilizzo");
    private final static QName _ISWSDettaglioUtilizzoTerra15ColtivazioneBiologica_QNAME = new QName("http://cooperazione.sian.it/schema/fascicolo", "ColtivazioneBiologica");
    private final static QName _ISWSDettaglioUtilizzoTerra15TipologiaSemina_QNAME = new QName("http://cooperazione.sian.it/schema/fascicolo", "TipologiaSemina");
    private final static QName _ISWSDettaglioUtilizzoTerra15TipologiaIrrigazione_QNAME = new QName("http://cooperazione.sian.it/schema/fascicolo", "TipologiaIrrigazione");
    private final static QName _ISWSDettaglioUtilizzoTerra15ProtezioneColture_QNAME = new QName("http://cooperazione.sian.it/schema/fascicolo", "ProtezioneColture");
    private final static QName _ISWSDettaglioUtilizzoTerra15FaseAllevamento_QNAME = new QName("http://cooperazione.sian.it/schema/fascicolo", "FaseAllevamento");
    private final static QName _ISWSDettaglioUtilizzoTerra15TipoCertificazione_QNAME = new QName("http://cooperazione.sian.it/schema/fascicolo", "tipoCertificazione");
    private final static QName _ISWSDettaglioUtilizzoTerra15Percentuale_QNAME = new QName("http://cooperazione.sian.it/schema/fascicolo", "percentuale");
    private final static QName _ISWSDettaglioUtilizzoTerra15Menzione_QNAME = new QName("http://cooperazione.sian.it/schema/fascicolo", "menzione");
    private final static QName _ISWSDettaglioUtilizzoTerra15TipoUtilizzolivo_QNAME = new QName("http://cooperazione.sian.it/schema/fascicolo", "tipoUtilizzolivo");
    private final static QName _ISWSDettaglioUtilizzoTerra15CapacitaProduttiva_QNAME = new QName("http://cooperazione.sian.it/schema/fascicolo", "capacitaProduttiva");
    private final static QName _ISWSDettaglioUtilizzoTerra15Altitudine_QNAME = new QName("http://cooperazione.sian.it/schema/fascicolo", "altitudine");
    private final static QName _ISWSBaseTerritorio1SuperficieGrafica_QNAME = new QName("http://cooperazione.sian.it/schema/fascicolo", "SuperficieGrafica");
    private final static QName _ISWSDURCDettaglioDURC_QNAME = new QName("http://cooperazione.sian.it/schema/fascicolo", "DettaglioDURC");
    private final static QName _ISWSSchedaRiepilogo_QNAME = new QName("http://cooperazione.sian.it/schema/fascicolo", "Riepilogo");
    private final static QName _ISWSRespSchedeIDScheda_QNAME = new QName("http://cooperazione.sian.it/schema/fascicolo", "IDScheda");
    private final static QName _ISWSRespSchedeDataScheda_QNAME = new QName("http://cooperazione.sian.it/schema/fascicolo", "DataScheda");
    private final static QName _ISWSTerritorioFS7CodiZVN_QNAME = new QName("http://cooperazione.sian.it/schema/fascicolo", "CodiZVN");
    private final static QName _ISWSRespAnagFascicolo15SessoPF_QNAME = new QName("http://cooperazione.sian.it/schema/fascicolo", "sessoPF");
    private final static QName _ISWSRespAnagFascicolo15DescPec_QNAME = new QName("http://cooperazione.sian.it/schema/fascicolo", "DescPec");
    private final static QName _ISWSCUAAModificatoStatoFascicolo_QNAME = new QName("http://cooperazione.sian.it/schema/fascicolo", "StatoFascicolo");
    private final static QName _ISWSCUAAModificatoDataOperazione_QNAME = new QName("http://cooperazione.sian.it/schema/fascicolo", "DataOperazione");
    private final static QName _ISWSCUAAModificatoCAANew_QNAME = new QName("http://cooperazione.sian.it/schema/fascicolo", "CAANew");
    private final static QName _ISWSRiep3CodiceOccupazione_QNAME = new QName("http://cooperazione.sian.it/schema/fascicolo", "CodiceOccupazione");
    private final static QName _ISWSCHEDEAnnoCampagna_QNAME = new QName("http://cooperazione.sian.it/schema/fascicolo", "AnnoCampagna");
    private final static QName _ISWSFabbricatoFS6CasiParticolari_QNAME = new QName("http://cooperazione.sian.it/schema/fascicolo", "CasiParticolari");
    private final static QName _ISWSMacchinaCarburante_QNAME = new QName("http://cooperazione.sian.it/schema/fascicolo", "Carburante");
    private final static QName _ISWSMacchinaTrazione_QNAME = new QName("http://cooperazione.sian.it/schema/fascicolo", "Trazione");
    private final static QName _ISWSOTETipoIdScheda_QNAME = new QName("http://cooperazione.sian.it/schema/fascicolo", "TipoIdScheda");
    private final static QName _ISWSOTEIdScheda_QNAME = new QName("http://cooperazione.sian.it/schema/fascicolo", "IdScheda");
    private final static QName _WSDocuFascCuaaDefunto_QNAME = new QName("http://cooperazione.sian.it/schema/fascicolo", "CuaaDefunto");
    private final static QName _WSDocuFascDataEvento_QNAME = new QName("http://cooperazione.sian.it/schema/fascicolo", "DataEvento");
    private final static QName _WSDocuFascCuaaSoggDelegato_QNAME = new QName("http://cooperazione.sian.it/schema/fascicolo", "CuaaSoggDelegato");
    private final static QName _WSDocuFascNumeroEredi_QNAME = new QName("http://cooperazione.sian.it/schema/fascicolo", "NumeroEredi");
    private final static QName _WSDocuFascTipoDocuRico_QNAME = new QName("http://cooperazione.sian.it/schema/fascicolo", "TipoDocuRico");
    private final static QName _WSDocuFascNumeroDocuRico_QNAME = new QName("http://cooperazione.sian.it/schema/fascicolo", "NumeroDocuRico");
    private final static QName _WSDocuFascDataScadDocuRico_QNAME = new QName("http://cooperazione.sian.it/schema/fascicolo", "DataScadDocuRico");
    private final static QName _ISWSCodiceINPSNumeroIscrizione_QNAME = new QName("http://cooperazione.sian.it/schema/fascicolo", "NumeroIscrizione");
    private final static QName _ISWSCodiceINPSDataCessazione_QNAME = new QName("http://cooperazione.sian.it/schema/fascicolo", "DataCessazione");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.abacogroup.gari.dataimporter.soap.fascicolo
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link SOAPAutenticazione }
     * 
     */
    public SOAPAutenticazione createSOAPAutenticazione() {
        return new SOAPAutenticazione();
    }

    /**
     * Create an instance of {@link ISWSDatiFascicolo15 }
     * 
     */
    public ISWSDatiFascicolo15 createISWSDatiFascicolo15() {
        return new ISWSDatiFascicolo15();
    }

    /**
     * Create an instance of {@link ISWSUbicazione }
     * 
     */
    public ISWSUbicazione createISWSUbicazione() {
        return new ISWSUbicazione();
    }

    /**
     * Create an instance of {@link ISWSIscrizioneCC }
     * 
     */
    public ISWSIscrizioneCC createISWSIscrizioneCC() {
        return new ISWSIscrizioneCC();
    }

    /**
     * Create an instance of {@link ISWSCodiceINPS }
     * 
     */
    public ISWSCodiceINPS createISWSCodiceINPS() {
        return new ISWSCodiceINPS();
    }

    /**
     * Create an instance of {@link ISWSDatiTerritori15 }
     * 
     */
    public ISWSDatiTerritori15 createISWSDatiTerritori15() {
        return new ISWSDatiTerritori15();
    }

    /**
     * Create an instance of {@link ISWSTerritorio15 }
     * 
     */
    public ISWSTerritorio15 createISWSTerritorio15() {
        return new ISWSTerritorio15();
    }

    /**
     * Create an instance of {@link ISWSChiudiConsistenza }
     * 
     */
    public ISWSChiudiConsistenza createISWSChiudiConsistenza() {
        return new ISWSChiudiConsistenza();
    }

    /**
     * Create an instance of {@link ISWSChiudiTerritori }
     * 
     */
    public ISWSChiudiTerritori createISWSChiudiTerritori() {
        return new ISWSChiudiTerritori();
    }

    /**
     * Create an instance of {@link ISWSRTI }
     * 
     */
    public ISWSRTI createISWSRTI() {
        return new ISWSRTI();
    }

    /**
     * Create an instance of {@link ISWSAsso }
     * 
     */
    public ISWSAsso createISWSAsso() {
        return new ISWSAsso();
    }

    /**
     * Create an instance of {@link ISWSDatiRTI }
     * 
     */
    public ISWSDatiRTI createISWSDatiRTI() {
        return new ISWSDatiRTI();
    }

    /**
     * Create an instance of {@link ISWSAzieRTI }
     * 
     */
    public ISWSAzieRTI createISWSAzieRTI() {
        return new ISWSAzieRTI();
    }

    /**
     * Create an instance of {@link ISWSDatiSoci }
     * 
     */
    public ISWSDatiSoci createISWSDatiSoci() {
        return new ISWSDatiSoci();
    }

    /**
     * Create an instance of {@link ISWSDatiSocio }
     * 
     */
    public ISWSDatiSocio createISWSDatiSocio() {
        return new ISWSDatiSocio();
    }

    /**
     * Create an instance of {@link ISWSInfoRTI }
     * 
     */
    public ISWSInfoRTI createISWSInfoRTI() {
        return new ISWSInfoRTI();
    }

    /**
     * Create an instance of {@link ISWSChiudiSocio }
     * 
     */
    public ISWSChiudiSocio createISWSChiudiSocio() {
        return new ISWSChiudiSocio();
    }

    /**
     * Create an instance of {@link ISWSChiudiOA }
     * 
     */
    public ISWSChiudiOA createISWSChiudiOA() {
        return new ISWSChiudiOA();
    }

    /**
     * Create an instance of {@link ISWSDatiTerritori16 }
     * 
     */
    public ISWSDatiTerritori16 createISWSDatiTerritori16() {
        return new ISWSDatiTerritori16();
    }

    /**
     * Create an instance of {@link ISWSTerritorio16 }
     * 
     */
    public ISWSTerritorio16 createISWSTerritorio16() {
        return new ISWSTerritorio16();
    }

    /**
     * Create an instance of {@link DocuFascicolo }
     * 
     */
    public DocuFascicolo createDocuFascicolo() {
        return new DocuFascicolo();
    }

    /**
     * Create an instance of {@link WSDocuFasc }
     * 
     */
    public WSDocuFasc createWSDocuFasc() {
        return new WSDocuFasc();
    }

    /**
     * Create an instance of {@link RichiestaOTE }
     * 
     */
    public RichiestaOTE createRichiestaOTE() {
        return new RichiestaOTE();
    }

    /**
     * Create an instance of {@link ISWSOTE }
     * 
     */
    public ISWSOTE createISWSOTE() {
        return new ISWSOTE();
    }

    /**
     * Create an instance of {@link ISWSDatiAllevamenti15 }
     * 
     */
    public ISWSDatiAllevamenti15 createISWSDatiAllevamenti15() {
        return new ISWSDatiAllevamenti15();
    }

    /**
     * Create an instance of {@link ISWSAllevamento15 }
     * 
     */
    public ISWSAllevamento15 createISWSAllevamento15() {
        return new ISWSAllevamento15();
    }

    /**
     * Create an instance of {@link ISWSResponse }
     * 
     */
    public ISWSResponse createISWSResponse() {
        return new ISWSResponse();
    }

    /**
     * Create an instance of {@link ISWSIdParticella }
     * 
     */
    public ISWSIdParticella createISWSIdParticella() {
        return new ISWSIdParticella();
    }

    /**
     * Create an instance of {@link ISWSAgricoltoreAttivo }
     * 
     */
    public ISWSAgricoltoreAttivo createISWSAgricoltoreAttivo() {
        return new ISWSAgricoltoreAttivo();
    }

    /**
     * Create an instance of {@link ISWSAgricoltoreAttivoISOP }
     * 
     */
    public ISWSAgricoltoreAttivoISOP createISWSAgricoltoreAttivoISOP() {
        return new ISWSAgricoltoreAttivoISOP();
    }

    /**
     * Create an instance of {@link ISWSEsitoServiziAsync }
     * 
     */
    public ISWSEsitoServiziAsync createISWSEsitoServiziAsync() {
        return new ISWSEsitoServiziAsync();
    }

    /**
     * Create an instance of {@link ISWSDettaglioSoggetto }
     * 
     */
    public ISWSDettaglioSoggetto createISWSDettaglioSoggetto() {
        return new ISWSDettaglioSoggetto();
    }

    /**
     * Create an instance of {@link ISWSDatiContiCorrenti }
     * 
     */
    public ISWSDatiContiCorrenti createISWSDatiContiCorrenti() {
        return new ISWSDatiContiCorrenti();
    }

    /**
     * Create an instance of {@link ISWSContoCorrente }
     * 
     */
    public ISWSContoCorrente createISWSContoCorrente() {
        return new ISWSContoCorrente();
    }

    /**
     * Create an instance of {@link ISWSDatiMacchine }
     * 
     */
    public ISWSDatiMacchine createISWSDatiMacchine() {
        return new ISWSDatiMacchine();
    }

    /**
     * Create an instance of {@link ISWSMacchina }
     * 
     */
    public ISWSMacchina createISWSMacchina() {
        return new ISWSMacchina();
    }

    /**
     * Create an instance of {@link ISWSDatiManodopera }
     * 
     */
    public ISWSDatiManodopera createISWSDatiManodopera() {
        return new ISWSDatiManodopera();
    }

    /**
     * Create an instance of {@link ISWSLavoro }
     * 
     */
    public ISWSLavoro createISWSLavoro() {
        return new ISWSLavoro();
    }

    /**
     * Create an instance of {@link ISWSDatiFabbricati }
     * 
     */
    public ISWSDatiFabbricati createISWSDatiFabbricati() {
        return new ISWSDatiFabbricati();
    }

    /**
     * Create an instance of {@link ISWSFabbricato }
     * 
     */
    public ISWSFabbricato createISWSFabbricato() {
        return new ISWSFabbricato();
    }

    /**
     * Create an instance of {@link ISWSDatiFabbricatiFS6 }
     * 
     */
    public ISWSDatiFabbricatiFS6 createISWSDatiFabbricatiFS6() {
        return new ISWSDatiFabbricatiFS6();
    }

    /**
     * Create an instance of {@link ISWSFabbricatoFS6 }
     * 
     */
    public ISWSFabbricatoFS6 createISWSFabbricatoFS6() {
        return new ISWSFabbricatoFS6();
    }

    /**
     * Create an instance of {@link SoggettoWS }
     * 
     */
    public SoggettoWS createSoggettoWS() {
        return new SoggettoWS();
    }

    /**
     * Create an instance of {@link ContoCorrenteWS }
     * 
     */
    public ContoCorrenteWS createContoCorrenteWS() {
        return new ContoCorrenteWS();
    }

    /**
     * Create an instance of {@link ISWSFascicoloDomanda }
     * 
     */
    public ISWSFascicoloDomanda createISWSFascicoloDomanda() {
        return new ISWSFascicoloDomanda();
    }

    /**
     * Create an instance of {@link RecapitoWS }
     * 
     */
    public RecapitoWS createRecapitoWS() {
        return new RecapitoWS();
    }

    /**
     * Create an instance of {@link RappresentanteLegaleWS }
     * 
     */
    public RappresentanteLegaleWS createRappresentanteLegaleWS() {
        return new RappresentanteLegaleWS();
    }

    /**
     * Create an instance of {@link RichiestaSchede }
     * 
     */
    public RichiestaSchede createRichiestaSchede() {
        return new RichiestaSchede();
    }

    /**
     * Create an instance of {@link ISWSCHEDE }
     * 
     */
    public ISWSCHEDE createISWSCHEDE() {
        return new ISWSCHEDE();
    }

    /**
     * Create an instance of {@link RichiestaScheda }
     * 
     */
    public RichiestaScheda createRichiestaScheda() {
        return new RichiestaScheda();
    }

    /**
     * Create an instance of {@link ISWReqScheda }
     * 
     */
    public ISWReqScheda createISWReqScheda() {
        return new ISWReqScheda();
    }

    /**
     * Create an instance of {@link Livello }
     * 
     */
    public Livello createLivello() {
        return new Livello();
    }

    /**
     * Create an instance of {@link ISWSRiep3 }
     * 
     */
    public ISWSRiep3 createISWSRiep3() {
        return new ISWSRiep3();
    }

    /**
     * Create an instance of {@link ISWSToOprResponse }
     * 
     */
    public ISWSToOprResponse createISWSToOprResponse() {
        return new ISWSToOprResponse();
    }

    /**
     * Create an instance of {@link ISWSSegnalazione }
     * 
     */
    public ISWSSegnalazione createISWSSegnalazione() {
        return new ISWSSegnalazione();
    }

    /**
     * Create an instance of {@link DettaglioSoggettoWS }
     * 
     */
    public DettaglioSoggettoWS createDettaglioSoggettoWS() {
        return new DettaglioSoggettoWS();
    }

    /**
     * Create an instance of {@link ISWSMandati }
     * 
     */
    public ISWSMandati createISWSMandati() {
        return new ISWSMandati();
    }

    /**
     * Create an instance of {@link ISWSCUAAModificato }
     * 
     */
    public ISWSCUAAModificato createISWSCUAAModificato() {
        return new ISWSCUAAModificato();
    }

    /**
     * Create an instance of {@link ISWSRespAnagFascicolo15 }
     * 
     */
    public ISWSRespAnagFascicolo15 createISWSRespAnagFascicolo15() {
        return new ISWSRespAnagFascicolo15();
    }

    /**
     * Create an instance of {@link ISWSAgricoltoreAttivoResp }
     * 
     */
    public ISWSAgricoltoreAttivoResp createISWSAgricoltoreAttivoResp() {
        return new ISWSAgricoltoreAttivoResp();
    }

    /**
     * Create an instance of {@link ISWSGiovaneAgricoltoreResp }
     * 
     */
    public ISWSGiovaneAgricoltoreResp createISWSGiovaneAgricoltoreResp() {
        return new ISWSGiovaneAgricoltoreResp();
    }

    /**
     * Create an instance of {@link ISWSTerritorioFS6 }
     * 
     */
    public ISWSTerritorioFS6 createISWSTerritorioFS6() {
        return new ISWSTerritorioFS6();
    }

    /**
     * Create an instance of {@link ISWSBaseAssoRTIResp }
     * 
     */
    public ISWSBaseAssoRTIResp createISWSBaseAssoRTIResp() {
        return new ISWSBaseAssoRTIResp();
    }

    /**
     * Create an instance of {@link ISWSRespOA }
     * 
     */
    public ISWSRespOA createISWSRespOA() {
        return new ISWSRespOA();
    }

    /**
     * Create an instance of {@link ISWSRespOTE }
     * 
     */
    public ISWSRespOTE createISWSRespOTE() {
        return new ISWSRespOTE();
    }

    /**
     * Create an instance of {@link ISWSAllevamento16 }
     * 
     */
    public ISWSAllevamento16 createISWSAllevamento16() {
        return new ISWSAllevamento16();
    }

    /**
     * Create an instance of {@link ISWSTerritorioFS7 }
     * 
     */
    public ISWSTerritorioFS7 createISWSTerritorioFS7() {
        return new ISWSTerritorioFS7();
    }

    /**
     * Create an instance of {@link ISWSRespSchede }
     * 
     */
    public ISWSRespSchede createISWSRespSchede() {
        return new ISWSRespSchede();
    }

    /**
     * Create an instance of {@link ISWSScheda }
     * 
     */
    public ISWSScheda createISWSScheda() {
        return new ISWSScheda();
    }

    /**
     * Create an instance of {@link ISWSDURC }
     * 
     */
    public ISWSDURC createISWSDURC() {
        return new ISWSDURC();
    }

    /**
     * Create an instance of {@link ISWSProprietario }
     * 
     */
    public ISWSProprietario createISWSProprietario() {
        return new ISWSProprietario();
    }

    /**
     * Create an instance of {@link ISWSBaseTerritorio1 }
     * 
     */
    public ISWSBaseTerritorio1 createISWSBaseTerritorio1() {
        return new ISWSBaseTerritorio1();
    }

    /**
     * Create an instance of {@link ISWSUtilizzoFabbricato }
     * 
     */
    public ISWSUtilizzoFabbricato createISWSUtilizzoFabbricato() {
        return new ISWSUtilizzoFabbricato();
    }

    /**
     * Create an instance of {@link WsDocumenti }
     * 
     */
    public WsDocumenti createWsDocumenti() {
        return new WsDocumenti();
    }

    /**
     * Create an instance of {@link ISWSDettaglioUtilizzoTerra15 }
     * 
     */
    public ISWSDettaglioUtilizzoTerra15 createISWSDettaglioUtilizzoTerra15() {
        return new ISWSDettaglioUtilizzoTerra15();
    }

    /**
     * Create an instance of {@link ISWSUtilizzoTerra15 }
     * 
     */
    public ISWSUtilizzoTerra15 createISWSUtilizzoTerra15() {
        return new ISWSUtilizzoTerra15();
    }

    /**
     * Create an instance of {@link ISWSAzieOA }
     * 
     */
    public ISWSAzieOA createISWSAzieOA() {
        return new ISWSAzieOA();
    }

    /**
     * Create an instance of {@link ISWSSoci }
     * 
     */
    public ISWSSoci createISWSSoci() {
        return new ISWSSoci();
    }

    /**
     * Create an instance of {@link ISWSRespSoci }
     * 
     */
    public ISWSRespSoci createISWSRespSoci() {
        return new ISWSRespSoci();
    }

    /**
     * Create an instance of {@link ISWSOTECS }
     * 
     */
    public ISWSOTECS createISWSOTECS() {
        return new ISWSOTECS();
    }

    /**
     * Create an instance of {@link WsUtilizzoTerraCaba }
     * 
     */
    public WsUtilizzoTerraCaba createWsUtilizzoTerraCaba() {
        return new WsUtilizzoTerraCaba();
    }

    /**
     * Create an instance of {@link ISWSStallaAllevamento }
     * 
     */
    public ISWSStallaAllevamento createISWSStallaAllevamento() {
        return new ISWSStallaAllevamento();
    }

    /**
     * Create an instance of {@link ISWSPropAllevamento }
     * 
     */
    public ISWSPropAllevamento createISWSPropAllevamento() {
        return new ISWSPropAllevamento();
    }

    /**
     * Create an instance of {@link ISWSCapoAllevamento2 }
     * 
     */
    public ISWSCapoAllevamento2 createISWSCapoAllevamento2() {
        return new ISWSCapoAllevamento2();
    }

    /**
     * Create an instance of {@link ISWSIndirizzo }
     * 
     */
    public ISWSIndirizzo createISWSIndirizzo() {
        return new ISWSIndirizzo();
    }

    /**
     * Create an instance of {@link ISWSIndicatori }
     * 
     */
    public ISWSIndicatori createISWSIndicatori() {
        return new ISWSIndicatori();
    }

    /**
     * Create an instance of {@link ISWSCapoAllevamento16 }
     * 
     */
    public ISWSCapoAllevamento16 createISWSCapoAllevamento16() {
        return new ISWSCapoAllevamento16();
    }

    /**
     * Create an instance of {@link WsUtilizzoTerraCaba7 }
     * 
     */
    public WsUtilizzoTerraCaba7 createWsUtilizzoTerraCaba7() {
        return new WsUtilizzoTerraCaba7();
    }

    /**
     * Create an instance of {@link WsIdoneita }
     * 
     */
    public WsIdoneita createWsIdoneita() {
        return new WsIdoneita();
    }

    /**
     * Create an instance of {@link ISWSParticelleScheda }
     * 
     */
    public ISWSParticelleScheda createISWSParticelleScheda() {
        return new ISWSParticelleScheda();
    }

    /**
     * Create an instance of {@link ISWSSuoloScheda }
     * 
     */
    public ISWSSuoloScheda createISWSSuoloScheda() {
        return new ISWSSuoloScheda();
    }

    /**
     * Create an instance of {@link ISWSRiepilogoScheda }
     * 
     */
    public ISWSRiepilogoScheda createISWSRiepilogoScheda() {
        return new ISWSRiepilogoScheda();
    }

    /**
     * Create an instance of {@link ISWSRiep1 }
     * 
     */
    public ISWSRiep1 createISWSRiep1() {
        return new ISWSRiep1();
    }

    /**
     * Create an instance of {@link ISWSRiep2 }
     * 
     */
    public ISWSRiep2 createISWSRiep2() {
        return new ISWSRiep2();
    }

    /**
     * Create an instance of {@link ISWSAnomalieDURC }
     * 
     */
    public ISWSAnomalieDURC createISWSAnomalieDURC() {
        return new ISWSAnomalieDURC();
    }

    /**
     * Create an instance of {@link ISWSDettaglioDURC }
     * 
     */
    public ISWSDettaglioDURC createISWSDettaglioDURC() {
        return new ISWSDettaglioDURC();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SOAPAutenticazione }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link SOAPAutenticazione }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/SoapAutenticazione", name = "SOAPAutenticazione")
    public JAXBElement<SOAPAutenticazione> createSOAPAutenticazione(SOAPAutenticazione value) {
        return new JAXBElement<SOAPAutenticazione>(_SOAPAutenticazione_QNAME, SOAPAutenticazione.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "Cuaa")
    public JAXBElement<String> createCuaa(String value) {
        return new JAXBElement<String>(_Cuaa_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Integer }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link Integer }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "Giorni")
    public JAXBElement<Integer> createGiorni(Integer value) {
        return new JAXBElement<Integer>(_Giorni_QNAME, Integer.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "TipoVinc")
    public JAXBElement<String> createTipoVinc(String value) {
        return new JAXBElement<String>(_TipoVinc_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "aggiornaAnagrafe", scope = ISWSDatiFascicolo15 .class)
    public JAXBElement<String> createISWSDatiFascicolo15AggiornaAnagrafe(String value) {
        return new JAXBElement<String>(_ISWSDatiFascicolo15AggiornaAnagrafe_QNAME, String.class, ISWSDatiFascicolo15 .class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "PEC", scope = ISWSDatiFascicolo15 .class)
    public JAXBElement<String> createISWSDatiFascicolo15PEC(String value) {
        return new JAXBElement<String>(_ISWSDatiFascicolo15PEC_QNAME, String.class, ISWSDatiFascicolo15 .class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "Email", scope = ISWSDatiFascicolo15 .class)
    public JAXBElement<String> createISWSDatiFascicolo15Email(String value) {
        return new JAXBElement<String>(_ISWSDatiFascicolo15Email_QNAME, String.class, ISWSDatiFascicolo15 .class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "Telefono", scope = ISWSDatiFascicolo15 .class)
    public JAXBElement<String> createISWSDatiFascicolo15Telefono(String value) {
        return new JAXBElement<String>(_ISWSDatiFascicolo15Telefono_QNAME, String.class, ISWSDatiFascicolo15 .class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "TipoDocumento", scope = ISWSDatiFascicolo15 .class)
    public JAXBElement<String> createISWSDatiFascicolo15TipoDocumento(String value) {
        return new JAXBElement<String>(_ISWSDatiFascicolo15TipoDocumento_QNAME, String.class, ISWSDatiFascicolo15 .class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "CUAADeteCont", scope = ISWSDatiFascicolo15 .class)
    public JAXBElement<String> createISWSDatiFascicolo15CUAADeteCont(String value) {
        return new JAXBElement<String>(_ISWSDatiFascicolo15CUAADeteCont_QNAME, String.class, ISWSDatiFascicolo15 .class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "TipoIncaricoDetentore", scope = ISWSDatiFascicolo15 .class)
    public JAXBElement<String> createISWSDatiFascicolo15TipoIncaricoDetentore(String value) {
        return new JAXBElement<String>(_ISWSDatiFascicolo15TipoIncaricoDetentore_QNAME, String.class, ISWSDatiFascicolo15 .class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "DataDeteCont", scope = ISWSDatiFascicolo15 .class)
    public JAXBElement<String> createISWSDatiFascicolo15DataDeteCont(String value) {
        return new JAXBElement<String>(_ISWSDatiFascicolo15DataDeteCont_QNAME, String.class, ISWSDatiFascicolo15 .class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "TipoIdentificativoScheda", scope = ISWSDatiFascicolo15 .class)
    public JAXBElement<String> createISWSDatiFascicolo15TipoIdentificativoScheda(String value) {
        return new JAXBElement<String>(_ISWSDatiFascicolo15TipoIdentificativoScheda_QNAME, String.class, ISWSDatiFascicolo15 .class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "IdentificativoSchedaFascicolo", scope = ISWSDatiFascicolo15 .class)
    public JAXBElement<String> createISWSDatiFascicolo15IdentificativoSchedaFascicolo(String value) {
        return new JAXBElement<String>(_ISWSDatiFascicolo15IdentificativoSchedaFascicolo_QNAME, String.class, ISWSDatiFascicolo15 .class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "TipoLegameAsso", scope = ISWSChiudiSocio.class)
    public JAXBElement<String> createISWSChiudiSocioTipoLegameAsso(String value) {
        return new JAXBElement<String>(_ISWSChiudiSocioTipoLegameAsso_QNAME, String.class, ISWSChiudiSocio.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "Fattispecie", scope = DocuFascicolo.class)
    public JAXBElement<String> createDocuFascicoloFattispecie(String value) {
        return new JAXBElement<String>(_DocuFascicoloFattispecie_QNAME, String.class, DocuFascicolo.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "TipoSoggetto", scope = ISWSAgricoltoreAttivoISOP.class)
    public JAXBElement<String> createISWSAgricoltoreAttivoISOPTipoSoggetto(String value) {
        return new JAXBElement<String>(_ISWSAgricoltoreAttivoISOPTipoSoggetto_QNAME, String.class, ISWSAgricoltoreAttivoISOP.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "TipoEntePPAA", scope = ISWSAgricoltoreAttivoISOP.class)
    public JAXBElement<String> createISWSAgricoltoreAttivoISOPTipoEntePPAA(String value) {
        return new JAXBElement<String>(_ISWSAgricoltoreAttivoISOPTipoEntePPAA_QNAME, String.class, ISWSAgricoltoreAttivoISOP.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "ProventiTotNAg", scope = ISWSAgricoltoreAttivoISOP.class)
    public JAXBElement<String> createISWSAgricoltoreAttivoISOPProventiTotNAg(String value) {
        return new JAXBElement<String>(_ISWSAgricoltoreAttivoISOPProventiTotNAg_QNAME, String.class, ISWSAgricoltoreAttivoISOP.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "ProventiTotAg", scope = ISWSAgricoltoreAttivoISOP.class)
    public JAXBElement<String> createISWSAgricoltoreAttivoISOPProventiTotAg(String value) {
        return new JAXBElement<String>(_ISWSAgricoltoreAttivoISOPProventiTotAg_QNAME, String.class, ISWSAgricoltoreAttivoISOP.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "ProventiTotAgNAg", scope = ISWSAgricoltoreAttivoISOP.class)
    public JAXBElement<String> createISWSAgricoltoreAttivoISOPProventiTotAgNAg(String value) {
        return new JAXBElement<String>(_ISWSAgricoltoreAttivoISOPProventiTotAgNAg_QNAME, String.class, ISWSAgricoltoreAttivoISOP.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "TipoControllo1", scope = ISWSAgricoltoreAttivoISOP.class)
    public JAXBElement<String> createISWSAgricoltoreAttivoISOPTipoControllo1(String value) {
        return new JAXBElement<String>(_ISWSAgricoltoreAttivoISOPTipoControllo1_QNAME, String.class, ISWSAgricoltoreAttivoISOP.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "TipoControllo2", scope = ISWSAgricoltoreAttivoISOP.class)
    public JAXBElement<String> createISWSAgricoltoreAttivoISOPTipoControllo2(String value) {
        return new JAXBElement<String>(_ISWSAgricoltoreAttivoISOPTipoControllo2_QNAME, String.class, ISWSAgricoltoreAttivoISOP.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "Codi_sess", scope = SoggettoWS.class)
    public JAXBElement<String> createSoggettoWSCodiSess(String value) {
        return new JAXBElement<String>(_SoggettoWSCodiSess_QNAME, String.class, SoggettoWS.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "CodiceLivello", scope = Livello.class)
    public JAXBElement<String> createLivelloCodiceLivello(String value) {
        return new JAXBElement<String>(_LivelloCodiceLivello_QNAME, String.class, Livello.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "CodiceMacrouso", scope = Livello.class)
    public JAXBElement<String> createLivelloCodiceMacrouso(String value) {
        return new JAXBElement<String>(_LivelloCodiceMacrouso_QNAME, String.class, Livello.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "SuperficieDichiarata", scope = Livello.class)
    public JAXBElement<String> createLivelloSuperficieDichiarata(String value) {
        return new JAXBElement<String>(_LivelloSuperficieDichiarata_QNAME, String.class, Livello.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "SuperficieRiscontrata", scope = Livello.class)
    public JAXBElement<String> createLivelloSuperficieRiscontrata(String value) {
        return new JAXBElement<String>(_LivelloSuperficieRiscontrata_QNAME, String.class, Livello.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "risposta0", scope = ISWSToOprResponse.class)
    public JAXBElement<String> createISWSToOprResponseRisposta0(String value) {
        return new JAXBElement<String>(_ISWSToOprResponseRisposta0_QNAME, String.class, ISWSToOprResponse.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DettaglioSoggettoWS }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link DettaglioSoggettoWS }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "risposta12", scope = ISWSToOprResponse.class)
    public JAXBElement<DettaglioSoggettoWS> createISWSToOprResponseRisposta12(DettaglioSoggettoWS value) {
        return new JAXBElement<DettaglioSoggettoWS>(_ISWSToOprResponseRisposta12_QNAME, DettaglioSoggettoWS.class, ISWSToOprResponse.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ISWSMandati }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link ISWSMandati }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "risposta15", scope = ISWSToOprResponse.class)
    public JAXBElement<ISWSMandati> createISWSToOprResponseRisposta15(ISWSMandati value) {
        return new JAXBElement<ISWSMandati>(_ISWSToOprResponseRisposta15_QNAME, ISWSMandati.class, ISWSToOprResponse.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ISWSRespAnagFascicolo15 }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link ISWSRespAnagFascicolo15 }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "risposta20", scope = ISWSToOprResponse.class)
    public JAXBElement<ISWSRespAnagFascicolo15> createISWSToOprResponseRisposta20(ISWSRespAnagFascicolo15 value) {
        return new JAXBElement<ISWSRespAnagFascicolo15>(_ISWSToOprResponseRisposta20_QNAME, ISWSRespAnagFascicolo15 .class, ISWSToOprResponse.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ISWSAgricoltoreAttivoResp }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link ISWSAgricoltoreAttivoResp }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "risposta24", scope = ISWSToOprResponse.class)
    public JAXBElement<ISWSAgricoltoreAttivoResp> createISWSToOprResponseRisposta24(ISWSAgricoltoreAttivoResp value) {
        return new JAXBElement<ISWSAgricoltoreAttivoResp>(_ISWSToOprResponseRisposta24_QNAME, ISWSAgricoltoreAttivoResp.class, ISWSToOprResponse.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ISWSGiovaneAgricoltoreResp }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link ISWSGiovaneAgricoltoreResp }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "risposta28", scope = ISWSToOprResponse.class)
    public JAXBElement<ISWSGiovaneAgricoltoreResp> createISWSToOprResponseRisposta28(ISWSGiovaneAgricoltoreResp value) {
        return new JAXBElement<ISWSGiovaneAgricoltoreResp>(_ISWSToOprResponseRisposta28_QNAME, ISWSGiovaneAgricoltoreResp.class, ISWSToOprResponse.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ISWSScheda }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link ISWSScheda }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "risposta37", scope = ISWSToOprResponse.class)
    public JAXBElement<ISWSScheda> createISWSToOprResponseRisposta37(ISWSScheda value) {
        return new JAXBElement<ISWSScheda>(_ISWSToOprResponseRisposta37_QNAME, ISWSScheda.class, ISWSToOprResponse.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ISWSDURC }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link ISWSDURC }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "risposta38", scope = ISWSToOprResponse.class)
    public JAXBElement<ISWSDURC> createISWSToOprResponseRisposta38(ISWSDURC value) {
        return new JAXBElement<ISWSDURC>(_ISWSToOprResponseRisposta38_QNAME, ISWSDURC.class, ISWSToOprResponse.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "TipoConduzione", scope = ISWSRiep1 .class)
    public JAXBElement<String> createISWSRiep1TipoConduzione(String value) {
        return new JAXBElement<String>(_ISWSRiep1TipoConduzione_QNAME, String.class, ISWSRiep1 .class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "DesConduzione", scope = ISWSRiep1 .class)
    public JAXBElement<String> createISWSRiep1DesConduzione(String value) {
        return new JAXBElement<String>(_ISWSRiep1DesConduzione_QNAME, String.class, ISWSRiep1 .class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "NumParticelle", scope = ISWSRiep1 .class)
    public JAXBElement<String> createISWSRiep1NumParticelle(String value) {
        return new JAXBElement<String>(_ISWSRiep1NumParticelle_QNAME, String.class, ISWSRiep1 .class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "SuperficieTotale", scope = ISWSRiep1 .class)
    public JAXBElement<String> createISWSRiep1SuperficieTotale(String value) {
        return new JAXBElement<String>(_ISWSRiep1SuperficieTotale_QNAME, String.class, ISWSRiep1 .class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "PartTotaleCondAzienda", scope = ISWSRiepilogoScheda.class)
    public JAXBElement<String> createISWSRiepilogoSchedaPartTotaleCondAzienda(String value) {
        return new JAXBElement<String>(_ISWSRiepilogoSchedaPartTotaleCondAzienda_QNAME, String.class, ISWSRiepilogoScheda.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "SupTotaleCondAzienda", scope = ISWSRiepilogoScheda.class)
    public JAXBElement<String> createISWSRiepilogoSchedaSupTotaleCondAzienda(String value) {
        return new JAXBElement<String>(_ISWSRiepilogoSchedaSupTotaleCondAzienda_QNAME, String.class, ISWSRiepilogoScheda.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "SupTotaleOccuAzienda", scope = ISWSRiepilogoScheda.class)
    public JAXBElement<String> createISWSRiepilogoSchedaSupTotaleOccuAzienda(String value) {
        return new JAXBElement<String>(_ISWSRiepilogoSchedaSupTotaleOccuAzienda_QNAME, String.class, ISWSRiepilogoScheda.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "SupTotaleRiscontrataAzienda", scope = ISWSRiepilogoScheda.class)
    public JAXBElement<String> createISWSRiepilogoSchedaSupTotaleRiscontrataAzienda(String value) {
        return new JAXBElement<String>(_ISWSRiepilogoSchedaSupTotaleRiscontrataAzienda_QNAME, String.class, ISWSRiepilogoScheda.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "CodBelfiore", scope = ISWSSuoloScheda.class)
    public JAXBElement<String> createISWSSuoloSchedaCodBelfiore(String value) {
        return new JAXBElement<String>(_ISWSSuoloSchedaCodBelfiore_QNAME, String.class, ISWSSuoloScheda.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "CodiIstaProv", scope = ISWSSuoloScheda.class)
    public JAXBElement<String> createISWSSuoloSchedaCodiIstaProv(String value) {
        return new JAXBElement<String>(_ISWSSuoloSchedaCodiIstaProv_QNAME, String.class, ISWSSuoloScheda.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "CodiIstaComu", scope = ISWSSuoloScheda.class)
    public JAXBElement<String> createISWSSuoloSchedaCodiIstaComu(String value) {
        return new JAXBElement<String>(_ISWSSuoloSchedaCodiIstaComu_QNAME, String.class, ISWSSuoloScheda.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "Comune", scope = ISWSSuoloScheda.class)
    public JAXBElement<String> createISWSSuoloSchedaComune(String value) {
        return new JAXBElement<String>(_ISWSSuoloSchedaComune_QNAME, String.class, ISWSSuoloScheda.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "Sezione", scope = ISWSSuoloScheda.class)
    public JAXBElement<String> createISWSSuoloSchedaSezione(String value) {
        return new JAXBElement<String>(_ISWSSuoloSchedaSezione_QNAME, String.class, ISWSSuoloScheda.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "Foglio", scope = ISWSSuoloScheda.class)
    public JAXBElement<String> createISWSSuoloSchedaFoglio(String value) {
        return new JAXBElement<String>(_ISWSSuoloSchedaFoglio_QNAME, String.class, ISWSSuoloScheda.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "Particella", scope = ISWSSuoloScheda.class)
    public JAXBElement<String> createISWSSuoloSchedaParticella(String value) {
        return new JAXBElement<String>(_ISWSSuoloSchedaParticella_QNAME, String.class, ISWSSuoloScheda.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "Subalterno", scope = ISWSSuoloScheda.class)
    public JAXBElement<String> createISWSSuoloSchedaSubalterno(String value) {
        return new JAXBElement<String>(_ISWSSuoloSchedaSubalterno_QNAME, String.class, ISWSSuoloScheda.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "CodiceOccupazioneSuolo", scope = ISWSSuoloScheda.class)
    public JAXBElement<String> createISWSSuoloSchedaCodiceOccupazioneSuolo(String value) {
        return new JAXBElement<String>(_ISWSSuoloSchedaCodiceOccupazioneSuolo_QNAME, String.class, ISWSSuoloScheda.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "CodiceDestinazioneUso", scope = ISWSSuoloScheda.class)
    public JAXBElement<String> createISWSSuoloSchedaCodiceDestinazioneUso(String value) {
        return new JAXBElement<String>(_ISWSSuoloSchedaCodiceDestinazioneUso_QNAME, String.class, ISWSSuoloScheda.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "CodiceUso", scope = ISWSSuoloScheda.class)
    public JAXBElement<String> createISWSSuoloSchedaCodiceUso(String value) {
        return new JAXBElement<String>(_ISWSSuoloSchedaCodiceUso_QNAME, String.class, ISWSSuoloScheda.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "CodiceQualita", scope = ISWSSuoloScheda.class)
    public JAXBElement<String> createISWSSuoloSchedaCodiceQualita(String value) {
        return new JAXBElement<String>(_ISWSSuoloSchedaCodiceQualita_QNAME, String.class, ISWSSuoloScheda.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "CodiceOccupazioneVarieta", scope = ISWSSuoloScheda.class)
    public JAXBElement<String> createISWSSuoloSchedaCodiceOccupazioneVarieta(String value) {
        return new JAXBElement<String>(_ISWSSuoloSchedaCodiceOccupazioneVarieta_QNAME, String.class, ISWSSuoloScheda.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "AnnoImpianto", scope = ISWSSuoloScheda.class)
    public JAXBElement<String> createISWSSuoloSchedaAnnoImpianto(String value) {
        return new JAXBElement<String>(_ISWSSuoloSchedaAnnoImpianto_QNAME, String.class, ISWSSuoloScheda.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "TipoAllevamento", scope = ISWSSuoloScheda.class)
    public JAXBElement<String> createISWSSuoloSchedaTipoAllevamento(String value) {
        return new JAXBElement<String>(_ISWSSuoloSchedaTipoAllevamento_QNAME, String.class, ISWSSuoloScheda.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "SestoImpiantoSuFila", scope = ISWSSuoloScheda.class)
    public JAXBElement<String> createISWSSuoloSchedaSestoImpiantoSuFila(String value) {
        return new JAXBElement<String>(_ISWSSuoloSchedaSestoImpiantoSuFila_QNAME, String.class, ISWSSuoloScheda.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "SestoImpiantoTraFile", scope = ISWSSuoloScheda.class)
    public JAXBElement<String> createISWSSuoloSchedaSestoImpiantoTraFile(String value) {
        return new JAXBElement<String>(_ISWSSuoloSchedaSestoImpiantoTraFile_QNAME, String.class, ISWSSuoloScheda.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "NumeroPiante", scope = ISWSSuoloScheda.class)
    public JAXBElement<String> createISWSSuoloSchedaNumeroPiante(String value) {
        return new JAXBElement<String>(_ISWSSuoloSchedaNumeroPiante_QNAME, String.class, ISWSSuoloScheda.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "SuperficieColtivata", scope = ISWSSuoloScheda.class)
    public JAXBElement<String> createISWSSuoloSchedaSuperficieColtivata(String value) {
        return new JAXBElement<String>(_ISWSSuoloSchedaSuperficieColtivata_QNAME, String.class, ISWSSuoloScheda.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "DataInizColtivazione", scope = ISWSSuoloScheda.class)
    public JAXBElement<String> createISWSSuoloSchedaDataInizColtivazione(String value) {
        return new JAXBElement<String>(_ISWSSuoloSchedaDataInizColtivazione_QNAME, String.class, ISWSSuoloScheda.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "DataFineColtivazione", scope = ISWSSuoloScheda.class)
    public JAXBElement<String> createISWSSuoloSchedaDataFineColtivazione(String value) {
        return new JAXBElement<String>(_ISWSSuoloSchedaDataFineColtivazione_QNAME, String.class, ISWSSuoloScheda.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "Epoca", scope = ISWSSuoloScheda.class)
    public JAXBElement<String> createISWSSuoloSchedaEpoca(String value) {
        return new JAXBElement<String>(_ISWSSuoloSchedaEpoca_QNAME, String.class, ISWSSuoloScheda.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "TipoSemina", scope = ISWSSuoloScheda.class)
    public JAXBElement<String> createISWSSuoloSchedaTipoSemina(String value) {
        return new JAXBElement<String>(_ISWSSuoloSchedaTipoSemina_QNAME, String.class, ISWSSuoloScheda.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "ColturaPrincipale", scope = ISWSSuoloScheda.class)
    public JAXBElement<String> createISWSSuoloSchedaColturaPrincipale(String value) {
        return new JAXBElement<String>(_ISWSSuoloSchedaColturaPrincipale_QNAME, String.class, ISWSSuoloScheda.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "RotazColturale", scope = ISWSSuoloScheda.class)
    public JAXBElement<String> createISWSSuoloSchedaRotazColturale(String value) {
        return new JAXBElement<String>(_ISWSSuoloSchedaRotazColturale_QNAME, String.class, ISWSSuoloScheda.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "PotenzialeIrriguo", scope = ISWSSuoloScheda.class)
    public JAXBElement<String> createISWSSuoloSchedaPotenzialeIrriguo(String value) {
        return new JAXBElement<String>(_ISWSSuoloSchedaPotenzialeIrriguo_QNAME, String.class, ISWSSuoloScheda.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "TipoIrrigazione", scope = ISWSSuoloScheda.class)
    public JAXBElement<String> createISWSSuoloSchedaTipoIrrigazione(String value) {
        return new JAXBElement<String>(_ISWSSuoloSchedaTipoIrrigazione_QNAME, String.class, ISWSSuoloScheda.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "StruttureAziendali", scope = ISWSSuoloScheda.class)
    public JAXBElement<String> createISWSSuoloSchedaStruttureAziendali(String value) {
        return new JAXBElement<String>(_ISWSSuoloSchedaStruttureAziendali_QNAME, String.class, ISWSSuoloScheda.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "CriteriMantenimento", scope = ISWSSuoloScheda.class)
    public JAXBElement<String> createISWSSuoloSchedaCriteriMantenimento(String value) {
        return new JAXBElement<String>(_ISWSSuoloSchedaCriteriMantenimento_QNAME, String.class, ISWSSuoloScheda.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "Quota", scope = ISWSSuoloScheda.class)
    public JAXBElement<String> createISWSSuoloSchedaQuota(String value) {
        return new JAXBElement<String>(_ISWSSuoloSchedaQuota_QNAME, String.class, ISWSSuoloScheda.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "Pendenza", scope = ISWSSuoloScheda.class)
    public JAXBElement<String> createISWSSuoloSchedaPendenza(String value) {
        return new JAXBElement<String>(_ISWSSuoloSchedaPendenza_QNAME, String.class, ISWSSuoloScheda.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "CodBelfiore", scope = ISWSParticelleScheda.class)
    public JAXBElement<String> createISWSParticelleSchedaCodBelfiore(String value) {
        return new JAXBElement<String>(_ISWSSuoloSchedaCodBelfiore_QNAME, String.class, ISWSParticelleScheda.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "CodiIstaProv", scope = ISWSParticelleScheda.class)
    public JAXBElement<String> createISWSParticelleSchedaCodiIstaProv(String value) {
        return new JAXBElement<String>(_ISWSSuoloSchedaCodiIstaProv_QNAME, String.class, ISWSParticelleScheda.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "CodiIstaComu", scope = ISWSParticelleScheda.class)
    public JAXBElement<String> createISWSParticelleSchedaCodiIstaComu(String value) {
        return new JAXBElement<String>(_ISWSSuoloSchedaCodiIstaComu_QNAME, String.class, ISWSParticelleScheda.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "Comune", scope = ISWSParticelleScheda.class)
    public JAXBElement<String> createISWSParticelleSchedaComune(String value) {
        return new JAXBElement<String>(_ISWSSuoloSchedaComune_QNAME, String.class, ISWSParticelleScheda.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "Sezione", scope = ISWSParticelleScheda.class)
    public JAXBElement<String> createISWSParticelleSchedaSezione(String value) {
        return new JAXBElement<String>(_ISWSSuoloSchedaSezione_QNAME, String.class, ISWSParticelleScheda.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "Foglio", scope = ISWSParticelleScheda.class)
    public JAXBElement<String> createISWSParticelleSchedaFoglio(String value) {
        return new JAXBElement<String>(_ISWSSuoloSchedaFoglio_QNAME, String.class, ISWSParticelleScheda.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "Particella", scope = ISWSParticelleScheda.class)
    public JAXBElement<String> createISWSParticelleSchedaParticella(String value) {
        return new JAXBElement<String>(_ISWSSuoloSchedaParticella_QNAME, String.class, ISWSParticelleScheda.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "Subalterno", scope = ISWSParticelleScheda.class)
    public JAXBElement<String> createISWSParticelleSchedaSubalterno(String value) {
        return new JAXBElement<String>(_ISWSSuoloSchedaSubalterno_QNAME, String.class, ISWSParticelleScheda.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "TipoConduzione", scope = ISWSParticelleScheda.class)
    public JAXBElement<String> createISWSParticelleSchedaTipoConduzione(String value) {
        return new JAXBElement<String>(_ISWSRiep1TipoConduzione_QNAME, String.class, ISWSParticelleScheda.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "FormaConduzione", scope = ISWSParticelleScheda.class)
    public JAXBElement<String> createISWSParticelleSchedaFormaConduzione(String value) {
        return new JAXBElement<String>(_ISWSParticelleSchedaFormaConduzione_QNAME, String.class, ISWSParticelleScheda.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "Protocollo", scope = ISWSParticelleScheda.class)
    public JAXBElement<String> createISWSParticelleSchedaProtocollo(String value) {
        return new JAXBElement<String>(_ISWSParticelleSchedaProtocollo_QNAME, String.class, ISWSParticelleScheda.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "Proprietario", scope = ISWSParticelleScheda.class)
    public JAXBElement<String> createISWSParticelleSchedaProprietario(String value) {
        return new JAXBElement<String>(_ISWSParticelleSchedaProprietario_QNAME, String.class, ISWSParticelleScheda.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "FlagCondParz", scope = ISWSParticelleScheda.class)
    public JAXBElement<String> createISWSParticelleSchedaFlagCondParz(String value) {
        return new JAXBElement<String>(_ISWSParticelleSchedaFlagCondParz_QNAME, String.class, ISWSParticelleScheda.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "DataInizCond", scope = ISWSParticelleScheda.class)
    public JAXBElement<String> createISWSParticelleSchedaDataInizCond(String value) {
        return new JAXBElement<String>(_ISWSParticelleSchedaDataInizCond_QNAME, String.class, ISWSParticelleScheda.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "DataFineCond", scope = ISWSParticelleScheda.class)
    public JAXBElement<String> createISWSParticelleSchedaDataFineCond(String value) {
        return new JAXBElement<String>(_ISWSParticelleSchedaDataFineCond_QNAME, String.class, ISWSParticelleScheda.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "SupCatastale", scope = ISWSParticelleScheda.class)
    public JAXBElement<String> createISWSParticelleSchedaSupCatastale(String value) {
        return new JAXBElement<String>(_ISWSParticelleSchedaSupCatastale_QNAME, String.class, ISWSParticelleScheda.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "SupGrafica", scope = ISWSParticelleScheda.class)
    public JAXBElement<String> createISWSParticelleSchedaSupGrafica(String value) {
        return new JAXBElement<String>(_ISWSParticelleSchedaSupGrafica_QNAME, String.class, ISWSParticelleScheda.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "SupCondotta", scope = ISWSParticelleScheda.class)
    public JAXBElement<String> createISWSParticelleSchedaSupCondotta(String value) {
        return new JAXBElement<String>(_ISWSParticelleSchedaSupCondotta_QNAME, String.class, ISWSParticelleScheda.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "CodDenominazione", scope = WsIdoneita.class)
    public JAXBElement<String> createWsIdoneitaCodDenominazione(String value) {
        return new JAXBElement<String>(_WsIdoneitaCodDenominazione_QNAME, String.class, WsIdoneita.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "CodSottozona", scope = WsIdoneita.class)
    public JAXBElement<String> createWsIdoneitaCodSottozona(String value) {
        return new JAXBElement<String>(_WsIdoneitaCodSottozona_QNAME, String.class, WsIdoneita.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "CodVarietale", scope = WsIdoneita.class)
    public JAXBElement<String> createWsIdoneitaCodVarietale(String value) {
        return new JAXBElement<String>(_WsIdoneitaCodVarietale_QNAME, String.class, WsIdoneita.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "CodColore", scope = WsIdoneita.class)
    public JAXBElement<String> createWsIdoneitaCodColore(String value) {
        return new JAXBElement<String>(_WsIdoneitaCodColore_QNAME, String.class, WsIdoneita.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "DenominazioneVino", scope = WsIdoneita.class)
    public JAXBElement<String> createWsIdoneitaDenominazioneVino(String value) {
        return new JAXBElement<String>(_WsIdoneitaDenominazioneVino_QNAME, String.class, WsIdoneita.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Integer }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link Integer }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "ResaApplicata", scope = WsIdoneita.class)
    public JAXBElement<Integer> createWsIdoneitaResaApplicata(Integer value) {
        return new JAXBElement<Integer>(_WsIdoneitaResaApplicata_QNAME, Integer.class, WsIdoneita.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Integer }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link Integer }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "SupeDettagliata", scope = WsIdoneita.class)
    public JAXBElement<Integer> createWsIdoneitaSupeDettagliata(Integer value) {
        return new JAXBElement<Integer>(_WsIdoneitaSupeDettagliata_QNAME, Integer.class, WsIdoneita.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Integer }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link Integer }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "NumeUNAR", scope = WsIdoneita.class)
    public JAXBElement<Integer> createWsIdoneitaNumeUNAR(Integer value) {
        return new JAXBElement<Integer>(_WsIdoneitaNumeUNAR_QNAME, Integer.class, WsIdoneita.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Integer }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link Integer }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "QtaMaxUvaRivendicabile", scope = WsIdoneita.class)
    public JAXBElement<Integer> createWsIdoneitaQtaMaxUvaRivendicabile(Integer value) {
        return new JAXBElement<Integer>(_WsIdoneitaQtaMaxUvaRivendicabile_QNAME, Integer.class, WsIdoneita.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "CodiceLivello", scope = WsUtilizzoTerraCaba7 .class)
    public JAXBElement<String> createWsUtilizzoTerraCaba7CodiceLivello(String value) {
        return new JAXBElement<String>(_LivelloCodiceLivello_QNAME, String.class, WsUtilizzoTerraCaba7 .class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "CodiceOccupazioneVarieta", scope = WsUtilizzoTerraCaba7 .class)
    public JAXBElement<String> createWsUtilizzoTerraCaba7CodiceOccupazioneVarieta(String value) {
        return new JAXBElement<String>(_ISWSSuoloSchedaCodiceOccupazioneVarieta_QNAME, String.class, WsUtilizzoTerraCaba7 .class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "CodiceMacrouso", scope = WsUtilizzoTerraCaba7 .class)
    public JAXBElement<String> createWsUtilizzoTerraCaba7CodiceMacrouso(String value) {
        return new JAXBElement<String>(_LivelloCodiceMacrouso_QNAME, String.class, WsUtilizzoTerraCaba7 .class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "CodiceProdotto", scope = WsUtilizzoTerraCaba7 .class)
    public JAXBElement<String> createWsUtilizzoTerraCaba7CodiceProdotto(String value) {
        return new JAXBElement<String>(_WsUtilizzoTerraCaba7CodiceProdotto_QNAME, String.class, WsUtilizzoTerraCaba7 .class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "CodiceVarieta", scope = WsUtilizzoTerraCaba7 .class)
    public JAXBElement<String> createWsUtilizzoTerraCaba7CodiceVarieta(String value) {
        return new JAXBElement<String>(_WsUtilizzoTerraCaba7CodiceVarieta_QNAME, String.class, WsUtilizzoTerraCaba7 .class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Integer }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link Integer }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "SuperficieEleggibile", scope = WsUtilizzoTerraCaba7 .class)
    public JAXBElement<Integer> createWsUtilizzoTerraCaba7SuperficieEleggibile(Integer value) {
        return new JAXBElement<Integer>(_WsUtilizzoTerraCaba7SuperficieEleggibile_QNAME, Integer.class, WsUtilizzoTerraCaba7 .class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "CodiceColtivazioneBiologica", scope = WsUtilizzoTerraCaba7 .class)
    public JAXBElement<String> createWsUtilizzoTerraCaba7CodiceColtivazioneBiologica(String value) {
        return new JAXBElement<String>(_WsUtilizzoTerraCaba7CodiceColtivazioneBiologica_QNAME, String.class, WsUtilizzoTerraCaba7 .class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "CodiceTipoSemina", scope = WsUtilizzoTerraCaba7 .class)
    public JAXBElement<String> createWsUtilizzoTerraCaba7CodiceTipoSemina(String value) {
        return new JAXBElement<String>(_WsUtilizzoTerraCaba7CodiceTipoSemina_QNAME, String.class, WsUtilizzoTerraCaba7 .class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "CodiceTipoIrrigazione", scope = WsUtilizzoTerraCaba7 .class)
    public JAXBElement<String> createWsUtilizzoTerraCaba7CodiceTipoIrrigazione(String value) {
        return new JAXBElement<String>(_WsUtilizzoTerraCaba7CodiceTipoIrrigazione_QNAME, String.class, WsUtilizzoTerraCaba7 .class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "CodiceProtezioneColture", scope = WsUtilizzoTerraCaba7 .class)
    public JAXBElement<String> createWsUtilizzoTerraCaba7CodiceProtezioneColture(String value) {
        return new JAXBElement<String>(_WsUtilizzoTerraCaba7CodiceProtezioneColture_QNAME, String.class, WsUtilizzoTerraCaba7 .class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "CodiceFaseAllevamento", scope = WsUtilizzoTerraCaba7 .class)
    public JAXBElement<String> createWsUtilizzoTerraCaba7CodiceFaseAllevamento(String value) {
        return new JAXBElement<String>(_WsUtilizzoTerraCaba7CodiceFaseAllevamento_QNAME, String.class, WsUtilizzoTerraCaba7 .class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "CodiceFormaAllevamento", scope = WsUtilizzoTerraCaba7 .class)
    public JAXBElement<String> createWsUtilizzoTerraCaba7CodiceFormaAllevamento(String value) {
        return new JAXBElement<String>(_WsUtilizzoTerraCaba7CodiceFormaAllevamento_QNAME, String.class, WsUtilizzoTerraCaba7 .class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "FlagColtPrincipale", scope = WsUtilizzoTerraCaba7 .class)
    public JAXBElement<String> createWsUtilizzoTerraCaba7FlagColtPrincipale(String value) {
        return new JAXBElement<String>(_WsUtilizzoTerraCaba7FlagColtPrincipale_QNAME, String.class, WsUtilizzoTerraCaba7 .class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "MantPratiPermanente", scope = WsUtilizzoTerraCaba7 .class)
    public JAXBElement<String> createWsUtilizzoTerraCaba7MantPratiPermanente(String value) {
        return new JAXBElement<String>(_WsUtilizzoTerraCaba7MantPratiPermanente_QNAME, String.class, WsUtilizzoTerraCaba7 .class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "MantenSupAgricola", scope = WsUtilizzoTerraCaba7 .class)
    public JAXBElement<String> createWsUtilizzoTerraCaba7MantenSupAgricola(String value) {
        return new JAXBElement<String>(_WsUtilizzoTerraCaba7MantenSupAgricola_QNAME, String.class, WsUtilizzoTerraCaba7 .class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Integer }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link Integer }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "SuperficieEleggibileOP", scope = WsUtilizzoTerraCaba7 .class)
    public JAXBElement<Integer> createWsUtilizzoTerraCaba7SuperficieEleggibileOP(Integer value) {
        return new JAXBElement<Integer>(_WsUtilizzoTerraCaba7SuperficieEleggibileOP_QNAME, Integer.class, WsUtilizzoTerraCaba7 .class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Integer }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link Integer }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "NumeroPiante", scope = WsUtilizzoTerraCaba7 .class)
    public JAXBElement<Integer> createWsUtilizzoTerraCaba7NumeroPiante(Integer value) {
        return new JAXBElement<Integer>(_ISWSSuoloSchedaNumeroPiante_QNAME, Integer.class, WsUtilizzoTerraCaba7 .class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "SestoImpiantoSuFila", scope = WsUtilizzoTerraCaba7 .class)
    public JAXBElement<String> createWsUtilizzoTerraCaba7SestoImpiantoSuFila(String value) {
        return new JAXBElement<String>(_ISWSSuoloSchedaSestoImpiantoSuFila_QNAME, String.class, WsUtilizzoTerraCaba7 .class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "SestoImpiantoTraFile", scope = WsUtilizzoTerraCaba7 .class)
    public JAXBElement<String> createWsUtilizzoTerraCaba7SestoImpiantoTraFile(String value) {
        return new JAXBElement<String>(_ISWSSuoloSchedaSestoImpiantoTraFile_QNAME, String.class, WsUtilizzoTerraCaba7 .class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "AnnoImpianto", scope = WsUtilizzoTerraCaba7 .class)
    public JAXBElement<String> createWsUtilizzoTerraCaba7AnnoImpianto(String value) {
        return new JAXBElement<String>(_ISWSSuoloSchedaAnnoImpianto_QNAME, String.class, WsUtilizzoTerraCaba7 .class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "TipoImpianto", scope = WsUtilizzoTerraCaba7 .class)
    public JAXBElement<String> createWsUtilizzoTerraCaba7TipoImpianto(String value) {
        return new JAXBElement<String>(_WsUtilizzoTerraCaba7TipoImpianto_QNAME, String.class, WsUtilizzoTerraCaba7 .class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "TipoCertificazione", scope = WsUtilizzoTerraCaba7 .class)
    public JAXBElement<String> createWsUtilizzoTerraCaba7TipoCertificazione(String value) {
        return new JAXBElement<String>(_WsUtilizzoTerraCaba7TipoCertificazione_QNAME, String.class, WsUtilizzoTerraCaba7 .class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "Percentuale", scope = WsUtilizzoTerraCaba7 .class)
    public JAXBElement<String> createWsUtilizzoTerraCaba7Percentuale(String value) {
        return new JAXBElement<String>(_WsUtilizzoTerraCaba7Percentuale_QNAME, String.class, WsUtilizzoTerraCaba7 .class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Integer }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link Integer }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "Menzione", scope = WsUtilizzoTerraCaba7 .class)
    public JAXBElement<Integer> createWsUtilizzoTerraCaba7Menzione(Integer value) {
        return new JAXBElement<Integer>(_WsUtilizzoTerraCaba7Menzione_QNAME, Integer.class, WsUtilizzoTerraCaba7 .class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "TipoUtilizzoOlivo", scope = WsUtilizzoTerraCaba7 .class)
    public JAXBElement<String> createWsUtilizzoTerraCaba7TipoUtilizzoOlivo(String value) {
        return new JAXBElement<String>(_WsUtilizzoTerraCaba7TipoUtilizzoOlivo_QNAME, String.class, WsUtilizzoTerraCaba7 .class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "CapacitaProduttiva", scope = WsUtilizzoTerraCaba7 .class)
    public JAXBElement<String> createWsUtilizzoTerraCaba7CapacitaProduttiva(String value) {
        return new JAXBElement<String>(_WsUtilizzoTerraCaba7CapacitaProduttiva_QNAME, String.class, WsUtilizzoTerraCaba7 .class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Integer }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link Integer }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "Altitudine", scope = WsUtilizzoTerraCaba7 .class)
    public JAXBElement<Integer> createWsUtilizzoTerraCaba7Altitudine(Integer value) {
        return new JAXBElement<Integer>(_WsUtilizzoTerraCaba7Altitudine_QNAME, Integer.class, WsUtilizzoTerraCaba7 .class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "FlagProduzioneIntegrata", scope = WsUtilizzoTerraCaba7 .class)
    public JAXBElement<String> createWsUtilizzoTerraCaba7FlagProduzioneIntegrata(String value) {
        return new JAXBElement<String>(_WsUtilizzoTerraCaba7FlagProduzioneIntegrata_QNAME, String.class, WsUtilizzoTerraCaba7 .class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "CodiceNormativa", scope = ISWSIndicatori.class)
    public JAXBElement<String> createISWSIndicatoriCodiceNormativa(String value) {
        return new JAXBElement<String>(_ISWSIndicatoriCodiceNormativa_QNAME, String.class, ISWSIndicatori.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "NormativaRiferimento", scope = ISWSIndicatori.class)
    public JAXBElement<String> createISWSIndicatoriNormativaRiferimento(String value) {
        return new JAXBElement<String>(_ISWSIndicatoriNormativaRiferimento_QNAME, String.class, ISWSIndicatori.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "Descrizione", scope = ISWSIndicatori.class)
    public JAXBElement<String> createISWSIndicatoriDescrizione(String value) {
        return new JAXBElement<String>(_ISWSIndicatoriDescrizione_QNAME, String.class, ISWSIndicatori.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "DataValidita", scope = ISWSIndicatori.class)
    public JAXBElement<String> createISWSIndicatoriDataValidita(String value) {
        return new JAXBElement<String>(_ISWSIndicatoriDataValidita_QNAME, String.class, ISWSIndicatori.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Integer }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link Integer }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "StatoIndicatore", scope = ISWSIndicatori.class)
    public JAXBElement<Integer> createISWSIndicatoriStatoIndicatore(Integer value) {
        return new JAXBElement<Integer>(_ISWSIndicatoriStatoIndicatore_QNAME, Integer.class, ISWSIndicatori.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "CodiceLivello", scope = WsUtilizzoTerraCaba.class)
    public JAXBElement<String> createWsUtilizzoTerraCabaCodiceLivello(String value) {
        return new JAXBElement<String>(_LivelloCodiceLivello_QNAME, String.class, WsUtilizzoTerraCaba.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "CodiceOccupazioneVarieta", scope = WsUtilizzoTerraCaba.class)
    public JAXBElement<String> createWsUtilizzoTerraCabaCodiceOccupazioneVarieta(String value) {
        return new JAXBElement<String>(_ISWSSuoloSchedaCodiceOccupazioneVarieta_QNAME, String.class, WsUtilizzoTerraCaba.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "CodiceMacrouso", scope = WsUtilizzoTerraCaba.class)
    public JAXBElement<String> createWsUtilizzoTerraCabaCodiceMacrouso(String value) {
        return new JAXBElement<String>(_LivelloCodiceMacrouso_QNAME, String.class, WsUtilizzoTerraCaba.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "CodiceProdotto", scope = WsUtilizzoTerraCaba.class)
    public JAXBElement<String> createWsUtilizzoTerraCabaCodiceProdotto(String value) {
        return new JAXBElement<String>(_WsUtilizzoTerraCaba7CodiceProdotto_QNAME, String.class, WsUtilizzoTerraCaba.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "CodiceVarieta", scope = WsUtilizzoTerraCaba.class)
    public JAXBElement<String> createWsUtilizzoTerraCabaCodiceVarieta(String value) {
        return new JAXBElement<String>(_WsUtilizzoTerraCaba7CodiceVarieta_QNAME, String.class, WsUtilizzoTerraCaba.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Integer }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link Integer }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "SuperficieEleggibile", scope = WsUtilizzoTerraCaba.class)
    public JAXBElement<Integer> createWsUtilizzoTerraCabaSuperficieEleggibile(Integer value) {
        return new JAXBElement<Integer>(_WsUtilizzoTerraCaba7SuperficieEleggibile_QNAME, Integer.class, WsUtilizzoTerraCaba.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "CodiceColtivazioneBiologica", scope = WsUtilizzoTerraCaba.class)
    public JAXBElement<String> createWsUtilizzoTerraCabaCodiceColtivazioneBiologica(String value) {
        return new JAXBElement<String>(_WsUtilizzoTerraCaba7CodiceColtivazioneBiologica_QNAME, String.class, WsUtilizzoTerraCaba.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "CodiceTipoSemina", scope = WsUtilizzoTerraCaba.class)
    public JAXBElement<String> createWsUtilizzoTerraCabaCodiceTipoSemina(String value) {
        return new JAXBElement<String>(_WsUtilizzoTerraCaba7CodiceTipoSemina_QNAME, String.class, WsUtilizzoTerraCaba.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "CodiceTipoIrrigazione", scope = WsUtilizzoTerraCaba.class)
    public JAXBElement<String> createWsUtilizzoTerraCabaCodiceTipoIrrigazione(String value) {
        return new JAXBElement<String>(_WsUtilizzoTerraCaba7CodiceTipoIrrigazione_QNAME, String.class, WsUtilizzoTerraCaba.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "CodiceProtezioneColture", scope = WsUtilizzoTerraCaba.class)
    public JAXBElement<String> createWsUtilizzoTerraCabaCodiceProtezioneColture(String value) {
        return new JAXBElement<String>(_WsUtilizzoTerraCaba7CodiceProtezioneColture_QNAME, String.class, WsUtilizzoTerraCaba.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "CodiceFaseAllevamento", scope = WsUtilizzoTerraCaba.class)
    public JAXBElement<String> createWsUtilizzoTerraCabaCodiceFaseAllevamento(String value) {
        return new JAXBElement<String>(_WsUtilizzoTerraCaba7CodiceFaseAllevamento_QNAME, String.class, WsUtilizzoTerraCaba.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "CodiceFormaAllevamento", scope = WsUtilizzoTerraCaba.class)
    public JAXBElement<String> createWsUtilizzoTerraCabaCodiceFormaAllevamento(String value) {
        return new JAXBElement<String>(_WsUtilizzoTerraCaba7CodiceFormaAllevamento_QNAME, String.class, WsUtilizzoTerraCaba.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "FlagColtPrincipale", scope = WsUtilizzoTerraCaba.class)
    public JAXBElement<String> createWsUtilizzoTerraCabaFlagColtPrincipale(String value) {
        return new JAXBElement<String>(_WsUtilizzoTerraCaba7FlagColtPrincipale_QNAME, String.class, WsUtilizzoTerraCaba.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "MantPratiPermanente", scope = WsUtilizzoTerraCaba.class)
    public JAXBElement<String> createWsUtilizzoTerraCabaMantPratiPermanente(String value) {
        return new JAXBElement<String>(_WsUtilizzoTerraCaba7MantPratiPermanente_QNAME, String.class, WsUtilizzoTerraCaba.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "MantenSupAgricola", scope = WsUtilizzoTerraCaba.class)
    public JAXBElement<String> createWsUtilizzoTerraCabaMantenSupAgricola(String value) {
        return new JAXBElement<String>(_WsUtilizzoTerraCaba7MantenSupAgricola_QNAME, String.class, WsUtilizzoTerraCaba.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Integer }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link Integer }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "SuperficieEleggibileOP", scope = WsUtilizzoTerraCaba.class)
    public JAXBElement<Integer> createWsUtilizzoTerraCabaSuperficieEleggibileOP(Integer value) {
        return new JAXBElement<Integer>(_WsUtilizzoTerraCaba7SuperficieEleggibileOP_QNAME, Integer.class, WsUtilizzoTerraCaba.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Integer }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link Integer }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "NumeroPiante", scope = WsUtilizzoTerraCaba.class)
    public JAXBElement<Integer> createWsUtilizzoTerraCabaNumeroPiante(Integer value) {
        return new JAXBElement<Integer>(_ISWSSuoloSchedaNumeroPiante_QNAME, Integer.class, WsUtilizzoTerraCaba.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "SestoImpiantoSuFila", scope = WsUtilizzoTerraCaba.class)
    public JAXBElement<String> createWsUtilizzoTerraCabaSestoImpiantoSuFila(String value) {
        return new JAXBElement<String>(_ISWSSuoloSchedaSestoImpiantoSuFila_QNAME, String.class, WsUtilizzoTerraCaba.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "SestoImpiantoTraFile", scope = WsUtilizzoTerraCaba.class)
    public JAXBElement<String> createWsUtilizzoTerraCabaSestoImpiantoTraFile(String value) {
        return new JAXBElement<String>(_ISWSSuoloSchedaSestoImpiantoTraFile_QNAME, String.class, WsUtilizzoTerraCaba.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "AnnoImpianto", scope = WsUtilizzoTerraCaba.class)
    public JAXBElement<String> createWsUtilizzoTerraCabaAnnoImpianto(String value) {
        return new JAXBElement<String>(_ISWSSuoloSchedaAnnoImpianto_QNAME, String.class, WsUtilizzoTerraCaba.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "TipoImpianto", scope = WsUtilizzoTerraCaba.class)
    public JAXBElement<String> createWsUtilizzoTerraCabaTipoImpianto(String value) {
        return new JAXBElement<String>(_WsUtilizzoTerraCaba7TipoImpianto_QNAME, String.class, WsUtilizzoTerraCaba.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "TipoCertificazione", scope = WsUtilizzoTerraCaba.class)
    public JAXBElement<String> createWsUtilizzoTerraCabaTipoCertificazione(String value) {
        return new JAXBElement<String>(_WsUtilizzoTerraCaba7TipoCertificazione_QNAME, String.class, WsUtilizzoTerraCaba.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "Percentuale", scope = WsUtilizzoTerraCaba.class)
    public JAXBElement<String> createWsUtilizzoTerraCabaPercentuale(String value) {
        return new JAXBElement<String>(_WsUtilizzoTerraCaba7Percentuale_QNAME, String.class, WsUtilizzoTerraCaba.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Integer }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link Integer }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "Menzione", scope = WsUtilizzoTerraCaba.class)
    public JAXBElement<Integer> createWsUtilizzoTerraCabaMenzione(Integer value) {
        return new JAXBElement<Integer>(_WsUtilizzoTerraCaba7Menzione_QNAME, Integer.class, WsUtilizzoTerraCaba.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "TipoUtilizzoOlivo", scope = WsUtilizzoTerraCaba.class)
    public JAXBElement<String> createWsUtilizzoTerraCabaTipoUtilizzoOlivo(String value) {
        return new JAXBElement<String>(_WsUtilizzoTerraCaba7TipoUtilizzoOlivo_QNAME, String.class, WsUtilizzoTerraCaba.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "CapacitaProduttiva", scope = WsUtilizzoTerraCaba.class)
    public JAXBElement<String> createWsUtilizzoTerraCabaCapacitaProduttiva(String value) {
        return new JAXBElement<String>(_WsUtilizzoTerraCaba7CapacitaProduttiva_QNAME, String.class, WsUtilizzoTerraCaba.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Integer }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link Integer }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "Altitudine", scope = WsUtilizzoTerraCaba.class)
    public JAXBElement<Integer> createWsUtilizzoTerraCabaAltitudine(Integer value) {
        return new JAXBElement<Integer>(_WsUtilizzoTerraCaba7Altitudine_QNAME, Integer.class, WsUtilizzoTerraCaba.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "FlagProduzioneIntegrata", scope = WsUtilizzoTerraCaba.class)
    public JAXBElement<String> createWsUtilizzoTerraCabaFlagProduzioneIntegrata(String value) {
        return new JAXBElement<String>(_WsUtilizzoTerraCaba7FlagProduzioneIntegrata_QNAME, String.class, WsUtilizzoTerraCaba.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Integer }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link Integer }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "superficieEligibile", scope = ISWSUtilizzoTerra15 .class)
    public JAXBElement<Integer> createISWSUtilizzoTerra15SuperficieEligibile(Integer value) {
        return new JAXBElement<Integer>(_ISWSUtilizzoTerra15SuperficieEligibile_QNAME, Integer.class, ISWSUtilizzoTerra15 .class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Integer }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link Integer }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "superficieEligibileOP", scope = ISWSUtilizzoTerra15 .class)
    public JAXBElement<Integer> createISWSUtilizzoTerra15SuperficieEligibileOP(Integer value) {
        return new JAXBElement<Integer>(_ISWSUtilizzoTerra15SuperficieEligibileOP_QNAME, Integer.class, ISWSUtilizzoTerra15 .class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Integer }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link Integer }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "SuperficieEligibile", scope = ISWSDettaglioUtilizzoTerra15 .class)
    public JAXBElement<Integer> createISWSDettaglioUtilizzoTerra15SuperficieEligibile(Integer value) {
        return new JAXBElement<Integer>(_ISWSDettaglioUtilizzoTerra15SuperficieEligibile_QNAME, Integer.class, ISWSDettaglioUtilizzoTerra15 .class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Integer }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link Integer }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "superficieEligibileOP", scope = ISWSDettaglioUtilizzoTerra15 .class)
    public JAXBElement<Integer> createISWSDettaglioUtilizzoTerra15SuperficieEligibileOP(Integer value) {
        return new JAXBElement<Integer>(_ISWSUtilizzoTerra15SuperficieEligibileOP_QNAME, Integer.class, ISWSDettaglioUtilizzoTerra15 .class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "DataFineUtilizzo", scope = ISWSDettaglioUtilizzoTerra15 .class)
    public JAXBElement<String> createISWSDettaglioUtilizzoTerra15DataFineUtilizzo(String value) {
        return new JAXBElement<String>(_ISWSDettaglioUtilizzoTerra15DataFineUtilizzo_QNAME, String.class, ISWSDettaglioUtilizzoTerra15 .class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Integer }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link Integer }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "NumeroPiante", scope = ISWSDettaglioUtilizzoTerra15 .class)
    public JAXBElement<Integer> createISWSDettaglioUtilizzoTerra15NumeroPiante(Integer value) {
        return new JAXBElement<Integer>(_ISWSSuoloSchedaNumeroPiante_QNAME, Integer.class, ISWSDettaglioUtilizzoTerra15 .class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "FlagColtPrincipale", scope = ISWSDettaglioUtilizzoTerra15 .class)
    public JAXBElement<String> createISWSDettaglioUtilizzoTerra15FlagColtPrincipale(String value) {
        return new JAXBElement<String>(_WsUtilizzoTerraCaba7FlagColtPrincipale_QNAME, String.class, ISWSDettaglioUtilizzoTerra15 .class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "AnnoImpianto", scope = ISWSDettaglioUtilizzoTerra15 .class)
    public JAXBElement<String> createISWSDettaglioUtilizzoTerra15AnnoImpianto(String value) {
        return new JAXBElement<String>(_ISWSSuoloSchedaAnnoImpianto_QNAME, String.class, ISWSDettaglioUtilizzoTerra15 .class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "SestoImpiantoSuFila", scope = ISWSDettaglioUtilizzoTerra15 .class)
    public JAXBElement<String> createISWSDettaglioUtilizzoTerra15SestoImpiantoSuFila(String value) {
        return new JAXBElement<String>(_ISWSSuoloSchedaSestoImpiantoSuFila_QNAME, String.class, ISWSDettaglioUtilizzoTerra15 .class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "SestoImpiantoTraFile", scope = ISWSDettaglioUtilizzoTerra15 .class)
    public JAXBElement<String> createISWSDettaglioUtilizzoTerra15SestoImpiantoTraFile(String value) {
        return new JAXBElement<String>(_ISWSSuoloSchedaSestoImpiantoTraFile_QNAME, String.class, ISWSDettaglioUtilizzoTerra15 .class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "TipoImpianto", scope = ISWSDettaglioUtilizzoTerra15 .class)
    public JAXBElement<String> createISWSDettaglioUtilizzoTerra15TipoImpianto(String value) {
        return new JAXBElement<String>(_WsUtilizzoTerraCaba7TipoImpianto_QNAME, String.class, ISWSDettaglioUtilizzoTerra15 .class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "ColtivazioneBiologica", scope = ISWSDettaglioUtilizzoTerra15 .class)
    public JAXBElement<String> createISWSDettaglioUtilizzoTerra15ColtivazioneBiologica(String value) {
        return new JAXBElement<String>(_ISWSDettaglioUtilizzoTerra15ColtivazioneBiologica_QNAME, String.class, ISWSDettaglioUtilizzoTerra15 .class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "TipologiaSemina", scope = ISWSDettaglioUtilizzoTerra15 .class)
    public JAXBElement<String> createISWSDettaglioUtilizzoTerra15TipologiaSemina(String value) {
        return new JAXBElement<String>(_ISWSDettaglioUtilizzoTerra15TipologiaSemina_QNAME, String.class, ISWSDettaglioUtilizzoTerra15 .class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "TipologiaIrrigazione", scope = ISWSDettaglioUtilizzoTerra15 .class)
    public JAXBElement<String> createISWSDettaglioUtilizzoTerra15TipologiaIrrigazione(String value) {
        return new JAXBElement<String>(_ISWSDettaglioUtilizzoTerra15TipologiaIrrigazione_QNAME, String.class, ISWSDettaglioUtilizzoTerra15 .class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "ProtezioneColture", scope = ISWSDettaglioUtilizzoTerra15 .class)
    public JAXBElement<String> createISWSDettaglioUtilizzoTerra15ProtezioneColture(String value) {
        return new JAXBElement<String>(_ISWSDettaglioUtilizzoTerra15ProtezioneColture_QNAME, String.class, ISWSDettaglioUtilizzoTerra15 .class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "FaseAllevamento", scope = ISWSDettaglioUtilizzoTerra15 .class)
    public JAXBElement<String> createISWSDettaglioUtilizzoTerra15FaseAllevamento(String value) {
        return new JAXBElement<String>(_ISWSDettaglioUtilizzoTerra15FaseAllevamento_QNAME, String.class, ISWSDettaglioUtilizzoTerra15 .class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "MantPratiPermanente", scope = ISWSDettaglioUtilizzoTerra15 .class)
    public JAXBElement<String> createISWSDettaglioUtilizzoTerra15MantPratiPermanente(String value) {
        return new JAXBElement<String>(_WsUtilizzoTerraCaba7MantPratiPermanente_QNAME, String.class, ISWSDettaglioUtilizzoTerra15 .class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "MantenSupAgricola", scope = ISWSDettaglioUtilizzoTerra15 .class)
    public JAXBElement<String> createISWSDettaglioUtilizzoTerra15MantenSupAgricola(String value) {
        return new JAXBElement<String>(_WsUtilizzoTerraCaba7MantenSupAgricola_QNAME, String.class, ISWSDettaglioUtilizzoTerra15 .class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "tipoCertificazione", scope = ISWSDettaglioUtilizzoTerra15 .class)
    public JAXBElement<String> createISWSDettaglioUtilizzoTerra15TipoCertificazione(String value) {
        return new JAXBElement<String>(_ISWSDettaglioUtilizzoTerra15TipoCertificazione_QNAME, String.class, ISWSDettaglioUtilizzoTerra15 .class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "percentuale", scope = ISWSDettaglioUtilizzoTerra15 .class)
    public JAXBElement<String> createISWSDettaglioUtilizzoTerra15Percentuale(String value) {
        return new JAXBElement<String>(_ISWSDettaglioUtilizzoTerra15Percentuale_QNAME, String.class, ISWSDettaglioUtilizzoTerra15 .class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Integer }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link Integer }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "menzione", scope = ISWSDettaglioUtilizzoTerra15 .class)
    public JAXBElement<Integer> createISWSDettaglioUtilizzoTerra15Menzione(Integer value) {
        return new JAXBElement<Integer>(_ISWSDettaglioUtilizzoTerra15Menzione_QNAME, Integer.class, ISWSDettaglioUtilizzoTerra15 .class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "tipoUtilizzolivo", scope = ISWSDettaglioUtilizzoTerra15 .class)
    public JAXBElement<String> createISWSDettaglioUtilizzoTerra15TipoUtilizzolivo(String value) {
        return new JAXBElement<String>(_ISWSDettaglioUtilizzoTerra15TipoUtilizzolivo_QNAME, String.class, ISWSDettaglioUtilizzoTerra15 .class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "capacitaProduttiva", scope = ISWSDettaglioUtilizzoTerra15 .class)
    public JAXBElement<String> createISWSDettaglioUtilizzoTerra15CapacitaProduttiva(String value) {
        return new JAXBElement<String>(_ISWSDettaglioUtilizzoTerra15CapacitaProduttiva_QNAME, String.class, ISWSDettaglioUtilizzoTerra15 .class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Integer }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link Integer }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "altitudine", scope = ISWSDettaglioUtilizzoTerra15 .class)
    public JAXBElement<Integer> createISWSDettaglioUtilizzoTerra15Altitudine(Integer value) {
        return new JAXBElement<Integer>(_ISWSDettaglioUtilizzoTerra15Altitudine_QNAME, Integer.class, ISWSDettaglioUtilizzoTerra15 .class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "TipoDocumento", scope = WsDocumenti.class)
    public JAXBElement<String> createWsDocumentiTipoDocumento(String value) {
        return new JAXBElement<String>(_ISWSDatiFascicolo15TipoDocumento_QNAME, String.class, WsDocumenti.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "SuperficieGrafica", scope = ISWSBaseTerritorio1 .class)
    public JAXBElement<String> createISWSBaseTerritorio1SuperficieGrafica(String value) {
        return new JAXBElement<String>(_ISWSBaseTerritorio1SuperficieGrafica_QNAME, String.class, ISWSBaseTerritorio1 .class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ISWSDettaglioDURC }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link ISWSDettaglioDURC }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "DettaglioDURC", scope = ISWSDURC.class)
    public JAXBElement<ISWSDettaglioDURC> createISWSDURCDettaglioDURC(ISWSDettaglioDURC value) {
        return new JAXBElement<ISWSDettaglioDURC>(_ISWSDURCDettaglioDURC_QNAME, ISWSDettaglioDURC.class, ISWSDURC.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ISWSRiepilogoScheda }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link ISWSRiepilogoScheda }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "Riepilogo", scope = ISWSScheda.class)
    public JAXBElement<ISWSRiepilogoScheda> createISWSSchedaRiepilogo(ISWSRiepilogoScheda value) {
        return new JAXBElement<ISWSRiepilogoScheda>(_ISWSSchedaRiepilogo_QNAME, ISWSRiepilogoScheda.class, ISWSScheda.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "IDScheda", scope = ISWSRespSchede.class)
    public JAXBElement<String> createISWSRespSchedeIDScheda(String value) {
        return new JAXBElement<String>(_ISWSRespSchedeIDScheda_QNAME, String.class, ISWSRespSchede.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "DataScheda", scope = ISWSRespSchede.class)
    public JAXBElement<String> createISWSRespSchedeDataScheda(String value) {
        return new JAXBElement<String>(_ISWSRespSchedeDataScheda_QNAME, String.class, ISWSRespSchede.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "CodiZVN", scope = ISWSTerritorioFS7 .class)
    public JAXBElement<String> createISWSTerritorioFS7CodiZVN(String value) {
        return new JAXBElement<String>(_ISWSTerritorioFS7CodiZVN_QNAME, String.class, ISWSTerritorioFS7 .class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "CodiZVN", scope = ISWSTerritorioFS6 .class)
    public JAXBElement<String> createISWSTerritorioFS6CodiZVN(String value) {
        return new JAXBElement<String>(_ISWSTerritorioFS7CodiZVN_QNAME, String.class, ISWSTerritorioFS6 .class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "sessoPF", scope = ISWSRespAnagFascicolo15 .class)
    public JAXBElement<String> createISWSRespAnagFascicolo15SessoPF(String value) {
        return new JAXBElement<String>(_ISWSRespAnagFascicolo15SessoPF_QNAME, String.class, ISWSRespAnagFascicolo15 .class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "TipoDocumento", scope = ISWSRespAnagFascicolo15 .class)
    public JAXBElement<String> createISWSRespAnagFascicolo15TipoDocumento(String value) {
        return new JAXBElement<String>(_ISWSDatiFascicolo15TipoDocumento_QNAME, String.class, ISWSRespAnagFascicolo15 .class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "DescPec", scope = ISWSRespAnagFascicolo15 .class)
    public JAXBElement<String> createISWSRespAnagFascicolo15DescPec(String value) {
        return new JAXBElement<String>(_ISWSRespAnagFascicolo15DescPec_QNAME, String.class, ISWSRespAnagFascicolo15 .class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "Email", scope = ISWSRespAnagFascicolo15 .class)
    public JAXBElement<String> createISWSRespAnagFascicolo15Email(String value) {
        return new JAXBElement<String>(_ISWSDatiFascicolo15Email_QNAME, String.class, ISWSRespAnagFascicolo15 .class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "StatoFascicolo", scope = ISWSCUAAModificato.class)
    public JAXBElement<String> createISWSCUAAModificatoStatoFascicolo(String value) {
        return new JAXBElement<String>(_ISWSCUAAModificatoStatoFascicolo_QNAME, String.class, ISWSCUAAModificato.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "DataOperazione", scope = ISWSCUAAModificato.class)
    public JAXBElement<String> createISWSCUAAModificatoDataOperazione(String value) {
        return new JAXBElement<String>(_ISWSCUAAModificatoDataOperazione_QNAME, String.class, ISWSCUAAModificato.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "CAANew", scope = ISWSCUAAModificato.class)
    public JAXBElement<String> createISWSCUAAModificatoCAANew(String value) {
        return new JAXBElement<String>(_ISWSCUAAModificatoCAANew_QNAME, String.class, ISWSCUAAModificato.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "CodiceOccupazione", scope = ISWSRiep3 .class)
    public JAXBElement<String> createISWSRiep3CodiceOccupazione(String value) {
        return new JAXBElement<String>(_ISWSRiep3CodiceOccupazione_QNAME, String.class, ISWSRiep3 .class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "CodiceDestinazioneUso", scope = ISWSRiep3 .class)
    public JAXBElement<String> createISWSRiep3CodiceDestinazioneUso(String value) {
        return new JAXBElement<String>(_ISWSSuoloSchedaCodiceDestinazioneUso_QNAME, String.class, ISWSRiep3 .class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "CodiceUso", scope = ISWSRiep3 .class)
    public JAXBElement<String> createISWSRiep3CodiceUso(String value) {
        return new JAXBElement<String>(_ISWSSuoloSchedaCodiceUso_QNAME, String.class, ISWSRiep3 .class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "CodiceQualita", scope = ISWSRiep3 .class)
    public JAXBElement<String> createISWSRiep3CodiceQualita(String value) {
        return new JAXBElement<String>(_ISWSSuoloSchedaCodiceQualita_QNAME, String.class, ISWSRiep3 .class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "CodiceVarieta", scope = ISWSRiep3 .class)
    public JAXBElement<String> createISWSRiep3CodiceVarieta(String value) {
        return new JAXBElement<String>(_WsUtilizzoTerraCaba7CodiceVarieta_QNAME, String.class, ISWSRiep3 .class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "SuperficieDichiarata", scope = ISWSRiep3 .class)
    public JAXBElement<String> createISWSRiep3SuperficieDichiarata(String value) {
        return new JAXBElement<String>(_LivelloSuperficieDichiarata_QNAME, String.class, ISWSRiep3 .class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "SuperficieRiscontrata", scope = ISWSRiep3 .class)
    public JAXBElement<String> createISWSRiep3SuperficieRiscontrata(String value) {
        return new JAXBElement<String>(_LivelloSuperficieRiscontrata_QNAME, String.class, ISWSRiep3 .class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "AnnoCampagna", scope = ISWSCHEDE.class)
    public JAXBElement<XMLGregorianCalendar> createISWSCHEDEAnnoCampagna(XMLGregorianCalendar value) {
        return new JAXBElement<XMLGregorianCalendar>(_ISWSCHEDEAnnoCampagna_QNAME, XMLGregorianCalendar.class, ISWSCHEDE.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "CasiParticolari", scope = ISWSFabbricatoFS6 .class)
    public JAXBElement<String> createISWSFabbricatoFS6CasiParticolari(String value) {
        return new JAXBElement<String>(_ISWSFabbricatoFS6CasiParticolari_QNAME, String.class, ISWSFabbricatoFS6 .class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "CodiceLivello", scope = ISWSFabbricatoFS6 .class)
    public JAXBElement<String> createISWSFabbricatoFS6CodiceLivello(String value) {
        return new JAXBElement<String>(_LivelloCodiceLivello_QNAME, String.class, ISWSFabbricatoFS6 .class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "CodiceOccupazioneVarieta", scope = ISWSFabbricatoFS6 .class)
    public JAXBElement<String> createISWSFabbricatoFS6CodiceOccupazioneVarieta(String value) {
        return new JAXBElement<String>(_ISWSSuoloSchedaCodiceOccupazioneVarieta_QNAME, String.class, ISWSFabbricatoFS6 .class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "CasiParticolari", scope = ISWSFabbricato.class)
    public JAXBElement<String> createISWSFabbricatoCasiParticolari(String value) {
        return new JAXBElement<String>(_ISWSFabbricatoFS6CasiParticolari_QNAME, String.class, ISWSFabbricato.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "Carburante", scope = ISWSMacchina.class)
    public JAXBElement<String> createISWSMacchinaCarburante(String value) {
        return new JAXBElement<String>(_ISWSMacchinaCarburante_QNAME, String.class, ISWSMacchina.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "Trazione", scope = ISWSMacchina.class)
    public JAXBElement<String> createISWSMacchinaTrazione(String value) {
        return new JAXBElement<String>(_ISWSMacchinaTrazione_QNAME, String.class, ISWSMacchina.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "AnnoCampagna", scope = ISWSOTE.class)
    public JAXBElement<XMLGregorianCalendar> createISWSOTEAnnoCampagna(XMLGregorianCalendar value) {
        return new JAXBElement<XMLGregorianCalendar>(_ISWSCHEDEAnnoCampagna_QNAME, XMLGregorianCalendar.class, ISWSOTE.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "TipoIdScheda", scope = ISWSOTE.class)
    public JAXBElement<String> createISWSOTETipoIdScheda(String value) {
        return new JAXBElement<String>(_ISWSOTETipoIdScheda_QNAME, String.class, ISWSOTE.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "IdScheda", scope = ISWSOTE.class)
    public JAXBElement<String> createISWSOTEIdScheda(String value) {
        return new JAXBElement<String>(_ISWSOTEIdScheda_QNAME, String.class, ISWSOTE.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "CuaaDefunto", scope = WSDocuFasc.class)
    public JAXBElement<String> createWSDocuFascCuaaDefunto(String value) {
        return new JAXBElement<String>(_WSDocuFascCuaaDefunto_QNAME, String.class, WSDocuFasc.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "DataEvento", scope = WSDocuFasc.class)
    public JAXBElement<String> createWSDocuFascDataEvento(String value) {
        return new JAXBElement<String>(_WSDocuFascDataEvento_QNAME, String.class, WSDocuFasc.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "CuaaSoggDelegato", scope = WSDocuFasc.class)
    public JAXBElement<String> createWSDocuFascCuaaSoggDelegato(String value) {
        return new JAXBElement<String>(_WSDocuFascCuaaSoggDelegato_QNAME, String.class, WSDocuFasc.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "NumeroEredi", scope = WSDocuFasc.class)
    public JAXBElement<String> createWSDocuFascNumeroEredi(String value) {
        return new JAXBElement<String>(_WSDocuFascNumeroEredi_QNAME, String.class, WSDocuFasc.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "TipoDocuRico", scope = WSDocuFasc.class)
    public JAXBElement<String> createWSDocuFascTipoDocuRico(String value) {
        return new JAXBElement<String>(_WSDocuFascTipoDocuRico_QNAME, String.class, WSDocuFasc.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "NumeroDocuRico", scope = WSDocuFasc.class)
    public JAXBElement<String> createWSDocuFascNumeroDocuRico(String value) {
        return new JAXBElement<String>(_WSDocuFascNumeroDocuRico_QNAME, String.class, WSDocuFasc.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "DataScadDocuRico", scope = WSDocuFasc.class)
    public JAXBElement<String> createWSDocuFascDataScadDocuRico(String value) {
        return new JAXBElement<String>(_WSDocuFascDataScadDocuRico_QNAME, String.class, WSDocuFasc.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "TipoDocumento", scope = ISWSTerritorio16 .class)
    public JAXBElement<String> createISWSTerritorio16TipoDocumento(String value) {
        return new JAXBElement<String>(_ISWSDatiFascicolo15TipoDocumento_QNAME, String.class, ISWSTerritorio16 .class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "CodiZVN", scope = ISWSTerritorio16 .class)
    public JAXBElement<String> createISWSTerritorio16CodiZVN(String value) {
        return new JAXBElement<String>(_ISWSTerritorioFS7CodiZVN_QNAME, String.class, ISWSTerritorio16 .class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "TipoDocumento", scope = ISWSTerritorio15 .class)
    public JAXBElement<String> createISWSTerritorio15TipoDocumento(String value) {
        return new JAXBElement<String>(_ISWSDatiFascicolo15TipoDocumento_QNAME, String.class, ISWSTerritorio15 .class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "CodiZVN", scope = ISWSTerritorio15 .class)
    public JAXBElement<String> createISWSTerritorio15CodiZVN(String value) {
        return new JAXBElement<String>(_ISWSTerritorioFS7CodiZVN_QNAME, String.class, ISWSTerritorio15 .class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "NumeroIscrizione", scope = ISWSCodiceINPS.class)
    public JAXBElement<String> createISWSCodiceINPSNumeroIscrizione(String value) {
        return new JAXBElement<String>(_ISWSCodiceINPSNumeroIscrizione_QNAME, String.class, ISWSCodiceINPS.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://cooperazione.sian.it/schema/fascicolo", name = "DataCessazione", scope = ISWSCodiceINPS.class)
    public JAXBElement<String> createISWSCodiceINPSDataCessazione(String value) {
        return new JAXBElement<String>(_ISWSCodiceINPSDataCessazione_QNAME, String.class, ISWSCodiceINPS.class, value);
    }

}
