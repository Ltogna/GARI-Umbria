
package com.abacogroup.gari.dataimporter.soap.fascicolo;

import java.util.ArrayList;
import java.util.List;
import jakarta.xml.bind.JAXBElement;
import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlElementRef;
import jakarta.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ISWSTerritorioFS7 complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ISWSTerritorioFS7"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://cooperazione.sian.it/schema/fascicolo}ISWSBaseTerritorio1"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="CUAA" type="{http://cooperazione.sian.it/schema/fascicolo}Cuaa"/&gt;
 *         &lt;element name="Comune" type="{http://cooperazione.sian.it/schema/fascicolo}Comune"/&gt;
 *         &lt;element name="Provincia" type="{http://cooperazione.sian.it/schema/fascicolo}Provincia"/&gt;
 *         &lt;element name="UtilizzoSuolo" type="{http://cooperazione.sian.it/schema/fascicolo}WsUtilizzoTerraCaba7" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="Documento" type="{http://cooperazione.sian.it/schema/fascicolo}WsDocumenti" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="FlagIrrigua"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://cooperazione.sian.it/schema/fascicolo}Flag"&gt;
 *               &lt;enumeration value="0"/&gt;
 *               &lt;enumeration value="1"/&gt;
 *               &lt;enumeration value="2"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="FlagTerrazzata"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://cooperazione.sian.it/schema/fascicolo}Flag"&gt;
 *               &lt;enumeration value="0"/&gt;
 *               &lt;enumeration value="1"/&gt;
 *               &lt;enumeration value="2"/&gt;
 *               &lt;enumeration value="3"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="RotazioneColtureOrtive"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://cooperazione.sian.it/schema/fascicolo}Flag"&gt;
 *               &lt;enumeration value="0"/&gt;
 *               &lt;enumeration value="1"/&gt;
 *               &lt;enumeration value="2"/&gt;
 *               &lt;enumeration value="3"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="EffluentiZootecnici"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://cooperazione.sian.it/schema/fascicolo}Flag"&gt;
 *               &lt;enumeration value="0"/&gt;
 *               &lt;enumeration value="1"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="SostanzePericolose"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://cooperazione.sian.it/schema/fascicolo}Flag"&gt;
 *               &lt;enumeration value="0"/&gt;
 *               &lt;enumeration value="1"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="CasiParticolari" type="{http://cooperazione.sian.it/schema/fascicolo}CasiParticolari"/&gt;
 *         &lt;element name="FlagGiust" type="{http://cooperazione.sian.it/schema/fascicolo}Flag"/&gt;
 *         &lt;element name="CodiZVN" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ISWSTerritorioFS7", propOrder = {
    "cuaa",
    "comune",
    "provincia",
    "utilizzoSuolo",
    "documento",
    "flagIrrigua",
    "flagTerrazzata",
    "rotazioneColtureOrtive",
    "effluentiZootecnici",
    "sostanzePericolose",
    "casiParticolari",
    "flagGiust",
    "codiZVN"
})
public class ISWSTerritorioFS7
    extends ISWSBaseTerritorio1
{

    @XmlElement(name = "CUAA", required = true)
    protected String cuaa;
    @XmlElement(name = "Comune", required = true)
    protected String comune;
    @XmlElement(name = "Provincia", required = true)
    protected String provincia;
    @XmlElement(name = "UtilizzoSuolo", nillable = true)
    protected List<WsUtilizzoTerraCaba7> utilizzoSuolo;
    @XmlElement(name = "Documento", nillable = true)
    protected List<WsDocumenti> documento;
    @XmlElement(name = "FlagIrrigua", required = true)
    protected String flagIrrigua;
    @XmlElement(name = "FlagTerrazzata", required = true)
    protected String flagTerrazzata;
    @XmlElement(name = "RotazioneColtureOrtive", required = true)
    protected String rotazioneColtureOrtive;
    @XmlElement(name = "EffluentiZootecnici", required = true, nillable = true)
    protected String effluentiZootecnici;
    @XmlElement(name = "SostanzePericolose", required = true, nillable = true)
    protected String sostanzePericolose;
    @XmlElement(name = "CasiParticolari", required = true, nillable = true)
    protected String casiParticolari;
    @XmlElement(name = "FlagGiust", required = true, nillable = true)
    protected String flagGiust;
    @XmlElementRef(name = "CodiZVN", namespace = "http://cooperazione.sian.it/schema/fascicolo", type = JAXBElement.class, required = false)
    protected JAXBElement<String> codiZVN;

    /**
     * Gets the value of the cuaa property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCUAA() {
        return cuaa;
    }

    /**
     * Sets the value of the cuaa property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCUAA(String value) {
        this.cuaa = value;
    }

    /**
     * Gets the value of the comune property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getComune() {
        return comune;
    }

    /**
     * Sets the value of the comune property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setComune(String value) {
        this.comune = value;
    }

    /**
     * Gets the value of the provincia property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProvincia() {
        return provincia;
    }

    /**
     * Sets the value of the provincia property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProvincia(String value) {
        this.provincia = value;
    }

    /**
     * Gets the value of the utilizzoSuolo property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the Jakarta XML Binding object.
     * This is why there is not a <CODE>set</CODE> method for the utilizzoSuolo property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getUtilizzoSuolo().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link WsUtilizzoTerraCaba7 }
     * 
     * 
     */
    public List<WsUtilizzoTerraCaba7> getUtilizzoSuolo() {
        if (utilizzoSuolo == null) {
            utilizzoSuolo = new ArrayList<WsUtilizzoTerraCaba7>();
        }
        return this.utilizzoSuolo;
    }

    /**
     * Gets the value of the documento property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the Jakarta XML Binding object.
     * This is why there is not a <CODE>set</CODE> method for the documento property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getDocumento().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link WsDocumenti }
     * 
     * 
     */
    public List<WsDocumenti> getDocumento() {
        if (documento == null) {
            documento = new ArrayList<WsDocumenti>();
        }
        return this.documento;
    }

    /**
     * Gets the value of the flagIrrigua property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFlagIrrigua() {
        return flagIrrigua;
    }

    /**
     * Sets the value of the flagIrrigua property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFlagIrrigua(String value) {
        this.flagIrrigua = value;
    }

    /**
     * Gets the value of the flagTerrazzata property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFlagTerrazzata() {
        return flagTerrazzata;
    }

    /**
     * Sets the value of the flagTerrazzata property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFlagTerrazzata(String value) {
        this.flagTerrazzata = value;
    }

    /**
     * Gets the value of the rotazioneColtureOrtive property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRotazioneColtureOrtive() {
        return rotazioneColtureOrtive;
    }

    /**
     * Sets the value of the rotazioneColtureOrtive property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRotazioneColtureOrtive(String value) {
        this.rotazioneColtureOrtive = value;
    }

    /**
     * Gets the value of the effluentiZootecnici property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEffluentiZootecnici() {
        return effluentiZootecnici;
    }

    /**
     * Sets the value of the effluentiZootecnici property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEffluentiZootecnici(String value) {
        this.effluentiZootecnici = value;
    }

    /**
     * Gets the value of the sostanzePericolose property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSostanzePericolose() {
        return sostanzePericolose;
    }

    /**
     * Sets the value of the sostanzePericolose property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSostanzePericolose(String value) {
        this.sostanzePericolose = value;
    }

    /**
     * Gets the value of the casiParticolari property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCasiParticolari() {
        return casiParticolari;
    }

    /**
     * Sets the value of the casiParticolari property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCasiParticolari(String value) {
        this.casiParticolari = value;
    }

    /**
     * Gets the value of the flagGiust property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFlagGiust() {
        return flagGiust;
    }

    /**
     * Sets the value of the flagGiust property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFlagGiust(String value) {
        this.flagGiust = value;
    }

    /**
     * Gets the value of the codiZVN property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getCodiZVN() {
        return codiZVN;
    }

    /**
     * Sets the value of the codiZVN property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setCodiZVN(JAXBElement<String> value) {
        this.codiZVN = value;
    }

}
