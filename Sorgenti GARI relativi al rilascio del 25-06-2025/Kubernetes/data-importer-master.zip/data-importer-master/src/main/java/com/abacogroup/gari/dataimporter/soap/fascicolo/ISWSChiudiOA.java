
package com.abacogroup.gari.dataimporter.soap.fascicolo;

import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlRootElement;
import jakarta.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="CuaaOA" type="{http://cooperazione.sian.it/schema/fascicolo}Cuaa"/&gt;
 *         &lt;sequence&gt;
 *           &lt;element ref="{http://cooperazione.sian.it/schema/fascicolo}ISWSInfoRTI"/&gt;
 *         &lt;/sequence&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "cuaaOA",
    "iswsInfoRTI"
})
@XmlRootElement(name = "ISWSChiudiOA")
public class ISWSChiudiOA {

    @XmlElement(name = "CuaaOA", required = true)
    protected String cuaaOA;
    @XmlElement(name = "ISWSInfoRTI", required = true)
    protected ISWSInfoRTI iswsInfoRTI;

    /**
     * Gets the value of the cuaaOA property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCuaaOA() {
        return cuaaOA;
    }

    /**
     * Sets the value of the cuaaOA property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCuaaOA(String value) {
        this.cuaaOA = value;
    }

    /**
     * Gets the value of the iswsInfoRTI property.
     * 
     * @return
     *     possible object is
     *     {@link ISWSInfoRTI }
     *     
     */
    public ISWSInfoRTI getISWSInfoRTI() {
        return iswsInfoRTI;
    }

    /**
     * Sets the value of the iswsInfoRTI property.
     * 
     * @param value
     *     allowed object is
     *     {@link ISWSInfoRTI }
     *     
     */
    public void setISWSInfoRTI(ISWSInfoRTI value) {
        this.iswsInfoRTI = value;
    }

}
