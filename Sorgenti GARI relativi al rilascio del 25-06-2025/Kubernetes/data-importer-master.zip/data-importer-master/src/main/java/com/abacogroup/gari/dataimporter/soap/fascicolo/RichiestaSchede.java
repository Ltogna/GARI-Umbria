
package com.abacogroup.gari.dataimporter.soap.fascicolo;

import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlRootElement;
import jakarta.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="ISWSCHEDE" type="{http://cooperazione.sian.it/schema/fascicolo}ISWSCHEDE"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "iswschede"
})
@XmlRootElement(name = "RichiestaSchede")
public class RichiestaSchede {

    @XmlElement(name = "ISWSCHEDE", required = true)
    protected ISWSCHEDE iswschede;

    /**
     * Gets the value of the iswschede property.
     * 
     * @return
     *     possible object is
     *     {@link ISWSCHEDE }
     *     
     */
    public ISWSCHEDE getISWSCHEDE() {
        return iswschede;
    }

    /**
     * Sets the value of the iswschede property.
     * 
     * @param value
     *     allowed object is
     *     {@link ISWSCHEDE }
     *     
     */
    public void setISWSCHEDE(ISWSCHEDE value) {
        this.iswschede = value;
    }

}
