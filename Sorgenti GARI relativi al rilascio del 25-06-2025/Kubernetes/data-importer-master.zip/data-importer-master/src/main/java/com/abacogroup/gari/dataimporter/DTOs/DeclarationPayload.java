package com.abacogroup.gari.dataimporter.DTOs;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
public class DeclarationPayload {

	@JsonProperty("landuseCode")
	private String landuseCode;

	@JsonProperty("declCode")
	private String declCode;

	@JsonProperty("areaPerc")
	private double areaPerc;

	@JsonProperty("fromDate")
	private String fromDate;

	@JsonProperty("fromDatePrecision")
	private String fromDatePrecision;

	@JsonProperty("toDate")
	private String toDate;

	@JsonProperty("fieldsCodes")
	private List<FieldCode> fieldsCodes;

	@JsonProperty("removeExistingDeclarations")
	private boolean removeExistingDeclarations;

	public String getLanduseCode() {
		return landuseCode;
	}

	public void setLanduseCode(String landuseCode) {
		this.landuseCode = landuseCode;
	}
	public String getDeclCode() {
		return declCode;
	}

	public void setDeclCode(String declCode) {
		this.declCode = declCode;
	}

	public double getAreaPerc() {
		return areaPerc;
	}

	public void setAreaPerc(double areaPerc) {
		this.areaPerc = areaPerc;
	}

	public String getFromDate() {
		return fromDate;
	}

	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;
	}

	public String getFromDatePrecision() {
		return fromDatePrecision;
	}

	public void setFromDatePrecision(String fromDatePrecision) {
		this.fromDatePrecision = fromDatePrecision;
	}

	public String getToDate() {
		return toDate;
	}

	public void setToDate(String toDate) {
		this.toDate = toDate;
	}

	public List<FieldCode> getFieldsCodes() {
		return fieldsCodes;
	}

	public void setFieldsCodes(List<FieldCode> fieldsCodes) {
		this.fieldsCodes = fieldsCodes;
	}

	public boolean isRemoveExistingDeclarations() {
		return removeExistingDeclarations;
	}

	public void setRemoveExistingDeclarations(boolean removeExistingDeclarations) {
		this.removeExistingDeclarations = removeExistingDeclarations;
	}

	@JsonIgnoreProperties(ignoreUnknown = true)
	public static class FieldCode {

		@JsonProperty("fieldCode")
		private String fieldCode;

//		@JsonProperty("fieldDescription")
//		private String fieldDescription;

		@JsonProperty("dayFrom")
		private String dayFrom;

		@JsonProperty("dayTo")
		private String dayTo;

//		@JsonProperty("sortOrder")
//		private int sortOrder;

		@JsonProperty("value")
		private String value;

//		@JsonProperty("valueDescription")
//		private String valueDescription;

		@JsonProperty("flShowInTooltip")
		private boolean flShowInTooltip;

		public void setFieldCode(String fieldCode) {
			this.fieldCode = fieldCode;
		}

//		public void setFieldDescription(String fieldDescription) {
//			this.fieldDescription = fieldDescription;
//		}

		public void setDayFrom(String dayFrom) {
			this.dayFrom = dayFrom;
		}

		public void setDayTo(String dayTo) {
			this.dayTo = dayTo;
		}

//		public void setSortOrder(int sortOrder) {
//			this.sortOrder = sortOrder;
//		}

		public void setValue(String value) {
			this.value = value;
		}

//		public void setValueDescription(String valueDescription) {
//			this.valueDescription = valueDescription;
//		}

		public void setFlShowInTooltip(boolean flShowInTooltip) {
			this.flShowInTooltip = flShowInTooltip;
		}

		// Getters and setters...
	}
}
