
package com.abacogroup.gari.dataimporter.soap.fascicolo;

import java.util.ArrayList;
import java.util.List;
import jakarta.xml.bind.JAXBElement;
import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlElementRef;
import jakarta.xml.bind.annotation.XmlSeeAlso;
import jakarta.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ISWSBaseTerritorio1 complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ISWSBaseTerritorio1"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Sezione" type="{http://cooperazione.sian.it/schema/fascicolo}Sezione"/&gt;
 *         &lt;element name="Foglio" type="{http://cooperazione.sian.it/schema/fascicolo}Foglio"/&gt;
 *         &lt;element name="Particella" type="{http://cooperazione.sian.it/schema/fascicolo}Particella"/&gt;
 *         &lt;element name="Subalterno" type="{http://cooperazione.sian.it/schema/fascicolo}Subalterno"/&gt;
 *         &lt;element name="codiceTipoConduzione" type="{http://cooperazione.sian.it/schema/fascicolo}TipoConduzione" minOccurs="0"/&gt;
 *         &lt;element name="DataInizioConduzione" type="{http://cooperazione.sian.it/schema/fascicolo}Data"/&gt;
 *         &lt;element name="DataFineConduzione" type="{http://cooperazione.sian.it/schema/fascicolo}Data"/&gt;
 *         &lt;element name="Proprietari" type="{http://cooperazione.sian.it/schema/fascicolo}ISWSProprietario" maxOccurs="5" minOccurs="0"/&gt;
 *         &lt;element name="SuperficieCatastale" type="{http://cooperazione.sian.it/schema/fascicolo}Superficie"/&gt;
 *         &lt;element name="SuperficieCondotta" type="{http://cooperazione.sian.it/schema/fascicolo}Superficie"/&gt;
 *         &lt;element name="SuperficieGrafica" type="{http://cooperazione.sian.it/schema/fascicolo}Superficie" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ISWSBaseTerritorio1", propOrder = {
    "sezione",
    "foglio",
    "particella",
    "subalterno",
    "codiceTipoConduzione",
    "dataInizioConduzione",
    "dataFineConduzione",
    "proprietari",
    "superficieCatastale",
    "superficieCondotta",
    "superficieGrafica"
})
@XmlSeeAlso({
    ISWSTerritorio15 .class,
    ISWSTerritorio16 .class,
    ISWSTerritorioFS6 .class,
    ISWSTerritorioFS7 .class
})
public class ISWSBaseTerritorio1 {

    @XmlElement(name = "Sezione", required = true, nillable = true)
    protected String sezione;
    @XmlElement(name = "Foglio", required = true)
    protected String foglio;
    @XmlElement(name = "Particella", required = true)
    protected String particella;
    @XmlElement(name = "Subalterno", required = true, nillable = true)
    protected String subalterno;
    protected String codiceTipoConduzione;
    @XmlElement(name = "DataInizioConduzione", required = true)
    protected String dataInizioConduzione;
    @XmlElement(name = "DataFineConduzione", required = true, nillable = true)
    protected String dataFineConduzione;
    @XmlElement(name = "Proprietari", nillable = true)
    protected List<ISWSProprietario> proprietari;
    @XmlElement(name = "SuperficieCatastale", required = true)
    protected String superficieCatastale;
    @XmlElement(name = "SuperficieCondotta", required = true)
    protected String superficieCondotta;
    @XmlElementRef(name = "SuperficieGrafica", namespace = "http://cooperazione.sian.it/schema/fascicolo", type = JAXBElement.class, required = false)
    protected JAXBElement<String> superficieGrafica;

    /**
     * Gets the value of the sezione property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSezione() {
        return sezione;
    }

    /**
     * Sets the value of the sezione property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSezione(String value) {
        this.sezione = value;
    }

    /**
     * Gets the value of the foglio property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFoglio() {
        return foglio;
    }

    /**
     * Sets the value of the foglio property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFoglio(String value) {
        this.foglio = value;
    }

    /**
     * Gets the value of the particella property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getParticella() {
        return particella;
    }

    /**
     * Sets the value of the particella property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setParticella(String value) {
        this.particella = value;
    }

    /**
     * Gets the value of the subalterno property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSubalterno() {
        return subalterno;
    }

    /**
     * Sets the value of the subalterno property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSubalterno(String value) {
        this.subalterno = value;
    }

    /**
     * Gets the value of the codiceTipoConduzione property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodiceTipoConduzione() {
        return codiceTipoConduzione;
    }

    /**
     * Sets the value of the codiceTipoConduzione property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodiceTipoConduzione(String value) {
        this.codiceTipoConduzione = value;
    }

    /**
     * Gets the value of the dataInizioConduzione property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDataInizioConduzione() {
        return dataInizioConduzione;
    }

    /**
     * Sets the value of the dataInizioConduzione property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDataInizioConduzione(String value) {
        this.dataInizioConduzione = value;
    }

    /**
     * Gets the value of the dataFineConduzione property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDataFineConduzione() {
        return dataFineConduzione;
    }

    /**
     * Sets the value of the dataFineConduzione property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDataFineConduzione(String value) {
        this.dataFineConduzione = value;
    }

    /**
     * Gets the value of the proprietari property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the Jakarta XML Binding object.
     * This is why there is not a <CODE>set</CODE> method for the proprietari property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getProprietari().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ISWSProprietario }
     * 
     * 
     */
    public List<ISWSProprietario> getProprietari() {
        if (proprietari == null) {
            proprietari = new ArrayList<ISWSProprietario>();
        }
        return this.proprietari;
    }

    /**
     * Gets the value of the superficieCatastale property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSuperficieCatastale() {
        return superficieCatastale;
    }

    /**
     * Sets the value of the superficieCatastale property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSuperficieCatastale(String value) {
        this.superficieCatastale = value;
    }

    /**
     * Gets the value of the superficieCondotta property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSuperficieCondotta() {
        return superficieCondotta;
    }

    /**
     * Sets the value of the superficieCondotta property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSuperficieCondotta(String value) {
        this.superficieCondotta = value;
    }

    /**
     * Gets the value of the superficieGrafica property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getSuperficieGrafica() {
        return superficieGrafica;
    }

    /**
     * Sets the value of the superficieGrafica property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setSuperficieGrafica(JAXBElement<String> value) {
        this.superficieGrafica = value;
    }

}
