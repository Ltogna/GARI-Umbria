package com.abacogroup.gari.dataimporter.db.ntt;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.NonNull;

import java.time.OffsetDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class NotificationsNTT {

	@NonNull
	private String uid; // ULID

	@NonNull
	private String familyType;

	@NonNull
	private String flVersion;

	private long partyId; // Foreign key to dataimporter_notifications_dates

	private OffsetDateTime dtSent; // Sent date

	private OffsetDateTime dtResponse; // Response date

	private String responsePayload; // Response payload
}
