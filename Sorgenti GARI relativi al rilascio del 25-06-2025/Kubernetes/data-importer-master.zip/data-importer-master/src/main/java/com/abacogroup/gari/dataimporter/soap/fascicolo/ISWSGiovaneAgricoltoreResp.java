
package com.abacogroup.gari.dataimporter.soap.fascicolo;

import java.util.ArrayList;
import java.util.List;
import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ISWSGiovaneAgricoltoreResp complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ISWSGiovaneAgricoltoreResp"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="GiovaneAgricoltore"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;enumeration value="SI"/&gt;
 *               &lt;enumeration value="NO"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="Indicatori" type="{http://cooperazione.sian.it/schema/fascicolo}ISWSIndicatori" maxOccurs="unbounded" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ISWSGiovaneAgricoltoreResp", propOrder = {
    "giovaneAgricoltore",
    "indicatori"
})
public class ISWSGiovaneAgricoltoreResp {

    @XmlElement(name = "GiovaneAgricoltore", required = true)
    protected String giovaneAgricoltore;
    @XmlElement(name = "Indicatori", nillable = true)
    protected List<ISWSIndicatori> indicatori;

    /**
     * Gets the value of the giovaneAgricoltore property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGiovaneAgricoltore() {
        return giovaneAgricoltore;
    }

    /**
     * Sets the value of the giovaneAgricoltore property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGiovaneAgricoltore(String value) {
        this.giovaneAgricoltore = value;
    }

    /**
     * Gets the value of the indicatori property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the Jakarta XML Binding object.
     * This is why there is not a <CODE>set</CODE> method for the indicatori property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getIndicatori().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ISWSIndicatori }
     * 
     * 
     */
    public List<ISWSIndicatori> getIndicatori() {
        if (indicatori == null) {
            indicatori = new ArrayList<ISWSIndicatori>();
        }
        return this.indicatori;
    }

}
