
package com.abacogroup.gari.dataimporter.soap.fascicolo;

import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ISWSDatiSocio complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ISWSDatiSocio"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="CuaaOrgAssociativo" type="{http://cooperazione.sian.it/schema/fascicolo}Cuaa"/&gt;
 *         &lt;sequence minOccurs="0"&gt;
 *           &lt;element ref="{http://cooperazione.sian.it/schema/fascicolo}ISWSInfoRTI"/&gt;
 *         &lt;/sequence&gt;
 *         &lt;element name="TipoLegameAsso"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="DataInizioAsso" type="{http://cooperazione.sian.it/schema/fascicolo}Data"/&gt;
 *         &lt;element name="DataFineAsso" type="{http://cooperazione.sian.it/schema/fascicolo}Data"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ISWSDatiSocio", propOrder = {
    "cuaaOrgAssociativo",
    "iswsInfoRTI",
    "tipoLegameAsso",
    "dataInizioAsso",
    "dataFineAsso"
})
public class ISWSDatiSocio {

    @XmlElement(name = "CuaaOrgAssociativo", required = true)
    protected String cuaaOrgAssociativo;
    @XmlElement(name = "ISWSInfoRTI")
    protected ISWSInfoRTI iswsInfoRTI;
    @XmlElement(name = "TipoLegameAsso", required = true)
    protected String tipoLegameAsso;
    @XmlElement(name = "DataInizioAsso", required = true)
    protected String dataInizioAsso;
    @XmlElement(name = "DataFineAsso", required = true, nillable = true)
    protected String dataFineAsso;

    /**
     * Gets the value of the cuaaOrgAssociativo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCuaaOrgAssociativo() {
        return cuaaOrgAssociativo;
    }

    /**
     * Sets the value of the cuaaOrgAssociativo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCuaaOrgAssociativo(String value) {
        this.cuaaOrgAssociativo = value;
    }

    /**
     * Gets the value of the iswsInfoRTI property.
     * 
     * @return
     *     possible object is
     *     {@link ISWSInfoRTI }
     *     
     */
    public ISWSInfoRTI getISWSInfoRTI() {
        return iswsInfoRTI;
    }

    /**
     * Sets the value of the iswsInfoRTI property.
     * 
     * @param value
     *     allowed object is
     *     {@link ISWSInfoRTI }
     *     
     */
    public void setISWSInfoRTI(ISWSInfoRTI value) {
        this.iswsInfoRTI = value;
    }

    /**
     * Gets the value of the tipoLegameAsso property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTipoLegameAsso() {
        return tipoLegameAsso;
    }

    /**
     * Sets the value of the tipoLegameAsso property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTipoLegameAsso(String value) {
        this.tipoLegameAsso = value;
    }

    /**
     * Gets the value of the dataInizioAsso property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDataInizioAsso() {
        return dataInizioAsso;
    }

    /**
     * Sets the value of the dataInizioAsso property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDataInizioAsso(String value) {
        this.dataInizioAsso = value;
    }

    /**
     * Gets the value of the dataFineAsso property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDataFineAsso() {
        return dataFineAsso;
    }

    /**
     * Sets the value of the dataFineAsso property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDataFineAsso(String value) {
        this.dataFineAsso = value;
    }

}
