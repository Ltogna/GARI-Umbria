package com.abacogroup.gari.dataimporter.DTOs;

public class FieldDefinition {
	private String code;
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
}
