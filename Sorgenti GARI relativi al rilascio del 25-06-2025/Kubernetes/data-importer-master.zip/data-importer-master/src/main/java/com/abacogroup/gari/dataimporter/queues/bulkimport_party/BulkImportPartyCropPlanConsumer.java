package com.abacogroup.gari.dataimporter.queues.bulkimport_party;

import com.abacogroup.embeddedqueue.QueueErrorListener;
import com.abacogroup.embeddedqueue.ThrowingConsumer;
import com.abacogroup.gari.dataimporter.services.BulkImportPartyLoadService;
import com.abacogroup.gari.dataimporter.services.BulkImportPartyService;

public class BulkImportPartyCropPlanConsumer implements ThrowingConsumer<String>, QueueErrorListener<String> {

	private final BulkImportPartyService service;
	private final BulkImportPartyLoadService loadService;
	private final int step;

	public BulkImportPartyCropPlanConsumer(BulkImportPartyService service, BulkImportPartyLoadService loadService, int step) {
		this.service = service;
		this.loadService = loadService;
		this.step = step;
	}

	@Override
	public void accept(String job) throws Exception {
		service.importPartyCropPlan(job);
		loadService.updateStatusAndStep(job, BulkImportPartyLoadService.STATUS_DONE, step);
		loadService.completeImport(job);
	}

	@Override
	public QueueErrorListener.ErrorAction onJobError(String id, Throwable t) {
		loadService.updateStatusAndStep(id, BulkImportPartyLoadService.STATUS_ERROR, step - 1);
		return QueueErrorListener.ErrorAction.MARK_AS_ERRORED;
	}
}
