package com.abacogroup.gari.dataimporter.DTOs;

import java.time.LocalDate;

import com.abacogroup.jdbi.datatype.AbsoluteDate;

import lombok.Builder;
import lombok.Data;
import lombok.Builder.Default;

@Data
@Builder
public class CreatePartyAclEntity {
    private String code;
    private String parent_code;
    private String name;
    private String description;
    private String entity_type_code;
    private String registry_party_id;

    @Default
    private AbsoluteDate day_from = AbsoluteDate.of(LocalDate.now());

    @Default
    private AbsoluteDate day_to = AbsoluteDate.of("99991231");
}
