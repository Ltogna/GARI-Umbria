package com.abacogroup.gari.dataimporter.DTOs;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.Builder.Default;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
// NOTE: we do not want delta only fields to be returned in non delta responses
@JsonInclude(JsonInclude.Include.NON_NULL)
public class PCGCropPlanResponse {

    // the following fields are only used for the delta APIs response

    @JsonProperty("campagna")
    private Integer campagna;

    @JsonProperty("is_certified")
    private Boolean certified;

    @JsonProperty("tipo_modifica")
    private String tipoModifica;

    // from here we have common fields

    @JsonProperty("id_appezzamento")
    private String idAppezzamento; // plotId

    @JsonProperty("denominazione")
    private String denominazione; // description

    @JsonProperty("cod_nazionale")
    private String codNazionale; // domainZoneId

    @JsonProperty("area_mq")
    private double areaMq; // areaSqm

    @JsonProperty("data_inizio_validita")
    private LocalDate dataInizioValidita; // fromDate

    @JsonProperty("data_fine_validita")
    private LocalDate dataFineValidita; // toDate

    @JsonProperty("id_appezzamento_padre")
    private String idAppezzamentoPadre; // plotId

    @JsonProperty("gis")
    private GIS gis;

    @JsonProperty("dichiarazioni")
    private List<Declaration> dichiarazioni; // decls

    @JsonProperty("ultimo_aggiornamento")
    private LocalDateTime ultimoAggiornamento; // versionDate

    @JsonProperty("chiave")
    private Chiave chiave;

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class GIS {
        @JsonProperty("sr_code")
        private String srCode; // srs

        @JsonProperty("wkt")
        private String wkt; // geom
    }

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class Declaration {
        @JsonProperty("id_dichiarazione")
        private String idDichiarazione; // declCode

        @JsonProperty("codice_coltura")
        private String codiceColtura; // code

        @JsonProperty("coltura")
        private String coltura; // description

        @JsonProperty("area_mq")
        private int areaMq; // areaSqm calculation based on percentage

        @JsonProperty("data_inizio_validita")
        private LocalDate dataInizioValidita; // fromDate

        @JsonProperty("data_fine_validita")
        private LocalDate dataFineValidita; // toDate

        @JsonProperty("data_impianto")
        @Default
        private LocalDate dataImpianto = LocalDate.of(1900, 1, 1);

        @JsonProperty("bbch")
        private List<Object> bbch; // null

        @JsonProperty("protocolli")
        private List<Map<String, String>> protocolli; // null

        @JsonProperty("chiave")
        private ChiaveDichiarazioni chiave;

        @JsonProperty("datiAggiuntiviPCG")
        private DatiAggiuntiviPCG datiAggiuntiviPCG;

        @JsonProperty("data_impianto")
        public LocalDate getDataImpianto() {
            return dataImpianto == null ? LocalDate.of(1900, 1, 1) : dataImpianto;
        }
    }

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class Chiave {
        @JsonProperty("idSchedaValidazione")
        private String idSchedaValidazione;

        @JsonProperty("identificativoPianoColtivazione")
        private String identificativoPianoColtivazione;

        @JsonProperty("codiBarrSchedaValidazione")
        private String codiBarrSchedaValidazione; // always null

        @JsonProperty("identificativoIsola")
        private String identificativoIsola;

        @JsonProperty("identificativoAppezzamento")
        private String identificativoAppezzamento;

        @JsonProperty("idAppezzamentoOrig")
        private String idAppezzamentoOrig; // always null
    }

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class ChiaveDichiarazioni {
        @JsonProperty("idColt")
        private String idColt;
    }

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class DatiAggiuntiviPCG {
        @JsonProperty("zootechnical_effluents_id")
        private String zootechnicalEffluentsId;

        @JsonProperty("zootechnical_effluents")
        private GenericType zootechnicalEffluents;

        @JsonProperty("irrigation_potential_id")
        private String irrigationPotentialId;

        @JsonProperty("irrigation_potential")
        private GenericType irrigationPotential;

        @JsonProperty("company_structures_id")
        private String companyStructuresId;

        @JsonProperty("company_structures")
        private GenericType companyStructures;

        @JsonProperty("sowing_type_id")
        private String sowingTypeId;

        @JsonProperty("sowing_type")
        private GenericType sowingType;

        @JsonProperty("breeding_phase_id")
        private String breedingPhaseId;

        @JsonProperty("breeding_phase")
        private GenericType breedingPhase;

        @JsonProperty("breeding_form_id")
        private String breedingFormId;

        @JsonProperty("breeding_form")
        private GenericType breedingForm;

        @JsonProperty("breeding_type_id")
        private String breedingTypeId;

        @JsonProperty("breeding_type")
        private GenericType breedingType;

        @JsonProperty("irrigation_type_id")
        private String irrigationTypeId;

        @JsonProperty("irrigation_type")
        private GenericType irrigationType;

        @JsonProperty("year_month")
        private String yearMonth; // value of field: annoMese
    }

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class GenericType {
        @JsonProperty("type")
        private String type;

        @JsonProperty("id")
        private String id;

        @JsonProperty("code")
        private String code;

        @JsonProperty("key")
        private String key;

        @JsonProperty("name")
        private String name;

        @JsonProperty("created_at")
        private LocalDate createdAt;

        @JsonProperty("updated_at")
        private LocalDate updatedAt;

        @JsonProperty("deleted_at")
        private LocalDate deletedAt;
    }
}
