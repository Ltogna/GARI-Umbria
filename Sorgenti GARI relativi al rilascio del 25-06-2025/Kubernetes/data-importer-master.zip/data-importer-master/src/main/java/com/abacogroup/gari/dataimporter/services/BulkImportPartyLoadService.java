package com.abacogroup.gari.dataimporter.services;

import java.time.OffsetDateTime;

import com.abacogroup.gari.dataimporter.db.dao.PartyBulkLoadDAO;
import com.abacogroup.gari.dataimporter.db.ntt.PartyBulkLoadNTT;
import com.abacogroup.gari.dataimporter.utils.ULIDGenerator;

public class BulkImportPartyLoadService {
	public static final String STATUS_TODO = "TODO";
	public static final String STATUS_PENDING = "PENDING";
	public static final String STATUS_ERROR = "ERROR";
	public static final String STATUS_DONE = "DONE";

	private final PartyBulkLoadDAO partyBulkLoadDAO;

	public BulkImportPartyLoadService(PartyBulkLoadDAO partyBulkLoadDAO) {
		this.partyBulkLoadDAO = partyBulkLoadDAO;
	}

	public String createPartyBulkLoad(String cuaa, String tenant, Integer campagna) {
		try {
			PartyBulkLoadNTT bulkLoad = PartyBulkLoadNTT.builder()
					.id(ULIDGenerator.generateULID())
					.campagna(campagna)
					.cuaa(cuaa)
					.dtStart(OffsetDateTime.now())
					.importStatus(STATUS_TODO)
					.tenant(tenant)
					.build();
			partyBulkLoadDAO.useTransaction(dao -> {
				partyBulkLoadDAO.insert(bulkLoad);
			});

			return bulkLoad.getId();
		} catch (Exception e) {
			throw new RuntimeException("Error creating PartyBulkLoad record for cuaa " + cuaa, e);
		}
	}

	public PartyBulkLoadNTT findById(String id) {
		try {
			return partyBulkLoadDAO.findById(id);
		} catch (Exception e) {
			throw new RuntimeException("Error finding PartyBulkLoad by ID", e);
		}
	}

	public int updateStatusAndStep(String id, String newStatus, int lastOkStep) {
		try {
			return partyBulkLoadDAO.updateStatusAndStep(id, newStatus, lastOkStep);
		} catch (Exception e) {
			throw new RuntimeException("Error updating PartyBulkLoad status", e);
		}
	}

	public int completeImport(String id) {
		try {
			return partyBulkLoadDAO.completeImport(id, OffsetDateTime.now());
		} catch (Exception e) {
			throw new RuntimeException("Error updating PartyBulkLoad status", e);
		}
	}

	public int updatePartyById(String id, Long partyId) {
		try {
			return partyBulkLoadDAO.updatePartyById(id, partyId);
		} catch (Exception e) {
			throw new RuntimeException("Error querying PartyBulkLoad by CUAA and status", e);
		}
	}
}
