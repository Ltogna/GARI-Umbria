package com.abacogroup.gari.dataimporter.DTOs;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class AnagraficaCommitPayload {
	public String tenant;
	public Long partyId;
}
