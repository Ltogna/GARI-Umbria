package com.abacogroup.gari.dataimporter.DTOs;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.NoArgsConstructor;

@JsonIgnoreProperties(ignoreUnknown = true)
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class DossierRequest {

		@JsonProperty("partyId")
		private Long partyId;

		@JsonProperty("year")
		private Integer year;

		@JsonProperty("sectorCode")
		private String sectorCode;

		@JsonProperty("moduleCode")
		private String moduleCode;

		@JsonProperty("amendmentDossierId")
		private Integer amendmentDossierId;
}
