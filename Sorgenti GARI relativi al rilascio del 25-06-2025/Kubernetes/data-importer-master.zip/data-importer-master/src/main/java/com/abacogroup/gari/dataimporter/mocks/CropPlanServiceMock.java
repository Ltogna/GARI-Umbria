package com.abacogroup.gari.dataimporter.mocks;

import java.io.File;
import java.io.IOException;

import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.gari.dataimporter.DTOs.FeaturesResponse;
import com.fasterxml.jackson.databind.ObjectMapper;

public class CropPlanServiceMock {

	private static final String MOCK_DATA_PATH = "src/test/resources/CCNFDN75D13A345J_2024.json";
	private final ObjectMapper mapper = new ObjectMapper();

	public FeaturesResponse getCropPlanData(User user, String tenantId, String bussinesId, Integer campagna) {
		try {
			return mapper.readValue(new File(MOCK_DATA_PATH), FeaturesResponse.class);
		} catch (IOException e) {
			throw new RuntimeException("Error reading mock data from feature.json", e);
		}
	}
}
