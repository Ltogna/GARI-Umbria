
package com.abacogroup.gari.dataimporter.soap.fascicolo;

import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ISWSCapoAllevamento16 complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ISWSCapoAllevamento16"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="IdAlleBdn"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}int"&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="NumeCapiLatte"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}int"&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="DecoRazzaPrev"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}int"&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="NumeCapi624"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}int"&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="NumeCapiOltre24"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}int"&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="NumeVaccheLatte"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}int"&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="NumeBufa"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}int"&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="DataIniz" type="{http://cooperazione.sian.it/schema/fascicolo}Data"/&gt;
 *         &lt;element name="DataFine" type="{http://cooperazione.sian.it/schema/fascicolo}Data"/&gt;
 *         &lt;element name="NumeCapiTota"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}int"&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="NumeViteFino6"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}int"&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="Nume624Mace"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}int"&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="Nume624MaceFemm"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}int"&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="Nume624Alle"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}int"&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="Nume624AlleFemm"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}int"&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="NumeOltre24Mace"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}int"&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="NumeOltre24MaceFemm"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}int"&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="NumeOltre24Alle"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}int"&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="NumeOltre24AlleFemm"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}int"&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="NumeFino6"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}int"&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="NumeOltre6"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}int"&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="NumeOltre12"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}int"&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="NumeOltre12Femm"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}int"&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="NumeCapiRimonta"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}int"&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="NumeCapiRimontaFemm"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}int"&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="NumeCapiRimontaUBA"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}int"&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="NumeTori"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}int"&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="NumeAltreVacche"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}int"&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="NumeAltreVaccheDich"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}int"&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="Suini"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}int"&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="Lattonzoli"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}int"&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="Magroni"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}int"&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="Scrofe"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}int"&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="Verre"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}int"&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="Scrofette"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}int"&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="Magroncelli"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}int"&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ISWSCapoAllevamento16", propOrder = {
    "idAlleBdn",
    "numeCapiLatte",
    "decoRazzaPrev",
    "numeCapi624",
    "numeCapiOltre24",
    "numeVaccheLatte",
    "numeBufa",
    "dataIniz",
    "dataFine",
    "numeCapiTota",
    "numeViteFino6",
    "nume624Mace",
    "nume624MaceFemm",
    "nume624Alle",
    "nume624AlleFemm",
    "numeOltre24Mace",
    "numeOltre24MaceFemm",
    "numeOltre24Alle",
    "numeOltre24AlleFemm",
    "numeFino6",
    "numeOltre6",
    "numeOltre12",
    "numeOltre12Femm",
    "numeCapiRimonta",
    "numeCapiRimontaFemm",
    "numeCapiRimontaUBA",
    "numeTori",
    "numeAltreVacche",
    "numeAltreVaccheDich",
    "suini",
    "lattonzoli",
    "magroni",
    "scrofe",
    "verre",
    "scrofette",
    "magroncelli"
})
public class ISWSCapoAllevamento16 {

    @XmlElement(name = "IdAlleBdn", required = true, type = Integer.class, nillable = true)
    protected Integer idAlleBdn;
    @XmlElement(name = "NumeCapiLatte", required = true, type = Integer.class, nillable = true)
    protected Integer numeCapiLatte;
    @XmlElement(name = "DecoRazzaPrev", required = true, type = Integer.class, nillable = true)
    protected Integer decoRazzaPrev;
    @XmlElement(name = "NumeCapi624", required = true, type = Integer.class, nillable = true)
    protected Integer numeCapi624;
    @XmlElement(name = "NumeCapiOltre24", required = true, type = Integer.class, nillable = true)
    protected Integer numeCapiOltre24;
    @XmlElement(name = "NumeVaccheLatte", required = true, type = Integer.class, nillable = true)
    protected Integer numeVaccheLatte;
    @XmlElement(name = "NumeBufa", required = true, type = Integer.class, nillable = true)
    protected Integer numeBufa;
    @XmlElement(name = "DataIniz", required = true)
    protected String dataIniz;
    @XmlElement(name = "DataFine", required = true)
    protected String dataFine;
    @XmlElement(name = "NumeCapiTota", required = true, type = Integer.class, nillable = true)
    protected Integer numeCapiTota;
    @XmlElement(name = "NumeViteFino6", required = true, type = Integer.class, nillable = true)
    protected Integer numeViteFino6;
    @XmlElement(name = "Nume624Mace", required = true, type = Integer.class, nillable = true)
    protected Integer nume624Mace;
    @XmlElement(name = "Nume624MaceFemm", required = true, type = Integer.class, nillable = true)
    protected Integer nume624MaceFemm;
    @XmlElement(name = "Nume624Alle", required = true, type = Integer.class, nillable = true)
    protected Integer nume624Alle;
    @XmlElement(name = "Nume624AlleFemm", required = true, type = Integer.class, nillable = true)
    protected Integer nume624AlleFemm;
    @XmlElement(name = "NumeOltre24Mace", required = true, type = Integer.class, nillable = true)
    protected Integer numeOltre24Mace;
    @XmlElement(name = "NumeOltre24MaceFemm", required = true, type = Integer.class, nillable = true)
    protected Integer numeOltre24MaceFemm;
    @XmlElement(name = "NumeOltre24Alle", required = true, type = Integer.class, nillable = true)
    protected Integer numeOltre24Alle;
    @XmlElement(name = "NumeOltre24AlleFemm", required = true, type = Integer.class, nillable = true)
    protected Integer numeOltre24AlleFemm;
    @XmlElement(name = "NumeFino6", required = true, type = Integer.class, nillable = true)
    protected Integer numeFino6;
    @XmlElement(name = "NumeOltre6", required = true, type = Integer.class, nillable = true)
    protected Integer numeOltre6;
    @XmlElement(name = "NumeOltre12", required = true, type = Integer.class, nillable = true)
    protected Integer numeOltre12;
    @XmlElement(name = "NumeOltre12Femm", required = true, type = Integer.class, nillable = true)
    protected Integer numeOltre12Femm;
    @XmlElement(name = "NumeCapiRimonta", required = true, type = Integer.class, nillable = true)
    protected Integer numeCapiRimonta;
    @XmlElement(name = "NumeCapiRimontaFemm", required = true, type = Integer.class, nillable = true)
    protected Integer numeCapiRimontaFemm;
    @XmlElement(name = "NumeCapiRimontaUBA", required = true, type = Integer.class, nillable = true)
    protected Integer numeCapiRimontaUBA;
    @XmlElement(name = "NumeTori", required = true, type = Integer.class, nillable = true)
    protected Integer numeTori;
    @XmlElement(name = "NumeAltreVacche", required = true, type = Integer.class, nillable = true)
    protected Integer numeAltreVacche;
    @XmlElement(name = "NumeAltreVaccheDich", required = true, type = Integer.class, nillable = true)
    protected Integer numeAltreVaccheDich;
    @XmlElement(name = "Suini", required = true, type = Integer.class, nillable = true)
    protected Integer suini;
    @XmlElement(name = "Lattonzoli", required = true, type = Integer.class, nillable = true)
    protected Integer lattonzoli;
    @XmlElement(name = "Magroni", required = true, type = Integer.class, nillable = true)
    protected Integer magroni;
    @XmlElement(name = "Scrofe", required = true, type = Integer.class, nillable = true)
    protected Integer scrofe;
    @XmlElement(name = "Verre", required = true, type = Integer.class, nillable = true)
    protected Integer verre;
    @XmlElement(name = "Scrofette", required = true, type = Integer.class, nillable = true)
    protected Integer scrofette;
    @XmlElement(name = "Magroncelli", required = true, type = Integer.class, nillable = true)
    protected Integer magroncelli;

    /**
     * Gets the value of the idAlleBdn property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getIdAlleBdn() {
        return idAlleBdn;
    }

    /**
     * Sets the value of the idAlleBdn property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setIdAlleBdn(Integer value) {
        this.idAlleBdn = value;
    }

    /**
     * Gets the value of the numeCapiLatte property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getNumeCapiLatte() {
        return numeCapiLatte;
    }

    /**
     * Sets the value of the numeCapiLatte property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setNumeCapiLatte(Integer value) {
        this.numeCapiLatte = value;
    }

    /**
     * Gets the value of the decoRazzaPrev property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getDecoRazzaPrev() {
        return decoRazzaPrev;
    }

    /**
     * Sets the value of the decoRazzaPrev property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setDecoRazzaPrev(Integer value) {
        this.decoRazzaPrev = value;
    }

    /**
     * Gets the value of the numeCapi624 property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getNumeCapi624() {
        return numeCapi624;
    }

    /**
     * Sets the value of the numeCapi624 property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setNumeCapi624(Integer value) {
        this.numeCapi624 = value;
    }

    /**
     * Gets the value of the numeCapiOltre24 property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getNumeCapiOltre24() {
        return numeCapiOltre24;
    }

    /**
     * Sets the value of the numeCapiOltre24 property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setNumeCapiOltre24(Integer value) {
        this.numeCapiOltre24 = value;
    }

    /**
     * Gets the value of the numeVaccheLatte property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getNumeVaccheLatte() {
        return numeVaccheLatte;
    }

    /**
     * Sets the value of the numeVaccheLatte property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setNumeVaccheLatte(Integer value) {
        this.numeVaccheLatte = value;
    }

    /**
     * Gets the value of the numeBufa property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getNumeBufa() {
        return numeBufa;
    }

    /**
     * Sets the value of the numeBufa property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setNumeBufa(Integer value) {
        this.numeBufa = value;
    }

    /**
     * Gets the value of the dataIniz property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDataIniz() {
        return dataIniz;
    }

    /**
     * Sets the value of the dataIniz property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDataIniz(String value) {
        this.dataIniz = value;
    }

    /**
     * Gets the value of the dataFine property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDataFine() {
        return dataFine;
    }

    /**
     * Sets the value of the dataFine property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDataFine(String value) {
        this.dataFine = value;
    }

    /**
     * Gets the value of the numeCapiTota property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getNumeCapiTota() {
        return numeCapiTota;
    }

    /**
     * Sets the value of the numeCapiTota property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setNumeCapiTota(Integer value) {
        this.numeCapiTota = value;
    }

    /**
     * Gets the value of the numeViteFino6 property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getNumeViteFino6() {
        return numeViteFino6;
    }

    /**
     * Sets the value of the numeViteFino6 property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setNumeViteFino6(Integer value) {
        this.numeViteFino6 = value;
    }

    /**
     * Gets the value of the nume624Mace property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getNume624Mace() {
        return nume624Mace;
    }

    /**
     * Sets the value of the nume624Mace property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setNume624Mace(Integer value) {
        this.nume624Mace = value;
    }

    /**
     * Gets the value of the nume624MaceFemm property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getNume624MaceFemm() {
        return nume624MaceFemm;
    }

    /**
     * Sets the value of the nume624MaceFemm property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setNume624MaceFemm(Integer value) {
        this.nume624MaceFemm = value;
    }

    /**
     * Gets the value of the nume624Alle property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getNume624Alle() {
        return nume624Alle;
    }

    /**
     * Sets the value of the nume624Alle property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setNume624Alle(Integer value) {
        this.nume624Alle = value;
    }

    /**
     * Gets the value of the nume624AlleFemm property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getNume624AlleFemm() {
        return nume624AlleFemm;
    }

    /**
     * Sets the value of the nume624AlleFemm property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setNume624AlleFemm(Integer value) {
        this.nume624AlleFemm = value;
    }

    /**
     * Gets the value of the numeOltre24Mace property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getNumeOltre24Mace() {
        return numeOltre24Mace;
    }

    /**
     * Sets the value of the numeOltre24Mace property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setNumeOltre24Mace(Integer value) {
        this.numeOltre24Mace = value;
    }

    /**
     * Gets the value of the numeOltre24MaceFemm property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getNumeOltre24MaceFemm() {
        return numeOltre24MaceFemm;
    }

    /**
     * Sets the value of the numeOltre24MaceFemm property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setNumeOltre24MaceFemm(Integer value) {
        this.numeOltre24MaceFemm = value;
    }

    /**
     * Gets the value of the numeOltre24Alle property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getNumeOltre24Alle() {
        return numeOltre24Alle;
    }

    /**
     * Sets the value of the numeOltre24Alle property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setNumeOltre24Alle(Integer value) {
        this.numeOltre24Alle = value;
    }

    /**
     * Gets the value of the numeOltre24AlleFemm property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getNumeOltre24AlleFemm() {
        return numeOltre24AlleFemm;
    }

    /**
     * Sets the value of the numeOltre24AlleFemm property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setNumeOltre24AlleFemm(Integer value) {
        this.numeOltre24AlleFemm = value;
    }

    /**
     * Gets the value of the numeFino6 property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getNumeFino6() {
        return numeFino6;
    }

    /**
     * Sets the value of the numeFino6 property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setNumeFino6(Integer value) {
        this.numeFino6 = value;
    }

    /**
     * Gets the value of the numeOltre6 property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getNumeOltre6() {
        return numeOltre6;
    }

    /**
     * Sets the value of the numeOltre6 property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setNumeOltre6(Integer value) {
        this.numeOltre6 = value;
    }

    /**
     * Gets the value of the numeOltre12 property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getNumeOltre12() {
        return numeOltre12;
    }

    /**
     * Sets the value of the numeOltre12 property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setNumeOltre12(Integer value) {
        this.numeOltre12 = value;
    }

    /**
     * Gets the value of the numeOltre12Femm property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getNumeOltre12Femm() {
        return numeOltre12Femm;
    }

    /**
     * Sets the value of the numeOltre12Femm property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setNumeOltre12Femm(Integer value) {
        this.numeOltre12Femm = value;
    }

    /**
     * Gets the value of the numeCapiRimonta property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getNumeCapiRimonta() {
        return numeCapiRimonta;
    }

    /**
     * Sets the value of the numeCapiRimonta property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setNumeCapiRimonta(Integer value) {
        this.numeCapiRimonta = value;
    }

    /**
     * Gets the value of the numeCapiRimontaFemm property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getNumeCapiRimontaFemm() {
        return numeCapiRimontaFemm;
    }

    /**
     * Sets the value of the numeCapiRimontaFemm property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setNumeCapiRimontaFemm(Integer value) {
        this.numeCapiRimontaFemm = value;
    }

    /**
     * Gets the value of the numeCapiRimontaUBA property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getNumeCapiRimontaUBA() {
        return numeCapiRimontaUBA;
    }

    /**
     * Sets the value of the numeCapiRimontaUBA property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setNumeCapiRimontaUBA(Integer value) {
        this.numeCapiRimontaUBA = value;
    }

    /**
     * Gets the value of the numeTori property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getNumeTori() {
        return numeTori;
    }

    /**
     * Sets the value of the numeTori property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setNumeTori(Integer value) {
        this.numeTori = value;
    }

    /**
     * Gets the value of the numeAltreVacche property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getNumeAltreVacche() {
        return numeAltreVacche;
    }

    /**
     * Sets the value of the numeAltreVacche property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setNumeAltreVacche(Integer value) {
        this.numeAltreVacche = value;
    }

    /**
     * Gets the value of the numeAltreVaccheDich property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getNumeAltreVaccheDich() {
        return numeAltreVaccheDich;
    }

    /**
     * Sets the value of the numeAltreVaccheDich property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setNumeAltreVaccheDich(Integer value) {
        this.numeAltreVaccheDich = value;
    }

    /**
     * Gets the value of the suini property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getSuini() {
        return suini;
    }

    /**
     * Sets the value of the suini property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setSuini(Integer value) {
        this.suini = value;
    }

    /**
     * Gets the value of the lattonzoli property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getLattonzoli() {
        return lattonzoli;
    }

    /**
     * Sets the value of the lattonzoli property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setLattonzoli(Integer value) {
        this.lattonzoli = value;
    }

    /**
     * Gets the value of the magroni property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getMagroni() {
        return magroni;
    }

    /**
     * Sets the value of the magroni property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setMagroni(Integer value) {
        this.magroni = value;
    }

    /**
     * Gets the value of the scrofe property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getScrofe() {
        return scrofe;
    }

    /**
     * Sets the value of the scrofe property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setScrofe(Integer value) {
        this.scrofe = value;
    }

    /**
     * Gets the value of the verre property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getVerre() {
        return verre;
    }

    /**
     * Sets the value of the verre property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setVerre(Integer value) {
        this.verre = value;
    }

    /**
     * Gets the value of the scrofette property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getScrofette() {
        return scrofette;
    }

    /**
     * Sets the value of the scrofette property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setScrofette(Integer value) {
        this.scrofette = value;
    }

    /**
     * Gets the value of the magroncelli property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getMagroncelli() {
        return magroncelli;
    }

    /**
     * Sets the value of the magroncelli property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setMagroncelli(Integer value) {
        this.magroncelli = value;
    }

}
