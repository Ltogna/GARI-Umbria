package com.abacogroup.gari.dataimporter.db.ntt;

import java.util.Optional;

/**
 * @author Gennaro Tamburrelli
 * @param <T>
 *            The ID's type of class
 */
public interface IIdRs<T> {
	void setKey(T id);

	Optional<T> getKey();

}
