
package com.abacogroup.gari.dataimporter.soap.fascicolo;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ISWSRespOTE complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ISWSRespOTE"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="CuaaAzienda" type="{http://cooperazione.sian.it/schema/fascicolo}Cuaa"/&gt;
 *         &lt;element name="NumSchedaValidazione" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="DataSchedaValidazione" type="{http://cooperazione.sian.it/schema/fascicolo}Data"/&gt;
 *         &lt;element name="codiOTE" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="DescrOTE" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="DimensioneEconomica"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}decimal"&gt;
 *               &lt;totalDigits value="18"/&gt;
 *               &lt;fractionDigits value="2"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="numCapiTot" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="SupeTot"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}decimal"&gt;
 *               &lt;totalDigits value="18"/&gt;
 *               &lt;fractionDigits value="2"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="ColtureSpecie" type="{http://cooperazione.sian.it/schema/fascicolo}ISWS_OTE_CS" maxOccurs="unbounded" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ISWSRespOTE", propOrder = {
    "cuaaAzienda",
    "numSchedaValidazione",
    "dataSchedaValidazione",
    "codiOTE",
    "descrOTE",
    "dimensioneEconomica",
    "numCapiTot",
    "supeTot",
    "coltureSpecie"
})
public class ISWSRespOTE {

    @XmlElement(name = "CuaaAzienda", required = true)
    protected String cuaaAzienda;
    @XmlElement(name = "NumSchedaValidazione", required = true)
    protected String numSchedaValidazione;
    @XmlElement(name = "DataSchedaValidazione", required = true)
    protected String dataSchedaValidazione;
    @XmlElement(required = true, nillable = true)
    protected String codiOTE;
    @XmlElement(name = "DescrOTE", required = true, nillable = true)
    protected String descrOTE;
    @XmlElement(name = "DimensioneEconomica", required = true, nillable = true)
    protected BigDecimal dimensioneEconomica;
    @XmlElement(required = true, nillable = true)
    protected String numCapiTot;
    @XmlElement(name = "SupeTot", required = true, nillable = true)
    protected BigDecimal supeTot;
    @XmlElement(name = "ColtureSpecie", nillable = true)
    protected List<ISWSOTECS> coltureSpecie;

    /**
     * Gets the value of the cuaaAzienda property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCuaaAzienda() {
        return cuaaAzienda;
    }

    /**
     * Sets the value of the cuaaAzienda property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCuaaAzienda(String value) {
        this.cuaaAzienda = value;
    }

    /**
     * Gets the value of the numSchedaValidazione property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNumSchedaValidazione() {
        return numSchedaValidazione;
    }

    /**
     * Sets the value of the numSchedaValidazione property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNumSchedaValidazione(String value) {
        this.numSchedaValidazione = value;
    }

    /**
     * Gets the value of the dataSchedaValidazione property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDataSchedaValidazione() {
        return dataSchedaValidazione;
    }

    /**
     * Sets the value of the dataSchedaValidazione property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDataSchedaValidazione(String value) {
        this.dataSchedaValidazione = value;
    }

    /**
     * Gets the value of the codiOTE property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodiOTE() {
        return codiOTE;
    }

    /**
     * Sets the value of the codiOTE property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodiOTE(String value) {
        this.codiOTE = value;
    }

    /**
     * Gets the value of the descrOTE property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDescrOTE() {
        return descrOTE;
    }

    /**
     * Sets the value of the descrOTE property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDescrOTE(String value) {
        this.descrOTE = value;
    }

    /**
     * Gets the value of the dimensioneEconomica property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getDimensioneEconomica() {
        return dimensioneEconomica;
    }

    /**
     * Sets the value of the dimensioneEconomica property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setDimensioneEconomica(BigDecimal value) {
        this.dimensioneEconomica = value;
    }

    /**
     * Gets the value of the numCapiTot property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNumCapiTot() {
        return numCapiTot;
    }

    /**
     * Sets the value of the numCapiTot property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNumCapiTot(String value) {
        this.numCapiTot = value;
    }

    /**
     * Gets the value of the supeTot property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getSupeTot() {
        return supeTot;
    }

    /**
     * Sets the value of the supeTot property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setSupeTot(BigDecimal value) {
        this.supeTot = value;
    }

    /**
     * Gets the value of the coltureSpecie property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the Jakarta XML Binding object.
     * This is why there is not a <CODE>set</CODE> method for the coltureSpecie property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getColtureSpecie().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ISWSOTECS }
     * 
     * 
     */
    public List<ISWSOTECS> getColtureSpecie() {
        if (coltureSpecie == null) {
            coltureSpecie = new ArrayList<ISWSOTECS>();
        }
        return this.coltureSpecie;
    }

}
