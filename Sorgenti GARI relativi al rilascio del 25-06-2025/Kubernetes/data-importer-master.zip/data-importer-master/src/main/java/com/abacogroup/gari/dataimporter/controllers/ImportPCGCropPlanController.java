package com.abacogroup.gari.dataimporter.controllers;

import java.time.OffsetDateTime;

import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.gari.dataimporter.DTOs.PCGCropPlanResponse;
import com.abacogroup.gari.dataimporter.Interfaces.ICropPlanService;
import com.abacogroup.jdbi.paging.InfiniteListResults;

import io.dropwizard.auth.Auth;
import jakarta.annotation.security.RolesAllowed;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.MediaType;

@Path("/{tenant}/public/v1/pcg")
@Produces(MediaType.APPLICATION_JSON)
public class ImportPCGCropPlanController {
	private final ICropPlanService iCropPlanService;

	public ImportPCGCropPlanController(ICropPlanService iCropPlanService) {
		this.iCropPlanService = iCropPlanService;
	}

	@GET
	@Path("/{cuaa}/{campagna}")
	@RolesAllowed({ "DATAIMPORTER|CROPPLAN", "DATAIMPORTER|ADMIN" })
	public InfiniteListResults<PCGCropPlanResponse> findPCGCropPlanByCuaa(
			@Auth User user,
			@PathParam("tenant") String tenantId,
			@PathParam("cuaa") String cuaa,
			@PathParam("campagna") Integer campagna,
			@QueryParam("nextKey") String nextKey) {
		return iCropPlanService.findPCGCropPlanByCuaa(user, tenantId, cuaa, campagna, nextKey);
	}

	@GET
	@Path("/{cuaa}/aggiornamento")
	@RolesAllowed({ "DATAIMPORTER|CROPPLAN", "DATAIMPORTER|ADMIN" })
	public InfiniteListResults<PCGCropPlanResponse> deltaHandling(
			@Auth User user,
			@PathParam("tenant") String tenantId,
			@PathParam("cuaa") String cuaa,
			@QueryParam("ref_timestamp") OffsetDateTime reftimestamp) {
		return iCropPlanService.deltaHandling(user, tenantId, cuaa, reftimestamp);
	}
}
