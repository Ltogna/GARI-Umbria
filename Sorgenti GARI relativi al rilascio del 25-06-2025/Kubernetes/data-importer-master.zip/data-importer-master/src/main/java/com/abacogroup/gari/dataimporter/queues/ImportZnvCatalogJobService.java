package com.abacogroup.gari.dataimporter.queues;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.OffsetDateTime;

@Data
@NoArgsConstructor
public class ImportZnvCatalogJobService {

	private double xmin;
	private double ymin;
	private double xmax;
	private double ymax;
	private String epsg;
	private OffsetDateTime dataVal;
	private String requestId;
	private String tenantId;

	public ImportZnvCatalogJobService(double xmin, double ymin, double xmax, double ymax, String epsg, OffsetDateTime dataVal, String requestId,
			String tenantId) {
		this.xmin = xmin;
		this.ymin = ymin;
		this.xmax = xmax;
		this.ymax = ymax;
		this.epsg = epsg;
		this.dataVal = dataVal;
		this.requestId = requestId;
		this.tenantId = tenantId;
	}

	public double getXmin() {
		return xmin;
	}

	public void setXmin(double xmin) {
		this.xmin = xmin;
	}

	public double getYmin() {
		return ymin;
	}

	public void setYmin(double ymin) {
		this.ymin = ymin;
	}

	public double getXmax() {
		return xmax;
	}

	public void setXmax(double xmax) {
		this.xmax = xmax;
	}

	public double getYmax() {
		return ymax;
	}

	public void setYmax(double ymax) {
		this.ymax = ymax;
	}

	public String getEpsg() {
		return epsg;
	}

	public void setEpsg(String epsg) {
		this.epsg = epsg;
	}

	public OffsetDateTime getDataVa() {
		return dataVal;
	}

	public void setDataVa(OffsetDateTime dataVal) {
		this.dataVal = dataVal;
	}

	public String getRequestId() {
		return requestId;
	}

	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}

	public String getTenantId() {
		return tenantId;
	}

	public void setTenantId(String tenantId) {
		this.tenantId = tenantId;
	}
}
