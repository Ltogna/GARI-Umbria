package com.abacogroup.gari.dataimporter.DTOs;

import org.locationtech.jts.geom.Geometry;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class PlotCropPlanRequest {

	private String fromPointInTime;
	private Geometry geom;
	private CutParameters cutParameters;

	@Data
	public static class CutParameters {
		private String behaviour;
		private List<String> plotCodes;
	}
}
