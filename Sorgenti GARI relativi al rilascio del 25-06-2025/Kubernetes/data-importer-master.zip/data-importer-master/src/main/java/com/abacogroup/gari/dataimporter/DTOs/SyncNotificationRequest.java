package com.abacogroup.gari.dataimporter.DTOs;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.OffsetDateTime;
import java.util.List;

	@Data
	@Builder
	@NoArgsConstructor
	@AllArgsConstructor
	public class SyncNotificationRequest {
		@JsonProperty("processed")
		private boolean processed;

		@JsonProperty("entities")
		private List<Entity> entities;

		@JsonProperty("errors")
		private List<Error> errors;

		@Data
		@Builder
		@NoArgsConstructor
		@AllArgsConstructor
		public static class Entity {
			@JsonProperty("entity")
			private String entity;

			@JsonProperty("ref_timestamp")
			private OffsetDateTime refTimestamp; // Use `OffsetDateTime` if you prefer date parsing
		}

		@Data
		@Builder
		@NoArgsConstructor
		@AllArgsConstructor
		public static class Error {
			@JsonProperty("code")
			private String code;

			@JsonProperty("msg")
			private String msg;

			@JsonProperty("key")
			private String key;
		}
	}