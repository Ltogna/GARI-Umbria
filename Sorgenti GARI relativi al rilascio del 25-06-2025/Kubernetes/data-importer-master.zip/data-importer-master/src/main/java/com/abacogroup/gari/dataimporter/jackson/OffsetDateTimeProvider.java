package com.abacogroup.gari.dataimporter.jackson;

import jakarta.ws.rs.ext.ParamConverter;
import jakarta.ws.rs.ext.ParamConverterProvider;
import jakarta.ws.rs.ext.Provider;
import java.lang.annotation.Annotation;
import java.lang.reflect.Type;
import java.time.OffsetDateTime;
import java.time.format.DateTimeFormatter;

@Provider
public class OffsetDateTimeProvider implements ParamConverterProvider
{

	@Override
	public <T> ParamConverter<T> getConverter(Class<T> clazz, Type type, Annotation[] annotations)
	{
		if (!clazz.equals(OffsetDateTime.class))
			return null;

		return new ParamConverter<T>()
		{
			@Override
			@SuppressWarnings("unchecked")
			public T fromString(String value)
			{
				if (value == null)
					return null;
				return (T) OffsetDateTime.parse(value);
			}

			@Override
			public String toString(T time)
			{
				OffsetDateTime dt = (OffsetDateTime) time;
				return dt.format(DateTimeFormatter.ISO_OFFSET_DATE_TIME);
			}
		};
	}
}