package com.abacogroup.gari.dataimporter.DTOs;

import java.time.OffsetDateTime;
import java.util.List;
import java.util.Map;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 
 * @author Emanuele Crocilla
 *
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class UserDetails {

	private String userId;
	private String tenant;
	private String userName;
	private String description;

	private Boolean internalUser;  // Se true
	private String userLocale;
	private String dateFormat;
	private char isLocked;
	private char isModifyPasswordOnNextLogin;
	private OffsetDateTime creationDate;
	private OffsetDateTime lastLoginDate;
	private OffsetDateTime lastLoginModificationDate;
	private List<UserRoleData> userRoles;
	private Map<String, String> userProperties;
	
	@Data
	@Builder
	@NoArgsConstructor
	@AllArgsConstructor
	public static class UserRoleData {
		
		private String roleCode;
		private String description;
		private OffsetDateTime assignmentDate;
		
		
	}
	
}
