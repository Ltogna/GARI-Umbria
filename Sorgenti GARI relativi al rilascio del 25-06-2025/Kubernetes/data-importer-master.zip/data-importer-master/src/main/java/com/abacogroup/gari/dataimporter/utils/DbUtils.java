package com.abacogroup.gari.dataimporter.utils;

import java.util.Optional;

/**
 * 
 * @author Emanuele Crocilla
 *
 */
public class DbUtils {

    /**
     * The constant isPostgres.
     */
    public static Boolean isPostgres;

    /**
     * Converts a flag represented by a "Y"/"N"/ or "S"/"N" or "1"/"0" string to boolean,
     * where "Y"/"S" is true and "N" is false
     *
     * @param flag the string representation of a boolean
     * @return the flag value rerpesented by a Boolean
     */
    public static Boolean convertYNFlag(String flag) {
        if (Optional.ofNullable(flag).isEmpty() || flag.isEmpty()) {
            return null;
        }

        return "S".equals(flag) || "Y".equals(flag) || "1".equals(flag);
    }
    
    public static Boolean convertYNFlag(Short flag) {
        if ( Optional.ofNullable(flag).isEmpty() ) {
            return null;
        }

        return flag == 1;
    }
    
    public static Short convertBoolFlag(Boolean n) {
        if ( Optional.ofNullable(n).isEmpty()) {
            return null;
        }

        return (short) (n ? 1 : 0);
    }
}
