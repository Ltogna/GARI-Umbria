package com.abacogroup.gari.dataimporter.db.dao;

import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.transaction.Transactional;

import java.util.List;

/**
 * 
 * @author Emanuele Crocilla
 *
 * @param <T>
 * @param <D>
 */
public interface DataImporterDAO<T, D> extends /*EnhancedSqlObject,*/ Transactional<DataImporterDAO<T, D>> {
	@SqlQuery
	List<T> findById(D id);
}
