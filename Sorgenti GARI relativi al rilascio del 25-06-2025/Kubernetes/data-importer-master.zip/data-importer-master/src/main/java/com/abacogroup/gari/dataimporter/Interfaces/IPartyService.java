package com.abacogroup.gari.dataimporter.Interfaces;

import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.gari.dataimporter.DTOs.PartyResponse;

public interface IPartyService {
	PartyResponse getParty(User user, String tenant, String cuaa);
}
