
package com.abacogroup.gari.dataimporter.soap.fascicolo;

import jakarta.xml.bind.JAXBElement;
import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElementRef;
import jakarta.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ISWSRiep3 complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ISWSRiep3"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="CodiceOccupazione" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;length value="3"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="CodiceDestinazioneUso" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;length value="3"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="CodiceUso" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;length value="3"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="CodiceQualita" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;length value="3"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="CodiceVarieta" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;length value="3"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="SuperficieDichiarata" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="SuperficieRiscontrata" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ISWSRiep3", propOrder = {
    "codiceOccupazione",
    "codiceDestinazioneUso",
    "codiceUso",
    "codiceQualita",
    "codiceVarieta",
    "superficieDichiarata",
    "superficieRiscontrata"
})
public class ISWSRiep3 {

    @XmlElementRef(name = "CodiceOccupazione", namespace = "http://cooperazione.sian.it/schema/fascicolo", type = JAXBElement.class, required = false)
    protected JAXBElement<String> codiceOccupazione;
    @XmlElementRef(name = "CodiceDestinazioneUso", namespace = "http://cooperazione.sian.it/schema/fascicolo", type = JAXBElement.class, required = false)
    protected JAXBElement<String> codiceDestinazioneUso;
    @XmlElementRef(name = "CodiceUso", namespace = "http://cooperazione.sian.it/schema/fascicolo", type = JAXBElement.class, required = false)
    protected JAXBElement<String> codiceUso;
    @XmlElementRef(name = "CodiceQualita", namespace = "http://cooperazione.sian.it/schema/fascicolo", type = JAXBElement.class, required = false)
    protected JAXBElement<String> codiceQualita;
    @XmlElementRef(name = "CodiceVarieta", namespace = "http://cooperazione.sian.it/schema/fascicolo", type = JAXBElement.class, required = false)
    protected JAXBElement<String> codiceVarieta;
    @XmlElementRef(name = "SuperficieDichiarata", namespace = "http://cooperazione.sian.it/schema/fascicolo", type = JAXBElement.class, required = false)
    protected JAXBElement<String> superficieDichiarata;
    @XmlElementRef(name = "SuperficieRiscontrata", namespace = "http://cooperazione.sian.it/schema/fascicolo", type = JAXBElement.class, required = false)
    protected JAXBElement<String> superficieRiscontrata;

    /**
     * Gets the value of the codiceOccupazione property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getCodiceOccupazione() {
        return codiceOccupazione;
    }

    /**
     * Sets the value of the codiceOccupazione property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setCodiceOccupazione(JAXBElement<String> value) {
        this.codiceOccupazione = value;
    }

    /**
     * Gets the value of the codiceDestinazioneUso property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getCodiceDestinazioneUso() {
        return codiceDestinazioneUso;
    }

    /**
     * Sets the value of the codiceDestinazioneUso property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setCodiceDestinazioneUso(JAXBElement<String> value) {
        this.codiceDestinazioneUso = value;
    }

    /**
     * Gets the value of the codiceUso property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getCodiceUso() {
        return codiceUso;
    }

    /**
     * Sets the value of the codiceUso property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setCodiceUso(JAXBElement<String> value) {
        this.codiceUso = value;
    }

    /**
     * Gets the value of the codiceQualita property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getCodiceQualita() {
        return codiceQualita;
    }

    /**
     * Sets the value of the codiceQualita property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setCodiceQualita(JAXBElement<String> value) {
        this.codiceQualita = value;
    }

    /**
     * Gets the value of the codiceVarieta property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getCodiceVarieta() {
        return codiceVarieta;
    }

    /**
     * Sets the value of the codiceVarieta property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setCodiceVarieta(JAXBElement<String> value) {
        this.codiceVarieta = value;
    }

    /**
     * Gets the value of the superficieDichiarata property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getSuperficieDichiarata() {
        return superficieDichiarata;
    }

    /**
     * Sets the value of the superficieDichiarata property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setSuperficieDichiarata(JAXBElement<String> value) {
        this.superficieDichiarata = value;
    }

    /**
     * Gets the value of the superficieRiscontrata property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getSuperficieRiscontrata() {
        return superficieRiscontrata;
    }

    /**
     * Sets the value of the superficieRiscontrata property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setSuperficieRiscontrata(JAXBElement<String> value) {
        this.superficieRiscontrata = value;
    }

}
