package com.abacogroup.gari.dataimporter.queues;

import com.abacogroup.embeddedqueue.QueueErrorListener;
import com.abacogroup.embeddedqueue.ThrowingConsumer;
import com.abacogroup.gari.dataimporter.db.dao.NotificationsDAO;
import com.abacogroup.gari.dataimporter.services.GIASNotificationService;

public class NotificationsConsumer implements ThrowingConsumer<String>, QueueErrorListener<String> {

	private final GIASNotificationService giasNotificationService;
	private NotificationsDAO notificationsDAO;

	public NotificationsConsumer(GIASNotificationService _giasNotificationService, NotificationsDAO norNotificationsDAO) {
		this.giasNotificationService = _giasNotificationService;
		this.notificationsDAO = norNotificationsDAO;
	}

	@Override
	public void accept(String ulid) throws Exception {
		giasNotificationService.WorkQueueSync(ulid);
	}

	@Override
	public ErrorAction onJobError(String ulid, Throwable t) {
		notificationsDAO.delete(ulid); // We will schedule it again the next time that fires notifications queue runs
		return ErrorAction.MARK_AS_ERRORED;
	}
}
