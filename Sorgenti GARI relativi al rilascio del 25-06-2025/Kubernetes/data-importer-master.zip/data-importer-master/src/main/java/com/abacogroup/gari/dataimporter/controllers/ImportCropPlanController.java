package com.abacogroup.gari.dataimporter.controllers;

import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.embeddedqueue.WorkQueue;
import com.abacogroup.gari.dataimporter.DTOs.ImportType;
import com.abacogroup.gari.dataimporter.DTOs.LoggerResponse;
import com.abacogroup.gari.dataimporter.db.ntt.TrackRequestNTT;
import com.abacogroup.gari.dataimporter.queues.ImportJobService;
import com.abacogroup.gari.dataimporter.services.TrackRequestService;
import io.dropwizard.auth.Auth;
import jakarta.validation.constraints.NotNull;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;

import java.util.List;

@Path("/{tenant}/public/v1/import-crop-plan")
@Produces(MediaType.APPLICATION_JSON)
public class ImportCropPlanController {
	private final TrackRequestService _trackingService;
	private WorkQueue<ImportJobService> cropPlanQueue;

	public ImportCropPlanController(WorkQueue<ImportJobService> cropPlanQueue, TrackRequestService trackingService) {
		this.cropPlanQueue = cropPlanQueue;
		_trackingService = trackingService;
	}

	@GET
	@Path("/{cuaa}/import")
	public TrackRequestNTT createImportRequest(
			@Auth User user,
			@PathParam("tenant") String tenantId,
			@PathParam("cuaa") String cuaa,
			@QueryParam("campagna") @NotNull Integer campagna) {

		var trackRequest = _trackingService.createTrackRequest(tenantId, cuaa, campagna.toString(), "PENDING", ImportType.IMPORT_CROP_PLAN);
		ImportJobService job = new ImportJobService(tenantId, cuaa, campagna, trackRequest.getRequestId());
		cropPlanQueue.add(job, System.currentTimeMillis());
		return trackRequest;
	}

	@GET
	@Path("/{cuaa}/requests/{requestId}")
	public TrackRequestNTT getProccessById(
			@Auth User user,
			@PathParam("tenant") String tenantId,
			@PathParam("cuaa") String cuaa,
			@PathParam("requestId") String requestId) {
		return _trackingService.findByIdAndCuaaAndTenant(requestId, cuaa, tenantId, ImportType.IMPORT_CROP_PLAN);
	}

	@GET
	@Path("/{cuaa}/requests/{requestId}/log")
	public LoggerResponse getLogByRequestId(
			@Auth User user,
			@PathParam("tenant") String tenantId,
			@PathParam("cuaa") String cuaa,
			@PathParam("requestId") String requestId) {
		return _trackingService.findLogByIdAndCuaaAndTenant(requestId, cuaa, tenantId, ImportType.IMPORT_CROP_PLAN);
	}

	@GET
	@Path("/{cuaa}/requests")
	public List<TrackRequestNTT> GetCuaaRequests(
			@Auth User user,
			@PathParam("tenant") String tenantId,
			@PathParam("cuaa") String cuaa,
			@QueryParam("onlyPending") @DefaultValue("true") boolean onlyPending) {
		return _trackingService.findBySatusAndCuaaAndTenant(cuaa, tenantId, onlyPending, ImportType.IMPORT_CROP_PLAN);
	}
}
