package com.abacogroup.gari.dataimporter.services;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.jdbi.v3.core.Jdbi;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.abacogroup.dropwizard.auth.sso2.Sso2Client;
import com.abacogroup.embeddedqueue.QueueErrorListener.ErrorAction;
import com.abacogroup.embeddedqueue.WorkQueue;
import com.abacogroup.embeddedqueue.db.JdbiRepository;
import com.abacogroup.gari.dataimporter.DataImporterConfiguration;
import com.abacogroup.gari.dataimporter.DTOs.GiasUser;
import com.abacogroup.gari.dataimporter.DTOs.UserDetails;
import com.abacogroup.gari.dataimporter.DTOs.GiasUser.UserRole;
import com.abacogroup.gari.dataimporter.DTOs.UserDetails.UserRoleData;
import com.abacogroup.gari.dataimporter.db.dao.LoggerDAO;
import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.Delivery;

import io.dropwizard.auth.AuthenticationException;
import io.dropwizard.core.setup.Environment;
import jakarta.ws.rs.client.Client;

/**
 * 
 * @author Emanuele Crocilla
 *
 */
public class GIASUsersSynchronizationService extends ADataImporterService {

    private static final Logger log = LoggerFactory.getLogger(GIASUsersSynchronizationService.class);

    private static final String QUEUE = "sync-users-to-gias";
    private static final String EXCHANGE = "sso2-exchange";
    private static final String ROUTING_KEY = "user.*"; //  (added,updated)

	private SSO2UserService sso2UserService;
	private GIASUserService giasUserService;

    public GIASUsersSynchronizationService(Environment environment, DataImporterConfiguration config, 
    		Sso2Client sso2Client, Client client, Jdbi jdbi, Connection rabbitMQConnection, 
    		GIASUserService giasUserService, SSO2UserService ss2UserService, LoggerDAO loggerDAO) throws IOException {
    	
    	super(sso2Client, client, config, environment.getObjectMapper(), loggerDAO);
    	
    	this.sso2UserService = ss2UserService;
    	this.giasUserService = giasUserService;

        WorkQueue<WorkQueuePayload> workQueue = WorkQueue.builder(QUEUE, new JdbiRepository(jdbi), WorkQueuePayload.class)
                .withConsumer(this::consumeWorkQueueMessage)
                .withErrorListener((el, t) -> ErrorAction.MARK_AS_ERRORED)
                .withMetricsRegistry(environment.metrics())
                .withNumThreads(1)
                .withTimeoutMs(60_000)
                .build();
        workQueue.start();

        setupRabbit(rabbitMQConnection, workQueue);
    }

    private void setupRabbit(Connection rabbitMQConnection, WorkQueue<WorkQueuePayload> workQueue) throws IOException {
        if (rabbitMQConnection == null) {
            return;
        }

        Channel channel = rabbitMQConnection.createChannel();
        channel.queueDeclare(QUEUE, true, false, false, null);
        channel.queueBind(QUEUE, EXCHANGE, ROUTING_KEY);
        channel.basicQos(1);
        channel.basicConsume(QUEUE, false,
                (consumerTag, delivery) -> onRabbitMqMessage(workQueue, delivery, channel),
                consumerTag -> {
                });
    }

    private void onRabbitMqMessage(WorkQueue<WorkQueuePayload> workQueue, Delivery delivery, Channel channel) throws IOException {
        long deliveryTag = delivery.getEnvelope().getDeliveryTag();
        try {
            // The event carries more info but we do not care...
            WorkQueuePayload payload = mapper.readValue(delivery.getBody(), WorkQueuePayload.class);
            workQueue.add(payload, System.currentTimeMillis());
            channel.basicAck(deliveryTag, false);
        } catch (Throwable t) {
            log.error("Error processing message", t);
            channel.basicNack(deliveryTag, false, false);
        }
    }

    private void consumeWorkQueueMessage(WorkQueuePayload payload) throws AuthenticationException {
        log.info("Processing GIAS user sync for username {}/{}", payload.tenant, payload.username);

        String authToken = getAuthToken(payload.tenant);
        
        // TODO EC - REMOVE THIS AFTER TESTS
        // authToken = "eyJraWQiOiIyMDI1MDYxNjE0MzkwMjE0cm9yZ2Q2d3JheHkiLCJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJzdWIiOiJNQVNURVIvQURNSU4iLCJhdWQiOiJzc28yLWF1dGgiLCJpc3MiOiJBYmFjby1TU08yIiwiZXhwIjoxNzUwMjU5NjEzLCJpYXQiOjE3NTAyNTkzMTMsInRlbmFudCI6Im1hc3RlciIsIl9sbCI6ZmFsc2UsInVzZXJuYW1lIjoiQURNSU4ifQ.QvRdojIHQF19WvIzUHQPElK1Sn2kpiD_eiHn6uyb9-beWzZeqJiFefRlNzdKbDv6MslYCsoCO7y3VsgaRAU6EnftcXeZp3HwuV-Wm_Ms8mENQYADKrfnh12ZU0pe-e1Q-1MFgQGhiIIn6UdotLoKHq1VUfSbr5kTwa-Sv2HynlPQ0dTwk4TLke4DZxNL6Euai5opA1Yr2ZuA8Dh02qbLoY3aM4trj-TGSLlUbwUJZMXX3Oo70VLZdmLPZxCNE0jgtFY_8yCj69aWpKCGmvmV0KP68F3FeCSCwwL0nXm4fKhlaVjbTRelVxe2Acz6K7kYGZpz0DOBoi8qGbzQmZUr2A";
        
        UserDetails userBySSO2 = sso2UserService.getUserBySSO2(authToken, payload.tenant, payload.username);
        
        // prepare user for GIAS
        var userProperties = userBySSO2.getUserProperties(); 
        var isLocked = 'N' != userBySSO2.getIsLocked();
        
        GiasUser giasUser = GiasUser.builder()
        		.username(userBySSO2.getUserName())
        		.cognome(userBySSO2.getDescription())
        		.nome(null)
        		.codiceFiscale(userProperties.get("fiscalCode"))
        		.mail(userProperties.get("email"))
        		.bloccato(isLocked)
        		.spid(!userBySSO2.getInternalUser())
        		.userRoles(convertUserRoles(userBySSO2.getUserRoles()))
        		.build();
        
		giasUserService.sendUserToGias(giasUser);
    }

    private List<UserRole> convertUserRoles(List<UserRoleData> userRoles) {
    	List<UserRole> roles = new ArrayList<>();
    	userRoles.forEach(e -> roles.add(new UserRole(e.getRoleCode())));
		return roles;
	}

    public static final class WorkQueuePayload {
        public String tenant;
        public String username;
    }
}
