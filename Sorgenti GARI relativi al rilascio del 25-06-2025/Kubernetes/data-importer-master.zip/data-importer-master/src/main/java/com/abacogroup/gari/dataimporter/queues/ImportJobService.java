package com.abacogroup.gari.dataimporter.queues;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ImportJobService {
	private String requestId;
	private String tenantId;
	private String cuaa;
	private Integer campagna;

	public ImportJobService(String tenantId, String cuaa, Integer campagna, String requestId) {
		this.requestId = requestId;
		this.tenantId = tenantId;
		this.cuaa = cuaa;
		this.campagna = campagna;
	}

	public String getRequestId() {
		return requestId;
	}

	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}

	public String getTenantId() {
		return tenantId;
	}

	public void setTenantId(String tenantId) {
		this.tenantId = tenantId;
	}

	public String getCuaa() {
		return cuaa;
	}

	public void setCuaa(String cuaa) {
		this.cuaa = cuaa;
	}

	public Integer getCampagna() {
		return campagna;
	}

	public void setCampagna(Integer campagna) {
		this.campagna = campagna;
	}
}
