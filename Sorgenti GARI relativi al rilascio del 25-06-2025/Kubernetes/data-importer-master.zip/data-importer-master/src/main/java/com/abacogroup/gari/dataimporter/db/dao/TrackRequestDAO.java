package com.abacogroup.gari.dataimporter.db.dao;

import java.util.List;

import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.customizer.BindBean;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;

import com.abacogroup.gari.dataimporter.db.ntt.LoggerNTT;
import com.abacogroup.gari.dataimporter.db.ntt.TrackRequestNTT;

@RegisterBeanMapper(LoggerNTT.class)
@RegisterBeanMapper(TrackRequestNTT.class)
public interface TrackRequestDAO {

	@SqlUpdate("INSERT INTO dataimporter_track_request (request_id, user_id, cuaa, campagna, dt_request, fl_status, import_type) " +
			"VALUES (:requestId, :userId, :cuaa, :campagna, :dtRequest, :flStatus,:importType)")
	void insert(@BindBean TrackRequestNTT trackRequest);

	@SqlQuery("SELECT * FROM dataimporter_track_request " +
			"WHERE request_id = :requestId " +
			"AND cuaa = :cuaa " +
			"AND import_type = :importType " +
			"AND user_id LIKE CONCAT(:tenant, '/%')")
	TrackRequestNTT findByIdAndCuaaAndTenant(@Bind("requestId") String requestId,
			@Bind("cuaa") String cuaa,
			@Bind("tenant") String tenant,
			@Bind("importType") Integer importType);

	@SqlUpdate("UPDATE dataimporter_track_request " +
			"SET fl_status = :newStatus " +
			"WHERE request_id = :requestId")
	int updateStatus(@Bind("requestId") String requestId, @Bind("newStatus") String newStatus);

	@SqlQuery("SELECT * FROM dataimporter_track_request " +
			"WHERE cuaa = :cuaa " +
			"AND user_id LIKE CONCAT(:tenant, '/%') " +
			"AND import_type = :importType " +
			"AND (:onlyPending IS FALSE OR fl_status = 'PENDING')")
	List<TrackRequestNTT> findBySatusAndCuaaAndTenant(
			@Bind("cuaa") String cuaa,
			@Bind("tenant") String tenant,
			@Bind("onlyPending") boolean onlyPending,
			@Bind("importType") Integer importType);

	@SqlQuery("SELECT * FROM dataimporter_logger WHERE request_id = :requestId")
	List<LoggerNTT> findLoggersWithDifferentObjectRequest(@Bind("requestId") String requestId);
}
