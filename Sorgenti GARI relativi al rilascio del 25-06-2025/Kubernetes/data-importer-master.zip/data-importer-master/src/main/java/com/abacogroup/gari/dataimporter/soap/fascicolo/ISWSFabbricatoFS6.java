
package com.abacogroup.gari.dataimporter.soap.fascicolo;

import java.util.ArrayList;
import java.util.List;
import jakarta.xml.bind.JAXBElement;
import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlElementRef;
import jakarta.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ISWSFabbricatoFS6 complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ISWSFabbricatoFS6"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="CUAA" type="{http://cooperazione.sian.it/schema/fascicolo}Cuaa"/&gt;
 *         &lt;element name="Provincia" type="{http://cooperazione.sian.it/schema/fascicolo}Provincia"/&gt;
 *         &lt;element name="Comune" type="{http://cooperazione.sian.it/schema/fascicolo}Comune"/&gt;
 *         &lt;element name="Sezione" type="{http://cooperazione.sian.it/schema/fascicolo}Sezione"/&gt;
 *         &lt;element name="Foglio" type="{http://cooperazione.sian.it/schema/fascicolo}Foglio"/&gt;
 *         &lt;element name="Particella" type="{http://cooperazione.sian.it/schema/fascicolo}Particella"/&gt;
 *         &lt;element name="Subalterno" type="{http://cooperazione.sian.it/schema/fascicolo}Subalterno"/&gt;
 *         &lt;element name="Tipo"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;enumeration value="301"/&gt;
 *               &lt;enumeration value="302"/&gt;
 *               &lt;enumeration value="303"/&gt;
 *               &lt;enumeration value="304"/&gt;
 *               &lt;enumeration value="305"/&gt;
 *               &lt;enumeration value="306"/&gt;
 *               &lt;enumeration value="307"/&gt;
 *               &lt;enumeration value="308"/&gt;
 *               &lt;enumeration value="309"/&gt;
 *               &lt;enumeration value="310"/&gt;
 *               &lt;enumeration value="311"/&gt;
 *               &lt;enumeration value="312"/&gt;
 *               &lt;enumeration value="313"/&gt;
 *               &lt;enumeration value="314"/&gt;
 *               &lt;enumeration value="315"/&gt;
 *               &lt;enumeration value="316"/&gt;
 *               &lt;enumeration value="317"/&gt;
 *               &lt;enumeration value="318"/&gt;
 *               &lt;enumeration value="319"/&gt;
 *               &lt;enumeration value="320"/&gt;
 *               &lt;enumeration value="321"/&gt;
 *               &lt;enumeration value="322"/&gt;
 *               &lt;enumeration value="323"/&gt;
 *               &lt;enumeration value="324"/&gt;
 *               &lt;enumeration value="325"/&gt;
 *               &lt;enumeration value="326"/&gt;
 *               &lt;enumeration value="327"/&gt;
 *               &lt;enumeration value="328"/&gt;
 *               &lt;enumeration value="329"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="Destinazione"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;enumeration value="1"/&gt;
 *               &lt;enumeration value="2"/&gt;
 *               &lt;enumeration value="3"/&gt;
 *               &lt;enumeration value="4"/&gt;
 *               &lt;enumeration value="5"/&gt;
 *               &lt;enumeration value="6"/&gt;
 *               &lt;enumeration value="7"/&gt;
 *               &lt;enumeration value="8"/&gt;
 *               &lt;enumeration value="9"/&gt;
 *               &lt;enumeration value="10"/&gt;
 *               &lt;enumeration value="11"/&gt;
 *               &lt;enumeration value="12"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="CasiParticolari" type="{http://cooperazione.sian.it/schema/fascicolo}CasiParticolari" minOccurs="0"/&gt;
 *         &lt;element name="SuperficieCoperta" type="{http://cooperazione.sian.it/schema/fascicolo}Superficie"/&gt;
 *         &lt;element name="SuperficieScoperta" type="{http://cooperazione.sian.it/schema/fascicolo}Superficie"/&gt;
 *         &lt;element name="Volume" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="NumeroPosti" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="TipoConduzione" type="{http://cooperazione.sian.it/schema/fascicolo}TipoConduzione"/&gt;
 *         &lt;element name="DataInizioConduzione" type="{http://cooperazione.sian.it/schema/fascicolo}Data"/&gt;
 *         &lt;element name="DataFineConduzione" type="{http://cooperazione.sian.it/schema/fascicolo}Data"/&gt;
 *         &lt;element name="Uso" type="{http://cooperazione.sian.it/schema/fascicolo}ISWSUtilizzoFabbricato" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="Proprietari" type="{http://cooperazione.sian.it/schema/fascicolo}ISWSProprietario" maxOccurs="5" minOccurs="0"/&gt;
 *         &lt;element name="CodiceLivello" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;length value="3"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="CodiceOccupazioneSuolo"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="CodiceDestinazioneUso"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;length value="3"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="CodiceUso"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;length value="3"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="CodiceQualita"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;length value="3"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="CodiceOccupazioneVarieta" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ISWSFabbricatoFS6", propOrder = {
    "cuaa",
    "provincia",
    "comune",
    "sezione",
    "foglio",
    "particella",
    "subalterno",
    "tipo",
    "destinazione",
    "casiParticolari",
    "superficieCoperta",
    "superficieScoperta",
    "volume",
    "numeroPosti",
    "tipoConduzione",
    "dataInizioConduzione",
    "dataFineConduzione",
    "uso",
    "proprietari",
    "codiceLivello",
    "codiceOccupazioneSuolo",
    "codiceDestinazioneUso",
    "codiceUso",
    "codiceQualita",
    "codiceOccupazioneVarieta"
})
public class ISWSFabbricatoFS6 {

    @XmlElement(name = "CUAA", required = true)
    protected String cuaa;
    @XmlElement(name = "Provincia", required = true)
    protected String provincia;
    @XmlElement(name = "Comune", required = true)
    protected String comune;
    @XmlElement(name = "Sezione", required = true, nillable = true)
    protected String sezione;
    @XmlElement(name = "Foglio", required = true)
    protected String foglio;
    @XmlElement(name = "Particella", required = true)
    protected String particella;
    @XmlElement(name = "Subalterno", required = true, nillable = true)
    protected String subalterno;
    @XmlElement(name = "Tipo", required = true)
    protected String tipo;
    @XmlElement(name = "Destinazione", required = true)
    protected String destinazione;
    @XmlElementRef(name = "CasiParticolari", namespace = "http://cooperazione.sian.it/schema/fascicolo", type = JAXBElement.class, required = false)
    protected JAXBElement<String> casiParticolari;
    @XmlElement(name = "SuperficieCoperta", required = true, nillable = true)
    protected String superficieCoperta;
    @XmlElement(name = "SuperficieScoperta", required = true, nillable = true)
    protected String superficieScoperta;
    @XmlElement(name = "Volume", required = true, nillable = true)
    protected String volume;
    @XmlElement(name = "NumeroPosti", required = true, nillable = true)
    protected String numeroPosti;
    @XmlElement(name = "TipoConduzione", required = true, nillable = true)
    protected String tipoConduzione;
    @XmlElement(name = "DataInizioConduzione", required = true)
    protected String dataInizioConduzione;
    @XmlElement(name = "DataFineConduzione", required = true, nillable = true)
    protected String dataFineConduzione;
    @XmlElement(name = "Uso", nillable = true)
    protected List<ISWSUtilizzoFabbricato> uso;
    @XmlElement(name = "Proprietari", nillable = true)
    protected List<ISWSProprietario> proprietari;
    @XmlElementRef(name = "CodiceLivello", namespace = "http://cooperazione.sian.it/schema/fascicolo", type = JAXBElement.class, required = false)
    protected JAXBElement<String> codiceLivello;
    @XmlElement(name = "CodiceOccupazioneSuolo", required = true)
    protected String codiceOccupazioneSuolo;
    @XmlElement(name = "CodiceDestinazioneUso", required = true)
    protected String codiceDestinazioneUso;
    @XmlElement(name = "CodiceUso", required = true)
    protected String codiceUso;
    @XmlElement(name = "CodiceQualita", required = true)
    protected String codiceQualita;
    @XmlElementRef(name = "CodiceOccupazioneVarieta", namespace = "http://cooperazione.sian.it/schema/fascicolo", type = JAXBElement.class, required = false)
    protected JAXBElement<String> codiceOccupazioneVarieta;

    /**
     * Gets the value of the cuaa property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCUAA() {
        return cuaa;
    }

    /**
     * Sets the value of the cuaa property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCUAA(String value) {
        this.cuaa = value;
    }

    /**
     * Gets the value of the provincia property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProvincia() {
        return provincia;
    }

    /**
     * Sets the value of the provincia property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProvincia(String value) {
        this.provincia = value;
    }

    /**
     * Gets the value of the comune property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getComune() {
        return comune;
    }

    /**
     * Sets the value of the comune property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setComune(String value) {
        this.comune = value;
    }

    /**
     * Gets the value of the sezione property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSezione() {
        return sezione;
    }

    /**
     * Sets the value of the sezione property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSezione(String value) {
        this.sezione = value;
    }

    /**
     * Gets the value of the foglio property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFoglio() {
        return foglio;
    }

    /**
     * Sets the value of the foglio property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFoglio(String value) {
        this.foglio = value;
    }

    /**
     * Gets the value of the particella property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getParticella() {
        return particella;
    }

    /**
     * Sets the value of the particella property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setParticella(String value) {
        this.particella = value;
    }

    /**
     * Gets the value of the subalterno property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSubalterno() {
        return subalterno;
    }

    /**
     * Sets the value of the subalterno property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSubalterno(String value) {
        this.subalterno = value;
    }

    /**
     * Gets the value of the tipo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTipo() {
        return tipo;
    }

    /**
     * Sets the value of the tipo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTipo(String value) {
        this.tipo = value;
    }

    /**
     * Gets the value of the destinazione property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDestinazione() {
        return destinazione;
    }

    /**
     * Sets the value of the destinazione property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDestinazione(String value) {
        this.destinazione = value;
    }

    /**
     * Gets the value of the casiParticolari property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getCasiParticolari() {
        return casiParticolari;
    }

    /**
     * Sets the value of the casiParticolari property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setCasiParticolari(JAXBElement<String> value) {
        this.casiParticolari = value;
    }

    /**
     * Gets the value of the superficieCoperta property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSuperficieCoperta() {
        return superficieCoperta;
    }

    /**
     * Sets the value of the superficieCoperta property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSuperficieCoperta(String value) {
        this.superficieCoperta = value;
    }

    /**
     * Gets the value of the superficieScoperta property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSuperficieScoperta() {
        return superficieScoperta;
    }

    /**
     * Sets the value of the superficieScoperta property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSuperficieScoperta(String value) {
        this.superficieScoperta = value;
    }

    /**
     * Gets the value of the volume property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getVolume() {
        return volume;
    }

    /**
     * Sets the value of the volume property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setVolume(String value) {
        this.volume = value;
    }

    /**
     * Gets the value of the numeroPosti property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNumeroPosti() {
        return numeroPosti;
    }

    /**
     * Sets the value of the numeroPosti property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNumeroPosti(String value) {
        this.numeroPosti = value;
    }

    /**
     * Gets the value of the tipoConduzione property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTipoConduzione() {
        return tipoConduzione;
    }

    /**
     * Sets the value of the tipoConduzione property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTipoConduzione(String value) {
        this.tipoConduzione = value;
    }

    /**
     * Gets the value of the dataInizioConduzione property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDataInizioConduzione() {
        return dataInizioConduzione;
    }

    /**
     * Sets the value of the dataInizioConduzione property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDataInizioConduzione(String value) {
        this.dataInizioConduzione = value;
    }

    /**
     * Gets the value of the dataFineConduzione property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDataFineConduzione() {
        return dataFineConduzione;
    }

    /**
     * Sets the value of the dataFineConduzione property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDataFineConduzione(String value) {
        this.dataFineConduzione = value;
    }

    /**
     * Gets the value of the uso property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the Jakarta XML Binding object.
     * This is why there is not a <CODE>set</CODE> method for the uso property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getUso().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ISWSUtilizzoFabbricato }
     * 
     * 
     */
    public List<ISWSUtilizzoFabbricato> getUso() {
        if (uso == null) {
            uso = new ArrayList<ISWSUtilizzoFabbricato>();
        }
        return this.uso;
    }

    /**
     * Gets the value of the proprietari property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the Jakarta XML Binding object.
     * This is why there is not a <CODE>set</CODE> method for the proprietari property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getProprietari().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ISWSProprietario }
     * 
     * 
     */
    public List<ISWSProprietario> getProprietari() {
        if (proprietari == null) {
            proprietari = new ArrayList<ISWSProprietario>();
        }
        return this.proprietari;
    }

    /**
     * Gets the value of the codiceLivello property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getCodiceLivello() {
        return codiceLivello;
    }

    /**
     * Sets the value of the codiceLivello property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setCodiceLivello(JAXBElement<String> value) {
        this.codiceLivello = value;
    }

    /**
     * Gets the value of the codiceOccupazioneSuolo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodiceOccupazioneSuolo() {
        return codiceOccupazioneSuolo;
    }

    /**
     * Sets the value of the codiceOccupazioneSuolo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodiceOccupazioneSuolo(String value) {
        this.codiceOccupazioneSuolo = value;
    }

    /**
     * Gets the value of the codiceDestinazioneUso property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodiceDestinazioneUso() {
        return codiceDestinazioneUso;
    }

    /**
     * Sets the value of the codiceDestinazioneUso property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodiceDestinazioneUso(String value) {
        this.codiceDestinazioneUso = value;
    }

    /**
     * Gets the value of the codiceUso property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodiceUso() {
        return codiceUso;
    }

    /**
     * Sets the value of the codiceUso property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodiceUso(String value) {
        this.codiceUso = value;
    }

    /**
     * Gets the value of the codiceQualita property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodiceQualita() {
        return codiceQualita;
    }

    /**
     * Sets the value of the codiceQualita property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodiceQualita(String value) {
        this.codiceQualita = value;
    }

    /**
     * Gets the value of the codiceOccupazioneVarieta property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getCodiceOccupazioneVarieta() {
        return codiceOccupazioneVarieta;
    }

    /**
     * Sets the value of the codiceOccupazioneVarieta property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setCodiceOccupazioneVarieta(JAXBElement<String> value) {
        this.codiceOccupazioneVarieta = value;
    }

}
