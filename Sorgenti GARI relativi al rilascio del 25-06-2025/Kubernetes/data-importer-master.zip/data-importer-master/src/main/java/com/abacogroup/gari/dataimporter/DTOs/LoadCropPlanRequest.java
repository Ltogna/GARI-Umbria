package com.abacogroup.gari.dataimporter.DTOs;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.List;

public class LoadCropPlanRequest {

    @JsonProperty("farmDescription")
    private String farmDescription;

    @JsonProperty("countryNotebookName")
    private String countryNotebookName;

    @JsonProperty("countryNotebookDesc")
    private String countryNotebookDesc;

    @JsonProperty("campaingYear")
    private int campaignYear;

    @JsonProperty("farmingEvents")
    private List<FarmingEvent> farmingEvents;

    @JsonProperty("phytochemicalTreatments")
    private List<PhytochemicalTreatment> phytochemicalTreatments;

    @JsonProperty("chemicalFertilizations")
    private List<ChemicalFertilization> chemicalFertilizations;

    @JsonProperty("organicFertilizations")
    private List<OrganicFertilization> organicFertilizations;

    @JsonProperty("growthStages")
    private List<GrowthStage> growthStages;

    @JsonProperty("irrigations")
    private List<Irrigation> irrigations;

    @JsonProperty("plotDescriptions")
    private List<PlotDescription> plotDescriptions;

    @JsonProperty("seedTreatments")
    private List<SeedTreatment> seedTreatments;

    @JsonProperty("productTreatments")
    private List<ProductTreatment> productTreatments;

    @JsonProperty("equipmentList")
    private List<Equipment> equipmentList;

    @JsonProperty("workers")
    private List<Worker> workers;

    public static class ChemicalFertilization {

        @JsonProperty("pcgId")
        private String pcgId;

        @JsonProperty("codiBarrScheVali")
        private String codiBarrScheVali;

        @JsonProperty("islandId")
        private String islandId;

        @JsonProperty("plotId")
        private String plotId;

        @JsonProperty("plantationId")
        private String plantationId;

        @JsonProperty("startDate")
        private String startDate;

        @JsonProperty("endDate")
        private String endDate;

        @JsonProperty("productRegistrationNumber")
        private String productRegistrationNumber;

        @JsonProperty("productQuantity")
        private Integer productQuantity; // Made Integer to allow null values

        @JsonProperty("productMeasureUnit")
        private String productMeasureUnit;

        @JsonProperty("areaQuantity")
        private String areaQuantity;

        @JsonProperty("actionArea")
        private Integer actionArea; // Made Integer to allow null values

        @JsonProperty("applicationTypeCode")
        private String applicationTypeCode;

        @JsonProperty("planting")
        private Boolean planting;

        @JsonProperty("productTaxonomyId")
        private Integer productTaxonomyId; // Made Integer to allow null values

        // No-argument constructor
        public ChemicalFertilization() {
        }

        // Getters for all fields
        public String getPcgId() { return pcgId; }
        public String getCodiBarrScheVali() { return codiBarrScheVali; }
        public String getIslandId() { return islandId; }
        public String getPlotId() { return plotId; }
        public String getPlantationId() { return plantationId; }
        public String getStartDate() { return startDate; }
        public String getEndDate() { return endDate; }
        public String getProductRegistrationNumber() { return productRegistrationNumber; }
        public Integer getProductQuantity() { return productQuantity; }
        public String getProductMeasureUnit() { return productMeasureUnit; }
        public String getAreaQuantity() { return areaQuantity; }
        public Integer getActionArea() { return actionArea; }
        public String getApplicationTypeCode() { return applicationTypeCode; }
        public Boolean getPlanting() { return planting; }
        public Integer getProductTaxonomyId() { return productTaxonomyId; }
    }

    public static class OrganicFertilization {

        @JsonProperty("pcgId")
        private String pcgId;

        @JsonProperty("codiBarrScheVali")
        private String codiBarrScheVali;

        @JsonProperty("islandId")
        private String islandId;

        @JsonProperty("plotId")
        private String plotId;

        @JsonProperty("plantationId")
        private String plantationId;

        @JsonProperty("startDate")
        private String startDate;

        @JsonProperty("endDate")
        private String endDate;

        @JsonProperty("productQuantity")
        private Integer productQuantity; // Made Integer to allow null values

        @JsonProperty("productMeasureUnit")
        private String productMeasureUnit;

        @JsonProperty("actionArea")
        private Integer actionArea; // Made Integer to allow null values

        @JsonProperty("applicationTypeCode")
        private String applicationTypeCode;

        @JsonProperty("productTaxonomyId")
        private Integer productTaxonomyId; // Made Integer to allow null values

        @JsonProperty("nitrogenPerMil")
        private Integer nitrogenPerMil; // Made Integer to allow null values

        @JsonProperty("phosphorusPerMil")
        private Integer phosphorusPerMil; // Made Integer to allow null values

        @JsonProperty("potassiumPerMil")
        private Integer potassiumPerMil; // Made Integer to allow null values

        @JsonProperty("npkCoefficient")
        private Integer npkCoefficient; // Made Integer to allow null values

        @JsonProperty("dryMatter")
        private Integer dryMatter; // Made Integer to allow null values

        // No-argument constructor
        public OrganicFertilization() {
        }

        // Getters for all fields
        public String getPcgId() { return pcgId; }
        public String getCodiBarrScheVali() { return codiBarrScheVali; }
        public String getIslandId() { return islandId; }
        public String getPlotId() { return plotId; }
        public String getPlantationId() { return plantationId; }
        public String getStartDate() { return startDate; }
        public String getEndDate() { return endDate; }
        public Integer getProductQuantity() { return productQuantity; }
        public String getProductMeasureUnit() { return productMeasureUnit; }
        public Integer getActionArea() { return actionArea; }
        public String getApplicationTypeCode() { return applicationTypeCode; }
        public Integer getProductTaxonomyId() { return productTaxonomyId; }
        public Integer getNitrogenPerMil() { return nitrogenPerMil; }
        public Integer getPhosphorusPerMil() { return phosphorusPerMil; }
        public Integer getPotassiumPerMil() { return potassiumPerMil; }
        public Integer getNpkCoefficient() { return npkCoefficient; }
        public Integer getDryMatter() { return dryMatter; }
    }

    public static class GrowthStage {

        @JsonProperty("pcgId")
        private String pcgId;

        @JsonProperty("codiBarrScheVali")
        private String codiBarrScheVali;

        @JsonProperty("islandId")
        private String islandId;

        @JsonProperty("plotId")
        private String plotId;

        @JsonProperty("plantationId")
        private String plantationId;

        @JsonProperty("bbch0StartDate")
        private String bbch0StartDate;

        @JsonProperty("bbch0EndDate")
        private String bbch0EndDate;

        @JsonProperty("bbch1StartDate")
        private String bbch1StartDate;

        @JsonProperty("bbch1EndDate")
        private String bbch1EndDate;

        @JsonProperty("bbch2StartDate")
        private String bbch2StartDate;

        @JsonProperty("bbch2EndDate")
        private String bbch2EndDate;

        @JsonProperty("bbch3StartDate")
        private String bbch3StartDate;

        @JsonProperty("bbch3EndDate")
        private String bbch3EndDate;

        @JsonProperty("bbch4StartDate")
        private String bbch4StartDate;

        @JsonProperty("bbch4EndDate")
        private String bbch4EndDate;

        @JsonProperty("bbch5StartDate")
        private String bbch5StartDate;

        @JsonProperty("bbch5EndDate")
        private String bbch5EndDate;

        @JsonProperty("bbch6StartDate")
        private String bbch6StartDate;

        @JsonProperty("bbch6EndDate")
        private String bbch6EndDate;

        @JsonProperty("bbch7StartDate")
        private String bbch7StartDate;

        @JsonProperty("bbch7EndDate")
        private String bbch7EndDate;

        @JsonProperty("bbch8StartDate")
        private String bbch8StartDate;

        @JsonProperty("bbch8EndDate")
        private String bbch8EndDate;

        @JsonProperty("bbch9StartDate")
        private String bbch9StartDate;

        @JsonProperty("bbch9EndDate")
        private String bbch9EndDate;

        // No-argument constructor
        public GrowthStage() {
        }

        // Getters for all fields
        public String getPcgId() { return pcgId; }
        public String getCodiBarrScheVali() { return codiBarrScheVali; }
        public String getIslandId() { return islandId; }
        public String getPlotId() { return plotId; }
        public String getPlantationId() { return plantationId; }
        public String getBbch0StartDate() { return bbch0StartDate; }
        public String getBbch0EndDate() { return bbch0EndDate; }
        public String getBbch1StartDate() { return bbch1StartDate; }
        public String getBbch1EndDate() { return bbch1EndDate; }
        public String getBbch2StartDate() { return bbch2StartDate; }
        public String getBbch2EndDate() { return bbch2EndDate; }
        public String getBbch3StartDate() { return bbch3StartDate; }
        public String getBbch3EndDate() { return bbch3EndDate; }
        public String getBbch4StartDate() { return bbch4StartDate; }
        public String getBbch4EndDate() { return bbch4EndDate; }
        public String getBbch5StartDate() { return bbch5StartDate; }
        public String getBbch5EndDate() { return bbch5EndDate; }
        public String getBbch6StartDate() { return bbch6StartDate; }
        public String getBbch6EndDate() { return bbch6EndDate; }
        public String getBbch7StartDate() { return bbch7StartDate; }
        public String getBbch7EndDate() { return bbch7EndDate; }
        public String getBbch8StartDate() { return bbch8StartDate; }
        public String getBbch8EndDate() { return bbch8EndDate; }
        public String getBbch9StartDate() { return bbch9StartDate; }
        public String getBbch9EndDate() { return bbch9EndDate; }
    }

    public static class Irrigation {

        @JsonProperty("pcgId")
        private String pcgId;

        @JsonProperty("codiBarrScheVali")
        private String codiBarrScheVali;

        @JsonProperty("islandId")
        private String islandId;

        @JsonProperty("plotId")
        private String plotId;

        @JsonProperty("plantationId")
        private String plantationId;

        @JsonProperty("eventDate")
        private String eventDate;

        @JsonProperty("quantity")
        private Integer quantity; // Made Integer to allow null values

        @JsonProperty("actionArea")
        private Integer actionArea; // Made Integer to allow null values

        @JsonProperty("applicationTypeCode")
        private String applicationTypeCode;

        @JsonProperty("fertigation")
        private Boolean fertigation;

        // No-argument constructor
        public Irrigation() {
        }

        // Getters for all fields
        public String getPcgId() { return pcgId; }
        public String getCodiBarrScheVali() { return codiBarrScheVali; }
        public String getIslandId() { return islandId; }
        public String getPlotId() { return plotId; }
        public String getPlantationId() { return plantationId; }
        public String getEventDate() { return eventDate; }
        public Integer getQuantity() { return quantity; }
        public Integer getActionArea() { return actionArea; }
        public String getApplicationTypeCode() { return applicationTypeCode; }
        public Boolean getFertigation() { return fertigation; }
    }

    public static class PlotDescription {

        @JsonProperty("islandId")
        private String islandId;

        @JsonProperty("plotId")
        private String plotId;

        @JsonProperty("plotDescription")
        private String plotDescription;

        // No-argument constructor
        public PlotDescription() {
        }

        // Getters for all fields
        public String getIslandId() { return islandId; }
        public String getPlotId() { return plotId; }
        public String getPlotDescription() { return plotDescription; }
    }

    public static class SeedTreatment {

        @JsonProperty("address")
        private String address;

        @JsonProperty("municipality")
        private String municipality;

        @JsonProperty("foglio")
        private String foglio;

        @JsonProperty("particella")
        private String particella;

        @JsonProperty("subalterno")
        private String subalterno;

        @JsonProperty("georeferencing")
        private String georeferencing;

        @JsonProperty("capacity")
        private Integer capacity; // Made Integer to allow null values

        @JsonProperty("seedType")
        private String seedType;

        @JsonProperty("eventDate")
        private String eventDate;

        @JsonProperty("productRegistrationNumber")
        private String productRegistrationNumber;

        @JsonProperty("quantity")
        private Integer quantity; // Made Integer to allow null values

        @JsonProperty("measureUnit")
        private String measureUnit;

        @JsonProperty("seedQuantity")
        private Integer seedQuantity; // Made Integer to allow null values

        @JsonProperty("seedMeasureUnit")
        private String seedMeasureUnit;

        @JsonProperty("adversityName")
        private String adversityName;

        @JsonProperty("workers")
        private List<Worker> workers;

        // No-argument constructor
        public SeedTreatment() {
        }

        // Getters for all fields
        public String getAddress() { return address; }
        public String getMunicipality() { return municipality; }
        public String getFoglio() { return foglio; }
        public String getParticella() { return particella; }
        public String getSubalterno() { return subalterno; }
        public String getGeoreferencing() { return georeferencing; }
        public Integer getCapacity() { return capacity; }
        public String getSeedType() { return seedType; }
        public String getEventDate() { return eventDate; }
        public String getProductRegistrationNumber() { return productRegistrationNumber; }
        public Integer getQuantity() { return quantity; }
        public String getMeasureUnit() { return measureUnit; }
        public Integer getSeedQuantity() { return seedQuantity; }
        public String getSeedMeasureUnit() { return seedMeasureUnit; }
        public String getAdversityName() { return adversityName; }
        public List<Worker> getWorkers() { return workers; }
    }



    public static class ProductTreatment {

        @JsonProperty("address")
        private String address;

        @JsonProperty("municipality")
        private String municipality;

        @JsonProperty("foglio")
        private String foglio;

        @JsonProperty("particella")
        private String particella;

        @JsonProperty("subalterno")
        private String subalterno;

        @JsonProperty("georeferencing")
        private String georeferencing;

        @JsonProperty("capacity")
        private Integer capacity; // Made Integer to allow null values

        @JsonProperty("agriculturalCommodity")
        private String agriculturalCommodity;

        @JsonProperty("eventDate")
        private String eventDate;

        @JsonProperty("productRegistrationNumber")
        private String productRegistrationNumber;

        @JsonProperty("quantity")
        private Integer quantity; // Made Integer to allow null values

        @JsonProperty("measureUnit")
        private String measureUnit;

        @JsonProperty("targetProductQuantity")
        private Integer targetProductQuantity; // Made Integer to allow null values

        @JsonProperty("targetProductMeasureUnit")
        private String targetProductMeasureUnit;

        @JsonProperty("treatmentApplicationMode")
        private String treatmentApplicationMode;

        @JsonProperty("adversityName")
        private String adversityName;

        @JsonProperty("workers")
        private List<Worker> workers;

        @JsonProperty("equipment")
        private List<Equipment> equipment;

        // No-argument constructor
        public ProductTreatment() {
        }

        // Getters for all fields
        public String getAddress() {
            return address;
        }

        public String getMunicipality() {
            return municipality;
        }

        public String getFoglio() {
            return foglio;
        }

        public String getParticella() {
            return particella;
        }

        public String getSubalterno() {
            return subalterno;
        }

        public String getGeoreferencing() {
            return georeferencing;
        }

        public Integer getCapacity() {
            return capacity;
        }

        public String getAgriculturalCommodity() {
            return agriculturalCommodity;
        }

        public String getEventDate() {
            return eventDate;
        }

        public String getProductRegistrationNumber() {
            return productRegistrationNumber;
        }

        public Integer getQuantity() {
            return quantity;
        }

        public String getMeasureUnit() {
            return measureUnit;
        }

        public Integer getTargetProductQuantity() {
            return targetProductQuantity;
        }

        public String getTargetProductMeasureUnit() {
            return targetProductMeasureUnit;
        }

        public String getTreatmentApplicationMode() {
            return treatmentApplicationMode;
        }

        public String getAdversityName() {
            return adversityName;
        }

        public List<Worker> getWorkers() {
            return workers;
        }

        public List<Equipment> getEquipment() {
            return equipment;
        }
    }

    public static class Equipment {

        @JsonProperty("calibrationId")
        private String calibrationId;

        @JsonProperty("lastCheckDate")
        private String lastCheckDate;

        @JsonProperty("description")
        private String description;

        // No-argument constructor
        public Equipment() {
        }

        // Getters for all fields
        public String getCalibrationId() {
            return calibrationId;
        }

        public String getLastCheckDate() {
            return lastCheckDate;
        }

        public String getDescription() {
            return description;
        }
    }

    public static class Worker {

        @JsonProperty("workerType")
        private String workerType;

        @JsonProperty("workerName")
        private String workerName;

        @JsonProperty("workerSurname")
        private String workerSurname;

        @JsonProperty("fiscalCode")
        private String fiscalCode;

        @JsonProperty("companyName")
        private String companyName;

        @JsonProperty("vatNumber")
        private String vatNumber;

        @JsonProperty("licenseNumber")
        private String licenseNumber;

        @JsonProperty("licenseReleaseDate")
        private String licenseReleaseDate;

        @JsonProperty("licenseExpirationDate")
        private String licenseExpirationDate;

        // No-argument constructor
        public Worker() {
        }

        // Getters for all fields
        public String getWorkerType() {
            return workerType;
        }

        public String getWorkerName() {
            return workerName;
        }

        public String getWorkerSurname() {
            return workerSurname;
        }

        public String getFiscalCode() {
            return fiscalCode;
        }

        public String getCompanyName() {
            return companyName;
        }

        public String getVatNumber() {
            return vatNumber;
        }

        public String getLicenseNumber() {
            return licenseNumber;
        }

        public String getLicenseReleaseDate() {
            return licenseReleaseDate;
        }

        public String getLicenseExpirationDate() {
            return licenseExpirationDate;
        }
    }





        // Nested Classes with Getters and Setters
        public static class FarmingEvent {

            @JsonProperty("pcgId")
            private String pcgId;

            @JsonProperty("codiBarrScheVali")
            private String codiBarrScheVali;

            @JsonProperty("islandId")
            private String islandId;

            @JsonProperty("plotId")
            private String plotId;

            @JsonProperty("plantationId")
            private String plantationId;

            @JsonProperty("farmingPhase")
            private String farmingPhase;

            @JsonProperty("startDate")
            private String startDate;

            @JsonProperty("endDate")
            private String endDate;

            // No-argument constructor
            public FarmingEvent() {
            }

            // Getters for all fields
            public String getPcgId() {
                return pcgId;
            }

            public String getCodiBarrScheVali() {
                return codiBarrScheVali;
            }

            public String getIslandId() {
                return islandId;
            }

            public String getPlotId() {
                return plotId;
            }

            public String getPlantationId() {
                return plantationId;
            }

            public String getFarmingPhase() {
                return farmingPhase;
            }

            public String getStartDate() {
                return startDate;
            }

            public String getEndDate() {
                return endDate;
            }
        }



    public static class PhytochemicalTreatment {

        @JsonProperty("pcgId")
        private String pcgId;

        @JsonProperty("codiBarrScheVali")
        private String codiBarrScheVali;

        @JsonProperty("islandId")
        private String islandId;

        @JsonProperty("plotId")
        private String plotId;

        @JsonProperty("plantationId")
        private String plantationId;

        @JsonProperty("startDate")
        private String startDate;

        @JsonProperty("endDate")
        private String endDate;

        @JsonProperty("productRegistrationNumber")
        private String productRegistrationNumber;

        @JsonProperty("productQuantity")
        private int productQuantity;

        @JsonProperty("productMeasureUnit")
        private String productMeasureUnit;

        @JsonProperty("waterQuantity")
        private int waterQuantity;

        @JsonProperty("actionArea")
        private int actionArea;

        @JsonProperty("treatmentApplicationMode")
        private String treatmentApplicationMode;

        @JsonProperty("applicationTypeCode")
        private String applicationTypeCode;

        @JsonProperty("adversityName")
        private String adversityName;

        @JsonProperty("workers")
        private List<Worker> workers;

        @JsonProperty("equipment")
        private List<Equipment> equipment;

        // No-argument constructor
        public PhytochemicalTreatment() {
        }

        // Getters for all fields

        public String getPcgId() {
            return pcgId;
        }

        public String getCodiBarrScheVali() {
            return codiBarrScheVali;
        }

        public String getIslandId() {
            return islandId;
        }

        public String getPlotId() {
            return plotId;
        }

        public String getPlantationId() {
            return plantationId;
        }

        public String getStartDate() {
            return startDate;
        }

        public String getEndDate() {
            return endDate;
        }

        public String getProductRegistrationNumber() {
            return productRegistrationNumber;
        }

        public int getProductQuantity() {
            return productQuantity;
        }

        public String getProductMeasureUnit() {
            return productMeasureUnit;
        }

        public int getWaterQuantity() {
            return waterQuantity;
        }

        public int getActionArea() {
            return actionArea;
        }

        public String getTreatmentApplicationMode() {
            return treatmentApplicationMode;
        }

        public String getApplicationTypeCode() {
            return applicationTypeCode;
        }

        public String getAdversityName() {
            return adversityName;
        }

        public List<Worker> getWorkers() {
            return workers;
        }

        public List<Equipment> getEquipment() {
            return equipment;
        }
    }

}