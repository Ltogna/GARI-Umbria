package com.abacogroup.gari.dataimporter.DTOs;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.OffsetDateTime;
import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class DossierTransitionLogDTO {

	@JsonProperty("id")
	private Long id;

	@JsonProperty("startDate")
	private OffsetDateTime startDate;

	@JsonProperty("endDate")
	private OffsetDateTime endDate;

	@JsonProperty("userId")
	private String userId;

	@JsonProperty("processId")
	private Long processId;

	@JsonProperty("transitionId")
	private Long transitionId;

	@JsonProperty("notes")
	private String notes;

	@JsonProperty("failed")
	private Boolean failed;

	@JsonProperty("description")
	private String description;

	@JsonProperty("fromNode")
	private String fromNode;

	@JsonProperty("fromNodeDescription")
	private String fromNodeDescription;

	@JsonProperty("toNode")
	private String toNode;

	@JsonProperty("toNodeDescription")
	private String toNodeDescription;

	@JsonProperty("messages")
	private List<DossierTransitionMessageDTO> messages;
}
