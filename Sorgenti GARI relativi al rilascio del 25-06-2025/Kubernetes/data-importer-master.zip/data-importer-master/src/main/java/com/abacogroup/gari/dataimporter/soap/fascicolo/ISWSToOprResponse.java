
package com.abacogroup.gari.dataimporter.soap.fascicolo;

import java.util.ArrayList;
import java.util.List;
import jakarta.xml.bind.JAXBElement;
import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlElementRef;
import jakarta.xml.bind.annotation.XmlRootElement;
import jakarta.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element ref="{http://cooperazione.sian.it/schema/fascicolo}ISWSResponse"/&gt;
 *         &lt;choice&gt;
 *           &lt;element name="risposta0" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *           &lt;element name="risposta3" type="{http://cooperazione.sian.it/schema/fascicolo}ISWSSegnalazione" maxOccurs="unbounded" minOccurs="0"/&gt;
 *           &lt;element name="risposta6" type="{http://cooperazione.sian.it/schema/fascicolo}ISWSLavoro" maxOccurs="unbounded" minOccurs="0"/&gt;
 *           &lt;element name="risposta7" type="{http://cooperazione.sian.it/schema/fascicolo}ISWSMacchina" maxOccurs="unbounded" minOccurs="0"/&gt;
 *           &lt;element name="risposta8" type="{http://cooperazione.sian.it/schema/fascicolo}ISWSFabbricato" maxOccurs="unbounded" minOccurs="0"/&gt;
 *           &lt;element name="risposta12" type="{http://cooperazione.sian.it/schema/fascicolo}DettaglioSoggettoWS" minOccurs="0"/&gt;
 *           &lt;element name="risposta13" type="{http://cooperazione.sian.it/schema/fascicolo}Cuaa" maxOccurs="unbounded" minOccurs="0"/&gt;
 *           &lt;element name="risposta14" type="{http://cooperazione.sian.it/schema/fascicolo}ISWSContoCorrente" maxOccurs="unbounded" minOccurs="0"/&gt;
 *           &lt;element name="risposta15" type="{http://cooperazione.sian.it/schema/fascicolo}ISWSMandati" minOccurs="0"/&gt;
 *           &lt;element name="risposta19" type="{http://cooperazione.sian.it/schema/fascicolo}ISWSCUAAModificato" maxOccurs="unbounded" minOccurs="0"/&gt;
 *           &lt;element name="risposta20" type="{http://cooperazione.sian.it/schema/fascicolo}ISWSRespAnagFascicolo15" minOccurs="0"/&gt;
 *           &lt;element name="risposta21" type="{http://cooperazione.sian.it/schema/fascicolo}ISWSTerritorio15" maxOccurs="unbounded" minOccurs="0"/&gt;
 *           &lt;element name="risposta24" type="{http://cooperazione.sian.it/schema/fascicolo}ISWSAgricoltoreAttivoResp" minOccurs="0"/&gt;
 *           &lt;element name="risposta27" type="{http://cooperazione.sian.it/schema/fascicolo}ISWSAllevamento15" maxOccurs="unbounded" minOccurs="0"/&gt;
 *           &lt;element name="risposta28" type="{http://cooperazione.sian.it/schema/fascicolo}ISWSGiovaneAgricoltoreResp" minOccurs="0"/&gt;
 *           &lt;element name="risposta29" type="{http://cooperazione.sian.it/schema/fascicolo}ISWSTerritorioFS6" maxOccurs="unbounded" minOccurs="0"/&gt;
 *           &lt;element name="risposta30" type="{http://cooperazione.sian.it/schema/fascicolo}ISWSFabbricatoFS6" maxOccurs="unbounded" minOccurs="0"/&gt;
 *           &lt;element name="risposta31" type="{http://cooperazione.sian.it/schema/fascicolo}ISWSBaseAssoRTIResp" maxOccurs="unbounded" minOccurs="0"/&gt;
 *           &lt;element name="risposta32" type="{http://cooperazione.sian.it/schema/fascicolo}ISWSRespOA" maxOccurs="unbounded" minOccurs="0"/&gt;
 *           &lt;element name="risposta33" type="{http://cooperazione.sian.it/schema/fascicolo}ISWSRespOTE" maxOccurs="unbounded" minOccurs="0"/&gt;
 *           &lt;element name="risposta34" type="{http://cooperazione.sian.it/schema/fascicolo}ISWSAllevamento16" maxOccurs="unbounded" minOccurs="0"/&gt;
 *           &lt;element name="risposta35" type="{http://cooperazione.sian.it/schema/fascicolo}ISWSTerritorioFS7" maxOccurs="unbounded" minOccurs="0"/&gt;
 *           &lt;element name="risposta36" type="{http://cooperazione.sian.it/schema/fascicolo}ISWSRespSchede" maxOccurs="unbounded" minOccurs="0"/&gt;
 *           &lt;element name="risposta37" type="{http://cooperazione.sian.it/schema/fascicolo}ISWSScheda" minOccurs="0"/&gt;
 *           &lt;element name="risposta38" type="{http://cooperazione.sian.it/schema/fascicolo}ISWSDURC" minOccurs="0"/&gt;
 *         &lt;/choice&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "iswsResponse",
    "risposta0",
    "risposta3",
    "risposta6",
    "risposta7",
    "risposta8",
    "risposta12",
    "risposta13",
    "risposta14",
    "risposta15",
    "risposta19",
    "risposta20",
    "risposta21",
    "risposta24",
    "risposta27",
    "risposta28",
    "risposta29",
    "risposta30",
    "risposta31",
    "risposta32",
    "risposta33",
    "risposta34",
    "risposta35",
    "risposta36",
    "risposta37",
    "risposta38"
})
@XmlRootElement(name = "ISWSToOprResponse")
public class ISWSToOprResponse {

    @XmlElement(name = "ISWSResponse", required = true)
    protected ISWSResponse iswsResponse;
    @XmlElementRef(name = "risposta0", namespace = "http://cooperazione.sian.it/schema/fascicolo", type = JAXBElement.class, required = false)
    protected JAXBElement<String> risposta0;
    @XmlElement(nillable = true)
    protected List<ISWSSegnalazione> risposta3;
    @XmlElement(nillable = true)
    protected List<ISWSLavoro> risposta6;
    @XmlElement(nillable = true)
    protected List<ISWSMacchina> risposta7;
    @XmlElement(nillable = true)
    protected List<ISWSFabbricato> risposta8;
    @XmlElementRef(name = "risposta12", namespace = "http://cooperazione.sian.it/schema/fascicolo", type = JAXBElement.class, required = false)
    protected JAXBElement<DettaglioSoggettoWS> risposta12;
    @XmlElement(nillable = true)
    protected List<String> risposta13;
    @XmlElement(nillable = true)
    protected List<ISWSContoCorrente> risposta14;
    @XmlElementRef(name = "risposta15", namespace = "http://cooperazione.sian.it/schema/fascicolo", type = JAXBElement.class, required = false)
    protected JAXBElement<ISWSMandati> risposta15;
    @XmlElement(nillable = true)
    protected List<ISWSCUAAModificato> risposta19;
    @XmlElementRef(name = "risposta20", namespace = "http://cooperazione.sian.it/schema/fascicolo", type = JAXBElement.class, required = false)
    protected JAXBElement<ISWSRespAnagFascicolo15> risposta20;
    @XmlElement(nillable = true)
    protected List<ISWSTerritorio15> risposta21;
    @XmlElementRef(name = "risposta24", namespace = "http://cooperazione.sian.it/schema/fascicolo", type = JAXBElement.class, required = false)
    protected JAXBElement<ISWSAgricoltoreAttivoResp> risposta24;
    @XmlElement(nillable = true)
    protected List<ISWSAllevamento15> risposta27;
    @XmlElementRef(name = "risposta28", namespace = "http://cooperazione.sian.it/schema/fascicolo", type = JAXBElement.class, required = false)
    protected JAXBElement<ISWSGiovaneAgricoltoreResp> risposta28;
    @XmlElement(nillable = true)
    protected List<ISWSTerritorioFS6> risposta29;
    @XmlElement(nillable = true)
    protected List<ISWSFabbricatoFS6> risposta30;
    @XmlElement(nillable = true)
    protected List<ISWSBaseAssoRTIResp> risposta31;
    @XmlElement(nillable = true)
    protected List<ISWSRespOA> risposta32;
    @XmlElement(nillable = true)
    protected List<ISWSRespOTE> risposta33;
    @XmlElement(nillable = true)
    protected List<ISWSAllevamento16> risposta34;
    @XmlElement(nillable = true)
    protected List<ISWSTerritorioFS7> risposta35;
    @XmlElement(nillable = true)
    protected List<ISWSRespSchede> risposta36;
    @XmlElementRef(name = "risposta37", namespace = "http://cooperazione.sian.it/schema/fascicolo", type = JAXBElement.class, required = false)
    protected JAXBElement<ISWSScheda> risposta37;
    @XmlElementRef(name = "risposta38", namespace = "http://cooperazione.sian.it/schema/fascicolo", type = JAXBElement.class, required = false)
    protected JAXBElement<ISWSDURC> risposta38;

    /**
     * Gets the value of the iswsResponse property.
     * 
     * @return
     *     possible object is
     *     {@link ISWSResponse }
     *     
     */
    public ISWSResponse getISWSResponse() {
        return iswsResponse;
    }

    /**
     * Sets the value of the iswsResponse property.
     * 
     * @param value
     *     allowed object is
     *     {@link ISWSResponse }
     *     
     */
    public void setISWSResponse(ISWSResponse value) {
        this.iswsResponse = value;
    }

    /**
     * Gets the value of the risposta0 property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getRisposta0() {
        return risposta0;
    }

    /**
     * Sets the value of the risposta0 property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setRisposta0(JAXBElement<String> value) {
        this.risposta0 = value;
    }

    /**
     * Gets the value of the risposta3 property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the Jakarta XML Binding object.
     * This is why there is not a <CODE>set</CODE> method for the risposta3 property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getRisposta3().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ISWSSegnalazione }
     * 
     * 
     */
    public List<ISWSSegnalazione> getRisposta3() {
        if (risposta3 == null) {
            risposta3 = new ArrayList<ISWSSegnalazione>();
        }
        return this.risposta3;
    }

    /**
     * Gets the value of the risposta6 property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the Jakarta XML Binding object.
     * This is why there is not a <CODE>set</CODE> method for the risposta6 property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getRisposta6().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ISWSLavoro }
     * 
     * 
     */
    public List<ISWSLavoro> getRisposta6() {
        if (risposta6 == null) {
            risposta6 = new ArrayList<ISWSLavoro>();
        }
        return this.risposta6;
    }

    /**
     * Gets the value of the risposta7 property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the Jakarta XML Binding object.
     * This is why there is not a <CODE>set</CODE> method for the risposta7 property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getRisposta7().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ISWSMacchina }
     * 
     * 
     */
    public List<ISWSMacchina> getRisposta7() {
        if (risposta7 == null) {
            risposta7 = new ArrayList<ISWSMacchina>();
        }
        return this.risposta7;
    }

    /**
     * Gets the value of the risposta8 property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the Jakarta XML Binding object.
     * This is why there is not a <CODE>set</CODE> method for the risposta8 property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getRisposta8().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ISWSFabbricato }
     * 
     * 
     */
    public List<ISWSFabbricato> getRisposta8() {
        if (risposta8 == null) {
            risposta8 = new ArrayList<ISWSFabbricato>();
        }
        return this.risposta8;
    }

    /**
     * Gets the value of the risposta12 property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link DettaglioSoggettoWS }{@code >}
     *     
     */
    public JAXBElement<DettaglioSoggettoWS> getRisposta12() {
        return risposta12;
    }

    /**
     * Sets the value of the risposta12 property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link DettaglioSoggettoWS }{@code >}
     *     
     */
    public void setRisposta12(JAXBElement<DettaglioSoggettoWS> value) {
        this.risposta12 = value;
    }

    /**
     * Gets the value of the risposta13 property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the Jakarta XML Binding object.
     * This is why there is not a <CODE>set</CODE> method for the risposta13 property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getRisposta13().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link String }
     * 
     * 
     */
    public List<String> getRisposta13() {
        if (risposta13 == null) {
            risposta13 = new ArrayList<String>();
        }
        return this.risposta13;
    }

    /**
     * Gets the value of the risposta14 property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the Jakarta XML Binding object.
     * This is why there is not a <CODE>set</CODE> method for the risposta14 property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getRisposta14().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ISWSContoCorrente }
     * 
     * 
     */
    public List<ISWSContoCorrente> getRisposta14() {
        if (risposta14 == null) {
            risposta14 = new ArrayList<ISWSContoCorrente>();
        }
        return this.risposta14;
    }

    /**
     * Gets the value of the risposta15 property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link ISWSMandati }{@code >}
     *     
     */
    public JAXBElement<ISWSMandati> getRisposta15() {
        return risposta15;
    }

    /**
     * Sets the value of the risposta15 property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link ISWSMandati }{@code >}
     *     
     */
    public void setRisposta15(JAXBElement<ISWSMandati> value) {
        this.risposta15 = value;
    }

    /**
     * Gets the value of the risposta19 property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the Jakarta XML Binding object.
     * This is why there is not a <CODE>set</CODE> method for the risposta19 property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getRisposta19().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ISWSCUAAModificato }
     * 
     * 
     */
    public List<ISWSCUAAModificato> getRisposta19() {
        if (risposta19 == null) {
            risposta19 = new ArrayList<ISWSCUAAModificato>();
        }
        return this.risposta19;
    }

    /**
     * Gets the value of the risposta20 property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link ISWSRespAnagFascicolo15 }{@code >}
     *     
     */
    public JAXBElement<ISWSRespAnagFascicolo15> getRisposta20() {
        return risposta20;
    }

    /**
     * Sets the value of the risposta20 property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link ISWSRespAnagFascicolo15 }{@code >}
     *     
     */
    public void setRisposta20(JAXBElement<ISWSRespAnagFascicolo15> value) {
        this.risposta20 = value;
    }

    /**
     * Gets the value of the risposta21 property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the Jakarta XML Binding object.
     * This is why there is not a <CODE>set</CODE> method for the risposta21 property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getRisposta21().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ISWSTerritorio15 }
     * 
     * 
     */
    public List<ISWSTerritorio15> getRisposta21() {
        if (risposta21 == null) {
            risposta21 = new ArrayList<ISWSTerritorio15>();
        }
        return this.risposta21;
    }

    /**
     * Gets the value of the risposta24 property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link ISWSAgricoltoreAttivoResp }{@code >}
     *     
     */
    public JAXBElement<ISWSAgricoltoreAttivoResp> getRisposta24() {
        return risposta24;
    }

    /**
     * Sets the value of the risposta24 property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link ISWSAgricoltoreAttivoResp }{@code >}
     *     
     */
    public void setRisposta24(JAXBElement<ISWSAgricoltoreAttivoResp> value) {
        this.risposta24 = value;
    }

    /**
     * Gets the value of the risposta27 property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the Jakarta XML Binding object.
     * This is why there is not a <CODE>set</CODE> method for the risposta27 property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getRisposta27().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ISWSAllevamento15 }
     * 
     * 
     */
    public List<ISWSAllevamento15> getRisposta27() {
        if (risposta27 == null) {
            risposta27 = new ArrayList<ISWSAllevamento15>();
        }
        return this.risposta27;
    }

    /**
     * Gets the value of the risposta28 property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link ISWSGiovaneAgricoltoreResp }{@code >}
     *     
     */
    public JAXBElement<ISWSGiovaneAgricoltoreResp> getRisposta28() {
        return risposta28;
    }

    /**
     * Sets the value of the risposta28 property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link ISWSGiovaneAgricoltoreResp }{@code >}
     *     
     */
    public void setRisposta28(JAXBElement<ISWSGiovaneAgricoltoreResp> value) {
        this.risposta28 = value;
    }

    /**
     * Gets the value of the risposta29 property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the Jakarta XML Binding object.
     * This is why there is not a <CODE>set</CODE> method for the risposta29 property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getRisposta29().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ISWSTerritorioFS6 }
     * 
     * 
     */
    public List<ISWSTerritorioFS6> getRisposta29() {
        if (risposta29 == null) {
            risposta29 = new ArrayList<ISWSTerritorioFS6>();
        }
        return this.risposta29;
    }

    /**
     * Gets the value of the risposta30 property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the Jakarta XML Binding object.
     * This is why there is not a <CODE>set</CODE> method for the risposta30 property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getRisposta30().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ISWSFabbricatoFS6 }
     * 
     * 
     */
    public List<ISWSFabbricatoFS6> getRisposta30() {
        if (risposta30 == null) {
            risposta30 = new ArrayList<ISWSFabbricatoFS6>();
        }
        return this.risposta30;
    }

    /**
     * Gets the value of the risposta31 property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the Jakarta XML Binding object.
     * This is why there is not a <CODE>set</CODE> method for the risposta31 property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getRisposta31().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ISWSBaseAssoRTIResp }
     * 
     * 
     */
    public List<ISWSBaseAssoRTIResp> getRisposta31() {
        if (risposta31 == null) {
            risposta31 = new ArrayList<ISWSBaseAssoRTIResp>();
        }
        return this.risposta31;
    }

    /**
     * Gets the value of the risposta32 property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the Jakarta XML Binding object.
     * This is why there is not a <CODE>set</CODE> method for the risposta32 property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getRisposta32().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ISWSRespOA }
     * 
     * 
     */
    public List<ISWSRespOA> getRisposta32() {
        if (risposta32 == null) {
            risposta32 = new ArrayList<ISWSRespOA>();
        }
        return this.risposta32;
    }

    /**
     * Gets the value of the risposta33 property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the Jakarta XML Binding object.
     * This is why there is not a <CODE>set</CODE> method for the risposta33 property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getRisposta33().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ISWSRespOTE }
     * 
     * 
     */
    public List<ISWSRespOTE> getRisposta33() {
        if (risposta33 == null) {
            risposta33 = new ArrayList<ISWSRespOTE>();
        }
        return this.risposta33;
    }

    /**
     * Gets the value of the risposta34 property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the Jakarta XML Binding object.
     * This is why there is not a <CODE>set</CODE> method for the risposta34 property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getRisposta34().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ISWSAllevamento16 }
     * 
     * 
     */
    public List<ISWSAllevamento16> getRisposta34() {
        if (risposta34 == null) {
            risposta34 = new ArrayList<ISWSAllevamento16>();
        }
        return this.risposta34;
    }

    /**
     * Gets the value of the risposta35 property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the Jakarta XML Binding object.
     * This is why there is not a <CODE>set</CODE> method for the risposta35 property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getRisposta35().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ISWSTerritorioFS7 }
     * 
     * 
     */
    public List<ISWSTerritorioFS7> getRisposta35() {
        if (risposta35 == null) {
            risposta35 = new ArrayList<ISWSTerritorioFS7>();
        }
        return this.risposta35;
    }

    /**
     * Gets the value of the risposta36 property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the Jakarta XML Binding object.
     * This is why there is not a <CODE>set</CODE> method for the risposta36 property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getRisposta36().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ISWSRespSchede }
     * 
     * 
     */
    public List<ISWSRespSchede> getRisposta36() {
        if (risposta36 == null) {
            risposta36 = new ArrayList<ISWSRespSchede>();
        }
        return this.risposta36;
    }

    /**
     * Gets the value of the risposta37 property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link ISWSScheda }{@code >}
     *     
     */
    public JAXBElement<ISWSScheda> getRisposta37() {
        return risposta37;
    }

    /**
     * Sets the value of the risposta37 property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link ISWSScheda }{@code >}
     *     
     */
    public void setRisposta37(JAXBElement<ISWSScheda> value) {
        this.risposta37 = value;
    }

    /**
     * Gets the value of the risposta38 property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link ISWSDURC }{@code >}
     *     
     */
    public JAXBElement<ISWSDURC> getRisposta38() {
        return risposta38;
    }

    /**
     * Sets the value of the risposta38 property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link ISWSDURC }{@code >}
     *     
     */
    public void setRisposta38(JAXBElement<ISWSDURC> value) {
        this.risposta38 = value;
    }

}
