
package com.abacogroup.gari.dataimporter.soap.fascicolo;

import jakarta.xml.bind.JAXBElement;
import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlElementRef;
import jakarta.xml.bind.annotation.XmlRootElement;
import jakarta.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="CuaaSocio" type="{http://cooperazione.sian.it/schema/fascicolo}Cuaa"/&gt;
 *         &lt;element name="CuaaOrgAssociativo" type="{http://cooperazione.sian.it/schema/fascicolo}Cuaa"/&gt;
 *         &lt;element name="TipoLegameAsso" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "cuaaSocio",
    "cuaaOrgAssociativo",
    "tipoLegameAsso"
})
@XmlRootElement(name = "ISWSChiudiSocio")
public class ISWSChiudiSocio {

    @XmlElement(name = "CuaaSocio", required = true)
    protected String cuaaSocio;
    @XmlElement(name = "CuaaOrgAssociativo", required = true)
    protected String cuaaOrgAssociativo;
    @XmlElementRef(name = "TipoLegameAsso", namespace = "http://cooperazione.sian.it/schema/fascicolo", type = JAXBElement.class, required = false)
    protected JAXBElement<String> tipoLegameAsso;

    /**
     * Gets the value of the cuaaSocio property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCuaaSocio() {
        return cuaaSocio;
    }

    /**
     * Sets the value of the cuaaSocio property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCuaaSocio(String value) {
        this.cuaaSocio = value;
    }

    /**
     * Gets the value of the cuaaOrgAssociativo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCuaaOrgAssociativo() {
        return cuaaOrgAssociativo;
    }

    /**
     * Sets the value of the cuaaOrgAssociativo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCuaaOrgAssociativo(String value) {
        this.cuaaOrgAssociativo = value;
    }

    /**
     * Gets the value of the tipoLegameAsso property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getTipoLegameAsso() {
        return tipoLegameAsso;
    }

    /**
     * Sets the value of the tipoLegameAsso property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setTipoLegameAsso(JAXBElement<String> value) {
        this.tipoLegameAsso = value;
    }

}
