package com.abacogroup.gari.dataimporter.controllers;

import java.time.OffsetDateTime;
import java.util.List;

import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.embeddedqueue.WorkQueue;
import com.abacogroup.gari.dataimporter.services.BulkImportPartyLoadService;
import com.abacogroup.gari.dataimporter.services.ImportPartyRegistryService;
import com.abacogroup.partyregistry.dto.v1.ExternalSourceDtoV1;

import io.dropwizard.auth.Auth;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;

@Path("/{tenant}/public/v1/import-party-registry")
@Produces(MediaType.APPLICATION_JSON)
public class ImportPartyRegistryController {
	private final ImportPartyRegistryService importPartyRegistryService;
	private final WorkQueue<String> consumerWorkQueue;
	private final BulkImportPartyLoadService partyLoadService;

	public ImportPartyRegistryController(ImportPartyRegistryService importPartyRegistryService, BulkImportPartyLoadService partyLoadService,
			WorkQueue<String> consumerWorkQueue) {
		this.importPartyRegistryService = importPartyRegistryService;
		this.partyLoadService = partyLoadService;
		this.consumerWorkQueue = consumerWorkQueue;
	}

	@GET
	@Path("/{cuaa}")
	public ExternalSourceDtoV1 importParty(
			@Auth User user,
			@PathParam("tenant") String tenantId,
			@PathParam("cuaa") String cuaa) {
		return importPartyRegistryService.Import(tenantId, cuaa);
	}

	// Logic to start Job
	@POST
	@Path("/import")
	public void importParties(
			@Auth User user,
			List<String> cuaas,
			@PathParam("tenant") String tenantId) {

		int year = OffsetDateTime.now().getYear();
		long start = System.currentTimeMillis();

		String id;
		for (String cuaa : cuaas) {
			// TODO This is weak, the 2 actions should be in a transaction
			id = partyLoadService.createPartyBulkLoad(cuaa, tenantId, year);
			consumerWorkQueue.add(id, start++);
		}
	}
}
