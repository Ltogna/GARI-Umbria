
package com.abacogroup.gari.dataimporter.soap.fascicolo;

import java.util.ArrayList;
import java.util.List;
import jakarta.xml.bind.JAXBElement;
import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlElementRef;
import jakarta.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ISWSScheda complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ISWSScheda"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="ComposizioneTerritorio" type="{http://cooperazione.sian.it/schema/fascicolo}ISWSParticelleScheda" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="PianoColtivazione" type="{http://cooperazione.sian.it/schema/fascicolo}ISWSSuoloScheda" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="Riepilogo" type="{http://cooperazione.sian.it/schema/fascicolo}ISWSRiepilogoScheda" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ISWSScheda", propOrder = {
    "composizioneTerritorio",
    "pianoColtivazione",
    "riepilogo"
})
public class ISWSScheda {

    @XmlElement(name = "ComposizioneTerritorio", nillable = true)
    protected List<ISWSParticelleScheda> composizioneTerritorio;
    @XmlElement(name = "PianoColtivazione", nillable = true)
    protected List<ISWSSuoloScheda> pianoColtivazione;
    @XmlElementRef(name = "Riepilogo", namespace = "http://cooperazione.sian.it/schema/fascicolo", type = JAXBElement.class, required = false)
    protected JAXBElement<ISWSRiepilogoScheda> riepilogo;

    /**
     * Gets the value of the composizioneTerritorio property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the Jakarta XML Binding object.
     * This is why there is not a <CODE>set</CODE> method for the composizioneTerritorio property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getComposizioneTerritorio().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ISWSParticelleScheda }
     * 
     * 
     */
    public List<ISWSParticelleScheda> getComposizioneTerritorio() {
        if (composizioneTerritorio == null) {
            composizioneTerritorio = new ArrayList<ISWSParticelleScheda>();
        }
        return this.composizioneTerritorio;
    }

    /**
     * Gets the value of the pianoColtivazione property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the Jakarta XML Binding object.
     * This is why there is not a <CODE>set</CODE> method for the pianoColtivazione property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getPianoColtivazione().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ISWSSuoloScheda }
     * 
     * 
     */
    public List<ISWSSuoloScheda> getPianoColtivazione() {
        if (pianoColtivazione == null) {
            pianoColtivazione = new ArrayList<ISWSSuoloScheda>();
        }
        return this.pianoColtivazione;
    }

    /**
     * Gets the value of the riepilogo property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link ISWSRiepilogoScheda }{@code >}
     *     
     */
    public JAXBElement<ISWSRiepilogoScheda> getRiepilogo() {
        return riepilogo;
    }

    /**
     * Sets the value of the riepilogo property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link ISWSRiepilogoScheda }{@code >}
     *     
     */
    public void setRiepilogo(JAXBElement<ISWSRiepilogoScheda> value) {
        this.riepilogo = value;
    }

}
