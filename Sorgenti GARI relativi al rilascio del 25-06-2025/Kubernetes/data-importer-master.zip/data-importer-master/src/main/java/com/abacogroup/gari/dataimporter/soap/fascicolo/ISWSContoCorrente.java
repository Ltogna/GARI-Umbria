
package com.abacogroup.gari.dataimporter.soap.fascicolo;

import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ISWSContoCorrente complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ISWSContoCorrente"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="ContoCorrente"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;maxLength value="34"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="Codi_swift1"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;maxLength value="11"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="Codi_swift2"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;maxLength value="11"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="Data_fine" type="{http://cooperazione.sian.it/schema/fascicolo}Data"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ISWSContoCorrente", propOrder = {
    "contoCorrente",
    "codiSwift1",
    "codiSwift2",
    "dataFine"
})
public class ISWSContoCorrente {

    @XmlElement(name = "ContoCorrente", required = true)
    protected String contoCorrente;
    @XmlElement(name = "Codi_swift1", required = true, nillable = true)
    protected String codiSwift1;
    @XmlElement(name = "Codi_swift2", required = true, nillable = true)
    protected String codiSwift2;
    @XmlElement(name = "Data_fine", required = true, nillable = true)
    protected String dataFine;

    /**
     * Gets the value of the contoCorrente property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getContoCorrente() {
        return contoCorrente;
    }

    /**
     * Sets the value of the contoCorrente property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setContoCorrente(String value) {
        this.contoCorrente = value;
    }

    /**
     * Gets the value of the codiSwift1 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodiSwift1() {
        return codiSwift1;
    }

    /**
     * Sets the value of the codiSwift1 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodiSwift1(String value) {
        this.codiSwift1 = value;
    }

    /**
     * Gets the value of the codiSwift2 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodiSwift2() {
        return codiSwift2;
    }

    /**
     * Sets the value of the codiSwift2 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodiSwift2(String value) {
        this.codiSwift2 = value;
    }

    /**
     * Gets the value of the dataFine property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDataFine() {
        return dataFine;
    }

    /**
     * Sets the value of the dataFine property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDataFine(String value) {
        this.dataFine = value;
    }

}
