package com.abacogroup.gari.dataimporter;

import java.io.IOException;
import java.sql.DatabaseMetaData;
import java.util.concurrent.TimeoutException;

import com.abacogroup.gari.dataimporter.controllers.*;
import com.abacogroup.gari.dataimporter.db.dao.*;
import com.abacogroup.gari.dataimporter.queues.*;
import com.abacogroup.gari.dataimporter.queues.bulkimport_party.*;
import com.abacogroup.gari.dataimporter.services.*;

import org.apache.commons.lang3.StringUtils;
import org.jdbi.v3.core.Jdbi;
import org.jdbi.v3.sqlobject.SqlObjectPlugin;
import org.locationtech.jts.geom.Geometry;

import com.abacogroup.bundles.initializer.BundleInitServiceBuilder;
import com.abacogroup.dropwizard.auth.sso2.AuthUtils;
import com.abacogroup.dropwizard.auth.sso2.Sso2Client;
import com.abacogroup.dropwizard.auth.sso2.SsoAuthorizer;
import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.embeddedqueue.KeyedJob;
import com.abacogroup.embeddedqueue.ScheduledQueue;
import com.abacogroup.embeddedqueue.WorkQueue;
import com.abacogroup.embeddedqueue.db.JdbiRepository;
import com.abacogroup.gari.dataimporter.Interfaces.ICropPlanService;
import com.abacogroup.gari.dataimporter.config.BundleConfig;
import com.abacogroup.gari.dataimporter.config.RabbitMqConfig;
import com.abacogroup.gari.dataimporter.jackson.OffsetDateTimeProvider;
import com.abacogroup.gari.dataimporter.jackson.WKTGeometryDeserializer;
import com.abacogroup.gari.dataimporter.jackson.WKTGeometrySerializer;
import com.abacogroup.gari.dataimporter.utils.DevAuthenticator;
import com.abacogroup.gari.dataimporter.utils.DevAuthorizer;
import com.abacogroup.gari.dataimporter.utils.DevFilter;
import com.abacogroup.jaxrsutils.GenericCallerService;
import com.abacogroup.jaxrsutils.model.AbacoTechUser;
import com.abacogroup.jdbi.OraJdbiPlugin;
import com.abacogroup.jdbi.PgJdbiPlugin;
import com.abacogroup.jdbi.config.AbacoJdbiConfig;
import com.abacogroup.tracing.dropwizard.AbacoApplication;
import com.fasterxml.jackson.core.Version;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.databind.module.SimpleModule;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;

import io.dropwizard.auth.AuthValueFactoryProvider;
import io.dropwizard.client.JerseyClientBuilder;
import io.dropwizard.client.JerseyClientConfiguration;
import io.dropwizard.core.setup.Bootstrap;
import io.dropwizard.core.setup.Environment;
import io.dropwizard.db.DataSourceFactory;
import io.dropwizard.jdbi3.JdbiFactory;
import io.dropwizard.jdbi3.bundles.JdbiExceptionsBundle;
import io.dropwizard.migrations.MigrationsBundle;
import jakarta.ws.rs.client.Client;
import oracle.jdbc.driver.OracleConnection;

public class DataImporterApplication extends AbacoApplication<DataImporterConfiguration> {

	public static void main(String[] args) throws Exception {
		new DataImporterApplication().run(args);
	}

	@Override
	public void initialize(Bootstrap<DataImporterConfiguration> bootstrap) {
		bootstrap.addBundle(new JdbiExceptionsBundle());
		bootstrap.addBundle(new MigrationsBundle<>() {
			@Override
			public DataSourceFactory getDataSourceFactory(DataImporterConfiguration configuration) {
				return configuration.getDatabase();
			}
		});
		io.dropwizard.configuration.SubstitutingSourceProvider provider = new io.dropwizard.configuration.SubstitutingSourceProvider(
				bootstrap.getConfigurationSourceProvider(),
				new io.dropwizard.configuration.EnvironmentVariableSubstitutor(false));
		bootstrap.setConfigurationSourceProvider(provider);
	}

	@Override
	public void doRun(DataImporterConfiguration config, Environment environment) throws Exception {
		// health check
		// environment.healthChecks().register("basic", new BasicHealthCheck());
		configure(environment.getObjectMapper());
		final Jdbi jdbi = createJdbi(config, environment);

		// build http client
		JerseyClientConfiguration clientConfig = config.getJerseyClientConfiguration();
		final Client client = new JerseyClientBuilder(environment).using(clientConfig).build(getName());
		// SSO2 Client
		Sso2Client sso2Client = new Sso2Client(config.getSso2TokenSecretAuth(), client.target(config.getSso2Url()));
		registerAuthFilters(sso2Client, config, environment);

		// Import CropPlan
		LoggerDAO loggerDAO = jdbi.onDemand(LoggerDAO.class);
		PartyBulkLoadDAO partyBulkLoadDAO = jdbi.onDemand(PartyBulkLoadDAO.class);
		ZvnCatalogDAO znvDAO = jdbi.onDemand(ZvnCatalogDAO.class);

		NotificationsDAO notificationsDAO = jdbi.onDemand(NotificationsDAO.class);
		NotificationsDatesDAO notificationsDatesDAO = jdbi.onDemand(NotificationsDatesDAO.class);

		TrackRequestDAO trackRequestDAO = jdbi.onDemand(TrackRequestDAO.class);

		// rabbit
		Connection rabbitMQConnection = null;
		if (!"DISABLE".equals(config.getRabbitmqConfig().getHost())) {
			rabbitMQConnection = createRabbitmqConnection(config.getRabbitmqConfig());
			createBundleInfrastructure(rabbitMQConnection, jdbi, environment.getObjectMapper(), config.getBundleConfig());
		}

		// Services
		ICropPlanService cropPlanService = new CropPlanService(sso2Client, client, config, environment.getObjectMapper(), loggerDAO);

		TrackRequestService trackRequestService = new TrackRequestService(trackRequestDAO);
		var refreshMunicipalities = environment.lifecycle().scheduledExecutorService("refreshMunicipalities").build();
		ImportPartyRegistryService importPartyRegistryService = new ImportPartyRegistryService(sso2Client, client, config, environment.getObjectMapper(),
				loggerDAO, refreshMunicipalities);
		ImportZnvCatalogService importIntersectionService = new ImportZnvCatalogService(sso2Client, client, config, environment.getObjectMapper(),
				loggerDAO, znvDAO);
		ImportPartyCreditService importPartyCreditService = new ImportPartyCreditService(sso2Client, client, config, environment.getObjectMapper(), loggerDAO);
		GIASNotificationService giasnotification = new GIASNotificationService(sso2Client, environment.getObjectMapper(), loggerDAO, config, client,
				rabbitMQConnection, cropPlanService, notificationsDatesDAO, notificationsDAO, trackRequestService);
		@SuppressWarnings("unused")
		UpdatePartiesAclService updatePartiesAclService = new UpdatePartiesAclService(environment, config, sso2Client, client, jdbi, rabbitMQConnection);
		
		GIASUserService giasUserService = new GIASUserService(sso2Client, environment.getObjectMapper(), loggerDAO, config, client);
		
		/** TODO EC remove this comment to activate the "users synchronization to GIAS" part 
		GenericCallerService genericCallerService = new GenericCallerService(client, new AbacoTechUser());
		SSO2UserService ss2UserService = new SSO2UserService(genericCallerService, config.getSso2Url());
		@SuppressWarnings("unused") 
		GIASUsersSynchronizationService giasUsersSynchronizationService = 
				new GIASUsersSynchronizationService(environment, config, sso2Client, client, jdbi, rabbitMQConnection, giasUserService, ss2UserService, loggerDAO);
		*/
		
		WorkQueue<ImportJobService> cropPlanQueue = createImportCropPlanQueue(environment, jdbi, cropPlanService, trackRequestService);

		// Bulk Import Party
		BulkImportPartyLoadService partyLoadService = new BulkImportPartyLoadService(partyBulkLoadDAO);
		BulkImportPartyService bulkPartyService = new BulkImportPartyService(sso2Client, client, config, environment.getObjectMapper(), loggerDAO,
				partyLoadService, cropPlanService);
		WorkQueue<String> partyJobServiceWorkQueue = createBulkImportPartyQueue(environment, jdbi, bulkPartyService, partyLoadService,
				trackRequestService);

		// Dossier

		///

		WorkQueue<ImportJobService> partyCreditQueue = createImportPaymentMethodsQueue(environment, jdbi, trackRequestService, importPartyCreditService);
		createGiasNotificationQueues(config, environment, jdbi, giasnotification, notificationsDAO);

		WorkQueue<ImportZnvCatalogJobService> znvCatalogQueue = createImportZnvQueue(environment, jdbi, importIntersectionService, trackRequestService);
		// Controllers
		environment.jersey().register(new ImportIntersectionsController(znvCatalogQueue, trackRequestService));
		environment.jersey().register(new ImportCropPlanController(cropPlanQueue, trackRequestService));

		environment.jersey().register(new ImportPartyRegistryController(importPartyRegistryService, partyLoadService, partyJobServiceWorkQueue));

		environment.jersey().register(new ImportPartyCreditController(partyCreditQueue, trackRequestService));
		environment.jersey().register(new ImportPCGCropPlanController(cropPlanService));
		environment.jersey().register(new ImportAnagraficaController(cropPlanService));
		environment.jersey().register(new NotificationController(giasnotification));
		environment.jersey().register(new TrackRequestService(trackRequestDAO));
		environment.jersey().register(new OffsetDateTimeProvider());
		environment.jersey().register(new GiasController(giasUserService));
		environment.jersey().register(giasnotification);
	}

	private void createBundleInfrastructure(Connection rabbitMQConnection, Jdbi jdbi, ObjectMapper objectMapper, BundleConfig bundleConfig) {
		if (bundleConfig == null) {
			return;
		}

		if (rabbitMQConnection == null) {
			throw new IllegalStateException("Connection to RabbitMQ instance failed but needed");
		}

		try {
			BundleInitServiceBuilder.producer(rabbitMQConnection)
					.configLocation(bundleConfig.getConfigLocation())
					.build()
					.start();
		} catch (Exception e) {
			throw new IllegalStateException("Error starting rabbitmq producer", e);
		}
	}

	private void createGiasNotificationQueues(DataImporterConfiguration config, Environment environment, final Jdbi jdbi,
			GIASNotificationService giasnotification, NotificationsDAO notificationsDAO) {
		// Working
		NotificationsConsumer notificationsConsumer = new NotificationsConsumer(giasnotification, notificationsDAO);
		WorkQueue<String> workQueue = WorkQueue.builder("notify-gias", new JdbiRepository(jdbi), String.class)
				.withErrorListener(notificationsConsumer)
				.withConsumer(notificationsConsumer)
				.withMetricsRegistry(environment.metrics())
				.withNumThreads(4)
				.withTimeoutMs(60 * 60 * 1_000L)
				.build();
		workQueue.start();

		// Notification
		FireNotificationConsumer fireNotificationConsumer = new FireNotificationConsumer(workQueue, giasnotification);
		ScheduledQueue<String> notificationQueue = ScheduledQueue.builder("fire-notify-gias", new JdbiRepository(jdbi), String.class)
				.withConsumer(fireNotificationConsumer)
				.withMetricsRegistry(environment.metrics())
				.withNumThreads(1)
				.withTimeoutMs(60 * 60 * 1_000L)
				.build();
		notificationQueue.start();
		notificationQueue.addIfNotPresent(new KeyedJob<>("fire-notify-gias", "go"), 10000, config.getGiasNotificationInterval());
	}

	private WorkQueue<ImportJobService> createImportPaymentMethodsQueue(Environment environment, final Jdbi jdbi, TrackRequestService trackRequestService,
			ImportPartyCreditService importPartyCreditService) {
		ImportPartyCreditsConsumer importPartyCreditsConsumer = new ImportPartyCreditsConsumer(importPartyCreditService, trackRequestService);
		WorkQueue<ImportJobService> partyCreditQueue = WorkQueue.builder("import-party-payment", new JdbiRepository(jdbi), ImportJobService.class)
				.withErrorListener(importPartyCreditsConsumer)
				.withConsumer(importPartyCreditsConsumer)
				.withMetricsRegistry(environment.metrics())
				.withNumThreads(2)
				.withTimeoutMs(60 * 60 * 1_000L)
				.build();
		partyCreditQueue.start();
		return partyCreditQueue;
	}

	private WorkQueue<ImportJobService> createImportCropPlanQueue(Environment environment, final Jdbi jdbi, ICropPlanService cropPlanService,
			TrackRequestService trackRequestService) {
		// Create queue
		ImportCropPlanConsumer importCropPlanConsumer = new ImportCropPlanConsumer(cropPlanService, trackRequestService);
		WorkQueue<ImportJobService> cropPlanQueue = WorkQueue.builder("import-crop-plan", new JdbiRepository(jdbi), ImportJobService.class)
				.withErrorListener(importCropPlanConsumer)
				.withConsumer(importCropPlanConsumer)
				.withMetricsRegistry(environment.metrics())
				.withNumThreads(10)
				.withTimeoutMs(60 * 60 * 1_000L)
				.build();
		cropPlanQueue.start();
		return cropPlanQueue;
	}

	/// Bulk Import Party
	private WorkQueue<String> createBulkImportPartyQueue(Environment environment, final Jdbi jdbi, BulkImportPartyService service,
			BulkImportPartyLoadService bulkImportPartyLoadService, TrackRequestService trackRequestService) {

		// Crop Plan
		BulkImportPartyCropPlanConsumer importCropPlanConsumer = new BulkImportPartyCropPlanConsumer(service, bulkImportPartyLoadService, 3);
		WorkQueue<String> cropPlanQueue = WorkQueue.builder("bulk-import-party-crop-plan", new JdbiRepository(jdbi), String.class)
				.withErrorListener(importCropPlanConsumer)
				.withConsumer(importCropPlanConsumer)
				.withMetricsRegistry(environment.metrics())
				.withNumThreads(10)
				.withTimeoutMs(60 * 60 * 1_000L)
				.build();
		cropPlanQueue.start();

		// dossier
		BulkImportPartyDossierConsumer dossierConsumer = new BulkImportPartyDossierConsumer(service, bulkImportPartyLoadService, cropPlanQueue, 2);
		WorkQueue<String> createDossierQueue = WorkQueue.builder("bulk-import-party-dossier", new JdbiRepository(jdbi), String.class)
				.withErrorListener(dossierConsumer)
				.withConsumer(dossierConsumer)
				.withMetricsRegistry(environment.metrics())
				.withNumThreads(5)
				.withTimeoutMs(60 * 60 * 1_000L)
				.build();
		createDossierQueue.start();

		//
		BulkImportBusinessConsumer consumer = new BulkImportBusinessConsumer(bulkImportPartyLoadService, service, createDossierQueue, 1);
		WorkQueue<String> importPartyQueue = WorkQueue.builder("bulk-import-party", new JdbiRepository(jdbi), String.class)
				.withErrorListener(consumer)
				.withConsumer(consumer)
				.withMetricsRegistry(environment.metrics())
				.withNumThreads(5)
				.withTimeoutMs(60 * 60 * 1_000L)
				.build();
		importPartyQueue.start();

		return importPartyQueue;
	}

	///
	private WorkQueue<ImportZnvCatalogJobService> createImportZnvQueue(Environment environment, final Jdbi jdbi, ImportZnvCatalogService service,
			TrackRequestService trackRequestService) {
		// Create queue
		ImportZnvCatalogConsumer importznvC = new ImportZnvCatalogConsumer(service);
		WorkQueue<ImportZnvCatalogJobService> queue = WorkQueue.builder("import-zvn-catalog", new JdbiRepository(jdbi), ImportZnvCatalogJobService.class)
				.withErrorListener(importznvC)
				.withConsumer(importznvC)
				.withMetricsRegistry(environment.metrics())
				.withNumThreads(10)
				.withTimeoutMs(60 * 60 * 1_000L)
				.build();

		queue.setOnGroupCompleted(group -> {
			trackRequestService.updateStatus(group.getGroup(), group.isHasError() ? "ERROR" : "DONE");
		});

		queue.start();
		return queue;
	}

	private Jdbi createJdbi(DataImporterConfiguration config, Environment environment) {
		final JdbiFactory factory = new JdbiFactory();
		final Jdbi jdbi = factory.build(environment, config.getDatabase(), "ApplicationsApplication");

		boolean isPostgres = jdbi.withHandle(h -> {
			String db = h.queryMetadata(DatabaseMetaData::getDatabaseProductName);
			return db.toLowerCase().contains("postgresql");
		});

		jdbi.installPlugin(new SqlObjectPlugin());
		if (isPostgres) {
			jdbi.installPlugin(new PgJdbiPlugin());
		} else {
			var params = new OraJdbiPlugin.OraJdbiPluginParams(cnn -> cnn.unwrap(OracleConnection.class), true);
			jdbi.installPlugin(new OraJdbiPlugin(params));
		}
		jdbi.configure(AbacoJdbiConfig.class, cfg -> cfg.setTablesPrefix("dataimporter"));
		return jdbi;
	}

	protected Connection createRabbitmqConnection(RabbitMqConfig rabbitmqConfig) {
		if (rabbitmqConfig == null) {
			return null;
		}

		if (StringUtils.isBlank(rabbitmqConfig.getHost())) {
			return null;
		}

		ConnectionFactory factory = new ConnectionFactory();
		factory.setHost(rabbitmqConfig.getHost());

		if (!StringUtils.isBlank(rabbitmqConfig.getUser())) {
			factory.setUsername(rabbitmqConfig.getUser());
		}
		if (!StringUtils.isBlank(rabbitmqConfig.getPassword())) {
			factory.setPassword(rabbitmqConfig.getPassword());
		}
		if (!StringUtils.isBlank(rabbitmqConfig.getVirtualhost())) {
			factory.setVirtualHost(rabbitmqConfig.getVirtualhost());
		}
		if (rabbitmqConfig.getPort() != null) {
			factory.setPort(rabbitmqConfig.getPort());
		}
		factory.setAutomaticRecoveryEnabled(true);

		try {
			return factory.newConnection();
		} catch (IOException | TimeoutException e) {
			throw new IllegalStateException("Cannot connect to rabbit mq", e);
		}
	}

	private void registerAuthFilters(Sso2Client client, DataImporterConfiguration config, Environment environment) {
		if (config.isSecureAuth()) {
			AuthUtils.installAuthFilter(environment, client, new SsoAuthorizer(client));
		} else {
			environment.jersey().register(new DevFilter.Builder<User>()
					.setAuthenticator(new DevAuthenticator())
					.setAuthorizer(new DevAuthorizer<>(config.getDevUser()))
					.setRealm("DEV Env")
					.buildAuthFilter());
			environment.jersey().register(new AuthValueFactoryProvider.Binder<>(User.class));
		}

	}

	private void configure(ObjectMapper objectMapper) {
		objectMapper.disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);
		objectMapper.disable(DeserializationFeature.ADJUST_DATES_TO_CONTEXT_TIME_ZONE);
		// objectMapper.registerModule(new JavaTimeModule());

		SimpleModule module = new SimpleModule("custom-deserializers", Version.unknownVersion());
		module.addSerializer(Geometry.class, new WKTGeometrySerializer());
		module.addDeserializer(Geometry.class, new WKTGeometryDeserializer());
		objectMapper.registerModule(module);
	}
}
