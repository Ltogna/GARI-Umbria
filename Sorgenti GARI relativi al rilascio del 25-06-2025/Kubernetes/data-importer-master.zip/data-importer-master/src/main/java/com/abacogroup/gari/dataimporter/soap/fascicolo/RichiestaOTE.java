
package com.abacogroup.gari.dataimporter.soap.fascicolo;

import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlRootElement;
import jakarta.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="ISWSOTE" type="{http://cooperazione.sian.it/schema/fascicolo}ISWSOTE"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "iswsote"
})
@XmlRootElement(name = "RichiestaOTE")
public class RichiestaOTE {

    @XmlElement(name = "ISWSOTE", required = true)
    protected ISWSOTE iswsote;

    /**
     * Gets the value of the iswsote property.
     * 
     * @return
     *     possible object is
     *     {@link ISWSOTE }
     *     
     */
    public ISWSOTE getISWSOTE() {
        return iswsote;
    }

    /**
     * Sets the value of the iswsote property.
     * 
     * @param value
     *     allowed object is
     *     {@link ISWSOTE }
     *     
     */
    public void setISWSOTE(ISWSOTE value) {
        this.iswsote = value;
    }

}
