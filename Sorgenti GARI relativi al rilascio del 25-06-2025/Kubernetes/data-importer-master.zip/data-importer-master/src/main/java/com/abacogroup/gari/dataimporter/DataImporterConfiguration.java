package com.abacogroup.gari.dataimporter;

import com.abacogroup.gari.dataimporter.config.BundleConfig;
import com.abacogroup.gari.dataimporter.config.RabbitMqConfig;
import com.abacogroup.gari.dataimporter.config.SianSoapCredentials;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.dropwizard.client.JerseyClientConfiguration;
import io.dropwizard.core.Configuration;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import lombok.Data;
import lombok.EqualsAndHashCode;

import io.dropwizard.db.DataSourceFactory;

@Data
@EqualsAndHashCode(callSuper = true)
public class DataImporterConfiguration extends Configuration {
	@NotEmpty
	private String sso2Url;

	@NotEmpty
	private String mtlsProxyUrl;

	private String partyRegistry;
	private String partyRegistryAcl;
	private String vectorDataLayers;
	private String lauService;
	private String dossierDataModule;
	private String dossierUrl;
	private Boolean activateBundleConfig;
	private BundleConfig bundleConfig;
	private String giasBaseUrl;
	private String giasLoginToken;
	private Integer giasNotificationInterval;
	private SianSoapCredentials sianSoapCredentials;

	private RabbitMqConfig rabbitmqConfig;
	@JsonProperty("database")
	private DataSourceFactory database;
	@NotEmpty
	private String cropPlanUrl;

	@NotEmpty
	private String sso2TokenSecretAuth;

	@Valid
	@NotNull
	private JerseyClientConfiguration jerseyClientConfiguration;

	public DataSourceFactory getDatabase() {
		return database;
	}

	private boolean secureAuth;

	private Boolean devUser;

	public Boolean getDevUser() {
		return devUser;
	}

	public boolean isSecureAuth() {
		return secureAuth;
	}

}
