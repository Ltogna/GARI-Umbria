
package com.abacogroup.gari.dataimporter.soap.fascicolo;

import jakarta.xml.bind.JAXBElement;
import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlElementRef;
import jakarta.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ISWSDettaglioUtilizzoTerra15 complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ISWSDettaglioUtilizzoTerra15"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="codiceProdotto"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;length value="3"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="codiceVarieta"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;length value="3"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="SuperficieUtilizzata"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}int"&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="SuperficieEligibile" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}int"&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="superficieEligibileOP" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}int"&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="DataFineUtilizzo" type="{http://cooperazione.sian.it/schema/fascicolo}Data" minOccurs="0"/&gt;
 *         &lt;element name="NumeroPiante" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}int"&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="FlagColtPrincipale" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;enumeration value="0"/&gt;
 *               &lt;enumeration value="1"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="FormaAllevamento" type="{http://cooperazione.sian.it/schema/fascicolo}formalle"/&gt;
 *         &lt;element name="AnnoImpianto" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;length value="4"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="SestoImpiantoSuFila" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;maxLength value="8"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="SestoImpiantoTraFile" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;maxLength value="8"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="TipoImpianto" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;enumeration value="1"/&gt;
 *               &lt;enumeration value="2"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="ColtivazioneBiologica" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;enumeration value="1"/&gt;
 *               &lt;enumeration value="2"/&gt;
 *               &lt;enumeration value="3"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="TipologiaSemina" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;enumeration value="1"/&gt;
 *               &lt;enumeration value="2"/&gt;
 *               &lt;enumeration value="3"/&gt;
 *               &lt;enumeration value="4"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="TipologiaIrrigazione" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;enumeration value="1"/&gt;
 *               &lt;enumeration value="2"/&gt;
 *               &lt;enumeration value="3"/&gt;
 *               &lt;enumeration value="4"/&gt;
 *               &lt;enumeration value="5"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="ProtezioneColture" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;enumeration value="1"/&gt;
 *               &lt;enumeration value="2"/&gt;
 *               &lt;enumeration value="3"/&gt;
 *               &lt;enumeration value="4"/&gt;
 *               &lt;enumeration value="5"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="FaseAllevamento" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;enumeration value="1"/&gt;
 *               &lt;enumeration value="2"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="MantPratiPermanente" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;enumeration value="1"/&gt;
 *               &lt;enumeration value="2"/&gt;
 *               &lt;enumeration value="3"/&gt;
 *               &lt;enumeration value="4"/&gt;
 *               &lt;enumeration value="5"/&gt;
 *               &lt;enumeration value="6"/&gt;
 *               &lt;enumeration value="7"/&gt;
 *               &lt;enumeration value="8"/&gt;
 *               &lt;enumeration value="10"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="MantenSupAgricola" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;enumeration value="1"/&gt;
 *               &lt;enumeration value="2"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="tipoCertificazione" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;enumeration value="0"/&gt;
 *               &lt;enumeration value="1"/&gt;
 *               &lt;enumeration value="2"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="percentuale" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;maxLength value="3"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="menzione" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}int"&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="tipoUtilizzolivo" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;enumeration value="0"/&gt;
 *               &lt;enumeration value="1"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="capacitaProduttiva" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;maxLength value="8"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="altitudine" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}int"&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ISWSDettaglioUtilizzoTerra15", propOrder = {
    "codiceProdotto",
    "codiceVarieta",
    "superficieUtilizzata",
    "superficieEligibile",
    "superficieEligibileOP",
    "dataFineUtilizzo",
    "numeroPiante",
    "flagColtPrincipale",
    "formaAllevamento",
    "annoImpianto",
    "sestoImpiantoSuFila",
    "sestoImpiantoTraFile",
    "tipoImpianto",
    "coltivazioneBiologica",
    "tipologiaSemina",
    "tipologiaIrrigazione",
    "protezioneColture",
    "faseAllevamento",
    "mantPratiPermanente",
    "mantenSupAgricola",
    "tipoCertificazione",
    "percentuale",
    "menzione",
    "tipoUtilizzolivo",
    "capacitaProduttiva",
    "altitudine"
})
public class ISWSDettaglioUtilizzoTerra15 {

    @XmlElement(required = true)
    protected String codiceProdotto;
    @XmlElement(required = true)
    protected String codiceVarieta;
    @XmlElement(name = "SuperficieUtilizzata")
    protected int superficieUtilizzata;
    @XmlElementRef(name = "SuperficieEligibile", namespace = "http://cooperazione.sian.it/schema/fascicolo", type = JAXBElement.class, required = false)
    protected JAXBElement<Integer> superficieEligibile;
    @XmlElementRef(name = "superficieEligibileOP", namespace = "http://cooperazione.sian.it/schema/fascicolo", type = JAXBElement.class, required = false)
    protected JAXBElement<Integer> superficieEligibileOP;
    @XmlElementRef(name = "DataFineUtilizzo", namespace = "http://cooperazione.sian.it/schema/fascicolo", type = JAXBElement.class, required = false)
    protected JAXBElement<String> dataFineUtilizzo;
    @XmlElementRef(name = "NumeroPiante", namespace = "http://cooperazione.sian.it/schema/fascicolo", type = JAXBElement.class, required = false)
    protected JAXBElement<Integer> numeroPiante;
    @XmlElementRef(name = "FlagColtPrincipale", namespace = "http://cooperazione.sian.it/schema/fascicolo", type = JAXBElement.class, required = false)
    protected JAXBElement<String> flagColtPrincipale;
    @XmlElement(name = "FormaAllevamento", required = true, nillable = true)
    protected String formaAllevamento;
    @XmlElementRef(name = "AnnoImpianto", namespace = "http://cooperazione.sian.it/schema/fascicolo", type = JAXBElement.class, required = false)
    protected JAXBElement<String> annoImpianto;
    @XmlElementRef(name = "SestoImpiantoSuFila", namespace = "http://cooperazione.sian.it/schema/fascicolo", type = JAXBElement.class, required = false)
    protected JAXBElement<String> sestoImpiantoSuFila;
    @XmlElementRef(name = "SestoImpiantoTraFile", namespace = "http://cooperazione.sian.it/schema/fascicolo", type = JAXBElement.class, required = false)
    protected JAXBElement<String> sestoImpiantoTraFile;
    @XmlElementRef(name = "TipoImpianto", namespace = "http://cooperazione.sian.it/schema/fascicolo", type = JAXBElement.class, required = false)
    protected JAXBElement<String> tipoImpianto;
    @XmlElementRef(name = "ColtivazioneBiologica", namespace = "http://cooperazione.sian.it/schema/fascicolo", type = JAXBElement.class, required = false)
    protected JAXBElement<String> coltivazioneBiologica;
    @XmlElementRef(name = "TipologiaSemina", namespace = "http://cooperazione.sian.it/schema/fascicolo", type = JAXBElement.class, required = false)
    protected JAXBElement<String> tipologiaSemina;
    @XmlElementRef(name = "TipologiaIrrigazione", namespace = "http://cooperazione.sian.it/schema/fascicolo", type = JAXBElement.class, required = false)
    protected JAXBElement<String> tipologiaIrrigazione;
    @XmlElementRef(name = "ProtezioneColture", namespace = "http://cooperazione.sian.it/schema/fascicolo", type = JAXBElement.class, required = false)
    protected JAXBElement<String> protezioneColture;
    @XmlElementRef(name = "FaseAllevamento", namespace = "http://cooperazione.sian.it/schema/fascicolo", type = JAXBElement.class, required = false)
    protected JAXBElement<String> faseAllevamento;
    @XmlElementRef(name = "MantPratiPermanente", namespace = "http://cooperazione.sian.it/schema/fascicolo", type = JAXBElement.class, required = false)
    protected JAXBElement<String> mantPratiPermanente;
    @XmlElementRef(name = "MantenSupAgricola", namespace = "http://cooperazione.sian.it/schema/fascicolo", type = JAXBElement.class, required = false)
    protected JAXBElement<String> mantenSupAgricola;
    @XmlElementRef(name = "tipoCertificazione", namespace = "http://cooperazione.sian.it/schema/fascicolo", type = JAXBElement.class, required = false)
    protected JAXBElement<String> tipoCertificazione;
    @XmlElementRef(name = "percentuale", namespace = "http://cooperazione.sian.it/schema/fascicolo", type = JAXBElement.class, required = false)
    protected JAXBElement<String> percentuale;
    @XmlElementRef(name = "menzione", namespace = "http://cooperazione.sian.it/schema/fascicolo", type = JAXBElement.class, required = false)
    protected JAXBElement<Integer> menzione;
    @XmlElementRef(name = "tipoUtilizzolivo", namespace = "http://cooperazione.sian.it/schema/fascicolo", type = JAXBElement.class, required = false)
    protected JAXBElement<String> tipoUtilizzolivo;
    @XmlElementRef(name = "capacitaProduttiva", namespace = "http://cooperazione.sian.it/schema/fascicolo", type = JAXBElement.class, required = false)
    protected JAXBElement<String> capacitaProduttiva;
    @XmlElementRef(name = "altitudine", namespace = "http://cooperazione.sian.it/schema/fascicolo", type = JAXBElement.class, required = false)
    protected JAXBElement<Integer> altitudine;

    /**
     * Gets the value of the codiceProdotto property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodiceProdotto() {
        return codiceProdotto;
    }

    /**
     * Sets the value of the codiceProdotto property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodiceProdotto(String value) {
        this.codiceProdotto = value;
    }

    /**
     * Gets the value of the codiceVarieta property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodiceVarieta() {
        return codiceVarieta;
    }

    /**
     * Sets the value of the codiceVarieta property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodiceVarieta(String value) {
        this.codiceVarieta = value;
    }

    /**
     * Gets the value of the superficieUtilizzata property.
     * 
     */
    public int getSuperficieUtilizzata() {
        return superficieUtilizzata;
    }

    /**
     * Sets the value of the superficieUtilizzata property.
     * 
     */
    public void setSuperficieUtilizzata(int value) {
        this.superficieUtilizzata = value;
    }

    /**
     * Gets the value of the superficieEligibile property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Integer }{@code >}
     *     
     */
    public JAXBElement<Integer> getSuperficieEligibile() {
        return superficieEligibile;
    }

    /**
     * Sets the value of the superficieEligibile property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Integer }{@code >}
     *     
     */
    public void setSuperficieEligibile(JAXBElement<Integer> value) {
        this.superficieEligibile = value;
    }

    /**
     * Gets the value of the superficieEligibileOP property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Integer }{@code >}
     *     
     */
    public JAXBElement<Integer> getSuperficieEligibileOP() {
        return superficieEligibileOP;
    }

    /**
     * Sets the value of the superficieEligibileOP property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Integer }{@code >}
     *     
     */
    public void setSuperficieEligibileOP(JAXBElement<Integer> value) {
        this.superficieEligibileOP = value;
    }

    /**
     * Gets the value of the dataFineUtilizzo property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getDataFineUtilizzo() {
        return dataFineUtilizzo;
    }

    /**
     * Sets the value of the dataFineUtilizzo property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setDataFineUtilizzo(JAXBElement<String> value) {
        this.dataFineUtilizzo = value;
    }

    /**
     * Gets the value of the numeroPiante property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Integer }{@code >}
     *     
     */
    public JAXBElement<Integer> getNumeroPiante() {
        return numeroPiante;
    }

    /**
     * Sets the value of the numeroPiante property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Integer }{@code >}
     *     
     */
    public void setNumeroPiante(JAXBElement<Integer> value) {
        this.numeroPiante = value;
    }

    /**
     * Gets the value of the flagColtPrincipale property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getFlagColtPrincipale() {
        return flagColtPrincipale;
    }

    /**
     * Sets the value of the flagColtPrincipale property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setFlagColtPrincipale(JAXBElement<String> value) {
        this.flagColtPrincipale = value;
    }

    /**
     * Gets the value of the formaAllevamento property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFormaAllevamento() {
        return formaAllevamento;
    }

    /**
     * Sets the value of the formaAllevamento property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFormaAllevamento(String value) {
        this.formaAllevamento = value;
    }

    /**
     * Gets the value of the annoImpianto property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getAnnoImpianto() {
        return annoImpianto;
    }

    /**
     * Sets the value of the annoImpianto property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setAnnoImpianto(JAXBElement<String> value) {
        this.annoImpianto = value;
    }

    /**
     * Gets the value of the sestoImpiantoSuFila property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getSestoImpiantoSuFila() {
        return sestoImpiantoSuFila;
    }

    /**
     * Sets the value of the sestoImpiantoSuFila property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setSestoImpiantoSuFila(JAXBElement<String> value) {
        this.sestoImpiantoSuFila = value;
    }

    /**
     * Gets the value of the sestoImpiantoTraFile property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getSestoImpiantoTraFile() {
        return sestoImpiantoTraFile;
    }

    /**
     * Sets the value of the sestoImpiantoTraFile property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setSestoImpiantoTraFile(JAXBElement<String> value) {
        this.sestoImpiantoTraFile = value;
    }

    /**
     * Gets the value of the tipoImpianto property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getTipoImpianto() {
        return tipoImpianto;
    }

    /**
     * Sets the value of the tipoImpianto property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setTipoImpianto(JAXBElement<String> value) {
        this.tipoImpianto = value;
    }

    /**
     * Gets the value of the coltivazioneBiologica property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getColtivazioneBiologica() {
        return coltivazioneBiologica;
    }

    /**
     * Sets the value of the coltivazioneBiologica property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setColtivazioneBiologica(JAXBElement<String> value) {
        this.coltivazioneBiologica = value;
    }

    /**
     * Gets the value of the tipologiaSemina property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getTipologiaSemina() {
        return tipologiaSemina;
    }

    /**
     * Sets the value of the tipologiaSemina property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setTipologiaSemina(JAXBElement<String> value) {
        this.tipologiaSemina = value;
    }

    /**
     * Gets the value of the tipologiaIrrigazione property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getTipologiaIrrigazione() {
        return tipologiaIrrigazione;
    }

    /**
     * Sets the value of the tipologiaIrrigazione property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setTipologiaIrrigazione(JAXBElement<String> value) {
        this.tipologiaIrrigazione = value;
    }

    /**
     * Gets the value of the protezioneColture property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getProtezioneColture() {
        return protezioneColture;
    }

    /**
     * Sets the value of the protezioneColture property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setProtezioneColture(JAXBElement<String> value) {
        this.protezioneColture = value;
    }

    /**
     * Gets the value of the faseAllevamento property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getFaseAllevamento() {
        return faseAllevamento;
    }

    /**
     * Sets the value of the faseAllevamento property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setFaseAllevamento(JAXBElement<String> value) {
        this.faseAllevamento = value;
    }

    /**
     * Gets the value of the mantPratiPermanente property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getMantPratiPermanente() {
        return mantPratiPermanente;
    }

    /**
     * Sets the value of the mantPratiPermanente property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setMantPratiPermanente(JAXBElement<String> value) {
        this.mantPratiPermanente = value;
    }

    /**
     * Gets the value of the mantenSupAgricola property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getMantenSupAgricola() {
        return mantenSupAgricola;
    }

    /**
     * Sets the value of the mantenSupAgricola property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setMantenSupAgricola(JAXBElement<String> value) {
        this.mantenSupAgricola = value;
    }

    /**
     * Gets the value of the tipoCertificazione property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getTipoCertificazione() {
        return tipoCertificazione;
    }

    /**
     * Sets the value of the tipoCertificazione property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setTipoCertificazione(JAXBElement<String> value) {
        this.tipoCertificazione = value;
    }

    /**
     * Gets the value of the percentuale property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getPercentuale() {
        return percentuale;
    }

    /**
     * Sets the value of the percentuale property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setPercentuale(JAXBElement<String> value) {
        this.percentuale = value;
    }

    /**
     * Gets the value of the menzione property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Integer }{@code >}
     *     
     */
    public JAXBElement<Integer> getMenzione() {
        return menzione;
    }

    /**
     * Sets the value of the menzione property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Integer }{@code >}
     *     
     */
    public void setMenzione(JAXBElement<Integer> value) {
        this.menzione = value;
    }

    /**
     * Gets the value of the tipoUtilizzolivo property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getTipoUtilizzolivo() {
        return tipoUtilizzolivo;
    }

    /**
     * Sets the value of the tipoUtilizzolivo property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setTipoUtilizzolivo(JAXBElement<String> value) {
        this.tipoUtilizzolivo = value;
    }

    /**
     * Gets the value of the capacitaProduttiva property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getCapacitaProduttiva() {
        return capacitaProduttiva;
    }

    /**
     * Sets the value of the capacitaProduttiva property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setCapacitaProduttiva(JAXBElement<String> value) {
        this.capacitaProduttiva = value;
    }

    /**
     * Gets the value of the altitudine property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Integer }{@code >}
     *     
     */
    public JAXBElement<Integer> getAltitudine() {
        return altitudine;
    }

    /**
     * Sets the value of the altitudine property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Integer }{@code >}
     *     
     */
    public void setAltitudine(JAXBElement<Integer> value) {
        this.altitudine = value;
    }

}
