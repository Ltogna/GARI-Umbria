
package com.abacogroup.gari.dataimporter.soap.fascicolo;

import java.util.ArrayList;
import java.util.List;
import jakarta.xml.bind.JAXBElement;
import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlElementRef;
import jakarta.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ISWSDURC complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ISWSDURC"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="EsisteDURC"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;enumeration value="0"/&gt;
 *               &lt;enumeration value="1"/&gt;
 *               &lt;enumeration value="2"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="TipoAnomalia" type="{http://cooperazione.sian.it/schema/fascicolo}ISWSAnomalieDURC" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="DettaglioDURC" type="{http://cooperazione.sian.it/schema/fascicolo}ISWSDettaglioDURC" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ISWSDURC", propOrder = {
    "esisteDURC",
    "tipoAnomalia",
    "dettaglioDURC"
})
public class ISWSDURC {

    @XmlElement(name = "EsisteDURC", required = true)
    protected String esisteDURC;
    @XmlElement(name = "TipoAnomalia", nillable = true)
    protected List<ISWSAnomalieDURC> tipoAnomalia;
    @XmlElementRef(name = "DettaglioDURC", namespace = "http://cooperazione.sian.it/schema/fascicolo", type = JAXBElement.class, required = false)
    protected JAXBElement<ISWSDettaglioDURC> dettaglioDURC;

    /**
     * Gets the value of the esisteDURC property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEsisteDURC() {
        return esisteDURC;
    }

    /**
     * Sets the value of the esisteDURC property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEsisteDURC(String value) {
        this.esisteDURC = value;
    }

    /**
     * Gets the value of the tipoAnomalia property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the Jakarta XML Binding object.
     * This is why there is not a <CODE>set</CODE> method for the tipoAnomalia property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getTipoAnomalia().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ISWSAnomalieDURC }
     * 
     * 
     */
    public List<ISWSAnomalieDURC> getTipoAnomalia() {
        if (tipoAnomalia == null) {
            tipoAnomalia = new ArrayList<ISWSAnomalieDURC>();
        }
        return this.tipoAnomalia;
    }

    /**
     * Gets the value of the dettaglioDURC property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link ISWSDettaglioDURC }{@code >}
     *     
     */
    public JAXBElement<ISWSDettaglioDURC> getDettaglioDURC() {
        return dettaglioDURC;
    }

    /**
     * Sets the value of the dettaglioDURC property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link ISWSDettaglioDURC }{@code >}
     *     
     */
    public void setDettaglioDURC(JAXBElement<ISWSDettaglioDURC> value) {
        this.dettaglioDURC = value;
    }

}
