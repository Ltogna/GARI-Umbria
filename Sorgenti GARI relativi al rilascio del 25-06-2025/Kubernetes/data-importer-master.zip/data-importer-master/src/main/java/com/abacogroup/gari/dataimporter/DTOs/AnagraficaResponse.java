package com.abacogroup.gari.dataimporter.DTOs;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.time.ZonedDateTime;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class AnagraficaResponse {

	@JsonProperty("cuaa") // party code
	private String cuaa;

	@JsonProperty("tipo_anagrafica") // partytype == N ? P: G
	private String tipoAnagrafica;

	@JsonProperty("denominazione") // trim(LastName +" "+ FirstName)
	private String denominazione;

	@JsonProperty("codice_fiscale") // tax code
	private String codiceFiscale;

	@JsonProperty("partita_iva") // vatcode
	private String partitaIva;

	@JsonProperty("sede") // addressResidential
	private AnagraficaSede sede;

	@JsonProperty("centro_aziendale") // null
	private AnagraficaCentroAziendale centroAziendale;

	@JsonProperty("codice_op") // null
	private String codiceOp;

	private Mandato mandato;

	@JsonProperty("ultimo_aggiornamento") // null
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ssXXX")
	private ZonedDateTime ultimoAggiornamento;

	@Builder
	@AllArgsConstructor
	@NoArgsConstructor
	public static class AnagraficaSede {

		@JsonProperty("codice_belfiore") // municipalitydetail.shortDescr
		private String codiceBelfiore;

		@JsonProperty("comune") // municipalitydetail.i18nName
		private String comune;

		@JsonProperty("indirizzo") // locality +" "+ streeet +" "+ houseNumber
		private String indirizzo;

		@JsonProperty("cap") // postCode
		private String cap;
	}

	@Data
	@Builder
	@AllArgsConstructor
	@NoArgsConstructor
	public static class AnagraficaCentroAziendale {

		@JsonProperty("lat")
		private Double lat;

		@JsonProperty("long")
		private Double lng;
	}

	@Data
	@AllArgsConstructor
	@NoArgsConstructor
	public static class Mandato {
		@JsonProperty("codice_detentore")
		private String codiceDetentore;
		@JsonProperty("data_inizio_validita")
		private LocalDate dataInizioValidita = LocalDate.of(1900, 1, 1);
		@JsonProperty("data_fine_validita")
		private LocalDate dataFineValidita = LocalDate.of(2100, 12, 31);

		public Mandato(String codiceDetentore) {
			this.codiceDetentore = codiceDetentore;
		}
	}
}
