package com.abacogroup.gari.dataimporter.DTOs;

import com.abacogroup.jdbi.datatype.AbsoluteDate;

import lombok.Data;

@Data
public class PartyAclEntitiesResponse {
    private Long id;
    private PartyType party_type;
    private AbsoluteDate day_from;
    private AbsoluteDate day_to;
    private Entity entity;

    @Data
    public static class PartyType {
        private Long id;
        private String code;
        private String description;
        private boolean fl_exclusive;
        private boolean fl_manage;
    }

    @Data
    public static class Entity {
        private Long id;
        private String code;
        private String name;
        private EntityType entity_type;
        private AbsoluteDate day_from;
        private AbsoluteDate day_to;
        private boolean closed;
        private AbsoluteDate close_day;
    }

    @Data
    public static class EntityType {
        private Long id;
        private String code;
        private String description;
    }
}
