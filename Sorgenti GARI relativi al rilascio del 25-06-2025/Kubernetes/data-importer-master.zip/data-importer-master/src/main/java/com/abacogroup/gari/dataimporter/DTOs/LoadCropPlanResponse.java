package com.abacogroup.gari.dataimporter.DTOs;

import com.fasterxml.jackson.annotation.JsonProperty;

public class LoadCropPlanResponse {

    @JsonProperty("loadingProcessId")
    private String loadingProcessId;

    @JsonProperty("status")
    private String status;

    @JsonProperty("message")
    private String message;

    // No-argument constructor
    public LoadCropPlanResponse() {
    }

    // Getters and setters

    public String getLoadingProcessId() {
        return loadingProcessId;
    }

    public void setLoadingProcessId(String loadingProcessId) {
        this.loadingProcessId = loadingProcessId;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
