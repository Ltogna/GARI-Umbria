package com.abacogroup.gari.dataimporter.exceptions;

import jakarta.ws.rs.WebApplicationException;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.core.Response.Status;

public abstract class AbstractWebException extends WebApplicationException {

    private ExceptionErrorBody errorBody;

    protected AbstractWebException() {
    }

    AbstractWebException(Status status, ExceptionErrorBody body) {
        super(body.getMessage(),
                Response.status(status)
                        .entity(body)
                        .build());
        this.errorBody = body;
    }

    AbstractWebException(int status, ExceptionErrorBody body) {
        this(Status.fromStatusCode(status), body);
    }

    AbstractWebException(int status, ExceptionErrorBody body, Throwable throwable) {
        super(body.getMessage(),
                throwable,
                Response.status(status)
                        .entity(body)
                        .build());
        this.errorBody = body;
    }

    public ExceptionErrorBody getErrorBody() {
        return errorBody;
    }

    public String getCode() {
        return getErrorBody().getErrorCode();
    }

    public interface ExceptionErrorBody {
        String getErrorCode();

        String getMessage();
    }

}
