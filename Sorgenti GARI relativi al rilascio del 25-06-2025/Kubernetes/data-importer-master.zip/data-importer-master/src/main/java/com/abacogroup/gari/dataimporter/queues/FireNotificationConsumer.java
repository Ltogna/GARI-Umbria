package com.abacogroup.gari.dataimporter.queues;

import com.abacogroup.embeddedqueue.ThrowingConsumer;
import com.abacogroup.embeddedqueue.WorkQueue;
import com.abacogroup.gari.dataimporter.services.GIASNotificationService;

public class FireNotificationConsumer implements ThrowingConsumer<String> {
	private final WorkQueue<String> workQueue;
	private final GIASNotificationService giasNotificationService;

	public FireNotificationConsumer(WorkQueue<String> workQueue, GIASNotificationService giasNotificationService) {
		this.workQueue = workQueue;
		this.giasNotificationService = giasNotificationService;
	}

	@Override
	public void accept(String job) throws Exception {
		giasNotificationService.ImportNotification(workQueue);
	}
}
