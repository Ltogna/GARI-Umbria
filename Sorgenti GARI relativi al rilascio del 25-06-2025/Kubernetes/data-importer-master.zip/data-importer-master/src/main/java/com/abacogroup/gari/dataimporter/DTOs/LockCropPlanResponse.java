package com.abacogroup.gari.dataimporter.DTOs;

import com.fasterxml.jackson.annotation.JsonProperty;

public class LockCropPlanResponse {

    @JsonProperty("status")
    private String status;

    @JsonProperty("message")
    private String message;
    
    @JsonProperty("businessId")
    private String businessId;
    
    @JsonProperty("cropPlanId")
    private String cropPlanId;

    // No-argument constructor
    public LockCropPlanResponse() {
    }

    // Getters and setters

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getMessage() {
        return message;
    }

	public void setMessage(String message) {
        this.message = message;
    }
    
    public String getBusinessId() {
		return businessId;
	}
    
    public void setBusinessId(String businessId) {
		this.businessId = businessId;
	}
    
    public String getCropPlanId() {
		return cropPlanId;
	}
    
    public void setCropPlanId(String cropPlanId) {
		this.cropPlanId = cropPlanId;
	}
    
    @Override
   	public String toString() {
   		return "LockCropPlanResponse [status=" + status + ", message=" + message + ", businessId=" + businessId
   				+ ", cropPlanId=" + cropPlanId + "]";
   	}
}
