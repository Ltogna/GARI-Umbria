package com.abacogroup.gari.dataimporter.DTOs;

import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.OffsetDateTime;
import java.util.List;
import java.util.Objects;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class PlotDataResponse {

    @JsonProperty("plotId")
    private String plotId;
    @JsonProperty("plotCode")
    private String plotCode;
    @JsonProperty("domainZoneId")
    private String domainZoneId;
    @JsonProperty("description")
    private String description;
    @JsonProperty("notes")
    private String notes;
    @JsonProperty("parcelIntersections")
    private List<ParcelIntersection> parcelIntersections;
    @JsonProperty("areaSqm")
    private double areaSqm;
    @JsonProperty("geom")
    private String geom;
    @JsonProperty("srs")
    private String srs;
    @JsonProperty("mbrOverview")
    private String mbrOverview;
    @JsonProperty("decls")
    private List<Declaration> decls;
    @JsonProperty("style")
    private Style style;
    @JsonProperty("fromDate")
    private AbsoluteDate fromDate;
    @JsonProperty("toDate")
    private AbsoluteDate toDate;
    @JsonProperty("fullRangeFromDate")
    private String fullRangeFromDate;
    @JsonProperty("fullRangeToDate")
    private String fullRangeToDate;
    @JsonProperty("editability")
    private String editability;
    @JsonProperty("anomalies")
    private List<Anomaly> anomalies;

    @Override
    public boolean equals(Object o) {
        if (this == o)
            return true;
        if (o == null || getClass() != o.getClass())
            return false;
        PlotDataResponse that = (PlotDataResponse) o;
        return Objects.equals(plotId, that.plotId) && Objects.equals(plotCode, that.plotCode)
                && Objects.equals(domainZoneId, that.domainZoneId)
                && Objects.equals(description, that.description) && Objects.equals(notes, that.notes)
                && Objects.equals(parcelIntersections, that.parcelIntersections)
                && Objects.equals(areaSqm, that.areaSqm) && Objects.equals(geom, that.geom)
                && Objects.equals(srs, that.srs) && Objects.equals(mbrOverview, that.mbrOverview)
                && Objects.equals(decls, that.decls)
                && Objects.equals(style, that.style) && Objects.equals(fromDate, that.fromDate)
                && Objects.equals(toDate, that.toDate)
                && Objects.equals(fullRangeFromDate, that.fullRangeFromDate)
                && Objects.equals(fullRangeToDate, that.fullRangeToDate)
                && Objects.equals(editability, that.editability) && Objects.equals(anomalies, that.anomalies);
    }

    @Override
    public int hashCode() {
        return Objects.hash(plotId, plotCode, domainZoneId, description, notes, parcelIntersections, areaSqm, geom, srs,
                mbrOverview, decls, style, fromDate,
                toDate, fullRangeFromDate, fullRangeToDate, editability, anomalies);
    }

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class ParcelIntersection {
        @JsonProperty("code")
        private String code;
        @JsonProperty("description")
        private String description;
        @JsonProperty("parcelCode")
        private String parcelCode;
        @JsonProperty("notes")
        private String notes;
        @JsonProperty("landCoverCode")
        private String landCoverCode;
        @JsonProperty("landCoverDescription")
        private String landCoverDescription;
        @JsonProperty("areaSqm")
        private double areaSqm;
        @JsonProperty("holdingPercentage")
        private String holdingPercentage;
        @JsonProperty("anomalies")
        private List<Anomaly> anomalies;
        @JsonProperty("canDeclarePesticides")
        private String canDeclarePesticides;

        @Override
        public boolean equals(Object o) {
            if (this == o)
                return true;
            if (o == null || getClass() != o.getClass())
                return false;
            ParcelIntersection that = (ParcelIntersection) o;
            return Objects.equals(code, that.code) && Objects.equals(description, that.description)
                    && Objects.equals(parcelCode, that.parcelCode)
                    && Objects.equals(notes, that.notes) && Objects.equals(landCoverCode, that.landCoverCode)
                    && Objects.equals(landCoverDescription, that.landCoverDescription)
                    && Objects.equals(areaSqm, that.areaSqm)
                    && Objects.equals(holdingPercentage, that.holdingPercentage)
                    && Objects.equals(anomalies, that.anomalies)
                    && Objects.equals(canDeclarePesticides, that.canDeclarePesticides);
        }

        @Override
        public int hashCode() {
            return Objects.hash(code, description, parcelCode, notes, landCoverCode, landCoverDescription, areaSqm,
                    holdingPercentage, anomalies,
                    canDeclarePesticides);
        }
    }

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class Anomaly {
        @JsonProperty("objectCode")
        private String objectCode;
        @JsonProperty("objectType")
        private String objectType;
        @JsonProperty("errorCode")
        private String errorCode;
        @JsonProperty("errorDescription")
        private String errorDescription;
        @JsonProperty("blocking")
        private String blocking;

        @Override
        public boolean equals(Object o) {
            if (this == o)
                return true;
            if (o == null || getClass() != o.getClass())
                return false;
            Anomaly anomaly = (Anomaly) o;
            return Objects.equals(objectCode, anomaly.objectCode) && Objects.equals(objectType, anomaly.objectType)
                    && Objects.equals(errorCode, anomaly.errorCode)
                    && Objects.equals(errorDescription, anomaly.errorDescription)
                    && Objects.equals(blocking, anomaly.blocking);
        }

        @Override
        public int hashCode() {
            return Objects.hash(objectCode, objectType, errorCode, errorDescription, blocking);
        }
    }

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class Declaration {
        @JsonProperty("declCode")
        private String declCode;
        @JsonProperty("landuse")
        private LandUse landuse;
        @JsonProperty("landuseCode")
        private String landuseCode;
        @JsonProperty("areaPerc")
        private double areaPerc;
        @JsonProperty("style")
        private Style style;
        @JsonProperty("fromDate")
        private AbsoluteDate fromDate;
        @JsonProperty("fromDatePrecision")
        private String fromDatePrecision;
        @JsonProperty("toDate")
        private AbsoluteDate toDate;
        @JsonProperty("permanentCropForms")
        private List<PermanentCropForm> permanentCropForms;
        @JsonProperty("anomalies")
        private List<Anomaly> anomalies;
        @JsonProperty("pesticides")
        private List<Pesticide> pesticides;
        @JsonProperty("fieldsCodes")
        private List<AdditionalField> fieldsCodes;

        @Override
        public boolean equals(Object o) {
            if (this == o)
                return true;
            if (o == null || getClass() != o.getClass())
                return false;
            Declaration that = (Declaration) o;
            return Objects.equals(declCode, that.declCode) && Objects.equals(landuse, that.landuse)
                    && Objects.equals(areaPerc, that.areaPerc)
                    && Objects.equals(style, that.style) && Objects.equals(fromDate, that.fromDate)
                    && Objects.equals(fromDatePrecision, that.fromDatePrecision)
                    && Objects.equals(toDate, that.toDate)
                    && Objects.equals(permanentCropForms, that.permanentCropForms)
                    && Objects.equals(anomalies, that.anomalies) && Objects.equals(pesticides, that.pesticides)
                    && Objects.equals(fieldsCodes, that.fieldsCodes);
        }

        @Override
        public int hashCode() {
            return Objects.hash(declCode, landuse, areaPerc, style, fromDate, fromDatePrecision, toDate,
                    permanentCropForms, anomalies, pesticides,
                    fieldsCodes);
        }
    }

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class LandUse {
        @JsonProperty("code")
        private String code;
        @JsonProperty("description")
        private String description;

        @Override
        public boolean equals(Object o) {
            if (this == o)
                return true;
            if (o == null || getClass() != o.getClass())
                return false;
            LandUse landUse = (LandUse) o;
            return Objects.equals(code, landUse.code) && Objects.equals(description, landUse.description);
        }

        @Override
        public int hashCode() {
            return Objects.hash(code, description);
        }
    }

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class Style {
        @JsonProperty("fillColor")
        private String fillColor;
        @JsonProperty("fillStyle")
        private String fillStyle;
        @JsonProperty("borderColor")
        private String borderColor;

        @Override
        public boolean equals(Object o) {
            if (this == o)
                return true;
            if (o == null || getClass() != o.getClass())
                return false;
            Style style = (Style) o;
            return Objects.equals(fillColor, style.fillColor) && Objects.equals(fillStyle, style.fillStyle)
                    && Objects.equals(borderColor, style.borderColor);
        }

        @Override
        public int hashCode() {
            return Objects.hash(fillColor, fillStyle, borderColor);
        }
    }

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class PermanentCropForm {
        @JsonProperty("formCode")
        private String formCode;
        @JsonProperty("formType")
        private String formType;
        @JsonProperty("permanentCropFormData")
        private PermanentCropFormData permanentCropFormData;

        @Override
        public boolean equals(Object o) {
            if (this == o)
                return true;
            if (o == null || getClass() != o.getClass())
                return false;
            PermanentCropForm that = (PermanentCropForm) o;
            return Objects.equals(formCode, that.formCode) && Objects.equals(formType, that.formType)
                    && Objects.equals(permanentCropFormData, that.permanentCropFormData);
        }

        @Override
        public int hashCode() {
            return Objects.hash(formCode, formType, permanentCropFormData);
        }
    }

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class PermanentCropFormData {
        @JsonProperty("areaSqm")
        private double areaSqm;
        @JsonProperty("distanceOnTheRowCm")
        private String distanceOnTheRowCm;
        @JsonProperty("distanceBetweenRowsCm")
        private String distanceBetweenRowsCm;
        @JsonProperty("stumpsNumber")
        private String stumpsNumber;
        @JsonProperty("farmingForm")
        private String farmingForm;
        @JsonProperty("irrigation")
        private String irrigation;
        @JsonProperty("productDestinationCode")
        private String productDestinationCode;
        @JsonProperty("cultivationTypeCode")
        private String cultivationTypeCode;
        @JsonProperty("varietyCode")
        private String varietyCode;
        @JsonProperty("variationTypeCode")
        private String variationTypeCode;
        @JsonProperty("vineyardTypeCode")
        private String vineyardTypeCode;
        @JsonProperty("plantingType")
        private String plantingType;
        @JsonProperty("layering")
        private String layering;
        @JsonProperty("rock")
        private String rock;
        @JsonProperty("skeleton")
        private String skeleton;
        @JsonProperty("vegetativeState")
        private String vegetativeState;
        @JsonProperty("pruning")
        private String pruning;
        @JsonProperty("judgement")
        private String judgement;
        @JsonProperty("stumpsDensity100")
        private String stumpsDensity100;
        @JsonProperty("failuresPerc")
        private String failuresPerc;
        @JsonProperty("soilLayeringPerc")
        private String soilLayeringPerc;
        @JsonProperty("altitudeAboveSeaLevel")
        private String altitudeAboveSeaLevel;
        @JsonProperty("terracing")
        private String terracing;
        @JsonProperty("headerAnchoring")
        private String headerAnchoring;
        @JsonProperty("polesHeader")
        private String polesHeader;
        @JsonProperty("polesWeaving")
        private String polesWeaving;
        @JsonProperty("polesDistanceCm")
        private String polesDistanceCm;
        @JsonProperty("supportWires")
        private String supportWires;
        @JsonProperty("cultivationState")
        private String cultivationState;
        @JsonProperty("origin")
        private String origin;
        @JsonProperty("graftDate")
        private OffsetDateTime graftDate;
        @JsonProperty("graftHolder")
        private String graftHolder;
        @JsonProperty("covering")
        private String covering;
        @JsonProperty("bio")
        private String bio;
        @JsonProperty("subscriptionCodes")
        private String subscriptionCodes;
        @JsonProperty("externalCode")
        private String externalCode;
        @JsonProperty("externalDescription")
        private String externalDescription;
        @JsonProperty("qualitySystem")
        private String qualitySystem;
        @JsonProperty("protectionStructures")
        private String protectionStructures;

        @Override
        public boolean equals(Object o) {
            if (this == o)
                return true;
            if (o == null || getClass() != o.getClass())
                return false;
            PermanentCropFormData that = (PermanentCropFormData) o;
            return Objects.equals(areaSqm, that.areaSqm) && Objects.equals(distanceOnTheRowCm, that.distanceOnTheRowCm)
                    && Objects.equals(distanceBetweenRowsCm, that.distanceBetweenRowsCm)
                    && Objects.equals(stumpsNumber, that.stumpsNumber)
                    && Objects.equals(farmingForm, that.farmingForm) && Objects.equals(irrigation, that.irrigation)
                    && Objects.equals(productDestinationCode, that.productDestinationCode)
                    && Objects.equals(cultivationTypeCode, that.cultivationTypeCode)
                    && Objects.equals(varietyCode, that.varietyCode)
                    && Objects.equals(variationTypeCode, that.variationTypeCode)
                    && Objects.equals(vineyardTypeCode, that.vineyardTypeCode)
                    && Objects.equals(plantingType, that.plantingType)
                    && Objects.equals(layering, that.layering) && Objects.equals(rock, that.rock)
                    && Objects.equals(skeleton, that.skeleton)
                    && Objects.equals(vegetativeState, that.vegetativeState) && Objects.equals(pruning, that.pruning)
                    && Objects.equals(judgement, that.judgement)
                    && Objects.equals(stumpsDensity100, that.stumpsDensity100)
                    && Objects.equals(failuresPerc, that.failuresPerc)
                    && Objects.equals(soilLayeringPerc, that.soilLayeringPerc)
                    && Objects.equals(altitudeAboveSeaLevel, that.altitudeAboveSeaLevel)
                    && Objects.equals(terracing, that.terracing)
                    && Objects.equals(headerAnchoring, that.headerAnchoring)
                    && Objects.equals(polesHeader, that.polesHeader)
                    && Objects.equals(polesWeaving, that.polesWeaving)
                    && Objects.equals(polesDistanceCm, that.polesDistanceCm)
                    && Objects.equals(supportWires, that.supportWires)
                    && Objects.equals(cultivationState, that.cultivationState)
                    && Objects.equals(origin, that.origin) && Objects.equals(graftDate, that.graftDate)
                    && Objects.equals(graftHolder, that.graftHolder)
                    && Objects.equals(covering, that.covering) && Objects.equals(bio, that.bio)
                    && Objects.equals(subscriptionCodes, that.subscriptionCodes)
                    && Objects.equals(externalCode, that.externalCode)
                    && Objects.equals(externalDescription, that.externalDescription)
                    && Objects.equals(qualitySystem, that.qualitySystem)
                    && Objects.equals(protectionStructures, that.protectionStructures);
        }

        @Override
        public int hashCode() {
            return Objects.hash(areaSqm, distanceOnTheRowCm, distanceBetweenRowsCm, stumpsNumber, farmingForm,
                    irrigation, productDestinationCode,
                    cultivationTypeCode, varietyCode, variationTypeCode, vineyardTypeCode, plantingType, layering, rock,
                    skeleton, vegetativeState, pruning,
                    judgement, stumpsDensity100, failuresPerc, soilLayeringPerc, altitudeAboveSeaLevel, terracing,
                    headerAnchoring, polesHeader, polesWeaving,
                    polesDistanceCm, supportWires, cultivationState, origin, graftDate, graftHolder, covering, bio,
                    subscriptionCodes, externalCode,
                    externalDescription, qualitySystem, protectionStructures);
        }
    }

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class Pesticide {
        @JsonProperty("pesticideEntryCode")
        private String pesticideEntryCode;
        @JsonProperty("planId")
        private String planId;
        @JsonProperty("plotCode")
        private String plotCode;
        @JsonProperty("declCode")
        private String declCode;
        @JsonProperty("productCode")
        private String productCode;
        @JsonProperty("uomCode")
        private String uomCode;
        @JsonProperty("amount")
        private String amount;
        @JsonProperty("entryDate")
        private String entryDate;
        @JsonProperty("productName")
        private String productName;
        @JsonProperty("uomLabel")
        private String uomLabel;
        @JsonProperty("userId")
        private String userId;
        @JsonProperty("declaration")
        private Declaration declaration;
        @JsonProperty("parcelIntersection")
        private List<ParcelIntersection> parcelIntersection;
        @JsonProperty("plotAreaSqm")
        private String plotAreaSqm;

        @Override
        public boolean equals(Object o) {
            if (this == o)
                return true;
            if (o == null || getClass() != o.getClass())
                return false;
            Pesticide pesticide = (Pesticide) o;
            return Objects.equals(pesticideEntryCode, pesticide.pesticideEntryCode)
                    && Objects.equals(planId, pesticide.planId)
                    && Objects.equals(plotCode, pesticide.plotCode) && Objects.equals(declCode, pesticide.declCode)
                    && Objects.equals(productCode, pesticide.productCode) && Objects.equals(uomCode, pesticide.uomCode)
                    && Objects.equals(amount, pesticide.amount) && Objects.equals(entryDate, pesticide.entryDate)
                    && Objects.equals(productName, pesticide.productName)
                    && Objects.equals(uomLabel, pesticide.uomLabel)
                    && Objects.equals(userId, pesticide.userId) && Objects.equals(declaration, pesticide.declaration)
                    && Objects.equals(parcelIntersection, pesticide.parcelIntersection)
                    && Objects.equals(plotAreaSqm, pesticide.plotAreaSqm);
        }

        @Override
        public int hashCode() {
            return Objects.hash(pesticideEntryCode, planId, plotCode, declCode, productCode, uomCode, amount, entryDate,
                    productName, uomLabel, userId,
                    declaration, parcelIntersection, plotAreaSqm);
        }
    }

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class AdditionalField {
        @JsonProperty("fieldCode")
        private String fieldCode;
        @JsonProperty("fieldDescription")
        private String fieldDescription;
        @JsonProperty("dayFrom")
        private AbsoluteDate dayFrom;
        @JsonProperty("dayTo")
        private AbsoluteDate dayTo;
        @JsonProperty("sortOrder")
        private String sortOrder;
        @JsonProperty("value")
        private String value;
        @JsonProperty("valueDescription")
        private String valueDescription;
        @JsonProperty("flShowInTooltip")
        private String flShowInTooltip;

        @Override
        public boolean equals(Object o) {
            if (this == o)
                return true;
            if (o == null || getClass() != o.getClass())
                return false;
            AdditionalField fieldCode1 = (AdditionalField) o;
            return Objects.equals(fieldCode, fieldCode1.fieldCode)
                    && Objects.equals(fieldDescription, fieldCode1.fieldDescription)
                    && Objects.equals(dayFrom, fieldCode1.dayFrom) && Objects.equals(dayTo, fieldCode1.dayTo)
                    && Objects.equals(sortOrder, fieldCode1.sortOrder)
                    && Objects.equals(value, fieldCode1.value)
                    && Objects.equals(valueDescription, fieldCode1.valueDescription)
                    && Objects.equals(flShowInTooltip, fieldCode1.flShowInTooltip);
        }

        @Override
        public int hashCode() {
            return Objects.hash(fieldCode, fieldDescription, dayFrom, dayTo, sortOrder, value, valueDescription,
                    flShowInTooltip);
        }
    }
}
