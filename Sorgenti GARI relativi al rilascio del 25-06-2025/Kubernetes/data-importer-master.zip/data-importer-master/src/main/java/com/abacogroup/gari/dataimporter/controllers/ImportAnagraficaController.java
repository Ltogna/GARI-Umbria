package com.abacogroup.gari.dataimporter.controllers;

import java.time.OffsetDateTime;

import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.gari.dataimporter.DTOs.AnagraficaResponse;
import com.abacogroup.gari.dataimporter.Interfaces.ICropPlanService;
import com.abacogroup.jdbi.paging.InfiniteListResults;

import io.dropwizard.auth.Auth;
import jakarta.annotation.security.RolesAllowed;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.MediaType;

@Path("/{tenant}/public/v1/anagrafica")
@Produces(MediaType.APPLICATION_JSON)
public class ImportAnagraficaController {
	private final ICropPlanService iCropPlanService;

	public ImportAnagraficaController(ICropPlanService _iCropPlanService) {
		this.iCropPlanService = _iCropPlanService;
	}

	@GET
	@Path("/{cuaa}")
	@RolesAllowed({ "DATAIMPORTER|PARTIES", "DATAIMPORTER|ADMIN" })
	public AnagraficaResponse findPCGCropPlanByCuaa(
			@Auth User user,
			@PathParam("tenant") String tenantId,
			@PathParam("cuaa") String cuaa) {
		return iCropPlanService.findAnagraficaByCuaa(user, tenantId, cuaa);
	}

	@GET
	@Path("/{cuaa}/aggiornamento")
	@RolesAllowed({ "DATAIMPORTER|PARTIES", "DATAIMPORTER|ADMIN" })
	public InfiniteListResults<AnagraficaResponse> anagraficaInfinityList(
			@Auth User user,
			@PathParam("tenant") String tenantId,
			@PathParam("cuaa") String cuaa,
			@QueryParam("nextKey") String nextKey,
			@QueryParam("ref_timestamp") OffsetDateTime reftimestamp) {
		return iCropPlanService.findAnagraficaListByCuaa(user, tenantId, cuaa, reftimestamp, nextKey);
	}
}
