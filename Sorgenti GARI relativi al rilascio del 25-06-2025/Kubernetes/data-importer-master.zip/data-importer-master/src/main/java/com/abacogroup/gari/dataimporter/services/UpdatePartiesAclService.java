package com.abacogroup.gari.dataimporter.services;

import java.io.IOException;
import java.net.URL;
import java.util.Optional;

import org.jdbi.v3.core.Jdbi;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.abacogroup.dropwizard.auth.sso2.Sso2Client;
import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.embeddedqueue.QueueErrorListener.ErrorAction;
import com.abacogroup.embeddedqueue.WorkQueue;
import com.abacogroup.embeddedqueue.db.JdbiRepository;
import com.abacogroup.gari.dataimporter.DataImporterConfiguration;
import com.abacogroup.gari.dataimporter.DTOs.CreatePartyAclEntity;
import com.abacogroup.gari.dataimporter.DTOs.LinkBusinessToEntity;
import com.abacogroup.gari.dataimporter.DTOs.PartyAclEntity;
import com.abacogroup.gari.dataimporter.DTOs.PartyResponse;
import com.abacogroup.gari.dataimporter.config.SianSoapCredentials;
import com.abacogroup.gari.dataimporter.soap.OprFascicoloFS6ServiceName;
import com.abacogroup.gari.dataimporter.soap.fascicolo.ISWSRespAnagFascicolo15;
import com.abacogroup.gari.dataimporter.soap.fascicolo.ISWSToOprResponse;
import com.abacogroup.gari.dataimporter.soap.fascicolo.InterService;
import com.abacogroup.gari.dataimporter.soap.fascicolo.ObjectFactory;
import com.abacogroup.gari.dataimporter.soap.fascicolo.OprFascicoloFS6;
import com.abacogroup.gari.dataimporter.soap.fascicolo.SOAPAutenticazione;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.jdbi.paging.impl.InfiniteListResultsImpl;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.Delivery;

import io.dropwizard.auth.AuthenticationException;
import io.dropwizard.core.setup.Environment;
import jakarta.ws.rs.NotFoundException;
import jakarta.ws.rs.client.Client;
import jakarta.ws.rs.client.Entity;
import jakarta.ws.rs.core.GenericType;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.SecurityContext;

public class UpdatePartiesAclService {

    private static final Logger log = LoggerFactory.getLogger(UpdatePartiesAclService.class);

    private static final String QUEUE = "data-importer-pacl";
    private static final String EXCHANGE = "party-exchange";
    private static final String ROUTING_KEY = "party.new-party"; // party.*
    private static final String ENTITY_TYPE_CAA = "CAA";
    private static final String ENTITY_TYPE_REGIONAL_OFFICE = "REGIONAL_OFFICE";
    private static final String PARTY_TYPE_MAN = "MAN";
    private static final String PARTY_TYPE_DEL = "DEL";

    private static final String ALL_USERS_ENITY_CODE = "REGIONE";

    private ObjectMapper mapper;
    private Sso2Client sso2Client;
    private Client webClient;
    private ObjectFactory objectFactory = new ObjectFactory();
    private InterService oprFascicoloFS6Service;
    private SianSoapCredentials sianSoapCredentials;
    private String partyRegistry;
    private String partyRegistryAcl;

    private Long maybeNullAllUsersEntityId;

    public UpdatePartiesAclService(Environment environment, DataImporterConfiguration config, Sso2Client sso2Client, Client client, Jdbi jdbi,
            Connection rabbitMQConnection) throws IOException {
        this.sianSoapCredentials = config.getSianSoapCredentials();
        this.partyRegistry = config.getPartyRegistry();
        this.partyRegistryAcl = config.getPartyRegistryAcl();
        this.sso2Client = sso2Client;
        this.webClient = client;
        this.mapper = environment.getObjectMapper();

        URL url = getClass().getResource("/wsdl/OprFascicoloFS6.wsdl");
        OprFascicoloFS6 oprFascicoloFS6 = new OprFascicoloFS6(url);
        oprFascicoloFS6Service = oprFascicoloFS6.getOprFascicoloFS6();

        WorkQueue<WorkQueuePayload> workQueue = WorkQueue.builder(QUEUE, new JdbiRepository(jdbi), WorkQueuePayload.class)
                .withConsumer(this::consumeWorkQueueMessage)
                .withErrorListener((el, t) -> ErrorAction.MARK_AS_ERRORED)
                .withMetricsRegistry(environment.metrics())
                .withNumThreads(2)
                .withTimeoutMs(60_000)
                .build();
        workQueue.start();

        setupRabbit(rabbitMQConnection, workQueue);
    }

    private void setupRabbit(Connection rabbitMQConnection, WorkQueue<WorkQueuePayload> workQueue) throws IOException {
        if (rabbitMQConnection == null) {
            return;
        }

        Channel channel = rabbitMQConnection.createChannel();
        channel.queueDeclare(QUEUE, true, false, false, null);
        channel.queueBind(QUEUE, EXCHANGE, ROUTING_KEY);
        channel.basicQos(1);
        channel.basicConsume(QUEUE, false,
                (consumerTag, delivery) -> onRabbitMqMessage(workQueue, delivery, channel),
                consumerTag -> {
                });
    }

    private void onRabbitMqMessage(WorkQueue<WorkQueuePayload> workQueue, Delivery delivery, Channel channel) throws IOException {
        long deliveryTag = delivery.getEnvelope().getDeliveryTag();
        try {
            // The event carries more info but we do not care...
            WorkQueuePayload payload = mapper.readValue(delivery.getBody(), WorkQueuePayload.class);
            workQueue.add(payload, System.currentTimeMillis());
            channel.basicAck(deliveryTag, false);
        } catch (Throwable t) {
            log.error("Error processing message", t);
            channel.basicNack(deliveryTag, false, false);
        }
    }

    private void consumeWorkQueueMessage(WorkQueuePayload payload) throws AuthenticationException {
        log.info("Processing acl for party {}/{}", payload.tenant, payload.partyId);

        SecurityContext sc = sso2Client.createSecurityContextFromUserName(payload.tenant, ADataImporterService.IMPORT_SERVICE_ACCOUNT);
        User user = (User) sc.getUserPrincipal();
        String authToken = user.getAuthToken();

        // Get the CUAA
        PartyResponse party = webClient.target(partyRegistry)
                .path("/{tenant}/public/v1/parties/{id}")
                .resolveTemplate("tenant", payload.tenant)
                .resolveTemplate("id", payload.partyId)
                .request(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON)
                .header("Authorization", "JWT " + authToken)
                .get(PartyResponse.class);
        String cuaa = party.getCode();

        // call SIAN
        ISWSRespAnagFascicolo15 resp = findDossierAtSian(cuaa);
        String codCaa = resp.getDetentore();
        if (codCaa != null) {
            // Make sure that parties ACL entity exists
            Long entityId = getOrCreatePartiesAclEntityId(codCaa, payload.tenant, authToken);

            // assign party to entity
            LinkBusinessToEntity createLink = new LinkBusinessToEntity(payload.partyId, PARTY_TYPE_MAN);
            webClient.target(partyRegistryAcl)
                    .path("/{tenant}/public/v1/parties-acl/entities/{entityId}/parties")
                    .resolveTemplate("tenant", payload.tenant)
                    .resolveTemplate("entityId", entityId)
                    .request(MediaType.APPLICATION_JSON)
                    .accept(MediaType.APPLICATION_JSON)
                    .header("Authorization", "JWT " + authToken)
                    .post(Entity.json(createLink), Long.class);
        }

        Long allUsersEntityId = getAllUsersAclEntityId(payload.tenant, authToken);
        if (allUsersEntityId == null) {
            throw new IllegalStateException("All users entity [%s] not found in parties acl".formatted(ALL_USERS_ENITY_CODE));
        }
        // assign party to "all users entity"
        LinkBusinessToEntity createLink = new LinkBusinessToEntity(payload.partyId, PARTY_TYPE_DEL);
        webClient.target(partyRegistryAcl)
                .path("/{tenant}/public/v1/parties-acl/entities/{entityId}/parties")
                .resolveTemplate("tenant", payload.tenant)
                .resolveTemplate("entityId", allUsersEntityId)
                .request(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON)
                .header("Authorization", "JWT " + authToken)
                .post(Entity.json(createLink), Long.class);
    }

    private ISWSRespAnagFascicolo15 findDossierAtSian(String cuaa) {
        SOAPAutenticazione soapAutenticazione = objectFactory.createSOAPAutenticazione();
        soapAutenticazione.setUsername(sianSoapCredentials.getUsername());
        soapAutenticazione.setPassword(sianSoapCredentials.getPassword());

        soapAutenticazione.setNomeServizio(OprFascicoloFS6ServiceName.TROVAFASCICOLOFS6);
        ISWSToOprResponse result = oprFascicoloFS6Service.trovaFascicoloFS6(cuaa, soapAutenticazione);
        ISWSRespAnagFascicolo15 resp = result.getRisposta20().getValue();
        return resp;
    }

    private Long getAllUsersAclEntityId(String tenant, String authToken) {
        if (maybeNullAllUsersEntityId == null) {
            PartyAclEntity entity = getPartyAclEntity(tenant, ALL_USERS_ENITY_CODE, ENTITY_TYPE_REGIONAL_OFFICE, authToken);
            maybeNullAllUsersEntityId = entity == null ? null : entity.getId();
        }
        return maybeNullAllUsersEntityId;
    }

    private Long getOrCreatePartiesAclEntityId(String codCaa, String tenant, String authToken) {
        if (codCaa.length() % 3 != 0) {
            throw new IllegalArgumentException("Invalid CAA code: " + codCaa);
        }

        // check if pacl entity exists
        PartyAclEntity entity = getPartyAclEntity(tenant, codCaa, ENTITY_TYPE_CAA, authToken);
        if (entity != null) {
            return entity.getId();
        }

        String codParent = null;
        PartyAclEntity parentEntity = null;
        if (codCaa.length() > 3) {
            codParent = codCaa.substring(0, codCaa.length() - 3);
            getOrCreatePartiesAclEntityId(codParent, tenant, authToken);
            parentEntity = getPartyAclEntity(tenant, codParent, ENTITY_TYPE_CAA, authToken);
        }

        // Create the entity
        String name;
        if (parentEntity == null) {
            name = "CAA " + codCaa;
        } else {
            name = parentEntity.getName() + ", ufficio " + codCaa;
        }

        CreatePartyAclEntity create = CreatePartyAclEntity.builder()
                .code(codCaa)
                .description(name)
                .entity_type_code(ENTITY_TYPE_CAA)
                .name(name)
                .parent_code(codParent)
                .build();

        return webClient.target(partyRegistryAcl)
                .path("/{tenant}/public/v1/parties-acl/entities")
                .resolveTemplate("tenant", tenant)
                .request(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON)
                .header("Authorization", "JWT " + authToken)
                .post(Entity.json(create), Long.class);
    }

    private PartyAclEntity getPartyAclEntity(String tenant, String code, String entityTypeCode, String authToken) {
        String nextKey = null;
        Optional<PartyAclEntity> ntt;
        InfiniteListResults<PartyAclEntity> result;
        do {
            try {
                result = webClient.target(partyRegistryAcl)
                        .path("/{tenant}/public/v1/parties-acl/entities")
                        .resolveTemplate("tenant", tenant)
                        .queryParam("entityTypeCode", entityTypeCode)
                        .queryParam("code", code)
                        .queryParam("next_key", nextKey)
                        .queryParam("nextKey", nextKey) // NOTE: the sofware is currently using only next_key, but we want to be future proof
                        .request(MediaType.APPLICATION_JSON)
                        .accept(MediaType.APPLICATION_JSON)
                        .header("Authorization", "JWT " + authToken)
                        .get(new GenericType<InfiniteListResultsImpl<PartyAclEntity>>() {
                        });
            } catch (NotFoundException e) {
                return null;
            }

            ntt = result.getRecords().stream()
                    .filter(e -> code.equals(e.getCode()))
                    .findFirst();

            if (ntt.isPresent()) {
                return ntt.get();
            } else {
                // NOTE this is an info because we observed some long iterations and we want to be able to debug it on production
                // this procedure, in the vast majority of cases, will return the entity in the first iteration
                log.info("Iterating over parties acl entities, nextKey: {} for entityTypeCode {} and code {}", nextKey, entityTypeCode, code);
            }

            nextKey = result.getNextKey();
        } while (nextKey != null);

        return null;
    }

    public static final class WorkQueuePayload {
        public String tenant;
        public Long partyId;
    }
}
