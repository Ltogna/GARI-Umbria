package com.abacogroup.gari.dataimporter.DTOs;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class PartyAclEntity {
    private Long id;
    private String code;
    private String name;

    // This is not exhaustive of the returned attributes
}
