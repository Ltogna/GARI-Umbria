package com.abacogroup.gari.dataimporter.db.ntt;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.NonNull;

import java.time.OffsetDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class NotificationsDatesNTT {
	public static final String STATUS_TODO = "TODO";
	public static final String STATUS_DONE = "DONE";

	private long partyId;

	@NonNull
	private String familyType;

	@NonNull
	private String flVersion;

	@NonNull
	private OffsetDateTime dtVersion;

	private int flToBeProcessed;
}
