package com.abacogroup.gari.dataimporter.services;

import com.abacogroup.gari.dataimporter.DTOs.GetUserByTenant;
import com.abacogroup.gari.dataimporter.DTOs.UserDetails;
import com.abacogroup.gari.dataimporter.exceptions.UserNotFoundSSO2RuntimeException;
import com.abacogroup.gari.dataimporter.services.common.GetUserBySso2Caller;
import com.abacogroup.jaxrsutils.GenericCallerService;

import lombok.extern.slf4j.Slf4j;

/**
 * 
 * @author Emanuele Crocilla
 *
 */
@Slf4j
public class SSO2UserService {

	private final GetUserBySso2Caller getUserBySso2Caller;
	private final String _url;

	public SSO2UserService(GenericCallerService callerService, String url) {
		
		this.getUserBySso2Caller = new GetUserBySso2Caller(callerService);
		
		// GET {sso2Url}/{tenant}/public/v1/user-management/users/{username}
		this._url = url + "/{tenant}/public/v1/user-management/users/{username}";
	}

	public UserDetails getUserBySSO2(String token, String tenant, String username) {
		
		GetUserByTenant input = null;
		
		try {
			
			log.info("retrieving user by using sso2 for tenant: {} username: {}", tenant, username);
			
			input = GetUserByTenant.of(tenant, username, _url, "JWT " + token);
			
			return getUserBySso2Caller.makeCall(input);
			
		} catch (Exception e) {
			log.error("error calling getUserBySSO2 to fetch user details with input {}", input);
			log.error(e.getMessage(), e);
			throw new UserNotFoundSSO2RuntimeException(e.getMessage());
		}
	}
}
