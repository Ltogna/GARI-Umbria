
package com.abacogroup.gari.dataimporter.soap.fascicolo;

import jakarta.xml.bind.JAXBElement;
import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlElementRef;
import jakarta.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ISWSMacchina complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ISWSMacchina"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="CUAA" type="{http://cooperazione.sian.it/schema/fascicolo}Cuaa"/&gt;
 *         &lt;element name="TipoMacchina"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;maxLength value="5"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="FormaPossesso" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;maxLength value="2"/&gt;
 *               &lt;enumeration value="L"/&gt;
 *               &lt;enumeration value="P"/&gt;
 *               &lt;enumeration value="N"/&gt;
 *               &lt;enumeration value="PU"/&gt;
 *               &lt;enumeration value="U"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="Targa"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;maxLength value="10"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="TipoTarga" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;length value="1"/&gt;
 *               &lt;enumeration value="F"/&gt;
 *               &lt;enumeration value="S"/&gt;
 *               &lt;enumeration value="R"/&gt;
 *               &lt;enumeration value="T"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="Marca"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;maxLength value="20"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="Modello"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;maxLength value="20"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="Telaio"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;maxLength value="20"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="Carburante" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;length value="1"/&gt;
 *               &lt;enumeration value="B"/&gt;
 *               &lt;enumeration value="G"/&gt;
 *               &lt;enumeration value="P"/&gt;
 *               &lt;enumeration value="N"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="Trazione" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;maxLength value="2"/&gt;
 *               &lt;enumeration value="C"/&gt;
 *               &lt;enumeration value="DT"/&gt;
 *               &lt;enumeration value="F"/&gt;
 *               &lt;enumeration value="M"/&gt;
 *               &lt;enumeration value="R"/&gt;
 *               &lt;enumeration value="SC"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="DataIscrizione" type="{http://cooperazione.sian.it/schema/fascicolo}Data"/&gt;
 *         &lt;element name="DataCessazione" type="{http://cooperazione.sian.it/schema/fascicolo}Data"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ISWSMacchina", propOrder = {
    "cuaa",
    "tipoMacchina",
    "formaPossesso",
    "targa",
    "tipoTarga",
    "marca",
    "modello",
    "telaio",
    "carburante",
    "trazione",
    "dataIscrizione",
    "dataCessazione"
})
public class ISWSMacchina {

    @XmlElement(name = "CUAA", required = true)
    protected String cuaa;
    @XmlElement(name = "TipoMacchina", required = true)
    protected String tipoMacchina;
    @XmlElement(name = "FormaPossesso")
    protected String formaPossesso;
    @XmlElement(name = "Targa", required = true, nillable = true)
    protected String targa;
    @XmlElement(name = "TipoTarga")
    protected String tipoTarga;
    @XmlElement(name = "Marca", required = true, nillable = true)
    protected String marca;
    @XmlElement(name = "Modello", required = true, nillable = true)
    protected String modello;
    @XmlElement(name = "Telaio", required = true, nillable = true)
    protected String telaio;
    @XmlElementRef(name = "Carburante", namespace = "http://cooperazione.sian.it/schema/fascicolo", type = JAXBElement.class, required = false)
    protected JAXBElement<String> carburante;
    @XmlElementRef(name = "Trazione", namespace = "http://cooperazione.sian.it/schema/fascicolo", type = JAXBElement.class, required = false)
    protected JAXBElement<String> trazione;
    @XmlElement(name = "DataIscrizione", required = true, nillable = true)
    protected String dataIscrizione;
    @XmlElement(name = "DataCessazione", required = true, nillable = true)
    protected String dataCessazione;

    /**
     * Gets the value of the cuaa property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCUAA() {
        return cuaa;
    }

    /**
     * Sets the value of the cuaa property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCUAA(String value) {
        this.cuaa = value;
    }

    /**
     * Gets the value of the tipoMacchina property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTipoMacchina() {
        return tipoMacchina;
    }

    /**
     * Sets the value of the tipoMacchina property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTipoMacchina(String value) {
        this.tipoMacchina = value;
    }

    /**
     * Gets the value of the formaPossesso property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFormaPossesso() {
        return formaPossesso;
    }

    /**
     * Sets the value of the formaPossesso property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFormaPossesso(String value) {
        this.formaPossesso = value;
    }

    /**
     * Gets the value of the targa property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTarga() {
        return targa;
    }

    /**
     * Sets the value of the targa property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTarga(String value) {
        this.targa = value;
    }

    /**
     * Gets the value of the tipoTarga property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTipoTarga() {
        return tipoTarga;
    }

    /**
     * Sets the value of the tipoTarga property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTipoTarga(String value) {
        this.tipoTarga = value;
    }

    /**
     * Gets the value of the marca property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMarca() {
        return marca;
    }

    /**
     * Sets the value of the marca property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMarca(String value) {
        this.marca = value;
    }

    /**
     * Gets the value of the modello property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getModello() {
        return modello;
    }

    /**
     * Sets the value of the modello property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setModello(String value) {
        this.modello = value;
    }

    /**
     * Gets the value of the telaio property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTelaio() {
        return telaio;
    }

    /**
     * Sets the value of the telaio property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTelaio(String value) {
        this.telaio = value;
    }

    /**
     * Gets the value of the carburante property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getCarburante() {
        return carburante;
    }

    /**
     * Sets the value of the carburante property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setCarburante(JAXBElement<String> value) {
        this.carburante = value;
    }

    /**
     * Gets the value of the trazione property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getTrazione() {
        return trazione;
    }

    /**
     * Sets the value of the trazione property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setTrazione(JAXBElement<String> value) {
        this.trazione = value;
    }

    /**
     * Gets the value of the dataIscrizione property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDataIscrizione() {
        return dataIscrizione;
    }

    /**
     * Sets the value of the dataIscrizione property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDataIscrizione(String value) {
        this.dataIscrizione = value;
    }

    /**
     * Gets the value of the dataCessazione property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDataCessazione() {
        return dataCessazione;
    }

    /**
     * Sets the value of the dataCessazione property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDataCessazione(String value) {
        this.dataCessazione = value;
    }

}
