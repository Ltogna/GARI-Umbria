package com.abacogroup.gari.dataimporter.DTOs;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.NoArgsConstructor;

@JsonIgnoreProperties(ignoreUnknown = true)
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class LauServicesResponse {

	@JsonProperty("code")
	private String code;

	@JsonProperty("tenantId")
	private String tenantId;

	@JsonProperty("districtCode")
	private String districtCode;

	@JsonProperty("shortDescr")
	private String shortDescr;

	@JsonProperty("active")
	private boolean active;

	@JsonProperty("i18nName")
	private String i18nName;

	@JsonProperty("district")
	private District district;

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getTenantId() {
		return tenantId;
	}

	public void setTenantId(String tenantId) {
		this.tenantId = tenantId;
	}

	public String getDistrictCode() {
		return districtCode;
	}

	public void setDistrictCode(String districtCode) {
		this.districtCode = districtCode;
	}

	public String getShortDescr() {
		return shortDescr;
	}

	public void setShortDescr(String shortDescr) {
		this.shortDescr = shortDescr;
	}

	public boolean isActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	public String getI18nName() {
		return i18nName;
	}

	public void setI18nName(String i18nName) {
		this.i18nName = i18nName;
	}

	public District getDistrict() {
		return district;
	}

	public void setDistrict(District district) {
		this.district = district;
	}

	@JsonIgnoreProperties(ignoreUnknown = true)
	@Builder
	@AllArgsConstructor
	@NoArgsConstructor
	public static class District {

		@JsonProperty("code")
		private String code;

		@JsonProperty("tenantId")
		private String tenantId;

		@JsonProperty("regionCode")
		private String regionCode;

		@JsonProperty("shortDescr")
		private String shortDescr;

		@JsonProperty("active")
		private boolean active;

		@JsonProperty("i18nName")
		private String i18nName;

		@JsonProperty("region")
		private Region region;
		public String getCode() {
			return code;
		}

		public void setCode(String code) {
			this.code = code;
		}

		public String getTenantId() {
			return tenantId;
		}

		public void setTenantId(String tenantId) {
			this.tenantId = tenantId;
		}

		public String getRegionCode() {
			return regionCode;
		}

		public void setRegionCode(String regionCode) {
			this.regionCode = regionCode;
		}

		public String getShortDescr() {
			return shortDescr;
		}

		public void setShortDescr(String shortDescr) {
			this.shortDescr = shortDescr;
		}

		public boolean isActive() {
			return active;
		}

		public void setActive(boolean active) {
			this.active = active;
		}

		public String getI18nName() {
			return i18nName;
		}

		public void setI18nName(String i18nName) {
			this.i18nName = i18nName;
		}

		public Region getRegion() {
			return region;
		}

		public void setRegion(Region region) {
			this.region = region;
		}
	}

	@JsonIgnoreProperties(ignoreUnknown = true)
	@Builder
	@AllArgsConstructor
	@NoArgsConstructor
	public static class Region {

		@JsonProperty("code")
		private String code;

		@JsonProperty("tenantId")
		private String tenantId;

		@JsonProperty("countryCode")
		private String countryCode;

		@JsonProperty("shortDescr")
		private String shortDescr;

		@JsonProperty("active")
		private boolean active;

		@JsonProperty("i18nName")
		private String i18nName;

		@JsonProperty("country")
		private Country country;

		public String getCode() {
			return code;
		}

		public void setCode(String code) {
			this.code = code;
		}

		public String getTenantId() {
			return tenantId;
		}

		public void setTenantId(String tenantId) {
			this.tenantId = tenantId;
		}

		public String getCountryCode() {
			return countryCode;
		}

		public void setCountryCode(String countryCode) {
			this.countryCode = countryCode;
		}

		public String getShortDescr() {
			return shortDescr;
		}

		public void setShortDescr(String shortDescr) {
			this.shortDescr = shortDescr;
		}

		public boolean isActive() {
			return active;
		}

		public void setActive(boolean active) {
			this.active = active;
		}

		public String getI18nName() {
			return i18nName;
		}

		public void setI18nName(String i18nName) {
			this.i18nName = i18nName;
		}

		public Country getCountry() {
			return country;
		}

		public void setCountry(Country country) {
			this.country = country;
		}
	}

	@JsonIgnoreProperties(ignoreUnknown = true)
	@Builder
	@AllArgsConstructor
	@NoArgsConstructor
	public static class Country {

		@JsonProperty("code")
		private String code;

		@JsonProperty("tenantId")
		private String tenantId;

		@JsonProperty("active")
		private boolean active;

		@JsonProperty("i18nName")
		private String i18nName;

		public String getCode() {
			return code;
		}

		public void setCode(String code) {
			this.code = code;
		}

		public String getTenantId() {
			return tenantId;
		}

		public void setTenantId(String tenantId) {
			this.tenantId = tenantId;
		}

		public boolean isActive() {
			return active;
		}

		public void setActive(boolean active) {
			this.active = active;
		}

		public String getI18nName() {
			return i18nName;
		}

		public void setI18nName(String i18nName) {
			this.i18nName = i18nName;
		}
	}
}
