
package com.abacogroup.gari.dataimporter.soap.fascicolo;

import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlRootElement;
import jakarta.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Cuaa" type="{http://cooperazione.sian.it/schema/fascicolo}Cuaa"/&gt;
 *         &lt;element name="Servizio"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;enumeration value="ScriviConsistenzaAsync"/&gt;
 *               &lt;enumeration value="ScriviConsistenzaFS2Async"/&gt;
 *               &lt;enumeration value="ScriviConsistenzaFS5Async"/&gt;
 *               &lt;enumeration value="ScriviConsistenzaFS51Async"/&gt;
 *               &lt;enumeration value="ScriviConsistenzaFS6Async"/&gt;
 *               &lt;enumeration value="ScriviAllevamentiFS5Async"/&gt;
 *               &lt;enumeration value="LeggiConsistenzaFS6Async"/&gt;
 *               &lt;enumeration value="LeggiConsistenzaCFS6Async"/&gt;
 *               &lt;enumeration value="LeggiConsistenzaFS7Async"/&gt;
 *               &lt;enumeration value="LeggiConsistenzaCFS7Async"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="Idxml" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "cuaa",
    "servizio",
    "idxml"
})
@XmlRootElement(name = "ISWSEsitoServiziAsync")
public class ISWSEsitoServiziAsync {

    @XmlElement(name = "Cuaa", required = true)
    protected String cuaa;
    @XmlElement(name = "Servizio", required = true)
    protected String servizio;
    @XmlElement(name = "Idxml", required = true, nillable = true)
    protected String idxml;

    /**
     * Gets the value of the cuaa property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCuaa() {
        return cuaa;
    }

    /**
     * Sets the value of the cuaa property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCuaa(String value) {
        this.cuaa = value;
    }

    /**
     * Gets the value of the servizio property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getServizio() {
        return servizio;
    }

    /**
     * Sets the value of the servizio property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setServizio(String value) {
        this.servizio = value;
    }

    /**
     * Gets the value of the idxml property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIdxml() {
        return idxml;
    }

    /**
     * Sets the value of the idxml property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIdxml(String value) {
        this.idxml = value;
    }

}
