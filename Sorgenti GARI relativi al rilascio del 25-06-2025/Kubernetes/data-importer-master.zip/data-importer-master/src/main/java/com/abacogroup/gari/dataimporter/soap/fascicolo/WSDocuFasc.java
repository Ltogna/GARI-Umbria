
package com.abacogroup.gari.dataimporter.soap.fascicolo;

import jakarta.xml.bind.JAXBElement;
import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlElementRef;
import jakarta.xml.bind.annotation.XmlType;


/**
 * <p>Java class for WSDocuFasc complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="WSDocuFasc"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="TipologiaDocumento"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;enumeration value="456"/&gt;
 *               &lt;enumeration value="1358"/&gt;
 *               &lt;enumeration value="1359"/&gt;
 *               &lt;enumeration value="1360"/&gt;
 *               &lt;enumeration value="1361"/&gt;
 *               &lt;enumeration value="1362"/&gt;
 *               &lt;enumeration value="1363"/&gt;
 *               &lt;enumeration value="1365"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="NumeroDocumento"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;maxLength value="100"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="DataRilascio" type="{http://cooperazione.sian.it/schema/fascicolo}Data"/&gt;
 *         &lt;element name="DataScadenza" type="{http://cooperazione.sian.it/schema/fascicolo}Data"/&gt;
 *         &lt;element name="CuaaDefunto" type="{http://cooperazione.sian.it/schema/fascicolo}Cuaa" minOccurs="0"/&gt;
 *         &lt;element name="DataEvento" type="{http://cooperazione.sian.it/schema/fascicolo}Data" minOccurs="0"/&gt;
 *         &lt;element name="CuaaSoggDelegato" type="{http://cooperazione.sian.it/schema/fascicolo}Cuaa" minOccurs="0"/&gt;
 *         &lt;element name="NumeroEredi" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;maxLength value="2"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="TipoDocuRico" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;length value="1"/&gt;
 *               &lt;enumeration value="1"/&gt;
 *               &lt;enumeration value="2"/&gt;
 *               &lt;enumeration value="3"/&gt;
 *               &lt;enumeration value="4"/&gt;
 *               &lt;enumeration value="5"/&gt;
 *               &lt;enumeration value="6"/&gt;
 *               &lt;enumeration value="7"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="NumeroDocuRico" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;maxLength value="16"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="DataScadDocuRico" type="{http://cooperazione.sian.it/schema/fascicolo}Data" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "WSDocuFasc", propOrder = {
    "tipologiaDocumento",
    "numeroDocumento",
    "dataRilascio",
    "dataScadenza",
    "cuaaDefunto",
    "dataEvento",
    "cuaaSoggDelegato",
    "numeroEredi",
    "tipoDocuRico",
    "numeroDocuRico",
    "dataScadDocuRico"
})
public class WSDocuFasc {

    @XmlElement(name = "TipologiaDocumento", required = true)
    protected String tipologiaDocumento;
    @XmlElement(name = "NumeroDocumento", required = true)
    protected String numeroDocumento;
    @XmlElement(name = "DataRilascio", required = true)
    protected String dataRilascio;
    @XmlElement(name = "DataScadenza", required = true)
    protected String dataScadenza;
    @XmlElementRef(name = "CuaaDefunto", namespace = "http://cooperazione.sian.it/schema/fascicolo", type = JAXBElement.class, required = false)
    protected JAXBElement<String> cuaaDefunto;
    @XmlElementRef(name = "DataEvento", namespace = "http://cooperazione.sian.it/schema/fascicolo", type = JAXBElement.class, required = false)
    protected JAXBElement<String> dataEvento;
    @XmlElementRef(name = "CuaaSoggDelegato", namespace = "http://cooperazione.sian.it/schema/fascicolo", type = JAXBElement.class, required = false)
    protected JAXBElement<String> cuaaSoggDelegato;
    @XmlElementRef(name = "NumeroEredi", namespace = "http://cooperazione.sian.it/schema/fascicolo", type = JAXBElement.class, required = false)
    protected JAXBElement<String> numeroEredi;
    @XmlElementRef(name = "TipoDocuRico", namespace = "http://cooperazione.sian.it/schema/fascicolo", type = JAXBElement.class, required = false)
    protected JAXBElement<String> tipoDocuRico;
    @XmlElementRef(name = "NumeroDocuRico", namespace = "http://cooperazione.sian.it/schema/fascicolo", type = JAXBElement.class, required = false)
    protected JAXBElement<String> numeroDocuRico;
    @XmlElementRef(name = "DataScadDocuRico", namespace = "http://cooperazione.sian.it/schema/fascicolo", type = JAXBElement.class, required = false)
    protected JAXBElement<String> dataScadDocuRico;

    /**
     * Gets the value of the tipologiaDocumento property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTipologiaDocumento() {
        return tipologiaDocumento;
    }

    /**
     * Sets the value of the tipologiaDocumento property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTipologiaDocumento(String value) {
        this.tipologiaDocumento = value;
    }

    /**
     * Gets the value of the numeroDocumento property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNumeroDocumento() {
        return numeroDocumento;
    }

    /**
     * Sets the value of the numeroDocumento property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNumeroDocumento(String value) {
        this.numeroDocumento = value;
    }

    /**
     * Gets the value of the dataRilascio property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDataRilascio() {
        return dataRilascio;
    }

    /**
     * Sets the value of the dataRilascio property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDataRilascio(String value) {
        this.dataRilascio = value;
    }

    /**
     * Gets the value of the dataScadenza property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDataScadenza() {
        return dataScadenza;
    }

    /**
     * Sets the value of the dataScadenza property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDataScadenza(String value) {
        this.dataScadenza = value;
    }

    /**
     * Gets the value of the cuaaDefunto property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getCuaaDefunto() {
        return cuaaDefunto;
    }

    /**
     * Sets the value of the cuaaDefunto property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setCuaaDefunto(JAXBElement<String> value) {
        this.cuaaDefunto = value;
    }

    /**
     * Gets the value of the dataEvento property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getDataEvento() {
        return dataEvento;
    }

    /**
     * Sets the value of the dataEvento property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setDataEvento(JAXBElement<String> value) {
        this.dataEvento = value;
    }

    /**
     * Gets the value of the cuaaSoggDelegato property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getCuaaSoggDelegato() {
        return cuaaSoggDelegato;
    }

    /**
     * Sets the value of the cuaaSoggDelegato property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setCuaaSoggDelegato(JAXBElement<String> value) {
        this.cuaaSoggDelegato = value;
    }

    /**
     * Gets the value of the numeroEredi property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getNumeroEredi() {
        return numeroEredi;
    }

    /**
     * Sets the value of the numeroEredi property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setNumeroEredi(JAXBElement<String> value) {
        this.numeroEredi = value;
    }

    /**
     * Gets the value of the tipoDocuRico property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getTipoDocuRico() {
        return tipoDocuRico;
    }

    /**
     * Sets the value of the tipoDocuRico property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setTipoDocuRico(JAXBElement<String> value) {
        this.tipoDocuRico = value;
    }

    /**
     * Gets the value of the numeroDocuRico property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getNumeroDocuRico() {
        return numeroDocuRico;
    }

    /**
     * Sets the value of the numeroDocuRico property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setNumeroDocuRico(JAXBElement<String> value) {
        this.numeroDocuRico = value;
    }

    /**
     * Gets the value of the dataScadDocuRico property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getDataScadDocuRico() {
        return dataScadDocuRico;
    }

    /**
     * Sets the value of the dataScadDocuRico property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setDataScadDocuRico(JAXBElement<String> value) {
        this.dataScadDocuRico = value;
    }

}
