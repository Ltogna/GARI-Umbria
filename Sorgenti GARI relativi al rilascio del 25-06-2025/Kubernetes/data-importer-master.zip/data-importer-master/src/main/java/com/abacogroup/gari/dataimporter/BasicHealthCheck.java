package com.abacogroup.gari.dataimporter;

import com.codahale.metrics.health.HealthCheck;

public class BasicHealthCheck extends HealthCheck {
	@Override
	protected Result check() throws Exception {
		// For demonstration, always return healthy
		return Result.healthy();
	}
}
