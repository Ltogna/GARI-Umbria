
package com.abacogroup.gari.dataimporter.soap.fascicolo;

import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlRootElement;
import jakarta.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="ISWReqScheda" type="{http://cooperazione.sian.it/schema/fascicolo}ISWReqScheda"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "iswReqScheda"
})
@XmlRootElement(name = "RichiestaScheda")
public class RichiestaScheda {

    @XmlElement(name = "ISWReqScheda", required = true)
    protected ISWReqScheda iswReqScheda;

    /**
     * Gets the value of the iswReqScheda property.
     * 
     * @return
     *     possible object is
     *     {@link ISWReqScheda }
     *     
     */
    public ISWReqScheda getISWReqScheda() {
        return iswReqScheda;
    }

    /**
     * Sets the value of the iswReqScheda property.
     * 
     * @param value
     *     allowed object is
     *     {@link ISWReqScheda }
     *     
     */
    public void setISWReqScheda(ISWReqScheda value) {
        this.iswReqScheda = value;
    }

}
