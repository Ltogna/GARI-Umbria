
package com.abacogroup.gari.dataimporter.soap.fascicolo;

import java.util.ArrayList;
import java.util.List;
import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlRootElement;
import jakarta.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;sequence minOccurs="0"&gt;
 *           &lt;element ref="{http://cooperazione.sian.it/schema/fascicolo}SoggettoWS"/&gt;
 *         &lt;/sequence&gt;
 *         &lt;sequence maxOccurs="unbounded" minOccurs="0"&gt;
 *           &lt;element ref="{http://cooperazione.sian.it/schema/fascicolo}RecapitoWS"/&gt;
 *         &lt;/sequence&gt;
 *         &lt;sequence maxOccurs="unbounded" minOccurs="0"&gt;
 *           &lt;element ref="{http://cooperazione.sian.it/schema/fascicolo}ContoCorrenteWS"/&gt;
 *         &lt;/sequence&gt;
 *         &lt;element name="Data_iniz_rapp" type="{http://cooperazione.sian.it/schema/fascicolo}Data"/&gt;
 *         &lt;element name="Deco_tipo_cari"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}int"&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="Data_fine_rapp" type="{http://cooperazione.sian.it/schema/fascicolo}Data"/&gt;
 *         &lt;element name="Deco_font_dato"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}int"&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "soggettoWS",
    "recapitoWS",
    "contoCorrenteWS",
    "dataInizRapp",
    "decoTipoCari",
    "dataFineRapp",
    "decoFontDato"
})
@XmlRootElement(name = "RappresentanteLegaleWS")
public class RappresentanteLegaleWS {

    @XmlElement(name = "SoggettoWS")
    protected SoggettoWS soggettoWS;
    @XmlElement(name = "RecapitoWS")
    protected List<RecapitoWS> recapitoWS;
    @XmlElement(name = "ContoCorrenteWS")
    protected List<ContoCorrenteWS> contoCorrenteWS;
    @XmlElement(name = "Data_iniz_rapp", required = true)
    protected String dataInizRapp;
    @XmlElement(name = "Deco_tipo_cari", required = true, type = Integer.class, nillable = true)
    protected Integer decoTipoCari;
    @XmlElement(name = "Data_fine_rapp", required = true)
    protected String dataFineRapp;
    @XmlElement(name = "Deco_font_dato", required = true, type = Integer.class, nillable = true)
    protected Integer decoFontDato;

    /**
     * Gets the value of the soggettoWS property.
     * 
     * @return
     *     possible object is
     *     {@link SoggettoWS }
     *     
     */
    public SoggettoWS getSoggettoWS() {
        return soggettoWS;
    }

    /**
     * Sets the value of the soggettoWS property.
     * 
     * @param value
     *     allowed object is
     *     {@link SoggettoWS }
     *     
     */
    public void setSoggettoWS(SoggettoWS value) {
        this.soggettoWS = value;
    }

    /**
     * Gets the value of the recapitoWS property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the Jakarta XML Binding object.
     * This is why there is not a <CODE>set</CODE> method for the recapitoWS property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getRecapitoWS().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link RecapitoWS }
     * 
     * 
     */
    public List<RecapitoWS> getRecapitoWS() {
        if (recapitoWS == null) {
            recapitoWS = new ArrayList<RecapitoWS>();
        }
        return this.recapitoWS;
    }

    /**
     * Gets the value of the contoCorrenteWS property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the Jakarta XML Binding object.
     * This is why there is not a <CODE>set</CODE> method for the contoCorrenteWS property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getContoCorrenteWS().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ContoCorrenteWS }
     * 
     * 
     */
    public List<ContoCorrenteWS> getContoCorrenteWS() {
        if (contoCorrenteWS == null) {
            contoCorrenteWS = new ArrayList<ContoCorrenteWS>();
        }
        return this.contoCorrenteWS;
    }

    /**
     * Gets the value of the dataInizRapp property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDataInizRapp() {
        return dataInizRapp;
    }

    /**
     * Sets the value of the dataInizRapp property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDataInizRapp(String value) {
        this.dataInizRapp = value;
    }

    /**
     * Gets the value of the decoTipoCari property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getDecoTipoCari() {
        return decoTipoCari;
    }

    /**
     * Sets the value of the decoTipoCari property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setDecoTipoCari(Integer value) {
        this.decoTipoCari = value;
    }

    /**
     * Gets the value of the dataFineRapp property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDataFineRapp() {
        return dataFineRapp;
    }

    /**
     * Sets the value of the dataFineRapp property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDataFineRapp(String value) {
        this.dataFineRapp = value;
    }

    /**
     * Gets the value of the decoFontDato property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getDecoFontDato() {
        return decoFontDato;
    }

    /**
     * Sets the value of the decoFontDato property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setDecoFontDato(Integer value) {
        this.decoFontDato = value;
    }

}
