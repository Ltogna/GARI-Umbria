package com.abacogroup.gari.dataimporter.Interfaces;

import java.time.OffsetDateTime;

import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.gari.dataimporter.DTOs.AnagraficaResponse;
import com.abacogroup.gari.dataimporter.DTOs.CropPlanVersionWithInfo;
import com.abacogroup.gari.dataimporter.DTOs.PCGCropPlanResponse;
import com.abacogroup.jdbi.paging.InfiniteListResults;

public interface ICropPlanService {
	void ImportCropPlan(User user, String tenanId, String cuaa, Integer campagna, String requestId);

	InfiniteListResults<PCGCropPlanResponse> findPCGCropPlanByCuaa(User user, String tenant, String cuaa,
			Integer campagna, String nextKey);

	InfiniteListResults<PCGCropPlanResponse> deltaHandling(User user, String tenant, String cuaa,
			OffsetDateTime reftimestamp);

	AnagraficaResponse findAnagraficaByCuaa(User user, String tenant, String cuaa);

	InfiniteListResults<AnagraficaResponse> findAnagraficaListByCuaa(User user, String tenant, String cuaa,
			OffsetDateTime requestTime, String nextKey);

	CropPlanVersionWithInfo getCropPlanVersionWithInfo(String tenant, Long businessId, Long cropPlanId);
}
