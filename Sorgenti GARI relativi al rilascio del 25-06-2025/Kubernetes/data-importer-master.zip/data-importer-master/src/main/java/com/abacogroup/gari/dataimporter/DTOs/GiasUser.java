package com.abacogroup.gari.dataimporter.DTOs;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

/**
 * 
 * @author Emanuele Crocilla
 *
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class GiasUser {

	@JsonProperty("username")
	private String username;

	@JsonProperty("cognome")
	private String cognome;

	@JsonProperty("nome")
	private String nome;

	@JsonProperty("codice_Fiscale")
	private String codiceFiscale;

	@JsonProperty("mail")
	private String mail;

	@JsonProperty("bloccato")
	private Boolean bloccato;

	@JsonProperty("spid")
	private Boolean spid;

	@JsonProperty("ruoli")
	private List<UserRole> userRoles;

	@Data
	@Builder
	@NoArgsConstructor
	@AllArgsConstructor
	@ToString
	@JsonInclude(JsonInclude.Include.NON_NULL) // Exclude null fields during serialization
	public static class UserRole {
		
		@JsonProperty("roleCode")
		private String roleCode;
		
	}
}
