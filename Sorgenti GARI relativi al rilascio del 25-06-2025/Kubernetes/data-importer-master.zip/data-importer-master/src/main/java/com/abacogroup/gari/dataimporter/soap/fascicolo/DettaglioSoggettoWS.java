
package com.abacogroup.gari.dataimporter.soap.fascicolo;

import java.util.ArrayList;
import java.util.List;
import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlType;


/**
 * <p>Java class for DettaglioSoggettoWS complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DettaglioSoggettoWS"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;sequence&gt;
 *           &lt;element ref="{http://cooperazione.sian.it/schema/fascicolo}SoggettoWS"/&gt;
 *         &lt;/sequence&gt;
 *         &lt;sequence maxOccurs="unbounded" minOccurs="0"&gt;
 *           &lt;element ref="{http://cooperazione.sian.it/schema/fascicolo}RecapitoWS"/&gt;
 *         &lt;/sequence&gt;
 *         &lt;sequence maxOccurs="unbounded" minOccurs="0"&gt;
 *           &lt;element ref="{http://cooperazione.sian.it/schema/fascicolo}ContoCorrenteWS"/&gt;
 *         &lt;/sequence&gt;
 *         &lt;sequence maxOccurs="unbounded" minOccurs="0"&gt;
 *           &lt;element ref="{http://cooperazione.sian.it/schema/fascicolo}RappresentanteLegaleWS"/&gt;
 *         &lt;/sequence&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DettaglioSoggettoWS", propOrder = {
    "soggettoWS",
    "recapitoWS",
    "contoCorrenteWS",
    "rappresentanteLegaleWS"
})
public class DettaglioSoggettoWS {

    @XmlElement(name = "SoggettoWS", required = true)
    protected SoggettoWS soggettoWS;
    @XmlElement(name = "RecapitoWS")
    protected List<RecapitoWS> recapitoWS;
    @XmlElement(name = "ContoCorrenteWS")
    protected List<ContoCorrenteWS> contoCorrenteWS;
    @XmlElement(name = "RappresentanteLegaleWS")
    protected List<RappresentanteLegaleWS> rappresentanteLegaleWS;

    /**
     * Gets the value of the soggettoWS property.
     * 
     * @return
     *     possible object is
     *     {@link SoggettoWS }
     *     
     */
    public SoggettoWS getSoggettoWS() {
        return soggettoWS;
    }

    /**
     * Sets the value of the soggettoWS property.
     * 
     * @param value
     *     allowed object is
     *     {@link SoggettoWS }
     *     
     */
    public void setSoggettoWS(SoggettoWS value) {
        this.soggettoWS = value;
    }

    /**
     * Gets the value of the recapitoWS property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the Jakarta XML Binding object.
     * This is why there is not a <CODE>set</CODE> method for the recapitoWS property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getRecapitoWS().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link RecapitoWS }
     * 
     * 
     */
    public List<RecapitoWS> getRecapitoWS() {
        if (recapitoWS == null) {
            recapitoWS = new ArrayList<RecapitoWS>();
        }
        return this.recapitoWS;
    }

    /**
     * Gets the value of the contoCorrenteWS property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the Jakarta XML Binding object.
     * This is why there is not a <CODE>set</CODE> method for the contoCorrenteWS property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getContoCorrenteWS().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ContoCorrenteWS }
     * 
     * 
     */
    public List<ContoCorrenteWS> getContoCorrenteWS() {
        if (contoCorrenteWS == null) {
            contoCorrenteWS = new ArrayList<ContoCorrenteWS>();
        }
        return this.contoCorrenteWS;
    }

    /**
     * Gets the value of the rappresentanteLegaleWS property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the Jakarta XML Binding object.
     * This is why there is not a <CODE>set</CODE> method for the rappresentanteLegaleWS property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getRappresentanteLegaleWS().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link RappresentanteLegaleWS }
     * 
     * 
     */
    public List<RappresentanteLegaleWS> getRappresentanteLegaleWS() {
        if (rappresentanteLegaleWS == null) {
            rappresentanteLegaleWS = new ArrayList<RappresentanteLegaleWS>();
        }
        return this.rappresentanteLegaleWS;
    }

}
