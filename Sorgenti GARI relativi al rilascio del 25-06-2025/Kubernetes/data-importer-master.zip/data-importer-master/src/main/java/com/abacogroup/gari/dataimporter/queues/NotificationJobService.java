package com.abacogroup.gari.dataimporter.queues;

import com.abacogroup.gari.dataimporter.DTOs.CropPlanCommitPayload;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class NotificationJobService {
	private String requestId;
	private CropPlanCommitPayload commitPayload;

	public NotificationJobService(CropPlanCommitPayload _commitPayload, String requestId) {
		this.requestId = requestId;
		this.commitPayload = _commitPayload;
	}

	public String getRequestId() {
		return requestId;
	}

	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}

}
