package com.abacogroup.gari.dataimporter.services;

import java.io.IOException;
import java.net.URL;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.Semaphore;
import java.util.concurrent.TimeUnit;

import com.abacogroup.dropwizard.auth.sso2.Sso2Client;
import com.abacogroup.gari.dataimporter.DataImporterConfiguration;
import com.abacogroup.gari.dataimporter.DTOs.FieldDefinition;
import com.abacogroup.gari.dataimporter.DTOs.LauServicesResponse;
import com.abacogroup.gari.dataimporter.DTOs.RecordResponse;
import com.abacogroup.gari.dataimporter.config.SianSoapCredentials;
import com.abacogroup.gari.dataimporter.db.dao.LoggerDAO;
import com.abacogroup.gari.dataimporter.soap.OprFascicoloFS6ServiceName;
import com.abacogroup.gari.dataimporter.soap.fascicolo.ISWSIndirizzo;
import com.abacogroup.gari.dataimporter.soap.fascicolo.ISWSRespAnagFascicolo15;
import com.abacogroup.gari.dataimporter.soap.fascicolo.ISWSToOprResponse;
import com.abacogroup.gari.dataimporter.soap.fascicolo.InterService;
import com.abacogroup.gari.dataimporter.soap.fascicolo.ObjectFactory;
import com.abacogroup.gari.dataimporter.soap.fascicolo.OprFascicoloFS6;
import com.abacogroup.gari.dataimporter.soap.fascicolo.SOAPAutenticazione;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.partyregistry.api.GenderEnum;
import com.abacogroup.partyregistry.api.PartyTypeEnum;
import com.abacogroup.partyregistry.dto.v1.AddressExternalDtoV1;
import com.abacogroup.partyregistry.dto.v1.ExternalSourceDtoV1;
import com.abacogroup.partyregistry.dto.v1.PartyExternalDtoV1;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import jakarta.ws.rs.client.Client;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class ImportPartyRegistryService extends ADataImporterService {
	private static final ObjectFactory objectFactory = new ObjectFactory();
	private static final Semaphore cacheReloadSemaphore = new Semaphore(1);
	private static final ConcurrentHashMap<String, RecordResponse<LauServicesResponse>> LAU_SERVICES_CACHE = new ConcurrentHashMap<>();
	private static List<FieldDefinition> tenantDefinitions;

	private SianSoapCredentials sianSoapCredentials;

	public ImportPartyRegistryService(Sso2Client _sso2Client, Client _client, DataImporterConfiguration _configuration, ObjectMapper mapper,
			LoggerDAO loggerDAO, ScheduledExecutorService executorService) {
		super(_sso2Client, _client, _configuration, mapper, loggerDAO);
		this.sianSoapCredentials = _configuration.getSianSoapCredentials();
		try {
			tenantDefinitions = loadFieldDefinitions("/tenantConfig.jsonl", "tenantConfig");
			executorService.scheduleAtFixedRate(this::reloadCache, 0, 2, TimeUnit.HOURS);
		} catch (IOException e) {
			throwDynamicException("", "", new Object(), "ImportPartyRegistryService Constructor", "Not able to load Tenant Cong file");
			throw new RuntimeException(e);
		}
	}

	public ExternalSourceDtoV1 Import(String tenantId, String cuaa) {
		URL url;
		try {
			// Load WSDL from classpath
			url = ImportPartyRegistryService.class.getResource("/wsdl/OprFascicoloFS6.wsdl");
			if (url == null) {
				throwDynamicException("URL Create", tenantId, null, "URL Create", "WSDL file not found in classpath: /wsdl/OprFascicoloFS6.wsdl");
				throw new RuntimeException("WSDL file not found in classpath: /wsdl/OprFascicoloFS6.wsdl");
			}
		} catch (Exception e) {
			throwDynamicException("URL Create", tenantId, null, "Not Found OprFascicoloFS6.wsdl", "Error locating WSDL file");
			throw new RuntimeException("Error locating WSDL file", e);
		}
		// Initialize SOAP client
		OprFascicoloFS6 oprFascicoloFS6_TEST = new OprFascicoloFS6(url);
		InterService serviceLocalWSDL = oprFascicoloFS6_TEST.getOprFascicoloFS6();
		SOAPAutenticazione soapAutenticazione = objectFactory.createSOAPAutenticazione();
		soapAutenticazione.setUsername(sianSoapCredentials.getUsername());
		soapAutenticazione.setPassword(sianSoapCredentials.getPassword());
		soapAutenticazione.setNomeServizio(OprFascicoloFS6ServiceName.TROVAFASCICOLOFS6);

		log.debug("SOAPAutenticazione: username {}, password {}, nome servizio {}", soapAutenticazione.getUsername(), soapAutenticazione.getPassword(),
				soapAutenticazione.getNomeServizio());

		// Call SOAP service
		ISWSToOprResponse iswsToOprResponse = serviceLocalWSDL.trovaFascicoloFS6(cuaa, soapAutenticazione);
		if (iswsToOprResponse == null) {
			return null;
		}

		ISWSRespAnagFascicolo15 iswsRespAnagFascicolo15 = iswsToOprResponse.getRisposta20().getValue();
		RecordResponse<LauServicesResponse> services = getCachedLauServices(tenantId, iswsRespAnagFascicolo15);
		LauServicesResponse currentService = services.getRecords().stream()
				.filter(x -> x.getCode() != null &&
						x.getCode().startsWith("ITA_") &&
						x.getCode()
								.endsWith(iswsRespAnagFascicolo15.getSedeResidenza().getProvincia() + iswsRespAnagFascicolo15.getSedeResidenza().getComune()))
				.findAny()
				.get();
		if (currentService == null) {
			throwDynamicException("Find_current_lau_service_by_Code", tenantId, iswsRespAnagFascicolo15, "Find_current_lau_service_by_Code",
					"Can not find any record that match this party!");
			throw new RuntimeException("Can not find any record that match this party!");
		}
		PartyExternalDtoV1 partyExternalDto = mapToPartyExternalDtoV1(iswsRespAnagFascicolo15, currentService, cuaa);
		return ExternalSourceDtoV1.builder()
				.setPartyData(partyExternalDto)
				.build();
	}

	public PartyExternalDtoV1 mapToPartyExternalDtoV1(ISWSRespAnagFascicolo15 response, LauServicesResponse service, String cuaa) {

		PartyExternalDtoV1 dto = new PartyExternalDtoV1();
		try {
			// Mapping partyType
			String tipoAzienda = response.getTipoAzienda();
			dto.setPartyType("PG".equals(tipoAzienda) ? PartyTypeEnum.L : PartyTypeEnum.N);
			var sessoPF = response.getSessoPF();
			dto.setGender(sessoPF != null ? GenderEnum.valueOf(sessoPF.getValue()) : null);
			dto.setLastName(response.getDenominazione());
			dto.setFirstName(response.getNomePF());
			dto.setTaxCode(cuaa);
			dto.setCode(cuaa);
			dto.setVatNumber(null);
			dto.setLegalStatus("ALTRI");
			dto.setBirthDate(convertToAbsoluteDate(response.getDataNascitaPF()));
			dto.setDeathDate(null);
			dto.setBirthMunicipality(null);
			dto.setNationality(null);
			AddressExternalDtoV1 addressResidential = getAddressExternalDtoV1(response, service);
			dto.setAddressResidential(addressResidential);
			dto.setAddressBilling(null);
		} catch (Exception ex) {
			throwDynamicException("", "", response, "Map Party Lau Service", ex.getMessage());
			throw new RuntimeException(ex);
		}
		return dto;
	}

	private static AddressExternalDtoV1 getAddressExternalDtoV1(ISWSRespAnagFascicolo15 response, LauServicesResponse service) {
		ISWSIndirizzo sedeResidenza = response.getSedeResidenza();
		AddressExternalDtoV1 addressResidential = new AddressExternalDtoV1();
		if (service != null) {
			addressResidential
					.setStreet(sedeResidenza.getIndirizzo() + (sedeResidenza.getCodiceStatoEstero() != null ? sedeResidenza.getCodiceStatoEstero() : ""));
			addressResidential.setPostcode(sedeResidenza.getCap());
			addressResidential.setMunicipality(service.getCode());
			addressResidential.setLocality(null);
			addressResidential.setHouseNumber(null);
			addressResidential.setDetails(null);
			addressResidential.setNote(null);
		}
		return addressResidential;
	}

	private static AbsoluteDate convertToAbsoluteDate(String date) {
		if (date == null || date.isEmpty()) {
			return null;
		}
		return AbsoluteDate.of(date);
	}

	private RecordResponse<LauServicesResponse> getCachedLauServices(String tenant, ISWSRespAnagFascicolo15 iswsRespAnagFascicolo15) {
		RecordResponse<LauServicesResponse> cachedResponse = LAU_SERVICES_CACHE.get(tenant);
		if (cachedResponse == null) {
			try {
				cacheReloadSemaphore.acquire();
				cachedResponse = LAU_SERVICES_CACHE.get(tenant);
				if (cachedResponse == null) {
					cachedResponse = GetLauServices(tenant, null, false);
					LAU_SERVICES_CACHE.put(tenant, cachedResponse);
				}
			} catch (InterruptedException e) {
				Thread.currentThread().interrupt();
				throw new RuntimeException("Interrupted while waiting for cache reload", e);
			} finally {
				cacheReloadSemaphore.release();
			}
		}
		return cachedResponse;
	}

	private void reloadCache() {
		try {
			cacheReloadSemaphore.acquire();
			for (FieldDefinition fieldDef : tenantDefinitions) {
				GetLauServices(fieldDef.getCode(), null, true);
			}
		} catch (InterruptedException e) {
			Thread.currentThread().interrupt();
			throw new RuntimeException("Interrupted during cache reload", e);
		} finally {
			cacheReloadSemaphore.release();
		}
	}

	private RecordResponse<LauServicesResponse> GetLauServices(String tenant, String nextKey, boolean reloadCache) {
		if (LAU_SERVICES_CACHE.containsKey(tenant) && !reloadCache) {
			return LAU_SERVICES_CACHE.get(tenant);
		}
		var response = new RecordResponse<LauServicesResponse>();
		do {
			String url = String.format("%s/%s/public/v1/municipalities?pageSize=200%s",
					lauService,
					tenant,
					nextKey != null ? "&nextKey=" + nextKey : "");
			var data = sendGetRequestWithAuth(
					url,
					new TypeReference<RecordResponse<LauServicesResponse>>() {
					},
					"Get Lau Services",
					tenant);

			if (data == null || data.getRecords() == null) {
				break;
			}
			if (response.getRecords() == null) {
				response.setRecords(data.getRecords());
			} else {
				response.getRecords().addAll(data.getRecords());
			}
			nextKey = data.getNextKey();
		} while (nextKey != null);
		LAU_SERVICES_CACHE.put(tenant, response);
		return response;
	}
}
