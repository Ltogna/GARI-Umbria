package com.abacogroup.gari.dataimporter.exceptions;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.ws.rs.core.Response.Status;

/**
 * 
 * @author Emanuele Crocilla
 *
 */
public class GiasServiceException extends AbstractWebException {
   
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private static final String ERROR_CODE = "GENERIC_GIAS_SERVICE_ERROR";

    public GiasServiceException(String errorMessage) {
        super(Status.INTERNAL_SERVER_ERROR, new ErrorBody(ERROR_CODE, errorMessage));
    }

    @Schema(name = "GiasServiceErrorBody")
    public static class ErrorBody implements ExceptionErrorBody {
        private final String code;
        private final String message;

        public ErrorBody(String code, String message) {
            this.code = code;
            this.message = message;
        }

        @Override
        @Schema(allowableValues = { ERROR_CODE })
        public String getErrorCode() {
            return code;
        }

        @Override
        @Schema
        public String getMessage() {
            return message;
        }
    }

}
