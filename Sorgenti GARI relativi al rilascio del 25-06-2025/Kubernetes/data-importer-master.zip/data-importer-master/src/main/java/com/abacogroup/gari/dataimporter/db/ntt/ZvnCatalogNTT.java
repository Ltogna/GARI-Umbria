package com.abacogroup.gari.dataimporter.db.ntt;

import com.abacogroup.gari.dataimporter.DTOs.GeoJsonFeatureCollection;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.locationtech.jts.geom.Geometry;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ZvnCatalogNTT {

	private Long id; // Primary Key
	private Double area; // Area
	private Long idRec; // ID Record
	private String regione; // Nome regione
	private String nomeZvn; // Nome ZVN
	private String type; // Feature type (e.g., Polygon)
	private Geometry geom; // GeoJSON coordinates
	private String trackingRequestId; // ULID referencing track request

}
