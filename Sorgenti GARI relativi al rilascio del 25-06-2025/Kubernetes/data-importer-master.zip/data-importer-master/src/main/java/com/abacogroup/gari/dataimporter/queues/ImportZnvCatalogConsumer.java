package com.abacogroup.gari.dataimporter.queues;

import com.abacogroup.embeddedqueue.QueueErrorListener;
import com.abacogroup.embeddedqueue.ThrowingConsumer;
import com.abacogroup.gari.dataimporter.services.ImportZnvCatalogService;

public class ImportZnvCatalogConsumer implements ThrowingConsumer<ImportZnvCatalogJobService>, QueueErrorListener<ImportZnvCatalogJobService> {

	private final ImportZnvCatalogService service;

	public ImportZnvCatalogConsumer(ImportZnvCatalogService _service) {
		this.service = _service;
	}

	@Override
	public void accept(ImportZnvCatalogJobService job) throws Exception {
		service.Import(null, job.getTenantId(), job.getXmin(), job.getYmin(), job.getXmax(), job.getYmax(), job.getEpsg(), job.getDataVal(),
				job.getRequestId());
	}

	@Override
	public ErrorAction onJobError(ImportZnvCatalogJobService job, Throwable t) {
		return ErrorAction.MARK_AS_ERRORED;
	}

}
