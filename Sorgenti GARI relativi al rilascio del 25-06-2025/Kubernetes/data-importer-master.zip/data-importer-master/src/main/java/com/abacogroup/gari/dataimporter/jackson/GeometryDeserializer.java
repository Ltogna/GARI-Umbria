package com.abacogroup.gari.dataimporter.jackson;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonDeserializer;
import org.locationtech.jts.geom.Geometry;
import org.locationtech.jts.io.ParseException;
import org.locationtech.jts.io.WKTReader;

import java.io.IOException;

public class GeometryDeserializer extends JsonDeserializer<Geometry> {

	@Override
	public Geometry deserialize(JsonParser parser, DeserializationContext context) throws IOException, JsonProcessingException {
		String wkt = parser.getText();
		WKTReader reader = new WKTReader();
		try {
			return reader.read(wkt);
		} catch (ParseException e) {
			throw new IOException("Failed to parse WKT geometry: " + wkt, e);
		}
	}
}
