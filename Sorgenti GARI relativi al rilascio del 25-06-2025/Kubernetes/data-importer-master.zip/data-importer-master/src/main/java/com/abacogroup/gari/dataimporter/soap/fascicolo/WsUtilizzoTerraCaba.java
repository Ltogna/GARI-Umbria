
package com.abacogroup.gari.dataimporter.soap.fascicolo;

import jakarta.xml.bind.JAXBElement;
import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlElementRef;
import jakarta.xml.bind.annotation.XmlType;


/**
 * <p>Java class for WsUtilizzoTerraCaba complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="WsUtilizzoTerraCaba"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="CodiceLivello" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;length value="3"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="CodiceOccupazioneSuolo"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="CodiceDestinazioneUso"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;length value="3"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="CodiceUso"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;length value="3"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="CodiceQualita"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;length value="3"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="CodiceOccupazioneVarieta" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="SuperficieUtilizzata"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}int"&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="CodiceMacrouso" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;length value="3"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="CodiceProdotto" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;length value="3"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="CodiceVarieta" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;length value="3"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="SuperficieEleggibile" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}int"&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="CodiceColtivazioneBiologica" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;enumeration value="1"/&gt;
 *               &lt;enumeration value="0"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="CodiceTipoSemina" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;enumeration value="1"/&gt;
 *               &lt;enumeration value="2"/&gt;
 *               &lt;enumeration value="3"/&gt;
 *               &lt;enumeration value="4"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="CodiceTipoIrrigazione" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;enumeration value="1"/&gt;
 *               &lt;enumeration value="2"/&gt;
 *               &lt;enumeration value="3"/&gt;
 *               &lt;enumeration value="4"/&gt;
 *               &lt;enumeration value="5"/&gt;
 *               &lt;enumeration value="6"/&gt;
 *               &lt;enumeration value="7"/&gt;
 *               &lt;enumeration value="8"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="CodiceProtezioneColture" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;enumeration value="1"/&gt;
 *               &lt;enumeration value="2"/&gt;
 *               &lt;enumeration value="3"/&gt;
 *               &lt;enumeration value="4"/&gt;
 *               &lt;enumeration value="5"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="CodiceFaseAllevamento" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;enumeration value="1"/&gt;
 *               &lt;enumeration value="2"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="CodiceFormaAllevamento" type="{http://cooperazione.sian.it/schema/fascicolo}formalle" minOccurs="0"/&gt;
 *         &lt;element name="FlagColtPrincipale" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;enumeration value="0"/&gt;
 *               &lt;enumeration value="1"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="DataInizioUtilizzo" type="{http://cooperazione.sian.it/schema/fascicolo}Data"/&gt;
 *         &lt;element name="DataFineUtilizzo" type="{http://cooperazione.sian.it/schema/fascicolo}Data"/&gt;
 *         &lt;element name="MantPratiPermanente" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;enumeration value="1"/&gt;
 *               &lt;enumeration value="2"/&gt;
 *               &lt;enumeration value="3"/&gt;
 *               &lt;enumeration value="4"/&gt;
 *               &lt;enumeration value="5"/&gt;
 *               &lt;enumeration value="6"/&gt;
 *               &lt;enumeration value="7"/&gt;
 *               &lt;enumeration value="8"/&gt;
 *               &lt;enumeration value="10"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="MantenSupAgricola" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;enumeration value="1"/&gt;
 *               &lt;enumeration value="2"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="SuperficieEleggibileOP" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}int"&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="NumeroPiante" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}int"&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="SestoImpiantoSuFila" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;maxLength value="8"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="SestoImpiantoTraFile" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;maxLength value="8"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="AnnoImpianto" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;length value="4"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="TipoImpianto" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;enumeration value="1"/&gt;
 *               &lt;enumeration value="2"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="TipoCertificazione" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;enumeration value="0"/&gt;
 *               &lt;enumeration value="1"/&gt;
 *               &lt;enumeration value="2"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="Percentuale" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;maxLength value="3"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="Menzione" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}int"&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="TipoUtilizzoOlivo" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;enumeration value="0"/&gt;
 *               &lt;enumeration value="1"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="CapacitaProduttiva" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;maxLength value="8"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="Altitudine" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}int"&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="FlagProduzioneIntegrata" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;enumeration value="1"/&gt;
 *               &lt;enumeration value="0"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "WsUtilizzoTerraCaba", propOrder = {
    "codiceLivello",
    "codiceOccupazioneSuolo",
    "codiceDestinazioneUso",
    "codiceUso",
    "codiceQualita",
    "codiceOccupazioneVarieta",
    "superficieUtilizzata",
    "codiceMacrouso",
    "codiceProdotto",
    "codiceVarieta",
    "superficieEleggibile",
    "codiceColtivazioneBiologica",
    "codiceTipoSemina",
    "codiceTipoIrrigazione",
    "codiceProtezioneColture",
    "codiceFaseAllevamento",
    "codiceFormaAllevamento",
    "flagColtPrincipale",
    "dataInizioUtilizzo",
    "dataFineUtilizzo",
    "mantPratiPermanente",
    "mantenSupAgricola",
    "superficieEleggibileOP",
    "numeroPiante",
    "sestoImpiantoSuFila",
    "sestoImpiantoTraFile",
    "annoImpianto",
    "tipoImpianto",
    "tipoCertificazione",
    "percentuale",
    "menzione",
    "tipoUtilizzoOlivo",
    "capacitaProduttiva",
    "altitudine",
    "flagProduzioneIntegrata"
})
public class WsUtilizzoTerraCaba {

    @XmlElementRef(name = "CodiceLivello", namespace = "http://cooperazione.sian.it/schema/fascicolo", type = JAXBElement.class, required = false)
    protected JAXBElement<String> codiceLivello;
    @XmlElement(name = "CodiceOccupazioneSuolo", required = true)
    protected String codiceOccupazioneSuolo;
    @XmlElement(name = "CodiceDestinazioneUso", required = true)
    protected String codiceDestinazioneUso;
    @XmlElement(name = "CodiceUso", required = true)
    protected String codiceUso;
    @XmlElement(name = "CodiceQualita", required = true)
    protected String codiceQualita;
    @XmlElementRef(name = "CodiceOccupazioneVarieta", namespace = "http://cooperazione.sian.it/schema/fascicolo", type = JAXBElement.class, required = false)
    protected JAXBElement<String> codiceOccupazioneVarieta;
    @XmlElement(name = "SuperficieUtilizzata")
    protected int superficieUtilizzata;
    @XmlElementRef(name = "CodiceMacrouso", namespace = "http://cooperazione.sian.it/schema/fascicolo", type = JAXBElement.class, required = false)
    protected JAXBElement<String> codiceMacrouso;
    @XmlElementRef(name = "CodiceProdotto", namespace = "http://cooperazione.sian.it/schema/fascicolo", type = JAXBElement.class, required = false)
    protected JAXBElement<String> codiceProdotto;
    @XmlElementRef(name = "CodiceVarieta", namespace = "http://cooperazione.sian.it/schema/fascicolo", type = JAXBElement.class, required = false)
    protected JAXBElement<String> codiceVarieta;
    @XmlElementRef(name = "SuperficieEleggibile", namespace = "http://cooperazione.sian.it/schema/fascicolo", type = JAXBElement.class, required = false)
    protected JAXBElement<Integer> superficieEleggibile;
    @XmlElementRef(name = "CodiceColtivazioneBiologica", namespace = "http://cooperazione.sian.it/schema/fascicolo", type = JAXBElement.class, required = false)
    protected JAXBElement<String> codiceColtivazioneBiologica;
    @XmlElementRef(name = "CodiceTipoSemina", namespace = "http://cooperazione.sian.it/schema/fascicolo", type = JAXBElement.class, required = false)
    protected JAXBElement<String> codiceTipoSemina;
    @XmlElementRef(name = "CodiceTipoIrrigazione", namespace = "http://cooperazione.sian.it/schema/fascicolo", type = JAXBElement.class, required = false)
    protected JAXBElement<String> codiceTipoIrrigazione;
    @XmlElementRef(name = "CodiceProtezioneColture", namespace = "http://cooperazione.sian.it/schema/fascicolo", type = JAXBElement.class, required = false)
    protected JAXBElement<String> codiceProtezioneColture;
    @XmlElementRef(name = "CodiceFaseAllevamento", namespace = "http://cooperazione.sian.it/schema/fascicolo", type = JAXBElement.class, required = false)
    protected JAXBElement<String> codiceFaseAllevamento;
    @XmlElementRef(name = "CodiceFormaAllevamento", namespace = "http://cooperazione.sian.it/schema/fascicolo", type = JAXBElement.class, required = false)
    protected JAXBElement<String> codiceFormaAllevamento;
    @XmlElementRef(name = "FlagColtPrincipale", namespace = "http://cooperazione.sian.it/schema/fascicolo", type = JAXBElement.class, required = false)
    protected JAXBElement<String> flagColtPrincipale;
    @XmlElement(name = "DataInizioUtilizzo", required = true)
    protected String dataInizioUtilizzo;
    @XmlElement(name = "DataFineUtilizzo", required = true, nillable = true)
    protected String dataFineUtilizzo;
    @XmlElementRef(name = "MantPratiPermanente", namespace = "http://cooperazione.sian.it/schema/fascicolo", type = JAXBElement.class, required = false)
    protected JAXBElement<String> mantPratiPermanente;
    @XmlElementRef(name = "MantenSupAgricola", namespace = "http://cooperazione.sian.it/schema/fascicolo", type = JAXBElement.class, required = false)
    protected JAXBElement<String> mantenSupAgricola;
    @XmlElementRef(name = "SuperficieEleggibileOP", namespace = "http://cooperazione.sian.it/schema/fascicolo", type = JAXBElement.class, required = false)
    protected JAXBElement<Integer> superficieEleggibileOP;
    @XmlElementRef(name = "NumeroPiante", namespace = "http://cooperazione.sian.it/schema/fascicolo", type = JAXBElement.class, required = false)
    protected JAXBElement<Integer> numeroPiante;
    @XmlElementRef(name = "SestoImpiantoSuFila", namespace = "http://cooperazione.sian.it/schema/fascicolo", type = JAXBElement.class, required = false)
    protected JAXBElement<String> sestoImpiantoSuFila;
    @XmlElementRef(name = "SestoImpiantoTraFile", namespace = "http://cooperazione.sian.it/schema/fascicolo", type = JAXBElement.class, required = false)
    protected JAXBElement<String> sestoImpiantoTraFile;
    @XmlElementRef(name = "AnnoImpianto", namespace = "http://cooperazione.sian.it/schema/fascicolo", type = JAXBElement.class, required = false)
    protected JAXBElement<String> annoImpianto;
    @XmlElementRef(name = "TipoImpianto", namespace = "http://cooperazione.sian.it/schema/fascicolo", type = JAXBElement.class, required = false)
    protected JAXBElement<String> tipoImpianto;
    @XmlElementRef(name = "TipoCertificazione", namespace = "http://cooperazione.sian.it/schema/fascicolo", type = JAXBElement.class, required = false)
    protected JAXBElement<String> tipoCertificazione;
    @XmlElementRef(name = "Percentuale", namespace = "http://cooperazione.sian.it/schema/fascicolo", type = JAXBElement.class, required = false)
    protected JAXBElement<String> percentuale;
    @XmlElementRef(name = "Menzione", namespace = "http://cooperazione.sian.it/schema/fascicolo", type = JAXBElement.class, required = false)
    protected JAXBElement<Integer> menzione;
    @XmlElementRef(name = "TipoUtilizzoOlivo", namespace = "http://cooperazione.sian.it/schema/fascicolo", type = JAXBElement.class, required = false)
    protected JAXBElement<String> tipoUtilizzoOlivo;
    @XmlElementRef(name = "CapacitaProduttiva", namespace = "http://cooperazione.sian.it/schema/fascicolo", type = JAXBElement.class, required = false)
    protected JAXBElement<String> capacitaProduttiva;
    @XmlElementRef(name = "Altitudine", namespace = "http://cooperazione.sian.it/schema/fascicolo", type = JAXBElement.class, required = false)
    protected JAXBElement<Integer> altitudine;
    @XmlElementRef(name = "FlagProduzioneIntegrata", namespace = "http://cooperazione.sian.it/schema/fascicolo", type = JAXBElement.class, required = false)
    protected JAXBElement<String> flagProduzioneIntegrata;

    /**
     * Gets the value of the codiceLivello property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getCodiceLivello() {
        return codiceLivello;
    }

    /**
     * Sets the value of the codiceLivello property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setCodiceLivello(JAXBElement<String> value) {
        this.codiceLivello = value;
    }

    /**
     * Gets the value of the codiceOccupazioneSuolo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodiceOccupazioneSuolo() {
        return codiceOccupazioneSuolo;
    }

    /**
     * Sets the value of the codiceOccupazioneSuolo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodiceOccupazioneSuolo(String value) {
        this.codiceOccupazioneSuolo = value;
    }

    /**
     * Gets the value of the codiceDestinazioneUso property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodiceDestinazioneUso() {
        return codiceDestinazioneUso;
    }

    /**
     * Sets the value of the codiceDestinazioneUso property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodiceDestinazioneUso(String value) {
        this.codiceDestinazioneUso = value;
    }

    /**
     * Gets the value of the codiceUso property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodiceUso() {
        return codiceUso;
    }

    /**
     * Sets the value of the codiceUso property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodiceUso(String value) {
        this.codiceUso = value;
    }

    /**
     * Gets the value of the codiceQualita property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodiceQualita() {
        return codiceQualita;
    }

    /**
     * Sets the value of the codiceQualita property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodiceQualita(String value) {
        this.codiceQualita = value;
    }

    /**
     * Gets the value of the codiceOccupazioneVarieta property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getCodiceOccupazioneVarieta() {
        return codiceOccupazioneVarieta;
    }

    /**
     * Sets the value of the codiceOccupazioneVarieta property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setCodiceOccupazioneVarieta(JAXBElement<String> value) {
        this.codiceOccupazioneVarieta = value;
    }

    /**
     * Gets the value of the superficieUtilizzata property.
     * 
     */
    public int getSuperficieUtilizzata() {
        return superficieUtilizzata;
    }

    /**
     * Sets the value of the superficieUtilizzata property.
     * 
     */
    public void setSuperficieUtilizzata(int value) {
        this.superficieUtilizzata = value;
    }

    /**
     * Gets the value of the codiceMacrouso property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getCodiceMacrouso() {
        return codiceMacrouso;
    }

    /**
     * Sets the value of the codiceMacrouso property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setCodiceMacrouso(JAXBElement<String> value) {
        this.codiceMacrouso = value;
    }

    /**
     * Gets the value of the codiceProdotto property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getCodiceProdotto() {
        return codiceProdotto;
    }

    /**
     * Sets the value of the codiceProdotto property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setCodiceProdotto(JAXBElement<String> value) {
        this.codiceProdotto = value;
    }

    /**
     * Gets the value of the codiceVarieta property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getCodiceVarieta() {
        return codiceVarieta;
    }

    /**
     * Sets the value of the codiceVarieta property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setCodiceVarieta(JAXBElement<String> value) {
        this.codiceVarieta = value;
    }

    /**
     * Gets the value of the superficieEleggibile property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Integer }{@code >}
     *     
     */
    public JAXBElement<Integer> getSuperficieEleggibile() {
        return superficieEleggibile;
    }

    /**
     * Sets the value of the superficieEleggibile property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Integer }{@code >}
     *     
     */
    public void setSuperficieEleggibile(JAXBElement<Integer> value) {
        this.superficieEleggibile = value;
    }

    /**
     * Gets the value of the codiceColtivazioneBiologica property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getCodiceColtivazioneBiologica() {
        return codiceColtivazioneBiologica;
    }

    /**
     * Sets the value of the codiceColtivazioneBiologica property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setCodiceColtivazioneBiologica(JAXBElement<String> value) {
        this.codiceColtivazioneBiologica = value;
    }

    /**
     * Gets the value of the codiceTipoSemina property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getCodiceTipoSemina() {
        return codiceTipoSemina;
    }

    /**
     * Sets the value of the codiceTipoSemina property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setCodiceTipoSemina(JAXBElement<String> value) {
        this.codiceTipoSemina = value;
    }

    /**
     * Gets the value of the codiceTipoIrrigazione property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getCodiceTipoIrrigazione() {
        return codiceTipoIrrigazione;
    }

    /**
     * Sets the value of the codiceTipoIrrigazione property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setCodiceTipoIrrigazione(JAXBElement<String> value) {
        this.codiceTipoIrrigazione = value;
    }

    /**
     * Gets the value of the codiceProtezioneColture property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getCodiceProtezioneColture() {
        return codiceProtezioneColture;
    }

    /**
     * Sets the value of the codiceProtezioneColture property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setCodiceProtezioneColture(JAXBElement<String> value) {
        this.codiceProtezioneColture = value;
    }

    /**
     * Gets the value of the codiceFaseAllevamento property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getCodiceFaseAllevamento() {
        return codiceFaseAllevamento;
    }

    /**
     * Sets the value of the codiceFaseAllevamento property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setCodiceFaseAllevamento(JAXBElement<String> value) {
        this.codiceFaseAllevamento = value;
    }

    /**
     * Gets the value of the codiceFormaAllevamento property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getCodiceFormaAllevamento() {
        return codiceFormaAllevamento;
    }

    /**
     * Sets the value of the codiceFormaAllevamento property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setCodiceFormaAllevamento(JAXBElement<String> value) {
        this.codiceFormaAllevamento = value;
    }

    /**
     * Gets the value of the flagColtPrincipale property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getFlagColtPrincipale() {
        return flagColtPrincipale;
    }

    /**
     * Sets the value of the flagColtPrincipale property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setFlagColtPrincipale(JAXBElement<String> value) {
        this.flagColtPrincipale = value;
    }

    /**
     * Gets the value of the dataInizioUtilizzo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDataInizioUtilizzo() {
        return dataInizioUtilizzo;
    }

    /**
     * Sets the value of the dataInizioUtilizzo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDataInizioUtilizzo(String value) {
        this.dataInizioUtilizzo = value;
    }

    /**
     * Gets the value of the dataFineUtilizzo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDataFineUtilizzo() {
        return dataFineUtilizzo;
    }

    /**
     * Sets the value of the dataFineUtilizzo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDataFineUtilizzo(String value) {
        this.dataFineUtilizzo = value;
    }

    /**
     * Gets the value of the mantPratiPermanente property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getMantPratiPermanente() {
        return mantPratiPermanente;
    }

    /**
     * Sets the value of the mantPratiPermanente property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setMantPratiPermanente(JAXBElement<String> value) {
        this.mantPratiPermanente = value;
    }

    /**
     * Gets the value of the mantenSupAgricola property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getMantenSupAgricola() {
        return mantenSupAgricola;
    }

    /**
     * Sets the value of the mantenSupAgricola property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setMantenSupAgricola(JAXBElement<String> value) {
        this.mantenSupAgricola = value;
    }

    /**
     * Gets the value of the superficieEleggibileOP property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Integer }{@code >}
     *     
     */
    public JAXBElement<Integer> getSuperficieEleggibileOP() {
        return superficieEleggibileOP;
    }

    /**
     * Sets the value of the superficieEleggibileOP property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Integer }{@code >}
     *     
     */
    public void setSuperficieEleggibileOP(JAXBElement<Integer> value) {
        this.superficieEleggibileOP = value;
    }

    /**
     * Gets the value of the numeroPiante property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Integer }{@code >}
     *     
     */
    public JAXBElement<Integer> getNumeroPiante() {
        return numeroPiante;
    }

    /**
     * Sets the value of the numeroPiante property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Integer }{@code >}
     *     
     */
    public void setNumeroPiante(JAXBElement<Integer> value) {
        this.numeroPiante = value;
    }

    /**
     * Gets the value of the sestoImpiantoSuFila property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getSestoImpiantoSuFila() {
        return sestoImpiantoSuFila;
    }

    /**
     * Sets the value of the sestoImpiantoSuFila property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setSestoImpiantoSuFila(JAXBElement<String> value) {
        this.sestoImpiantoSuFila = value;
    }

    /**
     * Gets the value of the sestoImpiantoTraFile property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getSestoImpiantoTraFile() {
        return sestoImpiantoTraFile;
    }

    /**
     * Sets the value of the sestoImpiantoTraFile property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setSestoImpiantoTraFile(JAXBElement<String> value) {
        this.sestoImpiantoTraFile = value;
    }

    /**
     * Gets the value of the annoImpianto property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getAnnoImpianto() {
        return annoImpianto;
    }

    /**
     * Sets the value of the annoImpianto property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setAnnoImpianto(JAXBElement<String> value) {
        this.annoImpianto = value;
    }

    /**
     * Gets the value of the tipoImpianto property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getTipoImpianto() {
        return tipoImpianto;
    }

    /**
     * Sets the value of the tipoImpianto property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setTipoImpianto(JAXBElement<String> value) {
        this.tipoImpianto = value;
    }

    /**
     * Gets the value of the tipoCertificazione property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getTipoCertificazione() {
        return tipoCertificazione;
    }

    /**
     * Sets the value of the tipoCertificazione property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setTipoCertificazione(JAXBElement<String> value) {
        this.tipoCertificazione = value;
    }

    /**
     * Gets the value of the percentuale property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getPercentuale() {
        return percentuale;
    }

    /**
     * Sets the value of the percentuale property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setPercentuale(JAXBElement<String> value) {
        this.percentuale = value;
    }

    /**
     * Gets the value of the menzione property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Integer }{@code >}
     *     
     */
    public JAXBElement<Integer> getMenzione() {
        return menzione;
    }

    /**
     * Sets the value of the menzione property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Integer }{@code >}
     *     
     */
    public void setMenzione(JAXBElement<Integer> value) {
        this.menzione = value;
    }

    /**
     * Gets the value of the tipoUtilizzoOlivo property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getTipoUtilizzoOlivo() {
        return tipoUtilizzoOlivo;
    }

    /**
     * Sets the value of the tipoUtilizzoOlivo property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setTipoUtilizzoOlivo(JAXBElement<String> value) {
        this.tipoUtilizzoOlivo = value;
    }

    /**
     * Gets the value of the capacitaProduttiva property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getCapacitaProduttiva() {
        return capacitaProduttiva;
    }

    /**
     * Sets the value of the capacitaProduttiva property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setCapacitaProduttiva(JAXBElement<String> value) {
        this.capacitaProduttiva = value;
    }

    /**
     * Gets the value of the altitudine property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Integer }{@code >}
     *     
     */
    public JAXBElement<Integer> getAltitudine() {
        return altitudine;
    }

    /**
     * Sets the value of the altitudine property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Integer }{@code >}
     *     
     */
    public void setAltitudine(JAXBElement<Integer> value) {
        this.altitudine = value;
    }

    /**
     * Gets the value of the flagProduzioneIntegrata property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getFlagProduzioneIntegrata() {
        return flagProduzioneIntegrata;
    }

    /**
     * Sets the value of the flagProduzioneIntegrata property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setFlagProduzioneIntegrata(JAXBElement<String> value) {
        this.flagProduzioneIntegrata = value;
    }

}
