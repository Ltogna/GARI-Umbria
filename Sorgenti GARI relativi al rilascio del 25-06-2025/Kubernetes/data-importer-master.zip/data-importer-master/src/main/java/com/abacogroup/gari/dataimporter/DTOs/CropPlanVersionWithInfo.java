package com.abacogroup.gari.dataimporter.DTOs;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class CropPlanVersionWithInfo {
    private VersionResponse version;
    private boolean moreThanOne;
}
