package com.abacogroup.gari.dataimporter.controllers;

import java.util.Collections;

import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.gari.dataimporter.services.GIASUserService;
import com.codahale.metrics.annotation.Timed;

import io.dropwizard.auth.Auth;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.constraints.NotNull;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Timed
@Path("/{tenant}/public/v1/gias")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
@Tag(name = "tags", description = "Gias related APIs")
/**
 * 
 * @author Emanuele Crocilla
 *
 */
public class GiasController {
	
	private final GIASUserService service;

    public GiasController(GIASUserService service) {
    	this.service = service;
    }
    
	@GET
	@Path("/user")
	public Response get(@NotNull @Parameter(hidden = true) @Auth User user) {

		String agriUserName = null;
		
		try {
			
			agriUserName = user.getName();
			
			String foundUser = this.service.getGiasUserByAgriUser(agriUserName);

			return Response.ok(Collections.singletonMap("username", foundUser)).build();
			
		} catch (Exception e) {
			log.error(e.getMessage());
			throw e;
		}
	}
}
