package com.abacogroup.gari.dataimporter.DTOs;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
public class EditDeclarationResult {

	@JsonProperty("validationMessages")
	private List<ValidationMessage> validationMessages;

	@JsonProperty("declaration")
	private Declaration declaration;

	// Getters and setters...

	@JsonIgnoreProperties(ignoreUnknown = true)
	public static class ValidationMessage {

		@JsonProperty("message")
		private String message;

		@JsonProperty("blocking")
		private boolean blocking;

		// Getters and setters...
	}

	@JsonIgnoreProperties(ignoreUnknown = true)
	public static class Declaration {

		@JsonProperty("declCode")
		private String declCode;

		@JsonProperty("landuse")
		private Landuse landuse;

		@JsonProperty("areaPerc")
		private int areaPerc;

		@JsonProperty("style")
		private Style style;

		@JsonProperty("fromDate")
		private String fromDate;

		@JsonProperty("fromDatePrecision")
		private String fromDatePrecision;

		@JsonProperty("toDate")
		private String toDate;

		@JsonProperty("permanentCropForms")
		private List<PermanentCropForm> permanentCropForms;

		@JsonProperty("anomalies")
		private List<Anomaly> anomalies;

		@JsonProperty("pesticides")
		private List<Pesticide> pesticides;

		@JsonProperty("fieldsCodes")
		private List<FieldCode> fieldsCodes;

		// Getters and setters...

		@JsonIgnoreProperties(ignoreUnknown = true)
		public static class Landuse {

			@JsonProperty("code")
			private String code;

			@JsonProperty("description")
			private String description;

			// Getters and setters...
		}

		@JsonIgnoreProperties(ignoreUnknown = true)
		public static class Style {

			@JsonProperty("fillColor")
			private String fillColor;

			@JsonProperty("fillStyle")
			private String fillStyle;

			@JsonProperty("borderColor")
			private String borderColor;

			// Getters and setters...
		}

		@JsonIgnoreProperties(ignoreUnknown = true)
		public static class PermanentCropForm {

			@JsonProperty("formCode")
			private String formCode;

			@JsonProperty("formType")
			private String formType;

			@JsonProperty("permanentCropFormData")
			private PermanentCropFormData permanentCropFormData;

			// Getters and setters...

			@JsonIgnoreProperties(ignoreUnknown = true)
			public static class PermanentCropFormData {

				@JsonProperty("areaSqm")
				private int areaSqm;

				@JsonProperty("distanceOnTheRowCm")
				private int distanceOnTheRowCm;

				@JsonProperty("distanceBetweenRowsCm")
				private int distanceBetweenRowsCm;

				@JsonProperty("stumpsNumber")
				private int stumpsNumber;

				@JsonProperty("farmingForm")
				private String farmingForm;

				@JsonProperty("irrigation")
				private String irrigation;

				@JsonProperty("productDestinationCode")
				private String productDestinationCode;

				@JsonProperty("cultivationTypeCode")
				private String cultivationTypeCode;

				@JsonProperty("varietyCode")
				private String varietyCode;

				@JsonProperty("variationTypeCode")
				private String variationTypeCode;

				@JsonProperty("vineyardTypeCode")
				private String vineyardTypeCode;

				@JsonProperty("plantingType")
				private String plantingType;

				@JsonProperty("layering")
				private String layering;

				@JsonProperty("rock")
				private String rock;

				@JsonProperty("skeleton")
				private String skeleton;

				@JsonProperty("vegetativeState")
				private String vegetativeState;

				@JsonProperty("pruning")
				private String pruning;

				@JsonProperty("judgement")
				private String judgement;

				@JsonProperty("stumpsDensity100")
				private int stumpsDensity100;

				@JsonProperty("failuresPerc")
				private int failuresPerc;

				@JsonProperty("soilLayeringPerc")
				private int soilLayeringPerc;

				@JsonProperty("altitudeAboveSeaLevel")
				private int altitudeAboveSeaLevel;

				@JsonProperty("terracing")
				private String terracing;

				@JsonProperty("headerAnchoring")
				private String headerAnchoring;

				@JsonProperty("polesHeader")
				private String polesHeader;

				@JsonProperty("polesWeaving")
				private String polesWeaving;

				@JsonProperty("polesDistanceCm")
				private int polesDistanceCm;

				@JsonProperty("supportWires")
				private String supportWires;

				@JsonProperty("cultivationState")
				private String cultivationState;

				@JsonProperty("origin")
				private String origin;

				@JsonProperty("graftDate")
				private String graftDate;

				@JsonProperty("graftHolder")
				private String graftHolder;

				@JsonProperty("covering")
				private String covering;

				@JsonProperty("bio")
				private String bio;

				@JsonProperty("subscriptionCodes")
				private String subscriptionCodes;

				@JsonProperty("externalCode")
				private String externalCode;

				@JsonProperty("externalDescription")
				private String externalDescription;

				@JsonProperty("qualitySystem")
				private String qualitySystem;

				@JsonProperty("protectionStructures")
				private String protectionStructures;

				// Getters and setters...
			}
		}

		@JsonIgnoreProperties(ignoreUnknown = true)
		public static class Anomaly {

			@JsonProperty("objectCode")
			private String objectCode;

			@JsonProperty("objectType")
			private String objectType;

			@JsonProperty("errorCode")
			private String errorCode;

			@JsonProperty("errorDescription")
			private String errorDescription;

			@JsonProperty("blocking")
			private boolean blocking;

			// Getters and setters...
		}

		@JsonIgnoreProperties(ignoreUnknown = true)
		public static class Pesticide {

			@JsonProperty("pesticideEntryCode")
			private String pesticideEntryCode;

			@JsonProperty("planId")
			private int planId;

			@JsonProperty("plotCode")
			private String plotCode;

			@JsonProperty("declCode")
			private String declCode;

			@JsonProperty("productCode")
			private String productCode;

			@JsonProperty("uomCode")
			private String uomCode;

			@JsonProperty("amount")
			private int amount;

			@JsonProperty("entryDate")
			private String entryDate;

			@JsonProperty("productName")
			private String productName;

			@JsonProperty("uomLabel")
			private String uomLabel;

			@JsonProperty("userId")
			private String userId;

			@JsonProperty("declaration")
			private PesticideDeclaration declaration;

			@JsonProperty("parcelIntersection")
			private List<ParcelIntersection> parcelIntersection;

			@JsonProperty("plotAreaSqm")
			private int plotAreaSqm;

			// Getters and setters...

			@JsonIgnoreProperties(ignoreUnknown = true)
			public static class PesticideDeclaration {

				@JsonProperty("declCode")
				private String declCode;

				@JsonProperty("landuse")
				private Landuse landuse;

				@JsonProperty("areaPerc")
				private int areaPerc;

				@JsonProperty("style")
				private Style style;

				@JsonProperty("fromDate")
				private String fromDate;

				@JsonProperty("fromDatePrecision")
				private String fromDatePrecision;

				@JsonProperty("toDate")
				private String toDate;

				// Getters and setters...
			}

			@JsonIgnoreProperties(ignoreUnknown = true)
			public static class ParcelIntersection {

				@JsonProperty("code")
				private String code;

				@JsonProperty("description")
				private String description;

				@JsonProperty("parcelCode")
				private String parcelCode;

				@JsonProperty("notes")
				private String notes;

				@JsonProperty("landCoverCode")
				private String landCoverCode;

				@JsonProperty("landCoverDescription")
				private String landCoverDescription;

				@JsonProperty("areaSqm")
				private int areaSqm;

				@JsonProperty("holdingPercentage")
				private int holdingPercentage;

				@JsonProperty("anomalies")
				private List<Anomaly> anomalies;

				@JsonProperty("canDeclarePesticides")
				private boolean canDeclarePesticides;

				// Getters and setters...
			}
		}

		@JsonIgnoreProperties(ignoreUnknown = true)
		public static class FieldCode {

			@JsonProperty("fieldCode")
			private String fieldCode;

			@JsonProperty("fieldDescription")
			private String fieldDescription;

			@JsonProperty("dayFrom")
			private String dayFrom;

			@JsonProperty("dayTo")
			private String dayTo;

			@JsonProperty("sortOrder")
			private int sortOrder;

			@JsonProperty("value")
			private String value;

			@JsonProperty("valueDescription")
			private String valueDescription;

			@JsonProperty("flShowInTooltip")
			private boolean flShowInTooltip;

			// Getters and setters...
		}
	}
}
