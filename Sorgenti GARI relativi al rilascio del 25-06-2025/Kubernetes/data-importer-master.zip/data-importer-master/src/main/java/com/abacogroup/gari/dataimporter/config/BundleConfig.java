package com.abacogroup.gari.dataimporter.config;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Data
public class BundleConfig {

	@NotBlank
	private String configLocation;
	private String initBaseTempDir;

}
