package com.abacogroup.gari.dataimporter.DTOs;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
public class InsertDeclarationPayload {

	@JsonProperty("landuseCode")
	private String landuseCode;

	@JsonProperty("areaPerc")
	private int areaPerc;

	@JsonProperty("fromDate")
	private String fromDate;

	@JsonProperty("fromDatePrecision")
	private String fromDatePrecision;

	@JsonProperty("toDate")
	private String toDate;

	@JsonProperty("permanentCropForms")
	private List<PermanentCropForm> permanentCropForms;

	@JsonProperty("fieldsCodes")
	private List<FieldCode> fieldsCodes;

	@JsonProperty("removeExistingDeclarations")
	private boolean removeExistingDeclarations;

	// Getters and setters...

	@JsonIgnoreProperties(ignoreUnknown = true)
	public static class PermanentCropForm {

		@JsonProperty("formType")
		private String formType;

		@JsonProperty("permanentCropFormData")
		private PermanentCropFormData permanentCropFormData;

		// Getters and setters...

		@JsonIgnoreProperties(ignoreUnknown = true)
		public static class PermanentCropFormData {

			@JsonProperty("areaSqm")
			private int areaSqm;

			@JsonProperty("distanceOnTheRowCm")
			private int distanceOnTheRowCm;

			@JsonProperty("distanceBetweenRowsCm")
			private int distanceBetweenRowsCm;

			@JsonProperty("stumpsNumber")
			private int stumpsNumber;

			@JsonProperty("farmingForm")
			private String farmingForm;

			@JsonProperty("irrigation")
			private String irrigation;

			@JsonProperty("productDestinationCode")
			private String productDestinationCode;

			@JsonProperty("cultivationTypeCode")
			private String cultivationTypeCode;

			@JsonProperty("varietyCode")
			private String varietyCode;

			@JsonProperty("variationTypeCode")
			private String variationTypeCode;

			@JsonProperty("vineyardTypeCode")
			private String vineyardTypeCode;

			@JsonProperty("plantingType")
			private String plantingType;

			@JsonProperty("layering")
			private String layering;

			@JsonProperty("rock")
			private String rock;

			@JsonProperty("skeleton")
			private String skeleton;

			@JsonProperty("vegetativeState")
			private String vegetativeState;

			@JsonProperty("pruning")
			private String pruning;

			@JsonProperty("judgement")
			private String judgement;

			@JsonProperty("stumpsDensity100")
			private int stumpsDensity100;

			@JsonProperty("failuresPerc")
			private int failuresPerc;

			@JsonProperty("soilLayeringPerc")
			private int soilLayeringPerc;

			@JsonProperty("altitudeAboveSeaLevel")
			private int altitudeAboveSeaLevel;

			@JsonProperty("terracing")
			private String terracing;

			@JsonProperty("headerAnchoring")
			private String headerAnchoring;

			@JsonProperty("polesHeader")
			private String polesHeader;

			@JsonProperty("polesWeaving")
			private String polesWeaving;

			@JsonProperty("polesDistanceCm")
			private int polesDistanceCm;

			@JsonProperty("supportWires")
			private String supportWires;

			@JsonProperty("cultivationState")
			private String cultivationState;

			@JsonProperty("origin")
			private String origin;

			@JsonProperty("graftDate")
			private String graftDate;

			@JsonProperty("graftHolder")
			private String graftHolder;

			@JsonProperty("covering")
			private String covering;

			@JsonProperty("bio")
			private String bio;

			@JsonProperty("subscriptionCodes")
			private String subscriptionCodes;

			@JsonProperty("externalCode")
			private String externalCode;

			@JsonProperty("externalDescription")
			private String externalDescription;

			@JsonProperty("qualitySystem")
			private String qualitySystem;

			@JsonProperty("protectionStructures")
			private String protectionStructures;

			// Getters and setters...
		}
	}

	@JsonIgnoreProperties(ignoreUnknown = true)
	public static class FieldCode {

		@JsonProperty("fieldCode")
		private String fieldCode;

		@JsonProperty("fieldDescription")
		private String fieldDescription;

		@JsonProperty("dayFrom")
		private String dayFrom;

		@JsonProperty("dayTo")
		private String dayTo;

		@JsonProperty("sortOrder")
		private int sortOrder;

		@JsonProperty("value")
		private String value;

		@JsonProperty("valueDescription")
		private String valueDescription;

		@JsonProperty("flShowInTooltip")
		private boolean flShowInTooltip;

		// Getters and setters...
	}
}
