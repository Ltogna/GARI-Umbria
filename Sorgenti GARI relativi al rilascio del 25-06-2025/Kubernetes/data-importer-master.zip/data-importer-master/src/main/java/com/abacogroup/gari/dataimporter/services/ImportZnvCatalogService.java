package com.abacogroup.gari.dataimporter.services;

import java.time.OffsetDateTime;
import java.time.format.DateTimeFormatter;

import org.geojson.Feature;
import org.geojson.FeatureCollection;
import org.locationtech.jts.geom.Geometry;
import org.locationtech.jts.geom.GeometryFactory;
import org.locationtech.jts.io.ParseException;
import org.locationtech.jts.io.geojson.GeoJsonReader;

import com.abacogroup.dropwizard.auth.sso2.Sso2Client;
import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.gari.dataimporter.DataImporterConfiguration;
import com.abacogroup.gari.dataimporter.DTOs.GeoJsonFeatureCollection;
import com.abacogroup.gari.dataimporter.db.dao.LoggerDAO;
import com.abacogroup.gari.dataimporter.db.dao.ZvnCatalogDAO;
import com.abacogroup.gari.dataimporter.db.ntt.ZvnCatalogNTT;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import jakarta.ws.rs.NotFoundException;
import jakarta.ws.rs.client.Client;
import jakarta.ws.rs.core.MediaType;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class ImportZnvCatalogService extends ADataImporterService {

	public final ZvnCatalogDAO ZvnCatalogDAO;

	public ImportZnvCatalogService(Sso2Client _sso2Client, Client _client, DataImporterConfiguration _configuration,
			ObjectMapper mapper,
			LoggerDAO loggerDAO, com.abacogroup.gari.dataimporter.db.dao.ZvnCatalogDAO zvnCatalogDAO) {
		super(_sso2Client, _client, _configuration, mapper, loggerDAO);

		ZvnCatalogDAO = zvnCatalogDAO;
	}

	public void Import(User user, String tenant, double xmin, double ymin, double xmax, double ymax, String epsg,
			OffsetDateTime dataVal, String requestId)
			throws JsonProcessingException, ParseException {
		FeatureCollection res = sendGetSectionsRequest(xmin, ymin, xmax, ymax, epsg, tenant, dataVal);
		if (res != null) {
			for (Feature feature : res.getFeatures()) {
				if (!ZvnCatalogDAO.existsByIdRec(toLong(feature.getProperties().get("idRec")))) {

					// We pass a GeometryFactory because do not wanto to use the default SRID 4326
					GeoJsonReader reader = new GeoJsonReader(new GeometryFactory());

					String tmp = mapper.writeValueAsString(feature.getGeometry());
					Geometry geom = reader.read(tmp);
					ZvnCatalogDAO.insert(ZvnCatalogNTT.builder()
							.idRec(toLong(feature.getProperties().get("idRec")))
							.area(toDouble(feature.getProperties().get("area")))
							.trackingRequestId(requestId)
							.regione((String) feature.getProperties().get("regione"))
							.geom(geom)
							.nomeZvn((String) feature.getProperties().get("nomeZvn"))
							.type("feature")
							.build());
				}
			}
		}
	}

	private double toDouble(Object object) {
		if (object instanceof Number n) {
			return n.doubleValue();
		} else if (object instanceof String s) {
			return Double.valueOf(s);
		} else {
			throw new IllegalArgumentException("Unsupported type: " + object.getClass().getName());
		}
	}

	private long toLong(Object object) {

		if (object instanceof Number n) {
			return n.longValue();
		} else if (object instanceof String s) {
			return Long.valueOf(s);
		} else {
			throw new IllegalArgumentException("Unsupported type: " + object.getClass().getName());
		}
	}

	public FeatureCollection sendGetSectionsRequest(double xmin, double ymin, double xmax, double ymax, String epsg,
			String tenant,
			OffsetDateTime dataVal) {
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm");
		String url = String.format("%s/api/v1/gis/zvn/intersezione/bbox/%s,%s,%s,%s/epsg/%s", mtlsProxyUrl, xmin, ymin,
				xmax, ymax, epsg);

		try {
			return client.target(url)
					.path("/dataVal")
					.path(dataVal.format(formatter))
					.request(MediaType.APPLICATION_JSON)
					.header("Authorization", "JWT " + getAuthToken(tenant))
					.get(FeatureCollection.class);
		} catch (NotFoundException e) {
			return null;
		}
	}
}
