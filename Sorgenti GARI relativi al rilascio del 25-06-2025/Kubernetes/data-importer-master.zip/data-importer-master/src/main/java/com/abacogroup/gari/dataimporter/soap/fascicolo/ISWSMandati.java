
package com.abacogroup.gari.dataimporter.soap.fascicolo;

import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ISWSMandati complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ISWSMandati"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="CuaaDich" type="{http://cooperazione.sian.it/schema/fascicolo}Cuaa"/&gt;
 *         &lt;element name="CodiCaa"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;maxLength value="3"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="CodiProvCaa"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;maxLength value="3"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="CodiProgCaa"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;maxLength value="3"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="DescUffiCaa"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;minLength value="1"/&gt;
 *               &lt;maxLength value="100"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="DataSottMand" type="{http://cooperazione.sian.it/schema/fascicolo}Data"/&gt;
 *         &lt;element name="DataInse" type="{http://cooperazione.sian.it/schema/fascicolo}Data"/&gt;
 *         &lt;element name="Uten"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;minLength value="1"/&gt;
 *               &lt;maxLength value="50"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="DataAggi" type="{http://cooperazione.sian.it/schema/fascicolo}Data"/&gt;
 *         &lt;element name="RifeArchAcqu"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;minLength value="1"/&gt;
 *               &lt;maxLength value="50"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="DataScadMand" type="{http://cooperazione.sian.it/schema/fascicolo}Data"/&gt;
 *         &lt;element name="DataPresMand" type="{http://cooperazione.sian.it/schema/fascicolo}Data"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ISWSMandati", propOrder = {
    "cuaaDich",
    "codiCaa",
    "codiProvCaa",
    "codiProgCaa",
    "descUffiCaa",
    "dataSottMand",
    "dataInse",
    "uten",
    "dataAggi",
    "rifeArchAcqu",
    "dataScadMand",
    "dataPresMand"
})
public class ISWSMandati {

    @XmlElement(name = "CuaaDich", required = true)
    protected String cuaaDich;
    @XmlElement(name = "CodiCaa", required = true)
    protected String codiCaa;
    @XmlElement(name = "CodiProvCaa", required = true)
    protected String codiProvCaa;
    @XmlElement(name = "CodiProgCaa", required = true, nillable = true)
    protected String codiProgCaa;
    @XmlElement(name = "DescUffiCaa", required = true, nillable = true)
    protected String descUffiCaa;
    @XmlElement(name = "DataSottMand", required = true)
    protected String dataSottMand;
    @XmlElement(name = "DataInse", required = true)
    protected String dataInse;
    @XmlElement(name = "Uten", required = true)
    protected String uten;
    @XmlElement(name = "DataAggi", required = true, nillable = true)
    protected String dataAggi;
    @XmlElement(name = "RifeArchAcqu", required = true, nillable = true)
    protected String rifeArchAcqu;
    @XmlElement(name = "DataScadMand", required = true, nillable = true)
    protected String dataScadMand;
    @XmlElement(name = "DataPresMand", required = true, nillable = true)
    protected String dataPresMand;

    /**
     * Gets the value of the cuaaDich property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCuaaDich() {
        return cuaaDich;
    }

    /**
     * Sets the value of the cuaaDich property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCuaaDich(String value) {
        this.cuaaDich = value;
    }

    /**
     * Gets the value of the codiCaa property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodiCaa() {
        return codiCaa;
    }

    /**
     * Sets the value of the codiCaa property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodiCaa(String value) {
        this.codiCaa = value;
    }

    /**
     * Gets the value of the codiProvCaa property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodiProvCaa() {
        return codiProvCaa;
    }

    /**
     * Sets the value of the codiProvCaa property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodiProvCaa(String value) {
        this.codiProvCaa = value;
    }

    /**
     * Gets the value of the codiProgCaa property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodiProgCaa() {
        return codiProgCaa;
    }

    /**
     * Sets the value of the codiProgCaa property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodiProgCaa(String value) {
        this.codiProgCaa = value;
    }

    /**
     * Gets the value of the descUffiCaa property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDescUffiCaa() {
        return descUffiCaa;
    }

    /**
     * Sets the value of the descUffiCaa property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDescUffiCaa(String value) {
        this.descUffiCaa = value;
    }

    /**
     * Gets the value of the dataSottMand property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDataSottMand() {
        return dataSottMand;
    }

    /**
     * Sets the value of the dataSottMand property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDataSottMand(String value) {
        this.dataSottMand = value;
    }

    /**
     * Gets the value of the dataInse property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDataInse() {
        return dataInse;
    }

    /**
     * Sets the value of the dataInse property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDataInse(String value) {
        this.dataInse = value;
    }

    /**
     * Gets the value of the uten property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUten() {
        return uten;
    }

    /**
     * Sets the value of the uten property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUten(String value) {
        this.uten = value;
    }

    /**
     * Gets the value of the dataAggi property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDataAggi() {
        return dataAggi;
    }

    /**
     * Sets the value of the dataAggi property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDataAggi(String value) {
        this.dataAggi = value;
    }

    /**
     * Gets the value of the rifeArchAcqu property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRifeArchAcqu() {
        return rifeArchAcqu;
    }

    /**
     * Sets the value of the rifeArchAcqu property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRifeArchAcqu(String value) {
        this.rifeArchAcqu = value;
    }

    /**
     * Gets the value of the dataScadMand property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDataScadMand() {
        return dataScadMand;
    }

    /**
     * Sets the value of the dataScadMand property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDataScadMand(String value) {
        this.dataScadMand = value;
    }

    /**
     * Gets the value of the dataPresMand property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDataPresMand() {
        return dataPresMand;
    }

    /**
     * Sets the value of the dataPresMand property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDataPresMand(String value) {
        this.dataPresMand = value;
    }

}
