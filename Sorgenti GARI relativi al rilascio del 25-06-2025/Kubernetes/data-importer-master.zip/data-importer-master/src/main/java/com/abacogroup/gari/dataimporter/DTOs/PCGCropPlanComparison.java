package com.abacogroup.gari.dataimporter.DTOs;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class PCGCropPlanComparison {

    @JsonProperty("id_appezzamento")
    private String idAppezzamento;

    @JsonProperty("id_appezzamento_padre")
    private String idAppezzamentoPadre;

    @JsonProperty("tipo_modifica")
    private String tipoModifica;
}
