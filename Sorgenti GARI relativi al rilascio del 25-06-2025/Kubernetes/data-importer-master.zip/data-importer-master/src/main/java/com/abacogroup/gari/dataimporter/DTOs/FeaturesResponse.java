package com.abacogroup.gari.dataimporter.DTOs;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;
import org.locationtech.jts.geom.Geometry;

import java.util.List;
import java.util.Objects;

@JsonIgnoreProperties(ignoreUnknown = true)
public class FeaturesResponse {

	@JsonProperty("features")
	private List<Feature> features;

	public List<Feature> getFeatures() {
		return features;
	}

	public void setFeatures(List<Feature> features) {
		this.features = features;
	}

	@JsonIgnoreProperties(ignoreUnknown = true)
	@Builder
	@AllArgsConstructor
	@NoArgsConstructor
	public static class Feature {

		@JsonProperty("properties")
		private Properties properties;

		@JsonProperty("geometry")
		private Geometry geometry;

		public Properties getProperties() {
			return properties;
		}

		public void setProperties(Properties properties) {
			this.properties = properties;
		}

		public Geometry getGeometry() {
			return geometry;
		}

		public void setGeometry(Geometry geometry) {
			this.geometry = geometry;
		}
	}

	@JsonIgnoreProperties(ignoreUnknown = true)
	@ToString
	public static class Properties {
		@JsonProperty("numPoints")
		private int numPoints;

		@JsonProperty("featureLabel")
		private String featureLabel;

		@JsonProperty("dataStamScheVali")
		private String dataStamScheVali;

		@JsonProperty("tipo")
		private String tipo;

		@JsonProperty("codiceRilevato")
		private String codiceRilevato;

		@JsonProperty("codiceEpsg")
		private String codiceEpsg;

		@JsonProperty("identificativoPianoColtivazione")
		private String identificativoPianoColtivazione;

		@JsonProperty("dataInizAppe")
		private String dataInizAppe;

		@JsonProperty("codiBarrScheVali")
		private String codiBarrScheVali;

		@JsonProperty("dataFineAppe")
		private String dataFineAppe;

		@JsonProperty("identificativoAppezzamento")
		private String identificativoAppezzamento;

		@JsonProperty("idAppeLast")
		private String idAppeLast;

		@JsonProperty("superficieAppezzamento")
		private int superficieAppezzamento;

		@JsonProperty("idSchedaValidazione")
		private String idSchedaValidazione;

		@JsonProperty("codiceProdottoRilevato")
		private String codiceProdottoRilevato;

		@JsonProperty("idPcgVers")
		private String idPcgVers;

		@JsonProperty("areaPoligono")
		private double areaPoligono;

		@JsonProperty("coltivazioni")
		private List<Coltivazione> coltivazioni;

		@JsonProperty("id")
		private String id;

		@JsonProperty("cuaa")
		private String cuaa;

		@JsonProperty("indiceTabella")
		private String indiceTabella;

		@JsonProperty("identificativoIsola")
		private String identificativoIsola;

		@JsonProperty("nomeLayer")
		private String nomeLayer;

		// Getters and Setters

		public int getNumPoints() {
			return numPoints;
		}

		public void setNumPoints(int numPoints) {
			this.numPoints = numPoints;
		}

		public String getFeatureLabel() {
			return featureLabel;
		}

		public void setFeatureLabel(String featureLabel) {
			this.featureLabel = featureLabel;
		}

		public String getDataStamScheVali() {
			return dataStamScheVali;
		}

		public void setDataStamScheVali(String dataStamScheVali) {
			this.dataStamScheVali = dataStamScheVali;
		}

		public String getTipo() {
			return tipo;
		}

		public void setTipo(String tipo) {
			this.tipo = tipo;
		}

		public String getCodiceRilevato() {
			return codiceRilevato;
		}

		public void setCodiceRilevato(String codiceRilevato) {
			this.codiceRilevato = codiceRilevato;
		}

		public String getCodiceEpsg() {
			return codiceEpsg;
		}

		public void setCodiceEpsg(String codiceEpsg) {
			this.codiceEpsg = codiceEpsg;
		}

		public String getIdentificativoPianoColtivazione() {
			return identificativoPianoColtivazione;
		}

		public void setIdentificativoPianoColtivazione(String identificativoPianoColtivazione) {
			this.identificativoPianoColtivazione = identificativoPianoColtivazione;
		}

		public String getDataInizAppe() {
			return dataInizAppe;
		}

		public void setDataInizAppe(String dataInizAppe) {
			this.dataInizAppe = dataInizAppe;
		}

		public String getCodiBarrScheVali() {
			return codiBarrScheVali;
		}

		public void setCodiBarrScheVali(String codiBarrScheVali) {
			this.codiBarrScheVali = codiBarrScheVali;
		}

		public String getDataFineAppe() {
			return dataFineAppe;
		}

		public void setDataFineAppe(String dataFineAppe) {
			this.dataFineAppe = dataFineAppe;
		}

		public String getIdentificativoAppezzamento() {
			return identificativoAppezzamento;
		}

		public void setIdentificativoAppezzamento(String identificativoAppezzamento) {
			this.identificativoAppezzamento = identificativoAppezzamento;
		}

		public String getIdAppeLast() {
			return idAppeLast;
		}

		public void setIdAppeLast(String idAppeLast) {
			this.idAppeLast = idAppeLast;
		}

		public int getSuperficieAppezzamento() {
			return superficieAppezzamento;
		}

		public void setSuperficieAppezzamento(int superficieAppezzamento) {
			this.superficieAppezzamento = superficieAppezzamento;
		}

		public String getIdSchedaValidazione() {
			return idSchedaValidazione;
		}

		public void setIdSchedaValidazione(String idSchedaValidazione) {
			this.idSchedaValidazione = idSchedaValidazione;
		}

		public String getCodiceProdottoRilevato() {
			return codiceProdottoRilevato;
		}

		public void setCodiceProdottoRilevato(String codiceProdottoRilevato) {
			this.codiceProdottoRilevato = codiceProdottoRilevato;
		}

		public String getIdPcgVers() {
			return idPcgVers;
		}

		public void setIdPcgVers(String idPcgVers) {
			this.idPcgVers = idPcgVers;
		}

		public double getAreaPoligono() {
			return areaPoligono;
		}

		public void setAreaPoligono(int areaPoligono) {
			this.areaPoligono = areaPoligono;
		}

		public List<Coltivazione> getColtivazioni() {
			return coltivazioni;
		}

		public void setColtivazioni(List<Coltivazione> coltivazioni) {
			this.coltivazioni = coltivazioni;
		}

		public String getId() {
			return id;
		}

		public void setId(String id) {
			this.id = id;
		}

		public String getCuaa() {
			return cuaa;
		}

		public void setCuaa(String cuaa) {
			this.cuaa = cuaa;
		}

		public String getIndiceTabella() {
			return indiceTabella;
		}

		public void setIndiceTabella(String indiceTabella) {
			this.indiceTabella = indiceTabella;
		}

		public String getIdentificativoIsola() {
			return identificativoIsola;
		}

		public void setIdentificativoIsola(String identificativoIsola) {
			this.identificativoIsola = identificativoIsola;
		}

		public String getNomeLayer() {
			return nomeLayer;
		}

		public void setNomeLayer(String nomeLayer) {
			this.nomeLayer = nomeLayer;
		}

		@Override
		public boolean equals(Object o) {
			if (this == o)
				return true;
			if (o == null || getClass() != o.getClass())
				return false;
			Properties that = (Properties) o;
			return numPoints == that.numPoints && superficieAppezzamento == that.superficieAppezzamento
					&& Double.compare(areaPoligono, that.areaPoligono) == 0 && Objects.equals(featureLabel, that.featureLabel)
					&& Objects.equals(dataStamScheVali, that.dataStamScheVali) && Objects.equals(tipo, that.tipo) && Objects.equals(
					codiceRilevato, that.codiceRilevato)
					&& Objects.equals(codiceEpsg, that.codiceEpsg) && Objects.equals(
					identificativoPianoColtivazione, that.identificativoPianoColtivazione)
					&& Objects.equals(dataInizAppe, that.dataInizAppe)
					&& Objects.equals(codiBarrScheVali, that.codiBarrScheVali) && Objects.equals(dataFineAppe, that.dataFineAppe)
					&& Objects.equals(identificativoAppezzamento, that.identificativoAppezzamento) && Objects.equals(idSchedaValidazione,
					that.idSchedaValidazione)
					&& Objects.equals(codiceProdottoRilevato, that.codiceProdottoRilevato) && Objects.equals(idPcgVers,
					that.idPcgVers)
					&& Objects.equals(coltivazioni, that.coltivazioni) && Objects.equals(id, that.id) && Objects.equals(
					cuaa, that.cuaa)
					&& Objects.equals(indiceTabella, that.indiceTabella) && Objects.equals(identificativoIsola,
					that.identificativoIsola)
					&& Objects.equals(nomeLayer, that.nomeLayer);
		}

		@Override
		public int hashCode() {
			return Objects.hash(numPoints, featureLabel, dataStamScheVali, tipo, codiceRilevato, codiceEpsg, identificativoPianoColtivazione, dataInizAppe,
					codiBarrScheVali, dataFineAppe, identificativoAppezzamento, superficieAppezzamento, idSchedaValidazione, codiceProdottoRilevato, idPcgVers,
					areaPoligono, coltivazioni, id, cuaa, indiceTabella, identificativoIsola, nomeLayer);
		}
	}

	@Data
	public static class Coltivazione {
		@JsonProperty("idColt")
		private String idColt;

		@JsonProperty("codiDestUtil")
		private String codiDestUtil;

		@JsonProperty("codiOccu")
		private String codiOccu;

		@JsonProperty("codiDestUsoo")
		private String codiDestUsoo;

		@JsonProperty("codiUsoo")
		private String codiUsoo;

		@JsonProperty("codiQual")
		private String codiQual;

		@JsonProperty("codiOccuVari")
		private String codiOccuVari;

		@JsonProperty("dataInizColt")
		private String dataInizColt;

		@JsonProperty("dataFineColt")
		private String dataFineColt;

		@JsonProperty("supeColt")
		private double supeColt;

		@JsonProperty("flagColtPrin")
		private String flagColtPrin;

		@JsonProperty("pratPerm")
		private String pratPerm;

		@JsonProperty("critMant")
		private String critMant;

		@JsonProperty("flagProdInte")
		private String flagProdInte;

		@JsonProperty("flagDop")
		private String flagDop;

		@JsonProperty("tipoDiSemina")
		private String tipoDiSemina;

		@JsonProperty("tipoIrrigazione")
		private String tipoIrrigazione;

		@JsonProperty("annoMese")
		private String annoMese;

		@JsonProperty("potenzialitaIrrigua")
		private String potenzialitaIrrigua;

		@JsonProperty("sostanzePericolose")
		private String sostanzePericolose;

		@JsonProperty("effluentiZootecnici")
		private String effluentiZootecnici;

		@JsonProperty("presenzaTerrazzamenti")
		private String presenzaTerrazzamenti;

		@JsonProperty("struttureAziendali")
		private String struttureAziendali;

		@JsonProperty("tipoDiImpianto")
		private String tipoDiImpianto;

		@JsonProperty("tipoDiAllevamento")
		private String tipoDiAllevamento;

		@JsonProperty("destinazioniProduttive")
		private String destinazioniProduttive;

		@JsonProperty("faseDiAllevamento")
		private String faseDiAllevamento;

		@JsonProperty("rotazioneColturale")
		private String rotazioneColturale;

		@JsonProperty("formaDiAllevamento")
		private String formaDiAllevamento;

		@JsonProperty("ultimoAnnoDiTaglio")
		private String ultimoAnnoDiTaglio;

		@JsonProperty("flagBiol")
		private String flagBiol;

		@JsonProperty("idColtLast")
		private String idColtLast;

		@JsonProperty("tipoColtSqnpi")
		private String tipoColtSqnpi;

		@JsonProperty("numeCiclSqnpi")
		private String numeCiclSqnpi;

		@JsonProperty("prodStimSqnpi")
		private String prodStimSqnpi;

		@JsonProperty("attoBiol")
		private String attoBiol;

		@JsonProperty("dataInitAttoBiol")
		private String dataInitAttoBiol;

		@JsonProperty("dataFineAttoBiol")
		private String dataFineAttoBiol;

		@JsonProperty("resaBiol")
		private String resaBiol;

	}
}
