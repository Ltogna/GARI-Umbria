package com.abacogroup.gari.dataimporter.DTOs;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.geojson.FeatureCollection;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class PlotFeatureBindingDTO {

	private com.abacogroup.gari.dataimporter.DTOs.PlotDataResponse plot;
	private FeaturesResponse.Feature feature;

}
