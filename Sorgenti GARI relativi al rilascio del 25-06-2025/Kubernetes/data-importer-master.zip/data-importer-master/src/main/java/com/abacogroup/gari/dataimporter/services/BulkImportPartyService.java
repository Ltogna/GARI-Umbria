package com.abacogroup.gari.dataimporter.services;

import java.util.Map;

import com.abacogroup.dropwizard.auth.sso2.Sso2Client;
import com.abacogroup.gari.dataimporter.DataImporterConfiguration;
import com.abacogroup.gari.dataimporter.DTOs.DossierDTO;
import com.abacogroup.gari.dataimporter.DTOs.DossierDataDTO;
import com.abacogroup.gari.dataimporter.DTOs.DossierRequest;
import com.abacogroup.gari.dataimporter.DTOs.DossierTransitionStatusDTO;
import com.abacogroup.gari.dataimporter.DTOs.PartyInsertRequest;
import com.abacogroup.gari.dataimporter.DTOs.PartyResponse;
import com.abacogroup.gari.dataimporter.DTOs.RecordResponse;
import com.abacogroup.gari.dataimporter.Interfaces.ICropPlanService;
import com.abacogroup.gari.dataimporter.db.dao.LoggerDAO;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import jakarta.ws.rs.NotFoundException;
import jakarta.ws.rs.client.Client;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class BulkImportPartyService extends ADataImporterService {
	private static final int MAX_DOSSIER_ATTEMPTS = 75;

	private final BulkImportPartyLoadService loadService;
	private final ICropPlanService cropPlanService;

	public BulkImportPartyService(Sso2Client sso2Client, Client client, DataImporterConfiguration configuration,
			ObjectMapper objectMapper, LoggerDAO loggerDAO, BulkImportPartyLoadService loadService, ICropPlanService cropPlanService) {
		super(sso2Client, client, configuration, objectMapper, loggerDAO);
		this.loadService = loadService;
		this.cropPlanService = cropPlanService;
	}

	public void importCuaaBulk(String id) {
		var loadNTT = loadService.findById(id);
		Long partyId = getPartyIdFromCuaa(loadNTT.getTenant(), loadNTT.getCuaa());
		if (partyId == null) {
			var request = PartyInsertRequest.builder()
					.partyCode(loadNTT.getCuaa())
					.sourceCode("SIAN")
					.build();
			var party = createPartyFromExternal(loadNTT.getTenant(), loadNTT.getCuaa(), request);
			if (party != null) {
				loadService.updatePartyById(loadNTT.getId(), (long) party.getId());
			} else {
				throw new RuntimeException("Not able to create party from external, Cuaa:" + loadNTT.getCuaa());
			}
		} else {
			loadService.updatePartyById(id, partyId);
		}
	}

	// DOSSIER
	public void createDossier(String loadId) {
		var loadNTT = loadService.findById(loadId);
		var tenant = loadNTT.getTenant();
		var partyId = loadNTT.getPartyId();
		var year = loadNTT.getCampagna();

		var existingDossier = checkDossierExistingByPartyAndYear(tenant, partyId, year);
		boolean exists = (existingDossier != null && existingDossier.getDossierId() != null );

		if (!exists) {
			DossierDTO dossierResult = sendDossierPartyRequest(tenant, DossierRequest.builder()
					.partyId(partyId)
					.moduleCode("FARMER-REGISTRY")
					.sectorCode("FASCICOLO")
					.year(year)
					.build());

			if (dossierResult == null || dossierResult.getDossierId() == null) {
				throw new RuntimeException(String.format("Not able to create dossier for party: %s, Cuaa: %s", partyId, loadNTT.getCuaa()));
			}

			if (!waitForDossierTransition(tenant, dossierResult.getDossierId())) {
				throw new RuntimeException("Timeout: Dossier still in transition after %s attempts. Id %s".formatted(MAX_DOSSIER_ATTEMPTS, loadId));
			}
		}
	}

	// CROP PLAN
	public void importPartyCropPlan(String loadId) {
		var loadNTT = loadService.findById(loadId);
		cropPlanService.ImportCropPlan(null, loadNTT.getTenant(), loadNTT.getCuaa(), loadNTT.getCampagna(), null);
	}

	// Actions
	private boolean waitForDossierTransition(String tenant, Long dossierId) {
		final long waitMillis = 1500;

		for (int attempt = 0; attempt < MAX_DOSSIER_ATTEMPTS; attempt++) {
			var status = dossierInTransaction(tenant, dossierId);
			if (!status.isInTransition()) {
				if (status.getLastTransitionLog() != null && status.getLastTransitionLog().getFailed()) {
					throw new RuntimeException("Dossier transition failed for dossierId: " + dossierId);
				}
				return true; // transition completed successfully
			}
			try {
				Thread.sleep(waitMillis);
			} catch (InterruptedException e) {
				Thread.currentThread().interrupt();
				throw new RuntimeException("Thread interrupted while waiting for dossier transition.", e);
			}
		}
		return false; // timeout
	}

	// PartyRegistry
	public Long getPartyIdFromCuaa(String tenantId, String cuaa) {
		String url = String.format("%s/%s/public/v1/parties/code/%s", partyRegistry, tenantId, cuaa);
		try {
			@SuppressWarnings("rawtypes")
			Map<String, Object> obj = sendGetRequest(tenantId, url, Map.class, "checkPartyExisting");
			if (obj == null || obj.isEmpty()) {
				// This API return 204 no content if not found
				return null;
			}
			return ((Number) obj.get("id")).longValue();
		} catch (NotFoundException e) {
			return null;
		}
	}

	public PartyResponse createPartyFromExternal(String tenantId, String cuaa, PartyInsertRequest request) {
		String url = String.format("%s/%s/api-priv/v1/parties/external", partyRegistry, tenantId);
		return sendPutRequest(tenantId, url, request, PartyResponse.class, "createPartyFromExternal");
	}

	// Dossier
	public DossierDataDTO checkDossierExistingByPartyAndYear(String tenantId, Long partyId, Integer year) {
		try {
			String url = String.format("%s/%s/api-priv/v1/dossiers/parties/%s", dossierUrl, tenantId, partyId, year);
			var dossiers =  sendGetRequestWithAuth(url, new TypeReference<RecordResponse<DossierDataDTO>>() {
			}, "checkPartyExisting", tenantId);
			if(dossiers != null){
				if (!dossiers.getRecords().isEmpty()){
					return  dossiers.getRecords().stream().filter(x->x.getYear().equals(year)).findFirst().orElse(null);
				}
			}
		} catch (Exception ignored) {
		}
		return null;
	}

	public DossierDTO sendDossierPartyRequest(String tenantId, DossierRequest request) {
		String url = String.format("%s/%s/api-priv/v1/dossiers-async", dossierUrl, tenantId);
		return sendPostRequest(tenantId, url, request, DossierDTO.class, "sendDossierPartyRequest");
	}

	public DossierTransitionStatusDTO dossierInTransaction(String tenantId, Long dossierId) {
		String url = String.format("%s/%s/api-priv/v1/dossiers/%s/is-in-transition", dossierUrl, tenantId, dossierId);
		return sendGetRequest(tenantId, url, DossierTransitionStatusDTO.class, "createPartyFromExternal");
	}
	//

}
