package com.abacogroup.gari.dataimporter.DTOs;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@JsonIgnoreProperties(ignoreUnknown = true)
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class DossierTransitionStatusDTO {

	@JsonProperty("inTransition")
	private boolean inTransition;

	@JsonProperty("lastTransitionLog")
	private DossierTransitionLogDTO lastTransitionLog;
}
