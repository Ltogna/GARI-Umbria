package com.abacogroup.gari.dataimporter.DTOs;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import groovy.transform.ToString;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.OffsetDateTime;
import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class NotifyGias {
	@JsonProperty("ID_ExternalSystem")
	private String idExternalSystem;

	@JsonProperty("elencoCUAA")
	private List<CUAAItem> elencoCUAA;

	@Data
	@Builder
	@NoArgsConstructor
	@AllArgsConstructor
	@ToString
	public static class CUAAItem {
		@JsonProperty("CUAA")
		private String cuaa;

		@JsonProperty("Campagna")
		private Integer campagna;

		@JsonProperty("Operazione")
		private String operazione;

		@JsonProperty("Dettaglio")
		private Dettaglio dettaglio;

		@JsonProperty("id_signal")
		private String idSignal;
	}

	@Data
	@Builder
	@NoArgsConstructor
	@AllArgsConstructor
	@ToString
	@JsonInclude(JsonInclude.Include.NON_NULL) // Exclude null fields during serialization
	public static class Dettaglio {
		@JsonProperty("anagrafica")
		private NotificationDate anagrafica;

		@JsonProperty("pcg")
		private NotificationDate pcg;
	}

	@Data
	@Builder
	@NoArgsConstructor
	@AllArgsConstructor
	@ToString
	@JsonInclude(JsonInclude.Include.NON_NULL) // Exclude null fields during serialization
	public static class NotificationDate {
		@JsonProperty("DataOraNotifica")
		private OffsetDateTime dataOraNotifica;
	}
}
