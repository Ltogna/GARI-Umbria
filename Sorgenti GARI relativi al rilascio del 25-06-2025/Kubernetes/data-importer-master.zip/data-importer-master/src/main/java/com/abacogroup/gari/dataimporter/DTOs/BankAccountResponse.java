package com.abacogroup.gari.dataimporter.DTOs;

import java.util.List;
import java.util.Map;

public class BankAccountResponse {
	private long id;
	private long partyId;
	private String network; // Example: SEPA
	private String iban;
	private String swiftBic;
	private String bicExtraSepa;
	private String bankCountry;
	private String bankName;
	private String bankBranch;
	private String description;
	private boolean defaultBankAccount;
	private String dayFrom;
	private String dayTo;
	private Anomalies anomalies;
	private boolean active;

	// Getters and Setters
	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public long getPartyId() {
		return partyId;
	}

	public void setPartyId(long partyId) {
		this.partyId = partyId;
	}

	public String getNetwork() {
		return network;
	}

	public void setNetwork(String network) {
		this.network = network;
	}

	public String getIban() {
		return iban;
	}

	public void setIban(String iban) {
		this.iban = iban;
	}

	public String getSwiftBic() {
		return swiftBic;
	}

	public void setSwiftBic(String swiftBic) {
		this.swiftBic = swiftBic;
	}

	public String getBicExtraSepa() {
		return bicExtraSepa;
	}

	public void setBicExtraSepa(String bicExtraSepa) {
		this.bicExtraSepa = bicExtraSepa;
	}

	public String getBankCountry() {
		return bankCountry;
	}

	public void setBankCountry(String bankCountry) {
		this.bankCountry = bankCountry;
	}

	public String getBankName() {
		return bankName;
	}

	public void setBankName(String bankName) {
		this.bankName = bankName;
	}

	public String getBankBranch() {
		return bankBranch;
	}

	public void setBankBranch(String bankBranch) {
		this.bankBranch = bankBranch;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public boolean isDefaultBankAccount() {
		return defaultBankAccount;
	}

	public void setDefaultBankAccount(boolean defaultBankAccount) {
		this.defaultBankAccount = defaultBankAccount;
	}

	public String getDayFrom() {
		return dayFrom;
	}

	public void setDayFrom(String dayFrom) {
		this.dayFrom = dayFrom;
	}

	public String getDayTo() {
		return dayTo;
	}

	public void setDayTo(String dayTo) {
		this.dayTo = dayTo;
	}

	public Anomalies getAnomalies() {
		return anomalies;
	}

	public void setAnomalies(Anomalies anomalies) {
		this.anomalies = anomalies;
	}

	public boolean isActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	// Nested Classes
	public static class Anomalies {
		private String maxLevel; // Example: DANGER
		private int count;
		private Map<String, List<AnomalyDetails>> levels; // Keys: INFO, WARN, DANGER

		public String getMaxLevel() {
			return maxLevel;
		}

		public void setMaxLevel(String maxLevel) {
			this.maxLevel = maxLevel;
		}

		public int getCount() {
			return count;
		}

		public void setCount(int count) {
			this.count = count;
		}

		public Map<String, List<AnomalyDetails>> getLevels() {
			return levels;
		}

		public void setLevels(Map<String, List<AnomalyDetails>> levels) {
			this.levels = levels;
		}
	}

	public static class AnomalyDetails {
		private String entityCode;
		private String entityId;
		private Type type;

		public String getEntityCode() {
			return entityCode;
		}

		public void setEntityCode(String entityCode) {
			this.entityCode = entityCode;
		}

		public String getEntityId() {
			return entityId;
		}

		public void setEntityId(String entityId) {
			this.entityId = entityId;
		}

		public Type getType() {
			return type;
		}

		public void setType(Type type) {
			this.type = type;
		}
	}

	public static class Type {
		private String groupCode;
		private String code;
		private String i18nCode;

		public String getGroupCode() {
			return groupCode;
		}

		public void setGroupCode(String groupCode) {
			this.groupCode = groupCode;
		}

		public String getCode() {
			return code;
		}

		public void setCode(String code) {
			this.code = code;
		}

		public String getI18nCode() {
			return i18nCode;
		}

		public void setI18nCode(String i18nCode) {
			this.i18nCode = i18nCode;
		}
	}
}

