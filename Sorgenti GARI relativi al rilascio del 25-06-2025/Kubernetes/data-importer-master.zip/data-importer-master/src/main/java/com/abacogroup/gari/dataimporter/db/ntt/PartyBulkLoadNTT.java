package com.abacogroup.gari.dataimporter.db.ntt;

import java.time.OffsetDateTime;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PartyBulkLoadNTT {

	private String id; // ULID as a String
	private String cuaa;
	private String tenant;
	private Long partyId; // Initially null
	private Integer campagna; // Initially null
	private OffsetDateTime dtStart;
	private OffsetDateTime dtEnd;
	private Short lastOkStep; // Nullable smallint
	private String importStatus; // Default: TODO
}
