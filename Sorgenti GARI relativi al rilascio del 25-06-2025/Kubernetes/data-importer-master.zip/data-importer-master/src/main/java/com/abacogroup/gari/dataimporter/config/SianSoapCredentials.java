package com.abacogroup.gari.dataimporter.config;

import lombok.Data;

@Data
public class SianSoapCredentials {
    private String username;
    private String password;
}
