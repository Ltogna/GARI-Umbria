package com.abacogroup.gari.dataimporter.db.dao;

import java.util.List;

import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.customizer.BindBean;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;

import com.abacogroup.gari.dataimporter.db.ntt.LoggerNTT;

public interface LoggerDAO {

	@SqlUpdate("INSERT INTO dataimporter_logger (request_time, \"user\", url, http_status, response_body, method_name, object_request, cuaa_code,request_id) " +
			"VALUES (:request_time, :user, :url, :http_status, :response_body, :method_name, :object_request, :cuaa_code,:request_id)")
	void insert(@BindBean LoggerNTT loggerntt);

	@SqlQuery("SELECT * FROM dataimporter_logger " +
			"WHERE request_id = :requestId")
	List<LoggerNTT> findLoggersWithDifferentObjectRequest(
			@Bind("requestId") String requestId);
}
