
package com.abacogroup.gari.dataimporter.soap.fascicolo;

import java.util.ArrayList;
import java.util.List;
import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ISWSAllevamento16 complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ISWSAllevamento16"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="IdAlleBDN"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}int"&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="CodiceAzienda" type="{http://cooperazione.sian.it/schema/fascicolo}Data"/&gt;
 *         &lt;element name="CodiceSpecie" type="{http://cooperazione.sian.it/schema/fascicolo}Anno"/&gt;
 *         &lt;element name="CodFiscaleProp" type="{http://cooperazione.sian.it/schema/fascicolo}Cuaa"/&gt;
 *         &lt;element name="DenomProp"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;maxLength value="128"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="TipoProd"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;maxLength value="5"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="AutorizLatte"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;enumeration value="0"/&gt;
 *               &lt;enumeration value="1"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="IscrLibriGene"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}int"&gt;
 *               &lt;enumeration value="0"/&gt;
 *               &lt;enumeration value="1"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="DataIniziAtti" type="{http://cooperazione.sian.it/schema/fascicolo}Data"/&gt;
 *         &lt;element name="DataFineAtti" type="{http://cooperazione.sian.it/schema/fascicolo}Data"/&gt;
 *         &lt;element name="MetodoAllevamento"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}int"&gt;
 *               &lt;enumeration value="1"/&gt;
 *               &lt;enumeration value="2"/&gt;
 *               &lt;enumeration value="3"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="DestinazioneAllev"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;enumeration value="0"/&gt;
 *               &lt;enumeration value="1"/&gt;
 *               &lt;enumeration value="2"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="StalAllev" type="{http://cooperazione.sian.it/schema/fascicolo}ISWSStallaAllevamento"/&gt;
 *         &lt;element name="PropAllev" type="{http://cooperazione.sian.it/schema/fascicolo}ISWSPropAllevamento" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="DeteAllev" type="{http://cooperazione.sian.it/schema/fascicolo}ISWSPropAllevamento" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="ConsAllev" type="{http://cooperazione.sian.it/schema/fascicolo}ISWSCapoAllevamento16"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ISWSAllevamento16", propOrder = {
    "idAlleBDN",
    "codiceAzienda",
    "codiceSpecie",
    "codFiscaleProp",
    "denomProp",
    "tipoProd",
    "autorizLatte",
    "iscrLibriGene",
    "dataIniziAtti",
    "dataFineAtti",
    "metodoAllevamento",
    "destinazioneAllev",
    "stalAllev",
    "propAllev",
    "deteAllev",
    "consAllev"
})
public class ISWSAllevamento16 {

    @XmlElement(name = "IdAlleBDN", required = true, type = Integer.class, nillable = true)
    protected Integer idAlleBDN;
    @XmlElement(name = "CodiceAzienda", required = true)
    protected String codiceAzienda;
    @XmlElement(name = "CodiceSpecie", required = true)
    protected String codiceSpecie;
    @XmlElement(name = "CodFiscaleProp", required = true)
    protected String codFiscaleProp;
    @XmlElement(name = "DenomProp", required = true, nillable = true)
    protected String denomProp;
    @XmlElement(name = "TipoProd", required = true, nillable = true)
    protected String tipoProd;
    @XmlElement(name = "AutorizLatte", required = true)
    protected String autorizLatte;
    @XmlElement(name = "IscrLibriGene", required = true, type = Integer.class, nillable = true)
    protected Integer iscrLibriGene;
    @XmlElement(name = "DataIniziAtti", required = true)
    protected String dataIniziAtti;
    @XmlElement(name = "DataFineAtti", required = true, nillable = true)
    protected String dataFineAtti;
    @XmlElement(name = "MetodoAllevamento", required = true, type = Integer.class, nillable = true)
    protected Integer metodoAllevamento;
    @XmlElement(name = "DestinazioneAllev", required = true, nillable = true)
    protected String destinazioneAllev;
    @XmlElement(name = "StalAllev", required = true, nillable = true)
    protected ISWSStallaAllevamento stalAllev;
    @XmlElement(name = "PropAllev", nillable = true)
    protected List<ISWSPropAllevamento> propAllev;
    @XmlElement(name = "DeteAllev", nillable = true)
    protected List<ISWSPropAllevamento> deteAllev;
    @XmlElement(name = "ConsAllev", required = true, nillable = true)
    protected ISWSCapoAllevamento16 consAllev;

    /**
     * Gets the value of the idAlleBDN property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getIdAlleBDN() {
        return idAlleBDN;
    }

    /**
     * Sets the value of the idAlleBDN property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setIdAlleBDN(Integer value) {
        this.idAlleBDN = value;
    }

    /**
     * Gets the value of the codiceAzienda property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodiceAzienda() {
        return codiceAzienda;
    }

    /**
     * Sets the value of the codiceAzienda property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodiceAzienda(String value) {
        this.codiceAzienda = value;
    }

    /**
     * Gets the value of the codiceSpecie property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodiceSpecie() {
        return codiceSpecie;
    }

    /**
     * Sets the value of the codiceSpecie property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodiceSpecie(String value) {
        this.codiceSpecie = value;
    }

    /**
     * Gets the value of the codFiscaleProp property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodFiscaleProp() {
        return codFiscaleProp;
    }

    /**
     * Sets the value of the codFiscaleProp property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodFiscaleProp(String value) {
        this.codFiscaleProp = value;
    }

    /**
     * Gets the value of the denomProp property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDenomProp() {
        return denomProp;
    }

    /**
     * Sets the value of the denomProp property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDenomProp(String value) {
        this.denomProp = value;
    }

    /**
     * Gets the value of the tipoProd property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTipoProd() {
        return tipoProd;
    }

    /**
     * Sets the value of the tipoProd property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTipoProd(String value) {
        this.tipoProd = value;
    }

    /**
     * Gets the value of the autorizLatte property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAutorizLatte() {
        return autorizLatte;
    }

    /**
     * Sets the value of the autorizLatte property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAutorizLatte(String value) {
        this.autorizLatte = value;
    }

    /**
     * Gets the value of the iscrLibriGene property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getIscrLibriGene() {
        return iscrLibriGene;
    }

    /**
     * Sets the value of the iscrLibriGene property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setIscrLibriGene(Integer value) {
        this.iscrLibriGene = value;
    }

    /**
     * Gets the value of the dataIniziAtti property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDataIniziAtti() {
        return dataIniziAtti;
    }

    /**
     * Sets the value of the dataIniziAtti property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDataIniziAtti(String value) {
        this.dataIniziAtti = value;
    }

    /**
     * Gets the value of the dataFineAtti property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDataFineAtti() {
        return dataFineAtti;
    }

    /**
     * Sets the value of the dataFineAtti property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDataFineAtti(String value) {
        this.dataFineAtti = value;
    }

    /**
     * Gets the value of the metodoAllevamento property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getMetodoAllevamento() {
        return metodoAllevamento;
    }

    /**
     * Sets the value of the metodoAllevamento property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setMetodoAllevamento(Integer value) {
        this.metodoAllevamento = value;
    }

    /**
     * Gets the value of the destinazioneAllev property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDestinazioneAllev() {
        return destinazioneAllev;
    }

    /**
     * Sets the value of the destinazioneAllev property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDestinazioneAllev(String value) {
        this.destinazioneAllev = value;
    }

    /**
     * Gets the value of the stalAllev property.
     * 
     * @return
     *     possible object is
     *     {@link ISWSStallaAllevamento }
     *     
     */
    public ISWSStallaAllevamento getStalAllev() {
        return stalAllev;
    }

    /**
     * Sets the value of the stalAllev property.
     * 
     * @param value
     *     allowed object is
     *     {@link ISWSStallaAllevamento }
     *     
     */
    public void setStalAllev(ISWSStallaAllevamento value) {
        this.stalAllev = value;
    }

    /**
     * Gets the value of the propAllev property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the Jakarta XML Binding object.
     * This is why there is not a <CODE>set</CODE> method for the propAllev property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getPropAllev().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ISWSPropAllevamento }
     * 
     * 
     */
    public List<ISWSPropAllevamento> getPropAllev() {
        if (propAllev == null) {
            propAllev = new ArrayList<ISWSPropAllevamento>();
        }
        return this.propAllev;
    }

    /**
     * Gets the value of the deteAllev property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the Jakarta XML Binding object.
     * This is why there is not a <CODE>set</CODE> method for the deteAllev property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getDeteAllev().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ISWSPropAllevamento }
     * 
     * 
     */
    public List<ISWSPropAllevamento> getDeteAllev() {
        if (deteAllev == null) {
            deteAllev = new ArrayList<ISWSPropAllevamento>();
        }
        return this.deteAllev;
    }

    /**
     * Gets the value of the consAllev property.
     * 
     * @return
     *     possible object is
     *     {@link ISWSCapoAllevamento16 }
     *     
     */
    public ISWSCapoAllevamento16 getConsAllev() {
        return consAllev;
    }

    /**
     * Sets the value of the consAllev property.
     * 
     * @param value
     *     allowed object is
     *     {@link ISWSCapoAllevamento16 }
     *     
     */
    public void setConsAllev(ISWSCapoAllevamento16 value) {
        this.consAllev = value;
    }

}
