package com.abacogroup.gari.dataimporter.DTOs;

import com.abacogroup.jaxrsutils.callerv2.ICallerInput;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Map;

import static com.abacogroup.jaxrsutils.GenericCallerService.GET_METHOD;

/**
 * 
 * @author Emanuele Crocilla
 *
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class GetUserByTenant implements ICallerInput {

	private String url;
	private String tenant;
	private String token;
	private String username;

	public static GetUserByTenant of(String tenant, String username, String url, String token) {
		return GetUserByTenant.builder()
				.url(url)
				.tenant(tenant)
				.token(token)
				.username(username)
				.build();
	}

	@Override
	public Map<String, Object> getPathVariablesMap() {
		return Map.of("username", this.getUsername(), "tenant", this.getTenant());
	}

	@Override
	public String provideAuthToken() {
		return this.getToken();
	}

	@Override
	public String getHttpMethod() {
		return GET_METHOD;
	}
}
