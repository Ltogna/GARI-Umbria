
package com.abacogroup.gari.dataimporter.soap.fascicolo;

import java.util.ArrayList;
import java.util.List;
import jakarta.xml.bind.JAXBElement;
import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlElementRef;
import jakarta.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ISWSRespAnagFascicolo15 complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ISWSRespAnagFascicolo15"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="CUAA" type="{http://cooperazione.sian.it/schema/fascicolo}Cuaa"/&gt;
 *         &lt;element name="tipoAzienda" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;length value="2"/&gt;
 *               &lt;enumeration value="PF"/&gt;
 *               &lt;enumeration value="PG"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="denominazione"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;minLength value="1"/&gt;
 *               &lt;maxLength value="150"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="nomePF"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;maxLength value="20"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="sessoPF" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;length value="1"/&gt;
 *               &lt;enumeration value="M"/&gt;
 *               &lt;enumeration value="F"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="dataNascitaPF" type="{http://cooperazione.sian.it/schema/fascicolo}Data"/&gt;
 *         &lt;element name="comuneNascitaPF"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;length value="4"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="TipoDocumento" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;enumeration value="1"/&gt;
 *               &lt;enumeration value="2"/&gt;
 *               &lt;enumeration value="3"/&gt;
 *               &lt;enumeration value="4"/&gt;
 *               &lt;enumeration value="5"/&gt;
 *               &lt;enumeration value="6"/&gt;
 *               &lt;enumeration value="7"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="NumeroDocumento"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;maxLength value="16"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="DataDocumento" type="{http://cooperazione.sian.it/schema/fascicolo}Data"/&gt;
 *         &lt;element name="DataScadDocumento" type="{http://cooperazione.sian.it/schema/fascicolo}Data"/&gt;
 *         &lt;element name="sedeResidenza" type="{http://cooperazione.sian.it/schema/fascicolo}ISWSIndirizzo"/&gt;
 *         &lt;element name="recapito" type="{http://cooperazione.sian.it/schema/fascicolo}ISWSIndirizzo"/&gt;
 *         &lt;element name="DescPec" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;maxLength value="100"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="Email" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;maxLength value="100"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="iscrizioneRea" type="{http://cooperazione.sian.it/schema/fascicolo}ISWSIscrizioneCC" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="iscrizioneRegistroImprese" type="{http://cooperazione.sian.it/schema/fascicolo}ISWSIscrizioneCC" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="matricolaINPS" type="{http://cooperazione.sian.it/schema/fascicolo}ISWSCodiceINPS" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="organismoPagatore"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;length value="4"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="dataAperturaFascicolo" type="{http://cooperazione.sian.it/schema/fascicolo}Data"/&gt;
 *         &lt;element name="dataChiusuraFascicolo" type="{http://cooperazione.sian.it/schema/fascicolo}Data"/&gt;
 *         &lt;element name="tipoDetentore" type="{http://cooperazione.sian.it/schema/fascicolo}CodiceTipoDetentore"/&gt;
 *         &lt;element name="detentore" type="{http://cooperazione.sian.it/schema/fascicolo}Detentore"/&gt;
 *         &lt;element name="dataValidazFascicolo" type="{http://cooperazione.sian.it/schema/fascicolo}Data"/&gt;
 *         &lt;element name="schedaValidazione"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;maxLength value="30"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="dataSchedaValidazione" type="{http://cooperazione.sian.it/schema/fascicolo}Data"/&gt;
 *         &lt;element name="dataSottMandato" type="{http://cooperazione.sian.it/schema/fascicolo}Data"/&gt;
 *         &lt;element name="dataElaborazione" type="{http://cooperazione.sian.it/schema/fascicolo}Data"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ISWSRespAnagFascicolo15", propOrder = {
    "cuaa",
    "tipoAzienda",
    "denominazione",
    "nomePF",
    "sessoPF",
    "dataNascitaPF",
    "comuneNascitaPF",
    "tipoDocumento",
    "numeroDocumento",
    "dataDocumento",
    "dataScadDocumento",
    "sedeResidenza",
    "recapito",
    "descPec",
    "email",
    "iscrizioneRea",
    "iscrizioneRegistroImprese",
    "matricolaINPS",
    "organismoPagatore",
    "dataAperturaFascicolo",
    "dataChiusuraFascicolo",
    "tipoDetentore",
    "detentore",
    "dataValidazFascicolo",
    "schedaValidazione",
    "dataSchedaValidazione",
    "dataSottMandato",
    "dataElaborazione"
})
public class ISWSRespAnagFascicolo15 {

    @XmlElement(name = "CUAA", required = true)
    protected String cuaa;
    protected String tipoAzienda;
    @XmlElement(required = true)
    protected String denominazione;
    @XmlElement(required = true, nillable = true)
    protected String nomePF;
    @XmlElementRef(name = "sessoPF", namespace = "http://cooperazione.sian.it/schema/fascicolo", type = JAXBElement.class, required = false)
    protected JAXBElement<String> sessoPF;
    @XmlElement(required = true, nillable = true)
    protected String dataNascitaPF;
    @XmlElement(required = true, nillable = true)
    protected String comuneNascitaPF;
    @XmlElementRef(name = "TipoDocumento", namespace = "http://cooperazione.sian.it/schema/fascicolo", type = JAXBElement.class, required = false)
    protected JAXBElement<String> tipoDocumento;
    @XmlElement(name = "NumeroDocumento", required = true, nillable = true)
    protected String numeroDocumento;
    @XmlElement(name = "DataDocumento", required = true, nillable = true)
    protected String dataDocumento;
    @XmlElement(name = "DataScadDocumento", required = true, nillable = true)
    protected String dataScadDocumento;
    @XmlElement(required = true)
    protected ISWSIndirizzo sedeResidenza;
    @XmlElement(required = true, nillable = true)
    protected ISWSIndirizzo recapito;
    @XmlElementRef(name = "DescPec", namespace = "http://cooperazione.sian.it/schema/fascicolo", type = JAXBElement.class, required = false)
    protected JAXBElement<String> descPec;
    @XmlElementRef(name = "Email", namespace = "http://cooperazione.sian.it/schema/fascicolo", type = JAXBElement.class, required = false)
    protected JAXBElement<String> email;
    @XmlElement(nillable = true)
    protected List<ISWSIscrizioneCC> iscrizioneRea;
    @XmlElement(nillable = true)
    protected List<ISWSIscrizioneCC> iscrizioneRegistroImprese;
    @XmlElement(nillable = true)
    protected List<ISWSCodiceINPS> matricolaINPS;
    @XmlElement(required = true)
    protected String organismoPagatore;
    @XmlElement(required = true)
    protected String dataAperturaFascicolo;
    @XmlElement(required = true, nillable = true)
    protected String dataChiusuraFascicolo;
    @XmlElement(required = true, nillable = true)
    protected String tipoDetentore;
    @XmlElement(required = true, nillable = true)
    protected String detentore;
    @XmlElement(required = true, nillable = true)
    protected String dataValidazFascicolo;
    @XmlElement(required = true, nillable = true)
    protected String schedaValidazione;
    @XmlElement(required = true, nillable = true)
    protected String dataSchedaValidazione;
    @XmlElement(required = true, nillable = true)
    protected String dataSottMandato;
    @XmlElement(required = true, nillable = true)
    protected String dataElaborazione;

    /**
     * Gets the value of the cuaa property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCUAA() {
        return cuaa;
    }

    /**
     * Sets the value of the cuaa property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCUAA(String value) {
        this.cuaa = value;
    }

    /**
     * Gets the value of the tipoAzienda property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTipoAzienda() {
        return tipoAzienda;
    }

    /**
     * Sets the value of the tipoAzienda property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTipoAzienda(String value) {
        this.tipoAzienda = value;
    }

    /**
     * Gets the value of the denominazione property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDenominazione() {
        return denominazione;
    }

    /**
     * Sets the value of the denominazione property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDenominazione(String value) {
        this.denominazione = value;
    }

    /**
     * Gets the value of the nomePF property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNomePF() {
        return nomePF;
    }

    /**
     * Sets the value of the nomePF property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNomePF(String value) {
        this.nomePF = value;
    }

    /**
     * Gets the value of the sessoPF property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getSessoPF() {
        return sessoPF;
    }

    /**
     * Sets the value of the sessoPF property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setSessoPF(JAXBElement<String> value) {
        this.sessoPF = value;
    }

    /**
     * Gets the value of the dataNascitaPF property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDataNascitaPF() {
        return dataNascitaPF;
    }

    /**
     * Sets the value of the dataNascitaPF property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDataNascitaPF(String value) {
        this.dataNascitaPF = value;
    }

    /**
     * Gets the value of the comuneNascitaPF property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getComuneNascitaPF() {
        return comuneNascitaPF;
    }

    /**
     * Sets the value of the comuneNascitaPF property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setComuneNascitaPF(String value) {
        this.comuneNascitaPF = value;
    }

    /**
     * Gets the value of the tipoDocumento property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getTipoDocumento() {
        return tipoDocumento;
    }

    /**
     * Sets the value of the tipoDocumento property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setTipoDocumento(JAXBElement<String> value) {
        this.tipoDocumento = value;
    }

    /**
     * Gets the value of the numeroDocumento property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNumeroDocumento() {
        return numeroDocumento;
    }

    /**
     * Sets the value of the numeroDocumento property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNumeroDocumento(String value) {
        this.numeroDocumento = value;
    }

    /**
     * Gets the value of the dataDocumento property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDataDocumento() {
        return dataDocumento;
    }

    /**
     * Sets the value of the dataDocumento property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDataDocumento(String value) {
        this.dataDocumento = value;
    }

    /**
     * Gets the value of the dataScadDocumento property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDataScadDocumento() {
        return dataScadDocumento;
    }

    /**
     * Sets the value of the dataScadDocumento property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDataScadDocumento(String value) {
        this.dataScadDocumento = value;
    }

    /**
     * Gets the value of the sedeResidenza property.
     * 
     * @return
     *     possible object is
     *     {@link ISWSIndirizzo }
     *     
     */
    public ISWSIndirizzo getSedeResidenza() {
        return sedeResidenza;
    }

    /**
     * Sets the value of the sedeResidenza property.
     * 
     * @param value
     *     allowed object is
     *     {@link ISWSIndirizzo }
     *     
     */
    public void setSedeResidenza(ISWSIndirizzo value) {
        this.sedeResidenza = value;
    }

    /**
     * Gets the value of the recapito property.
     * 
     * @return
     *     possible object is
     *     {@link ISWSIndirizzo }
     *     
     */
    public ISWSIndirizzo getRecapito() {
        return recapito;
    }

    /**
     * Sets the value of the recapito property.
     * 
     * @param value
     *     allowed object is
     *     {@link ISWSIndirizzo }
     *     
     */
    public void setRecapito(ISWSIndirizzo value) {
        this.recapito = value;
    }

    /**
     * Gets the value of the descPec property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getDescPec() {
        return descPec;
    }

    /**
     * Sets the value of the descPec property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setDescPec(JAXBElement<String> value) {
        this.descPec = value;
    }

    /**
     * Gets the value of the email property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getEmail() {
        return email;
    }

    /**
     * Sets the value of the email property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setEmail(JAXBElement<String> value) {
        this.email = value;
    }

    /**
     * Gets the value of the iscrizioneRea property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the Jakarta XML Binding object.
     * This is why there is not a <CODE>set</CODE> method for the iscrizioneRea property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getIscrizioneRea().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ISWSIscrizioneCC }
     * 
     * 
     */
    public List<ISWSIscrizioneCC> getIscrizioneRea() {
        if (iscrizioneRea == null) {
            iscrizioneRea = new ArrayList<ISWSIscrizioneCC>();
        }
        return this.iscrizioneRea;
    }

    /**
     * Gets the value of the iscrizioneRegistroImprese property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the Jakarta XML Binding object.
     * This is why there is not a <CODE>set</CODE> method for the iscrizioneRegistroImprese property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getIscrizioneRegistroImprese().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ISWSIscrizioneCC }
     * 
     * 
     */
    public List<ISWSIscrizioneCC> getIscrizioneRegistroImprese() {
        if (iscrizioneRegistroImprese == null) {
            iscrizioneRegistroImprese = new ArrayList<ISWSIscrizioneCC>();
        }
        return this.iscrizioneRegistroImprese;
    }

    /**
     * Gets the value of the matricolaINPS property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the Jakarta XML Binding object.
     * This is why there is not a <CODE>set</CODE> method for the matricolaINPS property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getMatricolaINPS().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ISWSCodiceINPS }
     * 
     * 
     */
    public List<ISWSCodiceINPS> getMatricolaINPS() {
        if (matricolaINPS == null) {
            matricolaINPS = new ArrayList<ISWSCodiceINPS>();
        }
        return this.matricolaINPS;
    }

    /**
     * Gets the value of the organismoPagatore property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOrganismoPagatore() {
        return organismoPagatore;
    }

    /**
     * Sets the value of the organismoPagatore property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOrganismoPagatore(String value) {
        this.organismoPagatore = value;
    }

    /**
     * Gets the value of the dataAperturaFascicolo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDataAperturaFascicolo() {
        return dataAperturaFascicolo;
    }

    /**
     * Sets the value of the dataAperturaFascicolo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDataAperturaFascicolo(String value) {
        this.dataAperturaFascicolo = value;
    }

    /**
     * Gets the value of the dataChiusuraFascicolo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDataChiusuraFascicolo() {
        return dataChiusuraFascicolo;
    }

    /**
     * Sets the value of the dataChiusuraFascicolo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDataChiusuraFascicolo(String value) {
        this.dataChiusuraFascicolo = value;
    }

    /**
     * Gets the value of the tipoDetentore property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTipoDetentore() {
        return tipoDetentore;
    }

    /**
     * Sets the value of the tipoDetentore property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTipoDetentore(String value) {
        this.tipoDetentore = value;
    }

    /**
     * Gets the value of the detentore property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDetentore() {
        return detentore;
    }

    /**
     * Sets the value of the detentore property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDetentore(String value) {
        this.detentore = value;
    }

    /**
     * Gets the value of the dataValidazFascicolo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDataValidazFascicolo() {
        return dataValidazFascicolo;
    }

    /**
     * Sets the value of the dataValidazFascicolo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDataValidazFascicolo(String value) {
        this.dataValidazFascicolo = value;
    }

    /**
     * Gets the value of the schedaValidazione property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSchedaValidazione() {
        return schedaValidazione;
    }

    /**
     * Sets the value of the schedaValidazione property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSchedaValidazione(String value) {
        this.schedaValidazione = value;
    }

    /**
     * Gets the value of the dataSchedaValidazione property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDataSchedaValidazione() {
        return dataSchedaValidazione;
    }

    /**
     * Sets the value of the dataSchedaValidazione property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDataSchedaValidazione(String value) {
        this.dataSchedaValidazione = value;
    }

    /**
     * Gets the value of the dataSottMandato property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDataSottMandato() {
        return dataSottMandato;
    }

    /**
     * Sets the value of the dataSottMandato property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDataSottMandato(String value) {
        this.dataSottMandato = value;
    }

    /**
     * Gets the value of the dataElaborazione property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDataElaborazione() {
        return dataElaborazione;
    }

    /**
     * Sets the value of the dataElaborazione property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDataElaborazione(String value) {
        this.dataElaborazione = value;
    }

}
