package com.abacogroup.gari.dataimporter.services;

import com.abacogroup.dropwizard.auth.sso2.Sso2Client;
import com.abacogroup.gari.dataimporter.DTOs.*;
import com.abacogroup.gari.dataimporter.config.SianSoapCredentials;
import com.abacogroup.gari.dataimporter.DataImporterConfiguration;
import com.abacogroup.gari.dataimporter.db.dao.LoggerDAO;
import com.abacogroup.gari.dataimporter.soap.OprFascicoloFS6ServiceName;
import com.abacogroup.gari.dataimporter.soap.fascicolo.*;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.ws.rs.client.Client;
import lombok.extern.slf4j.Slf4j;
import java.net.URL;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@Slf4j
public class ImportPartyCreditService extends ADataImporterService {

	private SianSoapCredentials sianSoapCredentials;

	public ImportPartyCreditService(Sso2Client sso2Client, Client client, DataImporterConfiguration configuration, ObjectMapper objectMapper,
			LoggerDAO loggerDAO) {
		super(sso2Client, client, configuration, objectMapper, loggerDAO);
		this.sianSoapCredentials = configuration.getSianSoapCredentials();
	}

	public void ImportPartyCredits(String tenantId, String cuaa) {
		ObjectFactory objectFactory = new ObjectFactory();
		URL url = getWsdlUrl(tenantId);
		// Initialize SOAP client
		OprFascicoloFS6 oprFascicoloFS6_TEST = new OprFascicoloFS6(url);
		InterService serviceLocalWSDL = oprFascicoloFS6_TEST.getOprFascicoloFS6();
		SOAPAutenticazione soapAutenticazione = objectFactory.createSOAPAutenticazione();
		soapAutenticazione.setUsername(sianSoapCredentials.getUsername());
		soapAutenticazione.setPassword(sianSoapCredentials.getPassword());
		soapAutenticazione.setNomeServizio(OprFascicoloFS6ServiceName.LEGGICONTICORRENTIFS6);
		ISWSToOprResponse iswsToOprResponse = serviceLocalWSDL.leggiContiCorrentiFS6(cuaa, soapAutenticazione);
		PartyResponse party = getParty(tenantId, cuaa);
		// Logic
		List<ISWSContoCorrente> cgPayment = iswsToOprResponse.getRisposta14();
		List<BankAccountResponse> cPayment = getCuaaPayments(tenantId, cuaa, party.getId(), null);
		mappPayments(cPayment, cgPayment, tenantId, party.getId());
	}

	private void mappPayments(List<BankAccountResponse> cPayment, List<ISWSContoCorrente> cgPayment, String tenant, Integer partyId) {

		List<BankAccountResponse> removeBankAccount = new ArrayList<>();
		List<BankAccount> insertedBankAccount = new ArrayList<>();

		// Find added payments
		for (BankAccountResponse bankAccount : cPayment) {
			boolean existsInCgPayment = cgPayment.stream()
					.anyMatch(cg -> bankAccount.getIban().equals(cg.getContoCorrente()));
			if (!existsInCgPayment) {
				removeBankAccount.add(bankAccount); // New payment added
			}
		}
		for (ISWSContoCorrente cgAccount : cgPayment) {
			boolean existsInCPayment = cPayment.stream()
					.anyMatch(cp -> cgAccount.getContoCorrente().equals(cp.getIban()));
			if (!existsInCPayment) {
				insertedBankAccount.add(ConvertCGToBankAccount(cgAccount)); // Payment to be removed
			}
		}
		removeBankAccount.forEach(x -> {
			removePaymentMethode(tenant, partyId, x.getId());
		});
		insertedBankAccount.forEach(x -> {
			SendCreatePayment(tenant, partyId, x);
		});
	}

	private BankAccount ConvertCGToBankAccount(ISWSContoCorrente cg) {
		return BankAccount.builder()
				.description(cg.getContoCorrente())
				.defaultBankAccount(false)
				.network("SEPA")
				.iban(cg.getContoCorrente())
				.swiftBic(cg.getCodiSwift1())
				.bicExtraSepa(cg.getCodiSwift1())
				.bankCountry((cg.getContoCorrente() != null && cg.getContoCorrente().length() >= 2 ? cg.getContoCorrente().substring(0, 2) : null))
				.bankName(null)
				.bankBranch(null)
				.dayFrom(AbsoluteDate.of(LocalDate.now()).toString())
				.build();
	}

	public void removePaymentMethode(String tenantId, Integer partyId, Long accountId) {
		String url = String.format("%s/%s/api-priv/v1/payment-methods/parties/%s/accounts/%s", dossierDataModule, tenantId, partyId, accountId);
		sendPutRequest(tenantId, url, null, null, "removePaymentMethode");
	}

	public BankAccountResponse SendCreatePayment(String tenantId, Integer partyId, BankAccount modelRequest) {
		String url = String.format("%s/%s/api-priv/v1/payment-methods/parties/%s/accounts", dossierDataModule, tenantId, partyId);
		return sendPostRequest(tenantId, url, modelRequest, BankAccountResponse.class, "SendCreatePayment");
	}

	private List<BankAccountResponse> getCuaaPayments(String tenant, String cuaa, Integer partyId, String nextKey) {
		var response = new RecordResponse<BankAccountResponse>();

		do {
			String url = String.format("%s/%s/api-priv/v1/payment-methods/parties/%s/accounts",
					dossierDataModule,
					tenant,
					partyId,
					nextKey != null ? "&nextKey=" + nextKey : "");
			var data = sendGetRequestWithAuth(
					url,
					new TypeReference<RecordResponse<BankAccountResponse>>() {
					},
					"Get Lau Services",
					tenant);

			if (data == null || data.getRecords() == null) {
				break;
			}
			if (response.getRecords() == null) {
				response.setRecords(data.getRecords());
			} else {
				response.getRecords().addAll(data.getRecords());
			}
			nextKey = data.getNextKey();
		} while (nextKey != null);
		return response.getRecords();
	}
}
