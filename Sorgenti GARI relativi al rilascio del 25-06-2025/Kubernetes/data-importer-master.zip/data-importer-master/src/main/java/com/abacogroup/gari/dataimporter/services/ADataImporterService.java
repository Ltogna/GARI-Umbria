package com.abacogroup.gari.dataimporter.services;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeFormatterBuilder;
import java.time.temporal.ChronoField;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import com.abacogroup.dropwizard.auth.sso2.Sso2Client;
import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.gari.dataimporter.DataImporterConfiguration;
import com.abacogroup.gari.dataimporter.DTOs.FieldDefinition;
import com.abacogroup.gari.dataimporter.DTOs.PartyResponse;
import com.abacogroup.gari.dataimporter.db.dao.LoggerDAO;
import com.abacogroup.gari.dataimporter.db.ntt.LoggerNTT;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectReader;
import com.github.benmanes.caffeine.cache.Caffeine;
import com.github.benmanes.caffeine.cache.LoadingCache;

import io.dropwizard.auth.AuthenticationException;
import jakarta.ws.rs.client.Client;
import jakarta.ws.rs.client.Entity;
import jakarta.ws.rs.client.WebTarget;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.core.Response.Status.Family;
import jakarta.ws.rs.core.SecurityContext;

public abstract class ADataImporterService {

	public static final String IMPORT_SERVICE_ACCOUNT = "IMPORT_SERVICE_ACCOUNT";

	protected final Sso2Client sso2client;
	protected final Client client;
	protected final String cropPlanUrl;
	protected final String mtlsProxyUrl;
	protected final String partyRegistry;
	protected final String partyRegistryAcl;
	protected final String vectorDataLayers;
	protected final String lauService;
	protected final String dossierDataModule;
	protected final String dossierUrl;
	protected Boolean isImportCP;
	protected final ObjectMapper mapper;
	private final LoggerDAO loggerDAO;
	protected  LoggerNTT loggerntt = null;
	protected LoadingCache<String, String> authTokenCache;
	protected ThreadLocal<String> requestId = new ThreadLocal<>();

	public ADataImporterService(Sso2Client sso2Client, Client client, DataImporterConfiguration configuration, ObjectMapper mapper, LoggerDAO loggerDAO) {
		this.sso2client = sso2Client;
		this.client = client;
		this.cropPlanUrl = configuration.getCropPlanUrl();
		this.mtlsProxyUrl = configuration.getMtlsProxyUrl();
		this.partyRegistry = configuration.getPartyRegistry();
		this.partyRegistryAcl = configuration.getPartyRegistryAcl();
		this.vectorDataLayers = configuration.getVectorDataLayers();
		this.lauService = configuration.getLauService();
		this.dossierDataModule = configuration.getDossierDataModule();
		this.dossierUrl = configuration.getDossierUrl();
		this.mapper = mapper;
		this.isImportCP = false;
		this.loggerDAO = loggerDAO;

		this.authTokenCache = Caffeine.newBuilder()
				.maximumSize(1000)
				.expireAfterWrite(Duration.ofMinutes(30))
				.build(this::getAuthToken);
	}

	protected <T> T sendPostRequestWithAuth(String url, Object requestBody, TypeReference<T> responseType, String methodeName, String tenantId) {
		return sendRequest(url, responseType, authTokenCache.get(tenantId), requestBody, "POST", methodeName, tenantId);
	}

	protected <T> T sendGetRequestWithAuth(String url, TypeReference<T> responseType, String methodeName, String tenantId) {
		return sendRequest(url, responseType, authTokenCache.get(tenantId), null, "GET", methodeName, tenantId);
	}

	protected <T> T sendGetRequest(String tenantId, String url, Class<T> responseType, String methodeName) {
		return sendRequest(url, responseType, authTokenCache.get(tenantId), null, "GET", methodeName, tenantId);
	}

	protected <T> T sendPostRequest(String tenantId, String url, Object requestBody, Class<T> responseType, String methodeName) {
		return sendRequest(url, responseType, authTokenCache.get(tenantId), requestBody, "POST", methodeName, tenantId);
	}

	protected <T> T sendPostRequestGias(String tenantId, String url, Object requestBody, Class<T> responseType, String methodeName, String token) {
		return sendGiasRequest(url, responseType, token, requestBody, "POST", methodeName, tenantId);
	}

	protected <T> T sendPutRequest(String tenantId, String url, Object requestBody, Class<T> responseType, String methodeName) {
		Object _requestBody = requestBody != null ? requestBody : "{}";
		var result = sendRequest(url, responseType, authTokenCache.get(tenantId), _requestBody, "PUT", methodeName, tenantId);
		return result;
	}
	protected <T> T sendDeleteRequest(String tenantId, String url, Object requestBody, Class<T> responseType, String methodeName) {
		return sendRequest(url, responseType, authTokenCache.get(tenantId), requestBody, "DELETE", methodeName, tenantId);
	}

	protected <T> T sendRequest(String url, TypeReference<T> responseType, String authToken, Object requestBody, String method, String methodeName,
			String tenantId) {
		WebTarget target = client.target(url);
		Response response = null;
		String responseBody = null;
		try {
			response = createRequest(target, method, authToken, requestBody);
			response.bufferEntity();
			responseBody = response.readEntity(String.class);
			checkResponseStatus(response, url, tenantId, requestBody, methodeName, null,responseBody);
			return responseType == null ? null : mapReturn(response, responseType);
		} catch (Exception e) {
			checkResponseStatus(response, url, tenantId, requestBody, methodeName, null,responseBody);
			throw new RuntimeException(e);
		} finally {
			if (response != null)
				response.close();
		}
	}

	protected <T> T sendRequest(String url, Class<T> responseType, String authToken, Object requestBody, String method, String methodeName, String tenantId) {
		WebTarget target = client.target(url);
		Response response = null;
		try {
			response = createRequest(target, method, authToken, requestBody);
			response.bufferEntity();
			String responseBody = response.readEntity(String.class);
			checkResponseStatus(response, url, tenantId, requestBody, methodeName, null,responseBody);
			return responseType == null ? null : mapReturn(response, responseType);

		} catch (Exception e) {
			checkResponseStatus(response, url, tenantId, requestBody, methodeName, e,null);
			throw new RuntimeException(e);
		} finally {
			if (response != null)
				response.close();
		}
	}

	private Response createRequest(WebTarget target, String method, String authToken, Object requestBody) {
		switch (method.toUpperCase()) {
			case "GET":
				return target.request(MediaType.APPLICATION_JSON)
						.header("Authorization", "JWT " + authToken)
						.get();
			case "POST":
				return target.request(MediaType.APPLICATION_JSON)
						.header("Authorization", "JWT " + authToken)
						.post(Entity.json(requestBody));
			case "PUT":
				return target.request(MediaType.APPLICATION_JSON)
						.header("Authorization", "JWT " + authToken)
						.put(Entity.json(requestBody));
			case "DELETE":
				return target.request(MediaType.APPLICATION_JSON)
						.header("Authorization", "JWT " + authToken)
						.delete();
			default: {
				String uri = target.getUri().toString();
				throwDynamicException(uri, "", requestBody, method, "Unsupported HTTP method: " + method);
				throw new IllegalArgumentException("Unsupported HTTP method: " + method);
			}
		}
	}

	protected <T> T sendGiasRequest(String url, Class<T> responseType, String authToken, Object requestBody, String method, String methodeName,
			String tenantId) {
		WebTarget target = client.target(url);
		Response response = null;
		try {
			switch (method.toUpperCase()) {
				case "GET":
					response = target.request(MediaType.APPLICATION_JSON)
							.header("Authorization", "Bearer " + authToken)
							.get();
					break;
				case "POST":
					response = target.request(MediaType.APPLICATION_JSON)
							.header("Authorization", "Bearer " + authToken)
							.post(Entity.json(requestBody));
					break;
				case "PUT":
					response = target.request(MediaType.APPLICATION_JSON)
							.header("Authorization", "Bearer " + authToken)
							.put(Entity.json(requestBody));
					break;
				case "DELETE":
					response = target.request(MediaType.APPLICATION_JSON)
							.header("Authorization", "Bearer " + authToken)
							.delete();
					break;
				default:
					String uri = target.getUri().toString();
					throwDynamicException(uri, "", requestBody, method, "Unsupported HTTP method: " + method);
					throw new IllegalArgumentException("Unsupported HTTP method: " + method);
			}
			checkResponseStatus(response, url, tenantId, requestBody, methodeName, null,null);
			return responseType == null ? null : mapReturn(response, responseType);

		} catch (Exception e) {
			checkResponseStatus(response, url, tenantId, requestBody, methodeName, e,null);
			throw new RuntimeException(e);
		} finally {
			if (response != null)
				response.close();
		}
	}

	public String getAuthToken(String tenantId) {
		try {
			SecurityContext sc = sso2client.createSecurityContextFromUserName(tenantId, IMPORT_SERVICE_ACCOUNT);
			User serviceAccount = (User) sc.getUserPrincipal();
			return serviceAccount.getAuthToken();
		} catch (AuthenticationException e) {
			addLoggerException(e, 400, "Authenticate User 'IMPORT_SERVICE_ACCOUNT'", "Authenticate User", UserName(tenantId), e.getMessage(), loggerDAO);
			throw new RuntimeException("Authenticate User 'IMPORT_SERVICE_ACCOUNT'");
		}
	}

	protected String UserName(String tenant) {
		return tenant + "/" + IMPORT_SERVICE_ACCOUNT;
	}

	protected void throwDynamicException(String url, String tenant, Object requestBody, String method, String e) {
		addLoggerException(new Exception(e), 500, url, method, UserName(tenant), requestBody.toString(), loggerDAO);
	}

	protected void addLog(String url, String tenant, Object requestBody, String method, Integer status, String e) {
		addNewLog(status, url, method, UserName(tenant), requestBody.toString(), loggerDAO, e);
	}

	protected void checkResponseStatus(Response response, String url, String tenant, Object requestBody, String method, Exception ex, String responseBody) {
		try {
			if(!isLoggerNttEmpty(loggerntt))
				return;
			if (response != null && response.getStatusInfo().getFamily() != Family.SUCCESSFUL) {
				String body = responseBody != null ? responseBody : readBodyIgnoringErrors(response);
				String errorMessage = "Request failed with status: " + response.getStatus() + " and body: " + body;
				if (ex != null) {
					errorMessage += ex.getMessage();
				}
				ex = new Exception(errorMessage);
				var rb = mapper.writeValueAsString(requestBody);
				addLoggerException(ex, response.getStatus(), url, method, UserName(tenant), rb, loggerDAO);
				throw new RuntimeException("Error processing response", ex);
			} else if (ex != null) {
				var rb = mapper.writeValueAsString(requestBody);
				addLoggerException(ex, 500, url, method, UserName(tenant), rb, loggerDAO);
				throw new RuntimeException("Error processing response", ex);
			}
		} catch (Exception e) {
			addLoggerException(e, 500, url, method, UserName(tenant), null, loggerDAO);
			throw new RuntimeException(e.getMessage(), e);
		}
	}

	private String readBodyIgnoringErrors(Response response) {
		String body;
		try {
			body = response.readEntity(String.class);
		} catch (Exception e) {
			body = null;
		}
		return body;
	}

	public List<FieldDefinition> loadFieldDefinitions(String resourceName, String method) throws IOException {
		ObjectReader reader = mapper.readerFor(FieldDefinition.class);
		List<FieldDefinition> fieldDefinitions = new ArrayList<>();

		var in = ADataImporterService.class.getResourceAsStream(resourceName);
		try (BufferedReader r = new BufferedReader(new InputStreamReader(in))) {
			String line;
			while (true) {
				line = r.readLine();
				if (line == null) {
					break;
				}
				if (line.trim().isEmpty()) {
					continue;
				}
				try {
					FieldDefinition fieldDef = reader.readValue(line);
					fieldDefinitions.add(fieldDef);
				} catch (IOException e) {
					checkResponseStatus(null, "", "", resourceName, method, e,null);
					throw new RuntimeException(e);
				}

			}
		}

		return fieldDefinitions;
	}

	protected void addLoggerException(Exception exception, Integer status, String url, String methodName, String user, String requestBody,
			LoggerDAO loggerDAO) {
		if (loggerDAO != null) {
			ByteArrayOutputStream baos = new ByteArrayOutputStream(1024);
			try (PrintStream out = new PrintStream(baos)) {
				exception.printStackTrace(out);
			}

			addNewLog(status, url, methodName, user, requestBody, loggerDAO, baos.toString(StandardCharsets.UTF_8));
		}
	}
	private final ScheduledExecutorService scheduler = Executors.newSingleThreadScheduledExecutor();
	private void addNewLog(Integer status, String url, String methodName, String user, String requestBody, LoggerDAO loggerDAO, String body) {
		if (isLoggerNttEmpty(loggerntt)) {
			loggerntt = new LoggerNTT();
			loggerntt.setRequest_time(OffsetDateTime.now());
			loggerntt.setUser(user);
			loggerntt.setUrl(url);
			loggerntt.setRequest_id(requestId.get());
			loggerntt.setHttp_status(status);
			loggerntt.setCuaa_code("DEFAULT_CUAA_CODE");
			loggerntt.setResponse_body(body);
			loggerntt.setMethod_name(methodName);
			loggerntt.setObject_request(requestBody);
			scheduler.schedule(() -> {
				loggerntt = null;
			}, 5, TimeUnit.SECONDS);
			if(!isImportCP){
				loggerDAO.insert(loggerntt);
			}
		}
	}
	public void storeLog(Integer status, String url, String methodName, String user, String requestBody, Exception exception) {
		if (loggerDAO != null) {
			ByteArrayOutputStream baos = new ByteArrayOutputStream(1024);
			try (PrintStream out = new PrintStream(baos)) {
				exception.printStackTrace(out);
			}
			if(loggerntt == null){
				addNewLog(status, url, methodName, user, requestBody, loggerDAO, baos.toString(StandardCharsets.UTF_8));
			}
			loggerDAO.insert(loggerntt);
			loggerntt = null;
		}
	}

	public static OffsetDateTime parseToOffsetDateTime(String dateStr) {
		DateTimeFormatter formatter = new DateTimeFormatterBuilder()
				.appendPattern("yyyy-MM-dd'T'HH:mm:ss")
				.optionalStart()
				.appendFraction(ChronoField.NANO_OF_SECOND, 0, 9, true) // Handle fractional seconds (up to nanoseconds)
				.optionalEnd()
				.toFormatter();
		return OffsetDateTime.of(LocalDateTime.parse(dateStr, formatter), ZoneOffset.UTC);
	}

	protected <T> T mapReturn(Response response, Class<T> responseType) throws JsonProcessingException {
		if (response.getStatus() == 204) { // No Content status, no content returned from the end-point.
			return null;
		} else {
			return mapper.readValue(response.readEntity(String.class), responseType);
		}
	}

	protected PartyResponse getParty(String tenant, String cuaa) {
		String url = String.format("%s/%s/public/v1/parties/code/%s", partyRegistry, tenant, cuaa);
		PartyResponse pr = sendGetRequest(tenant, url, PartyResponse.class, "getParty");
		if (pr == null) {
			throwDynamicException(url, tenant, new Object(), "getParty", "Cam not find any bussines party");
		}
		return pr;
	}

	protected PartyResponse getPartyById(String tenant, Long id) {
		String url = String.format("%s/%s/public/v1/parties/%s", partyRegistry, tenant, id);
		PartyResponse pr = sendGetRequest(tenant, url, PartyResponse.class, "getParty");
		if (pr == null) {
			throwDynamicException(url, tenant, new Object(), "getParty", "Cam not find any bussines party");
		}
		return pr;
	}

	protected <T> T mapReturn(Response response, TypeReference<T> responseType) throws JsonProcessingException {
		if (response.getStatus() == 204) { // No Content status, no content returned from the end-point.
			return null;
		} else {
			return mapper.readValue(response.readEntity(String.class), responseType);
		}
	}

	protected URL getWsdlUrl(String tenantId) {
		URL url;
		try {
			url = ImportPartyRegistryService.class.getResource("/wsdl/OprFascicoloFS6.wsdl");
			if (url == null) {
				throwDynamicException("URL Create", tenantId, null, "URL Create", "WSDL file not found in classpath: /wsdl/OprFascicoloFS6.wsdl");
				throw new RuntimeException("WSDL file not found in classpath: /wsdl/OprFascicoloFS6.wsdl");
			}
		} catch (Exception e) {
			throwDynamicException("URL Create", tenantId, null, "Not Found OprFascicoloFS6.wsdl", "Error locating WSDL file");
			throw new RuntimeException("Error locating WSDL file", e);
		}
		return url;
	}
	private boolean isLoggerNttEmpty(LoggerNTT loggerntt) {
		return loggerntt == null ||(loggerntt.getCuaa_code() == null);
	}
}
