package com.abacogroup.gari.dataimporter.soap;

public interface OprFascicoloFS6ServiceName {
    String ANAGRAFICAAZIENDAFS6 = "AnagraficaAziendaFS6";
    String CHIUDICAPOFILAFSRTI = "ChiudiCapofilaFSRTI";
    String CHIUDICONSISTENZAFS6 = "ChiudiConsistenzaFS6";
    String CHIUDILEGAMEASSOCIATIVOFS = "ChiudiLegameAssociativoFS";
    String CHIUDIMANDANTEFSRTI = "ChiudiMandanteFSRTI";
    String DETTAGLIOSOGGETTOFS6 = "DettaglioSoggettoFS6";
    String ESISTEDURCCUAA = "EsisteDURCCUAA";
    String ESITOSERVIZIASYNC = "EsitoServiziAsync";
    String LEGGIAGRICOLTOREATTIVOFS6 = "LeggiAgricoltoreAttivoFS6";
    String LEGGIALLEVAMENTIFS6 = "LeggiAllevamentiFS6";
    String LEGGIBASEASSOCIATIVAFSRTI = "LeggiBaseAssociativaFSRTI";
    String LEGGICONSISTENZAFS6 = "LeggiConsistenzaFS6";
    String LEGGICONSISTENZAFS6ASYNC = "LeggiConsistenzaFS6Async";
    String LEGGICONSISTENZAFS7 = "LeggiConsistenzaFS7";
    String LEGGICONSISTENZAFS7ASYNC = "LeggiConsistenzaFS7Async";
    String LEGGICONTICORRENTIFS6 = "LeggiContiCorrentiFS6";
    String LEGGICUAAMODIFICATIFS6 = "LeggiCuaaModificatiFS6";
    String LEGGIFABBRICATIFS6 = "LeggiFabbricatiFS6";
    String LEGGIGIOVANEAGRICOLTOREFS6 = "LeggiGiovaneAgricoltoreFS6";
    String LEGGILEGAMEASSOCIATIVOFS = "LeggiLegameAssociativoFS";
    String LEGGIMACCHINEFS6 = "LeggiMacchineFS6";
    String LEGGIMANODOPERAFS6 = "LeggiManodoperaFS6";
    String LEGGIOTEAZIENDA = "LeggiOTEAzienda";
    String LEGGISCHEDAVALIDAZIONE = "LeggiSchedaValidazione";
    String LEGGISCHEDECUAA = "LeggiSchedeCUAA";
    String LEGGISEGNALAZIONIFS6 = "LeggiSegnalazioniFS6";
    String SCRIVIAGRICOLTOREATTIVOFSISOP = "ScriviAgricoltoreAttivoFSISOP";
    String SCRIVIALLEVAMENTIFS5ASYNC = "ScriviAllevamentiFS5Async";
    String SCRIVICAPOFILAFSRTI = "ScriviCapofilaFSRTI";
    String SCRIVICONSISTENZAFS5_1ASYNC = "ScriviConsistenzaFS5_1Async";
    String SCRIVICONSISTENZAFS6ASYNC = "ScriviConsistenzaFS6Async";
    String SCRIVICONTICORRENTIFS6 = "ScriviContiCorrentiFS6";
    String SCRIVIDOCUMENTIFASCICOLO = "ScriviDocumentiFascicolo";
    String SCRIVIFABBRICATIFS5_1 = "ScriviFabbricatiFS5_1";
    String SCRIVIFABBRICATIFS6 = "ScriviFabbricatiFS6";
    String SCRIVIFASCICOLODOMANDAFS6 = "ScriviFascicoloDomandaFS6";
    String SCRIVIFASCICOLOFS6 = "ScriviFascicoloFS6";
    String SCRIVILEGAMEASSOCIATIVOFS = "ScriviLegameAssociativoFS";
    String SCRIVIMACCHINEFS6 = "ScriviMacchineFS6";
    String SCRIVIMANODOPERAFS6 = "ScriviManodoperaFS6";
    String TROVAFASCICOLOFS6 = "TrovaFascicoloFS6";
}

