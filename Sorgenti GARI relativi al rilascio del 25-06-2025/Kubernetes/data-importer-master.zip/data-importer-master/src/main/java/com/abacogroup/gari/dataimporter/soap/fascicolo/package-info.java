@jakarta.xml.bind.annotation.XmlSchema(namespace = "http://cooperazione.sian.it/schema/fascicolo", elementFormDefault = jakarta.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.abacogroup.gari.dataimporter.soap.fascicolo;
