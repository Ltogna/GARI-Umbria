
package com.abacogroup.gari.dataimporter.soap.fascicolo;

import java.util.ArrayList;
import java.util.List;
import jakarta.xml.bind.JAXBElement;
import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlElementRef;
import jakarta.xml.bind.annotation.XmlRootElement;
import jakarta.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="CodiceLivello" type="{http://cooperazione.sian.it/schema/fascicolo}CodLivello" minOccurs="0"/&gt;
 *         &lt;element name="CodiceMacrouso" type="{http://cooperazione.sian.it/schema/fascicolo}CodMacrouso" minOccurs="0"/&gt;
 *         &lt;element ref="{http://cooperazione.sian.it/schema/fascicolo}Livello" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="SuperficieDichiarata" type="{http://cooperazione.sian.it/schema/fascicolo}SupDichiarata" minOccurs="0"/&gt;
 *         &lt;element name="SuperficieRiscontrata" type="{http://cooperazione.sian.it/schema/fascicolo}SupRiscontrata" minOccurs="0"/&gt;
 *         &lt;element name="DettaglioUsoSuolo" type="{http://cooperazione.sian.it/schema/fascicolo}ISWSRiep3" maxOccurs="unbounded" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "codiceLivello",
    "codiceMacrouso",
    "livello",
    "superficieDichiarata",
    "superficieRiscontrata",
    "dettaglioUsoSuolo"
})
@XmlRootElement(name = "Livello")
public class Livello {

    @XmlElementRef(name = "CodiceLivello", namespace = "http://cooperazione.sian.it/schema/fascicolo", type = JAXBElement.class, required = false)
    protected JAXBElement<String> codiceLivello;
    @XmlElementRef(name = "CodiceMacrouso", namespace = "http://cooperazione.sian.it/schema/fascicolo", type = JAXBElement.class, required = false)
    protected JAXBElement<String> codiceMacrouso;
    @XmlElement(name = "Livello")
    protected List<Livello> livello;
    @XmlElementRef(name = "SuperficieDichiarata", namespace = "http://cooperazione.sian.it/schema/fascicolo", type = JAXBElement.class, required = false)
    protected JAXBElement<String> superficieDichiarata;
    @XmlElementRef(name = "SuperficieRiscontrata", namespace = "http://cooperazione.sian.it/schema/fascicolo", type = JAXBElement.class, required = false)
    protected JAXBElement<String> superficieRiscontrata;
    @XmlElement(name = "DettaglioUsoSuolo", nillable = true)
    protected List<ISWSRiep3> dettaglioUsoSuolo;

    /**
     * Gets the value of the codiceLivello property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getCodiceLivello() {
        return codiceLivello;
    }

    /**
     * Sets the value of the codiceLivello property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setCodiceLivello(JAXBElement<String> value) {
        this.codiceLivello = value;
    }

    /**
     * Gets the value of the codiceMacrouso property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getCodiceMacrouso() {
        return codiceMacrouso;
    }

    /**
     * Sets the value of the codiceMacrouso property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setCodiceMacrouso(JAXBElement<String> value) {
        this.codiceMacrouso = value;
    }

    /**
     * Gets the value of the livello property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the Jakarta XML Binding object.
     * This is why there is not a <CODE>set</CODE> method for the livello property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getLivello().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Livello }
     * 
     * 
     */
    public List<Livello> getLivello() {
        if (livello == null) {
            livello = new ArrayList<Livello>();
        }
        return this.livello;
    }

    /**
     * Gets the value of the superficieDichiarata property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getSuperficieDichiarata() {
        return superficieDichiarata;
    }

    /**
     * Sets the value of the superficieDichiarata property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setSuperficieDichiarata(JAXBElement<String> value) {
        this.superficieDichiarata = value;
    }

    /**
     * Gets the value of the superficieRiscontrata property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getSuperficieRiscontrata() {
        return superficieRiscontrata;
    }

    /**
     * Sets the value of the superficieRiscontrata property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setSuperficieRiscontrata(JAXBElement<String> value) {
        this.superficieRiscontrata = value;
    }

    /**
     * Gets the value of the dettaglioUsoSuolo property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the Jakarta XML Binding object.
     * This is why there is not a <CODE>set</CODE> method for the dettaglioUsoSuolo property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getDettaglioUsoSuolo().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ISWSRiep3 }
     * 
     * 
     */
    public List<ISWSRiep3> getDettaglioUsoSuolo() {
        if (dettaglioUsoSuolo == null) {
            dettaglioUsoSuolo = new ArrayList<ISWSRiep3>();
        }
        return this.dettaglioUsoSuolo;
    }

}
