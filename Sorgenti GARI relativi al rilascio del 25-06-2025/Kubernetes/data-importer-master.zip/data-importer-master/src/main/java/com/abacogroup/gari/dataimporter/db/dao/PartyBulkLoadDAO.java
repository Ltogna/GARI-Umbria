package com.abacogroup.gari.dataimporter.db.dao;

import java.time.OffsetDateTime;
import java.util.List;

import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.customizer.BindBean;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;
import org.jdbi.v3.sqlobject.transaction.Transactional;

import com.abacogroup.gari.dataimporter.db.ntt.PartyBulkLoadNTT;

@RegisterBeanMapper(PartyBulkLoadNTT.class)
public interface PartyBulkLoadDAO extends Transactional<PartyBulkLoadDAO> {

	@SqlUpdate("INSERT INTO dataimporter_party_bulk_load " +
			"(id, cuaa, party_id, dt_start, dt_end, last_ok_step, import_status,campagna,tenant) " +
			"VALUES (:id, :cuaa, :partyId, :dtStart, :dtEnd, :lastOkStep, :importStatus,:campagna,:tenant)")
	void insert(@BindBean PartyBulkLoadNTT bulkLoad);

	@SqlQuery("SELECT * FROM dataimporter_party_bulk_load WHERE id = :id")
	PartyBulkLoadNTT findById(@Bind("id") String id);

	@SqlUpdate("UPDATE dataimporter_party_bulk_load " +
			"SET import_status = :importStatus, last_ok_step = :lastOkStep " +
			"WHERE id = :id")
	int updateStatusAndStep(@Bind("id") String id,
			@Bind("importStatus") String importStatus,
			@Bind("lastOkStep") int lastOkStep);

	@SqlUpdate("UPDATE dataimporter_party_bulk_load " +
			"SET dt_end = :dtEnd " +
			"WHERE id = :id")
	int completeImport(@Bind("id") String id,
			@Bind("dtEnd") OffsetDateTime dtEnd);

	@SqlUpdate("UPDATE dataimporter_party_bulk_load " +
			"SET party_id = :partyId " +
			"WHERE id = :id")
	int updatePartyById(@Bind("id") String id,
			@Bind("partyId") Long partyId);

	@SqlQuery("SELECT * FROM dataimporter_party_bulk_load " +
			"WHERE cuaa = :cuaa AND import_status = :importStatus")
	List<PartyBulkLoadNTT> findByCuaaAndStatus(@Bind("cuaa") String cuaa,
			@Bind("importStatus") String importStatus);
}
