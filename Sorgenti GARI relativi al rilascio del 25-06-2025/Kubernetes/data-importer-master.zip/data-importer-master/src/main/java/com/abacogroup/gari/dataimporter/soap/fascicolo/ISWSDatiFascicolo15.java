
package com.abacogroup.gari.dataimporter.soap.fascicolo;

import java.util.ArrayList;
import java.util.List;
import jakarta.xml.bind.JAXBElement;
import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlElementRef;
import jakarta.xml.bind.annotation.XmlRootElement;
import jakarta.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="cuaa" type="{http://cooperazione.sian.it/schema/fascicolo}Cuaa"/&gt;
 *         &lt;element name="aggiornaAnagrafe" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;length value="1"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="UTE" type="{http://cooperazione.sian.it/schema/fascicolo}ISWSUbicazione" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="PEC" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;maxLength value="100"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="Email" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;maxLength value="100"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="Telefono" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;maxLength value="20"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="TipoDocumento" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;enumeration value="1"/&gt;
 *               &lt;enumeration value="2"/&gt;
 *               &lt;enumeration value="3"/&gt;
 *               &lt;enumeration value="4"/&gt;
 *               &lt;enumeration value="5"/&gt;
 *               &lt;enumeration value="6"/&gt;
 *               &lt;enumeration value="7"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="NumeroDocumento"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;maxLength value="16"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="DataDocumento" type="{http://cooperazione.sian.it/schema/fascicolo}Data"/&gt;
 *         &lt;element name="DataScadDocumento" type="{http://cooperazione.sian.it/schema/fascicolo}Data"/&gt;
 *         &lt;element name="IscrizioneRea" type="{http://cooperazione.sian.it/schema/fascicolo}ISWSIscrizioneCC" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="IscrizioneRegistroImprese" type="{http://cooperazione.sian.it/schema/fascicolo}ISWSIscrizioneCC" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="CUAADeteCont" type="{http://cooperazione.sian.it/schema/fascicolo}Cuaa" minOccurs="0"/&gt;
 *         &lt;element name="TipoIncaricoDetentore" type="{http://cooperazione.sian.it/schema/fascicolo}Foglio" minOccurs="0"/&gt;
 *         &lt;element name="DataDeteCont" type="{http://cooperazione.sian.it/schema/fascicolo}Data" minOccurs="0"/&gt;
 *         &lt;element name="MatricolaINPS" type="{http://cooperazione.sian.it/schema/fascicolo}ISWSCodiceINPS" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="DataApertFascicolo" type="{http://cooperazione.sian.it/schema/fascicolo}Data"/&gt;
 *         &lt;element name="DataChiusFascicolo" type="{http://cooperazione.sian.it/schema/fascicolo}Data"/&gt;
 *         &lt;element name="CodiceTipoDetentore" type="{http://cooperazione.sian.it/schema/fascicolo}CodiceTipoDetentore"/&gt;
 *         &lt;element name="Detentore" type="{http://cooperazione.sian.it/schema/fascicolo}Detentore"/&gt;
 *         &lt;element name="DataMandato" type="{http://cooperazione.sian.it/schema/fascicolo}Data"/&gt;
 *         &lt;element name="DataValidazFascicolo" type="{http://cooperazione.sian.it/schema/fascicolo}Data"/&gt;
 *         &lt;element name="TipoIdentificativoScheda" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;length value="1"/&gt;
 *               &lt;enumeration value="1"/&gt;
 *               &lt;enumeration value="2"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="IdentificativoSchedaFascicolo" type="{http://cooperazione.sian.it/schema/fascicolo}IdScheda" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "cuaa",
    "aggiornaAnagrafe",
    "ute",
    "pec",
    "email",
    "telefono",
    "tipoDocumento",
    "numeroDocumento",
    "dataDocumento",
    "dataScadDocumento",
    "iscrizioneRea",
    "iscrizioneRegistroImprese",
    "cuaaDeteCont",
    "tipoIncaricoDetentore",
    "dataDeteCont",
    "matricolaINPS",
    "dataApertFascicolo",
    "dataChiusFascicolo",
    "codiceTipoDetentore",
    "detentore",
    "dataMandato",
    "dataValidazFascicolo",
    "tipoIdentificativoScheda",
    "identificativoSchedaFascicolo"
})
@XmlRootElement(name = "ISWSDatiFascicolo15")
public class ISWSDatiFascicolo15 {

    @XmlElement(required = true)
    protected String cuaa;
    @XmlElementRef(name = "aggiornaAnagrafe", namespace = "http://cooperazione.sian.it/schema/fascicolo", type = JAXBElement.class, required = false)
    protected JAXBElement<String> aggiornaAnagrafe;
    @XmlElement(name = "UTE")
    protected List<ISWSUbicazione> ute;
    @XmlElementRef(name = "PEC", namespace = "http://cooperazione.sian.it/schema/fascicolo", type = JAXBElement.class, required = false)
    protected JAXBElement<String> pec;
    @XmlElementRef(name = "Email", namespace = "http://cooperazione.sian.it/schema/fascicolo", type = JAXBElement.class, required = false)
    protected JAXBElement<String> email;
    @XmlElementRef(name = "Telefono", namespace = "http://cooperazione.sian.it/schema/fascicolo", type = JAXBElement.class, required = false)
    protected JAXBElement<String> telefono;
    @XmlElementRef(name = "TipoDocumento", namespace = "http://cooperazione.sian.it/schema/fascicolo", type = JAXBElement.class, required = false)
    protected JAXBElement<String> tipoDocumento;
    @XmlElement(name = "NumeroDocumento", required = true, nillable = true)
    protected String numeroDocumento;
    @XmlElement(name = "DataDocumento", required = true, nillable = true)
    protected String dataDocumento;
    @XmlElement(name = "DataScadDocumento", required = true, nillable = true)
    protected String dataScadDocumento;
    @XmlElement(name = "IscrizioneRea", nillable = true)
    protected List<ISWSIscrizioneCC> iscrizioneRea;
    @XmlElement(name = "IscrizioneRegistroImprese", nillable = true)
    protected List<ISWSIscrizioneCC> iscrizioneRegistroImprese;
    @XmlElementRef(name = "CUAADeteCont", namespace = "http://cooperazione.sian.it/schema/fascicolo", type = JAXBElement.class, required = false)
    protected JAXBElement<String> cuaaDeteCont;
    @XmlElementRef(name = "TipoIncaricoDetentore", namespace = "http://cooperazione.sian.it/schema/fascicolo", type = JAXBElement.class, required = false)
    protected JAXBElement<String> tipoIncaricoDetentore;
    @XmlElementRef(name = "DataDeteCont", namespace = "http://cooperazione.sian.it/schema/fascicolo", type = JAXBElement.class, required = false)
    protected JAXBElement<String> dataDeteCont;
    @XmlElement(name = "MatricolaINPS")
    protected List<ISWSCodiceINPS> matricolaINPS;
    @XmlElement(name = "DataApertFascicolo", required = true)
    protected String dataApertFascicolo;
    @XmlElement(name = "DataChiusFascicolo", required = true, nillable = true)
    protected String dataChiusFascicolo;
    @XmlElement(name = "CodiceTipoDetentore", required = true)
    protected String codiceTipoDetentore;
    @XmlElement(name = "Detentore", required = true, nillable = true)
    protected String detentore;
    @XmlElement(name = "DataMandato", required = true, nillable = true)
    protected String dataMandato;
    @XmlElement(name = "DataValidazFascicolo", required = true)
    protected String dataValidazFascicolo;
    @XmlElementRef(name = "TipoIdentificativoScheda", namespace = "http://cooperazione.sian.it/schema/fascicolo", type = JAXBElement.class, required = false)
    protected JAXBElement<String> tipoIdentificativoScheda;
    @XmlElementRef(name = "IdentificativoSchedaFascicolo", namespace = "http://cooperazione.sian.it/schema/fascicolo", type = JAXBElement.class, required = false)
    protected JAXBElement<String> identificativoSchedaFascicolo;

    /**
     * Gets the value of the cuaa property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCuaa() {
        return cuaa;
    }

    /**
     * Sets the value of the cuaa property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCuaa(String value) {
        this.cuaa = value;
    }

    /**
     * Gets the value of the aggiornaAnagrafe property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getAggiornaAnagrafe() {
        return aggiornaAnagrafe;
    }

    /**
     * Sets the value of the aggiornaAnagrafe property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setAggiornaAnagrafe(JAXBElement<String> value) {
        this.aggiornaAnagrafe = value;
    }

    /**
     * Gets the value of the ute property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the Jakarta XML Binding object.
     * This is why there is not a <CODE>set</CODE> method for the ute property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getUTE().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ISWSUbicazione }
     * 
     * 
     */
    public List<ISWSUbicazione> getUTE() {
        if (ute == null) {
            ute = new ArrayList<ISWSUbicazione>();
        }
        return this.ute;
    }

    /**
     * Gets the value of the pec property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getPEC() {
        return pec;
    }

    /**
     * Sets the value of the pec property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setPEC(JAXBElement<String> value) {
        this.pec = value;
    }

    /**
     * Gets the value of the email property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getEmail() {
        return email;
    }

    /**
     * Sets the value of the email property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setEmail(JAXBElement<String> value) {
        this.email = value;
    }

    /**
     * Gets the value of the telefono property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getTelefono() {
        return telefono;
    }

    /**
     * Sets the value of the telefono property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setTelefono(JAXBElement<String> value) {
        this.telefono = value;
    }

    /**
     * Gets the value of the tipoDocumento property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getTipoDocumento() {
        return tipoDocumento;
    }

    /**
     * Sets the value of the tipoDocumento property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setTipoDocumento(JAXBElement<String> value) {
        this.tipoDocumento = value;
    }

    /**
     * Gets the value of the numeroDocumento property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNumeroDocumento() {
        return numeroDocumento;
    }

    /**
     * Sets the value of the numeroDocumento property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNumeroDocumento(String value) {
        this.numeroDocumento = value;
    }

    /**
     * Gets the value of the dataDocumento property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDataDocumento() {
        return dataDocumento;
    }

    /**
     * Sets the value of the dataDocumento property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDataDocumento(String value) {
        this.dataDocumento = value;
    }

    /**
     * Gets the value of the dataScadDocumento property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDataScadDocumento() {
        return dataScadDocumento;
    }

    /**
     * Sets the value of the dataScadDocumento property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDataScadDocumento(String value) {
        this.dataScadDocumento = value;
    }

    /**
     * Gets the value of the iscrizioneRea property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the Jakarta XML Binding object.
     * This is why there is not a <CODE>set</CODE> method for the iscrizioneRea property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getIscrizioneRea().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ISWSIscrizioneCC }
     * 
     * 
     */
    public List<ISWSIscrizioneCC> getIscrizioneRea() {
        if (iscrizioneRea == null) {
            iscrizioneRea = new ArrayList<ISWSIscrizioneCC>();
        }
        return this.iscrizioneRea;
    }

    /**
     * Gets the value of the iscrizioneRegistroImprese property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the Jakarta XML Binding object.
     * This is why there is not a <CODE>set</CODE> method for the iscrizioneRegistroImprese property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getIscrizioneRegistroImprese().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ISWSIscrizioneCC }
     * 
     * 
     */
    public List<ISWSIscrizioneCC> getIscrizioneRegistroImprese() {
        if (iscrizioneRegistroImprese == null) {
            iscrizioneRegistroImprese = new ArrayList<ISWSIscrizioneCC>();
        }
        return this.iscrizioneRegistroImprese;
    }

    /**
     * Gets the value of the cuaaDeteCont property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getCUAADeteCont() {
        return cuaaDeteCont;
    }

    /**
     * Sets the value of the cuaaDeteCont property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setCUAADeteCont(JAXBElement<String> value) {
        this.cuaaDeteCont = value;
    }

    /**
     * Gets the value of the tipoIncaricoDetentore property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getTipoIncaricoDetentore() {
        return tipoIncaricoDetentore;
    }

    /**
     * Sets the value of the tipoIncaricoDetentore property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setTipoIncaricoDetentore(JAXBElement<String> value) {
        this.tipoIncaricoDetentore = value;
    }

    /**
     * Gets the value of the dataDeteCont property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getDataDeteCont() {
        return dataDeteCont;
    }

    /**
     * Sets the value of the dataDeteCont property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setDataDeteCont(JAXBElement<String> value) {
        this.dataDeteCont = value;
    }

    /**
     * Gets the value of the matricolaINPS property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the Jakarta XML Binding object.
     * This is why there is not a <CODE>set</CODE> method for the matricolaINPS property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getMatricolaINPS().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ISWSCodiceINPS }
     * 
     * 
     */
    public List<ISWSCodiceINPS> getMatricolaINPS() {
        if (matricolaINPS == null) {
            matricolaINPS = new ArrayList<ISWSCodiceINPS>();
        }
        return this.matricolaINPS;
    }

    /**
     * Gets the value of the dataApertFascicolo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDataApertFascicolo() {
        return dataApertFascicolo;
    }

    /**
     * Sets the value of the dataApertFascicolo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDataApertFascicolo(String value) {
        this.dataApertFascicolo = value;
    }

    /**
     * Gets the value of the dataChiusFascicolo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDataChiusFascicolo() {
        return dataChiusFascicolo;
    }

    /**
     * Sets the value of the dataChiusFascicolo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDataChiusFascicolo(String value) {
        this.dataChiusFascicolo = value;
    }

    /**
     * Gets the value of the codiceTipoDetentore property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodiceTipoDetentore() {
        return codiceTipoDetentore;
    }

    /**
     * Sets the value of the codiceTipoDetentore property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodiceTipoDetentore(String value) {
        this.codiceTipoDetentore = value;
    }

    /**
     * Gets the value of the detentore property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDetentore() {
        return detentore;
    }

    /**
     * Sets the value of the detentore property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDetentore(String value) {
        this.detentore = value;
    }

    /**
     * Gets the value of the dataMandato property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDataMandato() {
        return dataMandato;
    }

    /**
     * Sets the value of the dataMandato property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDataMandato(String value) {
        this.dataMandato = value;
    }

    /**
     * Gets the value of the dataValidazFascicolo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDataValidazFascicolo() {
        return dataValidazFascicolo;
    }

    /**
     * Sets the value of the dataValidazFascicolo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDataValidazFascicolo(String value) {
        this.dataValidazFascicolo = value;
    }

    /**
     * Gets the value of the tipoIdentificativoScheda property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getTipoIdentificativoScheda() {
        return tipoIdentificativoScheda;
    }

    /**
     * Sets the value of the tipoIdentificativoScheda property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setTipoIdentificativoScheda(JAXBElement<String> value) {
        this.tipoIdentificativoScheda = value;
    }

    /**
     * Gets the value of the identificativoSchedaFascicolo property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getIdentificativoSchedaFascicolo() {
        return identificativoSchedaFascicolo;
    }

    /**
     * Sets the value of the identificativoSchedaFascicolo property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setIdentificativoSchedaFascicolo(JAXBElement<String> value) {
        this.identificativoSchedaFascicolo = value;
    }

}
