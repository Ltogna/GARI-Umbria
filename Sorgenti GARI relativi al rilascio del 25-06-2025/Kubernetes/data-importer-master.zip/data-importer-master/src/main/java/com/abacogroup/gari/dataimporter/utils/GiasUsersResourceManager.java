package com.abacogroup.gari.dataimporter.utils;
 
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Map;
import java.util.stream.Collectors;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.extern.slf4j.Slf4j;

/**
 * 
 * Singleton class to manage a JSON file in memory during the entire application lifecycle.
 * The JSON file is loaded from the classpath only once during initialization.
 * 
 * @author Emanuele Crocilla
 *
 */
@Slf4j
public class GiasUsersResourceManager {
	
    // Singleton instance
    private static GiasUsersResourceManager instance;
    
    // JSON file name in the classpath
    private final static String JSON_RESOURCE_PATH = "user-mapping.json";
    
	private Map<String, String> data;
    
    private GiasUsersResourceManager() {
        JsonNode jsonData = getJsonFromResource();
        this.data = convertJsonNodeToMap(jsonData);
    }

    public static GiasUsersResourceManager getInstance() {
        if (instance == null) {
            synchronized (GiasUsersResourceManager.class) {
                if (instance == null) {
                    instance = new GiasUsersResourceManager();
                }
            }
        }
        return instance;
    }
    
    /**
     * load JSON file from the classpath
     */
    private JsonNode getJsonFromResource() {
        try (InputStream inputStream = getClass().getClassLoader().getResourceAsStream(JSON_RESOURCE_PATH)) {
            if (inputStream == null) {
                throw new IOException("Cannot find resource: " + JSON_RESOURCE_PATH);
            }
            
            try (BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream))) {
                String jsonContent = reader.lines().collect(Collectors.joining("\n"));
                return new ObjectMapper().readTree(jsonContent);
            }
        } catch (IOException e) {
            throw new RuntimeException("Error reading JSON file: " + e.getMessage(), e);
        }
    }
    
    private static Map<String, String> convertJsonNodeToMap(JsonNode jsonNode) {
        Map<String, String> resultMap = new HashMap<>();
        
        if (jsonNode == null || !jsonNode.isArray()) {
            throw new IllegalArgumentException("JsonNode must be an array");
        }
        
        for (JsonNode node : jsonNode) {
            if (node.has("agri") && node.has("gias")) {
                String agriValue = node.get("agri").asText();
                String giasValue = node.get("gias").asText();
                resultMap.put(agriValue, giasValue);
            }
        }
        
        return resultMap;
    }
    
    /**
     * Updates the in-memory JsonNode with a new version from the file
     * Useful if the file has been modified and you want to reload the content
     */
    public void reload() {
    	JsonNode jsonData = getJsonFromResource();
        this.data = convertJsonNodeToMap(jsonData);
    }
    
    public String getGiasUserByAgriUser(String agriUser) {
		return data.get(agriUser);
	}
}