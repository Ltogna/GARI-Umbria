
package com.abacogroup.gari.dataimporter.soap.fascicolo;

import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ISWSAzieRTI complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ISWSAzieRTI"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="CuaaMandante" type="{http://cooperazione.sian.it/schema/fascicolo}Cuaa"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ISWSAzieRTI", propOrder = {
    "cuaaMandante"
})
public class ISWSAzieRTI {

    @XmlElement(name = "CuaaMandante", required = true)
    protected String cuaaMandante;

    /**
     * Gets the value of the cuaaMandante property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCuaaMandante() {
        return cuaaMandante;
    }

    /**
     * Sets the value of the cuaaMandante property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCuaaMandante(String value) {
        this.cuaaMandante = value;
    }

}
