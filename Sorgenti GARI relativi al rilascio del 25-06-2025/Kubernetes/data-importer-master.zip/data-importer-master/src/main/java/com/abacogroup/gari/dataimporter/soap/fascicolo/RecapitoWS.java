
package com.abacogroup.gari.dataimporter.soap.fascicolo;

import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlRootElement;
import jakarta.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Deco_tipo_reca"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}int"&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="Data_iniz" type="{http://cooperazione.sian.it/schema/fascicolo}Data"/&gt;
 *         &lt;element name="Data_fine" type="{http://cooperazione.sian.it/schema/fascicolo}Data"/&gt;
 *         &lt;element name="Desc_tele"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;maxLength value="20"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="Desc_indi"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;maxLength value="100"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="Desc_fax_inte"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;maxLength value="20"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="Desc_mail_inte"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;maxLength value="100"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="Deco_font_dato"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}int"&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="Codi_fisc_reca"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;length value="4"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="Codi_capp" type="{http://cooperazione.sian.it/schema/fascicolo}Cap"/&gt;
 *         &lt;element name="Codi_sigl_prov_reca"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;length value="2"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="Desc_prov_reca"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;maxLength value="100"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="Desc_comu_reca"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;maxLength value="100"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "decoTipoReca",
    "dataIniz",
    "dataFine",
    "descTele",
    "descIndi",
    "descFaxInte",
    "descMailInte",
    "decoFontDato",
    "codiFiscReca",
    "codiCapp",
    "codiSiglProvReca",
    "descProvReca",
    "descComuReca"
})
@XmlRootElement(name = "RecapitoWS")
public class RecapitoWS {

    @XmlElement(name = "Deco_tipo_reca")
    protected int decoTipoReca;
    @XmlElement(name = "Data_iniz", required = true)
    protected String dataIniz;
    @XmlElement(name = "Data_fine", required = true)
    protected String dataFine;
    @XmlElement(name = "Desc_tele", required = true, nillable = true)
    protected String descTele;
    @XmlElement(name = "Desc_indi", required = true, nillable = true)
    protected String descIndi;
    @XmlElement(name = "Desc_fax_inte", required = true, nillable = true)
    protected String descFaxInte;
    @XmlElement(name = "Desc_mail_inte", required = true, nillable = true)
    protected String descMailInte;
    @XmlElement(name = "Deco_font_dato", required = true, type = Integer.class, nillable = true)
    protected Integer decoFontDato;
    @XmlElement(name = "Codi_fisc_reca", required = true, nillable = true)
    protected String codiFiscReca;
    @XmlElement(name = "Codi_capp", required = true, nillable = true)
    protected String codiCapp;
    @XmlElement(name = "Codi_sigl_prov_reca", required = true, nillable = true)
    protected String codiSiglProvReca;
    @XmlElement(name = "Desc_prov_reca", required = true, nillable = true)
    protected String descProvReca;
    @XmlElement(name = "Desc_comu_reca", required = true, nillable = true)
    protected String descComuReca;

    /**
     * Gets the value of the decoTipoReca property.
     * 
     */
    public int getDecoTipoReca() {
        return decoTipoReca;
    }

    /**
     * Sets the value of the decoTipoReca property.
     * 
     */
    public void setDecoTipoReca(int value) {
        this.decoTipoReca = value;
    }

    /**
     * Gets the value of the dataIniz property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDataIniz() {
        return dataIniz;
    }

    /**
     * Sets the value of the dataIniz property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDataIniz(String value) {
        this.dataIniz = value;
    }

    /**
     * Gets the value of the dataFine property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDataFine() {
        return dataFine;
    }

    /**
     * Sets the value of the dataFine property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDataFine(String value) {
        this.dataFine = value;
    }

    /**
     * Gets the value of the descTele property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDescTele() {
        return descTele;
    }

    /**
     * Sets the value of the descTele property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDescTele(String value) {
        this.descTele = value;
    }

    /**
     * Gets the value of the descIndi property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDescIndi() {
        return descIndi;
    }

    /**
     * Sets the value of the descIndi property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDescIndi(String value) {
        this.descIndi = value;
    }

    /**
     * Gets the value of the descFaxInte property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDescFaxInte() {
        return descFaxInte;
    }

    /**
     * Sets the value of the descFaxInte property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDescFaxInte(String value) {
        this.descFaxInte = value;
    }

    /**
     * Gets the value of the descMailInte property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDescMailInte() {
        return descMailInte;
    }

    /**
     * Sets the value of the descMailInte property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDescMailInte(String value) {
        this.descMailInte = value;
    }

    /**
     * Gets the value of the decoFontDato property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getDecoFontDato() {
        return decoFontDato;
    }

    /**
     * Sets the value of the decoFontDato property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setDecoFontDato(Integer value) {
        this.decoFontDato = value;
    }

    /**
     * Gets the value of the codiFiscReca property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodiFiscReca() {
        return codiFiscReca;
    }

    /**
     * Sets the value of the codiFiscReca property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodiFiscReca(String value) {
        this.codiFiscReca = value;
    }

    /**
     * Gets the value of the codiCapp property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodiCapp() {
        return codiCapp;
    }

    /**
     * Sets the value of the codiCapp property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodiCapp(String value) {
        this.codiCapp = value;
    }

    /**
     * Gets the value of the codiSiglProvReca property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodiSiglProvReca() {
        return codiSiglProvReca;
    }

    /**
     * Sets the value of the codiSiglProvReca property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodiSiglProvReca(String value) {
        this.codiSiglProvReca = value;
    }

    /**
     * Gets the value of the descProvReca property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDescProvReca() {
        return descProvReca;
    }

    /**
     * Sets the value of the descProvReca property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDescProvReca(String value) {
        this.descProvReca = value;
    }

    /**
     * Gets the value of the descComuReca property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDescComuReca() {
        return descComuReca;
    }

    /**
     * Sets the value of the descComuReca property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDescComuReca(String value) {
        this.descComuReca = value;
    }

}
