
package com.abacogroup.gari.dataimporter.soap.fascicolo;

import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlRootElement;
import jakarta.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Codi_abii"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;length value="5"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="Desc_abii"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;maxLength value="80"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="Codi_cabb"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;length value="5"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="Desc_cabb"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;maxLength value="50"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="Codi_sigl_prov"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;length value="2"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="Desc_prov"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;maxLength value="100"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="Desc_comu"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;maxLength value="100"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="Data_iniz" type="{http://cooperazione.sian.it/schema/fascicolo}Data"/&gt;
 *         &lt;element name="Data_fine" type="{http://cooperazione.sian.it/schema/fascicolo}Data"/&gt;
 *         &lt;element name="Codi_capp" type="{http://cooperazione.sian.it/schema/fascicolo}Cap"/&gt;
 *         &lt;element name="Codi_nume_ccor"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;maxLength value="30"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="Codi_nazi"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;maxLength value="2"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="Check_digit"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;maxLength value="2"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="Codi_pin"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;length value="1"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="Deco_tipo_cont"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}int"&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "codiAbii",
    "descAbii",
    "codiCabb",
    "descCabb",
    "codiSiglProv",
    "descProv",
    "descComu",
    "dataIniz",
    "dataFine",
    "codiCapp",
    "codiNumeCcor",
    "codiNazi",
    "checkDigit",
    "codiPin",
    "decoTipoCont"
})
@XmlRootElement(name = "ContoCorrenteWS")
public class ContoCorrenteWS {

    @XmlElement(name = "Codi_abii", required = true, nillable = true)
    protected String codiAbii;
    @XmlElement(name = "Desc_abii", required = true, nillable = true)
    protected String descAbii;
    @XmlElement(name = "Codi_cabb", required = true, nillable = true)
    protected String codiCabb;
    @XmlElement(name = "Desc_cabb", required = true, nillable = true)
    protected String descCabb;
    @XmlElement(name = "Codi_sigl_prov", required = true, nillable = true)
    protected String codiSiglProv;
    @XmlElement(name = "Desc_prov", required = true, nillable = true)
    protected String descProv;
    @XmlElement(name = "Desc_comu", required = true, nillable = true)
    protected String descComu;
    @XmlElement(name = "Data_iniz", required = true)
    protected String dataIniz;
    @XmlElement(name = "Data_fine", required = true)
    protected String dataFine;
    @XmlElement(name = "Codi_capp", required = true, nillable = true)
    protected String codiCapp;
    @XmlElement(name = "Codi_nume_ccor", required = true)
    protected String codiNumeCcor;
    @XmlElement(name = "Codi_nazi", required = true, nillable = true)
    protected String codiNazi;
    @XmlElement(name = "Check_digit", required = true, nillable = true)
    protected String checkDigit;
    @XmlElement(name = "Codi_pin", required = true, nillable = true)
    protected String codiPin;
    @XmlElement(name = "Deco_tipo_cont", required = true, type = Integer.class, nillable = true)
    protected Integer decoTipoCont;

    /**
     * Gets the value of the codiAbii property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodiAbii() {
        return codiAbii;
    }

    /**
     * Sets the value of the codiAbii property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodiAbii(String value) {
        this.codiAbii = value;
    }

    /**
     * Gets the value of the descAbii property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDescAbii() {
        return descAbii;
    }

    /**
     * Sets the value of the descAbii property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDescAbii(String value) {
        this.descAbii = value;
    }

    /**
     * Gets the value of the codiCabb property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodiCabb() {
        return codiCabb;
    }

    /**
     * Sets the value of the codiCabb property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodiCabb(String value) {
        this.codiCabb = value;
    }

    /**
     * Gets the value of the descCabb property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDescCabb() {
        return descCabb;
    }

    /**
     * Sets the value of the descCabb property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDescCabb(String value) {
        this.descCabb = value;
    }

    /**
     * Gets the value of the codiSiglProv property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodiSiglProv() {
        return codiSiglProv;
    }

    /**
     * Sets the value of the codiSiglProv property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodiSiglProv(String value) {
        this.codiSiglProv = value;
    }

    /**
     * Gets the value of the descProv property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDescProv() {
        return descProv;
    }

    /**
     * Sets the value of the descProv property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDescProv(String value) {
        this.descProv = value;
    }

    /**
     * Gets the value of the descComu property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDescComu() {
        return descComu;
    }

    /**
     * Sets the value of the descComu property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDescComu(String value) {
        this.descComu = value;
    }

    /**
     * Gets the value of the dataIniz property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDataIniz() {
        return dataIniz;
    }

    /**
     * Sets the value of the dataIniz property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDataIniz(String value) {
        this.dataIniz = value;
    }

    /**
     * Gets the value of the dataFine property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDataFine() {
        return dataFine;
    }

    /**
     * Sets the value of the dataFine property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDataFine(String value) {
        this.dataFine = value;
    }

    /**
     * Gets the value of the codiCapp property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodiCapp() {
        return codiCapp;
    }

    /**
     * Sets the value of the codiCapp property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodiCapp(String value) {
        this.codiCapp = value;
    }

    /**
     * Gets the value of the codiNumeCcor property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodiNumeCcor() {
        return codiNumeCcor;
    }

    /**
     * Sets the value of the codiNumeCcor property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodiNumeCcor(String value) {
        this.codiNumeCcor = value;
    }

    /**
     * Gets the value of the codiNazi property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodiNazi() {
        return codiNazi;
    }

    /**
     * Sets the value of the codiNazi property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodiNazi(String value) {
        this.codiNazi = value;
    }

    /**
     * Gets the value of the checkDigit property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCheckDigit() {
        return checkDigit;
    }

    /**
     * Sets the value of the checkDigit property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCheckDigit(String value) {
        this.checkDigit = value;
    }

    /**
     * Gets the value of the codiPin property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodiPin() {
        return codiPin;
    }

    /**
     * Sets the value of the codiPin property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodiPin(String value) {
        this.codiPin = value;
    }

    /**
     * Gets the value of the decoTipoCont property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getDecoTipoCont() {
        return decoTipoCont;
    }

    /**
     * Sets the value of the decoTipoCont property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setDecoTipoCont(Integer value) {
        this.decoTipoCont = value;
    }

}
