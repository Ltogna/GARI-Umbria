package com.abacogroup.gari.dataimporter.DTOs;

public enum ImportType {
	IMPORT_CROP_PLAN(1),
	TRACKING_REQUEST(2),
	PARTY_CREDITS(3),
	CROP_PLAN_NOTIFICATION(4),
	ZNV_CATALOG_NOTIFICATION(5),
	IMPORT_PARTIES(6);

	private final int value;

	ImportType(int value) {
		this.value = value;
	}

	public int getValue() {
		return value;
	}

	public static ImportType fromValue(int value) {
		for (ImportType type : values()) {
			if (type.value == value) {
				return type;
			}
		}
		throw new IllegalArgumentException("Unknown ImportType value: " + value);
	}
}
