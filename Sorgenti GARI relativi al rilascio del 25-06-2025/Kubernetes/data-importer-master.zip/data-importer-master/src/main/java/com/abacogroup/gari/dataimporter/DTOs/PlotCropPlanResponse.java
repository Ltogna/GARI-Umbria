package com.abacogroup.gari.dataimporter.DTOs;

import java.util.List;

import groovy.transform.EqualsAndHashCode;
import lombok.Data;

@Data
public class PlotCropPlanResponse {

    private List<ValidationMessage> validationMessages;
    private List<PlotDataResponse> added;
    private List<String> deleted;
    private List<PlotDataResponse> updated;
    private List<String> coveredByInserted;
    private List<String> alertCodes;

    @Data
    public static class ValidationMessage {
        private String message;
        private boolean blocking;
    }
}
