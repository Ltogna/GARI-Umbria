package com.abacogroup.gari.dataimporter.services;

import java.io.IOException;
import java.time.OffsetDateTime;
import java.time.OffsetTime;
import java.time.ZoneOffset;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.abacogroup.dropwizard.auth.sso2.Sso2Client;
import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.embeddedqueue.WorkQueue;
import com.abacogroup.gari.dataimporter.DataImporterConfiguration;
import com.abacogroup.gari.dataimporter.DTOs.AnagraficaCommitPayload;
import com.abacogroup.gari.dataimporter.DTOs.CropPlanCommitPayload;
import com.abacogroup.gari.dataimporter.DTOs.CropPlanVersionWithInfo;
import com.abacogroup.gari.dataimporter.DTOs.GiasTokenResponse;
import com.abacogroup.gari.dataimporter.DTOs.NotifyGias;
import com.abacogroup.gari.dataimporter.DTOs.NotifyGias.Dettaglio.DettaglioBuilder;
import com.abacogroup.gari.dataimporter.DTOs.NotifyGias.NotificationDate;
import com.abacogroup.gari.dataimporter.DTOs.SyncNotificationRequest;
import com.abacogroup.gari.dataimporter.DTOs.SyncNotificationResponse;
import com.abacogroup.gari.dataimporter.Interfaces.ICropPlanService;
import com.abacogroup.gari.dataimporter.db.dao.LoggerDAO;
import com.abacogroup.gari.dataimporter.db.dao.NotificationsDAO;
import com.abacogroup.gari.dataimporter.db.dao.NotificationsDatesDAO;
import com.abacogroup.gari.dataimporter.db.ntt.NotificationsDatesNTT;
import com.abacogroup.gari.dataimporter.db.ntt.NotificationsNTT;
import com.abacogroup.gari.dataimporter.utils.ULIDGenerator;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.Delivery;

import jakarta.ws.rs.BadRequestException;
import jakarta.ws.rs.InternalServerErrorException;
import jakarta.ws.rs.client.Client;
import jakarta.ws.rs.client.ClientRequestContext;
import jakarta.ws.rs.client.ClientRequestFilter;
import jakarta.ws.rs.client.Entity;
import jakarta.ws.rs.client.WebTarget;
import jakarta.ws.rs.core.HttpHeaders;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.core.Response.Status.Family;

public class GIASNotificationService extends ADataImporterService {
	private static final Logger log = LoggerFactory.getLogger(GIASNotificationService.class);

	private static final String QUEUE = "dataimporter-cropplan";
	private static final String QUEUE_PARTY = "dataimporter-party";
	private static final String EXCHANGE_PARTY = "party-exchange";
	private static final String ROUTING_KEY_PARTY = "party.*";

	private static final String EXCHANGE = "crop-plan-commit";
	private static final String ROUTING_KEY = "CROPPLAN";
	private static final int NUM_CONCURRENT = 1;

	private static final ZoneOffset ZONE_OFFSET = OffsetTime.now().getOffset();

	private enum FamilyType {
		azienda, pcg;
	}

	// private static final String FamilyType.azienda = "azienda";
	// private static final String FamilyType.pcg = "pcg";

	// The lists must be in "age descending order" like: grand grand paerent, grand
	// paerent, paerent
	private static final Map<FamilyType, List<FamilyType>> FAMILIES_HIERARCHIES = Map.of(
			FamilyType.azienda, List.of(FamilyType.pcg),
			FamilyType.pcg, List.of(FamilyType.azienda));

	private final ObjectMapper objectMapper;
	private final ICropPlanService cropPlanService;
	private final String giasLoginToken;
	private final WebTarget client;
	private final NotificationsDatesDAO notificationsDatesDAO;
	private final NotificationsDAO notificationsDAO;
	private final String tenant = "master";

	public GIASNotificationService(Sso2Client sso2Client, ObjectMapper objectMapper, LoggerDAO loggerDAO,
			DataImporterConfiguration configuration,
			Client client, Connection rabbit, ICropPlanService cropPlanService,
			NotificationsDatesDAO datesDAO, NotificationsDAO notificationsDAO, TrackRequestService trackingService) {
		super(sso2Client, client, configuration, objectMapper, loggerDAO);
		this.notificationsDatesDAO = datesDAO;
		this.notificationsDAO = notificationsDAO;
		this.objectMapper = mapper;
		this.giasLoginToken = configuration.getGiasLoginToken();
		this.cropPlanService = cropPlanService;

		final List<Object> contentEncoding = List.of("identity");
		this.client = client.target(configuration.getGiasBaseUrl());
		this.client.register(new ClientRequestFilter() {
			@Override
			public void filter(ClientRequestContext requestContext) throws IOException {
				// Disable gzip on POST, it looks like the remote service doesn't like that
				requestContext.getHeaders().put(HttpHeaders.CONTENT_ENCODING, contentEncoding);
			}
		});

		try {
			initializeConsumers(rabbit);
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}

	protected void initializeConsumers(Connection connection) throws IOException {
		if (connection == null) {
			return;
		}

		Channel channel = connection.createChannel();
		channel.queueDeclare(QUEUE, true, false, false, null);
		channel.queueBind(QUEUE, EXCHANGE, ROUTING_KEY);
		channel.basicQos(NUM_CONCURRENT);
		channel.basicConsume(QUEUE, false,
				(consumerTag, delivery) -> onCropPlanMessage(delivery, channel),
				consumerTag -> {
				});

		channel.queueDeclare(QUEUE_PARTY, true, false, false, null);
		channel.queueBind(QUEUE_PARTY, EXCHANGE_PARTY, ROUTING_KEY_PARTY);
		channel.basicQos(1);
		channel.basicConsume(QUEUE_PARTY, false,
				(consumerTag, delivery) -> onPartyMessage(delivery, channel),
				consumerTag -> {
				});
	}

	protected void onPartyMessage(Delivery delivery, Channel channel) throws IOException {
		long deliveryTag = delivery.getEnvelope().getDeliveryTag();
		try {
			String flag;
			String deliveryRoutingKey = delivery.getEnvelope().getRoutingKey();
			if (deliveryRoutingKey.endsWith(".new-party")) {
				flag = "C";
			} else {
				flag = "U";
			}

			AnagraficaCommitPayload payload = objectMapper.readValue(delivery.getBody(), AnagraficaCommitPayload.class);

			notificationsDAO.useTransaction(dao -> {
				int flToBeProcessed = 1;
				if (unlockPreviousInHierarchy(payload.getPartyId(), FamilyType.azienda)) {
					flToBeProcessed = 0;
				}

				unlockOrInsert(payload.getPartyId(), FamilyType.azienda, flag, OffsetDateTime.now(), flToBeProcessed);
			});

			channel.basicAck(deliveryTag, false);
		} catch (Throwable t) {
			log.error("Error processing party message, will NOT retry", t);
			channel.basicNack(deliveryTag, false, false);
		}
	}

	protected void onCropPlanMessage(Delivery delivery, Channel channel) throws IOException {
		long deliveryTag = delivery.getEnvelope().getDeliveryTag();
		try {
			CropPlanCommitPayload payload = objectMapper.readValue(delivery.getBody(), CropPlanCommitPayload.class);

			CropPlanVersionWithInfo ci = cropPlanService.getCropPlanVersionWithInfo(payload.getTenant(),
					payload.getBusinessId(), payload.getCropPlanId());
			String flag = ci.isMoreThanOne() ? "U" : "C";

			notificationsDAO.useTransaction(dao -> {
				int flToBeProcessed = 1;
				if (unlockPreviousInHierarchy(payload.getBusinessId(), FamilyType.pcg)) {
					flToBeProcessed = 0;
				}

				OffsetDateTime dt = payload.getVersionDate().atOffset(ZONE_OFFSET);
				unlockOrInsert(payload.getBusinessId(), FamilyType.pcg, flag, dt, flToBeProcessed);
			});

			channel.basicAck(deliveryTag, false);
		} catch (Throwable t) {
			log.error("Error processing crop plan message, will NOT retry", t);
			channel.basicNack(deliveryTag, false, false);
		}
	}

	private void unlockOrInsert(Long partyId, FamilyType family, String flag, OffsetDateTime dt, int flToBeProcessed) {
		int updated = notificationsDatesDAO.setToBeProcessed(partyId, family.name(), "C", flToBeProcessed);
		if (updated != 0 && !"C".equals(flag)) {
			// If we have a C we do not process any U
			flToBeProcessed = 0;
			updated = notificationsDatesDAO.setToBeProcessed(partyId, family.name(), flag, flToBeProcessed);
		} else if ("U".equals(flag)) {
			updated = notificationsDatesDAO.setToBeProcessed(partyId, family.name(), "U", flToBeProcessed);
		}

		if (updated == 0) {
			NotificationsDatesNTT ntt = NotificationsDatesNTT.builder()
					.dtVersion(dt)
					.familyType(family.name())
					.flToBeProcessed(flToBeProcessed)
					.flVersion(flag)
					.partyId(partyId)
					.build();
			notificationsDatesDAO.insert(ntt);
		}
	}

	private boolean unlockPreviousInHierarchy(Long partyId, FamilyType currentFamily) {
		int updated;
		for (FamilyType parentFamily : FAMILIES_HIERARCHIES.get(currentFamily)) {
			updated = notificationsDatesDAO.setToBeProcessed(partyId, parentFamily.name(), "C", 1);
			if (updated != 0) {
				return true;
			}
			updated = notificationsDatesDAO.setToBeProcessed(partyId, parentFamily.name(), "U", 1);
			if (updated != 0) {
				return true;
			}
		}

		return false;
	}

	// Jobs
	public void ImportNotification(WorkQueue<String> workQueue) {
		log.debug("Start notifications generation");
		notificationsDatesDAO.findUnnotifiedRecords(notificationDate -> {
			NotificationsNTT entity = NotificationsNTT.builder()
					.familyType(notificationDate.getFamilyType())
					.flVersion(notificationDate.getFlVersion())
					.partyId(notificationDate.getPartyId())
					.uid(ULIDGenerator.generateULID())
					.build();
			log.debug("Inserting notification {}", entity);
			notificationsDAO.insert(entity);
			workQueue.add(entity.getUid(), System.currentTimeMillis());
		});
	}

	public void WorkQueueSync(String ulid) {
		NotificationsNTT notification = notificationsDAO.findNotificationByUid(ulid);
		var notificationDate = notificationsDatesDAO.findByIdFamilyAndVersion(notification.getPartyId(),
				notification.getFamilyType(),
				notification.getFlVersion());

		var detail = NotifyGias.Dettaglio.builder();
		addDateToDetail(detail, FamilyType.valueOf(notification.getFamilyType()), notificationDate.getDtVersion());

		var campagna = notificationDate.getDtVersion().getYear();
		var party = getPartyById(tenant, notification.getPartyId());
		var elenco = NotifyGias.CUAAItem.builder()
				.cuaa(party.getCode())
				.campagna(campagna)
				.operazione(notificationDate.getFlVersion())
				.dettaglio(detail.build())
				.idSignal(ulid)
				.build();

		var elencoArray = new ArrayList<NotifyGias.CUAAItem>(1);
		elencoArray.add(elenco);
		var request = NotifyGias.builder()
				.idExternalSystem("NEWAGRI")
				.elencoCUAA(elencoArray)
				.build();

		NotifyGias(request, ulid);

		notificationsDAO.updateDT_Sent(ulid);
	}

	private void addDateToDetail(DettaglioBuilder detail, FamilyType familyType, OffsetDateTime dt) {
		NotificationDate notificationDate = NotificationDate.builder()
				.dataOraNotifica(dt)
				.build();

		switch (familyType) {
			case azienda -> detail.anagrafica(notificationDate);
			case pcg -> detail.pcg(notificationDate);
		}
	}

	public String NotifyGias(NotifyGias request, String ulId) {
		var token = AuthenticateWithGias().getRispostaStringa();
		try {
			String result = client.path("/AgronicaCoreApi/Notification/NotificaCUAA")
					.request(MediaType.APPLICATION_JSON)
					.header("Authorization", "Bearer " + token)
					.post(Entity.json(request), String.class);
			return result;
		} catch (InternalServerErrorException e) {
			log.warn("Error notifying GIAS, ulid: {}, payload: {}", ulId, request);
			throw e;
		}
	}

	// Authentication
	public GiasTokenResponse AuthenticateWithGias() {
		try (Response res = client.path("/AgronicaCoreApi/Login/BackgroundAuthentication")
				.request(MediaType.APPLICATION_JSON)
				.post(Entity.json(Map.of("key", giasLoginToken)))) {

			if (res.getStatusInfo().getFamily() != Family.SUCCESSFUL) {
				String err = res.readEntity(String.class);
				throw new IllegalStateException(
						String.format("Error authenticating to GIAS, status %s, body=%s", res.getStatus(), err));
			}

			return res.readEntity(GiasTokenResponse.class);
		}
	}

	// API Sync
	public SyncNotificationResponse sync(User user, String tenant, String ulid, SyncNotificationRequest request) {
		// Sync logic
		NotificationsNTT notification = notificationsDAO.findNotificationByUid(ulid);
		try {
			String serializedPayload = objectMapper.writeValueAsString(request);
			notificationsDAO.useTransaction(dao -> {
				int updatedRows = notificationsDAO.updateResponse(ulid, serializedPayload);
				if (updatedRows == 0) {
					throw new IllegalArgumentException("No record found for UID: " + ulid);
				}

				if (request.isProcessed()) {
					List<SyncNotificationRequest.Entity> entities = request.getEntities();
					for (SyncNotificationRequest.Entity entity : entities) {
						String entityNames = entity.getEntity();
						OffsetDateTime refTimestamp = entity.getRefTimestamp();
						if (entityNames == null || refTimestamp == null) {
							continue;
						}
						if (!notification.getFamilyType().equalsIgnoreCase(entityNames)) {
							throw new BadRequestException("Bad entityNames");
						}
						notificationsDatesDAO.delete(notification.getPartyId(), notification.getFamilyType(),
								notification.getFlVersion());
						unlockPreviousInHierarchy(notification.getPartyId(),
								FamilyType.valueOf(notification.getFamilyType()));
					}
				} else {
					notificationsDatesDAO.markToBeProcessed(notification.getPartyId(), notification.getFamilyType(),
							notification.getFlVersion(), 0);
				}
			});
		} catch (JsonProcessingException e) {
			throw new RuntimeException(e);
		}

		return new SyncNotificationResponse(true);
	}

}
