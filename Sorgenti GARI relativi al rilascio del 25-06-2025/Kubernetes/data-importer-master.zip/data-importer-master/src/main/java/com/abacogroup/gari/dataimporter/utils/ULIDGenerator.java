package com.abacogroup.gari.dataimporter.utils;

import io.azam.ulidj.ULID;

import java.util.concurrent.ThreadLocalRandom;

public class ULIDGenerator {

	public static String generateULID() {
		return ULID.random(ThreadLocalRandom.current());
	}
}