package com.abacogroup.gari.dataimporter.db.dao;

import com.abacogroup.gari.dataimporter.utils.DbUtils;
import com.abacogroup.jdbi.paging.PagingParams;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;

import java.time.LocalDateTime;
import java.util.List;

/**
 * @author Gennaro Tamburrelli
 * @param <T>
 *            The RS type class
 * @param <D>
 *            The RS type's ID type
 */
public interface IGenericDAO<T, D> extends DataImporterDAO<T, D>  {

	@SqlQuery
	D nextSequenceVal();

	@SqlQuery
	List<T> findPagedType(PagingParams pp);

	@SqlUpdate
	 void insert(T rs);

	@SqlUpdate
	void update(T rs);

	@SqlUpdate
	void deleteById(D id);

	@SqlQuery("select §current_timestamp§")
	LocalDateTime getCurrentTimestampPostgres();

	@SqlQuery("select §current_timestamp§ from dual")
	LocalDateTime getCurrentTimestampOracle();

	default LocalDateTime getCurrentTimestamp() {
		if (Boolean.TRUE.equals(DbUtils.isPostgres)) {
			return this.getCurrentTimestampPostgres();
		} else {
			return this.getCurrentTimestampOracle();
		}
	}

}
