package com.abacogroup.gari.dataimporter.services;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import com.abacogroup.dropwizard.auth.sso2.Sso2Client;
import com.abacogroup.gari.dataimporter.DataImporterConfiguration;
import com.abacogroup.gari.dataimporter.DTOs.GiasTokenResponse;
import com.abacogroup.gari.dataimporter.DTOs.GiasUser;
import com.abacogroup.gari.dataimporter.db.dao.LoggerDAO;
import com.abacogroup.gari.dataimporter.exceptions.GiasServiceException;
import com.abacogroup.gari.dataimporter.utils.GiasUsersResourceManager;
import com.fasterxml.jackson.databind.ObjectMapper;

import jakarta.ws.rs.InternalServerErrorException;
import jakarta.ws.rs.client.Client;
import jakarta.ws.rs.client.ClientRequestContext;
import jakarta.ws.rs.client.ClientRequestFilter;
import jakarta.ws.rs.client.Entity;
import jakarta.ws.rs.client.WebTarget;
import jakarta.ws.rs.core.HttpHeaders;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.core.Response.Status.Family;
import lombok.extern.slf4j.Slf4j;

/**
 * 
 * @author Emanuele Crocilla
 *
 */
@Slf4j
public class GIASUserService extends ADataImporterService {
	
	private final WebTarget agronicaWebClient;
	private final String giasLoginToken;

	public GIASUserService(Sso2Client sso2Client, ObjectMapper objectMapper, LoggerDAO loggerDAO, DataImporterConfiguration configuration,
			Client client) {
		
		super(sso2Client, client, configuration, objectMapper, loggerDAO);
		
		this.giasLoginToken = configuration.getGiasLoginToken();
		
		
		final List<Object> contentEncoding = List.of("identity");
		this.agronicaWebClient = client.target(configuration.getGiasBaseUrl());
		this.agronicaWebClient.register(new ClientRequestFilter() {
			@Override
			public void filter(ClientRequestContext requestContext) throws IOException {
				// Disable gzip on POST, it looks like the remote service doesn't like that
				requestContext.getHeaders().put(HttpHeaders.CONTENT_ENCODING, contentEncoding);
			}
		});
	}

	public String getGiasUserByAgriUser(String agriUserName) {
		
		try {

			String foundGiasName = 
					GiasUsersResourceManager.getInstance().getGiasUserByAgriUser(agriUserName);

			return foundGiasName != null ? foundGiasName : agriUserName;

		} catch (Exception e) {
			String msg = String.format("Unable to retrieve gias user name from agri user %s due an error", agriUserName);
			log.error(msg, e);
			throw new GiasServiceException(msg);
		}
	}
	
	public String sendUserToGias(GiasUser giasUser) {
		
		var token = authenticateWithGias().getRispostaStringa();
		
		try {
			
			// POST {giasBaseUrl}/Path_AgronicaCoreAPI/NewAgri/Import/Utente
			String result = agronicaWebClient.path("/AgronicaCoreAPI/NewAgri/Import/Utente")
					.request(MediaType.APPLICATION_JSON)
					.header("Authorization", "Bearer " + token)
					.post(Entity.json(giasUser), String.class);
			return result;
		} catch (InternalServerErrorException e) {
			log.warn("Error importing GiasUser to GIAS, ulid: payload: {}", giasUser);
			throw e;
		}
	}

	// Authentication
	public GiasTokenResponse authenticateWithGias() {
		
		// https://reumbriacollaudo23_27.netagronica.it/AgronicaCoreApi/Login/BackgroundAuthentication
		try (Response res = agronicaWebClient.path("/AgronicaCoreApi/Login/BackgroundAuthentication")
				.request(MediaType.APPLICATION_JSON)
				.post(Entity.json(Map.of("key", giasLoginToken)))) {

			if (res.getStatusInfo().getFamily() != Family.SUCCESSFUL) {
				String err = res.readEntity(String.class);
				throw new IllegalStateException(String.format("Error authenticating to GIAS, status %s, body=%s", res.getStatus(), err));
			}

			return res.readEntity(GiasTokenResponse.class);
		}
	}

}
