package com.abacogroup.gari.dataimporter.DTOs;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@JsonIgnoreProperties(ignoreUnknown = true)
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class CropPlanRequest {
	@JsonProperty("cropPlanTypeCode")
	private String cropPlanTypeCode;

	@JsonProperty("description")
	private String description;

	@JsonProperty("flNotManaged")
	private boolean flNotManaged;
}

