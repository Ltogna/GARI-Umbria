
package com.abacogroup.gari.dataimporter.soap.fascicolo;

import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlRootElement;
import jakarta.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="CuaaMandataria" type="{http://cooperazione.sian.it/schema/fascicolo}Cuaa"/&gt;
 *         &lt;element name="TipoRTI"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://cooperazione.sian.it/schema/fascicolo}Anno"&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="DataInizioRTI" type="{http://cooperazione.sian.it/schema/fascicolo}Data"/&gt;
 *         &lt;element name="DataFineRTI" type="{http://cooperazione.sian.it/schema/fascicolo}Data"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "cuaaMandataria",
    "tipoRTI",
    "dataInizioRTI",
    "dataFineRTI"
})
@XmlRootElement(name = "ISWSInfoRTI")
public class ISWSInfoRTI {

    @XmlElement(name = "CuaaMandataria", required = true)
    protected String cuaaMandataria;
    @XmlElement(name = "TipoRTI", required = true)
    protected String tipoRTI;
    @XmlElement(name = "DataInizioRTI", required = true)
    protected String dataInizioRTI;
    @XmlElement(name = "DataFineRTI", required = true)
    protected String dataFineRTI;

    /**
     * Gets the value of the cuaaMandataria property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCuaaMandataria() {
        return cuaaMandataria;
    }

    /**
     * Sets the value of the cuaaMandataria property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCuaaMandataria(String value) {
        this.cuaaMandataria = value;
    }

    /**
     * Gets the value of the tipoRTI property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTipoRTI() {
        return tipoRTI;
    }

    /**
     * Sets the value of the tipoRTI property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTipoRTI(String value) {
        this.tipoRTI = value;
    }

    /**
     * Gets the value of the dataInizioRTI property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDataInizioRTI() {
        return dataInizioRTI;
    }

    /**
     * Sets the value of the dataInizioRTI property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDataInizioRTI(String value) {
        this.dataInizioRTI = value;
    }

    /**
     * Gets the value of the dataFineRTI property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDataFineRTI() {
        return dataFineRTI;
    }

    /**
     * Sets the value of the dataFineRTI property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDataFineRTI(String value) {
        this.dataFineRTI = value;
    }

}
