package com.abacogroup.gari.dataimporter.controllers;

import java.util.List;

import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.embeddedqueue.WorkQueue;
import com.abacogroup.gari.dataimporter.DTOs.ImportType;
import com.abacogroup.gari.dataimporter.db.ntt.TrackRequestNTT;
import com.abacogroup.gari.dataimporter.queues.ImportJobService;
import com.abacogroup.gari.dataimporter.services.TrackRequestService;

import io.dropwizard.auth.Auth;
import jakarta.ws.rs.DefaultValue;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.MediaType;

@Path("/{tenant}/public/v1/import-party-payment")
@Produces(MediaType.APPLICATION_JSON)
public class ImportPartyCreditController {
	private final TrackRequestService _trackingService;
	private WorkQueue<ImportJobService> jobSericeQueue;

	public ImportPartyCreditController(WorkQueue<ImportJobService> cropPlanQueue, TrackRequestService trackingService) {
		this.jobSericeQueue = cropPlanQueue;
		_trackingService = trackingService;
	}

	@GET
	@Path("/{cuaa}/import")
	public TrackRequestNTT createImportRequest(
			@Auth User user,
			@PathParam("tenant") String tenantId,
			@PathParam("cuaa") String cuaa) {

		var trackRequest = _trackingService.createTrackRequest(tenantId, cuaa, null, "PENDING", ImportType.PARTY_CREDITS);
		ImportJobService job = new ImportJobService(tenantId, cuaa, null, trackRequest.getRequestId());
		jobSericeQueue.add(job, System.currentTimeMillis());
		return trackRequest;
	}

	@GET
	@Path("/{cuaa}/requests/{requestId}")
	public TrackRequestNTT getRequestById(
			@Auth User user,
			@PathParam("tenant") String tenantId,
			@PathParam("cuaa") String cuaa,
			@PathParam("requestId") String requestId) {
		return _trackingService.findByIdAndCuaaAndTenant(requestId, cuaa, tenantId, ImportType.PARTY_CREDITS);
	}

	@GET
	@Path("/{cuaa}/requests")
	public List<TrackRequestNTT> getRequests(
			@Auth User user,
			@PathParam("tenant") String tenantId,
			@PathParam("cuaa") String cuaa,
			@QueryParam("onlyPending") @DefaultValue("true") boolean onlyPending) {
		return _trackingService.findBySatusAndCuaaAndTenant(cuaa, tenantId, onlyPending, ImportType.PARTY_CREDITS);
	}
}
