package com.abacogroup.gari.dataimporter.DTOs;

import com.fasterxml.jackson.annotation.JsonProperty;

public class LoggerResponse {
	@JsonProperty("request_id")
	private String request_id;

	@JsonProperty("response_body")
	private String response_body;

	@JsonProperty("request_time")
	private String request_time;

	public String getRequest_id() {
		return request_id;
	}

	public void setRequest_id(String request_id) {
		this.request_id = request_id;
	}

	public String getResponse_body() {
		return response_body;
	}

	public void setResponse_body(String response_body) {
		this.response_body = response_body;
	}

	public String getRequest_time() {
		return request_time;
	}

	public void setRequest_time(String request_time) {
		this.request_time = request_time;
	}
	// Getters and constructors...
}
