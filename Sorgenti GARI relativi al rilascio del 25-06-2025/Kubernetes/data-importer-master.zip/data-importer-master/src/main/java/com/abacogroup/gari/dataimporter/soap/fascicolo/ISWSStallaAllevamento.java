
package com.abacogroup.gari.dataimporter.soap.fascicolo;

import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ISWSStallaAllevamento complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ISWSStallaAllevamento"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="DataIniziStal" type="{http://cooperazione.sian.it/schema/fascicolo}Data"/&gt;
 *         &lt;element name="DataFineStal" type="{http://cooperazione.sian.it/schema/fascicolo}Data"/&gt;
 *         &lt;element name="Indirizzo" type="{http://cooperazione.sian.it/schema/fascicolo}Indirizzo"/&gt;
 *         &lt;element name="Localita"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;maxLength value="128"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="Cap" type="{http://cooperazione.sian.it/schema/fascicolo}Cap"/&gt;
 *         &lt;element name="Provincia" type="{http://cooperazione.sian.it/schema/fascicolo}Provincia"/&gt;
 *         &lt;element name="Comune" type="{http://cooperazione.sian.it/schema/fascicolo}Comune"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ISWSStallaAllevamento", propOrder = {
    "dataIniziStal",
    "dataFineStal",
    "indirizzo",
    "localita",
    "cap",
    "provincia",
    "comune"
})
public class ISWSStallaAllevamento {

    @XmlElement(name = "DataIniziStal", required = true)
    protected String dataIniziStal;
    @XmlElement(name = "DataFineStal", required = true, nillable = true)
    protected String dataFineStal;
    @XmlElement(name = "Indirizzo", required = true, nillable = true)
    protected String indirizzo;
    @XmlElement(name = "Localita", required = true, nillable = true)
    protected String localita;
    @XmlElement(name = "Cap", required = true, nillable = true)
    protected String cap;
    @XmlElement(name = "Provincia", required = true, nillable = true)
    protected String provincia;
    @XmlElement(name = "Comune", required = true, nillable = true)
    protected String comune;

    /**
     * Gets the value of the dataIniziStal property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDataIniziStal() {
        return dataIniziStal;
    }

    /**
     * Sets the value of the dataIniziStal property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDataIniziStal(String value) {
        this.dataIniziStal = value;
    }

    /**
     * Gets the value of the dataFineStal property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDataFineStal() {
        return dataFineStal;
    }

    /**
     * Sets the value of the dataFineStal property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDataFineStal(String value) {
        this.dataFineStal = value;
    }

    /**
     * Gets the value of the indirizzo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIndirizzo() {
        return indirizzo;
    }

    /**
     * Sets the value of the indirizzo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIndirizzo(String value) {
        this.indirizzo = value;
    }

    /**
     * Gets the value of the localita property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLocalita() {
        return localita;
    }

    /**
     * Sets the value of the localita property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLocalita(String value) {
        this.localita = value;
    }

    /**
     * Gets the value of the cap property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCap() {
        return cap;
    }

    /**
     * Sets the value of the cap property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCap(String value) {
        this.cap = value;
    }

    /**
     * Gets the value of the provincia property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProvincia() {
        return provincia;
    }

    /**
     * Sets the value of the provincia property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProvincia(String value) {
        this.provincia = value;
    }

    /**
     * Gets the value of the comune property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getComune() {
        return comune;
    }

    /**
     * Sets the value of the comune property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setComune(String value) {
        this.comune = value;
    }

}
