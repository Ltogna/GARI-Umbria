package com.abacogroup.gari.dataimporter.DTOs;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class DossierDTO {

	@JsonProperty("dossierId")
	private Long dossierId;

	@JsonProperty("dossierCode")
	private String dossierCode;

	@JsonProperty("anomalies")
	private List<DossierAnomalyDTO> anomalies;
}
