package com.abacogroup.gari.dataimporter.bundles;

/**
 * @author Gennaro Tamburrelli
 * @author Alexandru Paraschiv
 */
public class BundleConstants {

	public static final String WORKFLOW = "workflows";

	private BundleConstants() {
	}

	public static final String TENANT_TEMPLATE_CODE = "*";
	public static final String BUNDLE_SYSTEM_USERNAME = "BUNDLE";
}
