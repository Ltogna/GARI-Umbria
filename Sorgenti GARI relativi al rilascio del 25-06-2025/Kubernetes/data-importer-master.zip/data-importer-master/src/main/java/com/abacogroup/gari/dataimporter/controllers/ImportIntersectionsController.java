package com.abacogroup.gari.dataimporter.controllers;

import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.embeddedqueue.WorkQueue;
import com.abacogroup.gari.dataimporter.DTOs.ImportType;
import com.abacogroup.gari.dataimporter.db.ntt.TrackRequestNTT;
import com.abacogroup.gari.dataimporter.queues.ImportZnvCatalogJobService;
import com.abacogroup.gari.dataimporter.services.TrackRequestService;
import io.dropwizard.auth.Auth;
import jakarta.validation.constraints.NotNull;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;

import java.time.OffsetDateTime;

import org.locationtech.jts.geom.Envelope;

@Path("/{tenant}/public/v1/import-gis/zvn")
@Produces(MediaType.APPLICATION_JSON)
public class ImportIntersectionsController {
	private final TrackRequestService _trackingService;
	private WorkQueue<ImportZnvCatalogJobService> znvQueue;

	public ImportIntersectionsController(WorkQueue<ImportZnvCatalogJobService> _service, TrackRequestService trackingService) {
		_trackingService = trackingService;
		this.znvQueue = _service;
	}

	@GET
	@Path("/bbox")
	public TrackRequestNTT importZVN(
			@Auth User user,
			@NotNull @QueryParam("tenant") String tenant,
			@NotNull @QueryParam("xmin") double xmin,
			@NotNull @QueryParam("ymin") double ymin,
			@NotNull @QueryParam("xmax") double xmax,
			@NotNull @QueryParam("ymax") double ymax,
			@NotNull @QueryParam("epsg") String epsg,
			@QueryParam("max-lenght-per-side") @DefaultValue("5000") int maxLenghtPerSide,
			@NotNull @QueryParam("date") OffsetDateTime dataVal) {

		Envelope env = new Envelope(xmin, xmax, ymin, ymax);

		int width = (int) Math.ceil(env.getWidth() / maxLenghtPerSide);
		int height = (int) Math.ceil(env.getHeight() / maxLenghtPerSide);

		TrackRequestNTT trackRequest = _trackingService.createTrackRequest(tenant, "", "", "PENDING", ImportType.ZNV_CATALOG_NOTIFICATION);
		for (int w = 0; w < width; w++) {
			for (int h = 0; h < height; h++) {
				double x1 = xmin + w * maxLenghtPerSide;
				double x2 = Math.min(xmax, x1 + maxLenghtPerSide);
				double y1 = ymin + h * maxLenghtPerSide;
				double y2 = Math.min(ymax, y1 + maxLenghtPerSide);

				ImportZnvCatalogJobService job = new ImportZnvCatalogJobService(x1, y1, x2, y2, epsg, dataVal, trackRequest.getRequestId(), tenant);
				znvQueue.add(job, trackRequest.getRequestId(), w + 1 + h * width);
			}
		}

		return trackRequest;
	}
}
