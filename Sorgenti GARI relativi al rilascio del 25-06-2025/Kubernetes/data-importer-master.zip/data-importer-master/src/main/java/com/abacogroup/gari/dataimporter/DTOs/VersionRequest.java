package com.abacogroup.gari.dataimporter.DTOs;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@JsonIgnoreProperties(ignoreUnknown = true)

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class VersionRequest {

	@JsonProperty("message")
	private String message;

	@JsonProperty("havingAcknowledgedAnomalies")
	private boolean havingAcknowledgedAnomalies;

	@JsonProperty("pointInTime")
	private String pointInTime;
}
