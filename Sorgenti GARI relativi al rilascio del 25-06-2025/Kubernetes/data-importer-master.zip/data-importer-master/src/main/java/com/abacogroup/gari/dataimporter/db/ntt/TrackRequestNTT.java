package com.abacogroup.gari.dataimporter.db.ntt;

import java.time.OffsetDateTime;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class TrackRequestNTT {

	private String requestId; // ULID as a String
	private String userId;
	private String cuaa;
	private String campagna;
	private OffsetDateTime dtRequest;
	private String flStatus; // Enum values: PENDING, DONE, ERROR
	private Integer importType;// Enum values: PENDING, DONE, ERROR
	// private List<LoggerNTT> loggers;
	// public List<LoggerNTT> getLoggers() {
	// return loggers;
	// }
	// public void setLoggers(List<LoggerNTT> loggers) {
	// this.loggers = loggers;
	// }

	public String getRequestId() {
		return requestId;
	}

	public String getCuaa() {
		return cuaa;
	}

	public void setCuaa(String cuaa) {
		this.cuaa = cuaa;
	}

	public String getCampagna() {
		return campagna;
	}

	public void setCampagna(String campagna) {
		this.campagna = campagna;
	}
}
