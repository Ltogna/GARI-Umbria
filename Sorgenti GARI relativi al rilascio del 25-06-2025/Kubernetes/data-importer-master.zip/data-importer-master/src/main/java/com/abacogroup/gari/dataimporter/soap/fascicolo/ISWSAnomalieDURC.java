
package com.abacogroup.gari.dataimporter.soap.fascicolo;

import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ISWSAnomalieDURC complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ISWSAnomalieDURC"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="CodiceAnomaliaDURC" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;maxLength value="3"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="DescrizioneAnomaliaDURC" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ISWSAnomalieDURC", propOrder = {
    "codiceAnomaliaDURC",
    "descrizioneAnomaliaDURC"
})
public class ISWSAnomalieDURC {

    @XmlElement(name = "CodiceAnomaliaDURC")
    protected String codiceAnomaliaDURC;
    @XmlElement(name = "DescrizioneAnomaliaDURC")
    protected String descrizioneAnomaliaDURC;

    /**
     * Gets the value of the codiceAnomaliaDURC property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodiceAnomaliaDURC() {
        return codiceAnomaliaDURC;
    }

    /**
     * Sets the value of the codiceAnomaliaDURC property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodiceAnomaliaDURC(String value) {
        this.codiceAnomaliaDURC = value;
    }

    /**
     * Gets the value of the descrizioneAnomaliaDURC property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDescrizioneAnomaliaDURC() {
        return descrizioneAnomaliaDURC;
    }

    /**
     * Sets the value of the descrizioneAnomaliaDURC property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDescrizioneAnomaliaDURC(String value) {
        this.descrizioneAnomaliaDURC = value;
    }

}
