package com.abacogroup.gari.dataimporter.DTOs;

import java.time.LocalDateTime;

import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.NoArgsConstructor;

@JsonIgnoreProperties(ignoreUnknown = true)
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class VersionResponse {

	@JsonProperty("version")
	private String version;

	@JsonProperty("versionDate")
	private LocalDateTime versionDate;

	@JsonProperty("versionReferenceDate")
	private AbsoluteDate versionReferenceDate;

	@JsonProperty("message")
	private String message;

	@JsonProperty("userId")
	private String userId;

	@JsonProperty("flPublished")
	private boolean flPublished;

	// Getters
	public String getVersion() {
		return version;
	}

	public LocalDateTime getVersionDate() {
		return versionDate;
	}

	public AbsoluteDate getVersionReferenceDate() {
		return versionReferenceDate;
	}

	public String getMessage() {
		return message;
	}

	public String getUserId() {
		return userId;
	}

}
