package com.abacogroup.gari.dataimporter.queues;

import com.abacogroup.embeddedqueue.QueueErrorListener;
import com.abacogroup.embeddedqueue.ThrowingConsumer;
import com.abacogroup.gari.dataimporter.Interfaces.ICropPlanService;
import com.abacogroup.gari.dataimporter.services.TrackRequestService;

public class ImportCropPlanConsumer implements ThrowingConsumer<ImportJobService>, QueueErrorListener<ImportJobService> {

	private final ICropPlanService iCropPlanService;
	private final TrackRequestService trackRequestService;

	public ImportCropPlanConsumer(ICropPlanService iCropPlanService, TrackRequestService trackRequestService) {
		this.iCropPlanService = iCropPlanService;
		this.trackRequestService = trackRequestService;
	}

	@Override
	public void accept(ImportJobService job) throws Exception {
		iCropPlanService.ImportCropPlan(null, job.getTenantId(), job.getCuaa(), job.getCampagna(),job.getRequestId()); // TODO: remove user
		trackRequestService.updateStatus(job.getRequestId(), "DONE");
	}

	@Override
	public ErrorAction onJobError(ImportJobService job, Throwable t) {
		trackRequestService.updateStatus(job.getRequestId(), "ERROR");
		return ErrorAction.MARK_AS_ERRORED;
	}

}
