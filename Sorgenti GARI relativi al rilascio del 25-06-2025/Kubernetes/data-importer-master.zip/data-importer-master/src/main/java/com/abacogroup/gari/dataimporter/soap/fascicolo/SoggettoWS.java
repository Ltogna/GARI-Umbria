
package com.abacogroup.gari.dataimporter.soap.fascicolo;

import jakarta.xml.bind.JAXBElement;
import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlElementRef;
import jakarta.xml.bind.annotation.XmlRootElement;
import jakarta.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="CUAA" type="{http://cooperazione.sian.it/schema/fascicolo}Cuaa"/&gt;
 *         &lt;element name="Flag_pers_fisi"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}int"&gt;
 *               &lt;enumeration value="0"/&gt;
 *               &lt;enumeration value="1"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="Codi_sess" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;length value="1"/&gt;
 *               &lt;enumeration value="M"/&gt;
 *               &lt;enumeration value="F"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="Data_nasc" type="{http://cooperazione.sian.it/schema/fascicolo}Data"/&gt;
 *         &lt;element name="Data_iniz_atti" type="{http://cooperazione.sian.it/schema/fascicolo}Data"/&gt;
 *         &lt;element name="Data_fine_atti" type="{http://cooperazione.sian.it/schema/fascicolo}Data"/&gt;
 *         &lt;element name="Data_aggi" type="{http://cooperazione.sian.it/schema/fascicolo}Data"/&gt;
 *         &lt;element name="Desc_cogn"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;maxLength value="30"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="Desc_nome"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;maxLength value="50"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="Desc_natu_giur"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;maxLength value="100"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="Desc_ragi_soci"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;maxLength value="150"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="Codi_fisc_luna"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;length value="4"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="Codi_sigl_prov_nasc"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;length value="2"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="Desc_prov_nasc"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;maxLength value="100"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="Desc_comu_nasc"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;maxLength value="100"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="Codi_came_ciaa_reaa"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;maxLength value="16"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="Codi_came_ciaa_riii"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;maxLength value="16"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="Codi_part_ivaa"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;maxLength value="11"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="Desc_inte"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;maxLength value="150"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="Data_iniz_part_ivaa" type="{http://cooperazione.sian.it/schema/fascicolo}Data"/&gt;
 *         &lt;element name="Data_fine_part_ivaa" type="{http://cooperazione.sian.it/schema/fascicolo}Data"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "cuaa",
    "flagPersFisi",
    "codiSess",
    "dataNasc",
    "dataInizAtti",
    "dataFineAtti",
    "dataAggi",
    "descCogn",
    "descNome",
    "descNatuGiur",
    "descRagiSoci",
    "codiFiscLuna",
    "codiSiglProvNasc",
    "descProvNasc",
    "descComuNasc",
    "codiCameCiaaReaa",
    "codiCameCiaaRiii",
    "codiPartIvaa",
    "descInte",
    "dataInizPartIvaa",
    "dataFinePartIvaa"
})
@XmlRootElement(name = "SoggettoWS")
public class SoggettoWS {

    @XmlElement(name = "CUAA", required = true)
    protected String cuaa;
    @XmlElement(name = "Flag_pers_fisi")
    protected int flagPersFisi;
    @XmlElementRef(name = "Codi_sess", namespace = "http://cooperazione.sian.it/schema/fascicolo", type = JAXBElement.class, required = false)
    protected JAXBElement<String> codiSess;
    @XmlElement(name = "Data_nasc", required = true, nillable = true)
    protected String dataNasc;
    @XmlElement(name = "Data_iniz_atti", required = true, nillable = true)
    protected String dataInizAtti;
    @XmlElement(name = "Data_fine_atti", required = true, nillable = true)
    protected String dataFineAtti;
    @XmlElement(name = "Data_aggi", required = true)
    protected String dataAggi;
    @XmlElement(name = "Desc_cogn", required = true, nillable = true)
    protected String descCogn;
    @XmlElement(name = "Desc_nome", required = true, nillable = true)
    protected String descNome;
    @XmlElement(name = "Desc_natu_giur", required = true, nillable = true)
    protected String descNatuGiur;
    @XmlElement(name = "Desc_ragi_soci", required = true, nillable = true)
    protected String descRagiSoci;
    @XmlElement(name = "Codi_fisc_luna", required = true, nillable = true)
    protected String codiFiscLuna;
    @XmlElement(name = "Codi_sigl_prov_nasc", required = true, nillable = true)
    protected String codiSiglProvNasc;
    @XmlElement(name = "Desc_prov_nasc", required = true, nillable = true)
    protected String descProvNasc;
    @XmlElement(name = "Desc_comu_nasc", required = true, nillable = true)
    protected String descComuNasc;
    @XmlElement(name = "Codi_came_ciaa_reaa", required = true, nillable = true)
    protected String codiCameCiaaReaa;
    @XmlElement(name = "Codi_came_ciaa_riii", required = true, nillable = true)
    protected String codiCameCiaaRiii;
    @XmlElement(name = "Codi_part_ivaa", required = true, nillable = true)
    protected String codiPartIvaa;
    @XmlElement(name = "Desc_inte", required = true, nillable = true)
    protected String descInte;
    @XmlElement(name = "Data_iniz_part_ivaa", required = true, nillable = true)
    protected String dataInizPartIvaa;
    @XmlElement(name = "Data_fine_part_ivaa", required = true, nillable = true)
    protected String dataFinePartIvaa;

    /**
     * Gets the value of the cuaa property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCUAA() {
        return cuaa;
    }

    /**
     * Sets the value of the cuaa property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCUAA(String value) {
        this.cuaa = value;
    }

    /**
     * Gets the value of the flagPersFisi property.
     * 
     */
    public int getFlagPersFisi() {
        return flagPersFisi;
    }

    /**
     * Sets the value of the flagPersFisi property.
     * 
     */
    public void setFlagPersFisi(int value) {
        this.flagPersFisi = value;
    }

    /**
     * Gets the value of the codiSess property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getCodiSess() {
        return codiSess;
    }

    /**
     * Sets the value of the codiSess property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setCodiSess(JAXBElement<String> value) {
        this.codiSess = value;
    }

    /**
     * Gets the value of the dataNasc property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDataNasc() {
        return dataNasc;
    }

    /**
     * Sets the value of the dataNasc property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDataNasc(String value) {
        this.dataNasc = value;
    }

    /**
     * Gets the value of the dataInizAtti property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDataInizAtti() {
        return dataInizAtti;
    }

    /**
     * Sets the value of the dataInizAtti property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDataInizAtti(String value) {
        this.dataInizAtti = value;
    }

    /**
     * Gets the value of the dataFineAtti property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDataFineAtti() {
        return dataFineAtti;
    }

    /**
     * Sets the value of the dataFineAtti property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDataFineAtti(String value) {
        this.dataFineAtti = value;
    }

    /**
     * Gets the value of the dataAggi property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDataAggi() {
        return dataAggi;
    }

    /**
     * Sets the value of the dataAggi property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDataAggi(String value) {
        this.dataAggi = value;
    }

    /**
     * Gets the value of the descCogn property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDescCogn() {
        return descCogn;
    }

    /**
     * Sets the value of the descCogn property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDescCogn(String value) {
        this.descCogn = value;
    }

    /**
     * Gets the value of the descNome property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDescNome() {
        return descNome;
    }

    /**
     * Sets the value of the descNome property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDescNome(String value) {
        this.descNome = value;
    }

    /**
     * Gets the value of the descNatuGiur property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDescNatuGiur() {
        return descNatuGiur;
    }

    /**
     * Sets the value of the descNatuGiur property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDescNatuGiur(String value) {
        this.descNatuGiur = value;
    }

    /**
     * Gets the value of the descRagiSoci property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDescRagiSoci() {
        return descRagiSoci;
    }

    /**
     * Sets the value of the descRagiSoci property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDescRagiSoci(String value) {
        this.descRagiSoci = value;
    }

    /**
     * Gets the value of the codiFiscLuna property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodiFiscLuna() {
        return codiFiscLuna;
    }

    /**
     * Sets the value of the codiFiscLuna property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodiFiscLuna(String value) {
        this.codiFiscLuna = value;
    }

    /**
     * Gets the value of the codiSiglProvNasc property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodiSiglProvNasc() {
        return codiSiglProvNasc;
    }

    /**
     * Sets the value of the codiSiglProvNasc property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodiSiglProvNasc(String value) {
        this.codiSiglProvNasc = value;
    }

    /**
     * Gets the value of the descProvNasc property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDescProvNasc() {
        return descProvNasc;
    }

    /**
     * Sets the value of the descProvNasc property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDescProvNasc(String value) {
        this.descProvNasc = value;
    }

    /**
     * Gets the value of the descComuNasc property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDescComuNasc() {
        return descComuNasc;
    }

    /**
     * Sets the value of the descComuNasc property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDescComuNasc(String value) {
        this.descComuNasc = value;
    }

    /**
     * Gets the value of the codiCameCiaaReaa property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodiCameCiaaReaa() {
        return codiCameCiaaReaa;
    }

    /**
     * Sets the value of the codiCameCiaaReaa property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodiCameCiaaReaa(String value) {
        this.codiCameCiaaReaa = value;
    }

    /**
     * Gets the value of the codiCameCiaaRiii property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodiCameCiaaRiii() {
        return codiCameCiaaRiii;
    }

    /**
     * Sets the value of the codiCameCiaaRiii property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodiCameCiaaRiii(String value) {
        this.codiCameCiaaRiii = value;
    }

    /**
     * Gets the value of the codiPartIvaa property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodiPartIvaa() {
        return codiPartIvaa;
    }

    /**
     * Sets the value of the codiPartIvaa property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodiPartIvaa(String value) {
        this.codiPartIvaa = value;
    }

    /**
     * Gets the value of the descInte property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDescInte() {
        return descInte;
    }

    /**
     * Sets the value of the descInte property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDescInte(String value) {
        this.descInte = value;
    }

    /**
     * Gets the value of the dataInizPartIvaa property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDataInizPartIvaa() {
        return dataInizPartIvaa;
    }

    /**
     * Sets the value of the dataInizPartIvaa property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDataInizPartIvaa(String value) {
        this.dataInizPartIvaa = value;
    }

    /**
     * Gets the value of the dataFinePartIvaa property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDataFinePartIvaa() {
        return dataFinePartIvaa;
    }

    /**
     * Sets the value of the dataFinePartIvaa property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDataFinePartIvaa(String value) {
        this.dataFinePartIvaa = value;
    }

}
