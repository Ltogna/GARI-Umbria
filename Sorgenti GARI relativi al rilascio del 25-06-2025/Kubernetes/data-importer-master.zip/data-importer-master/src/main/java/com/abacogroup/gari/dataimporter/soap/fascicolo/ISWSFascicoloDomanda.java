
package com.abacogroup.gari.dataimporter.soap.fascicolo;

import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlRootElement;
import jakarta.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="CUAA" type="{http://cooperazione.sian.it/schema/fascicolo}Cuaa"/&gt;
 *         &lt;element name="tipoIdScheda"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;enumeration value="1"/&gt;
 *               &lt;enumeration value="2"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="idScheda"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;maxLength value="30"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="DataScheda" type="{http://cooperazione.sian.it/schema/fascicolo}Data"/&gt;
 *         &lt;element name="tipoIdDomanda"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;enumeration value="1"/&gt;
 *               &lt;enumeration value="2"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="idDomanda"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;maxLength value="16"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="tipoDomanda"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="campagna" type="{http://cooperazione.sian.it/schema/fascicolo}Anno"/&gt;
 *         &lt;element name="DataDomanda" type="{http://cooperazione.sian.it/schema/fascicolo}Data"/&gt;
 *         &lt;element name="flagFirmaDich"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;enumeration value="SI"/&gt;
 *               &lt;enumeration value="NO"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "cuaa",
    "tipoIdScheda",
    "idScheda",
    "dataScheda",
    "tipoIdDomanda",
    "idDomanda",
    "tipoDomanda",
    "campagna",
    "dataDomanda",
    "flagFirmaDich"
})
@XmlRootElement(name = "ISWSFascicoloDomanda")
public class ISWSFascicoloDomanda {

    @XmlElement(name = "CUAA", required = true)
    protected String cuaa;
    @XmlElement(required = true)
    protected String tipoIdScheda;
    @XmlElement(required = true)
    protected String idScheda;
    @XmlElement(name = "DataScheda", required = true)
    protected String dataScheda;
    @XmlElement(required = true)
    protected String tipoIdDomanda;
    @XmlElement(required = true)
    protected String idDomanda;
    @XmlElement(required = true)
    protected String tipoDomanda;
    @XmlElement(required = true)
    protected String campagna;
    @XmlElement(name = "DataDomanda", required = true)
    protected String dataDomanda;
    @XmlElement(required = true)
    protected String flagFirmaDich;

    /**
     * Gets the value of the cuaa property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCUAA() {
        return cuaa;
    }

    /**
     * Sets the value of the cuaa property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCUAA(String value) {
        this.cuaa = value;
    }

    /**
     * Gets the value of the tipoIdScheda property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTipoIdScheda() {
        return tipoIdScheda;
    }

    /**
     * Sets the value of the tipoIdScheda property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTipoIdScheda(String value) {
        this.tipoIdScheda = value;
    }

    /**
     * Gets the value of the idScheda property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIdScheda() {
        return idScheda;
    }

    /**
     * Sets the value of the idScheda property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIdScheda(String value) {
        this.idScheda = value;
    }

    /**
     * Gets the value of the dataScheda property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDataScheda() {
        return dataScheda;
    }

    /**
     * Sets the value of the dataScheda property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDataScheda(String value) {
        this.dataScheda = value;
    }

    /**
     * Gets the value of the tipoIdDomanda property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTipoIdDomanda() {
        return tipoIdDomanda;
    }

    /**
     * Sets the value of the tipoIdDomanda property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTipoIdDomanda(String value) {
        this.tipoIdDomanda = value;
    }

    /**
     * Gets the value of the idDomanda property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIdDomanda() {
        return idDomanda;
    }

    /**
     * Sets the value of the idDomanda property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIdDomanda(String value) {
        this.idDomanda = value;
    }

    /**
     * Gets the value of the tipoDomanda property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTipoDomanda() {
        return tipoDomanda;
    }

    /**
     * Sets the value of the tipoDomanda property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTipoDomanda(String value) {
        this.tipoDomanda = value;
    }

    /**
     * Gets the value of the campagna property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCampagna() {
        return campagna;
    }

    /**
     * Sets the value of the campagna property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCampagna(String value) {
        this.campagna = value;
    }

    /**
     * Gets the value of the dataDomanda property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDataDomanda() {
        return dataDomanda;
    }

    /**
     * Sets the value of the dataDomanda property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDataDomanda(String value) {
        this.dataDomanda = value;
    }

    /**
     * Gets the value of the flagFirmaDich property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFlagFirmaDich() {
        return flagFirmaDich;
    }

    /**
     * Sets the value of the flagFirmaDich property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFlagFirmaDich(String value) {
        this.flagFirmaDich = value;
    }

}
