package com.abacogroup.gari.dataimporter.DTOs;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;
import lombok.Builder;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class GeoJsonFeatureCollection {

	@JsonProperty("type")
	private String type;

	@JsonProperty("crs")
	private Crs crs;

	@JsonProperty("features")
	private List<Feature> features;

	@Data
	@NoArgsConstructor
	@AllArgsConstructor
	@Builder
	public static class Crs {
		@JsonProperty("type")
		private String type;

		@JsonProperty("properties")
		private CrsProperties properties;

		@Data
		@NoArgsConstructor
		@AllArgsConstructor
		@Builder
		public static class CrsProperties {
			@JsonProperty("name")
			private String name;
		}
	}

	@Data
	@NoArgsConstructor
	@AllArgsConstructor
	@Builder
	public static class Feature {
		@JsonProperty("type")
		private String type;

		@JsonProperty("properties")
		private FeatureProperties properties;

		@JsonProperty("geometry")
		private Geometry geometry;

		@JsonProperty("id")
		private String id;
	}

	@Data
	@NoArgsConstructor
	@AllArgsConstructor
	@Builder
	public static class FeatureProperties {
		@JsonProperty("area")
		private Double area;

		@JsonProperty("rifAtto")
		private String rifAtto;

		@JsonProperty("idRec")
		private Long idRec;

		@JsonProperty("regione")
		private String regione;

		@JsonProperty("nomeZvn")
		private String nomeZvn;
	}

	@Data
	@NoArgsConstructor
	@AllArgsConstructor
	@Builder
	public static class Geometry {
		@JsonProperty("type")
		private String type;

		// A Polygon in GeoJSON is typically List<List<List<Double>>>
		// The outer list is the array of rings, each ring is a list of coordinate pairs
		@JsonProperty("coordinates")
		private List<List<List<Double>>> coordinates;
	}
}

