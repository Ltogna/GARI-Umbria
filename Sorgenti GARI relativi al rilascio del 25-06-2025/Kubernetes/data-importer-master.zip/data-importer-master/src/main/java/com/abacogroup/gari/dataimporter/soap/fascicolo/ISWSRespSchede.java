
package com.abacogroup.gari.dataimporter.soap.fascicolo;

import jakarta.xml.bind.JAXBElement;
import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlElementRef;
import jakarta.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ISWSRespSchede complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ISWSRespSchede"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="CUAA" type="{http://cooperazione.sian.it/schema/fascicolo}Cuaa"/&gt;
 *         &lt;element name="IDScheda" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;maxLength value="15"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="DataScheda" type="{http://cooperazione.sian.it/schema/fascicolo}Data" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ISWSRespSchede", propOrder = {
    "cuaa",
    "idScheda",
    "dataScheda"
})
public class ISWSRespSchede {

    @XmlElement(name = "CUAA", required = true)
    protected String cuaa;
    @XmlElementRef(name = "IDScheda", namespace = "http://cooperazione.sian.it/schema/fascicolo", type = JAXBElement.class, required = false)
    protected JAXBElement<String> idScheda;
    @XmlElementRef(name = "DataScheda", namespace = "http://cooperazione.sian.it/schema/fascicolo", type = JAXBElement.class, required = false)
    protected JAXBElement<String> dataScheda;

    /**
     * Gets the value of the cuaa property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCUAA() {
        return cuaa;
    }

    /**
     * Sets the value of the cuaa property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCUAA(String value) {
        this.cuaa = value;
    }

    /**
     * Gets the value of the idScheda property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getIDScheda() {
        return idScheda;
    }

    /**
     * Sets the value of the idScheda property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setIDScheda(JAXBElement<String> value) {
        this.idScheda = value;
    }

    /**
     * Gets the value of the dataScheda property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getDataScheda() {
        return dataScheda;
    }

    /**
     * Sets the value of the dataScheda property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setDataScheda(JAXBElement<String> value) {
        this.dataScheda = value;
    }

}
