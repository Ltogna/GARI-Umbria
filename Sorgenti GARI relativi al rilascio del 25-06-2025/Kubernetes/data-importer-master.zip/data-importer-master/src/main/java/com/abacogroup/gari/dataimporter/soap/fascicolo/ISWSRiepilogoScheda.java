
package com.abacogroup.gari.dataimporter.soap.fascicolo;

import java.util.ArrayList;
import java.util.List;
import jakarta.xml.bind.JAXBElement;
import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlElementRef;
import jakarta.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ISWSRiepilogoScheda complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ISWSRiepilogoScheda"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="RiepilogoConsTerreni" type="{http://cooperazione.sian.it/schema/fascicolo}ISWSRiep1" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="PartTotaleCondAzienda" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="SupTotaleCondAzienda" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="RiepilogoOccuSuolo" type="{http://cooperazione.sian.it/schema/fascicolo}ISWSRiep2" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="SupTotaleOccuAzienda" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="SupTotaleRiscontrataAzienda" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ISWSRiepilogoScheda", propOrder = {
    "riepilogoConsTerreni",
    "partTotaleCondAzienda",
    "supTotaleCondAzienda",
    "riepilogoOccuSuolo",
    "supTotaleOccuAzienda",
    "supTotaleRiscontrataAzienda"
})
public class ISWSRiepilogoScheda {

    @XmlElement(name = "RiepilogoConsTerreni", nillable = true)
    protected List<ISWSRiep1> riepilogoConsTerreni;
    @XmlElementRef(name = "PartTotaleCondAzienda", namespace = "http://cooperazione.sian.it/schema/fascicolo", type = JAXBElement.class, required = false)
    protected JAXBElement<String> partTotaleCondAzienda;
    @XmlElementRef(name = "SupTotaleCondAzienda", namespace = "http://cooperazione.sian.it/schema/fascicolo", type = JAXBElement.class, required = false)
    protected JAXBElement<String> supTotaleCondAzienda;
    @XmlElement(name = "RiepilogoOccuSuolo", nillable = true)
    protected List<ISWSRiep2> riepilogoOccuSuolo;
    @XmlElementRef(name = "SupTotaleOccuAzienda", namespace = "http://cooperazione.sian.it/schema/fascicolo", type = JAXBElement.class, required = false)
    protected JAXBElement<String> supTotaleOccuAzienda;
    @XmlElementRef(name = "SupTotaleRiscontrataAzienda", namespace = "http://cooperazione.sian.it/schema/fascicolo", type = JAXBElement.class, required = false)
    protected JAXBElement<String> supTotaleRiscontrataAzienda;

    /**
     * Gets the value of the riepilogoConsTerreni property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the Jakarta XML Binding object.
     * This is why there is not a <CODE>set</CODE> method for the riepilogoConsTerreni property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getRiepilogoConsTerreni().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ISWSRiep1 }
     * 
     * 
     */
    public List<ISWSRiep1> getRiepilogoConsTerreni() {
        if (riepilogoConsTerreni == null) {
            riepilogoConsTerreni = new ArrayList<ISWSRiep1>();
        }
        return this.riepilogoConsTerreni;
    }

    /**
     * Gets the value of the partTotaleCondAzienda property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getPartTotaleCondAzienda() {
        return partTotaleCondAzienda;
    }

    /**
     * Sets the value of the partTotaleCondAzienda property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setPartTotaleCondAzienda(JAXBElement<String> value) {
        this.partTotaleCondAzienda = value;
    }

    /**
     * Gets the value of the supTotaleCondAzienda property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getSupTotaleCondAzienda() {
        return supTotaleCondAzienda;
    }

    /**
     * Sets the value of the supTotaleCondAzienda property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setSupTotaleCondAzienda(JAXBElement<String> value) {
        this.supTotaleCondAzienda = value;
    }

    /**
     * Gets the value of the riepilogoOccuSuolo property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the Jakarta XML Binding object.
     * This is why there is not a <CODE>set</CODE> method for the riepilogoOccuSuolo property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getRiepilogoOccuSuolo().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ISWSRiep2 }
     * 
     * 
     */
    public List<ISWSRiep2> getRiepilogoOccuSuolo() {
        if (riepilogoOccuSuolo == null) {
            riepilogoOccuSuolo = new ArrayList<ISWSRiep2>();
        }
        return this.riepilogoOccuSuolo;
    }

    /**
     * Gets the value of the supTotaleOccuAzienda property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getSupTotaleOccuAzienda() {
        return supTotaleOccuAzienda;
    }

    /**
     * Sets the value of the supTotaleOccuAzienda property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setSupTotaleOccuAzienda(JAXBElement<String> value) {
        this.supTotaleOccuAzienda = value;
    }

    /**
     * Gets the value of the supTotaleRiscontrataAzienda property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getSupTotaleRiscontrataAzienda() {
        return supTotaleRiscontrataAzienda;
    }

    /**
     * Sets the value of the supTotaleRiscontrataAzienda property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setSupTotaleRiscontrataAzienda(JAXBElement<String> value) {
        this.supTotaleRiscontrataAzienda = value;
    }

}
