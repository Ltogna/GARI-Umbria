package com.abacogroup.gari.dataimporter.db.dao;

import java.util.function.Consumer;

import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.customizer.BindBean;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;

import com.abacogroup.gari.dataimporter.db.ntt.NotificationsDatesNTT;

@RegisterBeanMapper(NotificationsDatesNTT.class)
public interface NotificationsDatesDAO {

	@SqlUpdate("""
			INSERT INTO dataimporter_notifications_dates (party_id, family_type, fl_version, dt_version, fl_to_be_processed)
			VALUES(:partyId, :familyType, :flVersion, :dtVersion, :flToBeProcessed)""")
	void insert(@BindBean NotificationsDatesNTT notificationDate);

	@SqlQuery("SELECT * FROM dataimporter_notifications_dates WHERE party_id = :partyId AND family_type=:family_type AND fl_version=:fl_version")
	NotificationsDatesNTT findById(@Bind("partyId") long partyId, @Bind("family_type") String familyType, @Bind("fl_version") String flVersion);

	@SqlUpdate("""
			UPDATE dataimporter_notifications_dates
			   SET fl_to_be_processed = :flToBeProcessed
			 WHERE party_id = :partyId
			   AND family_type=:familyType
			   AND fl_version = :flVersion""")
	int setToBeProcessed(@Bind("partyId") long partyId, @Bind("familyType") String familyType, @Bind("flVersion") String flVersion,
			@Bind("flToBeProcessed") int flToBeProcessed);

	@SqlQuery("""
			SELECT *
			  FROM dataimporter_notifications_dates d
			 WHERE fl_to_be_processed=1
			   AND NOT EXISTS (select 1 from dataimporter_notifications n
			                    where n.party_id = d.party_id
								  and n.family_type = d.family_type
								  and n.fl_version = d.fl_version
								  and dt_response is null)""")
	void findUnnotifiedRecords(Consumer<NotificationsDatesNTT> consumer);

	@SqlQuery("SELECT * FROM dataimporter_notifications_dates WHERE party_id=:partyId AND family_type=:familyType AND fl_version=:flVersion")
	NotificationsDatesNTT findByIdFamilyAndVersion(@Bind("partyId") long partyId, @Bind("familyType") String familyType, @Bind("flVersion") String flVersion);

	@SqlUpdate("""
			UPDATE dataimporter_notifications_dates
			   SET fl_to_be_processed = :flToBeProcessed
			 WHERE party_id = :partyId
			   AND family_type=:familyType
			   AND fl_version = :flVersion""")
	int markToBeProcessed(@Bind("partyId") long partyId, @Bind("familyType") String familyType, @Bind("flVersion") String flVersion,
			@Bind("flToBeProcessed") int flToBeProcessed);

	@SqlUpdate("""
			DELETE FROM dataimporter_notifications_dates
				 WHERE party_id = :partyId
				   AND family_type=:familyType
				   AND fl_version = :flVersion""")
	void delete(@Bind("partyId") long partyId, @Bind("familyType") String familyType, @Bind("flVersion") String flVersion);

}
