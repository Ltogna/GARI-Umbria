package com.abacogroup.gari.dataimporter.services;

import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.util.List;

import com.abacogroup.gari.dataimporter.DTOs.ImportType;
import com.abacogroup.gari.dataimporter.DTOs.LoggerResponse;
import com.abacogroup.gari.dataimporter.db.dao.TrackRequestDAO;
import com.abacogroup.gari.dataimporter.db.ntt.TrackRequestNTT;
import com.abacogroup.gari.dataimporter.utils.ULIDGenerator;

public class TrackRequestService {

	private final TrackRequestDAO trackRequestDAO;

	public TrackRequestService(TrackRequestDAO trackRequestDAO) {
		this.trackRequestDAO = trackRequestDAO;
	}

	public TrackRequestNTT createTrackRequest(String tenant, String cuaa, String campagna, String flStatus, ImportType importType) {
		try {
			if (campagna == null) {
				campagna = String.valueOf(LocalDate.now().getYear());
			}
			String requestId = ULIDGenerator.generateULID();
			TrackRequestNTT trackRequest = TrackRequestNTT.builder()
					.requestId(requestId)
					.userId(tenant + "/IMPORT_SERVICE_ACCOUNT")
					.cuaa(cuaa)
					.campagna(campagna)
					.dtRequest(OffsetDateTime.now())
					.flStatus(flStatus)
					.importType(importType.getValue())
					.build();
			trackRequestDAO.insert(trackRequest);
			return trackRequest;
		} catch (Exception e) {
			throw new RuntimeException(e);
		}

	}

	public Integer updateStatus(String requestId, String status) {
		try {
			return trackRequestDAO.updateStatus(requestId, status);
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	public TrackRequestNTT findByIdAndCuaaAndTenant(String requestId, String cuaa, String tenant, ImportType importType) {
		// List<LoggerNTT> filteredLoggers = trackRequestDAO.findLoggersWithDifferentObjectRequest(requestId);
		TrackRequestNTT trackRequest = trackRequestDAO.findByIdAndCuaaAndTenant(requestId, cuaa, tenant, importType.getValue());
		// if (filteredLoggers != null && !filteredLoggers.isEmpty()) {
		// trackRequest.setLoggers(filteredLoggers);
		// } else {
		// trackRequest.setLoggers(List.of());
		// }
		return trackRequest;
	}

	public LoggerResponse findLogByIdAndCuaaAndTenant(String requestId, String cuaa, String tenant, ImportType importType) {
		var logs = trackRequestDAO.findLoggersWithDifferentObjectRequest(requestId);
		LoggerResponse response = new LoggerResponse();
		if (logs != null && !logs.isEmpty()) {
			var log = logs.stream().findFirst().orElse(null);
			response.setResponse_body(log.getResponse_body());
			response.setRequest_id(log.getRequest_id());
			response.setRequest_time(log.getRequest_time() != null ? log.getRequest_time().toString() : null);
		}
		return response;
	}

	public List<TrackRequestNTT> findBySatusAndCuaaAndTenant(String cuaa, String tenant, boolean onlyPending, ImportType importType) {
		return trackRequestDAO.findBySatusAndCuaaAndTenant(cuaa, tenant, onlyPending, importType.getValue());
	}
}
