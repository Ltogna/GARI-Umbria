package com.abacogroup.gari.dataimporter.queues;

import com.abacogroup.embeddedqueue.QueueErrorListener;
import com.abacogroup.embeddedqueue.ThrowingConsumer;
import com.abacogroup.gari.dataimporter.services.ImportPartyCreditService;
import com.abacogroup.gari.dataimporter.services.TrackRequestService;

public class ImportPartyCreditsConsumer implements ThrowingConsumer<ImportJobService>, QueueErrorListener<ImportJobService> {

	private final ImportPartyCreditService importPartyCreditService;
	private final TrackRequestService trackRequestService;

	public ImportPartyCreditsConsumer(ImportPartyCreditService _importPartyCreditService, TrackRequestService trackRequestService) {
		this.importPartyCreditService = _importPartyCreditService;
		this.trackRequestService = trackRequestService;
	}

	@Override
	public void accept(ImportJobService job) throws Exception {
		importPartyCreditService.ImportPartyCredits(job.getTenantId(), job.getCuaa());
		trackRequestService.updateStatus(job.getRequestId(), "DONE");
	}

	@Override
	public ErrorAction onJobError(ImportJobService job, Throwable t) {
		trackRequestService.updateStatus(job.getRequestId(), "ERROR");
		return ErrorAction.MARK_AS_ERRORED;
	}

}
