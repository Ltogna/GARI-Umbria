
package com.abacogroup.gari.dataimporter.soap.fascicolo;

import java.util.ArrayList;
import java.util.List;
import jakarta.xml.bind.JAXBElement;
import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlElementRef;
import jakarta.xml.bind.annotation.XmlRootElement;
import jakarta.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="CUAADichiarante" type="{http://cooperazione.sian.it/schema/fascicolo}Cuaa"/&gt;
 *         &lt;element name="Fattispecie" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;length value="3"/&gt;
 *               &lt;enumeration value="289"/&gt;
 *               &lt;enumeration value="203"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="Documenti" type="{http://cooperazione.sian.it/schema/fascicolo}WSDocuFasc" maxOccurs="unbounded"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "cuaaDichiarante",
    "fattispecie",
    "documenti"
})
@XmlRootElement(name = "DocuFascicolo")
public class DocuFascicolo {

    @XmlElement(name = "CUAADichiarante", required = true)
    protected String cuaaDichiarante;
    @XmlElementRef(name = "Fattispecie", namespace = "http://cooperazione.sian.it/schema/fascicolo", type = JAXBElement.class, required = false)
    protected JAXBElement<String> fattispecie;
    @XmlElement(name = "Documenti", required = true)
    protected List<WSDocuFasc> documenti;

    /**
     * Gets the value of the cuaaDichiarante property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCUAADichiarante() {
        return cuaaDichiarante;
    }

    /**
     * Sets the value of the cuaaDichiarante property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCUAADichiarante(String value) {
        this.cuaaDichiarante = value;
    }

    /**
     * Gets the value of the fattispecie property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getFattispecie() {
        return fattispecie;
    }

    /**
     * Sets the value of the fattispecie property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setFattispecie(JAXBElement<String> value) {
        this.fattispecie = value;
    }

    /**
     * Gets the value of the documenti property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the Jakarta XML Binding object.
     * This is why there is not a <CODE>set</CODE> method for the documenti property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getDocumenti().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link WSDocuFasc }
     * 
     * 
     */
    public List<WSDocuFasc> getDocumenti() {
        if (documenti == null) {
            documenti = new ArrayList<WSDocuFasc>();
        }
        return this.documenti;
    }

}
