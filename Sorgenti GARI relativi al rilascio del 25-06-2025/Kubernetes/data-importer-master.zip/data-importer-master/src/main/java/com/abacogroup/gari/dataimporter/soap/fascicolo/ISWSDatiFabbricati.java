
package com.abacogroup.gari.dataimporter.soap.fascicolo;

import java.util.ArrayList;
import java.util.List;
import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlRootElement;
import jakarta.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="CUAA" type="{http://cooperazione.sian.it/schema/fascicolo}Cuaa"/&gt;
 *         &lt;element name="DatiFabbricati" type="{http://cooperazione.sian.it/schema/fascicolo}ISWSFabbricato" maxOccurs="unbounded" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "cuaa",
    "datiFabbricati"
})
@XmlRootElement(name = "ISWSDatiFabbricati")
public class ISWSDatiFabbricati {

    @XmlElement(name = "CUAA", required = true)
    protected String cuaa;
    @XmlElement(name = "DatiFabbricati", nillable = true)
    protected List<ISWSFabbricato> datiFabbricati;

    /**
     * Gets the value of the cuaa property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCUAA() {
        return cuaa;
    }

    /**
     * Sets the value of the cuaa property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCUAA(String value) {
        this.cuaa = value;
    }

    /**
     * Gets the value of the datiFabbricati property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the Jakarta XML Binding object.
     * This is why there is not a <CODE>set</CODE> method for the datiFabbricati property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getDatiFabbricati().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ISWSFabbricato }
     * 
     * 
     */
    public List<ISWSFabbricato> getDatiFabbricati() {
        if (datiFabbricati == null) {
            datiFabbricati = new ArrayList<ISWSFabbricato>();
        }
        return this.datiFabbricati;
    }

}
