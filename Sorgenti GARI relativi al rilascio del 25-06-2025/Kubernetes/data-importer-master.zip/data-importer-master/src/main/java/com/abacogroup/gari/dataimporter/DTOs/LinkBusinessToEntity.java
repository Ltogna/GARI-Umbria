package com.abacogroup.gari.dataimporter.DTOs;

import java.time.LocalDate;

import com.abacogroup.jdbi.datatype.AbsoluteDate;

import lombok.Data;

@Data
public class LinkBusinessToEntity {
    private Long id;
    private String party_type_code;
    private AbsoluteDate day_from = AbsoluteDate.of(LocalDate.now());
    private AbsoluteDate day_to = AbsoluteDate.of("99991231");

    public LinkBusinessToEntity(Long partyId, String partyTypeCode) {
        this.id = partyId;
        this.party_type_code = partyTypeCode;
    }
}
