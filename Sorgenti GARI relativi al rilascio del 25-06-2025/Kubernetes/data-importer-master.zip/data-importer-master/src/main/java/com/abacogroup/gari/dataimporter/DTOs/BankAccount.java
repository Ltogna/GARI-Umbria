package com.abacogroup.gari.dataimporter.DTOs;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@JsonIgnoreProperties(ignoreUnknown = true)
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class BankAccount {
	private String description;
	private boolean defaultBankAccount;
	private String network;
	private String iban;
	private String swiftBic;
	private String bicExtraSepa;
	private String bankCountry;
	private String bankName;
	private String bankBranch;
	private String dayFrom;
}
