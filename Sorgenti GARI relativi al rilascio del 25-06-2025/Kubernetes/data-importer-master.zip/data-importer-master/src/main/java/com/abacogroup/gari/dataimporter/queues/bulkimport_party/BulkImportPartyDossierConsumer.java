package com.abacogroup.gari.dataimporter.queues.bulkimport_party;

import com.abacogroup.embeddedqueue.QueueErrorListener;
import com.abacogroup.embeddedqueue.ThrowingConsumer;
import com.abacogroup.embeddedqueue.WorkQueue;
import com.abacogroup.gari.dataimporter.services.BulkImportPartyLoadService;
import com.abacogroup.gari.dataimporter.services.BulkImportPartyService;

public class BulkImportPartyDossierConsumer implements ThrowingConsumer<String>, QueueErrorListener<String> {

	private final BulkImportPartyService service;
	private final BulkImportPartyLoadService loadService;
	private final WorkQueue<String> nextQueue;
	private final int step;

	public BulkImportPartyDossierConsumer(BulkImportPartyService service, BulkImportPartyLoadService loadService,
			WorkQueue<String> nextQueue, int step) {
		this.service = service;
		this.loadService = loadService;
		this.nextQueue = nextQueue;
		this.step = step;
	}

	@Override
	public void accept(String id) throws Exception {
		service.createDossier(id);
		loadService.updateStatusAndStep(id, BulkImportPartyLoadService.STATUS_PENDING, step);
		nextQueue.add(id, System.currentTimeMillis());
	}

	@Override
	public QueueErrorListener.ErrorAction onJobError(String id, Throwable t) {
		loadService.updateStatusAndStep(id, BulkImportPartyLoadService.STATUS_ERROR, step - 1);
		return ErrorAction.MARK_AS_ERRORED;
	}

}
