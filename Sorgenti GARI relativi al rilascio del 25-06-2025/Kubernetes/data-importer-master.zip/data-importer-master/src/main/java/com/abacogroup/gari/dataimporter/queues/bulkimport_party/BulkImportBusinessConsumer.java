package com.abacogroup.gari.dataimporter.queues.bulkimport_party;

import com.abacogroup.embeddedqueue.QueueErrorListener;
import com.abacogroup.embeddedqueue.ThrowingConsumer;
import com.abacogroup.embeddedqueue.WorkQueue;
import com.abacogroup.gari.dataimporter.services.BulkImportPartyLoadService;
import com.abacogroup.gari.dataimporter.services.BulkImportPartyService;

public class BulkImportBusinessConsumer implements ThrowingConsumer<String>, QueueErrorListener<String> {

	private final BulkImportPartyLoadService loadService;
	private final BulkImportPartyService service;
	private final WorkQueue<String> nextQueue;
	private final int step;

	public BulkImportBusinessConsumer(BulkImportPartyLoadService loadService, BulkImportPartyService service, WorkQueue<String> nextQueue, int step) {
		this.loadService = loadService;
		this.service = service;
		this.nextQueue = nextQueue;
		this.step = step;
	}

	@Override
	public void accept(String id) throws Exception {
		service.importCuaaBulk(id);
		loadService.updateStatusAndStep(id, BulkImportPartyLoadService.STATUS_PENDING, step);
		nextQueue.add(id, System.currentTimeMillis());
	}

	@Override
	public ErrorAction onJobError(String id, Throwable t) {
		loadService.updateStatusAndStep(id, BulkImportPartyLoadService.STATUS_ERROR, step - 1);
		return ErrorAction.MARK_AS_ERRORED;
	}

}
