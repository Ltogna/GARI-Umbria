
package com.abacogroup.gari.dataimporter.soap.fascicolo;

import java.util.ArrayList;
import java.util.List;
import jakarta.xml.bind.JAXBElement;
import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlElementRef;
import jakarta.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ISWSUtilizzoTerra15 complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ISWSUtilizzoTerra15"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="codiceMacrouso"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;length value="3"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="codiceQualita"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;length value="3"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="superficieUtilizzata"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}int"&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="superficieEligibile" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}int"&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="superficieEligibileOP" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}int"&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="DataInizioUtilizzo" type="{http://cooperazione.sian.it/schema/fascicolo}Data"/&gt;
 *         &lt;element name="DataFineUtilizzo" type="{http://cooperazione.sian.it/schema/fascicolo}Data"/&gt;
 *         &lt;element name="Dettagli" type="{http://cooperazione.sian.it/schema/fascicolo}ISWSDettaglioUtilizzoTerra15" maxOccurs="unbounded" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ISWSUtilizzoTerra15", propOrder = {
    "codiceMacrouso",
    "codiceQualita",
    "superficieUtilizzata",
    "superficieEligibile",
    "superficieEligibileOP",
    "dataInizioUtilizzo",
    "dataFineUtilizzo",
    "dettagli"
})
public class ISWSUtilizzoTerra15 {

    @XmlElement(required = true)
    protected String codiceMacrouso;
    @XmlElement(required = true)
    protected String codiceQualita;
    protected int superficieUtilizzata;
    @XmlElementRef(name = "superficieEligibile", namespace = "http://cooperazione.sian.it/schema/fascicolo", type = JAXBElement.class, required = false)
    protected JAXBElement<Integer> superficieEligibile;
    @XmlElementRef(name = "superficieEligibileOP", namespace = "http://cooperazione.sian.it/schema/fascicolo", type = JAXBElement.class, required = false)
    protected JAXBElement<Integer> superficieEligibileOP;
    @XmlElement(name = "DataInizioUtilizzo", required = true)
    protected String dataInizioUtilizzo;
    @XmlElement(name = "DataFineUtilizzo", required = true, nillable = true)
    protected String dataFineUtilizzo;
    @XmlElement(name = "Dettagli", nillable = true)
    protected List<ISWSDettaglioUtilizzoTerra15> dettagli;

    /**
     * Gets the value of the codiceMacrouso property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodiceMacrouso() {
        return codiceMacrouso;
    }

    /**
     * Sets the value of the codiceMacrouso property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodiceMacrouso(String value) {
        this.codiceMacrouso = value;
    }

    /**
     * Gets the value of the codiceQualita property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodiceQualita() {
        return codiceQualita;
    }

    /**
     * Sets the value of the codiceQualita property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodiceQualita(String value) {
        this.codiceQualita = value;
    }

    /**
     * Gets the value of the superficieUtilizzata property.
     * 
     */
    public int getSuperficieUtilizzata() {
        return superficieUtilizzata;
    }

    /**
     * Sets the value of the superficieUtilizzata property.
     * 
     */
    public void setSuperficieUtilizzata(int value) {
        this.superficieUtilizzata = value;
    }

    /**
     * Gets the value of the superficieEligibile property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Integer }{@code >}
     *     
     */
    public JAXBElement<Integer> getSuperficieEligibile() {
        return superficieEligibile;
    }

    /**
     * Sets the value of the superficieEligibile property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Integer }{@code >}
     *     
     */
    public void setSuperficieEligibile(JAXBElement<Integer> value) {
        this.superficieEligibile = value;
    }

    /**
     * Gets the value of the superficieEligibileOP property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Integer }{@code >}
     *     
     */
    public JAXBElement<Integer> getSuperficieEligibileOP() {
        return superficieEligibileOP;
    }

    /**
     * Sets the value of the superficieEligibileOP property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Integer }{@code >}
     *     
     */
    public void setSuperficieEligibileOP(JAXBElement<Integer> value) {
        this.superficieEligibileOP = value;
    }

    /**
     * Gets the value of the dataInizioUtilizzo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDataInizioUtilizzo() {
        return dataInizioUtilizzo;
    }

    /**
     * Sets the value of the dataInizioUtilizzo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDataInizioUtilizzo(String value) {
        this.dataInizioUtilizzo = value;
    }

    /**
     * Gets the value of the dataFineUtilizzo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDataFineUtilizzo() {
        return dataFineUtilizzo;
    }

    /**
     * Sets the value of the dataFineUtilizzo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDataFineUtilizzo(String value) {
        this.dataFineUtilizzo = value;
    }

    /**
     * Gets the value of the dettagli property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the Jakarta XML Binding object.
     * This is why there is not a <CODE>set</CODE> method for the dettagli property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getDettagli().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ISWSDettaglioUtilizzoTerra15 }
     * 
     * 
     */
    public List<ISWSDettaglioUtilizzoTerra15> getDettagli() {
        if (dettagli == null) {
            dettagli = new ArrayList<ISWSDettaglioUtilizzoTerra15>();
        }
        return this.dettagli;
    }

}
