package com.abacogroup.gari.dataimporter.db.dao;

import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.customizer.BindBean;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;
import org.jdbi.v3.sqlobject.transaction.Transactional;

import com.abacogroup.gari.dataimporter.db.ntt.NotificationsNTT;

@RegisterBeanMapper(NotificationsNTT.class)
public interface NotificationsDAO extends Transactional<NotificationsDAO> {

	@SqlUpdate("""
			INSERT INTO dataimporter_notifications (uid, party_id, dt_sent, dt_response, response_payload, family_type, fl_version)
			VALUES (:uid, :partyId, :dtSent, :dtResponse, :responsePayload, :familyType, :flVersion)""")
	void insert(@BindBean NotificationsNTT notification);

	@SqlQuery("SELECT * FROM dataimporter_notifications WHERE uid = :uid")
	NotificationsNTT findById(@Bind("uid") String uid);

	// Actions
	@SqlUpdate("""
			UPDATE dataimporter_notifications
			SET dt_response = §current_timestamp§, response_payload = :responsePayload
			WHERE uid = :uid""")
	int updateResponse(@Bind("uid") String uid, @Bind("responsePayload") String responsePayload);

	@SqlUpdate("UPDATE dataimporter_notifications SET dt_sent = §current_timestamp§ WHERE uid = :uid")
	int updateDT_Sent(@Bind("uid") String uid);

	@SqlQuery("SELECT * FROM dataimporter_notifications WHERE uid = :uid")
	NotificationsNTT findNotificationByUid(@Bind("uid") String uid);

	@SqlUpdate("DELETE FROM dataimporter_notifications WHERE uid = :uid")
	void delete(@Bind("uid") String ulid);

}
