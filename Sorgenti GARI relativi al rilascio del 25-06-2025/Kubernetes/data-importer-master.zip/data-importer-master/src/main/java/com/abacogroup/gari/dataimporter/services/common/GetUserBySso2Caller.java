package com.abacogroup.gari.dataimporter.services.common;

import com.abacogroup.gari.dataimporter.DTOs.GetUserByTenant;
import com.abacogroup.gari.dataimporter.DTOs.UserDetails;
import com.abacogroup.jaxrsutils.GenericCallerService;
import com.abacogroup.jaxrsutils.callerv2.AbacoDtoCaller;

/**
 * 
 * @author Emanuele Crocilla
 *
 */
public class GetUserBySso2Caller extends AbacoDtoCaller<GetUserByTenant, UserDetails> {

	public GetUserBySso2Caller(GenericCallerService genericCallerService) {
		super(genericCallerService);
	}

}
