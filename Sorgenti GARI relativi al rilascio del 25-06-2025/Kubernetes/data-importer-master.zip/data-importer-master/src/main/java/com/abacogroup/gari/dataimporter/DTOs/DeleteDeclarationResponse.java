package com.abacogroup.gari.dataimporter.DTOs;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class DeleteDeclarationResponse {

	private List<String> validationMessages;
	private Object declaration; // Replace Object with actual declaration class if known
}
