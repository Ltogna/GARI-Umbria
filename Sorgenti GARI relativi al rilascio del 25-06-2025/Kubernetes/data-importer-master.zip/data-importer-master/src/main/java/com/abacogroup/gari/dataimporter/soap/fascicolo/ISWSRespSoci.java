
package com.abacogroup.gari.dataimporter.soap.fascicolo;

import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ISWSRespSoci complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ISWSRespSoci"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="CuaaSocio" type="{http://cooperazione.sian.it/schema/fascicolo}Cuaa"/&gt;
 *         &lt;element name="DenomSocio"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;minLength value="1"/&gt;
 *               &lt;maxLength value="150"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="DataInizioAsso" type="{http://cooperazione.sian.it/schema/fascicolo}Data"/&gt;
 *         &lt;element name="DataFineAsso" type="{http://cooperazione.sian.it/schema/fascicolo}Data"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ISWSRespSoci", propOrder = {
    "cuaaSocio",
    "denomSocio",
    "dataInizioAsso",
    "dataFineAsso"
})
public class ISWSRespSoci {

    @XmlElement(name = "CuaaSocio", required = true)
    protected String cuaaSocio;
    @XmlElement(name = "DenomSocio", required = true)
    protected String denomSocio;
    @XmlElement(name = "DataInizioAsso", required = true)
    protected String dataInizioAsso;
    @XmlElement(name = "DataFineAsso", required = true)
    protected String dataFineAsso;

    /**
     * Gets the value of the cuaaSocio property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCuaaSocio() {
        return cuaaSocio;
    }

    /**
     * Sets the value of the cuaaSocio property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCuaaSocio(String value) {
        this.cuaaSocio = value;
    }

    /**
     * Gets the value of the denomSocio property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDenomSocio() {
        return denomSocio;
    }

    /**
     * Sets the value of the denomSocio property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDenomSocio(String value) {
        this.denomSocio = value;
    }

    /**
     * Gets the value of the dataInizioAsso property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDataInizioAsso() {
        return dataInizioAsso;
    }

    /**
     * Sets the value of the dataInizioAsso property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDataInizioAsso(String value) {
        this.dataInizioAsso = value;
    }

    /**
     * Gets the value of the dataFineAsso property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDataFineAsso() {
        return dataFineAsso;
    }

    /**
     * Sets the value of the dataFineAsso property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDataFineAsso(String value) {
        this.dataFineAsso = value;
    }

}
