
package com.abacogroup.gari.dataimporter.soap.fascicolo;

import java.math.BigDecimal;
import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ISWS_OTE_CS complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ISWS_OTE_CS"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="codiRUAP" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="DescrizioneRUAP" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="UnitaMisuraRUAP" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="Superficie"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}decimal"&gt;
 *               &lt;totalDigits value="18"/&gt;
 *               &lt;fractionDigits value="2"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="Capi" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="ImpProduzione"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}decimal"&gt;
 *               &lt;totalDigits value="18"/&gt;
 *               &lt;fractionDigits value="2"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="FlagAttiPrev" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ISWS_OTE_CS", propOrder = {
    "codiRUAP",
    "descrizioneRUAP",
    "unitaMisuraRUAP",
    "superficie",
    "capi",
    "impProduzione",
    "flagAttiPrev"
})
public class ISWSOTECS {

    @XmlElement(required = true, nillable = true)
    protected String codiRUAP;
    @XmlElement(name = "DescrizioneRUAP", required = true, nillable = true)
    protected String descrizioneRUAP;
    @XmlElement(name = "UnitaMisuraRUAP", required = true, nillable = true)
    protected String unitaMisuraRUAP;
    @XmlElement(name = "Superficie", required = true, nillable = true)
    protected BigDecimal superficie;
    @XmlElement(name = "Capi", required = true, nillable = true)
    protected String capi;
    @XmlElement(name = "ImpProduzione", required = true, nillable = true)
    protected BigDecimal impProduzione;
    @XmlElement(name = "FlagAttiPrev", required = true, nillable = true)
    protected String flagAttiPrev;

    /**
     * Gets the value of the codiRUAP property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodiRUAP() {
        return codiRUAP;
    }

    /**
     * Sets the value of the codiRUAP property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodiRUAP(String value) {
        this.codiRUAP = value;
    }

    /**
     * Gets the value of the descrizioneRUAP property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDescrizioneRUAP() {
        return descrizioneRUAP;
    }

    /**
     * Sets the value of the descrizioneRUAP property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDescrizioneRUAP(String value) {
        this.descrizioneRUAP = value;
    }

    /**
     * Gets the value of the unitaMisuraRUAP property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUnitaMisuraRUAP() {
        return unitaMisuraRUAP;
    }

    /**
     * Sets the value of the unitaMisuraRUAP property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUnitaMisuraRUAP(String value) {
        this.unitaMisuraRUAP = value;
    }

    /**
     * Gets the value of the superficie property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getSuperficie() {
        return superficie;
    }

    /**
     * Sets the value of the superficie property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setSuperficie(BigDecimal value) {
        this.superficie = value;
    }

    /**
     * Gets the value of the capi property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCapi() {
        return capi;
    }

    /**
     * Sets the value of the capi property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCapi(String value) {
        this.capi = value;
    }

    /**
     * Gets the value of the impProduzione property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getImpProduzione() {
        return impProduzione;
    }

    /**
     * Sets the value of the impProduzione property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setImpProduzione(BigDecimal value) {
        this.impProduzione = value;
    }

    /**
     * Gets the value of the flagAttiPrev property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFlagAttiPrev() {
        return flagAttiPrev;
    }

    /**
     * Sets the value of the flagAttiPrev property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFlagAttiPrev(String value) {
        this.flagAttiPrev = value;
    }

}
