package com.abacogroup.gari.dataimporter.DTOs;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
public class CropPlanResponse {
	@JsonProperty("cropPlanId")
	private int cropPlanId;

	@JsonProperty("cropPlanTypeCode")
	private String cropPlanTypeCode;

	@JsonProperty("cropPlanTypeDescription")
	private String cropPlanTypeDescription;

	@JsonProperty("description")
	private String description;

	@JsonProperty("changesPending")
	private boolean changesPending;

	@JsonProperty("readOnly")
	private boolean readOnly;

	@JsonProperty("locked")
	private boolean locked;

	@JsonProperty("lockedErrorCode")
	private String lockedErrorCode;

	@JsonProperty("canAddPlots")
	private boolean canAddPlots;

	@JsonProperty("cropPlanPrints")
	private List<CropPlanPrint> cropPlanPrints;

	// Getters and setters
	public int getCropPlanId() {
		return cropPlanId;
	}

	public void setCropPlanId(int cropPlanId) {
		this.cropPlanId = cropPlanId;
	}

	public String getCropPlanTypeCode() {
		return cropPlanTypeCode;
	}

	public void setCropPlanTypeCode(String cropPlanTypeCode) {
		this.cropPlanTypeCode = cropPlanTypeCode;
	}

	public String getCropPlanTypeDescription() {
		return cropPlanTypeDescription;
	}

	public void setCropPlanTypeDescription(String cropPlanTypeDescription) {
		this.cropPlanTypeDescription = cropPlanTypeDescription;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public boolean isChangesPending() {
		return changesPending;
	}

	public void setChangesPending(boolean changesPending) {
		this.changesPending = changesPending;
	}

	public boolean isReadOnly() {
		return readOnly;
	}

	public void setReadOnly(boolean readOnly) {
		this.readOnly = readOnly;
	}

	public boolean isLocked() {
		return locked;
	}

	public void setLocked(boolean locked) {
		this.locked = locked;
	}

	public String getLockedErrorCode() {
		return lockedErrorCode;
	}

	public void setLockedErrorCode(String lockedErrorCode) {
		this.lockedErrorCode = lockedErrorCode;
	}

	public boolean isCanAddPlots() {
		return canAddPlots;
	}

	public void setCanAddPlots(boolean canAddPlots) {
		this.canAddPlots = canAddPlots;
	}

	public List<CropPlanPrint> getCropPlanPrints() {
		return cropPlanPrints;
	}

	public void setCropPlanPrints(List<CropPlanPrint> cropPlanPrints) {
		this.cropPlanPrints = cropPlanPrints;
	}

	// Inner class representing cropPlanPrints array items
	@JsonIgnoreProperties(ignoreUnknown = true)
	public static class CropPlanPrint {

		@JsonProperty("code")
		private String code;

		@JsonProperty("description")
		private String description;

		// Getters and setters
		public String getCode() {
			return code;
		}

		public void setCode(String code) {
			this.code = code;
		}

		public String getDescription() {
			return description;
		}

		public void setDescription(String description) {
			this.description = description;
		}
	}
}
