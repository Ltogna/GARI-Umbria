package com.abacogroup.gari.dataimporter.DTOs;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.OffsetDateTime;

@JsonIgnoreProperties(ignoreUnknown = true)
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class DossierDataDTO {

	@JsonProperty("partyId")
	private Long partyId;

	@JsonProperty("year")
	private Integer year;

	@JsonProperty("sectorCode")
	private String sectorCode;

	@JsonProperty("sectorDescription")
	private String sectorDescription;

	@JsonProperty("moduleCode")
	private String moduleCode;

	@JsonProperty("moduleDescription")
	private String moduleDescription;

	@JsonProperty("dossierId")
	private Long dossierId;

	@JsonProperty("dossierCode")
	private String dossierCode;

	@JsonProperty("processStatus")
	private String processStatus;

	@JsonProperty("processStatusDescription")
	private String processStatusDescription;

	@JsonProperty("dtClosed")
	private OffsetDateTime dtClosed;

	@JsonProperty("flAmendable")
	private Boolean flAmendable;
}
