package com.abacogroup.gari.dataimporter.db.dao;

import com.abacogroup.gari.dataimporter.db.ntt.ZvnCatalogNTT;
import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.customizer.BindBean;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;

import java.util.List;

@RegisterBeanMapper(ZvnCatalogNTT.class)
public interface ZvnCatalogDAO {

	@SqlUpdate("INSERT INTO dataimporter_zvn_catalog (area, id_rec, regione, nome_zvn, type, geom, tracking_request_id) " +
			"VALUES (:area, :idRec, :regione, :nomeZvn, :type, :geom, :trackingRequestId)")
	void insert(@BindBean ZvnCatalogNTT zvnCatalog);

	@SqlQuery("SELECT * FROM dataimporter_zvn_catalog WHERE id = :id")
	ZvnCatalogNTT findById(@Bind("id") Long id);

	@SqlQuery("SELECT * FROM dataimporter_zvn_catalog WHERE id_rec = :id_rec")
	ZvnCatalogNTT findByIdRec(@Bind("id_rec") Long idRec);

	@SqlQuery("SELECT EXISTS (SELECT 1 FROM dataimporter_zvn_catalog WHERE id_rec = :id_rec)")
	boolean existsByIdRec(@Bind("id_rec") Long idRec);

	@SqlQuery("SELECT * FROM dataimporter_zvn_catalog WHERE tracking_request_id = :trackingRequestId")
	List<ZvnCatalogNTT> findByTrackingRequestId(@Bind("trackingRequestId") String trackingRequestId);

	@SqlUpdate("UPDATE dataimporter_zvn_catalog SET area = :area, id_rec = :idRec, regione = :regione, " +
			"nome_zvn = :nomeZvn, type = :type, geom = :geom " +
			"WHERE id = :id")
	int update(@BindBean ZvnCatalogNTT zvnCatalog);

	@SqlUpdate("DELETE FROM dataimporter_zvn_catalog WHERE id = :id")
	int delete(@Bind("id") Long id);
}
