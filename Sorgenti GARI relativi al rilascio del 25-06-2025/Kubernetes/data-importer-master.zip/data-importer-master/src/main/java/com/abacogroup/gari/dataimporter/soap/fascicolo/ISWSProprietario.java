
package com.abacogroup.gari.dataimporter.soap.fascicolo;

import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ISWSProprietario complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ISWSProprietario"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="proprietario" type="{http://cooperazione.sian.it/schema/fascicolo}Proprietario"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ISWSProprietario", propOrder = {
    "proprietario"
})
public class ISWSProprietario {

    @XmlElement(required = true)
    protected String proprietario;

    /**
     * Gets the value of the proprietario property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProprietario() {
        return proprietario;
    }

    /**
     * Sets the value of the proprietario property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProprietario(String value) {
        this.proprietario = value;
    }

}
