package com.abacogroup.gari.dataimporter.DTOs;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class GiasTokenResponse {

	@JsonProperty("RispostaOK")
	private boolean rispostaOK;

	@JsonProperty("RispostaStringa")
	private String rispostaStringa;
}