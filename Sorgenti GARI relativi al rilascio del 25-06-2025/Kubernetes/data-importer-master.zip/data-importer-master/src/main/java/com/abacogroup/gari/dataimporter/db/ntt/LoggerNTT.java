package com.abacogroup.gari.dataimporter.db.ntt;

import java.time.OffsetDateTime;
import java.util.Optional;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.NoArgsConstructor;

@Builder
@NoArgsConstructor
@AllArgsConstructor
public class LoggerNTT implements IIdRs<Long> {
	private Long pkid;
	private OffsetDateTime request_time;
	private String user;
	private String url;
	private String cuaa_code;
	private Integer http_status;
	private String response_body;
	private String method_name;
	private String object_request;
	private String request_id;

	public Long getPkid() {
		return pkid;
	}

	public void setPkid(Long pkid) {
		this.pkid = pkid;
	}

	public OffsetDateTime getRequest_time() {
		return request_time;
	}

	public void setRequest_time(OffsetDateTime request_time) {
		this.request_time = request_time;
	}

	public String getUser() {
		return user;
	}
	public void setUser(String user) {
		this.user = user;
	}

	public void setRequest_id(String requestId) {
		this.request_id = requestId;
	}
	public String getRequest_id() {
		return request_id;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public Integer getHttp_status() {
		return http_status;
	}

	public void setHttp_status(Integer http_status) {
		this.http_status = http_status;
	}

	public String getCuaa_code() {
		return cuaa_code;
	}

	public void setCuaa_code(String cuaa_code) {
		this.cuaa_code = cuaa_code;
	}

	public String getResponse_body() {
		return response_body;
	}

	public void setResponse_body(String response_body) {
		this.response_body = response_body;
	}

	public String getMethod_name() {
		return method_name;
	}

	public void setMethod_name(String method_name) {
		this.method_name = method_name;
	}

	public String getObject_request() {
		return object_request;
	}

	public void setObject_request(String object_request) {
		this.object_request = object_request;
	}

	@Override
	public void setKey(Long id) {
		setPkid(id);
	}

	@Override
	public Optional<Long> getKey() {
		return Optional.ofNullable(getPkid());
	}

	public Boolean getFlOrganicFertBool() {
		return true;
	}

}
