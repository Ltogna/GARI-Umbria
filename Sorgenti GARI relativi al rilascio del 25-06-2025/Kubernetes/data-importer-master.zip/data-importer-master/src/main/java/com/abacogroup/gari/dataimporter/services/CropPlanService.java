package com.abacogroup.gari.dataimporter.services;

import com.abacogroup.dropwizard.auth.sso2.Sso2Client;
import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.gari.dataimporter.DTOs.*;
import com.abacogroup.gari.dataimporter.DTOs.AnagraficaResponse.Mandato;
import com.abacogroup.gari.dataimporter.DTOs.FeaturesResponse.Feature;
import com.abacogroup.gari.dataimporter.DTOs.FeaturesResponse.Properties;
import com.abacogroup.gari.dataimporter.DTOs.PCGCropPlanResponse.Declaration;
import com.abacogroup.gari.dataimporter.DTOs.PCGCropPlanResponse.GIS;
import com.abacogroup.gari.dataimporter.DTOs.PlotDataResponse.AdditionalField;
import com.abacogroup.gari.dataimporter.DataImporterConfiguration;
import com.abacogroup.gari.dataimporter.Interfaces.ICropPlanService;
import com.abacogroup.gari.dataimporter.db.dao.LoggerDAO;
import com.abacogroup.gari.dataimporter.db.ntt.LoggerNTT;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.jdbi.paging.impl.InfiniteListResultsImpl;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.ws.rs.client.Client;
import jakarta.ws.rs.core.GenericType;
import jakarta.ws.rs.core.MediaType;
import lombok.extern.slf4j.Slf4j;
import org.geojson.FeatureCollection;
import org.locationtech.jts.geom.Geometry;
import org.locationtech.jts.geom.GeometryFactory;
import org.locationtech.jts.io.ParseException;
import org.locationtech.jts.io.geojson.GeoJsonReader;

import java.io.IOException;
import java.lang.reflect.Field;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicReference;
import java.util.function.Function;
import java.util.stream.Collectors;

@Slf4j
public class CropPlanService extends ADataImporterService implements ICropPlanService {
	private static final DateTimeFormatter FORMATTER = DateTimeFormatter.ofPattern("dd/MM/yyyy");
	private static final DateTimeFormatter SHORTSTRINGDATEFORMATTER = DateTimeFormatter.ofPattern("yyyyMMdd");
	private static List<FieldDefinition> fieldDefinitions;
	private static List<FieldDefinition> fieldDefinitionsProperties;

	public CropPlanService(Sso2Client sso2Client, Client client, DataImporterConfiguration configuration,
			ObjectMapper objectMapper, LoggerDAO loggerDAO) {
		super(sso2Client, client, configuration, objectMapper, loggerDAO);
		try {
			fieldDefinitions = loadFieldDefinitions("/fieldsConf.jsonl", "fieldsConf");
			fieldDefinitionsProperties = loadFieldDefinitions("/fieldsConfFeature.jsonl", "fieldsConfFeature");
		} catch (IOException e) {
			throwDynamicException("", "", new Object(), "CropPlanService Constructor",
					"Not able to load Fields Cong file");
			throw new RuntimeException(e);
		}
	}

	public static String getFieldValueByCode(List<PlotDataResponse.AdditionalField> additionalFields,
			String wantedFieldCode) {
		if (additionalFields == null || wantedFieldCode == null || wantedFieldCode.isEmpty()) {
			return null;
		}
		for (PlotDataResponse.AdditionalField field : additionalFields) {
			if (wantedFieldCode.equals(field.getFieldCode())) {
				return field.getValue();
			}
		}
		return null;
	}

	public static PCGCropPlanResponse.DatiAggiuntiviPCG mapFieldCodesToDatiAggiuntiviPCG(
			List<PlotDataResponse.AdditionalField> fieldCodes) {
		PCGCropPlanResponse.DatiAggiuntiviPCG.DatiAggiuntiviPCGBuilder builder = PCGCropPlanResponse.DatiAggiuntiviPCG
				.builder();

		for (PlotDataResponse.AdditionalField fieldCode : fieldCodes) {
			String fieldCodeValue = fieldCode.getFieldCode();
			String value = fieldCode.getValue();
			String description = fieldCode.getFieldDescription();
			AbsoluteDate dayFrom = fieldCode.getDayFrom();
			switch (fieldCodeValue) {
				case "effluentiZootecnici":
					builder.zootechnicalEffluentsId(value == null ? null : "1")
							.zootechnicalEffluents(value == null ? null
									: createGenericType("ZootechicsalEffluents", value, description, dayFrom));
					break;
				case "potenzialitaIrrigua":
					builder.irrigationPotentialId(value == null ? null : "1")
							.irrigationPotential(value == null ? null
									: createGenericType("IrrigationPotential", value, description, dayFrom));
					break;
				case "struttureAziendali":
					builder.companyStructuresId(value == null ? null : "1")
							.companyStructures(value == null ? null
									: createGenericType("CompanyStructures", value, description, dayFrom));
					break;
				case "tipoDiSemina":
					builder.sowingTypeId(value == null ? null : "1")
							.sowingType(value == null ? null
									: createGenericType("SowingType", value, description, dayFrom));
					break;
				case "faseAllevamento":
					builder.breedingPhaseId(value == null ? null : "1")
							.breedingPhase(value == null ? null
									: createGenericType("BreedingPhase", value, description, dayFrom));
					break;
				case "formaDiAllevamento":
					builder.breedingFormId(value == null ? null : "1")
							.breedingForm(value == null ? null
									: createGenericType("BreedingForm", value, description, dayFrom));
					break;
				case "tipoDiAllevamento":
					builder.breedingTypeId(value == null ? null : "1")
							.breedingType(value == null ? null
									: createGenericType("BreedingType", value, description, dayFrom));
					break;
				case "tipoIrrigazione":
					builder.irrigationTypeId(value == null ? null : "1")
							.irrigationType(value == null ? null
									: createGenericType("IrrigationType", value, description, dayFrom));
					break;
				case "annoMese":
					builder.yearMonth(value);
					break;
				default:
					// Handle unexpected or unmapped field codes if necessary
					break;
			}
		}
		return builder.build();
	}

	private static PCGCropPlanResponse.GenericType createGenericType(String type, String code, String name,
			AbsoluteDate dayFrom) {
		return PCGCropPlanResponse.GenericType.builder()
				.type(type)
				.id("1")
				.code(null)
				.key(code)
				.name(name)
				.createdAt(dayFrom.toLocalDate())
				.updatedAt(dayFrom.toLocalDate())
				.deletedAt(null)
				.build();
	}

	// Load Code Fields
	public static String getFieldValue(FeaturesResponse.Coltivazione coltivazione, String fieldName) {
		try {
			Field field = FeaturesResponse.Coltivazione.class.getDeclaredField(fieldName);
			field.setAccessible(true);
			Object value = field.get(coltivazione);
			return value != null ? value.toString() : null;
		} catch (NoSuchFieldException | IllegalAccessException e) {
			e.printStackTrace();
			return "";
		}
	}

	// Load Code Fields
	public static String getFieldValueProperties(FeaturesResponse.Properties properties, String fieldName) {
		try {
			Field field = FeaturesResponse.Properties.class.getDeclaredField(fieldName);
			field.setAccessible(true);
			Object value = field.get(properties);
			return value != null ? value.toString() : null;
		} catch (NoSuchFieldException | IllegalAccessException e) {
			e.printStackTrace();
			return "";
		}
	}

	public static void setFieldValueByType(List<PlotDataResponse.AdditionalField> fieldCodes, String type,
			String newValue) {
		if (fieldCodes == null || type == null || type.isEmpty()) {
			return;
		}
		for (PlotDataResponse.AdditionalField fieldCode : fieldCodes) {
			if (type.equals(fieldCode.getFieldCode())) {
				fieldCode.setValue(newValue);
				return; // Stop iteration after updating the first match
			}
		}
	}

	public static InfiniteListResults<PlotDataResponse> mergePlotDataByPlotCode(List<PlotDataResponse> plots) {
		Map<String, PlotDataResponse> mergedMap = new HashMap<>();
		InfiniteListResultsImpl<PlotDataResponse> plotList = new InfiniteListResultsImpl<>();

		for (PlotDataResponse plot : plots) {
			String plotCode = plot.getPlotCode();

			if (plotCode == null || plotCode.trim().isEmpty())
				continue;

			if (!mergedMap.containsKey(plotCode)) {
				mergedMap.put(plotCode, plot);
			} else {
				PlotDataResponse existing = mergedMap.get(plotCode);

				if (plot.getFromDate() == null || plot.getToDate() == null ||
						existing.getFromDate() == null || existing.getToDate() == null) {

					mergedMap.put(plotCode, plot);
					continue;
				}
				LocalDate currentTo = plot.getToDate().toLocalDate();
				LocalDate existingTo = existing.getToDate().toLocalDate();
				boolean currentIsLater = currentTo.isAfter(existingTo);
				PlotDataResponse surviving = currentIsLater ? plot : existing;
				PlotDataResponse toDiscard = currentIsLater ? existing : plot;

				LocalDate survivingFrom = surviving.getFromDate().toLocalDate();
				LocalDate discardFrom = toDiscard.getFromDate().toLocalDate();

				LocalDate mergedFrom = survivingFrom.isBefore(discardFrom) ? survivingFrom : discardFrom;
				surviving.setFromDate(AbsoluteDate.of(mergedFrom));

				mergedMap.put(plotCode, surviving);
			}
		}

		plotList.setRecords(new ArrayList<>(mergedMap.values()));
		return plotList;
	}

	@Override
	public void ImportCropPlan(User user, String tenant, String cuaa, Integer campagna, String _requestId) {
		try {
			loggerntt = new LoggerNTT();
			isImportCP = true;
			requestId.set(_requestId);
			PartyResponse businessResult = getParty(tenant, cuaa);
			CropPlanResponse cropPlan = LoadCropPlanLogic(user, tenant, businessResult.getId());
			int cropPlanId = cropPlan.getCropPlanId();
			RecordResponse<VersionResponse> versions = getVersionCropPlan(user, tenant, businessResult.getId(),
					cropPlanId,
					campagna);
			@SuppressWarnings("unused")
			LockCropPlanResponse lockCropPlan = lockCropPlan(tenant, businessResult.getId(), cropPlanId);
			LocalDate today = LocalDate.now();
			String formattedTodayDate = today.format(SHORTSTRINGDATEFORMATTER);
			LocalDate tomorrow = LocalDate.now().plusDays(1);
			tomorrow = tomorrow.withYear(campagna);

			// tomorrow = LocalDate.of(2025, 3, 11);

			String formattedDate = tomorrow.format(FORMATTER);
			var lastVersionMessage = (versions.getRecords() != null && !versions.getRecords().isEmpty())
					? versions.getRecords().get(0).getMessage()
					: null;
			FeaturesResponse collection = getFeatureCollection(user, tenant, cuaa, campagna, formattedDate,
					lastVersionMessage);
			if (collection == null) {
				return;
			}

			collection.setFeatures(collection.getFeatures()
					.stream()
					.filter(f -> checkInCorrectCampaign(f, campagna))
					.sorted(Comparator.comparing((Feature x) -> x.getProperties().getAreaPoligono())
							.thenComparing(Comparator.comparing((Feature x) -> x.getProperties().getId()).reversed()))
					.toList());

			if (collection.getFeatures().isEmpty()) {
				return;
			}

			String idPcgVers = collection.getFeatures().get(0).getProperties().getIdPcgVers();
			if (!ValidateVersions(versions, idPcgVers)) {
				return;
			}

			if (lastVersionMessage == null) { // any previous import stopped
				cleanupBeforeImport(tenant, businessResult.getId(), cropPlanId);
			}

			List<PlotFeatureBindingDTO> plotFeatureMatches = new ArrayList<>();
			if (lastVersionMessage != null) {
				RecordResponse<PlotDataResponse> plotResult = listOfPlots(tenant,
						businessResult.getId(), cropPlanId, formattedTodayDate);

				// Delete Plot Check
				plotFeatureMatches = findMatches(collection.getFeatures(), plotResult);
				Set<String> updatePlotIds = plotFeatureMatches.stream()
						.map(x -> x.getPlot().getPlotId())
						.collect(Collectors.toSet());

				List<PlotDataResponse> deletedPlot = plotResult.getRecords().stream()
						.filter(x -> !updatePlotIds.contains(x.getPlotId()))
						.toList();

				if (deletedPlot != null && !deletedPlot.isEmpty()) {
					AbsoluteDate startDateOfCurrentCampaing = AbsoluteDate
							.of(LocalDate.of(campagna - 1, 11, 11));

					for (PlotDataResponse plot : deletedPlot) {
						if (plot.getFromDate().isBefore(startDateOfCurrentCampaing)) { // Is from previous campaign
							// NOTE: We preserve the plot in the current history, expiring it at the end of
							// the campaign
							String fromDate = LocalDate.of(campagna - 1, 11, 10)
									.format(SHORTSTRINGDATEFORMATTER);
							deletePlotRequest(tenant, businessResult.getId(), cropPlanId, plot.getDomainZoneId(),
									plot.getPlotCode(), fromDate);
						} else {
							// NOTE: Deleting at "plot fromDate" implies tha the server will set dt_delete
							// in the past; removing it from the current history
							deletePlotRequest(tenant, businessResult.getId(), cropPlanId, plot.getDomainZoneId(),
									plot.getPlotCode(),
									plot.getFromDate().toString());
						}
					}
				}
			}

			LocalDate maxAppeDate = null;
			for (Feature feature : collection.getFeatures()) {
				log.debug("PROPERTY ID: {}", feature.getProperties().getId());
				LocalDate dataFineAppe = LocalDate.parse(feature.getProperties().getDataFineAppe(), FORMATTER);
				if (dataFineAppe.getYear() == campagna && (maxAppeDate == null || dataFineAppe.isAfter(maxAppeDate))) {
					maxAppeDate = dataFineAppe;
				}

				if (lastVersionMessage == null) {
					// NOTE: Create without checking previous version, since there are // no
					// previous versions
					interSectionWithDomains(user, tenant, feature, businessResult, cropPlanId);
				} else {
					PlotDataResponse plot = null;
					if (feature != null && feature.getProperties() != null
							&& feature.getProperties().getIdAppeLast() != null) {
						String featureId = feature.getProperties().getIdAppeLast();

						PlotFeatureBindingDTO plotFeatureBindingDTO = plotFeatureMatches.stream()
								.filter(x -> x.getFeature() != null &&
										x.getFeature().getProperties() != null &&
										featureId.equals(x.getFeature().getProperties().getIdAppeLast()))
								.findFirst()
								.orElse(null);

						if (plotFeatureBindingDTO != null) {
							// This is the plot to be updated for the current feature
							plot = plotFeatureBindingDTO.getPlot();
						}
					}

					interSectionWithDomainsV2(user, tenant, feature, businessResult, cropPlanId, plot);
				}
			}

			if (maxAppeDate == null) {
				// No features in the FeatureCollection
				maxAppeDate = LocalDate.now();
			}
			// Validate plot
			RecordResponse<PlotDataResponse> plotResult = listOfPlots(tenant,
					businessResult.getId(), cropPlanId, formattedTodayDate);
			if (plotResult != null && !plotResult.getRecords().isEmpty()) {
				plotResult.getRecords().forEach(plot -> {
					if (plot.getAreaSqm() < 1) {// delete plots with areasq lower than 1
						deletePlotRequest(tenant, businessResult.getId(), cropPlanId, plot.getDomainZoneId(),
								plot.getPlotCode(),
								plot.getFromDate().toString());
					}
				});
			}

			VersionRequest versionRequest = VersionRequest.builder()
					.message(idPcgVers)
					.havingAcknowledgedAnomalies(false)
					.pointInTime(AbsoluteDate.of(maxAppeDate).getValue())
					.build();
			createVersionCropPlan(user, tenant, businessResult.getId(), cropPlan.getCropPlanId(), versionRequest);

			isImportCP = false;
		} catch (Exception ex) {
			isImportCP = false;
			checkResponseStatus(null, "", tenant, null, "ImportCropPlan", ex, null);
			storeLog(500, null, "ImportCropPlan", UserName(tenant), null, ex);
			throw new RuntimeException(ex);
		}

	}

	private boolean checkInCorrectCampaign(Feature f, int campagna) {
		LocalDate campaignFrom = LocalDate.parse("11/11/" + (campagna - 1), FORMATTER);
		LocalDate campaignTo = LocalDate.parse("10/11/" + campagna, FORMATTER);
		LocalDate start = LocalDate.parse(f.getProperties().getDataInizAppe(), FORMATTER);
		LocalDate end = LocalDate.parse(f.getProperties().getDataFineAppe(), FORMATTER);
		return start.compareTo(campaignTo) <= 0 && end.compareTo(campaignFrom) >= 0;
	}

	@Override
	public InfiniteListResults<PCGCropPlanResponse> findPCGCropPlanByCuaa(User user, String tenant, String cuaa,
			Integer campagna, String nextKey) {
		PartyResponse businessResult = getParty(tenant, cuaa);
		CropPlanResponse cropPlan = LoadCropPlanLogic(user, tenant, businessResult.getId());
		Integer cropPlanId = cropPlan.getCropPlanId();
		RecordResponse<VersionResponse> versions = getVersionCropPlan(user, tenant, businessResult.getId(), cropPlanId,
				9999);

		if (versions.getRecords().isEmpty()) {
			return new InfiniteListResultsImpl<>();
		}

		VersionResponse version = versions.getRecords().get(0);
		var lastVersionYear = version.getVersionReferenceDate().toLocalDate().getYear();

		if (lastVersionYear != campagna) {
			throw new IllegalArgumentException("cuaa = " + cuaa + ", campagna must be = " + lastVersionYear);
		}

		InfiniteListResults<PlotDataResponse> plotResult = getPlotDetails(user, tenant, businessResult.getId(),
				cropPlanId, lastVersionYear, nextKey);

		List<PCGCropPlanResponse> records = plotResult.getRecords().stream()
				.filter(p -> p.getDecls() != null && !p.getDecls().isEmpty())
				.flatMap(p -> mapPlotDataResponse(p, version, false).stream())
				.toList();

		return new InfiniteListResultsImpl<>(records, plotResult.getNextKey());
	}

	@Override
	public AnagraficaResponse findAnagraficaByCuaa(User user, String tenant, String cuaa) {
		PartyResponse businessResult = getParty(tenant, cuaa);
		return mapAnagrafica(tenant, businessResult);
	}

	private AnagraficaResponse mapAnagrafica(String tenant, PartyResponse party) {
		var resi = party.getAddressResidential();
		var seda = AnagraficaResponse.AnagraficaSede.builder()
				.codiceBelfiore(resi.getMunicipalityDetail().getShortDescr())
				.comune(resi.getMunicipalityDetail().getI18nName())
				.indirizzo(
						FormatStringWithSpace(resi.getLocality(), true) + FormatStringWithSpace(resi.getStreet(), true)
								+ FormatStringWithSpace(resi.getHouseNumber(), false))
				.cap(resi.getPostcode())
				.build();

		String codiceDetentore = readCodiceDetentore(tenant, party.getId());
		return AnagraficaResponse.builder()
				.cuaa(party.getCode())
				.mandato(new Mandato(codiceDetentore))
				.codiceFiscale(party.getTaxCode())
				.denominazione(FormatStringWithSpace(party.getLastName(), true)
						+ FormatStringWithSpace(party.getFirstName(), false))
				.partitaIva(party.getVatNumber())
				.sede(seda)
				.tipoAnagrafica(
						(party.getPartyType() != null && "n".equalsIgnoreCase(party.getPartyType())) ? "P" : "G")
				.build();
	}

	private String readCodiceDetentore(String tenant, int partyId) {
		if (client == null) {
			return null;
		}

		InfiniteListResultsImpl<PartyAclEntitiesResponse> list = client.target(partyRegistryAcl)
				.path(tenant)
				.path("/api-priv/v1/parties-acl/parties")
				.path("" + partyId)
				.path("/entities")
				.request(MediaType.APPLICATION_JSON)
				.header("Authorization", "JWT " + authTokenCache.get(tenant))
				.get(new GenericType<InfiniteListResultsImpl<PartyAclEntitiesResponse>>() {
				});

		return list.getRecords().stream()
				.filter(e -> AbsoluteDate.of(LocalDate.now()).isBetween(e.getDay_from(), e.getDay_to()))
				.filter(e -> "MAN".equals(e.getParty_type().getCode()))
				.filter(e -> "CAA".equals(e.getEntity().getEntity_type().getCode()))
				.map(e -> e.getEntity().getCode())
				.findAny()
				.orElse(null);
	}

	public String FormatStringWithSpace(String val, boolean addspace) {
		if (val == null || val.isEmpty()) {
			return "";
		}
		if (addspace) {
			return val + " ";
		} else {
			return val;
		}
	}

	@Override
	public InfiniteListResults<AnagraficaResponse> findAnagraficaListByCuaa(User user, String tenant, String cuaa,
			OffsetDateTime requestTime, String nextKey) {
		AnagraficaResponse br = findAnagraficaByCuaa(user, tenant, cuaa);
		ArrayList<AnagraficaResponse> list = new ArrayList<>();
		list.add(br);
		InfiniteListResultsImpl<AnagraficaResponse> result = new InfiniteListResultsImpl<>();
		result.setRecords(list);
		return result;
	}

	@Override
	public InfiniteListResults<PCGCropPlanResponse> deltaHandling(User user, String tenant, String cuaa,
			OffsetDateTime offsetDateTime) {
		PartyResponse businessResult = getParty(tenant, cuaa);
		CropPlanResponse cropPlan = LoadCropPlanLogic(user, tenant, businessResult.getId());
		Integer cropPlanId = cropPlan.getCropPlanId();
		RecordResponse<VersionResponse> versions = deltaVersionCropPlan(user, tenant, businessResult.getId(),
				cropPlanId, offsetDateTime);
		return mapPCGResults(user, versions, cropPlanId, businessResult.getId(), tenant, offsetDateTime);
	}

	private InfiniteListResults<PCGCropPlanResponse> mapPCGResults(
			User user,
			RecordResponse<VersionResponse> versions,
			Integer cropPlanId,
			Integer businessId,
			String tenant,
			OffsetDateTime requestedTime) {
		InfiniteListResults<PlotDataResponse> latestCP = new InfiniteListResultsImpl<>();
		InfiniteListResults<PlotDataResponse> oldCP = new InfiniteListResultsImpl<>();
		InfiniteListResultsImpl<PCGCropPlanResponse> finalResults = new InfiniteListResultsImpl<>();

		LocalDateTime localRequestedTime = requestedTime.toLocalDateTime();

		if ((long) versions.getRecords().size() == 2) {
			var versonOffsetAfter = (versions.getRecords().get(0).getVersionDate());
			if (versonOffsetAfter.isAfter(localRequestedTime) || versonOffsetAfter.isEqual(localRequestedTime)) {
				var versionDate = versions.getRecords().get(0).getVersionReferenceDate().toLocalDate();
				latestCP = getPlotDetailsFromVersion(user, tenant, businessId, cropPlanId, versions.getRecords().get(0),
						versionDate.getYear());
			}
			var versionOffsetBefore = (versions.getRecords().get(1).getVersionDate());
			if (versionOffsetBefore.isBefore(localRequestedTime)) {
				var versionDate = versions.getRecords().get(1).getVersionReferenceDate().toLocalDate();
				oldCP = getPlotDetailsFromVersion(user, tenant, businessId, cropPlanId, versions.getRecords().get(1),
						versionDate.getYear());
			}
		} else if ((long) versions.getRecords().size() == 1) {
			var versionOffsetBefore = (versions.getRecords().get(0).getVersionDate());
			if (versionOffsetBefore.isBefore(localRequestedTime)) {
				var versionDate = versions.getRecords().get(0).getVersionReferenceDate().toLocalDate();
				oldCP = getPlotDetailsFromVersion(user, tenant, businessId, cropPlanId, versions.getRecords().get(0),
						versionDate.getYear());
			}
		}
		if (latestCP != null && !latestCP.getRecords().isEmpty())
			latestCP = mergePlotDataByPlotCode(latestCP.getRecords());
		if (oldCP != null && !oldCP.getRecords().isEmpty())
			oldCP = mergePlotDataByPlotCode(oldCP.getRecords());

		List<PCGCropPlanResponse> responseList = new ArrayList<>();
		// Identify "new" and "updated" plots
		if (latestCP.getCount() > 0 && oldCP.getCount() > 0) {
			Map<String, PlotDataResponse> latestMap = latestCP.getRecords().stream()
					.collect(Collectors.toMap(PlotDataResponse::getPlotCode, Function.identity()));

			Map<String, PlotDataResponse> oldMap = oldCP.getRecords().stream()
					.collect(Collectors.toMap(PlotDataResponse::getPlotCode, Function.identity()));
			// Identify "deleted" plots
			for (PlotDataResponse oldPlot : oldCP.getRecords()) {
				var cVersion = (long) versions.getRecords().size() > 1 ? versions.getRecords().get(1)
						: versions.getRecords().get(0);
				if (!latestMap.containsKey(oldPlot.getPlotCode())) {
					List<PCGCropPlanResponse> plots = mapPlotDataResponse(oldPlot, cVersion, true);
					PCGCropPlanResponse emptyPlot;
					for (PCGCropPlanResponse plot : plots) {
						emptyPlot = PCGCropPlanResponse.builder()
								.campagna(cVersion.getVersionReferenceDate().toLocalDate().getYear())
								.tipoModifica("C")
								.idAppezzamento(plot.getIdAppezzamento())
								.idAppezzamentoPadre(plot.getIdAppezzamentoPadre())
								.build();
						responseList.add(emptyPlot);
					}
				}
			}

			for (PlotDataResponse latestPlot : latestCP.getRecords()) {
				if (!oldMap.containsKey(latestPlot.getPlotCode())) {
					// New plot
					List<PCGCropPlanResponse> plots = mapPlotDataResponse(latestPlot, versions.getRecords().get(0),
							true);
					plots.forEach(p -> p.setTipoModifica("I"));
					responseList.addAll(plots);
				} else {
					PlotDataResponse oldPlot = oldMap.get(latestPlot.getPlotCode());
					if (!latestPlot.getPlotId().equals(oldPlot.getPlotId())) {
						// Updated plot
						List<PCGCropPlanResponse> plots = mapPlotDataResponse(latestPlot, versions.getRecords().get(0),
								true);
						plots.forEach(p -> p.setTipoModifica("A"));
						responseList.addAll(plots);
					}
				}
			}

		} else if (versions.getCount() == 1) {
			var requestedVersionDate = (versions.getRecords().get(0).getVersionDate());
			if (requestedVersionDate.isAfter(localRequestedTime)) {
				oldCP.getRecords().forEach(x -> {
					List<PCGCropPlanResponse> plots = mapPlotDataResponse(x, versions.getRecords().get(0), true);
					plots.forEach(p -> p.setTipoModifica("I"));
					responseList.addAll(plots);
				});
			}
		}

		if (!responseList.isEmpty()) {
			finalResults.setRecords(responseList);
		}

		return finalResults;
	}

	public InfiniteListResults<PlotDataResponse> getPlotDetailsFromVersion(User user, String tenantId,
			Integer businessId, Integer cropPlanId,
			VersionResponse version, Integer year) {
		InfiniteListResultsImpl<PlotDataResponse> result = new InfiniteListResultsImpl<PlotDataResponse>();
		ArrayList<PlotDataResponse> dt = new ArrayList<>();
		String nextKey = null;
		do {
			String url = String.format("%s/%s/public/v1/crop-plans/%s/plans/%s/plots" +
					"?pointInTime=%s1111&pointInTimeTo=%s1110" +
					"&excludes=ANOMALIES&excludes=DECLARATIONS_PESTICIDES&excludes=DECLARATIONS_PLOT_STYLE&excludes=PARCELS&version=%s%s",
					cropPlanUrl, tenantId, businessId, cropPlanId, year - 1, year, version.getVersion(),
					(nextKey != null ? "&nextKey=" + nextKey : ""));
			var data = sendGetRequestWithAuth(url, new TypeReference<InfiniteListResultsImpl<PlotDataResponse>>() {
			}, "createCropPlan", tenantId);
			dt.addAll(data.getRecords());
			nextKey = data.getNextKey();
		} while (nextKey != null);
		result.setRecords(dt);
		return result;
	}

	private List<PCGCropPlanResponse> mapPlotDataResponse(PlotDataResponse plot, VersionResponse version,
			boolean isDelta) {
		List<DeclarationWithFields> declarations = createDeclarations(plot);
		List<DeclarationWithFields> overlapping = new ArrayList<>();
		List<DeclarationWithFields> nonOverlapping = new ArrayList<>();

		Set<Integer> overlappingInTime = findOverlapsInTimeIndices(declarations);
		for (int i = 0; i < declarations.size(); i++) {
			DeclarationWithFields declWithFields = declarations.get(i);
			if (overlappingInTime.contains(i)) {
				overlapping.add(declWithFields);
			} else {
				nonOverlapping.add(declWithFields);
			}
		}

		GIS gis = GIS.builder().srCode(plot.getSrs()).wkt(plot.getGeom()).build();
		List<PCGCropPlanResponse> ret = new ArrayList<>();

		if (!nonOverlapping.isEmpty()) {
			DeclarationWithFields df = nonOverlapping.get(0);
			PCGCropPlanResponse r = createEmptyPCGCropPlanResponse(plot.getPlotCode(), plot, df, gis, version);
			r.getDichiarazioni().addAll(nonOverlapping.stream()
					.map(DeclarationWithFields::decl)
					.toList());

			ret.add(r);
		}

		for (DeclarationWithFields df : overlapping) {
			PCGCropPlanResponse r = createEmptyPCGCropPlanResponse(
					"o" + plot.getPlotCode() + "-" + df.decl.getIdDichiarazione(), plot, df, gis, version);
			r.getDichiarazioni().add(df.decl);
			ret.add(r);
		}

		if (isDelta) {
			int year = version.getVersionReferenceDate().toLocalDate().getYear();
			ret.forEach(r -> {
				r.setCampagna(year);
				r.setCertified(true);
			});
		}

		return ret;
	}

	private PCGCropPlanResponse createEmptyPCGCropPlanResponse(String idAppezzamento, PlotDataResponse plot,
			DeclarationWithFields df, GIS gis, VersionResponse version) {
		return PCGCropPlanResponse.builder()
				.idAppezzamento(idAppezzamento)
				.denominazione(plot.getDescription() == null ? "" : plot.getDescription())
				.codNazionale(plot.getDomainZoneId())
				.areaMq(plot.getAreaSqm())
				.chiave(PCGCropPlanResponse.Chiave.builder()
						.idSchedaValidazione(getFieldValueByCode(df.fields, "idSchedaValidazione"))
						.identificativoPianoColtivazione(
								getFieldValueByCode(df.fields, "identificativoPianoColtivazione"))
						.codiBarrSchedaValidazione(null)
						.identificativoIsola(getFieldValueByCode(df.fields, "identificativoIsola"))
						.identificativoAppezzamento(
								getFieldValueByCode(df.fields, "identificativoAppezzamento"))
						.idAppezzamentoOrig(getFieldValueByCode(df.fields, "idAppezzamentoOrig"))
						.build())
				.dataInizioValidita(plot.getFromDate().toLocalDate())
				.dataFineValidita(plot.getToDate().toLocalDate())
				.idAppezzamentoPadre(idAppezzamento)
				.dichiarazioni(new ArrayList<>())
				.gis(gis)
				.ultimoAggiornamento(version.getVersionDate())
				.build();
	}

	private Set<Integer> findOverlapsInTimeIndices(List<DeclarationWithFields> declarations) {
		List<FromTo> list = declarations.stream()
				.map(DeclarationWithFields::decl)
				.map(decl -> new FromTo(decl.getDataInizioValidita(), decl.getDataFineValidita()))
				.sorted(Comparator.comparing(FromTo::from).thenComparing(FromTo::to))
				.toList();

		Set<Integer> ret = new HashSet<>(declarations.size());

		FromTo current;
		FromTo next;
		for (int i = 0; i < list.size() - 1; i++) {
			current = list.get(i);
			for (int j = i + 1; j < list.size(); j++) {
				next = list.get(j);
				if (current.to.isBefore(next.from)) {
					break;
				}
				if (current.from.compareTo(next.to) <= 0 && current.to.compareTo(next.from) >= 0) {
					ret.add(i);
					ret.add(j);
				}
			}
		}

		return ret;
	}

	private List<DeclarationWithFields> createDeclarations(PlotDataResponse plot) {
		return plot.getDecls().stream()
				.map(delc -> {
					List<AdditionalField> fieldsCodes = delc.getFieldsCodes();

					List<Map<String, String>> protocolli = getProtocolli(fieldsCodes);

					var idColt = getFieldValueByCode(fieldsCodes, "idColt");
					Declaration d = Declaration.builder()
							.idDichiarazione(delc.getDeclCode())
							.coltura(delc.getLanduse().getDescription())
							.codiceColtura(delc.getLanduse().getCode())
							.areaMq((int) Math.round((plot.getAreaSqm() * delc.getAreaPerc()) / 100d))
							.dataInizioValidita(delc.getFromDate().toLocalDate())
							.dataFineValidita(delc.getToDate().toLocalDate())
							.dataImpianto(null)
							.bbch(null)
							.protocolli(protocolli)
							.chiave(PCGCropPlanResponse.ChiaveDichiarazioni.builder().idColt(idColt).build())
							.datiAggiuntiviPCG(mapFieldCodesToDatiAggiuntiviPCG(fieldsCodes))
							.build();

					return new DeclarationWithFields(d, fieldsCodes);
				})
				.toList();
	}

	private List<Map<String, String>> getProtocolli(List<AdditionalField> allAdditionalFields) {
		ArrayList<Map<String, String>> protocolli = new ArrayList<>(2);
		if (allAdditionalFields.stream()
				.filter(f -> "attoBiol".equals(f.getFieldCode()))
				.anyMatch(f -> "BIOL".equals(f.getValue()))
				||
				allAdditionalFields.stream()
						.filter(f -> "flagBiol".equals(f.getFieldCode()))
						.anyMatch(f -> "SI".equals(f.getValue()) || "1".equals(f.getValue()))) {
			protocolli.add(Map.of("protocollo", "BIO"));
		}

		if (allAdditionalFields.stream()
				.filter(f -> "flagProdInte".equals(f.getFieldCode()))
				.anyMatch(f -> "SI".equals(f.getValue()) || "1".equals(f.getValue()))) {
			protocolli.add(Map.of("protocollo", "DPI"));
		}

		return protocolli;
	}

	private void cleanupBeforeImport(String tenantId, int bussinesId, Integer cropPlanId) {
		String url = String.format("%s/%s/public/v1/crop-plans/%s/plans/%s/cleanup", cropPlanUrl, tenantId, bussinesId,
				cropPlanId);
		sendRequest(url, String.class, authTokenCache.get(tenantId), null, "DELETE", "cleanup", tenantId);
	}

	private boolean ValidateVersions(RecordResponse<VersionResponse> versions, String idPcgVers) {
		AtomicBoolean isValid = new AtomicBoolean(true);
		versions.getRecords().forEach(v -> {
			if (v.getMessage().equals(idPcgVers)) {
				isValid.set(false);
			}
		});
		return isValid.get();
	}

	private CropPlanResponse LoadCropPlanLogic(User user, String tenant, Integer bussinesId) {
		RecordResponse<CropPlanResponse> cropPlans = getCropPlans(user, tenant, bussinesId, "CROPPLAN");
		if (cropPlans.getRecords().isEmpty()) {
			CropPlanRequest cpRequest = CropPlanRequest.builder().cropPlanTypeCode("CROPPLAN").description("Crop Plan")
					.flNotManaged(false).build();
			return createCropPlan(user, tenant, bussinesId, cpRequest);
		} else {
			return cropPlans.getRecords().get(0);
		}
	}

	private void interSectionWithDomains(User user, String tenant, Feature feature, PartyResponse businessResult,
			Integer cropPlanId) {

		var property = feature.getProperties();

		Geometry geom = feature.getGeometry();
		IntersectionResponse intersectionResult = null;
		intersectionResult = SendIntersectionRequest(geom, tenant,
				property.getCodiceEpsg());
		if (intersectionResult == null) {
			geom = geom.buffer(80);
			intersectionResult = SendIntersectionRequest(geom, tenant,
					property.getCodiceEpsg());
		}
		checkIntersectionResponse(tenant, feature, intersectionResult);

		try {
			PlotCropPlanRequest.CutParameters cutParameters = new PlotCropPlanRequest.CutParameters();
			cutParameters.setBehaviour("CUT_ON_EXISTING");
			PlotCropPlanRequest plotRequest = PlotCropPlanRequest.builder()
					.geom(feature.getGeometry())
					.fromPointInTime(
							AbsoluteDate.of(LocalDate.parse(property.getDataInizAppe(), FORMATTER)).toString())
					.cutParameters(cutParameters)
					.build();

			String domainZoneCode = intersectionResult.getFields().get("sector");
			log.debug("sector: {}", domainZoneCode);
			PlotDataResponse plotResult = plotCropPlan(tenant, businessResult.getId(), cropPlanId, domainZoneCode,
					plotRequest);
			if (plotResult != null) {
				SendPlotDeclaration(user, tenant, feature, businessResult, cropPlanId, property, domainZoneCode,
						plotResult);
			}
		} catch (Exception e) {
			checkResponseStatus(null, "", tenant, intersectionResult, "interSectionWithDomains", e, null);
			throw new RuntimeException(e);
		}
	}

	private void checkIntersectionResponse(String tenant, Feature feature, IntersectionResponse intersectionResult) {
		if (intersectionResult == null || intersectionResult.getFields().get("sector") == null
				|| intersectionResult.getFields().get("sector").isEmpty()) {
			var error = "Not able to find sector inside fields of intersection response";
			if (intersectionResult == null) {
				error = "Intersection respond with null result";
			}
			try {
				throwDynamicException("", tenant, mapper.writeValueAsString(feature), "SendIntersectionRequest",
						String.format("Intersection request failed for this feature: %s, %s",
								feature.getProperties().getId(), error));
			} catch (JsonProcessingException e) {
				throw new RuntimeException(e);
			}
			throw new RuntimeException(error);
		}
	}

	// Read DomainZone / Send Intersection Request
	private IntersectionResponse SendIntersectionRequest(Geometry geometry, String tenant, String epsgCode) {
		try {
			String date = AbsoluteDate.of(LocalDate.now()).toString();
			String nextKey = null;
			ArrayList<IntersectionResponse> allRecords = new ArrayList<>();
			GeometryObjectRequest request = new GeometryObjectRequest(geometry);
			do {
				String url = String.format(
						"%s/%s/public/v1/layers/BLOCKS/geometries/intersection?reference_date=%s&srs=EPSG:%s%s",
						vectorDataLayers, tenant, date, epsgCode,
						nextKey != null ? "&nextKey=" + nextKey : "");
				var data = sendPostRequestWithAuth(url, request,
						new TypeReference<RecordResponse<IntersectionResponse>>() {
						}, "sendIntersectionRequest", tenant);
				allRecords.addAll(data.getRecords());
				nextKey = data.getNextKey();
			} while (nextKey != null);

			if (allRecords.size() == 1) {
				return allRecords.get(0);
			}
			Map<String, Double> areaSumBySector = new HashMap<>();
			Map<String, IntersectionResponse> maxAreaResponseBySector = new HashMap<>();
			for (IntersectionResponse record : allRecords) {
				String sector = record.getFields().get("sector");
				if (sector == null) {
					continue;
				}
				double area = record.getAreaSqm();
				areaSumBySector.put(sector, areaSumBySector.getOrDefault(sector, 0.0) + area);

				IntersectionResponse currentMaxResponse = maxAreaResponseBySector.get(sector);
				if (currentMaxResponse == null || areaSumBySector.get(sector) > currentMaxResponse.getAreaSqm()) {
					record.setAreaSqm(areaSumBySector.get(sector)); // Set accumulated area
					maxAreaResponseBySector.put(sector, record);
				}
			}
			return maxAreaResponseBySector.values().stream()
					.max(Comparator.comparingDouble(IntersectionResponse::getAreaSqm))
					.orElse(null);

		} catch (Exception ex) {
			checkResponseStatus(null, "", tenant, "", "SendIntersectionRequest", ex, null);
			throw new RuntimeException("Error processing response", ex);
		}
	}

	public PlotDataResponse plotCropPlan(String tenantId, Integer businessId, Integer cropPlanId, String domainZoneCode,
			PlotCropPlanRequest plotCropPlanRequest) {
		Object[] args = { cropPlanUrl, tenantId, businessId, cropPlanId, domainZoneCode };
		String url = String.format("%s/%s/public/v1/crop-plans/%s/plans/%s/domains/%s/plots?cleanZeroAreaResults=true",
				args);
		var plotResult = sendPostRequest(tenantId, url, plotCropPlanRequest, PlotCropPlanResponse.class,
				"plotCropPlan");
		if (plotResult == null) {
			throwDynamicException(url, tenantId, new Object(), "plotCropPlan",
					"Error on plots creation: DomainZone:" + domainZoneCode);
		}
		PlotDataResponse mainAddedPlot = findMainPlot(plotResult.getAdded());
		return mainAddedPlot;
	}

	private PlotDataResponse findMainPlot(List<PlotDataResponse> added) {
		PlotDataResponse ret = null;
		double maxArea = 0;
		for (PlotDataResponse p : added) {
			if (p.getAreaSqm() > maxArea) {
				maxArea = p.getAreaSqm();
				ret = p;
			}
		}
		return ret;
	}

	private void SendPlotDeclaration(User user, String tenant, Feature feature, PartyResponse bussinesResult,
			Integer CropPlanId, Properties property,
			String domainZoneCode, PlotDataResponse mainAddedPlot) {
		property.getColtivazioni().forEach(coltivazione -> {
			try {
				log.debug("Send Plot Decl DomainId {} Coltivazioni: {}", domainZoneCode, coltivazione.getIdColt());
				DeclarationPayload del = FulFillEntity(feature, coltivazione, mainAddedPlot);
				insertDeclaration(user, tenant, bussinesResult.getId(), CropPlanId, domainZoneCode,
						mainAddedPlot.getPlotCode(), del);
				log.debug("------------------------------------------------------------------------------");
			} catch (IOException e) {
				checkResponseStatus(null, "", tenant, mainAddedPlot, "SendPlotDeclaration", e, null);
				throw new RuntimeException(e);
			}
		});
	}

	private DeclarationPayload FulFillEntity(Feature feature, FeaturesResponse.Coltivazione coltivazione,
			PlotDataResponse mainAddedPlot) throws IOException {
		DeclarationPayload payload = new DeclarationPayload();
		try {

			FeaturesResponse.Properties properties = feature.getProperties();
			double areaPerc = (coltivazione.getSupeColt() / mainAddedPlot.getAreaSqm()) * 100.0;
			payload.setAreaPerc(areaPerc);
			String landuseCode = String.join("-",
					nvl(coltivazione.getCodiOccu(), "000"),
					nvl(coltivazione.getCodiDestUsoo(), "000"),
					nvl(coltivazione.getCodiUsoo(), "000"),
					nvl(coltivazione.getCodiQual(), "000"),
					nvl(coltivazione.getCodiOccuVari(), "000"));
			payload.setLanduseCode(landuseCode);
			payload.setFromDate(
					AbsoluteDate.of(LocalDate.parse(coltivazione.getDataInizColt(), FORMATTER)).toString());
			payload.setToDate(AbsoluteDate.of(LocalDate.parse(coltivazione.getDataFineColt(), FORMATTER)).toString());
			payload.setFromDatePrecision("YMD");

			List<DeclarationPayload.FieldCode> fieldsCodes = new ArrayList<>();
			fulfillColtivazioni(coltivazione, fieldsCodes);
			fulfillFeatures(properties, coltivazione, fieldsCodes);
			payload.setFieldsCodes(fieldsCodes);
			payload.setRemoveExistingDeclarations(false);

		} catch (Exception e) {
			checkResponseStatus(null, "", "", feature, "FulFillEntity", e, null);
			throw new RuntimeException(e);
		}
		return payload;
	}

	private String nvl(String possiblyNull, String defVal) {
		if (possiblyNull == null || possiblyNull.isEmpty()) {
			return defVal;
		}
		return possiblyNull;
	}

	private void fulfillColtivazioni(FeaturesResponse.Coltivazione coltivazione,
			List<DeclarationPayload.FieldCode> fieldsCodes) {
		for (FieldDefinition fieldDef : fieldDefinitions) {
			DeclarationPayload.FieldCode fieldCode = createFieldCode(
					fieldDef.getCode(),
					coltivazione,
					AbsoluteDate.of(LocalDate.parse(coltivazione.getDataInizColt(), FORMATTER)).toString(),
					AbsoluteDate.of(LocalDate.parse(coltivazione.getDataFineColt(), FORMATTER)).toString(),
					false);
			fieldsCodes.add(fieldCode);
		}
	}

	private void fulfillFeatures(FeaturesResponse.Properties properties, FeaturesResponse.Coltivazione coltivazione,
			List<DeclarationPayload.FieldCode> fieldsCodes) {
		for (FieldDefinition fieldDef : fieldDefinitionsProperties) {
			DeclarationPayload.FieldCode fieldCode = createFieldCodeProperties(
					fieldDef.getCode(),
					properties,
					AbsoluteDate.of(LocalDate.parse(properties.getDataInizAppe(), FORMATTER)).toString(),
					AbsoluteDate.of(LocalDate.parse(properties.getDataFineAppe(), FORMATTER)).toString(),
					false);
			fieldsCodes.add(fieldCode);
		}
	}

	private DeclarationPayload.FieldCode createFieldCode(String fieldCodeName,
			FeaturesResponse.Coltivazione coltivazione, String dayFrom, String dayTo,
			boolean flShowInTooltip) {
		DeclarationPayload.FieldCode fieldCode = new DeclarationPayload.FieldCode();
		fieldCode.setDayFrom(dayFrom);
		fieldCode.setDayTo(dayTo);
		fieldCode.setFieldCode(fieldCodeName);
		fieldCode.setFlShowInTooltip(flShowInTooltip);
		fieldCode.setValue(getFieldValue(coltivazione, fieldCodeName));
		return fieldCode;
	}

	private DeclarationPayload.FieldCode createFieldCodeProperties(String fieldCodeName,
			FeaturesResponse.Properties properties, String dayFrom, String dayTo,
			boolean flShowInTooltip) {
		DeclarationPayload.FieldCode fieldCode = new DeclarationPayload.FieldCode();
		fieldCode.setDayFrom(dayFrom);
		fieldCode.setDayTo(dayTo);
		fieldCode.setFieldCode(fieldCodeName);
		fieldCode.setFlShowInTooltip(flShowInTooltip);
		fieldCode.setValue(getFieldValueProperties(properties, fieldCodeName));
		return fieldCode;
	}

	public RecordResponse<CropPlanResponse> getCropPlans(User user, String tenantId, Integer businessId,
			String cropPlanTypeCode) {
		String url = String.format("%s/%s/public/v1/crop-plans/%s/plans?cropPlanTypeCode=%s", cropPlanUrl, tenantId,
				businessId, cropPlanTypeCode);
		var cropPlans = sendGetRequestWithAuth(url, new TypeReference<RecordResponse<CropPlanResponse>>() {
		}, "getCropPlans", tenantId);
		if (cropPlans.getCount() > 1) {
			throwDynamicException(url, tenantId, new Object(), "getCropPlans", "Crop Plan can not be more than one.");
			throw new RuntimeException(new IOException("Crop Plan can not be more than one."));
		}
		return cropPlans;
	}

	public CropPlanResponse createCropPlan(User user, String tenantId, Integer businessId, CropPlanRequest cropPlan) {
		String url = String.format("%s/%s/public/v1/crop-plans/%s/plans", cropPlanUrl, tenantId, businessId);
		return sendPostRequest(tenantId, url, cropPlan, CropPlanResponse.class, "createCropPlan");
	}

	public InfiniteListResults<PlotDataResponse> getPlotDetails(User user, String tenantId, Integer businessId,
			Integer cropPlanId, Integer year,
			String nextKey) {
		String url = String.format("%s/%s/public/v1/crop-plans/%s/plans/%s/plots" +
				"?pointInTime=%s1111&pointInTimeTo=%s1110" +
				"&excludes=ANOMALIES&excludes=DECLARATIONS_PESTICIDES&excludes=DECLARATIONS_PLOT_STYLE&excludes=PARCELS%s",
				cropPlanUrl, tenantId, businessId, cropPlanId, year - 1, year,
				(nextKey != null ? "&nextKey=" + nextKey : ""));
		return sendGetRequestWithAuth(url, new TypeReference<InfiniteListResultsImpl<PlotDataResponse>>() {
		}, "getPlotDetails", tenantId);
	}

	// Version
	@Override
	public CropPlanVersionWithInfo getCropPlanVersionWithInfo(String tenantId, Long businessId, Long cropPlanId) {
		String url = String.format("%s/%s/public/v1/crop-plans/%s/plans/%s/versions?includeInPublishing=true",
				cropPlanUrl, tenantId, businessId, cropPlanId);

		RecordResponse<VersionResponse> data = sendGetRequestWithAuth(url,
				new TypeReference<RecordResponse<VersionResponse>>() {
				},
				"getVersionCropPlan", tenantId);

		int num = data.getCount();
		if (num == 0) {
			return new CropPlanVersionWithInfo(null, false);
		}

		return new CropPlanVersionWithInfo(data.getRecords().get(0), num > 1);
	}

	public RecordResponse<VersionResponse> getVersionCropPlan(
			User user, String tenantId, Integer businessId, Integer cropPlanId, Integer campagna) {

		RecordResponse<VersionResponse> result = new RecordResponse<>();
		result.setRecords(new ArrayList<>());

		String nextKey = null;
		do {
			String url = String.format("%s/%s/public/v1/crop-plans/%s/plans/%s/versions",
					cropPlanUrl, tenantId, businessId, cropPlanId);

			RecordResponse<VersionResponse> data = sendGetRequestWithAuth(url,
					new TypeReference<RecordResponse<VersionResponse>>() {
					},
					"getVersionCropPlan", tenantId);
			result.getRecords().addAll(data.getRecords());
			nextKey = data.getNextKey();
		} while (nextKey != null);

		if (result.getRecords().isEmpty()) {
			return result;
		}
		return CompareVersionWithCampagna(tenantId, campagna, result);
	}

	public RecordResponse<VersionResponse> deltaVersionCropPlan(
			User user, String tenantId, Integer businessId, Integer cropPlanId, OffsetDateTime deltaTime) {

		RecordResponse<VersionResponse> result = new RecordResponse<>();
		AtomicBoolean afterDelta = new AtomicBoolean(false);
		AtomicBoolean beforeDelta = new AtomicBoolean(false);
		AtomicBoolean skipVersionsCall = new AtomicBoolean(false);

		result.setRecords(new ArrayList<>());

		LocalDateTime localDeltaTime = deltaTime.toLocalDateTime();

		String nextKey = null;
		do {
			String url = String.format("%s/%s/public/v1/crop-plans/%s/plans/%s/versions",
					cropPlanUrl, tenantId, businessId, cropPlanId);

			RecordResponse<VersionResponse> data = sendGetRequestWithAuth(url,
					new TypeReference<RecordResponse<VersionResponse>>() {
					},
					"getVersionCropPlan", tenantId);

			data.getRecords().forEach(x -> {
				var versionDate = x.getVersionDate();
				if (afterDelta.get() == false && versionDate.isAfter(localDeltaTime)) {
					afterDelta.set(true);
					result.getRecords().add(x);
				}
				if (beforeDelta.get() == false && versionDate.isBefore(localDeltaTime)) {
					beforeDelta.set(true);
					result.getRecords().add(x);
					skipVersionsCall.set(true);
				}
			});
			nextKey = data.getNextKey();

		} while (!skipVersionsCall.get() && nextKey != null);

		if (result.getRecords().isEmpty()) {
			return result;
		}

		return result;
	}

	private RecordResponse<VersionResponse> CompareVersionWithCampagna(String tenantId, Integer campagna,
			RecordResponse<VersionResponse> result) {
		AtomicReference<Integer> biggesYear = new AtomicReference<>(0);
		result.getRecords().forEach(x -> {
			var versionDate = x.getVersionReferenceDate().toLocalDate();
			if (biggesYear.get() < versionDate.getYear())
				biggesYear.set(versionDate.getYear());
		});
		VersionResponse lastRecord = result.getRecords().get(0);
		if (biggesYear.get() > campagna) {
			String error = "The last version date is greater than the specified campagna date.";
			throwDynamicException("", tenantId, new Object(), "", error);
			throw new RuntimeException(error);
		}
		result.setRecords(List.of(lastRecord));
		return result;
	}

	public VersionResponse createVersionCropPlan(User user, String tenantId, Integer businessId, Integer cropPlanId,
			VersionRequest version) {
		String url = String.format("%s/%s/public/v1/crop-plans/%s/plans/%s/versions", cropPlanUrl, tenantId, businessId,
				cropPlanId);
		return sendPostRequest(tenantId, url, version, VersionResponse.class, "createVersionCropPlan");
	}

	// Lock Crop Plan
	public LockCropPlanResponse lockCropPlan(String tenantId, Integer businessId, Integer cropPlanId) {
		String url = String.format("%s/%s/public/v1/crop-plans/%s/plans/%s/lock", cropPlanUrl, tenantId, businessId,
				cropPlanId);
		sendPutRequest(tenantId, url, null, null, "lockCropPlan");
		LockCropPlanResponse resp = new LockCropPlanResponse();
		resp.setMessage("crop-plan correctly locked");
		resp.setStatus("succedeed");
		resp.setBusinessId(businessId.toString());
		resp.setCropPlanId(cropPlanId.toString());
		return resp;
	}

	// Load All Feature Crop Plan
	public FeaturesResponse getFeatureCollection(User user, String tenantId, String cuaa, Integer campagna, String date,
			String lastVersion) {
		// String url =
		// String.format("%s/api/v1/quadernocampagna/pianodicoltivazione?cuaa=%s&campagna=%s",
		// mtlsProxyUrl,
		// cuaa, campagna);
		String url = String.format(
				"%s/api/v2/quadernocampagna/pianodicoltivazione?cuaa=%s&dataUltimaScheda=%s",
				mtlsProxyUrl, cuaa, date);
		url = url + (lastVersion != null
				? "&codiDestUtil=true&codiOccu=true&codiDestUsoo=true&codiUsoo=true&codiQual=true&codiOccuVari=true&codiRile=true&codiProdRile=true&tolleranza=1&identificativoPcg="
						+ lastVersion
				: "");
		FeatureCollection collection = sendGetRequest(tenantId, url, FeatureCollection.class, "getFeatureCollection");
		if (collection == null || collection.getFeatures().isEmpty()) {
			String message = "Nessun dato disponibile per l'importazione";
			addLog(url, tenantId, "", "getFeatureCollection", 200, message);
			return null;
		}

		// NOTE: we pass a GeometryFactory because do not wanto to use the
		// default SRID 4326
		GeoJsonReader reader = new GeoJsonReader(new GeometryFactory());
		FeaturesResponse res = new FeaturesResponse();
		res.setFeatures(new ArrayList<>());
		collection.forEach(feature -> {
			try {
				String tmp = mapper.writeValueAsString(feature.getGeometry());
				Geometry geom = reader.read(tmp);
				tmp = mapper.writeValueAsString(feature.getProperties());
				FeaturesResponse.Properties property = mapper.readValue(tmp, Properties.class);
				res.getFeatures().add(Feature.builder()
						.geometry(geom)
						.properties(property)
						.build());
			} catch (JsonProcessingException | ParseException e) {
				throwDynamicException("", tenantId, new Object(), cuaa, e.getMessage());
				throw new RuntimeException("Error processing response", e);
			}
		});
		return res;
	}

	// Send Party Request

	// Send Declaration
	public EditDeclarationResult insertDeclaration(User user, String tenantId, Integer bussinesId, Integer cropPlanId,
			String domainZoneCode, String plotCode,
			DeclarationPayload request) {
		String url = String.format("%s/%s/public/v1/crop-plans/%s/plans/%s/domains/%s/plots/%s/decls?autoLock=true",
				cropPlanUrl,
				tenantId, bussinesId, cropPlanId,
				domainZoneCode, plotCode);
		return sendPostRequest(tenantId, url, request, EditDeclarationResult.class, "insertDeclaration");
	}

	// Delta Import logic implementation
	public RecordResponse<PlotDataResponse> listOfPlots(String tenantId, Integer businessId, Integer cropPlanId,
			String pointInTime) {
		Object[] args = { cropPlanUrl, tenantId, businessId, cropPlanId };
		ArrayList<PlotDataResponse> dt = new ArrayList<>();
		String nextKey = null;
		do {
			String url = String.format("%s/%s/public/v1/crop-plans/%s/plans/%s/plots", args);
			url = url + (pointInTime != null ? "?pointInTime=" + pointInTime : "");
			url = url + (nextKey != null ? "&nextKey=" + nextKey : "");
			var data = sendGetRequestWithAuth(url, new TypeReference<RecordResponse<PlotDataResponse>>() {
			}, "getCropPlans", tenantId);
			dt.addAll(data.getRecords());
			nextKey = data.getNextKey();
		} while (nextKey != null);

		RecordResponse<PlotDataResponse> list = new RecordResponse<>();
		list.setRecords(dt);
		return list;
	}

	private List<PlotFeatureBindingDTO> findMatches(List<Feature> features,
			RecordResponse<PlotDataResponse> plots) {

		List<PlotFeatureBindingDTO> matchedPlotFeatures = new ArrayList<>();
		for (PlotDataResponse plot : plots.getRecords()) {
			if (plot.getDecls() == null || plot.getDecls().isEmpty()) {
				continue;
			}

			var firstDecl = plot.getDecls().get(0);
			boolean matchFound = false;

			for (Feature feature : features) {
				var props = feature.getProperties();
				if (props == null || props.getIdAppeLast() == null)
					continue;

				for (var fc : firstDecl.getFieldsCodes()) {
					if (fc.getFieldCode().equalsIgnoreCase("identificativoAppezzamento") &&
							fc.getValue().equals(props.getIdAppeLast())) {

						matchedPlotFeatures.add(new PlotFeatureBindingDTO(plot, feature));
						matchFound = true;
						break;
					}
				}

				if (matchFound)
					break;
			}
		}

		return matchedPlotFeatures;
	}

	private void interSectionWithDomainsV2(User user, String tenant, Feature feature, PartyResponse businessResult,
			int cropPlanId, PlotDataResponse plot) {

		try {
			Properties property = feature.getProperties();
			if (plot == null) {
				// Add New Plot
				IntersectionResponse intersectionResult = SendIntersectionRequest(feature.getGeometry(), tenant,
						property.getCodiceEpsg());
				sendInsertPlotRequest(user, tenant, feature, businessResult, cropPlanId, property, intersectionResult);
			} else {
				sendUpdatePlotRequest(user, tenant, feature, businessResult, cropPlanId, property,
						plot.getDomainZoneId(),
						plot.getPlotCode());
				updateDecalartionsPlot(user, tenant, feature, businessResult, cropPlanId, plot, plot.getDomainZoneId());
			}
		} catch (Exception e) {
			checkResponseStatus(null, "", tenant, null, "interSectionWithDomainsV2", e, null);
			throw new RuntimeException(e);
		}
	}

	private void sendInsertPlotRequest(User user, String tenant, Feature feature, PartyResponse businessResult,
			Integer CropPlanId, Properties property,
			IntersectionResponse intersectionResult) {
		PlotCropPlanRequest.CutParameters cutParameters = new PlotCropPlanRequest.CutParameters();
		cutParameters.setBehaviour("CUT_ON_EXISTING");
		PlotCropPlanRequest plotRequest = PlotCropPlanRequest.builder()
				.geom(feature.getGeometry())
				.fromPointInTime(AbsoluteDate.of(LocalDate.parse(property.getDataInizAppe(), FORMATTER)).toString())
				.cutParameters(cutParameters)
				.build();

		String domainZoneCode = intersectionResult.getFields().get("sector");
		var plotResult = plotCropPlan(tenant, businessResult.getId(), CropPlanId, domainZoneCode, plotRequest);
		if (plotResult == null) {
			throw new RuntimeException("Not Able to insert new plot");
		}

		sendPlotDeclaration(user, tenant, feature, businessResult, CropPlanId, property, domainZoneCode, plotResult);
	}

	private void sendUpdatePlotRequest(User user, String tenant, Feature feature, PartyResponse businessResult,
			Integer cropPlanId, Properties property,
			String domainZone, String plotCode) {
		PlotCropPlanRequest.CutParameters cutParameters = new PlotCropPlanRequest.CutParameters();
		cutParameters.setBehaviour("CUT_EXISTING");
		cutParameters.setPlotCodes(List.of(plotCode));
		PlotCropPlanRequest plotRequest = PlotCropPlanRequest.builder()
				.geom(feature.getGeometry())
				.fromPointInTime(AbsoluteDate.of(LocalDate.parse(property.getDataInizAppe(), FORMATTER)).toString())
				.cutParameters(cutParameters)
				.build();

		Object[] args = { cropPlanUrl, tenant, businessResult.getId(), cropPlanId, domainZone, plotCode };
		String url = String.format("%s/%s/api-priv/v1/crop-plans/%s/plans/%s/%s/plots/%s",
				args);
		var plotResult = sendPutRequest(tenant, url, plotRequest, PlotCropPlanResponse.class,
				"UpdatePlotRequestFormatter");
		if (plotResult == null) {
			throwDynamicException(url, tenant, new Object(), "plotCropPlan",
					"Error on plots creation: DomainZone:" + domainZone);
		}
		PlotDataResponse mainUpdatedPlot = findMainPlot(plotResult.getUpdated());
		if (mainUpdatedPlot == null) {
			var exception = new Exception("Not Able to update  plot");
			checkResponseStatus(null, url, tenant, plotRequest, "UpdatePlotRequestFormatter", exception, null);
			throw new RuntimeException(exception);
		}
	}

	public void updateDecalartionsPlot(User user, String tenant, Feature feature, PartyResponse businessResult,
			int cropPlanId, PlotDataResponse plot, String domainZoneCode)
			throws IOException {
		var property = feature.getProperties();
		var remocedDeclaration = new ArrayList<PlotDataResponse.Declaration>();
		for (var decl : plot.getDecls()) {
			decl.setLanduseCode(decl.getLanduse().getCode());
			// DeletionPart SerchForColtivazioni, If i dont found then delete decl otherwise
			// we do nothing
			var existDecl = searchForDeclaration(feature, decl);
			if (existDecl == null) {
				// Delete Decl Method
				deleteDeclarationRequest(tenant, businessResult.getId(), cropPlanId, domainZoneCode, plot.getPlotCode(),
						decl.getDeclCode());
				remocedDeclaration.add(decl);
			}
			// else {
			//
			// setFieldValueByType(decl.getFieldsCodes(), "identificativoPianoColtivazione",
			// property.getIdPcgVers());
			// setFieldValueByType(decl.getFieldsCodes(), "identificativoAppezzamento",
			// property.getIdentificativoAppezzamento());
			// updateDeclarationRequest(tenant, businessResult.getId(), cropPlanId,
			// domainZoneCode,
			// plot.getPlotCode(), decl, decl.getDeclCode());
			// }
		}

		if (!remocedDeclaration.isEmpty()) {
			var declCode = remocedDeclaration.stream().map(x -> x.getDeclCode()).toList();
			plot.setDecls(plot.getDecls().stream()
					.filter(x -> declCode.contains(x.getDeclCode()))
					.toList());
		}

		for (var colt : property.getColtivazioni()) {
			// apply same logic SearchForPlot "SearchForDecl" , if return null create new
			// decl otherwise is update
			if (colt.getIdColtLast() == null || colt.getIdColtLast().isEmpty()) {
				addNewDeclaration(user, tenant, feature, businessResult, cropPlanId, domainZoneCode, plot, colt);
				continue;
			}

			AdditionalField currentFieldCode = null;
			for (var decl : plot.getDecls()) {
				decl.setLanduseCode(decl.getLanduse().getCode());

				currentFieldCode = decl.getFieldsCodes().stream()
						.filter(x -> Objects.equals("idColt", x.getFieldCode())
								&& Objects.equals(x.getValue(), colt.getIdColtLast()))
						.findFirst()
						.orElse(null);

				if (currentFieldCode != null) {
					DeclarationPayload newDecl = newDeclarationPayload(feature, colt, plot);
					newDecl.setDeclCode(decl.getDeclCode());
					setFieldValueByType(decl.getFieldsCodes(), "identificativoPianoColtivazione",
							property.getIdPcgVers());
					setFieldValueByType(decl.getFieldsCodes(), "identificativoAppezzamento",
							property.getIdentificativoAppezzamento());
					updateDeclarationRequest(tenant, businessResult.getId(), cropPlanId, domainZoneCode,
							plot.getPlotCode(), newDecl, decl.getDeclCode());

					break;
				}
			}

			if (currentFieldCode == null) {
				addNewDeclaration(user, tenant, feature, businessResult, cropPlanId, domainZoneCode, plot, colt);
			}
		}
	}

	private DeclarationPayload newDeclarationPayload(Feature feature, FeaturesResponse.Coltivazione coltivazione,
			PlotDataResponse mainAddedPlot) {
		DeclarationPayload payload = new DeclarationPayload();
		try {

			FeaturesResponse.Properties properties = feature.getProperties();
			double areaPerc = (coltivazione.getSupeColt() / mainAddedPlot.getAreaSqm()) * 100.0;
			payload.setAreaPerc(areaPerc);
			String landuseCode = String.join("-",
					coltivazione.getCodiOccu(),
					coltivazione.getCodiDestUsoo(),
					coltivazione.getCodiUsoo(),
					coltivazione.getCodiQual(),
					coltivazione.getCodiOccuVari());
			payload.setLanduseCode(landuseCode);
			payload.setFromDate(
					AbsoluteDate.of(LocalDate.parse(coltivazione.getDataInizColt(), FORMATTER)).toString());
			payload.setToDate(AbsoluteDate.of(LocalDate.parse(coltivazione.getDataFineColt(), FORMATTER)).toString());
			payload.setFromDatePrecision("YMD");

			List<DeclarationPayload.FieldCode> fieldsCodes = new ArrayList<>();
			fulfillColtivazioni(coltivazione, fieldsCodes);
			fulfillFeatures(properties, coltivazione, fieldsCodes);
			payload.setFieldsCodes(fieldsCodes);
			payload.setRemoveExistingDeclarations(false);

		} catch (Exception e) {
			checkResponseStatus(null, "", "", feature, "FulFillEntity", e, null);
			throw new RuntimeException(e);
		}
		return payload;
	}

	public PlotDataResponse.Declaration searchForDeclaration(Feature feature,
			PlotDataResponse.Declaration decl)
			throws IOException {
		var property = feature.getProperties();
		for (var fc : decl.getFieldsCodes()) {
			if (fc.getFieldCode().equalsIgnoreCase("idColt")) {
				var existingColt = property.getColtivazioni().stream()
						.filter(x -> Objects.equals(x.getIdColtLast(), fc.getValue()))
						.findFirst()
						.orElse(null);
				if (existingColt != null) {
					return decl;
				}
			}
		}
		return null;
	}

	// Actions
	private void sendPlotDeclaration(User user, String tenant, Feature feature, PartyResponse bussinesResult,
			Integer CropPlanId, Properties property,
			String domainZoneCode, PlotDataResponse mainAddedPlot) {
		property.getColtivazioni().forEach(coltivazione -> {
			log.debug("Send Plot Decl DomainId {} Coltivazioni: {}", domainZoneCode, coltivazione.getIdColt());
			DeclarationPayload del = newDeclarationPayload(feature, coltivazione, mainAddedPlot);
			insertDeclaration(user, tenant, bussinesResult.getId(), CropPlanId, domainZoneCode,
					mainAddedPlot.getPlotCode(), del);
			log.debug("------------------------------------------------------------------------------");
		});
	}

	private void addNewDeclaration(User user, String tenant, Feature feature, PartyResponse bussinesResult,
			Integer cropPlanId, String domainZoneCode, PlotDataResponse mainAddedPlot,
			FeaturesResponse.Coltivazione coltivazione) {
		DeclarationPayload del = null;
		del = newDeclarationPayload(feature, coltivazione, mainAddedPlot);
		insertDeclaration(user, tenant, bussinesResult.getId(), cropPlanId, domainZoneCode,
				mainAddedPlot.getPlotCode(), del);
	}

	// Send Declaration
	public EditDeclarationResult insertDeclarationOnUpdatePlot(String tenantId, Integer bussinesId, Integer cropPlanId,
			String domainZoneCode, String plotCode,
			PlotDataResponse.Declaration request) {
		String url = String.format("%s/%s/public/v1/crop-plans/%s/plans/%s/domains/%s/plots/%s/decls", cropPlanUrl,
				tenantId, bussinesId, cropPlanId,
				domainZoneCode, plotCode);
		return sendPostRequest(tenantId, url, request, EditDeclarationResult.class, "insertDeclaration");
	}

	public EditDeclarationResult updateDeclarationRequest(String tenantId, Integer bussinesId,
			Integer cropPlanId, String domainZoneCode, String plotCode,
			DeclarationPayload request, String declCode) {
		String url = String.format("%s/%s/public/v1/crop-plans/%s/plans/%s/zones/%s/plots/%s/decls/%s", cropPlanUrl,
				tenantId, bussinesId, cropPlanId,
				domainZoneCode, plotCode, declCode);
		return sendPutRequest(tenantId, url, request, EditDeclarationResult.class, "UpdateDeclarationRequest");
	}

	public DeleteDeclarationResponse deleteDeclarationRequest(String tenantId, int bussinesId, int cropPlanId,
			String domainZoneCode, String plotCode, String declCode) {
		String url = String.format("%s/%s/public/v1/crop-plans/%s/plans/%s/zones/%s/plots/%s/decls/%s", cropPlanUrl,
				tenantId, bussinesId, cropPlanId,
				domainZoneCode, plotCode, declCode);
		return sendDeleteRequest(tenantId, url, null, DeleteDeclarationResponse.class, "DeleteDeclarationRequest");
	}

	public PlotCropPlanResponse deletePlotRequest(String tenant, int bussinesId, Integer cropPlanId,
			String domainZoneCode, String plotCode, String fromDate) {
		String url = String.format(
				"%s/%s/api-priv/v1/crop-plans/%s/plans/%s/%s/plots/%s?ignoreDeclValidationWarnings=true&fromPointInTime=%s",
				cropPlanUrl, tenant, bussinesId, cropPlanId,
				domainZoneCode, plotCode, fromDate);
		return sendDeleteRequest(tenant, url, null, PlotCropPlanResponse.class, "DeletePlotRequest");
	}

	private record FromTo(LocalDate from, LocalDate to) {
	}

	private record DeclarationWithFields(Declaration decl, List<AdditionalField> fields) {
	}

}
