
package com.abacogroup.gari.dataimporter.soap.fascicolo;

import java.util.ArrayList;
import java.util.List;
import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlRootElement;
import jakarta.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="CuaaSocio" type="{http://cooperazione.sian.it/schema/fascicolo}Cuaa"/&gt;
 *         &lt;element name="DatiAssociazione" type="{http://cooperazione.sian.it/schema/fascicolo}ISWSDatiSocio" maxOccurs="unbounded"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "cuaaSocio",
    "datiAssociazione"
})
@XmlRootElement(name = "ISWSDatiSoci")
public class ISWSDatiSoci {

    @XmlElement(name = "CuaaSocio", required = true)
    protected String cuaaSocio;
    @XmlElement(name = "DatiAssociazione", required = true, nillable = true)
    protected List<ISWSDatiSocio> datiAssociazione;

    /**
     * Gets the value of the cuaaSocio property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCuaaSocio() {
        return cuaaSocio;
    }

    /**
     * Sets the value of the cuaaSocio property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCuaaSocio(String value) {
        this.cuaaSocio = value;
    }

    /**
     * Gets the value of the datiAssociazione property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the Jakarta XML Binding object.
     * This is why there is not a <CODE>set</CODE> method for the datiAssociazione property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getDatiAssociazione().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ISWSDatiSocio }
     * 
     * 
     */
    public List<ISWSDatiSocio> getDatiAssociazione() {
        if (datiAssociazione == null) {
            datiAssociazione = new ArrayList<ISWSDatiSocio>();
        }
        return this.datiAssociazione;
    }

}
