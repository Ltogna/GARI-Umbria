
package com.abacogroup.gari.dataimporter.soap.fascicolo;

import java.util.ArrayList;
import java.util.List;
import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ISWSRespOA complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ISWSRespOA"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="CuaaAzieOA" type="{http://cooperazione.sian.it/schema/fascicolo}Cuaa"/&gt;
 *         &lt;element name="DenomAzieOA"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;minLength value="1"/&gt;
 *               &lt;maxLength value="150"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="TipoLegaAsso"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="DescrLegaAsso"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;minLength value="1"/&gt;
 *               &lt;maxLength value="200"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="Socio" type="{http://cooperazione.sian.it/schema/fascicolo}ISWSRespSoci" maxOccurs="unbounded" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ISWSRespOA", propOrder = {
    "cuaaAzieOA",
    "denomAzieOA",
    "tipoLegaAsso",
    "descrLegaAsso",
    "socio"
})
public class ISWSRespOA {

    @XmlElement(name = "CuaaAzieOA", required = true)
    protected String cuaaAzieOA;
    @XmlElement(name = "DenomAzieOA", required = true)
    protected String denomAzieOA;
    @XmlElement(name = "TipoLegaAsso", required = true)
    protected String tipoLegaAsso;
    @XmlElement(name = "DescrLegaAsso", required = true)
    protected String descrLegaAsso;
    @XmlElement(name = "Socio", nillable = true)
    protected List<ISWSRespSoci> socio;

    /**
     * Gets the value of the cuaaAzieOA property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCuaaAzieOA() {
        return cuaaAzieOA;
    }

    /**
     * Sets the value of the cuaaAzieOA property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCuaaAzieOA(String value) {
        this.cuaaAzieOA = value;
    }

    /**
     * Gets the value of the denomAzieOA property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDenomAzieOA() {
        return denomAzieOA;
    }

    /**
     * Sets the value of the denomAzieOA property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDenomAzieOA(String value) {
        this.denomAzieOA = value;
    }

    /**
     * Gets the value of the tipoLegaAsso property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTipoLegaAsso() {
        return tipoLegaAsso;
    }

    /**
     * Sets the value of the tipoLegaAsso property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTipoLegaAsso(String value) {
        this.tipoLegaAsso = value;
    }

    /**
     * Gets the value of the descrLegaAsso property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDescrLegaAsso() {
        return descrLegaAsso;
    }

    /**
     * Sets the value of the descrLegaAsso property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDescrLegaAsso(String value) {
        this.descrLegaAsso = value;
    }

    /**
     * Gets the value of the socio property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the Jakarta XML Binding object.
     * This is why there is not a <CODE>set</CODE> method for the socio property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getSocio().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ISWSRespSoci }
     * 
     * 
     */
    public List<ISWSRespSoci> getSocio() {
        if (socio == null) {
            socio = new ArrayList<ISWSRespSoci>();
        }
        return this.socio;
    }

}
