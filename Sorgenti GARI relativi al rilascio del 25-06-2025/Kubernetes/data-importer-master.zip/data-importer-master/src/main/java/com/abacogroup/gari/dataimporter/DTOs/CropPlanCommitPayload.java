package com.abacogroup.gari.dataimporter.DTOs;

import java.time.LocalDateTime;

import groovyjarjarantlr4.v4.runtime.misc.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class CropPlanCommitPayload {
	@NotNull
	private String tenant;

	@NotNull
	private Long businessId;

	@NotNull
	private Long cropPlanId;

	@NotNull
	private String cropPlanTypeCode;

	@NotNull
	private String version;

	@NotNull
	private LocalDateTime versionDate;

	// @NotBlank(groups = ConsumerValidation.class) // custom publish consumer validation
	// private String referenceDate;

	// @NotNull
	// private String username;
}
