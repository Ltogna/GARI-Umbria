package com.abacogroup.gari.dataimporter.DTOs;

import java.util.Map;

import org.locationtech.jts.geom.Geometry;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.NoArgsConstructor;

@JsonIgnoreProperties(ignoreUnknown = true)
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class IntersectionResponse {

	@JsonProperty("id")
	private String id;

	@JsonProperty("label")
	private String label;

	// @JsonDeserialize(using = GeometryDeserializer.class)
	@JsonProperty("geometry")
	private Geometry geometry;

	@JsonProperty("srs")
	private String srs;

	@JsonProperty("areaSqm")
	private double areaSqm;

	@JsonProperty("fields")
	private Map<String, String> fields;

	// Getters and Setters
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getLabel() {
		return label;
	}

	public void setLabel(String label) {
		this.label = label;
	}

	public Geometry getGeometry() {
		return geometry;
	}

	public void setGeometry(Geometry geometry) {
		this.geometry = geometry;
	}

	public String getSrs() {
		return srs;
	}

	public void setSrs(String srs) {
		this.srs = srs;
	}

	public double getAreaSqm() {
		return areaSqm;
	}

	public void setAreaSqm(double areaSqm) {
		this.areaSqm = areaSqm;
	}

	public Map<String, String> getFields() {
		return fields;
	}

	public void setFields(Map<String, String> fields) {
		this.fields = fields;
	}
}
