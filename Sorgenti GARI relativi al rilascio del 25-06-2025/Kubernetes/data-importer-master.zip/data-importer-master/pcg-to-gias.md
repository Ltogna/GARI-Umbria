# Add a new API related to the crop plan
This API will be called by another software to get the crop plan data from our system.

## API to get the crop plans
GET /{tenant}/public/v1/pcg/{cuaa}

Given the `CUAA` it must get the `businessId` as the import API is doing; then:
* GET {{base}}/crop-plan-api/master/public/v1/crop-plans/{businessId}/plans?cropPlanTypeCode=CROPPLAN
  * read the cropPlanId 
* GET {{base}}/crop-plan-api/master/public/v1/crop-plans/{businessId}/plans/{cropPlanId}/versions
  * Read all the versions and sort them by versionDate; by now, consider only the greatest (but we will need the others as well later)
* GET {{base}}/crop-plan-api/master/public/v1/crop-plans/{businessId}/plans/{cropPlanId}/plots?pointInTime={year from versionReferenceDate}1111&pointInTimeTo={year from versionReferenceDate}1110&excludes=ANOMALIES&excludes=DECLARATIONS_PESTICIDES&excludes=DECLARATIONS_PLOT_STYLE&excludes=PARCELS
  
The API must return an object with this shape; comments indicates the field we are getting the value from:

```json
{
    "id_appezzamento": "1522173558", // plotId
    "denominazione": "1522173558", // description
    "cod_nazionale": "F605", // domainZoneId
    "area_mq": 670, // areaSqm
    "data_inizio_validita": "2022-05-12", // fromDate
    "data_fine_validita": "2023-05-11", // toDate
    "id_appezzamento_padre": "1522173558", // plotId
    "gis": {
        "sr_code": "EPSG:32632", // srs
        "wkt": "POLYGON ...." // geom
    },
    "dichiarazioni": [ // decls
        {
            "id_dichiarazione": "25866314-1-1", // declCode
            "codice_coltura": "410-009-000-000-000", // code
            "coltura": "410-009-000-000-000 - NESSUNA VARIETA'", // description
            "area_mq": 670, // round(plot.areaSqm * areaPerc / 100)
            "data_inizio_validita": "2022-05-12", // fromDate
            "data_fine_validita": "2023-05-11", // toDate
            "data_impianto": "2019-07-01-01", // null
            "bbch": [], // null
            "protocolli": [], // null
            "chiave": {
                "idColt": "1522173558" // vale of field: idColt
            },

            // Almost all the elements of this element works the same:
            // there is a pair of attributes like: zootechnical_effluents_id and zootechnical_effluents
            // the one that does non end with `_id` is created starting from one of our `fieldCodes`; if the value of the fieldCode is null, then all the attribute is set to null and also the one ending in _id. i.e.: see company_structures in the folloeing attributes
            // the one ending in _id always have a value of 1 (when not null)
            //  type is the camelCase version of the snake_case key; i.e.: zootechnical_effluents has a type of: ZootechicsalEffluents
            // code is our field `value`
            // key is always null
            // name is our field `fieldDescription`
            // created_at and updasted_at are both set to the value of dayFrom
            // deleted_at is always null
            "datiAggiuntiviPCG": { // taken from "fieldCodes"
                "zootechnical_effluents_id": 1,
                "zootechnical_effluents": { // from field: effluentiZootecnici
                    "type": "ZootechicsalEffluents",
                    "id": 1,
                    "code": null, // value
                    "key": null,
                    "name": "No", // valueDescription
                    "created_at": 1711557960,
                    "updated_at": 1711557960,
                    "deleted_at": null
                },
                "irrigation_potential_id": 1,
                "irrigation_potential": { // from field: potenzialitaIrrigua
                    "type": "IrrigationPotential",
                    "id": 1,
                    "code": null,
                    "key": "0",
                    "name": "No",
                    "created_at": 1711557960,
                    "updated_at": 1711557960,
                    "deleted_at": null
                },
                "company_structures_id": null,
                "company_structures": null, // from field: struttureAziendali
                "sowing_type_id": 1,
                "sowing_type": {
                    "type": "SowingType",
                    "id": 1,
                    "code": "70023",
                    "key": "1",
                    "name": "TRADIZIONALE",
                    "created_at": 1711558018,
                    "updated_at": 1711558018,
                    "deleted_at": null
                },
                "breeding_phase_id": null, // from field: faseAllevamento
                "breeding_phase": null,
                "breeding_form_id": null,
                "breeding_form": null,  // from field: formaDiAllevamento
                "breeding_type_id": 2, // from field: tipoDiAllevamento
                "breeding_type": {
                    "type": "BreedingType",
                    "id": 2,
                    "code": "4102",
                    "key": "102",
                    "name": "ALBERELLO - CORDONE SPERONATO",
                    "created_at": 1711557936,
                    "updated_at": 1711557936,
                    "deleted_at": null
                },
                "irrigation_type_id": 2, // from field: tipoIrrigazione
                "irrigation_type": {
                    "type": "IrrigationType",
                    "id": 2,
                    "code": "4152",
                    "key": "1",
                    "name": "Non irrigato",
                    "created_at": 1711557969,
                    "updated_at": 1711557969,
                    "deleted_at": null
                },
                "year_month": "2019-07-01" // value of field: annoMese
            }
        }
    ],
    "ultimo_aggiornamento": "2024-09-21T04:13:57+01:00", // versionDate

    // This is computed from the first or the last declaration (they all share the same values for these specific fields)
    "chiave": {
        "idSchedaValidazione": "412200201", // value of field: idSchedaValidazione
        "identificativoPianoColtivazione": "412200191",// value of field: identificativoPianoColtivazione
        "codiBarrSchedaValidazione": "2024DUA0000MCHSRA87T47I726K0000000003",// always null
        "identificativoIsola": "124718937",// value of field: identificativoIsola
        "identificativoAppezzamento": "1522173547",// value of field: identificativoAppezzamento
        "idAppezzamentoOrig": null// always null
    }
}
```

# Delta handling

NOTE: Replace `plotId` with `plotCode`   

API to implement:
GET /{tenant}/public/v1/pcg/{cuaa}/aggiornamento?ref_timestamp=<OffsetDateTime>

Given the `CUAA` it must get the `businessId` as the import API is doing; then

We get the crop plan id:
GET {{base}}/crop-plan-api/master/public/v1/crop-plans/{businessId}/plans?cropPlanTypeCode=CROPPLAN

We read all the versions:
GET {{base}}/crop-plan-api/master/public/v1/crop-plans/{businessId}/plans/{cropPlanId}/versions
  * Read all the versions and sort them by versionDate; all the versions with a date less then `ref_timestamp` need to be discarded
  * We then keep only 2 versions: 
    * amongst the ones where `versionDate < ref_timestamp` we keep the one with the greatest `versionDate`
    * the latest one

As an example, given these versions:
```json
{
  "nextKey": null,
  "records": [
    {
      "version": "C",
      "versionDate": "2024-12-18T15:23:52",
      "versionReferenceDate": "20241218",
      "message": "25254850",
      "userId": "MASTER/IMPORT_SERVICE_ACCOUNT",
      "flPublished": true
    },
    {
      "version": "B",
      "versionDate": "2024-12-15T10:43:37",
      "versionReferenceDate": "20241215",
      "message": "25254849",
      "userId": "MASTER/IMPORT_SERVICE_ACCOUNT",
      "flPublished": true
    }
    {
      "version": "A",
      "versionDate": "2024-12-10T09:43:41",
      "versionReferenceDate": "20241210",
      "message": "25254848_",
      "userId": "MASTER/IMPORT_SERVICE_ACCOUNT",
      "flPublished": true
    }
  ],
  "count": 3
}
```
and this parameter passed in: `ref_timestamp=2024-12-10T09:43:42`
We will keep versions: A and C

We then read the crop plans at both versions:
GET {{base}}/crop-plan-api/master/public/v1/crop-plans/{businessId}/plans/{cropPlanId}/plots?pointInTime={year from versionReferenceDate - 1}1111&pointInTimeTo={year from versionReferenceDate}1110&excludes=ANOMALIES&excludes=DECLARATIONS_PESTICIDES&excludes=DECLARATIONS_PLOT_STYLE&excludes=PARCELS&version=<the version>

We need to find the differences (at plot level) between the oldest and the newer versions, comparing using the `plotCode` field:
* if a plot is present in the old version and is not present in the new version: mark it as deleted
* if a plot is present in both versions and also have the same `plotId` ignore it
* if a plot is present in both versions with different `plotId`s mark it as "updated"
* if a plot is only in the new version, mark it as "new"

WARNING: In order to compute the delta, we need to read all records recursivelly.

The API response is an `InfiniteResult` with all the records (not paginated); the record shape is the same of the previous API but with an additional field named `tipo_modifica`:
* for "new" plots: we return the same info as the "original" API we already developed; `tipo_modifica` must be set to `I`
* for "updated" plots: we return the same info as the "original" API we already developed; `tipo_modifica` must be set to `A`
* for "deleted" plots, we return this:

```json
{
    "id_appezzamento": "1522173558", // plotCode
    "id_appezzamento_padre": "1522173558", // plotCode
    "tipo_modifica": "C",
    ... everything else will be set as null ....
}
```

# Notification to GIAS that new data is ready

## Configuration params:
* GIAS BASE URL (https://reumbriacollaudo23_27.netagronica.it for dev)
* login token
* GIAS notification interval (set it to 10 mins but we could have to chantge it)

## Authentication to call GIAS APIs

POST {GIAS BASE URL}/AgronicaCoreApi/Login/BackgroundAuthentication
```json
{
  "token": <login token from config>
}
```

Reply:
```json
{
  "RispostaOK": true,
  "RispostaStringa": "ey..."
}
```
If `RispostaOK` != true then error
Read the value of `RispostaStringa`, this value will be used in the `Authentication: Bearer <token>` header

## Tables

dataimporter_notifications_dates:
* party_id (PK)
* fl_party_version
* dt_party_version
* fl_pcg_version
* dt_pcg_version

dataimporter_notifications:
* uid (PK)
* party_id
* dt_sent
* dt_response
* response_payload

## Messages from rabbitmq

When we receive a message related to a new crop plan version or a party registry change, we will update `dataimporter_norifications_dates` for the party_id.
The flags are computed this way:
* if the record is missing for the party, then the flag is 'C'
* if the date is null, then the flag is 'C'
* otherwise the flag is 'U'

## Database Queue

We need 2 (more) queues:
* ScheduledQueue:
  * configured with 1 thread
  * runs every `GIAS notification interval` minutes
  * `select * from dataimporter_notifications_dates d where fl_party_version is not null and fl_pcg_version is not null and  not exists (select 1 from dataimporter_notifications n where n.party_id=d.party_id and dt_response is null)`
  * for each record:
   --Comment  * insert a record in the second table using the dates from `dataimporter_notifications_dates`
    * insert a record in dataimporter_notifications (with a new ULID)
* WorkQueue:
  * configured with 10 threads
  * runs ASAP
  * notifies GIAS, only for a single flag type, C first; if both flags are the same then we can send a single notifications wiht all of them
  * Update dataimporter_notifications set dt_sent = $current time stamp$ where uid = ulid

## Notification to GIAS

POST {GIAS BASE URL}/AgronicaCoreApi/Notification/NotificaCUAA
c u  = c
anagrafica(party) with data
pcg will be null

c  c = c
anagrafica(party) with data
pcg with data

u u  = u
anagrafica(party) with data
pcg with data

u c  = c
anagrafica(party) will be null
pcg with data



```json
{
  "ID_ExternalSystem": "NEWAGRI",
  "elencoCUAA": [
    {
      "CUAA": "11680461008",
      "Campagna" : 2023,
      "Operazione" : "C/U",
      "Dettaglio" : {
        "anagrafica" : {  // can be null if 
          "DataOraNotifica": "2023-08-28T16:29:39.605Z"
        },
        "pcg" : {
          "DataOraNotifica": "2023-08-28T16:29:39.605Z"
        },
      },
      "id_signal" : "<ulid>"
    }
  ]
}

```


u u  = u
## Async response from GIAS

GIAS will call this API

POST /{tenant}/public/v1/sync/{ulid}
```json
{
  "processed": true,
  "entities": [
    {
      "entity": "azienda|pcg|terreni|pcg-terreni|equipaggiamenti",
      "ref_timestamp": "2025-01-01...."
    }
  ],
  "errors": [
    {
      "code": "...",
      "msg": "...",
      "key": "..."
    }
  ]
}
```

Reply:
```json
{
  "ack": true
}
```

the API will:
* `update dataimporter_notifications where uid=<received ulid> set dt_response=§current_timestamp§, payload=<received payload serialized to json>`
* if no records where updated then error
* Id one of the entities is `azienda`:
  * `update dataimporter_notifications_dates set dt_party_version=null, fl_party_version = null where party_id=<party_id from current uid> and dt_party_version <= <ref_timestamp>`
* Id one of the entities is `pcg`:
  * `update dataimporter_notifications_dates set dt_pcg_version=null, fl_pcg_version = null where party_id=<party_id from current uid> and dt_pcg_version <= <ref_timestamp>`
  
