# Track requests

Table: TrackRequest
request id uuid (PK)
user id
cuaa
campagna
dt_request
fl_staus (PENDING, DONE, ERRuR)

## Use ULID as request_id

		<dependency>
			<groupId>io.azam.ulidj</groupId>
			<artifactId>ulidj</artifactId>
			<version>1.0.4</version>
		</dependency>

ULID.random(ThreadLocalRandom.current())
