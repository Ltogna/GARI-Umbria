# Bulk business import

cuaa: SRDMRS49P46C309O


## Import a business:
	https://umbria-dev.fe.abacogroup.eu/party-registry/master/api-priv/v1/parties/external/check-existence/source/SIAN/party/SRDMRS49P46C309O?_nc=1743066092645
	https://umbria-dev.fe.abacogroup.eu/party-registry/master/api-priv/v1/parties/external?_nc=1743066092647

## Crete a dossier:
	https://umbria-dev.fe.abacogroup.eu/dossiers/master/api-priv/v1/dossiers-async?_nc=1743066503706
			{"partyId":72,"moduleCode":"FARMER-REGISTRY","sectorCode":"FASCICOLO","year":2024}
	https://umbria-dev.fe.abacogroup.eu/dossiers/master/api-priv/v1/dossiers/641/is-in-transition?_nc=1743066503707

## Import crop plan
	we know very well...
	
-------------------------------------------------

## Import flow

data-import:
```
	- new API that receives a set of CUAAs as POST
	- 3 new embedded db queues:
		- 1: import business details, on success,
				- update dataimporter_paryt_bulk_load set party_id=<the created one>, last_ok_step=1
				- insert the generated party_id into queue2
		- 2: create the dossier and wait for creation, on success:
				- update dataimporter_paryt_bulk_load set last_ok_step=2
				- insert the generated dossier id and party id in queue3
		- 3: import the crop plan for the party id
				- update dataimporter_paryt_bulk_load set last_ok_step=3, import_status=DONE
	
	Create a new table: dataimporter_paryt_bulk_load
		- ulid
		- cuaa
		- party_id (initiallt null)
		- dt_start
		- dt_end
		- last_ok_step (initially null)
		- import_status (initially TODO) then queue 1 set it to IN_PROGRESS and it is set to ERROR if any error occurs and DONE at the end of queue3
```