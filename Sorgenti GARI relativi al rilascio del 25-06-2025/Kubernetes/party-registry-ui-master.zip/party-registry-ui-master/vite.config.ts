import vue from "@vitejs/plugin-vue";
import { execSync } from "child_process";
import { fileURLToPath, URL } from "url";
import { defineConfig } from "vite";
import { viteStaticCopy } from "vite-plugin-static-copy";
import nodePackage from "./package.json";
import { BASE } from "./src/constants";
import VueDevTools from "vite-plugin-vue-devtools";

process.env.VITE_APP_VERSION = nodePackage.version;
process.env.VITE_APP_GIT_COMMIT = execSync("git rev-parse --short=8 HEAD").toString().trim();

// https://vitejs.dev/config/
export default defineConfig({
    base: BASE,
    plugins: [
        viteStaticCopy({
            targets: [
                {
                    src: "node_modules/bootstrap-italia/dist/**/*",
                    dest: "bootstrap-italia/dist",
                },
                {
                    src: "node_modules/patri-common-ui/public/locales/*",
                    dest: "locales/common",
                },
            ],
        }),
        vue(),
        VueDevTools(),
    ],
    resolve: {
        alias: {
            "@": fileURLToPath(new URL("./src", import.meta.url)),
        },
    },
    css: {
        devSourcemap: true,
    },
    build: {
        target: "esnext",
        rollupOptions: {
            output: {
                entryFileNames: "[name].[hash].js",
                assetFileNames: "assets/[name].[hash].[ext]",
            },
        },
    },
    server: {
        port: 3000,
        proxy: {
            "/sso2": {
                target: "https://apps-test.opr.fvg.it/",
                // target: "https://iacs-dev.fe.abacogroup.eu/",
                // target: "https://patri-renew-dev.fe.abacogroup.eu/",
                secure: false,
                changeOrigin: true,
            },
            "/party-registry": {
                target: "https://apps-test.opr.fvg.it/",
                // target: "https://iacs-dev.fe.abacogroup.eu/",
                // target: "https://patri-renew-dev.fe.abacogroup.eu/",
                secure: false,
                changeOrigin: true,
            },
            "/lau-service": {
                target: "https://apps-test.opr.fvg.it/",
                // target: "https://iacs-dev.fe.abacogroup.eu/",
                // target: "https://patri-renew-dev.fe.abacogroup.eu/",
                secure: false,
                changeOrigin: true,
            },
            "/file-store": {
                target: "https://apps-test.opr.fvg.it/",
                // target: "https://iacs-dev.fe.abacogroup.eu/",
                // target: "https://patri-renew-dev.fe.abacogroup.eu/",
                changeOrigin: true,
                secure: true,
            },
            "/party-registry-dynamic-docs": {
                target: "https://apps-test.opr.fvg.it/",
                // target: "https://iacs-dev.fe.abacogroup.eu/",
                // target: "https://patri-renew-dev.fe.abacogroup.eu/",
                changeOrigin: true,
                secure: true,
            },
        },
    },
});
