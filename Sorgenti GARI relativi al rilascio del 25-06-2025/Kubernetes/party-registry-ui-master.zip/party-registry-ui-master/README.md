# party-registry-ui

This template should help get you started developing with Vue 3 in Vite.

## Recommended IDE Setup

[VSCode](https://code.visualstudio.com/) + [Volar](https://marketplace.visualstudio.com/items?itemName=Vue.volar) (and disable Vetur) + [TypeScript Vue Plugin (Volar)](https://marketplace.visualstudio.com/items?itemName=Vue.vscode-typescript-vue-plugin).

## Type Support for `.vue` Imports in TS

TypeScript cannot handle type information for `.vue` imports by default, so we replace the `tsc` CLI with `vue-tsc` for type checking. In editors, we need [TypeScript Vue Plugin (Volar)](https://marketplace.visualstudio.com/items?itemName=Vue.vscode-typescript-vue-plugin) to make the TypeScript language service aware of `.vue` types.

If the standalone TypeScript plugin doesn't feel fast enough to you, Volar has also implemented a [Take Over Mode](https://github.com/johnsoncodehk/volar/discussions/471#discussioncomment-1361669) that is more performant. You can enable it by the following steps:

1. Disable the built-in TypeScript Extension
    1) Run `Extensions: Show Built-in Extensions` from VSCode's command palette
    2) Find `TypeScript and JavaScript Language Features`, right click and select `Disable (Workspace)`
2. Reload the VSCode window by running `Developer: Reload Window` from the command palette.

## Customize configuration

See [Vite Configuration Reference](https://vitejs.dev/config/).

## Project Setup

```sh
npm install
```

### Compile and Hot-Reload for Development

```sh
npm run dev
```

### Type-Check, Compile and Minify for Production

```sh
npm run build
```

### Run Unit Tests with [Vitest](https://vitest.dev/)

```sh
npm run test:unit
```

### Run End-to-End Tests with [Cypress](https://www.cypress.io/)

```sh
npm run build
npm run test:e2e # or `npm run test:e2e:ci` for headless testing
```

### Lint with [ESLint](https://eslint.org/)

```sh
npm run lint
```

### Avvio applicazione standalone
Per avviare l'applicazione client come modulo indipendente, lanciare il comando:

```sh
    npm run dev:standalone
```

### Servire come micro frontend
Per compilare l'applicazione in modalità `production` e servirla in locale come verrà poi fatto 
sui server:

```sh
npm run build
docker build -t <image name> .
docker run --rm -p <local port>:8080 <image name>
```

### Accesso al Nexus Abaco

Accesso al nexus abaco (npm)

```sh
	npm login --registry=https://nexus.fe.abacogroup.eu/repository/npm-group/
	npm login --registry=https://nexus.fe.abacogroup.eu/repository/npm-private/
```

### Configurazione sso2

Per avvio in ambiente locale su contesto PATRI:

1. Utilizzare l'url `https://patri-renew-dev.fe.abacogroup.eu/`, da modificare su `vite.config.ts`

```js
    server: {
        port: 3000,
        proxy: {
            "/sso2": {
                target: "https://patri-renew-dev.fe.abacogroup.eu/",
                ...
            }
        }
    }
```

2. Utilizzare l'utente `admin` per testare la configurazione con `locale: it`.
Utilizzare l'utente admin_en per testare la configurazione con `locale: en`.

Per settare lo user, modificare il file `.env.standalone` come segue:

per locale `it`

`VITE_LOGIN_DATA = { "username": "admin", "password": "welcome", "tenant": "master" }`

oppure locale `en`

`VITE_LOGIN_DATA = { "username": "admin_en", "password": "admin_enpwd", "tenant": "master" }`

## Configurazione

### Gestione della API user premission [#135102](https://abacogroup.easyredmine.com/issues/135102)

Per vedere correttamente il bottone di aggiunta soggetto è necessario recuperare il risultato della API `GET /party-registry/{tenant}/api-priv/v1/user/permissions`.

Per poterlo fare è necessario avere la versione di `party-registry` server maggiore o uguale alla `v4.2.4`.



