<script setup lang="ts">
import { inject, onMounted, ref, type Ref } from "vue";
import { useRoute } from "vue-router";
import { useApiResponseHandler } from "@/index";
import useColors from "@abaco/bootstrap-italia-components/src/composables/useColors";
import type { MunicipalitySearchResponse, LauPublicApi } from "patri-common-ui/src";
import type RegistryApi from "@/api/registry-api";
import type { PartyResponse } from "@/models/PartySearchResponseSchema";
import { i18n, type I18nInterface } from "patri-common-ui/src";
import BiButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiButton.vue";
import BiIcon from "@abaco/bootstrap-italia-components/src/components/BiIcon/BiIcon.vue";

const i18nService = inject<I18nInterface | null>("partyI18nService", null);
const { t } = i18nService?.global ?? i18n.global;
const moduleId = inject("moduleId");

const registryApi: RegistryApi = inject("registryApi") as RegistryApi;
const lauPublicApi = inject("lauPublicApi") as LauPublicApi;

const route = useRoute();
const { getColor } = useColors();

const partyId: Ref<number | null> = ref(null);
const registry: Ref<PartyResponse | null> = ref(null);
const municipality: Ref<MunicipalitySearchResponse | null> = ref(null);

function goToDetail() {
    const parentModuleDeployDir = "dossier",
        basePath =
            window.location.href.indexOf(`/${parentModuleDeployDir}`) > -1
                ? window.location.href.split(`/${parentModuleDeployDir}`)[0]
                : window.location.origin,
        detailUrl = `${basePath}/${moduleId}/edit/${partyId.value}`,
        targetUrl = window.location.href.replace(window.location.origin, ""); // Get current url without domain
    window.location.assign(detailUrl + `?backUrl=${encodeURIComponent(targetUrl)}`);
}

onMounted(async () => {
    partyId.value = parseInt(route.query?.partyId as string) || null;

    if (partyId.value) {
        registry.value = await useApiResponseHandler(() => registryApi.getRegistry(partyId.value ?? 0));
        if (registry.value?.addressResidential?.municipality)
            municipality.value = await useApiResponseHandler(() =>
                lauPublicApi.getMunicipalityByCode(registry.value?.addressResidential?.municipality ?? ""),
            );
    }
});
</script>

<template>
    <div class="container">
        <div class="row my-3 justify-content-start">
            <div class="col-12 my-3">
                <h4 class="fw-bold" :class="getColor('text', 'primary')">
                    <BiIcon class="mx-2" icon="file-lines" size="lg" />
                    {{ t(`${moduleId}.registry.summary.title`) }}
                </h4>
            </div>
        </div>
        <div class="container">
            <div>
                <strong class="text-secondary me-1">{{ t(`${moduleId}.registry.summary.city`) }}:</strong>
                <span class="text-secondary">{{
                    municipality?.i18nName && municipality?.district.shortDescr
                        ? `${municipality?.i18nName} (${municipality?.district.shortDescr})`
                        : ""
                }}</span>
            </div>
            <div>
                <strong class="text-secondary me-1">{{ t(`${moduleId}.registry.summary.address`) }}:</strong>
                <span class="text-secondary">{{ registry?.addressResidential?.street }}</span>
            </div>
            <div>
                <strong class="text-secondary me-1">{{ t(`${moduleId}.registry.summary.vatNumber`) }}:</strong>
                <span class="text-secondary">{{ registry?.vatNumber }}</span>
            </div>
            <div class="bg-red flex text-center mt-3">
                <BiButton color="success" class="btn-me" @click="goToDetail">
                    {{ t(`${moduleId}.registry.summary.detail`) }}
                </BiButton>
            </div>
        </div>
    </div>
</template>
