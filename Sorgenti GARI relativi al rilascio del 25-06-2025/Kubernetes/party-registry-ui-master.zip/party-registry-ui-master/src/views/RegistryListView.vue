<script setup lang="ts">
import { computed, inject, onMounted, ref } from "vue";

import type RegistryApi from "@/api/registry-api";
import type { RegistrySearchRequest } from "@/models/RegistrySearchRequest";

import RegistryList from "@/components/registry-list/RegistryList.vue";
import RegistryFilterChips from "@/components/registry-search-form/RegistryFiterChips.vue";
import SearchForm from "@/components/registry-search-form/RegistrySearchForm.vue";
import { MODULE_ID } from "@/constants";
import { useTags } from "@/hooks/useTags";
import { useApiResponseHandler } from "@/index";
import { RouteName } from "@/routes";
import { useRegistryStore } from "@/stores/registry";
import { useUserPermissionStore } from "@/stores/userPermission";
import BiBackButton from "@abaco/bootstrap-italia-components/src/components/BiBackButton/BiBackButton.vue";
import BiButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiButton.vue";
import BiCard from "@abaco/bootstrap-italia-components/src/components/BiCard/BiCard.vue";
import useColors from "@abaco/bootstrap-italia-components/src/composables/useColors";
import { i18n } from "patri-common-ui/src";
import { MODULE_ID as COMMON_MODULE_ID } from "patri-common-ui/src/constants";
import { useRouter } from "vue-router";

const registryStore = useRegistryStore();
const router = useRouter();
const { t } = i18n.global;
const { getColor } = useColors();

const registryApi: RegistryApi = inject("registryApi") as RegistryApi;

const { fetchTagList } = useTags();
const isNextVersion = ref<boolean>(false);
const canCreateParty = ref(false);

const registryList = computed(() => registryStore.getRegistryFullPage.records);
const nextKey = computed(() => registryStore.getRegistryFullPage.nextKey || undefined);
let currentSearchForm: Partial<RegistrySearchRequest>;

onMounted(async () => {
    await fetchTagList();
    const res = await useApiResponseHandler(() => registryApi.getExternalSources());
    if (res && res.length) {
        sessionStorage.setItem("isNextVersion", "true");
        registryStore.setExternalSources(res);
        isNextVersion.value = true;
    } else {
        sessionStorage.setItem("isNextVersion", "false");
        registryStore.setExternalSources([]);
        isNextVersion.value = false;
    }
    // #135102 get user permissions
    canCreateParty.value = await useUserPermissionStore().getCanCreateParties;
});

function goToRegistryForm() {
    if (isNextVersion.value == true) {
        router.push({ name: RouteName.NEXT_PARTY_LIST, query: { backUrl: "" } });
    } else {
        router.push({ name: RouteName.PARTY_NEW_FORM, query: { backUrl: "" } });
    }
}
function resetSearch() {
    registryStore.resetList();
}
async function onSearch(searchForm: Partial<RegistrySearchRequest>) {
    currentSearchForm = searchForm;
    const res = await useApiResponseHandler(() => registryApi.getRegistries(searchForm));

    if (res) {
        registryStore.setList(res);
    }
}
async function onLoadMore() {
    const res = await useApiResponseHandler(() => registryApi.getRegistries(currentSearchForm, nextKey.value));
    if (res) {
        registryStore.incrementList(res);
    }
}
</script>

<template>
    <div class="container my-5">
        <BiCard :extra-classes="['card-bg', 'rounded', 'no-after']">
            <template #card-header>
                <div class="card-header px-4">
                    <div class="d-flex justify-content-between align-items-end">
                        <BiBackButton
                            v-if="registryList"
                            class="btn-me"
                            @click="resetSearch"
                            :visually-hidden-text="t(`${COMMON_MODULE_ID}.general.comeBack`)"
                        />
                        <h3 class="flex-grow-1 text-primary m-0">
                            {{ t(`${MODULE_ID}.registry.subjectRegistry`) }}
                        </h3>
                        <!-- #135102 add button if user permission can_create_parties is true -->
                        <BiButton
                            v-if="canCreateParty"
                            @click="goToRegistryForm"
                            :class="`${getColor('button', 'primary', 'outline')} py-2`"
                        >
                            {{ t(`${MODULE_ID}.registry.actions.new`) }}
                        </BiButton>
                    </div>
                </div>
            </template>
            <template #card-body>
                <SearchForm @search="onSearch" v-if="!registryList"></SearchForm>
                <template v-if="registryList">
                    <div class="my-3">
                        <RegistryFilterChips @remove-filter="onSearch" />
                    </div>
                    <RegistryList
                        :registry-list="registryList"
                        @load-more="onLoadMore()"
                        :show-load-more="!!nextKey"
                    ></RegistryList>
                </template>
            </template>
        </BiCard>
    </div>
</template>
