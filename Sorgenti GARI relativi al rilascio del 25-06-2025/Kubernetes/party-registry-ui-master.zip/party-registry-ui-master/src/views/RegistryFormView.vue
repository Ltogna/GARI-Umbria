<script setup lang="ts">
import type DynamicDocumentApi from "@/api/dynamic-document-api";
import type RegistryApi from "@/api/registry-api";
import { getFormSidebarConfig, getRouteConfig } from "@/components/registry-form/formSidebarConfig";
import { useApiResponseHandler } from "@/index";
import type { DocTypeResponse } from "patri-common-ui/src";
import type { PartyResponse } from "@/models/PartySearchResponseSchema";
import { useRegistryStore } from "@/stores/registry";
import BiCard from "@abaco/bootstrap-italia-components/src/components/BiCard/BiCard.vue";

import { computed, inject, onMounted, onUnmounted, onBeforeUnmount, ref, watch, nextTick } from "vue";
import { RouterView, useRouter } from "vue-router";
import RegistryArchiveToggler from "@/components/registry-form/RegistryArchiveToggler.vue";
import { i18n } from "patri-common-ui/src";
import { useDynamicDocsStore } from "patri-common-ui/src";
import { useTags } from "@/hooks/useTags";
import type {
    PartyDocumentResponse,
    PartyDocumentResponseList,
} from "@/models/dynamic-document/DynamicDocumentResponse";
import { MODULE_ID } from "@/constants";
import { MODULE_ID as COMMON_MODULE_ID } from "patri-common-ui/src/constants";
import BiBackButton from "@abaco/bootstrap-italia-components/src/components/BiBackButton/BiBackButton.vue";
import AccordionSidebar from "@/components/accordion-sidebar/AccordionSidebar.vue";
import { RouteName } from "@/routes";
import usePermissions from "@/hooks/usePermissions";

const { t } = i18n.global;
const router = useRouter();
const registryStore = useRegistryStore();
const dynamicDocStore = useDynamicDocsStore<PartyDocumentResponseList, PartyDocumentResponse>();
const { fetchTagList } = useTags();
const { canWrite } = usePermissions();
const isNextVersion = ref<boolean>(false);
/**
 * #133119 21/03/24
 *
 * `formVisible` set false on form reset than return true.
 */
const formVisible = ref(true);
const loading = ref(true);

const registryApi: RegistryApi = inject("registryApi") as RegistryApi;
const dynamicDocumentApi: DynamicDocumentApi = inject("dynamicDocumentApi") as DynamicDocumentApi;

const regId = computed(() => {
    if (router.currentRoute.value.params["regId"]) {
        return Number(router.currentRoute.value.params["regId"]);
    }
    return null;
});

const formSidebarConfig = ref(getFormSidebarConfig((s: string) => t(s), regId.value));
const formSidebarRouteConfig = ref(getRouteConfig(regId.value));
const registryDetail = ref<PartyResponse | null>(null);

watch(regId, (value) => {
    fetchDynamicDocumentConfig(regId.value);
    initRegistryDetail(value);
});

onMounted(async () => {
    isNextVersion.value = sessionStorage.getItem("isNextVersion") === "true";
    await fetchTagList();
    fetchDynamicDocumentConfig(regId.value);
    initRegistryDetail(regId.value);
    const urlParams = new URLSearchParams(window.location.search);
    const backUrl = urlParams.get("backUrl");
    if (backUrl != null) {
        sessionStorage.setItem(`${MODULE_ID}.backUrl`, backUrl);
    }
});

async function initRegistryDetail(regId: number | null) {
    loading.value = true;
    if (regId) {
        await fetchRegistryDetail(regId);
    }
    loading.value = false;
}

function goToRegistryList() {
    const backUrl = sessionStorage.getItem(`${MODULE_ID}.backUrl`);
    if (backUrl) {
        router.back();
        // window.location.assign(decodeURIComponent(backUrl as string));
    } else {
        if (router.currentRoute.value?.query["fromNextVer"] === "true") {
            router.push({ name: RouteName.NEXT_PARTY_LIST });
        } else {
            router.back();
            // router.push({ name: RouteName.PARTY_LIST });
        }
    }
}

async function fetchRegistryDetail(regId: number) {
    registryDetail.value = await useApiResponseHandler(() => registryApi.getRegistry(regId));

    if (registryDetail.value) {
        registryStore.setCurrentDetail(registryDetail.value);
    }
}

async function fetchDynamicDocumentConfig(regId: number | null) {
    if (!regId) {
        return;
    }

    const docTypes: DocTypeResponse[] | null = await useApiResponseHandler<DocTypeResponse[]>(() =>
        dynamicDocumentApi.getDocumentTypes(regId, {}),
    );

    if (docTypes) {
        dynamicDocStore.setDocTypes(docTypes);
        formSidebarConfig.value = getFormSidebarConfig((s: string) => t(s), regId, docTypes);
        formSidebarRouteConfig.value = getRouteConfig(regId, docTypes);
    }
}
onBeforeUnmount(() => {
    registryStore.currentDetail = null;
});
onUnmounted(() => {
    dynamicDocStore.setDocTypes([] as DocTypeResponse[]);
});

/**
 * #133119 21/03/24
 *
 * reload form on `reset` event is emitted
 */
function onReload() {
    formVisible.value = false;
    nextTick(() => {
        formVisible.value = true;
    });
}
</script>

<template>
    <div class="container my-5">
        <BiCard :extra-classes="['card-bg', 'rounded', 'no-after']">
            <template #card-header>
                <div class="card-header px-4">
                    <div class="d-flex justify-content-between align-items-end">
                        <div class="d-flex align-items-center">
                            <BiBackButton
                                @click="goToRegistryList"
                                :visually-hidden-text="t(`${COMMON_MODULE_ID}.general.comeBack`)"
                                class="btn-me"
                            />
                            <h3 class="text-primary m-0">
                                <template v-if="registryDetail">
                                    {{ registryDetail.lastName }} {{ registryDetail.firstName }}
                                </template>
                                <template v-else>
                                    {{ t(`${COMMON_MODULE_ID}.general.new_f`, 1) }}
                                    {{ t(`${MODULE_ID}.registry.title`) }}
                                </template>
                            </h3>
                        </div>
                        <RegistryArchiveToggler
                            v-if="regId && registryDetail && canWrite"
                            :is-archived="registryDetail.archived"
                            @status-updated="initRegistryDetail(regId)"
                            :reg-id="regId"
                        />
                    </div>
                </div>
            </template>
            <template #card-body>
                <div class="row">
                    <div class="col-md-2 col-sm-12">
                        <div class="mt-4">
                            <AccordionSidebar
                                :form-sidebar-config="formSidebarConfig"
                                :form-sidebar-route-config="formSidebarRouteConfig"
                            />
                        </div>
                    </div>
                    <div class="col-md-10 col-sm-12">
                        <div class="py-4 border-right">
                            <!-- #133119 21/03/24 reset form -->
                            <RouterView v-if="formVisible && !loading" @reload="onReload" />
                        </div>
                    </div>
                </div>
            </template>
        </BiCard>
    </div>
</template>
