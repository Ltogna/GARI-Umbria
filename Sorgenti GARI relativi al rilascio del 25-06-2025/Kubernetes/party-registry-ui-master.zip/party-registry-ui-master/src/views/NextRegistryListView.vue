<script setup lang="ts">
import { MODULE_ID } from "@/constants";
import { MODULE_ID as COMMON_MODULE_ID } from "patri-common-ui/src/constants";
import BiBackButton from "@abaco/bootstrap-italia-components/src/components/BiBackButton/BiBackButton.vue";
import BiCard from "@abaco/bootstrap-italia-components/src/components/BiCard/BiCard.vue";
import { i18n } from "patri-common-ui/src";
import NextRegistrySearchForm from "@/components/registry-search-form/NextRegistrySearchForm.vue";
import { RouteName } from "@/routes";
import { useRouter } from "vue-router";

const { t } = i18n.global;
const router = useRouter();

function resetSearch() {
    router.push({ name: RouteName.PARTY_LIST, query: { backUrl: "" } });
}
</script>

<template>
    <div class="container my-5">
        <BiCard :extra-classes="['card-bg', 'rounded', 'no-after']">
            <template #card-header>
                <div class="card-header px-4">
                    <div class="d-flex justify-content-between align-items-end">
                        <BiBackButton
                            class="btn-me"
                            @click="resetSearch"
                            :visually-hidden-text="t(`${COMMON_MODULE_ID}.general.comeBack`)"
                        />
                        <h3 class="flex-grow-1 text-primary m-0">
                            {{ t(`${MODULE_ID}.registry.subjectRegistry`) }}
                        </h3>
                    </div>
                </div>
            </template>
            <template #card-body>
                <NextRegistrySearchForm></NextRegistrySearchForm>
            </template>
        </BiCard>
    </div>
</template>
