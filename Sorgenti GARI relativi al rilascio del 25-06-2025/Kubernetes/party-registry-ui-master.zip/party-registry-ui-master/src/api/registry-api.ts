import type { HTTPClient } from "@abaco/safe-rest/src/HTTPClient";

import type { PartyCheckRequest, PartyCUAACheckRequest } from "@/models/PartyCheckRequest";
import {
    ExternalSourcesResponseSchema,
    PartyCheckDetailedResponseSchema,
    PartyCheckResponseSchema,
    PartyResponseSchema,
    PartySearchResponseListSchema,
    SubjectInExternalSourceResponseSchema,
} from "@/models/PartySearchResponseSchema";
import type { RegistryRequest } from "@/models/RegistryRequest";
import type { RegistrySearchRequest } from "@/models/RegistrySearchRequest";
import { TagRegistrySearchResponseListSchema } from "@/models/tag/TagSearchResponseSchema";

export default class RegistryApi {
    private http: HTTPClient;
    private rootPath: string;

    constructor(http: HTTPClient, rootPath: string) {
        this.http = http;
        this.rootPath = rootPath;
    }

    public async getRegistries(registrySearchRequest: Partial<RegistrySearchRequest>, nextKey?: string) {
        let params: { [key: string]: unknown | undefined } = {};
        // #134847 assign key of tags to params
        Object.entries(registrySearchRequest).forEach(([key, value]) => {
            if (value !== undefined && value !== "" && value !== null) {
                if (key === "tag" && Array.isArray(value)) {
                    params[key] = value.map((tag) => tag.key);
                } else {
                    params[key] = value;
                }
            }
        });
        if (nextKey) {
            params = {
                ...params,
                nextKey,
            };
        }
        return this.http.getJson(PartySearchResponseListSchema, `${this.rootPath}/api-priv/v1/parties`, {
            params,
        });
    }

    public async getRegistry(registryId: number) {
        return this.http.getJson(PartyResponseSchema, `${this.rootPath}/api-priv/v1/parties/${registryId}`);
    }

    public async getRegistryTags(registryId: number) {
        return this.http.getJson(
            TagRegistrySearchResponseListSchema,
            `${this.rootPath}/api-priv/v1/parties/${registryId}/tags`,
        );
    }

    public async createRegistry(registryRequest: Partial<RegistryRequest>) {
        return this.http.postJson(PartyResponseSchema, `${this.rootPath}/api-priv/v1/parties`, registryRequest);
    }

    public async updateRegistry(regId: number, registryRequest: Partial<RegistryRequest>) {
        return this.http.putJson(PartyResponseSchema, `${this.rootPath}/api-priv/v1/parties/${regId}`, registryRequest);
    }

    public async archiveRegistry(regId: number) {
        return this.http.putJson(
            PartyResponseSchema,
            `${this.rootPath}/api-priv/v1/parties/${regId}/archived_flag`,
            {},
        );
    }

    public async unarchiveRegistry(regId: number) {
        return this.http.delete(`${this.rootPath}/api-priv/v1/parties/${regId}/archived_flag`);
    }

    public async getDuplicates(partyCheckRequest: Partial<PartyCheckRequest>) {
        const params: { [key: string]: unknown | undefined } = { ...partyCheckRequest };
        return this.http.getJson(PartyCheckResponseSchema, `${this.rootPath}/api-priv/v1/parties/duplicates`, {
            params,
        });
    }

    public async getDuplicatesDetailed(partyCheckRequest: Partial<PartyCheckRequest>) {
        const params: { [key: string]: unknown | undefined } = { ...partyCheckRequest };
        return this.http.getJson(
            PartyCheckDetailedResponseSchema,
            `${this.rootPath}/api-priv/v1/parties/duplicates_detailed`,
            {
                params,
            },
        );
    }

    public async getDuplicateCuaa(partyCuaaCheckRequest: Partial<PartyCUAACheckRequest>) {
        const params: { [key: string]: unknown | undefined } = { ...partyCuaaCheckRequest };
        return this.http.getJson(PartyCheckResponseSchema, `${this.rootPath}/api-priv/v1/parties/duplicates_code`, {
            params,
        });
    }

    public async getExternalSources() {
        return this.http.getJson(ExternalSourcesResponseSchema, `${this.rootPath}/api-priv/v1/external-sources`);
    }

    public async checkSubjectInExternalSource(partyCode: string, sourceCode: string) {
        return this.http.getJson(
            SubjectInExternalSourceResponseSchema,
            `${this.rootPath}/api-priv/v1/parties/external/check-existence/source/${sourceCode}/party/${partyCode}`,
        );
    }

    public async searchAndUpdateParty(sourceCode: string, partyCode: string) {
        return this.http.putJson(PartyResponseSchema, `${this.rootPath}/api-priv/v1/parties/external`, {
            partyCode: partyCode,
            sourceCode: sourceCode,
        });
    }
}
