import {
    RelationTypeRegistryResponseSchema,
    RelationTypeRegistrySearchResponseListSchema,
    RelationTypesSearchResponseListSchema,
} from "@/models/relation/RelationTypeSearchResponseSchema";
import type { RegistryRelation } from "@/models/relation/RelationRequest";
import type { RegistryRelationType } from "@/models/relation/RelationTypeRequest";
import type { HTTPClient } from "@abaco/safe-rest/src/HTTPClient";
import {
    RelationRegistryResponseSchema,
    RelationRegistrySearchResponseListSchema,
    RelationRolesSearchResponseListSchema,
} from "@/models/relation/RelationSearchResponseSchema";

export default class RelationApi {
    private http: HTTPClient;
    private rootPath: string;

    constructor(http: HTTPClient, rootPath: string) {
        this.http = http;
        this.rootPath = rootPath;
    }

    public async getRelationTypes() {
        return this.http.getJson(RelationTypesSearchResponseListSchema, `${this.rootPath}/api-priv/v1/relation-types`);
    }

    public async getRegistryRelationTypes(regId: number, nextKey?: string) {
        let params: { [key: string]: unknown | undefined } = {};
        if (nextKey) params = { nextKey };
        return this.http.getJson(
            RelationTypeRegistrySearchResponseListSchema,
            `${this.rootPath}/api-priv/v1/parties/${regId}/relation-types`,
            { params },
        );
    }

    public async createRegistryRelationType(regId: number, relationTypeRequest: Partial<RegistryRelationType>) {
        return this.http.postJson(
            RelationTypeRegistryResponseSchema,
            `${this.rootPath}/api-priv/v1/parties/${regId}/relation-types`,
            relationTypeRequest,
        );
    }

    public async updateRegistryRelationType(regId: number, relationTypeRequest: Partial<RegistryRelationType>) {
        return this.http.putJson(
            RelationTypeRegistryResponseSchema,
            `${this.rootPath}/api-priv/v1/parties/${regId}/relation-types/${relationTypeRequest.id}`,
            relationTypeRequest,
        );
    }

    public async deleteRegistryRelationType(regId: number, relationTypeRequest: Partial<RegistryRelationType>) {
        return this.http.delete(
            `${this.rootPath}/api-priv/v1/parties/${regId}/relation-types/${relationTypeRequest.id}`,
        );
    }

    public async getRelationTypeRoles(relationTypeRequest: RegistryRelationType, nextKey?: string) {
        let params: { [key: string]: unknown | undefined } = {};
        if (nextKey) params = { nextKey };
        return this.http.getJson(
            RelationRolesSearchResponseListSchema,
            `${this.rootPath}/api-priv/v1/relation-types/${relationTypeRequest.relationTypeCode}/roles`,
            { params },
        );
    }

    public async getRelationTypeRelations(regId: number, relationTypeRequest: RegistryRelationType, nextKey?: string) {
        let params: { [key: string]: unknown | undefined } = {};
        if (nextKey) params = { nextKey };
        return this.http.getJson(
            RelationRegistrySearchResponseListSchema,
            `${this.rootPath}/api-priv/v1/parties/${regId}/relation-types/${relationTypeRequest.id}/relations`,
            { params },
        );
    }

    public async getRegistryRelationTypeRelation(regId: number, relationRequest: Partial<RegistryRelation>) {
        return this.http.getJson(
            RelationRegistryResponseSchema,
            `${this.rootPath}/api-priv/v1/parties/${regId}/relation-types/${relationRequest.partyRelationId}/relations/${relationRequest.pkid}`,
        );
    }

    public async createRegistryRelationTypeRelation(regId: number, relationRequest: Partial<RegistryRelation>) {
        return this.http.postJson(
            RelationRegistryResponseSchema,
            `${this.rootPath}/api-priv/v1/parties/${regId}/relation-types/${relationRequest.partyRelationId}/relations`,
            relationRequest,
        );
    }

    public async updateRegistryRelationTypeRelation(regId: number, relationRequest: Partial<RegistryRelation>) {
        return this.http.putJson(
            RelationRegistryResponseSchema,
            `${this.rootPath}/api-priv/v1/parties/${regId}/relation-types/${relationRequest.partyRelationId}/relations/${relationRequest.pkid}`,
            relationRequest,
        );
    }

    public async deleteRegistryRelationTypeRelation(regId: number, relationRequest: Partial<RegistryRelation>) {
        return this.http.delete(
            `${this.rootPath}/api-priv/v1/parties/${regId}/relation-types/${relationRequest.partyRelationId}/relations/${relationRequest.pkid}`,
        );
    }
}
