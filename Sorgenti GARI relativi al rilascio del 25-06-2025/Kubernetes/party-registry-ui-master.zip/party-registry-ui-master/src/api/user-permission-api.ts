/**
 * #135102 user permissions API
 */

import { UserPermissionSchema } from "@/models/user-permission/UserPermissionSchema";
import type { HTTPClient, HttpJsonResult } from "@abaco/safe-rest/src/HTTPClient";

export default class UserPermissionApi {
    private http: HTTPClient;
    private rootPath: string;

    constructor(http: HTTPClient, rootPath: string) {
        this.http = http;
        this.rootPath = rootPath;
    }

    public async getUserPermissions(): Promise<HttpJsonResult<UserPermissionSchema>> {
        return this.http.getJson(UserPermissionSchema, `${this.rootPath}/api-priv/v1/user/permissions`);
        // return {
        //     errorType: 0,
        //     data: {
        //         can_create_parties: true,
        //     },
        //     response: new Response(""),
        // };
    }
}
