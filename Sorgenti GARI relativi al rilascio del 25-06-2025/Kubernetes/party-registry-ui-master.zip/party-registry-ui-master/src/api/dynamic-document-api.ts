import type { DocTypeSearchRequest, InsertDocument } from "patri-common-ui/src";
import { DocTypeSearchResponseListSchema } from "patri-common-ui/src";
import { DocumentSchema } from "@abaco/dynamic-documents/src/resources/models";
import type { HTTPClient } from "@abaco/safe-rest/src/HTTPClient";
import {
    type PartyDocumentResponse,
    PartyDocumentResponseListSchema,
    PartyDocumentResponseSchema,
} from "@/models/dynamic-document/DynamicDocumentResponse";

export default class DynamicDocumentApi {
    private http: HTTPClient;
    private rootPath: string;

    constructor(http: HTTPClient, rootPath: string) {
        this.http = http;
        this.rootPath = rootPath;
    }

    public async getDocumentTypes(regId: number, docTypeSearchRequest: Partial<DocTypeSearchRequest>) {
        return this.http.getJson(DocTypeSearchResponseListSchema, `${this.rootPath}/api-priv/v1/doc-types/${regId}`, {
            params: { ...docTypeSearchRequest },
        });
    }

    public async getPartyDocumentsByType(regId: number, docType: string, nextKey?: string) {
        let params;
        nextKey && (params = { nextKey });

        return this.http.getJson(
            PartyDocumentResponseListSchema,
            `${this.rootPath}/api-priv/v1/parties/${regId}/documents/type/${docType}`,
            { params },
        );
    }

    public async getPartyDocumentById(regId: number, docType: string, docId: number) {
        return this.http.getJson(
            PartyDocumentResponseSchema,
            `${this.rootPath}/api-priv/v1/parties/${regId}/documents/type/${docType}/${docId}`,
        );
    }

    public async getDocumentDefinition(regId: number, docType: string) {
        return this.http.getJson(
            DocumentSchema,
            `${this.rootPath}/api-priv/v1/parties/${regId}/documents/type/${docType}/definition`,
        );
    }

    public async createDocument(insertDocument: InsertDocument) {
        return this.http.postJson(
            PartyDocumentResponseSchema,
            `${this.rootPath}/api-priv/v1/parties/${insertDocument.businessId}/documents/type/${insertDocument.defCode}`,
            insertDocument,
        );
    }

    public async updateDocument(updateDocument: PartyDocumentResponse) {
        return this.http.putJson(
            PartyDocumentResponseSchema,
            `${this.rootPath}/api-priv/v1/parties/${updateDocument.partyId}/documents/type/${updateDocument.definitionCode}/${updateDocument.documentId}`,
            { fields: updateDocument.data },
        );
    }

    public async deleteDocument(partyId: number, docType: string, docId: number) {
        return this.http.delete(`${this.rootPath}/api-priv/v1/parties/${partyId}/documents/type/${docType}/${docId}`);
    }
}
