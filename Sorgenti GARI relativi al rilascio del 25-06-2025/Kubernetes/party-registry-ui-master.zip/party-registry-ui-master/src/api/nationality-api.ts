import { NationalityAutocompleteResponseSchema, NationalitySearchResponseSchema } from "patri-common-ui/src";
import type { HTTPClient } from "@abaco/safe-rest/src/HTTPClient";

export default class NationalityApi {
    private http: HTTPClient;
    private rootPath: string;

    constructor(http: HTTPClient, rootPath: string) {
        this.http = http;
        this.rootPath = rootPath;
    }

    public async getNationalities(nextKey?: string) {
        let params: { [key: string]: unknown | undefined } = {};
        if (nextKey) params = { nextKey };
        return this.http.getJson(NationalityAutocompleteResponseSchema, `${this.rootPath}/api-priv/v1/citizenships`, {
            params,
        });
    }

    public async getNationalityByCode(code: string) {
        return this.http.getJson(NationalitySearchResponseSchema, `${this.rootPath}/api-priv/v1/citizenships/${code}`);
    }
}
