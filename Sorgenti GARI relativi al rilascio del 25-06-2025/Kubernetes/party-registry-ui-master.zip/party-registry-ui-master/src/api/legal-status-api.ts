import { GenericSearchSchema, LegalStatusResponseListSchema } from "@/models/LegalStatus";
import type { HTTPClient } from "@abaco/safe-rest/src/HTTPClient";

export default class LegalStatusApi {
    private http: HTTPClient;
    private rootPath: string;

    constructor(http: HTTPClient, rootPath: string) {
        this.http = http;
        this.rootPath = rootPath;
    }

    public async getLegalStatusList(nextKey?: string) {
        let params: { [key: string]: unknown | undefined } = {};
        if (nextKey) params = { nextKey };
        return this.http.getJson(LegalStatusResponseListSchema, `${this.rootPath}/api-priv/v1/legal-status`, {
            params,
        });
    }

    public async getLegalStatusByCode(code: string) {
        return this.http.getJson(GenericSearchSchema, `${this.rootPath}/api-priv/v1/legal-status/${code}`);
    }
}
