import {
    ContactRegistryResponseSchema,
    ContactRegistrySearchResponseListSchema,
} from "@/models/contact/ContactRegistrySearchResponseSchema";
import type { Contact } from "@/models/contact/ContactRequest";
import type { HTTPClient } from "@abaco/safe-rest/src/HTTPClient";

export default class ContactApi {
    private http: HTTPClient;
    private rootPath: string;

    constructor(http: HTTPClient, rootPath: string) {
        this.http = http;
        this.rootPath = rootPath;
    }

    public async getContacts(regId: number, nextKey?: string) {
        let params: { [key: string]: unknown | undefined } = {};
        if (nextKey) params = { nextKey };
        return this.http.getJson(
            ContactRegistrySearchResponseListSchema,
            `${this.rootPath}/api-priv/v1/parties/${regId}/contacts`,
            { params },
        );
    }

    public async createContact(regId: number, contactRequest: Partial<Contact>) {
        return this.http.postJson(
            ContactRegistryResponseSchema,
            `${this.rootPath}/api-priv/v1/parties/${regId}/contacts`,
            contactRequest,
        );
    }

    public async updateContact(regId: number, contactRequest: Partial<Contact>) {
        return this.http.putJson(
            ContactRegistryResponseSchema,
            `${this.rootPath}/api-priv/v1/parties/${regId}/contacts/${contactRequest.pkid}`,
            contactRequest,
        );
    }

    public async deleteContact(regId: number, contactRequest: Partial<Contact>) {
        return this.http.delete(`${this.rootPath}/api-priv/v1/parties/${regId}/contacts/${contactRequest.pkid}`);
    }
}
