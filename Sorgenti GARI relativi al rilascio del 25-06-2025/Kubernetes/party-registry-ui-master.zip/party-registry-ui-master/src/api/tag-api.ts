import type { Tag } from "@/models/tag/TagRequest";
import { TagResponseListSchema, TagSearchResponseListSchema } from "@/models/tag/TagSearchResponseSchema";
import type { HTTPClient } from "@abaco/safe-rest/src/HTTPClient";

export default class TagApi {
    private http: HTTPClient;
    private rootPath: string;

    constructor(http: HTTPClient, rootPath: string) {
        this.http = http;
        this.rootPath = rootPath;
    }

    public async searchTags(tagSearchRequest: Partial<Tag>) {
        return this.http.getJson(TagSearchResponseListSchema, `${this.rootPath}/api-priv/v1/tags`, {
            params: { ...tagSearchRequest },
        });
    }

    public async getTags() {
        return this.http.getJson(TagResponseListSchema, `${this.rootPath}/api-priv/v1/tags/list`);
    }
}
