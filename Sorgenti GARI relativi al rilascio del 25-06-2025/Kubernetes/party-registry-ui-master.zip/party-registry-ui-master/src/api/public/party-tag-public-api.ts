import type { HTTPClient } from "@abaco/safe-rest/src/HTTPClient";

import { TagResponseListSchema } from "../../models/tag/TagSearchResponseSchema";

export default class PartyTagPublicApi {
    private http: HTTPClient;
    private rootPath: string;

    constructor(http: HTTPClient, rootPath: string) {
        this.http = http;
        this.rootPath = rootPath;
    }

    public async getTags() {
        return this.http.getJson(TagResponseListSchema, `${this.rootPath}/public/v1/tags/list`);
    }
}
