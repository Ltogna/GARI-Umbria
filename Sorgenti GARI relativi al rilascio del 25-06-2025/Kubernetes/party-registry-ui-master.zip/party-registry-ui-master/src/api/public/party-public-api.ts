import type { HTTPClient } from "@abaco/safe-rest/src/HTTPClient";

import { PartySearchResponseListSchema, PartyResponseSchema } from "../../models/PartySearchResponseSchema";
import type { RegistrySearchRequest } from "../../models/RegistrySearchRequest";

export default class PartyPublicApi {
    private http: HTTPClient;
    private rootPath: string;

    constructor(http: HTTPClient, rootPath: string) {
        this.http = http;
        this.rootPath = rootPath;
    }

    public async getParties(partySearchRequest: Partial<RegistrySearchRequest>, nextKey?: string) {
        let params: Record<string, unknown> = { ...partySearchRequest };
        if (nextKey) {
            params = {
                ...params,
                nextKey,
            };
        }
        return this.http.getJson(PartySearchResponseListSchema, `${this.rootPath}/public/v1/parties`, {
            params,
        });
    }

    public async getParty(partyId: number) {
        return this.http.getJson(PartyResponseSchema, `${this.rootPath}/public/v1/parties/${partyId}`);
    }
}
