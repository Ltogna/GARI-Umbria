import { ConfigurationResponseSchema } from "@/models/configuration/ConfigurationResponseSchema";
import type { HTTPClient } from "@abaco/safe-rest/src/HTTPClient";

export default class PartyConfigurationPublicApi {
    private http: HTTPClient;
    private rootPath: string;

    constructor(http: HTTPClient, rootPath: string) {
        this.http = http;
        this.rootPath = rootPath;
    }

    public async getConfigByKey(configKey: string) {
        return this.http.getJson(ConfigurationResponseSchema, `${this.rootPath}/public/v1/configurations/${configKey}`);
    }
}
