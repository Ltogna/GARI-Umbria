import { defineStore } from "pinia";

type State = {
    history: string[];
};

const SEPARATOR = ":";

const defaultState: Readonly<State> = {
    history: [],
};

const state: State = structuredClone(defaultState);

/**
 * #134529 25/03/24 relationPartyHistory Store
 *
 * Added a stor to manage history relation party modal
 */
export const useRelationPartyHistoryStore = defineStore({
    id: "relationPartyHistory",
    state: (): State => state,
    getters: {},
    actions: {
        pushState({ partyId, relationId }: { partyId: number; relationId: number }) {
            this.history.push(`${partyId}${SEPARATOR}${relationId}`);
        },
        popLast() {
            return this.history.pop();
        },
        getLast() {
            if (this.history.length > 0) {
                const [partyId, relationId] = this.history[this.history.length - 1].split(SEPARATOR);
                return {
                    partyId: +partyId,
                    relationId: +relationId,
                };
            }
            return null;
        },
        $reset() {
            this.$state = structuredClone(defaultState);
        },
    },
});
