import { defineStore } from "pinia";

interface BaseConfigParams {
    unique?: boolean;
    mandatory?: boolean;
    editable?: boolean;
}

interface CustomConfigParams extends BaseConfigParams {
    [key: string]: boolean | undefined;
}

export interface AdvCustomConfigParams {
    configurationKey?: string;
    configuration?: {
        [key: string]: { [key: string]: boolean | string | number | undefined };
    };
}

export interface GenericConfiguration {
    configurationKey?: string;
    configuration?: CustomConfigParams;
}
export interface RegExpRulesConfiguration {
    configurationKey?: string;
    configuration?: { L: string[]; N: string[] };
}

type State = {
    code: GenericConfiguration | null;
    party_type: GenericConfiguration | null;
    vat_number_validation: RegExpRulesConfiguration | null;
    vat_number: AdvCustomConfigParams | null;
    tax_code_validation: RegExpRulesConfiguration | null;
    code_validation: RegExpRulesConfiguration | null;
    nationality: GenericConfiguration | null;
    legalStatus_validation: RegExpRulesConfiguration | null;
    legal_status: AdvCustomConfigParams | null;
};

const state: State = {
    code: null,
    party_type: null,
    vat_number: null,
    vat_number_validation: null,
    tax_code_validation: null,
    code_validation: null,
    nationality: null,
    legalStatus_validation: null,
    legal_status: null,
};

export const useConfigurationStore = defineStore({
    id: "configuration",
    state: (): State => state,
    actions: {
        setCuaaConfig(config: GenericConfiguration | null) {
            this.code = config;
        },
        setPartyTypeConfig(config: GenericConfiguration | null) {
            this.party_type = config;
        },
        setVatNumberValidationConfig(config: RegExpRulesConfiguration | null) {
            this.vat_number_validation = config;
        },
        setVatNumberConfig(config: AdvCustomConfigParams | null) {
            this.vat_number = config;
        },
        setTaxCodeConfig(config: RegExpRulesConfiguration | null) {
            this.tax_code_validation = config;
        },
        setCodeConfig(config: RegExpRulesConfiguration | null) {
            this.code_validation = config;
        },
        setNationalityConfig(config: GenericConfiguration | null) {
            this.nationality = config;
        },
        setLegalStatusValidationConfig(config: RegExpRulesConfiguration | null) {
            this.legalStatus_validation = config;
        },
        setLegalStatusConfig(config: AdvCustomConfigParams | null) {
            this.legal_status = config;
        },
        resetConfig(): void {
            this.$reset();
        },
        $reset() {
            this.$state = {
                code: null,
                party_type: null,
                vat_number_validation: null,
                vat_number: null,
                tax_code_validation: null,
                code_validation: null,
                nationality: null,
                legalStatus_validation: null,
                legal_status: null,
            };
        },
    },
});
