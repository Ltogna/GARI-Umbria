import type { InfiniteListPage } from "patri-common-ui/src";
import type {
    PartyResponse,
    PartySearchResponse,
    PartySearchResponseList,
    ExternalSourcesResponse,
    ReadOnlyFieldsModel,
} from "@/models/PartySearchResponseSchema";
import type { RegistrySearchRequest } from "@/models/RegistrySearchRequest";
import { defineStore } from "pinia";

type State = {
    currentDetail: PartyResponse | null;
    search: Partial<RegistrySearchRequest>;
    list: Record<string, PartySearchResponse>;
    page: InfiniteListPage;
    externalSources: ExternalSourcesResponse;
    readOnlyFields: ReadOnlyFieldsModel;
};

const defaultState: Readonly<State> = {
    currentDetail: null,
    search: {},
    list: {},
    page: {
        count: 0,
        nextKey: null,
        records: null,
    },
    externalSources: [],
    readOnlyFields: {
        partyType: true,
        gender: true,
        lastName: true,
        firstName: true,
        taxCode: true,
        vatNumber: true,
        code: true,
        legalStatus: true,
        birthDate: true,
        deathDate: true,
        birthMunicipality: true,
        nationality: true,
        addressResidential: {
            municipality: true,
            locality: true,
            postcode: true,
            street: true,
            houseNumber: true,
        },
        addressBilling: {
            municipality: true,
            locality: true,
            postcode: true,
            street: true,
            houseNumber: true,
        },
    },
};

const state: State = structuredClone(defaultState);

export const useRegistryStore = defineStore({
    id: "registry",
    state: (): State => state,
    getters: {
        getRegistryById:
            (state) =>
            (id: number): PartySearchResponse => {
                return state.list[id];
            },
        getRegistryFullPage: (state) => {
            return {
                ...state.page,
                records: state.page?.records ? state.page.records.map((recId) => state.list[recId]) : null,
            };
        },
        getExternalSources: (state) => {
            return state.externalSources;
        },
        getReadOnlyFields: (state) => {
            return state.readOnlyFields;
        },
    },
    actions: {
        setSearch(registrySearchForm: Partial<RegistrySearchRequest>): void {
            this.search = registrySearchForm;
        },
        resetSearch(): void {
            this.search = {};
        },
        resetList(): void {
            this.list = {};
            this.page = {
                count: 0,
                nextKey: null,
                records: null,
            };
        },
        setList(registries: PartySearchResponseList) {
            this.list = registries.records.reduce(
                (acc, item) => {
                    acc[item.id] = item;
                    return acc;
                },
                {} as Record<string, PartySearchResponse>,
            );

            this.page = { ...registries, records: registries.records.map((item) => item.id) };
        },
        incrementList(registries: PartySearchResponseList) {
            this.list = {
                ...this.list,
                ...registries.records.reduce(
                    (acc, item) => {
                        acc[item.id] = item;
                        return acc;
                    },
                    {} as Record<string, PartySearchResponse>,
                ),
            };

            this.page = {
                ...registries,
                records: [...(this.page.records ?? []), ...registries.records.map((item) => item.id)],
            };
        },
        addElement(registry: PartySearchResponse): void {
            this.list = {
                ...this.list,
                [registry.id]: registry,
            };
        },
        setCurrentDetail(currentDetail: PartyResponse): void {
            this.currentDetail = currentDetail;
        },
        setExternalSources(externalSources: ExternalSourcesResponse) {
            this.externalSources = externalSources;
        },
        $reset() {
            this.$state = structuredClone(state);
        },
    },
});
