import type { TagResponse } from "@/models/tag/TagSearchResponseSchema";
import { defineStore } from "pinia";

type State = {
    list: Record<string, TagResponse>;
    page: number[];
};

const defaultState: Readonly<State> = {
    list: {},
    page: [],
};

const state: State = structuredClone(defaultState);

export const useTagStore = defineStore({
    id: "tags",
    state: (): State => state,
    getters: {
        getTagFullPage: (state) => {
            return state.page.map((it) => state.list[it]).slice();
        },
        getListByCode: (state) => {
            return state.page
                .map((it) => state.list[it])
                .reduce(
                    (acc, item) => {
                        acc[item.code] = item;
                        return acc;
                    },
                    {} as Record<string, TagResponse>,
                );
        },
        getListValues: (state) => {
            return Object.values(state.list);
        },
    },
    actions: {
        setList(tags: TagResponse[]) {
            this.list = tags.reduce(
                (acc, item) => {
                    acc[item.id] = item;
                    return acc;
                },
                {} as Record<string, TagResponse>,
            );

            this.page = tags.map((it) => it.id);
        },
        incrementList(tags: TagResponse[]) {
            this.list = {
                ...this.list,
                ...tags.reduce(
                    (acc, item) => {
                        acc[item.id] = item;
                        return acc;
                    },
                    {} as Record<string, TagResponse>,
                ),
            };

            this.page = [...(this.page ?? []), ...tags.map((item) => item.id)];
        },
        resetList(): void {
            this.$reset();
        },
        $reset() {
            this.$state = structuredClone(defaultState);
        },
    },
});
