/**
 * #135102 Created user permission store
 */
import type { UserPermissionSchema } from "@/models/user-permission/UserPermissionSchema";
import deferred, { type DeferredPromise } from "@/utils/deferredPromise";
import { defineStore } from "pinia";

type State = {
    canCreateDeferred: DeferredPromise<UserPermissionSchema>;
};

const state: State = {
    canCreateDeferred: deferred<UserPermissionSchema>(),
};

export const useUserPermissionStore = defineStore({
    id: "userPermission",
    state: (): State => state,
    getters: {
        async getCanCreateParties(state) {
            try {
                const ret = await state.canCreateDeferred.promise;
                return ret.can_create_parties;
            } catch (err) {
                return false;
            }
        },
    },
    actions: {
        setUserPermissions(config: UserPermissionSchema | null) {
            if (config) {
                this.canCreateDeferred.resolve(config);
            } else {
                this.canCreateDeferred.reject("error");
            }
        },
        resetConfig(): void {
            this.$reset();
        },
        $reset() {
            this.$state = {
                canCreateDeferred: deferred<UserPermissionSchema>(),
            };
        },
    },
});
