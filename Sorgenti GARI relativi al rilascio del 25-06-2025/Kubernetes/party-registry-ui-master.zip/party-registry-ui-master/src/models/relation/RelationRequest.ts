export interface RegistryRelation {
    pkid: number;
    partyRelationId: number;
    relationRoleId: number;
    firstName: string;
    lastName: string;
    dtStart: string;
    dtEnd?: string;
    relatedRoleCode: string;
    relationRoleI18nCode: string;
    relatedPartyId: number;
    // #134529 added birthDate
    birthDate?: string;
    // #134529 added taxCode
    taxCode?: string;
    hasMandates: boolean;
}

export interface RelationRole {
    code: string;
    i18nCode: string;
}
