import { z } from "zod";
import { InfiniteListResultsSchema } from "patri-common-ui/src";

const RelationRole = z.object({
    code: z.string(),
    i18nCode: z.nullable(z.string()),
});

export const RelationRegistryResponseSchema = z.object({
    pkid: z.number(),
    partyRelationId: z.number(),
    relationRoleId: z.number(),
    firstName: z.nullable(z.string()),
    lastName: z.string(),
    dtStart: z.string(),
    dtEnd: z.string(),
    relatedRoleCode: z.string(),
    relationRoleI18nCode: z.nullable(z.string()),
    relatedPartyId: z.number(),
    // #134529 added birthDate
    birthDate: z.string().nullish(),
    // #134529 added taxCode
    taxCode: z.string().nullish(),
    hasMandates: z.boolean().default(true),
});
export type RelationRegistrySearchResponse = z.infer<typeof RelationRegistryResponseSchema>;

export const RelationRegistrySearchResponseListSchema = InfiniteListResultsSchema.extend({
    records: z.array(RelationRegistryResponseSchema),
});
export type RelationRegistrySearchResponseList = z.infer<typeof RelationRegistrySearchResponseListSchema>;

export const RelationRolesSearchResponseListSchema = InfiniteListResultsSchema.extend({
    records: z.array(RelationRole),
});
export type RelationTypesSearchResponseList = z.infer<typeof RelationRolesSearchResponseListSchema>;
