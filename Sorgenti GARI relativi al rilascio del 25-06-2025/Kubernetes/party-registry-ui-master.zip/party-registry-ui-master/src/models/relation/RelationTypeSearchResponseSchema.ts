import { z } from "zod";
import { InfiniteListResultsSchema } from "patri-common-ui/src";

const RelationType = z.object({
    id: z.number(),
    code: z.string(),
    multiple: z.boolean(),
    i18nCode: z.nullable(z.string()),
});

export const RelationTypeRegistryResponseSchema = z.object({
    id: z.number(),
    partyId: z.number(),
    note: z.nullable(z.string()),
    relationTypeCode: z.string(),
    relationTypeI18nCode: z.nullable(z.string()),
});
export type RelationTypeRegistrySearchResponse = z.infer<typeof RelationTypeRegistryResponseSchema>;

export const RelationTypeRegistrySearchResponseListSchema = InfiniteListResultsSchema.extend({
    records: z.array(RelationTypeRegistryResponseSchema),
});
export type RelationRegistrySearchResponseList = z.infer<typeof RelationTypeRegistrySearchResponseListSchema>;

export const RelationTypesSearchResponseListSchema = InfiniteListResultsSchema.extend({
    records: z.array(RelationType),
});
export type RelationTypesSearchResponseList = z.infer<typeof RelationTypesSearchResponseListSchema>;
