export interface RegistryRelationType {
    id: number;
    partyId: number;
    note: string;
    relationTypeCode: string;
    relationTypeI18nCode: string;
}

export interface RelationType {
    id: number;
    code: string;
    multiple: boolean;
    i18nCode: string;
}

export interface RelationTypeRequest {
    relationTypeCode: number;
    note: string;
}
