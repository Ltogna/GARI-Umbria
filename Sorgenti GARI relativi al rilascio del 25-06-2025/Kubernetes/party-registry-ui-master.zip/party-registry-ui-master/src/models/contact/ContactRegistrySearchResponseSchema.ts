import { z } from "zod";
import { InfiniteListResultsSchema } from "patri-common-ui/src";

const ContactTypeEnum = z.enum(["EMAIL", "PEC", "PHONE"]);

export const ContactRegistryResponseSchema = z.object({
    pkid: z.number(),
    partyId: z.number(),
    contactType: ContactTypeEnum,
    subType: z.string(),
    contactValue: z.string(),
    note: z.nullable(z.string()),
});
export type ContactRegistrySearchResponse = z.infer<typeof ContactRegistryResponseSchema>;

export const ContactRegistrySearchResponseListSchema = InfiniteListResultsSchema.extend({
    records: z.array(ContactRegistryResponseSchema),
});
export type ContactRegistrySearchResponseList = z.infer<typeof ContactRegistrySearchResponseListSchema>;
