export interface Contact {
    pkid: number;
    partyId: number;
    contactType: ContactTypeEnum;
    subType: string;
    contactValue: string;
    note: string;
}

export enum ContactTypeEnum {
    EMAIL = "EMAIL",
    PEC = "PEC",
    PHONE = "PHONE",
}
