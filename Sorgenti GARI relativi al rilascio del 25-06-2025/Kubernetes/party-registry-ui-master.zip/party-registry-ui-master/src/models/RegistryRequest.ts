export enum PartyType {
    N = "N", // Natural
    L = "L", // Legal
}

export enum GenderEnum {
    M = "M",
    F = "F",
}

export interface Address {
    id: number;
    municipality: string;
    locality: string;
    street: string;
    houseNumber: string;
    postcode: string;
    details: string;
    note: string;
}

export interface RegistryRequest {
    id: number;
    code: string;
    partyType: PartyType;
    gender: GenderEnum;
    lastName: string;
    firstName: string;
    taxCode: string;
    vatNumber: string;
    birthDate: string;
    deathDate: string;
    birthMunicipality: string;
    nationality: string;
    addressResidential: Address;
    addressHome: Address;
    addressBilling: Address;
    archived: boolean;
    legalStatus: string;
    tags: string[];
    externalSource?: Array<{ code: string; allowManual: boolean; description: string }> | null;
}

export interface RegistryRequestPayload extends Omit<RegistryRequest, "nationality"> {
    nationality: string | null;
}
