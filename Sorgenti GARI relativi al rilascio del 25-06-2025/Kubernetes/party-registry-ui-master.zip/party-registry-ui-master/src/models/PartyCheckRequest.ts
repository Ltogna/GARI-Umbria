export interface PartyCheckRequest {
    id: number;
    vatNumber: string;
    taxCode: string;
}

export interface PartyCUAACheckRequest {
    id: number;
    code: string;
}
