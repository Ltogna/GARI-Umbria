import { z } from "zod";
import { InfiniteListResultsSchema } from "patri-common-ui/src";

export const GenericSearchSchema = z.object({
    code: z.string(),
    i18nCode: z.nullable(z.string()),
});
export type GenericSearchResponse = z.infer<typeof GenericSearchSchema>;

export const LegalStatusResponseListSchema = InfiniteListResultsSchema.extend({
    records: z.array(GenericSearchSchema),
});
export type LegalStatusResponseList = z.infer<typeof LegalStatusResponseListSchema>;
