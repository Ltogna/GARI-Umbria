/**
 * #135102 added user permission schema
 */

import { z } from "zod";

export const UserPermissionSchema = z.object({
    can_create_parties: z.boolean().default(false),
});
export type UserPermissionSchema = z.infer<typeof UserPermissionSchema>;
