export interface RegistrySearchRequest {
    id: number;
    code: string;
    lastName: string;
    firstName: string;
    taxCode: string;
    vatNumber: string;
    taxOrVat: string;
    tag: TagOption[];
    archived: ArchivedEnum | boolean;
}
// #134847 Redefine model for tag.
export interface TagOption {
    key: string;
    value: string;
    i18nCode: string;
}

export enum ArchivedEnum {
    all = "all",
    only_archived = "only_archived",
    not_archived = "not_archived",
}
