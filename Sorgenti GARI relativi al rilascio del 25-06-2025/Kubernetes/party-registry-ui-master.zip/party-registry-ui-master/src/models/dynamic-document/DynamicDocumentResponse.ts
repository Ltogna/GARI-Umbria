import { z } from "zod";
import { DocumentResponseSchema, DocumentResponseListSchema } from "patri-common-ui/src";

export const PartyDocumentResponseSchema = DocumentResponseSchema.extend({
    partyId: z.number(),
});
export type PartyDocumentResponse = z.infer<typeof PartyDocumentResponseSchema>;

export const PartyDocumentResponseListSchema = DocumentResponseListSchema.extend({
    records: z.array(PartyDocumentResponseSchema),
});
export type PartyDocumentResponseList = z.infer<typeof PartyDocumentResponseListSchema>;
