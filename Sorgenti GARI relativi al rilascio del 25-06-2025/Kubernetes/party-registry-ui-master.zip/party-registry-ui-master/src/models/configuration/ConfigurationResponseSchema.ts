import { z } from "zod";

export const ConfigurationResponseSchema = z
    .object({
        configurationKey: z.string(),
        configuration: z.record(z.any()),
    })
    .nullable()
    .optional();
export type ConfigurationResponse = z.infer<typeof ConfigurationResponseSchema>;
