import { z } from "zod";
import { InfiniteListResultsSchema, MunicipalitySearchResponseSchema } from "patri-common-ui/src";
import { TagResponseSchema } from "./tag/TagSearchResponseSchema";

const PartyTypeEnumSchema = z.enum(["N", "L"]);
export type PartyTypeEnum = z.infer<typeof PartyTypeEnumSchema>;

const GenderEnumSchema = z.enum(["M", "F"]);
export type GenderEnum = z.infer<typeof GenderEnumSchema>;

export const AddressSchema = z.object({
    id: z.number(),
    municipality: z.string().nullable(),
    locality: z.string().nullable(),
    street: z.string().nullable(),
    houseNumber: z.string().nullable(),
    postcode: z.string().nullable(),
    details: z.string().nullable(),
    note: z.string().nullable(),
    municipalityI18nCode: z.string().nullable(),
    districtShortDescr: z.string().nullable().optional(),
    municipalityDetail: MunicipalitySearchResponseSchema.nullable().optional(),
});

export const ExternalSourceSchema = z.object({ code: z.string(), allowManual: z.boolean(), description: z.string() });
export const ExternalSourcesResponseSchema = z.array(ExternalSourceSchema).nullable();
export type ExternalSourcesResponse = z.infer<typeof ExternalSourcesResponseSchema>;

export const SubjectInExternalSourceResponseSchema = z.boolean();
export type SubjectInExternalSourceResponse = z.infer<typeof SubjectInExternalSourceResponseSchema>;

export const PartyResponseSchema = z.object({
    id: z.number(),
    partyType: PartyTypeEnumSchema,
    gender: z.nullable(GenderEnumSchema.or(z.undefined())),
    lastName: z.string(),
    firstName: z.nullable(z.string().or(z.undefined())),
    taxCode: z.nullable(z.string().or(z.undefined())),
    code: z.string().nullable().optional(),
    vatNumber: z.nullable(z.string().or(z.undefined())),
    birthDate: z.nullable(z.string().or(z.undefined())),
    deathDate: z.nullable(z.string().or(z.undefined())),
    birthCountry: z.nullable(z.string().or(z.undefined())),
    birthDistrict: z.nullable(z.string().or(z.undefined())),
    birthCity: z.nullable(z.string().or(z.undefined())),
    birthMunicipality: z.nullable(z.string().or(z.undefined())),
    birthRegion: z.nullable(z.string().or(z.undefined())),
    nationality: z.nullable(z.string().or(z.undefined())),
    addressResidential: AddressSchema.nullable().optional(),
    addressHome: AddressSchema.nullable().optional(),
    addressBilling: AddressSchema.nullable().optional(),
    archived: z.boolean(),
    legalStatus: z.nullable(z.string().or(z.undefined())),
    tags: z.array(TagResponseSchema).or(z.undefined()),
    externalSource: ExternalSourceSchema.nullable().optional(),
});
export type PartyResponse = z.infer<typeof PartyResponseSchema>;

export const AddressResponseSchema = AddressSchema.extend({
    countryI18nCode: z.nullable(z.string()),
    municipalityI18nCode: z.nullable(z.string()),
    districtI18nCode: z.nullable(z.string()),
});
export type AddressResponse = z.infer<typeof AddressResponseSchema>;

export const PartySearchResponseSchema = PartyResponseSchema.extend({
    addressResidential: z.nullable(AddressSchema.or(z.undefined())),
    addressHome: z.nullable(AddressSchema.or(z.undefined())),
    addressBilling: z.nullable(AddressSchema.or(z.undefined())),
});
export type PartySearchResponse = z.infer<typeof PartySearchResponseSchema>;

export const PartySearchResponseListSchema = InfiniteListResultsSchema.extend({
    records: z.array(PartySearchResponseSchema),
});
export type PartySearchResponseList = z.infer<typeof PartySearchResponseListSchema>;

export const PartyCheckResponseSchema = z.object({
    duplicated: z.boolean(),
});
export const PartyCheckDetailedResponseSchema = z.object({
    codiceFiscale: z.boolean().nullable().optional(),
    partitaIva: z.boolean().nullable().optional(),
});
export type PartyCheckDetailedResponse = z.infer<typeof PartyCheckDetailedResponseSchema>;

export const ReadOnlyFieldsModelSchema = z.object({
    id: z.boolean().optional(),
    partyType: z.boolean().optional(),
    gender: z.boolean().optional(),
    lastName: z.boolean().optional(),
    firstName: z.boolean().optional(),
    taxCode: z.boolean().optional(),
    code: z.boolean().optional(),
    vatNumber: z.boolean().optional(),
    birthDate: z.boolean().optional(),
    deathDate: z.boolean().optional(),
    birthCountry: z.boolean().optional(),
    birthDistrict: z.boolean().optional(),
    birthCity: z.boolean().optional(),
    birthMunicipality: z.boolean().optional(),
    birthRegion: z.boolean().optional(),
    nationality: z.boolean().optional(),
    addressResidential: z.any().optional(),
    addressHome: z.any().optional(),
    addressBilling: z.any().optional(),
    archived: z.boolean().optional(),
    legalStatus: z.boolean().optional(),
    tags: z.boolean().optional(),
});
export type ReadOnlyFieldsModel = z.infer<typeof ReadOnlyFieldsModelSchema>;

export const userConfigResponseSchema = z.object({
    isFromExternalSource: z.boolean(),
    addPartyRegistryEnabled: z.boolean(),
    readOnlyFieldsForIncomingData: ReadOnlyFieldsModelSchema,
});
export type userConfigResponse = z.infer<typeof userConfigResponseSchema>;
