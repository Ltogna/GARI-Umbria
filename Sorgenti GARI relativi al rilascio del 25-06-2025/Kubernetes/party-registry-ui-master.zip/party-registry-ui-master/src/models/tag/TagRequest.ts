export interface Tag {
    id: number;
    code: string;
    i18nCode: string;
}
