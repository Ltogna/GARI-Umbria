import { z } from "zod";
import { InfiniteListResultsSchema } from "patri-common-ui/src";

export const TagResponseSchema = z.object({
    id: z.number(),
    code: z.string(),
    i18nCode: z.nullable(z.string()),
});
export type TagResponse = z.infer<typeof TagResponseSchema>;

export const TagSearchResponseListSchema = InfiniteListResultsSchema.extend({
    records: z.array(TagResponseSchema),
});
export type TagSearchResponseList = z.infer<typeof TagSearchResponseListSchema>;

export const TagResponseListSchema = z.array(TagResponseSchema);
export type TagResponseList = z.infer<typeof TagResponseListSchema>;

export const TagRegistryResponseSchema = z.object({
    pkid: z.number(),
    partyId: z.number(),
    tagId: z.number(),
    tagCode: z.string(),
    tagI18nCode: z.nullable(z.string()),
});
export type TagRegistrySearchResponse = z.infer<typeof TagRegistryResponseSchema>;

export const TagRegistrySearchResponseListSchema = z.array(TagRegistryResponseSchema);
export type TagRegistrySearchResponseList = z.infer<typeof TagRegistrySearchResponseListSchema>;
