export const BASE = "/ui/party-registry-ui/";
export const MODULE_ID = "party-registry-ui";
export const SIDEBAR_OTHERS_GROUP_CODE = "others";
export const DEFAULT_DATE_FORMAT = "dd/MM/yyyy";
export const DEFAULT_FILE_STORE_URL = "/file-store";

export const CURRENT_DATE = new Date();
