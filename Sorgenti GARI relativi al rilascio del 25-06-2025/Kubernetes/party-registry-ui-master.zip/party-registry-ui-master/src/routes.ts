import { MODULE_ID } from "./constants";
import { useUserPermissionStore } from "./stores/userPermission";
import NewRegistryListView from "./views/NextRegistryListView.vue";
import RegistryListView from "./views/RegistryListView.vue";
import type { RouteRecordRaw } from "vue-router";

const RegistryFormView = () => import("./views/RegistryFormView.vue");
const RegistrySummaryView = () => import("./views/RegistrySummaryView.vue");

const RegistryForm = () => import("@/components/registry-form/RegistryForm.vue");
const DynamicDocumentWrapper = () => import("@/components/dynamic-document/DynamicDocumentWrapper.vue");

export enum RouteName {
    PARTY_LIST = `${MODULE_ID}:partyList`,
    PARTY_EDIT = `${MODULE_ID}:partyEdit`,
    PARTY_EDIT_REDIRECT = `${MODULE_ID}:partyEditRedirect`,
    PARTY_EDIT_FORM = `${MODULE_ID}:paryEditForm`,
    PARTY_DOC_TYPE = `${MODULE_ID}:partyDocType`,
    PARTY_SUMMARY = `${MODULE_ID}:partySummary`,
    PARTY_NEW = `${MODULE_ID}:partyNew`,
    PARTY_NEW_REDIRECT = `${MODULE_ID}:partyNewRedirect`,
    PARTY_NEW_FORM = `${MODULE_ID}:partyNewForm`,
    // next routes
    NEXT_PARTY_LIST = `${MODULE_ID}:nextPartyList`,
}

const routes: RouteRecordRaw[] = [
    {
        path: "/next", //TODO REMOVE
        name: RouteName.NEXT_PARTY_LIST,
        component: NewRegistryListView,
    },
    {
        path: "/",
        name: RouteName.PARTY_LIST,
        component: RegistryListView,
    },
    {
        path: "/edit/:regId",
        name: RouteName.PARTY_EDIT,
        components: {
            default: RegistryFormView,
            leaveConfirmationModal: () => import("patri-common-ui/src/components/LeaveDirtyPageModal.vue"),
        },
        props: true,
        children: [
            {
                path: "",
                name: RouteName.PARTY_EDIT_REDIRECT,
                redirect: () => {
                    return { name: RouteName.PARTY_EDIT_FORM };
                },
            },
            {
                path: "form",
                name: RouteName.PARTY_EDIT_FORM,
                component: RegistryForm,
                props: true,
            },
            {
                path: "doc/:docType",
                name: RouteName.PARTY_DOC_TYPE,
                component: DynamicDocumentWrapper,
            },
        ],
    },
    {
        path: "/new",
        name: RouteName.PARTY_NEW,
        components: {
            default: RegistryFormView,
            leaveConfirmationModal: () => import("patri-common-ui/src/components/LeaveDirtyPageModal.vue"),
        },
        beforeEnter: async () => {
            // #135102 get if an user can create
            return await useUserPermissionStore().getCanCreateParties;
        },
        children: [
            {
                path: "",
                name: RouteName.PARTY_NEW_REDIRECT,
                redirect: () => {
                    return { name: RouteName.PARTY_NEW_FORM };
                },
            },
            {
                path: "form",
                name: RouteName.PARTY_NEW_FORM,
                component: RegistryForm,
            },
        ],
    },
    {
        path: "/summary",
        name: RouteName.PARTY_SUMMARY,
        component: RegistrySummaryView,
    },
];

export default routes;
