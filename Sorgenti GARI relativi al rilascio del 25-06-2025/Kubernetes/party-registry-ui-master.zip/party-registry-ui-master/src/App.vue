<script setup lang="ts">
import BiNotification from "@abaco/bootstrap-italia-components/src/components/BiNotification/BiNotification.vue";
import type { ErrorModel } from "@abaco/bootstrap-italia-components/src/models";
import { useAlertsStore } from "@abaco/bootstrap-italia-components/src/stores/alertsStore";
import { useNotification } from "patri-common-ui/src/hooks/useApiResponseHandler";
import { computed, onMounted, ref, watch } from "vue";
import { RouterView } from "vue-router";
import { MODULE_ID } from "./constants";
import { useConfiguration } from "./hooks/useConfiguration";
import { usePermissions } from "./hooks/useUserPermissions";

const { loadCuaaDisplayability, loadPartyTypeEditability, loadLegalStatusDisplayability, loadVatNumberDisplayability } =
    useConfiguration();
const { loadUserPermissions } = usePermissions();

const alertStore = useAlertsStore();
const { message } = useNotification(MODULE_ID);

const showNoticationError = ref(false);
const error = ref<ErrorModel>();

watch(
    () => alertStore.error,
    (value) => {
        error.value = value;
        showNoticationError.value = !!value;
    },
);

onMounted(async () => {
    await loadCuaaDisplayability();
    await loadPartyTypeEditability();
    // #135102 load user permissions
    await loadUserPermissions();
    // #164897
    await loadLegalStatusDisplayability();
    await loadVatNumberDisplayability();
});

const notificationProps = computed(() => {
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const { open: _1, ...rest } = message;
    return rest;
});
</script>

<template>
    <main ref="sectionRef" class="party-registry">
        <RouterView />
        <RouterView name="leaveConfirmationModal" />
        <BiNotification v-bind="notificationProps" v-model="message.open" />
    </main>
</template>
