import { inject } from "vue";
import type PartyConfigurationPublicApi from "@/api/public/party-configuration-public-api";
import { useConfigurationStore, type RegExpRulesConfiguration } from "@/stores/configuration";
import { useApiResponseHandler } from "@/index";

const CUAA_CONFIG_KEY = "code";
const PARTY_TYPE_KEY = "party_type";
const VAT_NUMBER_VALIDATION_KEY = "vatNumber_validation";
const VAT_NUMBER_KEY = "vat_number";
const TAX_CODE_VALIDATION_KEY = "taxCode_validation";
const CUAA_VALIDATION_KEY = "code_validation";
const NATIONALITY_KEY = "nationality";
const LEGAL_STATUS_VALIDATION_KEY = "legalStatus_validation";
const LEGAL_STATUS_KEY = "legal_status";

export function useConfiguration() {
    const partyConfigPublicApi: PartyConfigurationPublicApi = inject(
        "partyConfigPublicApi",
    ) as PartyConfigurationPublicApi;

    const configurationStore = useConfigurationStore();

    async function loadCuaaDisplayability() {
        const res = await useApiResponseHandler(() => partyConfigPublicApi.getConfigByKey(CUAA_CONFIG_KEY));
        configurationStore.setCuaaConfig(res ?? null);
    }

    async function loadPartyTypeEditability() {
        const res = await useApiResponseHandler(() => partyConfigPublicApi.getConfigByKey(PARTY_TYPE_KEY));
        configurationStore.setPartyTypeConfig(res ?? null);
    }

    async function loadVatNumberRegexRules() {
        const res = await useApiResponseHandler(() => partyConfigPublicApi.getConfigByKey(VAT_NUMBER_VALIDATION_KEY));
        configurationStore.setVatNumberValidationConfig(res as RegExpRulesConfiguration);
    }

    async function loadVatNumberDisplayability() {
        const res = await useApiResponseHandler(() => partyConfigPublicApi.getConfigByKey(VAT_NUMBER_KEY));
        configurationStore.setVatNumberConfig(res ?? null);
    }

    async function loadTaxCodeRegexRules() {
        const res = await useApiResponseHandler(() => partyConfigPublicApi.getConfigByKey(TAX_CODE_VALIDATION_KEY));
        configurationStore.setTaxCodeConfig(res as RegExpRulesConfiguration);
    }

    async function loadCodeRegexRules() {
        const res = await useApiResponseHandler(() => partyConfigPublicApi.getConfigByKey(CUAA_VALIDATION_KEY));
        configurationStore.setCodeConfig(res as RegExpRulesConfiguration);
    }

    async function loadNationalityMandatory() {
        const res = await useApiResponseHandler(() => partyConfigPublicApi.getConfigByKey(NATIONALITY_KEY));
        configurationStore.setNationalityConfig(res ?? null);
    }

    async function loadLegalStatusRegexRules() {
        const res = await useApiResponseHandler(() => partyConfigPublicApi.getConfigByKey(LEGAL_STATUS_VALIDATION_KEY));
        configurationStore.setLegalStatusValidationConfig(res as RegExpRulesConfiguration);
    }

    async function loadLegalStatusDisplayability() {
        const res = await useApiResponseHandler(() => partyConfigPublicApi.getConfigByKey(LEGAL_STATUS_KEY));
        configurationStore.setLegalStatusConfig(res ?? null);
    }

    async function loadValidationConfig() {
        await loadTaxCodeRegexRules();
        await loadVatNumberRegexRules();
        await loadCodeRegexRules();
        await loadNationalityMandatory();
        await loadLegalStatusRegexRules();
    }

    return {
        loadCuaaDisplayability,
        loadPartyTypeEditability,
        loadVatNumberRegexRules,
        loadTaxCodeRegexRules,
        loadValidationConfig,
        loadNationalityMandatory,
        loadLegalStatusRegexRules,
        loadLegalStatusDisplayability,
        loadVatNumberDisplayability,
    };
}
