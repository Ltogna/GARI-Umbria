import type NationalityApi from "@/api/nationality-api";
import type { NationalityAutocompleteResponse } from "patri-common-ui/src";

import { inject } from "vue";
import { useApiResponseHandler } from "@/index";
import type { GenericSearchResponse } from "@/models/LegalStatus";

export function useNationalityAutocomplete() {
    const nationalityApi: NationalityApi = inject("nationalityApi") as NationalityApi;

    async function getNationalityList(): Promise<GenericSearchResponse[]> {
        const list: GenericSearchResponse[] = [];
        let nextKey: string | undefined = undefined;
        do {
            const res = await useApiResponseHandler<NationalityAutocompleteResponse>(() =>
                nationalityApi.getNationalities(nextKey),
            );
            if (res) {
                nextKey = res.nextKey ?? undefined;
                list.push(...res.records);
            }
        } while (nextKey);

        if (list.length) {
            return list
                .filter((fl) => !!fl?.i18nCode)
                .sort((a, b) => {
                    const i18nCodeA = a.i18nCode ?? "";
                    const i18nCodeB = b.i18nCode ?? "";

                    return i18nCodeA.localeCompare(i18nCodeB);
                });
        }

        return Promise.resolve([]);
    }

    async function getNationalityById(code: string): Promise<GenericSearchResponse | null> {
        const res: GenericSearchResponse | null = await useApiResponseHandler<GenericSearchResponse>(() =>
            nationalityApi.getNationalityByCode(code),
        );

        return res ?? Promise.resolve(null);
    }

    return {
        getNationalityList,
        getNationalityById,
    };
}
