import type TagApi from "@/api/tag-api";
import type { TagResponse, TagResponseList } from "@/models/tag/TagSearchResponseSchema";
import { useTagStore } from "@/stores/tag";
import { computed, inject } from "vue";
import { useApiResponseHandler } from "@/index";

export function useTags() {
    const tagApi: TagApi = inject("tagApi") as TagApi;
    const tagStore = useTagStore();

    const tagList = computed<TagResponseList>(() => tagStore.getListValues);
    const tags = computed<Record<string, TagResponse>>(() => tagStore.getListByCode);
    async function fetchTagList() {
        if (tagList.value.length) {
            return;
        }
        const res = await useApiResponseHandler(() => tagApi.getTags());

        res && tagStore.setList(res);
    }

    return {
        tags,
        tagList,
        fetchTagList,
    };
}
