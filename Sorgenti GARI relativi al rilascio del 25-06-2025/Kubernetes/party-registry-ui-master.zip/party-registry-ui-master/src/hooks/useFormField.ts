import { computed, ref } from "vue";

export interface FormFieldProps {
    id: string;
    modelValue?: unknown;
    isDisabled?: boolean;
    isReadonly?: boolean;
    info?: string;
    label?: string;
    extraClasses?: string[];
    validatorFn?: (id: string) => Promise<boolean>;
    formatFn?: (value: unknown) => string;
}

// eslint-disable-next-line @typescript-eslint/no-explicit-any
export function useFormField<T extends FormFieldProps>(props: T, emit: any) {
    const isBlurred = ref(false);

    const isValid = ref(true);

    const helpId = computed(() => {
        return `${props.id}-helpDescription`;
    });

    /**
     * If label is present
     */
    const hasLabel = computed(() => props.label && props.label.length > 0);

    async function validate() {
        if (props.validatorFn) {
            isValid.value = await props.validatorFn(`#${props.id}`);
        }
    }

    const onBlur = () => {
        isBlurred.value = true;
        validate();
    };

    const onInput = (e: Event) => {
        if (isBlurred.value) {
            validate();
        }
        emitUpdateModelValue(e);
    };

    const onChange = (e: Event) => {
        emitUpdateModelValue(e);
    };

    function formatInputValue(value: unknown) {
        if (props.formatFn) {
            return props.formatFn(value);
        }

        return value;
    }

    function emitUpdateModelValue(e: Event) {
        const value = formatInputValue((e.target as HTMLInputElement | HTMLSelectElement).value);
        emit("update:model-value", value as string);
    }

    return {
        isValid,
        helpId,
        hasLabel,
        validate,
        onBlur,
        onInput,
        onChange,
    };
}
