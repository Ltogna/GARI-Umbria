/**
 * #135102 added user permissions hooks
 */

import { inject } from "vue";
import type UserPermissionApi from "@/api/user-permission-api";
import { useUserPermissionStore } from "@/stores/userPermission";
import { useApiResponseHandler } from "@/index";

export function usePermissions() {
    const userPermissionApi: UserPermissionApi = inject("userPermissionApi") as UserPermissionApi;

    const userPermissionStore = useUserPermissionStore();

    async function loadUserPermissions() {
        const res = await useApiResponseHandler(() => userPermissionApi.getUserPermissions());
        userPermissionStore.setUserPermissions(res);
    }

    return {
        loadUserPermissions,
    };
}
