import type RegistryApi from "@/api/registry-api";
import { i18n } from "patri-common-ui/src";
import type { PartyResponse } from "@/models/PartySearchResponseSchema";
import { GenderEnum, PartyType, type RegistryRequest } from "@/models/RegistryRequest";
import { useRegistryStore } from "@/stores/registry";
import { computed, inject, watch } from "vue";
import { useRouter } from "vue-router";
import { useApiResponseHandler } from "@/index";
import { MODULE_ID } from "@/constants";
import type PartyConfigurationPublicApi from "@/api/public/party-configuration-public-api";

const CUAA_CONFIG_KEY = "code";

export function useRegistryForm(initRegistryFormFn: (value: PartyResponse | null) => void) {
    const registryApi: RegistryApi = inject("registryApi") as RegistryApi;
    const partyConfigPublicApi: PartyConfigurationPublicApi = inject(
        "partyConfigPublicApi",
    ) as PartyConfigurationPublicApi;

    const registryStore = useRegistryStore();
    const router = useRouter();
    const { t } = i18n.global;

    const partyTypes = Object.keys(PartyType).map((key) => ({
        key,
        value: t(`${MODULE_ID}.registry.form.fields.partyTypeEnum.` + key),
    }));

    const genders = Object.keys(GenderEnum).map((key) => ({
        id: key,
        text: t(`${MODULE_ID}.registry.form.fields.genderEnum.` + key),
    }));

    const regId = computed(() => {
        if (router.currentRoute.value.params["regId"]) {
            return Number(router.currentRoute.value.params["regId"]);
        }
        return null;
    });

    const registryDetail = computed(() => {
        if (regId.value) {
            return registryStore.currentDetail;
        }
        return null;
    });

    watch(registryDetail, (value) => {
        initRegistryFormFn(value);
    });

    async function create(formValue: Partial<RegistryRequest>) {
        const res = await useApiResponseHandler(() => registryApi.createRegistry(formValue));
        return res;
    }

    async function update(regId: number, formValue: Partial<RegistryRequest>) {
        const res = await useApiResponseHandler(() => registryApi.updateRegistry(regId, formValue));
        return res;
    }

    async function getCuaaDisplayability(): Promise<boolean> {
        const res = await useApiResponseHandler(() => partyConfigPublicApi.getConfigByKey(CUAA_CONFIG_KEY));
        return !!res;
    }

    return {
        registryDetail: registryDetail.value,
        regId,
        create,
        update,
        getCuaaDisplayability,
        partyTypes,
        genders,
    };
}
