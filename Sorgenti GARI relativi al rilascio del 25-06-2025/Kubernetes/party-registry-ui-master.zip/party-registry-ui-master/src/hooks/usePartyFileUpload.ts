import { ref } from "vue";
import type { FileUploadConfig } from "@abaco/dynamic-documents/src/resources/composables/useFiles";

const { VITE_REGISTRY_SERVICE } = import.meta.env;

export interface FileUploadConfigParams {
    tenantId: string;
    partyId: number;
    docId?: number;
    docType: string;
    bucketName: string;
}

export function usePartyFileUpload() {
    const fileUploadConfig = ref<FileUploadConfig>();

    function updateFileUploadConfig(configParams: FileUploadConfigParams) {
        const { tenantId, partyId, docId, docType, bucketName } = configParams;
        const baseRootPath = `/${VITE_REGISTRY_SERVICE}/${tenantId}`;
        fileUploadConfig.value = {
            bucketName,
            readUrl: docId
                ? `${baseRootPath}/api-priv/v1/parties/${partyId}/documents/type/${docType}/${docId}/attachments`
                : "",
            tenantId,
        };
    }

    return {
        updateFileUploadConfig,
        fileUploadConfig,
    };
}
