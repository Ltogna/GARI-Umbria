<script lang="ts">
/**
 * # Party PickerModal
 *
 * @deprecated Since v0.2.33
 */
export default {};
</script>

<script setup lang="ts">
import { ref } from "vue";

import BiButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiButton.vue";
import BiModal from "@abaco/bootstrap-italia-components/src/components/BiModal/BiModal.vue";
import { getUUID } from "@abaco/bootstrap-italia-components/src/utilities";

import type { PartySearchResponse } from "../../models/PartySearchResponseSchema";
import PartyPicker from "./PartyPicker.vue";

defineProps<{
    btnLabel: string;
    modalTitle: string;
}>();
const emit = defineEmits<{
    (e: "select-party", value: PartySearchResponse): void;
}>();

const modalVisible = ref(false);
const showModal = ref(false);

function openModal() {
    showModal.value = true;
    toggleModalVisibility(true);
}
function dismissModal() {
    showModal.value = false;
}
function toggleModalVisibility(toggleVisibility: boolean) {
    modalVisible.value = toggleVisibility;
}
function onSelectParty(selectedParty: PartySearchResponse) {
    emit("select-party", selectedParty);
    dismissModal();
}
</script>
<template>
    <BiButton @click="openModal" :is-outlined="true" color="primary">
        {{ btnLabel }}
    </BiButton>
    <Teleport to="body">
        <BiModal
            size="xl"
            ariaLabelledby="party-picker-modal"
            :id="getUUID()"
            v-model="showModal"
            :title="modalTitle"
            data-keyboard="false"
            data-backdrop="static"
            extra-body-class="pt-5"
            @hidden-modal="toggleModalVisibility(false)"
        >
            <template #body>
                <PartyPicker v-if="modalVisible" @cancel="dismissModal" @select-party="onSelectParty" />
            </template>
        </BiModal>
    </Teleport>
</template>
