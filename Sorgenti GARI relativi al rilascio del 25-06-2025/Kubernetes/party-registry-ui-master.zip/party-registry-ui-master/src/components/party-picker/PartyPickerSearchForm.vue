<script lang="ts">
/**
 * # Party Picker Search Form
 *
 * @deprecated Since v0.2.33
 */
export default {};
</script>

<script setup lang="ts">
import JustValidate from "just-validate";
import { computed, inject, onMounted, reactive, ref, toRaw } from "vue";

import BiNotification from "@abaco/bootstrap-italia-components/src/components/BiNotification/BiNotification.vue";
import BiButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiButton.vue";
import BiInput from "@abaco/bootstrap-italia-components/src/components/form/BiInput.vue";
import { getUUID } from "@abaco/bootstrap-italia-components/src/utilities";

import { useForm } from "patri-common-ui/src";
import { i18n, type I18nInterface, BiSelectCustom } from "patri-common-ui/src";
import { useApiResponseHandler } from "../../index";

import type PartyTagPublicApi from "../../api/public/party-tag-public-api";

import { ArchivedEnum, type RegistrySearchRequest } from "../../models/RegistrySearchRequest";
import type { TagResponse } from "../../models/tag/TagSearchResponseSchema";
import { formUtils } from "patri-common-ui/src";
import { MODULE_ID } from "../../constants";
import { MODULE_ID as COMMON_MODULE_ID } from "patri-common-ui/src/constants";

const emit = defineEmits<{
    (e: "search", value: Partial<RegistrySearchRequest>): void;
    (e: "cancel"): void;
}>();

const { justValidateConfig } = formUtils;
const partyTagPublicApi = inject("partyTagPublicApi") as PartyTagPublicApi;
const i18nService = inject<I18nInterface | null>("partyI18nService", null);
const { t } = i18nService?.global ?? i18n.global;

const formId = getUUID();
const searchForm = reactive<Partial<RegistrySearchRequest>>({
    archived: ArchivedEnum.not_archived,
});
const searchFormRef = ref();
const tagList = ref<TagResponse[]>();

const { validate, isSubmitted, onSubmit } = useForm(submitCallback, searchForm, formId);

const atLeastOneField = computed(() => {
    return Object.keys(searchForm).some((key) => {
        if (key === "archived") {
            return false;
        }
        if (Array.isArray((searchForm as Record<string, unknown>)[key])) {
            const valid = !!((searchForm as Record<string, unknown>)[key] as unknown[]).length;
            return valid;
        }
        return !!(searchForm as Record<string, unknown>)[key];
    });
});
const tagSelectItems = computed(
    () => tagList.value?.map((it) => Object.assign({ key: it.code, value: it.i18nCode ?? it.code }, {})) ?? [],
);

onMounted(async () => {
    validate.value = new JustValidate(searchFormRef.value, justValidateConfig);
    await fetchTagList();
});

function submitCallback() {
    atLeastOneField.value && emit("search", toRaw(searchForm));
}
function cancel() {
    emit("cancel");
}
async function fetchTagList() {
    const res = await useApiResponseHandler(() => partyTagPublicApi.getTags());
    res && (tagList.value = res);
}

// TODO: #134847 autocompete con tags
const model = computed({
    get() {
        return searchForm.tag?.map((v) => v.key) ?? [];
    },
    set(value: string[]) {
        if (!searchForm.tag) {
            searchForm.tag = [];
        }
        const tags = tagList.value?.filter((v) => value.includes(v.code));
        if (tags) {
            for (const tag of tags) {
                searchForm.tag.push({
                    key: tag.code,
                    value: tag.i18nCode ?? tag.code,
                    i18nCode: tag.i18nCode ?? tag.code,
                });
            }
        }
    },
});
</script>

<template>
    <form
        :id="formId"
        class="party-registry-ui__registry-search-form needs-validation pt-5"
        ref="searchFormRef"
        @submit.prevent="onSubmit"
    >
        <div class="row">
            <div class="form-group col-md-6">
                <BiInput
                    v-model="searchForm.taxOrVat"
                    :label="t(`${MODULE_ID}.registry.search.taxOrVat`)"
                    name="taxOrVat"
                    :placeholder="t(`${MODULE_ID}.registry.search.inputPlaceholder`)"
                />
            </div>
            <div class="form-group col-md-6">
                <div class="registry-search-form__select form-group input-container has-label">
                    <!-- TODO: #134847 autocompete con tags -->
                    <BiSelectCustom
                        :id="getUUID()"
                        name="tags"
                        :label="t(`${MODULE_ID}.registry.form.fields.tags.label`)"
                        :is-multiple="true"
                        :placeholder="t(`${MODULE_ID}.registry.form.fields.tags.placeholder`)"
                        :items="tagSelectItems"
                        v-model="model"
                    ></BiSelectCustom>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="form-group col-md-6">
                <BiInput
                    v-model="searchForm.lastName"
                    :label="t(`${MODULE_ID}.registry.search.lastName`)"
                    name="lastName"
                    :placeholder="t(`${MODULE_ID}.registry.search.inputPlaceholder`)"
                />
            </div>
            <div class="form-group col-md-6">
                <BiInput
                    v-model="searchForm.firstName"
                    :label="t(`${MODULE_ID}.registry.search.firstName`)"
                    name="firstName"
                    :placeholder="t(`${MODULE_ID}.registry.search.inputPlaceholder`)"
                />
            </div>
        </div>

        <div class="row">
            <div class="form-group col-md-12 text-center">
                <BiButton @click="cancel" :is-outlined="true" color="primary" class="btn-me">
                    {{ t(`${COMMON_MODULE_ID}.general.cancel`) }}
                </BiButton>
                <BiButton type="submit" color="success">
                    {{ t(`${COMMON_MODULE_ID}.general.search`) }}
                </BiButton>
            </div>
        </div>
    </form>
    <BiNotification
        :model-value="!atLeastOneField && isSubmitted"
        :title="t(`${COMMON_MODULE_ID}.general.warning`)"
        :variant="'error'"
        :text="t(`${MODULE_ID}.registry.search.errors.atLeastOneField`)"
        :icon="'circle-xmark'"
    />
</template>

<style lang="scss" scoped>
.party-registry-ui__registry-search-form {
    .registry-search-form__select {
        margin-top: 1.2em;
    }
}
</style>
