<script lang="ts">
/**
 * # Party Picker List
 *
 * @deprecated Since v0.2.33
 */
export default {};
</script>

<script setup lang="ts">
import BiButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiButton.vue";
import BiIcon from "@abaco/bootstrap-italia-components/src/components/BiIcon/BiIcon.vue";
import BiTable from "@abaco/bootstrap-italia-components/src/components/BiTable/BiTable.vue";
import { inject } from "vue";

import { i18n, type I18nInterface } from "patri-common-ui/src";
import type { PartySearchResponse } from "../../models/PartySearchResponseSchema";
import { MODULE_ID } from "../../constants";
import { MODULE_ID as COMMON_MODULE_ID } from "patri-common-ui/src/constants";
import useColors from "@abaco/bootstrap-italia-components/src/composables/useColors";

withDefaults(
    defineProps<{
        partyList: PartySearchResponse[];
        showLoadMore?: boolean;
    }>(),
    { showLoadMore: false },
);
const emit = defineEmits<{
    (e: "load-more"): void;
    (e: "select-party", value: PartySearchResponse): void;
}>();

const { getColor } = useColors();

const i18nService = inject<I18nInterface | null>("partyI18nService", null);
const { t } = i18nService?.global ?? i18n.global;

function loadMore() {
    emit("load-more");
}

function selectParty(value: PartySearchResponse) {
    emit("select-party", value);
}
</script>
<template>
    <BiTable class="table mb-0" extraTableClasses="table-head-bg" is-row-hover isResponsive>
        <template #head>
            <tr class="bg-light" :class="getColor('text', 'secondary')">
                <th scope="col">{{ t(`${MODULE_ID}.registry.list.fields.lastName`) }}</th>
                <th scope="col">{{ t(`${MODULE_ID}.registry.list.fields.firstName`) }}</th>
                <th scope="col">{{ t(`${MODULE_ID}.registry.list.fields.taxCode`) }}</th>
                <th scope="col">{{ t(`${MODULE_ID}.registry.list.fields.vatNumber`) }}</th>
                <th scope="col"></th>
            </tr>
        </template>
        <template #body>
            <tr v-for="(item, i) in partyList" :key="i">
                <td :data-label="t(`${MODULE_ID}.registry.list.fields.lastName`)">
                    {{ item.lastName }}
                </td>
                <td :data-label="t(`${MODULE_ID}.registry.list.fields.firstName`)">
                    {{ item.firstName }}
                </td>
                <td :data-label="t(`${MODULE_ID}.registry.list.fields.taxCode`)">
                    {{ item.taxCode }}
                </td>
                <td :data-label="t(`${MODULE_ID}.registry.list.fields.vatNumber`)">
                    {{ item.vatNumber }}
                </td>
                <td class="actions">
                    <BiButton
                        :title="t(`${COMMON_MODULE_ID}.general.add`)"
                        size="xs"
                        color="info"
                        is-outlined
                        is-icon
                        :width="40"
                        :height="38"
                        @click="selectParty(item)"
                    >
                        <BiIcon icon="plus"></BiIcon>
                    </BiButton>
                </td>
            </tr>
        </template>
    </BiTable>
    <div class="d-flex justify-content-end mb-4" v-if="showLoadMore">
        <BiButton :is-outlined="true" color="primary" @click="loadMore()">
            {{ t(`${COMMON_MODULE_ID}.general.loadMore`) }}
        </BiButton>
    </div>
</template>
