<script lang="ts">
/**
 * # Party Picker
 * @deprecated Since v0.2.33
 */
export default {};
</script>

<script setup lang="ts">
import { inject, ref } from "vue";

import type PartyPublicApi from "../../api/public/party-public-api";

import type { RegistrySearchRequest } from "../../models/RegistrySearchRequest";
import type { PartySearchResponse } from "../../models/PartySearchResponseSchema";
import PartyPickerSearchForm from "./PartyPickerSearchForm.vue";
import PartyPickerList from "./PartyPickerList.vue";
import { useApiResponseHandler } from "../../index";

const emit = defineEmits<{
    (e: "cancel"): void;
    (e: "select-party", value: PartySearchResponse): void;
}>();

const partyPublicApi = inject("partyPublicApi") as PartyPublicApi;

const currentSearch = ref<Partial<RegistrySearchRequest>>();
const partyList = ref<PartySearchResponse[] | null>();
const nextKey = ref<string | null>();

function onCancel() {
    emit("cancel");
}
function onSelectParty(selectedParty: PartySearchResponse) {
    emit("select-party", selectedParty);
}
async function onLoadMore() {
    currentSearch.value && (await fetchParties(currentSearch.value));
}
async function onSearch(searchForm: Partial<RegistrySearchRequest>) {
    currentSearch.value = searchForm;
    await fetchParties(currentSearch.value);
}
async function fetchParties(searchForm: Partial<RegistrySearchRequest>) {
    const res = await useApiResponseHandler(() => partyPublicApi.getParties(searchForm, nextKey.value ?? undefined));
    res?.nextKey && (nextKey.value = res.nextKey);
    res?.records && (partyList.value = res.records);
}
</script>
<template>
    <PartyPickerSearchForm @cancel="onCancel" @search="onSearch" />
    <PartyPickerList
        v-if="partyList"
        :party-list="partyList"
        :show-load-more="!!nextKey"
        @load-more="onLoadMore"
        @select-party="onSelectParty"
    />
</template>
