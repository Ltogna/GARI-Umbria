<script setup lang="ts">
import { i18n } from "patri-common-ui/src";

import BiIcon from "@abaco/bootstrap-italia-components/src/components/BiIcon/BiIcon.vue";
import BiTable from "@abaco/bootstrap-italia-components/src/components/BiTable/BiTable.vue";
import BiButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiButton.vue";
import BiAlert from "@abaco/bootstrap-italia-components/src/components/BiAlert/BiAlert.vue";
import type { PartySearchResponse } from "@/models/PartySearchResponseSchema";
import { MODULE_ID } from "@/constants";
import { MODULE_ID as COMMON_MODULE_ID } from "patri-common-ui/src/constants";
import { useRouter } from "vue-router";
import useColors from "@abaco/bootstrap-italia-components/src/composables/useColors";
import { RouteName } from "@/routes";
import usePermissions from "@/hooks/usePermissions";

withDefaults(
    defineProps<{
        registryList: PartySearchResponse[];
        showLoadMore?: boolean;
    }>(),
    { showLoadMore: false },
);

const { t } = i18n.global;
const router = useRouter();
const { getColor } = useColors();
const { canWrite } = usePermissions();

const emit = defineEmits<{
    (e: "load-more"): void;
}>();

function loadMore() {
    emit("load-more");
}

function onSelectRegistry(selectedRegistryId: number) {
    router.push({ name: RouteName.PARTY_EDIT_FORM, params: { regId: selectedRegistryId }, query: { backUrl: "" } });
}
</script>
<template>
    <BiTable class="table mb-0" extraTableClasses="table-head-bg" is-row-hover isResponsive>
        <template #head>
            <tr class="bg-light" :class="getColor('text', 'secondary')">
                <th scope="col">{{ t(`${MODULE_ID}.registry.list.fields.lastName`) }}</th>
                <th scope="col">{{ t(`${MODULE_ID}.registry.list.fields.firstName`) }}</th>
                <th scope="col">{{ t(`${MODULE_ID}.registry.list.fields.person`) }}</th>
                <th scope="col">{{ t(`${MODULE_ID}.registry.list.fields.taxCode`) }}</th>
                <th scope="col">{{ t(`${MODULE_ID}.registry.list.fields.vatNumber`) }}</th>
                <th scope="col">{{ t(`${MODULE_ID}.registry.list.fields.addressResidential`) }}</th>
                <th scope="col">{{ t(`${MODULE_ID}.registry.list.fields.pcodMunicDistr`) }}</th>
                <th scope="col" class="text-center">{{ t(`${MODULE_ID}.registry.list.fields.archived`) }}</th>
                <th scope="col"></th>
            </tr>
        </template>
        <template #body>
            <tr v-for="(item, i) in registryList" :key="i" :class="{ 'text-muted': item.archived }">
                <td :data-label="t(`${MODULE_ID}.registry.list.fields.lastName`)">
                    {{ item.lastName }}
                </td>
                <td :data-label="t(`${MODULE_ID}.registry.list.fields.firstName`)">
                    {{ item.firstName }}
                </td>
                <td :data-label="t(`${MODULE_ID}.registry.list.fields.person`)">
                    {{ t(`${MODULE_ID}.registry.list.fields.partyTypeEnum.` + item.partyType) }}
                </td>
                <td :data-label="t(`${MODULE_ID}.registry.list.fields.taxCode`)">
                    {{ item.taxCode }}
                </td>
                <td :data-label="t(`${MODULE_ID}.registry.list.fields.vatNumber`)">
                    {{ item.vatNumber }}
                </td>
                <td :data-label="t(`${MODULE_ID}.registry.list.fields.addressResidential`)">
                    {{ item.addressResidential?.street }} {{ item.addressResidential?.houseNumber }}
                </td>
                <td :data-label="t(`${MODULE_ID}.registry.list.fields.pcodMunicDistr`)">
                    {{ item.addressResidential?.postcode }}
                    {{ item.addressResidential?.municipalityI18nCode }}
                    {{
                        item.addressResidential?.districtShortDescr
                            ? `(${item.addressResidential?.districtShortDescr})`
                            : ""
                    }}
                </td>
                <td :data-label="t(`${MODULE_ID}.registry.list.fields.archived`)" class="text-center">
                    <span v-if="item.archived">
                        <BiIcon icon="check" size="sm"></BiIcon>
                        <span class="visually-hidden">{{ t(`${MODULE_ID}.registry.list.fields.state.archived`) }}</span>
                    </span>
                </td>
                <td class="actions">
                    <BiButton
                        :title="t(`${MODULE_ID}.registry.list.actions.open`)"
                        size="xs"
                        color="info"
                        is-outlined
                        is-icon
                        :width="40"
                        :height="38"
                        @click="onSelectRegistry(item.id)"
                    >
                        <BiIcon icon="arrow-right" v-if="item.archived && !canWrite" />
                        <BiIcon icon="pencil" v-else />
                    </BiButton>
                </td>
            </tr>
        </template>
    </BiTable>
    <BiAlert isInfo v-if="!registryList.length" class="mb-0">
        <template #body>
            {{ t(`${MODULE_ID}.registry.form.no_element_found`) }}
        </template>
    </BiAlert>
    <div class="d-flex justify-content-end" v-if="showLoadMore">
        <BiButton is-outlined color="primary" @click="loadMore()">
            {{ t(`${COMMON_MODULE_ID}.general.loadMore`) }}
        </BiButton>
    </div>
</template>
