<script setup lang="ts">
import { computed, onBeforeUnmount, onMounted, ref, useSlots, watch } from "vue";
import dayjs, { type Dayjs } from "dayjs";
import utc from "dayjs/plugin/utc";
import customParseFormat from "dayjs/plugin/customParseFormat";
import { debounce, isNull } from "lodash";
import { getUUID } from "@abaco/bootstrap-italia-components/src/utilities/index";
import { useFormField } from "../hooks/useFormField";

dayjs.extend(utc);
dayjs.extend(customParseFormat);

const emit = defineEmits<{
    (e: "update:model-value", value?: Date | string | number | null): void;
    (e: "validate", value: string): void;
}>();

const props = withDefaults(
    defineProps<{
        /**
         * Id that identifies the checkbox
         */
        id?: string;
        /**
         * Value assumed by the date picker
         */
        modelValue?: Date | string | number | null;
        /**
         * date format
         */
        format?: string;
        /**
         * If this property is true then the date picker will not be usable
         */
        isDisabled?: boolean;
        /**
         * If this property is true then the date picker will  be read only
         */
        isReadonly?: boolean;
        /**
         * If picker is required.
         * Remove from firefox and other browser's the clear button
         */
        isRequired?: boolean;
        /**
         * This property will display a description below the Date picker.
         * It will also be associated with the
         * ```HTML
         * aria-describedby
         * ```
         * attribute of the input field
         */
        info?: string;
        /**
         * Date picker label
         */
        label?: string;
        /**
         * Name of the Date Picker input
         */
        name?: string;
        /**
         * EXTENSION of native max (that is unreliable)
         */
        max?: Date | string | number;
        /**
         * EXTENSION of native min (that is unreliable)
         */
        min?: Date | string | number;
        /**
         * Default date in case of invalid date
         */
        defaultDate?: Date | string | number;
        /**
         * Validation functions
         * returning false will revert changes
         */
        validate?: (val: Date) => boolean;
        /**
         * List of custom CSS classes to add to the card
         */
        extraClasses?: string[];
        /**
         * Function used to validate the data
         */
        validatorFn?: (id: string) => Promise<boolean>;
        /**
         * return date in UTC
         * @default true
         */
        useUtc?: boolean;
        /**
         * use debounce time on change value
         * @default 500
         */
        debounceTime?: number;
        /**
         * set custom valididy message
         * @default "Invalid Date"
         */
        customValidityMessage?: string;
        /**
         * Validation class (is-invalid only)
         */
        validationInvalidClassname?: string;
        /**
         * Validation class (is-valid only)
         */
        validationValidClassname?: string;
        /**
         *  Validation error list
         */
        errors?: string[];
        /**
         *  Validation valid list
         */
        valids?: string[];
        /**
         * Hides label
         *
         * This property adds this class
         * ```CSS
         * .visually-hidden
         * ```
         */
        isHidden?: boolean;
        validateOnChange?: boolean;
    }>(),
    {
        id: () => getUUID(),
        format: "YYYY-MM-DD",
        isDisabled: false,
        isReadonly: false,
        isRequired: false,
        validationInvalidClassname: "is-invalid",
        validationValidClassname: "is-valid",
        errors: () => [],
        valids: () => [],
        useUtc: true,
        debounceTime: 500,
        customValidityMessage: "Invalid Date",
        validateOnChange: true,
    },
);

/**
 * Form field toolbox
 */
const { isValid, helpId, onBlur, hasLabel } = useFormField(props, emit);

/**
 * HTML element
 */
const inputRef = ref<HTMLInputElement | null>(null);

const slots = useSlots();
const hasLabelInSlots = computed(() => !!(slots && slots.label && slots.label()) || !!hasLabel.value);

/**
 * Bootstrap instance
 */
// eslint-disable-next-line @typescript-eslint/no-explicit-any
const inputBoostrapInstance = ref<any>();

/**
 * Create
 */
onMounted(() => {
    if (inputRef.value) inputBoostrapInstance.value = window.bootstrap.Input.getOrCreateInstance(inputRef.value);
});

/**
 * Destroy
 */
onBeforeUnmount(() => {
    if (inputBoostrapInstance.value instanceof window.bootstrap.Input) inputBoostrapInstance.value.dispose();
});

/**
 * Format from generic data to Dayjs object, to better manage dates
 * remove TIME to prevent logical errors, since input type=Date picks only DATE
 *
 * @param value
 */
const formatFromUserToDayjs = (value?: Date | string | number): Dayjs | undefined => {
    if (!value) return;
    let dayJsObject: Dayjs | undefined;
    switch (typeof value !== "undefined" && !isNull(value) ? typeof value : "string") {
        case "number":
            // timestamp to string
            dayJsObject = props.useUtc ? dayjs.utc(value) : dayjs(value);
            break;
        case "string":
            // transforms every format string into standard string
            dayJsObject = props.useUtc ? dayjs.utc(value, props.format) : dayjs(value, props.format);
            break;
        case "object":
            dayJsObject = props.useUtc ? dayjs.utc((value as Date).getTime()) : dayjs((value as Date).getTime());
            break;
    }
    if (!dayJsObject) return;
    // remove TIME
    return dayJsObject.set("hour", 0).set("minute", 0).set("second", 0).set("milliseconds", 0);
};

/**
 * Translate generic value to one accepted by input date (string formatted with YYYY-MM-DD)
 *
 * @param value
 */
const formatFromUserToElement = (value?: Date | string | number | null): string | undefined => {
    const dayJsObject = formatFromUserToDayjs(value ?? undefined);
    if (dayJsObject && dayJsObject.isValid()) return dayJsObject.format("YYYY-MM-DD").toString();
};

/**
 * Translate Dayjs value to whatever type was the one inserted by the user
 */
const formatFromElementToUser = (value?: Dayjs) => {
    if (!value) return;
    switch (typeof props.modelValue !== "undefined" ? typeof props.modelValue : "string") {
        case "number":
            return value.valueOf();
        case "string":
            return value.format(props.format).toString();
        case "object":
            return value.toDate();
    }
};

/**
 * defaultDate can be generic type but, if used, it must return the same type as the user input (modelValue)
 * So it needs a double conversion
 *
 * If invalid: return false and can't be used
 */
const translatedDefaultDate = computed(() => {
    const defaultDateDayjs = formatFromUserToDayjs(props.defaultDate);
    return checkValueIfInvalid(defaultDateDayjs) ? false : formatFromElementToUser(defaultDateDayjs);
});

/**
 * Clear input
 * If required it is resetted to a previous valid date
 *
 * @param ui - if we want to activate the invalid UI markup
 */
function resetValue(ui = false) {
    if (ui) {
        inputRef.value?.setCustomValidity(props.customValidityMessage);
        inputRef.value?.classList.add("is-invalid");
    }
    if (translatedDefaultDate.value) {
        // if valid default date is inserted
        emit("update:model-value", translatedDefaultDate.value);
    } else if (!props.isRequired) {
        // if not required
        emit("update:model-value", "");
        if (inputRef.value) inputRef.value.value = "";
    } else {
        // if required and no valid default date: previous valid date
        if (inputRef.value) inputRef.value.value = formatFromUserToElement(props.modelValue) || "";
        emit("update:model-value", props.modelValue);
    }
}

/**
 * Check if data is valid
 * true = valid
 *
 * @param value
 * @return boolean
 */
function checkValueIfInvalid(value?: Dayjs) {
    return (
        !value ||
        !value.isValid() ||
        (props.validate && !props.validate(value.toDate())) ||
        (props.max && value.isAfter(formatFromUserToDayjs(props.max))) ||
        (props.min && value.isBefore(formatFromUserToDayjs(props.min)))
    );
}

/**
 * input type="date" return a string with format YYYY-MM-DD,
 * and I want return the result with the same format as the user input
 *
 * @param value
 */
const changeInputFromElement = debounce(function (value: string) {
    const dateParsed = formatFromUserToDayjs(value);
    // if has an error than not reset class
    if (!props.errors.length) {
        // RESET UI VALIDATION
        inputRef.value?.classList.remove("is-invalid");
        inputRef.value?.setCustomValidity("");
    }
    // INVALID
    if (checkValueIfInvalid(dateParsed)) {
        resetValue(props.isRequired);
        return;
    }
    // VALID
    emit("update:model-value", formatFromElementToUser(dateParsed));
}, props.debounceTime);

/**
 *
 * @param target
 */
function handlerChange({ target }: Event) {
    props.validateOnChange && changeInputFromElement((target as HTMLInputElement).value);
}

/**
 *
 * @param target
 */
function handlerBlur({ target }: Event) {
    changeInputFromElement((target as HTMLInputElement).value);
    onBlur();
}

/**
 * Change modelValue to a correct format
 */
watch(
    [() => props.modelValue, inputRef],
    function ([value]) {
        if (!inputRef.value) return;
        // If an invalid value is set from an external command, check and eventually reset:
        if (checkValueIfInvalid(formatFromUserToDayjs(value ?? undefined))) {
            resetValue(props.isRequired);
            return;
        }
        inputRef.value.value = formatFromUserToElement(value) || "";
    },
    { immediate: true },
);
</script>

<template>
    <div
        class="form-group input-container"
        :class="{
            'has-label': hasLabelInSlots && !isHidden,
        }"
    >
        <label v-show="hasLabelInSlots" class="active" :for="id">
            <slot name="label">
                <span :class="{ 'visually-hidden': isHidden }"> {{ label }}</span>
            </slot>
        </label>
        <input
            ref="inputRef"
            type="date"
            :id="id"
            :name="name"
            :disabled="isDisabled"
            :readonly="isReadonly"
            :required="isRequired"
            :aria-describedby="info ? helpId : undefined"
            class="form-control"
            :class="{
                [validationInvalidClassname]: !!props.errors.length,
                [validationValidClassname]: !!props.valids.length,
                extraClasses,
            }"
            @blur="handlerBlur"
            @change="handlerChange"
            :max="formatFromUserToElement(max)"
            :min="formatFromUserToElement(min)"
        />
        <small v-if="info && isValid" :id="helpId" class="form-text text-muted">
            {{ info }}
        </small>
        <!-- validation errors -->
        <slot name="errors" v-bind="{ errors }">
            <div v-for="error in errors" :key="error" class="invalid-feedback">
                {{ error }}
            </div>
        </slot>
        <slot name="valids" v-bind="{ valids }">
            <div v-for="valid in valids" :key="valid" class="valid-feedback">
                {{ valid }}
            </div>
        </slot>
    </div>
</template>

<style scoped lang="scss">
.input-container {
    margin-bottom: 0;
    // not working on firefox, need to put "required" the input
    input[type="date"] {
        &:required {
            &::-ms-clear,
            &::-webkit-clear-button {
                display: none;
                appearance: none;
            }
        }
    }
    &.has-label {
        margin-top: 1.2em;
    }
}
</style>
