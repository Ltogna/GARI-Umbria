<script setup lang="ts">
import BiCheckbox from "@abaco/bootstrap-italia-components/src/components/form/BiCheckbox.vue";
import { getUUID } from "@abaco/bootstrap-italia-components/src/utilities";

import { ref, watch, computed } from "vue";
import { useTags } from "@/hooks/useTags";
import type { TagResponse } from "@/models/tag/TagSearchResponseSchema";
import { useRegistryStore } from "@/stores/registry";
import usePermissions from "@/hooks/usePermissions";

const props = defineProps<{
    modelValue?: string[];
    validatorFn?: (id: string) => Promise<boolean>;
}>();

const emit = defineEmits<{
    (e: "update:modelValue", value: string[]): void;
}>();

const selectedTags = ref<TagResponse[]>([]);
const { tagList, tags } = useTags();
const registryStore = useRegistryStore();
const { canWrite } = usePermissions();

const isReadonly = computed(() => registryStore.currentDetail?.archived || !canWrite);

watch(
    () => props.modelValue,
    (value) => {
        value && (selectedTags.value = value.map((it) => tags.value[it]));
    },
);

function onInput(event: Event, elem: TagResponse) {
    if ((event.target as HTMLInputElement).checked) {
        selectedTags.value.push(elem);
    } else {
        selectedTags.value = selectedTags.value.filter((item) => item.id !== elem.id);
    }
    emit(
        "update:modelValue",
        selectedTags.value.map((it) => it.code),
    );
}
</script>
<template>
    <div>
        <BiCheckbox
            v-for="tag in tagList"
            :key="tag.id"
            :id="getUUID()"
            :label="tag.i18nCode ? tag.i18nCode : tag.code"
            :extraClasses="['form-check-inline']"
            :modelValue="selectedTags.includes(tag)"
            @input="onInput($event, tag)"
            :validatorFn="validatorFn"
            :is-disabled="isReadonly && !canWrite"
        />
    </div>
</template>
