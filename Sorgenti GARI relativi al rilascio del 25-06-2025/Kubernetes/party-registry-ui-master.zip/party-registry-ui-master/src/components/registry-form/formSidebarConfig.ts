import type { DocTypeResponse } from "patri-common-ui/src";
import type { RouteLocationNamedRaw } from "vue-router";
import { MODULE_ID, SIDEBAR_OTHERS_GROUP_CODE } from "../../constants";
import { RouteName } from "@/routes";

export interface AccordionSidebarItem {
    path: string;
    text: string;
}

export interface AccordionSidebarConfig {
    [headerCode: string]: {
        headerText: string;
        items: AccordionSidebarItem[];
    };
}

export const getFormSidebarConfig = (
    t: (key: string) => string,
    regId: number | null = null,
    docTypes?: DocTypeResponse[],
): AccordionSidebarConfig => {
    let config = {
        registry: {
            headerText: t(`${MODULE_ID}.registry.sidebar.registry`),
            items: [
                {
                    path: regId ? `/edit/${regId}/form` : `/new/form`,
                    text: t(`${MODULE_ID}.registry.sidebar.registryData`),
                },
            ],
        },
    };

    if (docTypes && regId) {
        config = {
            ...config,
            ...docTypes.reduce((acc, item) => {
                item.docGroup &&
                    (acc[item.docGroup] = {
                        headerText: item.i18nDocGroup ?? "-",
                        items: createAccordionSidebarItem(acc[item.docGroup]?.items, item, regId),
                    });
                !item.docGroup &&
                    (acc[SIDEBAR_OTHERS_GROUP_CODE] = {
                        headerText: "",
                        items: createAccordionSidebarItem(acc[SIDEBAR_OTHERS_GROUP_CODE]?.items, item, regId),
                    });
                return acc;
            }, {} as AccordionSidebarConfig),
        };
    }

    return config;
};

function createAccordionSidebarItem(
    itemList: AccordionSidebarItem[] | undefined,
    item: DocTypeResponse,
    regId: number,
) {
    if (itemList) {
        return [
            ...itemList,
            {
                path: `/edit/${regId}/doc/${item.docType}`,
                text: item.i18nDocType ?? "-",
            },
        ];
    }

    return [
        {
            path: `/edit/${regId}/doc/${item.docType}`,
            text: item.i18nDocType ?? "-",
        },
    ];
}

export const getRouteConfig = (
    regId: number | null = null,
    docTypes?: DocTypeResponse[],
): Record<string, RouteLocationNamedRaw> => {
    let config: Record<string, RouteLocationNamedRaw> = {
        "/new/form": {
            name: RouteName.PARTY_NEW_FORM,
        },
        [`/edit/${regId}/form`]: {
            name: RouteName.PARTY_EDIT_FORM,
            params: { regId },
        },
    };

    if (docTypes) {
        docTypes.forEach((docType) => {
            config = {
                ...config,
                [`/edit/${regId}/doc/${docType.docType}`]: {
                    name: RouteName.PARTY_DOC_TYPE,
                    params: { regId, docType: docType.docType },
                },
            };
        });
    }

    return config;
};
