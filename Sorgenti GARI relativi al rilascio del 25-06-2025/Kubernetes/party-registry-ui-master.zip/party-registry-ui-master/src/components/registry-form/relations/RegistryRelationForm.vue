<script setup lang="ts">
import { computed, onMounted, ref, watch } from "vue";
import type { RegistryRelation } from "@/models/relation/RelationRequest";
import { getUUID } from "@abaco/bootstrap-italia-components/src/utilities";
import BiButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiButton.vue";
import { i18n, BiTextInput, dateUtils } from "patri-common-ui/src";
import { ModalModeEnum } from "patri-common-ui/src";
import { useForm } from "patri-common-ui/src";
import createRelationFormValidatorConfig from "./relationFormValidatorConfig";
import BiDatepicker from "../../BiDatepicker.vue";
import { MODULE_ID } from "@/constants";
import { MODULE_ID as COMMON_MODULE_ID } from "patri-common-ui/src/constants";
import type { GenericSearchResponse } from "@/models/LegalStatus";
import type { RegistryRelationType } from "@/models/relation/RelationTypeRequest";

const props = defineProps<{
    modelValue: RegistryRelation;
    modalMode: ModalModeEnum;
    roleTypes: { id: string; text: string }[];
    selectedRelationType: RegistryRelationType;
}>();

const { t } = i18n.global;
const formId = getUUID();
const relationFormRef = ref();
const relationForm = ref<Partial<RegistryRelation>>({});
const { validate, onValidate, onSubmit } = useForm<Partial<RegistryRelation>>(
    onSubmitCallback,
    relationForm.value,
    formId,
);

const dtStart = ref<Date>();
const dtEnd = ref<Date>();
const roleTypeList = ref<GenericSearchResponse[]>([]);
const searchRoleText = ref("");

onMounted(() => {
    if (props.modalMode !== ModalModeEnum.DELETE) {
        validate.value = createRelationFormValidatorConfig(t, relationFormRef.value, relationForm);
    }
    if (props.modelValue.relatedRoleCode) {
        relationForm.value.relatedRoleCode = props.modelValue.relatedRoleCode;
        searchRoleText.value = props.modelValue.relationRoleI18nCode;
    }
    roleTypeList.value = props.roleTypes.map((o) => {
        return {
            code: o.id,
            i18nCode: o.text ?? "",
        };
    });
});

const emit = defineEmits<{
    (e: "close-relation"): void;
    (e: "save-relation", relation: RegistryRelation): void;
}>();

watch([dtStart, dtEnd], ([dtStart, dtEnd]) => {
    relationForm.value.dtStart = dtStart ? dateUtils.getNormalizedDate(dtStart) : undefined;
    relationForm.value.dtEnd = dtEnd ? dateUtils.getNormalizedDate(dtEnd) : undefined;
});

watch(
    () => props.modelValue,
    (value) => {
        relationForm.value = Object.assign({ ...props.modelValue });
        value?.dtStart &&
            value?.dtStart !== dateUtils.INFINITE_DATE &&
            (dtStart.value = new Date(dateUtils.getStringDate(value.dtStart)));
        value?.dtEnd &&
            value?.dtEnd !== dateUtils.INFINITE_DATE &&
            (dtEnd.value = new Date(dateUtils.getStringDate(value.dtEnd)));
    },
    { immediate: true },
);

function onCloseRelation() {
    emit("close-relation");
}

function onSubmitCallback() {
    emit("save-relation", relationForm.value as RegistryRelation);
}

const modalConfirmButton = computed(() => {
    if (props.modalMode == ModalModeEnum.DELETE) return "danger";
    else return "success";
});
</script>
<template>
    <form :id="formId" class="needs-validation" @submit.prevent="onSubmit" ref="relationFormRef">
        <div v-if="modalMode !== ModalModeEnum.DELETE">
            <div class="row">
                <div class="form-group" :class="relationForm.firstName ? 'col-md-6' : 'col-md-12'">
                    <BiTextInput
                        :id="getUUID()"
                        :label="
                            relationForm.firstName
                                ? t(`${MODULE_ID}.registry.form.fields.relation.lastName`)
                                : t(`${MODULE_ID}.registry.form.fields.relation.denomination`)
                        "
                        name="lastName"
                        :validator-fn="onValidate"
                        v-model="relationForm.lastName"
                        :is-readonly="true"
                    ></BiTextInput>
                </div>
                <div class="form-group col-md-6" v-if="relationForm.firstName">
                    <BiTextInput
                        :id="getUUID()"
                        :label="t(`${MODULE_ID}.registry.form.fields.relation.firstName`)"
                        name="firstName"
                        :validator-fn="onValidate"
                        v-model="relationForm.firstName"
                        :is-readonly="true"
                    ></BiTextInput>
                </div>
            </div>
            <div class="row">
                <div class="form-group col-md-12 mb-5">
                    <BiTextInput
                        :id="getUUID()"
                        :label="t(`${MODULE_ID}.registry.form.fields.relation.role`)"
                        :items="roleTypeList"
                        name="roleType"
                        :validator-fn="onValidate"
                        v-model="relationForm.relatedRoleCode"
                        item-title="i18nCode"
                        item-value="code"
                        v-model:text="searchRoleText"
                        :seamless="true"
                        :strict="true"
                        list-height="400px"
                    />
                </div>
            </div>
            <div class="row">
                <div class="form-group col-md-6">
                    <!-- #134560 21/03/24 added max date -->
                    <BiDatepicker
                        :id="getUUID()"
                        name="dtStart"
                        :validate-on-change="false"
                        :debounce-time="0"
                        :label="t(`${MODULE_ID}.registry.form.fields.relation.from`)"
                        :validatorFn="onValidate"
                        :max="dtEnd"
                        v-model="dtStart"
                    />
                </div>
                <!-- #134560 21/03/24 added min date -->
                <div class="form-group col-md-6">
                    <BiDatepicker
                        :id="getUUID()"
                        name="dtEnd"
                        :validate-on-change="false"
                        :debounce-time="0"
                        :label="t(`${MODULE_ID}.registry.form.fields.relation.to`)"
                        :validatorFn="onValidate"
                        :min="dtStart"
                        v-model="dtEnd"
                    />
                </div>
            </div>
        </div>
        <div class="d-flex justify-content-center">
            <BiButton color="primary" is-outlined @click="onCloseRelation" class="btn-me">
                {{ t(`${COMMON_MODULE_ID}.general.cancel`) }}
            </BiButton>
            <BiButton type="submit" :color="modalConfirmButton">
                {{ t(`${MODULE_ID}.registry.form.fields.relation.modalModeEnum.` + modalMode + ".confirm") }}
            </BiButton>
        </div>
    </form>
</template>
