<script setup lang="ts">
import { computed } from "vue";
import { i18n } from "patri-common-ui/src";
import type { RegistryRelationType } from "@/models/relation/RelationTypeRequest";
import BiButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiButton.vue";
import BiTable from "@abaco/bootstrap-italia-components/src/components/BiTable/BiTable.vue";
import BiIcon from "@abaco/bootstrap-italia-components/src/components/BiIcon/BiIcon.vue";
import { MODULE_ID } from "@/constants";
import { MODULE_ID as COMMON_MODULE_ID } from "patri-common-ui/src/constants";
import useColors from "@abaco/bootstrap-italia-components/src/composables/useColors";
import { useRegistryStore } from "@/stores/registry";
import usePermissions from "@/hooks/usePermissions";

withDefaults(
    defineProps<{
        relationTypeList: RegistryRelationType[];
        showLoadMore?: boolean;
    }>(),
    { showLoadMore: false },
);

const { t } = i18n.global;
const registryStore = useRegistryStore();

const { getColor } = useColors();

const emit = defineEmits<{
    (e: "edit-relation-type", value: RegistryRelationType): void;
    (e: "delete-relation-type", value: RegistryRelationType): void;
    (e: "load-more"): void;
}>();

const { canWrite } = usePermissions();
const isReadonly = computed(() => registryStore.currentDetail?.archived || !canWrite);

const onEditRelationType = (elem: RegistryRelationType) => {
    emit("edit-relation-type", elem);
};

const onDeleteRelationType = (elem: RegistryRelationType) => {
    emit("delete-relation-type", elem);
};

function loadMore() {
    emit("load-more");
}
</script>
<template>
    <BiTable class="table mb-0" extraTableClasses="table-head-bg" is-row-hover isResponsive>
        <template #head>
            <tr class="bg-light" :class="getColor('text', 'secondary')">
                <th scope="col">{{ t(`${MODULE_ID}.registry.form.fields.relationType.typology`) }}</th>
                <th scope="col">{{ t(`${MODULE_ID}.registry.form.fields.relationType.description`) }}</th>
                <th scope="col"></th>
            </tr>
        </template>
        <template #body>
            <tr v-for="(item, i) in relationTypeList" :key="i">
                <td :data-label="t(`${MODULE_ID}.registry.form.fields.relationType.typology`)">
                    {{ item.relationTypeI18nCode }}
                </td>
                <td :data-label="t(`${MODULE_ID}.registry.form.fields.relationType.description`)">
                    {{ item.note }}
                </td>
                <td class="text-end">
                    <BiButton
                        :title="t(`${COMMON_MODULE_ID}.general.edit`)"
                        size="xs"
                        :color="!isReadonly ? 'success' : 'primary'"
                        is-outlined
                        is-icon
                        :width="40"
                        :height="38"
                        class="btn-me"
                        @click="onEditRelationType(item)"
                    >
                        <BiIcon :icon="isReadonly ? 'eye' : 'pencil'"></BiIcon>
                    </BiButton>
                    <BiButton
                        v-if="!isReadonly"
                        :title="t(`${COMMON_MODULE_ID}.general.delete`)"
                        size="xs"
                        color="danger"
                        is-outlined
                        is-icon
                        :width="40"
                        :height="38"
                        @click="onDeleteRelationType(item)"
                    >
                        <BiIcon icon="trash-can"></BiIcon>
                    </BiButton>
                </td>
            </tr>
        </template>
    </BiTable>
    <div class="d-flex justify-content-end mb-4" v-if="showLoadMore">
        <BiButton :is-outlined="true" color="primary" @click="loadMore()">
            {{ t(`${COMMON_MODULE_ID}.general.loadMore`) }}
        </BiButton>
    </div>
</template>
