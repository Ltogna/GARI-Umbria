<script setup lang="ts">
import { computed, onMounted, reactive, ref, toRaw, watch } from "vue";
import { useTags } from "@/hooks/useTags";
import { i18n, formUtils, useForm, BiTextInput } from "patri-common-ui/src";
import BiAutocompleteNext from "@abaco/bootstrap-italia-components/src/components/form/BiAutocompleteNext.vue";
import { ArchivedEnum, type RegistrySearchRequest } from "@/models/RegistrySearchRequest";
import BiNotification from "@abaco/bootstrap-italia-components/src/components/BiNotification/BiNotification.vue";
import BiButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiButton.vue";
import { getUUID } from "@abaco/bootstrap-italia-components/src/utilities";
import JustValidate from "just-validate";
import { MODULE_ID } from "@/constants";
import { MODULE_ID as COMMON_MODULE_ID } from "patri-common-ui/src/constants";

const emit = defineEmits<{
    (e: "search", value: Partial<RegistrySearchRequest>): void;
    (e: "cancel"): void;
}>();

const { justValidateConfig } = formUtils;
const { t } = i18n.global;

const formId = getUUID();
const searchForm = reactive<Partial<RegistrySearchRequest>>({
    archived: ArchivedEnum.not_archived,
});
const searchFormRef = ref();
const includeArchived = ref(false);

const { tagList } = useTags();
const { validate, isSubmitted, onSubmit, onReset } = useForm(submitCallback, searchForm, formId);

const atLeastOneField = computed(() => {
    return Object.keys(searchForm).some(
        (key) =>
            (key !== "archived" && (searchForm as { [s: string]: unknown })[key]) ||
            (Array.isArray((searchForm as { [s: string]: unknown })[key]) &&
                (searchForm as { [s: string]: unknown[] })[key].length),
    );
});

const tagSelectItems = computed(() =>
    tagList.value.map((it) => Object.assign({ key: it.code, value: it.i18nCode ?? it.code, i18: it.i18nCode }, {})),
);

watch(includeArchived, (value) => {
    searchForm.archived = value ? ArchivedEnum.all : ArchivedEnum.not_archived;
});

onMounted(() => {
    validate.value = new JustValidate(searchFormRef.value, justValidateConfig);
});

function submitCallback() {
    if (atLeastOneField.value) {
        const rawRegistryForm = toRaw(searchForm);
        emit("search", rawRegistryForm);
    }
}
function onCustomReset() {
    onReset();
    emit("cancel");
}
</script>

<template>
    <form
        :id="formId"
        class="party-registry-ui__registry-search-form needs-validation pt-5"
        ref="searchFormRef"
        @submit.prevent="onSubmit"
    >
        <div class="row">
            <div class="col-md-6 mb-4 align-self-end">
                <BiTextInput
                    :id="getUUID()"
                    :name="'taxOrVat'"
                    :label="t(`${MODULE_ID}.registry.search.taxOrVat`)"
                    :placeholder="t(`${MODULE_ID}.registry.search.inputPlaceholder`)"
                    v-model="searchForm.taxOrVat"
                />
            </div>
            <div class="col-md-6 form-tag custom-margin mb-4 align-self-end">
                <div class="registry-search-form__select form-group input-container has-label">
                    <!-- #134847  replaced BiSelect with Autocomplete -->
                    <BiAutocompleteNext
                        :id="getUUID()"
                        v-model="searchForm.tag"
                        :items="tagSelectItems"
                        :label="t(`${MODULE_ID}.registry.form.fields.tags.label`)"
                        :placeholder="t(`${MODULE_ID}.registry.form.fields.tags.placeholder`)"
                        itemTitle="value"
                        itemValue="key"
                        chipType="primary"
                        chipIconSize="sm"
                        multiple
                    />
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-6 mb-4 align-self-end">
                <BiTextInput
                    :id="getUUID()"
                    name="lastName"
                    :placeholder="t(`${MODULE_ID}.registry.search.inputPlaceholder`)"
                    :label="t(`${MODULE_ID}.registry.list.fields.lastName`)"
                    v-model="searchForm.lastName"
                />
            </div>
            <div class="col-md-6 mb-4 align-self-end">
                <BiTextInput
                    :id="getUUID()"
                    name="firstName"
                    :placeholder="t(`${MODULE_ID}.registry.search.inputPlaceholder`)"
                    :label="t(`${MODULE_ID}.registry.list.fields.firstName`)"
                    v-model="searchForm.firstName"
                />
            </div>
        </div>

        <div class="row">
            <div class="form-group col-md-12 text-center mt-4">
                <BiButton type="reset" @click="onCustomReset" is-outlined color="primary" class="btn-me">
                    {{ t(`${COMMON_MODULE_ID}.general.cancel`) }}
                </BiButton>
                <BiButton type="submit" color="success">
                    {{ t(`${COMMON_MODULE_ID}.general.search`) }}
                </BiButton>
            </div>
        </div>
    </form>
    <BiNotification
        :model-value="!atLeastOneField && isSubmitted"
        :title="t(`${COMMON_MODULE_ID}.general.warning`)"
        :variant="'error'"
        :text="t(`${MODULE_ID}.registry.search.errors.atLeastOneField`)"
        :icon="'circle-xmark'"
    />
</template>

<style lang="scss" scoped>
.party-registry-ui__registry-search-form {
    .registry-search-form__select {
        margin-top: 1.2em;
    }
}
</style>
