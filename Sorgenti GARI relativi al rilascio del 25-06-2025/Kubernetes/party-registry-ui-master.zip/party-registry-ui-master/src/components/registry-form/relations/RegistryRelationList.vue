<script setup lang="ts">
import { MODULE_ID } from "@/constants";
import usePermissions from "@/hooks/usePermissions";
import type { RegistryRelation } from "@/models/relation/RelationRequest";
import { RouteName } from "@/routes";
import { useRegistryStore } from "@/stores/registry";
import BiButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiButton.vue";
import BiIcon from "@abaco/bootstrap-italia-components/src/components/BiIcon/BiIcon.vue";
import BiTable from "@abaco/bootstrap-italia-components/src/components/BiTable/BiTable.vue";
import useColors from "@abaco/bootstrap-italia-components/src/composables/useColors";
import moment from "moment";
import { dateUtils, i18n } from "patri-common-ui/src";
import { MODULE_ID as COMMON_MODULE_ID } from "patri-common-ui/src/constants";
import { computed, inject, nextTick } from "vue";
import { useRouter } from "vue-router";

const router = useRouter();
const userDateFormat = inject<string>("userDateFormat");
const registryStore = useRegistryStore();
const { canWrite } = usePermissions();
const isReadonly = computed(() => registryStore.currentDetail?.archived || !canWrite);

withDefaults(
    defineProps<{
        // #135589 added regId
        regId: number;
        relationList: RegistryRelation[];
        showLoadMore?: boolean;
    }>(),
    { showLoadMore: false },
);

const { t } = i18n.global;

const emit = defineEmits<{
    (e: "edit-relation", value: RegistryRelation): void;
    (e: "delete-relation", value: RegistryRelation): void;
    (e: "load-more"): void;
    (e: "reload"): void;
}>();

const { getColor } = useColors();

const onEditRelation = (elem: RegistryRelation) => {
    emit("edit-relation", elem);
};

const onDeleteRelation = (elem: RegistryRelation) => {
    emit("delete-relation", elem);
};

/**
 * #134529 22/03/24
 *
 * Fo to next party
 */
const goToRelation = (elem: RegistryRelation) => {
    nextTick(() => {
        router.push({
            name: RouteName.PARTY_EDIT_FORM,
            params: { regId: elem.relatedPartyId },
            query: { backUrl: "" },
        });
        emit("reload");
    });
};

function formatDate(value: string) {
    return moment(value).format("DD/MM/YYYY");
}

function loadMore() {
    emit("load-more");
}
</script>
<template>
    <BiTable class="table mb-0" extraTableClasses="table-head-bg" is-row-hover isResponsive>
        <template #head>
            <tr class="bg-light" :class="getColor('text', 'secondary')">
                <!-- #134529 added taxCode -->
                <th scope="col">{{ t(`${MODULE_ID}.registry.list.fields.taxCode`) }}</th>
                <th scope="col">{{ t(`${MODULE_ID}.registry.form.fields.relation.denomination`) }}</th>
                <!-- #134529 added birthDate -->
                <th scope="col">{{ t(`${MODULE_ID}.registry.list.fields.birthDate`) }}</th>
                <th scope="col">{{ t(`${MODULE_ID}.registry.form.fields.relation.role`) }}</th>
                <th scope="col">{{ t(`${MODULE_ID}.registry.form.fields.relation.from`) }}</th>
                <th scope="col">{{ t(`${MODULE_ID}.registry.form.fields.relation.to`) }}</th>
                <th scope="col"></th>
            </tr>
        </template>
        <template #body>
            <tr v-for="(item, i) in relationList" :key="i">
                <!-- #134529 added taxCode -->
                <td :data-label="t(`${MODULE_ID}.registry.list.fields.taxCode`)">
                    {{ item.taxCode }}
                </td>
                <td :data-label="t(`${MODULE_ID}.registry.form.fields.relation.denomination`)">
                    {{ item.lastName }}
                    <span v-if="item.firstName"> &nbsp;{{ item.firstName }} </span>
                </td>
                <!-- #134529 added birthDate -->
                <td :data-label="t(`${MODULE_ID}.registry.form.fields.relation.birthDate`)">
                    {{ item.birthDate ? moment(item.birthDate).format(userDateFormat?.toUpperCase()) : "" }}
                </td>
                <td :data-label="t(`${MODULE_ID}.registry.form.fields.relation.role`)">
                    {{ item.relationRoleI18nCode }}
                </td>
                <td :data-label="t(`${MODULE_ID}.registry.form.fields.relation.from`)">
                    {{ formatDate(item.dtStart) }}
                </td>
                <td :data-label="t(`${MODULE_ID}.registry.form.fields.relation.to`)">
                    <span v-if="item.dtEnd && item.dtEnd !== dateUtils.INFINITE_DATE">
                        {{ formatDate(item.dtEnd) }}
                    </span>
                </td>
                <td class="td-actions">
                    <!-- #135588 alignment buttons actions -->
                    <div class="actions d-flex g-2">
                        <BiButton
                            v-if="!isReadonly"
                            :title="t(`${COMMON_MODULE_ID}.general.edit`)"
                            size="xs"
                            color="success"
                            is-outlined
                            is-icon
                            :width="40"
                            :height="38"
                            @click="onEditRelation(item)"
                        >
                            <BiIcon icon="pencil"></BiIcon>
                        </BiButton>
                        <BiButton
                            v-if="!isReadonly"
                            :title="t(`${COMMON_MODULE_ID}.general.delete`)"
                            size="xs"
                            color="danger"
                            is-outlined
                            is-icon
                            :width="40"
                            :height="38"
                            @click="onDeleteRelation(item)"
                        >
                            <BiIcon icon="trash-can"></BiIcon>
                        </BiButton>
                        <!-- #135589 removed button if is same partyId -->
                        <BiButton
                            v-if="item.relatedPartyId !== regId"
                            :title="t(`${MODULE_ID}.registry.form.fields.relation.gotoRelation`)"
                            size="xs"
                            color="primary"
                            is-outlined
                            is-icon
                            :is-disabled="!item.hasMandates"
                            :width="40"
                            :height="38"
                            @click="goToRelation(item)"
                        >
                            <BiIcon icon="arrow-right"></BiIcon>
                        </BiButton>
                    </div>
                </td>
            </tr>
        </template>
    </BiTable>
    <div class="d-flex justify-content-end mb-4" v-if="showLoadMore">
        <BiButton :is-outlined="true" color="primary" @click="loadMore()">
            {{ t(`${COMMON_MODULE_ID}.general.loadMore`) }}
        </BiButton>
    </div>
</template>

<style lang="scss" scoped>
// #135588 alignment buttons actions
.td-actions {
    vertical-align: middle;
}
// #135588 alignment buttons actions
.actions {
    gap: var(--bs-gutter-x, 0) var(--bs-gutter-y, 0);
}
</style>
