<script setup lang="ts">
import { computed, onMounted, ref } from "vue";
import type { RegistryRelation } from "@/models/relation/RelationRequest";
import type { RegistryRelationType } from "@/models/relation/RelationTypeRequest";
import { getUUID } from "@abaco/bootstrap-italia-components/src/utilities";
import BiSelect from "@abaco/bootstrap-italia-components/src/components/form/BiSelect.vue";
import BiButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiButton.vue";
import { i18n } from "patri-common-ui/src";
import { ModalModeEnum } from "patri-common-ui/src";
import { useForm } from "patri-common-ui/src";
import createRelationFormValidatorConfig from "./relationTypeFormValidatorConfig";
import BiTextarea from "@abaco/bootstrap-italia-components/src/components/form/BiTextarea.vue";
import RegistryRelationList from "./RegistryRelationList.vue";
import { MODULE_ID } from "@/constants";
import { MODULE_ID as COMMON_MODULE_ID } from "patri-common-ui/src/constants";
import usePermissions from "@/hooks/usePermissions";
import { useRegistryStore } from "@/stores/registry";

const props = withDefaults(
    defineProps<{
        // #135589 added regId
        regId: number;
        modelValue: RegistryRelationType;
        modalMode: ModalModeEnum;
        relationTypes: { id: string; text: string }[];
        relationsList: RegistryRelation[];
        showLoadMore?: boolean;
        roleTypes?: { key: string; value: string }[];
    }>(),
    { showLoadMore: false },
);

const { t } = i18n.global;
const formId = getUUID();
const relationFormRef = ref();
const registryStore = useRegistryStore();
const { canWrite } = usePermissions();
const isReadonly = computed(() => registryStore.currentDetail?.archived || !canWrite);
const relationTypeId = computed(() => props.relationTypes[0].id);
const relationForm = ref<Partial<RegistryRelationType>>({
    relationTypeCode: relationTypeId.value,
} as RegistryRelationType);
const { validate, onValidate, onSubmit } = useForm<Partial<RegistryRelationType>>(
    submitCallback,
    relationForm.value,
    formId,
);

onMounted(() => {
    if (props.modalMode !== ModalModeEnum.DELETE)
        validate.value = createRelationFormValidatorConfig(t, relationFormRef.value);
    relationForm.value = Object.assign(
        { relationTypeCode: props.relationTypes[0].id } as RegistryRelationType,
        props.modelValue,
    );
});

const emit = defineEmits<{
    (e: "close-modal"): void;
    (e: "save-relation-type", relation: RegistryRelationType): void;
    (e: "delete-relation", value: RegistryRelation): void;
    (e: "edit-relation", value: RegistryRelation): void;
    (e: "search-relation"): void;
    (e: "load-more"): void;
    (e: "reload"): void;
}>();

function onCloseModal() {
    emit("close-modal");
}

function submitCallback() {
    emit("save-relation-type", relationForm.value as RegistryRelationType);
}

async function onEditRelation(value: RegistryRelation) {
    emit("edit-relation", value);
}

function onDeleteRelation(value: RegistryRelation) {
    emit("delete-relation", value);
}

function onSearchRelation() {
    emit("search-relation");
}

function loadMore() {
    emit("load-more");
}

const modalConfirmButton = computed(() => {
    if (props.modalMode == ModalModeEnum.DELETE) return "danger";
    else return "success";
});
</script>
<template>
    <form :id="formId" class="needs-validation" @submit.prevent="onSubmit" ref="relationFormRef">
        <div class="row" v-if="modalMode !== ModalModeEnum.DELETE">
            <div class="form-group col-md-12">
                <!-- #136072 fixed disabled select. Replaced `is-disabled` with `disabled` -->
                <BiSelect
                    :id="getUUID()"
                    :label="t(`${MODULE_ID}.registry.form.fields.relationType.typology`)"
                    :items="relationTypes"
                    name="relationType"
                    :validator-fn="onValidate"
                    v-model="relationForm.relationTypeCode"
                    :disabled="modalMode !== ModalModeEnum.NEW"
                ></BiSelect>
            </div>
            <div class="col-md-12">
                <BiTextarea
                    :errors="[]"
                    :label="t(`${MODULE_ID}.registry.form.fields.relationType.description`)"
                    v-model="relationForm.note"
                    :rows="3"
                    class="mb-4"
                    :is-disabled="isReadonly"
                >
                </BiTextarea>
            </div>
        </div>
        <!-- #135589 pass regId to RegistryRelationList -->
        <RegistryRelationList
            v-if="modalMode === ModalModeEnum.EDIT && relationsList.length"
            :relation-list="relationsList"
            :reg-id="regId"
            :show-load-more="!!showLoadMore"
            @load-more="loadMore"
            @edit-relation="onEditRelation"
            @delete-relation="onDeleteRelation"
            @reload="emit('reload')"
        ></RegistryRelationList>
        <div class="d-flex justify-content-center">
            <BiButton color="primary" is-outlined @click="onCloseModal()" class="btn-me">
                {{ t(`${COMMON_MODULE_ID}.general.cancel`) }}
            </BiButton>
            <BiButton
                :color="modalConfirmButton"
                v-if="modalMode === ModalModeEnum.EDIT && !isReadonly"
                @click="onSearchRelation"
                :is-disabled="!roleTypes?.length"
                class="btn-me"
            >
                {{ t(`${MODULE_ID}.registry.form.fields.relation.add`) }}
            </BiButton>
            <BiButton v-if="!isReadonly" type="submit" :color="modalConfirmButton">
                {{ t(`${MODULE_ID}.registry.form.fields.relationType.modalModeEnum.` + modalMode + ".confirm") }}
            </BiButton>
        </div>
    </form>
</template>
