import JustValidate from "just-validate";
import { formUtils } from "patri-common-ui/src";
import type { FieldRuleInterface } from "just-validate/dist/modules/interfaces";
import type { RegistryRelation } from "@/models/relation/RelationRequest";
import type { Ref } from "vue";
import { MODULE_ID as COMMON_MODULE_ID } from "patri-common-ui/src/constants";

const { justValidateConfig, getFieldSelector } = formUtils;

const createRelationFormValidatorConfig = (
    t: (s: string) => string,
    formRef: Element,
    form: Ref<Partial<RegistryRelation>>,
): JustValidate =>
    new JustValidate(formRef, justValidateConfig)
        .addField(getFieldSelector(formRef.id, "roleType"), [
            {
                validator: () => !!form.value?.relatedRoleCode,
                errorMessage: t(`${COMMON_MODULE_ID}.errors.fieldRequired`),
            } as FieldRuleInterface,
        ])
        .addField(getFieldSelector(formRef.id, "dtStart"), [
            {
                rule: "required",
                errorMessage: t(`${COMMON_MODULE_ID}.errors.fieldRequired`),
            } as FieldRuleInterface,
        ]);
export default createRelationFormValidatorConfig;
