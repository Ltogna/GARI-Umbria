<script setup lang="ts">
import { computed, inject, onMounted, ref, watch } from "vue";
import { i18n } from "patri-common-ui/src";
import BiButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiButton.vue";
import BiModal from "@abaco/bootstrap-italia-components/src/components/BiModal/BiModal.vue";
import { getUUID } from "@abaco/bootstrap-italia-components/src/utilities";
import { ModalModeEnum } from "patri-common-ui/src";
import type { RegistryRelation } from "@/models/relation/RelationRequest";
import type { RegistryRelationType } from "@/models/relation/RelationTypeRequest";
import RegistryRelationTypeForm from "@/components/registry-form/relations/RegistryRelationTypeForm.vue";
import RegistryRelationTypeList from "@/components/registry-form/relations/RegistryRelationTypeList.vue";
import { useApiResponseHandler, useApiDeleteHandler } from "@/index";
import type RelationApi from "@/api/relation-api";
import moment from "moment";
import RegistryRelationForm from "./RegistryRelationForm.vue";
import RegistryRelationSearchForm from "./RegistryRelationSearchForm.vue";
import RegistryRelationSearchList from "./RegistryRelationSearchList.vue";
import type { RegistrySearchRequest } from "@/models/RegistrySearchRequest";
import type RegistryApi from "@/api/registry-api";
import type { PartySearchResponse } from "@/models/PartySearchResponseSchema";
import type { RelationTypeRegistrySearchResponse } from "@/models/relation/RelationTypeSearchResponseSchema";
import { MODULE_ID } from "@/constants";
import { useRegistryStore } from "@/stores/registry";
import { useRelationPartyHistoryStore } from "@/stores/relationPartyHistory";
import usePermissions from "@/hooks/usePermissions";
import type { GenericSearchResponse } from "@/models/LegalStatus";

const { t } = i18n.global;
const registryStore = useRegistryStore();
const relationPartyHistoryStore = useRelationPartyHistoryStore();

const props = defineProps<{
    regId: number;
    validatorFn?: (id: string) => Promise<boolean>;
}>();

const emit = defineEmits<{
    reload: [];
    openAccordion: [boolean];
}>();

const showModal = ref(false);
const modalMode = ref(ModalModeEnum.NEW);
const selectedRelationType = ref({} as RegistryRelationType);
selectedRelationType.value = Object.assign({} as RegistryRelationType);
const registryApi: RegistryApi = inject("registryApi") as RegistryApi;
const relationApi: RelationApi = inject("relationApi") as RelationApi;
const relationTypeListNextKey = ref();
const registryRelationTypeList = ref<RegistryRelationType[]>([]);

/**
 * #134529 22/03/24
 *
 * Open modal with hashed url
 */
watch(
    [registryRelationTypeList, () => relationPartyHistoryStore.history.length],
    async ([registryRelationTypeList]) => {
        const last = relationPartyHistoryStore.getLast();
        if (last) {
            if (last.partyId === props.regId) {
                const value = registryRelationTypeList.find((d) => d.id === last.relationId);
                if (value) {
                    selectedRelationType.value = value;
                    await getRelationTypeRelations();
                    modalMode.value = ModalModeEnum.EDIT;
                    showModal.value = true;
                    emit("openAccordion", true);
                }
            }
        }
    },
    { immediate: true },
);

/**
 * #134529 22/03/24
 *
 * Close modal with hashed url
 */
watch(
    [showModal, modalMode],
    async ([showModal, modalMode]) => {
        if (!showModal && modalMode === ModalModeEnum.EDIT) {
            relationPartyHistoryStore.popLast();
        }
    },
    { immediate: true },
);

onMounted(() => {
    getRelationTypes();
    getRegistryRelationTypes();
});

const { canWrite } = usePermissions();
const isReadonly = computed(() => registryStore.currentDetail?.archived || !canWrite);

const relationTypes = ref<{ id: string; text: string }[]>([]);
const relationsList = ref<RegistryRelation[]>([]);
async function getRelationTypes() {
    const res = await useApiResponseHandler(() => relationApi.getRelationTypes());
    relationTypes.value =
        res?.records.map((el) => {
            return { id: el.code, text: el.i18nCode ? el.i18nCode : el.code };
        }) ?? [];
}

function closeModal() {
    showModal.value = false;
}

function newRelationType() {
    modalMode.value = ModalModeEnum.NEW;
    showModal.value = true;
    selectedRelationType.value = Object.assign({} as RegistryRelationType);
}

async function editRelationType(value: RegistryRelationType) {
    // #134529 25/03/24 add to pushState
    relationPartyHistoryStore.pushState({ partyId: value.partyId, relationId: value.id });
}

function removeRelationType(value: RegistryRelationType) {
    modalMode.value = ModalModeEnum.DELETE;
    selectedRelationType.value = value;
    showModal.value = true;
}

function saveRelationType(value: RegistryRelationType) {
    switch (modalMode.value) {
        case ModalModeEnum.EDIT:
            updateRelationType(value);
            break;
        case ModalModeEnum.DELETE:
            deleteRelationType(value);
            break;
        default:
            createRelationType(value);
    }
}

async function getRegistryRelationTypes() {
    const res = await useApiResponseHandler(() => relationApi.getRegistryRelationTypes(props.regId));
    if (res) {
        registryRelationTypeList.value = res.records as RegistryRelationType[];
        relationTypeListNextKey.value = res.nextKey;
    }
}

async function loadMoreRelationTypes() {
    const res = await useApiResponseHandler(() =>
        relationApi.getRegistryRelationTypes(props.regId, relationTypeListNextKey.value),
    );
    if (res) {
        registryRelationTypeList.value = {
            ...registryRelationTypeList.value,
            ...res.records.reduce(
                (acc, item) => {
                    acc[item.id] = item;
                    return acc;
                },
                {} as Record<string, RelationTypeRegistrySearchResponse>,
            ),
        };
        relationTypeListNextKey.value = res.nextKey;
    }
}

async function createRelationType(relation: Partial<RegistryRelationType>) {
    const res = await useApiResponseHandler(() => relationApi.createRegistryRelationType(props.regId, relation));
    if (res) {
        getRegistryRelationTypes();
        closeModal();
    }
}

async function updateRelationType(relation: Partial<RegistryRelationType>) {
    const res = await useApiResponseHandler(() => relationApi.updateRegistryRelationType(props.regId, relation));
    if (res) {
        getRegistryRelationTypes();
        closeModal();
    }
}

async function deleteRelationType(relation: Partial<RegistryRelationType>) {
    const res = await useApiDeleteHandler(() => relationApi.deleteRegistryRelationType(props.regId, relation));
    if (res) {
        getRegistryRelationTypes();
        closeModal();
    }
}

/***** Relations *****/
const selectedRelation = ref({} as RegistryRelation);
selectedRelation.value = Object.assign({} as RegistryRelation);
const showRelationForm = ref(false);
const showSearchForm = ref(false);
const registryList = ref();
const registryListNextKey = ref();
const relationListNextKey = ref();
let currentSearchForm: Partial<RegistrySearchRequest>;

const roleTypes = ref();
async function getRoleTypes(value: RegistryRelationType) {
    const list = [];
    let nextKey: string | undefined = undefined;
    do {
        const res = await useApiResponseHandler(() => relationApi.getRelationTypeRoles(value, nextKey));
        if (res) {
            nextKey = res.nextKey ?? undefined;
            list.push(
                ...res.records.map((el: GenericSearchResponse) => {
                    return { id: el.code, text: el.i18nCode ? el.i18nCode : el.code };
                }),
            );
        }
    } while (nextKey);
    roleTypes.value = list.sort((a, b) => {
        const textA = a.text ?? "";
        const textB = b.text ?? "";

        return textA.localeCompare(textB);
    });
}

async function getRelationTypeRelations() {
    const res = await useApiResponseHandler(() =>
        relationApi.getRelationTypeRelations(props.regId, selectedRelationType.value, relationListNextKey.value),
    );
    if (res) {
        relationsList.value = res.records as RegistryRelation[];
        relationListNextKey.value = res.nextKey;

        await getRoleTypes(selectedRelationType.value);
    }
}

async function loadMoreRelations() {
    const res = await useApiResponseHandler(() =>
        relationApi.getRelationTypeRelations(props.regId, selectedRelationType.value, relationListNextKey.value),
    );
    if (res) {
        relationsList.value = [...relationsList.value, ...(res.records as RegistryRelation[])];
        relationListNextKey.value = res.nextKey;
    }
}

async function getRelationDetail(value: RegistryRelation) {
    const res = await useApiResponseHandler(() => relationApi.getRegistryRelationTypeRelation(props.regId, value));
    if (res) {
        selectedRelation.value = res as RegistryRelation;
    }
}

function newRelation(value: PartySearchResponse) {
    registryList.value = null;
    selectedRelation.value.relatedPartyId = value.id;
    selectedRelation.value.partyRelationId = selectedRelationType.value.id;
    if (value.firstName) selectedRelation.value.firstName = value.firstName;
    selectedRelation.value.lastName = value.lastName;
    closeSearchRelation();
    modalMode.value = ModalModeEnum.NEW;
    showRelationForm.value = true;
}

async function editRelation(value: RegistryRelation) {
    await getRelationDetail(value);
    modalMode.value = ModalModeEnum.EDIT;
    showRelationForm.value = true;
}

async function removeRelation(value: RegistryRelation) {
    selectedRelation.value = value;
    modalMode.value = ModalModeEnum.DELETE;
    showRelationForm.value = true;
}

function closeRelation() {
    showRelationForm.value = false;
    modalMode.value = ModalModeEnum.EDIT;
    selectedRelation.value = {} as RegistryRelation;
}

function saveRelation(value: RegistryRelation) {
    switch (modalMode.value) {
        case ModalModeEnum.EDIT:
            updateRelation(value);
            break;
        case ModalModeEnum.DELETE:
            deleteRelation(value);
            break;
        default:
            createRelation(value);
    }
}

async function createRelation(relation: Partial<RegistryRelation>) {
    const mappedRelation = { ...relation } as RegistryRelation;
    mappedRelation.dtStart = moment(relation.dtStart).format("YYYYMMDD");
    mappedRelation.dtEnd = relation.dtEnd ? moment(relation.dtEnd).format("YYYYMMDD") : undefined;
    const res = await useApiResponseHandler(() =>
        relationApi.createRegistryRelationTypeRelation(props.regId, mappedRelation),
    );
    if (res) {
        getRelationTypeRelations();
        closeRelation();
    }
}

async function updateRelation(relation: Partial<RegistryRelation>) {
    const mappedRelation = { ...relation } as RegistryRelation;
    mappedRelation.dtStart = moment(relation.dtStart).format("YYYYMMDD");
    mappedRelation.dtEnd = relation.dtEnd ? moment(relation.dtEnd).format("YYYYMMDD") : undefined;
    const res = await useApiResponseHandler(() =>
        relationApi.updateRegistryRelationTypeRelation(props.regId, mappedRelation),
    );
    if (res) {
        getRelationTypeRelations();
        closeRelation();
    }
}

async function deleteRelation(relation: Partial<RegistryRelation>) {
    const res = await useApiDeleteHandler(() => relationApi.deleteRegistryRelationTypeRelation(props.regId, relation));
    if (res) {
        getRelationTypeRelations();
        closeRelation();
    }
}

function openSearchRelation() {
    showRelationForm.value = false;
    showSearchForm.value = true;
}

function closeSearchRelation() {
    registryList.value = null;
    showSearchForm.value = false;
}

async function searchRelation(searchForm: Partial<RegistrySearchRequest>) {
    currentSearchForm = searchForm;
    const res = await useApiResponseHandler(() => registryApi.getRegistries(searchForm));
    if (res) {
        registryList.value = res.records as PartySearchResponse[];
        registryListNextKey.value = res.nextKey;
    }
}

async function loadMoreRegistry() {
    const res = await useApiResponseHandler(() =>
        registryApi.getRegistries(currentSearchForm, registryListNextKey.value),
    );
    if (res) {
        registryList.value = {
            ...registryList.value,
            ...res.records.reduce(
                (acc, item) => {
                    acc[item.id] = item;
                    return acc;
                },
                {} as Record<string, PartySearchResponse>,
            ),
        };
        registryListNextKey.value = res.nextKey;
    }
}

const modalTitle = computed(() => {
    const title = t(`${MODULE_ID}.registry.form.fields.relationType.modalModeEnum.` + ModalModeEnum.EDIT + ".title");
    const subTitle = t(`${MODULE_ID}.registry.form.fields.relation.modalModeEnum.` + modalMode.value + ".title");
    const searchTitle = t(`${MODULE_ID}.registry.form.fields.relation.search`);
    if (showRelationForm.value && modalMode.value !== ModalModeEnum.DELETE) return `${title} - ${subTitle}`;
    else if (showSearchForm.value) return `${title} - ${searchTitle}`;
    else return title;
});
</script>
<template>
    <RegistryRelationTypeList
        v-if="registryRelationTypeList.length > 0"
        :relation-type-list="registryRelationTypeList"
        :show-load-more="!!relationTypeListNextKey"
        @load-more="loadMoreRelationTypes"
        @edit-relation-type="editRelationType"
        @delete-relation-type="removeRelationType"
    ></RegistryRelationTypeList>
    <div class="mt-3 d-flex justify-content-center">
        <BiButton :is-outlined="true" color="primary" @click="newRelationType" v-if="!isReadonly">
            {{ t(`${MODULE_ID}.registry.form.fields.relationType.new`) }}
        </BiButton>
    </div>

    <BiModal
        :size="modalMode === 'DELETE' ? undefined : 'xl'"
        ariaLabelledby="relation"
        :id="getUUID()"
        v-model="showModal"
        :title="modalTitle"
        data-keyboard="false"
        data-backdrop="static"
        extra-body-class="pt-5"
    >
        <template #body>
            <template v-if="showModal">
                <!-- #135589 pass regId to RegistryRelationTypeForm -->
                <RegistryRelationTypeForm
                    v-if="!showRelationForm && !showSearchForm"
                    :reg-id="regId"
                    :model-value="selectedRelationType"
                    :modal-mode="modalMode"
                    :relation-types="relationTypes"
                    :relations-list="relationsList"
                    :roleTypes="roleTypes"
                    @load-more="loadMoreRelations"
                    :show-load-more="!!relationListNextKey"
                    @close-modal="closeModal"
                    @save-relation-type="saveRelationType"
                    @edit-relation="editRelation"
                    @delete-relation="removeRelation"
                    @search-relation="openSearchRelation"
                    @reload="emit('reload')"
                ></RegistryRelationTypeForm>
                <RegistryRelationForm
                    v-if="showRelationForm"
                    :model-value="selectedRelation"
                    :modal-mode="modalMode"
                    :role-types="roleTypes"
                    :selected-relation-type="selectedRelationType"
                    @close-relation="closeRelation"
                    @save-relation="saveRelation"
                >
                </RegistryRelationForm>
                <RegistryRelationSearchForm
                    v-if="showSearchForm"
                    @search="searchRelation"
                    @cancel="closeSearchRelation"
                ></RegistryRelationSearchForm>
                <RegistryRelationSearchList
                    v-if="showSearchForm && registryList"
                    :registry-list="registryList"
                    @add-relation="newRelation"
                    @load-more="loadMoreRegistry"
                    :show-load-more="!!registryListNextKey"
                >
                </RegistryRelationSearchList>
            </template>
        </template>
    </BiModal>
</template>
