<script setup lang="ts">
import { i18n } from "patri-common-ui/src";
import type { PartySearchResponse } from "@/models/PartySearchResponseSchema";
import BiTable from "@abaco/bootstrap-italia-components/src/components/BiTable/BiTable.vue";
import BiButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiButton.vue";
import BiIcon from "@abaco/bootstrap-italia-components/src/components/BiIcon/BiIcon.vue";
import { MODULE_ID } from "@/constants";
import { MODULE_ID as COMMON_MODULE_ID } from "patri-common-ui/src/constants";
import useColors from "@abaco/bootstrap-italia-components/src/composables/useColors";

withDefaults(
    defineProps<{
        registryList: PartySearchResponse[];
        showLoadMore?: boolean;
    }>(),
    { showLoadMore: false },
);

const { t } = i18n.global;

const { getColor } = useColors();

const emit = defineEmits<{
    (e: "load-more"): void;
    (e: "add-relation", value: PartySearchResponse): void;
}>();

function loadMore() {
    emit("load-more");
}

function onAddRelation(value: PartySearchResponse) {
    emit("add-relation", value);
}
</script>
<template>
    <BiTable class="table mb-0" extraTableClasses="table-head-bg" is-row-hover isResponsive>
        <template #head>
            <tr class="bg-light" :class="getColor('text', 'secondary')">
                <th scope="col">{{ t(`${MODULE_ID}.registry.list.fields.lastName`) }}</th>
                <th scope="col">{{ t(`${MODULE_ID}.registry.list.fields.firstName`) }}</th>
                <th scope="col">{{ t(`${MODULE_ID}.registry.list.fields.taxCode`) }}</th>
                <th scope="col">{{ t(`${MODULE_ID}.registry.list.fields.vatNumber`) }}</th>
                <th scope="col"></th>
            </tr>
        </template>
        <template #body>
            <tr v-for="(item, i) in registryList" :key="i" :class="{ 'text-muted': item.archived }">
                <td :data-label="t(`${MODULE_ID}.registry.list.fields.lastName`)">
                    {{ item.lastName }}
                </td>
                <td :data-label="t(`${MODULE_ID}.registry.list.fields.firstName`)">
                    {{ item.firstName }}
                </td>
                <td :data-label="t(`${MODULE_ID}.registry.list.fields.taxCode`)">
                    {{ item.taxCode }}
                </td>
                <td :data-label="t(`${MODULE_ID}.registry.list.fields.vatNumber`)">
                    {{ item.vatNumber }}
                </td>
                <td class="actions">
                    <BiButton
                        :title="t(`${COMMON_MODULE_ID}.general.add`)"
                        size="xs"
                        color="info"
                        is-outlined
                        is-icon
                        :width="40"
                        :height="38"
                        @click="onAddRelation(item)"
                    >
                        <BiIcon icon="plus"></BiIcon>
                    </BiButton>
                </td>
            </tr>
        </template>
    </BiTable>
    <div class="d-flex justify-content-end mb-4" v-if="showLoadMore">
        <BiButton :is-outlined="true" color="primary" @click="loadMore()">
            {{ t(`${COMMON_MODULE_ID}.general.loadMore`) }}
        </BiButton>
    </div>
</template>
