import JustValidate from "just-validate";
import { formUtils } from "patri-common-ui/src";

const { justValidateConfig } = formUtils;

const createRelationTypeFormValidatorConfig = (t: (s: string) => string, formRef: Element): JustValidate =>
    new JustValidate(formRef, justValidateConfig);
export default createRelationTypeFormValidatorConfig;
