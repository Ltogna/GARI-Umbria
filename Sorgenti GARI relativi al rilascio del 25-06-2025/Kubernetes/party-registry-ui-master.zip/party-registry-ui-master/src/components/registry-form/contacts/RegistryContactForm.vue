<script setup lang="ts">
import { computed, onMounted, ref, watch } from "vue";
import { type Contact, ContactTypeEnum } from "@/models/contact/ContactRequest";
import { getUUID } from "@abaco/bootstrap-italia-components/src/utilities";
import BiSelect from "@abaco/bootstrap-italia-components/src/components/form/BiSelect.vue";
import BiButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiButton.vue";
import { ModalModeEnum } from "patri-common-ui/src";
import { useForm } from "patri-common-ui/src";
import createContactFormValidatorConfig from "./contactFormValidatorConfig";
import { i18n, BiTextInput } from "patri-common-ui/src";
import { MODULE_ID } from "@/constants";
import { MODULE_ID as COMMON_MODULE_ID } from "patri-common-ui/src/constants";
import type { FieldRuleInterface } from "just-validate";
import type JustValidate from "just-validate";
import { getFieldSelector } from "patri-common-ui/src/utils/formUtils";

const props = defineProps<{
    modelValue: Contact;
    modalMode: ModalModeEnum;
    validatorFn?: (id: string) => Promise<boolean>;
}>();
const emit = defineEmits<{
    (e: "close-modal"): void;
    (e: "save-contact", contact: Contact): void;
}>();

const { t } = i18n.global;
const formId = getUUID();
const contactFormRef = ref();
const contactForm = ref<Partial<Contact>>({ contactType: ContactTypeEnum.PHONE } as Contact);
const items = Object.keys(ContactTypeEnum).map((key) => {
    return { id: key, text: t(`${MODULE_ID}.registry.form.fields.contacts.contactTypeEnum.` + key) };
});
const { validate, onValidate, onSubmit } = useForm<Partial<Contact>>(submitCallback, contactForm.value, formId);

watch(
    contactForm,
    ({ contactType }) => {
        if (contactType === "PHONE") {
            (validate.value as JustValidate).addField(getFieldSelector(formId, "contactValue"), [
                {
                    rule: "required",
                    errorMessage: t(`${COMMON_MODULE_ID}.errors.fieldRequired`),
                } as FieldRuleInterface,
                {
                    rule: "customRegexp",
                    value: /(^\+?[0-9]+$)/i,
                    errorMessage: t(`${MODULE_ID}.errors.phoneFormat`),
                } as FieldRuleInterface,
            ]);
        }

        if (contactType === "EMAIL" || contactType === "PEC") {
            (validate.value as JustValidate).addField(getFieldSelector(formId, "contactValue"), [
                {
                    rule: "required",
                    errorMessage: t(`${COMMON_MODULE_ID}.errors.fieldRequired`),
                } as FieldRuleInterface,
                {
                    rule: "email",
                    errorMessage: t(`${MODULE_ID}.errors.emailFormat`),
                } as FieldRuleInterface,
            ]);
        }
    },
    { deep: true },
);

onMounted(() => {
    validate.value = createContactFormValidatorConfig(t, contactFormRef.value);
    contactForm.value = Object.assign({} as Contact, props.modelValue);
});

function closeModal() {
    emit("close-modal");
}

function submitCallback() {
    emit("save-contact", contactForm.value as Contact);
}

const modalConfirmButton = computed(() => {
    if (props.modalMode == ModalModeEnum.DELETE) return "danger";
    else return "success";
});
</script>
<template>
    <form :id="formId" class="needs-validation" @submit.prevent="onSubmit" ref="contactFormRef">
        <div class="form-group" v-if="modalMode !== ModalModeEnum.DELETE">
            <BiSelect
                :id="getUUID()"
                :label="t(`${MODULE_ID}.registry.form.fields.contacts.typology`)"
                :items="items"
                name="contactType"
                :validator-fn="onValidate"
                v-model="contactForm.contactType"
            ></BiSelect>
        </div>
        <div class="form-group">
            <BiTextInput
                :id="getUUID()"
                :label="t(`${MODULE_ID}.registry.form.fields.contacts.contactTypeEnum.` + contactForm.contactType)"
                name="contactValue"
                :validator-fn="onValidate"
                v-model="contactForm.contactValue"
                :is-disabled="modalMode === ModalModeEnum.DELETE"
            ></BiTextInput>
        </div>
        <div class="form-group">
            <BiTextInput
                :id="getUUID()"
                :label="t(`${MODULE_ID}.registry.form.fields.contacts.tag`)"
                name="subType"
                :validator-fn="onValidate"
                v-model="contactForm.subType"
                :is-disabled="modalMode === ModalModeEnum.DELETE"
            ></BiTextInput>
        </div>
        <div class="form-group">
            <BiTextInput
                :id="getUUID()"
                :label="t(`${MODULE_ID}.registry.form.fields.contacts.note`)"
                name="note"
                :validator-fn="onValidate"
                v-model="contactForm.note"
                :is-disabled="modalMode === ModalModeEnum.DELETE"
            ></BiTextInput>
        </div>
        <div class="d-flex justify-content-center">
            <BiButton color="primary" is-outlined @click="closeModal()" class="btn-me">
                {{ t(`${COMMON_MODULE_ID}.general.cancel`) }}
            </BiButton>
            <BiButton type="submit" :color="modalConfirmButton">
                {{ t(`${MODULE_ID}.registry.form.fields.contacts.modalModeEnum.` + modalMode + ".confirm") }}
            </BiButton>
        </div>
    </form>
</template>
