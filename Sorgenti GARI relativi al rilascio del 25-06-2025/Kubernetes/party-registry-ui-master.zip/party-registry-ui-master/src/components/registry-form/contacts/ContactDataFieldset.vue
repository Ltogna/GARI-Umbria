<script setup lang="ts">
import { ref, computed } from "vue";

import { i18n } from "patri-common-ui/src";

import BiButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiButton.vue";
import BiModal from "@abaco/bootstrap-italia-components/src/components/BiModal/BiModal.vue";
import { getUUID } from "@abaco/bootstrap-italia-components/src/utilities";
import { ModalModeEnum } from "patri-common-ui/src";
import { ContactTypeEnum, type Contact } from "@/models/contact/ContactRequest";

import RegistryContactForm from "@/components/registry-form/contacts/RegistryContactForm.vue";
import RegistryContactList from "@/components/registry-form/contacts/RegistryContactList.vue";
import { MODULE_ID } from "@/constants";
import { useRegistryStore } from "@/stores/registry";
import usePermissions from "@/hooks/usePermissions";

const { t } = i18n.global;
const registryStore = useRegistryStore();

withDefaults(
    defineProps<{
        contactList: Contact[];
        showLoadMore?: boolean;
        validatorFn?: (id: string) => Promise<boolean>;
    }>(),
    { showLoadMore: false },
);

const showModal = ref(false);
const modalMode = ref(ModalModeEnum.NEW);
const selectedContact = ref();
selectedContact.value = Object.assign({ contactType: ContactTypeEnum.PHONE } as Contact);

const emit = defineEmits<{
    (e: "create-contact", value: Contact): void;
    (e: "update-contact", value: Contact): void;
    (e: "delete-contact", value: Contact): void;
    (e: "load-more"): void;
}>();

const { canWrite } = usePermissions();
const isReadonly = computed(() => registryStore.currentDetail?.archived || !canWrite);

function closeModal() {
    showModal.value = false;
}

function newContact() {
    modalMode.value = ModalModeEnum.NEW;
    showModal.value = true;
    selectedContact.value = Object.assign({ contactType: ContactTypeEnum.PHONE } as Contact);
}

function onEditContact(value: Contact) {
    modalMode.value = ModalModeEnum.EDIT;
    selectedContact.value = value;
    showModal.value = true;
}

function onDeleteContact(value: Contact) {
    modalMode.value = ModalModeEnum.DELETE;
    selectedContact.value = value;
    showModal.value = true;
}

function onSaveContact(value: Contact) {
    switch (modalMode.value) {
        case ModalModeEnum.EDIT:
            emit("update-contact", value);
            break;
        case ModalModeEnum.DELETE:
            emit("delete-contact", value);
            break;
        default:
            emit("create-contact", value);
    }
    closeModal();
}

function loadMore() {
    emit("load-more");
}
</script>
<template>
    <RegistryContactList
        :contact-list="contactList"
        :show-load-more="!!showLoadMore"
        @load-more="loadMore"
        @edit-contact="onEditContact"
        @delete-contact="onDeleteContact"
    ></RegistryContactList>
    <div class="mt-3 d-flex justify-content-center" v-if="!isReadonly">
        <BiButton :is-outlined="true" color="primary" @click="newContact()">
            {{ t(`${MODULE_ID}.registry.form.fields.contacts.new`) }}
        </BiButton>
    </div>
    <Teleport to="body">
        <BiModal
            ariaLabelledby="new-contact"
            :id="getUUID()"
            v-model="showModal"
            :title="t(`${MODULE_ID}.registry.form.fields.contacts.modalModeEnum.` + modalMode + '.title')"
            data-keyboard="false"
            data-backdrop="static"
            extra-body-class="pt-5"
        >
            <template #body>
                <RegistryContactForm
                    v-if="showModal"
                    :model-value="selectedContact"
                    :modal-mode="modalMode"
                    @close-modal="closeModal"
                    @save-contact="onSaveContact"
                    :validator-fn="validatorFn"
                ></RegistryContactForm>
            </template>
        </BiModal>
    </Teleport>
</template>
