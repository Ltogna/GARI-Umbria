import { formUtils } from "patri-common-ui/src";
import JustValidate from "just-validate";
import type { FieldRuleInterface } from "just-validate/dist/modules/interfaces";
import { MODULE_ID as COMMON_MODULE_ID } from "patri-common-ui/src/constants";

const { justValidateConfig, getFieldSelector } = formUtils;

const createContactFormValidatorConfig = (t: (s: string) => string, formRef: Element): JustValidate =>
    new JustValidate(formRef, justValidateConfig)
        .addField(getFieldSelector(formRef.id, "contactValue"), [
            {
                rule: "required",
                errorMessage: t(`${COMMON_MODULE_ID}.errors.fieldRequired`),
            } as FieldRuleInterface,
        ])
        .addField(getFieldSelector(formRef.id, "subType"), [
            {
                rule: "required",
                errorMessage: t(`${COMMON_MODULE_ID}.errors.fieldRequired`),
            } as FieldRuleInterface,
        ]);

export default createContactFormValidatorConfig;
