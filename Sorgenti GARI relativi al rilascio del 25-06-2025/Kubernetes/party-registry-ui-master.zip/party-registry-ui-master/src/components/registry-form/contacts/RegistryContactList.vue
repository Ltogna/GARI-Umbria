<script setup lang="ts">
import { computed } from "vue";
import { i18n } from "patri-common-ui/src";
import type { Contact } from "@/models/contact/ContactRequest";
import BiButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiButton.vue";
import BiTable from "@abaco/bootstrap-italia-components/src/components/BiTable/BiTable.vue";
import BiIcon from "@abaco/bootstrap-italia-components/src/components/BiIcon/BiIcon.vue";
import { MODULE_ID } from "@/constants";
import { MODULE_ID as COMMON_MODULE_ID } from "patri-common-ui/src/constants";
import useColors from "@abaco/bootstrap-italia-components/src/composables/useColors";
import { useRegistryStore } from "@/stores/registry";
import usePermissions from "@/hooks/usePermissions";

withDefaults(
    defineProps<{
        contactList: Contact[];
        showLoadMore?: boolean;
    }>(),
    { showLoadMore: false },
);

const { t } = i18n.global;
const registryStore = useRegistryStore();

const emit = defineEmits<{
    (e: "edit-contact", value: Contact): void;
    (e: "delete-contact", value: Contact): void;
    (e: "load-more"): void;
}>();

const { getColor } = useColors();
const { canWrite } = usePermissions();
const isReadonly = computed(() => registryStore.currentDetail?.archived || !canWrite);

const onEditContact = (elem: Contact) => {
    emit("edit-contact", elem);
};

const onDeleteContact = (elem: Contact) => {
    emit("delete-contact", elem);
};

function loadMore() {
    emit("load-more");
}
</script>
<template>
    <BiTable class="table mb-0" extraTableClasses="table-head-bg" is-row-hover isResponsive>
        <template #head>
            <tr class="bg-light" :class="getColor('text', 'secondary')">
                <th scope="col">{{ t(`${MODULE_ID}.registry.form.fields.contacts.typology`) }}</th>
                <th scope="col">{{ t(`${MODULE_ID}.registry.form.fields.contacts.numberOrAddress`) }}</th>
                <th scope="col">{{ t(`${MODULE_ID}.registry.form.fields.contacts.tag`) }}</th>
                <th scope="col">{{ t(`${MODULE_ID}.registry.form.fields.contacts.note`) }}</th>
                <th scope="col"></th>
            </tr>
        </template>
        <template #body>
            <tr v-for="(item, i) in contactList" :key="i">
                <td :data-label="t(`${MODULE_ID}.registry.form.fields.contacts.typology`)">
                    {{ t(`${MODULE_ID}.registry.form.fields.contacts.contactTypeEnum.` + item.contactType) }}
                </td>
                <td :data-label="t(`${MODULE_ID}.registry.form.fields.contacts.numberOrAddress`)">
                    {{ item.contactValue }}
                </td>
                <td :data-label="t(`${MODULE_ID}.registry.form.fields.contacts.tag`)">
                    {{ item.subType }}
                </td>
                <td :data-label="t(`${MODULE_ID}.registry.form.fields.contacts.note`)">
                    {{ item.note }}
                </td>
                <td class="text-end">
                    <BiButton
                        v-if="!isReadonly"
                        :title="t(`${COMMON_MODULE_ID}.general.edit`)"
                        size="xs"
                        color="success"
                        is-outlined
                        is-icon
                        :width="40"
                        :height="38"
                        class="btn-me"
                        @click="onEditContact(item)"
                    >
                        <BiIcon icon="pencil"></BiIcon>
                    </BiButton>
                    <BiButton
                        v-if="!isReadonly"
                        :title="t(`${COMMON_MODULE_ID}.general.delete`)"
                        size="xs"
                        color="danger"
                        is-outlined
                        is-icon
                        :width="40"
                        :height="38"
                        @click="onDeleteContact(item)"
                    >
                        <BiIcon icon="trash-can"></BiIcon>
                    </BiButton>
                </td>
            </tr>
        </template>
    </BiTable>
    <div class="d-flex justify-content-end mb-4" v-if="showLoadMore">
        <BiButton :is-outlined="true" color="primary" @click="loadMore()">
            {{ t(`${COMMON_MODULE_ID}.general.loadMore`) }}
        </BiButton>
    </div>
</template>
