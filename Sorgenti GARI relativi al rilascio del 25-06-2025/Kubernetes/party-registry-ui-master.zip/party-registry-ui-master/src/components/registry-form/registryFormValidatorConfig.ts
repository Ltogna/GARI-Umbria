import { MODULE_ID as COMMON_MODULE_ID } from "patri-common-ui/src/constants";
import JustValidate from "just-validate";
import type { FieldRuleInterface } from "just-validate/dist/modules/interfaces";
import { formUtils, i18n, dateUtils } from "patri-common-ui/src";
import type { Ref } from "vue";
import moment from "moment";
import { MODULE_ID } from "@/constants";
import type { RegistryRequest } from "@/models/RegistryRequest";
import {
    type GenericConfiguration,
    type RegExpRulesConfiguration,
    type AdvCustomConfigParams,
} from "@/stores/configuration";
import { useConfigurationStore } from "@/stores/configuration";

const { t } = i18n.global;

const vatNumberRgex =
    /(^(?:[A-Z][AEIOU][AEIOUX]|[B-DF-HJ-NP-TV-Z]{2}[A-Z]){2}(?:[\dLMNP-V]{2}(?:[A-EHLMPR-T](?:[04LQ][1-9MNP-V]|[15MR][\dLMNP-V]|[26NS][0-8LMNP-U])|[DHPS][37PT][0L]|[ACELMRT][37PT][01LM]|[AC-EHLMPR-T][26NS][9V])|(?:[02468LNQSU][048LQU]|[13579MPRTV][26NS])B[26NS][9V])(?:[A-MZ][1-9MNP-V][\dLMNP-V]{2}|[A-M][0L](?:[1-9MNP-V][\dLMNP-V]|[0L][1-9MNP-V]))[A-Z]$)|(^[0-9]{11}$)/i;
const taxCodeRgex =
    /^(?:[A-Z][AEIOU][AEIOUX]|[B-DF-HJ-NP-TV-Z]{2}[A-Z]){2}(?:[\dLMNP-V]{2}(?:[A-EHLMPR-T](?:[04LQ][1-9MNP-V]|[15MR][\dLMNP-V]|[26NS][0-8LMNP-U])|[DHPS][37PT][0L]|[ACELMRT][37PT][01LM]|[AC-EHLMPR-T][26NS][9V])|(?:[02468LNQSU][048LQU]|[13579MPRTV][26NS])B[26NS][9V])(?:[A-MZ][1-9MNP-V][\dLMNP-V]{2}|[A-M][0L](?:[1-9MNP-V][\dLMNP-V]|[0L][1-9MNP-V]))[A-Z]$/i;

const { justValidateConfig, getFieldSelector } = formUtils;

export default class RegistryFormValidatorConfig {
    validate: JustValidate;
    formRefId: string;
    form: Ref<Partial<RegistryRequest>>;
    cuaaConfig: GenericConfiguration | null;
    nationalityConfig?: GenericConfiguration | null;
    isPartyTypeEditable: boolean | null;
    hasLegalStatus?: boolean;
    hasVatNumber?: boolean;
    legalStatusConfig?: AdvCustomConfigParams | null;
    vatNumberConfig?: AdvCustomConfigParams | null;

    get fields() {
        return this.validate.fields;
    }

    constructor(
        formRef: Element,
        groupIds: { [s: string]: string },
        form: Ref<Partial<RegistryRequest>>,
        cuaaConfig?: GenericConfiguration | null,
        nationalityConfig?: GenericConfiguration | null,
        isPartyTypeEditable?: boolean | null,
        hasLegalStatus?: boolean,
        hasVatNumber?: boolean,
    ) {
        this.formRefId = formRef.id;
        this.form = form;
        this.cuaaConfig = cuaaConfig ?? null;
        this.nationalityConfig = nationalityConfig ?? null;
        this.isPartyTypeEditable = isPartyTypeEditable ?? null;
        this.hasLegalStatus = !!hasLegalStatus;
        this.hasVatNumber = !!hasVatNumber;
        this.legalStatusConfig = useConfigurationStore().legal_status;
        this.vatNumberConfig = useConfigurationStore().vat_number;
        this.validate = new JustValidate(formRef, justValidateConfig)
            .addField(getFieldSelector(formRef.id, "lastName"), [
                {
                    rule: "required",
                    errorMessage: t(`${COMMON_MODULE_ID}.errors.fieldRequired`),
                } as FieldRuleInterface,
            ])
            .addField(getFieldSelector(this.formRefId, "taxCode"), [
                {
                    rule: "required",
                    errorMessage: t(`${COMMON_MODULE_ID}.errors.fieldRequired`),
                } as FieldRuleInterface,
                {
                    rule: "customRegexp",
                    value: taxCodeRgex,
                    errorMessage: t(`${COMMON_MODULE_ID}.errors.customRegexp`),
                } as FieldRuleInterface,
            ])
            .addField(getFieldSelector(this.formRefId, "deathDate"), [
                {
                    validator: () => {
                        if (!!this.form.value.deathDate && !!this.form.value.birthDate) {
                            const convertedBirthDate = dateUtils.getRawDate(
                                dateUtils.getStringDate(this.form.value.birthDate),
                            );
                            const convertedDeathDate = dateUtils.getRawDate(
                                dateUtils.getStringDate(this.form.value.deathDate),
                            );

                            return moment(convertedDeathDate).isAfter(convertedBirthDate);
                        }
                        return true;
                    },
                    errorMessage: t(`${MODULE_ID}.errors.deathDate`),
                } as FieldRuleInterface,
            ]);

        if (this.isPartyTypeEditable) {
            this.validate.addRequiredGroup(`#${groupIds.partyTypeGroup}`, t(`${MODULE_ID}.errors.fieldRequired`));
        }

        if (!!this.cuaaConfig && this.cuaaConfig.configuration?.mandatory) {
            this.validate.addField(getFieldSelector(formRef.id, "cuaa"), [
                {
                    rule: "required",
                    errorMessage: t(`${COMMON_MODULE_ID}.errors.fieldRequired`),
                } as FieldRuleInterface,
            ]);
        }

        if (this.hasVatNumber) {
            this.validate.addField(getFieldSelector(this.formRefId, "vatNumber"), [
                {
                    rule: "customRegexp",
                    value: vatNumberRgex,
                    errorMessage: t(`${COMMON_MODULE_ID}.errors.customRegexp`),
                } as FieldRuleInterface,
            ]);
        }

        if (this.hasLegalStatus) {
            this.validate.addField(getFieldSelector(this.formRefId, "legalStatus"), [
                {
                    rule: "required",
                    errorMessage: t(`${COMMON_MODULE_ID}.errors.fieldRequired`),
                } as FieldRuleInterface,
                {
                    validator: () => {
                        if (!form.value.legalStatus) return false;
                        return true;
                    },
                    errorMessage: t(`${MODULE_ID}.errors.notValidOption`),
                } as FieldRuleInterface,
            ]);
        }
    }

    updateNaturalTypeValidation(
        form: Ref<Partial<RegistryRequest>>,
        cuaaValidation?: RegExpRulesConfiguration | null,
        vatNumberValidation?: RegExpRulesConfiguration | null,
        taxCodeValidation?: RegExpRulesConfiguration | null,
        legalStatusValidation?: RegExpRulesConfiguration | null,
        hasLegalStatus?: boolean,
        hasVatNumber?: boolean,
    ) {
        this.validate
            .removeField(getFieldSelector(this.formRefId, "lastName"))
            .addField(getFieldSelector(this.formRefId, "lastName"), [
                {
                    rule: "required",
                    errorMessage: t(`${COMMON_MODULE_ID}.errors.fieldRequired`),
                } as FieldRuleInterface,
            ])
            .addField(getFieldSelector(this.formRefId, "firstName"), [
                {
                    rule: "required",
                    errorMessage: t(`${COMMON_MODULE_ID}.errors.fieldRequired`),
                } as FieldRuleInterface,
            ])
            .removeField(getFieldSelector(this.formRefId, "deathDate"))
            .addField(getFieldSelector(this.formRefId, "deathDate"), [
                {
                    validator: () => {
                        if (!!form.value.deathDate && !!form.value.birthDate) {
                            const convertedBirthDate = dateUtils.getRawDate(
                                dateUtils.getStringDate(form.value.birthDate),
                            );
                            const convertedDeathDate = dateUtils.getRawDate(
                                dateUtils.getStringDate(form.value.deathDate),
                            );

                            return moment(convertedDeathDate).isAfter(convertedBirthDate);
                        }
                        return true;
                    },
                    errorMessage: t(`${MODULE_ID}.errors.deathDate`),
                } as FieldRuleInterface,
            ])
            .removeField(getFieldSelector(this.formRefId, "taxCode"))
            .addField(getFieldSelector(this.formRefId, "taxCode"), [
                {
                    rule: "required",
                    errorMessage: t(`${COMMON_MODULE_ID}.errors.fieldRequired`),
                } as FieldRuleInterface,
                {
                    validator: (value) => {
                        if (typeof value === "string" && taxCodeValidation && taxCodeValidation.configuration) {
                            const regExpRules = taxCodeValidation.configuration.N.map((o) => new RegExp(o));
                            return regExpRules.some((regex) => regex.test(value));
                        }
                        return true;
                    },
                    errorMessage: t(`${COMMON_MODULE_ID}.errors.customRegexp`),
                } as FieldRuleInterface,
            ]);

        if (!!this.cuaaConfig && this.cuaaConfig.configuration?.mandatory) {
            this.validate.addField(getFieldSelector(this.formRefId, "cuaa"), [
                {
                    rule: "required",
                    errorMessage: t(`${COMMON_MODULE_ID}.errors.fieldRequired`),
                } as FieldRuleInterface,
                {
                    validator: () => {
                        if (form.value?.code && cuaaValidation && cuaaValidation.configuration) {
                            const cuaa = form.value.code;
                            const regExpRules = cuaaValidation.configuration.N.map((o) => new RegExp(o));
                            return regExpRules.some((regex) => regex.test(cuaa));
                        }
                        return true;
                    },
                    errorMessage: t(`${COMMON_MODULE_ID}.errors.customRegexp`),
                } as FieldRuleInterface,
            ]);
        }

        if (!!this.nationalityConfig && this.nationalityConfig.configuration?.mandatory) {
            this.validate.addField(getFieldSelector(this.formRefId, "nationality"), [
                {
                    rule: "required",
                    errorMessage: t(`${COMMON_MODULE_ID}.errors.fieldRequired`),
                } as FieldRuleInterface,
            ]);
        }

        if (hasVatNumber) {
            this.validate
                .removeField(getFieldSelector(this.formRefId, "vatNumber"))
                .addField(getFieldSelector(this.formRefId, "vatNumber"), [
                    {
                        validator: () => {
                            if (form.value?.vatNumber && vatNumberValidation && vatNumberValidation.configuration) {
                                const vatNumber = form.value.vatNumber;
                                const regExpRules = vatNumberValidation.configuration.L.map((o) => new RegExp(o));
                                return regExpRules.some((regex) => regex.test(vatNumber));
                            }
                            return true;
                        },
                        errorMessage: t(`${COMMON_MODULE_ID}.errors.customRegexp`),
                    } as FieldRuleInterface,
                ]);
        } else {
            this.validate.removeField(getFieldSelector(this.formRefId, "vatNumber"));
        }

        if (hasLegalStatus) {
            this.validate
                .removeField(getFieldSelector(this.formRefId, "legalStatus"))
                .addField(getFieldSelector(this.formRefId, "legalStatus"), [
                    {
                        rule: "required",
                        errorMessage: t(`${COMMON_MODULE_ID}.errors.fieldRequired`),
                    } as FieldRuleInterface,
                    {
                        validator: () => {
                            if (!form.value.legalStatus) return false;
                            return true;
                        },
                        errorMessage: t(`${MODULE_ID}.errors.notValidOption`),
                    } as FieldRuleInterface,
                ]);
        }

        if (hasLegalStatus && legalStatusValidation) {
            this.validate
                .removeField(getFieldSelector(this.formRefId, "legalStatus"))
                .addField(getFieldSelector(this.formRefId, "legalStatus"), [
                    {
                        validator: () => {
                            if (legalStatusValidation?.configuration) {
                                const legalStatus = form.value?.legalStatus;
                                const regExpRules = legalStatusValidation.configuration.N.map((o) => new RegExp(o));
                                return regExpRules.some((regex) => regex.test(legalStatus ?? ""));
                            }
                            return true;
                        },
                        errorMessage: t(`${COMMON_MODULE_ID}.errors.fieldRequired`),
                    } as FieldRuleInterface,
                ]);
        }
    }

    updateLegalTypeValidation(
        form: Ref<Partial<RegistryRequest>>,
        cuaaValidation?: RegExpRulesConfiguration | null,
        vatNumberValidation?: RegExpRulesConfiguration | null,
        taxCodeValidation?: RegExpRulesConfiguration | null,
        legalStatusValidation?: RegExpRulesConfiguration | null,
        hasLegalStatus?: boolean,
        hasVatNumber?: boolean,
    ) {
        this.validate
            .removeField(getFieldSelector(this.formRefId, "lastName"))
            .addField(getFieldSelector(this.formRefId, "lastName"), [
                {
                    rule: "required",
                    errorMessage: t(`${COMMON_MODULE_ID}.errors.fieldRequired`),
                } as FieldRuleInterface,
            ])
            .removeField(getFieldSelector(this.formRefId, "firstName"))
            .removeField(getFieldSelector(this.formRefId, "deathDate"))
            .addField(getFieldSelector(this.formRefId, "deathDate"), [
                {
                    validator: () => {
                        if (!!form.value.deathDate && !!form.value.birthDate) {
                            const convertedBirthDate = dateUtils.getRawDate(
                                dateUtils.getStringDate(form.value.birthDate),
                            );
                            const convertedDeathDate = dateUtils.getRawDate(
                                dateUtils.getStringDate(form.value.deathDate),
                            );

                            return moment(convertedDeathDate).isAfter(convertedBirthDate);
                        }
                        return true;
                    },
                    errorMessage: t(`${MODULE_ID}.errors.terminationDate`),
                } as FieldRuleInterface,
            ])
            .removeField(getFieldSelector(this.formRefId, "taxCode"))
            .addField(getFieldSelector(this.formRefId, "taxCode"), [
                {
                    rule: "required",
                    errorMessage: t(`${COMMON_MODULE_ID}.errors.fieldRequired`),
                } as FieldRuleInterface,
                {
                    validator: (value) => {
                        if (typeof value === "string" && taxCodeValidation && taxCodeValidation.configuration) {
                            const regExpRules = taxCodeValidation.configuration.N.map((o) => new RegExp(o));
                            return regExpRules.some((regex) => regex.test(value));
                        }
                        return true;
                    },
                    errorMessage: t(`${COMMON_MODULE_ID}.errors.customRegexp`),
                } as FieldRuleInterface,
            ]);

        if (!!this.nationalityConfig && this.nationalityConfig.configuration?.mandatory) {
            this.validate.removeField(getFieldSelector(this.formRefId, "nationality"));
        }

        if (!!this.cuaaConfig && this.cuaaConfig.configuration?.mandatory) {
            this.validate.addField(getFieldSelector(this.formRefId, "cuaa"), [
                {
                    rule: "required",
                    errorMessage: t(`${COMMON_MODULE_ID}.errors.fieldRequired`),
                } as FieldRuleInterface,
                {
                    validator: () => {
                        if (form.value?.code && cuaaValidation && cuaaValidation.configuration) {
                            const cuaa = form.value.code;
                            const regExpRules = cuaaValidation.configuration.L.map((o) => new RegExp(o));
                            return regExpRules.some((regex) => regex.test(cuaa));
                        }
                        return true;
                    },
                    errorMessage: t(`${COMMON_MODULE_ID}.errors.customRegexp`),
                } as FieldRuleInterface,
            ]);
        }

        if (hasVatNumber) {
            this.validate.removeField(getFieldSelector(this.formRefId, "vatNumber"));
            this.validate.addField(getFieldSelector(this.formRefId, "vatNumber"), [
                {
                    rule: "required",
                    errorMessage: t(`${COMMON_MODULE_ID}.errors.fieldRequired`),
                } as FieldRuleInterface,
                {
                    validator: () => {
                        if (form.value?.vatNumber && vatNumberValidation && vatNumberValidation.configuration) {
                            const vatNumber = form.value.vatNumber;
                            const regExpRules = vatNumberValidation.configuration.L.map((o) => new RegExp(o));
                            return regExpRules.some((regex) => regex.test(vatNumber));
                        }
                        return true;
                    },
                    errorMessage: t(`${COMMON_MODULE_ID}.errors.customRegexp`),
                } as FieldRuleInterface,
            ]);
        } else {
            this.validate.removeField(getFieldSelector(this.formRefId, "vatNumber"));
        }

        if (hasLegalStatus) {
            this.validate
                .removeField(getFieldSelector(this.formRefId, "legalStatus"))
                .addField(getFieldSelector(this.formRefId, "legalStatus"), [
                    {
                        rule: "required",
                        errorMessage: t(`${COMMON_MODULE_ID}.errors.fieldRequired`),
                    } as FieldRuleInterface,
                    {
                        validator: () => {
                            if (!form.value.legalStatus) return false;
                            return true;
                        },
                        errorMessage: t(`${MODULE_ID}.errors.notValidOption`),
                    } as FieldRuleInterface,
                ]);
        }

        if (hasLegalStatus && legalStatusValidation) {
            this.validate
                .removeField(getFieldSelector(this.formRefId, "legalStatus"))
                .addField(getFieldSelector(this.formRefId, "legalStatus"), [
                    {
                        validator: () => {
                            if (legalStatusValidation?.configuration) {
                                const legalStatus = form.value?.legalStatus;
                                const regExpRules = legalStatusValidation.configuration.L.map((o) => new RegExp(o));
                                return regExpRules.some((regex) => regex.test(legalStatus ?? ""));
                            }
                        },
                        errorMessage: t(`${COMMON_MODULE_ID}.errors.fieldRequired`),
                    } as FieldRuleInterface,
                ]);
        }
    }

    revalidate() {
        return this.validate.revalidate();
    }

    revalidateField(fieldId: string) {
        return this.validate.revalidateField(fieldId);
    }
}
