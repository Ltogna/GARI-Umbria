<script setup lang="ts">
import { computed, inject, onMounted, ref, toValue, watch, type MaybeRef, type Ref } from "vue";
import { useRouter } from "vue-router";

import BiAccordion from "@abaco/bootstrap-italia-components/src/components/BiAccordion/BiAccordion.vue";
import BiAccordionGroup from "@abaco/bootstrap-italia-components/src/components/BiAccordion/BiAccordionGroup.vue";
import BiAlert from "@abaco/bootstrap-italia-components/src/components/BiAlert/BiAlert.vue";
import BiButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiButton.vue";
import BiIcon from "@abaco/bootstrap-italia-components/src/components/BiIcon/BiIcon.vue";
import BiModal from "@abaco/bootstrap-italia-components/src/components/BiModal/BiModal.vue";
import BiDatepicker from "../BiDatepicker.vue";
import BiRadiobutton from "@abaco/bootstrap-italia-components/src/components/form/BiRadiobutton.vue";
import BiSelect from "@abaco/bootstrap-italia-components/src/components/form/BiSelect.vue";
import { getUUID } from "@abaco/bootstrap-italia-components/src/utilities";

import type ContactApi from "@/api/contact-api";
import type LegalStatusApi from "@/api/legal-status-api";

import { useNationalityAutocomplete } from "@/hooks/useNationalityAutocomplete";
import { useRegistryForm } from "@/hooks/useRegistryForm";
import { useApiDeleteHandler, useApiResponseHandler } from "@/index";
import { dateUtils, useForm } from "patri-common-ui/src";

import type { Contact } from "@/models/contact/ContactRequest";
import type { PartyResponse, ReadOnlyFieldsModel } from "@/models/PartySearchResponseSchema";
import { GenderEnum, PartyType, type RegistryRequest, type RegistryRequestPayload } from "@/models/RegistryRequest";

import type RegistryApi from "@/api/registry-api";
import AddressFieldset from "@/components/registry-form/AddressFieldset.vue";
import ContactDataFieldset from "@/components/registry-form/contacts/ContactDataFieldset.vue";
import RegistryFormValidatorConfig from "@/components/registry-form/registryFormValidatorConfig";
import TagsFieldset from "@/components/registry-form/TagsFieldset.vue";
import type { ContactRegistrySearchResponse } from "@/models/contact/ContactRegistrySearchResponseSchema";
import type { PartyCheckRequest, PartyCUAACheckRequest } from "@/models/PartyCheckRequest";
import { BiTextInput } from "patri-common-ui/src";
import RelationTypeDataFieldset from "./relations/RelationTypeDataFieldset.vue";

import TopBar from "@/components/registry-form/TopBar.vue";
import { MODULE_ID, CURRENT_DATE } from "@/constants";
import { useConfiguration } from "@/hooks/useConfiguration";
import usePermissions from "@/hooks/usePermissions";
import type { GenericSearchResponse } from "@/models/LegalStatus";
import type { PartyCheckDetailedResponse } from "@/models/PartySearchResponseSchema";
import { RouteName } from "@/routes";
import { useConfigurationStore } from "@/stores/configuration";
import { useRegistryStore } from "@/stores/registry";
import BiProgressIndicator from "@abaco/bootstrap-italia-components/src/components/BiProgressIndicator/BiProgressIndicator.vue";
import useColors from "@abaco/bootstrap-italia-components/src/composables/useColors";
import { i18n } from "patri-common-ui/src";
import { MODULE_ID as COMMON_MODULE_ID } from "patri-common-ui/src/constants";
import MunicipalityPickerInput from "../municipality-picker/MunicipalityPickerInput.vue";
import { sub } from "date-fns";
import { useRegistryFormConfigHelper } from "./useRegistryFormConfigHelper";

defineProps<{ regId?: number | string }>();

const MAX_BIRTH_DATE = sub(CURRENT_DATE, { days: 1 });

const { t } = i18n.global;
const router = useRouter();
const { canWrite } = usePermissions();
const { loadValidationConfig } = useConfiguration();
const { getColor } = useColors();

const contactApi: ContactApi = inject("contactApi") as ContactApi;
const legalStatusApi: LegalStatusApi = inject("legalStatusApi") as LegalStatusApi;

const configurationStore = useConfigurationStore();
const registryStore = useRegistryStore();
const formId = getUUID();
const groupIds: { [s: string]: string } = {
    partyTypeGroup: getUUID(),
    genderGroup: getUUID(),
};
const accordionId = getUUID();
const registryFormRef = ref<HTMLFormElement | null>();
const registryForm = ref<Partial<RegistryRequest>>({
    partyType: PartyType.N,
    gender: GenderEnum.M,
});
const birthDate = ref<Date>();
const deathDate = ref<Date>();
const initialCuaa = ref<string | null | undefined>();
const canGoToList = ref<boolean>(false);
const checkDuplicatesRes = ref<PartyCheckDetailedResponse>();
const isNextVersion = ref<boolean>(false);
const readOnlyFields = ref<ReadOnlyFieldsModel>({});
const externalSources = computed(() => registryStore.getExternalSources);
const isLoading = ref<boolean>(false);

/**
 * #134529 25/03/24
 * Accordion Ref
 */
const relationDataFieldsetAccordionRef = ref<InstanceType<typeof BiAccordion>>();

const emit = defineEmits<{
    reload: [];
}>();

async function initRegistryDetail(registryDetail: PartyResponse | null) {
    if (registryDetail) {
        initialCuaa.value = registryDetail?.code;
        registryForm.value = Object.assign(
            {
                ...registryDetail,
                tags: registryDetail.tags?.map((it) => it.code),
            },
            {} as RegistryRequest,
        );

        !!registryDetail.nationality &&
            (searchNationalityText.value = (await getNationalityById(registryDetail.nationality))?.i18nCode ?? "");
        if (registryDetail.legalStatus) {
            const res = await useApiResponseHandler(() =>
                // eslint-disable-next-line @typescript-eslint/no-non-null-assertion
                legalStatusApi.getLegalStatusByCode(registryDetail.legalStatus!),
            );
            searchLegalStatusText.value = res?.i18nCode ?? "";
        }
        registryDetail.deathDate &&
            registryDetail.deathDate !== dateUtils.INFINITE_DATE &&
            (deathDate.value = new Date(dateUtils.getStringDate(registryDetail.deathDate)));

        registryDetail.birthDate &&
            registryDetail.birthDate !== dateUtils.INFINITE_DATE &&
            (birthDate.value = new Date(dateUtils.getStringDate(registryDetail.birthDate)));
    }
    setValidation();
}

const registryContactList = ref<Contact[]>([]);
const contactListNextKey = ref();
async function getRegistryContacts() {
    if (regIdForm.value) {
        const id = regIdForm.value;
        const res = await useApiResponseHandler(() => contactApi.getContacts(id));
        if (res) {
            registryContactList.value = res.records as Contact[];
            contactListNextKey.value = res.nextKey;
        }
    }
}

const searchLegalStatusText = ref("");
const registryLegalStatustList = ref<GenericSearchResponse[]>([]);
async function getLegalStatusList() {
    const list: GenericSearchResponse[] = [];
    let nextKey: string | undefined = undefined;
    do {
        const res = await useApiResponseHandler(() => legalStatusApi.getLegalStatusList(nextKey));
        if (res) {
            nextKey = res.nextKey ?? undefined;
            list.push(
                ...res.records.map((o: GenericSearchResponse) => {
                    return {
                        code: o.code,
                        i18nCode: o.i18nCode ?? "",
                    };
                }),
            );
        }
    } while (nextKey);
    registryLegalStatustList.value = [
        ...list.sort((a, b) => {
            const i18nCodeA = a.i18nCode ?? "";
            const i18nCodeB = b.i18nCode ?? "";

            return i18nCodeA.localeCompare(i18nCodeB);
        }),
    ];
}

async function loadMoreContacts() {
    if (regIdForm.value) {
        const id = regIdForm.value;
        const res = await useApiResponseHandler(() => contactApi.getContacts(id, contactListNextKey.value));
        if (res) {
            registryContactList.value = {
                ...registryContactList.value,
                ...res.records.reduce(
                    (acc, item) => {
                        acc[item.pkid] = item;
                        return acc;
                    },
                    {} as Record<string, ContactRegistrySearchResponse>,
                ),
            };
            contactListNextKey.value = res.nextKey;
        }
    }
}

const { registryDetail, regId: regIdForm, create, update, partyTypes, genders } = useRegistryForm(initRegistryDetail);
const { validate, onValidate, onSubmit } = useForm<Partial<RegistryRequest>>(
    submitCallback,
    registryForm.value,
    formId,
);

const registryApi: RegistryApi = inject("registryApi") as RegistryApi;

const searchNationalityText = ref("");
const searchNationalityItems = ref<GenericSearchResponse[]>([]);
const { getNationalityList, getNationalityById } = useNationalityAutocomplete();

const showDuplicatesModal = ref<boolean>(false);
const showExternalSourcesErrorModal = ref<boolean>(false);
const showDuplicatedCuaaModal = ref<boolean>(false);
let saveCallBack: () => void;

watch(deathDate, (value) => {
    registryForm.value.deathDate = value ? dateUtils.getNormalizedDate(value) : undefined;
});
watch(birthDate, (value) => {
    registryForm.value.birthDate = value ? dateUtils.getNormalizedDate(value) : undefined;
});
watch(canGoToList, (value) => {
    if (value && !showDuplicatedCuaaModal.value && !showDuplicatesModal.value) {
        goToRegistryList();
    }
});

onMounted(async () => {
    if (sessionStorage.getItem("isNextVersion") === null) {
        const res = await useApiResponseHandler(() => registryApi.getExternalSources());
        if (res && res.length) {
            sessionStorage.setItem("isNextVersion", "true");
            registryStore.setExternalSources(res);
            isNextVersion.value = true;
        } else {
            sessionStorage.setItem("isNextVersion", "false");
            registryStore.setExternalSources([]);
            isNextVersion.value = false;
        }
    } else {
        isNextVersion.value = sessionStorage.getItem("isNextVersion") === "true";
    }
    await loadValidationConfig();
    await getLegalStatusList();
    searchNationalityItems.value = await getNationalityList();
    initRegistryDetail(registryDetail);
    getRegistryContacts();
    if (registryForm.value?.externalSource && isNextVersion.value && regIdForm.value !== null) {
        readOnlyFields.value = registryStore.getReadOnlyFields;
    }
    if (regIdForm.value !== null) {
        getRegistryContacts();
    }
});

async function onRefreshData() {
    isLoading.value = true;
    let firstExternalSource = externalSources.value ? externalSources.value[0] : null;
    if (!firstExternalSource) {
        const res = await useApiResponseHandler(() => registryApi.getExternalSources());
        if (res && res.length) {
            registryStore.setExternalSources(res);
            firstExternalSource = res[0];
        } else {
            registryStore.setExternalSources([]);
            firstExternalSource = null;
        }
    }
    const res = await useApiResponseHandler(() =>
        registryApi.searchAndUpdateParty(
            firstExternalSource?.code ?? "",
            (registryForm.value.taxCode ?? "").trim() ?? "",
        ),
    );

    if (res) {
        isLoading.value = false;
        location.reload();
    } else {
        isLoading.value = false;
        showExternalSourcesErrorModal.value = true;
    }
}

function onChangePartyType() {
    if (registryForm.value.partyType === PartyType.N) {
        registryForm.value.gender = GenderEnum.M;
    } else {
        registryForm.value.firstName = undefined;
        registryForm.value.gender = undefined;
    }
    setValidation();
}

function setValidation() {
    if (!validate.value && registryFormRef.value) {
        validate.value = new RegistryFormValidatorConfig(
            registryFormRef.value,
            groupIds,
            registryForm,
            configurationStore.code,
            configurationStore.nationality,
            // configurationStore.vatNumber,
            // configurationStore.taxCode,
            isPartyTypeEditable.value,
            !!registryLegalStatustList.value.length && !isLegalStatusHidden.value,
            !isVatNumberHidden.value,
        );
    }

    if (registryForm.value.partyType === PartyType.N) {
        validate.value.updateNaturalTypeValidation(
            registryForm,
            configurationStore.code_validation,
            configurationStore.vat_number_validation,
            configurationStore.tax_code_validation,
            configurationStore.legalStatus_validation,
            !!registryLegalStatustList.value.length && !isLegalStatusHidden.value,
            !isVatNumberHidden.value,
        );
    } else {
        validate.value.updateLegalTypeValidation(
            registryForm,
            configurationStore.code_validation,
            configurationStore.vat_number_validation,
            configurationStore.tax_code_validation,
            configurationStore.legalStatus_validation,
            !!registryLegalStatustList.value.length && !isLegalStatusHidden.value,
            !isVatNumberHidden.value,
        );
    }
}

function toUppercase(value: unknown): string {
    return `${value}`.toUpperCase();
}

/**
 * #131236 29/05/24
 *
 * Before save the form, clear the values
 */
function fixedFormData(value: MaybeRef<RegistryRequest>) {
    try {
        const cloned = JSON.parse(JSON.stringify(toValue(value)));
        cloned.nationality = cloned.nationality ? cloned.nationality : null;
        return cloned;
    } catch (e) {
        const instance = toValue(value) as RegistryRequestPayload;
        instance.nationality = instance.nationality ? instance.nationality : null;
        return instance;
    }
}

function submitCallback() {
    saveCallBack = async () => {
        let res;
        // #131236 clear the form values before sending
        const data = fixedFormData(registryForm as Ref<RegistryRequest>);
        if (regIdForm.value) res = await update(regIdForm.value, data);
        else res = await create(data);

        /**
         * #137061 04/19/2024
         *
         * This bug is caused when came from Dossier.
         * If the `backUrl` parameter is set and returning to the dossier, the software, tried to load the list
         * but the API had no parameters and it went into error.
         *
         * So, show the warning toast.
         *
         */
        const backUrl = sessionStorage.getItem(`${MODULE_ID}.backUrl`);
        if (backUrl) {
            res && window.location.assign(decodeURIComponent(backUrl));
        } else {
            if (registryStore.search) {
                await fetchList();
            } else {
                router.push({ name: RouteName.PARTY_LIST });
            }

            if (res) {
                canGoToList.value = true;
            }
        }
    };

    checkDuplicates();
}

async function onSave() {
    const isValid = await validate.value.revalidate();
    if (isValid) {
        saveCallBack = async () => {
            const res = await create(registryForm.value);
            if (res)
                router.replace({
                    name: RouteName.PARTY_EDIT_FORM,
                    params: { regId: res.id },
                });
        };

        checkDuplicates();
    }
}

function goToRegistryList() {
    const backUrl = sessionStorage.getItem(`${MODULE_ID}.backUrl`);
    if (backUrl) {
        window.location.assign(decodeURIComponent(backUrl));
    } else {
        router.push({
            name:
                router.currentRoute.value?.query["fromNextVer"] === "true"
                    ? RouteName.NEXT_PARTY_LIST
                    : RouteName.PARTY_LIST,
        });
    }
}

/**
 * #133119 21/03/24
 * Reset form instead goes back
 */
async function resetForm() {
    emit("reload");
}

async function onDispatchContactAction(contact: Partial<Contact>, apiMethod: "POST" | "PUT" | "DELETE") {
    if (!regIdForm.value) {
        return;
    }

    const id = regIdForm.value;
    const apiSet: Record<string, () => Promise<unknown> | null> = {
        POST: () => useApiResponseHandler(() => contactApi.createContact(id, contact)),
        PUT: () => useApiResponseHandler(() => contactApi.updateContact(id, contact)),
        DELETE: () => useApiDeleteHandler(() => contactApi.deleteContact(id, contact)),
    };

    (await apiSet[apiMethod]()) && getRegistryContacts();
}

async function onCreateContact(contact: Partial<Contact>) {
    onDispatchContactAction(contact, "POST");
}

async function onUpdateContact(contact: Partial<Contact>) {
    onDispatchContactAction(contact, "PUT");
}

async function onDeleteContact(contact: Partial<Contact>) {
    onDispatchContactAction(contact, "DELETE");
}

const canDisplayCuaa = computed(() => {
    return !!configurationStore.code;
});

const isCuaaEditable = computed(() => {
    return (
        !regIdForm.value ||
        (!!regIdForm.value && !!configurationStore?.code?.configuration?.editable) ||
        (!!regIdForm.value && !initialCuaa.value)
    );
});
const isPartyTypeEditable = computed(() => {
    return !regIdForm.value || (!!regIdForm.value && !!configurationStore?.party_type?.configuration?.editable);
});
const lastNameLabel = computed(() => {
    if (registryForm.value.partyType === PartyType.N) return t(`${MODULE_ID}.registry.form.fields.lastName`);
    else return t(`${MODULE_ID}.registry.form.fields.companyName`);
});

const birthDatalabelAppend = computed(() => {
    if (registryForm.value.partyType === PartyType.N)
        return ` ${t(`${MODULE_ID}.registry.form.fields.birthData.ofBirth`)}`;
    else return ` ${t(`${MODULE_ID}.registry.form.fields.birthData.ofEstablishment`)}`;
});
const deathDateLabel = computed(() => {
    if (registryForm.value.partyType === PartyType.N) {
        return ` ${t(`${MODULE_ID}.registry.form.fields.deathDate.label`)}`;
    }
    return ` ${t(`${MODULE_ID}.registry.form.fields.terminationDate.label`)}`;
});

const municipalityLabel = computed(() =>
    [t(`${MODULE_ID}.registry.form.fields.birthData.birthMunicipality.label`), birthDatalabelAppend.value].join(" "),
);
const municipalityPlaceholder = computed(() =>
    [t(`${COMMON_MODULE_ID}.general.select`), t(`${MODULE_ID}.municipality.search.municipality`).toLowerCase()].join(
        " ",
    ),
);
const birthDateLabel = computed(() =>
    [t(`${MODULE_ID}.registry.form.fields.birthData.birthDate.label`), birthDatalabelAppend.value].join(" "),
);

const isReadonly = computed(() => (!!regIdForm.value && !!registryStore.currentDetail?.archived) || !canWrite);

async function checkDuplicates() {
    const partyCheckRequest: Partial<PartyCheckRequest> = {};
    if (regIdForm.value) {
        partyCheckRequest.id = regIdForm.value;
    }
    if (registryForm.value.taxCode) {
        partyCheckRequest.taxCode = registryForm.value.taxCode;
    }
    if (registryForm.value.vatNumber) {
        partyCheckRequest.vatNumber = registryForm.value.vatNumber;
    }

    if (canDisplayCuaa.value) {
        const isDuplicatedCuaa = await checkDuplicateCuaa();

        isDuplicatedCuaa && (showDuplicatedCuaaModal.value = isDuplicatedCuaa);
    }

    if (showDuplicatedCuaaModal.value) {
        return;
    }

    const res = await useApiResponseHandler(() => registryApi.getDuplicatesDetailed(partyCheckRequest));

    if (res && (res.codiceFiscale || res.partitaIva)) {
        checkDuplicatesRes.value = { ...res };
        showDuplicatesModal.value = true;
    } else {
        showDuplicatesModal.value = false;
        checkDuplicatesRes.value = undefined;
    }

    if (showDuplicatesModal.value || showDuplicatedCuaaModal.value) {
        return;
    }

    await saveCallBack();
}

async function checkDuplicateCuaa() {
    const partyCuaaCheckRequest: Partial<PartyCUAACheckRequest> = {};
    if (registryForm.value.code) {
        partyCuaaCheckRequest.code = registryForm.value.code;
        !!regIdForm.value && (partyCuaaCheckRequest.id = regIdForm.value);
    } else {
        return false;
    }

    const res = await useApiResponseHandler(() => registryApi.getDuplicateCuaa(partyCuaaCheckRequest));
    return !!res?.duplicated;
}

async function fetchList() {
    const res = await useApiResponseHandler(() => registryApi.getRegistries(registryStore.search));

    if (res) {
        registryStore.setList(res);
    }
}

function dismissModal() {
    showDuplicatesModal.value = false;
}

function dismissCuaaModal() {
    showDuplicatedCuaaModal.value = false;
}

function dismissExternalSourcesErrorModal() {
    showExternalSourcesErrorModal.value = false;
}

async function confirmDuplicate() {
    await saveCallBack();
    dismissModal();
}

function onHiddenDuplicatesModal() {
    canGoToList.value && goToRegistryList();
}

const tobBarTitle = computed(() => {
    const ret: string[] = [];
    if (registryForm.value.partyType === PartyType.N) {
        const names: string[] = [];
        registryForm.value.lastName && names.push(registryForm.value.lastName);
        registryForm.value.firstName && names.push(registryForm.value.firstName);
        names.length > 0 && ret.push(names.join(" "));
        registryForm.value.taxCode && ret.push(registryForm.value.taxCode);
    }
    if (registryForm.value.partyType === PartyType.L) {
        registryForm.value.lastName && ret.push(registryForm.value.lastName);
        registryForm.value.vatNumber && ret.push(registryForm.value.vatNumber);
    }
    return ret.length ? ret.join(" - ") : "-";
});

/**
 * #134529 25/03/24
 * Open accordion
 */
function openAppordionHandler() {
    if (relationDataFieldsetAccordionRef.value) {
        const collapseEl = (relationDataFieldsetAccordionRef.value.$el as HTMLDivElement).querySelector(".collapse");
        if (collapseEl) {
            const collapse = window.bootstrap.Collapse.getInstance(collapseEl);
            if (collapse) {
                collapse.show();
            }
        }
    }
}

/**
 * #164897 06/03/25
 * VatNumber and LegalStatus custom config
 */
const { isLegalStatusHidden, isVatNumberHidden } = useRegistryFormConfigHelper(registryForm, regIdForm);
</script>
<template>
    <TopBar class="mb-4" :name="tobBarTitle" :archived="registryStore.currentDetail?.archived ?? null" />
    <form
        :id="formId"
        class="needs-validation party-registry-ui__registry-form"
        @submit.prevent="onSubmit"
        ref="registryFormRef"
        autocomplete="off"
    >
        <div class="row">
            <div class="form-group col-md-6">
                <div :id="groupIds.partyTypeGroup" v-if="registryForm.partyType && isPartyTypeEditable">
                    <BiRadiobutton
                        v-for="item of partyTypes"
                        :key="item.key"
                        :id="getUUID()"
                        :name="'partyType'"
                        :label="item.value"
                        :value="item.key"
                        is-inline
                        v-model="registryForm.partyType"
                        :validatorFn="onValidate"
                        :onchange="onChangePartyType"
                        :is-disabled="readOnlyFields?.partyType && !!registryForm.partyType"
                    />
                </div>
                <div class="" v-if="!!regIdForm && !isPartyTypeEditable">
                    <strong> {{ t(`${MODULE_ID}.registry.form.fields.partyType.label`) }} </strong>
                    <div class="ps-2">
                        {{ t(`${MODULE_ID}.registry.form.fields.partyTypeEnum.${registryForm.partyType}`) }}
                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="form-group" :class="registryForm.partyType === PartyType.N ? 'col-md-3' : 'col-md-4'">
                <BiTextInput
                    :id="getUUID()"
                    required
                    :name="'lastName'"
                    :label="lastNameLabel"
                    :validatorFn="onValidate"
                    :format-fn="toUppercase"
                    :is-readonly="isReadonly || (readOnlyFields?.lastName && !!registryForm.lastName)"
                    v-model="registryForm.lastName"
                />
            </div>
            <div class="form-group col-md-3" v-if="registryForm.partyType === PartyType.N">
                <BiTextInput
                    :id="getUUID()"
                    :required="registryForm.partyType === PartyType.N"
                    :name="'firstName'"
                    :label="t(`${MODULE_ID}.registry.form.fields.firstName`)"
                    :validatorFn="onValidate"
                    :format-fn="toUppercase"
                    :is-readonly="isReadonly || (readOnlyFields?.firstName && !!registryForm.firstName)"
                    v-model="registryForm.firstName"
                />
            </div>
            <div
                class="form-group"
                :class="registryForm.partyType === PartyType.N ? 'col-md-3' : 'col-md-4'"
                v-if="!isVatNumberHidden"
            >
                <BiTextInput
                    :id="getUUID()"
                    :required="registryForm.partyType === PartyType.L"
                    :name="'vatNumber'"
                    :label="t(`${MODULE_ID}.registry.form.fields.vatNumber.label`)"
                    :validatorFn="onValidate"
                    :is-readonly="isReadonly || (readOnlyFields?.vatNumber && !!registryForm.vatNumber)"
                    v-model="registryForm.vatNumber"
                />
            </div>
            <div class="form-group" :class="registryForm.partyType === PartyType.N ? 'col-md-3' : 'col-md-4'">
                <BiTextInput
                    :id="getUUID()"
                    :required="registryForm.partyType === PartyType.N"
                    :name="'taxCode'"
                    :label="t(`${MODULE_ID}.registry.form.fields.taxCode.label`)"
                    :validatorFn="onValidate"
                    :format-fn="toUppercase"
                    :is-readonly="isReadonly || (readOnlyFields?.taxCode && !!registryForm.taxCode)"
                    v-model="registryForm.taxCode"
                />
            </div>
        </div>

        <div class="row">
            <div class="form-group col-md-2" v-if="registryForm.partyType === PartyType.N">
                <BiSelect
                    v-if="!isReadonly"
                    :id="getUUID()"
                    name="gender"
                    :label="t(`${MODULE_ID}.registry.form.fields.gender.label`)"
                    :items="genders"
                    :validator-fn="onValidate"
                    v-model="registryForm.gender"
                    :disabled="readOnlyFields?.gender && !!registryForm.gender"
                ></BiSelect>
                <BiTextInput
                    v-if="isReadonly"
                    :id="getUUID()"
                    :name="'gender'"
                    :label="t(`${MODULE_ID}.registry.form.fields.gender.label`)"
                    :is-readonly="isReadonly || (readOnlyFields?.gender && !!registryForm.gender)"
                    :value="t(`${MODULE_ID}.registry.form.fields.genderEnum.` + registryForm.gender)"
                    v-model="registryForm.gender"
                />
            </div>
            <div class="form-group" :class="registryForm.partyType === PartyType.N ? 'col-md-8' : 'col-md-12'">
                <div class="row">
                    <div class="col">
                        <BiDatepicker
                            :id="getUUID()"
                            :max="MAX_BIRTH_DATE"
                            :validate-on-change="false"
                            :debounce-time="0"
                            :name="'birthDate'"
                            :label="birthDateLabel"
                            :validatorFn="onValidate"
                            :is-readonly="isReadonly || (readOnlyFields?.birthDate && !!birthDate)"
                            v-model="birthDate"
                        />
                    </div>
                    <div class="col">
                        <MunicipalityPickerInput
                            name="birthMunicipality"
                            :label="municipalityLabel"
                            :placeholder="municipalityPlaceholder"
                            :validatorFn="onValidate"
                            :disabled="
                                !!isReadonly || (readOnlyFields?.birthMunicipality && !!registryForm.birthMunicipality)
                            "
                            v-model="registryForm.birthMunicipality"
                        />
                    </div>
                </div>
            </div>
            <div class="form-group col-md-2" v-if="registryForm.partyType === PartyType.N">
                <BiTextInput
                    v-if="!isReadonly"
                    :id="getUUID()"
                    :label="t(`${MODULE_ID}.registry.form.fields.nationality.label`)"
                    name="nationality"
                    :item-title="'i18nCode'"
                    :item-value="'code'"
                    v-model="registryForm.nationality"
                    :validatorFn="onValidate"
                    :items="searchNationalityItems"
                    v-model:text="searchNationalityText"
                    :seamless="true"
                    :strict="true"
                    :is-readonly="readOnlyFields?.nationality"
                    :is-disabled="readOnlyFields?.nationality"
                    :disabled="readOnlyFields?.nationality"
                    list-height="400px"
                />
                <BiTextInput
                    v-else
                    :id="getUUID()"
                    :label="t(`${MODULE_ID}.registry.form.fields.nationality.label`)"
                    name="nationality"
                    :is-readonly="readOnlyFields?.nationality"
                    :disabled="isReadonly || readOnlyFields?.nationality"
                    :value="searchNationalityText"
                    v-model="registryForm.nationality"
                />
            </div>
        </div>

        <div class="row">
            <div v-if="canDisplayCuaa" class="form-group col-md-4">
                <BiTextInput
                    :id="getUUID()"
                    :name="'cuaa'"
                    :is-readonly="!isCuaaEditable || isReadonly || (readOnlyFields?.code && !!registryForm.code)"
                    :label="t(`${MODULE_ID}.registry.form.fields.cuaa.label`)"
                    :validatorFn="onValidate"
                    v-model="registryForm.code"
                />
            </div>
            <div class="form-group col-md-4">
                <BiDatepicker
                    :id="getUUID()"
                    :name="'deathDate'"
                    :validate-on-change="false"
                    :debounce-time="0"
                    :label="deathDateLabel"
                    :validatorFn="onValidate"
                    :is-readonly="isReadonly || readOnlyFields?.deathDate"
                    :is-disabled="isReadonly || readOnlyFields?.deathDate"
                    v-model="deathDate"
                />
            </div>
            <div class="form-group col-md-4">
                <BiTextInput
                    v-if="!!registryLegalStatustList.length && !isLegalStatusHidden"
                    :id="getUUID()"
                    :name="'legalStatus'"
                    :label="t(`${MODULE_ID}.registry.form.fields.legalStatus.label`)"
                    :items="registryLegalStatustList"
                    :validatorFn="onValidate"
                    item-title="i18nCode"
                    item-value="code"
                    v-model="registryForm.legalStatus"
                    v-model:text="searchLegalStatusText"
                    :seamless="true"
                    :strict="true"
                    list-height="400px"
                    :is-readonly="isReadonly || (readOnlyFields?.legalStatus && !!registryForm.legalStatus)"
                    :disabled="isReadonly || (readOnlyFields?.legalStatus && !!registryForm.legalStatus)"
                />
            </div>
        </div>

        <div class="mb-5">
            <BiAccordionGroup :group-id="accordionId">
                <BiAccordion
                    :is-disabled="!regIdForm"
                    :title="t(`${MODULE_ID}.registry.form.fields.addressResidential.label`)"
                >
                    <div class="pt-3">
                        <AddressFieldset
                            :validatorFn="onValidate"
                            v-model="registryForm.addressResidential"
                            :isDisabled="readOnlyFields?.addressResidential && !!registryForm.addressResidential"
                        />
                    </div>
                </BiAccordion>
                <BiAccordion
                    :is-disabled="!regIdForm"
                    :title="t(`${MODULE_ID}.registry.form.fields.addressHome.label`)"
                >
                    <AddressFieldset
                        :validatorFn="onValidate"
                        v-model="registryForm.addressHome"
                        :info-label="t(`${MODULE_ID}.registry.form.fields.addressResidential.differentInfo`)"
                        :show-denomination="true"
                        :show-warning="true"
                        :isDisabled="readOnlyFields?.addressHome && !!registryForm.addressHome"
                    />
                </BiAccordion>
                <BiAccordion
                    :is-disabled="!regIdForm"
                    :title="t(`${MODULE_ID}.registry.form.fields.addressBilling.label`)"
                >
                    <AddressFieldset
                        :validatorFn="onValidate"
                        v-model="registryForm.addressBilling"
                        :info-label="t(`${MODULE_ID}.registry.form.fields.addressResidential.differentInfo`)"
                        :show-denomination="true"
                        :show-warning="true"
                        :isDisabled="readOnlyFields?.addressBilling && !!registryForm.addressBilling"
                    />
                </BiAccordion>
                <BiAccordion :is-disabled="!regIdForm" :title="t(`${MODULE_ID}.registry.form.fields.contacts.label`)">
                    <ContactDataFieldset
                        v-if="regIdForm"
                        :validatorFn="onValidate"
                        :contact-list="registryContactList"
                        :show-load-more="!!contactListNextKey"
                        @load-more="loadMoreContacts"
                        @create-contact="onCreateContact"
                        @update-contact="onUpdateContact"
                        @delete-contact="onDeleteContact"
                    ></ContactDataFieldset>
                </BiAccordion>
                <BiAccordion
                    ref="relationDataFieldsetAccordionRef"
                    :is-disabled="!regIdForm"
                    :title="t(`${MODULE_ID}.registry.form.fields.relationType.label`)"
                >
                    <RelationTypeDataFieldset
                        v-if="regIdForm"
                        :validatorFn="onValidate"
                        :reg-id="regIdForm"
                        @reload="emit('reload')"
                        @open-accordion="openAppordionHandler"
                    ></RelationTypeDataFieldset>
                </BiAccordion>
                <BiAccordion :is-disabled="!regIdForm" :title="t(`${MODULE_ID}.registry.form.fields.tags.label`)">
                    <TagsFieldset v-if="regIdForm" :validatorFn="onValidate" v-model="registryForm.tags"></TagsFieldset>
                </BiAccordion>
            </BiAccordionGroup>
        </div>

        <div class="row" v-if="!isReadonly">
            <div v-if="!isLoading" class="col-md-6 offset-md-3 text-center">
                <!-- #133119 21/03/24 resetForm instead change route -->
                <BiButton color="primary" :is-outlined="true" @click="resetForm()" class="btn-me">
                    {{ t(`${COMMON_MODULE_ID}.general.cancel`) }}
                </BiButton>
                <BiButton type="submit" color="success" class="btn-me" v-if="regIdForm">
                    {{ t(`${COMMON_MODULE_ID}.general.saveChanges`) }}
                </BiButton>
                <BiButton type="submit" color="success" class="btn-me" v-if="!regIdForm">
                    {{ t(`${COMMON_MODULE_ID}.general.saveClose`) }}
                </BiButton>
                <BiButton v-if="isNextVersion" @click="onRefreshData" color="success">
                    {{ t(`${MODULE_ID}.registry.form.updateData`) }}
                </BiButton>
            </div>
            <div v-else class="d-flex w-100 justify-content-center">
                <BiProgressIndicator type="spinner"></BiProgressIndicator>
            </div>
            <div class="col-md-3 d-flex justify-content-end">
                <BiButton @click="onSave()" color="success" is-outlined is-icon v-if="!regIdForm">
                    {{ t(`${COMMON_MODULE_ID}.general.saveContinue`) }}
                    <BiIcon icon="arrow-right" size="sm" class="ms-1"></BiIcon>
                </BiButton>
            </div>
        </div>
    </form>
    <Teleport to="body">
        <BiModal
            ariaLabelledby="confirm-duplicate-registry"
            :id="getUUID()"
            v-model="showDuplicatesModal"
            :title="t(`${MODULE_ID}.registry.form.duplicateWarning.title`)"
            data-keyboard="false"
            data-backdrop="static"
            extra-body-class="pt-5"
            @hidden-modal="onHiddenDuplicatesModal"
        >
            <template #body>
                <div v-if="checkDuplicatesRes?.codiceFiscale && !checkDuplicatesRes?.partitaIva">
                    {{
                        t(`${MODULE_ID}.registry.form.duplicateWarning.taxCode`, {
                            taxCode: registryForm.taxCode,
                        })
                    }}
                </div>
                <div v-if="!checkDuplicatesRes?.codiceFiscale && checkDuplicatesRes?.partitaIva">
                    {{
                        t(`${MODULE_ID}.registry.form.duplicateWarning.vatNumber`, {
                            vatNumber: registryForm.vatNumber,
                        })
                    }}
                </div>
                <div v-if="checkDuplicatesRes?.codiceFiscale && checkDuplicatesRes?.partitaIva">
                    {{
                        t(`${MODULE_ID}.registry.form.duplicateWarning.taxCodeAndVatNumber`, {
                            taxCode: registryForm.taxCode,
                            vatNumber: registryForm.vatNumber,
                        })
                    }}
                </div>
            </template>
            <template #footer>
                <div class="text-center pt-5 pb-5 w-100">
                    <BiButton @click="dismissModal" :is-outlined="true" color="primary" class="btn-me">
                        {{ t(`${COMMON_MODULE_ID}.general.cancel`) }}
                    </BiButton>
                    <BiButton @click="confirmDuplicate" color="danger">
                        {{ t(`${COMMON_MODULE_ID}.general.confirm`) }}
                    </BiButton>
                </div>
            </template>
        </BiModal>
    </Teleport>
    <Teleport to="body">
        <BiModal
            ariaLabelledby="duplicate-cuaa"
            :id="getUUID()"
            v-model="showDuplicatedCuaaModal"
            :title="t(`${MODULE_ID}.registry.form.duplicateCuaaWarning.title`)"
            data-keyboard="false"
            data-backdrop="static"
            extra-body-class="pt-5"
        >
            <template #body>
                {{ t(`${MODULE_ID}.registry.form.duplicateCuaaWarning.message`) }}
            </template>
            <template #footer>
                <div class="text-center pt-5 pb-5 w-100">
                    <BiButton @click="dismissCuaaModal" :is-outlined="true" color="primary" class="btn-me">
                        {{ t(`${COMMON_MODULE_ID}.general.cancel`) }}
                    </BiButton>
                </div>
            </template>
        </BiModal>
    </Teleport>
    <Teleport to="body">
        <BiModal
            :disabled-teleport="true"
            :extra-footer-class="'justify-content-center'"
            v-model="showExternalSourcesErrorModal"
            :aria-labelledby="t(`${COMMON_MODULE_ID}.general.warning`)"
            :title="t(`${COMMON_MODULE_ID}.general.warning`)"
            :prevent-dismiss="true"
        >
            <template #body>
                <div class="col-12 mb-3">
                    <BiAlert isInfo>
                        <template #body>
                            {{ t(`${MODULE_ID}.registry.form.externalSourcesError`) }}
                        </template>
                    </BiAlert>
                </div>
            </template>
            <template #footer>
                <div class="d-flex justify-content-center w-100">
                    <BiButton
                        class="mx-1"
                        :class="getColor('button', 'secondary', 'outline')"
                        @click.stop="dismissExternalSourcesErrorModal"
                        >{{ t(`${COMMON_MODULE_ID}.general.close`) }}
                    </BiButton>
                </div>
            </template>
        </BiModal>
    </Teleport>
</template>

<style lang="scss" scoped>
.party-registry-ui {
    &__registry-form {
        .registry-form__input {
            margin-top: 1.2em;
        }
    }
}
</style>
