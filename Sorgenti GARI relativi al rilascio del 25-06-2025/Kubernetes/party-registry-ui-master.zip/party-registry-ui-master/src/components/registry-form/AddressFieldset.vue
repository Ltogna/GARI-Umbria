<script setup lang="ts">
import { MODULE_ID } from "@/constants";
import { MODULE_ID as COMMON_MODULE_ID } from "patri-common-ui/src/constants";
import type { Address } from "@/models/RegistryRequest";
import { getUUID } from "@abaco/bootstrap-italia-components/src/utilities";
import { BiTextInput, i18n } from "patri-common-ui/src";
import { computed, ref, watch } from "vue";

import MunicipalityPickerInput from "@/components/municipality-picker/MunicipalityPickerInput.vue";
import { useRegistryStore } from "@/stores/registry";
import usePermissions from "@/hooks/usePermissions";

const props = withDefaults(
    defineProps<{
        modelValue?: Address;
        showDenomination?: boolean;
        infoLabel?: string;
        showWarning?: boolean;
        validatorFn?: (id: string) => Promise<boolean>;
        isDisabled?: boolean;
    }>(),
    { showDenomination: false, showWarning: false },
);

const { t } = i18n.global;

const registryStore = useRegistryStore();
const addressDataForm = ref<Partial<Address>>({});
const { canWrite } = usePermissions();

const municipalityPlaceholder = computed(() =>
    [t(`${COMMON_MODULE_ID}.general.select`), t(`${MODULE_ID}.municipality.search.municipality`).toLowerCase()].join(
        " ",
    ),
);

const isReadonly = computed(() => registryStore.currentDetail?.archived || props?.isDisabled || !canWrite);

watch(
    () => props.modelValue,
    (value) => {
        if (value) {
            addressDataForm.value = value;
        }
    },
);

const emit = defineEmits<{
    (e: "update:modelValue", value: Partial<Address>): void;
}>();

watch(addressDataForm.value, (value) => {
    emit("update:modelValue", value);
});
</script>
<template>
    <div class="form-row small mb-5" v-if="infoLabel">
        {{ infoLabel }}
    </div>
    <div class="row">
        <div class="col-md-4 mb-4">
            <MunicipalityPickerInput
                name="addressMunicipality"
                :label="t(`${MODULE_ID}.registry.form.fields.address.municipality.label`)"
                :placeholder="municipalityPlaceholder"
                :validatorFn="validatorFn"
                :disabled="isReadonly"
                v-model="addressDataForm.municipality"
            />
        </div>
    </div>
    <div class="row">
        <div class="form-group col-md-4">
            <BiTextInput
                :id="getUUID()"
                name="addressLocality"
                :label="t(`${MODULE_ID}.registry.form.fields.address.locality.label`)"
                :validatorFn="validatorFn"
                :is-readonly="isReadonly"
                v-model="addressDataForm.locality"
            />
        </div>
        <div class="form-group col-md-2">
            <BiTextInput
                :id="getUUID()"
                name="addressPostcode"
                :label="t(`${MODULE_ID}.registry.form.fields.address.postcode.label`)"
                :validatorFn="validatorFn"
                :is-readonly="isReadonly"
                v-model="addressDataForm.postcode"
            />
        </div>
        <div class="form-group col-md-4">
            <BiTextInput
                :id="getUUID()"
                name="addressStreet"
                :label="t(`${MODULE_ID}.registry.form.fields.address.street.label`)"
                :validatorFn="validatorFn"
                :is-readonly="isReadonly"
                v-model="addressDataForm.street"
            />
        </div>
        <div class="form-group col-md-2">
            <BiTextInput
                :id="getUUID()"
                name="addressHouseNumber"
                :label="t(`${MODULE_ID}.registry.form.fields.address.houseNumber.label`)"
                :validatorFn="validatorFn"
                :is-readonly="isReadonly"
                v-model="addressDataForm.houseNumber"
            />
        </div>
    </div>
    <div class="row" v-if="showDenomination">
        <div class="form-group col-md-6">
            <BiTextInput
                :id="getUUID()"
                name="addressDenomination"
                :label="t(`${MODULE_ID}.registry.form.fields.address.denomination.label`)"
                :validatorFn="validatorFn"
                :is-readonly="isReadonly"
                v-model="addressDataForm.details"
            />
        </div>
    </div>
</template>
