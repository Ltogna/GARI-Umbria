<script setup lang="ts">
import { MODULE_ID } from "@/constants";
import { i18n } from "patri-common-ui/src";

const { t } = i18n.global;

defineProps<{
    name?: string;
    archived: boolean | null;
}>();
</script>

<template>
    <div class="collapse-header domande d-flex">
        {{ name }}
        <span class="ms-auto" v-if="typeof archived === 'boolean'">
            {{ t(archived ? `${MODULE_ID}.registry.state_archived_f` : `${MODULE_ID}.registry.state_active_f`) }}
        </span>
    </div>
</template>

<style scoped lang="scss">
.collapse-header.domande {
    border-top: 1px solid var(--bs-primary);
    border-bottom: 1px solid var(--bs-primary);
    background-color: var(--bs-primary);
    color: white;
    font-weight: 500;
    padding-left: 20px;
}

.collapse-header {
    padding: 10px;
}
.collapse-header {
    border-bottom: 1px solid #e3e4e6;
    border-top: 0px solid #e3e4e6;
}
.collapse-header {
    color: var(--text-color);
}

.collapse-header {
    position: relative;
}
</style>
