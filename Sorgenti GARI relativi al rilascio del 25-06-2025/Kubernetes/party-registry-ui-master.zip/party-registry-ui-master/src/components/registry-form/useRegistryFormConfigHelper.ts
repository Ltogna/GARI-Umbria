import { PartyType, type RegistryRequest } from "@/models/RegistryRequest";
import { computed, watch, type Ref, type ComputedRef } from "vue";
import { JSONPath } from "jsonpath-plus";
import { useConfigurationStore } from "@/stores/configuration";
import * as _ from "lodash";

type StrictPartyTypeValues = "N" | "L";

export function useRegistryFormConfigHelper(
    registryForm: Ref<Partial<RegistryRequest>>,
    regIdForm: ComputedRef<number | null>,
) {
    const configurationStore = useConfigurationStore();

    const isLegalStatusHidden = computed(() =>
        registryForm.value.partyType && configurationStore.legal_status
            ? !!configurationStore.legal_status?.configuration?.hidden?.[registryForm.value.partyType?.toString()]
            : false,
    );

    const hasVatNumberDefault = computed(() =>
        registryForm.value.partyType && configurationStore.vat_number
            ? !!configurationStore.vat_number?.configuration?.default?.[registryForm.value.partyType?.toString()]
            : false,
    );

    const hasLegalStatusDefault = computed(() =>
        registryForm.value.partyType && configurationStore.legal_status
            ? !!configurationStore.legal_status?.configuration?.default?.[registryForm.value.partyType?.toString()]
            : false,
    );

    const isVatNumberHidden = computed(() =>
        registryForm.value.partyType && configurationStore.vat_number
            ? !!configurationStore.vat_number?.configuration?.hidden?.[registryForm.value.partyType?.toString()]
            : false,
    );

    watch(
        [() => registryForm.value.partyType, () => registryForm.value],
        ([partyType, registryForm]) => {
            !regIdForm.value &&
                partyType &&
                registryForm &&
                setDefaultValues(partyType.toString() as StrictPartyTypeValues);
        },
        { deep: true, immediate: true },
    );

    watch(
        [() => registryForm.value.taxCode, () => registryForm.value],
        ([taxCode, registryForm]) => {
            taxCode && registryForm && updateVatNumber();
        },
        { deep: true, immediate: true },
    );

    function updateVatNumber() {
        if (registryForm.value.partyType === PartyType.L) {
            configurationStore.vat_number?.configuration?.default?.L &&
                (registryForm.value.vatNumber = getDefaultValue(
                    configurationStore.vat_number?.configuration?.default?.L,
                ));
        }
    }

    function setDefaultValues(partyTypeKey: StrictPartyTypeValues) {
        hasLegalStatusDefault.value &&
            (registryForm.value.legalStatus = getDefaultValue(
                configurationStore.legal_status?.configuration?.default?.[partyTypeKey],
            ));
        hasVatNumberDefault.value &&
            (registryForm.value.vatNumber = getDefaultValue(
                configurationStore.vat_number?.configuration?.default?.[partyTypeKey],
            ));
    }

    function getDefaultValue(conf: boolean | string | number | undefined) {
        if (!conf) return undefined;

        if (_.startsWith(conf.toString(), "$")) {
            return JSONPath({
                path: conf as string,
                json: registryForm.value,
            })[0];
        }

        return conf as string;
    }
    return { isLegalStatusHidden, isVatNumberHidden };
}
