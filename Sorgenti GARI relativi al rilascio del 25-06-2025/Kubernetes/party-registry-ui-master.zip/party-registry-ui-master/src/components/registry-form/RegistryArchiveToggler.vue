<script setup lang="ts">
import { computed, inject, ref } from "vue";

import { i18n } from "patri-common-ui/src";
import BiButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiButton.vue";
import BiModal from "@abaco/bootstrap-italia-components/src/components/BiModal/BiModal.vue";
import { getUUID } from "@abaco/bootstrap-italia-components/src/utilities/index";

import type RegistryApi from "@/api/registry-api";
import { useApiResponseHandler } from "@/index";
import { MODULE_ID } from "@/constants";
import { MODULE_ID as COMMON_MODULE_ID } from "patri-common-ui/src/constants";

const { t } = i18n.global;

const registryApi: RegistryApi = inject("registryApi") as RegistryApi;
const props = defineProps<{
    isArchived?: boolean;
    regId: number;
}>();

const showModal = ref<boolean>(false);

const emit = defineEmits<{
    (e: "statusUpdated", isArchived: boolean): void;
}>();

const btnLabel = computed(() => {
    return props.isArchived ? t(`${MODULE_ID}.registry.form.unarchive`) : t(`${MODULE_ID}.registry.form.archive`);
});

async function toggleArchiveRegistry() {
    if (props.isArchived) {
        await registryApi.unarchiveRegistry(props.regId);
        emit("statusUpdated", true);
    } else {
        showModal.value = true;
    }
}
async function confirmArchvive() {
    await useApiResponseHandler(() => registryApi.archiveRegistry(props.regId));
    dismissModal();
    emit("statusUpdated", false);
}
function dismissModal() {
    showModal.value = false;
}
</script>
<template>
    <BiButton @click="toggleArchiveRegistry" :is-outlined="true" :color="isArchived ? 'success' : 'danger'">
        {{ btnLabel }}
    </BiButton>
    <Teleport to="body">
        <BiModal
            ariaLabelledby="confirm-archive-registry"
            :id="getUUID()"
            v-model="showModal"
            :title="t(`${MODULE_ID}.registry.form.archive`)"
            data-keyboard="false"
            data-backdrop="static"
            extra-body-class="pt-5"
        >
            <template #body>
                {{ t(`${MODULE_ID}.registry.form.archiveMessage`) }}
            </template>
            <template #footer>
                <div class="text-center pt-5 pb-5 w-100">
                    <BiButton @click="dismissModal" :is-outlined="true" color="primary" class="btn-me">
                        {{ t(`${COMMON_MODULE_ID}.general.cancel`) }}
                    </BiButton>
                    <BiButton @click="confirmArchvive" color="danger">
                        {{ t(`${MODULE_ID}.registry.form.confirmArchiveBtn`) }}
                    </BiButton>
                </div>
            </template>
        </BiModal>
    </Teleport>
</template>
