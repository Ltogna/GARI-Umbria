<script setup lang="ts">
import { ref } from "vue";
import BiAccordion from "@abaco/bootstrap-italia-components/src/components/BiAccordion/BiAccordion.vue";
import type { AccordionSidebarItem } from "../registry-form/formSidebarConfig";
import type { RouteLocationNamedRaw } from "vue-router";

defineProps<{
    modelValue?: boolean;
    headerText: string;
    formSidebarRouteConfig: Record<string, RouteLocationNamedRaw>;
    accordionItems: AccordionSidebarItem[];
}>();

const emit = defineEmits<{
    (e: "update:modelValue", value: unknown): void;
}>();

const isAccordionOpen = ref(true);
</script>

<template>
    <div class="pb-3">
        <BiAccordion
            :modelValue="isAccordionOpen"
            @update:modelValue="(value: unknown) => emit('update:modelValue', value)"
            colorBgHeader="primary"
            colorHeader="white"
            bodyExtraClass="p-0"
            header-extra-class="d-block text-truncate"
        >
            <template #header>
                {{ headerText }}
            </template>
            <slot>
                <div class="it-list-wrapper">
                    <ul class="it-list border">
                        <li v-for="{ path, text } in accordionItems" :key="path">
                            <div class="border-bottom-0 text-secondary">
                                <RouterLink
                                    replace
                                    :to="formSidebarRouteConfig[path!]"
                                    :class="'text-decoration-none px-2 py-2 d-block'"
                                    :exact-active-class="'primary-bg-a1 text-black'"
                                >
                                    <span>{{ text }}</span>
                                </RouterLink>
                            </div>
                        </li>
                    </ul>
                </div>
            </slot>
        </BiAccordion>
    </div>
</template>
