<script setup lang="ts">
import { SIDEBAR_OTHERS_GROUP_CODE } from "@/constants";
import { computed } from "vue";
import type { RouteLocationNamedRaw } from "vue-router";
import type { AccordionSidebarConfig } from "../registry-form/formSidebarConfig";
import AccordionSidebarItem from "./AccordionSidebarItem.vue";

const props = defineProps<{
    formSidebarConfig: AccordionSidebarConfig;
    formSidebarRouteConfig: Record<string, RouteLocationNamedRaw>;
}>();

const accordionListConfig = computed(() =>
    Object.keys(props.formSidebarConfig)
        .filter((key) => key !== SIDEBAR_OTHERS_GROUP_CODE)
        .reduce((acc, item) => {
            acc[item] = props.formSidebarConfig[item];
            return acc;
        }, {} as AccordionSidebarConfig),
);
</script>
<template>
    <div class="AccordionSidebar">
        <AccordionSidebarItem
            v-for="(item, key) in accordionListConfig"
            :key="key"
            :header-text="item.headerText"
            :form-sidebar-route-config="formSidebarRouteConfig"
            :accordion-items="item.items"
        />

        <div class="it-list-wrapper" v-if="formSidebarConfig?.others?.items">
            <ul class="it-list border">
                <li v-for="{ path, text } in formSidebarConfig.others.items" :key="path">
                    <div class="border-bottom-0 text-secondary">
                        <RouterLink
                            replace
                            :to="formSidebarRouteConfig[path!]"
                            :class="'text-decoration-none px-2 py-2 d-block'"
                            :exact-active-class="'primary-bg-a1 text-black'"
                        >
                            <span>{{ text }}</span>
                        </RouterLink>
                    </div>
                </li>
            </ul>
        </div>
    </div>
</template>
