<script setup lang="ts">
import usePermissions from "@/hooks/usePermissions";
import type { PartyDocumentResponse } from "@/models/dynamic-document/DynamicDocumentResponse";
import BiButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiButton.vue";
import BiIcon from "@abaco/bootstrap-italia-components/src/components/BiIcon/BiIcon.vue";
import DocumentBuilder from "@abaco/dynamic-documents/src/components/DocumentBuilder.vue";
import type { FileUploadConfig } from "@abaco/dynamic-documents/src/resources/composables/useFiles";
import type { DocumentSchemaType } from "@abaco/dynamic-documents/src/resources/models";
import type { DocumentDataDocSchemaType } from "@abaco/dynamic-documents/src/resources/models/document";
import { getUserData } from "@abaco/safe-rest/src/sso2";
import type { InsertDocument, ModalModeEnum } from "patri-common-ui/src";
import { i18n } from "patri-common-ui/src";
import { MODULE_ID as COMMON_MODULE_ID } from "patri-common-ui/src/constants";
import { computed, onMounted, ref, watch } from "vue";

const { t, locale } = i18n.global;
const VITE_TENANT = import.meta.env.VITE_TENANT as string;

const props = withDefaults(
    defineProps<{
        partyId: number;
        multiple?: boolean;
        mode: ModalModeEnum;
        modelValue?: PartyDocumentResponse;
        docDefinition: DocumentSchemaType;
    }>(),
    { multiple: false },
);

const emit = defineEmits<{
    (e: "form-reset"): void;
    (e: "create-document", value: InsertDocument): void;
    (e: "update-document", value: PartyDocumentResponse): void;
    (e: "delete-document", value: PartyDocumentResponse): void;
}>();

const formValues = ref<DocumentDataDocSchemaType>();
const isValid = ref(false);
const language = ref(locale.value);
const showErrors = ref(false);
const formConfirmBtn = computed(() =>
    props.mode === "EDIT"
        ? t(`${COMMON_MODULE_ID}.dynamic-docs.form.updateConfirm`)
        : t(`${COMMON_MODULE_ID}.general.save`),
);
const isLoading = ref<boolean>(false);
const { canWrite } = usePermissions();
const isReadonly = computed(() => !canWrite || checkDDReadonly.value);

// TODO temp patch -> remove and find another solution
const checkDDReadonly = computed(() => {
    return (
        props.docDefinition &&
        (props.docDefinition.code === "ACTIVITY_DETAIL" || props.docDefinition.code === "VAT_NUMBER_DETAIL")
    );
});

watch(
    () => props.modelValue,
    (value) => {
        formValues.value = { ...formValues.value, fields: { ...value?.data } };
    },
    { immediate: true },
);

onMounted(() => {
    isLoading.value = true;
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    formValues.value = { fields: props.modelValue?.data ? (props.modelValue?.data as any) : null };
    isLoading.value = false;
});

function formReset() {
    emit("form-reset");
}
function formConfirm() {
    const modalActions = {
        NEW: () => emit("create-document", mapCreateRequest()),
        EDIT: () => emit("update-document", mapRequest()),
        DELETE: () => onDeleteDocument(),
    };

    showErrors.value = !isValid.value;

    if (isValid.value) {
        modalActions[props.mode]();
    }
}
function mapCreateRequest() {
    return {
        defCode: props.docDefinition.code,
        label: "", // TODO: which value?
        businessId: props.partyId,
        doc: {
            ...formValues.value,
        },
    } as InsertDocument;
}
function mapRequest() {
    if (!formValues.value) {
        return {} as PartyDocumentResponse;
    }
    return {
        ...props.modelValue,
        data: {
            ...(formValues.value.fields as Record<string, unknown>),
        },
    } as PartyDocumentResponse;
}
function onDeleteDocument() {
    emit("delete-document", mapRequest());
}

const fileUploadConfigComputed = computed<FileUploadConfig | undefined>(() => {
    const { VITE_REGISTRY_SERVICE } = import.meta.env;
    const tenant = getUserData()?.tenant ?? VITE_TENANT;
    const partyId = props.partyId;
    const definitionCode = props.modelValue?.definitionCode;
    const documentId = props.modelValue?.documentId;
    const bucketName = props.docDefinition.bucketName;
    const hasDocumentConfig = !!bucketName && !!definitionCode && !!documentId;
    return {
        bucketName: bucketName as string,
        readUrl: hasDocumentConfig
            ? `/${VITE_REGISTRY_SERVICE}/${tenant}/api-priv/v1/parties/${partyId}/documents/type/${definitionCode}/${documentId}/attachments`
            : "",
        tenantId: tenant,
    };
});
</script>
<template>
    <DocumentBuilder
        v-if="docDefinition?.fieldSets && !isLoading"
        v-model="formValues"
        v-model:lang="language"
        :schema="docDefinition"
        :show-errors="showErrors"
        doc-title-hide
        :file-upload-config="fileUploadConfigComputed"
        :readonly="mode === 'DELETE' || isReadonly"
        @update:valid="(value) => (isValid = value)"
        @update:model-value="
            (value: any) => {
                formValues = value;
            }
        "
    />
    <!-- TEST ONLY -->
    <!-- <hr />
    {{ docDefinition }}
    <hr />
    {{ formValues }}
    <hr />
    {{ isValid }} -->
    <div class="text-center mt-4 pb-5">
        <template v-if="multiple">
            <BiButton v-if="!isReadonly" @click="formReset" is-outlined color="primary" class="btn-me">
                {{ t(`${COMMON_MODULE_ID}.general.cancel`) }}
            </BiButton>
            <BiButton v-if="mode === 'DELETE' && !isReadonly" @click="onDeleteDocument" color="danger">
                {{ t(`${COMMON_MODULE_ID}.dynamic-docs.form.deleteConfirm`) }}
            </BiButton>
            <BiButton v-else-if="!isReadonly" @click="formConfirm" color="success">
                {{ formConfirmBtn }}
            </BiButton>
        </template>
        <template v-else>
            <BiButton
                v-if="mode !== 'NEW' && !isReadonly"
                @click="onDeleteDocument"
                color="danger"
                class="btn-me"
                is-icon
            >
                <BiIcon icon="trash-can" size="sm" class="me-1"></BiIcon>
                {{ t(`${COMMON_MODULE_ID}.dynamic-docs.form.delete`) }}
            </BiButton>
            <BiButton v-if="!isReadonly" @click="formConfirm" color="success" is-icon>
                <BiIcon icon="pencil" size="sm" class="me-1"></BiIcon>
                {{ t(`${COMMON_MODULE_ID}.dynamic-docs.form.updateSave`) }}
            </BiButton>
        </template>
    </div>
</template>
