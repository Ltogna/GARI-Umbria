<script setup lang="ts">
import type { PartyDocumentResponse } from "@/models/dynamic-document/DynamicDocumentResponse";
import type { DocTypeResponse } from "patri-common-ui/src";
import { i18n } from "patri-common-ui/src";
import { computed, inject, ref } from "vue";

import { getUUID } from "@abaco/bootstrap-italia-components/src/utilities/index";

import BiButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiButton.vue";
import BiIcon from "@abaco/bootstrap-italia-components/src/components/BiIcon/BiIcon.vue";
import BiModal from "@abaco/bootstrap-italia-components/src/components/BiModal/BiModal.vue";
import BiTable from "@abaco/bootstrap-italia-components/src/components/BiTable/BiTable.vue";

import type DynamicDocumentApi from "@/api/dynamic-document-api";
import type { DocumentSchemaType } from "@abaco/dynamic-documents/src/resources/models";
import moment from "moment";
import type { InsertDocument } from "patri-common-ui/src";
import { ModalModeEnum } from "patri-common-ui/src";
import { useApiResponseHandler } from "@/index";
import DynamicDocumentForm from "./DynamicDocumentForm.vue";
import { MODULE_ID as COMMON_MODULE_ID } from "patri-common-ui/src/constants";
import useColors from "@abaco/bootstrap-italia-components/src/composables/useColors";
import usePermissions from "@/hooks/usePermissions";

const { canWrite } = usePermissions();
const isReadonly = computed(() => !canWrite);

const props = withDefaults(
    defineProps<{
        partyId: number;
        documentList: PartyDocumentResponse[];
        docType: DocTypeResponse;
        docDefinition: DocumentSchemaType;
        showLoadMore?: boolean;
    }>(),
    { showLoadMore: false },
);

const emit = defineEmits<{
    (e: "load-more"): void;
    (e: "create-document", value: InsertDocument): void;
    (e: "update-document", value: PartyDocumentResponse): void;
    (e: "delete-document", value: PartyDocumentResponse): void;
}>();

const { t } = i18n.global;

const dynamicDocumentApi: DynamicDocumentApi = inject("dynamicDocumentApi") as DynamicDocumentApi;

const currentDocument = ref<PartyDocumentResponse>();
const showModal = ref(false);
const modalMode = ref(ModalModeEnum.NEW);

const { getColor } = useColors();

const modalTitle = computed(() => {
    if (modalMode.value === ModalModeEnum.NEW) {
        return [t(`${COMMON_MODULE_ID}.general.new`, 2), props.docType.i18nDocType?.toLowerCase()].join(" ");
    }
    if (modalMode.value === ModalModeEnum.EDIT) {
        return [t(`${COMMON_MODULE_ID}.general.edit`), props.docType.i18nDocType?.toLowerCase()].join(" ");
    }
    if (modalMode.value === ModalModeEnum.DELETE) {
        return [t(`${COMMON_MODULE_ID}.general.delete`), props.docType.i18nDocType?.toLowerCase()].join(" ");
    }
    return "";
});
const fieldDefinitions = computed(() => props.docType.summaryFieldDefinitions);

function newDocument(): void {
    currentDocument.value = undefined;
    modalMode.value = ModalModeEnum.NEW;
    showModal.value = true;
}
async function editDocument(document: PartyDocumentResponse) {
    await fetchCurrentDocument(document.documentId);
    modalMode.value = ModalModeEnum.EDIT;
    showModal.value = true;
}
async function deleteDocument(document: PartyDocumentResponse) {
    await fetchCurrentDocument(document.documentId);
    modalMode.value = ModalModeEnum.DELETE;
    showModal.value = true;
}
async function fetchCurrentDocument(docId: number) {
    const res = await useApiResponseHandler<PartyDocumentResponse>(() =>
        dynamicDocumentApi.getPartyDocumentById(props.partyId, props.docType.docType, docId),
    );

    if (res) {
        currentDocument.value = res;
    } else {
        currentDocument.value = undefined;
    }
}
function loadMore() {
    emit("load-more");
}
function onCreateDocument(documentData: InsertDocument) {
    emit("create-document", documentData);
    showModal.value = false;
}
function onUpdateDocument(documentData: PartyDocumentResponse) {
    emit("update-document", documentData);
    showModal.value = false;
}
function onDeleteDocument(documentData: PartyDocumentResponse) {
    emit("delete-document", documentData);
    showModal.value = false;
}
function dismissModal() {
    showModal.value = false;
    currentDocument.value = undefined;
}
function formatField(fieldCode: string, doc: PartyDocumentResponse) {
    const fieldType = doc.summaryFieldDefinitions?.find((it) => it.code === fieldCode)?.fieldType || "string";
    const fieldValue = doc.data[fieldCode];
    if (fieldType === "date") {
        return moment(fieldValue).format("DD/MM/YYYY");
    }
    return fieldValue;
}
</script>
<template>
    <BiTable class="table mb-0" extraTableClasses="table-head-bg" is-row-hover isResponsive>
        <template #head>
            <tr class="bg-light" :class="getColor('text', 'secondary')">
                <th
                    scope="col"
                    v-for="(item, i) in fieldDefinitions"
                    :key="i"
                    :class="{ 'text-center': item.fieldType === 'file' }"
                >
                    {{ item.description }}
                </th>
                <th></th>
            </tr>
        </template>
        <template #body>
            <tr v-for="(doc, trIndex) in documentList" :key="trIndex">
                <td
                    v-for="(field, tdIndex) in fieldDefinitions"
                    :key="tdIndex"
                    :class="{ 'text-center': field.fieldType === 'file' && doc.data[field.code] }"
                >
                    <BiIcon v-if="field.fieldType === 'file' && doc.data[field.code]" icon="check" />
                    <span v-else>{{ formatField(field.code, doc) }}</span>
                </td>
                <td class="text-end">
                    <BiButton
                        size="xs"
                        :color="!isReadonly ? 'success' : 'primary'"
                        is-outlined
                        is-icon
                        :width="40"
                        :height="38"
                        class="btn-me"
                        @click="editDocument(doc)"
                    >
                        <BiIcon :icon="!isReadonly ? 'pencil' : 'eye'"></BiIcon>
                    </BiButton>
                    <BiButton
                        v-if="!isReadonly"
                        size="xs"
                        color="danger"
                        is-outlined
                        is-icon
                        :width="40"
                        :height="38"
                        @click="deleteDocument(doc)"
                    >
                        <BiIcon icon="trash-can"></BiIcon>
                    </BiButton>
                </td>
            </tr>
        </template>
    </BiTable>
    <div class="d-flex justify-content-end mb-4" v-if="showLoadMore">
        <BiButton :is-outlined="true" color="primary" @click="loadMore">
            {{ t(`${COMMON_MODULE_ID}.general.loadMore`) }}
        </BiButton>
    </div>
    <div class="col-md-12 mt-4 text-center">
        <BiButton v-if="!isReadonly" :is-outlined="true" color="primary" @click="newDocument">
            {{ t(`${COMMON_MODULE_ID}.general.new`, 2) }} {{ docType.i18nDocType?.toLowerCase() }}
        </BiButton>
    </div>
    <Teleport to="body">
        <BiModal
            size="lg"
            ariaLabelledby="new-contact"
            :id="getUUID()"
            v-model="showModal"
            :title="modalTitle"
            data-keyboard="false"
            data-backdrop="static"
            extra-body-class="pt-5"
        >
            <template #body>
                <DynamicDocumentForm
                    v-if="showModal"
                    :party-id="partyId"
                    v-model="currentDocument"
                    multiple
                    :mode="modalMode"
                    :docDefinition="docDefinition"
                    @form-reset="dismissModal"
                    @create-document="onCreateDocument"
                    @update-document="onUpdateDocument"
                    @delete-document="onDeleteDocument"
                />
            </template>
        </BiModal>
    </Teleport>
</template>
