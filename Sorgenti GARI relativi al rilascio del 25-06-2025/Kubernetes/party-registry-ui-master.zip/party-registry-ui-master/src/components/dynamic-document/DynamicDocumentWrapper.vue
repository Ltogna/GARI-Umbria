<script setup lang="ts">
import type DynamicDocumentApi from "@/api/dynamic-document-api.js";
import type {
    PartyDocumentResponse,
    PartyDocumentResponseList,
} from "@/models/dynamic-document/DynamicDocumentResponse";
import type { DocumentSchemaType } from "@abaco/dynamic-documents/src/resources/models";
import type { DocTypeResponse, InsertDocument } from "patri-common-ui/src";
import { i18n, ModalModeEnum, useDynamicDocsStore } from "patri-common-ui/src";
import { useApiResponseHandler, useApiDeleteHandler } from "@/index";
import { computed, inject, onMounted, ref, watch, watchEffect } from "vue";
import { useRouter, type RouteParams } from "vue-router";
import DynamicDocumentForm from "./DynamicDocumentForm.vue";
import DynamicDocumentList from "./DynamicDocumentList.vue";

import BiButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiButton.vue";
import BiModal from "@abaco/bootstrap-italia-components/src/components/BiModal/BiModal.vue";
import { getUUID } from "@abaco/bootstrap-italia-components/src/utilities";
import { MODULE_ID as COMMON_MODULE_ID } from "patri-common-ui/src/constants";

defineEmits<{
    reload: [];
}>();

const { t } = i18n.global;
const router = useRouter();
const dynamicDocStore = useDynamicDocsStore<PartyDocumentResponseList, PartyDocumentResponse>();

const dynamicDocumentApi: DynamicDocumentApi = inject("dynamicDocumentApi") as DynamicDocumentApi;

const regId = ref<number>();
const docTypeCode = ref<string>();
const docType = ref<DocTypeResponse>();
const currentDocument = ref<PartyDocumentResponse>();
const showModal = ref<boolean>(false);
const modalMode = ref<ModalModeEnum>(ModalModeEnum.EDIT);
const processingDocument = ref<PartyDocumentResponse>();
const isLoading = ref<boolean>(false);

const nextKey = computed(() => dynamicDocStore.getDocumentFullPage.nextKey || undefined);
const currentList = computed(() => dynamicDocStore.getDocumentFullPage.records);
const currentDefinition = computed(() => dynamicDocStore.currentDefinition);
const cofirmModalTitle = computed(() => {
    if (modalMode.value === ModalModeEnum.DELETE) {
        return [t(`${COMMON_MODULE_ID}.dynamic-docs.form.deleteConfirm`), docType.value?.i18nDocType].join(" ");
    }
    if (modalMode.value === ModalModeEnum.EDIT) {
        return [t(`${COMMON_MODULE_ID}.dynamic-docs.form.updateConfirm`), docType.value?.i18nDocType].join(" ");
    }
    return "";
});

watch(router.currentRoute, ({ params }) => {
    initFromRouteParams(params);
});
watchEffect(() => {
    if (docTypeCode.value) {
        docType.value = dynamicDocStore.getDocType(docTypeCode.value);
    }
});
watch(docTypeCode, async (oldValue, newValue) => {
    isLoading.value = true;
    if (oldValue !== newValue) {
        await fetchCurrentDocuments();
        await fetchDocumentSchema();
    }
    isLoading.value = false;
});

watch([currentList, docType], async ([list, dType]) => {
    currentDocument.value = undefined;
    const doc = list && list.length > 0 ? list[0] : null;
    if (doc) {
        // sets all the variables that will later be evaluated
        const documentId = doc.documentId;
        const partyId = doc.partyId;
        const definitionCode = doc.definitionCode;
        const docType = dType?.docType;
        if (dType && !dType.multiple && definitionCode === docType) {
            await fetchCurrentDocument(partyId, dType.docType, documentId);
        }
    }
});

onMounted(async () => {
    initFromRouteParams(router.currentRoute.value.params);
});

function initFromRouteParams(params: RouteParams) {
    regId.value = params["regId"] ? +params["regId"] : undefined;
    docTypeCode.value = (params["docType"] as string) ?? null;
}
async function fetchCurrentDocuments() {
    const rId = regId.value;
    const dType = docTypeCode.value;

    if (!rId || !dType) {
        return;
    }

    const currentDocuments = await useApiResponseHandler<PartyDocumentResponseList>(() =>
        dynamicDocumentApi.getPartyDocumentsByType(rId, dType),
    );

    if (currentDocuments) {
        dynamicDocStore.setList(currentDocuments);
    }
}
async function fetchCurrentDocument(rId: number, dType: string, docId: number) {
    const res = await useApiResponseHandler<PartyDocumentResponse>(() =>
        dynamicDocumentApi.getPartyDocumentById(rId, dType, docId),
    );

    if (res) {
        currentDocument.value = res;
    } else {
        currentDocument.value = undefined;
    }
}
async function onLoadMore() {
    const rId = regId.value;
    const dType = docTypeCode.value;

    if (!rId || !dType) {
        return;
    }
    const res = await useApiResponseHandler(() =>
        dynamicDocumentApi.getPartyDocumentsByType(rId, dType, nextKey.value),
    );
    if (res) {
        dynamicDocStore.incrementList(res);
    }
}
async function fetchDocumentSchema() {
    const rId = regId.value;
    const dType = docTypeCode.value;

    if (!rId || !dType) {
        return;
    }
    const res = await useApiResponseHandler(() => dynamicDocumentApi.getDocumentDefinition(rId, dType));
    if (res) {
        dynamicDocStore.setCurrentDefinition(res);
    }
}
async function onCreateDocument(documentData: InsertDocument) {
    const res = await useApiResponseHandler(() => dynamicDocumentApi.createDocument(documentData));
    if (res) {
        await fetchCurrentDocuments();
    }
}
async function onUpdateDocument(documentData: PartyDocumentResponse) {
    const res = await useApiResponseHandler(() => dynamicDocumentApi.updateDocument(documentData));
    if (res) {
        await fetchCurrentDocuments();
    }
    showModal.value = false;
}
async function onDeleteDocument(documentData: PartyDocumentResponse) {
    const res = await useApiDeleteHandler(() =>
        dynamicDocumentApi.deleteDocument(documentData.partyId, documentData.definitionCode, documentData.documentId),
    );
    if (res) {
        currentDocument.value = undefined;
        await fetchCurrentDocuments();
    }
}
function onConfirmUpdate(documentData: PartyDocumentResponse) {
    processingDocument.value = documentData;
    modalMode.value = ModalModeEnum.EDIT;
    showModal.value = true;
}
function onConfirmDelete(documentData: PartyDocumentResponse) {
    processingDocument.value = documentData;
    modalMode.value = ModalModeEnum.DELETE;
    showModal.value = true;
}
function dismissModal() {
    processingDocument.value = undefined;
    showModal.value = false;
}
async function confirmAction() {
    if (modalMode.value === ModalModeEnum.DELETE && processingDocument.value) {
        await onDeleteDocument(processingDocument.value);
        showModal.value = false;
        processingDocument.value = undefined;
    }
    if (modalMode.value === ModalModeEnum.EDIT && processingDocument.value) {
        await onUpdateDocument(processingDocument.value);
        showModal.value = false;
        processingDocument.value = undefined;
    }
}

// update deprecated vue v3 @vnode-* in @vue:*
function onDynamicDocumentListUnmounted() {
    dynamicDocStore.setCurrentDefinition({} as DocumentSchemaType);
}
</script>
<template>
    <template v-if="docType && currentList && regId && !isLoading">
        <DynamicDocumentList
            v-if="docType.multiple"
            :partyId="regId"
            :documentList="currentList"
            :docType="docType"
            :docDefinition="currentDefinition"
            :show-load-more="!!nextKey"
            @load-more="onLoadMore"
            @create-document="onCreateDocument"
            @update-document="onUpdateDocument"
            @delete-document="onDeleteDocument"
            @vue:unmounted="onDynamicDocumentListUnmounted"
        />
        <DynamicDocumentForm
            v-else
            :mode="!currentDocument ? ModalModeEnum.NEW : ModalModeEnum.EDIT"
            :docDefinition="currentDefinition"
            :partyId="regId"
            v-model="currentDocument"
            @create-document="onCreateDocument"
            @update-document="onConfirmUpdate"
            @delete-document="onConfirmDelete"
        />
        <Teleport to="body">
            <BiModal
                size="lg"
                ariaLabelledby="confirm-modal-document"
                :id="getUUID()"
                v-model="showModal"
                :title="cofirmModalTitle"
                data-keyboard="false"
                data-backdrop="static"
                extra-body-class="pt-5"
            >
                <template #body>
                    {{ t(`${COMMON_MODULE_ID}.dynamic-docs.form.confirmMessage.` + modalMode) }}
                </template>
                <template #footer>
                    <div class="text-center pt-5 pb-5 w-100">
                        <BiButton @click="dismissModal" is-outlined color="primary" class="btn-me">
                            {{ t(`${COMMON_MODULE_ID}.general.cancel`) }}
                        </BiButton>
                        <BiButton v-if="modalMode === 'DELETE'" @click="confirmAction" color="danger">
                            {{ t(`${COMMON_MODULE_ID}.dynamic-docs.form.deleteConfirm`) }}
                        </BiButton>
                        <BiButton v-if="modalMode === 'EDIT'" @click="confirmAction" color="success">
                            {{ t(`${COMMON_MODULE_ID}.dynamic-docs.form.updateConfirm`) }}
                        </BiButton>
                    </div>
                </template>
            </BiModal>
        </Teleport>
    </template>
</template>
