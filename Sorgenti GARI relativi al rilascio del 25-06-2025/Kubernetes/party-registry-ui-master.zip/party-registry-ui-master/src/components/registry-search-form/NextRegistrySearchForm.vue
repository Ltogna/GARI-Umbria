<script setup lang="ts">
import { MODULE_ID } from "@/constants";
import { ArchivedEnum, type RegistrySearchRequest } from "@/models/RegistrySearchRequest";
import BiButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiButton.vue";
import { getUUID } from "@abaco/bootstrap-italia-components/src/utilities";
import { BiTextInput, i18n, useApiResponseHandler } from "patri-common-ui/src";
import BiModal from "@abaco/bootstrap-italia-components/src/components/BiModal/BiModal.vue";
import BiAlert from "@abaco/bootstrap-italia-components/src/components/BiAlert/BiAlert.vue";
import { reactive, ref, inject, computed } from "vue";
import useColors from "@abaco/bootstrap-italia-components/src/composables/useColors";
import { useRegistryStore } from "@/stores/registry";
import type RegistryApi from "@/api/registry-api";
import { MODULE_ID as COMMON_MODULE_ID } from "patri-common-ui/src/constants";
import { RouteName } from "@/routes";
import { useRouter } from "vue-router";
import BiProgressIndicator from "@abaco/bootstrap-italia-components/src/components/BiProgressIndicator/BiProgressIndicator.vue";
import type { PartyResponse, PartySearchResponseList } from "@/models/PartySearchResponseSchema";

const { t } = i18n.global;
const router = useRouter();

const formId = getUUID();
const { getColor } = useColors();
const registryApi: RegistryApi = inject("registryApi") as RegistryApi;
const registryStore = useRegistryStore();
const externalSources = computed(() => registryStore.getExternalSources);

const regId = ref<number>(0);
const searchForm = reactive<Partial<RegistrySearchRequest>>({});
const searchFormRef = ref();
const isModalOpen = ref<boolean>(false);
const addPartyRegistryEnabled = ref<boolean>(false);
const modalType = ref<number>(0);
const isLoading = ref<boolean>(false);

// eslint-disable-next-line @typescript-eslint/no-unused-vars
const emit = defineEmits<{
    (e: "search", value: Partial<RegistrySearchRequest>): void;
}>();

function resetBodyScroll() {
    document.body.classList.remove("modal-open");
    document.body.style.removeProperty("overflow");
    document.body.style.removeProperty("padding-right");
}

function toggleModal() {
    isModalOpen.value = !isModalOpen.value;
    !isModalOpen.value && resetBodyScroll();
}

async function onConfirm() {
    switch (modalType.value) {
        case 2:
            await useApiResponseHandler<PartyResponse>(() =>
                registryApi.searchAndUpdateParty(
                    (externalSources.value && externalSources.value[0] && externalSources.value[0].code) ?? "",
                    searchForm.taxOrVat?.trim() ?? "",
                ),
            );

            router.push({ name: RouteName.PARTY_NEW_FORM, query: { fromNextVer: "true" } });
            break;
        case 3:
            await useApiResponseHandler<PartyResponse>(() =>
                registryApi.searchAndUpdateParty(
                    (externalSources.value && externalSources.value[0] && externalSources.value[0].code) ?? "",
                    searchForm.taxOrVat?.trim() ?? "",
                ),
            );

            router.push({
                name: RouteName.PARTY_EDIT_FORM,
                params: { regId: regId.value },
                query: { fromNextVer: "true" },
            });
            break;
        case 4:
            regId.value =
                (
                    await useApiResponseHandler<PartyResponse>(() =>
                        registryApi.searchAndUpdateParty(
                            (externalSources.value && externalSources.value[0] && externalSources.value[0].code) ?? "",
                            searchForm.taxOrVat?.trim() ?? "",
                        ),
                    )
                )?.id ?? 0;

            router.push({
                name: RouteName.PARTY_EDIT_FORM,
                params: { regId: regId.value },
                query: { fromNextVer: "true" },
            });
            break;
        case 5:
            // TODO REDIRECT A NEW???
            // 5 -servizio KO e posso aggiungere (errore 502 e addPartyRegistryEnabled = true)
            break;
        default:
            toggleModal();
            break;
    }
}

async function onSearch() {
    if (!isLoading.value && externalSources.value?.length !== 0) {
        isLoading.value = true;
        const firstExternalSource = externalSources.value ? externalSources.value[0] : null;
        addPartyRegistryEnabled.value = firstExternalSource?.allowManual ?? false;

        const subjectExternalSource = await registryApi.checkSubjectInExternalSource(
            searchForm.taxOrVat?.trim() ?? "",
            firstExternalSource?.code ?? "",
        );

        //TEST: ZNNLCU98T31G633N
        // 1 -soggetto non c'è e non posso aggiungerlo (addPartyRegistryEnabled = false)
        // 2 -soggetto non c'è e posso aggiungerlo manualmente (addPartyRegistryEnabled = true)
        // 3 -soggetto c'è in anagrafica esterna e interna posso andare in edit
        // 4 -soggetto c'è in anagrafica esterna ma non in interna e posso creare soggetto
        // 5 -servizio KO e posso aggiungere (addPartyRegistryEnabled = true)
        // 6 -servizio KO e non posso aggiungere (addPartyRegistryEnabled = false)

        if (subjectExternalSource.errorType === 0) {
            if (subjectExternalSource.data) {
                const subjectInternalSource = await useApiResponseHandler<PartySearchResponseList>(() =>
                    registryApi.getRegistries({
                        archived: ArchivedEnum.not_archived,
                        taxOrVat: searchForm.taxOrVat?.trim() ?? "",
                    }),
                );

                if ((subjectInternalSource?.count ?? 0) > 0) {
                    // 3 -soggetto c'è in anagrafica e posso andare in edit (cod 200)
                    regId.value = subjectInternalSource?.records[0].id ?? 0;
                    modalType.value = 3;
                } else {
                    // 4 -soggetto c'è in anagrafica esterna ma non in interna posso creare soggetto
                    modalType.value = 4;
                }
            } else {
                // 1 -soggetto non c'è e non posso aggiungerlo (addPartyRegistryEnabled = false)
                // 2 -soggetto non c'è e posso aggiungerlo manualmente (addPartyRegistryEnabled = true)
                modalType.value = addPartyRegistryEnabled.value ? 2 : 1;
            }
        } else {
            // 5 -servizio KO e posso aggiungere (addPartyRegistryEnabled = true)
            // 6 -servizio KO e non posso aggiungere (addPartyRegistryEnabled = false)
            modalType.value = addPartyRegistryEnabled.value ? 5 : 6;
        }

        isLoading.value = false;
        isModalOpen.value = true;
    }
}
</script>
<template>
    <form
        :id="formId"
        class="party-registry-ui__registry-search-form needs-validation pt-5"
        ref="searchFormRef"
        @submit.prevent="onSearch"
    >
        <div class="row">
            <div class="col-md-4 mb-4">
                <BiTextInput
                    :id="getUUID()"
                    v-model="searchForm.taxOrVat"
                    :label="t(`${MODULE_ID}.registry.search.taxOrVat`)"
                    name="taxOrVat"
                    :placeholder="t(`${MODULE_ID}.registry.search.inputPlaceholder`)"
                    :disabled="isLoading"
                />
            </div>
            <div class="form-group col-12 d-flex justify-content-center align-items-center">
                <BiButton
                    v-if="!isLoading"
                    :is-disabled="!searchForm?.taxOrVat || isLoading"
                    @click="onSearch"
                    size="lg"
                    class="ms-3 btn"
                    :class="getColor('button', 'success')"
                >
                    {{ t(`${MODULE_ID}.registry.search.checkAndGet`) }}
                </BiButton>
                <BiProgressIndicator v-else type="spinner"></BiProgressIndicator>
            </div>
        </div>
    </form>

    <BiModal
        :disabled-teleport="true"
        :extra-footer-class="'justify-content-center'"
        v-model="isModalOpen"
        :aria-labelledby="t(`${COMMON_MODULE_ID}.general.warning`)"
        :title="t(`${COMMON_MODULE_ID}.general.warning`)"
        :prevent-dismiss="true"
        style="white-space: pre-line"
    >
        <template #body>
            <div class="col-12 mb-3">
                <BiAlert isInfo>
                    <template #body>
                        {{ t(`${MODULE_ID}.registry.search.modal.body${modalType}`) }}
                    </template>
                </BiAlert>
            </div>
        </template>
        <template #footer>
            <div class="d-flex justify-content-center w-100">
                <BiButton
                    v-if="modalType === 0 || modalType === 1 || modalType === 6"
                    class="mx-1"
                    :class="getColor('button', 'secondary', 'outline')"
                    @click.stop="
                        () => {
                            toggleModal();
                        }
                    "
                    >{{ t(`${COMMON_MODULE_ID}.general.close`) }}
                </BiButton>
                <BiButton
                    v-if="modalType === 2 || modalType === 3 || modalType === 4 || modalType === 5"
                    class="mx-1"
                    :class="getColor('button', 'secondary', 'outline')"
                    @click.stop="
                        () => {
                            toggleModal();
                        }
                    "
                    >{{ t(`${COMMON_MODULE_ID}.general.cancel`) }}
                </BiButton>
                <BiButton
                    v-if="modalType === 2 || modalType === 3 || modalType === 4 || modalType === 5"
                    class="mx-1"
                    isPrimary
                    :class="getColor('button', 'success')"
                    @click.stop="
                        async () => {
                            await onConfirm();
                        }
                    "
                    >{{ t(`${COMMON_MODULE_ID}.general.confirm`) }}
                </BiButton>
            </div>
        </template>
    </BiModal>
</template>

<style lang="scss" scoped>
.party-registry-ui {
    &__registry-search-form {
        .registry-search-form__select {
            margin-top: 1.2em;
        }
    }
}
</style>
