<script setup lang="ts">
import { computed } from "vue";
import { ArchivedEnum, type RegistrySearchRequest } from "@/models/RegistrySearchRequest";
import { i18n } from "patri-common-ui/src";
import { MODULE_ID } from "@/constants";
import { useRegistryStore } from "@/stores/registry";
import BiChip from "@abaco/bootstrap-italia-components/src/components/BiChip/BiChip.vue";

type RegistryFilterField = keyof RegistrySearchRequest;

const emit = defineEmits<{
    (e: "remove-filter", value: Partial<RegistrySearchRequest>): void;
}>();

const { t } = i18n.global;
const registryStore = useRegistryStore();
const label = t(`${MODULE_ID}.registry.list.fields.tag`);
// #134847 fixed, now if at least one chip (excluded archived) isn't set, we can't remove.
const atLeastOneField = computed(() => {
    let numberOfFields = [
        code.value,
        lastName.value,
        firstName.value,
        taxOrVat.value,
        taxCode.value,
        vatNumber.value,
    ].filter((f) => f != null).length;

    if (Array.isArray(tags.value) && tags.value.length > 0) {
        numberOfFields += tags.value.length;
    }

    return numberOfFields >= 2;
});

const code = computed(() => {
    const label = t(`${MODULE_ID}.registry.list.fields.code`);
    const value = registryStore.search.code;

    return value ? `${label}: ${value}` : null;
});
const lastName = computed(() => {
    const label = t(`${MODULE_ID}.registry.list.fields.lastName`);
    const value = registryStore.search.lastName;

    return value ? `${label}: ${value}` : null;
});
const firstName = computed(() => {
    const label = t(`${MODULE_ID}.registry.list.fields.firstName`);
    const value = registryStore.search.firstName;

    return value ? `${label}: ${value}` : null;
});
const taxOrVat = computed(() => {
    const label = t(`${MODULE_ID}.registry.search.taxOrVat`);
    const value = registryStore.search.taxOrVat;

    return value ? `${label}: ${value}` : null;
});
const taxCode = computed(() => {
    const label = t(`${MODULE_ID}.registry.list.fields.taxCode`);
    const value = registryStore.search.taxCode;

    return value ? `${label}: ${value}` : null;
});
const vatNumber = computed(() => {
    const label = t(`${MODULE_ID}.registry.list.fields.vatNumber`);
    const value = registryStore.search.vatNumber;

    return value ? `${label}: ${value}` : null;
});
const archived = computed(() => {
    const label = t(`${MODULE_ID}.registry.list.fields.archived`);
    const value =
        registryStore.search.archived === ArchivedEnum.all
            ? t(`${MODULE_ID}.registry.list.fields.archived_yes`)
            : t(`${MODULE_ID}.registry.list.fields.archived_no`);

    return value ? `${label}: ${value}` : null;
});
const tags = computed(() => {
    // #134847 return values for tags
    const values = registryStore.search.tag ?? [];

    return values.map((tag) => `${tag.value}`);
});

function removeFilter(filterCode: RegistryFilterField) {
    if (atLeastOneField.value) {
        registryStore.search[filterCode] = undefined;
        emit("remove-filter", registryStore.search);
    }
}
function resetArchived() {
    registryStore.search.archived = ArchivedEnum.not_archived;
    emit("remove-filter", registryStore.search);
}
function removeTagFilter(tag: string) {
    if (atLeastOneField.value) {
        registryStore.search.tag = registryStore.search.tag?.filter((t) => t.value !== tag);
        emit("remove-filter", registryStore.search);
    }
}
</script>
<template>
    <BiChip v-if="code" :isDelete="atLeastOneField" :label="code" @click="removeFilter('code')"></BiChip>
    <BiChip v-if="taxOrVat" :isDelete="atLeastOneField" :label="taxOrVat" @click="removeFilter('taxOrVat')"></BiChip>
    <BiChip v-if="firstName" :isDelete="atLeastOneField" :label="firstName" @click="removeFilter('firstName')"></BiChip>
    <BiChip v-if="lastName" :isDelete="atLeastOneField" :label="lastName" @click="removeFilter('lastName')"></BiChip>
    <BiChip v-if="taxCode" :isDelete="atLeastOneField" :label="taxCode" @click="removeFilter('taxCode')"></BiChip>
    <BiChip v-if="vatNumber" :isDelete="atLeastOneField" :label="vatNumber" @click="removeFilter('vatNumber')"></BiChip>
    <BiChip
        v-if="archived"
        :isDelete="registryStore.search.archived === ArchivedEnum.all"
        :label="archived"
        @click="resetArchived()"
    ></BiChip>
    <BiChip
        v-for="(tag, index) in tags"
        :key="`${tag}_${index}`"
        :isDelete="atLeastOneField"
        :label="`${label}: ${tag}`"
        @click="removeTagFilter(tag)"
    ></BiChip>
</template>
