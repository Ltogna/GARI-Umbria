<script setup lang="ts">
import { MODULE_ID } from "@/constants";
import { useTags } from "@/hooks/useTags";
import { ArchivedEnum, type RegistrySearchRequest } from "@/models/RegistrySearchRequest";
import { useConfigurationStore } from "@/stores/configuration";
import { useRegistryStore } from "@/stores/registry";
import BiButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiButton.vue";
import BiNotification from "@abaco/bootstrap-italia-components/src/components/BiNotification/BiNotification.vue";
import BiAutocompleteNext from "@abaco/bootstrap-italia-components/src/components/form/BiAutocompleteNext.vue";
import BiCheckbox from "@abaco/bootstrap-italia-components/src/components/form/BiCheckbox.vue";
import useColors from "@abaco/bootstrap-italia-components/src/composables/useColors";
import { getUUID } from "@abaco/bootstrap-italia-components/src/utilities";
import JustValidate from "just-validate";
import { BiTextInput, formUtils, i18n, useForm } from "patri-common-ui/src";
import { MODULE_ID as COMMON_MODULE_ID } from "patri-common-ui/src/constants";
import { computed, onMounted, reactive, ref, toRaw, watch } from "vue";

const { justValidateConfig } = formUtils;
const { t } = i18n.global;

const formId = getUUID();
const configurationStore = useConfigurationStore();
const { getColor } = useColors();

const searchForm = reactive<Partial<RegistrySearchRequest>>({
    archived: ArchivedEnum.not_archived,
});
const searchFormRef = ref();
const includeArchived = ref(false);

const { tagList } = useTags();
const registryStore = useRegistryStore();
const { validate, isSubmitted, onSubmit, onReset } = useForm(submitCallback, searchForm, formId);

const atLeastOneField = computed(() => {
    // #134847 empty array won't be send
    return Object.keys(searchForm).some((key) => {
        const value = (searchForm as { [s: string]: unknown })[key];
        if (Array.isArray(value)) {
            return value.length > 0;
        }
        return key !== "archived" && !!value;
    });
});

const canDisplayCuaa = computed(() => {
    return !!configurationStore.code;
});

const emit = defineEmits<{
    (e: "search", value: Partial<RegistrySearchRequest>): void;
}>();

const tagSelectItems = computed(() =>
    tagList.value.map((it) => Object.assign({ key: it.code, value: it.i18nCode ?? it.code, i18: it.i18nCode }, {})),
);

onMounted(() => {
    initSearchForm();
    validate.value = new JustValidate(searchFormRef.value, justValidateConfig);
});

watch(includeArchived, (value) => {
    searchForm.archived = value ? ArchivedEnum.all : ArchivedEnum.not_archived;
});

function submitCallback() {
    if (atLeastOneField.value) {
        const rawRegistryForm = toRaw(searchForm);
        registryStore.setSearch(rawRegistryForm);
        emit("search", rawRegistryForm);
    }
}

function initSearchForm() {
    Object.keys(registryStore.search)
        .filter((key) => (registryStore.search as { [s: string]: unknown })[key])
        .forEach((it) => {
            (searchForm as { [s: string]: unknown })[it] = (registryStore.search as { [s: string]: unknown })[it];
        });
    searchForm.archived =
        registryStore.search.archived === ArchivedEnum.all ? ArchivedEnum.all : ArchivedEnum.not_archived;
    includeArchived.value = registryStore.search.archived === ArchivedEnum.all;
}

function onCustomReset() {
    onReset();
    registryStore.resetSearch();
}
</script>

<template>
    <form
        :id="formId"
        class="party-registry-ui__registry-search-form needs-validation pt-5"
        ref="searchFormRef"
        @submit.prevent="onSubmit"
    >
        <div class="row">
            <div class="col-md-6 mb-4 align-self-end">
                <BiTextInput
                    :id="getUUID()"
                    v-model.trim="searchForm.taxOrVat"
                    :label="t(`${MODULE_ID}.registry.search.taxOrVat`)"
                    name="taxOrVat"
                    :placeholder="t(`${MODULE_ID}.registry.search.inputPlaceholder`)"
                />
            </div>
            <div class="col-md-6 form-tag custom-margin mb-4 align-self-end">
                <!-- #134847 added autocomplete with chips -->
                <BiAutocompleteNext
                    :id="getUUID()"
                    v-model.trim="searchForm.tag"
                    :items="tagSelectItems"
                    :label="t(`${MODULE_ID}.registry.form.fields.tags.label`)"
                    :placeholder="t(`${MODULE_ID}.registry.form.fields.tags.placeholder`)"
                    itemTitle="value"
                    itemValue="key"
                    chipType="primary"
                    chipIconSize="sm"
                    multiple
                    :min-search-lenght="1"
                    :label-no-result="`${t(`${MODULE_ID}.registry.form.no_element_found`)}`"
                    :label-no-items="`${t(`${MODULE_ID}.registry.form.empty_list`)}`"
                />
            </div>
            <div class="col-md-6 mb-4 align-self-end">
                <BiTextInput
                    :id="getUUID()"
                    v-model.trim="searchForm.lastName"
                    :label="t(`${MODULE_ID}.registry.list.fields.lastName`)"
                    name="lastName"
                    :placeholder="t(`${MODULE_ID}.registry.search.inputPlaceholder`)"
                />
            </div>
            <div class="col-md-6 mb-4 align-self-end">
                <BiTextInput
                    :id="getUUID()"
                    v-model.trim="searchForm.firstName"
                    :label="t(`${MODULE_ID}.registry.list.fields.firstName`)"
                    name="firstName"
                    :placeholder="t(`${MODULE_ID}.registry.search.inputPlaceholder`)"
                />
            </div>
            <div v-if="canDisplayCuaa" class="col-md-6 align-self-end mb-4">
                <BiTextInput
                    :id="getUUID()"
                    :name="'cuaa'"
                    :label="t(`${MODULE_ID}.registry.form.fields.cuaa.label`)"
                    :placeholder="t(`${MODULE_ID}.registry.search.inputPlaceholder`)"
                    v-model.trim="searchForm.code"
                />
            </div>
            <div class="col-md-6 d-flex align-items-end fw-semibold mb-4 align-self-end">
                <BiCheckbox :label="t(`${MODULE_ID}.registry.search.searchAll`)" v-model.trim="includeArchived" />
            </div>
            <div class="form-group col-12 d-flex justify-content-center align-items-center mt-4">
                <BiButton
                    type="reset"
                    @click="onCustomReset"
                    class="btn-me"
                    size="lg"
                    :class="getColor('button', 'secondary', 'outline')"
                >
                    {{ t(`patri-common.general.cancel`) }}
                </BiButton>
                <BiButton type="submit" size="lg" class="ms-3 btn" :class="getColor('button', 'success')">
                    {{ t(`${COMMON_MODULE_ID}.general.search`) }}
                </BiButton>
            </div>
        </div>
    </form>
    <BiNotification
        :model-value="!atLeastOneField && isSubmitted"
        :title="t(`patri-common.general.warning`)"
        :variant="'error'"
        :text="t(`${MODULE_ID}.registry.search.errors.atLeastOneField`)"
        :icon="'circle-xmark'"
    />
</template>

<style lang="scss" scoped>
.party-registry-ui {
    &__registry-search-form {
        .registry-search-form__select {
            margin-top: 1.2em;
        }
    }
}
</style>
