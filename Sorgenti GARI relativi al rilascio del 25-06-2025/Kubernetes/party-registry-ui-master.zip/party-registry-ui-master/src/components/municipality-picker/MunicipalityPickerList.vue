<script setup lang="ts">
import BiButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiButton.vue";
import BiIcon from "@abaco/bootstrap-italia-components/src/components/BiIcon/BiIcon.vue";
import BiTable from "@abaco/bootstrap-italia-components/src/components/BiTable/BiTable.vue";
import { inject } from "vue";

import { i18n, type I18nInterface, type MunicipalitySearchResponse } from "patri-common-ui/src";
import { MODULE_ID } from "../../constants";
import { MODULE_ID as COMMON_MODULE_ID } from "patri-common-ui/src/constants";
import useColors from "@abaco/bootstrap-italia-components/src/composables/useColors";

withDefaults(
    defineProps<{
        municipalityList: MunicipalitySearchResponse[];
        showLoadMore?: boolean;
    }>(),
    { showLoadMore: false },
);
const emit = defineEmits<{
    (e: "load-more"): void;
    (e: "select-municipality", value: MunicipalitySearchResponse): void;
}>();

const { getColor } = useColors();

const i18nService = inject<I18nInterface | null>("partyI18nService", null);
const { t } = i18nService?.global ?? i18n.global;

function loadMore() {
    emit("load-more");
}

function selectParty(value: MunicipalitySearchResponse) {
    emit("select-municipality", value);
}
</script>
<template>
    <BiTable class="table mb-0" extraTableClasses="table-head-bg" is-row-hover isResponsive>
        <template #head>
            <tr class="bg-light" :class="getColor('text', 'secondary')">
                <th scope="col">{{ t(`${MODULE_ID}.municipality.search.municipality`) }}</th>
                <th scope="col">{{ t(`${MODULE_ID}.municipality.search.district`) }}</th>
                <th scope="col">{{ t(`${MODULE_ID}.municipality.search.region`) }}</th>
                <th scope="col">{{ t(`${MODULE_ID}.municipality.search.country`) }}</th>
                <th scope="col"></th>
            </tr>
        </template>
        <template #body>
            <tr v-for="(item, i) in municipalityList" :key="i">
                <td :data-label="t(`${MODULE_ID}.municipality.search.municipality`)">
                    {{ item.i18nName }}
                </td>
                <td :data-label="t(`${MODULE_ID}.municipality.search.district`)">{{ item.district.i18nName }}</td>
                <td :data-label="t(`${MODULE_ID}.municipality.search.region`)">{{ item.district.region.i18nName }}</td>
                <td :data-label="t(`${MODULE_ID}.municipality.search.country`)">
                    {{ item.district.region.country.i18nName }}
                </td>
                <td class="actions">
                    <BiButton
                        color="info"
                        is-icon
                        :is-outlined="true"
                        :title="t(`${COMMON_MODULE_ID}.general.add`)"
                        :width="40"
                        :height="38"
                        @click="selectParty(item)"
                    >
                        <BiIcon icon="plus" size="lg" />
                    </BiButton>
                </td>
            </tr>
        </template>
    </BiTable>
    <div class="d-flex justify-content-end mb-4" v-if="showLoadMore">
        <BiButton :is-outlined="true" color="primary" @click="loadMore()">
            {{ t(`${COMMON_MODULE_ID}.general.loadMore`) }}
        </BiButton>
    </div>
</template>
