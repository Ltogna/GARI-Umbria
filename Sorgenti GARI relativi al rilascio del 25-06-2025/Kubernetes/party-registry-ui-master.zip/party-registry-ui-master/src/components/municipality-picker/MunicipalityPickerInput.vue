<script setup lang="ts">
import { getUUID } from "@abaco/bootstrap-italia-components/src/utilities";
import {
    i18n,
    LauPublicApi,
    BiTextInput,
    type I18nInterface,
    type MunicipalitySearchResponse,
} from "patri-common-ui/src";
import { inject, onMounted, ref, watch } from "vue";

import { MODULE_ID } from "../../constants";
import MunicipalityPickerModal from "./MunicipalityPickerModal.vue";

const i18nService = inject<I18nInterface | null>("partyI18nService", null);
const { t } = i18nService?.global ?? i18n.global;
const lauPublicApi = inject("lauPublicApi") as LauPublicApi;

const props = defineProps<{
    name: string;
    label?: string;
    placeholder?: string;
    disabled?: boolean;
    validatorFn?: (id: string) => Promise<boolean>;
    modelValue?: string;
}>();
const emit = defineEmits<{
    (e: "update:modelValue", value: string): void;
}>();

const municipalityDescr = ref<string>();

watch(
    () => props.modelValue,
    async (value) => {
        value && !municipalityDescr.value && (await fetchMunicipality(value));
    },
);

onMounted(async () => {
    props.modelValue && (await fetchMunicipality(props.modelValue));
});

function onSelectMunicipality(selectedMunicipality: MunicipalitySearchResponse) {
    municipalityDescr.value = selectedMunicipality.i18nName ?? selectedMunicipality.code;
    emit("update:modelValue", selectedMunicipality.code);
}
async function fetchMunicipality(municipalityCode: string) {
    const res = await lauPublicApi.getMunicipalityByCode(municipalityCode);
    res && res.errorType === 0 && res.data && onSelectMunicipality(res.data as MunicipalitySearchResponse);
}
</script>
<template>
    <div class="d-flex align-items-end flex-nowrap">
        <div class="flex-grow-1">
            <BiTextInput
                :id="getUUID()"
                :name="name"
                is-readonly
                :label="label || t(`${MODULE_ID}.municipality.field.label`)"
                :placeholder="placeholder || t(`${MODULE_ID}.municipality.field.placeholder`)"
                v-model="municipalityDescr"
            />
        </div>
        <MunicipalityPickerModal
            v-if="!disabled"
            :btn-label="t(`${MODULE_ID}.general.search`)"
            :modal-title="t(`${MODULE_ID}.municipality.search.title`)"
            @select-municipality="onSelectMunicipality"
        />
    </div>
</template>
