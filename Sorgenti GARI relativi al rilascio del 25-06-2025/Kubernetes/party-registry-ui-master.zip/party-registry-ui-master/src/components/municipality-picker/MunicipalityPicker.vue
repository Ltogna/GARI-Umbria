<script setup lang="ts">
import { inject, ref } from "vue";

import type { MunicipalitySearchResponse, LauPublicApi } from "patri-common-ui/src";
import MunicipalityPickerSearchForm from "./MunicipalityPickerSearchForm.vue";
import MunicipalityPickerList from "./MunicipalityPickerList.vue";
import { type MunicipalitySearchRequest } from "patri-common-ui/src";
import { useApiResponseHandler } from "../../index";

const emit = defineEmits<{
    (e: "cancel"): void;
    (e: "select-municipality", value: MunicipalitySearchResponse): void;
}>();

const lauPublicApi = inject("lauPublicApi") as LauPublicApi;

const currentSearch = ref<Partial<MunicipalitySearchRequest>>();
const municipalityList = ref<MunicipalitySearchResponse[] | null>();
const nextKey = ref<string | null>();

function onCancel() {
    emit("cancel");
}
function onSelectMunicipality(selectedMunicipality: MunicipalitySearchResponse) {
    emit("select-municipality", selectedMunicipality);
}
async function onLoadMore() {
    currentSearch.value && (await fetchParties(currentSearch.value, nextKey.value ?? undefined));
}
async function onSearch(searchForm: Partial<MunicipalitySearchRequest>) {
    currentSearch.value = searchForm;
    await fetchParties(currentSearch.value);
}
async function fetchParties(searchForm: Partial<MunicipalitySearchRequest>, nextPage?: string) {
    const res = await useApiResponseHandler(() => lauPublicApi.getMunicipalities(searchForm, nextPage ?? undefined));

    nextKey.value = res?.nextKey;
    !nextPage && (municipalityList.value = null);

    if (res?.records) {
        municipalityList.value && (municipalityList.value = [...municipalityList.value, ...res.records]);
        !municipalityList.value && (municipalityList.value = res.records);
    }
}
</script>
<template>
    <MunicipalityPickerSearchForm @cancel="onCancel" @search="onSearch" />
    <MunicipalityPickerList
        v-if="municipalityList"
        :municipality-list="municipalityList"
        :show-load-more="!!nextKey"
        @load-more="onLoadMore"
        @select-municipality="onSelectMunicipality"
    />
</template>
