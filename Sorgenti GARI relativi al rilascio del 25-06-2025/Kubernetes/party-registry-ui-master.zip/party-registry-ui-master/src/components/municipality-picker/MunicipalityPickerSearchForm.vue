<script setup lang="ts">
import JustValidate from "just-validate";
import { computed, inject, onMounted, reactive, ref, toRaw } from "vue";

import BiNotification from "@abaco/bootstrap-italia-components/src/components/BiNotification/BiNotification.vue";
import BiButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiButton.vue";
import BiInput from "@abaco/bootstrap-italia-components/src/components/form/BiInput.vue";
import { getUUID } from "@abaco/bootstrap-italia-components/src/utilities";

import { useForm, type MunicipalitySearchRequest, i18n, type I18nInterface, formUtils } from "patri-common-ui/src";
import { MODULE_ID } from "../../constants";
import { MODULE_ID as COMMON_MODULE_ID } from "patri-common-ui/src/constants";

const emit = defineEmits<{
    (e: "search", value: Partial<MunicipalitySearchRequest>): void;
    (e: "cancel"): void;
}>();

const { justValidateConfig } = formUtils;
const i18nService = inject<I18nInterface | null>("partyI18nService", null);
const { t } = i18nService?.global ?? i18n.global;

const formId = getUUID();
const searchForm = reactive<Partial<MunicipalitySearchRequest>>({});
const searchFormRef = ref();

const { validate, isSubmitted, onSubmit } = useForm(submitCallback, searchForm, formId);

const atLeastOneField = computed(() => {
    return Object.keys(searchForm).some((key) => {
        if (Array.isArray((searchForm as Record<string, unknown>)[key])) {
            const valid = !!((searchForm as Record<string, unknown>)[key] as unknown[]).length;
            return valid;
        }
        return !!(searchForm as Record<string, unknown>)[key];
    });
});

onMounted(async () => {
    validate.value = new JustValidate(searchFormRef.value, justValidateConfig);
});

function submitCallback() {
    atLeastOneField.value && emit("search", toRaw(searchForm));
}
function cancel() {
    emit("cancel");
}
</script>

<template>
    <form :id="formId" class="needs-validation pt-5" ref="searchFormRef" @submit.prevent="onSubmit">
        <div class="row">
            <div class="col-md-6 mb-4">
                <BiInput
                    name="countryI18n"
                    :label="t(`${MODULE_ID}.municipality.search.country`)"
                    :placeholder="t(`${MODULE_ID}.registry.search.inputPlaceholder`)"
                    v-model="searchForm.countryI18n"
                />
            </div>
            <div class="col-md-6 mb-4">
                <BiInput
                    name="regionI18n"
                    :label="t(`${MODULE_ID}.municipality.search.region`)"
                    :placeholder="t(`${MODULE_ID}.registry.search.inputPlaceholder`)"
                    v-model="searchForm.regionI18n"
                />
            </div>
        </div>

        <div class="row">
            <div class="col-md-6 mb-4">
                <BiInput
                    name="districtI18n"
                    :label="t(`${MODULE_ID}.municipality.search.district`)"
                    :placeholder="t(`${MODULE_ID}.registry.search.inputPlaceholder`)"
                    v-model="searchForm.districtI18n"
                />
            </div>
            <div class="col-md-6 mb-4">
                <BiInput
                    name="i18nName"
                    :label="t(`${MODULE_ID}.municipality.search.municipality`)"
                    :placeholder="t(`${MODULE_ID}.registry.search.inputPlaceholder`)"
                    v-model="searchForm.i18nName"
                />
            </div>
        </div>

        <div class="row">
            <div class="form-group col-md-12 text-center">
                <BiButton @click="cancel" :is-outlined="true" color="primary" class="btn-me">
                    {{ t(`${COMMON_MODULE_ID}.general.cancel`) }}
                </BiButton>
                <BiButton type="submit" color="success">
                    {{ t(`${COMMON_MODULE_ID}.general.search`) }}
                </BiButton>
            </div>
        </div>
    </form>
    <BiNotification
        :model-value="!atLeastOneField && isSubmitted"
        :title="t(`${COMMON_MODULE_ID}.general.warning`)"
        :variant="'error'"
        :text="t(`${MODULE_ID}.registry.search.errors.atLeastOneField`)"
        :icon="'circle-xmark'"
    />
</template>
