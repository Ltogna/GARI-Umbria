<script setup lang="ts">
import BiButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiButton.vue";
import BiModal from "@abaco/bootstrap-italia-components/src/components/BiModal/BiModal.vue";
import { ref } from "vue";

import type { MunicipalitySearchResponse } from "patri-common-ui/src";
import MunicipalityPicker from "./MunicipalityPicker.vue";

defineProps<{
    btnLabel: string;
    modalTitle: string;
}>();
const emit = defineEmits<{
    (e: "select-municipality", value: MunicipalitySearchResponse): void;
}>();

const modalVisible = ref(false);
const showModal = ref(false);

function openModal() {
    showModal.value = true;
    toggleModalVisibility(true);
}
function dismissModal() {
    showModal.value = false;
}
function toggleModalVisibility(toggleVisibility: boolean) {
    modalVisible.value = toggleVisibility;
}
function onSelectMunicipality(selectedMunicipality: MunicipalitySearchResponse) {
    emit("select-municipality", selectedMunicipality);
    dismissModal();
}
</script>
<template>
    <BiButton @click="openModal" :is-outlined="true" color="primary">
        {{ btnLabel }}
    </BiButton>
    <BiModal
        size="xl"
        ariaLabelledby="municipality-picker-modal"
        v-model="showModal"
        :title="modalTitle"
        data-keyboard="false"
        data-backdrop="static"
        extra-body-class="pt-5"
        @hidden-modal="toggleModalVisibility(false)"
    >
        <template #body>
            <MunicipalityPicker
                v-if="modalVisible"
                @cancel="dismissModal"
                @select-municipality="onSelectMunicipality"
            />
        </template>
    </BiModal>
</template>
