import type { HTTPClient } from "@abaco/safe-rest/src/HTTPClient";
import { getUserData } from "@abaco/safe-rest/src/sso2";
import type { App, Plugin } from "vue";
import PartyPublicApi from "./api/public/party-public-api";
import PartyTagPublicApi from "./api/public/party-tag-public-api";

import { i18n, loadLocaleMessages } from "patri-common-ui/src";
import { BASE } from "./constants";

const { VITE_REGISTRY_SERVICE, VITE_TENANT } = import.meta.env;

export interface PartyRegistryPluginProps {
    httpConfig: HTTPClient;
}

export default async function (props: PartyRegistryPluginProps): Promise<Plugin> {
    const { httpConfig } = props;
    const tenant = getUserData()?.tenant ?? VITE_TENANT;
    const locale = getUserData()?.locale;

    return {
        install: async (app: App) => {
            const partyPublicApi = new PartyPublicApi(httpConfig, `/${VITE_REGISTRY_SERVICE}/${tenant}`);
            const partyTagPublicApi = new PartyTagPublicApi(httpConfig, `/${VITE_REGISTRY_SERVICE}/${tenant}`);

            app.provide("partyPublicApi", partyPublicApi);
            app.provide("partyTagPublicApi", partyTagPublicApi);

            const userLang = locale ?? navigator.language;
            await loadLocaleMessages(userLang, BASE, ["common"]);
            app.provide("partyI18nService", i18n);
        },
    };
}
