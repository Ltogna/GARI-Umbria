import createBootstrapItaliaComponentPlugin from "@abaco/bootstrap-italia-components/src/components/BootstrapItaliaComponentPlugin";
import { onModuleLoaded } from "@abaco/micro-frontend/src/Application";
import { createAbcRouter } from "@abaco/micro-frontend/src/Utility";
import { HTTPClient } from "@abaco/safe-rest/src/HTTPClient";
import { createPinia, type Pinia } from "pinia";
import { createApp, type App as VueApp } from "vue";

import routes from "@/routes";

import {
    NOOP_STOP_LISTENER,
    type SetStopListenerFunction,
    type StopListener,
} from "@abaco/micro-frontend/src/StopPreventionSuport";

import ContactApi from "@/api/contact-api";
import DynamicDocumentApi from "@/api/dynamic-document-api";
import LegalStatusApi from "@/api/legal-status-api";
import NationalityApi from "@/api/nationality-api";
import RegistryApi from "@/api/registry-api";
import RelationApi from "./api/relation-api";
import TagApi from "./api/tag-api";

import RegistryApp from "@/App.vue";
import { getUserData, installSso2RequestConfigProvider, userHasPermission } from "@abaco/safe-rest/src/sso2";
import { loadLocaleMessages, login, PatriCommonPlugin } from "patri-common-ui/src";
import PartyConfigurationPublicApi from "./api/public/party-configuration-public-api";
import PartyPublicApi from "./api/public/party-public-api";
import PartyTagPublicApi from "./api/public/party-tag-public-api";
import UserPermissionApi from "./api/user-permission-api";
import { BASE, DEFAULT_DATE_FORMAT, MODULE_ID } from "./constants";

const { MODE, BASE_URL, VITE_REGISTRY_SERVICE, VITE_TENANT, VITE_LOGIN_DATA, VITE_APP_VERSION, VITE_APP_GIT_COMMIT } =
    import.meta.env;
const isStandalone = MODE === "standalone";

console.log(`Party registry: v${VITE_APP_VERSION}-${VITE_APP_GIT_COMMIT}`);

import "@/assets/party-registry.scss";

/**
 * #134529 25/03/24 reset store
 *
 * Destroy and recreate pinia on module unload and reload
 */
let pinia: Pinia | null = null;
const http = new HTTPClient();
installSso2RequestConfigProvider(http, "/sso2");

if (isStandalone) {
    window.bootstrap.loadFonts(`${BASE_URL}bootstrap-italia/dist/fonts`);
    await import("@/assets/main.scss");
    await login(JSON.parse(VITE_LOGIN_DATA));
    const router = createAbcRouter(routes, BASE_URL);
    const app = createApp(RegistryApp);
    app.provide("setStopListener", undefined);
    app.use(router);
    await initApp(app);
    app.mount("#app");
} else {
    let appModule: VueApp<Element> | null;
    let stopListener: StopListener = NOOP_STOP_LISTENER;
    const fnc: SetStopListenerFunction = (l: StopListener | null) => (stopListener = l || NOOP_STOP_LISTENER);

    onModuleLoaded(MODULE_ID, {
        async start(node, basePath?: string) {
            appModule = createApp(RegistryApp);
            appModule.provide("setStopListener", fnc);
            // eslint-disable-next-line @typescript-eslint/no-explicit-any
            const router = createAbcRouter(routes, basePath);
            appModule.use(router);

            await initApp(appModule, basePath);
            appModule.mount(node);
        },
        css() {
            return { index: "/ui/party-registry-ui/assets/index.css.json" };
        },
        async canStop() {
            return stopListener();
        },
        async stop() {
            appModule?.unmount();
            pinia = null;
            appModule = null;
        },
    });
}

async function initApp(appModule: VueApp, basePath?: string) {
    pinia ??= createPinia();

    appModule.use(pinia);
    const bootstrapItaliaComponentPlugin = await createBootstrapItaliaComponentPlugin({
        includeGlobalComponent: false,
        includeFontAwesome: isStandalone,
    });

    const user = getUserData();
    const hasPermissionAdmin = userHasPermission("PARTY-REGISTRY", "ADMIN");
    const hasPermissionWrite = userHasPermission("PARTY-REGISTRY", "WRITE");
    const hasPermissionRead = userHasPermission("PARTY-REGISTRY", "READ");
    const hasPermissionDelete = userHasPermission("PARTY-REGISTRY", "DELETE");
    const lang = user?.locale ?? window.navigator.language;
    const userDateFormat = user?.dateFormat ?? DEFAULT_DATE_FORMAT;
    await loadLocaleMessages(lang, BASE, ["common"]);

    const tenant = user?.tenant ?? VITE_TENANT;
    const registryApi = new RegistryApi(http, `/${VITE_REGISTRY_SERVICE}/${tenant}`);
    const tagApi = new TagApi(http, `/${VITE_REGISTRY_SERVICE}/${tenant}`);
    const contactApi = new ContactApi(http, `/${VITE_REGISTRY_SERVICE}/${tenant}`);
    const relationApi = new RelationApi(http, `/${VITE_REGISTRY_SERVICE}/${tenant}`);
    const nationalityApi = new NationalityApi(http, `/${VITE_REGISTRY_SERVICE}/${tenant}`);
    const dynamicDocumentApi = new DynamicDocumentApi(http, `/${VITE_REGISTRY_SERVICE}/${tenant}`);
    const legalStatusApi = new LegalStatusApi(http, `/${VITE_REGISTRY_SERVICE}/${tenant}`);
    // #135102 create user permission API client
    const userPermissionApi = new UserPermissionApi(http, `/${VITE_REGISTRY_SERVICE}/${tenant}`);

    const partyPublicApi = new PartyPublicApi(http, `/${VITE_REGISTRY_SERVICE}/${tenant}`);
    const partyTagPublicApi = new PartyTagPublicApi(http, `/${VITE_REGISTRY_SERVICE}/${tenant}`);
    const partyConfigPublicApi = new PartyConfigurationPublicApi(http, `/${VITE_REGISTRY_SERVICE}/${tenant}`);

    try {
        appModule.use(bootstrapItaliaComponentPlugin);
        appModule.use(await PatriCommonPlugin({ httpConfig: http }));
        appModule.provide("hasPermissionAdmin", isStandalone || hasPermissionAdmin);
        appModule.provide("hasPermissionWrite", isStandalone || hasPermissionWrite);
        appModule.provide("hasPermissionRead", isStandalone || hasPermissionRead);
        appModule.provide("hasPermissionDelete", isStandalone || hasPermissionDelete);
        appModule.provide("userDateFormat", userDateFormat);
        appModule.provide("basePath", basePath);
        appModule.provide("moduleId", MODULE_ID);

        appModule.provide("dynamicDocumentApi", dynamicDocumentApi);
        appModule.provide("registryApi", registryApi);
        appModule.provide("tagApi", tagApi);
        appModule.provide("contactApi", contactApi);
        appModule.provide("relationApi", relationApi);
        appModule.provide("nationalityApi", nationalityApi);
        appModule.provide("legalStatusApi", legalStatusApi);
        // #135102 set user permissions client to provide
        appModule.provide("userPermissionApi", userPermissionApi);

        appModule.provide("partyPublicApi", partyPublicApi);
        appModule.provide("partyTagPublicApi", partyTagPublicApi);
        appModule.provide("partyConfigPublicApi", partyConfigPublicApi);
    } catch (err) {
        console.warn(err);
    }
}
