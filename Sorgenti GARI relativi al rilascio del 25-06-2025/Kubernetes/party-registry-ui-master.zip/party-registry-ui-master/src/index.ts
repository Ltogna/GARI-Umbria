import PartyPicker from "./components/party-picker/PartyPickerList.vue";
import PartyPickerModal from "./components/party-picker/PartyPickerModal.vue";
import PartyPickerList from "./components/party-picker/PartyPickerList.vue";
import PartyPickerSearchForm from "./components/party-picker/PartyPickerSearchForm.vue";

import MunicipalityPicker from "./components/municipality-picker/MunicipalityPicker.vue";
import MunicipalityPickerInput from "./components/municipality-picker/MunicipalityPickerInput.vue";
import MunicipalityPickerModal from "./components/municipality-picker/MunicipalityPickerModal.vue";
import MunicipalityPickerList from "./components/municipality-picker/MunicipalityPickerList.vue";
import MunicipalityPickerSearchForm from "./components/municipality-picker/MunicipalityPickerSearchForm.vue";

import PartyPublicApi from "./api/public/party-public-api";
import PartyTagPublicApi from "./api/public/party-tag-public-api";
import PartyRegistryPlugin from "./PartyRegistryPlugin";

export { useApiResponseHandler } from "patri-common-ui/src/hooks/useApiResponseHandler";
export { useApiDeleteHandler } from "patri-common-ui/src/hooks/useApiDeleteHandler";

export type { RegistrySearchRequest } from "./models/RegistrySearchRequest";
export type { PartySearchResponse } from "./models/PartySearchResponseSchema";

export type { Tag } from "./models/tag/TagRequest";
export {
    TagResponseSchema,
    TagSearchResponseListSchema,
    TagResponseListSchema,
    TagRegistryResponseSchema,
    TagRegistrySearchResponseListSchema,
    type TagResponse,
    type TagSearchResponseList,
    type TagResponseList,
    type TagRegistrySearchResponse,
    type TagRegistrySearchResponseList,
} from "./models/tag/TagSearchResponseSchema";

export { PartyPublicApi, PartyTagPublicApi };

export { PartyPicker, PartyPickerModal, PartyPickerList, PartyPickerSearchForm };

export {
    MunicipalityPicker,
    MunicipalityPickerInput,
    MunicipalityPickerModal,
    MunicipalityPickerList,
    MunicipalityPickerSearchForm,
};

export { PartyRegistryPlugin };
