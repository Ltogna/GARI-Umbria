/// <reference types="vite/client" />

interface ImportMeta {
    readonly env: ImportMetaEnv;
}

interface ImportMetaEnv {
    readonly VITE_HOST: string;
    readonly VITE_REGISTRY_SERVICE: string;
    readonly VITE_TENNANT: string;
}
