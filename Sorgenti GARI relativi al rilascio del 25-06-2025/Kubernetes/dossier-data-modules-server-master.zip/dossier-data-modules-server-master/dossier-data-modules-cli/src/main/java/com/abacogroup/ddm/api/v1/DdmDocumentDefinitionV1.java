package com.abacogroup.ddm.api.v1;

import com.fasterxml.jackson.annotation.JsonGetter;
import java.util.List;
import java.util.Map;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Accessors(chain = true)
public class DdmDocumentDefinitionV1 {

	// TODO use DD dependency

	private String code;
	private String version;
	private String description;
	private Map<String, String> title;
	private Metadata metadata;
	private List<FieldSet> fieldSets;
	private List<Lookup> lookups;
	private List<RESTLookup> restLookups;
	private String bucketName;

	@Data
	@AllArgsConstructor
	@NoArgsConstructor
	@Accessors(chain = true)
	public static class ExtraPath {
		private String path;
		private Map<String, String> label;

		// Getters and setters
	}

	@Data
	@AllArgsConstructor
	@NoArgsConstructor
	@Accessors(chain = true)
	public static class Field {
		private String code;
		private boolean required;
		private Map<String, String> label;
		private String type;
		private FieldFormat format;
		private String style;
		private List<Help> help;
		private String lookupCode;
		private List<Validation> validation;

		// Getters and setters

		@JsonGetter("type")
		public String getJsonFieldType() {
			return null != type ? type.toLowerCase() : null;
		}
	}

	@Data
	@AllArgsConstructor
	@NoArgsConstructor
	@Accessors(chain = true)
	public static class FieldFormat {
		private int numDecimalDigits;

		// Getters and setters
	}

	@Data
	@AllArgsConstructor
	@NoArgsConstructor
	@Accessors(chain = true)
	public static class FieldSet {
		private String code;
		private int minOccurs;
		private int maxOccurs;
		private Map<String, String> label;
		private List<Field> fields;

		// Getters and setters
	}

	@Data
	@AllArgsConstructor
	@NoArgsConstructor
	@Accessors(chain = true)
	public static class Help {
		private Map<String, String> title;
		private Map<String, String> content;

		// Getters and setters
	}

	@Data
	@AllArgsConstructor
	@NoArgsConstructor
	@Accessors(chain = true)
	public static class Lookup {
		private String code;
		private List<LookupEntry> entries;

		// Getters and setters
	}

	@Data
	@AllArgsConstructor
	@NoArgsConstructor
	@Accessors(chain = true)
	public static class LookupEntry {
		private String code;
		private Map<String, String> label;

		// Getters and setters
	}

	@Data
	@AllArgsConstructor
	@NoArgsConstructor
	@Accessors(chain = true)
	public static class Metadata {
		private int maxOccurs;
		private boolean timeOverlap;
		private String defaultLocale;
		private String startDateField;
		private String endDateField;
		private List<String> summaryFields;

		// Getters and setters
	}

	@Data
	@AllArgsConstructor
	@NoArgsConstructor
	@Accessors(chain = true)
	public static class RESTLookup {
		private String code;
		private String url;
		private String detailsUrl;
		private String recordsPath;
		private String recordCodePath;
		private String labelPath;
		private List<ExtraPath> extraPaths;

		// Getters and setters
	}

	@Data
	@AllArgsConstructor
	@NoArgsConstructor
	@Accessors(chain = true)
	public static class Validation {
		private String formula;
		private String operator;
		private String expression;
		private Map<String, String> errorMessage;

		// Getters and setters
	}
}
