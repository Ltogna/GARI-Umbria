package com.abacogroup.ddm.heirs_special_case.api.v1;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder(setterPrefix = "set")
@NoArgsConstructor
@AllArgsConstructor
public class SuccessionTypeLookupResponseV1 {

	private String code;
	private String description; 

}
