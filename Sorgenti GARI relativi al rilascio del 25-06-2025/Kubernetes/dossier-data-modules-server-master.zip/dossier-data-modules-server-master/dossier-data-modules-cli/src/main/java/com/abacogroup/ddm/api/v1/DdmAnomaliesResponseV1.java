package com.abacogroup.ddm.api.v1;

import com.abacogroup.anomalyregistry.api.v1.AnomalySearchResponse;
import com.abacogroup.ddm.api.AnomalyLevelEnum;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonProperty.Access;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.media.SchemaProperties;
import io.swagger.v3.oas.annotations.media.SchemaProperty;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import lombok.AllArgsConstructor;
import lombok.Builder.Default;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder(setterPrefix = "set", toBuilder = true)
@NoArgsConstructor
@AllArgsConstructor
@SchemaProperties({
		@SchemaProperty(name = "INFO", array = @ArraySchema(schema = @Schema(ref = "#/components/schemas/AnomalySearchResponse"))),
		@SchemaProperty(name = "WARN", array = @ArraySchema(schema = @Schema(ref = "#/components/schemas/AnomalySearchResponse"))),
		@SchemaProperty(name = "DANGER", array = @ArraySchema(schema = @Schema(ref = "#/components/schemas/AnomalySearchResponse"))),
		@SchemaProperty(name = "count", schema = @Schema(implementation = Integer.class, description = "total anomaly count")),
		@SchemaProperty(name = "maxLevel", schema = @Schema(implementation = AnomalyLevelEnum.class, description = "max anomaly level")),
})
@JsonIgnoreProperties(value = {"count", "maxLevel"}, allowGetters = true)
public class DdmAnomaliesResponseV1 {

	@Default
	@JsonAnyGetter
	@JsonAnySetter
	@JsonProperty(access = Access.WRITE_ONLY)
	private Map<AnomalyLevelEnum, List<AnomalySearchResponse>> anomaliesGrouped = new HashMap<>();

	@JsonProperty(access = Access.READ_ONLY)
	public Integer getCount() {
		return anomaliesGrouped.values().stream()
				.reduce(0, (total, list) -> total + list.size(), Integer::sum);
	}

	@JsonProperty(access = Access.READ_ONLY)
	public AnomalyLevelEnum getMaxLevel() {
		return anomaliesGrouped.isEmpty() ? null : Collections.min(anomaliesGrouped.keySet(), Comparator.comparingInt(AnomalyLevelEnum::ordinal));
	}

	static class ListAnomalySearchResponse extends ArrayList<AnomalySearchResponse> {

	}
}
