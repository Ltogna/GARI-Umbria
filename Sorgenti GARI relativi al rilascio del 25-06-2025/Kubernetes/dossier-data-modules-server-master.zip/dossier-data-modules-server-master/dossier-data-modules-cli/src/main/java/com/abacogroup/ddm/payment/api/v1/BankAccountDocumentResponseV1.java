package com.abacogroup.ddm.payment.api.v1;

import com.abacogroup.ddm.api.v1.DocTypeRelationResponseV1.SummaryFieldDefinitionV1;
import java.util.LinkedHashMap;
import java.util.List;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@NoArgsConstructor
@SuperBuilder(setterPrefix = "set")
public class BankAccountDocumentResponseV1 {

	private Long bankAccountId;
	private String definitionCode;
	private Long documentId;

	private String bucketName;

	private List<SummaryFieldDefinitionV1> summaryFieldDefinitions;
	private LinkedHashMap<String, Object> data;

}
