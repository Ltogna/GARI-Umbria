package com.abacogroup.ddm.payment.api.v1;

import com.abacogroup.ddm.api.v1.DdmAnomaliesResponseV1;
import lombok.AllArgsConstructor;
import lombok.Builder.Default;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.experimental.SuperBuilder;

@Data
@EqualsAndHashCode(callSuper = true)
@ToString(callSuper = true)
@SuperBuilder(setterPrefix = "set")
@NoArgsConstructor
@AllArgsConstructor
public class BankAccountSearchResponseV1 extends BankAccountResponseV1 {

	@Default
	private DdmAnomaliesResponseV1 anomalies = new DdmAnomaliesResponseV1();

}
