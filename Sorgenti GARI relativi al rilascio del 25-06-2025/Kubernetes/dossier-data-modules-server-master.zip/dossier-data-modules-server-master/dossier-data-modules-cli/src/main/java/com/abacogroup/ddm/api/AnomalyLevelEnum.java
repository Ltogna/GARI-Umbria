package com.abacogroup.ddm.api;

import io.swagger.v3.oas.annotations.media.Schema;

@Schema(description = "The level of anomaly")
public enum AnomalyLevelEnum {
	DANGER,
	WARN,
	INFO
}
