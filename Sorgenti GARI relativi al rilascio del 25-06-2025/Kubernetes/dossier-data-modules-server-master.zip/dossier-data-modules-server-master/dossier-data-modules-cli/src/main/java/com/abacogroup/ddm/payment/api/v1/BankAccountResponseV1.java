package com.abacogroup.ddm.payment.api.v1;

import com.abacogroup.ddm.payment.api.BankNetworkEnum;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import lombok.AllArgsConstructor;
import lombok.Builder.Default;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder(setterPrefix = "set")
@NoArgsConstructor
@AllArgsConstructor
public class BankAccountResponseV1 {

	private Long id;

	private Long partyId; // TODO full dto?

	private BankNetworkEnum network;
	private String iban;

	private String swiftBic;
	private String bicExtraSepa;

	private String bankCountry;
	private String bankName;
	private String bankBranch;

	private String description;

	private Boolean defaultBankAccount;

	@Default
	private boolean active = true;

	private AbsoluteDate dayFrom;
	private AbsoluteDate dayTo;


}
