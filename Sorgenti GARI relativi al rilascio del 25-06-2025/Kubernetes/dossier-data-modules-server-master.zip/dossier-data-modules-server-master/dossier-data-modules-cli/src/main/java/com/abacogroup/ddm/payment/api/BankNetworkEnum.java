package com.abacogroup.ddm.payment.api;

public enum BankNetworkEnum {

	SEPA,
	SWIFT
}
