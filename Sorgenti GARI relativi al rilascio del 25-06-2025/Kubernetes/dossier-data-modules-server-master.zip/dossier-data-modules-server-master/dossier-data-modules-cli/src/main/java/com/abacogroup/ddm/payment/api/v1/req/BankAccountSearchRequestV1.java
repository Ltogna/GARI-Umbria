package com.abacogroup.ddm.payment.api.v1.req;

import com.abacogroup.ddm.payment.api.BankNetworkEnum;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import jakarta.validation.constraints.NotNull;
import jakarta.ws.rs.DefaultValue;
import jakarta.ws.rs.QueryParam;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

@Data
@NoArgsConstructor
@Accessors(chain = true)
public class BankAccountSearchRequestV1 {

	@NotNull
	@Parameter(in = ParameterIn.QUERY, description = "Visualizzazione Conti Correnti (obbligatorio)")
	@DefaultValue("all")
	@QueryParam("active")
	private ActiveEnum active = ActiveEnum.all;

	@Parameter(in = ParameterIn.QUERY, description = "IBAN/Numero Conto (facoltativo)")
	@QueryParam("iban")
	private String iban;

	@Parameter(in = ParameterIn.QUERY, description = "Area/Rete (facoltativo)")
	@QueryParam("network")
	private BankNetworkEnum network;

	@Parameter(in = ParameterIn.QUERY, description = "Descrizione")
	@QueryParam("description")
	private String description;

}
