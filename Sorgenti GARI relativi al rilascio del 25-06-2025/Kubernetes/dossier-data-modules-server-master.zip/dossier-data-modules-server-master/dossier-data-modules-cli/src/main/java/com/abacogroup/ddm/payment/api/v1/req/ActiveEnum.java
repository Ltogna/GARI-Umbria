package com.abacogroup.ddm.payment.api.v1.req;

public enum ActiveEnum {
	all,
	only_active,
	not_active
}
