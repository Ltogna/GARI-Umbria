package com.abacogroup.ddm.resources;

public interface PublicResourceConstants {
    String API_V1_PUB = "/{tenant}/public/v1";

    String PAYMENT_MODULE_API_V1_PUB = API_V1_PUB + "/payment-methods";
    String HEIR_MODULE_API_V1_PUB = API_V1_PUB + "/heirs-methods";
}
