# Oracle Docker Compose


```
    <dependency>
      <groupId>com.oracle.database.jdbc</groupId>
      <artifactId>ojdbc8</artifactId>
      <version>12.2.0.1</version>
    </dependency>
```


For terminal:

```
sudo docker login docker-registry.fe.abacogroup.eu
```

The terminal will ask for user and password.
Please, give your Abaco maven credentials
(you probably have them in `/home/<your-user>/.m2` folder, in settings.xml file)

```
sudo docker-compose -f oracle_docker-compose.yml up
``` 

Once the "compose" is up, connect with a database client (Dbeaver for example)

```
Host: localhost
Port: 31521
Database: ORCLPDB1 (Service Name)
Authentication: Oracle Database Native
Username: test
Password: test
```
