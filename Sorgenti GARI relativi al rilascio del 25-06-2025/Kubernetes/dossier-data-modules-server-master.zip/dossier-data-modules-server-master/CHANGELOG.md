# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [v2.0.5](https://gitlab.fe.abacogroup.eu/new-agri/dossier-data-modules-server/compare/v2.0.4...v2.0.5) (2025-05-15)

### Other

* :arrow_up: upgrade file-store-client version to 4.5.0

## [v2.0.4](https://gitlab.fe.abacogroup.eu/new-agri/dossier-data-modules-server/compare/v2.0.3...v2.0.4) (2025-05-08)

### Other

* :arrow_up: upgrade dropwizard version to 4.0.6

## [v2.0.3](https://gitlab.fe.abacogroup.eu/new-agri/dossier-data-modules-server/compare/v2.0.2...v2.0.3) (2025-05-06)

### Fixes

* :bug: fixed some heirs document issues, closes [#173748](https://abacogroup.easyredmine.com/issues/173748), [#173864](https://abacogroup.easyredmine.com/issues/173864)

## [v2.0.2](https://gitlab.fe.abacogroup.eu/new-agri/dossier-data-modules-server/compare/v2.0.1...v2.0.2) (2025-04-29)

### Fixes

* :bug: fixed some heirs dynamic document field names

## [v2.0.1](https://gitlab.fe.abacogroup.eu/new-agri/dossier-data-modules-server/compare/v2.0.0...v2.0.1) (2025-04-29)

### Other

* :arrow_up: update dynamic-doc version to v5.4.2

## [v2.0.0](https://gitlab.fe.abacogroup.eu/new-agri/dossier-data-modules-server/compare/v1.0.10...v2.0.0) (2025-04-22) Heirs module

### Features

* :sparkles: implementation of heirs module, closes [#164627](https://abacogroup.easyredmine.com/issues/164627)

### Other

* :recycle: some refactor
* :arrow_up: upgrade lombok version to v1.18.32
* :arrow_up: upgrade dynamic document version to v5.4.1

### Documentation

* :memo: update README.md


## [1.0.10] - 2025-01-22

### Fixed

- Fixed sonar agea issues


## [1.0.9] - 2024-12-04

### Fixed

- Fixed getDocumentFileContent API response consume decorator to MediaType WILDCARD

## [1.0.8] - 2024-12-04

### Fixed

- Fixed getDocumentFileContent API response produce decorator to MediaType APPLICATION_OCTET_STREAM

## [1.0.7] - 2024-11-19

### Fixed

- Remove old VineAuthorizationDoIgtQuotasAndAptitudesConfig in favour of TreeUnitsValidation for vine, fruit, 
and olive tenant

 ## [1.0.6] - 2024-11-19

### Added

- Added TreeUnit "units" configuration class

## [1.0.5] - 2024-11-07

### Fixed

- Fixed (Aptitudes, DoIgtQuota, Authorization) change nextKey from snake_case to camelCase
- Fixed (Aptitudes, DoIgtQuota, Authorization) increase timeout to JerseyClient

## [1.0.4] - 2024-11-05

### Removed

- Remove pods url obfuscation from AppConfigResource.getByKey since they are not to be considered sensitive data

## [1.0.3] - 2024-11-05

### Changed

- Fixed configuration APIs context|functions [#155673](https://abacogroup.easyredmine.com/issues/155673)

## [1.0.2] - 2024-10-24

### Added

- Added API for getting list of party ids given the iban [#154726](https://abacogroup.easyredmine.com/issues/154726)

## [1.0.1] - 2024-10-22

### Added

- Added sso-server-2 context functions in bundles folder for bundles producer

## [1.0.0] - 2024-10-21

### Changed

- Changed APIs context|functions

## [0.1.10]

- First release
