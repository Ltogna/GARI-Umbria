
# ✨ DOSSIER DATA MODULES ✨ #

## [dossier-data-modules-api](dossier-data-modules-api/README.md) ##
- ### [openapi](dossier-data-modules-api/docs/openapi.yaml) ###
- ### [bundles](dossier-data-modules-api/README.md#bundles-infrastructure-integration-) ###

## SSO context|function
The allowed SSO contexzt|function are:
- DDM_DOSSIER|VIEWER:
  - it enables the user to the dossier data module: aptitudes, authorizations and do-igt quota
- DDM_PAYMENT_METHODS|VIEWER:
  - it grants access to the payment methods dossier data module
- DDM_PAYMENT_METHODS|EDITOR:
  - it grants editor functions to the payment methods dossier data module
- DDM_HEIR_METHODS|VIEWER:
  - it grants access to the heir methods dossier data module
- DDM_HEIR_METHODS|EDITOR:
  - it grants editor functions to the heir methods dossier data module