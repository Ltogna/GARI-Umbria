insert into ddm_doc_type_relations (pkid, tenant_id, definition_code, namespace, fl_required,
                                    dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-1, :test_tenant, 'DD_1', 'payment', 1,
        to_date('19700101', 'YYYYMMDD'), :user_id, to_date('99991231', 'YYYYMMDD'), null);

insert into ddm_doc_type_relations (pkid, tenant_id, definition_code, namespace, fl_required,
                                    dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-2, :test_tenant, 'DD_2', 'payment', 0,
        to_date('19700101', 'YYYYMMDD'), :user_id, to_date('99991231', 'YYYYMMDD'), null);

insert into ddm_doc_type_relations (pkid, tenant_id, definition_code, namespace, fl_required,
                                    dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-3, :test_tenant, 'DD_3', 'payment', 0,
        to_date('19700101', 'YYYYMMDD'), :user_id, to_date('99991231', 'YYYYMMDD'), null);

-- other service
insert into ddm_doc_type_relations (pkid, tenant_id, definition_code, namespace, fl_required,
                                    dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-99, :test_tenant, 'DD_99', 'OTHER', 0,
        to_date('19700101', 'YYYYMMDD'), :user_id, to_date('99991231', 'YYYYMMDD'), null);


------------------

insert into ddm_i18n_values (tenant_id, table_name, field_name, i18n_value, lang, i18n_text)
values (:test_tenant, 'ddm_doc_type_relations', 'definition_code', 'DD_1', 'en', 'Di Di One');

insert into ddm_i18n_values (tenant_id, table_name, field_name, i18n_value, lang, i18n_text)
values (:test_tenant, 'ddm_doc_type_relations', 'definition_code', 'DD_2', 'en', 'Di Di Two');
