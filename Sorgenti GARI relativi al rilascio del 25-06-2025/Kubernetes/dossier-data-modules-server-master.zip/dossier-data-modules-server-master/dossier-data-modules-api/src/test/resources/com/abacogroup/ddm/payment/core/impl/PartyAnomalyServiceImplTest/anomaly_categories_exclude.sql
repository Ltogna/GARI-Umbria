
insert into ddm_anomaly_categories (tenant_id, namespace, group_code, code, "level", fl_exclude)
values (:test_tenant, 'payment', 'dossier-data-modules-server.payment.account', 'CC_PRED', 'INFO', 1);

