insert into ddm_anomaly_categories (tenant_id, namespace, group_code, code, "level", fl_exclude)
values (:test_tenant, 'payment', 'dossier-data-modules-server.payment.account', 'NO_CC', 'WARN', 0);
insert into ddm_anomaly_categories (tenant_id, namespace, group_code, code, "level", fl_exclude)
values (:test_tenant, 'payment', 'dossier-data-modules-server.payment.account', 'CC_PRED', 'INFO', 0);
insert into ddm_anomaly_categories (tenant_id, namespace, group_code, code, "level", fl_exclude)
values (:test_tenant, 'payment', 'dossier-data-modules-server.payment.account', '915', 'WARN', 0);
insert into ddm_anomaly_categories (tenant_id, namespace, group_code, code, "level", fl_exclude)
values (:test_tenant, 'payment', 'dossier-data-modules-server.payment.dynamic-documents', 'ATTO', 'WARN', 0);
