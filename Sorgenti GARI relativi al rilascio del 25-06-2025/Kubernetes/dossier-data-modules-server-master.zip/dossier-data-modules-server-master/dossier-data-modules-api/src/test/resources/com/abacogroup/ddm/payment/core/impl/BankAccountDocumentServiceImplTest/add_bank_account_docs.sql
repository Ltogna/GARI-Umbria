insert into ddm_bank_account_documents (pkid, bank_account_id, definition_code, document_id,
                                        dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-10101, -1, 'DD_1', 90101,
        to_date('19700101', 'YYYYMMDD'), :user_id, to_date('99991231', 'YYYYMMDD'), null);

insert into ddm_bank_account_documents (pkid, bank_account_id, definition_code, document_id,
                                        dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-10102, -1, 'DD_2', 90102,
        to_date('19700101', 'YYYYMMDD'), :user_id, to_date('99991231', 'YYYYMMDD'), null);



