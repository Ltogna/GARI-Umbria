insert into ddm_anomaly_categories (tenant_id, namespace, group_code, code, "level", fl_exclude)
values ('*', 'payment', 'test', '01', 'INFO', 0);
insert into ddm_anomaly_categories (tenant_id, namespace, group_code, code, "level", fl_exclude)
values ('*', 'payment', 'test', '02', 'WARN', 0);
insert into ddm_anomaly_categories (tenant_id, namespace, group_code, code, "level", fl_exclude)
values ('*', 'payment', 'test', '03', 'DANGER', 0);
insert into ddm_anomaly_categories (tenant_id, namespace, group_code, code, "level", fl_exclude)
values ('*', 'payment', 'test', '00', 'INFO', 1);
