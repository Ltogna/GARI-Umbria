insert into ddm_doc_type_relations (pkid, tenant_id, definition_code, namespace, fl_required,
                                    dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-1, :test_tenant, 'DD_1', 'payment', 1,
        to_date('19700101', 'YYYYMMDD'), :user_id, to_date('99991231', 'YYYYMMDD'), null);

insert into ddm_doc_type_relations (pkid, tenant_id, definition_code, namespace, fl_required,
                                    dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-2, :test_tenant, 'DD_2', 'payment', 0,
        to_date('19700101', 'YYYYMMDD'), :user_id, to_date('99991231', 'YYYYMMDD'), null);


