INSERT INTO ddm_bank_account (id, tenant_id, party_id)
VALUES (-1, :test_tenant, 555);
INSERT INTO ddm_bank_account_detail (pkid, id, network, iban, swift_bic, bic_extra_sepa,
                                            bank_country, bank_name, bank_branch, description, fl_default, day_from, day_to,
                                            dt_insert, user_id_insert, dt_delete, user_id_delete)
VALUES (-1, -1, 'SEPA', 'IT47Y0300203280177188245251', 'UNCRITMMXXX', 'AABBCC',
        'Italy (IT)', 'UNICREDIT BANCA DI ROMA SPA', 'ROMA 80 - PIAZZA MONTE', 'CC test', 1, '20200202', '99991231',
        to_date('20231016', 'YYYYMMDD'), :user_id, to_date('99991231', 'YYYYMMDD'), null);

INSERT INTO ddm_bank_account (id, tenant_id, party_id)
VALUES (-2, :test_tenant, 555);
INSERT INTO ddm_bank_account_detail (pkid, id, network, iban, swift_bic, bic_extra_sepa,
                                            bank_country, bank_name, bank_branch, description, fl_default, day_from, day_to,
                                            dt_insert, user_id_insert, dt_delete, user_id_delete)
VALUES (-2, -2, 'SEPA', 'GB80BARC20040162398845', 'BARCGB22', null,
        'GB', 'BARCLAYS BANK UK PLC', 'Dept MZ\nRemittances Unpaid\nThynne Street\nBolton BL1 1XX', 'CC test 2', 0, '20211202', '99991231',
        to_date('20231016', 'YYYYMMDD'), :user_id, to_date('99991231', 'YYYYMMDD'), null);



INSERT INTO ddm_bank_account (id, tenant_id, party_id)
VALUES (-3, :test_tenant, 666);
INSERT INTO ddm_bank_account_detail (pkid, id, network, iban, swift_bic, bic_extra_sepa,
                                     bank_country, bank_name, bank_branch, description, fl_default, day_from, day_to,
                                     dt_insert, user_id_insert, dt_delete, user_id_delete)
VALUES (-3, -3, 'SEPA', 'GB80BARC20040162398845', 'BARCGB22', null,
        'GB', 'BARCLAYS BANK UK PLC', 'Dept MZ\nRemittances Unpaid\nThynne Street\nBolton BL1 1XX', 'CC test 3', 0, '20211202', '99991231',
        to_date('20231016', 'YYYYMMDD'), :user_id, to_date('99991231', 'YYYYMMDD'), null);



INSERT INTO ddm_bank_account (id, tenant_id, party_id)
VALUES (-4, :test_tenant, 777);
INSERT INTO ddm_bank_account_detail (pkid, id, network, iban, swift_bic, bic_extra_sepa,
                                     bank_country, bank_name, bank_branch, description, fl_default, day_from, day_to,
                                     dt_insert, user_id_insert, dt_delete, user_id_delete)
VALUES (-4, -4, 'SEPA', 'GB80BARC20040162398845', null, null,
        'GB', 'BARCLAYS BANK UK PLC', 'Dept MZ\nRemittances Unpaid\nThynne Street\nBolton BL1 1XX', 'CC test 4', 0, '20211202', '99991231',
        to_date('20231016', 'YYYYMMDD'), :user_id, to_date('99991231', 'YYYYMMDD'), null);



INSERT INTO ddm_bank_account (id, tenant_id, party_id)
VALUES (-5, :test_tenant, 888);
INSERT INTO ddm_bank_account_detail (pkid, id, network, iban, swift_bic, bic_extra_sepa,
                                     bank_country, bank_name, bank_branch, description, fl_default, day_from, day_to,
                                     dt_insert, user_id_insert, dt_delete, user_id_delete)
VALUES (-5, -5, 'SEPA', 'NL28ABNA3518588532', 'ABNANL2AXXX', null,
        'Netherlands (NL)', 'ABN AMRO BANK N.V.', null, 'CC test 5', 0, '20111102', '20211202',
        to_date('20231016', 'YYYYMMDD'), :user_id, to_date('99991231', 'YYYYMMDD'), null);



INSERT INTO ddm_bank_account (id, tenant_id, party_id)
VALUES (-6, :test_tenant, 999);
INSERT INTO ddm_bank_account_detail (pkid, id, network, iban, swift_bic, bic_extra_sepa,
                                     bank_country, bank_name, bank_branch, description, fl_default, day_from, day_to,
                                     dt_insert, user_id_insert, dt_delete, user_id_delete)
VALUES (-6, -6, 'SEPA', 'NL28ABNA3518588532', 'ABNANL2AXXX', null,
        'Netherlands (NL)', 'ABN AMRO BANK N.V.', null, 'CC test 6', 1, '20111102', '99991231',
        to_date('20231016', 'YYYYMMDD'), :user_id, to_date('99991231', 'YYYYMMDD'), null);

