insert into ddm_app_configuration (id, tenant_id, configuration_key, configuration,
                                   dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-1, :test_tenant, 'payment_regex_validation', '{"regexes":["[A-Z]+"]}',
        TO_DATE('19700101', 'YYYYMMDD'), :user_id, TO_DATE('99991231', 'YYYYMMDD'), null);
