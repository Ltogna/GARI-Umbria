insert into ddm_bank_account_documents (pkid, bank_account_id, definition_code, document_id,
                                        dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-10101, -1, 'DD_1', 90101,
        to_date('19700101', 'YYYYMMDD'), :user_id, to_date('99991231', 'YYYYMMDD'), null);


insert into ddm_bank_account_documents (pkid, bank_account_id, definition_code, document_id,
                                        dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-10202, -2, 'DD_2', 90202,
        to_date('19700101', 'YYYYMMDD'), :user_id, to_date('99991231', 'YYYYMMDD'), null);


insert into ddm_bank_account_documents (pkid, bank_account_id, definition_code, document_id,
                                        dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-10602, -6, 'DD_2', 90602,
        to_date('19700101', 'YYYYMMDD'), :user_id, to_date('99991231', 'YYYYMMDD'), null);

insert into ddm_bank_account_documents (pkid, bank_account_id, definition_code, document_id,
                                        dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-10601, -6, 'DD_1', 90601,
        to_date('19700101', 'YYYYMMDD'), :user_id, to_date('99991231', 'YYYYMMDD'), null);




