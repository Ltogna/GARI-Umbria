package com.abacogroup.ddm.common;

import com.abacogroup.ddm.common.resources.ReqContext;
import java.util.Map;

public class ReqContextUtils {

	private final Class<?> aClass;
	public ReqContextUtils(Class<?> aClass) {
		this.aClass = aClass;
	}

	public  String getTenantId() {
		return String.format("%s_t", aClass.getSimpleName());
	}
	public  String getUserId() {
		return String.format("%s_u", aClass.getSimpleName());
	}

	public  final Map<String, Object> getTestScriptParams () {
		return Map.of(
				"test_tenant", getTenantId(),
				"user_id", getUserId()
		);
	}

	public  ReqContext getReqContext() {
		return new ReqContext(getTenantId(), getUserId(), "en");
	}
}
