package com.abacogroup.ddm.payment.core.impl;

import static com.abacogroup.ddm.payment.core.impl.AnomalyHelper.ANM_TYPE_915;
import static com.abacogroup.ddm.payment.core.impl.AnomalyHelper.ANM_TYPE_ATTO;
import static com.abacogroup.ddm.payment.core.impl.AnomalyHelper.ANM_TYPE_CC_PRED;
import static com.abacogroup.ddm.payment.core.impl.AnomalyHelper.ANM_TYPE_NO_CC;
import static com.abacogroup.ddm.payment.core.impl.AnomalyHelper.BANK_ACCOUNT_CODE;
import static com.abacogroup.ddm.payment.core.impl.AnomalyHelper.PARTY_ENTITY_CODE;
import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.tuple;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.ArgumentMatchers.notNull;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.verify;

import com.abacogroup.anomalyregistry.api.v1.req.AnomalyRequest;
import com.abacogroup.anomalyregistry.core.cli.v1.AnomalyClient;
import com.abacogroup.ddm.common.JdbiTest;
import com.abacogroup.ddm.common.ReqContextUtils;
import com.abacogroup.ddm.db.dao.DocTypeRelationDAO;
import com.abacogroup.ddm.db.ntt.DocTypeRelationEntity;
import com.abacogroup.ddm.payment.db.dao.BankAccountDAO;
import com.abacogroup.ddm.payment.db.dao.BankAccountDocumentDAO;
import com.abacogroup.ddm.payment.db.ntt.BankAccountDocumentEntity;
import com.abacogroup.ddm.payment.db.ntt.BankAccountEntity;
import com.abacogroup.dynamicdocuments.bean.Document;
import com.abacogroup.dynamicdocuments.services.DocumentService;
import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;
import java.time.Clock;
import java.time.OffsetDateTime;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;

@ExtendWith(DropwizardExtensionsSupport.class)
class AnomalyHelperTest extends JdbiTest {

	private final AnomalyClient anomalyClient = mock(AnomalyClient.class);
	private final Clock appClock = spy(Clock.systemDefaultZone());

	private ReqContextUtils ctx = new ReqContextUtils(this.getClass());

	// ----- pushAnomalies -----
	@Test
	void test_pushAnomalies_NO_CC_ok() {

		setUnusedBindingAllowed(true);
		getJdbi().useHandle(handle -> {
			handle.begin();

			execSqlFiles(this.getClass(), List.of(
					"add_bank_accounts"
			), ctx.getTestScriptParams());

			Long partyId = 555L;
			BankAccountDAO bankAccountDAO = handle.attach(BankAccountDAO.class);

			AnomalyHelper.newInstance(anomalyClient, ctx.getReqContext(), appClock)
					.tryAddNoCC(bankAccountDAO, 444L) // add
					.tryAddNoCC(bankAccountDAO, 555L) // skip
					.expireNoCC(555L) // expire
					.pushAnomalies();

			ArgumentCaptor<List<AnomalyRequest>> anomalyReqCaptor = ArgumentCaptor.forClass(List.class);
			verify(anomalyClient).add(eq(ctx.getReqContext().getLang()), eq(ctx.getReqContext().getUser()),
					anomalyReqCaptor.capture());
			verify(anomalyClient).expire(eq(ctx.getReqContext().getLang()), eq(ctx.getReqContext().getUser()),
					anomalyReqCaptor.capture());

			List<AnomalyRequest> added = anomalyReqCaptor.getAllValues().get(0);
			assertThat(added).hasSize(1)
					.extracting(AnomalyRequest::getEntityCode, AnomalyRequest::getEntityId, AnomalyRequest::getTypeCode)
					.containsExactlyInAnyOrder(tuple(PARTY_ENTITY_CODE, "444", ANM_TYPE_NO_CC));

			List<AnomalyRequest> expired = anomalyReqCaptor.getAllValues().get(1);
			assertThat(expired).hasSize(1)
					.extracting(AnomalyRequest::getEntityCode, AnomalyRequest::getEntityId, AnomalyRequest::getTypeCode)
					.containsExactlyInAnyOrder(tuple(PARTY_ENTITY_CODE, "555", ANM_TYPE_NO_CC));

			handle.rollback();
		});

	}

	@Test
	void test_pushAnomalies_recalculate_NO_CC_ok() {

		setUnusedBindingAllowed(true);
		getJdbi().useHandle(handle -> {
			handle.begin();

			execSqlFiles(this.getClass(), List.of(
					"add_bank_accounts"
			), ctx.getTestScriptParams());

			Long partyId = 555L;
			BankAccountDAO bankAccountDAO = handle.attach(BankAccountDAO.class);

			AnomalyHelper.newInstance(anomalyClient, ctx.getReqContext(), appClock)
					.recalculateNoCC(bankAccountDAO, 444L) // add
					.recalculateNoCC(bankAccountDAO, 555L) // expire
					.recalculateNoCC(bankAccountDAO, 888L) // add
					.pushAnomalies();

			ArgumentCaptor<List<AnomalyRequest>> anomalyReqCaptor = ArgumentCaptor.forClass(List.class);
			verify(anomalyClient).add(eq(ctx.getReqContext().getLang()), eq(ctx.getReqContext().getUser()),
					anomalyReqCaptor.capture());
			verify(anomalyClient).expire(eq(ctx.getReqContext().getLang()), eq(ctx.getReqContext().getUser()),
					anomalyReqCaptor.capture());

			List<AnomalyRequest> added = anomalyReqCaptor.getAllValues().get(0);
			assertThat(added).hasSize(2)
					.extracting(AnomalyRequest::getEntityCode, AnomalyRequest::getEntityId, AnomalyRequest::getTypeCode)
					.containsExactlyInAnyOrder(
							tuple(PARTY_ENTITY_CODE, "444", ANM_TYPE_NO_CC),
							tuple(PARTY_ENTITY_CODE, "888", ANM_TYPE_NO_CC)
					);

			List<AnomalyRequest> expired = anomalyReqCaptor.getAllValues().get(1);
			assertThat(expired).hasSize(1)
					.extracting(AnomalyRequest::getEntityCode, AnomalyRequest::getEntityId, AnomalyRequest::getTypeCode)
					.containsExactlyInAnyOrder(tuple(PARTY_ENTITY_CODE, "555", ANM_TYPE_NO_CC));

			handle.rollback();
		});

	}

	@Test
	void test_pushAnomalies_CC_PRED_ok() {

		setUnusedBindingAllowed(true);
		getJdbi().useHandle(handle -> {
			handle.begin();

			execSqlFiles(this.getClass(), List.of(
					"add_bank_accounts"
			), ctx.getTestScriptParams());

			BankAccountDAO bankAccountDAO = handle.attach(BankAccountDAO.class);

			AnomalyHelper.newInstance(anomalyClient, ctx.getReqContext(), appClock)
					.tryAddCCPred(bankAccountDAO, 666L) // add
					.tryAddCCPred(bankAccountDAO, 555L) // skip
					.tryExpireCCPred(BankAccountEntity.builder().setPartyId(444L).setFlDefault(1).build()) // expire
					.tryExpireCCPred(BankAccountEntity.builder().setPartyId(333L).setFlDefault(0).build()) // skip
					.pushAnomalies();

			ArgumentCaptor<List<AnomalyRequest>> anomalyReqCaptor = ArgumentCaptor.forClass(List.class);
			verify(anomalyClient).add(eq(ctx.getReqContext().getLang()), eq(ctx.getReqContext().getUser()),
					anomalyReqCaptor.capture());
			verify(anomalyClient).expire(eq(ctx.getReqContext().getLang()), eq(ctx.getReqContext().getUser()),
					anomalyReqCaptor.capture());

			List<AnomalyRequest> added = anomalyReqCaptor.getAllValues().get(0);
			assertThat(added).hasSize(1)
					.extracting(AnomalyRequest::getEntityCode, AnomalyRequest::getEntityId, AnomalyRequest::getTypeCode)
					.containsExactlyInAnyOrder(tuple(PARTY_ENTITY_CODE, "666", ANM_TYPE_CC_PRED));

			List<AnomalyRequest> expired = anomalyReqCaptor.getAllValues().get(1);
			assertThat(expired).hasSize(1)
					.extracting(AnomalyRequest::getEntityCode, AnomalyRequest::getEntityId, AnomalyRequest::getTypeCode)
					.containsExactlyInAnyOrder(tuple(PARTY_ENTITY_CODE, "444", ANM_TYPE_CC_PRED));

			handle.rollback();
		});

	}

	@Test
	void test_pushAnomalies_recalculate_CC_PRED_ok() {

		setUnusedBindingAllowed(true);
		getJdbi().useHandle(handle -> {
			handle.begin();

			execSqlFiles(this.getClass(), List.of(
					"add_bank_accounts"
			), ctx.getTestScriptParams());

			BankAccountDAO bankAccountDAO = handle.attach(BankAccountDAO.class);

			AnomalyHelper.newInstance(anomalyClient, ctx.getReqContext(), appClock)
					.recalculateCCPred(bankAccountDAO, 666L) // add
					.recalculateCCPred(bankAccountDAO, 555L) // expire
					.recalculateCCPred(bankAccountDAO, 444L) // skip
					.recalculateCCPred(bankAccountDAO, 888L) // skip
					.pushAnomalies();

			ArgumentCaptor<List<AnomalyRequest>> anomalyReqCaptor = ArgumentCaptor.forClass(List.class);
			verify(anomalyClient).add(eq(ctx.getReqContext().getLang()), eq(ctx.getReqContext().getUser()),
					anomalyReqCaptor.capture());
			verify(anomalyClient).expire(eq(ctx.getReqContext().getLang()), eq(ctx.getReqContext().getUser()),
					anomalyReqCaptor.capture());

			List<AnomalyRequest> added = anomalyReqCaptor.getAllValues().get(0);
			assertThat(added).hasSize(1)
					.extracting(AnomalyRequest::getEntityCode, AnomalyRequest::getEntityId, AnomalyRequest::getTypeCode)
					.containsExactlyInAnyOrder(tuple(PARTY_ENTITY_CODE, "666", ANM_TYPE_CC_PRED));

			List<AnomalyRequest> expired = anomalyReqCaptor.getAllValues().get(1);
			assertThat(expired).hasSize(1)
					.extracting(AnomalyRequest::getEntityCode, AnomalyRequest::getEntityId, AnomalyRequest::getTypeCode)
					.containsExactlyInAnyOrder(tuple(PARTY_ENTITY_CODE, "555", ANM_TYPE_CC_PRED));

			handle.rollback();
		});

	}

	@Test
	void test_pushAnomalies_915_ok() {

		setUnusedBindingAllowed(true);
		getJdbi().useHandle(handle -> {
			handle.begin();

			execSqlFiles(this.getClass(), List.of(
					"add_bank_accounts"
			), ctx.getTestScriptParams());

			BankAccountDAO bankAccountDAO = handle.attach(BankAccountDAO.class);

			AnomalyHelper.newInstance(anomalyClient, ctx.getReqContext(), appClock)
					.tryAdd195(bankAccountDAO, BankAccountEntity.builder().setId(-1L)
							.setIban("IT47Y0300203280177188245251").setSwiftBic("UNCRITMMXXX").setBicExtraSepa("AABBCC").build()) // skip
					.tryAdd195(bankAccountDAO, BankAccountEntity.builder().setId(4L)
							.setIban("IT47Y0300203280177188245251").setSwiftBic("UNCRITMMXXX").build()) // skip
					.tryAdd195(bankAccountDAO, BankAccountEntity.builder().setId(-2L)
							.setIban("GB80BARC20040162398845").setSwiftBic("BARCGB22").build()) // add -2 -3
					.expire195(bankAccountDAO, BankAccountEntity.builder().setId(1L)
							.setIban("IT47Y0300203280177188245251").setSwiftBic("UNCRITMMXXX").setBicExtraSepa("AABBCC").build()) // expire 1 -1
					.expire195(bankAccountDAO, BankAccountEntity.builder().setId(2L)
							.setIban("GB80BARC20040162398845").setSwiftBic("BARCGB22").build()) // expire 2
					.expire195(bankAccountDAO, BankAccountEntity.builder().setId(3L)
							.setIban("IT47Y0300203280177188245251").setBicExtraSepa("AABBCC").build()) // expire 3
					.pushAnomalies();

			ArgumentCaptor<List<AnomalyRequest>> anomalyReqCaptor = ArgumentCaptor.forClass(List.class);
			verify(anomalyClient).add(eq(ctx.getReqContext().getLang()), eq(ctx.getReqContext().getUser()),
					anomalyReqCaptor.capture());
			verify(anomalyClient).expire(eq(ctx.getReqContext().getLang()), eq(ctx.getReqContext().getUser()),
					anomalyReqCaptor.capture());

			List<AnomalyRequest> added = anomalyReqCaptor.getAllValues().get(0);
			assertThat(added).hasSize(2)
					.extracting(AnomalyRequest::getEntityCode, AnomalyRequest::getEntityId, AnomalyRequest::getTypeCode)
					.containsExactlyInAnyOrder(
							tuple(BANK_ACCOUNT_CODE, "-2", ANM_TYPE_915),
							tuple(BANK_ACCOUNT_CODE, "-3", ANM_TYPE_915)
					);

			List<AnomalyRequest> expired = anomalyReqCaptor.getAllValues().get(1);
			assertThat(expired).hasSize(4)
					.extracting(AnomalyRequest::getEntityCode, AnomalyRequest::getEntityId, AnomalyRequest::getTypeCode)
					.containsExactlyInAnyOrder(
							tuple(BANK_ACCOUNT_CODE, "1", ANM_TYPE_915),
							tuple(BANK_ACCOUNT_CODE, "-1", ANM_TYPE_915),
							tuple(BANK_ACCOUNT_CODE, "2", ANM_TYPE_915),
							tuple(BANK_ACCOUNT_CODE, "3", ANM_TYPE_915)
					);

			handle.rollback();
		});

	}

	@Test
	void test_pushAnomalies_recalculate_915_ok() {

		setUnusedBindingAllowed(true);
		getJdbi().useHandle(handle -> {
			handle.begin();

			execSqlFiles(this.getClass(), List.of(
					"add_bank_accounts"
			), ctx.getTestScriptParams());

			BankAccountDAO bankAccountDAO = handle.attach(BankAccountDAO.class);

			AnomalyHelper.newInstance(anomalyClient, ctx.getReqContext(), appClock)
					.recalculate195(bankAccountDAO, bankAccountDAO.findById(ctx.getTenantId(), -1L).orElseThrow()) // expire
					.recalculate195(bankAccountDAO, bankAccountDAO.findById(ctx.getTenantId(), -2L).orElseThrow()) // add -2 -3
					.recalculate195(bankAccountDAO, bankAccountDAO.findById(ctx.getTenantId(), -6L).orElseThrow()) // expire
					.pushAnomalies();

			ArgumentCaptor<List<AnomalyRequest>> anomalyReqCaptor = ArgumentCaptor.forClass(List.class);
			verify(anomalyClient).add(eq(ctx.getReqContext().getLang()), eq(ctx.getReqContext().getUser()),
					anomalyReqCaptor.capture());
			verify(anomalyClient).expire(eq(ctx.getReqContext().getLang()), eq(ctx.getReqContext().getUser()),
					anomalyReqCaptor.capture());

			List<AnomalyRequest> added = anomalyReqCaptor.getAllValues().get(0);
			assertThat(added).hasSize(2)
					.extracting(AnomalyRequest::getEntityCode, AnomalyRequest::getEntityId, AnomalyRequest::getTypeCode)
					.containsExactlyInAnyOrder(
							tuple(BANK_ACCOUNT_CODE, "-2", ANM_TYPE_915),
							tuple(BANK_ACCOUNT_CODE, "-3", ANM_TYPE_915)
					);

			List<AnomalyRequest> expired = anomalyReqCaptor.getAllValues().get(1);
			assertThat(expired).hasSize(2)
					.extracting(AnomalyRequest::getEntityCode, AnomalyRequest::getEntityId, AnomalyRequest::getTypeCode)
					.containsExactlyInAnyOrder(
							tuple(BANK_ACCOUNT_CODE, "-1", ANM_TYPE_915),
							tuple(BANK_ACCOUNT_CODE, "-6", ANM_TYPE_915)
					);

			handle.rollback();
		});

	}

	@Test
	void test_pushAnomalies_ATTO_ok() {

		setUnusedBindingAllowed(true);
		getJdbi().useHandle(handle -> {
			handle.begin();

			execSqlFiles(this.getClass(), List.of(
					"add_bank_accounts",
					"add_doc_type_rel",
					"add_bank_account_docs"
			), ctx.getTestScriptParams());

			DocTypeRelationDAO docTypeRelationDAO = handle.attach(DocTypeRelationDAO.class);
			BankAccountDocumentDAO bankAccountDocumentDAO = handle.attach(BankAccountDocumentDAO.class);

			AnomalyHelper.newInstance(anomalyClient, ctx.getReqContext(), appClock)
					.tryAddAtto(docTypeRelationDAO, -3L) // add
					.tryAddAtto(docTypeRelationDAO, bankAccountDocumentDAO, -1L) // skip
					.tryAddAtto(docTypeRelationDAO, bankAccountDocumentDAO, -2L) // add
					.tryExpireAtto(docTypeRelationDAO, bankAccountDocumentDAO, -1L) // expire
					.tryExpireAtto(docTypeRelationDAO, bankAccountDocumentDAO, -2L) // skip
					.pushAnomalies();

			ArgumentCaptor<List<AnomalyRequest>> anomalyReqCaptor = ArgumentCaptor.forClass(List.class);
			verify(anomalyClient).add(eq(ctx.getReqContext().getLang()), eq(ctx.getReqContext().getUser()),
					anomalyReqCaptor.capture());
			verify(anomalyClient).expire(eq(ctx.getReqContext().getLang()), eq(ctx.getReqContext().getUser()),
					anomalyReqCaptor.capture());

			List<AnomalyRequest> added = anomalyReqCaptor.getAllValues().get(0);
			assertThat(added).hasSize(2)
					.extracting(AnomalyRequest::getEntityCode, AnomalyRequest::getEntityId, AnomalyRequest::getTypeCode)
					.containsExactlyInAnyOrder(
							tuple(BANK_ACCOUNT_CODE, "-3", ANM_TYPE_ATTO),
							tuple(BANK_ACCOUNT_CODE, "-2", ANM_TYPE_ATTO)
					);

			List<AnomalyRequest> expired = anomalyReqCaptor.getAllValues().get(1);
			assertThat(expired).hasSize(1)
					.extracting(AnomalyRequest::getEntityCode, AnomalyRequest::getEntityId, AnomalyRequest::getTypeCode)
					.containsExactlyInAnyOrder(
							tuple(BANK_ACCOUNT_CODE, "-1", ANM_TYPE_ATTO)
					);

			handle.rollback();
		});

	}

	@Test
	void test_pushAnomalies_ATTO_noRequiredOk() {

		DocTypeRelationDAO docTypeRelationDAO = mock(DocTypeRelationDAO.class);
		BankAccountDocumentDAO bankAccountDocumentDAO = mock(BankAccountDocumentDAO.class);

		given(docTypeRelationDAO.findByNamespace(anyString(), anyString()))
				.willReturn(List.of(DocTypeRelationEntity.builder().setFlRequired(0).build()));

		AnomalyHelper.newInstance(anomalyClient, ctx.getReqContext(), appClock)
				.tryAddAtto(docTypeRelationDAO, 1L) // skip
				.tryAddAtto(docTypeRelationDAO, bankAccountDocumentDAO, 2L) // skip
				.tryExpireAtto(docTypeRelationDAO, bankAccountDocumentDAO, 3L) // expire
				.pushAnomalies();

		ArgumentCaptor<List<AnomalyRequest>> anomalyReqCaptor = ArgumentCaptor.forClass(List.class);
		verify(anomalyClient, never()).add(any(), any(), any());
		verify(anomalyClient).expire(eq(ctx.getReqContext().getLang()), eq(ctx.getReqContext().getUser()),
				anomalyReqCaptor.capture());

		List<AnomalyRequest> expired = anomalyReqCaptor.getValue();
		assertThat(expired).hasSize(1)
				.extracting(AnomalyRequest::getEntityCode, AnomalyRequest::getEntityId, AnomalyRequest::getTypeCode)
				.containsExactlyInAnyOrder(
						tuple(BANK_ACCOUNT_CODE, "3", ANM_TYPE_ATTO)
				);

	}

	@Test
	void test_pushAnomalies_recalculate_ATTO_ok() {
		setUnusedBindingAllowed(true);
		getJdbi().useHandle(handle -> {
			handle.begin();

			execSqlFiles(this.getClass(), List.of(
					"add_bank_accounts",
					"add_doc_type_rel",
					"add_bank_account_docs"
			), ctx.getTestScriptParams());

			DocumentService documentService = mock(DocumentService.class);
			OffsetDateTime now = OffsetDateTime.now(appClock);
			given(documentService.getDocumentFromId(90101L)).willReturn(givenDoc(now.plusYears(9)));
			given(documentService.getDocumentFromId(90202L)).willReturn(givenDoc(now.plusYears(8)));
			given(documentService.getDocumentFromId(90601L)).willReturn(givenDoc(now.plusYears(7)));
			given(documentService.getDocumentFromId(90602L)).willReturn(givenDoc(now.minusDays(15)));

			DocTypeRelationDAO docTypeRelationDAO = handle.attach(DocTypeRelationDAO.class);
			BankAccountDocumentDAO bankAccountDocumentDAO = handle.attach(BankAccountDocumentDAO.class);

			AnomalyHelper.newInstance(anomalyClient, ctx.getReqContext(), appClock)
					.recalculateAtto(docTypeRelationDAO, bankAccountDocumentDAO, documentService, -6L) // add
					.recalculateAtto(docTypeRelationDAO, bankAccountDocumentDAO, documentService, -1L) // expire
					.recalculateAtto(docTypeRelationDAO, bankAccountDocumentDAO, documentService, -2L) // add
					.recalculateAtto(docTypeRelationDAO, bankAccountDocumentDAO, documentService, -3L) // add
					.pushAnomalies();

			ArgumentCaptor<List<AnomalyRequest>> anomalyReqCaptor = ArgumentCaptor.forClass(List.class);
			verify(anomalyClient).add(eq(ctx.getReqContext().getLang()), eq(ctx.getReqContext().getUser()),
					anomalyReqCaptor.capture());
			verify(anomalyClient).expire(eq(ctx.getReqContext().getLang()), eq(ctx.getReqContext().getUser()),
					anomalyReqCaptor.capture());

			List<AnomalyRequest> added = anomalyReqCaptor.getAllValues().get(0);
			assertThat(added).hasSize(3)
					.extracting(AnomalyRequest::getEntityCode, AnomalyRequest::getEntityId, AnomalyRequest::getTypeCode)
					.containsExactlyInAnyOrder(
							tuple(BANK_ACCOUNT_CODE, "-6", ANM_TYPE_ATTO),
							tuple(BANK_ACCOUNT_CODE, "-3", ANM_TYPE_ATTO),
							tuple(BANK_ACCOUNT_CODE, "-2", ANM_TYPE_ATTO)
					);

			List<AnomalyRequest> expired = anomalyReqCaptor.getAllValues().get(1);
			assertThat(expired).hasSize(1)
					.extracting(AnomalyRequest::getEntityCode, AnomalyRequest::getEntityId, AnomalyRequest::getTypeCode)
					.containsExactlyInAnyOrder(
							tuple(BANK_ACCOUNT_CODE, "-1", ANM_TYPE_ATTO)
					);

			handle.rollback();
		});
	}

	@Test
	void test_pushAnomalies_recalculate_ATTO_noRequiredOk() {

		DocTypeRelationDAO docTypeRelationDAO = mock(DocTypeRelationDAO.class);
		BankAccountDocumentDAO bankAccountDocumentDAO = mock(BankAccountDocumentDAO.class);
		DocumentService documentService = mock(DocumentService.class);

		given(bankAccountDocumentDAO.findByAndAccountId(anyString(), any()))
				.willReturn(List.of(
						BankAccountDocumentEntity.builder().setDocumentId(123L).build(),
						BankAccountDocumentEntity.builder().setDocumentId(456L).build(),
						BankAccountDocumentEntity.builder().setDocumentId(789L).build()
				));

		OffsetDateTime now = OffsetDateTime.now(appClock);
		given(documentService.getDocumentFromId(any())).willReturn(givenDoc(now.plusYears(9)));

		given(docTypeRelationDAO.findByNamespace(anyString(), anyString()))
				.willReturn(List.of(DocTypeRelationEntity.builder().setFlRequired(0).build()));

		AnomalyHelper.newInstance(anomalyClient, ctx.getReqContext(), appClock)
				.recalculateAtto(docTypeRelationDAO, bankAccountDocumentDAO, documentService, 1L) // expire
				.pushAnomalies();

		ArgumentCaptor<List<AnomalyRequest>> anomalyReqCaptor = ArgumentCaptor.forClass(List.class);
		verify(anomalyClient, never()).add(any(), any(), any());
		verify(anomalyClient).expire(eq(ctx.getReqContext().getLang()), eq(ctx.getReqContext().getUser()),
				anomalyReqCaptor.capture());

		List<AnomalyRequest> expired = anomalyReqCaptor.getValue();
		assertThat(expired).hasSize(1)
				.extracting(AnomalyRequest::getEntityCode, AnomalyRequest::getEntityId, AnomalyRequest::getTypeCode)
				.containsExactlyInAnyOrder(
						tuple(BANK_ACCOUNT_CODE, "1", ANM_TYPE_ATTO)
				);

	}

	private Document givenDoc(OffsetDateTime validTo) {
		Document expired = new Document();
		expired.setValidTo(validTo);
		return expired;
	}
}
