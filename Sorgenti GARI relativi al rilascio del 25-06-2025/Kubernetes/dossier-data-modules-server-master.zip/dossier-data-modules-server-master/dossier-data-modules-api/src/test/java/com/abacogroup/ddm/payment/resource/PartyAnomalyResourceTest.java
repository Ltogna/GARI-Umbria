package com.abacogroup.ddm.payment.resource;

import static com.abacogroup.ddm.common.WebCliHelper.TENANT;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.verify;

import com.abacogroup.anomalyregistry.api.v1.AnomalySearchResponse;
import com.abacogroup.anomalyregistry.api.v1.AnomalySearchResponse.AnomalySearchResponseBuilder;
import com.abacogroup.anomalyregistry.api.v1.AnomalyTypeResponse;
import com.abacogroup.ddm.api.AnomalyLevelEnum;
import com.abacogroup.ddm.api.DdmAnomaliesRes;
import com.abacogroup.ddm.common.WebCliHelper;
import com.abacogroup.ddm.common.resources.ReqContext;
import com.abacogroup.ddm.payment.core.PartyAnomalyService;
import com.abacogroup.ddm.payment.core.impl.AnomalyHelper;
import com.abacogroup.ddm.payment.core.impl.PartyAnomalyServiceImpl;
import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;
import io.dropwizard.testing.junit5.ResourceExtension;
import jakarta.ws.rs.core.GenericType;
import jakarta.ws.rs.core.UriBuilder;
import java.util.List;
import java.util.Map;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;

@ExtendWith(DropwizardExtensionsSupport.class)
class PartyAnomalyResourceTest {

	private final PartyAnomalyService partyAnomalyService = Mockito.mock(PartyAnomalyServiceImpl.class);
	private final ResourceExtension EXT = WebCliHelper.createEXT(new PartyAnomalyResource(partyAnomalyService));

	// ----- getAnomalies -----
	@Test
	void test_getAnomalies_ok() {
		Long partyId = 555L;

		UriBuilder uriBuilder = UriBuilder.fromResource(PartyAnomalyResource.class).path(PartyAnomalyResource.class, "getAnomalies");
		String uri = uriBuilder.build(TENANT, partyId).toString();
		System.out.println(uri);

		var mockRes = DdmAnomaliesRes.builder()
				.setAnomaliesGrouped(Map.of(
						AnomalyLevelEnum.INFO, List.of(
								givenAnomaly(partyId, null, AnomalyHelper.ANM_GROUP_CODE_PAYMENT_ACCOUNT, AnomalyHelper.ANM_TYPE_CC_PRED).build(),
								givenAnomaly(partyId, null, AnomalyHelper.ANM_GROUP_CODE_PAYMENT_ACCOUNT, AnomalyHelper.ANM_TYPE_CC_PRED).build()
						),
						AnomalyLevelEnum.WARN, List.of(
								givenAnomaly(partyId, null, AnomalyHelper.ANM_GROUP_CODE_PAYMENT_ACCOUNT, AnomalyHelper.ANM_TYPE_NO_CC).build()
						)
				)).build();

		given(partyAnomalyService.getAnomalies(any(), anyLong())).willReturn(mockRes);

		DdmAnomaliesRes res = EXT.getJerseyTest().client()
				.target(UriBuilder.fromUri(uri))
				.request()
				.header("Authorization", WebCliHelper.JWT_MOCK_CREDENTIALS)
				.get(new GenericType<>() {
				});

//		System.out.println(EXT.getJerseyTest().client()
//				.target(UriBuilder.fromUri(uri))
//				.request()
//				.header("Authorization", WebCliHelper.JWT_MOCK_CREDENTIALS)
//				.get(String.class));

		assertThat(res).isNotNull()
				.isEqualTo(mockRes);

		verify(partyAnomalyService).getAnomalies(any(ReqContext.class), eq(partyId));
	}




	private AnomalySearchResponseBuilder<?, ?> givenAnomaly(Long partyId, Long id, String groupCode, String code) {
		return AnomalySearchResponse.builder()
				.setId(id)
				.setEntityId(partyId.toString())
				.setEntityCode(AnomalyHelper.PARTY_ENTITY_CODE)
				.setType(AnomalyTypeResponse.builder()
						.setId(id)
						.setCode(code)
						.setGroupCode(groupCode)
						.setI18nCode(code)
						.build());
	}

}
