package com.abacogroup.ddm.bundle.tenant;

import static com.abacogroup.bundles.Constants.ALL_TENANTS;
import static org.assertj.core.api.Assertions.assertThat;

import com.abacogroup.bundles.listener.tenant.TenantMessage;
import com.abacogroup.ddm.common.JdbiTest;
import com.abacogroup.ddm.common.ReqContextUtils;
import com.abacogroup.ddm.db.dao.AnomalyCategoriesDAO;
import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;
import java.util.HashMap;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

@ExtendWith(DropwizardExtensionsSupport.class)
class AnomalyCategoriesTenantMessageProcessorTest extends JdbiTest {

	private ReqContextUtils ctx = new ReqContextUtils(this.getClass());

	private final AnomalyCategoriesTenantMessageProcessor processor = getService(AnomalyCategoriesTenantMessageProcessor.class);


	// ----- onMessage -----
	@Test
	void test_onMessage_ok() {

		getJdbi().useHandle(handle -> {
			handle.begin();
			AnomalyCategoriesDAO dao = handle.attach(AnomalyCategoriesDAO.class);

			List<String> initScripts = List.of("anomaly_categories_all_tenants");
			execSqlFiles(this.getClass(), initScripts, new HashMap<>());

			assertThat(dao.countAll(ALL_TENANTS))
					.withFailMessage("unexpected data with * tenant")
					.isEqualTo(4L);
			assertThat(dao.countAll(ctx.getTenantId()))
					.isEqualTo(0L);

			processor.onMessage(new TenantMessage().setTenantId(ctx.getTenantId()));

			assertThat(dao.countAll(ctx.getTenantId()))
					.isEqualTo(4L);

			handle.rollback();
		});

	}
}
