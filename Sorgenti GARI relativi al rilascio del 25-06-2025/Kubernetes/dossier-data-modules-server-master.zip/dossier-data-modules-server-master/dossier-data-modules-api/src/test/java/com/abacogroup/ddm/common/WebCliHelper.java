package com.abacogroup.ddm.common;

import java.util.Collection;
import java.util.Map;
import java.util.Optional;

import org.glassfish.jersey.server.filter.RolesAllowedDynamicFeature;

import com.abacogroup.ddm.DossierDataModulesTestApplication;
import com.abacogroup.dropwizard.auth.multitenant.MultitenantFilter;
import com.abacogroup.dropwizard.auth.sso2.JwtAuthenticationFilter;
import com.abacogroup.dropwizard.auth.sso2.User;
import com.auth0.jwt.JWT;

import io.dropwizard.auth.AuthDynamicFeature;
import io.dropwizard.auth.AuthValueFactoryProvider;
import io.dropwizard.testing.junit5.ResourceExtension;
import jakarta.ws.rs.client.WebTarget;

public abstract class WebCliHelper {

	public static final String BASIC_USERNAME = "test-user@example";
	public static final String FAKE_JWT = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJuYW1lIjoidGVzdC11c2VyQGV4YW1wbGUifQ.gaT_yiyjQ3uzXWZ9Fj5zB4iSrzhHJ7PvXbx77GCFYvo";
	public static final String JWT_MOCK_CREDENTIALS = "JWT " + FAKE_JWT;
	public static final String TENANT = "master";

	public static ResourceExtension createEXT(Object resource) {

		return ResourceExtension.builder()
				.setMapper(DossierDataModulesTestApplication.getObjectMapper())
				.addProvider(new AuthDynamicFeature(new JwtAuthenticationFilter.Builder()
						.setAuthenticator(credentials -> Optional.of(new User(JWT.decode(FAKE_JWT).getClaim("name").asString(), TENANT)))
						.setAuthorizer((principal, role, requestContext) -> true)
						.buildAuthFilter()))
				.addProvider(RolesAllowedDynamicFeature.class)
				.addProvider(new AuthValueFactoryProvider.Binder<>(User.class))
				.addProvider(new MultitenantFilter("tenant"))
				.addResource(resource)
				.build();
	}

	public static WebTarget addQueryParamsFromMap(Map<String, Object> params, WebTarget wt) {
		if (null == params) {
			return wt;
		}
		for (Map.Entry<String, Object> entry : params.entrySet()) {
			String key = entry.getKey();
			Object v = entry.getValue();
			if (v instanceof Collection) {
				for (Object x : (Collection) v) {
					wt = wt.queryParam(key, x);
				}
			} else {
				wt = wt.queryParam(key, entry.getValue());
			}
		}
		return wt;
	}

}
