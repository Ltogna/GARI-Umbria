package com.abacogroup.ddm.payment.resource;

import static com.abacogroup.ddm.common.WebCliHelper.BASIC_USERNAME;
import static com.abacogroup.ddm.common.WebCliHelper.TENANT;
import static org.assertj.core.api.Assertions.assertThat;
import static org.hamcrest.Matchers.is;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.verify;

import com.abacogroup.ddm.common.WebCliHelper;
import com.abacogroup.ddm.common.resources.ReqContext;
import com.abacogroup.ddm.payment.api.BankAccountDocumentRes;
import com.abacogroup.ddm.payment.api.BankAccountDocumentRes.BankAccountDocumentResBuilder;
import com.abacogroup.ddm.payment.api.req.BankAccountDocumentSearchReq;
import com.abacogroup.ddm.payment.core.BankAccountDocumentService;
import com.abacogroup.ddm.payment.core.impl.BankAccountDocumentServiceImpl;
import com.abacogroup.dynamicdocuments.bean.Document;
import com.abacogroup.dynamicdocuments.bean.InsertDocument;
import com.abacogroup.jdbi.paging.impl.InfiniteListResultsImpl;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;
import io.dropwizard.testing.junit5.ResourceExtension;
import jakarta.ws.rs.client.Entity;
import jakarta.ws.rs.core.GenericType;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.core.UriBuilder;
import java.util.List;
import java.util.Map;
import org.hamcrest.MatcherAssert;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mockito;

@ExtendWith(DropwizardExtensionsSupport.class)
class BankAccountDocumentResourceTest {

	private final BankAccountDocumentService bankAccountDocumentService = Mockito.mock(BankAccountDocumentServiceImpl.class);
	private final ResourceExtension EXT = WebCliHelper.createEXT(new BankAccountDocumentResource(bankAccountDocumentService));

	@Test
	void should_search() {
		Long partyId = 555L;
		Long accountId = 100L;
		String definitionCode = "DEF_1";
		String nextKey = "11";

		BankAccountDocumentSearchReq searchReq = new BankAccountDocumentSearchReq()
				.setDefinitionCode(definitionCode);

		ObjectMapper mapper = new ObjectMapper();
		Map<String, Object> queryMap = mapper.convertValue(searchReq, Map.class);

		UriBuilder uriBuilder = UriBuilder.fromResource(BankAccountDocumentResource.class).path(BankAccountDocumentResource.class, "search");
		queryMap.forEach(uriBuilder::queryParam);
		String uri = uriBuilder.build(TENANT, partyId, accountId).toString();
		System.out.println(uri);

		InfiniteListResultsImpl<BankAccountDocumentRes> mockRes = new InfiniteListResultsImpl<>(List.of(
				baDocumentResBuilder(101L, accountId, definitionCode).build(),
				baDocumentResBuilder(102L, accountId, definitionCode).build(),
				baDocumentResBuilder(103L, accountId, definitionCode).build()), nextKey);

		given(bankAccountDocumentService.search(any(), anyLong(), anyLong(), any(), any())).willReturn(mockRes);

		InfiniteListResultsImpl<BankAccountDocumentRes> res = EXT.getJerseyTest().client()
				.target(UriBuilder.fromUri(uri))
				.queryParam("nextKey", nextKey)
				.request()
				.header("Authorization", WebCliHelper.JWT_MOCK_CREDENTIALS)
				.get(new GenericType<>() {
				});

		assertThat(res).isNotNull()
				.extracting(InfiniteListResultsImpl::getRecords)
				.isEqualTo(mockRes.getRecords());

		ArgumentCaptor<ReqContext> reqCtxCaptor = ArgumentCaptor.forClass(ReqContext.class);
		verify(bankAccountDocumentService).search(reqCtxCaptor.capture(), eq(partyId), eq(accountId), eq(searchReq), eq(nextKey));
	}

	// ----- getByDocumentId -----
	@Test
	void test_getByDocumentId_ok() {
		Long partyId = 555L;
		Long accountId = 100L;
		Long documentId = 123L;

		UriBuilder uriBuilder = UriBuilder.fromResource(BankAccountDocumentResource.class).path(BankAccountDocumentResource.class, "getByDocumentId");
		String uri = uriBuilder.build(TENANT, partyId, accountId, documentId).toString();
		System.out.println(uri);

		BankAccountDocumentRes mockRes = baDocumentResBuilder(101L, accountId, "DEF_TEST").build();
		given(bankAccountDocumentService.getBankAccountDocument(any(), anyLong(), anyLong(), anyLong())).willReturn(mockRes);

		BankAccountDocumentRes res = EXT.getJerseyTest().client()
				.target(UriBuilder.fromUri(uri))
				.request()
				.header("Authorization", WebCliHelper.JWT_MOCK_CREDENTIALS)
				.get(new GenericType<>() {
				});

		assertThat(res).isNotNull().isEqualTo(mockRes);

		ArgumentCaptor<ReqContext> reqCtxCaptor = ArgumentCaptor.forClass(ReqContext.class);
		verify(bankAccountDocumentService).getBankAccountDocument(reqCtxCaptor.capture(), eq(partyId), eq(accountId), eq(documentId));
	}

	// ----- getDocumentFileContent -----
	@Test
	void test_getDocumentFileContent_ok() {
		Long partyId = 555L;
		Long accountId = 100L;
		Long documentId = 123L;
		String fileId = "theFileId";

		UriBuilder uriBuilder = UriBuilder.fromResource(BankAccountDocumentResource.class).path(BankAccountDocumentResource.class, "getDocumentFileContent");
		String uri = uriBuilder.build(TENANT, partyId, accountId, documentId, "my-bucket", fileId).toString();
		System.out.println(uri);

		Response mockRes = Response.ok("my file content".getBytes(), MediaType.TEXT_PLAIN_TYPE).build();
		given(bankAccountDocumentService.getDocumentFileContent(any(), anyLong(), anyLong(), anyLong(), anyString())).willReturn(mockRes);

		Response res = EXT.getJerseyTest().client()
				.target(UriBuilder.fromUri(uri))
				.request()
				.header("Authorization", WebCliHelper.JWT_MOCK_CREDENTIALS)
				.get();

		assertThat(res).isNotNull();
		assertThat(res.readEntity(String.class)).isNotNull()
				.isEqualTo("my file content");

		ArgumentCaptor<ReqContext> reqCtxCaptor = ArgumentCaptor.forClass(ReqContext.class);
		verify(bankAccountDocumentService).getDocumentFileContent(reqCtxCaptor.capture(), eq(partyId), eq(accountId), eq(documentId), eq(fileId));
	}

	// ----- getDocumentFileMetadata -----
	@Test
	void test_getDocumentFileMetadata_ok() {
		Long partyId = 555L;
		Long accountId = 100L;
		Long documentId = 123L;
		String fileId = "theFileId";

		UriBuilder uriBuilder = UriBuilder.fromResource(BankAccountDocumentResource.class).path(BankAccountDocumentResource.class, "getDocumentFileMetadata");
		String uri = uriBuilder.build(TENANT, partyId, accountId, documentId, "my-bucket", fileId).toString();
		System.out.println(uri);

		Response mockRes = Response.ok("my file content".getBytes(), MediaType.TEXT_PLAIN_TYPE)
				.header("hKey", "hValue").build();
		given(bankAccountDocumentService.getDocumentFileMetadata(any(), anyLong(), anyLong(), anyLong(), anyString())).willReturn(mockRes);

		Response res = EXT.getJerseyTest().client()
				.target(UriBuilder.fromUri(uri))
				.request()
				.header("Authorization", WebCliHelper.JWT_MOCK_CREDENTIALS)
				.head();

		assertThat(res).isNotNull();
		assertThat(res.getHeaderString("Content-type")).isNotNull()
				.isEqualTo(MediaType.TEXT_PLAIN_TYPE.toString());
		assertThat(res.getHeaderString("hKey")).isNotNull()
				.isEqualTo("hValue");

		ArgumentCaptor<ReqContext> reqCtxCaptor = ArgumentCaptor.forClass(ReqContext.class);
		verify(bankAccountDocumentService).getDocumentFileMetadata(reqCtxCaptor.capture(), eq(partyId), eq(accountId), eq(documentId), eq(fileId));
	}

	@Test
	void test_add_doc_ok() {
		Long partyId = 555L;
		Long accountId = 100L;
		String definitionCode = "DEF_1";

		String uri = UriBuilder.fromResource(BankAccountDocumentResource.class)
				.build(TENANT, partyId, accountId).toString();
		System.out.println(uri);

		BankAccountDocumentRes mockRes = baDocumentResBuilder(100L, accountId, definitionCode).build();
		given(bankAccountDocumentService.insert(any(), anyLong(), anyLong(), any())).willReturn(mockRes);
		InsertDocument doc = new InsertDocument();
		doc.setDefCode(definitionCode);
		doc.setBusinessId(accountId);

		BankAccountDocumentRes res = EXT.getJerseyTest().target()
				.path(uri)
				.request()
				.header("Authorization", WebCliHelper.JWT_MOCK_CREDENTIALS)
				.post(Entity.json(doc), new GenericType<>() {
				});

		assertThat(res).isNotNull()
				.isEqualTo(mockRes);

		ArgumentCaptor<ReqContext> reqCtxCaptor = ArgumentCaptor.forClass(ReqContext.class);
		verify(bankAccountDocumentService).insert(reqCtxCaptor.capture(), eq(partyId), eq(accountId), eq(doc));
		ReqContext reqContext = reqCtxCaptor.getValue();
		MatcherAssert.assertThat(reqContext.getTenantId(), is(TENANT));
		MatcherAssert.assertThat(reqContext.getLang(), is("en"));
		MatcherAssert.assertThat(reqContext.getUsername(), is(BASIC_USERNAME));
	}

	@Test
	void test_update_doc_ok() {
		Long partyId = 555L;
		Long accountId = 100L;
		Long docId = 1L;
		String definitionCode = "DEF_1";

		String uri = UriBuilder.fromResource(BankAccountDocumentResource.class).path(BankAccountDocumentResource.class, "update")
				.build(TENANT, partyId, accountId, docId).toString();

		BankAccountDocumentRes mockRes = baDocumentResBuilder(docId, accountId, definitionCode).build();
		given(bankAccountDocumentService.update(any(), anyLong(), anyLong(), anyLong(), any())).willReturn(mockRes);

		Document req = new Document();

		BankAccountDocumentRes res = EXT.getJerseyTest().target()
				.path(uri)
				.request()
				.header("Authorization", WebCliHelper.JWT_MOCK_CREDENTIALS)
				.put(Entity.json(req), new GenericType<>() {
				});

		assertThat(res).isNotNull().isEqualTo(mockRes);

		ArgumentCaptor<ReqContext> reqCtxCaptor = ArgumentCaptor.forClass(ReqContext.class);
		verify(bankAccountDocumentService).update(reqCtxCaptor.capture(), eq(partyId), eq(accountId), eq(docId), eq(req));
		ReqContext reqContext = reqCtxCaptor.getValue();
		MatcherAssert.assertThat(reqContext.getTenantId(), is(TENANT));
		MatcherAssert.assertThat(reqContext.getLang(), is("en"));
		MatcherAssert.assertThat(reqContext.getUsername(), is(BASIC_USERNAME));
	}

	@Test
	void test_delete_doc_ok() {
		Long partyId = 555L;
		Long accountId = 100L;
		Long docId = 1L;

		String uri = UriBuilder.fromResource(BankAccountDocumentResource.class).path(BankAccountDocumentResource.class, "delete")
				.build(TENANT, partyId, accountId, docId).toString();
		System.out.println(uri);

		Response res = EXT.getJerseyTest().target()
				.path(uri)
				.request()
				.header("Authorization", WebCliHelper.JWT_MOCK_CREDENTIALS)
				.delete(new GenericType<>() {
				});

		assertThat(res).isNotNull();
		assertThat(res.getStatus()).isEqualTo(200);

		ArgumentCaptor<ReqContext> reqCtxCaptor = ArgumentCaptor.forClass(ReqContext.class);
		verify(bankAccountDocumentService).expire(reqCtxCaptor.capture(), eq(partyId), eq(accountId), eq(docId));
		ReqContext reqContext = reqCtxCaptor.getValue();
		System.out.println(reqContext);
		MatcherAssert.assertThat(reqContext.getTenantId(), is(TENANT));
		MatcherAssert.assertThat(reqContext.getLang(), is("en"));
		MatcherAssert.assertThat(reqContext.getUsername(), is(BASIC_USERNAME));
	}

	private BankAccountDocumentResBuilder<?, ?> baDocumentResBuilder(Long docId, Long accountId, String defCode) {
		return BankAccountDocumentRes.builder()
				.setBankAccountId(accountId)
				.setDefinitionCode(defCode)
				.setDocumentId(docId);
	}

}
