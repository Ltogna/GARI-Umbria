package com.abacogroup.bundles.initializer.impl;

import com.abacogroup.bundles.initializer.impl.BundleInitServiceImpl;
import com.abacogroup.bundles.initializer.impl.BundleInitServiceProducer;
import com.abacogroup.bundles.initializer.impl.FileSupport;
import com.abacogroup.ddm.DossierDataModulesTestApplication;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.HashMap;
import java.util.Map;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.Mockito;

/**
 * NOT A TEST!
 * <li>crea e sostituisce il file src/test/resources/party-registry-bundle.zip
 * <li>il contenuto è quello di src/test/resources/bundles
 *
 * <p>
 * </p>
 * I test sono istruiti per applicare questo bundle allo startup, vedi .{@link DossierDataModulesTestApplication} <code>after services
 * up</code>
 */
@Disabled
public class CreateBundlesZipTest {
	private static final String BASE_TEMP_DIR = "target";
	private static final String LOCATION = "src/test/resources/bundles/standard";
	private final BundleInitServiceProducer producer = Mockito.mock(BundleInitServiceProducer.class);
	private final BundleInitServiceImpl initService = new BundleInitServiceImpl(
			producer,
			LOCATION,
			BASE_TEMP_DIR);

	@Disabled
	@Test
	void testCreateBundle() throws IOException {
		initService.start();
		ArgumentCaptor<File> captor = ArgumentCaptor.forClass(File.class);
		Mockito.verify(producer, Mockito.times(1))
				.pushConfig(captor.capture(), Mockito.anyString(), Mockito.any());
		File zip = captor.getValue();
		Files.copy(zip.toPath(), Path.of("src/test/resources", zip.getName()), StandardCopyOption.REPLACE_EXISTING);

		Path wd = Path.of(zip.getParentFile().getPath(), "lol");
		FileUtils.createParentDirectories(wd.toFile());

		FileSupport.unzip(new FileInputStream(zip), wd);

		Map<String, String> map = new HashMap<>();
		FileSupport.listFiles(wd)
				.stream().filter(f -> f.getFileName().toString().endsWith(".zip"))
				.forEach(zipF -> {
					try {
						String chgDirNme = FilenameUtils.getBaseName(zipF.toFile().getName());
						Path chgDirPath = Path.of(wd.toString(), chgDirNme);
						FileSupport.unzip(new FileInputStream(zipF.toFile()), chgDirPath);
						map.put(zipF.toFile().getName(), FileSupport.md5Hex(chgDirPath));
					} catch (Throwable t) {
						throw new RuntimeException("errore in generazione json bundle");
					}
				});
		File target = Path.of("src", "test", "resources", zip.getName() + ".json").toFile();

		FileUtils.write(target, new ObjectMapper().writeValueAsString(map), Charset.defaultCharset());
		System.out.println("il bundle di test è stato aggiornato, dovresti rifare il db!");
		System.out.println("                                                                 ");
		System.out.println("██████  ██ ███████  █████  ██     ██ ██          ██████  ██████  ");
		System.out.println("██   ██ ██ ██      ██   ██ ██     ██ ██          ██   ██ ██   ██ ");
		System.out.println("██████  ██ █████   ███████ ██     ██ ██          ██   ██ ██████  ");
		System.out.println("██   ██ ██ ██      ██   ██ ██     ██ ██          ██   ██ ██   ██ ");
		System.out.println("██   ██ ██ ██      ██   ██ ██     ██ ███████     ██████  ██████  ");
		System.out.println("                                                                 ");
	}
}
