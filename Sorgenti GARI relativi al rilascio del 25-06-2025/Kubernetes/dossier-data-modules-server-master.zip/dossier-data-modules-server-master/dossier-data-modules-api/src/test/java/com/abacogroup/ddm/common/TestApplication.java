package com.abacogroup.ddm.common;

import org.jdbi.v3.core.Jdbi;

public interface TestApplication {

	Jdbi getJdbi();

	ApplicationTestSupport getAppTestSupport();

}
