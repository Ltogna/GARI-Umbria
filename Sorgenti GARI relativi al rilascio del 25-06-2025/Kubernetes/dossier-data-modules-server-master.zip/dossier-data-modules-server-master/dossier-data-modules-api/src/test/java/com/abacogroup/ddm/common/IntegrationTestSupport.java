package com.abacogroup.ddm.common;

import io.dropwizard.core.Configuration;
import io.dropwizard.testing.junit5.DropwizardAppExtension;
import java.lang.reflect.Field;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.reflect.FieldUtils;
import org.jdbi.v3.core.Jdbi;
import org.jdbi.v3.core.locator.ClasspathSqlLocator;
import org.jdbi.v3.core.statement.SqlStatements;

public class IntegrationTestSupport {

	private final DropwizardAppExtension<? extends Configuration> EXT;
	private final TestApplication app;

	private final Configuration configuration;

	public IntegrationTestSupport(DropwizardAppExtension<? extends Configuration> ext) {
		EXT = ext;
		if (!(ext.getApplication() instanceof TestApplication)) {
			throw new IllegalStateException(String.format("la classe %s deve implementare TestApplication", ext.getApplication().getClass().getName()));
		}
		this.app = EXT.getApplication();
		this.configuration = EXT.getConfiguration();
	}

	public static void execSqlFiles(Jdbi jdbi, Class clazz, List<String> scripts, Map<String, Object> args) {
		Map<String, Object> params = new HashMap<>(Optional.ofNullable(args).orElse(new HashMap<>()));

		if (!scripts.isEmpty()) {
			String name = String.format("%s.", clazz.getName());
			jdbi.useTransaction(handle -> {
				scripts.stream().forEach(s -> {
					String sqlFileAsString = ClasspathSqlLocator.removingComments().locate(name + s);
					Arrays.stream(sqlFileAsString.split(";"))
							.filter(StringUtils::isNotBlank)
							.forEach(str -> handle.createUpdate(str).bindMap(params).execute());
				});
			});
		}
	}

	public static <T, M> void injectMock(T target, M mock) {
		try {
			Class<T> targetClazz = (Class<T>) target.getClass();
			Field field = Arrays.stream(FieldUtils.getAllFields(targetClazz))
					.filter(f -> f.getType().isAssignableFrom(mock.getClass()))
					.findFirst()
					.orElseThrow();
			FieldUtils.writeField(target, field.getName(), mock, true);
		} catch (IllegalAccessException ex) {
			throw new RuntimeException("errore in inject", ex);
		}
	}

	public Configuration getConfiguration() {
		return configuration;
	}

	public Jdbi getJdbi() {
		return app.getJdbi();
	}

	public void setUnusedBindingAllowed(boolean allowed) {
		app.getJdbi().getConfig().get(SqlStatements.class).setUnusedBindingAllowed(allowed);
	}

	public void execSqlFiles(Class clazz, List<String> scripts, Map<String, Object> args) {
		execSqlFiles(app.getJdbi(), clazz, scripts, args);
	}

	public <T> T getDAO(Class<T> classDAO) {
		return app.getJdbi().onDemand(classDAO);
	}

	@SuppressWarnings("unchecked")
	public <T> T getService(Class<T> clazz) {
		return (T) Optional

				.ofNullable(app.getAppTestSupport().getServices().get(clazz))
				.orElseThrow(() -> new RuntimeException(
						String.format("Error loading %s! Did you call by interface? Implementation required", clazz.getSimpleName())));
	}

}
