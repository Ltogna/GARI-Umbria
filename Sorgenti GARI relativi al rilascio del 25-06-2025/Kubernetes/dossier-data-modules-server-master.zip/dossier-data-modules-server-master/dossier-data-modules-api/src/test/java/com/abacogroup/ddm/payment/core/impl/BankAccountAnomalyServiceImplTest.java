package com.abacogroup.ddm.payment.core.impl;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;

import com.abacogroup.anomalyregistry.api.v1.AnomalySearchResponse;
import com.abacogroup.anomalyregistry.api.v1.AnomalySearchResponse.AnomalySearchResponseBuilder;
import com.abacogroup.anomalyregistry.api.v1.AnomalyTypeResponse;
import com.abacogroup.anomalyregistry.api.v1.req.AnomalySearchRequest;
import com.abacogroup.anomalyregistry.core.cli.v1.AnomalyClient;
import com.abacogroup.ddm.api.AnomalyLevelEnum;
import com.abacogroup.ddm.api.DdmAnomaliesRes;
import com.abacogroup.ddm.common.JdbiTest;
import com.abacogroup.ddm.common.ReqContextUtils;
import com.abacogroup.ddm.core.impl.DdmAnomalyServiceImpl;
import com.abacogroup.ddm.payment.core.BankAccountAnomalyService;
import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;
import java.util.List;
import org.assertj.core.api.InstanceOfAssertFactories;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;

@ExtendWith(DropwizardExtensionsSupport.class)
class BankAccountAnomalyServiceImplTest extends JdbiTest {

	private final BankAccountAnomalyService service = getService(BankAccountAnomalyServiceImpl.class);
	private final ReqContextUtils ctx = new ReqContextUtils(this.getClass());

	private final AnomalyClient anomalyClient = mock(AnomalyClient.class);

	@BeforeEach
	void setUp() {
		DdmAnomalyServiceImpl ddmAnomalyService = getService(DdmAnomalyServiceImpl.class);
		this.injectMock(ddmAnomalyService, anomalyClient);
	}


	// ----- getAnomalies -----
	@Test
	void test_getAnomalies_ok() {
		setUnusedBindingAllowed(true);
		getJdbi().useHandle(handle -> {
			handle.begin();

			execSqlFiles(this.getClass(), List.of(
					"anomaly_categories", "add_bank_accounts"
			), ctx.getTestScriptParams());

			Long partyId = 555L;
			Long accountId = -1L;

			AnomalySearchResponse atto = givenAnomaly(accountId, 123L, AnomalyHelper.ANM_GROUP_CODE_PAYMENT_DD, AnomalyHelper.ANM_TYPE_ATTO).build();
			AnomalySearchResponse a195 = givenAnomaly(accountId, 456L, AnomalyHelper.ANM_GROUP_CODE_PAYMENT_ACCOUNT, AnomalyHelper.ANM_TYPE_915).build();
			given(anomalyClient.search(anyString(), any(), anyString(), any()))
					.willReturn(List.of(atto, a195));

			// test
			DdmAnomaliesRes anomalies = service.getAnomalies(ctx.getReqContext(), partyId, accountId);

			assertThat(anomalies).isNotNull()
					.extracting(DdmAnomaliesRes::getAnomaliesGrouped)
					.asInstanceOf(InstanceOfAssertFactories.map(AnomalyLevelEnum.class, List.class))
					.containsOnlyKeys(AnomalyLevelEnum.WARN)
					.satisfies(a -> {
						assertThat(a.get(AnomalyLevelEnum.WARN)).hasSize(2).containsExactly(atto, a195);
					});

			ArgumentCaptor<AnomalySearchRequest> searchReqCaptor = ArgumentCaptor.forClass(AnomalySearchRequest.class);
			verify(anomalyClient).search(eq(ctx.getReqContext().getLang()), eq(ctx.getReqContext().getUser()),
					eq(AnomalyHelper.BANK_ACCOUNT_CODE), searchReqCaptor.capture());

			assertThat(searchReqCaptor.getValue()).isNotNull()
					.satisfies(sr -> {
						assertThat(sr.getEntityId()).containsExactlyInAnyOrder(accountId.toString());
					});

			handle.rollback();
			//			handle.commit();
		});
	}

	private AnomalySearchResponseBuilder<?, ?> givenAnomaly(Long accountId, Long id, String groupCode, String code) {
		return AnomalySearchResponse.builder()
				.setId(id)
				.setEntityId(accountId.toString())
				.setEntityCode(AnomalyHelper.BANK_ACCOUNT_CODE)
				.setType(AnomalyTypeResponse.builder()
						.setId(id)
						.setCode(code)
						.setGroupCode(groupCode)
						.setI18nCode(code)
						.build());
	}
}
