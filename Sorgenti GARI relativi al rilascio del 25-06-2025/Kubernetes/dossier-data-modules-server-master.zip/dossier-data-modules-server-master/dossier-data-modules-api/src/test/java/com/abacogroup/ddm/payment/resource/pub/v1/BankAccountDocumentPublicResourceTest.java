package com.abacogroup.ddm.payment.resource.pub.v1;

import static com.abacogroup.ddm.common.WebCliHelper.TENANT;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.verify;

import com.abacogroup.ddm.common.WebCliHelper;
import com.abacogroup.ddm.common.resources.ReqContext;
import com.abacogroup.ddm.payment.api.BankAccountDocumentRes;
import com.abacogroup.ddm.payment.api.BankAccountDocumentRes.BankAccountDocumentResBuilder;
import com.abacogroup.ddm.payment.api.req.BankAccountDocumentSearchReq;
import com.abacogroup.ddm.payment.api.v1.BankAccountDocumentResponseV1;
import com.abacogroup.ddm.payment.core.BankAccountDocumentService;
import com.abacogroup.ddm.payment.core.impl.BankAccountDocumentServiceImpl;
import com.abacogroup.jdbi.paging.impl.InfiniteListResultsImpl;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;
import io.dropwizard.testing.junit5.ResourceExtension;
import jakarta.ws.rs.core.GenericType;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.core.UriBuilder;
import java.util.List;
import java.util.Map;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mockito;

@ExtendWith(DropwizardExtensionsSupport.class)
class BankAccountDocumentPublicResourceTest {

	private final BankAccountDocumentService bankAccountDocumentService = Mockito.mock(BankAccountDocumentServiceImpl.class);
	private final BankAccountDocumentPublicResource resource = new BankAccountDocumentPublicResource(bankAccountDocumentService);
	private final ResourceExtension EXT = WebCliHelper.createEXT(resource);

	@Test
	void should_search() {
		Long partyId = 555L;
		Long accountId = 100L;
		String definitionCode = "DEF_1";
		String nextKey = "11";

		BankAccountDocumentSearchReq searchReq = new BankAccountDocumentSearchReq()
				.setDefinitionCode(definitionCode);

		ObjectMapper mapper = new ObjectMapper();
		Map<String, Object> queryMap = mapper.convertValue(searchReq, Map.class);

		UriBuilder uriBuilder = UriBuilder.fromResource(resource.getClass()).path(resource.getClass(), "search");
		queryMap.forEach(uriBuilder::queryParam);
		String uri = uriBuilder.build(TENANT, partyId, accountId).toString();
		System.out.println(uri);

		InfiniteListResultsImpl<BankAccountDocumentRes> mockRes = new InfiniteListResultsImpl<>(List.of(
				baDocumentResBuilder(101L, accountId, definitionCode).build(),
				baDocumentResBuilder(102L, accountId, definitionCode).build(),
				baDocumentResBuilder(103L, accountId, definitionCode).build()), nextKey);

		given(bankAccountDocumentService.search(any(), anyLong(), anyLong(), any(), any())).willReturn(mockRes);

		InfiniteListResultsImpl<BankAccountDocumentResponseV1> res = EXT.getJerseyTest().client()
				.target(UriBuilder.fromUri(uri))
				.queryParam("nextKey", nextKey)
				.request()
				.header("Authorization", WebCliHelper.JWT_MOCK_CREDENTIALS)
				.get(new GenericType<>() {
				});

		assertThat(res).isNotNull()
				.extracting(InfiniteListResultsImpl::getRecords)
				.usingRecursiveComparison()
				.isEqualTo(mockRes.getRecords());

		ArgumentCaptor<ReqContext> reqCtxCaptor = ArgumentCaptor.forClass(ReqContext.class);
		verify(bankAccountDocumentService).search(reqCtxCaptor.capture(), eq(partyId), eq(accountId), eq(searchReq), eq(nextKey));
	}

	// ----- getByDocumentId -----
	@Test
	void test_getByDocumentId_ok() {
		Long partyId = 555L;
		Long accountId = 100L;
		Long documentId = 123L;

		UriBuilder uriBuilder = UriBuilder.fromResource(resource.getClass()).path(resource.getClass(), "getByDocumentId");
		String uri = uriBuilder.build(TENANT, partyId, accountId, documentId).toString();
		System.out.println(uri);

		BankAccountDocumentRes mockRes = baDocumentResBuilder(101L, accountId, "DEF_TEST").build();
		given(bankAccountDocumentService.getBankAccountDocument(any(), anyLong(), anyLong(), anyLong())).willReturn(mockRes);

		BankAccountDocumentResponseV1 res = EXT.getJerseyTest().client()
				.target(UriBuilder.fromUri(uri))
				.request()
				.header("Authorization", WebCliHelper.JWT_MOCK_CREDENTIALS)
				.get(new GenericType<>() {
				});

		assertThat(res).isNotNull()
				.usingRecursiveComparison()
				.isEqualTo(mockRes);

		ArgumentCaptor<ReqContext> reqCtxCaptor = ArgumentCaptor.forClass(ReqContext.class);
		verify(bankAccountDocumentService).getBankAccountDocument(reqCtxCaptor.capture(), eq(partyId), eq(accountId), eq(documentId));
	}

	// ----- getDocumentFileContent -----
	@Test
	void test_getDocumentFileContent_ok() {
		Long partyId = 555L;
		Long accountId = 100L;
		Long documentId = 123L;
		String fileId = "theFileId";

		UriBuilder uriBuilder = UriBuilder.fromResource(resource.getClass()).path(resource.getClass(), "getDocumentFileContent");
		String uri = uriBuilder.build(TENANT, partyId, accountId, documentId, "my-bucket", fileId).toString();
		System.out.println(uri);

		Response mockRes = Response.ok("my file content".getBytes(), MediaType.TEXT_PLAIN_TYPE).build();
		given(bankAccountDocumentService.getDocumentFileContent(any(), anyLong(), anyLong(), anyLong(), anyString())).willReturn(mockRes);

		Response res = EXT.getJerseyTest().client()
				.target(UriBuilder.fromUri(uri))
				.request()
				.header("Authorization", WebCliHelper.JWT_MOCK_CREDENTIALS)
				.get();

		assertThat(res).isNotNull();
		assertThat(res.readEntity(String.class)).isNotNull()
				.isEqualTo("my file content");

		ArgumentCaptor<ReqContext> reqCtxCaptor = ArgumentCaptor.forClass(ReqContext.class);
		verify(bankAccountDocumentService).getDocumentFileContent(reqCtxCaptor.capture(), eq(partyId), eq(accountId), eq(documentId), eq(fileId));
	}

	// ----- getDocumentFileMetadata -----
	@Test
	void test_getDocumentFileMetadata_ok() {
		Long partyId = 555L;
		Long accountId = 100L;
		Long documentId = 123L;
		String fileId = "theFileId";

		UriBuilder uriBuilder = UriBuilder.fromResource(resource.getClass()).path(resource.getClass(), "getDocumentFileMetadata");
		String uri = uriBuilder.build(TENANT, partyId, accountId, documentId, "my-bucket", fileId).toString();
		System.out.println(uri);

		Response mockRes = Response.ok("my file content".getBytes(), MediaType.TEXT_PLAIN_TYPE)
				.header("hKey", "hValue").build();
		given(bankAccountDocumentService.getDocumentFileMetadata(any(), anyLong(), anyLong(), anyLong(), anyString())).willReturn(mockRes);

		Response res = EXT.getJerseyTest().client()
				.target(UriBuilder.fromUri(uri))
				.request()
				.header("Authorization", WebCliHelper.JWT_MOCK_CREDENTIALS)
				.head();

		assertThat(res).isNotNull();
		assertThat(res.getHeaderString("Content-type")).isNotNull()
				.isEqualTo(MediaType.TEXT_PLAIN_TYPE.toString());
		assertThat(res.getHeaderString("hKey")).isNotNull()
				.isEqualTo("hValue");

		ArgumentCaptor<ReqContext> reqCtxCaptor = ArgumentCaptor.forClass(ReqContext.class);
		verify(bankAccountDocumentService).getDocumentFileMetadata(reqCtxCaptor.capture(), eq(partyId), eq(accountId), eq(documentId), eq(fileId));
	}



	private BankAccountDocumentResBuilder<?, ?> baDocumentResBuilder(Long docId, Long accountId, String defCode) {
		return BankAccountDocumentRes.builder()
				.setBankAccountId(accountId)
				.setDefinitionCode(defCode)
				.setDocumentId(docId);
	}

}
