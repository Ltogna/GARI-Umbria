package com.abacogroup.ddm.bundle.tenant;

import static com.abacogroup.bundles.Constants.ALL_TENANTS;
import static org.assertj.core.api.Assertions.assertThat;

import com.abacogroup.bundles.initializer.impl.FileSupport;
import com.abacogroup.bundles.listener.configdata.ConfigDataMessage;
import com.abacogroup.bundles.listener.tenant.TenantMessage;
import com.abacogroup.ddm.bundle.config.DynamicDocConfigMessageProcessor;
import com.abacogroup.ddm.common.JdbiTest;
import com.abacogroup.ddm.db.dao.DocTypeRelationDAO;
import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;
import java.nio.file.Path;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

@ExtendWith(DropwizardExtensionsSupport.class)
class DynamicDocTenantMessageProcessorTest extends JdbiTest {

	private static final String TENANT_ID = String.format("%s_t", DynamicDocTenantMessageProcessorTest.class.getSimpleName());
	private final DynamicDocTenantMessageProcessor processor = getService(DynamicDocTenantMessageProcessor.class);

	@Test
	void onMessage() {

		DocTypeRelationDAO docTypeRelationDAO = getDAO(DocTypeRelationDAO.class);

		getJdbi().useHandle(handle -> {
			handle.begin();

			getService(DynamicDocConfigMessageProcessor.class).onMessage(new ConfigDataMessage(ALL_TENANTS, FileSupport.listFilesRecursive(
					Path.of("src/test/resources/com/abacogroup/ddm/bundle/tenant/DynamicDocTenantMessageProcessorTest/dynamic_documents"))));

			Long relations = docTypeRelationDAO.countAll(ALL_TENANTS);
			assertThat(relations).isGreaterThan(0);
			assertThat(docTypeRelationDAO.countAll(TENANT_ID)).isEqualTo(0);

			processor.onMessage(new TenantMessage()
					.setTenantId(TENANT_ID));

			assertThat(docTypeRelationDAO.countAll(TENANT_ID)).isEqualTo(relations);

			handle.rollback();
		});
	}

}
