package com.abacogroup.ddm.payment.core.impl;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;

import com.abacogroup.anomalyregistry.core.cli.v1.AnomalyClient;
import com.abacogroup.ddm.common.JdbiTest;
import com.abacogroup.ddm.common.ReqContextUtils;
import com.abacogroup.ddm.core.cli.FileStoreProxyClient;
import com.abacogroup.ddm.core.exceptions.InvalidDocumentException;
import com.abacogroup.ddm.core.exceptions.InvalidDocumentException.ErrEnum;
import com.abacogroup.ddm.payment.api.BankAccountDocumentRes;
import com.abacogroup.ddm.payment.api.req.BankAccountDocumentSearchReq;
import com.abacogroup.ddm.payment.core.BankAccountDocumentService;
import com.abacogroup.ddm.payment.db.dao.BankAccountDocumentDAO;
import com.abacogroup.dynamicdocuments.bean.Document;
import com.abacogroup.dynamicdocuments.bean.DocumentDefinition;
import com.abacogroup.dynamicdocuments.bean.InsertDocument;
import com.abacogroup.dynamicdocuments.bean.SummaryFieldDefinition;
import com.abacogroup.dynamicdocuments.bean.SummaryFieldValue;
import com.abacogroup.dynamicdocuments.bean.documentdefinition.FieldSet;
import com.abacogroup.dynamicdocuments.bean.documentdefinition.Metadata;
import com.abacogroup.dynamicdocuments.bean.documentdefinition.fieldset.Field;
import com.abacogroup.dynamicdocuments.bean.documentdefinition.fieldset.field.FieldType;
import com.abacogroup.dynamicdocuments.services.DocumentService;
import com.abacogroup.dynamicdocuments.services.DocumentTypeService;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;
import jakarta.ws.rs.core.Response;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Optional;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

@ExtendWith(DropwizardExtensionsSupport.class)
class BankAccountDocumentServiceImplTest extends JdbiTest {

	private final BankAccountDocumentService service = getService(BankAccountDocumentServiceImpl.class);

	private final DocumentService documentService = mock(DocumentService.class);
	private final DocumentTypeService documentTypeService = mock(DocumentTypeService.class);
	private final FileStoreProxyClient fileStoreProxyClient = mock(FileStoreProxyClient.class);
	private final AnomalyClient anomalyClient = mock(AnomalyClient.class);

	private ReqContextUtils ctx = new ReqContextUtils(this.getClass());

	private String bucketName = EXT.getConfiguration().getDynamicDocumentsBucket();

	@BeforeEach
	void setUp() {
		//ctx.getReqContext().setUser(new User(ctx.getUserId(), "token", ctx.getTenantId(), ctx.getUserId()));

		this.injectMock(service, documentService);
		this.injectMock(service, documentTypeService);
		this.injectMock(service, fileStoreProxyClient);
		this.injectMock(service, anomalyClient);
	}

	// ----- insert -----
	@Test
	void test_insert_ok() {
		setUnusedBindingAllowed(true);
		getJdbi().useHandle(handle -> {
			handle.begin();

			execSqlFiles(this.getClass(), List.of(
					"add_bank_accounts",
					"add_doc_type_rel",
					"add_bank_account_docs"
			), ctx.getTestScriptParams());

			Long partyId = 555L;
			Long accountId = -2L;

			String definitionCode = "DD_1";
			DocumentDefinition documentDefinition = givenDocDef(definitionCode, 1);
			given(documentTypeService.getDocumentDefinition(anyString(), anyString()))
					.willReturn(Optional.of(documentDefinition));

			Long docId = 999L;
			given(documentService.insertDocument(any(), any(), any(), any(), any(), any()))
					.willReturn(docId);

			Document doc = createDoc(Map.of("F_1", "id_assignment", "F_2", 987L));
			given(documentService.getDocumentFromId(anyLong()))
					.willReturn(doc);

			InsertDocument ins = new InsertDocument();
			ins.setDoc(doc);
			ins.setDefCode(definitionCode);
			ins.setBusinessId(accountId);
			ins.setLabel("Test Doc");

			// test
			BankAccountDocumentRes documentRes = service.insert(ctx.getReqContext(), partyId, accountId, ins);

			assertThat(documentRes).isNotNull()
					.extracting(
							BankAccountDocumentRes::getBankAccountId,
							BankAccountDocumentRes::getDocumentId,
							BankAccountDocumentRes::getDefinitionCode,
							BankAccountDocumentRes::getBucketName,
							BankAccountDocumentRes::getData
					).containsExactly(
							accountId,
							docId,
							definitionCode,
							bucketName,
							doc.getFields()
					);

			verify(documentTypeService).getDocumentDefinition(ctx.getTenantId(), definitionCode);
			verify(documentService).insertDocument(ctx.getTenantId(), definitionCode, doc, ctx.getUserId(), accountId, ins.getLabel());

			handle.rollback();
		});
	}

	@Test
	void test_insert_namespaceKo() {
		setUnusedBindingAllowed(true);
		getJdbi().useHandle(handle -> {
			handle.begin();

			execSqlFiles(this.getClass(), List.of(
					"add_bank_accounts",
					"add_doc_type_rel",
					"add_bank_account_docs"
			), ctx.getTestScriptParams());

			Long partyId = 555L;
			Long accountId = -2L;

			String definitionCode = "DD_99";
			DocumentDefinition documentDefinition = givenDocDef(definitionCode, 1);
			given(documentTypeService.getDocumentDefinition(anyString(), anyString()))
					.willReturn(Optional.of(documentDefinition));

			Document doc = createDoc(Map.of("F_1", "id_assignment", "F_2", 987L));

			InsertDocument ins = new InsertDocument();
			ins.setDoc(doc);
			ins.setDefCode(definitionCode);
			ins.setBusinessId(accountId);
			ins.setLabel("Test Doc");

			//test
			InvalidDocumentException invalidDocumentException = assertThrows(InvalidDocumentException.class,
					() -> service.insert(ctx.getReqContext(), partyId, accountId, ins));

			assertThat(invalidDocumentException).isNotNull()
					.satisfies(ex -> System.out.println(ex.getMessage()))
					.extracting(InvalidDocumentException::getCode).isEqualTo(ErrEnum.DYNAMIC_DOCUMENT_ERR.toString());

			verifyNoInteractions(documentService);

			handle.rollback();
		});
	}

	@Test
	void test_insert_maxOccoursKo() {
		setUnusedBindingAllowed(true);
		getJdbi().useHandle(handle -> {
			handle.begin();

			execSqlFiles(this.getClass(), List.of(
					"add_bank_accounts",
					"add_doc_type_rel",
					"add_bank_account_docs"
			), ctx.getTestScriptParams());

			Long partyId = 555L;
			Long accountId = -1L;

			String definitionCode = "DD_1";
			DocumentDefinition documentDefinition = givenDocDef(definitionCode, 1);
			given(documentTypeService.getDocumentDefinition(anyString(), anyString()))
					.willReturn(Optional.of(documentDefinition));

			Document doc = createDoc(Map.of("F_1", "id_assignment", "F_2", 987L));

			InsertDocument ins = new InsertDocument();
			ins.setDoc(doc);
			ins.setDefCode(definitionCode);
			ins.setBusinessId(accountId);
			ins.setLabel("Test Doc");

			//test
			InvalidDocumentException invalidDocumentException = assertThrows(InvalidDocumentException.class,
					() -> service.insert(ctx.getReqContext(), partyId, accountId, ins));

			assertThat(invalidDocumentException).isNotNull()
					.satisfies(ex -> System.out.println(ex.getMessage()))
					.extracting(InvalidDocumentException::getCode).isEqualTo(ErrEnum.DYNAMIC_DOCUMENT_ERR.toString());

			verifyNoInteractions(documentService);

			handle.rollback();
		});
	}


	// ----- update -----
	@Test
	void test_update_ok() {
		setUnusedBindingAllowed(true);
		getJdbi().useHandle(handle -> {
			handle.begin();

			execSqlFiles(this.getClass(), List.of(
					"add_bank_accounts",
					"add_doc_type_rel",
					"add_bank_account_docs"
			), ctx.getTestScriptParams());

			Long partyId = 555L;
			Long accountId = -1L;
			Long docId = 90101L;

			Document doc = createDoc(Map.of("F_1", "id_assignment", "F_2", 987L));
			Document updatedDoc = createDoc(Map.of("F_1", "updated", "F_2", 987L));
			given(documentService.getDocumentFromId(anyLong()))
					.willReturn(doc).willReturn(updatedDoc);

			//test
			BankAccountDocumentRes documentRes = service.update(ctx.getReqContext(), partyId, accountId, docId, updatedDoc);

			assertThat(documentRes).isNotNull()
					.extracting(
							BankAccountDocumentRes::getBankAccountId,
							BankAccountDocumentRes::getDocumentId,
							BankAccountDocumentRes::getDefinitionCode,
							BankAccountDocumentRes::getBucketName,
							BankAccountDocumentRes::getData
					).containsExactly(
							accountId,
							docId,
							"DD_1",
							bucketName,
							updatedDoc.getFields()
					);

			verify(documentService).updateDocument(docId, updatedDoc, ctx.getUserId());

			handle.rollback();
		});
	}

	// ----- expire -----
	@Test
	void test_expire_ok() {
		setUnusedBindingAllowed(true);
		getJdbi().useHandle(handle -> {
			handle.begin();

			execSqlFiles(this.getClass(), List.of(
					"add_bank_accounts",
					"add_doc_type_rel",
					"add_bank_account_docs"
			), ctx.getTestScriptParams());

			Long partyId = 555L;
			Long accountId = -1L;
			Long docId = 90101L;

			Document doc = createDoc(Map.of("F_1", "id_assignment", "F_2", 987L));
			given(documentService.getDocumentFromId(anyLong()))
					.willReturn(doc);

			//test
			service.expire(ctx.getReqContext(), partyId, accountId, docId);

			assertThat(handle.attach(BankAccountDocumentDAO.class).findByDocumentIdAndAccountId(ctx.getTenantId(), docId, accountId)).isEmpty();

			verify(documentService).updateDocument(docId, doc, ctx.getUserId());

			handle.rollback();
		});
	}

	// ----- search -----
	@Test
	void test_search_ok() {
		setUnusedBindingAllowed(true);
		getJdbi().useHandle(handle -> {
			handle.begin();

			execSqlFiles(this.getClass(), List.of(
					"add_bank_accounts",
					"add_doc_type_rel",
					"add_bank_account_docs"
			), ctx.getTestScriptParams());

			Long partyId = 555L;
			Long accountId = -1L;
			BankAccountDocumentSearchReq searchReq = new BankAccountDocumentSearchReq();

			Document doc1 = createDoc(Map.of("F_1", "res 1", "F_2", 987L));
			given(documentService.getDocumentFromId(90101L)).willReturn(doc1);
			Document doc2 = createDoc(Map.of("F_1", "res 2", "F_2", 654L));
			given(documentService.getDocumentFromId(90102L)).willReturn(doc2);

			DocumentDefinition documentDefinition = givenDocDef("DD_X", 1);
			given(documentTypeService.getDocumentDefinition(anyString(), anyString()))
					.willReturn(Optional.of(documentDefinition));

			given(documentService.getSummaryValues(any(), eq(doc1), anyString()))
					.willReturn(List.of(new SummaryFieldValue("F_1", "res 1")));
			given(documentService.getSummaryValues(any(), eq(doc2), anyString()))
					.willReturn(List.of(new SummaryFieldValue("F_1", "res 2")));

			List<SummaryFieldDefinition> summaryFieldDefinitions = List.of(SummaryFieldDefinition.builder()
					.code("F_1").description("field1").fieldType(FieldType.STRING).build());
			given(documentTypeService.getSummaryFields(any(), anyString()))
					.willReturn(summaryFieldDefinitions);

			//test
			InfiniteListResults<BankAccountDocumentRes> results = service.search(ctx.getReqContext(), partyId, accountId, searchReq, null);

			assertThat(results).isNotNull()
					.extracting(InfiniteListResults::getRecords)
					.asList().hasSize(2)
					.containsExactlyInAnyOrder(
							BankAccountDocumentRes.builder()
									.setBankAccountId(accountId)
									.setDocumentId(90101L)
									.setBucketName(bucketName)
									.setDefinitionCode("DD_1")
									.setSummaryFieldDefinitions(summaryFieldDefinitions)
									.setData(new LinkedHashMap<>(Map.of(
											"F_1", "res 1"
									))).build(),
							BankAccountDocumentRes.builder()
									.setBankAccountId(accountId)
									.setDocumentId(90102L)
									.setBucketName(bucketName)
									.setDefinitionCode("DD_2")
									.setSummaryFieldDefinitions(summaryFieldDefinitions)
									.setData(new LinkedHashMap<>(Map.of(
											"F_1", "res 2"
									))).build()
					);

			handle.rollback();
		});
	}

	// ----- getDocumentFileContent -----
	// ----- getDocumentFileMetadata -----
	@Test
	void test_getDocumentFileContent_getDocumentFileMetadata_ok() {
		setUnusedBindingAllowed(true);
		getJdbi().useHandle(handle -> {
			handle.begin();

			execSqlFiles(this.getClass(), List.of(
					"add_bank_accounts",
					"add_doc_type_rel",
					"add_bank_account_docs"
			), ctx.getTestScriptParams());

			Long partyId = 555L;
			Long accountId = -1L;
			Long docId = 90101L;
			String fileId = "path/to/file";

			Document doc1 = createDoc(Map.of(
					"F_1", "res 1",
					"F_2", 987L,
					"file", fileId));
			given(documentService.getDocumentFromId(anyLong())).willReturn(doc1);

			DocumentDefinition documentDefinition = givenDocDef("DD_1", 1);
			given(documentTypeService.getDocumentDefinition(anyString(), anyString()))
					.willReturn(Optional.of(documentDefinition));

			Response mockResponse = Response.ok().build();
			given(fileStoreProxyClient.getFileContent(anyString(), any(), anyString(), anyString()))
					.willReturn(mockResponse);
			given(fileStoreProxyClient.getFileMetadata(anyString(), any(), anyString(), anyString()))
					.willReturn(mockResponse);

			//test
			Response fileContent = service.getDocumentFileContent(ctx.getReqContext(), partyId, accountId, docId, fileId);
			//test
			Response fileMetadata = service.getDocumentFileMetadata(ctx.getReqContext(), partyId, accountId, docId, fileId);

			assertThat(fileContent).isEqualTo(mockResponse);
			assertThat(fileMetadata).isEqualTo(mockResponse);

			verify(fileStoreProxyClient).getFileContent("en", ctx.getReqContext().getUser(), bucketName, fileId);
			verify(fileStoreProxyClient).getFileMetadata("en", ctx.getReqContext().getUser(), bucketName, fileId);

			handle.rollback();
		});
	}

	private Document createDoc(Map<String, Object> item) {
		Document doc = new Document();

		Map<String, Object> fields = new HashMap<>();
		for (Entry<String, Object> entry : item.entrySet()) {
			String key = entry.getKey();
			Object value = entry.getValue();
			fields.put(key, value);
		}

		doc.setFields(fields);

		return doc;
	}

	private DocumentDefinition givenDocDef(final String definitionCode, final int maxOccurs) {
		return new DocumentDefinition() {{
			setMetadata(new Metadata() {{
				this.setMaxOccurs(maxOccurs);
				this.setSummaryFields(List.of("F_1"));
			}});
			setCode(definitionCode);
			setVersion("1.2.3");
			setFieldSets(List.of(
					new FieldSet() {{
						this.setCode("FS_1");
						this.setFields(List.of(
								new Field() {{
									this.setCode("F_1");
									this.setType(FieldType.STRING);
								}},
								new Field() {{
									this.setCode("F_2");
									this.setType(FieldType.LONG);
								}},
								new Field() {{
									this.setCode("file");
									this.setType(FieldType.FILE);
								}}
						));
					}}
			));
		}};
	}

}
