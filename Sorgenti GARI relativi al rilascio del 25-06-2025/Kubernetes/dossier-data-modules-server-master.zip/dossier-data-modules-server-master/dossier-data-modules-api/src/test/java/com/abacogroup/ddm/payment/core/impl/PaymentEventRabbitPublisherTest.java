package com.abacogroup.ddm.payment.core.impl;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.mock;

import com.abacogroup.ddm.DossierDataModulesTestApplication;
import com.abacogroup.ddm.payment.core.dto.PaymentEventType;
import com.abacogroup.ddm.payment.core.dto.PaymentQueueMessage;
import com.abacogroup.ddm.payment.core.dto.PaymentQueueMessage.PaymentQueueMessageBuilder;
import com.abacogroup.ddm.payment.db.dao.BankAccountDAO;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import java.io.IOException;
import java.time.LocalDateTime;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class PaymentEventRabbitPublisherTest  {

	private final ObjectMapper objectMapper = DossierDataModulesTestApplication.getObjectMapper();
	private PaymentEventRabbitPublisher paymentEventPublisher;

	@BeforeEach
	void setUp() throws IOException {
		Connection connection = mock(Connection.class);
		BankAccountDAO bankAccountDAO = mock(BankAccountDAO.class);

		given(connection.createChannel()).willReturn(mock(Channel.class));

		paymentEventPublisher = new PaymentEventRabbitPublisher(connection, objectMapper, bankAccountDAO);
	}

	// ----- getPayload -----
	@Test
	void test_getPayload_ok() throws Exception {

		PaymentQueueMessageBuilder<?, ?> builder = PaymentQueueMessage.builder()
				.setTenant("the_tenant")
				.setUsername("the_user")
				.setLang("en")
				.setAccountId(123L)
				.setPartyId(555L)
				.setDate(LocalDateTime.now());


		assertThat(paymentEventPublisher.getPayload(builder
				.setEventType(PaymentEventType.NEW_BANK_ACCOUNT)
				.build()))
				.isEqualTo(objectMapper.writeValueAsBytes(builder
						.setEventType(PaymentEventType.NEW_BANK_ACCOUNT)
						.build()));

	}
}
