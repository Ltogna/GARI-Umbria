package com.abacogroup.ddm.payment.core.impl;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.only;
import static org.mockito.Mockito.verify;

import org.junit.jupiter.api.Test;

import com.abacogroup.ddm.common.ReqContextUtils;
import com.abacogroup.ddm.core.PartyService;
import com.abacogroup.ddm.core.exceptions.BankAccountException;
import com.abacogroup.ddm.core.exceptions.BankAccountException.ErrEnum;
import com.abacogroup.ddm.core.impl.PartyServiceImpl;
import com.abacogroup.partyregistry.api.v1.PartyResponseV1;
import com.abacogroup.partyregistry.core.cli.v1.PartyClientV1;

import jakarta.ws.rs.BadRequestException;
import jakarta.ws.rs.InternalServerErrorException;
import jakarta.ws.rs.ServerErrorException;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.core.Response.Status;


class PartyServiceImplTest {

	private final ReqContextUtils ctx = new ReqContextUtils(this.getClass());

	private final PartyClientV1 partyClient = mock(PartyClientV1.class);

	private final PartyService service = new PartyServiceImpl(partyClient);

	// ----- validatePartyId -----
	@Test
	void test_validatePartyId_ok() {

		Long partyId = 555L;

		given(partyClient.getById(anyString(), any(), anyLong()))
				.willAnswer(i -> new PartyResponseV1().setId(i.getArgument(2)));

		// test
		service.validatePartyId(ctx.getReqContext(), partyId);

		verify(partyClient, only()).getById(ctx.getReqContext().getLang(), ctx.getReqContext().getUser(), partyId);

	}

	@Test
	void test_validatePartyId_nullKo() {

		Long partyId = 555L;

		given(partyClient.getById(anyString(), any(), anyLong()))
				.willReturn(null);

		// test
		BankAccountException bankAccountException = assertThrows(BankAccountException.class,
				() -> service.validatePartyId(ctx.getReqContext(), partyId));

		assertThat(bankAccountException)
				.satisfies(e -> System.out.println(e.getMessage()))
				.extracting(e -> e.getErrorBody().getErrorCode()).isEqualTo(ErrEnum.INVALID_PARTY.toString());
		verify(partyClient, only()).getById(ctx.getReqContext().getLang(), ctx.getReqContext().getUser(), partyId);

	}

	@Test
	void test_validatePartyId_400Ko() {

		Long partyId = 555L;

		given(partyClient.getById(anyString(), any(), anyLong()))
				.willThrow(new BadRequestException(Response.status(400).entity("not found").build()));

		// test
		BankAccountException bankAccountException = assertThrows(BankAccountException.class,
				() -> service.validatePartyId(ctx.getReqContext(), partyId));

		assertThat(bankAccountException)
				.satisfies(e -> System.out.println(e.getMessage()))
				.extracting(e -> e.getErrorBody().getErrorCode()).isEqualTo(ErrEnum.INVALID_PARTY.toString());
		verify(partyClient, only()).getById(ctx.getReqContext().getLang(), ctx.getReqContext().getUser(), partyId);

	}

	@Test
	void test_validatePartyId_500Ko() {

		Long partyId = 555L;

		given(partyClient.getById(anyString(), any(), anyLong()))
				.willThrow(new InternalServerErrorException(Response.status(500).entity("server error").build()));

		// test
		ServerErrorException serverErrorException = assertThrows(ServerErrorException.class,
				() -> service.validatePartyId(ctx.getReqContext(), partyId));

		assertThat(serverErrorException)
				.satisfies(e -> System.out.println(e.getMessage()))
				.extracting(e -> e.getResponse().getStatus()).isEqualTo(Status.BAD_GATEWAY.getStatusCode());
		verify(partyClient, only()).getById(ctx.getReqContext().getLang(), ctx.getReqContext().getUser(), partyId);

	}

	@Test
	void test_validatePartyId_errorKo() {

		Long partyId = 555L;

		given(partyClient.getById(anyString(), any(), anyLong()))
				.willThrow(new RuntimeException("this is a test"));

		// test
		InternalServerErrorException serverErrorException = assertThrows(InternalServerErrorException.class,
				() -> service.validatePartyId(ctx.getReqContext(), partyId));

		assertThat(serverErrorException)
				.satisfies(e -> System.out.println(e.getMessage()))
				.extracting(e -> e.getResponse().getStatus()).isEqualTo(Status.INTERNAL_SERVER_ERROR.getStatusCode());
		verify(partyClient, only()).getById(ctx.getReqContext().getLang(), ctx.getReqContext().getUser(), partyId);

	}

}
