package com.abacogroup.ddm.bundle.config;

import static com.abacogroup.ddm.DossierDataModulesApplication.PAYMENT_MODULE;

import com.abacogroup.bundles.listener.configdata.ConfigDataMessage;
import com.abacogroup.ddm.api.AnomalyLevelEnum;
import com.abacogroup.ddm.common.JdbiTest;
import com.abacogroup.ddm.common.ReqContextUtils;
import com.abacogroup.ddm.db.dao.AnomalyCategoriesDAO;
import com.abacogroup.ddm.db.ntt.AnomalyCategoriesEntity;
import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;
import java.util.List;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

@ExtendWith(DropwizardExtensionsSupport.class)
class AnomalyCategoriesConfigMessageProcessorTest extends JdbiTest {

	private ReqContextUtils ctx = new ReqContextUtils(this.getClass());

	private final AnomalyCategoriesConfigMessageProcessor processor = getService(AnomalyCategoriesConfigMessageProcessor.class);

	// ----- onMessage -----
	@Test
	void test_onMessage_ADD() {
		var message = new ConfigDataMessage()
				.setTenantId(ctx.getTenantId())
				.setConfigFiles(List.of(
						file2Path.apply("anomaly-categories.jsonl")
				));

		getJdbi().useHandle(handle -> {
			handle.begin();
			AnomalyCategoriesDAO dao = handle.attach(AnomalyCategoriesDAO.class);

			Assertions.assertThat(dao.countAll(ctx.getTenantId())).isEqualTo(0L);

			processor.onMessage(message);

			Assertions.assertThat(dao.countAll(ctx.getTenantId())).isEqualTo(5L);

			Assertions.assertThat(dao.findByTenantGroupCodeAndCode(ctx.getTenantId(), PAYMENT_MODULE, "test", "01"))
					.isNotNull()
					.isEqualTo(AnomalyCategoriesEntity.builder()
							.setNamespace(PAYMENT_MODULE)
							.setGroupCode("test")
							.setCode("01")
							.setLevel(AnomalyLevelEnum.INFO)
							.setFlExclude(0)
							.build());
			Assertions.assertThat(dao.findByTenantGroupCodeAndCode(ctx.getTenantId(), PAYMENT_MODULE, "test", "excluded-1"))
					.isNotNull()
					.isEqualTo(AnomalyCategoriesEntity.builder()
							.setNamespace(PAYMENT_MODULE)
							.setGroupCode("test")
							.setCode("excluded-1")
							.setLevel(AnomalyLevelEnum.WARN)
							.setFlExclude(1)
							.build());
			Assertions.assertThat(dao.findByTenantGroupCodeAndCode(ctx.getTenantId(), PAYMENT_MODULE, "test", "excluded-2"))
					.isNotNull();
			Assertions.assertThat(dao.findByTenantGroupCodeAndCode(ctx.getTenantId(), PAYMENT_MODULE, "test", "02"))
					.isNotNull();
			Assertions.assertThat(dao.findByTenantGroupCodeAndCode(ctx.getTenantId(), PAYMENT_MODULE, "test", "03"))
					.isNotNull();

			handle.rollback();
		});
	}

	@Test
	void test_onMessage_REMOVE() {
		var message = new ConfigDataMessage()
				.setTenantId(ctx.getTenantId())
				.setConfigFiles(List.of(
						file2Path.apply("anomaly-categories.delete.jsonl")
				));

		getJdbi().useHandle(handle -> {
			handle.begin();
			AnomalyCategoriesDAO dao = handle.attach(AnomalyCategoriesDAO.class);

			processor.onMessage(new ConfigDataMessage()
					.setTenantId(ctx.getTenantId())
					.setConfigFiles(List.of(
							file2Path.apply("anomaly-categories.jsonl")
					)));

			Assertions.assertThat(dao.countAll(ctx.getTenantId())).isEqualTo(5L);

			processor.onMessage(message);

			Assertions.assertThat(dao.countAll(ctx.getTenantId())).isEqualTo(3L);

			Assertions.assertThat(dao.findByTenantGroupCodeAndCode(ctx.getTenantId(), PAYMENT_MODULE, "test", "01"))
					.isNotNull();
			Assertions.assertThat(dao.findByTenantGroupCodeAndCode(ctx.getTenantId(), PAYMENT_MODULE, "test", "excluded-1"))
					.isNull();
			Assertions.assertThat(dao.findByTenantGroupCodeAndCode(ctx.getTenantId(), PAYMENT_MODULE, "test", "excluded-2"))
					.isNull();
			Assertions.assertThat(dao.findByTenantGroupCodeAndCode(ctx.getTenantId(), PAYMENT_MODULE, "test", "02"))
					.isNotNull();
			Assertions.assertThat(dao.findByTenantGroupCodeAndCode(ctx.getTenantId(), PAYMENT_MODULE, "test", "03"))
					.isNotNull();

			handle.rollback();
		});
	}


}
