package com.abacogroup.ddm.payment.resource;

import static com.abacogroup.ddm.common.WebCliHelper.TENANT;
import static com.abacogroup.ddm.payment.core.impl.AnomalyHelper.BANK_ACCOUNT_CODE;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.any;
import static org.mockito.Mockito.anyLong;
import static org.mockito.Mockito.anyString;
import static org.mockito.Mockito.eq;
import static org.mockito.Mockito.isNull;
import static org.mockito.Mockito.only;
import static org.mockito.Mockito.verify;

import com.abacogroup.anomalyregistry.api.v1.AnomalySearchResponse;
import com.abacogroup.anomalyregistry.api.v1.AnomalyTypeResponse;
import com.abacogroup.ddm.api.AnomalyLevelEnum;
import com.abacogroup.ddm.api.DdmAnomaliesRes;
import com.abacogroup.ddm.common.WebCliHelper;
import com.abacogroup.ddm.common.resources.ReqContext;
import com.abacogroup.ddm.payment.api.BankAccountRes;
import com.abacogroup.ddm.payment.api.BankAccountRes.BankAccountResBuilder;
import com.abacogroup.ddm.payment.api.BankAccountSearchRes;
import com.abacogroup.ddm.payment.api.BankAccountSearchRes.BankAccountSearchResBuilder;
import com.abacogroup.ddm.payment.api.BankNetworkEnum;
import com.abacogroup.ddm.payment.api.req.BankAccountCreateReq;
import com.abacogroup.ddm.payment.api.req.BankAccountPatchReq;
import com.abacogroup.ddm.payment.api.req.BankAccountSearchReq;
import com.abacogroup.ddm.payment.api.req.BankAccountUpdateReq;
import com.abacogroup.ddm.payment.api.v1.req.ActiveEnum;
import com.abacogroup.ddm.payment.core.BankAccountService;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.jdbi.model.AuditEntity;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.jdbi.paging.impl.InfiniteListResultsImpl;
import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;
import io.dropwizard.testing.junit5.ResourceExtension;
import jakarta.ws.rs.client.Entity;
import jakarta.ws.rs.core.GenericType;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.core.UriBuilder;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;

@ExtendWith(DropwizardExtensionsSupport.class)
class BankAccountResourceTest {

	private final BankAccountService bankAccountService = Mockito.mock(BankAccountService.class);

	private final BankAccountResource resource = new BankAccountResource(bankAccountService);
	private final ResourceExtension EXT = WebCliHelper.createEXT(resource);

	// ----- search -----
	@Test
	void test_search_ok() {
		Long partyId = 555L;
		Long accountId = 100L;

		BankAccountSearchReq searchReq = new BankAccountSearchReq()
				.setActive(ActiveEnum.only_active)
				.setDescription("descr")
				.setIban("IT08W0300203280185367754125")
				.setNetwork(BankNetworkEnum.SEPA);

		Map<String, Object> queryMap = new HashMap<>(EXT.getObjectMapper().convertValue(searchReq, Map.class));
		queryMap.put("nextKey", "111");

		UriBuilder uriBuilder = UriBuilder.fromResource(resource.getClass()).path(resource.getClass(), "search");
		queryMap.forEach(uriBuilder::queryParam);
		String uri = uriBuilder.build(TENANT, partyId).toString();
		System.out.println(uri);

		BankAccountSearchRes mockRes = givenBankAccountSearchRes(partyId, accountId).build();
		given(bankAccountService.search(any(), anyLong(), any(), anyString()))
				.willReturn(new InfiniteListResultsImpl<>(List.of(mockRes), null));

		InfiniteListResultsImpl<BankAccountSearchRes> res = EXT.getJerseyTest().client()
				.target(UriBuilder.fromUri(uri))
				.request()
				.header("Authorization", WebCliHelper.JWT_MOCK_CREDENTIALS)
				.get(new GenericType<>() {
				});

		assertThat(res).isNotNull()
				.extracting(InfiniteListResults::getRecords)
				.asList().containsExactly(mockRes);

		verify(bankAccountService).search(any(ReqContext.class), eq(partyId), eq(searchReq), eq("111"));
	}

	@Test
	void test_search_emptyOk() {
		Long partyId = 555L;
		Long accountId = 100L;

		BankAccountSearchReq searchReq = new BankAccountSearchReq();

		UriBuilder uriBuilder = UriBuilder.fromResource(resource.getClass()).path(resource.getClass(), "search");
		String uri = uriBuilder.build(TENANT, partyId).toString();
		System.out.println(uri);

		BankAccountSearchRes mockRes = givenBankAccountSearchRes(partyId, accountId).build();
		given(bankAccountService.search(any(), anyLong(), any(), any()))
				.willReturn(new InfiniteListResultsImpl<>(List.of(mockRes), null));

		InfiniteListResultsImpl<BankAccountSearchRes> res = EXT.getJerseyTest().client()
				.target(UriBuilder.fromUri(uri))
				.request()
				.header("Authorization", WebCliHelper.JWT_MOCK_CREDENTIALS)
				.get(new GenericType<>() {
				});

		assertThat(res).isNotNull()
				.extracting(InfiniteListResults::getRecords)
				.asList().containsExactly(mockRes);

		verify(bankAccountService).search(any(ReqContext.class), eq(partyId), eq(searchReq), isNull());
	}

	// ----- getById -----
	@Test
	void test_getById_ok() {
		Long partyId = 555L;
		Long accountId = 100L;

		UriBuilder uriBuilder = UriBuilder.fromResource(resource.getClass()).path(resource.getClass(), "getById");
		String uri = uriBuilder.build(TENANT, partyId, accountId).toString();
		System.out.println(uri);

		BankAccountSearchRes mockRes = givenBankAccountSearchRes(partyId, accountId).build();
		given(bankAccountService.getById(any(), anyLong(), anyLong())).willReturn(Optional.of(mockRes));

		BankAccountSearchRes res = EXT.getJerseyTest().client()
				.target(UriBuilder.fromUri(uri))
				.request()
				.header("Authorization", WebCliHelper.JWT_MOCK_CREDENTIALS)
				.get(new GenericType<>() {
				});

		assertThat(res).isNotNull().isEqualTo(mockRes);

		verify(bankAccountService).getById(any(ReqContext.class), eq(partyId), eq(accountId));
	}

	@Test
	void test_getById_empty() {
		Long partyId = 555L;
		Long accountId = 100L;

		UriBuilder uriBuilder = UriBuilder.fromResource(resource.getClass()).path(resource.getClass(), "getById");
		String uri = uriBuilder.build(TENANT, partyId, accountId).toString();
		System.out.println(uri);

		given(bankAccountService.getById(any(), anyLong(), anyLong())).willReturn(Optional.empty());

		BankAccountRes res = EXT.getJerseyTest().client()
				.target(UriBuilder.fromUri(uri))
				.request()
				.header("Authorization", WebCliHelper.JWT_MOCK_CREDENTIALS)
				.get(new GenericType<>() {
				});

		assertThat(res).isNull();

		verify(bankAccountService).getById(any(ReqContext.class), eq(partyId), eq(accountId));
	}

	// ----- getActiveDefault -----
	@Test
	void test_getActiveDefault_ok() {
		Long partyId = 555L;
		Long accountId = 100L;

		UriBuilder uriBuilder = UriBuilder.fromResource(resource.getClass()).path(resource.getClass(), "getActiveDefault");
		String uri = uriBuilder.build(TENANT, partyId).toString();
		System.out.println(uri);

		BankAccountSearchRes mockRes = givenBankAccountSearchRes(partyId, accountId).build();
		given(bankAccountService.getActiveDefault(any(), anyLong())).willReturn(Optional.of(mockRes));

		BankAccountSearchRes res = EXT.getJerseyTest().client()
				.target(UriBuilder.fromUri(uri))
				.request()
				.header("Authorization", WebCliHelper.JWT_MOCK_CREDENTIALS)
				.get(new GenericType<>() {
				});

		assertThat(res).isNotNull().isEqualTo(mockRes);

		verify(bankAccountService).getActiveDefault(any(ReqContext.class), eq(partyId));
	}

	// ----- addAccount -----
	@Test
	void test_addAccount_ok() {
		Long partyId = 555L;

		String uri = UriBuilder.fromResource(resource.getClass())//.path(GroupResource.class, "createGroup")
				.build(TENANT, partyId).toString();
		System.out.println(uri);

		BankAccountSearchRes mockRes = givenBankAccountSearchRes(partyId, 100L).build();
		given(bankAccountService.insert(any(), anyLong(), any())).willReturn(mockRes);

		BankAccountCreateReq createReq = BankAccountCreateReq.builder()
				.setNetwork(BankNetworkEnum.SEPA)
				.setIban("IT08W0300203280185367754125")
				.setSwiftBic("UNCRITMMXXX")
				.setBankName("UNICREDIT BANCA DI ROMA SPA")
				.setBankCountry("Italy (IT)")
				.setBankBranch("ROMA 80 - PIAZZA MONTE")
				.setDescription("test resource")
				.setDefaultBankAccount(true)
				.setDayFrom(AbsoluteDate.of(LocalDate.ofEpochDay(0)))
				.build();

		BankAccountSearchRes res = EXT.getJerseyTest().target()
				.path(uri)
				.request()
				.header("Authorization", WebCliHelper.JWT_MOCK_CREDENTIALS)
				.post(Entity.json(createReq), new GenericType<>() {
				});

		assertThat(res).isNotNull().isEqualTo(mockRes);
		Mockito.verify(bankAccountService, only()).insert(any(ReqContext.class), eq(partyId), eq(createReq));
	}

	@Test
	void test_addAccount_emptyKo() {
		Long partyId = 555L;

		String uri = UriBuilder.fromResource(resource.getClass())//.path(GroupResource.class, "createGroup")
				.build(TENANT, partyId).toString();
		System.out.println(uri);

		assertThat(EXT.getJerseyTest().target()
				.path(uri)
				.request()
				.header("Authorization", WebCliHelper.JWT_MOCK_CREDENTIALS)
				.post(Entity.json("{}")))
				.satisfies(r -> System.out.println(r.readEntity(String.class)))
				.extracting(Response::getStatus).isEqualTo(422);

	}

	// ----- updateAccount -----
	@Test
	void test_updateAccount_ok() {
		Long partyId = 555L;
		Long accountId = 100L;

		String uri = UriBuilder.fromResource(resource.getClass()).path(resource.getClass(), "updateAccount")
				.build(TENANT, partyId, accountId).toString();
		System.out.println(uri);

		BankAccountSearchRes mockRes = givenBankAccountSearchRes(partyId, accountId).build();
		given(bankAccountService.update(any(), anyLong(), any(), any())).willReturn(mockRes);

		BankAccountUpdateReq updateReq = BankAccountUpdateReq.builder()
				.setDescription("test resource")
				.setDefaultBankAccount(true)
				.build();

		BankAccountSearchRes res = EXT.getJerseyTest().target()
				.path(uri)
				.request()
				.header("Authorization", WebCliHelper.JWT_MOCK_CREDENTIALS)
				.put(Entity.json(updateReq), new GenericType<>() {
				});

		assertThat(res).isNotNull().isEqualTo(mockRes);
		Mockito.verify(bankAccountService, only()).update(any(ReqContext.class), eq(partyId), eq(accountId), eq(updateReq));
	}

	@Test
	void test_updateAccount_emptyOk() {
		Long partyId = 555L;
		Long accountId = 100L;

		String uri = UriBuilder.fromResource(resource.getClass()).path(resource.getClass(), "updateAccount")
				.build(TENANT, partyId, accountId).toString();
		System.out.println(uri);

		BankAccountSearchRes mockRes = givenBankAccountSearchRes(partyId, accountId).build();
		given(bankAccountService.update(any(), anyLong(), any(), any())).willReturn(mockRes);

		BankAccountSearchRes res = EXT.getJerseyTest().target()
				.path(uri)
				.request()
				.header("Authorization", WebCliHelper.JWT_MOCK_CREDENTIALS)
				.put(Entity.json("{}"), new GenericType<>() {
				});

		assertThat(res).isNotNull().isEqualTo(mockRes);
		Mockito.verify(bankAccountService, only()).update(any(ReqContext.class), eq(partyId), eq(accountId),
				eq(BankAccountUpdateReq.builder().setDefaultBankAccount(false).build()));
	}

	// ----- updateAccountDayTo -----
	@Test
	void test_updateAccountDayTo_ok() {
		Long partyId = 555L;
		Long accountId = 100L;

		String uri = UriBuilder.fromResource(resource.getClass()).path(resource.getClass(), "updateAccountDayTo")
				.build(TENANT, partyId, accountId).toString();
		System.out.println(uri);

		BankAccountSearchRes mockRes = givenBankAccountSearchRes(partyId, accountId).build();
		given(bankAccountService.updateDayTo(any(), anyLong(), any(), any())).willReturn(mockRes);

		BankAccountPatchReq updateReq = BankAccountPatchReq.builder()
				.setDayTo(AbsoluteDate.of("20100102"))
				.build();

		BankAccountSearchRes res = EXT.getJerseyTest().target()
				.path(uri)
				.request()
				.header("Authorization", WebCliHelper.JWT_MOCK_CREDENTIALS)
				.method("PUT", Entity.json(updateReq), new GenericType<>() {
				});

		assertThat(res).isNotNull().isEqualTo(mockRes);
		Mockito.verify(bankAccountService, only()).updateDayTo(any(ReqContext.class), eq(partyId), eq(accountId), eq(updateReq.getDayTo()));
	}

	@Test
	void test_updateAccountDayTo_emptyKo() {
		Long partyId = 555L;
		Long accountId = 100L;

		String uri = UriBuilder.fromResource(resource.getClass()).path(resource.getClass(), "updateAccountDayTo")
				.build(TENANT, partyId, accountId).toString();
		System.out.println(uri);

		assertThat(EXT.getJerseyTest().target()
				.path(uri)
				.request()
				.header("Authorization", WebCliHelper.JWT_MOCK_CREDENTIALS)
				.method("PUT", Entity.json("{}")))
				.satisfies(r -> System.out.println(r.readEntity(String.class)))
				.extracting(Response::getStatus).isEqualTo(422);
	}


	private BankAccountResBuilder<?, ?> givenBankAccountRes(Long partyId, Long accountId) {
		return BankAccountRes.builder()
				.setId(accountId)
				.setPartyId(partyId)
				.setNetwork(BankNetworkEnum.SEPA)
				.setIban("IT08W0300203280185367754125")
				.setSwiftBic("UNCRITMMXXX")
				.setBankName("UNICREDIT BANCA DI ROMA SPA")
				.setBankCountry("Italy (IT)")
				.setBankBranch("ROMA 80 - PIAZZA MONTE")
				.setDescription("test resource")
				.setDefaultBankAccount(true)
				.setDayFrom(AbsoluteDate.of(LocalDate.ofEpochDay(0)))
				.setDayTo(AbsoluteDate.of(AuditEntity.dateActive));
	}

	private BankAccountSearchResBuilder<?, ?> givenBankAccountSearchRes(Long partyId, Long accountId) {
		return BankAccountSearchRes.builder()
				.setId(accountId)
				.setPartyId(partyId)
				.setNetwork(BankNetworkEnum.SEPA)
				.setIban("IT08W0300203280185367754125")
				.setSwiftBic("UNCRITMMXXX")
				.setBankName("UNICREDIT BANCA DI ROMA SPA")
				.setBankCountry("Italy (IT)")
				.setBankBranch("ROMA 80 - PIAZZA MONTE")
				.setDescription("test resource")
				.setDefaultBankAccount(true)
				.setDayFrom(AbsoluteDate.of(LocalDate.ofEpochDay(0)))
				.setDayTo(AbsoluteDate.of(AuditEntity.dateActive))
				.setAnomalies(DdmAnomaliesRes.builder()
						.setAnomaliesGrouped(Map.of(AnomalyLevelEnum.INFO, List.of(
								AnomalySearchResponse.builder()
										.setType(AnomalyTypeResponse.builder()
												.setCode("TEST")
												.setGroupCode("test.bank-account")
												.setI18nCode("Test")
												.build())
										.setEntityId(accountId.toString())
										.setEntityCode(BANK_ACCOUNT_CODE)
										.build()
						))).build());
	}
}
