package com.abacogroup.ddm.payment.resource;

import static com.abacogroup.ddm.common.WebCliHelper.TENANT;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.verify;

import com.abacogroup.anomalyregistry.api.v1.AnomalySearchResponse;
import com.abacogroup.anomalyregistry.api.v1.AnomalySearchResponse.AnomalySearchResponseBuilder;
import com.abacogroup.anomalyregistry.api.v1.AnomalyTypeResponse;
import com.abacogroup.ddm.api.AnomalyLevelEnum;
import com.abacogroup.ddm.api.DdmAnomaliesRes;
import com.abacogroup.ddm.common.WebCliHelper;
import com.abacogroup.ddm.common.resources.ReqContext;
import com.abacogroup.ddm.payment.core.BankAccountAnomalyService;
import com.abacogroup.ddm.payment.core.impl.AnomalyHelper;
import com.abacogroup.ddm.payment.core.impl.BankAccountAnomalyServiceImpl;
import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;
import io.dropwizard.testing.junit5.ResourceExtension;
import jakarta.ws.rs.core.GenericType;
import jakarta.ws.rs.core.UriBuilder;
import java.util.List;
import java.util.Map;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;

@ExtendWith(DropwizardExtensionsSupport.class)
class BankAccountAnomalyResourceTest {

	private final BankAccountAnomalyService bankAccountAnomalyService = Mockito.mock(BankAccountAnomalyServiceImpl.class);
	private final ResourceExtension EXT = WebCliHelper.createEXT(new BankAccountAnomalyResource(bankAccountAnomalyService));

	// ----- getAnomalies -----
	@Test
	void test_getAnomalies_ok() {
		Long partyId = 555L;
		Long accountId = 123L;

		UriBuilder uriBuilder = UriBuilder.fromResource(BankAccountAnomalyResource.class).path(BankAccountAnomalyResource.class, "getAnomalies");
		String uri = uriBuilder.build(TENANT, partyId, accountId).toString();
		System.out.println(uri);

		var mockRes = DdmAnomaliesRes.builder()
				.setAnomaliesGrouped(Map.of(
						AnomalyLevelEnum.WARN, List.of(
								givenAnomaly(partyId, null, AnomalyHelper.ANM_GROUP_CODE_PAYMENT_ACCOUNT, AnomalyHelper.ANM_TYPE_915).build(),
								givenAnomaly(partyId, null, AnomalyHelper.ANM_GROUP_CODE_PAYMENT_DD, AnomalyHelper.ANM_TYPE_ATTO).build()
						)
				)).build();

		given(bankAccountAnomalyService.getAnomalies(any(), anyLong(), anyLong())).willReturn(mockRes);

		DdmAnomaliesRes res = EXT.getJerseyTest().client()
				.target(UriBuilder.fromUri(uri))
				.request()
				.header("Authorization", WebCliHelper.JWT_MOCK_CREDENTIALS)
				.get(new GenericType<>() {
				});

		assertThat(res).isNotNull()
				.isEqualTo(mockRes);

		verify(bankAccountAnomalyService).getAnomalies(any(ReqContext.class), eq(partyId), eq(accountId));
	}




	private AnomalySearchResponseBuilder<?, ?> givenAnomaly(Long accountId, Long id, String groupCode, String code) {
		return AnomalySearchResponse.builder()
				.setId(id)
				.setEntityId(accountId.toString())
				.setEntityCode(AnomalyHelper.BANK_ACCOUNT_CODE)
				.setType(AnomalyTypeResponse.builder()
						.setId(id)
						.setCode(code)
						.setGroupCode(groupCode)
						.setI18nCode(code)
						.build());
	}

}
