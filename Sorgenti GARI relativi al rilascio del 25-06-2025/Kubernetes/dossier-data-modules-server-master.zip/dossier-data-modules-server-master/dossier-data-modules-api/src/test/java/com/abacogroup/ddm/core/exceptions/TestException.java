package com.abacogroup.ddm.core.exceptions;

import jakarta.ws.rs.WebApplicationException;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.core.Response.Status;

public class TestException extends WebApplicationException {

	private static final ErrorBody BODY = new ErrorBody();

	public TestException(String msg) {
		this(msg, Status.BAD_REQUEST);
	}

	public TestException(String msg, Status status) {
		super(msg, Response.status(status).entity(BODY).build());
	}

	public static class ErrorBody {

		private static final String ERR = "TEST_ERROR";

		public String getErrorCode() {
			return ERR;
		}
	}

}
