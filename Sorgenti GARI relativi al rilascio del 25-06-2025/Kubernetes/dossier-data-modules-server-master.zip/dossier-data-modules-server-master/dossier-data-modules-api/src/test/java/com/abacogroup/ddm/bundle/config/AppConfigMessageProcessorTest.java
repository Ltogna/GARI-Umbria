package com.abacogroup.ddm.bundle.config;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;

import com.abacogroup.bundles.initializer.impl.exceptions.BundleException;
import com.abacogroup.bundles.listener.configdata.ConfigDataMessage;
import com.abacogroup.ddm.common.JdbiTest;
import com.abacogroup.ddm.common.ReqContextUtils;
import com.abacogroup.ddm.db.dao.AppConfigDAO;
import com.abacogroup.ddm.db.ntt.AppConfigEntity;
import com.fasterxml.jackson.databind.exc.InvalidTypeIdException;
import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;
import jakarta.validation.ConstraintViolationException;
import java.util.List;
import org.assertj.core.groups.Tuple;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

@ExtendWith(DropwizardExtensionsSupport.class)
class AppConfigMessageProcessorTest extends JdbiTest {

	private ReqContextUtils ctx = new ReqContextUtils(this.getClass());

	private final AppConfigMessageProcessor processor = getService(AppConfigMessageProcessor.class);

	// ----- onMessage -----
	@Test
	void test_onMessage_ADD() {
		var message = new ConfigDataMessage()
				.setTenantId(ctx.getTenantId())
				.setConfigFiles(List.of(
						file2Path.apply("appConfig.json")
				));

		getJdbi().useHandle(handle -> {
			handle.begin();
			AppConfigDAO dao = handle.attach(AppConfigDAO.class);

			assertThat(dao.countAll(ctx.getTenantId())).isEqualTo(0L);

			processor.onMessage(message);

			assertThat(dao.findAll(ctx.getTenantId())).hasSize(3)
					.extracting(AppConfigEntity::getConfigurationKey, AppConfigEntity::getConfiguration)
					.containsExactly(
							Tuple.tuple("payment_default_account", "{\"allowClose\":true}"),
							Tuple.tuple("payment_regex_validation", "{\"regexes\":[\"[\\\\dA-Za-z]{1,999}\"]}"),
							Tuple.tuple("payment_validation", "{\"active\":false,\"validation_url\":\"http://validate.this.iban\"}")
					);

			handle.rollback();
		});
	}

	@Test
	void test_onMessage_AddUnknownKo() {
		var message = new ConfigDataMessage()
				.setTenantId(ctx.getTenantId())
				.setConfigFiles(List.of(
						file2Path.apply("appConfig_unknown.json")
				));

		getJdbi().useHandle(handle -> {
			handle.begin();
			AppConfigDAO dao = handle.attach(AppConfigDAO.class);

			assertThat(dao.countAll(ctx.getTenantId())).isEqualTo(0L);

			BundleException bundleException = assertThrows(BundleException.class, () -> processor.onMessage(message));

			//bundleException.printStackTrace();
			assertThat(bundleException)
					.hasCauseInstanceOf(InvalidTypeIdException.class);

			handle.rollback();
		});
	}

	@Test
	void test_onMessage_AddNotValidKo() {
		var message = new ConfigDataMessage()
				.setTenantId(ctx.getTenantId())
				.setConfigFiles(List.of(
						file2Path.apply("appConfig_not_valid.json")
				));

		getJdbi().useHandle(handle -> {
			handle.begin();
			AppConfigDAO dao = handle.attach(AppConfigDAO.class);

			assertThat(dao.countAll(ctx.getTenantId())).isEqualTo(0L);

			BundleException bundleException = assertThrows(BundleException.class, () -> processor.onMessage(message));

			//bundleException.printStackTrace();
			assertThat(bundleException)
					.hasCauseInstanceOf(ConstraintViolationException.class);

			handle.rollback();
		});
	}
}
