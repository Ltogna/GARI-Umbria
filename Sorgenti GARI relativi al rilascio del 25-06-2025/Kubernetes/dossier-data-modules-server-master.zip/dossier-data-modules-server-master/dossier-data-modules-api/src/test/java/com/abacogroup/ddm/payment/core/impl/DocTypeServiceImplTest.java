package com.abacogroup.ddm.payment.core.impl;

import static com.abacogroup.ddm.DossierDataModulesApplication.PAYMENT_MODULE;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.mock;

import java.util.List;
import java.util.Optional;

import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

import com.abacogroup.ddm.api.DdmDocumentDefinition;
import com.abacogroup.ddm.api.DocTypeRelationRes;
import com.abacogroup.ddm.common.JdbiTest;
import com.abacogroup.ddm.common.ReqContextUtils;
import com.abacogroup.ddm.core.DocTypeService;
import com.abacogroup.ddm.core.impl.DocTypeServiceImpl;
import com.abacogroup.dynamicdocuments.bean.DocumentDefinition;
import com.abacogroup.dynamicdocuments.bean.SummaryFieldDefinition;
import com.abacogroup.dynamicdocuments.bean.documentdefinition.FieldSet;
import com.abacogroup.dynamicdocuments.bean.documentdefinition.Metadata;
import com.abacogroup.dynamicdocuments.bean.documentdefinition.fieldset.Field;
import com.abacogroup.dynamicdocuments.bean.documentdefinition.fieldset.field.FieldType;
import com.abacogroup.dynamicdocuments.services.DocumentTypeService;

import io.dropwizard.auth.AuthenticationException;
import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;

@ExtendWith(DropwizardExtensionsSupport.class)
class DocTypeServiceImplTest extends JdbiTest {

	private final DocTypeService service = getService(DocTypeServiceImpl.class);

	private DocumentTypeService documentTypeService = mock(DocumentTypeService.class);

	private ReqContextUtils ctx = new ReqContextUtils(this.getClass());

	@BeforeEach
	void setUp() throws AuthenticationException {

		this.injectMock(service, documentTypeService);
	}

	// ----- getDocTypeRelations -----
	@Test
	void test_getDocTypeRelations_noAccountIdOk() {


		setUnusedBindingAllowed(true);
		getJdbi().useHandle(handle -> {
			handle.begin();

			execSqlFiles(this.getClass(), List.of(
					"add_bank_accounts",
					"add_doc_type_rel",
					"add_bank_account_docs"
			), ctx.getTestScriptParams());

			given(documentTypeService.getDocumentDefinition(anyString(), anyString()))
					.willReturn(Optional.of(new DocumentDefinition() {{
						setMetadata(new Metadata() {{
							setMaxOccurs(1);
						}});
					}})).willReturn(Optional.of(new DocumentDefinition() {{
						setMetadata(new Metadata() {{
							setMaxOccurs(2);
						}});
					}})).willReturn(Optional.of(new DocumentDefinition() {{
						setMetadata(new Metadata() {{
							setMaxOccurs(3);
						}});
					}}));

			List<SummaryFieldDefinition> summaryFieldDefinitions = List.of(
					SummaryFieldDefinition.builder().fieldType(FieldType.STRING).code("foo").build()
			);
			given(documentTypeService.getSummaryFields(any(), anyString()))
					.willReturn(summaryFieldDefinitions);

			List<DocTypeRelationRes> docTypeRelations = service.getPaymentDocTypeRelationsByAccountId(ctx.getReqContext(), null);

			Assertions.assertThat(docTypeRelations).hasSize(3)
					.containsExactlyInAnyOrder(
							DocTypeRelationRes.builder().setDefinitionCode("DD_1").setDefinitionCodeI18n("Di Di One")
									.setNamespace(PAYMENT_MODULE).setRequired(true).setDocPresent(null)
									.setMultiple(false).setSummaryFieldDefinitions(summaryFieldDefinitions).build(),
							DocTypeRelationRes.builder().setDefinitionCode("DD_2").setDefinitionCodeI18n("Di Di Two")
									.setNamespace(PAYMENT_MODULE).setRequired(false).setDocPresent(null)
									.setMultiple(true).setSummaryFieldDefinitions(summaryFieldDefinitions).build(),
							DocTypeRelationRes.builder().setDefinitionCode("DD_3").setDefinitionCodeI18n("DD_3")
									.setNamespace(PAYMENT_MODULE).setRequired(false).setDocPresent(null)
									.setMultiple(true).setSummaryFieldDefinitions(summaryFieldDefinitions).build()
					);

			handle.rollback();
		});

	}

	@Test
	void test_getDocTypeRelations_withAccountIdOk() {


		setUnusedBindingAllowed(true);
		getJdbi().useHandle(handle -> {
			handle.begin();

			execSqlFiles(this.getClass(), List.of(
					"add_bank_accounts",
					"add_doc_type_rel",
					"add_bank_account_docs"
			), ctx.getTestScriptParams());

			given(documentTypeService.getDocumentDefinition(anyString(), anyString()))
					.willReturn(Optional.of(new DocumentDefinition() {{
						setMetadata(new Metadata() {{
							setMaxOccurs(1);
						}});
					}})).willReturn(Optional.of(new DocumentDefinition() {{
						setMetadata(new Metadata() {{
							setMaxOccurs(2);
						}});
					}})).willReturn(Optional.of(new DocumentDefinition() {{
						setMetadata(new Metadata() {{
							setMaxOccurs(3);
						}});
					}}));

			List<SummaryFieldDefinition> summaryFieldDefinitions = List.of(
					SummaryFieldDefinition.builder().fieldType(FieldType.STRING).code("foo").build()
			);
			given(documentTypeService.getSummaryFields(any(), anyString()))
					.willReturn(summaryFieldDefinitions);

			long accountId = -1L;
			List<DocTypeRelationRes> docTypeRelations = service.getPaymentDocTypeRelationsByAccountId(ctx.getReqContext(), accountId);

			Assertions.assertThat(docTypeRelations).hasSize(3)
					.containsExactlyInAnyOrder(
							DocTypeRelationRes.builder().setDefinitionCode("DD_1").setDefinitionCodeI18n("Di Di One")
									.setNamespace(PAYMENT_MODULE).setRequired(true).setDocPresent(true)
									.setMultiple(false).setSummaryFieldDefinitions(summaryFieldDefinitions).build(),
							DocTypeRelationRes.builder().setDefinitionCode("DD_2").setDefinitionCodeI18n("Di Di Two")
									.setNamespace(PAYMENT_MODULE).setRequired(false).setDocPresent(true)
									.setMultiple(true).setSummaryFieldDefinitions(summaryFieldDefinitions).build(),
							DocTypeRelationRes.builder().setDefinitionCode("DD_3").setDefinitionCodeI18n("DD_3")
									.setNamespace(PAYMENT_MODULE).setRequired(false).setDocPresent(false)
									.setMultiple(true).setSummaryFieldDefinitions(summaryFieldDefinitions).build()
					);

			handle.rollback();
		});

	}

	// ----- getDefinition -----
	@Test
	void test_getDefinition_ok() {

		DocumentDefinition documentDefinition = new DocumentDefinition() {{
			setMetadata(new Metadata() {{
				setMaxOccurs(1);
			}});
			setCode("DD_X");
			setVersion("1.2.3");
			setFieldSets(List.of(
					new FieldSet() {{
						this.setCode("FS_1");
						this.setFields(List.of(
								new Field() {{
									this.setCode("F_1");
									this.setType(FieldType.STRING);
								}},
								new Field() {{
									this.setCode("F_2");
									this.setType(FieldType.LONG);
								}}
						));
					}}
			));
		}};
		given(documentTypeService.getDocumentDefinition(anyString(), anyString()))
				.willReturn(Optional.of(documentDefinition));

		DdmDocumentDefinition ddX = service.getDefinition(ctx.getReqContext(), "DD_X");

		assertThat(ddX).isNotNull()
				.hasFieldOrPropertyWithValue("bucketName", EXT.getConfiguration().getDynamicDocumentsBucket())
				.usingRecursiveComparison()
				.ignoringFields("bucketName")
				.isEqualTo(documentDefinition);


	}
}
