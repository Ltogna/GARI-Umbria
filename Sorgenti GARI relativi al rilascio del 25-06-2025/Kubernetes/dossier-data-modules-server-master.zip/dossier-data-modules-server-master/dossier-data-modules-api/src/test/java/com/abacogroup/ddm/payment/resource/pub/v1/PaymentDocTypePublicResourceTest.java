package com.abacogroup.ddm.payment.resource.pub.v1;

import static com.abacogroup.ddm.common.WebCliHelper.TENANT;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.verify;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mockito;

import com.abacogroup.ddm.api.DdmDocumentDefinition;
import com.abacogroup.ddm.api.DocTypeRelationRes;
import com.abacogroup.ddm.api.DocTypeRelationRes.DocTypeRelationResBuilder;
import com.abacogroup.ddm.api.v1.DdmDocumentDefinitionV1;
import com.abacogroup.ddm.api.v1.DocTypeRelationResponseV1;
import com.abacogroup.ddm.common.WebCliHelper;
import com.abacogroup.ddm.common.resources.ReqContext;
import com.abacogroup.ddm.core.DocTypeService;
import com.abacogroup.ddm.core.impl.DocTypeServiceImpl;

import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;
import io.dropwizard.testing.junit5.ResourceExtension;
import jakarta.ws.rs.core.GenericType;
import jakarta.ws.rs.core.UriBuilder;

@ExtendWith(DropwizardExtensionsSupport.class)
class PaymentDocTypePublicResourceTest {

	private final DocTypeService docTypeRelationService = Mockito.mock(DocTypeServiceImpl.class);
	private final PaymentDocTypePublicResource resource = new PaymentDocTypePublicResource(docTypeRelationService);
	private final ResourceExtension EXT = WebCliHelper.createEXT(resource);

	@Test
	void should_search_docTypes() {
		Long accountId = 100L;

		UriBuilder uriBuilder = UriBuilder.fromResource(resource.getClass()).path(resource.getClass(), "search");
		String uri = uriBuilder.build(TENANT).toString();

		List<DocTypeRelationRes> mockRes = (List.of(
				docTypeRelationRes("DEF_1").build(),
				docTypeRelationRes("DEF_2").build(),
				docTypeRelationRes("DEF_3").build()));

		given(docTypeRelationService.getPaymentDocTypeRelationsByAccountId(any(), eq(accountId))).willReturn(mockRes);

		List<DocTypeRelationResponseV1> res = EXT.getJerseyTest().client()
				.target(UriBuilder.fromUri(uri))
				.queryParam("accountId", accountId)
				.request()
				.header("Authorization", WebCliHelper.JWT_MOCK_CREDENTIALS)
				.get(new GenericType<>() {
				});

		assertThat(res).isNotNull()
				.usingRecursiveComparison()
				.isEqualTo(mockRes);

		ArgumentCaptor<ReqContext> reqCtxCaptor = ArgumentCaptor.forClass(ReqContext.class);
		verify(docTypeRelationService).getPaymentDocTypeRelationsByAccountId(reqCtxCaptor.capture(), eq(accountId));

	}

	@Test
	void test_getDefinition() {
		String definitionCode = "DEF_1";

		UriBuilder uriBuilder = UriBuilder.fromResource(resource.getClass()).path(resource.getClass(), "getDefinition");

		String uri = uriBuilder.build(TENANT, definitionCode).toString();

		DdmDocumentDefinition mockRes = new DdmDocumentDefinition();
		mockRes.setBucketName("bank_account_docs");
		mockRes.setCode(definitionCode);

		given(docTypeRelationService.getDefinition(any(), eq(definitionCode))).willReturn(mockRes);

		DdmDocumentDefinitionV1 res = EXT.getJerseyTest().client()
				.target(UriBuilder.fromUri(uri))
				.request()
				.header("Authorization", WebCliHelper.JWT_MOCK_CREDENTIALS)
				.get(new GenericType<>() {
				});

		assertThat(res).isNotNull()
				.usingRecursiveComparison()
				.isEqualTo(mockRes);

		ArgumentCaptor<ReqContext> reqCtxCaptor = ArgumentCaptor.forClass(ReqContext.class);
		verify(docTypeRelationService).getDefinition(reqCtxCaptor.capture(), eq(definitionCode));
	}

	private DocTypeRelationResBuilder<?, ?> docTypeRelationRes(String defCode) {
		return DocTypeRelationRes.builder()
				.setDefinitionCode(defCode)
				.setDocPresent(false)
				.setRequired(true);
	}

}
