package com.abacogroup.ddm.core.cli;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.reset;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import com.abacogroup.anomalyregistry.api.v1.AnomalySearchResponse;
import com.abacogroup.anomalyregistry.api.v1.req.AnomalyRequest;
import com.abacogroup.anomalyregistry.api.v1.req.AnomalySearchRequest;
import com.abacogroup.anomalyregistry.core.cli.v1.AnomalyClient;
import com.abacogroup.ddm.common.WebCliHelper;
import com.abacogroup.ddm.core.exceptions.TestException;
import com.abacogroup.dropwizard.auth.sso2.User;
import io.dropwizard.auth.Auth;
import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;
import io.dropwizard.testing.junit5.ResourceExtension;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import jakarta.ws.rs.BadRequestException;
import jakarta.ws.rs.BeanParam;
import jakarta.ws.rs.DefaultValue;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.HeaderParam;
import jakarta.ws.rs.InternalServerErrorException;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.client.WebTarget;
import jakarta.ws.rs.core.Response.Status;
import java.util.ArrayList;
import java.util.List;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

@ExtendWith({ DropwizardExtensionsSupport.class })
class AnomalyDdmClientImplTest {

	public static final String URI = "/{tenant}/public/v1/anomalies";
	private static final User USER = new User(WebCliHelper.BASIC_USERNAME, WebCliHelper.FAKE_JWT, WebCliHelper.TENANT, WebCliHelper.BASIC_USERNAME);
	private static final PingResource mockResource = spy(new PingResource());
	private static final ResourceExtension EXT = WebCliHelper.createEXT(mockResource);
	private final WebTarget anmBaseTarget = EXT.target("");
	private AnomalyClient anomalyClient;

	@BeforeEach
	void setUp() {
		reset(mockResource);
		anomalyClient = new AnomalyDdmClientImpl(anmBaseTarget);
	}

	// ----- search -----
	@Test
	void test_search_ok() {
		AnomalySearchRequest searchRequest = new AnomalySearchRequest()
				.setGroupCode(List.of("GR1", "GR2"))
				.setTypeCode(List.of("ATx", "ATy"))
				.setTypeId(List.of(123L, 456L, 789L))
				.setEntityId(List.of("11", "22"));

		List<AnomalySearchResponse> results = anomalyClient.search("it", USER, "PARTY", searchRequest);

		assertThat(results).isNotNull().hasSize(3)
				.usingRecursiveFieldByFieldElementComparatorIgnoringFields("id")
				.containsExactly(
						AnomalySearchResponse.builder().setId(123L).build(),
						AnomalySearchResponse.builder().setId(456L).build(),
						AnomalySearchResponse.builder().setId(789L).build()
				);
		// TODO test jwt
		verify(mockResource).search(eq("it"), any(User.class), eq(USER.getTenant()), eq("PARTY"), //eq(searchRequest));
				eq(new TestAnomalySearchRequest()
						.setGroupCode(List.of("GR1", "GR2"))
						.setTypeCode(List.of("ATx", "ATy"))
						.setTypeId(List.of(123L, 456L, 789L))
						.setEntityId(List.of("11", "22"))
				));
	}

	@Test
	void test_search_400() {
		AnomalySearchRequest searchRequest = new AnomalySearchRequest();

		assertThrows(BadRequestException.class, () -> anomalyClient.search("it", USER, "GIVE_ME_400", searchRequest));

		// TODO test jwt
		verify(mockResource).search(eq("it"), any(User.class), eq(USER.getTenant()), eq("GIVE_ME_400"),
				eq(new TestAnomalySearchRequest()
						.setEntityId(new ArrayList<>())
						.setTypeCode(new ArrayList<>())
						.setGroupCode(new ArrayList<>())
						.setTypeId(new ArrayList<>())
				));
	}

	@Test
	void test_search_500() {
		AnomalySearchRequest searchRequest = new AnomalySearchRequest();

		assertThrows(InternalServerErrorException.class, () -> anomalyClient.search("it", USER, "GIVE_ME_500", searchRequest));

		// TODO test jwt
		verify(mockResource, times(2)).search(eq("it"), any(User.class), eq(USER.getTenant()), eq("GIVE_ME_500"),
				eq(new TestAnomalySearchRequest()
						.setEntityId(new ArrayList<>())
						.setTypeCode(new ArrayList<>())
						.setGroupCode(new ArrayList<>())
						.setTypeId(new ArrayList<>())
				));
	}

	// ----- add -----
	@Test
	void test_add_ok() {
		var request = List.of(
				AnomalyRequest.builder().setTypeGroupCode("GR1").setTypeCode("AT1").setEntityCode("PARTY").setEntityId("11").build(),
				AnomalyRequest.builder().setTypeGroupCode("GR2").setTypeCode("AT2").setEntityCode("PARTY").setEntityId("22").build()
		);

		anomalyClient.add("it", USER, request);

		// TODO test jwt
		verify(mockResource).add(eq("it"), any(User.class), eq(USER.getTenant()), eq(request));
	}

	@Test
	void test_add_400() {
		var request = List.of(
				AnomalyRequest.builder().setTypeGroupCode("GR1").setTypeCode("AT1").setEntityCode("GIVE_ME_400").setEntityId("11").build(),
				AnomalyRequest.builder().setTypeGroupCode("GR2").setTypeCode("AT2").setEntityCode("PARTY").setEntityId("22").build()
		);

		assertThrows(BadRequestException.class, () -> anomalyClient.add("it", USER, request));

		// TODO test jwt
		verify(mockResource).add(eq("it"), any(User.class), eq(USER.getTenant()), eq(request));
	}

	// ----- expire -----
	@Test
	void test_expire_ok() {
		var request = List.of(
				AnomalyRequest.builder().setTypeGroupCode("GR1").setTypeCode("AT1").setEntityCode("GIVE_ME_400").setEntityId("11").build(),
				AnomalyRequest.builder().setTypeGroupCode("GR2").setTypeCode("AT2").setEntityCode("PARTY").setEntityId("22").build()
		);

		anomalyClient.expire("it", USER, request);

		// TODO test jwt
		verify(mockResource).expire(eq("it"), any(User.class), eq(USER.getTenant()), eq(request));
	}

	@Path(URI)
	public static class PingResource {

		@GET
		@Path("/{entityCode}")
		public List<AnomalySearchResponse> search(
				@HeaderParam("accept-language") @DefaultValue("en") String lang,
				@Auth User user,
				@PathParam("tenant") String tenantId,
				@PathParam("entityCode") String entityCode,
				@BeanParam TestAnomalySearchRequest searchRequest
//				@BeanParam AnomalySearchRequest searchRequest
		) {
			if (entityCode.equals("GIVE_ME_400")) {
				throw new TestException("as requested", Status.BAD_REQUEST);
			} else if (entityCode.equals("GIVE_ME_500")) {
				throw new TestException("as requested", Status.INTERNAL_SERVER_ERROR);
			}
			return List.of(
					AnomalySearchResponse.builder().setId(123L).build(),
					AnomalySearchResponse.builder().setId(456L).build(),
					AnomalySearchResponse.builder().setId(789L).build()
			);
		}

		@POST
		public void add(
				@HeaderParam("accept-language") @DefaultValue("en") String lang,
				@Auth User user,
				@PathParam("tenant") String tenantId,
				@NotNull @Valid List<AnomalyRequest> req
		) {
			if (req.get(0).getEntityCode().equals("GIVE_ME_400")) {
				throw new TestException("as requested", Status.BAD_REQUEST);
			}
		}

		@POST
		@Path("/expired")
		public void expire(
				@HeaderParam("accept-language") @DefaultValue("en") String lang,
				@Auth User user,
				@PathParam("tenant") String tenantId,
				@NotNull @Valid List<AnomalyRequest> req
		) {
			// ...
		}

	}

	@NoArgsConstructor
	@Accessors(chain = true)
	public static class TestAnomalySearchRequest extends AnomalySearchRequest {

		@Override
		@QueryParam("groupCode")
		public List<String> getGroupCode() {
			return super.getGroupCode();
		}

		@Override
		@QueryParam("groupCode")
		public TestAnomalySearchRequest setGroupCode(List<String> groupCode) {
			super.setGroupCode(groupCode);
			return this;
		}

		@Override
		@QueryParam("typeCode")
		public List<String> getTypeCode() {
			return super.getTypeCode();
		}

		@Override
		@QueryParam("typeCode")
		public TestAnomalySearchRequest setTypeCode(List<String> typeCode) {
			super.setTypeCode(typeCode);
			return this;
		}

		@Override
		@QueryParam("entityId")
		public List<String> getEntityId() {
			return super.getEntityId();
		}

		@Override
		@QueryParam("entityId")
		public TestAnomalySearchRequest setEntityId(List<String> entityId) {
			super.setEntityId(entityId);
			return this;
		}

		@Override
		@QueryParam("typeId")
		public List<Long> getTypeId() {
			return super.getTypeId();
		}

		@Override
		@QueryParam("typeId")
		public TestAnomalySearchRequest setTypeId(List<Long> typeId) {
			super.setTypeId(typeId);
			return this;
		}

	}

}
