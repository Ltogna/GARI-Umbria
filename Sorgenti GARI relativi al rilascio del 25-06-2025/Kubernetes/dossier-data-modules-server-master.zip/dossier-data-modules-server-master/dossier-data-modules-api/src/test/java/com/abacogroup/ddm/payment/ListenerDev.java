package com.abacogroup.ddm.payment;

import static com.abacogroup.ddm.payment.core.dto.PaymentEventType.TOPIC_PREFIX;
import static com.abacogroup.ddm.payment.core.impl.PaymentEventRabbitPublisher.EXCHANGE;

import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;
import com.rabbitmq.client.DeliverCallback;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.TimeoutException;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Disabled;

@Slf4j
@Disabled
public class ListenerDev {

	// ----- startLister -----
	public static void main(String[] args) throws IOException, TimeoutException {
		ListenerDev listenerDevTest = new ListenerDev();
		listenerDevTest.listenEvents(listenerDevTest.createConnection(listenerDevTest.getPort(args)));
	}

	private int getPort(String[] args) {
		if (args.length > 0) {
			return Integer.parseInt(args[0]);
		} else {
			return 5678;
		}
	}

	private Connection createConnection(int port) throws IOException, TimeoutException {
		ConnectionFactory factory = new ConnectionFactory();

		// factory.setHost(...);
		// factory.setUsername(...);
		// factory.setPassword(...);
		// factory.setVirtualHost(...);
		factory.setPort(port);

		factory.setAutomaticRecoveryEnabled(true);

		Connection connection = factory.newConnection();

		return connection;
	}

	private void listenEvents(Connection rabbitmqConnection) throws IOException {
		Channel channel = rabbitmqConnection.createChannel();

		channel.exchangeDeclare(EXCHANGE, "topic", true);
		String queueName = channel.queueDeclare().getQueue();

		channel.queueBind(queueName, EXCHANGE, TOPIC_PREFIX + ".#");

		DeliverCallback deliverCallback = (consumerTag, delivery) -> {
			String message = new String(delivery.getBody(), StandardCharsets.UTF_8);
			String routingKey = delivery.getEnvelope().getRoutingKey();
			log.info(" [\uD83D\uDC07 \uD83D\uDC4C] Received message in '{}'", routingKey);
//			JSONObject json = new JSONObject(message);
//			System.out.println(json.toString(2));
			System.out.println(message);
		};
		channel.basicConsume(queueName, true, deliverCallback, consumerTag -> {
		});
	}

}
