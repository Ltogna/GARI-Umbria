package com.abacogroup.ddm.payment.core.impl;

import static com.abacogroup.ddm.payment.core.impl.AnomalyHelper.ANM_TYPE_915;
import static com.abacogroup.ddm.payment.core.impl.AnomalyHelper.ANM_TYPE_ATTO;
import static com.abacogroup.ddm.payment.core.impl.AnomalyHelper.ANM_TYPE_CC_PRED;
import static com.abacogroup.ddm.payment.core.impl.AnomalyHelper.ANM_TYPE_NO_CC;
import static com.abacogroup.ddm.payment.core.impl.AnomalyHelper.BANK_ACCOUNT_CODE;
import static com.abacogroup.ddm.payment.core.impl.AnomalyHelper.PARTY_ENTITY_CODE;
import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.tuple;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.verify;

import java.time.Clock;
import java.time.OffsetDateTime;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;

import com.abacogroup.anomalyregistry.api.v1.req.AnomalyRequest;
import com.abacogroup.anomalyregistry.core.cli.v1.AnomalyClient;
import com.abacogroup.ddm.common.JdbiTest;
import com.abacogroup.ddm.common.ReqContextUtils;
import com.abacogroup.ddm.core.PartyService;
import com.abacogroup.ddm.payment.core.BulkAnomalyRecalculationService;
import com.abacogroup.dynamicdocuments.bean.Document;
import com.abacogroup.dynamicdocuments.services.DocumentService;

import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;

@ExtendWith(DropwizardExtensionsSupport.class)
class BulkAnomalyRecalculationServiceImplTest extends JdbiTest {

	private final BulkAnomalyRecalculationService service = getService(BulkAnomalyRecalculationServiceImpl.class);
	private final ReqContextUtils ctx = new ReqContextUtils(this.getClass());

	private final PartyService partyservice = mock(PartyService.class);
	private final DocumentService documentService = mock(DocumentService.class);
	private final AnomalyClient anomalyClient = mock(AnomalyClient.class);

	private final Clock appClock = spy(Clock.systemDefaultZone());

	@BeforeEach
	void setUp() {
		this.injectMock(service, partyservice);
		this.injectMock(service, documentService);
		this.injectMock(service, anomalyClient);
		this.injectMock(service, appClock);
	}

	// ----- recalculate -----
	@Test
	void test_recalculate_ok() {

		setUnusedBindingAllowed(true);
		getJdbi().useHandle(handle -> {
			handle.begin();

			execSqlFiles(this.getClass(), List.of(
					"add_bank_accounts",
					"add_doc_type_rel",
					"add_bank_account_docs"
			), ctx.getTestScriptParams());

			OffsetDateTime now = OffsetDateTime.now(appClock);
			given(documentService.getDocumentFromId(90101L)).willReturn(givenDoc(now.plusYears(9)));
			given(documentService.getDocumentFromId(90202L)).willReturn(givenDoc(now.plusYears(8)));
			given(documentService.getDocumentFromId(90601L)).willReturn(givenDoc(now.plusYears(7)));
			given(documentService.getDocumentFromId(90602L)).willReturn(givenDoc(now.minusDays(15)));

			Long partyId = 555L;

			//test
			service.recalculate(ctx.getReqContext(), partyId);

			ArgumentCaptor<List<AnomalyRequest>> anomalyReqCaptor = ArgumentCaptor.forClass(List.class);
			verify(anomalyClient).add(eq(ctx.getReqContext().getLang()), eq(ctx.getReqContext().getUser()),
					anomalyReqCaptor.capture());
			verify(anomalyClient).expire(eq(ctx.getReqContext().getLang()), eq(ctx.getReqContext().getUser()),
					anomalyReqCaptor.capture());

			List<AnomalyRequest> added = anomalyReqCaptor.getAllValues().get(0);
			assertThat(added).hasSize(7)
					.extracting(AnomalyRequest::getEntityCode, AnomalyRequest::getEntityId, AnomalyRequest::getTypeCode)
					.containsExactlyInAnyOrder(
							tuple(PARTY_ENTITY_CODE, "555", ANM_TYPE_CC_PRED),
							tuple(BANK_ACCOUNT_CODE, "-2", ANM_TYPE_915),
							tuple(BANK_ACCOUNT_CODE, "-3", ANM_TYPE_915),
							tuple(BANK_ACCOUNT_CODE, "-6", ANM_TYPE_ATTO),
							tuple(BANK_ACCOUNT_CODE, "-3", ANM_TYPE_ATTO),
							tuple(BANK_ACCOUNT_CODE, "-4", ANM_TYPE_ATTO),
							tuple(BANK_ACCOUNT_CODE, "-2", ANM_TYPE_ATTO)
					);

			List<AnomalyRequest> expired = anomalyReqCaptor.getAllValues().get(1);
			assertThat(expired).hasSize(5)
					.extracting(AnomalyRequest::getEntityCode, AnomalyRequest::getEntityId, AnomalyRequest::getTypeCode)
					.containsExactlyInAnyOrder(
							tuple(PARTY_ENTITY_CODE, "555", ANM_TYPE_NO_CC),
							tuple(BANK_ACCOUNT_CODE, "-1", ANM_TYPE_915),
							tuple(BANK_ACCOUNT_CODE, "-4", ANM_TYPE_915),
							tuple(BANK_ACCOUNT_CODE, "-6", ANM_TYPE_915),
							tuple(BANK_ACCOUNT_CODE, "-1", ANM_TYPE_ATTO)
					);

			handle.rollback();
		});
	}

	private Document givenDoc(OffsetDateTime validTo) {
		Document expired = new Document();
		expired.setValidTo(validTo);
		return expired;
	}
}
