package com.abacogroup.ddm;

import java.io.IOException;
import java.lang.reflect.Field;
import java.time.Clock;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.TimeoutException;

import org.apache.commons.lang3.reflect.FieldUtils;
import org.jdbi.v3.core.Jdbi;
import org.jdbi.v3.core.statement.Slf4JSqlLogger;
import org.mockito.Mockito;

import com.abacogroup.bundles.initializer.InitService;
import com.abacogroup.bundles.initializer.impl.BundleInitServiceProducer;
import com.abacogroup.bundles.listener.RabbitListener;
import com.abacogroup.bundles.listener.configdata.ConfigDataLogProducer;
import com.abacogroup.ddm.common.ApplicationTestSupport;
import com.abacogroup.ddm.common.TestApplication;
import com.abacogroup.ddm.common.resources.ReqContext;
import com.abacogroup.ddm.heirs_special_case.core.HeirEventProducer;
import com.abacogroup.ddm.heirs_special_case.core.dto.HeirEventType;
import com.abacogroup.ddm.payment.core.PaymentEventProducer;
import com.abacogroup.ddm.payment.core.dto.PaymentEventType;
import com.abacogroup.ddm.payment.db.dao.BankAccountDAO;
import com.abacogroup.dropwizard.auth.multitenant.MultitenantFilter;
import com.abacogroup.dropwizard.auth.sso2.Sso2Client;
import com.abacogroup.dropwizard.auth.sso2.User;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.collect.ImmutableMap;
import com.google.common.collect.ImmutableSet;
import com.rabbitmq.client.Connection;

import io.dropwizard.auth.AuthFilter;
import io.dropwizard.auth.PolymorphicAuthDynamicFeature;
import io.dropwizard.auth.PolymorphicAuthValueFactoryProvider;
import io.dropwizard.auth.basic.BasicCredentialAuthFilter;
import io.dropwizard.auth.chained.ChainedAuthFilter;
import io.dropwizard.core.setup.Environment;
import io.dropwizard.jersey.setup.JerseyEnvironment;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class DossierDataModulesTestApplication extends DossierDataModulesApplication implements TestApplication {

	public static Jdbi jdbi;

	private final ApplicationTestSupport applicationTestSupport = new ApplicationTestSupport(this.getName());

	public static ObjectMapper getObjectMapper() {
		ObjectMapper mapper = new ObjectMapper();
		mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		// brutto, ma consente di accentrare la configurazione senza snaturare application
		new DossierDataModulesApplication().configureObjectMapper(mapper);
		return mapper;
	}

	@Override
	public ApplicationTestSupport getAppTestSupport() {
		return applicationTestSupport;
	}

	@Override
	public Jdbi getJdbi() {
		return jdbi;
	}

	@Override
	protected Jdbi jdbi(DossierDataModulesConfiguration configuration, Environment environment) {
		Jdbi jdbi = super.jdbi(configuration, environment);
		jdbi.setSqlLogger(new Slf4JSqlLogger());
		DossierDataModulesTestApplication.jdbi = jdbi;

		applicationTestSupport.execMigrations(environment, configuration.getDatabase());
		return jdbi;
	}

	@Override
	protected <T> T register(T service) {
		if (isBetterToMock(service)) {
			service = (T) Mockito.mock(service.getClass());
		}

		applicationTestSupport.register(service);
		return super.register(service);
	}

	private <T> boolean isBetterToMock(T service) {
		return !applicationTestSupport.isInitRabbit() &&
				(service instanceof ConfigDataLogProducer
				|| service instanceof BundleInitServiceProducer);
	}

	@Override
	protected PaymentEventProducer buildPaymentEventProducer(Environment environment, Jdbi jdbi, ObjectMapper objectMapper, Connection rabbitmqConnection,
			BankAccountDAO bankAccountDAO, Clock appClock) throws IOException {
		return new PaymentEventProducer() {
			@Override
			public void pushBankAccountEvent(ReqContext reqContext, Long partyId, Long accountId, PaymentEventType eventType) {
				pushBankAccountEvent(reqContext.getTenantId(), reqContext.getUsername(), reqContext.getLang(), partyId, accountId, eventType);
			}

			@Override
			public void pushBankAccountEvent(String tenant, String username, String lang, Long partyId, Long accountId, PaymentEventType eventType) {
				log.info("MOCK {} event for accountId: {}", eventType, accountId);
			}
		};
	}
	
	@Override
	protected HeirEventProducer buildHeirEventProducer(Environment environment, Jdbi jdbi, ObjectMapper objectMapper, Connection rabbitmqConnection,
			Clock appClock) throws IOException {
		return new HeirEventProducer() {
			@Override
			public void pushHeirEvent(ReqContext reqContext, Long partyId, String partyCuaa, HeirEventType eventType) {
				pushHeirEvent(reqContext.getTenantId(), reqContext.getUsername(), reqContext.getLang(), partyId, partyCuaa, eventType);
			}
			
			@Override
			public void pushHeirEvent(String tenant, String username, String lang, Long partyId, String partyCuaa, HeirEventType eventType) {
				log.info("MOCK {} event for accountId: {}", eventType, partyCuaa);
			}
		};
	}

	@Override
	protected ConfigDataLogProducer configDataLogProducerBean(ObjectMapper objectMapper, com.rabbitmq.client.Connection rabbitmqConnection) {
		if (!applicationTestSupport.isInitRabbit()) {
			return Mockito.mock(ConfigDataLogProducer.class);
		}
		return super.configDataLogProducerBean(objectMapper, rabbitmqConnection);
	}

	@Override
	protected void initOpenApi(JerseyEnvironment jersey) {
		log.info("OPEN-API DISABELD");
	}

	@Override
	protected void initAuth(Environment environment, Sso2Client sso2Cli) {
		List<AuthFilter<?, ? extends User>> filters = new ArrayList<>();
		filters.add(new BasicCredentialAuthFilter.Builder<User>()
				.setAuthenticator(credentials -> Optional.of(new User(credentials.getUsername(), "master")))
				.setAuthorizer((principal, role, requestContext) -> true)
				.setRealm("GUEST authenticator")
				.buildAuthFilter());

		ChainedAuthFilter usersFilter = new ChainedAuthFilter(filters);

		final PolymorphicAuthDynamicFeature<? extends User> feature = new PolymorphicAuthDynamicFeature<>(
				ImmutableMap.of(User.class, usersFilter));

		PolymorphicAuthValueFactoryProvider.Binder<? extends User> binder = new PolymorphicAuthValueFactoryProvider.Binder<>(
				ImmutableSet.of(User.class));

		environment.jersey().register(feature);
		environment.jersey().register(binder);
		// */
	}

	@Override
	protected void startRabbitConsumerAndProducers(InitService initService, RabbitListener rabbitListener) throws Exception {
		if (!applicationTestSupport.isInitRabbit()) {
			System.out.println("startup producers and consumers OFF");
		} else {
			super.startRabbitConsumerAndProducers(initService, rabbitListener);
		}
	}

	@Override
	protected void afterServicesUp() {
		if (!applicationTestSupport.isExecMigrations()) {
			return;
		}
		try {
			applicationTestSupport.installBundle(jdbi, String.format("%s.%s", this.getName(), "zip"));
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}

	protected static <T, M> void injectMockByField(T target, String filedName) {
		try {
			Class<T> targetClazz = (Class<T>) target.getClass();
			Field field = Arrays.stream(FieldUtils.getAllFields(targetClazz))
					.filter(f -> f.getName().equals(filedName))
					.findFirst()
					.orElseThrow();

			FieldUtils.writeField(target, field.getName(), Mockito.mock(field.getType()), true);
		} catch (IllegalAccessException ex) {
			throw new RuntimeException("errore in inject", ex);
		}
	}

	@Override
	protected com.rabbitmq.client.Connection createRabbitmqConnection(DossierDataModulesConfiguration configuration) throws IOException, TimeoutException {
		if (applicationTestSupport.isInitRabbit()) {
			return super.createRabbitmqConnection(configuration);
		} else {
			log.info("RABBIT CONNECTION DISABLED");
			return null;
		}
	}

	private void initMultiTenant(Environment environment) {
		environment.jersey().register(new MultitenantFilter("tenant"));
	}


}
