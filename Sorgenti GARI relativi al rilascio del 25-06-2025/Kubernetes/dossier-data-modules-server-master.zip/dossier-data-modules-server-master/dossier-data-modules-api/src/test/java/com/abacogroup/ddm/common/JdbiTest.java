package com.abacogroup.ddm.common;

import static org.junit.jupiter.api.Assertions.assertTrue;

import java.nio.file.Path;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.function.Function;

import org.jdbi.v3.core.Jdbi;
import org.junit.jupiter.api.Test;

import com.abacogroup.ddm.DossierDataModulesConfiguration;
import com.abacogroup.ddm.DossierDataModulesTestApplication;
import com.fasterxml.jackson.databind.ObjectMapper;

import io.dropwizard.client.JerseyClientBuilder;
import io.dropwizard.testing.ResourceHelpers;
import io.dropwizard.testing.junit5.DropwizardAppExtension;
import jakarta.ws.rs.client.Client;
import jakarta.ws.rs.client.WebTarget;

/**
 * Abstract class per integration test di Service e DAO layer
 * <p>
 * - applica le migrazioni in automatico (se configurato)
 * <p>
 * - espone jdbi e getDAO
 */
public class JdbiTest {

	protected static DropwizardAppExtension<DossierDataModulesConfiguration> EXT = new DropwizardAppExtension<>(
			DossierDataModulesTestApplication.class,
			ResourceHelpers.resourceFilePath(System.getProperty("test_config_file", "test_config.yml")));
	protected final IntegrationTestSupport testSupport = new IntegrationTestSupport(EXT);
	protected Function<String, Path> file2Path = filename -> Optional.of(Path.of(
			"src/test/resources",
			this.getClass().getName().replaceAll("\\.", "/"),
			filename)).orElseThrow();

	public static void execSqlFiles(Class clazz, List<String> scripts, Map<String, Object> args) {
		Jdbi jdbi = ((DossierDataModulesTestApplication) EXT.getApplication()).getJdbi();
		IntegrationTestSupport.execSqlFiles(jdbi, clazz, scripts, args);
	}

	public static DossierDataModulesConfiguration getConfiguration() {
		return EXT.getConfiguration();
	}

	// -------- per comodità ----
	public <T> T getService(Class<T> clazz) {
		return testSupport.getService(clazz);
	}

	public <T> T getDAO(Class<T> classDAO) {
		return testSupport.getDAO(classDAO);
	}

	public void setUnusedBindingAllowed(boolean allowed) {
		testSupport.setUnusedBindingAllowed(allowed);
	}

	public Jdbi getJdbi() {
		return testSupport.getJdbi();
	}

	public <T, M> void injectMock(T target, M mock) {
		IntegrationTestSupport.injectMock(target, mock);
	}

	protected WebTarget getGenericWebTarget(String url) {
		final Client client = new JerseyClientBuilder(EXT.getEnvironment())
				.using(EXT.getObjectMapper())
				.using(EXT.getConfiguration().getJerseyClient())
				.build("spy");
		WebTarget wt = client.target(url);
		return wt;
	}

	protected ObjectMapper getMapper() {
		return EXT.getObjectMapper();
	}
	
	@Test
	public void dummyTest() {
		assertTrue(true);
	}

}
