package com.abacogroup.ddm.payment.core.impl;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.spy;

import java.time.Clock;
import java.time.Instant;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.Mockito;

import com.abacogroup.anomalyregistry.api.v1.AnomalySearchResponse;
import com.abacogroup.anomalyregistry.api.v1.AnomalySearchResponse.AnomalySearchResponseBuilder;
import com.abacogroup.anomalyregistry.api.v1.AnomalyTypeResponse;
import com.abacogroup.anomalyregistry.core.cli.v1.AnomalyClient;
import com.abacogroup.ddm.api.AnomalyLevelEnum;
import com.abacogroup.ddm.api.DdmAnomaliesRes;
import com.abacogroup.ddm.common.JdbiTest;
import com.abacogroup.ddm.common.ReqContextUtils;
import com.abacogroup.ddm.core.DdmAnomalyService;
import com.abacogroup.ddm.core.PartyService;
import com.abacogroup.ddm.core.exceptions.BankAccountException;
import com.abacogroup.ddm.core.exceptions.BankAccountException.ErrEnum;
import com.abacogroup.ddm.payment.api.BankAccountRes;
import com.abacogroup.ddm.payment.api.BankAccountSearchRes;
import com.abacogroup.ddm.payment.api.BankNetworkEnum;
import com.abacogroup.ddm.payment.api.req.BankAccountCreateReq;
import com.abacogroup.ddm.payment.api.req.BankAccountSearchReq;
import com.abacogroup.ddm.payment.api.req.BankAccountUpdateReq;
import com.abacogroup.ddm.payment.core.BankAccountService;
import com.abacogroup.ddm.payment.db.dao.BankAccountDAO;
import com.abacogroup.ddm.payment.db.ntt.BankAccountEntity;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.jdbi.model.AuditEntity;
import com.abacogroup.jdbi.paging.InfiniteListResults;

import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;

@ExtendWith(DropwizardExtensionsSupport.class)
class BankAccountServiceImplTest extends JdbiTest {

	private final BankAccountService service = getService(BankAccountServiceImpl.class);
	private final ReqContextUtils ctx = new ReqContextUtils(this.getClass());

	private final PartyService partyservice = mock(PartyService.class);
	private final DdmAnomalyService anomalyService = mock(DdmAnomalyService.class);
	private final AnomalyClient anomalyClient = mock(AnomalyClient.class);
//	private final PartyClientV1 partyClient = mock(PartyClientV1.class);
	private final Clock appClock = spy(Clock.systemDefaultZone());

	@BeforeEach
	void setUp() {
		this.injectMock(service, partyservice);
		this.injectMock(service, anomalyService);
		this.injectMock(service, anomalyClient);
		this.injectMock(service, appClock);
	}


	// ----- insert -----
	@Test
	void test_insert_ok() {
		setUnusedBindingAllowed(true);
		getJdbi().useHandle(handle -> {
			handle.begin();

			Long partyId = 555L;
			BankAccountCreateReq createReq = BankAccountCreateReq.builder()
					.setNetwork(BankNetworkEnum.SEPA)
					.setIban("IT47Y0300203280177188245251")
					.setSwiftBic("UNCRITMMXXX")
					.setBicExtraSepa(null)
					.setBankCountry("Italy (IT)")
					.setBankName("UNICREDIT BANCA DI ROMA SPA")
					.setBankBranch("ROMA 80 - PIAZZA MONTE")
					.setDescription("CC test")
					.setDefaultBankAccount(true)
					.setDayFrom(AbsoluteDate.of("20200202"))
					.build();

			//test
			BankAccountRes res = service.insert(ctx.getReqContext(), partyId, createReq);

			assertThat(res).isNotNull();
			assertThat(handle.attach(BankAccountDAO.class).findById(ctx.getTenantId(), partyId, res.getId()))
					.isPresent().get()
					.hasFieldOrPropertyWithValue("dayTo", AbsoluteDate.of(AuditEntity.dateActive))
					.hasFieldOrPropertyWithValue("partyId", partyId)
					.hasFieldOrPropertyWithValue("tenantId", ctx.getTenantId())
					.hasFieldOrPropertyWithValue("flDefault", 1)
					.usingRecursiveComparison()
					.ignoringFields("pkid","userIdDelete", "userIdInsert", "dtDelete", "dtInsert", "tenantId", "dayTo", "flDefault", "id", "partyId")
					.isEqualTo(createReq);

			handle.rollback();
		});
	}

	@Test
	void test_insert_partyKo() {

		Long partyId = 555L;
		BankAccountCreateReq createReq = BankAccountCreateReq.builder()
				.setNetwork(BankNetworkEnum.SEPA)
				.setIban("IT47Y0300203280177188245251")
				.setSwiftBic("UNCRITMMXXX")
				.setBicExtraSepa(null)
				.setBankCountry("Italy (IT)")
				.setBankName("UNICREDIT BANCA DI ROMA SPA")
				.setBankBranch("ROMA 80 - PIAZZA MONTE")
				.setDescription("CC test")
				.setDefaultBankAccount(true)
				.setDayFrom(AbsoluteDate.of("20200202"))
				.build();

		Mockito.doThrow(new BankAccountException(ErrEnum.INVALID_PARTY, ""))
				.when(partyservice).validatePartyId(any(), anyLong());

		setUnusedBindingAllowed(true);
		getJdbi().useHandle(handle -> {
			handle.begin();

			//test
			BankAccountException bankAccountException = assertThrows(BankAccountException.class, () -> service.insert(ctx.getReqContext(), partyId, createReq));

			assertThat(bankAccountException.getErrorBody().getErrorCode()).isEqualTo(ErrEnum.INVALID_PARTY.toString());

			handle.rollback();
		});
	}

	@Test
	void test_insert_ibanKo() {

		Long partyId = 555L;
		BankAccountCreateReq createReq = BankAccountCreateReq.builder()
				.setNetwork(BankNetworkEnum.SEPA)
				.setIban("1?2A")
				.setSwiftBic("UNCRITMMXXX")
				.setBicExtraSepa(null)
				.setBankCountry("Italy (IT)")
				.setBankName("UNICREDIT BANCA DI ROMA SPA")
				.setBankBranch("ROMA 80 - PIAZZA MONTE")
				.setDescription("CC test")
				.setDefaultBankAccount(true)
				.setDayFrom(AbsoluteDate.of("20200202"))
				.build();

		setUnusedBindingAllowed(true);
		getJdbi().useHandle(handle -> {
			handle.begin();

			//test
			BankAccountException bankAccountException = assertThrows(BankAccountException.class, () -> service.insert(ctx.getReqContext(), partyId, createReq));

			assertThat(bankAccountException.getErrorBody().getErrorCode()).isEqualTo(ErrEnum.INVALID_IBAN.toString());

			handle.rollback();
		});
	}

	@Test
	void test_insert_dayToKo() {

		Long partyId = 555L;
		BankAccountCreateReq createReq = BankAccountCreateReq.builder()
				.setNetwork(BankNetworkEnum.SEPA)
				.setIban("IT47Y0300203280177188245251")
				.setSwiftBic("UNCRITMMXXX")
				.setBicExtraSepa(null)
				.setBankCountry("Italy (IT)")
				.setBankName("UNICREDIT BANCA DI ROMA SPA")
				.setBankBranch("ROMA 80 - PIAZZA MONTE")
				.setDescription("CC test")
				.setDefaultBankAccount(true)
				.setDayFrom(AbsoluteDate.of("20200202"))
				.build();

		given(appClock.instant()).willReturn(Instant.ofEpochSecond(0));

		setUnusedBindingAllowed(true);
		getJdbi().useHandle(handle -> {
			handle.begin();

			//test
			BankAccountException bankAccountException = assertThrows(BankAccountException.class, () -> service.insert(ctx.getReqContext(), partyId, createReq));

			assertThat(bankAccountException.getErrorBody().getErrorCode()).isEqualTo(ErrEnum.INVALID_DAY_FROM.toString());

			handle.rollback();
		});
	}

	@Test
	void test_insert_duplicateKo() {
		setUnusedBindingAllowed(true);
		getJdbi().useHandle(handle -> {
			handle.begin();

			execSqlFiles(this.getClass(), List.of(
					"add_bank_accounts"
			), ctx.getTestScriptParams());

			Long partyId = 555L;
			BankAccountCreateReq createReq = BankAccountCreateReq.builder()
					.setNetwork(BankNetworkEnum.SEPA)
					.setIban("IT47Y0300203280177188245251")
					.setSwiftBic("UNCRITMMXXX")
					.setBicExtraSepa(null)
					.setBankCountry("Italy (IT)")
					.setBankName("UNICREDIT BANCA DI ROMA SPA")
					.setBankBranch("ROMA 80 - PIAZZA MONTE")
					.setDescription("CC test")
					.setDefaultBankAccount(true)
					.setDayFrom(AbsoluteDate.of("20200202"))
					.build();

			//test
			BankAccountException bankAccountException = assertThrows(BankAccountException.class,
					() -> service.insert(ctx.getReqContext(), partyId, createReq));

			assertThat(bankAccountException.getErrorBody().getErrorCode()).isEqualTo(ErrEnum.DUPLICATE_BANK_ACCOUNT.toString());

			handle.rollback();
		});
	}

	// ----- search -----
	@ParameterizedTest
	@MethodSource("com.abacogroup.ddm.payment.core.impl.BankAccountServiceImplTestSource#test_search_ok")
	void test_search_ok(String ignoredTitle, BankAccountSearchReq request, List<Long> expectedIds) {

		setUnusedBindingAllowed(true);
		getJdbi().useHandle(handle -> {
			handle.begin();

			execSqlFiles(this.getClass(), List.of(
					"add_bank_accounts"
			), ctx.getTestScriptParams());

			Long partyId = 555L;
			given(anomalyService.getAnomaliesGroupedByLevel(any(), anyString(), anyString(), anyList())).willReturn(new HashMap<>());

			//test
			InfiniteListResults<BankAccountSearchRes> results = service.search(ctx.getReqContext(), partyId, request, null);

			assertThat(results).isNotNull();
			assertThat(results.getRecords()).hasSize(expectedIds.size())
					.extracting(BankAccountRes::getId)
					.containsExactlyElementsOf(expectedIds);

			handle.rollback();
		});

	}

	@Test
	void test_search_mappingOk() {

		setUnusedBindingAllowed(true);
		getJdbi().useHandle(handle -> {
			handle.begin();

			execSqlFiles(this.getClass(), List.of(
					"add_bank_accounts"
			), ctx.getTestScriptParams());

			Long partyId = 555L;
			BankAccountSearchReq request = new BankAccountSearchReq();
			given(anomalyService.getAnomaliesGroupedByLevel(any(), anyString(), anyString(), anyList())).willReturn(Map.of(
					AnomalyLevelEnum.INFO, List.of(
							givenAnomaly(-1L).build(),
							givenAnomaly(-2L).build(),
							givenAnomaly(-1L).build()
					),
					AnomalyLevelEnum.WARN, List.of(
							givenAnomaly(-2L).build()
					),
					AnomalyLevelEnum.DANGER, List.of(
							givenAnomaly(-3L).build()
					)
			));

			//test
			InfiniteListResults<BankAccountSearchRes> results = service.search(ctx.getReqContext(), partyId, request, null);

			assertThat(results).isNotNull();
			assertThat(results.getRecords()).hasSize(4);

			assertThat(results.getRecords())
					.filteredOn(r -> r.getId().equals(-1L)).element(0)
					.extracting(BankAccountSearchRes::getAnomalies)
					.isEqualTo(new DdmAnomaliesRes(Map.of(
							AnomalyLevelEnum.INFO, List.of(
							givenAnomaly(-1L).build(),
							givenAnomaly(-1L).build()
					))));
			assertThat(results.getRecords())
					.filteredOn(r -> r.getId().equals(-2L)).element(0)
					.extracting(BankAccountSearchRes::getAnomalies)
					.isEqualTo(new DdmAnomaliesRes(Map.of(
							AnomalyLevelEnum.INFO, List.of(
									givenAnomaly(-2L).build()
							),
							AnomalyLevelEnum.WARN, List.of(
									givenAnomaly(-2L).build()
							))));
			assertThat(results.getRecords())
					.filteredOn(r -> r.getId().equals(-3L)).element(0)
					.extracting(BankAccountSearchRes::getAnomalies)
					.isEqualTo(new DdmAnomaliesRes(Map.of(
							AnomalyLevelEnum.DANGER, List.of(
									givenAnomaly(-3L).build()
							))));
			assertThat(results.getRecords())
					.filteredOn(r -> r.getId().equals(-4L)).element(0)
					.extracting(BankAccountSearchRes::getAnomalies)
					.isEqualTo(new DdmAnomaliesRes(Map.of()));

			handle.rollback();
		});

	}

	// ----- update -----
	@Test
	void test_update_ok() {
		setUnusedBindingAllowed(true);
		getJdbi().useHandle(handle -> {
			handle.begin();

			execSqlFiles(this.getClass(), List.of(
					"add_bank_accounts"
			), ctx.getTestScriptParams());

			Long partyId = 555L;
			Long accountId = -1L;
			BankAccountUpdateReq updateReq = BankAccountUpdateReq.builder()
					.setDescription("CC test")
					.setDefaultBankAccount(true)
					.build();

			//test
			BankAccountRes res = service.update(ctx.getReqContext(), partyId, accountId, updateReq);

			assertThat(res).isNotNull();
			assertThat(handle.attach(BankAccountDAO.class).findById(ctx.getTenantId(), partyId, accountId))
					.isPresent().get()
					.extracting(BankAccountEntity::getDescription, BankAccountEntity::getFlDefault)
					.containsExactly(updateReq.getDescription(), 1);
			assertThat(handle.attach(BankAccountDAO.class).findById(ctx.getTenantId(), partyId, -2L))
					.isPresent().get()
					.extracting(BankAccountEntity::getFlDefault)
					.isEqualTo(0);

			handle.rollback();
		});
	}

	// ----- updateDayTo -----
	@Test
	void test_updateDayTo_ok() {
		setUnusedBindingAllowed(true);
		getJdbi().useHandle(handle -> {
			handle.begin();

			execSqlFiles(this.getClass(), List.of(
					"add_bank_accounts"
			), ctx.getTestScriptParams());

			Long partyId = 555L;
			Long accountId = -2L;
			String dayTo = "20220222";

			//test
			BankAccountRes res = service.updateDayTo(ctx.getReqContext(), partyId, accountId, AbsoluteDate.of(dayTo));

			assertThat(res).isNotNull();
			assertThat(handle.attach(BankAccountDAO.class).findById(ctx.getTenantId(), partyId, accountId))
					.isPresent().get()
					.extracting(BankAccountEntity::getDayTo, BankAccountEntity::getFlDefault)
					.containsExactly(AbsoluteDate.of(dayTo), 0);

			handle.rollback();
		});
	}

	@Test
	void test_updateDayTo_beforeDayFromKo() {
		setUnusedBindingAllowed(true);
		getJdbi().useHandle(handle -> {
			handle.begin();

			execSqlFiles(this.getClass(), List.of(
					"add_bank_accounts"
			), ctx.getTestScriptParams());

			Long partyId = 555L;
			Long accountId = -2L;
			String dayTo = "20011001";

			//test
			BankAccountException bankAccountException = assertThrows(BankAccountException.class,
					() -> service.updateDayTo(ctx.getReqContext(), partyId, accountId, AbsoluteDate.of(dayTo)));

			assertThat(bankAccountException.getErrorBody().getErrorCode()).isEqualTo(ErrEnum.INVALID_DAY_TO.toString());
			System.out.println(bankAccountException.getMessage());

			handle.rollback();
		});
	}

	@Test
	void test_updateDayTo_afterTodayKo() {
		setUnusedBindingAllowed(true);
		getJdbi().useHandle(handle -> {
			handle.begin();

			execSqlFiles(this.getClass(), List.of(
					"add_bank_accounts"
			), ctx.getTestScriptParams());

			given(appClock.instant()).willReturn(Instant.ofEpochSecond(0));

			Long partyId = 555L;
			Long accountId = -2L;
			String dayTo = "20220202";

			//test
			BankAccountException bankAccountException = assertThrows(BankAccountException.class,
					() -> service.updateDayTo(ctx.getReqContext(), partyId, accountId, AbsoluteDate.of(dayTo)));

			assertThat(bankAccountException.getErrorBody().getErrorCode()).isEqualTo(ErrEnum.INVALID_DAY_TO.toString());
			System.out.println(bankAccountException.getMessage());

			handle.rollback();
		});
	}

	private AnomalySearchResponseBuilder<?, ?> givenAnomaly(Long accountId) {
		return AnomalySearchResponse.builder()
				.setId(null)
				.setEntityId(accountId.toString())
				.setEntityCode(AnomalyHelper.BANK_ACCOUNT_CODE)
				.setType(AnomalyTypeResponse.builder()
						.setId(null)
						.setCode("TEST")
						.setGroupCode("test.bank-account")
						.setI18nCode("Test")
						.build());
	}
}
