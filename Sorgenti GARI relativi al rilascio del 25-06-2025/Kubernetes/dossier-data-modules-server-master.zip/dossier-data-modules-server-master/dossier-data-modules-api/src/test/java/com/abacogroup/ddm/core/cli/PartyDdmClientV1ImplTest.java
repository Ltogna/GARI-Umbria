package com.abacogroup.ddm.core.cli;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.reset;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import com.abacogroup.ddm.common.WebCliHelper;
import com.abacogroup.ddm.core.exceptions.TestException;
import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.jdbi.paging.impl.InfiniteListResultsImpl;
import com.abacogroup.partyregistry.api.v1.PartyResponseV1;
import com.abacogroup.partyregistry.api.v1.PartySearchResponseV1;
import com.abacogroup.partyregistry.api.v1.req.PartySearchRequestV1;
import com.abacogroup.partyregistry.core.cli.v1.PartyClientV1;
import com.abacogroup.partyregistry.resources.PublicResourceConstants;
import com.abacogroup.partyregistry.resources.req.ArchivedEnum;
import io.dropwizard.auth.Auth;
import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;
import io.dropwizard.testing.junit5.ResourceExtension;
import jakarta.validation.Valid;
import jakarta.ws.rs.BadRequestException;
import jakarta.ws.rs.BeanParam;
import jakarta.ws.rs.DefaultValue;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.HeaderParam;
import jakarta.ws.rs.InternalServerErrorException;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.client.WebTarget;
import java.util.ArrayList;
import java.util.List;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

@ExtendWith({ DropwizardExtensionsSupport.class })
class PartyDdmClientV1ImplTest {

	public static final String PARTY_URI = PublicResourceConstants.API_V1_PUB + "/parties";
	private static final User USER = new User(WebCliHelper.BASIC_USERNAME, WebCliHelper.FAKE_JWT, WebCliHelper.TENANT, WebCliHelper.BASIC_USERNAME);
	private static final PingResource mockResource = spy(new PingResource());
	private static final ResourceExtension EXT = WebCliHelper.createEXT(mockResource);
	private final WebTarget prtBaseTarget = EXT.target("");
	private PartyClientV1 partyClient;

	@BeforeEach
	void setUp() {
		reset(mockResource);
		partyClient = new PartyDdmClientV1Impl(prtBaseTarget);
	}

	// ----- search -----
	@Test
	void test_search_ok() {
		PartySearchRequestV1 searchRequest = new PartySearchRequestV1()
				.setLastName("last")
				.setFirstName("first")
				.setTaxCode("000")
				.setVatNumber("111")
				.setTaxOrVat("222")
				.setCode("the_code")
				.setHasCode(true)
				.setFullName("Full Name")
				.setFullNameOrCode("Full the_code")
				.setTag(List.of("t1", "t2"))
				.setArchived(ArchivedEnum.all);
		String nextKey = "next";

		InfiniteListResults<PartySearchResponseV1> results = partyClient.search("it", USER, nextKey, searchRequest);

		assertThat(results).isNotNull();
		assertThat(results.getRecords()).hasSize(3)
				.containsExactly(
						PartySearchResponseV1.builder().setId(123L).build(),
						PartySearchResponseV1.builder().setId(456L).build(),
						PartySearchResponseV1.builder().setId(789L).build()
				);
		// TODO test jwt
		verify(mockResource).search(eq("it"), any(User.class), eq(USER.getTenant()), eq(nextKey),
				eq(new TestPartySearchRequestV1()
						.setLastName("last")
						.setFirstName("first")
						.setTaxCode("000")
						.setVatNumber("111")
						.setTaxOrVat("222")
						.setCode("the_code")
						.setHasCode(true)
						.setFullName("Full Name")
						.setFullNameOrCode("Full the_code")
						.setTag(List.of("t1", "t2"))
						.setArchived(ArchivedEnum.all)));
	}

	@Test
	void test_search_400() {
		PartySearchRequestV1 searchRequest = new PartySearchRequestV1()
				.setLastName("give me 400");
		String nextKey = "next";

		assertThrows(BadRequestException.class, () -> partyClient.search("it", USER, nextKey, searchRequest));

		// TODO test jwt
		verify(mockResource).search(eq("it"), any(User.class), eq(USER.getTenant()), eq(nextKey),
				eq(new TestPartySearchRequestV1()
						.setLastName("give me 400")
						.setArchived(ArchivedEnum.not_archived)
						.setTag(new ArrayList<>())));
	}

	@Test
	void test_search_500() {
		PartySearchRequestV1 searchRequest = new PartySearchRequestV1()
				.setLastName("give me 500");
		String nextKey = "next";

		assertThrows(InternalServerErrorException.class, () -> partyClient.search("it", USER, nextKey, searchRequest));

		// TODO test jwt
		verify(mockResource, times(2)).search(eq("it"), any(User.class), eq(USER.getTenant()), eq(nextKey),
				eq(new TestPartySearchRequestV1()
						.setLastName("give me 500")
						.setArchived(ArchivedEnum.not_archived)
						.setTag(new ArrayList<>())));
	}

	// ----- getById -----
	@Test
	void test_getById_ok() {
		long id = 123L;

		PartyResponseV1 party = partyClient.getById("it", USER, id);

		assertThat(party).isNotNull().isEqualTo(new PartyResponseV1().setId(id));
		// TODO test jwt
		verify(mockResource).getById(eq("it"), any(User.class), eq(USER.getTenant()), eq(id));
	}

	@Test
	void test_givenNotExistingId_getById_null() {
		long id = 999L;

		PartyResponseV1 party = partyClient.getById("it", USER, id);

		assertThat(party).isNull();
		// TODO test jwt
		verify(mockResource).getById(eq("it"), any(User.class), eq(USER.getTenant()), eq(id));
	}

	// ----- getByCuaa -----
	@Test
	void test_getByCuaa_ok() {
		String cuaa = "ABCDE";

		PartyResponseV1 party = partyClient.getByCode("it", USER, cuaa);

		assertThat(party).isNotNull();
		// TODO test jwt
		verify(mockResource).getByCuaa(eq("it"), any(User.class), eq(USER.getTenant()), eq(cuaa));
	}

	@Path(PARTY_URI)
	public static class PingResource {

		@GET
		public InfiniteListResults<PartySearchResponseV1> search(
				@HeaderParam("accept-language") @DefaultValue("en") String lang,
				@Auth User user,
				@PathParam("tenant") String tenantId,
				@QueryParam("nextKey") String nextKey,
				@BeanParam @Valid TestPartySearchRequestV1 partySearchReq
		) {
			if (partySearchReq.getLastName().equals("give me 400")) {
				throw new TestException("as requested");
			} else if (partySearchReq.getLastName().equals("give me 500")) {
				throw new RuntimeException("something happened!");
			}
			return new InfiniteListResultsImpl<>(List.of(
					PartySearchResponseV1.builder().setId(123L).build(),
					PartySearchResponseV1.builder().setId(456L).build(),
					PartySearchResponseV1.builder().setId(789L).build()
			), null);
		}

		@GET
		@Path("/{id}")
		public PartyResponseV1 getById(
				@HeaderParam("accept-language") @DefaultValue("en") String lang,
				@Auth User user,
				@PathParam("tenant") String tenantId,
				@PathParam("id") Long id
		) {
			if (id.equals(123L)) {
				return new PartyResponseV1().setId(123L);
			} else {
				return null;
			}
		}

		@GET
		@Path("/code/{code}")
		public PartyResponseV1 getByCuaa(
				@HeaderParam("accept-language") @DefaultValue("en") String lang,
				@Auth User user,
				@PathParam("tenant") String tenantId,
				@PathParam("code") String code
		) {
			return new PartyResponseV1().setId(123L);
		}
	}

	@Data
	@NoArgsConstructor
	@Accessors(chain = true)
	public static class TestPartySearchRequestV1 {//extends PartySearchRequestV1 {

		@QueryParam("lastName")
		private String lastName;

		@QueryParam("firstName")
		private String firstName;

		@QueryParam("taxCode")
		private String taxCode;

		@QueryParam("vatNumber")
		private String vatNumber;

		@QueryParam("taxOrVat")
		private String taxOrVat;

		@QueryParam("code")
		private String code;

		@QueryParam("hasCode")
		private Boolean hasCode;

		@QueryParam("fullName")
		private String fullName;
		@QueryParam("fullNameOrCode")
		private String fullNameOrCode;

		@QueryParam("tag")
		private List<String> tag;

		@DefaultValue("not_archived")
		@QueryParam("archived")
		private ArchivedEnum archived;

	}
}
