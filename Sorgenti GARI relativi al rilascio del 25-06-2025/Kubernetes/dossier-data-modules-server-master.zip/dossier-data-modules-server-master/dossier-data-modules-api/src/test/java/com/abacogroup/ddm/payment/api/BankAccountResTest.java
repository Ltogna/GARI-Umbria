package com.abacogroup.ddm.payment.api;

import static org.assertj.core.api.Assertions.assertThat;

import com.abacogroup.jdbi.datatype.AbsoluteDate;
import java.time.LocalDate;
import org.junit.jupiter.api.Test;

class BankAccountResTest {

	@Test
	void testActiveTodayWhenCreatedToday() {
		BankAccountRes res = BankAccountRes.builder()
				.setDayFrom(AbsoluteDate.of(LocalDate.now()))
				.setDayTo(AbsoluteDate.of("99991231"))
				.build();
		assertThat(res.isActive()).isTrue();
	}

	@Test
	void testActiveTodayWhenCreatedYesterday() {
		BankAccountRes res = BankAccountRes.builder()
				.setDayFrom(AbsoluteDate.of(LocalDate.now().minusDays(1)))
				.setDayTo(AbsoluteDate.of("99991231"))
				.build();
		assertThat(res.isActive()).isTrue();
	}

	@Test
	void testNotActiveWhenCreatedTomorrow() {
		BankAccountRes  res = BankAccountRes.builder()
				.setDayFrom(AbsoluteDate.of(LocalDate.now().plusDays(1)))
				.setDayTo(AbsoluteDate.of("99991231"))
				.build();
		assertThat(res.isActive()).isFalse();
	}

}
