package com.abacogroup.ddm.payment.resource.pub.v1;

import static com.abacogroup.ddm.common.WebCliHelper.TENANT;
import static com.abacogroup.ddm.payment.core.impl.AnomalyHelper.BANK_ACCOUNT_CODE;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.any;
import static org.mockito.Mockito.anyLong;
import static org.mockito.Mockito.anyString;
import static org.mockito.Mockito.eq;
import static org.mockito.Mockito.isNull;
import static org.mockito.Mockito.verify;

import com.abacogroup.anomalyregistry.api.v1.AnomalySearchResponse;
import com.abacogroup.anomalyregistry.api.v1.AnomalyTypeResponse;
import com.abacogroup.ddm.api.AnomalyLevelEnum;
import com.abacogroup.ddm.api.DdmAnomaliesRes;
import com.abacogroup.ddm.api.v1.PartyDetailResponseV1;
import com.abacogroup.ddm.common.WebCliHelper;
import com.abacogroup.ddm.common.resources.ReqContext;
import com.abacogroup.ddm.payment.api.BankAccountRes;
import com.abacogroup.ddm.payment.api.BankAccountRes.BankAccountResBuilder;
import com.abacogroup.ddm.payment.api.BankAccountSearchRes;
import com.abacogroup.ddm.payment.api.BankAccountSearchRes.BankAccountSearchResBuilder;
import com.abacogroup.ddm.payment.api.BankNetworkEnum;
import com.abacogroup.ddm.payment.api.req.BankAccountSearchReq;
import com.abacogroup.ddm.payment.api.v1.BankAccountResponseV1;
import com.abacogroup.ddm.payment.api.v1.BankAccountSearchResponseV1;
import com.abacogroup.ddm.payment.api.v1.req.ActiveEnum;
import com.abacogroup.ddm.payment.api.v1.req.BankAccountSearchRequestV1;
import com.abacogroup.ddm.payment.core.BankAccountService;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.jdbi.model.AuditEntity;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.jdbi.paging.impl.InfiniteListResultsImpl;
import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;
import io.dropwizard.testing.junit5.ResourceExtension;
import jakarta.ws.rs.core.GenericType;
import jakarta.ws.rs.core.UriBuilder;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;

@ExtendWith(DropwizardExtensionsSupport.class)
class BankAccountPublicResourceTest {

	private final BankAccountService bankAccountService = Mockito.mock(BankAccountService.class);

	private final BankAccountPublicResource resource = new BankAccountPublicResource(bankAccountService);
	private final ResourceExtension EXT = WebCliHelper.createEXT(resource);

	// ----- search -----
	@Test
	void test_search_ok() {
		Long partyId = 555L;
		Long accountId = 100L;

		BankAccountSearchRequestV1 searchReq = new BankAccountSearchRequestV1()
				.setActive(ActiveEnum.only_active)
				.setDescription("descr")
				.setIban("IT08W0300203280185367754125")
				.setNetwork(BankNetworkEnum.SEPA);

		Map<String, Object> queryMap = new HashMap<>(EXT.getObjectMapper().convertValue(searchReq, Map.class));
		queryMap.put("nextKey", "111");

		UriBuilder uriBuilder = UriBuilder.fromResource(resource.getClass()).path(resource.getClass(), "search");
		queryMap.forEach(uriBuilder::queryParam);
		String uri = uriBuilder.build(TENANT, partyId).toString();
		System.out.println(uri);

		BankAccountSearchRes mockRes = givenBankAccountSearchRes(partyId, accountId).build();
		given(bankAccountService.search(any(), anyLong(), any(), anyString()))
				.willReturn(new InfiniteListResultsImpl<>(List.of(mockRes), null));

		InfiniteListResultsImpl<BankAccountSearchResponseV1> res = EXT.getJerseyTest().client()
				.target(UriBuilder.fromUri(uri))
				.request()
				.header("Authorization", WebCliHelper.JWT_MOCK_CREDENTIALS)
				.get(new GenericType<>() {
				});

		assertThat(res).isNotNull()
				.extracting(InfiniteListResults::getRecords)
				.asList()
				.usingRecursiveComparison()
				.ignoringFields("active")
				.isEqualTo(List.of(mockRes));

		verify(bankAccountService).search(any(ReqContext.class), eq(partyId), eq(new BankAccountSearchReq()
				.setActive(ActiveEnum.only_active)
				.setDescription("descr")
				.setIban("IT08W0300203280185367754125")
				.setNetwork(BankNetworkEnum.SEPA)), eq("111"));
	}

	@Test
	void test_search_emptyOk() {
		Long partyId = 555L;
		Long accountId = 100L;

		BankAccountSearchRequestV1 searchReq = new BankAccountSearchRequestV1();

		UriBuilder uriBuilder = UriBuilder.fromResource(resource.getClass()).path(resource.getClass(), "search");
		String uri = uriBuilder.build(TENANT, partyId).toString();
		System.out.println(uri);

		BankAccountSearchRes mockRes = givenBankAccountSearchRes(partyId, accountId).build();
		given(bankAccountService.search(any(), anyLong(), any(), any()))
				.willReturn(new InfiniteListResultsImpl<>(List.of(mockRes), null));

		InfiniteListResultsImpl<BankAccountSearchResponseV1> res = EXT.getJerseyTest().client()
				.target(UriBuilder.fromUri(uri))
				.request()
				.header("Authorization", WebCliHelper.JWT_MOCK_CREDENTIALS)
				.get(new GenericType<>() {
				});

		assertThat(res).isNotNull()
				.extracting(InfiniteListResults::getRecords)
				.asList()
				.usingRecursiveComparison()
				.ignoringFields("active")
				.isEqualTo(List.of(mockRes));

		verify(bankAccountService).search(any(ReqContext.class), eq(partyId), eq(new BankAccountSearchReq()), isNull());
	}

	// ----- getById -----
	@Test
	void test_getById_ok() {
		Long partyId = 555L;
		Long accountId = 100L;

		UriBuilder uriBuilder = UriBuilder.fromResource(resource.getClass()).path(resource.getClass(), "getById");
		String uri = uriBuilder.build(TENANT, partyId, accountId).toString();
		System.out.println(uri);

		BankAccountSearchRes mockRes = givenBankAccountSearchRes(partyId, accountId).build();
		given(bankAccountService.getById(any(), anyLong(), anyLong())).willReturn(Optional.of(mockRes));

		BankAccountSearchResponseV1 res = EXT.getJerseyTest().client()
				.target(UriBuilder.fromUri(uri))
				.request()
				.header("Authorization", WebCliHelper.JWT_MOCK_CREDENTIALS)
				.get(new GenericType<>() {
				});

		assertThat(res).isNotNull()
				.usingRecursiveComparison()
				.ignoringFields("active")
				.isEqualTo(mockRes);

		verify(bankAccountService).getById(any(ReqContext.class), eq(partyId), eq(accountId));
	}

	@Test
	void test_getById_empty() {
		Long partyId = 555L;
		Long accountId = 100L;

		UriBuilder uriBuilder = UriBuilder.fromResource(resource.getClass()).path(resource.getClass(), "getById");
		String uri = uriBuilder.build(TENANT, partyId, accountId).toString();
		System.out.println(uri);

		given(bankAccountService.getById(any(), anyLong(), anyLong())).willReturn(Optional.empty());

		BankAccountResponseV1 res = EXT.getJerseyTest().client()
				.target(UriBuilder.fromUri(uri))
				.request()
				.header("Authorization", WebCliHelper.JWT_MOCK_CREDENTIALS)
				.get(new GenericType<>() {
				});

		assertThat(res).isNull();

		verify(bankAccountService).getById(any(ReqContext.class), eq(partyId), eq(accountId));
	}

	// ----- getActiveDefault -----
	@Test
	void test_getActiveDefault_ok() {
		Long partyId = 555L;
		Long accountId = 100L;

		UriBuilder uriBuilder = UriBuilder.fromResource(resource.getClass()).path(resource.getClass(), "getActiveDefault");
		String uri = uriBuilder.build(TENANT, partyId).toString();
		System.out.println(uri);

		BankAccountSearchRes mockRes = givenBankAccountSearchRes(partyId, accountId).build();
		given(bankAccountService.getActiveDefault(any(), anyLong())).willReturn(Optional.of(mockRes));

		BankAccountSearchResponseV1 res = EXT.getJerseyTest().client()
				.target(UriBuilder.fromUri(uri))
				.request()
				.header("Authorization", WebCliHelper.JWT_MOCK_CREDENTIALS)
				.get(new GenericType<>() {
				});

		assertThat(res).isNotNull()
				.usingRecursiveComparison()
				.ignoringFields("active")
				.isEqualTo(mockRes);

		verify(bankAccountService).getActiveDefault(any(ReqContext.class), eq(partyId));
	}


	private BankAccountResBuilder<?, ?> givenBankAccountRes(Long partyId, Long accountId) {
		return BankAccountRes.builder()
				.setId(accountId)
				.setPartyId(partyId)
				.setNetwork(BankNetworkEnum.SEPA)
				.setIban("IT08W0300203280185367754125")
				.setSwiftBic("UNCRITMMXXX")
				.setBankName("UNICREDIT BANCA DI ROMA SPA")
				.setBankCountry("Italy (IT)")
				.setBankBranch("ROMA 80 - PIAZZA MONTE")
				.setDescription("test resource")
				.setDefaultBankAccount(true)
				.setDayFrom(AbsoluteDate.of(LocalDate.ofEpochDay(0)))
				.setDayTo(AbsoluteDate.of(AuditEntity.dateActive));
	}

	private BankAccountSearchResBuilder<?, ?> givenBankAccountSearchRes(Long partyId, Long accountId) {
		return BankAccountSearchRes.builder()
				.setId(accountId)
				.setPartyId(partyId)
				.setNetwork(BankNetworkEnum.SEPA)
				.setIban("IT08W0300203280185367754125")
				.setSwiftBic("UNCRITMMXXX")
				.setBankName("UNICREDIT BANCA DI ROMA SPA")
				.setBankCountry("Italy (IT)")
				.setBankBranch("ROMA 80 - PIAZZA MONTE")
				.setDescription("test resource")
				.setDefaultBankAccount(true)
				.setDayFrom(AbsoluteDate.of(LocalDate.ofEpochDay(0)))
				.setDayTo(AbsoluteDate.of(AuditEntity.dateActive))
				.setAnomalies(DdmAnomaliesRes.builder()
						.setAnomaliesGrouped(Map.of(AnomalyLevelEnum.INFO, List.of(
								AnomalySearchResponse.builder()
										.setType(AnomalyTypeResponse.builder()
												.setCode("TEST")
												.setGroupCode("test.bank-account")
												.setI18nCode("Test")
												.build())
										.setEntityId(accountId.toString())
										.setEntityCode(BANK_ACCOUNT_CODE)
										.build()
						))).build());
	}

	/* getListOfPartiesGivenTheIBAN */

	@Test
	public void test_getListOfPartiesGivenTheIBAN_ok() {
		Long partyId = 555L;
		Long accountId = 100L;
		String iban = "IT08W0300203280185367754125";

		UriBuilder uriBuilder = UriBuilder.fromResource(resource.getClass()).path(resource.getClass(), "getListOfPartiesGivenTheIBAN");
		String uri = uriBuilder.build(TENANT, iban).toString();
		System.out.println(uri);


		BankAccountSearchRes mockRes = givenBankAccountSearchRes(partyId, accountId).build();
		given(bankAccountService.getByIban(any(), anyString(), anyString(), anyString()))
				.willReturn(new InfiniteListResultsImpl<PartyDetailResponseV1>());

		InfiniteListResultsImpl<BankAccountSearchResponseV1> res = EXT.getJerseyTest().client()
				.target(UriBuilder.fromUri(uri))
				.request()
				.header("Authorization", WebCliHelper.JWT_MOCK_CREDENTIALS)
				.get(new GenericType<>() {
				});

		assertThat(res).isNull();

		verify(bankAccountService).getByIban(any(ReqContext.class), eq(iban), eq(LocalDate.now().toString()), eq(null));
	}
}
