package com.abacogroup.ddm.core.impl;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.tuple;

import com.abacogroup.ddm.api.AppConfigRes;
import com.abacogroup.ddm.common.JdbiTest;
import com.abacogroup.ddm.common.ReqContextUtils;
import com.abacogroup.ddm.core.AppConfigService;
import com.abacogroup.ddm.core.dto.appconfig.PaymentDefaultAccount;
import com.abacogroup.ddm.core.dto.appconfig.PaymentRegexValidation;
import com.abacogroup.ddm.core.dto.appconfig.PaymentValidation;
import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

@ExtendWith(DropwizardExtensionsSupport.class)
class AppConfigServiceImplTest extends JdbiTest {

	private final ReqContextUtils ctx = new ReqContextUtils(this.getClass());

	private AppConfigService appConfigService = getService(AppConfigServiceImpl.class);

	// ----- getConfig -----
	@Test
	void test_getConfig_ok() {
		getJdbi().useHandle(handle -> {
			handle.begin();

			execSqlFiles(this.getClass(), List.of("app_config"), ctx.getTestScriptParams());

			assertThat(appConfigService.getConfig(ctx.getTenantId(), PaymentRegexValidation.CONFIG_KEY, PaymentRegexValidation.class))
					.isPresent().get()
					.isEqualTo(PaymentRegexValidation.builder()
							.setConfigurationKey(PaymentRegexValidation.CONFIG_KEY)
							.setConfiguration(new PaymentRegexValidation.Config(List.of("[A-Z]+")))
							.build());

			assertThat(appConfigService.getConfig(ctx.getTenantId(), PaymentDefaultAccount.CONFIG_KEY, PaymentDefaultAccount.class))
					.isPresent().get()
					.isEqualTo(PaymentDefaultAccount.builder()
							.setConfigurationKey(PaymentDefaultAccount.CONFIG_KEY)
							.setConfiguration(new PaymentDefaultAccount.Config(true))
							.build());

			assertThat(appConfigService.getConfig(ctx.getTenantId(), PaymentValidation.CONFIG_KEY, PaymentValidation.class))
					.isNotPresent();

			handle.rollback();
		});
	}

	// ----- searchAll -----
	@Test
	void test_searchAll_ok() {
		getJdbi().useHandle(handle -> {
			handle.begin();

			execSqlFiles(this.getClass(), List.of("app_config"), ctx.getTestScriptParams());

			assertThat(appConfigService.searchAll(ctx.getReqContext()))
					.extracting(AppConfigRes::getConfigurationKey, c -> c.getConfiguration().toString())
					.containsExactly(
							tuple(PaymentRegexValidation.CONFIG_KEY, "{\"regexes\":[\"[A-Z]+\"]}"),
							tuple(PaymentDefaultAccount.CONFIG_KEY, "{\"allowClose\":true}")
					);

			handle.rollback();
		});
	}

	// ----- searchByKey -----
	@Test
	void test_searchByKey_ok() {
		getJdbi().useHandle(handle -> {
			handle.begin();

			execSqlFiles(this.getClass(), List.of("app_config"), ctx.getTestScriptParams());

			assertThat(appConfigService.searchByKey(ctx.getReqContext(), PaymentRegexValidation.CONFIG_KEY))
					.isPresent().get()
					.extracting(AppConfigRes::getConfigurationKey, c -> c.getConfiguration().toString())
					.containsExactly(PaymentRegexValidation.CONFIG_KEY, "{\"regexes\":[\"[A-Z]+\"]}");

			assertThat(appConfigService.searchByKey(ctx.getReqContext(), PaymentDefaultAccount.CONFIG_KEY))
					.isPresent().get()
					.extracting(AppConfigRes::getConfigurationKey, c -> c.getConfiguration().toString())
					.containsExactly(PaymentDefaultAccount.CONFIG_KEY, "{\"allowClose\":true}");

			assertThat(appConfigService.searchByKey(ctx.getReqContext(), PaymentValidation.CONFIG_KEY))
					.isNotPresent();

			handle.rollback();
		});
	}
}
