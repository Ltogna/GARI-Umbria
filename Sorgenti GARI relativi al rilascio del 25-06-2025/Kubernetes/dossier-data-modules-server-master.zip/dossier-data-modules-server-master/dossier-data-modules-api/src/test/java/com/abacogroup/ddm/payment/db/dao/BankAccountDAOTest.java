package com.abacogroup.ddm.payment.db.dao;

import static org.junit.jupiter.api.Assertions.assertTrue;

import java.time.LocalDate;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

import com.abacogroup.ddm.common.JdbiTest;
import com.abacogroup.ddm.common.core.AuditHelper;
import com.abacogroup.ddm.payment.api.BankNetworkEnum;
import com.abacogroup.ddm.payment.db.ntt.BankAccountEntity;
import com.abacogroup.jdbi.datatype.AbsoluteDate;

import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;

@ExtendWith(DropwizardExtensionsSupport.class)
class BankAccountDAOTest extends JdbiTest {

	@Test
	void test_save() {

		BankAccountEntity entity = BankAccountEntity.builder()
				.setTenantId("a_tenant")
				.setPartyId(-123L)

				.setNetwork(BankNetworkEnum.SEPA)
				.setIban("ITCCVV123")
				.setBankCountry("Italy")
				.setBankName("Banca Agri")
				.setDayFrom(AbsoluteDate.of(LocalDate.now()))
				.setDayTo(AbsoluteDate.of(LocalDate.now()))
				.build();

		var dao = this.getDAO(BankAccountDAO.class);
		long id= dao.issuePk();
		AuditHelper.setAuditForInsert("userId", dao, entity);
		dao.insertMasterRow(id, entity);
		dao.insertDetailRow(entity, id);
		
		assertTrue(true);
	}
}
