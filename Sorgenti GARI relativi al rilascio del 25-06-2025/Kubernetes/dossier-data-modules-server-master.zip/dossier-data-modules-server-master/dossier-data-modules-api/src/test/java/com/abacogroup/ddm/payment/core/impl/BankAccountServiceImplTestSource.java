package com.abacogroup.ddm.payment.core.impl;

import com.abacogroup.ddm.payment.api.BankNetworkEnum;
import com.abacogroup.ddm.payment.api.req.BankAccountSearchReq;
import com.abacogroup.ddm.payment.api.v1.req.ActiveEnum;
import java.util.List;
import java.util.stream.Stream;
import org.junit.jupiter.params.provider.Arguments;

class BankAccountServiceImplTestSource {

	static Stream<Arguments> test_search_ok() {
		return Stream.of(
				Arguments.of("empty search req",
						new BankAccountSearchReq(),
						List.of(-2L, -3L, -1L, -4L))
				, Arguments.of("active=only_active",
						new BankAccountSearchReq().setActive(ActiveEnum.only_active),
						List.of(-2L, -1L, -4L))
				, Arguments.of("active=not_active",
						new BankAccountSearchReq().setActive(ActiveEnum.not_active),
						List.of(-3L))
				, Arguments.of("network=SEPA",
						new BankAccountSearchReq().setNetwork(BankNetworkEnum.SEPA),
						List.of(-2L, -3L, -1L))
				, Arguments.of("description=test",
						new BankAccountSearchReq().setDescription("test"),
						List.of(-2L, -3L, -1L, -4L))
				, Arguments.of("description=test 4",
						new BankAccountSearchReq().setDescription("test 4"),
						List.of(-4L))
				, Arguments.of("iban=gb80barc20040162398845",
						new BankAccountSearchReq().setIban("gb80barc20040162398845"),
						List.of(-2L, -3L))
				, Arguments.of("iban=GB80BARC20040162398845&active=only_active",
						new BankAccountSearchReq().setIban("GB80BARC20040162398845").setActive(ActiveEnum.only_active),
						List.of(-2L))

		);
	}
}
