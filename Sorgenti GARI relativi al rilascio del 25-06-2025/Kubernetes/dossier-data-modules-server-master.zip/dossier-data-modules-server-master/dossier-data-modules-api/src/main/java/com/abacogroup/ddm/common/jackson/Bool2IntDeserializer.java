package com.abacogroup.ddm.common.jackson;

import com.fasterxml.jackson.core.JacksonException;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonToken;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonDeserializer;
import java.io.IOException;

public class Bool2IntDeserializer extends JsonDeserializer<Integer> {
	@Override
	public Integer deserialize(JsonParser p, DeserializationContext ctxt) throws IOException {
		int val = 0;
		if (p.hasToken(JsonToken.VALUE_TRUE)) {
			val = 1;
		}
		return val;

	}
}
