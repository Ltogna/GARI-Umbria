package com.abacogroup.ddm.bundle.model;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder(setterPrefix = "set")
@NoArgsConstructor
@AllArgsConstructor
public class SuccessionConfigDeleteListMessage {
	
	private List<SuccessionConfigMessage> successionConfigList;
	
}
