package com.abacogroup.ddm.payment.core.impl;

import static com.abacogroup.ddm.DossierDataModulesApplication.PAYMENT_MODULE;

import com.abacogroup.anomalyregistry.api.v1.req.AnomalyRequest;
import com.abacogroup.anomalyregistry.core.cli.v1.AnomalyClient;
import com.abacogroup.ddm.common.resources.ReqContext;
import com.abacogroup.ddm.db.dao.DocTypeRelationDAO;
import com.abacogroup.ddm.db.ntt.DocTypeRelationEntity;
import com.abacogroup.ddm.payment.db.dao.BankAccountDAO;
import com.abacogroup.ddm.payment.db.dao.BankAccountDocumentDAO;
import com.abacogroup.ddm.payment.db.ntt.BankAccountDocumentEntity;
import com.abacogroup.ddm.payment.db.ntt.BankAccountEntity;
import com.abacogroup.dynamicdocuments.services.DocumentService;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import java.time.Clock;
import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class AnomalyHelper {

	public static final String ANM_TYPE_NO_CC = "NO_CC";
	public static final String ANM_TYPE_CC_PRED = "CC_PRED";
	public static final String ANM_TYPE_915 = "915";
	public static final String ANM_TYPE_ATTO = "ATTO";

	public static final String ANM_GROUP_CODE_PAYMENT_ACCOUNT = "dossier-data-modules-server.payment.account";
	public static final String ANM_GROUP_CODE_PAYMENT_DD = "dossier-data-modules-server.payment.dynamic-documents";

	public static final String PARTY_ENTITY_CODE = "REFERENCE_PARTY";
	public static final String BANK_ACCOUNT_CODE = "REFERENCE_BANK_ACCOUNT";


	private final AnomalyClient anomalyClient;
	private final ReqContext reqContext;
	private final Clock appClock;

	private final Set<AnomalyRequest> toExpire;
	private final Set<AnomalyRequest> toAdd;

	private AnomalyHelper(AnomalyClient anomalyClient, ReqContext reqContext, Clock appClock) {
		this.anomalyClient = anomalyClient;
		this.reqContext = reqContext;
		this.appClock = appClock;

		this.toExpire = new HashSet<>();
		this.toAdd = new HashSet<>();
	}

	public static AnomalyHelper newInstance(AnomalyClient anomalyClient, ReqContext reqContext, Clock appClock) {
		return new AnomalyHelper(anomalyClient, reqContext, appClock);
	}

	// NO_CC

	public AnomalyHelper expireNoCC(Long partyId) {
		//1 - try spegnere tutte le anom di tipo ANM_TYPE_NO_CC per il party corrente
		return expire(AnomalyRequest.builder()
				.setEntityCode(PARTY_ENTITY_CODE)
				.setEntityId(String.valueOf(partyId))
				.setTypeCode(ANM_TYPE_NO_CC)
				.setTypeGroupCode(ANM_GROUP_CODE_PAYMENT_ACCOUNT)
				.build());
	}

	public AnomalyHelper addNoCC(Long partyId) {
		return add(AnomalyRequest.builder()
				.setEntityCode(PARTY_ENTITY_CODE)
				.setEntityId(String.valueOf(partyId))
				.setTypeCode(ANM_TYPE_NO_CC)
				.setTypeGroupCode(ANM_GROUP_CODE_PAYMENT_ACCOUNT)
				.build());
	}

	public AnomalyHelper tryAddNoCC(BankAccountDAO bankAccountDAO, Long partyId) {
		//1 - se non ci sono altri cc validi per il party  accensione anom no_cc
		if (bankAccountDAO.countByPartyId(reqContext.getTenantId(), partyId,
				AbsoluteDate.of(LocalDate.now(appClock)).getValue()) <= 0) {
			return addNoCC(partyId);
		}
		return this;
	}

	public AnomalyHelper recalculateNoCC(BankAccountDAO bankAccountDAO, Long partyId) {
		if (bankAccountDAO.countByPartyId(reqContext.getTenantId(), partyId,
				AbsoluteDate.of(LocalDate.now(appClock)).getValue()) <= 0) {
			return addNoCC(partyId);
		} else {
			return expireNoCC(partyId);
		}
	}

	// CC_PRED

	public AnomalyHelper expireCCPred(Long partyId) {
		return expire(AnomalyRequest.builder()
				.setEntityCode(PARTY_ENTITY_CODE)
				.setEntityId(String.valueOf(partyId))
				.setTypeCode(ANM_TYPE_CC_PRED)
				.setTypeGroupCode(ANM_GROUP_CODE_PAYMENT_ACCOUNT)
				.build());
	}

	public AnomalyHelper tryExpireCCPred(BankAccountEntity entity) {
		//2 - se predefinito {
		if (entity.getFlDefault() == 1) {
			//	spegni tutte le CC_PRED per il party corrente
			return expireCCPred(entity.getPartyId());
		}
		return this;
	}

	private AnomalyHelper addCCPred(Long partyId) {
		return add(AnomalyRequest.builder()
				.setEntityCode(PARTY_ENTITY_CODE)
				.setEntityId(String.valueOf(partyId))
				.setTypeCode(ANM_TYPE_CC_PRED)
				.setTypeGroupCode(ANM_GROUP_CODE_PAYMENT_ACCOUNT)
				.build());
	}

	public AnomalyHelper tryAddCCPred(BankAccountDAO bankAccountDAO, Long partyId) {
		//  se non c'è nessun predefinito per il party accendi anomalia
		if (bankAccountDAO.findDefault(reqContext.getTenantId(), partyId,
				AbsoluteDate.of(LocalDate.now(appClock)).getValue()).isEmpty()) {
			return addCCPred(partyId);
		}
		return this;
	}

	public AnomalyHelper recalculateCCPred(BankAccountDAO bankAccountDAO, Long partyId) {
		//  se non c'è nessun predefinito per il party accendi anomalia
		String refDate = AbsoluteDate.of(LocalDate.now(appClock)).getValue();
		if (bankAccountDAO.findDefault(reqContext.getTenantId(), partyId,
				refDate).isEmpty()) {
			if (bankAccountDAO.countByPartyId(reqContext.getTenantId(), partyId, refDate) > 0) {
				return addCCPred(partyId);
			} else {
				return this;
			}
		} else {
			return expireCCPred(partyId);
		}
	}

	// 195

	public AnomalyHelper expire195(BankAccountDAO bankAccountDAO, BankAccountEntity entity) {
		//3 - spegnimento 915 su questo cc.
		// se count duplicati = 1 spegnamo l'altro

		List<BankAccountEntity> entitiesByIban = bankAccountDAO.findByIbanConcat(reqContext.getTenantId(),
				entity.getIban(), entity.getSwiftBic(), entity.getBicExtraSepa(),
				AbsoluteDate.of(LocalDate.now(appClock)).getValue());
		entitiesByIban.removeIf(e -> e.getId().equals(entity.getId())); // always false
		if (entitiesByIban.size() == 1) {
			entitiesByIban.forEach(bankAccountEntity ->  {
				expire195(bankAccountEntity.getId());
			});
		}

		return expire195(entity.getId());
	}

	public AnomalyHelper expire195(Long accountId) {
		return expire(AnomalyRequest.builder()
				.setEntityCode(BANK_ACCOUNT_CODE)
				.setEntityId(String.valueOf(accountId))
				.setTypeCode(ANM_TYPE_915)
				.setTypeGroupCode(ANM_GROUP_CODE_PAYMENT_ACCOUNT)
				.build());
	}

	public AnomalyHelper add195(Long accountId) {
		add(AnomalyRequest.builder()
				.setEntityCode(BANK_ACCOUNT_CODE)
				.setEntityId(String.valueOf(accountId))
				.setTypeCode(ANM_TYPE_915)
				.setTypeGroupCode(ANM_GROUP_CODE_PAYMENT_ACCOUNT)
				.build());

		return this;
	}

	public AnomalyHelper tryAdd195(BankAccountDAO bankAccountDAO, BankAccountEntity entity) {
		//3-  cerca tutti gli account validi e se trovi un duplicato (IBAN)
		List<BankAccountEntity> entitiesByIban = bankAccountDAO.findByIbanConcat(reqContext.getTenantId(),
				entity.getIban(), entity.getSwiftBic(), entity.getBicExtraSepa(),
				AbsoluteDate.of(LocalDate.now(appClock)).getValue());
		if (entitiesByIban.size() >= 2) {

			entitiesByIban
					.forEach(bankAccountEntity ->  {
						// accendi anomalia 915 (una per occorrenza)
						add195(bankAccountEntity.getId());
					});
		}
		return this;
	}

	public AnomalyHelper recalculate195(BankAccountDAO bankAccountDAO, BankAccountEntity entity) {

		List<BankAccountEntity> entitiesByIban = bankAccountDAO.findByIbanConcat(reqContext.getTenantId(),
				entity.getIban(), entity.getSwiftBic(), entity.getBicExtraSepa(),
				AbsoluteDate.of(LocalDate.now(appClock)).getValue());

		if (entitiesByIban.size() >= 2) {
			entitiesByIban.forEach(bankAccountEntity ->  {
				add195(bankAccountEntity.getId());
			});
		} else {
			entitiesByIban.forEach(bankAccountEntity ->  {
				expire195(bankAccountEntity.getId());
			});
		}

		return this;
	}

	// ATTO

	public AnomalyHelper expireAtto(Long accountId) {
		//4 spegnano tutte le anom di tipo ATTO per il bankAccount
		return expire(AnomalyRequest.builder()
				.setEntityCode(BANK_ACCOUNT_CODE)
				.setEntityId(String.valueOf(accountId))
				.setTypeCode(ANM_TYPE_ATTO)
				.setTypeGroupCode(ANM_GROUP_CODE_PAYMENT_DD)
				.build());
	}

	public AnomalyHelper tryExpireAtto(DocTypeRelationDAO docTypeRelationDAO, BankAccountDocumentDAO bankAccountDocumentDAO, Long accountId) {
		// try OFF ATTO - verifica presenza di TUTTI i documenti obbligatori
		String tenantId = reqContext.getTenantId();
		List<DocTypeRelationEntity> docTypeRelationEntities = docTypeRelationDAO.findByNamespace(tenantId, PAYMENT_MODULE);

		List<String> requiredDocDefs = docTypeRelationEntities.stream()
				.filter(ddt -> ddt.getFlRequired() > 0)
				.map(DocTypeRelationEntity::getDefinitionCode)
				.collect(Collectors.toList());

		if (requiredDocDefs.isEmpty()) {
			return expireAtto(accountId);
		} else {
			if (requiredDocDefs.stream()
					.noneMatch(defCode -> bankAccountDocumentDAO.countByDefinitionCodeAndAccountId(tenantId, defCode, accountId) == 0L)) {
				// TODO verify elapsed docs

				return expireAtto(accountId);
			}
		}

		return this;
	}

	public AnomalyHelper tryAddAtto(DocTypeRelationDAO docTypeRelationDAO, Long accountId) {
		//4-  se ci sono dd obbligatori, accendi ATTO
		List<DocTypeRelationEntity> docTypeRelationEntities = docTypeRelationDAO.findByNamespace(reqContext.getTenantId(), PAYMENT_MODULE);

		if (docTypeRelationEntities.stream().anyMatch(ddt -> ddt.getFlRequired() > 0)) {
			return addAtto(accountId);
		}

		return this;
	}

	public AnomalyHelper tryAddAtto(DocTypeRelationDAO docTypeRelationDAO, BankAccountDocumentDAO bankAccountDocumentDAO, Long accountId) {
		// try ON ATTO - verifica assenza documenti obbligatori
		String tenantId = reqContext.getTenantId();
		List<DocTypeRelationEntity> docTypeRelationEntities = docTypeRelationDAO.findByNamespace(tenantId, PAYMENT_MODULE);

		if (docTypeRelationEntities.stream()
				.filter(ddt -> ddt.getFlRequired() > 0)
				.map(DocTypeRelationEntity::getDefinitionCode)
				.anyMatch(defCode -> bankAccountDocumentDAO.countByDefinitionCodeAndAccountId(tenantId, defCode, accountId) == 0L)) {
			// TODO verify elapsed docs

			return addAtto(accountId);
		}

		return this;
	}

	public AnomalyHelper addAtto(Long accountId) {
		return add(AnomalyRequest.builder()
				.setEntityCode(BANK_ACCOUNT_CODE)
				.setEntityId(String.valueOf(accountId))
				.setTypeCode(ANM_TYPE_ATTO)
				.setTypeGroupCode(ANM_GROUP_CODE_PAYMENT_DD)
				.build());
	}

	public AnomalyHelper recalculateAtto(DocTypeRelationDAO docTypeRelationDAO, BankAccountDocumentDAO bankAccountDocumentDAO,
			DocumentService documentService, Long accountId) {
		// try ON ATTO - verifica assenza documenti obbligatori
		String tenantId = reqContext.getTenantId();

		OffsetDateTime now = OffsetDateTime.now(appClock);
		if (bankAccountDocumentDAO.findByAndAccountId(tenantId, accountId).stream()
				.map(BankAccountDocumentEntity::getDocumentId)
				.map(documentService::getDocumentFromId)
				.anyMatch(doc -> now.isAfter(doc.getValidTo()))) {
			return addAtto(accountId);
		}

		List<String> requiredDocDefs = docTypeRelationDAO.findByNamespace(tenantId, PAYMENT_MODULE).stream()
				.filter(ddt -> ddt.getFlRequired() > 0)
				.map(DocTypeRelationEntity::getDefinitionCode)
				.collect(Collectors.toList());

		if (requiredDocDefs.isEmpty()) {
			return expireAtto(accountId);
		} else {
			if (requiredDocDefs.stream()
					.anyMatch(defCode -> bankAccountDocumentDAO.countByDefinitionCodeAndAccountId(tenantId, defCode, accountId) == 0L)) {
				return addAtto(accountId);
			} else {
				return expireAtto(accountId);
			}
		}
	}

	// general

	public AnomalyHelper add(AnomalyRequest anomalyRequest) {
		toAdd.add(anomalyRequest);
		return this;
	}

	public AnomalyHelper expire(AnomalyRequest anomalyRequest) {
		toExpire.add(anomalyRequest);
		return this;
	}

	public void pushAnomalies() {
		if (!toExpire.isEmpty()) {
			if (!toAdd.isEmpty()) {
				toExpire.removeAll(toAdd);
			}
			anomalyClient.expire(this.reqContext.getLang(), this.reqContext.getUser(), new ArrayList<>(toExpire));
			log.debug("pushed anomalies to expire: {}", toExpire);
		}
		if (!toAdd.isEmpty()) {
			anomalyClient.add(this.reqContext.getLang(), this.reqContext.getUser(), new ArrayList<>(toAdd));
			log.debug("pushed anomalies to add: {}", toAdd);
		}
	}
}
