package com.abacogroup.ddm.heirs_special_case.api.req;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder(setterPrefix = "set")	
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(callSuper=true)
public class HeirCreateReq extends HeirUpdateReq {
	
	@Schema(description = "Heir's Cuaa", required = true)
	@NotNull
	private String heirCuaa;

}
