package com.abacogroup.ddm.doigt_quotas.api.repositories;

import com.abacogroup.ddm.common.core.cli.impl.TokenRelayStrategy;
import com.abacogroup.ddm.common.resources.ReqContext;
import jakarta.ws.rs.client.Invocation;
import jakarta.ws.rs.client.WebTarget;
import jakarta.ws.rs.core.Response;

public class DoIgtQuotaRepository {
    public static Response getQuotasByPartyId(WebTarget avepaLegacyWebTarget, ReqContext reqContext, Long partyId, String nextKey, Integer pageSize) {
        WebTarget path = avepaLegacyWebTarget
                .path(reqContext.getTenantId())
                .path("public/v1/doigt-quotes")
                .path(String.valueOf(partyId))
                .queryParam("next_key", nextKey);

        if (pageSize != null) {
            path = path.queryParam("page_size", pageSize);
        }

        Invocation.Builder builder = addAuthorizationHeader(path, reqContext);

        return builder.get();
    }

    private static Invocation.Builder addAuthorizationHeader(WebTarget webTarget, ReqContext reqContext) {
        TokenRelayStrategy authorizationStrategy = new TokenRelayStrategy();
        return webTarget.request()
                .header("Authorization", authorizationStrategy.getAuthorization(reqContext.getUser()));
    }

}
