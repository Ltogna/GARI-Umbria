package com.abacogroup.ddm.common.resources;

public interface ResourceConstants {
	int PAGE_SIZE = 10;

	String API_PRIV = "/{tenant}/api-priv/v1";

	String PAYMENT_MODULE_API_PRIV = API_PRIV + "/payment-methods";
	
	String VINE_AUTH_MODULE_API_PRIV = API_PRIV + "/vine-auth";

	String APTITUDES_MODULE_API_PRIV = API_PRIV + "/vine-aptitudes";

	String DOIGT_QUOTAS_MODULE_API_PRIV = API_PRIV + "/doigt-quotas";

	String HEIRS_MODULE_API_PRIV = API_PRIV + "/heirs-methods";

	Integer DEFAULT_PAGE_SIZE = 50;
}
