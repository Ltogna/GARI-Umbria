package com.abacogroup.ddm.core.impl;

import java.time.Duration;

import com.abacogroup.ddm.common.resources.ReqContext;
import com.abacogroup.ddm.core.PartyService;
import com.abacogroup.ddm.core.exceptions.BankAccountException;
import com.abacogroup.ddm.core.exceptions.BankAccountException.ErrEnum;
import com.abacogroup.ddm.core.exceptions.HeirException;
import com.abacogroup.ddm.heirs_special_case.api.PartyCacheData;
import com.abacogroup.partyregistry.api.v1.PartyResponseV1;
import com.abacogroup.partyregistry.core.cli.v1.PartyClientV1;
import com.github.benmanes.caffeine.cache.Cache;
import com.github.benmanes.caffeine.cache.Caffeine;

import jakarta.ws.rs.InternalServerErrorException;
import jakarta.ws.rs.ServerErrorException;
import jakarta.ws.rs.WebApplicationException;
import jakarta.ws.rs.core.Response.Status;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class PartyServiceImpl implements PartyService {

	private final PartyClientV1 partyClient;

	private Cache<String, PartyCacheData> partyCache;

	public PartyServiceImpl(PartyClientV1 partyClient) {
		this.partyClient = partyClient;

		partyCache =  Caffeine.newBuilder()
				.maximumSize(1000)
				.expireAfterWrite(Duration.ofMinutes(60))
				.build();	
	}

	@Override
	public void validatePartyId(ReqContext reqContext, Long partyId) {
		try {
			PartyResponseV1 party = partyClient.getById(reqContext.getLang(), reqContext.getUser(), partyId);

			if (null == party) {
				throw new BankAccountException(ErrEnum.INVALID_PARTY,
						String.format("no party found with id '%s' and tenant '%s'", partyId, reqContext.getTenantId()));
			}

			log.trace("party {} loaded", party.getId());
		} catch (BankAccountException bae) {
			throw bae;
		} catch (WebApplicationException wae) {
			if (wae.getResponse().getStatus() == 204 || wae.getResponse().getStatus() >= 400 && wae.getResponse().getStatus() < 500) {
				String requestMsg;
				try {
					requestMsg = wae.getResponse().readEntity(String.class);
				} catch (Exception e) {
					requestMsg = "bad request";
				}
				String msg = String.format("cannot fetch party with id '%s' and tenant '%s' from party registry: %s",
						partyId, reqContext.getTenantId(), requestMsg);
				log.error(msg, wae);
				throw new BankAccountException(ErrEnum.INVALID_PARTY, msg);
			} else {
				String msg = String.format("cannot fetch party with id '%s' and tenant '%s' due party registry error: %s", partyId, reqContext.getTenantId(), wae.getMessage());
				log.error(msg, wae);
				throw new ServerErrorException(msg, Status.BAD_GATEWAY, wae);
			}
		} catch (Exception e) {
			String msg = String.format("cannot fetch party with id '%s' and tenant '%s': %s", partyId, reqContext.getTenantId(), e.getMessage());
			log.error(msg, e);
			throw new InternalServerErrorException(msg, e);
		}
	}

	@Override
	public PartyCacheData getPartyByCuaa(ReqContext reqContext, String cuaa) {
		String key = reqContext.getTenantId() + cuaa;

		PartyCacheData partyCacheData = partyCache.getIfPresent(key);

		if (partyCacheData == null) {
			partyCacheData = loadPartyByCuaa(reqContext, cuaa);
			partyCache.put(key, partyCacheData);
		}

		return partyCacheData;

	}

	private PartyCacheData loadPartyByCuaa(ReqContext reqContext, String cuaa) {
		PartyResponseV1 party = partyClient.getByCode(reqContext.getLang(), reqContext.getUser(), cuaa);
		if (null == party) {
			throw new HeirException(HeirException.ErrEnum.INVALID_PARTY,
					String.format("no party found with cuaa '%s' and tenant '%s'", cuaa, reqContext.getTenantId()));
		}
		
		return PartyCacheData.builder()
				.setId(party.getId())
				.setLastName(party.getLastName())
				.setFirstName(party.getFirstName())
				.setTaxCode(party.getTaxCode())
				.setVatNumber(party.getVatNumber())
				.setCode(party.getCode())
				.setBirthDate(party.getBirthDate())
				.build();
	}

}
