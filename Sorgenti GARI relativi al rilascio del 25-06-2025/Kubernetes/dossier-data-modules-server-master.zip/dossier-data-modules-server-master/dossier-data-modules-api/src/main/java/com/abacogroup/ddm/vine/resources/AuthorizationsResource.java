package com.abacogroup.ddm.vine.resources;

import com.abacogroup.ddm.common.resources.ReqContext;
import com.abacogroup.ddm.common.resources.ResourceConstants;
import com.abacogroup.ddm.vine.api.services.AuthorizationService;
import com.abacogroup.dropwizard.auth.sso2.User;
import com.codahale.metrics.annotation.Timed;

import io.dropwizard.auth.Auth;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.annotation.security.RolesAllowed;
import jakarta.validation.constraints.NotNull;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DefaultValue;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.HeaderParam;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

@Path(ResourceConstants.VINE_AUTH_MODULE_API_PRIV)
@Tag(name = "Vine authorizations")
@Timed
@RolesAllowed({ "DDM_DOSSIER|VIEWER" })
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
public class AuthorizationsResource {
    private final AuthorizationService authorizationService;

    public AuthorizationsResource(AuthorizationService authorizationService) {
        this.authorizationService = authorizationService;
    }

    @GET
    @Path("/{partyId}")
    @Operation(description = "Returns the list of authorizations grouped by authorizationType and filtered by partyId", summary = "")
    @ApiResponse(description = "The list of authorizations grouped by authorizationType and filtered by partyId - if nothing found list will be empty", content = @Content(mediaType = MediaType.APPLICATION_JSON), useReturnTypeSchema = true)
    public Response getAuthorizationsGroupedByType(
            @HeaderParam("accept-language") @DefaultValue("en") String lang,
            @Parameter(hidden = true) @Auth User user,
            @Parameter(description = "Current Tenant") @PathParam("tenant") String tenantId,
            @Parameter(description = "Next key used for infinite pagination") @QueryParam("nextKey") String nextKey,
            @Parameter(description = "The Party Id") @PathParam("partyId") Long partyId) {

        ReqContext reqContext = new ReqContext(user, lang);
        return authorizationService.getAuthorizationsGroupedByType(reqContext, partyId, nextKey);
    }

    @GET
    @Path("/{partyId}/{auth_type_code}")
    @Operation(description = "Returns the list of authorizations by authorizationTypeCode and partyId")
    @ApiResponse(description = "The list of authorizations by authorizationTypeCode and partyId - if nothing found list will be empty", content = @Content(mediaType = MediaType.APPLICATION_JSON), useReturnTypeSchema = true)
    public Response getAuthorizationsByPartyId(
            @HeaderParam("accept-language") @DefaultValue("en") String lang,
            @Parameter(hidden = true) @Auth User user,
            @Parameter(description = "Current Tenant") @PathParam("tenant") String tenantId,
            @Parameter(description = "Next key used for infinite pagination") @QueryParam("nextKey") String nextKey,
            @Parameter(description = "The Authorization Type") @NotNull @PathParam("auth_type_code") String authorizationTypeCode,
            @Parameter(description = "If API need to include expired authorizations") @QueryParam("includeExpired") Boolean includeExpired,
            @Parameter(description = "The Party id") @PathParam("partyId") Long partyId) {

        ReqContext reqContext = new ReqContext(user, lang);
        return authorizationService.getAuthorizationsByPartyIdAndType(reqContext, partyId, authorizationTypeCode, includeExpired, nextKey);
    }

    @GET
    @Path("/{partyId}/authorization/{id}")
    @Operation(description = "The authorization with the given id, if it exists. It will return 404 if the authorization doesn't exists")
    @ApiResponse(description = "The list of authorizations - if nothing found list will be empty")
    public Response getAuthorizationById(
            @HeaderParam("accept-language") @DefaultValue("en") String lang,
            @Parameter(description = "Current Tenant") @PathParam("tenant") String tenant,
            @Parameter(description = "The Authorization Id to be returned, if it exists") @PathParam("id") Long id,
            @Parameter(description = "The Party id") @NotNull @PathParam("partyId") Long partyId,
            @Parameter(hidden = true) @Auth User user) {
        ReqContext reqContext = new ReqContext(user, lang);
        return authorizationService.getAuthorizationById(reqContext, id, partyId);
    }
}
