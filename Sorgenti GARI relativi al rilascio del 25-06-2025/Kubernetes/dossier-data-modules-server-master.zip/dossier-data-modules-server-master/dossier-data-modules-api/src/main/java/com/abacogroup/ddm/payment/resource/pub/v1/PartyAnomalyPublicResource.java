package com.abacogroup.ddm.payment.resource.pub.v1;

import static com.abacogroup.ddm.resources.PublicResourceConstants.PAYMENT_MODULE_API_V1_PUB;

import com.abacogroup.ddm.api.DdmAnomaliesRes;
import com.abacogroup.ddm.api.v1.DdmAnomaliesResponseV1;
import com.abacogroup.ddm.common.resources.ReqContext;
import com.abacogroup.ddm.core.exceptions.BankAccountException;
import com.abacogroup.ddm.payment.core.BulkAnomalyRecalculationService;
import com.abacogroup.ddm.payment.core.PartyAnomalyService;
import com.abacogroup.ddm.payment.resource.pub.mapper.DdmAnomaliesResponseMapper;
import com.abacogroup.dropwizard.auth.sso2.User;
import io.dropwizard.auth.Auth;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import io.swagger.v3.oas.annotations.tags.Tags;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DefaultValue;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.HeaderParam;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

@Path(PAYMENT_MODULE_API_V1_PUB + "/parties/{partyId}/anomalies")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
@Tags({
		@Tag(name = "Party anomalies PUBLIC", description = "Operations on Party anomalies"),
		@Tag(name = "Bank Accounts PUBLIC"),
		@Tag(name = "v1")
})
public class PartyAnomalyPublicResource {

	private final BulkAnomalyRecalculationService bulkAnomalyRecalculationService;
	private final PartyAnomalyService partyAnomalyService;

	public PartyAnomalyPublicResource(BulkAnomalyRecalculationService bulkAnomalyRecalculationService, PartyAnomalyService partyAnomalyService) {
		this.bulkAnomalyRecalculationService = bulkAnomalyRecalculationService;
		this.partyAnomalyService = partyAnomalyService;
	}


	@PUT
	@Path("/")
	@Operation(description = "recalculate all anomalies on party payment method and its bank accounts", summary = "recalculate anomalies")
	@ApiResponse(responseCode = "204", description = "recalculated")
	@ApiResponse(responseCode = "400", description = "party not found", content = @Content(mediaType = MediaType.APPLICATION_JSON,
			schema = @Schema(implementation = BankAccountException.ErrorBody.class)))
	public Response recalculateAnomalies(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "tenant id") @PathParam("tenant") String tenantId,
			@Parameter(description = "party id") @PathParam("partyId") Long partyId) {

		ReqContext reqContext = new ReqContext(user, lang);
		bulkAnomalyRecalculationService.recalculate(reqContext, partyId);

		return Response.noContent().build();
	}

	@GET
	@Path("/")
	@Operation(description = "Get the list of bank account anomalies on party", summary = "party anomalies")
	@ApiResponse(responseCode = "200", description = "anomalies grouped by level",
			content = @Content(mediaType = MediaType.APPLICATION_JSON), useReturnTypeSchema = true)
//	@ApiResponse(responseCode = "400", description = "party not found", content = @Content(mediaType = MediaType.APPLICATION_JSON,
//			schema = @Schema(implementation = DossierDataModulesException.ErrorBody.class)))
	public DdmAnomaliesResponseV1 getAnomalies(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "tenant id") @PathParam("tenant") String tenantId,
			@Parameter(description = "party id") @PathParam("partyId") Long partyId) {
			//@Parameter(description = "reference date", schema = @Schema(format = AbsoluteDate.DATE_PATTERN))
			//@PathParam("referenceDate") @Size(min = 8, max = 8) String referenceDate) {

		ReqContext reqContext = new ReqContext(user, lang);
		DdmAnomaliesRes anomalies = partyAnomalyService.getAnomalies(reqContext, partyId);
		return DdmAnomaliesResponseMapper.INSTANCE.toResponseV1(anomalies);
	}

}
