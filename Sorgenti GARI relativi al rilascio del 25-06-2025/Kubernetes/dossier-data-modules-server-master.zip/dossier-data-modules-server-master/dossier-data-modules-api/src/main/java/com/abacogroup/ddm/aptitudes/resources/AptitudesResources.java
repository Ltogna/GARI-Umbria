package com.abacogroup.ddm.aptitudes.resources;

import com.abacogroup.ddm.aptitudes.api.services.AptitudeServices;
import com.abacogroup.ddm.common.resources.ReqContext;
import com.abacogroup.ddm.common.resources.ResourceConstants;
import com.abacogroup.dropwizard.auth.sso2.User;
import com.codahale.metrics.annotation.Timed;

import io.dropwizard.auth.Auth;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.annotation.security.RolesAllowed;
import jakarta.validation.constraints.NotNull;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DefaultValue;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.HeaderParam;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

@Path(ResourceConstants.APTITUDES_MODULE_API_PRIV)
@Tag(name = "Vine aptitudes")
@Timed
@RolesAllowed({ "DDM_DOSSIER|VIEWER" })
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
public class AptitudesResources {
    private final AptitudeServices aptitudeServices;

    public AptitudesResources(AptitudeServices aptitudeServices) {
        this.aptitudeServices = aptitudeServices;
    }

    @GET
    @Path("/{partyId}/summary/aptitudes/{referenceDate}")
    @Operation(description = "Returns the list of VineAptitudes grouped by Vine Code and filtered by partyId", summary = "")
    @ApiResponse(description = "The list of VineAptitudes grouped by Vine Code and filtered by partyId - if nothing found list will be empty", content = @Content(mediaType = MediaType.APPLICATION_JSON), useReturnTypeSchema = true)
    public Response getAptitudesGroupedByVineCode(
            @HeaderParam("accept-language") @DefaultValue("en") String lang,
            @Parameter(hidden = true) @Auth User user,
            @Parameter(description = "Current Tenant") @PathParam("tenant") String tenantId,
            @Parameter(description = "Reference Date") @PathParam("referenceDate") String referenceDate,
            @Parameter(description = "Next key used for infinite pagination") @QueryParam("nextKey") String nextKey,
            @Parameter(description = "The Party Id") @PathParam("partyId") Long partyId) {
        ReqContext reqContext = new ReqContext(user, lang);

        return aptitudeServices.getAptitudesGroupedByVineCode(reqContext, referenceDate, partyId, nextKey);
    }

    @GET
    @Path("/{partyId}/summary/aptitudes/{referenceDate}/{doigt_code}")
    @Operation(description = "Returns the list of VineAptitudes by Vine Code and partyId")
    @ApiResponse(description = "The list of VineAptitudes by Vine Code and partyId - if nothing found list will be empty", content = @Content(mediaType = MediaType.APPLICATION_JSON), useReturnTypeSchema = true)
    public Response getAllAptitudesByPartyId(
            @HeaderParam("accept-language") @DefaultValue("en") String lang,
            @Parameter(hidden = true) @Auth User user,
            @Parameter(description = "Current Tenant") @PathParam("tenant") String tenantId,
            @Parameter(description = "Next key used for infinite pagination") @QueryParam("nextKey") String nextKey,
            @Parameter(description = "DoIgt Code") @NotNull @PathParam("doigt_code") String doIgtCode,
            @Parameter(description = "Reference Date") @PathParam("referenceDate") String referenceDate,
            @Parameter(description = "The Party id") @PathParam("partyId") Long partyId) {
        ReqContext reqContext = new ReqContext(user, lang);

        return aptitudeServices.getAllAptitudesByPartyId(reqContext, referenceDate, partyId, doIgtCode, nextKey);
    }

    @GET
    @Path("/aptitude/{referenceDate}/{parcelId}/land-covers/{landCoversId}/units/vine-unit/{vineUnitId}/aptitudes/{vineAptitudeId}")
    @Operation(description = "Returns the list of VineAptitudes by Vine Code and partyId")
    @ApiResponse(description = "The list of VineAptitudes by Vine Code and partyId - if nothing found list will be empty", content = @Content(mediaType = MediaType.APPLICATION_JSON), useReturnTypeSchema = true)
    public Response getAptitudeById(
            @HeaderParam("accept-language") @DefaultValue("en") String lang,
            @Parameter(description = "Current Tenant") @PathParam("tenant") String tenant,
            @Parameter(description = "The Authorization Id to be returned, if it exists") @PathParam("id") Long id,
            @Parameter(description = "Reference Date") @PathParam("referenceDate") String referenceDate,
            @Parameter(description = "Parcel Id") @NotNull @PathParam("parcelId") Long parcelId,
            @Parameter(description = "Land Covers id") @NotNull @PathParam("landCoversId") Long landCoversId,
            @Parameter(description = "Vine Unit Id") @NotNull @PathParam("vineUnitId") Long vineUnitId,
            @Parameter(description = "Vine Aptitude id") @NotNull @PathParam("vineAptitudeId") Long vineAptitudeId,
            @Parameter(hidden = true) @Auth User user) {
        ReqContext reqContext = new ReqContext(user, lang);

        return aptitudeServices.getAptitudeById(reqContext, referenceDate, parcelId, landCoversId, vineUnitId, vineAptitudeId);
    }

}
