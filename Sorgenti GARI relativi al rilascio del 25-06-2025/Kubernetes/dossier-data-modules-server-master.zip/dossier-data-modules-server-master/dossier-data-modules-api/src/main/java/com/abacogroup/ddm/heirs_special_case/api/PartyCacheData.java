package com.abacogroup.ddm.heirs_special_case.api;

import com.abacogroup.jdbi.datatype.AbsoluteDate;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder(setterPrefix = "set")
@NoArgsConstructor
@AllArgsConstructor
public class PartyCacheData {

	private Long id;
	private String lastName;
	private String firstName;
	private String taxCode;
	private String vatNumber;
	private String code;
	private AbsoluteDate birthDate;

}
