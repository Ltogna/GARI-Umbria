package com.abacogroup.ddm.payment.resource;

import java.util.Map;

import com.abacogroup.ddm.common.resources.ReqContext;
import com.abacogroup.ddm.common.resources.ResourceConstants;
import com.abacogroup.ddm.core.exceptions.BankAccountException;
import com.abacogroup.ddm.core.exceptions.InvalidDocumentException;
import com.abacogroup.ddm.payment.api.BankAccountDocumentRes;
import com.abacogroup.ddm.payment.api.req.BankAccountDocumentSearchReq;
import com.abacogroup.ddm.payment.core.BankAccountDocumentService;
import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.dynamicdocuments.bean.Document;
import com.abacogroup.dynamicdocuments.bean.InsertDocument;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.codahale.metrics.annotation.Timed;

import io.dropwizard.auth.Auth;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.annotation.security.RolesAllowed;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import jakarta.ws.rs.BeanParam;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.DefaultValue;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.HEAD;
import jakarta.ws.rs.HeaderParam;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

@Path(ResourceConstants.PAYMENT_MODULE_API_PRIV + "/parties/{partyId}/accounts/{accountId}/documents")
@Tag(name = "Bank Account documents", description = "Operations on bank account documents")
@Timed
@RolesAllowed({ "DDM_PAYMENT_METHODS|EDITOR", "DDM_PAYMENT_METHODS|VIEWER" })
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
public class BankAccountDocumentResource {

    private final BankAccountDocumentService bankAccountDocumentService;

    public BankAccountDocumentResource(BankAccountDocumentService bankAccountDocumentService) {
        this.bankAccountDocumentService = bankAccountDocumentService;
    }

    @GET
    @Path("")
    @Operation(summary = "Infinite list of documents", description = "Get list of documents filtered with criteria")
    @ApiResponse(responseCode = "200", description = "Successfully, returns a list of documents (sorted/filtered)", useReturnTypeSchema = true)
    @ApiResponse(responseCode = "400", description = "bank account not found", content = @Content(mediaType = MediaType.APPLICATION_JSON, schema = @Schema(implementation = BankAccountException.ErrorBody.class)))
    public InfiniteListResults<BankAccountDocumentRes> search(
            @HeaderParam("accept-language") @DefaultValue("en") String lang,
            @Parameter(hidden = true) @Auth User user,
            @PathParam("tenant") String tenantId,
            @Parameter(description = "party ID") @PathParam("partyId") Long partyId,
            @Parameter(description = "account ID") @PathParam("accountId") Long accountId,
            @Parameter(description = "Next key used for infinite pagination") @QueryParam("nextKey") String nextKey,
            @BeanParam BankAccountDocumentSearchReq searchReq) {

        ReqContext reqContext = new ReqContext(user, lang);
        return bankAccountDocumentService.search(reqContext, partyId, accountId, searchReq, nextKey);
    }

    @GET
    @Path("/{documentId}")
    @Operation(summary = "Find document by code and id", description = "Returns document based on its definition code and document id")
    @ApiResponse(responseCode = "200", description = "Document successfully found", useReturnTypeSchema = true)
    @ApiResponse(responseCode = "400", description = "The document does not exist", content = @Content(mediaType = MediaType.APPLICATION_JSON, schema = @Schema(anyOf = {
            BankAccountException.ErrorBody.class,
            InvalidDocumentException.ErrorBody.class
    })))
    public BankAccountDocumentRes getByDocumentId(
            @HeaderParam("accept-language") @DefaultValue("en") String lang,
            @Parameter(hidden = true) @Auth User user,
            @PathParam("tenant") String tenantId,
            @Parameter(description = "party ID") @PathParam("partyId") Long partyId,
            @Parameter(description = "account ID") @PathParam("accountId") Long accountId,
            @Parameter(description = "document ID") @PathParam("documentId") Long documentId) {
        ReqContext reqContext = new ReqContext(user, lang);
        return this.bankAccountDocumentService.getBankAccountDocument(reqContext, partyId, accountId, documentId);
    }

    @GET
    @Consumes(MediaType.WILDCARD)
    @Produces(MediaType.APPLICATION_OCTET_STREAM)
    @Path("/{documentId}/attachments/{bucket}/{fileId}")
    @Operation(summary = "get document attachment content", description = "Returns document attachment content")
    @ApiResponse(responseCode = "200", description = "The file bytes", content = @Content(mediaType = MediaType.APPLICATION_OCTET_STREAM, schema = @Schema(type = "string", format = "binary")))
    @ApiResponse(responseCode = "400", description = "The document does not exist", content = @Content(mediaType = MediaType.APPLICATION_JSON, schema = @Schema(anyOf = {
            BankAccountException.ErrorBody.class,
            InvalidDocumentException.ErrorBody.class
    })))
    public Response getDocumentFileContent(
            @HeaderParam("accept-language") @DefaultValue("en") String lang,
            @Parameter(hidden = true) @Auth User user,
            @PathParam("tenant") String tenantId,
            @Parameter(description = "party ID") @PathParam("partyId") Long partyId,
            @Parameter(description = "account ID") @PathParam("accountId") Long accountId,
            @Parameter(description = "document ID") @PathParam("documentId") Long documentId,
            @PathParam("bucket") String bucket,
            @PathParam("fileId") String fileId) {
        ReqContext reqContext = new ReqContext(user, lang);
        return bankAccountDocumentService.getDocumentFileContent(reqContext, partyId, accountId, documentId, fileId);
    }

    @HEAD
    @Path("/{documentId}/attachments/{bucket}/{fileId}")
    @Operation(summary = "get document attachment metadata", description = "Returns document attachment metadata in header")
    @ApiResponse(responseCode = "200", description = "The file metadata in header")
    @ApiResponse(responseCode = "400", description = "The document does not exist", content = @Content(mediaType = MediaType.APPLICATION_JSON, schema = @Schema(anyOf = {
            BankAccountException.ErrorBody.class,
            InvalidDocumentException.ErrorBody.class
    })))
    public Response getDocumentFileMetadata(
            @HeaderParam("accept-language") @DefaultValue("en") String lang,
            @Parameter(hidden = true) @Auth User user,
            @PathParam("tenant") String tenantId,
            @Parameter(description = "party ID") @PathParam("partyId") Long partyId,
            @Parameter(description = "account ID") @PathParam("accountId") Long accountId,
            @Parameter(description = "document ID") @PathParam("documentId") Long documentId,
            @PathParam("bucket") String bucket,
            @PathParam("fileId") String fileId) {
        ReqContext reqContext = new ReqContext(user, lang);
        return bankAccountDocumentService.getDocumentFileMetadata(reqContext, partyId, accountId, documentId, fileId);
    }

    @POST
    @Path("")
    @RolesAllowed("DDM_PAYMENT_METHODS|EDITOR")
    @Operation(summary = "Create document", description = "Insert a new document")
    @ApiResponse(responseCode = "200", description = "Successfully, the document has been correctly created", useReturnTypeSchema = true)
    @ApiResponse(responseCode = "400", description = "document insert error", content = @Content(mediaType = "application/json", schema = @Schema(anyOf = {
            InvalidDocumentException.ErrorBody.class,
            BankAccountException.ErrorBody.class })))
    public BankAccountDocumentRes insert(
            @HeaderParam("accept-language") @DefaultValue("en") String lang,
            @Parameter(hidden = true) @Auth User user,
            @PathParam("tenant") String tenantId,
            @Parameter(description = "party ID") @PathParam("partyId") Long partyId,
            @Parameter(description = "account ID") @PathParam("accountId") Long accountId,
            @NotNull @Valid InsertDocument document) {
        ReqContext reqContext = new ReqContext(user, lang);
        return bankAccountDocumentService.insert(reqContext, partyId, accountId, document);
    }

    @Operation(summary = "update document", description = "update an existing document")
    @ApiResponse(responseCode = "200", description = "document updated", useReturnTypeSchema = true)
    @ApiResponse(responseCode = "400", description = "document update error", content = @Content(mediaType = "application/json", schema = @Schema(anyOf = {
            InvalidDocumentException.ErrorBody.class,
            BankAccountException.ErrorBody.class })))
    @PUT
    @Path("/{documentId}")
    @RolesAllowed("DDM_PAYMENT_METHODS|EDITOR")
    public BankAccountDocumentRes update(
            @HeaderParam("accept-language") @DefaultValue("en") String lang,
            @Parameter(hidden = true) @Auth User user,
            @PathParam("tenant") String tenantId,
            @Parameter(description = "party ID") @PathParam("partyId") Long partyId,
            @Parameter(description = "account ID") @PathParam("accountId") Long accountId,
            @PathParam("documentId") Long documentId,
            @NotNull @Valid Document updateReq) {
        ReqContext reqContext = new ReqContext(user, lang);
        return this.bankAccountDocumentService.update(reqContext, partyId, accountId, documentId, updateReq);
    }

    @DELETE
    @Path("/{documentId}")
    @RolesAllowed("DDM_PAYMENT_METHODS|EDITOR")
    @Operation(summary = "delete document", description = "delete an existing document by expiring it")
    @ApiResponse(responseCode = "200", description = "document expired")
    @ApiResponse(responseCode = "400", description = "document delete error", content = @Content(mediaType = "application/json", schema = @Schema(anyOf = {
            InvalidDocumentException.ErrorBody.class,
            BankAccountException.ErrorBody.class
    })))
    public Response delete(
            @HeaderParam("accept-language") @DefaultValue("en") String lang,
            @Parameter(hidden = true) @Auth User user,
            @PathParam("tenant") String tenantId,
            @Parameter(description = "party ID") @PathParam("partyId") Long partyId,
            @Parameter(description = "account ID") @PathParam("accountId") Long accountId,
            @PathParam("documentId") Long documentId) {
        ReqContext reqContext = new ReqContext(user, lang);
        this.bankAccountDocumentService.expire(reqContext, partyId, accountId, documentId);
        return Response.ok(Map.of()).build();
    }

}
