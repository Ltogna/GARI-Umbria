package com.abacogroup.ddm.payment.api;

import com.abacogroup.ddm.api.DdmAnomaliesRes;
import lombok.AllArgsConstructor;
import lombok.Builder.Default;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.experimental.SuperBuilder;

@Data
@EqualsAndHashCode(callSuper = true)
@ToString(callSuper = true)
@SuperBuilder(setterPrefix = "set")
@NoArgsConstructor
@AllArgsConstructor
public class BankAccountSearchRes extends BankAccountRes {

	@Default
	private DdmAnomaliesRes anomalies = new DdmAnomaliesRes();

}
