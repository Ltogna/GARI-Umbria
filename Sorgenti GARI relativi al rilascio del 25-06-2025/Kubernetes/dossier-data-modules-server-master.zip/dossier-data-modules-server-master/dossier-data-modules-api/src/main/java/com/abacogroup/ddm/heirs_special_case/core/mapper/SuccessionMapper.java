package com.abacogroup.ddm.heirs_special_case.core.mapper;

import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import com.abacogroup.ddm.db.ntt.SuccessionConfigEntity;
import com.abacogroup.ddm.heirs_special_case.api.AttachmentTypeRes;
import com.abacogroup.ddm.heirs_special_case.api.SuccessionTypeRes;
import com.abacogroup.ddm.heirs_special_case.db.ntt.SuccessionTypeEntity;

@Mapper
public interface SuccessionMapper {

	SuccessionMapper INSTANCE = Mappers.getMapper(SuccessionMapper.class);

	@InheritInverseConfiguration
	SuccessionTypeRes entityToRes(SuccessionTypeEntity entity);
	
	@InheritInverseConfiguration
	@Mapping(target = "code", source = "attachmentType")
	@Mapping(target = "description", source = "attachmentTypeDescription")
	AttachmentTypeRes configEntityToAttachmentRes(SuccessionConfigEntity entity);

}
