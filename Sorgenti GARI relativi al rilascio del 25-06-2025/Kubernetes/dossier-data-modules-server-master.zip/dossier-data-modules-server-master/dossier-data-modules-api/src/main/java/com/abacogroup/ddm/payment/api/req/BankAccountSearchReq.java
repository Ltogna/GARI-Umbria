package com.abacogroup.ddm.payment.api.req;

import com.abacogroup.ddm.common.resources.ReqContext;
import com.abacogroup.ddm.common.resources.ResourceConstants;
import com.abacogroup.ddm.common.resources.req.BaseSearchReq;
import com.abacogroup.ddm.payment.api.BankNetworkEnum;
import com.abacogroup.ddm.payment.api.v1.req.ActiveEnum;
import com.abacogroup.jdbi.criteria.Criteria;
import com.abacogroup.jdbi.criteria.CriteriaBuilder;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.jdbi.orderby.OrderBy;
import com.abacogroup.jdbi.orderby.OrderByBuilder;
import com.abacogroup.jdbi.orderby.OrderByElement;
import com.abacogroup.jdbi.orderby.SortDirection;
import com.fasterxml.jackson.annotation.JsonIgnore;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotNull;
import jakarta.ws.rs.DefaultValue;
import jakarta.ws.rs.QueryParam;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;
import org.apache.commons.lang3.StringUtils;

@Data
@NoArgsConstructor
@Accessors(chain = true)
public class BankAccountSearchReq implements BaseSearchReq {

	@NotNull
	@Parameter(in = ParameterIn.QUERY, description = "Visualizzazione Conti Correnti (obbligatorio)")
	@DefaultValue("all")
	@QueryParam("active")
	private ActiveEnum active = ActiveEnum.all;

	@Parameter(in = ParameterIn.QUERY, description = "IBAN/Numero Conto (facoltativo)")
	@QueryParam("iban")
	private String iban;

	@Parameter(in = ParameterIn.QUERY, description = "Area/Rete (facoltativo)")
	@QueryParam("network")
	private BankNetworkEnum network;

	@Parameter(in = ParameterIn.QUERY, description = "Descrizione")
	@QueryParam("description")
	private String description;

	@Override
	@JsonIgnore
	@Schema(hidden = true)
	public int getPageSize() {
		return ResourceConstants.PAGE_SIZE;
	}

	@Deprecated
	@JsonIgnore
	@Schema(hidden = true)
	@Override
	public Criteria getCriteria(ReqContext reqContext) {
		return getCriteria(AbsoluteDate.of(LocalDateTime.now()));
	}

	@JsonIgnore
	@Schema(hidden = true)
	public Criteria getCriteria(AbsoluteDate referenceDate) {
		List<Criteria> specs = new ArrayList<>();

		Optional.of(getActive())
				.ifPresent(v -> {
							switch (v) {
//							case all:
//								break;
							case not_active:
								specs.add(CriteriaBuilder.string("day_to").le(referenceDate.getValue()));
								break;
							case only_active:
								specs.add(CriteriaBuilder.string("day_to").gt(referenceDate.getValue()));
								specs.add(CriteriaBuilder.string("day_from").le(referenceDate.getValue()));
								break;
							}
						});

		Optional.ofNullable(getIban())
				.map(StringUtils::trimToNull)
				.map(StringUtils::upperCase)
				.ifPresent(v -> specs.add(CriteriaBuilder.string("UPPER(iban)").contains(v)));

		Optional.ofNullable(getNetwork())
				.map(Objects::toString)
				.ifPresent(v -> specs.add(CriteriaBuilder.string("network").eq(v)));

		Optional.ofNullable(getDescription())
				.map(StringUtils::trimToNull)
				.ifPresent(v -> specs.add(CriteriaBuilder.string("description").caseInsensitiveContains(v)));


		return CriteriaBuilder.and(specs.toArray(new Criteria[0]));
	}

	@Override
	@JsonIgnore
	@Schema(hidden = true)
	public OrderByElement getSort() {
		return OrderByBuilder
				.field("day_from")
				.direction(SortDirection.ASC);
	}

	@JsonIgnore
	@Schema(hidden = true)
	public OrderBy getSortList() {
		return OrderByBuilder.from(
				OrderByBuilder
						.field("fl_default")
						.direction(SortDirection.DESC),
				OrderByBuilder
						.field("day_from")
						.direction(SortDirection.ASC),
				OrderByBuilder
						.field("id")
						.direction(SortDirection.ASC)
		);

	}


}
