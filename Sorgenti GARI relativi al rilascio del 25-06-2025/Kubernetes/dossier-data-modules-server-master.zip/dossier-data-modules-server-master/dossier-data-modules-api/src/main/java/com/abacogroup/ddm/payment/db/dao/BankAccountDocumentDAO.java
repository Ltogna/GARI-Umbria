package com.abacogroup.ddm.payment.db.dao;

import com.abacogroup.ddm.common.resources.ReqContext;
import com.abacogroup.ddm.payment.api.BankAccountDocumentRes;
import com.abacogroup.ddm.payment.db.ntt.BankAccountDocumentEntity;
import com.abacogroup.jdbi.EnhancedSqlObject;
import com.abacogroup.jdbi.criteria.BindCriteria;
import com.abacogroup.jdbi.criteria.Criteria;
import com.abacogroup.jdbi.orderby.DefineOrder;
import com.abacogroup.jdbi.orderby.OrderBy;
import java.util.List;
import java.util.Optional;
import org.jdbi.v3.core.result.ResultIterator;
import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.customizer.BindBean;
import org.jdbi.v3.sqlobject.statement.GetGeneratedKeys;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;
import org.jdbi.v3.sqlobject.transaction.Transactional;

public interface BankAccountDocumentDAO extends Transactional<BankAccountDocumentDAO>, EnhancedSqlObject {

	String FIELDS = " gd.pkid, gd.bank_account_id, gd.definition_code, gd.document_id, gd.dt_insert, gd.user_id_insert, gd.dt_delete, gd.user_id_delete\n";

	String CURRENT_RECORD = " AND (§current_timestamp§ between gd.dt_insert and gd.dt_delete) ";

	@SqlQuery("select " + FIELDS
			+ " FROM ddm_bank_account_documents gd "
			+ " join ddm_bank_account g on g.id = gd.bank_account_id "
			+ " where gd.bank_account_id = :accountId "
			+ " and g.tenant_id = :tenantId "
			+ " and <criteria> "
			+ CURRENT_RECORD
			+ " ORDER BY <orderBy> ")
	@RegisterBeanMapper(BankAccountDocumentRes.class)
	ResultIterator<BankAccountDocumentRes> search(
			@Bind("accountId") Long accountId,
			@BindCriteria Criteria criteria,
			@DefineOrder OrderBy orderBy,
			@BindBean ReqContext ctx);

	@SqlQuery("select count(*) "
			+ " FROM ddm_bank_account_documents gd "
			+ " join ddm_bank_account g on g.id = gd.bank_account_id "
			+ " where gd.definition_code = :definitionCode "
			+ " and g.id = :accountId "
			+ " and g.tenant_id = :tenantId "
			+ CURRENT_RECORD)
	Long countByDefinitionCodeAndAccountId(
			@Bind("tenantId") String tenantId,
			@Bind("definitionCode") String definitionCode,
			@Bind("accountId") Long accountId);

	@SqlQuery("select " + FIELDS
			+ " FROM ddm_bank_account_documents gd "
			+ " join ddm_bank_account g on g.id = gd.bank_account_id "
			+ " where gd.document_id = :documentId "
			+ " and g.id = :accountId "
			+ " and g.tenant_id = :tenantId "
			+ CURRENT_RECORD)
	@RegisterBeanMapper(BankAccountDocumentRes.class)
	Optional<BankAccountDocumentRes> getByDocumentIdAndAccountId(
			@Bind("documentId") Long documentId,
			@Bind("accountId") Long accountId,
			@BindBean ReqContext ctx);

	@SqlQuery("select " + FIELDS
			+ " FROM ddm_bank_account_documents gd "
			+ " join ddm_bank_account g on g.id = gd.bank_account_id "
			+ " where g.id = :accountId "
			+ " and gd.definition_code = :definitionCode "
			+ " and g.tenant_id = :tenantId "
			+ CURRENT_RECORD)
	@RegisterBeanMapper(BankAccountDocumentRes.class)
	List<BankAccountDocumentRes> getByAccountIdAndDefinitionCode(
			@Bind("accountId") Long accountId,
			@Bind("definitionCode") String definitionCode,
			@BindBean ReqContext ctx);

	@SqlQuery("select " + FIELDS
			+ " FROM ddm_bank_account_documents gd "
			+ " join ddm_bank_account g on g.id = gd.bank_account_id "
			+ " where gd.document_id = :documentId "
			+ " and g.id = :accountId "
			+ " and g.tenant_id = :tenantId "
			+ CURRENT_RECORD)
	@RegisterBeanMapper(BankAccountDocumentEntity.class)
	Optional<BankAccountDocumentEntity> findByDocumentIdAndAccountId(
			@Bind("tenantId") String tenantId,
			@Bind("documentId") Long documentId,
			@Bind("accountId") Long accountId);

	@SqlQuery("select " + FIELDS
			+ " FROM ddm_bank_account_documents gd "
			+ " join ddm_bank_account g on g.id = gd.bank_account_id "
			+ " where g.id = :accountId "
			+ " and g.tenant_id = :tenantId "
			+ CURRENT_RECORD)
	@RegisterBeanMapper(BankAccountDocumentEntity.class)
	List<BankAccountDocumentEntity> findByAndAccountId(
			@Bind("tenantId") String tenantId,
			@Bind("accountId") Long accountId);


	@SqlUpdate(
			"INSERT INTO ddm_bank_account_documents (bank_account_id, definition_code, document_id, dt_insert, user_id_insert, dt_delete, user_id_delete) "
					+ " VALUES (:bankAccountId, :definitionCode, :documentId, :dtInsert, :userIdInsert, :dtDelete, :userIdDelete)")
	@GetGeneratedKeys("pkid")
	Long insert(@BindBean BankAccountDocumentEntity entity);

	@SqlUpdate("update ddm_bank_account_documents set dt_delete =:dtDelete, user_id_delete=:userIdDelete where pkid = :pkid")
	void expireRow(@BindBean BankAccountDocumentEntity entity);
}
