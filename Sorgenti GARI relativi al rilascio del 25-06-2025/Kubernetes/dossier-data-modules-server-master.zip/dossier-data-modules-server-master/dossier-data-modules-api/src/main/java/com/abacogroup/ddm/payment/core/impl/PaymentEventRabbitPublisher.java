package com.abacogroup.ddm.payment.core.impl;

import com.abacogroup.ddm.payment.core.dto.PaymentQueueMessage;
import com.abacogroup.ddm.payment.db.dao.BankAccountDAO;
import com.abacogroup.embeddedqueue.rabbitmq.RabbitMqPublisher;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.rabbitmq.client.Connection;
import java.io.IOException;
import java.util.Objects;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class PaymentEventRabbitPublisher extends RabbitMqPublisher<PaymentQueueMessage> {

	public static final String EXCHANGE = "ddm-payment-exchange";
	private final BankAccountDAO bankAccountDAO;

	public PaymentEventRabbitPublisher(Connection connection, ObjectMapper objectMapper, BankAccountDAO bankAccountDAO) throws IOException {
		super(Objects.requireNonNull(connection));
		this.bankAccountDAO = bankAccountDAO;

		super.setObjectMapper(objectMapper);
	}

	@Override
	protected String getExchangeName() {
		return EXCHANGE;
	}

	@Override
	protected String getRoutingKey(PaymentQueueMessage element) {
		return element.getRoutingKey();
	}


	@Override
	protected byte[] getPayload(PaymentQueueMessage element) throws Exception {
		return getObjectMapper().writeValueAsBytes(element);
	}



}
