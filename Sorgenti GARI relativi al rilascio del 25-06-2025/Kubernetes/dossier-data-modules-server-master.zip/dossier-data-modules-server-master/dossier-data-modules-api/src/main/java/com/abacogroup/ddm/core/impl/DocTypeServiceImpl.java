package com.abacogroup.ddm.core.impl;

import static com.abacogroup.ddm.DossierDataModulesApplication.PAYMENT_MODULE;
import static com.abacogroup.ddm.DossierDataModulesApplication.HEIR_MODULE;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import com.abacogroup.ddm.api.DdmDocumentDefinition;
import com.abacogroup.ddm.api.DocTypeRelationRes;
import com.abacogroup.ddm.common.resources.ReqContext;
import com.abacogroup.ddm.core.DocTypeService;
import com.abacogroup.ddm.core.exceptions.InvalidDocumentException;
import com.abacogroup.ddm.db.dao.DAOContainer;
import com.abacogroup.ddm.db.dao.DocTypeRelationDAO;
import com.abacogroup.ddm.heirs_special_case.db.dao.HeirDocumentDAO;
import com.abacogroup.ddm.payment.core.mapper.DdmDocumentDefinitionMapper;
import com.abacogroup.ddm.payment.db.dao.BankAccountDocumentDAO;
import com.abacogroup.dynamicdocuments.bean.DocumentDefinition;
import com.abacogroup.dynamicdocuments.services.DocumentTypeService;

public class DocTypeServiceImpl implements DocTypeService {

	private final DocTypeRelationDAO dao;
	private final BankAccountDocumentDAO bankAccountDocumentDAO;
	private final HeirDocumentDAO heirDocumentDAO;

	private final DocumentTypeService documentTypeService;

	private final String dynamicDocumentsBucket;

	public DocTypeServiceImpl(DAOContainer dc, DocumentTypeService documentTypeService, String dynamicDocumentsBucket) {
		this.dao = dc.getDocTypeRelationDAO();
		this.bankAccountDocumentDAO = dc.getBankAccountDocumentDAO();
		this.heirDocumentDAO = dc.getHeirDocumentDAO();
		this.documentTypeService = documentTypeService;
		this.dynamicDocumentsBucket = dynamicDocumentsBucket;
	}

	@Override
	public List<DocTypeRelationRes> getPaymentDocTypeRelationsByAccountId(ReqContext context, Long accountId) {

		return dao.getByNamespace(context, PAYMENT_MODULE)
				.stream()
				.map(dt -> addSummaryFields(context, dt))
				.map(gd -> addFlPaymentDocPresent(context, gd, accountId))
				.collect(Collectors.toList());
	}

	@Override
	public DdmDocumentDefinition getDefinition(ReqContext reqContext, String definitionCode) {
		return documentTypeService.getDocumentDefinition(reqContext.getTenantId(), definitionCode)
				.map(DdmDocumentDefinitionMapper.INSTANCE::toDdmDocumentDefinition)
				.map(def -> def.setBucketName(dynamicDocumentsBucket))
				.orElseThrow(
						() -> new InvalidDocumentException(InvalidDocumentException.ErrEnum.DYNAMIC_DOCUMENT_ERR,
								String.format("error loading definition for %s", definitionCode)));
	}

	private DocTypeRelationRes addSummaryFields(ReqContext reqContext, DocTypeRelationRes docTypeRelationRes) {
		Optional<DocumentDefinition> def = documentTypeService.getDocumentDefinition(reqContext.getTenantId(), docTypeRelationRes.getDefinitionCode());

		def.ifPresent(d -> {
			docTypeRelationRes.setSummaryFieldDefinitions(documentTypeService.getSummaryFields(d, reqContext.getLang()));
			docTypeRelationRes.setMultiple(d.getMetadata().getMaxOccurs() != null && d.getMetadata().getMaxOccurs() > 1);
		});
		return docTypeRelationRes;
	}

	private DocTypeRelationRes addFlPaymentDocPresent(ReqContext reqContext, DocTypeRelationRes docTypeRelation, Long accountId) {
		if (null != accountId) {
			Long documentsCount = bankAccountDocumentDAO.countByDefinitionCodeAndAccountId(reqContext.getTenantId(),
					docTypeRelation.getDefinitionCode(), accountId);

			docTypeRelation.setDocPresent(documentsCount > 0L);
		}

		return docTypeRelation;

	}

	@Override
	public List<DocTypeRelationRes> getHeirDocTypeRelationsBySuccessionCode(ReqContext context, String cuaa) {

		return dao.getByNamespace(context, HEIR_MODULE)
				.stream()
				.map(dt -> addSummaryFields(context, dt))
				.map(gd -> addFlHeirDocPresent(context, gd, cuaa))
				.collect(Collectors.toList());
	}
	
	private DocTypeRelationRes addFlHeirDocPresent(ReqContext reqContext, DocTypeRelationRes docTypeRelation, String cuaa) {
		if (null != cuaa) {
			Long documentsCount = heirDocumentDAO.countByDefinitionCodeAndCuaa(reqContext.getTenantId(),
					docTypeRelation.getDefinitionCode(), cuaa);

			docTypeRelation.setDocPresent(documentsCount > 0L);
		}

		return docTypeRelation;

	}

}
