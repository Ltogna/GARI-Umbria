package com.abacogroup.ddm.common.client;

import com.abacogroup.ddm.common.resources.ReqContext;
import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.jdbi.paging.impl.InfiniteListResultsImpl;
import io.github.resilience4j.retry.RetryConfig;
import io.github.resilience4j.retry.RetryRegistry;
import java.time.Duration;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.function.Consumer;
import jakarta.ws.rs.ProcessingException;
import jakarta.ws.rs.ServerErrorException;
import jakarta.ws.rs.client.Entity;
import jakarta.ws.rs.client.Invocation.Builder;
import jakarta.ws.rs.client.WebTarget;
import jakarta.ws.rs.core.GenericType;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.MultivaluedHashMap;
import jakarta.ws.rs.core.MultivaluedMap;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

@Slf4j
public class ClientHelper {

	private static final String DEFAULT_PREFIX = "JWT";

	private final WebTarget target;

	private final RetryRegistry retryRegistry;

	public ClientHelper(WebTarget webTarget) {
		this.target = webTarget;
		this.retryRegistry = RetryRegistry.of(RetryConfig.custom()
				.maxAttempts(2)
				.waitDuration(Duration.ofMillis(500))
				.failAfterMaxAttempts(true)
				.retryExceptions(ProcessingException.class, ServerErrorException.class)
				.build());
	}

	public <T> List<T> getAllFromInfiniteResult(String path, ReqContext context, Map<String, Object> pathVariables, MultivaluedMap<String, Object> queryParams,
			GenericType<InfiniteListResultsImpl<T>> type) {

		List<T> all = new ArrayList<>();

		this.consumeAllFromInfiniteResult(path, context, pathVariables, queryParams, type, all::add);

		return all;
	}

	public <T> T getElementFromInfiniteResult(String path, ReqContext context, Map<String, Object> pathVariables, MultivaluedMap<String, Object> queryParams,
			GenericType<InfiniteListResultsImpl<T>> type, int pos) {
		InfiniteListResultsImpl<T> infiniteListResults = this.getRequestBuilder(path, getHeaders(context), pathVariables, queryParams)
				.accept(MediaType.APPLICATION_JSON_TYPE)
				.get(type);

		if (infiniteListResults.getCount() <= pos) {
			return null;
		} else {
			T t = infiniteListResults.getRecords().get(pos);
			return t;
		}
	}

	private <T> void consumeAllFromInfiniteResult(String path, ReqContext context, Map<String, Object> pathVariables,
			MultivaluedMap<String, Object> queryParams,
			GenericType<InfiniteListResultsImpl<T>> type, Consumer<T> consumer) {
		if (queryParams == null) {
			queryParams = new MultivaluedHashMap<>();
		}

		String nextKey = null;
		do {
			queryParams.putSingle("nextKey", nextKey);
			queryParams.putSingle("next_key", nextKey);
			InfiniteListResultsImpl<T> infiniteListResults = this.get(path, context, pathVariables, queryParams, type);

			for (T record : infiniteListResults.getRecords()) {
				consumer.accept(record);
			}
			nextKey = infiniteListResults.getNextKey();
		} while (nextKey != null);
	}

	public <T> InfiniteListResults<T> getInfiniteResult(String path, ReqContext context, Map<String, Object> pathVariables,
			MultivaluedMap<String, Object> queryParams,
			GenericType<InfiniteListResultsImpl<T>> type) {
		if (queryParams == null) {
			queryParams = new MultivaluedHashMap<>();
		}

		InfiniteListResultsImpl<T> infiniteListResults = this.getRequestBuilder(path, getHeaders(context), pathVariables, queryParams)
				.accept(MediaType.APPLICATION_JSON_TYPE)
				.get(type);

		return infiniteListResults;

	}

	public <T> T get(String path, ReqContext context, Map<String, Object> pathVariables, MultivaluedMap<String, Object> queryParams,
			GenericType<? extends T> type) {
		return retryRegistry.retry(String.format("GET %s/%s", target.getUri().toString(), path))
				.executeSupplier(() -> this.getRequestBuilder(path, getHeaders(context), pathVariables, queryParams)
						.accept(MediaType.APPLICATION_JSON_TYPE)
						.get(type));
	}

	public <T> T post(String path, ReqContext context, Map<String, Object> pathVariables, MultivaluedMap<String, Object> queryParams, Object requestBody,
			GenericType<? extends T> type) {
		return retryRegistry.retry(String.format("POST %s/%s", target.getUri().toString(), path))
				.executeSupplier(() -> this.getRequestBuilder(path, getHeaders(context), pathVariables, queryParams)
						.accept(MediaType.APPLICATION_JSON_TYPE)
						.post(Entity.json(requestBody == null ? Map.of() : requestBody), type));
	}

	public <T> T patch(String path, ReqContext context, Map<String, Object> pathVariables, MultivaluedMap<String, Object> queryParams, Object requestBody,
			GenericType<? extends T> type) {
		return retryRegistry.retry(String.format("PATCH %s/%s", target.getUri().toString(), path))
				.executeSupplier(() -> this.getRequestBuilder(path, getHeaders(context), pathVariables, queryParams)
						.accept(MediaType.APPLICATION_JSON_TYPE)
						.method("PATCH", Entity.json(requestBody == null ? Map.of() : requestBody), type));
	}

	private Builder getRequestBuilder(String path, MultivaluedMap<String, Object> headers, Map<String, Object> pathVariables,
			MultivaluedMap<String, Object> queryParams) {
		WebTarget webTarget = target.path(path)
				.resolveTemplates(pathVariables == null ? new HashMap<>() : pathVariables);

		if (queryParams != null) {
			for (Entry<String, List<Object>> entry : queryParams.entrySet()) {
				webTarget = webTarget.queryParam(entry.getKey(), entry.getValue().toArray());
			}
		}

		WebTarget finalWebTarget = webTarget;

		Builder builder = finalWebTarget.request(MediaType.APPLICATION_JSON_TYPE);

		if (headers != null) {
			for (Entry<String, List<Object>> entry : headers.entrySet()) {
				if (entry.getValue() != null) {
					for (Object v : entry.getValue()) {
						builder = builder.header(entry.getKey(), v);
					}
				} else {
					builder = builder.header(entry.getKey(), null);
				}
			}
		}

		log.info("calling {}", webTarget);
		return builder;
	}

	private String getAuthorization(User user) {
		if (StringUtils.isNotBlank(user.getAuthToken())) {
			return String.format("%s %s", DEFAULT_PREFIX, user.getAuthToken());
		} else {
			return null;
		}
	}

	private MultivaluedHashMap getHeaders(ReqContext context) {
		MultivaluedHashMap headers = new MultivaluedHashMap<>();
		headers.add("accept-language", context.getLang());
		headers.add("Authorization", getAuthorization(context.getUser()));
		return headers;
	}
}
