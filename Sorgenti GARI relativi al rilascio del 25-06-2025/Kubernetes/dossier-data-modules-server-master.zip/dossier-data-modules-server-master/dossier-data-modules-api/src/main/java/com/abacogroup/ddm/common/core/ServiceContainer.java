package com.abacogroup.ddm.common.core;

import com.abacogroup.ddm.aptitudes.api.services.AptitudeServices;
import com.abacogroup.ddm.core.AppConfigService;
import com.abacogroup.ddm.core.DdmAnomalyService;
import com.abacogroup.ddm.core.DocTypeService;
import com.abacogroup.ddm.core.PartyService;
import com.abacogroup.ddm.doigt_quotas.api.services.DoIgtQuotaService;
import com.abacogroup.ddm.heirs_special_case.core.HeirDocumentService;
import com.abacogroup.ddm.heirs_special_case.core.HeirsService;
import com.abacogroup.ddm.heirs_special_case.core.DocLookupsService;
import com.abacogroup.ddm.payment.core.BankAccountAnomalyService;
import com.abacogroup.ddm.payment.core.BankAccountDocumentService;
import com.abacogroup.ddm.payment.core.BankAccountService;
import com.abacogroup.ddm.payment.core.BulkAnomalyRecalculationService;
import com.abacogroup.ddm.payment.core.PartyAnomalyService;
import com.abacogroup.ddm.vine.api.services.AuthorizationService;
import com.abacogroup.dynamicdocuments.services.DocumentService;
import com.abacogroup.dynamicdocuments.services.DocumentTypeService;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class ServiceContainer {
	private DocumentTypeService documentTypeService;
	private DocumentService documentService;
	private AppConfigService appConfigService;
	private DdmAnomalyService ddmAnomalyService;
	private PartyService partyService;
	private BankAccountService bankAccountService;
	private BankAccountDocumentService bankAccountDocumentService;
	private BankAccountAnomalyService bankAccountAnomalyService;
	private DocTypeService docTypeService;
	private PartyAnomalyService partyAnomalyService;
	private BulkAnomalyRecalculationService bulkAnomalyRecalculationService;
	private AuthorizationService authorizationService;
	private AptitudeServices aptitudeServices;
	private DoIgtQuotaService doIgtQuotaService;
	private HeirDocumentService heirDocumentService;
	private HeirsService heirsService;
	private DocLookupsService docLookupsService;
}
