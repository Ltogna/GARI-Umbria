package com.abacogroup.ddm.payment.core;

import com.abacogroup.ddm.common.resources.ReqContext;

public interface BulkAnomalyRecalculationService {
	void recalculate(ReqContext reqContext, Long partyId);
}
