package com.abacogroup.ddm.heirs_special_case.resource;

import java.util.List;

import com.abacogroup.ddm.api.DdmDocumentDefinition;
import com.abacogroup.ddm.api.DocTypeRelationRes;
import com.abacogroup.ddm.common.resources.ReqContext;
import com.abacogroup.ddm.common.resources.ResourceConstants;
import com.abacogroup.ddm.core.DocTypeService;
import com.abacogroup.dropwizard.auth.sso2.User;
import com.codahale.metrics.annotation.Timed;

import io.dropwizard.auth.Auth;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.annotation.security.RolesAllowed;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DefaultValue;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.HeaderParam;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.MediaType;

@Path(ResourceConstants.HEIRS_MODULE_API_PRIV + "/doc-types")
@Tag(name = "Document types", description = "Operations on Dynamic documents definitions")
@Tag(name = "Heirs documents")
@Timed
@RolesAllowed({ "DDM_HEIR_METHODS|EDITOR", "DDM_HEIR_METHODS|VIEWER" })
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
public class HeirDocTypeResource {

	private final DocTypeService docTypeService;

	public HeirDocTypeResource(DocTypeService docTypeService) {
		this.docTypeService = docTypeService;
	}

	@GET
	@Path("")
	@Operation(description = "Get the list of dynamic document types")
	@ApiResponse(responseCode = "200", description = "Get the list of dynamic document types", useReturnTypeSchema = true)
	public List<DocTypeRelationRes> search(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "tenant id") @PathParam("tenant") String tenantId,
			@Parameter(description = "party cuaa") @QueryParam("cuaa") String cuaa) {

		ReqContext reqContext = new ReqContext(user, lang);
		return docTypeService.getHeirDocTypeRelationsBySuccessionCode(reqContext, cuaa);
	}

	@GET
	@Path("/{definitionCode}")
	@Operation(summary = "document definition", description = "Get document definition by its code")
	@ApiResponse(responseCode = "200", description = "Successfully, returns a document definition", useReturnTypeSchema = true)
	public DdmDocumentDefinition getDefinition(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@PathParam("tenant") String tenantId,
			@PathParam("definitionCode") String definitionCode) {

		ReqContext reqContext = new ReqContext(user, lang);
		return docTypeService.getDefinition(reqContext, definitionCode);
	}
}
