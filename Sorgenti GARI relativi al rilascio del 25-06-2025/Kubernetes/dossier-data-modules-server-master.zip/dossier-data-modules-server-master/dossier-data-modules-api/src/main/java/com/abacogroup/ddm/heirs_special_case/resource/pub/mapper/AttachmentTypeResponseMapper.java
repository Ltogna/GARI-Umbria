package com.abacogroup.ddm.heirs_special_case.resource.pub.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import com.abacogroup.ddm.heirs_special_case.api.AttachmentTypeRes;
import com.abacogroup.ddm.heirs_special_case.api.SuccessionTypeRes;
import com.abacogroup.ddm.heirs_special_case.api.v1.AttachmentTypeLookupResponseV1;

@Mapper
public interface AttachmentTypeResponseMapper {

	AttachmentTypeResponseMapper INSTANCE = Mappers.getMapper(AttachmentTypeResponseMapper.class);

	AttachmentTypeLookupResponseV1 toResponseV1(AttachmentTypeRes res);

}
