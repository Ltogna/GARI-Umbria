package com.abacogroup.ddm.core.dto.appconfig;


import com.abacogroup.ddm.core.dto.appconfig.HeirConfig.Config;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.experimental.SuperBuilder;

@Data
@EqualsAndHashCode(callSuper = true)
@ToString(callSuper = true)
@SuperBuilder(setterPrefix = "set")
@AllArgsConstructor
@NoArgsConstructor
public class HeirConfig extends BaseAppConfig<Config> {
    public static final String CONFIG_KEY = "heir";


    private Config configuration;
	
	@Data
	@Builder(setterPrefix = "set")
	@NoArgsConstructor
	@AllArgsConstructor
	@Schema(name = "HeirConfig")
	public static class Config {
		@NotNull
		private String cfRegex;
	}

}