package com.abacogroup.ddm.heirs_special_case.db.ntt;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;



@Data
@SuperBuilder(setterPrefix = "set")
@NoArgsConstructor
@AllArgsConstructor
public class SuccessionTypeEntity implements Serializable {

	private static final long serialVersionUID = -8679690881653804506L;

	private String tenantId;
	private String code;
	private String description;
	private Integer flVisible;

}
