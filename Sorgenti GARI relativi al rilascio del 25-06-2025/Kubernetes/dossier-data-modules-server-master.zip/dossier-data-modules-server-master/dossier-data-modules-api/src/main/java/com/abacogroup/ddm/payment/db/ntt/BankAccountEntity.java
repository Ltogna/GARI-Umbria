package com.abacogroup.ddm.payment.db.ntt;

import com.abacogroup.ddm.payment.api.BankNetworkEnum;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.jdbi.model.AuditEntity;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;
import java.io.Serializable;
import java.time.LocalDateTime;



@Data
@SuperBuilder(setterPrefix = "set")
@NoArgsConstructor
@AllArgsConstructor
public class BankAccountEntity implements AuditEntity, Serializable {

	private static final long serialVersionUID = -8679690881653804506L;

	private Long pkid;
	private Long id;
	private String tenantId;
	private Long partyId;

	private BankNetworkEnum network;
	private String iban;

	private String swiftBic;
	private String bicExtraSepa;

	private String bankCountry;
	private String bankName;
	private String bankBranch;

	private String description;

	private int flDefault;

	private AbsoluteDate dayFrom;
	private AbsoluteDate dayTo;

	private LocalDateTime dtInsert;
	private String userIdInsert;
	private LocalDateTime dtDelete;
	private String userIdDelete;

}
