package com.abacogroup.ddm.db.dao;

import com.abacogroup.ddm.heirs_special_case.db.dao.HeirDAO;
import com.abacogroup.ddm.heirs_special_case.db.dao.HeirDocumentDAO;
import com.abacogroup.ddm.heirs_special_case.db.dao.SuccessionTypeDAO;
import com.abacogroup.ddm.payment.db.dao.BankAccountDAO;
import com.abacogroup.ddm.payment.db.dao.BankAccountDocumentDAO;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class DAOContainer {
	private I18nDAO i18nDAO;
	private AppConfigDAO appConfigDAO;
	private DocTypeRelationDAO docTypeRelationDAO;
	private AnomalyCategoriesDAO anomalyCategoriesDAO;

	private BankAccountDAO bankAccountDAO;
	private BankAccountDocumentDAO bankAccountDocumentDAO;
	
	private HeirDAO heirDAO;
	private HeirDocumentDAO heirDocumentDAO;
	private SuccessionTypeDAO successionTypeDAO;
	private SuccessionConfigDAO successionConfigDAO;
}
