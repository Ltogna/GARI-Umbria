package com.abacogroup.ddm.core.cli;

import static com.abacogroup.partyregistry.resources.PublicResourceConstants.API_V1_PUB;

import com.abacogroup.ddm.common.client.ClientHelper;
import com.abacogroup.ddm.common.resources.ReqContext;
import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.jdbi.paging.impl.InfiniteListResultsImpl;
import com.abacogroup.partyregistry.api.v1.PartyResponseV1;
import com.abacogroup.partyregistry.api.v1.PartySearchResponseV1;
import com.abacogroup.partyregistry.api.v1.req.PartyByIdInSearchRequestV1;
import com.abacogroup.partyregistry.api.v1.req.PartySearchRequestV1;
import com.abacogroup.partyregistry.core.cli.v1.PartyClientV1;
import jakarta.ws.rs.client.WebTarget;
import jakarta.ws.rs.core.GenericType;
import jakarta.ws.rs.core.MultivaluedHashMap;
import jakarta.ws.rs.core.MultivaluedMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class PartyDdmClientV1Impl implements PartyClientV1 {

	public static final String PARTIES = "parties";
	private final ClientHelper clientHelper;

	public PartyDdmClientV1Impl(WebTarget prtBaseTarget) {
		clientHelper = new ClientHelper(prtBaseTarget);
	}

	@Override
	public InfiniteListResults<PartySearchResponseV1> search(String lang, User user, String nextKey, PartySearchRequestV1 searchRequest) {
		String tenantId = user.getTenant();

		String path = String.format("%s/%s", API_V1_PUB, PARTIES);
		Map<String, Object> pathVars = Map.of(
				"tenant", tenantId
		);
		MultivaluedMap<String, Object> queryParams = new MultivaluedHashMap<>();
		Optional.ofNullable(nextKey).ifPresent(v -> queryParams.add("nextKey", v));
		Optional.ofNullable(searchRequest.getLastName()).ifPresent(v -> queryParams.add("lastName", v));
		Optional.ofNullable(searchRequest.getFirstName()).ifPresent(v -> queryParams.add("firstName", v));
		Optional.ofNullable(searchRequest.getTaxCode()).ifPresent(v -> queryParams.add("taxCode", v));
		Optional.ofNullable(searchRequest.getVatNumber()).ifPresent(v -> queryParams.add("vatNumber", v));
		Optional.ofNullable(searchRequest.getTaxOrVat()).ifPresent(v -> queryParams.add("taxOrVat", v));
		Optional.ofNullable(searchRequest.getCode()).ifPresent(v -> queryParams.add("code", v));
		Optional.ofNullable(searchRequest.getHasCode()).ifPresent(v -> queryParams.add("hasCode", v));
		Optional.ofNullable(searchRequest.getFullName()).ifPresent(v -> queryParams.add("fullName", v));
		Optional.ofNullable(searchRequest.getFullNameOrCode()).ifPresent(v -> queryParams.add("fullNameOrCode", v));
		Optional.ofNullable(searchRequest.getTag()).ifPresent(v -> queryParams.addAll("tag", v.toArray()));
		Optional.ofNullable(searchRequest.getArchived()).ifPresent(v -> queryParams.add("archived", v));

		InfiniteListResultsImpl<PartySearchResponseV1> results = clientHelper.get(path,
				new ReqContext(user, lang), pathVars, queryParams, new GenericType<>() {});

		return results;
	}

	@Override
	public PartyResponseV1 getById(String lang, User user, Long id) {
		String tenantId = user.getTenant();

		String path = String.format("%s/%s/{id}", API_V1_PUB, PARTIES);
		Map<String, Object> pathVars = Map.of(
				"tenant", tenantId,
				"id", id
		);
		MultivaluedMap<String, Object> queryParams = new MultivaluedHashMap<>();

		PartyResponseV1 result = clientHelper.get(path, new ReqContext(user, lang),
				pathVars, queryParams, new GenericType<>() {});

		return result;
	}

	@Override
	public List<PartyResponseV1> getByIds(String lang, User user, List<Long> ids) {
		String tenantId = user.getTenant();

		String path = String.format("%s/%s", API_V1_PUB, PARTIES);
		Map<String, Object> pathVars = Map.of(
				"tenant", tenantId
		);
		MultivaluedMap<String, Object> queryParams = new MultivaluedHashMap<>();

		List<PartyResponseV1>  results = clientHelper.post(path, new ReqContext(user, lang),
				pathVars, queryParams, new PartyByIdInSearchRequestV1().setIds(ids), new GenericType<>() {});

		return results;
	}

	@Override
	public PartyResponseV1 getByCode(String lang, User user, String code) {
		String tenantId = user.getTenant();

		String path = String.format("%s/%s/code/{code}", API_V1_PUB, PARTIES);
		Map<String, Object> pathVars = Map.of(
				"tenant", tenantId,
				"code", code
		);
		MultivaluedMap<String, Object> queryParams = new MultivaluedHashMap<>();

		PartyResponseV1 result = clientHelper.get(path, new ReqContext(user, lang),
				pathVars, queryParams, new GenericType<>() {});

		return result;
	}

}
