package com.abacogroup.ddm.vine.api.services;


import com.abacogroup.ddm.DossierDataModulesConfiguration;
import com.abacogroup.ddm.common.resources.ReqContext;
import com.abacogroup.ddm.common.resources.ResourceConstants;
import com.abacogroup.ddm.core.AppConfigService;
import com.abacogroup.ddm.core.dto.appconfig.TreeUnitsConfig;
import com.abacogroup.ddm.vine.api.repositories.AuthorizationRepository;
import io.dropwizard.client.JerseyClientBuilder;
import io.dropwizard.core.setup.Environment;
import jakarta.ws.rs.client.Client;
import jakarta.ws.rs.client.WebTarget;
import jakarta.ws.rs.core.Response;

import java.time.LocalDateTime;

public class AuthorizationService {
    private final Environment environment;
    private final DossierDataModulesConfiguration configuration;
    private final AppConfigService appConfigService;

    public AuthorizationService(Environment environment, DossierDataModulesConfiguration configuration, AppConfigService appConfigService) {
        this.environment = environment;
        this.configuration = configuration;
        this.appConfigService = appConfigService;
    }

    public Response getAuthorizationsGroupedByType(ReqContext reqContext, Long partyId, String nextKey) {

        WebTarget avepaLegacyWebTarget = buildAvepaLegacyWebTarget(reqContext);
        return AuthorizationRepository.getAuthorizationsGroupedByType(avepaLegacyWebTarget, reqContext, partyId, nextKey, ResourceConstants.DEFAULT_PAGE_SIZE);
    }

    public Response getAuthorizationsByPartyIdAndType(ReqContext reqContext, Long partyId,
                                                      String authorizationTypeCode, Boolean includeExpired, String nextKey) {
        WebTarget avepaLegacyWebTarget = buildAvepaLegacyWebTarget(reqContext);
        return AuthorizationRepository.getAuthorizationsByPartyIdAndType(avepaLegacyWebTarget, reqContext, partyId, authorizationTypeCode, includeExpired, nextKey, ResourceConstants.DEFAULT_PAGE_SIZE);
    }

    public Response getAuthorizationById(ReqContext reqContext, Long id, Long partyId) {
        WebTarget avepaLegacyWebTarget = buildAvepaLegacyWebTarget(reqContext);
        return AuthorizationRepository.getAuthorizationById(avepaLegacyWebTarget, reqContext, id, partyId);
    }

    private WebTarget buildAvepaLegacyWebTarget(ReqContext reqContext) {
        final Client client = new JerseyClientBuilder(environment)
                .using(configuration.getJerseyClient())
                .build("authorizations-client: " + LocalDateTime.now());

        String baseUrl = getBaseUrl(reqContext);

        return client.target(baseUrl);
    }

    private String getBaseUrl(ReqContext reqContext) {
        return appConfigService.getConfig(reqContext.getTenantId(), TreeUnitsConfig.CONFIG_KEY, TreeUnitsConfig.class)
         				.map(TreeUnitsConfig::getConfiguration)
         				.map(TreeUnitsConfig.Config::getAuth_url)
         				.orElseThrow(() ->  new RuntimeException("Could not find BaseUrl for " + reqContext.getTenantId()));
    }
}
