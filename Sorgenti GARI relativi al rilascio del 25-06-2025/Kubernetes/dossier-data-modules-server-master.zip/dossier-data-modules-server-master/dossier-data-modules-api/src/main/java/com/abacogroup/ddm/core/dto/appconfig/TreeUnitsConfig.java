package com.abacogroup.ddm.core.dto.appconfig;

import io.swagger.v3.oas.annotations.media.Schema;
import com.abacogroup.ddm.core.dto.appconfig.TreeUnitsConfig.Config;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import lombok.*;
import lombok.experimental.SuperBuilder;

@Data
@EqualsAndHashCode(callSuper = true)
@ToString(callSuper = true)
@SuperBuilder(setterPrefix = "set")
@AllArgsConstructor
@NoArgsConstructor
public class TreeUnitsConfig extends BaseAppConfig<Config> {
    public static final String CONFIG_KEY = "units";

    @Valid
    @NotNull
    private Config configuration;

    @Data
    @Builder(setterPrefix = "set")
    @NoArgsConstructor
    @AllArgsConstructor
    @Schema(name = "TreeUnitsValidationConfig")
    public static class Config {
        @NotNull
        private Boolean aptitudes_enabled;

        @NotNull
        private String aptitudes_url;

        @NotNull
        private Boolean auth_enabled;

        @NotNull
        private String auth_url;

        @NotNull
        private Boolean do_igt_quotas_enabled;

        @NotNull
        private String do_igt_quotas_url;

        @NotNull
        private String mode;
    }
}
