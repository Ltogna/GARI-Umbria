package com.abacogroup.ddm.db.ntt;

import com.abacogroup.jdbi.model.AuditEntity;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;
import java.time.LocalDateTime;

@Data
@SuperBuilder(setterPrefix = "set")
@NoArgsConstructor
public class AppConfigEntity implements AuditEntity {

	private Long id;

	private String tenantId;
	private String configurationKey;
	private String configuration;

	private LocalDateTime dtInsert;
	private String userIdInsert;
	private LocalDateTime dtDelete;
	private String userIdDelete;

}
