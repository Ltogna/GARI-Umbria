package com.abacogroup.ddm.heirs_special_case.core;

import com.abacogroup.ddm.common.resources.ReqContext;
import com.abacogroup.ddm.heirs_special_case.api.HeirDocumentRes;
import com.abacogroup.ddm.heirs_special_case.api.req.HeirDocumentSearchReq;
import com.abacogroup.dynamicdocuments.bean.Document;
import com.abacogroup.dynamicdocuments.bean.InsertDocument;
import com.abacogroup.jdbi.paging.InfiniteListResults;

import jakarta.ws.rs.core.Response;

public interface HeirDocumentService {
	HeirDocumentRes insert(ReqContext reqContext, String partyCuaa, InsertDocument document);

	void expire(ReqContext reqContext, String partyCuaa, Long documentId);

	HeirDocumentRes update(ReqContext reqContext, String partyCuaa, Long documentId, Document updateReq);

	HeirDocumentRes getHeirDocument(ReqContext reqContext, String partyCuaa, Long documentId);

	InfiniteListResults<HeirDocumentRes> search(ReqContext reqContext, String partyCuaa, HeirDocumentSearchReq searchReq,
			String nextKey);


	Response getDocumentFileContent(ReqContext reqContext, String partyCuaa, Long documentId, String fileId);

	Response getDocumentFileMetadata(ReqContext reqContext, String partyCuaa, Long documentId, String fileId);
}
