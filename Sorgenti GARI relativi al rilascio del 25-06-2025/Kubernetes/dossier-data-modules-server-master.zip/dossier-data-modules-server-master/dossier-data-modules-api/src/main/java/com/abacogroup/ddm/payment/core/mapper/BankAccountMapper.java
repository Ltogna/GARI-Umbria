package com.abacogroup.ddm.payment.core.mapper;

import com.abacogroup.ddm.api.DdmAnomaliesRes;
import com.abacogroup.ddm.payment.api.BankAccountRes;
import com.abacogroup.ddm.payment.api.BankAccountSearchRes;
import com.abacogroup.ddm.payment.api.req.BankAccountCreateReq;
import com.abacogroup.ddm.payment.api.req.BankAccountUpdateReq;
import com.abacogroup.ddm.payment.db.ntt.BankAccountEntity;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.factory.Mappers;

@Mapper(uses = StringFormatMapper.class)
public interface BankAccountMapper {

	BankAccountMapper INSTANCE = Mappers.getMapper(BankAccountMapper.class);

	@Mapping(target = "flDefault", expression = "java(req.getDefaultBankAccount() ? 1 : 0)")
	@Mapping(target = "iban", qualifiedByName = "formatCode")
	@Mapping(target = "swiftBic", qualifiedByName = "formatCode")
	@Mapping(target = "bicExtraSepa", qualifiedByName = "formatCode")
	BankAccountEntity reqToEntity(BankAccountCreateReq req);

	@Mapping(target = "flDefault", expression = "java(req.getDefaultBankAccount() ? 1 : 0)")
	void reqToEntity(BankAccountUpdateReq req, @MappingTarget BankAccountEntity targetEntity);

	@Mapping(target = "defaultBankAccount", expression = "java(entity.getFlDefault() > 0)")
	BankAccountRes entityToRes(BankAccountEntity entity);

	@Mapping(target = "defaultBankAccount", expression = "java(entity.getFlDefault() > 0)")
	BankAccountSearchRes entityToSearchRes(BankAccountEntity entity, DdmAnomaliesRes anomalies);


}
