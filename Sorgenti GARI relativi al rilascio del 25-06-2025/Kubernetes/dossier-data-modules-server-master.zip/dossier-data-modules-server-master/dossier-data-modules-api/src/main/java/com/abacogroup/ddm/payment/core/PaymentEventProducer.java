package com.abacogroup.ddm.payment.core;

import com.abacogroup.ddm.common.resources.ReqContext;
import com.abacogroup.ddm.payment.core.dto.PaymentEventType;

public interface PaymentEventProducer {
	void pushBankAccountEvent(ReqContext reqContext, Long partyId, Long accountId, PaymentEventType eventType);

	void pushBankAccountEvent(String tenant, String username, String lang, Long partyId, Long accountId, PaymentEventType eventType);
}
