package com.abacogroup.ddm.heirs_special_case.db.ntt;

import com.abacogroup.jdbi.model.AuditEntity;
import java.time.LocalDateTime;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder(setterPrefix = "set")
@NoArgsConstructor
public class HeirDocumentEntity implements AuditEntity {

	private Long pkid;
	private String tenantId;
	private Long partyId;
	private String cuaa;
	private String definitionCode;
	private Long documentId;
	private String successionCode;
	private String attachmentCode;

	private LocalDateTime dtInsert;
	private String userIdInsert;
	private LocalDateTime dtDelete;
	private String userIdDelete;

}
