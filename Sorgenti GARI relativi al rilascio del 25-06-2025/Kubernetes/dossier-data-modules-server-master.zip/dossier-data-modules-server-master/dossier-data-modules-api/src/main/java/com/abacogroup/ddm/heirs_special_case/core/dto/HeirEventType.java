package com.abacogroup.ddm.heirs_special_case.core.dto;

public enum HeirEventType {

	NEW_HEIR("new-heir"),
	UPDATE_HEIR("update-heir"),
	REMOVE_HEIR("remove-heir"),
	ADD_HEIR_DOCUMENT("add-heir-document"),
	UPDATE_HEIR_DOCUMENT("update-heir-document"),
	REMOVE_HEIR_DOCUMENT("remove-heir-document"),
	
	;

	public static final String TOPIC_PREFIX = "ddm-heir";

	private final String topic;

	HeirEventType(String topicName) {
		this.topic = topicName;
	}

	public String getTopic() {
		return String.format("%s.%s", TOPIC_PREFIX, topic);
	}
}
