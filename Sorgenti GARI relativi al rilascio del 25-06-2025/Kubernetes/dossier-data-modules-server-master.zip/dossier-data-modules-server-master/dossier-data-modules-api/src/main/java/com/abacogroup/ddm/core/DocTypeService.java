package com.abacogroup.ddm.core;

import com.abacogroup.ddm.api.DdmDocumentDefinition;
import com.abacogroup.ddm.api.DocTypeRelationRes;
import com.abacogroup.ddm.common.resources.ReqContext;
import java.util.List;

public interface DocTypeService {
	
	List<DocTypeRelationRes> getPaymentDocTypeRelationsByAccountId(ReqContext context, Long accountId);
	
	List<DocTypeRelationRes> getHeirDocTypeRelationsBySuccessionCode(ReqContext context, String cuaa);

	DdmDocumentDefinition getDefinition(ReqContext reqContext, String definitionCode);
}
