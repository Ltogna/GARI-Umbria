package com.abacogroup.ddm.heirs_special_case.core.impl;

import java.io.IOException;
import java.util.Objects;

import com.abacogroup.ddm.heirs_special_case.core.dto.HeirQueueMessage;
import com.abacogroup.embeddedqueue.rabbitmq.RabbitMqPublisher;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.rabbitmq.client.Connection;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class HeirEventRabbitPublisher extends RabbitMqPublisher<HeirQueueMessage> {

	public static final String EXCHANGE = "ddm-heir-exchange";

	public HeirEventRabbitPublisher(Connection connection, ObjectMapper objectMapper) throws IOException {
		super(Objects.requireNonNull(connection));

		super.setObjectMapper(objectMapper);
	}

	@Override
	protected String getExchangeName() {
		return EXCHANGE;
	}

	@Override
	protected String getRoutingKey(HeirQueueMessage element) {
		return element.getRoutingKey();
	}


	@Override
	protected byte[] getPayload(HeirQueueMessage element) throws Exception {
		return getObjectMapper().writeValueAsBytes(element);
	}



}
