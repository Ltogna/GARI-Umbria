package com.abacogroup.ddm.core;

import com.abacogroup.ddm.common.resources.ReqContext;
import com.abacogroup.ddm.heirs_special_case.api.PartyCacheData;

public interface PartyService {
	
	void validatePartyId(ReqContext reqContext, Long partyId);
	
	PartyCacheData getPartyByCuaa(ReqContext reqContext, String cuaa);
}
