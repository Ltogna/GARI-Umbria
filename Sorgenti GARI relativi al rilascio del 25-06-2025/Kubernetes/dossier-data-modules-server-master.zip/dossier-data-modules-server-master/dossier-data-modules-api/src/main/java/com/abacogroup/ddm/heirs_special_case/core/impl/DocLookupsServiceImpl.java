package com.abacogroup.ddm.heirs_special_case.core.impl;

import java.util.List;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;

import com.abacogroup.ddm.common.resources.ReqContext;
import com.abacogroup.ddm.core.exceptions.HeirException;
import com.abacogroup.ddm.core.exceptions.HeirException.ErrEnum;
import com.abacogroup.ddm.db.dao.SuccessionConfigDAO;
import com.abacogroup.ddm.heirs_special_case.api.AttachmentTypeRes;
import com.abacogroup.ddm.heirs_special_case.api.SuccessionTypeRes;
import com.abacogroup.ddm.heirs_special_case.core.DocLookupsService;
import com.abacogroup.ddm.heirs_special_case.core.mapper.SuccessionMapper;
import com.abacogroup.ddm.heirs_special_case.db.dao.SuccessionTypeDAO;

import jakarta.validation.constraints.NotBlank;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class DocLookupsServiceImpl implements DocLookupsService {

	private final SuccessionTypeDAO successionTypeDAO;
	private final SuccessionConfigDAO successionConfigDAO;

	public DocLookupsServiceImpl(SuccessionTypeDAO successionTypeDAO, SuccessionConfigDAO successionConfigDAO) {
		this.successionTypeDAO = successionTypeDAO;
		this.successionConfigDAO = successionConfigDAO;
	}

	@Override
	public List<SuccessionTypeRes> getSuccessionTypeList(ReqContext reqContext, String successionCode) {
		return successionTypeDAO.getSuccessionTypes(reqContext.getTenantId(), reqContext.getLang(), successionCode, 1).stream()
				.map(SuccessionMapper.INSTANCE::entityToRes)
				.collect(Collectors.toList());
	}

	@Override
	public List<AttachmentTypeRes> getAttachmentTypeList(ReqContext reqContext, String namespace, @NotBlank String successionCode, String attachmentCode) {
		return successionConfigDAO.getByNamespaceAndSuccessionCode(reqContext.getTenantId(), reqContext.getLang(), namespace, successionCode, attachmentCode).stream()
				.filter(config -> StringUtils.isNotBlank(config.getAttachmentType()))
				.map(SuccessionMapper.INSTANCE::configEntityToAttachmentRes)
				.distinct()
				.collect(Collectors.toList());
	}

	@Override
	public AttachmentTypeRes getAttachmentTypeByCode(ReqContext reqContext, String namespace, String attachmentCode) {
		return successionConfigDAO.getByNamespace(reqContext.getTenantId(), reqContext.getLang(), namespace, null, attachmentCode).stream()
		.filter(config -> StringUtils.isNotBlank(config.getAttachmentType()))
		.map(SuccessionMapper.INSTANCE::configEntityToAttachmentRes)
		.findFirst()
		.orElseThrow(() -> new HeirException(ErrEnum.ATTACHMENT_TYPE_NOT_FOUND, String.format("Tipologia allegato [%s] non trovata", attachmentCode)));
		
	}

}

