package com.abacogroup.ddm.payment.resource.pub.mapper;

import com.abacogroup.ddm.api.DdmAnomaliesRes;
import com.abacogroup.ddm.api.v1.DdmAnomaliesResponseV1;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper
public interface DdmAnomaliesResponseMapper {

	DdmAnomaliesResponseMapper INSTANCE = Mappers.getMapper(DdmAnomaliesResponseMapper.class);

	DdmAnomaliesResponseV1 toResponseV1(DdmAnomaliesRes res);

}
