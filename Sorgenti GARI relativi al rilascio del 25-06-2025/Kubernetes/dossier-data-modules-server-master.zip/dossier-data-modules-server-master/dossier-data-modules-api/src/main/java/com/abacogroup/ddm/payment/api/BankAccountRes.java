package com.abacogroup.ddm.payment.api;

import com.abacogroup.jdbi.datatype.AbsoluteDate;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder(setterPrefix = "set")
@NoArgsConstructor
@AllArgsConstructor
public class BankAccountRes {

	private Long id;

	private Long partyId; // TODO full dto?

	private BankNetworkEnum network;
	private String iban;

	private String swiftBic;
	private String bicExtraSepa;

	private String bankCountry;
	private String bankName;
	private String bankBranch;

	private String description;

	private Boolean defaultBankAccount;
	//private Boolean active;

	private AbsoluteDate dayFrom;
	private AbsoluteDate dayTo;


	public boolean isActive() {
		return !(java.time.LocalDate.now().isBefore(this.getDayFrom().toLocalDate()))
				&& java.time.LocalDate.now().isBefore(this.getDayTo().toLocalDate());
	}
}
