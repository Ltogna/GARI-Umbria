package com.abacogroup.ddm.payment.core;

import com.abacogroup.ddm.api.DdmAnomaliesRes;
import com.abacogroup.ddm.common.resources.ReqContext;

public interface BankAccountAnomalyService {
	DdmAnomaliesRes getAnomalies(ReqContext reqContext, Long partyId, Long accountId);
}
