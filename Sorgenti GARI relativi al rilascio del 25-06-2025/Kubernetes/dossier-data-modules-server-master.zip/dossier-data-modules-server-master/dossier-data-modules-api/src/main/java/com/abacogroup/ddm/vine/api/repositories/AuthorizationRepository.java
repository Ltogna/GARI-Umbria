package com.abacogroup.ddm.vine.api.repositories;

import com.abacogroup.ddm.common.core.cli.impl.TokenRelayStrategy;
import com.abacogroup.ddm.common.resources.ReqContext;
import jakarta.ws.rs.client.Invocation;
import jakarta.ws.rs.client.WebTarget;
import jakarta.ws.rs.core.Response;

public class AuthorizationRepository {

    public static Response getAuthorizationsGroupedByType(WebTarget avepaLegacyWebTarget, ReqContext reqContext,
                                                          Long partyId, String nextKey, Integer pageSize) {
        WebTarget path = avepaLegacyWebTarget
                .path(reqContext.getTenantId())
                .path("public/v1/authorizations")
                .path(String.valueOf(partyId))
                .queryParam("next_key", nextKey);

        if (pageSize != null) {
            path = path.queryParam("page_size", pageSize);
        }

        Invocation.Builder builder = addAuthorizationHeader(path, reqContext);

        return builder.get();
    }

    public static Response getAuthorizationsByPartyIdAndType(WebTarget avepaLegacyWebTarget, ReqContext reqContext,
              Long partyId, String authorizationTypeCode, Boolean includeExpired, String nextKey, Integer pageSize) {

        WebTarget path = avepaLegacyWebTarget
                .path(reqContext.getTenantId())
                .path("public/v1/authorizations")
                .path(String.valueOf(partyId))
                .path(authorizationTypeCode)
                .queryParam("next_key", nextKey)
                .queryParam("includeExpired", includeExpired);

        if (pageSize != null) {
            path = path.queryParam("page_size", pageSize);
        }

        Invocation.Builder builder = addAuthorizationHeader(path, reqContext);

        return builder.get();
    }

    public static Response getAuthorizationById(WebTarget avepaLegacyWebTarget, ReqContext reqContext, Long id, Long partyId) {
        WebTarget path = avepaLegacyWebTarget
                .path(reqContext.getTenantId())
                .path("public/v1/authorizations")
                .path(String.valueOf(partyId))
                .path("authorization")
                .path(String.valueOf(id));

        Invocation.Builder builder = addAuthorizationHeader(path, reqContext);
        return builder.get();
    }


    private static Invocation.Builder addAuthorizationHeader(WebTarget webTarget, ReqContext reqContext) {
         TokenRelayStrategy authorizationStrategy = new TokenRelayStrategy();
         return webTarget.request()
                .header("Authorization", authorizationStrategy.getAuthorization(reqContext.getUser()));
    }
}
