package com.abacogroup.ddm.payment.core.mapper;

import com.abacogroup.ddm.api.DdmDocumentDefinition;
import com.abacogroup.dynamicdocuments.bean.DocumentDefinition;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper
public interface DdmDocumentDefinitionMapper {

	DdmDocumentDefinitionMapper INSTANCE = Mappers.getMapper(DdmDocumentDefinitionMapper.class);

	DdmDocumentDefinition toDdmDocumentDefinition(DocumentDefinition dd);

}
