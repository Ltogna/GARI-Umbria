package com.abacogroup.ddm.core.dto;

import com.abacogroup.anomalyregistry.api.v1.AnomalySearchResponse;
import com.abacogroup.ddm.db.ntt.AnomalyCategoriesEntity;
import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class AnomalyType {

	private String groupCode;
	private String code;

	public AnomalyType(AnomalySearchResponse anomalySearchResponse) {
		this.groupCode = anomalySearchResponse.getType().getGroupCode();
		this.code = anomalySearchResponse.getType().getCode();
	}

	public AnomalyType(AnomalyCategoriesEntity anomalyCategoriesEntity) {
		this.groupCode = anomalyCategoriesEntity.getGroupCode();
		this.code = anomalyCategoriesEntity.getCode();
	}
}
