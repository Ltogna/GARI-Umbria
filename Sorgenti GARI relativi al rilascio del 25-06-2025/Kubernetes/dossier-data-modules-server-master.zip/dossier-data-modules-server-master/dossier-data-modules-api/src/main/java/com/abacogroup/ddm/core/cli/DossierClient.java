package com.abacogroup.ddm.core.cli;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.abacogroup.ddm.common.client.ClientHelper;
import com.abacogroup.ddm.common.resources.ReqContext;
import com.abacogroup.ddm.core.dto.DossierByPartyDTO;
import com.abacogroup.dropwizard.auth.sso2.Sso2Client;
import com.abacogroup.jdbi.paging.impl.InfiniteListResultsImpl;

import jakarta.ws.rs.client.WebTarget;
import jakarta.ws.rs.core.GenericType;
import jakarta.ws.rs.core.MultivaluedHashMap;
import jakarta.ws.rs.core.MultivaluedMap;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class DossierClient {

	private final Sso2Client sso2Client;
	private final ClientHelper clientHelper;

	private static final String GET_DOSSIER_BY_PARTY_ID_PATH = "/{tenant}/public/v1/dossiers/parties/{partyId}";

	public DossierClient(Sso2Client sso2Client, WebTarget dossierWT) {
		this.sso2Client = sso2Client;
		clientHelper = new ClientHelper(dossierWT);

	}

	public List<DossierByPartyDTO> getDossierListByPartyId(ReqContext reqontext, Long partyId) {

		Map<String, Object> pathVars = new HashMap<>();
		pathVars.put("tenant", reqontext.getTenantId());
		pathVars.put("partyId", partyId);

		sso2Client.ensureLongLivingAuthToken(reqontext.getUser());

		MultivaluedMap<String, Object> queryParams = new MultivaluedHashMap<>();

		return clientHelper.getAllFromInfiniteResult(GET_DOSSIER_BY_PARTY_ID_PATH, 
				reqontext, 
				pathVars, 
				queryParams, 
				new GenericType<InfiniteListResultsImpl<DossierByPartyDTO>>() {});
	}

}
