package com.abacogroup.ddm.aptitudes.api.services;

import com.abacogroup.ddm.DossierDataModulesConfiguration;
import com.abacogroup.ddm.aptitudes.api.repositories.AptitudeRepository;
import com.abacogroup.ddm.common.resources.ReqContext;
import com.abacogroup.ddm.common.resources.ResourceConstants;
import com.abacogroup.ddm.core.AppConfigService;
import com.abacogroup.ddm.core.dto.appconfig.TreeUnitsConfig;
import io.dropwizard.client.JerseyClientBuilder;
import io.dropwizard.core.setup.Environment;
import jakarta.ws.rs.client.Client;
import jakarta.ws.rs.client.WebTarget;
import jakarta.ws.rs.core.Response;

import java.time.LocalDateTime;

public class AptitudeServices {
    private final Environment environment;
    private final DossierDataModulesConfiguration configuration;
    private final AppConfigService appConfigService;

    public AptitudeServices(Environment environment, DossierDataModulesConfiguration configuration, AppConfigService appConfigService) {
        this.environment = environment;
        this.configuration = configuration;
        this.appConfigService = appConfigService;
    }

    public Response getAptitudesGroupedByVineCode(ReqContext reqContext, String referenceDate, Long partyId, String nextKey) {
        WebTarget vineGisWebTarget = buildVineGisWebTarget(reqContext);

        return AptitudeRepository.getAptitudesGroupedByVineCode(vineGisWebTarget, reqContext,referenceDate, partyId, nextKey);
    }

    public Response getAllAptitudesByPartyId(ReqContext reqContext, String referenceDate, Long partyId, String vineCode, String nextKey) {
        WebTarget vineGisWebTarget = buildVineGisWebTarget(reqContext);
        return AptitudeRepository.getAllAptitudesByPartyId(vineGisWebTarget, reqContext, referenceDate, partyId, vineCode, nextKey, ResourceConstants.DEFAULT_PAGE_SIZE);
    }


    public Response getAptitudeById(ReqContext reqContext, String referenceDate,  Long parcelId,
                                    Long landCoversId,
                                    Long vineUnitId,
                                    Long vineAptitudeId) {
        WebTarget vineGisWebTarget = buildVineGisWebTarget(reqContext);

        return AptitudeRepository
                .getAptitudeById(vineGisWebTarget, reqContext, referenceDate, parcelId, landCoversId, vineUnitId, vineAptitudeId);
    }

    private WebTarget buildVineGisWebTarget(ReqContext reqContext) {
        final Client client = new JerseyClientBuilder(environment)
                .using(configuration.getJerseyClient())
                .build("aptitudes-client: " + LocalDateTime.now());

        String baseUrl = getBaseUrl(reqContext);

        return client.target(baseUrl);
    }

    private String getBaseUrl(ReqContext reqContext) {
        return appConfigService.getConfig(reqContext.getTenantId(), TreeUnitsConfig.CONFIG_KEY, TreeUnitsConfig.class)
                .map(TreeUnitsConfig::getConfiguration)
                .map(TreeUnitsConfig.Config::getAptitudes_url)
                .orElseThrow(() ->  new RuntimeException("Could not find BaseUrl for " + reqContext.getTenantId()));
    }
}
