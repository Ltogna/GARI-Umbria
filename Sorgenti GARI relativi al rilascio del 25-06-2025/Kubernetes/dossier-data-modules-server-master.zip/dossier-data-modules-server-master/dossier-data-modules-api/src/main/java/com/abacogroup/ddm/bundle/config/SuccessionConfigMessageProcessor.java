package com.abacogroup.ddm.bundle.config;

import java.io.File;
import java.nio.file.Path;
import java.util.List;

import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang3.StringUtils;

import com.abacogroup.bundles.initializer.impl.exceptions.BundleException;
import com.abacogroup.bundles.listener.configdata.ConfigDataMessage;
import com.abacogroup.bundles.listener.configdata.ConfigMessageProcessor;
import com.abacogroup.ddm.bundle.BundleConstants;
import com.abacogroup.ddm.bundle.config.i18n.I18nHelper;
import com.abacogroup.ddm.bundle.model.SuccessionConfigDeleteListMessage;
import com.abacogroup.ddm.bundle.model.SuccessionConfigListMessage;
import com.abacogroup.ddm.bundle.model.SuccessionConfigMessage;
import com.abacogroup.ddm.bundle.model.SuccessionMessage;
import com.abacogroup.ddm.common.core.AuditHelper;
import com.abacogroup.ddm.db.dao.DAOContainer;
import com.abacogroup.ddm.db.dao.SuccessionConfigDAO;
import com.abacogroup.ddm.db.ntt.SuccessionConfigEntity;
import com.abacogroup.ddm.heirs_special_case.db.dao.SuccessionTypeDAO;
import com.abacogroup.ddm.heirs_special_case.db.ntt.SuccessionTypeEntity;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class SuccessionConfigMessageProcessor implements ConfigMessageProcessor {

	private final SuccessionConfigDAO successionConfigDAO;
	private final SuccessionTypeDAO successionTypeDAO;
	private final I18nHelper i18nHelper;

	private final ObjectMapper objectMapper = new ObjectMapper().disable(DeserializationFeature.FAIL_ON_IGNORED_PROPERTIES);

	private static final String LANG = "en";

	public SuccessionConfigMessageProcessor(DAOContainer daoContainer) {
		this.successionTypeDAO = daoContainer.getSuccessionTypeDAO();
		this.successionConfigDAO = daoContainer.getSuccessionConfigDAO();
		this.i18nHelper = new I18nHelper(daoContainer.getI18nDAO());
	}

	@Override
	public String getDomainName() {
		return "succession-config";
	}

	@Override
	public void onMessage(ConfigDataMessage message) {
		message.getConfigFiles().stream()
		.map(Path::toFile)
		.filter(file -> !file.isDirectory() && StringUtils.endsWithIgnoreCase(file.getAbsolutePath(), ".delete.json"))
		.forEach(file -> deleteSuccessionConfigMessage(message.getTenantId(), file));

		message.getConfigFiles().stream()
		.map(Path::toFile)
		.filter(file -> !file.isDirectory() && FilenameUtils.getExtension(file.getAbsolutePath()).equalsIgnoreCase("json")
				&& !StringUtils.endsWithIgnoreCase(file.getAbsolutePath(), ".delete.json"))
		.forEach(file -> insertOrUpdateSuccessionConfigMessage(message.getTenantId(), file));
	}

	private void deleteSuccessionConfigMessage(String tenantId, File file) {

		try {
			SuccessionConfigDeleteListMessage successionConfigListMessage = objectMapper.readValue(file, SuccessionConfigDeleteListMessage.class);

			if (successionConfigListMessage.getSuccessionConfigList() != null) {
				log.info("No succession_config_list found in file {}", file.getName());
				return;
			}
			successionConfigListMessage.getSuccessionConfigList().forEach(msg -> {
				try {

					SuccessionTypeEntity successionTypeEntity = getSuccessionTypeEntity(tenantId, LANG, msg.getSuccessionCode());

					if (msg.getGroups() == null || msg.getGroups().isEmpty()) {
						throw new BundleException("No groups found for Succession type " + successionTypeEntity.getCode() + " and namespace " + msg.getNamespace() + " in file " + file.getName());
					}

					msg.getGroups().stream().forEach(group-> {

						SuccessionConfigEntity existingConfig = successionConfigDAO.getSuccessionConfig(tenantId, LANG, msg.getNamespace(), successionTypeEntity.getCode(), group.getCode());

						if (existingConfig != null) {
							successionConfigDAO.expire(existingConfig.getPkid(), BundleConstants.SYSTEM_USER);
						} else {
							throw new BundleException("Succession config not found for code " + group.getCode() + "succession type " + successionTypeEntity.getCode() + " and namespace " + msg.getNamespace() + " in file " + file.getName());
						}

					});

				} catch (Exception e) {
					log.error("Error during delete operation of succession code {} and namespace {} for tenant {} in file {} : {}",  
							msg.getSuccessionCode(), msg.getNamespace(), tenantId, file.getName(), e);
				}

			});

		} catch (Exception e) {
			log.error("Error processing file {} for tenant {} : {}" + file.getName(), tenantId, e);
		}

	}

	private void insertOrUpdateSuccessionConfigMessage(String tenantId, File file) {

		try {
			SuccessionConfigListMessage successionConfigListMessage = objectMapper.readValue(file, SuccessionConfigListMessage.class);

			if (successionConfigListMessage.getSuccessionConfigList() == null) {
			}
			
			if(successionConfigListMessage.getSuccessionList() != null 
					&& !successionConfigListMessage.getSuccessionList().isEmpty()) {
				insertOrUpdateSuccessionCode(tenantId, successionConfigListMessage.getSuccessionList(), file.getName());
			} else {
				log.info("No succession list found in file {}", file.getName());
			}

			if(successionConfigListMessage.getSuccessionConfigList() != null 
					&& !successionConfigListMessage.getSuccessionConfigList().isEmpty()) {
				insertOrUpdateSuccessionConfig(tenantId, successionConfigListMessage.getSuccessionConfigList(), file.getName());
			} else {
				log.info("No succession config list found in file {}", file.getName());
			}


		} catch (Exception e) {
			log.error("Error processing file {} for tenant {} : {}" + file.getName(), tenantId, e);
		}

	}

	private void insertOrUpdateSuccessionCode(String tenantId, List<SuccessionMessage> successionList, String fileName) {			
		successionList.forEach(msg -> {
			try {
				
				SuccessionTypeEntity newEntity = SuccessionTypeEntity.builder()
						.setTenantId(tenantId)
						.setCode(msg.getCode())
						.setFlVisible(Boolean.TRUE.equals(msg.getVisible()) ? 1: 0)
						.build();

				List<SuccessionTypeEntity> successionTypes = successionTypeDAO.getSuccessionTypes(tenantId, LANG, newEntity.getCode(),
						null);
				if (successionTypes.isEmpty()) {
					successionTypeDAO.insert(newEntity);
				} else {
					successionTypeDAO.update(newEntity);
				}
				
				if(msg.getDescription() == null) {
					return;
				}
				
				i18nHelper.upsert(tenantId, "ddm_succession_types", "code", msg);
			} catch (Exception e) {
				log.error("Error during insert/update operation of succession code {} for tenant {} in file {} : {}",  
						msg.getCode(), tenantId, fileName, e);
			}

		});}

	private void insertOrUpdateSuccessionConfig(String tenantId, List<SuccessionConfigMessage> successionConfigListMessage, String fileName) {			
		successionConfigListMessage.forEach(msg -> {
			try {

				SuccessionTypeEntity successionTypeEntity = getSuccessionTypeEntity(tenantId, LANG, msg.getSuccessionCode());

				if (msg.getGroups() == null || msg.getGroups().isEmpty()) {
					throw new BundleException("No groups found for Succession type " + msg.getSuccessionCode() + " and namespace " + msg.getNamespace() + " in file " + fileName);
				}

				msg.getGroups().stream().forEach(group-> {
					SuccessionConfigEntity successionConfigEntity = SuccessionConfigEntity.builder()
							.setPkid(successionConfigDAO.nextSequenceValPkid())
							.setNamespace(msg.getNamespace())
							.setSuccessionCode(successionTypeEntity.getCode())
							.setCode(group.getCode())
							.setParentCode(group.getParentCode())
							.setAttachmentType(group.getAttachmentType() != null ? group.getAttachmentType().getCode() : null)
							.setMaxOccurrences(group.getAttachmentType() != null ? group.getAttachmentType().getMaxOccurrences() : null)
							.setFlMandatory(Boolean.TRUE.equals(group.getFlMandatory()) ? 1 : 0)
							.build();
					AuditHelper.setAuditForInsert(BundleConstants.SYSTEM_USER, successionConfigDAO, successionConfigEntity);

					SuccessionConfigEntity existingConfig = successionConfigDAO.getSuccessionConfig(tenantId, LANG, msg.getNamespace(), msg.getSuccessionCode(), group.getCode());

					if (existingConfig != null) {
						successionConfigDAO.expire(existingConfig.getPkid(), BundleConstants.SYSTEM_USER);
					}
					
					successionConfigDAO.insert(tenantId, successionConfigEntity);
					
					if(group.getAttachmentType() != null) {
						i18nHelper.upsert(tenantId, "ddm_succession_doc_config", "attachment_type", group.getAttachmentType());
					}

				});

			} catch (Exception e) {
				log.error("Error during insert/update operation of succession code {} and namespace {} for tenant {} in file {} : {}",  
						msg.getSuccessionCode(), msg.getNamespace(), tenantId, fileName, e);
			}

		});}

	private SuccessionTypeEntity getSuccessionTypeEntity(String tenantId, String lang, String successionCode) {
		List<SuccessionTypeEntity> successionTypes = successionTypeDAO.getSuccessionTypes(tenantId, lang, successionCode,
				null);
		if (successionTypes == null || successionTypes.size() != 1) {
			throw new BundleException(String.format("Succession type %s not found for tenant %s", successionCode, tenantId));
		}
		return successionTypes.get(0);
	}
}
