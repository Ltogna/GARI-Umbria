package com.abacogroup.ddm.payment.resource.pub.v1;

import static com.abacogroup.ddm.resources.PublicResourceConstants.PAYMENT_MODULE_API_V1_PUB;

import java.util.List;

import com.abacogroup.ddm.api.v1.DdmDocumentDefinitionV1;
import com.abacogroup.ddm.api.v1.DocTypeRelationResponseV1;
import com.abacogroup.ddm.common.resources.ReqContext;
import com.abacogroup.ddm.core.DocTypeService;
import com.abacogroup.ddm.payment.resource.pub.mapper.DynamicDocumentResponseMapper;
import com.abacogroup.dropwizard.auth.sso2.User;

import io.dropwizard.auth.Auth;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import io.swagger.v3.oas.annotations.tags.Tags;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DefaultValue;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.HeaderParam;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.MediaType;

@Path(PAYMENT_MODULE_API_V1_PUB + "/doc-types")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
@Tags({
		@Tag(name = "Document types PUBLIC", description = "Operations on Dynamic documents definitions"),
		@Tag(name = "Bank Account documents PUBLIC"),
		@Tag(name = "v1")
})
public class PaymentDocTypePublicResource {

	private final DocTypeService docTypeService;

	public PaymentDocTypePublicResource(DocTypeService docTypeService) {
		this.docTypeService = docTypeService;
	}

	@Operation(description = "Get the list of dynamic document types")
	@ApiResponse(responseCode = "200", description = "Get the list of dynamic document types", useReturnTypeSchema = true)
	@GET
	@Path("")
	public List<DocTypeRelationResponseV1> search(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "tenant id") @PathParam("tenant") String tenantId,
			@Parameter(description = "bank account id (business id), used to value the docPresent field")
			@QueryParam("accountId") Long accountId) {

		ReqContext reqContext = new ReqContext(user, lang);
		return DynamicDocumentResponseMapper.INSTANCE
				.toDocTypeRelationResponseV1List(docTypeService.getPaymentDocTypeRelationsByAccountId(reqContext, accountId));
	}

	@Operation(summary = "document definition", description = "Get document definition by its code")
	@ApiResponses({
			@ApiResponse(responseCode = "200", description = "Successfully, returns a document definition", useReturnTypeSchema = true),
	})
	@GET
	@Path("/{definitionCode}")
	public DdmDocumentDefinitionV1 getDefinition(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@PathParam("tenant") String tenantId,
			@PathParam("definitionCode") String definitionCode) {

		ReqContext reqContext = new ReqContext(user, lang);
		return DynamicDocumentResponseMapper.INSTANCE
				.toDdmDocumentDefinitionV1(docTypeService.getDefinition(reqContext, definitionCode));
	}
}
