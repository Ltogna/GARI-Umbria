package com.abacogroup.ddm.payment.resource;

import com.abacogroup.ddm.api.DdmAnomaliesRes;
import com.abacogroup.ddm.common.resources.ReqContext;
import com.abacogroup.ddm.common.resources.ResourceConstants;
import com.abacogroup.ddm.payment.core.PartyAnomalyService;
import com.abacogroup.dropwizard.auth.sso2.User;
import com.codahale.metrics.annotation.Timed;

import io.dropwizard.auth.Auth;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.annotation.security.RolesAllowed;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DefaultValue;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.HeaderParam;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;

@Path(ResourceConstants.PAYMENT_MODULE_API_PRIV + "/parties/{partyId}/anomalies")
@Tag(name = "Party anomalies", description = "Operations on Party anomalies")
@Tag(name = "Bank Accounts")
@Timed
@RolesAllowed({ "DDM_PAYMENT_METHODS|EDITOR", "DDM_PAYMENT_METHODS|VIEWER" })
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
public class PartyAnomalyResource {

	private final PartyAnomalyService partyAnomalyService;

	public PartyAnomalyResource(PartyAnomalyService partyAnomalyService) {
		this.partyAnomalyService = partyAnomalyService;
	}

	@GET
	@Path("/")
	@Operation(description = "Get the list of bank account anomalies on party", summary = "party anomalies")
	@ApiResponse(responseCode = "200", description = "anomalies grouped by level", content = @Content(mediaType = MediaType.APPLICATION_JSON), useReturnTypeSchema = true)
	public DdmAnomaliesRes getAnomalies(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "tenant id") @PathParam("tenant") String tenantId,
			@Parameter(description = "party id") @PathParam("partyId") Long partyId) {
		ReqContext reqContext = new ReqContext(user, lang);
		return partyAnomalyService.getAnomalies(reqContext, partyId);
	}

}
