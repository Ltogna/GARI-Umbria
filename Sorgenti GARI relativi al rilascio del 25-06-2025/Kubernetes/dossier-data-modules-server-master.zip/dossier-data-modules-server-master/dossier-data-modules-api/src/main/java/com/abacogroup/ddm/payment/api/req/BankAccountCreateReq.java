package com.abacogroup.ddm.payment.api.req;

import com.abacogroup.ddm.payment.api.BankNetworkEnum;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.experimental.SuperBuilder;

@Data
@EqualsAndHashCode(callSuper = true)
@ToString(callSuper = true)
@SuperBuilder(setterPrefix = "set")
@NoArgsConstructor
@AllArgsConstructor
public class BankAccountCreateReq extends BankAccountUpdateReq {

	@NotNull
	private BankNetworkEnum network;

	@NotBlank
	private String iban;


	private String swiftBic;
	private String bicExtraSepa;

	private String bankCountry;
	private String bankName;
	private String bankBranch;

//	private String description;
//
//	@Default
//	@NotNull
//	private Boolean defaultBankAccount = false;

	@NotNull
	private AbsoluteDate dayFrom;
	//	private AbsoluteDate dayTo;
}
