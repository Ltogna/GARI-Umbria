package com.abacogroup.ddm.payment.core.mapper;

import java.util.Optional;
import org.apache.commons.lang3.StringUtils;
import org.mapstruct.Mapper;
import org.mapstruct.Named;

@Mapper
public class StringFormatMapper {

    @Named("formatCode")
    public String formatCode(String str) {
        return Optional.ofNullable(str)
                .map(StringUtils::trimToNull)
                .map(StringUtils::upperCase)
                .orElse(null);
    }
}
