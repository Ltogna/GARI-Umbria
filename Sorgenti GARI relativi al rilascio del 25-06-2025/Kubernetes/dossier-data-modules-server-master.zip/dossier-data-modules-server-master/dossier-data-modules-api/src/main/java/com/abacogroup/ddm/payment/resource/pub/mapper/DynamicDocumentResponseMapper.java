package com.abacogroup.ddm.payment.resource.pub.mapper;

import com.abacogroup.ddm.api.DdmDocumentDefinition;
import com.abacogroup.ddm.api.DocTypeRelationRes;
import com.abacogroup.ddm.api.v1.DdmDocumentDefinitionV1;
import com.abacogroup.ddm.api.v1.DocTypeRelationResponseV1;
import java.util.List;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper
public interface DynamicDocumentResponseMapper {

	DynamicDocumentResponseMapper INSTANCE = Mappers.getMapper(DynamicDocumentResponseMapper.class);

	DocTypeRelationResponseV1 toDocTypeRelationResponseV1(DocTypeRelationRes res);
	List<DocTypeRelationResponseV1> toDocTypeRelationResponseV1List(List<DocTypeRelationRes> res);

	DdmDocumentDefinitionV1 toDdmDocumentDefinitionV1(DdmDocumentDefinition res);

}
