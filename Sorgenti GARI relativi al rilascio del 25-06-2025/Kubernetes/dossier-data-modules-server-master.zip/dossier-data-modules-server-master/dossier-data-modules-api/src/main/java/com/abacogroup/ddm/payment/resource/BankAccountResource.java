package com.abacogroup.ddm.payment.resource;

import com.abacogroup.ddm.common.resources.ReqContext;
import com.abacogroup.ddm.common.resources.ResourceConstants;
import com.abacogroup.ddm.core.exceptions.BankAccountException;
import com.abacogroup.ddm.payment.api.BankAccountSearchRes;
import com.abacogroup.ddm.payment.api.req.BankAccountCreateReq;
import com.abacogroup.ddm.payment.api.req.BankAccountPatchReq;
import com.abacogroup.ddm.payment.api.req.BankAccountSearchReq;
import com.abacogroup.ddm.payment.api.req.BankAccountUpdateReq;
import com.abacogroup.ddm.payment.core.BankAccountService;
import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.codahale.metrics.annotation.Timed;

import io.dropwizard.auth.Auth;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.media.SchemaProperty;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.annotation.security.RolesAllowed;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import jakarta.ws.rs.BeanParam;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DefaultValue;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.HeaderParam;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.MediaType;

@Path(ResourceConstants.PAYMENT_MODULE_API_PRIV + "/parties/{partyId}/accounts")
@Tag(name = "Bank Accounts", description = "Operations on Bank Accounts")
@Timed
@RolesAllowed({ "DDM_PAYMENT_METHODS|EDITOR", "DDM_PAYMENT_METHODS|VIEWER" })
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
public class BankAccountResource {

    private final BankAccountService bankAccountService;

    public BankAccountResource(BankAccountService bankAccountService) {
        this.bankAccountService = bankAccountService;
    }

    @GET
    @Path("")
    @Operation(description = "Get the list of filtered accounts", summary = "search bank accounts")
    @ApiResponse(responseCode = "200", description = "Get the list of filtered bank accounts", useReturnTypeSchema = true)
    public InfiniteListResults<BankAccountSearchRes> search(
            @HeaderParam("accept-language") @DefaultValue("en") String lang,
            @Parameter(hidden = true) @Auth User user,
            @Parameter(description = "tenant id") @PathParam("tenant") String tenantId,
            @Parameter(description = "party id") @PathParam("partyId") Long partyId,
            @Parameter(description = "Next key used for infinite pagination") @QueryParam("nextKey") String nextKey,
            @BeanParam @Valid BankAccountSearchReq searchReq) {

        return bankAccountService.search(new ReqContext(user, lang), partyId, searchReq, nextKey);
    }

    @GET
    @Path("/{accountId}")
    @Operation(description = "Get a bank account by id", summary = "get a bank account")
    @ApiResponse(responseCode = "200", description = "The bank account", useReturnTypeSchema = true)
    @ApiResponse(responseCode = "204", description = "bank account not found")
    public BankAccountSearchRes getById(
            @HeaderParam("accept-language") @DefaultValue("en") String lang,
            @Parameter(hidden = true) @Auth User user,
            @Parameter(description = "tenant id") @PathParam("tenant") String tenantId,
            @Parameter(description = "party id") @PathParam("partyId") Long partyId,
            @Parameter(description = "accountId") @PathParam("accountId") Long accountId) {

        return bankAccountService.getById(new ReqContext(user, lang), partyId, accountId)
                .orElse(null);
    }

    @GET
    @Path("/default")
    @Operation(description = "Get active default bank account", summary = "get default bank account")
    @ApiResponse(responseCode = "200", description = "The bank account", useReturnTypeSchema = true)
    @ApiResponse(responseCode = "204", description = "bank account not found")
    public BankAccountSearchRes getActiveDefault(
            @HeaderParam("accept-language") @DefaultValue("en") String lang,
            @Parameter(hidden = true) @Auth User user,
            @Parameter(description = "tenant id") @PathParam("tenant") String tenantId,
            @Parameter(description = "party id") @PathParam("partyId") Long partyId) {

        return bankAccountService.getActiveDefault(new ReqContext(user, lang), partyId)
                .orElse(null);
    }

    @POST
    @Path("")
    @RolesAllowed("DDM_PAYMENT_METHODS|EDITOR")
    @Operation(description = "Create a new bank account", summary = "create new bank account")
    @ApiResponse(responseCode = "200", description = "The created bank account", useReturnTypeSchema = true)
    @ApiResponse(responseCode = "400", description = "bank account creation error", content = @Content(mediaType = MediaType.APPLICATION_JSON, schema = @Schema(implementation = BankAccountException.ErrorBody.class)))
    @ApiResponse(responseCode = "422", description = "unprocessable content", content = @Content(mediaType = MediaType.APPLICATION_JSON, schemaProperties = @SchemaProperty(name = "errors", array = @ArraySchema(schema = @Schema(implementation = String.class)))))
    public BankAccountSearchRes addAccount(
            @HeaderParam("accept-language") @DefaultValue("en") String lang,
            @Parameter(hidden = true) @Auth User user,
            @Parameter(description = "tenant id") @PathParam("tenant") String tenantId,
            @Parameter(description = "party id") @PathParam("partyId") Long partyId,
            @NotNull @Valid BankAccountCreateReq bankAccountCreateReq) {

        ReqContext reqContext = new ReqContext(user, lang);
        return bankAccountService.insert(reqContext, partyId, bankAccountCreateReq);
    }

    @PUT
    @Path("/{accountId}")
    @RolesAllowed("DDM_PAYMENT_METHODS|EDITOR")
    @Operation(description = "Update a bank account by id", summary = "update a bank account")
    @ApiResponse(responseCode = "200", description = "The update bank account", useReturnTypeSchema = true)
    @ApiResponse(responseCode = "400", description = "bank account update error", content = @Content(mediaType = MediaType.APPLICATION_JSON, schema = @Schema(implementation = BankAccountException.ErrorBody.class)))
    public BankAccountSearchRes updateAccount(
            @HeaderParam("accept-language") @DefaultValue("en") String lang,
            @Parameter(hidden = true) @Auth User user,
            @Parameter(description = "tenant id") @PathParam("tenant") String tenantId,
            @Parameter(description = "party id") @PathParam("partyId") Long partyId,
            @Parameter(description = "accountId") @PathParam("accountId") Long accountId,
            @NotNull @Valid BankAccountUpdateReq bankAccountUpdateReq) {

        ReqContext reqContext = new ReqContext(user, lang);
        return bankAccountService.update(reqContext, partyId, accountId, bankAccountUpdateReq);
    }

    @PUT
    @Path("/{accountId}/day-to")
    @RolesAllowed("DDM_PAYMENT_METHODS|EDITOR")
    @Operation(description = "update the day-to value", summary = "update the day-to value")
    @ApiResponse(responseCode = "200", description = "The updated bank account", useReturnTypeSchema = true)
    @ApiResponse(responseCode = "400", description = "bank account update error", content = @Content(mediaType = MediaType.APPLICATION_JSON, schema = @Schema(implementation = BankAccountException.ErrorBody.class)))
    @ApiResponse(responseCode = "422", description = "unprocessable content", content = @Content(mediaType = MediaType.APPLICATION_JSON, schemaProperties = @SchemaProperty(name = "errors", array = @ArraySchema(schema = @Schema(implementation = String.class)))))
    public BankAccountSearchRes updateAccountDayTo(
            @HeaderParam("accept-language") @DefaultValue("en") String lang,
            @Parameter(hidden = true) @Auth User user,
            @Parameter(description = "tenant id") @PathParam("tenant") String tenantId,
            @Parameter(description = "party id") @PathParam("partyId") Long partyId,
            @Parameter(description = "accountId") @PathParam("accountId") Long accountId,
            @NotNull @Valid BankAccountPatchReq bankAccountPatchReq) {

        ReqContext reqContext = new ReqContext(user, lang);
        return bankAccountService.updateDayTo(reqContext, partyId, accountId, bankAccountPatchReq.getDayTo());
    }

}
