package com.abacogroup.ddm.resources;

import java.util.List;

import com.abacogroup.ddm.api.AppConfigRes;
import com.abacogroup.ddm.common.resources.ReqContext;
import com.abacogroup.ddm.common.resources.ResourceConstants;
import com.abacogroup.ddm.core.AppConfigService;
import com.abacogroup.ddm.core.dto.appconfig.PaymentDefaultAccount;
import com.abacogroup.ddm.core.dto.appconfig.PaymentRegexValidation;
import com.abacogroup.dropwizard.auth.sso2.User;
import com.codahale.metrics.annotation.Timed;

import io.dropwizard.auth.Auth;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.annotation.security.RolesAllowed;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DefaultValue;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.HeaderParam;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;

@Path(ResourceConstants.API_PRIV + "/configurations")
@Tag(name = "configurations", description = "Operations on the application configurations")
@Timed
@RolesAllowed({ "DDM_DOSSIER|VIEWER", "DDM_PAYMENT_METHODS|VIEWER", "DDM_PAYMENT_METHODS|EDITOR" })
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
public class AppConfigResource {

    private final AppConfigService appConfigService;

    public AppConfigResource(AppConfigService appConfigService) {
        this.appConfigService = appConfigService;
    }

    @Operation(summary = "List of configurations", description = "Get list of all the app configurations")
    @ApiResponse(responseCode = "200", description = "Successfully, returns a list of configurations", content = @Content(mediaType = "application/json"), useReturnTypeSchema = true)
    @GET
    public List<AppConfigRes> search(
            @HeaderParam("accept-language") @DefaultValue("en") String lang,
            @Parameter(hidden = true) @Auth User user,
            @Parameter(description = "tenant ID") @PathParam("tenant") String tenantId) {

        ReqContext reqContext = new ReqContext(user, lang);
        return appConfigService.searchAll(reqContext);
    }

    @Operation(summary = "Find configuration by key", description = "Get a specific configuration by key")
    @ApiResponse(responseCode = "200", description = "Successfully, configuration is found", content = @Content(mediaType = "application/json"), useReturnTypeSchema = true)
    @GET
    @Path("/{key}")
    public AppConfigRes getByKey(
            @HeaderParam("accept-language") @DefaultValue("en") String lang,
            @Parameter(hidden = true) @Auth User user,
            @Parameter(description = "tenant ID") @PathParam("tenant") String tenantId,
            @Parameter(description = "the configuration key", schema = @Schema(allowableValues = {
                    PaymentDefaultAccount.CONFIG_KEY, PaymentRegexValidation.CONFIG_KEY
            })) @PathParam("key") String key) {

        ReqContext reqContext = new ReqContext(user, lang);
        return appConfigService.searchByKey(reqContext, key).orElse(null);
    }

}
