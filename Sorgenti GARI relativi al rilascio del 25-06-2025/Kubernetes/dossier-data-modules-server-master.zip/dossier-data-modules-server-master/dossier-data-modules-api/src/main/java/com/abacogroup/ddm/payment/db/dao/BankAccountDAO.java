package com.abacogroup.ddm.payment.db.dao;

import com.abacogroup.ddm.common.resources.ReqContext;
import com.abacogroup.ddm.payment.api.BankAccountRes;
import com.abacogroup.ddm.payment.api.BankAccountSearchRes;
import com.abacogroup.ddm.payment.db.ntt.BankAccountEntity;
import com.abacogroup.jdbi.EnhancedSqlObject;
import com.abacogroup.jdbi.criteria.BindCriteria;
import com.abacogroup.jdbi.criteria.Criteria;
import com.abacogroup.jdbi.orderby.DefineOrder;
import com.abacogroup.jdbi.orderby.OrderBy;
import java.util.function.Consumer;
import org.jdbi.v3.core.result.ResultIterator;
import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.customizer.BindBean;
import org.jdbi.v3.sqlobject.statement.GetGeneratedKeys;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;
import org.jdbi.v3.sqlobject.transaction.Transactional;
import java.util.List;
import java.util.Optional;


public interface BankAccountDAO extends Transactional<BankAccountDAO>, EnhancedSqlObject {

	@SqlQuery("§select_nextval(ddm_bank_account_id_seq)§")
	Long issuePk();


	@SqlUpdate("INSERT INTO ddm_bank_account (id, tenant_id, party_id ) VALUES (:sequenceId, :tenantId, :partyId)")
	void insertMasterRow(@Bind("sequenceId") Long id, @BindBean BankAccountEntity entity);

	/**
	 * usato SOLO in creazione
	 */
	@SqlUpdate(
			"INSERT INTO ddm_bank_account_detail (pkid, id, " +
					"network, iban, swift_bic, bic_extra_sepa, " +
					"bank_country, bank_name, bank_branch, description, " +
					"fl_default, day_from, day_to, " +
					"dt_insert, user_id_insert, dt_delete, user_id_delete) " +
					"VALUES (:pkid, :pkid, " +  // PKID x2
					":network, :iban, :swiftBic, :bicExtraSepa, " +
					":bankCountry, :bankName, :bankBranch, :description, " +
					":flDefault, :dayFrom, :dayTo, " +
					":dtInsert, :userIdInsert, :dtDelete, :userIdDelete)")
	void insertDetailRow(@BindBean BankAccountEntity entity, @Bind("pkid") Long pkid);


	@SqlUpdate(
			"INSERT INTO ddm_bank_account_detail (id, " +
					"network, iban, swift_bic, bic_extra_sepa, " +
					"bank_country, bank_name, bank_branch, description, " +
					"fl_default, day_from, day_to, " +
					"dt_insert, user_id_insert, dt_delete, user_id_delete) " +
					"VALUES (:id, " +
					":network, :iban, :swiftBic, :bicExtraSepa, " +
					":bankCountry, :bankName, :bankBranch, :description, " +
					":flDefault, :dayFrom, :dayTo, " +
					":dtInsert, :userIdInsert, :dtDelete, :userIdDelete)")
	@GetGeneratedKeys("pkid")
	long insertVersionRow(@BindBean BankAccountEntity entity);

	@SqlUpdate("update ddm_bank_account_detail set " +
			"dt_delete =:dtDelete, user_id_delete=:userIdDelete where pkid = :pkid")
	void expireRow(@BindBean BankAccountEntity entity);


	@SqlQuery("select bad.pkid, ba.id, ba.tenant_id, ba.party_id, network, "
			+ "bad.iban, bad.swift_bic, bad.bic_extra_sepa, "
			+ "bad.bank_country, bad.bank_name, bad.bank_branch, bad.description, "
			+ "bad.fl_default, bad.day_from, bad.day_to, "
			+ "bad.dt_insert, bad.user_id_insert, bad.dt_delete, bad.user_id_delete "
			+ "from ddm_bank_account ba "
			+ " inner join ddm_bank_account_detail bad on  ba.id = bad.id  "
			+ " WHERE ba.tenant_id = :tenantId "
			+ "and ba.id = :id "
			+ " AND (§current_timestamp§ between bad.dt_insert and bad.dt_delete) ")
	@RegisterBeanMapper(BankAccountEntity.class)
	Optional<BankAccountEntity> findById(
			@Bind("tenantId") String tenantId,
			@Bind("id") Long id
	);

	@SqlQuery("select bad.pkid, ba.id, ba.tenant_id, ba.party_id, network, "
			+ "bad.iban, bad.swift_bic, bad.bic_extra_sepa, "
			+ "bad.bank_country, bad.bank_name, bad.bank_branch, bad.description, "
			+ "bad.fl_default, bad.day_from, bad.day_to, "
			+ "bad.dt_insert, bad.user_id_insert, bad.dt_delete, bad.user_id_delete "
			+ "from ddm_bank_account ba "
			+ " inner join ddm_bank_account_detail bad on  ba.id = bad.id  "
			+ " WHERE ba.tenant_id = :tenantId "
			+ "and ba.party_id = :partyId "
			+ "and ba.id = :id "
			+ " AND (§current_timestamp§ between bad.dt_insert and bad.dt_delete) ")
	@RegisterBeanMapper(BankAccountEntity.class)
	Optional<BankAccountEntity> findById(
			@Bind("tenantId") String tenantId,
			@Bind("partyId") Long partyId,
			@Bind("id") Long id
	);

	@SqlQuery("select bad.pkid, ba.id, ba.tenant_id, ba.party_id, network, "
			+ "bad.iban, bad.swift_bic, bad.bic_extra_sepa, "
			+ "bad.bank_country, bad.bank_name, bad.bank_branch, bad.description, "
			+ "bad.fl_default as defaultBankAccount, bad.day_from, bad.day_to, "
			+ "bad.dt_insert, bad.user_id_insert, bad.dt_delete, bad.user_id_delete "
			+ "from ddm_bank_account ba "
			+ " inner join ddm_bank_account_detail bad on  ba.id = bad.id  "
			+ " WHERE ba.tenant_id = :tenantId "
			+ "and ba.party_id = :partyId "
			+ "and <criteria> "
			+ " AND (§current_timestamp§ between bad.dt_insert and bad.dt_delete) "
			+ " ORDER BY <orderBy> ")
	@RegisterBeanMapper(BankAccountSearchRes.class)
	ResultIterator<BankAccountSearchRes> search(
			@Bind("partyId") Long partyId,
			@BindCriteria Criteria criteria,
			@DefineOrder OrderBy orderBy,
			@BindBean ReqContext ctx
	);

	@SqlUpdate("update ddm_bank_account_detail set " +
			"fl_default = 0 where pkid in (" +
			"select pkid from ddm_bank_account_detail d inner join  ddm_bank_account b on d.id = b.id " +
			"where b.tenant_id = :tenantId " +
			"and b.party_id = :partyId " +
			"AND (§current_timestamp§ between d.dt_insert and d.dt_delete) " +
			"and d.id not in (:id)" +
			" )")
	void setDefaultAndUpdateOthers(@BindBean BankAccountEntity entity,
								   @BindBean ReqContext ctx);

	@SqlQuery("select bad.pkid, ba.id, ba.tenant_id, ba.party_id, network, "
			+ "bad.iban, bad.swift_bic, bad.bic_extra_sepa, "
			+ "bad.bank_country, bad.bank_name, bad.bank_branch, bad.description, "
			+ "bad.fl_default, bad.day_from, bad.day_to, "
			+ "bad.dt_insert, bad.user_id_insert, bad.dt_delete, bad.user_id_delete "
			+ "from ddm_bank_account ba "
			+ " inner join ddm_bank_account_detail bad on  ba.id = bad.id  "
			+ " WHERE ba.tenant_id = :tenantId "
			+ "and ba.party_id = :partyId "
			+ "and bad.fl_default = 1 "
			+ "and (day_to > :refDate AND day_from <= :refDate) "
			+ " AND (§current_timestamp§ between bad.dt_insert and bad.dt_delete) ")
	@RegisterBeanMapper(BankAccountEntity.class)
	Optional<BankAccountEntity> findDefault(
			@Bind("tenantId") String tenantId,
			@Bind("partyId") Long partyId,
			@Bind("refDate") String refDate
	);

	@SqlQuery("select bad.pkid, ba.id, ba.tenant_id, ba.party_id, network, "
			+ "bad.iban, bad.swift_bic, bad.bic_extra_sepa, "
			+ "bad.bank_country, bad.bank_name, bad.bank_branch, bad.description, "
			+ "bad.fl_default, bad.day_from, bad.day_to, "
			+ "bad.dt_insert, bad.user_id_insert, bad.dt_delete, bad.user_id_delete "
			+ "from ddm_bank_account ba "
			+ " inner join ddm_bank_account_detail bad on  ba.id = bad.id  "
			+ " WHERE ba.tenant_id = :tenantId "
			+ "and bad.iban = :iban "
			+ "and (day_to > :refDate AND day_from <= :refDate) "
			+ " AND (§current_timestamp§ between bad.dt_insert and bad.dt_delete) ")
	@RegisterBeanMapper(BankAccountEntity.class)
	ResultIterator<BankAccountEntity> findByIban(
			@Bind("tenantId") String tenantId,
			@Bind("iban") String iban,
			@Bind("refDate") String refDate
	);

	@SqlQuery("select bad.pkid, ba.id, ba.tenant_id, ba.party_id, network, "
			+ "bad.iban, bad.swift_bic, bad.bic_extra_sepa, "
			+ "bad.bank_country, bad.bank_name, bad.bank_branch, bad.description, "
			+ "bad.fl_default, bad.day_from, bad.day_to, "
			+ "bad.dt_insert, bad.user_id_insert, bad.dt_delete, bad.user_id_delete "
			+ "from ddm_bank_account ba "
			+ " inner join ddm_bank_account_detail bad on  ba.id = bad.id  "
			+ " WHERE ba.tenant_id = :tenantId "
			+ "and upper(coalesce(bad.iban, '') || coalesce(bad.swift_bic, '') || coalesce(bad.bic_extra_sepa, '')) = "
			+ "upper(coalesce(:iban, '') || coalesce(:swiftBic, '') || coalesce(:bicExtraSepa, '')) "
			+ "and (day_to > :refDate AND day_from <= :refDate) "
			+ " AND (§current_timestamp§ between bad.dt_insert and bad.dt_delete) ")
	@RegisterBeanMapper(BankAccountEntity.class)
	List<BankAccountEntity> findByIbanConcat(
			@Bind("tenantId") String tenantId,
			@Bind("iban") String iban,
			@Bind("swiftBic") String swiftBic,
			@Bind("bicExtraSepa") String bicExtraSepa,
			@Bind("refDate") String refDate
	);

	@SqlQuery("select bad.pkid, ba.id, ba.tenant_id, ba.party_id, network, "
			+ "bad.iban, bad.swift_bic, bad.bic_extra_sepa, "
			+ "bad.bank_country, bad.bank_name, bad.bank_branch, bad.description, "
			+ "bad.fl_default, bad.day_from, bad.day_to, "
			+ "bad.dt_insert, bad.user_id_insert, bad.dt_delete, bad.user_id_delete "
			+ "from ddm_bank_account ba "
			+ " inner join ddm_bank_account_detail bad on  ba.id = bad.id  "
			+ " WHERE ba.tenant_id = :tenantId "
			+ " and ba.party_id = :partyId "
			+ "and upper(coalesce(bad.iban, '') || coalesce(bad.swift_bic, '') || coalesce(bad.bic_extra_sepa, '')) = "
			+ "upper(coalesce(:iban, '') || coalesce(:swiftBic, '') || coalesce(:bicExtraSepa, '')) "
			+ "and (day_to > :refDate AND day_from <= :refDate) "
			+ " AND (§current_timestamp§ between bad.dt_insert and bad.dt_delete) ")
	@RegisterBeanMapper(BankAccountEntity.class)
	List<BankAccountEntity> findByIbanConcat(
			@Bind("tenantId") String tenantId,
			@Bind("iban") String iban,
			@Bind("swiftBic") String swiftBic,
			@Bind("bicExtraSepa") String bicExtraSepa,
			@Bind("partyId") Long partyId,
			@Bind("refDate") String refDate
	);

	@SqlQuery("select count(ba.id) "
			+ "from ddm_bank_account ba "
			+ " inner join ddm_bank_account_detail bad on  ba.id = bad.id  "
			+ " WHERE ba.tenant_id = :tenantId "
			+ "and ba.party_id = :partyId "
			+ "and (day_to > :refDate AND day_from <= :refDate) "
			+ " AND (§current_timestamp§ between bad.dt_insert and bad.dt_delete) ")
	@RegisterBeanMapper(BankAccountEntity.class)
	Long countByPartyId(
			@Bind("tenantId") String tenantId,
			@Bind("partyId") Long partyId,
			@Bind("refDate") String refDate
	);

	@SqlQuery("select bad.pkid, ba.id, ba.tenant_id, ba.party_id, network, "
			+ "bad.iban, bad.swift_bic, bad.bic_extra_sepa, "
			+ "bad.bank_country, bad.bank_name, bad.bank_branch, bad.description, "
			+ "bad.fl_default, bad.day_from, bad.day_to, "
			+ "bad.dt_insert, bad.user_id_insert, bad.dt_delete, bad.user_id_delete "
			+ "from ddm_bank_account ba "
			+ " inner join ddm_bank_account_detail bad on  ba.id = bad.id  "
			+ " WHERE ba.tenant_id = :tenantId "
			+ "and ba.party_id = :partyId "
			+ "and (day_to > :refDate AND day_from <= :refDate) "
			+ " AND (§current_timestamp§ between bad.dt_insert and bad.dt_delete) ")
	@RegisterBeanMapper(BankAccountEntity.class)
	void consumeByPartyId(
			@Bind("tenantId") String tenantId,
			@Bind("partyId") Long partyId,
			@Bind("refDate") String refDate,
			Consumer<BankAccountEntity> consumer
	);

}


