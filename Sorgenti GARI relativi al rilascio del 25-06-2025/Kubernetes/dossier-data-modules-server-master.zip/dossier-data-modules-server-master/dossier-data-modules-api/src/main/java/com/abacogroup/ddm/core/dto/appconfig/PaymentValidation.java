package com.abacogroup.ddm.core.dto.appconfig;

import com.abacogroup.ddm.core.dto.appconfig.PaymentValidation.Config;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.experimental.SuperBuilder;

@Deprecated
@Data
@EqualsAndHashCode(callSuper = true)
@ToString(callSuper = true)
@SuperBuilder(setterPrefix = "set")
@AllArgsConstructor
@NoArgsConstructor
public class PaymentValidation extends BaseAppConfig<Config> {

	public static final String CONFIG_KEY = "payment_validation";

	@Valid
	@NotNull
	private Config configuration;

	@Data
	@Builder(setterPrefix = "set")
	@NoArgsConstructor
	@AllArgsConstructor
	@Schema(name = "PaymentValidationConfig")
	public static class Config {
		@NotNull
		private Boolean active;

		@NotBlank
		@JsonProperty("validation_url")
		private String validationUrl;
	}

}
