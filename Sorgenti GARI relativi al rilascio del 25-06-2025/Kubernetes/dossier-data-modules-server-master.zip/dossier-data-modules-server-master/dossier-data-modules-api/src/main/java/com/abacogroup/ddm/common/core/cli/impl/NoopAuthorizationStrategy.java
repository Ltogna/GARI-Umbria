package com.abacogroup.ddm.common.core.cli.impl;

import com.abacogroup.ddm.common.core.cli.AuthorizationStrategy;
import com.abacogroup.dropwizard.auth.sso2.User;

public class NoopAuthorizationStrategy implements AuthorizationStrategy {

	@Override
	public String getAuthorization(User user) {
		return null;
	}

}
