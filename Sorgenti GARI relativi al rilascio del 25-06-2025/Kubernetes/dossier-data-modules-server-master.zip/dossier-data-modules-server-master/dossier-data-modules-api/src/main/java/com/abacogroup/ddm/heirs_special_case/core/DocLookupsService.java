package com.abacogroup.ddm.heirs_special_case.core;

import java.util.List;

import com.abacogroup.ddm.common.resources.ReqContext;
import com.abacogroup.ddm.heirs_special_case.api.AttachmentTypeRes;
import com.abacogroup.ddm.heirs_special_case.api.SuccessionTypeRes;

import jakarta.validation.constraints.NotBlank;

public interface DocLookupsService {

	List<SuccessionTypeRes> getSuccessionTypeList(ReqContext reqContext, String successionCode);

	List<AttachmentTypeRes> getAttachmentTypeList(ReqContext reqContext, String namespace, @NotBlank String successionCode, String attachmentCode);

	AttachmentTypeRes getAttachmentTypeByCode(ReqContext reqContext, String namespace, String attachmentCode);

}
