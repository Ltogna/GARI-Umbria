package com.abacogroup.ddm.heirs_special_case.resource.pub.v1;
import static com.abacogroup.ddm.DossierDataModulesApplication.HEIR_MODULE;
import static com.abacogroup.ddm.resources.PublicResourceConstants.HEIR_MODULE_API_V1_PUB;

import java.util.List;
import java.util.stream.Collectors;

import com.abacogroup.ddm.common.resources.ReqContext;
import com.abacogroup.ddm.core.exceptions.HeirException;
import com.abacogroup.ddm.core.exceptions.HeirException.ErrEnum;
import com.abacogroup.ddm.heirs_special_case.api.v1.AttachmentTypeLookupResponseV1;
import com.abacogroup.ddm.heirs_special_case.api.v1.SuccessionTypeLookupResponseV1;
import com.abacogroup.ddm.heirs_special_case.core.DocLookupsService;
import com.abacogroup.ddm.heirs_special_case.resource.pub.mapper.AttachmentTypeResponseMapper;
import com.abacogroup.ddm.heirs_special_case.resource.pub.mapper.SuccessionTypeResponseMapper;
import com.abacogroup.dropwizard.auth.sso2.User;
import com.codahale.metrics.annotation.Timed;

import io.dropwizard.auth.Auth;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.annotation.security.RolesAllowed;
import jakarta.validation.constraints.NotBlank;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DefaultValue;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.HeaderParam;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.MediaType;

@Path(HEIR_MODULE_API_V1_PUB + "/doc-types/lookups")
@Tag(name = "Doc type lookup PUBLIC", description = "Operations on doc type lookups")
@Tag(name = "v1")
@Timed
@RolesAllowed({ "DDM_HEIR_METHODS|EDITOR", "DDM_HEIR_METHODS|VIEWER" })
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
public class DocLookupsPublicResource {

	private final DocLookupsService docLookupsService;

	public DocLookupsPublicResource(DocLookupsService successionTypeService) {
		this.docLookupsService = successionTypeService;
	}

	@GET
	@Path("/successions")
	@Operation(description = "Get the list of Succession types", summary = "search Succession types")
	@ApiResponse(responseCode = "200", description = "Get the list of Succession types", useReturnTypeSchema = true)
	public List<SuccessionTypeLookupResponseV1> searchSuccessionType(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "tenant id") @PathParam("tenant") String tenantId) {

		return docLookupsService.getSuccessionTypeList(new ReqContext(user, lang), null).stream()
				.map(SuccessionTypeResponseMapper.INSTANCE::toResponseV1)
				.collect(Collectors.toList());
	}

	@GET
	@Path("/successions/{successionCode}")
	@Operation(description = "Get the list of Succession types", summary = "search Succession types")
	@ApiResponse(responseCode = "200", description = "Get the list of Succession types", useReturnTypeSchema = true)
	public SuccessionTypeLookupResponseV1 getSuccessionType(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "tenant id") @PathParam("tenant") String tenantId,
			@Parameter(description = "Succession code") @PathParam("successionCode") String successionCode) {

		return docLookupsService.getSuccessionTypeList(new ReqContext(user, lang), successionCode).stream()
				.filter(successionType -> successionType.getCode().equals(successionCode))
				.findFirst()
				.map(SuccessionTypeResponseMapper.INSTANCE::toResponseV1)
				.orElseThrow(() -> new HeirException(ErrEnum.SUCC_TYPE_NOT_FOUND, String.format("Succession type with code %s not found", successionCode)));
	}

	@GET
	@Path("/attachment-types")
	@Operation(description = "Get the list of attachment types", summary = "search attachment types")
	@ApiResponse(responseCode = "200", description = "Get the list of attachment types", useReturnTypeSchema = true)
	public List<AttachmentTypeLookupResponseV1> searchAttachmentTypes(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "tenant id") @PathParam("tenant") String tenantId,
			@Parameter(description = "Succession code") @QueryParam("successionCode") @NotBlank String successionCode) {

		return docLookupsService.getAttachmentTypeList(new ReqContext(user, lang), HEIR_MODULE, successionCode, null).stream()
				.map(AttachmentTypeResponseMapper.INSTANCE::toResponseV1)
				.collect(Collectors.toList());
	}

	@GET
	@Path("/attachment-types/{attachmentCode}")
	@Operation(description = "Get the attachment type", summary = "search attachment types")
	@ApiResponse(responseCode = "200", description = "Get attachment type", useReturnTypeSchema = true)
	public AttachmentTypeLookupResponseV1 getAttachmentType(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "tenant id") @PathParam("tenant") String tenantId,
			@Parameter(description = "Attachment code") @PathParam("attachmentCode") String attachmentCode) {

		return AttachmentTypeResponseMapper.INSTANCE.toResponseV1(docLookupsService.getAttachmentTypeByCode(new ReqContext(user, lang), HEIR_MODULE, attachmentCode));
	}

}
