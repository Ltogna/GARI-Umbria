package com.abacogroup.ddm.bundle.model;

import java.util.Set;

import com.abacogroup.ddm.bundle.config.i18n.I18nAware;
import com.abacogroup.ddm.bundle.config.i18n.I18nEntry;
import com.abacogroup.ddm.bundle.config.i18n.I18nMap;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder(setterPrefix = "set")
@NoArgsConstructor
@AllArgsConstructor
public class SuccessionMessage implements I18nAware {

		private String code;
		
		@Builder.Default
		private Boolean visible = true;
		
		@Builder.Default
		private I18nMap description = new I18nMap();
		
	@Override
	public String getI18nCode() {
		return code;
	}

	@Override
	public Set<I18nEntry> getI18n() {
		return description.getI18n();
	}
	
}
