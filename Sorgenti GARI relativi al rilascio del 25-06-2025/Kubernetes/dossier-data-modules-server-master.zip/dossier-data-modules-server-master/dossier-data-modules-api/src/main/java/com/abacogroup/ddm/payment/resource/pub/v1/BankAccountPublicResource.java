package com.abacogroup.ddm.payment.resource.pub.v1;

import static com.abacogroup.ddm.resources.PublicResourceConstants.PAYMENT_MODULE_API_V1_PUB;

import java.time.LocalDate;

import com.abacogroup.ddm.api.v1.PartyDetailResponseV1;
import com.abacogroup.ddm.common.resources.ReqContext;
import com.abacogroup.ddm.payment.api.req.BankAccountSearchReq;
import com.abacogroup.ddm.payment.api.v1.BankAccountSearchResponseV1;
import com.abacogroup.ddm.payment.api.v1.req.BankAccountSearchRequestV1;
import com.abacogroup.ddm.payment.core.BankAccountService;
import com.abacogroup.ddm.payment.resource.pub.mapper.BankAccountResponseMapper;
import com.abacogroup.ddm.payment.resource.pub.mapper.BankAccountSearchRequestMapper;
import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.codahale.metrics.annotation.Timed;

import io.dropwizard.auth.Auth;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.annotation.security.RolesAllowed;
import jakarta.validation.Valid;
import jakarta.ws.rs.BeanParam;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DefaultValue;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.HeaderParam;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.MediaType;

@Path(PAYMENT_MODULE_API_V1_PUB)
@Tag(name = "Bank Accounts PUBLIC", description = "Operations on Bank Accounts")
@Tag(name = "v1")
@Timed
@RolesAllowed({ "DDM_PAYMENT_METHODS|EDITOR", "DDM_PAYMENT_METHODS|VIEWER" })
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
public class BankAccountPublicResource {

	private final BankAccountService bankAccountService;

	public BankAccountPublicResource(BankAccountService bankAccountService) {
		this.bankAccountService = bankAccountService;
	}

	@GET
	@Path("/parties/{partyId}/accounts")
	@Operation(description = "Get the list of filtered accounts", summary = "search bank accounts")
	@ApiResponse(responseCode = "200", description = "Get the list of filtered bank accounts", useReturnTypeSchema = true)
	public InfiniteListResults<BankAccountSearchResponseV1> search(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "tenant id") @PathParam("tenant") String tenantId,
			@Parameter(description = "party id") @PathParam("partyId") Long partyId,
			@Parameter(description = "Next key used for infinite pagination") @QueryParam("nextKey") String nextKey,
			@BeanParam @Valid BankAccountSearchRequestV1 searchRequestV1) {

		ReqContext reqContext = new ReqContext(user, lang);
		BankAccountSearchReq searchReq = BankAccountSearchRequestMapper.INSTANCE.toSearchReq(searchRequestV1);

		return bankAccountService.search(reqContext, partyId, searchReq, nextKey)
				.map(BankAccountResponseMapper.INSTANCE::toSearchResponseV1);
	}

	@GET
	@Path("/parties/{partyId}/accounts/{accountId}")
	@Operation(description = "Get a bank account by id", summary = "get a bank account")
	@ApiResponse(responseCode = "200", description = "The bank account", useReturnTypeSchema = true)
	@ApiResponse(responseCode = "204", description = "bank account not found")
	public BankAccountSearchResponseV1 getById(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "tenant id") @PathParam("tenant") String tenantId,
			@Parameter(description = "party id") @PathParam("partyId") Long partyId,
			@Parameter(description = "accountId") @PathParam("accountId") Long accountId) {

		return bankAccountService.getById(new ReqContext(user, lang), partyId, accountId)
				.map(BankAccountResponseMapper.INSTANCE::toSearchResponseV1)
				.orElse(null);
	}

	@GET
	@Path("/parties/{partyId}/accounts/default")
	@Operation(description = "Get active default bank account", summary = "fet default bank account")
	@ApiResponse(responseCode = "200", description = "The bank account", useReturnTypeSchema = true)
	@ApiResponse(responseCode = "204", description = "bank account not found")
	public BankAccountSearchResponseV1 getActiveDefault(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "tenant id") @PathParam("tenant") String tenantId,
			@Parameter(description = "party id") @PathParam("partyId") Long partyId) {

		return bankAccountService.getActiveDefault(new ReqContext(user, lang), partyId)
				.map(BankAccountResponseMapper.INSTANCE::toSearchResponseV1)
				.orElse(null);
	}

	@GET
	@Path("/iban/{iban}/parties")
	@Operation(description = "Get list of parties that have given IBAN registered")
	public InfiniteListResults<PartyDetailResponseV1> getListOfPartiesGivenTheIBAN(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "tenant id") @PathParam("tenant") String tenantId,
			@Parameter(description = "iban") @PathParam("iban") String iban,
			@Parameter(description = "Reference date") @QueryParam("referenceDate") String referenceDate,
			@Parameter(description = "Next key used for infinite pagination") @QueryParam("nextKey") String nextKey) {

		if (referenceDate == null)
			referenceDate = LocalDate.now().toString();

		return bankAccountService.getByIban(new ReqContext(user, lang), iban, referenceDate, nextKey);
	}

}
