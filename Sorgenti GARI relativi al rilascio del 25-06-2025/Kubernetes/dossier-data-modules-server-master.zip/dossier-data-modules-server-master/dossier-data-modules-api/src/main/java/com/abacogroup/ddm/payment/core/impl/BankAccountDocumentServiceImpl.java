package com.abacogroup.ddm.payment.core.impl;

import static com.abacogroup.ddm.DossierDataModulesApplication.PAYMENT_MODULE;
import static com.abacogroup.ddm.core.exceptions.InvalidDocumentException.ErrEnum.DYNAMIC_DOCUMENT_FILE_NOT_FOUND;
import static com.abacogroup.ddm.core.exceptions.InvalidDocumentException.ErrEnum.DYNAMIC_DOCUMENT_NOT_FOUND;

import com.abacogroup.anomalyregistry.core.cli.v1.AnomalyClient;
import com.abacogroup.ddm.common.core.AuditHelper;
import com.abacogroup.ddm.common.resources.ReqContext;
import com.abacogroup.ddm.core.cli.FileStoreProxyClient;
import com.abacogroup.ddm.core.exceptions.BankAccountException;
import com.abacogroup.ddm.core.exceptions.InvalidDocumentException;
import com.abacogroup.ddm.core.exceptions.InvalidDocumentException.ErrEnum;
import com.abacogroup.ddm.db.dao.DocTypeRelationDAO;
import com.abacogroup.ddm.payment.api.BankAccountDocumentRes;
import com.abacogroup.ddm.payment.api.req.BankAccountDocumentSearchReq;
import com.abacogroup.ddm.payment.db.dao.BankAccountDAO;
import com.abacogroup.ddm.payment.db.dao.BankAccountDocumentDAO;
import com.abacogroup.ddm.payment.db.ntt.BankAccountDocumentEntity;
import com.abacogroup.ddm.payment.db.ntt.BankAccountEntity;
import com.abacogroup.dynamicdocuments.bean.Document;
import com.abacogroup.dynamicdocuments.bean.DocumentDefinition;
import com.abacogroup.dynamicdocuments.bean.InsertDocument;
import com.abacogroup.dynamicdocuments.bean.SummaryFieldDefinition;
import com.abacogroup.dynamicdocuments.bean.SummaryFieldValue;
import com.abacogroup.dynamicdocuments.bean.documentdefinition.fieldset.field.FieldType;
import com.abacogroup.dynamicdocuments.exceptions.UnknownDocumentException;
import com.abacogroup.dynamicdocuments.services.DocumentService;
import com.abacogroup.dynamicdocuments.services.DocumentTypeService;
import com.abacogroup.jdbi.criteria.Criteria;
import com.abacogroup.jdbi.model.AuditEntity;
import com.abacogroup.jdbi.orderby.OrderBy;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import jakarta.ws.rs.core.Response;
import java.time.Clock;
import java.time.OffsetDateTime;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.stream.Stream;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

@Slf4j
public class BankAccountDocumentServiceImpl implements com.abacogroup.ddm.payment.core.BankAccountDocumentService {

	private final BankAccountDocumentDAO dao;
	private final BankAccountDAO bankAccountDAO;
	private final DocTypeRelationDAO docTypeRelationDAO;

	private final DocumentService documentService;
	private final DocumentTypeService documentTypeService;

	private final AnomalyClient anomalyClient;
	private final FileStoreProxyClient fileStoreProxyClient;
	private final String dynamicDocumentsBucket;

	private final Clock appClock;

	public BankAccountDocumentServiceImpl(BankAccountDocumentDAO dao, BankAccountDAO bankAccountDAO,
			DocTypeRelationDAO docTypeRelationDAO, DocumentService documentService, DocumentTypeService documentTypeService,
			AnomalyClient anomalyClient, FileStoreProxyClient fileStoreProxyClient, String dynamicDocumentsBucket, Clock appClock) {
		this.dao = dao;
		this.bankAccountDAO = bankAccountDAO;
		this.docTypeRelationDAO = docTypeRelationDAO;
		this.documentService = documentService;
		this.documentTypeService = documentTypeService;
		this.anomalyClient = anomalyClient;
		this.fileStoreProxyClient = fileStoreProxyClient;
		this.dynamicDocumentsBucket = dynamicDocumentsBucket;

		this.appClock = appClock;
	}

	@Override
	public BankAccountDocumentRes insert(ReqContext reqContext, Long partyId, Long accountId, InsertDocument document) {

		if (StringUtils.isBlank(document.getDefCode())) {
			throw new InvalidDocumentException(InvalidDocumentException.ErrEnum.DYNAMIC_DOCUMENT_ERR, "missing defCode");
		}

		BankAccountEntity bankAccountEntity = loadBankAccount(reqContext, partyId, accountId);
		document.setBusinessId(bankAccountEntity.getId());

		String definitionCode = document.getDefCode();
		DocumentDefinition definition = this.documentTypeService.getDocumentDefinition(reqContext.getTenantId(), definitionCode)
				.orElseThrow(() -> new InvalidDocumentException(InvalidDocumentException.ErrEnum.DYNAMIC_DOCUMENT_ERR, "invalid defCode"));

		if (docTypeRelationDAO.findByNamespaceAndDefCode(reqContext.getTenantId(), PAYMENT_MODULE, definitionCode).isEmpty()) {
			throw new InvalidDocumentException(ErrEnum.DYNAMIC_DOCUMENT_ERR, "invalid defCode for payment method module");
		}

		int maxOccurs = 0;
		if (null != definition.getMetadata()) {
			maxOccurs = Optional.ofNullable(definition.getMetadata().getMaxOccurs()).orElse(0);
		}
		if (maxOccurs <= this.countDocumentsByAccountIdAndDefinitionCode(reqContext, accountId, definitionCode)) {
			throw new InvalidDocumentException(InvalidDocumentException.ErrEnum.DYNAMIC_DOCUMENT_ERR, "over maxOccurs");
		}

		Long documentId = dao.inTransaction(handle -> {
			Long id = store(reqContext, document.getDoc(), document.getDefCode(), document.getBusinessId(), document.getLabel());

			BankAccountDocumentEntity entity = new BankAccountDocumentEntity();
			entity.setBankAccountId(bankAccountEntity.getId());
			entity.setDefinitionCode(document.getDefCode());
			entity.setDocumentId(id);
			AuditHelper.setAuditForInsert(entity, reqContext.getUsername(), dao);
			this.dao.insert(entity);

			return id;
		});

		AnomalyHelper.newInstance(anomalyClient, reqContext, appClock)
				.tryExpireAtto(docTypeRelationDAO, dao, accountId)
				.pushAnomalies();

		return getBankAccountDocument(reqContext, bankAccountEntity, documentId);
	}

	private Long store(ReqContext reqContext, Document document, String definitionCode, Long accountId, String label) {

		document.setValidFrom(Optional.ofNullable(document.getValidFrom()).orElse(OffsetDateTime.now(appClock)));
		document.setValidTo(Optional.ofNullable(document.getValidTo())
				.orElse(AuditEntity.dateActive.atOffset(appClock.getZone().getRules().getOffset(appClock.instant()))));

		return documentService.insertDocument(reqContext.getTenantId(), definitionCode, document, reqContext.getUser().getUserId(), accountId, label);
	}

	@Override
	public void expire(ReqContext reqContext, Long partyId, Long accountId, Long documentId) {
		BankAccountEntity bankAccountEntity = loadBankAccount(reqContext, partyId, accountId);
		BankAccountDocumentEntity entity = dao.findByDocumentIdAndAccountId(reqContext.getTenantId(), documentId, bankAccountEntity.getId())
				.orElseThrow(() -> new InvalidDocumentException(DYNAMIC_DOCUMENT_NOT_FOUND, "Bank Account Document not found"));

		Document doc = Optional.of(documentService.getDocumentFromId(documentId))
				.orElseThrow(() -> new InvalidDocumentException(DYNAMIC_DOCUMENT_NOT_FOUND, "Document not found"));

		doc.setValidTo(OffsetDateTime.now(appClock));
		dao.useTransaction(handle -> {
			documentService.updateDocument(documentId, doc, reqContext.getUser().getUserId());
			Consumer<BankAccountDocumentEntity> expire = handle::expireRow;
			AuditHelper.expire(entity, reqContext.getUsername(), expire, handle.getCurrentTimestamp());
		});

		AnomalyHelper.newInstance(anomalyClient, reqContext, appClock)
				.tryAddAtto(docTypeRelationDAO, dao, accountId)
				.pushAnomalies();
	}

	@Override
	public BankAccountDocumentRes update(ReqContext reqContext, Long partyId, Long accountId, Long documentId, Document updateReq) {
		BankAccountEntity bankAccountEntity = loadBankAccount(reqContext, partyId, accountId);
		BankAccountDocumentEntity entity = dao.findByDocumentIdAndAccountId(reqContext.getTenantId(), documentId, accountId)
				.orElseThrow(() -> new InvalidDocumentException(DYNAMIC_DOCUMENT_NOT_FOUND, "Bank Account Document not found"));

		Document doc = Optional.of(documentService.getDocumentFromId(documentId))
				.orElseThrow(() -> new InvalidDocumentException(DYNAMIC_DOCUMENT_NOT_FOUND, "Document not found"));

		doc.setValidFrom(Optional.ofNullable(updateReq.getValidFrom()).orElse(doc.getValidFrom()));
		doc.setValidTo(Optional.ofNullable(updateReq.getValidTo()).orElse(doc.getValidTo()));
		doc.setFields(Optional.ofNullable(updateReq.getFields()).orElse(doc.getFields()));
		entity.setBankAccountId(accountId);
		entity.setDocumentId(documentId);

		updateDocument(reqContext, documentId, entity, doc, bankAccountEntity);

		// TODO verify elapsed

		return getBankAccountDocument(reqContext, bankAccountEntity, documentId);
	}

	private Long updateDocument(ReqContext reqContext, Long documentId, BankAccountDocumentEntity entity, Document doc, BankAccountEntity bankAccountEntity) {
		return dao.inTransaction(handle -> {
			documentService.updateDocument(documentId, doc, reqContext.getUser().getUserId());

			Consumer<BankAccountDocumentEntity> expire = handle::expireRow;
			Function<BankAccountDocumentEntity, Long> insert = handle::insert;

			Long updatedBankAccountDocId = AuditHelper.update(entity, reqContext.getUsername(), expire, insert, handle.getCurrentTimestamp());

			return updatedBankAccountDocId;
		});
	}

	@Override
	public BankAccountDocumentRes getBankAccountDocument(ReqContext reqContext, Long partyId, Long accountId, Long documentId) {
		BankAccountEntity bankAccountEntity = loadBankAccount(reqContext, partyId, accountId);

		return getBankAccountDocument(reqContext, bankAccountEntity, documentId);
	}

	public BankAccountDocumentRes getBankAccountDocument(ReqContext reqContext, BankAccountEntity bankAccountEntity, Long documentId) {
		return dao.getByDocumentIdAndAccountId(documentId, bankAccountEntity.getId(), reqContext)
				.map(baDoc -> addData(baDoc, dynamicDocumentsBucket))
				.orElseThrow(() -> new InvalidDocumentException(DYNAMIC_DOCUMENT_NOT_FOUND, "Document not found"));
	}

	@Override
	public InfiniteListResults<BankAccountDocumentRes> search(ReqContext reqContext, Long partyId, Long accountId, BankAccountDocumentSearchReq searchReq,
			String nextKey) {
		BankAccountEntity bankAccountEntity = loadBankAccount(reqContext, partyId, accountId);

		Criteria criteria = searchReq.getCriteria(reqContext);
		OrderBy orderBy = searchReq.getSort();

		return dao.infinite(() -> dao.search(bankAccountEntity.getId(), criteria, orderBy, reqContext), nextKey, searchReq.getPageSize())
				.map(baDoc -> addSummaryFields(reqContext, baDoc, dynamicDocumentsBucket));
	}

	@Override
	public Long countDocumentsByAccountIdAndDefinitionCode(ReqContext reqContext, Long accountId, String code) {
		return dao.countByDefinitionCodeAndAccountId(reqContext.getTenantId(), code, accountId);
	}

	@Override
	public Response getDocumentFileContent(ReqContext reqContext, Long partyId, Long accountId, Long documentId, String fileId) {
		this.validateCanReadFile(reqContext, partyId, accountId, documentId, fileId);

		return fileStoreProxyClient.getFileContent(reqContext.getLang(), reqContext.getUser(), dynamicDocumentsBucket, fileId);
	}

	@Override
	public Response getDocumentFileMetadata(ReqContext reqContext, Long partyId, Long accountId, Long documentId, String fileId) {
		this.validateCanReadFile(reqContext, partyId, accountId, documentId, fileId);

		return fileStoreProxyClient.getFileMetadata(reqContext.getLang(), reqContext.getUser(), dynamicDocumentsBucket, fileId);
	}

	private void validateCanReadFile(ReqContext reqContext, Long partyId, Long accountId, Long documentId, String fileId) {
		BankAccountEntity bankAccountEntity = loadBankAccount(reqContext, partyId, accountId);

		BankAccountDocumentEntity groupDocumentEntity = dao.findByDocumentIdAndAccountId(reqContext.getTenantId(), documentId, accountId)
				.orElseThrow(() -> new InvalidDocumentException(DYNAMIC_DOCUMENT_NOT_FOUND,
						String.format("Document  %s not found", documentId)));

		Document document;
		try {
			document = documentService.getDocumentFromId(groupDocumentEntity.getDocumentId());
		} catch (UnknownDocumentException ude) {
			throw new InvalidDocumentException(DYNAMIC_DOCUMENT_NOT_FOUND, ude.getMessage());
		}
		DocumentDefinition definition = documentTypeService.getDocumentDefinition(reqContext.getTenantId(), groupDocumentEntity.getDefinitionCode())
				.orElseThrow(() -> new InvalidDocumentException(InvalidDocumentException.ErrEnum.DYNAMIC_DOCUMENT_ERR,
						String.format("error loading definition for %s", groupDocumentEntity.getDefinitionCode())));

		boolean containsFileId = definition.getFieldSets().stream()
				.flatMap(fieldSet -> fieldSet.getFields().stream())
				.filter(field -> FieldType.FILE.equals(field.getType()))
				.map(field -> document.getFields().get(field.getCode()))
				.filter(Objects::nonNull)
				.flatMap(fieldValue -> fieldValue instanceof Collection ? ((Collection<?>) fieldValue).stream() : Stream.of(fieldValue))
				.anyMatch(fileId::equals);

		if (!containsFileId) {
			throw new InvalidDocumentException(DYNAMIC_DOCUMENT_FILE_NOT_FOUND,
					String.format("document '%s' of bank account '%s' does not contain file with id '%s'",
							documentId, bankAccountEntity.getId(), fileId));
		}
	}

	private BankAccountEntity loadBankAccount(ReqContext reqContext, Long partyId, Long accountId) {
		return bankAccountDAO.findById(reqContext.getTenantId(), partyId, accountId)
				.orElseThrow(() -> new BankAccountException(BankAccountException.ErrEnum.BANK_ACCOUNT_NOT_FOUND,
						String.format("bank account %s not found", accountId)));
	}

	private BankAccountDocumentRes addSummaryFields(ReqContext reqContext, BankAccountDocumentRes bankAccountDocumentRes, String dynamicDocumentsBucket) {
		Document document = documentService.getDocumentFromId(bankAccountDocumentRes.getDocumentId());
		Optional<DocumentDefinition> def = documentTypeService
				.getDocumentDefinition(reqContext.getTenantId(), bankAccountDocumentRes.getDefinitionCode());

		if (def.isPresent()) {
			List<SummaryFieldDefinition> summaryFields = documentTypeService.getSummaryFields(def.get(), reqContext.getLang());
			List<SummaryFieldValue> listValues = documentService.getSummaryValues(def.get(), document, reqContext.getLang());

			LinkedHashMap<String, Object> summaryFieldsData = new LinkedHashMap<>();
			listValues.forEach(
					summaryFieldValue -> summaryFieldsData.put(summaryFieldValue.getCode(), summaryFieldValue.getValue())
			);

			bankAccountDocumentRes.setSummaryFieldDefinitions(summaryFields);
			bankAccountDocumentRes.setData(summaryFieldsData);
			bankAccountDocumentRes.setBucketName(dynamicDocumentsBucket);
		}
		return bankAccountDocumentRes;
	}

	private BankAccountDocumentRes addData(BankAccountDocumentRes bankAccountDocumentRes, String dynamicDocumentsBucket) {
		Document document = Optional.ofNullable(documentService.getDocumentFromId(bankAccountDocumentRes.getDocumentId()))
				.orElseThrow(() -> new InvalidDocumentException(ErrEnum.DYNAMIC_DOCUMENT_NOT_FOUND, "doc not found " + bankAccountDocumentRes.getDocumentId()));
		bankAccountDocumentRes.setData(new LinkedHashMap<>(document.getFields()));
		bankAccountDocumentRes.setBucketName(dynamicDocumentsBucket);
		return bankAccountDocumentRes;
	}

}

