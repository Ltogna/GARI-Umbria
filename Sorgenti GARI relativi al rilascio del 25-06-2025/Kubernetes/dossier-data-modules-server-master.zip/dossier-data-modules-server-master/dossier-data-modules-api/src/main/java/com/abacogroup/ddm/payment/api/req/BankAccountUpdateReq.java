package com.abacogroup.ddm.payment.api.req;

import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder.Default;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder(setterPrefix = "set")
@NoArgsConstructor
@AllArgsConstructor
public class BankAccountUpdateReq {

	private String description;

	@Default
	@NotNull
	private Boolean defaultBankAccount = false;

}
