package com.abacogroup.ddm.heirs_special_case.db.dao;

import java.util.List;

import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.customizer.BindBean;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;
import org.jdbi.v3.sqlobject.transaction.Transactional;

import com.abacogroup.ddm.heirs_special_case.db.ntt.SuccessionTypeEntity;
import com.abacogroup.jdbi.EnhancedSqlObject;


public interface SuccessionTypeDAO extends Transactional<SuccessionTypeDAO>, EnhancedSqlObject {

	@SqlQuery("select s.code, \n"
            + "  coalesce (§i18n(:tenantId, 'ddm_succession_types', 'code', s.code, :lang)§, s.code) as description, \n"
            + "  s.fl_visible as flVisible \n"
            + "from ddm_succession_types s \n" 
            + "where s.tenant_id = :tenantId \n"
            + "  and (:code is null or s.code = :code) \n"
            + "  and (:flVisible is null or s.fl_visible = :flVisible) \n")
	@RegisterBeanMapper(SuccessionTypeEntity.class)
	List<SuccessionTypeEntity> getSuccessionTypes(@Bind("tenantId") String tenantId, @Bind("lang") String lang,
			@Bind("code") String code, @Bind("flVisible") Integer flVisible);
	
	@SqlUpdate("insert into ddm_succession_types (tenant_id, code, fl_visible) \n"
			+ "values (:tenantId, :code, :flVisible) \n")
	void insert(@BindBean SuccessionTypeEntity successionType);
	
	@SqlUpdate("update ddm_succession_types \n"
            + "set fl_visible = :flVisible \n"
            + "where tenant_id = :tenantId \n"
            + "  and code = :code \n")
	void update(@BindBean SuccessionTypeEntity successionType);
}