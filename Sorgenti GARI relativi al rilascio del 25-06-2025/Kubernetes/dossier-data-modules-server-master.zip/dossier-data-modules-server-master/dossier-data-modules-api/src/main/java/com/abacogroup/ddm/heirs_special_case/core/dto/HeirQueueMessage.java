package com.abacogroup.ddm.heirs_special_case.core.dto;

import java.time.LocalDateTime;

import com.abacogroup.ddm.heirs_special_case.core.dto.HeirEventType;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder(setterPrefix = "set")
public class HeirQueueMessage {

	private final String tenant;
	private final String username;
	private final String lang;
	private final Long partyId;
	private final String partyCuaa;
	private final LocalDateTime date;

	private final HeirEventType eventType;

	@JsonCreator
	public HeirQueueMessage(@JsonProperty("tenant") String tenant,
			@JsonProperty("username") String username,
			@JsonProperty("lang") String lang,
			@JsonProperty("partyId") Long partyId,
			@JsonProperty("partyCuaa") String partyCuaa,
			@JsonProperty("date") LocalDateTime date,
			@JsonProperty("eventType") HeirEventType eventType) {
		this.tenant = tenant;
		this.username = username;
		this.lang = lang;
		this.partyId = partyId;
		this.partyCuaa = partyCuaa;
		this.date = date;
		this.eventType = eventType;
	}

	public String getRoutingKey() {
		return eventType.getTopic();
	}

}
