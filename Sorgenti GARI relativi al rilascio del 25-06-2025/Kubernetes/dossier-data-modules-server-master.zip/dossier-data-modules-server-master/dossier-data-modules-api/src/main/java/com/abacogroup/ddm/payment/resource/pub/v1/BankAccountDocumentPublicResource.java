package com.abacogroup.ddm.payment.resource.pub.v1;

import static com.abacogroup.ddm.resources.PublicResourceConstants.PAYMENT_MODULE_API_V1_PUB;

import com.abacogroup.ddm.common.resources.ReqContext;
import com.abacogroup.ddm.core.exceptions.BankAccountException;
import com.abacogroup.ddm.core.exceptions.InvalidDocumentException;
import com.abacogroup.ddm.payment.api.req.BankAccountDocumentSearchReq;
import com.abacogroup.ddm.payment.api.v1.BankAccountDocumentResponseV1;
import com.abacogroup.ddm.payment.core.BankAccountDocumentService;
import com.abacogroup.ddm.payment.resource.pub.mapper.BankAccountDocumentResponseMapper;
import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.jdbi.paging.InfiniteListResults;

import io.dropwizard.auth.Auth;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import io.swagger.v3.oas.annotations.tags.Tags;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DefaultValue;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.HEAD;
import jakarta.ws.rs.HeaderParam;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Path(PAYMENT_MODULE_API_V1_PUB + "/parties/{partyId}/accounts/{accountId}/documents")
@Produces(MediaType.APPLICATION_JSON)
@Tags({
		@Tag(name = "Bank Account documents PUBLIC", description = "Operations on bank account documents"),
		@Tag(name = "v1")
})
public class BankAccountDocumentPublicResource {

	private final BankAccountDocumentService bankAccountDocumentService;

	public BankAccountDocumentPublicResource(BankAccountDocumentService bankAccountDocumentService) {
		this.bankAccountDocumentService = bankAccountDocumentService;
	}

	@Operation(summary = "Infinite list of documents", description = "Get list of documents filtered with criteria")
	@ApiResponse(responseCode = "200", description = "Successfully, returns a list of documents (sorted/filtered)", useReturnTypeSchema = true)
	@ApiResponse(responseCode = "400", description = "bank account not found", content = @Content(mediaType = MediaType.APPLICATION_JSON,
			schema = @Schema(implementation = BankAccountException.ErrorBody.class)))
	@GET
	@Path("")
	public InfiniteListResults<BankAccountDocumentResponseV1> search(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@PathParam("tenant") String tenantId,
			@Parameter(description = "party ID") @PathParam("partyId") Long partyId,
			@Parameter(description = "account ID") @PathParam("accountId") Long accountId,
			@Parameter(description = "Next key used for infinite pagination") @QueryParam("nextKey") String nextKey,
			@Parameter(in = ParameterIn.QUERY, description = "DD definition Code")
			@QueryParam("definitionCode") String definitionCode) {
		//			@BeanParam BankAccountDocumentSearchReq searchReq) {

		ReqContext reqContext = new ReqContext(user, lang);
		BankAccountDocumentSearchReq searchReq = new BankAccountDocumentSearchReq().setDefinitionCode(definitionCode);

		return bankAccountDocumentService.search(reqContext, partyId, accountId, searchReq, nextKey)
				.map(BankAccountDocumentResponseMapper.INSTANCE::toResponseV1);
	}

	@Operation(summary = "Find document by code and id", description = "Returns document based on its definition code and document id")
	@ApiResponses({
			@ApiResponse(responseCode = "200", description = "Document successfully found", useReturnTypeSchema = true),
			@ApiResponse(responseCode = "400", description = "The document does not exist", content = @Content(mediaType = MediaType.APPLICATION_JSON,
					schema = @Schema(anyOf = {
							BankAccountException.ErrorBody.class,
							InvalidDocumentException.ErrorBody.class
					})))
	})
	@GET
	@Path("/{documentId}")
	public BankAccountDocumentResponseV1 getByDocumentId(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@PathParam("tenant") String tenantId,
			@Parameter(description = "party ID") @PathParam("partyId") Long partyId,
			@Parameter(description = "account ID") @PathParam("accountId") Long accountId,
			@Parameter(description = "document ID") @PathParam("documentId") Long documentId) {
		ReqContext reqContext = new ReqContext(user, lang);
		return BankAccountDocumentResponseMapper.INSTANCE
				.toResponseV1(this.bankAccountDocumentService.getBankAccountDocument(reqContext, partyId, accountId, documentId));
	}

	@GET
	@Consumes(MediaType.WILDCARD)
	@Produces(MediaType.APPLICATION_OCTET_STREAM)
	@Path("/{documentId}/attachments/{bucket}/{fileId}")
	@Operation(summary = "get document attachment content", description = "Returns document attachment content")
	@ApiResponses({
			@ApiResponse(responseCode = "200", description = "The file bytes",
					content = @Content(mediaType = MediaType.APPLICATION_OCTET_STREAM, schema = @Schema(type = "string", format = "binary"))),
			@ApiResponse(responseCode = "400", description = "The document does not exist", content = @Content(mediaType = MediaType.APPLICATION_JSON,
					schema = @Schema(anyOf = {
							BankAccountException.ErrorBody.class,
							InvalidDocumentException.ErrorBody.class
					})))
	})
	public Response getDocumentFileContent(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@PathParam("tenant") String tenantId,
			@Parameter(description = "party ID") @PathParam("partyId") Long partyId,
			@Parameter(description = "account ID") @PathParam("accountId") Long accountId,
			@Parameter(description = "document ID") @PathParam("documentId") Long documentId,
			@PathParam("bucket") String bucket,
			@PathParam("fileId") String fileId) {
		ReqContext reqContext = new ReqContext(user, lang);
		return bankAccountDocumentService.getDocumentFileContent(reqContext, partyId, accountId, documentId, fileId);
	}

	@Operation(summary = "get document attachment metadata", description = "Returns document attachment metadata in header")
	@ApiResponses({
			@ApiResponse(responseCode = "200", description = "The file metadata in header"),
			@ApiResponse(responseCode = "400", description = "The document does not exist", content = @Content(mediaType = MediaType.APPLICATION_JSON,
					schema = @Schema(anyOf = {
							BankAccountException.ErrorBody.class,
							InvalidDocumentException.ErrorBody.class
					})))
	})
	@HEAD
	@Path("/{documentId}/attachments/{bucket}/{fileId}")
	public Response getDocumentFileMetadata(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@PathParam("tenant") String tenantId,
			@Parameter(description = "party ID") @PathParam("partyId") Long partyId,
			@Parameter(description = "account ID") @PathParam("accountId") Long accountId,
			@Parameter(description = "document ID") @PathParam("documentId") Long documentId,
			@PathParam("bucket") String bucket,
			@PathParam("fileId") String fileId) {
		ReqContext reqContext = new ReqContext(user, lang);
		return bankAccountDocumentService.getDocumentFileMetadata(reqContext, partyId, accountId, documentId, fileId);
	}

}
