package com.abacogroup.ddm.doigt_quotas.resources;

import com.abacogroup.ddm.common.resources.ReqContext;
import com.abacogroup.ddm.common.resources.ResourceConstants;
import com.abacogroup.ddm.doigt_quotas.api.services.DoIgtQuotaService;
import com.abacogroup.dropwizard.auth.sso2.User;
import com.codahale.metrics.annotation.Timed;

import io.dropwizard.auth.Auth;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.annotation.security.RolesAllowed;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DefaultValue;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.HeaderParam;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

@Path(ResourceConstants.DOIGT_QUOTAS_MODULE_API_PRIV)
@Tag(name = "DO-IGT Quotas")
@Timed
@RolesAllowed({ "DDM_DOSSIER|VIEWER" })
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
public class DoIgtQuotaResources {
    private final DoIgtQuotaService doIgtQuotaService;

    public DoIgtQuotaResources(DoIgtQuotaService doIgtQuotaService) {
        this.doIgtQuotaService = doIgtQuotaService;
    }

    @GET
    @Path("/{partyId}")
    @Operation(description = "Returns the list of Do Igt Quotas for this partyId", summary = "")
    @ApiResponse(description = "The list of Do Igt Quotas for this partyId - if nothing found list will be empty", content = @Content(mediaType = MediaType.APPLICATION_JSON), useReturnTypeSchema = true)
    public Response getQuotasByPartyId(
            @HeaderParam("accept-language") @DefaultValue("en") String lang,
            @Parameter(hidden = true) @Auth User user,
            @Parameter(description = "Current Tenant") @PathParam("tenant") String tenantId,
            @Parameter(description = "Next key used for infinite pagination") @QueryParam("nextKey") String nextKey,
            @Parameter(description = "The Party Id") @PathParam("partyId") Long partyId) {
        ReqContext reqContext = new ReqContext(user, lang);

        return doIgtQuotaService.getQuotasByPartyId(reqContext, partyId, nextKey);
    }
}
