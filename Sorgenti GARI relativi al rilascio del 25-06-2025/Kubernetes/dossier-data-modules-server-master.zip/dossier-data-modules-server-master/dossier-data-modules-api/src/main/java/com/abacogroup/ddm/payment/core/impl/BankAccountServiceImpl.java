package com.abacogroup.ddm.payment.core.impl;

import static com.abacogroup.ddm.DossierDataModulesApplication.PAYMENT_MODULE;
import static com.abacogroup.ddm.core.exceptions.BankAccountException.ErrEnum.DUPLICATE_BANK_ACCOUNT;
import static com.abacogroup.ddm.payment.core.impl.AnomalyHelper.BANK_ACCOUNT_CODE;

import java.time.Clock;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Optional;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import org.apache.commons.lang3.SerializationUtils;

import com.abacogroup.anomalyregistry.api.v1.AnomalySearchResponse;
import com.abacogroup.anomalyregistry.core.cli.v1.AnomalyClient;
import com.abacogroup.ddm.api.AnomalyLevelEnum;
import com.abacogroup.ddm.api.DdmAnomaliesRes;
import com.abacogroup.ddm.api.v1.PartyDetailResponseV1;
import com.abacogroup.ddm.common.core.AuditHelper;
import com.abacogroup.ddm.common.resources.ReqContext;
import com.abacogroup.ddm.core.AppConfigService;
import com.abacogroup.ddm.core.DdmAnomalyService;
import com.abacogroup.ddm.core.PartyService;
import com.abacogroup.ddm.core.dto.appconfig.PaymentDefaultAccount;
import com.abacogroup.ddm.core.dto.appconfig.PaymentRegexValidation;
import com.abacogroup.ddm.core.dto.appconfig.PaymentRegexValidation.Config;
import com.abacogroup.ddm.core.exceptions.BankAccountException;
import com.abacogroup.ddm.core.exceptions.BankAccountException.ErrEnum;
import com.abacogroup.ddm.db.dao.DocTypeRelationDAO;
import com.abacogroup.ddm.payment.api.BankAccountRes;
import com.abacogroup.ddm.payment.api.BankAccountSearchRes;
import com.abacogroup.ddm.payment.api.req.BankAccountCreateReq;
import com.abacogroup.ddm.payment.api.req.BankAccountSearchReq;
import com.abacogroup.ddm.payment.api.req.BankAccountUpdateReq;
import com.abacogroup.ddm.payment.core.BankAccountService;
import com.abacogroup.ddm.payment.core.PaymentEventProducer;
import com.abacogroup.ddm.payment.core.dto.PaymentEventType;
import com.abacogroup.ddm.payment.core.mapper.BankAccountMapper;
import com.abacogroup.ddm.payment.db.dao.BankAccountDAO;
import com.abacogroup.ddm.payment.db.ntt.BankAccountEntity;
import com.abacogroup.jdbi.criteria.Criteria;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.jdbi.model.AuditEntity;
import com.abacogroup.jdbi.orderby.OrderBy;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.jdbi.paging.impl.InfiniteListResultsImpl;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class BankAccountServiceImpl implements BankAccountService {

	private final BankAccountDAO bankAccountDAO;
	private final DocTypeRelationDAO docTypeRelationDAO;

	private final AppConfigService appConfigService;
	private final PartyService partyService;
	private final DdmAnomalyService anomalyService;

	private final PaymentEventProducer paymentEventProducer;

	private final AnomalyClient anomalyClient;

	private final Clock appClock;

	private final static int DEFAULT_PAGE_SIZE = 50;

	public BankAccountServiceImpl(BankAccountDAO bankAccountDAO, DocTypeRelationDAO docTypeRelationDAO,
			AppConfigService appConfigService, PartyService partyService, DdmAnomalyService anomalyService, PaymentEventProducer paymentEventProducer,
			AnomalyClient anomalyClient, Clock appClock) {
		this.bankAccountDAO = bankAccountDAO;
		this.docTypeRelationDAO = docTypeRelationDAO;
		this.appConfigService = appConfigService;
		this.partyService = partyService;
		this.anomalyService = anomalyService;
		this.paymentEventProducer = paymentEventProducer;
		this.anomalyClient = anomalyClient;
		this.appClock = appClock;
	}

	@Override
	public BankAccountSearchRes insert(ReqContext reqContext, Long partyId, BankAccountCreateReq createReq) {
		partyService.validatePartyId(reqContext, partyId);

		BankAccountEntity entity = BankAccountMapper.INSTANCE.reqToEntity(createReq);
		entity.setTenantId(reqContext.getTenantId());
		entity.setPartyId(partyId);
		entity.setDayTo(AbsoluteDate.of(AuditEntity.dateActive));

		this.validateIban(reqContext, entity.getIban());

		//data apertura conto <= data corrente
		LocalDate today = appClock.instant().atZone(ZoneId.systemDefault()).toLocalDate();
		if (createReq.getDayFrom().toLocalDate().isAfter(today)) {
			throw new BankAccountException(BankAccountException.ErrEnum.INVALID_DAY_FROM, "data inizio deve essere oggi o successiva");
		}

		if (!bankAccountDAO.findByIbanConcat(reqContext.getTenantId(), entity.getIban(), entity.getSwiftBic(), entity.getBicExtraSepa(),
				partyId, AbsoluteDate.of(today).getValue()).isEmpty()) {
			throw new BankAccountException(DUPLICATE_BANK_ACCOUNT, "Conto Corrente già esistente, impossibile procedere con l'inserimento");
		}

		bankAccountDAO.useTransaction(h -> {
			Long id = h.issuePk();
			AuditHelper.setAuditForInsert(entity, reqContext.getUsername(), h);
			h.insertMasterRow(id, entity);
			h.insertDetailRow(entity, id);
			entity.setId(id);
			if (entity.getFlDefault() == 1) {
				entity.setPkid(id);
				h.setDefaultAndUpdateOthers(entity, reqContext);
			}
		});

		paymentEventProducer.pushBankAccountEvent(reqContext, partyId, entity.getId(), PaymentEventType.NEW_BANK_ACCOUNT);

		//------

		AnomalyHelper.newInstance(anomalyClient, reqContext, appClock)
				.expireNoCC(partyId)
				.tryExpireCCPred(entity)
				.tryAddCCPred(bankAccountDAO, partyId)
				.tryAdd195(bankAccountDAO, entity)
				.tryAddAtto(docTypeRelationDAO, entity.getId())
				.pushAnomalies();

		return this.mapAnomalies(reqContext, entity);
	}



	@Override
	public Optional<BankAccountSearchRes> getById(ReqContext reqContext, Long partyId, Long accountId) {
		return bankAccountDAO.findById(reqContext.getTenantId(), partyId, accountId)
				.map(ba -> mapAnomalies(reqContext, ba));
	}

	@Override
	public Optional<BankAccountSearchRes> getActiveDefault(ReqContext reqContext, Long partyId) {
		return bankAccountDAO.findDefault(reqContext.getTenantId(), partyId, AbsoluteDate.of(LocalDate.now(appClock)).getValue())
				.map(ba -> mapAnomalies(reqContext, ba));
	}

	@Override
	public InfiniteListResults<BankAccountSearchRes> search(ReqContext reqContext, Long partyId, BankAccountSearchReq searchRequest, String nextKey) {
		Criteria criteria = searchRequest.getCriteria(AbsoluteDate.of(bankAccountDAO.getCurrentTimestamp()));
		OrderBy sort = searchRequest.getSortList();
		InfiniteListResults<BankAccountSearchRes> results = bankAccountDAO.infinite(
				() -> bankAccountDAO.search(partyId, criteria, sort, reqContext),
				nextKey, searchRequest.getPageSize());

		List<String> resIds = results.getRecords().stream().map(BankAccountRes::getId).map(Object::toString).collect(Collectors.toList());
		Map<AnomalyLevelEnum, List<AnomalySearchResponse>> allAnomaliesGroupedByLevel = anomalyService.getAnomaliesGroupedByLevel(reqContext,
				PAYMENT_MODULE, BANK_ACCOUNT_CODE, resIds);

		results.map(r -> {
			Map<AnomalyLevelEnum, List<AnomalySearchResponse>> anomalies = allAnomaliesGroupedByLevel.entrySet().stream()
					.map(e -> Map.entry(e.getKey(), e.getValue().stream()
							.filter(a -> a.getEntityId().equals(r.getId().toString()))
							.collect(Collectors.toList())))
					.filter(e -> !e.getValue().isEmpty())
					.collect(Collectors.toMap(Entry::getKey, Entry::getValue));
			r.setAnomalies(new DdmAnomaliesRes(anomalies));
			return r;
		});

		return results;
	}

	@Override
	public BankAccountSearchRes update(ReqContext reqContext, Long partyId, Long accountId, BankAccountUpdateReq updateReq) {
		BankAccountEntity entity = bankAccountDAO.findById(reqContext.getTenantId(), partyId, accountId)
				.orElseThrow(() -> new BankAccountException(BankAccountException.ErrEnum.BANK_ACCOUNT_NOT_FOUND,
						String.format("bank account %s not found", accountId)));

		BankAccountEntity originalEntity = SerializationUtils.clone(entity);
		BankAccountMapper.INSTANCE.reqToEntity(updateReq, entity);

		//skip unnecessary update
		if (originalEntity.equals(entity)) {
			log.info("nothing to update for account {}", accountId);
			return this.mapAnomalies(reqContext, entity);
		}

		doUpdate(reqContext, entity);

		paymentEventProducer.pushBankAccountEvent(reqContext, partyId, accountId, PaymentEventType.UPDATE_BANK_ACCOUNT);

		AnomalyHelper.newInstance(anomalyClient, reqContext, appClock)
				.tryExpireCCPred(entity)
				.tryAddCCPred(bankAccountDAO, partyId)
				.pushAnomalies();

		return this.mapAnomalies(reqContext, entity);
	}

	@Override
	public BankAccountSearchRes updateDayTo(ReqContext reqContext, Long partyId, Long accountId, AbsoluteDate dayTo) {
		BankAccountEntity entity = bankAccountDAO.findById(reqContext.getTenantId(), partyId, accountId)
				.orElseThrow(() -> new BankAccountException(BankAccountException.ErrEnum.BANK_ACCOUNT_NOT_FOUND,
						String.format("bank account %s not found", accountId)));

		boolean allowCloseDefault = appConfigService.getConfig(reqContext.getTenantId(), PaymentDefaultAccount.CONFIG_KEY, PaymentDefaultAccount.class)
				.map(PaymentDefaultAccount::getConfiguration)
				.map(PaymentDefaultAccount.Config::getAllowClose)
				.orElse(true);

		//se allow == false E è predefinito
		if (entity.getFlDefault() == 1 && !allowCloseDefault) {
			throw new BankAccountException(BankAccountException.ErrEnum.CANNOT_CLOSE_DEFAULT, "non è possibile chiudere un predefinito");
		}

		// data chiusura conto >= data apertura conto e < data corrente
		if (!dayTo.toLocalDate().isBefore(appClock.instant().atZone(ZoneId.systemDefault()).toLocalDate())) {
			throw new BankAccountException(BankAccountException.ErrEnum.INVALID_DAY_TO, "data fine deve essere minore della data corrente");
		}
		if (entity.getDayFrom().toLocalDate().isAfter(dayTo.toLocalDate())) {
			throw new BankAccountException(BankAccountException.ErrEnum.INVALID_DAY_TO, "errore data fine deve essere successiva di almeno un giorno rispetto alla data di inizio");
		}

		entity.setDayTo(dayTo);
		entity.setFlDefault(0);
		doUpdate(reqContext, entity);

		paymentEventProducer.pushBankAccountEvent(reqContext, partyId, accountId, PaymentEventType.CLOSE_BANK_ACCOUNT);

		AnomalyHelper.newInstance(anomalyClient, reqContext, appClock)
				.tryAddNoCC(bankAccountDAO, partyId)
				.tryAddCCPred(bankAccountDAO, partyId)
				.expire195(bankAccountDAO, entity)
				.expireAtto(entity.getId())
				.pushAnomalies();

		return this.mapAnomalies(reqContext, entity);
	}

	@Override
	public InfiniteListResults<PartyDetailResponseV1> getByIban(ReqContext reqContext, String iban, String referenceDate, String nextKey) {
		InfiniteListResults<BankAccountEntity> results = bankAccountDAO.infinite(
				() -> bankAccountDAO.findByIban(reqContext.getTenantId(), iban, referenceDate),
				nextKey, DEFAULT_PAGE_SIZE);

		List<PartyDetailResponseV1> partyIdList = results.getRecords()
				.stream()
				.map(record -> new PartyDetailResponseV1(record.getPartyId()))
				.collect(Collectors.toList());

		return new InfiniteListResultsImpl<>(partyIdList, results.getNextKey());
	}

	private void doUpdate(ReqContext reqContext, BankAccountEntity entity) {
		bankAccountDAO.useTransaction(h -> {
			Consumer<BankAccountEntity> expire = h::expireRow;
			Function<BankAccountEntity, Long> insert = h::insertVersionRow;
			AuditHelper.update(entity, reqContext.getUsername(), expire, insert, h.getCurrentTimestamp());
			if (entity.getFlDefault() == 1) {
				h.setDefaultAndUpdateOthers(entity,reqContext);
			}
		});
	}

	private void validateIban(ReqContext reqContext, String iban) {
		List<String> ibanRegexes = appConfigService.getConfig(reqContext.getTenantId(), PaymentRegexValidation.CONFIG_KEY, PaymentRegexValidation.class)
				.map(PaymentRegexValidation::getConfiguration)
				.map(Config::getRegexes)
				.orElse(new ArrayList<>());

		if (ibanRegexes.isEmpty()) {
			log.debug("no iban regexes");
		} else {
			if (ibanRegexes.stream().noneMatch(regex -> Pattern.matches(regex, iban))) {
				throw new BankAccountException(ErrEnum.INVALID_IBAN,
						String.format("%s format not valid. it must match at least one of these regexes: %s", "iban",
								String.join(",", ibanRegexes)));
			}
		}

		// TODO validate using external service here
	}

	private BankAccountSearchRes mapAnomalies(ReqContext reqContext, BankAccountEntity ba) {
		Map<AnomalyLevelEnum, List<AnomalySearchResponse>> allAnomaliesGroupedByLevel = anomalyService.getAnomaliesGroupedByLevel(reqContext,
				PAYMENT_MODULE, BANK_ACCOUNT_CODE, ba.getId().toString());
		DdmAnomaliesRes ddmAnomaliesRes = new DdmAnomaliesRes(allAnomaliesGroupedByLevel);

		return BankAccountMapper.INSTANCE.entityToSearchRes(ba, ddmAnomaliesRes);
	}

}

