package com.abacogroup.ddm.core;

import com.abacogroup.anomalyregistry.api.v1.AnomalySearchResponse;
import com.abacogroup.ddm.api.AnomalyLevelEnum;
import com.abacogroup.ddm.common.resources.ReqContext;
import com.abacogroup.ddm.core.dto.AnomalyType;
import java.util.List;
import java.util.Map;

public interface DdmAnomalyService {

	Map<AnomalyLevelEnum, List<AnomalySearchResponse>> getAnomaliesGroupedByLevel(ReqContext reqContext, String namespace,
			String entityCode, String entityId, AnomalyType... acceptedAnomalyTypes);

	Map<AnomalyLevelEnum, List<AnomalySearchResponse>> getAnomaliesGroupedByLevel(ReqContext reqContext, String namespace,
			String entityCode, List<String> entityIds, AnomalyType... acceptedAnomalyTypes);

}
