package com.abacogroup.ddm.payment.api.req;

import com.abacogroup.jdbi.datatype.AbsoluteDate;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder.Default;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder(setterPrefix = "set")
@NoArgsConstructor
@AllArgsConstructor
public class BankAccountPatchReq {

	@NotNull
	private AbsoluteDate dayTo;

}
