package com.abacogroup.ddm.core;


import com.abacogroup.ddm.api.AppConfigRes;
import com.abacogroup.ddm.common.resources.ReqContext;
import com.abacogroup.ddm.core.dto.appconfig.BaseAppConfig;
import java.util.List;
import java.util.Optional;

public interface AppConfigService  {

	<AC extends BaseAppConfig<?>> Optional<AC> getConfig(String tenant, String key, Class<AC> type);

	List<AppConfigRes> searchAll(ReqContext reqContext);

	Optional<AppConfigRes> searchByKey(ReqContext reqContext, String key);

}
