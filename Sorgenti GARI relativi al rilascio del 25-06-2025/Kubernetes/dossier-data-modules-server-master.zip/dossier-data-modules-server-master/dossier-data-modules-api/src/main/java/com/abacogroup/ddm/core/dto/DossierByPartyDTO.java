package com.abacogroup.ddm.core.dto;

import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author Francesco Gallo
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DossierByPartyDTO {
	@Schema(description = "The party id owner of this dossier")
	private Long partyId;
	@Schema(description = "The dossier's year")
	private Integer year;
	@Schema(description = "The dossier's sector code")
	private String sectorCode;
	@Schema(description = "The dossier's sector description")
	private String sectorDescription;
	@Schema(description = "The dossier's module code")
	private String moduleCode;
	@Schema(description = "The dossier's module description")
	private String moduleDescription;
	@Schema(description = "The dossier's id")
	private Long dossierId;
	@Schema(description = "The dossier's code")
	private String dossierCode;
	@JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
	private Long processId;
	@Schema(description = "The dossier's status")
	private String processStatus;
	@Schema(description = "The dossier's status description")
	private String processStatusDescription;
	@Schema(description = "The dossier's closure date")
	private AbsoluteDate dtClosed;
	@Schema(description = "The dossier's flag for check if dossier is amendable")
	private Boolean flAmendable;

}
