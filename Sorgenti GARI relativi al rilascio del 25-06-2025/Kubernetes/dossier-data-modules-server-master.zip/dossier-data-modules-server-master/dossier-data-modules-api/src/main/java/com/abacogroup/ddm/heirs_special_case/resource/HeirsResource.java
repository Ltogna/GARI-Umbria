package com.abacogroup.ddm.heirs_special_case.resource;

import com.abacogroup.ddm.common.resources.ReqContext;
import com.abacogroup.ddm.common.resources.ResourceConstants;
import com.abacogroup.ddm.core.exceptions.HeirException;
import com.abacogroup.ddm.heirs_special_case.api.HeirRes;
import com.abacogroup.ddm.heirs_special_case.api.req.HeirCreateReq;
import com.abacogroup.ddm.heirs_special_case.api.req.HeirUpdateReq;
import com.abacogroup.ddm.heirs_special_case.core.HeirsService;
import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.codahale.metrics.annotation.Timed;

import io.dropwizard.auth.Auth;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.media.SchemaProperty;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.annotation.security.RolesAllowed;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.DefaultValue;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.HeaderParam;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

@Path(ResourceConstants.HEIRS_MODULE_API_PRIV + "/parties/{partyCuaa}/heirs")
@Tag(name = "Heirs", description = "Operations on Heirs")
@Timed
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
public class HeirsResource {

	private final HeirsService heirService;

	public HeirsResource(HeirsService heirService) {
		this.heirService = heirService;
	}

	@GET
	@Path("")
@RolesAllowed({ "DDM_HEIR_METHODS|EDITOR", "DDM_HEIR_METHODS|VIEWER" })
	@Operation(description = "Get the list of heirs", summary = "search heirs")
	@ApiResponse(responseCode = "200", description = "Get the list of filtered heirs", useReturnTypeSchema = true)
	public InfiniteListResults<HeirRes> search(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "tenant id") @PathParam("tenant") String tenantId,
			@Parameter(description = "party cuaa") @PathParam("partyCuaa") String partyCuaa,
			@Parameter(description = "heir cuaa") @QueryParam("heirCuaa") String heirCuaa,
	         @Parameter(description = "Next key used for infinite pagination") @QueryParam("nextKey") String nextKey,
			@Parameter(description = "page size") @QueryParam("pageSize") @DefaultValue("10") Integer pageSize) {

		return heirService.getHeirsByCuaa(new ReqContext(user, lang), partyCuaa, heirCuaa, nextKey, pageSize);
	}

	@POST
	@Path("")
	@RolesAllowed("DDM_HEIR_METHODS|EDITOR")
	@Operation(description = "Create a new heir", summary = "create new heir")
	@ApiResponse(responseCode = "200", description = "The created heir", useReturnTypeSchema = true)
	@ApiResponse(responseCode = "400", description = "heir creation error", content = @Content(mediaType = MediaType.APPLICATION_JSON, schema = @Schema(implementation = HeirException.ErrorBody.class)))
	@ApiResponse(responseCode = "422", description = "unprocessable content", content = @Content(mediaType = MediaType.APPLICATION_JSON, schemaProperties = @SchemaProperty(name = "errors", array = @ArraySchema(schema = @Schema(implementation = String.class)))))
	public HeirRes addHeir(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "tenant id") @PathParam("tenant") String tenantId,
			@Parameter(description = "party cuaa") @PathParam("partyCuaa") String partyCuaa,
			@NotNull @Valid HeirCreateReq heirCreateReq) {

		ReqContext reqContext = new ReqContext(user, lang);
		return heirService.insert(reqContext, partyCuaa, heirCreateReq);
	}
	
	@PUT
	@Path("/{heirId}")
	@RolesAllowed("DDM_HEIR_METHODS|EDITOR")
	@Operation(description = "Update a heir by id", summary = "update a heir")
	@ApiResponse(responseCode = "200", description = "The update heir", useReturnTypeSchema = true)
	@ApiResponse(responseCode = "400", description = "heir error", content = @Content(mediaType = MediaType.APPLICATION_JSON, schema = @Schema(implementation = HeirException.ErrorBody.class)))
	public HeirRes updateHeir(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "tenant id") @PathParam("tenant") String tenantId,
			@Parameter(description = "party cuaa") @PathParam("partyCuaa") String partyCuaa,
			@Parameter(description = "heirId") @PathParam("heirId") Long heirId,
			@NotNull @Valid HeirUpdateReq heirUpdateReq) {
		
		ReqContext reqContext = new ReqContext(user, lang);
		return heirService.update(reqContext, partyCuaa, heirId, heirUpdateReq);
	}
	
	@DELETE
	@Path("/{heirId}")
	@RolesAllowed("DDM_HEIR_METHODS|EDITOR")
	@Operation(description = "Update a heir by id", summary = "update heir")
	@ApiResponse(responseCode = "200", description = "The updated heir", useReturnTypeSchema = true)
	@ApiResponse(responseCode = "400", description = "heir update error", 
	content = @Content(mediaType = MediaType.APPLICATION_JSON, 
	schema = @Schema(implementation = HeirException.ErrorBody.class)))
	public Response deleteHeir(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "tenant id") @PathParam("tenant") String tenantId,
			@Parameter(description = "party cuaa") @PathParam("partyCuaa") String partyCuaa,
			@Parameter(description = "heirId") @PathParam("heirId") Long heirId) {

		ReqContext reqContext = new ReqContext(user, lang);
		return heirService.delete(reqContext, partyCuaa, heirId);
	}

}
