package com.abacogroup.ddm.doigt_quotas.api.services;

import com.abacogroup.ddm.DossierDataModulesConfiguration;
import com.abacogroup.ddm.common.resources.ReqContext;
import com.abacogroup.ddm.common.resources.ResourceConstants;
import com.abacogroup.ddm.core.AppConfigService;
import com.abacogroup.ddm.core.dto.appconfig.TreeUnitsConfig;
import com.abacogroup.ddm.doigt_quotas.api.repositories.DoIgtQuotaRepository;
import io.dropwizard.client.JerseyClientBuilder;
import io.dropwizard.core.setup.Environment;
import jakarta.ws.rs.client.Client;
import jakarta.ws.rs.client.WebTarget;
import jakarta.ws.rs.core.Response;

import java.time.LocalDateTime;

public class DoIgtQuotaService {
    private final Environment environment;
    private final DossierDataModulesConfiguration configuration;
    private final AppConfigService appConfigService;

    public DoIgtQuotaService(Environment environment, DossierDataModulesConfiguration configuration, AppConfigService appConfigService) {
        this.environment = environment;
        this.configuration = configuration;
        this.appConfigService = appConfigService;
    }

    public Response getQuotasByPartyId(ReqContext reqContext, Long partyId, String nextKey) {
        WebTarget avepaLegacyWebTarget = buildAvepaLegacyWebTarget(reqContext);
        return DoIgtQuotaRepository.getQuotasByPartyId(avepaLegacyWebTarget, reqContext, partyId, nextKey, ResourceConstants.DEFAULT_PAGE_SIZE);
    }

    private WebTarget buildAvepaLegacyWebTarget(ReqContext reqContext) {
        final Client client = new JerseyClientBuilder(environment)
                .using(configuration.getJerseyClient())
                .build("authorizations-client: " + LocalDateTime.now());

        String baseUrl = getBaseUrl(reqContext);

        return client.target(baseUrl);
    }

    private String getBaseUrl(ReqContext reqContext) {
        return appConfigService.getConfig(reqContext.getTenantId(), TreeUnitsConfig.CONFIG_KEY, TreeUnitsConfig.class)
                .map(TreeUnitsConfig::getConfiguration)
                .map(TreeUnitsConfig.Config::getDo_igt_quotas_url)
                .orElseThrow(() ->  new RuntimeException("Could not find BaseUrl for " + reqContext.getTenantId()));
    }
}
