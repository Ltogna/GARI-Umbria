package com.abacogroup.ddm.bundle.tenant;

import static com.abacogroup.bundles.Constants.ALL_TENANTS;

import com.abacogroup.bundles.listener.tenant.TenantMessage;
import com.abacogroup.bundles.listener.tenant.TenantMessageProcessor;
import com.abacogroup.ddm.db.dao.AnomalyCategoriesDAO;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class AnomalyCategoriesTenantMessageProcessor implements TenantMessageProcessor {

	private final AnomalyCategoriesDAO anomalyCategoriesDAO;

	public AnomalyCategoriesTenantMessageProcessor(AnomalyCategoriesDAO anomalyCategoriesDAO) {
		this.anomalyCategoriesDAO = anomalyCategoriesDAO;
	}

	@Override
	public void onMessage(TenantMessage message) {
		String tenantId = message.getTenantId();
		if (anomalyCategoriesDAO.countAll(tenantId) > 0L) {
			log.warn("anomaly categories already present for tenant {}", tenantId);
		} else {
			anomalyCategoriesDAO.insertNewTenant(ALL_TENANTS, tenantId);
			log.info("anomaly categories successfully inserted for tenant {}", tenantId);
		}
	}
}
