package com.abacogroup.ddm.heirs_special_case.api;

import com.abacogroup.jdbi.datatype.AbsoluteDate;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder(setterPrefix = "set")
@NoArgsConstructor
@AllArgsConstructor
public class HeirRes {

	@Schema(description = "party cuaa", required = true)	
	@NotNull
	private String cuaa;
	
	@Schema(description = "heir id", required = true)	
	@NotNull
	private Long heirId;
	
	@Schema(description = "heir cuaa", required = true)
	@NotNull
	private String heirCuaa;
	
	@Schema(description = "heir first name", required = true)
	@NotNull
	private String firstName;
	
	@Schema(description = "heir last name", required = true)
	@NotNull
	private String lastName;

	@Schema(description = "heir tax code", required = true)
	@NotNull
	private String taxCode;
	
	@Schema(description = "heir birth date", required = true)
	@NotNull
	private AbsoluteDate birthDate;
	
	@Schema(description = "succession date", required = true)
	@NotNull
	private AbsoluteDate successionDate;
	
	@Schema(description = "if true, has dossier", required = true)
	@NotNull
	@Builder.Default
	private Boolean hasDossier = false;
	
	@Schema(description = "if true, has delegation", required = true)
	@NotNull
	@Builder.Default
	private Boolean hasDelegation = false;

}
