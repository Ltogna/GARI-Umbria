package com.abacogroup.ddm.payment.resource.pub.mapper;

import com.abacogroup.ddm.payment.api.BankAccountDocumentRes;
import com.abacogroup.ddm.payment.api.v1.BankAccountDocumentResponseV1;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper
public interface BankAccountDocumentResponseMapper {

	BankAccountDocumentResponseMapper INSTANCE = Mappers.getMapper(BankAccountDocumentResponseMapper.class);

	BankAccountDocumentResponseV1 toResponseV1(BankAccountDocumentRes res);


}
