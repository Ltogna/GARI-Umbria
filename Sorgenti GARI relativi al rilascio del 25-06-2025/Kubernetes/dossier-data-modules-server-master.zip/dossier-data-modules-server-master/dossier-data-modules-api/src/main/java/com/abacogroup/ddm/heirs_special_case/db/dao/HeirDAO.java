package com.abacogroup.ddm.heirs_special_case.db.dao;

import java.util.List;

import org.jdbi.v3.core.result.ResultIterator;
import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.customizer.BindBean;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;
import org.jdbi.v3.sqlobject.transaction.Transactional;

import com.abacogroup.ddm.heirs_special_case.db.ntt.HeirEntity;
import com.abacogroup.jdbi.EnhancedSqlObject;


public interface HeirDAO extends Transactional<HeirDAO>, EnhancedSqlObject {

	@SqlQuery("§select_nextval(ddm_heirs_seq)§")
	Long nextSequenceValHeirId();
	
	@SqlUpdate("insert into ddm_heirs (pkid, tenant_id, heir_id, heir_cuaa, cuaa, fl_delegation, succession_date, "
			+ " user_id_insert, user_id_delete, dt_insert, dt_delete) \n"
			+ "values (:pkid, :tenantId, :heirId, :heirCuaa, :partyCuaa, :flDelegation, :successionDate, "
			+ " :userIdInsert, null, §current_timestamp§, TO_TIMESTAMP('9999-12-3123:59:59','YYYY-MM-DDHH24:MI:SS')) \n")
	void insertHeir(@Bind("tenantId") String tenantId, @Bind("userIdInsert") String userIdInsert,  @BindBean HeirEntity heirEntity);

	@SqlQuery("select h.pkid, \n"
			+ "  h.heir_id, \n"
			+ "  h.cuaa as partyCuaa, \n"
			+ "  h.heir_cuaa, \n"
			+ "  h.fl_delegation, \n"
			+ "  h.succession_date \n"
			+ "from ddm_heirs h \n"
			+ "where h.tenant_id = :tenantId \n"
			+ "  and h.cuaa = :partyCuaa \n"
			+ "  and (:heirCuaa is null or h.heir_cuaa = :heirCuaa) \n"
			+ "  and §current_timestamp§ between h.dt_insert and h.dt_delete \n"
			+ "")
	@RegisterBeanMapper(HeirEntity.class)
	ResultIterator<HeirEntity> getInfiniteHeirListByCuaa(@Bind("tenantId") String tenantId, @Bind("partyCuaa") String partyCuaa, @Bind("heirCuaa") String heirCuaa);
	
	@SqlQuery("select h.pkid, \n"
			+ "  h.heir_id, \n"
			+ "  h.cuaa as partyCuaa, \n"
			+ "  h.heir_cuaa, \n"
			+ "  h.fl_delegation, \n"
			+ "  h.succession_date \n"
			+ "from ddm_heirs h \n"
			+ "where h.tenant_id = :tenantId \n"
			+ "  and h.cuaa = :partyCuaa \n"
			+ "  and (:heirCuaa is null or h.heir_cuaa = :heirCuaa) \n"
			+ "  and §current_timestamp§ between h.dt_insert and h.dt_delete \n"
			+ "")
	@RegisterBeanMapper(HeirEntity.class)
	List<HeirEntity> getHeirListByCuaa(@Bind("tenantId") String tenantId, @Bind("partyCuaa") String partyCuaa, @Bind("heirCuaa") String heirCuaa);

	@SqlQuery("select h.pkid, \n"
			+ "  h.heir_id, \n"
			+ "  h.cuaa as partyCuaa, \n"
			+ "  h.heir_cuaa, \n"
			+ "  h.fl_delegation, \n"
			+ "  h.succession_date \n"
			+ "from ddm_heirs h \n"
			+ "where h.tenant_id = :tenantId \n"
			+ "  and h.heir_id = :heirId \n"
			+ "  and h.cuaa = :partyCuaa \n"
			+ "  and §current_timestamp§ between h.dt_insert and h.dt_delete \n"
			+ "")
	@RegisterBeanMapper(HeirEntity.class)
	HeirEntity getHeirsByHeirId(@Bind("tenantId") String tenantId, @Bind("partyCuaa") String partyCuaa, @Bind("heirId") Long heirId);
	
	@SqlUpdate("update ddm_heirs \n" 
			+ "set dt_delete = §current_timestamp§, \n" 
			+ "    user_id_delete = :userIdDelete \n"
			+ "where pkid = :pkid")
	void expireRow(@Bind("pkid") Long pkid, @Bind("userIdDelete") String userIdDelete);
	
}

