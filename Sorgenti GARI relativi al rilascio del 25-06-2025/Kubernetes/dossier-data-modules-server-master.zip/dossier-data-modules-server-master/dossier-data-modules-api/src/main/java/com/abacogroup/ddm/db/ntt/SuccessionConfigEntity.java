package com.abacogroup.ddm.db.ntt;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import com.abacogroup.jdbi.model.AuditEntity;

import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder(setterPrefix = "set", toBuilder = true)
@NoArgsConstructor
public class SuccessionConfigEntity implements AuditEntity {

	private Long pkid;
	private String namespace;
	private String successionCode;
	private String code;
	private String parentCode;
	private String attachmentType;
	private String attachmentTypeDescription;
	private Integer maxOccurrences;
	private Integer flMandatory;
	
	private LocalDateTime dtInsert;
	private String userIdInsert;
	private LocalDateTime dtDelete;
	private String userIdDelete;
	
	@Builder.Default
	private List<SuccessionConfigEntity> children = new ArrayList<>();
	
}
