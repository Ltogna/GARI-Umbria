package com.abacogroup.ddm.db.dao;

import com.abacogroup.ddm.db.ntt.AppConfigEntity;
import com.abacogroup.jdbi.EnhancedSqlObject;
import com.abacogroup.jdbi.model.AuditEntity;
import java.util.Collection;
import java.util.List;
import java.util.Optional;
import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.customizer.BindBean;
import org.jdbi.v3.sqlobject.customizer.BindList;
import org.jdbi.v3.sqlobject.statement.GetGeneratedKeys;
import org.jdbi.v3.sqlobject.statement.SqlBatch;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;
import org.jdbi.v3.sqlobject.transaction.Transactional;

public interface AppConfigDAO extends Transactional<AppConfigDAO>, EnhancedSqlObject {

	@SqlQuery("select id, tenant_id, configuration_key, configuration, dt_insert, user_id_insert, dt_delete, user_id_delete " +
			"from ddm_app_configuration pvc " +
			"where pvc.tenant_id = :tenantId  " +
			"AND (§current_timestamp§ between pvc.dt_insert and pvc.dt_delete)")
	@RegisterBeanMapper(AppConfigEntity.class)
	List<AppConfigEntity> findAll(@Bind("tenantId") String tenantId);

	@SqlQuery("select id, tenant_id, configuration_key, configuration, dt_insert, user_id_insert, dt_delete, user_id_delete " +
			"from ddm_app_configuration pvc " +
			"where pvc.tenant_id = :tenantId  " +
			"and pvc.configuration_key in (<configurationKeys>)  " +
			"AND (§current_timestamp§ between pvc.dt_insert and pvc.dt_delete)")
	@RegisterBeanMapper(AppConfigEntity.class)
	List<AppConfigEntity> findByConfigKeyIn(@Bind("tenantId") String tenantId,
			@BindList("configurationKeys") Collection<String> configurationKeys);

	@SqlQuery("select id, tenant_id, configuration_key, configuration, dt_insert, user_id_insert, dt_delete, user_id_delete " +
			"from ddm_app_configuration pvc " +
			"where pvc.tenant_id = :tenantId  " +
			"and pvc.id = :id  " +
			"AND (§current_timestamp§ between pvc.dt_insert and pvc.dt_delete)")
	@RegisterBeanMapper(AppConfigEntity.class)
	Optional<AppConfigEntity> findById(@Bind("tenantId") String tenantId, @Bind("id") Long id);

	@SqlQuery("select id, tenant_id, configuration_key, configuration, dt_insert, user_id_insert, dt_delete, user_id_delete " +
			"from ddm_app_configuration pvc " +
			"where pvc.tenant_id = :tenantId  " +
			"and pvc.configuration_key = :key  " +
			"AND (§current_timestamp§ between pvc.dt_insert and pvc.dt_delete)")
	@RegisterBeanMapper(AppConfigEntity.class)
	Optional<AppConfigEntity> findByKey(@Bind("tenantId") String tenantId, @Bind("key") String key);

	@SqlUpdate("insert into ddm_app_configuration (tenant_id, configuration_key, configuration, dt_insert, user_id_insert, dt_delete, user_id_delete) " +
			"values (:tenantId, :configurationKey, :configuration, :dtInsert, :userIdInsert, :dtDelete, :userIdDelete)")
	@GetGeneratedKeys("id")
	Long insert(@BindBean AppConfigEntity entity);

	@SqlBatch("insert into ddm_app_configuration (tenant_id, configuration_key, configuration, dt_insert, user_id_insert, dt_delete, user_id_delete) " +
			"§select_from_dual(:tenantId, :configurationKey, :configuration, :dtInsert, :userIdInsert, :dtDelete, :userIdDelete)§ " +
			"where not exists (" +
			"	select configuration_key " +
			"	from ddm_app_configuration " +
			"	where tenant_id = :tenantId " +
			"	and configuration_key = :configurationKey " +
			"	AND (§current_timestamp§ between dt_insert and dt_delete) )")
	void insertIdempotent(@BindBean AppConfigEntity... entity);

	@SqlUpdate("insert into ddm_app_configuration (tenant_id, configuration_key, configuration, dt_insert, user_id_insert, dt_delete, user_id_delete) " +
			"select :newTenantId as tenant_id, configuration_key, configuration, :dtInsert, :userIdInsert, :dtDelete, :userIdDelete " +
			"from ddm_app_configuration " +
			"where tenant_id = :sourceTenant " +
			"AND (§current_timestamp§ between dt_insert and dt_delete) ")
	void insertNewTenant(
			@Bind("sourceTenant") String sourceTenant,
			@Bind("newTenantId") String newTenantId,
			@BindBean AuditEntity audit);

	@SqlUpdate("update ddm_app_configuration set dt_delete= :dtDelete, user_id_delete= :userIdDelete WHERE id= :id")
	void expireRow(@BindBean AppConfigEntity entity);

	@SqlUpdate("update ddm_app_configuration " +
			"set dt_delete= :dtDelete, user_id_delete= :userIdDelete " +
			"WHERE configuration_key in (<keys>) " +
			"and tenant_id = :tenantId " +
			"AND (§current_timestamp§ between dt_insert and dt_delete) ")
	void expireRowsByKey(@BindBean AuditEntity audit, @Bind("tenantId") String tenantId, @BindList("keys") List<String> keys);

	@SqlQuery("select count(*) FROM ddm_app_configuration where tenant_id = :tenantId ")
	Long countAll(@Bind("tenantId") String tenantId);

}
