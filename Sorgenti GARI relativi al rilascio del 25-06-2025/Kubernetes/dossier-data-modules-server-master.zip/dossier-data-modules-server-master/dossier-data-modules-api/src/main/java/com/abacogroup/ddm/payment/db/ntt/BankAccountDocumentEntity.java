package com.abacogroup.ddm.payment.db.ntt;

import com.abacogroup.jdbi.model.AuditEntity;
import java.time.LocalDateTime;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder(setterPrefix = "set")
@NoArgsConstructor
public class BankAccountDocumentEntity implements AuditEntity {

	private Long pkid;
	private Long bankAccountId;
	private String definitionCode;
	private Long documentId;

	private LocalDateTime dtInsert;
	private String userIdInsert;
	private LocalDateTime dtDelete;
	private String userIdDelete;

}
