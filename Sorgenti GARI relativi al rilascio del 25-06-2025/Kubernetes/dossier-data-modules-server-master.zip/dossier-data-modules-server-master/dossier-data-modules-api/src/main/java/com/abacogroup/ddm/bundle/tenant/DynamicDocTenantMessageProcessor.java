package com.abacogroup.ddm.bundle.tenant;

import static com.abacogroup.bundles.Constants.ALL_TENANTS;

import com.abacogroup.bundles.initializer.impl.exceptions.BundleException;
import com.abacogroup.bundles.listener.tenant.TenantMessage;
import com.abacogroup.bundles.listener.tenant.TenantMessageProcessor;
import com.abacogroup.ddm.bundle.BundleConstants;
import com.abacogroup.ddm.common.core.AuditHelper;
import com.abacogroup.ddm.db.dao.DocTypeRelationDAO;
import com.abacogroup.ddm.db.ntt.DocTypeRelationEntity;
import com.abacogroup.dynamicdocuments.bean.DocumentDefinition;
import com.abacogroup.dynamicdocuments.services.DocumentTypeService;
import com.fasterxml.jackson.core.JsonProcessingException;
import java.io.IOException;
import java.util.Optional;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class DynamicDocTenantMessageProcessor implements TenantMessageProcessor {

	private final DocTypeRelationDAO docTypeRelationDAO;
	private final DocumentTypeService documentTypeService;

	public DynamicDocTenantMessageProcessor(DocTypeRelationDAO docTypeRelationDAO, DocumentTypeService documentTypeService) {
		this.docTypeRelationDAO = docTypeRelationDAO;
		this.documentTypeService = documentTypeService;
	}

	@Override
	public void onMessage(TenantMessage tenantMessage) {

		String tenantId = tenantMessage.getTenantId();
		if (docTypeRelationDAO.countAll(tenantId) > 0L) {
			log.warn("docType relations already present for tenant {}", tenantId);
		} else {
			DocTypeRelationEntity auditType = new DocTypeRelationEntity();
			AuditHelper.setAuditForInsert(BundleConstants.SYSTEM_USER, docTypeRelationDAO, auditType);
			docTypeRelationDAO.insertNewTenant(ALL_TENANTS, tenantId, auditType);
			documentTypeService.getDocumentDefinitionCodes(ALL_TENANTS)
					.forEach(typeCode -> storeDocDefinition(tenantId, typeCode));
		}

	}

	private void storeDocDefinition(String tenantId, String typeCode) {
		try {
			Optional<DocumentDefinition> documentDefinition =
					documentTypeService.getDocumentDefinition(ALL_TENANTS, typeCode);
			if (documentDefinition.isPresent()) {
				documentTypeService.saveDocumentType(tenantId, documentDefinition.get(), BundleConstants.SYSTEM_USER);
			}

		} catch (JsonProcessingException e) {
			throw new BundleException("error in doc serialization", e);
		} catch (IOException e) {
			throw new BundleException("error saving doctype", e);
		}
	}
}
