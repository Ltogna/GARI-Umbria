package com.abacogroup.ddm.core.cli;

import static com.abacogroup.anomalyregistry.CliConstants.API_V1_PUB;

import com.abacogroup.anomalyregistry.api.v1.AnomalySearchResponse;
import com.abacogroup.anomalyregistry.api.v1.req.AnomalyRequest;
import com.abacogroup.anomalyregistry.api.v1.req.AnomalySearchRequest;
import com.abacogroup.anomalyregistry.core.cli.v1.AnomalyClient;
import com.abacogroup.ddm.common.client.ClientHelper;
import com.abacogroup.ddm.common.resources.ReqContext;
import com.abacogroup.dropwizard.auth.sso2.User;
import jakarta.ws.rs.client.WebTarget;
import jakarta.ws.rs.core.GenericType;
import jakarta.ws.rs.core.MultivaluedHashMap;
import jakarta.ws.rs.core.MultivaluedMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class AnomalyDdmClientImpl implements AnomalyClient {

	public static final String ANOMALIES = "anomalies";
	private final ClientHelper clientHelper;

	public AnomalyDdmClientImpl(WebTarget anmBaseTarget) {
		clientHelper = new ClientHelper(anmBaseTarget);
	}

	@Override
	public List<AnomalySearchResponse> search(String lang, User user, String entityCode, AnomalySearchRequest searchRequest) {

		String tenantId = user.getTenant();

		Map<String, Object> pathVars = Map.of(
				"tenant", tenantId,
				"entityCode", entityCode
		);
		MultivaluedMap<String, Object> queryParams = new MultivaluedHashMap<>();
		Optional.ofNullable(searchRequest.getGroupCode()).ifPresent(v -> queryParams.addAll("groupCode", v.toArray()));
		Optional.ofNullable(searchRequest.getTypeCode()).ifPresent(v -> queryParams.addAll("typeCode", v.toArray()));
		Optional.ofNullable(searchRequest.getEntityId()).ifPresent(v -> queryParams.addAll("entityId", v.toArray()));
		Optional.ofNullable(searchRequest.getTypeId()).ifPresent(v -> queryParams.addAll("typeId", v.toArray()));

		List<AnomalySearchResponse> anomalySearchResponses = clientHelper.get(String.format("%s/%s/%s", API_V1_PUB, ANOMALIES, "{entityCode}"),
				new ReqContext(user, lang), pathVars, queryParams, new GenericType<>() {});
		return anomalySearchResponses;
	}

	@Override
	public void add(String lang, User user, List<AnomalyRequest> req) {
		String tenantId = user.getTenant();

		Map<String, Object> pathVars = Map.of(
				"tenant", tenantId
		);
		MultivaluedMap<String, Object> queryParams = null;

		clientHelper.post(String.format("%s/%s", API_V1_PUB, ANOMALIES), new ReqContext(user, lang), pathVars, queryParams, req, new GenericType<>() {});

	}

	@Override
	public void expire(String lang, User user, List<AnomalyRequest> req) {

		String tenantId = user.getTenant();

		Map<String, Object> pathVars = Map.of(
				"tenant", tenantId
		);
		MultivaluedMap<String, Object> queryParams = null;

		clientHelper.post(String.format("%s/%s/%s", API_V1_PUB, ANOMALIES, "expired"), new ReqContext(user, lang), pathVars, queryParams, req, new GenericType<>() {});

	}

}
