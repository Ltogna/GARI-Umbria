package com.abacogroup.ddm.aptitudes.api.repositories;

import com.abacogroup.ddm.common.core.cli.impl.TokenRelayStrategy;
import com.abacogroup.ddm.common.resources.ReqContext;
import jakarta.ws.rs.client.Invocation;
import jakarta.ws.rs.client.WebTarget;
import jakarta.ws.rs.core.Response;

import java.util.Objects;

public class AptitudeRepository {
    public static Response getAptitudesGroupedByVineCode(WebTarget vineGisWebTarget, ReqContext reqContext, String referenceDate, Long partyId, String nextKey) {
        WebTarget path = vineGisWebTarget
                .path(reqContext.getTenantId())
                .path("public/v1/lpis/units/vine-unit/party")
                .path(String.valueOf(partyId))
                .path("summary/aptitudes")
                .path(referenceDate);

        if (Objects.nonNull(nextKey)) {
            path = path.queryParam("next_key", nextKey);
        }

        Invocation.Builder builder = addAuthorizationHeader(path, reqContext);

        return builder.get();
    }

    public static Response getAllAptitudesByPartyId(WebTarget vineGisWebTarget, ReqContext reqContext, String referenceDate,
                                                    Long partyId, String vineCode, String nextKey, Integer pageSize) {
        WebTarget path = vineGisWebTarget
                .path(reqContext.getTenantId())
                .path("public/v1/lpis/units/vine-unit/party")
                .path(String.valueOf(partyId))
                .path("summary/aptitudes")
                .path(referenceDate)
                .path(vineCode);

        if (Objects.nonNull(pageSize)) {
            path = path.queryParam("page_size", pageSize);
        }

        if (Objects.nonNull(nextKey)) {
            path = path.queryParam("next_key", nextKey);
        }

        Invocation.Builder builder = addAuthorizationHeader(path, reqContext);

        return builder.get();
    }

    public static Response getAptitudeById(WebTarget vineGisWebTarget, ReqContext reqContext, String referenceDate,
                                           Long parcelId, Long landCoversId, Long vineUnitId, Long vineAptitudeId) {
        WebTarget path = vineGisWebTarget
                .path(reqContext.getTenantId())
                .path("public/v1/lpis/parcels")
                .path(referenceDate)
                .path(String.valueOf(parcelId))
                .path("land-covers")
                .path(String.valueOf(landCoversId))
                .path("units/vine-unit")
                .path(String.valueOf(vineUnitId))
                .path("aptitudes")
                .path(String.valueOf(vineAptitudeId));

        Invocation.Builder builder = addAuthorizationHeader(path, reqContext);

        return builder.get();
    }

    private static Invocation.Builder addAuthorizationHeader(WebTarget webTarget, ReqContext reqContext) {
        TokenRelayStrategy authorizationStrategy = new TokenRelayStrategy();
        return webTarget.request()
                .header("Authorization", authorizationStrategy.getAuthorization(reqContext.getUser()));
    }
}
