package com.abacogroup.ddm.payment.core;

import com.abacogroup.ddm.api.v1.PartyDetailResponseV1;
import com.abacogroup.ddm.common.resources.ReqContext;
import com.abacogroup.ddm.payment.api.BankAccountSearchRes;
import com.abacogroup.ddm.payment.api.req.BankAccountCreateReq;
import com.abacogroup.ddm.payment.api.req.BankAccountSearchReq;
import com.abacogroup.ddm.payment.api.req.BankAccountUpdateReq;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import java.util.Optional;

public interface BankAccountService {

	BankAccountSearchRes insert(ReqContext reqContext, Long partyId, BankAccountCreateReq createReq);

	Optional<BankAccountSearchRes> getById(ReqContext reqContext, Long partyId, Long accountId);

	Optional<BankAccountSearchRes> getActiveDefault(ReqContext reqContext, Long partyId);

	InfiniteListResults<BankAccountSearchRes> search(ReqContext reqContext, Long partyId, BankAccountSearchReq searchRequest, String nextKey);

	BankAccountSearchRes update(ReqContext reqContext, Long partyId, Long accountId, BankAccountUpdateReq updateReq);

	BankAccountSearchRes updateDayTo(ReqContext reqContext, Long partyId, Long accountId, AbsoluteDate dayTo);

	InfiniteListResults<PartyDetailResponseV1> getByIban(ReqContext reqContext, String iban, String referenceDate, String nextKey);

}
