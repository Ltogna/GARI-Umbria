package com.abacogroup.ddm.heirs_special_case.core;

import com.abacogroup.ddm.common.resources.ReqContext;
import com.abacogroup.ddm.heirs_special_case.core.dto.HeirEventType;

public interface HeirEventProducer {
	void pushHeirEvent(ReqContext reqContext, Long partyId, String partyCuaa, HeirEventType eventType);

	void pushHeirEvent(String tenant, String username, String lang, Long partyId, String partyCuaa, HeirEventType eventType);
}
