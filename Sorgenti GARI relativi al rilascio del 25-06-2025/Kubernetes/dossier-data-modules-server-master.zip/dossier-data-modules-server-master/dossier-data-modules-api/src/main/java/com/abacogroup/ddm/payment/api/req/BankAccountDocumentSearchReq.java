package com.abacogroup.ddm.payment.api.req;

import com.abacogroup.ddm.common.resources.ReqContext;
import com.abacogroup.ddm.common.resources.ResourceConstants;
import com.abacogroup.ddm.common.resources.req.BaseSearchReq;
import com.abacogroup.jdbi.criteria.Criteria;
import com.abacogroup.jdbi.criteria.CriteriaBuilder;
import com.abacogroup.jdbi.orderby.OrderByBuilder;
import com.abacogroup.jdbi.orderby.OrderByElement;
import com.abacogroup.jdbi.orderby.SortDirection;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import jakarta.ws.rs.QueryParam;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;
import org.apache.commons.lang3.StringUtils;

@Data
@NoArgsConstructor
@Accessors(chain = true)
public class BankAccountDocumentSearchReq implements BaseSearchReq {

	@Parameter(in = ParameterIn.QUERY, description = "DD definition Code")
	@QueryParam("definitionCode")
	private String definitionCode;

	@Override
	public int getPageSize() {
		return ResourceConstants.PAGE_SIZE;
	}

	@Override
	public Criteria getCriteria(ReqContext reqContext) {
		List<Criteria> specs = new ArrayList<>();

		Optional.ofNullable(this.getDefinitionCode())
				.map(StringUtils::trimToNull)
				.ifPresent(v -> specs.add(CriteriaBuilder.string("gd.definition_code").eq(v)));

		return CriteriaBuilder.and(specs.toArray(new Criteria[0]));
	}

	@Override
	public OrderByElement getSort() {
		return OrderByBuilder.field(" gd.pkid")
				.direction(SortDirection.DESC);
	}
}
