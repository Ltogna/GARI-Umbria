package com.abacogroup.ddm.heirs_special_case.api;

import com.abacogroup.dynamicdocuments.bean.SummaryFieldDefinition;
import java.util.LinkedHashMap;
import java.util.List;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@NoArgsConstructor
@SuperBuilder(setterPrefix = "set")
public class HeirDocumentRes {

	private Long partyId;
	private String cuaa;
	private String definitionCode;
	private Long documentId;

	private String bucketName;

	private List<SummaryFieldDefinition> summaryFieldDefinitions;
	private LinkedHashMap<String, Object> data;

}
