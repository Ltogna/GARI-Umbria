package com.abacogroup.ddm.bundle.config;

import com.abacogroup.bundles.initializer.impl.exceptions.BundleException;
import com.abacogroup.bundles.listener.configdata.ConfigDataMessage;
import com.abacogroup.bundles.listener.configdata.ConfigMessageProcessor;
import com.abacogroup.ddm.bundle.BundleConstants;
import com.abacogroup.ddm.bundle.FileOperationEnum;
import com.abacogroup.ddm.common.core.AuditHelper;
import com.abacogroup.ddm.core.dto.appconfig.BaseAppConfig;
import com.abacogroup.ddm.db.dao.AppConfigDAO;
import com.abacogroup.ddm.db.ntt.AppConfigEntity;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.jayway.jsonpath.JsonPath;
import jakarta.validation.ConstraintViolation;
import jakarta.validation.ConstraintViolationException;
import jakarta.validation.Valid;
import jakarta.validation.Validation;
import jakarta.validation.Validator;
import jakarta.validation.ValidatorFactory;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.function.Function;
import java.util.stream.Collectors;
import lombok.Data;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

@Slf4j
public class AppConfigMessageProcessor implements ConfigMessageProcessor {

	private final AppConfigDAO appConfigDAO;
	private final ObjectMapper mapper;

	public AppConfigMessageProcessor(AppConfigDAO appConfigDAO) {
		this.appConfigDAO = appConfigDAO;

		this.mapper = new ObjectMapper();
	}

	@Override
	public String getDomainName() {
		return BundleConstants.DOMAIN_APP_CONFIG;
	}

	@Override
	public void onMessage(ConfigDataMessage message) {
		String tenantId = message.getTenantId();

		Function<String, FileOperationEnum> groupingPredicate = x -> {
			if (StringUtils.containsIgnoreCase(x, "delete")) {
				return FileOperationEnum.DELETE;
			} else {
				return FileOperationEnum.DEFAULT;
			}
		};

		List<Path> paths = message.getConfigFiles();
		var map = paths.stream()
				.collect(Collectors.groupingBy(x -> groupingPredicate.apply(x.toString()),
						Collectors.toCollection(ArrayList::new)));

		map.getOrDefault(FileOperationEnum.DELETE, new ArrayList<>()).forEach(path -> removeContent(tenantId, path));
		map.getOrDefault(FileOperationEnum.DEFAULT, new ArrayList<>()).forEach(path -> addContent(tenantId, path));
	}

	private void removeContent(String tenantId, Path path) {
		try {
			String jsonContent = Files.readString(path);
			List<String> keys = JsonPath.parse(jsonContent).read("$[*].configurationKey");
			AuditHelper.expire(new AppConfigEntity(), BundleConstants.SYSTEM_USER,
					a -> appConfigDAO.expireRowsByKey(a, tenantId, keys),
					appConfigDAO.getCurrentTimestamp());
		} catch (IOException e) {
			throw new BundleException(String.format("error reading %s", path), e);
		}
	}

	private void addContent(String tenantId, Path path) {
		try {
			String jsonContent = Files.readString(path);

			List<String> keys = JsonPath.parse(jsonContent).read("$[*].configurationKey");
			AuditHelper.expire(new AppConfigEntity(), BundleConstants.SYSTEM_USER,
					a -> appConfigDAO.expireRowsByKey(a, tenantId, keys),
					appConfigDAO.getCurrentTimestamp());

			AppConfigEntity[] entities = mapEntities(tenantId, jsonContent);
			AuditHelper.setAuditForInsert(BundleConstants.SYSTEM_USER, appConfigDAO, entities);
			appConfigDAO.insertIdempotent(entities);

		} catch (IOException e) {
			throw new BundleException(String.format("error reading %s", path), e);
		}
	}

	private AppConfigEntity[] mapEntities(String tenantId, String jsonContent) {
		try (ValidatorFactory validatorFactory = Validation.buildDefaultValidatorFactory()) {
			List<BaseAppConfig<?>> list = mapper.readValue(jsonContent, new TypeReference<>() {});

			Validator validator = validatorFactory.getValidator();
			Set<ConstraintViolation<ValidList<BaseAppConfig<?>>>> constraintViolations = validator.validate(new ValidList<>(list));

			if (!constraintViolations.isEmpty()) {
				throw new BundleException("error in content validation", new ConstraintViolationException(constraintViolations));
			}

			List<AppConfigEntity> entities = new ArrayList<>();
			for (BaseAppConfig<?> x : list) {

				entities.add(AppConfigEntity.builder()
						.setTenantId(tenantId)
						.setConfigurationKey(x.getConfigurationKey())
						.setConfiguration(mapper.writeValueAsString(x.getConfiguration()))
						.build());
			}

			return entities.toArray(AppConfigEntity[]::new);
		} catch (BundleException be) {
			throw be;
		} catch (Exception e) {
			throw new BundleException("error in deserialization json ", e);
		}
	}

	@Data
	public static class AppConfigMixin {
		@JsonProperty("configurationKey")
		private String configurationKey;

		@JsonProperty("configuration")
		private JsonNode configuration;

		String getConfigurationAsString() {
			if (configuration.isEmpty() || configuration.isNull()) {
				return null;
			}
			return configuration.toString();
		}
	}

	@Getter
	@RequiredArgsConstructor
	static class ValidList<E> {

		@Valid
		private final List<E> elements;
	}

}
