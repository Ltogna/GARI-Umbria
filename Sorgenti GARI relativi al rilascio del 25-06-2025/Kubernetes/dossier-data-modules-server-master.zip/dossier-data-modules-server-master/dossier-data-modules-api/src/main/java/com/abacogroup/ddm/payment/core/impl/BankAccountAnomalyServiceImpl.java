package com.abacogroup.ddm.payment.core.impl;

import static com.abacogroup.ddm.DossierDataModulesApplication.PAYMENT_MODULE;

import com.abacogroup.anomalyregistry.api.v1.AnomalySearchResponse;
import com.abacogroup.ddm.api.AnomalyLevelEnum;
import com.abacogroup.ddm.api.DdmAnomaliesRes;
import com.abacogroup.ddm.common.resources.ReqContext;
import com.abacogroup.ddm.core.DdmAnomalyService;
import com.abacogroup.ddm.core.exceptions.BankAccountException;
import com.abacogroup.ddm.core.exceptions.BankAccountException.ErrEnum;
import com.abacogroup.ddm.payment.db.dao.BankAccountDAO;
import com.abacogroup.ddm.payment.db.ntt.BankAccountEntity;
import java.util.List;
import java.util.Map;

public class BankAccountAnomalyServiceImpl implements com.abacogroup.ddm.payment.core.BankAccountAnomalyService {

	private final BankAccountDAO bankAccountDAO;
	private final DdmAnomalyService anomalyService;

	public BankAccountAnomalyServiceImpl(BankAccountDAO bankAccountDAO, DdmAnomalyService anomalyService) {
		this.bankAccountDAO = bankAccountDAO;
		this.anomalyService = anomalyService;
	}

	@Override
	public DdmAnomaliesRes getAnomalies(ReqContext reqContext, Long partyId, Long accountId) {

		BankAccountEntity bankAccount = bankAccountDAO.findById(reqContext.getTenantId(), partyId, accountId)
				.orElseThrow(() -> new BankAccountException(ErrEnum.BANK_ACCOUNT_NOT_FOUND,
						String.format("bank account %s not found", accountId)));

		Map<AnomalyLevelEnum, List<AnomalySearchResponse>> anomaliesGrouped = anomalyService.getAnomaliesGroupedByLevel(reqContext, PAYMENT_MODULE,
				AnomalyHelper.BANK_ACCOUNT_CODE, bankAccount.getId().toString());

		return new DdmAnomaliesRes(anomaliesGrouped);
	}

}
