package com.abacogroup.ddm.core.dto.appconfig;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonSubTypes;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.fasterxml.jackson.annotation.JsonTypeInfo.As;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@JsonTypeInfo(use = JsonTypeInfo.Id.NAME, include = As.EXISTING_PROPERTY, property = "configurationKey", visible = true)
@JsonSubTypes({
		@JsonSubTypes.Type(value = PaymentDefaultAccount.class, name = PaymentDefaultAccount.CONFIG_KEY),
		@JsonSubTypes.Type(value = PaymentValidation.class, name = PaymentValidation.CONFIG_KEY),
		@JsonSubTypes.Type(value = PaymentRegexValidation.class, name = PaymentRegexValidation.CONFIG_KEY),
		@JsonSubTypes.Type(value = TreeUnitsConfig.class, name = TreeUnitsConfig.CONFIG_KEY),
		@JsonSubTypes.Type(value = HeirConfig.class, name = HeirConfig.CONFIG_KEY)
})
@Data
@SuperBuilder(setterPrefix = "set")
@NoArgsConstructor
@AllArgsConstructor
public abstract class BaseAppConfig<T> {

	@NotBlank
	@JsonProperty("configurationKey")
	private String configurationKey;

	@Valid
	@NotNull
	@JsonProperty("configuration")
	public abstract T getConfiguration();

	public static String asJson(String key, String configuration) {
		return String.format("{\"configurationKey\":\"%s\",\"configuration\":%s}", key, configuration);
	}

}
