package com.abacogroup.ddm.db.ntt;

import com.abacogroup.ddm.api.AnomalyLevelEnum;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder(setterPrefix = "set")
@NoArgsConstructor
@AllArgsConstructor
public class AnomalyCategoriesEntity {

	private String namespace;
	private String groupCode;
	private String code;
	private AnomalyLevelEnum level;
	private Integer flExclude;
}
