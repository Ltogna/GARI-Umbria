package com.abacogroup.ddm.heirs_special_case.core.impl;

import static com.abacogroup.ddm.DossierDataModulesApplication.HEIR_MODULE;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

import com.abacogroup.ddm.common.resources.ReqContext;
import com.abacogroup.ddm.core.PartyService;
import com.abacogroup.ddm.core.cli.DossierClient;
import com.abacogroup.ddm.core.dto.DossierByPartyDTO;
import com.abacogroup.ddm.core.exceptions.HeirException;
import com.abacogroup.ddm.core.exceptions.HeirException.ErrEnum;
import com.abacogroup.ddm.db.dao.DAOContainer;
import com.abacogroup.ddm.db.dao.SuccessionConfigDAO;
import com.abacogroup.ddm.db.ntt.SuccessionConfigEntity;
import com.abacogroup.ddm.heirs_special_case.api.HeirRes;
import com.abacogroup.ddm.heirs_special_case.api.PartyCacheData;
import com.abacogroup.ddm.heirs_special_case.api.req.HeirCreateReq;
import com.abacogroup.ddm.heirs_special_case.api.req.HeirUpdateReq;
import com.abacogroup.ddm.heirs_special_case.core.HeirEventProducer;
import com.abacogroup.ddm.heirs_special_case.core.HeirsService;
import com.abacogroup.ddm.heirs_special_case.core.dto.HeirEventType;
import com.abacogroup.ddm.heirs_special_case.core.mapper.HeirMapper;
import com.abacogroup.ddm.heirs_special_case.db.dao.HeirDAO;
import com.abacogroup.ddm.heirs_special_case.db.dao.HeirDocumentDAO;
import com.abacogroup.ddm.heirs_special_case.db.ntt.HeirDocumentEntity;
import com.abacogroup.ddm.heirs_special_case.db.ntt.HeirEntity;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.jdbi.paging.InfiniteListResults;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import jakarta.ws.rs.core.Response;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class HeirsServiceImpl implements HeirsService {

	private final HeirDAO heirDAO;
	private final HeirDocumentDAO  heirDocumentDAO;
	private final SuccessionConfigDAO successionConfigDAO;

	private final PartyService partyService;
	private final DossierClient dossierClient;
	
	private final HeirEventProducer heirEventProducer;

	public HeirsServiceImpl(DAOContainer daoContainer, PartyService partyService, 
			DossierClient dossierClient, HeirEventProducer heirEventProducer) {
		this.heirDAO = daoContainer.getHeirDAO();
		this.heirDocumentDAO = daoContainer.getHeirDocumentDAO();
		this.successionConfigDAO = daoContainer.getSuccessionConfigDAO();

		this.partyService = partyService;
		this.dossierClient = dossierClient;
		
		this.heirEventProducer = heirEventProducer;
	}

	@Override
	public InfiniteListResults<HeirRes> getHeirsByCuaa(ReqContext reqContext, String partyCuaa, String heirCuaa, String nextKey, Integer pageSize) {
		checkPartyCuaaExists(reqContext, partyCuaa);

		// Check if the heir is a valid party
		if(heirCuaa != null) {
			checkPartyCuaaExists(reqContext, heirCuaa);
		}

		return heirDAO.infinite(
				() -> heirDAO.getInfiniteHeirListByCuaa(reqContext.getTenantId(), partyCuaa, heirCuaa),
				nextKey, pageSize)
				.map(h -> {
					PartyCacheData heirParty = getPartyByCuaa(reqContext, h.getHeirCuaa());
					HeirRes heirRes = HeirMapper.INSTANCE.entityToRes(h, heirParty);

					List<DossierByPartyDTO> dossierList = dossierClient.getDossierListByPartyId(reqContext, heirParty.getId());
					heirRes.setHasDossier(dossierList != null && !dossierList.isEmpty());
					return heirRes;
				});
	}
	
	public List<HeirRes> getHeirsListByCuaa(ReqContext reqContext, String partyCuaa, String heirCuaa) {
		List<HeirRes> heirs = new ArrayList<>();
		InfiniteListResults<HeirRes> heirsInfinite = null;
		
		do {
			heirsInfinite = getHeirsByCuaa(reqContext, partyCuaa, heirCuaa, heirsInfinite != null ? heirsInfinite.getNextKey() : null, 100);
			heirs.addAll(heirsInfinite.getRecords());
		} while (heirsInfinite != null && heirsInfinite.getNextKey() != null);
		
		return heirs;
	}

	@Override
	public HeirRes insert(ReqContext reqContext, String partyCuaa, @NotNull @Valid HeirCreateReq heirCreateReq) {

		PartyCacheData party = getPartyByCuaa(reqContext, partyCuaa);

		// Check if the heir is a valid party
		checkPartyCuaaExists(reqContext, heirCreateReq.getHeirCuaa());
		
		if (partyCuaa.equals(heirCreateReq.getHeirCuaa())) {
			throw new HeirException(ErrEnum.HEIR_CUAA_SAME_AS_PARTY,
					"CUAA erede non può essere uguale al CUAA del soggetto");
		}

		// Check if the heir already exists
		List<HeirEntity> existingHeirs = heirDAO.getHeirListByCuaa(reqContext.getTenantId(), partyCuaa, heirCreateReq.getHeirCuaa());
		if (!existingHeirs.isEmpty()) {
			throw new HeirException(ErrEnum.HEIR_ALREADY_EXISTS, "Erede già esistente con CUAA: " + heirCreateReq.getHeirCuaa());
		}

		Long id = heirDAO.nextSequenceValHeirId();

		HeirEntity entity = HeirEntity.builder()
				.setPkid(id)
				.setHeirId(id)
				.setPartyCuaa(partyCuaa)
				.setHeirCuaa(heirCreateReq.getHeirCuaa())
				.setFlDelegation(heirCreateReq.getHasDelegation() != null && heirCreateReq.getHasDelegation() ? 1 : 0)
				.setSuccessionDate(heirCreateReq.getSuccessionDate() != null ? heirCreateReq.getSuccessionDate() : AbsoluteDate.of(LocalDate.now()))
				.build();
		heirDAO.insertHeir(reqContext.getTenantId(), reqContext.getUser().getUserId(), entity);
		
		heirEventProducer.pushHeirEvent(reqContext, party.getId(), party.getCode(), HeirEventType.NEW_HEIR);

		return getHeirByHeirId(reqContext, partyCuaa, id);
	}

	@Override
	public HeirRes update(ReqContext reqContext, String partyCuaa, Long heirId, @NotNull @Valid HeirUpdateReq heirUpdateReq) {
		PartyCacheData party = getPartyByCuaa(reqContext, partyCuaa);

		HeirEntity heirEntity = heirDAO.getHeirsByHeirId(reqContext.getTenantId(), partyCuaa, heirId);
		if(heirEntity == null) {
			throw new HeirException(ErrEnum.HEIR_NOT_FOUND, String.format("Erede con id '%s' non trovato", heirId));
		}

		heirDAO.useTransaction(h -> {

			Long oldPkid = heirEntity.getPkid();

			heirEntity.setPkid(heirDAO.nextSequenceValHeirId());
			heirEntity.setSuccessionDate(heirUpdateReq.getSuccessionDate());
			heirEntity.setFlDelegation(Boolean.TRUE.equals(heirUpdateReq.getHasDelegation()) ? 1 : 0);

			h.expireRow(oldPkid, reqContext.getUser().getUserId());
			h.insertHeir(reqContext.getTenantId(), reqContext.getUser().getUserId(), heirEntity);
		});

		heirEventProducer.pushHeirEvent(reqContext, party.getId(), party.getCode(), HeirEventType.UPDATE_HEIR);
		return getHeirByHeirId(reqContext, partyCuaa, heirId);
	}

	@Override
	public Response delete(ReqContext reqContext, String partyCuaa, Long heirId) {
		PartyCacheData party = getPartyByCuaa(reqContext, partyCuaa);
		HeirEntity heirEntity = getHeirEntityByHeirId(reqContext, partyCuaa, heirId);
		heirDAO.expireRow(heirEntity.getPkid(), reqContext.getUser().getUserId());
		
		heirEventProducer.pushHeirEvent(reqContext, party.getId(), party.getCode(), HeirEventType.REMOVE_HEIR);
		return Response.ok().build();
	}

	private HeirRes getHeirByHeirId(ReqContext reqContext, String partyCuaa, Long heirId) {
		HeirEntity heirEntity = getHeirEntityByHeirId(reqContext, partyCuaa, heirId);
		PartyCacheData party = getPartyByCuaa(reqContext, heirEntity.getHeirCuaa());
		return HeirMapper.INSTANCE.entityToRes(heirEntity, party);

	}

	private HeirEntity getHeirEntityByHeirId(ReqContext reqContext, String partyCuaa, Long heirId) {
		HeirEntity heirEntity = heirDAO.getHeirsByHeirId(reqContext.getTenantId(), partyCuaa, heirId);
		if(heirEntity == null) {
			throw new HeirException(ErrEnum.HEIR_NOT_FOUND, String.format("Erede con id '%s' non trovato", heirId));
		}

		return heirEntity;
	}	
	
	private void checkPartyCuaaExists(ReqContext reqContext, String cuaa) {
	    if (cuaa == null) {
	        throw new HeirException(ErrEnum.INVALID_PARTY, "CUAA '" + cuaa + "' non valido");
	    }
	    PartyCacheData party = partyService.getPartyByCuaa(reqContext, cuaa);
	    if (party == null) {
	        throw new HeirException(ErrEnum.INVALID_PARTY, "CUAA '" + cuaa + "' non trovato");
	    }
	}

	private PartyCacheData getPartyByCuaa(ReqContext reqContext, String cuaa) {
		checkPartyCuaaExists(reqContext, cuaa);
	    return partyService.getPartyByCuaa(reqContext, cuaa);
	}
	
	private Boolean hasAllDocuments(ReqContext reqContext, String cuaa) {
		List<HeirDocumentEntity> docList = heirDocumentDAO.getByCuaa(reqContext.getTenantId(), cuaa);
		List<HeirRes> heirsList = getHeirsListByCuaa(reqContext, cuaa, null);
		
		if(heirsList.isEmpty()) {
			return true;
		}
		
		if(docList.isEmpty()) {
			return false;
		}
		
		String successionCode = docList.get(0).getSuccessionCode();
		
		List<SuccessionConfigEntity> succConfigs = getSuccessionConfigTree(reqContext, successionCode);
		if (succConfigs.isEmpty()) {
			return true;
		}
		
		return checkDocumentExists(succConfigs, docList);
	}

	private Boolean checkDocumentExists(List<SuccessionConfigEntity> succConfigs, List<HeirDocumentEntity> docList) {
		for (SuccessionConfigEntity config : succConfigs) {

			if(config.getChildren().isEmpty()) {
				if (config.getFlMandatory() == 1
						&& docList.stream().noneMatch(doc -> doc.getAttachmentCode().equals(config.getAttachmentType()))) {
					return false;
				}
			} else {
				Boolean hasValidChild = hasAnyValidChild(config.getChildren(), docList);
				if(config.getFlMandatory() == 1 && Boolean.FALSE.equals(hasValidChild)) {
					return false;
				}
			}
		}

		return true;
	}

	private boolean hasAnyValidChild(List<SuccessionConfigEntity> children, List<HeirDocumentEntity> docList) {
		for (SuccessionConfigEntity child : children) {
			if (!checkDocumentExists(List.of(child), docList) && child.getFlMandatory() == 1) {
				return false;
			}
		}
		return true;
	}

	private List<SuccessionConfigEntity> getSuccessionConfigTree(ReqContext reqContext, String successionCode) {
		List<SuccessionConfigEntity> flatList = successionConfigDAO.getByNamespaceAndSuccessionCode(reqContext.getTenantId(), reqContext.getLang(), 
				HEIR_MODULE, successionCode, null);
	    Map<String, SuccessionConfigEntity> nodeMap = flatList.stream()
	        .collect(Collectors.toMap(SuccessionConfigEntity::getCode, Function.identity()));

	    List<SuccessionConfigEntity> roots = new ArrayList<>();

	    for (SuccessionConfigEntity node : flatList) {
	        String parentCode = node.getParentCode();
	        if (parentCode == null) {
	            roots.add(node);
	        } else {
	            SuccessionConfigEntity parent = nodeMap.get(parentCode);
	            if (parent != null) {
	                if (parent.getChildren() == null) {
	                    parent.setChildren(new ArrayList<>());
	                }
	                parent.getChildren().add(node);
	            }
	        }
	    }

	    return roots;
	}

}

