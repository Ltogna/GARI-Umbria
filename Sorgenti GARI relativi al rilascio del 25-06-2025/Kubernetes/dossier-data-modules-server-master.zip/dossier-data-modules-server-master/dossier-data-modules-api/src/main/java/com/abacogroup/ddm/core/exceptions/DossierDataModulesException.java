package com.abacogroup.ddm.core.exceptions;

import io.swagger.v3.oas.annotations.media.Schema;
import com.abacogroup.ddm.common.exceptions.AbstractAppException;

@Deprecated
public class DossierDataModulesException extends AbstractAppException {

	public DossierDataModulesException(ErrEnum code, String message) {
		super(new ErrorBody(code.name(), message));
	}

	public enum ErrEnum {
		GENERIC
	}

	@Schema(name = "DossierDataModulesExceptionErrorBody")
	public static class ErrorBody implements ExceptionErrorBody {
		private final String code;
		private final String message;

		public ErrorBody(String code, String message) {
			this.code = code;
			this.message = message;
		}

		@Override
		@Schema(allowableValues = { "GENERIC" })
		public String getErrorCode() {
			return code;
		}

		@Override
		@Schema
		public String getMessage() {
			return message;
		}
	}
}
