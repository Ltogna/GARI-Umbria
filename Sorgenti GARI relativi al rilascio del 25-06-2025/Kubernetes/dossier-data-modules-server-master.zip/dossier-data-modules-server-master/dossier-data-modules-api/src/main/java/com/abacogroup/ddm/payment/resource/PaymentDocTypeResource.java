package com.abacogroup.ddm.payment.resource;

import java.util.List;

import com.abacogroup.ddm.api.DdmDocumentDefinition;
import com.abacogroup.ddm.api.DocTypeRelationRes;
import com.abacogroup.ddm.common.resources.ReqContext;
import com.abacogroup.ddm.common.resources.ResourceConstants;
import com.abacogroup.ddm.core.DocTypeService;
import com.abacogroup.dropwizard.auth.sso2.User;
import com.codahale.metrics.annotation.Timed;

import io.dropwizard.auth.Auth;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.annotation.security.RolesAllowed;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DefaultValue;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.HeaderParam;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.MediaType;

@Path(ResourceConstants.PAYMENT_MODULE_API_PRIV + "/doc-types")
@Tag(name = "Document types", description = "Operations on Dynamic documents definitions")
@Tag(name = "Bank Account documents")
@Timed
@RolesAllowed({ "DDM_PAYMENT_METHODS|EDITOR", "DDM_PAYMENT_METHODS|VIEWER" })
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
public class PaymentDocTypeResource {

	private final DocTypeService docTypeService;

	public PaymentDocTypeResource(DocTypeService docTypeService) {
		this.docTypeService = docTypeService;
	}

	@GET
	@Path("")
	@Operation(description = "Get the list of dynamic document types")
	@ApiResponse(responseCode = "200", description = "Get the list of dynamic document types", useReturnTypeSchema = true)
	public List<DocTypeRelationRes> search(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "tenant id") @PathParam("tenant") String tenantId,
			@Parameter(description = "bank account id (business id), used to value the docPresent field") @QueryParam("accountId") Long accountId) {

		ReqContext reqContext = new ReqContext(user, lang);
		return docTypeService.getPaymentDocTypeRelationsByAccountId(reqContext, accountId);
	}

	@GET
	@Path("/{definitionCode}")
	@Operation(summary = "document definition", description = "Get document definition by its code")
	@ApiResponse(responseCode = "200", description = "Successfully, returns a document definition", useReturnTypeSchema = true)
	public DdmDocumentDefinition getDefinition(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@PathParam("tenant") String tenantId,
			@PathParam("definitionCode") String definitionCode) {

		ReqContext reqContext = new ReqContext(user, lang);
		return docTypeService.getDefinition(reqContext, definitionCode);
	}
}
