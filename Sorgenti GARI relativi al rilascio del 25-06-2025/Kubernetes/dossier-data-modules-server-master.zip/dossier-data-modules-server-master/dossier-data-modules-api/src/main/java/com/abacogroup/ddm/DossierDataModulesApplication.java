package com.abacogroup.ddm;

import java.io.IOException;
import java.net.URI;
import java.time.Clock;
import java.util.ArrayList;
import java.util.EnumSet;
import java.util.List;
import java.util.Optional;
import java.util.TimeZone;
import java.util.concurrent.TimeoutException;

import org.eclipse.jetty.servlets.CrossOriginFilter;
import org.jdbi.v3.core.Jdbi;
import org.jdbi.v3.core.statement.Slf4JSqlLogger;

import com.abacogroup.anomalyregistry.core.cli.v1.AnomalyClient;
import com.abacogroup.bundles.Constants;
import com.abacogroup.bundles.initializer.BundleInitServiceBuilder;
import com.abacogroup.bundles.initializer.InitService;
import com.abacogroup.bundles.initializer.impl.BundleInitServiceProducer;
import com.abacogroup.bundles.listener.ListenerBuilder;
import com.abacogroup.bundles.listener.RabbitListener;
import com.abacogroup.bundles.listener.configdata.ConfigDataLogProducer;
import com.abacogroup.bundles.listener.configdata.ProcessorOrderPolicyEnum;
import com.abacogroup.bundles.listener.configdata.builder.ConfigDataConsumerBuilder;
import com.abacogroup.bundles.listener.tenant.builder.NewTenantEventConsumerBuilder;
import com.abacogroup.ddm.DossierDataModulesConfiguration.BundleConfig;
import com.abacogroup.ddm.DossierDataModulesConfiguration.RabbitmqConfig;
import com.abacogroup.ddm.aptitudes.api.services.AptitudeServices;
import com.abacogroup.ddm.aptitudes.resources.AptitudesResources;
import com.abacogroup.ddm.bundle.config.AnomalyCategoriesConfigMessageProcessor;
import com.abacogroup.ddm.bundle.config.AppConfigMessageProcessor;
import com.abacogroup.ddm.bundle.config.DynamicDocConfigMessageProcessor;
import com.abacogroup.ddm.bundle.config.SuccessionConfigMessageProcessor;
import com.abacogroup.ddm.bundle.tenant.AnomalyCategoriesTenantMessageProcessor;
import com.abacogroup.ddm.bundle.tenant.AppConfigTenantMessageProcessor;
import com.abacogroup.ddm.bundle.tenant.DynamicDocTenantMessageProcessor;
import com.abacogroup.ddm.bundle.tenant.I18nTenantMessageProcessor;
import com.abacogroup.ddm.common.core.ServiceContainer;
import com.abacogroup.ddm.core.AppConfigService;
import com.abacogroup.ddm.core.DdmAnomalyService;
import com.abacogroup.ddm.core.PartyService;
import com.abacogroup.ddm.core.cli.AnomalyDdmClientImpl;
import com.abacogroup.ddm.core.cli.DossierClient;
import com.abacogroup.ddm.core.cli.FileStoreProxyClient;
import com.abacogroup.ddm.core.cli.PartyDdmClientV1Impl;
import com.abacogroup.ddm.core.impl.AppConfigServiceImpl;
import com.abacogroup.ddm.core.impl.DdmAnomalyServiceImpl;
import com.abacogroup.ddm.core.impl.DocTypeServiceImpl;
import com.abacogroup.ddm.core.impl.PartyServiceImpl;
import com.abacogroup.ddm.db.dao.AnomalyCategoriesDAO;
import com.abacogroup.ddm.db.dao.AppConfigDAO;
import com.abacogroup.ddm.db.dao.DAOContainer;
import com.abacogroup.ddm.db.dao.DocTypeRelationDAO;
import com.abacogroup.ddm.db.dao.I18nDAO;
import com.abacogroup.ddm.db.dao.SuccessionConfigDAO;
import com.abacogroup.ddm.doigt_quotas.api.services.DoIgtQuotaService;
import com.abacogroup.ddm.doigt_quotas.resources.DoIgtQuotaResources;
import com.abacogroup.ddm.heirs_special_case.core.HeirEventProducer;
import com.abacogroup.ddm.heirs_special_case.core.impl.DocLookupsServiceImpl;
import com.abacogroup.ddm.heirs_special_case.core.impl.HeirDocumentServiceImpl;
import com.abacogroup.ddm.heirs_special_case.core.impl.HeirEventProducerImpl;
import com.abacogroup.ddm.heirs_special_case.core.impl.HeirEventRabbitPublisher;
import com.abacogroup.ddm.heirs_special_case.core.impl.HeirsServiceImpl;
import com.abacogroup.ddm.heirs_special_case.db.dao.HeirDAO;
import com.abacogroup.ddm.heirs_special_case.db.dao.HeirDocumentDAO;
import com.abacogroup.ddm.heirs_special_case.db.dao.SuccessionTypeDAO;
import com.abacogroup.ddm.heirs_special_case.resource.HeirDocTypeResource;
import com.abacogroup.ddm.heirs_special_case.resource.HeirDocumentResource;
import com.abacogroup.ddm.heirs_special_case.resource.HeirsResource;
import com.abacogroup.ddm.heirs_special_case.resource.pub.v1.DocLookupsPublicResource;
import com.abacogroup.ddm.payment.core.PaymentEventProducer;
import com.abacogroup.ddm.payment.core.impl.BankAccountAnomalyServiceImpl;
import com.abacogroup.ddm.payment.core.impl.BankAccountDocumentServiceImpl;
import com.abacogroup.ddm.payment.core.impl.BankAccountServiceImpl;
import com.abacogroup.ddm.payment.core.impl.BulkAnomalyRecalculationServiceImpl;
import com.abacogroup.ddm.payment.core.impl.PartyAnomalyServiceImpl;
import com.abacogroup.ddm.payment.core.impl.PaymentEventProducerImpl;
import com.abacogroup.ddm.payment.core.impl.PaymentEventRabbitPublisher;
import com.abacogroup.ddm.payment.db.dao.BankAccountDAO;
import com.abacogroup.ddm.payment.db.dao.BankAccountDocumentDAO;
import com.abacogroup.ddm.payment.resource.BankAccountAnomalyResource;
import com.abacogroup.ddm.payment.resource.BankAccountDocumentResource;
import com.abacogroup.ddm.payment.resource.BankAccountResource;
import com.abacogroup.ddm.payment.resource.PartyAnomalyResource;
import com.abacogroup.ddm.payment.resource.PaymentDocTypeResource;
import com.abacogroup.ddm.payment.resource.pub.v1.BankAccountAnomalyPublicResource;
import com.abacogroup.ddm.payment.resource.pub.v1.BankAccountDocumentPublicResource;
import com.abacogroup.ddm.payment.resource.pub.v1.BankAccountPublicResource;
import com.abacogroup.ddm.payment.resource.pub.v1.PartyAnomalyPublicResource;
import com.abacogroup.ddm.payment.resource.pub.v1.PaymentDocTypePublicResource;
import com.abacogroup.ddm.resources.AppConfigResource;
import com.abacogroup.ddm.resources.DevtoolsResource;
import com.abacogroup.ddm.vine.api.services.AuthorizationService;
import com.abacogroup.ddm.vine.resources.AuthorizationsResource;
import com.abacogroup.dropwizard.auth.multitenant.MultitenantFilter;
import com.abacogroup.dropwizard.auth.sso2.AuthUtils;
import com.abacogroup.dropwizard.auth.sso2.Sso2Client;
import com.abacogroup.dropwizard.auth.sso2.SsoAuthorizer;
import com.abacogroup.dynamicdocuments.auth.impl.Sso2AuthenticatorProvider;
import com.abacogroup.dynamicdocuments.files.AbacoFileStore;
import com.abacogroup.dynamicdocuments.files.FileStoreSupport;
import com.abacogroup.dynamicdocuments.http.JaxRsClient;
import com.abacogroup.dynamicdocuments.http.RestClient;
import com.abacogroup.dynamicdocuments.http.Sso2AuthenticationProvider;
import com.abacogroup.dynamicdocuments.services.DocumentService;
import com.abacogroup.dynamicdocuments.services.DocumentTypeService;
import com.abacogroup.filestore.client.FileStoreClient;
import com.abacogroup.jdbi.OraJdbiPlugin;
import com.abacogroup.jdbi.OraJdbiPlugin.OraJdbiPluginParams;
import com.abacogroup.jdbi.PgJdbiPlugin;
import com.abacogroup.jdbi.argument.AbsoluteDateArgumentFactory;
import com.abacogroup.jdbi.config.AbacoJdbiConfig;
import com.abacogroup.jdbi.mapper.AbsoluteDateMapper;
import com.abacogroup.partyregistry.core.cli.v1.PartyClientV1;
import com.abacogroup.tracing.dropwizard.AbacoApplication;
import com.abacogroup.tracing.jaxrs.client.AddRequestId;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;

import io.dropwizard.client.JerseyClientBuilder;
import io.dropwizard.configuration.EnvironmentVariableSubstitutor;
import io.dropwizard.configuration.SubstitutingSourceProvider;
import io.dropwizard.core.setup.Bootstrap;
import io.dropwizard.core.setup.Environment;
import io.dropwizard.db.DataSourceFactory;
import io.dropwizard.forms.MultiPartBundle;
import io.dropwizard.jdbi3.JdbiFactory;
import io.dropwizard.jersey.setup.JerseyEnvironment;
import io.dropwizard.migrations.MigrationsBundle;
import io.swagger.v3.jaxrs2.integration.resources.OpenApiResource;
import io.swagger.v3.oas.integration.ClasspathOpenApiConfigurationLoader;
import io.swagger.v3.oas.integration.api.OpenAPIConfiguration;
import jakarta.servlet.DispatcherType;
import jakarta.servlet.FilterRegistration.Dynamic;
import jakarta.ws.rs.client.Client;
import jakarta.ws.rs.client.WebTarget;
import lombok.extern.slf4j.Slf4j;
import oracle.jdbc.OracleConnection;

@Slf4j
public class DossierDataModulesApplication extends AbacoApplication<DossierDataModulesConfiguration> {

	public static final String PAYMENT_MODULE = "payment";
	public static final String HEIR_MODULE = "heir";

	public static void main(final String[] args) {
		try {
			new DossierDataModulesApplication().run(args);
		} catch (Exception e) {
			log.error("Error during run dossier-data-modules application: ", e);
			System.exit(1);
		}
	}

	@Override
	public String getName() {
		return "dossier-data-modules";
	}

	@Override
	public void initialize(final Bootstrap<DossierDataModulesConfiguration> bootstrap) {

		bootstrap.addBundle(new MigrationsBundle<>() {
			@Override
			public DataSourceFactory getDataSourceFactory(DossierDataModulesConfiguration configuration) {
				return configuration.getDatabase();
			}
		});

		SubstitutingSourceProvider provider = new SubstitutingSourceProvider(bootstrap.getConfigurationSourceProvider(),
				new EnvironmentVariableSubstitutor(false));
		bootstrap.setConfigurationSourceProvider(provider);

		bootstrap.addBundle(new MultiPartBundle());
	}



	@Override
	public void doRun(DossierDataModulesConfiguration configuration,  Environment environment) throws Exception {
		ObjectMapper objectMapper = environment.getObjectMapper();
		configureObjectMapper(objectMapper);

		Jdbi jdbi = jdbi(configuration, environment);
		Connection rabbitmqConnection = this.createRabbitmqConnection(configuration);

		final Sso2Client sso2Client = this.initSso2Client(configuration, environment);
		
		DAOContainer daoContainer = buildDAOContainer(jdbi);
		
		ServiceContainer serviceContainer = buildServiceContainer(configuration, environment, jdbi, objectMapper, rabbitmqConnection, sso2Client, daoContainer);

		registerResources(configuration, environment, jdbi, rabbitmqConnection, serviceContainer);

		this.initAuth(environment, sso2Client);
		this.initMultiTenant(environment);
		this.initOpenApi(environment.jersey());
		this.setupCORS(configuration, environment);

		log.info("creating CONSUMERS rabbitConsumerManager");

		initBundles(configuration, objectMapper, jdbi, rabbitmqConnection, daoContainer, serviceContainer);
		
		this.afterServicesUp();

	}

	private void initBundles(DossierDataModulesConfiguration configuration, ObjectMapper objectMapper, Jdbi jdbi,
			Connection rabbitmqConnection, DAOContainer daoContainer, ServiceContainer serviceContainer) throws Exception {
		
		RabbitListener rabbitListener = ListenerBuilder
				.newBuilder(rabbitmqConnection)
				.withConfigDataConsumer(this.register(ConfigDataConsumerBuilder.newBuilder(jdbi, rabbitmqConnection)
						.route(this.getName())
						.processor(this.register(new AppConfigMessageProcessor(daoContainer.getAppConfigDAO())))
						.processor(this.register(new DynamicDocConfigMessageProcessor(daoContainer.getDocTypeRelationDAO(), serviceContainer.getDocumentTypeService(), daoContainer.getI18nDAO())))
						.processor(this.register(new AnomalyCategoriesConfigMessageProcessor(daoContainer.getAnomalyCategoriesDAO(), objectMapper)))
						.processor(this.register(new SuccessionConfigMessageProcessor(daoContainer)))
						.configLogProducer(configDataLogProducerBean(objectMapper, rabbitmqConnection))
						.withOrderPolicy(ProcessorOrderPolicyEnum.PROCESSOR)
						.build()))

				.withNewTenantEventConsumer(this.register(NewTenantEventConsumerBuilder.newBuilder(jdbi)
						.route(this.getName())
						.processor(this.register(new AppConfigTenantMessageProcessor(daoContainer.getAppConfigDAO())))
						.processor(this.register(new I18nTenantMessageProcessor(daoContainer.getI18nDAO())))
						.processor(this.register(new DynamicDocTenantMessageProcessor(daoContainer.getDocTypeRelationDAO(), serviceContainer.getDocumentTypeService())))
						.processor(this.register(new AnomalyCategoriesTenantMessageProcessor(daoContainer.getAnomalyCategoriesDAO())))
						.build()))
				.buildListener();

		log.info("creating INITIALIZERS");
		BundleConfig bundleConfig = configuration.getBundleConfig();

		InitService bundleInitService = BundleInitServiceBuilder
				.producer(this.register(new BundleInitServiceProducer(rabbitmqConnection)))
				.configLocation(bundleConfig.getConfigLocation())
				//.baseTempDir()
				.build();

		this.startRabbitConsumerAndProducers(bundleInitService, rabbitListener);
	}

	private void registerResources(DossierDataModulesConfiguration configuration, Environment environment, Jdbi jdbi, Connection rabbitmqConnection, ServiceContainer serviceContainer) {
		List<Object> resources = new ArrayList<>();

		// ddm
		resources.add(new AppConfigResource(serviceContainer.getAppConfigService()));

		// payment
		resources.add(new BankAccountResource(serviceContainer.getBankAccountService()));
		resources.add(new PaymentDocTypeResource(serviceContainer.getDocTypeService()));
		resources.add(new BankAccountDocumentResource(serviceContainer.getBankAccountDocumentService()));
		resources.add(new BankAccountAnomalyResource(serviceContainer.getBankAccountAnomalyService()));
		resources.add(new PartyAnomalyResource(serviceContainer.getPartyAnomalyService()));
		
		// heirs
		resources.add(new HeirDocTypeResource(serviceContainer.getDocTypeService()));
		resources.add(new HeirDocumentResource(serviceContainer.getHeirDocumentService()));
		resources.add(new HeirsResource(serviceContainer.getHeirsService()));

		// payment public
		resources.add(new BankAccountPublicResource(serviceContainer.getBankAccountService()));
		resources.add(new PaymentDocTypePublicResource(serviceContainer.getDocTypeService()));
		resources.add(new BankAccountDocumentPublicResource(serviceContainer.getBankAccountDocumentService()));
		resources.add(new BankAccountAnomalyPublicResource(serviceContainer.getBankAccountAnomalyService()));
		resources.add(new PartyAnomalyPublicResource(serviceContainer.getBulkAnomalyRecalculationService(), serviceContainer.getPartyAnomalyService()));
		resources.add(new AuthorizationsResource(serviceContainer.getAuthorizationService()));
		resources.add(new AptitudesResources(serviceContainer.getAptitudeServices()));
		resources.add(new DoIgtQuotaResources(serviceContainer.getDoIgtQuotaService()));
		
		// heirs public
		resources.add(new DocLookupsPublicResource(serviceContainer.getDocLookupsService()));

		if (configuration.isDevToolsEnabled()) {
			resources.add(new DevtoolsResource(rabbitmqConnection, jdbi));
		}
		
		resources.forEach(environment.jersey()::register);
	}
	
	private ServiceContainer buildServiceContainer(DossierDataModulesConfiguration configuration, Environment environment, Jdbi jdbi, 
			ObjectMapper objectMapper, Connection rabbitmqConnection, Sso2Client sso2Client, DAOContainer daoContainer) throws Exception{
		
		WebTarget anomalyTarget = this.initAnomalyTarget(configuration, environment);
		WebTarget partyTarget = this.initPartyTarget(configuration, environment);
		WebTarget dossierTarget = this.initDossierTarget(configuration, environment);
		
		Clock appClock = Clock.systemDefaultZone();
		
		FileStoreClient fileStoreClient = new FileStoreClient(URI.create(configuration.getFileStoreConfig().getUrl()), objectMapper);
		DossierClient dossierClient = new DossierClient(sso2Client, dossierTarget);

		FileStoreSupport fileStoreSupport = new AbacoFileStore(fileStoreClient, new Sso2AuthenticatorProvider(sso2Client));

		final FileStoreProxyClient fileStoreProxyClient = this.register(new FileStoreProxyClient(this.initFileStoreTarget(configuration, environment)));
		final AnomalyClient anomalyClient = this.register(new AnomalyDdmClientImpl(anomalyTarget));
		final PartyClientV1 partyClient = this.register(new PartyDdmClientV1Impl(partyTarget));

		final DocumentTypeService documentTypeService = this.register(new DocumentTypeService(jdbi));

		Client externalServiceClient = this.initExternalServiceClient(configuration, environment);
		RestClient restClient = new JaxRsClient(externalServiceClient, new Sso2AuthenticationProvider(sso2Client));
		
		final DocumentService documentService = this.register(DocumentService.create(documentTypeService, restClient, fileStoreSupport, configuration.getDynamicDocumentsBucket()));

		final AppConfigService appConfigService = this.register(new AppConfigServiceImpl(daoContainer.getAppConfigDAO(), objectMapper));
		final DdmAnomalyService anomalyService = this.register(new DdmAnomalyServiceImpl(anomalyClient, daoContainer.getAnomalyCategoriesDAO()));

		final PaymentEventProducer paymentEventProducer = this.register(this.buildPaymentEventProducer(environment, jdbi, objectMapper, rabbitmqConnection,
				daoContainer.getBankAccountDAO(), appClock));
		final HeirEventProducer heirEventProducer = this.register(this.buildHeirEventProducer(environment, jdbi, objectMapper, rabbitmqConnection,
				appClock)); 
		final PartyService partyService = this.register(new PartyServiceImpl(partyClient));
		
		return ServiceContainer.builder()
				.documentTypeService(documentTypeService)
				.documentService(documentService)
				.appConfigService(appConfigService)
				.ddmAnomalyService(anomalyService)
				.partyService(partyService)
				.bankAccountService(this.register(new BankAccountServiceImpl(daoContainer.getBankAccountDAO(), daoContainer.getDocTypeRelationDAO(), appConfigService,
						partyService, anomalyService, paymentEventProducer, anomalyClient,appClock)))
				.bankAccountDocumentService(this.register(new BankAccountDocumentServiceImpl(
						daoContainer.getBankAccountDocumentDAO(), daoContainer.getBankAccountDAO(), daoContainer.getDocTypeRelationDAO(), documentService, 
						documentTypeService, anomalyClient, fileStoreProxyClient, configuration.getDynamicDocumentsBucket(), appClock)))
				.bankAccountAnomalyService(this.register(new BankAccountAnomalyServiceImpl(daoContainer.getBankAccountDAO(), anomalyService)))
				.docTypeService(this.register(new DocTypeServiceImpl(daoContainer, documentTypeService, configuration.getDynamicDocumentsBucket())))
				.partyAnomalyService(this.register(new PartyAnomalyServiceImpl(anomalyService)))
				.bulkAnomalyRecalculationService(this.register( new BulkAnomalyRecalculationServiceImpl(daoContainer.getBankAccountDAO(), daoContainer.getBankAccountDocumentDAO(), daoContainer.getDocTypeRelationDAO(),
								partyService, documentService, anomalyClient, appClock)))
				.authorizationService(this.register(new AuthorizationService(environment, configuration, appConfigService)))
				.aptitudeServices(this.register(new AptitudeServices(environment, configuration, appConfigService)))
				.doIgtQuotaService(this.register(new DoIgtQuotaService(environment, configuration, appConfigService)))
				.heirDocumentService(this.register(new HeirDocumentServiceImpl(daoContainer, documentService, documentTypeService, fileStoreProxyClient, partyService, 
						configuration.getDynamicDocumentsBucket(), appClock, heirEventProducer)))
				.heirsService(this.register(new HeirsServiceImpl(daoContainer, partyService, dossierClient, heirEventProducer)))
				.docLookupsService(this.register(new DocLookupsServiceImpl(daoContainer.getSuccessionTypeDAO(), daoContainer.getSuccessionConfigDAO())))
				.build();
				
	}
	
	private DAOContainer buildDAOContainer(Jdbi jdbi) {
		return DAOContainer.builder()
				.i18nDAO(jdbi.onDemand(I18nDAO.class))
				.appConfigDAO(jdbi.onDemand(AppConfigDAO.class))
				.docTypeRelationDAO(jdbi.onDemand(DocTypeRelationDAO.class))
				.anomalyCategoriesDAO(jdbi.onDemand(AnomalyCategoriesDAO.class))
				.bankAccountDAO(jdbi.onDemand(BankAccountDAO.class))
				.bankAccountDocumentDAO(jdbi.onDemand(BankAccountDocumentDAO.class))
				.heirDAO(jdbi.onDemand(HeirDAO.class))
				.heirDocumentDAO(jdbi.onDemand(HeirDocumentDAO.class))
				.successionTypeDAO(jdbi.onDemand(SuccessionTypeDAO.class))
				.successionConfigDAO(jdbi.onDemand(SuccessionConfigDAO.class))
				.build();
	}
	
	protected ConfigDataLogProducer configDataLogProducerBean(ObjectMapper objectMapper, Connection rabbitmqConnection) {
		return this.register(new ConfigDataLogProducer(objectMapper, rabbitmqConnection, Constants.DEFAULT_EXCHANGE_NAME));
	}

	protected void afterServicesUp() {
		log.debug("application started");
	}

	protected PaymentEventProducer buildPaymentEventProducer(Environment environment, Jdbi jdbi, ObjectMapper objectMapper,
			Connection rabbitmqConnection, BankAccountDAO bankAccountDAO, Clock appClock) throws IOException {

		PaymentEventRabbitPublisher publisher = new PaymentEventRabbitPublisher(rabbitmqConnection, objectMapper, bankAccountDAO);

		PaymentEventProducerImpl paymentEventProducer = new PaymentEventProducerImpl(environment, jdbi, objectMapper, publisher, appClock);

		paymentEventProducer.start();

		return paymentEventProducer;
	}
	
	protected HeirEventProducer buildHeirEventProducer(Environment environment, Jdbi jdbi, ObjectMapper objectMapper,
			Connection rabbitmqConnection, Clock appClock) throws IOException {
		
		HeirEventRabbitPublisher publisher = new HeirEventRabbitPublisher(rabbitmqConnection, objectMapper);
		
		HeirEventProducerImpl heirEventProducer = new HeirEventProducerImpl(environment, jdbi, objectMapper, publisher, appClock);
		
		heirEventProducer.start();
		
		return heirEventProducer;
	}

	private Sso2Client initSso2Client(DossierDataModulesConfiguration configuration, Environment environment) {
		final Client client = new JerseyClientBuilder(environment)
				.using(configuration.getJerseyClient())
				.build("sso2-client");
		client.register(new AddRequestId());

		WebTarget webTarget = client.target(configuration.getSso2Config().getUrl());
		Sso2Client sso2Cli = new Sso2Client(configuration.getSso2Config().getTasksAuthPhrase(), webTarget);
		return sso2Cli;
	}

	private WebTarget initAnomalyTarget(DossierDataModulesConfiguration configuration, Environment environment) {
		final Client client = new JerseyClientBuilder(environment)
				.using(configuration.getJerseyClient())
				.build("anomaly-client");
		WebTarget anomaly = client.target(configuration.getAnomaliesRegistryConfig().getUrl());
		return anomaly;
	}

	private WebTarget initPartyTarget(DossierDataModulesConfiguration configuration, Environment environment) {
		final Client client = new JerseyClientBuilder(environment)
				.using(configuration.getJerseyClient())
				.build("party-client");
		WebTarget party = client.target(configuration.getPartyConfig().getUrl());
		return party;
	}
	
	private WebTarget initDossierTarget(DossierDataModulesConfiguration configuration, Environment environment) {
		final Client client = new JerseyClientBuilder(environment)
				.using(configuration.getJerseyClient())
				.build("dossier-client");
		WebTarget dossier = client.target(configuration.getDossierConfig().getUrl());
		return dossier;
	}

	protected void startRabbitConsumerAndProducers(InitService initService, RabbitListener rabbitListener) throws Exception {
		rabbitListener.start();
		initService.start();
	}

	protected Connection createRabbitmqConnection(DossierDataModulesConfiguration configuration)
			throws IOException, TimeoutException {
		RabbitmqConfig rabbitmqConfig = configuration.getRabbitmqConfig();

		ConnectionFactory factory = new ConnectionFactory();

		if (rabbitmqConfig.getHost() != null) {
			factory.setHost(rabbitmqConfig.getHost());
		}
		if (rabbitmqConfig.getUser() != null) {
			factory.setUsername(rabbitmqConfig.getUser());
		}
		if (rabbitmqConfig.getPassword() != null) {
			factory.setPassword(rabbitmqConfig.getPassword());
		}
		if (rabbitmqConfig.getVirtualhost() != null) {
			factory.setVirtualHost(rabbitmqConfig.getVirtualhost());
		}
		if (rabbitmqConfig.getPort() != null) {
			factory.setPort(rabbitmqConfig.getPort());
		}
		factory.setAutomaticRecoveryEnabled(true);

		Connection connection = factory.newConnection();
		return connection;
	}

	protected void configureObjectMapper(ObjectMapper objectMapper) {
		objectMapper.registerModule(new JavaTimeModule());
		objectMapper
				.setTimeZone(TimeZone.getDefault())
				.disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);

	}

	protected void initAuth(Environment environment, Sso2Client sso2Cli) {
		AuthUtils.installAuthFilter(environment, sso2Cli, new SsoAuthorizer(sso2Cli));
	}

	protected Jdbi jdbi(final DossierDataModulesConfiguration configuration, final Environment environment) {
		final JdbiFactory factory = new JdbiFactory();
		final Jdbi jdbi = factory.build(environment, configuration.getDatabase(), this.getName());

		jdbi.configure(AbacoJdbiConfig.class, cfg -> cfg.setTablesPrefix("ddm"));

		String driverClassName = Optional.ofNullable(configuration.getDatabase()
						.getDriverClass())
				.orElse("");

		if (driverClassName.equalsIgnoreCase("org.postgresql.Driver")) {
			jdbi.installPlugin(new PgJdbiPlugin());
		} else {

			OraJdbiPluginParams params = new OraJdbiPluginParams(cnn -> cnn.unwrap(OracleConnection.class), true);
			jdbi.installPlugin(new OraJdbiPlugin(params));

			//jdbi.installPlugin(new OraJdbiPlugin());
		}

		jdbi.registerColumnMapper(new AbsoluteDateMapper());
		jdbi.registerArgument(new AbsoluteDateArgumentFactory());
		jdbi.setSqlLogger(new Slf4JSqlLogger());

		return jdbi;
	}

	private WebTarget initFileStoreTarget(DossierDataModulesConfiguration configuration, Environment environment) {
		final Client client = new JerseyClientBuilder(environment)
				.using(configuration.getJerseyClient())
				.build("file-store-client");
		WebTarget target = client.target(configuration.getFileStoreConfig().getUrl());
		return target;
	}

	protected <T> T register(T service) {
		return service;
	}

	protected void initOpenApi(JerseyEnvironment jersey) throws IOException {
		OpenAPIConfiguration oasConfig = new ClasspathOpenApiConfigurationLoader()
				.load("openapi-configuration.yaml");
		jersey.register(new OpenApiResource().openApiConfiguration(oasConfig));
	}

	private void setupCORS(DossierDataModulesConfiguration configuration, Environment environment) {
		if (!configuration.isCors()) {
			log.info("CORS is disabled");
			return;
		}

		log.info("CORS is enabled");

		Dynamic cors = environment.servlets().addFilter("CORS", CrossOriginFilter.class);
		cors.setInitParameter(CrossOriginFilter.ALLOWED_ORIGINS_PARAM, "*");
		cors.setInitParameter(CrossOriginFilter.ALLOWED_HEADERS_PARAM, "*");
		cors.setInitParameter(CrossOriginFilter.ALLOWED_METHODS_PARAM, "GET,PUT,POST,DELETE");

		// OPTIONS pre-flight request will be served by the filter ONLY and not
		// passed ahead
		// cors.setInitParameter(CrossOriginFilter.CHAIN_PREFLIGHT_PARAM,
		// "false");

		// Add URL mapping
		cors.addMappingForUrlPatterns(EnumSet.allOf(DispatcherType.class), false, "*");
	}

	private void initMultiTenant(Environment environment) {
		environment.jersey().register(new MultitenantFilter("tenant"));
	}

	private Client initExternalServiceClient(DossierDataModulesConfiguration configuration, Environment environment) {
		return new JerseyClientBuilder(environment)
				.using(configuration.getJerseyClient())
				.build("external-service-client")
				.register(new AddRequestId());
	}


}
