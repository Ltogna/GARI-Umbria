package com.abacogroup.ddm.heirs_special_case.core;

import com.abacogroup.ddm.common.resources.ReqContext;
import com.abacogroup.ddm.heirs_special_case.api.HeirRes;
import com.abacogroup.ddm.heirs_special_case.api.req.HeirCreateReq;
import com.abacogroup.ddm.heirs_special_case.api.req.HeirUpdateReq;
import com.abacogroup.jdbi.paging.InfiniteListResults;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import jakarta.ws.rs.core.Response;

public interface HeirsService {

	InfiniteListResults<HeirRes> getHeirsByCuaa(ReqContext reqContext, String partyCuaa, String heirCuaa, String nextKey, Integer pageSize);

	HeirRes insert(ReqContext reqContext, String partyCuaa, @NotNull @Valid HeirCreateReq heirCreateReq);

	HeirRes update(ReqContext reqContext, String partyCuaa, Long heirId, @NotNull @Valid HeirUpdateReq heirUpdateReq);

	Response delete(ReqContext reqContext, String partyCuaa, Long heirId);

}
