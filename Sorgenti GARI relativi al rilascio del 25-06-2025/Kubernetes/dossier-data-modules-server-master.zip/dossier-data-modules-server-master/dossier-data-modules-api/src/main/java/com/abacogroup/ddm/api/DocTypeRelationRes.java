package com.abacogroup.ddm.api;

import com.abacogroup.dynamicdocuments.bean.SummaryFieldDefinition;
import io.swagger.v3.oas.annotations.media.Schema;
import java.util.List;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;
import org.jdbi.v3.core.mapper.reflect.ColumnName;

@Data
@SuperBuilder(setterPrefix = "set")
@NoArgsConstructor
public class DocTypeRelationRes {

	private String definitionCode;  //docType
	private String definitionCodeI18n;

	private String namespace;

	@ColumnName("fl_required")
	private Boolean required;

	@Schema(description = "if businessId is set, it indicates whether there are documents for this docType")
	private Boolean docPresent; // flag used to indicate if there is already documents inserted of this docType

	private boolean multiple;
	private List<SummaryFieldDefinition> summaryFieldDefinitions;


}
