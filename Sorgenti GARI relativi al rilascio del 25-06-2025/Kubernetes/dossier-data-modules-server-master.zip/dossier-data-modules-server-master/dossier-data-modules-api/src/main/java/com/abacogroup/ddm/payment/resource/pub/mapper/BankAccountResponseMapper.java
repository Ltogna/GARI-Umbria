package com.abacogroup.ddm.payment.resource.pub.mapper;

import com.abacogroup.ddm.payment.api.BankAccountRes;
import com.abacogroup.ddm.payment.api.BankAccountSearchRes;
import com.abacogroup.ddm.payment.api.v1.BankAccountResponseV1;
import com.abacogroup.ddm.payment.api.v1.BankAccountSearchResponseV1;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper
public interface BankAccountResponseMapper {

	BankAccountResponseMapper INSTANCE = Mappers.getMapper(BankAccountResponseMapper.class);

	BankAccountResponseV1 toResponseV1(BankAccountRes res);

	BankAccountSearchResponseV1 toSearchResponseV1(BankAccountSearchRes res);

}
