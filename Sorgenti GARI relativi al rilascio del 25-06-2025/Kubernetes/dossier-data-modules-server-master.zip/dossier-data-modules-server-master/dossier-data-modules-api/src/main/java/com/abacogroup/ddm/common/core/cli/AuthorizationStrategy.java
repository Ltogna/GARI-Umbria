package com.abacogroup.ddm.common.core.cli;

import com.abacogroup.dropwizard.auth.sso2.User;

public interface AuthorizationStrategy {

	String getAuthorization(User user);
}
