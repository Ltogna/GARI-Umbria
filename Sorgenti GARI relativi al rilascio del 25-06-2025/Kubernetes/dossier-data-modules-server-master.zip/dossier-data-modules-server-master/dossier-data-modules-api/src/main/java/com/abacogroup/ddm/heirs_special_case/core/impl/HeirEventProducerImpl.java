package com.abacogroup.ddm.heirs_special_case.core.impl;

import java.time.Clock;
import java.time.LocalDateTime;

import org.jdbi.v3.core.Jdbi;

import com.abacogroup.ddm.common.resources.ReqContext;
import com.abacogroup.ddm.heirs_special_case.core.HeirEventProducer;
import com.abacogroup.ddm.heirs_special_case.core.dto.HeirEventType;
import com.abacogroup.ddm.heirs_special_case.core.dto.HeirQueueMessage;
import com.abacogroup.embeddedqueue.db.JdbiRepository;
import com.abacogroup.embeddedqueue.rabbitmq.RabbitMqPublisherWorkQueue;
import com.fasterxml.jackson.databind.ObjectMapper;

import io.dropwizard.core.setup.Environment;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class HeirEventProducerImpl implements HeirEventProducer {

	private final Clock appClock;
	private final RabbitMqPublisherWorkQueue<HeirQueueMessage> q;

	public HeirEventProducerImpl(Environment environment, Jdbi jdbi, ObjectMapper mapper,
			HeirEventRabbitPublisher eventPublisher, Clock appClock) {

		this.appClock = appClock;

		this.q = RabbitMqPublisherWorkQueue.builder("ddm-heir-events", new JdbiRepository(jdbi), HeirQueueMessage.class)
				.withConsumer(eventPublisher)
				.withMetricsRegistry(environment.metrics())
				.build();

		this.q.setObjectMapper(mapper);

	}

	public void start() {
		q.start();
	}

	public void stop() throws Exception {
		q.stop();
	}

	@Override
	public void pushHeirEvent(ReqContext reqContext, Long partyId, String partyCuaa, HeirEventType eventType) {
		this.pushHeirEvent(reqContext.getTenantId(), reqContext.getUsername(), reqContext.getLang(), partyId, partyCuaa, eventType);
	}

	@Override
	public void pushHeirEvent(String tenant, String username, String lang, Long partyId, String partyCuaa, HeirEventType eventType) {
		q.add(new HeirQueueMessage(tenant, username, lang, partyId, partyCuaa, LocalDateTime.now(appClock), eventType), appClock.millis());
	}

}
