package com.abacogroup.ddm.heirs_special_case.resource.pub.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import com.abacogroup.ddm.heirs_special_case.api.SuccessionTypeRes;
import com.abacogroup.ddm.heirs_special_case.api.v1.SuccessionTypeLookupResponseV1;

@Mapper
public interface SuccessionTypeResponseMapper {

	SuccessionTypeResponseMapper INSTANCE = Mappers.getMapper(SuccessionTypeResponseMapper.class);

	SuccessionTypeLookupResponseV1 toResponseV1(SuccessionTypeRes res);

}
