package com.abacogroup.ddm.resources;

import static com.abacogroup.bundles.Constants.TOPIC_PREFIX;

import com.abacogroup.bundles.Constants;
import com.abacogroup.bundles.db.dao.RegistryDAO;
import com.abacogroup.bundles.initializer.BundleInitServiceBuilder;
import com.abacogroup.bundles.initializer.impl.BundleInitServiceProducer;
import com.abacogroup.bundles.initializer.impl.FileSupport;
import com.abacogroup.bundles.initializer.impl.exceptions.BundleException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.rabbitmq.client.AMQP;
import com.rabbitmq.client.BuiltinExchangeType;
import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import io.swagger.v3.oas.annotations.Hidden;
import io.swagger.v3.oas.annotations.Operation;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.glassfish.jersey.media.multipart.FormDataContentDisposition;
import org.glassfish.jersey.media.multipart.FormDataParam;
import org.jdbi.v3.core.Jdbi;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.TimeoutException;

@Path("/devtools")
@Produces(MediaType.APPLICATION_JSON)
@Hidden
@Slf4j
public class DevtoolsResource {

	private final ObjectMapper objectMapper = new ObjectMapper();
	private final Connection rabbitmqConnection;
	private final Jdbi jdbi;

	public DevtoolsResource(Connection rabbitmqConnection, Jdbi jdbi) {
		this.rabbitmqConnection = rabbitmqConnection;
		this.jdbi = jdbi;
	}

	// public static void flushTenant(Jdbi jdbi, String newTenant) {
	// jdbi.useTransaction(handle -> {
	//
	// handle.execute("delete from doc_document_content where doc_document_id in (select id from doc_document where tenant_id = ?)", newTenant);
	// handle.execute("delete from doc_document where tenant_id = ?", newTenant);
	// handle.execute("delete from doc_type_spec where doc_type_id in (select id from doc_type where tenant_id = ?)", newTenant);
	// handle.execute("delete from doc_type where tenant_id = ?", newTenant);
	//
	// handle.execute("delete from prt_parties_documents where tenant_id = ?", newTenant);
	// handle.execute("delete from prt_doc_type where tenant_id = ?", newTenant);
	//
	// handle.execute("delete from prt_citizenship where tenant_id = ?", newTenant);
	// handle.execute("delete from prt_parties_tags where party_id in (select id from prt_parties where tenant_id = ?)", newTenant);
	//
	// handle.execute("delete from prt_party_relation_parties where party_relation_id in ("
	// + "select id from prt_party_relations where party_id in ("
	// + "select id from prt_parties where tenant_id = ? )) ", newTenant);
	//
	// handle.execute("delete from prt_party_relation_details where party_relation_id in ("
	// + "select id from prt_party_relations where party_id in ("
	// + "select id from prt_parties where tenant_id = ? )) ", newTenant);
	//
	// handle.execute("delete from prt_party_relations where party_id in (select id from prt_parties where tenant_id = ? ) ", newTenant);
	//
	// handle.execute("delete from prt_relation_roles where type_id in (select id from prt_relation_types where tenant_id = ?) ", newTenant);
	// handle.execute("delete from prt_relation_types where tenant_id = ? ", newTenant);
	//
	// handle.execute("delete from prt_parties_detail where party_id in (select id from prt_parties where tenant_id = ?)", newTenant);
	// handle.execute("delete from prt_parties where tenant_id = ?", newTenant);
	//
	// handle.execute("delete from prt_relation_roles where type_id in (select id from prt_relation_types where tenant_id = ?)", newTenant);
	// handle.execute("delete from prt_relation_types where tenant_id = ?", newTenant);
	//
	// handle.execute("delete from prt_tags where tenant_id = ?", newTenant);
	// handle.execute("delete from prt_i18n_values where tenant_id = ?", newTenant);
	//
	// handle.execute("delete from prt_addresses where id not in ("
	// + "select fk_address_residential from prt_parties_detail "
	// + "union aLL "
	// + "select fk_address_home from prt_parties_detail "
	// + "union aLL "
	// + "select fk_address_billing from prt_parties_detail "
	// + ")");
	//
	// handle.execute("delete from bnd_registry where tenant_id = ?", newTenant);
	// handle.execute("delete from bnd_tenant where tenant_id = ?", newTenant);
	// });
	// }

	@POST
	@Path("/bundle/install")
	public Object install(@NotNull @Valid BundleInstallReq bundleInstallReq) {
		String bundlePath = bundleInstallReq.getPath();
		return doInstall(bundlePath);
	}

	@POST
	@Consumes(MediaType.MULTIPART_FORM_DATA)
	@Path("/bundle/install")
	public Object install(
			@FormDataParam("bundle") final InputStream fileInputStream,
			@FormDataParam("bundle") final FormDataContentDisposition contentDispositionHeader) throws IOException {
		java.nio.file.Path workDir = createWorkDir(String.format("%s/bundles/devtools", System.getProperty("java.io.tmpdir")));

		FileSupport.unzip(fileInputStream, workDir);

		String bundlePath = workDir.toFile().listFiles()[0].getAbsolutePath();
		return doInstall(bundlePath);
	}

	@GET
	@Path("/bundle/registry")
	public Object getRegistry() {
		RegistryDAO registryDAO = jdbi.onDemand(RegistryDAO.class);

		return registryDAO.findAll();
	}

	@POST
	@Path("/tenants/{newTenant}")
	public Object newTenant(@PathParam("newTenant") String newTenant) {
		this.pushNewTenantEvent(newTenant);
		return Map.of("result", "ok");
	}

	// @DELETE
	// @Path("/tenants/{newTenant}")
	// public Object deleteTenant(@PathParam("newTenant") String newTenant) {
	//
	// flushTenant(jdbi, newTenant);
	//
	// return Map.of("result", "ok");
	// }

	// ---

	private java.nio.file.Path createWorkDir(String baseDir) {
		try {
			String wd = Optional.ofNullable(baseDir)
					.orElse(System.getProperty("java.io.tmpdir"));
			new File(wd).mkdirs();
			java.nio.file.Path workingDir = Files.createTempDirectory(java.nio.file.Path.of(wd), "bundle_");
			log.info("devtools work directory created: {}", workingDir);
			return workingDir;
		} catch (Exception ex) {
			throw new BundleException("error creating devtools work dir in " + baseDir, ex);
		}
	}

	private Map<String, String> doInstall(String bundlePath) {
		log.info("BUILDING CUSTOM INIT SERIVICE FOR {}", bundlePath);
		var initService = BundleInitServiceBuilder
				.producer(new BundleInitServiceProducer(rabbitmqConnection))
				.configLocation(bundlePath)
				.build();

		log.info("STARTING INIT SERVICE {}", bundlePath);
		initService.start();
		log.info("END INIT SERVICE {}", bundlePath);

		return Map.of("result", "ok");
	}

	public void pushNewTenantEvent(String tenant) {
		String exchangeName = Constants.DEFAULT_EXCHANGE_NAME;

		try (Channel channel = rabbitmqConnection.createChannel()) {
			channel.exchangeDeclare(exchangeName, BuiltinExchangeType.TOPIC);

			String topic = String.format("%s.%s", TOPIC_PREFIX, "newtenant");

			Map<String, Object> headers = Map.of("tenant", tenant);
			AMQP.BasicProperties properties = new AMQP.BasicProperties.Builder()
					.deliveryMode(2) // persistent
					.correlationId(UUID.randomUUID().toString())
					.contentType("application/octet-stream")
					.headers(headers)
					.build();
			channel.basicPublish(exchangeName, topic, properties, tenant.getBytes(StandardCharsets.UTF_8));
			log.info("'{}' pushed to exchange {} with topic {} and headers {}", tenant, exchangeName, topic, headers);
		} catch (TimeoutException | IOException e) {
			throw new RuntimeException(e);
		}
	}

	@Data
	protected static class BundleInstallReq {

		@NotNull
		private String path;

	}

}
