package com.abacogroup.ddm.core.exceptions;

import com.abacogroup.ddm.common.exceptions.AbstractAppException;
import io.swagger.v3.oas.annotations.media.Schema;

public class HeirDocumentException extends AbstractAppException {

	private static final long serialVersionUID = 1L;

	public HeirDocumentException(ErrEnum code, String message) {
		super(new ErrorBody(code.name(), message));
	}

	public enum ErrEnum {
		SUCCESSION_CODE_CANNOT_BE_NULL,
		SUCCESSION_CODE_NOT_VALID, 
		SUCCESSION_CODE_NOT_FOUND, 
		SUCCESSION_CODE_NOT_EDITABLE, 
		ATTACHMENT_TYPE_CANNOT_BE_NULL,
		ATTACHMENT_TYPE_NOT_FOUND,
		ATTACHMENT_TYPE_NOT_VALID, 
		ATTACHMENT_TYPE_NOT_EDITABLE,
		MAX_OCCURRENCES_EXCEEDED, 
		FILE_ID_NOT_EDITABLE, 
	}

	@Schema(name = "BankAccountExceptionErrorBody")
	public static class ErrorBody implements ExceptionErrorBody {
		private final String code;
		private final String message;

		public ErrorBody(String code, String message) {
			this.code = code;
			this.message = message;
		}

		@Override
		@Schema(allowableValues = { "INVALID_PARTY", "INVALID_IBAN", "BANK_ACCOUNT_NOT_FOUND",
				"INVALID_DAY_TO", "INVALID_DAY_FROM",
				"CANNOT_CLOSE_DEFAULT", "DUPLICATE_BANK_ACCOUNT" })
		public String getErrorCode() {
			return code;
		}

		@Override
		@Schema
		public String getMessage() {
			return message;
		}
	}
}
