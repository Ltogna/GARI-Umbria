package com.abacogroup.ddm.payment.core.dto;

public enum PaymentEventType {

	NEW_BANK_ACCOUNT("new-account"),
	UPDATE_BANK_ACCOUNT("update-account"),
	CLOSE_BANK_ACCOUNT("close-account"),
	;

	public static final String TOPIC_PREFIX = "ddm-payment";

	private final String topic;

	PaymentEventType(String topicName) {
		this.topic = topicName;
	}

	public String getTopic() {
		return String.format("%s.%s", TOPIC_PREFIX, topic);
	}
}
