package com.abacogroup.ddm.heirs_special_case.core.mapper;

import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import com.abacogroup.ddm.heirs_special_case.api.HeirRes;
import com.abacogroup.ddm.heirs_special_case.api.PartyCacheData;
import com.abacogroup.ddm.heirs_special_case.db.ntt.HeirEntity;

@Mapper
public interface HeirMapper {

	HeirMapper INSTANCE = Mappers.getMapper(HeirMapper.class);

	@InheritInverseConfiguration
	@Mapping(target = "hasDelegation", expression = "java(heirEntity.getFlDelegation() == 1)")
	@Mapping(target = "cuaa", source = "heirEntity.partyCuaa")
	HeirRes entityToRes(HeirEntity heirEntity, PartyCacheData party);

}
