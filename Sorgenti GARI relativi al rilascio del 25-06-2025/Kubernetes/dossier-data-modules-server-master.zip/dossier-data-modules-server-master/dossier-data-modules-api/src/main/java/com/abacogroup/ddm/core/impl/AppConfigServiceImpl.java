package com.abacogroup.ddm.core.impl;

import com.abacogroup.ddm.api.AppConfigRes;
import com.abacogroup.ddm.common.resources.ReqContext;
import com.abacogroup.ddm.core.AppConfigService;
import com.abacogroup.ddm.core.dto.appconfig.BaseAppConfig;
import com.abacogroup.ddm.db.dao.AppConfigDAO;
import com.abacogroup.ddm.db.ntt.AppConfigEntity;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.IOException;
import java.io.InputStream;
import java.util.*;

public class AppConfigServiceImpl implements AppConfigService {
	
	public static final String DEFAULTS_LOCATION = "appConfigDefaults.json";

	private final AppConfigDAO dao;
	
	private final ObjectMapper mapper;
	
	private Map<String, BaseAppConfig<?>> configDefaults;

	public AppConfigServiceImpl(AppConfigDAO dao, ObjectMapper mapper) {
		this.dao = dao;
		this.mapper = mapper;

		this.init();
		
	}

	private void init() {
		this.configDefaults = new HashMap<>();

		try (InputStream is = this.getClass().getClassLoader().getResourceAsStream(DEFAULTS_LOCATION)) {
			List<BaseAppConfig<?>> defaultConfigs = mapper.readValue(is, new TypeReference<>() {});

			for (BaseAppConfig<?> defaultConfig : defaultConfigs) {
				configDefaults.put(defaultConfig.getConfigurationKey(), defaultConfig);
			}

		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}

	@Override
	public <AC extends BaseAppConfig<?>> Optional<AC> getConfig(String tenant, String key, Class<AC> type) {
		return dao.findByKey(tenant, key)
				.map(entity -> BaseAppConfig.asJson(entity.getConfigurationKey(), entity.getConfiguration()))
				.map(json -> {
					try {
						return mapper.readValue(json, type);
					} catch (JsonProcessingException e) {
						throw new RuntimeException(e);
					}
				}).or(() -> Optional.ofNullable(configDefaults.get(key))
						.map(type::cast));
	}

	@Override
	public List<AppConfigRes> searchAll(ReqContext reqContext) {

		Map<String, BaseAppConfig<?>> defaults = new HashMap<>(configDefaults);

		List<AppConfigRes> configs = new ArrayList<>();

		for (AppConfigEntity entity : dao.findAll(reqContext.getTenantId())) {
			try {
				defaults.remove(entity.getConfigurationKey());
				String json = BaseAppConfig.asJson(entity.getConfigurationKey(), entity.getConfiguration());
				configs.add(mapper.readValue(json, AppConfigRes.class));
			} catch (JsonProcessingException e) {
				throw new RuntimeException(e);
			}
		}

		defaults.values().stream()
				.map(cfg -> {
					JsonNode jsonNode = mapper.valueToTree(cfg.getConfiguration());
					return new AppConfigRes(cfg.getConfigurationKey(), jsonNode);
				}).forEach(configs::add);

		return configs;
	}

	@Override
	public Optional<AppConfigRes> searchByKey(ReqContext reqContext, String key) {
		return dao.findByKey(reqContext.getTenantId(), key)
				.map(entity -> BaseAppConfig.asJson(entity.getConfigurationKey(), entity.getConfiguration()))
				.map(json -> {
					try {
						return mapper.readValue(json, AppConfigRes.class);
					} catch (JsonProcessingException e) {
						throw new RuntimeException(e);
					}
				}).or(() -> Optional.ofNullable(configDefaults.get(key))
						.map(cfg -> {
							JsonNode jsonNode = mapper.valueToTree(cfg.getConfiguration());
							return new AppConfigRes(cfg.getConfigurationKey(), jsonNode);
						}));
	}
}
