package com.abacogroup.ddm.bundle.model;

import java.util.List;
import java.util.Set;

import com.abacogroup.ddm.bundle.config.i18n.I18nAware;
import com.abacogroup.ddm.bundle.config.i18n.I18nEntry;
import com.abacogroup.ddm.bundle.config.i18n.I18nMap;

import jakarta.validation.constraints.NotEmpty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder(setterPrefix = "set")
@NoArgsConstructor
@AllArgsConstructor
public class SuccessionConfigMessage {

	private String successionCode;
	private String namespace;
	
	private List<Group> groups;
	
	@Data
	@Builder(setterPrefix = "set")
	@NoArgsConstructor
	@AllArgsConstructor
	public static class Group {
		
		@NotEmpty
		private String code;
		private String parentCode;
		private AttachmentType attachmentType;
		
		
		@Builder.Default
		private Boolean flMandatory =false;

	}
	
	@Data
	@Builder(setterPrefix = "set")
	@NoArgsConstructor
	@AllArgsConstructor
	public static class AttachmentType implements I18nAware {
		
		@NotEmpty
		private String code;
		private Integer maxOccurrences;
		private I18nMap description;		
		
		@Override
		public String getI18nCode() {
			return code;
		}
		
		
		@Override
		public Set<I18nEntry> getI18n() {
			return description.getI18n();
		}
	}
	
}
