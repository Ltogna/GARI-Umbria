package com.abacogroup.ddm.db.dao;

import com.abacogroup.ddm.api.DocTypeRelationRes;
import com.abacogroup.ddm.common.resources.ReqContext;
import com.abacogroup.ddm.db.ntt.DocTypeRelationEntity;
import com.abacogroup.jdbi.EnhancedSqlObject;
import com.abacogroup.jdbi.model.AuditEntity;
import java.util.List;
import java.util.Optional;
import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.customizer.BindBean;
import org.jdbi.v3.sqlobject.statement.GetGeneratedKeys;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;
import org.jdbi.v3.sqlobject.transaction.Transactional;

public interface DocTypeRelationDAO extends Transactional<DocTypeRelationDAO>, EnhancedSqlObject {

	String CURRENT_RECORD = " AND (§current_timestamp§ between cdtr.dt_insert and cdtr.dt_delete) ";
	String I18NDefCode = ", coalesce (§i18n(:tenantId, 'ddm_doc_type_relations', 'definition_code', cdtr.definition_code, :lang)§, cdtr.definition_code) as definition_code_i18n\n ";

	@SqlUpdate("INSERT INTO ddm_doc_type_relations"
			+ " (tenant_id, namespace, definition_code, fl_required, "
			+ "dt_insert, user_id_insert, dt_delete, user_id_delete) "
			+ "VALUES (:tenantId, :namespace, :definitionCode, :flRequired, "
			+ ":dtInsert, :userIdInsert, :dtDelete, :userIdDelete)")
	@GetGeneratedKeys("pkid")
	Long insert(@BindBean DocTypeRelationEntity entity);

	@SqlQuery("select count(*)  from ddm_doc_type_relations "
			+ " WHERE (§current_timestamp§ between dt_insert and dt_delete)"
			+ " AND tenant_id= :tenantId")
	@RegisterBeanMapper(DocTypeRelationEntity.class)
	Long count(@Bind("tenantId") String tenantId);

	@SqlQuery("select cdtr.pkid,cdtr.tenant_id,cdtr.namespace, cdtr.definition_code, cdtr.fl_required, "
			+ " cdtr.dt_insert, cdtr.user_id_insert, cdtr.dt_delete, cdtr.user_id_delete"
			+ " from ddm_doc_type_relations cdtr"
			+ " WHERE cdtr.tenant_id= :tenantId"
			+ " AND cdtr.namespace= :namespace "
			+ " AND cdtr.definition_code = :defCode"
			+ CURRENT_RECORD)
	@RegisterBeanMapper(DocTypeRelationEntity.class)
	Optional<DocTypeRelationEntity> findByNamespaceAndDefCode(@Bind("tenantId") String tenantId, @Bind("namespace") String namespace, @Bind("defCode") String defCode);

	@SqlQuery("select cdtr.pkid,cdtr.namespace, cdtr.definition_code, cdtr.fl_required "
			+ I18NDefCode
			+ " from ddm_doc_type_relations cdtr"
			+ " WHERE cdtr.tenant_id= :tenantId"
			+ " AND cdtr.namespace= :namespace "
			+ CURRENT_RECORD)
	@RegisterBeanMapper(DocTypeRelationRes.class)
	List<DocTypeRelationRes> getByNamespace(@BindBean ReqContext reqContext, @Bind("namespace") String namespace);

	@SqlQuery("select cdtr.pkid,cdtr.tenant_id,cdtr.namespace, cdtr.definition_code, cdtr.fl_required, "
			+ " cdtr.dt_insert, cdtr.user_id_insert, cdtr.dt_delete, cdtr.user_id_delete"
			+ " from ddm_doc_type_relations cdtr"
			+ " WHERE cdtr.tenant_id= :tenantId"
			+ " AND cdtr.namespace= :namespace "
			+ CURRENT_RECORD)
	@RegisterBeanMapper(DocTypeRelationEntity.class)
	List<DocTypeRelationEntity> findByNamespace(@Bind("tenantId") String tenantId, @Bind("namespace") String namespace);

	@SqlUpdate("update ddm_doc_type_relations set dt_delete =:dtDelete, user_id_delete =:userIdDelete where pkid = :pkid")
	void expireRow(@BindBean DocTypeRelationEntity entity);

	@SqlQuery("select count(*) FROM ddm_doc_type_relations where tenant_id = :tenantId ")
	Long countAll(@Bind("tenantId") String tenantId);

	@SqlUpdate("INSERT INTO ddm_doc_type_relations ("
			+ " tenant_id, namespace, definition_code, fl_required, "
			+ " dt_insert, user_id_insert, dt_delete, user_id_delete )\n"
			+ " select :newTenantId , namespace, definition_code, fl_required, "
			+ " :dtInsert, :userIdInsert, :dtDelete, :userIdDelete "
			+ " FROM ddm_doc_type_relations cdtr "
			+ " where cdtr.tenant_id = :sourceTenant "
			+ " AND (§current_timestamp§ between cdtr.dt_insert and cdtr.dt_delete) ")
	void insertNewTenant(
			@Bind("sourceTenant") String sourceTenant,
			@Bind("newTenantId") String newTenantId,
			@BindBean AuditEntity audit);

}
