package com.abacogroup.ddm.payment.core.impl;

import java.time.Clock;
import java.time.LocalDate;

import com.abacogroup.anomalyregistry.core.cli.v1.AnomalyClient;
import com.abacogroup.ddm.common.resources.ReqContext;
import com.abacogroup.ddm.core.PartyService;
import com.abacogroup.ddm.db.dao.DocTypeRelationDAO;
import com.abacogroup.ddm.payment.db.dao.BankAccountDAO;
import com.abacogroup.ddm.payment.db.dao.BankAccountDocumentDAO;
import com.abacogroup.dynamicdocuments.services.DocumentService;
import com.abacogroup.jdbi.datatype.AbsoluteDate;

public class BulkAnomalyRecalculationServiceImpl implements com.abacogroup.ddm.payment.core.BulkAnomalyRecalculationService {

	private final BankAccountDAO bankAccountDAO;
	private final BankAccountDocumentDAO bankAccountDocumentDAO;
	private final DocTypeRelationDAO docTypeRelationDAO;

	private final PartyService partyService;
	private final DocumentService documentService;

	private final AnomalyClient anomalyClient;

	private final Clock appClock;

	public BulkAnomalyRecalculationServiceImpl(BankAccountDAO bankAccountDAO,
			BankAccountDocumentDAO bankAccountDocumentDAO, DocTypeRelationDAO docTypeRelationDAO,
			PartyService partyService, DocumentService documentService,
			AnomalyClient anomalyClient, Clock appClock) {
		this.bankAccountDAO = bankAccountDAO;
		this.bankAccountDocumentDAO = bankAccountDocumentDAO;
		this.docTypeRelationDAO = docTypeRelationDAO;
		this.partyService = partyService;
		this.documentService = documentService;
		this.anomalyClient = anomalyClient;
		this.appClock = appClock;
	}

	@Override
	public void recalculate(ReqContext reqContext, Long partyId) {
		partyService.validatePartyId(reqContext, partyId);

		AnomalyHelper anomalyHelper = AnomalyHelper.newInstance(anomalyClient, reqContext, appClock)
				.recalculateNoCC(bankAccountDAO, partyId)
				.recalculateCCPred(bankAccountDAO, partyId);

		bankAccountDAO.consumeByPartyId(reqContext.getTenantId(), partyId, AbsoluteDate.of(LocalDate.now(appClock)).getValue(), ba -> {
			anomalyHelper.recalculate195(bankAccountDAO, ba)
					.recalculateAtto(docTypeRelationDAO, bankAccountDocumentDAO, documentService, ba.getId());
		});

		anomalyHelper.pushAnomalies();

	}
}
