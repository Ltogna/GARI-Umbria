package com.abacogroup.ddm.bundle;

public interface BundleConstants {

	String DOMAIN_DYNAMIC_DOCUMENTS = "dynamic_documents";

	String DOMAIN_APP_CONFIG = "app_config";
	String MY_CONFIG_BUNDLE_NS = "the_bundle_folder";

	String SYSTEM_USER = "system";

	String JSONL_COMMENT = "--";
}
