package com.abacogroup.ddm.db.dao;

import com.abacogroup.ddm.db.ntt.AnomalyCategoriesEntity;
import com.abacogroup.jdbi.EnhancedSqlObject;
import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.customizer.BindBean;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;
import org.jdbi.v3.sqlobject.transaction.Transactional;

public interface AnomalyCategoriesDAO extends Transactional<AnomalyCategoriesDAO>, EnhancedSqlObject {

	@SqlUpdate("insert into ddm_anomaly_categories (tenant_id, namespace, group_code, code, \"level\", fl_exclude) " +
			"values (:tenant_id, :namespace, :groupCode, :code, :level, :flExclude)")
	void insert(@Bind("tenant_id") String tenantId, @BindBean AnomalyCategoriesEntity category);

	@SqlUpdate("update ddm_anomaly_categories set \"level\" = :level, fl_exclude = :flExclude"
			+ " where tenant_id = :tenant_id and namespace = :namespace and group_code = :groupCode and code = :code")
	void update(@Bind("tenant_id") String tenantId, @BindBean AnomalyCategoriesEntity category);

	@SqlUpdate("delete from ddm_anomaly_categories where tenant_id = :tenant_id and namespace = :namespace and group_code = :group_code and code = :code")
	void deleteByTenantGroupCodeAndCode(@Bind("tenant_id") String tenantId, @Bind("namespace") String namespace, @Bind("group_code") String groupCode, @Bind("code") String code);

	@SqlQuery("select namespace, \n"
			+ "       group_code, \n"
			+ "       code, \n"
			+ "       \"level\", \n"
			+ "       fl_exclude "
			+ "  from ddm_anomaly_categories \n"
			+ " where tenant_id = :tenant_id \n"
			+ "   and namespace = :namespace \n"
			+ "   and group_code = :group_code \n"
			+ "   and code = :code")
	@RegisterBeanMapper(AnomalyCategoriesEntity.class)
	AnomalyCategoriesEntity findByTenantGroupCodeAndCode(@Bind("tenant_id") String tenantId, @Bind("namespace") String namespace, @Bind("group_code") String groupCode, @Bind("code") String code);

	@SqlQuery("select count(*) from ddm_anomaly_categories where tenant_id = :tenant_id")
	Long countAll(@Bind("tenant_id") String tenantId);

	@SqlUpdate("insert into ddm_anomaly_categories (tenant_id, namespace, group_code, code, \"level\", fl_exclude)  "
			+ " select :newTenantId as tenant_id, namespace, group_code, code, \"level\", fl_exclude  "
			+ " FROM ddm_anomaly_categories  "
			+ " where tenant_id = :sourceTenant ")
	void insertNewTenant(@Bind("sourceTenant") String sourceTenant, @Bind("newTenantId") String newTenantId);
}
