package com.abacogroup.ddm.core.exceptions;

import com.abacogroup.ddm.common.exceptions.AbstractAppException;
import io.swagger.v3.oas.annotations.media.Schema;

public class BankAccountException extends AbstractAppException {

	public BankAccountException(ErrEnum code, String message) {
		super(new ErrorBody(code.name(), message));
	}

	public enum ErrEnum {
		INVALID_PARTY,
		INVALID_IBAN,
		BANK_ACCOUNT_NOT_FOUND,
		INVALID_DAY_TO,
		INVALID_DAY_FROM,
		CANNOT_CLOSE_DEFAULT,
		DUPLICATE_BANK_ACCOUNT,
	}

	@Schema(name = "BankAccountExceptionErrorBody")
	public static class ErrorBody implements ExceptionErrorBody {
		private final String code;
		private final String message;

		public ErrorBody(String code, String message) {
			this.code = code;
			this.message = message;
		}

		@Override
		@Schema(allowableValues = { "INVALID_PARTY", "INVALID_IBAN", "BANK_ACCOUNT_NOT_FOUND",
				"INVALID_DAY_TO", "INVALID_DAY_FROM",
				"CANNOT_CLOSE_DEFAULT", "DUPLICATE_BANK_ACCOUNT" })
		public String getErrorCode() {
			return code;
		}

		@Override
		@Schema
		public String getMessage() {
			return message;
		}
	}
}
