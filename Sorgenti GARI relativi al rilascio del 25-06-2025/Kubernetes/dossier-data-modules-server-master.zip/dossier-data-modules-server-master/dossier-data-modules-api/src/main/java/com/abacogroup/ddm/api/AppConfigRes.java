package com.abacogroup.ddm.api;

import com.abacogroup.ddm.core.dto.appconfig.PaymentDefaultAccount;
import com.abacogroup.ddm.core.dto.appconfig.PaymentRegexValidation;
import com.fasterxml.jackson.databind.JsonNode;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder(setterPrefix = "set")
@NoArgsConstructor
@AllArgsConstructor
public class AppConfigRes {

	@Schema(allowableValues = {
			PaymentDefaultAccount.CONFIG_KEY,
			PaymentRegexValidation.CONFIG_KEY
	})
	private String configurationKey;

	@Schema(oneOf = {
			PaymentDefaultAccount.Config.class,
			PaymentRegexValidation.Config.class
	})
	private JsonNode configuration;
}
