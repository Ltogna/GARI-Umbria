package com.abacogroup.ddm.db.ntt;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder(setterPrefix = "set")
@NoArgsConstructor
public class I18nEntity {

	private String tenantId;
	private String tableName;
	private String fieldName;
	private String i18nValue;
	private String lang;
	private String i18nText;
}
