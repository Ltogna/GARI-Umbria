package com.abacogroup.ddm.db.dao;

import com.abacogroup.ddm.db.ntt.I18nEntity;
import java.util.Optional;
import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.customizer.BindBean;
import org.jdbi.v3.sqlobject.statement.SqlBatch;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;
import org.jdbi.v3.sqlobject.transaction.Transactional;

public interface I18nDAO extends Transactional<I18nDAO> {

	@SqlQuery("select tenant_id, table_name, field_name, i18n_value, lang, i18n_text "
			+ "from ddm_i18n_values "
			+ "where tenant_id= :tenantId and table_name= :tableName and field_name= :fieldName and i18n_value= :i18nValue and lang= :lang ")
	@RegisterBeanMapper(I18nEntity.class)
	Optional<I18nEntity> findOne(
			@Bind("tenantId") String tenantId,
			@Bind("tableName") String tableName,
			@Bind("fieldName") String fieldName,
			@Bind("i18nValue") String i18nValue,
			@Bind("lang") String lang
	);

	@SqlQuery("select i18n_text "
			+ "from ddm_i18n_values "
			+ "where tenant_id= :tenantId and table_name= :tableName and field_name= :fieldName and i18n_value= :i18nValue and lang= :lang ")
		//@RegisterBeanMapper(String.class)
	String searchLabel(
			@Bind("tenantId") String tenantId,
			@Bind("tableName") String tableName,
			@Bind("fieldName") String fieldName,
			@Bind("i18nValue") String i18nValue,
			@Bind("lang") String lang
	);

	@SqlUpdate("insert into ddm_i18n_values (tenant_id, table_name, field_name, i18n_value, lang, i18n_text) "
			+ " values (:tenantId, :tableName, :fieldName, :i18nValue, :lang, :i18nText) ")
	void insert(@BindBean I18nEntity entity);

	@SqlBatch("insert into ddm_i18n_values (tenant_id, table_name, field_name, i18n_value, lang, i18n_text) "
			+ " values (:tenantId, :tableName, :fieldName, :i18nValue, :lang, :i18nText) ")
	void insert(@BindBean I18nEntity... entity);

	@SqlBatch("delete from ddm_i18n_values "
			+ " where tenant_id = :tenantId "
			+ "and table_name = :tableName "
			+ "and field_name = :fieldName "
			+ "and i18n_value = :i18nValue "
			+ "and lang = :lang ")
	void deleteBatch(@BindBean I18nEntity... entity);

	@SqlQuery("select count(*) FROM ddm_i18n_values where tenant_id = :tenantId ")
	Long countAll(@Bind("tenantId") String tenantId);

	@SqlUpdate("INSERT INTO ddm_i18n_values (tenant_id, table_name, field_name, i18n_value, lang, i18n_text) " +
			" select :newTenantId as tenant_id, table_name, field_name, i18n_value, lang, i18n_text " +
			" FROM ddm_i18n_values  where tenant_id = :sourceTenant ")
	void insertNewTenant(@Bind("sourceTenant") String sourceTenant,
			@Bind("newTenantId") String newTenantId);

}
