package com.abacogroup.ddm.core.exceptions;

import com.abacogroup.ddm.common.exceptions.AbstractAppException;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
public class InvaliDocTypeRelationException extends AbstractAppException {
	public InvaliDocTypeRelationException(ErrEnum code, String message) {
		super(new ErrorBody(code.name(), message));
	}

	public enum ErrEnum {
		DOC_TYPE_RELATION_NOT_FOUND,
		DOC_TYPE_RELATION_ERROR
	}

	@Schema(name = "InvaliDDocTypeRelationExceptionErrorBody")
	public static class ErrorBody implements ExceptionErrorBody {
		private final String code;
		private final String message;

		public ErrorBody(String code, String message) {
			this.code = code;
			this.message = message;
		}

		@Override
		@Schema(allowableValues = { "DOC_TYPE_RELATION_NOT_FOUND", "DOC_TYPE_RELATION_ERROR" })
		public String getErrorCode() {
			return code;
		}

		@Override
		@Schema
		public String getMessage() {
			return message;
		}
	}

}
