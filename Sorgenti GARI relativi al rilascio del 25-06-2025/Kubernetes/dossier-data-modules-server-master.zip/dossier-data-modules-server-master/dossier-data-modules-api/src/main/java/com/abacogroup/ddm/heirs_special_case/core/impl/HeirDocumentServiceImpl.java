package com.abacogroup.ddm.heirs_special_case.core.impl;

import static com.abacogroup.ddm.DossierDataModulesApplication.HEIR_MODULE;
import static com.abacogroup.ddm.core.exceptions.InvalidDocumentException.ErrEnum.DYNAMIC_DOCUMENT_FILE_NOT_FOUND;
import static com.abacogroup.ddm.core.exceptions.InvalidDocumentException.ErrEnum.DYNAMIC_DOCUMENT_NOT_FOUND;

import java.time.Clock;
import java.time.OffsetDateTime;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.function.Consumer;
import java.util.stream.Stream;

import org.apache.commons.lang3.StringUtils;

import com.abacogroup.ddm.common.core.AuditHelper;
import com.abacogroup.ddm.common.resources.ReqContext;
import com.abacogroup.ddm.core.PartyService;
import com.abacogroup.ddm.core.cli.FileStoreProxyClient;
import com.abacogroup.ddm.core.exceptions.HeirDocumentException;
import com.abacogroup.ddm.core.exceptions.HeirException;
import com.abacogroup.ddm.core.exceptions.InvalidDocumentException;
import com.abacogroup.ddm.core.exceptions.InvalidDocumentException.ErrEnum;
import com.abacogroup.ddm.db.dao.DAOContainer;
import com.abacogroup.ddm.db.dao.DocTypeRelationDAO;
import com.abacogroup.ddm.db.dao.SuccessionConfigDAO;
import com.abacogroup.ddm.db.ntt.SuccessionConfigEntity;
import com.abacogroup.ddm.heirs_special_case.api.HeirDocumentRes;
import com.abacogroup.ddm.heirs_special_case.api.PartyCacheData;
import com.abacogroup.ddm.heirs_special_case.api.req.HeirDocumentSearchReq;
import com.abacogroup.ddm.heirs_special_case.core.HeirDocumentService;
import com.abacogroup.ddm.heirs_special_case.core.HeirEventProducer;
import com.abacogroup.ddm.heirs_special_case.core.dto.HeirEventType;
import com.abacogroup.ddm.heirs_special_case.db.dao.HeirDocumentDAO;
import com.abacogroup.ddm.heirs_special_case.db.ntt.HeirDocumentEntity;
import com.abacogroup.dynamicdocuments.bean.Document;
import com.abacogroup.dynamicdocuments.bean.DocumentDefinition;
import com.abacogroup.dynamicdocuments.bean.InsertDocument;
import com.abacogroup.dynamicdocuments.bean.SummaryFieldDefinition;
import com.abacogroup.dynamicdocuments.bean.SummaryFieldValue;
import com.abacogroup.dynamicdocuments.bean.documentdefinition.fieldset.field.FieldType;
import com.abacogroup.dynamicdocuments.exceptions.UnknownDocumentException;
import com.abacogroup.dynamicdocuments.services.DocumentService;
import com.abacogroup.dynamicdocuments.services.DocumentTypeService;
import com.abacogroup.jdbi.criteria.Criteria;
import com.abacogroup.jdbi.model.AuditEntity;
import com.abacogroup.jdbi.orderby.OrderBy;
import com.abacogroup.jdbi.paging.InfiniteListResults;

import jakarta.ws.rs.core.Response;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class HeirDocumentServiceImpl implements HeirDocumentService {
	private final HeirDocumentDAO heirDocumentDAO;
	private final DocTypeRelationDAO docTypeRelationDAO;
	private final SuccessionConfigDAO successionConfigDAO;

	private final DocumentService documentService;
	private final DocumentTypeService documentTypeService;

	private final FileStoreProxyClient fileStoreProxyClient;
	private final PartyService partyService;
	private final String dynamicDocumentsBucket;
	private final HeirEventProducer heirEventProducer;

	private final Clock appClock;
	
	private static final String SUCCESSION_TYPE_FIELD = "successionCode";
	private static final String ATTACHMENT_TYPE_FIELD = "attachmentCode";
	private static final String FILE_ID_FIELD = "file";

	public HeirDocumentServiceImpl(DAOContainer dc, DocumentService documentService, DocumentTypeService documentTypeService, 
			FileStoreProxyClient fileStoreProxyClient, PartyService partyService, String dynamicDocumentsBucket, 
			Clock appClock, HeirEventProducer heirEventProducer) {
		this.heirDocumentDAO = dc.getHeirDocumentDAO();
		this.docTypeRelationDAO = dc.getDocTypeRelationDAO();
		this.successionConfigDAO = dc.getSuccessionConfigDAO();
		
		this.documentService = documentService;
		this.documentTypeService = documentTypeService;
		this.fileStoreProxyClient = fileStoreProxyClient;
		this.partyService = partyService;
		this.dynamicDocumentsBucket = dynamicDocumentsBucket;
		this.heirEventProducer = heirEventProducer;

		this.appClock = appClock;
	}

	@Override
	public HeirDocumentRes insert(ReqContext reqContext, String partyCuaa, InsertDocument document) {

		if (StringUtils.isBlank(document.getDefCode())) {
			throw new InvalidDocumentException(InvalidDocumentException.ErrEnum.DYNAMIC_DOCUMENT_ERR, "missing defCode");
		}

		PartyCacheData party = getPartyByCuaa(reqContext, partyCuaa);
		document.setBusinessId(party.getId());

		String definitionCode = document.getDefCode();
		DocumentDefinition definition = this.documentTypeService.getDocumentDefinition(reqContext.getTenantId(), definitionCode)
				.orElseThrow(() -> new InvalidDocumentException(InvalidDocumentException.ErrEnum.DYNAMIC_DOCUMENT_ERR, "invalid defCode"));

		if (docTypeRelationDAO.findByNamespaceAndDefCode(reqContext.getTenantId(), HEIR_MODULE, definitionCode).isEmpty()) {
			throw new InvalidDocumentException(ErrEnum.DYNAMIC_DOCUMENT_ERR, "invalid defCode for heir method module");
		}

		int maxOccurs = 0;
		if (null != definition.getMetadata()) {
			maxOccurs = Optional.ofNullable(definition.getMetadata().getMaxOccurs()).orElse(0);
		}
		if (maxOccurs <= heirDocumentDAO.countByDefinitionCodeAndCuaa(reqContext.getTenantId(), definitionCode, partyCuaa)) {
			throw new InvalidDocumentException(InvalidDocumentException.ErrEnum.DYNAMIC_DOCUMENT_ERR, "over maxOccurs");
		}
		
		String successionCode = getFieldFromDocumentByName(document.getDoc(), SUCCESSION_TYPE_FIELD);
		String attachmentCode = getFieldFromDocumentByName(document.getDoc(), ATTACHMENT_TYPE_FIELD);
		checkSuccessionType(reqContext, partyCuaa, successionCode, attachmentCode, null);

		Long documentId = heirDocumentDAO.inTransaction(handle -> {
			Long id = store(reqContext, document.getDoc(), document.getDefCode(), document.getBusinessId(), document.getLabel());

			HeirDocumentEntity entity = new HeirDocumentEntity();
			entity.setTenantId(reqContext.getTenantId());
			entity.setPkid(heirDocumentDAO.nextSequenceValHeirDocId());
			entity.setPartyId(party.getId());
			entity.setCuaa(partyCuaa);
			entity.setDefinitionCode(document.getDefCode());
			entity.setDocumentId(id);
			entity.setSuccessionCode(successionCode);
			entity.setAttachmentCode(attachmentCode);
			AuditHelper.setAuditForInsert(entity, reqContext.getUsername(), heirDocumentDAO);
			this.heirDocumentDAO.insert(entity);

			return id;
		});
		
		heirEventProducer.pushHeirEvent(reqContext, party.getId(), party.getCode(), HeirEventType.ADD_HEIR_DOCUMENT);
		return getHeirDocument(reqContext, partyCuaa, documentId);
	}

	private void checkSuccessionType(ReqContext reqContext, String partyCuaa, String successionCode, String attachmentCode, Long documentId) {
		List<HeirDocumentEntity> heirDocs = heirDocumentDAO.getByCuaa(reqContext.getTenantId(), partyCuaa);
		if (heirDocs.isEmpty()) {
			return;
		}

		if (StringUtils.isBlank(successionCode)) {
			throw new HeirDocumentException(HeirDocumentException.ErrEnum.SUCCESSION_CODE_CANNOT_BE_NULL,
					String.format("Tipo successione non puo' essere null per CUAA '%s'", partyCuaa));
		}
		
		if (StringUtils.isBlank(attachmentCode)) {
			throw new HeirDocumentException(HeirDocumentException.ErrEnum.ATTACHMENT_TYPE_CANNOT_BE_NULL,
					String.format("Tipologia allegato non puo' essere null per CUAA '%s'", partyCuaa));
		}
		
		heirDocs.forEach(heirDoc -> {				
			if (heirDoc.getSuccessionCode() == null || !heirDoc.getSuccessionCode().equals(successionCode)) {
				throw new HeirDocumentException(HeirDocumentException.ErrEnum.SUCCESSION_CODE_NOT_VALID,
						String.format("Tipo successione non valido per CUAA '%s'", partyCuaa));
			}
		});
		
		List<SuccessionConfigEntity> succConfigs = successionConfigDAO.getByNamespaceAndSuccessionCode(reqContext.getTenantId(), reqContext.getLang(), HEIR_MODULE, successionCode, attachmentCode);
		if (succConfigs.stream().noneMatch(succConfig -> succConfig.getSuccessionCode().equals(successionCode) && succConfig.getAttachmentType().equals(attachmentCode))) {
			throw new HeirDocumentException(HeirDocumentException.ErrEnum.ATTACHMENT_TYPE_NOT_VALID, "Tipologia allegato non valido");
		}
		
		Long numDoc = heirDocs.stream()
				.filter(d -> documentId == null || !d.getDocumentId().equals(documentId))
				.filter(d -> d.getSuccessionCode().equals(successionCode) && d.getAttachmentCode().equals(attachmentCode))
				.count();
		
		succConfigs.stream()
		.filter(conf -> conf.getMaxOccurrences() != null)
		.map(SuccessionConfigEntity::getMaxOccurrences).max(Comparable::compareTo)
		.ifPresent(maxOcc -> {
			if (maxOcc <= numDoc) {
				throw new HeirDocumentException(HeirDocumentException.ErrEnum.MAX_OCCURRENCES_EXCEEDED,
						String.format("Numero massimo di documenti ('%s') superato per CUAA '%s'", maxOcc, partyCuaa));
			}
		});
	}

	@Override
	public void expire(ReqContext reqContext, String partyCuaa, Long documentId) {
		PartyCacheData party = getPartyByCuaa(reqContext, partyCuaa);
		HeirDocumentEntity entity = heirDocumentDAO.findByDocumentIdAndCuaa(reqContext.getTenantId(), documentId, party.getCode())
				.orElseThrow(() -> new InvalidDocumentException(DYNAMIC_DOCUMENT_NOT_FOUND, "Documento non trovato"));

		Document doc = Optional.of(documentService.getDocumentFromId(documentId))
				.orElseThrow(() -> new InvalidDocumentException(DYNAMIC_DOCUMENT_NOT_FOUND, "Documento non trovato"));

		doc.setValidTo(OffsetDateTime.now(appClock));
		heirDocumentDAO.useTransaction(handle -> {
			documentService.updateDocument(documentId, doc, reqContext.getUser().getUserId());
			Consumer<HeirDocumentEntity> expire = handle::expireRow;
			AuditHelper.expire(entity, reqContext.getUsername(), expire, handle.getCurrentTimestamp());
		});
		
		heirEventProducer.pushHeirEvent(reqContext, party.getId(), party.getCode(), HeirEventType.REMOVE_HEIR_DOCUMENT);
	}

	@Override
	public HeirDocumentRes update(ReqContext reqContext, String partyCuaa, Long documentId, Document updateReq) {
		PartyCacheData party = getPartyByCuaa(reqContext, partyCuaa);
		HeirDocumentEntity entity = heirDocumentDAO.findByDocumentIdAndCuaa(reqContext.getTenantId(), documentId, party.getCode())
				.orElseThrow(() -> new InvalidDocumentException(DYNAMIC_DOCUMENT_NOT_FOUND, "Documento non trovato"));

		Document doc = Optional.of(documentService.getDocumentFromId(documentId))
				.orElseThrow(() -> new InvalidDocumentException(DYNAMIC_DOCUMENT_NOT_FOUND, "Documento non trovato"));

		checkDocumentFeilds(entity, doc, updateReq);
		
		doc.setValidFrom(Optional.ofNullable(updateReq.getValidFrom()).orElse(doc.getValidFrom()));
		doc.setValidTo(Optional.ofNullable(updateReq.getValidTo()).orElse(doc.getValidTo()));
		doc.setFields(Optional.ofNullable(updateReq.getFields()).orElse(doc.getFields()));
		entity.setPartyId(party.getId());
		entity.setCuaa(partyCuaa);
		entity.setTenantId(reqContext.getTenantId());
		entity.setDocumentId(documentId);
		entity.setSuccessionCode(getFieldFromDocumentByName(updateReq, SUCCESSION_TYPE_FIELD));
		entity.setAttachmentCode(getFieldFromDocumentByName(updateReq, ATTACHMENT_TYPE_FIELD));
		
		checkSuccessionType(reqContext, partyCuaa, entity.getSuccessionCode(), entity.getAttachmentCode(), documentId);

		heirDocumentDAO.useTransaction(handle -> {
			documentService.updateDocument(documentId, doc, reqContext.getUser().getUserId());
			Consumer<HeirDocumentEntity> expire = handle::expireRow;
			AuditHelper.expire(entity, reqContext.getUsername(), expire, handle.getCurrentTimestamp());
			
			AuditHelper.setAuditForInsert(entity, reqContext.getUsername(), heirDocumentDAO);
			entity.setPkid(handle.nextSequenceValHeirDocId());
			handle.insert(entity);
		});

		// TODO verify elapsed

		heirEventProducer.pushHeirEvent(reqContext, party.getId(), party.getCode(), HeirEventType.UPDATE_HEIR_DOCUMENT);
		return getHeirDocument(reqContext, partyCuaa, documentId);
	}

	private void checkDocumentFeilds(HeirDocumentEntity entity, Document doc, Document updateReq) {
		if(!entity.getSuccessionCode().equals(getFieldFromDocumentByName(updateReq, SUCCESSION_TYPE_FIELD))) {
			throw new HeirDocumentException(HeirDocumentException.ErrEnum.SUCCESSION_CODE_NOT_EDITABLE,
					String.format("Tipo successione non si puo' modificare"));
		}

		if(!entity.getAttachmentCode().equals(getFieldFromDocumentByName(updateReq, ATTACHMENT_TYPE_FIELD))) {
			throw new HeirDocumentException(HeirDocumentException.ErrEnum.ATTACHMENT_TYPE_NOT_EDITABLE,
					String.format("Tipologia allegato non si puo' modificare"));
		}
		
		List<String> docFileIds = getFileIdsFromDocument(doc);
		List<String> updateFileIds = getFileIdsFromDocument(updateReq);
		
		if(docFileIds.size() != updateFileIds.size()
			    || !docFileIds.containsAll(updateFileIds)
			    || !updateFileIds.containsAll(docFileIds)) {
			throw new HeirDocumentException(HeirDocumentException.ErrEnum.FILE_ID_NOT_EDITABLE,
					String.format("File non si puo' modificare"));
		}
		
	}

	@Override
	public HeirDocumentRes getHeirDocument(ReqContext reqContext, String partyCuaa, Long documentId) {
		PartyCacheData party = getPartyByCuaa(reqContext, partyCuaa);

		return heirDocumentDAO.getByDocumentIdAndCuaa(documentId, party.getCode(), reqContext)
				.map(heirDoc -> addData(heirDoc, dynamicDocumentsBucket))
				.orElseThrow(() -> new InvalidDocumentException(DYNAMIC_DOCUMENT_NOT_FOUND, "Documento non trovato"));
	}

	@Override
	public InfiniteListResults<HeirDocumentRes> search(ReqContext reqContext, String partyCuaa, 
			HeirDocumentSearchReq searchReq, String nextKey) {
		PartyCacheData party = getPartyByCuaa(reqContext, partyCuaa);

		Criteria criteria = searchReq.getCriteria(reqContext);
		OrderBy orderBy = searchReq.getSort();

		return heirDocumentDAO.infinite(() -> heirDocumentDAO.search(party.getCode(), criteria, orderBy, reqContext), nextKey, searchReq.getPageSize())
				.map(baDoc -> addSummaryFields(reqContext, baDoc, dynamicDocumentsBucket));
	}

	@Override
	public Response getDocumentFileContent(ReqContext reqContext, String partyCuaa, Long documentId, String fileId) {
		validateCanReadFile(reqContext, partyCuaa, documentId, fileId);

		return fileStoreProxyClient.getFileContent(reqContext.getLang(), reqContext.getUser(), dynamicDocumentsBucket, fileId);
	}

	@Override
	public Response getDocumentFileMetadata(ReqContext reqContext, String partyCuaa, Long documentId, String fileId) {
		this.validateCanReadFile(reqContext, partyCuaa, documentId, fileId);

		return fileStoreProxyClient.getFileMetadata(reqContext.getLang(), reqContext.getUser(), dynamicDocumentsBucket, fileId);
	}
	
	private PartyCacheData getPartyByCuaa(ReqContext reqContext, String partyCuaa) {
		if (partyCuaa == null) {
			throw new HeirException(HeirException.ErrEnum.INVALID_PARTY, "CUAA '" + partyCuaa + "' non valido");
		}
		
		PartyCacheData party = partyService.getPartyByCuaa(reqContext, partyCuaa);
		if (party == null) {
			throw new HeirException(HeirException.ErrEnum.INVALID_PARTY, "CUAA '" + partyCuaa + "' non trovato");
		}
		
		return party;
	}
	
	private HeirDocumentRes addSummaryFields(ReqContext reqContext, HeirDocumentRes heirDocumentRes, String dynamicDocumentsBucket) {
		Document document = documentService.getDocumentFromId(heirDocumentRes.getDocumentId());
		Optional<DocumentDefinition> def = documentTypeService
				.getDocumentDefinition(reqContext.getTenantId(), heirDocumentRes.getDefinitionCode());

		if (def.isPresent()) {
			List<SummaryFieldDefinition> summaryFields = documentTypeService.getSummaryFields(def.get(), reqContext.getLang());
			List<SummaryFieldValue> listValues = documentService.getSummaryValues(def.get(), document, reqContext.getLang());

			LinkedHashMap<String, Object> summaryFieldsData = new LinkedHashMap<>();
			listValues.forEach(
					summaryFieldValue -> summaryFieldsData.put(summaryFieldValue.getCode(), summaryFieldValue.getValue())
			);

			heirDocumentRes.setSummaryFieldDefinitions(summaryFields);
			heirDocumentRes.setData(summaryFieldsData);
			heirDocumentRes.setBucketName(dynamicDocumentsBucket);
		}
		return heirDocumentRes;
	}

	private HeirDocumentRes addData(HeirDocumentRes heirDocumentRes, String dynamicDocumentsBucket) {
		Document document = Optional.ofNullable(documentService.getDocumentFromId(heirDocumentRes.getDocumentId()))
				.orElseThrow(() -> new InvalidDocumentException(ErrEnum.DYNAMIC_DOCUMENT_NOT_FOUND, String.format("Documento con id %s non trovato", heirDocumentRes.getDocumentId())));
		heirDocumentRes.setData(new LinkedHashMap<>(document.getFields()));
		heirDocumentRes.setBucketName(dynamicDocumentsBucket);
		return heirDocumentRes;
	}
	
	private void validateCanReadFile(ReqContext reqContext, String partyCuaa, Long documentId, String fileId) {
		PartyCacheData party = getPartyByCuaa(reqContext, partyCuaa);
		
		HeirDocumentEntity groupDocumentEntity = heirDocumentDAO.findByDocumentIdAndCuaa(reqContext.getTenantId(), documentId, party.getCode())
				.orElseThrow(() -> new InvalidDocumentException(DYNAMIC_DOCUMENT_NOT_FOUND,
						String.format("Documento con id %s non trovato", documentId)));

		Document document;
		try {
			document = documentService.getDocumentFromId(groupDocumentEntity.getDocumentId());
		} catch (UnknownDocumentException ude) {
			throw new InvalidDocumentException(DYNAMIC_DOCUMENT_NOT_FOUND, ude.getMessage());
		}
		DocumentDefinition definition = documentTypeService.getDocumentDefinition(reqContext.getTenantId(), groupDocumentEntity.getDefinitionCode())
				.orElseThrow(() -> new InvalidDocumentException(InvalidDocumentException.ErrEnum.DYNAMIC_DOCUMENT_ERR,
						String.format("error loading definition for %s", groupDocumentEntity.getDefinitionCode())));

		boolean containsFileId = definition.getFieldSets().stream()
				.flatMap(fieldSet -> fieldSet.getFields().stream())
				.filter(field -> FieldType.FILE.equals(field.getType()))
				.map(field -> document.getFields().get(field.getCode()))
				.filter(Objects::nonNull)
				.flatMap(fieldValue -> fieldValue instanceof Collection ? ((Collection<?>) fieldValue).stream() : Stream.of(fieldValue))
				.anyMatch(fileId::equals);

		if (!containsFileId) {
			throw new InvalidDocumentException(DYNAMIC_DOCUMENT_FILE_NOT_FOUND,
					String.format("documento con id %s per CUAA %s non contiene file con id %s", 
							documentId, partyCuaa, fileId));
		}
	}
	
	private Long store(ReqContext reqContext, Document document, String definitionCode, Long partyId, String label) {

		document.setValidFrom(Optional.ofNullable(document.getValidFrom()).orElse(OffsetDateTime.now(appClock)));
		document.setValidTo(Optional.ofNullable(document.getValidTo())
				.orElse(AuditEntity.dateActive.atOffset(appClock.getZone().getRules().getOffset(appClock.instant()))));

		return documentService.insertDocument(reqContext.getTenantId(), definitionCode, document, reqContext.getUser().getUserId(), partyId, label);
	}
	
	private String getFieldFromDocumentByName(Document document, String fiedlName) {
        return document.getFields().entrySet().stream()
                .filter(entry -> entry.getKey().equals(fiedlName))
                .map(entry -> entry.getValue().toString())
                .findFirst()
                .orElse(null);
	}
	
	private List<String> getFileIdsFromDocument(Document document) {
		Object fileField = document.getFields().get(FILE_ID_FIELD);
		List<String> fileIds = null;
		if (fileField instanceof List) {
		    fileIds = (List<String>) fileField;
		}
		
		return fileIds;
	}

}

