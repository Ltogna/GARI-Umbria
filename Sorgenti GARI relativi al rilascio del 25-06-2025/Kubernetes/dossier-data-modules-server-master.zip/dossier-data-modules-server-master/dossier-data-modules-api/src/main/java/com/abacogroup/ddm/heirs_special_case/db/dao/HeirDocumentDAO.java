package com.abacogroup.ddm.heirs_special_case.db.dao;

import java.util.List;
import java.util.Optional;

import org.jdbi.v3.core.result.ResultIterator;
import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.customizer.BindBean;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;
import org.jdbi.v3.sqlobject.transaction.Transactional;

import com.abacogroup.ddm.common.resources.ReqContext;
import com.abacogroup.ddm.heirs_special_case.api.HeirDocumentRes;
import com.abacogroup.ddm.heirs_special_case.db.ntt.HeirDocumentEntity;
import com.abacogroup.jdbi.EnhancedSqlObject;
import com.abacogroup.jdbi.criteria.BindCriteria;
import com.abacogroup.jdbi.criteria.Criteria;
import com.abacogroup.jdbi.orderby.DefineOrder;
import com.abacogroup.jdbi.orderby.OrderBy;

public interface HeirDocumentDAO extends Transactional<HeirDocumentDAO>, EnhancedSqlObject {
	
	@SqlQuery("§select_nextval(ddm_heir_documents_seq)§")
	Long nextSequenceValHeirDocId();

	@SqlQuery("select hd.pkid, \n"
			+ "   hd.party_id, \n"
			+ "   hd.cuaa, \n"
			+ "   hd.definition_code, \n"
			+ "   hd.document_id, \n"
			+ "   hd.succession_code, \n"
			+ "   hd.attachment_code, \n"
			+ "   hd.dt_insert, \n"
			+ "   hd.user_id_insert, \n"
			+ "   hd.dt_delete, \n"
			+ "   hd.user_id_delete \n"
			+ " FROM ddm_heir_documents hd "
			+ " where hd.cuaa = :cuaa "
			+ "   and hd.tenant_id = :tenantId "
			+ "   and <criteria> "
			+ "   and §current_timestamp§ between hd.dt_insert and hd.dt_delete "
			+ " ORDER BY <orderBy> ")
	@RegisterBeanMapper(HeirDocumentRes.class)
	ResultIterator<HeirDocumentRes> search(
			@Bind("cuaa") String cuaa,
			@BindCriteria Criteria criteria,
			@DefineOrder OrderBy orderBy,
			@BindBean ReqContext ctx);

	@SqlQuery("select count(*) "
			+ " FROM ddm_heir_documents hd "
			+ " where hd.definition_code = :definitionCode "
			+ "   and hd.cuaa = :cuaa "
			+ "   and hd.tenant_id = :tenantId "
			+ "   and §current_timestamp§ between hd.dt_insert and hd.dt_delete ")
	Long countByDefinitionCodeAndCuaa(
			@Bind("tenantId") String tenantId,
			@Bind("definitionCode") String definitionCode,
			@Bind("cuaa") String cuaa);

	@SqlQuery("select hd.pkid, \n"
			+ "   hd.party_id, \n"
			+ "   hd.cuaa, \n"
			+ "   hd.definition_code, \n"
			+ "   hd.document_id, \n"
			+ "   hd.succession_code, \n"
			+ "   hd.attachment_code, \n"
			+ "   hd.dt_insert, \n"
			+ "   hd.user_id_insert, \n"
			+ "   hd.dt_delete, \n"
			+ "   hd.user_id_delete \n"
			+ " FROM ddm_heir_documents hd "
			+ " where hd.document_id = :documentId "
			+ "   and hd.cuaa = :cuaa "
			+ "   and hd.tenant_id = :tenantId "
			+ "   and §current_timestamp§ between hd.dt_insert and hd.dt_delete ")
	@RegisterBeanMapper(HeirDocumentRes.class)
	Optional<HeirDocumentRes> getByDocumentIdAndCuaa(
			@Bind("documentId") Long documentId,
			@Bind("cuaa") String cuaa,
			@BindBean ReqContext ctx);

	@SqlQuery("select hd.pkid, \n"
			+ "   hd.cuaa, \n"
			+ "   hd.definition_code, \n"
			+ "   hd.document_id, \n"
			+ "   hd.succession_code, \n"
			+ "   hd.attachment_code, \n"
			+ "   hd.dt_insert, \n"
			+ "   hd.user_id_insert, \n"
			+ "   hd.dt_delete, \n"
			+ "   hd.user_id_delete \n"
			+ " FROM ddm_heir_documents hd "
			+ " where hd.document_id = :documentId "
			+ "   and hd.cuaa = :cuaa "
			+ "   and hd.tenant_id = :tenantId "
			+ "   and §current_timestamp§ between hd.dt_insert and hd.dt_delete ")
	@RegisterBeanMapper(HeirDocumentEntity.class)
	Optional<HeirDocumentEntity> findByDocumentIdAndCuaa(
			@Bind("tenantId") String tenantId,
			@Bind("documentId") Long documentId,
			@Bind("cuaa") String cuaa);
	
	@SqlQuery("select hd.pkid, \n"
			+ "   hd.cuaa, \n"
			+ "   hd.definition_code, \n"
			+ "   hd.document_id, \n"
			+ "   hd.succession_code, \n"
			+ "   hd.attachment_code, \n"
			+ "   hd.dt_insert, \n"
			+ "   hd.user_id_insert, \n"
			+ "   hd.dt_delete, \n"
			+ "   hd.user_id_delete \n"
			+ " FROM ddm_heir_documents hd "
			+ "   inner join ddm_heirs h on h.cuaa = hd.cuaa "
			+ " where hd.cuaa = :cuaa "
			+ "   and hd.tenant_id = :tenantId "
			+ "   and §current_timestamp§ between hd.dt_insert and hd.dt_delete ")
	@RegisterBeanMapper(HeirDocumentEntity.class)
	List<HeirDocumentEntity> getByCuaa(
			@Bind("tenantId") String tenantId,
			@Bind("cuaa") String cuaa);

	@SqlUpdate(
			"INSERT INTO ddm_heir_documents (pkid, tenant_id, party_id, cuaa, definition_code, document_id, succession_code, attachment_code, "
			+ " dt_insert, user_id_insert, dt_delete, user_id_delete) "
			+ "VALUES (:pkid, :tenantId, :partyId, :cuaa, :definitionCode, :documentId, :successionCode, :attachmentCode, "
			+ " :dtInsert, :userIdInsert, :dtDelete, :userIdDelete)")
	void insert(@BindBean HeirDocumentEntity entity);

	@SqlUpdate("update ddm_heir_documents set dt_delete =:dtDelete, user_id_delete=:userIdDelete where pkid = :pkid")
	void expireRow(@BindBean HeirDocumentEntity entity);
}
