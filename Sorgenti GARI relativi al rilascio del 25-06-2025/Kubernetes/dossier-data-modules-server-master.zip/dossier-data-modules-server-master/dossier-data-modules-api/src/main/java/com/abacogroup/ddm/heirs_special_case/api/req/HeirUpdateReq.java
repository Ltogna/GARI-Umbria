package com.abacogroup.ddm.heirs_special_case.api.req;

import com.abacogroup.jdbi.datatype.AbsoluteDate;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder(setterPrefix = "set")
@NoArgsConstructor
@AllArgsConstructor
public class HeirUpdateReq {
	
	@Schema(description = "The Succession Date of the heir")
	private AbsoluteDate successionDate;
	
	@Schema(description = "if true has the right to delegate")
	private Boolean hasDelegation;

}
