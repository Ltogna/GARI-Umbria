package com.abacogroup.ddm.payment.core.impl;

import com.abacogroup.ddm.common.resources.ReqContext;
import com.abacogroup.ddm.payment.core.dto.PaymentEventType;
import com.abacogroup.ddm.payment.core.dto.PaymentQueueMessage;
import com.abacogroup.embeddedqueue.db.JdbiRepository;
import com.abacogroup.embeddedqueue.rabbitmq.RabbitMqPublisherWorkQueue;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.dropwizard.core.setup.Environment;
import java.time.Clock;
import java.time.LocalDateTime;
import lombok.extern.slf4j.Slf4j;
import org.jdbi.v3.core.Jdbi;

@Slf4j
public class PaymentEventProducerImpl implements com.abacogroup.ddm.payment.core.PaymentEventProducer {

	private final Clock appClock;
	private final RabbitMqPublisherWorkQueue<PaymentQueueMessage> q;

	public PaymentEventProducerImpl(Environment environment, Jdbi jdbi, ObjectMapper mapper,
			PaymentEventRabbitPublisher eventPublisher, Clock appClock) {

		this.appClock = appClock;

		this.q = RabbitMqPublisherWorkQueue.builder("ddm-payment-events", new JdbiRepository(jdbi), PaymentQueueMessage.class)
				.withConsumer(eventPublisher)
				.withMetricsRegistry(environment.metrics())
				.build();

		this.q.setObjectMapper(mapper);

	}

	public void start() {
		q.start();
	}

	public void stop() throws Exception {
		q.stop();
	}

	@Override
	public void pushBankAccountEvent(ReqContext reqContext, Long partyId, Long accountId, PaymentEventType eventType) {
		this.pushBankAccountEvent(reqContext.getTenantId(), reqContext.getUsername(), reqContext.getLang(), partyId, accountId, eventType);
	}

	@Override
	public void pushBankAccountEvent(String tenant, String username, String lang, Long partyId, Long accountId, PaymentEventType eventType) {
		q.add(new PaymentQueueMessage(tenant, username, lang, partyId, accountId, LocalDateTime.now(appClock), eventType), appClock.millis());
	}

}
