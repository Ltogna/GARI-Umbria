package com.abacogroup.ddm.heirs_special_case.db.ntt;

import com.abacogroup.jdbi.datatype.AbsoluteDate;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder(setterPrefix = "set")
@NoArgsConstructor
@AllArgsConstructor
public class HeirEntity {

	private Long pkid;
	private Long heirId;
	private String heirCuaa;

	private String partyCuaa;
	
	private Integer flDelegation;
	private AbsoluteDate successionDate;
	
}
