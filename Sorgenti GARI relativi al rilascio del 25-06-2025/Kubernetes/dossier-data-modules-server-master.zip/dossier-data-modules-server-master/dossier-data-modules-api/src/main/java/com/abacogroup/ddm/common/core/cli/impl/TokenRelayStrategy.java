package com.abacogroup.ddm.common.core.cli.impl;

import com.abacogroup.ddm.common.core.cli.AuthorizationStrategy;
import com.abacogroup.dropwizard.auth.sso2.User;

import org.apache.commons.lang3.StringUtils;

public class TokenRelayStrategy implements AuthorizationStrategy {

	private static final String DEFAULT_PREFIX = "JWT";

	private final String prefix;

	public TokenRelayStrategy(String prefix) {
		this.prefix = prefix;
	}

	public TokenRelayStrategy() {
		this(DEFAULT_PREFIX);
	}

	@Override
	public String getAuthorization(User user) {
		if (StringUtils.isNotBlank(user.getAuthToken())) {
			return String.format("%s %s", prefix, user.getAuthToken());
		} else {
			return null;
		}
	}

}
