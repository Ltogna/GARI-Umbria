package com.abacogroup.ddm.bundle;

public enum FileOperationEnum {
	DELETE,
	DEFAULT,
}
