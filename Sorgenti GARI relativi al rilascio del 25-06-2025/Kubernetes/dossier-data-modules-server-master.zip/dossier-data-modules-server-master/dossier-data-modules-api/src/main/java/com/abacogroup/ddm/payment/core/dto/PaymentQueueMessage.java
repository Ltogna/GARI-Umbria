package com.abacogroup.ddm.payment.core.dto;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.time.LocalDateTime;
import lombok.Data;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder(setterPrefix = "set")
public class PaymentQueueMessage {

	private final String tenant;
	private final String username;
	private final String lang;
	private final Long partyId;
	private final Long accountId;
	private final LocalDateTime date;

	private final PaymentEventType eventType;

	@JsonCreator
	public PaymentQueueMessage(@JsonProperty("tenant") String tenant,
			@JsonProperty("username") String username,
			@JsonProperty("lang") String lang,
			@JsonProperty("partyId") Long partyId,
			@JsonProperty("accountId") Long accountId,
			@JsonProperty("date") LocalDateTime date,
			@JsonProperty("eventType") PaymentEventType eventType) {
		this.tenant = tenant;
		this.username = username;
		this.lang = lang;
		this.partyId = partyId;
		this.accountId = accountId;
		this.date = date;
		this.eventType = eventType;
	}

	public String getRoutingKey() {
		return eventType.getTopic();
	}

}
