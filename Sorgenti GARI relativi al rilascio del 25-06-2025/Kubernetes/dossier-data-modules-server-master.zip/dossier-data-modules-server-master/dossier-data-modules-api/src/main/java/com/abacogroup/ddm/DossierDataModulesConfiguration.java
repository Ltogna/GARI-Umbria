package com.abacogroup.ddm;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.dropwizard.client.JerseyClientConfiguration;
import io.dropwizard.core.Configuration;
import io.dropwizard.db.DataSourceFactory;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Data
public class DossierDataModulesConfiguration extends Configuration {

	private boolean cors = true;

	@Valid
	@NotNull
	private DataSourceFactory database;

	private RabbitmqConfig rabbitmqConfig;

	@Valid
	private BundleConfig bundleConfig;

	@Valid
	private Sso2Config sso2Config;

	@Valid
	private FileStoreConfig fileStoreConfig;

	@Valid
	private AnomaliesRegistryConfig anomaliesRegistryConfig;

	@Valid
	private PartyConfig partyConfig;
	
	@Valid
	private DossierConfig dossierConfig;

	private String dynamicDocumentsBucket; // TODO class with modules buckets

	@JsonProperty("devtools-enabled")
	private boolean devToolsEnabled = false;



	@Valid
	@NotNull
	@Getter
	@Setter
	private JerseyClientConfiguration jerseyClient = new JerseyClientConfiguration();

	@Data
	public static class RabbitmqConfig {

		private String host;
		private String user;
		private String password;
		private String virtualhost;
		private Integer port;
	}

	@Data
	public static class Sso2Config {
		private String url;
		private String tasksAuthPhrase;
	}

	@Data
	public static class BundleConfig {

		@NotBlank
		private String configLocation;

		private String initBaseTempDir;

	}


	@Data
	public static class FileStoreConfig {
		private String url;
	}

	@Data
	public static class AnomaliesRegistryConfig {
		private String url;
	}

	@Data
	public static class PartyConfig {
		private String url;
	}
	
	@Data
	public static class DossierConfig {
		private String url;
	}

}
