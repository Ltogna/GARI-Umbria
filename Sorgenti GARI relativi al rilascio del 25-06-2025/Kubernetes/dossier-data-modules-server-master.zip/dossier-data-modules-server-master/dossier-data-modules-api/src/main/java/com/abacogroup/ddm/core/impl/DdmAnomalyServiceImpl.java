package com.abacogroup.ddm.core.impl;

import com.abacogroup.anomalyregistry.api.v1.AnomalySearchResponse;
import com.abacogroup.anomalyregistry.api.v1.req.AnomalySearchRequest;
import com.abacogroup.anomalyregistry.core.cli.v1.AnomalyClient;
import com.abacogroup.ddm.api.AnomalyLevelEnum;
import com.abacogroup.ddm.common.resources.ReqContext;
import com.abacogroup.ddm.core.dto.AnomalyType;
import com.abacogroup.ddm.db.dao.AnomalyCategoriesDAO;
import com.abacogroup.ddm.db.ntt.AnomalyCategoriesEntity;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.function.Function;
import java.util.stream.Collectors;

public class DdmAnomalyServiceImpl implements com.abacogroup.ddm.core.DdmAnomalyService {

	private static final AnomalyCategoriesEntity DEFAULT_ANOMALY_CATEGORY = AnomalyCategoriesEntity.builder()
			.setLevel(AnomalyLevelEnum.INFO).setFlExclude(0).build();

	private final AnomalyClient anomalyClient;
	private final AnomalyCategoriesDAO anomalyCategoriesDAO;

	public DdmAnomalyServiceImpl(AnomalyClient anomalyClient, AnomalyCategoriesDAO anomalyCategoriesDAO) {
		this.anomalyClient = anomalyClient;
		this.anomalyCategoriesDAO = anomalyCategoriesDAO;
	}

	@Override
	public Map<AnomalyLevelEnum, List<AnomalySearchResponse>> getAnomaliesGroupedByLevel(ReqContext reqContext, String namespace,
			String entityCode, String entityId, AnomalyType... acceptedAnomalyTypes) {
		return getAnomaliesGroupedByLevel(reqContext, namespace, entityCode, List.of(entityId), acceptedAnomalyTypes);
	}

	@Override
	public Map<AnomalyLevelEnum, List<AnomalySearchResponse>> getAnomaliesGroupedByLevel(ReqContext reqContext, String namespace,
			String entityCode, List<String> entityIds, AnomalyType... acceptedAnomalyTypes) {

		List<AnomalyType> acceptedAnomalyTypesList = acceptedAnomalyTypes.length > 0 ? List.of(acceptedAnomalyTypes) : List.of();

		AnomalySearchRequest searchRequest = new AnomalySearchRequest()
				.setGroupCode(acceptedAnomalyTypesList.isEmpty() ? null
						: acceptedAnomalyTypesList.stream().map(AnomalyType::getGroupCode)
								.distinct().collect(Collectors.toList()))
				.setTypeCode(acceptedAnomalyTypesList.isEmpty() ? null
						: acceptedAnomalyTypesList.stream().map(AnomalyType::getCode)
								.distinct().collect(Collectors.toList()))
				.setEntityId(entityIds);
		List<AnomalySearchResponse> anomalySearchResponses = anomalyClient.search(reqContext.getLang(), reqContext.getUser(), entityCode, searchRequest);

		Map<AnomalyType, AnomalyCategoriesEntity> anomalyCategories = anomalySearchResponses.stream()
				.map(AnomalyType::new).distinct()
				.map(t -> anomalyCategoriesDAO.findByTenantGroupCodeAndCode(reqContext.getTenantId(), namespace, t.getGroupCode(), t.getCode()))
				.filter(Objects::nonNull)
				.collect(Collectors.toMap(AnomalyType::new, Function.identity()));

		Map<AnomalyLevelEnum, List<AnomalySearchResponse>> anomaliesGrouped = new HashMap<>();
		for (AnomalySearchResponse anomalySearchResponse : anomalySearchResponses) {
			AnomalyType anomalyType = new AnomalyType(anomalySearchResponse);
			AnomalyCategoriesEntity anomalyCategory = anomalyCategories.getOrDefault(anomalyType, DEFAULT_ANOMALY_CATEGORY);

			if (anomalyCategory.getFlExclude() == 0 && (acceptedAnomalyTypesList.isEmpty() || acceptedAnomalyTypesList.contains(anomalyType))) {
				anomaliesGrouped.computeIfAbsent(anomalyCategory.getLevel(), k -> new ArrayList<>())
						.add(anomalySearchResponse);
			}
		}

		return anomaliesGrouped;
	}

}
