package com.abacogroup.ddm.db.dao;

import java.util.List;

import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.customizer.BindBean;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;
import org.jdbi.v3.sqlobject.transaction.Transactional;

import com.abacogroup.ddm.db.ntt.SuccessionConfigEntity;
import com.abacogroup.jdbi.EnhancedSqlObject;

public interface SuccessionConfigDAO extends Transactional<SuccessionConfigDAO>, EnhancedSqlObject {
	
	@SqlQuery("§select_nextval(ddm_succession_doc_seq)§")
	Long nextSequenceValPkid();
	
	@SqlUpdate("INSERT INTO ddm_succession_doc_config (pkid, tenant_id, namespace, code, parent_code, succession_code, attachment_type, fl_mandatory, max_occurrences, dt_insert, user_id_insert, dt_delete, user_id_delete) "
            + "VALUES (:pkid, :tenantId, :namespace, :code, :parentCode, :successionCode, :attachmentType, :flMandatory, :maxOccurrences, :dtInsert, :userIdInsert, :dtDelete, :userIdDelete)")
	void insert(@Bind("tenantId") String tenantId, @BindBean SuccessionConfigEntity successionConfigEntity);

	@SqlQuery("select pkid, \n"
			+ "      namespace, \n"
			+ "      code, \n"
			+ "      parent_code, \n"
			+ "      succession_code, \n"
			+ "      attachment_type, \n"
            + "      coalesce (§i18n(:tenantId, 'ddm_succession_doc_config', 'attachment_type', attachment_type, :lang)§, attachment_type) as attachmentTypeDescription, \n"
			+ "      fl_mandatory, \n"
			+ "      max_occurrences \n"
			+ " from ddm_succession_doc_config \n"
			+ " where tenant_id = :tenantId\n"
			+ "   and namespace = :namespace\n"
			+ "   and code = :code\n"
			+ "   and succession_code = :successionCode\n"
			+ "   and §current_timestamp§ between dt_insert and dt_delete")
	@RegisterBeanMapper(SuccessionConfigEntity.class)
	SuccessionConfigEntity getSuccessionConfig(@Bind("tenantId") String tenantId, @Bind("lang") String lang, @Bind("namespace") String namespace,
			@Bind("successionCode") String successionCode, @Bind("code") String code);
	
	@SqlQuery("select pkid, \n"
			+ "      namespace, \n"
			+ "      code, \n"
			+ "      parent_code, \n"
			+ "      succession_code, \n"
			+ "      attachment_type, \n"
			+ "      coalesce (§i18n(:tenantId, 'ddm_succession_doc_config', 'attachment_type', attachment_type, :lang)§, attachment_type) as attachmentTypeDescription, \n"
			+ "      fl_mandatory, \n"
			+ "      max_occurrences \n"
			+ " from ddm_succession_doc_config \n"
			+ " where tenant_id = :tenantId\n"
			+ "   and namespace = :namespace\n"
			+ "   and succession_code = :successionCode\n"
			+ "   and (:attachmentCode is null or attachment_type = :attachmentCode)\n"
			+ "   and §current_timestamp§ between dt_insert and dt_delete")
	@RegisterBeanMapper(SuccessionConfigEntity.class)
	List<SuccessionConfigEntity> getByNamespaceAndSuccessionCode(@Bind("tenantId") String tenantId, @Bind("lang") String lang, @Bind("namespace") String namespace,
			@Bind("successionCode") String successionCode, @Bind("attachmentCode") String attachmentCode);

	@SqlQuery("select pkid, \n"
			+ "      namespace, \n"
			+ "      code, \n"
			+ "      parent_code, \n"
			+ "      succession_code, \n"
			+ "      attachment_type, \n"
			+ "      coalesce (§i18n(:tenantId, 'ddm_succession_doc_config', 'attachment_type', attachment_type, :lang)§, attachment_type) as attachmentTypeDescription, \n"
			+ "      fl_mandatory, \n"
			+ "      max_occurrences \n"
			+ " from ddm_succession_doc_config \n"
			+ " where tenant_id = :tenantId\n"
			+ "   and namespace = :namespace\n"
			+ "   and (:successionCode is null or succession_code = :successionCode)\n"
			+ "   and (:attachmentCode is null or attachment_type = :attachmentCode)\n"
			+ "   and §current_timestamp§ between dt_insert and dt_delete")
	@RegisterBeanMapper(SuccessionConfigEntity.class)
	List<SuccessionConfigEntity> getByNamespace(@Bind("tenantId") String tenantId, @Bind("lang") String lang, @Bind("namespace") String namespace,
			@Bind("successionCode") String successionCode, @Bind("attachmentCode") String attachmentCode);
	
	@SqlUpdate("UPDATE ddm_succession_doc_config "
			+ "SET dt_delete = §current_timestamp§, "
			+ "   user_id_delete = :userIdDelete " 
			+ "WHERE pkid = :pkid")
	void expire(@Bind("pkid") Long pkid, @Bind("userIdDelete") String userIdDelete);
	
}
