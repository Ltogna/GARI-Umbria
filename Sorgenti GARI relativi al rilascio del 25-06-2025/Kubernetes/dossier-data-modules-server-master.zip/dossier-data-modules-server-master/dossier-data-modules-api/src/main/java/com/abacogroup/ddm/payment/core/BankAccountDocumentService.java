package com.abacogroup.ddm.payment.core;

import com.abacogroup.ddm.common.resources.ReqContext;
import com.abacogroup.ddm.payment.api.BankAccountDocumentRes;
import com.abacogroup.ddm.payment.api.req.BankAccountDocumentSearchReq;
import com.abacogroup.dynamicdocuments.bean.Document;
import com.abacogroup.dynamicdocuments.bean.InsertDocument;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import jakarta.ws.rs.core.Response;

public interface BankAccountDocumentService {
	BankAccountDocumentRes insert(ReqContext reqContext, Long partyId, Long accountId, InsertDocument document);

	void expire(ReqContext reqContext, Long partyId, Long accountId, Long documentId);

	BankAccountDocumentRes update(ReqContext reqContext, Long partyId, Long accountId, Long documentId, Document updateReq);

	BankAccountDocumentRes getBankAccountDocument(ReqContext reqContext, Long partyId, Long accountId, Long documentId);

	InfiniteListResults<BankAccountDocumentRes> search(ReqContext reqContext, Long partyId, Long accountId, BankAccountDocumentSearchReq searchReq,
			String nextKey);

	Long countDocumentsByAccountIdAndDefinitionCode(ReqContext reqContext, Long accountId, String code);

	Response getDocumentFileContent(ReqContext reqContext, Long partyId, Long accountId, Long documentId, String fileId);

	Response getDocumentFileMetadata(ReqContext reqContext, Long partyId, Long accountId, Long documentId, String fileId);
}
