package com.abacogroup.ddm.payment.core.impl;

import static com.abacogroup.ddm.DossierDataModulesApplication.PAYMENT_MODULE;

import com.abacogroup.anomalyregistry.api.v1.AnomalySearchResponse;
import com.abacogroup.ddm.api.AnomalyLevelEnum;
import com.abacogroup.ddm.api.DdmAnomaliesRes;
import com.abacogroup.ddm.common.resources.ReqContext;
import com.abacogroup.ddm.core.DdmAnomalyService;
import com.abacogroup.ddm.core.dto.AnomalyType;
import java.util.List;
import java.util.Map;

public class PartyAnomalyServiceImpl implements com.abacogroup.ddm.payment.core.PartyAnomalyService {

	private final DdmAnomalyService anomalyService;

	public PartyAnomalyServiceImpl(DdmAnomalyService anomalyService) {
		this.anomalyService = anomalyService;
	}

	@Override
	public DdmAnomaliesRes getAnomalies(ReqContext reqContext, Long partyId) {

		// TODO validate party ?

		Map<AnomalyLevelEnum, List<AnomalySearchResponse>> anomaliesGrouped = anomalyService.getAnomaliesGroupedByLevel(reqContext, PAYMENT_MODULE,
				AnomalyHelper.PARTY_ENTITY_CODE, partyId.toString(),
				new AnomalyType(AnomalyHelper.ANM_GROUP_CODE_PAYMENT_ACCOUNT, AnomalyHelper.ANM_TYPE_NO_CC),
				new AnomalyType(AnomalyHelper.ANM_GROUP_CODE_PAYMENT_ACCOUNT, AnomalyHelper.ANM_TYPE_CC_PRED));

		return new DdmAnomaliesRes(anomaliesGrouped);
	}

}
