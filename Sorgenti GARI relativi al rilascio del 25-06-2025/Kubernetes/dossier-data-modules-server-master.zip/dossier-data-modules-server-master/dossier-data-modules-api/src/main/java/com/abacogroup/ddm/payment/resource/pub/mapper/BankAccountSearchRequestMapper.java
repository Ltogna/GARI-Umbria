package com.abacogroup.ddm.payment.resource.pub.mapper;

import com.abacogroup.ddm.payment.api.req.BankAccountSearchReq;
import com.abacogroup.ddm.payment.api.v1.req.BankAccountSearchRequestV1;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper
public interface BankAccountSearchRequestMapper {

	BankAccountSearchRequestMapper INSTANCE = Mappers.getMapper(BankAccountSearchRequestMapper.class);

	BankAccountSearchReq toSearchReq(BankAccountSearchRequestV1 requestV1);


}
