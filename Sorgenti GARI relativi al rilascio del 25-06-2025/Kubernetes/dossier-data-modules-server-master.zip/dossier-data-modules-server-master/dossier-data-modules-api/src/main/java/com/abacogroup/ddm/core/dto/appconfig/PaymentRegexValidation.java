package com.abacogroup.ddm.core.dto.appconfig;

import com.abacogroup.ddm.core.dto.appconfig.PaymentRegexValidation.Config;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.experimental.SuperBuilder;

@Data
@EqualsAndHashCode(callSuper = true)
@ToString(callSuper = true)
@SuperBuilder(setterPrefix = "set")
@AllArgsConstructor
@NoArgsConstructor
public class PaymentRegexValidation extends BaseAppConfig<Config> {

	public static final String CONFIG_KEY = "payment_regex_validation";

	@Valid
	@NotNull
	private Config configuration;

	@Data
	@Builder(setterPrefix = "set")
	@NoArgsConstructor
	@AllArgsConstructor
	@Schema(name = "PaymentRegexValidationConfig")
	public static class Config {
		@NotEmpty
		private List<@NotBlank String> regexes;
	}

}
