package com.abacogroup.ddm.db.ntt;

import com.abacogroup.jdbi.model.AuditEntity;
import java.time.LocalDateTime;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder(setterPrefix = "set", toBuilder = true)
@NoArgsConstructor
public class DocTypeRelationEntity implements AuditEntity {

	private Long pkid;
	private String tenantId;
	private String definitionCode;
	private String namespace;

	private int flRequired = 0;

	private LocalDateTime dtInsert;
	private String userIdInsert;
	private LocalDateTime dtDelete;
	private String userIdDelete;
}
