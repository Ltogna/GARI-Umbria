
# ✨ DOSSIER DATA MODULES API ✨ #

[TOC]

## How to start the DOSSIER DATA MODULES API application ##

1. Run `mvn clean install` to build your application
1. execute migrations with `java -jar target/original-dossier-data-modules-api-{version}.jar db migrate config.yml`
1. Start application with `java -jar target/dossier-data-modules-api-{version}.jar server config.yml`
1. To check that your application is running enter url [localhost:18912/dossier-data-modules](http://localhost:18912/dossier-data-modules)


## OpenAPI ##

[openapi.yaml](docs/openapi.yaml)

[openapi.json from local server](`http://localhost:18912/dossier-data-modules/openapi.json`)   
[swagger per testare l'output](https://editor-next.swagger.io/)

## Services (namespace) ##
This project is divided into virtual sub-services.
For each one a sub-path is defined that groups its APIs

### payment
Manage bank accounts.

path: `/{tenant}/api-priv/v1/payment-methods/`

### heir
Manage bank accounts.

path: `/{tenant}/api-priv/v1/heirs-methods/`

### vine
Manage viticulture index.

path: `/{tenant}/api-priv/v1/vine-auth`


## Bundles Infrastructure integration ##

The application must be connected to a RabbitMQ instance.

The bundles infrastructure will automatically set up to allow automatic configuration.

The application module id is `dossier-data-modules` and the supported changeset domains are:

```
📂 dossier-data-modules
┗━📂 <client-id>-<nnnnn>
  ┣━📂 app_config
  ┃ ┣━📜 <any file>.json
  ┃ ┗━📜 <.*>delete<.*>.json
  ┣━📂 anomaly-categories
  ┃ ┣━📜 <any file>.jsonl
  ┃ ┗━📜 <.*>delete<.*>.jsonl
  ┣━📂 dynamic_documents
  ┃ ┣━📜 <any file>.json
  ┃ ┣━📜 settings<.*>.json
  ┃ ┗━📜 settings<.*>delete<.*>.json
  ┣━📂 succession-config
  ┃ ┣━📜 <any file>.json
  ┃ ┗━📜 <.*>delete<.*>.json

```

### app_config

The `app_config` file(s) are used to insert/update custom application properties.  
JSON file(s) must have the following structure:

```json5
[
  {
    "configurationKey": "the_key", // mandatory
    "configuration": { // custom json, mandatory
      "k1": true,
      "k2": "v2",
      "k3": {
        "k3_1": "v3_1",
        // [...]
      },
      //[...]
    }
  },
  // [...]
]
```

`app_config` file(s) containing `delete` in its name are used to delete configurations.  
JSON file(s) must have the following structure:

```json5
[
  {
    "configurationKey": "the_key" // mandatory
  },
  // [...]
]
```

#### payment_default_account

used by the service [payment](#payment)

configures the behaviour of the application when closing a default bank account:
- if `allowClose=false` the application will prevent setting a closing date to a default current account
- if `allowClose=true` the application will allow a default bank account to be closed and set it as non-default

```json5
[
  {
    "configurationKey": "payment_default_account",
    "configuration": {
      "allowClose": false 
    }
  }
]
```

#### payment_regex_validation

used by the service [payment](#payment)

this json configures the regex to be used to validate an iban:
- regexes: regex list, the iban is valid when at least one matches

```json5
[
  {
    "configurationKey": "payment_regex_validation",
    "configuration": {
      "regexes" : [
        "[\\dA-Z]{1,99}", "[\\da-z]{1,99}" //, [...]
      ]
    }
  }
]
```


### anomaly-categories

The anomaly categories JSONL file(s) is used for insert/update `ddm_anomaly_categories` table and must have the following structure:
```json5 lines
{"namespace": "String (mandatory)", "groupCode": "String (mandatory)", "code": "String (mandatory)" ,"level": "AnomalyLevelEnum (mandatory)", "exclude": "boolean"}
//[...]
```
The anomaly categories JSONL file(s) that contains "delete" in its name is used for delete `ddm_anomaly_categories` entries and must have the following structure:
```json5 lines
{"namespace": "String (mandatory)", "groupCode": "String (mandatory)", "code": "String (mandatory)"}
//[...]
```

`Anomaly categories values`:

- `namespace`: [service reference](#services-namespace-)
- `groupCode`: code group of anomaly categories
- `code`: code of anomaly categories
- `level`: level of anomaly, allowable values: `DANGER`, `WARN`, `INFO`
- `exclude`: flag for exclude a category, default is false


### dynamic_documents

The `dynamic_documents` file(s) are used to insert/update dynamic document schemas.  
JSON file(s) must have the following structure:

#### dynamic doc definitions

(see dynamic document documentation)

#### settings

The application handles `dynamic documents` (abbr: _DD_)

A sample configuration can be found at [`bundles/standard/dossier-data-modules/ddm-001/dynamic_documents`](bundles/standard/dossier-data-modules/ddm-001/dynamic_documents)

The system will assume as definition file **any** `json` in the directory except those whose names begin with `settings` (e.g.: _settings_01.json_)

When loading a `DD` definition the i18n labels of the DD will be automatically created.

The settings file is used to define the usage of the _DD_ on the portal.   
An example of a settings file:

```json5
[
  {
    "definitionCode": "DEF_1",
    "required": true,
    "namespace": "payment"
  },
  {
    "definitionCode": "DEF_2",
    "required": false,
    "namespace": "payment"
  },
  {
    "definitionCode": "DEF_3",
    "required": true,
    "namespace": "payment"
  }
]
```

For each namespace, there is a list of dynamic documents that has to be associated.

The presence of at least one associated dynamic document to a specific namespace
must have a specific configuration that defines their obligatory nature in general (required).

The configuration of a specific dynamic document type (definitionCode) changes throughout the associated namespace.
For each type of DD (definitionCode) you have to specify:

- the `namespace` the [service](#services-namespace-) to be associated to the dynamic document type.
- the `required` represents the obligatory nature of defining a DD.

#### delete settings

`dynamic_documents` files starting with `settings` and containing `delete` in the name (ex. 'settings_0001.delete.json') are used to delete settings related to
the specific DDType (definitionCode) in relative namespace.
The DDs will no longer be visualised by the FE but remain in the db and can be reactivated by a new settings file. 

JSON file(s) must have the following structure:

```json5
[
  {
    "definitionCode": "DEF_1",
    "namespace": "payment"
  }
  //[...]
]
```
### succession-config

The succession config JSON file(s) is used for insert/update `ddm_succession_doc_config` and `ddm_succession_types` tables.
The configuration JSON is composed of two main sections:

- `successionList`: list of available succession types
- `successionConfigList`: detailed document configuration for each type

#### 🔹 successionList
- `code`: unique code identifying the succession type
- `description`: i18nMap of succession type descriptions
- `visible`: if true, this type is visible in ui

#### 🔹 successionConfigList
- `successionCode`: the succession type code
- `namespace`: the [service](#services-namespace) .
- `groups`: Array [ see below ]

#### 🔹 groups
Each group represents a document or a logical group of documents. It may contain:
- `code`: unique identifier
- `parentCode`: (optional) to create hierarchical or alternative relationships
- `flMandatory`: whether the document or group of document is required
- `attachmentType`: [ see below ]

#### 🔹 attachmentType
- `code`: unique identifier
- `description`: i18nMap of descriptions
- `maxOccurrences`: num of occurrences of a specific document type

#### some notes...
- `group.code` and `attachmentType.code` must be unique
- Use `parentCode` to build hierarchies and model OR logic
- If a group is marked as "flMandatory": true, then the requirement can be satisfied in one of two ways:  
   - Case 1: If the group includes an `attachmentType`, then the document specified **must be provided**.  
   - Case 2: If the group doesn't include a document itself, but has child groups, at least one of them must be satisfied.

the model:
```json5
{
    "successionList": [
        {
            "code": "String (mandatory)",
            "description": {
                "String": "String",
                // ...
            },
            "visible": Boolean
        },
        {
          // ...
        }
    ],
    "successionConfigList": [
        {
            "successionCode": "String (mandatory)",
            "namespace": "String (mandatory)",
            "groups": [
                {
                    "code": "String (mandatory)",
                    "parent_code": "String",
                    "flMandatory": Boolean,
                    "attachmentType": {
                        "code": "String (mandatory)",
                        "description": {
                            "String": "String",
                            // ...
                        },
                        "maxOccurrences": Integer
                    }
                },
                {
                  // ...
                }
            ]	
        },
        {
          // ...
        }
    ]
}
```
The succession config JSONL file(s) that contains "delete" in its name is used for delete `ddm_succession_doc_config` entries and must have the following structure:
```json5 lines
{
    "successionConfigList": [
        {
            "successionCode": "String (mandatory)",
            "namespace": "String (mandatory)",
            "groups": [
                {
                    "code": "String (mandatory)",
                },
                {
                  // ...
                }
            ]	
        },
        {
          // ...
        }
    ]
}
```






