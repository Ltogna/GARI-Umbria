# TAG A NEW DOSSIER-DATA-MODULES-SERVER VERSION

mvn versions:set -DnewVersion=X.X.X

mvn versions:commit