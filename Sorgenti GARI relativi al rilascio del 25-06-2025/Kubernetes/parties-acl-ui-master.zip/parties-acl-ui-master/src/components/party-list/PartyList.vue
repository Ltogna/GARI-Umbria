<script setup lang="ts">
import { useApiResponseHandler } from "@/composables/useApiResponseHandler";
import useMandeteListHistoryFlag from "@/composables/useMandeteListHistoryFlag";
import useModuleId from "@/composables/useModuleId";
import { usePartyList } from "@/composables/usePartyList";
import type { FilterModel, PartyFilterSchema, PartySchema } from "@/models/parties";
import { RouteName } from "@/models/routes";
import { getParties } from "@/resources/api/parties";
import { getPartyDenomination } from "@/utils/partyDenomination";
import BiIconButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiIconButton.vue";
import BiChip from "@abaco/bootstrap-italia-components/src/components/BiChip/BiChip.vue";
import BiHiddenContent from "@abaco/bootstrap-italia-components/src/components/BiHiddenContent/BiHiddenContent.vue";
import BiTable from "@abaco/bootstrap-italia-components/src/components/BiTable/BiTable.vue";
import { computed } from "vue";
import { useI18n } from "vue-i18n";
import { useRouter } from "vue-router";
import LoadMore from "../common/LoadMore.vue";

withDefaults(
  defineProps<{
    partyList: PartySchema[];
    showLoadMore?: boolean;
    loading?: boolean;
  }>(),
  { showLoadMore: false, loading: false },
);

const emit = defineEmits<{
  (e: "load-more"): void;
}>();

const { history } = useMandeteListHistoryFlag();

type PartySearchFilterField = keyof FilterModel;

const { t } = useI18n();
const moduleId = useModuleId();
const router = useRouter();
const { search, removeFilter, setPageValues } = usePartyList();

function loadMore() {
  emit("load-more");
}

function goToDetail(partyId: string) {
  router.push({ name: RouteName.PARTY_DETAILS, params: { partyId } });
  history.value = false;
}

function hasMandateToString(party: PartySchema) {
  if (party.exclusiveCount === undefined || party.exclusiveCount === null) {
    return "-";
  }

  return party.exclusiveCount > 0 ? t(`${moduleId}.general.yes`) : t(`${moduleId}.general.no`);
}
const cuaaLabel = computed(() => {
  if (search.code) {
    return t(`${moduleId}.cuaaChip`, { code: search.code.toUpperCase() });
  }
  return null;
});
const fullNameLabel = computed(() => {
  if (search.fullName) {
    return t(`${moduleId}.party.list.fields.last_name_chip`, { name: search.fullName.toUpperCase() });
  }
  return null;
});
const isDeletable = computed(() => {
  return !!search.fullName && !!search.code;
});

async function removeChip(filterCode: PartySearchFilterField) {
  if (search.code && search.fullName) {
    removeFilter(filterCode);

    const res = await useApiResponseHandler(() => getParties(search as PartyFilterSchema));
    if (res && typeof res !== "boolean") {
      setPageValues(res);
    }
  }
}
</script>
<template>
  <BiChip :model-value="!!cuaaLabel" :is-delete="isDeletable" :label="cuaaLabel ?? ''" @delete="removeChip('code')"></BiChip>
  <BiChip :model-value="!!fullNameLabel" :is-delete="isDeletable" :label="fullNameLabel ?? ''" @delete="removeChip('fullName')"></BiChip>
  <BiTable is-custom responsive-breakpoint="md" is-row-hover is-header-light class="mt-3">
    <template #head>
      <tr>
        <th>
          {{ t(`${moduleId}.party.list.fields.last_name`) }}
        </th>
        <th>{{ t(`${moduleId}.cuaa`) }}</th>
        <th>
          {{ t(`${moduleId}.party.list.fields.has_mandates`) }}
        </th>
        <th>
          <BiHiddenContent :text="t(`${moduleId}.general.goto_details`)"></BiHiddenContent>
        </th>
      </tr>
    </template>
    <template #body>
      <tr v-for="party in partyList" :key="party.id">
        <td :data-label="t(`${moduleId}.party.list.fields.last_name`)">
          {{ getPartyDenomination(party) }}
        </td>
        <td :data-label="t(`${moduleId}.cuaa`)">
          {{ party.code }}
        </td>
        <td :data-label="t(`${moduleId}.party.list.fields.has_mandates`)">
          {{ hasMandateToString(party) }}
        </td>
        <td class="actions">
          <BiIconButton
            icon="arrow-right"
            is-outlined
            color="secondary"
            icon-color="secondary"
            :width="35"
            :title="t(`${moduleId}.general.goto_details`)"
            @click="goToDetail(party.id.toString())"
          />
        </td>
      </tr>
    </template>
  </BiTable>

  <LoadMore :is-loading="loading" :is-visible="showLoadMore" @load:more="loadMore"></LoadMore>
</template>
