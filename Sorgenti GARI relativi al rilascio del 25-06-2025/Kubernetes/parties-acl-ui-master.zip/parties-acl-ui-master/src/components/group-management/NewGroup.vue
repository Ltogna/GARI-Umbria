<script setup lang="ts">
import { useApiResponseHandler, useNotification } from "@/composables/useApiResponseHandler";
import useEmitter from "@/composables/useEmitter";
import useModuleId from "@/composables/useModuleId";
import usePermissions from "@/composables/usePermissions";
import type { CreateEntityPayloadModel } from "@/models/entities";
import type { PartySchema } from "@/models/parties";
import { RouteName } from "@/models/routes";
import type { EntityTypeModel } from "@/models/types";
import { createEntity } from "@/resources/api/entities";
import { getAllEntityTypes } from "@/resources/api/types";
import { useConfigStore } from "@/stores/config";
import { DATE_FORMAT_DAYJS } from "@/utils/dates";
import { getPartyDenomination } from "@/utils/partyDenomination";
import BiButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiButton.vue";
import BiTextarea from "@abaco/bootstrap-italia-components/src/components/form/BiTextarea.vue";
import BiDatepicker from "@abaco/bootstrap-italia-components/src/components/form/BiDatepicker.vue";
import BiInput from "@abaco/bootstrap-italia-components/src/components/form/BiInput.vue";
import BiSelect from "@abaco/bootstrap-italia-components/src/components/form/BiSelect.vue";
import type { SelectItem } from "@abaco/bootstrap-italia-components/src/models";
import { ErrorType } from "@abaco/safe-rest/src/HTTPClient";
import { toTypedSchema } from "@vee-validate/zod";
import { useForm } from "vee-validate";
import { computed, onMounted, ref, watch } from "vue";
import { useI18n } from "vue-i18n";
import { useRouter } from "vue-router";
import z from "zod";
import "../../../node_modules/bootstrap-italia/src/scss/custom/_just-validate.scss";
import SearchPartyModal from "./modals/SearchPartyModal.vue";

const DEFAULT_FORM_VALUES = {
  denomination: "",
  description: "",
  partyCode: "",
  startDate: "",
  type: "",
  registry_party_id: "",
};

const moduleId = useModuleId();
const { t } = useI18n();
const { canWrite } = usePermissions();
const emitter = useEmitter();

const entityTypesList = ref<EntityTypeModel[]>([]);
const entityTypeItems = ref<(SelectItem & { fl_entity_code_mandatory?: boolean })[]>([]);

onMounted(async () => {
  let nextKey: string | null = null;
  do {
    const response = await getAllEntityTypes(nextKey);
    if (response.errorType !== ErrorType.NONE) {
      console.warn(response);
    } else {
      entityTypesList.value = [...entityTypesList.value, ...response.data.records];
      const mappedItems: SelectItem[] = response.data.records.map((item) => {
        return {
          id: item.code,
          text: item.description,
          fl_entity_code_mandatory: item.fl_entity_code_mandatory ?? false,
        };
      });
      entityTypeItems.value = [...entityTypeItems.value, ...mappedItems];
      nextKey = response.data.nextKey;
    }
  } while (nextKey);
});

/*
"code": "string",
"name": "string",
"description": "string",
"entity_type_code": "string",
"registry_party_id": "string",
"day_from": "20211231",
"day_to": "20211231"
*/
const FormSchema = z
  .object({
    partyCode: z
      .string({
        required_error: t(`${moduleId}.general.mandatory_field`),
      })
      .trim(),
    denomination: z
      .string({
        required_error: t(`${moduleId}.general.mandatory_field`),
      })
      .trim()
      .min(1, t(`${moduleId}.general.mandatory_field`)),
    type: z
      .string({
        required_error: t(`${moduleId}.general.mandatory_field`),
      })
      .trim()
      .min(1, t(`${moduleId}.general.mandatory_field`)),
    //TODO: add validation if allowPastDate is false
    startDate: z
      .string({
        required_error: t(`${moduleId}.general.mandatory_field`),
      })
      .min(1, t(`${moduleId}.general.mandatory_field`)),
    description: z
      .string({
        required_error: t(`${moduleId}.general.mandatory_field`),
      })
      .trim(),
    registry_party_id: z.string({
      required_error: t(`${moduleId}.general.mandatory_field`),
    }),
  })
  .refine(
    (data) => {
      const required = entityTypeItems.value.find((e) => e.id.toString() === data.type.toString())?.fl_entity_code_mandatory ?? false;
      return !required || (required && data.partyCode.length > 0);
    },
    { path: ["partyCode"], message: t(`${moduleId}.general.mandatory_field`) },
  );
type FormModel = z.infer<typeof FormSchema>;

const router = useRouter();
const { handleSubmit, defineField, errors, resetForm, meta, submitCount } = useForm<FormModel>({
  validationSchema: toTypedSchema(FormSchema),
  initialValues: structuredClone(DEFAULT_FORM_VALUES),
});

const [partyCode] = defineField("partyCode");
const [denomination] = defineField("denomination");
const [type] = defineField("type");
const [startDate] = defineField("startDate");
const [description] = defineField("description");
const [registry_party_id] = defineField("registry_party_id");

watch(
  () => meta.value.dirty,
  (isDirty) => {
    emitter.emit("is:dirty", isDirty);
  },
);

const onSubmit = handleSubmit(async (values) => {
  {
    const details: CreateEntityPayloadModel = {
      name: !values.registry_party_id ? values.denomination : undefined,
      code: values.partyCode || undefined,
      entity_type_code: values.type,
      registry_party_id: values.registry_party_id || undefined,
      day_from: values.startDate,
      description: values.description,
    };
    const resp = await useApiResponseHandler(() => createEntity(details));
    if (resp && typeof resp !== "boolean") {
      //await groupStore.getGroupDetails(groupDetail.id);
      resetForm({
        values,
      });
      useNotification().showSuccessNotification();
      gotoGroup(resp);
      return true;
    }

    return false;
  }
});

const onReset = () => {
  const values = structuredClone(DEFAULT_FORM_VALUES);
  resetForm({
    values,
  });
};

const isEditable = computed(() => canWrite);

const showModal = ref(false);

const onShowModal = () => {
  showModal.value = !showModal.value;
};

function gotoGroup(groupId: number) {
  router.push({ name: RouteName.GROUP_DETAILS, params: { groupId } });
}

function onPartySelected(party: PartySchema) {
  entityTypesList.value = [];
  denomination.value = getPartyDenomination(party);
  registry_party_id.value = party.id.toString();
}

function clearParty() {
  denomination.value = "";
  registry_party_id.value = "";
}

const fl_entity_code_mandatory = computed(
  () => entityTypeItems.value.find((e) => e.id.toString() === type.value.toString())?.fl_entity_code_mandatory ?? false,
);

const { allowPastDate } = useConfigStore();

const minStartDate = computed(() => (!allowPastDate ? new Date() : undefined));
</script>

<template>
  <!-- TODO better style & layout -->
  <form @submit.prevent="onSubmit" @reset.prevent="onReset" novalidate class="parties-acl__form">
    <div class="row g-2">
      <div class="col-md-6 col-lg-4" :class="{ 'field-required': fl_entity_code_mandatory }">
        <BiInput
          type="search"
          v-model.trim="partyCode"
          :label="t(`${moduleId}.group.search.group_code`)"
          :errors="errors.partyCode && submitCount > 0 ? [errors.partyCode] : []"
          :required="fl_entity_code_mandatory"
        ></BiInput>
      </div>
      <div class="w-100" />

      <div class="col-md-6 col-lg-4 field-required">
        <BiInput
          type="search"
          v-model.trim="denomination"
          :readonly="!!registry_party_id"
          :label="t(`${moduleId}.group.search.denomination`)"
          :errors="errors.denomination && submitCount > 0 ? [errors.denomination] : []"
        ></BiInput>
      </div>
      <div class="col-md-6 col-lg-4">
        <BiButton color="secondary" class="btn-me" is-outlined @click="onShowModal">
          {{ t(`${moduleId}.group.search_registry`) }}
        </BiButton>
        <BiButton v-if="!!registry_party_id" color="danger" is-outlined @click="clearParty">
          {{ t(`${moduleId}.group.empty_registry`) }}
        </BiButton>
      </div>
      <div class="w-100" />
      <div class="col-md-6 col-lg-4">
        <BiSelect
          :items="entityTypeItems"
          :empty-option="t(`${moduleId}.general.select`)"
          :label="t(`${moduleId}.group.type`)"
          :errors="errors.type && submitCount > 0 ? [errors.type] : []"
          class="field-required"
          v-model="type"
        ></BiSelect>
      </div>
      <div class="w-100" />
      <div class="col-md-6 col-lg-4">
        <BiDatepicker
          :is-disabled="!isEditable"
          :format="DATE_FORMAT_DAYJS"
          :label="t(`${moduleId}.group.start_date`)"
          :min="minStartDate"
          :errors="errors.startDate && submitCount > 0 ? [errors.startDate] : []"
          class="field-required"
          v-model="startDate"
        ></BiDatepicker>
      </div>
      <div class="w-100" />
      <div class="col-md-6 col-lg-4">
        <BiTextarea :label="t(`${moduleId}.group.description`)" v-model="description"></BiTextarea>
      </div>
    </div>

    <div class="row mt-4">
      <div class="col">
        <BiButton :is-disabled="!meta.dirty || !isEditable" type="submit" color="success" class="me-2">
          {{ t(`${moduleId}.general.proceed`) }}
        </BiButton>
        <BiButton :is-disabled="!meta.dirty || !isEditable" type="reset" color="secondary" is-outlined>
          {{ t(`${moduleId}.mandate_form.reset`) }}
        </BiButton>
      </div>
    </div>
  </form>

  <SearchPartyModal v-model="showModal" @selected="onPartySelected"></SearchPartyModal>
</template>
