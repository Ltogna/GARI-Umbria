<script setup lang="ts">
import useModuleId from "@/composables/useModuleId";
import { RouteName } from "@/models/routes";
import BiBackButton from "@abaco/bootstrap-italia-components/src/components/BiBackButton/BiBackButton.vue";
import { useI18n } from "vue-i18n";
import { useRoute, useRouter } from "vue-router";

const router = useRouter();
const route = useRoute();
const moduleId = useModuleId();
const { t } = useI18n();

async function backToList() {
  if (route.name === RouteName.GROUP_LIST) {
    router.replace({
      name: RouteName.GROUP,
    });
  }
  if (route.name === RouteName.GROUP_NEW) {
    router.replace({
      name: RouteName.GROUP,
    });
  }
  if (route.name === RouteName.GROUP_DETAILS) {
    router.replace({
      name: RouteName.GROUP_LIST,
    });
  }
  if (route.name === RouteName.GROUP_USERS) {
    router.replace({
      name: RouteName.GROUP_DETAILS,
    });
  }
  if (route.name === RouteName.GROUP_HIERARCHY) {
    router.replace({
      name: RouteName.GROUP_DETAILS,
    });
  }
  // if (route.name === RouteName.GROUP_CLOSE) {
  //   router.replace({
  //     name: RouteName.GROUP_DETAILS,
  //   });
  // }
}
</script>

<template><BiBackButton :visually-hidden-text="t(`${moduleId}.general.go_back`)" @click="backToList" /></template>
