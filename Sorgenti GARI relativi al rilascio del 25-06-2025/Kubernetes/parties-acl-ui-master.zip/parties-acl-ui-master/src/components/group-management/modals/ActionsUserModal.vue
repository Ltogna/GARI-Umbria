<script setup lang="ts">
import { useApiResponseHandler, useNotification } from "@/composables/useApiResponseHandler";
import useEmitter from "@/composables/useEmitter";
import useGroupId from "@/composables/useGroupId";
import useModuleId from "@/composables/useModuleId";
import type { NewUserModel, UpdateEntityUserPayloadModel, UserModel } from "@/models/mandates";
import { addUserToEntity, updateUserInEntity } from "@/resources/api/mandates";
import { useUserStore } from "@/stores/user";
import BiButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiButton.vue";
import BiModal from "@abaco/bootstrap-italia-components/src/components/BiModal/BiModal.vue";
import BiTextarea from "@abaco/bootstrap-italia-components/src/components/form/BiTextarea.vue";
import BiCheckbox from "@abaco/bootstrap-italia-components/src/components/form/BiCheckbox.vue";
import BiInput from "@abaco/bootstrap-italia-components/src/components/form/BiInput.vue";
import { toTypedSchema } from "@vee-validate/zod";
import { useVModel } from "@vueuse/core";
import { useForm } from "vee-validate";
import { computed, onMounted, onUnmounted, ref, watch } from "vue";
import { useI18n } from "vue-i18n";
import { z } from "zod";

const moduleId = useModuleId();
const { t } = useI18n();
const { groupId } = useGroupId();

const FormSchema = z.object({
  username: z
    .string({ required_error: t(`${moduleId}.general.mandatory_field`) })
    .trim()
    .min(1, t(`${moduleId}.general.mandatory_field`)),
  isAdmin: z.boolean(),
  description: z.string().trim(),
});

type FormModel = z.infer<typeof FormSchema>;

const DEFAULT_VALUES: FormModel = {
  username: "",
  isAdmin: false,
  description: "",
};

const props = defineProps<{
  modelValue: boolean;
}>();

const emits = defineEmits<{
  (e: "update:modelValue"): void;
}>();

const emitter = useEmitter();
const userData = ref<UserModel | null>(null);
const isCreateUser = ref(true);

onMounted(() => {
  emitter.on("show:modal:user:edit", (user: UserModel) => {
    isCreateUser.value = false;
    showModal.value = true;
    userData.value = user;

    const { role, username, description } = user;
    resetForm({ values: { username, description: description ?? "", isAdmin: role === "ADMIN" } });
  });
});

onUnmounted(() => {
  emitter.off("show:modal:user:edit");
});

const { handleSubmit, defineField, resetForm, isSubmitting, meta, errors } = useForm<FormModel>({
  validationSchema: toTypedSchema(FormSchema),
  initialValues: structuredClone(DEFAULT_VALUES),
});

const [username] = defineField("username");
const [description] = defineField("description");
const [isAdmin] = defineField("isAdmin");

const showModal = useVModel(props, "modelValue", emits);

const onClose = () => {
  showModal.value = false;
};

watch(
  () => showModal.value,
  (isOpen) => {
    if (isOpen) {
      isError.value = false;
      if (!userData.value) {
        isCreateUser.value = true;
        resetForm({ values: structuredClone(DEFAULT_VALUES) });
      }
      return;
    }
    userData.value = null;
  },
);

const isLoading = ref(false);
const isError = ref(false);
const { showSuccessNotification } = useNotification();
const onConfirm = handleSubmit(async (values) => {
  if (!values) {
    return false;
  }

  const mappedUser: NewUserModel = {
    username: values.username,
    description: values.description,
    role: values.isAdmin ? "ADMIN" : "STD",
  };

  isLoading.value = true;
  let response: boolean | null = null;

  if (userData.value?.id) {
    response = await useApiResponseHandler(() =>
      updateUserInEntity(groupId.value, userData.value?.id || "", mappedUser as UpdateEntityUserPayloadModel),
    );
  } else {
    response = await useApiResponseHandler(() => addUserToEntity(groupId.value, mappedUser));
  }

  if (response) {
    isError.value = false;
    onClose();
    await useUserStore().getGroupUsers(groupId.value);
    showSuccessNotification();
  } else {
    isError.value = true;
  }
});

const title = computed(() => (isCreateUser.value ? t(`${moduleId}.group.user.add`) : t(`${moduleId}.group.user.edit`)));
const confirmLabel = computed(() => (isCreateUser.value ? t(`${moduleId}.general.add`) : t(`${moduleId}.group.user.edit`)));
</script>

<template>
  <BiModal class="parties-acl__modal" v-model="showModal" :title="title" size="lg">
    <template #body>
      <form @submit.prevent="onConfirm" class="parties-acl__form">
        <div class="field-required">
          <BiInput
            :readonly="!isCreateUser"
            :placeholder="t(`${moduleId}.group.user.insert_username`)"
            :label="t(`${moduleId}.group.user.username`)"
            :errors="meta.touched && errors.username ? [errors.username] : undefined"
            v-model.trim="username"
          />
        </div>
        <!-- <ErrorMessage v-if="meta.touched" name="username" class="form-feedback just-validate-error-label" /> -->
        <BiTextarea class="my-5" :label="t(`${moduleId}.group.description`)" v-model="description" />
        <BiCheckbox size="sm" :label="t(`${moduleId}.group.user.admin`)" v-model="isAdmin" />
        <input type="submit" class="invisible" :aria-label="t(`${moduleId}.general.save`)" />
      </form>
    </template>
    <template #footer>
      <div class="col-md-12 d-flex justify-content-center">
        <BiButton :is-disabled="isSubmitting" class="me-3" color="secondary" is-outlined @click="onClose">
          {{ t(`${moduleId}.general.cancel`) }}
        </BiButton>
        <BiButton :is-disabled="isSubmitting" color="success" @click="onConfirm">
          {{ confirmLabel }}
        </BiButton>
      </div>
    </template>
  </BiModal>
</template>
