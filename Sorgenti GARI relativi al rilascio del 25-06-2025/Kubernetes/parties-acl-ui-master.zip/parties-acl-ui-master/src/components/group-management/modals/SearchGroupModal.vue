<script setup lang="ts">
import { useApiResponseHandler } from "@/composables/useApiResponseHandler";
import useModuleId from "@/composables/useModuleId";
import usePermissions from "@/composables/usePermissions";
import type { EntityFilterModel, EntityModel, InfiniteListEntityModel } from "@/models/entities";
import { getEntitiesList } from "@/resources/api/entities";
import BiAlert from "@abaco/bootstrap-italia-components/src/components/BiAlert/BiAlert.vue";
import BiButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiButton.vue";
import BiModal from "@abaco/bootstrap-italia-components/src/components/BiModal/BiModal.vue";
import BiInput from "@abaco/bootstrap-italia-components/src/components/form/BiInput.vue";
import { toTypedSchema } from "@vee-validate/zod";
import { useVModel } from "@vueuse/core";
import { useForm } from "vee-validate";
import { computed, reactive, ref, watch } from "vue";
import { useI18n } from "vue-i18n";
import { z } from "zod";
import EntityList from "./EntityList.vue";

const moduleId = useModuleId();
const { t } = useI18n();
const { canWrite, isAdmin } = usePermissions();

const loading = ref(false);
const entities = reactive<InfiniteListEntityModel>({
  count: 0,
  nextKey: null,
  records: [],
});

const props = defineProps<{
  modelValue: boolean;
  filter?: EntityFilterModel;
  /**
   * [#110615](https://abacogroup.easyredmine.com/issues/110615) 31/07/23
   *
   * Exclude entity from list.
   * For now excluded the current group ID.
   *
   */
  excludeFromList?: number;
}>();

/**
 * [#110615](https://abacogroup.easyredmine.com/issues/110615) 31/07/23
 *
 * `filteredEntities` list without current group id
 */
const filteredEntities = computed(() => {
  if (props.excludeFromList) {
    return entities.records.filter((e) => e.id !== props.excludeFromList);
  }
  return entities.records;
});

const emits = defineEmits<{
  (e: "update:modelValue"): void;
  (e: "selected", t: EntityModel): void;
}>();

const showModal = useVModel(props, "modelValue", emits);

const FormSchema = z.object({
  code: z.string().trim().optional(),
  name: z.string().trim().optional(),
});

type FormModel = z.infer<typeof FormSchema>;

const { handleSubmit, defineField, isSubmitting, handleReset, resetForm, submitCount } = useForm<FormModel>({
  initialValues: props.filter,
  validationSchema: toTypedSchema(FormSchema),
});
const [code] = defineField("code");
const [name] = defineField("name");

const onClose = () => {
  showModal.value = false;
};

async function submit(values: EntityFilterModel) {
  loading.value = true;
  const res = await useApiResponseHandler(() => getEntitiesList(values));

  if (res) {
    Object.assign(entities, res);
  }
  loading.value = false;
}

const onConfirm = handleSubmit(submit);

// #145840 start search on open if isn't ADMIN
watch(showModal, async (show) => {
  if (show && canWrite && !isAdmin) {
    await submit({});
  }
});

const onLoadMore = async () => {
  loading.value = true;
  const res = await useApiResponseHandler(() =>
    getEntitiesList({
      history: false,
      name: name.value,
      code: code.value,
      next_key: entities.nextKey ?? undefined,
    }),
  );

  if (res && typeof res !== "boolean") {
    entities.count = res.count;
    entities.nextKey = res.nextKey;
    entities.records = [...entities.records, ...res.records];
  }
  loading.value = false;
};

const onSelected = (entity: EntityModel) => {
  showModal.value = false;
  emits("selected", entity);
};

const clear = () => {
  Object.assign(entities, {
    count: 0,
    nextKey: null,
    records: [],
  });
  resetForm({
    values: {
      name: undefined,
      code: undefined,
    },
  });
};
</script>

<template>
  <BiModal
    v-model="showModal"
    class="parties-acl__modal parties-acl__search-group-modal modal-sheets"
    :title="t(`${moduleId}.group.default`)"
    size="xl"
    @hidden-modal="clear"
    extra-footer-class="justify-content-center"
  >
    <template #body>
      <form class="parties-acl__search-group-form d-flex g-3 flex-wrap" @submit.prevent="onConfirm" @reset.prevent="handleReset" autocomplete="off">
        <div class="flex-grow-1 align-self-end">
          <BiInput
            v-model="code"
            :label="t(`${moduleId}.group.search.group_code`)"
            :placeholder="t(`${moduleId}.group.search.insert_code`)"
            :default-return-if-not-value="'undefined'"
          />
        </div>
        <div class="flex-grow-1 align-self-end">
          <BiInput
            v-model="name"
            :label="t(`${moduleId}.group.search.denomination`)"
            :placeholder="t(`${moduleId}.group.search.insert_denomination`)"
            :default-return-if-not-value="'undefined'"
          />
        </div>
        <div class="align-self-end d-flex g-2">
          <BiButton type="reset" :is-disabled="isSubmitting" class="me-2" color="secondary" is-outlined>
            {{ t(`${moduleId}.general.cancel`) }}
          </BiButton>
          <BiButton type="submit" :is-disabled="isSubmitting" color="success" @click="onConfirm">
            {{ t(`${moduleId}.general.search`) }}
          </BiButton>
        </div>
      </form>

      <EntityList
        v-if="filteredEntities.length"
        :entity-list="filteredEntities"
        :show-load-more="!!entities.nextKey"
        :loading="loading"
        @load-more="onLoadMore"
        @selected="onSelected"
      />
      <BiAlert class="mt-4" v-if="submitCount > 0 && !loading && !filteredEntities.length" is-info :title="t(`${moduleId}.general.warning`)">
        <template #body>{{ t(`${moduleId}.party.search.errors.not_found`) }}</template>
      </BiAlert>
    </template>
    <template #footer>
      <div class="col-md-12 d-flex justify-content-center">
        <BiButton :is-disabled="isSubmitting" color="secondary" is-outlined @click="onClose">
          {{ t(`${moduleId}.general.close`) }}
        </BiButton>
      </div>
    </template>
  </BiModal>
</template>

<style lang="scss">
.parties-acl {
  &__search-group-form {
    gap: var(--bs-gutter-x) var(--bs-gutter-y);
  }
}
</style>
