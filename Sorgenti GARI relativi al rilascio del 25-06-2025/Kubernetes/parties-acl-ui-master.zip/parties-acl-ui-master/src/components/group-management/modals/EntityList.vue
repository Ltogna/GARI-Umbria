<script setup lang="ts">
import LoadMoreRow from "@/components/common/LoadMoreRow.vue";
import useModuleId from "@/composables/useModuleId";
import type { EntityModel } from "@/models/entities";
import BiIcon from "@abaco/bootstrap-italia-components/src/components/BiIcon/BiIcon.vue";
import BiTable from "@abaco/bootstrap-italia-components/src/components/BiTable/BiTable.vue";
import BiHiddenContent from "@abaco/bootstrap-italia-components/src/components/BiHiddenContent/BiHiddenContent.vue";
import { useI18n } from "vue-i18n";

withDefaults(
  defineProps<{
    entityList: EntityModel[];
    showLoadMore?: boolean;
    loading?: boolean;
  }>(),
  { showLoadMore: false, loading: false },
);
const emit = defineEmits<{
  (e: "load-more"): void;
  (e: "selected", t: EntityModel): void;
}>();

const { t } = useI18n();
const moduleId = useModuleId();

function loadMore() {
  emit("load-more");
}
function onSelectEntity(entity: EntityModel) {
  emit("selected", entity);
}
</script>
<template>
  <BiTable is-row-hover is-custom responsive-breakpoint="md" is-header-light class="parties-acl__modal-table fixed-table mt-3">
    <template #head>
      <tr>
        <th>
          {{ t(`${moduleId}.group.search.group_code`) }}
        </th>
        <th>{{ t(`${moduleId}.group.denomination`) }}</th>
        <th>
          <BiHiddenContent :text="t(`${moduleId}.general.select`)"></BiHiddenContent>
        </th>
      </tr>
    </template>
    <template #body>
      <tr v-for="entity in entityList" :key="entity.id">
        <td :data-label="t(`${moduleId}.group.group_code`)">
          {{ entity.code }}
        </td>
        <td :data-label="t(`${moduleId}.group.denomination`)">
          {{ entity.name }}
        </td>
        <td class="table-actions text-center">
          <a type="button" class="text-decoration-none" href="#" @click.prevent="onSelectEntity(entity)">
            {{ t(`${moduleId}.general.select`) }}
            <BiIcon icon="arrow-right"></BiIcon>
          </a>
        </td>
      </tr>
      <LoadMoreRow :is-loading="loading" :is-visible="showLoadMore" @load:more="loadMore"></LoadMoreRow>
    </template>
  </BiTable>
</template>
