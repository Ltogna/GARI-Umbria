<script setup lang="ts">
import LoadMoreRow from "@/components/common/LoadMoreRow.vue";
import useModuleId from "@/composables/useModuleId";
import type { PartySchema } from "@/models/parties";
import { getPartyDenomination } from "@/utils/partyDenomination";
import BiIcon from "@abaco/bootstrap-italia-components/src/components/BiIcon/BiIcon.vue";
import BiTable from "@abaco/bootstrap-italia-components/src/components/BiTable/BiTable.vue";
import BiHiddenContent from "@abaco/bootstrap-italia-components/src/components/BiHiddenContent/BiHiddenContent.vue";
import { useI18n } from "vue-i18n";

withDefaults(
  defineProps<{
    partyList: PartySchema[];
    showLoadMore?: boolean;
    loading?: boolean;
  }>(),
  { showLoadMore: false, loading: false },
);
const emit = defineEmits<{
  (e: "load-more"): void;
  (e: "selected", t: PartySchema): void;
}>();

const { t } = useI18n();
const moduleId = useModuleId();

function loadMore() {
  emit("load-more");
}
function onSelectParty(party: PartySchema) {
  emit("selected", party);
}
</script>
<template>
  <BiTable is-row-hover is-custom responsive-breakpoint="md" is-header-light class="parties-acl__modal-table fixed-table mt-3">
    <template #head>
      <tr>
        <th>
          {{ t(`${moduleId}.party.list.fields.last_name`) }}
        </th>
        <th>{{ t(`${moduleId}.cuaa`) }}</th>
        <th>
          <BiHiddenContent :text="t(`${moduleId}.general.select`)"></BiHiddenContent>
        </th>
      </tr>
    </template>
    <template #body>
      <tr v-for="party in partyList" :key="party.id">
        <td :data-label="t(`${moduleId}.party.list.fields.last_name`)">
          {{ getPartyDenomination(party) }}
        </td>
        <td :data-label="t(`${moduleId}.cuaa`)">
          {{ party.code }}
        </td>
        <td class="table-actions text-center">
          <a type="button" class="text-decoration-none" href="#" @click.prevent="onSelectParty(party)">
            {{ t(`${moduleId}.general.select`) }}
            <BiIcon icon="arrow-right"></BiIcon>
          </a>
        </td>
      </tr>
      <LoadMoreRow :is-loading="loading" :is-visible="showLoadMore" @load:more="loadMore"></LoadMoreRow>
    </template>
  </BiTable>
</template>
