<script setup lang="ts">
import useGroupId from "@/composables/useGroupId";
import useModuleId from "@/composables/useModuleId";
import { useUserStore } from "@/stores/user";
import BiButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiButton.vue";
import BiModal from "@abaco/bootstrap-italia-components/src/components/BiModal/BiModal.vue";
import BiInput from "@abaco/bootstrap-italia-components/src/components/form/BiInput.vue";
import { useVModel } from "@vueuse/core";
import { ref, watch } from "vue";
import { useI18n } from "vue-i18n";

const moduleId = useModuleId();
const { t } = useI18n();
const { groupId } = useGroupId();

const props = defineProps<{
  modelValue: boolean;
}>();

const emits = defineEmits<{
  (e: "update:modelValue"): void;
}>();

const showModal = useVModel(props, "modelValue", emits);

const username = ref("");

const onClose = () => {
  showModal.value = false;
};

const userStore = useUserStore();

const onConfirm = async () => {
  userStore.setFilter({ username: username.value.trim() });
  await userStore.getGroupUsers(groupId.value);
  onClose();
};

watch(
  () => showModal.value,
  (isModalOpen) => {
    if (isModalOpen) {
      username.value = userStore.filter.username;
    }
  },
);
</script>

<template>
  <BiModal class="parties-acl__modal" v-model="showModal" :title="t(`${moduleId}.group.search.search_user`)" size="lg">
    <template #body>
      <form @submit.prevent="onConfirm">
        <BiInput type="search" class="my-5" :placeholder="t(`${moduleId}.group.search.search_username`)" v-model="username">
          <template #label>
            <span class="visually-hidden">{{ t(`${moduleId}.group.search.search_username`) }} </span>
          </template>
        </BiInput>
        <input type="submit" class="invisible" :aria-label="t(`${moduleId}.general.save`)" />
      </form>
    </template>
    <template #footer>
      <div class="col-md-12 d-flex justify-content-center">
        <BiButton class="me-3" color="secondary" is-outlined @click="onClose">
          {{ t(`${moduleId}.general.cancel`) }}
        </BiButton>
        <BiButton color="success" @click="onConfirm">
          {{ t(`${moduleId}.general.select`) }}
        </BiButton>
      </div>
    </template>
  </BiModal>
</template>
