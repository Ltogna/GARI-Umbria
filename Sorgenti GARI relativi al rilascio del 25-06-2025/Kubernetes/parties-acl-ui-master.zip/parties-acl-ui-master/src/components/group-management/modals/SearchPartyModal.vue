<script setup lang="ts">
import useModuleId from "@/composables/useModuleId";
import BiButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiButton.vue";
import BiModal from "@abaco/bootstrap-italia-components/src/components/BiModal/BiModal.vue";
import { useI18n } from "vue-i18n";
import { useVModel } from "@vueuse/core";
import PartySearchForm from "@/components/party-search-form/PartySearchForm.vue";
import { usePartyList } from "@/composables/usePartyList";
import type { PartyFilterSchema, PartySchema } from "@/models/parties";
import { useApiResponseHandler } from "@/composables/useApiResponseHandler";
import { getParties } from "@/resources/api/parties";
import { computed, ref } from "vue";
import PartyList from "./PartyList.vue";

const moduleId = useModuleId();
const { loading, page, search, resetPage, setPageValues, updatePageValues, setSearchValues, resetAll } = usePartyList();
const { t } = useI18n();
const formRef = ref<InstanceType<typeof PartySearchForm>>();

const partyList = computed(() => page.records);
const nextKey = computed(() => page.nextKey || undefined);

const props = defineProps<{
  modelValue: boolean;
}>();

const emits = defineEmits<{
  (e: "update:modelValue"): void;
  (e: "selected", t: PartySchema): void;
}>();

const showModal = useVModel(props, "modelValue", emits);

const onClose = () => {
  showModal.value = false;
};

// const onConfirm = () => {
//   console.log("confirm");
//   onClose();
// };

async function onSearch(searchForm: Partial<PartyFilterSchema>) {
  resetPage();
  setSearchValues(searchForm as PartyFilterSchema);
  loading.value = true;
  const res = await useApiResponseHandler(() => getParties(search as PartyFilterSchema));
  if (res && typeof res !== "boolean") {
    setPageValues(res);
  }
  loading.value = false;
}

async function onLoadMore() {
  loading.value = true;
  const res = await useApiResponseHandler(() => getParties({ ...search, nextKey: nextKey.value } as PartyFilterSchema));
  if (res && typeof res !== "boolean") {
    updatePageValues(res);
  }
  loading.value = false;
}
function onPartySelected(party: PartySchema) {
  onClose();
  emits("selected", party);
}
const clear = () => {
  formRef.value?.clearForm();
  resetAll();
};
</script>

<template>
  <BiModal
    v-model="showModal"
    @hidden-modal="clear"
    class="parties-acl__modal"
    :title="t(`${moduleId}.group.search.search_subject`)"
    size="xl"
    extra-footer-class="justify-content-center"
  >
    <template #body>
      <PartySearchForm ref="formRef" @search="onSearch" inline />
      <template v-if="partyList.length !== 0">
        <PartyList
          class="mt-3"
          :party-list="partyList"
          :show-load-more="!!nextKey"
          @load-more="onLoadMore()"
          :loading="loading"
          @selected="onPartySelected"
        ></PartyList>
      </template>
    </template>
    <template #footer>
      <div class="col-md-12 d-flex justify-content-center">
        <BiButton color="secondary" is-outlined @click="onClose">
          {{ t(`${moduleId}.general.close`) }}
        </BiButton>
      </div>
    </template>
  </BiModal>
</template>
