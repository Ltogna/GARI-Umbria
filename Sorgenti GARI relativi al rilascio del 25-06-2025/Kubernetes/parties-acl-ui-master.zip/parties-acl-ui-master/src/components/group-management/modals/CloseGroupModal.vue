<script setup lang="ts">
import useModuleId from "@/composables/useModuleId";
import { useGroupStore } from "@/stores/group";
import BiAlert from "@abaco/bootstrap-italia-components/src/components/BiAlert/BiAlert.vue";
import BiButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiButton.vue";
import BiModal from "@abaco/bootstrap-italia-components/src/components/BiModal/BiModal.vue";
import { useVModel } from "@vueuse/core";
import { computed } from "vue";
import { useI18n } from "vue-i18n";

const moduleId = useModuleId();
const { t } = useI18n();

const props = defineProps<{
  modelValue: boolean;
  canDelete: boolean;
}>();

const emits = defineEmits<{
  (e: "update:modelValue"): void;
  (e: "confirmed"): void;
  (e: "update:canDelete", t: boolean): void;
  (e: "hiddenModal"): void;
}>();

const showModal = useVModel(props, "modelValue", emits);

const text = computed(() => (props.canDelete ? t(`${moduleId}.group.close.can`) : t(`${moduleId}.group.close.cant`)));

const onCancel = () => {
  showModal.value = false;
};

const groupStore = useGroupStore();
const onConfirm = async () => {
  emits("confirmed");
};
function onHiddenModal() {
  emits("hiddenModal");
  groupStore.hasError = false;
}
</script>

<template>
  <BiModal class="parties-acl__modal" v-model="showModal" :title="t(`${moduleId}.general.warning`)" @hiddenModal="onHiddenModal">
    <template #body>
      <BiAlert
        v-if="groupStore.hasError && canDelete && !groupStore.isLoading"
        :is-error="groupStore.hasError"
        :title="t(`${moduleId}.apiErrors.title`)"
      ></BiAlert>
      {{ text }}
    </template>

    <template #footer>
      <div class="col-md-12 d-flex justify-content-center">
        <BiButton v-if="canDelete" color="danger" class="btn-me" @click="onConfirm">
          {{ t(`${moduleId}.general.close`) }}
        </BiButton>
        <BiButton color="secondary" is-outlined @click="onCancel">
          {{ t(`${moduleId}.general.cancel`) }}
        </BiButton>
      </div>
    </template>
  </BiModal>
</template>
