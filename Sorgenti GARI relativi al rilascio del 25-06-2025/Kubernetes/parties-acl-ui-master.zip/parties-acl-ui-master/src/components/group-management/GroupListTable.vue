<script setup lang="ts">
import useModuleId from "@/composables/useModuleId";
import { RouteName } from "@/models/routes";
import { useGroupStore } from "@/stores/group";
import BiIconButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiIconButton.vue";
import BiTable from "@abaco/bootstrap-italia-components/src/components/BiTable/BiTable.vue";
import BiHiddenContent from "@abaco/bootstrap-italia-components/src/components/BiHiddenContent/BiHiddenContent.vue";
import { useI18n } from "vue-i18n";
import { useRouter } from "vue-router";
import LoadMore from "../common/LoadMore.vue";
import BiIcon from "@abaco/bootstrap-italia-components/src/components/BiIcon/BiIcon.vue";

const moduleId = useModuleId();
const { t } = useI18n();
const router = useRouter();

const groupStore = useGroupStore();

const gotoGroup = (groupId: number) => {
  router.push({ name: RouteName.GROUP_DETAILS, params: { groupId } });
};

const getUsersList = (users?: string[] | null) => {
  return users ? users.join(", ") : "-";
};

function loadMore() {
  groupStore.getGroupsList(true);
}
</script>

<template>
  <BiTable is-custom responsive-breakpoint="md" is-row-hover is-header-light>
    <template #head>
      <tr>
        <th>{{ t(`${moduleId}.group.group_code`) }}</th>
        <th>{{ t(`${moduleId}.group.denomination`) }}</th>
        <th>User Admin</th>
        <th v-if="groupStore.filter.history">{{ t(`${moduleId}.group.expired`) }}</th>
        <th>
          <BiHiddenContent :text="t(`${moduleId}.group.goto_details`)"></BiHiddenContent>
        </th>
      </tr>
    </template>
    <template #body>
      <tr v-for="group in groupStore.groupList" :key="group.id">
        <td :data-label="t(`${moduleId}.group.group_code`)">{{ group.code }}</td>
        <td :data-label="t(`${moduleId}.group.denomination`)">{{ group.name }}</td>
        <td data-label="User Admin">{{ getUsersList(group.admin_users) }}</td>
        <td :data-label="t(`${moduleId}.group.expired`)" v-if="groupStore.filter.history">
          <BiIcon v-if="group.closed" icon="check" :aria-label="t(`${moduleId}.general.closed`)" />
        </td>
        <td>
          <BiIconButton
            icon="arrow-right"
            :width="35"
            is-outlined
            color="secondary"
            :title="t(`${moduleId}.group.goto_details`)"
            @click="gotoGroup(group.id)"
          />
        </td>
      </tr>
    </template>
  </BiTable>

  <LoadMore :is-visible="!!groupStore.nextKey" @load:more="loadMore"></LoadMore>
</template>
