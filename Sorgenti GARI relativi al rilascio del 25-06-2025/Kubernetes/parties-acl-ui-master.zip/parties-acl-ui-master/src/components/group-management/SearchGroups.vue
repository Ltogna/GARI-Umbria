<script setup lang="ts">
import useModuleId from "@/composables/useModuleId";
import { DEFAULT_GROUP_FILTER } from "@/models/defaultValues";
import { type EntityFilterModel } from "@/models/entities";
import { RouteName } from "@/models/routes";
import { useGroupStore } from "@/stores/group";
import BiAlert from "@abaco/bootstrap-italia-components/src/components/BiAlert/BiAlert.vue";
import BiButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiButton.vue";
import BiCheckbox from "@abaco/bootstrap-italia-components/src/components/form/BiCheckbox.vue";
import BiInput from "@abaco/bootstrap-italia-components/src/components/form/BiInput.vue";
import useColors from "@abaco/bootstrap-italia-components/src/composables/useColors";
import { watchImmediate } from "@vueuse/core";
import { computed, reactive, ref } from "vue";
import { useI18n } from "vue-i18n";
import { useRouter } from "vue-router";

const moduleId = useModuleId();
const { t } = useI18n();
const groupStore = useGroupStore();
const router = useRouter();
const { getColor } = useColors();

const filter = reactive<EntityFilterModel>(structuredClone(DEFAULT_GROUP_FILTER));

watchImmediate(
  () => groupStore.filter,
  (groupFilter) => {
    Object.assign(filter, groupFilter);
  },
);

const hasSearched = ref(false);
const onSearch = async () => {
  groupStore.setFilter(filter);
  await groupStore.getGroupsList();

  if (groupStore.count > 0 && !groupStore.hasError) {
    hasSearched.value = false;
    router.push({
      name: RouteName.GROUP_LIST,
    });
  } else {
    hasSearched.value = true;
  }
};

const onReset = () => {
  hasSearched.value = false;
  Object.assign(filter, structuredClone(DEFAULT_GROUP_FILTER));
};

const showAlert = computed(() => hasSearched.value && groupStore.groupList.length === 0);
</script>

<template>
  <form @submit.prevent="onSearch" @reset.prevent="onReset">
    <div class="row">
      <div class="col-md-6">
        <BiInput type="search" :label="t(`${moduleId}.group.search.group_code`)" v-model.trim="filter.code"></BiInput>
      </div>
      <div class="col-md-6">
        <BiInput type="search" :label="t(`${moduleId}.group.denomination`)" v-model.trim="filter.name"></BiInput>
      </div>
    </div>
    <div class="row justify-content-end">
      <div class="col-md-6">
        <BiCheckbox :label="t(`${moduleId}.group.includes_archived`)" v-model="filter.history"></BiCheckbox>
      </div>
    </div>
    <div class="row">
      <div class="col-md-12 form-group d-flex justify-content-center">
        <BiButton type="reset" is-outlined class="btn-me" size="lg" :class="`${getColor('button', 'secondary', 'outline')} btn`">
          {{ t(`${moduleId}.general.cancel`) }}
        </BiButton>
        <BiButton type="submit" size="lg" class="ms-2 btn" :class="getColor('button', 'success')">
          {{ t(`${moduleId}.general.search`) }}
        </BiButton>
      </div>
    </div>
  </form>

  <BiAlert v-if="showAlert" variant="info">
    <template #body>{{ t(`${moduleId}.group.search.errors.not_found`) }}</template>
  </BiAlert>
</template>
