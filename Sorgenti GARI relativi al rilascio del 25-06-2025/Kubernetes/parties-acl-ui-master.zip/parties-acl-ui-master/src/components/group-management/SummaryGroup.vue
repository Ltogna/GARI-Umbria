<script setup lang="ts">
import useModuleId from "@/composables/useModuleId";
import useUserDateFormat from "@/composables/useUserDateFormat";
import { useGroupStore } from "@/stores/group";
import { format } from "date-fns";
import { computed } from "vue";
import { useI18n } from "vue-i18n";
// import { INFINITE_DATE } from "@/constants";
// import { DATE_FORMAT } from "@/utils/dates";

const moduleId = useModuleId();
const { t } = useI18n();
const userDateFormat = useUserDateFormat();
const groupStore = useGroupStore();

const groupDetails = computed(() => groupStore.selectedGroup);

// const endDate = computed(() => {
//   if (groupDetails.value && groupDetails.value.day_to) {
//     return format(groupDetails.value.day_to, DATE_FORMAT) !== INFINITE_DATE ? format(groupDetails.value.day_to, userDateFormat) : "-";
//   }
//   return "-";
// });
</script>

<template>
  <div class="row">
    <div class="col-md-4">
      <strong>{{ t(`${moduleId}.group.group_code`) }}: </strong>
      {{ groupDetails?.code }}
    </div>
  </div>
  <div class="row">
    <div class="col-md-4">
      <strong>{{ t(`${moduleId}.group.denomination`) }}: </strong>
      {{ groupDetails?.name }}
    </div>
  </div>
  <div class="row">
    <div class="col-md-4">
      <strong>{{ t(`${moduleId}.group.type`) }}: </strong>
      {{ groupDetails?.entity_type.description }}
    </div>
  </div>
  <div class="row">
    <div class="col-md-4">
      <strong>{{ t(`${moduleId}.group.start_date`) }}: </strong>
      <span v-if="groupDetails?.day_from">{{ format(groupDetails.day_from, userDateFormat) }}</span>
    </div>
  </div>
  <!-- <div class="row">
    <div class="col-md-4">
      <strong>{{ t(`${moduleId}.group.end_date`) }}: </strong>
      <span v-if="groupDetails?.day_from">{{ endDate }}</span>
    </div>
  </div> -->
</template>
