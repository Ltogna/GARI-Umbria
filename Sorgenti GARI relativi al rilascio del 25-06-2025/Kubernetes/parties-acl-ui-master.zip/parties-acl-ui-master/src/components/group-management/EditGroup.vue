<script setup lang="ts">
import SearchPartyModal from "@/components/group-management/modals/SearchPartyModal.vue";
import { useApiResponseHandler, useNotification } from "@/composables/useApiResponseHandler";
import useCanEditGroup from "@/composables/useCanEditGroup";
import useEmitter from "@/composables/useEmitter";
import useModuleId from "@/composables/useModuleId";
import useUserDateFormat from "@/composables/useUserDateFormat";
import { INFINITE_DATE } from "@/constants";
import type { UpdateEntityPayloadModel } from "@/models/entities";
import type { PartySchema } from "@/models/parties";
import { updateEntity } from "@/resources/api/entities";
import { useGroupStore } from "@/stores/group";
import { DATE_FORMAT } from "@/utils/dates";
import { getPartyDenomination } from "@/utils/partyDenomination";
import BiButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiButton.vue";
import BiTextarea from "@abaco/bootstrap-italia-components/src/components/form/BiTextarea.vue";
import BiInput from "@abaco/bootstrap-italia-components/src/components/form/BiInput.vue";
import { toTypedSchema } from "@vee-validate/zod";
import { format } from "date-fns";
import { useForm } from "vee-validate";
import { computed, ref, watch } from "vue";
import { useI18n } from "vue-i18n";
import z from "zod";

const moduleId = useModuleId();
const { t } = useI18n();
const userDateFormat = useUserDateFormat();
const groupStore = useGroupStore();
const emitter = useEmitter();
const { canEditGroup } = useCanEditGroup();

const FormSchema = z.object({
  denomination: z
    .string({
      required_error: t(`${moduleId}.general.mandatory_field`),
    })
    .trim()
    .min(1, t(`${moduleId}.general.mandatory_field`)),
  description: z
    .string({
      required_error: t(`${moduleId}.general.mandatory_field`),
    })
    .trim(),
  registry_party_id: z.union([
    z
      .string({
        required_error: t(`${moduleId}.general.mandatory_field`),
      })
      .trim(),
    z.number({
      required_error: t(`${moduleId}.general.mandatory_field`),
    }),
    z.null({
      required_error: t(`${moduleId}.general.mandatory_field`),
    }),
  ]),
});
z.union([z.string(), z.number()]);
type FormModel = z.infer<typeof FormSchema>;

const groupDetails = computed(() => groupStore.selectedGroup);
const { handleSubmit, defineField, handleReset, meta, resetForm, errors } = useForm<FormModel>({
  validationSchema: toTypedSchema(FormSchema),
  initialValues: {
    description: groupDetails.value?.description ?? "",
    denomination: groupDetails.value?.name ?? "",
    registry_party_id: groupDetails.value?.registry_party_id ?? null,
  },
});
const [description] = defineField("description");
const [denomination] = defineField("denomination");
const [registryPartyId] = defineField("registry_party_id");

const showModal = ref(false);
const onShowModal = () => {
  showModal.value = true;
};

watch(
  () => meta.value.dirty,
  (isDirty) => {
    emitter.emit("is:dirty", isDirty);
  },
);

function onPartySelected(party: PartySchema) {
  registryPartyId.value = party.id;
  denomination.value = getPartyDenomination(party);
}

const onSubmit = handleSubmit(async (values) => {
  const groupDetail = groupDetails.value;
  if (groupDetail) {
    const details: UpdateEntityPayloadModel = {
      name: !values.registry_party_id ? values.denomination : undefined,
      description: values.description,
      registry_party_id: !groupDetail.registry_party_id ? (values.registry_party_id ?? undefined) : undefined,
    };
    const resp = await useApiResponseHandler(() => updateEntity(groupDetail.id, details));
    if (resp === true) {
      await groupStore.getGroupDetails(groupDetail.id);
      resetForm({
        values: {
          description: groupDetails.value?.description ?? "",
          denomination: groupDetails.value?.name,
          registry_party_id: groupDetails.value?.registry_party_id ?? null,
        },
      });
      useNotification().showSuccessNotification();
      return true;
    }

    return false;
  }
});

const closeDateIsInfinite = computed(() => {
  if (groupDetails.value && groupDetails.value.close_day) {
    return format(groupDetails.value.close_day, DATE_FORMAT) === INFINITE_DATE;
  }
  return true;
});
const endDate = computed(() => {
  if (groupDetails.value && groupDetails.value.close_day) {
    return !closeDateIsInfinite.value ? format(groupDetails.value.close_day, userDateFormat) : "-";
  }
  return "-";
});

function clearParty() {
  registryPartyId.value = null;
  denomination.value = "";
}
</script>

<template>
  <template v-if="canEditGroup">
    <form @submit.prevent="onSubmit" @reset.prevent="handleReset" class="parties-acl__form">
      <div class="row g-2">
        <div class="col-lg-4 col-md-6">
          <BiInput readonly type="text" :model-value="groupDetails?.code?.trim() ?? ''" :label="t(`${moduleId}.group.group_code`)"></BiInput>
        </div>
        <div class="w-100" />
        <div class="col-lg-4 col-md-6 field-required">
          <BiInput
            :readonly="!!registryPartyId"
            type="text"
            v-model="denomination"
            :label="t(`${moduleId}.group.search.denomination`)"
            :errors="errors.denomination ? [errors.denomination] : []"
          ></BiInput>
        </div>
        <div class="col-lg-4 col-md-4">
          <BiButton v-if="!groupDetails?.registry_party_id" color="secondary" class="btn-me" is-outlined @click="onShowModal">
            {{ t(`${moduleId}.group.search_registry`) }}
          </BiButton>
          <BiButton v-if="!!registryPartyId && !groupDetails?.registry_party_id" color="danger" is-outlined @click="clearParty">
            {{ t(`${moduleId}.group.empty_registry`) }}
          </BiButton>
        </div>
        <div class="w-100" />
        <div class="col-lg-4 col-md-6 field-required">
          <BiInput readonly type="text" :model-value="groupDetails?.entity_type.description.trim()" :label="t(`${moduleId}.group.type`)"></BiInput>
        </div>
        <div class="w-100" />
        <div class="col-lg-4 col-md-6 field-required">
          <BiInput
            v-if="groupDetails?.day_from"
            readonly
            type="text"
            :model-value="format(groupDetails.day_from, userDateFormat)"
            :label="t(`${moduleId}.group.start_date`)"
          ></BiInput>
        </div>
        <div class="w-100" />
        <div v-if="!closeDateIsInfinite" class="col-lg-4 col-md-6">
          <BiInput v-if="groupDetails?.day_from" readonly type="text" :model-value="endDate" :label="t(`${moduleId}.group.end_date`)"></BiInput>
        </div>
        <div class="w-100" />
        <div class="col-lg-4 col-md-6">
          <BiTextarea :label="t(`${moduleId}.group.description`)" v-model="description"></BiTextarea>
        </div>
      </div>
      <div class="row mt-3">
        <div class="col">
          <BiButton :is-disabled="!meta.dirty || !meta.valid" class="btn-me" color="success" type="submit">
            {{ t(`${moduleId}.general.save_changes`) }}
          </BiButton>
          <BiButton :is-disabled="!meta.dirty" color="secondary" is-outlined type="reset">
            {{ t(`${moduleId}.general.cancel`) }}
          </BiButton>
        </div>
      </div>
    </form>

    <SearchPartyModal v-model="showModal" @selected="onPartySelected" />
  </template>
  <template v-else>
    <div class="row">
      <div class="col-lg-4 col-md-6">
        <strong>{{ t(`${moduleId}.group.group_code`) }}:</strong>
        {{ groupDetails?.code }}
      </div>
      <div class="w-100" />
      <div class="col-lg-4 col-md-6">
        <strong>{{ t(`${moduleId}.group.denomination`) }}:</strong>
        {{ denomination }}
      </div>
      <div class="w-100" />
      <div class="col-lg-4 col-md-6">
        <strong>{{ t(`${moduleId}.group.type`) }}:</strong>
        {{ groupDetails?.entity_type.description }}
      </div>
      <div class="w-100" />
      <div v-if="groupDetails" class="col-lg-4 col-md-6">
        <strong>{{ t(`${moduleId}.group.start_date`) }}:</strong>
        {{ format(groupDetails.day_from, userDateFormat) }}
      </div>
      <div class="w-100" />
      <div v-if="groupDetails && !closeDateIsInfinite" class="col-lg-4 col-md-6">
        <strong>{{ t(`${moduleId}.group.end_date`) }}:</strong>
        {{ endDate }}
      </div>
      <div class="w-100" />
      <div class="col-lg-4 col-md-6 d-flex">
        <strong class="me-1">{{ t(`${moduleId}.group.description`) }}:</strong>
        <span class="text-pre-wrap">
          {{ description }}
        </span>
      </div>
    </div>
  </template>
</template>

<style lang="scss" scoped>
.text-pre-wrap {
  white-space: pre-wrap;
}
</style>
