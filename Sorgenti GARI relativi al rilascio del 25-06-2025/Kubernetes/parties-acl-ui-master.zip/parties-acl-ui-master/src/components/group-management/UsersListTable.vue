<script setup lang="ts">
import { useApiResponseHandler, useNotification } from "@/composables/useApiResponseHandler";
import useCanEditGroup from "@/composables/useCanEditGroup";
import useEmitter from "@/composables/useEmitter";
import useGroupId from "@/composables/useGroupId";
import useModuleId from "@/composables/useModuleId";
import BiHiddenContent from "@abaco/bootstrap-italia-components/src/components/BiHiddenContent/BiHiddenContent.vue";
import type { UserModel } from "@/models/entities";
import { useUserStore } from "@/stores/user";
import BiAlert from "@abaco/bootstrap-italia-components/src/components/BiAlert/BiAlert.vue";
import BiIconButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiIconButton.vue";
import BiChip from "@abaco/bootstrap-italia-components/src/components/BiChip/BiChip.vue";
import BiIcon from "@abaco/bootstrap-italia-components/src/components/BiIcon/BiIcon.vue";
import BiTable from "@abaco/bootstrap-italia-components/src/components/BiTable/BiTable.vue";
import { onMounted, ref } from "vue";
import { useI18n } from "vue-i18n";
import GenericDeleteModal from "../common/GenericDeleteModal.vue";
import LoadMore from "../common/LoadMore.vue";
import { deleteUserFromEntity } from "@/resources/api/mandates";

const moduleId = useModuleId();
const { t } = useI18n();
const userStore = useUserStore();
const { groupId } = useGroupId();
const emitter = useEmitter();
const { canEditGroup } = useCanEditGroup();

const { showSuccessNotification } = useNotification();

onMounted(async () => {
  await userStore.getGroupUsers(groupId.value);
});

const onDeleteUser = async () => {
  if (!userIdToDelete.value) {
    console.warn("No user selected");
    return;
  }

  const isDeleteSuccesfull = await useApiResponseHandler(() => deleteUserFromEntity(groupId.value, userIdToDelete.value));
  if (isDeleteSuccesfull) {
    showSuccessNotification();
    await userStore.getGroupUsers(groupId.value);
  }
  showDeleteModal.value = false;
};

const showEditModal = (user: UserModel) => {
  emitter.emit("show:modal:user:edit", user);
};

const onResetSearch = async () => {
  userStore.resetFilter();
  await userStore.getGroupUsers(groupId.value);
};

const showDeleteModal = ref(false);
const userIdToDelete = ref("");

const setUserToDelete = (userId: string) => {
  userIdToDelete.value = userId;
  showDeleteModal.value = true;
};
</script>

<template>
  <BiChip v-show="userStore.filter.username" is-delete :label="userStore.filter.username" @click="onResetSearch" />
  <BiTable is-row-hover is-custom responsive-breakpoint="md" is-header-light class="mb-0" extra-table-classes="table-head-bg">
    <template #head>
      <tr>
        <th>
          {{ t(`${moduleId}.group.user.username`) }}
        </th>
        <th>
          {{ t(`${moduleId}.group.description`) }}
        </th>
        <th>
          {{ t(`${moduleId}.general.admin`, 1) }}
        </th>
        <th v-if="canEditGroup">
          <BiHiddenContent :text="t(`${moduleId}.general.action`, 2)"></BiHiddenContent>
        </th>
      </tr>
    </template>
    <template #body>
      <tr v-for="user in userStore.selectedGroupUsers" :key="user.id">
        <td :data-label="t(`${moduleId}.group.user.username`)">
          {{ user.username }}
        </td>
        <td :data-label="t(`${moduleId}.group.description`)">
          {{ user.description || "-" }}
        </td>
        <td :data-label="t(`${moduleId}.general.admin`, 1)">
          <BiIcon v-if="user.role === 'ADMIN'" icon="check" :aria-label="user.role" />
        </td>
        <td v-if="canEditGroup">
          <div class="d-flex flex-nowrap justify-content-end">
            <BiIconButton
              class="me-2"
              is-outlined
              icon="pencil"
              icon-style="fas"
              color="secondary"
              :width="35"
              :title="t(`${moduleId}.general.edit`)"
              @click="showEditModal(user)"
            />
            <BiIconButton
              is-outlined
              icon="trash-can"
              icon-style="fas"
              color="danger"
              :width="35"
              :title="t(`${moduleId}.general.delete`)"
              @click="setUserToDelete(user.id)"
            />
          </div>
        </td>
      </tr>
      <tr v-if="userStore.selectedGroupUsers.length === 0 && !userStore.isLoading">
        <td colspan="4">
          <BiAlert :title="t(`${moduleId}.party.search.errors.not_found`)"></BiAlert>
        </td>
      </tr>
    </template>
  </BiTable>
  <LoadMore :is-visible="!!userStore.nextKey" :is-loading="userStore.isLoading" @load:more="userStore.getGroupUsers(groupId, true)"></LoadMore>

  <GenericDeleteModal v-if="canEditGroup" v-model="showDeleteModal" @confirm:delete="onDeleteUser"></GenericDeleteModal>
</template>
