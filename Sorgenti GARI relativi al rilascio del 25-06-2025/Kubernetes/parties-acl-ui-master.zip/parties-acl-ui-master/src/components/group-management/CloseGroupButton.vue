<script setup lang="ts">
import useCanEditGroup from "@/composables/useCanEditGroup";
import useModuleId from "@/composables/useModuleId";
import { HttpErrorCode } from "@/models/errors";
import { RouteName } from "@/models/routes";
import { useGroupStore } from "@/stores/group";
import BiButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiButton.vue";
import { ref } from "vue";
import { useI18n } from "vue-i18n";
import { useRouter } from "vue-router";
import CloseGroupModal from "./modals/CloseGroupModal.vue";

const emits = defineEmits<{
  (e: "groupClosed", id: number): void;
}>();

const moduleId = useModuleId();
const { t } = useI18n();
const router = useRouter();
const groupStore = useGroupStore();
const { canEditGroup } = useCanEditGroup();

const showModal = ref(false);
const canDelete = ref(true);
let submitted = false;

async function onConfirm() {
  const response = await groupStore.closeGroup(new Date());
  if (response === HttpErrorCode.ENTITY_WITH_EXCLUSIVE_PARTY) {
    canDelete.value = false;
    return;
  }
  if (groupStore.hasError) {
    return;
  }
  showModal.value = false;
  submitted = true;
}

async function onModalClose() {
  if (submitted) {
    const groupId = groupStore.selectedGroup?.id ?? 0;
    emits("groupClosed", groupId);
    await groupStore.getGroupsList(false);
    router.push({ name: RouteName.GROUP_LIST });
    submitted = false;
  }
}
</script>

<template>
  <BiButton v-if="canEditGroup" color="danger" is-outlined class="btn-me" @click="showModal = true">
    {{ t(`${moduleId}.group.close.group`) }}
  </BiButton>
  <CloseGroupModal v-if="canEditGroup" @confirmed="onConfirm" v-model="showModal" :can-delete="canDelete" @hiddenModal="onModalClose" />
</template>
