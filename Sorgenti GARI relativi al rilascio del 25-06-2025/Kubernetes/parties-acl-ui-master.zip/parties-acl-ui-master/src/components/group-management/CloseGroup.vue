<script setup lang="ts">
import useCanEditGroup from "@/composables/useCanEditGroup";
import useModuleId from "@/composables/useModuleId";
import { HttpErrorCode } from "@/models/errors";
import { useGroupStore } from "@/stores/group";
import BiButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiButton.vue";
import BiDatepicker from "@abaco/bootstrap-italia-components/src/components/form/BiDatepicker.vue";
import { onBeforeMount, ref } from "vue";
import { useI18n } from "vue-i18n";
import { useRouter } from "vue-router";
import CloseGroupModal from "./modals/CloseGroupModal.vue";

const moduleId = useModuleId();
const { t } = useI18n();
const router = useRouter();
const groupStore = useGroupStore();
const { canEditGroup } = useCanEditGroup();

const endDate = ref(new Date());
const showModal = ref(false);
const canDelete = ref(true);
let submitted = false;

onBeforeMount(() => {
  submitted = false;
});

const onSubmit = () => {
  showModal.value = true;
};

const onReset = () => {
  endDate.value = new Date();
};

async function onConfirm() {
  const response = await groupStore.closeGroup(endDate.value);
  if (response === HttpErrorCode.ENTITY_WITH_EXCLUSIVE_PARTY) {
    canDelete.value = false;
    return;
  }
  if (groupStore.hasError) {
    return;
  }
  showModal.value = false;
  submitted = true;
}

async function onModalClose() {
  if (submitted) {
    router.go(0);
    submitted = false;
  }
}
</script>

<template>
  <form @submit.prevent="onSubmit" @reset.prevent="onReset">
    <div class="row">
      <div class="col-md-4">
        <strong>{{ t(`${moduleId}.group.close.date`) }}: </strong>
        <BiDatepicker :is-disabled="!canEditGroup" v-model="endDate" :min="new Date()" :default-date="new Date()"></BiDatepicker>
      </div>
    </div>
    <div v-if="canEditGroup" class="row mt-3">
      <div class="col-md-12 form-group d-flex">
        <BiButton type="submit" color="success" class="btn-me">
          {{ t(`${moduleId}.general.proceed`) }}
        </BiButton>
        <BiButton type="reset" color="secondary" is-outlined>
          {{ t(`${moduleId}.general.cancel`) }}
        </BiButton>
      </div>
    </div>
  </form>

  <CloseGroupModal
    v-if="canEditGroup"
    :closing-date="endDate"
    @confirmed="onConfirm"
    v-model="showModal"
    :can-delete="canDelete"
    @hiddenModal="onModalClose"
  />
</template>
