<script setup lang="ts">
import useCanEditGroup from "@/composables/useCanEditGroup";
import useGroupId from "@/composables/useGroupId";
import useModuleId from "@/composables/useModuleId";
import type { EntityModel, InfiniteListEntityModel } from "@/models/entities";
import { HttpErrorCode } from "@/models/errors";
import { addChildEntity, deleteChildEntity, getChildrenEntity } from "@/resources/api/entities";
import { useGroupStore } from "@/stores/group";
import BiAlert from "@abaco/bootstrap-italia-components/src/components/BiAlert/BiAlert.vue";
import BiButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiButton.vue";
import BiModal from "@abaco/bootstrap-italia-components/src/components/BiModal/BiModal.vue";
import BiProgressIndicator from "@abaco/bootstrap-italia-components/src/components/BiProgressIndicator/BiProgressIndicator.vue";
import BiTable from "@abaco/bootstrap-italia-components/src/components/BiTable/BiTable.vue";
import { ErrorType } from "@abaco/safe-rest/src/HTTPClient";
import { computed, onMounted, ref } from "vue";
import { useI18n } from "vue-i18n";
import GenericDeleteModal from "../common/GenericDeleteModal.vue";
import LoadMore from "../common/LoadMore.vue";
import SearchGroupModal from "./modals/SearchGroupModal.vue";
import { useApiResponseHandler, useNotification } from "@/composables/useApiResponseHandler";

const moduleId = useModuleId();
const { t } = useI18n();

const groupStore = useGroupStore();
const { canEditGroup } = useCanEditGroup();
const { groupId } = useGroupId();

const infiniteChildrenList = ref<InfiniteListEntityModel | null>(null);
const childrenList = ref<EntityModel[]>([]);
const nextKey = ref<string | null>(null);
const resetChildren = () => {
  infiniteChildrenList.value = null;
  childrenList.value = [];
  nextKey.value = null;
};

const groupParent = ref<EntityModel | null>(null);

const groupParentNameLabel = computed(() =>
  groupParent.value?.name ? groupParent.value?.name ?? "-" : groupStore.selectedGroup?.parent_name ?? "-",
);

const showModal = ref(false);
const showConfirmModal = ref(false);
const isLoading = ref(false);
const isError = ref(false);

const resetParent = async () => {
  isError.value = false;
  await fetchGroupParentDetails();
};

const canResetParent = computed(() => !!groupParent.value && groupStore.selectedGroup?.parent_id !== groupParent.value?.id);

const canSave = computed(() => {
  const idStore = groupStore.selectedGroup?.parent_id ?? null;
  const idLocal = groupParent.value?.id ?? null;
  if (!idLocal) {
    return false;
  } else {
    return idStore !== idLocal;
  }
});

//#region FETCH
const fetchGroupParentDetails = async (groupId?: number) => {
  const id = groupId ?? groupStore.selectedGroup?.parent_id;
  if (!id) {
    groupParent.value = null;
    resetChildren();
    return;
  }
  isLoading.value = true;
};

const fetchGroupChildrenList = async (loadNext = false) => {
  if (!loadNext) {
    infiniteChildrenList.value = null;
    childrenList.value = [];
    nextKey.value = null;
  } else if (nextKey.value) {
    nextKey.value = infiniteChildrenList.value?.nextKey ?? null;
  }

  isLoading.value = true;
  const response = await getChildrenEntity(groupId.value, nextKey.value);

  isError.value = response.errorType !== ErrorType.NONE;
  if (response.errorType !== ErrorType.NONE) {
    console.warn(response);
  } else {
    infiniteChildrenList.value = response.data;
    childrenList.value = [...childrenList.value, ...response.data.records];
    nextKey.value = response.data.nextKey;
    // childrenList.value = response.data.records.filter(({ id }) => id !== groupId.value);
  }
  isLoading.value = false;
};
//#endregion

onMounted(async () => {
  await fetchGroupParentDetails();

  await fetchGroupChildrenList();
});

const { showSuccessNotification, message, showFailNotification } = useNotification();

const onShowModal = () => {
  showModal.value = !showModal.value;
};

//#region SAVE
const onSave = async (forceUpdate = false) => {
  if (!groupParent.value?.id) {
    console.warn("No parent selected");
    return;
  }

  isLoading.value = true;
  const resp = await addChildEntity(groupParent.value.id, groupId.value, forceUpdate);
  if (resp.errorType === ErrorType.NONE) {
    isError.value = false;
    isLoading.value = false;
    return;
  }

  console.warn(resp);
  if (resp.errorType === ErrorType.HTTP_STATUS && !forceUpdate && resp.response.status !== 404) {
    try {
      const { errorCode, message } = await resp.response.json();
      if (errorCode === HttpErrorCode.ENTITY_WITH_PARENT) {
        showConfirmModal.value = true;
      } else {
        isError.value = true;
        showFailNotification(message as string);
      }
    } catch (err) {
      console.warn(err);
      showFailNotification();
    }
  } else {
    isError.value = true;
    showFailNotification();
  }

  isLoading.value = false;
};

const onForceSave = async () => {
  await onSave(true);
  showConfirmModal.value = false;
  if (isError.value) {
    return;
  }
  await reload();
};

const onPlainSave = async () => {
  await onSave();
  if (isError.value) {
    return;
  }
  if (!showConfirmModal.value) {
    await reload();
  }
};
//#endregion

async function reload() {
  await groupStore.getGroupDetails(groupId.value);
  groupParent.value = null;
  await fetchGroupParentDetails();
  await fetchGroupChildrenList();
  showSuccessNotification();
}

const hasChildren = computed(() => childrenList.value.length > 0);

const showAlert = computed(() => !isLoading.value && !hasChildren.value);

//#region REMOVE GROUP
const showDeleteModal = ref(false);

const onRemoveGroup = async () => {
  if (!groupStore.selectedGroup?.parent_id) {
    console.warn("No parent selected");
    return;
  }

  isLoading.value = true;
  await useApiResponseHandler(() => deleteChildEntity(groupStore.selectedGroup?.parent_id || -1, groupId.value));
  isLoading.value = false;
};

const onConfirmRemove = async () => {
  await onRemoveGroup();
  showDeleteModal.value = false;
  if (message.variant === "error") {
    return;
  }
  await reload();
};
//#endregion

const onRemoveResetClick = () => (canResetParent.value ? resetParent() : (showDeleteModal.value = true));
const removeResetLabel = computed(() => (canResetParent.value ? t(`${moduleId}.group.reset`) : t(`${moduleId}.group.remove`)));
</script>

<template>
  <div class="row">
    <div class="col-md-2">
      <strong>{{ t(`${moduleId}.group.superior_group`) }}: </strong>
      {{ groupParentNameLabel }}
    </div>
    <div v-if="canEditGroup" class="col-md-2">
      <BiButton class="btn-me" color="secondary" is-outlined :is-disabled="isLoading" @click="onShowModal">
        {{ t(`${moduleId}.group.search.search_group`) }}
      </BiButton>
      <BiButton
        v-if="canResetParent || groupStore.selectedGroup?.parent_id"
        color="danger"
        is-outlined
        :is-disabled="isLoading"
        @click="onRemoveResetClick"
      >
        {{ removeResetLabel }}
      </BiButton>
    </div>
  </div>
  <div v-if="canEditGroup" class="row">
    <div class="d-flex col-md-4 align-items-center">
      <BiButton :is-disabled="isLoading || !canSave" color="success" class="btn-me" @click="onPlainSave">
        {{ t(`${moduleId}.general.save`) }}
      </BiButton>
      <BiProgressIndicator v-if="isLoading" :extra-progress-classes="'size-sm'" :type="'spinner'"></BiProgressIndicator>
    </div>
  </div>
  <div class="row">
    <div class="col-md-4">
      <strong>{{ t(`${moduleId}.group.connected_groups`) }}: </strong>
    </div>
  </div>
  <div v-if="showAlert" class="row mt-3">
    <div class="col-md-4">
      <BiAlert>
        <template #body>
          {{ t(`${moduleId}.group.no_connected_groups`) }}
        </template>
      </BiAlert>
    </div>
  </div>
  <div class="row">
    <div class="col-md-5 mt-3">
      <BiTable is-custom responsive-breakpoint="md" v-if="hasChildren" is-bordered is-header-light>
        <template #head>
          <tr>
            <th>
              {{ t(`${moduleId}.general.code`) }}
            </th>
            <th>
              {{ t(`${moduleId}.group.default`) }}
            </th>
          </tr>
        </template>
        <template #body>
          <tr v-for="child in childrenList" :key="child.id">
            <td :data-label="t(`${moduleId}.group.group_code`)">{{ child.code }}</td>
            <td :data-label="t(`${moduleId}.group.default`)">{{ child.name }}</td>
          </tr>
        </template>
      </BiTable>
      <LoadMore :is-visible="!!infiniteChildrenList?.nextKey" :is-loading="isLoading" @load:more="fetchGroupChildrenList(true)"></LoadMore>
    </div>
  </div>

  <SearchGroupModal
    v-model="showModal"
    @selected="(parent) => (groupParent = parent)"
    :exclude-from-list="groupStore.selectedGroup?.id"
  ></SearchGroupModal>

  <BiModal v-if="canEditGroup" v-model="showConfirmModal" :title="t(`${moduleId}.general.warning`)">
    <template #body> {{ t(`${moduleId}.group.are_you_sure`) }} </template>
    <template #footer>
      <BiButton class="me-2" color="secondary" is-outlined @click="showConfirmModal = false">
        {{ t(`${moduleId}.general.cancel`) }}
      </BiButton>
      <BiButton color="success" :is-disabled="isLoading" @click="onForceSave">
        {{ t(`${moduleId}.general.confirm`) }}
      </BiButton>
    </template>
  </BiModal>

  <GenericDeleteModal v-if="canEditGroup" v-model="showDeleteModal" @confirm:delete="onConfirmRemove"></GenericDeleteModal>
</template>
