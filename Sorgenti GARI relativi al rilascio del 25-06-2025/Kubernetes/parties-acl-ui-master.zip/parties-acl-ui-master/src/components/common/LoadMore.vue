<script setup lang="ts">
import useModuleId from "@/composables/useModuleId";
import BiButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiButton.vue";
import BiProgressIndicator from "@abaco/bootstrap-italia-components/src/components/BiProgressIndicator/BiProgressIndicator.vue";
import { useI18n } from "vue-i18n";

const moduleId = useModuleId();
const { t } = useI18n();

defineProps<{
  isVisible?: boolean;
  isLoading?: boolean;
}>();

const emits = defineEmits<{
  (e: "load:more"): void;
}>();
</script>

<template>
  <div class="d-flex justify-content-end mt-1" v-if="isVisible">
    <BiProgressIndicator :extraProgressClasses="'size-sm'" v-if="isLoading" :type="'spinner'"></BiProgressIndicator>
    <BiButton class="mt-3" v-else is-outlined color="primary" @click="emits('load:more')">
      {{ t(`${moduleId}.general.load_more`) }}
    </BiButton>
  </div>
</template>
