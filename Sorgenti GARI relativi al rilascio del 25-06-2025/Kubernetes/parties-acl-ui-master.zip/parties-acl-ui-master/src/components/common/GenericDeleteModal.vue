<script setup lang="ts">
import useModuleId from "@/composables/useModuleId";
import BiButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiButton.vue";
import BiModal from "@abaco/bootstrap-italia-components/src/components/BiModal/BiModal.vue";
import { useVModel } from "@vueuse/core";
import { useI18n } from "vue-i18n";

const moduleId = useModuleId();
const { t } = useI18n();

const props = defineProps<{
  modelValue: boolean;
}>();

const emits = defineEmits<{
  (e: "update:modelValue"): void;
  (e: "confirm:delete"): void;
}>();

const showModal = useVModel(props, "modelValue", emits);

const onConfirm = () => {
  emits("confirm:delete");
  showModal.value = false;
};
</script>

<template>
  <BiModal v-model="showModal" :title="t(`${moduleId}.general.warning`)">
    <template #body>{{ t(`${moduleId}.general.are_you_sure`) }}</template>
    <template #footer>
      <div class="col-md-12 d-flex justify-content-center">
        <BiButton color="danger" class="btn-me" @click="onConfirm">
          {{ t(`${moduleId}.general.proceed`) }}
        </BiButton>
        <BiButton color="secondary" is-outlined @click="showModal = false">
          {{ t(`${moduleId}.general.cancel`) }}
        </BiButton>
      </div>
    </template>
  </BiModal>
</template>
