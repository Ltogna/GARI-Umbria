<script setup lang="ts">
import useModuleId from "@/composables/useModuleId";
import BiButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiButton.vue";
import BiProgressIndicator from "@abaco/bootstrap-italia-components/src/components/BiProgressIndicator/BiProgressIndicator.vue";
import { useI18n } from "vue-i18n";

const moduleId = useModuleId();
const { t } = useI18n();

defineProps<{
  isVisible?: boolean;
  isLoading?: boolean;
}>();

const emits = defineEmits<{
  (e: "load:more"): void;
}>();
</script>

<template>
  <tr class="show-more-row" v-if="isVisible">
    <td colspan="9999" class="text-center">
      <div class="d-inline-block">
        <BiButton
          color="primary"
          is-outlined
          class="parties-acl__entity-list-load-button py-1 px-2 d-flex"
          :is-disabled="isLoading"
          @click="emits('load:more')"
        >
          {{ t(`${moduleId}.general.load_more`) }}
          <BiProgressIndicator v-if="isLoading" :type="'spinner'"></BiProgressIndicator>
        </BiButton>
      </div>
    </td>
  </tr>
</template>

<style lang="scss">
.parties-acl {
  &__entity-list-load-button {
    .progress-spinner {
      width: 18px;
      height: 18px;
      border-width: 2px;
      margin-left: 8px;
    }
  }
}
</style>
