<script setup lang="ts">
import useEmitter from "@/composables/useEmitter";
import useModuleId from "@/composables/useModuleId";
import deferred, { type DeferredPromise } from "@/utils/deferredPromise";
import BiButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiButton.vue";
import BiModal from "@abaco/bootstrap-italia-components/src/components/BiModal/BiModal.vue";
import { type SetStopListenerFunction, createStopHelper } from "@abaco/micro-frontend/src/StopPreventionSuport";
import { inject, onBeforeUnmount, onMounted, ref } from "vue";
import { useI18n } from "vue-i18n";
import { type NavigationGuard, onBeforeRouteLeave, onBeforeRouteUpdate } from "vue-router";

const moduleId = useModuleId();
const { t } = useI18n();

const emitter = useEmitter();

const isDirty = ref(false);
onMounted(() => {
  emitter.on("is:dirty", (dirty) => {
    isDirty.value = dirty;
    window.onbeforeunload = dirty
      ? (e: BeforeUnloadEvent) => {
          e.preventDefault();
          return "Are you sure?";
        }
      : null;
  });
});

onBeforeUnmount(() => {
  emitter.off("is:dirty");
});

const showLeaveAlert = ref(false);

const helper = createStopHelper(isDirty, showLeaveAlert);

const setStopListener: SetStopListenerFunction | undefined = inject("setStopListener");
if (setStopListener) {
  setStopListener(helper.listener);
}

let $promiseToLeave: DeferredPromise<boolean, undefined> | null = null;

const onLeavePage = function () {
  showLeaveAlert.value = false;
  helper.confirm(true);
  isDirty.value = false;
  if ($promiseToLeave) {
    $promiseToLeave.resolve(true);
  }
};

const onAbortPage = function () {
  showLeaveAlert.value = false;
  helper.confirm(false);
  if ($promiseToLeave) {
    $promiseToLeave.resolve(false);
  }
};

const navigationGuard: NavigationGuard = async function () {
  if (isDirty.value) {
    showLeaveAlert.value = true;
    $promiseToLeave = deferred<boolean>();
    return $promiseToLeave.promise;
  } else {
    return Promise.resolve(true);
  }
};

onBeforeRouteLeave(navigationGuard);
onBeforeRouteUpdate(navigationGuard);
</script>

<template>
  <BiModal v-if="isDirty" v-model="showLeaveAlert" :title="t(`${moduleId}.warning_leave_title`)">
    <template #body>
      {{ t(`${moduleId}.warning_leave_message`) }}
    </template>
    <template #footer>
      <BiButton color="danger" @click="onLeavePage">
        {{ t(`${moduleId}.general.proceed`) }}
      </BiButton>
      <BiButton color="secondary" is-outlined @click="onAbortPage">
        {{ t(`${moduleId}.general.cancel`) }}
      </BiButton>
    </template>
  </BiModal>
</template>
