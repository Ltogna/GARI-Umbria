<script lang="ts" setup>
import { useApiResponseHandler, useNotification } from "@/composables/useApiResponseHandler";
import useEmitter from "@/composables/useEmitter";
import useModuleId from "@/composables/useModuleId";
import usePermissions from "@/composables/usePermissions";
import useUserDateFormat from "@/composables/useUserDateFormat";
import type { PartyWithEntityModel, UpdateEntityPartyPayloadModel } from "@/models/mandates";
import { RouteName } from "@/models/routes";
import { updateCloseDate } from "@/resources/api/mandates";
import { useConfigStore } from "@/stores/config";
import { DATE_FORMAT_DAYJS, stringToDate } from "@/utils/dates";
import BiButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiButton.vue";
import BiModal from "@abaco/bootstrap-italia-components/src/components/BiModal/BiModal.vue";
import BiDatepicker from "@abaco/bootstrap-italia-components/src/components/form/BiDatepicker.vue";
import { toTypedSchema } from "@vee-validate/zod";
import { format, isAfter, isBefore, isEqual, max } from "date-fns";
import { ErrorMessage, useForm } from "vee-validate";
import { computed, inject, ref, watch, type Ref } from "vue";
import { useI18n } from "vue-i18n";
import { useRoute, useRouter } from "vue-router";
import { z } from "zod";

const { t } = useI18n();
const moduleId = useModuleId();
const { canWrite } = usePermissions();
const router = useRouter();
const route = useRoute();
const { showSuccessNotification } = useNotification();
const emitter = useEmitter();
const mandateDetail = inject("mandateDetail") as Ref<PartyWithEntityModel>;
const userDateFormat = useUserDateFormat();
const configStore = useConfigStore();

const showConfirmModal = ref(false);
const submitConfirmed = ref(false);

const minEndDate = computed(() => {
  if (configStore.allowMandatePastCloseDate) return;
  return max([mandateDetail.value.day_from, new Date()]);
});
const maxEndDate = computed(() => mandateDetail.value.entity.day_to ?? new Date(9999, 11, 31));

const isEditable = computed(() => {
  return canWrite && !!mandateDetail.value.editable && route.name === RouteName.MANDATE_EDIT;
});
const isRevokable = computed(() => {
  return canWrite && !!mandateDetail.value.revocable && route.name === RouteName.MANDATE_REVOKE;
});

const FormSchema = z
  .object({
    dayFrom: z.date({
      required_error: t(`${moduleId}.general.mandatory_field`),
    }),
    dayTo: z.string().min(route.name === RouteName.MANDATE_REVOKE ? 1 : 0, { message: t(`${moduleId}.general.mandatory_field`) }), // TODO chiedere a Fabio se è corretto renderla obbligatoria anche per l'estensione del contratto.
  })
  .refine(
    (data) => {
      const dateToCompare = stringToDate(data.dayTo);
      return dateToCompare && (isEqual(dateToCompare, mandateDetail.value.day_from) || isAfter(dateToCompare, mandateDetail.value.day_from));
    },
    { path: ["dayTo"], message: t(`${moduleId}.mandate_form.dayFrom_greater_than_dayTo`) },
  )
  .refine(
    (data) => {
      const dateToCompare = stringToDate(data.dayTo);
      return (
        dateToCompare &&
        mandateDetail.value.entity.day_to &&
        (isEqual(dateToCompare, mandateDetail.value.entity.day_to) || isBefore(dateToCompare, mandateDetail.value.entity.day_to))
      );
    },
    {
      path: ["dayTo"],
      message: t(`${moduleId}.mandate_form.entity_dayTo_greater_than_day_to`, {
        entityDayTo: mandateDetail.value.entity.day_to ? format(mandateDetail.value.entity.day_to, userDateFormat) : "",
      }),
    },
  );
type FormModel = z.infer<typeof FormSchema>;

const { handleSubmit, defineField, resetForm, meta, isSubmitting, values } = useForm<FormModel>({
  validationSchema: toTypedSchema(FormSchema),
  validateOnMount: true,
  initialValues: {
    dayTo: "",
    dayFrom: mandateDetail.value.day_from,
  },
});

const [dayTo] = defineField("dayTo");

watch(
  () => meta.value.dirty,
  (isDirty) => {
    emitter.emit("is:dirty", isDirty);
  },
);

const onSubmit = handleSubmit(async (values) => {
  if (values) {
    showConfirmModal.value = true;
  }
});
async function onConfirmSubmit() {
  if (values) {
    const mandateData: UpdateEntityPartyPayloadModel = {
      day_to: values.dayTo !== "" ? values.dayTo : null,
      revoke: route.name === RouteName.MANDATE_REVOKE,
    };
    const resp = await useApiResponseHandler(() => updateCloseDate(+mandateDetail.value.mandate_id, mandateData));
    if (resp) {
      resetForm({
        values,
      });
      submitConfirmed.value = true;
      showConfirmModal.value = false;
      return true;
    }
    showConfirmModal.value = false;
    return false;
  }
}
function onHiddenModal() {
  if (submitConfirmed.value) {
    showSuccessNotification();
    router.replace({ name: RouteName.PARTY_DETAILS });
  }
}
const onReset = () => {
  resetForm();
};

const isDisabled = computed(() => {
  if (isRevokable.value) {
    return false;
  }
  if (isEditable.value) {
    return false;
  }

  return true;
});
const dateLabel = computed(() => {
  if (route.name === RouteName.MANDATE_REVOKE) {
    return t(`${moduleId}.mandate_form.revoke_date`);
  }

  return t(`${moduleId}.mandate_form.new_end_date`);
});
const confirmMessage = computed(() => {
  if (route.name === RouteName.MANDATE_REVOKE) {
    return t(`${moduleId}.mandate_form.revoke_confirm_message`);
  }

  return t(`${moduleId}.mandate_form.edit_confirm_message`);
});
</script>

<template>
  <form @submit.prevent="onSubmit" @reset.prevent="onReset" novalidate class="parties-acl__form">
    <div class="row g-2">
      <div class="col-lg-4">
        <BiDatepicker
          :is-disabled="isDisabled"
          :format="DATE_FORMAT_DAYJS"
          :debounce-time="0"
          :label="dateLabel"
          :min="minEndDate"
          :max="maxEndDate"
          :class="route.name === RouteName.MANDATE_REVOKE ? 'field-required' : ''"
          v-model="dayTo"
          :validate-on-change="false"
        ></BiDatepicker>
        <ErrorMessage v-if="meta.touched" name="dayTo" class="form-feedback just-validate-error-label" />
      </div>
    </div>
    <div class="row mt-3">
      <div class="col">
        <BiButton v-if="isEditable" color="primary" type="submit" class="me-2" :is-disabled="isSubmitting">
          {{ t(`${moduleId}.general.proceed`) }}
        </BiButton>
        <BiButton v-if="isRevokable" color="danger" type="submit" class="me-2" :is-disabled="isSubmitting">
          {{ t(`${moduleId}.general.proceed`) }}
        </BiButton>
        <BiButton color="secondary" is-outlined type="reset" :is-disabled="isDisabled || isSubmitting">
          {{ t(`${moduleId}.mandate_form.reset`) }}
        </BiButton>
      </div>
    </div>
  </form>

  <BiModal v-model="showConfirmModal" :title="t(`${moduleId}.general.warning`)" @hidden-modal="onHiddenModal">
    <template #body> {{ confirmMessage }} </template>
    <template #footer>
      <BiButton class="me-2" color="secondary" is-outlined @click="showConfirmModal = false">
        {{ t(`${moduleId}.general.cancel`) }}
      </BiButton>
      <BiButton color="success" @click="onConfirmSubmit">
        {{ t(`${moduleId}.general.confirm`) }}
      </BiButton>
    </template>
  </BiModal>
</template>
