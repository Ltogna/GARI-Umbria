<script setup lang="ts">
import { useApiResponseHandler } from "@/composables/useApiResponseHandler";
import useMandeteListHistoryFlag from "@/composables/useMandeteListHistoryFlag";
import useModuleId from "@/composables/useModuleId";
import useUserDateFormat from "@/composables/useUserDateFormat";
import { INFINITE_DATE } from "@/constants";
import { StatusCodeEnum, type PartyWithEntityModel } from "@/models/mandates";
import { RouteName } from "@/models/routes";
import { getMandatesByPartyId } from "@/resources/api/mandates";
import { DATE_FORMAT } from "@/utils/dates";
import BiAlert from "@abaco/bootstrap-italia-components/src/components/BiAlert/BiAlert.vue";
import BiIconButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiIconButton.vue";
import BiHiddenContent from "@abaco/bootstrap-italia-components/src/components/BiHiddenContent/BiHiddenContent.vue";
import BiTable from "@abaco/bootstrap-italia-components/src/components/BiTable/BiTable.vue";
import BiCheckbox from "@abaco/bootstrap-italia-components/src/components/form/BiCheckbox.vue";
import { format } from "date-fns";
import { onMounted, ref, watch } from "vue";
import { useI18n } from "vue-i18n";
import { useRoute, useRouter } from "vue-router";
import LoadMoreRow from "../common/LoadMoreRow.vue";

const moduleId = useModuleId();
const { history } = useMandeteListHistoryFlag();
const moduleIdMandate = `${moduleId}.mandate_list`;

const { t } = useI18n();
const router = useRouter();
const route = useRoute();
const userDateFormat = useUserDateFormat();

const loading = ref(false);
const nextKey = ref<string | null>(null);
const mandateList = ref<PartyWithEntityModel[]>([]);
const { partyId } = route.params as { partyId: string };

watch(history, async () => {
  await fetchMandates();
});

onMounted(async () => {
  await fetchMandates();
});

const gotoDetail = (mandateId: number) => {
  router.push({ name: RouteName.MANDATE_DETAILS, params: { mandateId } });
};

async function onLoadMore() {
  loading.value = true;
  const res = await useApiResponseHandler(() => getMandatesByPartyId(+partyId, history.value, nextKey.value ?? undefined));

  if (res && typeof res !== "boolean") {
    mandateList.value = [...mandateList.value, ...res.records];
    nextKey.value = res.nextKey;
  }

  loading.value = false;
}

async function fetchMandates() {
  loading.value = true;
  const res = await useApiResponseHandler(() => getMandatesByPartyId(+partyId, history.value));
  if (res && typeof res !== "boolean") {
    mandateList.value = res.records;
    nextKey.value = res.nextKey;
  }
  loading.value = false;
}

const realDayTo = (dayTo?: Date | null) => {
  if (dayTo) {
    return format(dayTo, DATE_FORMAT) !== INFINITE_DATE ? format(dayTo, userDateFormat) : "-";
  }
  return "-";
};

const translatedStatus = (status: StatusCodeEnum) => {
  const statusTranslations: Record<StatusCodeEnum, string> = {
    [StatusCodeEnum.VALID]: t(`${moduleId}.mandate.status.valid`),
    [StatusCodeEnum.NOT_VALID]: t(`${moduleId}.mandate.status.not_valid`),
    [StatusCodeEnum.CLOSED]: t(`${moduleId}.mandate.status.closed`),
  };
  return statusTranslations[status];
};
</script>

<template>
  <div class="d-flex justify-content-end me-2">
    <BiCheckbox size="sm" :label="t(`${moduleIdMandate}.show_expired`)" v-model="history" />
  </div>
  <BiTable is-custom responsive-breakpoint="md" extraTableClasses="table-head-bg" is-row-hover>
    <template #head>
      <tr class="bg-light">
        <th>{{ t(`${moduleIdMandate}.code`) }}</th>
        <th>{{ t(`${moduleIdMandate}.group`) }}</th>
        <th>{{ t(`${moduleIdMandate}.type`) }}</th>
        <th>{{ t(`${moduleIdMandate}.status`) }}</th>
        <th>{{ t(`${moduleIdMandate}.start_date`) }}</th>
        <!-- 145903 changed label name-->
        <th>{{ t(`${moduleIdMandate}.end_mandate`) }}</th>
        <th>
          <BiHiddenContent :text="t(`${moduleIdMandate}.goto_details`)"></BiHiddenContent>
        </th>
      </tr>
    </template>
    <template #body>
      <tr v-for="mandate in mandateList" :key="mandate.mandate_id">
        <td :data-label="t(`${moduleIdMandate}.code`)">{{ mandate.entity.code }}</td>
        <td :data-label="t(`${moduleIdMandate}.group`)">{{ mandate.entity.name }}</td>
        <td :data-label="t(`${moduleIdMandate}.type`)">{{ mandate.party_type.description }}</td>
        <td :data-label="t(`${moduleIdMandate}.status`)">{{ translatedStatus(mandate.status) }}</td>
        <td :data-label="t(`${moduleIdMandate}.start_date`)">{{ format(mandate.day_from, userDateFormat) }}</td>
        <td :data-label="t(`${moduleIdMandate}.end_mandate`)">
          {{ realDayTo(mandate.day_to) }}
        </td>
        <td>
          <BiIconButton
            icon="arrow-right"
            :width="35"
            is-outlined
            color="secondary"
            :title="t(`${moduleIdMandate}.goto_details`)"
            @click="gotoDetail(mandate.mandate_id)"
          />
        </td>
      </tr>
      <tr v-if="mandateList.length === 0 && !loading">
        <td colspan="6">
          <BiAlert is-info :title="t(`${moduleIdMandate}.no_mandates`)"></BiAlert>
        </td>
      </tr>
      <LoadMoreRow :is-loading="loading" :is-visible="!!nextKey" @load:more="onLoadMore"></LoadMoreRow>
    </template>
  </BiTable>
</template>
