<script lang="ts" setup>
import BiIcon from "@abaco/bootstrap-italia-components/src/components/BiIcon/BiIcon.vue";
import { defineProps } from "vue";

defineProps<{
  icon?: string; // file-lines | list
  title?: string;
}>();
</script>

<template>
  <main class="parties-acl">
    <div class="container">
      <div class="row my-3 justify-content-start">
        <div v-if="title" class="col-12 my-3">
          <h4 class="fw-bold text-primary">
            <BiIcon v-if="icon" class="mx-2" :icon="icon" size="lg" />
            {{ title }}
          </h4>
        </div>
      </div>

      <slot />
    </div>
  </main>
</template>
