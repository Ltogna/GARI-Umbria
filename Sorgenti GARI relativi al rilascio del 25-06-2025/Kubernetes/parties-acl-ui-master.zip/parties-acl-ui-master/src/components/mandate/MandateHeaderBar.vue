<script setup lang="ts">
import useModuleId from "@/composables/useModuleId";
import type { PartySchema } from "@/models/parties";
import { getPartyDenomination } from "@/utils/partyDenomination";
import { computed, inject, type Ref, defineProps } from "vue";
import { useI18n } from "vue-i18n";

const props = defineProps<{
  isStatus?: boolean;
}>();

const party = inject<Ref<PartySchema>>("party");
const { t } = useI18n();
const moduleId = useModuleId();

const denomination = computed(() => {
  return getPartyDenomination(party);
});
</script>

<template>
  <div v-if="party" class="w-100 d-flex col-12 text-white justify-content-between p-2 mandate-header-bar">
    <div class="text-left px-2">
      {{
        t(`${moduleId}.mandate.title`, {
          cuaa: party.code,
          companyName: denomination,
        })
      }}
    </div>
    <template v-if="props.isStatus">
      <slot name="stateSlot"></slot>
    </template>
  </div>
</template>

<style lang="scss" scoped>
.mandate-header-bar {
  background-color: var(--bs-primary) !important;
  font-weight: 500 !important;
  padding-left: 20px !important;
}

@media (min-width: 500px) {
  .status-nowrap {
    white-space: nowrap !important;
  }
}
</style>
