<script lang="ts" setup>
import useModuleId from "@/composables/useModuleId";
import useUserDateFormat from "@/composables/useUserDateFormat";
import { INFINITE_DATE } from "@/constants";
import type { PartyWithEntityModel } from "@/models/mandates";
import { useConfigStore } from "@/stores/config";
import { DATE_FORMAT } from "@/utils/dates";
import { format } from "date-fns";
import { computed } from "vue";
import { useI18n } from "vue-i18n";
import { useRoute } from "vue-router";
import { RouteName } from "@/models/routes";

const { showChronologicalDueDate } = useConfigStore();
const route = useRoute();

const props = defineProps<{
  mandateDetail: PartyWithEntityModel;
}>();

const lastDayOfYear = computed(() => {
  if (showChronologicalDueDate) {
    const currentYear = new Date().getFullYear();
    const dateTo = props.mandateDetail.day_to;
    if (dateTo && format(dateTo, DATE_FORMAT) === INFINITE_DATE) {
      return new Date(currentYear, 11, 31);
    }
  }
  return null;
});

const { t } = useI18n();
const moduleId = useModuleId();
const userDateFormat = useUserDateFormat();

const endMandateLabel = computed(() => {
  return route.name === RouteName.MANDATE_EDIT ? `${moduleId}.mandate_list.new_end_date` : `${moduleId}.mandate_list.end_mandate`;
});
</script>

<template>
  <div class="row">
    <div class="col-md-12">
      <strong>{{ t(`${moduleId}.mandate_list.code`) }}:</strong>
      {{ mandateDetail.entity.code }}
    </div>
  </div>
  <div class="row">
    <div class="col-md-12">
      <strong>{{ t(`${moduleId}.mandate_list.group`) }}:</strong>
      {{ mandateDetail.entity.name }}
    </div>
  </div>
  <div class="row">
    <div class="col-md-12">
      <strong>{{ t(`${moduleId}.mandate_list.type`) }}:</strong>
      {{ mandateDetail.party_type.description }}
    </div>
  </div>
  <div class="row">
    <div class="col-md-12">
      <strong>{{ t(`${moduleId}.mandate_list.start_date`) }}:</strong>
      {{ format(mandateDetail.day_from, userDateFormat) }}
    </div>
  </div>
  <div class="row" v-if="lastDayOfYear">
    <div class="col-md-12">
      <strong>{{ t(`${moduleId}.mandate_list.chronological_due_date`) }}:</strong>
      <strong class="text-danger ms-1">{{ format(lastDayOfYear, userDateFormat) }}</strong>
    </div>
  </div>
  <div class="row">
    <div class="col-md-12">
      <!-- 145903 changed label name-->
      <strong>{{ t(endMandateLabel) }}:</strong>
      {{ mandateDetail.day_to && format(mandateDetail.day_to, DATE_FORMAT) !== INFINITE_DATE ? format(mandateDetail.day_to, userDateFormat) : "-" }}
    </div>
  </div>
</template>
