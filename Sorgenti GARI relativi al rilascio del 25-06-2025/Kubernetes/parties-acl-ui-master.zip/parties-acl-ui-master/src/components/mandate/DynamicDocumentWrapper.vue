<script lang="ts" setup>
import useEmitter from "@/composables/useEmitter";
import useModuleId from "@/composables/useModuleId";
import type { DocumentDataRecordModel, DynamiDocumentDataModel, DynamiDocumentMapModel, DynamiDocumentModel } from "@/models/dynamicDocuments";
import usePermissions from "@/composables/usePermissions";
import { ScopeCode, type DocumentTypeListModel, type DocumentTypeModel } from "@/models/documents";
import { RouteName } from "@/models/routes";
import { getDocumentTypeByDefinitionCode, getDocumentTypes, type DocumentParams, type PartiesParam } from "@/resources/api/documents";
import { createDocument, deleteDocument, getDocument, getDocuments, updateDocument } from "@/resources/api/dynamicDocuments";
import BiButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiButton.vue";
import BiModal from "@abaco/bootstrap-italia-components/src/components/BiModal/BiModal.vue";
import { getUUID } from "@abaco/bootstrap-italia-components/src/utilities";
import type { DocumentSchemaType } from "@abaco/dynamic-documents/src/resources/models";
import { ErrorType } from "@abaco/safe-rest/src/HTTPClient";
import isEqual from "lodash/isEqual";
import { computed, inject, ref, toRaw, watch, type Ref } from "vue";
import { useI18n } from "vue-i18n";
import { useRoute, useRouter } from "vue-router";
import DynamicDocumentForm from "../dynamicDocuments/DynamicDocumentForm.vue";
import DynamicDocumentList from "../dynamicDocuments/DynamicDocumentList.vue";

import type { PartyWithEntityModel } from "@/models/mandates";
import { useApiResponseHandler, useNotification } from "@/composables/useApiResponseHandler";
import { getMandateById } from "@/resources/api/mandates";

enum ActionType {
  CREATE = "CREATE",
  EDIT = "EDIT",
  DELETE = "DELETE",
}

const moduleId = useModuleId();
const { t } = useI18n();
const route = useRoute();
const router = useRouter();
const emitter = useEmitter();

const { canWrite } = usePermissions();
const showModal = ref(false);
const docType = ref<DocumentTypeModel | null>(null);

const currentDefinition = ref<DocumentSchemaType | null>(null);
const currentDocument = ref<DynamiDocumentDataModel>({});
let currentDocumentPrevData: DynamiDocumentDataModel = {};

const documentList = ref<DynamiDocumentModel[]>([]);
const modalBodyText = ref("");
const action = ref<ActionType>(ActionType.CREATE);

const processingDocument = ref<DynamiDocumentMapModel>();
const loading = ref<boolean>(true);
const nextKey = ref<string | null>(null);
const totalCounts = ref<number>(0);

const confirmAction = ref<boolean>(false);

const documentTypes = inject<Ref<DocumentTypeListModel>>("documentTypes", ref<DocumentTypeListModel>([]));
const mandateDetail = inject<Ref<PartyWithEntityModel>>("mandateDetail");

const editable = computed(() => canWrite && (mandateDetail?.value.editable || mandateDetail?.value.revocable));

function goBack() {
  if (route.name === RouteName.MANDATE_NEW_MULTIPLE_DOC || route.name === RouteName.MANDATE_EDIT_MULTIPLE_DOC) {
    router.replace({ name: RouteName.MANDATE_DOC });
  } else {
    router.replace({ name: RouteName.MANDATE_DETAILS });
  }
}

function onDocumentChanged(changes: DocumentDataRecordModel) {
  if ("data" in currentDocumentPrevData && currentDocumentPrevData.data) {
    if (!isEqual(currentDocumentPrevData.data, changes)) {
      emitter.emit("is:dirty", true);
    } else {
      emitter.emit("is:dirty", false);
    }
  }
}

const isMultiple = computed(() => {
  if (route.name === RouteName.MANDATE_NEW_MULTIPLE_DOC) {
    return false;
  }
  if (route.name === RouteName.MANDATE_EDIT_MULTIPLE_DOC) {
    return false;
  }
  return docType.value?.multiple ?? false;
});

async function loadDocuments(append = false) {
  if (docType.value) {
    const mandateId = route.params.mandateId as string;
    const defCode = docType.value.definitionCode as string;
    const resp = await getDocuments(mandateId, defCode, nextKey.value);
    if (resp.errorType === ErrorType.NONE) {
      if (append) {
        documentList.value = [...documentList.value, ...resp.data.records];
      } else {
        documentList.value = resp.data.records;
      }
      nextKey.value = resp.data.nextKey;
      totalCounts.value = resp.data.count;
    } else {
      useNotification().showFailNotification();
    }
  }
}

watch(
  () => route.params,
  async (params) => {
    loading.value = true;
    currentDocument.value = {};

    documentList.value = [];
    nextKey.value = null;
    totalCounts.value = 0;

    const mandateId = params.mandateId as string | undefined;
    const partyId = params.partyId as string | undefined;
    const docTypeParam = params.docType as string | undefined;

    if (mandateId && partyId && docTypeParam) {
      const docResp = await getDocumentTypeByDefinitionCode(docTypeParam);
      if (docResp.errorType === ErrorType.NONE) {
        currentDefinition.value = docResp.data;
      }

      docType.value = documentTypes.value.find((v) => v.definitionCode === docTypeParam) ?? null;
      if (docType.value && docType.value.flDocPresent) {
        await loadDocuments();
        const docId = params.docId as string | undefined;
        if (documentList.value.length && (!docType.value.multiple || docId)) {
          const docResp = await getDocument(mandateId, docId ?? documentList.value[0].document_id);
          if (docResp.errorType === ErrorType.NONE) {
            currentDocument.value = docResp.data;
          } else {
            useNotification().showFailNotification();
          }
        }
      }
    }

    currentDocumentPrevData = structuredClone(toRaw(currentDocument.value));
    emitter.emit("is:dirty", false);
    loading.value = false;
  },
  { immediate: true },
);

async function handleModalClose() {
  // TODO: do it better!!! Added `setTimeout` avoid bootstrap ref error
  setTimeout(async () => {
    if (confirmAction.value) {
      switch (action.value) {
        case ActionType.CREATE:
          //! no entry here because the creation action no have modal
          // goBack();
          break;
        case ActionType.EDIT:
          // stay here for another change
          // goBack();
          break;
        case ActionType.DELETE:
          if (route.name === RouteName.MANDATE_DOC && docType.value?.multiple) {
            await loadDocuments();
          } else {
            goBack();
          }
          break;
      }
    }
    confirmAction.value = false;
  }, 200);
}

function handleDismissModal() {
  processingDocument.value = undefined;
  showModal.value = false;
}

async function handleConfirmAction() {
  const mandateId = route.params.mandateId as string;
  if (processingDocument.value === undefined) {
    return;
  }
  const { document_id: documentId } = processingDocument.value;
  if (typeof documentId !== "number") {
    return;
  }
  switch (action.value) {
    case ActionType.CREATE:
      break;
    case ActionType.EDIT:
      {
        const resp = await updateDocument(mandateId, documentId.toString(), {
          fields: processingDocument.value.data,
        });
        if (resp.errorType === ErrorType.NONE) {
          useNotification().showSuccessNotification();
          const paramsParty: DocumentParams = {
            scopeCode: ScopeCode.MANDATES,
            mandateId: mandateId as string,
          };
          await reloadDocumentTypes(paramsParty);
          currentDocumentPrevData = structuredClone(toRaw(currentDocument.value));
          emitter.emit("is:dirty", false);
        } else {
          useNotification().showFailNotification();
        }
      }

      break;
    case ActionType.DELETE:
      {
        await deleteDocument(mandateId, documentId);
        const paramsParty: DocumentParams = {
          scopeCode: ScopeCode.MANDATES,
          mandateId: mandateId as string,
        };
        await reloadDocumentTypes(paramsParty);
        currentDocumentPrevData = structuredClone(toRaw(currentDocument.value));
        emitter.emit("is:dirty", false);
      }
      break;
  }
  showModal.value = false;
}

async function reloadDocumentTypes(paramsParty: PartiesParam) {
  confirmAction.value = true;
  const resDocPromise = getDocumentTypes(paramsParty);

  const res = await useApiResponseHandler(() => getMandateById(+paramsParty.mandateId));
  if (res && typeof res !== "boolean" && mandateDetail) {
    mandateDetail.value = res;
  }
  const resDoc = await resDocPromise;
  if (resDoc.errorType === ErrorType.NONE && resDoc.data) {
    documentTypes.value = resDoc.data;
  } else {
    console.error("Failed to fetch document types:", resDoc);
  }
}

async function onCreateDocument(documentData: DynamiDocumentMapModel) {
  action.value = ActionType.CREATE;
  processingDocument.value = documentData;
  const mandateId = route.params.mandateId as string;
  const resp = await createDocument(mandateId, documentData);
  if (resp.errorType === ErrorType.NONE) {
    useNotification().showSuccessNotification();
    const paramsParty: DocumentParams = {
      scopeCode: ScopeCode.MANDATES,
      mandateId: mandateId as string,
    };
    reloadDocumentTypes(paramsParty);
    showModal.value = false;
    currentDocumentPrevData = structuredClone(toRaw(currentDocument.value));
    emitter.emit("is:dirty", false);
    goBack();
  }
}

function onConfirmUpdate(documentData: DynamiDocumentMapModel) {
  action.value = ActionType.EDIT;
  processingDocument.value = documentData;
  modalBodyText.value = t(`${moduleId}.dynamic_docs.form.confirmMessage.EDIT`);
  const docName = docType.value?.definitionCodeI18n ?? "";
  // #141072 fixed modal title
  modalTitle.value = t(`${moduleId}.dynamic_docs.form.updateConfirm`, {
    docName,
  });
  showModal.value = true;
}

async function onConfirmDelete(documentData: DynamiDocumentMapModel) {
  action.value = ActionType.DELETE;
  processingDocument.value = documentData;
  modalBodyText.value = t(`${moduleId}.dynamic_docs.form.confirmMessage.DELETE`);
  const docName = docType.value?.definitionCodeI18n ?? "";
  // #141072 fixed modal title
  modalTitle.value = t(`${moduleId}.dynamic_docs.form.deleteConfirm`, {
    docName,
  });
  showModal.value = true;
}

const modalTitle = ref<string>("");

async function onLoadMore() {
  await loadDocuments(true);
}
</script>

<template>
  <template v-if="docType && currentDefinition">
    <DynamicDocumentForm
      v-if="!isMultiple && !loading"
      :docDefinition="currentDefinition"
      v-model="currentDocument"
      :readonly="!editable"
      @create-document="onCreateDocument"
      @update-document="onConfirmUpdate"
      @delete-document="onConfirmDelete"
      @change-document="onDocumentChanged"
    />
    <DynamicDocumentList
      v-if="isMultiple && !loading"
      :documentList="documentList"
      :docType="docType"
      :docDefinition="currentDefinition"
      :showLoadMore="!!nextKey"
      :readonly="!editable"
      @delete-document="onConfirmDelete"
      @load-more="onLoadMore"
    />
  </template>

  <BiModal
    size="lg"
    ariaLabelledby="confirm-modal-document"
    :id="getUUID()"
    v-model="showModal"
    :title="modalTitle"
    data-keyboard="true"
    data-backdrop="static"
    extra-body-class="pt-5"
    @hidden-modal="handleModalClose()"
  >
    <template #body> {{ modalBodyText }} </template>
    <template #footer>
      <div class="customer-land-link__modal-footer text-center pt-5 pb-5 w-100">
        <BiButton @click="handleDismissModal" is-outlined color="secondary">
          {{ t(`${moduleId}.general.cancel`) }}
        </BiButton>

        <BiButton v-if="docType?.flDocPresent && action === ActionType.DELETE" @click="handleConfirmAction" color="danger">
          {{ t(`${moduleId}.dynamic_docs.form.deleteConfirm`) }}
        </BiButton>
        <BiButton @click="handleConfirmAction" color="success" v-if="!docType?.flDocPresent || (docType?.flDocPresent && action === ActionType.EDIT)">
          {{ t(`${moduleId}.dynamic_docs.form.updateConfirm`) }}
        </BiButton>
      </div>
    </template>
  </BiModal>
</template>

<style lang="scss">
.customer-land-link {
  &__modal-footer {
    button {
      &:not(:last-child) {
        margin-right: 12px;
      }
    }
  }
}
</style>
