<script lang="ts" setup>
import useModuleId from "@/composables/useModuleId";
import usePermissions from "@/composables/usePermissions";
import type { DocumentTypeListModel } from "@/models/documents";
import type { PartyWithEntityModel } from "@/models/mandates";
import { RouteName } from "@/models/routes";
import BiAccordion from "@abaco/bootstrap-italia-components/src/components/BiAccordion/BiAccordion.vue";
import BiIcon from "@abaco/bootstrap-italia-components/src/components/BiIcon/BiIcon.vue";
import { computed, inject, type Ref } from "vue";
import { useI18n } from "vue-i18n";

const moduleId = useModuleId();
const mandateDetail = inject<Ref<PartyWithEntityModel>>("mandateDetail");
const { canWrite } = usePermissions();
const { t } = useI18n();

const props = defineProps<{
  documentData: DocumentTypeListModel;
}>();

const editable = computed(() => {
  return canWrite && (mandateDetail?.value?.editable || mandateDetail?.value?.revocable);
});
</script>

<template>
  <BiAccordion
    v-if="props.documentData.length > 0"
    :model-value="true"
    color-bg-header="primary"
    color-header="white"
    body-extra-class="p-0"
    header-extra-class="d-block text-truncate"
  >
    <template #header>
      <span class="text-truncate">
        {{ t(`${moduleId}.mandate.document`, 2) }}
      </span>
    </template>

    <div class="it-list-wrapper">
      <ul class="it-list border ps-3 pe-1 py-3">
        <li v-for="docType in documentData" :key="docType.definitionCode" class="parties-acl__item-list">
          <span :class="'text-decoration-none d-flex align-items-center px-2 py-2 lh-sm'" v-if="!editable && !docType.flDocPresent">
            <span>{{ docType.definitionCodeI18n }}</span>
            <BiIcon class="ms-auto underline" :icon="'eye-slash'" :icon-style="'regular'" :color="'info'" size="lg" />
          </span>
          <RouterLink
            v-else
            :to="{
              name: RouteName.MANDATE_DOC,
              params: { docType: docType.definitionCode },
            }"
            :class="'text-decoration-none d-flex align-items-center px-2 py-2 lh-sm'"
            :active-class="'fw-semibold text-black'"
          >
            <span>{{ docType.definitionCodeI18n }}</span>

            <BiIcon v-if="!editable" class="ms-auto underline" :icon="'eye'" :icon-style="'regular'" :color="'success'" size="lg" />
            <BiIcon
              v-else-if="editable && !docType.flDocPresent"
              class="ms-auto underline"
              :icon="'pen-circle'"
              :icon-style="'regular'"
              :color="'info'"
              size="lg"
            />
            <BiIcon v-else class="ms-auto underline" :icon="'circle-check'" :icon-style="'regular'" :color="'success'" size="lg" />
          </RouterLink>
        </li>
      </ul>
    </div>
  </BiAccordion>
</template>

<style lang="scss" scoped>
.parties-acl {
  &__item-list {
    a {
      &:hover {
        text-decoration-line: none !important;
        span {
          text-decoration-line: underline !important;
        }
      }
    }
  }
}
</style>
<style lang="scss">
.parties-acl {
  .accordion-header {
    height: 44px !important;
  }
}
</style>
