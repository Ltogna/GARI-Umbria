<script setup lang="ts">
import useModuleId from "@/composables/useModuleId";
import { usePartyList } from "@/composables/usePartyList";
import type { PartyFilterSchema } from "@/models/parties";
import BiAlert from "@abaco/bootstrap-italia-components/src/components/BiAlert/BiAlert.vue";
import BiButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiButton.vue";
import BiProgressIndicator from "@abaco/bootstrap-italia-components/src/components/BiProgressIndicator/BiProgressIndicator.vue";
import BiInput from "@abaco/bootstrap-italia-components/src/components/form/BiInput.vue";
import useColors from "@abaco/bootstrap-italia-components/src/composables/useColors";
import { toTypedSchema } from "@vee-validate/zod";
import { useForm } from "vee-validate";
import { useI18n } from "vue-i18n";
import z from "zod";

withDefaults(defineProps<{ inline?: boolean }>(), { inline: false });

const emit = defineEmits<{
  (e: "search", value: Partial<PartyFilterSchema>): void;
}>();

defineExpose({
  /**
   * ### Reset form
   *
   * This calls `usePartyList` resetSearch and then reset form
   */
  clearForm,
});

const { loading, search, page, resetSearch } = usePartyList();

const { t } = useI18n();
const moduleId = useModuleId();
const { getColor } = useColors();

const FormSchema = z.object({
  code: z.string().trim().optional(),
  fullName: z.string().trim().optional(),
});

type FormModel = z.infer<typeof FormSchema>;

const { handleSubmit, submitCount, meta, setErrors, isSubmitting, resetForm, defineField } = useForm<FormModel>({
  initialValues: {
    code: search.code,
    fullName: search.fullName,
  },
  validationSchema: toTypedSchema(FormSchema),
});

const [code] = defineField("code");
const [fullName] = defineField("fullName");

const onSubmit = handleSubmit((values) => {
  if (!values.code && !values.fullName) {
    setErrors({
      code: "errors",
      fullName: "errors",
    });
    return;
  }
  emit("search", values as Partial<PartyFilterSchema>);
  return true;
});

/**
 * ### Reset form
 */
function clearForm() {
  resetSearch();
  resetForm({
    values: {
      code: search.code,
      fullName: search.fullName,
    },
  });
}
</script>

<template>
  <form v-if="!inline" class="needs-validation pt-5" @submit.prevent="onSubmit" @reset.prevent="clearForm">
    <div class="row">
      <div class="form-group col-md-6">
        <BiInput
          type="search"
          :label="t(`${moduleId}.cuaa`)"
          :placeholder="t(`${moduleId}.party.search.input_placeholder`)"
          v-model="code"
          :default-return-if-not-value="'undefined'"
        />
      </div>
      <div class="form-group col-md-6">
        <BiInput
          type="search"
          :label="t(`${moduleId}.party.list.fields.last_name`)"
          :placeholder="t(`${moduleId}.party.search.input_placeholder`)"
          v-model="fullName"
          :default-return-if-not-value="'undefined'"
        />
      </div>
    </div>

    <div class="row">
      <div class="col-md-12 form-group d-flex justify-content-center">
        <BiProgressIndicator :type="'spinner'" v-if="loading"></BiProgressIndicator>
        <template v-else>
          <BiButton
            :is-disabled="isSubmitting"
            type="reset"
            @click="clearForm"
            size="lg"
            class="btn"
            :class="getColor('button', 'secondary', 'outline')"
          >
            {{ t(`${moduleId}.general.cancel`) }}
          </BiButton>
          <BiButton :is-disabled="isSubmitting" type="submit" size="lg" class="ms-3 btn" :class="getColor('button', 'success')">
            {{ t(`${moduleId}.general.search`) }}
          </BiButton>
        </template>
      </div>
    </div>
  </form>
  <form
    v-else
    class="parties-acl__search-party-form d-flex mb-2 g-3 flex-wrap"
    @submit.prevent="onSubmit"
    @reset.prevent="clearForm"
    autocomplete="off"
  >
    <div class="flex-grow-1 align-self-end">
      <BiInput
        type="search"
        :label="t(`${moduleId}.cuaa`)"
        :placeholder="t(`${moduleId}.party.search.input_placeholder`)"
        v-model="code"
        :default-return-if-not-value="'undefined'"
      />
    </div>
    <div class="flex-grow-1 align-self-end">
      <BiInput
        type="search"
        :label="t(`${moduleId}.party.list.fields.last_name`)"
        :placeholder="t(`${moduleId}.party.search.input_placeholder`)"
        v-model="fullName"
        :default-return-if-not-value="'undefined'"
      />
    </div>
    <div class="align-self-end d-flex g-2">
      <BiButton type="reset" :is-disabled="isSubmitting" class="me-2" size="lg" :class="getColor('button', 'secondary', 'outline')">
        {{ t(`${moduleId}.general.cancel`) }}
      </BiButton>
      <BiButton type="submit" :is-disabled="isSubmitting" size="lg" class="ms-3 btn" :class="getColor('button', 'success')">
        {{ t(`${moduleId}.general.search`) }}
      </BiButton>
    </div>
  </form>
  <BiAlert
    class="mt-3"
    v-if="submitCount > 0 && !loading && meta.valid && page.records.length === 0"
    is-info
    :title="t(`${moduleId}.general.warning`)"
  >
    <template #body>{{ t(`${moduleId}.party.search.errors.not_found`) }}</template>
  </BiAlert>
  <BiAlert class="mt-3" v-if="submitCount > 0 && !meta.valid" is-error :title="t(`${moduleId}.general.warning`)">
    <template #body>{{ t(`${moduleId}.party.search.errors.at_least_one_field`) }}</template>
  </BiAlert>
</template>
