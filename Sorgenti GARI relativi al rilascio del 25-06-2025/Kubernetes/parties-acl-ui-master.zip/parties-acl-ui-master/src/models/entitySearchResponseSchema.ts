import { z } from "zod";
import { getNextPagedResultsSchema } from "@abaco/safe-rest/src/pagination";

export const EntityResponseSchema = z.object({
  id: z.number(),
  lastName: z.string().nullable().optional(),
  firstName: z.string().nullable().optional(),
  code: z.string().nullable().optional(),
});
export type EntityResponse = z.infer<typeof EntityResponseSchema>;

export const EntityResponseListSchema = getNextPagedResultsSchema(EntityResponseSchema);
export type EntitySearchResponseList = z.infer<typeof EntityResponseListSchema>;

export const EntityResponseArraySchema = z.object({
  entities: z.array(EntityResponseSchema),
});
export type EntitySearchResponseArray = z.infer<typeof EntityResponseArraySchema>;

export const EntityDossierConfigSchema = z.object({
  url: z.string(),
  description: z.string(),
  openNewTab: z.boolean().optional(),
  ssoFunctions: z.array(z.string()).nullable().optional(),
});
export type EntityDossierConfig = z.infer<typeof EntityDossierConfigSchema>;
export const EntityDossierConfigListSchema = z.array(EntityDossierConfigSchema);
export type EntityDossierConfigList = z.infer<typeof EntityDossierConfigListSchema>;
