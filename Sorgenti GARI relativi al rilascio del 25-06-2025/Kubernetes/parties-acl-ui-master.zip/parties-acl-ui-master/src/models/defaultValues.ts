import type { EntityFilterModel } from "./entities";
import type { UserFilterModel } from "./mandates";

export const DEFAULT_GROUP_FILTER: EntityFilterModel = {
  code: "",
  name: "",
  next_key: null,
  history: false,
};

export const DEFAULT_USER_FILTER: UserFilterModel = {
  username: "",
  next_key: null,
};
