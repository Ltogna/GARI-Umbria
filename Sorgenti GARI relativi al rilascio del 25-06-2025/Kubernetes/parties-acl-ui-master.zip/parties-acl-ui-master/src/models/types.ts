import { getNextPagedResultsSchema } from "@abaco/safe-rest/src/pagination";
import { z } from "zod";

export const PartyTypeSchema = z.object({
  id: z.number(),
  code: z.string(),
  fl_exclusive: z.boolean(),
  fl_manage: z.boolean(),
  description: z.string(),
});

export const EntityTypeSchema = z.object({
  id: z.number(),
  code: z.string(),
  description: z.string(),
  fl_entity_code_mandatory: z.boolean().optional(),
  party_types_list: z.array(PartyTypeSchema).optional(),
});

export type EntityTypeModel = z.infer<typeof EntityTypeSchema>;

export const InfiniteListEntityTypeSchema = getNextPagedResultsSchema(EntityTypeSchema);

export type InfiniteListEntityTypeModel = z.infer<typeof InfiniteListEntityTypeSchema>;

export const AddEntityTypePayloadSchema = z.object({
  code: z.string(),
  fl_entity_code_mandatory: z.boolean(),
  fl_single_relation: z.boolean(),
  fl_hidden: z.boolean(),
  translations: z.array(z.record(z.string())),
});

export type AddEntityTypePayloadModel = z.infer<typeof AddEntityTypePayloadSchema>;

export type PartyTypeSchema = z.infer<typeof PartyTypeSchema>;
export const InfiniteListPartyTypeSchema = getNextPagedResultsSchema(PartyTypeSchema);
export type InfiniteListPartyTypeModel = z.infer<typeof InfiniteListPartyTypeSchema>;

export const AddPartyTypePayloadSchema = z.object({
  code: z.string(),
  fl_exclusive: z.boolean(),
  fl_manage: z.boolean(),
  entity_type_codes: z.array(z.string()),
  translations: z.array(z.record(z.string())),
});

export type AddPartyTypePayloadModel = z.infer<typeof AddPartyTypePayloadSchema>;

export const UpdatePartyTypePayloadSchema = z.object({
  fl_exclusive: z.boolean(),
  fl_manage: z.boolean(),
  entity_type_codes: z.array(z.string()).optional(),
  translations: z.array(z.record(z.string())),
  emtpy: z.boolean().optional(),
});

export type UpdatePartyTypePayloadModel = z.infer<typeof UpdatePartyTypePayloadSchema>;
