/**
 * @deprecated
 */
export interface EntitySearchRequest {
  fullName: string;
  lastName: string;
  firstName: string;
  code: string;
}
