import { getNextPagedResultsSchema } from "@abaco/safe-rest/src/pagination";
import { z } from "zod";

export const FilterSchema = z.object({
  code: z.string().nullable().optional(),
  fullName: z.string().nullable().optional(),
});

export type FilterModel = z.infer<typeof FilterSchema>;

export const PartyFilterSchema = z.object({
  nextKey: z.string().optional(),
  lastName: z.string().optional(),
  firstName: z.string().optional(),
  taxCode: z.string().optional(),
  vatNumber: z.string().optional(),
  taxOrVat: z.string().optional(),
  code: z.string().optional(),
  hasCode: z.boolean().optional(),
  fullName: z.string().optional(),
  fullNameOrCode: z.string().optional(),
  tag: z.array(z.string()).optional(),
  archived: z.enum(["all", "only_archived", "not_archived"]).optional(),
  /**
   * #135540 acl value to access the resource: -1 skip check, 0 must have almost one read mandate, 1 must have almost one manage mandate
   */
  withManage: z.coerce.string().default("-1"),
});

export type PartyFilterSchema = z.infer<typeof PartyFilterSchema>;

export const PartySchema = z.object({
  id: z.number(),
  lastName: z.string().nullish(),
  firstName: z.string().nullish(),
  code: z.string().nullish(),
  exclusiveCount: z.number().nullish(),
  hasMandates: z.boolean().nullish(),
  mandatesCount: z.number().nullish(),
  manageCount: z.number().nullish(),
});
export type PartySchema = z.infer<typeof PartySchema>;

export const PartyListSchema = getNextPagedResultsSchema(PartySchema);
export type PartyListSchema = z.infer<typeof PartyListSchema>;

// export const PartyDossierConfigSchema = z.object({
//   url: z.string(),
//   description: z.string(),
//   openNewTab: z.boolean().optional(),
//   ssoFunctions: z.array(z.string()).nullable().optional(),
// });
// export type PartyDossierConfigSchema = z.infer<typeof PartyDossierConfigSchema>;
// export const PartyDossierConfigListSchema = z.array(PartyDossierConfigSchema);
// export type PartyDossierConfigList = z.infer<typeof PartyDossierConfigListSchema>;
