import { getNextPagedResultsSchema } from "@abaco/safe-rest/src/pagination";
import { z } from "zod";
import { DocumentDataFieldSchema, DocumentDataSchema } from "@abaco/dynamic-documents/src/resources/models";

export const SummaryFieldDefinitionSchema = z.object({
  code: z.string(),
  description: z.string(),
  fieldType: z.string(),
});

export const DynamiDocumentDataSchema = z.record(z.string().min(1), z.unknown());

export const DynamiDocumentSchema = z.object({
  entity_id: z.number().nullable().optional(),
  definition_code: z.string().nullable().optional(),
  document_id: z.number().nullable().optional(),
  bucket_name: z.string().nullable().optional(),
  summary_field_definitions: z.array(SummaryFieldDefinitionSchema).nullish(),
  data: DynamiDocumentDataSchema,
  mandate_id: z.number().nullable().optional(),
});
export const DynamiDocumentListSchema = getNextPagedResultsSchema(DynamiDocumentSchema);

export const DynamiDocumentMap = DocumentDataSchema.extend({
  id: z.string().nullish(),
  document_id: z.number().nullable().optional(),
  data: DynamiDocumentDataSchema,
});

export const DocumentDataRecordSchema = z.record(z.string().min(1), z.union([DocumentDataFieldSchema, z.array(DocumentDataFieldSchema)]));

export type DynamiDocumentDataModel = z.infer<typeof DynamiDocumentDataSchema>;
export type DynamiDocumentModel = z.infer<typeof DynamiDocumentSchema>;
export type DynamiDocumentListModel = z.infer<typeof DynamiDocumentListSchema>;
export type DynamiDocumentMapModel = z.infer<typeof DynamiDocumentMap>;
export type DocumentDataRecordModel = z.infer<typeof DocumentDataRecordSchema>;
