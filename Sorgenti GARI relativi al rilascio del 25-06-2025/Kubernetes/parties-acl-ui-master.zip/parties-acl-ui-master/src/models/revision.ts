import { z } from "zod";
import { dateToString } from "./utils";
import { getNextPagedResultsSchema } from "@abaco/safe-rest/src/pagination";

export enum OperationType {
  ADD_USER = "ADD_USER",
  ADD_PARTY = "ADD_PARTY",
  REMOVE_USER = "REMOVE_USER",
  REMOVE_PARTY = "REMOVE_PARTY",
  TRUNC_PATH = "TRUNC_PATH",
  EXT_PATH = "EXT_PATH",
}

export const RevisionHistorySchema = z.object({
  id: z.number(),
  operation: z.nativeEnum(OperationType),
  objectId: z.string(),
  oldPath: z.string().optional(),
  newPath: z.string().optional(),
  objectData: z.string().optional(),
  revisionDate: dateToString,
});

export type RevisionHistoryModel = z.infer<typeof RevisionHistorySchema>;

export const PaginatedRevisionHistoryListSchema = getNextPagedResultsSchema(RevisionHistorySchema);

export type PaginatedRevisionHistoryListModel = z.infer<typeof PaginatedRevisionHistoryListSchema>;
