import { MODULE_ID } from "@/constants";

export enum RouteName {
  PARTY_LIST = `${MODULE_ID}:partyList`,
  PARTY_DETAILS = `${MODULE_ID}:partyDetails`,
  MANDATE_NEW = `${MODULE_ID}:mandateNew`,
  MANDATE_EDIT = `${MODULE_ID}:mandateEdit`,
  MANDATE_REVOKE = `${MODULE_ID}:mandateRevoke`,
  MANDATE_DOC = `${MODULE_ID}:mandatedoc`,
  MANDATE_NEW_MULTIPLE_DOC = `${MODULE_ID}:mandateNewDoc`,
  MANDATE_EDIT_MULTIPLE_DOC = `${MODULE_ID}:mandateEditDoc`,
  MANDATE_DETAILS = `${MODULE_ID}:mandateDetails`,
  GROUP = `${MODULE_ID}:group`,
  GROUP_NEW = `${GROUP}:new`,
  GROUP_LIST = `${GROUP}:list`,
  GROUP_DETAILS = `${GROUP}:details`,
  GROUP_USERS = `${GROUP}:users`,
  GROUP_HIERARCHY = `${GROUP}:hierarchy`,
  // GROUP_CLOSE = `${GROUP}:close`,
}
