import { z } from "zod";

export enum AnomalyTypeLevel {
  DANGER = "DANGER",
  WARN = "WARN",
  INFO = "INFO",
  UNCATEGORIZED = "UNCATEGORIZED",
}
export const AnomalyTypeSchema = z.object({
  groupCode: z.string().optional(),
  code: z.string().optional(),
  i18nCode: z.string().optional(),
  level: z.nativeEnum(AnomalyTypeLevel).optional(),
});

export const AnomalySchema = z.object({
  entityCode: z.string().optional(),
  entityId: z.string().optional(),
  dt_insert: z.string().optional(),
  type: AnomalyTypeSchema,
});

export const AnomaliesListSchema = z.object({
  anomalies_list: z.array(AnomalySchema),
  error: z.string(),
});

export type AnomaliesListModel = z.infer<typeof AnomaliesListSchema>;
