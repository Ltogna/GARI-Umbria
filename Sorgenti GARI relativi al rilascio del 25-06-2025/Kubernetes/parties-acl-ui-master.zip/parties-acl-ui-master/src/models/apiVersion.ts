import { z } from "zod";

export const PartiesAclServerVersionSchema = z.object({
  buildtime: z.string().optional(),
  commitId: z.string(),
  description: z.string().optional(),
  name: z.string(),
  version: z.string(),
});

export type PartiesAclServerVersionSchema = z.infer<typeof PartiesAclServerVersionSchema>;
