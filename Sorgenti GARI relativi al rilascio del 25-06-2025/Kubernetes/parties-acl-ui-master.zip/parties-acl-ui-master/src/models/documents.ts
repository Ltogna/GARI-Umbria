import { z } from "zod";

export enum ScopeCode {
  GROUPS = "GROUPS",
  MANDATES = "MANDATES",
}

export const SummaryFieldDefinitionSchema = z.object({
  code: z.string(),
  description: z.string(),
  fieldType: z.string(),
});

export const BaseDocumentTypeSchema = z.object({
  definitionCode: z.string(),
  definitionCodeI18n: z.string(),
  flRequired: z.boolean().default(false),
  flReqOnAdd: z.boolean().default(false),
  flReqOnClose: z.boolean().default(false),
  entityId: z.number(),
  flDocPresent: z.number(),
  mandateId: z.number(),
  multiple: z.boolean().default(false),
  summaryFieldDefinitions: z.array(SummaryFieldDefinitionSchema).nullish(),
});
export const MultipleDocumentTypeSchema = BaseDocumentTypeSchema.extend({
  multiple: z.literal(true),
});
export const SingleDocumentTypeSchema = MultipleDocumentTypeSchema.extend({
  multiple: z.literal(false),
  documentId: z.number().nullish(),
});

export const DocumentTypeSchema = z.discriminatedUnion("multiple", [MultipleDocumentTypeSchema, SingleDocumentTypeSchema]);

export const DocumentTypeListSchema = z.array(DocumentTypeSchema);

export type DocumentTypeModel = z.infer<typeof DocumentTypeSchema>;
export type DocumentTypeListModel = z.infer<typeof DocumentTypeListSchema>;
