import { z } from "zod";
import { stringToDate as stringToDateFn, dateToString as dateToStringFn } from "@/utils/dates";

/**
 * Acccept a format like _yyyyMMdd_ and return a `Date`
 */
export const stringToDate = z.preprocess(stringToDateFn, z.date());
/**
 * Accept a date or a number and return a string like _yyyyMMdd_
 *
 * if `arg` is a string and string has a format like _yyyyMMdd_ the return `arg`
 */
export const dateToString = z.preprocess(dateToStringFn, z.string().or(z.number()));
