import { z } from "zod";

export const ClientConfigurationSchema = z.object({
  name: z.string().optional(),
  value: z.unknown().optional(),
});

export type ClientConfigurationModel = z.infer<typeof ClientConfigurationSchema>;

export const ClientConfigurationListSchema = z.object({
  client_configuration: z.array(ClientConfigurationSchema),
});

export type ClientConfigurationListModel = z.infer<typeof ClientConfigurationListSchema>;
