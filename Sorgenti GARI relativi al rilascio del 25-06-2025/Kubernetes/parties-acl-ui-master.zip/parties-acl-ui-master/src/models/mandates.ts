import { z } from "zod";
import { dateToString } from "./utils";
import { getNextPagedResultsSchema } from "@abaco/safe-rest/src/pagination";
import { EntitySchema } from "./entities";
import { PartyTypeSchema } from "./types";
import { stringToDate } from "@/models/utils";

export const PartySchema = z.object({
  id: z.string(),
  party_type_code: z.string(),
  day_from: dateToString,
  day_to: dateToString.nullable(),
});

export type PartyModel = z.infer<typeof PartySchema>;

export const PartyListSchema = z.object({
  partyList: z.array(PartySchema),
});

export type PartyListModel = z.infer<typeof PartyListSchema>;

export const UserSchema = z.object({
  id: z.string(),
  role: z.string(),
  username: z.string(),
  description: z.string().nullish(),
});

export type UserModel = z.infer<typeof UserSchema>;

export const NewUserSchema = UserSchema.omit({ id: true });

export type NewUserModel = z.infer<typeof NewUserSchema>;

export const PathUserSchema = z.object({
  id: z.string(),
  role: z.string(),
});

export type PathUserModel = z.infer<typeof PathUserSchema>;

export const PathPartySchema = PathUserSchema.extend({
  role: z.string(),
});

export type PathPartyModel = z.infer<typeof PathPartySchema>;

export const PathDetailsSchema = z.object({
  path: z.string(),
  mandatorUserList: z.array(PathUserSchema),
  partyList: z.array(PathPartySchema).optional(),
});

export type PathDetailsModel = z.infer<typeof PathDetailsSchema>;

export const UpdateEntityPartyPayloadSchema = z.object({
  day_to: dateToString.nullable().optional(),
  close_day: dateToString.nullable().optional(),
  revoke: z.boolean().optional(),
});

export type UpdateEntityPartyPayloadModel = z.infer<typeof UpdateEntityPartyPayloadSchema>;

export const UpdateEntityUserPayloadSchema = z.object({
  role: z.string().optional(),
  description: z.string().optional(),
});

export type UpdateEntityUserPayloadModel = z.infer<typeof UpdateEntityUserPayloadSchema>;

export const UserFilterSchema = z.object({
  username: z.string(),
  next_key: z.string().nullish(),
});

export type UserFilterModel = z.infer<typeof UserFilterSchema>;

export enum StatusCodeEnum {
  VALID = "VALID",
  NOT_VALID = "NOT_VALID",
  CLOSED = "CLOSED",
}

const StatusCodeEnumSchema = z.nativeEnum(StatusCodeEnum);

export const PartyWithEntitySchema = z.object({
  id: z.string(),
  mandate_id: z.number(),
  party_type: PartyTypeSchema,
  entity: EntitySchema,
  editable: z.boolean().nullish(),
  day_from: stringToDate,
  day_to: stringToDate.nullish(),
  status: StatusCodeEnumSchema,
  revocable: z.boolean().default(false),
});

export type PartyWithEntityModel = z.infer<typeof PartyWithEntitySchema>;

export const InfiniteListPartyWithEntitySchema = getNextPagedResultsSchema(PartyWithEntitySchema);

export type InfiniteListPartyWithEntityModel = z.infer<typeof InfiniteListPartyWithEntitySchema>;

export const InfiniteListUserSchema = getNextPagedResultsSchema(UserSchema);

export type InfiniteListUserModel = z.infer<typeof InfiniteListUserSchema>;
