import { getNextPagedResultsSchema } from "@abaco/safe-rest/src/pagination";
import { z } from "zod";
import { dateToString, stringToDate } from "./utils";
import { EntityTypeSchema } from "./types";

//TODO same in mandates (role using enum) => role solo admin
export const UserSchema = z.object({
  id: z.string(),
  role: z.string(),
  username: z.string(),
  description: z.string().nullish(),
});

export type UserModel = z.infer<typeof UserSchema>;

export const EntitySchema = z.object({
  /**
   * Entity id
   */
  id: z.number(),
  /**
   * Code of Entity
   */
  code: z.string().nullish(),
  /**
   * Entity's name
   */
  name: z.string(),

  entity_type: EntityTypeSchema,

  /**
   * Registry party id. If present, can't change denomination
   */
  registry_party_id: z.number().or(z.string()).nullish(),
  /**
   * Description of the entity
   */
  description: z.string().nullish(),
  /**
   * Entity's parent Id
   */
  parent_id: z.number().nullish(),
  /**
   * Entity's parent Name
   */
  parent_name: z.string().nullish(),
  /**
   * Entity's parent Code
   */
  parent_code: z.string().nullish(),
  /**
   * Entity's tree path
   */
  path: z.string(),
  day_from: stringToDate,
  close_day: stringToDate,
  day_to: stringToDate.nullish(),
  admin_users: z.array(z.string()).nullable().optional(),
  /**
   * Current user role, null if not associated
   */
  current_user_role: z.string().nullable(),

  closed: z.boolean(),
  //TODO: wating for updated api, never nullish
  editable: z.boolean().nullish().default(false),
});

export type EntityModel = z.infer<typeof EntitySchema>;

export const InfiniteListEntitySchema = getNextPagedResultsSchema(EntitySchema);

export type InfiniteListEntityModel = z.infer<typeof InfiniteListEntitySchema>;

export const CreateEntityPayloadSchema = z.object({
  code: z.string().nullish(),
  name: z.string().optional(),
  description: z.string().optional(),
  entity_type_code: z.string(),
  registry_party_id: z.number().or(z.string()).optional(),
  day_from: dateToString,
  day_to: dateToString.optional(),
});

export type CreateEntityPayloadModel = z.infer<typeof CreateEntityPayloadSchema>;

export const UpdateEntityPayloadSchema = z.object({
  code: z.string().optional(),
  name: z.string().optional(),
  description: z.string().optional(),
  registry_party_id: z.number().or(z.string()).optional(),
  day_from: dateToString.optional(),
  day_to: dateToString.optional(),
  entity_type_code: z.string().optional(),

  empty: z.boolean().optional(),
});

export type UpdateEntityPayloadModel = z.infer<typeof UpdateEntityPayloadSchema>;

export const EntityFilterSchema = z.object({
  referenceDate: dateToString.optional(),
  name: z.string().optional(),
  code: z.string().optional(),
  registryId: z.string().optional(),
  next_key: z.string().or(z.number()).nullish(),
  history: z.boolean().optional(),
});

export type EntityFilterModel = z.infer<typeof EntityFilterSchema>;

export const NewGroupFormSchema = z.object({
  denomination: z.string(),
  type: z.string(),
  startDate: z.date(),
  code: z.string().optional(),
  description: z.string().nullish(),
});

export type NewGroupFormModel = z.infer<typeof NewGroupFormSchema>;

export const CloseGroupPayloadSchema = z.object({
  day_to: dateToString.nullable().optional(),
  close_day: dateToString,
});

export type CloseGroupPayloadModel = z.infer<typeof CloseGroupPayloadSchema>;
