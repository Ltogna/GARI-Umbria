<script setup lang="ts">
import BiCallout from "@abaco/bootstrap-italia-components/src/components/BiCallout/BiCallout.vue";
import { computed, onMounted, onUnmounted } from "vue";
import { useI18n } from "vue-i18n";
import { RouterView } from "vue-router";
import usePermissions from "./composables/usePermissions";
import BiNotification from "@abaco/bootstrap-italia-components/src/components/BiNotification/BiNotification.vue";
import { useNotification } from "./composables/useApiResponseHandler";
import { useConfigStore } from "./stores/config";

const { t } = useI18n();
const { canRead } = usePermissions();
const { message } = useNotification();

const partiesAclAllowed = computed(() => canRead);
const { loadConfig } = useConfigStore();

onUnmounted(async () => {
  //
});

onMounted(async () => await loadConfig());

const notificationProps = computed(() => {
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const { open: _1, ...rest } = message;
  return rest;
});
</script>

<template>
  <div v-if="partiesAclAllowed" class="parties-acl">
    <main class="my-2">
      <section>
        <RouterView />
        <RouterView name="leaveConfirmationModal" />
      </section>
    </main>
  </div>
  <BiCallout v-else type="danger" :title="t('parties-acl.alerts.user_not_allowed_title')" class="mx-auto">
    <p>{{ t("parties-acl.alerts.user_not_allowed_text") }}</p>
  </BiCallout>
  <BiNotification v-bind="notificationProps" v-model="message.open" />
</template>
