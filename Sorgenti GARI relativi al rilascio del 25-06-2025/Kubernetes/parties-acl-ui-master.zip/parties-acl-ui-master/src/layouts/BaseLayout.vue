<script setup lang="ts"></script>

<template>
  <main>
    <section>
      <div class="container">
        <div class="row">
          <div class="col-md-12">
            <article class="scheda scheda-round shadow-sm mt-2">
              <div class="scheda-icona-small border-bottom border-primary px-3 pt-1">
                <h3 class="primary-color">
                  <!-- title -->
                </h3>
              </div>
              <div class="px-3 pt-4 pb-1">
                <div class="it-list-wrapper">
                  <div class="row">
                    <div class="col-md-3 col-sm-12 mb-1">
                      <div class="parties-acl__parcel-details it-line-right-side">
                        <!-- left -->
                      </div>
                    </div>
                    <div class="col-md-9 col-sm-12 mb-1">
                      <!-- right -->
                      <slot />
                    </div>
                  </div>
                </div>
              </div>
            </article>
          </div>
        </div>
      </div>
    </section>
  </main>
</template>
