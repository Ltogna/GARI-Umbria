import {
  InfiniteListPartyWithEntitySchema,
  InfiniteListUserSchema,
  PartyListSchema,
  PartyWithEntitySchema,
  PathDetailsSchema,
  type InfiniteListPartyWithEntityModel,
  type InfiniteListUserModel,
  type NewUserModel,
  type PartyListModel,
  type PartyModel,
  type PartyWithEntityModel,
  type PathDetailsModel,
  type UpdateEntityPartyPayloadModel,
  type UpdateEntityUserPayloadModel,
  type UserFilterModel,
  type UserModel,
} from "@/models/mandates";
import { getValuable } from "@/utils/getValuable";
import { type HttpJsonResult, type HttpResult } from "@abaco/safe-rest/src/HTTPClient";
import { z } from "zod";
import { httpPartiesACLServer as http } from "./http";

/**
 * Add parties to Entity
 * @param entity
 * @returns
 */
export const addPartiesToEntity = async (entityId: number | string, party: PartyModel): Promise<HttpJsonResult<number>> => {
  const params = getValuable(party);
  return http.postJson(z.number(), `/api-priv/v1/parties-acl/entities/${entityId}/parties`, params);
};

/**
 * Add user to party
 * @param entity
 * @returns
 */
export const addUserToParty = async (partyId: number, newUser: UserModel): Promise<HttpJsonResult<boolean>> => {
  return http.postJson(z.boolean(), `/api-priv/v1/parties-acl/parties/${partyId}`, newUser);
};

/**
 * Add user to Entity
 * @param entityId
 * @param newUser
 * @returns
 */
export const addUserToEntity = async (entityId: number, newUser: NewUserModel): Promise<HttpJsonResult<boolean>> => {
  return http.postJson(z.boolean(), `/api-priv/v1/parties-acl/entities/${entityId}/users`, newUser);
};

/**
 * GET parties by mandator user id
 * @param userId
 * @param partyId
 * @returns
 */
export const getPartiesByUserId = async (userId: string, partyId: number): Promise<HttpJsonResult<PartyListModel>> => {
  return http.getJson(PartyListSchema, `/api-priv/v1/parties-acl/users/${userId}/parties/${partyId}`);
};

/**
 * GET parties by Entity user id
 * @param userId
 * @returns
 */
export const getPartiesByEntityUserId = async (userId: string): Promise<HttpJsonResult<PartyListModel>> => {
  return http.getJson(PartyListSchema, `/api-priv/v1/parties-acl/users/${userId}/parties`);
};

/**
 * Get flat mandates data
 * @param userId
 * @returns
 */
export const getFlatMandatesData = async (next_key?: string): Promise<HttpJsonResult<PathDetailsModel>> => {
  const params = getValuable({ next_key });

  return http.getJson(PathDetailsSchema, `/api-priv/v1/parties-acl/mandates`, {
    params,
  });
};

/**
 * Update an entity
 * @param entityId
 * @param updateEntityData
 * @returns
 */
export const updateEntity = async (
  entityId: number,
  partyId: string,
  updateEntityData: UpdateEntityPartyPayloadModel,
): Promise<HttpJsonResult<boolean>> => {
  return http.putJson(z.boolean(), `/api-priv/v1/parties-acl/entities/${entityId}/parties/${partyId}`, updateEntityData);
};

/**
 * Remove party from Entity
 * @param entityId
 * @param partyId
 * @returns
 */
export const deletePartyFromEntity = async (entityId: number, partyId: string): Promise<HttpResult> => {
  return await http.delete(`/api-priv/v1/parties-acl/entities/${entityId}/parties/${partyId}`);
};

/**
 * Update User in entity
 * @param entityId
 * @param userId
 * @param updateEntityUserData
 * @returns
 */
export const updateUserInEntity = async (
  entityId: number,
  userId: string,
  updateEntityUserData: UpdateEntityUserPayloadModel,
): Promise<HttpJsonResult<boolean>> => {
  const encodedUserId = encodeURIComponent(userId);
  return http.putJson(z.boolean(), `/api-priv/v1/parties-acl/entities/${entityId}/users/${encodedUserId}`, updateEntityUserData);
};

/**
 * Remove user from Entity
 * @param entityId
 * @param userId
 * @returns
 */
export const deleteUserFromEntity = async (entityId: number, userId: string): Promise<HttpResult> => {
  const encodedUserId = encodeURIComponent(userId);
  return await http.delete(`/api-priv/v1/parties-acl/entities/${entityId}/users/${encodedUserId}`);
};

/**
 * Update user in Party
 * @param partyId
 * @param userId
 * @param updateEntityUserData
 * @returns
 */
export const updateUserInParty = async (
  partyId: number,
  userId: string,
  updateEntityUserData: UpdateEntityUserPayloadModel,
): Promise<HttpJsonResult<boolean>> => {
  const encodedUserId = encodeURIComponent(userId);
  return http.putJson(z.boolean(), `/api-priv/v1/parties-acl/parties/${partyId}/users/${encodedUserId}`, updateEntityUserData);
};

/**
 * Remove user from Party
 * @param partyId
 * @param userId
 * @returns
 */
export const deleteUserFromParty = async (partyId: number, userId: string): Promise<HttpResult> => {
  return await http.delete(`/api-priv/v1/parties-acl/parties/${partyId}/users/${userId}`);
};

/**
 * GET mandates by partyId
 * @param partyId
 * @returns
 */
export const getMandatesByPartyId = async (
  partyId: number,
  history?: boolean,
  next_key?: string,
): Promise<HttpJsonResult<InfiniteListPartyWithEntityModel>> => {
  const params = getValuable({ history, next_key });

  return http.getJson(InfiniteListPartyWithEntitySchema, `/api-priv/v1/parties-acl/parties/${partyId}/entities`, { params });
};

/**
 * GET users by entity id
 * @param entityId
 * @param next_key
 * @returns
 */
export const getUsersByEntity = (entityId: number, filter?: UserFilterModel): Promise<HttpJsonResult<InfiniteListUserModel>> => {
  const params = filter && getValuable(filter);

  return http.getJson(InfiniteListUserSchema, `/api-priv/v1/parties-acl/entities/${entityId}/users`, { params });
};

/**
 * GET mandate detail by entityId
 * @param mandateId
 * @returns
 */
export const getMandateById = async (mandateId: number): Promise<HttpJsonResult<PartyWithEntityModel>> => {
  return http.getJson(PartyWithEntitySchema, `/api-priv/v1/parties-acl/mandates/${mandateId}`);
};

/**
 * Update an mandate end date
 * @param mandateId
 * @returns
 */
export const updateCloseDate = async (mandateId: number, updateEntityData: UpdateEntityPartyPayloadModel): Promise<HttpJsonResult<boolean>> => {
  return http.postJson(z.boolean(), `/api-priv/v1/parties-acl/mandates/${mandateId}/closedate`, updateEntityData);
};

/**
 * Remove mandate AKA "Errore Materiale"
 * @param mandateId
 * @returns
 */
export const deleteMandate = async (mandateId: number | string): Promise<HttpResult> => {
  return await http.delete(`/api-priv/v1/parties-acl/mandates/${mandateId}`);
};
