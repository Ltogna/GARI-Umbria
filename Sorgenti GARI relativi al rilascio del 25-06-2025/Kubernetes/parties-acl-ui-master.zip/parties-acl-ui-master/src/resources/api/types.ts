import {
  EntityTypeSchema,
  InfiniteListEntityTypeSchema,
  InfiniteListPartyTypeSchema,
  PartyTypeSchema,
  type AddEntityTypePayloadModel,
  type AddPartyTypePayloadModel,
  type EntityTypeModel,
  type InfiniteListEntityTypeModel,
  type InfiniteListPartyTypeModel,
  type UpdatePartyTypePayloadModel,
} from "@/models/types";
import { getValuable } from "@/utils/getValuable";
import type { HttpJsonResult, HttpResult } from "@abaco/safe-rest/src/HTTPClient";
import { z } from "zod";
import { httpPartiesACLServer as http } from "./http";

/**
 * Get all Entity types
 * @param next_key
 * @param code
 * @returns
 */
export const getAllEntityTypes = async (
  next_key?: string | null,
  code?: string,
  partyTypeList = false,
): Promise<HttpJsonResult<InfiniteListEntityTypeModel>> => {
  const params = getValuable({ code, next_key, partyTypeList });

  return http.getJson(InfiniteListEntityTypeSchema, `/api-priv/v1/parties-acl/entities/types`, { params });
};

/**
 * Add Entity type
 * @param entityTypeData
 * @returns
 */
export const addEntityType = async (entityTypeData: AddEntityTypePayloadModel): Promise<HttpJsonResult<boolean>> => {
  return http.postJson(z.boolean(), `/api-priv/v1/parties-acl/entities/types`, entityTypeData);
};

/**
 * GET Party type
 * @param id
 * @param code
 * @returns
 */
export const getAllPartyTypes = async (code?: string, next_key?: string): Promise<HttpJsonResult<InfiniteListPartyTypeModel>> => {
  const params = getValuable({ code, next_key });

  return http.getJson(InfiniteListPartyTypeSchema, `/api-priv/v1/parties-acl/parties/types`, { params });
};

/**
 * Add Party type
 * @param partyTypeData
 * @returns
 */
export const addPartyType = async (partyTypeData: AddPartyTypePayloadModel): Promise<HttpJsonResult<boolean>> => {
  return http.postJson(z.boolean(), `/api-priv/v1/parties-acl/parties/types`, partyTypeData);
};

/**
 * Get Entity type by id
 * @param id
 * @returns
 */
export const getEntityType = async (id: number, partyTypeList = false): Promise<HttpJsonResult<EntityTypeModel>> => {
  const params = { partyTypeList };
  return http.getJson(EntityTypeSchema, `/api-priv/v1/parties-acl/entities/types/${id}`, { params });
};

/**
 * Delete Entity type
 * @param id
 * @returns
 */
export const deleteEntityType = async (id: number): Promise<HttpResult> => {
  return await http.delete(`/api-priv/v1/parties-acl/entities/types/${id}`);
};

/**
 * Get Party type by id
 * @param id
 * @returns
 */
export const getPartyType = async (id: number): Promise<HttpJsonResult<PartyTypeSchema>> => {
  return http.getJson(PartyTypeSchema, `/api-priv/v1/parties-acl/parties/types/${id}`);
};

/**
 * Update Party type
 * @param id
 * @param partyTypeData
 * @returns
 */
export const updatePartyType = async (id: number, partyTypeData: UpdatePartyTypePayloadModel): Promise<HttpJsonResult<boolean>> => {
  return http.postJson(z.boolean(), `/api-priv/v1/parties-acl/parties/types/${id}`, partyTypeData);
};

/**
 * Delete Party type
 * @param id
 * @returns
 */
export const deletePartyType = async (id: number): Promise<HttpResult> => {
  return await http.delete(`/api-priv/v1/parties-acl/parties/types/${id}`);
};
