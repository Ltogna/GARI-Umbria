import {
  EntitySchema,
  InfiniteListEntitySchema,
  type CloseGroupPayloadModel,
  type CreateEntityPayloadModel,
  type EntityFilterModel,
  type EntityModel,
  type InfiniteListEntityModel,
  type UpdateEntityPayloadModel,
} from "@/models/entities";
import { getValuable } from "@/utils/getValuable";
import type { HttpJsonResult, HttpResult } from "@abaco/safe-rest/src/HTTPClient";
import z from "zod";
import { httpPartiesACLServer as http } from "./http";

/**
 * Add child to parent
 * @param entityId
 * @param childId
 * @returns
 */
export const addChildEntity = async (entityId: number, childId: number, forceUpdate = false): Promise<HttpJsonResult<boolean>> => {
  const params = { forceUpdate };
  return http.putJson(z.boolean(), `/api-priv/v1/parties-acl/entities/${entityId}/children/${childId}`, undefined, { params });
};

/**
 * Get entity children
 * @param entityId
 * @param next_key
 * @param includeAllLevels
 */
export const getChildrenEntity = async (
  entityId: number,
  next_key: string | null = null,
  includeAllLevels = false,
): Promise<HttpJsonResult<InfiniteListEntityModel>> => {
  const params = getValuable({ next_key, includeAllLevels });
  return http.getJson(InfiniteListEntitySchema, `/api-priv/v1/parties-acl/entities/${entityId}/children`, { params });
};

/**
 * Remove child from parent
 * @param entityId
 * @param childId
 * @returns
 */
export const deleteChildEntity = async (entityId: number, childId: number): Promise<HttpResult> => {
  return await http.delete(`/api-priv/v1/parties-acl/entities/${entityId}/children/${childId}`);
};

/**
 * Gets List of existing entities
 * @param filter
 * @returns
 */
export const getEntitiesList = async (filter?: EntityFilterModel): Promise<HttpJsonResult<InfiniteListEntityModel>> => {
  const params = filter && getValuable(filter);
  return http.getJson(InfiniteListEntitySchema, `/api-priv/v1/parties-acl/entities`, {
    params,
  });
};

/**
 * Gets List of existing entities
 * @param id
 * @returns
 */
export const getEntity = async (id: number): Promise<HttpJsonResult<EntityModel>> => {
  return http.getJson(EntitySchema, `/api-priv/v1/parties-acl/entities/${id}`);
};

/**
 * Creates new entity
 * @param entity
 * @returns
 */
export const createEntity = async (entity: CreateEntityPayloadModel): Promise<HttpJsonResult<number>> => {
  return http.postJson(z.number(), `/api-priv/v1/parties-acl/entities`, entity);
};

/**
 * Update an entity
 * @param entityId
 * @param entity
 * @returns
 */
export const updateEntity = async (entityId: number, entity: UpdateEntityPayloadModel): Promise<HttpJsonResult<boolean>> => {
  return http.putJson(z.boolean(), `/api-priv/v1/parties-acl/entities/${entityId}`, entity);
};

/**
 * Deletes entity by Id
 * @param entityId
 * @returns
 */
export const deleteEntity = async (entityId: number): Promise<HttpResult> => {
  return await http.delete(`/api-priv/v1/parties-acl/entities/${entityId}`);
};

/**
 * Close Entity
 * @param entityId
 * @param closeGroupPayload
 */
export const closeEntity = async (entityId: number, closeGroupPayload: CloseGroupPayloadModel): Promise<HttpJsonResult<boolean>> => {
  return http.postJson(z.boolean(), `/api-priv/v1/parties-acl/entities/${entityId}/closedate`, closeGroupPayload);
};
