import { PartyListSchema, PartySchema, type PartyFilterSchema } from "@/models/parties";
import { getValuable } from "@/utils/getValuable";
import type { HttpJsonResult } from "@abaco/safe-rest/src/HTTPClient";
import { httpClientPartyRegistryServer as http, httpPartiesACLServer } from "./http";

/**
 * Gets List of existing entities
 * @param filter
 * @returns
 */
export const getParties = async (filter?: PartyFilterSchema): Promise<HttpJsonResult<PartyListSchema>> => {
  const params = filter && getValuable(filter);
  return httpPartiesACLServer.getJson(PartyListSchema, `/public/v1/parties-acl/proxy/parties`, {
    /**
     * #135540 acl value to access the resource: -1 skip check, 0 must have almost one read mandate, 1 must have almost one manage mandate
     */
    params,
  });
};

/**
 * #135540 acl value to access the resource: -1 skip check, 0 must have almost one read mandate, 1 must have almost one manage mandate
 */
export const getPartyById = async (id: string, withManage = "-1"): Promise<HttpJsonResult<PartySchema>> => {
  return http.getJson(PartySchema, `/public/v1/parties/${id}`, { params: { withManage } });
};
