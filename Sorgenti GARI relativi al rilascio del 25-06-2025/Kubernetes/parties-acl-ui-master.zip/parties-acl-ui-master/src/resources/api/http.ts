import { PREFIX_PARTIES_ACL_SERVER_API, PREFIX_PARTY_REGISTRY_SERVER_API } from "@/constants";
import { isStandalone } from "@/utils/isStandalone";
import { ErrorType, HTTPClient, type HTTPClientOptions, type HttpResult, type RequestConfig } from "@abaco/safe-rest/src/HTTPClient";
import { getUserData, installSso2RequestConfigProvider } from "@abaco/safe-rest/src/sso2";
import { login } from "./loginStandalone";

class HTTPClientPartiesACLServer extends HTTPClient {
  prefix = PREFIX_PARTIES_ACL_SERVER_API;
  constructor(config: HTTPClientOptions = {}) {
    super(config);
  }

  protected async performCall(method: string, url: string, config?: RequestConfig | undefined, body?: BodyInit | undefined): Promise<HttpResult> {
    const user = getUserData();
    if (!user) {
      return {
        errorType: ErrorType.OTHER,
        err: 401,
      };
    }
    return super.performCall(method, `${this.prefix}/${user.tenant}${url}`, config, body);
  }
}
class HTTPClientPartyRegistryServer extends HTTPClient {
  prefix = PREFIX_PARTY_REGISTRY_SERVER_API;
  constructor(config: HTTPClientOptions = {}) {
    super(config);
  }

  protected async performCall(method: string, url: string, config?: RequestConfig | undefined, body?: BodyInit | undefined): Promise<HttpResult> {
    const user = getUserData();
    if (!user) {
      return {
        errorType: ErrorType.OTHER,
        err: 401,
      };
    }
    return super.performCall(method, `${this.prefix}/${user.tenant}${url}`, config, body);
  }
}

export const httpPartiesACLServer = new HTTPClientPartiesACLServer();
export const httpClientPartyRegistryServer = new HTTPClientPartyRegistryServer();
export const http = new HTTPClient();
installSso2RequestConfigProvider(httpClientPartyRegistryServer, "/sso2");
installSso2RequestConfigProvider(httpPartiesACLServer, "/sso2");
installSso2RequestConfigProvider(http, "/sso2");

if (isStandalone) {
  login({
    tenant: import.meta.env.VITE_TENANT,
    username: import.meta.env.VITE_USERNAME,
    password: import.meta.env.VITE_PASSWORD,
  });
}
