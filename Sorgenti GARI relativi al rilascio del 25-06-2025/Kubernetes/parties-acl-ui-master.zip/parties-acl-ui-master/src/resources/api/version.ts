import { PartiesAclServerVersionSchema } from "@/models/apiVersion";
import type { HttpJsonResult } from "@abaco/safe-rest/src/HTTPClient";
import { httpPartiesACLServer as http } from "./http";

/**
 * Gets List of existing entities
 * @param filter
 * @returns
 */
export const getPartiesAclVersion = async (): Promise<HttpJsonResult<PartiesAclServerVersionSchema>> => {
  return http.getJson(PartiesAclServerVersionSchema, `/api-priv/v1/parties-acl/utility/api.version`);
};
