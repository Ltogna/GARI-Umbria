import { PaginatedRevisionHistoryListSchema, type PaginatedRevisionHistoryListModel } from "@/models/revision";
import { getValuable } from "@/utils/getValuable";
import type { HttpJsonResult } from "@abaco/safe-rest/src/HTTPClient";
import { httpPartiesACLServer as http } from "./http";

/**
 * GET revision history by id
 * @param fromId
 * @param nextKey
 * @returns
 */
export const getPaginatedRevisionHistory = async (
  /**
   * Specify the last id syncronized from the client
   */
  fromId?: number,
  nextKey?: string,
): Promise<HttpJsonResult<PaginatedRevisionHistoryListModel>> => {
  const params = getValuable({ fromId, nextKey });

  return http.getJson(PaginatedRevisionHistoryListSchema, `/api-priv/v1/parties-acl/revisions`, { params });
};
