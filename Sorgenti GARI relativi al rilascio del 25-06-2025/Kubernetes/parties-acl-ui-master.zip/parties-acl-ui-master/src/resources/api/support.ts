import { ClientConfigurationListSchema, type ClientConfigurationListModel } from "@/models/support";
import { getValuable } from "@/utils/getValuable";
import type { HttpJsonResult } from "@abaco/safe-rest/src/HTTPClient";
import { httpPartiesACLServer as http } from "./http";

/**
 * GET config key string value
 * @param configKey
 * @returns
 */
export const getConfigKeyStringValue = async (configKey: string): Promise<HttpJsonResult<ClientConfigurationListModel>> => {
  return http.getJson(ClientConfigurationListSchema, `/api-priv/v1/parties-acl/support/config/${configKey}`);
};

/**
 * GET config codes
 * @param key
 * @returns
 */
export const getConfigCodes = async (key?: string): Promise<HttpJsonResult<ClientConfigurationListModel>> => {
  const params = getValuable({ key });

  return http.getJson(ClientConfigurationListSchema, `/api-priv/v1/parties-acl/support/config`, { params });
};
