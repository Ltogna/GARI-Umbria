import { AnomaliesListSchema, type AnomaliesListModel } from "@/models/anomalies";
import type { HttpJsonResult } from "@abaco/safe-rest/src/HTTPClient";
import { httpPartiesACLServer as http } from "./http";

/**
 * GET the anomalies of party
 * @param partyId
 * @returns
 */
export const getAnomaliesOfParty = async (partyId: string): Promise<HttpJsonResult<AnomaliesListModel>> => {
  return http.getJson(AnomaliesListSchema, `/api-priv/v1/parties-acl/anomalies/parties/${partyId}`);
};
