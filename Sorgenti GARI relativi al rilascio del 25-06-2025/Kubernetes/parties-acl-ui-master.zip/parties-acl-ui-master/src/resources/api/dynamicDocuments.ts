import { DynamiDocumentListSchema, DynamiDocumentSchema, type DynamiDocumentListModel, type DynamiDocumentModel } from "@/models/dynamicDocuments";
import { type HttpJsonResult, type HttpResult } from "@abaco/safe-rest/src/HTTPClient";
import { z } from "zod";
import { httpPartiesACLServer as http } from "./http";

export async function createDocument(
  mandateId: string,
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  doc: any,
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
): Promise<HttpJsonResult<any>> {
  return await http.postJson(z.any(), `/api-priv/v1/parties-acl/mandates/${mandateId}/documents`, doc);
}

export async function updateDocument(
  mandateId: string,
  documentId: string,
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  doc: any,
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
): Promise<HttpJsonResult<any>> {
  return await http.putJson(z.any(), `/api-priv/v1/parties-acl/mandates/${mandateId}/documents/${documentId}`, doc);
}

export async function getDocuments(
  mandateId: string,
  definitionCode?: string,
  nextKey?: string | null,
): Promise<HttpJsonResult<DynamiDocumentListModel>> {
  const params: Record<string, string> = {};

  if (definitionCode) {
    params["definitionCode"] = definitionCode;
  }
  if (nextKey) {
    params["nextKey"] = nextKey;
  }

  return await http.getJson(DynamiDocumentListSchema, `/api-priv/v1/parties-acl/mandates/${mandateId}/documents`, {
    params,
  });
}

export async function getDocument(mandateId: string, documentId: string | number | undefined | null): Promise<HttpJsonResult<DynamiDocumentModel>> {
  return await http.getJson(DynamiDocumentSchema, `/api-priv/v1/parties-acl/mandates/${mandateId}/documents/${documentId}`);
}

export async function deleteDocument(mandateId: string, documentId: string | number): Promise<HttpResult> {
  return await http.delete(`/api-priv/v1/parties-acl/mandates/${mandateId}/documents/${documentId}`);
}
