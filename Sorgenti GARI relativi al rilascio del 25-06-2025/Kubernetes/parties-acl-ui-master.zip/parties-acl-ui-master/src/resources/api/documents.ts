// import { getValuable } from "@/utils/getValuable";
import { type HttpJsonResult } from "@abaco/safe-rest/src/HTTPClient";
// import { httpClientPartyRegistryServer as http } from "./http";
import { DocumentTypeListSchema, ScopeCode, type DocumentTypeListModel } from "@/models/documents";
import { DocumentSchema, type DocumentSchemaType } from "@abaco/dynamic-documents/src/resources/models";
import { httpPartiesACLServer as http } from "./http";

// const mockDocumentTypeListData: DocumentTypeListModel = [
//   {
//     definitionCode: "DOC_1",
//     definitionCodeI18n: "Sottoscriziona mandato",
//     titleTypeId: 1,
//     flDocPresent: 1,
//     flReqOnAdd: 1,
//     flReqOnClose: 0,
//     flRequired: 1,
//     multiple: false,
//     summaryFieldDefinitions: [
//       { code: "id_type", description: "tipo documento", fieldType: "string" },
//       { code: "issue_date", description: "data di rilascio", fieldType: "date" },
//     ],
//     documentId: 1,
//   },
//   {
//     definitionCode: "DOC_3",
//     definitionCodeI18n: "Chiusura mandato",
//     titleTypeId: 1,
//     flDocPresent: 1,
//     flReqOnAdd: 1,
//     flReqOnClose: 0,
//     flRequired: 1,
//     multiple: false,
//     summaryFieldDefinitions: [
//       { code: "id_type", description: "tipo documento", fieldType: "string" },
//       { code: "issue_date", description: "data di rilascio", fieldType: "date" },
//     ],
//     documentId: 1,
//   },
//   {
//     definitionCode: "DOC_2",
//     definitionCodeI18n: "Revoca mandato",
//     titleTypeId: 1,
//     flDocPresent: 1,
//     flReqOnAdd: 1,
//     flReqOnClose: 0,
//     flRequired: 1,
//     multiple: false,
//     summaryFieldDefinitions: [
//       { code: "id_type", description: "tipo documento", fieldType: "string" },
//       { code: "issue_date", description: "data di rilascio", fieldType: "date" },
//     ],
//     documentId: 1,
//   },
// ];

export type GroupParam = { scopeCode: ScopeCode.GROUPS; entityId: string | number };
export type PartiesParam = {
  scopeCode: ScopeCode.MANDATES;
  mandateId: number | string;
};

export type DocumentParams = GroupParam | PartiesParam;

/**
 * @param scopeCode Default value: GROUPS
 * @param entityId
 * @param mandateId
 */
export async function getDocumentTypes(params: DocumentParams): Promise<HttpJsonResult<DocumentTypeListModel>> {
  if (params.scopeCode === ScopeCode.GROUPS && params.entityId) {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    if ((params as any).mandateId) {
      console.warn("partyId not valid here");
    }
  }
  if (params.scopeCode === ScopeCode.MANDATES && params.mandateId) {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    if ((params as any).entityId) {
      console.warn("groupId not valid here");
    }
  }

  const { scopeCode, ...rest } = params;

  return await http.getJson(DocumentTypeListSchema, `/api-priv/v1/parties-acl/doc-types/scopes/${scopeCode}`, {
    params: rest,
  });
}

// export async function getDocumentTypes(mandateId: string): Promise<HttpJsonResult<DocumentTypeListModel>> {
//   try {
//     const mockDocData = await new Promise<DocumentTypeListModel | null>((resolve) => {
//       const mockData: DocumentTypeListModel = mockDocumentTypeListData;

//       if (mandateId) {
//         setTimeout(() => {
//           // if (Math.random() < 0.5) {
//           //   resolve(mockData);
//           // } else
//           {
//             resolve(mockData);
//           }
//         }, 2000);
//       } else {
//         resolve(null);
//       }
//     });

//     if (!mockDocData) {
//       return {
//         errorType: ErrorType.HTTP_STATUS,
//         response: new Response(JSON.stringify({ message: "error" }), {
//           status: 404,
//         }),
//       };
//     }

//     const data = DocumentTypeListSchema.parse(mockDocData);
//     return {
//       errorType: ErrorType.NONE,
//       data,
//       response: new Response(JSON.stringify(data)),
//     };
//   } catch (err) {
//     return {
//       errorType: ErrorType.OTHER,
//       err,
//     };
//   }
// }

export async function getDocumentTypeByDefinitionCode(
  definitionCode: string,
  // scopeCode: string = ScopeCode.GROUPS,
): Promise<HttpJsonResult<DocumentSchemaType>> {
  return await http.getJson(DocumentSchema, `/api-priv/v1/parties-acl/doc-types/${definitionCode}`);
}
