<script setup lang="ts">
import MandateMainContent from "@/components/mandate/MandateMainContent.vue";
import PartyList from "@/components/party-list/PartyList.vue";
import SearchForm from "@/components/party-search-form/PartySearchForm.vue";
import { useApiResponseHandler } from "@/composables/useApiResponseHandler";
import useModuleId from "@/composables/useModuleId";
import { usePartyList } from "@/composables/usePartyList";
import usePermissions from "@/composables/usePermissions";
import type { PartyFilterSchema } from "@/models/parties";
import { RouteName } from "@/models/routes";
import { getParties } from "@/resources/api/parties";
import BiBackButton from "@abaco/bootstrap-italia-components/src/components/BiBackButton/BiBackButton.vue";
import BiButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiButton.vue";
import BiCard from "@abaco/bootstrap-italia-components/src/components/BiCard/BiCard.vue";
import { computed } from "vue";
import { useI18n } from "vue-i18n";
import { useRouter } from "vue-router";

const { t } = useI18n();
const moduleId = useModuleId();
const { canWrite } = usePermissions();
const { loading, page, search, resetPage, setPageValues, updatePageValues, setSearchValues } = usePartyList();

const partyList = computed(() => page.records);
const nextKey = computed(() => page.nextKey || undefined);
const router = useRouter();
const singlePartyId = computed(() => (partyList.value.length === 1 ? String(partyList.value[0].id) : null));

function goBack() {
  resetPage();
}

function handleNewMandate(partyId: string) {
  router.push({ name: RouteName.MANDATE_NEW, params: { partyId } });
}

async function onSearch(searchForm: Partial<PartyFilterSchema>) {
  resetPage();
  setSearchValues(searchForm as PartyFilterSchema);
  loading.value = true;
  const res = await useApiResponseHandler(() => getParties(searchForm as PartyFilterSchema));
  if (res && typeof res !== "boolean") {
    setPageValues(res);
  }
  loading.value = false;
}
async function onLoadMore() {
  loading.value = true;
  const res = await useApiResponseHandler(() => getParties({ ...search, nextKey: nextKey.value } as PartyFilterSchema));
  if (res && typeof res !== "boolean") {
    updatePageValues(res);
  }
  loading.value = false;
}
</script>

<template>
  <div class="container my-5">
    <BiCard :extra-classes="['card-bg', 'rounded', 'no-after']">
      <template #card-header>
        <div class="card-header px-4">
          <div class="d-flex justify-content-between align-items-end">
            <BiBackButton
              v-if="partyList.length !== 0"
              icon="arrow-left"
              is-outlined
              color="primary"
              icon-color="primary"
              class="me-2"
              :visually-hidden-text="t(`${moduleId}.general.go_back`)"
              @click="goBack"
            >
            </BiBackButton>
            <h3 class="flex-grow-1 text-primary m-0">
              {{ t(`${moduleId}.party.subject`) }}
            </h3>
            <BiButton v-if="canWrite && singlePartyId" is-outlined color="primary" @click="handleNewMandate(singlePartyId)">
              {{ t(`${moduleId}.party_details.new_mandate`) }}
            </BiButton>
          </div>
        </div>
      </template>
      <template #card-body>
        <SearchForm @search="onSearch" v-if="partyList.length === 0"></SearchForm>
        <template v-if="partyList.length !== 0">
          <MandateMainContent icon="list" :title="t(`${moduleId}.party.list.title`)">
            <PartyList :party-list="partyList" :show-load-more="!!nextKey" @load-more="onLoadMore()" :loading="loading"></PartyList>
          </MandateMainContent>
        </template>
      </template>
    </BiCard>
  </div>
</template>
