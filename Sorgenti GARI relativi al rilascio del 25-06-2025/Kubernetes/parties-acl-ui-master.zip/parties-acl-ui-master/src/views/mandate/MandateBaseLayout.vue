<script setup lang="ts">
import MandateHeaderBar from "@/components/mandate/MandateHeaderBar.vue";
import useModuleId from "@/composables/useModuleId";
import BiCard from "@abaco/bootstrap-italia-components/src/components/BiCard/BiCard.vue";
import { useI18n } from "vue-i18n";
import { computed, defineProps } from "vue";
import { useRoute } from "vue-router";
import { RouteName } from "@/models/routes";

const { t } = useI18n();
const moduleId = useModuleId();
const route = useRoute();

const props = defineProps<{
  leftColumn?: boolean;
  isStatus?: boolean;
  status?: string;
}>();

const classes = computed(() => {
  if (props.leftColumn) {
    return "col-lg-9";
  }

  return "col-lg-12";
});

const title = computed(() => {
  if (route.name === RouteName.MANDATE_EDIT) {
    return t(`${moduleId}.party.subject_with_action`, { action: t(`${moduleId}.mandate_form.extend_revoke_btn`) });
  }
  if (route.name === RouteName.MANDATE_REVOKE) {
    return t(`${moduleId}.party.subject_with_action`, { action: t(`${moduleId}.mandate_form.revoke_btn`) });
  }

  return t(`${moduleId}.party.subject`);
});
</script>

<template>
  <BiCard :extra-classes="['card-bg', 'rounded', 'no-after']">
    <template #card-header>
      <div class="card-header px-4">
        <div class="d-flex justify-content-between align-items-end">
          <slot name="backbutton"></slot>
          <h3 class="flex-grow-1 text-primary m-0">
            {{ title }}
          </h3>
          <slot name="actions"></slot>
        </div>
      </div>
    </template>
    <template #card-body>
      <div class="container row m-0 px-0">
        <div v-if="leftColumn" class="col-12 col-lg-3 pe-0 ps-0 pe-lg-2 mb-3">
          <slot name="leftColumn" />
        </div>
        <div :class="['col-12', classes, 'pe-0 ps-0 ps-lg-2']">
          <MandateHeaderBar :is-status="isStatus">
            <template #stateSlot>
              <span class="justify-content-end pe-sm-2 status-nowrap">
                {{ t(`${moduleId}.mandate.state`, { state: props.status?.toUpperCase() }) }}
              </span>
            </template>
          </MandateHeaderBar>
          <slot></slot>
        </div>
      </div>
    </template>
  </BiCard>
</template>
