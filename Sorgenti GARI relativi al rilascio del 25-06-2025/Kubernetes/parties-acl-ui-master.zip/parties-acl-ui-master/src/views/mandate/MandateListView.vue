<script lang="ts" setup>
import MandateListTable from "@/components/mandate/MandateListTable.vue";
import useModuleId from "@/composables/useModuleId";
import usePermissions from "@/composables/usePermissions";
import { RouteName } from "@/models/routes";
import BiBackButton from "@abaco/bootstrap-italia-components/src/components/BiBackButton/BiBackButton.vue";
import MandateMainContent from "@/components/mandate/MandateMainContent.vue";
import BiButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiButton.vue";
import { useI18n } from "vue-i18n";
import { useRouter } from "vue-router";
import MandateBaseLayout from "./MandateBaseLayout.vue";

const { t } = useI18n();
const moduleId = useModuleId();
const { canWrite } = usePermissions();
const router = useRouter();

function handleGotoBack() {
  router.push({ name: RouteName.PARTY_LIST });
}

function handleNewMandate() {
  router.push({ name: RouteName.MANDATE_NEW });
}
</script>

<template>
  <MandateBaseLayout>
    <template #backbutton>
      <BiBackButton
        icon="arrow-left"
        is-outlined
        color="primary"
        icon-color="primary"
        class="me-2"
        :visually-hidden-text="t(`${moduleId}.general.go_back`)"
        @click="handleGotoBack"
      />
    </template>

    <template #actions>
      <BiButton v-if="canWrite" is-outlined color="primary" @click="handleNewMandate">
        {{ t(`${moduleId}.party_details.new_mandate`) }}
      </BiButton>
    </template>
    <MandateMainContent icon="list" :title="t(`${moduleId}.mandate_list.title`)">
      <MandateListTable />
    </MandateMainContent>
  </MandateBaseLayout>
</template>
