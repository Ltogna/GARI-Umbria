<script lang="ts" setup>
import { useApiResponseHandler } from "@/composables/useApiResponseHandler";
import useModuleId from "@/composables/useModuleId";
import { deleteMandate } from "@/resources/api/mandates";
import BiAlert from "@abaco/bootstrap-italia-components/src/components/BiAlert/BiAlert.vue";
import BiButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiButton.vue";
import BiModal from "@abaco/bootstrap-italia-components/src/components/BiModal/BiModal.vue";
import { defineEmits, defineModel, defineProps, watch } from "vue";
import { useI18n } from "vue-i18n";

const props = defineProps<{
  mandateId: string | number;
}>();
const emits = defineEmits<{
  "hidden-modal": [boolean];
}>();
const openModal = defineModel<boolean>({ default: false });
let isDeleted = false;

const moduleId = useModuleId();
const { t } = useI18n();

watch(
  openModal,
  (isOpen) => {
    if (isOpen) {
      isDeleted = false;
    }
  },
  { immediate: true },
);

function hiddenModalHandler() {
  emits("hidden-modal", isDeleted);
}

function closeModalHandler() {
  openModal.value = false;
}

async function onDeleteHandler() {
  const resp = await useApiResponseHandler(() => deleteMandate(props.mandateId));

  if (resp) {
    isDeleted = true;
    openModal.value = false;
  }
}
</script>

<template>
  <BiModal
    :model-value="openModal"
    :title="t(`${moduleId}.delete`)"
    size="lg"
    extra-header-class="p-4"
    extra-footer-class="justify-content-center"
    @hiddenModal="hiddenModalHandler"
  >
    <template #body>
      <BiAlert :title="t(`${moduleId}.general.warning`)" is-warn>
        <template #body>
          <strong>{{ t(`${moduleId}.mandate_delete_message`) }}</strong>
        </template>
      </BiAlert>
    </template>
    <template #footer>
      <BiButton @click="closeModalHandler" color="secondary" is-outlined>
        {{ t(`${moduleId}.general.close`) }}
      </BiButton>
      <BiButton color="success" @click="onDeleteHandler">
        {{ t(`${moduleId}.general.confirm`) }}
      </BiButton>
    </template>
  </BiModal>
</template>
