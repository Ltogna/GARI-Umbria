<script lang="ts" setup>
import SearchGroupModal from "@/components/group-management/modals/SearchGroupModal.vue";
import { useApiResponseHandler, useNotification } from "@/composables/useApiResponseHandler";
import useEmitter from "@/composables/useEmitter";
import useModuleId from "@/composables/useModuleId";
import usePermissions from "@/composables/usePermissions";
import useUserDateFormat from "@/composables/useUserDateFormat";
import type { EntityModel } from "@/models/entities";
import type { PartyModel } from "@/models/mandates";
import type { PartySchema } from "@/models/parties";
import { RouteName } from "@/models/routes";
import type { EntityTypeModel } from "@/models/types";
import { addPartiesToEntity } from "@/resources/api/mandates";
import { getEntityType } from "@/resources/api/types";
import { useConfigStore } from "@/stores/config";
import { DATE_FORMAT_DAYJS, dateToString, stringToDate } from "@/utils/dates";
import BiBackButton from "@abaco/bootstrap-italia-components/src/components/BiBackButton/BiBackButton.vue";
import BiButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiButton.vue";
import BiDatepicker from "@abaco/bootstrap-italia-components/src/components/form/BiDatepicker.vue";
import BiInput from "@abaco/bootstrap-italia-components/src/components/form/BiInput.vue";
import MandateMainContent from "@/components/mandate/MandateMainContent.vue";
import BiSelect from "@abaco/bootstrap-italia-components/src/components/form/BiSelect.vue";
import { ErrorType } from "@abaco/safe-rest/src/HTTPClient";
import { toTypedSchema } from "@vee-validate/zod";
import { isBefore, isEqual } from "date-fns";
import { format } from "date-fns/format";
import { addDays } from "date-fns/addDays";
import { isAfter } from "date-fns/isAfter";
import { useForm, ErrorMessage } from "vee-validate";
import { computed, inject, onMounted, ref, watch, type Ref } from "vue";
import { useI18n } from "vue-i18n";
import { useRouter } from "vue-router";
import z from "zod";
import MandateBaseLayout from "./MandateBaseLayout.vue";

const party = inject<Ref<PartySchema>>("party");

const { t } = useI18n();
const moduleId = useModuleId();
const { canWrite } = usePermissions();
const { showSuccessNotification } = useNotification();
const userDateFormat = useUserDateFormat();
const emitter = useEmitter();

const openModal = ref(false);
const groupName = ref("");
const groupCode = ref("");
const entityTypes = ref<EntityTypeModel[]>([]);
const selectedEntity = ref<EntityModel>();

onMounted(async () => {
  entityTypes.value = [];
  // entityTypes.value.sort((a, b) => a.code.localeCompare(b.code));
});

const FormSchema = z
  .object({
    group: z
      .string({
        required_error: t(`${moduleId}.general.mandatory_field`),
      })
      .min(1, t(`${moduleId}.general.mandatory_field`)),
    type: z
      .string({
        required_error: t(`${moduleId}.general.mandatory_field`),
      })
      .min(1, t(`${moduleId}.general.mandatory_field`)),
    dayFrom: z
      .string({
        required_error: t(`${moduleId}.general.mandatory_field`),
      })
      .min(1, t(`${moduleId}.general.mandatory_field`)),
    dayTo: z.string(),
  })
  .refine(
    (data) => {
      const dateToCompare = stringToDate(data.dayTo);
      return (
        dateToCompare &&
        selectedEntity &&
        selectedEntity.value?.day_to &&
        (isEqual(dateToCompare, selectedEntity.value?.day_to) || isBefore(dateToCompare, selectedEntity.value?.day_to))
      );
    },
    {
      path: ["dayTo"],
      message: t(`${moduleId}.mandate_form.entity_dayTo_greater_than_day_to`, {
        entityDayTo: selectedEntity.value?.day_to ? format(selectedEntity.value?.day_to, userDateFormat) : "",
      }),
    },
  );
type FormModel = z.infer<typeof FormSchema>;

const router = useRouter();
const { handleSubmit, defineField, errors, resetForm, meta, submitCount } = useForm<FormModel>({
  validationSchema: toTypedSchema(FormSchema),
  initialValues: {
    group: "",
    type: "",
    dayFrom: "",
    dayTo: "",
  },
});

function handleGotoBack() {
  router.push({ name: RouteName.PARTY_DETAILS });
}
const [group] = defineField("group");
const [type] = defineField("type");
const [dayFrom] = defineField("dayFrom");
const [dayTo] = defineField("dayTo");

const onSubmit = handleSubmit(async (values) => {
  if (party?.value && submitCount.value > 0) {
    const partyData: PartyModel = {
      id: party.value.id.toString(),
      day_from: values.dayFrom,
      day_to: values.dayTo !== "" ? values.dayTo : null,
      party_type_code: values.type,
    };
    const resp = await useApiResponseHandler(() => addPartiesToEntity(values.group, partyData));
    if (resp) {
      showSuccessNotification();
      resetForm({
        values,
      });
      router.replace({ name: RouteName.PARTY_DETAILS });
      return true;
    }
    return false;
  }
});

const onGroupSelected = async (entity: EntityModel) => {
  entityTypes.value = [];
  selectedEntity.value = undefined;
  if (entity.entity_type.code) {
    selectedEntity.value = { ...entity };
    const resp = await getEntityType(entity.entity_type.id, true);
    if (resp.errorType === ErrorType.NONE && resp.data.party_types_list) {
      entityTypes.value = resp.data.party_types_list;
      entityTypes.value.sort((a, b) => a.code.localeCompare(b.code));
      if (entityTypes.value.length === 1) {
        type.value = entityTypes.value[0].code.toString();
      }
    } else {
      // TODO SHOW ERROR ALERT
    }
  }
  group.value = entity.id.toString();
  entity.code && (groupCode.value = entity.code);
  groupName.value = entity.name;
};

const onReset = () => {
  groupName.value = "";
  groupCode.value = "";
  entityTypes.value = [];
  dayFrom.value = "";
  resetForm();
};

const minEndDate = computed(() => {
  const date = stringToDate(dayFrom.value);
  if (date) {
    return dateToString(addDays(date, 1));
  }
  return dateToString(date);
});

const maxEndDate = computed(() => {
  return selectedEntity.value?.day_to ?? undefined;
});

const isEditable = computed(() => {
  return canWrite;
});

watch([dayFrom, dayTo], ([newDayFrom, newDayTo]) => {
  if (newDayFrom && newDayTo) {
    const dayFromDt = stringToDate(newDayFrom);
    const dayToDt = stringToDate(newDayTo);
    if (dayToDt && dayFromDt && isAfter(dayFromDt, dayToDt)) {
      dayTo.value = "";
    }
  }
});

watch(
  () => meta.value.dirty,
  (isDirty) => {
    emitter.emit("is:dirty", isDirty);
  },
);

const { allowPastDate } = useConfigStore();

const minStartDate = computed(() => {
  const entityDayFrom = selectedEntity.value?.day_from;
  if (!entityDayFrom) return;

  if (isAfter(entityDayFrom, new Date())) {
    return entityDayFrom;
  }

  return allowPastDate ? entityDayFrom : new Date();
});
</script>

<template>
  <form @submit.prevent="onSubmit" @reset.prevent="onReset" novalidate class="parties-acl__form">
    <MandateBaseLayout>
      <template #backbutton>
        <BiBackButton
          icon="arrow-left"
          is-outlined
          color="primary"
          icon-color="primary"
          class="me-2"
          :visually-hidden-text="t(`${moduleId}.general.go_back`)"
          @click="handleGotoBack"
        />
      </template>

      <MandateMainContent icon="file-lines" :title="t(`${moduleId}.mandate_form.title`)">
        <input type="hidden" v-model="group" />
        <div class="row g-2">
          <div class="col-md-6 col-lg-4 field-required">
            <BiInput readonly :label="t(`${moduleId}.mandate_form.code_label`)" v-model.trim="groupCode"></BiInput>
            <ErrorMessage v-if="meta.touched" name="group" class="form-feedback just-validate-error-label" />
          </div>
          <div class="w-100" />
          <div class="col-md-6 col-lg-4 field-required">
            <BiInput readonly :label="t(`${moduleId}.mandate_form.group_label`)" v-model.trim="groupName"></BiInput>
            <ErrorMessage v-if="meta.touched" name="group" class="form-feedback just-validate-error-label" />
          </div>
          <div class="col-md-6 col-lg-4" v-if="isEditable">
            <BiButton style="white-space: nowrap" is-outlined color="primary" @click="openModal = true">
              {{ t(`${moduleId}.mandate_form.search_group`) }}
            </BiButton>
          </div>
          <div class="w-100" />
          <div class="col-md-6 col-lg-4">
            <BiSelect
              v-model="type"
              :disabled="entityTypes.length === 0 || !isEditable"
              :empty-option="t(`${moduleId}.general.select`)"
              :label="t(`${moduleId}.mandate_form.type_label`)"
              :items="entityTypes.map(({ code, description }) => ({ id: code, text: description }))"
              :errors="errors.type ? [errors.type] : []"
              class="field-required"
            />
          </div>
          <div class="w-100" />
          <div class="col-md-6 col-lg-4">
            <!-- 145814 error message will display after submit-->
            <BiDatepicker
              :is-disabled="!isEditable"
              :format="DATE_FORMAT_DAYJS"
              :debounce-time="0"
              :label="t(`${moduleId}.mandate_form.start_date`)"
              :min="minStartDate"
              :errors="errors.dayFrom && submitCount > 0 ? [errors.dayFrom] : []"
              class="field-required"
              v-model="dayFrom"
              :validate-on-change="false"
            ></BiDatepicker>
          </div>
          <div class="w-100" />
          <div class="col-md-6 col-lg-4">
            <BiDatepicker
              :is-disabled="!isEditable"
              :format="DATE_FORMAT_DAYJS"
              :debounce-time="0"
              :label="t(`${moduleId}.mandate_form.end_date`)"
              :min="minEndDate"
              :max="maxEndDate"
              v-model="dayTo"
              :validate-on-change="false"
            ></BiDatepicker>
          </div>
        </div>
        <div class="row mt-3">
          <div class="col">
            <BiButton :is-disabled="!meta.dirty || !isEditable" color="primary" type="submit" class="me-2">
              {{ t(`${moduleId}.mandate_form.submit`) }}
            </BiButton>
            <BiButton :is-disabled="!meta.dirty || !isEditable" color="secondary" is-outlined type="reset">
              {{ t(`${moduleId}.mandate_form.reset`) }}
            </BiButton>
          </div>
        </div>
      </MandateMainContent>
    </MandateBaseLayout>
  </form>
  <SearchGroupModal v-model="openModal" @selected="onGroupSelected" />
</template>
