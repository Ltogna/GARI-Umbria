<script lang="ts" setup>
import DocumentAccordion from "@/components/mandate/DocumentAccordion.vue";
import MandateDetail from "@/components/mandate/MandateDetail.vue";
import MandateMainContent from "@/components/mandate/MandateMainContent.vue";
import { useApiResponseHandler } from "@/composables/useApiResponseHandler";
import useModuleId from "@/composables/useModuleId";
import usePermissions from "@/composables/usePermissions";
import { ScopeCode, type DocumentTypeListModel } from "@/models/documents";
import { StatusCodeEnum, type PartyWithEntityModel } from "@/models/mandates";
import { RouteName } from "@/models/routes";
import type { DocumentParams } from "@/resources/api/documents";
import { getDocumentTypes } from "@/resources/api/documents";
import { getMandateById } from "@/resources/api/mandates";
import BiAlert from "@abaco/bootstrap-italia-components/src/components/BiAlert/BiAlert.vue";
import BiBackButton from "@abaco/bootstrap-italia-components/src/components/BiBackButton/BiBackButton.vue";
import BiButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiButton.vue";
import { ErrorType } from "@abaco/safe-rest/src/HTTPClient";
import { computed, onMounted, provide, ref } from "vue";
import { useI18n } from "vue-i18n";
import { useRoute, useRouter } from "vue-router";
import DeleteMandateModal from "./DeleteMandateModal.vue";
import MandateBaseLayout from "./MandateBaseLayout.vue";

const { t } = useI18n();

const loading = ref(false);
const router = useRouter();
const route = useRoute();
const moduleId = useModuleId();
const { mandateId, partyId } = route.params as { partyId: string; mandateId: string };
const { canWrite } = usePermissions();
const errorMismatch = ref<boolean>(false);

const documentTypes = ref<DocumentTypeListModel>([]);
provide("documentTypes", documentTypes);

const hasDocumentTypes = computed(() => documentTypes.value && documentTypes.value.length > 0);

const mandateDetail = ref<PartyWithEntityModel>();
provide("mandateDetail", mandateDetail);

const paramsParty: DocumentParams = {
  scopeCode: ScopeCode.MANDATES,
  mandateId: mandateId,
};
onMounted(async () => {
  loading.value = true;
  errorMismatch.value = false;
  if (mandateId) {
    const resDocPromise = getDocumentTypes(paramsParty);

    const res = await useApiResponseHandler(() => getMandateById(+mandateId));
    if (res && typeof res !== "boolean") {
      mandateDetail.value = res;
    }
    const resDoc = await resDocPromise;
    if (resDoc.errorType === ErrorType.NONE && resDoc.data) {
      documentTypes.value = resDoc.data;
    } else {
      console.error("Failed to fetch document types:", resDoc);
    }

    if (mandateDetail.value && mandateDetail.value.id !== partyId) {
      errorMismatch.value = true;
    }
    loading.value = false;
  }
});

function handleGotoBack() {
  if (route.name === RouteName.MANDATE_EDIT) {
    router.push({ name: RouteName.MANDATE_DETAILS });
  }
  if (route.name === RouteName.MANDATE_REVOKE) {
    router.push({ name: RouteName.MANDATE_DETAILS });
  }
  if (route.name === RouteName.MANDATE_DETAILS) {
    router.push({ name: RouteName.PARTY_DETAILS });
  }
  if (route.name === RouteName.MANDATE_DOC) {
    router.push({ name: RouteName.MANDATE_DETAILS });
  }
  if (route.name === RouteName.MANDATE_NEW_MULTIPLE_DOC || route.name === RouteName.MANDATE_EDIT_MULTIPLE_DOC) {
    router.push({ name: RouteName.MANDATE_DOC });
  }
}
function editMandate() {
  router.push({ name: RouteName.MANDATE_EDIT });
}

function revokeMandate() {
  router.push({ name: RouteName.MANDATE_REVOKE });
}

const showMandateDetail = computed(
  () =>
    route.name === RouteName.MANDATE_DOC || route.name === RouteName.MANDATE_EDIT_MULTIPLE_DOC || route.name === RouteName.MANDATE_NEW_MULTIPLE_DOC,
);

const hasStatus = computed(() => {
  return mandateDetail.value?.status !== null || mandateDetail.value?.status !== undefined;
});

const statusTranslations = {
  [StatusCodeEnum.VALID]: t(`${moduleId}.mandate.status.valid`),
  [StatusCodeEnum.NOT_VALID]: t(`${moduleId}.mandate.status.not_valid`),
  [StatusCodeEnum.CLOSED]: t(`${moduleId}.mandate.status.closed`),
};

const translatedStatus = computed(() => {
  if (mandateDetail.value?.status) {
    return statusTranslations[mandateDetail.value.status] || "";
  }
  return "";
});

const openDeleteMandateModal = ref(false);
function openDeleteMandateModalHandler() {
  openDeleteMandateModal.value = true;
}

function handleGotoBackToList(goBack: boolean) {
  openDeleteMandateModal.value = false;
  if (goBack) {
    router.push({ name: RouteName.PARTY_DETAILS });
  }
}

const deleteMandateButtonVisible = computed(() => {
  return (
    (route.name === RouteName.MANDATE_DETAILS || route.name === RouteName.MANDATE_EDIT || route.name === RouteName.MANDATE_REVOKE) &&
    canWrite &&
    !!mandateDetail.value?.editable
  );
});
</script>

<template>
  <MandateBaseLayout v-if="!loading && !errorMismatch" :leftColumn="hasDocumentTypes" :is-status="hasStatus" :status="translatedStatus">
    <template #backbutton>
      <BiBackButton
        icon="arrow-left"
        is-outlined
        color="primary"
        icon-color="primary"
        class="me-2"
        :visually-hidden-text="t(`${moduleId}.general.go_back`)"
        @click="handleGotoBack"
      />
    </template>

    <template #actions>
      <div class="d-flex g-2">
        <BiButton
          v-if="
            canWrite &&
            !!mandateDetail?.editable &&
            route.name &&
            ![RouteName.MANDATE_EDIT, RouteName.MANDATE_REVOKE].includes(route.name as RouteName)
          "
          @click="editMandate"
          is-outlined
          :color="'primary'"
        >
          {{ t(`${moduleId}.mandate_form.extend_revoke_btn`) }}
        </BiButton>
        <BiButton
          v-if="
            canWrite &&
            !!mandateDetail?.revocable &&
            route.name &&
            ![RouteName.MANDATE_EDIT, RouteName.MANDATE_REVOKE].includes(route.name as RouteName)
          "
          @click="revokeMandate"
          is-outlined
          :color="'danger'"
        >
          {{ t(`${moduleId}.mandate_form.revoke_btn`) }}
        </BiButton>
      </div>
    </template>

    <template #leftColumn><DocumentAccordion :document-data="documentTypes"></DocumentAccordion> </template>

    <MandateMainContent>
      <MandateDetail v-if="!showMandateDetail && mandateDetail" :mandate-detail="mandateDetail" />
      <div v-if="mandateDetail" class="mt-3">
        <RouterView />
      </div>

      <div class="row mt-3" v-if="deleteMandateButtonVisible">
        <div class="col-12 d-flex justify-content-center">
          <BiButton @click="openDeleteMandateModalHandler" color="danger">{{ t(`${moduleId}.delete`) }}</BiButton>
        </div>
      </div>
    </MandateMainContent>
  </MandateBaseLayout>
  <MandateBaseLayout v-if="!loading && errorMismatch">
    <div class="mt-5">
      <BiAlert is-error :title="t(`${moduleId}.error_title_party_and_mandate_mismatch`)" />
    </div>
  </MandateBaseLayout>
  <DeleteMandateModal :mandate-id="mandateId" v-model="openDeleteMandateModal" @hidden-modal="handleGotoBackToList" />
</template>
