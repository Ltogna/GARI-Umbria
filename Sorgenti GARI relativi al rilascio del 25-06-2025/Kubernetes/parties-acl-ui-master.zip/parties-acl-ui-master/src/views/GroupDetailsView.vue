<script setup lang="ts">
import { useGroupStore } from "@/stores/group";
import { computed } from "vue";

const groupStore = useGroupStore();

const hasGroup = computed(() => !!groupStore.selectedGroup);
</script>

<template>
  <RouterView v-if="hasGroup" name="summary" />
  <RouterView v-if="hasGroup" />
</template>
