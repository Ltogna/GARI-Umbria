<script setup lang="ts">
import { useApiResponseHandler } from "@/composables/useApiResponseHandler";
import type { PartySchema } from "@/models/parties";
import { getPartyById } from "@/resources/api/parties";
import { onMounted, provide, ref } from "vue";
import { useRoute } from "vue-router";

const route = useRoute();
const { partyId } = route.params as { partyId: string };
const party = ref<PartySchema>();
provide("party", party);

onMounted(async () => {
  const entityRes = await useApiResponseHandler(() => getPartyById(partyId));
  if (entityRes && typeof entityRes !== "boolean") {
    party.value = entityRes;
  }
});
</script>

<template>
  <div v-if="party" class="container my-5">
    <RouterView />
  </div>
</template>
