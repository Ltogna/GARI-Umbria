<script setup lang="ts">
import CloseGroupButton from "@/components/group-management/CloseGroupButton.vue";
import ActionsUserModal from "@/components/group-management/modals/ActionsUserModal.vue";
import SearchUserModal from "@/components/group-management/modals/SearchUserModal.vue";
import useModuleId from "@/composables/useModuleId";
import usePermissions from "@/composables/usePermissions";
import { RouteName } from "@/models/routes";
import { useGroupStore } from "@/stores/group";
import BiButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiButton.vue";
import BiCard from "@abaco/bootstrap-italia-components/src/components/BiCard/BiCard.vue";
import { computed, ref } from "vue";
import { useI18n } from "vue-i18n";
import { useRoute, useRouter } from "vue-router";

const moduleId = useModuleId();
const { t } = useI18n();
const { canWrite } = usePermissions();
const groupStore = useGroupStore();

const router = useRouter();

const gotoCreateGroup = () => router.push({ name: RouteName.GROUP_NEW });
const gotoUsers = () => router.push({ name: RouteName.GROUP_USERS });
const goToHierarchy = () => router.push({ name: RouteName.GROUP_HIERARCHY });

const showSearchUserModal = ref(false);
const openSearchUserModal = () => {
  showSearchUserModal.value = true;
};
const showAddUserModal = ref(false);
const openAddUserModal = () => {
  showAddUserModal.value = true;
};

const route = useRoute();

const showNewGroupButton = computed(() => route.name === RouteName.GROUP);
const showUsersButton = computed(() => route.name === RouteName.GROUP_DETAILS);
const showCloseGroupButton = computed(() => route.name === RouteName.GROUP_DETAILS);
const showHierarchyButton = computed(() => route.name === RouteName.GROUP_DETAILS);
const showUserActionButton = computed(() => route.name === RouteName.GROUP_USERS);
</script>

<template>
  <div class="container my-5">
    <BiCard :extra-classes="['card-bg', 'rounded', 'no-after']">
      <template #card-header>
        <div class="card-header px-4">
          <div class="d-flex justify-content-between align-items-end">
            <h3 class="flex-grow-1 text-primary m-0">
              <RouterView name="backButton" />
              {{ t(`${moduleId}.group.management`) }}
            </h3>
            <BiButton v-if="showNewGroupButton && canWrite" color="success" is-outlined class="btn-me py-2" @click="gotoCreateGroup">
              {{ t(`${moduleId}.group.new`) }}
            </BiButton>
            <BiButton v-if="showHierarchyButton" color="success" is-outlined class="btn-me" @click="goToHierarchy">
              {{ t(`${moduleId}.group.hierarchy`) }}
            </BiButton>
            <BiButton v-if="showUsersButton" color="success" is-outlined class="btn-me" @click="gotoUsers">
              {{ t(`${moduleId}.group.user_management`) }}
            </BiButton>
            <CloseGroupButton v-if="showCloseGroupButton && canWrite && groupStore.isSelectedGroupEditable" />
            <BiButton v-if="showUserActionButton" color="success" is-outlined class="btn-me" @click="openSearchUserModal">
              {{ t(`${moduleId}.group.search.search_user`) }}
            </BiButton>
            <BiButton
              v-if="showUserActionButton && canWrite && groupStore.isSelectedGroupEditable"
              color="success"
              is-outlined
              class="btn-me"
              @click="openAddUserModal"
            >
              {{ t(`${moduleId}.group.user.add`) }}
            </BiButton>
          </div>
        </div>
      </template>
      <template #card-body>
        <RouterView />
      </template>
    </BiCard>
  </div>

  <SearchUserModal v-if="showUserActionButton" v-model="showSearchUserModal" />
  <ActionsUserModal v-if="showUserActionButton && canWrite && groupStore.isSelectedGroupEditable" v-model="showAddUserModal" />
</template>
