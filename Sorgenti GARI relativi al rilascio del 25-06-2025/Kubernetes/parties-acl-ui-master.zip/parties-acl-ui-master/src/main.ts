import "@/assets/parties-acl.scss";
import createBootstrapItaliaComponentPlugin from "@abaco/bootstrap-italia-components/src/components/BootstrapItaliaComponentPlugin";
import { onModuleLoaded } from "@abaco/micro-frontend/src/Application";
import { NOOP_STOP_LISTENER, type SetStopListenerFunction, type StopListener } from "@abaco/micro-frontend/src/StopPreventionSuport";
import { createAbcRouter } from "@abaco/micro-frontend/src/Utility";
import { ErrorType } from "@abaco/safe-rest/src/HTTPClient";
import { getUserData, userHasPermission } from "@abaco/safe-rest/src/sso2";
import mitt from "mitt";
import { createPinia, type Pinia } from "pinia";
import semver from "semver";
import { createApp, type App as VueApp } from "vue";
import { createRouter, createWebHistory } from "vue-router";
import App from "./App.vue";
import { DEFAULT_DATE_FORMAT, MODULE_ID } from "./constants";
import i18n, { loadLocaleMessages } from "./i18n";
import { getPartiesAclVersion } from "./resources/api/version";
import routes from "./routes";
import { isStandalone } from "./utils/isStandalone";

let pinia: Pinia | null = null;

if (isStandalone) {
  window.bootstrap.loadFonts(`${import.meta.env.BASE_URL}bootstrap-italia/dist/fonts`);
  await import("@/assets/index.scss");
  const router = createRouter({
    history: createWebHistory(import.meta.env.BASE_URL),
    routes,
  });
  const app = createApp(App);
  app.provide("setStopListener", undefined);
  await init(app);
  app.use(router);
  app.mount("#app");
} else {
  let appModule: VueApp<Element> | null;
  let stopListener: StopListener = NOOP_STOP_LISTENER;
  const fnc: SetStopListenerFunction = (l: StopListener | null) => (stopListener = l || NOOP_STOP_LISTENER);

  onModuleLoaded(MODULE_ID, {
    async start(node, basePath?: string) {
      appModule = createApp(App);
      appModule.provide("setStopListener", fnc);
      await init(appModule, basePath);
      const router = createAbcRouter(routes, basePath);
      appModule.use(router);

      appModule.mount(node);
    },
    css() {
      return { index: "/ui/parties-acl/assets/index.css.json" };
    },
    async canStop() {
      return stopListener();
    },
    async stop() {
      appModule?.unmount();
      pinia = null;
      appModule = null;
    },
  });
}

async function init(app: VueApp, basePath?: string) {
  const emitter = mitt();
  const partiesAclVersion = await getPartiesAclVersion();

  if (partiesAclVersion.errorType === ErrorType.NONE) {
    const { version, commitId, name } = partiesAclVersion.data;
    console.log(`Server: ${name}: v${version}-${commitId}`);
    console.log(`Client: parties-acl: v${import.meta.env.VITE_APP_VERSION}-${import.meta.env.VITE_APP_GIT_COMMIT}`);
    const diff = semver.diff(import.meta.env.VITE_APP_VERSION, version);

    if (diff && (diff === "minor" || diff === "major")) {
      console.error("API and client versions mismatch");
    }
  }
  pinia ??= createPinia();
  app.use(pinia);
  const bootstrapItaliaComponentPlugin = await createBootstrapItaliaComponentPlugin({
    includeGlobalComponent: false,
    includeFontAwesome: isStandalone,
  });

  const user = getUserData();
  const hasPermissionAdmin = userHasPermission("PACL", "ADMIN");
  const hasPermissionWrite = userHasPermission("PACL", "EDITOR");
  const hasPermissionRead = userHasPermission("PACL", "VIEWER");
  const lang = user?.locale ?? window.navigator.language;
  const userDateFormat = user?.dateFormat ?? DEFAULT_DATE_FORMAT;
  await loadLocaleMessages(lang);
  app.config.globalProperties.$emitter = emitter;

  try {
    app.use(i18n);
    app.use(bootstrapItaliaComponentPlugin);
    app.provide("hasPermissionAdmin", isStandalone || hasPermissionAdmin);
    app.provide("hasPermissionWrite", isStandalone || hasPermissionWrite);
    app.provide("hasPermissionRead", isStandalone || hasPermissionRead);
    app.provide("userDateFormat", userDateFormat);
    app.provide("basePath", basePath);
    app.provide("moduleId", MODULE_ID);
    app.provide("emitter", emitter);
  } catch (err) {
    console.warn(err);
  }
}
