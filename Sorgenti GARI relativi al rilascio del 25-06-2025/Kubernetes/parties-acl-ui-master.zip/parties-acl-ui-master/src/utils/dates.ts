import { format } from "date-fns";

export const DATE_PATTERN = /^(?<year>\d{4})(?<month>\d{2})(?<day>\d{2})$/;
export const DATE_FORMAT = "yyyyMMdd";
export const DATE_FORMAT_DAYJS = "YYYYMMDD";

/**
 * Acccept a format like _yyyyMMdd_ and return a `Date`
 */

export function stringToDate(arg?: unknown) {
  if (typeof arg === "string") {
    const match = arg.match(DATE_PATTERN)?.groups;
    if (!match) {
      return removeTimezone(new Date());
    }
    const date = new Date(+match.year, +match.month - 1, +match.day);
    if (isNaN(date.getTime())) {
      return new Date();
    }
    return removeTimezone(date);
  }
}

/**
 * Accept a date or a number and return a string like _yyyyMMdd_
 *
 * if `arg` is a string and string has a format like _yyyyMMdd_ the return `arg`
 */
export function dateToString(arg: unknown) {
  if (arg instanceof Date || typeof arg === "number") {
    return format(arg, DATE_FORMAT);
  } else if (typeof arg === "string") {
    // eslint-disable-next-line @typescript-eslint/ban-ts-comment
    // @ts-ignore
    const match = arg.match(DATE_PATTERN)?.groups;
    if (!match) {
      return format(new Date(), DATE_FORMAT);
    }
    const date = new Date(+match.year, +match.month - 1, +match.day);
    if (isNaN(date.getTime())) {
      return format(new Date(), DATE_FORMAT);
    }
    return arg;
  }
  return format(new Date(), DATE_FORMAT);
}

function removeTimezone(date: Date) {
  const timezone = date.getTimezoneOffset() * 60_000;
  return new Date(date.getTime() - timezone);
}
