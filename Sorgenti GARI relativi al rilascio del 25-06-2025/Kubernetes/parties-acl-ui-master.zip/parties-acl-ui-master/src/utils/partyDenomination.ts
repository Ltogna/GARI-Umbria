import type { PartySchema } from "@/models/parties";
import { isRef, type Ref } from "vue";

export function getPartyDenomination(party?: Ref<PartySchema> | PartySchema): string {
  const resp: string[] = [];
  if (party) {
    if (isRef(party)) {
      if (party.value.lastName) {
        resp.push(party.value.lastName);
      }
      if (party?.value.firstName) {
        resp.push(party.value.firstName);
      }
    } else {
      if (party.lastName) {
        resp.push(party.lastName);
      }
      if (party.firstName) {
        resp.push(party.firstName);
      }
    }
  }

  return resp.join(" ");
}
