export const BASE = "/ui/parties-acl/";
export const MODULE_ID = "parties-acl";
export const PREFIX_PARTIES_ACL_SERVER_API = "/parties-acl-server";
export const PREFIX_PARTY_REGISTRY_SERVER_API = "/party-registry";
export const INFINITE_DATE = "99991231";

export const DEFAULT_DATE_FORMAT = "dd/MM/yyyy";

export const GROUP_FILTER_KEY = "groupFilterKey";
