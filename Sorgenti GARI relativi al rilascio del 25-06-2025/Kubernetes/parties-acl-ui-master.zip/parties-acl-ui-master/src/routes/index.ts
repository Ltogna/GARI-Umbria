import { RouteName } from "@/models/routes";
import { useGroupStore } from "@/stores/group";
import { getParam } from "@/utils/getParam";
import { isStandalone } from "@/utils/isStandalone";
import type { RouteRecordRaw } from "vue-router";

const routes: RouteRecordRaw[] = [];

if (isStandalone) {
  routes.push({
    path: "/",
    redirect: "/party-search",
  });
}

routes.push({
  path: "/party-search",
  name: RouteName.PARTY_LIST,
  component: () => import("../views/PartyListView.vue"),
});

routes.push({
  path: "/",
  redirect: { name: RouteName.PARTY_LIST },
});

routes.push({
  path: "/party",
  redirect: { name: RouteName.PARTY_DETAILS },
  components: {
    default: () => import("../views/PartyDetailsView.vue"),
    leaveConfirmationModal: () => import("../components/common/LeaveDirtyPageModal.vue"),
  },
  children: [
    {
      path: ":partyId",
      name: RouteName.PARTY_DETAILS,
      component: () => import("../views/mandate/MandateListView.vue"),
    },
    {
      path: ":partyId/mandate/new",
      name: RouteName.MANDATE_NEW,
      component: () => import("../views/mandate/MandateFormView.vue"),
    },
    {
      path: ":partyId/mandate/:mandateId",
      name: RouteName.MANDATE_DETAILS,
      component: () => import("../views/mandate/MandateDetailsView.vue"),
      children: [
        {
          path: "edit",
          name: RouteName.MANDATE_EDIT,
          component: () => import("../components/mandate/MandateEditForm.vue"),
        },
        {
          path: "revoke",
          name: RouteName.MANDATE_REVOKE,
          component: () => import("../components/mandate/MandateEditForm.vue"),
        },
        {
          path: "doc/:docType",
          name: RouteName.MANDATE_DOC,
          component: () => import("../components/mandate/DynamicDocumentWrapper.vue"),
        },
        {
          path: "doc/:docType/new",
          name: RouteName.MANDATE_NEW_MULTIPLE_DOC,
          component: () => import("../components/mandate/DynamicDocumentWrapper.vue"),
        },
        {
          path: "doc/:docType/edit/:docId",
          name: RouteName.MANDATE_EDIT_MULTIPLE_DOC,
          component: () => import("../components/mandate/DynamicDocumentWrapper.vue"),
        },
      ],
    },
  ],
});

routes.push({
  path: "/group",
  components: {
    default: () => import("../views/GroupManagementView.vue"),
    leaveConfirmationModal: () => import("../components/common/LeaveDirtyPageModal.vue"),
  },
  children: [
    {
      path: "",
      name: RouteName.GROUP,
      component: () => import("../components/group-management/SearchGroups.vue"),
    },
    {
      path: "new",
      name: RouteName.GROUP_NEW,
      components: {
        default: () => import("../components/group-management/NewGroup.vue"),
        backButton: () => import("../components/group-management/GroupBackButton.vue"),
      },
    },
    {
      path: "list",
      name: RouteName.GROUP_LIST,
      components: {
        default: () => import("../components/group-management/GroupListTable.vue"),
        backButton: () => import("../components/group-management/GroupBackButton.vue"),
      },
      //TODO: requires better implementation
      async beforeEnter(_to, _from, next) {
        const groupStore = useGroupStore();
        if (groupStore.groupList.length === 0) {
          await groupStore.getGroupsList();
          if (groupStore.groupList.length === 0) next({ name: RouteName.GROUP, replace: true });
          else next();
        } else {
          next();
        }
      },
    },
    {
      path: ":groupId",
      components: {
        default: () => import("../views/GroupDetailsView.vue"),
        backButton: () => import("../components/group-management/GroupBackButton.vue"),
      },
      async beforeEnter(to, _from, next) {
        const groupStore = useGroupStore();
        const groupId = +getParam(to.params.groupId);
        await groupStore.getGroupDetails(groupId);
        if (groupStore.selectedGroup) {
          next();
        } else {
          next({ name: RouteName.GROUP });
        }
      },
      children: [
        {
          path: "",
          name: RouteName.GROUP_DETAILS,
          component: () => import("../components/group-management/EditGroup.vue"),
        },
        {
          path: "users",
          name: RouteName.GROUP_USERS,
          components: {
            summary: () => import("../components/group-management/SummaryGroup.vue"),
            default: () => import("../components/group-management/UsersListTable.vue"),
          },
        },
        {
          path: "hierarchy",
          name: RouteName.GROUP_HIERARCHY,
          components: {
            summary: () => import("../components/group-management/SummaryGroup.vue"),
            default: () => import("../components/group-management/GroupHierarchy.vue"),
          },
        },
        // {
        //   path: "close",
        //   name: RouteName.GROUP_CLOSE,
        //   components: {
        //     summary: () => import("../components/group-management/SummaryGroup.vue"),
        //     default: () => import("../components/group-management/CloseGroup.vue"),
        //   },
        // },
      ],
    },
  ],
});

export default routes;
