import { useRouteParams } from "@vueuse/router";

export default () => {
  const groupId = useRouteParams("groupId", "-1", { transform: Number });

  return {
    groupId,
  };
};
