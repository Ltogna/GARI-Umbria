import type { UserModel } from "@/models/mandates";
import type { Emitter } from "mitt";
import { inject } from "vue";

type Events = {
  "show:modal:user:edit": UserModel;
  "is:dirty": boolean;
};

export default function (): Emitter<Events> {
  return inject("emitter") as Emitter<Events>;
}
