import { MODULE_ID } from "@/constants";
import i18n from "@/i18n";
import type { VariantType } from "@abaco/bootstrap-italia-components/src/models";
import { ErrorType, type HttpJsonResult, type HttpResult } from "@abaco/safe-rest/src/HTTPClient";
import { reactive } from "vue";

interface NotificationModel {
  open: boolean;
  variant: VariantType;
  title: string;
  text: string;
  icon: string;
  timeout: number;
}

const DEFAULT_MESSAGE: Readonly<NotificationModel> = {
  open: false,
  variant: "info",
  title: "",
  text: "",
  icon: "",
  timeout: 7000,
};

const message = reactive<NotificationModel>(structuredClone(DEFAULT_MESSAGE));

export function useNotification() {
  const { t } = i18n.global;
  function resetNotification() {
    Object.assign(message, structuredClone(DEFAULT_MESSAGE));
  }

  function showSuccessNotification(text = "") {
    resetNotification();
    message.title = t(`${MODULE_ID}.apiSuccess.generic_save_title`);
    message.text = text;
    message.icon = "circle-check";
    message.variant = "success";
    message.open = true;
  }

  function showFailNotification(text = "") {
    resetNotification();
    message.title = t(`${MODULE_ID}.apiErrors.title`);
    message.text = text || t(`${MODULE_ID}.apiErrors.generic`);
    message.icon = "circle-xmark";
    message.variant = "error";
    message.open = true;
  }

  return { message, resetNotification, showSuccessNotification, showFailNotification };
}

export async function useApiResponseHandler<T>(apiFn: () => Promise<HttpJsonResult<T> | HttpResult>): Promise<T | null | boolean> {
  const { t, te } = i18n.global;
  const { message, resetNotification } = useNotification();
  const errorCode = t(`${MODULE_ID}.apiErrors.title`);
  let errorMessage = t(`${MODULE_ID}.apiErrors.generic`);

  const res = await apiFn();

  resetNotification();

  if (res.errorType === ErrorType.NONE) {
    return "data" in res ? res.data : Promise.resolve(true); //resolve changed in true because fix the delete
  }
  if (res.errorType === ErrorType.HTTP_STATUS && res.response.status !== 404) {
    const response = await res.response.json();
    if (te(`${MODULE_ID}.apiErrors.${response.errorCode}`)) {
      errorMessage = t(`${MODULE_ID}.apiErrors.${response.errorCode}`);
    } else {
      errorMessage = response.message;
    }
    console.error(response.message);
  } else {
    console.error(res);
  }

  message.title = errorCode;
  message.text = errorMessage;
  message.icon = "circle-xmark";
  message.variant = "error";
  message.open = true;

  return Promise.resolve(null);
}
