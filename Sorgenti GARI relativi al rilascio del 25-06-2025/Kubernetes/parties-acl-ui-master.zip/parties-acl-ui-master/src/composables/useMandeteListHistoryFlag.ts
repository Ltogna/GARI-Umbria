import { ref } from "vue";

const history = ref(false);

export default function () {
  return {
    history,
  };
}
