import { useGroupStore } from "@/stores/group";
import usePermissions from "./usePermissions";

export default () => {
  const { isSelectedGroupEditable } = useGroupStore();
  const { canWrite } = usePermissions();
  const canEditGroup = canWrite && isSelectedGroupEditable;

  return {
    canEditGroup,
  };
};
