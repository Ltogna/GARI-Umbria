import { inject } from "vue";

export default function () {
  const isAdmin = (inject("hasPermissionAdmin") as boolean) ?? false;
  const canWrite = (inject("hasPermissionWrite") as boolean) ?? false;
  const canRead = (inject("hasPermissionRead") as boolean) ?? false;

  return {
    /**
     * is admin
     */
    isAdmin,
    /**
     * can read
     */
    canRead,
    /**
     * can write
     */
    canWrite,
  };
}
