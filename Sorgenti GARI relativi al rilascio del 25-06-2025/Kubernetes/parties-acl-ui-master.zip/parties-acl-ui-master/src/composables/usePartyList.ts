import type { FilterModel, PartyFilterSchema, PartyListSchema } from "@/models/parties";
import { reactive, ref } from "vue";

type PartySearchFilterField = keyof FilterModel;

const defaultPage: PartyListSchema = {
  count: 0,
  nextKey: null,
  records: [],
};

const defaultSearch: Partial<PartyFilterSchema> = {
  code: "",
  fullName: "",
};

const loading = ref(false);
const page = reactive<PartyListSchema>(structuredClone(defaultPage));
const search = reactive<Partial<PartyFilterSchema>>(structuredClone(defaultSearch));

export function usePartyList() {
  function resetSearch() {
    loading.value = false;
    Object.assign(search, structuredClone(defaultSearch));
  }
  function resetPage() {
    loading.value = false;
    Object.assign(page, structuredClone(defaultPage));
  }
  function setPageValues(values: PartyListSchema) {
    Object.assign(page, values);
  }

  function setSearchValues(values: PartyFilterSchema) {
    Object.assign(search, values);
  }
  function resetAll() {
    resetPage();
    resetSearch();
  }
  async function removeFilter(filterCode: PartySearchFilterField) {
    search[filterCode] = undefined;
  }
  function updatePageValues(values: PartyListSchema) {
    page.count = values.count;
    page.nextKey = values.nextKey;
    page.records = [...page.records, ...values.records];
  }
  return {
    loading,
    page,
    search,
    resetSearch,
    resetPage,
    resetAll,
    setPageValues,
    removeFilter,
    updatePageValues,
    setSearchValues,
  };
}
