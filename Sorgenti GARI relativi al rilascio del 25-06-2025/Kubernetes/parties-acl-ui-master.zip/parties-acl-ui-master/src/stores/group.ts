import { useApiResponseHandler } from "@/composables/useApiResponseHandler";
import { GROUP_FILTER_KEY } from "@/constants";
import { DEFAULT_GROUP_FILTER } from "@/models/defaultValues";
import type { CreateEntityPayloadModel, EntityFilterModel, EntityModel, InfiniteListEntityModel, NewGroupFormModel } from "@/models/entities";
import { HttpErrorCode } from "@/models/errors";
import { dateToString } from "@/models/utils";
import { closeEntity, createEntity, getEntitiesList, getEntity } from "@/resources/api/entities";
import { ErrorType } from "@abaco/safe-rest/src/HTTPClient";
import { useSessionStorage } from "@vueuse/core";
import { defineStore } from "pinia";

interface State {
  filter: EntityFilterModel;
  infiniteGroupList: InfiniteListEntityModel | null;
  groupList: EntityModel[];
  selectedGroup: EntityModel | null;
  isLoading: boolean;
  hasError: boolean;
}

export const useGroupStore = defineStore({
  id: "group",
  state: () =>
    ({
      filter: useSessionStorage(GROUP_FILTER_KEY, structuredClone(DEFAULT_GROUP_FILTER)),
      isLoading: false,
      infiniteGroupList: null,
      groupList: [],
      selectedGroup: null,
      hasError: false,
    }) as State,
  getters: {
    nextKey(state) {
      return state.infiniteGroupList?.nextKey ?? null;
    },
    count(state) {
      return state.infiniteGroupList?.count ?? 0;
    },
    isSelectedGroupEditable(state) {
      return !!state.selectedGroup?.editable;
    },
  },
  actions: {
    setFilter(filter: EntityFilterModel) {
      this.filter = {
        code: filter.code?.trim(),
        history: filter.history,
        name: filter.name?.trim(),
        next_key: filter.next_key,
        referenceDate: filter.referenceDate,
        registryId: filter.registryId,
      };
    },
    setSelectedGroup(group: EntityModel) {
      this.selectedGroup = group;
    },
    async getGroupsList(loadNext?: boolean) {
      if (!loadNext) {
        this.infiniteGroupList = null;
        this.groupList = [];
        delete this.filter.next_key;
      } else if (loadNext && this.nextKey) {
        this.filter.next_key = this.nextKey;
      }

      this.isLoading = true;

      const response = await getEntitiesList(this.filter);

      if (response.errorType !== ErrorType.NONE) {
        this.hasError = true;
        console.warn(response);
      } else {
        this.hasError = false;
        this.infiniteGroupList = response.data;
        this.groupList = [...this.groupList, ...response.data.records];
      }

      this.isLoading = false;
    },
    async getGroupDetails(groupId: number) {
      this.isLoading = true;

      const response = await getEntity(groupId);

      if (response.errorType !== ErrorType.NONE) {
        this.hasError = true;
        console.warn(response);
      } else {
        this.hasError = false;
        this.selectedGroup = response.data;
      }
      this.isLoading = false;
    },
    async createGroup(groupData: NewGroupFormModel) {
      this.isLoading = true;
      const { denomination, startDate, type } = groupData;

      const parsedDayFrom = dateToString.safeParse(startDate);
      if (!parsedDayFrom.success) {
        console.warn(parsedDayFrom.error);
        return;
      }

      const mappedGroupData: CreateEntityPayloadModel = {
        day_from: parsedDayFrom.data,
        entity_type_code: type,
        name: denomination,
      };

      const response = await useApiResponseHandler(() => createEntity(mappedGroupData));

      if (!response) {
        this.hasError = true;
        this.isLoading = false;
      } else {
        this.hasError = false;
        this.isLoading = false;
        return response;
      }
    },
    async closeGroup(dayTo: Date) {
      if (!this.selectedGroup) {
        console.warn("No group selected");
        return;
      }

      const parsedDayTo = dateToString.safeParse(dayTo);
      this.hasError = parsedDayTo.success;
      if (!parsedDayTo.success) {
        console.warn(parsedDayTo.error);
        return;
      }
      const day_to = parsedDayTo.data.toString();

      this.isLoading = true;

      const resp = await closeEntity(this.selectedGroup.id, { close_day: day_to });

      if (resp.errorType !== ErrorType.NONE) {
        this.hasError = true;
        if (resp.errorType === ErrorType.HTTP_STATUS) {
          console.warn(resp.response);
          try {
            const { errorCode } = await resp.response.json();
            if (errorCode === HttpErrorCode.ENTITY_WITH_EXCLUSIVE_PARTY) {
              this.isLoading = false;
              this.hasError = false;
              return HttpErrorCode.ENTITY_WITH_EXCLUSIVE_PARTY;
            }
          } catch (err) {
            console.warn(err);
          }
        } else {
          console.warn(resp.err);
        }
      } else {
        this.hasError = false;
        this.isLoading = false;
        return resp.data;
      }
      this.isLoading = false;
      return;
    },
  },
});
