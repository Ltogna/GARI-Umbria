import { DEFAULT_USER_FILTER } from "@/models/defaultValues";
import type { InfiniteListUserModel, UserFilterModel, UserModel } from "@/models/mandates";
import { getUsersByEntity } from "@/resources/api/mandates";
import { ErrorType } from "@abaco/safe-rest/src/HTTPClient";
import { defineStore } from "pinia";

interface State {
  infiniteSelectedGroupUsers: InfiniteListUserModel | null;
  selectedGroupUsers: UserModel[];
  isLoading: boolean;
  hasError: boolean;
  filter: UserFilterModel;
}

export const useUserStore = defineStore({
  id: "user",
  state: () =>
    ({
      isLoading: false,
      hasError: false,
      infiniteSelectedGroupUsers: null,
      selectedGroupUsers: [],
      filter: structuredClone(DEFAULT_USER_FILTER),
    }) as State,
  getters: {
    nextKey(state) {
      return state.infiniteSelectedGroupUsers?.nextKey ?? null;
    },
    count(state) {
      return state.infiniteSelectedGroupUsers?.count ?? 0;
    },
  },
  actions: {
    setFilter(filter: UserFilterModel) {
      this.filter = filter;
    },
    resetFilter() {
      Object.assign(this.filter, structuredClone(DEFAULT_USER_FILTER));
    },
    /**
     * @param groupId
     * @param loadNext
     */
    async getGroupUsers(groupId: number, loadNext?: boolean) {
      if (!loadNext) {
        this.infiniteSelectedGroupUsers = null;
        this.selectedGroupUsers = [];
        delete this.filter.next_key;
      } else if (loadNext && this.nextKey) {
        this.filter.next_key = this.nextKey;
      }

      this.isLoading = true;

      const response = await getUsersByEntity(groupId, this.filter);
      if (response.errorType !== ErrorType.NONE) {
        console.warn(response);
        this.hasError = true;
      } else {
        this.hasError = false;
        this.infiniteSelectedGroupUsers = response.data;
        this.selectedGroupUsers = [...this.selectedGroupUsers, ...response.data.records];
      }
      this.isLoading = false;
    },
  },
});
