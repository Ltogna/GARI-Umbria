import type { ClientConfigurationListModel } from "@/models/support";
import { getConfigCodes } from "@/resources/api/support";
import { ErrorType } from "@abaco/safe-rest/src/HTTPClient";
import { defineStore } from "pinia";

interface State {
  config: ClientConfigurationListModel | null;
  isLoading: boolean;
  hasError: boolean;
}

export const useConfigStore = defineStore({
  id: "config",
  state: () =>
    ({
      config: null,
      hasError: false,
      isLoading: false,
    }) as State,
  getters: {
    maxAnomlyLevelAllowedEditUser(state) {
      return (state.config?.client_configuration.find((conf) => conf.name === "max_anomly_level_allowed_edit_user")?.value as string) ?? "";
    },
    maxAnomlyLevelAllowedEditEntity(state) {
      return (state.config?.client_configuration.find((conf) => conf.name === "max_anomly_level_allowed_edit_entity")?.value as string) ?? "";
    },
    anomaliesRegistryUrl(state) {
      return (state.config?.client_configuration.find((conf) => conf.name === "anomalies_registry_url")?.value as string) ?? "";
    },
    showUncategorizedAnomalyTypes(state) {
      return (state.config?.client_configuration.find((conf) => conf.name === "fl_show_uncategorized_anomaly_types")?.value as boolean) ?? true;
    },
    partyRegistryUrl(state) {
      return (state.config?.client_configuration.find((conf) => conf.name === "party_registry_url")?.value as string) ?? "";
    },
    allowPastDate(state) {
      return (state.config?.client_configuration.find((conf) => conf.name === "allow_past_date")?.value as boolean) ?? true;
    },
    anomaliesUserCodeKey(state) {
      return (state.config?.client_configuration.find((conf) => conf.name === "anomalies_user_code_key")?.value as string) ?? "";
    },
    maxAnomlyLevelAllowedEditParty(state) {
      return (state.config?.client_configuration.find((conf) => conf.name === "max_anomly_level_allowed_edit_party")?.value as string) ?? "";
    },
    anomaliesEntityCodeKey(state) {
      return (state.config?.client_configuration.find((conf) => conf.name === "anomalies_entity_code_key")?.value as string) ?? "";
    },
    showChronologicalDueDate(state) {
      return (state.config?.client_configuration.find((conf) => conf.name === "show_chronological_due_date")?.value as boolean) ?? false;
    },
    allowMandatePastCloseDate(state) {
      return (state.config?.client_configuration.find((conf) => conf.name === "allow_past_close_date")?.value as boolean) ?? false;
    },
  },
  actions: {
    async loadConfig(key?: string) {
      this.isLoading = true;

      const response = await getConfigCodes(key);

      if (response.errorType !== ErrorType.NONE) {
        this.hasError = true;
      } else {
        this.config = response.data;
        this.hasError = false;
      }
    },
  },
});
