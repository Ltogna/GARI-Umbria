import vue from "@vitejs/plugin-vue";
import { execSync } from "child_process";
import { fileURLToPath, URL } from "url";
import { defineConfig } from "vite";
import { viteStaticCopy } from "vite-plugin-static-copy";
import nodePackage from "./package.json";
import { BASE } from "./src/constants";
import VueDevTools from "vite-plugin-vue-devtools";

try {
  process.env.VITE_APP_VERSION = nodePackage.version;
  process.env.VITE_APP_GIT_COMMIT = execSync("git rev-parse --short=8 HEAD").toString().trim();
} catch (err) {
  //
}
// https://vitejs.dev/config/
export default defineConfig({
  plugins: [
    viteStaticCopy({
      targets: [
        {
          src: "node_modules/bootstrap-italia/dist/**/*",
          dest: "bootstrap-italia/dist",
        },
      ],
    }),
    vue(),
    VueDevTools(),
  ],
  base: BASE,
  resolve: {
    alias: {
      "@": fileURLToPath(new URL("./src", import.meta.url)),
    },
  },
  build: {
    // target: "esnext",
    rollupOptions: {
      output: {
        entryFileNames: "[name].[hash].js",
        assetFileNames: "assets/[name].[hash].[ext]",
      },
    },
  },
  css: {
    devSourcemap: true,
  },
  server: {
    port: 3000,
    proxy: {
      "/parties-acl-server": {
        // target: "http://localhost:8080/",
        target: "https://iacs-dev.fe.abacogroup.eu/",
        // target: "https://farm-coll.avepa.it/",
        // target: "https://iacs-test.abacogroup.cloud/",
        changeOrigin: true,
        secure: false,
      },
      "/party-registry": {
        target: "https://iacs-dev.fe.abacogroup.eu/",
        // target: "https://farm-coll.avepa.it/",
        // target: "https://iacs-test.abacogroup.cloud/",
        changeOrigin: true,
        secure: false,
      },
      "/sso2": {
        target: "https://iacs-dev.fe.abacogroup.eu/",
        // target: "https://farm-coll.avepa.it/",
        // target: "https://iacs-test.abacogroup.cloud/",
        secure: false,
        changeOrigin: true,
      },
      "/file-store": {
        target: "https://iacs-dev.fe.abacogroup.eu/",
        changeOrigin: true,
        secure: true,
      },
    },
  },
});
