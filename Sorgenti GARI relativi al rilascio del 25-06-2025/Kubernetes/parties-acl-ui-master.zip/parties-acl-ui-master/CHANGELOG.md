# Changelog

## [v1.3.4](https://gitlab.fe.abacogroup.eu/new-agri/parties-acl-ui/compare/v1.3.3...v1.3.4) (2024-09-05)

### Fixes

* :sparkles: #150894 added tream on inputs text, closes [#150894](https://abacogroup.easyredmine.com/issues/150894)

### [v1.3.3](https://gitlab.fe.abacogroup.eu/new-agri/parties-acl-ui/compare/v1.3.2...v1.3.3) (2024-08-19)

#### Features

* :bug: #148799 fixed edit mandate manually insert date, closes [#148799](https://abacogroup.easyredmine.com/issues/148799)

#### Other

* :memo: update changelog

### [v1.3.2](https://gitlab.fe.abacogroup.eu/new-agri/parties-acl-ui/compare/v1.3.1...v1.3.2) (2024-07-18)

#### Fixes

* :bug: fixed labels
* :bug: #145814  fixed duplicate message error & display after submit, closes [#145814](https://abacogroup.easyredmine.com/issues/145814)
* :bug: #145872 fixed insert mannualy date, closes [#145872](https://abacogroup.easyredmine.com/issues/145872)
* :bug: #145814 error message will dispaly after submit, closes [#145814](https://abacogroup.easyredmine.com/issues/145814)

#### Other

* :memo: update changelog
* :lipstick: #145816 changed style buttons, closes [#145816](https://abacogroup.easyredmine.com/issues/145816)

#### Documentation

* :memo: update changelog
* :memo: update changelog

### [v1.3.1](https://gitlab.fe.abacogroup.eu/new-agri/parties-acl-ui/compare/v1.3.0...v1.3.1) (2024-07-17)

#### Fixes

* :bug: #145840 start search on open SearchGroupModal if isn't ADMIN, closes [#145840](https://abacogroup.easyredmine.com/issues/145840)

#### Other

* :memo: update changelog

## [v1.3.0](https://gitlab.fe.abacogroup.eu/new-agri/parties-acl-ui/compare/v1.2.1...v1.3.0) (2024-07-04)

### Features

* :sparkles: #133717 mandate optional extend date, closes [#133717](https://abacogroup.easyredmine.com/issues/133717)
* :sparkles: #133717 added delete mandate, closes [#133717](https://abacogroup.easyredmine.com/issues/133717)
* :sparkles: edit document if the mandate is revacable
* :sparkles: added revoke mandate flag
* :sparkles: added revoke modal message
* :sparkles: improved revoke page
* :sparkles: added status mandates in table
* :sparkles: improved status mandates
* :sparkles: improved chronological due date
* :sparkles: added permission
* :sparkles: improved document list
* :sparkles: added close mandate in past date
* :sparkles: check exclusive mandates
* :sparkles: improved multiple documents
* :sparkles: upload files
* :alien: rename PARTIES in MANDATES
* :sparkles: improved handleModalCLose for dd
* :sparkles: improved readonly documents
* :alien: update model
* :alien: remove unused API
* :sparkles: improved documents wrapper
* :sparkles: update api's e models for documents
* :sparkles: save document
* :sparkles: improved load documents types
* :sparkles: improved documents accordion
* :sparkles: update model
* :alien: update API requests
* :sparkles: added dynamic document wrapper
* :sparkles: added document accordion
* :sparkles: added DynamicDocuments form & list
* :sparkles: added notification store
* :sparkles: start implementing api for documents
* :sparkles: added models for documents
* :sparkles: added routes for documents in party
* :sparkles: start implementing accordion
* :sparkles: added config showChronologicalDueDate
* :sparkles: #133717 improved layout, closes [#133717](https://abacogroup.easyredmine.com/issues/133717)
* :sparkles: added button new mandate
* :sparkles: added chips for filter search

### Fixes

* :green_heart: fixed CI
* :green_heart: fixed CI
* :truck: #133717 fixed back url, closes [#133717](https://abacogroup.easyredmine.com/issues/133717)
* :sparkles: #133717 reset history flag during navigation, closes [#133717](https://abacogroup.easyredmine.com/issues/133717)
* :sparkles: fixed mismatch party and mandate
* :bug: fixed history flalg
* :sparkles: fixed typo

### Other

* :memo: update changelog
* :lipstick: added field-required
* :sparkles: added locals
* :sparkles: aded locals
* :wrench: added file store proxy
* :sparkles: added locals for documents
* :arrow_up: update dependencies
* :lipstick: style improved
* :sparkles: edit label name

### [v1.2.1](https://gitlab.fe.abacogroup.eu/new-agri/parties-acl-ui/compare/v1.2.0...v1.2.1) (2024-06-21)

## [v1.2.0](https://gitlab.fe.abacogroup.eu/new-agri/parties-acl-ui/compare/v1.1.4...v1.2.0) (2024-04-05)

### Features

* :sparkles: update dependencies
* :sparkles: #135540 acl value to access the resource: -1 skip check, 0 must have almost one read mandate, 1 must have almost one manage mandate, closes [#135540](https://abacogroup.easyredmine.com/issues/135540)

### Other

* :bug: fixed vite config

### [v1.1.4](https://gitlab.fe.abacogroup.eu/new-agri/parties-acl-ui/compare/v1.1.3...v1.1.4) (2024-02-14)

### [v1.1.3](https://gitlab.fe.abacogroup.eu/new-agri/parties-acl-ui/compare/v1.1.2...v1.1.3) (2024-02-14)

#### Fixes

* :green_heart: fixed CI

#### Other

* :arrow_up: update depenencies

### [v1.1.2](https://gitlab.fe.abacogroup.eu/new-agri/parties-acl-ui/compare/v1.1.1...v1.1.2) (2023-09-14)

#### Other

* :arrow_up: update dependencies

### [v1.1.1](https://gitlab.fe.abacogroup.eu/new-agri/parties-acl-ui/compare/v1.1.0...v1.1.1) (2023-07-31)

#### Features

* :sparkles: #110615 removed current group from hierarchy List, closes [#110615](https://abacogroup.easyredmine.com/issues/110615)
* :wheelchair: better accessibility on tables, minor refactor

#### Fixes

* :bug: fixed responsiveness table
* :bug: fixed class for responsivness

#### Other

* :lipstick: update styles
* :label: welcome back types
* :arrow_up: update dependencies
* minor package update
* :arrow_up: upgrade dependencies

#### Documentation

* :memo: updated CHANGELOG.md

## [v1.1.0](https://gitlab.fe.abacogroup.eu/new-agri/parties-acl-ui/compare/v1.0.0...v1.1.0) (2023-07-11)

### Features

* :sparkles: has mandate in parties list

### Fixes

* :bug: add missing fixes on using useApiResponseHandler
* :bug: fixed error on deleteUser
* :zap: parent group management improved
* :iphone: fixed responsiveness & accessibility on UserListTable
* :wheelchair: fixed tables accessibility
* :wheelchair: improve accessibility
* :wheelchair: fixed table headers accessibility
* :wheelchair: fixed accessibility back buttons
* :rotating_light: fixed textarea warnings
* :wrench: updated config
* :bug: fixed warn mismatch version

### Other

* :arrow_up: update dependencies
* :wrench: updated tsconfig.cypress-ct.json
* :fire: clean types d.ts
* :art: format code
* :art: format code
* :recycle: minor refactor
* :arrow_up: upgradde dependencies
* :arrow_up: upgrade dependencies

### Documentation

* :memo: updated CHANGELOG
* :memo: updated CHANGELOG.md
* :memo: updated CHANGELOG.md

## v1.0.0 (2023-06-19)

### Features

* :children_crossing: add show error notification on save group hierarchy
* :sparkles: add show fail notification on composable
* :children_crossing: add success notification on save group hierarchy
* :goal_net: add notification on remove group from hierarchy
* :goal_net: better error management on user actions
* :alien: use close_day in entity model
* :sparkles: add alert on mandates list
* :sparkles: mandate set day_to instead close_day
* :bug: fixed new mandate form
* :sparkles: add function to remove blank properties from obj
* :passport_control: add permissions can edit group
* :sparkles: update close date requests payload
* :truck: changed index path to avoid conflicts
* :sparkles: add icon on close column group list, minor model change
* :sparkles: added redirect
* :truck: changed index router
* :sparkles: close mandate button
* :construction: start implementing new version of group filter & list
* :sparkles: removed end date
* :sparkles: changed reset/remove group button on hierarchy
* :sparkles: show end date in group details
* :sparkles: add allow past date on start date on new mandate
* :globe_with_meridians: add translations
* :globe_with_meridians: add translations
* :sparkles: add min start date from config on create group
* :sparkles: add load config
* :sparkles: update end date of mandate
* :alien: added updateCloseDate api
* :sparkles: new group submit added
* :alien: update get children api
* :sparkles: add remove child group
* :passport_control: add route guards on groupId routes & group list
* :sparkles: add new close group implementation
* :sparkles: user permissions
* :alien: add close entity api
* :sparkles: show confirm route leave modal on form dirty event
* :goal_net: better error management on GroupHierarchy
* :sparkles: add route guard dirty form modal
* :sparkles: improved CloseGroup form
* :sparkles: Update mandate edit form
* :wheelchair: better accessibility
* :sparkles: add confirm delete user modal
* :bug: fixed form close mandate
* :sparkles: add load more on group hierarchy
* :sparkles: add conditional confirm modal on change parent group
* :alien: updated add child entity api
* :sparkles: implemented change parent group, add spinner on confirm
* :sparkles: add restore inital parent group
* :sparkles: add change group parent locally
* :sparkles: load entity children on hierarchy
* :safety_vest: add validation on add user
* :sparkles: update group
* :bug: fix mandate list
* :alien: change API path
* :sparkles: add notification to delete user from entity
* :sparkles: changed api response composable to handle HttpResponse
* :truck: moved SummaryGroup
* :sparkles: implemented entity users filter
* :safety_vest: minor validation on close group date
* :sparkles: implemented close group, minor clean
* :sparkles: update mandate edit form
* :sparkles: improve mandate
* :sparkles: add filter chip on users table
* :sparkles: add alert on user modal
* :sparkles: create mandate detail component, WIP edit mandate component
* :sparkles: add edit iser in group
* :sparkles: add search user in group, see TODO
* :construction: start implementing edit user in group
* :sparkles: implemented add user to group
* :alien: admin user list
* :alien: updated entity model
* :sparkles: add groupId composable
* :sparkles: improved loadmore on group list table
* :construction: start implementing delete user from group
* :sparkles: improve modal tables
* :sparkles: reset party reset modal on close
* :sparkles: implemented users on user list table component
* :alien: update user model, minor api fix
* :truck: rename SearchSubjectModal in SearchPartyModal
* :sparkles: search party modal
* :alien: add get users by entity api & model
* :sparkles: add code input on create group
* :truck: rename EntitySearchForm in PartySearchForm
* :sparkles: create mandate table list component
* :sparkles: show users list on group list table
* :alien: add user data to entity schema
* :sparkles: removed unnecessary stores
* :sparkles: add missing fields on summary group
* :sparkles: add user date composable
* :sparkles: notifications
* :sparkles: add load type on create group, fixed typo
* :construction: start implementing create group
* :art: improve form mandate
* :art: improve form mandate
* :sparkles: imporove form new mandate
* :sparkles: imporove form new mandate
* :sparkles: implemented update group
* :sparkles: implemented summary group
* :sparkles: new mandate form
* :sparkles: implemented search & list group
* :sparkles: imporve parties list
* :sparkles: parties list
* :sparkles: insert group into form
* :sparkles: search group modal
* :alien: updated types api & models
* :sparkles: improved group search modal
* :arrow_up: update dependencies
* :sparkles: implemented vee-validate
* :alien: updated revision models
* :sparkles: add user modal buttons
* :sparkles: improved views
* :sparkles: added new mandate view
* :sparkles: add close group route
* :sparkles: add hierarchy route and backButton management
* :sparkles: add close & confirm close group modal
* :sparkles: add GroupHierarchy component
* :sparkles: add common summary group component
* :sparkles: add routing user management, add locales
* :sparkles: add config store
* :sparkles: add UsersListTable
* :construction: minor changes
* :globe_with_meridians: add locales
* :sparkles: updated API
* :construction: start implementing group details component
* :sparkles: added back button
* :sparkles: entity detail view
* :sparkles: add backbutton
* :construction: start implementing GroupListTable component, minor changes
* :sparkles: responsive table
* :sparkles: add GenericSearchModal component
* :sparkles: improved routing
* :sparkles: add new group component
* :sparkles: call entities API
* :sparkles: add search group component
* :sparkles: start implementing group components
* :sparkles: better API call management
* :sparkles: add anomalies apis & models
* :sparkles: search parties
* :sparkles: add types apis & models
* :sparkles: add support models % apis
* :sparkles: added mandates & revision models & api
* :sparkles: added permission
* :sparkles: start implementing mandates models & apis
* :sparkles: add missing entity model
* :sparkles: add entities apis & models
* :arrow_up: update dependencies
* :tada: first import

### Fixes

* :goal_net: Fixed alert on hierarchy
* :bug: fixed pinia initialization
* :bug: fixed pinia initialization
* :bug: fixed config on standalone
* :adhesive_bandage: minor change on new mandate validation to preserve style
* :bug: fixed min day from on MandateFormView
* :wrench: fixed configuration
* :wrench: fixed configuration
* :children_crossing: fixed lag on action user modal
* :adhesive_bandage: reset error alert on closing modal actions user
* :bug: fixed mandate extend/revoke button visibility
* :adhesive_bandage: minor fix
* :bug: fixed hidden/show action buttons on group section
* :wheelchair: minor aria fix
* :sparkles: update schema
* :adhesive_bandage: change route destination on close closeGroup modal
* :globe_with_meridians: minor fix
* :adhesive_bandage: minor fix to avoid using isEmpty on getChildrenEntity
* :bug: delete button fixed
* :bug: delete button fixed
* :bug: reset date on mandate form fixed
* :adhesive_bandage: add new required error validation message
* :bug: datepicker error style on submit fixed
* :bug: close mandate min date
* :bug: used entity name instead entity description
* :bug: minor fix group hierarchy
* :bug: minor fix on dirty form, minor clean
* :bug: fixed leave dirty page modal behaviour
* :bug: minor fixes on create group
* :bug: minor fix new group api
* :bug: fixed onbeforeunload errors
* :bug: better implementation on change/delete group parent
* :bug: fixed guard modal on submit form
* :adhesive_bandage: disabled save btn on loading
* :bug: changed children groups management on hierarchy
* :bug: fixed addChildEntity api
* :bug: fix on edit group, minor clean
* :adhesive_bandage: minor fix search groups, minor changes
* :bug: minor fix on group list
* :adhesive_bandage: fixed deafult values on search form group
* :adhesive_bandage: disabled buttons on loading on GroupHierarchy
* :bug: minor fix on search user
* :bug: fixed search user
* :bug: fixed restore group when group has no parent
* :bug: fix mandate form end day
* :bug: fix day to vlidation for mandate form (new/edit)
* :bug: update alert message in group search page
* :bug: fixed group hierarchy route
* :bug: fixed close group route
* :bug: fix mandate
* :bug: fixed api response handler, minor fix on delete user
* :bug: fixed load users in entity
* :pencil2: fixed typo
* :bug: fixed edit group, summary & api update group
* :bug: fix day to validation in mandate edit form
* :bug: fixed encoded user on update user in entity, minor fixes
* :bug: minor fix on reset user modal form
* :bug: fixed user apis using encodedURI
* :bug: fix zod schema for Entity
* :bug: minor fix
* :bug: minor import fix
* :bug: minor fix
* :bug: minor fix
* :bug: minor model fix
* :bug: minor model fix, add todo
* :bug: fixed description on edit group
* :alien: fixed entity payload schemas
* :bug: minor model fix
* :alien: changed entity models & updateEntity api
* :bug: fixed import
* :bug: fixed models import on types api
* :globe_with_meridians: minor fix
* :globe_with_meridians: fixed locales, minor fix
* :globe_with_meridians: fixed locales
* :adhesive_bandage: add missing back route on close group
* :adhesive_bandage: minor fixes on close group
* :adhesive_bandage: minor fix
* :globe_with_meridians: fixed locale
* :bug: fixed filter
* :globe_with_meridians: fixed translations
* :wrench: add missing proxy
* :pencil2: fixed typo
* :bug: fixed some apis & models issues

### Styles

* :lipstick: required input style added in edit group
* :lipstick: better style on form fields required
* :lipstick: fixed modal buttons layout

### Other

* :recycle: minor refactor
* :pencil2: fixed typo
* :recycle: minor refactor
* :see_no_evil: added  some files to gitignore
* :recycle: minor clean & refactor
* :recycle: minor clean & refactor on MandateDetail
* :recycle: minor refactor on useApiResponseHandler
* :construction: changed min start date on mandate form
* :heavy_plus_sign: add @types/lodash devDependency
* :recycle: minor refactor on MandateListTable
* :art: format code
* :bulb: add todo
* :fire: removed .gitkeep
* :globe_with_meridians: minor text change
* :heavy_minus_sign: remove lodash dependencies
* :recycle: minor refactor
* :recycle: refactor omitBy using getValuable
* :recycle: minor refactor
* :speech_balloon: update text on modal close group
* :technologist: minor change
* :recycle: minor refactor
* :recycle: minor refactor
* :goal_net: minor change
* :sparkles: reload entity list when entity is closed
* :recycle: minor refactor
* :lipstick: changed layout on SearchGroups & changed locales
* :speech_balloon: add placeholder on user list if description is empty
* :globe_with_meridians: add translation
* :wheelchair: better aria, minor refactor
* :art: format code
* :recycle: refactor moduleId & others
* :fire: removed dead view
* :recycle: minor refactor & improved accessibility
* :recycle: refactor & improved accessibility
* :bulb: add todo comment
* :speech_balloon: add placeholder text on hierrachy when no parent group selected
* :recycle: minor refactor
* :pencil2: fix typo
* :label: better config model typing
* :art: format code
* :label: better typing
* :bug: fixed types
* :recycle: minor refactor
* better buttons management on group hierarchy
* :art: minor format
* :pencil2: fixed models typos
* :recycle: add load more component on MadateListTable
* :recycle: add LoadMoreRow component
* :art: format code
* :recycle: add LoadMore component on PartyList
* :recycle: minor clean & refactor
* :lipstick: some style fixed
* :globe_with_meridians: add missing translation
* :globe_with_meridians: add locales
* :recycle: minor refactor
* :goal_net: better error management
* :zap: minor improvement on group hierarchy
* :recycle: refactor search groups using session storage
* :wrench: added css sourcemap
* :recycle: minor refactor api response handler
* :recycle: refator load more feat in new component
* :recycle: refactor default values const
* :lipstick: improve style
* :art: format code
* :safety_vest: add default date on close group
* :arrow_up: update dependencies
* :truck: renamed AddUserModal to ActionsUserModal
* :globe_with_meridians: updated locales
* :globe_with_meridians: add locales
* :lipstick: fixed group list styles
* :recycle: refactor user / group store
* :bulb: add todo
* :bulb: add todo
* :lipstick: minor layout change
* :truck: rename view
* :sparkles: Layout form mandate
* :bug: fix labels
* :truck: renmaed GroupDetails to EditGroup
* :recycle: refactor entity models, minor api fix
* :art: format code
* :recycle: changed RouteName to enum
* updated tsconfig to prevent build error
* :arrow_up: upgrade typescript@5.0.4
* :recycle: minor refactor
* :art: format code
* :globe_with_meridians: imporved locales
* :recycle: changed routing on groupId routes
* :art: minor change
* :globe_with_meridians: added translations for new mandate button
* :globe_with_meridians: updated locales
* :heavy_plus_sign: add @vueuse/router dependency
* :recycle: refactor routes
* :recycle: minor refactor
* :recycle: better modals management
* :recycle: refactor modal managment in different modals
* :bug: Fixed translations
* :globe_with_meridians: added missin key
* :truck: move party/parties in entity/entities
* :truck: rename entity search form
* :truck: rename entity list componet
* :globe_with_meridians: add translations
* :truck: rename view
* :truck: rename schemas
* :sparkles: reneame stores/party.ts in stores/entity.ts
* :globe_with_meridians: add missing translation
* :globe_with_meridians: add missing translations
* minor fixes
* :globe_with_meridians: update translations
* renamed enum
* :art: format code
* :wrench: config default port
