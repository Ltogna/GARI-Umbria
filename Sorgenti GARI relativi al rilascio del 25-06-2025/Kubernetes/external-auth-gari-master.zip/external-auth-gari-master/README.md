# External-auth-svg

External authentication serivce for FVG

## How to generate certificate and private key 

Run the following command to generate keystore, Remember the password used in this step because it will be asked in the following steps.

`keytool -genkey -keyalg RSA -v -keystore keystore.jks -alias <your-alias> -validity <your-validity>`

Follow the prompted instructions to in insert data into the certificate.

Export it from jks to pkcs12

`keytool -importkeystore -srckeystore keystore.jks -destkeystore keystore.p12 -srcstoretype jks -deststoretype pkcs12`

Write pkcs12 to pem file

`openssl pkcs12 -nodes -in keystore.p12 -out keystore.pem`

In the file called keystore.pem you will find the generated certificate and key

# Mock

```sh
docker run --name=testsamlidp_idp -p 8080:8080 -p 8443:8443 -e SIMPLESAMLPHP_SP_ENTITY_ID=umbria-dev.fe.abacogroup.eu -e SIMPLESAMLPHP_SP_ASSERTION_CONSUMER_SERVICE=http://localhost:10000/ac -e SIMPLESAMLPHP_SP_SINGLE_LOGOUT_SERVICE=http://localhost/simplesaml/slo -d kristophjunge/test-saml-idp
```