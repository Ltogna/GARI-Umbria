package com.abacogroup.external.auth.gari.core.saml;

public class SAMLValidationException extends RuntimeException {

	private static final long serialVersionUID = -4525035549588382910L;

	public SAMLValidationException(String message, Throwable cause) {
		super(message, cause);
	}

	public SAMLValidationException(String message) {
		super(message);
	}

	public SAMLValidationException(Throwable cause) {
		super(cause);
	}

}
