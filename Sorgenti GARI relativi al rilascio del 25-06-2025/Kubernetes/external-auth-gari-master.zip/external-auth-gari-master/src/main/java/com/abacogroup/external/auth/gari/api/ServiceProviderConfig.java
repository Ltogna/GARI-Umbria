package com.abacogroup.external.auth.gari.api;

import java.util.List;

import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class ServiceProviderConfig {
	@NotEmpty
	private String entityId;
	@NotEmpty
	private String privKey;
	@NotEmpty
	private String cert;

	@NotEmpty
	private String displayName;
	@NotNull
	private List<String> attributes;
	@NotNull
	private List<String> eidasMinimumAttributes;
	@NotNull
	private List<String> eidasFullAttributes;
	@NotEmpty
	private String minAuthRef;
}
