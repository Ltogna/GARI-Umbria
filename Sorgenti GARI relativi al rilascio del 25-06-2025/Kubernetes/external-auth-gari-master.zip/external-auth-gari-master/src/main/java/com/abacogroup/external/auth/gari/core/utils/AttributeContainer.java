package com.abacogroup.external.auth.gari.core.utils;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class AttributeContainer {

    private String fiscalCode;

    private String email;

    private String name;

    private String surname;

    private String inResponseTo;

}
