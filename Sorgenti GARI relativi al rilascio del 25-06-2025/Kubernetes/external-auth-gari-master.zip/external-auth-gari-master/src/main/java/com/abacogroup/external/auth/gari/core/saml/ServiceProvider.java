package com.abacogroup.external.auth.gari.core.saml;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.StringWriter;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.security.KeyFactory;
import java.security.PrivateKey;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.security.spec.PKCS8EncodedKeySpec;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.opensaml.core.xml.config.XMLObjectProviderRegistrySupport;
import org.opensaml.core.xml.io.Marshaller;
import org.opensaml.saml.common.xml.SAMLConstants;
import org.opensaml.saml.saml2.core.NameID;
import org.opensaml.saml.saml2.metadata.*;
import org.opensaml.security.SecurityException;
import org.opensaml.security.credential.UsageType;
import org.opensaml.security.x509.BasicX509Credential;
import org.opensaml.security.x509.X509Credential;
import org.opensaml.xmlsec.SignatureSigningParameters;
import org.opensaml.xmlsec.keyinfo.KeyInfoGenerator;
import org.opensaml.xmlsec.keyinfo.impl.X509KeyInfoGeneratorFactory;
import org.opensaml.xmlsec.signature.SignableXMLObject;
import org.opensaml.xmlsec.signature.Signature;
import org.opensaml.xmlsec.signature.support.SignatureConstants;
import org.opensaml.xmlsec.signature.support.SignatureSupport;
import org.w3c.dom.Document;

import com.abacogroup.external.auth.gari.api.ServiceProviderConfig;

import net.shibboleth.utilities.java.support.xml.BasicParserPool;

public class ServiceProvider {
	private static final String LANG = "it";

	private ServiceProviderConfig config;
	private X509Credential credential;
	private X509KeyInfoGeneratorFactory keyInfoGeneratorFactory;

	private BasicParserPool parserPool;

	public ServiceProvider(BasicParserPool parserPool, ServiceProviderConfig config) {
		this.parserPool = parserPool;
		this.config = config;
		this.credential = this.loadX509Credentials(config.getCert(), config.getPrivKey());

		keyInfoGeneratorFactory = new X509KeyInfoGeneratorFactory();
		keyInfoGeneratorFactory.setEmitEntityCertificate(true);
	}

	public String getEntityId() {
		return config.getEntityId();
	}

	public X509Credential getCredential() {
		return credential;
	}

	private X509Credential loadX509Credentials(String certPath, String keyPath) {
		try {
			X509Certificate cert;
			try (InputStream in = new FileInputStream(certPath)) {
				CertificateFactory cf = CertificateFactory.getInstance("X.509");
				cert = (X509Certificate) cf.generateCertificate(in);
			}

			PrivateKey privKey = readPrivateKey(new File(keyPath));

			return new BasicX509Credential(cert, privKey);
		} catch (Exception e) {
			throw new RuntimeException(e.getMessage(), e);
		}
	}

	private PrivateKey readPrivateKey(File keyFile) throws Exception {
		// read key bytes
		byte[] keyBytes = Files.readAllBytes(keyFile.toPath());

		String privateKey = new String(keyBytes, StandardCharsets.UTF_8);
		privateKey = privateKey
				.replaceAll("(-+BEGIN [RSA ]?PRIVATE KEY-+\r?\n|-+END [RSA ]?PRIVATE KEY-+\r?\n?)", "")
				.replaceAll("\r|\n", "");

		keyBytes = Base64.getDecoder().decode(privateKey);

		PKCS8EncodedKeySpec spec = new PKCS8EncodedKeySpec(keyBytes);
		KeyFactory keyFactory = KeyFactory.getInstance("RSA");
		return keyFactory.generatePrivate(spec);
	}

	public String signAndMarshal(SignableXMLObject obj, String canonicalizationAlgorithm) throws Exception {
		X509KeyInfoGeneratorFactory keyInfoGeneratorFactory = new X509KeyInfoGeneratorFactory();
		keyInfoGeneratorFactory.setEmitEntityCertificate(true);
		KeyInfoGenerator keyInfoGenerator = keyInfoGeneratorFactory.newInstance();

		Signature signature = OpenSAMLUtils.buildSAMLObject(Signature.class);
		SignatureSigningParameters parameters = new SignatureSigningParameters();
		parameters.setKeyInfoGenerator(keyInfoGenerator);
		parameters.setSigningCredential(credential);
		parameters.setSignatureAlgorithm(SignatureConstants.ALGO_ID_SIGNATURE_RSA_SHA256);
		parameters.setSignatureCanonicalizationAlgorithm(canonicalizationAlgorithm);
		SignatureSupport.prepareSignatureParams(signature, parameters);
		SignatureSupport.signObject(obj, parameters);

		Document document;
		DocumentBuilder builder = parserPool.getBuilder();
		try {
			document = builder.newDocument();
		} finally {
			parserPool.returnBuilder(builder);
		}

		Marshaller out = XMLObjectProviderRegistrySupport.getMarshallerFactory().getMarshaller(obj);
		out.marshall(obj, document);

		Transformer transformer = TransformerFactory.newInstance().newTransformer();
		StringWriter writer = new StringWriter();
		StreamResult streamResult = new StreamResult(writer);
		DOMSource source = new DOMSource(document);
		transformer.transform(source, streamResult);
		writer.close();

		return writer.toString();
	}

	private KeyDescriptor createEncodingKeyDescriptor(KeyInfoGenerator keyInfoGenerator) throws SecurityException {
		KeyDescriptor encKeyDescriptor = OpenSAMLUtils.buildSAMLObject(KeyDescriptor.class);
		encKeyDescriptor.setUse(UsageType.ENCRYPTION);
		encKeyDescriptor.setKeyInfo(keyInfoGenerator.generate(credential));
		return encKeyDescriptor;
	}

	private KeyDescriptor createSignKeyDescriptor(KeyInfoGenerator keyInfoGenerator) throws SecurityException {
		KeyDescriptor signKeyDescriptor = OpenSAMLUtils.buildSAMLObject(KeyDescriptor.class);
		signKeyDescriptor.setUse(UsageType.SIGNING);
		signKeyDescriptor.setKeyInfo(keyInfoGenerator.generate(credential));
		return signKeyDescriptor;
	}

	private AssertionConsumerService createAssertionConsumerService(String contextBaseURL) {
		AssertionConsumerService assertionConsumerService = OpenSAMLUtils
				.buildSAMLObject(AssertionConsumerService.class);
		assertionConsumerService.setIndex(0);
		assertionConsumerService.setBinding(SAMLConstants.SAML2_POST_BINDING_URI);
		assertionConsumerService.setIsDefault(true);
		assertionConsumerService.setLocation(getAssertionConsumerLocation(contextBaseURL));
		return assertionConsumerService;
	}

	private SingleLogoutService createSingleSignout(String contextBaseURL) {
		SingleLogoutService logoutService = OpenSAMLUtils.buildSAMLObject(SingleLogoutService.class);
		logoutService.setLocation(contextBaseURL + "/slo");
		logoutService.setBinding(SAMLConstants.SAML2_POST_BINDING_URI);
		return logoutService;
	}

	private AttributeConsumingService createMinimumAttributeSet() {
		AttributeConsumingService minimumAttributeSet = OpenSAMLUtils.buildSAMLObject(AttributeConsumingService.class);
		minimumAttributeSet.setIndex(99);
		{
			ServiceName serviceName = OpenSAMLUtils.buildSAMLObject(ServiceName.class);
			serviceName.setXMLLang(LANG);
			serviceName.setValue("eIDAS Natural Person Minimum Attribute Set");
			minimumAttributeSet.getNames().add(serviceName);
		}
		return minimumAttributeSet;
	}

	private AttributeConsumingService createFullAttributeSet() {
		AttributeConsumingService fullAttributeSet = OpenSAMLUtils.buildSAMLObject(AttributeConsumingService.class);
		fullAttributeSet.setIndex(100);
		{
			ServiceName serviceName = OpenSAMLUtils.buildSAMLObject(ServiceName.class);
			serviceName.setXMLLang(LANG);
			serviceName.setValue("eIDAS Natural Person Full Attribute Set");
			fullAttributeSet.getNames().add(serviceName);
		}
		return fullAttributeSet;
	}

	private Organization createOrganization(EntityDescriptor spEntityDescriptor, SPSSODescriptor spSSODescriptor) {
		Organization org = OpenSAMLUtils.buildSAMLObject(Organization.class);
		{
			OrganizationName name = OpenSAMLUtils.buildSAMLObject(OrganizationName.class);
			name.setValue(config.getDisplayName());
			name.setXMLLang(LANG);
			org.getOrganizationNames().add(name);
		}
		{
			OrganizationDisplayName name = OpenSAMLUtils.buildSAMLObject(OrganizationDisplayName.class);
			name.setValue(config.getDisplayName());
			name.setXMLLang(LANG);
			org.getDisplayNames().add(name);
		}
		// {
		// OrganizationURL name = OpenSAMLUtils.buildSAMLObject(OrganizationURL.class);
		// name.setURI(config.getOrgURL());
		// name.setXMLLang(LANG);
		// org.getURLs().add(name);
		// }

		spEntityDescriptor.getRoleDescriptors().add(spSSODescriptor);
		return org;
	}

	private void addRequestedAttributes(List<String> attributes, AttributeConsumingService attrConsService) {
		RequestedAttribute ra;
		for (String a : attributes) {
			ra = OpenSAMLUtils.buildSAMLObject(RequestedAttribute.class);
			ra.setName(a);
			attrConsService.getRequestedAttributes().add(ra);
		}
	}

	private String getAssertionConsumerLocation(String baseURL) {
		return baseURL + "/ac";
	}

	public String createMetadata(String contextBaseURL) {
		try {
			return createMetadataInternal(contextBaseURL);
		} catch (Exception e) {
			throw new RuntimeException(e.getMessage(), e);
		}
	}

	private String createMetadataInternal(String contextBaseURL) throws Exception {
		EntityDescriptor spEntityDescriptor = OpenSAMLUtils.buildSAMLObject(EntityDescriptor.class);
		spEntityDescriptor.setEntityID(config.getEntityId());

		SPSSODescriptor spSSODescriptor = OpenSAMLUtils.buildSAMLObject(SPSSODescriptor.class);
		spSSODescriptor.setWantAssertionsSigned(true);
		spSSODescriptor.setAuthnRequestsSigned(true);
		spSSODescriptor.addSupportedProtocol(SAMLConstants.SAML20P_NS);

		// Keys
		KeyInfoGenerator keyInfoGenerator = keyInfoGeneratorFactory.newInstance();

		KeyDescriptor encKeyDescriptor = createEncodingKeyDescriptor(keyInfoGenerator);
		spSSODescriptor.getKeyDescriptors().add(encKeyDescriptor);

		KeyDescriptor signKeyDescriptor = createSignKeyDescriptor(keyInfoGenerator);
		spSSODescriptor.getKeyDescriptors().add(signKeyDescriptor);

		// Request transient pseudonym
		NameIDFormat nameIDFormat = OpenSAMLUtils.buildSAMLObject(NameIDFormat.class);
		nameIDFormat.setURI(NameID.TRANSIENT);
		spSSODescriptor.getNameIDFormats().add(nameIDFormat);

		// ASSERTION CONSUMER
		AssertionConsumerService assertionConsumerService = createAssertionConsumerService(contextBaseURL);
		spSSODescriptor.getAssertionConsumerServices().add(assertionConsumerService);

		// SINGLE SIGNOUT
		SingleLogoutService logoutService = createSingleSignout(contextBaseURL);
		spSSODescriptor.getSingleLogoutServices().add(logoutService); // ResponseLocation is optional for SPID

		// AttributeConsumingService
		AttributeConsumingService attrConsService = OpenSAMLUtils.buildSAMLObject(AttributeConsumingService.class);
		attrConsService.setIndex(0);

		{
			ServiceName serviceName = OpenSAMLUtils.buildSAMLObject(ServiceName.class);
			serviceName.setXMLLang(LANG);
			serviceName.setValue(config.getDisplayName());
			attrConsService.getNames().add(serviceName);
		}

		this.addRequestedAttributes(config.getAttributes(), attrConsService);

		spSSODescriptor.getAttributeConsumingServices().add(attrConsService);

		// eIDAS attributes
		List<String> attrs = config.getEidasMinimumAttributes();
		if (attrs.size() > 0) {
			AttributeConsumingService minimumAttributeSet = createMinimumAttributeSet();
			this.addRequestedAttributes(attrs, minimumAttributeSet);
			spSSODescriptor.getAttributeConsumingServices().add(minimumAttributeSet);
		}

		attrs = new ArrayList<>();
		attrs.addAll(config.getEidasMinimumAttributes());
		attrs.addAll(config.getEidasFullAttributes());
		if (attrs.size() > 0) {
			AttributeConsumingService fullAttributeSet = createFullAttributeSet();
			this.addRequestedAttributes(attrs, fullAttributeSet);
			spSSODescriptor.getAttributeConsumingServices().add(fullAttributeSet);
		}

		// Organization metadata
		Organization org = createOrganization(spEntityDescriptor, spSSODescriptor);
		spEntityDescriptor.setOrganization(org);

		// if (config.getPaContactPerson() != null) {
		// addContactPerson(spEntityDescriptor, config.getPaContactPerson());
		// } else {
		// addContactPerson(spEntityDescriptor, config.getPrivateContactPerson());
		// }

		return signAndMarshal(spEntityDescriptor, SignatureConstants.ALGO_ID_C14N11_OMIT_COMMENTS);
	}

}
