package com.abacogroup.external.auth.gari.core.handler;

import lombok.AllArgsConstructor;
import lombok.Value;

@Value
@AllArgsConstructor
public class GiasTokenRequest {
    private final String CUAA;
    private final String username;
}
