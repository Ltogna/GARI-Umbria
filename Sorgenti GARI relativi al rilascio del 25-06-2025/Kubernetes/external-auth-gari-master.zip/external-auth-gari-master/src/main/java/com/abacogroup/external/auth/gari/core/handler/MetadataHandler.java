package com.abacogroup.external.auth.gari.core.handler;

import java.io.IOException;

import org.eclipse.jetty.server.Request;
import org.eclipse.jetty.server.handler.AbstractHandler;

import com.abacogroup.external.auth.gari.core.saml.ServiceProvider;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class MetadataHandler extends AbstractHandler {

    private final ServiceProvider serviceProvider;

    public MetadataHandler(ServiceProvider serviceProvider) {
        this.serviceProvider = serviceProvider;
    }

    @Override
    public void handle(String target, Request baseRequest, HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
        log.debug("Serving metadata");
        String uri = getContextPath(baseRequest);
        String metadata = serviceProvider.createMetadata(uri.toString());
        response.setContentType("text/xml");

        var writer = response.getWriter();
        writer.write(metadata);
        writer.flush();

        baseRequest.setHandled(true);
    }

    private String getContextPath(Request jettyRequest) {
        String forwarded = jettyRequest.getHeader("X-Forwarded-Proto");
        if ("localhost".equals(jettyRequest.getServerName())) {
            forwarded = "http";
        }
        if (forwarded == null) {
            forwarded = "https";
        }

        StringBuilder contextPath = jettyRequest.getRootURL();
        int index = contextPath.indexOf(":");
        if (!forwarded.isEmpty()) {
            contextPath.replace(0, index, forwarded);
        }
        return contextPath.toString();
    }

}
