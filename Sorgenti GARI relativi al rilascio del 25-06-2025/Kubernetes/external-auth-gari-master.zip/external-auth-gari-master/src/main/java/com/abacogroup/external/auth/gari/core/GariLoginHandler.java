package com.abacogroup.external.auth.gari.core;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.Base64;

import org.eclipse.jetty.server.Request;

import com.abacogroup.external.auth.gari.ExternalAuthGariConfiguration;
import com.abacogroup.external.auth.gari.core.handler.impl.SamlAccessControlHandler;
import com.abacogroup.external_auth_sdk.http.handler.LoginHandler;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class GariLoginHandler implements LoginHandler {
	private final SamlAccessControlHandler samlResponseHanlder;
	private String page401;

	public GariLoginHandler(SamlAccessControlHandler handler, ExternalAuthGariConfiguration configuration) {
		this.samlResponseHanlder = handler;
		this.page401 = configuration.getPage401();
	}

	@Override
	public void handleLogin(Request request, HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse) throws IOException {
		String uri = request.getRequestURI();
		if (uri.equals(page401)) {
			return;
		}

		if (uri.equals("/idp") || uri.startsWith("/idp?")) {
			log.debug("Redirecting to identity provider endpoint");
			try {
				samlResponseHanlder.redirectToIdentityProvider(request, httpServletResponse);
				httpServletResponse.getWriter().flush();
			} catch (Exception e) {
				log.error("Error redirecting to the identity provider", e);
			}
		} else {
			log.debug("Redirecting {} to login page", uri);
			StringBuilder redirectTo = new StringBuilder(this.getContextPath(request)).append("/sso2-login/");
			redirectTo.append("?state=").append(buildState(request));
			httpServletResponse.sendRedirect(redirectTo.toString());
		}
	}

	private String getContextPath(Request jettyRequest) {
		StringBuilder contextPath = jettyRequest.getRootURL();
		int index = contextPath.indexOf(":");
		contextPath.replace(0, index, "https");
		return contextPath.toString();
	}

	private String buildState(Request jettyRequest) {
		StringBuffer redirectTo = new StringBuffer(getContextPath(jettyRequest).concat(jettyRequest.getRequestURI())); // If you also want the host
		String query = jettyRequest.getQueryString();
		if (query != null && !query.isEmpty()) {
			redirectTo.append('?').append(query);
		}

		var bytes = redirectTo.toString().getBytes(StandardCharsets.UTF_8);
		return Base64.getUrlEncoder().withoutPadding().encodeToString(bytes);
	}

}
