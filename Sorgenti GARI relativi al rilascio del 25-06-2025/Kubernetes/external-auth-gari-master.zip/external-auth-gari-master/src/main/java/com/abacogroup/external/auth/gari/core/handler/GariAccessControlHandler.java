package com.abacogroup.external.auth.gari.core.handler;

import java.util.ArrayList;
import java.util.List;

import org.eclipse.jetty.server.Request;

import com.abacogroup.external.auth.gari.core.handler.impl.LoginCookieAuthHandler;
import com.abacogroup.external.auth.gari.core.handler.impl.SamlAccessControlHandler;
import com.abacogroup.external.auth.gari.core.handler.impl.Sso2AuthHandler;
import com.abacogroup.external_auth_sdk.http.AuthService;
import com.abacogroup.external_auth_sdk.http.handler.ExternalAuthHandler;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class GariAccessControlHandler implements ExternalAuthHandler {

	private static final String TARGET = "X-TARGET";

	private List<ExternalAuthHandler> handlers = new ArrayList<>();

	public GariAccessControlHandler(AuthService authService, Sso2AuthHandler sso2, SamlAccessControlHandler saml, GariAuthHandler gari) {
		this.handlers.add(sso2);
		this.handlers.add(saml);
		this.handlers.add(gari);

		// This must be the last one (and it is ony a safeguard for future proofing the systen; gari should handle everything)
		this.handlers.add(new LoginCookieAuthHandler(authService));
	}

	@Override
	public boolean shouldIHandleIt(String target, Request jettyRequest) {
		jettyRequest.setAttribute(TARGET, target);
		return true;
	}

	@Override
	public boolean handle(Request jettyRequest, HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse) throws Exception {
		String target = (String) jettyRequest.getAttribute(TARGET);

		boolean res = false;
		for (var h : handlers) {
			if (h.shouldIHandleIt(target, jettyRequest)) {
				res = h.handle(jettyRequest, httpServletRequest, httpServletResponse);
				if (res) {
					break;
				}
			}
		}

		return res;
	}
}
