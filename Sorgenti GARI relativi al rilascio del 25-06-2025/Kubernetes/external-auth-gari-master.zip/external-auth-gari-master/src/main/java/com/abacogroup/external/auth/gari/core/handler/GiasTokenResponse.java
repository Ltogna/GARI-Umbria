package com.abacogroup.external.auth.gari.core.handler;

import lombok.Data;

@Data
public class GiasTokenResponse {
    private String message;
    private Integer statusCode;
    private String token;
    private String baseURL;
}
