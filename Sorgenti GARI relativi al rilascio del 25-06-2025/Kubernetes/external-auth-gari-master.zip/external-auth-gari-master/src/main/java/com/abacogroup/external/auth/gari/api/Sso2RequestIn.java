package com.abacogroup.external.auth.gari.api;

import jakarta.validation.constraints.NotEmpty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class Sso2RequestIn {
	@NotEmpty
	String authToken;
	@NotEmpty
	String state;
}
