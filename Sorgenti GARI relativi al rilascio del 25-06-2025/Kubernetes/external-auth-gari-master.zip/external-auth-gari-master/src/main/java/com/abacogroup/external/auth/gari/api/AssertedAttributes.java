package com.abacogroup.external.auth.gari.api;

public interface AssertedAttributes {
	boolean isSuccess();

	<T> T get(String name);

}
