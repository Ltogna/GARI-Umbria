package com.abacogroup.external.auth.gari.core.service;

import java.io.ByteArrayInputStream;
import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;

import javax.xml.parsers.DocumentBuilder;

import org.apache.commons.codec.binary.Base64;
import org.opensaml.core.xml.XMLObject;
import org.opensaml.core.xml.config.XMLObjectProviderRegistrySupport;
import org.opensaml.core.xml.io.Unmarshaller;
import org.opensaml.core.xml.schema.XSString;
import org.opensaml.saml.common.SAMLVersion;
import org.opensaml.saml.common.xml.SAMLConstants;
import org.opensaml.saml.saml2.core.*;
import org.opensaml.xmlsec.signature.Signature;
import org.opensaml.xmlsec.signature.support.SignatureException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.abacogroup.external.auth.gari.ExternalAuthGariConfiguration;
import com.abacogroup.external.auth.gari.core.saml.OpenSAMLUtils;
import com.abacogroup.external.auth.gari.core.saml.RemoteIdentityProvider;
import com.abacogroup.external.auth.gari.core.saml.SAMLValidationException;
import com.abacogroup.external.auth.gari.core.saml.ServiceProvider;
import com.abacogroup.external.auth.gari.core.utils.AttributeContainer;

import jakarta.servlet.http.HttpServletResponse;
import lombok.extern.slf4j.Slf4j;
import net.shibboleth.utilities.java.support.xml.BasicParserPool;

@Slf4j
public class Saml2Service {
	private static final long ACCEPT_LEEWAY = 300000;

	// private static final String PASSWORD_PROTECT_TRANSPORT = "urn:oasis:names:tc:SAML:2.0:ac:classes:PasswordProtectedTransport";
	// private static final String SPID_L1 = "https://www.spid.gov.it/SpidL1";

	private static final String SMART_CARD_CNS = "urn:oasis:names:tc:SAML:2.0:ac:classes:SmartcardCNS";
	private static final String SMART_CARD = "urn:oasis:names:tc:SAML:2.0:ac:classes:Smartcard";

	private static final String SECURE_REMOTE_PWD = "urn:oasis:names:tc:SAML:2.0:ac:classes:SecureRemotePassword";
	private static final String SPID_L2 = "https://www.spid.gov.it/SpidL2";
	private static final String SPID_L3 = "https://www.spid.gov.it/SpidL3";

	private static final List<String> ALLOWED_AUTHN_CONTEXTS = List.of(SMART_CARD_CNS, SMART_CARD, SECURE_REMOTE_PWD, SPID_L2, SPID_L3);

	public List<String> fiscalNumberFields;
	public List<String> nameFields;
	public List<String> surnameFields;
	public List<String> emailFields;

	private ServiceProvider serviceProvider;
	private RemoteIdentityProvider remoteIdentityProvider;

	private BasicParserPool parserPool;

	public Saml2Service(BasicParserPool parserPool, ServiceProvider serviceProvider, RemoteIdentityProvider remoteIdentityProvider,
			ExternalAuthGariConfiguration configuration) {
		this.serviceProvider = serviceProvider;
		this.remoteIdentityProvider = remoteIdentityProvider;
		this.fiscalNumberFields = configuration.getFiscalNumberFields();
		this.emailFields = configuration.getEmailFields();
		this.nameFields = configuration.getNameFields();
		this.surnameFields = configuration.getSurnameFields();
		this.parserPool = parserPool;
	}

	public void postToLogin(String returnURL, HttpServletResponse response, String contextPath) throws Exception {
		AuthnRequest authnRequest = buildAuthnRequest(contextPath);
		String signedRequest = serviceProvider.signAndMarshal(authnRequest, remoteIdentityProvider.getCanonicalizationAlgorithm());
		String b64 = Base64.encodeBase64String(signedRequest.getBytes());

		response.setContentType("text/html");
		response.setStatus(HttpServletResponse.SC_FOUND);

		var location = getSingleSignonLocation();

		response.getWriter().println("<body>\n" +
				"  <form id=\"initLogin\" method='post' action=\" " + location + "\">\n" +
				"    <input type=\"hidden\" name=\"SAMLRequest\" value=\"" + b64 + "\">\n" +
				"    <input type=\"hidden\" name=\"RelayState\" value=\"" + returnURL + "\">\n" +
				"  </form>\n" +
				"  <script src='" + contextPath + "/external-auth/submitForm.js' type='text/javascript'>\n" +
				"  </script>\n" +
				"</body>");
	}

	private String getSingleSignonLocation() {
		var location = remoteIdentityProvider.getSingleSignOnService().getLocation();
		// if (!location.endsWith("/")) {
		// location += '/';
		// }
		// location += serviceProvider.getEntityId();
		return location;
	}

	public AttributeContainer getAttribute(String base64SamlResponse, String contextPath) throws Exception {
		byte[] tmp = Base64.decodeBase64(base64SamlResponse);
		String samlResponse = new String(tmp, StandardCharsets.UTF_8);

		AttributeContainer rsAttribute = this.getAssertedAttributes(samlResponse, contextPath);

		// forse non necessario
		if (rsAttribute.getFiscalCode().equals(null)) {
			throw new IllegalStateException("SAML asserted attributes error: isSuccess = false");
		}
		return rsAttribute;
	}

	private AttributeContainer getAssertedAttributes(String samlResponse, String contextPath) throws Exception {
		AttributeContainer attributeContainer = new AttributeContainer();
		DocumentBuilder docBuilder = parserPool.getBuilder();
		try {
			Document doc = docBuilder.parse(new ByteArrayInputStream(samlResponse.getBytes()));
			Element el = doc.getDocumentElement();
			Unmarshaller unmarshaller = XMLObjectProviderRegistrySupport.getUnmarshallerFactory().getUnmarshaller(el);
			XMLObject obj = unmarshaller.unmarshall(el);
			if (!(obj instanceof Response)) {
				throw new SAMLValidationException("Bad SAMLResponse");
			}

			var response = (Response) obj;

			if (response.isSigned()) {
				// Message signature is not mandatoy for SPID
				Signature signature = response.getSignature();
				if (signature != null) {
					remoteIdentityProvider.validateSignature(signature);
				}
			}

			validateResponseAttributes(response, contextPath);
			validateStatus(response);
			if (!isResponseStatusSuccess(response)) {
				attributeContainer.setInResponseTo(response.getInResponseTo());
				return attributeContainer;
			}

			remoteIdentityProvider.validateIssuer(response.getIssuer(), remoteIdentityProvider.getIssuerFormatResponseCheck());

			List<Assertion> assertions = requireNonEmpty(response.getAssertions(), () -> "Expected at list one Assertion");
			Assertion validatedAssertionWithAttribute = null;
			List<String> errors = new ArrayList<>();
			int validatedAssertions = 0;
			while (validatedAssertionWithAttribute == null && validatedAssertions < assertions.size()) {
				try {
					validatedAssertionWithAttribute = validateAuthnResponseAssertion(assertions.get(validatedAssertions), contextPath);
				} catch (Exception e) {
					errors.add(e.getMessage());
				}
				validatedAssertions++;
			}

			if (validatedAssertionWithAttribute == null) {
				throw new SAMLValidationException(errors.toString());
			}
			attributeContainer = getRequiredAttribute(validatedAssertionWithAttribute);
			attributeContainer.setInResponseTo(response.getInResponseTo());
			log.debug("{}", attributeContainer);
			return attributeContainer;
		} finally {
			parserPool.returnBuilder(docBuilder);
		}
	}/**/

	private AuthnRequest buildAuthnRequest(String contextPath) {
		String id = this.remoteIdentityProvider.createAuthnID();

		AuthnRequest request = OpenSAMLUtils.buildSAMLObject(AuthnRequest.class);

		request.setID(id);
		request.setIssueInstant(Instant.now());

		request.setDestination(getSingleSignonLocation());
		request.setProtocolBinding(SAMLConstants.SAML2_POST_BINDING_URI);
		request.setVersion(SAMLVersion.VERSION_20);
		request.setAssertionConsumerServiceURL(getAssertionConsumerLocation(contextPath));

		request.setIsPassive(false);
		request.setForceAuthn(false);

		request.setIssuer(buildIssuer());
		request.setNameIDPolicy(buildNameIdPolicy());
		request.setRequestedAuthnContext(buildRequestedAuthnContext());

		return request;
	}

	private Issuer buildIssuer() {
		Issuer issuer = OpenSAMLUtils.buildSAMLObject(Issuer.class);
		issuer.setValue(this.serviceProvider.getEntityId());
		issuer.setFormat(NameID.ENTITY);
		issuer.setNameQualifier(this.serviceProvider.getEntityId());

		return issuer;
	}

	private NameIDPolicy buildNameIdPolicy() {
		NameIDPolicy policy = OpenSAMLUtils.buildSAMLObject(NameIDPolicy.class);
		policy.setFormat(NameID.TRANSIENT);
		policy.setSPNameQualifier("Issuer");
		policy.setAllowCreate(true);
		return policy;
	}

	private RequestedAuthnContext buildRequestedAuthnContext() {
		RequestedAuthnContext ctx = OpenSAMLUtils.buildSAMLObject(RequestedAuthnContext.class);
		// ctx.setComparison(AuthnContextComparisonTypeEnumeration.EXACT);
		ctx.setComparison(AuthnContextComparisonTypeEnumeration.EXACT);

		AuthnContextClassRef classRef;
		for (var method : ALLOWED_AUTHN_CONTEXTS) {
			classRef = OpenSAMLUtils.buildSAMLObject(AuthnContextClassRef.class);
			classRef.setURI(method);
			ctx.getAuthnContextClassRefs().add(classRef);
		}

		return ctx;
	}

	private void validateResponseAttributes(Response response, String baseURL) {
		if (!SAMLVersion.VERSION_20.equals(response.getVersion())) {
			throw new SAMLValidationException("Bad SAML version");
		}

		requireIssueInstant(response.getIssueInstant(), "Response");
		requireNonEmpty(response.getID(), () -> "ID is missing in response");

		String inResponseTo = requireNonEmpty(response.getInResponseTo(), () -> "InResponseTo is missing in response");
		remoteIdentityProvider.validateAuthnID(inResponseTo);

		String destination = response.getDestination();
		if (!getAssertionConsumerLocation(baseURL).equals(destination)) {
			throw new SAMLValidationException("This response is not for me; bad Destination attribute");
		}
	}

	private void validateStatus(Response response) {
		Status status = requireNonNull(response.getStatus(), () -> "Status not specified");
		StatusCode statusCodeObj = requireNonNull(status.getStatusCode(), () -> "Status code not specified");

		String statusCode = statusCodeObj.getValue();

		if (StatusCode.RESPONDER.equals(statusCode)) {
			StatusMessage statusMessage = requireNonNull(status.getStatusMessage(), () -> "Status message not specified");
			String errorCodeMessage = requireNonEmpty(statusMessage.getValue(), () -> "Error code message not specified");

			log.error(errorCodeMessage);
		}
		if (!StatusCode.SUCCESS.equals(statusCode) && !StatusCode.AUTHN_FAILED.equals(statusCode)) {
			throw new SAMLValidationException("Bad response status,"
					+ " expected: " + StatusCode.SUCCESS + " or " + StatusCode.AUTHN_FAILED
					+ " got: " + statusCode);
		}
	}

	private Assertion validateAuthnResponseAssertion(Assertion assertion, String baseURL) {

		if (!SAMLVersion.VERSION_20.equals(assertion.getVersion())) {
			throw new SAMLValidationException("Bad SAML version");
		}
		String assertionID = requireNonEmpty(assertion.getID(), () -> "Asserion ID is missing");
		if (!assertion.isSigned()) {
			throw new SAMLValidationException("Assertion " + assertionID + " is not signed");
		}

		remoteIdentityProvider.validateIssuer(assertion.getIssuer(), remoteIdentityProvider.getIssuerFormatResponseCheck());

		try {
			remoteIdentityProvider.validateSignature(assertion.getSignature());
		} catch (SignatureException e) {
			throw new SAMLValidationException("Bad Assertion signature", e);
		}

		requireIssueInstant(assertion.getIssueInstant(), "assertion");
		Subject subject = requireNonNull(assertion.getSubject(), () -> "Missing Subject in assertion " + assertionID);

		requireNonNull(subject.getNameID(), () -> "Missing NameID");

		// NameID nameID = requireNonNull(subject.getNameID(), () -> "Missing NameID");
		// if (!NameID.TRANSIENT.equals(nameID.getFormat()))
		// {
		// throw new SAMLValidationException(("Identity type must be " + NameID.TRANSIENT));
		// }

		SubjectConfirmation confirmation = subject.getSubjectConfirmations().stream()
				.filter(c -> SubjectConfirmation.METHOD_BEARER.equals(c.getMethod()))
				.findFirst()
				.orElseThrow(() -> new SAMLValidationException(
						"No SubjectConfirmations with method " + SubjectConfirmation.METHOD_BEARER));

		SubjectConfirmationData data = requireNonNull(confirmation.getSubjectConfirmationData(),
				() -> "Missing SubjectConfirmationData");
		if (!getAssertionConsumerLocation(baseURL).equals(data.getRecipient())) {
			throw new SAMLValidationException("Bad recipient in SubjectConfirmationData");
		}

		requireNotOnOrAfter(data.getNotOnOrAfter());
		requireNonEmpty(data.getInResponseTo(), () -> "Missing inResponseTo attribute");
		remoteIdentityProvider.validateAuthnID(data.getInResponseTo());
		validateAsserionsConditions(assertion.getConditions());
		validateaAuthnStatements(assertion.getAuthnStatements());

		return assertion;
	}

	private void validateaAuthnStatements(List<AuthnStatement> authnStatements) {
		requireNonEmpty(authnStatements, () -> "Must have AuthnStatement");

		AuthnContext ctx;
		AuthnContextClassRef ref;
		AuthnContextDecl decl;
		String type;
		ArrayList<String> receivedTypes = new ArrayList<>();
		for (AuthnStatement stmt : authnStatements) {
			ctx = requireNonNull(stmt.getAuthnContext(),
					() -> "AuthnStatement must have a child node of type AuthnContext");
			ref = ctx.getAuthnContextClassRef();
			if (ref != null) {
				type = requireNonNull(ref.getURI(), () -> "AuthnContextClassRef is not specified");
			} else {
				decl = requireNonNull(ctx.getAuthContextDecl(),
						() -> "AuthnContext must have a child node of type AuthnContextClassDecl or AuthnContextClassRef");
				type = requireNonNull(decl.getTextContent(), () -> "AuthnContextClassDecl is not specified");
			}

			receivedTypes.add(type);

			if (ALLOWED_AUTHN_CONTEXTS.isEmpty() || ALLOWED_AUTHN_CONTEXTS.contains(type)) {
				return;
			}
		}

		throw new SAMLValidationException("Wrong authn types returned: " + receivedTypes);
	}

	private void validateAsserionsConditions(Conditions conditions) {
		requireNonNull(conditions, () -> "Conditions is missing");
		requireNotOnOrAfter(conditions.getNotOnOrAfter());
		requireNotBefore(conditions.getNotBefore());

		List<AudienceRestriction> restrictions = requireNonEmpty(conditions.getAudienceRestrictions(),
				() -> "Must have AudienceRestriction");
		validateAudienceRestriction(restrictions);
	}

	private void validateAudienceRestriction(List<AudienceRestriction> restrictions) {
		for (AudienceRestriction ar : restrictions) {
			for (Audience audience : requireNonEmpty(ar.getAudiences(),
					() -> "AudienceRestriction must have achild node named Audience")) {
				if (serviceProvider.getEntityId().equals(audience.getURI())) {
					return;
				}
			}
		}

		throw new SAMLValidationException("Missing AudienceRestriction with correct audience");
	}

	private String getAssertionConsumerLocation(String baseURL) {
		return baseURL + "/ac";
	}

	private AttributeContainer getRequiredAttribute(Assertion assertion) {
		List<AttributeStatement> statements = requireNonEmpty(assertion.getAttributeStatements(),
				() -> "Assertion must have a child note og type AttributeStatement");

		AttributeContainer attributesContainer = new AttributeContainer();
		List<Attribute> attributes;
		for (AttributeStatement stmt : statements) {
			attributes = requireNonEmpty(stmt.getAttributes(),
					() -> "AttributeStatement must have a child note of type Attribute");

			attributes.forEach(attr -> {
				if (this.fiscalNumberFields.stream().anyMatch(field -> field.equals(attr.getName()))) {
					String value = this.getAttributeValue(attr);
					attributesContainer.setFiscalCode(value);
				}
				if (this.emailFields.stream().anyMatch(field -> field.equals(attr.getName()))) {
					String value = this.getAttributeValue(attr);
					attributesContainer.setEmail(value);
				}
				if (this.nameFields.stream().anyMatch(field -> field.equals(attr.getName()))) {
					String value = this.getAttributeValue(attr);
					attributesContainer.setName(value);
				}
				if (this.surnameFields.stream().anyMatch(field -> field.equals(attr.getName()))) {
					String value = this.getAttributeValue(attr);
					attributesContainer.setSurname(value);
				}
			});
		}
		return attributesContainer;
	}

	public String getAttributeValue(Attribute attr) {
		XMLObject xml = attr.getAttributeValues().get(0);
		XSString xsString = (XSString) xml;
		return xsString.getValue();
	}

	private boolean isResponseStatusSuccess(Response response) {
		Status status = response.getStatus();
		String statusCode = status.getStatusCode().getValue();
		return StatusCode.SUCCESS.equals(statusCode);
	}

	private <T> T requireNonNull(T obj, Supplier<String> errorMessage) {
		if (obj == null) {
			throw new SAMLValidationException(errorMessage.get());
		}
		return obj;
	}

	private String requireNonEmpty(String str, Supplier<String> errorMessage) {
		if (str == null || str.isEmpty()) {
			throw new SAMLValidationException(errorMessage.get());
		}
		return str;
	}

	private <T> List<T> requireNonEmpty(List<T> list, Supplier<String> errorMessage) {
		if (requireNonNull(list, errorMessage).size() < 1) {
			throw new SAMLValidationException(errorMessage.get());
		}
		return list;
	}

	private void requireNotOnOrAfter(Instant notOnOrAfter) {
		requireNonNull(notOnOrAfter, () -> "NotOnOrAfter attribute is missing");
		if (System.currentTimeMillis() - notOnOrAfter.toEpochMilli() > ACCEPT_LEEWAY) {
			throw new SAMLValidationException("Assertion is expired due to NotOnOrAfter");
		}
	}

	private void requireNotBefore(Instant notBefore) {
		requireNonNull(notBefore, () -> "NotBefore attribute is missing");
		if (System.currentTimeMillis() - notBefore.toEpochMilli() < -ACCEPT_LEEWAY) {
			throw new SAMLValidationException("Assertion is not usable yet due to NotBefore");
		}
	}

	private void requireIssueInstant(Instant issueInstant, String context) {
		requireNonNull(issueInstant, () -> "IssueInstant attribute is missing in " + context);
		long diff = System.currentTimeMillis() - issueInstant.toEpochMilli();

		if (diff > ACCEPT_LEEWAY) {
			throw new SAMLValidationException(context + " is expired due to IssueInstant");
		}
		if (diff < -ACCEPT_LEEWAY) {
			throw new SAMLValidationException(context + " is not usable yet due to IssueInstant");
		}
	}
}
