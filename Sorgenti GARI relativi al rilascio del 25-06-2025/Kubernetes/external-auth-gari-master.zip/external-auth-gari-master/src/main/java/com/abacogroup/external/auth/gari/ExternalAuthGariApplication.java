package com.abacogroup.external.auth.gari;

import com.abacogroup.external.auth.gari.config.GiasConfig;
import com.abacogroup.external.auth.gari.core.GariLoginHandler;
import com.abacogroup.external.auth.gari.core.handler.GariAuthHandler;
import com.abacogroup.external.auth.gari.core.handler.MetadataHandler;
import com.abacogroup.external.auth.gari.core.handler.GariAccessControlHandler;
import com.abacogroup.external.auth.gari.core.handler.impl.SamlAccessControlHandler;
import com.abacogroup.external.auth.gari.core.handler.impl.Sso2AuthHandler;
import com.abacogroup.external.auth.gari.core.saml.RemoteIdentityProvider;
import com.abacogroup.external.auth.gari.core.saml.ServiceProvider;
import com.abacogroup.external.auth.gari.core.service.Saml2Service;
import com.abacogroup.external.auth.gari.core.service.UserService;
import com.abacogroup.external_auth_sdk.http.AuthService;
import com.abacogroup.external_auth_sdk.http.ExternalAuthApplication;
import com.abacogroup.external_auth_sdk.http.ExternalAuthEnvironment;
import com.abacogroup.external_auth_sdk.http.handler.ExternalAuthHandler;
import com.abacogroup.external_auth_sdk.http.handler.LoginHandler;
import com.abacogroup.external_auth_sdk.http.handler.impl.LogoutHandler;
import com.abacogroup.filestore.client.FileStoreClient;
import com.fasterxml.jackson.databind.ObjectMapper;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.ws.rs.client.Client;
import jakarta.ws.rs.client.ClientBuilder;
import net.shibboleth.utilities.java.support.component.ComponentInitializationException;
import net.shibboleth.utilities.java.support.xml.BasicParserPool;

import org.eclipse.jetty.server.Request;
import org.eclipse.jetty.server.handler.ContextHandler;
import org.eclipse.jetty.server.handler.HandlerCollection;
import org.eclipse.jetty.server.handler.ResourceHandler;

import org.opensaml.core.config.InitializationException;
import org.opensaml.core.config.InitializationService;

import java.net.URI;
import java.util.List;
import java.util.concurrent.TimeUnit;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLSession;

public class ExternalAuthGariApplication extends ExternalAuthApplication<ExternalAuthGariConfiguration> {
	private static final List<String> tenants = List.of("master");
	private UserService userService;

	private GariAccessControlHandler accessControlHandler;
	private SamlAccessControlHandler samlHandler;
	private ServiceProvider serviceProvider;
	private ObjectMapper objectMapper;

	public ExternalAuthGariApplication(String[] args, Class<ExternalAuthGariConfiguration> configurationClass) throws Exception {
		super(args, configurationClass);
	}

	public static void main(String[] args) throws Exception {
		new ExternalAuthGariApplication(args, ExternalAuthGariConfiguration.class);
	}

	@Override
	protected void initialize(ExternalAuthGariConfiguration configuration, ExternalAuthEnvironment environment, AuthService authService) {
		BasicParserPool parserPool;
		try {
			parserPool = new BasicParserPool();
			parserPool.initialize();

			InitializationService.initialize();
		} catch (InitializationException | ComponentInitializationException e) {
			throw new RuntimeException(e.getMessage(), e);
		}

		serviceProvider = new ServiceProvider(parserPool, configuration.getServiceProviderConfig());
		RemoteIdentityProvider remoteIdentityProvider = new RemoteIdentityProvider(parserPool, configuration.getIdpMetadataFile(),
				configuration.getExternalAuthConfiguration().getTokenSecret());

		Saml2Service saml2Service = new Saml2Service(parserPool, serviceProvider, remoteIdentityProvider, configuration);
		userService = new UserService(authService.getSso2ClientWrap());
		objectMapper = new ObjectMapper();
		objectMapper.findAndRegisterModules();

		FileStoreClient fileStoreClient = new FileStoreClient(URI.create(configuration.getFileStoreUrl()), objectMapper);

		Sso2AuthHandler ssoHandler = new Sso2AuthHandler(authService);
		samlHandler = new SamlAccessControlHandler(saml2Service, userService, authService, fileStoreClient, tenants, configuration);
		accessControlHandler = new GariAccessControlHandler(authService, ssoHandler, samlHandler,
				createAuthenticationHandler(configuration, environment, authService));
	}

	@Override
	protected ExternalAuthHandler createAccessControlHandler(ExternalAuthGariConfiguration configuration, ExternalAuthEnvironment environment,
			AuthService authService) {
		return accessControlHandler;
	}

	@Override
	protected LoginHandler createLoginHandler(ExternalAuthGariConfiguration configuration, ExternalAuthEnvironment environment, AuthService authService) {
		return new GariLoginHandler(samlHandler, configuration);
	}

	@Override
	protected GariAuthHandler createAuthenticationHandler(ExternalAuthGariConfiguration configuration, ExternalAuthEnvironment environment,
			AuthService authService) {

		GiasConfig giasConfig = configuration.getGiasConfig();

		Client client;
		if (giasConfig.isUseInsecureClient()) {
			client = ClientBuilder.newBuilder()
					.hostnameVerifier(new HostnameVerifier() {
						@Override
						public boolean verify(String hostname, SSLSession session) {
							return true;
						}
					})
					.readTimeout(5, TimeUnit.SECONDS)
					.connectTimeout(5, TimeUnit.SECONDS)
					.build();
		} else {
			client = getClient(configuration);
		}

		return new GariAuthHandler(authService, giasConfig, client, objectMapper);
	}

	@Override
	protected ExternalAuthHandler createLogoutHandler(ExternalAuthGariConfiguration configuration, ExternalAuthEnvironment environment,
			AuthService authService) {
		return new LogoutHandler(authService) {
			@Override
			public boolean shouldIHandleIt(String target, Request jettyRequest) {
				return target.equals("/logout");
			}

			@Override
			protected void afterLogout(Request jettyRequest, HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse) throws Exception {
				httpServletResponse.sendRedirect("/");
			}
		};

	}

	@Override
	protected void beforeStart(ExternalAuthGariConfiguration configuration, ExternalAuthEnvironment environment, HandlerCollection handlerCollection) {
		ResourceHandler resourceHandler = new ResourceHandler();
		resourceHandler.setResourceBase("jsFiles");
		resourceHandler.setDirectoriesListed(true);
		ContextHandler contextHandler = new ContextHandler("/external-auth");
		contextHandler.setHandler(resourceHandler);
		handlerCollection.addHandler(contextHandler);

		MetadataHandler metadataHandler = new MetadataHandler(serviceProvider);
		contextHandler = new ContextHandler("/sp/metadata");
		contextHandler.setHandler(metadataHandler);
		handlerCollection.addHandler(contextHandler);
	}

}
