package com.abacogroup.external.auth.gari.core.handler.impl;

import org.eclipse.jetty.server.Request;

import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.external_auth_sdk.http.AuthService;
import com.abacogroup.external_auth_sdk.http.handler.ExternalAuthHandler;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class LoginCookieAuthHandler implements ExternalAuthHandler {

	private AuthService authService;

	public LoginCookieAuthHandler(AuthService authService) {
		this.authService = authService;
	}

	@Override
	public boolean shouldIHandleIt(String target, Request jettyRequest) {
		return true;
	}

	@Override
	public boolean handle(Request jettyRequest, HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse) throws Exception {
		User user = this.authService.getUserFromRequest(jettyRequest, httpServletResponse);

		if (user == null) {
			return false;
		}

		return true;
	}
}
