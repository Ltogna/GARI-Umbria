package com.abacogroup.external.auth.gari.core.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.abacogroup.external.auth.gari.api.CreateUserRequest;
import com.abacogroup.external.auth.gari.api.UserData;
import com.abacogroup.external.auth.gari.core.utils.AttributeContainer;
import com.abacogroup.external_auth_sdk.http.client.Sso2ClientWrap;

import jakarta.ws.rs.WebApplicationException;
import jakarta.ws.rs.client.Entity;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class UserService {
	private final Sso2ClientWrap sso2ClientWrap;

	public UserService(Sso2ClientWrap sso2ClientWrap) {
		this.sso2ClientWrap = sso2ClientWrap;
	}

	public UserData getUserDataOrNull(String tenantId, String username) {
		try (Response response = this.sso2ClientWrap.getSystemUserWebTarget(tenantId)
				.path(tenantId + "/public/v1/users/" + username)
				.request()
				.get()) {

			return this.sso2ClientWrap.readResponse(response, UserData.class).orElse(null);
		}
	}

	public UserData createNewUser(String tenantId, AttributeContainer attributeContainer) {

		Map<String, String> userProperties = new HashMap<>();
		userProperties.put("email", attributeContainer.getEmail());
		userProperties.put("name", attributeContainer.getName());
		userProperties.put("surname", attributeContainer.getSurname());
		userProperties.put("fiscalCode", attributeContainer.getFiscalCode());

		CreateUserRequest createUserRequest = CreateUserRequest.builder()
				.description(attributeContainer.getName() + " " + attributeContainer.getSurname())
				.flInternal('N')
				.isParent((short) 0)
				.password("$no_log_password$")
				.username(attributeContainer.getFiscalCode())
				.language("it")
				.userProperties(userProperties)
				.build();
		return this.createUserApiCall(tenantId, createUserRequest);
	}

	private UserData createUserApiCall(String tenantId, CreateUserRequest createUserRequest) {
		try (Response resp = sso2ClientWrap.getSystemUserWebTarget(tenantId)
				.path(tenantId + "/public/v1/user-management")
				.request(MediaType.APPLICATION_JSON)
				.post(Entity.json(createUserRequest))) {

			return this.sso2ClientWrap.readResponse(resp, UserData.class)
					.orElseThrow(() -> new WebApplicationException(resp));
		}
	}

	public void assignUserRole(String tenantId, String username) {
		StringBuilder path = new StringBuilder(tenantId).append("/public/v1/user-management/").append(username).append("/roles");
		try (Response response = this.sso2ClientWrap.getSystemUserWebTarget(tenantId)
				.path(path.toString())
				.request()
				.post(Entity.json(List.of("ACCREDITATION")))) {
			response.getStatus();
		}
	}

}
