package com.abacogroup.external.auth.gari;

import java.util.List;

import com.abacogroup.external.auth.gari.api.ServiceProviderConfig;
import com.abacogroup.external.auth.gari.api.config.DataSourceConfig;
import com.abacogroup.external.auth.gari.config.GiasConfig;
import com.abacogroup.external_auth_sdk.http.api.config.ExternalAuthAppConfig;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = true)
public class ExternalAuthGariConfiguration extends ExternalAuthAppConfig {
	@Valid
	@NotNull
	private DataSourceConfig dbGuard;

	@Valid
	@NotNull
	private ServiceProviderConfig serviceProviderConfig = new ServiceProviderConfig();

	@NotEmpty
	private String idpMetadataFile;

	@NotEmpty
	private String defaultTenant;

	@NotEmpty
	private String fileStoreUrl;
	@NotEmpty
	private List<String> fiscalNumberFields;

	private String defaultRedirectUrl;
	private String page401;

	private List<String> emailFields;
	private List<String> nameFields;
	private List<String> surnameFields;

	private GiasConfig giasConfig;

}
