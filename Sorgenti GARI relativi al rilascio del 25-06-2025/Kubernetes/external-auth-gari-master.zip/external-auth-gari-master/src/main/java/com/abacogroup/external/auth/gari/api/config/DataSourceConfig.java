package com.abacogroup.external.auth.gari.api.config;

import jakarta.validation.constraints.NotEmpty;
import lombok.Data;

@Data
public class DataSourceConfig {
	@NotEmpty
	private String url;
	@NotEmpty
	private String user;
	@NotEmpty
	private String password;
}
