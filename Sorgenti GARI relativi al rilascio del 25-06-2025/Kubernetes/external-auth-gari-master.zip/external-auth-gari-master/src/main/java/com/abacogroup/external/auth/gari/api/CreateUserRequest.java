package com.abacogroup.external.auth.gari.api;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Map;

import jakarta.validation.constraints.NotEmpty;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class CreateUserRequest {
    private String dateFormat;
    private String description;
    private Character flInternal;
    private Character isLocked;
    private Short isParent;
    private String parentUserId;
    @NotEmpty
    private String password;
    @NotEmpty
    private String username;
    private String userId;
    private String language;
    private Map<String, String> userProperties;
}
