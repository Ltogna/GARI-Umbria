package com.abacogroup.external.auth.gari.api;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@Data
@AllArgsConstructor
@NoArgsConstructor
public class UserData {
	private String userId;
	private String tenant;
	private String userName;
	private String description;
}
