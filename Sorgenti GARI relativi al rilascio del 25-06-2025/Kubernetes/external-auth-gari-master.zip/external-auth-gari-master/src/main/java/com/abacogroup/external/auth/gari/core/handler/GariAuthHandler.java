package com.abacogroup.external.auth.gari.core.handler;

import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.eclipse.jetty.server.Request;

import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.external.auth.gari.config.GiasConfig;
import com.abacogroup.external_auth_sdk.http.AuthService;
import com.abacogroup.external_auth_sdk.http.handler.ExternalAuthHandler;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.ws.rs.client.Client;
import jakarta.ws.rs.client.Entity;
import jakarta.ws.rs.core.MediaType;

public class GariAuthHandler implements ExternalAuthHandler {
    private static final String GIAS_TOKEN_URL = "/get-gias-token";
    private static final String CUAA_PARAM_NAME = "cuaa";

    // JSON file name in the classpath
    private static final String JSON_RESOURCE_PATH = "user-mapping.json";

    private final AuthService authService;
    private Client client;
    private ObjectMapper objectMapper;
    private GiasConfig giasConfig;
    private List<String> additionalAudience;

    private Map<String, String> userNameMapping;

    public GariAuthHandler(AuthService authService, GiasConfig giasConfig, Client client, ObjectMapper objectMapper) {
        this.authService = authService;
        this.giasConfig = giasConfig;
        this.client = client;
        this.objectMapper = objectMapper;
        this.additionalAudience = new ArrayList<>(0);
    }

    @Override
    public boolean shouldIHandleIt(String target, Request jettyRequest) {
        return true;
    }

    @Override
    public boolean handle(Request jettyRequest, HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse) throws Exception {
        User user = this.authService.getUserFromRequest(jettyRequest, httpServletResponse, this.additionalAudience);
        if (user == null) {
            return false;
        }

        if (GIAS_TOKEN_URL.equals(jettyRequest.getRequestURI())) {
            handleGetGiasToken(httpServletRequest, httpServletResponse, user);
        } else {
            httpServletResponse.setStatus(200);
        }

        return true;
    }

    private void handleGetGiasToken(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, User user) throws IOException {
        String cuaa = httpServletRequest.getParameter(CUAA_PARAM_NAME);
        if (cuaa != null && cuaa.isBlank()) {
            cuaa = null;
        }

        String userName = getUsersMapping(user.getName());
        var tokenReq = new GiasTokenRequest(cuaa, userName);
        GiasTokenResponse tokenResp = client.target(giasConfig.getGetTokenUrl())
                .request(MediaType.APPLICATION_JSON)
                .header("Authorization", "Bearer " + giasConfig.getBearerToken())
                .post(Entity.json(tokenReq), GiasTokenResponse.class);

        PrintWriter w = httpServletResponse.getWriter();
        if (tokenResp.getStatusCode() != 200) {
            httpServletResponse.setStatus(tokenResp.getStatusCode());
            w.write(tokenResp.getMessage());
            w.flush();
        } else {
            // https://reumbriacollaudo23_27.netagronica.it/AgronicaWebApiProfilatore/ProfilatoreUtenze.svc/AutenticazioneDemetra
            String url = giasConfig.getGetTokenUrl();
            int pos = url.indexOf("//");
            url = url.substring(0, url.indexOf("/", pos + 2));
            tokenResp.setBaseURL(url);
            httpServletResponse.setContentType(MediaType.APPLICATION_JSON);
            w.write(objectMapper.writeValueAsString(tokenResp));
        }

    }

    private String getUsersMapping(String userName) {
        if (userNameMapping == null) {
            try (InputStream inputStream = getClass().getClassLoader().getResourceAsStream(JSON_RESOURCE_PATH)) {
                if (inputStream == null) {
                    throw new IOException("Cannot find resource: " + JSON_RESOURCE_PATH);
                }

                List<Map<String, String>> mappings = new ObjectMapper().readValue(inputStream, new TypeReference<List<Map<String, String>>>() {
                });

                Map<String, String> tmp = mappings.stream()
                        .collect(Collectors.toMap(
                                map -> map.get("agri"),
                                map -> map.get("gias"),
                                (existing, replacement) -> existing)); // Handle duplicates by keeping the first one

                this.userNameMapping = Collections.unmodifiableMap(tmp);
            } catch (IOException e) {
                throw new RuntimeException("Error reading JSON file: " + e.getMessage(), e);
            }
        }

        return userNameMapping.getOrDefault(userName, userName);
    }

}
