package com.abacogroup.external.auth.gari.core.handler.impl;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.atomic.AtomicReference;

import org.eclipse.jetty.server.Request;
import org.opensaml.messaging.encoder.MessageEncodingException;

import com.abacogroup.external.auth.gari.ExternalAuthGariConfiguration;
import com.abacogroup.external.auth.gari.api.UserData;
import com.abacogroup.external.auth.gari.core.service.Saml2Service;
import com.abacogroup.external.auth.gari.core.service.UserService;
import com.abacogroup.external.auth.gari.core.utils.AttributeContainer;
import com.abacogroup.external_auth_sdk.http.AuthService;
import com.abacogroup.external_auth_sdk.http.handler.ExternalAuthHandler;
import com.abacogroup.filestore.client.FileStoreClient;
import com.abacogroup.filestore.client.auth.Authenticator;
import com.abacogroup.filestore.client.request.FileToAddMetadata;
import com.abacogroup.filestore.client.response.AddFileResponse;

import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.ws.rs.NotFoundException;
import jakarta.ws.rs.core.UriBuilder;
import lombok.extern.slf4j.Slf4j;
import net.shibboleth.utilities.java.support.component.ComponentInitializationException;

@Slf4j
public class SamlAccessControlHandler implements ExternalAuthHandler {

    private static final String TENANT_QUERY_PARAM_NAME = "tenant";
    private static final FileToAddMetadata REDIRECT_URL_FILE_METADATA = new FileToAddMetadata("redirect.url", "text/plain", 10);
    private static final String BUCKET = "externalauth";

    private Saml2Service saml2Service;

    private UserService userService;
    private AuthService authService;
    private FileStoreClient fileStoreClient;
    private String defaultTenant;
    private List<String> tenants;

    private String defaultRedirectUrl;

    private final Authenticator fileStoreAuth;
    private final String page401;

    public SamlAccessControlHandler(Saml2Service saml2Service, UserService userService, AuthService authService, FileStoreClient fileStoreClient,
            List<String> tenants, ExternalAuthGariConfiguration configuration) {
        this.saml2Service = saml2Service;
        this.userService = userService;
        this.authService = authService;
        this.fileStoreClient = fileStoreClient;
        this.defaultTenant = configuration.getDefaultTenant();
        this.tenants = tenants;
        this.defaultRedirectUrl = configuration.getDefaultRedirectUrl();
        this.page401 = configuration.getPage401();
        this.fileStoreAuth = request -> {
            var client = authService.getSso2ClientWrap();
            var userId = client.getSystemUserId(defaultTenant);
            var authToken = client.getAuthToken(defaultTenant, userId);
            request.addHeader("Authorization", "JWT " + authToken);
        };
    }

    @Override
    public boolean handle(Request request, HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse) throws Exception {
        log.debug("Consuming SAML response");
        String redirectUrl = this.getRedirectUrl(request, httpServletResponse);
        if (redirectUrl.endsWith("/idp")) {
            redirectUrl = "/";
        }
        log.debug("Redirecting to " + redirectUrl);
        httpServletResponse.sendRedirect(redirectUrl);
        return true;
    }

    @Override
    public boolean shouldIHandleIt(String target, Request jettyRequest) {
        return "/ac".equals(target);
    }

    public void redirectToIdentityProvider(Request jettyRequest, HttpServletResponse response) throws Exception {
        String returnUrl = buildState(jettyRequest);
        this.addCookieRelayState(returnUrl, response);

        try {
            var url = getContextPath(jettyRequest);
            saml2Service.postToLogin(returnUrl, response, url);
        } catch (ComponentInitializationException | MessageEncodingException e) {
            log.error(e.getMessage());
            response.sendError(500, e.getMessage());
        }
    }

    public void addCookieRelayState(String relayState, HttpServletResponse response) {
        Cookie cookie = new Cookie("RELAY_STATE_COOKIE", relayState);
        cookie.setMaxAge(-1);
        cookie.setPath("/");
        cookie.setSecure(true);
        cookie.setHttpOnly(true);
        response.addCookie(cookie);
    }

    public String getRedirectUrl(Request jettyRequest, HttpServletResponse response) throws Exception {
        Map<String, String[]> parameterMap = jettyRequest.getParameterMap();
        String SAMLResponse = this.getRequestParameter(parameterMap, "SAMLResponse");
        log.debug("Received the following SAMLResponse: " + SAMLResponse);

        String redirectUrl = findRedirectUrl(parameterMap, jettyRequest);

        String tenant = this.getTenant(redirectUrl);
        AttributeContainer attContainer = this.saml2Service.getAttribute(SAMLResponse, getContextPath(jettyRequest));

        // String fileID = this.savePropertiesToFileStore(attContainer,tenant);

        Optional<String> loginToken = this.getLoginToken(tenant, attContainer);

        AtomicReference<String> resultUrl = new AtomicReference<>();

        // log.info(fileID);
        // "?userFileData=" + fileID
        loginToken.ifPresentOrElse(token -> {
            this.authService.addCookieLogin(token, response);

            URI uri = UriBuilder.fromUri(redirectUrl).build();
            resultUrl.set(uri.toString());
        }, () -> resultUrl.set(getContextPath(jettyRequest) + this.page401));

        return resultUrl.get();
    }

    private String findRedirectUrl(Map<String, String[]> parameterMap, Request jettyRequest) throws IOException {
        String relayState;

        if (parameterMap.containsKey("RelayState")) {
            try {
                relayState = this.getRequestParameter(parameterMap, "RelayState");
                return getState(relayState);
            } catch (Exception e) {
                log.info("Relay State not found in request");
            }
        }

        relayState = this.extractRelayStateCookie(jettyRequest);

        if (relayState == null) {
            return this.defaultRedirectUrl;
        }

        return getState(relayState);
    }

    private String extractRelayStateCookie(Request jettyRequest) {
        Cookie[] cookies = jettyRequest.getCookies();
        if (cookies == null) {
            return null;
        }
        Cookie[] var3 = cookies;
        int var4 = cookies.length;

        for (int var5 = 0; var5 < var4; ++var5) {
            Cookie cookie = var3[var5];
            if ("RELAY_STATE_COOKIE".equals(cookie.getName())) {
                return cookie.getValue();
            }
        }

        return null;

    }

    private String getContextPath(Request jettyRequest) {
        String forwarded = "https"; // jettyRequest.getHeader("X-Forwarded-Proto");
        if ("localhost".equals(jettyRequest.getServerName())) {
            forwarded = "http";
        }

        StringBuilder contextPath = jettyRequest.getRootURL();
        int index = contextPath.indexOf(":");
        if (forwarded != null && !forwarded.isEmpty()) {
            contextPath.replace(0, index, forwarded);
        }
        return contextPath.toString();
    }

    private String buildState(Request jettyRequest) throws IOException {
        // StringBuffer redirectTo = new StringBuffer(jettyRequest.getRequestURI());
        StringBuffer redirectTo = new StringBuffer(getContextPath(jettyRequest).concat(jettyRequest.getRequestURI())); // If you also want the host
        String query = jettyRequest.getQueryString();
        if (query != null && !query.isEmpty()) {
            redirectTo.append('?').append(query);
        }

        var bytes = redirectTo.toString().getBytes(StandardCharsets.UTF_8);

        AddFileResponse response = fileStoreClient.addFile(fileStoreAuth, defaultTenant, BUCKET, REDIRECT_URL_FILE_METADATA, new ByteArrayInputStream(bytes));
        return response.getId();
    }

    private String getState(String state) throws IOException {
        try (ByteArrayOutputStream baos = new ByteArrayOutputStream(128)) {

            fileStoreClient.getFileContent(fileStoreAuth, defaultTenant, BUCKET, state, baos);
            return new String(baos.toByteArray(), StandardCharsets.UTF_8);
        }
    }

    private String getRequestParameter(Map<String, String[]> parameterMap, String parameter) {
        Optional<String> value = Arrays.stream(parameterMap.get(parameter)).findFirst();
        return value.orElseThrow(() -> new NotFoundException(parameter + " not found"));
    }

    private String getTenant(String originalUrlString) {
        try {
            URL originalUrl = new URL(originalUrlString);
            String query = originalUrl.getQuery();
            String path = originalUrl.getPath();
            String tenantId = getTenantFromQuery(query)
                    .orElse(getTenantFromPath(path)
                            .orElse(this.defaultTenant));

            if (!tenants.contains(tenantId)) {
                return this.defaultTenant;
            }
            return tenantId;
        } catch (MalformedURLException e) {
            log.error(e.getMessage());
            return this.defaultTenant;
        }
    }

    private Optional<String> getTenantFromQuery(String query) {
        if (query == null) {
            return Optional.empty();
        }
        String[] tokens = query.split("&");
        AtomicReference<String> result = new AtomicReference<>();
        Arrays.stream(tokens)
                .filter(token -> token.startsWith(TENANT_QUERY_PARAM_NAME))
                .findAny()
                .ifPresent(s -> {
                    String[] splittedTokens = s.split("=");
                    if (splittedTokens.length == 2) {
                        result.set(splittedTokens[1]);
                    }
                });
        return Optional.ofNullable(result.get());
    }

    private Optional<String> getTenantFromPath(String path) {
        String[] tokens = path.split("/");
        if (tokens.length < 2) {
            return Optional.empty();
        }
        return Optional.of(tokens[1]);
    }

    private Optional<String> getLoginToken(String tenant, AttributeContainer attributeContainer) {

        UserData userData = this.userService.getUserDataOrNull(tenant, attributeContainer.getFiscalCode());
        if (userData == null) {
            userData = this.userService.createNewUser(tenant, attributeContainer);

            if (userData != null) {
                this.userService.assignUserRole(tenant, userData.getUserName());
            }
        }

        return Optional.of(this.authService.getLoginToken(userData.getUserName(), tenant));
    }

}
