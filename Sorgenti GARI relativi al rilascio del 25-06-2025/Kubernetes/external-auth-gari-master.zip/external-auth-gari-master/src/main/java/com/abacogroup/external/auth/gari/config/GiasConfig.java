package com.abacogroup.external.auth.gari.config;

import lombok.Data;

@Data
public class GiasConfig {
    private String getTokenUrl;
    private String bearerToken;
    private boolean useInsecureClient = false;
}
