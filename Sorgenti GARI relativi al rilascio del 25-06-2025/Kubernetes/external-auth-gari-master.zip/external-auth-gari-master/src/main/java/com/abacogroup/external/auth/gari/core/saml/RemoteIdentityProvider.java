package com.abacogroup.external.auth.gari.core.saml;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.file.Files;
import java.util.Date;
import java.util.Optional;
import java.util.Properties;
import java.util.function.Predicate;

import javax.xml.parsers.DocumentBuilder;

import org.opensaml.core.criterion.EntityIdCriterion;
import org.opensaml.core.xml.XMLObject;
import org.opensaml.core.xml.config.XMLObjectProviderRegistrySupport;
import org.opensaml.core.xml.io.Unmarshaller;
import org.opensaml.saml.common.xml.SAMLConstants;
import org.opensaml.saml.criterion.EntityRoleCriterion;
import org.opensaml.saml.metadata.resolver.impl.DOMMetadataResolver;
import org.opensaml.saml.metadata.resolver.impl.PredicateRoleDescriptorResolver;
import org.opensaml.saml.saml2.core.Issuer;
import org.opensaml.saml.saml2.core.NameID;
import org.opensaml.saml.saml2.metadata.EntityDescriptor;
import org.opensaml.saml.saml2.metadata.IDPSSODescriptor;
import org.opensaml.saml.saml2.metadata.SingleLogoutService;
import org.opensaml.saml.saml2.metadata.SingleSignOnService;
import org.opensaml.saml.security.impl.MetadataCredentialResolver;
import org.opensaml.security.credential.Credential;
import org.opensaml.security.credential.UsageType;
import org.opensaml.xmlsec.config.impl.DefaultSecurityConfigurationBootstrap;
import org.opensaml.xmlsec.keyinfo.KeyInfoCredentialResolver;
import org.opensaml.xmlsec.signature.Signature;
import org.opensaml.xmlsec.signature.support.SignatureConstants;
import org.opensaml.xmlsec.signature.support.SignatureException;
import org.opensaml.xmlsec.signature.support.SignatureValidator;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.auth0.jwt.JWT;
import com.auth0.jwt.JWTVerifier;
import com.auth0.jwt.algorithms.Algorithm;
import com.auth0.jwt.exceptions.JWTVerificationException;

import lombok.extern.slf4j.Slf4j;
import net.shibboleth.utilities.java.support.resolver.CriteriaSet;
import net.shibboleth.utilities.java.support.xml.BasicParserPool;

@Slf4j
public class RemoteIdentityProvider {
	public static final String IDP_METADATA_EXTENSION = ".metadata.xml";
	private static final long AUTHN_ID_DURATION_MS = 1000L * 60 * 15;
	private static final String SAML_AUTHN_AUDIENCE = "SAML-AUTHN";
	private final String ISSUER = "Abaco external sso2-saml";

	private Algorithm algorithm;
	private JWTVerifier verifier;

	private String destinationUrl;
	private String canonicalizationAlgorithm;
	private String entityID;
	private Iterable<Credential> credentials;
	private SingleSignOnService singleSignOnService;
	private SingleLogoutService singleLogoutService;
	private final Predicate<String> IssuerFormatResponseCheck = format -> format != null && !format.isEmpty() && !NameID.ENTITY.equals((format));
	private final Predicate<String> IssuerFormatAssertionCheck = format -> format == null || format.isEmpty() || !NameID.ENTITY.equals(format);

	private BasicParserPool parserPool;

	public RemoteIdentityProvider(BasicParserPool parserPool, String idpMetadataFilePath, String tokenSecret) {
		this.parserPool = parserPool;

		File metadataFile = new File(idpMetadataFilePath);
		if (!metadataFile.exists()) {
			throw new IllegalStateException(metadataFile.getAbsolutePath() + " does not exist");
		}

		File propsFile;
		Properties props;

		try {
			propsFile = new File(metadataFile.getAbsolutePath() + ".properties");
			props = new Properties();
			if (propsFile.exists()) {
				try (InputStream in = new FileInputStream(propsFile)) {
					props.load(in);
				}
			}
			algorithm = Algorithm.HMAC256(tokenSecret);
			this.initIdentityProvider(algorithm, Files.readAllBytes(metadataFile.toPath()), props);
		} catch (IOException e) {
			throw new RuntimeException(e.getMessage(), e);
		}
	}

	private void initIdentityProvider(Algorithm algorithm, byte[] metadataBytes, Properties props) {
		this.algorithm = algorithm;

		try {
			init(metadataBytes, props);
		} catch (Exception e) {
			throw new IllegalStateException(e.getMessage(), e);
		}

		verifier = JWT.require(algorithm)
				.acceptLeeway(5000)
				.withIssuer(ISSUER)
				.withAudience(SAML_AUTHN_AUDIENCE)
				.withSubject(getEntityID())
				.build();
	}

	public String createAuthnID() {
		long now = System.currentTimeMillis();
		return JWT.create()
				.withIssuer(ISSUER)
				.withAudience(SAML_AUTHN_AUDIENCE)
				.withSubject(getEntityID())
				.withIssuedAt(new Date(now))
				.withExpiresAt(new Date(now + AUTHN_ID_DURATION_MS))
				.sign(algorithm);
	}

	public void validateAuthnID(String id) {
		try {
			verifier.verify(id);
		} catch (JWTVerificationException e) {
			throw new SAMLValidationException("Bad Authn ID", e);
		}

	}

	public Predicate<String> getIssuerFormatAssertionCheck() {
		return IssuerFormatAssertionCheck;
	}

	public Predicate<String> getIssuerFormatResponseCheck() {
		return IssuerFormatResponseCheck;
	}

	public void validateIssuer(Issuer issuer, Predicate<String> condition) {
		if (issuer == null) {
			throw new SAMLValidationException("Issuer is null");
		}

		// TODO capire se togliere, perchè al momento non ce lo tornano
		String format = issuer.getFormat();
		if (condition.test(format)) {
			throw new SAMLValidationException("Format attribute must be equal to: " + NameID.ENTITY);
		}

		String parsedIssuer = getParsedIssuer(issuer.getValue());
		String parsedEntityID = getParsedIssuer(getEntityID());

		if (!parsedEntityID.equals(parsedIssuer))
			throw new SAMLValidationException("Bad issuer; expected: " + parsedEntityID + " got: " + parsedIssuer);
	}

	public String getEntityID() {
		return entityID;
	}

	public String getDestinationUrl() {
		return destinationUrl;
	}

	public String getCanonicalizationAlgorithm() {
		return canonicalizationAlgorithm;
	}

	public SingleSignOnService getSingleSignOnService() {
		return singleSignOnService;
	}

	public Optional<SingleLogoutService> getSingleLogoutService() {
		return Optional.ofNullable(singleLogoutService);
	}

	public void validateSignature(Signature signature) throws SignatureException {
		boolean ok = false;
		for (Credential c : credentials) {
			if (c.getUsageType() != UsageType.SIGNING) {
				continue;
			}

			try {
				SignatureValidator.validate(signature, c);
				ok = true;
				break;
			} catch (SignatureException e) {
				// Try next credential, if any...
			}
		}

		if (!ok) {
			throw new SignatureException("Invalid signature");
		}
	}

	private void init(byte[] metadataBytes, Properties props) throws Exception {

		Document doc;
		DocumentBuilder builder = parserPool.getBuilder();
		try (ByteArrayInputStream in = new ByteArrayInputStream(metadataBytes)) {
			doc = builder.parse(in);
		} finally {
			parserPool.returnBuilder(builder);
		}

		// DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		// factory.setNamespaceAware(true);
		// DocumentBuilder docBuilder = factory.newDocumentBuilder();

		// Document doc = docBuilder.parse(new ByteArrayInputStream(metadataBytes));
		Element el = doc.getDocumentElement();

		Unmarshaller unmarshaller = XMLObjectProviderRegistrySupport.getUnmarshallerFactory().getUnmarshaller(el);
		XMLObject obj = unmarshaller.unmarshall(el);
		if (!(obj instanceof EntityDescriptor)) {
			throw new IllegalStateException("Bad IDP metadata XML document");
		}

		EntityDescriptor entityDescriptor = (EntityDescriptor) obj;
		this.entityID = entityDescriptor.getEntityID();

		String tmp = props.getProperty("destinationUrl");
		this.destinationUrl = tmp == null ? entityID : tmp;

		tmp = props.getProperty("canonicalizationAlgorithm");
		if (tmp == null) {
			Signature sig = entityDescriptor.getSignature();
			tmp = sig != null ? sig.getCanonicalizationAlgorithm() : tmp;
		}
		this.canonicalizationAlgorithm = tmp == null ? SignatureConstants.ALGO_ID_C14N11_OMIT_COMMENTS : tmp;

		DOMMetadataResolver domResolver = new DOMMetadataResolver(doc.getDocumentElement());
		domResolver.setId("domResolver");
		domResolver.initialize();

		PredicateRoleDescriptorResolver roleDescriptorResolver = new PredicateRoleDescriptorResolver(domResolver);
		roleDescriptorResolver.initialize();

		KeyInfoCredentialResolver keyInfoCredentialResolver = DefaultSecurityConfigurationBootstrap.buildBasicInlineKeyInfoCredentialResolver();

		MetadataCredentialResolver credentialResolver = new MetadataCredentialResolver();
		credentialResolver.setRoleDescriptorResolver(roleDescriptorResolver);
		credentialResolver.setKeyInfoCredentialResolver(keyInfoCredentialResolver);
		credentialResolver.initialize();

		CriteriaSet criteriaSet = new CriteriaSet();
		criteriaSet.add(new EntityIdCriterion(entityID));
		criteriaSet.add(new EntityRoleCriterion(IDPSSODescriptor.DEFAULT_ELEMENT_NAME));

		credentials = credentialResolver.resolve(criteriaSet);

		initSsoAndSlo(entityDescriptor);
	}

	private void initSsoAndSlo(EntityDescriptor entityDescriptor) {
		IDPSSODescriptor idpSSODescriptor = entityDescriptor.getIDPSSODescriptor(SAMLConstants.SAML20P_NS);
		if (idpSSODescriptor == null) {
			throw new IllegalStateException("No IDPSSODescriptor in metadata");
		}

		this.singleSignOnService = idpSSODescriptor.getSingleSignOnServices().stream()
				.filter(s -> SAMLConstants.SAML2_POST_BINDING_URI.equals(s.getBinding()) || SAMLConstants.SAML2_REDIRECT_BINDING_URI.equals(s.getBinding()))
				.sorted((a, b) -> a.getBinding().compareTo(b.getBinding()))
				.findFirst()
				.orElseThrow(() -> new IllegalStateException("No SingleSignOnService with HTTP-POST or HTTP-Redirect binding found"));

		this.singleLogoutService = idpSSODescriptor.getSingleLogoutServices().stream()
				.filter(s -> SAMLConstants.SAML2_POST_BINDING_URI.equals(s.getBinding()))
				.findFirst()
				.orElse(null);
	}

	private String getParsedIssuer(String issuer) {
		try {
			URL issuerURL = new URL(issuer);
			return issuerURL.getHost();
		} catch (MalformedURLException e) {
			return issuer;
		}
	}
}
