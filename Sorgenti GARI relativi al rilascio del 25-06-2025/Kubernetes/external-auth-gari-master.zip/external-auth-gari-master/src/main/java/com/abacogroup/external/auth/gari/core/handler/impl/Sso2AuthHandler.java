package com.abacogroup.external.auth.gari.core.handler.impl;

import java.io.IOException;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.List;
import java.util.stream.Collectors;

import org.eclipse.jetty.server.Request;

import com.abacogroup.dropwizard.auth.sso2.Constants;
import com.abacogroup.dropwizard.auth.sso2.JwtAuthenticator;
import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.external.auth.gari.api.Sso2RequestIn;
import com.abacogroup.external_auth_sdk.http.AuthService;
import com.abacogroup.external_auth_sdk.http.handler.ExternalAuthHandler;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class Sso2AuthHandler implements ExternalAuthHandler {
	private AuthService authService;

	public Sso2AuthHandler(AuthService authService) {
		this.authService = authService;
	}

	@Override
	public boolean shouldIHandleIt(String target, Request jettyRequest) {
		return target.equals("/ac-sso2") && jettyRequest.getMethod().equals("POST");
	}

	@Override
	public boolean handle(Request jettyRequest, HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse) throws Exception {
		Sso2RequestIn sso2RequestIn = this.parseBodyFormParam(jettyRequest);
		String state = this.getState(sso2RequestIn.getState());

		User user = this.authService.getUserFromToken(sso2RequestIn.getAuthToken(),
				new JwtAuthenticator(this.authService.getSso2Client(), List.of(Constants.AUTH_AUDIENCE)));

		if (user != null) {
			String loginCookie = this.authService.getLoginToken(user.getName(), user.getTenant());
			this.authService.addCookieLogin(loginCookie, httpServletResponse);
			httpServletResponse.sendRedirect(state);
			return true;
		}

		return false;
	}

	private String getState(String state) {
		String decodedUriState = URLDecoder.decode(state, StandardCharsets.UTF_8);
		byte[] bytes = Base64.getUrlDecoder().decode(decodedUriState);
		return new String(bytes, StandardCharsets.UTF_8);
	}

	private Sso2RequestIn parseBodyFormParam(Request jettyRequest) throws IOException {
		String body = jettyRequest.getReader().lines().collect(Collectors.joining(System.lineSeparator()));
		Sso2RequestIn sso2RequestIn = new Sso2RequestIn();
		String[] tokens = body.split("&");
		for (int i = 0; i < tokens.length; i++) {
			String[] keyVal = tokens[i].split("=");
			if (keyVal.length <= 1) {
				throw new IllegalStateException("Cannot parse tokens");
			}
			if (keyVal[0].equals("authToken")) {
				sso2RequestIn.setAuthToken(keyVal[1]);
			}
			if (keyVal[0].equals("state")) {
				sso2RequestIn.setState(keyVal[1]);
			}
		}

		return sso2RequestIn;
	}
}
