#!/bin/sh

umask 0002 && \
java -XX:MaxRAMPercentage=70 -XshowSettings:vm -jar ${project.build.finalName}.jar config.yml
