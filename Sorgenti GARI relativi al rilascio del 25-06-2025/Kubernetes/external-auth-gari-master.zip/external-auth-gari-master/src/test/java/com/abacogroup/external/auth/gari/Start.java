package com.abacogroup.external.auth.gari;

public class Start {
    public static void main(String[] args) throws Exception {
        ExternalAuthGariApplication.main(new String[] { "config.yml" });
    }
}
