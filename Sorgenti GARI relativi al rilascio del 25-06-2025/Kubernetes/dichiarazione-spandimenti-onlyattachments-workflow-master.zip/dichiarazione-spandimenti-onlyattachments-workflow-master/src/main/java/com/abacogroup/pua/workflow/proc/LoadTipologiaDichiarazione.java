package com.abacogroup.pua.workflow.proc;

import com.abacogroup.applicationworkflowsdk.environment.IAgriProcedureEnvironment;
import com.abacogroup.applicationworkflowsdk.v2.procedures.ApplicationProcedure;
import com.abacogroup.pua.workflow.model.TipologiaDichirazione;
import com.abacogroup.workflow.sdk.beans.ProcessData;
import com.abacogroup.workflow.sdk.beans.WorkflowMessage;
import com.abacogroup.workflow.sdk.proc.StopTransitionException;

import jakarta.ws.rs.client.Client;
import jakarta.ws.rs.client.WebTarget;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class LoadTipologiaDichiarazione extends ApplicationProcedure {

    @Override
    protected void doExecute(ProcessData processData, IAgriProcedureEnvironment env) throws Exception {
        log.debug("[dichiarazione-spandimenti-onlyattachment-workflow] LoadTipologiaDichiarazione started");
        String url = env.getProperty("puaAppFormsUrl").orElseThrow().toString();

        Client client = env.getJerseyClient().orElseThrow();
        WebTarget target = processData.getAuthContext()
                .getAuthenticatedWebTarget(client, url)
                .path("/master/v1/applications/")
                .path(getApplicationsWorkflowParams().getApplicationId().toString())
                .path("tipologia-dichiarazione");

        log.debug("[dichiarazione-spandimenti-onlyattachment-workflow] Preparing WebTarget");
        try (Response response = target.request(MediaType.APPLICATION_JSON).get()) {
            int status = response.getStatus();
            if (status == 404) {
                processData.getWorkflowMessages()
                        .add(new WorkflowMessage("FORM_NOT_PRESENT", "Compilare la form per procedere", WorkflowMessage.Type.ERROR));

                throw new StopTransitionException();
            }

            if (status < 200 || status > 299) {
                throw new IllegalStateException("Got a bad response; status is: " + status);
            }

            TipologiaDichirazione tipologiaDichirazione = response.readEntity(TipologiaDichirazione.class);

            processData.getGlobalVars().put(TipologiaDichirazione.KEY, tipologiaDichirazione);
            log.debug("[dichiarazione-spandimenti-onlyattachment-workflow] Setting global var {} = {}", TipologiaDichirazione.KEY, tipologiaDichirazione);
        }
    }

}
