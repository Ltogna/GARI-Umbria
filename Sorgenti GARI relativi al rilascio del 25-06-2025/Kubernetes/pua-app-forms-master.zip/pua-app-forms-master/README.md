# PUA-APP-FORMS

## Bundles Infrastructure integration

The application must be connected to a RabbitMQ instance.

The bundles infrastructure will automatically set up to allow automatic configuration.

The application module id is `pua-application-forms` and the supported changeset domains are:

```
📂 pua-application-forms
┣ 📂 <client-id>-<nnnn>
  ┣ 📂 workflows
    📂 attachment-types
    ┣ 📜 <any file>.json
    📂 dynamic-document-types
    ┣ 📜 <any file>.json
    📂 effluent-types
    ┣ 📜 <any file>.json
   
```

n = one digit (0..9)

The workflow file(s) is a jar or zip containing the workflow definition.

 

The attachment-types JSON file(s) must have the following structure:

```
{
   "attachmentTypes":[
      {
         "code":"String",
         "typeCode":"String",
         "attachmentGroupCode":"String",
         "i18n":[
            {
               "lang":"String",
               "description":"String"
            }
         ]
      }
   ]
}
```
 
 The dynamic-document-types JSON file(s) must have the following structure:

```
{
   "documentTypes":[
      {
         "code":"String",
         "title":{
            "en":"String",
            "it":"String"
         },
         "description":"String",
         "version":"String",
         "metadata":{
            "maxOccurs":"Integer",
            "timeOverlap":"Boolean",
            "endDateField":"LocalDate",
            "defaultLocale":"String",
            "startDateField":"LocalDate"
         },
         "fieldSets":[
            {
               "code":"String",
               "label":{
                  "en":"String",
                  "it":"String"
               },
               "fields":[
                  {
                     "code":"String",
                     "type":"String",
                     "label":{
                        "en":"String",
                        "it":"String"
                     },
                     "required":"Boolean"
                  }
               ],
               "maxOccurs":"Integer",
               "minOccurs":"Integer"
            }
         ]
      }
   ]
}
```

The effluent-types JSON file(s) must have the following structure:

```
{
  "effluentTypes": [
	    {
	      "categoryCode": "String",
	      "fertilizerCategory": "String",
	      "typeCode": "String",
	      "fertilizerType": "String"
	    }
    }
}
```



## Environment variables

- ACTIVATE_JWT_AUTH: BOOLEAN If TRUE, activate the JWT Filter, which verify the jwt token in the header Authorization, with schema "JWT". Example:
  Authorization: "JWT >token<". if FALSE, a Dev Filter is activated, which does not verify any Authorization header and inject an User with username: "ADMIN"
  and tenant: "tenant"
- SSO2_URL: STRING the url from which the application downloads the certificates to verify the JWT token signature
- DATABASE_TYPE: STRING
  "oracle" or "postgresql", defines which database the application should connect
- DATABASE_DRIVER: STRING the database driver in form of full defined class name
- JDBC_URL: STRING jdbc url for connecting to database
- JDBC_USER: STRING user for connecting to database
- JDBC_PASSWORD: STRING password for database
- JDBC_VALIDATION_QUERY: STRING a validation query for certify that connection is working (required by JDBI)

