package com.abacogroup.agri.applicationforms.pua.core.exceptions;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.ws.rs.core.Response;

public class DocDefNotFoundRuntimeException extends AbstractException {

	private static final long serialVersionUID = 1L;
	
	private static final DocDefNotFoundRuntimeException.ErrorBody BODY = new DocDefNotFoundRuntimeException.ErrorBody();

	public DocDefNotFoundRuntimeException(String message) {
		super(Response.Status.NOT_FOUND, BODY, message);
	}

	public DocDefNotFoundRuntimeException() {
		super(Response.Status.NOT_FOUND, BODY, "Object not found");
	}

	@Schema(name = "DocDefNotFoundRuntimeExceptionErrorBody")
	public static class ErrorBody implements ExceptionErrorBody {
		private static final String ERR = "DOCUMENT_DEFINITION_NOT_FOUND_ERROR";

		@Override
		@Schema(allowableValues = ERR)
		public String getErrorCode() {
			return ERR;
		}
	}
}
