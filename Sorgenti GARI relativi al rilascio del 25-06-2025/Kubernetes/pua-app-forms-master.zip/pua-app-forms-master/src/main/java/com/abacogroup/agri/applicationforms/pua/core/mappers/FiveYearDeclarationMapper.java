package com.abacogroup.agri.applicationforms.pua.core.mappers;

import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import com.abacogroup.agri.applicationforms.pua.core.model.dto.FiveYearDeclarationDTO;
import com.abacogroup.agri.applicationforms.pua.db.ntt.FiveYearDeclarationNTT;
import com.abacogroup.jdbi.mapper.AbsoluteDateMapper;

/**
 * 
 * @author Emanuele Crocilla
 *
 */
@Mapper(uses = AbsoluteDateMapper.class)
public interface FiveYearDeclarationMapper extends EntityMapper<FiveYearDeclarationDTO, FiveYearDeclarationNTT> {

	FiveYearDeclarationMapper INSTANCE = Mappers.getMapper(FiveYearDeclarationMapper.class);

	@InheritInverseConfiguration()
	FiveYearDeclarationDTO entityToDto(FiveYearDeclarationNTT entity);

	FiveYearDeclarationNTT dtoToEntity(FiveYearDeclarationDTO dto);

}
