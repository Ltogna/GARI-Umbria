package com.abacogroup.agri.applicationforms.pua.core.mappers;

import java.time.LocalDate;
import java.time.LocalDateTime;

import com.abacogroup.agri.applicationforms.pua.core.model.AbsoluteDate;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class AbsoluteDateMapper {

	public String asString(AbsoluteDate date) {
		if (date == null)
			return null;

		try {
			return date.toString();
		} catch (Exception e) {
			log.error(e.getMessage(), e);
		}

		return null;
	}

	public LocalDate asLocalDate(AbsoluteDate date) {
		if (date == null) {
			return null;
		}
		try {
			return date.get();
		} catch (Exception e) {
			log.error(e.getMessage(), e);
		}
		return null;
	}

	public AbsoluteDate asAbsoluteDate(String date) {
		if (date == null || date.isBlank())
			return null;

		try {
			return new AbsoluteDate(date);
		} catch (Exception e) {
			log.error(e.getMessage(), e);
		}
		return null;
	}

	public AbsoluteDate asAbsoluteDate(LocalDate date) {
		if (date == null)
			return null;

		try {
			return new AbsoluteDate(date);
		} catch (Exception e) {
			log.error(e.getMessage(), e);
		}
		return null;
	}

	public AbsoluteDate asAbsoluteDate(LocalDateTime localDateTime) {
		if (localDateTime == null)
			return null;

		try {
			return new AbsoluteDate(localDateTime.toLocalDate());
		} catch (Exception e) {
			log.error(e.getMessage(), e);
		}
		return null;
	}

}
