package com.abacogroup.agri.applicationforms.pua.core.model.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class BalanceIndicesResponse {

	@JsonProperty("Chiave_Appezzamento")
	private String chiaveAppezzamento;

	@JsonProperty("Ciclo_Principale")
	private Boolean cicloPrincipale;

	@JsonProperty("ZVN")
	private Boolean zvn;

	@JsonProperty("N_Mas")
	private Double nMas;

	@JsonProperty("N_Fabbisogno")
	private Double nFabbisogno;

	@JsonProperty("N_FabbisognoSoddisfatto")
	private Double nFabbisognoSoddisfatto;

	@JsonProperty("N_Zootecnico")
	private Double nZootecnico;

	@JsonProperty("N_Zootecnico_Letame")
	private Double nZootecnicoLetame;

	@JsonProperty("N_Zootecnico_Liquame")
	private Double nZootecnicoLiquame;

	@JsonProperty("N_BilancioAzotato_Utile")
	private Double nBilancioAzotatoUtile;

	@JsonProperty("N_TotaleSoddisfatto")
	private Double nTotaleSoddisfatto;

	@JsonProperty("N_BilancioAzotato_Totale")
	private Double nBilancioAzotatoTotale;
}
