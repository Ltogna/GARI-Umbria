package com.abacogroup.agri.applicationforms.pua.db.dao;

import java.time.Instant;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.util.Calendar;
import java.util.List;

import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.customizer.BindBean;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;

import com.abacogroup.agri.applicationforms.pua.core.exceptions.ObjectNotFoundRuntimeException;
import com.abacogroup.agri.applicationforms.pua.db.ntt.FiveYearDeclarationNTT;
import com.abacogroup.agri.applicationforms.pua.services.common.FunctionalObject;

/**
 * 
 * @author Emanuele Crocilla
 *
 */
public interface FiveYearDeclarationDAO extends IGenericPuaDAO<FiveYearDeclarationNTT, Long> {

	@Override
	@SqlQuery("§select_nextval(appfpua_five_year_declaration_id_seq)§")
	Long nextSequenceVal();
	
	@Override
	@SqlUpdate("""
			INSERT INTO appfpua_five_year_declaration (pkid, application_id, id, party_id, sector_code, block_code, 
			parcel_code, sub_parcel_code, cadastral_area_sqm, day_from, day_to, used_area_sqm, dt_insert, dt_delete, user_id_insert ) 
			VALUES(:pkId, :applicationId, :id, :partyId, :sectorCode, :blockCode, :parcelCode, :subParcelCode, 
			:cadastralAreaSqm, :dayFrom, :dayTo, :usedAreaSqm, :dtInsert, :dtDelete, :userIdInsert) """)
	void insert(@BindBean FiveYearDeclarationNTT ntt);

	@SqlQuery("SELECT * FROM appfpua_five_year_declaration WHERE pkid = :pkid ")
	@RegisterBeanMapper(FiveYearDeclarationNTT.class)
	List<FiveYearDeclarationNTT> findById(@Bind("pkid") Long pkid);
 
	@SqlQuery("SELECT * FROM appfpua_five_year_declaration WHERE id = :declarationId AND §current_timestamp§ between dt_insert AND dt_delete  ")
	@RegisterBeanMapper(FiveYearDeclarationNTT.class)
	FiveYearDeclarationNTT findByDeclarationId(@Bind("declarationId") Long declarationId);
	
	@SqlQuery("select * from appfpua_five_year_declaration WHERE application_id = :application_id AND dt_delete > §current_timestamp§ order by id")
    @RegisterBeanMapper(FiveYearDeclarationNTT.class)
    List<FiveYearDeclarationNTT> findByApplicationId(@Bind("application_id") Long applicationId);

	 
	@SqlUpdate(""" 
			UPDATE public.appfpua_five_year_declaration 
			SET id=:id, sector_code=:sectorCode, block_code=:blockCode, parcel_code=:parcelCode, sub_parcel_code=:subParcelCode, 
			cadastral_area_sqm=:cadastralAreaSqm, day_from=:dayFrom, day_to=:dayTo, used_area_sqm=:usedAreaSqm 
			WHERE pkid = :pkId """)
	@Override
	void update(@BindBean FiveYearDeclarationNTT rs);
	
	@SqlUpdate("""
            UPDATE appfpua_five_year_declaration
               SET dt_delete=:dtDelete,
                   user_id_delete = :userIdDelete
             WHERE application_id=:applicationId 
    		  	   AND id=:declatationId 
               AND §current_timestamp§ between dt_insert AND dt_delete 
            """)
    void expireByDeclarationId(@Bind("applicationId") Long applicationId, @Bind("declatationId") Long declatationId,  @Bind("dtDelete") OffsetDateTime dtDelete, @Bind("userIdDelete") String userIdDelete);

	@SqlUpdate("""
            UPDATE appfpua_five_year_declaration
               SET dt_delete=:dtDelete,
                   user_id_delete = :userIdDelete
             WHERE application_id=:applicationId 
    		  	   AND pkId=:pkId 
               AND §current_timestamp§ between dt_insert AND dt_delete 
            """)
    void expireByPkId(@Bind("applicationId") Long applicationId, @Bind("pkId") Long pkId,  @Bind("dtDelete") OffsetDateTime dtDelete, @Bind("userIdDelete") String userIdDelete);


	default void upsert(FiveYearDeclarationNTT nttToUpd) {
    	
    	// suppose that all ntts have the same application ID
    	FunctionalObject<Long> applicationId = () -> nttToUpd != null ? nttToUpd.getApplicationId() : null;
    	FunctionalObject<Long> nttId = () -> nttToUpd != null ? nttToUpd.getId() : null;
    	
    	if (nttToUpd != null && nttId.get() != null && this.countById(nttId.get()) > 0) {

			String userIdInsert = nttToUpd.getUserIdInsert();
			long rightNow = Calendar.getInstance().getTimeInMillis();
        	long rightNowMinusAMillis = rightNow-1;
        	
        	Instant instantRightNow = Instant.ofEpochMilli(rightNow);
        	Instant instantMinusAMillis = Instant.ofEpochMilli(rightNowMinusAMillis);
        	
        	OffsetDateTime dateTimeRightNow = instantRightNow.atOffset(ZoneOffset.UTC);
        	OffsetDateTime dateTimeMinusAMillis = instantMinusAMillis.atOffset(ZoneOffset.UTC);

        	nttToUpd.setDtInsert(dateTimeRightNow);
        	
        	nttToUpd.setPkId(nextSequenceVal());
        	
        	useTransaction(dao -> {
        		
        		((FiveYearDeclarationDAO)dao).expireByDeclarationId(applicationId.get(), nttId.get(), dateTimeMinusAMillis, userIdInsert);
    			((FiveYearDeclarationDAO)dao).insert(nttToUpd);
            });
    	}
    	else {
    		
    		throw new ObjectNotFoundRuntimeException("Unable to find id = " + applicationId.get() + " and Id = " + nttId.get());
    	}
    }

	@SqlQuery("select count(*) from appfpua_five_year_declaration where id = :id and dt_delete > §current_timestamp§")
    @RegisterBeanMapper(FiveYearDeclarationNTT.class)
    int countById(@Bind("id") Long d);
	
	@SqlQuery("select count(*) from appfpua_five_year_declaration where application_id = :application_id and dt_delete > §current_timestamp§")
    @RegisterBeanMapper(FiveYearDeclarationNTT.class)
    int count(@Bind("application_id") Long applicationId);
}
