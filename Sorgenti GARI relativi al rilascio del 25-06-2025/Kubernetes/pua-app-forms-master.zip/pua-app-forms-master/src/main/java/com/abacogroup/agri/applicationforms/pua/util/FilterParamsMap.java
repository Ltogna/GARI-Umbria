package com.abacogroup.agri.applicationforms.pua.util;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;

/**
 * 
 * @author Emanuele Crocilla
 *
 */
public class FilterParamsMap extends HashMap<String, FilterParam>{

	public Collection<String> getParamNames() {
		return keySet();
	}
	
	public Collection<String> getParamDbNames() {
		Collection<String> res = new ArrayList<>();
		for (FilterParam filterParam : values()) {
			res.add(filterParam.getDbName());
		}
		return res;
	}
	
	public Collection<String> getParamDbNames(Collection<String> namesToExtract) {
		Collection<String> res = new ArrayList<>();
		for (String name : namesToExtract) {
			if(containsKey(name)) {
				res.add(get(name).getDbName());
			}
		}
		return res;
	}
}
