package com.abacogroup.agri.applicationforms.pua.services;

import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.Optional;

import com.abacogroup.agri.applicationforms.pua.core.exceptions.ObjectNotFoundRuntimeException;
import com.abacogroup.agri.applicationforms.pua.core.mappers.OptionCatalogMapper;
import com.abacogroup.agri.applicationforms.pua.core.model.OptionType;
import com.abacogroup.agri.applicationforms.pua.core.model.dto.OptionCatalogDTO;
import com.abacogroup.agri.applicationforms.pua.db.dao.IGenericPuaDAO;
import com.abacogroup.agri.applicationforms.pua.db.dao.OptionCatalogDAO;
import com.abacogroup.agri.applicationforms.pua.db.ntt.OptionCatalogNTT;
import com.abacogroup.agri.applicationforms.pua.db.ntt.OptionConfigsNTT;
import com.abacogroup.agri.applicationforms.pua.db.ntt.applications.RsI18N;
import com.abacogroup.agri.applicationforms.pua.services.common.I18NService;
import com.abacogroup.agri.applicationforms.pua.services.common.crud.AbstractCrudService;
import com.abacogroup.agri.applicationforms.pua.util.GenericUtility;
import com.abacogroup.jdbi.datatype.AbsoluteDate;

import lombok.extern.slf4j.Slf4j;

/**
 * @author Alexandru Paraschiv
 * @author Emanuele Crocilla
 */
@Slf4j
public class OptionCatalogsCrudService extends AbstractCrudService<OptionCatalogNTT, Long, OptionCatalogDTO, OptionCatalogMapper, Void, IGenericPuaDAO<OptionCatalogNTT, Long>> {

	public static final String I18N_OPTION_CATALOG_TABLE = "appfpua_option_catalog";
	private final I18NService i18NService;

	public OptionCatalogsCrudService(IGenericPuaDAO<OptionCatalogNTT, Long> dao, OptionCatalogMapper mapper,
									 I18NService i18NService) {
		super(dao, mapper);
		this.i18NService = i18NService;
	}

	@Override
	protected boolean hasPrimaryKey() {
		return true;
	}

	@Override
	protected Optional<OptionCatalogNTT> findRsByCustomKey(Void customKey) {
		return Optional.empty();
	}

	@Override
	protected void deleteByCustomKey(Void customKey) {
		throw GenericUtility.throwNotImplementedException.get();
	}

	@Override
	protected void setCustomSearchKey(OptionCatalogNTT rs, Void customKey) {
		throw GenericUtility.throwNotImplementedException.get();
	}

	public Optional<OptionCatalogDTO> findOptById(Long id) {
		log.info("Invoking findById with params id:{}", id);

		return this.dao.findById(id)
				.stream()
				.findFirst()
				.map(mapper::entityToDto);
	}

	public OptionCatalogDTO findById(Long id) {
		log.info("Invoking findById with params id:{}", id);

		return this.dao.findById(id)
				.stream()
				.findFirst()
				.map(mapper::entityToDto)
				.orElseThrow(ObjectNotFoundRuntimeException::new);
	}

	public OptionCatalogDTO findByOptionCode(String tenant, String optionCode) {
		log.info("Invoking findByOptionCode with params tenant:{} optionCode:{}", tenant, optionCode);

		return ((OptionCatalogDAO) this.dao).findByOptionCode(tenant, optionCode)
				.stream()
				.findFirst()
				.map(mapper::entityToDto)
				.orElseThrow(ObjectNotFoundRuntimeException::new);
	}

	public OptionCatalogDTO findByOptionCode(String tenant, String optionCode, String lang) {
		log.info("Invoking findByOptionCode with params tenant:{} optionCode:{} lang: {}", tenant, optionCode, lang);

		return ((OptionCatalogDAO) this.dao).findByOptionCode(tenant, optionCode, lang)
				.stream()
				.findFirst()
				.map(mapper::entityToDto)
				.orElseThrow(ObjectNotFoundRuntimeException::new);
	}

	public Optional<OptionCatalogDTO> findOptByOptionCode(String tenant, String optionCode) {
		log.info("Invoking findById with params tenant:{} optionCode:{}", tenant, optionCode);

		return ((OptionCatalogDAO) this.dao).findByOptionCode(tenant, optionCode, Locale.ITALIAN.getLanguage())
				.stream()
				.findFirst()
				.map(mapper::entityToDto);
	}

	public Optional<OptionCatalogDTO> findOptByOptionCodesAndOptionCode(String tenant, List<String> optionCodeList, String optionCode) {
		log.info("Invoking findById with params tenant:{} optionCode:{}", tenant, optionCode);

		return ((OptionCatalogDAO) this.dao).findByOptionCodesAndOptionCode(tenant, optionCodeList, optionCode, Locale.ITALIAN.getLanguage())
				.stream()
				.findFirst()
				.map(mapper::entityToDto);
	}

	public List<OptionCatalogDTO> findByOptionId(String tenant, Long optionId) {
		return ((OptionCatalogDAO) this.dao).findByOptionId(tenant, optionId, Locale.ITALIAN.getLanguage()).stream()
				.map(mapper::entityToDto)
				.toList();
	}

	public List<OptionCatalogDTO> findByOptionIds(String tenant, List<Long> optionIds) {
		return ((OptionCatalogDAO) this.dao).findByOptionIds(tenant, optionIds, Locale.ITALIAN.getLanguage()).stream()
				.map(mapper::entityToDto)
				.toList();
	}

	public List<OptionCatalogDTO> findByOptionCodes(String tenant, List<String> optionCodeList) {
		if(Optional.ofNullable(optionCodeList).isEmpty() || optionCodeList.isEmpty()){
			return Collections.emptyList();
		}

		return ((OptionCatalogDAO) this.dao).findByOptionCodes(tenant, optionCodeList, Locale.ITALIAN.getLanguage()).stream()
				.map(mapper::entityToDto)
				.toList();
	}

	public List<OptionCatalogDTO> findAllByTenant(String tenant) {
		log.info("Invoking findById with params tenant:{}", tenant);

		return ((OptionCatalogDAO) this.dao).findAllByTenant(tenant, Locale.ITALIAN.getLanguage())
				.stream()
				.map(mapper::entityToDto)
				.toList();
	}

	public OptionCatalogDTO insert(OptionCatalogDTO in) {
		log.info("Invoking insert with params in: {}", in);
		return this.insert(in, null);
	}

	public OptionCatalogDTO update(Long id, OptionCatalogDTO in) {
		log.info("Invoking update with params key: {} in: {}", id, in);
		return this.update(id, in, null);
	}

	public void insertOptionCatalogI18n(String tenant, String code, String lang, String description) {
		log.info("Invoking insertOptionCatalogI18n with params tenant: {} code: {} lang: {} description: {}", tenant, code, lang, description);
		this.i18NService.insertI18N(tenant, I18N_OPTION_CATALOG_TABLE, OPTION_CATALOG_I18N.CODE.optionCode, lang, code, description);
	}

	public void deleteOptionCatalogI18N(String tenant, String code) {
		log.info("Invoking deleteOptionCatalogI18N with params tenant: {} code: {}", tenant, code);
		this.i18NService.deleteAllI18NbyCode(tenant, I18N_OPTION_CATALOG_TABLE, code);
	}

	public List<RsI18N> getAllOptionCatalogI18NByTenantAndCode(String tenant, String code) {
		return this.i18NService.getAllI18NbyCode(tenant, I18N_OPTION_CATALOG_TABLE, code);
	}

	public enum OPTION_CATALOG_I18N {
		CODE("option_code");

		private final String optionCode;

		OPTION_CATALOG_I18N(String val) {
			this.optionCode = val;
		}

		public String getOptionCode() {
			return this.optionCode;
		}
	}

	public List<String> findFatherOptionCodeByChildOptionCode(String tenant, String optionCode) {
		return ((OptionCatalogDAO) this.dao).findFatherOptionCodeByChildOptionCode(tenant, optionCode);
	}

	public List<OptionConfigsNTT> findChildrenConfigsByFatherOptionCode(String tenant, String optionCode) {
		return ((OptionCatalogDAO) this.dao).findChildrenConfigsByFatherOptionCode(tenant, optionCode);
	}

	public String findOptionCodeByOptionConfigId(String tenant, Long optionConfigId) {
		return ((OptionCatalogDAO) this.dao).findOptionCodeByOptionConfigId(tenant, optionConfigId);
	}

	public List<OptionType> retrieveOptionCatalogAndType(String tenant, AbsoluteDate validityDate) {
		return ((OptionCatalogDAO) this.dao).retrieveOptionCatalogAndType(tenant, validityDate.toString());
	}
}

