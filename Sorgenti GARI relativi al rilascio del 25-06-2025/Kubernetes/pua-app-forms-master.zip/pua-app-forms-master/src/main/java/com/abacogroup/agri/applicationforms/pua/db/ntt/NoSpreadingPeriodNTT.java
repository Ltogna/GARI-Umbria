package com.abacogroup.agri.applicationforms.pua.db.ntt;

import com.abacogroup.agri.applicationforms.pua.db.ntt.applications.IIdRs;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.OffsetDateTime;
import java.util.Optional;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class NoSpreadingPeriodNTT implements IIdRs<Long> {
	private Long pkid;
	private Long applicationId;
	private String effluent;

	private String dayFrom;
	private String dayTo;

	private OffsetDateTime dtInsert;
	private OffsetDateTime dtDelete;
	private String userIdInsert;
	private String userIdDelete;

	@Override
	public void setKey(Long id) {
		this.pkid = id;
	}

	@Override
	public Optional<Long> getKey() {
		return Optional.ofNullable(pkid);
	}
}
