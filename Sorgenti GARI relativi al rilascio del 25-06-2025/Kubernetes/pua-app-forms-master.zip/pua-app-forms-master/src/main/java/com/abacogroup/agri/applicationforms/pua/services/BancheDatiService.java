package com.abacogroup.agri.applicationforms.pua.services;

import com.abacogroup.agri.applicationforms.pua.ApplicationFormsModuleConfiguration;
import com.abacogroup.agri.applicationforms.pua.core.model.EffluentFrequencyKey;
import com.abacogroup.agri.applicationforms.pua.core.model.PrecedingCropTypeKey;
import com.abacogroup.agri.applicationforms.pua.core.model.dto.*;
import com.abacogroup.dropwizard.auth.sso2.Sso2Client;
import com.abacogroup.dropwizard.auth.sso2.User;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.github.benmanes.caffeine.cache.Cache;
import com.github.benmanes.caffeine.cache.Caffeine;
import jakarta.ws.rs.client.Client;
import lombok.extern.slf4j.Slf4j;

import java.math.BigDecimal;
import java.util.List;
import java.util.concurrent.TimeUnit;

/**
 * @author Emanuele Crocilla
 */
@Slf4j
public class BancheDatiService extends ADataImporterService {

	private Cache<PrecedingCropTypeKey, PrecedingCropType> precedingCropTypeCache;
	private Cache<EffluentFrequencyKey, EffluentFrequency> effluentFrequencyCache;

	public BancheDatiService(Sso2Client sso2client, Client client, ApplicationFormsModuleConfiguration config, ObjectMapper objectMapper) {
		super(sso2client, client, config, objectMapper);

		this.precedingCropTypeCache = Caffeine.newBuilder()
				.maximumSize(100L)
				.expireAfterAccess(3, TimeUnit.HOURS)
				.build(); // without automatic loader

		this.effluentFrequencyCache = Caffeine.newBuilder()
				.maximumSize(100L)
				.expireAfterAccess(3, TimeUnit.HOURS)
				.build(); // without automatic loader
	}

	public List<Specie> getSpecies(User user, String tenant) {
		try {

			authToken = user.getAuthToken();

			String url = String.format("%s/%s/public/v1/animals/species", bancheDatiUrl, tenant);

			TypeReference<List<Specie>> responseType = new TypeReference<>() {
			};

			return sendGetRequestWithAuth(url, responseType, "species", tenant);

		} catch (Exception ex) {
			checkResponseStatus(null, "", tenant, "", "Error processing response for get species service", ex);
			throw new RuntimeException("Error processing response for get species service", ex);
		}
	}

	public List<Effluent> getEffluents(User user, String tenant) {
		try {

			authToken = user.getAuthToken();

			String url = String.format("%s/%s/public/v1/effluents?filterOnceWithFrequency=false", bancheDatiUrl, tenant);

			TypeReference<List<Effluent>> responseType = new TypeReference<>() {
			};

			return sendGetRequestWithAuth(url, responseType, "effluents", tenant);

		} catch (Exception ex) {
			checkResponseStatus(null, "", tenant, "", "Error processing response for getEffluents service", ex);
			throw new RuntimeException("Error processing response for getEffluents service", ex);
		}
	}

	public List<AnimalHousing> getAnimalHousing(User user, String tenant, String genreCode,
			String specieCode, String categoryCode, String productionCode) {

		try {

			authToken = user.getAuthToken();

			String url = String.format("%s/%s/public/v1/animals/species/%s/%s/%s/%s/housing",
					bancheDatiUrl, tenant, genreCode, specieCode, categoryCode, productionCode);

			TypeReference<List<AnimalHousing>> responseType = new TypeReference<>() {
			};

			return sendGetRequestWithAuth(url, responseType, "getAnimalHousing", tenant);

		} catch (Exception ex) {
			checkResponseStatus(null, "", tenant, "", "Error processing response for getAnimalHousing service", ex);
			throw new RuntimeException("Error processing response for getAnimalHousing service", ex);
		}
	}

	public List<AnimalCategory> getAnimalCategory(User user, String tenant, String genreCode, String code) {

		try {

			authToken = user.getAuthToken();

			String url = String.format("%s/%s/public/v1/animals/species/%s/%s/categories",
					bancheDatiUrl, tenant, genreCode, code);

			TypeReference<List<AnimalCategory>> responseType = new TypeReference<>() {
			};

			return sendGetRequestWithAuth(url, responseType, "getAnimalCategory", tenant);

		} catch (Exception ex) {
			checkResponseStatus(null, "", tenant, "", "Error processing response for getAnimalCategory service", ex);
			throw new RuntimeException("Error processing response for getAnimalCategory service", ex);
		}
	}

	/**
	 * the MAS is MaxToAddByCrop.nitrogenQt example:
	 * https://umbria-dev.fe.abacogroup.eu/banche-dati/:tenant/public/v1/nitrogen/max-to-add-by-crop?cropCode=A15-011-000-000-000 returns something like that:
	 * [{ "cropCode": "A15-011-000-000-000", "nitrogenQt": 20.0, "yield": 25.0, "nitrogenCorrectionFactor": 0.0 }]
	 */
	public List<MaxToAddByCrop> getMaxToAddByCrop(User user, String tenant, List<String> cropCodes) {
		try {

			authToken = user.getAuthToken();

			StringBuilder cropCoderParams = new StringBuilder("?");

			for (String cropCode : cropCodes) {
				cropCoderParams.append("cropCode=").append(cropCode).append("&");
			}

			String url = String.format("%s/%s/public/v1/nitrogen/max-to-add-by-crop" + cropCoderParams, bancheDatiUrl, tenant);

			TypeReference<List<MaxToAddByCrop>> responseType = new TypeReference<>() {
			};

			return sendGetRequestWithAuth(url, responseType, "getMaxToAddByCrop", tenant);

		} catch (Exception ex) {
			checkResponseStatus(null, "", tenant, "", "Error processing response for getMaxToAddByCrop service", ex);
			throw new RuntimeException("Error processing response for getMaxToAddByCrop service", ex);
		}
	}

	/**
	 * https://umbria-dev.fe.abacogroup.eu/banche-dati/:tenant/public/v1/effluents
	 */
	public List<Effluent> getEffluentList(User user, String tenant) {
		try {
			authToken = user.getAuthToken();

			String url = String.format("%s/%s/public/v1/effluents", bancheDatiUrl, tenant);

			TypeReference<List<Effluent>> responseType = new TypeReference<>() {
			};

			return sendGetRequestWithAuth(url, responseType, "getEffluentList", tenant);

		} catch (Exception ex) {
			checkResponseStatus(null, "", tenant, "", "Error processing response for getEffluentList service", ex);
			throw new RuntimeException("Error processing response for getEffluentList service", ex);
		}
	}

	public List<ProductType> getProductTypesByCrop(User user, String tenant, List<String> cropCodes) {
		try {

			authToken = user.getAuthToken();

			StringBuilder cropCoderParams = new StringBuilder("?");

			for (String cropCode : cropCodes) {
				cropCoderParams.append("cropCode=").append(cropCode);
			}

			String url = String.format("%s/%s/public/v1/nitrogen/product-types-by-crop" + cropCoderParams, bancheDatiUrl, tenant);

			TypeReference<List<ProductType>> responseType = new TypeReference<>() {
			};

			return sendGetRequestWithAuth(url, responseType, "getProductTypesByCrop", tenant);

		} catch (Exception ex) {
			checkResponseStatus(null, "", tenant, "", "Error processing response for getProductTypesByCrop service", ex);
			throw new RuntimeException("Error processing response for getProductTypesByCrop service", ex);
		}
	}

	public PrecedingCropType getPrecedingCropType(User user, String tenant, int code) {
		PrecedingCropTypeKey key = new PrecedingCropTypeKey(tenant, String.valueOf(code));
		if (!precedingCropTypeCache.asMap().containsKey(key)) {
			retrievePrecedingCropTypesAndPutElementsInCache(user, tenant); // (re)load elements
		}
		return precedingCropTypeCache.asMap().get(key);
	}

	public EffluentFrequency getEffluentFrequency(User user, String tenant, String code) {
		EffluentFrequencyKey key = new EffluentFrequencyKey(tenant, code);
		if (!effluentFrequencyCache.asMap().containsKey(key)) {
			retrieveEffluentsFrequenciesAndPutElementsInCache(user, tenant); // (re)load elements
		}
		return effluentFrequencyCache.asMap().get(key);
	}

	public List<EffluentFrequency> getEffluentFrequencies(User user, String tenant, String code) {
		try {

			authToken = user.getAuthToken();

			String url = String.format("%s/%s/public/v1/effluents/%s/frequencies", bancheDatiUrl, tenant, code);
			TypeReference<List<EffluentFrequency>> responseType = new TypeReference<>() {
			};
			return sendGetRequestWithAuth(url, responseType, "getEffluentFrequencies", tenant);
		} catch (Exception ex) {
			checkResponseStatus(null, "", tenant, "", "Error processing response for getPrecedingCropType service", ex);
			throw new RuntimeException("Error processing response for getPrecedingCropType service", ex);
		}
	}

	public List<EffluentFrequency> getEffluentFrequenciesByCodes(User user, String tenant, List<String> codes) {
		try {
			authToken = user.getAuthToken();

			String url = String.format("%s/%s/public/v1/effluents/frequencies", bancheDatiUrl, tenant);

			FrequenzeCodesRequest body = new FrequenzeCodesRequest();
			body.setEffluentCodes(codes);

			TypeReference<List<EffluentFrequency>> responseType = new TypeReference<>() {
			};
			return sendPostRequestWithAuth(url, body, responseType, "getEffluentFrequencies", tenant);
		} catch (Exception ex) {
			checkResponseStatus(null, "", tenant, "", "Error processing response for getEffluentFrequencies service", ex);
			throw new RuntimeException("Error processing response for getEffluentFrequencies service", ex);
		}
	}

	/**
	 * TODO continue..
	 *
	 * public List<XXX> getXXX(User user, String tenant) {
	 * try {
	 *
	 * authToken = user.getAuthToken();
	 *
	 * String url = String.format("%s/%s/public/v1/XXX", bancheDatiUrl, tenant);
	 *
	 * TypeReference<List<AnimalHousing>> responseType = new TypeReference<>() {};
	 *
	 * return sendGetRequestWithAuth(url, responseType, "XXX", tenant);
	 *
	 * } catch (Exception ex) {
	 * checkResponseStatus(null, "", tenant, "", "Error processing response for XXX service", ex);
	 * throw new RuntimeException("Error processing response for XXX service", ex);
	 * }
	 * }
	 */

	// *** private methods

	// retrieve elements from the cache or load them when necessary
	public void retrievePrecedingCropTypesAndPutElementsInCache(User user, String tenant) {
		// loading
		List<PrecedingCropType> elements = this.retrievePrecedingCropTypesFromBancheDati(user, tenant);
		precedingCropTypeCache.cleanUp();
		elements.forEach(e -> {
			PrecedingCropTypeKey key = new PrecedingCropTypeKey(tenant, e.getCode());
			precedingCropTypeCache.put(key, e);
		});
	}

	/** Precessioni */
	private List<PrecedingCropType> retrievePrecedingCropTypesFromBancheDati(User user, String tenant) {
		try {

			authToken = user.getAuthToken();

			String url = String.format("%s/%s/public/v1/preceding-crops/types", bancheDatiUrl, tenant);

			TypeReference<List<PrecedingCropType>> responseType = new TypeReference<>() {
			};

			return sendGetRequestWithAuth(url, responseType, "getPrecedingCropType", tenant);

		} catch (Exception ex) {
			checkResponseStatus(null, "", tenant, "", "Error processing response for getPrecedingCropType service", ex);
			throw new RuntimeException("Error processing response for getPrecedingCropType service", ex);
		}
	}

	// retrieve elements from the cache or load them when necessary
	private void retrieveEffluentsFrequenciesAndPutElementsInCache(User user, String tenant) {
		List<EffluentFrequency> effluents = this.retrieveEffluentsFrequenciesFromBancheDati(user, tenant);
		effluentFrequencyCache.cleanUp();
		effluents.forEach(e -> {
			EffluentFrequencyKey key = new EffluentFrequencyKey(tenant, e.getCode());
			effluentFrequencyCache.put(key, e);
		});
	}

	/** EffluentFrequency */
	private List<EffluentFrequency> retrieveEffluentsFrequenciesFromBancheDati(User user, String tenant) {
		try {

			authToken = user.getAuthToken();

			String url = String.format("%s/%s/public/v1/effluents?filterOnceWithFrequency=true", bancheDatiUrl, tenant);

			TypeReference<List<EffluentFrequency>> responseType = new TypeReference<>() {
			};

			return sendGetRequestWithAuth(url, responseType, "effluentsFrequency", tenant);

		} catch (Exception ex) {
			checkResponseStatus(null, "", tenant, "", "Error processing response for getEffluentsFrequency service", ex);
			throw new RuntimeException("Error processing response for getEffluentsFrequency service", ex);
		}
	}

	//	public FabbisognoResponseDati getFabbisognoResponseDati(User user, String tenant, DeclOnCropsDTO payload) {
	//		try {
	//			authToken = user.getAuthToken();
	//			String url = String.format("%s/%s/public/v1/nitrogen/calculate-fabbisogno?cropCode=%s&chiaveAppezzamento=%s&"
	//							+ "tipologiaCod=%s&resa=%s&precessioneCod=%s&nFertilizzazioniPrecedenti=%s",
	//					bancheDatiUrl, tenant, (payload.getLandUseCode()), payload.getDeclCode(), NotAllowStringNullValue(payload.getTypology()),
	//					NotAllowIntegerNullValue(payload.getYield()),
	//					NotAllowIntegerNullValue(payload.getPrecessionCode()), payload.getTotResidualNumber());
	//			TypeReference<FabbisognoResponseDati> responseType = new TypeReference<>() {
	//			};
	//			return sendGetRequestWithAuth(url, responseType, "effluentsFrequency", tenant);
	//
	//		} catch (Exception ex) {
	//			checkResponseStatus(null, "", tenant, "", "Error processing response for getEffluentsFrequency service", ex);
	//			throw new RuntimeException("Error processing response for getEffluentsFrequency service", ex);
	//		}
	//	}

	public FabbisognoResponseDati getFabbisognoResponseDati(User user, String tenant, String landuseCode, String declCode, String tipology, Integer yield,
			Integer precessionCode, BigDecimal totalResidualNitrogen) {
		try {
			authToken = user.getAuthToken();
			String url = String.format("%s/%s/public/v1/nitrogen/calculate-fabbisogno?cropCode=%s&chiaveAppezzamento=%s&"
							+ "tipologiaCod=%s&resa=%s&precessioneCod=%s&nFertilizzazioniPrecedenti=%s",
					bancheDatiUrl, tenant, (landuseCode), declCode, NotAllowStringNullValue(tipology),
					NotAllowIntegerNullValue(yield),
					NotAllowIntegerNullValue(precessionCode), NotAllowBigDecimalNullValue(totalResidualNitrogen));
			TypeReference<FabbisognoResponseDati> responseType = new TypeReference<>() {
			};
			return sendGetRequestWithAuth(url, responseType, "effluentsFrequency", tenant);

		} catch (Exception ex) {
			checkResponseStatus(null, "", tenant, "", "Error processing response for getEffluentsFrequency service", ex);
			throw new RuntimeException("Error processing response for getEffluentsFrequency service", ex);
		}
	}

	public String NotAllowStringNullValue(String val) {
		if (val == null || val.isEmpty())
			return "0";
		return val;
	}

	public Integer NotAllowIntegerNullValue(Integer val) {
		if (val == null)
			return 0;
		return val;
	}

	public BigDecimal NotAllowBigDecimalNullValue(BigDecimal val) {
		if (val == null)
			return BigDecimal.ZERO;
		return val;
	}

}
