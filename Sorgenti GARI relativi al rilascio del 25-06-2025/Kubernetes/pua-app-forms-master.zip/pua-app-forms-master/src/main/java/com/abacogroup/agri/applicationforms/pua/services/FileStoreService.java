package com.abacogroup.agri.applicationforms.pua.services;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.text.MessageFormat;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.Future;

import com.abacogroup.agri.applicationforms.pua.core.exceptions.FileStoreIORuntimeException;
import com.abacogroup.agri.applicationforms.pua.core.exceptions.FileStoreMetadataNotFoundException;
import com.abacogroup.agri.applicationforms.pua.core.model.dto.FileDTO;
import com.abacogroup.agri.applicationforms.pua.core.model.dto.SavedFileDTO;
import com.abacogroup.dropwizard.auth.sso2.Sso2Client;
import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.dynamicdocuments.files.FileStoreSupport;
import com.abacogroup.filestore.client.FileStoreClient;
import com.abacogroup.filestore.client.auth.Authenticator;
import com.abacogroup.filestore.client.auth.Sso2Authenticator;
import com.abacogroup.filestore.client.request.FileToAddMetadata;
import com.abacogroup.filestore.client.response.AddFileResponse;
import com.abacogroup.filestore.client.response.FileMetadata;

import io.dropwizard.auth.AuthenticationException;
import jakarta.ws.rs.core.Response;
import lombok.extern.slf4j.Slf4j;

/**
 * @author Mauro Pozzana
 * @author Alexandru Paraschiv
 */
@Slf4j
public class FileStoreService implements FileStoreSupport {

	private static final String APP_OCTET_STREAM_MIME_TYPE = "application/octet-stream";
	private final FileStoreClient fileStoreClient;

	private final Sso2Client sso2Client;

	public FileStoreService(FileStoreClient fileStoreClient, Sso2Client sso2Client) {
		this.fileStoreClient = fileStoreClient;
		this.sso2Client = sso2Client;
	}

	public FileDTO getFile(String tenantId, String fileId, String bucketId, User user, Authenticator authenticator) throws FileStoreMetadataNotFoundException {

		ByteArrayOutputStream outputStream = new ByteArrayOutputStream();

		FileMetadata fileMetadata = null;


		try {
			fileMetadata = fileStoreClient.getFileMetadata(authenticator, tenantId, bucketId, fileId);
			fileStoreClient.getFileContent(authenticator, tenantId, bucketId, fileId, outputStream);
		} catch (IOException e) {
			throw new FileStoreIORuntimeException(e.getMessage());
		}

		if (Optional.ofNullable(fileMetadata).isEmpty()) {
			throw new FileStoreMetadataNotFoundException(MessageFormat.format(
					"File metadata not found for user: {0} tenant: {1} fileId: {2} bucketId: {3}",
					user.getName(), tenantId, fileId, bucketId));
		}

		byte[] content = outputStream.toByteArray();
		return FileDTO.builder()
				.name(fileMetadata.getName())
				.id(fileId)
				.bucketId(bucketId)
				.content(content)
				.build();
	}

	public Response getFileForDownload(String tenantId, String fileId, String bucketId, User user, Authenticator authenticator) {
		log.info("getFileForDownload from file store started with tenantId: {} fileId: {} bucketId: {} username: {}",
				tenantId, fileId, bucketId, user.getName());
		try {
			return fileStoreClient.jaxrs().proxyFileResponse(authenticator, tenantId, bucketId, fileId);
		} catch (IOException e) {
			throw new FileStoreIORuntimeException("Cannot retrieve file");
		} finally {
			log.info("getFileForDownload from File Store ended");
		}
	}

	public Response getFileForHead(String tenantId, String fileId, String bucketId, User user, Authenticator authenticator) {
		log.info("getFileForDownload from file store started with tenantId: {} fileId: {} bucketId: {} username: {}",
				tenantId, fileId, bucketId, user.getName());
		try {
			return fileStoreClient.jaxrs().proxyHeaderResponse(authenticator, tenantId, bucketId, fileId);
		} catch (IOException e) {
			throw new FileStoreIORuntimeException("Cannot retrieve file");
		} finally {
			log.info("getFileForDownload from File Store ended");
		}
	}

	public SavedFileDTO saveFile(String tenantId, String bucketId, InputStream inputStream, String fileName, User user,
								 Authenticator authenticator) {
		log.info("Saving file to File Store with tenantId: {} bucketId: {} fileName: {} username: {}",
				tenantId, bucketId, fileName, user.getName());
		FileToAddMetadata fileToAddMetadata = new FileToAddMetadata(fileName, APP_OCTET_STREAM_MIME_TYPE);
		AddFileResponse response = null;
		try {
			response = fileStoreClient.addFile(authenticator, tenantId, bucketId, fileToAddMetadata, inputStream);
		} catch (IOException e) {
			throw new FileStoreIORuntimeException("Cannot add file");
		}
		log.info("Successfully saved file to File Store with id {}", response.getId());

		return SavedFileDTO.builder()
				.fileId(response.getId())
				.build();
	}

	public void deleteFile(String tenantId, String fileId, String bucketId, User user) {
		log.info("deleting file on file server with user: {} tenant: {} fileId: {} bucketId: {}",
				user.getName(), tenantId, fileId, bucketId);
		log.warn("Skipping attachment deletion on File Store: functionality not supported");
	}

	@Override
	public List<Future<Void>> makePermanentAsync(String tenant, String userId, String filesBucket, List<String> fileIdList) {
		return Optional.ofNullable(fileIdList).orElseGet(Collections::emptyList)
				.stream()
				.map(fileId -> {
					try {
						var sc = sso2Client.createSecurityContextFromUserId(tenant, userId);
						var user = (User) sc.getUserPrincipal();
						return fileStoreClient.makePermanentAsync(new Sso2Authenticator(user), tenant, filesBucket, fileId);
					} catch (AuthenticationException e) {
						throw new RuntimeException(e);
					}
				})
				.toList();
	}
}
