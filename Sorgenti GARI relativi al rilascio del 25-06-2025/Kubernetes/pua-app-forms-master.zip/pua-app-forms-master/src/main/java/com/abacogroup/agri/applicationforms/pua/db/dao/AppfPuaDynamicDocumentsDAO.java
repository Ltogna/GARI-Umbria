package com.abacogroup.agri.applicationforms.pua.db.dao;

import java.util.List;

import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.customizer.BindBean;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;

import com.abacogroup.agri.applicationforms.pua.db.ntt.AppfPuaDynamicDocumentsNTT;

/**
 * @author Alexandru Paraschiv
 */
public interface AppfPuaDynamicDocumentsDAO extends IGenericPuaDAO<AppfPuaDynamicDocumentsNTT, Long> {

	@Override
	@SqlQuery("§select_nextval(appfpua_dynamic_documents_id_seq)§")
	Long nextSequenceVal();

	@Override
	@SqlUpdate("INSERT INTO appfpua_dynamic_documents " +
			"( id," +
			" application_id," +
			" document_id," +
			" document_code," +
			" takeover_id)" +
			" VALUES(:id, :application_id, :document_id, :document_code, :takeover_id)")
	void insert(@BindBean AppfPuaDynamicDocumentsNTT ntt);

	@SqlQuery("select " +
			" id, " +
			" application_id, " +
			" takeover_id, " +
			" document_id, " +
			" document_code" +
			" FROM appfpua_dynamic_documents " +
			" WHERE id = :id ")
	@RegisterBeanMapper(AppfPuaDynamicDocumentsNTT.class)
	List<AppfPuaDynamicDocumentsNTT> findById(@Bind("id") Long id);

	@SqlQuery("select " +
			" id, " +
			" application_id, " +
			" takeover_id, " +
			" document_id, " +
			" document_code" +
			" FROM appfpua_dynamic_documents " +
			" WHERE application_id = :application_id")
	@RegisterBeanMapper(AppfPuaDynamicDocumentsNTT.class)
	List<com.abacogroup.agri.applicationforms.pua.db.ntt.AppfPuaDynamicDocumentsNTT> findByApplicationId(@Bind("application_id") Long applicationId);

	@SqlQuery("select " +
			" id, " +
			" application_id, " +
			" takeover_id, " +
			" document_id, " +
			" document_code" +
			" FROM appfpua_dynamic_documents " +
			" WHERE application_id = :application_id" +
			" AND document_code = :document_code ")
	@RegisterBeanMapper(AppfPuaDynamicDocumentsNTT.class)
	List<AppfPuaDynamicDocumentsNTT> findByApplicationIdAndDocumentCode(@Bind("application_id") Long applicationId, @Bind("document_code") String documentCode);

	@SqlQuery("select " +
			" id, " +
			" application_id, " +
			" takeover_id, " +
			" document_id, " +
			" document_code" +
			" FROM appfpua_dynamic_documents " +
			" WHERE application_id = :application_id" +
			" AND document_code = :document_code " +
			" AND ((:takeover_id IS NULL AND takeover_id IS NULL) OR takeover_id = :takeover_id)")
	@RegisterBeanMapper(AppfPuaDynamicDocumentsNTT.class)
	List<AppfPuaDynamicDocumentsNTT> findByApplicationIdAndDocumentCodeAndTakeoverId(@Bind("application_id") Long applicationId, @Bind("document_code") String documentCode,
																				  @Bind("takeover_id") Long takeoverId);

	@SqlUpdate("DELETE FROM appfpua_dynamic_documents a " +
			" WHERE a.application_id = :application_id " +
			" AND a.document_id = :document_id " +
			" AND takeover_id is null")
	void deleteByApplicationIdAndDocumentId(@Bind("application_id") Long applicationId, @Bind("document_id") Long documentId);

	@SqlUpdate("DELETE FROM appfpua_dynamic_documents a " +
			" WHERE a.application_id = :application_id " +
			" AND a.document_id = :document_id " +
			" AND ((:takeover_id IS NULL AND takeover_id IS NULL) OR takeover_id = :takeover_id)")
	void deleteByApplicationIdAndDocumentIdAndTakeoverId(@Bind("application_id") Long applicationId, @Bind("document_id") Long documentId,
														@Bind("takeover_id") Long takeoverId);

	@SqlUpdate("DELETE FROM appfpua_dynamic_documents a " +
			" WHERE a.application_id = :application_id " +
			" AND a.document_code = :document_code")
	void deleteByApplicationIdAndDocumentCode(@Bind("application_id") Long applicationId, @Bind("document_code") String documentCode);

	@SqlUpdate("DELETE FROM appfpua_dynamic_documents a " +
			" WHERE a.application_id = :application_id " +
			" AND a.document_code = :document_code " +
			" AND ((:takeover_id IS NULL AND takeover_id IS NULL) OR takeover_id = :takeover_id)")
	void deleteByApplicationIdAndDocumentCodeAndTakeoverId(@Bind("application_id") Long applicationId, @Bind("document_code") String documentCode,
														   @Bind("takeover_id") Long takeoverId);

	@SqlUpdate("update appfpua_dynamic_documents " +
			"SET application_id = :application_id," +
			"document_id = :document_id, " +
			"document_code = :document_code, " +
			"takeover_id = :takeover_id " +
			"WHERE id = :id ")
	@Override
	void update(@BindBean AppfPuaDynamicDocumentsNTT rs);
}
