package com.abacogroup.agri.applicationforms.pua.bundles.model.effluenttype;

import java.util.ArrayList;
import java.util.List;

import com.abacogroup.agri.applicationforms.pua.core.model.dto.EffluentDTO;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 
 * @author Emanuele Crocilla
 *
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class BundleEffluentTypesMessage {
	@Builder.Default
	private List<EffluentDTO> effluentTypes = new ArrayList<>();
}
