package com.abacogroup.agri.applicationforms.pua.core.model.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.math.BigDecimal;
import java.time.OffsetDateTime;
import java.util.List;

/**
 * @author Emanuele Crocilla
 */
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
@Schema(description = "The Declaration On Sectors DTO")
public class DeclOnCropsDTO {

	@Schema(description = "The declaration id's")
	@JsonProperty("ids")
	private List<Long> ids;

	@JsonProperty(access = JsonProperty.Access.READ_ONLY)
	@Schema(description = "The application id")
	private Long applicationId;

	@Schema(description = "The plan id")
	private Long planId;

	@Schema(description = "The plot code")
	private String plotCode;
	
	@Schema(description = "the Plot Description")
	private String plotDescription;

	@Schema(description = "The declaration code")
	private String declCode;

	@Schema(description = "The version")
	private String declarationVersion;

	@Schema(description = "The land use code")
	private String landUseCode;

	@Schema(description = "The fl zvn")
	private boolean flZvn;

	@Schema(description = "The area sqm")
	private Integer areaSqm;

	@Schema(description = "The crop duration")
	private String cropDuration;

	@Schema(description = "The plant status")
	private String plantStatus;

	@Schema(description = "The cycle")
	@Builder.Default
	private Integer cycle = 0;

	@Schema(description = "The typology")
	private String typology;
	// Removed from last implementation
	//    @Schema(description = "The yield reference")
	//    private Integer yieldReference;

	@Schema(description = "The yield")
	private Integer yield;

	@Schema(description = "The mas")
	private Integer mas;

	@Schema(description = "The precession code")
	private Integer precessionCode;

	@Schema(description = "The precession code")
	private String precessionDescription;

	@Schema(description = "The total residual Nitrogen")
	private BigDecimal totResidualNitrogen;

	@Schema(description = "The distributable Nitrogen")
	private BigDecimal distributableNitrogen;

	@Schema(description = "The total nitrogen")
	private BigDecimal totalNitrogen;

	@Schema(description = "Sector Code")
	private String sectorCode;

	@Schema(description = "The previous effluents")
	private List<DeclOnCropsPrevEffluentsDTO> previousEffluents;

	@Schema(description = "The insert date")
	@JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ssXXX")
	@JsonProperty(access = JsonProperty.Access.READ_ONLY)
	private OffsetDateTime dtInsert;

	@Schema(description = "The deleted date")
	@JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ssXXX")
	@JsonProperty(access = JsonProperty.Access.READ_ONLY)
	private OffsetDateTime dtDelete;

	@Schema(description = "The user id which inserted ")
	@JsonProperty(access = JsonProperty.Access.READ_ONLY)
	private String userIdInsert;

	@Schema(description = "The user id which deleted ")
	@JsonProperty(access = JsonProperty.Access.READ_ONLY)
	private String userIdDelete;
	
	public void setCycle(Integer cycle) {
		this.cycle = (cycle == null || cycle.intValue() < 0) ? 0 : cycle;
	}

}
