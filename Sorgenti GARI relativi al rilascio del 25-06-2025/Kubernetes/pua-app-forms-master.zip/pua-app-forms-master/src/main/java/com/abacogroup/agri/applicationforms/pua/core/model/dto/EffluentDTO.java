package com.abacogroup.agri.applicationforms.pua.core.model.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

/**
 * DTO for effluents
 * 
 * @author Emanuele Crocilla
 *
 */
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
@Schema(description = "The Effluent DTO")
public class EffluentDTO {
    
    @Schema(description = "The category code")
    private String categoryCode;

    @Schema(description = "The fertilizer category")
    private String fertilizerCategory;

    @Schema(description = "The type code")
    private String typeCode;

    @Schema(description = "The fertilizer type description")
    private String fertilizerType;
 
}
