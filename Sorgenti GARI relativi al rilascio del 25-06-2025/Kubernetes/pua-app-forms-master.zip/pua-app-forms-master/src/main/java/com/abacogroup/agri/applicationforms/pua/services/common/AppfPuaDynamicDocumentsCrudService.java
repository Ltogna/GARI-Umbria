package com.abacogroup.agri.applicationforms.pua.services.common;

import java.util.List;
import java.util.Optional;

import com.abacogroup.agri.applicationforms.pua.core.mappers.AppfPuaDynamicDocumentsMapper;
import com.abacogroup.agri.applicationforms.pua.core.model.dto.AppfPuaDynamicDocumentsDTO;
import com.abacogroup.agri.applicationforms.pua.db.dao.AppfPuaDynamicDocumentsDAO;
import com.abacogroup.agri.applicationforms.pua.db.ntt.AppfPuaDynamicDocumentsNTT;
//import com.abacogroup.agri.applicationforms.core.mappers.AppfPuaDynamicDocumentsMapper;
//import com.abacogroup.agri.applicationforms.core.model.dto.AppfPuaDynamicDocumentsDTO;
//import com.abacogroup.agri.applicationforms.db.dao.AppfPuaDynamicDocumentsDAO;
//import com.abacogroup.agri.applicationforms.db.ntt.AppfPuaDynamicDocumentsNTT;
import com.abacogroup.agri.applicationforms.pua.services.common.crud.AbstractCrudService;
import com.abacogroup.agri.applicationforms.pua.util.GenericUtility;

import lombok.extern.slf4j.Slf4j;

/**
 * @author Alexandru Paraschiv
 */
@Slf4j
public class AppfPuaDynamicDocumentsCrudService
		extends AbstractCrudService<AppfPuaDynamicDocumentsNTT, Long, AppfPuaDynamicDocumentsDTO, AppfPuaDynamicDocumentsMapper, Void, AppfPuaDynamicDocumentsDAO> {

	public static final String DEFAULT_DECLARATIONS_DOC_CODE = "DECLARATIONS_DOC_1";

	public AppfPuaDynamicDocumentsCrudService(AppfPuaDynamicDocumentsDAO dao, AppfPuaDynamicDocumentsMapper mapper) {
		super(dao, mapper);
	}

	@Override
	protected boolean hasPrimaryKey() {
		return true;
	}

	@Override
	protected Optional<AppfPuaDynamicDocumentsNTT> findRsByCustomKey(Void customKey) {
		return Optional.empty();
	}

	@Override protected void deleteByCustomKey(Void customKey) {
		throw GenericUtility.throwNotImplementedException.get();
	}

	@Override protected void setCustomSearchKey(AppfPuaDynamicDocumentsNTT rs, Void customKey) {
		throw GenericUtility.throwNotImplementedException.get();
	}

	public Optional<AppfPuaDynamicDocumentsDTO> findById(Long machineryId) {
		return returnOptionalRecord(dao.findById(machineryId));
	}

	public AppfPuaDynamicDocumentsDTO insert(AppfPuaDynamicDocumentsDTO in) {
		log.info("Invoking insert with params in: {}", in);
		return this.insert(in, null);
	}

	public AppfPuaDynamicDocumentsDTO update(Long key, AppfPuaDynamicDocumentsDTO in) {
		log.info("Invoking update with params key: {} in: {}", key, in);
		return this.update(key, in, null);
	}

	public void deleteByApplicationIdAndDocumentId(Long applicationId, Long documentId) {
		log.info("Invoking deleteByApplicationIdAndDocumentId with params applicationId: {} documentId: {}", applicationId, documentId);
		dao.deleteByApplicationIdAndDocumentId(applicationId, documentId);
	}

	public void deleteByApplicationIdAndDocumentIdAndTakeoverId(Long applicationId, Long documentId, Long takeoverId) {
		dao.deleteByApplicationIdAndDocumentIdAndTakeoverId(applicationId, documentId, takeoverId);
	}

	public void deleteByApplicationIdAndDocumentCode(Long applicationId, String documentCode) {
		log.info("Invoking deleteByApplicationIdAndDocumentCode with params applicationId: {} documentCode: {}", applicationId, documentCode);
		dao.deleteByApplicationIdAndDocumentCode(applicationId, documentCode);
	}

	public void deleteByApplicationIdAndDocumentCodeAndTakeoverId(Long applicationId, String documentCode, Long takeoverId) {
		dao.deleteByApplicationIdAndDocumentCodeAndTakeoverId(applicationId, documentCode, takeoverId);
	}


	public void delete(Long key) {
		log.info("Invoking delete with params key: {}", key);
		this.delete(key, null);
	}

	public List<AppfPuaDynamicDocumentsDTO> findByApplicationId(Long applicationId) {
		return this.dao.findByApplicationId(applicationId).stream()
				.map(mapper::entityToDto)
				.toList();
	}

	public AppfPuaDynamicDocumentsDTO findByApplicationIdAndDocumentCode(Long applicationId, String documentCode) {
		return this.dao.findByApplicationIdAndDocumentCode(applicationId, documentCode).stream()
				.findFirst()
				.map(mapper::entityToDto)
				.orElse(null);
	}

	public AppfPuaDynamicDocumentsDTO findByApplicationIdAndDocumentCodeAndTakeoverId(Long applicationId, String documentCode, Long takeoverId) {
		return this.dao.findByApplicationIdAndDocumentCodeAndTakeoverId(applicationId, documentCode, takeoverId).stream()
				.findFirst()
				.map(mapper::entityToDto)
				.orElse(null);
	}
}
