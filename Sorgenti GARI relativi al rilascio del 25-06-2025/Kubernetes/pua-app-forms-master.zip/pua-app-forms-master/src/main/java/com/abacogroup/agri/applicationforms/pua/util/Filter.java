package com.abacogroup.agri.applicationforms.pua.util;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import com.abacogroup.jdbi.criteria.Criteria;
import com.abacogroup.jdbi.orderby.OrderBy;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 
 * @author Emanuele Crocilla
 *
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Filter {
	
	private Collection<FilterParam> params; 
	private OrderBy orderBy; 

	public String convertFromJavaNameToDbName(String javaName) {
		
		var res = params
				.stream()
				.filter(x -> x.getJavaName().equals(javaName))
				.findFirst()
				.orElse(null);
		 
		return res != null ? res.getDbName() : null;
	}
	
	public Criteria[] getAllParametersCriterias() {
		// Set the criteria and ordering
		List<Criteria> criterias = new ArrayList<>();

		params.forEach(filterParam -> {
			if (null != filterParam.getCriteria()) {
				criterias.add(filterParam.getCriteria());
			}
		});

		return criterias.toArray(new Criteria[criterias.size()]);
	}
	
	public boolean contaninsParam(String javaName) {
		var res = params
				.stream()
				.filter(x -> x.getJavaName().equals(javaName))
				.findFirst()
				.orElse(null);
		 
		return res != null;
	}
}
