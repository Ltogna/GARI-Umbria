package com.abacogroup.agri.applicationforms.pua.services;

import org.apache.commons.io.FilenameUtils;
import org.glassfish.jersey.media.multipart.FormDataContentDisposition;

import com.abacogroup.agri.applicationforms.pua.core.exceptions.FileNotPermittedRuntimeException;
import com.abacogroup.agri.applicationforms.pua.core.model.FilePermittedEnum;

import lombok.extern.slf4j.Slf4j;

/**
 * @author Gennaro Tamburrelli
 */
@Slf4j
public class FileCheckerService {

    //TODO add logic to retrieve permitted file extensions

    public void checkFileExtension(FormDataContentDisposition fileMetadata) {
        final String fileExtension = FilenameUtils.getExtension(fileMetadata.getFileName());

        if (!FilePermittedEnum.isValid(fileExtension))
            throw new FileNotPermittedRuntimeException(String.format("File %s not permitted", fileMetadata.getFileName()));

    }

}
