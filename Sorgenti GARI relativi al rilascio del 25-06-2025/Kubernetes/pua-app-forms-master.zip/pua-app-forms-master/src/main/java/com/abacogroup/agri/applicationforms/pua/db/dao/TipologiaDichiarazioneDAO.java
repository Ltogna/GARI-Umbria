package com.abacogroup.agri.applicationforms.pua.db.dao;

import java.time.Instant;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.util.Calendar;
import java.util.List;

import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.customizer.BindBean;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;

import com.abacogroup.agri.applicationforms.pua.core.exceptions.ObjectNotFoundRuntimeException;
import com.abacogroup.agri.applicationforms.pua.db.ntt.TipologiaDichiarazioneNTT;

/**
 * 
 * @author Emanuele Crocilla
 *
 */
public interface TipologiaDichiarazioneDAO extends IGenericPuaDAO<TipologiaDichiarazioneNTT, Long> {

    @SqlQuery("select * from appfpua_declaration_type where application_id = :application_id and dt_delete > §current_timestamp§ ")
    @RegisterBeanMapper(TipologiaDichiarazioneNTT.class)
    TipologiaDichiarazioneNTT getByApplicationId(@Bind("application_id") Long applicationId);
    
    @SqlQuery("select * from appfpua_declaration_type where year = :year")
    @RegisterBeanMapper(TipologiaDichiarazioneNTT.class)
    List<TipologiaDichiarazioneNTT> getByYear(@Bind("year") Integer year);
    
    @SqlQuery("select * from appfpua_declaration_type where pkid = :pkid")
    @RegisterBeanMapper(TipologiaDichiarazioneNTT.class)
    TipologiaDichiarazioneNTT getById(@Bind("pkid") Long pkid);

    @Override
    @SqlUpdate("""
                INSERT INTO appfpua_declaration_type 
                (application_id, "year", fl_organic_fert, fl_livestocks, dt_insert, dt_delete, user_id_insert, user_id_delete) 
                VALUES(:applicationId, :year, :flOrganicFert, :flLivestocks, :dtInsert, :dtDelete, :userIdInsert, :userIdDelete);
            """)
    void insert(@BindBean TipologiaDichiarazioneNTT ntt);

    @SqlUpdate("""
            update appfpua_declaration_type
               set dt_delete=:dtDelete,
                   user_id_delete = :userIdDelete
             where application_id=:applicationId
               and §current_timestamp§ between dt_insert and dt_delete
            """)
    void expire(@BindBean TipologiaDichiarazioneNTT ntt);

    default void upsert(TipologiaDichiarazioneNTT ntt) {
    	
    	/**
    	 * 
    	  pkid    | app id    | year  | dt_insert             | dt_delete
		  1 		123         2024    12/11/2024 11:30        12/11/2024 11:30:28
		  2			123         2025    12/11/2024 11:30:29     31/12/9999
    	 * 
    	 */
    	
    	TipologiaDichiarazioneNTT nttExpired = getByApplicationId(ntt.getApplicationId()); // Cloner.clone(ntt);
    	
    	if (nttExpired != null) {
			
    		long rightNow = Calendar.getInstance().getTimeInMillis();
        	long rightNowMinusAMillis = rightNow-1;
        	
        	Instant instantRightNow = Instant.ofEpochMilli(rightNow);
        	Instant instantMinusAMillis = Instant.ofEpochMilli(rightNowMinusAMillis);
        	
        	OffsetDateTime dateTimeRightNow = instantRightNow.atOffset(ZoneOffset.UTC);
        	OffsetDateTime dateTimeMinusAMillis = instantMinusAMillis.atOffset(ZoneOffset.UTC);

        	nttExpired.setDtDelete(dateTimeMinusAMillis);
        	ntt.setDtInsert(dateTimeRightNow);

        	nttExpired.setUserIdDelete(ntt.getUserIdInsert());
        	
            useTransaction(dao -> {
            	((TipologiaDichiarazioneDAO)dao).expire(nttExpired);
            	((TipologiaDichiarazioneDAO)dao).insert(ntt);
            });
    		
		}
    	else {
    		
    		throw new ObjectNotFoundRuntimeException("Unable to find application id = " + ntt.getApplicationId());
    	}
    }
    
    @Override
    @SqlQuery("SELECT * FROM appfpua_declaration_type a WHERE a.pkid = :pkid")
    @RegisterBeanMapper(TipologiaDichiarazioneNTT.class)
    List<TipologiaDichiarazioneNTT> findById(@Bind("pkid") Long id);

	boolean getOrNull(TipologiaDichiarazioneNTT tipologiaDichiarazione);
    
    
    
}
