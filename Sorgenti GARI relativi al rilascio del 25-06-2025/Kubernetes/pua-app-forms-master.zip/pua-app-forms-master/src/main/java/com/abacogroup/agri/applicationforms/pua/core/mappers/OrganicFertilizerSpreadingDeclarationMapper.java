package com.abacogroup.agri.applicationforms.pua.core.mappers;

import java.math.BigDecimal;
import java.math.RoundingMode;

import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;
import org.mapstruct.factory.Mappers;

import com.abacogroup.agri.applicationforms.pua.core.model.dto.OrganicFertilizerSpreadingDeclarationDTO;
import com.abacogroup.agri.applicationforms.pua.db.ntt.OrganicFertilizerSpreadingDeclarationNTT;
import com.abacogroup.jdbi.mapper.AbsoluteDateMapper;

/**
 * 
 * @author Emanuele Crocilla
 *
 */
@Mapper(uses = AbsoluteDateMapper.class)
public interface OrganicFertilizerSpreadingDeclarationMapper extends EntityMapper<OrganicFertilizerSpreadingDeclarationDTO, OrganicFertilizerSpreadingDeclarationNTT> {

	OrganicFertilizerSpreadingDeclarationMapper INSTANCE = Mappers.getMapper(OrganicFertilizerSpreadingDeclarationMapper.class);

	@InheritInverseConfiguration()
	OrganicFertilizerSpreadingDeclarationDTO entityToDto(OrganicFertilizerSpreadingDeclarationNTT entity);

	@Mapping(source = "livestockEffluentsQty", target = "livestockEffluentsQty", qualifiedByName = "truncateToFourDecimals")
	OrganicFertilizerSpreadingDeclarationNTT dtoToEntity(OrganicFertilizerSpreadingDeclarationDTO dto);

	@Named("truncateToFourDecimals")
	default BigDecimal truncateToFourDecimals(BigDecimal in) {
		return in.setScale(4, RoundingMode.DOWN);

	}
}
