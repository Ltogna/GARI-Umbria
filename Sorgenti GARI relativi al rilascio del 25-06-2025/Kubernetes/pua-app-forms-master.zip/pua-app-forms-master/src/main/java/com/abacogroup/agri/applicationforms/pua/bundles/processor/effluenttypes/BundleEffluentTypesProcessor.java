package com.abacogroup.agri.applicationforms.pua.bundles.processor.effluenttypes;

import java.nio.file.Path;

import org.jdbi.v3.core.Jdbi;

import com.abacogroup.agri.applicationforms.pua.bundles.model.effluenttype.BundleEffluentTypesMessage;
import com.abacogroup.agri.applicationforms.pua.bundles.processor.AbstractBundleApplicationFormsProcessor;
import com.abacogroup.bundles.listener.configdata.ConfigDataMessage;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.extern.slf4j.Slf4j;

/**
 * 
 * @author Emanuele Crocilla
 *
 */
@Slf4j
public class BundleEffluentTypesProcessor extends AbstractBundleApplicationFormsProcessor<BundleEffluentTypesMessage> {

	protected final EffluentTypesBundleWorker effluentTypesBundleWorker;

	public BundleEffluentTypesProcessor(ObjectMapper objectMapper, EffluentTypesBundleWorker effluentTypesBundleWorker, Jdbi jdbi) {
		super(objectMapper, jdbi);
		this.effluentTypesBundleWorker = effluentTypesBundleWorker;
	}

	@Override
	public String getDomainName() {
		return "effluent-types";
	}

	@Override
	protected TypeReference<BundleEffluentTypesMessage> getTypeReference() {
		return new TypeReference<BundleEffluentTypesMessage>() {
		};
	}

	@Override
	public void onMessageInTransaction(ConfigDataMessage message) {
		log.info("BundleEffluentTypesProcessor: proccessing file with tenant {}", message.getTenantId());
		message.getConfigFiles().stream()
				.map(Path::toFile)
				.filter(file -> file.getAbsolutePath().endsWith(".json"))
				.forEach(file -> processFile(message.getTenantId(), file));
	}

	@Override
	protected void delete(String tenantId, BundleEffluentTypesMessage message) {
		effluentTypesBundleWorker.delete(tenantId, message.getEffluentTypes());
	}

	@Override
	protected void doInsertOrUpdate(String tenantId, BundleEffluentTypesMessage message) {
		effluentTypesBundleWorker.upsert(tenantId, message);
	}

}
