package com.abacogroup.agri.applicationforms.pua.core.model.dto;

import java.math.BigDecimal;
import java.time.OffsetDateTime;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

/**
 * @author Emanuele Crocilla
 */
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
@Schema(description = "The Organic Fertilizer Spreading Declaration LandUse DTO")
public class OrganicFertilizerSpreadingDeclarationLanduseDTO {

	@Schema(description = "The entity pkid")
	@JsonIgnore
	@JsonProperty(access = JsonProperty.Access.READ_ONLY)
	private Long pkid;

	@Schema(description = "The parent id")
	@JsonIgnore
	@JsonProperty(access = JsonProperty.Access.READ_ONLY)
	private Long appfpuaOrganicFertSpreadingDeclarationPkid;

    @Schema(description = "The plot")
    private String plotId;

    @Schema(description = "The declaration code")
    private String declarationCode;

    @Schema(description = "The Plot Description")
    private String plotDescription;

    @Schema(description = "The landuse code")
    private String landUseCode;
    
    @Schema(description = "The landuse description")
	private String landUseDescription;
    
    @Schema(description = "The plot area in suqade meters code")
	private Integer plotAreaSqm;
    
    @Schema(description = "The plot area percentage")
	private Double plotAreaPerc;
    
    @Schema(description = "The plot total in hectar")
	private BigDecimal plotTotalHectar;
	
	@Schema(description = "The insert date")
	@JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ssXXX")
	@JsonProperty(access = JsonProperty.Access.READ_ONLY)
	private OffsetDateTime dtInsert;

	@Schema(description = "The deleted date")
	@JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ssXXX")
	@JsonProperty(access = JsonProperty.Access.READ_ONLY)
	private OffsetDateTime dtDelete;

	@Schema(description = "The user id which inserted ")
	@JsonProperty(access = JsonProperty.Access.READ_ONLY)
	private String userIdInsert;

	@Schema(description = "The user id which deleted ")
	@JsonProperty(access = JsonProperty.Access.READ_ONLY)
	private String userIdDelete;

}
