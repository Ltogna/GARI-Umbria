package com.abacogroup.agri.applicationforms.pua.db.ntt;

import java.util.Optional;

import com.abacogroup.agri.applicationforms.pua.db.ntt.applications.IIdRs;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author Alexandru Paraschiv
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AppfPuaDynamicDocumentsNTT implements IIdRs<Long> {

	private Long id;
	private Long application_id;
	private Long document_id;
	private String document_code;
	private Long takeover_id;

	@Override
	public Optional<Long> getKey() {
		return Optional.ofNullable(getId());
	}

	@Override
	public void setKey(Long id) {
		setId(id);
	}
}
