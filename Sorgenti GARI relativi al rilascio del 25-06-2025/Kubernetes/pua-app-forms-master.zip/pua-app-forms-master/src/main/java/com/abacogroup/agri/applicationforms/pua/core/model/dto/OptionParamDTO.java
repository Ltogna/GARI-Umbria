package com.abacogroup.agri.applicationforms.pua.core.model.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author Mattia Perini
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class OptionParamDTO {

	@Schema(description = "The related option configuration id")
	private Long optionConfigId;
	@Schema(description = "The attribute name")
	private String attributeName;
	@Schema(description = "The attribute value")
	private String attributeValue;

}
