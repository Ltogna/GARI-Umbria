package com.abacogroup.agri.applicationforms.pua.core.model.dto;

import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author Mauro Pozzana
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AttachmentPublicDTO {
	private String attachmentId;
	private Long applicationId;
	private AttachmentTypePublicDTO type;
	private String fileName;
	private String notes;
	private LocalDateTime dtInsert;
	@JsonIgnore
	private Long typeId;
	@JsonIgnore
	private String typeCode;
	@JsonIgnore
	private String typeAttachmentGroupCode;
	@JsonIgnore
	private String typeAttachmentCode;
	@JsonIgnore
	private String tenantId;
}
