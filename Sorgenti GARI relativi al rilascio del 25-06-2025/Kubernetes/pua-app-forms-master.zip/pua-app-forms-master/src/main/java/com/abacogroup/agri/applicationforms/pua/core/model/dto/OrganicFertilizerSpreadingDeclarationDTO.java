package com.abacogroup.agri.applicationforms.pua.core.model.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.time.OffsetDateTime;
import java.util.Collection;

/**
 * @author Emanuele Crocilla
 */
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
@Schema(description = "The Organic Fertilizer Spreading Declaration DTO")
public class OrganicFertilizerSpreadingDeclarationDTO {

	@JsonIgnore
	@JsonProperty(access = JsonProperty.Access.READ_ONLY)
	@Schema(description = "The pkid")
	private Long pkid;

	@JsonIgnore
	@JsonProperty(access = JsonProperty.Access.READ_ONLY)
	@Schema(description = "The application id")
	private Long applicationId;

	@Schema(description = "The declaration id")
	private Long id;

	@Schema(description = "The party code (cuaa)")
	private String cuaa;

	@Schema(description = "The company name")
	private String company;

	@Schema(description = "The party id")
	private Long partyId;

	@Schema(description = "The expected date (format: yyyyMMdd)")
	private String expectedDate;

	@Schema(description = "The livestock effluents")
	private String livestockEffluents;

	@Schema(description = "The quantity of livestock effluents")
	private Double livestockEffluentsQty;

	@Schema(description = "unit of measure for livestockEffluentsQty")
	private String livestockEffluentsCodeUom;

	@Schema(description = "unit of measure for livestockEffluentsQty")
	private String livestockEffluentsDescriptionUom;

	@Schema(description = "giasFertilizerCode")
	private String giasFertilizerCode;
    
	@Schema(description = "The crop plan version")
	private String cropPlanVersion;

	@Schema(description = "The sector code")
	private String sectorCode;

	private Collection<OrganicFertilizerSpreadingDeclarationLanduseDTO> landuses;

	@Schema(description = "The insert date")
	@JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ssXXX")
	@JsonProperty(access = JsonProperty.Access.READ_ONLY)
	private OffsetDateTime dtInsert;

	@Schema(description = "The logical deletion date")
	@JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ssXXX")
	@JsonProperty(access = JsonProperty.Access.READ_ONLY)
	private OffsetDateTime dtDelete;

	@Schema(description = "The user id which inserted this record")
	@JsonProperty(access = JsonProperty.Access.READ_ONLY)
	private String userIdInsert;

	@Schema(description = "The user id which deleted this record")
	@JsonProperty(access = JsonProperty.Access.READ_ONLY)
	private String userIdDelete;

}
