package com.abacogroup.agri.applicationforms.pua.core.model.dto.enums;
 
public enum OptionTypeEnum {

	SURFACE,
	ZOOTECHNIC,
	BREEDING,
	CATTLE;

}
