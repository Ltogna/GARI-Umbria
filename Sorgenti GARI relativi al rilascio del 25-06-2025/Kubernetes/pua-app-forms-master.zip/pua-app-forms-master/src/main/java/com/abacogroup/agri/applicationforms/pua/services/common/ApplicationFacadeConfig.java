package com.abacogroup.agri.applicationforms.pua.services.common;

import com.abacogroup.applicationsupport.caller.DeleteCompileStatusCaller;
import com.abacogroup.applicationsupport.caller.GetApplicationByPartyYearModuleCodeCaller;
import com.abacogroup.applicationsupport.caller.GetApplicationDetailsCaller;
import com.abacogroup.applicationsupport.caller.GetApplicationPrintHistoryCaller;
import com.abacogroup.applicationsupport.caller.GetApplicationProfilesCaller;
import com.abacogroup.applicationsupport.caller.GetCompileStatusCaller;
import com.abacogroup.applicationsupport.caller.GetFormDetailsCaller;
import com.abacogroup.applicationsupport.caller.GetFormReadOnlyCaller;
import com.abacogroup.applicationsupport.caller.PutCompileStatusCaller;
import com.abacogroup.applicationsupport.caller.PutProfilesCaller;

import lombok.Builder;


/**
 * 
 * @author Emanuele Crocilla
 *
 */
@Builder
public class ApplicationFacadeConfig {
	
	GetCompileStatusCaller getCompileStatusCaller;
    GetFormReadOnlyCaller getFormReadOnlyCaller;
    PutCompileStatusCaller putCompileStatusCaller; 
    DeleteCompileStatusCaller deleteCompileStatusCaller;
    PutProfilesCaller putProfilesCaller;
    GetApplicationDetailsCaller getApplicationDetailsCaller;
    GetApplicationByPartyYearModuleCodeCaller getApplicationByPartyYearModuleCodeCaller;
    GetFormDetailsCaller getFormDetailsCaller;
    GetApplicationPrintHistoryCaller getApplicationPrintHistoryCaller;
    GetApplicationProfilesCaller getApplicationProfilesCaller;
    String applicationsBaseUrl;

}
