package com.abacogroup.agri.applicationforms.pua.core.model.dto;

import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author Mauro Pozzana
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AttachmentDTO  {
	private Long pkid;
	private Long applicationId;
	private String attachmentId;
	private String bucketId;
	private Long type;
	private String fileName;
	private String notes;
	@JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
	private String userIdInsert;
	@JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
	private String userIdDelete;
	@Schema(description = "the application's date of creation")
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	private LocalDateTime dtInsert;
	@JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	private LocalDateTime dtDelete;
	@JsonIgnore
	private Long typeId;
	@JsonIgnore
	private String typeCode;
	@JsonIgnore
	private String typeAttachmentGroupCode;
	@JsonIgnore
	private String typeAttachmentCode;
	@JsonIgnore
	private String tenantId;
}
