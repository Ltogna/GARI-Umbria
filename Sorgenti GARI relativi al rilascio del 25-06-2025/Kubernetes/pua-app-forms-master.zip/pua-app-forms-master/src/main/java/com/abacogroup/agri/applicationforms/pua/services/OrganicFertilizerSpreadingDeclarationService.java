package com.abacogroup.agri.applicationforms.pua.services;

import com.abacogroup.agri.applicationforms.pua.core.exceptions.*;
import com.abacogroup.agri.applicationforms.pua.core.mappers.OrganicFertilizerSpreadingDeclarationLanduseMapper;
import com.abacogroup.agri.applicationforms.pua.core.mappers.OrganicFertilizerSpreadingDeclarationLanduseMapperImpl;
import com.abacogroup.agri.applicationforms.pua.core.mappers.OrganicFertilizerSpreadingDeclarationMapper;
import com.abacogroup.agri.applicationforms.pua.core.model.CompileStatusEnum;
import com.abacogroup.agri.applicationforms.pua.core.model.dto.*;
import com.abacogroup.agri.applicationforms.pua.db.dao.OrganicFertilizerSpreadingDeclarationDAO;
import com.abacogroup.agri.applicationforms.pua.db.ntt.OrganicFertilizerSpreadingDeclarationLanduseNTT;
import com.abacogroup.agri.applicationforms.pua.db.ntt.OrganicFertilizerSpreadingDeclarationNTT;
import com.abacogroup.agri.applicationforms.pua.services.common.ApplicationFacadeService;
import com.abacogroup.agri.applicationforms.pua.services.common.crud.AbstractCrudService;
import com.abacogroup.agri.applicationforms.pua.util.GenericUtility;
import com.abacogroup.applicationworkflowsdk.model.io.output.ApplicationDetailsPublicDTO;
import com.abacogroup.dropwizard.auth.sso2.User;
import lombok.extern.slf4j.Slf4j;
import org.jdbi.v3.core.statement.StatementException;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;
import java.util.zip.GZIPOutputStream;

import static com.abacogroup.agri.applicationforms.pua.util.GenericUtility.throwNotImplementedException;

/**
 * @author Emanuele Crocilla
 */
@Slf4j
public class OrganicFertilizerSpreadingDeclarationService extends
		AbstractCrudService<OrganicFertilizerSpreadingDeclarationNTT, Long, OrganicFertilizerSpreadingDeclarationDTO, OrganicFertilizerSpreadingDeclarationMapper, Long, OrganicFertilizerSpreadingDeclarationDAO> {

	private final ApplicationFacadeService applicationFacadeService;
	private final GiasAgronicaService giasAgronicaService;
	private final NoSpreadingPeriodService noSpreadingPeriodService;
	private final BancheDatiService bancheDatiService;
	private final PartyService partyService;
	private DateFormat expectedDateSDF;

	public OrganicFertilizerSpreadingDeclarationService(
			OrganicFertilizerSpreadingDeclarationDAO dao,
			ApplicationFacadeService applicationFacadeService,
			GiasAgronicaService _giasAgronicaService,
			PartyService partyService,
			OrganicFertilizerSpreadingDeclarationMapper mapper, BancheDatiService bancheDatiService, NoSpreadingPeriodService noSpreadingPeriodService
	) {

		super(dao, mapper);
		this.applicationFacadeService = applicationFacadeService;
		this.noSpreadingPeriodService = noSpreadingPeriodService;
		this.partyService = partyService;
		this.giasAgronicaService = _giasAgronicaService;
		this.bancheDatiService = bancheDatiService;
		this.expectedDateSDF = new SimpleDateFormat("yyyyMMdd");
	}

	public OrganicFertilizerSpreadingDeclarationDTO get(User user, String tenant, Long applicationId, Long id) {

		try {

			ApplicationDetailsPublicDTO applicationDetailsPublicDTO =
					applicationFacadeService.callForApplicationDetails(tenant, applicationId, user, Locale.ITALIAN.getLanguage());

			log.info(applicationDetailsPublicDTO.toString());

			OrganicFertilizerSpreadingDeclarationDTO dto = findHierarchyByDeclarationId(id);

			if (dto != null) {
				PartyResponse partyResponse = this.partyService.getPartyById(user, tenant, dto.getPartyId());
				log.info("Retrieving of OrganicFertilizerSpreadingDeclaration completed for tenant {} and applicationId {} ", tenant, id);
				dto.setCuaa(partyResponse.getCode());
				dto.setCompany(getCompanyName(partyResponse));
				return dto;
			}

		} catch (Exception e) {
			String msg = GenericUtility.formatStr("Unable to complete 'get' method due an unhandled error for tenant {} and id {} ", tenant, id);
			log.error(msg, e);
			throw e;
		}

		String msg = GenericUtility.formatStr("Cannot find OrganicFertilizerSpreadingDeclaration using tenant {} and id {} ", tenant, id);
		ObjectNotFoundRuntimeException err = new ObjectNotFoundRuntimeException(msg);
		log.warn(msg, err);
		throw err;
	}

	public List<OrganicFertilizerSpreadingDeclarationDTO> getAll(User user, String tenant, Long applicationId) {

		try {

			ApplicationDetailsPublicDTO applicationDetailsPublicDTO =
					applicationFacadeService.callForApplicationDetails(tenant, applicationId, user, Locale.ITALIAN.getLanguage());

			log.info(applicationDetailsPublicDTO.toString());

			List<OrganicFertilizerSpreadingDeclarationDTO> dtos = findHierarchyByApplicationId(applicationId);

			PartyResponse partyResponse = null;

			if (dtos != null) {
				for (OrganicFertilizerSpreadingDeclarationDTO dto : dtos) {
					partyResponse = this.partyService.getPartyById(user, tenant, dto.getPartyId());
					dto.setCuaa(partyResponse.getCode());
					dto.setCompany(getCompanyName(partyResponse));
				}
				log.info("Retrieving of OrganicFertilizerSpreadingDeclaration completed for tenant {} and applicationId {} ", tenant, applicationId);
				return dtos;
			}

			return Collections.emptyList();
		} catch (Exception e) {

			String msg = GenericUtility.formatStr("Unable to complete 'get' method due an unhandled error for tenant {} and applicationId {} ", tenant,
					applicationId);
			log.error(msg, e);
			throw e;
		}
	}

	public void completeSpreadingEffluentsAndFrequencies(User user, String tenantId, OrganicFertilizerSpreadingDeclarationDTO payload) {
		if (payload.getLivestockEffluents() == null) {
			return;
		}
		List<Effluent> effluentList = bancheDatiService.getEffluentList(user, tenantId);
		Effluent effluent = effluentList.stream().filter(ef -> ef.getCode().equals(payload.getLivestockEffluents())).toList().get(0);
		if (effluent != null) {
			payload.setLivestockEffluentsCodeUom(effluent.getCodeUom());
			payload.setLivestockEffluentsDescriptionUom(effluent.getDescriptionUom());
			payload.setGiasFertilizerCode(effluent.getFerCod());
		}
	}

	public void completeSpreadingListEffluentsAndFrequencies(User user, String tenantId, List<OrganicFertilizerSpreadingDeclarationDTO> payloads) {
		List<Effluent> effluentList = bancheDatiService.getEffluentList(user, tenantId);
		for (OrganicFertilizerSpreadingDeclarationDTO payload : payloads) {
			Effluent effluent = effluentList.stream().filter(ef -> ef.getCode().equals(payload.getLivestockEffluents())).toList().get(0);
			payload.setLivestockEffluentsCodeUom(effluent.getCodeUom());
			payload.setLivestockEffluentsDescriptionUom(effluent.getDescriptionUom());
			payload.setGiasFertilizerCode(effluent.getFerCod());
		}
	}

	public OrganicFertilizerSpreadingDeclarationDTO insert(User user, String tenant, Long applicationId, Long formConfigId, String compileStatusIdentifier,
			OrganicFertilizerSpreadingDeclarationDTO dto) {

		try {

			applicationFacadeService.verifyAcceptDispositiveCalls(user, tenant, applicationId, formConfigId);

			// validating partyId and get PartyResponse
			PartyResponse partyResponse = this.validatePartyIdAndGetPartyResponse(user, partyService, tenant, dto.getPartyId());

			// validating ExpectedDate
			validateExpectedDate(dto.getExpectedDate());
			// validate No Spreading Period
			noSpreadingPeriodService.isSpreadingDateAllowed(user, partyResponse.getId(), dto.getLivestockEffluents(), dto.getExpectedDate());
			//Check Before Inserting
			for (var landUse : dto.getLanduses()) {
				int count = dao.exists(dto.getApplicationId(), dto.getPartyId(), landUse.getPlotId());
				if (count != 0) {
					String msg = "The plot of land with plot id = {} has been included in another spreading declaration";
					throw new PlotDuplicationRuntimeException(GenericUtility.formatStr(msg, landUse.getPlotId()));
				}
			}

			// first Time Insertion (the declaration ID is the same as the pkId)
			OrganicFertilizerSpreadingDeclarationDTO res = insert(dto);

			// update compile status
			applicationFacadeService.updateCompileStatus(user, tenant, applicationId, compileStatusIdentifier, CompileStatusEnum.COMPLETED);

			log.info("Insert of OrganicFertilizerSpreadingDeclaration completed for tenant {} applicationId {} formConfigId {}", tenant, applicationId,
					formConfigId);

			res.setCuaa(partyResponse.getCode());
			res.setCompany(getCompanyName(partyResponse));

			return res;
		} catch (Exception e) {

			String msg = GenericUtility.formatStr("Unable to complete 'insert' method due an error for tenant {} applicationId {} formConfigId {}", tenant,
					applicationId, formConfigId);
			log.error(msg, e);
			throw e;
		}
	}

	public OrganicFertilizerSpreadingDeclarationDTO update(User user, String tenant, Long applicationId, Long formConfigId, String compileStatusIdentifier,
			OrganicFertilizerSpreadingDeclarationDTO dto) {

		try {

			applicationFacadeService.verifyAcceptDispositiveCalls(user, tenant, applicationId, formConfigId);

			OrganicFertilizerSpreadingDeclarationNTT ntt = OrganicFertilizerSpreadingDeclarationMapper.INSTANCE.dtoToEntity(dto);

			var landUsesNtts = new ArrayList<OrganicFertilizerSpreadingDeclarationLanduseNTT>();

			dto.getLanduses().forEach(landuse ->
					landUsesNtts.add(OrganicFertilizerSpreadingDeclarationLanduseMapper.INSTANCE.dtoToEntity(landuse)));

			// validating partyId and get PartyResponse
			PartyResponse partyResponse = this.validatePartyIdAndGetPartyResponse(user, partyService, tenant, dto.getPartyId());

			// validating ExpectedDate
			validateExpectedDate(dto.getExpectedDate());

			// validate No Spreading Period
			noSpreadingPeriodService.isSpreadingDateAllowed(user, partyResponse.getId(), dto.getLivestockEffluents(), dto.getExpectedDate());

			dao.upsert(ntt, landUsesNtts);

			OrganicFertilizerSpreadingDeclarationDTO res = findHierarchyByDeclarationId(dto.getId());

			if (null != res) {

				applicationFacadeService.updateCompileStatus(user, tenant, applicationId, compileStatusIdentifier, CompileStatusEnum.COMPLETED);

				res.setCuaa(partyResponse.getCode());
				res.setCompany(getCompanyName(partyResponse));
			}

			return res;

		} catch (Exception e) {
			String msg = GenericUtility.formatStr("Unable to complete 'update' method due an error for tenant {}, applicationId {} and formConfigId {}", tenant,
					applicationId, formConfigId);
			log.error(msg, e);
			throw e;
		}
	}

	public boolean delete(User user, String tenant, Long applicationId, Long formConfigId, String compileStatusIdentifier, Long declarationId) {

		try {

			applicationFacadeService.verifyAcceptDispositiveCalls(user, tenant, applicationId, formConfigId);

			OrganicFertilizerSpreadingDeclarationNTT ntt = dao.findByDeclarationId(declarationId);

			if (ntt != null) {

				dao.expireHierarchyByPkId(applicationId, ntt.getPkid(), user.getUserId());

				if (!existsAtLeastOneElement(applicationId)) {
					applicationFacadeService.deleteCompileStatus(user, tenant, applicationId, compileStatusIdentifier);
				} else {
					applicationFacadeService.updateCompileStatus(user, tenant, applicationId, compileStatusIdentifier, CompileStatusEnum.COMPLETED);
				}

				return true;
			} else {

				log.warn("Unable to find item with application id = " + applicationId + " and declaration Id = " + declarationId);
				return false;
			}

		} catch (Exception e) {
			String msg = GenericUtility.formatStr("Unable to complete 'delete' method due an error for tenant {}, applicationId {} and formConfigId {}", tenant,
					applicationId, formConfigId);
			log.error(msg, e);
			throw e;
		}
	}

	//brogliaccio

	/**
	 * Method to add organic fertilizers
	 */
	public void addOrganicFert(User user, String tenant, Long applicationId) {

		log.debug("Start addOrganicFert - tenant: {}, applicationId: {}", tenant, applicationId);

		try {

			var listOrganicFertProcessComplete = new ArrayList<AttivitaOperazioniQdC>();

			log.debug("Getting all organic fertilizers for applicationId: {}", applicationId);

			var organicFertilizerSpreadingDeclarationDTOS = getAll(user, tenant, applicationId);
			log.debug("Organic fertilizers retrieved: {}",
					organicFertilizerSpreadingDeclarationDTOS != null ? organicFertilizerSpreadingDeclarationDTOS.size() : 0);

			var effluents = bancheDatiService.getEffluents(user, tenant);
			log.debug("Effluents retrieved: {}", effluents != null ? effluents.size() : 0);

			log.debug("Converting organic fertilizers to GIAS format");
			var organicFertGias = convertOrganicFertToGIAS(organicFertilizerSpreadingDeclarationDTOS, user, effluents, false);
			log.debug("Organic fertilizers converted to GIAS: {}", organicFertGias != null ? organicFertGias.size() : 0);

			if (organicFertGias != null && !organicFertGias.isEmpty()) {

				log.debug("Requesting authentication with GIAS");
				var token = giasAgronicaService.authenticateWithGias();
				log.debug("GIAS token obtained: {}", token != null);

				Map<Long, String> mapIdCuaa = mapIdsAndCuaas(organicFertilizerSpreadingDeclarationDTOS);

				log.debug("Starting processing of {} organic fertilizers", organicFertGias.size());
				organicFertGias.forEach(x -> {

					String cuaa = mapIdCuaa.get(x.getCodice());
					log.debug("Processing fertilizer with ID: {} and CUAA {}", x.getCodice(), cuaa);

					var operazioniQdC = convertAttivaToOperazioni(x, cuaa);
					log.debug("Conversion to operations completed, sending to GIAS");

					var agronicaResponse = giasAgronicaService.importOperazioniQdCV2(operazioniQdC, token.getRispostaStringa());
					if (agronicaResponse.getErrore() != null && agronicaResponse.getErrore().isBlank()) {
						listOrganicFertProcessComplete.add(x);
						log.debug("Fertilizer processed successfully");
					} else {
						throw new RuntimeException(agronicaResponse.getErrore());
					}
				});
				log.debug("Completed processing of {} fertilizers", listOrganicFertProcessComplete.size());
			} else {
				log.debug("No organic fertilizers to process");
			}
		} catch (Exception ex) {
			log.error("Error during addOrganicFert: {}", ex.getMessage(), ex);
			throw new RuntimeException(ex.getMessage(), ex);
		}
		log.debug("End addOrganicFert");
	}

	/**
	 * Method to remove organic fertilizers
	 */
	public void removeOrganicFert(User user, String tenant, Long applicationId) {

		log.debug("Start removeOrganicFert - tenant: {}, applicationId: {}", tenant, applicationId);

		try {

			// Deletion of all elements existing in the DB

			log.debug("Mode: deleting all elements for applicationId: {}", applicationId);

			var organicFertilizerSpreadingDeclarationDTOS = getAll(user, tenant, applicationId);
			log.debug("Organic fertilizers retrieved: {}",
					organicFertilizerSpreadingDeclarationDTOS != null ? organicFertilizerSpreadingDeclarationDTOS.size() : 0);

			var effluents = bancheDatiService.getEffluents(user, tenant);
			log.debug("Effluents retrieved: {}", effluents != null ? effluents.size() : 0);

			log.debug("Converting organic fertilizers to GIAS format for deletion");

			var organicFertGias = convertOrganicFertToGIAS(organicFertilizerSpreadingDeclarationDTOS, user, effluents, true);
			log.debug("Organic fertilizers converted to GIAS for deletion: {}", organicFertGias != null ? organicFertGias.size() : 0);

			if (organicFertGias != null && !organicFertGias.isEmpty()) {

				log.debug("Requesting authentication with GIAS");
				var token = giasAgronicaService.authenticateWithGias();
				log.debug("GIAS token obtained: {}", token != null);

				log.debug("Starting processing for deletion of {} fertilizers", organicFertGias.size());

				Map<Long, String> mapIdCuaa = mapIdsAndCuaas(organicFertilizerSpreadingDeclarationDTOS);

				organicFertGias.forEach(x -> {

					String cuaa = mapIdCuaa.get(x.getCodice());
					log.debug("Processing fertilizer with ID: {} and CUAA {}", x.getCodice(), cuaa);

					log.debug("Setting flagCancellazione=true for fertilizer ID: {}", x.getCodice());
					x.setFlagCancellazione(true);

					var operazioniQdC = convertAttivaToOperazioni(x, cuaa);
					log.debug("Conversion to operations completed, sending to GIAS for deletion");

					var agronicaResponse = giasAgronicaService.importOperazioniQdCV2(operazioniQdC, token.getRispostaStringa());
					log.debug("Fertilizer marked for deletion");

					if (agronicaResponse.getErrore() != null && agronicaResponse.getErrore().isBlank()) {
						log.debug("Fertilizer deleted successfully");
					} else {
						throw new RuntimeException(agronicaResponse.getErrore());
					}
				});

				log.debug("Completed processing for deletion of all elements");

			} else {
				log.debug("No organic fertilizers to delete");
			}

		} catch (Exception ex) {
			log.error("Error during removeOrganicFert: {}", ex.getMessage(), ex);
			throw new RuntimeException("Some Organic Fertilizers were not able to remove to GIAS (" + ex.getMessage() + ")", ex);
		}

		log.debug("End removeOrganicFert");
	}

	@Override
	protected boolean hasPrimaryKey() {
		return true;
	}

	@Override
	protected void deleteByCustomKey(Long customKey) {
		throw throwNotImplementedException.get();
	}

	@Override
	protected void setCustomSearchKey(OrganicFertilizerSpreadingDeclarationNTT rs, Long customKey) {
		throw throwNotImplementedException.get();
	}

	@Override
	protected Optional<OrganicFertilizerSpreadingDeclarationNTT> findRsByCustomKey(Long customKey) {
		OrganicFertilizerSpreadingDeclarationNTT ntt = this.dao.findByDeclarationId(customKey);
		return ntt == null ? Optional.empty() : Optional.of(ntt);
	}

	protected OrganicFertilizerSpreadingDeclarationDTO firstTimeInsertion(OrganicFertilizerSpreadingDeclarationDTO dtoIn) {
		return dao.inTransaction(handle -> {
			try {

				Long parentPkid = this.retrievePrimaryKey(null);
				OrganicFertilizerSpreadingDeclarationNTT OrgFertSpreadDeclNTT = mapper.dtoToEntity(dtoIn);
				OrgFertSpreadDeclNTT.setPkid(parentPkid);
				OrgFertSpreadDeclNTT.setId(parentPkid);// declaration ID is set as pkId only for the first time (declaration ID never change in updates)
				dao.insert(OrgFertSpreadDeclNTT);

				OrganicFertilizerSpreadingDeclarationLanduseMapper localMapper = new OrganicFertilizerSpreadingDeclarationLanduseMapperImpl();

				for (var landUse : dtoIn.getLanduses()) {
					OrganicFertilizerSpreadingDeclarationLanduseNTT landUseNTT = localMapper.dtoToEntity(landUse);
					Long landusePkId = dao.nextSequenceOrganicFertilizerSpreadingDeclarationLanduseVal();
					landUseNTT.setPkid(landusePkId);
					landUseNTT.setAppfpuaOrganicFertSpreadingDeclarationPkid(parentPkid);
					dao.insert(landUseNTT);
				}

				//				return findOutDtoByPrimaryKey(pkId);
				return findOrganicFertilizerSpreadingDeclarationByPkId(parentPkid);

			} catch (StatementException e) {
				log.error(e.getMessage(), e);
				throw new InsertExceptionRuntimeException("error during insert");
			} catch (ObjectNotFoundException e) {
				throw new ObjectNotFoundRuntimeException();
			} catch (Exception e) {
				throw new AgriApplicationFormsRuntimeException(e.getMessage());
			}
		});
	}

	private OrganicFertilizerSpreadingDeclarationDTO findHierarchyByDeclarationId(Long id) {

		OrganicFertilizerSpreadingDeclarationLanduseMapper localMapper = new OrganicFertilizerSpreadingDeclarationLanduseMapperImpl();

		OrganicFertilizerSpreadingDeclarationNTT elementFound = this.dao.findByDeclarationId(id);

		if (null != elementFound) {
			Long pkid = elementFound.getPkid();

			List<OrganicFertilizerSpreadingDeclarationLanduseDTO> landUses =
					dao.getOrganicFertilizerSpreadingDeclarationLanduseByParentId(pkid)
							.stream()
							.map(localMapper::entityToDto)
							.toList();

			OrganicFertilizerSpreadingDeclarationDTO res = returnOptionalRecord(elementFound).get();

			res.setLanduses(landUses);

			return res;
		}

		return null;
	}

	private OrganicFertilizerSpreadingDeclarationDTO findOrganicFertilizerSpreadingDeclarationByPkId(Long pkid) throws ObjectNotFoundException {

		OrganicFertilizerSpreadingDeclarationLanduseMapper localMapper = new OrganicFertilizerSpreadingDeclarationLanduseMapperImpl();

		OrganicFertilizerSpreadingDeclarationDTO elementFound = findOutDtoByPrimaryKey(pkid);

		if (elementFound != null) {

			List<OrganicFertilizerSpreadingDeclarationLanduseDTO> landUses =
					dao.getOrganicFertilizerSpreadingDeclarationLanduseByParentId(pkid)
							.stream()
							.map(localMapper::entityToDto)
							.toList();

			elementFound.setLanduses(landUses);

			return elementFound;
		}

		return null;
	}

	private List<OrganicFertilizerSpreadingDeclarationDTO> findHierarchyByApplicationId(Long applicationId) {

		OrganicFertilizerSpreadingDeclarationLanduseMapper localMapper = new OrganicFertilizerSpreadingDeclarationLanduseMapperImpl();

		List<OrganicFertilizerSpreadingDeclarationDTO> elementsFound =
				this.dao.findByApplicationId(applicationId).stream()
						.map(mapper::entityToDto)
						.toList();

		//	{
		//		"pkId1": [elemento1, elemento2, ...],
		//		"pkId2": [elemento3, elemento4, ...],
		//		...
		//	}
		var map = elementsFound.stream().collect(Collectors.groupingBy(OrganicFertilizerSpreadingDeclarationDTO::getPkid));

		List<OrganicFertilizerSpreadingDeclarationLanduseDTO> landUses = null;

		if (null != map && !map.isEmpty()) {

			landUses =
					dao.getOrganicFertilizerSpreadingDeclarationLanduseByParentIds(map.keySet())
							.stream()
							.map(localMapper::entityToDto)
							.toList();

			landUses.forEach(landUse -> {

				var elems = map.getOrDefault(landUse.getAppfpuaOrganicFertSpreadingDeclarationPkid(), Collections.emptyList());
				OrganicFertilizerSpreadingDeclarationDTO parent = elems.stream().findFirst().get();

				if (parent.getLanduses() == null) {
					parent.setLanduses(new ArrayList<>());
				}

				parent.getLanduses().add(landUse);
			});
		}

		return elementsFound;
	}

	private OrganicFertilizerSpreadingDeclarationDTO insert(OrganicFertilizerSpreadingDeclarationDTO in) {
		log.info("Invoking insert with params in: {}", in);
		return this.firstTimeInsertion(in);
	}

	private void validateExpectedDate(String expectedDate) {
		try {
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyMMdd");
			LocalDate expected = LocalDate.parse(expectedDate, formatter);
			LocalDate today = LocalDate.now();
			LocalDate dayAfterTomorrow = today.plusDays(2);

			if (expected.isBefore(dayAfterTomorrow)) {
				throw new Exception("The expected date = '" + expectedDate + "' is not valid. It must be at least the day after tomorrow.");
			}

		} catch (Exception e) {
			log.error(e.getMessage());
			throw new RuntimeException(e.getMessage());
		}
	}

	private boolean existsAtLeastOneElement(Long applicationId) {
		return dao.count(applicationId) > 0;
	}

	private OperazioniQdC convertAttivaToOperazioni(AttivitaOperazioniQdC request, String cuaa) {
		try {
			var arrayRequest = new ArrayList<AttivitaOperazioniQdC>();
			arrayRequest.add(request);

			var jsonReq = giasAgronicaService.mapper.writeValueAsString(arrayRequest);
			byte[] inputBytes = jsonReq.getBytes(StandardCharsets.UTF_16LE);

			// Compress using Deflater (raw DEFLATE compression, not GZIP)
			ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
			try (GZIPOutputStream gzipOutputStream = new GZIPOutputStream(outputStream)) {
				gzipOutputStream.write(inputBytes);
			}
			byte[] compressedBytes = outputStream.toByteArray();

			// Encode the just compressed result in Base64
			var datiInBase64 = Base64.getEncoder().encodeToString(compressedBytes);

			return OperazioniQdC.builder()
					.cuaa(cuaa)
					.dati(datiInBase64)
					.build();
		} catch (IOException e) {
			throw new RuntimeException("Errore durante la compressione DEFLATE dei dati", e);
		}
	}

	private List<AttivitaOperazioniQdC> convertOrganicFertToGIAS(List<OrganicFertilizerSpreadingDeclarationDTO> list, User user, List<Effluent> effluents,
			boolean isCancellazione) {
		var listOrganicFert = new ArrayList<AttivitaOperazioniQdC>();
		if (list != null && !list.isEmpty()) {
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyMMdd");
			list.forEach(x -> {
				LocalDate localDate = LocalDate.parse(x.getExpectedDate(), formatter);
				var impianti = new ArrayList<AttivitaOperazioniQdC.ImpiantiAttivitaOperazioniQdC>();
				if (!x.getLanduses().isEmpty()) {
					x.getLanduses().forEach(la -> {
						impianti.add(AttivitaOperazioniQdC.ImpiantiAttivitaOperazioniQdC.builder()
								.plotId(la.getDeclarationCode())
								.superficieTrattata(la.getPlotTotalHectar())
								.build());
					});
				}
				var prodotti = new ArrayList<AttivitaOperazioniQdC.ProdottiAttivitaOperazioniQdC>();
				var effluent = effluents.stream().filter(ef -> ef.getCode().equals(x.getLivestockEffluents())).findFirst().orElse(null);
				if (effluent == null) {
					throw new RuntimeException("Not able to find Effluents with code:" + x.getLivestockEffluents());
				} else {
					prodotti.add(AttivitaOperazioniQdC.ProdottiAttivitaOperazioniQdC.builder()
							.codice(effluent.getFerCod())
							.udm(effluent.getDescriptionUom().toUpperCase())
							.quantita(x.getLivestockEffluentsQty())
							.build());
				}
				Date expectedDate = java.sql.Date.valueOf(localDate);
				listOrganicFert.add(AttivitaOperazioniQdC.builder()
						.codice(x.getId())
						.utenteUltimaModifica(user.getName())
						.data(expectedDate)
						.impianti(impianti)
						.tipoOperazione(124) // 124 as required
						.prodotti(prodotti)
						.flagCancellazione(isCancellazione)
						.regolamentoCod(125) // 125 as required
						.build());

			});
		}
		return listOrganicFert;
	}

	private synchronized Map<Long, String> mapIdsAndCuaas(List<OrganicFertilizerSpreadingDeclarationDTO> dtos) {
		return dtos == null || dtos.isEmpty()
				? Collections.emptyMap()
				: dtos.stream()
						.collect(Collectors.toMap(
								dto -> dto.getId(),           // key: id
								dto -> dto.getCuaa(),         // value: cuaa
								(existing, replacement) -> existing  // in case of duplicates, keep first
						));
	}

}
