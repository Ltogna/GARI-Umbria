package com.abacogroup.agri.applicationforms.pua.services;

import com.abacogroup.agri.applicationforms.pua.ApplicationFormsModuleConfiguration;
import com.abacogroup.agri.applicationforms.pua.util.CommonConstants;
import com.abacogroup.dropwizard.auth.sso2.Sso2Client;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import jakarta.ws.rs.client.Client;
import jakarta.ws.rs.client.Entity;
import jakarta.ws.rs.client.WebTarget;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;

/**
 * 
 * @author Emanuele Crocilla
 *
 */
@Slf4j
public abstract class ADataImporterService {

	protected final Sso2Client sso2client;
	protected final Client client;
	protected final String cropPlanUrl;
	protected final String lpisServerUrl;
	protected final String partyRegistryUrl;
	protected final String vectorDataLayersUrl;
	protected final String bancheDatiUrl;
	protected final ObjectMapper mapper;
	protected String authToken;
	protected Boolean allow204 = false;

	protected static final String ERROR_PROCESSING_RESPONSE = "Error processing response";

	protected ADataImporterService(Sso2Client sso2client, Client client, ApplicationFormsModuleConfiguration configuration, ObjectMapper mapper) {
		this.sso2client = sso2client;
		this.client = client;
		this.cropPlanUrl = configuration.getCropPlanUrl();
		this.lpisServerUrl = configuration.getLpisServerUrl();
		this.partyRegistryUrl = configuration.getPartyRegistryUrl();
		this.vectorDataLayersUrl = configuration.getVectorDataLayersUrl();
		this.bancheDatiUrl = configuration.getBancheDatiUrl();
		this.mapper = mapper;
	}

	protected <T> T sendPostRequestWithAuth(String url, Object requestBody, TypeReference<T> responseType, String methodeName, String tenantId) {
		return sendRequest(url, responseType, authToken, requestBody, "POST", methodeName, tenantId);
	}

	protected <T> T sendGetRequestWithAuth(String url, TypeReference<T> responseType, String methodeName, String tenantId) {
		return sendRequest(url, responseType, authToken, null, "GET", methodeName, tenantId);
	}

	protected <T> T sendGetRequest(String tenantId, String url, Class<T> responseType, String methodeName) {
		return sendRequest(url, responseType, authToken, null, "GET", methodeName, tenantId);
	}

	protected <T> T sendPostRequest(String tenantId, String url, Object requestBody, Class<T> responseType, String methodeName) {
		return sendRequest(url, responseType, authToken, requestBody, "POST", methodeName, tenantId);
	}

	protected <T> T sendPutRequest(String tenantId, String url, Object requestBody, Class<T> responseType, String methodeName) {
		var reqBody = requestBody != null ? requestBody : "{}";
		return sendRequest(url, responseType, authToken, reqBody, "PUT", methodeName, tenantId);
	}

	protected <T> T sendRequest(String url, TypeReference<T> responseType, String authToken, Object requestBody, String method, String methodeName,
			String tenantId) {
		WebTarget target = client.target(url);
		Response response = null;
		try {
			if ("GET".equalsIgnoreCase(method)) {
				response = target.request(MediaType.APPLICATION_JSON)
						.header(CommonConstants.AUTHORIZATION, CommonConstants.AUTH_PREFIX + authToken)
						.get();
				
			} else if ("POST".equalsIgnoreCase(method)) {
				response = target.request(MediaType.APPLICATION_JSON)
						.header(CommonConstants.AUTHORIZATION, CommonConstants.AUTH_PREFIX + authToken)
						.post(Entity.json(requestBody));
				
			} else if ("PUT".equalsIgnoreCase(method)) {
				response = target.request(MediaType.APPLICATION_JSON)
						.header(CommonConstants.AUTHORIZATION, CommonConstants.AUTH_PREFIX + authToken)
						.put(Entity.json(requestBody));
			}

			checkResponseStatus(response, url, tenantId, requestBody, methodeName, null);
			return mapReturn(response, responseType);
		} catch (Exception e) {
			checkResponseStatus(response, url, tenantId, requestBody, methodeName, null);
			throw new RuntimeException(e);
		} finally {
			if (response != null)
				response.close();
		}
	}

	protected <T> T sendRequest(String url, Class<T> responseType, String authToken, Object requestBody, String method, String methodeName, String tenantId) {
		WebTarget target = client.target(url);
		Response response = null;
		try {
			if ("GET".equalsIgnoreCase(method)) {
				response = target.request(MediaType.APPLICATION_JSON)
						.header(CommonConstants.AUTHORIZATION, CommonConstants.AUTH_PREFIX + authToken)
						.get();
			} else if ("POST".equalsIgnoreCase(method)) {
				response = target.request(MediaType.APPLICATION_JSON)
						.header(CommonConstants.AUTHORIZATION, CommonConstants.AUTH_PREFIX + authToken)
						.post(Entity.json(requestBody));
			} else if ("PUT".equalsIgnoreCase(method)) {
				response = target.request(MediaType.APPLICATION_JSON)
						.header(CommonConstants.AUTHORIZATION, CommonConstants.AUTH_PREFIX + authToken)
						.put(Entity.json(requestBody));
			}

			checkResponseStatus(response, url, tenantId, requestBody, methodeName, null);
			return mapReturn(response, responseType);

		} catch (Exception e) {
			checkResponseStatus(response, url, tenantId, requestBody, methodeName, e);
			throw new RuntimeException(e);
		} finally {
			if (response != null)
				response.close();
		}
	}

//	protected void getAuthToken(String tenantId) {
//		try {
//			SecurityContext sc = sso2client.createSecurityContextFromUserName(tenantId, "IMPORT_SERVICE_ACCOUNT");
//			User serviceAccount = (User) sc.getUserPrincipal();
//			authToken = serviceAccount.getAuthToken();
//		} catch (AuthenticationException e) {
//			log.error(ERROR_PROCESSING_RESPONSE, e);
//			throw new RuntimeException(ERROR_PROCESSING_RESPONSE, e);
//		}
//	}

	protected String UserName(String tenant) {
		return tenant + "/IMPORT_SERVICE_ACCOUNT";
	}

	@SneakyThrows
	protected void checkResponseStatus(Response response, String url, String tenant, Object requestBody, String method, Exception ex) {
		if (response != null && (response.getStatus() != 200 && (response.getStatus() == 204 && !allow204))) {
			String errorMessage = "Request failed with status: " + response.getStatus() + " and body: " + response.readEntity(String.class);
			if (ex != null) {
				errorMessage += ex.getMessage();
			}
			ex = new Exception(errorMessage);
			log.error(ERROR_PROCESSING_RESPONSE, ex);
			throw new RuntimeException(ERROR_PROCESSING_RESPONSE, ex);
		} else if (ex != null) {
			log.error(ERROR_PROCESSING_RESPONSE, ex);
			throw new RuntimeException(ERROR_PROCESSING_RESPONSE, ex);
		}
	}

	protected <T> T mapReturn(Response response, Class<T> responseType) throws JsonMappingException, JsonProcessingException {
		if (response.getStatus() == 204) { // No Content status, no content returned from the end-point.
			return null;
		} else {
			return mapper.readValue(response.readEntity(String.class), responseType);
		}
	}

	protected <T> T mapReturn(Response response, TypeReference<T> responseType) throws JsonMappingException, JsonProcessingException {
		if (response.getStatus() == 204) { // No Content status, no content returned from the end-point.
			return null;
		} else {
			return mapper.readValue(response.readEntity(String.class), responseType);
		}
	}
	
}
