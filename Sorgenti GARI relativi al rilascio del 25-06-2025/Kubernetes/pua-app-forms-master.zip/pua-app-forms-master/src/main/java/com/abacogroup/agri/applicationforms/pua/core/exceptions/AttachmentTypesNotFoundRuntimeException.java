package com.abacogroup.agri.applicationforms.pua.core.exceptions;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.ws.rs.core.Response;

public class AttachmentTypesNotFoundRuntimeException extends AbstractException {
	
	private static final long serialVersionUID = 1L;

	private static final AttachmentTypesNotFoundRuntimeException.ErrorBody BODY = new AttachmentTypesNotFoundRuntimeException.ErrorBody();

	public AttachmentTypesNotFoundRuntimeException(String message) {
		super(Response.Status.NOT_FOUND, BODY, message);
	}

	@Schema(name = "AttachmentTypesNotFoundRuntimeExceptionErrorBody")
	public static class ErrorBody implements ExceptionErrorBody {
		private static final String ERR = "ATTACHMENT_TYPES_NOT_FOUND_ERROR";

		@Override
		@Schema(allowableValues = ERR)
		public String getErrorCode() {
			return ERR;
		}
	}
}
