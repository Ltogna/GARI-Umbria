package com.abacogroup.agri.applicationforms.pua.core.mappers;

/**
 * @param <D> the DTO entity model
 * @param <P> the public element
 * @author Alexandru Paraschiv
 * @author Mauro Pozzana
 */
public interface PublicMapper<D, P> {
	D publicToDTO(P publicElement);

	P dtoToPublic(D dto);

}
