package com.abacogroup.agri.applicationforms.pua.resources;

import com.abacogroup.agri.applicationforms.pua.ApplicationFormsModuleConfiguration;
import com.abacogroup.agri.applicationforms.pua.core.exceptions.ObjectNotFoundRuntimeException;
import com.abacogroup.agri.applicationforms.pua.core.model.dto.*;
import com.abacogroup.agri.applicationforms.pua.services.BancheDatiService;
import com.abacogroup.agri.applicationforms.pua.services.CropPlanService;
import com.abacogroup.agri.applicationforms.pua.services.DeclarationsOnSectorsService;
import com.abacogroup.agri.applicationforms.pua.services.GiasAgronicaService;
import com.abacogroup.agri.applicationforms.pua.services.IpisGisService;
import com.abacogroup.agri.applicationforms.pua.services.common.ApplicationFacadeService;
import com.abacogroup.agri.applicationforms.pua.util.CommonConstants;
import com.abacogroup.agri.applicationforms.pua.util.DeclarationsOnSectorsBuffer;
import com.abacogroup.agri.applicationforms.pua.util.FilterHandler;
import com.abacogroup.applicationworkflowsdk.model.io.output.ApplicationDetailsPublicDTO;
import com.abacogroup.dropwizard.auth.sso2.Sso2Client;
import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import io.dropwizard.auth.Auth;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.parameters.RequestBody;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.constraints.NotNull;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.Context;
import jakarta.ws.rs.core.Response;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.locationtech.jts.geom.Geometry;
import org.locationtech.jts.io.WKTReader;

import java.util.*;

/**
 * @author Emanuele Crocilla
 */
@Slf4j
public class DeclarationsOnSectorsResources extends AGenericPuaResources {

	public DeclarationsOnSectorsResources(ApplicationFormsModuleConfiguration configuration,
			ApplicationFacadeService applicationFacadeService,
			DeclarationsOnSectorsService declarationsOnSectorsService,
			CropPlanService cropPlanService,
			IpisGisService ipisGisService,
			BancheDatiService bancheDatiService,
			Sso2Client sso2Client,
			GiasAgronicaService giasService) {

		super(configuration, sso2Client);
		this.declarationsOnSectorsService = declarationsOnSectorsService;
		this.applicationFacadeService = applicationFacadeService;
		this.cropPlanService = cropPlanService;
		this.ipisGisService = ipisGisService;
		this.bancheDatiService = bancheDatiService;
	}

	@GET
	@Path("/{applicationId}/declaration-on-sector/{declatation_id}")
	public Response get(
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "Current Tenant") @NotNull @PathParam("tenant") String tenant,
			@Parameter(description = "The application id") @NotNull @PathParam("applicationId") Long applicationId,
			@Parameter(description = "The declatation id") @NotNull @PathParam("declatation_id") Long declarationId
	) {

		DeclarationsOnSectorsDTO dto = null;

		try {

			dto = declarationsOnSectorsService.get(user, tenant, applicationId, declarationId);

		} catch (ObjectNotFoundRuntimeException e) {
			return Response.noContent().build();
		}

		return Response.ok(dto).build();
	}

	@GET
	@Path("/{applicationId}/declarations-on-sectors")
	public Response getAll(
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "Current Tenant") @NotNull @PathParam("tenant") String tenant,
			@Parameter(description = "The application id") @NotNull @PathParam("applicationId") Long applicationId,
			@Parameter(description = "The infinite list key") @QueryParam("nextKey") String nextKey,
			@Context HttpServletRequest request) {

		InfiniteListResults<DeclarationsOnSectorsDTO> dtos = null;

		try {

			Map<String, String[]> requestParams = FilterHandler.convertRequestParametersToMap(request);

			dtos = declarationsOnSectorsService.searchDeclarationOnsectorsByFilter(user, tenant,
					applicationId, requestParams, null /*nextKey TODO EC UNCOMMENT THIS TO RESTORE PAGINATION */);

		} catch (ObjectNotFoundRuntimeException e) {
			return Response.ok(Collections.emptyList()).build();
		}

		//		return Response.ok(dtos).build(); TODO EC UNCOMMENT THIS TO RESTORE PAGINATION
		return Response.ok(dtos.getRecords()).build();
	}

	@POST
	@Path("/{applicationId}/declarations-on-sectors")
	public Response add(
			@Auth User user,
			@NotNull @RequestBody DeclarationsOnSectorsDTO payload,
			@Parameter(description = "Current Tenant") @NotNull @PathParam("tenant") String tenantId,
			@Parameter(description = "The application id") @NotNull @PathParam("applicationId") Long applicationId,
			@Parameter(description = "The form config id") @NotNull @QueryParam("formConfigId") Long formConfigId,
			@Parameter(description = "The compile status identifier") @QueryParam("compileStatusIdentifier") String compileStatusIdentifier
	) {

		// validations
		ipisGisService.validateSectorCode(user, tenantId, payload.getSectorCode());
		ipisGisService.validateLandUseCode(user, tenantId, payload.getLandUseCode());

		payload.setApplicationId(applicationId);
		payload.setUserIdInsert(user.getUserId());
		payload.setDtDelete(CommonConstants.FAR_OFF_DATE);
		DeclarationsOnSectorsDTO res = declarationsOnSectorsService.insert(user, tenantId, applicationId, formConfigId, compileStatusIdentifier, payload);
		return Response.ok(res).build();
	}

	@PUT
	@Path("/{applicationId}/declaration-on-sector/{declatation_id}")
	public Response update(
			@Auth User user,
			@NotNull @RequestBody DeclarationsOnSectorsDTO payload,
			@Parameter(description = "Current Tenant") @NotNull @PathParam("tenant") String tenantId,
			@Parameter(description = "The application id") @NotNull @PathParam("applicationId") Long applicationId,
			@Parameter(description = "The form config id") @NotNull @QueryParam("formConfigId") Long formConfigId,
			@Parameter(description = "The compile status identifier") @QueryParam("compileStatusIdentifier") String compileStatusIdentifier,
			@Parameter(description = "The declatation id") @NotNull @PathParam("declatation_id") Long declatationId
	) {

		// validations
		ipisGisService.validateSectorCode(user, tenantId, payload.getSectorCode());
		ipisGisService.validateLandUseCode(user, tenantId, payload.getLandUseCode());

		payload.setApplicationId(applicationId);
		payload.setUserIdInsert(user.getUserId());
		payload.setDtDelete(CommonConstants.FAR_OFF_DATE);

		DeclarationsOnSectorsDTO res = declarationsOnSectorsService.update(user, tenantId, applicationId, formConfigId, compileStatusIdentifier, payload,
				declatationId);
		return Response.ok(res).build();
	}

	@PUT
	@Path("/{applicationId}/declarations-on-sector")
	public Response updateMassive(
			@Auth User user,
			@NotNull @RequestBody DeclarationsOnSectorsDTO payload,
			@Parameter(description = "Current Tenant") @NotNull @PathParam("tenant") String tenantId,
			@Parameter(description = "The application id") @NotNull @PathParam("applicationId") Long applicationId,
			@Parameter(description = "The form config id") @NotNull @QueryParam("formConfigId") Long formConfigId,
			@Parameter(description = "The compile status identifier") @QueryParam("compileStatusIdentifier") String compileStatusIdentifier
	) {

		// validations
		var ntts = declarationsOnSectorsService.getByIds(payload.getIds());
		ntts.forEach(x -> {
			try {
				ipisGisService.validateSectorCode(user, tenantId, payload.getSectorCode());
				ipisGisService.validateLandUseCode(user, tenantId, x.getLandUseCode());
			} catch (Exception ex) {
				payload.setIds(payload.getIds().stream().filter(p -> !Objects.equals(p, x.getPkid())).toList());
			}
		});

		var res = declarationsOnSectorsService.updateMassive(user, tenantId, applicationId, formConfigId, compileStatusIdentifier,
				payload);
		return Response.ok(res).build();
	}

	@DELETE
	@Path("/{applicationId}/declaration-on-sector/{declatation_id}")
	public void delete(
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "Current Tenant") @NotNull @PathParam("tenant") String tenantId,
			@Parameter(description = "The application id") @NotNull @PathParam("applicationId") Long applicationId,
			@Parameter(description = "The form config id") @NotNull @QueryParam("formConfigId") Long formConfigId,
			@Parameter(description = "The compile status identifier") @QueryParam("compileStatusIdentifier") String compileStatusIdentifier,
			@Parameter(description = "The declatation id") @NotNull @PathParam("declatation_id") Long declatationId) {

		declarationsOnSectorsService.delete(user, tenantId, applicationId, formConfigId, compileStatusIdentifier, declatationId);
	}

	@DELETE
	@Path("/{applicationId}/declaration-on-sector")
	public Response deleteAll(
			@Auth User user,
			@Parameter(description = "Current Tenant") @NotNull @PathParam("tenant") String tenantId,
			@Parameter(description = "The application id") @NotNull @PathParam("applicationId") Long applicationId,
			@Parameter(description = "The form config id") @NotNull @QueryParam("formConfigId") Long formConfigId,
			@Parameter(description = "The compile status identifier") @QueryParam("compileStatusIdentifier") String compileStatusIdentifier
	) {
		declarationsOnSectorsService.deleteAll(user, tenantId, applicationId, formConfigId, compileStatusIdentifier);
		return Response.ok().build();
	}

	@GET
	@Path("/{applicationId}/declarations-on-sectors/{campaignYear}/import")
	public Response addMassive(
			@Auth User user,
			@Parameter(description = "Current Tenant") @NotNull @PathParam("tenant") String tenantId,
			@Parameter(description = "The application id") @NotNull @PathParam("applicationId") Long applicationId,
			@Parameter(description = "The form config id") @NotNull @QueryParam("formConfigId") Long formConfigId,
			@Parameter(description = "The compile status identifier") @QueryParam("compileStatusIdentifier") String compileStatusIdentifier,
			@Parameter(description = "The campaign year") @NotNull @PathParam("campaignYear") Integer campaignYear
	) {

		ApplicationDetailsPublicDTO applicationDetailsPublicDTO =
				applicationFacadeService.callForApplicationDetails(tenantId, applicationId, user, Locale.ITALIAN.getLanguage());

		Long businessId = applicationDetailsPublicDTO.getPartyId();

		// EXAMPLE: https://umbria-dev.fe.abacogroup.eu/crop-plan-api/master/public/v1/crop-plans/2/plans?cropPlanTypeCode=CROPPLAN
		RecordResponse<CropPlanResponse> cropPlans = cropPlanService.getCropPlans(user, tenantId, businessId, "CROPPLAN");

		List<DeclarationsOnSectorsDTO> res = new ArrayList<>();

		if (!cropPlans.getRecords().isEmpty()) {

			Integer cropPlanId = cropPlans.getRecords().get(0).getCropPlanId();

			// EXAMPLE: https://umbria-dev.fe.abacogroup.eu/crop-plan-api/master/public/v1/crop-plans/2/plans/11/versions
			RecordResponse<VersionResponse> versionCropPlans =
					cropPlanService.getVersionCropPlan(user, tenantId, businessId, cropPlanId, campaignYear);

			List<VersionResponse> versions = versionCropPlans != null ? versionCropPlans.getRecords() : Collections.emptyList();
			String version = null;

			if (!versions.isEmpty()) {
				versions.sort((o1, o2) -> o1.getVersionReferenceDate().compareTo(o2.getVersionReferenceDate()));

				// get the last one version - will be something as: MjAyNC0xMS0yMVQxMDo0OToxOS4xODkxMDk
				version = versions.get(versions.size() - 1).getVersion();
			}

			// EXAMPLE: https://umbria-dev.fe.abacogroup.eu/crop-plan-api/master/public/v1/crop-plans/2/plans/11/plots?version=MjAyNC0xMS0yMVQxMDo0OToxOS4xODkxMDk&pointInTime=20231111&pointInTimeTo=20241011
			RecordResponse<PlotRecord> plotCropPlan =
					cropPlanService.plotCropPlan(user, tenantId, businessId, cropPlanId, version, campaignYear);

			/**
			 With this buffer, will be done an aggregation based on [domainZoneId | landUse].
			 The "AreaSqr" Will be the sum of all "usedAreaSqr" (areaSqr / 100 * areaPerc) which are in relationship with  [domainZoneId | landUse]
			 Eg.:
			 [domainZoneId | landUse]  -  [AreaSqr]
			 E435|002-011-000-000-101  -	  46421
			 E435|065-002-009-000-000  -     116
			 L218|780-000-000-000-000  -    1338
			 F785|420-006-000-000-000  -      89
			 G237|A15-011-000-000-000  -   70473
			 I244|651-000-000-000-000  -     385
			 */
			DeclarationsOnSectorsBuffer buffer = new DeclarationsOnSectorsBuffer(applicationId, user.getUserId());

			plotCropPlan.getRecords().forEach(rcd -> {

				String domainZoneId = rcd.getDomainZoneId();
				double areaSqr = rcd.getAreaSqm();

				var flZvn = new Value<Boolean>(false);

				try {

					WKTReader reader = new WKTReader();
					Geometry geometry = reader.read(rcd.getGeom());
					String srs = rcd.getSrs();
					flZvn.set(cropPlanService.thereAreAnyIntersections(geometry, tenantId, srs));
				} catch (Exception e) {
					log.error(e.getMessage(), e);
				}

				rcd.getDecls().forEach(dec -> {
					String landUse = dec.getLanduse().getCode();
					double areaPerc = dec.getAreaPerc();

					var maxToAddByCrop = bancheDatiService.getMaxToAddByCrop(user, tenantId, Collections.singletonList(landUse));
					Double nitrogenQt = maxToAddByCrop.get(0).getNitrogenQt();
					int mas = nitrogenQt == null ? 0 : maxToAddByCrop.get(0).getNitrogenQt().intValue();
					DeclarationsOnSectorsBuffer.DeclarationsOnSectorsBufferElement buffElem =
							buffer.newElementOrExisting(domainZoneId, landUse, mas);
					buffElem.addAreaSqr(areaSqr, areaPerc);
					buffElem.setFlZvn(flZvn.get());
				});
			});

			// force deleting of existing elements
			declarationsOnSectorsService.deleteAll(user, tenantId, applicationId, formConfigId, compileStatusIdentifier);

			var importedElements = buffer.getAllAsDeclarationsOnSectorsDTOs();

			if (!importedElements.isEmpty()) {

				// insert in DB just imported elements 
				List<DeclarationsOnSectorsDTO> elementsInserted =
						declarationsOnSectorsService.insertMany(user, tenantId, applicationId, formConfigId, compileStatusIdentifier, importedElements,
								(short) 1);

				res.addAll(elementsInserted);
			}
		}

		return Response.ok(res).build();
	}

	@NoArgsConstructor
	@AllArgsConstructor
	private class Value<T> {
		private T t;

		public T get() {
			return t;
		}

		public void set(T t) {
			this.t = t;
		}

		public boolean isNull() {
			return t == null;
		}
	}
}
