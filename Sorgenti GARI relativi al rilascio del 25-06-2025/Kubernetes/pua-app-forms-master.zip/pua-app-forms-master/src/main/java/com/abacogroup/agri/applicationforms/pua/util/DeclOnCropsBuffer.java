package com.abacogroup.agri.applicationforms.pua.util;

import com.abacogroup.agri.applicationforms.pua.core.model.dto.DeclOnCropsDTO;
import com.abacogroup.agri.applicationforms.pua.util.DeclOnCropsBuffer.DeclOnCropsBufferElement;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * @author Emanuele Crocilla
 */
public class DeclOnCropsBuffer extends HashMap<String, DeclOnCropsBufferElement> {

	private static final long serialVersionUID = 1L;

	private Long applicationId;
	private String userId;

	private static final String SEPARATOR = "||";

	public DeclOnCropsBuffer(Long applicationId, String userId) {
		this.applicationId = applicationId;
		this.userId = userId;
	}

	public DeclOnCropsBufferElement newElement(Long planId, String declCode, String landUseCode, int mas) {
		var newElement = new DeclOnCropsBufferElement(planId, declCode, landUseCode, mas);
		put(newElement.getIdentifier(), newElement);
		return newElement;
	}

	public DeclOnCropsBufferElement newElementOrExisting(Long planId, String declCode, String landUseCode, int mas) {

		if (!this.containsElement(planId, declCode, landUseCode)) {
			return this.newElement(planId, declCode, landUseCode, mas);
		}

		return this.getElement(planId, declCode, landUseCode);
	}

	public DeclOnCropsBufferElement getElement(Long planId, String declCode, String landUseCode) {
		return get(planId + SEPARATOR + declCode + SEPARATOR + landUseCode);
	}

	public List<DeclOnCropsDTO> getAllAsDeclOnCropsDTOs() {
		var res = new ArrayList<DeclOnCropsDTO>();

		this.forEach((k, v) -> {

			DeclOnCropsDTO declarationsOnCropsDTO = DeclOnCropsDTO.builder()
					.applicationId(applicationId)
					.areaSqm((int) Math.round(v.usedAreaSqr))
					.cropDuration(v.cropDuration)
					.cycle(v.cycle)
					.declCode(v.getDeclCode())
					.distributableNitrogen(v.distributableNitrogen)
					.flZvn(v.flZvn)
					.landUseCode(v.landUseCode)
					.mas(v.mas)
					.planId(v.planId)
					.plantStatus(v.plantStatus)
					.plotCode(v.plotCode)
					.plotDescription(v.plotDescription)
					.precessionCode(v.precessionCode)
					.totResidualNitrogen(v.totResidualNitrogen)
					.typology(v.typology)
					.declarationVersion(v.version)
					.sectorCode(v.sectorCode)
					.yield(v.yield)
					.userIdInsert(userId)
					.userIdDelete("")
					.dtInsert(OffsetDateTime.now())
					.dtDelete(CommonConstants.FAR_OFF_DATE)
					.build();

			res.add(declarationsOnCropsDTO);
		});
		return res;
	}

	public boolean containsElement(Long planId, String declCode, String landUseCode) {
		return this.containsKey(planId + SEPARATOR + declCode + SEPARATOR + landUseCode);
	}

	@Data
	@NoArgsConstructor
	public class DeclOnCropsBufferElement {

		private String identifier;

		private Long planId;
		private String plotCode;
		private String plotDescription;
		private String declCode;
		private String version;
		private String landUseCode;

		private boolean flZvn;
		private Integer areaSqm;
		private String cropDuration;
		private String plantStatus;
		private Integer cycle = 0;
		private String typology;
		private Integer yieldReference;
		private Integer yield;
		private Integer mas;
		private Integer precessionCode;
		//		private String precessionDescription;
		private BigDecimal totResidualNitrogen;
		private BigDecimal distributableNitrogen;
		private Integer totalNitrogen;
		private String sectorCode;

		//		private List<DeclOnCropsPrevEffluentsBufferElement> cropsPrevEffluentsBufferElements;

		private double usedAreaSqr = 0;

		public DeclOnCropsBufferElement(Long planId, String declCode, String landUseCode, int mas) {
			this.identifier = planId + SEPARATOR + declCode + SEPARATOR + landUseCode;
			this.planId = planId;
			this.declCode = declCode;
			this.landUseCode = landUseCode;
			this.mas = mas;
		}

		public void addAreaSqr(double areaSqr, double areaPerc) {
			this.usedAreaSqr += areaSqr / 100 * areaPerc;
		}
	}

	@Override
	public boolean equals(Object o) {
		return super.equals(o);
	}

	@Override
	public int hashCode() {
		return super.hashCode();
	}

	//	@Data
	//	@NoArgsConstructor
	//	public class DeclOnCropsPrevEffluentsBufferElement {
	//		private String effluent;
	//		private String measurementUnit;
	//		private BigDecimal quantity;
	//		private BigDecimal nitrogenContent;
	//		private String frequency;
	//		private BigDecimal reduction;
	//		private BigDecimal residualNumber;
	//	}
}

