package com.abacogroup.agri.applicationforms.pua.core.exceptions;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.ws.rs.core.Response;

/**
 * The type File not permitted runtime exception.
 * @author Carlo Sindico
 */
public class FileNotPermittedRuntimeException extends AbstractException {

	private static final long serialVersionUID = 1L;
	
    private static final FileNotPermittedRuntimeException.ErrorBody BODY = new FileNotPermittedRuntimeException.ErrorBody();

    public FileNotPermittedRuntimeException(String message) {
        super(Response.Status.BAD_REQUEST, BODY, message);
    }

    @Schema(name = "FileNotPermittedRuntimeExceptionErrorBody")
    public static class ErrorBody implements ExceptionErrorBody {
        private static final String ERR = "FILE_NOT_PERMITTED_ERROR";

        @Override
        @Schema(allowableValues = ERR)
        public String getErrorCode() {
            return ERR;
        }
    }
}
