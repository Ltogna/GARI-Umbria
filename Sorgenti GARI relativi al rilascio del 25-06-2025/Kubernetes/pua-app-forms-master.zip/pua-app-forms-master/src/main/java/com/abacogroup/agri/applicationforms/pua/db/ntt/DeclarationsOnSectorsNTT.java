package com.abacogroup.agri.applicationforms.pua.db.ntt;

import com.abacogroup.agri.applicationforms.pua.db.ntt.applications.IIdRs;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.OffsetDateTime;
import java.util.Optional;

/**
 * @author Emanuele Crocilla
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DeclarationsOnSectorsNTT implements IIdRs<Long> {

	private Long pkid;
	private Long applicationId;
	private String sectorCode;
	private String landUseCode;
	private Integer areaSqm;
	private Integer mas;
	private OffsetDateTime dtInsert;
	private OffsetDateTime dtDelete;
	private String userIdInsert;
	private String userIdDelete;
	private Short flImported;
	private Short flZvn;

	@Override
	public void setKey(Long id) {
		setPkid(id);
	}

	@Override
	public Optional<Long> getKey() {
		return Optional.ofNullable(getPkid());
	}
}
