package com.abacogroup.agri.applicationforms.pua.db.keys;

import java.util.Objects;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

/**
 * @author Mattia Perini
 */
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class OptionParamKey {
    private Long optionConfigId;
    private String attributeName;

    @Override
    public boolean equals(Object o) {
        if (this == o)
            return true;
        if (!(o instanceof OptionParamKey))
            return false;

        OptionParamKey optionParamKey = (OptionParamKey) o;
        return Objects.equals(optionConfigId, optionParamKey.getOptionConfigId()) &&
                Objects.equals(attributeName, optionParamKey.getAttributeName());
    }

    @Override
    public int hashCode() {
        return Objects.hash(optionConfigId, attributeName);
    }
}
