package com.abacogroup.agri.applicationforms.pua.services;

import java.util.ArrayList;
import java.util.Collections;
import java.util.concurrent.TimeUnit;

import com.abacogroup.agri.applicationforms.pua.ApplicationFormsModuleConfiguration;
import com.abacogroup.agri.applicationforms.pua.core.model.dto.LandUseCodesDTO;
import com.abacogroup.agri.applicationforms.pua.core.model.dto.LandUseCodesRequest;
import com.abacogroup.agri.applicationforms.pua.core.model.dto.RecordResponse;
import com.abacogroup.agri.applicationforms.pua.core.model.dto.SectorDTO;
import com.abacogroup.agri.applicationforms.pua.core.model.dto.SectorRequest;
import com.abacogroup.dropwizard.auth.sso2.Sso2Client;
import com.abacogroup.dropwizard.auth.sso2.User;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.github.benmanes.caffeine.cache.Cache;
import com.github.benmanes.caffeine.cache.Caffeine;

import jakarta.ws.rs.client.Client;
import lombok.extern.slf4j.Slf4j;

/**
 * 
 * @author Emanuele Crocilla
 *
 */
@Slf4j
public class IpisGisService extends ADataImporterService {
	
	private final Cache<String, Boolean> sectorCodesCache; // KEY: tenant|SectorCode
	private final Cache<String, Boolean> landusesCodesCache; // KEY: tenant|LandusesCode

	public IpisGisService(Sso2Client sso2client, Client client, ApplicationFormsModuleConfiguration config, ObjectMapper objectMapper) {
		super(sso2client, client, config, objectMapper);
		 
		sectorCodesCache = Caffeine.newBuilder()
				.maximumWeight(1000)
				.weigher((key, value) -> 1)
				.expireAfterWrite(6, TimeUnit.HOURS)
				.build();
		
		landusesCodesCache = Caffeine.newBuilder()
				.maximumWeight(1000)
				.weigher((key, value) -> 1)
				.expireAfterWrite(6, TimeUnit.HOURS)
				.build();
	}
	
	public RecordResponse<SectorDTO> getSectors(User user, String tenantId, SectorRequest request) {
		authToken = user.getAuthToken();
		var result = new RecordResponse<SectorDTO>();
		result.setRecords(new ArrayList<>());
		String nextKey = null;

		do {
			// /lpis-server-api/master/public/v1/lpis/sectors
			String url = String.format("%s/%s/public/v1/lpis/sectors", lpisServerUrl, tenantId);
			var data = sendPostRequestWithAuth(url, request, new TypeReference<RecordResponse<SectorDTO>>() {
			}, "getSectors", tenantId);

			if (data != null && !data.getRecords().isEmpty()) {
				result.getRecords().addAll(data.getRecords());
				nextKey = data.getNextKey();
			}
		}
		while (nextKey != null);
		return result;
	}
 
	public LandUseCodesDTO getLandusesCodes(User user, String tenantId, LandUseCodesRequest request) {
		authToken = user.getAuthToken();

		// /lpis-server-api/master/public/v1/lpis/sectors
		String url = String.format("%s/%s/public/v1/lpis/support/landuses-codes", lpisServerUrl, tenantId);
		return sendPostRequest(tenantId, url, request, LandUseCodesDTO.class, "getLandusesCodes");
	}
	
	// TRUE, FALSE or Null
	public Boolean existsSectorCodeInCache(String tenant, String sectorCode) {
        log.info("retrieve sectorCode from cache for tenant: {} sectorCode: {}", tenant, sectorCode);
		return this.sectorCodesCache.getIfPresent(tenant + sectorCode);
    }

	public void putSectorCodeToCache(String tenant, String sectorCode, boolean value) {
		log.info("add sectorCode in cache for tenant: {} sectorCode: {} value: {}", tenant, sectorCode, value);
		this.sectorCodesCache.put(tenant + sectorCode, value);
	}
	
	// TRUE, FALSE or Null
	public Boolean existsLanduseCodeInCache(String tenant, String landusesCode) {
        log.info("retrieve landusesCodesCache from cache for tenant: {} sectorCode: {}", tenant, landusesCode);
		return this.landusesCodesCache.getIfPresent(tenant + landusesCode);
    }

	public void putLanduseCodeInCache(String tenant, String landusesCode, boolean value) {
		log.info("add landusesCode in cache for tenant: {} landusesCode: {} value: {}", tenant, landusesCode, value);
		this.landusesCodesCache.put(tenant + landusesCode, value);
	}
	
	/** validations for landUseCode */
	public void validateLandUseCode(User user, String tenantId, String landUseCode) {

		// try to retrieve LandUseCode from cache
		Boolean isExistingLandUseCode = existsLanduseCodeInCache(tenantId, landUseCode);
		if (isExistingLandUseCode == null) {
			LandUseCodesRequest request = LandUseCodesRequest.builder()
					.landuseCodes(Collections.singletonList(landUseCode))
					.build();

			LandUseCodesDTO landUseCodes = getLandusesCodes(user, tenantId, request);
			isExistingLandUseCode = landUseCodes != null && !landUseCodes.getLandUsesCodesList().isEmpty();
			putLanduseCodeInCache(tenantId, landUseCode, isExistingLandUseCode);
		}

		if (!isExistingLandUseCode) {
			log.error("Unable to find the landUseCodes = " + landUseCode);
			throw new RuntimeException("Unable to find the landUseCodes = " + landUseCode);
		}
	}
	
	/** validations for sectorCode */
	public void validateSectorCode(User user, String tenantId, String sectorCode) {

		// try to retrieve SectorCode from cache
		Boolean isExistingSectorCode = existsSectorCodeInCache(tenantId, sectorCode);		
		if (isExistingSectorCode == null) {
			SectorRequest sectorRequest = SectorRequest.builder()
					.codes(Collections.singletonList(sectorCode))
					.filter("")
					.nextKey("1")
					.build();

			RecordResponse<SectorDTO> sectors = getSectors(user, tenantId, sectorRequest);
			isExistingSectorCode = sectors != null && !sectors.getRecords().isEmpty();
			putSectorCodeToCache(tenantId, sectorCode, isExistingSectorCode);
		}

		if (!isExistingSectorCode) {
			log.error("Unable to find the SectorCode = " + sectorCode);
			throw new RuntimeException("Unable to find the SectorCode = " + sectorCode);
		}
	}

}
