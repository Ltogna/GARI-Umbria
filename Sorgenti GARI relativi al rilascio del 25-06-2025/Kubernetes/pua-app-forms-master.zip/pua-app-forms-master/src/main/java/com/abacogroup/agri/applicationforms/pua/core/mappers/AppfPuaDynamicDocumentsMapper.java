package com.abacogroup.agri.applicationforms.pua.core.mappers;

import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import com.abacogroup.agri.applicationforms.pua.core.model.dto.AppfPuaDynamicDocumentsDTO;
import com.abacogroup.agri.applicationforms.pua.db.ntt.AppfPuaDynamicDocumentsNTT;
import com.abacogroup.jdbi.mapper.AbsoluteDateMapper;

@Mapper(uses = AbsoluteDateMapper.class)
public interface AppfPuaDynamicDocumentsMapper extends EntityMapper<AppfPuaDynamicDocumentsDTO, AppfPuaDynamicDocumentsNTT> {

	AppfPuaDynamicDocumentsMapper INSTANCE = Mappers.getMapper(AppfPuaDynamicDocumentsMapper.class);

	@InheritInverseConfiguration()
	AppfPuaDynamicDocumentsDTO entityToDto(AppfPuaDynamicDocumentsNTT entity);

	@Mapping(source = "id", target = "id")
	@Mapping(source = "applicationId", target = "application_id")
	@Mapping(source = "documentId", target = "document_id")
	@Mapping(source = "documentCode", target = "document_code")
	@Mapping(source = "takeoverId", target = "takeover_id")
	AppfPuaDynamicDocumentsNTT dtoToEntity(AppfPuaDynamicDocumentsDTO dto);

}
