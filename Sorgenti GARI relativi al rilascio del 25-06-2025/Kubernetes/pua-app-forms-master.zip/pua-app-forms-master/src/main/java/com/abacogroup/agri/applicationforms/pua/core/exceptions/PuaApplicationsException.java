package com.abacogroup.agri.applicationforms.pua.core.exceptions;

public class PuaApplicationsException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 748787262154109107L;

	public PuaApplicationsException(String errorMessage, Throwable err) {
		super(errorMessage, err);
	}

	public PuaApplicationsException(String errorMessage) {
		super(errorMessage);
	}

	public PuaApplicationsException(Throwable err) {
		super(err);
	}
}
