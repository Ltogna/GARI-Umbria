package com.abacogroup.agri.applicationforms.pua.core.model;

import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 
 * @author Emanuele Crocilla
 *
 */
@Data
@NoArgsConstructor
@Builder
public class EffluentFrequencyKey {
	private String tenant;
    private String code;
    
	public EffluentFrequencyKey(String tenant, String code) {
		super();
		this.tenant = tenant;
		this.code = code;
	}
    
}
