package com.abacogroup.agri.applicationforms.pua.util;

import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.jdbi.paging.impl.InfiniteListResultsImpl;
import io.github.resilience4j.retry.RetryConfig;
import io.github.resilience4j.retry.RetryRegistry;
import jakarta.ws.rs.ProcessingException;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.ServerErrorException;
import jakarta.ws.rs.client.Entity;
import jakarta.ws.rs.client.Invocation.Builder;
import jakarta.ws.rs.client.WebTarget;
import jakarta.ws.rs.core.GenericType;
import jakarta.ws.rs.core.HttpHeaders;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.MultivaluedHashMap;
import jakarta.ws.rs.core.MultivaluedMap;
import java.io.InputStream;
import java.lang.reflect.Field;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Optional;
import java.util.concurrent.Future;
import java.util.function.Consumer;
import java.util.function.Function;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

@Slf4j
public class ClientHelper {

	private static final String DEFAULT_PREFIX = "JWT";
	private static final String DEFAULT_LANG = "en";

	private final WebTarget target;

	private final RetryRegistry retryRegistry;

	public ClientHelper(WebTarget webTarget) {
		this.target = webTarget;
		this.retryRegistry = RetryRegistry.of(RetryConfig.custom()
				.maxAttempts(2)
				.waitDuration(Duration.ofMillis(500))
				.failAfterMaxAttempts(true)
				.retryExceptions(ProcessingException.class, ServerErrorException.class)
				.build());
	}

	public <T> T getElementFromInfiniteResult(String path, ReqContext context, Map<String, Object> pathVariables, MultivaluedMap<String, Object> queryParams,
			GenericType<InfiniteListResultsImpl<T>> type, int pos) {
		InfiniteListResultsImpl<T> infiniteListResults = this.get(path, context, pathVariables, queryParams, type);

		if (infiniteListResults.getCount() <= pos) {
			return null;
		} else {
			T t = infiniteListResults.getRecords().get(pos);
			return t;
		}
	}

	public <T> List<T> getAllFromInfiniteResult(String path, ReqContext context, Map<String, Object> pathVariables, MultivaluedMap<String, Object> queryParams,
			GenericType<InfiniteListResultsImpl<T>> type) {

		List<T> all = new ArrayList<>();

		this.consumeAllFromInfiniteResult(path, context, pathVariables, queryParams, type, all::add);

		return all;
	}

	public <T> void consumeAllFromInfiniteResult(String path, ReqContext context, Map<String, Object> pathVariables, MultivaluedMap<String, Object> queryParams,
			GenericType<InfiniteListResultsImpl<T>> type, Consumer<T> consumer) {
		doConsumeInfiniteResult(queryParams, consumer, qp -> this.get(path, context, pathVariables, qp, type));
	}

	public <T> void consumeAllFromPostInfiniteResult(String path, ReqContext context, Map<String, Object> pathVariables, MultivaluedMap<String, Object> queryParams, Object requestBody,
			GenericType<InfiniteListResultsImpl<T>> type, Consumer<T> consumer) {
		doConsumeInfiniteResult(queryParams, consumer, qp -> this.post(path, context, pathVariables, qp, requestBody, type));
	}

	private <T> void doConsumeInfiniteResult(MultivaluedMap<String, Object> queryParams,
			Consumer<T> consumer, Function<MultivaluedMap<String, Object>, InfiniteListResultsImpl<T>> supplier) {
		if (queryParams == null) {
			queryParams = new MultivaluedHashMap<>();
		}

		String nextKey = null;
		do {
			queryParams.putSingle("nextKey", nextKey);
			queryParams.putSingle("next_key", nextKey);
			InfiniteListResultsImpl<T> infiniteListResults = supplier.apply(queryParams);

			for (T record : infiniteListResults.getRecords()) {
				consumer.accept(record);
			}
			nextKey = infiniteListResults.getNextKey();
		} while (nextKey != null);
	}

	public <T> InfiniteListResults<T> getInfiniteResult(String path, ReqContext context, Map<String, Object> pathVariables,
			MultivaluedMap<String, Object> queryParams, String nextKey,
			GenericType<InfiniteListResultsImpl<T>> type) {
		if (queryParams == null) {
			queryParams = new MultivaluedHashMap<>();
		}
		if (StringUtils.isNotBlank(nextKey)) {
			queryParams.putSingle("nextKey", nextKey);
			queryParams.putSingle("next_key", nextKey);
		}

		InfiniteListResultsImpl<T> infiniteListResults = this.get(path, context, pathVariables, queryParams, type);

		return infiniteListResults;

	}

	public byte[] getFile(String path, ReqContext context, Map<String, Object> pathVariables, MultivaluedMap<String, Object> queryParams) {
		return retryRegistry.retry(String.format("GET %s/%s", target.getUri().toString(), path))
				.executeSupplier(() -> this.getRequestBuilder(path, getHeaders(context), pathVariables, queryParams, MediaType.APPLICATION_OCTET_STREAM_TYPE)
						.get(byte[].class));
	}

	public InputStream getFileAsStream(String path, ReqContext context, Map<String, Object> pathVariables, MultivaluedMap<String, Object> queryParams) {
		return retryRegistry.retry(String.format("GET %s/%s", target.getUri().toString(), path))
				.executeSupplier(() -> this.getRequestBuilder(path, getHeaders(context), pathVariables, queryParams, MediaType.APPLICATION_OCTET_STREAM_TYPE)
						.get(InputStream.class));
	}

	public <T> T get(String path, ReqContext context, Map<String, Object> pathVariables, MultivaluedMap<String, Object> queryParams,
			GenericType<? extends T> type) {
		return retryRegistry.retry(String.format("GET %s/%s", target.getUri().toString(), path))
				.executeSupplier(() -> this.getRequestBuilder(path, getHeaders(context), pathVariables, queryParams)
						.get(type));
	}

	public <T> T post(String path, ReqContext context, Map<String, Object> pathVariables, MultivaluedMap<String, Object> queryParams, Object requestBody,
			GenericType<? extends T> type) {
		return retryRegistry.retry(String.format("POST %s/%s", target.getUri().toString(), path))
				.executeSupplier(() -> this.getRequestBuilder(path, getHeaders(context), pathVariables, queryParams)
						.post(Entity.json(requestBody == null ? Map.of() : requestBody), type));
	}

	public <T> T put(String path, ReqContext context, Map<String, Object> pathVariables, MultivaluedMap<String, Object> queryParams, Object requestBody,
			GenericType<? extends T> type) {
		return retryRegistry.retry(String.format("PUT %s/%s", target.getUri().toString(), path))
				.executeSupplier(() -> this.getRequestBuilder(path, getHeaders(context), pathVariables, queryParams)
						.put(Entity.json(requestBody == null ? Map.of() : requestBody), type));
	}

	public <T> Future<T> putAsync(String path, ReqContext context, Map<String, Object> pathVariables, MultivaluedMap<String, Object> queryParams, Object requestBody,
			GenericType<T> type) {
		return retryRegistry.retry(String.format("async PUT %s/%s", target.getUri().toString(), path))
				.executeSupplier(() -> this.getRequestBuilder(path, getHeaders(context), pathVariables, queryParams).async()
						.put(Entity.json(requestBody == null ? Map.of() : requestBody), type));
	}


	public <T> T patch(String path, ReqContext context, Map<String, Object> pathVariables, MultivaluedMap<String, Object> queryParams, Object requestBody,
			GenericType<? extends T> type) {
		return retryRegistry.retry(String.format("PATCH %s/%s", target.getUri().toString(), path))
				.executeSupplier(() -> this.getRequestBuilder(path, getHeaders(context), pathVariables, queryParams)
						.method("PATCH", Entity.json(requestBody == null ? Map.of() : requestBody), type));
	}

	public <T> T delete(String path, ReqContext context, Map<String, Object> pathVariables, MultivaluedMap<String, Object> queryParams,
			GenericType<? extends T> type) {
		return retryRegistry.retry(String.format("DELETE %s/%s", target.getUri().toString(), path))
				.executeSupplier(() -> this.getRequestBuilder(path, getHeaders(context), pathVariables, queryParams)
						.delete(type));
	}

	private Builder getRequestBuilder(String path, MultivaluedMap<String, Object> headers, Map<String, Object> pathVariables,
			MultivaluedMap<String, Object> queryParams) {
		return getRequestBuilder(path, headers, pathVariables, queryParams, MediaType.APPLICATION_JSON_TYPE);
	}

	private Builder getRequestBuilder(String path, MultivaluedMap<String, Object> headers, Map<String, Object> pathVariables,
			MultivaluedMap<String, Object> queryParams, MediaType mediaType) {
		WebTarget webTarget = target.path(path)
				.resolveTemplates(pathVariables == null ? new HashMap<>() : pathVariables);

		if (queryParams != null) {
			for (Entry<String, List<Object>> entry : queryParams.entrySet()) {
				webTarget = webTarget.queryParam(entry.getKey(), entry.getValue().toArray());
			}
		}

		WebTarget finalWebTarget = webTarget;

		Builder builder = finalWebTarget.request(mediaType);

		if (headers != null) {
			for (Entry<String, List<Object>> entry : headers.entrySet()) {
				if (entry.getValue() != null) {
					for (Object v : entry.getValue()) {
						builder = builder.header(entry.getKey(), v);
					}
				} else {
					builder = builder.header(entry.getKey(), null);
				}
			}
		}

		log.info("calling {}", webTarget);
		return builder;
	}

	private String getAuthorization(User user) {
		if (StringUtils.isNotBlank(user.getAuthToken())) {
			return String.format("%s %s", DEFAULT_PREFIX, user.getAuthToken());
		} else {
			return null;
		}
	}

	private MultivaluedHashMap getHeaders(ReqContext context) {
		MultivaluedHashMap headers = new MultivaluedHashMap<>();

		Optional.ofNullable(context)
				.map(ReqContext::getLang)
				.ifPresentOrElse(
						lang -> headers.add(HttpHeaders.ACCEPT_LANGUAGE, lang),
						() -> headers.add(HttpHeaders.ACCEPT_LANGUAGE, DEFAULT_LANG)
				);

		Optional.ofNullable(context)
				.map(ReqContext::getUser)
				.map(this::getAuthorization)
				.ifPresent(
						auth -> headers.add(HttpHeaders.AUTHORIZATION, auth)
				);

		return headers;
	}

	public static MultivaluedMap<String, Object> extractQueryParams(Object req) throws IllegalAccessException {
		MultivaluedMap<String, Object> paramsMap = new MultivaluedHashMap<>();

		for (Field field : req.getClass().getDeclaredFields()) {
			field.setAccessible(true);

			if (field.isAnnotationPresent(QueryParam.class)) {
				Class<?> fieldType = field.getType();
				QueryParam queryParam = field.getAnnotation(QueryParam.class);
				Object value = field.get(req);

				if (value != null) {
					if (fieldType.isArray()) {
						paramsMap.addAll(queryParam.value(), ((Object[]) value));
					} else if (Collection.class.isAssignableFrom(fieldType)) {
						paramsMap.addAll(queryParam.value(), new ArrayList<>((Collection<?>) value));
					} else {
						paramsMap.add(queryParam.value(), value);
					}
				}
			}
		}

		return paramsMap;
	}
}
