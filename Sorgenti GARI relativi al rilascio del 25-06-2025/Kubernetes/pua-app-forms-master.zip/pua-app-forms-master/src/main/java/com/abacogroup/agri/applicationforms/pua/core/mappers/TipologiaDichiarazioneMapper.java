package com.abacogroup.agri.applicationforms.pua.core.mappers;

import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;
import org.mapstruct.factory.Mappers;

import com.abacogroup.agri.applicationforms.pua.core.model.dto.TipologiaDichiarazioneDTO;
import com.abacogroup.agri.applicationforms.pua.db.ntt.TipologiaDichiarazioneNTT;
import com.abacogroup.jdbi.mapper.AbsoluteDateMapper;

/**
 * 
 * @author Emanuele Crocilla
 *
 */
@Mapper(uses = AbsoluteDateMapper.class)
public interface TipologiaDichiarazioneMapper extends EntityMapper<TipologiaDichiarazioneDTO, TipologiaDichiarazioneNTT> {

	TipologiaDichiarazioneMapper INSTANCE = Mappers.getMapper(TipologiaDichiarazioneMapper.class);

	@InheritInverseConfiguration()
	@Mapping(source = "flLivestocks", target = "flLivestocks", qualifiedByName = "shortToBoolean")
	@Mapping(source = "flOrganicFert", target = "flOrganicFert", qualifiedByName = "shortToBoolean")
    TipologiaDichiarazioneDTO entityToDto(TipologiaDichiarazioneNTT entity);

	@Mapping(source = "applicationId", target = "applicationId")
	@Mapping(source = "flLivestocks", target = "flLivestocks", qualifiedByName = "booleanToShort")
	@Mapping(source = "flOrganicFert", target = "flOrganicFert", qualifiedByName = "booleanToShort")
	@Mapping(source = "year", target = "year")
	@Mapping(source = "dtInsert", target = "dtInsert")
	@Mapping(source = "dtDelete", target = "dtDelete")
	@Mapping(source = "userIdInsert", target = "userIdInsert")
	@Mapping(source = "userIdDelete", target = "userIdDelete")
	TipologiaDichiarazioneNTT dtoToEntity(TipologiaDichiarazioneDTO dto);
	
	@Named("shortToBoolean")
	default boolean shortToBoolean(short value) {
		return value != 0;
	}

	@Named("booleanToShort")
	default short booleanToShort(boolean value) {
		return value ? (short) 1 : (short) 0;
	}

}
