package com.abacogroup.agri.applicationforms.pua.services.common;

import java.util.List;

import com.abacogroup.agri.applicationforms.pua.db.dao.I18NDAO;
import com.abacogroup.agri.applicationforms.pua.db.ntt.applications.RsI18N;

/**
 * @author Gennaro Tamburrelli
 */
public class I18NService {

	private final I18NDAO i18NDAO;

	public I18NService(I18NDAO i18NDAO) {
		this.i18NDAO = i18NDAO;
	}

	public void insertI18N(String tenant, String table, String fieldName, String lang, String typeCode, String i18nText) {
		this.i18NDAO.insertI18N(tenant, table, fieldName, typeCode, lang, i18nText);
	}

	public void deleteI18N(String tenant, String table, String fieldName, String typeCode, String lang) {
		this.i18NDAO.deleteI18N(tenant, table, fieldName, typeCode, lang);
	}

	public RsI18N getI18NByLang(String tenant, String table, String fieldName, String lang, String typeCode) {
		return this.i18NDAO.getI18NByLang(tenant, table, fieldName, typeCode, lang)
				.stream()
				.findFirst()
				.orElse(null);
	}

	public List<RsI18N> getAllI18NbyCode(String tenant, String table, String typeCode) {
		return this.i18NDAO.getAllI18N(tenant, table, typeCode);
	}

	public RsI18N getI18NReasonCode(String tenant, String reasonCode){
		return this.i18NDAO.getI18NReasonCode(tenant, reasonCode);
	}

	public void deleteAllI18NbyCode(String tenant, String table, String typeCode) {
		this.i18NDAO.deleteAllByCode(tenant, table, typeCode);
	}
}
