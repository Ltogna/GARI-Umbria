package com.abacogroup.agri.applicationforms.pua.db.ntt;

import java.util.Optional;

import com.abacogroup.agri.applicationforms.pua.db.ntt.applications.IIdRs;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

/**
 * @author Mauro Pozzana
 */
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class AttachmentTypeNTT implements IIdRs<Long> {

	private Long pkid;
	private String attachment_group_code;
	private String tenant_id;
	private String code;
	private String type_code;

	@Override
	public Optional<Long> getKey() {
		return Optional.ofNullable(getPkid());
	}

	@Override
	public void setKey(Long id) {
		setPkid(id);
	}
}
