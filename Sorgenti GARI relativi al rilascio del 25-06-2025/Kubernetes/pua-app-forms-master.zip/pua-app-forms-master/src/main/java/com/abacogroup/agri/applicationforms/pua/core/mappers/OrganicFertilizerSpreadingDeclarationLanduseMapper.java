package com.abacogroup.agri.applicationforms.pua.core.mappers;

import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import com.abacogroup.agri.applicationforms.pua.core.model.dto.OrganicFertilizerSpreadingDeclarationLanduseDTO;
import com.abacogroup.agri.applicationforms.pua.db.ntt.OrganicFertilizerSpreadingDeclarationLanduseNTT;
import com.abacogroup.jdbi.mapper.AbsoluteDateMapper;

/**
 * 
 * @author Emanuele Crocilla
 *
 */
@Mapper(uses = AbsoluteDateMapper.class)
public interface OrganicFertilizerSpreadingDeclarationLanduseMapper extends EntityMapper<OrganicFertilizerSpreadingDeclarationLanduseDTO, OrganicFertilizerSpreadingDeclarationLanduseNTT> {

	OrganicFertilizerSpreadingDeclarationLanduseMapper INSTANCE = Mappers.getMapper(OrganicFertilizerSpreadingDeclarationLanduseMapper.class);

	@InheritInverseConfiguration()
	OrganicFertilizerSpreadingDeclarationLanduseDTO entityToDto(OrganicFertilizerSpreadingDeclarationLanduseNTT entity);

	OrganicFertilizerSpreadingDeclarationLanduseNTT dtoToEntity(OrganicFertilizerSpreadingDeclarationLanduseDTO dto);

}
