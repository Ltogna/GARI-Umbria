package com.abacogroup.agri.applicationforms.pua.bundles.model.attachmenttypes;

import java.util.ArrayList;
import java.util.List;

import com.abacogroup.agri.applicationforms.pua.core.model.attachmenttypes.BundleAttachmentTypesInDTO;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author Alexandru Paraschiv
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class BundleAttachmentTypesMessage {
	@Builder.Default
	private List<BundleAttachmentTypesInDTO> attachmentTypes = new ArrayList<>();
}
