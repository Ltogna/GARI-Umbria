package com.abacogroup.agri.applicationforms.pua.core.mappers;

import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import com.abacogroup.agri.applicationforms.pua.core.model.dto.AttachmentDTO;
import com.abacogroup.agri.applicationforms.pua.core.model.dto.AttachmentPublicDTO;

@Mapper
public interface AttachmentPublicMapper extends PublicMapper<AttachmentDTO, AttachmentPublicDTO> {

	AttachmentPublicMapper INSTANCE = Mappers.getMapper(AttachmentPublicMapper.class);

	@InheritInverseConfiguration()
	AttachmentDTO publicToDTO(AttachmentPublicDTO entity);

	@Mapping(source = "applicationId", target = "applicationId")
	@Mapping(source = "attachmentId", target = "attachmentId")
	@Mapping(source = "type", target = "type", ignore=true)
	@Mapping(source = "fileName", target = "fileName")
	@Mapping(source = "notes", target = "notes")
	@Mapping(source = "typeId", target = "typeId")
	@Mapping(source = "typeCode", target = "typeCode")
	@Mapping(source = "typeAttachmentGroupCode", target = "typeAttachmentGroupCode")
	@Mapping(source = "typeAttachmentCode", target = "typeAttachmentCode")
	@Mapping(source = "tenantId", target = "tenantId")
	@Mapping(source = "dtInsert", target = "dtInsert")
	AttachmentPublicDTO dtoToPublic(AttachmentDTO dto);
}
