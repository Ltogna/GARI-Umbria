package com.abacogroup.agri.applicationforms.pua.db.ntt;

import com.abacogroup.agri.applicationforms.pua.db.ntt.applications.IIdRs;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.OffsetDateTime;
import java.util.Optional;

/**
 * @author Emanuele Crocilla
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class OrganicFertilizerSpreadingDeclarationNTT implements IIdRs<Long> {

	private Long pkid;
	private Long applicationId;
	private Long id;
	private Long partyId;
	private String expectedDate;
	private String livestockEffluents;
	private String livestockEffluentsCodeUom;
	private String livestockEffluentsDescriptionUom;
	private BigDecimal livestockEffluentsQty;
	private String cropPlanVersion;
	private String sectorCode;
	private OffsetDateTime dtInsert;
	private OffsetDateTime dtDelete;
	private String userIdInsert;
	private String userIdDelete;
	private String giasFertilizerCode;

	//    private Collection<OrganicFertilizerSpreadingDeclarationLanduseNTT> landUses;

	@Override
	public void setKey(Long id) {
		setPkid(id);
	}

	@Override
	public Optional<Long> getKey() {
		return Optional.ofNullable(getPkid());
	}
}
