package com.abacogroup.agri.applicationforms.pua.core.model.dto;

import com.abacogroup.dynamicdocuments.bean.Document;
import com.abacogroup.dynamicdocuments.bean.DocumentDefinition;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author Alexandru Paraschiv
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DeclarationsWithDefinitionDTO {
	private Document document;
	private DocumentDefinition documentDefinition;
}
