package com.abacogroup.agri.applicationforms.pua;

import com.abacogroup.agri.applicationforms.pua.config.BundleConfig;
import com.abacogroup.agri.applicationforms.pua.config.RabbitMqConfig;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.dropwizard.client.JerseyClientConfiguration;
import io.dropwizard.core.Configuration;
import io.dropwizard.db.DataSourceFactory;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @author Emanuele Crocilla
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class ApplicationFormsModuleConfiguration extends Configuration {
	@Valid
	@NotNull
	@JsonProperty("database")
	private DataSourceFactory database;

	private boolean secureAuth;

	@Valid
	private Sso2Config sso2Config;

	private String sso2Url;
	private String fileStoreUrl;
	private String applicationsUrl;
	private String sso2TokenSecretAuth;
	private String attachmentBucket;
	private RabbitMqConfig rabbitmqConfig;
	private String bundleServiceId;
	private Boolean activateBundleConfig;
	private BundleConfig bundleConfig;
	private String partyRegistryUrl;
	private String vectorDataLayersUrl;
	private String bancheDatiUrl;
	private String giasBaseUrl;
	private String giasLoginToken;

	@NotEmpty
	private String cropPlanUrl;

	@NotEmpty
	private String lpisServerUrl;

	public DataSourceFactory getDatabase() {
		return database;
	}

	@Valid
	@NotNull
	@JsonProperty("jerseyClient")
	private JerseyClientConfiguration jerseyClientConfiguration = new JerseyClientConfiguration();

	@Data
	public static class Sso2Config {
		private String url;
		private String tasksAuthPhrase;
	}
}
