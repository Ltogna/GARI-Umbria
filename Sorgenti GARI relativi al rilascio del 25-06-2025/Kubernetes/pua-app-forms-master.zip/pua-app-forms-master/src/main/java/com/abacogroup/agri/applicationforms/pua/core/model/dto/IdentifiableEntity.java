package com.abacogroup.agri.applicationforms.pua.core.model.dto;

/**
 * @author Mauro Pozzana
 * @param <T> the identifier type
 */
public interface IdentifiableEntity<T> {
    T getId();
    void setId(T id);
}
