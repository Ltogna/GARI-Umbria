package com.abacogroup.agri.applicationforms.pua.core.model.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.time.OffsetDateTime;
import java.util.List;

/**
 * @author Emanuele Crocilla
 */
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
@Schema(description = "The Declaration On Sectors DTO")
public class DeclarationsOnSectorsDTO {

	@Schema(description = "The declaration id's")
	@JsonProperty("ids")
	private List<Long> ids;

	@JsonProperty(access = JsonProperty.Access.READ_ONLY)
	@Schema(description = "The application id")
	private Long applicationId;

	@Schema(description = "The sector code")
	private String sectorCode;

	@Schema(description = "The land use code")
	private String landUseCode;

	@Schema(description = "The area in square meters")
	private int areaSqm;

	@Schema(description = "The mas (massimale azoto)")
	private int mas;

	@Schema(description = "Is Imported")
	private boolean flImported;

	@Schema(description = "The fl zvn")
	private boolean flZvn;

	@Schema(description = "The insert date")
	@JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ssXXX")
	@JsonProperty(access = JsonProperty.Access.READ_ONLY)
	private OffsetDateTime dtInsert;

	@Schema(description = "The deleted date")
	@JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ssXXX")
	@JsonProperty(access = JsonProperty.Access.READ_ONLY)
	private OffsetDateTime dtDelete;

	@Schema(description = "The user id which inserted ")
	@JsonProperty(access = JsonProperty.Access.READ_ONLY)
	private String userIdInsert;

	@Schema(description = "The user id which deleted ")
	@JsonProperty(access = JsonProperty.Access.READ_ONLY)
	private String userIdDelete;

}
