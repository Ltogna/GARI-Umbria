package com.abacogroup.agri.applicationforms.pua.core.model.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class BalanceIndicesRootResponse {

	@JsonProperty("message")
	private String message;

	@JsonProperty("errore")
	private String errore;

	@JsonProperty("dati")
	private BalanceIndicesData dati;
}
