package com.abacogroup.agri.applicationforms.pua.core.exceptions;

/**
 * @author Mauro Pozzana
 */
public class FileStoreMetadataNotFoundException extends Exception {

	private static final long serialVersionUID = 1L;
	
    public FileStoreMetadataNotFoundException(String message) {
        super(message);
    }
}
