package com.abacogroup.agri.applicationforms.pua.core.model.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AppezzamentoRequest {

	@JsonProperty("Chiave_Appezzamento")
	private String Chiave_Appezzamento;

	@JsonProperty("N_Mas")
	private Double N_Mas;

	@JsonProperty("N_Fabbisogno")
	private Double N_Fabbisogno;
	@JsonProperty("ZVN")
	private Boolean ZVN;
	@JsonProperty("Ciclo_Principale")
	private Boolean Ciclo_Principale;
}
