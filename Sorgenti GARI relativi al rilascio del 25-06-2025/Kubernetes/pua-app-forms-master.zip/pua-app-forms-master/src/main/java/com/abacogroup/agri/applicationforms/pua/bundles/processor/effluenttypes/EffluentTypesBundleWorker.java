package com.abacogroup.agri.applicationforms.pua.bundles.processor.effluenttypes;

import java.util.List;

import com.abacogroup.agri.applicationforms.pua.bundles.model.effluenttype.BundleEffluentTypesMessage;
import com.abacogroup.agri.applicationforms.pua.core.exceptions.ObjectNotFoundRuntimeException;
import com.abacogroup.agri.applicationforms.pua.core.model.dto.EffluentDTO;
import com.abacogroup.agri.applicationforms.pua.services.EffluentCrudService;
import com.abacogroup.dropwizard.auth.sso2.User;

import lombok.extern.slf4j.Slf4j;

/**
 * 
 * @author Emanuele Crocilla
 *
 */
@Slf4j
public class EffluentTypesBundleWorker {

	private static final String BUNDLE = "BUNDLE";
	protected final EffluentCrudService service;

	public EffluentTypesBundleWorker(EffluentCrudService service) {
		this.service = service;
	}

	public void upsert(String tenantId, BundleEffluentTypesMessage message) {
		log.info("EffluentTypesBundleWorker: processing file with tenant {}", tenantId);
		message.getEffluentTypes()
				.stream()
				.forEachOrdered(effluent -> {
					try {
						update(tenantId, effluent);
					} catch (ObjectNotFoundRuntimeException exp) {
						log.info("effluent not found, inserting it");
						insert(tenantId, effluent);
					}
				});
	}
	
	private void update(String tenantId, EffluentDTO effluent) throws ObjectNotFoundRuntimeException {
		var existent = service.get(new User(BUNDLE), tenantId, null, effluent.getTypeCode());
		log.info("EffluentTypesBundleWorker: updating effluent with tenant {} " +
				"and typeCode {} and categoryCode {}  and fertilizerCategory {}  and fertilizerType {} ", tenantId,  
				existent.getTypeCode(), existent.getCategoryCode(), existent.getFertilizerCategory(), existent.getFertilizerType());
		service.update(BUNDLE, tenantId, existent);
	}
	
	public void insert(String tenantId, EffluentDTO input) {
		log.info("EffluentBundleWorker: inserting effluent with tenant {} "
				+ "and typeCode {} and categoryCode {}  and fertilizerCategory {}  and fertilizerType {} ", tenantId, 
				input.getTypeCode(), input.getCategoryCode(), input.getFertilizerCategory(), input.getFertilizerType());
		service.insert(BUNDLE, tenantId, EffluentDTO.builder()
				.categoryCode(input.getCategoryCode())
		    	.fertilizerCategory(input.getFertilizerCategory())
		    	.fertilizerType(input.getFertilizerType())
		    	.typeCode(input.getTypeCode())
				.build());
	}
	
	public void delete(String tenantId, List<EffluentDTO> inputs) {
		
		log.info("EffluentBundleWorker: deleting effluents with tenant {}", tenantId);
		
		try {

			inputs.forEach((input) -> {

				log.info("working on efflunent with typeCode {} and categoryCode {}  and fertilizerCategory {}  and fertilizerType {} ", 
						input.getTypeCode(), input.getCategoryCode(), input.getFertilizerCategory(), input.getFertilizerType());
				
				service.delete(BUNDLE, tenantId, input.getTypeCode());
			});
			

		} catch (Exception e) {
			log.error("error deleting effluent with tenant = " + tenantId, e);
		}
	}
}
