package com.abacogroup.agri.applicationforms.pua.db.ntt;

import java.util.Optional;

import com.abacogroup.agri.applicationforms.pua.db.keys.OptionParamKey;
import com.abacogroup.agri.applicationforms.pua.db.ntt.applications.IIdRs;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

/**
 * @author Mattia Perini
 */
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class OptionParamNTT implements IIdRs<OptionParamKey> {
	private Long option_config_id;
	private String attribute_name;
	private String attribute_value;

	@Override
	public void setKey(OptionParamKey key) {
		this.option_config_id = key.getOptionConfigId();
		this.attribute_name = key.getAttributeName();
	}

	@Override
	public Optional<OptionParamKey> getKey() {
		return Optional.ofNullable(OptionParamKey.builder()
						.optionConfigId(option_config_id)
						.attributeName(attribute_name)
				.build());
	}
}
