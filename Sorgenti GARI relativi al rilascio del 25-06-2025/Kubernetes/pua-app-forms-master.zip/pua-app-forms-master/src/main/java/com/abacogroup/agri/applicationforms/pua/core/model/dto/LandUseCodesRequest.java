package com.abacogroup.agri.applicationforms.pua.core.model.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 
 * @author Emanuele Crocilla
 *
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Schema(description = "The LandUse Codes DTO Request")
public class LandUseCodesRequest {
 
    @Schema(description = "The landuse codes")
    @JsonProperty("landuse_codes")
    private List<String> landuseCodes;
     
}
