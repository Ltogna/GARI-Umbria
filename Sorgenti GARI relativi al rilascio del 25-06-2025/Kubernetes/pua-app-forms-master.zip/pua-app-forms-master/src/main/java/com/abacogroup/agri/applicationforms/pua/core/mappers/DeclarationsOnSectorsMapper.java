package com.abacogroup.agri.applicationforms.pua.core.mappers;

import com.abacogroup.agri.applicationforms.pua.core.model.dto.DeclarationsOnSectorsDTO;
import com.abacogroup.agri.applicationforms.pua.db.ntt.DeclarationsOnSectorsNTT;
import com.abacogroup.agri.applicationforms.pua.util.GenericUtility;
import com.abacogroup.jdbi.mapper.AbsoluteDateMapper;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;
import org.mapstruct.factory.Mappers;

import java.util.Collections;
import java.util.List;

/**
 * @author Emanuele Crocilla
 */
@Mapper(uses = AbsoluteDateMapper.class)
public interface DeclarationsOnSectorsMapper extends EntityMapper<DeclarationsOnSectorsDTO, DeclarationsOnSectorsNTT> {

	DeclarationsOnSectorsMapper INSTANCE = Mappers.getMapper(DeclarationsOnSectorsMapper.class);

	@InheritInverseConfiguration()
	@Mapping(source = "pkid", target = "ids", qualifiedByName = "fromPkIdToIds")
	@Mapping(source = "flImported", target = "flImported", qualifiedByName = "shortToBoolean")
	@Mapping(source = "flZvn", target = "flZvn", qualifiedByName = "shortToBoolean")
	DeclarationsOnSectorsDTO entityToDto(DeclarationsOnSectorsNTT entity);

	@Mapping(source = "ids", target = "pkid", qualifiedByName = "fromIdsToPkId")
	@Mapping(source = "flImported", target = "flImported", qualifiedByName = "booleanToShort")
	@Mapping(source = "flZvn", target = "flZvn", qualifiedByName = "booleanToShort")
	DeclarationsOnSectorsNTT dtoToEntity(DeclarationsOnSectorsDTO dto);

	@Named("shortToBoolean")
	default boolean shortToBoolean(short value) {
		return value != 0;
	}

	@Named("booleanToShort")
	default short booleanToShort(boolean value) {
		return value ? (short) 1 : (short) 0;
	}

	@Named("stringToInt")
	default Integer stringToInt(String s) {
		return GenericUtility.isDigit(s) ? Integer.parseInt(s) : null;
	}

	@Named("intToString")
	default String intToString(Integer i) {
		return String.valueOf(i);
	}

	@Named("fromPkIdToIds")
	default List<Long> fromPkIdToIds(Long pkId) {
		return pkId == null ? null : Collections.singletonList(pkId);
	}

	@Named("fromIdsToPkId")
	default Long fromIdsToPkId(List<Long> ids) {
		return ids != null && !ids.isEmpty() ? ids.get(0) : null;
	}
}
