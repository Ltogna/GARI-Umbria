package com.abacogroup.agri.applicationforms.pua.core.model.attachmenttypes;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author Alexandru Paraschiv
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AttachmentTypesI18n {
		private String lang;
		private String code;
}