package com.abacogroup.agri.applicationforms.pua.bundles.processor.dyinamicdocumenttypes;

import org.jdbi.v3.core.Jdbi;

import com.abacogroup.agri.applicationforms.pua.bundles.BundleConstants;
import com.abacogroup.agri.applicationforms.pua.bundles.model.dynamicdocumenttype.BundleDynamicDocumentTypesMessage;
import com.abacogroup.bundles.listener.tenant.TenantMessage;
import com.abacogroup.bundles.listener.tenant.TenantMessageProcessor;

import lombok.extern.slf4j.Slf4j;

/**
 * @author Gennaro Tamburrelli
 */
@Slf4j
public class DynamicDocumentTypesNewTenantProcessor implements TenantMessageProcessor {

	protected final Jdbi jdbi;
	protected final DynamicDocumentTypesBundleWorker dynamicDocumentTypesBundleWorker;

	public DynamicDocumentTypesNewTenantProcessor(Jdbi jdbi, DynamicDocumentTypesBundleWorker dynamicDocumentTypesBundleWorker) {
		this.jdbi = jdbi;
		this.dynamicDocumentTypesBundleWorker = dynamicDocumentTypesBundleWorker;
	}

	@Override
	public void onMessage(TenantMessage message) {
		jdbi.useTransaction(handle -> checkAndInsertDocument(message.getTenantId()));
	}

	private void checkAndInsertDocument(String tenantId) {
		log.info("DynamicDocumentTypesNewTenantProcessor: processing file with tenant {}", tenantId);
		var service = dynamicDocumentTypesBundleWorker.exposeAPPFDynamicDocumentService();
		dynamicDocumentTypesBundleWorker.upsert(tenantId, BundleDynamicDocumentTypesMessage.builder()
				.documentTypes(service.getDocumentDefinitionByTenant(BundleConstants.TENANT_TEMPLATE_CODE))
				.build());
	}

}
