package com.abacogroup.agri.applicationforms.pua.bundles.processor.attachmenttypes;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.jdbi.v3.core.Jdbi;

import com.abacogroup.agri.applicationforms.pua.bundles.BundleConstants;
import com.abacogroup.agri.applicationforms.pua.bundles.model.attachmenttypes.BundleAttachmentTypesMessage;
import com.abacogroup.agri.applicationforms.pua.core.model.attachmenttypes.AttachmentTypesI18n;
import com.abacogroup.agri.applicationforms.pua.core.model.attachmenttypes.BundleAttachmentTypesInDTO;
import com.abacogroup.agri.applicationforms.pua.db.ntt.applications.RsI18N;
import com.abacogroup.agri.applicationforms.pua.services.AttachmentTypesCrudService;
import com.abacogroup.bundles.listener.tenant.TenantMessage;
import com.abacogroup.bundles.listener.tenant.TenantMessageProcessor;

import lombok.extern.slf4j.Slf4j;

/**
 * @author Alexandru Paraschiv
 */
@Slf4j
public class AttachmentTypesNewTenantProcessor implements TenantMessageProcessor {

	protected final Jdbi jdbi;
	protected final AttachmentTypesBundleWorker attachmentTypesBundleWorker;

	public AttachmentTypesNewTenantProcessor(Jdbi jdbi, AttachmentTypesBundleWorker attachmentTypesBundleWorker) {
		this.jdbi = jdbi;
		this.attachmentTypesBundleWorker = attachmentTypesBundleWorker;
	}

	@Override
	public void onMessage(TenantMessage message) {
		jdbi.useTransaction(handle -> checkAndInsertAttachmentType(message.getTenantId()));
	}

	private void checkAndInsertAttachmentType(String tenantId) {
		log.info("AttachmentTypesNewTenantProcessor: processing file with tenant {}", tenantId);
		var service = attachmentTypesBundleWorker.exposeAttachmentTypesCrudService();
		attachmentTypesBundleWorker.upsert(tenantId, BundleAttachmentTypesMessage.builder()
				.attachmentTypes(service.findByTenantId(BundleConstants.TENANT_TEMPLATE_CODE).stream()
						.map(at -> BundleAttachmentTypesInDTO.builder()
								.attachmentGroupCode(at.getAttachmentGroupCode())
								.typeCode(at.getTypeCode())
								.i18n(this.mapI18NList(BundleConstants.TENANT_TEMPLATE_CODE, at.getTypeCode()))
								.build())
						.collect(Collectors.toList()))
				.build());
	}

	private List<AttachmentTypesI18n> mapI18NList(String tenantId, String typeCode) {
		var mapLang = attachmentTypesBundleWorker.exposeAttachmentTypesCrudService()
				.getAllAttachmentTypesI18NByTenantAndCode(tenantId, typeCode)
				.stream()
				.collect(Collectors.groupingBy(RsI18N::getLang));
		List<AttachmentTypesI18n> records = new ArrayList<>();
		mapLang.forEach((lang, item) -> records.add(AttachmentTypesI18n.builder()
				.lang(lang)
				.code(extractI18NText(item, AttachmentTypesCrudService.ATTACHMENT_TYPE_I18N.CODE.getCode()))
				.build()));

		return records;
	}

	private String extractI18NText(List<RsI18N> items, String field) {
		return items
				.stream()
				.filter(x -> field.equals(x.getField_name()))
				.findFirst()
				.map(RsI18N::getI18n_text)
				.orElse(null);
	}

}
