package com.abacogroup.agri.applicationforms.pua.core.model.dto;

import com.abacogroup.agri.applicationforms.pua.core.model.AbsoluteDate;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.time.OffsetDateTime;

@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
@Schema(description = "No Spreading Period DTO")
public class NoSpreadingPeriodDTO {

	@Schema(description = "pkId")
	@JsonProperty("pkId")
	private Long pkId;

	@Schema(description = "Application ID")
	private Long applicationId;

	@Schema(description = "Effluent type")
	private String effluent;

	@Schema(description = "Start date of the prohibition period (yyyyMMdd)")
	private AbsoluteDate dayFrom;

	@Schema(description = "End date of the prohibition period (yyyyMMdd)")
	private AbsoluteDate dayTo;

	@Schema(description = "Insert timestamp")
	@JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ssXXX")
	@JsonProperty(access = JsonProperty.Access.READ_ONLY)
	private OffsetDateTime dtInsert;

	@Schema(description = "Logical delete timestamp")
	@JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ssXXX")
	@JsonProperty(access = JsonProperty.Access.READ_ONLY)
	private OffsetDateTime dtDelete;

	@Schema(description = "User who inserted the record")
	@JsonProperty(access = JsonProperty.Access.READ_ONLY)
	private String userIdInsert;

	@Schema(description = "User who deleted the record")
	@JsonProperty(access = JsonProperty.Access.READ_ONLY)
	private String userIdDelete;
}
