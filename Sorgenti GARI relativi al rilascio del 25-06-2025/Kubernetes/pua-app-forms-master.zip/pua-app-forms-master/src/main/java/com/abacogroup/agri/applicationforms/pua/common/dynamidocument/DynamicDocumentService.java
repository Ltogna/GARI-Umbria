package com.abacogroup.agri.applicationforms.pua.common.dynamidocument;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;

import com.abacogroup.agri.applicationforms.pua.core.exceptions.DocDefNotFoundRuntimeException;
import com.abacogroup.agri.applicationforms.pua.core.exceptions.DynamicDocumentRuntimeException;
import com.abacogroup.agri.applicationforms.pua.core.model.CompileStatusEnum;
import com.abacogroup.agri.applicationforms.pua.core.model.dto.AppfPuaDynamicDocumentsDTO;
import com.abacogroup.agri.applicationforms.pua.core.model.dto.ApplicationOptionDTO;
import com.abacogroup.agri.applicationforms.pua.core.model.dto.DeclarationsDTO;
import com.abacogroup.agri.applicationforms.pua.core.model.dto.DeclarationsWithDefinitionDTO;
import com.abacogroup.agri.applicationforms.pua.core.model.dto.OptionParamDTO;
import com.abacogroup.agri.applicationforms.pua.services.ApplicationOptionCrudService;
import com.abacogroup.agri.applicationforms.pua.services.OptionCatalogsCrudService;
import com.abacogroup.agri.applicationforms.pua.services.OptionConfigsCrudService;
import com.abacogroup.agri.applicationforms.pua.services.OptionParamCrudService;
import com.abacogroup.agri.applicationforms.pua.services.common.AppfPuaDynamicDocumentsCrudService;
import com.abacogroup.agri.applicationforms.pua.services.common.ApplicationFacadeService;
import com.abacogroup.agri.applicationforms.pua.util.CommonConstants;
import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.dynamicdocuments.bean.Document;
import com.abacogroup.dynamicdocuments.bean.DocumentDefinition;
import com.abacogroup.dynamicdocuments.bean.documentdefinition.fieldset.Field;
import com.abacogroup.dynamicdocuments.services.DocumentService;
import com.abacogroup.dynamicdocuments.services.DocumentTypeService;
import com.abacogroup.dynamicdocuments.services.SavedDocumentType;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.ObjectMapper;

import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;

/**
 * @author Alexandru Paraschiv
 */
@Slf4j
@AllArgsConstructor
public class DynamicDocumentService {

	private final DocumentService documentService;
	private final DocumentTypeService documentTypeService;
	private final OptionCatalogsCrudService optionCatalogsCrudService;
	private final OptionConfigsCrudService optionConfigsCrudService;
	private final OptionParamCrudService optionParamCrudService;
	private final AppfPuaDynamicDocumentsCrudService appfPuaDynamicDocumentsCrudService;
	private final ApplicationOptionCrudService applicationOptionCrudService;
	private final ApplicationFacadeService applicationFacadeService;

	public Long createDocumentInstance(String tenant, User user, Long applicationId,
				Document document, String documentCode, String compileStatusIdentifier,
					Boolean isDeclaration, CompileStatusEnum compileStatusEnum, Long formConfigId) {

		applicationFacadeService.verifyAcceptDispositiveCalls(user, tenant, applicationId, formConfigId);
		
		Long result = this.createDocumentInstance(tenant, documentCode, document, user.getUserId(), null, null);

		this.processCompileStatusForDeclarations(tenant, user, applicationId, document, documentCode, isDeclaration, 
				compileStatusIdentifier, compileStatusEnum);

		return result;
	}
	
	protected Long createDocumentInstance(String tenant, String documentCode, Document document, String userId) {
		return this.createDocumentInstance(tenant, documentCode, document, userId, null, null);
	}

	protected Long createDocumentInstance(String tenant, String documentCode, Document document, String userId, Long businessId, String label) {
		try {
			if (Optional.ofNullable(document).isEmpty()) {
				throw new IllegalStateException("Empty document");
			}
			return documentService.insertDocument(tenant, documentCode, document, userId, businessId, label);
		} catch (IllegalStateException e) {
			throw new DynamicDocumentRuntimeException(e.getMessage());
		}
	}

	protected void updateDocumentInstance(Long documentId, Document document, User user) {
		try {
			if (Optional.ofNullable(document).isEmpty()) {
				throw new IllegalStateException("Empty document");
			}
			documentService.updateDocument(documentId, document, user.getUserId());
		} catch (IllegalStateException e) {
			throw new DynamicDocumentRuntimeException(e.getMessage());
		}
	}

	protected Document findDocumentInstanceById(Long documentId) {
		try {
			return documentService.getDocumentFromId(documentId);
		} catch (IllegalStateException e) {
			throw new DynamicDocumentRuntimeException(e.getMessage());
		}
	}

	public SavedDocumentType saveDocumentType(String tenant, String username, DocumentDefinition def) throws IOException {
		ObjectMapper om = new ObjectMapper();
		om.setSerializationInclusion(JsonInclude.Include.NON_NULL);
		String jsonDef = om.writeValueAsString(def);
		return this.documentTypeService.saveDocumentType(tenant, jsonDef, username);
	}

	protected Optional<DocumentDefinition> getDocumentDefinitionByTenantAndCode(String tenant, String docCode) {
		return this.documentTypeService.getDocumentDefinition(tenant, docCode);
	}
	
	public List<DocumentDefinition> getDocumentDefinitionByTenant(String tenant) {
		
		return this.documentTypeService.getDocumentDefinitionCodes(tenant)
				.stream()
				.map(code -> this.getDocumentDefinitionByTenantAndCode(tenant, code))
				.filter(Optional::isPresent)
				.map(Optional::get)
				.toList();
	}

	protected boolean isCompiledDynamicDocument(String tenant, String documentCode, Long documentId) {
		Document document = this.findDocumentInstanceById(documentId);
		log.debug("document:{}", document);

		return isCompiledDynamicDocument(tenant, documentCode, document);
	}

	protected boolean isCompiledDynamicDocument(String tenant, String documentCode, @NotNull Document document) {
		DocumentDefinition documentDefinition = this.getDocumentDefinitionByTenantAndCode(tenant, documentCode).orElse(null);

		return isCompiledDynamicDocument(documentDefinition, document);
	}

	protected boolean isCompiledDynamicDocument(DocumentDefinition documentDefinition, Document document) {
		log.debug("documentDefinition:{}", documentDefinition);

		List<Field> documentDefinitionFields = new ArrayList<>();
		Optional.ofNullable(documentDefinition)
				.ifPresent(docDef -> docDef.getFieldSets().stream()
						.forEach(fieldSet -> documentDefinitionFields.addAll(fieldSet.getFields())));
		log.debug("documentDefinitionFields:{}", documentDefinitionFields);

		List<Boolean> result = new ArrayList<>();
		document.getFields().forEach((key, value) -> {
			Field matchingField = documentDefinitionFields.stream().filter(f -> f.getCode().equals(key))
					.findFirst().orElse(null);
			result.add(matchingFieldNotFound(matchingField) ||
					requiredFieldNotFound(matchingField) ||
					requiredFiedlFoundButIsFalse(matchingField) ||
					requiredFieldFoundAndIsTrueAndValueIsPresent(value, matchingField) ||
					Optional.ofNullable(value).isPresent());
		});
		log.debug("result:{}", result);
		return result.stream().allMatch(x -> x.equals(Boolean.TRUE));
	}

	private boolean requiredFieldFoundAndIsTrueAndValueIsPresent(Object value, Field matchingField) {
		return Boolean.TRUE.equals(matchingField.getRequired()) && Optional.ofNullable(value).isPresent();
	}

	private Boolean requiredFiedlFoundButIsFalse(Field matchingField) {
		return Optional.ofNullable(matchingField.getRequired()).map(Boolean.FALSE::equals).orElse(false);
	}

	private boolean requiredFieldNotFound(Field matchingField) {
		return Optional.ofNullable(matchingField.getRequired()).isEmpty();
	}

	private boolean matchingFieldNotFound(Field matchingField) {
		return Optional.ofNullable(matchingField).isEmpty();
	}

	protected DeclarationsWithDefinitionDTO getWaiverAdditionalDeclaration(String tenant, Long applicationId, Long optionConfigId, Long takeoverId) {
		if (optionConfigId == null)
			return null;

		return getDocumentCodeByOptionConfigIdAndAttributeName(tenant, optionConfigId, CommonConstants.WAIVER_DOCUMENT_CODE)
				.flatMap(docCode -> getDocumentDefinitionByTenantAndCode(tenant, docCode))
				.map(documentDefinition -> DeclarationsWithDefinitionDTO.builder()
                    .document(this.findByApplicationIdAndDocumentCodeAndTakeoverId(applicationId, documentDefinition.getCode(), takeoverId))
                    .documentDefinition(documentDefinition)
                    .build())
				.orElse(null);
	}

	private Optional<String> getDocumentCodeByOptionConfigIdAndAttributeName(String tenant, Long optionConfigId, String attributeName) {
		return this.optionParamCrudService.findByOptionConfigId(tenant, optionConfigId).stream()
				.filter(optionParamDTO -> attributeName.equalsIgnoreCase(optionParamDTO.getAttributeName()))
				.map(OptionParamDTO::getAttributeValue)
				.filter(StringUtils::isNotBlank)
				.findFirst();
	}

	protected Document findByApplicationIdAndDocumentCode(Long applicationId, String code) {
		AppfPuaDynamicDocumentsDTO dynDoc = appfPuaDynamicDocumentsCrudService.findByApplicationIdAndDocumentCode(applicationId, code);
		Long documentId = Optional.ofNullable(dynDoc).map(AppfPuaDynamicDocumentsDTO::getDocumentId).orElse(null);
		return Optional.ofNullable(documentId).map(this::findDocumentInstanceById).orElse(null);
	}

	protected Document findByApplicationIdAndDocumentCodeAndTakeoverId(Long applicationId, String code, Long takeoverId) {
		AppfPuaDynamicDocumentsDTO dynDoc = appfPuaDynamicDocumentsCrudService.findByApplicationIdAndDocumentCodeAndTakeoverId(applicationId, code, takeoverId);
		Long documentId = Optional.ofNullable(dynDoc).map(AppfPuaDynamicDocumentsDTO::getDocumentId).orElse(null);
		return Optional.ofNullable(documentId).map(this::findDocumentInstanceById).orElse(null);
	}

	protected void deleteDynamicDocumentByOptionCode(String tenant, Long applicationId, String optionCode, String attributeName,
												  Long takeoverId, User user) {
		Long optionId = optionCatalogsCrudService.findByOptionCode(tenant, optionCode).getId();
		Long optionConfigId = optionConfigsCrudService.findByOptionIdAndApplicationId(tenant, applicationId, optionId).getId();

		Optional<String> optDocumentCode = getDocumentCodeByOptionConfigIdAndAttributeName(tenant, optionConfigId, attributeName);

		Optional.ofNullable(applicationOptionCrudService.findByApplicationIdAndOptionCodeAndTakeoverId(tenant, applicationId, optionCode, takeoverId))
				.ifPresent(applicationOptionDTO -> {
					Long documentId = applicationOptionDTO.getDocumentId();

					if (Optional.ofNullable(documentId).isPresent() && optDocumentCode.isPresent()) {
						checkForDeleteDocument(applicationId, user, applicationOptionDTO, optDocumentCode.get(), documentId);
					} else {
						optDocumentCode.ifPresent(documentCode ->
								appfPuaDynamicDocumentsCrudService.deleteByApplicationIdAndDocumentCodeAndTakeoverId(applicationId, documentCode, takeoverId));
					}
				});
	}
	
	public DeclarationsWithDefinitionDTO getDeclarations(User user, String tenant, Long applicationId, Long formConfigId, String dynamicDocumentCode) {
        DeclarationsWithDefinitionDTO declarationsWithDefinitionDTO = new DeclarationsWithDefinitionDTO();
        Optional.ofNullable(appfPuaDynamicDocumentsCrudService.findByApplicationIdAndDocumentCode(applicationId, dynamicDocumentCode))
                .ifPresentOrElse(appfPuaDynamicDocumentsDTO -> {
                    declarationsWithDefinitionDTO.setDocument(findDocumentInstanceById(appfPuaDynamicDocumentsDTO.getDocumentId()));
                    declarationsWithDefinitionDTO.setDocumentDefinition(this.getDefinitionByDocumentCode(tenant, appfPuaDynamicDocumentsDTO.getDocumentCode()));
                }, () -> declarationsWithDefinitionDTO.setDocumentDefinition(
                        this.getDefinitionByDocumentCode(tenant, dynamicDocumentCode)));
        return declarationsWithDefinitionDTO;
    }

	protected DocumentDefinition getDefinitionByDocumentCode(String tenant, String documentCode) {
        return getDocumentDefinitionByTenantAndCode(tenant, documentCode)
                .orElseThrow(() -> new DocDefNotFoundRuntimeException("Document definition not found"));
    }
	
	public DeclarationsDTO insertOrUpdateDeclarations(String tenant, User user, Long applicationId,
			Document document, String documentCode, Boolean isDeclaration, 
				String compileStatusIdentifier, CompileStatusEnum compileStatusEnum, Long formConfigId) {

		applicationFacadeService.verifyAcceptDispositiveCalls(user, tenant, applicationId, formConfigId);

		DeclarationsDTO result = insertOrUpdateDeclarations(tenant, user, applicationId, document, documentCode);

		this.processCompileStatusForDeclarations(tenant, user, applicationId, document, documentCode, 
				isDeclaration, compileStatusIdentifier, compileStatusEnum);
		
		return result;
	}

    protected DeclarationsDTO insertOrUpdateDeclarations(String tenant, User user, Long applicationId,
            	Document document, String documentCode ) {
    	
        DeclarationsDTO declarationsDTO = new DeclarationsDTO();

        Optional.ofNullable(appfPuaDynamicDocumentsCrudService.findByApplicationIdAndDocumentCode(applicationId, documentCode))
                .ifPresentOrElse(appfPuaDynamicDocumentsDTO -> {
                    updateDocumentInstance(appfPuaDynamicDocumentsDTO.getDocumentId(), document, user);
                    declarationsDTO.setDocument(findDocumentInstanceById(appfPuaDynamicDocumentsDTO.getDocumentId()));
                }, () -> {
                    Long createdDocumentId = createDocumentInstance(tenant,
                            documentCode, document, user.getUserId());
                    AppfPuaDynamicDocumentsDTO created = appfPuaDynamicDocumentsCrudService.insert(AppfPuaDynamicDocumentsDTO.builder()
                            .applicationId(applicationId)
                            .documentId(createdDocumentId)
                            .documentCode(documentCode)
                            .build());
                    declarationsDTO.setDocument(findDocumentInstanceById(created.getDocumentId()));
                });

        return declarationsDTO;
    }

    protected DeclarationsDTO upsertDeclarations(String tenant, User user, Long applicationId, Document document, String documentCode) {
    	
    	log.debug("Invoking upsertDeclarations with params tenant:{} user:{} applicationId:{} document:{} documentCode:{}", tenant,
                user, applicationId, document, documentCode);
        return this.insertOrUpdateDeclarations(tenant, user, applicationId, document, documentCode);
    }

    public DeclarationsDTO upsertDeclarations(String tenant, User user, Long applicationId,
			Document document, String documentCode, Boolean isDeclaration, String compileStatusIdentifier, 
			CompileStatusEnum compileStatusEnum, Long formConfigId) {

		applicationFacadeService.verifyAcceptDispositiveCalls(user, tenant, applicationId, formConfigId);
		
		log.debug("Upserting document instance...");
		
		DeclarationsDTO result = insertOrUpdateDeclarations(tenant, user, applicationId, document, documentCode);
		
		log.debug("Upserted document instance:{}", result.getDocument());

		this.processCompileStatusForDeclarations(tenant, user, applicationId, result.getDocument(), documentCode, 
				isDeclaration, compileStatusIdentifier, compileStatusEnum);

		return result;
	}

	/*
	 * TODO should also check the additional columns (if mandatory)
	 */
	private void processCompileStatusForDeclarations(String tenant, User user, Long applicationId,
			Document document, String documentCode, Boolean isDeclaration,  String compileStatusIdentifier, 
					CompileStatusEnum compileStatusEnum) {

		log.debug("Invoked processCompileStatusForDeclarations with params tenant:{} user:{} applicationId:{}" +
				"document:{} documentCode:{} compileStatusIdentifier:{} compileStatusEnum:{}", tenant, user, applicationId,
				document, documentCode, compileStatusIdentifier, compileStatusEnum);

		CompileStatusEnum processedCompileStatus;

		boolean isDynamicDocumentCompleted = true;
		
		// the check with "isDynamicDocumentCompleted" has to be performed only for the checkList case (if null the default is a checklist)
		if (null == isDeclaration || isDeclaration) {
			isDynamicDocumentCompleted = isDynamicDocumentCompleted(tenant, documentCode, document);
		}

		if (isDynamicDocumentCompleted) {
			log.debug("Changing status to 'COMPLETED'");
			processedCompileStatus = CompileStatusEnum.COMPLETED;
		} else {
			log.debug("Changing status to 'IN_PROGRESS'");
			processedCompileStatus = CompileStatusEnum.IN_PROGRESS;
		}

		log.debug("Updating compile status...");
		applicationFacadeService.updateCompileStatus(user, tenant, applicationId, compileStatusIdentifier, processedCompileStatus);
	}

	private boolean isDynamicDocumentCompleted(String tenant, String documentCode, Document document) {

		log.debug("Checking if all mandatory fields are present and if at least one field has '1' value...");

		if (Optional.ofNullable(document).isEmpty()) {
			log.debug("CFM document is empty");
			return false;
		}

		boolean isDocumentCompleted = isCompiledDynamicDocument(tenant, documentCode, document)
				&& document.getFields().values().stream().anyMatch(x -> x.equals(NumberUtils.LONG_ONE) || x.equals(NumberUtils.INTEGER_ONE));

		log.debug("isDocumentCompleted: {}", isDocumentCompleted);

		return isDocumentCompleted;
	}
    
	private void checkForDeleteDocument(Long applicationId, User user, ApplicationOptionDTO applicationOptionDTO, String documentCode, Long documentId) {
		AppfPuaDynamicDocumentsDTO appfPuaDynamicDocument = appfPuaDynamicDocumentsCrudService.findByApplicationIdAndDocumentCode(applicationId, documentCode);

		// If the appfPuaDynamicDocument correspond to the documentId it should be deleted
		if (Optional.ofNullable(appfPuaDynamicDocument).isPresent() && appfPuaDynamicDocument.getDocumentId().equals(documentId)) {
			applicationOptionDTO.setDocumentId(null);
			applicationOptionCrudService.update(applicationOptionDTO.getPkid(), applicationOptionDTO, user.getUserId());

			appfPuaDynamicDocumentsCrudService.deleteByApplicationIdAndDocumentIdAndTakeoverId(applicationId, documentId, applicationOptionDTO.getTakeoverId());
		} else if (Optional.ofNullable(appfPuaDynamicDocument).isPresent()) {
			appfPuaDynamicDocumentsCrudService.deleteByApplicationIdAndDocumentCodeAndTakeoverId(applicationId, documentCode, applicationOptionDTO.getTakeoverId());
		}
	}
}
