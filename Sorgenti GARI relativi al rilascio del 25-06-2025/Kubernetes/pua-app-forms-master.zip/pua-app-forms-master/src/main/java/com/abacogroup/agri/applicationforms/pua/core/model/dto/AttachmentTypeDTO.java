package com.abacogroup.agri.applicationforms.pua.core.model.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

/**
 * @author Mauro Pozzana
 */
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class AttachmentTypeDTO {
	private Long pkid;
	@Schema(description = "the attachment's group code")
	private String attachmentGroupCode;
	@Schema(description = "the application's tenant id")
	private String tenantId;
	private String code;
	private String typeCode;
}
