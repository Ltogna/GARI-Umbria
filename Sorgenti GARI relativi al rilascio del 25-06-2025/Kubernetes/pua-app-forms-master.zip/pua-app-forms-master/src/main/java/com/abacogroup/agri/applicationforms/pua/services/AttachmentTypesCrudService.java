package com.abacogroup.agri.applicationforms.pua.services;

import static com.abacogroup.agri.applicationforms.pua.util.PagingParamsFactory.DEFAULT_PAGE_SIZE;

import java.util.List;
import java.util.Locale;
import java.util.Optional;

import org.apache.commons.lang3.NotImplementedException;

import com.abacogroup.agri.applicationforms.pua.core.exceptions.ObjectNotFoundException;
import com.abacogroup.agri.applicationforms.pua.core.exceptions.ObjectNotFoundRuntimeException;
import com.abacogroup.agri.applicationforms.pua.core.mappers.AttachmentTypeMapper;
import com.abacogroup.agri.applicationforms.pua.core.model.dto.AttachmentTypeDTO;
import com.abacogroup.agri.applicationforms.pua.db.dao.AttachmentTypeDAO;
import com.abacogroup.agri.applicationforms.pua.db.dao.IGenericPuaDAO;
import com.abacogroup.agri.applicationforms.pua.db.ntt.AttachmentTypeNTT;
import com.abacogroup.agri.applicationforms.pua.db.ntt.applications.RsI18N;
import com.abacogroup.agri.applicationforms.pua.services.common.I18NService;
import com.abacogroup.agri.applicationforms.pua.services.common.crud.AbstractCrudService;
import com.abacogroup.jdbi.paging.InfiniteListResults;

import lombok.extern.slf4j.Slf4j;

/**
 * @author Mauro Pozzana
 */
@Slf4j
public class AttachmentTypesCrudService extends AbstractCrudService<AttachmentTypeNTT, Long, AttachmentTypeDTO, AttachmentTypeMapper, Void, IGenericPuaDAO<AttachmentTypeNTT, Long>> {

	public static final String I18N_ATTACHMENT_TYPES_TABLE = "appfpua_attachment_types";
	private final I18NService i18NService;

	public AttachmentTypesCrudService(IGenericPuaDAO<AttachmentTypeNTT, Long> dao, AttachmentTypeMapper mapper, I18NService i18NService) {
		super(dao, mapper);
		this.i18NService = i18NService;
	}

	@Override
	protected boolean hasPrimaryKey() {
		return true;
	}

	@Override
	protected Optional<AttachmentTypeNTT> findRsByCustomKey(Void customKey) {
		return Optional.empty();
	}

	@Override
	protected void deleteByCustomKey(Void customKey) {
		throw new NotImplementedException("Not implemented.");
	}

	@Override
	protected void setCustomSearchKey(AttachmentTypeNTT rs, Void customKey) {
		throw new NotImplementedException("Not implemented.");
	}

	public AttachmentTypeDTO findById(Long id) throws ObjectNotFoundException {
		log.info("Invoking find by id with id: {}", id);
		return this.findOutDtoByPrimaryKey(id);
	}

	public AttachmentTypeDTO insert(AttachmentTypeDTO in) {
		log.info("Invoking insert with params in: {}", in);
		return this.insert(in, null);
	}

	public AttachmentTypeDTO update(Long key, AttachmentTypeDTO in) {
		log.info("Invoking update with params key: {} in: {}", key, in);
		return this.update(key, in, null);
	}

	public void delete(Long key) {
		log.info("Invoking delete with params key: {}", key);
		this.delete(key, null);
	}

	public InfiniteListResults<AttachmentTypeDTO> findByTenantId(String tenantId, String nextKey) {
		log.info("Invoking findByTenantId with params tenantId:{}, nextKey:{}", tenantId, nextKey);
		return (returnInfiniteResults(
				this.dao.infinite(() -> ((AttachmentTypeDAO) this.dao).findInfiniteByTenantId(tenantId, Locale.ITALIAN.getLanguage()),
						nextKey,
						DEFAULT_PAGE_SIZE)));
	}

	public InfiniteListResults<AttachmentTypeDTO> findByTenantAttachmentGroup(String tenantId, String attachmentGroup, String nextKey) {
		log.info("Invoking findByTenantAttachmentGroup with params tenantId: {} attachmentGroup:{} " +
				"nextKey:{}", tenantId, attachmentGroup, nextKey);
		return (returnInfiniteResults(
				this.dao.infinite(() -> ((AttachmentTypeDAO) this.dao).findInfiniteByTenantIdAttachmentGroup(tenantId, attachmentGroup, Locale.ITALIAN.getLanguage()),
						nextKey,
						DEFAULT_PAGE_SIZE)));
	}

	public List<AttachmentTypeDTO> findByTenantAttachmentGroupFullList(String tenantId, String attachmentGroup) {
		log.info("InvokingfindByTenantAttachmentGroupFullList with params tenantId: {} attachmentGroup:{}", tenantId, attachmentGroup);
		return returnMappedList(((AttachmentTypeDAO) this.dao).findAllByTenantIdAttachmentGroup(tenantId, attachmentGroup, Locale.ITALIAN.getLanguage()));
	}

	public List<AttachmentTypeDTO> findByTenantId(String tenantId) {
		log.info("Invoking find by tenantId: {}", tenantId);
		return ((AttachmentTypeDAO) this.dao).findByTenantId(tenantId)
				.stream()
				.map(mapper::entityToDto)
				.toList();
	}

	public AttachmentTypeDTO findByCodeAndAttachmentGroupCode(String tenantId, String code, String groupCode) {
		log.info("Invoking find by Group Code And Attachment Code with tenant: {} code: {} groupCode: {}", tenantId, code, groupCode);
		return findOptByCodeAndAttachmentGroupCode(tenantId, code, groupCode)
				.orElseThrow(() -> new ObjectNotFoundRuntimeException("Document definition not found"));
	}

	public Optional<AttachmentTypeDTO> findOptByCodeAndAttachmentGroupCode(String tenantId, String code, String groupCode) {
		log.info("Invoking find by Group Code And Attachment Code with tenant: {} code: {} groupCode: {}", tenantId, code, groupCode);
		return ((AttachmentTypeDAO) this.dao).findByCodeAndAttachmentGroupCode(tenantId, code, groupCode, Locale.ITALIAN.getLanguage())
				.stream()
				.map(mapper::entityToDto)
				.findFirst();
	}
	public void insertAttachmentTypeI18N(String tenant, String typeCode, String lang, String description) {
		this.i18NService.insertI18N(tenant, I18N_ATTACHMENT_TYPES_TABLE, ATTACHMENT_TYPE_I18N.CODE.code, lang, typeCode, description);
	}

	public void deleteAttachmentTypesI18N(String tenant, String typeCode) {
		this.i18NService.deleteAllI18NbyCode(tenant, I18N_ATTACHMENT_TYPES_TABLE, typeCode);
	}

	public List<RsI18N> getAllAttachmentTypesI18NByTenantAndCode(String tenant, String code) {
		return this.i18NService.getAllI18NbyCode(tenant, I18N_ATTACHMENT_TYPES_TABLE, code);
	}

	public enum ATTACHMENT_TYPE_I18N {
		CODE("code");

		private final String code;

		ATTACHMENT_TYPE_I18N(String val) {
			this.code = val;
		}

		public String getCode() {
			return this.code;
		}
	}
}


