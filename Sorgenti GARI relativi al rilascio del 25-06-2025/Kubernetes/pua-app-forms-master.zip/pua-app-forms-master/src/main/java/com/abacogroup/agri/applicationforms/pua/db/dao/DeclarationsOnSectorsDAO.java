package com.abacogroup.agri.applicationforms.pua.db.dao;

import com.abacogroup.agri.applicationforms.pua.core.exceptions.ObjectNotFoundRuntimeException;
import com.abacogroup.agri.applicationforms.pua.db.ntt.DeclarationsOnSectorsNTT;
import com.abacogroup.agri.applicationforms.pua.services.common.FunctionalObject;
import com.abacogroup.jdbi.criteria.BindCriteria;
import com.abacogroup.jdbi.criteria.Criteria;
import com.abacogroup.jdbi.orderby.DefineOrder;
import com.abacogroup.jdbi.orderby.OrderBy;

import org.jdbi.v3.core.result.ResultIterator;
import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.customizer.BindBean;
import org.jdbi.v3.sqlobject.customizer.BindList;
import org.jdbi.v3.sqlobject.statement.SqlBatch;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;

import java.time.Instant;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.util.Calendar;
import java.util.List;

/**
 * @author Emanuele Crocilla
 */
public interface DeclarationsOnSectorsDAO extends IGenericPuaDAO<DeclarationsOnSectorsNTT, Long> {

	@SqlQuery("select * from appfpua_declarations_on_sectors where application_id = :application_id and dt_delete > §current_timestamp§ order by pkid")
	@RegisterBeanMapper(DeclarationsOnSectorsNTT.class)
	List<DeclarationsOnSectorsNTT> getByApplicationId(@Bind("application_id") Long applicationId);

	@SqlQuery("select count(*) from appfpua_declarations_on_sectors where application_id = :application_id and dt_delete > §current_timestamp§")
	@RegisterBeanMapper(DeclarationsOnSectorsNTT.class)
	int count(@Bind("application_id") Long applicationId);

	@SqlQuery("select count(*) from appfpua_declarations_on_sectors where pkid = :pkid and dt_delete > §current_timestamp§")
	@RegisterBeanMapper(DeclarationsOnSectorsNTT.class)
	int countByPkId(@Bind("pkid") Long pkid);

	@SqlQuery("select * from appfpua_declarations_on_sectors where pkid = :pkid and dt_delete > §current_timestamp§")
	@RegisterBeanMapper(DeclarationsOnSectorsNTT.class)
	DeclarationsOnSectorsNTT findByPkId(@Bind("pkid") Long pkid);

	@SqlQuery(""" 
			select * from appfpua_declarations_on_sectors 
				where application_id = :application_id 
					and sector_code = :sector_code
					and land_use_code = :land_use_code
					and dt_delete > §current_timestamp§ 
			""")
	@RegisterBeanMapper(DeclarationsOnSectorsNTT.class)
	DeclarationsOnSectorsNTT getByApplicationIdSectorCodeLandUseCode(
			@Bind("application_id") Long applicationId, @Bind("sector_code") String sectorCode, @Bind("land_use_code") String landUseCode);

	@SqlQuery(""" 
			select * from appfpua_declarations_on_sectors 
				where application_id = :application_id 
					and sector_code IN (<sector_codes>) 
					and land_use_code IN (<land_use_codes>)
					and dt_delete > §current_timestamp§ 
			""")
	@RegisterBeanMapper(DeclarationsOnSectorsNTT.class)
	List<DeclarationsOnSectorsNTT> getByApplicationIdSectorCodeLandUseCode(
			@Bind("application_id") Long applicationId, @BindList("sector_codes") List<String> sectorCodes,
			@BindList("land_use_codes") List<String> landUseCodes);

	@SqlQuery("select * from appfpua_declarations_on_sectors where application_id = :application_id and pkid = :declatation_id and dt_delete > §current_timestamp§ ")
	@RegisterBeanMapper(DeclarationsOnSectorsNTT.class)
	DeclarationsOnSectorsNTT getByApplicationIdAndDeclatationId(@Bind("application_id") Long applicationId, @Bind("declatation_id") Long pkid);

	@SqlQuery("select * from appfpua_declarations_on_sectors where sector_code = :sectorCode order by pkid")
	@RegisterBeanMapper(DeclarationsOnSectorsNTT.class)
	List<DeclarationsOnSectorsNTT> getBySectorCode(@Bind("sector_code") String sectorCode);

	@SqlQuery("select * from appfpua_declarations_on_sectors where land_use_code = :landUseCode order by pkid")
	@RegisterBeanMapper(DeclarationsOnSectorsNTT.class)
	List<DeclarationsOnSectorsNTT> getByLandUseCode(@Bind("land_use_code") String landUseCode);

	@SqlQuery("select * from appfpua_declarations_on_sectors where area_sqm = :areaSqm order by pkid")
	@RegisterBeanMapper(DeclarationsOnSectorsNTT.class)
	List<DeclarationsOnSectorsNTT> getByAreaSqm(@Bind("area_sqm") String areaSqm);

	@SqlQuery("select * from appfpua_declarations_on_sectors where mas = :mas order by pkid")
	@RegisterBeanMapper(DeclarationsOnSectorsNTT.class)
	List<DeclarationsOnSectorsNTT> getByMas(@Bind("mas") String mas);

	@SqlQuery("select * from appfpua_declarations_on_sectors where pkid in (<declatationIds>) order by pkid")
	@RegisterBeanMapper(DeclarationsOnSectorsNTT.class)
	List<DeclarationsOnSectorsNTT> getByIds(@BindList("declatationIds") List<Long> pkids);

	@Override
	@SqlUpdate("""
			    INSERT INTO appfpua_declarations_on_sectors 
			    (application_id, sector_code, land_use_code, area_sqm, mas, dt_insert, dt_delete, user_id_insert, user_id_delete, fl_imported, fl_zvn) 
			    VALUES(:applicationId, :sectorCode, :landUseCode, :areaSqm, :mas, :dtInsert, :dtDelete, :userIdInsert, :userIdDelete,:flImported, :flZvn);
			""")
	void insert(@BindBean DeclarationsOnSectorsNTT ntt);

	@SqlBatch("""
			    INSERT INTO appfpua_declarations_on_sectors 
			    (application_id, sector_code, land_use_code, area_sqm, mas, dt_insert, dt_delete, user_id_insert, user_id_delete, fl_imported, fl_zvn) 
			    VALUES(:applicationId, :sectorCode, :landUseCode, :areaSqm, :mas, :dtInsert, :dtDelete, :userIdInsert, :userIdDelete, :flImported, :flZvn);
			""")
	void insertBatch(@BindBean DeclarationsOnSectorsNTT[] ntts);

	@SqlQuery("""
			    SELECT EXISTS (
			        SELECT 1 
			        FROM appfpua_declarations_on_sectors 
			        WHERE application_id = :application_id 
			          AND fl_imported = 1 
			          AND dt_delete > §current_timestamp§ 
			    )
			""")
	boolean existsImport(
			@Bind("application_id") Long applicationId
	);

	@SqlUpdate("""
			update appfpua_declarations_on_sectors
			   set dt_delete=:dtDelete,
			       user_id_delete = :userIdDelete
			 where application_id=:applicationId 
			and pkid=:declatationId 
			   and §current_timestamp§ between dt_insert and dt_delete 
			""")
	void expire(@Bind("applicationId") Long applicationId, @Bind("declatationId") Long declatationId, @Bind("dtDelete") OffsetDateTime dtDelete,
			@Bind("userIdDelete") String userIdDelete);

	default void upsert(DeclarationsOnSectorsNTT nttToUpd) {

		// suppose that all ntts have the same application ID
		FunctionalObject<Long> applicationId = () -> nttToUpd != null ? nttToUpd.getApplicationId() : null;
		FunctionalObject<Long> nttId = () -> nttToUpd != null ? nttToUpd.getPkid() : null;

		if (nttToUpd != null && nttId.get() != null && this.countByPkId(nttId.get()) > 0) {

			String userIdInsert = nttToUpd.getUserIdInsert();
			long rightNow = Calendar.getInstance().getTimeInMillis();
			long rightNowMinusAMillis = rightNow - 1;

			Instant instantRightNow = Instant.ofEpochMilli(rightNow);
			Instant instantMinusAMillis = Instant.ofEpochMilli(rightNowMinusAMillis);

			OffsetDateTime dateTimeRightNow = instantRightNow.atOffset(ZoneOffset.UTC);
			OffsetDateTime dateTimeMinusAMillis = instantMinusAMillis.atOffset(ZoneOffset.UTC);

			nttToUpd.setDtInsert(dateTimeRightNow);

			useTransaction(dao -> {

				((DeclarationsOnSectorsDAO) dao).expire(applicationId.get(), nttId.get(), dateTimeMinusAMillis, userIdInsert);
				((DeclarationsOnSectorsDAO) dao).insert(nttToUpd);
			});
		} else {

			throw new ObjectNotFoundRuntimeException("Unable to find application id = " + applicationId.get() + " and pkId = " + nttId.get());
		}
	}

	default void upsertMany(List<DeclarationsOnSectorsNTT> nttsToUpd) {

		FunctionalObject<Long> applicationId = () -> nttsToUpd != null ? nttsToUpd.get(0).getApplicationId() : null;

		if (nttsToUpd != null && !nttsToUpd.isEmpty()) {

			String userIdInsert = nttsToUpd.get(0).getUserIdInsert();
			long rightNow = Calendar.getInstance().getTimeInMillis();
			long rightNowMinusAMillis = rightNow - 1;

			Instant instantRightNow = Instant.ofEpochMilli(rightNow);
			Instant instantMinusAMillis = Instant.ofEpochMilli(rightNowMinusAMillis);

			OffsetDateTime dateTimeRightNow = instantRightNow.atOffset(ZoneOffset.UTC);
			OffsetDateTime dateTimeMinusAMillis = instantMinusAMillis.atOffset(ZoneOffset.UTC);

			useTransaction(dao -> {

				Long oldPkId = null;
				DeclarationsOnSectorsNTT dbNtt = null;
				DeclarationsOnSectorsDAO dosDao = (DeclarationsOnSectorsDAO) dao;

				for (DeclarationsOnSectorsNTT ntt : nttsToUpd) {
					oldPkId = ntt.getPkid();
					dbNtt = dosDao.getByApplicationIdAndDeclatationId(applicationId.get(), oldPkId);
					if (dbNtt != null) {
						ntt.setDtInsert(dateTimeRightNow);
						dosDao.expire(applicationId.get(), oldPkId, dateTimeMinusAMillis, userIdInsert);
						dosDao.insert(ntt);
					}
				}
			});
		} else {

			throw new ObjectNotFoundRuntimeException("Unable to find application id = " + applicationId.get());
		}

	}

	@Override
	@SqlQuery("SELECT * FROM appfpua_declarations_on_sectors a WHERE a.pkid = :pkid")
	@RegisterBeanMapper(DeclarationsOnSectorsNTT.class)
	List<DeclarationsOnSectorsNTT> findById(@Bind("pkid") Long id);

	@RegisterBeanMapper(DeclarationsOnSectorsNTT.class)
	@SqlQuery(""" 
			SELECT * FROM appfpua_declarations_on_sectors 
			WHERE application_id = :application_id 
			AND <criteria>
			AND dt_delete > §current_timestamp§ 
			ORDER BY <orderBy>
			""")
	ResultIterator<DeclarationsOnSectorsNTT> searchDeclarationOnSectorssByFilter(@Bind("application_id") Long applicationId, 
			@BindCriteria("criteria") Criteria criteria, @DefineOrder("orderBy") OrderBy orderBy);

}
