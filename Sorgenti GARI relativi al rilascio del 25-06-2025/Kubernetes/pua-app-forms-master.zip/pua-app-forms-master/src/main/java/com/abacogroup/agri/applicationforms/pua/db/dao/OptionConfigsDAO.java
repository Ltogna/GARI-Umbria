package com.abacogroup.agri.applicationforms.pua.db.dao;

import java.util.List;

import org.jdbi.v3.sqlobject.config.RegisterArgumentFactory;
import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.config.RegisterColumnMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.customizer.BindBean;
import org.jdbi.v3.sqlobject.customizer.BindList;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;

import com.abacogroup.agri.applicationforms.pua.core.mappers.AbsoluteDateColumnMapper;
import com.abacogroup.agri.applicationforms.pua.core.model.AbsoluteDate;
import com.abacogroup.agri.applicationforms.pua.db.ntt.OptionConfigsNTT;
import com.abacogroup.agri.applicationforms.pua.db.ntt.OptionConfigsWithCodeNTT;
import com.abacogroup.jdbi.argument.AbsoluteDateArgumentFactory;

/**
 * @author Alexandru Paraschiv
 */
@RegisterArgumentFactory(AbsoluteDateArgumentFactory.class)
@RegisterColumnMapper(AbsoluteDateColumnMapper.class)
public interface OptionConfigsDAO extends IGenericPuaDAO<OptionConfigsNTT, Long> {

	@Override
	@SqlQuery("§select_nextval(appfpua_option_config_id_seq)§")
	Long nextSequenceVal();

	@Override
	@SqlUpdate("INSERT INTO appfpua_option_configs " +
			" (id, " +
			" option_id, " +
			" option_minimum_value, " +
			" option_row_minimum_engageable_value, " +
			" fl_full_engagement, " +
			" dt_validity_start, " +
			" dt_validity_end, " +
			" start_year, " +
			" nr_of_years, " +
			" fl_auto_compile) " +
			" VALUES(:id, :option_id, :option_minimum_value, :option_row_minimum_engageable_value, :fl_full_engagement, :dt_validity_start, :dt_validity_end, :start_year, :nr_of_years, :fl_auto_compile)")
	void insert(@BindBean OptionConfigsNTT ntt);

	@Override
	@SqlUpdate("UPDATE appfpua_option_configs " +
			" SET option_id = :option_id, " +
			" option_minimum_value = :option_minimum_value, " +
			" option_row_minimum_engageable_value = :option_row_minimum_engageable_value, " +
			" fl_full_engagement = :fl_full_engagement, " +
			" dt_validity_start = :dt_validity_start, " +
			" dt_validity_end = :dt_validity_end, " +
			" start_year = :start_year, " +
			" nr_of_years = :nr_of_years, " +
			" fl_auto_compile = :fl_auto_compile " +
			" WHERE id = :id")
	void update(@BindBean OptionConfigsNTT ntt);

	@Override
	@SqlQuery("SELECT foc.id," +
			" foc.option_id, " +
			" foc.option_minimum_value, " +
			" foc.option_row_minimum_engageable_value, " +
			" foc.fl_full_engagement, " +
			" foc.dt_validity_start, " +
			" foc.dt_validity_end, " +
			" foc.start_year, " +
			" foc.nr_of_years, " +
			" foc.fl_auto_compile " +
			" FROM appfpua_option_configs foc " +
			" WHERE id = :id")
	@RegisterBeanMapper(OptionConfigsNTT.class)
	List<OptionConfigsNTT> findById(@Bind("id") Long id);

	@SqlQuery("SELECT foc.id," +
			" foc.option_id, " +
			" foc.option_minimum_value, " +
			" foc.option_row_minimum_engageable_value, " +
			" foc.fl_full_engagement, " +
			" foc.dt_validity_start, " +
			" foc.dt_validity_end, " +
			" foc.start_year, " +
			" foc.nr_of_years, " +
			" foc.fl_auto_compile " +
			" FROM appfpua_option_configs foc " +
			" LEFT JOIN appfpua_OPTION_CATALOG oc ON foc.option_id = oc.id" +
			" WHERE oc.tenant_id = :tenant ")
	@RegisterBeanMapper(OptionConfigsNTT.class)
	List<OptionConfigsNTT> findByTenant(@Bind("tenant") String tenant);

	@SqlQuery("SELECT foc.id," +
			" foc.option_id, " +
			" foc.option_minimum_value, " +
			" foc.option_row_minimum_engageable_value, " +
			" foc.fl_full_engagement, " +
			" foc.dt_validity_start, " +
			" foc.dt_validity_end, " +
			" foc.start_year, " +
			" foc.nr_of_years, " +
			" foc.fl_auto_compile " +
			" FROM appfpua_option_configs foc " +
			" INNER JOIN appfpua_OPTION_CATALOG oc ON foc.option_id = oc.id" +
			" WHERE oc.tenant_id = :tenant " +
			" AND oc.option_code = :option_code " +
			" ORDER BY foc.dt_validity_end DESC")
	@RegisterBeanMapper(OptionConfigsNTT.class)
	List<OptionConfigsNTT> findByOptionCode(@Bind("tenant") String tenant,
			@Bind("option_code") String optionCode);

	@SqlQuery("SELECT foc.id," +
			" foc.option_id, " +
			" foc.option_minimum_value, " +
			" foc.option_row_minimum_engageable_value, " +
			" foc.fl_full_engagement, " +
			" foc.dt_validity_start, " +
			" foc.dt_validity_end, " +
			" foc.start_year, " +
			" foc.nr_of_years, " +
			" foc.fl_auto_compile " +
			" FROM appfpua_option_configs foc " +
			" INNER JOIN appfpua_OPTION_CATALOG oc ON foc.option_id = oc.id" +
			" WHERE oc.tenant_id = :tenant " +
			" AND oc.option_code in (<option_codes>)"+
			" AND :dtValidityEnd between foc.dt_validity_start and foc.dt_validity_end")
	@RegisterBeanMapper(OptionConfigsNTT.class)
	List<OptionConfigsNTT> findByOptionCodesAndDtValidityEnd(@Bind("tenant") String tenant,
			@BindList("option_codes") List<String> optionCodes, @Bind("dtValidityEnd") AbsoluteDate dtValidityEnd);

	@SqlQuery("SELECT foc.id," +
			" foc.option_id, " +
			" foc.option_minimum_value, " +
			" foc.option_row_minimum_engageable_value, " +
			" foc.fl_full_engagement, " +
			" foc.dt_validity_start, " +
			" foc.dt_validity_end, " +
			" foc.start_year, " +
			" foc.nr_of_years, " +
			" foc.fl_auto_compile " +
			" FROM appfpua_option_configs foc " +
			" WHERE foc.option_id =:option_id")
	@RegisterBeanMapper(OptionConfigsNTT.class)
	List<OptionConfigsNTT> findAllByOptionId(@Bind("option_id") Long optionId);

	@SqlQuery("SELECT foc.id," +
			" foc.option_id, " +
			" foc.option_minimum_value, " +
			" foc.option_row_minimum_engageable_value, " +
			" foc.fl_full_engagement, " +
			" foc.dt_validity_start, " +
			" foc.dt_validity_end, " +
			" foc.start_year, " +
			" foc.nr_of_years, " +
			" foc.fl_auto_compile " +
			" FROM appfpua_option_configs foc " +
			" INNER JOIN appfpua_OPTION_CATALOG oc ON foc.option_id = oc.id" +
			" WHERE oc.tenant_id = :tenant " +
			" AND oc.option_code = :option_code " +
			" AND :dtValidityEnd between foc.dt_validity_start and foc.dt_validity_end")
	@RegisterBeanMapper(OptionConfigsNTT.class)
	List<OptionConfigsNTT> findByOptionCodeAndDtValidityEnd(@Bind("tenant") String tenant,
			@Bind("option_code") String optionCode,
			@Bind("dtValidityEnd") AbsoluteDate dtValidityEnd);

	@SqlQuery	("SELECT foc.id," +
			" foc.option_id, " +
			" foc.option_minimum_value, " +
			" foc.option_row_minimum_engageable_value, " +
			" foc.fl_full_engagement, " +
			" foc.dt_validity_start, " +
			" foc.dt_validity_end, " +
			" foc.start_year, " +
			" foc.nr_of_years, " +
			" foc.fl_auto_compile " +
			" FROM appfpua_option_configs foc " +
			" LEFT JOIN appfpua_OPTION_CATALOG oc ON foc.option_id = oc.id " +
			" LEFT JOIN appfpua_APPLICATION_OPTIONS ao ON ao.option_config_id = foc.id " +
			" WHERE oc.tenant_id = :tenant" +
			" AND foc.option_id = :option_id " +
			" AND ao.application_id = :application_id " +
			" AND :dtValidity between foc.dt_validity_start and foc.dt_validity_end")
	@RegisterBeanMapper(OptionConfigsNTT.class)
	List<OptionConfigsNTT> findByApplicationIdOptionIdAndDtValidityEnd(@Bind("tenant") String tenant, @Bind("application_id") Long applicationId,
																	   @Bind("option_id") Long optionId, @Bind("dtValidity") AbsoluteDate dtValidity);

	@SqlQuery	("SELECT foc.id," +
			" foc.option_id, " +
			" foc.option_minimum_value, " +
			" foc.option_row_minimum_engageable_value, " +
			" foc.fl_full_engagement, " +
			" foc.dt_validity_start, " +
			" foc.dt_validity_end, " +
			" foc.start_year, " +
			" foc.nr_of_years, " +
			" foc.fl_auto_compile " +
			" FROM appfpua_option_configs foc " +
			" LEFT JOIN appfpua_OPTION_CATALOG oc ON foc.option_id = oc.id " +
			" LEFT JOIN appfpua_APPLICATION_OPTIONS ao ON ao.option_config_id = foc.id " +
			" WHERE oc.tenant_id = :tenant" +
			" AND foc.option_id = :option_id " +
			" AND ao.application_id = :application_id")
	@RegisterBeanMapper(OptionConfigsNTT.class)
	List<OptionConfigsNTT> findByApplicationIdOptionId(@Bind("tenant") String tenant, @Bind("application_id") Long applicationId,
													   @Bind("option_id") Long optionId);

	@Override
	@SqlUpdate("DELETE FROM appfpua_option_configs foc " +
			" WHERE foc.id = :id")
	void deleteById(@Bind("id") Long id);
	
	@SqlQuery("SELECT cat.option_code " +
			"FROM appfpua_option_catalog cat " +
			"LEFT JOIN appfpua_option_configs aoc ON aoc.OPTION_ID = cat.ID  " +
			"LEFT JOIN appfpua_APPLICATION_OPTIONS aao ON aao.OPTION_CONFIG_ID = aoc.ID  " +
			"WHERE cat.OPTION_CODE IN (<optionCodeList>) " +
			"AND aao.APPLICATION_ID = :application_id " +
			"AND :referenceDate between aoc.dt_validity_start and aoc.dt_validity_end " +
			"AND §current_timestamp§ BETWEEN aao.DT_INSERT AND aao.DT_DELETE " +
			"AND aoc.ID IN (SELECT aop.OPTION_CONFIG_ID " +
			"               FROM appfpua_OPTION_PARAMS aop " +
			"               WHERE aop.OPTION_CONFIG_ID = aoc.ID AND aop.ATTRIBUTE_VALUE IN (<paramValueList>)" +
			"               )")
	List<String> filterOptionCodesByParams(@Bind("tenant") String tenant, @Bind("application_id") Long applicationId, @Bind("referenceDate") AbsoluteDate dtValidity,
			@BindList(value = "optionCodeList") List<String> optionCodeList, @BindList(value = "paramValueList") List<String> paramValueList);

	@SqlQuery("SELECT aoc.option_code, " +
			" aoc2.id, " +
			" aoc2.option_minimum_value, " +
			" aoc2.option_row_minimum_engageable_value, " +
			" aoc2.fl_full_engagement, " +
			" aoc2.dt_validity_start, " +
			" aoc2.dt_validity_end, " +
			" aoc2.start_year, " +
			" aoc2.nr_of_years, " +
			" aoc2.fl_auto_compile " +
			" FROM appfpua_OPTION_CATALOG aoc " +
			" JOIN appfpua_option_configs aoc2 ON aoc.ID = AOC2.OPTION_ID " +
			" WHERE aoc.TENANT_ID = :tenant " +
			" AND :referenceDate between aoc2.dt_validity_start and aoc2.dt_validity_end")
	@RegisterBeanMapper(OptionConfigsWithCodeNTT.class)
	List<OptionConfigsWithCodeNTT> findConfigsDataByTenantAndReferenceDate(@Bind("tenant") String tenant, @Bind("referenceDate") AbsoluteDate dtValidity);

}
