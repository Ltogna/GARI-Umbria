package com.abacogroup.agri.applicationforms.pua.core.model.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author Alexandru Paraschiv
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AppfPuaDynamicDocumentsDTO {
	private Long id;
	private Long applicationId;
	private Long documentId;
	private String documentCode;
	private Long takeoverId;
}
