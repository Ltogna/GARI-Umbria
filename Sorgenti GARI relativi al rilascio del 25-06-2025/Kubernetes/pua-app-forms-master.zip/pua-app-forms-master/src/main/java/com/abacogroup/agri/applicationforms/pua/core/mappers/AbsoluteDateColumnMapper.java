package com.abacogroup.agri.applicationforms.pua.core.mappers;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.jdbi.v3.core.mapper.ColumnMapper;
import org.jdbi.v3.core.statement.StatementContext;

import com.abacogroup.agri.applicationforms.pua.core.model.AbsoluteDate;

public class AbsoluteDateColumnMapper implements ColumnMapper<AbsoluteDate>
{
	@Override
	public AbsoluteDate map(ResultSet r, int columnNumber, StatementContext ctx) throws SQLException
	{
		return new AbsoluteDate(r.getString(columnNumber));
	}
}
