package com.abacogroup.agri.applicationforms.pua.db.ntt;

import java.math.BigDecimal;
import java.time.OffsetDateTime;
import java.util.Optional;

import com.abacogroup.agri.applicationforms.pua.db.ntt.applications.IIdRs;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 
 * @author Emanuele Crocilla
 *
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DeclOnCropsPrevLivestockConsistenceNTT implements IIdRs<Long> {

    private Long pkid;                           // Primary key
    private Long declOnCropsLivestockConsistId;  // Identificativo logico
    private Long appfpuaDeclOnCropsPkid;         // pkid of appfpua_decl_on_crops row (parent id)
    private String animalSpecies;                // Specie animale
    private String animalCategory;               // Categoria animale
    private String housingSystem;                // Tipo stabulazione
    private Integer headOfLivestockNumb;         // N° capi allevati
    private BigDecimal averageLiveWeight;        // Peso vivo medio (P.v. medio)
    private Integer numberInTheField;            // N al campo
    private Integer liquidEfflLeavingStable;     // Liquami uscita stalla (m3)
    private Integer solidEffluentLeavingStable;  // Letami o palabili uscita stalla (t)
    private OffsetDateTime dtInsert;             // Insertion date
    private OffsetDateTime dtDelete;             // Logical deletion date
    private String userIdInsert;                 // Insertion user
    private String userIdDelete;                 // Logical deletion user

    @Override
	public void setKey(Long id) {
		setPkid(id);
	}

	@Override 
	public Optional<Long> getKey() {
		return Optional.ofNullable(getPkid());
	}

}
