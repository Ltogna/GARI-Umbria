package com.abacogroup.agri.applicationforms.pua.core.model.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.math.BigDecimal;
import java.time.OffsetDateTime;

/**
 * @author Emanuele Crocilla
 */
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
@Schema(description = "The Declaration On Crops Previous Effluents DTO")
public class DeclOnCropsPrevEffluentsDTO {

	@Schema(description = "The entity id")
	private Long id;

	@Schema(description = "The parent id")
	private Long parentId;

	@Schema(description = "The effluent")
	private String effluent;

	@Schema(description = "The measurement unit")
	private String measurementUnit;

	@Schema(description = "The quantity")
	private BigDecimal quantity;

	@Schema(description = "The nitrogen content")
	private BigDecimal nitrogenContent;

	@Schema(description = "The frequency")
	private String frequency;

	@Schema(description = "The reduction")
	private BigDecimal reduction;

	@Schema(description = "The residual number")
	private BigDecimal residualNitrogen;

	@Schema(description = "The insert date")
	@JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ssXXX")
	@JsonProperty(access = JsonProperty.Access.READ_ONLY)
	private OffsetDateTime dtInsert;

	@Schema(description = "The deleted date")
	@JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ssXXX")
	@JsonProperty(access = JsonProperty.Access.READ_ONLY)
	private OffsetDateTime dtDelete;

	@Schema(description = "The user id which inserted ")
	@JsonProperty(access = JsonProperty.Access.READ_ONLY)
	private String userIdInsert;

	@Schema(description = "The user id which deleted ")
	@JsonProperty(access = JsonProperty.Access.READ_ONLY)
	private String userIdDelete;

}
