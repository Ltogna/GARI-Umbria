package com.abacogroup.agri.applicationforms.pua.core.exceptions;

import jakarta.ws.rs.WebApplicationException;
import jakarta.ws.rs.core.Response;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=false)
public abstract class AbstractException extends WebApplicationException {
	 
	private static final long serialVersionUID = 1L;
	
	private final String code;
	private final String message;

	protected AbstractException(Response.Status status, ExceptionErrorBody body, String message) {
		super(message,
				Response.status(status).entity(new ApplicationsExceptionBody(body.getErrorCode(), message)).build());
		this.code = body.getErrorCode();
		this.message = message;
	}

	protected AbstractException(String errorCode, Response.Status status, Response response, String message) {
		super(message, response);
		this.code = errorCode;
		this.message = message;
	}

	public interface ExceptionErrorBody {
		String getErrorCode();
	}

	@Data
	public static class ApplicationsExceptionBody {

		private String errorCode;
		private String message;

		public ApplicationsExceptionBody(String errorCode, String message) {
			this.errorCode = errorCode;
			this.message = message;
		}
	}
}
