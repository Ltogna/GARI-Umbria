package com.abacogroup.agri.applicationforms.pua.services;

import java.util.Collections;
import java.util.List;
import java.util.Optional;

import com.abacogroup.agri.applicationforms.pua.core.exceptions.ObjectNotFoundException;
import com.abacogroup.agri.applicationforms.pua.core.mappers.ApplicationOptionMapper;
import com.abacogroup.agri.applicationforms.pua.core.model.dto.ApplicationOptionDTO;
import com.abacogroup.agri.applicationforms.pua.db.dao.ApplicationOptionDAO;
import com.abacogroup.agri.applicationforms.pua.db.ntt.ApplicationOptionNTT;
import com.abacogroup.agri.applicationforms.pua.services.common.crud.AbstractHistoricizationFieldsCrudService;

import lombok.extern.slf4j.Slf4j;

/**
 * @author Mattia Perini
 */
@Slf4j
public class ApplicationOptionCrudService extends AbstractHistoricizationFieldsCrudService<ApplicationOptionNTT, Long, ApplicationOptionDTO, ApplicationOptionMapper, Void> {


	public ApplicationOptionCrudService(ApplicationOptionDAO dao, ApplicationOptionMapper mapper) {
		super(dao, mapper);
	}

	@Override
	protected boolean hasPrimaryKey() {
		return true;
	}

	@Override
	protected Void retrieveCustomKeyByResultSet(ApplicationOptionNTT rs) {
		return null;
	}

	@Override
	protected ApplicationOptionNTT adjustR(ApplicationOptionNTT rs) {
		return rs;
	}

	@Override
	protected Optional<ApplicationOptionNTT> findRsByCustomKey(Void customKey) {
		return Optional.empty();
	}

	public ApplicationOptionDTO findById(Long id) throws ObjectNotFoundException {
		log.info("Invoking find by id with id: {}", id);
		return this.findOutDtoByPrimaryKey(id);
	}

	public List<ApplicationOptionDTO> findByApplicationId(String tenant, Long applicationId) {
		log.info("Invoking find by applicationId with id: {}", applicationId);
		return ((ApplicationOptionDAO) this.dao).findByApplicationId(tenant, applicationId).stream()
				.map(mapper::entityToDto)
				.toList();
	}

	public List<ApplicationOptionDTO> findExpiredByApplicationId(Long applicationId) {
		return ((ApplicationOptionDAO) this.dao).findExpiredByApplicationId(applicationId).stream()
				.map(mapper::entityToDto)
				.toList();
	}

	public List<ApplicationOptionDTO> findByApplicationIdAndTakeoverId(String tenant, Long applicationId, Long takeoverId) {
		log.info("Invoking find by applicationId with id: {}", applicationId);
		return ((ApplicationOptionDAO) this.dao).findByApplicationIdAndTakeoverId(tenant, applicationId, takeoverId).stream()
				.map(mapper::entityToDto)
				.toList();
	}

	public List<ApplicationOptionDTO> findByApplicationIdAndOptionCodes(String tenant, Long applicationId, List<String> optionCodes) {
		log.info("Invoking find by applicationId with id: {} optionCodes: {}", applicationId, optionCodes);

		if(Optional.ofNullable(optionCodes).isEmpty() || optionCodes.isEmpty()){
			return Collections.emptyList();
		}

		return ((ApplicationOptionDAO) this.dao).findByApplicationIdOptionCodes(tenant, applicationId, optionCodes).stream()
				.map(mapper::entityToDto)
				.toList();
	}

	public List<ApplicationOptionDTO> findByApplicationIdAndOptionCodesAndTakeoverId(String tenant, Long applicationId,
																					 List<String> optionCodes, Long takeoverId) {

		if(Optional.ofNullable(optionCodes).isEmpty() || optionCodes.isEmpty()){
			return Collections.emptyList();
		}

		return ((ApplicationOptionDAO) this.dao).findByApplicationIdOptionCodesAndTakeoverId(tenant, applicationId, optionCodes, takeoverId).stream()
				.map(mapper::entityToDto)
				.toList();
	}


	public List<ApplicationOptionDTO> findByApplicationIdAndOptionConfigId(String tenant, Long applicationId, Long optionConfigId) {
		log.info("Invoking find by applicationId with id: {} option config id: {}", applicationId, optionConfigId);
		return ((ApplicationOptionDAO) this.dao).findByApplicationIdOptionConfigId(tenant, applicationId, optionConfigId).stream()
				.map(mapper::entityToDto)
				.toList();
	}

	public ApplicationOptionDTO findByApplicationIdAndOptionCodeAndTakeoverId(String tenant, Long applicationId, String optionCode, Long takeoverId) {
		return ((ApplicationOptionDAO) this.dao).findByApplicationIdOptionCodesAndTakeoverId(tenant, applicationId, List.of(optionCode), takeoverId).stream()
				.map(mapper::entityToDto)
				.findFirst()
				.orElse(null);
	}

	public ApplicationOptionDTO findByApplicationIdAndOptionCode(String tenant, Long applicationId, String optionCode) {
		log.info("Invoking find by application id and option code with applicationId: {} optionCode: {}", applicationId, optionCode);
		return ((ApplicationOptionDAO) this.dao).findByApplicationIdOptionCode(tenant, applicationId, optionCode).stream()
				.map(mapper::entityToDto)
				.findFirst()
				.orElse(null);
	}

	public ApplicationOptionDTO insert(ApplicationOptionDTO in, String username) {
		log.info("Invoking insert with params in: {} username: {}", in, username);
		return this.insert(in, username, null, dao.getCurrentTimestamp());
	}

	public ApplicationOptionDTO update(Long key, ApplicationOptionDTO in, String username) {
		log.info("Invoking update with params key: {} in: {} username: {}", key, in, username);
		return this.update(key, in, username, null);
	}

	public void delete(Long key, String username) {
		log.info("Invoking delete with params key: {} username: {}", key, username);
		this.delete(key, username, null);
	}

	public void deleteByOptionConfigId(Long optionConfigId){
		log.info("Invoking deleteByOptionConfigId with params optionConfigId: {}", optionConfigId);
		((ApplicationOptionDAO)this.dao).deleteByOptionConfigId(optionConfigId);
	}

	public void deleteByTakeoverIdAndOptionConfigId(String tenant, Long applicationId, Long takeoverId, Long optionConfigId, String username) {
		log.info("Invoking deleteByTakeoverIdAndOptionConfigId with params tenant: {} applicationId: {} takeoverId: {} optionConfigId: {} username: {}",
				tenant, applicationId, takeoverId, optionConfigId, username);

		((ApplicationOptionDAO) this.dao).logicallyDeleteByTakeoverIdAndOptionConfigId(tenant, applicationId,
				takeoverId, optionConfigId, username, dao.getCurrentTimestamp());
	}

	public void logicallyDeleteByOptionConfigId(String tenant, Long applicationId, Long optionConfigId, String username) {
		log.info("Invoking deleteByOptionConfigId with params tenant: {} applicationId: {} optionConfigId: {} username: {}",
				tenant, applicationId, optionConfigId, username);

		((ApplicationOptionDAO) this.dao).logicallyDeleteOptionConfigId(tenant, applicationId, optionConfigId, username, dao.getCurrentTimestamp());
	}

	public void bulkDeleteByApplicationId(String tenant, Long applicationId, String name) {
		((ApplicationOptionDAO) this.dao).bulkLogicallyDeleteByApplicationId(tenant, applicationId, name);
	}
	public void deleteByApplicationIdExcludeOptionConfigIds(String tenant, Long applicationId, String name, List<Long> optionConfigIdsToExclude) {
		((ApplicationOptionDAO) this.dao).logicallyDeleteByApplicationIdExcludeOptionConfigIds(tenant, applicationId, name, optionConfigIdsToExclude);
	}

}

