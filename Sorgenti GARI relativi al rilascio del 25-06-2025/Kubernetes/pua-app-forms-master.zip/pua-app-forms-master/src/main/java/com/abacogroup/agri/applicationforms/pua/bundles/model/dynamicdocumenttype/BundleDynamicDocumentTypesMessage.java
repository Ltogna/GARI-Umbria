package com.abacogroup.agri.applicationforms.pua.bundles.model.dynamicdocumenttype;

import java.util.ArrayList;
import java.util.List;

import com.abacogroup.dynamicdocuments.bean.DocumentDefinition;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author Gennaro Tamburrelli
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class BundleDynamicDocumentTypesMessage {
	@Builder.Default
	private List<DocumentDefinition> documentTypes = new ArrayList<>();
}
