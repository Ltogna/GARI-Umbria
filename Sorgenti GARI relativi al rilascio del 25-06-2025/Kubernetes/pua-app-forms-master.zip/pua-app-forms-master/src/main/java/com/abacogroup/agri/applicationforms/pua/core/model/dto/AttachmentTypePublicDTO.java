package com.abacogroup.agri.applicationforms.pua.core.model.dto;

import com.fasterxml.jackson.annotation.JsonIgnore;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

/**
 * @author Mauro Pozzana
 */
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class AttachmentTypePublicDTO {
	@JsonIgnore
	private Long id;
	@Schema(description = "the attachment's group code")
	private String groupCode;
	@Schema(description = "the attachment's code")
	private String code;
	@Schema(description = "the attachment's type code")
	private String typeCode;
}
