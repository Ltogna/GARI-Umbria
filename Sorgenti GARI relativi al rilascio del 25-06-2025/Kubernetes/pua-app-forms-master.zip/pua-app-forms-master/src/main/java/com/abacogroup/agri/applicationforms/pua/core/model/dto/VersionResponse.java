package com.abacogroup.agri.applicationforms.pua.core.model.dto;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.NoArgsConstructor;

/**
 * 
 * @author Emanuele Crocilla
 *
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class VersionResponse {

	@JsonProperty("version")
	private String version;

	@JsonProperty("versionDate")
	private String versionDate;

	@JsonProperty("versionReferenceDate")
	private String versionReferenceDate;

	@JsonProperty("message")
	private String message;

	@JsonProperty("userId")
	private String userId;

	@JsonProperty("flPublished")
	private boolean flPublished;
	// Getters
	public String getVersion() {
		return version;
	}

	public String getVersionDate() {
		return versionDate;
	}

	public String getVersionReferenceDate() {
		return versionReferenceDate;
	}

	public String getMessage() {
		return message;
	}

	public String getUserId() {
		return userId;
	}

	public boolean isFlPublished() {
		return flPublished;
	}
}
