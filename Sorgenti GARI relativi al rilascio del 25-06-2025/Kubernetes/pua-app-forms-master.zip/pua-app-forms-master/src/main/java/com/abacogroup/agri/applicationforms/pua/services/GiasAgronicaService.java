package com.abacogroup.agri.applicationforms.pua.services;

import com.abacogroup.agri.applicationforms.pua.ApplicationFormsModuleConfiguration;
import com.abacogroup.agri.applicationforms.pua.core.exceptions.AgronicaGenericException;
import com.abacogroup.agri.applicationforms.pua.core.model.dto.AggiornaImpiantiNPua;
import com.abacogroup.agri.applicationforms.pua.core.model.dto.AgronicaResponse;
import com.abacogroup.agri.applicationforms.pua.core.model.dto.GiasTokenResponse;
import com.abacogroup.agri.applicationforms.pua.core.model.dto.OperazioniQdC;
import com.abacogroup.agri.applicationforms.pua.util.CommonConstants;
import com.abacogroup.agri.applicationforms.pua.util.JsonUtils;
import com.abacogroup.agri.applicationforms.pua.util.LogUtils;
import com.abacogroup.dropwizard.auth.sso2.Sso2Client;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.ws.rs.InternalServerErrorException;
import jakarta.ws.rs.client.*;
import jakarta.ws.rs.core.GenericType;
import jakarta.ws.rs.core.HttpHeaders;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.core.Response.Status.Family;
import lombok.extern.slf4j.Slf4j;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.List;
import java.util.Map;

/**
 * @author Emanuele Crocilla
 */
@Slf4j
public class GiasAgronicaService extends ADataImporterService {

	private final String giasLoginToken;
	private final WebTarget agronicaWebClient;

	public GiasAgronicaService(Sso2Client sso2client, Client client, ApplicationFormsModuleConfiguration config, ObjectMapper objectMapper) {

		super(sso2client, client, config, objectMapper);

		final List<Object> contentEncoding = List.of("identity");
		this.agronicaWebClient = client.target(config.getGiasBaseUrl());
		this.agronicaWebClient.register(new ClientRequestFilter() {
			@Override
			public void filter(ClientRequestContext requestContext) throws IOException {
				// Disable gzip on POST, it looks like the remote service doesn't like that
				requestContext.getHeaders().put(HttpHeaders.CONTENT_ENCODING, contentEncoding);
			}
		});

		//		this.agronicaWebClient = client.target(config.getGiasBaseUrl());
		this.giasLoginToken = config.getGiasLoginToken();
	}

	public AgronicaResponse<String> importOperazioniQdC(OperazioniQdC operazioniQdC) {

		var token = authenticateWithGias().getRispostaStringa();

		try {

			String datiInBase64 =
					Base64.getEncoder().encodeToString(operazioniQdC.getDati().getBytes(StandardCharsets.UTF_8));

			operazioniQdC.setDati(datiInBase64);

			AgronicaResponse<String> result = agronicaWebClient.path("/AgronicaCoreApi/NewAgri/Import/OperazioniQdC")
					.request(MediaType.APPLICATION_JSON)
					.header("Authorization", "Bearer " + token)
					.post(Entity.json(operazioniQdC), new GenericType<AgronicaResponse<String>>() {
					});

			result.validate();

			return result;
		} catch (InternalServerErrorException e) {
			log.warn("Error during import of operazioniQdC to GIAS Demetra for cuaa: {} ", operazioniQdC.getCuaa());
			throw e;
		}
	}

	public AgronicaResponse<String> importOperazioniQdCV2(OperazioniQdC operazioniQdC, String token) {
		AgronicaResponse<String> agronicaResp = null;

		try (Response res = agronicaWebClient.path("/AgronicaCoreApi/NewAgri/Import/OperazioniQdC")
				.request(MediaType.APPLICATION_JSON)
				.header(CommonConstants.AUTHORIZATION, CommonConstants.BEARER + token)
				.post(Entity.json(operazioniQdC))) {


			agronicaResp = res.readEntity(AgronicaResponse.class);
			

			return agronicaResp;
			
		}catch (Exception e) {
			log.warn("Error during execution of method importOperazioniQdCV2 to NewAgri for cuaa: {} ", operazioniQdC.getCuaa());
			LogUtils.logErrorServiceData(log, operazioniQdC, agronicaResp, agronicaWebClient, "/AgronicaCoreApi/NewAgri/Import/OperazioniQdC");
			throw new AgronicaGenericException(e.getMessage());
		}
	}

	// Authentication
	public GiasTokenResponse authenticateWithGias() {
		try (Response res = agronicaWebClient.path("/AgronicaCoreApi/Login/BackgroundAuthentication")
				.request(MediaType.APPLICATION_JSON)
				.post(Entity.json(Map.of("key", giasLoginToken)))) {

			if (res.getStatusInfo().getFamily() != Family.SUCCESSFUL) {
				String err = res.readEntity(String.class);
				throw new IllegalStateException(String.format("Error authenticating to GIAS, status %s, body=%s", res.getStatus(), err));
			}

			return res.readEntity(GiasTokenResponse.class);
		}
	}
	
	// https://<server_url>/AgronicaCoreApi/NewAgri/import/Aggiorna_Impianti_N_Pua
	public AgronicaResponse<Object> importAggiornaImpiantiNPua(AggiornaImpiantiNPua aggiornaImpianti, String token) {
		AgronicaResponse<Object> agronicaResp = null;

		try (Response res = agronicaWebClient.path("/AgronicaCoreApi/NewAgri/import/Aggiorna_Impianti_N_Pua")
				.request(MediaType.APPLICATION_JSON)
				.header(CommonConstants.AUTHORIZATION, CommonConstants.BEARER + token)
				.post(Entity.json(aggiornaImpianti))) {
			
		 	agronicaResp = res.readEntity(AgronicaResponse.class);

			return agronicaResp;
		}
		catch (Exception e) {
			log.warn("Error during import of AggiornaImpiantiNPua to NewAgri for cuaa: {} ", aggiornaImpianti.getCuaa());
			LogUtils.logErrorServiceData(log, aggiornaImpianti, agronicaResp, agronicaWebClient, "/AgronicaCoreApi/NewAgri/import/Aggiorna_Impianti_N_Pua");
			throw new AgronicaGenericException(e.getMessage());
		}
	}
}
