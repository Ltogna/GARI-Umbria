package com.abacogroup.agri.applicationforms.pua.util;

import com.abacogroup.agri.applicationforms.pua.core.model.dto.DeclarationsOnSectorsDTO;
import com.abacogroup.agri.applicationforms.pua.util.DeclarationsOnSectorsBuffer.DeclarationsOnSectorsBufferElement;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * @author Emanuele Crocilla
 */
public class DeclarationsOnSectorsBuffer extends HashMap<String, DeclarationsOnSectorsBufferElement> {

	private static final long serialVersionUID = 1L;

	private Long applicationId;
	private String userId;

	private static final String SEPARATOR = "||";

	public DeclarationsOnSectorsBuffer(Long applicationId, String userId) {
		this.applicationId = applicationId;
		this.userId = userId;
	}

	public DeclarationsOnSectorsBufferElement newElement(String domainZoneId, String landUse, int mas) {
		var newElement = new DeclarationsOnSectorsBufferElement(domainZoneId, landUse, mas);
		put(newElement.getIdentifier(), newElement);
		return newElement;
	}

	public DeclarationsOnSectorsBufferElement newElementOrExisting(String domainZoneId, String landUse, int mas) {

		if (!this.containsElement(domainZoneId, landUse)) {
			return this.newElement(domainZoneId, landUse, mas);
		}

		return this.getElement(domainZoneId, landUse);
	}

	public DeclarationsOnSectorsBufferElement getElement(String domainZoneId, String landUse) {
		return get(domainZoneId + SEPARATOR + landUse);
	}

	public List<DeclarationsOnSectorsDTO> getAllAsDeclarationsOnSectorsDTOs() {
		var res = new ArrayList<DeclarationsOnSectorsDTO>();

		this.forEach((k, v) -> {
			DeclarationsOnSectorsDTO declarationsOnSectorsDTO = DeclarationsOnSectorsDTO.builder()
					.applicationId(applicationId)
					.areaSqm((int) Math.round(v.usedAreaSqr))
					.sectorCode(v.domainZoneId)
					.landUseCode(v.landUse)
					.mas(v.mas)
					.flZvn(v.flZvn)
					.userIdInsert(userId)
					.userIdDelete("")
					.dtInsert(OffsetDateTime.now())
					.dtDelete(CommonConstants.FAR_OFF_DATE)
					.build();

			res.add(declarationsOnSectorsDTO);
		});
		return res;
	}

	public boolean containsElement(String domainZoneId, String landUse) {
		return this.containsKey(domainZoneId + SEPARATOR + landUse);
	}

	@Data
	@NoArgsConstructor
	public class DeclarationsOnSectorsBufferElement {

		private String domainZoneId;
		private String landUse;
		private String identifier;
		private int mas;
		private double usedAreaSqr = 0;
		private boolean flZvn;

		public DeclarationsOnSectorsBufferElement(String domainZoneId, String landUse, int mas) {
			this.identifier = domainZoneId + SEPARATOR + landUse;
			this.domainZoneId = domainZoneId;
			this.landUse = landUse;
			this.mas = mas;
		}

		public boolean isFlZvn() {
			return flZvn;
		}

		public void setFlZvn(boolean flZvn) {
			this.flZvn = flZvn;
		}

		public void addAreaSqr(double areaSqr, double areaPerc) {
			this.usedAreaSqr += areaSqr / 100 * areaPerc;
		}
	}

	@Override
	public boolean equals(Object o) {
		return super.equals(o);
	}

	@Override
	public int hashCode() {
		return super.hashCode();
	}

}

