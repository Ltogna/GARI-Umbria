package com.abacogroup.agri.applicationforms.pua.db.dao;

import java.time.LocalDateTime;
import java.util.List;

import org.jdbi.v3.core.result.ResultIterator;
import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.customizer.BindBean;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;

import com.abacogroup.agri.applicationforms.pua.db.ntt.AttachmentNTT;

/**
 * @author Mauro Pozzana
 */
public interface AttachmentDAO extends IGenericHistoricizationFieldsDAO<AttachmentNTT, Long, Void> {

	@Override
	@SqlQuery("§select_nextval(appfpua_attachments_id_seq)§")
	Long nextSequenceVal();

	@Override
	@SqlUpdate("INSERT INTO appfpua_attachments " +
			"(pkid, " +
			"application_id, " +
			"attachment_id, " +
			"bucket_id, " +
			"type, " +
			"file_name, " +
			"notes," +
			"user_id_insert, " +
			"dt_insert, " +
			"dt_delete) " +
			"VALUES(:pkid, :application_id, :attachment_id, :bucket_id, :type, :file_name, :notes, :user_id, :current_timestamp, TO_TIMESTAMP('9999-12-3123:59:59','YYYY-MM-DDHH24:MI:SS'))")
	void insert(@BindBean AttachmentNTT ntt, @Bind("user_id") String userId, @Bind("current_timestamp") LocalDateTime currentTimestamp);

	@Override
	@SqlUpdate("UPDATE appfpua_attachments " +
			"SET application_id = :application_id, " +
			"attachment_id = :attachment_id " +
			"bucket_id = :bucket_id " +
			"type = :type " +
			"file_name = :file_name " +
			"notes = :notes " +
			"user_id_insert = :user_id_insert " +
			"user_id_delete = :user_id_delete " +
			"dt_insert = :dt_insert " +
			"dt_delete = :dt_delete " +
			"WHERE pkid = :pkid ")
	void update(@BindBean AttachmentNTT ntt);

	@SqlQuery("select a.pkid," +
			"  a.application_id," +
			"  a.attachment_id," +
			"  a.bucket_id," +
			"  a.type," +
			"  a.file_name," +
			"  a.notes," +
			"  a.dt_insert," +
			"  a.dt_delete," +
			"  a.user_id_insert," +
			"  a.user_id_delete" +
			" from appfpua_attachments a" +
			" where a.pkid = :pkid")
	@RegisterBeanMapper(AttachmentNTT.class)
	List<AttachmentNTT> findById(@Bind("pkid") Long id);

	@Override
	@SqlUpdate("UPDATE appfpua_attachments SET " +
			"user_id_delete = :user_id_delete, dt_delete = :current_timestamp " +
			"WHERE pkid = :pkid " +
			"and §current_timestamp§ between dt_insert and dt_delete")
	void logicallyDeleteById(@Bind("pkid") Long id, @Bind("user_id_delete") String userDelete, @Bind("current_timestamp") LocalDateTime currentTimestamp);

	@SqlQuery("select a.pkid," +
			"  a.application_id," +
			"  a.attachment_id," +
			"  a.bucket_id," +
			"  a.type," +
			"  a.file_name," +
			"  a.notes," +
			"  a.dt_insert," +
			"  a.dt_delete," +
			"  a.user_id_insert," +
			"  a.user_id_delete," +
			"  at.pkid as type_id," +
			"  at.attachment_group_code as type_attachment_group_code," +
			"  §i18n(:tenant_id, 'appfpua_attachment_types', 'code', at.code, :lang)§ as type_attachment_code," +
			"  at.code as type_code," +
			"  at.tenant_id " +
			" from appfpua_attachments a" +
			" right join appfpua_ATTACHMENT_TYPES at ON a.type = at.pkid AND at.tenant_id = :tenant_id AND at.attachment_group_code = :attachment_group " +
			" where a.application_id = :application_id " +
			" and §current_timestamp§ between dt_insert and dt_delete")
	@RegisterBeanMapper(AttachmentNTT.class)
	ResultIterator<AttachmentNTT> findByApplicationId(@Bind("tenant_id") String tenant, @Bind("application_id") Long applicationId,
			@Bind("attachment_group") String attachmentGroup, @Bind("lang") String lang);

	@SqlQuery("select a.pkid," +
			"  a.application_id," +
			"  a.attachment_id," +
			"  a.bucket_id," +
			"  a.type," +
			"  a.file_name," +
			"  a.notes," +
			"  a.dt_insert," +
			"  a.dt_delete," +
			"  a.user_id_insert," +
			"  a.user_id_delete," +
			"  at.pkid as type_id," +
			"  at.attachment_group_code as type_attachment_group_code," +
			"  §i18n(:tenant_id, 'appfpua_attachment_types', 'code', at.code, :lang)§ as type_attachment_code," +
			"  at.code as type_code," +
			"  at.tenant_id " +
			" from appfpua_attachments a" +
			" right join appfpua_ATTACHMENT_TYPES at ON a.type = at.pkid AND at.tenant_id = :tenant_id AND at.attachment_group_code = :attachment_group " +
			" where a.application_id = :application_id " +
			" and §current_timestamp§ between dt_insert and dt_delete")
	@RegisterBeanMapper(AttachmentNTT.class)
	List<AttachmentNTT> findListByApplicationId(@Bind("tenant_id") String tenant, @Bind("application_id") Long applicationId,
			@Bind("attachment_group") String attachmentGroup, @Bind("lang") String lang);

	@SqlQuery("select a.pkid," +
			"  a.application_id," +
			"  a.attachment_id," +
			"  a.bucket_id," +
			"  a.type," +
			"  a.file_name," +
			"  a.notes," +
			"  a.dt_insert," +
			"  a.dt_delete," +
			"  a.user_id_insert," +
			"  a.user_id_delete," +
			"  at.pkid as type_id," +
			"  at.attachment_group_code as type_attachment_group_code," +
			"  §i18n(:tenant_id, 'appfpua_attachment_types', 'code', at.code, :lang)§ as type_attachment_code," +
			"  at.code as type_code," +
			"  at.tenant_id " +
			" from appfpua_attachments a" +
			" left join appfpua_ATTACHMENT_TYPES at ON a.type = at.pkid AND at.tenant_id = :tenant_id" +
			" where a.application_id = :application_id" +
			" and §current_timestamp§ between dt_insert and dt_delete")
	@RegisterBeanMapper(AttachmentNTT.class)
	ResultIterator<AttachmentNTT> findByApplicationId(@Bind("tenant_id") String tenant, @Bind("application_id") Long applicationId, @Bind("lang") String lang);

	@SqlQuery("select a.pkid," +
			"  a.application_id," +
			"  a.attachment_id," +
			"  a.bucket_id," +
			"  a.type," +
			"  a.file_name," +
			"  a.notes," +
			"  a.dt_insert," +
			"  a.dt_delete," +
			"  a.user_id_insert," +
			"  a.user_id_delete," +
			"  at.pkid as type_id," +
			"  at.attachment_group_code as type_attachment_group_code," +
			"  §i18n(:tenant_id, 'appfpua_attachment_types', 'code', at.code, :lang)§ as type_attachment_code," +
			"  at.code as type_code," +
			"  at.tenant_id " +
			" from appfpua_attachments a" +
			" left join appfpua_ATTACHMENT_TYPES at ON a.type = at.pkid AND at.tenant_id = :tenant_id" +
			" where a.application_id = :application_id AND a.attachment_id = :attachment_id" +
			" and §current_timestamp§ between dt_insert and dt_delete")
	@RegisterBeanMapper(AttachmentNTT.class)
	AttachmentNTT findByAttachmentId(@Bind("tenant_id") String tenant, @Bind("application_id") Long applicationId,
			@Bind("attachment_id") String attachmentId, @Bind("lang") String lang);
}
