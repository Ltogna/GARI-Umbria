package com.abacogroup.agri.applicationforms.pua.db.dao;

import java.time.Instant;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.util.Calendar;
import java.util.List;

import org.jdbi.v3.core.result.ResultIterator;
import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.customizer.BindBean;
import org.jdbi.v3.sqlobject.customizer.BindList;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;

import com.abacogroup.agri.applicationforms.pua.core.exceptions.ObjectNotFoundRuntimeException;
import com.abacogroup.agri.applicationforms.pua.db.ntt.EffluentNTT;

/**
 * 
 * @author Emanuele Crocilla
 *
 */
public interface EffluentDAO extends IGenericPuaDAO<EffluentNTT, Long> {

    @SqlQuery("SELECT * FROM appfpua_effluent WHERE category_code = :categoryCode and dt_delete > §current_timestamp§ ")
    @RegisterBeanMapper(EffluentNTT.class)
    List<EffluentNTT> getByCategoryCode(@Bind("categoryCode") String categoryCode);

    @SqlQuery("SELECT * FROM appfpua_effluent WHERE fertilizer_category = :fertilizerCategory and dt_delete > §current_timestamp§ ")
    @RegisterBeanMapper(EffluentNTT.class)
    List<EffluentNTT> getByFertilizerCategory(@Bind("fertilizerCategory") String fertilizerCategory);
    
    @SqlQuery("SELECT * FROM appfpua_effluent WHERE type_code = :typeCode and dt_delete > §current_timestamp§ ")
    @RegisterBeanMapper(EffluentNTT.class)
    EffluentNTT getByTypeCode(@Bind("typeCode") String typeCode);

    @SqlQuery("SELECT * FROM appfpua_effluent WHERE type_code IN (<typeCodes>) and dt_delete > §current_timestamp§ ")
    @RegisterBeanMapper(EffluentNTT.class)
    List<EffluentNTT> getByTypeCodes(@BindList("typeCodes") List<String> typeCodes);
    
    @SqlQuery("""
    		SELECT * FROM appfpua_effluent WHERE 
    		category_code = :categoryCode AND fertilizer_category = :fertilizerCategory
    		AND type_code = :typeCode AND dt_delete > §current_timestamp§ 
    		""")
    @RegisterBeanMapper(EffluentNTT.class)
    EffluentNTT get(@Bind("categoryCode") String categoryCode, @Bind("fertilizerCategory") String fertilizerCategory, @Bind("typeCode") String typeCode);
    
    @SqlQuery("SELECT * FROM appfpua_effluent WHERE dt_delete > §current_timestamp§")
    @RegisterBeanMapper(EffluentNTT.class)
	List<EffluentNTT> getAll();

    @SqlQuery("""
    		SELECT * FROM appfpua_effluent WHERE LOWER(fertilizer_type) like LOWER(CONCAT('%', :filter, '%')) 
    			AND dt_delete > §current_timestamp§ 
    		""")
    @RegisterBeanMapper(EffluentNTT.class)
    ResultIterator<EffluentNTT> searchInFertilizerType(@Bind("filter") String filter);
    
    @SqlQuery("SELECT * FROM appfpua_effluent WHERE pkid = :pkid")
    @RegisterBeanMapper(EffluentNTT.class)
    EffluentNTT getById(@Bind("pkid") Long pkid);

    @Override
    @SqlUpdate("""
                INSERT INTO appfpua_effluent (category_code, fertilizer_category, 
                type_code, fertilizer_type, dt_insert, dt_delete, user_id_insert, user_id_delete) 
                VALUES(:categoryCode, :fertilizerCategory, :typeCode, :fertilizerType, 
                :dtInsert, :dtDelete, :userIdInsert, :userIdDelete);
            """)
    void insert(@BindBean EffluentNTT ntt);

    @SqlUpdate("""
            update appfpua_effluent
               set dt_delete=:dtDelete,
                   user_id_delete = :userIdDelete
             WHERE type_code=:typeCode
               and §current_timestamp§ between dt_insert and dt_delete
            """)
    void expire(@BindBean EffluentNTT ntt);

    default void upsert(EffluentNTT ntt) {
    	
    	EffluentNTT nttExpired = getByTypeCode(ntt.getTypeCode());
    	
    	if (nttExpired != null) {
			
    		long rightNow = Calendar.getInstance().getTimeInMillis();
        	long rightNowMinusAMillis = rightNow-1;
        	
        	Instant instantRightNow = Instant.ofEpochMilli(rightNow);
        	Instant instantMinusAMillis = Instant.ofEpochMilli(rightNowMinusAMillis);
        	
        	OffsetDateTime dateTimeRightNow = instantRightNow.atOffset(ZoneOffset.UTC);
        	OffsetDateTime dateTimeMinusAMillis = instantMinusAMillis.atOffset(ZoneOffset.UTC);

        	nttExpired.setDtDelete(dateTimeMinusAMillis);
        	ntt.setDtInsert(dateTimeRightNow);

        	nttExpired.setUserIdDelete(ntt.getUserIdInsert());
        	
            useTransaction(dao -> {
            	((EffluentDAO)dao).expire(nttExpired);
            	((EffluentDAO)dao).insert(ntt);
            });
    		
		}
    	else {
    		
    		throw new ObjectNotFoundRuntimeException("Unable to find TypeCode = " + ntt.getTypeCode());
    	}
    }
    
    @Override
    @SqlQuery("SELECT * FROM appfpua_effluent a WHERE type_code=:typeCode ")
    @RegisterBeanMapper(EffluentNTT.class)
    List<EffluentNTT> findById(@Bind("pkid") Long id);
	boolean exists(EffluentNTT effluent);
    
}
