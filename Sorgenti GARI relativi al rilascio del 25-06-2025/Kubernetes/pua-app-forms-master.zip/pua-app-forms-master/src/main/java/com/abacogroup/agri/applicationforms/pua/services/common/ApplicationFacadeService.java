package com.abacogroup.agri.applicationforms.pua.services.common;

import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Optional;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import com.abacogroup.agri.applicationforms.pua.core.exceptions.OperationNotPermittedRuntimeException;
import com.abacogroup.agri.applicationforms.pua.core.exceptions.OptionCodeListNotValidRuntimeException;
import com.abacogroup.agri.applicationforms.pua.core.model.ApplicationKey;
import com.abacogroup.agri.applicationforms.pua.core.model.CompileStatusEnum;
import com.abacogroup.agri.applicationforms.pua.util.CommonConstants;
import com.abacogroup.applicationsupport.caller.DeleteCompileStatusCaller;
import com.abacogroup.applicationsupport.caller.GetApplicationByPartyYearModuleCodeCaller;
import com.abacogroup.applicationsupport.caller.GetApplicationDetailsCaller;
import com.abacogroup.applicationsupport.caller.GetApplicationPrintHistoryCaller;
import com.abacogroup.applicationsupport.caller.GetFormDetailsCaller;
import com.abacogroup.applicationsupport.caller.GetFormReadOnlyCaller;
import com.abacogroup.applicationsupport.caller.PutCompileStatusCaller;
import com.abacogroup.applicationsupport.caller.PutProfilesCaller;
import com.abacogroup.applicationsupport.model.io.callerinput.DeleteCompileStatusInput;
import com.abacogroup.applicationsupport.model.io.callerinput.GetApplicationByPartyYearModuleInput;
import com.abacogroup.applicationsupport.model.io.callerinput.GetApplicationDetailsInput;
import com.abacogroup.applicationsupport.model.io.callerinput.GetApplicationPrintHistoryInput;
import com.abacogroup.applicationsupport.model.io.callerinput.GetFormDetailsInput;
import com.abacogroup.applicationsupport.model.io.callerinput.GetReadOnlyInput;
import com.abacogroup.applicationsupport.model.io.callerinput.PutCompileStatusInput;
import com.abacogroup.applicationsupport.model.io.callerinput.PutProfilesInput;
import com.abacogroup.applicationsupport.model.io.output.ApplicationGeneratedPrintDTO;
import com.abacogroup.applicationworkflowsdk.model.io.output.ApplicationByPartyAndYearDTO;
import com.abacogroup.applicationworkflowsdk.model.io.output.ApplicationCompileStatusPayloadDTO;
import com.abacogroup.applicationworkflowsdk.model.io.output.ApplicationDetailsPublicDTO;
import com.abacogroup.applicationworkflowsdk.model.io.output.FormDetailsPublicDTO;
import com.abacogroup.applicationworkflowsdk.model.io.output.FormWithGroupHierarchyPublicDTO;
import com.abacogroup.dropwizard.auth.sso2.User;
import com.github.benmanes.caffeine.cache.Caffeine;
import com.github.benmanes.caffeine.cache.LoadingCache;

import jakarta.validation.constraints.NotNull;
import lombok.extern.slf4j.Slf4j;


/**
 * @author Gennaro Tamburrelli
 */
@Slf4j
public class ApplicationFacadeService {
    public static final String IT_LOCALE = "it";
    private final GetFormReadOnlyCaller getFormReadOnlyCaller;
    private final PutCompileStatusCaller putCompileStatusCaller;
    private final DeleteCompileStatusCaller deleteCompileStatusCaller;
    private final PutProfilesCaller putProfilesCaller;
    private final GetApplicationDetailsCaller getApplicationDetailsCaller;
    private final GetApplicationByPartyYearModuleCodeCaller getApplicationByPartyYearModuleCodeCaller;
    private final GetFormDetailsCaller getFormDetailsCaller;
    private final GetApplicationPrintHistoryCaller getApplicationPrintHistoryCaller;
    private final String applicationsBaseUrl;
    private final LoadingCache<ApplicationKey, List<FormWithGroupHierarchyPublicDTO>> formConfigListCache;
    
    public ApplicationFacadeService(ApplicationFacadeConfig o) {
    	this.getFormReadOnlyCaller = o.getFormReadOnlyCaller;
        this.putCompileStatusCaller = o.putCompileStatusCaller;
        this.deleteCompileStatusCaller = o.deleteCompileStatusCaller;
        this.putProfilesCaller = o.putProfilesCaller;
        this.getApplicationDetailsCaller = o.getApplicationDetailsCaller;
        this.getApplicationByPartyYearModuleCodeCaller = o.getApplicationByPartyYearModuleCodeCaller;
        this.getFormDetailsCaller = o.getFormDetailsCaller;
        this.getApplicationPrintHistoryCaller = o.getApplicationPrintHistoryCaller;
        this.applicationsBaseUrl = o.applicationsBaseUrl;

//      this.applicationDetailsCache = Caffeine.newBuilder()
//              .maximumSize(100L)
//              .expireAfterAccess(1, TimeUnit.SECONDS)
//              .build(key -> this.callForApplicationDetails(key.getTenant(), key.getApplicationId()));
      
      this.formConfigListCache = Caffeine.newBuilder()
              .maximumSize(100L)
              .expireAfterAccess(1, TimeUnit.SECONDS)
              .build(key -> this.callForFormConfigList(key.getTenant(), key.getApplicationId(), key.getAuthToken(), key.getLocale()));
      
//      this.moduleFormConfigListCache = Caffeine.newBuilder()
//              .maximumSize(100L)
//              .expireAfterAccess(1, TimeUnit.HOURS)
//              .build(key -> this.callForGetModuleConfigList(key.getTenant(), key.getModuleCode()));
    }

    public boolean cannotAcceptDispositiveCalls(@NotNull User user, @NotNull String tenant, @NotNull Long applicationId, @NotNull Long formConfigId) {
        return Boolean.TRUE.equals(
                this.getFormReadOnlyCaller.makeCall(GetReadOnlyInput.builder()
                                .applicationsBaseUrl(this.applicationsBaseUrl)
                                .authToken(CommonConstants.AUTH_PREFIX + user.getAuthToken())
                                .applicationId(applicationId)
                                .tenant(tenant)
                                .formConfigId(formConfigId)
                                .build())
                        .getReadOnly());

    }

    public void verifyAcceptDispositiveCalls(@NotNull User user, @NotNull String tenant, @NotNull Long applicationId, @NotNull Long formConfigId) {
        log.info("Verifying acceptability of dispositive calls for tenant {} applicationId {} formConfigId {}", tenant, applicationId, formConfigId);
        if (this.cannotAcceptDispositiveCalls(user, tenant, applicationId, formConfigId)) {
            throw new OperationNotPermittedRuntimeException();
        }
        log.info("dispositive calls for tenant {} applicationId {} formConfigId {} are acceptable", tenant, applicationId, formConfigId);
    }

    public boolean isFormReadOnly(@NotNull User user, @NotNull String tenant, @NotNull Long applicationId, @NotNull Long formConfigId) {
        return this.cannotAcceptDispositiveCalls(user, tenant, applicationId, formConfigId);
    }

    public Boolean hasForm(@NotNull User user, @NotNull String tenant, @NotNull Long applicationId, @NotNull String formCode, String locale) {
        return callForFormConfigList(user, tenant, applicationId, locale).stream()
                .map(FormWithGroupHierarchyPublicDTO::getFormDetails)
                .anyMatch(x -> x.getFormCode().equals(formCode));
    }

    public boolean isFormReadOnly(@NotNull User user, @NotNull String tenant, @NotNull Long applicationId, @NotNull String formCode, String locale) {
        return callForFormConfigList(user, tenant, applicationId, locale)
                .stream()
                .map(FormWithGroupHierarchyPublicDTO::getFormDetails)
                .filter(x -> x.getFormCode().equals(formCode))
                .anyMatch(x -> x.getFlReadOnly().equals(1));
    }

    public void updateCompileStatus(User user, String tenant, Long applicationId, String compileStatusIdentifier, CompileStatusEnum compileStatus, String locale) {
        updateCompileStatus(tenant, applicationId, compileStatusIdentifier, compileStatus, user, locale);
    }

    public void updateCompileStatus(User user, String tenant, Long applicationId, String compileStatusIdentifier, CompileStatusEnum compileStatus) {
    	updateCompileStatus(tenant, applicationId, compileStatusIdentifier, compileStatus, user, Locale.ITALIAN.getLanguage());
    }

    public void updateCompileStatus(String tenant, Long applicationId, String compileStatusIdentifier, CompileStatusEnum compileStatus,
                                    User user, String locale) {
        log.info("updating form compile status for tenant: {} applicationId: {} compileStatusIdentifier: {} compileStatus: {}",
                tenant, applicationId, compileStatusIdentifier, compileStatus);
        putCompileStatusCaller.makeCall(PutCompileStatusInput.builder()
                .applicationsBaseUrl(this.applicationsBaseUrl)
                .authToken(CommonConstants.AUTH_PREFIX + user.getAuthToken())
                .tenant(tenant)
                .applicationId(applicationId)
                .appCompileStatusIdentifier(compileStatusIdentifier)
                .payload(ApplicationCompileStatusPayloadDTO.builder()
                        .status(compileStatus.name())
                        .build())
                .locale(locale)
                .build());
    }
    
    public void deleteCompileStatus(User user, String tenant, Long applicationId, String compileStatusIdentifier) {
    	deleteCompileStatus(user, tenant, applicationId, compileStatusIdentifier, Locale.ITALIAN.getLanguage());
    }

    public void deleteCompileStatus(User user, String tenant, Long applicationId, String compileStatusIdentifier, String locale) {
    	
        log.info("deleting form compile status for tenant: {} applicationId: {} compileStatusIdentifier: {}",
                tenant, applicationId, compileStatusIdentifier);
        
        deleteCompileStatusCaller.makeCall(DeleteCompileStatusInput.builder()
                .applicationsBaseUrl(this.applicationsBaseUrl)
                .authToken(CommonConstants.AUTH_PREFIX + user.getAuthToken())
                .tenant(tenant)
                .applicationId(applicationId)
                .appCompileStatusIdentifier(compileStatusIdentifier)
                .locale(locale)
                .build());
    }

    public void updateProfiles(final User user, final String tenant, final Long applicationId, final List<String> profiles) {
        log.info("updating form profile for tenant: {} applicationId: {} list of profiles: {}", tenant, applicationId, profiles);
        putProfilesCaller.makeCall(PutProfilesInput.builder()
                .tenant(tenant)
                .applicationId(applicationId)
                .applicationsBaseUrl(this.applicationsBaseUrl)
                .authToken(CommonConstants.AUTH_PREFIX + user.getAuthToken())
                .profileCodeList(profiles)
                .build());
    }

    public ApplicationDetailsPublicDTO callForApplicationDetails(String tenant, Long applicationId, User user, String locale) {
        var input = GetApplicationDetailsInput.builder()
                .applicationId(applicationId)
                .tenant(tenant)
                .applicationsBaseUrl(this.applicationsBaseUrl)
                .authToken(CommonConstants.AUTH_PREFIX + user.getAuthToken())
                .locale(locale)
                .build();
        try {
            return getApplicationDetailsCaller.makeCall(input);
        } catch (Exception e) {
            log.error("error calling applications details with input {}", input);
            log.error(e.getMessage(), e);
            throw e;
        }
    }

    public List<ApplicationGeneratedPrintDTO> callForApplicationPrintHistory(String tenant, Long applicationId, User user, String locale) {
        return getApplicationPrintHistoryCaller.makeCall(GetApplicationPrintHistoryInput.builder()
                .applicationId(applicationId)
                .tenant(tenant)
                .applicationsBaseUrl(this.applicationsBaseUrl)
                .authToken(CommonConstants.AUTH_PREFIX + user.getAuthToken())
                .locale(locale)
                .build());
    }

    public List<ApplicationByPartyAndYearDTO> getApplicationsByPartyYearAndModuleCode(User user, String tenant, Long partyId, Integer year, String moduleCode, String locale) {
        return this.getApplicationByPartyYearModuleCodeCaller.makeCall(GetApplicationByPartyYearModuleInput
                .builder()
                .tenant(tenant)
                .partyId(partyId)
                .year(year)
                .moduleCode(moduleCode)
                .authToken(CommonConstants.AUTH_PREFIX + user.getAuthToken())
                .locale(locale)
                .build());
    }

    public List<ApplicationByPartyAndYearDTO> getPreviousYearApplications(User user, String tenant, Long partyId, Integer year, String moduleCode, String locale) {
        return this.getApplicationsByPartyYearAndModuleCode(user, tenant, partyId, year - 1, moduleCode, locale);
    }

    private List<FormWithGroupHierarchyPublicDTO> callForFormConfigList(User user, String tenant, Long applicationId, String locale) {
        return this.getFormDetailsCaller.makeCall(GetFormDetailsInput.builder()
                .tenant(tenant)
                .applicationId(applicationId)
                .locale(locale)
                .authToken(CommonConstants.AUTH_PREFIX + user.getAuthToken())
                .applicationsBaseUrl(this.applicationsBaseUrl)
                .build());
    }

    private List<FormWithGroupHierarchyPublicDTO> callForFormConfigList(String tenant, Long applicationId, String authToken, String locale) {
        return this.getFormDetailsCaller.makeCall(GetFormDetailsInput.builder()
                .tenant(tenant)
                .applicationId(applicationId)
                .locale(locale)
                .authToken(authToken)
                .applicationsBaseUrl(this.applicationsBaseUrl)
                .build());
    }

    public String retrieveAuthToken(User user) {
        return Optional.ofNullable(user).map(x -> CommonConstants.AUTH_PREFIX + x.getAuthToken()).orElse("null");
    }

    public List<FormWithGroupHierarchyPublicDTO> getFormConfigList(User user, String tenant, Long applicationId) {
        return this.formConfigListCache.get(ApplicationKey.builder()
                .tenant(tenant)
                .applicationId(applicationId)
                .authToken(CommonConstants.AUTH_PREFIX + user.getAuthToken())
                .locale(Locale.ITALIAN.getLanguage())
                .build());
    }

    public List<FormWithGroupHierarchyPublicDTO> getFormConfigListNoCache(User user, String tenant, Long applicationId, String locale) {
        return this.callForFormConfigList(user, tenant, applicationId, locale);
    }

    public List<FormWithGroupHierarchyPublicDTO> getFormConfigListNoCacheWithUser(String tenant, Long applicationId, User user, String locale) {
        return this.callForFormConfigList(user, tenant, applicationId, locale);
    }

    public String filterFormConfigList(User user, String tenant, Long applicationId, String compileStatusIdentifier, String key) {
        var formConfigList = this.getFormConfigList(user, tenant, applicationId);
        return formConfigList.stream()
                .map(FormWithGroupHierarchyPublicDTO::getFormDetails)
                .filter(x -> x.getCompileStatusIdentifier().equals(compileStatusIdentifier))
                .findFirst()
                .map(FormDetailsPublicDTO::getParams)
                .map(x -> x.get(key))
                .orElse(null);
    }

    public static final String ATTACHMENT_GROUP_KEY = "attachment_group";
    public static final String DOCUMENT_CODE_KEY = "document_code";

    public String getAttachmentGroupValue(User user, String tenant, Long applicationId, String compileStatusIdentifier) {
        return this.filterFormConfigList(user, tenant, applicationId, compileStatusIdentifier, ATTACHMENT_GROUP_KEY);
    }

    public String getDocumentCodeValue(User user, String tenant, Long applicationId, String compileStatusIdentifier) {
        return this.filterFormConfigList(user, tenant, applicationId, compileStatusIdentifier, DOCUMENT_CODE_KEY);
    }

    public static final String OPTION_CODES_KEY = "option_codes";

    public void verifyOptionCodeList(User user, String tenant, Long applicationId, List<String> optionCodeList, String formCode) {
        List<FormWithGroupHierarchyPublicDTO> formConfigList = this.getFormConfigList(user, tenant, applicationId).stream()
                .filter(formConfig -> Optional.ofNullable(formCode).isPresent() &&
                        formCode.equals(formConfig.getFormDetails().getFormCode())).toList();

        doVerifyOptionCodeList(optionCodeList, formConfigList);
    }

    public void verifyOptionCodeList(User user, String tenant, Long applicationId, List<String> optionCodeList) {
        List<FormWithGroupHierarchyPublicDTO> formConfigList = this.getFormConfigList(user, tenant, applicationId);

        doVerifyOptionCodeList(optionCodeList, formConfigList);
    }

    private void doVerifyOptionCodeList(List<String> optionCodeList, List<FormWithGroupHierarchyPublicDTO> formConfigList) {
        Set<String> allCodes = new HashSet<>();
        for (FormWithGroupHierarchyPublicDTO form : formConfigList) {
            var paramMap = form.getFormDetails().getParams();
            String stringCodeList = paramMap.get(OPTION_CODES_KEY);
            if (stringCodeList != null) {
                allCodes.addAll(List.of(stringCodeList.split(",")));
            }
        }

        if (!allCodes.containsAll(optionCodeList)) {
            throw new OptionCodeListNotValidRuntimeException();
        }
    }

    public FormWithGroupHierarchyPublicDTO getFormConfigByOptionCode(User user, String tenant, Long applicationId, String optionCode, String locale) {
        return this.getFormConfigListNoCache(user, tenant, applicationId, locale)
                .stream()
                .filter(x -> {
                    var params = x.getFormDetails().getParams();
                    if(params != null) {
                        return params.get(OPTION_CODES_KEY) != null;
                    }
                    return false;
                })
                .filter(x -> x.getFormDetails().getParams().get(OPTION_CODES_KEY).contains(optionCode))
                .findFirst()
                .orElseThrow();
    }

    public FormWithGroupHierarchyPublicDTO getFormConfigByOptionCodeWithUser(String tenant, Long applicationId, String optionCode, User user, String locale) {
        return this.callForFormConfigList(tenant, applicationId, user.getAuthToken(), locale)
                .stream()
                .filter(x -> {
                    var params = x.getFormDetails().getParams();
                    if(params != null) {
                        return params.get(OPTION_CODES_KEY) != null;
                    }
                    return false;
                })
                .filter(x -> x.getFormDetails().getParams().get(OPTION_CODES_KEY).contains(optionCode))
                .findFirst()
                .orElseThrow();
    }
}
