package com.abacogroup.agri.applicationforms.pua.services;

import com.abacogroup.agri.applicationforms.pua.core.exceptions.AgriApplicationFormsRuntimeException;
import com.abacogroup.agri.applicationforms.pua.core.exceptions.InsertExceptionRuntimeException;
import com.abacogroup.agri.applicationforms.pua.core.exceptions.ObjectNotFoundException;
import com.abacogroup.agri.applicationforms.pua.core.exceptions.ObjectNotFoundRuntimeException;
import com.abacogroup.agri.applicationforms.pua.core.mappers.FiveYearDeclarationMapper;
import com.abacogroup.agri.applicationforms.pua.core.model.CompileStatusEnum;
import com.abacogroup.agri.applicationforms.pua.core.model.dto.FiveYearDeclarationDTO;
import com.abacogroup.agri.applicationforms.pua.core.model.dto.PartyResponse;
import com.abacogroup.agri.applicationforms.pua.db.dao.FiveYearDeclarationDAO;
import com.abacogroup.agri.applicationforms.pua.db.ntt.FiveYearDeclarationNTT;
import com.abacogroup.agri.applicationforms.pua.services.common.ApplicationFacadeService;
import com.abacogroup.agri.applicationforms.pua.services.common.crud.AbstractCrudService;
import com.abacogroup.agri.applicationforms.pua.util.GenericUtility;
import com.abacogroup.applicationworkflowsdk.model.io.output.ApplicationDetailsPublicDTO;
import com.abacogroup.dropwizard.auth.sso2.User;
import lombok.extern.slf4j.Slf4j;
import org.jdbi.v3.core.statement.StatementException;

import java.time.OffsetDateTime;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.Optional;

import static com.abacogroup.agri.applicationforms.pua.util.GenericUtility.throwNotImplementedException;

/**
 * @author Emanuele Crocilla
 */
@Slf4j
public class FiveYearDeclarationService
		extends AbstractCrudService<FiveYearDeclarationNTT, Long, FiveYearDeclarationDTO, FiveYearDeclarationMapper, Long, FiveYearDeclarationDAO> {

	private final ApplicationFacadeService applicationFacadeService;
	private final PartyService partyService;

	public FiveYearDeclarationService(
			FiveYearDeclarationDAO dao,
			ApplicationFacadeService applicationFacadeService,
			PartyService partyService,
			FiveYearDeclarationMapper mapper
	) {

		super(dao, mapper);
		this.applicationFacadeService = applicationFacadeService;
		this.partyService = partyService;
	}

	public FiveYearDeclarationDTO get(User user, String tenant, Long applicationId, Long id) {

		try {

			ApplicationDetailsPublicDTO applicationDetailsPublicDTO =
					applicationFacadeService.callForApplicationDetails(tenant, applicationId, user, Locale.ITALIAN.getLanguage());

			log.info(applicationDetailsPublicDTO.toString());

			FiveYearDeclarationDTO dto = findByDeclarationId(id);

			if (dto != null) {
				PartyResponse partyResponse = this.partyService.getPartyById(user, tenant, dto.getPartyId());
				log.info("Retrieving of FiveYearDeclaration completed for tenant {} and applicationId {} ", tenant, id);
				dto.setCuaa(partyResponse.getCode());
				dto.setCompany(getCompanyName(partyResponse));
				return dto;
			}

			return null;

		} catch (Exception e) {
			String msg = GenericUtility.formatStr("Unable to complete 'get' method due an unhandled error for tenant {} and id {} ", tenant, id);
			log.error(msg, e);
			throw e;
		}
	}

	public List<FiveYearDeclarationDTO> getAll(User user, String tenant, Long applicationId) {

		try {

			ApplicationDetailsPublicDTO applicationDetailsPublicDTO =
					applicationFacadeService.callForApplicationDetails(tenant, applicationId, user, Locale.ITALIAN.getLanguage());

			log.info(applicationDetailsPublicDTO.toString());

			List<FiveYearDeclarationDTO> dtos = findByApplicationId(applicationId);

			PartyResponse partyResponse = null;

			if (dtos != null) {
				for (FiveYearDeclarationDTO dto : dtos) {
					partyResponse = this.partyService.getPartyById(user, tenant, dto.getPartyId());
					dto.setCuaa(partyResponse.getCode());
					dto.setCompany(getCompanyName(partyResponse));
				}
				log.info("Retrieving of FiveYearDeclaration completed for tenant {} and applicationId {} ", tenant, applicationId);
				return dtos;
			}

			return Collections.emptyList();
		} catch (Exception e) {

			String msg = GenericUtility.formatStr("Unable to complete 'get' method due an unhandled error for tenant {} and applicationId {} ", tenant,
					applicationId);
			log.error(msg, e);
			throw e;
		}
	}

	public FiveYearDeclarationDTO insert(User user, String tenant, Long applicationId, Long formConfigId, String compileStatusIdentifier,
			FiveYearDeclarationDTO dto) {

		try {

			applicationFacadeService.verifyAcceptDispositiveCalls(user, tenant, applicationId, formConfigId);

			// verify if usedAreaSqm value is less than zero and it is not greater than cadastralAreaSqm
			validateUserAreaSqmValue(dto);

			// validating partyId and get PartyResponse
			PartyResponse partyResponse = this.validatePartyIdAndGetPartyResponse(user, partyService, tenant, dto.getPartyId());

			// first Time Insertion (the declaration ID is the same as the pkId)
			FiveYearDeclarationDTO res = insert(dto);

			// update compile status
			applicationFacadeService.updateCompileStatus(user, tenant, applicationId, compileStatusIdentifier, CompileStatusEnum.COMPLETED);

			log.info("Insert of FiveYearDeclaration completed for tenant {} applicationId {} formConfigId {}", tenant, applicationId, formConfigId);

			res.setCuaa(partyResponse.getCode());
			res.setCompany(getCompanyName(partyResponse));

			return res;
		} catch (Exception e) {

			String msg = GenericUtility.formatStr("Unable to complete 'insert' method due an error for tenant {} applicationId {} formConfigId {}", tenant,
					applicationId, formConfigId);
			log.error(msg, e);
			throw e;
		}
	}

	public FiveYearDeclarationDTO update(User user, String tenant, Long applicationId, Long formConfigId, String compileStatusIdentifier,
			FiveYearDeclarationDTO dto) {

		try {

			applicationFacadeService.verifyAcceptDispositiveCalls(user, tenant, applicationId, formConfigId);

			FiveYearDeclarationNTT ntt = FiveYearDeclarationMapper.INSTANCE.dtoToEntity(dto);

			// verify if usedAreaSqm value is less than zero and it is not greater than cadastralAreaSqm
			validateUserAreaSqmValue(dto);

			// validating partyId and get PartyResponse
			PartyResponse partyResponse = this.validatePartyIdAndGetPartyResponse(user, partyService, tenant, dto.getPartyId());

			dao.upsert(ntt);

			FiveYearDeclarationNTT newNtt = dao.findByDeclarationId(dto.getId());

			FiveYearDeclarationDTO res = returnOptionalRecord(newNtt).get();

			applicationFacadeService.updateCompileStatus(user, tenant, applicationId, compileStatusIdentifier, CompileStatusEnum.COMPLETED);

			res.setCuaa(partyResponse.getCode());
			res.setCompany(getCompanyName(partyResponse));

			return res;

		} catch (Exception e) {
			String msg = GenericUtility.formatStr("Unable to complete 'update' method due an error for tenant {}, applicationId {} and formConfigId {}", tenant,
					applicationId, formConfigId);
			log.error(msg, e);
			throw e;
		}
	}

	public boolean delete(User user, String tenant, Long applicationId, Long formConfigId, String compileStatusIdentifier, Long declarationId) {

		try {

			applicationFacadeService.verifyAcceptDispositiveCalls(user, tenant, applicationId, formConfigId);

			FiveYearDeclarationNTT ntt = dao.findByDeclarationId(declarationId);

			if (ntt != null) {

				dao.expireByPkId(applicationId, ntt.getPkId(), OffsetDateTime.now(), user.getUserId());

				if (!existsAtLeastOneElement(applicationId)) {
					applicationFacadeService.deleteCompileStatus(user, tenant, applicationId, compileStatusIdentifier);
				} else {
					applicationFacadeService.updateCompileStatus(user, tenant, applicationId, compileStatusIdentifier, CompileStatusEnum.COMPLETED);
				}

				return true;
			} else {

				log.warn("Unable to find item with application id = " + applicationId + " and declaration Id = " + declarationId);
				return false;
			}

		} catch (Exception e) {
			String msg = GenericUtility.formatStr("Unable to complete 'delete' method due an error for tenant {}, applicationId {} and formConfigId {}", tenant,
					applicationId, formConfigId);
			log.error(msg, e);
			throw e;
		}
	}

	private FiveYearDeclarationDTO findByDeclarationId(Long id) {
		FiveYearDeclarationNTT item = this.dao.findByDeclarationId(id);
		return returnOptionalRecord(item).get();
	}

	private List<FiveYearDeclarationDTO> findByApplicationId(Long applicationId) {
		return this.dao.findByApplicationId(applicationId).stream()
				.map(mapper::entityToDto)
				.toList();
	}

	private FiveYearDeclarationDTO insert(FiveYearDeclarationDTO in) {
		log.info("Invoking insert with params in: {}", in);
		return this.firstTimeInsertion(in);
	}

	@Override
	protected boolean hasPrimaryKey() {
		return true;
	}

	@Override
	protected void deleteByCustomKey(Long customKey) {
		throw throwNotImplementedException.get();
	}

	@Override
	protected void setCustomSearchKey(FiveYearDeclarationNTT rs, Long customKey) {
		throw throwNotImplementedException.get();
	}

	@Override
	protected Optional<FiveYearDeclarationNTT> findRsByCustomKey(Long customKey) {
		FiveYearDeclarationNTT ntt = this.dao.findByDeclarationId(customKey);
		return ntt == null ? Optional.empty() : Optional.of(ntt);
	}

	protected FiveYearDeclarationDTO firstTimeInsertion(FiveYearDeclarationDTO dtoIn) {
		return dao.inTransaction(handle -> {
			try {

				Long pkId = this.retrievePrimaryKey(null);
				FiveYearDeclarationNTT rs = mapper.dtoToEntity(dtoIn);
				rs.setPkId(pkId);
				rs.setId(pkId);// declaration ID is set as pkId only for the first time (declaration ID never change in updates)
				dao.insert(rs);
				return findOutDtoByPrimaryKey(pkId);

			} catch (StatementException e) {
				log.error(e.getMessage(), e);
				throw new InsertExceptionRuntimeException("error during insert");
			} catch (ObjectNotFoundException e) {
				throw new ObjectNotFoundRuntimeException();
			} catch (Exception e) {
				throw new AgriApplicationFormsRuntimeException(e.getMessage());
			}
		});
	}

	/** verify if usedAreaSqm value is less than zero and it is not greater than cadastralAreaSqm value */
	private void validateUserAreaSqmValue(FiveYearDeclarationDTO dto) {

		if (dto.getUsedAreaSqm() < 1) {

			throw new RuntimeException("The usedAreaSqm value cannot less than 1 ");
		} else if (dto.getCadastralAreaSqm() < 1) {

			throw new RuntimeException("The cadastralAreaSqm value cannot be less than 1 ");
		} else if (dto.getUsedAreaSqm() > dto.getCadastralAreaSqm()) {

			throw new RuntimeException("The usedAreaSqm value cannot be greater than cadastralAreaSqm ");
		}
	}

	private boolean existsAtLeastOneElement(Long applicationId) {
		return dao.count(applicationId) > 0;
	}

}
