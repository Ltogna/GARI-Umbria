package com.abacogroup.agri.applicationforms.pua.db.dao;

import java.time.LocalDateTime;

import org.jdbi.v3.sqlobject.statement.SqlUpdate;

import com.abacogroup.agri.applicationforms.pua.db.ntt.applications.IHistoricizationFields;

/**
 * @author Gennaro Tamburrelli
 * @author Mauro Pozzana
 *
 * @param <T>
 *            The RS type class
 * @param <D>
 *            The RS type's ID type
 * @param <C>
 *            The Custom Key type
 */
public interface IGenericHistoricizationFieldsDAO<T extends IHistoricizationFields, D, C> extends IGenericPuaDAO<T, D> {

	@SqlUpdate
	void insert(T rs, String userId, LocalDateTime currentTimestamp);

	@SqlUpdate
	void logicallyDeleteById(D oldId, String userIdDelete, LocalDateTime currentTimestamp);

	@SqlUpdate
	void logicallyDeleteByCustomKey(C customKey, String userIdDelete, LocalDateTime currentTimestamp);
}
