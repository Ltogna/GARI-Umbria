package com.abacogroup.agri.applicationforms.pua.resources;

import com.abacogroup.agri.applicationforms.pua.ApplicationFormsModuleConfiguration;
import com.abacogroup.agri.applicationforms.pua.common.dynamidocument.DynamicDocumentService;
import com.abacogroup.agri.applicationforms.pua.services.AttachmentsService;
import com.abacogroup.agri.applicationforms.pua.services.BancheDatiService;
import com.abacogroup.agri.applicationforms.pua.services.CropPlanService;
import com.abacogroup.agri.applicationforms.pua.services.DeclOnCropsService;
import com.abacogroup.agri.applicationforms.pua.services.DeclarationsOnSectorsService;
import com.abacogroup.agri.applicationforms.pua.services.EffluentCrudService;
import com.abacogroup.agri.applicationforms.pua.services.FiveYearDeclarationService;
import com.abacogroup.agri.applicationforms.pua.services.GiasAgronicaService;
import com.abacogroup.agri.applicationforms.pua.services.IpisGisService;
import com.abacogroup.agri.applicationforms.pua.services.OrganicFertilizerSpreadingDeclarationService;
import com.abacogroup.agri.applicationforms.pua.services.PartyService;
import com.abacogroup.agri.applicationforms.pua.services.TipologiaDichiarazioneService;
import com.abacogroup.agri.applicationforms.pua.services.common.ApplicationFacadeService;
import com.abacogroup.dropwizard.auth.sso2.Sso2Client;

import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;

/**
 * 
 * @author Emanuele Crocilla
 *
 */
@Path("/{tenant}/v1/applications")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public abstract class AGenericPuaResources {
	
	protected final Sso2Client sso2Client;
	
	protected CropPlanService cropPlanService;
	protected IpisGisService ipisGisService;
	protected TipologiaDichiarazioneService tipologiaDichiarazioneService;
	protected DeclarationsOnSectorsService declarationsOnSectorsService;
	protected DeclOnCropsService declOnCropsService;
	protected ApplicationFacadeService applicationFacadeService;
	protected ApplicationFormsModuleConfiguration configuration;
	protected DynamicDocumentService dynamicDocumentService;
	protected AttachmentsService attachmentsService;
	protected FiveYearDeclarationService fiveYearDeclarationService;
	protected OrganicFertilizerSpreadingDeclarationService organicFertilizerSpreadingDeclarationService;
	protected EffluentCrudService effluentService;
	protected BancheDatiService bancheDatiService;
	protected GiasAgronicaService giasService;
	protected PartyService partyService;
	
	protected AGenericPuaResources(ApplicationFormsModuleConfiguration configuration, Sso2Client sso2Client) {
		this.sso2Client = sso2Client;
		this.configuration = configuration;
	}

}
