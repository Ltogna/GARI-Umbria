package com.abacogroup.agri.applicationforms.pua.core.model.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Author: Emanuele Crocilla
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Effluent {
	private String code;
	private String description;
	private Double nitrogen;
	private String codeUom;
	private String descriptionUom;
	private String ferCod;
}
