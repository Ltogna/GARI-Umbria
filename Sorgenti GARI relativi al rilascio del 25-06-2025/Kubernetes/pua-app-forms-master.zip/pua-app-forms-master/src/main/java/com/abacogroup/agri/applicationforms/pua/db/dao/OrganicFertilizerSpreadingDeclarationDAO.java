package com.abacogroup.agri.applicationforms.pua.db.dao;

import com.abacogroup.agri.applicationforms.pua.core.exceptions.ObjectNotFoundRuntimeException;
import com.abacogroup.agri.applicationforms.pua.db.ntt.OrganicFertilizerSpreadingDeclarationLanduseNTT;
import com.abacogroup.agri.applicationforms.pua.db.ntt.OrganicFertilizerSpreadingDeclarationNTT;
import com.abacogroup.agri.applicationforms.pua.services.common.FunctionalObject;
import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.customizer.BindBean;
import org.jdbi.v3.sqlobject.customizer.BindList;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;

import java.time.Instant;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.util.Calendar;
import java.util.Collection;
import java.util.List;

/**
 * @author Emanuele Crocilla
 */
public interface OrganicFertilizerSpreadingDeclarationDAO extends IGenericPuaDAO<OrganicFertilizerSpreadingDeclarationNTT, Long> {

	@Override
	@SqlQuery("§select_nextval(appfpua_organic_fert_spreading_declaration_id_seq)§")
	Long nextSequenceVal();

	@SqlQuery("§select_nextval(appfpua_organic_fert_spreading_declaration_landuse_id_seq)§")
	Long nextSequenceOrganicFertilizerSpreadingDeclarationLanduseVal();

	@Override
	@SqlUpdate("""
			INSERT INTO appfpua_organic_fert_spreading_declaration (pkid, application_id, id, party_id, expected_date, livestock_effluents, livestock_effluents_qty, livestock_effluents_code_uom, livestock_effluents_description_uom, crop_plan_version, sector_code, dt_insert, dt_delete, user_id_insert, gias_fertilizer_code) 
			VALUES(:pkid, :applicationId, :id, :partyId, :expectedDate, :livestockEffluents, :livestockEffluentsQty, :livestockEffluentsCodeUom, :livestockEffluentsDescriptionUom, 
			:cropPlanVersion, :sectorCode, :dtInsert, :dtDelete, :userIdInsert, :giasFertilizerCode);
			""")
	void insert(@BindBean OrganicFertilizerSpreadingDeclarationNTT ntt);

	@SqlQuery("""
			   SELECT COUNT(land.*) FROM appfpua_organic_fert_spreading_declaration decl 
			   JOIN appfpua_organic_fert_spreading_declaration_landuse land
				ON decl.pkid = land.appfpua_organic_fert_spreading_declaration_pkid 
			   WHERE decl.application_id = :applicationId
			     AND decl.party_id = :partyId
			     AND land.plot_id = :plotId
			     AND  decl.dt_delete > §current_timestamp§
			     AND  land.dt_delete > §current_timestamp§
			""")
	int exists(@Bind("applicationId") Long applicationId,
			@Bind("partyId") Long partyId,
			@Bind("plotId") String plotId);

	@SqlQuery("SELECT * FROM appfpua_organic_fert_spreading_declaration WHERE pkid = :pkid ")
	@RegisterBeanMapper(OrganicFertilizerSpreadingDeclarationNTT.class)
	List<OrganicFertilizerSpreadingDeclarationNTT> findById(@Bind("pkid") Long pkid);

	@SqlQuery("SELECT * FROM appfpua_organic_fert_spreading_declaration WHERE id = :declarationId AND §current_timestamp§ between dt_insert AND dt_delete  ")
	@RegisterBeanMapper(OrganicFertilizerSpreadingDeclarationNTT.class)
	OrganicFertilizerSpreadingDeclarationNTT findByDeclarationId(@Bind("declarationId") Long declarationId);

	@SqlQuery("select * from appfpua_organic_fert_spreading_declaration WHERE application_id = :application_id AND dt_delete > §current_timestamp§ order by id")
	@RegisterBeanMapper(OrganicFertilizerSpreadingDeclarationNTT.class)
	List<OrganicFertilizerSpreadingDeclarationNTT> findByApplicationId(@Bind("application_id") Long applicationId);

	@SqlUpdate(""" 
			UPDATE public.appfpua_organic_fert_spreading_declaration 
			SET id=:id, expected_date=:expectedDate, plot_id=:plotId, 
			livestock_effluents=:livestockEffluents, livestock_effluents_qty=:livestockEffluentsQty, 
			livestock_effluents_code_uom=:livestockEffluentsCodeUom,
			livestock_effluents_description_uom=:livestockEffluentsDescriptionUom,
			gias_fertilizer_code=:giasFertilizerCode,
			declaration_code=:declarationCode, cropPlanVersion=:crop_plan_version 
			WHERE pkid = :pkId """)
	@Override
	void update(@BindBean OrganicFertilizerSpreadingDeclarationNTT rs);

	@SqlUpdate("""
			UPDATE appfpua_organic_fert_spreading_declaration
			   SET dt_delete=:dtDelete,
			       user_id_delete = :userIdDelete
			 WHERE application_id=:applicationId 
			AND id=:declatationId 
			   AND §current_timestamp§ between dt_insert AND dt_delete 
			""")
	void expireByDeclarationId(@Bind("applicationId") Long applicationId, @Bind("declatationId") Long declatationId, @Bind("dtDelete") OffsetDateTime dtDelete,
			@Bind("userIdDelete") String userIdDelete);

	@SqlUpdate("""
			UPDATE appfpua_organic_fert_spreading_declaration
			   SET dt_delete=:dtDelete,
			       user_id_delete = :userIdDelete
			 WHERE application_id=:applicationId 
			AND pkId=:pkId 
			   AND §current_timestamp§ between dt_insert AND dt_delete 
			""")
	void expireByPkId(@Bind("applicationId") Long applicationId, @Bind("pkId") Long pkId, @Bind("dtDelete") OffsetDateTime dtDelete,
			@Bind("userIdDelete") String userIdDelete);

	default void upsert(OrganicFertilizerSpreadingDeclarationNTT nttToUpd, Collection<OrganicFertilizerSpreadingDeclarationLanduseNTT> landUsesToUpd) {

		FunctionalObject<Long> applicationId = () -> nttToUpd != null ? nttToUpd.getApplicationId() : null;
		FunctionalObject<Long> nttId = () -> nttToUpd != null ? nttToUpd.getId() : null;

		if (nttToUpd != null && nttId.get() != null && this.countById(nttId.get()) > 0) {

			String userIdInsert = nttToUpd.getUserIdInsert();
			long rightNow = Calendar.getInstance().getTimeInMillis();
			long rightNowMinusAMillis = rightNow - 1;

			Instant instantRightNow = Instant.ofEpochMilli(rightNow);
			Instant instantMinusAMillis = Instant.ofEpochMilli(rightNowMinusAMillis);

			OffsetDateTime dateTimeRightNow = instantRightNow.atOffset(ZoneOffset.UTC);
			OffsetDateTime dateTimeMinusAMillis = instantMinusAMillis.atOffset(ZoneOffset.UTC);

			nttToUpd.setDtInsert(dateTimeRightNow);

			useTransaction(dao -> {

				OrganicFertilizerSpreadingDeclarationDAO _dao = (OrganicFertilizerSpreadingDeclarationDAO) dao;

				var declToExpire = _dao.findByDeclarationId(nttId.get());

				_dao.expireOrganicFertilizerSpreadingDeclarationLandusesByParentPkId(declToExpire.getPkid(), dateTimeMinusAMillis, userIdInsert);

				_dao.expireByDeclarationId(applicationId.get(), nttId.get(), dateTimeMinusAMillis, userIdInsert);

				nttToUpd.setPkid(_dao.nextSequenceVal());

				_dao.insert(nttToUpd);

				if (landUsesToUpd != null) {
					for (var landUse : landUsesToUpd) {
						landUse.setAppfpuaOrganicFertSpreadingDeclarationPkid(nttToUpd.getPkid());
						landUse.setPkid(_dao.nextSequenceOrganicFertilizerSpreadingDeclarationLanduseVal());
						landUse.setDtInsert(dateTimeRightNow);
						_dao.insert(landUse);
					}
				}

			});
		} else {

			throw new ObjectNotFoundRuntimeException(
					"Unable to find any OrganicFertSpreadingDeclaration for application id = " + applicationId.get() + " and Id = " + nttId.get());
		}
	}

	default void expireHierarchyByPkId(
			@Bind("applicationId") Long applicationId,
			@Bind("pkId") Long pkId,
			@Bind("userIdDelete") String userIdDelete) {

		useTransaction(dao -> {
			OrganicFertilizerSpreadingDeclarationDAO _dao = (OrganicFertilizerSpreadingDeclarationDAO) dao;
			_dao.expireOrganicFertilizerSpreadingDeclarationLandusesByParentPkId(pkId, OffsetDateTime.now(), userIdDelete);
			_dao.expireByPkId(applicationId, pkId, OffsetDateTime.now(), userIdDelete);
		});
	}

	@SqlQuery("select count(*) from appfpua_organic_fert_spreading_declaration where id = :id and dt_delete > §current_timestamp§")
	@RegisterBeanMapper(OrganicFertilizerSpreadingDeclarationNTT.class)
	int countById(@Bind("id") Long d);

	@SqlQuery("select count(*) from appfpua_organic_fert_spreading_declaration where application_id = :application_id and dt_delete > §current_timestamp§")
	@RegisterBeanMapper(OrganicFertilizerSpreadingDeclarationNTT.class)
	int count(@Bind("application_id") Long applicationId);

	@SqlQuery(""" 
			SELECT * FROM appfpua_organic_fert_spreading_declaration_landuse 
				WHERE appfpua_organic_fert_spreading_declaration_pkid = :parentId 
				AND dt_delete > §current_timestamp§ 
			ORDER BY pkid
			""")
	@RegisterBeanMapper(OrganicFertilizerSpreadingDeclarationLanduseNTT.class)
	List<OrganicFertilizerSpreadingDeclarationLanduseNTT> getOrganicFertilizerSpreadingDeclarationLanduseByParentId(@Bind("parentId") Long parentId);

	@SqlQuery(""" 
			SELECT * FROM appfpua_organic_fert_spreading_declaration_landuse 
				WHERE appfpua_organic_fert_spreading_declaration_pkid IN (<parentIds>) 
				AND dt_delete > §current_timestamp§ 
			ORDER BY pkid
			""")
	@RegisterBeanMapper(OrganicFertilizerSpreadingDeclarationLanduseNTT.class)
	List<OrganicFertilizerSpreadingDeclarationLanduseNTT> getOrganicFertilizerSpreadingDeclarationLanduseByParentIds(
			@BindList("parentIds") Collection<Long> parentId);

	@SqlUpdate("""
			   INSERT INTO appfpua_organic_fert_spreading_declaration_landuse (pkid, appfpua_organic_fert_spreading_declaration_pkid, 
			   land_use_code, land_use_description, plot_id, plot_description, declaration_code, plot_area_sqm, plot_area_perc, 
			   plot_total_hectar, dt_insert, dt_delete, user_id_insert) 
			   VALUES(:pkid, :appfpuaOrganicFertSpreadingDeclarationPkid, :landUseCode, :landUseDescription, :plotId, :plotDescription, 
			   :declarationCode, :plotAreaSqm, :plotAreaPerc, :plotTotalHectar, :dtInsert, :dtDelete, :userIdInsert)
			""")
	void insert(@BindBean OrganicFertilizerSpreadingDeclarationLanduseNTT ntt);

	@SqlUpdate("""
			UPDATE appfpua_organic_fert_spreading_declaration_landuse
			   SET dt_delete=:dtDelete,
			       user_id_delete = :userIdDelete
			 WHERE appfpua_organic_fert_spreading_declaration_pkid = :parentId 
			   AND §current_timestamp§ between dt_insert AND dt_delete 
			""")
	void expireOrganicFertilizerSpreadingDeclarationLandusesByParentPkId(
			@Bind("parentId") Long parentId,
			@Bind("dtDelete") OffsetDateTime dtDelete,
			@Bind("userIdDelete") String userIdDelete);

}
