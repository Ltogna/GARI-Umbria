package com.abacogroup.agri.applicationforms.pua.core.model.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.List;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class FabbisognoResponseDati {
	@JsonProperty("ListaFabbisogni")
	private List<FabbisognoResponse> listaFabbisogni;
}


