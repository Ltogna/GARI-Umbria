package com.abacogroup.agri.applicationforms.pua.services.common;

import com.abacogroup.agri.applicationforms.pua.db.ntt.DeclOnCropsPrevEffluentsNTT;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.util.List;

/**
 * @author Emanuele Crocilla
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class DeclOnCropsSubdata {
	int cycle;
	String typology;
	int precessionCode;
	int yeld;
	BigDecimal distributableNum;
	Long pkId;
	List<DeclOnCropsPrevEffluentsNTT> previousEffluents;
	String UserIdInsert;

}
