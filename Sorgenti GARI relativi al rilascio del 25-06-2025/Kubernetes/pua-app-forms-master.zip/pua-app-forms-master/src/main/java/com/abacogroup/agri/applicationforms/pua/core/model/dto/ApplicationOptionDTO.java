package com.abacogroup.agri.applicationforms.pua.core.model.dto;

import java.time.LocalDateTime;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

/**
 * @author Mattia Perini
 */
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
@Schema(description = "The application options")
public class ApplicationOptionDTO implements IdentifiableEntity<Long> {

	@Schema(description = "The application options parcel's pkid")
	private Long pkid;
	@Schema(description = "The application options parcel's application id")
	private Long applicationId;
	@Schema(description = "The application options parcel's option config id")
	private Long optionConfigId;
	@Schema(description = "The application options code")
	private String optionCode;
	@Schema(description = "The related dynamic document instance's id. May be null is the config does not provide mandatory additional infos")
	private Long documentId;
	@Schema(description = "The takeover id, if exists")
	private Long takeoverId;
	@Schema(description = "The initial application, if exists")
	private Long startApplicationId;
	@Schema(description = "The previous application, if exists")
	private Long previousApplicationId;
	@Schema(description = "The application options parcel's user id insert")
	private String userIdInsert;
	@Schema(description = "The application options parcel's user id delete")
	private String userIdDelete;
	@Schema(description = "The application options parcel's insert date")
	private LocalDateTime dtInsert;
	@Schema(description = "The application options parcel's delete date")
	private LocalDateTime dtDelete;

	@Override
	public Long getId() {
		return pkid;
	}

	@Override
	public void setId(Long id) {
		setPkid(id);
	}
}
