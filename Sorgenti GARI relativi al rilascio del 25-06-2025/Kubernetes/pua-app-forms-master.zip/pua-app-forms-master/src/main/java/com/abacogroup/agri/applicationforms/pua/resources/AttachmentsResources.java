package com.abacogroup.agri.applicationforms.pua.resources;

import static com.abacogroup.agri.applicationforms.pua.resources.AttachmentsResources.ATTACHMENT_TAG_NAME;

import java.io.InputStream;
import java.util.Locale;

import org.glassfish.jersey.media.multipart.FormDataBodyPart;
import org.glassfish.jersey.media.multipart.FormDataContentDisposition;
import org.glassfish.jersey.media.multipart.FormDataParam;

import com.abacogroup.agri.applicationforms.pua.ApplicationFormsModuleConfiguration;
import com.abacogroup.agri.applicationforms.pua.core.exceptions.AttachmentNotFoundRuntimeException;
import com.abacogroup.agri.applicationforms.pua.core.model.CompileStatusEnum;
import com.abacogroup.agri.applicationforms.pua.core.model.dto.AttachmentPublicDTO;
import com.abacogroup.agri.applicationforms.pua.core.model.dto.AttachmentTypePublicDTO;
import com.abacogroup.agri.applicationforms.pua.core.model.dto.CreateAttachmentInDTO;
import com.abacogroup.agri.applicationforms.pua.core.model.dto.UpdateAttachmentInDTO;
import com.abacogroup.agri.applicationforms.pua.services.AttachmentsService;
import com.abacogroup.agri.applicationforms.pua.services.common.ApplicationFacadeService;
import com.abacogroup.dropwizard.auth.sso2.Sso2Client;
import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.codahale.metrics.annotation.Timed;

import io.dropwizard.auth.Auth;
import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.annotation.security.PermitAll;
import jakarta.annotation.security.RolesAllowed;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.PATCH;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.Context;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.core.SecurityContext;
import lombok.extern.slf4j.Slf4j;

/**
 * 
 * @author Emanuele Crocilla
 *
 */
@Timed
@OpenAPIDefinition(tags = {
		@Tag(name = ATTACHMENT_TAG_NAME)
})
@PermitAll
@Slf4j
@MultipartConfig()
@RolesAllowed("APPLICATIONS|USER")
public class AttachmentsResources extends AGenericPuaResources {

	public static final String ATTACHMENT_TAG_NAME = "Attachment Resources";

	public AttachmentsResources(
			ApplicationFormsModuleConfiguration configuration, 
			AttachmentsService attachmentsService,
			ApplicationFacadeService applicationFacadeService, 
			Sso2Client sso2Client
	) {
		
		super(configuration, sso2Client);
		this.attachmentsService = attachmentsService;
		this.applicationFacadeService = applicationFacadeService;
	}

	@GET
	@Path("/{application_id}/attachment-types/{attachment_group}")
	@Operation(description = "Returns the list of attachment types for the current tenant", tags = { ATTACHMENT_TAG_NAME })
	@ApiResponse(description = "The list of attachment types for the current tenant")
	public InfiniteListResults<AttachmentTypePublicDTO> getAttachmentTypes(
			@Parameter(description = "Current Tenant") @PathParam("tenant") String tenant,
			@Parameter(description = "The application id") @PathParam("application_id") Long applicationId,
			@Parameter(description = "The attachment's group") @PathParam("attachment_group") String attachmentGroup,
			@Parameter(description = "The infinite list key") @QueryParam("nextKey") String nextKey,
			@Parameter(hidden = true) @Auth User user,
			@Context SecurityContext sc) {
		
		applicationFacadeService.callForApplicationDetails(tenant, applicationId, user, Locale.ITALIAN.getLanguage());
		return attachmentsService.getAttachmentTypes(tenant, attachmentGroup, nextKey);
	}

	@GET
	@Path("/{application_id}/attachments/groups/{attachment_group}")
	@Operation(description = "Returns the list of attachments for an application", tags = { ATTACHMENT_TAG_NAME })
	@ApiResponse(description = "The list of attachments for an application")
	public InfiniteListResults<AttachmentPublicDTO> getAttachments(@Parameter(description = "Current Tenant") @PathParam("tenant") String tenant,
			@Parameter(description = "The application id") @PathParam("application_id") Long applicationId,
			@Parameter(description = "The attachment group code") @PathParam("attachment_group") String attachmentGroup,
			@Parameter(description = "The infinite list key") @QueryParam("nextKey") String nextKey,
			@Parameter(hidden = true) @Auth User user,
			@Context SecurityContext sc) {
		
		applicationFacadeService.callForApplicationDetails(tenant, applicationId, user, Locale.ITALIAN.getLanguage());
		return attachmentsService.getAttachments(tenant, applicationId, attachmentGroup, nextKey);
	}

	@GET
	@Path("/{application_id}/attachments/{attachment_id}")
	@Produces({ MediaType.APPLICATION_OCTET_STREAM, MediaType.APPLICATION_JSON })
	@Operation(description = "Returns the attached file referred to the id", tags = { ATTACHMENT_TAG_NAME })
	@ApiResponse(description = "The attached file")
	public Response getAttachment(@Parameter(description = "Current Tenant") @PathParam("tenant") String tenant,
			@Parameter(description = "The application id") @PathParam("application_id") Long applicationId,
			@Parameter(description = "The attachment id") @PathParam("attachment_id") String attachmentId,
			@Parameter(hidden = true) @Auth User user,
			@Context SecurityContext sc) {
		
		applicationFacadeService.callForApplicationDetails(tenant, applicationId, user, Locale.ITALIAN.getLanguage());
		return attachmentsService.getAttachment(tenant, user, applicationId, attachmentId);
	}

	@POST
	@Consumes(MediaType.MULTIPART_FORM_DATA)
	@Path("/{application_id}/attachments")
	@Operation(description = "Inserts the attachment", tags = { ATTACHMENT_TAG_NAME })
	@ApiResponse(description = "The inserted attachment")
	public AttachmentPublicDTO postAttachment(@Parameter(description = "Current Tenant") @PathParam("tenant") String tenant,
			@Parameter(description = "The application id") @PathParam("application_id") Long applicationId,
			@Parameter(description = "The attachment's metadata") @FormDataParam("payload") FormDataBodyPart part,
			@Parameter(description = "The attachment's file") @FormDataParam("file") InputStream inputStream,
			@Parameter(description = "The attachment's file") @FormDataParam("file") FormDataContentDisposition fileMetadata,
			@Parameter(description = "The form config id") @QueryParam("formConfigId") Long formConfigId,
			@Parameter(description = "The compile status identifier") @QueryParam("compileStatusIdentifier") String compileStatusIdentifier,
			@Parameter(description = "The compile status") @QueryParam("compileStatus") CompileStatusEnum compileStatusEnum,
			@Parameter(hidden = true) @Auth User user,
			@Context SecurityContext sc) {
		
		part.setMediaType(MediaType.APPLICATION_JSON_TYPE);
		CreateAttachmentInDTO payload = part.getValueAs(CreateAttachmentInDTO.class);
		
		return attachmentsService.createAttachment(tenant, applicationId, payload, user, formConfigId, compileStatusIdentifier, inputStream, fileMetadata);
	}

	@DELETE
	@Path("/{application_id}/attachments/{attachment_id}")
	@Operation(description = "Returns the attached file referred to the id", tags = { ATTACHMENT_TAG_NAME })
	@ApiResponse(description = "The attached file")
	public Response deleteAttachment(@Parameter(description = "Current Tenant") @PathParam("tenant") String tenant,
			@Parameter(description = "The application id") @PathParam("application_id") Long applicationId,
			@Parameter(description = "The attachment id") @PathParam("attachment_id") String attachmentId,
			@Parameter(description = "The form config id") @QueryParam("formConfigId") Long formConfigId,
			@Parameter(description = "The compile status identifier") @QueryParam("compileStatusIdentifier") String compileStatusIdentifier,
			@Parameter(description = "The compile status") @QueryParam("compileStatus") CompileStatusEnum compileStatusEnum,
			@Parameter(hidden = true) @Auth User user,
			@Context SecurityContext sc) {
		
		try {
			
			attachmentsService.deleteAttachment(tenant, user, formConfigId, compileStatusIdentifier, applicationId, attachmentId);
			
		} catch (AttachmentNotFoundRuntimeException e) {
			log.warn("attachment supposed to be deleted not found");
		}

		return Response.ok()
				.build();
	}

	@PATCH
	@Path("/{application_id}/attachments/{attachment_id}")
	@Operation(description = "Update an attachment for an application", tags = { ATTACHMENT_TAG_NAME })
	@ApiResponse(description = "The list of attachments for an application")
	public AttachmentPublicDTO updateAttachment(@Parameter(description = "Current Tenant") @PathParam("tenant") String tenant,
			@Parameter(description = "The application id") @PathParam("application_id") Long applicationId,
			@Parameter(description = "The attachment id") @PathParam("attachment_id") String attachmentId,
			@Parameter(description = "The form config id") @QueryParam("formConfigId") Long formConfigId,
			@Parameter(description = "The compile status identifier") @QueryParam("compileStatusIdentifier") String compileStatusIdentifier,
			@Parameter(description = "The compile status") @QueryParam("compileStatus") CompileStatusEnum compileStatusEnum,
			UpdateAttachmentInDTO payload,
			@Parameter(hidden = true) @Auth User user,
			@Context SecurityContext sc) {
		 
		return attachmentsService.updateAttachment(tenant, applicationId, attachmentId, formConfigId, compileStatusIdentifier, payload, user);
	}

}
