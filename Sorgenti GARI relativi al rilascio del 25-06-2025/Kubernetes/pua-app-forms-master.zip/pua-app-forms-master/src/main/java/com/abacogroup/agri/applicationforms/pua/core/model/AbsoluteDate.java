package com.abacogroup.agri.applicationforms.pua.core.model;

import com.abacogroup.agri.applicationforms.pua.jackson.AbsoluteDateSerializer;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import io.swagger.v3.oas.annotations.media.Schema;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

@JsonSerialize(using = AbsoluteDateSerializer.class)
@Schema(description = "A date without any time or timezone information",
		type = "string",
		format = "yyyyMMdd",
		example = "20211231")
public final class AbsoluteDate implements Comparable<AbsoluteDate> {
	private static final DateTimeFormatter FORMATTER = DateTimeFormatter.ofPattern("yyyyMMdd");

	private final String value;
	private final LocalDate dt;

	@JsonCreator
	public AbsoluteDate(String value) {
		this.dt = LocalDate.parse(value, FORMATTER);
		this.value = value;
	}

	public AbsoluteDate(LocalDate dt) {
		this.dt = dt;
		this.value = dt.format(FORMATTER);
	}

	public LocalDate get() {
		return dt;
	}

	// Implementation node: this must return value because it is used by the deserializer
	@Override
	public String toString() {
		return value;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((dt == null) ? 0 : dt.hashCode());
		result = prime * result + ((value == null) ? 0 : value.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		AbsoluteDate other = (AbsoluteDate) obj;
		if (dt == null) {
			if (other.dt != null)
				return false;
		} else if (!dt.equals(other.dt))
			return false;
		if (value == null) {
			if (other.value != null)
				return false;
		} else if (!value.equals(other.value))
			return false;
		return true;
	}

	@Override
	public int compareTo(AbsoluteDate obj) {
		return this.dt.compareTo(obj.dt);
	}

	public LocalDate toLocalDate() {
		return this.dt;
	}
}
