package com.abacogroup.agri.applicationforms.pua.core.mappers;

import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import com.abacogroup.agri.applicationforms.pua.core.model.dto.OptionConfigsDTO;
import com.abacogroup.agri.applicationforms.pua.db.ntt.OptionConfigsNTT;

/**
 * @author Alexandru Paraschiv
 * @author Gennaro Tamburrelli
 */
@Mapper(uses = AbsoluteDateMapper.class)
public interface OptionConfigsMapper extends EntityMapper<OptionConfigsDTO, OptionConfigsNTT> {

	OptionConfigsMapper INSTANCE = Mappers.getMapper(OptionConfigsMapper.class);

	@InheritInverseConfiguration()
	OptionConfigsDTO entityToDto(OptionConfigsNTT entity);

	@Mapping(source = "id", target = "id")
	@Mapping(source = "optionId", target = "option_id")
	@Mapping(source = "optionMinimumValue", target = "option_minimum_value")
	@Mapping(source = "optionRowMinimumEngageableValue", target = "option_row_minimum_engageable_value")
	@Mapping(source = "flFullEngagement", target = "fl_full_engagement")
	@Mapping(source = "dtValidityStart", target = "dt_validity_start")
	@Mapping(source = "dtValidityEnd", target = "dt_validity_end")
	@Mapping(source = "startYear", target = "start_year")
	@Mapping(source = "numberOfYears", target = "nr_of_years")
	@Mapping(source = "flAutoCompile", target = "fl_auto_compile")
	OptionConfigsNTT dtoToEntity(OptionConfigsDTO dto);

}
