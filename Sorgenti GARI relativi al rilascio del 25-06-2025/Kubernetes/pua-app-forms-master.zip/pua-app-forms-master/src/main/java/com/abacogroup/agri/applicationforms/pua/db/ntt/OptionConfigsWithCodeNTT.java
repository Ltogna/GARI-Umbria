package com.abacogroup.agri.applicationforms.pua.db.ntt;

import java.util.Optional;

import com.abacogroup.agri.applicationforms.pua.db.ntt.applications.IIdRs;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author Lorenzo Carli
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class OptionConfigsWithCodeNTT implements IIdRs<Long> {

	private Long id;
	private String option_code;
	private Double option_minimum_value;
	private Double option_row_minimum_engageable_value;
	private Integer fl_full_engagement;
	private String dt_validity_start;
	private String dt_validity_end;
	private Integer start_year;
	private Integer nr_of_years;
	private Integer fl_auto_compile;

	@Override
	public Optional<Long> getKey() {
		return Optional.ofNullable(this.getId());
	}

	@Override
	public void setKey(Long id) {
		this.id = id;
	}

}
