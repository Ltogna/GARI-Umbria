package com.abacogroup.agri.applicationforms.pua.core.model;

/**
 * The enum File permitted enum.
 * @author Carlo Sindico
 */
public enum FilePermittedEnum {
    PDF,
    JPEG,
    JPG,
    TIFF,
    XLSX,
    XLS,
    ODS,
    PNG,
    P7M;

    public static boolean isValid(final String value) {
        for (FilePermittedEnum filePermittedEnum : FilePermittedEnum.values()) {
            if (filePermittedEnum.toString().equalsIgnoreCase(value))
                return true;
        }

        return false;
    }
}
