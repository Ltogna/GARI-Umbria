package com.abacogroup.agri.applicationforms.pua.db.dao;

import com.abacogroup.agri.applicationforms.pua.db.ntt.NoSpreadingPeriodLatestInsertNTT;
import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.customizer.BindBean;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;

public interface NoSpreadingPeriodLatestInsertDAO {

	@SqlUpdate("""
			    INSERT INTO appfpua_no_spreading_periods_latest_insert
			    (application_id, party_id, effluent, year, day_from, day_to)
			    VALUES (:applicationId, :partyId, :effluent, :year, :dayFrom, :dayTo)
			    ON CONFLICT (party_id, effluent, year)
			    DO UPDATE SET
			        application_id = excluded.application_id,
			        day_from = excluded.day_from,
			        day_to = excluded.day_to
			""")
	void upsert(@BindBean NoSpreadingPeriodLatestInsertNTT entity);

	@SqlQuery("""
			    SELECT * FROM appfpua_no_spreading_periods_latest_insert
			    WHERE party_id = :partyId AND effluent = :effluent AND year = :year
			""")
	@RegisterBeanMapper(NoSpreadingPeriodLatestInsertNTT.class)
	NoSpreadingPeriodLatestInsertNTT getByKey(@Bind("partyId") Integer partyId,
			@Bind("effluent") String effluent,
			@Bind("year") Integer year);

	@SqlUpdate("""
			    DELETE FROM appfpua_no_spreading_periods_latest_insert
			    WHERE party_id = :partyId AND year = :year
			""")
	void deleteByPartyAndYear(@Bind("partyId") Long partyId, @Bind("year") Integer year);

	@SqlQuery("""
			    SELECT COUNT(*) FROM appfpua_no_spreading_periods_latest_insert
			    WHERE year = :year
			      AND party_id = :partyId
			      AND effluent = :effluent
			""")
	int countByYearPartyEffluent(@Bind("year") int year, @Bind("partyId") Long partyId, @Bind("effluent") String effluent);

}
