package com.abacogroup.agri.applicationforms.pua.core.model.dto;

import com.abacogroup.dynamicdocuments.bean.Document;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

/**
 * @author Alexandru Paraschiv
 */
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class DeclarationsDTO {
	private Document document;
}
