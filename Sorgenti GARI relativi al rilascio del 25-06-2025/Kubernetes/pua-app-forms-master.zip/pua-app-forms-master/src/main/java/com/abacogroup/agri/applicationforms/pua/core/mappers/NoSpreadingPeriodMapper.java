package com.abacogroup.agri.applicationforms.pua.core.mappers;

import com.abacogroup.agri.applicationforms.pua.core.model.AbsoluteDate;
import com.abacogroup.agri.applicationforms.pua.core.model.dto.NoSpreadingPeriodDTO;
import com.abacogroup.agri.applicationforms.pua.db.ntt.NoSpreadingPeriodNTT;
import com.abacogroup.jdbi.mapper.AbsoluteDateMapper;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;
import org.mapstruct.factory.Mappers;

/**
 * @author Emanuele Crocilla
 */
@Mapper(uses = AbsoluteDateMapper.class)
public interface NoSpreadingPeriodMapper extends EntityMapper<NoSpreadingPeriodDTO, NoSpreadingPeriodNTT> {

	NoSpreadingPeriodMapper INSTANCE = Mappers.getMapper(NoSpreadingPeriodMapper.class);

	@InheritInverseConfiguration()
	@Mapping(source = "pkid", target = "pkId")
	@Mapping(source = "dayFrom", target = "dayFrom", qualifiedByName = "stringToAbsoluteDate")
	@Mapping(source = "dayTo", target = "dayTo", qualifiedByName = "stringToAbsoluteDate")
	NoSpreadingPeriodDTO entityToDto(NoSpreadingPeriodNTT entity);

	@Mapping(source = "pkId", target = "pkid")
	@Mapping(source = "dayFrom", target = "dayFrom", qualifiedByName = "absoluteDateToString")
	@Mapping(source = "dayTo", target = "dayTo", qualifiedByName = "absoluteDateToString")
	NoSpreadingPeriodNTT dtoToEntity(NoSpreadingPeriodDTO dto);

	@Named("absoluteDateToString")
	default String absoluteDateToString(AbsoluteDate date) {
		return date != null ? date.toString() : null;
	}

	@Named("stringToAbsoluteDate")
	default AbsoluteDate stringToAbsoluteDate(String value) {
		return value != null ? new AbsoluteDate(value) : null;
	}
}
