package com.abacogroup.agri.applicationforms.pua.core.model.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 
 * @author Emanuele Crocilla
 * 
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class EffluentFrequency {

    private String code;
    private String description;
    private Double nitrogen;
}
