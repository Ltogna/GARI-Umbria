package com.abacogroup.agri.applicationforms.pua.core.model.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 
 * @author Emanuele Crocilla
 * 
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class GiasResponse {

    private String cuaa;
    private String dati;
 
}
