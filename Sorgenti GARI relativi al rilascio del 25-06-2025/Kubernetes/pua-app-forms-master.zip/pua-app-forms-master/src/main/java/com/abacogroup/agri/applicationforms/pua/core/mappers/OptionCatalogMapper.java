package com.abacogroup.agri.applicationforms.pua.core.mappers;

import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import com.abacogroup.agri.applicationforms.pua.core.model.dto.OptionCatalogDTO;
import com.abacogroup.agri.applicationforms.pua.db.ntt.OptionCatalogNTT;
import com.abacogroup.jdbi.mapper.AbsoluteDateMapper;

/**
 * @author Alexandru Paraschiv
 */
@Mapper(uses = AbsoluteDateMapper.class)
public interface OptionCatalogMapper extends EntityMapper<OptionCatalogDTO, OptionCatalogNTT> {

	OptionCatalogMapper INSTANCE = Mappers.getMapper(OptionCatalogMapper.class);

	@InheritInverseConfiguration()
	OptionCatalogDTO entityToDto(OptionCatalogNTT entity);

	@Mapping(source = "id", target = "id")
	@Mapping(source = "optionCode", target = "option_code")
	@Mapping(source = "tenantId", target = "tenant_id")
	@Mapping(source = "optionDescription", target = "option_description")
	OptionCatalogNTT dtoToEntity(OptionCatalogDTO dto);

}
