package com.abacogroup.agri.applicationforms.pua.core.model.dto.enums;

/**
 * 
 * @author Emanuele Crocilla
 *
 */
public enum Cycle {

	
	PRINCIPALE("Principale", 0), SECONDARIO("Secondario", 1);
	
	private int code;
	private String description;

	private Cycle(String description, int code) {
		this.description = description;
		this.code = code;
	}
	
	public String getDescription() {
		return description;
	}
	
	public int getCode() {
		return code;
	}
	
	public static String getDescriptionByCode(Integer code) {
		if (null != code) {
			for (Cycle cycle : values()) {
				if (cycle.getCode() == code) {
					return cycle.getDescription();
				}
			}
		}
		return null;
	}

	public static boolean validateCode(Integer code) {
		if (null != code) {
			for (Cycle cycle : values()) {
				if (cycle.getCode() == code) {
					return true;
				}
			}
		}
		return false;
	}
}
