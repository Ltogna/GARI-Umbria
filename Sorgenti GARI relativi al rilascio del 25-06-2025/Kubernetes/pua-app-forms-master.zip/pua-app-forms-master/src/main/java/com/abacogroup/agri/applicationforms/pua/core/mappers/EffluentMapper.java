package com.abacogroup.agri.applicationforms.pua.core.mappers;

import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import com.abacogroup.agri.applicationforms.pua.core.model.dto.EffluentDTO;
import com.abacogroup.agri.applicationforms.pua.db.ntt.EffluentNTT;
import com.abacogroup.jdbi.mapper.AbsoluteDateMapper;

/**
 * 
 * @author Emanuele Crocilla
 *
 */
@Mapper(uses = AbsoluteDateMapper.class)
public interface EffluentMapper extends EntityMapper<EffluentDTO, EffluentNTT> {

	EffluentMapper INSTANCE = Mappers.getMapper(EffluentMapper.class);

	@InheritInverseConfiguration()
	EffluentDTO entityToDto(EffluentNTT entity);

	EffluentNTT dtoToEntity(EffluentDTO dto);

}
