package com.abacogroup.agri.applicationforms.pua.resources;

import java.time.Instant;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.util.Calendar;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

import com.abacogroup.agri.applicationforms.pua.ApplicationFormsModuleConfiguration;
import com.abacogroup.agri.applicationforms.pua.core.exceptions.ObjectNotFoundRuntimeException;
import com.abacogroup.agri.applicationforms.pua.core.model.dto.FiveYearDeclarationDTO;
import com.abacogroup.agri.applicationforms.pua.services.FiveYearDeclarationService;
import com.abacogroup.agri.applicationforms.pua.services.common.ApplicationFacadeService;
import com.abacogroup.agri.applicationforms.pua.util.CommonConstants;
import com.abacogroup.applicationworkflowsdk.model.io.output.ApplicationDetailsPublicDTO;
import com.abacogroup.dropwizard.auth.sso2.Sso2Client;
import com.abacogroup.dropwizard.auth.sso2.User;

import io.dropwizard.auth.Auth;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.parameters.RequestBody;
import jakarta.validation.constraints.NotNull;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.Response;

/**
 * 
 * @author Emanuele Crocilla
 *
 */
public class FiveYearDeclarationResources extends AGenericPuaResources {
	
	public FiveYearDeclarationResources(
			ApplicationFormsModuleConfiguration configuration, 
			ApplicationFacadeService applicationFacadeService,
			FiveYearDeclarationService fiveYearDeclarationService, 
			Sso2Client sso2Client) {
		
		super(configuration, sso2Client);
		
		this.applicationFacadeService = applicationFacadeService;
		this.fiveYearDeclarationService = fiveYearDeclarationService;
	}
	
	@GET
	@Path("/{applicationId}/five-year-declaration/{id}")
	public Response get(
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "Current Tenant") @NotNull @PathParam("tenant") String tenant,
			@Parameter(description = "The application id") @NotNull @PathParam("applicationId") Long applicationId,
			@Parameter(description = "The declatation id") @NotNull @PathParam("id") Long id
			) {
		
		FiveYearDeclarationDTO dto = null;
		
		try {
			
			dto = fiveYearDeclarationService.get(user, tenant, applicationId, id);
			
			ApplicationDetailsPublicDTO applicationDetailsPublicDTO = 
					applicationFacadeService.callForApplicationDetails(tenant, applicationId, user, Locale.ITALIAN.getLanguage());
			
			Long partyId = applicationDetailsPublicDTO.getPartyId();
			if (partyId.equals(dto.getPartyId())) {
				dto.setPartyId(null);
			}
			
		} catch (ObjectNotFoundRuntimeException e) {
			return Response.noContent().build();
		}
		
		return Response.ok(dto).build();
	}
	
	@GET
	@Path("/{applicationId}/five-year-declarations")
	public Response getAll(
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "Current Tenant") @NotNull @PathParam("tenant") String tenant,
			@Parameter(description = "The application id") @NotNull @PathParam("applicationId") Long applicationId) {
		
		List<FiveYearDeclarationDTO> dtos = null;
		
		try {
			
			dtos = fiveYearDeclarationService.getAll(user, tenant, applicationId);
			
			ApplicationDetailsPublicDTO applicationDetailsPublicDTO = 
					applicationFacadeService.callForApplicationDetails(tenant, applicationId, user, Locale.ITALIAN.getLanguage());
			
			Long partyId = applicationDetailsPublicDTO.getPartyId();
			dtos.forEach((dto) -> {
				if (partyId.equals(dto.getPartyId())) {
					dto.setPartyId(null);
				}
			});
			
		} catch (ObjectNotFoundRuntimeException e) {
			return Response.ok(Collections.emptyList()).build();
		}

		return Response.ok(dtos).build();
	}
	
	@POST
	@Path("/{applicationId}/five-year-declaration")
	public Response add(
			@Auth User user, 
			@NotNull @RequestBody FiveYearDeclarationDTO payload,
			@Parameter(description = "Current Tenant") @NotNull @PathParam("tenant") String tenantId,
			@Parameter(description = "The application id") @NotNull @PathParam("applicationId") Long applicationId,
			@Parameter(description = "The form config id") @NotNull @QueryParam("formConfigId") Long formConfigId,
			@Parameter(description = "The compile status identifier") @QueryParam("compileStatusIdentifier") String compileStatusIdentifier
	) {
		
		ApplicationDetailsPublicDTO applicationDetailsPublicDTO = 
				applicationFacadeService.callForApplicationDetails(tenantId, applicationId, user, Locale.ITALIAN.getLanguage());
		
		long rightNow = Calendar.getInstance().getTimeInMillis();
    	Instant instantRightNow = Instant.ofEpochMilli(rightNow);
		OffsetDateTime dateTimeRightNow = instantRightNow.atOffset(ZoneOffset.UTC);
		
		boolean isMyCompany = false;
		
		payload.setApplicationId(applicationId);
		payload.setId(0L);// temporary id
		
		if (null == payload.getPartyId()) {
			Long partyId = applicationDetailsPublicDTO.getPartyId();
			payload.setPartyId(partyId);
			isMyCompany = true;
		}
		
		payload.setUserIdInsert(user.getUserId());
		payload.setDtInsert(dateTimeRightNow);
		payload.setDtDelete(CommonConstants.FAR_OFF_DATE);
		
		FiveYearDeclarationDTO res = fiveYearDeclarationService.insert(user, tenantId, applicationId, formConfigId, compileStatusIdentifier, payload);
		
		// for local company must return partyId as null
		if ( isMyCompany ) {
			res.setPartyId(null);
		}
		
		return Response.ok(res).build();
	}
	
	@PUT
	@Path("/{applicationId}/five-year-declaration/{id}")
	public Response update(
			@Auth User user, 
			@NotNull @RequestBody FiveYearDeclarationDTO payload,
			@Parameter(description = "Current Tenant") @NotNull @PathParam("tenant") String tenantId,
			@Parameter(description = "The application id") @NotNull @PathParam("applicationId") Long applicationId,
			@Parameter(description = "The form config id") @NotNull @QueryParam("formConfigId") Long formConfigId,
			@Parameter(description = "The compile status identifier") @QueryParam("compileStatusIdentifier") String compileStatusIdentifier,
			@Parameter(description = "The declatation id") @NotNull @PathParam("id") Long declatationId
	) {
		 
		payload.setId(declatationId);
		payload.setApplicationId(applicationId);
		payload.setUserIdInsert(user.getUserId());
		payload.setDtDelete(CommonConstants.FAR_OFF_DATE);
		
		ApplicationDetailsPublicDTO applicationDetailsPublicDTO = 
				applicationFacadeService.callForApplicationDetails(tenantId, applicationId, user, Locale.ITALIAN.getLanguage());
		
		boolean isMyCompany = false;
		
		if (null == payload.getPartyId()) {
			Long partyId = applicationDetailsPublicDTO.getPartyId();
			payload.setPartyId(partyId);
			isMyCompany = true;
		}
		
		FiveYearDeclarationDTO res = fiveYearDeclarationService.update(user, tenantId, applicationId, formConfigId, compileStatusIdentifier, payload);
		
		// for local company must return partyId as null
		if ( isMyCompany ) {
			res.setPartyId(null);
		}
		
		return Response.ok(res).build();
	}
	
	@DELETE
	@Path("/{applicationId}/five-year-declaration/{id}")
	public void delete(
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "Current Tenant") @NotNull @PathParam("tenant") String tenantId,
			@Parameter(description = "The application id") @NotNull @PathParam("applicationId") Long applicationId,
			@Parameter(description = "The form config id") @NotNull @QueryParam("formConfigId") Long formConfigId, 
			@Parameter(description = "The compile status identifier") @QueryParam("compileStatusIdentifier") String compileStatusIdentifier,
			@Parameter(description = "The declatation id") @NotNull @PathParam("id") Long id) {
		
		fiveYearDeclarationService.delete(user, tenantId, applicationId, formConfigId, compileStatusIdentifier, id);
	}

}
