package com.abacogroup.agri.applicationforms.pua.core.exceptions;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.ws.rs.core.Response;

/**
 * 
 * @author Emanuele Crocilla
 *
 */
public class OptionCodeListNotValidRuntimeException extends AbstractException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private static final OptionCodeListNotValidRuntimeException.ErrorBody BODY = new OptionCodeListNotValidRuntimeException.ErrorBody();

	public OptionCodeListNotValidRuntimeException() {
		super(Response.Status.FORBIDDEN, BODY, "option code list not valid");
	}

	@Schema(name = "OptionCodeListNotValidRuntimeExceptionErrorBody")
	public static class ErrorBody implements ExceptionErrorBody {
		private static final String ERR = "OPTION_CODE_LIST_NOT_VALID_ERROR";

		@Override
		@Schema(allowableValues = ERR)
		public String getErrorCode() {
			return ERR;
		}
	}
}
