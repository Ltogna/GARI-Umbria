package com.abacogroup.agri.applicationforms.pua.core.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author Gennaro Tamburrelli
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class ApplicationKey {
	private String tenant;
	private Long applicationId;
	private String username;
	private String authToken;
	private String locale;
}
