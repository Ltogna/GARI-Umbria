package com.abacogroup.agri.applicationforms.pua.resources;

import com.abacogroup.agri.applicationforms.pua.ApplicationFormsModuleConfiguration;
import com.abacogroup.agri.applicationforms.pua.core.model.dto.TipologiaDichiarazioneDTO;
import com.abacogroup.agri.applicationforms.pua.services.TipologiaDichiarazioneService;
import com.abacogroup.agri.applicationforms.pua.util.CommonConstants;
import com.abacogroup.dropwizard.auth.sso2.Sso2Client;
import com.abacogroup.dropwizard.auth.sso2.User;
import io.dropwizard.auth.Auth;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.parameters.RequestBody;
import jakarta.validation.constraints.NotNull;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.Response;

/**
 * @author Emanuele Crocilla
 */
public class TipologiaDichiarazioneResources extends AGenericPuaResources {

	public TipologiaDichiarazioneResources(ApplicationFormsModuleConfiguration configuration, TipologiaDichiarazioneService tipologiaDichiarazioneService,
			Sso2Client sso2Client) {
		super(configuration, sso2Client);
		this.tipologiaDichiarazioneService = tipologiaDichiarazioneService;
	}

	@GET
	@Path("/{applicationId}/tipologia-dichiarazione")
	public Response get(
			@NotNull @Parameter(hidden = true) @Auth User user,
			@Parameter(description = "Current Tenant") @NotNull @PathParam("tenant") String tenant,
			@NotNull @Parameter(description = "The application id") @NotNull @PathParam("applicationId") Long applicationId) {

		TipologiaDichiarazioneDTO tipologiaDichiarazione = tipologiaDichiarazioneService.get(user, tenant, applicationId);

		if (tipologiaDichiarazione != null) {
			return Response.ok(tipologiaDichiarazione).build();
		}

		return Response.ok().build();
	}

	@POST
	@Path("/{applicationId}/tipologie-dichiarazione")
	public Response add(
			@Auth User user,
			@NotNull @RequestBody TipologiaDichiarazioneDTO payload,
			@Parameter(description = "Current Tenant") @NotNull @PathParam("tenant") String tenant,
			@Parameter(description = "The application id") @NotNull @PathParam("applicationId") Long applicationId,
			@Parameter(description = "The form config id") @NotNull @QueryParam("formConfigId") Long formConfigId,
			@Parameter(description = "The compile status identifier") @QueryParam("compileStatusIdentifier") String compileStatusIdentifier
	) {
		payload.setApplicationId(applicationId);
		payload.setUserIdInsert(user.getUserId());
		payload.setDtDelete(CommonConstants.FAR_OFF_DATE);

		TipologiaDichiarazioneDTO res = tipologiaDichiarazioneService.insert(user, tenant, applicationId, formConfigId, compileStatusIdentifier, payload);
		return Response.ok(res).build();
	}

	@PUT
	@Path("/{applicationId}/tipologia-dichiarazione")
	public Response update(
			@Auth User user,
			@NotNull @RequestBody TipologiaDichiarazioneDTO payload,
			@Parameter(description = "Current Tenant") @NotNull @PathParam("tenant") String tenant,
			@Parameter(description = "The application id") @NotNull @PathParam("applicationId") Long applicationId,
			@Parameter(description = "The form config id") @NotNull @QueryParam("formConfigId") Long formConfigId,
			@Parameter(description = "The compile status identifier") @QueryParam("compileStatusIdentifier") String compileStatusIdentifier
	) {
		payload.setApplicationId(applicationId);
		payload.setUserIdInsert(user.getUserId());
		payload.setDtDelete(CommonConstants.FAR_OFF_DATE);
		TipologiaDichiarazioneDTO res = tipologiaDichiarazioneService.update(user, tenant, applicationId, formConfigId, compileStatusIdentifier, payload);
		return Response.ok(res).build();
	}

	@DELETE
	@Path("/{applicationId}/tipologia-dichiarazione")
	public void delete(
			@NotNull @Parameter(hidden = true) @Auth User user,
			@Parameter(description = "Current Tenant") @NotNull @PathParam("tenant") String tenant,
			@Parameter(description = "The application id") @NotNull @PathParam("applicationId") Long applicationId,
			@Parameter(description = "The form config id") @NotNull @QueryParam("formConfigId") Long formConfigId,
			@Parameter(description = "The compile status identifier") @QueryParam("compileStatusIdentifier") String compileStatusIdentifier
	) {

		tipologiaDichiarazioneService.delete(user, tenant, applicationId, formConfigId, compileStatusIdentifier);
	}

}
