package com.abacogroup.agri.applicationforms.pua.core.mappers;

import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import com.abacogroup.agri.applicationforms.pua.core.model.dto.ApplicationOptionDTO;
import com.abacogroup.agri.applicationforms.pua.db.ntt.ApplicationOptionNTT;
import com.abacogroup.jdbi.mapper.AbsoluteDateMapper;

/**
 * @author Mattia Perini
 */
@Mapper(uses = AbsoluteDateMapper.class)
public interface ApplicationOptionMapper extends EntityMapper<ApplicationOptionDTO, ApplicationOptionNTT> {

	ApplicationOptionMapper INSTANCE = Mappers.getMapper(ApplicationOptionMapper.class);

	@InheritInverseConfiguration()
	ApplicationOptionDTO entityToDto(ApplicationOptionNTT entity);

	@Mapping(source = "pkid", target = "pkid")
	@Mapping(source = "applicationId", target = "application_id")
	@Mapping(source = "optionConfigId", target = "option_config_id")
	@Mapping(source = "optionCode", target = "option_code")
	@Mapping(source = "documentId", target = "document_id")
	@Mapping(source = "takeoverId", target = "takeover_id")
	@Mapping(source = "startApplicationId", target = "start_application_id")
	@Mapping(source = "previousApplicationId", target = "previous_application_id")
	@Mapping(source = "userIdInsert", target = "user_id_insert")
	@Mapping(source = "userIdDelete", target = "user_id_delete")
	@Mapping(source = "dtInsert", target = "dt_insert")
	@Mapping(source = "dtDelete", target = "dt_delete")
    ApplicationOptionNTT dtoToEntity(ApplicationOptionDTO dto);

}
