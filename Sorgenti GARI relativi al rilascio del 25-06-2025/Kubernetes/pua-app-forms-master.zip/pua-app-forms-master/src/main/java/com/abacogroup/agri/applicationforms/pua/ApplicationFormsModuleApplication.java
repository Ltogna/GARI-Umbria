package com.abacogroup.agri.applicationforms.pua;

import com.abacogroup.agri.applicationforms.pua.bundles.processor.attachmenttypes.AttachmentTypesBundleWorker;
import com.abacogroup.agri.applicationforms.pua.bundles.processor.attachmenttypes.AttachmentTypesNewTenantProcessor;
import com.abacogroup.agri.applicationforms.pua.bundles.processor.attachmenttypes.BundleAttachmentTypesProcessor;
import com.abacogroup.agri.applicationforms.pua.bundles.processor.dyinamicdocumenttypes.BundleDynamicDocumentTypesProcessor;
import com.abacogroup.agri.applicationforms.pua.bundles.processor.dyinamicdocumenttypes.DynamicDocumentTypesBundleWorker;
import com.abacogroup.agri.applicationforms.pua.bundles.processor.effluenttypes.BundleEffluentTypesProcessor;
import com.abacogroup.agri.applicationforms.pua.bundles.processor.effluenttypes.EffluentTypesBundleWorker;
import com.abacogroup.agri.applicationforms.pua.common.dynamidocument.DynamicDocumentService;
import com.abacogroup.agri.applicationforms.pua.config.BundleConfig;
import com.abacogroup.agri.applicationforms.pua.config.RabbitMqConfig;
import com.abacogroup.agri.applicationforms.pua.core.mappers.*;
import com.abacogroup.agri.applicationforms.pua.db.dao.*;
import com.abacogroup.agri.applicationforms.pua.jackson.WKTGeometryDeserializer;
import com.abacogroup.agri.applicationforms.pua.jackson.WKTGeometrySerializer;
import com.abacogroup.agri.applicationforms.pua.resources.*;
import com.abacogroup.agri.applicationforms.pua.services.*;
import com.abacogroup.agri.applicationforms.pua.services.common.AppfPuaDynamicDocumentsCrudService;
import com.abacogroup.agri.applicationforms.pua.services.common.ApplicationFacadeConfig;
import com.abacogroup.agri.applicationforms.pua.services.common.ApplicationFacadeService;
import com.abacogroup.agri.applicationforms.pua.services.common.I18NService;
import com.abacogroup.agri.applicationforms.pua.services.common.crud.AttachmentsCrudService;
import com.abacogroup.agri.applicationforms.pua.util.CurrentDB;
import com.abacogroup.agri.applicationforms.pua.util.CurrentDB.DB;
import com.abacogroup.applicationsupport.caller.*;
import com.abacogroup.bundles.listener.ListenerBuilder;
import com.abacogroup.bundles.listener.configdata.ProcessorOrderPolicyEnum;
import com.abacogroup.bundles.listener.configdata.builder.ConfigDataConsumerBuilder;
import com.abacogroup.bundles.listener.tenant.builder.NewTenantEventConsumerBuilder;
import com.abacogroup.dropwizard.auth.sso2.AuthUtils;
import com.abacogroup.dropwizard.auth.sso2.Sso2Client;
import com.abacogroup.dropwizard.auth.sso2.SsoAuthorizer;
import com.abacogroup.dynamicdocuments.services.DocumentService;
import com.abacogroup.dynamicdocuments.services.DocumentTypeService;
import com.abacogroup.filestore.client.FileStoreClient;
import com.abacogroup.jaxrsutils.GenericCallerService;
import com.abacogroup.jaxrsutils.model.AbacoTechUser;
import com.abacogroup.jdbi.OraJdbiPlugin;
import com.abacogroup.jdbi.PgJdbiPlugin;
import com.abacogroup.jdbi.config.AbacoJdbiConfig;
import com.abacogroup.tracing.dropwizard.AbacoApplication;
import com.fasterxml.jackson.core.Version;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.databind.module.SimpleModule;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;
import io.dropwizard.client.JerseyClientBuilder;
import io.dropwizard.client.JerseyClientConfiguration;
import io.dropwizard.configuration.EnvironmentVariableSubstitutor;
import io.dropwizard.configuration.SubstitutingSourceProvider;
import io.dropwizard.core.setup.Bootstrap;
import io.dropwizard.core.setup.Environment;
import io.dropwizard.db.DataSourceFactory;
import io.dropwizard.jdbi3.JdbiFactory;
import io.dropwizard.jdbi3.bundles.JdbiExceptionsBundle;
import io.dropwizard.migrations.MigrationsBundle;
import io.swagger.v3.jaxrs2.SwaggerSerializers;
import io.swagger.v3.jaxrs2.integration.resources.OpenApiResource;
import io.swagger.v3.oas.integration.SwaggerConfiguration;
import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Contact;
import io.swagger.v3.oas.models.info.Info;
import jakarta.servlet.DispatcherType;
import jakarta.servlet.FilterRegistration.Dynamic;
import jakarta.ws.rs.client.Client;
import lombok.extern.slf4j.Slf4j;
import oracle.jdbc.OracleConnection;
import org.apache.commons.lang3.StringUtils;
import org.eclipse.jetty.servlets.CrossOriginFilter;
import org.glassfish.jersey.media.multipart.MultiPartFeature;
import org.jdbi.v3.core.Jdbi;
import org.jdbi.v3.sqlobject.SqlObjectPlugin;
import org.locationtech.jts.geom.Geometry;

import java.io.IOException;
import java.net.URI;
import java.sql.DatabaseMetaData;
import java.util.EnumSet;
import java.util.concurrent.TimeoutException;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@Slf4j
public class ApplicationFormsModuleApplication extends AbacoApplication<ApplicationFormsModuleConfiguration> {
	public static void main(String[] args) throws Exception {
		new ApplicationFormsModuleApplication().run(args);
	}

	@Override
	public void initialize(Bootstrap<ApplicationFormsModuleConfiguration> bootstrap) {
		bootstrap.addBundle(new JdbiExceptionsBundle());
		bootstrap.addBundle(new MigrationsBundle<>() {
			@Override
			public DataSourceFactory getDataSourceFactory(ApplicationFormsModuleConfiguration configuration) {
				return configuration.getDatabase();
			}
		});
		SubstitutingSourceProvider provider = new SubstitutingSourceProvider(bootstrap.getConfigurationSourceProvider(),
				new EnvironmentVariableSubstitutor(false));
		bootstrap.setConfigurationSourceProvider(provider);
	}

	@Override
	public void doRun(ApplicationFormsModuleConfiguration config, Environment environment) {
		ObjectMapper objectMapper = environment.getObjectMapper();
		configure(objectMapper);

		final JdbiFactory factory = new JdbiFactory();
		final Jdbi jdbi = factory.build(environment, config.getDatabase(), "ApplicationsApplication");

		boolean isPostgres = jdbi.withHandle(h -> {
			String db = h.queryMetadata(DatabaseMetaData::getDatabaseProductName);
			log.info("Database connection is '{}'", db);
			return db.toLowerCase().contains("postgresql");
		});

		CurrentDB.getInstance().setDbName(isPostgres ? DB.POSTGRES : DB.ORACLE);

		// jdbi database configuration
		jdbi.installPlugin(new SqlObjectPlugin());
		if (isPostgres) {
			jdbi.installPlugin(new PgJdbiPlugin());
		} else {
			var params = new OraJdbiPlugin.OraJdbiPluginParams(cnn -> cnn.unwrap(OracleConnection.class), true);
			jdbi.installPlugin(new OraJdbiPlugin(params));
		}

		jdbi.configure(AbacoJdbiConfig.class, cfg -> cfg.setTablesPrefix("appfpua"));

		// build http client
		JerseyClientConfiguration clientConfig = config.getJerseyClientConfiguration();
		final Client client = new JerseyClientBuilder(environment).using(clientConfig)
				.build(getName());

		Sso2Client sso2Client = new Sso2Client(config.getSso2TokenSecretAuth(), client.target(config.getSso2Url()));

		FileStoreClient fileStoreClient = new FileStoreClient(URI.create(config.getFileStoreUrl()), objectMapper);

		// DAOs Initialization
		TipologiaDichiarazioneDAO tipologiaDichiarazioneDAO = jdbi.onDemand(TipologiaDichiarazioneDAO.class);
		DeclarationsOnSectorsDAO declarationOnSectorsDAO = jdbi.onDemand(DeclarationsOnSectorsDAO.class);
		I18NDAO i18NDAO = jdbi.onDemand(I18NDAO.class);
		AttachmentDAO attachmentDAO = jdbi.onDemand(AttachmentDAO.class);
		AttachmentTypeDAO attachmentTypeDAO = jdbi.onDemand(AttachmentTypeDAO.class);
		AppfPuaDynamicDocumentsDAO appfPuaDynamicDocumentsDAO = jdbi.onDemand(AppfPuaDynamicDocumentsDAO.class);
		OptionCatalogDAO optionCatalogDAO = jdbi.onDemand(OptionCatalogDAO.class);
		NoSpreadingPeriodDAO noSpreadingPeriodDAO = jdbi.onDemand(NoSpreadingPeriodDAO.class);
		NoSpreadingPeriodLatestInsertDAO latestInsertDAO = jdbi.onDemand(NoSpreadingPeriodLatestInsertDAO.class);
		ApplicationOptionDAO applicationOptionDAO = jdbi.onDemand(ApplicationOptionDAO.class);
		OptionConfigsDAO optionConfigsDAO = jdbi.onDemand(OptionConfigsDAO.class);
		OptionParamDAO optionParamDAO = jdbi.onDemand(OptionParamDAO.class);
		FiveYearDeclarationDAO fiveYearDeclarationDAO = jdbi.onDemand(FiveYearDeclarationDAO.class);
		OrganicFertilizerSpreadingDeclarationDAO organicFertilizerSpreadingDeclarationDAO = jdbi.onDemand(OrganicFertilizerSpreadingDeclarationDAO.class);
		EffluentDAO effluentTypeDAO = jdbi.onDemand(EffluentDAO.class);
		DeclOnCropsDAO declarationOnCropsDAO = jdbi.onDemand(DeclOnCropsDAO.class);
		DeclOnCropLiveStocksDAO declarationOnCropsLSDAO = jdbi.onDemand(DeclOnCropLiveStocksDAO.class);

		// callers
		GenericCallerService genericCallerService = new GenericCallerService(client, new AbacoTechUser());
		GetFormReadOnlyCaller getFormReadOnlyCaller = new GetFormReadOnlyCaller(genericCallerService);
		GetCompileStatusCaller getCompileStatusCaller = new GetCompileStatusCaller(genericCallerService);
		PutCompileStatusCaller putCompileStatusCaller = new PutCompileStatusCaller(genericCallerService);
		DeleteCompileStatusCaller deleteCompileStatusCaller = new DeleteCompileStatusCaller(genericCallerService);
		PutProfilesCaller putProfilesCaller = new PutProfilesCaller(genericCallerService);
		GetApplicationDetailsCaller getApplicationDetailsCaller = new GetApplicationDetailsCaller(genericCallerService);
		GetApplicationByPartyYearModuleCodeCaller getApplicationByPartyYearModuleCodeCaller = new GetApplicationByPartyYearModuleCodeCaller(
				genericCallerService);
		//				GetUserBySso2Caller getUserBySso2Caller = new GetUserBySso2Caller(genericCallerService);
		//				GetPartiesCaller getPartiesCaller = new GetPartiesCaller(genericCallerService);
		//				GetPartyCaller getPartyCaller = new GetPartyCaller(genericCallerService);
		//				GetFuelValuesWithdrawnCaller getFuelValuesWithdrawnCaller = new GetFuelValuesWithdrawnCaller(genericCallerService);
		//				GetFuelValuesMaximumAssignedCaller getFuelValuesMaximumAssignedCaller = new GetFuelValuesMaximumAssignedCaller(genericCallerService);

		//				GetAllParcelDataCaller getAllParcelDataCaller = new GetAllParcelDataCaller(genericCallerService);
		//				GetAllParcelDataByParcelNumberCaller getAllParcelDataByParcelNumberCaller = new GetAllParcelDataByParcelNumberCaller(genericCallerService);
		//				GetCouncilNameBySectorCodeCaller getCouncilNameBySectorCodeCaller = new GetCouncilNameBySectorCodeCaller(genericCallerService);
		GetFormDetailsCaller getFormDetailsCaller = new GetFormDetailsCaller(genericCallerService);
		//				PostCouncilNamesByIstatCodesCaller postCouncilNamesByIstatCodesCaller = new PostCouncilNamesByIstatCodesCaller(genericCallerService);
		//				GetAllParcelDataByGeometryCaller getAllParcelDataByGeometryCaller = new GetAllParcelDataByGeometryCaller(genericCallerService);
		//				GetAllParcelDataByPlotCodeAndCPInfoCaller getAllParcelDataByPlotCodeAndCPInfoCaller = new GetAllParcelDataByPlotCodeAndCPInfoCaller(genericCallerService);
		//				GetAllModuleFormConfigsByModuleCodeCaller getAllModuleFormConfigsByModuleCodeCaller = new GetAllModuleFormConfigsByModuleCodeCaller(genericCallerService);

		//				GetParcelsDataCallingAvepaService getParcelsDataCallingAvepaService = new GetParcelsDataCallingAvepaService(getCouncilNameBySectorCodeCaller,
		//						postCouncilNamesByIstatCodesCaller, getAllParcelDataCaller, getAllParcelDataByGeometryCaller, getAllParcelDataByPlotCodeAndCPInfoCaller, config.getAvepaLegacyUrl());

		//				GetApplicationMyTransitionHistoryCaller getApplicationTransitionHistoryCaller = new GetApplicationMyTransitionHistoryCaller(genericCallerService);
		GetApplicationPrintHistoryCaller getApplicationPrintHistoryCaller = new GetApplicationPrintHistoryCaller(genericCallerService);
		GetApplicationProfilesCaller getApplicationProfilesCaller = new GetApplicationProfilesCaller(genericCallerService);
		//				GetFormDetailsByProcessStatusCaller getFormDetailsByProcessStatusCaller = new GetFormDetailsByProcessStatusCaller(genericCallerService);
		//		        CountNumberOfApplicationsCaller countNumberOfApplicationsCaller = new CountNumberOfApplicationsCaller(genericCallerService);

		// services init
		FileStoreService fileStoreService = new FileStoreService(fileStoreClient, sso2Client);
		FileCheckerService fileCheckerService = new FileCheckerService();

		var applicationFacadeConfig = ApplicationFacadeConfig.builder()
				.getCompileStatusCaller(getCompileStatusCaller)
				.getFormReadOnlyCaller(getFormReadOnlyCaller)
				.putCompileStatusCaller(putCompileStatusCaller)
				.deleteCompileStatusCaller(deleteCompileStatusCaller)
				.putProfilesCaller(putProfilesCaller)
				.getApplicationDetailsCaller(getApplicationDetailsCaller)
				.getApplicationByPartyYearModuleCodeCaller(getApplicationByPartyYearModuleCodeCaller)
				.getFormDetailsCaller(getFormDetailsCaller)
				.getApplicationPrintHistoryCaller(getApplicationPrintHistoryCaller)
				.getApplicationProfilesCaller(getApplicationProfilesCaller)
				.applicationsBaseUrl(config.getApplicationsUrl())
				.build();

		ApplicationFacadeService applicationFacadeService = new ApplicationFacadeService(applicationFacadeConfig);
		I18NService i18NService = new I18NService(i18NDAO);

		AttachmentsCrudService attachmentsCrudService = new AttachmentsCrudService(attachmentDAO, AttachmentMapper.INSTANCE);
		AttachmentTypesCrudService attachmentTypesCrudService = new AttachmentTypesCrudService(attachmentTypeDAO, AttachmentTypeMapper.INSTANCE, i18NService);
		AppfPuaDynamicDocumentsCrudService appfPuaDynamicDocumentsCrudService = new AppfPuaDynamicDocumentsCrudService(appfPuaDynamicDocumentsDAO,
				AppfPuaDynamicDocumentsMapper.INSTANCE);

		AttachmentsService attachmentsService = new AttachmentsService(jdbi, attachmentTypesCrudService,
				attachmentsCrudService, applicationFacadeService, fileStoreService, fileCheckerService, config.getAttachmentBucket());

		OptionCatalogsCrudService optionCatalogsCrudService = new OptionCatalogsCrudService(optionCatalogDAO, OptionCatalogMapper.INSTANCE, i18NService);

		ApplicationOptionCrudService applicationOptionCrudService = new ApplicationOptionCrudService(applicationOptionDAO, ApplicationOptionMapper.INSTANCE);

		OptionConfigsCrudService optionConfigsCrudService = new OptionConfigsCrudService(optionConfigsDAO, OptionConfigsMapper.INSTANCE, i18NService);

		OptionParamCrudService optionParamCrudService = new OptionParamCrudService(optionParamDAO, OptionParamMapper.INSTANCE);

		// Dynamic document
		DocumentTypeService documentTypeService = new DocumentTypeService(jdbi);
		DocumentService documentService = DocumentService.create(documentTypeService, fileStoreService, config.getAttachmentBucket());

		DynamicDocumentService dynamicDocumentService = new DynamicDocumentService(documentService, documentTypeService,
				optionCatalogsCrudService, optionConfigsCrudService, optionParamCrudService, appfPuaDynamicDocumentsCrudService,
				applicationOptionCrudService, applicationFacadeService);
		EffluentCrudService effluentCrudService = new EffluentCrudService(effluentTypeDAO, applicationFacadeService, EffluentMapper.INSTANCE);
		BancheDatiService bancheDatiService = new BancheDatiService(sso2Client, client, config, environment.getObjectMapper());

		TipologiaDichiarazioneService tipologiaDichiarazioneService = new TipologiaDichiarazioneService(tipologiaDichiarazioneDAO, applicationFacadeService,
				TipologiaDichiarazioneMapper.INSTANCE);
		GiasAgronicaService giasService = new GiasAgronicaService(sso2Client, client, config, environment.getObjectMapper());
		DeclarationsOnSectorsService declarationOnSectorsService = new DeclarationsOnSectorsService(declarationOnSectorsDAO, applicationFacadeService,
				DeclarationsOnSectorsMapper.INSTANCE, giasService);

		NoSpreadingPeriodService noSpreadingPeriodService = new NoSpreadingPeriodService(noSpreadingPeriodDAO, applicationFacadeService,
				NoSpreadingPeriodMapper.INSTANCE, latestInsertDAO, NoSpreadingPeriodLastInsertMapper.INSTANCE);

		CropPlanService cropPlanService = new CropPlanService(sso2Client, client, config, environment.getObjectMapper());

		PartyService partyService = new PartyService(sso2Client, client, config, environment.getObjectMapper());
		IpisGisService ipisGisService = new IpisGisService(sso2Client, client, config, environment.getObjectMapper());
		FiveYearDeclarationService fiveYearDeclarationService = new FiveYearDeclarationService(fiveYearDeclarationDAO, applicationFacadeService, partyService,
				FiveYearDeclarationMapper.INSTANCE);
		OrganicFertilizerSpreadingDeclarationService organicFertilizerSpreadingDeclarationService = new OrganicFertilizerSpreadingDeclarationService(
				organicFertilizerSpreadingDeclarationDAO, applicationFacadeService, giasService, partyService,
				OrganicFertilizerSpreadingDeclarationMapper.INSTANCE, bancheDatiService, noSpreadingPeriodService);

		DeclOnCropsService declarationOnCropsService = new DeclOnCropsService(declarationOnCropsDAO, applicationFacadeService,
				DeclOnCropsMapper.INSTANCE, declarationOnCropsLSDAO, DeclOnCropLiveStockMapper.INSTANCE, bancheDatiService, ipisGisService, giasService);

		DynamicDocumentTypesBundleWorker dynamicDocumentTypesBundleWorker = new DynamicDocumentTypesBundleWorker(dynamicDocumentService);
		AttachmentTypesBundleWorker attachmentTypesBundleWorker = new AttachmentTypesBundleWorker(attachmentTypesCrudService);
		EffluentTypesBundleWorker effluentTypesBundleWorker = new EffluentTypesBundleWorker(effluentCrudService);

		environment.jersey().register(tipologiaDichiarazioneService);
		environment.jersey().register(declarationOnSectorsService);
		environment.jersey().register(cropPlanService);
		environment.jersey().register(bancheDatiService);

		// Resources Registration
		environment.jersey().register(new BalanceIndicesResources(config, sso2Client, client, objectMapper));
		environment.jersey().register(new BalanceIndicesResources(config, sso2Client, client, objectMapper));
		environment.jersey().register(new TipologiaDichiarazioneResources(config, tipologiaDichiarazioneService, sso2Client));
		environment.jersey().register(
				new NoSpreadingPeriodResource(config, sso2Client, noSpreadingPeriodService));
		environment.jersey().register(
				new DeclarationsOnSectorsResources(config, applicationFacadeService, declarationOnSectorsService, cropPlanService, ipisGisService,
						bancheDatiService, sso2Client, giasService));
		environment.jersey().register(new AttachmentsResources(config, attachmentsService, applicationFacadeService, sso2Client));
		environment.jersey().register(new DynamicDocumentResources(config, dynamicDocumentService, applicationFacadeService, attachmentsService, sso2Client));
		environment.jersey().register(new FiveYearDeclarationResources(config, applicationFacadeService, fiveYearDeclarationService, sso2Client));
		environment.jersey().register(
				new OrganicFertilizerSpreadingDeclarationResources(config, applicationFacadeService, organicFertilizerSpreadingDeclarationService,
						effluentCrudService, bancheDatiService, cropPlanService, sso2Client));
		environment.jersey().register(
				new DeclOnCropsResources(config, applicationFacadeService, declarationOnCropsService, cropPlanService, ipisGisService, bancheDatiService,
						giasService, sso2Client));

		environment.jersey().register(MultiPartFeature.class);

		// register auth
		registerAuthFilters(sso2Client, config, environment);

		// register cors filter
		setupCORS(environment);

		// init open api
		initOpenApi(environment);

		Connection rabbitMQConnection = null;
		if (!"DISABLE".equals(config.getRabbitmqConfig().getHost())) {
			rabbitMQConnection = createRabbitmqConnection(config.getRabbitmqConfig());
			createBundleInfrastructure(config.getActivateBundleConfig(), rabbitMQConnection, jdbi, objectMapper,
					dynamicDocumentTypesBundleWorker,
					attachmentTypesBundleWorker,
					effluentTypesBundleWorker,
					config.getBundleConfig(),
					config.getBundleServiceId());
		}
	}

	private void registerAuthFilters(Sso2Client client, ApplicationFormsModuleConfiguration config, Environment environment) {
		AuthUtils.installAuthFilter(environment, client, new SsoAuthorizer(client));
	}

	private void initOpenApi(Environment environment) {
		OpenAPI oas = new OpenAPI();

		oas.info(new Info()
				.title("ABACO AGRI Applications")
				.description("Applications")
				.version("1.0")
				// .termsOfService("http://example.com/terms")
				.contact(new Contact().email("info@abacogroup.eu")));
		SwaggerConfiguration oasConfig = new SwaggerConfiguration()
				.openAPI(oas)
				.prettyPrint(true)
				.resourcePackages(Stream.of("com.abacogroup.agri.applicationforms.pua.resources")
						.collect(Collectors.toSet()));

		environment.jersey().register(SwaggerSerializers.class);
		environment.jersey().register(new OpenApiResource()
				.openApiConfiguration(oasConfig));
	}

	private void configure(ObjectMapper objectMapper) {
		objectMapper.disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);
		objectMapper.disable(DeserializationFeature.ADJUST_DATES_TO_CONTEXT_TIME_ZONE);

		SimpleModule module = new SimpleModule("custom-deserializers", Version.unknownVersion());
		module.addSerializer(Geometry.class, new WKTGeometrySerializer());
		module.addDeserializer(Geometry.class, new WKTGeometryDeserializer());

		objectMapper.registerModule(module);
	}

	private void setupCORS(Environment environment) {
		log.info("CORS is enabled");

		Dynamic cors = environment.servlets().addFilter("CORS", CrossOriginFilter.class);
		cors.setInitParameter(CrossOriginFilter.ALLOWED_ORIGINS_PARAM, "*");
		cors.setInitParameter(CrossOriginFilter.ALLOWED_HEADERS_PARAM, "*");
		cors.setInitParameter(CrossOriginFilter.ALLOWED_METHODS_PARAM, "GET,PUT,POST,PATCH,DELETE");

		// OPTIONS pre-flight request will be served by the filter ONLY and not passed ahead
		cors.setInitParameter(CrossOriginFilter.CHAIN_PREFLIGHT_PARAM, "false");

		// Add URL mapping
		cors.addMappingForUrlPatterns(EnumSet.allOf(DispatcherType.class), false, "*");
	}

	protected Connection createRabbitmqConnection(RabbitMqConfig rabbitmqConfig) {
		if (rabbitmqConfig == null) {
			return null;
		}

		if (StringUtils.isBlank(rabbitmqConfig.getHost())) {
			return null;
		}

		ConnectionFactory factory = new ConnectionFactory();
		factory.setHost(rabbitmqConfig.getHost());

		if (!StringUtils.isBlank(rabbitmqConfig.getUser())) {
			factory.setUsername(rabbitmqConfig.getUser());
		}
		if (!StringUtils.isBlank(rabbitmqConfig.getPassword())) {
			factory.setPassword(rabbitmqConfig.getPassword());
		}
		if (!StringUtils.isBlank(rabbitmqConfig.getVirtualhost())) {
			factory.setVirtualHost(rabbitmqConfig.getVirtualhost());
		}
		if (rabbitmqConfig.getPort() != null) {
			factory.setPort(rabbitmqConfig.getPort());
		}
		factory.setAutomaticRecoveryEnabled(true);

		try {
			return factory.newConnection();
		} catch (IOException | TimeoutException e) {
			throw new IllegalStateException("Cannot connect to rabbit mq", e);
		}
	}

	private void createBundleInfrastructure(
			boolean activateBundleConfig, Connection rabbitMQConnection, Jdbi jdbi, ObjectMapper objectMapper,
			DynamicDocumentTypesBundleWorker dynamicDocumentTypesBundleWorker,
			AttachmentTypesBundleWorker attachmentTypesBundleWorker,
			EffluentTypesBundleWorker effluentTypesBundleWorker,
			BundleConfig bundleConfig, String serviceName
	) {

		if (rabbitMQConnection == null) {
			return;
		}
		if (activateBundleConfig) {
			try {
				// Listener
				ListenerBuilder.newBuilder(rabbitMQConnection)
						.withConfigDataConsumer(ConfigDataConsumerBuilder.newBuilder(jdbi, rabbitMQConnection)
								.route(serviceName)
								.processors(
										new BundleDynamicDocumentTypesProcessor(objectMapper, dynamicDocumentTypesBundleWorker, jdbi),
										new BundleAttachmentTypesProcessor(objectMapper, attachmentTypesBundleWorker, jdbi),
										new BundleEffluentTypesProcessor(objectMapper, effluentTypesBundleWorker, jdbi))
								.withOrderPolicy(ProcessorOrderPolicyEnum.PROCESSOR)
								.build())
						.withNewTenantEventConsumer(NewTenantEventConsumerBuilder.newBuilder(jdbi)
								.route(serviceName)
								.processors(new AttachmentTypesNewTenantProcessor(jdbi, attachmentTypesBundleWorker))
								.build())
						.buildListener()
						.start();

			} catch (Exception e) {
				throw new IllegalStateException("Error starting rabbitmq listener", e);
			}

			//			try {
			//				// Producer
			//				BundleInitServiceBuilder.producer(rabbitMQConnection)
			//				.configLocation(bundleConfig.getConfigLocation())
			//				.build()
			//				.start();
			//
			//			} catch (Exception e) {
			//				throw new IllegalStateException("Error starting rabbitmq producer", e);
			//			}
		}
	}

}
