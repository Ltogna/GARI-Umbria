package com.abacogroup.agri.applicationforms.pua.db.ntt;

import com.abacogroup.agri.applicationforms.pua.db.ntt.applications.IIdRs;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.OffsetDateTime;
import java.util.Optional;

/**
 * @author Emanuele Crocilla
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class FiveYearDeclarationNTT implements IIdRs<Long> {

	private Long pkId;
	private Long applicationId;
	private Long id;
	private Long partyId;
	private String sectorCode;
	private Integer blockCode;
	private Integer parcelCode;
	private String subParcelCode;
	private Integer cadastralAreaSqm;
	private String dayFrom;
	private String dayTo;
	private Integer usedAreaSqm;
	private OffsetDateTime dtInsert;
	private OffsetDateTime dtDelete;
	private String userIdInsert;
	private String userIdDelete;

	@Override
	public void setKey(Long id) {
		setPkId(id);
	}

	@Override
	public Optional<Long> getKey() {
		return Optional.ofNullable(getPkId());
	}
}
