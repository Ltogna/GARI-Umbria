package com.abacogroup.agri.applicationforms.pua.db.dao;

import java.util.List;

import org.jdbi.v3.sqlobject.config.RegisterArgumentFactory;
import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.config.RegisterColumnMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.customizer.BindBean;
import org.jdbi.v3.sqlobject.customizer.BindList;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;

import com.abacogroup.agri.applicationforms.pua.core.mappers.AbsoluteDateColumnMapper;
import com.abacogroup.agri.applicationforms.pua.core.model.OptionType;
import com.abacogroup.agri.applicationforms.pua.db.ntt.OptionCatalogNTT;
import com.abacogroup.agri.applicationforms.pua.db.ntt.OptionConfigsNTT;
import com.abacogroup.jdbi.argument.AbsoluteDateArgumentFactory;

/**
 * @author Alexandru Paraschiv
 */
@RegisterArgumentFactory(AbsoluteDateArgumentFactory.class)
@RegisterColumnMapper(AbsoluteDateColumnMapper.class)
public interface OptionCatalogDAO extends IGenericPuaDAO<OptionCatalogNTT, Long> {


	@Override
	@SqlQuery("§select_nextval(appfpua_option_catalog_id_seq)§")
	Long nextSequenceVal();

	@Override
	@SqlUpdate("INSERT INTO appfpua_option_catalog " +
			"(id, " +
			"tenant_id, " +
			"option_code) " +
			"VALUES(:id, :tenant_id, :option_code)")
	void insert(@BindBean OptionCatalogNTT ntt);

	@Override
	@SqlUpdate("UPDATE appfpua_option_catalog " +
			"SET option_code = :option_code, " +
			"    tenant_id = :tenant_id " +
			"WHERE id = :id")
	void update(@BindBean OptionCatalogNTT ntt);

	@Override
	@SqlQuery("SELECT oc.id," +
			" oc.tenant_id, " +
			" oc.option_code " +
			" FROM appfpua_option_catalog oc " +
			" WHERE id = :id")
	@RegisterBeanMapper(OptionCatalogNTT.class)
	List<OptionCatalogNTT> findById(@Bind("id") Long id);

	@SqlQuery("SELECT oc.id," +
			" oc.tenant_id, " +
			" oc.option_code, " +
			" §i18n(:tenant, 'appfpua_option_catalog', 'option_code', oc.option_code, :lang)§ as option_description " +
			" FROM appfpua_option_catalog oc " +
			" WHERE oc.tenant_id = :tenant ")
	@RegisterBeanMapper(OptionCatalogNTT.class)
	List<OptionCatalogNTT> findList(@Bind("tenant") String tenant, @Bind("lang") String lang);

	@SqlQuery("SELECT oc.id, " +
			" oc.tenant_id, " +
			" §i18n(:tenant, 'appfpua_option_catalog', 'option_code', oc.option_code, :lang)§ as option_description, " +
			" oc.option_code " +
			" FROM appfpua_option_catalog oc " +
			" WHERE oc.tenant_id = :tenant ")
	@RegisterBeanMapper(OptionCatalogNTT.class)
	List<OptionCatalogNTT> findAllByTenant(@Bind("tenant") String tenant, @Bind("lang") String lang);

	@SqlQuery("SELECT oc.id, " +
			" oc.tenant_id, " +
			" oc.option_code " +
			" FROM appfpua_option_catalog oc " +
			" WHERE oc.tenant_id = :tenant " +
			" AND oc.option_code = :option_code")
	@RegisterBeanMapper(OptionCatalogNTT.class)
	List<OptionCatalogNTT> findByOptionCode(@Bind("tenant") String tenant, @Bind("option_code") String optionCode);


	@SqlQuery("select cat.option_code " +
			"from appfpua_option_catalog cat " +
			"left join appfpua_option_configs conf on cat.id = conf.option_id  " +
			"where conf.id in (" +
			"select ag.parent_option_config_id " +
			"from appfpua_option_groups ag " +
			"left join appfpua_option_configs aoc on ag.option_config_id = aoc.id " +
			"left join appfpua_option_catalog aoc2 on aoc.option_id = aoc2.id " +
			"where aoc2.option_code  = :childOptionCode and aoc2.tenant_id = :tenant_id " +
			"and §current_timestamp§ between TO_DATE(aoc.dt_validity_start,'YYYYMMDD') and TO_DATE(aoc.dt_validity_end,'YYYYMMDD'))")
	List<String> findFatherOptionCodeByChildOptionCode(@Bind("tenant_id") String tenant, @Bind("childOptionCode") String optionCode);

	@SqlQuery("select *" +
			"from appfpua_option_configs aoc3 " +
			"where aoc3.id in (" +
			"select ag.option_config_id  " +
			"from appfpua_option_groups ag " +
			"left join appfpua_option_configs aoc on ag.parent_option_config_id  = aoc.id " +
			"left join appfpua_option_catalog aoc2 on aoc.option_id = aoc2.id " +
			"where aoc2.option_code  = :fatherOptionCode and aoc2.tenant_id = :tenant_id " +
			"and §current_timestamp§ between TO_DATE(aoc.dt_validity_start,'YYYYMMDD') and TO_DATE(aoc.dt_validity_end,'YYYYMMDD'))")
	@RegisterBeanMapper(OptionConfigsNTT.class)
	List<OptionConfigsNTT> findChildrenConfigsByFatherOptionCode(@Bind("tenant_id") String tenant, @Bind("fatherOptionCode") String optionCode);

	@SqlQuery("SELECT oc.id, " +
			" oc.tenant_id, " +
			" oc.option_code, " +
			" §i18n(:tenant, 'appfpua_option_catalog', 'option_code', oc.option_code, :lang)§ as option_description " +
			" FROM appfpua_option_catalog oc " +
			" WHERE oc.tenant_id = :tenant " +
			" AND oc.id = :option_id")
	@RegisterBeanMapper(OptionCatalogNTT.class)
	List<OptionCatalogNTT> findByOptionId(@Bind("tenant") String tenant, @Bind("option_id") Long optionId,
					@Bind("lang") String lang);

	@SqlQuery("SELECT oc.id, " +
			" oc.tenant_id, " +
			" oc.option_code, " +
			" §i18n(:tenant, 'appfpua_option_catalog', 'option_code', oc.option_code, :lang)§ as option_description " +
			" FROM appfpua_option_catalog oc " +
			" WHERE oc.tenant_id = :tenant " +
			" AND oc.id in (<option_id_list>)")
	@RegisterBeanMapper(OptionCatalogNTT.class)
	List<OptionCatalogNTT> findByOptionIds(@Bind("tenant") String tenant, @BindList("option_id_list") List<Long> optionIdList,
			@Bind("lang") String lang);

	@SqlQuery("SELECT oc.id, " +
			" oc.tenant_id, " +
			" oc.option_code, " +
			" §i18n(:tenant, 'appfpua_option_catalog', 'option_code', oc.option_code, :lang)§ as option_description " +
			" FROM appfpua_option_catalog oc " +
			" WHERE oc.tenant_id = :tenant " +
			" AND oc.option_code = :option_code")
	@RegisterBeanMapper(OptionCatalogNTT.class)
	List<OptionCatalogNTT> findByOptionCode(@Bind("tenant") String tenant, @Bind("option_code") String optionCode, @Bind("lang") String lang);

	@SqlQuery("SELECT oc.id, " +
			" oc.tenant_id, " +
			" oc.option_code, " +
			" §i18n(:tenant, 'appfpua_option_catalog', 'option_code', oc.option_code, :lang)§ as option_description " +
			" FROM appfpua_option_catalog oc " +
			" WHERE oc.tenant_id = :tenant " +
			" AND oc.option_code = :option_code"+
			" AND oc.option_code in (<option_codes>)")
	@RegisterBeanMapper(OptionCatalogNTT.class)
	List<OptionCatalogNTT> findByOptionCodesAndOptionCode(@Bind("tenant") String tenant, @BindList("option_codes") List<String> optionCodes,
                                                                @Bind("option_code") String optionCode,
                                                                @Bind("lang") String lang);


	@Override
	@SqlUpdate("DELETE FROM appfpua_option_catalog oc " +
			" WHERE oc.id = :id")
	void deleteById(@Bind("id") Long id);

	@SqlQuery("SELECT oc.id, " +
			" oc.tenant_id, " +
			" oc.option_code, " +
			" §i18n(:tenant, 'appfpua_option_catalog', 'option_code', oc.option_code, :lang)§ as option_description " +
			" FROM appfpua_option_catalog oc " +
			" WHERE oc.tenant_id = :tenant " +
			" AND oc.option_code in (<option_codes>)")
	@RegisterBeanMapper(OptionCatalogNTT.class)
	List<OptionCatalogNTT> findByOptionCodes(@Bind("tenant") String tenant,
                                                @BindList(value="option_codes", onEmpty=BindList.EmptyHandling.NULL_VALUE) List<String> optionCodes,
                                                @Bind("lang") String lang);

	@SqlQuery("select aoc.option_code " +
			"from appfpua_option_catalog aoc left join appfpua_option_configs con on aoc.id = con.option_id " +
			"where con.id = :option_config_id")
	String findOptionCodeByOptionConfigId(@Bind("tenant") String tenant, @Bind("option_config_id") Long optionConfigId);
	
	
	@SqlQuery("SELECT aoc.OPTION_CODE as code, aop.ATTRIBUTE_VALUE as type " +
			"FROM appfpua_option_catalog aoc JOIN appfpua_OPTION_CONFIGS aoc2 ON aoc.ID = aoc2.OPTION_ID " +
			"JOIN appfpua_OPTION_PARAMS aop ON aop.OPTION_CONFIG_ID = aoc2.id " +
			"WHERE aoc.TENANT_ID = :tenant " +
			"AND aop.ATTRIBUTE_NAME = 'OPTION_TYPE' " +
			"AND :validity between aoc2.DT_VALIDITY_START AND aoc2.DT_VALIDITY_END " +
			"ORDER BY OPTION_CODE asc")
	@RegisterBeanMapper(OptionType.class)
	List<OptionType> retrieveOptionCatalogAndType(@Bind("tenant") String tenant, @Bind("validity") String validity);
}
