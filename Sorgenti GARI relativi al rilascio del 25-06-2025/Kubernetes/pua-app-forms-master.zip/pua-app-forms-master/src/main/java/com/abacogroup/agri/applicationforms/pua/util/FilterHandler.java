package com.abacogroup.agri.applicationforms.pua.util;

import com.abacogroup.agri.applicationforms.pua.core.model.dto.DeclOnCropsDTO;
import com.abacogroup.jdbi.criteria.Criteria;
import com.abacogroup.jdbi.criteria.CriteriaBuilder;
import com.abacogroup.jdbi.orderby.OrderBy;
import com.abacogroup.jdbi.orderby.OrderByBuilder;
import com.abacogroup.jdbi.orderby.OrderByElement;
import com.abacogroup.jdbi.orderby.SortDirection;
import jakarta.servlet.http.HttpServletRequest;

import java.lang.reflect.Field;
import java.math.BigDecimal;
import java.util.*;

/**
 * @author Emanuele Crocilla
 */
public class FilterHandler {

	public static Map<String, String[]> convertRequestParametersToMap(HttpServletRequest request) {

		Map<String, String[]> params = new HashMap<>();

		// fetch all parameters names
		Enumeration<String> parameterNames = request.getParameterNames();

		String paramName = null;
		String[] paramValues = null;

		// cycle through parameters names
		while (parameterNames.hasMoreElements()) {
			paramName = parameterNames.nextElement();
			paramValues = request.getParameterValues(paramName);
			params.put(paramName, paramValues);
		}

		return params;
	}

	public static Filter createFilterByParamsExistingInClass(Map<String, String[]> reqParams, Class<?> pojoClass,
			Map<String, String> paramNameTranslations) {

		FilterParamsMap params = new FilterParamsMap();

		List<String> orderByFieldNames = new ArrayList<>();
		String orderByDirection = null;

		for (Field field : pojoClass.getDeclaredFields()) {
			field.setAccessible(true);
			var javaName = field.getName();
			var databaseName = paramNameTranslations.getOrDefault(javaName, DbUtils.camelToSnake(javaName));
			var param = new FilterParam(javaName, databaseName, null);
			params.put(javaName, param);
		}

		FilterParam filterParam = null;
		String paramName = null;
		String[] paramValues = null;
		String dbName = null;

		// cycle through parameters names
		for (Map.Entry<String, String[]> entry : reqParams.entrySet()) {
			paramName = entry.getKey();
			paramValues = entry.getValue();
			dbName = paramNameTranslations.getOrDefault(paramName, DbUtils.camelToSnake(paramName));
			filterParam = params.get(paramName);  // new FilterParam(paramName, dbName, paramValues[0]);

			if (filterParam != null) {
				filterParam.setDbName(dbName);
				filterParam.setValue(paramValues[0]);
				filterParam.setActive(true);
			} else {
				switch (paramName.toLowerCase()) {
					case "orderby": {
						for (String paramValue : GenericUtility.rtrim(paramValues[0]).split(",")) {
							orderByFieldNames.add(paramValue);
						}
						break;
					}
					case "orderdirection": {
						orderByDirection = paramValues[0];
						break;
					}
				}
			}
		}

		Collection<String> fieldsforSorting = null;
		Collection<String> listToCheck = params.getParamNames();
		String[] elementsToRetrieve = orderByFieldNames.toArray(new String[0]);

		if (!orderByFieldNames.isEmpty() && GenericUtility.containsAllOfThese(listToCheck, elementsToRetrieve)) {
			fieldsforSorting = params.getParamDbNames(orderByFieldNames);
		} else {
			fieldsforSorting = Collections.emptyList(); // Set.of("1", "2", "3");
		}

		SortDirection direction = null != orderByDirection && "DESC".equalsIgnoreCase(orderByDirection) ?
				SortDirection.DESC : SortDirection.ASC;

		List<OrderBy> orderByElements = new ArrayList<>();
		OrderBy element = null;

		for (String field : fieldsforSorting) {
			element = OrderByBuilder.field(field).direction(direction);
			orderByElements.add(element);
		}

		Filter filter = FilterHandler.createFilterByParamsExistingInClass(params.values(), pojoClass);

		if (!orderByElements.isEmpty()) {
			filter.setOrderBy(OrderByBuilder.from(orderByElements.toArray(new OrderByElement[orderByElements.size()])));
		}

		return filter;
	}

	public static Filter createFilterByParamsExistingInClass(Collection<FilterParam> params, Class<?> pojoClass) {

		Filter filter = new Filter();

		// Create a map of POJO for a rapid access (case insensitive)
		Map<String, Field> dtoFields = new HashMap<>();

		for (Field field : pojoClass.getDeclaredFields()) {
			field.setAccessible(true);
			dtoFields.put(field.getName().toLowerCase(), field);
		}

		filter.setParams(params);

		params.forEach(filterParam -> {

			try {

				// search field in the POJO (case insensitive)
				Field field = dtoFields.get(filterParam.getJavaName().toLowerCase());

				if (null != field && filterParam.isActive()) {

					Object convertedValue = convertToFieldType(String.valueOf(filterParam.getValue()), field.getType());
					filterParam.setValue(convertedValue);

					Criteria criteria = getCriteriaToFilterParam(filterParam);
					filterParam.setCriteria(criteria);
				}

			} catch (Exception e) {

				throw new RuntimeException(
						"Error on value conversion '" + filterParam + "' for the field '" + filterParam.getJavaName() + "': " + e.getMessage());
			}

		});

		return filter;
	}

	public static List<FilterParam> parseFilterStringAndConvertParamsExistingInClass(String filterString, Class<?> pojoClass,
			Map<String, String> paramNameTranslations) {

		List<FilterParam> params = new ArrayList<>();

		if (filterString != null) {
			filterString = filterString.trim();

			// Create a map of POJO for a rapid access (case insensitive)
			Map<String, Field> dtoFields = new HashMap<>();

			for (Field field : pojoClass.getDeclaredFields()) {
				field.setAccessible(true);
				dtoFields.put(field.getName().toLowerCase(), field);
			}

			// Split the string on commas
			String[] pairs = filterString.split(",");

			for (String pair : pairs) {

				// Split each pairs per semicolon
				String[] keyValue = pair.split(":", 2); // limit on 2 the split to handle values containing semicolon ":"

				FilterParam filterParam = null;
				String paramName = null;
				Object paramValue = null;
				String dbName = null;

				if (keyValue.length == 2) {
					String key = keyValue[0];
					String value = keyValue[1];

					// search field in the POJO (case insensitive)
					Field field = dtoFields.get(key.toLowerCase());

					if (field != null) {
						try {
							// convert value in the appropriate type basing on the type of the field
							paramName = field.getName();
							paramValue = convertToFieldType(value, field.getType());
							dbName = paramNameTranslations.getOrDefault(paramName, DbUtils.camelToSnake(paramName));
							filterParam = new FilterParam(paramName, dbName, paramValue);
							params.add(filterParam);
						} catch (Exception e) {

							throw new RuntimeException("Error on value conversion '" + value + "' for the field '" + key + "': " + e.getMessage());
						}
					} else {
						throw new RuntimeException("Unvalid field: " + key);
					}
				}
			}
		}

		return params;
	}

	private static Criteria getCriteriaToFilterParam(FilterParam filterParam) {

		String fieldType = filterParam.getJavaType();
		String fieldDbName = filterParam.getDbName();
		Object fieldValue = filterParam.getValue();

		if (fieldValue != null) {

			if (fieldType.equals(String.class.getSimpleName())) {
				return CriteriaBuilder.string(fieldDbName).eq(String.valueOf(fieldValue));
			} else if (fieldType.equals(Integer.class.getSimpleName()) || fieldType.equals(int.class.getSimpleName())) {
				return CriteriaBuilder.number(fieldDbName).eq((Integer) fieldValue);
			} else if (fieldType.equals(Long.class.getSimpleName()) || fieldType.equals(long.class.getSimpleName())) {
				return CriteriaBuilder.number(fieldDbName).eq((Long) fieldValue);
			} else if (fieldType.equals(Double.class.getSimpleName()) || fieldType.equals(double.class.getSimpleName())) {
				return CriteriaBuilder.number(fieldDbName).eq((Double) fieldValue);
			} else if (fieldType.equals(Float.class.getSimpleName()) || fieldType.equals(float.class.getSimpleName())) {
				return CriteriaBuilder.number(fieldDbName).eq((Float) fieldValue);
			} else if (fieldType.equals(Boolean.class.getSimpleName()) || fieldType.equals(boolean.class.getSimpleName())) {
				return CriteriaBuilder.number(fieldDbName).eq(((Boolean) fieldValue) ? 1 : 0);
			} else if (fieldType.equals(BigDecimal.class.getSimpleName())) {
				return CriteriaBuilder.number(fieldDbName).eq((BigDecimal) fieldValue);
			}

		} else {
			return null;
		}

		throw new IllegalArgumentException("Error in getCriteriaToFilterParam: unsupported type: " + fieldType);
	}

	private static Object convertToFieldType(String value, String fieldType) {
		if (fieldType.equals(String.class.getSimpleName())) {
			return value;
		} else if (fieldType.equals(Integer.class.getSimpleName()) || fieldType.equals(int.class.getSimpleName())) {
			return Integer.parseInt(value);
		} else if (fieldType.equals(Long.class.getSimpleName()) || fieldType.equals(long.class.getSimpleName())) {
			return Long.parseLong(value);
		} else if (fieldType.equals(Double.class.getSimpleName()) || fieldType.equals(double.class.getSimpleName())) {
			return Double.parseDouble(value);
		} else if (fieldType.equals(Float.class.getSimpleName()) || fieldType.equals(float.class.getSimpleName())) {
			return Float.parseFloat(value);
		} else if (fieldType.equals(Boolean.class.getSimpleName()) || fieldType.equals(boolean.class.getSimpleName())) {
			return Boolean.parseBoolean(value);
		} else if (fieldType.equals(BigDecimal.class.getSimpleName())) {
			return new BigDecimal(value);
		}

		throw new IllegalArgumentException("Error in convertToFieldType: unsupported type: " + fieldType);
	}

	private static Object convertToFieldType(String value, Class<?> fieldType) {
		if (fieldType == String.class) {
			return value;
		} else if (fieldType == Integer.class || fieldType == int.class) {
			return Integer.parseInt(value);
		} else if (fieldType == Long.class || fieldType == long.class) {
			return Long.parseLong(value);
		} else if (fieldType == Double.class || fieldType == double.class) {
			return Double.parseDouble(value);
		} else if (fieldType == Float.class || fieldType == float.class) {
			return Float.parseFloat(value);
		} else if (fieldType == Boolean.class || fieldType == boolean.class) {
			return Boolean.parseBoolean(value);
		} else if (fieldType == BigDecimal.class) {
			return new BigDecimal(value);
		}

		throw new IllegalArgumentException("Error in convertToFieldType: unsupported type: " + fieldType.getName());
	}

	//  Testing

	public static void main(String[] args) {

		System.out.println("\n*testWithMapOfParams");
		testWithMapOfParams();

		System.out.println("\n\n*testWithSerialization ");
		testWithSerialization();

		System.out.println("\n\n*testWithMapOfParams2 ");
		testWithMapOfParams2();
	}

	private static void testWithSerialization() {

		Map<String, String> fieldsMap = new HashMap<>();
		fieldsMap.put("planId", "plan_id");
		fieldsMap.put("plotCode", "plot_code");
		fieldsMap.put("declCode", "decl_code");
		fieldsMap.put("landUseCode", "land_use_code");
		fieldsMap.put("flZvn", "fl_zvn");
		fieldsMap.put("areaSqm", "area_sqm");
		fieldsMap.put("cropDuration", "crop_duration");
		fieldsMap.put("plantStatus", "plant_status");
		fieldsMap.put("precessionCode", "precession_code");
		fieldsMap.put("totResidualNitrogen", "tot_residual_nitrogen");
		fieldsMap.put("distributableNitrogen", "distributable_nitrogen");

		String filterString = "planId:12345,plotCode:3968,declCode:DCLT-2025,version:1.0,landUseCode:870-011-000-000-000,flZvn:true,areaSqm:5000,cropDuration:ANNUAL,plantStatus:ACTIVE,cycle:2,typology:ORGANIC,yield:450,mas:25,precessionCode:78,precessionDescription:WHEAT,totResidualNumber:12.5,distributableNum:8,totalNitrogen:120,sectorCode:AGR-25";
		List<FilterParam> params = FilterHandler.parseFilterStringAndConvertParamsExistingInClass(filterString, DeclOnCropsDTO.class, fieldsMap);
		Filter filter = FilterHandler.createFilterByParamsExistingInClass(params, DeclOnCropsDTO.class);

		// print the result
		for (FilterParam fp : filter.getParams()) {
			System.out.println(fp);
		}
	}

	private static void testWithMapOfParams() {

		FilterParam landUseCode = new FilterParam("landUseCode", "land_use_code", "870-011-000-000-000");
		FilterParam planId = new FilterParam("planId", "plan_id", "12345");
		FilterParam flZvn = new FilterParam("flZvn", "fl_zvn", true);
		FilterParam totResidualNumber = new FilterParam("totResidualNitrogen", "tot_residual_nitrogen", "1.02");
		List<FilterParam> params = List.of(landUseCode, planId, flZvn, totResidualNumber);
		Filter filter = FilterHandler.createFilterByParamsExistingInClass(params, DeclOnCropsDTO.class);

		// print the result
		for (FilterParam fp : filter.getParams()) {
			System.out.println(fp);
		}
	}

	private static void testWithMapOfParams2() {

		FilterParam landUseCode = FilterParam.builder().javaName("landUseCode").value("870-011-000-000-000").build();
		FilterParam planId = FilterParam.builder().javaName("planId").value("12345").build();
		FilterParam flZvn = FilterParam.builder().javaName("flZvn").value(true).build();
		FilterParam totResidualNitrogen = FilterParam.builder().javaName("totResidualNitrogen").value("1.02").build();
		List<FilterParam> params = List.of(landUseCode, planId, flZvn, totResidualNitrogen);
		Filter filter = FilterHandler.createFilterByParamsExistingInClass(params, DeclOnCropsDTO.class);

		// print the result
		for (FilterParam fp : filter.getParams()) {
			System.out.println(fp);
		}
	}
}
