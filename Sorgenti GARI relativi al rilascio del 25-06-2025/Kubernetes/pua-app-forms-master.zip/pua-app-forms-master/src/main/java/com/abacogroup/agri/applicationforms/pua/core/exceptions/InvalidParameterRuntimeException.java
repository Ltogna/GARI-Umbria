package com.abacogroup.agri.applicationforms.pua.core.exceptions;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.ws.rs.core.Response;

/**
 * 
 * @author Emanuele Crocilla
 *
 */
public class InvalidParameterRuntimeException extends AbstractException {

	private static final long serialVersionUID = 1L;
	
	public enum ValidationError {
		
	    MASSIVE_EDIT_YIELD_INVALID("MASSIVE_EDIT_YIELD_INVALID"),
	    YIELD_INVALID("YIELD_INVALID"),
	    
	    MASSIVE_EDIT_PRECESSION_INVALID("MASSIVE_EDIT_PRECESSION_INVALID"),
	    PRECESSION_INVALID("PRECESSION_INVALID"),
	    
	    MASSIVE_EDIT_CYCLE_INVALID("MASSIVE_EDIT_CYCLE_INVALID"),
	    CYCLE_INVALID("CYCLE_INVALID"),
	    
	    MASSIVE_EDIT_PRODUCTTYPE_INVALID("MASSIVE_EDIT_PRODUCTTYPE_INVALID"),
	    PRODUCTTYPE_INVALID("PRODUCTTYPE_INVALID");
	    
	    private final String code;
	    
	    ValidationError(String code) {
	        this.code = code;
	    }
	    
	    public String getCode() {
	        return code;
	    }
	    
	    @Override
	    public String toString() {
	        return code;
	    }
	}
	 
	public InvalidParameterRuntimeException(ValidationError validationError, String message) {
		super(Response.Status.BAD_REQUEST, new InvalidParameterRuntimeException.ErrorBody(validationError), message);
	}

	public InvalidParameterRuntimeException(ValidationError validationError) {
		super(Response.Status.BAD_REQUEST,  new InvalidParameterRuntimeException.ErrorBody(validationError), validationError.getCode());
	}

	@Schema(name = "ObjectNotFoundRuntimeExceptionErrorBody")
	public static class ErrorBody implements ExceptionErrorBody {
		
		private ValidationError err;

		public ErrorBody(ValidationError validationError) {
			this.err = validationError;
		}

		@Override
		public String getErrorCode() {
			return err.getCode();
		}
	}
}
