package com.abacogroup.agri.applicationforms.pua.db.ntt;

import java.time.LocalDateTime;
import java.util.Optional;

import com.abacogroup.agri.applicationforms.pua.db.ntt.applications.IHistoricizationFields;
import com.abacogroup.agri.applicationforms.pua.db.ntt.applications.IIdRs;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author Mattia Perini
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ApplicationOptionNTT implements IIdRs<Long>, IHistoricizationFields {

	private Long pkid;
	private Long application_id;
	private Long option_config_id;
	private String option_code;
	private Long document_id;
	private Long takeover_id;
	private Long start_application_id;
	private Long previous_application_id;
	private String user_id_insert;
	private String user_id_delete;
	private LocalDateTime dt_insert;
	private LocalDateTime dt_delete;

	@Override
	public Optional<Long> getKey() {
		return Optional.ofNullable(this.getPkid());
	}

	@Override
	public void setKey(Long pkid) {
		this.pkid = pkid;
	}

}
