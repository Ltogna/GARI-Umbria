package com.abacogroup.agri.applicationforms.pua.core.mappers;

import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import com.abacogroup.agri.applicationforms.pua.core.model.dto.AttachmentTypeDTO;
import com.abacogroup.agri.applicationforms.pua.core.model.dto.AttachmentTypePublicDTO;
import com.abacogroup.jdbi.mapper.AbsoluteDateMapper;

@Mapper(uses = AbsoluteDateMapper.class)
public interface AttachmentTypePublicMapper extends PublicMapper<AttachmentTypeDTO, AttachmentTypePublicDTO> {

	AttachmentTypePublicMapper INSTANCE = Mappers.getMapper(AttachmentTypePublicMapper.class);

	@InheritInverseConfiguration()
	AttachmentTypeDTO publicToDTO(AttachmentTypePublicDTO entity);

	@Mapping(source = "pkid", target = "id")
	@Mapping(source = "attachmentGroupCode", target = "groupCode")
	@Mapping(source = "code", target = "code")
	@Mapping(source = "typeCode", target = "typeCode")
	AttachmentTypePublicDTO dtoToPublic(AttachmentTypeDTO dto);

}
