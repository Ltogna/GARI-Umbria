package com.abacogroup.agri.applicationforms.pua.db.dao;

import com.abacogroup.agri.applicationforms.pua.core.exceptions.ObjectNotFoundRuntimeException;
import com.abacogroup.agri.applicationforms.pua.db.ntt.DeclOnCropLiveStocksNTT;
import com.abacogroup.agri.applicationforms.pua.db.ntt.DeclOnCropsNTT;
import com.abacogroup.agri.applicationforms.pua.db.ntt.DeclOnCropsPrevEffluentsNTT;
import com.abacogroup.agri.applicationforms.pua.db.ntt.DeclOnCropsPrevLivestockConsistenceNTT;
import com.abacogroup.agri.applicationforms.pua.services.common.DeclOnCropsSubdata;
import com.abacogroup.agri.applicationforms.pua.services.common.FunctionalObject;
import com.abacogroup.agri.applicationforms.pua.util.CommonConstants;
import com.abacogroup.jdbi.criteria.BindCriteria;
import com.abacogroup.jdbi.criteria.Criteria;
import com.abacogroup.jdbi.orderby.DefineOrder;
import com.abacogroup.jdbi.orderby.OrderBy;
import org.jdbi.v3.core.result.ResultIterator;
import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.customizer.BindBean;
import org.jdbi.v3.sqlobject.customizer.BindList;
import org.jdbi.v3.sqlobject.statement.SqlBatch;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;

import java.math.BigDecimal;
import java.time.Instant;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * @author Emanuele Crocilla
 */
public interface DeclOnCropsDAO extends IGenericPuaDAO<DeclOnCropsNTT, Long> {

	@Override
	@SqlQuery("§select_nextval(appfpua_decl_on_crops_pkid_seq)§")
	Long nextSequenceVal();

	@SqlQuery("§select_nextval(appfpua_decl_on_crops_prev_effluents_id_seq)§")
	Long nextSequencePevEffluentsVal();

	default List<DeclOnCropsNTT> getByApplicationId(@Bind("application_id") Long applicationId) {
		List<DeclOnCropsNTT> declOnCropsByApplications = declOnCropsByApplicationId(applicationId);
		declOnCropsByApplications.forEach(e -> {
			var declOnCropsPrevEffluents = declOnCropsByDeclOnCropsByParentId(e.getPkid());
			e.setPreviousEffluents(declOnCropsPrevEffluents);
		});

		return declOnCropsByApplications;
	}

	default DeclOnCropsNTT getByApplicationIdAndDeclatationId(@Bind("application_id") Long applicationId, @Bind("declatation_id") Long pkid) {
		DeclOnCropsNTT declOnCrops = declOnCropsByApplicationIdAndDeclatationId(applicationId, pkid);
		if (declOnCrops != null) {
			var declOnCropsPrevEffluents = declOnCropsByDeclOnCropsByParentId(declOnCrops.getPkid());
			declOnCrops.setPreviousEffluents(declOnCropsPrevEffluents);
		}
		return declOnCrops;
	}

	default List<DeclOnCropsNTT> getByApplicationIdAndDeclatationIds(Long applicationId, List<Long> pkids) {
		
		List<DeclOnCropsNTT> declOnCropsByApplicationIdAndDeclatationIds = 
				declOnCropsByApplicationIdAndDeclatationIds(applicationId, pkids);
		
		if (null != declOnCropsByApplicationIdAndDeclatationIds && !declOnCropsByApplicationIdAndDeclatationIds.isEmpty()) {

			Map<Long, DeclOnCropsNTT> declMap = declOnCropsByApplicationIdAndDeclatationIds.stream()
					.collect(Collectors.toMap(
							DeclOnCropsNTT::getPkid,  // key: pkid
							Function.identity(),      // value: the DeclOnCropsNTT
							(existing, replacement) -> existing  // in case of duplicate key
							));

			List<DeclOnCropsPrevEffluentsNTT> declOnCropsPrevEffluents = declOnCropsByDeclOnCropsByParentIds(pkids);
			
			declOnCropsPrevEffluents.forEach(declOnCropsPrevEffluent -> {
				
				var declOnCropsNTT = declMap.get(declOnCropsPrevEffluent.getAppfpuaDeclOnCropsPkid());
				
				if(declOnCropsNTT.getPreviousEffluents() == null) {
					declOnCropsNTT.setPreviousEffluents(new ArrayList<>());
				}
				
				declOnCropsNTT.getPreviousEffluents().add(declOnCropsPrevEffluent);
			});
		}
		
		return declOnCropsByApplicationIdAndDeclatationIds;
	}

	@Deprecated
	default void upsert(DeclOnCropsNTT nttToUpd) {

		DeclOnCropsNTT newNTT = getByApplicationIdAndDeclatationId(nttToUpd.getApplicationId(), nttToUpd.getPkid());

		if (newNTT != null) {

			String userIdInsert = nttToUpd.getUserIdInsert();
			long rightNow = Calendar.getInstance().getTimeInMillis();
			long rightNowMinusAMillis = rightNow - 1;

			Instant instantRightNow = Instant.ofEpochMilli(rightNow);
			Instant instantMinusAMillis = Instant.ofEpochMilli(rightNowMinusAMillis);

			OffsetDateTime dateTimeRightNow = instantRightNow.atOffset(ZoneOffset.UTC);
			OffsetDateTime dateTimeMinusAMillis = instantMinusAMillis.atOffset(ZoneOffset.UTC);

			newNTT.setDtInsert(dateTimeRightNow);

			useTransaction(dao -> {

				DeclOnCropsDAO declOnCropsDAO = (DeclOnCropsDAO) dao;
				declOnCropsDAO.expire(nttToUpd.getApplicationId(), nttToUpd.getPkid(), dateTimeMinusAMillis, userIdInsert);
				declOnCropsDAO.insert(newNTT);
			});
		} else {

			throw new ObjectNotFoundRuntimeException("Unable to find application id = " + nttToUpd.getApplicationId() + " and pkid = " + nttToUpd.getPkid());
		}
	}

	@SqlUpdate("""
			UPDATE public.appfpua_decl_on_crops SET "cycle" = :cycle, typology = :typology, yield = :yeld, precession_code = :precession_code , distributable_nitrogen = :distributableNitrogen
			WHERE pkId = :pkId 
			""")
	void update(
			@Bind("cycle") String cycle,
			@Bind("typology") String typology,
			@Bind("precession_code") int precessionCode,
			@Bind("yeld") int yeld,
			@Bind("distributableNitrogen") BigDecimal distributableNitrogen,
			@Bind("pkId") Long pkId);

	default void update(List<DeclOnCropsSubdata> declOnCropsSubDataelements) {

		useTransaction(dao -> {
			String userIdInsert = declOnCropsSubDataelements.get(0).getUserIdInsert();
			long rightNow = Calendar.getInstance().getTimeInMillis();
			long rightNowMinusAMillis = rightNow - 1;
			Instant instantRightNow = Instant.ofEpochMilli(rightNow);
			Instant instantMinusAMillis = Instant.ofEpochMilli(rightNowMinusAMillis);
			OffsetDateTime dateTimeRightNow = instantRightNow.atOffset(ZoneOffset.UTC);
			OffsetDateTime dateTimeMinusAMillis = instantMinusAMillis.atOffset(ZoneOffset.UTC);

			for (DeclOnCropsSubdata declOnCropsSubdata : declOnCropsSubDataelements) {

				((DeclOnCropsDAO) dao).update(
						String.valueOf(declOnCropsSubdata.getCycle()),
						declOnCropsSubdata.getTypology(),
						declOnCropsSubdata.getPrecessionCode(),
						declOnCropsSubdata.getYeld(),
						declOnCropsSubdata.getDistributableNum(),
						declOnCropsSubdata.getPkId());

				// update its previous effluents
				if (declOnCropsSubdata.getPreviousEffluents() != null && !declOnCropsSubdata.getPreviousEffluents().isEmpty()) {
					this.expireDeclOnCropsPrevEffluentsByParentDeclarationpkId(declOnCropsSubdata.getPkId(), dateTimeMinusAMillis, userIdInsert);
					Long newPkIdEffluent = null;

					for (DeclOnCropsPrevEffluentsNTT effluentsNTT : declOnCropsSubdata.getPreviousEffluents()) {
						newPkIdEffluent = nextSequencePevEffluentsVal();
						effluentsNTT.setPkid(newPkIdEffluent);
						effluentsNTT.setPreviousEffluentOnCropsId(newPkIdEffluent);
						effluentsNTT.setAppfpuaDeclOnCropsPkid(declOnCropsSubdata.getPkId());
						effluentsNTT.setDtInsert(dateTimeRightNow);
						effluentsNTT.setUserIdInsert(declOnCropsSubdata.getUserIdInsert());
						effluentsNTT.setDtDelete(CommonConstants.FAR_OFF_DATE);
						this.insert(effluentsNTT);
					}
				}
				else {
					
					// we need to expire old elements also in case the new Previous effluents list is empty
					this.expireDeclOnCropsPrevEffluentsByParentDeclarationpkId(declOnCropsSubdata.getPkId(), 
							dateTimeMinusAMillis, userIdInsert);
				}
			}
		});

	}

	@Deprecated
	default void upsertMany(List<DeclOnCropsNTT> nttsToUpd) {

		FunctionalObject<Long> applicationId = () -> nttsToUpd != null ? nttsToUpd.get(0).getApplicationId() : null;
		FunctionalObject<Long> nttId = () -> nttsToUpd != null ? nttsToUpd.get(0).getPkid() : null;

		if (nttsToUpd != null && !nttsToUpd.isEmpty()) {

			String userIdInsert = nttsToUpd.get(0).getUserIdInsert();
			long rightNow = Calendar.getInstance().getTimeInMillis();
			long rightNowMinusAMillis = rightNow - 1;

			Instant instantRightNow = Instant.ofEpochMilli(rightNow);
			Instant instantMinusAMillis = Instant.ofEpochMilli(rightNowMinusAMillis);

			OffsetDateTime dateTimeRightNow = instantRightNow.atOffset(ZoneOffset.UTC);
			OffsetDateTime dateTimeMinusAMillis = instantMinusAMillis.atOffset(ZoneOffset.UTC);

			useTransaction(dao -> {

				((DeclOnCropsDAO) dao).expire(applicationId.get(), nttId.get(), dateTimeMinusAMillis, userIdInsert);

				for (DeclOnCropsNTT ntt : nttsToUpd) {
					ntt.setDtInsert(dateTimeRightNow);
					((DeclOnCropsDAO) dao).insert(ntt);
				}
			});
		} else {

			throw new ObjectNotFoundRuntimeException("Unable to find application id = " + applicationId.get());
		}
	}

	@SqlQuery(""" 
			select * from appfpua_decl_on_crops 
				where application_id = :application_id 
			and dt_delete > §current_timestamp§ 
			order by pkid
			""")
	@RegisterBeanMapper(DeclOnCropsNTT.class)
	List<DeclOnCropsNTT> declOnCropsByApplicationId(@Bind("application_id") Long applicationId);

	@SqlQuery(""" 
			select * from appfpua_decl_on_crops_prev_effluents 
				where appfpua_decl_on_crops_pkid = :appfpua_decl_on_crops_pkid 
				and dt_delete > §current_timestamp§ 
			order by previous_effluent_on_crops_id
			""")
	@RegisterBeanMapper(DeclOnCropsPrevEffluentsNTT.class)
	List<DeclOnCropsPrevEffluentsNTT> declOnCropsByDeclOnCropsByParentId(@Bind("appfpua_decl_on_crops_pkid") Long parentId);

	@SqlQuery("""
			   SELECT * FROM appfpua_decl_on_crops_prev_effluents 
			   WHERE appfpua_decl_on_crops_pkid IN (<parentIds>) 
			     AND dt_delete > §current_timestamp§ 
			   ORDER BY previous_effluent_on_crops_id
			""")
	@RegisterBeanMapper(DeclOnCropsPrevEffluentsNTT.class)
	List<DeclOnCropsPrevEffluentsNTT> declOnCropsByDeclOnCropsByParentIds(@BindList("parentIds") List<Long> parentIds);

	@SqlQuery(""" 
			select * from appfpua_decl_on_crops 
				where application_id = :application_id 
			and pkid = :declatation_id
			and dt_delete > §current_timestamp§ 
			""")
	@RegisterBeanMapper(DeclOnCropsNTT.class)
	DeclOnCropsNTT declOnCropsByApplicationIdAndDeclatationId(@Bind("application_id") Long applicationId, @Bind("declatation_id") Long pkid);

	@SqlQuery(""" 
			select * from appfpua_decl_on_crops 
				where application_id = :application_id 
			and pkid IN (<declatation_ids>)
			and dt_delete > §current_timestamp§ 
			""")
	@RegisterBeanMapper(DeclOnCropsNTT.class)
	List<DeclOnCropsNTT> declOnCropsByApplicationIdAndDeclatationIds(@Bind("application_id") Long applicationId, 
			@BindList("declatation_ids") List<Long> pkids);

	
	@SqlQuery(""" 
			select * from appfpua_decl_on_crops 
				where pkid = :declatation_id
			and dt_delete > §current_timestamp§ 
			""")
	@RegisterBeanMapper(DeclOnCropsNTT.class)
	DeclOnCropsNTT getDeclOnCropById(@Bind("declatation_id") Long pkid);

	@SqlQuery("select count(*) from appfpua_decl_on_crops where application_id = :application_id and dt_delete > §current_timestamp§")
	@RegisterBeanMapper(DeclOnCropsNTT.class)
	int count(@Bind("application_id") Long applicationId);

	@SqlQuery("select count(*) from appfpua_decl_on_crops where pkid = :pkid and dt_delete > §current_timestamp§")
	@RegisterBeanMapper(DeclOnCropsNTT.class)
	int countByPkId(@Bind("pkid") Long pkid);

	@SqlQuery("""
			    SELECT EXISTS (
			        SELECT 1 
			        FROM appfpua_decl_on_crops 
			        WHERE application_id = :application_id 
			          AND (plan_id IS NOT NULL 
			               OR decl_code IS NOT NULL 
			               OR plot_code IS NOT NULL 
			               OR version IS NOT NULL)
			          AND dt_delete > §current_timestamp§ 
			    )
			""")
	boolean existsPartialValidEntries(
			@Bind("application_id") Long applicationId
	);

	@SqlQuery(""" 
			select * from appfpua_decl_on_crops 
				where application_id = :application_id 
					and plan_id IN (<plan_ids>) 
					and decl_code IN (<decl_codes>) 
					and land_use_code IN (<land_use_codes>)
					and dt_delete > §current_timestamp§ 
			""")
	@RegisterBeanMapper(DeclOnCropsNTT.class)
	List<DeclOnCropsNTT> getByApplicationIdPlanIdDeclCodeLandUseCode(
			@Bind("application_id") Long applicationId,
			@BindList("plan_ids") List<Long> planIds,
			@BindList("decl_codes") List<String> declCodes,
			@BindList("land_use_codes") List<String> landUseCodes);

	@SqlQuery(""" 
			select * from appfpua_decl_on_crops 
				where application_id = :application_id 
					and plan_id = :plan_id 
					and decl_code = :decl_code 
					and land_use_code = :land_use_code 
					and dt_delete > §current_timestamp§ 
			""")
	@RegisterBeanMapper(DeclOnCropsNTT.class)
	DeclOnCropsNTT getByApplicationIdPlanIdDeclCodeLandUseCode(
			@Bind("application_id") Long applicationId,
			@BindList("plan_id") Long planId,
			@BindList("decl_code") String declCode,
			@BindList("land_use_code") String landUseCode);

	@SqlQuery("select * from appfpua_decl_on_crops where crop_code = :cropCode order by pkid")
	@RegisterBeanMapper(DeclOnCropsNTT.class)
	List<DeclOnCropsNTT> getByCropCode(@Bind("crop_code") String cropCode);

	@SqlQuery("select * from appfpua_decl_on_crops where land_use_code = :landUseCode order by pkid")
	@RegisterBeanMapper(DeclOnCropsNTT.class)
	List<DeclOnCropsNTT> getByLandUseCode(@Bind("land_use_code") String landUseCode);

	@SqlQuery("select * from appfpua_decl_on_crops where area_sqm = :areaSqm order by pkid")
	@RegisterBeanMapper(DeclOnCropsNTT.class)
	List<DeclOnCropsNTT> getByAreaSqm(@Bind("area_sqm") String areaSqm);

	@SqlQuery("select * from appfpua_decl_on_crops where mas = :mas order by pkid")
	@RegisterBeanMapper(DeclOnCropsNTT.class)
	List<DeclOnCropsNTT> getByMas(@Bind("mas") String mas);

	@SqlQuery("select * from appfpua_decl_on_crops where pkid in (<declatationIds>) and dt_delete > §current_timestamp§")
	@RegisterBeanMapper(DeclOnCropsNTT.class)
	List<DeclOnCropsNTT> getByIds(@BindList("declatationIds") List<Long> pkids);

	@Override
	@SqlUpdate("""
			   INSERT INTO public.appfpua_decl_on_crops 
			(application_id, plan_id, plot_code, plot_description, decl_code, "version", land_use_code, fl_zvn, area_sqm, crop_duration, plant_status, 
			"cycle", typology, yield, mas, precession_code, tot_residual_nitrogen, distributable_nitrogen, 
			dt_insert, dt_delete, user_id_insert, user_id_delete, sector_code) 
			VALUES(:applicationId, :planId, :plotCode, :plotDescription, :declCode, :version, :landUseCode, :flZvn, :areaSqm, :cropDuration, :plantStatus, 
			:cycle, :typology, :yield, :mas, :precessionCode, :totResidualNitrogen, :distributableNitrogen, 
			:dtInsert, :dtDelete, :userIdInsert, :userIdDelete,:sectorCode)
			""")
	void insert(@BindBean DeclOnCropsNTT ntt);

	@SqlBatch("""
			INSERT INTO public.appfpua_decl_on_crops 
			(application_id, plan_id, plot_code, plot_description, decl_code, "version", land_use_code, fl_zvn, area_sqm, crop_duration, plant_status, 
			"cycle", typology, yield, mas, precession_code, tot_residual_nitrogen, distributable_nitrogen, 
			dt_insert, dt_delete, user_id_insert, user_id_delete, sector_code) 
			VALUES(:applicationId, :planId, :plotCode, :plotDescription, :declCode, :version, :landUseCode, :flZvn, :areaSqm, :cropDuration, :plantStatus, 
			:cycle, :typology, :yield, :mas, :precessionCode, :totResidualNitrogen, :distributableNitrogen, 
			:dtInsert, :dtDelete, :userIdInsert, :userIdDelete, :sectorCode)
			""")
	void insertBatch(@BindBean DeclOnCropsNTT[] ntts);

	@SqlUpdate("""
			update appfpua_decl_on_crops
			   set dt_delete=:dtDelete,
			       user_id_delete = :userIdDelete
			 where application_id=:applicationId 
			and pkid=:declatationId 
			   and §current_timestamp§ between dt_insert and dt_delete 
			""")
	void expire(@Bind("applicationId") Long applicationId, @Bind("declatationId") Long declatationId, @Bind("dtDelete") OffsetDateTime dtDelete,
			@Bind("userIdDelete") String userIdDelete);

	@Override
	@SqlQuery("SELECT * FROM appfpua_decl_on_crops a WHERE a.pkid = :pkid")
	@RegisterBeanMapper(DeclOnCropsNTT.class)
	List<DeclOnCropsNTT> findById(@Bind("pkid") Long id);

	@SqlQuery("""
			SELECT * FROM appfpua_decl_on_crops_prev_effluents 
				WHERE previous_effluent_on_crops_id = :previousEffluentOnCropsId 
					AND §current_timestamp§ between dt_insert AND dt_delete  
			""")
	@RegisterBeanMapper(DeclOnCropsPrevEffluentsNTT.class)
	List<DeclOnCropsPrevEffluentsNTT> findDeclOnCropsPrevEffluentsById(@Bind("previousEffluentOnCropsId") Long previousEffluentOnCropsId);

	@SqlQuery("""
			SELECT * FROM appfpua_decl_on_crops_prev_effluents 
				WHERE appfpua_decl_on_crops_pkid = :parentId 
					AND §current_timestamp§ between dt_insert AND dt_delete  
			""")
	@RegisterBeanMapper(DeclOnCropsPrevEffluentsNTT.class)
	List<DeclOnCropsPrevEffluentsNTT> findDeclOnCropsPrevEffluentsByParentId(@Bind("parentId") Long parentId);

	@SqlUpdate("""
			update appfpua_decl_on_crops
			   set tot_residual_nitrogen=:totResidualNitrogen 
			 where pkid=:declatationId 
			""")
	void updateTotResidualNitrogen(@Bind("declatationId") Long declatationId,
			@Bind("totResidualNitrogen") double totResidualNitrogen);

	// *** CRUD for appfpua_decl_on_crops_prev_effluents ***

	@SqlUpdate("""
			   INSERT INTO public.appfpua_decl_on_crops_prev_effluents 
			   (pkid, previous_effluent_on_crops_id, appfpua_decl_on_crops_pkid, effluent, measurement_unit, quantity, 
			   nitrogen_content, frequency, reduction, residual_nitrogen, dt_insert, dt_delete, user_id_insert, user_id_delete) 
			VALUES(:pkid, :previousEffluentOnCropsId, :appfpuaDeclOnCropsPkid, :effluent, :measurementUnit, :quantity, 
			   :nitrogenContent, :frequency, :reduction, :residualNitrogen, :dtInsert, :dtDelete, :userIdInsert, :userIdDelete)
			""")
	void insert(@BindBean DeclOnCropsPrevEffluentsNTT ntt);

	default void upsert(DeclOnCropsPrevEffluentsNTT nttToUpd) {
		upsert(nttToUpd, true);
	}

	default void upsert(DeclOnCropsPrevEffluentsNTT nttToUpd, boolean useTransaction) {

		FunctionalObject<Long> previousEffluentOnCropsId = () -> nttToUpd != null ? nttToUpd.getPreviousEffluentOnCropsId() : null;

		if (nttToUpd != null && previousEffluentOnCropsId.get() != null
				&& this.countDeclOnCropsPrevEffluentsById(previousEffluentOnCropsId.get()) > 0) {

			String userIdInsert = nttToUpd.getUserIdInsert();
			long rightNow = Calendar.getInstance().getTimeInMillis();
			long rightNowMinusAMillis = rightNow - 1;

			Instant instantRightNow = Instant.ofEpochMilli(rightNow);
			Instant instantMinusAMillis = Instant.ofEpochMilli(rightNowMinusAMillis);

			OffsetDateTime dateTimeRightNow = instantRightNow.atOffset(ZoneOffset.UTC);
			OffsetDateTime dateTimeMinusAMillis = instantMinusAMillis.atOffset(ZoneOffset.UTC);

			nttToUpd.setDtInsert(dateTimeRightNow);

			nttToUpd.setPkid(nextSequencePevEffluentsVal());

			if (useTransaction) {
				useTransaction(dao -> {

					((DeclOnCropsDAO) dao).expireDeclOnCropsPrevEffluentsByDeclarationId(
							previousEffluentOnCropsId.get(), dateTimeMinusAMillis, userIdInsert);

					((DeclOnCropsDAO) dao).insert(nttToUpd);
				});
			} else {
				this.expireDeclOnCropsPrevEffluentsByDeclarationId(
						previousEffluentOnCropsId.get(), dateTimeMinusAMillis, userIdInsert);

				this.insert(nttToUpd);
			}

		} else {

			throw new ObjectNotFoundRuntimeException("Unable to find Id = " + previousEffluentOnCropsId.get());
		}
	}

	@SqlUpdate("""
			UPDATE appfpua_decl_on_crops_prev_effluents
			   SET dt_delete=:dtDelete,
			       user_id_delete = :userIdDelete
			 WHERE previous_effluent_on_crops_id = :previousEffluentOnCropsId 
			   AND §current_timestamp§ between dt_insert AND dt_delete 
			""")
	void expireDeclOnCropsPrevEffluentsByDeclarationId(@Bind("previousEffluentOnCropsId") Long previousEffluentOnCropsId,
			@Bind("dtDelete") OffsetDateTime dtDelete,
			@Bind("userIdDelete") String userIdDelete);

	@SqlUpdate("""
			UPDATE appfpua_decl_on_crops_prev_effluents
			   SET dt_delete=:dtDelete,
			       user_id_delete = :userIdDelete
			 WHERE appfpua_decl_on_crops_pkid = :appfpuaDeclOnCropsPkid 
			   AND §current_timestamp§ between dt_insert AND dt_delete 
			""")
	void expireDeclOnCropsPrevEffluentsByParentDeclarationpkId(
			@Bind("appfpuaDeclOnCropsPkid") Long appfpuaDeclOnCropsPkid,
			@Bind("dtDelete") OffsetDateTime dtDelete,
			@Bind("userIdDelete") String userIdDelete);

	@SqlQuery("""
			select count(*) from appfpua_decl_on_crops_prev_effluents 
			where previous_effluent_on_crops_id = :id 
			and dt_delete > §current_timestamp§
			""")
	@RegisterBeanMapper(DeclOnCropsPrevEffluentsNTT.class)
	int countDeclOnCropsPrevEffluentsById(@Bind("id") Long id);

	@SqlQuery("""
			select sum(residual_nitrogen)
			from appfpua_decl_on_crops_prev_effluents
			where appfpua_decl_on_crops_pkid = :parentId 
			and dt_delete > §current_timestamp§
			""")
	@RegisterBeanMapper(DeclOnCropsPrevEffluentsNTT.class)
	Double getSumOfTotResidualNuberByAllDeclOnCropsPrevEffluents(@Bind("parentId") Long parentId);

	@SqlUpdate("""
			   INSERT INTO public.appfpua_decl_on_crops_livestock_consist
			(pkid, decl_on_crops_livestock_consist_id, appfpua_decl_on_crops_pkid, animal_species, animal_category, 
			housing_system, head_of_livestock_numb, average_live_weight, number_in_the_field, liquid_effl_leaving_stable, 
			solid_effluent_leaving_stable, dt_insert, dt_delete, user_id_insert, user_id_delete)
			VALUES(:pkid, :declOnCropsLivestockConsistId, :appfpuaDeclOnCropsPkid, :animalSpecies, :animalCategory, 
			:housingSystem, :headOfLivestockNumb, :averageLiveWeight, :numberInTheField, :liquidEfflLeavingStable, 
			:solidEffluentLeavingStable, :dtInsert, :dtDelete, :userIdInsert, :userIdDelete)
			""")
	void insert(@BindBean DeclOnCropsPrevLivestockConsistenceNTT ntt);

	default void upsert(DeclOnCropsPrevLivestockConsistenceNTT nttToUpd) {

		FunctionalObject<Long> nttId = () -> nttToUpd != null ? nttToUpd.getDeclOnCropsLivestockConsistId() : null;

		if (nttToUpd != null && nttId.get() != null && this.countDeclOnCropsPrevLivestockConsistenceById(nttId.get()) > 0) {

			String userIdInsert = nttToUpd.getUserIdInsert();
			long rightNow = Calendar.getInstance().getTimeInMillis();
			long rightNowMinusAMillis = rightNow - 1;

			Instant instantRightNow = Instant.ofEpochMilli(rightNow);
			Instant instantMinusAMillis = Instant.ofEpochMilli(rightNowMinusAMillis);

			OffsetDateTime dateTimeRightNow = instantRightNow.atOffset(ZoneOffset.UTC);
			OffsetDateTime dateTimeMinusAMillis = instantMinusAMillis.atOffset(ZoneOffset.UTC);

			nttToUpd.setDtInsert(dateTimeRightNow);

			nttToUpd.setPkid(nextSequenceVal());

			useTransaction(dao -> {

				((DeclOnCropsDAO) dao).expireDeclOnCropsPrevLivestockConsistenceByDeclarationId(nttId.get(), dateTimeMinusAMillis, userIdInsert);
				((DeclOnCropsDAO) dao).insert(nttToUpd);
			});
		} else {

			throw new ObjectNotFoundRuntimeException("Unable to find Id = " + nttId.get());
		}
	}

	@SqlUpdate("""
			         UPDATE appfpua_decl_on_crops_livestock_consist
			SET dt_delete = :dtDelete,
			    user_id_delete = :userIdDelete
			WHERE decl_on_crops_livestock_consist_id = :declOnCropsLivestockConsistId
			AND §current_timestamp§ BETWEEN dt_insert AND dt_delete
			""")
	void expireDeclOnCropsPrevLivestockConsistenceByDeclarationId(@Bind("declatationId") Long declatationId, @Bind("dtDelete") OffsetDateTime dtDelete,
			@Bind("userIdDelete") String userIdDelete);

	@SqlQuery("""
			select count(*) from appfpua_decl_on_crops_livestock_consist 
			where decl_on_crops_livestock_consist_id = :id 
			and dt_delete > §current_timestamp§
			""")
	@RegisterBeanMapper(DeclOnCropsPrevLivestockConsistenceNTT.class)
	int countDeclOnCropsPrevLivestockConsistenceById(@Bind("id") Long id);

	@SqlQuery(""" 
			select * from appfpua_decl_on_crops_livestock_consist 
				where application_id = :application_id 
			and dt_delete > §current_timestamp§ 
			order by pkid
			""")
	@RegisterBeanMapper(DeclOnCropLiveStocksNTT.class)
	List<DeclOnCropLiveStocksNTT> getDeclOnCropsPrevLivestockConsistByApplicationId(@Bind("application_id") Long applicationId);

	//Dec On Crop

	default void upsertDcl(DeclOnCropsNTT nttToUpd) {

		DeclOnCropsNTT newNTT = getByApplicationIdAndDeclatationId(nttToUpd.getApplicationId(), nttToUpd.getPkid());

		if (newNTT != null) {

			String userIdInsert = nttToUpd.getUserIdInsert();
			long rightNow = Calendar.getInstance().getTimeInMillis();
			long rightNowMinusAMillis = rightNow - 1;

			Instant instantRightNow = Instant.ofEpochMilli(rightNow);
			Instant instantMinusAMillis = Instant.ofEpochMilli(rightNowMinusAMillis);

			OffsetDateTime dateTimeRightNow = instantRightNow.atOffset(ZoneOffset.UTC);
			OffsetDateTime dateTimeMinusAMillis = instantMinusAMillis.atOffset(ZoneOffset.UTC);

			newNTT.setCycle(nttToUpd.getCycle());
			newNTT.setTypology(nttToUpd.getTypology());
			;
			newNTT.setPrecessionCode(nttToUpd.getPrecessionCode());
			newNTT.setYield(nttToUpd.getYield());

			newNTT.setDtInsert(dateTimeRightNow);
			newNTT.setPkid(nextSequenceVal());
			useTransaction(dao -> {
				DeclOnCropsDAO declOnCropsDAO = (DeclOnCropsDAO) dao;
				declOnCropsDAO.expireDeclOnCropsById(nttToUpd.getPkid(), dateTimeMinusAMillis, userIdInsert);
				declOnCropsDAO.insertDeclOnCrop(newNTT);
				nttToUpd.setPkid(newNTT.getPkid());
			});
		} else {

			throw new ObjectNotFoundRuntimeException("Unable to find application id = " + nttToUpd.getApplicationId() + " and pkid = " + nttToUpd.getPkid());
		}
	}

	default void upsertManyDcl(List<DeclOnCropsNTT> nttToUpds) {

		useTransaction(dao -> {

			DeclOnCropsNTT newNTT = null;
			Long oldPkId = 0L;

			for (DeclOnCropsNTT nttToUpd : nttToUpds) {

				oldPkId = nttToUpd.getPkid();

				newNTT = getByApplicationIdAndDeclatationId(nttToUpd.getApplicationId(), oldPkId);

				if (newNTT != null) {

					String userIdInsert = nttToUpd.getUserIdInsert();
					long rightNow = Calendar.getInstance().getTimeInMillis();
					long rightNowMinusAMillis = rightNow - 1;

					Instant instantRightNow = Instant.ofEpochMilli(rightNow);
					Instant instantMinusAMillis = Instant.ofEpochMilli(rightNowMinusAMillis);

					OffsetDateTime dateTimeRightNow = instantRightNow.atOffset(ZoneOffset.UTC);
					OffsetDateTime dateTimeMinusAMillis = instantMinusAMillis.atOffset(ZoneOffset.UTC);

					newNTT.setCycle(nttToUpd.getCycle());
					newNTT.setTypology(nttToUpd.getTypology());

					newNTT.setPrecessionCode(nttToUpd.getPrecessionCode());
					newNTT.setYield(nttToUpd.getYield());

					newNTT.setDtInsert(dateTimeRightNow);
					newNTT.setPkid(nextSequenceVal());

					DeclOnCropsDAO declOnCropsDAO = (DeclOnCropsDAO) dao;
					declOnCropsDAO.expireDeclOnCropsById(oldPkId, dateTimeMinusAMillis, userIdInsert);
					declOnCropsDAO.insertDeclOnCrop(newNTT);

					// *** set the new PkID ***
					nttToUpd.setPkid(newNTT.getPkid());

					// update its previous effluents
					this.expireDeclOnCropsPrevEffluentsByParentDeclarationpkId(oldPkId, dateTimeMinusAMillis, userIdInsert);

					newNTT.setPreviousEffluents(nttToUpd.getPreviousEffluents());

					Long newPkIdEffluent = null;

					for (DeclOnCropsPrevEffluentsNTT effluentsNTT : newNTT.getPreviousEffluents()) {
						newPkIdEffluent = nextSequencePevEffluentsVal();
						effluentsNTT.setPkid(newPkIdEffluent);
						effluentsNTT.setPreviousEffluentOnCropsId(newPkIdEffluent);
						effluentsNTT.setAppfpuaDeclOnCropsPkid(nttToUpd.getPkid());
						effluentsNTT.setDtInsert(dateTimeRightNow);
						effluentsNTT.setUserIdInsert(newNTT.getUserIdInsert());
						effluentsNTT.setDtDelete(CommonConstants.FAR_OFF_DATE);

						this.insert(effluentsNTT);
					}

				} else {

					throw new ObjectNotFoundRuntimeException(
							"Unable to find application id = " + nttToUpd.getApplicationId() + " and pkid = " + nttToUpd.getPkid());
				}
			}
		});
	}

	@SqlQuery("""
			SELECT COUNT(*) FROM appfpua_decl_on_crops 
			WHERE pkid = :id 
			AND (dt_delete IS NULL OR dt_delete > current_timestamp)
			""")
	@RegisterBeanMapper(DeclOnCropsNTT.class)
	int countDeclOnCropsById(@Bind("id") Long id);

	@SqlUpdate("""
			UPDATE appfpua_decl_on_crops
			SET dt_delete = :dtDelete,
			    user_id_delete = :userIdDelete
			WHERE pkid = :declarationId
			AND current_timestamp BETWEEN dt_insert AND dt_delete
			""")
	void expireDeclOnCropsById(@Bind("declarationId") Long declarationId,
			@Bind("dtDelete") OffsetDateTime dtDelete,
			@Bind("userIdDelete") String userIdDelete);

	@SqlUpdate("""
			INSERT INTO public.appfpua_decl_on_crops 
			(pkid, application_id, plan_id, plot_code, plot_description, decl_code, version, land_use_code, fl_zvn, area_sqm, 
			 crop_duration, plant_status, cycle, typology, yield, mas, precession_code, tot_residual_nitrogen, 
			 distributable_nitrogen, dt_insert, dt_delete, user_id_insert, user_id_delete, sector_code) 
			VALUES(:pkid, :applicationId, :planId, :plotCode, :plotDescription, :declCode, :version, :landUseCode, :flZvn, :areaSqm, 
			       :cropDuration, :plantStatus, :cycle, :typology, :yield, :mas, :precessionCode, :totResidualNitrogen, 
			       :distributableNitrogen, :dtInsert, :dtDelete, :userIdInsert, :userIdDelete, :sectorCode)
			""")
	void insertDeclOnCrop(@BindBean DeclOnCropsNTT ntt);

	@SqlQuery("""
			SELECT * FROM appfpua_decl_on_crops 
			WHERE pkid = :pkid 
			AND current_timestamp BETWEEN dt_insert AND dt_delete
			""")
	@RegisterBeanMapper(DeclOnCropsNTT.class)
	DeclOnCropsNTT getDeclOnCropsById(@Bind("pkid") Long pkid);

	@SqlQuery("""
			SELECT * FROM appfpua_decl_on_crops 
			WHERE pkid IN (<pkids>) 
			AND current_timestamp BETWEEN dt_insert AND dt_delete
			""")
	@RegisterBeanMapper(DeclOnCropsNTT.class)
	List<DeclOnCropsNTT> getDeclOnCropsByIds(@BindList("pkids") List<Long> pkids);

	@SqlQuery(""" 
			select pkid from appfpua_decl_on_crops 
				where application_id = :application_id 
			and dt_delete > §current_timestamp§ 
			""")
	@RegisterBeanMapper(DeclOnCropsNTT.class)
	List<Long> declOnCropsPkIdsByApplicationId(@Bind("application_id") Long applicationId);

	@SqlQuery("""
			SELECT * FROM appfpua_decl_on_crops 
			where application_id = :application_id 
			AND §current_timestamp§ BETWEEN dt_insert AND dt_delete
			""")
	@RegisterBeanMapper(DeclOnCropsNTT.class)
	List<DeclOnCropsNTT> getDeclOnCropsWithoutPrevEffluentsByApplicationId(@Bind("application_id") Long applicationId);

	@SqlQuery("""
			SELECT * FROM appfpua_decl_on_crops 
			WHERE pkid IN (<pkids>) 
			AND §current_timestamp§ BETWEEN dt_insert AND dt_delete
			""")
	@RegisterBeanMapper(DeclOnCropsNTT.class)
	ResultIterator<DeclOnCropsNTT> getDeclOnCropsWithoutPrevEffluentsByIds(@BindList("pkids") List<Long> pkids);

	@RegisterBeanMapper(DeclOnCropsNTT.class)
	@SqlQuery(""" 
			SELECT * FROM appfpua_decl_on_crops 
			WHERE application_id = :application_id 
			AND <criteria>
			AND dt_delete > §current_timestamp§ 
			ORDER BY <orderBy>
			""")
	ResultIterator<DeclOnCropsNTT> searchDeclOnCropsByFilter(@Bind("application_id") Long applicationId,
			@BindCriteria("criteria") Criteria criteria, @DefineOrder("orderBy") OrderBy orderBy);

	@RegisterBeanMapper(DeclOnCropLiveStocksNTT.class)
	@SqlQuery(""" 
			SELECT * FROM appfpua_decl_on_crops_livestock_consist 
			WHERE application_id = :application_id 
			AND <criteria>
			AND dt_delete > §current_timestamp§ 
			ORDER BY <orderBy>
			""")
	ResultIterator<DeclOnCropLiveStocksNTT> searchDeclOnCropsEffluentsByFilter(@Bind("application_id") Long applicationId,
			@BindCriteria("criteria") Criteria criteria, @DefineOrder("orderBy") OrderBy orderBy);

}
