package com.abacogroup.agri.applicationforms.pua.resources;

import java.util.Locale;
import java.util.Optional;

import com.abacogroup.agri.applicationforms.pua.ApplicationFormsModuleConfiguration;
import com.abacogroup.agri.applicationforms.pua.common.dynamidocument.DynamicDocumentService;

//import static com.abacogroup.agri.applicationforms.utils.ExtendTokenDurability.extendToken;

//import com.abacogroup.agri.applicationforms.core.services.common.RolesVerifierService;
import com.abacogroup.agri.applicationforms.pua.core.model.CompileStatusEnum;
import com.abacogroup.agri.applicationforms.pua.core.model.dto.DeclarationsDTO;
import com.abacogroup.agri.applicationforms.pua.core.model.dto.DeclarationsWithDefinitionDTO;
import com.abacogroup.agri.applicationforms.pua.services.AttachmentsService;
import com.abacogroup.agri.applicationforms.pua.services.common.ApplicationFacadeService;
import com.abacogroup.dropwizard.auth.sso2.Sso2Client;
import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.dynamicdocuments.bean.Document;
import com.abacogroup.dynamicdocuments.bean.DocumentDefinition;
import com.codahale.metrics.annotation.Timed;

import io.dropwizard.auth.Auth;
import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.annotation.security.PermitAll;
import jakarta.annotation.security.RolesAllowed;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.HEAD;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.Context;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.core.SecurityContext;
import lombok.extern.slf4j.Slf4j;

/**
 * 
 * @author Emanuele Crocilla
 *
 */
@Timed
@OpenAPIDefinition(tags = { @Tag(name = DynamicDocumentResources.TAG_NAME) })
@PermitAll
@Slf4j
@MultipartConfig()
@RolesAllowed("APPLICATIONS|USER")
public class DynamicDocumentResources extends AGenericPuaResources {

	public static final String TAG_NAME = "Dynamic Document resources";

	public DynamicDocumentResources(
			ApplicationFormsModuleConfiguration configuration, DynamicDocumentService dynamicDocumentService, 
				ApplicationFacadeService applicationFacadeService, AttachmentsService attachmentsService, 
					Sso2Client sso2Client) {

		super(configuration, sso2Client);
		this.dynamicDocumentService = dynamicDocumentService;
		this.applicationFacadeService = applicationFacadeService;
		this.attachmentsService = attachmentsService;
	}

	@GET
	@Path("/{application_id}/declarations/{dynamic_document_code}")
	@Operation(description = "Returns the list of declarations", tags = { TAG_NAME })
	@ApiResponse(description = "The list of declarations")
	@ApiResponse(responseCode = "404", description = "The definition code was not found - ErrCode: DOCUMENT_DEFINITION_NOT_FOUND_ERROR")
	public DeclarationsWithDefinitionDTO getDeclarations(
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "Current Tenant") @PathParam("tenant") String tenant,
			@Parameter(description = "The application id") @PathParam("application_id") Long applicationId,
			@Parameter(description = "The dynamic document code") @PathParam("dynamic_document_code") String dynamicDocumentCode,
			@Parameter(description = "The form config id") @QueryParam("formConfigId") Long formConfigId
			) {

		applicationFacadeService.callForApplicationDetails(tenant, applicationId, user, Locale.ITALIAN.getLanguage());
		return dynamicDocumentService.getDeclarations(user, tenant, applicationId, formConfigId, dynamicDocumentCode);
	}

	@POST
	@Path("/{application_id}/declarations/{dynamic_document_code}")
	@Operation(description = "Inserts or updates the declaration", tags = { TAG_NAME })
	@ApiResponse(description = "The inserted or updated declaration")
	public DeclarationsDTO insertOrUpdateDeclarations(
			@Parameter(hidden = true) @Auth User user, 
			@Parameter(description = "Current Tenant") @PathParam("tenant") String tenant,
			@Parameter(description = "The application id") @PathParam("application_id") Long applicationId,
			@Parameter(description = "The document code") @PathParam("dynamic_document_code") String dynamicDocumentCode,
			@Parameter(description = "The form config id") @QueryParam("formConfigId") Long formConfigId,
			@Parameter(description = "The compile status identifier") @QueryParam("compileStatusIdentifier") String compileStatusIdentifier,
			@Parameter(description = "The compile status") @QueryParam("compileStatus") CompileStatusEnum compileStatusEnum,
			@Parameter(description = "Handle the form compiling validation as check list") @QueryParam("isDeclaration") Boolean isDeclaration,
			DeclarationsDTO payload) {
		
		return dynamicDocumentService.upsertDeclarations(tenant, user, applicationId, payload.getDocument(),
				dynamicDocumentCode, isDeclaration, compileStatusIdentifier, compileStatusEnum, formConfigId);
	}
	
	@GET
	@Path("/{application_id}/declarations/{dynamic_document_code}/files/{bucket}/{file_id}")
	@Consumes("*/*")
	@Operation(description = "Returns the attached file referred to the id", tags = { TAG_NAME })
	@ApiResponse(description = "The attached file")
	public Response getDeclarationSignature(
			@Parameter(description = "Current Tenant") @PathParam("tenant") String tenant,
			@Parameter(description = "The application id") @PathParam("application_id") Long applicationId,
			@Parameter(description = "The document code") @PathParam("dynamic_document_code") String dynamicDocumentCode,
			@Parameter(description = "The bucket name") @PathParam("bucket") String bucketName,
			@Parameter(description = "The attachment file id") @PathParam("file_id") String fileId,
			@Parameter(description = "The form config id") @QueryParam("formConfigId") Long formConfigId,
			@Parameter(hidden = true) @Auth User user,
			@Context SecurityContext sc) {
		
		applicationFacadeService.callForApplicationDetails(tenant, applicationId, user, Locale.ITALIAN.getLanguage());

		DeclarationsWithDefinitionDTO declarationsWithDefinition = 
				dynamicDocumentService.getDeclarations(user, tenant, applicationId, formConfigId, dynamicDocumentCode);
		
		Document document = declarationsWithDefinition.getDocument();
		DocumentDefinition documentDefinition = declarationsWithDefinition.getDocumentDefinition();
		
		if (Optional.ofNullable(document).isEmpty() && Optional.ofNullable(documentDefinition).isEmpty()) {
			throw new IllegalStateException("Empty document");
		}
		
		return attachmentsService.doCallFileStoreForDownload(tenant, user, bucketName, fileId);
	}
	
	@HEAD
	@Path("/{application_id}/declarations/{dynamic_document_code}/files/{bucket}/{file_id}")
	@Produces({ MediaType.APPLICATION_OCTET_STREAM })
	@Operation(description = "Returns the attached file referred to the id", tags = { TAG_NAME })
	@ApiResponse(description = "The attached file")
	public Response headDeclarationSignature(
			@Parameter(description = "Current Tenant") @PathParam("tenant") String tenant,
			@Parameter(description = "The application id") @PathParam("application_id") Long applicationId,
			@Parameter(description = "The document code") @PathParam("dynamic_document_code") String dynamicDocumentCode,
			@Parameter(description = "The bucket name") @PathParam("bucket") String bucketName,
			@Parameter(description = "The attachment file id") @PathParam("file_id") String fileId,
			@Parameter(description = "The form config id") @QueryParam("formConfigId") Long formConfigId,
			@Parameter(hidden = true) @Auth User user,
			@Context SecurityContext sc) {

		applicationFacadeService.callForApplicationDetails(tenant, applicationId, user, Locale.ITALIAN.getLanguage());
		
		DeclarationsWithDefinitionDTO declarationsWithDefinition = 
				dynamicDocumentService.getDeclarations(user, tenant, applicationId, formConfigId, dynamicDocumentCode);
		
		Document document = declarationsWithDefinition.getDocument();
		DocumentDefinition documentDefinition = declarationsWithDefinition.getDocumentDefinition();
		
		if (Optional.ofNullable(document).isEmpty() && Optional.ofNullable(documentDefinition).isEmpty()) {
			throw new IllegalStateException("Empty document");
		}
		
		return attachmentsService.doCallFileStoreForHead(tenant, user, bucketName, fileId);
	}
}
