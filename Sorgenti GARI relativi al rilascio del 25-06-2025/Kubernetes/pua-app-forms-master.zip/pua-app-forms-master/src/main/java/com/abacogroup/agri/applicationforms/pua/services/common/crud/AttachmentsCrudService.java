package com.abacogroup.agri.applicationforms.pua.services.common.crud;

import static com.abacogroup.agri.applicationforms.pua.util.PagingParamsFactory.DEFAULT_PAGE_SIZE;

import java.util.List;
import java.util.Locale;
import java.util.Optional;

import org.apache.commons.lang3.NotImplementedException;

import com.abacogroup.agri.applicationforms.pua.core.exceptions.AttachmentNotFoundRuntimeException;
import com.abacogroup.agri.applicationforms.pua.core.exceptions.ObjectNotFoundException;
import com.abacogroup.agri.applicationforms.pua.core.mappers.AttachmentMapper;
import com.abacogroup.agri.applicationforms.pua.core.model.dto.AttachmentDTO;
import com.abacogroup.agri.applicationforms.pua.db.dao.AttachmentDAO;
import com.abacogroup.agri.applicationforms.pua.db.ntt.AttachmentNTT;
import com.abacogroup.jdbi.paging.InfiniteListResults;

import lombok.extern.slf4j.Slf4j;

/**
 * @author Mauro Pozzana
 */
@Slf4j
public class AttachmentsCrudService extends AbstractHistoricizationFieldsCrudService<AttachmentNTT, Long, AttachmentDTO, AttachmentMapper, Void> {

    public AttachmentsCrudService(AttachmentDAO dao, AttachmentMapper mapper) {
        super(dao, mapper);
    }

    @Override
    protected boolean hasPrimaryKey() {
        return true;
    }

    @Override
    protected Void retrieveCustomKeyByResultSet(AttachmentNTT rs) {
        throw new NotImplementedException("not implemented");
    }

    @Override
    protected AttachmentNTT adjustR(AttachmentNTT rs) throws Exception {
        return rs;
    }

    @Override
    protected Optional<AttachmentNTT> findRsByCustomKey(Void customKey) {
        return Optional.empty();
    }

    public AttachmentDTO findById(Long id) throws ObjectNotFoundException {
        return this.findOutDtoByPrimaryKey(id);
    }

    public AttachmentDTO insert(AttachmentDTO in, String username) {
        log.info("Invoking insert with params in: {} username: {}", in, username);
        return this.insert(in, username, null, dao.getCurrentTimestamp());
    }

    public AttachmentDTO update(Long key, AttachmentDTO in, String username) {
        log.info("Invoking update with params key: {} in: {} username: {}", key, in, username);
        return this.update(key, in, username, null);
    }

    public void delete(Long key, String username) {
        log.info("Invoking delete with params key: {} username: {}", key, username);
        this.delete(key, username, null);
    }

    public InfiniteListResults<AttachmentDTO> findByApplicationId(String tenant, Long applicationId, String nextKey) {
        log.info("Invoking find by application id with params tenant: {} applicationId: {} nextKey: {}", tenant, applicationId, nextKey);
        return (returnInfiniteResults(
                this.dao.infinite(() -> ((AttachmentDAO) this.dao).findByApplicationId(tenant, applicationId, Locale.ITALIAN.getLanguage()),
                        nextKey,
                        DEFAULT_PAGE_SIZE)));
    }

    public InfiniteListResults<AttachmentDTO> findByApplicationIdAndAttachmentGroup(String tenant, Long applicationId, String attachmentGroup, String nextKey) {
        log.info("Invoking find by application id with params tenant: {} applicationId: {} attachmentGroup: {} nextKey: {}", tenant, applicationId,
                attachmentGroup, nextKey);
        return (returnInfiniteResults(
                this.dao.infinite(() -> ((AttachmentDAO) this.dao)
                		.findByApplicationId(tenant, applicationId, attachmentGroup, Locale.ITALIAN.getLanguage()),
                        nextKey,
                        DEFAULT_PAGE_SIZE)));
    }

    public List<AttachmentDTO> findListByApplicationIdAndAttachmentGroup(String tenant, Long applicationId, String attachmentGroup) {
        log.info("Invoking find by application id with params tenant: {} applicationId: {} attachmentGroup: {}", tenant, applicationId,
                attachmentGroup);
        return returnMappedList(((AttachmentDAO) this.dao).findListByApplicationId(tenant, applicationId, attachmentGroup, Locale.ITALIAN.getLanguage()));
    }

    public AttachmentDTO findByAttachmentId(String tenant, Long applicationId, String attachmentId) {
        log.info("Invoking find by attachment id with params tenant: {} applicationId: {} attachmentId: {}", tenant, applicationId, attachmentId);
        AttachmentNTT attachment = ((AttachmentDAO) this.dao).findByAttachmentId(tenant, applicationId, attachmentId, Locale.ITALIAN.getLanguage());

        if (Optional.ofNullable(attachment).isEmpty()) {
            throw new AttachmentNotFoundRuntimeException("Attachment descriptor not found");
        }

        log.info("Attachment descriptor found");
        return mapper.entityToDto(attachment);
    }
}


