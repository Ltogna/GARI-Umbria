package com.abacogroup.agri.applicationforms.pua.core.model.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
@Schema(description = "The option catalog")
public class OptionCatalogDTO {

	@Schema(description = "the option catalog's id")
	private Long id;
	@JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
	@Schema(description = "the option catalog's tenant")
	private String tenantId;
	@Schema(description = "the option catalog's option code")
	private String optionCode;
	@Schema(description = "the option catalog's option description")
	private String optionDescription;

}
