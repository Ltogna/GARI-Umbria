package com.abacogroup.agri.applicationforms.pua.bundles.processor.dyinamicdocumenttypes;

import java.nio.file.Path;

import org.jdbi.v3.core.Jdbi;

import com.abacogroup.agri.applicationforms.pua.bundles.model.dynamicdocumenttype.BundleDynamicDocumentTypesMessage;
import com.abacogroup.agri.applicationforms.pua.bundles.processor.AbstractBundleApplicationFormsProcessor;
import com.abacogroup.bundles.listener.configdata.ConfigDataMessage;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.extern.slf4j.Slf4j;

/**
 * @author Gennaro Tamburrelli
 */
@Slf4j
public class BundleDynamicDocumentTypesProcessor extends AbstractBundleApplicationFormsProcessor<BundleDynamicDocumentTypesMessage> {

	protected final DynamicDocumentTypesBundleWorker dynamicDocumentTypesBundleWorker;

	public BundleDynamicDocumentTypesProcessor(ObjectMapper objectMapper, DynamicDocumentTypesBundleWorker dynamicDocumentTypesBundleWorker, Jdbi jdbi) {
		super(objectMapper, jdbi);
		this.dynamicDocumentTypesBundleWorker = dynamicDocumentTypesBundleWorker;
	}

	@Override
	public String getDomainName() {
		return "dynamic-document-types";
	}

	@Override
	protected TypeReference<BundleDynamicDocumentTypesMessage> getTypeReference() {
		return new TypeReference<BundleDynamicDocumentTypesMessage>() {
		};
	}

	@Override
	public void onMessageInTransaction(ConfigDataMessage message) {
		log.info("BundleDynamicDocumentTypesProcessor: proccessing file with tenant {}", message.getTenantId());
		message.getConfigFiles().stream()
				.map(Path::toFile)
				.filter(file -> file.getAbsolutePath().endsWith(".json"))
				.forEach(file -> processFile(message.getTenantId(), file));
	}

	@Override
	protected void delete(String tenantId, BundleDynamicDocumentTypesMessage message) {
		// TODO implement this
	}

	@Override
	protected void doInsertOrUpdate(String tenantId, BundleDynamicDocumentTypesMessage message) {
		dynamicDocumentTypesBundleWorker.upsert(tenantId, message);
	}

}
