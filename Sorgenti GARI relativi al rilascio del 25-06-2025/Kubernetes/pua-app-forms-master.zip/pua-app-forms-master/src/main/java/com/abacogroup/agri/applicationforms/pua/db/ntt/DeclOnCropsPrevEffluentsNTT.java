package com.abacogroup.agri.applicationforms.pua.db.ntt;

import com.abacogroup.agri.applicationforms.pua.db.ntt.applications.IIdRs;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.OffsetDateTime;
import java.util.Optional;

/**
 * @author Emanuele Crocilla
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DeclOnCropsPrevEffluentsNTT implements IIdRs<Long> {

	private Long pkid;
	private Long previousEffluentOnCropsId;
	private Long appfpuaDeclOnCropsPkid;
	private String effluent;
	private String measurementUnit;
	private BigDecimal quantity;
	private BigDecimal nitrogenContent;
	private String frequency;
	private BigDecimal reduction;
	private BigDecimal residualNitrogen;
	private OffsetDateTime dtInsert;
	private OffsetDateTime dtDelete;
	private String userIdInsert;
	private String userIdDelete;

	@Override
	public void setKey(Long id) {
		setPkid(id);
	}

	@Override
	public Optional<Long> getKey() {
		return Optional.ofNullable(getPkid());
	}

}
