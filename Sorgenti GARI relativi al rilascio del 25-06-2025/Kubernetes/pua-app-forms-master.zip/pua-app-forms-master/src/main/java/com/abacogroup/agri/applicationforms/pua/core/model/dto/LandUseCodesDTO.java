package com.abacogroup.agri.applicationforms.pua.core.model.dto;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 
 * @author Emanuele Crocilla
 *
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Schema(description = "The LandUse Codes DTO")
public class LandUseCodesDTO {

	@Schema(description = "The landuse codes")
	@JsonProperty("land_uses_codes_list")
	private List<LandUseCode> landUsesCodesList;

	@Data
	@Builder
	@AllArgsConstructor
	@NoArgsConstructor
	public static class LandUseCode {

		@JsonProperty("land_uses_code")
		@Schema(description = "The landuse code")
		private String landUsesCode;
		
		@Schema(description = "The description")
		private String description;
	}
	
	public Map<String, LandUseCode> getLandUsesAsMap() {
		if (landUsesCodesList != null) {
			return (Map<String, LandUseCode>) landUsesCodesList.stream()
					.collect(Collectors.toMap(
							LandUseCode::getLandUsesCode, 
							landUse -> landUse
							));
		}
		return new HashMap<>();
	}
}
