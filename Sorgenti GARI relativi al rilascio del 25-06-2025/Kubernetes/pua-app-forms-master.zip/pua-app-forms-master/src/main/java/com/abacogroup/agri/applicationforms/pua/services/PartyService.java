package com.abacogroup.agri.applicationforms.pua.services;

import java.util.concurrent.TimeUnit;

import com.abacogroup.agri.applicationforms.pua.ApplicationFormsModuleConfiguration;
import com.abacogroup.agri.applicationforms.pua.core.model.PartyResponseKey;
import com.abacogroup.agri.applicationforms.pua.core.model.dto.PartyResponse;
import com.abacogroup.dropwizard.auth.sso2.Sso2Client;
import com.abacogroup.dropwizard.auth.sso2.User;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.github.benmanes.caffeine.cache.Caffeine;
import com.github.benmanes.caffeine.cache.LoadingCache;

import jakarta.ws.rs.client.Client;
import lombok.extern.slf4j.Slf4j;

/**
 * 
 * @author Emanuele Crocilla
 *
 */
@Slf4j
public class PartyService extends ADataImporterService {
	
	private final LoadingCache<PartyResponseKey, PartyResponse> partyResponseCache;
	
	public PartyService(Sso2Client sso2client, Client client, ApplicationFormsModuleConfiguration config, ObjectMapper objectMapper) {
		super(sso2client, client, config, objectMapper);
		
		this.partyResponseCache = Caffeine.newBuilder()
	              .maximumSize(20L)
	              .expireAfterAccess(12, TimeUnit.HOURS)
	              .build(key -> this._getPartyByIdOrCuaa(key.getUser(), key.getTenant(), key.getPartyId(), key.getCuaa()));
	      
	}
	
	public PartyResponse getPartyById(User user, String tenant, Long partyId) {
		return this.partyResponseCache.get(PartyResponseKey.builder()
                .user(user).tenant(tenant).partyId(partyId).build());
	}

	public PartyResponse getPartyByCuaa(User user, String tenant, String cuaa) {
		return this.partyResponseCache.get(PartyResponseKey.builder()
				.user(user).tenant(tenant).cuaa(cuaa).build());
	}
	
	private PartyResponse _getPartyByIdOrCuaa(User user, String tenant, Long id, String cuaa) {
		if (id != null && id > 0) {
			return _getPartyById(user, tenant, id);
		}
		return _getPartyByCuaa(user, tenant, cuaa);
	}

	private PartyResponse _getPartyByCuaa(User user, String tenant, String cuaa) {
		authToken = user.getAuthToken();
		String url = String.format("%s/%s/public/v1/parties/code/%s", partyRegistryUrl, tenant, cuaa);
		PartyResponse pr = sendGetRequest(tenant, url, PartyResponse.class, "getPartyByCuaa");
		return pr;
	}
	 
	private PartyResponse _getPartyById(User user, String tenant, Long partyId) {
		authToken = user.getAuthToken();
		String url = String.format("%s/%s/public/v1/parties/%s", partyRegistryUrl, tenant, partyId);
		PartyResponse pr = sendGetRequest(tenant, url, PartyResponse.class, "getPartyById");
		return pr;
	}

}
