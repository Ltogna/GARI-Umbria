package com.abacogroup.agri.applicationforms.pua.core.model.dto;

import java.util.List;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 
 * @author Emanuele Crocilla
 *
 */
@Data
@NoArgsConstructor
public class PlotRecord {
	
    private int plotId;
    private String plotCode;
    private String domainZoneId;
    private String description;
    private String notes;
    private List<Object> parcelIntersections; // Cambia il tipo se necessario
    private int areaSqm;
    private String geom;
    private String srs;
    private String mbrOverview;
    private List<Declaration> decls;
    private Style style;
    private String fromDate;
    private String toDate;
    private String fullRangeFromDate;
    private String fullRangeToDate;
    private String editability;
    private List<Object> anomalies; // Cambia il tipo se necessario

    @Data
    @NoArgsConstructor
    public static class Declaration {
        private String declCode;
        private LandUse landuse;
        private double areaPerc;
        private Style style;
        private String fromDate;
        private String fromDatePrecision;
        private String toDate;
        private List<Object> permanentCropForms; // Cambia il tipo se necessario
        private List<Object> anomalies; // Cambia il tipo se necessario
        private List<Object> pesticides; // Cambia il tipo se necessario
        private List<FieldCode> fieldsCodes;
        private String plotCodeDeclCodeKey;
        private Integer plotId;
        private String plotCode;
        private Integer plotAreaSqm;
    }

    @Data
    @NoArgsConstructor
    public static class LandUse {
        private String code;
        private String description;
    }

    @Data
    @NoArgsConstructor
    public static class Style {
        private String fillColor;
        private String fillStyle;
        private String borderColor;
    }

    @Data
    @NoArgsConstructor
    public static class FieldCode {
        private String fieldCode;
        private String fieldDescription;
        private String dayFrom;
        private String dayTo;
        private int sortOrder;
        private String value;
        private String valueDescription;
        private boolean flShowInTooltip;
        private String plotCodeDeclCodeKey;
    }
}

