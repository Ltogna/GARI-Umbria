package com.abacogroup.agri.applicationforms.pua.core.model.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 
 * @author Emanuele Crocilla
 * 
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class MaxToAddByCrop {
    private String cropCode;
    private Double nitrogenQt;
    private Double yield;
    private Double nitrogenCorrectionFactor;
}
