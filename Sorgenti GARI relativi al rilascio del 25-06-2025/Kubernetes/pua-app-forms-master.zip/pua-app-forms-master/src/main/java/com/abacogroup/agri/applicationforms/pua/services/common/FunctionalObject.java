package com.abacogroup.agri.applicationforms.pua.services.common;

/**
 * 
 * @author Emanuele Crocilla
 *
 */
@FunctionalInterface
public interface FunctionalObject<T> {
	T get();
}
