package com.abacogroup.agri.applicationforms.pua.core.mappers;

import org.mapstruct.factory.Mappers;

/**
 * 
 * @author Emanuele Crocilla
 *
 * @param <D>
 * @param <N>
 */
public interface EntityMapper<D, N> {
    D entityToDto(N entity);
    N dtoToEntity(D dto);
    
    default public EntityMapper<D, N> getInstance(){
    	return Mappers.getMapper(this.getClass());
    }

}
