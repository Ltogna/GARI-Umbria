package com.abacogroup.agri.applicationforms.pua.db.ntt;

import java.time.LocalDateTime;
import java.util.Optional;

import com.abacogroup.agri.applicationforms.pua.db.ntt.applications.IHistoricizationFields;
import com.abacogroup.agri.applicationforms.pua.db.ntt.applications.IIdRs;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

/**
 * @author Mauro Pozzana
 */
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class AttachmentNTT implements IIdRs<Long>, IHistoricizationFields {

	private Long pkid;
	private Long application_id;
	private String attachment_id;
	private String bucket_id;
	private Long type;
	private String type_code;
	private String file_name;
	private String notes;
	private String user_id_insert;
	private String user_id_delete;
	private LocalDateTime dt_insert;
	private LocalDateTime dt_delete;
	private Long type_id;
	private String type_attachment_group_code;
	private String type_attachment_code;
	private String tenant_id;
	@Override
	public Optional<Long> getKey() {
		return Optional.ofNullable(getPkid());
	}

	@Override
	public void setKey(Long id) {
		setPkid(id);
	}
}
