package com.abacogroup.agri.applicationforms.pua.core.model.dto;

import com.abacogroup.agri.applicationforms.pua.core.model.AbsoluteDate;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Schema(description = "The option config with option code")
public class OptionConfigsWithCodeDTO {

	@Schema(description = "the option config's id")
	private Long id;
	@Schema(description = "the option code")
	private String optionCode;
	@Schema(description = "the option config's option minimum area")
	private Double optionMinimumValue;
	@Schema(description = "the option config's parcel minimum engageable area")
	private Double optionRowMinimumEngageableValue;
	@Schema(description = "the option config's all engagement flag")
	private Integer flFullEngagement;
	@Schema(description = "the option config's validity start date")
	private AbsoluteDate dtValidityStart;
	@Schema(description = "the option config's validity end date")
	private AbsoluteDate dtValidityEnd;
	@Schema(description = "the starting year")
	private Integer startYear;
	@Schema(description = "the number of the engaged years")
	private Integer numberOfYears;
	@Schema(description = "the flag to indicate if the field is auto compiled if equals to 1")
	private Integer flAutoCompile;

}
