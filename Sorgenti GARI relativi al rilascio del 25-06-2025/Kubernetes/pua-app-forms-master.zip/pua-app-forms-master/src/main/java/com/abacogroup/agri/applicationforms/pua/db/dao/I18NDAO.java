package com.abacogroup.agri.applicationforms.pua.db.dao;

import java.util.List;

import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;
import org.jdbi.v3.sqlobject.transaction.Transactional;

import com.abacogroup.agri.applicationforms.pua.db.ntt.applications.RsI18N;
import com.abacogroup.jdbi.EnhancedSqlObject;

/**
 * @author Gennaro Tamburrelli
 */
public interface I18NDAO extends EnhancedSqlObject, Transactional<I18NDAO> {

	@SqlUpdate("INSERT INTO appfpua_i18n_values " +
			"(TENANT_ID, TABLE_NAME, FIELD_NAME, I18N_VALUE, LANG, I18N_TEXT) " +
			"VALUES(:tenant, :table, :field_name, :type_code, :lang, :i18n_text)")
	void insertI18N(@Bind("tenant") String tenant, @Bind("table") String table, @Bind("field_name") String fieldName,
			@Bind("type_code") String typeCode, @Bind("lang") String lang, @Bind("i18n_text") String i18ntext);

	@SqlQuery("select i18n_text " +
			"from (§i18n(:tenant, :table, :field_name, :type_code, :lang)§) ")
	@RegisterBeanMapper(RsI18N.class)
	List<RsI18N> getI18NByLang(@Bind("tenant") String tenant, @Bind("table") String table, @Bind("field_name") String fieldName,
			@Bind("type_code") String typeCode, @Bind("lang") String lang);

	@SqlQuery("select * " +
			"from appfpua_i18n_values " +
			"where tenant_id=:tenant " +
			"and table_name=:table " +
			"and i18n_value=:type_code")
	@RegisterBeanMapper(RsI18N.class)
	List<RsI18N> getAllI18N(@Bind("tenant") String tenant, @Bind("table") String table, @Bind("type_code") String typeCode);

	@SqlQuery("select * " +
			"from appfpua_i18n_values " +
			"where tenant_id=:tenant " +
			"and table_name='appfpua_withdraw_reasons' " +
			"and lang='it' " +
			"and field_name='reason_code' " +
			"and i18n_value=:type_code")
	@RegisterBeanMapper(RsI18N.class)
	RsI18N getI18NReasonCode(@Bind("tenant") String tenant, @Bind("type_code") String typeCode);

	@SqlUpdate("delete from appfpua_i18n_values  " +
			"  where tenant_id = :tenant " +
			"  and table_name = :table " +
			"  and field_name = :field_name " +
			"  and i18n_value = :type_code " +
			"  and lang = :lang ")
	void deleteI18N(@Bind("tenant") String tenant, @Bind("table") String table, @Bind("field_name") String fieldName,
			@Bind("type_code") String typeCode, @Bind("lang") String lang);

	@SqlUpdate("DELETE FROM appfpua_i18n_values " +
			"WHERE tenant_id = :tenant_id AND table_name = :table AND I18N_VALUE = :type_code")
	void deleteAllByCode(@Bind("tenant_id") String tenant, @Bind("table") String table, @Bind("type_code") String typeCode);
}
