package com.abacogroup.agri.applicationforms.pua.db.ntt;

import java.time.OffsetDateTime;
import java.util.Optional;

import com.abacogroup.agri.applicationforms.pua.db.ntt.applications.IIdRs;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * NTT (Network Transfer Table) for appfpua_effluent
 * 
 * @author Emanuele Crocilla
 * 
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class EffluentNTT implements IIdRs<Long> {
    
    private Long pkId;
    
    private String categoryCode;
    private String fertilizerCategory;
    private String typeCode;
    private String fertilizerType;
    
    private OffsetDateTime dtInsert;
    private OffsetDateTime dtDelete;
    
    private String userIdInsert;
    private String userIdDelete;
    
    @Override
    public void setKey(Long id) {
        setPkId(id);
    }
    
    @Override
    public Optional<Long> getKey() {
        return Optional.ofNullable(getPkId());
    }
}
