package com.abacogroup.agri.applicationforms.pua.core.mappers;

import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import com.abacogroup.agri.applicationforms.pua.core.model.dto.AttachmentTypeDTO;
import com.abacogroup.agri.applicationforms.pua.db.ntt.AttachmentTypeNTT;
import com.abacogroup.jdbi.mapper.AbsoluteDateMapper;

@Mapper(uses = AbsoluteDateMapper.class)
public interface AttachmentTypeMapper extends EntityMapper<AttachmentTypeDTO, AttachmentTypeNTT> {

	AttachmentTypeMapper INSTANCE = Mappers.getMapper(AttachmentTypeMapper.class);

	@InheritInverseConfiguration()
	AttachmentTypeDTO entityToDto(AttachmentTypeNTT entity);

	@Mapping(source = "pkid", target = "pkid")
	@Mapping(source = "attachmentGroupCode", target = "attachment_group_code")
	@Mapping(source = "tenantId", target = "tenant_id")
	@Mapping(source = "code", target = "code")
	@Mapping(source = "typeCode", target = "type_code")
	AttachmentTypeNTT dtoToEntity(AttachmentTypeDTO dto);

}
