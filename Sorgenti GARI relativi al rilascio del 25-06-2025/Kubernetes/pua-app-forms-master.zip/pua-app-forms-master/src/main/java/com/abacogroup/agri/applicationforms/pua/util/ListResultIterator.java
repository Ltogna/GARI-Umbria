package com.abacogroup.agri.applicationforms.pua.util;

import org.jdbi.v3.core.result.ResultIterator;
import org.jdbi.v3.core.statement.StatementContext;

import java.util.Iterator;
import java.util.List;
import java.util.function.Consumer;

/**
 * 
 * @author Emanuele Crocilla
 *
 * @param <T>
 */
public class ListResultIterator<T> implements ResultIterator<T> {
	private final Iterator<T> iterator;
	private final StatementContext ctx;

	public ListResultIterator(List<T> list, StatementContext ctx) {
		this.iterator = list.iterator();
		this.ctx = ctx;
	}

	@Override
	public void close() {
		// Non c'è nulla da chiudere con una lista
	}

	@Override
	public StatementContext getContext() {
		return ctx;
	}

	@Override
	public boolean hasNext() {
		return iterator.hasNext();
	}

	@Override
	public T next() {
		return iterator.next();
	}

	@Override
	public void forEachRemaining(Consumer<? super T> action) {
		iterator.forEachRemaining(action);
	}
}
