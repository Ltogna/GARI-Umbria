package com.abacogroup.agri.applicationforms.pua.core.exceptions;

public class ObjectNotFoundException extends PuaApplicationsException {

	/**
	 * 
	 */
	private static final long serialVersionUID = -5253740675913336764L;

	public ObjectNotFoundException(String errorMessage, Throwable err) {
		super(errorMessage, err);
	}

	public ObjectNotFoundException(String errorMessage) {
		super(errorMessage);
	}

	public ObjectNotFoundException(Throwable err) {
		super(err);
	}
}
