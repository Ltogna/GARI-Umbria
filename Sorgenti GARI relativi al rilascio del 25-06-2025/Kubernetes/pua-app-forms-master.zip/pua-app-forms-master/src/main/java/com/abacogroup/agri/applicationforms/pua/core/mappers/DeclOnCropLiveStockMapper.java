package com.abacogroup.agri.applicationforms.pua.core.mappers;

import com.abacogroup.agri.applicationforms.pua.core.model.dto.DeclOnCropLiveStocksDTO;
import com.abacogroup.agri.applicationforms.pua.db.ntt.DeclOnCropLiveStocksNTT;
import com.abacogroup.agri.applicationforms.pua.util.GenericUtility;
import com.abacogroup.jdbi.mapper.AbsoluteDateMapper;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;
import org.mapstruct.factory.Mappers;

@Mapper(uses = AbsoluteDateMapper.class)
public interface DeclOnCropLiveStockMapper extends EntityMapper<DeclOnCropLiveStocksDTO, DeclOnCropLiveStocksNTT> {

	DeclOnCropLiveStockMapper INSTANCE = Mappers.getMapper(DeclOnCropLiveStockMapper.class);

	@InheritInverseConfiguration()

	//	@Mapping(source = "genreCode", target = "genreCode")
	//	@Mapping(source = "productionCode", target = "productionCode")
	@Mapping(source = "pkid", target = "id")
	DeclOnCropLiveStocksDTO entityToDto(DeclOnCropLiveStocksNTT entity);

	@Mapping(source = "id", target = "pkid")
	@Mapping(source = "applicationId", target = "applicationId")
	@Mapping(source = "species", target = "animalSpecies")
	@Mapping(source = "category", target = "animalCategory")
	@Mapping(source = "typeStabling", target = "housingSystem")
	@Mapping(source = "numberHeadsRaised", target = "headOfLivestockNumb")
	@Mapping(source = "numberField", target = "numberInTheField")
	@Mapping(source = "averagePV", target = "averageLiveWeight", qualifiedByName = "truncateToFourDecimals")
	@Mapping(source = "sewageOutlet", target = "liquidEfflLeavingStable")
	@Mapping(source = "manureOrShovelableOutput", target = "solidEffluentLeavingStable")
	DeclOnCropLiveStocksNTT dtoToEntity(DeclOnCropLiveStocksDTO dto);

	@Named("shortToBoolean")
	default boolean shortToBoolean(short value) {
		return value != 0;
	}

	@Named("booleanToShort")
	default short booleanToShort(boolean value) {
		return value ? (short) 1 : (short) 0;
	}
	
	@Named("truncateToFourDecimals")
	default Double truncateToFourDecimals(Double in) {
		return GenericUtility.truncateDecimals(in, 4);
	}

}
