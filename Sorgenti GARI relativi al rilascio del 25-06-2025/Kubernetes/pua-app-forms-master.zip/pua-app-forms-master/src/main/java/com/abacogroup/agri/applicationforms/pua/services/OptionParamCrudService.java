package com.abacogroup.agri.applicationforms.pua.services;

import java.util.List;
import java.util.Optional;

import com.abacogroup.agri.applicationforms.pua.core.exceptions.ObjectNotFoundRuntimeException;
import com.abacogroup.agri.applicationforms.pua.core.mappers.OptionParamMapper;
import com.abacogroup.agri.applicationforms.pua.core.model.dto.OptionParamDTO;
import com.abacogroup.agri.applicationforms.pua.db.dao.OptionParamDAO;
import com.abacogroup.agri.applicationforms.pua.db.keys.OptionParamKey;
import com.abacogroup.agri.applicationforms.pua.db.ntt.OptionParamNTT;
import com.abacogroup.agri.applicationforms.pua.services.common.crud.AbstractCrudService;

import lombok.extern.slf4j.Slf4j;

/**
 * @author Mattia Perini
 */
@Slf4j
public class OptionParamCrudService
		extends AbstractCrudService<OptionParamNTT, OptionParamKey, OptionParamDTO, OptionParamMapper, OptionParamKey, OptionParamDAO> {

	public OptionParamCrudService(OptionParamDAO dao, OptionParamMapper mapper) {
		super(dao, mapper);
	}

	@Override
	protected boolean hasPrimaryKey() {
		return false;
	}

	@Override
    protected OptionParamKey retrievePrimaryKey(OptionParamKey customKey) {
		return customKey;
	}

	@Override
	protected Optional<OptionParamNTT> findRsByCustomKey(OptionParamKey customKey) {
		return this.dao.findById(customKey).stream().findFirst();
	}

	@Override
	protected void deleteByCustomKey(OptionParamKey customKey) {
		this.dao.deleteById(customKey);
	}

	@Override
	protected void setCustomSearchKey(OptionParamNTT rs, OptionParamKey customKey) {
		rs.setKey(customKey);
	}

    public OptionParamDTO findById(String tenant, OptionParamKey key) throws ObjectNotFoundRuntimeException {
        log.info("Invoking find by id with tenant: {} key: {}", tenant, key);
        return ((OptionParamDAO) this.dao).findByIdAndTenant(tenant, key).stream()
                .findFirst()
                .map(mapper::entityToDto)
                .orElseThrow(ObjectNotFoundRuntimeException::new);
    }

    public List<OptionParamDTO> findByIdAndParamName(OptionParamKey key) {
		return ((OptionParamDAO) this.dao).findByIdLike(key).stream()
				.map(mapper::entityToDto)
				.toList();
	}

	public Optional<OptionParamDTO> findOptById(String tenant, OptionParamKey key) {
		log.info("Invoking findOptById with params tenant: {} key: {}", tenant, key);
		return ((OptionParamDAO) this.dao).findByIdAndTenant(tenant, key).stream()
				.findFirst()
				.map(mapper::entityToDto);
	}

	public List<OptionParamDTO> findByOptionConfigId(String tenant, Long optionConfigId) {
		log.info("Invoking findByOptionConfigId with params tenant: {} optionConfigId: {}", tenant, optionConfigId);
		return ((OptionParamDAO) this.dao).findByOptionConfigId(tenant, optionConfigId).stream()
				.map(mapper::entityToDto)
				.toList();
	}

	public List<OptionParamDTO> findByOptionConfigIds(String tenant, List<Long> optionConfigIds) {
		log.info("Invoking findByOptionConfigIds with params tenant: {} optionConfigIds: {}", tenant, optionConfigIds);
		return ((OptionParamDAO) this.dao).findByOptionConfigIds(tenant, optionConfigIds).stream()
				.map(mapper::entityToDto)
				.toList();
	}

	public OptionParamDTO insert(OptionParamDTO in) {
		log.info("Invoking insert with params in: {}", in);
		return this.insert(in, OptionParamKey.builder()
				.optionConfigId(in.getOptionConfigId())
				.attributeName(in.getAttributeName())
				.build());
	}

	public OptionParamDTO update(OptionParamKey key, OptionParamDTO in) {
		log.info("Invoking update with params key: {} in: {}", key, in);
		this.delete(key);
		return this.insert(in);
	}

	public void delete(OptionParamKey key) {
		log.info("Invoking delete with params key: {}", key);
		this.delete(null, key);
	}

	public void deleteByOptionConfigId(OptionParamKey key) {
		log.info("Invoking delete with params key: {}", key);
		((OptionParamDAO) this.dao).deleteByOptionConfigId(key);
	}
}
