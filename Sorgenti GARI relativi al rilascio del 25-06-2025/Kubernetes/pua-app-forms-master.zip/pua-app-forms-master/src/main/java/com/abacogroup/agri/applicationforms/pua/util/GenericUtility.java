package com.abacogroup.agri.applicationforms.pua.util;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Optional;
import java.util.function.BiFunction;
import java.util.function.Function;
import java.util.function.Supplier;
import java.util.stream.Collectors;

import org.apache.commons.lang3.NotImplementedException;

import com.abacogroup.agri.applicationforms.pua.core.exceptions.AgriApplicationFormsRuntimeException;
import com.abacogroup.agri.applicationforms.pua.core.exceptions.BadRequestRuntimeException;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.jdbi.paging.impl.InfiniteListResultsImpl;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.extern.slf4j.Slf4j;

/**
 * 
 * @author Emanuele Crocilla
 *
 */
@Slf4j
public final class GenericUtility {

	private GenericUtility() {
	}

	private static final ObjectMapper mapper = new ObjectMapper();

	public static final Supplier<NotImplementedException> throwNotImplementedException = () -> new NotImplementedException("not in use");

	public enum NumberPattern {
		
		PATTERN_DECIMAL("#,##0.0000"), // Output example: 123.0 -> 123,0000
		PATTERN_DECIMAL_2("#,##0.00"), // Output example: 123.0 -> 123,00
		PATTERN_INT("#,##0"); 	// Output example: 123.0 -> 123
		
		private String pattern;
		
		private NumberPattern(String pattern) {
			this.pattern = pattern;
		}

		public String getPattern() {
			return pattern;
		}
	}

	/**
     * Returns the value from the inGetter if it's not null, otherwise returns the value from actualGetter.
     * This is a convenience method for Optional handling.
     *
     * @param inGetter Supplier that provides the primary value
     * @param actualGetter Supplier that provides the fallback value
     * @return The value from inGetter if not null, otherwise the value from actualGetter
     */
	public static <T> T getValueFromInIfIsNotNull(Supplier<T> inGetter, Supplier<T> actualGetter) {
		return Optional.ofNullable(inGetter.get())
				.orElseGet(actualGetter);
	}

    /**
     * Maps the elements of an InfiniteListResults using the provided mapper function.
     *
     * @param infiniteListResults The source infinite list results
     * @param mapper Function to transform elements from input type to output type
     * @return A new InfiniteListResults with transformed elements and the same nextKey
     */
	public static <O, I> InfiniteListResults<O> returnInfiniteResults(InfiniteListResults<I> infiniteListResults, Function<I, O> mapper) {
		return new InfiniteListResultsImpl<>(
				infiniteListResults.getRecords()
						.stream()
						.map(mapper)
						.toList(),
				infiniteListResults.getNextKey());
	}

    /**
     * Maps the elements of an InfiniteListResults using a BiFunction that takes each element and a secondary parameter.
     *
     * @param infiniteListResults The source infinite list results
     * @param secondType Additional parameter to pass to the mapper function
     * @param mapper BiFunction to transform elements using both the element and secondary parameter
     * @return A new InfiniteListResults with transformed elements and the same nextKey
     */
	public static <O, I, T> InfiniteListResults<O> returnInfiniteResults(InfiniteListResults<I> infiniteListResults, T secondType, BiFunction<I, T, O> mapper) {
		return new InfiniteListResultsImpl<>(
				infiniteListResults.getRecords()
						.stream()
						.map(i -> mapper.apply(i, secondType))
						.toList(),
				infiniteListResults.getNextKey());
	}

    /**
     * Maps the first element of a list (if any) to another type and returns it as an Optional.
     * If the input list is null, returns an empty Optional.
     *
     * @param input The source list
     * @param mapper Function to transform the element
     * @return Optional containing the transformed first element, or empty if list is null or empty
     */
	public static <I, O> Optional<O> returnOptionalFromList(List<I> input, Function<I, O> mapper) {
		return Optional.ofNullable(input)
				.orElseGet(Collections::emptyList)
				.stream()
				.findFirst()
				.map(mapper);
	}
	
    /**
     * Transforms an input value if it's not null and returns the result as an Optional.
     *
     * @param input The input value to transform
     * @param mapper Function to transform the input
     * @return Optional containing the transformed value, or empty if input is null
     */
	public static <I, O> Optional<O> transformIfPresent(I input, Function<I, O> mapper) {
	    return Optional.ofNullable(input).map(mapper);
	}

    /**
     * Maps all elements in a list to another type using the provided mapper function.
     * If the input list is null, returns an empty list.
     *
     * @param input The source list
     * @param mapper Function to transform each element
     * @return List containing all transformed elements
     */
	public static <I, O> List<O> returnMappedList(List<I> input, Function<I, O> mapper) {
		return Optional.ofNullable(input)
				.orElseGet(Collections::emptyList)
				.stream()
				.map(mapper)
				.toList();
	}

    /**
     * Converts a JSON string to an object of the specified class.
     *
     * @param payload JSON string to convert
     * @param clazz Target class type
     * @return Object of the specified class populated with data from the JSON string
     * @throws AgriApplicationFormsRuntimeException if JSON parsing fails
     */
	public static <T> T mapJsonToObject(String payload, Class<? extends T> clazz){
		try {
			return mapper.readValue(payload, clazz);
		} catch (JsonProcessingException e) {
			throw new AgriApplicationFormsRuntimeException(e.getMessage());
		}
	}

    /**
     * Returns the provided Long value or 0 if it's null.
     *
     * @param value The Long value to check
     * @return The provided value if not null, otherwise 0
     */
	public static long getLongValueOrZero(Long value) {
		return Optional.ofNullable(value)
				.orElse(0L);
	}

    /**
     * Extracts a specific attribute from each element in a list, removes duplicates,
     * and returns a list of these attribute values.
     *
     * @param elements Source list of elements
     * @param getter Function to extract the attribute from each element
     * @return List of distinct attribute values
     */
	public static <T, K> List<K> getAttributeFromList(List<T> elements,
											   Function<T,K> getter) {
		return elements.stream()
				.map(getter::apply)
				.distinct()
				.toList();
	}

    /**
     * Filters a list to include only elements where a specific attribute matches the given value.
     *
     * @param elements Source list of elements
     * @param attributeValue Value to match against
     * @param getter Function to extract the attribute to compare from each element
     * @return Filtered list containing only elements with matching attribute values
     */
	public static <E, T> List<E> getElementsByAttributeValue(
			List<E> elements, T attributeValue, Function<E, T> getter) {
		return elements.stream()
				.filter(element -> Optional.ofNullable(attributeValue).isPresent() &&
						attributeValue.equals(getter.apply(element))).toList();
	}

    /**
     * Filters a list to include only elements where a specific attribute is contained in the given values list.
     *
     * @param elements Source list of elements
     * @param attributeValues List of values to match against
     * @param getter Function to extract the attribute to compare from each element
     * @return Filtered list containing only elements with attribute values in the provided list
     */
	public static <E, T> List<E> getElementsByAttributeValues(
			List<E> elements, List<T> attributeValues, Function<E, T> getter) {
		return elements.stream()
				.filter(element -> Optional.ofNullable(attributeValues).isPresent() &&
						! attributeValues.isEmpty() &&
						attributeValues.contains(getter.apply(element))).toList();
	}

    /**
     * Returns the first element from a list where a specific attribute matches the given value.
     *
     * @param elements Source list of elements
     * @param attributeValue Value to match against
     * @param getter Function to extract the attribute to compare from each element
     * @return Optional containing the first matching element, or empty if none found
     */
	public static <E, T> Optional<E> getSingleElementByAttributeValue(
			List<E> elements, T attributeValue, Function<E, T> getter) {
		return getElementsByAttributeValue(elements, attributeValue, getter).stream()
				.findFirst();
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public static <T extends Enum<?>> T checkValidityAndGetElement(Class clazz, String value, Boolean allowEmpty) {
		log.info("Checking input value validity");

		T optionAction = null;
		try {
			if (!allowEmpty && Optional.ofNullable(value).isEmpty()) {
				throw new IllegalArgumentException("No matching value specified");
			}

			if (Optional.ofNullable(value).isPresent()) {
				optionAction = (T) T.valueOf(clazz, value);
			}
		} catch(IllegalArgumentException e) {
			throw new BadRequestRuntimeException(MessageFormat.format("Option of value {0} not supported. Aborting.", value));
		}

		log.info("Option of value {} is valid.", value);

		return optionAction;
	}

    /**
     * Returns 0 if the input number is null, otherwise returns the input value.
     *
     * @param value The number to check
     * @return The provided value if not null, otherwise 0
     */
	public static Number setZeroIfNull(Number value) {
		return Optional.ofNullable(value).orElse(0);
	}
	
    /**
     * Formats a string by replacing {} placeholders with the provided objects.
     * If there are more placeholders than provided objects, [?] is used for the extras.
     *
     * @param toFormat String template with {} placeholders
     * @param objs Objects to insert into the template
     * @return Formatted string with placeholders replaced by object values
     */
	public static String formatStr(String toFormat, Object...objs) {
		String str = toFormat.replaceAll("\\{\\}", "%s");
		int found = str.split("%s", -1).length - 1; 
		if (found > objs.length) {
			List<Object> newObjs = new ArrayList<>(Arrays.asList(objs));
			for (int ii = objs.length; ii < found; ii++) {
				newObjs.add("[?]");
			}
			return String.format(str, newObjs.toArray());
		}
		return String.format(str, objs);
	}
	
    /**
     * Converts an InputStream to a String.
     *
     * @param inputStream The input stream to convert
     * @return String representation of the input stream content
     * @throws RuntimeException if conversion fails
     */
	public static String convertInputStreamToString(InputStream inputStream) {
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream))) {
            return reader.lines().collect(Collectors.joining("\n"));
        } catch (Exception e) {
            throw new RuntimeException("Error converting InputStream to String", e);
        }
    }
	
    /**
     * Returns the provided value if it's not null, otherwise returns the default value.
     *
     * @param t The value to check
     * @param def The default value to return if t is null
     * @return The provided value if not null, otherwise the default value
     */
	public static <T> T getValueOrDefaultWhenIsNull(T t, T def) {
        try {
           	if(t != null) return t;
        } catch (Exception ignore) { /**do nothing*/ }
        return def;
    }
	
    /**
     * Removes trailing whitespace from a string.
     *
     * @param s The string to trim
     * @return The string with trailing whitespace removed, or null if input is null
     */
	public static String rtrim(String s) {
	    if (s == null) {
	        return null;
	    }
	    return s.replaceAll("\\s+$", "");
	}

    /**
     * Checks if a string consists only of digits.
     *
     * @param s The string to check
     * @return true if the string contains only digits, false otherwise or if null/empty
     */
	public static boolean isDigit(String s) {
	    if (s == null || s.isEmpty()) {
	        return false;
	    }

	    for (char c : s.toCharArray()) {
	        if (!Character.isDigit(c)) {
	            return false;
	        }
	    }

	    return true;
	}
	
    /**
     * Removes duplicate elements from a collection while preserving order.
     *
     * @param inputCollection The collection to process
     * @return A new collection with duplicates removed
     */
	public static <T extends Collection<?>> T removeDuplicates(Collection<?> inputCollection) {
        if (inputCollection == null) {
            return (T) new ArrayList<>();
        }
        return (T) new ArrayList<>(new LinkedHashSet<>(inputCollection));
    }
	
	/**
	 * Checks if the collection contains at least one of the specified elements.
	 * 
	 * @param listToCheck collection to check
	 * @param elementsToRetrive elements to search for in the collection
	 * @return true if at least one of the specified elements is found in the collection, false otherwise
	 */
	public static <T> boolean containsAtLeastOneOfThese(Collection<T> listToCheck, T...elementsToRetrive) {
	    if (listToCheck == null || elementsToRetrive == null || elementsToRetrive.length == 0) {
	        return false;
	    }
	    
	    for (T element : elementsToRetrive) {
	        if (listToCheck.contains(element)) {
	            return true;
	        }
	    }
	    
	    return false;
	}

	/**
	 * Checks if the collection contains all of the specified elements.
	 * 
	 * @param listToCheck collection to check
	 * @param elementsToRetrive elements to search for in the collection
	 * @return true if all of the specified elements are found in the collection, false otherwise
	 */
	public static <T> boolean containsAllOfThese(Collection<T> listToCheck, T...elementsToRetrive) {
	    if (listToCheck == null || elementsToRetrive == null) {
	        return false;
	    }
	    
	    if (elementsToRetrive.length == 0) {
	        return true;  // If there are no elements to search for, the condition is true
	    }
	    
	    for (T element : elementsToRetrive) {
	        if (!listToCheck.contains(element)) {
	            return false;
	        }
	    }
	    
	    return true;
	}
	
	public static String formatNumbAndGetAsString(Number number, NumberPattern numbPattern) {
		DecimalFormat df = new DecimalFormat(numbPattern.getPattern());
		df.setDecimalFormatSymbols(new DecimalFormatSymbols(Locale.ITALIAN));
		return number != null ? df.format(number) : "0"; 
	}
	
	public static double truncateDecimals(double value, int decimalPlaces) {
	    double factor = Math.pow(10, decimalPlaces);
	    return Math.floor(value * factor) / factor;
	}
	
}
