package com.abacogroup.agri.applicationforms.pua.core.model.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.time.OffsetDateTime;

@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
@Schema(description = "The Declaration On Sectors DTO")
public class DeclOnCropLiveStocksDTO {

	@Schema(description = "Primary key")
	@JsonProperty("id")
	private Long id;

	@Schema(description = "Animal species")
	@JsonProperty("species")
	private String species;

	@Schema(description = "Animal category")
	@JsonProperty("category")
	private String category;

	@Schema(description = "Type of stabling/housing system")
	@JsonProperty("typeStabling")
	private String typeStabling;

	@Schema(description = "Number of heads raised")
	@JsonProperty("numberHeadsRaised")
	private Integer numberHeadsRaised;

	//Not editable fields
	@Schema(description = "Number in the field")
	@JsonProperty("numberField")
	private Double numberField;

	@Schema(description = "Average live weight (PV)")
	@JsonProperty("averagePV")
	private Double averagePV;

	@Schema(description = "Sewage outlet")
	@JsonProperty("sewageOutlet")
	private Double sewageOutlet;

	@Schema(description = "Manure or shovelable output")
	@JsonProperty("manureOrShovelableOutput")
	private Double manureOrShovelableOutput;

	@Schema(description = "Insert date")
	@JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ssXXX")
	@JsonProperty(access = JsonProperty.Access.READ_ONLY)
	private OffsetDateTime dtInsert;

	@Schema(description = "Deleted date")
	@JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ssXXX")
	@JsonProperty(access = JsonProperty.Access.READ_ONLY)
	private OffsetDateTime dtDelete;

	@Schema(description = "User ID who inserted this record")
	@JsonProperty(access = JsonProperty.Access.READ_ONLY)
	private String userIdInsert;

	@Schema(description = "User ID who deleted this record")
	@JsonProperty(access = JsonProperty.Access.READ_ONLY)
	private String userIdDelete;

	@JsonProperty("applicationId")
	@JsonIgnore
	private Long applicationId;
}
