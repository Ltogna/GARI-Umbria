package com.abacogroup.agri.applicationforms.pua.core.model.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class FabbisognoResponse {

	@JsonProperty("Chiave_Appezzamneto") // <-- Must match exact field from JSON
	private String chiaveAppezzamento;

	@JsonProperty("N_Fabbisogno")
	private double nFabbisogno;
}

