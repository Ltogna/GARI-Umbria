package com.abacogroup.agri.applicationforms.pua.resources;

import com.abacogroup.agri.applicationforms.pua.ApplicationFormsModuleConfiguration;
import com.abacogroup.agri.applicationforms.pua.core.exceptions.BalanceNotFoundRuntimeException;
import com.abacogroup.agri.applicationforms.pua.core.model.dto.*;
import com.abacogroup.agri.applicationforms.pua.util.CommonConstants;
import com.abacogroup.agri.applicationforms.pua.util.JsonUtils;
import com.abacogroup.agri.applicationforms.pua.util.LogUtils;
import com.abacogroup.dropwizard.auth.sso2.Sso2Client;
import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.jdbi.paging.impl.InfiniteListResultsImpl;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.dropwizard.auth.Auth;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.parameters.RequestBody;
import jakarta.validation.constraints.NotNull;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.client.*;
import jakarta.ws.rs.core.HttpHeaders;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import lombok.extern.slf4j.Slf4j;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * @author Klaudio Marku
 */
@Slf4j
public class BalanceIndicesResources extends AGenericPuaResources {
	private final WebTarget client;
	protected final ObjectMapper mapper;

	public BalanceIndicesResources(ApplicationFormsModuleConfiguration configuration,
			Sso2Client sso2Client, Client client, ObjectMapper mapper) {
		super(configuration, sso2Client);
		this.mapper = mapper;
		final List<Object> contentEncoding = List.of("identity");
		this.client = client.target(configuration.getGiasBaseUrl());
		this.client.register(new ClientRequestFilter() {
			@Override
			public void filter(ClientRequestContext requestContext) throws IOException {
				// Disable gzip on POST, it looks like the remote service doesn't like that
				requestContext.getHeaders().put(HttpHeaders.CONTENT_ENCODING, contentEncoding);
			}
		});
	}

	@POST
	@Path("/{applicationId}/balance-indicates")
	public InfiniteListResults<BalanceIndicesResponse> list(
			@Auth User user,
			@NotNull @RequestBody BalanceIndicesRequest payload,
			@Parameter(description = "Current Tenant") @NotNull @PathParam("tenant") String tenant,
			@Parameter(description = "The application id") @NotNull @PathParam("applicationId") Long applicationId,
			@Parameter(description = "The form config id") @NotNull @QueryParam("formConfigId") Long formConfigId,
			@Parameter(description = "The compile status identifier") @QueryParam("compileStatusIdentifier") String compileStatusIdentifier
	) {
		InfiniteListResultsImpl<BalanceIndicesResponse> result = new InfiniteListResultsImpl<BalanceIndicesResponse>();
		//#TODO Uncomment these when newAgriToken will be there
		var authenticate = authenticateWithNewAgri();
		return agriDistribuito(applicationId, tenant, authenticate.getRispostaStringa(), payload);
	}

	public TokenResponse authenticateWithNewAgri() {
		try (Response res = client.path("/AgronicaCoreApi/Login/BackgroundAuthentication")
				.request(MediaType.APPLICATION_JSON)
				.post(Entity.json(Map.of("key", configuration.getGiasLoginToken())))) {

			if (res.getStatusInfo().getFamily() != Response.Status.Family.SUCCESSFUL) {
				String err = res.readEntity(String.class);
				throw new RuntimeException(String.format("Error authenticating to GIAS, status %s, body=%s", res.getStatus(), err));
			}

			return res.readEntity(TokenResponse.class);
		}
	}

	public InfiniteListResults<BalanceIndicesResponse> agriDistribuito(Long appicationId, String tenant, String token, BalanceIndicesRequest request) {
		try (Response res = client.path("/AgronicaCoreApi/NewAgri/N_Distribuito/")
				.request(MediaType.APPLICATION_JSON)
				.header(CommonConstants.AUTHORIZATION, CommonConstants.BEARER + token)
				.post(Entity.json(request))) {

			if (res.getStatusInfo().getFamily() != Response.Status.Family.SUCCESSFUL) {
				var err = res.readEntity(AgriErrorResponse.class);
				throw new BalanceNotFoundRuntimeException(err.getErrore());
			}

			BalanceIndicesRootResponse balanceIndicesRootResponse = null;
			try {
				
				 balanceIndicesRootResponse =
						mapper.readValue(res.readEntity(String.class), BalanceIndicesRootResponse.class);
				
				return MappResult(balanceIndicesRootResponse);
				
			} catch (JsonProcessingException e) {
				LogUtils.logErrorServiceData(log,  request, balanceIndicesRootResponse,client, "/AgronicaCoreApi/NewAgri/N_Distribuito/");
				throw new RuntimeException(e);
			}
		}
	}

	private InfiniteListResults<BalanceIndicesResponse> MappResult(BalanceIndicesRootResponse data) {
		InfiniteListResultsImpl<BalanceIndicesResponse> result = new InfiniteListResultsImpl<BalanceIndicesResponse>();
		var balancelist = new ArrayList<BalanceIndicesResponse>();
		if (data != null && data.getDati().getListaLimitiMas() != null && !data.getDati().getListaLimitiMas().isEmpty()) {
			balancelist.addAll(data.getDati().getListaLimitiMas());
		}
		result.setRecords(balancelist);
		return result;
	}
}
