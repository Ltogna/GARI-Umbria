package com.abacogroup.agri.applicationforms.pua.util;

import java.time.OffsetDateTime;
import java.time.ZoneOffset;

/**
 * @author Emanuele Crocilla
 */
public interface CommonConstants {

	public static final String AUTH_PREFIX = "JWT ";

	public static final OffsetDateTime FAR_OFF_DATE = OffsetDateTime.of(9999, 12, 31, 0, 0, 0, 0, ZoneOffset.UTC);

	public static final String WAIVER_DOCUMENT_CODE = "WAIVER_DOCUMENT_CODE";

	public static final String AUTHORIZATION = "Authorization";
	public static final String BEARER = "Bearer ";

}
