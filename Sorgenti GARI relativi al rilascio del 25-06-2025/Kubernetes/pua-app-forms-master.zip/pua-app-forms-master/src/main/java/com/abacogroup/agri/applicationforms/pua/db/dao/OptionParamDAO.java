package com.abacogroup.agri.applicationforms.pua.db.dao;

import java.util.List;

import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.customizer.BindBean;
import org.jdbi.v3.sqlobject.customizer.BindList;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;

import com.abacogroup.agri.applicationforms.pua.db.keys.OptionParamKey;
import com.abacogroup.agri.applicationforms.pua.db.ntt.OptionParamNTT;

/**
 * @author Mattia Perini
 */
public interface OptionParamDAO extends IGenericPuaDAO<OptionParamNTT, OptionParamKey> {
	@Override
	@SqlUpdate("INSERT INTO appfpua_option_params " +
			" (option_config_id, " +
			" attribute_name, " +
			" attribute_value) " +
			" VALUES(:option_config_id, :attribute_name, :attribute_value)")
	void insert(@BindBean OptionParamNTT ntt);

	@Override
	@SqlUpdate("UPDATE appfpua_option_params " +
			" SET option_config_id = :option_config_id, " +
			" attribute_name = :attribute_name, " +
			" attribute_value = :attribute_value " +
			" WHERE option_config_id = :option_config_id " +
			" AND attribute_name = :attribute_name")
	void update(@BindBean OptionParamNTT ntt);

	@Override
	@SqlQuery("SELECT p.option_config_id, " +
			" p.attribute_name, " +
			" p.attribute_value " +
			" FROM appfpua_option_params p" +
			" WHERE p.option_config_id = :optionConfigId " +
			" AND p.attribute_name = :attributeName ")
	@RegisterBeanMapper(OptionParamNTT.class)
	List<OptionParamNTT> findById(@BindBean OptionParamKey key);
	@SqlQuery("SELECT p.option_config_id, " +
			" p.attribute_name, " +
			" p.attribute_value " +
			" FROM appfpua_option_params p" +
			" WHERE p.option_config_id = :optionConfigId " +
			" AND p.attribute_name LIKE '%' || :attributeName || '%' " +
			" ORDER BY p.attribute_name")
	@RegisterBeanMapper(OptionParamNTT.class)
	List<OptionParamNTT> findByIdLike(@BindBean OptionParamKey key);

	@SqlQuery("SELECT p.option_config_id, " +
			" p.attribute_name, " +
			" p.attribute_value " +
			" FROM appfpua_option_params p" +
			" WHERE p.option_config_id = :optionConfigId " +
			" AND p.attribute_name = :attributeName " +
			" AND :tenant_id IN " +
			" (SELECT c.tenant_id " +
			"  FROM appfpua_option_catalog c " +
			"  INNER JOIN appfpua_option_configs o ON c.id = o.option_id" +
			"  WHERE p.option_config_id = o.id)")
	@RegisterBeanMapper(OptionParamNTT.class)
	List<OptionParamNTT> findByIdAndTenant(@Bind("tenant_id") String tenant, @BindBean OptionParamKey key);

	@SqlQuery("SELECT p.option_config_id, " +
			" p.attribute_name, " +
			" p.attribute_value " +
			" FROM appfpua_option_params p" +
			" WHERE p.option_config_id = :optionConfigId " +
			" AND :tenant_id IN " +
			" (SELECT c.tenant_id " +
			"  FROM appfpua_option_catalog c " +
			"  INNER JOIN appfpua_option_configs o ON c.id = o.option_id" +
			"  WHERE p.option_config_id = o.id)")
	@RegisterBeanMapper(OptionParamNTT.class)
	List<OptionParamNTT> findByOptionConfigId(@Bind("tenant_id") String tenant, @Bind("optionConfigId") Long optionConfigId);

	@SqlQuery("SELECT p.option_config_id, " +
			" p.attribute_name, " +
			" p.attribute_value " +
			" FROM appfpua_option_params p" +
			" WHERE p.option_config_id IN (<optionConfigIds>) " +
			" AND :tenant_id IN " +
			" (SELECT c.tenant_id " +
			"  FROM appfpua_option_catalog c " +
			"  INNER JOIN appfpua_option_configs o ON c.id = o.option_id" +
			"  WHERE p.option_config_id = o.id)")
	@RegisterBeanMapper(OptionParamNTT.class)
	List<OptionParamNTT> findByOptionConfigIds(@Bind("tenant_id") String tenant, @BindList("optionConfigIds") List<Long> optionConfigId);

	@Override
	@SqlUpdate("DELETE FROM appfpua_option_params p " +
			" WHERE p.option_config_id = :optionConfigId " +
			" AND p.attribute_name = :attributeName ")
	void deleteById(@BindBean OptionParamKey key);

	@SqlUpdate("DELETE FROM appfpua_option_params p " +
			" WHERE p.option_config_id = :optionConfigId")
	void deleteByOptionConfigId(@BindBean OptionParamKey key);

}
