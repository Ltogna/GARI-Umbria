package com.abacogroup.agri.applicationforms.pua.resources;

import com.abacogroup.agri.applicationforms.pua.ApplicationFormsModuleConfiguration;
import com.abacogroup.agri.applicationforms.pua.core.exceptions.ObjectNotFoundRuntimeException;
import com.abacogroup.agri.applicationforms.pua.core.exceptions.AbstractException.ApplicationsExceptionBody;
import com.abacogroup.agri.applicationforms.pua.core.model.dto.*;
import com.abacogroup.agri.applicationforms.pua.core.model.dto.PlotRecord.Declaration;
import com.abacogroup.agri.applicationforms.pua.services.BancheDatiService;
import com.abacogroup.agri.applicationforms.pua.services.CropPlanService;
import com.abacogroup.agri.applicationforms.pua.services.EffluentCrudService;
import com.abacogroup.agri.applicationforms.pua.services.OrganicFertilizerSpreadingDeclarationService;
import com.abacogroup.agri.applicationforms.pua.services.common.ApplicationFacadeService;
import com.abacogroup.agri.applicationforms.pua.util.CommonConstants;
import com.abacogroup.agri.applicationforms.pua.util.GenericUtility;
import com.abacogroup.agri.applicationforms.pua.util.GenericUtility.NumberPattern;
import com.abacogroup.applicationworkflowsdk.model.io.output.ApplicationDetailsPublicDTO;
import com.abacogroup.dropwizard.auth.sso2.Sso2Client;
import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import io.dropwizard.auth.Auth;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.parameters.RequestBody;
import jakarta.validation.constraints.NotNull;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.core.Response.Status;

import java.math.BigDecimal;
import java.time.Instant;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.util.*;
import java.util.stream.Collectors;

/**
 * @author Emanuele Crocilla
 */
public class OrganicFertilizerSpreadingDeclarationResources extends AGenericPuaResources {

	public OrganicFertilizerSpreadingDeclarationResources(
			ApplicationFormsModuleConfiguration configuration,
			ApplicationFacadeService applicationFacadeService,
			OrganicFertilizerSpreadingDeclarationService organicFertilizerSpreadingDeclarationService,
			EffluentCrudService effluentService,
			BancheDatiService bancheDatiService,
			CropPlanService cropPlanService,
			Sso2Client sso2Client) {

		super(configuration, sso2Client);

		this.applicationFacadeService = applicationFacadeService;
		this.organicFertilizerSpreadingDeclarationService = organicFertilizerSpreadingDeclarationService;
		this.effluentService = effluentService;
		this.bancheDatiService = bancheDatiService;
		this.cropPlanService = cropPlanService;
	}

	@GET
	@Path("/{applicationId}/fert-spreading-declaration/{id}")
	public Response get(
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "Current Tenant") @NotNull @PathParam("tenant") String tenant,
			@Parameter(description = "The application id") @NotNull @PathParam("applicationId") Long applicationId,
			@Parameter(description = "The declatation id") @NotNull @PathParam("id") Long id
	) {

		OrganicFertilizerSpreadingDeclarationDTO dto = null;

		try {

			dto = organicFertilizerSpreadingDeclarationService.get(user, tenant, applicationId, id);

			ApplicationDetailsPublicDTO applicationDetailsPublicDTO =
					applicationFacadeService.callForApplicationDetails(tenant, applicationId, user, Locale.ITALIAN.getLanguage());

			Long partyId = applicationDetailsPublicDTO.getPartyId();
			if (partyId.equals(dto.getPartyId())) {
				dto.setPartyId(null);
			}

		} catch (ObjectNotFoundRuntimeException e) {
			return Response.noContent().build();
		}

		return Response.ok(dto).build();
	}

	@GET
	@Path("/{applicationId}/fert-spreading-declarations")
	public Response getAll(
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "Current Tenant") @NotNull @PathParam("tenant") String tenant,
			@Parameter(description = "The application id") @NotNull @PathParam("applicationId") Long applicationId) {

		List<OrganicFertilizerSpreadingDeclarationDTO> dtos = null;

		try {

			dtos = organicFertilizerSpreadingDeclarationService.getAll(user, tenant, applicationId);

			ApplicationDetailsPublicDTO applicationDetailsPublicDTO =
					applicationFacadeService.callForApplicationDetails(tenant, applicationId, user, Locale.ITALIAN.getLanguage());

			Long partyId = applicationDetailsPublicDTO.getPartyId();
			dtos.forEach((dto) -> {
				if (partyId.equals(dto.getPartyId())) {
					dto.setPartyId(null);
				}
			});

		} catch (ObjectNotFoundRuntimeException e) {
			return Response.ok(Collections.emptyList()).build();
		}

		return Response.ok(dtos).build();
	}

	@GET
	@Path("/{applicationId}/fert-spreading-declarations/import-organic-fert-gias")
	public Response moveOrganicFertToProtocolla(
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "Current Tenant") @NotNull @PathParam("tenant") String tenant,
			@Parameter(description = "The application id") @NotNull @PathParam("applicationId") Long applicationId) {
		
		try {
		
			organicFertilizerSpreadingDeclarationService.addOrganicFert(user, tenant, applicationId);
			return Response.ok().build();
		
		} catch (ObjectNotFoundRuntimeException e) {
			return Response.ok(Collections.emptyList()).build();
		} catch (Exception e) {
			return Response.status(Status.BAD_REQUEST)
					.entity(new ApplicationsExceptionBody("ORGANIC_FERT_GIAS_ERR", e.getMessage())).build();
		}
	}

	@GET
	@Path("/{applicationId}/fert-spreading-declarations/remove-organic-fert-gias")
	public Response removeOrganicFertToGias(
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "Current Tenant") @NotNull @PathParam("tenant") String tenant,
			@Parameter(description = "The application id") @NotNull @PathParam("applicationId") Long applicationId) {
		
		try {
			organicFertilizerSpreadingDeclarationService.removeOrganicFert(user, tenant, applicationId);
			return Response.ok().build();
			
		} catch (ObjectNotFoundRuntimeException e) {
			return Response.ok(Collections.emptyList()).build();
		} catch (Exception e) {
			return Response.status(Status.BAD_REQUEST)
					.entity(new ApplicationsExceptionBody("ORGANIC_FERT_GIAS_ERR", e.getMessage())).build();
		}
	}

	@POST
	@Path("/{applicationId}/fert-spreading-declaration")
	public Response add(
			@Auth User user,
			@NotNull @RequestBody OrganicFertilizerSpreadingDeclarationDTO payload,
			@Parameter(description = "Current Tenant") @NotNull @PathParam("tenant") String tenantId,
			@Parameter(description = "The application id") @NotNull @PathParam("applicationId") Long applicationId,
			@Parameter(description = "The campaign year") @NotNull @QueryParam("campaignYear") Integer campaignYear,
			@Parameter(description = "The form config id") @NotNull @QueryParam("formConfigId") Long formConfigId,
			@Parameter(description = "The compile status identifier") @QueryParam("compileStatusIdentifier") String compileStatusIdentifier
	) {

		ApplicationDetailsPublicDTO applicationDetailsPublicDTO =
				applicationFacadeService.callForApplicationDetails(tenantId, applicationId, user, Locale.ITALIAN.getLanguage());

		long rightNow = Calendar.getInstance().getTimeInMillis();
		Instant instantRightNow = Instant.ofEpochMilli(rightNow);
		OffsetDateTime dateTimeRightNow = instantRightNow.atOffset(ZoneOffset.UTC);

		payload.setApplicationId(applicationId);
		organicFertilizerSpreadingDeclarationService.completeSpreadingEffluentsAndFrequencies(user, tenantId, payload);

		payload.setId(0L);// temporary id

		boolean isMyCompany = false;

		if (null == payload.getPartyId()) {
			Long partyId = applicationDetailsPublicDTO.getPartyId();
			payload.setPartyId(partyId);
			isMyCompany = true;
		}

		payload.setUserIdInsert(user.getUserId());
		payload.setDtInsert(dateTimeRightNow);
		payload.setDtDelete(CommonConstants.FAR_OFF_DATE);

		Long businessId = payload.getPartyId();
		String version = payload.getCropPlanVersion();

		for (var landuse : payload.getLanduses()) {
			landuse.setUserIdInsert(user.getUserId());
			landuse.setDtInsert(dateTimeRightNow);
			landuse.setDtDelete(CommonConstants.FAR_OFF_DATE);
		}

		List<PlotRecord> plotRecords = cropPlanService.getPlotCropPlans(user, tenantId, businessId, campaignYear, null/*declCode*/, version);

		// check if the PlotRecord.domainZoneId exists 
		PlotRecord prCheck = null;
		for (PlotRecord plotRecord : plotRecords) {
			if (plotRecord.getDomainZoneId().equalsIgnoreCase(payload.getSectorCode())) {
				prCheck = plotRecord;
				break;
			}
		}
		if (prCheck == null) {
			new ObjectNotFoundRuntimeException("PlotRecord.domainZoneId = " + payload.getSectorCode() + " not found ");
		}

		solveOrganicFertilizerSpreadingDeclarationData(payload, plotRecords);

		OrganicFertilizerSpreadingDeclarationDTO res =
				organicFertilizerSpreadingDeclarationService.insert(user, tenantId, applicationId, formConfigId, compileStatusIdentifier, payload);

		// for local company must return partyId as null
		if (isMyCompany) {
			res.setPartyId(null);
		}

		return Response.ok(res).build();
	}

	@PUT
	@Path("/{applicationId}/fert-spreading-declaration/{id}")
	public Response update(
			@Auth User user,
			@NotNull @RequestBody OrganicFertilizerSpreadingDeclarationDTO payload,
			@Parameter(description = "Current Tenant") @NotNull @PathParam("tenant") String tenantId,
			@Parameter(description = "The application id") @NotNull @PathParam("applicationId") Long applicationId,
			@Parameter(description = "The campaign year") @NotNull @QueryParam("campaignYear") Integer campaignYear,
			@Parameter(description = "The form config id") @NotNull @QueryParam("formConfigId") Long formConfigId,
			@Parameter(description = "The compile status identifier") @QueryParam("compileStatusIdentifier") String compileStatusIdentifier,
			@Parameter(description = "The declatation id") @NotNull @PathParam("id") Long declatationId
	) {

		payload.setId(declatationId);
		payload.setApplicationId(applicationId);
		organicFertilizerSpreadingDeclarationService.completeSpreadingEffluentsAndFrequencies(user, tenantId, payload);
		payload.setUserIdInsert(user.getUserId());
		payload.setDtDelete(CommonConstants.FAR_OFF_DATE);

		payload.getLanduses().forEach(landUse -> {
			landUse.setUserIdInsert(user.getUserId());
			landUse.setDtDelete(CommonConstants.FAR_OFF_DATE);
		});

		ApplicationDetailsPublicDTO applicationDetailsPublicDTO =
				applicationFacadeService.callForApplicationDetails(tenantId, applicationId, user, Locale.ITALIAN.getLanguage());

		boolean isMyCompany = false;

		if (null == payload.getPartyId()) {
			Long partyId = applicationDetailsPublicDTO.getPartyId();
			payload.setPartyId(partyId);
			isMyCompany = true;
		}

		Long businessId = payload.getPartyId();
		String version = payload.getCropPlanVersion();

		List<PlotRecord> plotRecords = cropPlanService.getPlotCropPlans(user, tenantId, businessId, campaignYear, null/*declCode*/, version);

		// check if the PlotRecord.domainZoneId exists 
		PlotRecord prCheck = null;
		for (PlotRecord plotRecord : plotRecords) {
			if (plotRecord.getDomainZoneId().equalsIgnoreCase(payload.getSectorCode())) {
				prCheck = plotRecord;
				break;
			}
		}
		if (prCheck == null) {
			new ObjectNotFoundRuntimeException("PlotRecord.domainZoneId = " + payload.getSectorCode() + " not found ");
		}

		solveOrganicFertilizerSpreadingDeclarationData(payload, plotRecords);

		OrganicFertilizerSpreadingDeclarationDTO res =
				organicFertilizerSpreadingDeclarationService.update(user, tenantId,
						applicationId, formConfigId, compileStatusIdentifier, payload);

		// for local company must return partyId as null
		if (isMyCompany) {
			res.setPartyId(null);
		}

		return Response.ok(res).build();
	}

	@DELETE
	@Path("/{applicationId}/fert-spreading-declaration/{id}")
	public void delete(
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "Current Tenant") @NotNull @PathParam("tenant") String tenantId,
			@Parameter(description = "The application id") @NotNull @PathParam("applicationId") Long applicationId,
			@Parameter(description = "The form config id") @NotNull @QueryParam("formConfigId") Long formConfigId,
			@Parameter(description = "The compile status identifier") @QueryParam("compileStatusIdentifier") String compileStatusIdentifier,
			@Parameter(description = "The declatation id") @NotNull @PathParam("id") Long id) {

		organicFertilizerSpreadingDeclarationService.delete(user, tenantId, applicationId, formConfigId, compileStatusIdentifier, id);
	}

	@GET
	@Path("/{applicationId}/effluents")
	public Response getAllEffluents(
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "Current Tenant") @NotNull @PathParam("tenant") String tenant,
			@Parameter(description = "The application id") @NotNull @PathParam("applicationId") Long applicationId) {

		//		List<EffluentDTO> dtos = null;
		List<Effluent> res = null;

		try {

			// dtos = effluentService.getAll(user, tenant, applicationId);

			res = bancheDatiService.getEffluents(user, tenant);

		} catch (ObjectNotFoundRuntimeException e) {
			return Response.ok(Collections.emptyList()).build();
		}

		return Response.ok(res /*dtos*/).build();
	}

	@GET
	@Path("/{applicationId}/effluents/search/fertilizer-type")
	public Response getAllEffluents(
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "Current Tenant") @NotNull @PathParam("tenant") String tenant,
			@Parameter(description = "The application id") @NotNull @PathParam("applicationId") Long applicationId,
			@Parameter(description = "The fertilizerType snippet to search") @NotNull @QueryParam("filter") String filter,
			@Parameter(description = "The infinite list key") @QueryParam("nextKey") String nextKey
	) {

		InfiniteListResults<EffluentDTO> dtos = null;

		try {

			dtos = effluentService.searchInFertilizerType(user, tenant, applicationId, filter, nextKey);

		} catch (ObjectNotFoundRuntimeException e) {
			return Response.ok(Collections.emptyList()).build();
		}

		return Response.ok(dtos).build();
	}

	@POST
	@Path("/{applicationId}/effluents/search/type-codes")
	public Response getAllEffluents(
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "Current Tenant") @NotNull @PathParam("tenant") String tenant,
			@Parameter(description = "The application id") @NotNull @PathParam("applicationId") Long applicationId,
			@NotNull @RequestBody Map<String, List<String>> codes
	) {

		List<EffluentDTO> dtos = null;

		try {
			List<String> typeCodes = codes.getOrDefault("codes", Arrays.asList(""));
			List<String> trimmedTypeCodes = new ArrayList<>(typeCodes.size());
			typeCodes.forEach((typeCode) -> trimmedTypeCodes.add((typeCode != null) ? typeCode.trim() : typeCode));
			dtos = effluentService.getByTypeCodes(user, tenant, applicationId, trimmedTypeCodes);

		} catch (ObjectNotFoundRuntimeException e) {
			return Response.ok(Collections.emptyList()).build();
		}

		return Response.ok(dtos).build();
	}

	private void solveOrganicFertilizerSpreadingDeclarationData(@NotNull OrganicFertilizerSpreadingDeclarationDTO payload, List<PlotRecord> plotRecords) {

		long hectarPartialCalculated = 0;
		Double usedAreaHects = null; //calcolato in questo modo: round((plotAreaSqm * areaPerc)/100)
		String plotTotalHectar = null;
		String plotDescription = null;
		int landUsePlotId = 0;
		List<PlotRecord> filteredPlotRecords = null;
		PlotRecord plotRecord = null;

		var plotRecordsMap = plotRecords.stream().collect(Collectors.groupingBy(PlotRecord::getPlotId));

		for (OrganicFertilizerSpreadingDeclarationLanduseDTO landuse : payload.getLanduses()) {

			landUsePlotId = Integer.valueOf(landuse.getPlotId());
			filteredPlotRecords = plotRecordsMap.get(landUsePlotId);

			plotRecord = filteredPlotRecords != null && !filteredPlotRecords.isEmpty() ? filteredPlotRecords.get(0) : null;

			if (plotRecord != null && plotRecord.getPlotId() == landUsePlotId) {

				Declaration declaration = plotRecord.getDecls().get(0);

				hectarPartialCalculated = Math.round(plotRecord.getAreaSqm() * declaration.getAreaPerc() / 100);
				usedAreaHects = Double.valueOf(hectarPartialCalculated) / 10000;
				plotTotalHectar = GenericUtility.formatNumbAndGetAsString(usedAreaHects, NumberPattern.PATTERN_DECIMAL);
				plotDescription = declaration.getLanduse().getDescription() + " Ha: " + plotTotalHectar;
				landuse.setPlotDescription(plotDescription);
				landuse.setPlotTotalHectar(BigDecimal.valueOf(usedAreaHects));
				landuse.setLandUseCode(declaration.getLanduse().getCode());
				landuse.setLandUseDescription(declaration.getLanduse().getDescription());
				landuse.setPlotAreaPerc(declaration.getAreaPerc());
				landuse.setPlotAreaSqm(plotRecord.getAreaSqm());
				landuse.setDeclarationCode(declaration.getDeclCode());
			} else {
				throw new RuntimeException("Cannot find PlotId = " + landUsePlotId);
			}
		}
	}
}
