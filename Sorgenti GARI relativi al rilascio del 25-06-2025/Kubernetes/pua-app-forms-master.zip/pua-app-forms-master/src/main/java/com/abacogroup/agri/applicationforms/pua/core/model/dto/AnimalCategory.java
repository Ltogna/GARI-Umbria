package com.abacogroup.agri.applicationforms.pua.core.model.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 
 * @author Emanuele Crocilla
 * 
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AnimalCategory {
    private String genreCode;
    private String specieCode;
    private String code;
    private String productionCode;
    private String decription;
    private Double averageWeight;
    private Double nitrogenPV;
}
