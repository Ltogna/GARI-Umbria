package com.abacogroup.agri.applicationforms.pua.util;

import java.lang.reflect.Field;

/**
 * 
 * @author Emanuele Crocilla
 *
 */
public final class Cloner {

	private Cloner() {
	}

	@SuppressWarnings("unchecked")
	public static <T> T clone(T original) {
		try {
			Class<?> clazz = original.getClass();
			T clone = (T) clazz.getDeclaredConstructor().newInstance();
			for (Field field : clazz.getDeclaredFields()) {
				field.setAccessible(true);
				Object value = field.get(original);
				field.set(clone, value);
			}
			return clone;
		} catch (Exception e) {
			throw new RuntimeException("Cloning failed", e);
		}

	}
}
