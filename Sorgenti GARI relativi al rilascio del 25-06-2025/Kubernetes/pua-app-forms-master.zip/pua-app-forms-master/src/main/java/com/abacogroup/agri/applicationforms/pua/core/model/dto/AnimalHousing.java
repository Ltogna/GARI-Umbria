package com.abacogroup.agri.applicationforms.pua.core.model.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 
 * @author Emanuele Crocilla
 * 
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AnimalHousing {

    private String genreCode;
    private String specieCode;
    private String categoryCode;
    private String productionCode;
    private String code;
    private String description;
    private Double sewageSludge; // liquame;
    private Double sewageSludgePct;
    private Double nitrogenSewage; // n liq
    private Double nitrogenShovellable; // m Pal
    private Double hay; // paglia;
    private Double shovellableMc;// palabielMc;
    private Double shovellableT;// palabielT;
}
