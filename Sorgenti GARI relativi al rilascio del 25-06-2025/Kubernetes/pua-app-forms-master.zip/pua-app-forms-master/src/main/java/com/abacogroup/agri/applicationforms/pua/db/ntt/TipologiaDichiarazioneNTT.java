package com.abacogroup.agri.applicationforms.pua.db.ntt;

import java.time.OffsetDateTime;
import java.util.Optional;

import com.abacogroup.agri.applicationforms.pua.db.ntt.applications.IIdRs;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 
 * @author Emanuele Crocilla
 *
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class TipologiaDichiarazioneNTT implements IIdRs<Long> {
	
    private Long pkid;
    private Long applicationId;
    private int year;
    private short flOrganicFert;
    private short flLivestocks;
    private OffsetDateTime dtInsert;
    private OffsetDateTime dtDelete;
    private String userIdInsert;
    private String userIdDelete;
	
    @Override
	public void setKey(Long id) {
		setPkid(id);
	}

	@Override 
	public Optional<Long> getKey() {
		return Optional.ofNullable(getPkid());
	}
}
