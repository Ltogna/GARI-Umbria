package com.abacogroup.agri.applicationforms.pua.core.exceptions;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.ws.rs.core.Response;
import lombok.extern.slf4j.Slf4j;

/**
 * 
 * @author Emanuele Crocilla
 *
 */
@Slf4j
public class AgriApplicationFormsRuntimeException extends AbstractException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private static final AgriApplicationFormsRuntimeException.ErrorBody BODY = new AgriApplicationFormsRuntimeException.ErrorBody();

	public AgriApplicationFormsRuntimeException(String message) {
		super(Response.Status.INTERNAL_SERVER_ERROR, BODY, message);
	}

	public AgriApplicationFormsRuntimeException(String message, Throwable e) {
		super(Response.Status.INTERNAL_SERVER_ERROR, BODY, message);
		log.error(e.getMessage(), e);
	}

	@Schema(name = "AgriApplicationFormsRuntimeExceptionErrorBody")
	public static class ErrorBody implements ExceptionErrorBody {
		private static final String ERR = "GENERIC_ERROR";

		@Override
		@Schema(allowableValues = ERR)
		public String getErrorCode() {
			return ERR;
		}
	}
}
