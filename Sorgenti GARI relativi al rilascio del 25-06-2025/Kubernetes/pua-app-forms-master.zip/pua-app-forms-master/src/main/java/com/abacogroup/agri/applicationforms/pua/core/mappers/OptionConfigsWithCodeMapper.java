package com.abacogroup.agri.applicationforms.pua.core.mappers;

import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import com.abacogroup.agri.applicationforms.pua.core.model.dto.OptionConfigsWithCodeDTO;
import com.abacogroup.agri.applicationforms.pua.db.ntt.OptionConfigsWithCodeNTT;

/**
 * @author Lorenzo Carli
 */
@Mapper(uses = AbsoluteDateMapper.class)
public interface OptionConfigsWithCodeMapper extends EntityMapper<OptionConfigsWithCodeDTO, OptionConfigsWithCodeNTT> {

	OptionConfigsWithCodeMapper INSTANCE = Mappers.getMapper(OptionConfigsWithCodeMapper.class);

	@InheritInverseConfiguration()
	OptionConfigsWithCodeDTO entityToDto(OptionConfigsWithCodeNTT entity);

	@Mapping(source = "id", target = "id")
	@Mapping(source = "optionCode", target = "option_code")
	@Mapping(source = "optionMinimumValue", target = "option_minimum_value")
	@Mapping(source = "optionRowMinimumEngageableValue", target = "option_row_minimum_engageable_value")
	@Mapping(source = "flFullEngagement", target = "fl_full_engagement")
	@Mapping(source = "dtValidityStart", target = "dt_validity_start")
	@Mapping(source = "dtValidityEnd", target = "dt_validity_end")
	@Mapping(source = "startYear", target = "start_year")
	@Mapping(source = "numberOfYears", target = "nr_of_years")
	@Mapping(source = "flAutoCompile", target = "fl_auto_compile")
	OptionConfigsWithCodeNTT dtoToEntity(OptionConfigsWithCodeDTO dto);

}
