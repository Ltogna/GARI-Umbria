package com.abacogroup.agri.applicationforms.pua.util;

import com.fasterxml.jackson.core.JsonProcessingException;

import jakarta.ws.rs.client.WebTarget;

/**
 * 
 * @author Emanuele Crocilla
 *
 */
public final class LogUtils {
	
	public static synchronized <P, R> void logDebugServiceData(org.slf4j.Logger log, P requestObj, R responseObj, 
			WebTarget usedWebClient, String path) {

		if (log.isDebugEnabled()) {

			try {
				
				String service = usedWebClient.getUri().getPath();
				
				log.debug("The request sent to '" + service + path + "' is: " + JsonUtils.convertToJson(requestObj, false));

				log.debug("The received response from '" + service + path + "' is: " + JsonUtils.convertToJson(responseObj, false));
			} 
			catch (JsonProcessingException e) {
				log.error("Unable to finish execution of LogUtils.logDebugServece method due an error", e);
			}
		}

	}
	public static synchronized <P, R> void logErrorServiceData(org.slf4j.Logger log, P requestObj, R responseObj,
			WebTarget usedWebClient, String path) {
			try {
				var reqObjJson = requestObj != null ? JsonUtils.convertToJson(requestObj, false) : null;
				var resObjJson = responseObj != null ? JsonUtils.convertToJson(responseObj, false) : null;

				String service = usedWebClient.getUri().getPath();

				log.debug("The request sent to '" + service + path + "' is: " + reqObjJson);

				log.debug("The received response from '" + service + path + "' is: " + resObjJson);
			}
			catch (JsonProcessingException e) {
				log.error("Unable to finish execution of LogUtils.logDebugServece method due an error", e);
			}

	}
}
