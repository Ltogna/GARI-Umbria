package com.abacogroup.agri.applicationforms.pua.util;

import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;

/**
 * 
 * @author Emanuele Crocilla
 *
 * @param <T>
 */
@NoArgsConstructor
@AllArgsConstructor
public class Value<T> {
	private T t;

	public T get() {
		return t;
	}

	public void set(T t) {
		this.t = t;
	}

	public boolean isNull() {
		return t == null;
	}
	
	public boolean compareContent(T c) {
		return c != null && t.equals(c);
	}
}
