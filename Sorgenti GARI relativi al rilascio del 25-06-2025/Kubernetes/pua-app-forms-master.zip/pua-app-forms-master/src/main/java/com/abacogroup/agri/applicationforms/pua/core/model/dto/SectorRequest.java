package com.abacogroup.agri.applicationforms.pua.core.model.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 
 * @author Emanuele Crocilla
 *
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Schema(description = "The Sector DTO")
public class SectorRequest {

	@Schema(description = "The codes")
    private List<String> codes;

	@Schema(description = "The filter")
    private String filter;

    @Schema(description = "The includeGeometries")
    @JsonProperty("include_geometries")
    private boolean includeGeometries;

    @Schema(description = "The nextKey")
    @JsonProperty("next_key")
    private String nextKey;
}
