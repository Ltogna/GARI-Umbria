package com.abacogroup.agri.applicationforms.pua.db.dao;

import com.abacogroup.agri.applicationforms.pua.core.exceptions.ObjectNotFoundRuntimeException;
import com.abacogroup.agri.applicationforms.pua.db.ntt.DeclarationsOnSectorsNTT;
import com.abacogroup.agri.applicationforms.pua.db.ntt.NoSpreadingPeriodNTT;
import com.abacogroup.agri.applicationforms.pua.services.common.FunctionalObject;
import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.customizer.BindBean;
import org.jdbi.v3.sqlobject.customizer.BindList;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;

import java.time.Instant;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.util.Calendar;
import java.util.List;

public interface NoSpreadingPeriodDAO extends IGenericPuaDAO<NoSpreadingPeriodNTT, Long> {

	@Override
	@SqlQuery("SELECT nextval('appfpua_no_spreading_periods_pkid_seq')")
	Long nextSequenceVal();

	@SqlQuery("""
			    SELECT * FROM appfpua_no_spreading_periods
			    WHERE application_id = :applicationId AND dt_delete > CURRENT_TIMESTAMP
			    ORDER BY pkid
			""")
	@RegisterBeanMapper(NoSpreadingPeriodNTT.class)
	List<NoSpreadingPeriodNTT> getByApplicationId(@Bind("applicationId") Long applicationId);

	@SqlQuery("""
			    SELECT * FROM appfpua_no_spreading_periods
			    WHERE pkid = :pkid AND dt_delete > CURRENT_TIMESTAMP
			""")
	@RegisterBeanMapper(NoSpreadingPeriodNTT.class)
	NoSpreadingPeriodNTT getById(@Bind("pkid") Long pkid);

	@SqlQuery("""
			    SELECT * FROM appfpua_no_spreading_periods
			    WHERE pkid = :pkid AND application_id = :applicationId AND dt_delete > CURRENT_TIMESTAMP
			""")
	@RegisterBeanMapper(NoSpreadingPeriodNTT.class)
	NoSpreadingPeriodNTT getByIdandApplicationId(@Bind("pkid") Long pkid, @Bind("applicationId") Long applicationId);

	@SqlQuery("SELECT * FROM appfpua_no_spreading_periods WHERE pkid IN (<ids>) AND dt_delete > §current_timestamp§")
	@RegisterBeanMapper(NoSpreadingPeriodNTT.class)
	List<NoSpreadingPeriodNTT> getByIds(@BindList("ids") List<Long> ids);

	@SqlUpdate("""
			 INSERT INTO appfpua_no_spreading_periods
			   (pkid, application_id, effluent, day_from, day_to, dt_insert, dt_delete, user_id_insert, user_id_delete)
			    VALUES (:pkid, :applicationId, :effluent, :dayFrom, :dayTo, :dtInsert, :dtDelete, :userIdInsert, :userIdDelete)
			""")
	void insert(@BindBean NoSpreadingPeriodNTT ntt);

	@SqlUpdate("""
			update appfpua_no_spreading_periods
			   set dt_delete=:dtDelete,
			       user_id_delete = :userIdDelete
			 where application_id=:applicationId 
			and pkid=:pkid 
			   and §current_timestamp§ between dt_insert and dt_delete 
			""")
	void expire(@Bind("applicationId") Long applicationId, @Bind("pkid") Long pkid, @Bind("dtDelete") OffsetDateTime dtDelete,
			@Bind("userIdDelete") String userIdDelete);

	default void upsert(NoSpreadingPeriodNTT nttToUpd) {

		// suppose that all ntts have the same application ID
		FunctionalObject<Long> applicationId = () -> nttToUpd != null ? nttToUpd.getApplicationId() : null;
		FunctionalObject<Long> nttId = () -> nttToUpd != null ? nttToUpd.getPkid() : null;

		if (nttToUpd != null && nttId.get() != null && this.countByPkId(nttId.get()) > 0) {

			String userIdInsert = nttToUpd.getUserIdInsert();
			long rightNow = Calendar.getInstance().getTimeInMillis();
			long rightNowMinusAMillis = rightNow - 1;

			Instant instantRightNow = Instant.ofEpochMilli(rightNow);
			Instant instantMinusAMillis = Instant.ofEpochMilli(rightNowMinusAMillis);

			OffsetDateTime dateTimeRightNow = instantRightNow.atOffset(ZoneOffset.UTC);
			OffsetDateTime dateTimeMinusAMillis = instantMinusAMillis.atOffset(ZoneOffset.UTC);

			nttToUpd.setDtInsert(dateTimeRightNow);

			useTransaction(dao -> {
				((NoSpreadingPeriodDAO) dao).expire(applicationId.get(), nttId.get(), dateTimeMinusAMillis, userIdInsert);
				nttToUpd.setPkid(nextSequenceVal());
				((NoSpreadingPeriodDAO) dao).insert(nttToUpd);
			});
		} else {

			throw new ObjectNotFoundRuntimeException("Unable to find application id = " + applicationId.get() + " and pkId = " + nttId.get());
		}
	}

	@SqlQuery("select count(*) from appfpua_no_spreading_periods where pkid = :pkid and dt_delete > §current_timestamp§")
	@RegisterBeanMapper(DeclarationsOnSectorsNTT.class)
	int countByPkId(@Bind("pkid") Long pkid);

	@SqlQuery("""
			    SELECT COUNT(*) FROM appfpua_no_spreading_periods
			    WHERE application_id = :applicationId
			      AND effluent = :effluent
			      AND dt_delete > CURRENT_TIMESTAMP
			""")
	int countByApplicationIdAndEffluent(@Bind("applicationId") Long applicationId, @Bind("effluent") String effluent);
}
