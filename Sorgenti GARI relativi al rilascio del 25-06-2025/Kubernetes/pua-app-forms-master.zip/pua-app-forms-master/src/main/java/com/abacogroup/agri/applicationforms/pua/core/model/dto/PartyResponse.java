package com.abacogroup.agri.applicationforms.pua.core.model.dto;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

/**
 * 
 * @author Emanuele Crocilla
 *
 */
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
@Schema(description = "The PartyResponse")
@JsonIgnoreProperties(ignoreUnknown = true)
public class PartyResponse {

	@JsonProperty("id")
	private int id;

	@JsonProperty("partyType")
	private String partyType;

	@JsonProperty("gender")
	private String gender;

	@JsonProperty("lastName")
	private String lastName;

	@JsonProperty("firstName")
	private String firstName;

	@JsonProperty("taxCode")
	private String taxCode;

	@JsonProperty("vatNumber")
	private String vatNumber;

	@JsonProperty("code")
	private String code;

	@JsonProperty("legalStatus")
	private String legalStatus;

	@JsonProperty("birthDate")
	private String birthDate;

	@JsonProperty("deathDate")
	private String deathDate;

	@JsonProperty("birthMunicipality")
	private String birthMunicipality;

	@JsonProperty("birthMunicipalityDetail")
	private MunicipalityDetail birthMunicipalityDetail;

	@JsonProperty("nationality")
	private String nationality;

	@JsonProperty("addressResidential")
	private Address addressResidential;

	@JsonProperty("addressHome")
	private Address addressHome;

	@JsonProperty("addressBilling")
	private Address addressBilling;

	@JsonProperty("tags")
	private List<Tag> tags;

	@JsonProperty("archived")
	private boolean archived;

	@JsonProperty("externalSource")
	private ExternalSource externalSource;

	@JsonIgnoreProperties(ignoreUnknown = true)
	public static class MunicipalityDetail {
		@JsonProperty("code")
		private String code;

		@JsonProperty("tenantId")
		private String tenantId;

		@JsonProperty("districtCode")
		private String districtCode;

		@JsonProperty("shortDescr")
		private String shortDescr;

		@JsonProperty("active")
		private boolean active;

		@JsonProperty("i18nName")
		private String i18nName;

		@JsonProperty("district")
		private District district;

		// Getters and setters...

		@JsonIgnoreProperties(ignoreUnknown = true)
		public static class District {
			@JsonProperty("code")
			private String code;

			@JsonProperty("tenantId")
			private String tenantId;

			@JsonProperty("regionCode")
			private String regionCode;

			@JsonProperty("shortDescr")
			private String shortDescr;

			@JsonProperty("active")
			private boolean active;

			@JsonProperty("i18nName")
			private String i18nName;

			@JsonProperty("region")
			private Region region;

			// Getters and setters...

			@JsonIgnoreProperties(ignoreUnknown = true)
			public static class Region {
				@JsonProperty("code")
				private String code;

				@JsonProperty("tenantId")
				private String tenantId;

				@JsonProperty("countryCode")
				private String countryCode;

				@JsonProperty("shortDescr")
				private String shortDescr;

				@JsonProperty("active")
				private boolean active;

				@JsonProperty("i18nName")
				private String i18nName;

				@JsonProperty("country")
				private Country country;

				// Getters and setters...

				@JsonIgnoreProperties(ignoreUnknown = true)
				public static class Country {
					@JsonProperty("code")
					private String code;

					@JsonProperty("tenantId")
					private String tenantId;

					@JsonProperty("active")
					private boolean active;

					@JsonProperty("i18nName")
					private String i18nName;
				}
			}
		}
	}

	@JsonIgnoreProperties(ignoreUnknown = true)
	public static class Address {
		@JsonProperty("id")
		private int id;

		@JsonProperty("municipality")
		private String municipality;

		@JsonProperty("locality")
		private String locality;

		@JsonProperty("street")
		private String street;

		@JsonProperty("houseNumber")
		private String houseNumber;

		@JsonProperty("postcode")
		private String postcode;

		@JsonProperty("details")
		private String details;

		@JsonProperty("note")
		private String note;

		@JsonProperty("municipalityI18nCode")
		private String municipalityI18nCode;

		@JsonProperty("municipalityDetail")
		private MunicipalityDetail municipalityDetail;
	}

	@JsonIgnoreProperties(ignoreUnknown = true)
	public static class Tag {
		@JsonProperty("id")
		private int id;

		@JsonProperty("code")
		private String code;

		@JsonProperty("i18nCode")
		private String i18nCode;
	}

	@JsonIgnoreProperties(ignoreUnknown = true)
	public static class ExternalSource {
		@JsonProperty("code")
		private String code;

		@JsonProperty("allowManual")
		private boolean allowManual;

		@JsonProperty("description")
		private String description;
	}
}
