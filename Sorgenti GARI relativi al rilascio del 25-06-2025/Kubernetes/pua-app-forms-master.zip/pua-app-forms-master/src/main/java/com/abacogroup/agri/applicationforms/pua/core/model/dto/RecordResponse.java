package com.abacogroup.agri.applicationforms.pua.core.model.dto;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

/**
 * 
 * @author Emanuele Crocilla
 *
 * @param <T>
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@Data
public class RecordResponse<T> {

	@JsonProperty("records")
	private List<T> records;

	@JsonProperty("nextKey")
	private String nextKey;

	@JsonProperty("count")
	private int count;
 
}
