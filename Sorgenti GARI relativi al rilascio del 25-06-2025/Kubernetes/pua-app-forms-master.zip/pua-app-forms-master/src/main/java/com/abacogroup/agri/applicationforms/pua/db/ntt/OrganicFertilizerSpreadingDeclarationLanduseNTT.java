package com.abacogroup.agri.applicationforms.pua.db.ntt;

import java.math.BigDecimal;
import java.time.OffsetDateTime;
import java.util.Optional;

import com.abacogroup.agri.applicationforms.pua.db.ntt.applications.IIdRs;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 
 * @author Emanuele Crocilla
 *
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class OrganicFertilizerSpreadingDeclarationLanduseNTT implements IIdRs<Long> {

	private Long pkid;
	private Long appfpuaOrganicFertSpreadingDeclarationPkid;
	private String landUseCode;
	private String landUseDescription;
	private String plotId;
	private String plotDescription;
	private String declarationCode;
	private Integer plotAreaSqm;
	private BigDecimal plotAreaPerc;
	private BigDecimal plotTotalHectar;
	private OffsetDateTime dtInsert;
	private OffsetDateTime dtDelete;
	private String userIdInsert;
	private String userIdDelete;

	@Override
	public void setKey(Long id) {
		setPkid(id);
	}

	@Override 
	public Optional<Long> getKey() {
		return Optional.ofNullable(getPkid());
	}
}
