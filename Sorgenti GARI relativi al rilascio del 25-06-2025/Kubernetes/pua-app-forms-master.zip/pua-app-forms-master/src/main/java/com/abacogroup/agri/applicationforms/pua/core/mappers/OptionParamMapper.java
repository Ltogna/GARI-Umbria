package com.abacogroup.agri.applicationforms.pua.core.mappers;

import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import com.abacogroup.agri.applicationforms.pua.core.model.dto.OptionParamDTO;
import com.abacogroup.agri.applicationforms.pua.db.ntt.OptionParamNTT;
import com.abacogroup.jdbi.mapper.AbsoluteDateMapper;

/**
 * @author Mattia Perini
 */
@Mapper(uses = AbsoluteDateMapper.class)
public interface OptionParamMapper extends EntityMapper<OptionParamDTO, OptionParamNTT> {

    OptionParamMapper INSTANCE = Mappers.getMapper(OptionParamMapper.class);


    @InheritInverseConfiguration()
    OptionParamDTO entityToDto(OptionParamNTT entity);

    @Mapping(source = "optionConfigId", target = "option_config_id")
    @Mapping(source = "attributeName", target = "attribute_name")
    @Mapping(source = "attributeValue", target = "attribute_value")
    OptionParamNTT dtoToEntity(OptionParamDTO dto);

}
