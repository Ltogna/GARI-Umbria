package com.abacogroup.agri.applicationforms.pua.core.model.dto;

import com.abacogroup.agri.applicationforms.pua.util.JsonUtils;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.core.JsonProcessingException;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AttivitaOperazioniQdC {

	@JsonProperty("codice")
	private Long codice;

	@JsonProperty("flag_cancellazione")
	private Boolean flagCancellazione;

	@JsonProperty("utente_ultima_modifica")
	private String utenteUltimaModifica;

	@JsonProperty("data")
	private Date data;

	@JsonProperty("tipo_operazione")
	private Integer tipoOperazione;

	@JsonProperty("regolamento_cod")
	private Integer regolamentoCod;

	@JsonProperty("impianti")
	private List<ImpiantiAttivitaOperazioniQdC> impianti;

	@JsonProperty("prodotti")
	private List<ProdottiAttivitaOperazioniQdC> prodotti;

	@Data
	@Builder
	@AllArgsConstructor
	@NoArgsConstructor
	public static class ImpiantiAttivitaOperazioniQdC {

		@JsonProperty("plot_id")
		private String plotId;

		@JsonProperty("superficie_trattata")
		private BigDecimal superficieTrattata;

	}

	@Data
	@Builder
	@AllArgsConstructor
	@NoArgsConstructor
	public static class ProdottiAttivitaOperazioniQdC {

		@JsonProperty("codice")
		private String codice;

		@JsonProperty("quantita")
		private Double quantita;

		@JsonProperty("udm")
		private String udm;

	}
}
