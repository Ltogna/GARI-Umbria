package com.abacogroup.agri.applicationforms.pua.core.mappers;

import java.math.BigDecimal;
import java.math.RoundingMode;

import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;
import org.mapstruct.factory.Mappers;

import com.abacogroup.agri.applicationforms.pua.core.model.dto.DeclOnCropsPrevEffluentsDTO;
import com.abacogroup.agri.applicationforms.pua.db.ntt.DeclOnCropsPrevEffluentsNTT;
import com.abacogroup.jdbi.mapper.AbsoluteDateMapper;

/**
 * 
 * @author Emanuele Crocilla
 *
 */
@Mapper(uses = AbsoluteDateMapper.class)
public interface DeclOnCropsPrevEffluentsMapper extends EntityMapper<DeclOnCropsPrevEffluentsDTO, DeclOnCropsPrevEffluentsNTT> {

	DeclOnCropsPrevEffluentsMapper INSTANCE = Mappers.getMapper(DeclOnCropsPrevEffluentsMapper.class);

	@InheritInverseConfiguration()
	@Mapping(source = "previousEffluentOnCropsId", target = "id")
	@Mapping(source = "appfpuaDeclOnCropsPkid", target = "parentId")
	DeclOnCropsPrevEffluentsDTO entityToDto(DeclOnCropsPrevEffluentsNTT entity);

	@Mapping(source = "id", target = "previousEffluentOnCropsId")
	@Mapping(source = "parentId", target = "appfpuaDeclOnCropsPkid")
	@Mapping(source = "quantity", target = "quantity", qualifiedByName = "truncateToFourDecimals")
	@Mapping(source = "nitrogenContent", target = "nitrogenContent", qualifiedByName = "truncateToFourDecimals")
	@Mapping(source = "reduction", target = "reduction", qualifiedByName = "truncateToFourDecimals")
	@Mapping(source = "residualNitrogen", target = "residualNitrogen", qualifiedByName = "truncateToFourDecimals")
	DeclOnCropsPrevEffluentsNTT dtoToEntity(DeclOnCropsPrevEffluentsDTO dto);
	
	@Named("truncateToFourDecimals")
	default BigDecimal truncateToFourDecimals(BigDecimal in) {
		return in.setScale(4, RoundingMode.DOWN);
	}

}
