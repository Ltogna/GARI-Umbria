package com.abacogroup.agri.applicationforms.pua.bundles.processor.attachmenttypes;

import com.abacogroup.agri.applicationforms.pua.bundles.model.attachmenttypes.BundleAttachmentTypesMessage;
import com.abacogroup.agri.applicationforms.pua.core.exceptions.ObjectNotFoundRuntimeException;
import com.abacogroup.agri.applicationforms.pua.core.model.attachmenttypes.BundleAttachmentTypesInDTO;
import com.abacogroup.agri.applicationforms.pua.core.model.dto.AttachmentTypeDTO;
import com.abacogroup.agri.applicationforms.pua.services.AttachmentTypesCrudService;

import lombok.extern.slf4j.Slf4j;

/**
 * @author Alexandru Paraschiv
 */
@Slf4j
public class AttachmentTypesBundleWorker {

	protected final AttachmentTypesCrudService attachmentTypesCrudService;

	public AttachmentTypesBundleWorker(AttachmentTypesCrudService attachmentTypesCrudService) {
		this.attachmentTypesCrudService = attachmentTypesCrudService;
	}

	public AttachmentTypesCrudService exposeAttachmentTypesCrudService() {
		return this.attachmentTypesCrudService;
	}

	public void upsert(String tenantId, BundleAttachmentTypesMessage message) {
		log.info("AttachmentTypesBundleWorker: processing file with tenant {}", tenantId);
		message.getAttachmentTypes()
				.stream()
				.forEachOrdered(cat -> {
					try {
						update(tenantId, cat);
					} catch (ObjectNotFoundRuntimeException exp) {
						log.info("category not found, inserting it");
						insert(tenantId, cat);
					}
				});
	}

	public void delete(String tenantId, BundleAttachmentTypesMessage at) {
		log.info("AttachmentTypesBundleWorker: deleting file with tenant {}", tenantId);
		at.getAttachmentTypes()
				.forEach(x -> {
					try {
						log.info("working on {}", x.getTypeCode());
						attachmentTypesCrudService.findOptByCodeAndAttachmentGroupCode(tenantId, x.getTypeCode(), x.getAttachmentGroupCode())
								.ifPresent(c -> {
									log.info("found attachemnt type with id {}. deleting it", c.getPkid());
									attachmentTypesCrudService.delete(c.getPkid());
									attachmentTypesCrudService.deleteAttachmentTypesI18N(tenantId, c.getTypeCode());
								});
					} catch (Exception e) {
						log.error("error deleting attachment type..", e);
					}
				});
	}

	private void update(String tenantId, BundleAttachmentTypesInDTO at) throws ObjectNotFoundRuntimeException {
		var existentAttachmentType = attachmentTypesCrudService.findByCodeAndAttachmentGroupCode(tenantId, at.getTypeCode(), at.getAttachmentGroupCode());
		log.info("AttachmentTypesBundleWorker: updating attachmentType with tenant {} and code {} and groupCode {}", tenantId, at.getTypeCode(), at.getAttachmentGroupCode());
		existentAttachmentType.setTenantId(tenantId);
		existentAttachmentType.setAttachmentGroupCode(at.getAttachmentGroupCode());
		attachmentTypesCrudService.update(existentAttachmentType.getPkid(), existentAttachmentType);
		attachmentTypesCrudService.deleteAttachmentTypesI18N(tenantId, at.getTypeCode());
		this.insertI18N(tenantId, at);
	}

	public void insertI18N(String tenantId, BundleAttachmentTypesInDTO at) {
		log.info("AttachmentTypesBundleWorker: inserting i18n with tenant {} and code {}", tenantId, at.getTypeCode());
		at.getI18n()
				.stream()
				.forEachOrdered(val -> attachmentTypesCrudService.insertAttachmentTypeI18N(tenantId,
						at.getTypeCode(),
						val.getLang(),
						val.getCode()));
	}

	public void insert(String tenantId, BundleAttachmentTypesInDTO at) {
		log.info("AttachmentTypesBundleWorker: inserting category with tenant {} and code {} and groupCode {}", tenantId, at.getTypeCode(), at.getAttachmentGroupCode());
		attachmentTypesCrudService.insert(AttachmentTypeDTO.builder()
						.attachmentGroupCode(at.getAttachmentGroupCode())
						.tenantId(tenantId)
						.typeCode(at.getTypeCode())
				.build());
		attachmentTypesCrudService.deleteAttachmentTypesI18N(tenantId, at.getTypeCode());
		this.insertI18N(tenantId, at);
	}

}
