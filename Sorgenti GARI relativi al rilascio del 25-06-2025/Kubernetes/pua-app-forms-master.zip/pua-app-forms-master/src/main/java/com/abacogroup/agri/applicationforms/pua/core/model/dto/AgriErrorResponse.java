package com.abacogroup.agri.applicationforms.pua.core.model.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class AgriErrorResponse {

	@JsonProperty("message")
	private String message;

	@JsonProperty("errore")
	private String errore;

	@JsonProperty("dati")
	private Object dati; // or a specific class if you know what it contains
}
