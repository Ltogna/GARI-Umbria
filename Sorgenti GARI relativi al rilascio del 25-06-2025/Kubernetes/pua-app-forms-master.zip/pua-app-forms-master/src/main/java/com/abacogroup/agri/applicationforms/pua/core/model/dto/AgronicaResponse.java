package com.abacogroup.agri.applicationforms.pua.core.model.dto;

import com.abacogroup.agri.applicationforms.pua.core.exceptions.AgronicaGenericException;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

/**
 * 
 * @author Emanuele Crocilla
 *
 * @param <T>
 * 
 * 
 * 
 * 
 * 
 */
@Data
public class AgronicaResponse<T> {
	
	@JsonProperty("message")
	private String message;

	@JsonProperty("errore")
	private String errore;

	@JsonProperty("dati")
	private T dati;

    @JsonIgnore
    public final void validate() {
        if ("OK".equals(message)) {
            return;
        }

        throw new AgronicaGenericException(errore);
    }
}
