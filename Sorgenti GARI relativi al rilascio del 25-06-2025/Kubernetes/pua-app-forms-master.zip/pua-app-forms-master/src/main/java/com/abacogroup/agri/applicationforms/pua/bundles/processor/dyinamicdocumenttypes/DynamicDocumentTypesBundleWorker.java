package com.abacogroup.agri.applicationforms.pua.bundles.processor.dyinamicdocumenttypes;

import java.io.IOException;
import java.util.Optional;

import com.abacogroup.agri.applicationforms.pua.bundles.model.dynamicdocumenttype.BundleDynamicDocumentTypesMessage;
import com.abacogroup.agri.applicationforms.pua.common.dynamidocument.DynamicDocumentService;
import com.abacogroup.agri.applicationforms.pua.core.exceptions.DynamicDocumentRuntimeException;
import com.abacogroup.dynamicdocuments.bean.DocumentDefinition;

import lombok.extern.slf4j.Slf4j;

/**
 * @author Gennaro Tamburrelli
 */
@Slf4j
public class DynamicDocumentTypesBundleWorker {

	protected final DynamicDocumentService appfPuaDynamicDocumentService;

	public DynamicDocumentTypesBundleWorker(DynamicDocumentService appfPuaDynamicDocumentService) {
		this.appfPuaDynamicDocumentService = appfPuaDynamicDocumentService;
	}

	public DynamicDocumentService exposeAPPFDynamicDocumentService() {
		return this.appfPuaDynamicDocumentService;
	}

	public void upsert(String tenantId, BundleDynamicDocumentTypesMessage message) {
		log.info("DynamicDocumentTypesBundleWorker: processing file with tenant {}", tenantId);
		message.getDocumentTypes()
				.stream()
				.forEachOrdered(docDef -> {
					try {
						Optional<DocumentDefinition> optDocDef = appfPuaDynamicDocumentService.getDocumentDefinitionByTenant(tenantId).stream()
								.sorted((x, y) -> x.getVersion().compareToIgnoreCase(y.getVersion()))
								.filter(x -> x.getCode().equals(docDef.getCode()))
								.findFirst();
						if (optDocDef.isPresent()) {
							log.info("DynamicDocumentTypesBundleWorker: updating document with tenant {}", tenantId);
						} else {
							log.info("DynamicDocumentTypesBundleWorker: inserting document with tenant {}", tenantId);
						}
						appfPuaDynamicDocumentService.saveDocumentType(tenantId, "BUNDLE", docDef);
					} catch (IOException e) {
						throw new DynamicDocumentRuntimeException(e.getMessage());
					}
				});

	}
}
