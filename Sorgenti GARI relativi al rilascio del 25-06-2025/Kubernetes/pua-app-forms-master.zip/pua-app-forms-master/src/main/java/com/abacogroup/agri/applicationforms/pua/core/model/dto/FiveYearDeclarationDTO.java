package com.abacogroup.agri.applicationforms.pua.core.model.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.time.OffsetDateTime;

/**
 * @author Emanuele Crocilla
 */
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
@Schema(description = "The FiveYearDeclaration DTO")
public class FiveYearDeclarationDTO {

	@JsonIgnore
	@JsonProperty(access = JsonProperty.Access.READ_ONLY)
	@Schema(description = "The pkid")
	private Long pkId;

	@JsonIgnore
	@JsonProperty(access = JsonProperty.Access.READ_ONLY)
	@Schema(description = "The application id")
	private Long applicationId;

	@Schema(description = "The five year declaration id")
	private Long id;

	@Schema(description = "The party id")
	private Long partyId;

	@Schema(description = "The sector code (municipality)")
	private String sectorCode;

	@Schema(description = "The block code (cadastral block)")
	private Integer blockCode;

	@Schema(description = "The parcel code (cadastral parcel)")
	private Integer parcelCode;

	@Schema(description = "The sub-parcel code (optional)")
	private String subParcelCode;

	@Schema(description = "The cadastral area in square meters")
	private Integer cadastralAreaSqm;

	@Schema(description = "The start date (format: yyyyMMdd)")
	private String dayFrom;

	@Schema(description = "The end date (format: yyyyMMdd)")
	private String dayTo;

	@Schema(description = "The utilized area in square meters")
	private Integer usedAreaSqm;

	@Schema(description = "The insert date")
	@JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ssXXX")
	@JsonProperty(access = JsonProperty.Access.READ_ONLY)
	private OffsetDateTime dtInsert;

	@Schema(description = "The logical deletion date")
	@JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ssXXX")
	@JsonProperty(access = JsonProperty.Access.READ_ONLY)
	private OffsetDateTime dtDelete;

	@Schema(description = "The user id which inserted this record")
	@JsonProperty(access = JsonProperty.Access.READ_ONLY)
	private String userIdInsert;

	@Schema(description = "The user id which deleted this record")
	@JsonProperty(access = JsonProperty.Access.READ_ONLY)
	private String userIdDelete;

	@Schema(description = "The party code (cuaa)")
	private String cuaa;

	@Schema(description = "The company name")
	private String company;
}

