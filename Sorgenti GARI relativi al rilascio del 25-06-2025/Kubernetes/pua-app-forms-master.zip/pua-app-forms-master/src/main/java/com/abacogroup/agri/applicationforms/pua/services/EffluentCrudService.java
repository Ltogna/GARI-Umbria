package com.abacogroup.agri.applicationforms.pua.services;

import static com.abacogroup.agri.applicationforms.pua.util.GenericUtility.throwNotImplementedException;
import static com.abacogroup.agri.applicationforms.pua.util.PagingParamsFactory.DEFAULT_LIMIT;
import static com.abacogroup.agri.applicationforms.pua.util.PagingParamsFactory.DEFAULT_PAGE_SIZE;

import java.time.OffsetDateTime;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.Optional;

import com.abacogroup.agri.applicationforms.pua.core.exceptions.ObjectNotFoundRuntimeException;
import com.abacogroup.agri.applicationforms.pua.core.mappers.EffluentMapper;
import com.abacogroup.agri.applicationforms.pua.core.model.dto.EffluentDTO;
import com.abacogroup.agri.applicationforms.pua.db.dao.EffluentDAO;
import com.abacogroup.agri.applicationforms.pua.db.ntt.EffluentNTT;
import com.abacogroup.agri.applicationforms.pua.services.common.ApplicationFacadeService;
import com.abacogroup.agri.applicationforms.pua.services.common.crud.AbstractCrudService;
import com.abacogroup.agri.applicationforms.pua.util.CommonConstants;
import com.abacogroup.agri.applicationforms.pua.util.GenericUtility;
import com.abacogroup.applicationworkflowsdk.model.io.output.ApplicationDetailsPublicDTO;
import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.jdbi.paging.InfiniteListResults;

import lombok.extern.slf4j.Slf4j;

/**
 * 
 * @author Emanuele Crocilla
 *
 */
@Slf4j
public class EffluentCrudService extends AbstractCrudService<EffluentNTT, Long, EffluentDTO, EffluentMapper, Void, EffluentDAO> {

	private final ApplicationFacadeService applicationFacadeService;
	
	public EffluentCrudService(
			EffluentDAO dao, 
			ApplicationFacadeService applicationFacadeService,
			EffluentMapper mapper) {
		
		super(dao, mapper);
		this.applicationFacadeService = applicationFacadeService;
	}

	public EffluentDTO get(User user, String tenant, Long applicationId, String typeCode) {

		try {
			
			if ( !"BUNDLE".equals(user.getUserId()) ) {
				
				ApplicationDetailsPublicDTO applicationDetailsPublicDTO = 
						applicationFacadeService.callForApplicationDetails(tenant, applicationId, user, Locale.ITALIAN.getLanguage());
				
				log.info(applicationDetailsPublicDTO.toString());
			}
			
			EffluentNTT ntt = dao.getByTypeCode(typeCode);

			if (ntt != null) {
				log.info("Retrieving of Effluent completed for tenant {} and typeCode {} ", tenant, typeCode);
				return returnOptionalRecord(Collections.singletonList(ntt)).get();
			}
		} 
		catch (Exception e) {
			String msg = GenericUtility.formatStr("Unable to complete 'get' method due an unhandled error for tenant {} and typeCode {} ", tenant, typeCode);
			log.error(msg, e);
			throw e;
		}
 
		String msg = GenericUtility.formatStr("Unable to find Effluent item with tenant = {} and typeCode = {} due unhandled error ", tenant, typeCode);
		ObjectNotFoundRuntimeException err = new ObjectNotFoundRuntimeException(msg);
		log.warn(msg, err);
		throw err;
	}
	
	public List<EffluentDTO> getAll(User user, String tenant, Long applicationId) {

		try {
			
			if ( !"BUNDLE".equals(user.getUserId()) ) {
				
				ApplicationDetailsPublicDTO applicationDetailsPublicDTO = 
						applicationFacadeService.callForApplicationDetails(tenant, applicationId, user, Locale.ITALIAN.getLanguage());
				
				log.info(applicationDetailsPublicDTO.toString());
			}
			
			List<EffluentNTT> ntts = dao.getAll();

			if (ntts != null && !ntts.isEmpty()) {
				log.info("Retrieving of Effluent completed for tenant {} ", tenant);
				return returnMappedList(ntts);
			}
		} 
		catch (Exception e) {
			String msg = GenericUtility.formatStr("Unable to complete 'get' method due an unhandled error for tenant {}", tenant);
			log.error(msg, e);
			throw e;
		}
 
		String msg = GenericUtility.formatStr("Unable to find Effluent item with tenant = {} due unhandled error ", tenant);
		ObjectNotFoundRuntimeException err = new ObjectNotFoundRuntimeException(msg);
		log.warn(msg, err);
		throw err;
	}
	
	public List<EffluentDTO> getByTypeCodes(User user, String tenant, Long applicationId, List<String> typeCodesToSearch) {

		try {
			
			if ( !"BUNDLE".equals(user.getUserId()) ) {
				
				ApplicationDetailsPublicDTO applicationDetailsPublicDTO = 
						applicationFacadeService.callForApplicationDetails(tenant, applicationId, user, Locale.ITALIAN.getLanguage());
				
				log.info(applicationDetailsPublicDTO.toString());
			}
			
			List<EffluentNTT> ntts = dao.getByTypeCodes(typeCodesToSearch);

			if (ntts != null && !ntts.isEmpty()) {
				log.info("Retrieving of Effluent completed for tenant {} ", tenant);
				return returnMappedList(ntts);
			}
		} 
		catch (Exception e) {
			String msg = GenericUtility.formatStr("Unable to complete 'get' method due an unhandled error for tenant {}", tenant);
			log.error(msg, e);
			throw e;
		}
 
		String msg = GenericUtility.formatStr("Unable to find Effluent item with tenant = {} due unhandled error ", tenant);
		ObjectNotFoundRuntimeException err = new ObjectNotFoundRuntimeException(msg);
		log.warn(msg, err);
		throw err;
	}
	
	public InfiniteListResults<EffluentDTO> searchInFertilizerType(User user, String tenant, Long applicationId, String filter, String nextKey) {
		
		log.info("Invoking find by application id with params tenant: {}, applicationId: {}, filter: {}, nextKey: {}", tenant, applicationId, filter, nextKey);
		
		try {
			
			ApplicationDetailsPublicDTO applicationDetailsPublicDTO = 
					applicationFacadeService.callForApplicationDetails(tenant, applicationId, user, Locale.ITALIAN.getLanguage());
			
			log.info(applicationDetailsPublicDTO.toString());
			
			log.info("Retrieving of Effluent completed for tenant {} ", tenant);
			
			return (returnInfiniteResults(
					this.dao.infinite(() -> dao.searchInFertilizerType(filter),
							nextKey,
							null!=nextKey?DEFAULT_PAGE_SIZE:DEFAULT_LIMIT)));
		} 
		catch (Exception e) {
			String msg = GenericUtility.formatStr("Unable to complete 'get' method due an unhandled error for tenant: {}, applicationId: {}, filter: {}, nextKey: {}", tenant, applicationId, filter, nextKey);
			log.error(msg, e);
			throw e;
		}
	}

	public EffluentDTO insert(String userName, String tenant, EffluentDTO dto) {
		
		try {

			EffluentNTT effluentNTT = EffluentNTT.builder()
					.categoryCode(dto.getCategoryCode())
			    	.fertilizerCategory(dto.getFertilizerCategory())
			    	.fertilizerType(dto.getFertilizerType())
			    	.typeCode(dto.getTypeCode())
			    	.dtInsert(OffsetDateTime.now())
			    	.dtDelete(CommonConstants.FAR_OFF_DATE)
			    	.userIdInsert(userName)
			    	.userIdDelete(null)
			    	.build();
			
			dao.insert(effluentNTT);
			 
			log.info("Insert of Effluent completed for tenant {} and typeCode {}", tenant, dto.getTypeCode());
			
			var res = dao.getByTypeCode(dto.getTypeCode());
			return returnOptionalRecord(Collections.singletonList(res)).get();
		} 
		catch (Exception e) {
			String msg = GenericUtility.formatStr("Unable to complete 'insert' method due an error for tenant {} and typeCode {}", tenant, dto.getTypeCode());
			log.error(msg, e);
			throw e;
		}
	}

	public EffluentDTO update(String userName, String tenant, EffluentDTO dto) {

		try {

			EffluentNTT effluentNTT = EffluentNTT.builder()
				.categoryCode(dto.getCategoryCode())
		    	.fertilizerCategory(dto.getFertilizerCategory())
		    	.fertilizerType(dto.getFertilizerType())
		    	.typeCode(dto.getTypeCode())
		    	.dtInsert(OffsetDateTime.now())
		    	.dtDelete(CommonConstants.FAR_OFF_DATE)
		    	.userIdInsert(userName)
		    	.userIdDelete(null)
		    	.build();

			dao.upsert(effluentNTT);
			
			log.info("Update of Effluent completed for tenant {}, typeCode {}", tenant, dto.getTypeCode());
			
			var res = dao.getByTypeCode(dto.getTypeCode());
			return returnOptionalRecord(Collections.singletonList(res)).get();
		} 
		catch (ObjectNotFoundRuntimeException e) {
			throw e;
		}
		catch (Exception e) {
			String msg = GenericUtility.formatStr("Unable to complete the 'update' method due an error for tenant {} and typeCode {} due an error ", tenant, dto.getTypeCode());
			log.error(msg, e);
			throw new RuntimeException(msg, e);
		}
	}

	public boolean delete(String userName, String tenant, String typeCode) {

		try {

			EffluentNTT ntt = dao.getByTypeCode(typeCode);

			if (ntt != null) {
				
				ntt.setUserIdDelete(userName);
				ntt.setDtDelete(OffsetDateTime.now());
				dao.expire(ntt);
				
				log.info("Delete of Effluent completed for tenant {}, typeCode {} ", tenant, typeCode);
				return true;
			}
			else {
				log.warn("Unable to find typeCode = " + typeCode);
				return false;
			}
		} 
		catch (Exception e) {
			String msg = GenericUtility.formatStr("Unable to complete 'delete' method due an error for tenant {}, typeCode {} ", tenant, typeCode);
			log.error(msg, e);
			throw e;
		}
	}

	@Override
	protected boolean hasPrimaryKey() {
		return true;
	}

	@Override
	protected void deleteByCustomKey(Void customKey) {
		throw throwNotImplementedException.get();
	}

	@Override
	protected void setCustomSearchKey(EffluentNTT rs, Void customKey) {
		throw throwNotImplementedException.get();
	}

	@Override
	protected Optional<EffluentNTT> findRsByCustomKey(Void customKey) {
		return Optional.empty();
	}

}
