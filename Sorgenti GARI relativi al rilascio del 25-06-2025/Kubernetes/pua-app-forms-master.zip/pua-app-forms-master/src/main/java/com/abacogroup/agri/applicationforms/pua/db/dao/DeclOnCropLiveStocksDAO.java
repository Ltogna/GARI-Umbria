package com.abacogroup.agri.applicationforms.pua.db.dao;

import com.abacogroup.agri.applicationforms.pua.core.exceptions.ObjectNotFoundRuntimeException;
import com.abacogroup.agri.applicationforms.pua.db.ntt.DeclOnCropLiveStocksNTT;
import com.abacogroup.agri.applicationforms.pua.db.ntt.DeclOnCropsNTT;
import com.abacogroup.agri.applicationforms.pua.services.common.FunctionalObject;
import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.customizer.BindBean;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;

import java.time.Instant;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.util.Calendar;
import java.util.List;

public interface DeclOnCropLiveStocksDAO extends IGenericPuaDAO<DeclOnCropLiveStocksNTT, Long> {

	@Override
	@SqlQuery("§select_nextval(appfpua_decl_on_crops_livestock_consist_id_seq)§")
	Long nextSequenceVal();

	@SqlUpdate("""
			INSERT INTO appfpua_decl_on_crops_livestock_consist 
			(pkid,  application_id,  animal_species,  animal_category,  housing_system,  head_of_livestock_numb, 	 average_live_weight,  number_in_the_field, 	 liquid_effl_leaving_stable, 
			 solid_effluent_leaving_stable, 	 dt_insert, 	 dt_delete,  user_id_insert,  user_id_delete,	 genre_code,	 production_code)
			VALUES(:pkid, :applicationId, :animalSpecies,  :animalCategory, :housingSystem,  :headOfLivestockNumb, 
			       :averageLiveWeight,  :numberInTheField,  :liquidEfflLeavingStable,  :solidEffluentLeavingStable,   :dtInsert,  :dtDelete,    :userIdInsert,   :userIdDelete,   :genreCode,
			       :productionCode)
			""")
	void insert(@BindBean DeclOnCropLiveStocksNTT ntt);

	@SqlUpdate("""
			update appfpua_decl_on_crops_livestock_consist
			   set dt_delete=:dtDelete,
			       user_id_delete = :userIdDelete
			 where application_id=:applicationId 
			 and pkid=:pkid 
			   and §current_timestamp§ between dt_insert and dt_delete 
			""")
	void expire(@Bind("applicationId") Long applicationId, @Bind("pkid") Long pkid, @Bind("dtDelete") OffsetDateTime dtDelete,
			@Bind("userIdDelete") String userIdDelete);

	default void upsert(DeclOnCropLiveStocksNTT nttToUpd, Long pkId) {

		// suppose that all ntts have the same application ID
		FunctionalObject<Long> applicationId = () -> nttToUpd != null ? nttToUpd.getApplicationId() : null;
		FunctionalObject<Long> nttId = () -> nttToUpd != null ? nttToUpd.getPkid() : null;

		if (nttToUpd != null && nttId.get() != null && this.countByPkId(nttId.get()) > 0) {

			String userIdInsert = nttToUpd.getUserIdInsert();
			long rightNow = Calendar.getInstance().getTimeInMillis();
			long rightNowMinusAMillis = rightNow - 1;

			Instant instantRightNow = Instant.ofEpochMilli(rightNow);
			Instant instantMinusAMillis = Instant.ofEpochMilli(rightNowMinusAMillis);

			OffsetDateTime dateTimeRightNow = instantRightNow.atOffset(ZoneOffset.UTC);
			OffsetDateTime dateTimeMinusAMillis = instantMinusAMillis.atOffset(ZoneOffset.UTC);

			nttToUpd.setDtInsert(dateTimeRightNow);

			useTransaction(dao -> {

				((DeclOnCropLiveStocksDAO) dao).expire(applicationId.get(), nttId.get(), dateTimeMinusAMillis, userIdInsert);
				nttToUpd.setPkid(pkId);
				((DeclOnCropLiveStocksDAO) dao).insert(nttToUpd);
			});
		} else {

			throw new ObjectNotFoundRuntimeException("Unable to find application id = " + applicationId.get() + " and pkId = " + nttId.get());
		}
	}

	@SqlQuery("select * from appfpua_decl_on_crops_livestock_consist where application_id = :application_id and pkid = :pkid and dt_delete > §current_timestamp§ ")
	@RegisterBeanMapper(DeclOnCropLiveStocksNTT.class)
	DeclOnCropLiveStocksNTT getByApplicationIdAndDeclatationId(@Bind("application_id") Long applicationId, @Bind("pkid") Long pkid);

	@SqlQuery("select count(*) from appfpua_decl_on_crops_livestock_consist where pkid = :pkid and dt_delete > §current_timestamp§")
	@RegisterBeanMapper(DeclOnCropLiveStocksNTT.class)
	int countByPkId(@Bind("pkid") Long pkid);

	@SqlQuery("SELECT * FROM appfpua_decl_on_crops_livestock_consist WHERE pkid = :pkid")
	@RegisterBeanMapper(DeclOnCropLiveStocksNTT.class)
	List<DeclOnCropLiveStocksNTT> findById(@Bind("pkid") Long pkid);

	@SqlUpdate("""
			UPDATE appfpua_decl_on_crops_livestock_consist 
			SET dt_delete = :dtDelete, 
			    user_id_delete = :userIdDelete 
			WHERE pkid = :pkid
			""")
	void delete(@Bind("pkid") Long pkid,
			@Bind("dtDelete") OffsetDateTime dtDelete,
			@Bind("userIdDelete") String userIdDelete);
	
	@SqlQuery("select count(*) from appfpua_decl_on_crops_livestock_consist where application_id = :application_id and dt_delete > §current_timestamp§")
	@RegisterBeanMapper(DeclOnCropsNTT.class)
	int count(@Bind("application_id") Long applicationId);


}
