package com.abacogroup.agri.applicationforms.pua.core.mappers;

import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import com.abacogroup.agri.applicationforms.pua.core.model.dto.AttachmentDTO;
import com.abacogroup.agri.applicationforms.pua.db.ntt.AttachmentNTT;

@Mapper
public interface AttachmentMapper extends EntityMapper<AttachmentDTO, AttachmentNTT> {

	AttachmentMapper INSTANCE = Mappers.getMapper(AttachmentMapper.class);

	@InheritInverseConfiguration()
	AttachmentDTO entityToDto(AttachmentNTT entity);

	@Mapping(source = "pkid", target = "pkid")
	@Mapping(source = "applicationId", target = "application_id")
	@Mapping(source = "attachmentId", target = "attachment_id")
	@Mapping(source = "bucketId", target = "bucket_id")
	@Mapping(source = "type", target = "type")
	@Mapping(source = "fileName", target = "file_name")
	@Mapping(source = "notes", target = "notes")
	@Mapping(source = "userIdInsert", target = "user_id_insert")
	@Mapping(source = "userIdDelete", target = "user_id_delete")
	@Mapping(source = "dtInsert", target = "dt_insert")
	@Mapping(source = "dtDelete", target = "dt_delete")
	@Mapping(source = "typeId", target = "type_id")
	@Mapping(source = "typeCode", target = "type_code")
	@Mapping(source = "typeAttachmentGroupCode", target = "type_attachment_group_code")
	@Mapping(source = "typeAttachmentCode", target = "type_attachment_code")
	@Mapping(source = "tenantId", target = "tenant_id")
	AttachmentNTT dtoToEntity(AttachmentDTO dto);

}
