package com.abacogroup.agri.applicationforms.pua.core.model;

import com.abacogroup.dropwizard.auth.sso2.User;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 
 * @author Emanuele Crocilla
 *
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class PartyResponseKey {
	private String tenant;
	private Long partyId;
	private String cuaa;
	private User user;
}
