package com.abacogroup.agri.applicationforms.pua.core.model.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 
 * @author Emanuele Crocilla
 * 
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ProductType {

    private String cropCode;
    private double nitrogenQt;
    private double yield;
    private double nitrogenCorrectionFactor;
    private String productTypeCode;
    private String productTypeDescr;
 
}
