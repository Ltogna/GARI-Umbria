package com.abacogroup.agri.applicationforms.pua.core.model.dto;

import java.time.OffsetDateTime;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;
 
/**
 * 
 * @author Emanuele Crocilla
 *
 */
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
@Schema(description = "The TipologiaDichiarazione DTO")
public class TipologiaDichiarazioneDTO {
     
	@JsonProperty(access = JsonProperty.Access.READ_ONLY)
    @Schema(description = "The application id")
    private Long applicationId;
    
    @Schema(description = "The year")
    private int year;
    
    @Schema(description = "The year flOrganicFert")
    private boolean flOrganicFert;
    
    @Schema(description = "The year flLivestocks")
    private boolean flLivestocks;
    
    @Schema(description = "The insert date")
    @JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ssXXX")
    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    private OffsetDateTime dtInsert;
    
    @Schema(description = "The deleted date")
    @JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ssXXX")
    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    private OffsetDateTime dtDelete;
    
    @Schema(description = "The user id which inserted ")
    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    private String userIdInsert;
    
    @Schema(description = "The user id which deleted ")
    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    private String userIdDelete;
}
