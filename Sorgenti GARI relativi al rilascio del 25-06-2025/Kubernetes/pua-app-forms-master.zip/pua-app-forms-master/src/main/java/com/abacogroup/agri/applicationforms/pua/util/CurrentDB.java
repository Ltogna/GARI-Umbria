package com.abacogroup.agri.applicationforms.pua.util;

/**
 * 
 * @author Emanuele Crocilla
 *
 */
public class CurrentDB {
	
    private static volatile CurrentDB INSTANCE; 
    
    private DB db;

    private CurrentDB() {}

    public static CurrentDB getInstance() {
        if (INSTANCE == null) {
            synchronized (CurrentDB.class) {
                if (INSTANCE == null) {
                    INSTANCE = new CurrentDB();
                }
            }
        }
        return INSTANCE;
    }

    public DB getDbName() {
        return db;
    }

    public void setDbName(DB dbName) {
        this.db = dbName;
    }
    
    public static boolean isPostgres() {
    	return DB.POSTGRES.equals(CurrentDB.INSTANCE.db);
    }
    
    public enum DB {
    	POSTGRES, ORACLE
    }
}
