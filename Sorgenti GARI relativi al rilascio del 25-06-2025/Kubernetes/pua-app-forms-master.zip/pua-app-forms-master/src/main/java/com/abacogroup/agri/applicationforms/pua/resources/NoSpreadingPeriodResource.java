package com.abacogroup.agri.applicationforms.pua.resources;

import com.abacogroup.agri.applicationforms.pua.ApplicationFormsModuleConfiguration;
import com.abacogroup.agri.applicationforms.pua.core.model.dto.NoSpreadingPeriodDTO;
import com.abacogroup.agri.applicationforms.pua.services.NoSpreadingPeriodService;
import com.abacogroup.dropwizard.auth.sso2.Sso2Client;
import com.abacogroup.dropwizard.auth.sso2.User;
import io.dropwizard.auth.Auth;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.parameters.RequestBody;
import jakarta.validation.constraints.NotNull;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.Response;
import lombok.extern.slf4j.Slf4j;

import java.util.List;

@Slf4j
public class NoSpreadingPeriodResource extends AGenericPuaResources {

	private final NoSpreadingPeriodService noSpreadingPeriodService;

	public NoSpreadingPeriodResource(ApplicationFormsModuleConfiguration configuration,
			Sso2Client sso2Client,
			NoSpreadingPeriodService noSpreadingPeriodService) {
		super(configuration, sso2Client);
		this.noSpreadingPeriodService = noSpreadingPeriodService;
	}

	@GET
	@Path("/{applicationId}/no-spreading-periods")
	public Response getAll(
			@Parameter(hidden = true) @Auth User user,
			@PathParam("tenant") @NotNull String tenant,
			@PathParam("applicationId") @NotNull Long applicationId
	) {
		List<NoSpreadingPeriodDTO> result = noSpreadingPeriodService.getAll(user, tenant, applicationId);
		return Response.ok(result).build();
	}

	@GET
	@Path("/{applicationId}/no-spreading-periods/{id}")
	public Response getById(
			@Parameter(hidden = true) @Auth User user,
			@PathParam("tenant") @NotNull String tenant,
			@PathParam("applicationId") @NotNull Long applicationId,
			@PathParam("id") @NotNull Long id
	) {
		NoSpreadingPeriodDTO result = noSpreadingPeriodService.get(user, tenant, applicationId, id);
		return Response.ok(result).build();
	}

	@POST
	@Path("/{applicationId}/no-spreading-periods")
	public Response create(
			@Parameter(hidden = true) @Auth User user,
			@PathParam("tenant") @NotNull String tenant,
			@PathParam("applicationId") @NotNull Long applicationId,
			@Parameter(description = "The form config id") @NotNull @QueryParam("formConfigId") Long formConfigId,
			@Parameter(description = "The compile status identifier") @QueryParam("compileStatusIdentifier") String compileStatusIdentifier,
			@NotNull @RequestBody NoSpreadingPeriodDTO payload
	) {
		NoSpreadingPeriodDTO result = noSpreadingPeriodService.insert(user, tenant, applicationId, payload, compileStatusIdentifier);
		return Response.ok(result).build();
	}

	@PUT
	@Path("/{applicationId}/no-spreading-periods/{id}")
	public Response update(
			@Parameter(hidden = true) @Auth User user,
			@PathParam("tenant") @NotNull String tenant,
			@PathParam("applicationId") @NotNull Long applicationId,
			@PathParam("id") @NotNull Long id,
			@Parameter(description = "The compile status identifier") @QueryParam("compileStatusIdentifier") String compileStatusIdentifier,
			@NotNull @RequestBody NoSpreadingPeriodDTO payload
	) {
		NoSpreadingPeriodDTO result = noSpreadingPeriodService.update(user, tenant, applicationId, id, payload, compileStatusIdentifier);
		return Response.ok(result).build();
	}

	@DELETE
	@Path("/{applicationId}/no-spreading-periods/{id}")
	public Response delete(
			@Parameter(hidden = true) @Auth User user,
			@PathParam("tenant") @NotNull String tenant,
			@PathParam("applicationId") @NotNull Long applicationId,
			@Parameter(description = "The compile status identifier") @QueryParam("compileStatusIdentifier") String compileStatusIdentifier,
			@PathParam("id") @NotNull Long id
	) {
		boolean success = noSpreadingPeriodService.delete(user, tenant, applicationId, id, compileStatusIdentifier);
		return success ? Response.ok().build() : Response.status(Response.Status.NOT_FOUND).build();
	}

	@DELETE
	@Path("/{applicationId}/no-spreading-periods")
	public Response deleteAll(
			@Parameter(hidden = true) @Auth User user,
			@PathParam("tenant") @NotNull String tenant,
			@Parameter(description = "The compile status identifier") @QueryParam("compileStatusIdentifier") String compileStatusIdentifier,
			@PathParam("applicationId") @NotNull Long applicationId
	) {
		noSpreadingPeriodService.deleteAll(user, tenant, applicationId, compileStatusIdentifier);
		return Response.ok().build();
	}

	/**
	 * 1. UPSERT latest period.
	 */
	//	@POST
	//	@Path("/no-spreading-periods-last")
	//	public Response upsertLatest(
	//			@Parameter(hidden = true) @Auth User user,
	//			@PathParam("tenant") @NotNull String tenant,
	//			@PathParam("applicationId") @NotNull Long applicationId,
	//			@PathParam("id") @NotNull Long id,
	//			@Parameter(description = "The compile status identifier") @QueryParam("compileStatusIdentifier") String compileStatusIdentifier,
	//			@NotNull @RequestBody NoSpreadingPeriodLatestInsertDTO dto
	//
	//	) {
	//		var result = noSpreadingPeriodService.upsertLatestNoSpreadingPeriod(dto);
	//		return Response.ok(result).build();
	//	}
	//
	//	@GET
	//	@Path("/{applicationId}/no-spreading-periods-last")
	//	public Response getLatestPeriodForValidation(
	//			@Parameter(hidden = true) @Auth User user,
	//			@PathParam("tenant") @NotNull String tenant,
	//			@PathParam("applicationId") @NotNull Long applicationId,
	//			@QueryParam("effluent") @NotNull String effluent,
	//			@QueryParam("partyId") @NotNull Long partyId,
	//			@QueryParam("year") @NotNull int year
	//
	//	) {
	//		var result = noSpreadingPeriodService.getLatestPeriodForValidation(user, partyId, effluent, year);
	//		return Response.ok(result).build();
	//	}
	//
	//	@GET
	//	@Path("/{applicationId}/no-spreading-periods-last/isSpreadingDateAllowed")
	//	public Response isSpreadingDateAllowed(
	//			@Parameter(hidden = true) @Auth User user,
	//			@PathParam("tenant") @NotNull String tenant,
	//			@PathParam("applicationId") @NotNull Long applicationId,
	//			@QueryParam("effluent") @NotNull String effluent,
	//			@QueryParam("partyId") @NotNull Long partyId,
	//			@QueryParam("year") @NotNull int year,
	//			@QueryParam("expecetdDate") @NotNull LocalDate expecetdDate
	//
	//	) {
	//		var result = noSpreadingPeriodService.isSpreadingDateAllowed(user, partyId, effluent, year, expecetdDate);
	//		return Response.ok(result).build();
	//	}
}
