package com.abacogroup.agri.applicationforms.pua.core.model.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

/**
 * 
 * @author Emanuele Crocilla
 *
 */
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
@Schema(description = "The Sector DTO")
public class SectorDTO {

	@Schema(description = "The id")
	private int id;
	
	@Schema(description = "The description")
	private String description;
	
	@Schema(description = "The short description")
	@JsonProperty("short_descr")
	private String shortDescr;
	
	@Schema(description = "The sector code")
	@JsonProperty("sector_code")
	private String sectorCode;
	
	@Schema(description = "The srs")
	private String srs;
	
	@Schema(description = "The geometry")
	private String geom;
	
	@Schema(description = "The world geometry")
	@JsonProperty("world_geom")
	private String worldGeom;
}
