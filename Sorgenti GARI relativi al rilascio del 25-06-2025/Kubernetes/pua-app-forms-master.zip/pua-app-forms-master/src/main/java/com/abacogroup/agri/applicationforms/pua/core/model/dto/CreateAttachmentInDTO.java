package com.abacogroup.agri.applicationforms.pua.core.model.dto;

import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author Alexandru Paraschiv
 * @author Mauro Pozzana
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CreateAttachmentInDTO {
	@NotNull
	private String groupCode;
	@NotNull
	private String typeCode;
	private String notes;
}
