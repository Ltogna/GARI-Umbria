package com.abacogroup.agri.applicationforms.pua.core.exceptions;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.ws.rs.core.Response;

/**
 * 
 * @author Emanuele Crocilla
 *
 */
public class OperationNotPermittedRuntimeException extends AbstractException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private static final OperationNotPermittedRuntimeException.ErrorBody BODY = new OperationNotPermittedRuntimeException.ErrorBody();

	public OperationNotPermittedRuntimeException() {
		super(Response.Status.FORBIDDEN, BODY, "form was in read only");
	}

	@Schema(name = "OperationNotPermittedRuntimeExceptionErrorBody")
	public static class ErrorBody implements ExceptionErrorBody {
		private static final String ERR = "OPERATION_NOT_PERMITTED_ERROR";

		@Override
		@Schema(allowableValues = ERR)
		public String getErrorCode() {
			return ERR;
		}
	}
}
