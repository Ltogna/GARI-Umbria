package com.abacogroup.agri.applicationforms.pua.core.mappers;

import com.abacogroup.agri.applicationforms.pua.core.model.AbsoluteDate;
import com.abacogroup.agri.applicationforms.pua.core.model.dto.NoSpreadingPeriodLatestInsertDTO;
import com.abacogroup.agri.applicationforms.pua.db.ntt.NoSpreadingPeriodLatestInsertNTT;
import com.abacogroup.jdbi.mapper.AbsoluteDateMapper;
import org.mapstruct.Mapper;
import org.mapstruct.Named;
import org.mapstruct.factory.Mappers;

/**
 * @author Emanuele Crocilla
 */
@Mapper(uses = AbsoluteDateMapper.class)
public interface NoSpreadingPeriodLastInsertMapper extends EntityMapper<NoSpreadingPeriodLatestInsertDTO, NoSpreadingPeriodLatestInsertNTT> {

	NoSpreadingPeriodLastInsertMapper INSTANCE = Mappers.getMapper(NoSpreadingPeriodLastInsertMapper.class);

	NoSpreadingPeriodLatestInsertDTO entityToDto(NoSpreadingPeriodLatestInsertNTT entity);

	NoSpreadingPeriodLatestInsertNTT dtoToEntity(NoSpreadingPeriodLatestInsertDTO dto);

	@Named("absoluteDateToString")
	default String absoluteDateToString(AbsoluteDate date) {
		return date != null ? date.toString() : null;
	}

	@Named("stringToAbsoluteDate")
	default AbsoluteDate stringToAbsoluteDate(String value) {
		return value != null ? new AbsoluteDate(value) : null;
	}
}
