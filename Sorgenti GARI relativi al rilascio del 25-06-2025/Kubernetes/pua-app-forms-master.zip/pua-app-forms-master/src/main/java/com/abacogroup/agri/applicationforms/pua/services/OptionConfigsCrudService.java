package com.abacogroup.agri.applicationforms.pua.services;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import com.abacogroup.agri.applicationforms.pua.core.exceptions.ObjectNotFoundRuntimeException;
import com.abacogroup.agri.applicationforms.pua.core.mappers.OptionConfigsMapper;
import com.abacogroup.agri.applicationforms.pua.core.mappers.OptionConfigsWithCodeMapper;
import com.abacogroup.agri.applicationforms.pua.core.model.AbsoluteDate;
import com.abacogroup.agri.applicationforms.pua.core.model.dto.OptionConfigsDTO;
import com.abacogroup.agri.applicationforms.pua.core.model.dto.OptionConfigsWithCodeDTO;
import com.abacogroup.agri.applicationforms.pua.db.dao.IGenericPuaDAO;
import com.abacogroup.agri.applicationforms.pua.db.dao.OptionConfigsDAO;
import com.abacogroup.agri.applicationforms.pua.db.ntt.OptionConfigsNTT;
import com.abacogroup.agri.applicationforms.pua.db.ntt.applications.RsI18N;
import com.abacogroup.agri.applicationforms.pua.services.common.I18NService;
import com.abacogroup.agri.applicationforms.pua.services.common.crud.AbstractCrudService;
import com.abacogroup.agri.applicationforms.pua.util.GenericUtility;

import lombok.extern.slf4j.Slf4j;

/**
 * @author Alexandru Paraschiv
 */
@Slf4j
public class OptionConfigsCrudService
		extends AbstractCrudService<OptionConfigsNTT, Long, OptionConfigsDTO, OptionConfigsMapper, Void, IGenericPuaDAO<OptionConfigsNTT, Long>> {

	public static final String I18N_OPTION_CONFIGS_TABLE = "appfpua_option_configs";
	private final I18NService i18NService;

	public OptionConfigsCrudService(IGenericPuaDAO<OptionConfigsNTT, Long> dao, OptionConfigsMapper mapper,
			I18NService i18NService) {
		super(dao, mapper);
		this.i18NService = i18NService;
	}

	@Override
	protected boolean hasPrimaryKey() {
		return true;
	}

	@Override
	protected Optional<OptionConfigsNTT> findRsByCustomKey(Void customKey) {
		return Optional.empty();
	}

	@Override
	protected void deleteByCustomKey(Void customKey) {
		throw GenericUtility.throwNotImplementedException.get();
	}

	@Override
	protected void setCustomSearchKey(OptionConfigsNTT rs, Void customKey) {
		throw GenericUtility.throwNotImplementedException.get();
	}

	public Optional<OptionConfigsDTO> findOptById(Long id) {
		log.info("Invoking findById with params id:{}", id);

		return this.dao.findById(id)
				.stream()
				.findFirst()
				.map(mapper::entityToDto);
	}

	public OptionConfigsDTO findById(Long id) {
		log.info("Invoking findById with params id:{}", id);

		return this.dao.findById(id)
				.stream()
				.findFirst()
				.map(mapper::entityToDto)
				.orElseThrow(ObjectNotFoundRuntimeException::new);
	}

	public List<OptionConfigsDTO> findByTenant(String tenant) {
		log.info("Invoking findById with params tenant:{}", tenant);

		return ((OptionConfigsDAO)this.dao).findByTenant(tenant)
				.stream()
				.map(mapper::entityToDto)
				.toList();
	}

	/**
	 * @deprecated (using method with dtValidity)
	 */
	@Deprecated(since = "start")
	public OptionConfigsDTO findByOptionCode(String tenant, String optionCode) {
		log.info("Invoking findByOptionCode with params tenant:{} optionCode:{}", tenant, optionCode);

		return ((OptionConfigsDAO)this.dao).findByOptionCode(tenant, optionCode)
				.stream()
				.findFirst()
				.map(mapper::entityToDto)
				.orElseThrow(ObjectNotFoundRuntimeException::new);
	}

	public List<OptionConfigsDTO> findByOptionCodesAndDtValidityEnd(String tenant, List<String> optionCodeList, AbsoluteDate dtValidityEnd) {
		log.info("Invoking findByOptionCodesAndDtValidityEnd with params tenant:{} optionCodeList:{}", tenant, optionCodeList);

		if(Optional.ofNullable(optionCodeList).isEmpty() || optionCodeList.isEmpty()){
			return Collections.emptyList();
		}

		return ((OptionConfigsDAO)this.dao).findByOptionCodesAndDtValidityEnd(tenant, optionCodeList, dtValidityEnd)
				.stream()
				.map(mapper::entityToDto)
				.toList();
	}

	public List<OptionConfigsDTO> findAllByOptionId(Long optionId) {
		log.info("Invoking findAllByOptionId with params optionId:{} ", optionId);

		return ((OptionConfigsDAO)this.dao).findAllByOptionId(optionId)
				.stream()
				.map(mapper::entityToDto)
				.toList();
	}


	public OptionConfigsDTO findByOptionCodeAndDtValidityEnd(String tenant, String optionCode, AbsoluteDate dtValidityEnd) {
		log.info("Invoking findByOptionCodeAndDtValidityEnd with params tenant:{} optionCode:{}", tenant, optionCode);

		return ((OptionConfigsDAO)this.dao).findByOptionCodeAndDtValidityEnd(tenant, optionCode, dtValidityEnd)
				.stream()
				.findFirst()
				.map(mapper::entityToDto)
				.orElseThrow(ObjectNotFoundRuntimeException::new);
	}


	public Optional<OptionConfigsDTO> findOptByOptionCodeAndDtValidityEnd(String tenant, String optionCode, AbsoluteDate dtValidityEnd) {
		log.info("Invoking findOptByOptionCodeAndDtValidityEnd with params tenant:{} optionCode:{}", tenant, optionCode);

		return ((OptionConfigsDAO)this.dao).findByOptionCodeAndDtValidityEnd(tenant, optionCode, dtValidityEnd)
				.stream()
				.findFirst()
				.map(mapper::entityToDto);
	}

	public OptionConfigsDTO findByOptionId(String tenant, Long applicationId, Long optionId,
				AbsoluteDate referredDate) {
		log.info("Invoking findByOptionId with params tenant: {} applicationId: {} optionId: {} referredDate: {}",
				tenant, applicationId, optionId, referredDate);

		return ((OptionConfigsDAO)this.dao).findByApplicationIdOptionIdAndDtValidityEnd(tenant, applicationId, optionId,
						referredDate)
				.stream()
				.findFirst()
				.map(mapper::entityToDto)
				.orElseThrow(ObjectNotFoundRuntimeException::new);
	}

	public OptionConfigsDTO findByOptionIdAndApplicationId(String tenant, Long applicationId, Long optionId) {
		log.info("Invoking findByOptionIdAndApplicationId with params tenant: {} applicationId: {} optionId: {}",
				tenant, applicationId, optionId);

		return ((OptionConfigsDAO)this.dao).findByApplicationIdOptionId(tenant, applicationId, optionId).stream()
				.findFirst()
				.map(mapper::entityToDto)
				.orElseThrow(ObjectNotFoundRuntimeException::new);
	}



	public OptionConfigsDTO insert(OptionConfigsDTO in) {
		log.info("Invoking insert with params in: {}", in);
		return this.insert(in, null);
	}

	public OptionConfigsDTO update(Long id, OptionConfigsDTO in) {
		log.info("Invoking update with params key: {} in: {}", id, in);
		return this.update(id, in, null);
	}

	public void insertOptionConfigsI18n(String tenant, String code, String lang, String description) {
		log.info("Invoking insertOptionConfigsI18n with params tenant: {} code: {} lang: {} description: {}", tenant, code, lang, description);
		this.i18NService.insertI18N(tenant, I18N_OPTION_CONFIGS_TABLE, OPTION_CONFIGS_I18N.CODE.code, lang, code, description);
	}

	public void deleteOptionConfigsI18N(String tenant, String code) {
		log.info("Invoking insertOptionConfigsI18n with params tenant: {} code: {}", tenant, code);
		this.i18NService.deleteAllI18NbyCode(tenant, I18N_OPTION_CONFIGS_TABLE, code);
	}

	public List<RsI18N> getAllOptionConfigsI18NByTenantAndCode(String tenant, String code) {
		return this.i18NService.getAllI18NbyCode(tenant, I18N_OPTION_CONFIGS_TABLE, code);
	}

	public enum OPTION_CONFIGS_I18N {
		CODE("code");

		private final String code;

		OPTION_CONFIGS_I18N(String val) {
			this.code = val;
		}

		public String getCode() {
			return this.code;
		}
	}

    public List<String> filterOptionCodesByParams(String tenant, Long applicationId, AbsoluteDate dtValidity,
                                                  List<String> optionCodeList, List<String> paramValueList) {
        if (Optional.ofNullable(optionCodeList).isEmpty() || Optional.ofNullable(paramValueList).isEmpty() ||
                optionCodeList.isEmpty() || paramValueList.isEmpty())
            return new ArrayList<>();

        return ((OptionConfigsDAO) this.dao).filterOptionCodesByParams(tenant, applicationId, dtValidity, optionCodeList, paramValueList);
    }

	public List<OptionConfigsWithCodeDTO> findOptionConfigsDataByTenant(String tenant, AbsoluteDate referenceDate) {
		return ((OptionConfigsDAO) this.dao).findConfigsDataByTenantAndReferenceDate(tenant, referenceDate)
				.stream()
				.map(OptionConfigsWithCodeMapper.INSTANCE::entityToDto)
				.toList();
	}
}

