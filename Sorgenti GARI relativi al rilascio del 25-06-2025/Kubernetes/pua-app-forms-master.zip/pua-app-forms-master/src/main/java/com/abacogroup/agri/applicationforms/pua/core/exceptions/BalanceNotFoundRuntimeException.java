package com.abacogroup.agri.applicationforms.pua.core.exceptions;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.ws.rs.core.Response;

/**
 * @author Emanuele Crocilla
 */
public class BalanceNotFoundRuntimeException extends AbstractException {

	private static final long serialVersionUID = 1L;

	private static final ErrorBody BODY = new ErrorBody();

	public BalanceNotFoundRuntimeException(String message) {
		super(Response.Status.INTERNAL_SERVER_ERROR, BODY, message);
	}

	@Schema(name = "BalanceNotFoundRuntimeExceptionBody")
	public static class ErrorBody implements ExceptionErrorBody {
		private static final String ERR = "BALANCE_NOT_FOUND_ERROR";

		@Override
		@Schema(allowableValues = ERR)
		public String getErrorCode() {
			return ERR;
		}
	}
}
