package com.abacogroup.agri.applicationforms.pua.services;

import com.abacogroup.agri.applicationforms.pua.core.exceptions.NoSpreadingAllowedException;
import com.abacogroup.agri.applicationforms.pua.core.exceptions.ObjectNotFoundRuntimeException;
import com.abacogroup.agri.applicationforms.pua.core.mappers.NoSpreadingPeriodLastInsertMapper;
import com.abacogroup.agri.applicationforms.pua.core.mappers.NoSpreadingPeriodMapper;
import com.abacogroup.agri.applicationforms.pua.core.model.CompileStatusEnum;
import com.abacogroup.agri.applicationforms.pua.core.model.dto.NoSpreadingPeriodDTO;
import com.abacogroup.agri.applicationforms.pua.db.dao.NoSpreadingPeriodDAO;
import com.abacogroup.agri.applicationforms.pua.db.dao.NoSpreadingPeriodLatestInsertDAO;
import com.abacogroup.agri.applicationforms.pua.db.ntt.NoSpreadingPeriodLatestInsertNTT;
import com.abacogroup.agri.applicationforms.pua.db.ntt.NoSpreadingPeriodNTT;
import com.abacogroup.agri.applicationforms.pua.services.common.ApplicationFacadeService;
import com.abacogroup.agri.applicationforms.pua.services.common.crud.AbstractCrudService;
import com.abacogroup.agri.applicationforms.pua.util.CommonConstants;
import com.abacogroup.dropwizard.auth.sso2.User;

import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.time.Year;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.Locale;
import java.util.Optional;
import java.util.stream.Collectors;

public class NoSpreadingPeriodService
		extends AbstractCrudService<NoSpreadingPeriodNTT, Long, NoSpreadingPeriodDTO, NoSpreadingPeriodMapper, Void, NoSpreadingPeriodDAO> {

	private final ApplicationFacadeService applicationFacadeService;
	private final NoSpreadingPeriodLatestInsertDAO latestInsertDAO;
	private final NoSpreadingPeriodLastInsertMapper mapperLastInsert;

	public NoSpreadingPeriodService(
			NoSpreadingPeriodDAO dao,
			ApplicationFacadeService applicationFacadeService,
			NoSpreadingPeriodMapper mapper,
			NoSpreadingPeriodLatestInsertDAO _latestInsertDAO,
			NoSpreadingPeriodLastInsertMapper mapperLastInsert

	) {

		super(dao, mapper);
		this.applicationFacadeService = applicationFacadeService;
		this.latestInsertDAO = _latestInsertDAO;
		this.mapperLastInsert = mapperLastInsert;
	}

	public List<NoSpreadingPeriodDTO> getAll(User user, String tenant, Long applicationId) {
		applicationFacadeService.callForApplicationDetails(tenant, applicationId, user, Locale.ITALIAN.getLanguage());
		return dao.getByApplicationId(applicationId).stream()
				.map(this.mapper::entityToDto)
				.collect(Collectors.toList());
	}

	public NoSpreadingPeriodDTO get(User user, String tenant, Long applicationId, Long pkid) {
		applicationFacadeService.callForApplicationDetails(tenant, applicationId, user, Locale.ITALIAN.getLanguage());
		NoSpreadingPeriodNTT entity = dao.getById(pkid);
		if (entity == null) {
			throw new ObjectNotFoundRuntimeException("NoSpreadingPeriod not found: " + pkid);
		}
		return mapper.entityToDto(entity);
	}

	public NoSpreadingPeriodDTO insert(User user, String tenant, Long applicationId, NoSpreadingPeriodDTO dto, String compileStatusIdentifier) {
		// Validate access
		applicationFacadeService.callForApplicationDetails(tenant, applicationId, user, Locale.ITALIAN.getLanguage());

		if (dao.countByApplicationIdAndEffluent(applicationId, dto.getEffluent()) > 0) {
			throw new IllegalArgumentException("Only one effluent is allowed per application.");
		}
		ValidateDates(dto);
		// Map DTO to NTT and populate system fields
		NoSpreadingPeriodNTT ntt = mapper.dtoToEntity(dto);
		ntt.setApplicationId(applicationId);
		ntt.setDtInsert(OffsetDateTime.now());
		ntt.setDtDelete(CommonConstants.FAR_OFF_DATE);
		ntt.setUserIdInsert(user.getUserId());
		Long nttId = dao.nextSequenceVal();
		ntt.setPkid(nttId);
		dao.insert(ntt);
		applicationFacadeService.updateCompileStatus(user, tenant, applicationId, compileStatusIdentifier, CompileStatusEnum.COMPLETED);
		return mapper.entityToDto(dao.getById(nttId));
	}

	public NoSpreadingPeriodDTO update(User user, String tenant, Long applicationId, Long pkid, NoSpreadingPeriodDTO dto, String compileStatusIdentifier) {
		applicationFacadeService.callForApplicationDetails(tenant, applicationId, user, Locale.ITALIAN.getLanguage());
		if (dao.countByApplicationIdAndEffluent(applicationId, dto.getEffluent()) > 0) {
			throw new IllegalArgumentException("Only one effluent is allowed per application.");
		}
		ValidateDates(dto);
		NoSpreadingPeriodNTT existing = dao.getByIdandApplicationId(pkid, applicationId);
		if (existing == null) {
			throw new ObjectNotFoundRuntimeException("NoSpreadingPeriod not found: " + pkid + " and ApplicationId: " + applicationId);
		}
		NoSpreadingPeriodNTT updated = mapper.dtoToEntity(dto);
		updated.setPkid(pkid);
		updated.setApplicationId(applicationId);
		updated.setDtInsert(OffsetDateTime.now());
		updated.setDtDelete(CommonConstants.FAR_OFF_DATE);
		updated.setUserIdInsert(user.getUserId());

		dao.upsert(updated);
		applicationFacadeService.updateCompileStatus(user, tenant, applicationId, compileStatusIdentifier, CompileStatusEnum.COMPLETED);
		var updatedet = dao.getById(updated.getPkid());

		return mapper.entityToDto(updatedet);
	}

	private void ValidateDates(NoSpreadingPeriodDTO dto) {
		if (dto.getDayFrom() == null || dto.getDayTo() == null) {
			throw new IllegalArgumentException("Periodo di Non Spandimento, problema tra dayFrom e dayTo.");
		}
		LocalDate dayFrom = dto.getDayFrom().toLocalDate();
		LocalDate dayTo = dto.getDayTo().toLocalDate();

		if (dayTo.isBefore(dayFrom)) {
			throw new IllegalArgumentException("Il giorno di fine deve essere uguale o successivo al giorno di inizio.");
		}
		long daysBetween = ChronoUnit.DAYS.between(dayFrom, dayTo);
		if (daysBetween < 90) {
			throw new IllegalArgumentException("Il periodo minimo di divieto di spandimento deve essere almeno di 90 giorni.");
		}

		LocalDate minStart = LocalDate.of(dayFrom.getYear(), 10, 1);
		int endYear = (dayTo.getMonthValue() <= 2) ? dayTo.getYear() : dayTo.getYear() + 1;
		boolean isLeapYear = Year.isLeap(endYear);
		LocalDate maxEnd = LocalDate.of(endYear, 2, isLeapYear ? 29 : 28);

		if (dayFrom.isBefore(minStart) || dayTo.isAfter(maxEnd)) {
			throw new IllegalArgumentException(
					"No Spreading Period, issue on dayFrom and dayTo: the selected period must start on or after October 1st and end on or before February 28th/29th.");
		}
	}

	public boolean delete(User user, String tenant, Long applicationId, Long pkid, String compileStatusIdentifier) {
		applicationFacadeService.callForApplicationDetails(tenant, applicationId, user, Locale.ITALIAN.getLanguage());

		NoSpreadingPeriodNTT entity = dao.getById(pkid);
		if (entity == null)
			return false;

		dao.expire(applicationId, pkid, OffsetDateTime.now(), user.getUserId());
		applicationFacadeService.updateCompileStatus(user, tenant, applicationId, compileStatusIdentifier, CompileStatusEnum.COMPLETED);
		return true;
	}

	public void deleteAll(User user, String tenant, Long applicationId, String compileStatusIdentifier) {
		applicationFacadeService.callForApplicationDetails(tenant, applicationId, user, Locale.ITALIAN.getLanguage());

		List<NoSpreadingPeriodNTT> all = dao.getByApplicationId(applicationId);
		all.forEach(ntt -> dao.expire(applicationId, ntt.getPkid(), OffsetDateTime.now(), user.getUserId()));
		applicationFacadeService.updateCompileStatus(user, tenant, applicationId, compileStatusIdentifier, CompileStatusEnum.COMPLETED);
	}

	@Override
	protected boolean hasPrimaryKey() {
		return false;
	}

	@Override
	protected Optional<NoSpreadingPeriodNTT> findRsByCustomKey(Void customKey) {
		return Optional.empty();
	}

	@Override
	protected void deleteByCustomKey(Void customKey) {

	}

	@Override
	protected void setCustomSearchKey(NoSpreadingPeriodNTT rs, Void customKey) {

	}

	//No Spreading Period Last Inserted

	/**
	 * Insert or update the latest no-spreading period range (PRE_PROTOCOLLED or PRE_RECTIFIED).
	 */
	//	public NoSpreadingPeriodLatestInsertDTO upsertLatestNoSpreadingPeriod(NoSpreadingPeriodLatestInsertDTO dto) {
	//		var entity = mapperLastInsert.dtoToEntity(dto);
	//		latestInsertDAO.upsert(entity);
	//		return mapperLastInsert.entityToDto(entity);
	//	}
	//
	//	public NoSpreadingPeriodLatestInsertDTO getLatestPeriodForValidation(User user, Long partyId, String effluent, int year) {
	//		var ntt = latestInsertDAO.getByKey(partyId, effluent, year);
	//		return mapperLastInsert.entityToDto(ntt);
	//	}
	//
	//	public NoSpreadingPeriodLatestInsertDTO getLatestPeriodByPartyAndYear(User user, Long partyId, int year) {
	//		var ntt = latestInsertDAO.getLatestPeriodByPartyAndYear(partyId, year);
	//		return mapperLastInsert.entityToDto(ntt);
	//	}
	public boolean isSpreadingDateAllowed(User user, Integer partyId, String effluent, String expectedDateString) {
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyMMdd");

		LocalDate expectedDate = LocalDate.parse(expectedDateString, formatter);
		int year = expectedDate.getYear();

		NoSpreadingPeriodLatestInsertNTT restriction = latestInsertDAO.getByKey(partyId, effluent, year);

		if (restriction == null) {
			LocalDate dec1 = LocalDate.of(year, 12, 1);
			LocalDate febEnd = Year.isLeap(year + 1)
					? LocalDate.of(year + 1, 2, 29)
					: LocalDate.of(year + 1, 2, 28);

			if (!expectedDate.isBefore(dec1) && !expectedDate.isAfter(febEnd)) {
				throw new NoSpreadingAllowedException("Lo spandimento ricade in un periodo di divieto");
			}
		} else {
			LocalDate from = LocalDate.parse(restriction.getDayFrom(), formatter);
			LocalDate to = LocalDate.parse(restriction.getDayTo(), formatter);

			if (!expectedDate.isBefore(from) && !expectedDate.isAfter(to)) {
				throw new NoSpreadingAllowedException("Lo spandimento ricade in un periodo di divieto dichiarato");
			}
		}
		return true;
	}
}
