package com.abacogroup.agri.applicationforms.pua.db.dao;

import java.util.List;

import org.jdbi.v3.core.result.ResultIterator;
import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.customizer.BindBean;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;

import com.abacogroup.agri.applicationforms.pua.db.ntt.AttachmentTypeNTT;

/**
 * @author Mauro Pozzana
 */
public interface AttachmentTypeDAO extends IGenericPuaDAO<AttachmentTypeNTT, Long> {

	@Override
	@SqlQuery("§select_nextval(appfpua_attachment_types_id_seq)§")
	Long nextSequenceVal();

	@Override
	@SqlUpdate("INSERT INTO appfpua_attachment_types " +
			"(pkid, " +
			"attachment_group_code, " +
			"tenant_id," +
			"code ) " +
			"VALUES(:pkid, :attachment_group_code, :tenant_id, :type_code)")
	void insert(@BindBean AttachmentTypeNTT ntt);

	@Override
	@SqlUpdate("UPDATE appfpua_attachment_types " +
			"SET attachment_group_code = :attachment_group_code, " +
			"tenant_id = :tenant_id," +
			"code = :type_code " +
			"WHERE pkid = :pkid ")
	void update(@BindBean AttachmentTypeNTT ntt);

	@SqlQuery("SELECT a.pkid, " +
			"a.attachment_group_code, " +
			"a.tenant_id," +
			"a.code as type_code " +
			"FROM appfpua_attachment_types a " +
			"WHERE a.pkid = :id")
	@RegisterBeanMapper(AttachmentTypeNTT.class)
	List<AttachmentTypeNTT> findById(@Bind("id") Long id);

	@SqlUpdate("DELETE FROM appfpua_attachment_types a " +
			" WHERE a.pkid = :id")
	void deleteById(@Bind("id") Long id);

	@SqlQuery("SELECT a.pkid, " +
			"a.attachment_group_code, " +
			"a.tenant_id, " +
			"§i18n(:tenant_id, 'appfpua_attachment_types', 'code', a.code, :lang)§ as code," +
			"a.code as type_code " +
			"FROM appfpua_attachment_types a " +
			"WHERE a.tenant_id = :tenant_id")
	@RegisterBeanMapper(AttachmentTypeNTT.class)
	ResultIterator<AttachmentTypeNTT> findInfiniteByTenantId(@Bind("tenant_id") String tenant, @Bind("lang") String lang);

	@SqlQuery("SELECT a.pkid, " +
			"a.attachment_group_code, " +
			"a.tenant_id, " +
			"§i18n(:tenant_id, 'appfpua_attachment_types', 'code', a.code, :lang)§ as code," +
			"a.code as type_code " +
			"FROM appfpua_attachment_types a " +
			"WHERE a.tenant_id = :tenant_id and a.attachment_group_code =:attachment_group_code")
	@RegisterBeanMapper(AttachmentTypeNTT.class)
	ResultIterator<AttachmentTypeNTT> findInfiniteByTenantIdAttachmentGroup(@Bind("tenant_id") String tenant,
			@Bind("attachment_group_code") String attachmentGroupCode, @Bind("lang") String lang);

	@SqlQuery("SELECT a.pkid, " +
			"a.attachment_group_code, " +
			"a.tenant_id, " +
			"§i18n(:tenant_id, 'appfpua_attachment_types', 'code', a.code, :lang)§ as code," +
			"a.code as type_code " +
			"FROM appfpua_attachment_types a " +
			"WHERE a.tenant_id = :tenant_id and a.attachment_group_code =:attachment_group_code")
	@RegisterBeanMapper(AttachmentTypeNTT.class)
	List<AttachmentTypeNTT> findAllByTenantIdAttachmentGroup(@Bind("tenant_id") String tenant,
			@Bind("attachment_group_code") String attachmentGroupCode, @Bind("lang") String lang);

	@SqlQuery("SELECT a.pkid, " +
			"a.attachment_group_code, " +
			"a.tenant_id, " +
			"a.code as type_code " +
			"FROM appfpua_attachment_types a " +
			"WHERE a.tenant_id = :tenant_id")
	@RegisterBeanMapper(AttachmentTypeNTT.class)
	List<AttachmentTypeNTT> findByTenantId(@Bind("tenant_id") String tenant);

	@SqlQuery("SELECT a.pkid, " +
			  " a.attachment_group_code, " +
			  " §i18n(:tenant_id, 'appfpua_attachment_types', 'code', a.code, :lang)§ as code," +
			  " a.code as type_code, " +
			  " a.tenant_id " +
			  " FROM appfpua_attachment_types a " +
			  " WHERE a.tenant_id = :tenant_id " +
			  " and a.code = :type_code ")
	@RegisterBeanMapper(AttachmentTypeNTT.class)
	List<AttachmentTypeNTT> findByCode(@Bind("tenant_id") String tenant, @Bind("type_code") String typeCode, @Bind("lang") String lang);

	@SqlQuery("SELECT a.pkid, " +
			" a.attachment_group_code, " +
			" §i18n(:tenant_id, 'appfpua_attachment_types', 'code', a.code, :lang)§ as code," +
			" a.code as type_code, " +
			" a.tenant_id " +
			" FROM appfpua_attachment_types a " +
			" WHERE a.tenant_id = :tenant_id " +
			" and a.code = :type_code " +
			" and a.attachment_group_code = :attachment_group_code")
	@RegisterBeanMapper(AttachmentTypeNTT.class)
	List<AttachmentTypeNTT> findByCodeAndAttachmentGroupCode(@Bind("tenant_id") String tenant,
															 @Bind("type_code") String typeCode,
															 @Bind("attachment_group_code") String attachmentGroupCode,
															 @Bind("lang") String lang);

}
