package com.abacogroup.agri.applicationforms.pua.services;

import com.abacogroup.agri.applicationforms.pua.core.exceptions.AgriApplicationFormsRuntimeException;
import com.abacogroup.agri.applicationforms.pua.core.exceptions.InsertExceptionRuntimeException;
import com.abacogroup.agri.applicationforms.pua.core.exceptions.ObjectNotFoundException;
import com.abacogroup.agri.applicationforms.pua.core.exceptions.ObjectNotFoundRuntimeException;
import com.abacogroup.agri.applicationforms.pua.core.mappers.*;
import com.abacogroup.agri.applicationforms.pua.core.model.CompileStatusEnum;
import com.abacogroup.agri.applicationforms.pua.core.model.dto.*;
import com.abacogroup.agri.applicationforms.pua.db.dao.DeclOnCropLiveStocksDAO;
import com.abacogroup.agri.applicationforms.pua.db.dao.DeclOnCropsDAO;
import com.abacogroup.agri.applicationforms.pua.db.ntt.DeclOnCropLiveStocksNTT;
import com.abacogroup.agri.applicationforms.pua.db.ntt.DeclOnCropsNTT;
import com.abacogroup.agri.applicationforms.pua.db.ntt.DeclOnCropsPrevEffluentsNTT;
import com.abacogroup.agri.applicationforms.pua.services.common.ApplicationFacadeService;
import com.abacogroup.agri.applicationforms.pua.services.common.DeclOnCropsSubdata;
import com.abacogroup.agri.applicationforms.pua.services.common.crud.AbstractCrudService;
import com.abacogroup.agri.applicationforms.pua.util.CommonConstants;
import com.abacogroup.agri.applicationforms.pua.util.Filter;
import com.abacogroup.agri.applicationforms.pua.util.FilterHandler;
import com.abacogroup.agri.applicationforms.pua.util.GenericUtility;
import com.abacogroup.applicationworkflowsdk.model.io.output.ApplicationDetailsPublicDTO;
import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.jdbi.criteria.Criteria;
import com.abacogroup.jdbi.criteria.CriteriaBuilder;
import com.abacogroup.jdbi.orderby.OrderBy;
import com.abacogroup.jdbi.orderby.OrderByBuilder;
import com.abacogroup.jdbi.orderby.SortDirection;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import jakarta.validation.constraints.NotNull;
import lombok.extern.slf4j.Slf4j;
import org.jdbi.v3.core.statement.StatementException;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.Instant;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

import static com.abacogroup.agri.applicationforms.pua.util.GenericUtility.throwNotImplementedException;
import static com.abacogroup.agri.applicationforms.pua.util.PagingParamsFactory.DEFAULT_LIMIT;
import static com.abacogroup.agri.applicationforms.pua.util.PagingParamsFactory.DEFAULT_PAGE_SIZE;

/**
 * @author Emanuele Crocilla
 */
@Slf4j
public class DeclOnCropsService extends AbstractCrudService<DeclOnCropsNTT, Long, DeclOnCropsDTO, DeclOnCropsMapper, Void, DeclOnCropsDAO> {

	private final ApplicationFacadeService applicationFacadeService;
	private final BancheDatiService bancheDatiService;
	private DeclOnCropLiveStocksDAO declOnCropLiveStocksDAO;
	private DeclOnCropLiveStockMapper mapperLS;
	private IpisGisService ipisGisService;
	private GiasAgronicaService giasService;

	public DeclOnCropsService(
			DeclOnCropsDAO dao,
			ApplicationFacadeService applicationFacadeService,
			DeclOnCropsMapper mapper,
			DeclOnCropLiveStocksDAO declarationOnCropslsDAO,
			DeclOnCropLiveStockMapper mapperLiveStock,
			BancheDatiService bancheDatiService,
			IpisGisService ipisGisService,
			GiasAgronicaService giasService) {

		super(dao, mapper);
		this.applicationFacadeService = applicationFacadeService;
		this.declOnCropLiveStocksDAO = declarationOnCropslsDAO;
		this.mapperLS = mapperLiveStock;
		this.bancheDatiService = bancheDatiService;
		this.ipisGisService = ipisGisService;
		this.giasService = giasService;
	}

	public List<DeclOnCropsDTO> getAll(User user, String tenant, Long applicationId) {

		applicationFacadeService.callForApplicationDetails(tenant, applicationId, user, Locale.ITALIAN.getLanguage());

		List<DeclOnCropsNTT> ntts = dao.getByApplicationId(applicationId);

		List<DeclOnCropsDTO> dtos = null;

		if (ntts != null) {
			dtos = returnMappedList(ntts);
			return dtos;
		}

		String msg = GenericUtility.formatStr("Unable to find item with application id = {}", applicationId);
		ObjectNotFoundRuntimeException err = new ObjectNotFoundRuntimeException(msg);
		log.warn(msg, err);
		throw err;
	}

	public List<DeclOnCropsDTO> getByIds(User user, String tenant, Long applicationId, List<Long> declarationIds) {

		try {

			ApplicationDetailsPublicDTO applicationDetailsPublicDTO =
					applicationFacadeService.callForApplicationDetails(tenant, applicationId, user, Locale.ITALIAN.getLanguage());
			log.info(applicationDetailsPublicDTO.toString());
			
//			List<DeclOnCropsNTT> ntts = dao.getByIds(new ArrayList<>(declarationIds));// fix EC 12.05.2025 12.40 
			List<DeclOnCropsNTT> ntts = dao.getByApplicationIdAndDeclatationIds(applicationId, declarationIds);
			
			if (ntts != null) {
				log.info("Retrieving of DeclOnCrops completed for tenant and declaration Id = {} ", tenant, applicationId, declarationIds);
				return returnMappedList(ntts);
			}
		} catch (Exception e) {
			String msg = GenericUtility.formatStr(
					"Unable to complete 'get' method due an unhandled error for tenant {}, applicationId {} and declatationId {} ", tenant, applicationId,
					declarationIds);
			log.error(msg, e);
			throw e;
		}

		String msg = GenericUtility.formatStr("Unable to find DeclOnCrops item with tenant = {}, application id = {} and declaration Id = {} ", tenant,
				applicationId, declarationIds);
		ObjectNotFoundRuntimeException err = new ObjectNotFoundRuntimeException(msg);
		log.warn(msg, err);
		throw err;
	}

	public DeclOnCropsDTO get(User user, String tenant, Long applicationId, Long declarationId) {

		try {

			ApplicationDetailsPublicDTO applicationDetailsPublicDTO =
					applicationFacadeService.callForApplicationDetails(tenant, applicationId, user, Locale.ITALIAN.getLanguage());

			log.info(applicationDetailsPublicDTO.toString());

			DeclOnCropsNTT ntt = dao.getByApplicationIdAndDeclatationId(applicationId, declarationId);

			if (ntt != null) {
				log.info("Retrieving of DeclOnCrops completed for tenant and declaration Id = {} ", tenant, applicationId, declarationId);
				return returnOptionalRecord(Collections.singletonList(ntt)).get();
			}
		} catch (Exception e) {
			String msg = GenericUtility.formatStr(
					"Unable to complete 'get' method due an unhandled error for tenant {}, applicationId {} and declatationId {} ", tenant, applicationId,
					declarationId);
			log.error(msg, e);
			throw e;
		}

		String msg = GenericUtility.formatStr("Unable to find DeclOnCrops item with tenant = {}, application id = {} and declaration Id = {} ", tenant,
				applicationId, declarationId);
		ObjectNotFoundRuntimeException err = new ObjectNotFoundRuntimeException(msg);
		log.warn(msg, err);
		throw err;
	}

	public List<DeclOnCropsDTO> insertMany(User user, String tenant, Long applicationId, Long formConfigId, String compileStatusIdentifier,
			List<DeclOnCropsDTO> dtos) {

		try {
			applicationFacadeService.verifyAcceptDispositiveCalls(user, tenant, applicationId, formConfigId);

			if (dtos != null && !dtos.isEmpty()) {

				List<DeclOnCropsNTT> ntts = convert(dtos);
				dao.insertBatch(ntts.toArray(new DeclOnCropsNTT[ntts.size()]));

				List<Long> planIds = new ArrayList<>();
				List<String> declCodes = new ArrayList<>();
				List<String> landUseCodes = new ArrayList<>();

				ntts.forEach(e -> {
					planIds.add(e.getPlanId());
					declCodes.add(e.getDeclCode());
					landUseCodes.add(e.getLandUseCode());
				});
				List<DeclOnCropsNTT> dbRes =
						dao.getByApplicationIdPlanIdDeclCodeLandUseCode(ntts.get(0).getApplicationId(), planIds, declCodes, landUseCodes);

				// double check (we want to be sure to return only just inserted elements)
				List<DeclOnCropsNTT> res = dbRes.stream()
						.filter(item -> dbRes.stream()
								.map(e -> e.getPlanId() + e.getDeclCode() + e.getLandUseCode())
								.collect(Collectors.toSet())
								.contains(item.getPlanId() + item.getDeclCode() + item.getLandUseCode())
						).toList();

				// must be completed after the front-end update of: cycle, typology, precessionCode, yeld
				applicationFacadeService.updateCompileStatus(user, tenant, applicationId, compileStatusIdentifier, CompileStatusEnum.IN_PROGRESS);

				return returnMappedList(res);
			}

			return Collections.emptyList();

		} catch (Exception e) {
			String msg = GenericUtility.formatStr("Unable to complete 'insertMany' method due an error for tenant {}, applicationId {} and formConfigId {}",
					tenant, applicationId, formConfigId);
			log.error(msg, e);
			throw e;
		}
	}

	public DeclOnCropsDTO update(User user, String tenant, Long applicationId, Long formConfigId, String compileStatusIdentifier,
			int cycle, String typology, int precessionCode, int yeld, BigDecimal distributableNum, Long pkId) {

		try {

			applicationFacadeService.verifyAcceptDispositiveCalls(user, tenant, applicationId, formConfigId);

			dao.update(String.valueOf(cycle), typology, precessionCode, yeld, distributableNum, pkId);

			DeclOnCropsNTT dbRes = dao.getByApplicationIdAndDeclatationId(applicationId, pkId);
			var declOnCropsPrevEffluents = dao.declOnCropsByDeclOnCropsByParentId(pkId);
			for (DeclOnCropsPrevEffluentsNTT declOnCropsPrevEffluentsNTT : declOnCropsPrevEffluents) {
				declOnCropsPrevEffluentsNTT.setAppfpuaDeclOnCropsPkid(dbRes.getPkid());
				dao.upsert(declOnCropsPrevEffluentsNTT);
			}
			dbRes.setPreviousEffluents(declOnCropsPrevEffluents);
			DeclOnCropsDTO res = returnOptionalRecord(Collections.singletonList(dbRes)).get();

			applicationFacadeService.updateCompileStatus(user, tenant, applicationId, compileStatusIdentifier, CompileStatusEnum.COMPLETED);

			return res;

		} catch (Exception e) {
			String msg = GenericUtility.formatStr("Unable to complete 'update' method due an error for tenant {}, applicationId {} and formConfigId {}", tenant,
					applicationId, formConfigId);
			log.error(msg, e);
			throw e;
		}
	}

	public List<DeclOnCropsDTO> updateManyDeclOnCropsSubdata(User user, String tenant, Long applicationId, Long formConfigId, String compileStatusIdentifier,
			List<DeclOnCropsSubdata> declOnCropsSubDataelements) {

		List<DeclOnCropsDTO> res = new ArrayList<>();

		try {

			applicationFacadeService.verifyAcceptDispositiveCalls(user, tenant, applicationId, formConfigId);

			var declarationIds = declOnCropsSubDataelements.stream()
					.map(DeclOnCropsSubdata::getPkId)
					.collect(Collectors.toList());

			List<DeclOnCropsNTT> ntts = dao.getByIds(new ArrayList<>(declarationIds));

			Map<Long, DeclOnCropsNTT> declOnCropNttMap = ntts.stream()
					.collect(Collectors.toMap(element -> element.getPkid(), Function.identity()));

			DeclOnCropsNTT declOnCropsNTT = null;

			for (DeclOnCropsSubdata declOnCropsSubdataElem : declOnCropsSubDataelements) {
				declOnCropsNTT = declOnCropNttMap.get(declOnCropsSubdataElem.getPkId());
				declOnCropsNTT.setCycle(declOnCropsSubdataElem.getCycle() + "");
				declOnCropsNTT.setDistributableNitrogen(declOnCropsSubdataElem.getDistributableNum());
				declOnCropsNTT.setPrecessionCode(declOnCropsSubdataElem.getPrecessionCode());
				declOnCropsNTT.setYield(declOnCropsSubdataElem.getYeld());
				declOnCropsNTT.setTypology(declOnCropsSubdataElem.getTypology());

				declOnCropsNTT.setPreviousEffluents(declOnCropsSubdataElem.getPreviousEffluents());
				declOnCropsSubdataElem.setUserIdInsert(declOnCropsNTT.getUserIdInsert());
			}

			if (ntts != null && !ntts.isEmpty()) {

				dao.update(declOnCropsSubDataelements);

				log.info("Updating of DeclOnCrops completed for tenant and declaration Id = {} ", tenant, applicationId, declarationIds);
			}

			res.addAll(returnMappedList(ntts));

			applicationFacadeService.updateCompileStatus(user, tenant, applicationId, compileStatusIdentifier, CompileStatusEnum.COMPLETED);

		} catch (Exception e) {
			String msg = GenericUtility.formatStr("Unable to complete 'update' method due an error for tenant {}, applicationId {} and formConfigId {}", tenant,
					applicationId, formConfigId);
			log.error(msg, e);
			throw e;
		}

		return res;
	}

	//	public boolean delete(User user, String tenant, Long applicationId, Long formConfigId, String compileStatusIdentifier, Long pkid) {
	//
	//		try {
	//			applicationFacadeService.verifyAcceptDispositiveCalls(user, tenant, applicationId, formConfigId);
	//
	//			DeclOnCropsNTT ntt = dao.getByApplicationIdAndDeclatationId(applicationId, pkid);
	//
	//			if (ntt != null) {
	//				dao.expire(applicationId, pkid, OffsetDateTime.now(), user.getUserId());
	//
	//				if (!existsAtLeastOneElement(applicationId)) {
	//					applicationFacadeService.deleteCompileStatus(user, tenant, applicationId, compileStatusIdentifier);
	//				} else {
	//					applicationFacadeService.updateCompileStatus(user, tenant, applicationId, compileStatusIdentifier, CompileStatusEnum.COMPLETED);
	//				}
	//
	//				return true;
	//			} else {
	//				log.debug("Unable to delete DeclOnCrops item with application id = " + applicationId + " and declaration Id = " + pkid);
	//				return false;
	//			}
	//
	//		} catch (Exception e) {
	//			String msg = GenericUtility.formatStr("Unable to complete 'delete' method due an error for tenant {}, applicationId {} and formConfigId {}", tenant,
	//					applicationId, formConfigId);
	//			log.error(msg, e);
	//			throw e;
	//		}
	//	}

	private List<Long> deleteAll(User user, String tenant, Long applicationId, Long formConfigId, String compileStatusIdentifier) {

		try {

			applicationFacadeService.verifyAcceptDispositiveCalls(user, tenant, applicationId, formConfigId);

			List<DeclOnCropsNTT> ntts = dao.getByApplicationId(applicationId);

			List<Long> deletedPkIds = new ArrayList<>();

			if (ntts != null && !ntts.isEmpty()) {

				for (DeclOnCropsNTT ntt : ntts) {
					deletedPkIds.add(ntt.getPkid());
					dao.expire(applicationId, ntt.getPkid(), OffsetDateTime.now(), user.getUserId());
				}
			} else {
				log.debug("Unable to delete DeclOnCrops item with application id = " + applicationId);
			}

			applicationFacadeService.deleteCompileStatus(user, tenant, applicationId, compileStatusIdentifier);

			return deletedPkIds;

		} catch (Exception e) {
			String msg = GenericUtility.formatStr("Unable to complete 'deleteAll' method due an error for tenant {}, applicationId {} and formConfigId {}",
					tenant, applicationId, formConfigId);
			log.error(msg, e);
			throw e;
		}
	}

	// *** CRUD for decl_on_crops_prev_effluents ***

	public DeclOnCropsPrevEffluentsDTO insertPreviousEffluents(User user, String tenant, Long applicationId, Long formConfigId,
			DeclOnCropsPrevEffluentsDTO dto) {

		try {

			applicationFacadeService.verifyAcceptDispositiveCalls(user, tenant, applicationId, formConfigId);

			log.info("Invoking insert with params in: {}", dto);
			DeclOnCropsPrevEffluentsDTO res = this.firstTimeInsertion(dto, user, tenant);

			log.info("Insert of DeclOnCropsPrevEffluents completed for tenant {} applicationId {} formConfigId {}", tenant, applicationId, formConfigId);

			// update appfpua_decl_on_crops.tot_residual_nitrogen value (of the parent table)
			//	Double newTotResidualNuber = dao.getSumOfTotResidualNuberByAllDeclOnCropsPrevEffluents(dto.getParentId());
			//	newTotResidualNuber = GenericUtility.getValueOrDefaultWhenIsNull(newTotResidualNuber, 0D);
			//	dao.updateTotResidualNumber(dto.getParentId(), newTotResidualNuber);

			return res;
		} catch (Exception e) {

			String msg = GenericUtility.formatStr("Unable to complete 'insert' method due an error for tenant {} applicationId {} formConfigId {}", tenant,
					applicationId, formConfigId);
			log.error(msg, e);
			throw e;
		}
	}

	public DeclOnCropsPrevEffluentsDTO updateDeclOnCropsPrevEffluents(User user, String tenant, Long applicationId,
			Long formConfigId/*, String compileStatusIdentifier*/, DeclOnCropsPrevEffluentsDTO dto) throws Exception {

		try {

			applicationFacadeService.verifyAcceptDispositiveCalls(user, tenant, applicationId, formConfigId);
			DeclOnCropsPrevEffluentsMapper localMapper = new DeclOnCropsPrevEffluentsMapperImpl();

			DeclOnCropsPrevEffluentsNTT ntt = localMapper.dtoToEntity(dto);
			validateEffluentNtt(ntt, user, tenant);
			dao.upsert(ntt);

			DeclOnCropsPrevEffluentsNTT newNtt = dao.findDeclOnCropsPrevEffluentsById(dto.getId())
					.stream()
					.findFirst()
					.orElseThrow(OBJECT_NOT_FOUND_EXCEPTION_SUPPLIER);

			DeclOnCropsPrevEffluentsDTO res = GenericUtility.transformIfPresent(newNtt, localMapper::entityToDto).get();

			// update appfpua_decl_on_crops.tot_residual_nitrogen value (of the parent table)
			//			Double newTotResidualNuber = dao.getSumOfTotResidualNuberByAllDeclOnCropsPrevEffluents(dto.getParentId());
			//			newTotResidualNuber = GenericUtility.getValueOrDefaultWhenIsNull(newTotResidualNuber, 0D);
			dao.updateTotResidualNitrogen(dto.getParentId(), ntt.getResidualNitrogen().doubleValue());

			return res;

		} catch (Exception e) {
			String msg = GenericUtility.formatStr("Unable to complete 'update' method due an error for tenant {}, applicationId {} and formConfigId {}", tenant,
					applicationId, formConfigId);
			log.error(msg, e);
			throw e;
		}
	}

	private void validateEffluentNtt(DeclOnCropsPrevEffluentsNTT ntt, User user, String tenant) {
		var effluents = bancheDatiService.getEffluents(user, tenant);
		var effluent = effluents.stream().filter(x -> x.getCode().equals(ntt.getEffluent())).findFirst().orElse(null);
		if (effluent == null) {
			throw new RuntimeException("Not able to find Effluents with code:" + ntt.getEffluent());
		}
		ntt.setMeasurementUnit(effluent.getDescriptionUom()); // Default value
		var efFrequencies = bancheDatiService.getEffluentFrequencies(user, tenant, effluent.getCode());
		if (efFrequencies == null) {
			throw new RuntimeException("Not able to find Effluent Frequencies with code:" + ntt.getEffluent());
		}
		var efFrequency = efFrequencies.stream().filter(x -> x.getCode().equals(ntt.getFrequency())).findFirst().orElse(null);
		if (efFrequency == null) {
			throw new RuntimeException("Not able to find Effluent Frequency with code:" + ntt.getEffluent());
		}
		ntt.setReduction(BigDecimal.valueOf(efFrequency.getNitrogen()));
		BigDecimal residualNr = ntt.getQuantity()
				.multiply(ntt.getNitrogenContent())
				.multiply(BigDecimal.valueOf(efFrequency.getNitrogen()));
		ntt.setResidualNitrogen(residualNr.setScale(4, RoundingMode.DOWN));
	}

	public boolean deleteDeclOnCropsPrevEffluentsById(User user, String tenant, Long applicationId, Long formConfigId, Long previousEffluentOnCropsId) {

		try {

			applicationFacadeService.verifyAcceptDispositiveCalls(user, tenant, applicationId, formConfigId);

			DeclOnCropsPrevEffluentsNTT ntt = dao.findDeclOnCropsPrevEffluentsById(previousEffluentOnCropsId)
					.stream()
					.findFirst()
					.orElse(null);

			if (ntt != null) {

				Long parentId = ntt.getAppfpuaDeclOnCropsPkid();

				dao.expireDeclOnCropsPrevEffluentsByDeclarationId(previousEffluentOnCropsId, OffsetDateTime.now(), user.getUserId());

				// update appfpua_decl_on_crops.tot_residual_nitrogen value (of the parent table)
				Double newTotResidualNuber = dao.getSumOfTotResidualNuberByAllDeclOnCropsPrevEffluents(parentId);
				newTotResidualNuber = GenericUtility.getValueOrDefaultWhenIsNull(newTotResidualNuber, 0D);
				dao.updateTotResidualNitrogen(parentId, newTotResidualNuber);

				return true;
			} else {

				log.debug("Unable to delete DeclOnCropsPrevEffluents item with application id = " +
						applicationId + " and previousEffluentOnCrops Id = " + previousEffluentOnCropsId);

				return false;
			}

		} catch (Exception e) {
			String msg = GenericUtility.formatStr("Unable to complete 'delete' method due an error for tenant {}, applicationId {} and formConfigId {}", tenant,
					applicationId, formConfigId);
			log.error(msg, e);
			throw e;
		}
	}

	public void deleteAllDeclOnCropsPrevEffluentsByParentIds(User user, String tenant, Long applicationId, Long formConfigId, Long... parentIds) {
		this.deleteAllDeclOnCropsPrevEffluentsByParentIds(user, tenant, applicationId, formConfigId, Arrays.asList(parentIds));
	}

	public void deleteAllDeclOnCropsPrevEffluentsByParentIds(User user, String tenant, Long applicationId, Long formConfigId, List<Long> parentIds) {

		try {

			applicationFacadeService.verifyAcceptDispositiveCalls(user, tenant, applicationId, formConfigId);

			parentIds.forEach(parentId -> {

				List<DeclOnCropsPrevEffluentsNTT> ntts = dao.findDeclOnCropsPrevEffluentsByParentId(parentId);

				if (ntts != null && !ntts.isEmpty()) {

					ntts.forEach(ntt -> dao.expireDeclOnCropsPrevEffluentsByDeclarationId(
							ntt.getPreviousEffluentOnCropsId(), OffsetDateTime.now(), user.getUserId()));

				} else {
					log.debug("Unable to delete DeclOnCropsPrevEffluents item with application id = " + applicationId + " and parentId Id = " + parentId);
				}
			});

		} catch (Exception e) {
			String msg = GenericUtility.formatStr("Unable to complete 'delete' method due an error for tenant {}, applicationId {} and formConfigId {}", tenant,
					applicationId, formConfigId);
			log.error(msg, e);
			throw e;
		}
	}

	public boolean deleteAllDeclOnCropsPrevEffluentsByParentId(User user, String tenant, Long applicationId, Long formConfigId, Long parentId) {

		try {

			applicationFacadeService.verifyAcceptDispositiveCalls(user, tenant, applicationId, formConfigId);

			List<DeclOnCropsPrevEffluentsNTT> ntts = dao.findDeclOnCropsPrevEffluentsByParentId(parentId);

			if (ntts != null && !ntts.isEmpty()) {

				ntts.forEach(ntt -> dao.expireDeclOnCropsPrevEffluentsByDeclarationId(ntt.getPkid(), OffsetDateTime.now(), user.getUserId()));

				return true;
			} else {

				log.debug("Unable to delete DeclOnCropsPrevEffluents item with application id = " + applicationId + " and parentId Id = " + parentId);
				return false;
			}

		} catch (Exception e) {
			String msg = GenericUtility.formatStr("Unable to complete 'delete' method due an error for tenant {}, applicationId {} and formConfigId {}", tenant,
					applicationId, formConfigId);
			log.error(msg, e);
			throw e;
		}
	}

	public void deleteDeclOnCropsHierarchy(User user, @NotNull String tenantId, @NotNull Long applicationId,
			@NotNull Long formConfigId, String compileStatusIdentifier) {
		List<Long> deletedIds = this.deleteAll(user, tenantId, applicationId, formConfigId, compileStatusIdentifier);
		this.deleteAllDeclOnCropsPrevEffluentsByParentIds(user, tenantId, applicationId, formConfigId, deletedIds);
	}

	// *** private methods ***

	@Override
	protected boolean hasPrimaryKey() {
		return true;
	}

	@Override
	protected void deleteByCustomKey(Void customKey) {
		throw throwNotImplementedException.get();
	}

	@Override
	protected void setCustomSearchKey(DeclOnCropsNTT rs, Void customKey) {
		throw throwNotImplementedException.get();
	}

	@Override
	protected Optional<DeclOnCropsNTT> findRsByCustomKey(Void customKey) {
		return Optional.empty();
	}

	private List<DeclOnCropsNTT> convert(List<DeclOnCropsDTO> dtos) {
		DeclOnCropsNTT ntt = null;
		List<DeclOnCropsNTT> ntts = new ArrayList<>();

		for (DeclOnCropsDTO dto : dtos) {
			ntt = DeclOnCropsMapper.INSTANCE.dtoToEntity(dto);
			ntts.add(ntt);
		}

		return ntts;
	}

	private boolean existsAtLeastOneElement(Long applicationId) {
		return dao.count(applicationId) > 0;
	}

	protected DeclOnCropsPrevEffluentsDTO firstTimeInsertion(DeclOnCropsPrevEffluentsDTO dtoIn, User user, String tenant) {
		return dao.inTransaction(handle -> {
			try {

				DeclOnCropsPrevEffluentsMapper localMapper = new DeclOnCropsPrevEffluentsMapperImpl();

				Long pkId = dao.nextSequencePevEffluentsVal();
				DeclOnCropsPrevEffluentsNTT rs = localMapper.dtoToEntity(dtoIn);

				// ID is set as pkId only for the first time (previousEffluentOnCropsID never change in updates)
				rs.setPkid(pkId);
				rs.setPreviousEffluentOnCropsId(pkId);
				validateEffluentNtt(rs, user, tenant);
				dao.insert(rs);

				return dao.findDeclOnCropsPrevEffluentsById(pkId)
						.stream()
						.findFirst()
						.map(localMapper::entityToDto)
						.orElseThrow(OBJECT_NOT_FOUND_EXCEPTION_SUPPLIER);

			} catch (StatementException e) {
				log.error(e.getMessage(), e);
				throw new InsertExceptionRuntimeException("error during insert");
			} catch (ObjectNotFoundException e) {
				throw new ObjectNotFoundRuntimeException();
			} catch (Exception e) {
				throw new AgriApplicationFormsRuntimeException(e.getMessage());
			}
		});
	}

	// TODO USE AS EXAMPLE (modify this, create an appropriate DTO, NTT, etc)

	public DeclOnCropLiveStocksDTO insertLivestockConsist(User user, String tenant, Long applicationId, String compileStatusIdentifier,
			Long formConfigId, DeclOnCropLiveStocksDTO dto) throws ObjectNotFoundException {
		try {

			applicationFacadeService.verifyAcceptDispositiveCalls(user, tenant, applicationId, formConfigId);

			List<Specie> species = bancheDatiService.getSpecies(user, tenant);
			var cs = species.stream().filter(x -> (x.getGenreCode() + "_" + x.getCode()).equals(dto.getSpecies())).findFirst().orElse(null);
			if (cs == null) {
				throw new RuntimeException("Can not find this specie animale, Specie:" + dto.getSpecies());
			}
			List<AnimalCategory> categories = bancheDatiService.getAnimalCategory(user, tenant, cs.getGenreCode(), cs.getCode());
			var category = categories.stream().filter(x -> x.getCode().equals(extractCategoryCodeValue(dto.getCategory()))
							&& x.getProductionCode().equals(extractProductionCodeValue(dto.getCategory()))
							&& (x.getGenreCode() + "_" + x.getSpecieCode()).equals(dto.getSpecies())).findFirst()
					.orElse(null);
			if (category == null) {
				throw new RuntimeException("Can not find this category animale, Category:" + extractCategoryCodeValue(dto.getCategory()));
			}
			List<AnimalHousing> animalHousings = bancheDatiService.getAnimalHousing(user, tenant, category.getGenreCode(), category.getSpecieCode(),
					category.getCode(), category.getProductionCode());
			validateDTO(species, category, animalHousings, dto);
			DeclOnCropLiveStocksNTT entity = mapperLS.dtoToEntity(dto);
			Long pkId = this.retrievePrimaryKey(null);
			entity.setPkid(pkId);
			entity.setApplicationId(applicationId);
			entity.setGenreCode(category.getGenreCode());
			entity.setProductionCode(category.getProductionCode());
			declOnCropLiveStocksDAO.insert(entity);

			applicationFacadeService.updateCompileStatus(user, tenant, applicationId, compileStatusIdentifier, CompileStatusEnum.COMPLETED);

			return declOnCropLiveStocksDAO.findById(entity.getPkid())
					.stream()
					.findFirst()
					.map(mapperLS::entityToDto)
					.orElseThrow(OBJECT_NOT_FOUND_EXCEPTION_SUPPLIER);

		} catch (Exception e) {
			String msg = GenericUtility.formatStr("Unable to complete 'insert' method due an error for tenant {} applicationId {} formConfigId {}", tenant,
					applicationId, formConfigId);
			log.error(msg, e);
			throw e;
		}
	}

	private void validateDTO(List<Specie> species, AnimalCategory category, List<AnimalHousing> animalHousings, DeclOnCropLiveStocksDTO dto) {
		if (dto.getSpecies().isEmpty()
				|| species.stream().filter(x -> (x.getGenreCode() + "_" + x.getCode()).equals(dto.getSpecies())).findFirst().orElse(null) == null) {
			throw new RuntimeException("Can not find this specie animale, specie:" + dto.getSpecies());
		}
		var animalHouse = animalHousings.stream().filter(x -> x.getCode().equals(dto.getTypeStabling())).findFirst().orElse(null);
		if (animalHouse == null) {
			throw new RuntimeException("Can not find this animale house, Code:" + dto.getTypeStabling());
		}
		//Check disabled values
		//Category
		dto.setNumberField(category.getNitrogenPV());
		dto.setAveragePV(category.getAverageWeight());
		//format category before save
		dto.setCategory(
				animalHouse.getGenreCode() + "_" + animalHouse.getSpecieCode() + "_" + animalHouse.getCategoryCode() + "_" + animalHouse.getProductionCode());
		//Animal house
		//dto.setSewageOutlet(animalHouse.getSewageSludge());
		//dto.setManureOrShovelableOutput(animalHouse.getShovellableT());
	}

	public boolean deleteLiveStock(User user, String tenant, Long applicationId, String compileStatusIdentifier, Long formConfigId, Long pkid) {

		try {
			applicationFacadeService.verifyAcceptDispositiveCalls(user, tenant, applicationId, formConfigId);
			var exist = declOnCropLiveStocksDAO.findById(pkid);
			if (exist != null) {
				declOnCropLiveStocksDAO.delete(pkid, OffsetDateTime.now(), user.getUserId());
				if (!existsAtLeastOneLiveStockElement(applicationId)) {
					applicationFacadeService.deleteCompileStatus(user, tenant, applicationId, compileStatusIdentifier);
				} else {
					applicationFacadeService.updateCompileStatus(user, tenant, applicationId, compileStatusIdentifier, CompileStatusEnum.COMPLETED);
				}
				return true;
			} else {
				log.debug("Unable to delete DeclOnCropsLivestocks item with application id = " + applicationId + " and Crop Plan Live Stock Id = " + pkid);
				return false;
			}
		} catch (Exception e) {
			String msg = GenericUtility.formatStr("Unable to complete 'delete' method due an error for tenant {}, applicationId {} and formConfigId {}", tenant,
					applicationId, formConfigId);
			log.error(msg, e);
			throw e;
		}
	}

	public List<DeclOnCropLiveStocksDTO> getAllDeclOnCropsLivestockConsist(User user, String tenant, Long applicationId) {

		applicationFacadeService.callForApplicationDetails(tenant, applicationId, user, Locale.ITALIAN.getLanguage());

		List<DeclOnCropLiveStocksNTT> ntts = dao.getDeclOnCropsPrevLivestockConsistByApplicationId(applicationId);

		if (ntts != null) {
			DeclOnCropLiveStockMapper localMapper = new DeclOnCropLiveStockMapperImpl();
			return GenericUtility.returnMappedList(ntts, localMapper::entityToDto);
		}

		String msg = GenericUtility.formatStr("Unable to find DeclOnCropsPrevLivestockConsistence elements by application id = {}", applicationId);
		ObjectNotFoundRuntimeException err = new ObjectNotFoundRuntimeException(msg);
		log.warn(msg, err);
		throw err;
	}

	public DeclOnCropLiveStocksDTO updateLiveStock(User user, String tenant, Long applicationId, Long formConfigId, String compileStatusIdentifier,
			DeclOnCropLiveStocksDTO dto) {

		try {

			applicationFacadeService.verifyAcceptDispositiveCalls(user, tenant, applicationId, formConfigId);
			List<Specie> species = bancheDatiService.getSpecies(user, tenant);
			var cs = species.stream().filter(x -> (x.getGenreCode() + "_" + x.getCode()).equals(dto.getSpecies())).findFirst().orElse(null);
			if (cs == null) {
				throw new RuntimeException("Can not find this specie animale, Specie:" + dto.getSpecies());
			}
			List<AnimalCategory> categories = bancheDatiService.getAnimalCategory(user, tenant, cs.getGenreCode(), cs.getCode());
			var category = categories.stream().filter(x -> x.getCode().equals(extractCategoryCodeValue(dto.getCategory()))
							&& x.getProductionCode().equals(extractProductionCodeValue(dto.getCategory()))
							&& (x.getGenreCode() + "_" + x.getSpecieCode()).equals(dto.getSpecies())).findFirst()
					.orElse(null);
			if (category == null) {
				throw new RuntimeException("Can not find this category animale, Category:" + extractCategoryCodeValue(dto.getCategory()));
			}
			List<AnimalHousing> animalHousings = bancheDatiService.getAnimalHousing(user, tenant, category.getGenreCode(), category.getSpecieCode(),
					category.getCode(), category.getProductionCode());
			validateDTO(species, category, animalHousings, dto);
			DeclOnCropLiveStocksNTT ntt = mapperLS.dtoToEntity(dto);
			ntt.setGenreCode(category.getGenreCode());
			ntt.setProductionCode(category.getProductionCode());
			var pkId = this.retrievePrimaryKey(null);
			declOnCropLiveStocksDAO.upsert(ntt, pkId);

			var newNtt = declOnCropLiveStocksDAO.getByApplicationIdAndDeclatationId(ntt.getApplicationId(), ntt.getPkid());

			DeclOnCropLiveStocksDTO res = returnLiveStocMappedRecords(Collections.singletonList(newNtt)).get();

			applicationFacadeService.updateCompileStatus(user, tenant, applicationId, compileStatusIdentifier, CompileStatusEnum.COMPLETED);

			return res;

		} catch (Exception e) {
			String msg = GenericUtility.formatStr("Unable to complete 'update' method due an error for tenant {}, applicationId {} and formConfigId {}", tenant,
					applicationId, formConfigId);
			log.error(msg, e);
			throw e;
		}
	}

	public String extractCategoryCodeValue(String input) {
		if (input == null || input.trim().isEmpty()) {
			return null;
		}
		String[] parts = input.split("_");
		if (parts.length < 3) { //3 is code
			return null;
		}
		try {
			return parts[2];
		} catch (NumberFormatException e) {
			return null;
		}
	}

	public String extractProductionCodeValue(String input) {
		if (input == null || input.trim().isEmpty()) {
			return null;
		}
		String[] parts = input.split("_");
		if (parts.length < 3) { //3 is productionCode
			return null;
		}
		try {
			return parts[3];
		} catch (NumberFormatException e) {
			return null;
		}
	}

	protected Optional<DeclOnCropLiveStocksDTO> returnLiveStocMappedRecords(List<DeclOnCropLiveStocksNTT> recordList) {
		return GenericUtility.returnOptionalFromList(recordList, mapperLS::entityToDto);
	}

	private boolean existsAtLeastOneLiveStockElement(Long applicationId) {
		return declOnCropLiveStocksDAO.count(applicationId) > 0;
	}

	//Declaration On Crop
	public DeclOnCropsDTO updateDeclarationOnCrop(User user, @NotNull String tenant, @NotNull Long applicationId,
			@NotNull Long formConfigId, String compileStatusIdentifier, @NotNull DeclOnCropsDTO payload, @NotNull Long declId) {

		try {

			applicationFacadeService.verifyAcceptDispositiveCalls(user, tenant, applicationId, formConfigId);
			var entity = dao.declOnCropsByApplicationIdAndDeclatationId(applicationId, declId);
			if (entity == null) {
				String msg = GenericUtility.formatStr("Not able to find declaration on crop with id {} and applicationid {} ", declId,
						applicationId);
				throw new RuntimeException(msg);
			}
			payload.setTotResidualNitrogen(BigDecimal.ZERO);
			payload.setDistributableNitrogen(BigDecimal.ZERO);
			if (payload.getLandUseCode() == null) {
				payload.setLandUseCode(entity.getLandUseCode());
			}
			calculateFabisognoAndResidualNR(user, tenant, payload);
			var ntt = mapper.dtoToEntity(payload);
			ntt.setPkid(declId);
			ntt.setApplicationId(applicationId);
			//nullable fields
			ntt.setPlanId(entity.getPlanId());
			ntt.setDeclCode(entity.getDeclCode());
			ntt.setPlotCode(entity.getPlotCode());
			ntt.setVersion(entity.getVersion());

			//
			dao.upsertDcl(ntt);
			DeclOnCropsNTT dbRes = dao.getDeclOnCropsById(ntt.getPkid());

			// update its previous effluents
			var declOnCropsPrevEffluents = dao.declOnCropsByDeclOnCropsByParentId(declId);
			for (DeclOnCropsPrevEffluentsNTT declOnCropsPrevEffluentsNTT : declOnCropsPrevEffluents) {
				declOnCropsPrevEffluentsNTT.setAppfpuaDeclOnCropsPkid(ntt.getPkid());
				dao.upsert(declOnCropsPrevEffluentsNTT);
			}
			dbRes.setPreviousEffluents(declOnCropsPrevEffluents);

			DeclOnCropsDTO res = returnOptionalRecord(Collections.singletonList(dbRes)).get();

			applicationFacadeService.updateCompileStatus(user, tenant, applicationId, compileStatusIdentifier, CompileStatusEnum.COMPLETED);
			return res;

		} catch (Exception e) {
			String msg = GenericUtility.formatStr("Unable to complete 'update' method due an error for tenant {}, applicationId {} and formConfigId {}", tenant,
					applicationId, formConfigId);
			log.error(msg, e);
			throw e;
		}
	}

	public List<DeclOnCropsDTO> updateManyDeclarationsOnCrop(User user, @NotNull String tenant, @NotNull Long applicationId,
			@NotNull Long formConfigId, String compileStatusIdentifier, @NotNull List<DeclOnCropsDTO> payloads,
			@NotNull List<Long> declIds) {

		try {

			applicationFacadeService.verifyAcceptDispositiveCalls(user, tenant, applicationId, formConfigId);

			List<DeclOnCropsNTT> ntts = new ArrayList<>();

			//			DeclOnCropsNTT dbRes = null;

			int index = 0;
			Long declId = 0L;

			DeclOnCropsPrevEffluentsMapper localMapper = new DeclOnCropsPrevEffluentsMapperImpl();

			for (DeclOnCropsDTO payload : payloads) {

				declId = declIds.get(index++);

				var entity = dao.declOnCropsByApplicationIdAndDeclatationId(applicationId, declId);

				if (entity == null) {

					String msg = GenericUtility.formatStr("Not able to find declaration on crop with id {} and applicationid {} ", declId,
							applicationId);

					throw new RuntimeException(msg);
				}

				payload.setTotResidualNitrogen(BigDecimal.ZERO);
				payload.setDistributableNitrogen(BigDecimal.ZERO);

				if (payload.getLandUseCode() == null) {
					payload.setLandUseCode(entity.getLandUseCode());
				}

				calculateFabisognoAndResidualNR(user, tenant, payload);
				var ntt = mapper.dtoToEntity(payload);
				ntt.setPkid(declId);
				ntt.setApplicationId(applicationId);

				//nullable fields
				ntt.setPlanId(entity.getPlanId());
				ntt.setDeclCode(entity.getDeclCode());
				ntt.setPlotCode(entity.getPlotCode());
				ntt.setVersion(entity.getVersion());

				List<DeclOnCropsPrevEffluentsNTT> effluents = new ArrayList<>();

				for (DeclOnCropsPrevEffluentsDTO eff : payload.getPreviousEffluents()) {
					effluents.add(localMapper.dtoToEntity(eff));
				}

				ntts.add(ntt);
			}

			dao.upsertManyDcl(ntts);

			//			var newPkIds = ntts.stream()
			//					.map(DeclOnCropsNTT::getPkid)
			//					.collect(Collectors.toList());

			//			var dbRes = dao.getDeclOnCropsByIds(newPkIds);

			//			List<DeclOnCropsDTO> res = returnMappedList(dbRes);
			//			List<DeclOnCropsDTO> res = getByIds(user, tenant, applicationId, newPkIds);

			applicationFacadeService.updateCompileStatus(user, tenant, applicationId, compileStatusIdentifier, CompileStatusEnum.COMPLETED);

			return returnMappedList(ntts);

		} catch (Exception e) {
			String msg = GenericUtility.formatStr("Unable to complete 'update' method due an error for tenant {}, applicationId {} and formConfigId {}", tenant,
					applicationId, formConfigId);
			log.error(msg, e);
			throw e;
		}
	}

	public DeclOnCropsDTO insertDeclarationOnCrop(User user, @NotNull String tenant, @NotNull Long applicationId, @NotNull Long formConfigId,
			String compileStatusIdentifier, @NotNull DeclOnCropsDTO payload) {
		try {
			applicationFacadeService.verifyAcceptDispositiveCalls(user, tenant, applicationId, formConfigId);
			Boolean checkIfExistAutomaticRecord = checkIfExistAutomaticRecord(user, tenant, applicationId);
			if (checkIfExistAutomaticRecord) {
				String msg = GenericUtility.formatStr(
						"Unable to complete 'insert' because has been automatic imported before, tenant {}, applicationId {} and formConfigId {} ", tenant,
						applicationId, formConfigId);
				throw new RuntimeException(msg);
			}

			payload.setTotResidualNitrogen(BigDecimal.ZERO);
			payload.setDistributableNitrogen(BigDecimal.ZERO);
			calculateFabisognoAndResidualNR(user, tenant, payload);

			var ntt = mapper.dtoToEntity(payload);
			//nullable fields
			ntt.setPlanId(null);
			ntt.setDeclCode(null);
			ntt.setPlotCode(null);
			ntt.setVersion(null);

			ntt.setApplicationId(applicationId);
			Long pkId = this.retrievePrimaryKey(null);
			ntt.setPkid(pkId);
			dao.insertDeclOnCrop(ntt);
			if (payload.getPreviousEffluents() != null && !payload.getPreviousEffluents().isEmpty()) {
				long rightNow = Calendar.getInstance().getTimeInMillis();
				Instant instantRightNow = Instant.ofEpochMilli(rightNow);
				OffsetDateTime dateTimeRightNow = instantRightNow.atOffset(ZoneOffset.UTC);
				payload.getPreviousEffluents().forEach(e -> {
					e.setParentId(ntt.getPkid());
					e.setUserIdInsert(user.getUserId());
					e.setDtInsert(dateTimeRightNow);
					e.setDtDelete(CommonConstants.FAR_OFF_DATE);
					insertPreviousEffluents(user, tenant, applicationId, formConfigId, e);
				});
			}

			applicationFacadeService.updateCompileStatus(user, tenant, applicationId, compileStatusIdentifier, CompileStatusEnum.COMPLETED);

			return get(user, tenant, applicationId, ntt.getPkid());

		} catch (Exception e) {
			String msg = GenericUtility.formatStr("Unable to complete 'update' method due an error for tenant {}, applicationId {} and formConfigId {}", tenant,
					applicationId, formConfigId);
			log.error(msg, e);
			throw new RuntimeException(e);
		}
	}

	private void calculateFabisognoAndResidualNR(User user, String tenant, DeclOnCropsDTO payload) {
		if (payload.getPreviousEffluents() != null && !payload.getPreviousEffluents().isEmpty()) {
			var totres = payload.getPreviousEffluents()
					.stream()
					.filter(x -> x.getResidualNitrogen() != null)
					.mapToDouble(x -> x.getResidualNitrogen().doubleValue())
					.sum();
			payload.setTotResidualNitrogen(BigDecimal.valueOf(totres));
		}
		var declCode = payload.getDeclCode() == null ? "0" : payload.getDeclCode();
		var fabbisognoResponseDati = bancheDatiService.getFabbisognoResponseDati(user,
				tenant,
				payload.getLandUseCode(),
				declCode,
				payload.getTypology(),
				payload.getYield(),
				payload.getPrecessionCode(),
				payload.getTotResidualNitrogen());
		if (fabbisognoResponseDati != null && !fabbisognoResponseDati.getListaFabbisogni().isEmpty()) {
			var sumOfDistribNitrogen = fabbisognoResponseDati.getListaFabbisogni().stream().mapToDouble(x -> x.getNFabbisogno()).sum();
			payload.setDistributableNitrogen(BigDecimal.valueOf( sumOfDistribNitrogen ));
		}
	}

	public List<DeclOnCropsDTO> insertDeclarationsOnCrops(User user, @NotNull String tenant, @NotNull Long applicationId, @NotNull Long formConfigId,
			String compileStatusIdentifier, @NotNull List<DeclOnCropsDTO> payloads) {

		try {
			// Verify if dispositive calls are accepted
			applicationFacadeService.verifyAcceptDispositiveCalls(user, tenant, applicationId, formConfigId);
			Boolean checkIfExistAutomaticRecord = checkIfExistAutomaticRecord(user, tenant, applicationId);
			if (checkIfExistAutomaticRecord) {
				String msg = GenericUtility.formatStr(
						"Unable to complete 'insert' because it was automatically imported before. Tenant {}, ApplicationId {}, FormConfigId {}",
						tenant, applicationId, formConfigId);
				throw new RuntimeException(msg);
			}

			DeclOnCropsPrevEffluentsMapper localMapper = new DeclOnCropsPrevEffluentsMapperImpl();
			List<DeclOnCropsDTO> insertedRecords = new ArrayList<>();

			DeclOnCropsNTT[] entities = payloads.stream()
					.map(payload -> {
						var ntt = mapper.dtoToEntity(payload);
						// Nullable fields
						ntt.setPlanId(null);
						ntt.setDeclCode(null);
						ntt.setPlotCode(null);
						ntt.setVersion(null);
						// Set application ID
						ntt.setApplicationId(applicationId);
						// Generate unique primary key for each
						ntt.setPkid(this.retrievePrimaryKey(null));
						return ntt;
					})
					.toArray(DeclOnCropsNTT[]::new);

			dao.insertBatch(entities);
			for (DeclOnCropsNTT entity : entities) {
				insertedRecords.add(mapper.entityToDto(dao.getDeclOnCropsById(entity.getPkid())));
			}

			applicationFacadeService.updateCompileStatus(user, tenant, applicationId, compileStatusIdentifier, CompileStatusEnum.COMPLETED);

			return insertedRecords;

		} catch (Exception e) {
			String msg = GenericUtility.formatStr(
					"Unable to complete 'insert' due to an error for Tenant {}, ApplicationId {}, and FormConfigId {}",
					tenant, applicationId, formConfigId);
			log.error(msg, e);
			throw new RuntimeException(e);
		}
	}

	public boolean deleteDeclOnCropAndItsPrevEffluents(User user, String tenant, Long applicationId, String compileStatusIdentifier, Long formConfigId,
			Long pkid) {
		try {
			applicationFacadeService.verifyAcceptDispositiveCalls(user, tenant, applicationId, formConfigId);
			var exist = dao.getDeclOnCropsById(pkid);

			if (exist != null) {
				if (exist.getDeclCode() != null || exist.getPlotCode() != null || exist.getPlanId() != null || exist.getVersion() != null) {
					String msg = GenericUtility.formatStr(
							"Unable to complete 'delete' because is a automatic import, tenant {}, applicationId {} and formConfigId {} ", tenant,
							applicationId, formConfigId);
					throw new RuntimeException(msg);
				}

				dao.expire(applicationId, pkid, OffsetDateTime.now(), user.getUserId());
				this.deleteAllDeclOnCropsPrevEffluentsByParentIds(user, tenant, applicationId, formConfigId, pkid);

				if (!existsAtLeastOneElement(applicationId)) {
					applicationFacadeService.deleteCompileStatus(user, tenant, applicationId, compileStatusIdentifier);
				}

				return true;
			} else {
				log.debug("Unable to delete DeclOnCropsLivestocks item with application id = " + applicationId + " and Crop Plan Live Stock Id = " + pkid);
				return false;
			}
		} catch (Exception e) {
			String msg = GenericUtility.formatStr("Unable to complete 'delete' method due an error for tenant {}, applicationId {} and formConfigId {}", tenant,
					applicationId, formConfigId);
			log.error(msg, e);
			throw e;
		}
	}

	public Boolean checkIfExistAutomaticRecord(User user, @NotNull String tenant, @NotNull Long applicationId) {
		return dao.existsPartialValidEntries(applicationId);
	}

	public InfiniteListResults<DeclOnCropsDTO> searchDeclOnCropsByFilter(User user, String tenant, Long applicationId, Map<String, String[]> params,
			String nextKey) {

		log.info("Invoking searchDeclOnCropsByFilter by application id with params tenant: {}, applicationId: {} ", tenant, applicationId);

		try {

			ApplicationDetailsPublicDTO applicationDetailsPublicDTO =
					applicationFacadeService.callForApplicationDetails(tenant, applicationId, user, Locale.ITALIAN.getLanguage());

			log.info(applicationDetailsPublicDTO.toString());

			log.info("Retrieving of DeclOnCrops completed for tenant {} ", tenant);

			Map<String, String> paramNameTranslationsForDB = new HashMap<>();
			paramNameTranslationsForDB.put("planId", "plan_id");
			paramNameTranslationsForDB.put("plotCode", "plot_code");
			paramNameTranslationsForDB.put("declCode", "decl_code");
			paramNameTranslationsForDB.put("landUseCode", "land_use_code");
			paramNameTranslationsForDB.put("flZvn", "fl_zvn");
			paramNameTranslationsForDB.put("areaSqm", "area_sqm");
			paramNameTranslationsForDB.put("cropDuration", "crop_duration");
			paramNameTranslationsForDB.put("plantStatus", "plant_status");
			paramNameTranslationsForDB.put("sectorCode", "sector_code");
			paramNameTranslationsForDB.put("mas", "mas");
			paramNameTranslationsForDB.put("precessionCode", "precession_code");
			paramNameTranslationsForDB.put("totResidualNitrogen", "tot_residual_nitrogen");
			paramNameTranslationsForDB.put("distributableNitrogen", "distributable_nitrogen");
			paramNameTranslationsForDB.put("declarationVersion", "version");

			Filter filter = FilterHandler.createFilterByParamsExistingInClass(params, DeclOnCropsDTO.class, paramNameTranslationsForDB);

			// set the default order if the front-end does not set one
			if (filter.getOrderBy() == null) {
				OrderBy orderBy = OrderByBuilder.from(
						OrderByBuilder.field("sector_code").direction(SortDirection.ASC),
						OrderByBuilder.field("land_use_code").direction(SortDirection.ASC),
						OrderByBuilder.field("area_sqm").direction(SortDirection.ASC),
						OrderByBuilder.field("mas").direction(SortDirection.ASC)
				);
				filter.setOrderBy(orderBy);
			}

			log.info("the filter is: {} ", filter);

			Criteria criteria = CriteriaBuilder.and(filter.getAllParametersCriterias());

			var dtoresult = (returnInfiniteResults(
					this.dao.infinite(() -> dao.searchDeclOnCropsByFilter(applicationId, criteria, filter.getOrderBy()),
							nextKey,
							null != nextKey ? DEFAULT_PAGE_SIZE : DEFAULT_LIMIT)));

			completeResidualNitrogen(dtoresult);
			return dtoresult;

		} catch (Exception e) {
			String msg = GenericUtility.formatStr("Unable to complete 'get' method due an unhandled error for tenant: {}, "
					+ "applicationId: {} ", tenant, applicationId);
			log.error(msg, e);
			throw e;
		}
	}
	
	public List<DeclOnCropsNTT> getDeclOnCropsWithoutPrevEffluentsByApplicationId(User user, String tenant, Long applicationId) {
		
		log.info("Invoking getDeclOnCropsWithoutPrevEffluentsByApplicationId by application id with params tenant: {}, applicationId: {} ", tenant, applicationId);

		try {

			ApplicationDetailsPublicDTO applicationDetailsPublicDTO =
					applicationFacadeService.callForApplicationDetails(tenant, applicationId, user, Locale.ITALIAN.getLanguage());

			log.info(applicationDetailsPublicDTO.toString());

			List<DeclOnCropsNTT> res = dao.getDeclOnCropsWithoutPrevEffluentsByApplicationId(applicationId);

			log.info("Retrieving of DeclOnCrops completed for tenant {} ", tenant);
 
			return res;

		} catch (Exception e) {
			String msg = GenericUtility.formatStr("Unable to complete 'getDeclOnCropsWithoutPrevEffluentsByApplicationId' method due an unhandled error for tenant: {}, "
					+ "applicationId: {} ", tenant, applicationId);
			log.error(msg, e);
			throw e;
		}
	}

	private void completeResidualNitrogen(InfiniteListResults<DeclOnCropsDTO> dtoresult) {
		if (dtoresult != null && !dtoresult.getRecords().isEmpty()) {
			var dclIds = dtoresult.getRecords().stream()
					.map(x -> x.getIds().get(0))
					.toList();

			var allEffluents = dao.declOnCropsByDeclOnCropsByParentIds(dclIds);
			var effluentsByParentId = allEffluents.stream()
					.collect(Collectors.groupingBy(DeclOnCropsPrevEffluentsNTT::getAppfpuaDeclOnCropsPkid));

			dtoresult.getRecords().forEach(dc -> {
				Long parentId = dc.getIds().get(0);
				var effluents = effluentsByParentId.getOrDefault(parentId, List.of());

				BigDecimal totalResidualNitrogen = effluents.stream()
						.map(e -> {
							BigDecimal quantity = e.getQuantity() != null ? e.getQuantity() : BigDecimal.ZERO;
							BigDecimal nitrogenContent = e.getNitrogenContent() != null ? e.getNitrogenContent() : BigDecimal.ZERO;
							BigDecimal reduction = e.getReduction() != null ? e.getReduction() : BigDecimal.ZERO;
							return quantity.multiply(nitrogenContent).multiply(reduction);
						})
						.reduce(BigDecimal.ZERO, BigDecimal::add);

				dc.setTotResidualNitrogen(totalResidualNitrogen);
			});
		}
	}

	public InfiniteListResults<DeclOnCropLiveStocksDTO> searchDeclOnCropsLiveStocksByFilter(User user, @NotNull String tenant, @NotNull Long applicationId,
			Map<String, String[]> params, String nextKey) {

		try {

			ApplicationDetailsPublicDTO applicationDetailsPublicDTO =
					applicationFacadeService.callForApplicationDetails(tenant, applicationId, user, Locale.ITALIAN.getLanguage());

			log.info(applicationDetailsPublicDTO.toString());

			log.info("Retrieving of DeclOnCrops completed for tenant {} ", tenant);

			Map<String, String> paramNameTranslationsForDB = new HashMap<>();
			paramNameTranslationsForDB.put("species", "animal_species");
			paramNameTranslationsForDB.put("category", "animal_category");
			paramNameTranslationsForDB.put("typeStabling", "housing_system");
			paramNameTranslationsForDB.put("numberHeadsRaised", "head_of_livestock_numb");
			paramNameTranslationsForDB.put("numberField", "number_in_the_field");
			paramNameTranslationsForDB.put("averagePV", "average_live_weight");
			paramNameTranslationsForDB.put("sewageOutlet", "liquid_effl_leaving_stable");
			paramNameTranslationsForDB.put("manureOrShovelableOutput", "solid_effluent_leaving_table");

			Filter filter = FilterHandler.createFilterByParamsExistingInClass(params, DeclOnCropLiveStocksDTO.class, paramNameTranslationsForDB);

			if (filter.getOrderBy() == null) {
				OrderBy orderBy = OrderByBuilder.from(
						OrderByBuilder.field("animal_species").direction(SortDirection.ASC),
						OrderByBuilder.field("animal_category").direction(SortDirection.ASC),
						OrderByBuilder.field("housing_system").direction(SortDirection.ASC)
				);
				filter.setOrderBy(orderBy);
			}

			Criteria criteria = CriteriaBuilder.and(filter.getAllParametersCriterias());

			return (returnInfiniteLSResults(
					this.dao.infinite(() -> dao.searchDeclOnCropsEffluentsByFilter(applicationId, criteria, filter.getOrderBy()),
							nextKey,
							null != nextKey ? DEFAULT_PAGE_SIZE : DEFAULT_LIMIT)));

		} catch (Exception e) {
			String msg = GenericUtility.formatStr("Unable to complete 'get' method due an unhandled error for tenant: {}, "
					+ "applicationId: {} ", tenant, applicationId);
			log.error(msg, e);
			throw e;
		}
	}

	protected InfiniteListResults<DeclOnCropLiveStocksDTO> returnInfiniteLSResults(InfiniteListResults<DeclOnCropLiveStocksNTT> infiniteListResults) {
		return GenericUtility.returnInfiniteResults(infiniteListResults, mapperLS::entityToDto);
	}
}
