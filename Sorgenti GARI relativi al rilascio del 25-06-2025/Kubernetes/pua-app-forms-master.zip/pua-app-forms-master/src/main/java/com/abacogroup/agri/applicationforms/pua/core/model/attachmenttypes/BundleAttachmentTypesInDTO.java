package com.abacogroup.agri.applicationforms.pua.core.model.attachmenttypes;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author Alexandru Paraschiv
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class BundleAttachmentTypesInDTO {
	private String attachmentGroupCode;
	private String typeCode;
	private List<AttachmentTypesI18n> i18n;
}
