package com.abacogroup.agri.applicationforms.pua.db.ntt;

import com.abacogroup.agri.applicationforms.pua.db.ntt.applications.IIdRs;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.OffsetDateTime;
import java.util.List;
import java.util.Optional;

/**
 * @author Emanuele Crocilla
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DeclOnCropsNTT implements IIdRs<Long> {

	private Long pkid;
	private Long applicationId;
	private Long planId;
	private String plotCode;
	private String plotDescription;
	private String declCode;
	private String version;
	private String landUseCode;
	private Short flZvn;
	private Integer areaSqm;
	private String cropDuration;
	private String plantStatus;
	@Builder.Default private String cycle = "0";
	private String typology;
	private Integer yield;
	private Integer mas;
	private Integer precessionCode;
	private BigDecimal totResidualNitrogen;
	private BigDecimal distributableNitrogen;
	private OffsetDateTime dtInsert;
	private OffsetDateTime dtDelete;
	private String userIdInsert;
	private String userIdDelete;
	private String sectorCode;

	private List<DeclOnCropsPrevEffluentsNTT> previousEffluents;
	
	public void setCycle(String cycle) {
		boolean cycleValueIsNotValid = (cycle == null || cycle.isBlank() || "null".equalsIgnoreCase(cycle.trim()));
		this.cycle = cycleValueIsNotValid  ? "0" : cycle.trim();
	}

	@Override
	public void setKey(Long id) {
		setPkid(id);
	}

	@Override
	public Optional<Long> getKey() {
		return Optional.ofNullable(getPkid());
	}

}
