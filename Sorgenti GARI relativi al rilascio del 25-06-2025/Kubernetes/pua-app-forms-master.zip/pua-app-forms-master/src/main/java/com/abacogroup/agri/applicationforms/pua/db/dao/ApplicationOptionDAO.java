package com.abacogroup.agri.applicationforms.pua.db.dao;

import java.time.LocalDateTime;
import java.util.List;

import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.customizer.BindBean;
import org.jdbi.v3.sqlobject.customizer.BindList;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;

import com.abacogroup.agri.applicationforms.pua.db.ntt.ApplicationOptionNTT;

/**
 * @author Mattia Perini
 */
public interface ApplicationOptionDAO extends IGenericHistoricizationFieldsDAO<ApplicationOptionNTT, Long, Void> {

	@Override
	@SqlQuery("§select_nextval(appfpua_application_options_id_seq)§")
	Long nextSequenceVal();

	@Override
	@SqlUpdate("INSERT INTO appfpua_application_options " +
			" (pkid, " +
			" application_id, " +
			" option_config_id, " +
			" option_code, " +
			" document_id, " +
			" takeover_id, " +
			" start_application_id, " +
			" previous_application_id, " +
			" dt_insert, " +
			" dt_delete, " +
			" user_id_insert, " +
			" user_id_delete) " +
			" VALUES(:pkid, :application_id, :option_config_id, :option_code, :document_id, :takeover_id, " +
			" :start_application_id, :previous_application_id, :current_timestamp, " +
			" TO_TIMESTAMP('9999-12-3123:59:59','YYYY-MM-DDHH24:MI:SS'), :user_id, NULL)")
	void insert(@BindBean ApplicationOptionNTT ntt, @Bind("user_id") String userId, @Bind("current_timestamp") LocalDateTime currentTimestamp);

	@SqlQuery("SELECT a.pkid, " +
			" a.application_id, " +
			" a.option_config_id, " +
			" a.option_code, " +
			" a.document_id, " +
			" a.takeover_id, " +
			" a.start_application_id, " +
			" a.previous_application_id, " +
			" a.dt_insert, " +
			" a.dt_delete, " +
			" a.user_id_insert, " +
			" a.user_id_delete " +
			" FROM appfpua_application_options a" +
			" WHERE pkid = :id")
	@RegisterBeanMapper(ApplicationOptionNTT.class)
	List<ApplicationOptionNTT> findById(@Bind("id") Long id);

	@Override
	@SqlUpdate("UPDATE appfpua_application_options SET " +
			"user_id_delete = :user_id_delete, dt_delete = :current_timestamp " +
			"WHERE pkid = :id " +
			"AND §current_timestamp§ BETWEEN dt_insert AND dt_delete")
	void logicallyDeleteById(@Bind("id") Long id, @Bind("user_id_delete") String userDelete, @Bind("current_timestamp") LocalDateTime currentTimestamp);

	@SqlQuery("SELECT a.pkid, " +
			" a.application_id, " +
			" a.option_config_id, " +
			" a.option_code, " +
			" a.document_id, " +
			" a.takeover_id, " +
			" a.start_application_id, " +
			" a.previous_application_id, " +
			" a.dt_insert, " +
			" a.dt_delete, " +
			" a.user_id_insert, " +
			" a.user_id_delete " +
			" FROM appfpua_application_options a " +
			" WHERE a.application_id = :application_id " +
			" AND §current_timestamp§ BETWEEN dt_insert AND dt_delete")
	@RegisterBeanMapper(ApplicationOptionNTT.class)
	List<ApplicationOptionNTT> findByApplicationId(@Bind("tenant") String tenant, @Bind("application_id") Long applicationId);

	@SqlQuery("SELECT a.pkid, " +
			" a.application_id, " +
			" a.option_config_id, " +
			" a.option_code, " +
			" a.document_id, " +
			" a.takeover_id, " +
			" a.start_application_id, " +
			" a.previous_application_id, " +
			" a.dt_insert, " +
			" a.dt_delete, " +
			" a.user_id_insert, " +
			" a.user_id_delete " +
			"FROM appfpua_application_options a " +
			"WHERE a.application_id = :application_id " +
			"AND §current_timestamp§ NOT BETWEEN dt_insert AND dt_delete " +
			"ORDER BY a.dt_delete DESC")
	@RegisterBeanMapper(ApplicationOptionNTT.class)
	List<ApplicationOptionNTT> findExpiredByApplicationId(@Bind("application_id") Long applicationId);

	@SqlQuery("SELECT a.pkid, " +
			" a.application_id, " +
			" a.option_config_id, " +
			" a.option_code, " +
			" a.document_id, " +
			" a.takeover_id, " +
			" a.start_application_id, " +
			" a.previous_application_id, " +
			" a.dt_insert, " +
			" a.dt_delete, " +
			" a.user_id_insert, " +
			" a.user_id_delete " +
			" FROM appfpua_application_options a " +
			" WHERE a.application_id = :application_id " +
			" AND §current_timestamp§ BETWEEN dt_insert AND dt_delete " +
			" AND (a.takeover_id = :takeover_id OR (:takeover_id IS NULL AND a.takeover_id IS NULL)) ")
	@RegisterBeanMapper(ApplicationOptionNTT.class)
	List<ApplicationOptionNTT> findByApplicationIdAndTakeoverId(@Bind("tenant") String tenant, @Bind("application_id") Long applicationId,
			@Bind("takeover_id") Long takeoverId);

	@SqlQuery("SELECT a.pkid, " +
			" a.application_id, " +
			" a.option_config_id, " +
			" a.option_code, " +
			" a.document_id, " +
			" a.takeover_id, " +
			" a.start_application_id, " +
			" a.previous_application_id, " +
			" a.dt_insert, " +
			" a.dt_delete, " +
			" a.user_id_insert, " +
			" a.user_id_delete " +
			" FROM appfpua_application_options a " +
			" LEFT JOIN appfpua_option_configs foc ON foc.id = a.option_config_id " +
			" LEFT JOIN appfpua_option_catalog oc ON oc.id = foc.option_id " +
			" WHERE a.application_id = :application_id " +
			" AND oc.option_code in (<option_codes>) " +
			" AND §current_timestamp§ BETWEEN a.dt_insert AND a.dt_delete")
	@RegisterBeanMapper(ApplicationOptionNTT.class)
	List<ApplicationOptionNTT> findByApplicationIdOptionCodes(@Bind("tenant") String tenant,
			@Bind("application_id") Long applicationId, @BindList("option_codes") List<String> optionCodes);

	@SqlQuery("SELECT a.pkid, " +
			" a.application_id, " +
			" a.option_config_id, " +
			" a.option_code, " +
			" a.document_id, " +
			" a.takeover_id, " +
			" a.start_application_id, " +
			" a.previous_application_id, " +
			" a.dt_insert, " +
			" a.dt_delete, " +
			" a.user_id_insert, " +
			" a.user_id_delete " +
			" FROM appfpua_application_options a " +
			" LEFT JOIN appfpua_option_configs foc ON foc.id = a.option_config_id " +
			" LEFT JOIN appfpua_option_catalog oc ON oc.id = foc.option_id " +
			" WHERE a.application_id = :application_id " +
			" AND oc.option_code in (<option_codes>) " +
			" AND (a.takeover_id = :takeover_id OR (:takeover_id IS NULL AND a.takeover_id IS NULL)) " +
			" AND §current_timestamp§ BETWEEN a.dt_insert AND a.dt_delete")
	@RegisterBeanMapper(ApplicationOptionNTT.class)
	List<ApplicationOptionNTT> findByApplicationIdOptionCodesAndTakeoverId(@Bind("tenant") String tenant,
															  @Bind("application_id") Long applicationId,
															  @BindList("option_codes") List<String> optionCodes,
															  @Bind("takeover_id") Long takeoverId);

	@SqlQuery("SELECT a.pkid, " +
			" a.application_id, " +
			" a.option_config_id, " +
			" a.option_code, " +
			" a.document_id, " +
			" a.takeover_id, " +
			" a.start_application_id, " +
			" a.previous_application_id, " +
			" a.dt_insert, " +
			" a.dt_delete, " +
			" a.user_id_insert, " +
			" a.user_id_delete " +
			" FROM appfpua_application_options a " +
			" LEFT JOIN appfpua_option_configs foc ON foc.id = a.option_config_id " +
			" LEFT JOIN appfpua_option_catalog oc ON oc.id = foc.option_id " +
			" WHERE a.application_id = :application_id " +
			" AND oc.option_code = :option_code " +
			" AND §current_timestamp§ BETWEEN a.dt_insert AND a.dt_delete")
	@RegisterBeanMapper(ApplicationOptionNTT.class)
	List<ApplicationOptionNTT> findByApplicationIdOptionCode(@Bind("tenant") String tenant,
			@Bind("application_id") Long applicationId, @Bind("option_code") String optionCode);

	@SqlQuery("SELECT a.pkid, " +
			" a.application_id, " +
			" a.option_config_id, " +
			" a.option_code, " +
			" a.document_id, " +
			" a.takeover_id, " +
			" a.start_application_id, " +
			" a.previous_application_id, " +
			" a.dt_insert, " +
			" a.dt_delete, " +
			" a.user_id_insert, " +
			" a.user_id_delete " +
			" FROM appfpua_application_options a " +
			" WHERE a.application_id = :application_id " +
			" AND a.option_config_id = :option_config_id " +
			" AND §current_timestamp§ BETWEEN dt_insert AND dt_delete")
	@RegisterBeanMapper(ApplicationOptionNTT.class)
	List<ApplicationOptionNTT> findByApplicationIdOptionConfigId(@Bind("tenant") String tenant,
																 @Bind("application_id") Long applicationId, @Bind("option_config_id") Long optionConfigId);


	@SqlUpdate("DELETE FROM appfpua_application_options a " +
			" WHERE a.option_config_id = :optionConfigId")
	void deleteByOptionConfigId(@Bind("optionConfigId") Long optionConfigId);

	@SqlUpdate("UPDATE appfpua_application_options ao SET " +
			" user_id_delete = :user_id_delete, dt_delete = :current_timestamp " +
			" WHERE :tenant in (SELECT oc.tenant_id from appfpua_option_catalog oc " +
			"  LEFT JOIN appfpua_option_configs foc on foc.option_id = oc.id " +
			"  WHERE foc.id = :option_config_id) " +
			" AND ao.application_id = :application_id " +
			" AND ao.option_config_id = :option_config_id " +
			" AND ao.takeover_id = :takeover_id " +
			" AND §current_timestamp§ BETWEEN ao.dt_insert AND ao.dt_delete")
	void logicallyDeleteByTakeoverIdAndOptionConfigId(@Bind("tenant") String tenant, @Bind("application_id") Long applicationId,
													  @Bind("takeover_id") Long takeoverId, @Bind("option_config_id") Long optionConfigId,
													  @Bind("user_id_delete") String userDelete, @Bind("current_timestamp") LocalDateTime currentTimestamp);


	@SqlUpdate("UPDATE appfpua_application_options ao SET " +
			" user_id_delete = :user_id_delete, dt_delete = :current_timestamp " +
			" WHERE :tenant in (SELECT oc.tenant_id from appfpua_option_catalog oc " +
			"  LEFT JOIN appfpua_option_configs foc on foc.option_id = oc.id " +
			"  WHERE foc.id = :option_config_id) " +
			" AND ao.application_id = :application_id " +
			" AND ao.option_config_id = :option_config_id " +
			" AND §current_timestamp§ BETWEEN ao.dt_insert AND ao.dt_delete")
	void logicallyDeleteOptionConfigId(@Bind("tenant") String tenant, @Bind("application_id") Long applicationId,
													  @Bind("option_config_id") Long optionConfigId,
													  @Bind("user_id_delete") String userDelete, @Bind("current_timestamp") LocalDateTime currentTimestamp);

	@SqlUpdate("UPDATE appfpua_application_options aaod SET " +
			" user_id_delete = :user_id_delete, dt_delete = §current_timestamp§ " +
			" WHERE :tenant in (SELECT oc.tenant_id from appfpua_option_catalog oc " +
			"  LEFT JOIN appfpua_option_configs foc on foc.option_id = oc.id ) " +
			" AND aaod.application_id = :application_id " +
			" AND §current_timestamp§ BETWEEN aaod.dt_insert AND aaod.dt_delete")
	void bulkLogicallyDeleteByApplicationId(@Bind("tenant") String tenant, @Bind("application_id") Long applicationId, @Bind("user_id_delete") String userDelete);

	@SqlUpdate("UPDATE appfpua_application_options aaod SET " +
			" user_id_delete = :user_id_delete, dt_delete = §current_timestamp§ " +
			" WHERE :tenant in (SELECT oc.tenant_id from appfpua_option_catalog oc " +
			"  LEFT JOIN appfpua_option_configs foc on foc.option_id = oc.id and foc.id = aaod.option_config_id) " +
			" AND aaod.application_id = :application_id " +
			" AND §current_timestamp§ BETWEEN aaod.dt_insert AND aaod.dt_delete " +
			" AND aaod.option_config_id not in (<option_config_ids>)")
	void logicallyDeleteByApplicationIdExcludeOptionConfigIds(@Bind("tenant") String tenant,
			@Bind("application_id") Long applicationId,
			@Bind("user_id_delete") String userDelete,
			@BindList("option_config_ids") List<Long> optionConfigIdsToExclude);


}
