package com.abacogroup.agri.applicationforms.pua.core.model.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
@Schema(description = "DTO for latest no-spreading period insert")
public class NoSpreadingPeriodLatestInsertDTO {

	@NotNull(message = "applicationId is required")
	private Long applicationId;

	@NotNull(message = "partyId is required")
	private Long partyId;

	@NotBlank(message = "effluent is required")
	private String effluent;

	@NotNull(message = "year is required")
	private Integer year;

	@NotBlank(message = "dayFrom is required")
	private String dayFrom;

	@NotBlank(message = "dayTo is required")
	private String dayTo;
}
