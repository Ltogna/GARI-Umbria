package com.abacogroup.agri.applicationforms.pua.services.common;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author Gennaro Tamburrelli
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class ModuleKey {
	private String tenant;
	private String moduleCode;
}
