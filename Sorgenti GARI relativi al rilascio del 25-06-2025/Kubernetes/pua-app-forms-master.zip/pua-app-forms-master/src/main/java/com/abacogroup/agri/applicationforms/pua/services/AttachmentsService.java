package com.abacogroup.agri.applicationforms.pua.services;

import static com.abacogroup.agri.applicationforms.pua.util.GenericUtility.returnInfiniteResults;

import java.io.InputStream;
import java.text.MessageFormat;
import java.util.List;
import java.util.Optional;

import org.glassfish.jersey.media.multipart.FormDataContentDisposition;
import org.jdbi.v3.core.Jdbi;

import com.abacogroup.agri.applicationforms.pua.core.exceptions.AgriApplicationFormsRuntimeException;
import com.abacogroup.agri.applicationforms.pua.core.exceptions.AttachmentTypesNotFoundRuntimeException;
import com.abacogroup.agri.applicationforms.pua.core.exceptions.BadRequestRuntimeException;
import com.abacogroup.agri.applicationforms.pua.core.exceptions.FileStoreIORuntimeException;
import com.abacogroup.agri.applicationforms.pua.core.mappers.AttachmentPublicMapper;
import com.abacogroup.agri.applicationforms.pua.core.mappers.AttachmentTypePublicMapper;
import com.abacogroup.agri.applicationforms.pua.core.model.CompileStatusEnum;
import com.abacogroup.agri.applicationforms.pua.core.model.dto.AttachmentDTO;
import com.abacogroup.agri.applicationforms.pua.core.model.dto.AttachmentPublicDTO;
import com.abacogroup.agri.applicationforms.pua.core.model.dto.AttachmentTypeDTO;
import com.abacogroup.agri.applicationforms.pua.core.model.dto.AttachmentTypePublicDTO;
import com.abacogroup.agri.applicationforms.pua.core.model.dto.CreateAttachmentInDTO;
import com.abacogroup.agri.applicationforms.pua.core.model.dto.SavedFileDTO;
import com.abacogroup.agri.applicationforms.pua.core.model.dto.UpdateAttachmentInDTO;
import com.abacogroup.agri.applicationforms.pua.services.common.ApplicationFacadeService;
import com.abacogroup.agri.applicationforms.pua.services.common.crud.AttachmentsCrudService;
import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.filestore.client.auth.Sso2Authenticator;
import com.abacogroup.jdbi.paging.InfiniteListResults;

import jakarta.ws.rs.core.Response;
import lombok.extern.slf4j.Slf4j;

/**
 * @author Gennaro Tamburrelli
 * @author Mauro Pozzana
 * @author Alexandru Paraschiv
 * @author Mattia Perini
 * @author Carlo Sindico
 */
@Slf4j
public class AttachmentsService {

    private final Jdbi jdbi;
    private final AttachmentsCrudService attachmentsCrudService;
    private final AttachmentTypesCrudService attachmentTypesCrudService;
    private final FileStoreService filesStoreService;
    private final FileCheckerService fileCheckerService;
    private final String bucketName;
    private final ApplicationFacadeService applicationFacadeService;

    public AttachmentsService(Jdbi jdbi,
            AttachmentTypesCrudService attachmentTypesCrudService,
            AttachmentsCrudService attachmentsCrudService,
            ApplicationFacadeService applicationFacadeService,
            FileStoreService filesStoreService, FileCheckerService fileCheckerService,
            String bucketName) {
    	
        this.jdbi = jdbi;
        this.attachmentTypesCrudService = attachmentTypesCrudService;
        this.attachmentsCrudService = attachmentsCrudService;
        this.filesStoreService = filesStoreService;
        this.fileCheckerService = fileCheckerService;
        this.applicationFacadeService = applicationFacadeService;
        this.bucketName = bucketName;
    }

    public InfiniteListResults<AttachmentPublicDTO> getAttachments(String tenantId, Long applicationId, String attachmentGroup, String nextKey) {
        log.info("retrieve the attachments data from db by application id: {}", applicationId);
        InfiniteListResults<AttachmentPublicDTO> attachments = returnInfiniteResults(
                attachmentsCrudService.findByApplicationIdAndAttachmentGroup(tenantId, applicationId, attachmentGroup, nextKey),
                AttachmentPublicMapper.INSTANCE::dtoToPublic);

        attachments.getRecords().forEach(this::enrichPublicAttachment);

        return attachments;
    }

    public List<AttachmentPublicDTO> getAttachmentList(String tenant, Long applicationId, String attachmentGroup) {
        log.info("retrieve the attachments data from db by application id: {}", applicationId);
        List<AttachmentPublicDTO> attachments = attachmentsCrudService.findListByApplicationIdAndAttachmentGroup(
        		tenant, applicationId, attachmentGroup)
                .stream()
                .map(AttachmentPublicMapper.INSTANCE::dtoToPublic)
                .toList();

        attachments.forEach(this::enrichPublicAttachment);

        return attachments;
    }

    public AttachmentPublicDTO createAttachment(String tenant, Long applicationId, CreateAttachmentInDTO in, User user, 
    		Long formConfigId, String compileStatusIdentifier,
        	InputStream inputStream, FormDataContentDisposition fileMetadata) {
    	
    	try {
    		log.info("Starting createAttachment with tenantId: {} applicationId: {} input payload: {}, username: {}, file metadata: {}",
    				tenant, applicationId, in, Optional.ofNullable(user).map(User::getName).orElse("null"), fileMetadata);

    		applicationFacadeService.verifyAcceptDispositiveCalls(user, tenant, applicationId, formConfigId);

    		var res = jdbi.inTransaction(h -> doCreateAttachment(tenant, applicationId, in, user, inputStream, fileMetadata));

    		// update compile status
    		applicationFacadeService.updateCompileStatus(user, tenant, applicationId, compileStatusIdentifier, CompileStatusEnum.COMPLETED);

    		return res;	

    	}
        catch (Exception e) {
			log.error("Unable to complete createAttachment method", e);
			throw e;
		}
    }

    private AttachmentPublicDTO doCreateAttachment(String tenantId, Long applicationId, CreateAttachmentInDTO in, User user, InputStream inputStream,
            FormDataContentDisposition fileMetadata) {
        log.info("retrieving attachment type from input type code {}", in.getTypeCode());
        AttachmentTypeDTO attachmentType = attachmentTypesCrudService.findByCodeAndAttachmentGroupCode(tenantId, in.getTypeCode(), in.getGroupCode());

        // TODO: save file with 60min of life then, if everything went good just before returning output,
        // make the attached file persistent
        log.info("saving the attachment named: {}", fileMetadata.getFileName());
        SavedFileDTO savedFile = doCallFileStore(tenantId, this.bucketName, user, inputStream, fileMetadata);

        log.info("building the attachment description");
        AttachmentDTO attachmentDTO = AttachmentDTO.builder()
                .fileName(fileMetadata.getFileName())
                .notes(in.getNotes())
                .type(attachmentType.getPkid())
                .attachmentId(savedFile.getFileId())
                .bucketId(this.bucketName)
                .applicationId(applicationId)
                .build();

        log.info("Saving the attachment description to db");
        log.debug("attachment description: {}", attachmentDTO);
        AttachmentPublicDTO out = AttachmentPublicMapper.INSTANCE.dtoToPublic(attachmentsCrudService.insert(attachmentDTO, user.getName()));
        out.setType(AttachmentTypePublicMapper.INSTANCE.dtoToPublic(attachmentType));

        log.info("Created attachment with description: {}", out);
        return out;
    }

    public SavedFileDTO doCallFileStore(String tenantId, String bucketName, User user, InputStream inputStream, FormDataContentDisposition fileMetadata) {
        this.fileCheckerService.checkFileExtension(fileMetadata);

        return filesStoreService.saveFile(tenantId, bucketName, inputStream,
                fileMetadata.getFileName(), user, buildSso2Authenticator(user));
    }

    public InfiniteListResults<AttachmentTypePublicDTO> getAttachmentTypes(String tenant, String attachmentGroup, String nextKey) {
        log.info("retrieve the attachments data from db by tenant id: {}", tenant);
        InfiniteListResults<AttachmentTypePublicDTO> attachmentTypes = returnInfiniteResults(
                attachmentTypesCrudService.findByTenantAttachmentGroup(tenant, attachmentGroup, nextKey),
                AttachmentTypePublicMapper.INSTANCE::dtoToPublic);

        if (attachmentTypes.getRecords().isEmpty()) {
            throw new AttachmentTypesNotFoundRuntimeException(MessageFormat.format("No attachment types found for tenant id: {0}", tenant));
        }

        return attachmentTypes;
    }

    public List<AttachmentTypePublicDTO> getAttachmentTypesFullList(String tenant, String attachmentGroup) {
        log.info("retrieve the attachments data from db by tenant id: {}", tenant);
        return attachmentTypesCrudService.findByTenantAttachmentGroupFullList(tenant, attachmentGroup)
                .stream()
                .map(AttachmentTypePublicMapper.INSTANCE::dtoToPublic)
                .toList();
    }

    public Response getAttachment(String tenant, User user, Long applicationId, String attachmentId) {
        log.info("Starting getAttachment with parameters tenant: {} username: {} applicationId: {} attachmentId: {}",
                tenant, Optional.ofNullable(user).map(User::getName).orElse("null"), applicationId, attachmentId);

        AttachmentDTO attachmentDescriptor = attachmentsCrudService.findByAttachmentId(tenant, applicationId, attachmentId);

        return doCallFileStoreForDownload(tenant, user, attachmentDescriptor.getBucketId(), attachmentDescriptor.getAttachmentId());
    }

    public Response doCallFileStoreForDownload(String tenant, User user, String bucketName, String fileId) {
        try {
            return filesStoreService.getFileForDownload(tenant, fileId,bucketName, user, buildSso2Authenticator(user));
        } catch (FileStoreIORuntimeException e) {
            throw new AgriApplicationFormsRuntimeException(e.getMessage());
        }
    }

    public Response doCallFileStoreForHead(String tenant, User user, String bucketName, String fileId) {
        try {
            return filesStoreService.getFileForHead(tenant, fileId,bucketName, user, buildSso2Authenticator(user));
        } catch (FileStoreIORuntimeException e) {
            throw new AgriApplicationFormsRuntimeException(e.getMessage());
        }
    }

    public AttachmentPublicDTO getAttachmentById(String tenant, User user, Long applicationId, String attachmentId) {
        log.info("Starting getAttachmentById with parameters tenant: {} username: {} applicationId: {} attachmentId: {}",
                tenant, Optional.ofNullable(user).map(User::getName).orElse("null"), applicationId, attachmentId);

        return AttachmentPublicMapper.INSTANCE.dtoToPublic(attachmentsCrudService.findByAttachmentId(tenant, applicationId, attachmentId));
    }

    public void deleteAttachment(String tenant, User user, 
    		Long formConfigId, String compileStatusIdentifier, 
    		Long applicationId, String attachmentId) {

    	applicationFacadeService.verifyAcceptDispositiveCalls(user, tenant, applicationId, formConfigId);

    	log.info("Starting deleteAttachment with parameters tenant: {} username: {} applicationId: {} attachmentId: {}",
                tenant, Optional.ofNullable(user).map(User::getName).orElse("null"), applicationId, attachmentId);
    	
    	var deletingAttachment = getAttachmentById(tenant, user, applicationId, attachmentId);
    	
    	String deletingAttachmentGroup = deletingAttachment.getTypeAttachmentGroupCode();
    	
        jdbi.useTransaction(t -> doDeleteAttachment(tenant, user, applicationId, attachmentId));
        
        var remainigAttachmentsList = getAttachmentList(tenant, applicationId, deletingAttachmentGroup);
        
        // no other attachments stored 
        // TODO EC - in the future you can evaluate to use the private method "existAnyAttachments" (present in this class) instead
        if (null == remainigAttachmentsList || remainigAttachmentsList.isEmpty()) {
        	// delete compile status
        	applicationFacadeService.deleteCompileStatus(user, tenant, applicationId, compileStatusIdentifier);
		}else {
			// update compile status
			applicationFacadeService.updateCompileStatus(user, tenant, applicationId, compileStatusIdentifier, CompileStatusEnum.COMPLETED);
		}
    }

    private void doDeleteAttachment(String tenant, User user, Long applicationId, String attachmentId) {
        log.info("retrieving the attachment data from db with attachment id: {}", attachmentId);
        AttachmentDTO attachmentDescriptor = attachmentsCrudService.findByAttachmentId(tenant, applicationId, attachmentId);

        log.info("Deleting attachment entry on db...");
        attachmentsCrudService.delete(attachmentDescriptor.getPkid(), user.getName());
        log.info("Attachment entry deleted");
        // added call to delete file on File Store also if actually file deletion is not a supported functionality of File Store
        filesStoreService.deleteFile(tenant, attachmentDescriptor.getAttachmentId(),
                attachmentDescriptor.getBucketId(), user);
    }

    public AttachmentPublicDTO updateAttachment(String tenant, Long applicationId, String attachmentId,
    		Long formConfigId, String compileStatusIdentifier, 
    		UpdateAttachmentInDTO attachmentToUpdate, User user) {
    	
    	applicationFacadeService.verifyAcceptDispositiveCalls(user, tenant, applicationId, formConfigId);
    	
        log.info("Starting updateAttachment with parameters tenant: {} username: {} applicationId: {} attachmentId: {}",
                tenant, Optional.ofNullable(user).map(User::getName).orElse("null"), applicationId, attachmentId);

        if (Optional.ofNullable(user).isEmpty()) {
            throw new BadRequestRuntimeException("The user is required");
        }

        log.info("retrieving the attachment data from db with attachment id: {}", attachmentId);
        AttachmentDTO currentAttachment = attachmentsCrudService.findByAttachmentId(tenant, applicationId, attachmentId);

        if (Optional.ofNullable(attachmentToUpdate.getTypeCode()).isPresent()) {
            log.info("retrieving the attachment type data from db with code id: {}", attachmentToUpdate.getTypeCode());
            AttachmentTypeDTO newType = attachmentTypesCrudService.findByCodeAndAttachmentGroupCode(tenant,
                    attachmentToUpdate.getTypeCode(), attachmentToUpdate.getGroupCode());
            currentAttachment.setType(newType.getPkid());
        }

        if (Optional.ofNullable(attachmentToUpdate.getNotes()).isPresent()) {
            log.info("Setting notes: {} to update to attachment of id: {}", attachmentToUpdate.getNotes(), currentAttachment.getPkid());
            currentAttachment.setNotes(attachmentToUpdate.getNotes());
        }

        attachmentsCrudService.update(currentAttachment.getPkid(), currentAttachment, user.getName());
        // call find by attachment id to retrieve also the attachment type data with the attachment id
        AttachmentDTO updatedAttachment = attachmentsCrudService.findByAttachmentId(tenant, applicationId, attachmentId);

        AttachmentPublicDTO outputAttachment = AttachmentPublicMapper.INSTANCE.dtoToPublic(updatedAttachment);
        enrichPublicAttachment(outputAttachment);

		// update compile status
		applicationFacadeService.updateCompileStatus(user, tenant, applicationId, compileStatusIdentifier, CompileStatusEnum.COMPLETED);

		return outputAttachment;	

    }

    private void enrichPublicAttachment(AttachmentPublicDTO attachment) {
        log.info("Enriching attachment of id: {} adding type: {}", attachment.getAttachmentId(),
                attachment.getType());
        attachment.setType(AttachmentTypePublicDTO.builder()
                .code(attachment.getTypeAttachmentCode())
                .groupCode(attachment.getTypeAttachmentGroupCode())
                .typeCode(attachment.getTypeCode())
                .id(attachment.getTypeId())
                .build());
    }

    private Sso2Authenticator buildSso2Authenticator(User user) {
        return new Sso2Authenticator(user);
    }
    
    // TODO EC not tested yet
    private boolean existAnyAttachments(String tenant, Long applicationId, User user, String compileStatusIdentifier) {
    	
    	 var attachmentGroupValue = applicationFacadeService.getAttachmentGroupValue(user, tenant, applicationId, compileStatusIdentifier);
         log.info("Checking if the attachment having group '{}' exists...", attachmentGroupValue);

         boolean isAttachmentPresent = getAttachments(tenant, applicationId, attachmentGroupValue, null)
                 .getRecords().stream().findFirst().isPresent();
         
         log.debug("isAttachmentPresent: {}", isAttachmentPresent);
         
         return isAttachmentPresent;
    }
}
