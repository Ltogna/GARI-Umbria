package com.abacogroup.agri.applicationforms.pua.db.ntt;

import com.abacogroup.agri.applicationforms.pua.db.ntt.applications.IIdRs;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.OffsetDateTime;
import java.util.Optional;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DeclOnCropLiveStocksNTT implements IIdRs<Long> {

	private Long pkid;
	//	private Long declOnCropsLivestockConsistId;
	private Long applicationId;
	private String animalSpecies;
	private String animalCategory;
	private String housingSystem;
	private Integer headOfLivestockNumb;
	private Double averageLiveWeight;
	private Integer numberInTheField;
	private Integer liquidEfflLeavingStable;
	private Integer solidEffluentLeavingStable;
	private OffsetDateTime dtInsert;
	private OffsetDateTime dtDelete;
	private String userIdInsert;
	private String userIdDelete;

	// ===== NEW FIELDS =====
	private String genreCode;
	private String productionCode;
	// =======================

	@Override
	public void setKey(Long id) {
		setPkid(id);
	}

	@Override
	public Optional<Long> getKey() {
		return Optional.ofNullable(getPkid());
	}
}
