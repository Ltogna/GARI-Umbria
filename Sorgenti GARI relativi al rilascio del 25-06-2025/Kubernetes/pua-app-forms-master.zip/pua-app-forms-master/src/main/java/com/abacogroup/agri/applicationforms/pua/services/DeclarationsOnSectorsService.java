package com.abacogroup.agri.applicationforms.pua.services;

import com.abacogroup.agri.applicationforms.pua.core.exceptions.BadRequestRuntimeException;
import com.abacogroup.agri.applicationforms.pua.core.exceptions.ObjectNotFoundRuntimeException;
import com.abacogroup.agri.applicationforms.pua.core.mappers.DeclarationsOnSectorsMapper;
import com.abacogroup.agri.applicationforms.pua.core.model.CompileStatusEnum;
import com.abacogroup.agri.applicationforms.pua.core.model.dto.DeclarationsOnSectorsDTO;
import com.abacogroup.agri.applicationforms.pua.db.dao.DeclarationsOnSectorsDAO;
import com.abacogroup.agri.applicationforms.pua.db.ntt.DeclarationsOnSectorsNTT;
import com.abacogroup.agri.applicationforms.pua.services.common.ApplicationFacadeService;
import com.abacogroup.agri.applicationforms.pua.services.common.crud.AbstractCrudService;
import com.abacogroup.agri.applicationforms.pua.util.Filter;
import com.abacogroup.agri.applicationforms.pua.util.FilterHandler;
import com.abacogroup.agri.applicationforms.pua.util.GenericUtility;
import com.abacogroup.applicationworkflowsdk.model.io.output.ApplicationDetailsPublicDTO;
import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.jdbi.criteria.Criteria;
import com.abacogroup.jdbi.criteria.CriteriaBuilder;
import com.abacogroup.jdbi.orderby.OrderBy;
import com.abacogroup.jdbi.orderby.OrderByBuilder;
import com.abacogroup.jdbi.orderby.SortDirection;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import jakarta.validation.constraints.NotNull;
import lombok.extern.slf4j.Slf4j;

import java.time.OffsetDateTime;
import java.util.*;
import java.util.stream.Collectors;

import static com.abacogroup.agri.applicationforms.pua.util.GenericUtility.throwNotImplementedException;
import static com.abacogroup.agri.applicationforms.pua.util.PagingParamsFactory.DEFAULT_LIMIT;
import static com.abacogroup.agri.applicationforms.pua.util.PagingParamsFactory.DEFAULT_PAGE_SIZE;

/**
 * @author Emanuele Crocilla
 */
@Slf4j
public class DeclarationsOnSectorsService
		extends AbstractCrudService<DeclarationsOnSectorsNTT, Long, DeclarationsOnSectorsDTO, DeclarationsOnSectorsMapper, Void, DeclarationsOnSectorsDAO> {

	private final ApplicationFacadeService applicationFacadeService;
	private GiasAgronicaService giasService;

	public DeclarationsOnSectorsService(
			DeclarationsOnSectorsDAO dao,
			ApplicationFacadeService applicationFacadeService,
			DeclarationsOnSectorsMapper mapper,
			GiasAgronicaService giasService) {

		super(dao, mapper);
		this.applicationFacadeService = applicationFacadeService;
		this.giasService = giasService;
	}

	public List<DeclarationsOnSectorsDTO> getAll(User user, String tenant, Long applicationId) {

		applicationFacadeService.callForApplicationDetails(tenant, applicationId, user, Locale.ITALIAN.getLanguage());

		List<DeclarationsOnSectorsNTT> ntts = dao.getByApplicationId(applicationId);

		if (ntts != null) {
			return returnMappedList(ntts);
		}

		String msg = GenericUtility.formatStr("Unable to find item with application id = {}", applicationId);
		ObjectNotFoundRuntimeException err = new ObjectNotFoundRuntimeException(msg);
		log.warn(msg, err);
		throw err;
	}

	public DeclarationsOnSectorsDTO get(User user, String tenant, Long applicationId, Long declatationId) {

		try {

			ApplicationDetailsPublicDTO applicationDetailsPublicDTO =
					applicationFacadeService.callForApplicationDetails(tenant, applicationId, user, Locale.ITALIAN.getLanguage());

			log.info(applicationDetailsPublicDTO.toString());

			DeclarationsOnSectorsNTT ntt = dao.getByApplicationIdAndDeclatationId(applicationId, declatationId);

			if (ntt != null) {
				log.info("Retrieving of DeclarationsOnSectors completed for tenant and declaration Id = {} ", tenant, applicationId, declatationId);
				return returnOptionalRecord(Collections.singletonList(ntt)).get();
			}
		} catch (Exception e) {
			String msg = GenericUtility.formatStr(
					"Unable to complete 'get' method due an unhandled error for tenant {}, applicationId {} and declatationId {} ", tenant, applicationId,
					declatationId);
			log.error(msg, e);
			throw e;
		}

		String msg = GenericUtility.formatStr("Unable to find DeclarationsOnSectors item with tenant = {}, application id = {} and declaration Id = {} ",
				tenant, applicationId, declatationId);
		ObjectNotFoundRuntimeException err = new ObjectNotFoundRuntimeException(msg);
		log.warn(msg, err);
		throw err;
	}

	public InfiniteListResults<DeclarationsOnSectorsDTO> searchDeclarationOnsectorsByFilter(User user, String tenant, Long applicationId,
			Map<String, String[]> params, String nextKey) {

		log.info("Invoking searchDeclarationsOnSectorsByFilter by application id with params tenant: {}, applicationId: {} ", tenant, applicationId);

		try {

			ApplicationDetailsPublicDTO applicationDetailsPublicDTO =
					applicationFacadeService.callForApplicationDetails(tenant, applicationId, user, Locale.ITALIAN.getLanguage());

			log.info(applicationDetailsPublicDTO.toString());

			log.info("Retrieving of DeclarationsOnSectors completed for tenant {} ", tenant);

			Map<String, String> paramNameTranslationsForDB = new HashMap<>();
			paramNameTranslationsForDB.put("sectorCode", "sector_code");
			paramNameTranslationsForDB.put("landUseCode", "land_use_code");
			paramNameTranslationsForDB.put("areaSqm", "area_sqm");

			Filter filter = FilterHandler.createFilterByParamsExistingInClass(params, DeclarationsOnSectorsDTO.class, paramNameTranslationsForDB);

			// set the default order if the front-end does not set one
			if (filter.getOrderBy() == null) {
				OrderBy orderBy = OrderByBuilder.from(
						OrderByBuilder.field("sector_code").direction(SortDirection.ASC),
						OrderByBuilder.field("land_use_code").direction(SortDirection.ASC),
						OrderByBuilder.field("area_sqm").direction(SortDirection.ASC),
						OrderByBuilder.field("mas").direction(SortDirection.ASC)
				);
				filter.setOrderBy(orderBy);
			}

			log.info("the filter is: {} ", filter);

			Criteria criteria = CriteriaBuilder.and(filter.getAllParametersCriterias());

			return (returnInfiniteResults(
					this.dao.infinite(() -> dao.searchDeclarationOnSectorssByFilter(applicationId, criteria, filter.getOrderBy()),
							nextKey,
							null != nextKey ? DEFAULT_PAGE_SIZE : DEFAULT_LIMIT)));

		} catch (Exception e) {
			String msg = GenericUtility.formatStr("Unable to complete 'get' method due an unhandled error for tenant: {}, "
					+ "applicationId: {} ", tenant, applicationId);
			log.error(msg, e);
			throw e;
		}
	}

	public DeclarationsOnSectorsDTO insert(User user, String tenant, Long applicationId, Long formConfigId, String compileStatusIdentifier,
			DeclarationsOnSectorsDTO dto) {

		try {
			applicationFacadeService.verifyAcceptDispositiveCalls(user, tenant, applicationId, formConfigId);

			boolean existImport = dao.existsImport(applicationId);
			if (existImport) {
				String msg = GenericUtility.formatStr(
						"Unable to complete 'insert' because there are imported fields,  tenant {}, applicationId {} and formConfigId {}",
						tenant,
						applicationId, formConfigId);
				throw new RuntimeException(msg);
			}
			DeclarationsOnSectorsNTT ntt = convert(dto, (long) 0);
			ntt.setFlImported((short) 0);
			dao.insert(ntt);

			var newNtt = dao.getByApplicationIdSectorCodeLandUseCode(ntt.getApplicationId(), ntt.getSectorCode(), ntt.getLandUseCode());
			DeclarationsOnSectorsDTO res = returnOptionalRecord(Collections.singletonList(newNtt)).get();

			applicationFacadeService.updateCompileStatus(user, tenant, applicationId, compileStatusIdentifier, CompileStatusEnum.COMPLETED);

			return res;
		} catch (Exception e) {
			String msg = GenericUtility.formatStr("Unable to complete insert method due an error for tenant {}, applicationId {} and formConfigId {}", tenant,
					applicationId, formConfigId);
			log.error(msg, e);
			throw e;
		}
	}

	public List<DeclarationsOnSectorsDTO> insertMany(User user, String tenant, Long applicationId, Long formConfigId, String compileStatusIdentifier,
			List<DeclarationsOnSectorsDTO> dtos, Short isImported) {

		try {
			applicationFacadeService.verifyAcceptDispositiveCalls(user, tenant, applicationId, formConfigId);

			if (dtos != null && !dtos.isEmpty()) {
				List<DeclarationsOnSectorsNTT> ntts = convert(dtos);
				ntts.forEach(x -> x.setFlImported(isImported));
				dao.insertBatch(ntts.toArray(new DeclarationsOnSectorsNTT[ntts.size()]));

				List<String> sectorCodes = new ArrayList<>();
				List<String> landUseCodes = new ArrayList<>();

				ntts.forEach(e -> {
					sectorCodes.add(e.getSectorCode());
					landUseCodes.add(e.getLandUseCode());
				});
				List<DeclarationsOnSectorsNTT> dbRes =
						dao.getByApplicationIdSectorCodeLandUseCode(ntts.get(0).getApplicationId(), sectorCodes, landUseCodes);

				// double check (we want to be sure to return only just inserted elements)
				List<DeclarationsOnSectorsNTT> res = dbRes.stream()
						.filter(item -> dbRes.stream()
								.map(e -> e.getSectorCode() + e.getLandUseCode())
								.collect(Collectors.toSet())
								.contains(item.getSectorCode() + item.getLandUseCode())
						).toList();

				applicationFacadeService.updateCompileStatus(user, tenant, applicationId, compileStatusIdentifier, CompileStatusEnum.COMPLETED);

				return returnMappedList(res);
			}

			return Collections.emptyList();

		} catch (Exception e) {
			String msg = GenericUtility.formatStr("Unable to complete 'insertMany' method due an error for tenant {}, applicationId {} and formConfigId {}",
					tenant, applicationId, formConfigId);
			log.error(msg, e);
			throw e;
		}
	}

	public DeclarationsOnSectorsDTO update(User user, String tenant, Long applicationId, Long formConfigId, String compileStatusIdentifier,
			DeclarationsOnSectorsDTO dto, Long pkId) {

		try {

			applicationFacadeService.verifyAcceptDispositiveCalls(user, tenant, applicationId, formConfigId);
			
			var isImport = dao.existsImport(applicationId);
			
			// Modifications are allowed only for NON imported items
			if ( !isImport ) {
				
				DeclarationsOnSectorsNTT ntt = convert(dto, pkId);
				
				var existing = dao.findByPkId(ntt.getPkid());
				
				if (existing != null) {
					ntt.setFlImported(existing.getFlImported());
				}
				 
				ntt.setPkid(pkId);
				dao.upsert(ntt);
				
				var newNtt = dao.getByApplicationIdSectorCodeLandUseCode(ntt.getApplicationId(), ntt.getSectorCode(), ntt.getLandUseCode());
				
				DeclarationsOnSectorsDTO res = returnOptionalRecord(Collections.singletonList(newNtt)).get();
				
				applicationFacadeService.updateCompileStatus(user, tenant, applicationId, compileStatusIdentifier, CompileStatusEnum.COMPLETED);

				return res;
			}
			else {
				var mess = GenericUtility.formatStr("It is not allowed to modify an imported declaration for tenant {}, applicationId {} and formConfigId {}", tenant, applicationId, formConfigId);
				throw new BadRequestRuntimeException(mess);
			}

		} catch (Exception e) {
			String msg = GenericUtility.formatStr("Unable to complete 'update' method due an error for tenant {}, applicationId {} and formConfigId {}", tenant,
					applicationId, formConfigId);
			
			log.error(msg, e);
			throw e;
		}
	}

	public void updateMany(User user, String tenant, Long applicationId, Long formConfigId, String compileStatusIdentifier,
			List<DeclarationsOnSectorsDTO> dtos) {

		applicationFacadeService.verifyAcceptDispositiveCalls(user, tenant, applicationId, formConfigId);

		List<DeclarationsOnSectorsNTT> ntts = convert(dtos);
		dao.upsertMany(ntts);

		applicationFacadeService.updateCompileStatus(user, tenant, applicationId, compileStatusIdentifier, CompileStatusEnum.COMPLETED);
	}

	public boolean delete(User user, String tenant, Long applicationId, Long formConfigId, String compileStatusIdentifier, Long pkid) {

		try {
			applicationFacadeService.verifyAcceptDispositiveCalls(user, tenant, applicationId, formConfigId);

			DeclarationsOnSectorsNTT ntt = dao.getByApplicationIdAndDeclatationId(applicationId, pkid);

			if (ntt != null) {
				if (ntt.getFlImported() == 1) {
					String msg = GenericUtility.formatStr(
							"Unable to complete 'delete' because is imported fields, tenant {}, applicationId {} and formConfigId {}",
							tenant,
							applicationId, formConfigId);
					throw new RuntimeException(msg);
				}
				dao.expire(applicationId, pkid, OffsetDateTime.now(), user.getUserId());

				if (!existsAtLeastOneElement(applicationId)) {
					applicationFacadeService.deleteCompileStatus(user, tenant, applicationId, compileStatusIdentifier);
				} else {
					applicationFacadeService.updateCompileStatus(user, tenant, applicationId, compileStatusIdentifier, CompileStatusEnum.COMPLETED);
				}

				return true;
			} else {
				log.warn("Unable to find item with application id = " + applicationId + " and declaration Id = " + pkid);
				return false;
			}

		} catch (Exception e) {
			String msg = GenericUtility.formatStr("Unable to complete 'delete' method due an error for tenant {}, applicationId {} and formConfigId {}", tenant,
					applicationId, formConfigId);
			log.error(msg, e);
			throw e;
		}
	}

	public void deleteAll(User user, String tenant, Long applicationId, Long formConfigId, String compileStatusIdentifier) {

		try {

			applicationFacadeService.verifyAcceptDispositiveCalls(user, tenant, applicationId, formConfigId);

			List<DeclarationsOnSectorsNTT> ntts = dao.getByApplicationId(applicationId);

			if (ntts != null && !ntts.isEmpty()) {

				for (DeclarationsOnSectorsNTT ntt : ntts) {
					dao.expire(applicationId, ntt.getPkid(), OffsetDateTime.now(), user.getUserId());
				}
			} else {
				log.info("Unable to find item with application id = " + applicationId);
			}

			applicationFacadeService.deleteCompileStatus(user, tenant, applicationId, compileStatusIdentifier);

		} catch (Exception e) {
			String msg = GenericUtility.formatStr("Unable to complete 'deleteAll' method due an error for tenant {}, applicationId {} and formConfigId {}",
					tenant, applicationId, formConfigId);
			log.error(msg, e);
			throw e;
		}
	}

	@Override
	protected boolean hasPrimaryKey() {
		return true;
	}

	@Override
	protected void deleteByCustomKey(Void customKey) {
		throw throwNotImplementedException.get();
	}

	@Override
	protected void setCustomSearchKey(DeclarationsOnSectorsNTT rs, Void customKey) {
		throw throwNotImplementedException.get();
	}

	@Override
	protected Optional<DeclarationsOnSectorsNTT> findRsByCustomKey(Void customKey) {
		return Optional.empty();
	}

	private List<DeclarationsOnSectorsNTT> convert(List<DeclarationsOnSectorsDTO> dtos) {
		DeclarationsOnSectorsNTT ntt = null;
		List<DeclarationsOnSectorsNTT> ntts = new ArrayList<>();

		for (DeclarationsOnSectorsDTO dto : dtos) {
			Long id = 0L;
			if (dto.getIds() != null && !dto.getIds().isEmpty()) {
				id = dto.getIds().get(0);
			}
			ntt = convert(dto, id);
			ntts.add(ntt);
		}

		return ntts;
	}

	private DeclarationsOnSectorsNTT convert(DeclarationsOnSectorsDTO dto, Long id) {
		Long dtoFirstId = 0L;
		if (dto.getIds() != null && !dto.getIds().isEmpty()) {
			dtoFirstId = dto.getIds().get(0);
		}
		var pkid = id == null ? dtoFirstId : id;
		return DeclarationsOnSectorsNTT.builder()
				.pkid(pkid)
				.applicationId(dto.getApplicationId())
				.sectorCode(dto.getSectorCode())
				.landUseCode(dto.getLandUseCode())
				.areaSqm(dto.getAreaSqm())
				.mas(dto.getMas())
				.flZvn((short) (dto.isFlZvn() ? 1 : 0))
				.dtInsert(OffsetDateTime.now())
				.dtDelete(dto.getDtDelete())
				.userIdInsert(dto.getUserIdInsert())
				.userIdDelete(null)
				.build();
	}

	private boolean existsAtLeastOneElement(Long applicationId) {
		return dao.count(applicationId) > 0;
	}

	public List<DeclarationsOnSectorsDTO> updateMassive(User user, @NotNull String tenant, @NotNull Long applicationId, @NotNull Long formConfigId,
			String compileStatusIdentifier, @NotNull DeclarationsOnSectorsDTO payload) {

		//applicationFacadeService.verifyAcceptDispositiveCalls(user, tenant, applicationId, formConfigId);
		var oldNtts = dao.getByIds(payload.getIds());
		//		List<DeclarationsOnSectorsNTT> ntts = new ArrayList<>();
		var isImport = dao.existsImport(applicationId);
		payload.getIds().forEach(id -> {
			var entity = oldNtts.stream().filter(f -> f.getPkid().equals(id))
					.findFirst().orElse(null);
			if (entity != null) {
				if (!isImport) {
					entity.setAreaSqm(payload.getAreaSqm());
					entity.setSectorCode(payload.getSectorCode());
				}
				entity.setMas(payload.getMas());
			}
		});
		dao.upsertMany(oldNtts);
		applicationFacadeService.updateCompileStatus(user, tenant, applicationId, compileStatusIdentifier, CompileStatusEnum.COMPLETED);
		var newIds = oldNtts.stream().map(DeclarationsOnSectorsNTT::getPkid).toList();
		return returnMappedList(dao.getByIds(newIds));
	}

	public List<DeclarationsOnSectorsNTT> getByIds(List<Long> ids) {
		return dao.getByIds(ids);
	}
}
