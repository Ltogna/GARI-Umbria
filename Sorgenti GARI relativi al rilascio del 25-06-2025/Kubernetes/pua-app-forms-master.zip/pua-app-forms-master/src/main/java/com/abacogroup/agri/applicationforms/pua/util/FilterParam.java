package com.abacogroup.agri.applicationforms.pua.util;

import com.abacogroup.jdbi.criteria.Criteria;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 
 * @author Emanuele Crocilla
 *
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class FilterParam {
	
	private String javaName; 
	private String dbName; 
	private Object value;
	private Criteria criteria;
	private boolean active;
	
	public String getJavaType() {
		return value.getClass().getSimpleName();
	}

	public FilterParam(String paramName, String dbName, Object value) {
		this(paramName, dbName, value, null, false);
	}
}
