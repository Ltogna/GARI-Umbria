package com.abacogroup.agri.applicationforms.pua.core.exceptions;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.ws.rs.core.Response;

public class FileStoreIORuntimeException extends AbstractException {

	private static final long serialVersionUID = 1L;

	private static final FileStoreIORuntimeException.ErrorBody BODY = new FileStoreIORuntimeException.ErrorBody();

	public FileStoreIORuntimeException(String message) {
		super(Response.Status.INTERNAL_SERVER_ERROR, BODY, message);
	}

	@Schema(name = "FileStoreIORuntimeExceptionErrorBody")
	public static class ErrorBody implements ExceptionErrorBody {
		private static final String ERR = "GENERIC_ERROR";

		@Override
		@Schema(allowableValues = ERR)
		public String getErrorCode() {
			return ERR;
		}
	}
}
