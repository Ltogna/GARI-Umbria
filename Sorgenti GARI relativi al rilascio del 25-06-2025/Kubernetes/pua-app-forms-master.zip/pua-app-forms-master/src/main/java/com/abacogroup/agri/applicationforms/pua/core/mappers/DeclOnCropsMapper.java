package com.abacogroup.agri.applicationforms.pua.core.mappers;

import com.abacogroup.agri.applicationforms.pua.core.model.dto.DeclOnCropsDTO;
import com.abacogroup.agri.applicationforms.pua.core.model.dto.DeclOnCropsPrevEffluentsDTO;
import com.abacogroup.agri.applicationforms.pua.db.ntt.DeclOnCropsNTT;
import com.abacogroup.agri.applicationforms.pua.db.ntt.DeclOnCropsPrevEffluentsNTT;
import com.abacogroup.agri.applicationforms.pua.util.GenericUtility;
import com.abacogroup.jdbi.mapper.AbsoluteDateMapper;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;
import org.mapstruct.factory.Mappers;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

/**
 * @author Emanuele Crocilla
 */
@Mapper(uses = AbsoluteDateMapper.class)
public interface DeclOnCropsMapper extends EntityMapper<DeclOnCropsDTO, DeclOnCropsNTT> {

	DeclOnCropsMapper INSTANCE = Mappers.getMapper(DeclOnCropsMapper.class);

	@InheritInverseConfiguration()
	@Mapping(source = "pkid", target = "ids", qualifiedByName = "fromPkIdToIds")
	@Mapping(source = "flZvn", target = "flZvn", qualifiedByName = "shortToBoolean")
	@Mapping(source = "cycle", target = "cycle", qualifiedByName = "stringToInt")
	@Mapping(source = "version", target = "declarationVersion")
	@Mapping(source = "previousEffluents", target = "previousEffluents", qualifiedByName = "mapPrevEffluentsFromNTTtoDTO")
	DeclOnCropsDTO entityToDto(DeclOnCropsNTT entity);

	@Mapping(source = "ids", target = "pkid", qualifiedByName = "fromIdsToPkId")
	@Mapping(source = "flZvn", target = "flZvn", qualifiedByName = "booleanToShort")
	@Mapping(source = "cycle", target = "cycle", qualifiedByName = "intToString")
	@Mapping(source = "declarationVersion", target = "version")
	@Mapping(source = "previousEffluents", target = "previousEffluents", qualifiedByName = "mapPrevEffluentsFromDTOtoNTT")
	@Mapping(source = "totResidualNitrogen", target = "totResidualNitrogen", qualifiedByName = "truncateToFourDecimals")
	DeclOnCropsNTT dtoToEntity(DeclOnCropsDTO dto);

	@Named("mapPrevEffluentsFromDTOtoNTT")
	default List<DeclOnCropsPrevEffluentsNTT> mapPrevEffluentsFromDTOtoNTT(List<DeclOnCropsPrevEffluentsDTO> prevEffluents) {
		return prevEffluents == null ? Collections.emptyList() : prevEffluents.stream()
				.map(DeclOnCropsPrevEffluentsMapper.INSTANCE::dtoToEntity)
				.collect(Collectors.toList());

	}

	@Named("mapPrevEffluentsFromNTTtoDTO")
	default List<DeclOnCropsPrevEffluentsDTO> mapPrevEffluentsFromNTTtoDTO(List<DeclOnCropsPrevEffluentsNTT> prevEffluents) {
		return prevEffluents == null ? Collections.emptyList() : prevEffluents.stream()
				.map(DeclOnCropsPrevEffluentsMapper.INSTANCE::entityToDto)
				.collect(Collectors.toList());

	}

	@Named("shortToBoolean")
	default boolean shortToBoolean(short value) {
		return value != 0;
	}

	@Named("booleanToShort")
	default short booleanToShort(boolean value) {
		return value ? (short) 1 : (short) 0;
	}

	@Named("stringToInt")
	default Integer stringToInt(String s) {
		return GenericUtility.isDigit(s) ? Integer.parseInt(s) : null;
	}

	@Named("intToString")
	default String intToString(Integer i) {
		return String.valueOf(i);
	}

	@Named("fromPkIdToIds")
	default List<Long> fromPkIdToIds(Long pkId) {
		return pkId == null ? null : Collections.singletonList(pkId);
	}

	@Named("fromIdsToPkId")
	default Long fromIdsToPkId(List<Long> ids) {
		return ids != null && !ids.isEmpty() ? ids.get(0) : null;
	}
	
	@Named("truncateToFourDecimals")
	default BigDecimal truncateToFourDecimals(BigDecimal in) {
		return in.setScale(4, RoundingMode.DOWN);
	}
}
