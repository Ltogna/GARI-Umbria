package com.abacogroup.agri.applicationforms.pua.db.dao;

import java.time.LocalDateTime;
import java.util.List;

import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;

import com.abacogroup.agri.applicationforms.pua.util.CurrentDB;
import com.abacogroup.jdbi.paging.PagingParams;

/**
 * 
 * @author Emanuele Crocilla
 *
 * @param <T>
 * @param <D>
 */
public interface IGenericPuaDAO<T, D> extends ReadOnlyDAO<T, D> {
	
	@SqlUpdate
	void insert(T rs);

	@SqlUpdate
	void update(T rs);

	@SqlUpdate
	void deleteById(D id);

	@SqlQuery("select §current_timestamp§")
	LocalDateTime getCurrentTimestampPostgres();

	@SqlQuery("select §current_timestamp§ from dual")
	LocalDateTime getCurrentTimestampOracle();

	default LocalDateTime getCurrentTimestamp() {
		if (Boolean.TRUE.equals(CurrentDB.isPostgres())) {
			return this.getCurrentTimestampPostgres();
		} else {
			return this.getCurrentTimestampOracle();
		}
	}
	
	@SqlQuery
	List<T> findById(D id);

	@SqlQuery
	D nextSequenceVal();

	@SqlQuery
	List<T> findPagedType(PagingParams pp);
	
	@SqlQuery
	int count(D id);
	
}
