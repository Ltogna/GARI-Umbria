package com.abacogroup.agri.applicationforms.pua.services;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.function.Consumer;
import java.util.stream.Collectors;

import org.locationtech.jts.geom.Geometry;

import com.abacogroup.agri.applicationforms.pua.ApplicationFormsModuleConfiguration;
import com.abacogroup.agri.applicationforms.pua.core.model.dto.CropPlanResponse;
import com.abacogroup.agri.applicationforms.pua.core.model.dto.GeometryObjectRequest;
import com.abacogroup.agri.applicationforms.pua.core.model.dto.IntersectionResponse;
import com.abacogroup.agri.applicationforms.pua.core.model.dto.PlotRecord;
import com.abacogroup.agri.applicationforms.pua.core.model.dto.PlotRecord.Declaration;
import com.abacogroup.agri.applicationforms.pua.core.model.dto.RecordResponse;
import com.abacogroup.agri.applicationforms.pua.core.model.dto.VersionResponse;
import com.abacogroup.agri.applicationforms.pua.util.ClientHelper;
import com.abacogroup.agri.applicationforms.pua.util.GenericUtility;
import com.abacogroup.agri.applicationforms.pua.util.ReqContext;
import com.abacogroup.dropwizard.auth.sso2.Sso2Client;
import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import jakarta.ws.rs.client.Client;
import jakarta.ws.rs.core.GenericType;
import jakarta.ws.rs.core.MultivaluedHashMap;
import lombok.extern.slf4j.Slf4j;

/**
 * 
 * @author Emanuele Crocilla
 *
 */
@Slf4j
public class CropPlanService extends ADataImporterService {

	private final ClientHelper clientHelper;

	public CropPlanService(Sso2Client sso2client, Client client, ApplicationFormsModuleConfiguration config, ObjectMapper objectMapper) {
		super(sso2client, client, config, objectMapper);
		this.clientHelper = new ClientHelper(this.client.target(config.getCropPlanUrl()));
	}

	public RecordResponse<CropPlanResponse> getCropPlans(User user, String tenantId, Long businessId, String cropPlanTypeCode) {

		try {

			authToken = user.getAuthToken();
			String url = String.format("%s/%s/public/v1/crop-plans/%s/plans?cropPlanTypeCode=%s", cropPlanUrl, tenantId, businessId, cropPlanTypeCode);
			var cropPlans = sendGetRequestWithAuth(url, new TypeReference<RecordResponse<CropPlanResponse>>() {
			}, tenantId, "getCropPlans");
			if (cropPlans.getCount() > 1) {
				throw new RuntimeException("Crop Plan can not be more than one.");
			}
			return cropPlans;

		} 
		catch (Exception e) {
			String msg = GenericUtility.formatStr("Unable to complete 'getCropPlans' method due an error for tenant {}, businessId {} and cropPlanTypeCode {}", tenantId, businessId, cropPlanTypeCode);
			log.error(msg, e);
			throw e;
		}
	}
	
	public RecordResponse<VersionResponse> getVersionCropPlan(User user, String tenantId, Long businessId, Integer cropPlanId, Integer campagna) {

		try {
			authToken = user.getAuthToken();
			RecordResponse<VersionResponse> result = new RecordResponse<>();
			result.setRecords(new ArrayList<>());
			AtomicBoolean hasCorrectYear = new AtomicBoolean(false);
			String nextKey = null;
			do {
				String url = String.format("%s/%s/public/v1/crop-plans/%s/plans/%s/versions", cropPlanUrl, tenantId, businessId, cropPlanId);
				RecordResponse<VersionResponse> data = sendGetRequestWithAuth(url, new TypeReference<RecordResponse<VersionResponse>>() {
				}, tenantId, "getVersionCropPlan");
				data.getRecords().forEach(record -> {
					AbsoluteDate versionDate = AbsoluteDate.of(record.getVersionReferenceDate());
					if (versionDate.toLocalDate().getYear() >= campagna) {
						result.getRecords().add(record);
						hasCorrectYear.set(true);
					}
				});
				nextKey = data.getNextKey();
			} while (nextKey != null && !hasCorrectYear.get());
			if (result.getCount() > 1 && !hasCorrectYear.get()) { //version with lower date
				throw new RuntimeException("No matching version data found in the crop plan response.");
			}
			return result;

		} 
		catch (Exception e) {
			String msg = GenericUtility.formatStr("Unable to complete 'getVersionCropPlan' method due an error for tenant {}, businessId {} and cropPlanId {}", tenantId, businessId, cropPlanId);
			log.error(msg, e);
			throw e;
		}
	}
	
	public RecordResponse<PlotRecord> plotCropPlan(User user, String tenantId, Long businessId, Integer cropPlanId, String version, int campaignYear) {

		try {
			authToken = user.getAuthToken();

			String pointInTime = String.valueOf(campaignYear-1) + "1111"; // eg. 20231111
			String pointInTimeTo = String.valueOf(campaignYear) + "1011"; // eg. 20241011

			String excludesChunk = "&excludes=PARCELS&excludes=PARCELS_DESCRIPTION&excludes=PARCELS_LAND_COVER_DESC&excludes=PARCELS_MBR_OVERVIEW&excludes=PARCELS_PLOT_STYLE&excludes=PARCELS_PLOT_EDITABILITY&excludes=DECLARATIONS_PLOT_STYLE&excludes=DECLARATIONS_PESTICIDES&excludes=ANOMALIES";
			String unformattedUrl = "%s/%s/public/v1/crop-plans/%s/plans/%s/plots?version=%s&pointInTime=%s&pointInTimeTo=%s&nextKey=%s%s";
			RecordResponse<PlotRecord> plotResult = null;
			RecordResponse<PlotRecord> globalPlotResult = new RecordResponse<>();
			String nextKey = "1";

			globalPlotResult.setRecords(new ArrayList<>());

			do {

				Object[] args = { cropPlanUrl, tenantId, businessId, cropPlanId, version, pointInTime, pointInTimeTo, nextKey, excludesChunk };
				String url = String.format(unformattedUrl, args);

				plotResult = sendGetRequestWithAuth(url, new TypeReference<RecordResponse<PlotRecord>>() {}, tenantId, "plotCropPlan");

				if (plotResult != null) {
					if (plotResult.getRecords() != null) {
						globalPlotResult.getRecords().addAll(plotResult.getRecords());
						globalPlotResult.setCount(globalPlotResult.getCount() + plotResult.getCount());
					}
				}
				else {
					throw new RuntimeException("Error on plotCropPlan");
				}

			} while ( (nextKey = plotResult.getNextKey()) != null );

			return globalPlotResult;

		} 
		catch (Exception e) {
			String msg = GenericUtility.formatStr("Unable to complete 'getVersionCropPlan' method due an error for tenant {}, businessId {}, cropPlanId {}, version {} and campaignYear {}", tenantId, businessId, cropPlanId, version, campaignYear);
			log.error(msg, e);
			throw e;
		}
	}

	public boolean thereAreAnyIntersections(Geometry geometry, String tenant, String srs) {
		
		try {
			
			// TODO to define the minimum accepted area ( X < 100 m2 && 10% area geometry )
			double minimumAcceptedArea = 1.0;
			 
			var intersections = getIntersections(geometry, tenant, srs);

			for(IntersectionResponse intersection: intersections){
				if(intersection != null && intersection.getAreaSqm() >= minimumAcceptedArea){
					return true;
				}
			}
			return false;
					
		} catch (Exception ex) {
			checkResponseStatus(null, "", tenant, "", "sendIntersectionRequest", ex);
			throw new RuntimeException("Error processing response", ex);
		}
	}

	// Read DomainZone / get Intersections 
	public ArrayList<IntersectionResponse> getIntersections(Geometry geometry, String tenant, String srs) {
		
		try {
			
			String date = AbsoluteDate.of(LocalDate.now()).toString();
			String nextKey = null;
			ArrayList<IntersectionResponse> allRecords = new ArrayList<>();
			GeometryObjectRequest request = new GeometryObjectRequest(geometry);
			String layerCode = "ZVN"; // "BLOCKS";
			
			do {
				
				var responseType = new TypeReference<RecordResponse<IntersectionResponse>>() {};
				String url = String.format("%s/%s/public/v1/layers/%s/geometries/intersection?reference_date=%s&srs=%s%s",
						vectorDataLayersUrl, tenant, layerCode, date, srs, (nextKey != null ? ("&nextKey=" + nextKey) : ""));
				
				var data = sendPostRequestWithAuth(url, request, responseType, "sendIntersectionRequest", tenant);
				
				allRecords.addAll(data.getRecords());
				
				nextKey = data.getNextKey();
			} 
			while (nextKey != null);

			return allRecords;
		} catch (Exception ex) {
			checkResponseStatus(null, "", tenant, "", "getIntersections", ex);
			throw new RuntimeException("Error processing response", ex);
		}
	}
	
	public List<Declaration> getPlotDeclarations(String lang, User user, String businessId, Long cropPlanId,
			String declCode, String versionRawValue, AbsoluteDate pointInTimeFrom, AbsoluteDate pointInTimeTo) {
		
		List<Declaration> declarations = new ArrayList<>();
		
		Consumer<Declaration> consumer = declarations::add;
		
		ReqContext reqContext = new ReqContext(user, lang);

		String api = "/{tenant}/public/v1/crop-plans/{businessId}/plans/{cropPlanId}/declarations";

		MultivaluedHashMap<String, Object> queryParams = new MultivaluedHashMap<>();
		if (null != versionRawValue && !versionRawValue.isBlank()) {
			queryParams.add("version", versionRawValue);
		}
		if (null != declCode && !declCode.isBlank()) {
			queryParams.add("declCodes", declCode);
		}
		queryParams.add("pointInTime", pointInTimeFrom);
		queryParams.add("pointInTimeTo", pointInTimeTo);

		clientHelper.consumeAllFromInfiniteResult(api, reqContext,
				Map.of("tenant", user.getTenant(), "businessId", businessId, "cropPlanId", cropPlanId), queryParams,
				new GenericType<>() {
				}, consumer);
		
		return declarations;

	}
	
	public List<Declaration> getPlotDeclarations(User user, String tenantId, Long businessId, int year, String declCode, String version) {
		
		AbsoluteDate pointInTimeFrom = AbsoluteDate.of((year-1) + "1111");
		AbsoluteDate pointInTimeTo = AbsoluteDate.of(year + "1110");
		
		RecordResponse<CropPlanResponse> cropPlans = this.getCropPlans(user, tenantId , businessId, "CROPPLAN");
		
		int cropPlanId = cropPlans.getRecords().get(0).getCropPlanId();
		
		List<Declaration> plotDeclarations = 
				this.getPlotDeclarations("it", user, String.valueOf(businessId), Long.valueOf(cropPlanId), 
						declCode, version, pointInTimeFrom, pointInTimeTo);
		
		return plotDeclarations;
	}
	
	public List<PlotRecord> getPlotCropPlans(User user, String tenantId, Long businessId, int year, String declCode, String version) {
		 
		RecordResponse<CropPlanResponse> cropPlans = this.getCropPlans(user, tenantId , businessId, "CROPPLAN");
		
		List<PlotRecord> res = new ArrayList<>();
		
		List<Integer> cropPlanIds = cropPlans.getRecords().stream().map(record -> record.getCropPlanId()).toList();

		RecordResponse<PlotRecord> plotCropPlan = null;
		
		for (Integer cropPlanId : cropPlanIds) {
			plotCropPlan = this.plotCropPlan(user, tenantId, businessId, cropPlanId, version, year);
			res.addAll(plotCropPlan.getRecords());
		}
		 
		return res;
	}
	
	public List<Declaration> getPlotDeclarations(List<PlotRecord> plotCropPlanRecords) {
		
		if (plotCropPlanRecords != null) {
			return plotCropPlanRecords.stream().flatMap(plotRecord -> plotRecord.getDecls().stream())
					.collect(Collectors.toList());
		}
		
		return Collections.emptyList();
	}

}
