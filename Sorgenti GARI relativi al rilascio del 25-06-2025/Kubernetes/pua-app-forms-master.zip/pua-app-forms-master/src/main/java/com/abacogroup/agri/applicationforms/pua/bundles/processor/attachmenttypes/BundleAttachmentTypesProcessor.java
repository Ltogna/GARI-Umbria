package com.abacogroup.agri.applicationforms.pua.bundles.processor.attachmenttypes;

import java.nio.file.Path;

import org.jdbi.v3.core.Jdbi;

import com.abacogroup.agri.applicationforms.pua.bundles.model.attachmenttypes.BundleAttachmentTypesMessage;
import com.abacogroup.agri.applicationforms.pua.bundles.processor.AbstractBundleApplicationFormsProcessor;
import com.abacogroup.bundles.listener.configdata.ConfigDataMessage;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.extern.slf4j.Slf4j;

/**
 * @author Alexandru Paraschiv
 */
@Slf4j
public class BundleAttachmentTypesProcessor extends AbstractBundleApplicationFormsProcessor<BundleAttachmentTypesMessage> {

	protected final AttachmentTypesBundleWorker attachmentTypesBundleWorker;

	public BundleAttachmentTypesProcessor(ObjectMapper objectMapper, AttachmentTypesBundleWorker attachmentTypesBundleWorker, Jdbi jdbi) {
		super(objectMapper, jdbi);
		this.attachmentTypesBundleWorker = attachmentTypesBundleWorker;
	}

	@Override
	public String getDomainName() {
		return "attachment-types";
	}

	@Override
	protected TypeReference<BundleAttachmentTypesMessage> getTypeReference() {
		return new TypeReference<>() {
		};
	}

	@Override
	public void onMessageInTransaction(ConfigDataMessage message) {
		log.info("BundleAttachmentTypesProcessor: proccessing file with tenant {}", message.getTenantId());
		message.getConfigFiles().stream()
				.map(Path::toFile)
				.filter(file -> file.getAbsolutePath().endsWith(".json"))
				.forEach(file -> processFile(message.getTenantId(), file));
	}

	@Override
	protected void delete(String tenantId, BundleAttachmentTypesMessage message) {
		attachmentTypesBundleWorker.delete(tenantId, message);
	}

	@Override
	protected void doInsertOrUpdate(String tenantId, BundleAttachmentTypesMessage message) {
		attachmentTypesBundleWorker.upsert(tenantId, message);
	}

}
