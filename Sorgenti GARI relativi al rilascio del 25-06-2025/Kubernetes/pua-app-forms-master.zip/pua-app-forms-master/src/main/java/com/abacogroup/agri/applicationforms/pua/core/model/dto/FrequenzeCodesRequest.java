package com.abacogroup.agri.applicationforms.pua.core.model.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.List;

@Data
public class FrequenzeCodesRequest {
	@JsonProperty("effluentCodes")
	private List<String> effluentCodes;

	public FrequenzeCodesRequest() {
	}

}
