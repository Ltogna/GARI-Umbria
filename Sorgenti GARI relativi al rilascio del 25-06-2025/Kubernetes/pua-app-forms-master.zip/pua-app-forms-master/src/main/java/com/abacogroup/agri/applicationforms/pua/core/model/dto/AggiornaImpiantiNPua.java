package com.abacogroup.agri.applicationforms.pua.core.model.dto;

import java.math.BigDecimal;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 
 * @author Emanuele Crocilla
 *
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AggiornaImpiantiNPua {

	@JsonProperty("Cuaa")
	private String cuaa;

	@JsonProperty("Regolamento_Cod")
	private Integer regolamentoCod;

	@JsonProperty("ElencoAppezzamenti")
	private List<Appezzamento> elencoAppezzamenti;

	@Data
	@Builder
	@NoArgsConstructor
	@AllArgsConstructor
	public static class Appezzamento {

		@JsonProperty("Chiave_Appezzamento")
		private String chiaveAppezzamento;

		@JsonProperty("N_Pua")
		private BigDecimal nPua;

		@Override
		public String toString() {
			return "Appezzamento [chiaveAppezzamento=" + chiaveAppezzamento + ", nPua=" + nPua + "]";
		}
	}

	@Override
	public String toString() {
		return "AggiornaImpiantiNPua [cuaa=" + cuaa + ", regolamentoCod=" + regolamentoCod + ", elencoAppezzamenti=" + elencoAppezzamenti + "]";
	}
}
