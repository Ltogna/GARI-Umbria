package com.abacogroup.agri.applicationforms.pua.services;

import static com.abacogroup.agri.applicationforms.pua.util.GenericUtility.throwNotImplementedException;

import java.time.OffsetDateTime;
import java.util.Collections;
import java.util.Locale;
import java.util.Optional;

import com.abacogroup.agri.applicationforms.pua.core.mappers.TipologiaDichiarazioneMapper;
import com.abacogroup.agri.applicationforms.pua.core.model.CompileStatusEnum;
import com.abacogroup.agri.applicationforms.pua.core.model.dto.TipologiaDichiarazioneDTO;
import com.abacogroup.agri.applicationforms.pua.db.dao.TipologiaDichiarazioneDAO;
import com.abacogroup.agri.applicationforms.pua.db.ntt.TipologiaDichiarazioneNTT;
import com.abacogroup.agri.applicationforms.pua.services.common.ApplicationFacadeService;
import com.abacogroup.agri.applicationforms.pua.services.common.crud.AbstractCrudService;
import com.abacogroup.agri.applicationforms.pua.util.DbUtils;
import com.abacogroup.agri.applicationforms.pua.util.GenericUtility;
import com.abacogroup.applicationworkflowsdk.model.io.output.ApplicationDetailsPublicDTO;
import com.abacogroup.dropwizard.auth.sso2.User;

import lombok.extern.slf4j.Slf4j;

/**
 * 
 * @author Emanuele Crocilla
 *
 */
@Slf4j
public class TipologiaDichiarazioneService extends AbstractCrudService<TipologiaDichiarazioneNTT, Long, TipologiaDichiarazioneDTO, TipologiaDichiarazioneMapper, Void, TipologiaDichiarazioneDAO> {

	private final ApplicationFacadeService applicationFacadeService;

	public TipologiaDichiarazioneService(
			TipologiaDichiarazioneDAO dao, 
			ApplicationFacadeService applicationFacadeService,
			TipologiaDichiarazioneMapper mapper) {
		
		super(dao, mapper);
		this.applicationFacadeService = applicationFacadeService;
	}

	public TipologiaDichiarazioneDTO get(User user, String tenant, Long applicationId) {

		try {
			
			ApplicationDetailsPublicDTO applicationDetailsPublicDTO = 
					applicationFacadeService.callForApplicationDetails(tenant, applicationId, user, Locale.ITALIAN.getLanguage());
			
			log.info(applicationDetailsPublicDTO.toString());
			
			TipologiaDichiarazioneNTT ntt = dao.getByApplicationId(applicationId);

			if (ntt != null) {
				log.info("Retrieving of TipologiaDichiarazione completed for tenant {} and applicationId {} ", tenant, applicationId);
				return returnOptionalRecord(Collections.singletonList(ntt)).get();
			}
		} 
		catch (Exception e) {
			String msg = GenericUtility.formatStr("Unable to complete 'get' method due an unhandled error for tenant {} and applicationId {} ", tenant, applicationId);
			log.error(msg, e);
			throw e;
		}

		String msg = GenericUtility.formatStr("Unable to find TipologiaDichiarazione item with tenant = {} and application id = {} due unhandled error ", tenant, applicationId);
		log.warn(msg);
		
		return null;
	}

	public TipologiaDichiarazioneDTO insert(User user, String tenant, Long applicationId, Long formConfigId, String compileStatusIdentifier, TipologiaDichiarazioneDTO dto) {
		
		try {
			applicationFacadeService.verifyAcceptDispositiveCalls(user, tenant, applicationId, formConfigId);
			
			TipologiaDichiarazioneNTT tipologiaDichiarazione = TipologiaDichiarazioneNTT.builder()
			    	.applicationId(dto.getApplicationId())
			    	.year(dto.getYear())
			    	.flOrganicFert(DbUtils.convertBoolFlag(dto.isFlOrganicFert()))
			    	.flLivestocks(DbUtils.convertBoolFlag(dto.isFlLivestocks()))
			    	.dtInsert(OffsetDateTime.now())
			    	.dtDelete(dto.getDtDelete())
			    	.userIdInsert(dto.getUserIdInsert())
			    	.userIdDelete(null)
			    	.build();
			
			dao.insert(tipologiaDichiarazione);
			
			// update compile status
			applicationFacadeService.updateCompileStatus(user, tenant, applicationId, compileStatusIdentifier, CompileStatusEnum.COMPLETED);
			
			log.info("Insert of TipologiaDichiarazione completed for tenant {} applicationId {} formConfigId {}", tenant, applicationId, formConfigId);
			
			var res = dao.getByApplicationId(dto.getApplicationId());
			return returnOptionalRecord(Collections.singletonList(res)).get();
		} 
		catch (Exception e) {
			String msg = GenericUtility.formatStr("Unable to complete 'insert' method due an error for tenant {} applicationId {} formConfigId {}", tenant, applicationId, formConfigId);
			log.error(msg, e);
			throw e;
		}
	}

	public TipologiaDichiarazioneDTO update(User user, String tenant, Long applicationId, Long formConfigId, String compileStatusIdentifier, TipologiaDichiarazioneDTO dto) {

		try {
			applicationFacadeService.verifyAcceptDispositiveCalls(user, tenant, applicationId, formConfigId);

			TipologiaDichiarazioneNTT tipologiaDichiarazione = TipologiaDichiarazioneNTT.builder()
					.applicationId(dto.getApplicationId())
					.year(dto.getYear())
					.flOrganicFert(DbUtils.convertBoolFlag(dto.isFlOrganicFert()))
					.flLivestocks(DbUtils.convertBoolFlag(dto.isFlLivestocks()))
					.dtInsert(OffsetDateTime.now())
					.dtDelete(dto.getDtDelete())
					.userIdInsert(dto.getUserIdInsert())
					.userIdDelete(null)
					.build();

			dao.upsert(tipologiaDichiarazione);
			
			// update compile status
			applicationFacadeService.updateCompileStatus(user, tenant, applicationId, compileStatusIdentifier, CompileStatusEnum.COMPLETED);
			
			log.info("Update of TipologiaDichiarazione completed for tenant {}, applicationId {} and formConfigId {}", tenant, applicationId, formConfigId);
			
			var res = dao.getByApplicationId(dto.getApplicationId());
			return returnOptionalRecord(Collections.singletonList(res)).get();
		} 
		catch (Exception e) {
			String msg = GenericUtility.formatStr("Unable to complete the 'update' method due an error for tenant {}, applicationId {} and formConfigId {}", tenant, applicationId, formConfigId);
			log.error(msg, e);
			throw new RuntimeException(msg, e);
		}
	}

	public boolean delete(User user, String tenant, Long applicationId, Long formConfigId, String compileStatusIdentifier) {

		try {
			applicationFacadeService.verifyAcceptDispositiveCalls(user, tenant, applicationId, formConfigId);

			TipologiaDichiarazioneNTT ntt = dao.getByApplicationId(applicationId);

			if (ntt != null) {
				
				ntt.setUserIdDelete(user.getUserId());
				ntt.setDtDelete(OffsetDateTime.now());
				dao.expire(ntt);

				applicationFacadeService.deleteCompileStatus(user, tenant, applicationId, compileStatusIdentifier);
				
				log.info("Delete of TipologiaDichiarazione completed for tenant {}, applicationId {} and formConfigId {}", tenant, applicationId, formConfigId);
				return true;
			}
			else {
				log.warn("Unable to find application id = " + applicationId);
				return false;
			}
		} 
		catch (Exception e) {
			String msg = GenericUtility.formatStr("Unable to complete 'delete' method due an error for tenant {}, applicationId {} and formConfigId {}", tenant, applicationId, formConfigId);
			log.error(msg, e);
			throw e;
		}
	}

	@Override
	protected boolean hasPrimaryKey() {
		return true;
	}

	@Override
	protected void deleteByCustomKey(Void customKey) {
		throw throwNotImplementedException.get();
	}

	@Override
	protected void setCustomSearchKey(TipologiaDichiarazioneNTT rs, Void customKey) {
		throw throwNotImplementedException.get();
	}

	@Override
	protected Optional<TipologiaDichiarazioneNTT> findRsByCustomKey(Void customKey) {
		return Optional.empty();
	}

}
