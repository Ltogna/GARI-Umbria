package com.abacogroup.agri.applicationforms.pua.db.ntt;

import java.util.Optional;

import com.abacogroup.agri.applicationforms.pua.db.ntt.applications.IIdRs;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author Alexandru Paraschiv
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class OptionCatalogNTT implements IIdRs<Long> {

	private Long id;
	private String tenant_id;
	private String option_code;
	private String option_description;

	@Override
	public Optional<Long> getKey() {
		return Optional.ofNullable(this.getId());
	}

	@Override
	public void setKey(Long id) {
		this.id = id;
	}

}
