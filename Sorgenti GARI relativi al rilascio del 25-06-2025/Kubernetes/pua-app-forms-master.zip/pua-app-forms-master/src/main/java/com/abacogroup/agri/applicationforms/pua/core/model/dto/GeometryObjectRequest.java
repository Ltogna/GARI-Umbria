package com.abacogroup.agri.applicationforms.pua.core.model.dto;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.NoArgsConstructor;
import org.locationtech.jts.geom.Geometry;
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class GeometryObjectRequest {

		@JsonProperty("touchingGeometry")
		private Geometry touchingGeometry;

		public Geometry getTouchingGeometry() {
			return touchingGeometry;
		}

		public void setTouchingGeometry(Geometry touchingGeometry) {
			this.touchingGeometry = touchingGeometry;
		}
}
