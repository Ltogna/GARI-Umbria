package com.abacogroup.agri.applicationforms.pua.core.model.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class BalanceIndicesRequest {

	@JsonProperty("Cuaa")
	private String Cuaa;

	@JsonProperty("Regolamento_Cod")
	private Integer Regolamento_Cod;

	@JsonProperty("ElencoAppezzamenti")
	private List<AppezzamentoRequest> ElencoAppezzamenti;
}
