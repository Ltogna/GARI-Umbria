package com.abacogroup.agri.applicationforms.pua.core.model;

/**
 * 
 * @author Emanuele Crocilla
 *
 */
public enum CompileStatusEnum {
	IN_PROGRESS,
	COMPLETED;
}
