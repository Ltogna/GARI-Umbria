package com.abacogroup.agri.applicationforms.pua.db.dao;

import java.util.List;

import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.transaction.Transactional;

import com.abacogroup.jdbi.EnhancedSqlObject;

/**
 * @author Mauro Pozzana
 * @param <T>
 *            The RS type class
 * @param <D>
 *            The RS type's ID type
 */
public interface ReadOnlyDAO<T, D> extends EnhancedSqlObject, Transactional<ReadOnlyDAO<T, D>> {
	@SqlQuery
	List<T> findById(D id);
}
