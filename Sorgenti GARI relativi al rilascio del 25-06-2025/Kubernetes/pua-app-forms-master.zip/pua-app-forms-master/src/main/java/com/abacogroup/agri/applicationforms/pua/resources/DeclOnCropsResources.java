package com.abacogroup.agri.applicationforms.pua.resources;

import com.abacogroup.agri.applicationforms.pua.ApplicationFormsModuleConfiguration;
import com.abacogroup.agri.applicationforms.pua.core.exceptions.AgronicaGenericException;
import com.abacogroup.agri.applicationforms.pua.core.exceptions.InvalidParameterRuntimeException;
import com.abacogroup.agri.applicationforms.pua.core.exceptions.InvalidParameterRuntimeException.ValidationError;
import com.abacogroup.agri.applicationforms.pua.core.exceptions.ObjectNotFoundException;
import com.abacogroup.agri.applicationforms.pua.core.exceptions.ObjectNotFoundRuntimeException;
import com.abacogroup.agri.applicationforms.pua.core.exceptions.PlotNotFoundRuntimeException;
import com.abacogroup.agri.applicationforms.pua.core.mappers.DeclOnCropsPrevEffluentsMapper;
import com.abacogroup.agri.applicationforms.pua.core.mappers.DeclOnCropsPrevEffluentsMapperImpl;
import com.abacogroup.agri.applicationforms.pua.core.model.dto.*;
import com.abacogroup.agri.applicationforms.pua.core.model.dto.AggiornaImpiantiNPua.Appezzamento;
import com.abacogroup.agri.applicationforms.pua.core.model.dto.PlotRecord.Declaration;
import com.abacogroup.agri.applicationforms.pua.core.model.dto.enums.Cycle;
import com.abacogroup.agri.applicationforms.pua.db.ntt.DeclOnCropsNTT;
import com.abacogroup.agri.applicationforms.pua.db.ntt.DeclOnCropsPrevEffluentsNTT;
import com.abacogroup.agri.applicationforms.pua.services.*;
import com.abacogroup.agri.applicationforms.pua.services.common.ApplicationFacadeService;
import com.abacogroup.agri.applicationforms.pua.services.common.DeclOnCropsSubdata;
import com.abacogroup.agri.applicationforms.pua.util.*;
import com.abacogroup.agri.applicationforms.pua.util.DeclOnCropsBuffer.DeclOnCropsBufferElement;
import com.abacogroup.applicationworkflowsdk.model.io.output.ApplicationDetailsPublicDTO;
import com.abacogroup.dropwizard.auth.sso2.Sso2Client;
import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import io.dropwizard.auth.Auth;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.parameters.RequestBody;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.constraints.NotNull;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.Context;
import jakarta.ws.rs.core.Response;
import lombok.extern.slf4j.Slf4j;
import org.locationtech.jts.geom.Geometry;
import org.locationtech.jts.io.WKTReader;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.OffsetDateTime;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.time.temporal.ChronoUnit;
import java.util.*;
import java.util.stream.Collectors;

/**
 * @author Emanuele Crocilla
 */
@Slf4j
public class DeclOnCropsResources extends AGenericPuaResources {

	private static final SimpleDateFormat DATE_FORMAT_FOR_YYYYMMDD = new SimpleDateFormat("yyyyMMdd");
	private static final String YMD = "YMD";

	public DeclOnCropsResources(ApplicationFormsModuleConfiguration configuration,
			ApplicationFacadeService applicationFacadeService,
			DeclOnCropsService declOnCropsService,
			CropPlanService cropPlanService,
			IpisGisService ipisGisService,
			BancheDatiService bancheDatiService,
			GiasAgronicaService giasService,
			Sso2Client sso2Client) {

		super(configuration, sso2Client);
		this.declOnCropsService = declOnCropsService;
		this.applicationFacadeService = applicationFacadeService;
		this.cropPlanService = cropPlanService;
		this.ipisGisService = ipisGisService;
		this.bancheDatiService = bancheDatiService;
		this.giasService = giasService;
	}

	@GET
	@Path("/{applicationId}/declaration-on-crop/{declatation_id}")
	public Response get(
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "Current Tenant") @NotNull @PathParam("tenant") String tenant,
			@Parameter(description = "The application id") @NotNull @PathParam("applicationId") Long applicationId,
			@Parameter(description = "The declatation id") @NotNull @PathParam("declatation_id") Long declarationId
	) {

		DeclOnCropsDTO dto = null;

		try {

			dto = declOnCropsService.get(user, tenant, applicationId, declarationId);
			if (dto.getDistributableNitrogen() != null && dto.getAreaSqm() != null) {
				//#TODO Check distributable insert if is negative number
				var distriNR = dto.getDistributableNitrogen().compareTo(BigDecimal.ZERO) >= 0 ? dto.getDistributableNitrogen() : BigDecimal.ZERO;
				dto.setTotalNitrogen(distriNR.multiply(BigDecimal.valueOf(dto.getAreaSqm())));
			}
			Integer precessionCode = dto.getPrecessionCode();
			if (null != precessionCode) {
				PrecedingCropType precessionDescription = bancheDatiService.getPrecedingCropType(user, tenant, precessionCode);
				dto.setPrecessionDescription(precessionDescription.getDescription());
			}

		} catch (ObjectNotFoundRuntimeException e) {
			return Response.noContent().build();
		}

		return Response.ok(dto).build();
	}

	@GET
	@Path("/{applicationId}/declarations-on-crops")
	public Response getAll(
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "Current Tenant") @NotNull @PathParam("tenant") String tenant,
			@Parameter(description = "The application id") @NotNull @PathParam("applicationId") Long applicationId,
			@Parameter(description = "The infinite list key") @QueryParam("nextKey") String nextKey,
			@Context HttpServletRequest request) {

		InfiniteListResults<DeclOnCropsDTO> dtos = null;

		try {

			Map<String, String[]> requestParams = FilterHandler.convertRequestParametersToMap(request);

			dtos = declOnCropsService.searchDeclOnCropsByFilter(user, tenant, applicationId, requestParams,
					null /* nextKey TODO EC UNCOMMENT THIS TO RESTORE PAGINATION */);

			dtos.getRecords().forEach(dto -> {
				if (dto.getDistributableNitrogen() != null && dto.getAreaSqm() != null) {
					//#TODO Check distributable insert if is negative number
					var distriNR = dto.getDistributableNitrogen().compareTo(BigDecimal.ZERO) >= 0 ? 
							dto.getDistributableNitrogen() : BigDecimal.ZERO;
					
					dto.setTotalNitrogen(distriNR.multiply(BigDecimal.valueOf(dto.getAreaSqm())));
				}
				Integer precessionCode = dto.getPrecessionCode();
				if (null != precessionCode) {
					PrecedingCropType precessionDescription = bancheDatiService.getPrecedingCropType(user, tenant, precessionCode);
					dto.setPrecessionDescription(precessionDescription != null ? precessionDescription.getDescription() : "");
				}
			});

		} catch (ObjectNotFoundRuntimeException e) {
			return Response.ok(Collections.emptyList()).build();
		}

		//		return Response.ok(dtos).build(); TODO EC UNCOMMENT THIS TO RESTORE PAGINATION
		return Response.ok(dtos.getRecords()).build();
	}

	@GET
	@Path("/{applicationId}/declarations-on-crops/{campaignYear}/import")
	public Response addMassive(
			@Auth User user,
			@Parameter(description = "Current Tenant") @NotNull @PathParam("tenant") String tenantId,
			@Parameter(description = "The application id") @NotNull @PathParam("applicationId") Long applicationId,
			@Parameter(description = "The form config id") @NotNull @QueryParam("formConfigId") Long formConfigId,
			@Parameter(description = "The compile status identifier") @QueryParam("compileStatusIdentifier") String compileStatusIdentifier,
			@Parameter(description = "The campaign year") @NotNull @PathParam("campaignYear") Integer campaignYear
	) {

		ApplicationDetailsPublicDTO applicationDetailsPublicDTO =
				applicationFacadeService.callForApplicationDetails(tenantId, applicationId, user, Locale.ITALIAN.getLanguage());

		Long businessId = applicationDetailsPublicDTO.getPartyId();

		// EXAMPLE: https://umbria-dev.fe.abacogroup.eu/crop-plan-api/master/public/v1/crop-plans/2/plans?cropPlanTypeCode=CROPPLAN
		RecordResponse<CropPlanResponse> cropPlans = cropPlanService.getCropPlans(user, tenantId, businessId, "CROPPLAN");

		List<DeclOnCropsDTO> res = new ArrayList<>();

		if (!cropPlans.getRecords().isEmpty()) {

			Integer cropPlanId = cropPlans.getRecords().get(0).getCropPlanId();

			// EXAMPLE: https://umbria-dev.fe.abacogroup.eu/crop-plan-api/master/public/v1/crop-plans/2/plans/11/versions
			RecordResponse<VersionResponse> versionCropPlans =
					cropPlanService.getVersionCropPlan(user, tenantId, businessId, cropPlanId, campaignYear);

			List<VersionResponse> versions = versionCropPlans != null ? versionCropPlans.getRecords() : Collections.emptyList();

			var version = new Value<String>();

			if (!versions.isEmpty()) {
				versions.sort((o1, o2) -> o1.getVersionReferenceDate().compareTo(o2.getVersionReferenceDate()));

				// get the last one version - will be something as: MjAyNC0xMS0yMVQxMDo0OToxOS4xODkxMDk
				version.set(versions.get(versions.size() - 1).getVersion());
			}

			// EXAMPLE: https://umbria-dev.fe.abacogroup.eu/crop-plan-api/master/public/v1/crop-plans/2/plans/11/plots?version=MjAyNC0xMS0yMVQxMDo0OToxOS4xODkxMDk&pointInTime=20231111&pointInTimeTo=20241011
			RecordResponse<PlotRecord> plotCropPlan =
					cropPlanService.plotCropPlan(user, tenantId, businessId, cropPlanId, version.get(), campaignYear);
			if (plotCropPlan == null || plotCropPlan.getCount() == 0 || plotCropPlan.getRecords().isEmpty()) {
				throw new PlotNotFoundRuntimeException("Unable to find any plot for Cuaa: " + applicationDetailsPublicDTO.getParty().getCuaa());
			}
			/**
			 With this buffer, will be done an aggregation based on [planId | declCode | landUseCode].
			 The "AreaSqr" Will be the sum of all "usedAreaSqr" (areaSqr / 100 * areaPerc) which are in relationship with  [domainZoneId | landUse]
			 Eg.:
			 [ planId 	| declCode	| 	landUseCode		]		-  [AreaSqr]
			 26		|	768		| 002-011-000-000-101  		-	  46421
			 27		|	825		| 065-002-009-000-000  		-     116
			 28		|	960		| 780-000-000-000-000  		-    1338
			 */
			DeclOnCropsBuffer buffer = new DeclOnCropsBuffer(applicationId, user.getUserId());

			List<PlotRecord> plotRecords = plotCropPlan.getRecords();

			List<String> landUseCodes = new ArrayList<>();
			plotRecords.forEach(rcd -> rcd.getDecls().forEach(dec -> landUseCodes.add(dec.getLanduse().getCode())));

			List<MaxToAddByCrop> maxToAddByCrops =
					bancheDatiService.getMaxToAddByCrop(user, tenantId, GenericUtility.removeDuplicates(landUseCodes));

			Map<String, MaxToAddByCrop> mapLandUseCodesMaxToAddByCrops = new HashMap<>();
			maxToAddByCrops.forEach(m -> mapLandUseCodesMaxToAddByCrops.put(m.getCropCode(), m));

			Value<MaxToAddByCrop> maxToAddByCrop = new Value<>();

			plotRecords.forEach(rcd -> {

				var flZvn = new Value<Boolean>(false);

				try {

					WKTReader reader = new WKTReader();
					Geometry geometry = reader.read(rcd.getGeom());
					String srs = rcd.getSrs();
					flZvn.set(cropPlanService.thereAreAnyIntersections(geometry, tenantId, srs));
				} catch (Exception e) {
					log.error(e.getMessage(), e);
				}

				rcd.getDecls().forEach(dec -> {

					String landUseCode = dec.getLanduse().getCode();
					String landUseDescription = dec.getLanduse().getDescription();
					String declCode = dec.getDeclCode();
					Long planId = Long.valueOf(cropPlanId);

					if (mapLandUseCodesMaxToAddByCrops.containsKey(landUseCode)) {

						maxToAddByCrop.set(mapLandUseCodesMaxToAddByCrops.get(landUseCode));

						Double nitrogenQt = maxToAddByCrop.get().getNitrogenQt();
						int mas = nitrogenQt == null ? 0 : maxToAddByCrop.get().getNitrogenQt().intValue();
						int totalNitrogen = 0; // distributableNum * rcd.getAreaSqm();

						DeclOnCropsBufferElement buffElem =
								buffer.newElementOrExisting(planId, declCode, landUseCode, mas);

						buffElem.setAreaSqm(rcd.getAreaSqm());
						buffElem.setSectorCode(rcd.getDomainZoneId());
						buffElem.setCropDuration(DeclOnCropsResources.calculateDuration(dec));
						buffElem.setFlZvn(flZvn.get());
						buffElem.setPlotCode(rcd.getPlotCode());
						buffElem.setPlotDescription(landUseDescription);
						buffElem.setTotalNitrogen(totalNitrogen);
						buffElem.setTotResidualNitrogen(BigDecimal.ZERO); // sum of all children fields "residual_number"
						buffElem.setVersion(version.get());
	/*
						buffElem.setCycle(null);// post inserted by front-end
						buffElem.setPrecessionCode(null); // post inserted by front-end
						buffElem.setTypology(null); // post inserted by front-end
						buffElem.setYield(0); // post inserted by front-end
	*/
						buffElem.setDistributableNitrogen(BigDecimal.ZERO);

						// TODO EC this part must be check
						Integer yealdReference = /*maxToAddByCrop.getYield() != null ?
								maxToAddByCrop.getYield().intValue() :*/ null;
						buffElem.setYieldReference(yealdReference);

						buffElem.setPlantStatus("");// TODO EC must understand how to retrieve this

						buffElem.addAreaSqr(rcd.getAreaSqm(), dec.getAreaPerc());

						log.info("Just added Declaration with declCode = {}, cropPlanId = {} and lanuseCode {} ",
								declCode, planId, landUseCode);
					} else {
						log.debug("Cannot add Declaration with declCode = {} and cropPlanId = {} because the "
								+ "lanuseCode {} was not retrieved by bancheDatiService.getMaxToAddByCrop ", declCode, planId, landUseCode);
					}

				});
			});

			// force deleting of existing elements (logical overwriting)
			declOnCropsService.deleteDeclOnCropsHierarchy(user, tenantId, applicationId, formConfigId, compileStatusIdentifier);

			List<DeclOnCropsDTO> allAsDeclOnCropsDTOs = buffer.getAllAsDeclOnCropsDTOs();

			if (!allAsDeclOnCropsDTOs.isEmpty()) {

				// insert in DB just imported elements 
				List<DeclOnCropsDTO> elementsInserted =
						declOnCropsService.insertMany(user, tenantId, applicationId, formConfigId, compileStatusIdentifier, allAsDeclOnCropsDTOs);

				res.addAll(elementsInserted);
			}
		}

		return Response.ok(res).build();
	}

	@PUT
	@Path("/{applicationId}/declarations-on-crop")
	public Response updateMassive(
			@Auth User user,
			@NotNull @RequestBody DeclOnCropsDTO payload,
			@Parameter(description = "Current Tenant") @NotNull @PathParam("tenant") String tenantId,
			@Parameter(description = "The application id") @NotNull @PathParam("applicationId") Long applicationId,
			@Parameter(description = "The form config id") @NotNull @QueryParam("formConfigId") Long formConfigId,
			@Parameter(description = "The compile status identifier") @QueryParam("compileStatusIdentifier") String compileStatusIdentifier

	) {

		List<DeclOnCropsDTO> result = new ArrayList<>();

		if (payload.getIds() != null && !payload.getIds().isEmpty()) {

			Boolean checkIfExistAutomaticRecord = declOnCropsService.checkIfExistAutomaticRecord(user, tenantId, applicationId);
			List<DeclOnCropsDTO> declOnCrops = declOnCropsService.getByIds(user, tenantId, applicationId, payload.getIds());

			if (declOnCrops != null && !declOnCrops.isEmpty()) {

				List<DeclOnCropsDTO> declOnCropsToUpd = new ArrayList<>();
				List<DeclOnCropsSubdata> declOnCropsSubDataElementsToUpd = new ArrayList<>();

				if (declOnCrops.size() > 1 &&
						declOnCrops.stream()
								.map(DeclOnCropsDTO::getLandUseCode)
								.distinct()
								.count() > 1) {
					throw new BadRequestException("All items must have the same landUseCode.");
				}

				declOnCrops.forEach(declOnCrop -> {

					handleValidationsForDeclOnCropsUpdate(user, tenantId, payload, declOnCrop.getLandUseCode(), true);

					//Calculate TotResidualNumber
					if (payload.getPreviousEffluents() != null && !payload.getPreviousEffluents().isEmpty()) {

						var totres = payload.getPreviousEffluents()
								.stream()
								.mapToDouble(x -> x.getResidualNitrogen().doubleValue())
								.sum();
						payload.setTotResidualNitrogen(BigDecimal.valueOf(totres));
					}
					
					
					//Calculate Fabbisogno

					if (!checkIfExistAutomaticRecord) {

						declOnCrop.setCycle(payload.getCycle());
						declOnCrop.setPrecessionCode(payload.getPrecessionCode());
						declOnCrop.setTypology(payload.getTypology());
						declOnCrop.setYield(payload.getYield());
						declOnCrop.setTotResidualNitrogen(payload.getTotResidualNitrogen());
						declOnCrop.setPreviousEffluents(payload.getPreviousEffluents());

						declOnCropsToUpd.add(declOnCrop);
					} else {

						FabbisognoResponseDati fabbisognoResponseDati = bancheDatiService.getFabbisognoResponseDati(user,
								tenantId,
								declOnCrop.getLandUseCode(),
								declOnCrop.getDeclCode(),
								payload.getTypology(),
								payload.getYield(),
								payload.getPrecessionCode(),
								payload.getTotResidualNitrogen());

						if (fabbisognoResponseDati != null && fabbisognoResponseDati.getListaFabbisogni() != null
								&& !fabbisognoResponseDati.getListaFabbisogni()
								.isEmpty()) {
							var sumOfDistribNitrogen = fabbisognoResponseDati.getListaFabbisogni().stream().mapToDouble(x -> x.getNFabbisogno()).sum();
							payload.setDistributableNitrogen(BigDecimal.valueOf( sumOfDistribNitrogen ));
						}

						if (payload.getDistributableNitrogen() != null && declOnCrop.getAreaSqm() != null) {
							//#TODO Check distributable insert if is negative number
							var distriNR = payload.getDistributableNitrogen().compareTo(BigDecimal.ZERO) >= 0 ? 
									payload.getDistributableNitrogen() : BigDecimal.ZERO;
							
							payload.setTotalNitrogen(distriNR.multiply(BigDecimal.valueOf(declOnCrop.getAreaSqm())));
						}

						// populate the bean with new subset of values to use for the update
						List<DeclOnCropsPrevEffluentsNTT> effluents = new ArrayList<>();
						if (payload.getPreviousEffluents() != null && !payload.getPreviousEffluents().isEmpty()) {
							DeclOnCropsPrevEffluentsMapper localMapper = new DeclOnCropsPrevEffluentsMapperImpl();
							for (DeclOnCropsPrevEffluentsDTO eff : payload.getPreviousEffluents()) {
								effluents.add(localMapper.dtoToEntity(eff));
							}
						}

						DeclOnCropsSubdata docsd = DeclOnCropsSubdata.builder()
								.cycle(payload.getCycle())
								.typology(payload.getTypology())
								.precessionCode(payload.getPrecessionCode())
								.yeld(payload.getYield())
								.distributableNum(payload.getDistributableNitrogen())
								.pkId(declOnCrop.getIds().get(0))
								.previousEffluents(effluents)
								.build();

						declOnCropsSubDataElementsToUpd.add(docsd);
					}
				});

				if (!checkIfExistAutomaticRecord) {

					List<Long> declOnCropIds = declOnCropsToUpd.stream()
							.map(declOnCrop -> declOnCrop.getIds().get(0))
							.collect(Collectors.toList());

					result.addAll(declOnCropsService.updateManyDeclarationsOnCrop(user, tenantId, applicationId, formConfigId,
							compileStatusIdentifier, declOnCropsToUpd, declOnCropIds));

				} else {

					result.addAll(declOnCropsService.updateManyDeclOnCropsSubdata(user, tenantId, applicationId,
							formConfigId, compileStatusIdentifier, declOnCropsSubDataElementsToUpd));
				}
			}
		}

		return Response.ok(result).build();
	}

	@PUT
	@Path("/{applicationId}/declaration-on-crop/{declaration_id}")
	public Response update(
			@Auth User user,
			@NotNull @RequestBody DeclOnCropsDTO payload,
			@Parameter(description = "Current Tenant") @NotNull @PathParam("tenant") String tenantId,
			@Parameter(description = "The application id") @NotNull @PathParam("applicationId") Long applicationId,
			@Parameter(description = "The form config id") @NotNull @QueryParam("formConfigId") Long formConfigId,
			@Parameter(description = "The compile status identifier") @QueryParam("compileStatusIdentifier") String compileStatusIdentifier,
			@Parameter(description = "The declatarion id") @NotNull @PathParam("declaration_id") Long declId
	) {

		DeclOnCropsDTO declOnCrops = declOnCropsService.get(user, tenantId, applicationId, declId);

		// *** Validations:
		handleValidationsForDeclOnCropsUpdate(user, tenantId, payload, declOnCrops.getLandUseCode(), false);

		//Calculate TotResidualNumber
		if (declOnCrops.getPreviousEffluents() != null && !declOnCrops.getPreviousEffluents().isEmpty()) {
			var totres = declOnCrops.getPreviousEffluents()
					.stream()
					.mapToDouble(x -> x.getResidualNitrogen().doubleValue())
					.sum();
			payload.setTotResidualNitrogen(BigDecimal.valueOf(totres));
		}

		//Calculate Fabbisogno
		DeclOnCropsDTO res;
		Boolean checkIfExistAutomaticRecord = declOnCropsService.checkIfExistAutomaticRecord(user, tenantId, applicationId);
		if (!checkIfExistAutomaticRecord) {
			payload.setUserIdInsert(declOnCrops.getUserIdInsert());
			payload.setDtInsert(declOnCrops.getDtInsert());
			payload.setDtDelete(CommonConstants.FAR_OFF_DATE);

			res = declOnCropsService.updateDeclarationOnCrop(user, tenantId, applicationId, formConfigId, compileStatusIdentifier, payload,
					declId);
		} else {
			FabbisognoResponseDati fabbisognoResponseDati = bancheDatiService.getFabbisognoResponseDati(user,
					tenantId,
					declOnCrops.getLandUseCode(),
					declOnCrops.getDeclCode(),
					payload.getTypology(),
					payload.getYield(),
					payload.getPrecessionCode(),
					payload.getTotResidualNitrogen());
			if (fabbisognoResponseDati != null && fabbisognoResponseDati.getListaFabbisogni() != null) {
				if (!fabbisognoResponseDati.getListaFabbisogni()
						.isEmpty()) {
					var distributableNitrogen = fabbisognoResponseDati.getListaFabbisogni().stream().mapToDouble(x -> x.getNFabbisogno()).sum();
					payload.setDistributableNitrogen(BigDecimal.valueOf(distributableNitrogen));
				}
			}
			if (payload.getDistributableNitrogen() != null && declOnCrops.getAreaSqm() != null) {
				//#TODO Check distributable insert if is negative number
				var distriNR = payload.getDistributableNitrogen().compareTo(BigDecimal.ZERO) >= 0 ? payload.getDistributableNitrogen() : BigDecimal.ZERO;
				payload.setTotalNitrogen(distriNR.multiply(BigDecimal.valueOf(declOnCrops.getAreaSqm())));
			}
			if (payload.getDistributableNitrogen() == null)
				payload.setDistributableNitrogen(declOnCrops.getDistributableNitrogen());
			res = declOnCropsService.update(user, tenantId, applicationId, formConfigId, compileStatusIdentifier,
					payload.getCycle(),
					payload.getTypology(),
					payload.getPrecessionCode(),
					payload.getYield(),
					payload.getDistributableNitrogen(),
					declId
			);
		}
		return Response.ok(res).build();
	}

	//DeclOnCrop APIS

	@POST
	@Path("/{applicationId}/declaration-on-crop")
	public Response insertDeclarationOnCrop(
			@Auth User user,
			@NotNull @RequestBody DeclOnCropsDTO payload,
			@Parameter(description = "Current Tenant") @NotNull @PathParam("tenant") String tenantId,
			@Parameter(description = "The application id") @NotNull @PathParam("applicationId") Long applicationId,
			@Parameter(description = "The form config id") @NotNull @QueryParam("formConfigId") Long formConfigId,
			@Parameter(description = "The compile status identifier") @QueryParam("compileStatusIdentifier") String compileStatusIdentifier
	) {
		long rightNow = Calendar.getInstance().getTimeInMillis();
		Instant instantRightNow = Instant.ofEpochMilli(rightNow);
		OffsetDateTime dateTimeRightNow = instantRightNow.atOffset(ZoneOffset.UTC);
		payload.setUserIdInsert(user.getUserId());
		payload.setDtInsert(dateTimeRightNow);
		payload.setDtDelete(CommonConstants.FAR_OFF_DATE);

		if (payload.getPlotDescription() == null && payload.getLandUseCode() != null) {
			LandUseCodesRequest req = new LandUseCodesRequest(Arrays.asList(payload.getLandUseCode()));
			var l = ipisGisService.getLandusesCodes(user, tenantId, req);
			payload.setPlotDescription(l.getLandUsesAsMap().get(payload.getLandUseCode()).getDescription());
		} else {
			payload.setPlotDescription("n/a");
		}

		DeclOnCropsDTO res = declOnCropsService.insertDeclarationOnCrop(user, tenantId, applicationId, formConfigId, compileStatusIdentifier, payload);
		return Response.ok(res).build();
	}

	@DELETE
	@Path("/{applicationId}/declaration-on-crop/{declaration_id}")
	public Response deleteDeclarationOnCrop(
			@Auth User user,
			@Parameter(description = "Current Tenant") @NotNull @PathParam("tenant") String tenantId,
			@Parameter(description = "The application id") @NotNull @PathParam("applicationId") Long applicationId,
			@Parameter(description = "The form config id") @NotNull @QueryParam("formConfigId") Long formConfigId,
			@Parameter(description = "The compile status identifier") @QueryParam("compileStatusIdentifier") String compileStatusIdentifier,
			@Parameter(description = "The declatarion id") @NotNull @PathParam("declaration_id") Long declId
	) {
		declOnCropsService.deleteDeclOnCropAndItsPrevEffluents(user, tenantId, applicationId, compileStatusIdentifier, formConfigId, declId);
		return Response.ok().build();
	}

	@DELETE
	@Path("/{applicationId}/declaration-on-crop")
	public Response deleteAll(
			@Auth User user,
			@Parameter(description = "Current Tenant") @NotNull @PathParam("tenant") String tenantId,
			@Parameter(description = "The application id") @NotNull @PathParam("applicationId") Long applicationId,
			@Parameter(description = "The form config id") @NotNull @QueryParam("formConfigId") Long formConfigId,
			@Parameter(description = "The compile status identifier") @QueryParam("compileStatusIdentifier") String compileStatusIdentifier
	) {
		declOnCropsService.deleteDeclOnCropsHierarchy(user, tenantId, applicationId, formConfigId, compileStatusIdentifier);
		return Response.ok().build();
	}
	// *** API for decl_on_crops_prev_effluents ***

	@POST
	@Path("/{applicationId}/declarations-on-crops-prev-effluent")
	public Response addDeclOnCropsEffluent(
			@Auth User user,
			@NotNull @RequestBody DeclOnCropsPrevEffluentsDTO payload,
			@Parameter(description = "Current Tenant") @NotNull @PathParam("tenant") String tenantId,
			@Parameter(description = "The application id") @NotNull @PathParam("applicationId") Long applicationId,
			@Parameter(description = "The form config id") @NotNull @QueryParam("formConfigId") Long formConfigId
	) {

		// validations:

		// let's validate Effluent
		EffluentFrequency effluentsFreq = bancheDatiService.getEffluentFrequency(user, tenantId, payload.getEffluent());
		if (null == effluentsFreq) {
			throw new ObjectNotFoundRuntimeException("Unable to find Effluent with code = " + payload.getEffluent());
		}

		// TODO there is something else to validate?
		// ...

		// validations OK, we can go on

		long rightNow = Calendar.getInstance().getTimeInMillis();
		Instant instantRightNow = Instant.ofEpochMilli(rightNow);
		OffsetDateTime dateTimeRightNow = instantRightNow.atOffset(ZoneOffset.UTC);
		payload.setUserIdInsert(user.getUserId());
		payload.setDtInsert(dateTimeRightNow);
		payload.setDtDelete(CommonConstants.FAR_OFF_DATE);
		payload.setId(0L);// temporary id

		DeclOnCropsPrevEffluentsDTO res = declOnCropsService.insertPreviousEffluents(user, tenantId, applicationId, formConfigId,
				/*compileStatusIdentifier,*/ payload);

		return Response.ok(res).build();
	}

	@PUT
	@Path("/{applicationId}/declarations-on-crops-prev-effluent/{id}")
	public Response updateDeclOnCropsEffluent(
			@Auth User user,
			@NotNull @RequestBody DeclOnCropsPrevEffluentsDTO payload,
			@Parameter(description = "Current Tenant") @NotNull @PathParam("tenant") String tenantId,
			@Parameter(description = "The application id") @NotNull @PathParam("applicationId") Long applicationId,
			@Parameter(description = "The form config id") @NotNull @QueryParam("formConfigId") Long formConfigId,
			@Parameter(description = "The declatation id") @NotNull @PathParam("id") Long declatationId
	) throws Exception {

		// validations:

		// let's validate Effluent
		EffluentFrequency effluentsFreq = bancheDatiService.getEffluentFrequency(user, tenantId, payload.getEffluent());
		if (null == effluentsFreq) {
			throw new ObjectNotFoundRuntimeException("Unable to find Effluent with code = " + payload.getEffluent());
		}

		// TODO there is something else to validate?
		// ...

		// validations OK, we can go on

		payload.setId(declatationId);
		payload.setUserIdInsert(user.getUserId());
		payload.setDtDelete(CommonConstants.FAR_OFF_DATE);

		DeclOnCropsPrevEffluentsDTO res = declOnCropsService.updateDeclOnCropsPrevEffluents(user, tenantId, applicationId,
				formConfigId/*, compileStatusIdentifier*/, payload);

		return Response.ok(res).build();
	}

	@DELETE
	@Path("/{applicationId}/declarations-on-crops-prev-effluent/{id}")
	public void deleteDeclOnCropsEffluent(
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "Current Tenant") @NotNull @PathParam("tenant") String tenantId,
			@Parameter(description = "The application id") @NotNull @PathParam("applicationId") Long applicationId,
			@Parameter(description = "The form config id") @NotNull @QueryParam("formConfigId") Long formConfigId,
			@Parameter(description = "The declatation id") @NotNull @PathParam("id") Long id) throws Exception {

		declOnCropsService.deleteDeclOnCropsPrevEffluentsById(user, tenantId, applicationId, formConfigId, id);
	}

	// TODO USE AS EXAMPLE (modify this, create an appropriate DTO, NTT, etc)
	@POST
	@Path("/{applicationId}/declarations-on-crops-livestock-consist")
	public Response addDeclOnCropsLivestockConsist(
			@Auth User user,
			@NotNull @RequestBody DeclOnCropLiveStocksDTO payload,
			@Parameter(description = "Current Tenant") @NotNull @PathParam("tenant") String tenantId,
			@Parameter(description = "The application id") @NotNull @PathParam("applicationId") Long applicationId,
			@Parameter(description = "The compile status identifier") @QueryParam("compileStatusIdentifier") String compileStatusIdentifier,
			@Parameter(description = "The form config id") @NotNull @QueryParam("formConfigId") Long formConfigId
	) throws ObjectNotFoundException {

		long rightNow = Calendar.getInstance().getTimeInMillis();
		Instant instantRightNow = Instant.ofEpochMilli(rightNow);
		OffsetDateTime dateTimeRightNow = instantRightNow.atOffset(ZoneOffset.UTC);
		payload.setUserIdInsert(user.getUserId());
		payload.setDtInsert(dateTimeRightNow);
		payload.setDtDelete(CommonConstants.FAR_OFF_DATE);
		//payload.setPkid(0L);// temporary id

		DeclOnCropLiveStocksDTO res = declOnCropsService.insertLivestockConsist(user, tenantId, applicationId, compileStatusIdentifier, formConfigId, payload);

		return Response.ok(res).build();
	}

	@PUT
	@Path("/{applicationId}/declarations-on-crops-livestock-consist/{id}")
	public Response update(
			@Auth User user,
			@NotNull @RequestBody DeclOnCropLiveStocksDTO payload,
			@Parameter(description = "Current Tenant") @NotNull @PathParam("tenant") String tenantId,
			@Parameter(description = "The application id") @NotNull @PathParam("applicationId") Long applicationId,
			@Parameter(description = "The form config id") @NotNull @QueryParam("formConfigId") Long formConfigId,
			@Parameter(description = "The compile status identifier") @QueryParam("compileStatusIdentifier") String compileStatusIdentifier,
			@Parameter(description = "The declatation id") @NotNull @PathParam("id") Long id
	) {

		payload.setId(id);
		payload.setApplicationId(applicationId);
		payload.setUserIdInsert(user.getUserId());
		payload.setDtDelete(CommonConstants.FAR_OFF_DATE);

		DeclOnCropLiveStocksDTO res = declOnCropsService.updateLiveStock(user, tenantId, applicationId, formConfigId, compileStatusIdentifier, payload);
		return Response.ok(res).build();
	}

	@DELETE
	@Path("/{applicationId}/declarations-on-crops-livestock-consist/{id}")
	public Response deleteDeclOnCropsLivestockConsist(
			@Auth User user,
			@Parameter(description = "Current Tenant") @NotNull @PathParam("tenant") String tenantId,
			@Parameter(description = "The application id") @NotNull @PathParam("applicationId") Long applicationId,
			@Parameter(description = "The compile status identifier") @QueryParam("compileStatusIdentifier") String compileStatusIdentifier,
			@Parameter(description = "The form config id") @NotNull @QueryParam("formConfigId") Long formConfigId,
			@Parameter(description = "Id of Live Stock") @NotNull @PathParam("id") Long id
	) throws ObjectNotFoundException {
		var res = declOnCropsService.deleteLiveStock(user, tenantId, applicationId, compileStatusIdentifier, formConfigId, id);
		return Response.ok(res).build();
	}

	@GET
	@Path("/{applicationId}/declarations-on-crops-livestock-consist")
	public Response getAllDeclOnCropsLivestockConsist(
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "Current Tenant") @NotNull @PathParam("tenant") String tenant,
			@Parameter(description = "The application id") @NotNull @PathParam("applicationId") Long applicationId,
			@Context HttpServletRequest request
	) {
		Map<String, String[]> requestParams = FilterHandler.convertRequestParametersToMap(request);
		InfiniteListResults<DeclOnCropLiveStocksDTO> dtos = null;

		try {
			dtos = declOnCropsService.searchDeclOnCropsLiveStocksByFilter(user, tenant, applicationId, requestParams,
					null /* nextKey TODO EC UNCOMMENT THIS TO RESTORE PAGINATION */);
			//			dtos = declOnCropsService.getAllDeclOnCropsLivestockConsist(user, tenant, applicationId);
		} catch (ObjectNotFoundRuntimeException e) {
			return Response.ok(Collections.emptyList()).build();
		}

		return Response.ok(dtos).build();
	}

	@GET
	@Path("/{applicationId}/cycle-types")
	public Response getAllCycles(@Parameter(hidden = true) @Auth User user) {

		List<Map<String, Object>> res = new ArrayList<>();
		Map<String, Object> cycleMap = null;
		for (Cycle cycle : Cycle.values()) {
			cycleMap = new HashMap<>();
			cycleMap.put("Ciclo_Cod", cycle.getCode());
			cycleMap.put("Ciclo_Des", cycle.getDescription());
			res.add(cycleMap);
		}
		return Response.ok(res).build();
	}
	
	@GET
	@Path("/{applicationId}/aggiorna-impianti-n-pua")
	public Response aggiornaImpiantiNPua(
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "Current Tenant") @NotNull @PathParam("tenant") String tenant,
			@Parameter(description = "The application id") @NotNull @PathParam("applicationId") Long applicationId) {

		try {

			GiasTokenResponse giasTokenResponse = giasService.authenticateWithGias();
			String token = giasTokenResponse.getRispostaStringa();

			ApplicationDetailsPublicDTO applicationDetailsPublicDTO = 
					applicationFacadeService.callForApplicationDetails(tenant, applicationId, user, 
							Locale.ITALIAN.getLanguage());

			var cuaa = applicationDetailsPublicDTO.getParty().getCuaa();

			List<Appezzamento> appezzamenti = new ArrayList<>();

			List<DeclOnCropsNTT> plots = 
					declOnCropsService.getDeclOnCropsWithoutPrevEffluentsByApplicationId(user, tenant, applicationId);

			plots.forEach(e -> appezzamenti.add(
					Appezzamento.builder()
					.chiaveAppezzamento(e.getDeclCode())
					.nPua(e.getDistributableNitrogen())
					.build()
					)
					);

			AggiornaImpiantiNPua aggiornaImpianti = AggiornaImpiantiNPua.builder()
					.cuaa(cuaa)
					.regolamentoCod(125)  // Set to 125 as required
					.elencoAppezzamenti(appezzamenti)
					.build();

			AgronicaResponse<Object> resp = giasService.importAggiornaImpiantiNPua(aggiornaImpianti, token);

			return Response.ok(resp).build();

		} 
		catch (AgronicaGenericException e) {
			log.error("Unabble to execute aggiornaImpiantiNPua ("+ e.getMessage()+")", e);
			throw e;
		} 
		catch (Exception e) {
			log.error("Unabble to execute aggiornaImpiantiNPua ("+ e.getMessage()+")", e);
			throw new RuntimeException(e);
		}
	}
	
	// *** private classes and methods ***

	private static synchronized String calculateDuration(Declaration dec) {
		String duration = null;

		try {
			if (YMD.equalsIgnoreCase(dec.getFromDatePrecision())) {

				Date from = DATE_FORMAT_FOR_YYYYMMDD.parse(dec.getFromDate());
				Date to = DATE_FORMAT_FOR_YYYYMMDD.parse(dec.getToDate());

				long daysDiff = ChronoUnit.DAYS.between(
						from.toInstant().atZone(ZoneId.systemDefault()).toLocalDate(),
						to.toInstant().atZone(ZoneId.systemDefault()).toLocalDate()
						);

				duration = String.valueOf(daysDiff);
			}
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			throw new RuntimeException(e);
		}

		return GenericUtility.getValueOrDefaultWhenIsNull(duration, "0");
	}

	/*
	 
	//Converters
	// Convert a comma-separated string to a List<Long> safely
	private static List<Long> convertToList(String input) {
		if (input == null || input.trim().isEmpty()) {
			return Collections.emptyList();
		}
		try {
			return Arrays.stream(input.split(","))
					.map(Long::parseLong)
					.collect(Collectors.toList());
		} catch (NumberFormatException e) {
			throw new BadRequestException("Invalid declaration ID format: " + input);
		}
	}

	// Safely get an element from a list by index
	private static Long getElementByIndex(List<Long> list, int index) {
		if (list == null || index < 0 || index >= list.size()) {
			return null;
		}
		return list.get(index);
	}

	private Map<String, Object> parseFilterString(String filterString) {
		Map<String, Object> filter = new HashMap<>();

		if (filterString != null) {
			filterString = filterString.trim();

			// Dividi la stringa per virgole
			String[] pairs = filterString.split(",");

			for (String pair : pairs) {

				// Dividi ogni coppia per i due punti
				String[] keyValue = pair.split(":");

				if (keyValue.length == 2) {
					String key = keyValue[0];
					String value = keyValue[1];
					filter.put(key, value);
				}
			}
		}

		return filter;
	}
	 */

	private void handleValidationsForDeclOnCropsUpdate(User user, String tenantId, DeclOnCropsDTO payload, String declOnCropLandUseCode, boolean isMassive) {

		// validate Precession (precessionCode)
		PrecedingCropType precedingCropType = null;

		if (null != payload.getPrecessionCode()) {
			precedingCropType = bancheDatiService.getPrecedingCropType(user, tenantId, payload.getPrecessionCode());
		}

		if (null == precedingCropType) {
			throw new InvalidParameterRuntimeException(
					isMassive ? ValidationError.MASSIVE_EDIT_PRECESSION_INVALID : ValidationError.PRECESSION_INVALID,
					"Unable to find any Precession code = " + payload.getPrecessionCode());
		}

		// validate Cycle
		if (!Cycle.validateCode(payload.getCycle())) {
			throw new InvalidParameterRuntimeException(
					isMassive ? ValidationError.MASSIVE_EDIT_CYCLE_INVALID : ValidationError.CYCLE_INVALID,
					"Unable to find cycle code = " + payload.getCycle());
		}

		// validate Yield
//		List<MaxToAddByCrop> maxToAddByCrop =
//				bancheDatiService.getMaxToAddByCrop(user, tenantId, Collections.singletonList(declOnCropLandUseCode));
//
//		if (null != maxToAddByCrop) {
//
//			MaxToAddByCrop maxToAddByCropElement = maxToAddByCrop.get(0);
//
//			if (maxToAddByCropElement.getYield() != null /*&& maxToAddByCropElement.getYield() > 0*/) {
//				if (maxToAddByCropElement.getYield() < payload.getYield()) {
//					throw new InvalidParameterRuntimeException(
//							isMassive ? ValidationError.MASSIVE_EDIT_YIELD_INVALID : ValidationError.YIELD_INVALID,
//							"The yield value (" + payload.getYield() + ") is too high ");
//				}
//			}
//		} else {
//			throw new ObjectNotFoundRuntimeException(
//					"Unable to find any MaxToAddByCrop code by landUseCode" + declOnCropLandUseCode);
//		}

		List<ProductType> productTypesByCrop =
				bancheDatiService.getProductTypesByCrop(user, tenantId,
						Collections.singletonList(declOnCropLandUseCode));

		if (null != productTypesByCrop) {

			// validate Typology
			ProductType productTypeFound =
					productTypesByCrop.stream().filter(f -> f.getProductTypeCode().equals(payload.getTypology())).findFirst().orElse(null);

			if (null == productTypeFound) {
				throw new InvalidParameterRuntimeException(
						isMassive ? ValidationError.MASSIVE_EDIT_PRODUCTTYPE_INVALID : ValidationError.PRODUCTTYPE_INVALID,
						"The productType value (" + payload.getTypology() + ") is not valid ");
			}
		} else {
			throw new ObjectNotFoundRuntimeException(
					"Unable to find any ProductType code by landUseCode" + declOnCropLandUseCode);
		}
	}

}
