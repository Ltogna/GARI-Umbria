package com.abacogroup.agri.applicationforms.pua.services;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.fail;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.List;

import org.glassfish.jersey.media.multipart.FormDataContentDisposition;
import org.jdbi.v3.core.Handle;
import org.jdbi.v3.core.HandleCallback;
import org.jdbi.v3.core.HandleConsumer;
import org.jdbi.v3.core.Jdbi;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.abacogroup.agri.applicationforms.pua.core.exceptions.AgriApplicationFormsRuntimeException;
import com.abacogroup.agri.applicationforms.pua.core.exceptions.AttachmentTypesNotFoundRuntimeException;
import com.abacogroup.agri.applicationforms.pua.core.exceptions.FileStoreIORuntimeException;
import com.abacogroup.agri.applicationforms.pua.core.model.dto.AttachmentDTO;
import com.abacogroup.agri.applicationforms.pua.core.model.dto.AttachmentPublicDTO;
import com.abacogroup.agri.applicationforms.pua.core.model.dto.AttachmentTypeDTO;
import com.abacogroup.agri.applicationforms.pua.core.model.dto.AttachmentTypePublicDTO;
import com.abacogroup.agri.applicationforms.pua.core.model.dto.CreateAttachmentInDTO;
import com.abacogroup.agri.applicationforms.pua.core.model.dto.SavedFileDTO;
import com.abacogroup.agri.applicationforms.pua.core.model.dto.UpdateAttachmentInDTO;
import com.abacogroup.agri.applicationforms.pua.services.common.ApplicationFacadeService;
import com.abacogroup.agri.applicationforms.pua.services.common.crud.AttachmentsCrudService;
import com.abacogroup.filestore.client.auth.Sso2Authenticator;
import com.abacogroup.jdbi.paging.impl.InfiniteListResultsImpl;

import jakarta.ws.rs.core.Response;

@ExtendWith(MockitoExtension.class)
class AttachmentsServiceTest extends AbstractServiceTest {

    @Mock
    private Jdbi jdbiMock;

    @Mock
    private Handle handle;

    @Mock
    private AttachmentsCrudService attachmentsCrudServiceMock;

    @Mock
    private AttachmentTypesCrudService attachmentTypesCrudServiceMock;

    @Mock
    private  FileStoreService fileStoreServiceMock;

    @Mock
    private FileCheckerService fileCheckerService;
    
    @Mock
	private ApplicationFacadeService applicationFacadeService;

    @InjectMocks
    private AttachmentsService attachmentsService;

    private static final Long ID = 1L;

    private final AttachmentTypePublicDTO type = AttachmentTypePublicDTO.builder()
            .id(ATTACHMENT_TYPE_ID)
            .code(CODE)
            .groupCode(GROUP_CODE)
            .typeCode(TYPE_CODE)
            .build();

    private final AttachmentPublicDTO attachmentPublicDTO = AttachmentPublicDTO.builder()
            .tenantId(TENANT)
            .applicationId(APPLICATION_ID)
            .attachmentId(ATTACHMENT_ID)
            .type(type)
            .fileName(FILE_NAME)
            .notes(NOTES)
            .typeId(TYPE_ID)
            .typeCode(TYPE_CODE)
            .typeAttachmentGroupCode(GROUP_CODE)
            .typeAttachmentCode(CODE)
            .build();

    private final AttachmentTypeDTO attachmentTypeDTO = AttachmentTypeDTO.builder()
            .pkid(ID)
            .attachmentGroupCode(GROUP_CODE)
            .tenantId(TENANT)
            .typeCode(TYPE_CODE)
            .code(CODE)
            .build();

    private final AttachmentDTO attachmentDTO = AttachmentDTO.builder()
            .pkid(ID)
            .applicationId(APPLICATION_ID)
            .attachmentId(ATTACHMENT_ID)
            .bucketId("")
            .build();

    private final AttachmentDTO attachmentDTO_create = AttachmentDTO.builder()
            .applicationId(APPLICATION_ID)
            .attachmentId(ATTACHMENT_ID)
            .bucketId(BUCKET)
            .type(TYPE_ID)
            .notes(NOTES)
            .fileName(FILE_NAME)
            .build();

    private final AttachmentDTO attachmentDTO_out = AttachmentDTO.builder()
            .pkid(ID)
            .applicationId(APPLICATION_ID)
            .attachmentId(ATTACHMENT_ID)
            .bucketId(BUCKET)
            .type(TYPE_ID)
            .notes(NOTES)
            .typeId(TYPE_ID)
            .fileName(FILE_NAME)
            .typeAttachmentCode(TYPE_ATTACHMENT_CODE)
            .typeAttachmentGroupCode(GROUP_CODE)
            .typeCode(TYPE_CODE)
            .tenantId(TENANT)
            .build();

    private final CreateAttachmentInDTO createAttachmentInDTO = CreateAttachmentInDTO.builder()
            .typeCode(TYPE_CODE)
            .groupCode(GROUP_CODE)
            .notes(NOTES)
            .build();

    private final SavedFileDTO savedFileDTO = SavedFileDTO.builder()
            .fileId(ATTACHMENT_ID)
            .build();


    @BeforeEach
    void init(){
        attachmentsService = new AttachmentsService(jdbiMock, attachmentTypesCrudServiceMock, attachmentsCrudServiceMock,
        		applicationFacadeService, fileStoreServiceMock, fileCheckerService, BUCKET);
    }

    @Test
    void getAttachments_ok(){
        AttachmentDTO attachmentDTO = new AttachmentDTO();
        attachmentDTO.setTypeAttachmentGroupCode(ATTACHMENT_GROUP);
        attachmentDTO.setAttachmentId(ATTACHMENT_ID);

        AttachmentPublicDTO publicDTO = AttachmentPublicDTO.builder()
                .typeAttachmentGroupCode(ATTACHMENT_GROUP)
                .attachmentId(ATTACHMENT_ID)
                .type(AttachmentTypePublicDTO.builder()
                        .groupCode(ATTACHMENT_GROUP)
                        .build())
                .build();

        when(attachmentsCrudServiceMock.findByApplicationIdAndAttachmentGroup(TENANT, APPLICATION_ID, ATTACHMENT_GROUP, null))
                .thenReturn(new InfiniteListResultsImpl<>(List.of(attachmentDTO), null));

        assertEquals(attachmentsService.getAttachments(TENANT, APPLICATION_ID, ATTACHMENT_GROUP, null).getRecords(), List.of(publicDTO));

    }

    @Test
    void getAttachmentsTypes_ok(){
        AttachmentDTO attachmentDTO = new AttachmentDTO();
        attachmentDTO.setTypeAttachmentGroupCode(ATTACHMENT_GROUP);
        attachmentDTO.setAttachmentId(ATTACHMENT_ID);

        AttachmentTypePublicDTO publicDTO = AttachmentTypePublicDTO.builder()
                .id(ID)
                .groupCode(GROUP_CODE)
                .code(CODE)
                .typeCode(TYPE_CODE)
                .build();

        when(attachmentTypesCrudServiceMock.findByTenantAttachmentGroup(TENANT, ATTACHMENT_GROUP, null))
                .thenReturn(new InfiniteListResultsImpl<>(List.of(attachmentTypeDTO), null));

        assertEquals(attachmentsService.getAttachmentTypes(TENANT, ATTACHMENT_GROUP, null).getRecords(), List.of(publicDTO));

    }

    @Test
    void getAttachmentsTypes_ko(){
        AttachmentDTO attachmentDTO = new AttachmentDTO();
        attachmentDTO.setTypeAttachmentGroupCode(ATTACHMENT_GROUP);
        attachmentDTO.setAttachmentId(ATTACHMENT_ID);

        when(attachmentTypesCrudServiceMock.findByTenantAttachmentGroup(TENANT, ATTACHMENT_GROUP, null))
                .thenReturn(new InfiniteListResultsImpl<>(List.of(), null));

        assertThrows(AttachmentTypesNotFoundRuntimeException.class, () -> attachmentsService.getAttachmentTypes(TENANT, ATTACHMENT_GROUP, null ));

    }

    @SuppressWarnings({"rawtypes", "unchecked"})
    @Test
    void doCreateAttachment_ok(){

        try {
            ArgumentCaptor<HandleCallback> handleCallbackLambdaCaptor = ArgumentCaptor.forClass(HandleCallback.class);

            when(attachmentTypesCrudServiceMock.findByCodeAndAttachmentGroupCode(TENANT, TYPE_CODE, GROUP_CODE)).thenReturn(attachmentTypeDTO);

            doReturn(savedFileDTO).when(fileStoreServiceMock).saveFile(eq(TENANT), eq(BUCKET), eq(null), eq(FILE_NAME), eq(LOGGED_USER), any());

            when(attachmentsCrudServiceMock.insert(attachmentDTO_create, LOGGED_USER.getName())).thenReturn(attachmentDTO_out);

            attachmentsService.createAttachment(TENANT, APPLICATION_ID, createAttachmentInDTO, LOGGED_USER, FORM_CONFIG_ID, 
            		COMPILE_STATUS_IDENTIFIER,
                    null, FormDataContentDisposition.name("name").fileName(FILE_NAME).build());

            verify(jdbiMock).inTransaction(handleCallbackLambdaCaptor.capture());

            AttachmentPublicDTO result = (AttachmentPublicDTO) handleCallbackLambdaCaptor.getValue().withHandle(handle);

            assertEquals(result ,attachmentPublicDTO);

        } catch (Exception e){
            fail(e.getMessage(), e);
        }
    }


    @Test
    void updateAttachment_ok(){
        UpdateAttachmentInDTO updateAttachmentInDTO = UpdateAttachmentInDTO.builder()
                .groupCode(GROUP_CODE)
                .typeCode(TYPE_CODE)
                .notes(NOTES)
                .build();

        AttachmentDTO dto = AttachmentDTO.builder()
                .pkid(ID)
                .bucketId("")
                .applicationId(APPLICATION_ID)
                .attachmentId(ATTACHMENT_ID)
                .type(TYPE_ID)
                .typeAttachmentCode(TYPE_ATTACHMENT_CODE)
                .typeAttachmentGroupCode(GROUP_CODE)
                .typeCode(TYPE_CODE)
                .fileName(FILE_NAME)
                .typeId(TYPE_ID)
                .tenantId(TENANT)
                .build();

        when(attachmentsCrudServiceMock.findByAttachmentId(TENANT, APPLICATION_ID, ATTACHMENT_ID)).thenReturn(attachmentDTO);

        when(attachmentTypesCrudServiceMock.findByCodeAndAttachmentGroupCode(TENANT, TYPE_CODE, GROUP_CODE)).thenReturn(attachmentTypeDTO);

        when(attachmentsCrudServiceMock.findByAttachmentId(TENANT, APPLICATION_ID, ATTACHMENT_ID)).thenReturn(dto);

        AttachmentPublicDTO result = attachmentsService.updateAttachment(TENANT, APPLICATION_ID, ATTACHMENT_ID, FORM_CONFIG_ID, 
        		COMPILE_STATUS_IDENTIFIER, updateAttachmentInDTO, LOGGED_USER);

        assertEquals(attachmentPublicDTO, result);
    }

//    @Test
//    void updateAttachment_ko(){
//        UpdateAttachmentInDTO updateAttachmentInDTO = UpdateAttachmentInDTO.builder()
//                .groupCode(GROUP_CODE)
//                .typeCode(TYPE_CODE)
//                .notes(NOTES)
//                .build();
//
//        assertThrows(BadRequestRuntimeException.class, () -> attachmentsService.updateAttachment(TENANT, APPLICATION_ID, ATTACHMENT_ID, updateAttachmentInDTO, null));
//    }

    @Test
    void getAttachmentList_ok(){

        AttachmentDTO attachmentDTO1 = new AttachmentDTO();
        attachmentDTO1.setTenantId(TENANT);
        attachmentDTO1.setApplicationId(APPLICATION_ID);
        attachmentDTO1.setAttachmentId(ATTACHMENT_ID);
        attachmentDTO1.setType(ATTACHMENT_TYPE_ID);
        attachmentDTO1.setFileName(FILE_NAME);
        attachmentDTO1.setNotes(NOTES);
        attachmentDTO1.setTypeId(TYPE_ID);
        attachmentDTO1.setTypeCode(TYPE_CODE);
        attachmentDTO1.setTypeAttachmentGroupCode(GROUP_CODE);
        attachmentDTO1.setTypeAttachmentCode(TYPE_ATTACHMENT_CODE);

        List<AttachmentDTO> attachmentDTOS = List.of(attachmentDTO1);

        List<AttachmentPublicDTO> expectedOutput = List.of(attachmentPublicDTO);

        when(attachmentsCrudServiceMock.findListByApplicationIdAndAttachmentGroup(TENANT, APPLICATION_ID, ATTACHMENT_GROUP))
                .thenReturn(attachmentDTOS);

        List<AttachmentPublicDTO> result = attachmentsService.getAttachmentList(TENANT, APPLICATION_ID, ATTACHMENT_GROUP);

        assertEquals(expectedOutput, result);
    }

    @Test
    void getAttachmentTypesFullList_ok(){

        List<AttachmentTypePublicDTO> expectedOutput = List.of(type);

        List<AttachmentTypeDTO> attachmentTypeDTOS = List.of(attachmentTypeDTO);

        when(attachmentTypesCrudServiceMock.findByTenantAttachmentGroupFullList(TENANT, ATTACHMENT_GROUP)).thenReturn(attachmentTypeDTOS);

        List<AttachmentTypePublicDTO> result = attachmentsService.getAttachmentTypesFullList(TENANT, ATTACHMENT_GROUP);

        assertEquals(expectedOutput, result);

    }

    @Test
    void getAttachment_ok(){
        when(attachmentsCrudServiceMock.findByAttachmentId(TENANT, APPLICATION_ID, ATTACHMENT_ID)).thenReturn(attachmentDTO);

        Response expectedOutput = Response.noContent().build();

        when(fileStoreServiceMock.getFileForDownload(anyString(), anyString(), anyString(), any(), any())).thenReturn(expectedOutput);

        Response result = attachmentsService.getAttachment(TENANT, USER, APPLICATION_ID, ATTACHMENT_ID);

        assertEquals(expectedOutput, result);
    }

    @Test
    void doCallFileStoreForDownload_ok() {
        Response expectedOutput = Response.ok().build();

        when(fileStoreServiceMock.getFileForDownload(eq(TENANT), eq(ATTACHMENT_ID), eq(BUCKET), eq(USER), any(Sso2Authenticator.class)))
                .thenReturn(expectedOutput);

        Response result = attachmentsService.doCallFileStoreForDownload(TENANT, USER, BUCKET, ATTACHMENT_ID);

        assertEquals(expectedOutput, result);
    }

    @Test
    void doCallFileStoreForDownload_ko(){
        when(fileStoreServiceMock.getFileForDownload(eq(TENANT), eq(ATTACHMENT_ID), eq(BUCKET), eq(USER), any(Sso2Authenticator.class)))
                .thenThrow(FileStoreIORuntimeException.class);

        assertThrows(AgriApplicationFormsRuntimeException.class, () -> attachmentsService.doCallFileStoreForDownload(TENANT, USER, BUCKET, ATTACHMENT_ID));
    }

    @Test
    void doCallFileStoreForHead_ok() {
        Response expectedOutput = Response.ok().build();

        when(fileStoreServiceMock.getFileForHead(eq(TENANT), eq(ATTACHMENT_ID), eq(BUCKET), eq(USER), any(Sso2Authenticator.class)))
                .thenReturn(expectedOutput);

        Response result = attachmentsService.doCallFileStoreForHead(TENANT, USER, BUCKET, ATTACHMENT_ID);

        assertEquals(expectedOutput, result);
    }

    @Test
    void doCallFileStoreForHead_ko() {
        when(fileStoreServiceMock.getFileForHead(eq(TENANT), eq(ATTACHMENT_ID), eq(BUCKET), eq(USER), any(Sso2Authenticator.class)))
                .thenThrow(FileStoreIORuntimeException.class);

        assertThrows(AgriApplicationFormsRuntimeException.class, () -> attachmentsService.doCallFileStoreForHead(TENANT, USER, BUCKET, ATTACHMENT_ID));
    }

    @Test
    void getAttachmentById_ok(){

        AttachmentPublicDTO expectedOutput = AttachmentPublicDTO.builder()
                        .attachmentId(ATTACHMENT_ID)
                        .applicationId(APPLICATION_ID)
                        .attachmentId(ATTACHMENT_ID).build();

        when(attachmentsCrudServiceMock.findByAttachmentId(TENANT, APPLICATION_ID, ATTACHMENT_ID)).thenReturn(attachmentDTO);

        AttachmentPublicDTO result = attachmentsService.getAttachmentById(TENANT, USER, APPLICATION_ID, ATTACHMENT_ID);

        assertEquals(expectedOutput, result);

    }

    @SuppressWarnings({"rawtypes", "unchecked"})
    @Test
    void doDeleteAttachment_ok(){

        try {
            ArgumentCaptor<HandleConsumer> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(HandleConsumer.class);

            when(attachmentsCrudServiceMock.findByAttachmentId(TENANT, APPLICATION_ID, ATTACHMENT_ID)).thenReturn(attachmentDTO);
            
//            AttachmentDTO attachmentDescriptor = attachmentsCrudService.findByAttachmentId(tenant, applicationId, attachmentId);
            
            attachmentsService.deleteAttachment(TENANT, LOGGED_USER, FORM_CONFIG_ID, COMPILE_STATUS_IDENTIFIER, 
            		APPLICATION_ID, ATTACHMENT_ID);

            verify(jdbiMock).useTransaction(handleConsumerLambdaCaptor.capture());
            handleConsumerLambdaCaptor.getValue().useHandle(handle);

            verify(attachmentsCrudServiceMock).delete(attachmentDTO.getPkid(), LOGGED_USER.getName());

            verify(fileStoreServiceMock).deleteFile(eq(TENANT), eq(ATTACHMENT_ID), eq(""), eq(LOGGED_USER));
        } catch (Exception e){
            fail(e.getMessage(), e);
        }

    }

}
