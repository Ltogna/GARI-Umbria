package com.abacogroup.agri.applicationforms.pua.services;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Collections;
import java.util.List;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.abacogroup.agri.applicationforms.pua.core.mappers.EffluentMapper;
import com.abacogroup.agri.applicationforms.pua.core.model.dto.EffluentDTO;
import com.abacogroup.agri.applicationforms.pua.db.dao.EffluentDAO;
import com.abacogroup.agri.applicationforms.pua.db.ntt.EffluentNTT;
import com.abacogroup.agri.applicationforms.pua.services.common.ApplicationFacadeService;
import com.abacogroup.applicationworkflowsdk.model.io.output.ApplicationDetailsPublicDTO;

/**
 * 
 * @author Emanuele Crocilla
 *
 */
@ExtendWith(MockitoExtension.class)
class EffluentServiceTest extends AbstractServiceTest {

	@Mock
    private EffluentDAO effluentDAO;

    @Mock
    private EffluentMapper mapper;
    
    @Mock
	private ApplicationFacadeService applicationFacadeService;
    
    @InjectMocks
    private EffluentCrudService effluentService;
    
    private static EffluentDTO in, modified, dbInserted;
    private static EffluentNTT dbFetched;
    
    @BeforeAll
    public static void init() {
    	
    	in = EffluentDTO.builder()
    			.categoryCode(CATEGORY_CODE)
                .fertilizerCategory(FERTILIZER_CATEGORY)
                .fertilizerType(FERTILIZER_TYPE)
                .typeCode(TYPE_CODE)
                .build();

        dbFetched = EffluentNTT.builder()
                .pkId(PKID)
                .categoryCode(CATEGORY_CODE)
                .fertilizerCategory(FERTILIZER_CATEGORY)
                .fertilizerType(FERTILIZER_TYPE)
                .typeCode(TYPE_CODE)
                .userIdInsert(LOGGED_USER_ID)
                .build();
        
        modified = EffluentDTO.builder()
                .categoryCode(CATEGORY_CODE)
                .fertilizerCategory(FERTILIZER_CATEGORY)
                .fertilizerType(FERTILIZER_TYPE)
                .typeCode(TYPE_CODE)
                .build();
        
        dbInserted = EffluentDTO.builder()
                .categoryCode(CATEGORY_CODE)
                .fertilizerCategory(FERTILIZER_CATEGORY)
                .fertilizerType(FERTILIZER_TYPE)
                .typeCode(TYPE_CODE)
                .build();
         
    }

    // Test: Insert
    @Test
    void testInsertSuccess() {

        when(effluentDAO.getByTypeCode(TYPE_CODE)).thenReturn(dbFetched);
        
        when(mapper.entityToDto(dbFetched)).thenReturn(modified);
 
        EffluentDTO res =  effluentService.insert(USERNAME, TENANT, in);
        
        assertNotNull(res);
        assertEquals(CATEGORY_CODE, res.getCategoryCode());
        assertEquals(FERTILIZER_CATEGORY, res.getFertilizerCategory());
        assertEquals(FERTILIZER_TYPE, res.getFertilizerType());
        assertEquals(TYPE_CODE, res.getTypeCode());
    }
    
    @Test
    void testUpdateSuccess() {

    	when(effluentDAO.getByTypeCode(TYPE_CODE)).thenReturn(dbFetched);
    	
        when(mapper.entityToDto(dbFetched)).thenReturn(modified);
        
        EffluentDTO res =  effluentService.update(USERNAME, TENANT, in);
        
        assertNotNull(res);
        assertEquals(CATEGORY_CODE, res.getCategoryCode());
        assertEquals(FERTILIZER_CATEGORY, res.getFertilizerCategory());
        assertEquals(FERTILIZER_TYPE, res.getFertilizerType());
        assertEquals(TYPE_CODE, res.getTypeCode());
    }

    // Test: Delete
    @Test
    void testDeleteSuccess() {

        when(effluentDAO.getByTypeCode(TYPE_CODE)).thenReturn(dbFetched);
         
        boolean result = effluentService.delete(USERNAME, TENANT, TYPE_CODE);
        
        assertTrue(result);
//        ArgumentCaptor<Long> idCaptor = ArgumentCaptor.forClass(Long.class);
//        ArgumentCaptor<Long> captor = ArgumentCaptor.forClass(Long.class);
        verify(effluentDAO).expire(dbFetched);
//        assertEquals(TYPE_CODE, captor.getValue());
    }

    @Test
    void testDeleteFailsWhenNotFound() {
        
    	when(effluentDAO.getByTypeCode(TYPE_CODE)).thenReturn(null);
        
        boolean result = effluentService.delete(USERNAME, TENANT, TYPE_CODE);
        
        assertFalse(result);
        verify(effluentDAO, never()).expire(dbFetched);
    }

    @Test
    void testGetSuccess() {
        

    	when(effluentDAO.getByTypeCode(TYPE_CODE)).thenReturn(dbFetched);
        when(mapper.entityToDto(dbFetched)).thenReturn(dbInserted);
        
        ApplicationDetailsPublicDTO mockApplicationDetailsPublicDTO = ApplicationDetailsPublicDTO.builder()
        		.build();
        
        when(applicationFacadeService.callForApplicationDetails(TENANT, APPLICATION_ID, LOGGED_USER, LANGUAGE))
    	.thenReturn(mockApplicationDetailsPublicDTO);
        
        EffluentDTO result = effluentService.get(LOGGED_USER, TENANT, APPLICATION_ID, TYPE_CODE);
        
        assertNotNull(result);
        assertEquals(dbInserted, result);
        verify(mapper).entityToDto(dbFetched);
    }

    // Test: Get All
    @Test
    void testGetAllSuccess() {
    	
    	
    	when(effluentDAO.getAll()).thenReturn(Collections.singletonList(dbFetched));
    	when(mapper.entityToDto(dbFetched)).thenReturn(dbInserted);
    	
    	ApplicationDetailsPublicDTO mockApplicationDetailsPublicDTO = ApplicationDetailsPublicDTO.builder()
        		.build();
        
        when(applicationFacadeService.callForApplicationDetails(TENANT, APPLICATION_ID, LOGGED_USER, LANGUAGE))
    	.thenReturn(mockApplicationDetailsPublicDTO);
    	
    	List<EffluentDTO> results = effluentService.getAll(LOGGED_USER, TENANT, APPLICATION_ID);
    	
    	assertNotNull(results);
    	assertEquals(dbInserted, results.get(0));
    	verify(mapper).entityToDto(dbFetched);
    }

}
