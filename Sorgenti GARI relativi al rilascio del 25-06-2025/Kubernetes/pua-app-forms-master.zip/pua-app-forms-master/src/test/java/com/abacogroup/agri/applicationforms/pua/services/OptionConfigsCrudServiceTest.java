package com.abacogroup.agri.applicationforms.pua.services;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.fail;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.List;
import java.util.Locale;
import java.util.Optional;

import org.apache.commons.lang3.NotImplementedException;
import org.jdbi.v3.sqlobject.transaction.TransactionalCallback;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.abacogroup.agri.applicationforms.pua.core.exceptions.ObjectNotFoundRuntimeException;
import com.abacogroup.agri.applicationforms.pua.core.mappers.OptionConfigsMapper;
import com.abacogroup.agri.applicationforms.pua.core.model.AbsoluteDate;
import com.abacogroup.agri.applicationforms.pua.core.model.dto.OptionConfigsDTO;
import com.abacogroup.agri.applicationforms.pua.db.dao.I18NDAO;
import com.abacogroup.agri.applicationforms.pua.db.dao.OptionConfigsDAO;
import com.abacogroup.agri.applicationforms.pua.db.ntt.OptionConfigsNTT;
import com.abacogroup.agri.applicationforms.pua.db.ntt.applications.RsI18N;
import com.abacogroup.agri.applicationforms.pua.services.common.I18NService;

import lombok.extern.slf4j.Slf4j;
 
@Slf4j
@ExtendWith(MockitoExtension.class)
class OptionConfigsCrudServiceTest extends AbstractServiceTest {

    @Mock
	private OptionConfigsDAO optionConfigsDAO;
    
    @Mock
    private OptionConfigsMapper optionConfigsMapper;
    
    @Mock
    private I18NService i18NServiceMock;

    @Mock
    private I18NDAO i18NDAO;
    
    @InjectMocks
    private OptionConfigsCrudService optionConfigsCrudService;

    private static final String I18N_OPTION_CONFIGS_TABLE = "appfpua_option_configs";

    private final OptionConfigsNTT optionConfigsNTT = OptionConfigsNTT.builder()
            .id(ID_1)
            .option_id(OPERATION_ID)
            .option_minimum_value(OPTION_MINIMUM_VALUE)
            .option_row_minimum_engageable_value(OPTION_ROW_MINIMUM_ENGAGEABLE_VALUE)
            .fl_full_engagement(FL_FULL_ENGAGEMENT)
            .dt_validity_start(DT_VALIDITY_START)
            .dt_validity_end(DT_VALIDITY_END)
            .build();

    private final OptionConfigsDTO optionConfigsDTO = OptionConfigsDTO.builder()
            .id(ID_1)
            .optionId(OPERATION_ID)
            .optionMinimumValue(OPTION_MINIMUM_VALUE)
            .optionRowMinimumEngageableValue(OPTION_ROW_MINIMUM_ENGAGEABLE_VALUE)
            .flFullEngagement(FL_FULL_ENGAGEMENT)
            .dtValidityStart(new AbsoluteDate(DT_VALIDITY_START))
            .dtValidityEnd(new AbsoluteDate(DT_VALIDITY_END))
            .build();

    @Test
    void findById_ok() {
        when(optionConfigsDAO.findById(ID_1))
                .thenReturn(List.of(optionConfigsNTT));

        when(optionConfigsMapper.entityToDto(optionConfigsNTT))
                .thenReturn(optionConfigsDTO);

        OptionConfigsDTO result  = optionConfigsCrudService.findById(ID_1);

        assertEquals(optionConfigsDTO, result);
    }

    @Test
    void findOptById_ok() {
        when(optionConfigsDAO.findById(ID_1))
                .thenReturn(List.of(optionConfigsNTT));

        when(optionConfigsMapper.entityToDto(optionConfigsNTT))
                .thenReturn(optionConfigsDTO);

        Optional<OptionConfigsDTO> result = optionConfigsCrudService.findOptById(ID_1);

        assertEquals(Optional.of(optionConfigsDTO), result);
    }

    @Test
    void findByTenant_ok() {
        when(optionConfigsDAO.findByTenant(TENANT))
                .thenReturn(List.of(optionConfigsNTT));

        when(optionConfigsMapper.entityToDto(optionConfigsNTT))
                .thenReturn(optionConfigsDTO);

        OptionConfigsDTO result = optionConfigsCrudService.findByTenant(TENANT).get(0);

        assertEquals(optionConfigsDTO, result);
    }

    @Test
    void findByApplicationId_ok() {
        when(optionConfigsDAO.findByApplicationIdOptionIdAndDtValidityEnd(TENANT, APPLICATION_ID, OPERATION_ID, new AbsoluteDate(DT_VALIDITY_START)))
                .thenReturn(List.of(optionConfigsNTT));

        when(optionConfigsMapper.entityToDto(optionConfigsNTT))
                .thenReturn(optionConfigsDTO);

        OptionConfigsDTO result;
        result = optionConfigsCrudService.findByOptionId(TENANT, APPLICATION_ID, OPERATION_ID, new AbsoluteDate(DT_VALIDITY_START));

        assertEquals(optionConfigsDTO, result);
    }

    @Test
    void findByFormCodeAndOperationCodeAndDtValidityEnd_ok() {
        when(optionConfigsDAO.findByOptionCodeAndDtValidityEnd(TENANT, OPTION_CODE, new AbsoluteDate(DT_VALIDITY_END)))
                .thenReturn(List.of(optionConfigsNTT));
        when(optionConfigsMapper.entityToDto(optionConfigsNTT))
                .thenReturn(optionConfigsDTO);

        OptionConfigsDTO result =
                optionConfigsCrudService.findByOptionCodeAndDtValidityEnd(TENANT, OPTION_CODE, new AbsoluteDate(DT_VALIDITY_END));

        assertEquals(optionConfigsDTO, result);
    }

    @Test
    @Deprecated
    void findByOperationCode_ok() {
        when(optionConfigsDAO.findByOptionCode(TENANT, OPTION_CODE))
                .thenReturn(List.of(optionConfigsNTT));
        when(optionConfigsMapper.entityToDto(optionConfigsNTT))
                .thenReturn(optionConfigsDTO);

        OptionConfigsDTO result = optionConfigsCrudService.findByOptionCode(TENANT, OPTION_CODE);

        assertEquals(optionConfigsDTO, result);
    }

    @Test
    void findByOperationCodesAndDtValidityEnd_ok() {
        when(optionConfigsDAO.findByOptionCodesAndDtValidityEnd(TENANT, List.of(OPTION_CODE), new AbsoluteDate(DT_VALIDITY_END)))
                .thenReturn(List.of(optionConfigsNTT));
        when(optionConfigsMapper.entityToDto(optionConfigsNTT))
                .thenReturn(optionConfigsDTO);

        List<OptionConfigsDTO> result =
                optionConfigsCrudService.findByOptionCodesAndDtValidityEnd(TENANT, List.of(OPTION_CODE), new AbsoluteDate(DT_VALIDITY_END));

        assertEquals(List.of(optionConfigsDTO), result);
    }

    @Test
    void findByOptionCodesAndDtValidityEnd_emptyList_ok() {
        assertEquals(List.of(), optionConfigsCrudService.findByOptionCodesAndDtValidityEnd(TENANT, null, new AbsoluteDate(DT_VALIDITY_END)));
        assertEquals(List.of(), optionConfigsCrudService.findByOptionCodesAndDtValidityEnd(TENANT, List.of(), new AbsoluteDate(DT_VALIDITY_END)));
    }

    @Test
    void findAllByOperationId_ok() {
        when(optionConfigsDAO.findAllByOptionId(OPERATION_ID))
                .thenReturn(List.of(optionConfigsNTT));
        when(optionConfigsMapper.entityToDto(optionConfigsNTT))
                .thenReturn(optionConfigsDTO);

        List<OptionConfigsDTO> result = optionConfigsCrudService.findAllByOptionId(OPERATION_ID);

        assertEquals(List.of(optionConfigsDTO), result);
    }

    @Test
    void findOptByOperationCodeAndDtValidityEnd_ok() {
        when(optionConfigsDAO.findByOptionCodeAndDtValidityEnd(TENANT, OPTION_CODE, new AbsoluteDate(DT_VALIDITY_END)))
                .thenReturn(List.of(optionConfigsNTT));
        when(optionConfigsMapper.entityToDto(optionConfigsNTT))
                .thenReturn(optionConfigsDTO);

        Optional<OptionConfigsDTO> result =
                optionConfigsCrudService.findOptByOptionCodeAndDtValidityEnd(TENANT, OPTION_CODE, new AbsoluteDate(DT_VALIDITY_END));

        assertEquals(Optional.of(optionConfigsDTO), result);
    }

    @SuppressWarnings({"rawtypes", "unchecked"})
    @Test
    void insert_ok() {
        OptionConfigsDTO in = OptionConfigsDTO.builder()
                .optionId(OPERATION_ID)
                .optionMinimumValue(OPTION_MINIMUM_VALUE)
                .optionRowMinimumEngageableValue(OPTION_ROW_MINIMUM_ENGAGEABLE_VALUE)
                .flFullEngagement(FL_FULL_ENGAGEMENT)
                .dtValidityStart(new AbsoluteDate(DT_VALIDITY_START))
                .dtValidityEnd(new AbsoluteDate(DT_VALIDITY_END))
                .build();
        try {
            ArgumentCaptor<TransactionalCallback> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(TransactionalCallback.class);

            when(optionConfigsDAO.findById(any()))
                    .thenReturn(List.of(optionConfigsNTT));
            when(optionConfigsMapper.dtoToEntity(in))
                    .thenReturn(optionConfigsNTT);
            when(optionConfigsMapper.entityToDto(optionConfigsNTT))
                    .thenReturn(optionConfigsDTO);

            optionConfigsCrudService.insert(in);

            verify(optionConfigsDAO).inTransaction(handleConsumerLambdaCaptor.capture());

            OptionConfigsDTO result = (OptionConfigsDTO) handleConsumerLambdaCaptor.getValue().inTransaction(optionConfigsDAO);

            assertEquals(optionConfigsDTO, result);
        } catch (Exception e) {
            fail(e.getMessage(), e);
        }
    }

    @SuppressWarnings({"unchecked", "rawtypes"})
    @Test
    void test_update() {
        try {
            ArgumentCaptor<TransactionalCallback> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(TransactionalCallback.class);

            when(optionConfigsDAO.findById(ID_1)).thenReturn(List.of(optionConfigsNTT));
            when(optionConfigsMapper.dtoToEntity(optionConfigsDTO))
                    .thenReturn(optionConfigsNTT);
            when(optionConfigsMapper.entityToDto(optionConfigsNTT))
                    .thenReturn(optionConfigsDTO);

            optionConfigsCrudService.update(ID_1, optionConfigsDTO);

            verify(optionConfigsDAO).inTransaction(handleConsumerLambdaCaptor.capture());

            handleConsumerLambdaCaptor.getValue().inTransaction(optionConfigsDAO);

            Optional<OptionConfigsNTT> actual = optionConfigsDAO.findById(ID_1).stream().findFirst();

            assertTrue(actual.isPresent());
            assertEquals(optionConfigsDTO.getOptionId(), actual.get().getOption_id());
            assertEquals(optionConfigsDTO.getOptionMinimumValue(), actual.get().getOption_minimum_value());
            assertEquals(optionConfigsDTO.getOptionRowMinimumEngageableValue(), actual.get().getOption_row_minimum_engageable_value());
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            fail(e.getMessage(), e);
        }
    }

    @Test
    void insertFormOperationConfigsI18n_ok() {
        optionConfigsCrudService.insertOptionConfigsI18n(TENANT, FORM_CODE, LANGUAGE, DESCRIPTION);

        verify(i18NServiceMock, times(1)).insertI18N(TENANT, I18N_OPTION_CONFIGS_TABLE,
                OptionConfigsCrudService.OPTION_CONFIGS_I18N.CODE.getCode(), Locale.ITALIAN.getLanguage(), FORM_CODE, DESCRIPTION);
    }

    @Test
    void deleteFormOperationConfigsI18N_ok() {
        optionConfigsCrudService.deleteOptionConfigsI18N(TENANT, FORM_CODE);

        verify(i18NServiceMock).deleteAllI18NbyCode(TENANT, I18N_OPTION_CONFIGS_TABLE, FORM_CODE);
    }

    @Test
    void getAllFormOperationConfigsI18NByTenantAndCode_ok() {
        RsI18N rsI18N = RsI18N.builder()
                .tenant_id(TENANT)
                .field_name(FIELD_NAME)
                .i18n_text(I18N_TEXT)
                .lang(LANG)
                .i18n_value(I18N_VALUE)
                .table_name(I18N_OPTION_CONFIGS_TABLE)
                .build();
        
        List<RsI18N> lres = List.of(rsI18N); 
        
        when(i18NServiceMock.getAllI18NbyCode(TENANT, I18N_OPTION_CONFIGS_TABLE,
                OptionConfigsCrudService.OPTION_CONFIGS_I18N.CODE.getCode())).thenReturn(lres);

        List<RsI18N> result =
                optionConfigsCrudService.getAllOptionConfigsI18NByTenantAndCode(TENANT, 
                		OptionConfigsCrudService.OPTION_CONFIGS_I18N.CODE.getCode());

        assertEquals(lres, result);
    }

    @Test
    void findRsByCustomKey_ok() {
        Optional<OptionConfigsNTT> result = optionConfigsCrudService.findRsByCustomKey(null);

        assertEquals(Optional.empty(), result);
    }

    @Test
    void deleteByCustomKey_ko() {
        assertThrows(NotImplementedException.class, () -> optionConfigsCrudService.deleteByCustomKey(null));
    }

    @Test
    void setCustomSearchKey_ko() {
        assertThrows(NotImplementedException.class, () -> optionConfigsCrudService.setCustomSearchKey(optionConfigsNTT, null));
    }

    @Test
    void findById_ko() {
        when(optionConfigsDAO.findById(ID_1))
                .thenReturn(List.of());

        assertThrows(ObjectNotFoundRuntimeException.class, () -> optionConfigsCrudService.findById(ID_1));
    }

    @Test
    @Deprecated
    void findByOptionCode_ko() {
        when(optionConfigsDAO.findByOptionCode(TENANT, OPTION_CODE))
                .thenReturn(List.of());

        assertThrows(ObjectNotFoundRuntimeException.class, () ->
                optionConfigsCrudService.findByOptionCode(TENANT, OPTION_CODE));
    }

    @Test
    void findByFormCodeAndOperationCodeAndDtValidityEnd_ko() {
        AbsoluteDate dtValidityEnd = new AbsoluteDate(DT_VALIDITY_END);

        when(optionConfigsDAO.findByOptionCodeAndDtValidityEnd(TENANT, OPTION_CODE, dtValidityEnd))
                .thenReturn(List.of());

        assertThrows(ObjectNotFoundRuntimeException.class, () ->
                optionConfigsCrudService.findByOptionCodeAndDtValidityEnd(TENANT, OPTION_CODE, dtValidityEnd));
    }

    @Test
    void filterOptionCodesByParams_ok() {

        when(optionConfigsDAO.filterOptionCodesByParams(TENANT, APPLICATION_ID, new AbsoluteDate(DT_VALIDITY_START), List.of(OPTION_CODE), List.of(PARAM_VALUE)))
                .thenReturn(List.of(OPTION_CODE));

        List<String> result =
                optionConfigsCrudService.filterOptionCodesByParams(TENANT, APPLICATION_ID, new AbsoluteDate(DT_VALIDITY_START), List.of(OPTION_CODE), List.of(PARAM_VALUE));

        assertEquals(List.of(OPTION_CODE), result);
    }
}
