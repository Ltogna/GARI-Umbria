package com.abacogroup.agri.applicationforms.pua.services;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.fail;
import static org.mockito.Mockito.when;

import org.glassfish.jersey.media.multipart.FormDataContentDisposition;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import com.abacogroup.agri.applicationforms.pua.core.exceptions.FileNotPermittedRuntimeException;

@ExtendWith(MockitoExtension.class)
class FileCheckerServiceTest {
    private FileCheckerService fileCheckerService;

    @BeforeEach
    void init() {
        fileCheckerService = new FileCheckerService();
    }

    @Test
    void checkFileExtension_ok() {
        try {
            FormDataContentDisposition formDataContentDisposition = Mockito.mock(FormDataContentDisposition.class);

            when(formDataContentDisposition.getFileName())
                    .thenReturn("ValidFile.png");

            assertDoesNotThrow(() -> fileCheckerService.checkFileExtension(formDataContentDisposition));
        } catch (Exception e) {
            fail(e.getMessage(), e);
        }
    }

    @Test
    void checkFileExtension_ko() {
        try {
            FormDataContentDisposition formDataContentDisposition = FormDataContentDisposition.name("Invalid file").build();

            assertThrows(FileNotPermittedRuntimeException.class, () ->
                    fileCheckerService.checkFileExtension(formDataContentDisposition));
        } catch (Exception e) {
            fail(e.getMessage(), e);
        }
    }
}
