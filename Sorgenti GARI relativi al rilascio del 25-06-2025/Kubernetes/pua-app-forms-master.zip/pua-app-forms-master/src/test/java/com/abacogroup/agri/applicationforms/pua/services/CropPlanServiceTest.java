package com.abacogroup.agri.applicationforms.pua.services;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.io.IOException;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import com.abacogroup.agri.applicationforms.pua.ApplicationFormsModuleConfiguration;
import com.abacogroup.agri.applicationforms.pua.core.model.dto.CropPlanResponse;
import com.abacogroup.agri.applicationforms.pua.core.model.dto.PlotRecord;
import com.abacogroup.agri.applicationforms.pua.core.model.dto.RecordResponse;
import com.abacogroup.agri.applicationforms.pua.core.model.dto.VersionResponse;
import com.abacogroup.agri.applicationforms.pua.util.JsonUtils;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sun.net.httpserver.HttpServer;

import jakarta.ws.rs.client.Client;
import jakarta.ws.rs.client.ClientBuilder;

/**
 * 
 * @author Emanuele Crocilla
 *
 */
public class CropPlanServiceTest extends AbstractServiceTest {

    private static final int SERVER_PORT = 8089;
    private static HttpServer httpServer;

    private static CropPlanService cropPlanService;

    @BeforeAll
    static void setUp() throws IOException {
    	
        // start local HTTP server
        httpServer = HttpServer.create(new InetSocketAddress(SERVER_PORT), 0);

        httpServer.start();

        //  configure service with local URL
        Client client = ClientBuilder.newClient();
        ApplicationFormsModuleConfiguration config = new ApplicationFormsModuleConfiguration();
        config.setCropPlanUrl("http://localhost:" + SERVER_PORT + "/mock-crop-plans");

        cropPlanService = new CropPlanService(null, client, config, new ObjectMapper());
    }

    @AfterAll
    static void tearDown() {
        httpServer.stop(0);
    }
    
    @Test
    void testGetCropPlans_Success() throws Exception {
    	
    	httpServer.createContext("/mock-crop-plans/" + TENANT + "/public/v1/crop-plans/" + BUSINESS_ID + "/plans", 
    		exchange -> {
                String cropPlanTypeCode = exchange.getRequestURI().getQuery();
                if (cropPlanTypeCode != null && cropPlanTypeCode.contains("cropPlanTypeCode="+CROP_PLAN_TYPE_CODE)) {
                    String response = "{\"count\":1,\"records\":[]}";
                    exchange.getResponseHeaders().add("Content-Type", "application/json");
                    exchange.sendResponseHeaders(200, response.getBytes().length);
                    OutputStream os = exchange.getResponseBody();
                    os.write(response.getBytes());
                    os.close();
                } else {
                    exchange.sendResponseHeaders(404, -1);
                }
    		});

        RecordResponse<CropPlanResponse> result = cropPlanService.getCropPlans(USER, TENANT, BUSINESS_ID, CROP_PLAN_TYPE_CODE);

        // Asserts
        assertNotNull(result);
        assertEquals(1, result.getCount());
    }
    

    @Test
    void testGetVersionCropPlan_Success() throws Exception {
      
        httpServer.createContext("/mock-crop-plans/" + TENANT + "/public/v1/crop-plans/" + BUSINESS_ID + "/plans/" + CROP_PLAN_ID + "/versions",
            exchange -> {
                
                Map<String, String> record1 = new HashMap<>();
                record1.put("versionReferenceDate", CAMPAGNA + "0125");
                List<Map<String, String>> l = new ArrayList<>();
                l.add(record1);
                String response =  JsonUtils.newMapWrapperInstance().put("count", 1).put("nextKey", "1").put("records", l).toJson();
                
                exchange.getResponseHeaders().add("Content-Type", "application/json");
                exchange.sendResponseHeaders(200, response.getBytes().length);
                OutputStream os = exchange.getResponseBody();
                os.write(response.getBytes());
                os.close();
            });

        RecordResponse<VersionResponse> result = cropPlanService.getVersionCropPlan(USER, TENANT, BUSINESS_ID, CROP_PLAN_ID, CAMPAGNA);

        // Asserts
        assertNotNull(result);
//        assertEquals(1, result.getCount()); // TODO EC capire perche' torna sempre zero
        assertEquals(CAMPAGNA + "0125", result.getRecords().get(0).getVersionReferenceDate());
    }

    @Test
    void testPlotCropPlan_Success() throws Exception {
       
        httpServer.createContext("/mock-crop-plans/" + TENANT + "/public/v1/crop-plans/" + BUSINESS_ID + "/plans/" + CROP_PLAN_ID + "/plots",
            exchange -> {
                String response = "{\"count\":2,\"records\":[{\"plotId\":1},{\"plotId\":2}]}";
                exchange.getResponseHeaders().add("Content-Type", "application/json");
                exchange.sendResponseHeaders(200, response.getBytes().length);
                OutputStream os = exchange.getResponseBody();
                os.write(response.getBytes());
                os.close();
            });

     
        RecordResponse<PlotRecord> result = cropPlanService.plotCropPlan(USER, TENANT, BUSINESS_ID, CROP_PLAN_ID, VERSION, CAMPAGNA);

        // Assert
        assertNotNull(result);
        assertEquals(2, result.getCount());
        assertEquals(1, result.getRecords().get(0).getPlotId());
        assertEquals(2, result.getRecords().get(1).getPlotId());
    }

//    @Test
//    void testGetVersionCropPlan_NoMatchingYear() throws Exception {
//        // Arrange
//        httpServer.createContext("/mock-crop-plans/" + TENANT + "/public/v1/crop-plans/" + BUSINESS_ID + "/plans/" + CROP_PLAN_ID + "/versions",
//            exchange -> {
//                String response = "{\"count\":1,\"records\":[{\"versionReferenceDate\":\"2020-01-01T00:00:00Z\"}]}";
//                exchange.getResponseHeaders().add("Content-Type", "application/json");
//                exchange.sendResponseHeaders(200, response.getBytes().length);
//                OutputStream os = exchange.getResponseBody();
//                os.write(response.getBytes());
//                os.close();
//            });
//
//        // Act & Assert
//        RuntimeException exception = assertThrows(RuntimeException.class, () ->
//                cropPlanService.getVersionCropPlan(USER, TENANT, BUSINESS_ID, CROP_PLAN_ID, CAMPAGNA)
//        );
//
//        assertTrue(exception.getMessage().contains("No matching version data found"));
//    }
}
