package com.abacogroup.agri.applicationforms.pua.services;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Collections;
import java.util.List;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.abacogroup.agri.applicationforms.pua.core.mappers.FiveYearDeclarationMapper;
import com.abacogroup.agri.applicationforms.pua.core.model.dto.FiveYearDeclarationDTO;
import com.abacogroup.agri.applicationforms.pua.core.model.dto.PartyResponse;
import com.abacogroup.agri.applicationforms.pua.db.dao.FiveYearDeclarationDAO;
import com.abacogroup.agri.applicationforms.pua.db.ntt.FiveYearDeclarationNTT;
import com.abacogroup.agri.applicationforms.pua.services.common.ApplicationFacadeService;
import com.abacogroup.applicationworkflowsdk.model.io.output.ApplicationDetailsPublicDTO;

/**
 * 
 * @author Emanuele Crocilla
 *
 */
@ExtendWith(MockitoExtension.class)
class FiveYearDeclarationServiceTest extends AbstractServiceTest {

	@Mock
    private FiveYearDeclarationDAO fiveYearDeclarationDAO;

    @Mock
    private FiveYearDeclarationMapper mapper;
    
    @Mock
    private PartyService partyService;

    @InjectMocks
    private FiveYearDeclarationService fiveYearDeclarationService;

    @Mock
	private ApplicationFacadeService applicationFacadeService;
    
    private static FiveYearDeclarationDTO in, modified, dbInserted;
    private static FiveYearDeclarationNTT dbFetched;
    private static PartyResponse partyResponse;
    
    @BeforeAll
    public static void init() {
    	
    	in = FiveYearDeclarationDTO.builder()
                .applicationId(APPLICATION_ID)
                .id(DECLARATION_ID)
                .partyId(PARTY_ID)
                .cadastralAreaSqm(100)
                .usedAreaSqm(100)
                .sectorCode(SECTOR_CODE)
                .userIdInsert(LOGGED_USER_ID)
                .build();

        dbFetched = FiveYearDeclarationNTT.builder()
                .applicationId(APPLICATION_ID)
                .pkId(PKID)
                .id(DECLARATION_ID)
                .partyId(UPDT_PARTY_ID)
                .cadastralAreaSqm(100)
                .usedAreaSqm(100)
                .sectorCode(SECTOR_CODE)
                .userIdInsert(LOGGED_USER_ID)
                .build();
        
        modified = FiveYearDeclarationDTO.builder()
                .applicationId(APPLICATION_ID)
                .id(DECLARATION_ID)
                .partyId(UPDT_PARTY_ID)
                .sectorCode(SECTOR_CODE)
                .userIdInsert(LOGGED_USER_ID)
                .build();
        
        dbInserted = FiveYearDeclarationDTO.builder()
                .applicationId(APPLICATION_ID)
                .id(DECLARATION_ID)
                .partyId(PARTY_ID)
                .sectorCode(SECTOR_CODE)
                .userIdInsert(LOGGED_USER_ID)
                .build();
        
        partyResponse = PartyResponse.builder()
        		.id(PARTY_ID.intValue())
        		.code(PARTY_CODE)
        		.build(); 
    }

    // Test: Insert
    @Test
    void testInsertSuccess() {

        when(partyService.getPartyById(LOGGED_USER,TENANT, PARTY_ID)).thenReturn(partyResponse);
        
        when(fiveYearDeclarationService.firstTimeInsertion(any())).thenReturn(dbInserted);
 
        FiveYearDeclarationDTO res = 
        		fiveYearDeclarationService.insert(LOGGED_USER, TENANT,  APPLICATION_ID, FORM_CONFIG_ID,  
        					COMPILE_STATUS_IDENTIFIER, in);
        
        assertNotNull(res);
        assertEquals(APPLICATION_ID, res.getApplicationId());
        assertEquals(DECLARATION_ID, res.getId());
        assertEquals(PARTY_ID, res.getPartyId());
        assertEquals(SECTOR_CODE, res.getSectorCode());
    }
    
    @Test
    void testUpdateSuccess() {

        when(fiveYearDeclarationDAO.findByDeclarationId(DECLARATION_ID)).thenReturn(dbFetched);
        
        when(mapper.entityToDto(dbFetched)).thenReturn(modified);
        
        when(partyService.getPartyById(LOGGED_USER,TENANT, PARTY_ID)).thenReturn(partyResponse);
         
        FiveYearDeclarationDTO res = 
        		fiveYearDeclarationService.update(LOGGED_USER, TENANT,  APPLICATION_ID, FORM_CONFIG_ID,  
        					COMPILE_STATUS_IDENTIFIER, in);
        
        assertNotNull(res);
        assertEquals(UPDT_PARTY_ID, res.getPartyId());
        assertNotEquals(in.getPartyId(), res.getPartyId() );
        assertEquals(APPLICATION_ID, res.getApplicationId());
        assertEquals(DECLARATION_ID, res.getId());
        assertEquals(SECTOR_CODE, res.getSectorCode());
    }

    // Test: Delete
    @Test
    void testDeleteSuccess() {
        
        FiveYearDeclarationNTT ntt = FiveYearDeclarationNTT.builder()
                .pkId(PKID)
                .applicationId(APPLICATION_ID)
                .build();

        when(fiveYearDeclarationDAO.findByDeclarationId(DECLARATION_ID)).thenReturn(ntt);
         
        boolean result = fiveYearDeclarationService.delete(LOGGED_USER, TENANT, APPLICATION_ID, FORM_CONFIG_ID, COMPILE_STATUS_IDENTIFIER, DECLARATION_ID);
        
        assertTrue(result);
        ArgumentCaptor<Long> idCaptor = ArgumentCaptor.forClass(Long.class);
        ArgumentCaptor<Long> declarationIdCaptor = ArgumentCaptor.forClass(Long.class);
        verify(fiveYearDeclarationDAO).expireByPkId(idCaptor.capture(), declarationIdCaptor.capture(), any(), eq(LOGGED_USER_ID));
        assertEquals(APPLICATION_ID, idCaptor.getValue());
        assertEquals(PKID, declarationIdCaptor.getValue());
    }

    @Test
    void testDeleteFailsWhenNotFound() {
        
        when(fiveYearDeclarationDAO.findByDeclarationId(DECLARATION_ID)).thenReturn(null);
        
        boolean result = fiveYearDeclarationService.delete(LOGGED_USER, TENANT, APPLICATION_ID, FORM_CONFIG_ID, COMPILE_STATUS_IDENTIFIER, DECLARATION_ID);
        
        assertFalse(result);
        verify(fiveYearDeclarationDAO, never()).expireByDeclarationId(anyLong(), anyLong(), any(), any());
    }

    // Test: Get All
    @Test
    void testGetAllSuccess() {
        
        FiveYearDeclarationNTT ntt = FiveYearDeclarationNTT.builder()
                .pkId(1L)
                .applicationId(APPLICATION_ID)
                .sectorCode(SECTOR_CODE)
                .build();
        
        ApplicationDetailsPublicDTO mockApplicationDetailsPublicDTO = ApplicationDetailsPublicDTO.builder()
        		.build();
    	
    	when(applicationFacadeService.callForApplicationDetails(TENANT, APPLICATION_ID, LOGGED_USER, LANGUAGE))
    	.thenReturn(mockApplicationDetailsPublicDTO);

        when(fiveYearDeclarationDAO.findByApplicationId(APPLICATION_ID)).thenReturn(Collections.singletonList(ntt));
        when(mapper.entityToDto(ntt)).thenReturn(dbInserted);
        
        when(partyService.getPartyById(LOGGED_USER,TENANT, PARTY_ID)).thenReturn(partyResponse);

        List<FiveYearDeclarationDTO> result = fiveYearDeclarationService.getAll(LOGGED_USER, TENANT, APPLICATION_ID);
        
        assertNotNull(result);
        assertEquals(1, result.size());
        assertEquals(dbInserted, result.get(0));
        verify(mapper).entityToDto(ntt);
    }

    @Test
    void testGetAllReturnsEmptyList() {
    	
    	ApplicationDetailsPublicDTO mockApplicationDetailsPublicDTO = ApplicationDetailsPublicDTO.builder()
        		.build();
    	
    	when(applicationFacadeService.callForApplicationDetails(TENANT, APPLICATION_ID, LOGGED_USER, LANGUAGE))
    	.thenReturn(mockApplicationDetailsPublicDTO);
        
        when(fiveYearDeclarationDAO.findByApplicationId(APPLICATION_ID)).thenReturn(Collections.emptyList());
        
        List<FiveYearDeclarationDTO> result = fiveYearDeclarationService.getAll(LOGGED_USER, TENANT, APPLICATION_ID);
        
        assertNotNull(result);
        assertTrue(result.isEmpty());
        verify(fiveYearDeclarationDAO).findByApplicationId(APPLICATION_ID);
    }
}
