package com.abacogroup.agri.applicationforms.pua.services;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.List;
import java.util.Locale;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.abacogroup.agri.applicationforms.pua.core.exceptions.ObjectNotFoundRuntimeException;
import com.abacogroup.agri.applicationforms.pua.services.common.ApplicationFacadeConfig;
import com.abacogroup.agri.applicationforms.pua.services.common.ApplicationFacadeService;
import com.abacogroup.agri.applicationforms.pua.util.CommonConstants;
import com.abacogroup.applicationsupport.caller.DeleteCompileStatusCaller;
import com.abacogroup.applicationsupport.caller.GetApplicationByPartyYearModuleCodeCaller;
import com.abacogroup.applicationsupport.caller.GetApplicationDetailsCaller;
import com.abacogroup.applicationsupport.caller.GetApplicationPrintHistoryCaller;
import com.abacogroup.applicationsupport.caller.GetApplicationProfilesCaller;
import com.abacogroup.applicationsupport.caller.GetCompileStatusCaller;
import com.abacogroup.applicationsupport.caller.GetFormDetailsCaller;
import com.abacogroup.applicationsupport.caller.GetFormReadOnlyCaller;
import com.abacogroup.applicationsupport.caller.PutCompileStatusCaller;
import com.abacogroup.applicationsupport.model.io.callerinput.DeleteCompileStatusInput;
import com.abacogroup.applicationsupport.model.io.callerinput.GetApplicationDetailsInput;
import com.abacogroup.applicationsupport.model.io.callerinput.GetApplicationPrintHistoryInput;
import com.abacogroup.applicationsupport.model.io.callerinput.PutCompileStatusInput;
import com.abacogroup.applicationsupport.model.io.output.ApplicationGeneratedPrintDTO;
import com.abacogroup.applicationworkflowsdk.model.io.output.ApplicationByPartyAndYearDTO;
import com.abacogroup.applicationworkflowsdk.model.io.output.ApplicationCompileStatusPayloadDTO;
import com.abacogroup.applicationworkflowsdk.model.io.output.ApplicationDetailsPublicDTO;

@ExtendWith(MockitoExtension.class)
class ApplicationFacadeServiceTest extends AbstractServiceTest {
	
	@Mock
	private GetCompileStatusCaller getCompileStatusCallerMock;
	@Mock
	private GetFormReadOnlyCaller getFormReadOnlyCallerMock;
	@Mock
	private PutCompileStatusCaller putCompileStatusCallerMock;
	@Mock
	private DeleteCompileStatusCaller deleteCompileStatusCallerMock;
	@Mock
	private GetApplicationDetailsCaller getApplicationDetailsCallerMock;
	@Mock
	private GetApplicationByPartyYearModuleCodeCaller getApplicationByPartyYearModuleCodeCallerMock;
	@Mock
	private GetFormDetailsCaller getFormConfigs;
	@Mock
	private GetApplicationPrintHistoryCaller getApplicationPrintHistoryCaller;
	@Mock
	private GetApplicationProfilesCaller getApplicationProfilesCaller;

//	@InjectMocks
	private ApplicationFacadeService applicationFacadeService;

	private final ApplicationDetailsPublicDTO applicationDetailsPublicDTO = ApplicationDetailsPublicDTO.builder()
			.applicationId(APPLICATION_ID)
			.partyId(PARTY_ID)
			.referredYear(YEAR)
			.applicationCode(APPLICATION_CODE_1)
			.processStatus(PROCESS_STATUS_1.name())
			.processId(PROCESS_ID_1)
			.dtPresentation(DT_PRESENTATION)
			.sectorDescription(SECTOR_DESCRIPTION)
			.moduleDescription(MODULE_DESCRIPTION)
			.isClosed(IS_CLOSED)
			.build();
	private final ApplicationGeneratedPrintDTO applicationGeneratedPrintDTO = ApplicationGeneratedPrintDTO.builder()
			.applicationId(APPLICATION_ID)
			.processStatus(PROCESS_STATUS_1.name())
			.username(USERNAME)
			.build();
//	private final MyDetailedTransitionHistory myDetailedTransitionHistory = MyDetailedTransitionHistory.builder()
//			.description(MODULE_DESCRIPTION)
//			.processId(PROCESS_ID_1)
//			.userId(USERNAME)
//			.build();
//	private final ApplicationByPartyAndYearDTO applicationByPartyAndYearDTO1 = ApplicationByPartyAndYearDTO.builder()
//			.year(YEAR)
//			.applicationCode(APPLICATION_CODE_1)
//			.processStatus(PROCESS_STATUS_1.name())
//			.partyId(PARTY_ID)
//			.processId(PROCESS_ID_1)
//			.dtPresentation(DT_PRESENTATION.toString())
//			.moduleCode(MODULE_CODE)
//			.moduleDescription(MODULE_DESCRIPTION)
//			.build();
	ApplicationByPartyAndYearDTO applicationByPartyAndYearDTO2 = ApplicationByPartyAndYearDTO.builder()
			.year(YEAR)
			.applicationCode(APPLICATION_CODE_2)
			.processStatus(PROCESS_STATUS_2.name())
			.partyId(PARTY_ID)
			.processId(PROCESS_ID_2)
			.moduleCode(MODULE_CODE)
			.build();
//	private final List<ApplicationByPartyAndYearDTO> applicationByPartyAndYearDTOs = List.of(applicationByPartyAndYearDTO1, applicationByPartyAndYearDTO2);
//	private final FormDetailsPublicDTO formDetailsPublicDTO = FormDetailsPublicDTO.builder()
//			.formConfigId(OPTION_CONFIG_ID)
//			.compileStatus(COMPILE_STATUS_ENUM.name())
//			.compileStatusIdentifier(COMPILE_STATUS_IDENTIFIER)
//			.flReadOnly(0)
//			.formCode(FORM_CODE)
//			.formName(FORM_NAME)
//			.params(Map.of(KEY_1, VALUE_1, KEY_2, VALUE_2))
//			.build();
//	private final FormGroupPublicDTO formGroupPublicDTO1 = FormGroupPublicDTO.builder()
//			.groupCode(GROUP_CODE_1)
//			.groupName(GROUP_NAME_1)
//			.build();
//	private final FormGroupPublicDTO formGroupPublicDTO2 = FormGroupPublicDTO.builder()
//			.groupCode(GROUP_CODE_2)
//			.groupName(GROUP_NAME_2)
//			.build();
//	private final FormWithGroupHierarchyPublicDTO formWithGroupHierarchyPublicDTO = FormWithGroupHierarchyPublicDTO.builder()
//			.formDetails(formDetailsPublicDTO)
//			.groups(List.of(formGroupPublicDTO1, formGroupPublicDTO2))
//			.build();
//	private final ModuleFormConfigsOutput moduleFormConfigsOutput = ModuleFormConfigsOutput.builder()
//			.formConfigId(FORM_CONFIG_ID)
//			.formCode(FORM_CODE)
//			.flReadOnly(0)
//			.compileStatusIdentifier(COMPILE_STATUS_IDENTIFIER)
//			.processStatus(PROCESS_STATUS_1.name())
//			.build();
//	private final GetAllModuleConfigsByModuleCodeOutput getAllModuleConfigsByModuleCodeOutput = GetAllModuleConfigsByModuleCodeOutput.builder()
//			.moduleCode(MODULE_CODE)
//			.configs(List.of(moduleFormConfigsOutput))
//			.build();

	@BeforeEach
	void init() {
		 
		var applicationFacadeOptions = ApplicationFacadeConfig.builder()
				.getCompileStatusCaller(getCompileStatusCallerMock)
				.getFormReadOnlyCaller(getFormReadOnlyCallerMock)
				.putCompileStatusCaller(putCompileStatusCallerMock) 
				.deleteCompileStatusCaller(deleteCompileStatusCallerMock)
				.putProfilesCaller(null)
				.getApplicationDetailsCaller(getApplicationDetailsCallerMock)
				.getApplicationByPartyYearModuleCodeCaller(getApplicationByPartyYearModuleCodeCallerMock)
				.getFormDetailsCaller(getFormConfigs)
				.getApplicationPrintHistoryCaller(getApplicationPrintHistoryCaller)
				.getApplicationProfilesCaller(getApplicationProfilesCaller)
				.applicationsBaseUrl(APPLICATION_BASE_URL)
				.build();

		applicationFacadeService = new ApplicationFacadeService(applicationFacadeOptions);
	}

//	@Test
//	void cannotAcceptDispositiveCalls_ok() {
//		ReadOnlyDto readOnlyDto = ReadOnlyDto.builder()
//				.readOnly(true)
//				.build();
//
//		GetReadOnlyInput input = GetReadOnlyInput.builder()
//				.authToken(MDC.get(MDCPreFilter.USED_JWT))
//				.applicationId(APPLICATION_ID)
//				.tenant(TENANT)
//				.formConfigId(OPTION_CONFIG_ID)
//				.applicationsBaseUrl(APPLICATION_BASE_URL)
//				.build();
//
//		when(getFormReadOnlyCallerMock.makeCall(input))
//				.thenReturn(readOnlyDto);
//
//		assertTrue(applicationFacadeService.cannotAcceptDispositiveCalls(TENANT, APPLICATION_ID, OPTION_CONFIG_ID));
//	}

//	@Test
//	void isFormReadOnly_ok() {
//		ReadOnlyDto readOnlyDto = ReadOnlyDto.builder()
//				.readOnly(true)
//				.build();
//
//		GetReadOnlyInput input = GetReadOnlyInput.builder()
//				.authToken(MDC.get(MDCPreFilter.USED_JWT))
//				.applicationId(APPLICATION_ID)
//				.tenant(TENANT)
//				.formConfigId(OPTION_CONFIG_ID)
//				.applicationsBaseUrl(APPLICATION_BASE_URL)
//				.build();
//
//		when(getFormReadOnlyCallerMock.makeCall(input))
//				.thenReturn(readOnlyDto);
//
//		assertTrue(applicationFacadeService.isFormReadOnly(TENANT, APPLICATION_ID, OPTION_CONFIG_ID));
//	}

//	@Test
//	void verifyAcceptDispositiveCalls_ok() {
//		ReadOnlyDto readOnlyDto = ReadOnlyDto.builder()
//				.readOnly(false)
//				.build();
//
//		GetReadOnlyInput input = GetReadOnlyInput.builder()
//				.authToken(MDC.get(MDCPreFilter.USED_JWT))
//				.applicationId(APPLICATION_ID)
//				.tenant(TENANT)
//				.applicationsBaseUrl(APPLICATION_BASE_URL)
//				.formConfigId(OPTION_CONFIG_ID)
//				.build();
//
//		when(getFormReadOnlyCallerMock.makeCall(input))
//				.thenReturn(readOnlyDto);
//
//		applicationFacadeService.verifyAcceptDispositiveCalls(TENANT, APPLICATION_ID, OPTION_CONFIG_ID);
//
//		verify(getFormReadOnlyCallerMock, times(1)).makeCall(input);
//	}

	@Test
	void updateCompileStatus_ok() {
		PutCompileStatusInput input = PutCompileStatusInput.builder()
				.authToken(CommonConstants.AUTH_PREFIX + USER.getAuthToken())
				.tenant(TENANT)
				.applicationId(APPLICATION_ID)
				.appCompileStatusIdentifier(COMPILE_STATUS_IDENTIFIER)
				.payload(ApplicationCompileStatusPayloadDTO.builder()
						.status(COMPILE_STATUS_ENUM.name())
						.build())
				.locale(Locale.ITALIAN.getLanguage())
				.applicationsBaseUrl(APPLICATION_BASE_URL)
				.build();

		applicationFacadeService.updateCompileStatus(TENANT, APPLICATION_ID, COMPILE_STATUS_IDENTIFIER, COMPILE_STATUS_ENUM, USER, LANGUAGE);

		verify(putCompileStatusCallerMock, times(1)).makeCall(input);
	}

	@Test
	void deleteCompileStatus_ok() {
		DeleteCompileStatusInput input = DeleteCompileStatusInput.builder()
				.authToken(CommonConstants.AUTH_PREFIX + USER.getAuthToken())
				.tenant(TENANT)
				.applicationId(APPLICATION_ID)
				.appCompileStatusIdentifier(COMPILE_STATUS_IDENTIFIER)
				.locale(Locale.ITALIAN.getLanguage())
				.applicationsBaseUrl(APPLICATION_BASE_URL)
				.build();
		
//		DeleteCompileStatusInput.builder()
//        .applicationsBaseUrl(this.applicationsBaseUrl)
//        .authToken(retrieveAuthToken(user))
//        .tenant(tenant)
//        .applicationId(applicationId)
//        .appCompileStatusIdentifier(compileStatusIdentifier)
//        .locale(Locale.ITALIAN.getLanguage())
//        .build()

		applicationFacadeService.deleteCompileStatus(USER, TENANT, APPLICATION_ID, COMPILE_STATUS_IDENTIFIER);

		verify(deleteCompileStatusCallerMock, times(1)).makeCall(input);
	}

//	@Test
//	void getApplicationDetails_ok() {
//		GetApplicationDetailsInput input = GetApplicationDetailsInput.builder()
//				.applicationId(APPLICATION_ID)
//				.tenant(TENANT)
//				.authToken(MDC.get(MDCPreFilter.USED_JWT))
//				.locale(Locale.ITALIAN.getLanguage())
//				.applicationsBaseUrl(APPLICATION_BASE_URL)
//				.build();
//
//		when(getApplicationDetailsCallerMock.makeCall(input))
//				.thenReturn(applicationDetailsPublicDTO);
//
//		ApplicationDetailsPublicDTO result = applicationFacadeService.getApplicationDetails(TENANT, APPLICATION_ID);
//
//		assertEquals(applicationDetailsPublicDTO, result);
//	}

//	@Test
//	void getApplicationReferredYear_ok() {
//		GetApplicationDetailsInput input = GetApplicationDetailsInput.builder()
//				.applicationId(APPLICATION_ID)
//				.tenant(TENANT)
//				.authToken(MDC.get(MDCPreFilter.USED_JWT))
//				.locale(Locale.ITALIAN.getLanguage())
//				.applicationsBaseUrl(APPLICATION_BASE_URL)
//				.build();
//
//		when(getApplicationDetailsCallerMock.makeCall(input))
//				.thenReturn(applicationDetailsPublicDTO);
//
//		Integer result = applicationFacadeService.getApplicationReferredYear(TENANT, APPLICATION_ID);
//
//		assertEquals(YEAR, result);
//	}

//	@Test
//	void getPartyIdFromApplicationId_ok() {
//		GetApplicationDetailsInput input = GetApplicationDetailsInput.builder()
//				.applicationId(APPLICATION_ID)
//				.tenant(TENANT)
//				.authToken(MDC.get(MDCPreFilter.USED_JWT))
//				.locale(Locale.ITALIAN.getLanguage())
//				.applicationsBaseUrl(APPLICATION_BASE_URL)
//				.build();
//
//		when(getApplicationDetailsCallerMock.makeCall(input))
//				.thenReturn(applicationDetailsPublicDTO);
//
//		Long result = applicationFacadeService.getPartyIdFromApplicationId(TENANT, APPLICATION_ID);
//
//		assertEquals(PARTY_ID, result);
//	}

//	@Test
//	void isApplicationClosed_ok() {
//		GetApplicationDetailsInput input = GetApplicationDetailsInput.builder()
//				.applicationId(APPLICATION_ID)
//				.tenant(TENANT)
//				.authToken(MDC.get(MDCPreFilter.USED_JWT))
//				.locale(Locale.ITALIAN.getLanguage())
//				.applicationsBaseUrl(APPLICATION_BASE_URL)
//				.build();
//
//		when(getApplicationDetailsCallerMock.makeCall(input))
//				.thenReturn(applicationDetailsPublicDTO);
//
//		Boolean result = applicationFacadeService.isApplicationClosed(TENANT, APPLICATION_ID);
//
//		assertFalse(result);
//	}

//	@Test
//	void getApplicationsByPartyYearAndModuleCode_ok() {
//		GetApplicationByPartyYearModuleInput input = GetApplicationByPartyYearModuleInput.builder()
//				.tenant(TENANT)
//				.partyId(PARTY_ID)
//				.year(YEAR)
//				.moduleCode(MODULE_CODE)
//				.authToken(MDC.get(MDCPreFilter.USED_JWT))
//				.locale(Locale.ITALIAN.getLanguage())
//				.build();
//
//		when(getApplicationByPartyYearModuleCodeCallerMock.makeCall(input))
//				.thenReturn(applicationByPartyAndYearDTOs);
//
//		List<ApplicationByPartyAndYearDTO> result = applicationFacadeService.getApplicationsByPartyYearAndModuleCode(TENANT, PARTY_ID, YEAR, MODULE_CODE);
//
//		assertEquals(applicationByPartyAndYearDTOs, result);
//	}

//	@Test
//	void getApplicationCompilerStatuses_ok() {
//		GetCompileStatusInput input1 = GetCompileStatusInput.builder()
//				.tenant(TENANT)
//				.applicationId(APPLICATION_ID)
//				.authToken(MDC.get(MDCPreFilter.USED_JWT))
//				.applicationsBaseUrl(APPLICATION_BASE_URL)
//				.build();
//		GetCompileStatusInput input2 = GetCompileStatusInput.builder()
//				.tenant(TENANT)
//				.applicationId(APPLICATION_ID)
//				.authToken(MDC.get(MDCPreFilter.USED_JWT))
//				.applicationsBaseUrl(APPLICATION_BASE_URL)
//				.nextKey(NEXT_KEY)
//				.build();
//
//		ApplicationCompileStatusDTO applicationCompileStatusDTO1 = ApplicationCompileStatusDTO.builder()
//				.build();
//		ApplicationCompileStatusDTO applicationCompileStatusDTO2 = ApplicationCompileStatusDTO.builder()
//				.build();
//
//		InfiniteListResultsImpl<ApplicationCompileStatusDTO> applicationCompileStatusDTOInfiniteListResults1 = new InfiniteListResultsImpl<>();
//		applicationCompileStatusDTOInfiniteListResults1.setRecords(List.of(applicationCompileStatusDTO1));
//		applicationCompileStatusDTOInfiniteListResults1.setNextKey(NEXT_KEY);
//		InfiniteListResultsImpl<ApplicationCompileStatusDTO> applicationCompileStatusDTOInfiniteListResults2 = new InfiniteListResultsImpl<>();
//		applicationCompileStatusDTOInfiniteListResults2.setRecords(List.of(applicationCompileStatusDTO2));
//
//		List<ApplicationCompileStatusDTO> expectedOutput = List.of(applicationCompileStatusDTO1, applicationCompileStatusDTO2);
//
//		when(getCompileStatusCallerMock.makeCall(input1))
//				.thenReturn(applicationCompileStatusDTOInfiniteListResults1);
//		when(getCompileStatusCallerMock.makeCall(input2))
//				.thenReturn(applicationCompileStatusDTOInfiniteListResults2);
//
//		List<ApplicationCompileStatusDTO> result = applicationFacadeService.getApplicationCompilerStatuses(TENANT, APPLICATION_ID);
//
//		assertEquals(expectedOutput, result);
//	}

//	@Test
//	void getPreviousYearApplications_ok() {
//		GetApplicationByPartyYearModuleInput input = GetApplicationByPartyYearModuleInput.builder()
//				.tenant(TENANT)
//				.partyId(PARTY_ID)
//				.year(YEAR)
//				.moduleCode(MODULE_CODE)
//				.authToken(MDC.get(MDCPreFilter.USED_JWT))
//				.locale(Locale.ITALIAN.getLanguage())
//				.build();
//
//		when(getApplicationByPartyYearModuleCodeCallerMock.makeCall(input))
//				.thenReturn(applicationByPartyAndYearDTOs);
//
//		List<ApplicationByPartyAndYearDTO> result = applicationFacadeService.getPreviousYearApplications(TENANT, PARTY_ID, 2024, MODULE_CODE);
//
//		assertEquals(applicationByPartyAndYearDTOs, result);
//	}

//	@Test
//	void getFormConfigList_ok() {
//		GetFormDetailsInput input = GetFormDetailsInput.builder()
//				.tenant(TENANT)
//				.applicationId(APPLICATION_ID)
//				.locale(Locale.ITALIAN.getLanguage())
//				.authToken(MDC.get(MDCPreFilter.USED_JWT))
//				.applicationsBaseUrl(APPLICATION_BASE_URL)
//				.build();
//
//		when(getFormConfigs.makeCall(input))
//				.thenReturn(List.of(formWithGroupHierarchyPublicDTO));
//
//		List<FormWithGroupHierarchyPublicDTO> result = applicationFacadeService.getFormConfigList(TENANT, APPLICATION_ID);
//
//		assertEquals(List.of(formWithGroupHierarchyPublicDTO), result);
//	}

//	@Test
//	void callForGetModuleConfigList_ok() {
//		GetAllModuleFormConfigsByModuleCodeInput input = GetAllModuleFormConfigsByModuleCodeInput.builder()
//				.tenant(TENANT)
//				.locale(Optional.ofNullable(Locale.ITALIAN.getLanguage()).orElse("it"))
//				.authToken(MDC.get(MDCPreFilter.USED_JWT))
//				.applicationsBaseUrl(APPLICATION_BASE_URL)
//				.build();
//
//		when(getAllModuleFormConfigsByModuleCodeCaller.makeCall(input))
//				.thenReturn(getAllModuleConfigsByModuleCodeOutput);
//
//		GetAllModuleConfigsByModuleCodeOutput result = applicationFacadeService.callForGetModuleConfigList(TENANT, MODULE_CODE);
//
//		assertEquals(getAllModuleConfigsByModuleCodeOutput, result);
//	}

//	@Test
//	void getFormConfigListNoCache_ok() {
//		GetFormDetailsInput input = GetFormDetailsInput.builder()
//				.tenant(TENANT)
//				.applicationId(APPLICATION_ID)
//				.locale(Locale.ITALIAN.getLanguage())
//				.authToken(MDC.get(MDCPreFilter.USED_JWT))
//				.applicationsBaseUrl(APPLICATION_BASE_URL)
//				.build();
//
//		when(getFormConfigs.makeCall(input))
//				.thenReturn(List.of(formWithGroupHierarchyPublicDTO));
//
//		List<FormWithGroupHierarchyPublicDTO> result = applicationFacadeService.getFormConfigListNoCache(TENANT, APPLICATION_ID);
//
//		assertEquals(List.of(formWithGroupHierarchyPublicDTO), result);
//	}

//	@Test
//	void filterFormConfigList_ok() {
//		GetFormDetailsInput input = GetFormDetailsInput.builder()
//				.tenant(TENANT)
//				.applicationId(APPLICATION_ID)
//				.locale(Locale.ITALIAN.getLanguage())
//				.authToken(MDC.get(MDCPreFilter.USED_JWT))
//				.applicationsBaseUrl(APPLICATION_BASE_URL)
//				.build();
//
//		when(getFormConfigs.makeCall(input))
//				.thenReturn(List.of(formWithGroupHierarchyPublicDTO));
//
//		String result = applicationFacadeService.filterFormConfigList(TENANT, APPLICATION_ID, COMPILE_STATUS_IDENTIFIER, KEY_1);
//
//		assertEquals(VALUE_1, result);
//	}

//	@Test
//	void filterFormConfigList_null_ok() {
//		GetFormDetailsInput input = GetFormDetailsInput.builder()
//				.tenant(TENANT)
//				.applicationId(APPLICATION_ID)
//				.locale(Locale.ITALIAN.getLanguage())
//				.authToken(MDC.get(MDCPreFilter.USED_JWT))
//				.applicationsBaseUrl(APPLICATION_BASE_URL)
//				.build();
//
//		when(getFormConfigs.makeCall(input))
//				.thenReturn(List.of());
//
//		assertNull(applicationFacadeService.filterFormConfigList(TENANT, APPLICATION_ID, COMPILE_STATUS_IDENTIFIER, KEY_1));
//	}

//	@Test
//	void getAttachmentGroupValue_ok() {
//		GetFormDetailsInput input = GetFormDetailsInput.builder()
//				.tenant(TENANT)
//				.applicationId(APPLICATION_ID)
//				.locale(Locale.ITALIAN.getLanguage())
//				.authToken(MDC.get(MDCPreFilter.USED_JWT))
//				.applicationsBaseUrl(APPLICATION_BASE_URL)
//				.build();
//
//		formWithGroupHierarchyPublicDTO
//				.getFormDetails().setParams(Map.of(ATTACHMENT_GROUP_KEY, VALUE_1));
//
//		when(getFormConfigs.makeCall(input))
//				.thenReturn(List.of(formWithGroupHierarchyPublicDTO));
//
//		String result = applicationFacadeService.getAttachmentGroupValue(TENANT, APPLICATION_ID, COMPILE_STATUS_IDENTIFIER);
//
//		assertEquals(VALUE_1, result);
//	}

//	@Test
//	void getDocumentCodeValue_ok() {
//		GetFormDetailsInput input = GetFormDetailsInput.builder()
//				.tenant(TENANT)
//				.applicationId(APPLICATION_ID)
//				.locale(Locale.ITALIAN.getLanguage())
//				.authToken(MDC.get(MDCPreFilter.USED_JWT))
//				.applicationsBaseUrl(APPLICATION_BASE_URL)
//				.build();
//
//		formWithGroupHierarchyPublicDTO
//				.getFormDetails().setParams(Map.of(DOCUMENT_CODE_KEY, VALUE_1));
//
//		when(getFormConfigs.makeCall(input))
//				.thenReturn(List.of(formWithGroupHierarchyPublicDTO));
//
//		String result = applicationFacadeService.getDocumentCodeValue(TENANT, APPLICATION_ID, COMPILE_STATUS_IDENTIFIER);
//
//		assertEquals(VALUE_1, result);
//	}

//	@Test
//	void verifyAcceptDispositiveCalls_ko() {
//		ReadOnlyDto readOnlyDto = ReadOnlyDto.builder()
//				.readOnly(true)
//				.build();
//
//		GetReadOnlyInput input = GetReadOnlyInput.builder()
//				.authToken(MDC.get(MDCPreFilter.USED_JWT))
//				.applicationId(APPLICATION_ID)
//				.tenant(TENANT)
//				.formConfigId(OPTION_CONFIG_ID)
//				.applicationsBaseUrl(APPLICATION_BASE_URL)
//				.build();
//
//		when(getFormReadOnlyCallerMock.makeCall(input))
//				.thenReturn(readOnlyDto);
//
//		assertThrows(OperationNotPermittedRuntimeException.class,
//				() -> applicationFacadeService.verifyAcceptDispositiveCalls(TENANT, APPLICATION_ID, OPTION_CONFIG_ID));
//	}

//	@Test
//	void verifyOptionCodeList_ok() {
//		GetFormDetailsInput input = GetFormDetailsInput.builder()
//				.tenant(TENANT)
//				.applicationId(APPLICATION_ID)
//				.locale(Locale.ITALIAN.getLanguage())
//				.authToken(MDC.get(MDCPreFilter.USED_JWT))
//				.applicationsBaseUrl(APPLICATION_BASE_URL)
//				.build();
//
//		formWithGroupHierarchyPublicDTO
//				.getFormDetails().setParams(Map.of("option_codes", OPTION_CODE_1));
//
//		when(getFormConfigs.makeCall(input))
//				.thenReturn(List.of(formWithGroupHierarchyPublicDTO));
//
//		applicationFacadeService.verifyOptionCodeList(TENANT, APPLICATION_ID, List.of(OPTION_CODE_1), FORM_CODE);
//	}

//	@Test
//	void verifyOptionCodeList_2_ok() {
//		GetFormDetailsInput input = GetFormDetailsInput.builder()
//				.tenant(TENANT)
//				.applicationId(APPLICATION_ID)
//				.locale(Locale.ITALIAN.getLanguage())
//				.authToken(MDC.get(MDCPreFilter.USED_JWT))
//				.applicationsBaseUrl(APPLICATION_BASE_URL)
//				.build();
//
//		formWithGroupHierarchyPublicDTO
//				.getFormDetails().setParams(Map.of("option_codes", OPTION_CODE_1));
//
//		when(getFormConfigs.makeCall(input))
//				.thenReturn(List.of(formWithGroupHierarchyPublicDTO));
//
//		applicationFacadeService.verifyOptionCodeList(TENANT, APPLICATION_ID, List.of(OPTION_CODE_1));
//	}

//	@Test
//	void doVerifyOptionCodeList_ko() {
//		GetFormDetailsInput input = GetFormDetailsInput.builder()
//				.tenant(TENANT)
//				.applicationId(APPLICATION_ID)
//				.locale(Locale.ITALIAN.getLanguage())
//				.authToken(MDC.get(MDCPreFilter.USED_JWT))
//				.applicationsBaseUrl(APPLICATION_BASE_URL)
//				.build();
//
//		formWithGroupHierarchyPublicDTO
//				.getFormDetails().setParams(Map.of("option_codes", FORM_CODE));
//
//		when(getFormConfigs.makeCall(input))
//				.thenReturn(List.of(formWithGroupHierarchyPublicDTO));
//
//		List<String> optionCodes = List.of(OPTION_CODE_1);
//		assertThrows(OptionCodeListNotValidRuntimeException.class, () -> applicationFacadeService.verifyOptionCodeList(TENANT, APPLICATION_ID, optionCodes));
//	}

	@Test
	void callForApplicationDetails_ok() {
		GetApplicationDetailsInput input = GetApplicationDetailsInput.builder()
				.applicationId(APPLICATION_ID)
				.tenant(TENANT)
				.applicationsBaseUrl(APPLICATION_BASE_URL)
				.authToken(CommonConstants.AUTH_PREFIX + AUTH_TOKEN)
				.locale(Locale.ITALIAN.getLanguage())
				.build();

		when(getApplicationDetailsCallerMock.makeCall(input))
				.thenReturn(applicationDetailsPublicDTO);

		ApplicationDetailsPublicDTO result = applicationFacadeService.callForApplicationDetails(TENANT, APPLICATION_ID,
				USER, Locale.ITALIAN.getLanguage());

		assertEquals(applicationDetailsPublicDTO, result);
	}

	@Test
	void callForApplicationDetails_ko() {
		GetApplicationDetailsInput input = GetApplicationDetailsInput.builder()
				.applicationId(APPLICATION_ID)
				.tenant(TENANT)
				.applicationsBaseUrl(APPLICATION_BASE_URL)
				.authToken(CommonConstants.AUTH_PREFIX + AUTH_TOKEN)
				.locale(Locale.ITALIAN.getLanguage())
				.build();

		when(getApplicationDetailsCallerMock.makeCall(input))
				.thenThrow(ObjectNotFoundRuntimeException.class);

		String locale = Locale.ITALIAN.getLanguage();
		assertThrows(ObjectNotFoundRuntimeException.class, () -> applicationFacadeService.callForApplicationDetails(TENANT, APPLICATION_ID, USER, locale));
	}

//	@Test
//	void callForApplicationTransitionHistory_ok() {
//		GetApplicationTransitionHistoryInput input = GetApplicationTransitionHistoryInput.builder()
//				.applicationId(APPLICATION_ID)
//				.tenant(TENANT)
//				.applicationsBaseUrl(APPLICATION_BASE_URL)
//				.authToken(CommonConstants.AUTH_PREFIX + AUTH_TOKEN)
//				.locale(Locale.ITALIAN.getLanguage())
//				.build();
//
//		when(getApplicationTransitionHistoryCaller.makeCall(input))
//				.thenReturn(List.of(myDetailedTransitionHistory));
//
//		List<MyDetailedTransitionHistory> result = applicationFacadeService.callForApplicationTransitionHistory(TENANT, APPLICATION_ID, USER,
//				Locale.ITALIAN.getLanguage());
//
//		assertEquals(List.of(myDetailedTransitionHistory), result);
//	}

	@Test
	void callForApplicationPrintHistory_ok() {
		GetApplicationPrintHistoryInput input = GetApplicationPrintHistoryInput.builder()
				.applicationId(APPLICATION_ID)
				.tenant(TENANT)
				.applicationsBaseUrl(APPLICATION_BASE_URL)
				.authToken(CommonConstants.AUTH_PREFIX + AUTH_TOKEN)
				.locale(Locale.ITALIAN.getLanguage())
				.build();

		when(getApplicationPrintHistoryCaller.makeCall(input))
				.thenReturn(List.of(applicationGeneratedPrintDTO));

		List<ApplicationGeneratedPrintDTO> result = applicationFacadeService.callForApplicationPrintHistory(TENANT, APPLICATION_ID, USER,
				Locale.ITALIAN.getLanguage());

		assertEquals(List.of(applicationGeneratedPrintDTO), result);
	}
}
