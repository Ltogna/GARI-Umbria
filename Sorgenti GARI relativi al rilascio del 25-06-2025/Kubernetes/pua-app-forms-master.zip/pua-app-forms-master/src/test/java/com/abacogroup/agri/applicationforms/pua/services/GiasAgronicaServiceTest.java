package com.abacogroup.agri.applicationforms.pua.services;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.fail;

import java.io.IOException;
import java.io.OutputStream;
import java.net.InetSocketAddress;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import com.abacogroup.agri.applicationforms.pua.ApplicationFormsModuleConfiguration;
import com.abacogroup.agri.applicationforms.pua.core.model.dto.AgronicaResponse;
import com.abacogroup.agri.applicationforms.pua.core.model.dto.GiasTokenResponse;
import com.abacogroup.agri.applicationforms.pua.core.model.dto.OperazioniQdC;
import com.abacogroup.agri.applicationforms.pua.util.JsonUtils;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sun.net.httpserver.HttpServer;

import jakarta.ws.rs.client.Client;
import jakarta.ws.rs.client.ClientBuilder;

/**
 * 
 * @author Emanuele Crocilla
 *
 */
class GiasAgronicaServiceTest extends AbstractServiceTest {

    private static final int SERVER_PORT = 8089;
    private static HttpServer httpServer;

    private static GiasAgronicaService giasAgronicaService;

    @BeforeAll
    static void setUp() throws IOException {
    	
        // start local HTTP server
        httpServer = HttpServer.create(new InetSocketAddress(SERVER_PORT), 0);

        httpServer.start();

        //  configure service with local URL
        Client client = ClientBuilder.newClient();
        ApplicationFormsModuleConfiguration config = new ApplicationFormsModuleConfiguration();
        config.setGiasBaseUrl("http://localhost:" + SERVER_PORT + "/mock-gias-agronica");
        config.setGiasLoginToken("eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9");

        giasAgronicaService = new GiasAgronicaService(null, client, config, new ObjectMapper());
    }

    @AfterAll
    static void tearDown() {
        httpServer.stop(0);
    }
    
    @Test
    void testImportOperazioniQdC_Success() throws Exception {

    	try {
    		
    		httpServer.createContext("/mock-gias-agronica/AgronicaCoreApi/Login/BackgroundAuthentication", 
    				exchange -> {
    					GiasTokenResponse response = new GiasTokenResponse(true, "OK");
    					String respInJson = JsonUtils.convertToJson(response);
    					exchange.getResponseHeaders().add("Content-Type", "application/json");
    					exchange.sendResponseHeaders(200, respInJson.getBytes().length);
    					OutputStream os = exchange.getResponseBody();
    					os.write(respInJson.getBytes());
    					os.close();
    				});
    		
    		httpServer.createContext("/mock-gias-agronica/AgronicaCoreApi/NewAgri/Import/OperazioniQdC", 
    				exchange -> {
    					AgronicaResponse<String> response = new AgronicaResponse<>();
    					response.setDati("ok response");
    					response.setMessage("OK");
    					String respInJson = JsonUtils.convertToJson(response);
    					exchange.getResponseHeaders().add("Content-Type", "application/json");
    					exchange.sendResponseHeaders(200, respInJson.getBytes().length);
    					OutputStream os = exchange.getResponseBody();
    					os.write(respInJson.getBytes());
    					os.close();
    				});

			OperazioniQdC operations = OperazioniQdC.builder().cuaa("00000000000").dati("[{ \"tipo\" : \"attività singola\"}]").build();
			
			AgronicaResponse<String> result = giasAgronicaService.importOperazioniQdCV2(operations, AUTH_TOKEN);

    		// Asserts
    		assertNotNull(result);
    		assertTrue("ok response".equals(result.getDati()));
    		assertTrue("OK".equals(result.getMessage()));
    		 

    	} catch (Exception e) {
    		fail("ERROR IN testImportOperazioniQdC_Success", e);
    	}
    }
}
