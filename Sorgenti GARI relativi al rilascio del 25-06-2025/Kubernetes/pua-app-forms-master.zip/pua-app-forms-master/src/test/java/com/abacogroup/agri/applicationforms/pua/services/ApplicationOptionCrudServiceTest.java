package com.abacogroup.agri.applicationforms.pua.services;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.fail;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import org.jdbi.v3.sqlobject.transaction.TransactionalCallback;
import org.jdbi.v3.sqlobject.transaction.TransactionalConsumer;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.abacogroup.agri.applicationforms.pua.core.exceptions.ObjectNotFoundException;
import com.abacogroup.agri.applicationforms.pua.core.mappers.ApplicationOptionMapper;
import com.abacogroup.agri.applicationforms.pua.core.model.dto.ApplicationOptionDTO;
import com.abacogroup.agri.applicationforms.pua.db.dao.ApplicationOptionDAO;
import com.abacogroup.agri.applicationforms.pua.db.ntt.ApplicationOptionNTT;

import lombok.extern.slf4j.Slf4j;
 
@Slf4j
@ExtendWith(MockitoExtension.class)
class ApplicationOptionCrudServiceTest {

    @Mock
    private ApplicationOptionDAO applicationOptionDAO;
    @Mock
    private ApplicationOptionMapper applicationOptionMapper;

    @InjectMocks
    private ApplicationOptionCrudService applicationOptionCrudService;

    private static final String TENANT = "ADMIN";
    private static final Long PKID = 1L;

    private static final Long OPTION_CONFIG_ID = 2L;
    private static final Long APPLICATION_ID = 3L;
    private final LocalDateTime NOW = LocalDateTime.now();
    private static final LocalDateTime DT_DELETE = LocalDateTime.MAX;
    private static final String USERNAME = "ADMIN";
    private static final String OPTION_CODE = "Option code";
    private static final Long TAKEOVER_ID = 123L;

    private final ApplicationOptionNTT applicationOptionNTT = ApplicationOptionNTT.builder()
            .pkid(PKID)
            .application_id(APPLICATION_ID)
            .option_config_id(OPTION_CONFIG_ID)
            .dt_insert(NOW)
            .dt_delete(DT_DELETE)
            .user_id_insert(USERNAME)
            .build();

    private final ApplicationOptionDTO applicationOptionDTO = ApplicationOptionDTO.builder()
            .pkid(PKID)
            .applicationId(APPLICATION_ID)
            .optionConfigId(OPTION_CONFIG_ID)
            .dtInsert(NOW)
            .dtDelete(DT_DELETE)
            .userIdInsert(USERNAME)
            .build();

    @Test
    void findById_ok() {
        when(applicationOptionDAO.findById(PKID))
                .thenReturn(List.of(applicationOptionNTT));

        when(applicationOptionMapper.entityToDto(applicationOptionNTT))
                .thenReturn(applicationOptionDTO);

        ApplicationOptionDTO result = null;
        try {
            result = applicationOptionCrudService.findById(PKID);
        } catch (ObjectNotFoundException e) {
            fail(e.getMessage(), e);
        }

        assertEquals(applicationOptionDTO, result);
    }

    @Test
    void findByApplicationId_ok() {
        when(applicationOptionDAO.findByApplicationId(TENANT, APPLICATION_ID))
                .thenReturn(List.of(applicationOptionNTT));
        when(applicationOptionMapper.entityToDto(applicationOptionNTT))
                .thenReturn(applicationOptionDTO);

        List<ApplicationOptionDTO> result = applicationOptionCrudService.findByApplicationId(TENANT, APPLICATION_ID);

        assertEquals(List.of(applicationOptionDTO), result);
    }

    @Test
    void findExpiredByApplicationId_ok() {
        when(applicationOptionDAO.findExpiredByApplicationId(APPLICATION_ID))
                .thenReturn(List.of(applicationOptionNTT));
        when(applicationOptionMapper.entityToDto(applicationOptionNTT))
                .thenReturn(applicationOptionDTO);

        List<ApplicationOptionDTO> result = applicationOptionCrudService.findExpiredByApplicationId(APPLICATION_ID);

        assertEquals(List.of(applicationOptionDTO), result);
    }

    @Test
    void findByApplicationIdAndTakeoverId_ok() {
        when(applicationOptionDAO.findByApplicationIdAndTakeoverId(TENANT, APPLICATION_ID, TAKEOVER_ID))
                .thenReturn(List.of(applicationOptionNTT));
        when(applicationOptionMapper.entityToDto(applicationOptionNTT))
                .thenReturn(applicationOptionDTO);

        List<ApplicationOptionDTO> result =
                applicationOptionCrudService.findByApplicationIdAndTakeoverId(TENANT, APPLICATION_ID, TAKEOVER_ID);

        assertEquals(List.of(applicationOptionDTO), result);
    }

    @Test
    void findByApplicationIdAndOptionCode_ok() {
        when(applicationOptionDAO.findByApplicationIdOptionCode(TENANT, APPLICATION_ID, OPTION_CODE))
                .thenReturn(List.of(applicationOptionNTT));
        when(applicationOptionMapper.entityToDto(applicationOptionNTT))
                .thenReturn(applicationOptionDTO);

        ApplicationOptionDTO result =
                applicationOptionCrudService.findByApplicationIdAndOptionCode(TENANT, APPLICATION_ID, OPTION_CODE);

        assertEquals(applicationOptionDTO, result);
    }

    @SuppressWarnings({"rawtypes", "unchecked"})
    @Test
    void update_ok() {
        ApplicationOptionDTO in = ApplicationOptionDTO.builder()
                .optionConfigId(OPTION_CONFIG_ID)
                .build();

        try {
            ArgumentCaptor<TransactionalCallback> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(TransactionalCallback.class);

            when(applicationOptionDAO.getCurrentTimestamp()).thenReturn(NOW);
            when(applicationOptionDAO.inTransaction(handleConsumerLambdaCaptor.capture()))
                    .thenReturn(applicationOptionDTO);

            applicationOptionCrudService.update(PKID, in, USERNAME);

            verify(applicationOptionDAO).inTransaction(handleConsumerLambdaCaptor.capture());

            handleConsumerLambdaCaptor.getValue().inTransaction(applicationOptionDAO);

            ApplicationOptionDTO result = applicationOptionCrudService.update(PKID, in, USERNAME);

            assertEquals(applicationOptionDTO, result);
        } catch (Exception e) {
            fail(e.getMessage(), e);
        }

    }

    @Test
    void findByApplicationIdAndOptionCodes_ok() {
        when(applicationOptionDAO.findByApplicationIdOptionCodes(TENANT, APPLICATION_ID, List.of(OPTION_CODE)))
                .thenReturn(List.of(applicationOptionNTT));
        when(applicationOptionMapper.entityToDto(applicationOptionNTT))
                .thenReturn(applicationOptionDTO);

        List<ApplicationOptionDTO> result =
                applicationOptionCrudService.findByApplicationIdAndOptionCodes(TENANT, APPLICATION_ID, List.of(OPTION_CODE));

        assertEquals(List.of(applicationOptionDTO), result);
    }

    @Test
    void findByApplicationIdAndOptionCodes_emptyList_ok() {
                assertEquals(List.of(), applicationOptionCrudService.findByApplicationIdAndOptionCodes(TENANT, APPLICATION_ID, null));
                assertEquals(List.of(), applicationOptionCrudService.findByApplicationIdAndOptionCodes(TENANT, APPLICATION_ID, List.of()));
    }

    @Test
    void logicallyDeleteByOptionConfigId_ok() {
        when(applicationOptionDAO.getCurrentTimestamp())
                .thenReturn(NOW);

        applicationOptionCrudService.logicallyDeleteByOptionConfigId(TENANT, APPLICATION_ID, OPTION_CONFIG_ID, USERNAME);

        verify(applicationOptionDAO, times(1)).logicallyDeleteOptionConfigId(TENANT, APPLICATION_ID, OPTION_CONFIG_ID, USERNAME, NOW);
    }

    @Test
    void bulkDeleteByApplicationId_ok() {
        applicationOptionCrudService.bulkDeleteByApplicationId(TENANT, APPLICATION_ID, USERNAME);

        verify(applicationOptionDAO, times(1)).bulkLogicallyDeleteByApplicationId(TENANT, APPLICATION_ID, USERNAME);
    }

    @Test
    void deleteByApplicationIdExcludeOptionConfigIds_ok() {
        applicationOptionCrudService.deleteByApplicationIdExcludeOptionConfigIds(TENANT, APPLICATION_ID, USERNAME, List.of(OPTION_CONFIG_ID));

        verify(applicationOptionDAO, times(1)).logicallyDeleteByApplicationIdExcludeOptionConfigIds(TENANT, APPLICATION_ID, USERNAME, List.of(OPTION_CONFIG_ID));
    }

    @Test
    void findByApplicationIdAndOptionConfigId_ok() {
        when(applicationOptionDAO.findByApplicationIdOptionConfigId(TENANT, APPLICATION_ID, OPTION_CONFIG_ID))
                .thenReturn(List.of(applicationOptionNTT));
        when(applicationOptionMapper.entityToDto(applicationOptionNTT))
                .thenReturn(applicationOptionDTO);

        List<ApplicationOptionDTO> result =
                applicationOptionCrudService.findByApplicationIdAndOptionConfigId(TENANT, APPLICATION_ID, OPTION_CONFIG_ID);

        assertEquals(List.of(applicationOptionDTO), result);
    }

    @SuppressWarnings({"rawtypes", "unchecked"})
    @Test
    void insert_ok() {
        ApplicationOptionDTO in = ApplicationOptionDTO.builder()
                .optionConfigId(OPTION_CONFIG_ID)
                .build();
        try {
            ArgumentCaptor<TransactionalCallback> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(TransactionalCallback.class);

            when(applicationOptionDAO.findById(any()))
                    .thenReturn(List.of(applicationOptionNTT));
            when(applicationOptionMapper.dtoToEntity(in))
                    .thenReturn(applicationOptionNTT);
            when(applicationOptionMapper.entityToDto(applicationOptionNTT))
                    .thenReturn(applicationOptionDTO);
            when(applicationOptionDAO.getCurrentTimestamp()).thenReturn(NOW);

            applicationOptionCrudService.insert(in, USERNAME);

            verify(applicationOptionDAO).inTransaction(handleConsumerLambdaCaptor.capture());

            ApplicationOptionDTO result = (ApplicationOptionDTO) handleConsumerLambdaCaptor.getValue().inTransaction(applicationOptionDAO);

            assertEquals(applicationOptionDTO, result);
        } catch (Exception e) {
            fail(e.getMessage(), e);
        }
    }

    @SuppressWarnings({"rawtypes", "unchecked"})
    @Test
    void test_delete() {
        try {
            ArgumentCaptor<TransactionalConsumer> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(TransactionalConsumer.class);
            when(applicationOptionDAO.getCurrentTimestamp()).thenReturn(NOW);

            applicationOptionCrudService.delete(APPLICATION_ID, USERNAME);

            verify(applicationOptionDAO).useTransaction(handleConsumerLambdaCaptor.capture());
            handleConsumerLambdaCaptor.getValue().useTransaction(applicationOptionDAO);
            verify(applicationOptionDAO).logicallyDeleteById(eq(APPLICATION_ID), eq(USERNAME), any());
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            fail(e.getMessage(), e);
        }
    }

    @Test
    void deleteByOptionConfigId_ok() {
        applicationOptionCrudService.deleteByOptionConfigId(OPTION_CONFIG_ID);

        verify(applicationOptionDAO, times(1)).deleteByOptionConfigId(OPTION_CONFIG_ID);
    }

    @Test
    void deleteByTakeoverIdAndOptionConfigId_ok() {
        when(applicationOptionDAO.getCurrentTimestamp())
                .thenReturn(NOW);

        applicationOptionCrudService.deleteByTakeoverIdAndOptionConfigId(TENANT, APPLICATION_ID, TAKEOVER_ID, OPTION_CONFIG_ID, USERNAME);

        verify(applicationOptionDAO, times(1))
                .logicallyDeleteByTakeoverIdAndOptionConfigId(TENANT, APPLICATION_ID, TAKEOVER_ID, OPTION_CONFIG_ID, USERNAME, NOW);
    }

    @Test
    void retrieveCustomKeyByResultSet_ok() {
        assertNull(applicationOptionCrudService.retrieveCustomKeyByResultSet(applicationOptionNTT));
    }

    @Test
    void findRsByCustomKey_ok() {
        Optional<ApplicationOptionNTT> result = applicationOptionCrudService.findRsByCustomKey(null);

        assertEquals(Optional.empty(), result);
    }
}
