package com.abacogroup.agri.applicationforms.pua.services;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.fail;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doAnswer;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.List;
import java.util.Locale;
import java.util.function.Supplier;

import org.jdbi.v3.sqlobject.transaction.TransactionalCallback;
import org.jdbi.v3.sqlobject.transaction.TransactionalConsumer;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.abacogroup.agri.applicationforms.pua.core.exceptions.AttachmentNotFoundRuntimeException;
import com.abacogroup.agri.applicationforms.pua.core.mappers.AttachmentMapper;
import com.abacogroup.agri.applicationforms.pua.core.model.dto.AttachmentDTO;
import com.abacogroup.agri.applicationforms.pua.db.dao.AttachmentDAO;
import com.abacogroup.agri.applicationforms.pua.db.ntt.AttachmentNTT;
import com.abacogroup.agri.applicationforms.pua.services.common.crud.AttachmentsCrudService;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.jdbi.paging.impl.InfiniteListResultsImpl;

@ExtendWith(MockitoExtension.class)
class AttachmentsCrudServiceTest extends AbstractServiceTest {
    @Mock
    private AttachmentDAO attachmentDAOMock;
    @Mock
    private AttachmentMapper attachmentMapperMock;

    @InjectMocks
    private AttachmentsCrudService attachmentsCrudService;

    private final AttachmentNTT attachmentNTT = AttachmentNTT.builder()
            .attachment_id(ATTACHMENT_ID)
            .application_id(APPLICATION_ID)
            .tenant_id(TENANT)
            .pkid(PKID)
            .bucket_id(BUCKET_ID)
            .notes(NOTES)
            .file_name(FILE_NAME)
            .type(TYPE)
            .type_attachment_code(TYPE_ATTACHMENT_CODE)
            .type_attachment_group_code(TYPE_ATTACHMENT_GROUP_CODE)
            .type_code(TYPE_CODE)
            .type_id(TYPE_ID)
            .build();
    private final AttachmentDTO attachmentDTO = AttachmentDTO.builder()
            .attachmentId(ATTACHMENT_ID)
            .applicationId(APPLICATION_ID)
            .type(TYPE)
            .fileName(FILE_NAME)
            .tenantId(TENANT)
            .typeAttachmentCode(TYPE_ATTACHMENT_CODE)
            .typeAttachmentGroupCode(TYPE_ATTACHMENT_GROUP_CODE)
            .bucketId(BUCKET_ID)
            .typeId(TYPE_ID)
            .pkid(PKID)
            .build();

    @Test
    void findById_ok() {
        try {
            when(attachmentDAOMock.findById(PKID))
                    .thenReturn(List.of(attachmentNTT));
            when(attachmentMapperMock.entityToDto(attachmentNTT))
                    .thenReturn(attachmentDTO);

            AttachmentDTO result = attachmentsCrudService.findById(PKID);

            assertEquals(attachmentDTO, result);
        } catch (Exception e) {
            fail(e.getMessage(), e);
        }
    }

    @Test
    void findByAttachmentId_ok() {
        when(attachmentDAOMock.findByAttachmentId(TENANT, APPLICATION_ID, ATTACHMENT_ID, Locale.ITALIAN.getLanguage()))
                .thenReturn(attachmentNTT);
        when(attachmentMapperMock.entityToDto(attachmentNTT))
                .thenReturn(attachmentDTO);

        AttachmentDTO result = attachmentsCrudService.findByAttachmentId(TENANT, APPLICATION_ID, ATTACHMENT_ID);

        assertEquals(attachmentDTO, result);
    }

    @Test
    void findByAttachmentId_ko() {
        when(attachmentDAOMock.findByAttachmentId(TENANT, APPLICATION_ID, ATTACHMENT_ID, Locale.ITALIAN.getLanguage()))
                .thenReturn(null);

        assertThrows(AttachmentNotFoundRuntimeException.class, () ->
                attachmentsCrudService.findByAttachmentId(TENANT, APPLICATION_ID, ATTACHMENT_ID));
    }

    @Test
    void findByApplicationId_ok() {
        doAnswer(ans -> {
            Supplier<InfiniteListResults<AttachmentNTT>> supplier = ans.getArgument(0);
            supplier.get();

            return new InfiniteListResultsImpl<>(List.of(attachmentNTT), NEXT_KEY);
        }).when(attachmentDAOMock).infinite(any(), eq(NEXT_KEY), eq(PagingParamsFactory.DEFAULT_PAGE_SIZE));
        when(attachmentMapperMock.entityToDto(attachmentNTT))
                .thenReturn(attachmentDTO);

        InfiniteListResults<AttachmentDTO> result = attachmentsCrudService.findByApplicationId(TENANT, APPLICATION_ID, NEXT_KEY);

        assertEquals(List.of(attachmentDTO), result.getRecords());
    }

    @Test
    void findByApplicationIdAndAttachmentGroup_ok() {
        doAnswer(ans -> {
            Supplier<InfiniteListResults<AttachmentNTT>> supplier = ans.getArgument(0);
            supplier.get();

            return new InfiniteListResultsImpl<>(List.of(attachmentNTT), NEXT_KEY);
        }).when(attachmentDAOMock).infinite(any(), eq(NEXT_KEY), eq(PagingParamsFactory.DEFAULT_PAGE_SIZE));
        when(attachmentMapperMock.entityToDto(attachmentNTT))
                .thenReturn(attachmentDTO);

        InfiniteListResults<AttachmentDTO> result =
                attachmentsCrudService.findByApplicationIdAndAttachmentGroup(TENANT, APPLICATION_ID, ATTACHMENT_ID, NEXT_KEY);

        assertEquals(List.of(attachmentDTO), result.getRecords());
    }

    @Test
    void findListByApplicationIdAndAttachmentGroup_ok() {
        when(attachmentDAOMock.findListByApplicationId(TENANT, APPLICATION_ID, ATTACHMENT_ID, Locale.ITALIAN.getLanguage()))
                .thenReturn(List.of(attachmentNTT));
        when(attachmentMapperMock.entityToDto(attachmentNTT))
                .thenReturn(attachmentDTO);

        List<AttachmentDTO> result = attachmentsCrudService.findListByApplicationIdAndAttachmentGroup(TENANT, APPLICATION_ID, ATTACHMENT_ID);

        assertEquals(List.of(attachmentDTO), result);
    }


    @SuppressWarnings({"rawtypes", "unchecked"})
    @Test
    void insert_ok() {
        AttachmentDTO in = AttachmentDTO.builder()
                .typeId(TYPE_ID)
                .bucketId(BUCKET_ID)
                .fileName(FILE_NAME)
                .notes(NOTES)
                .build();

        try {
            ArgumentCaptor<TransactionalCallback> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(TransactionalCallback.class);

            when(attachmentDAOMock.findById(any()))
                    .thenReturn(List.of(attachmentNTT));
            when(attachmentMapperMock.dtoToEntity(in))
                    .thenReturn(attachmentNTT);
            when(attachmentMapperMock.entityToDto(attachmentNTT))
                    .thenReturn(attachmentDTO);
            when(attachmentDAOMock.getCurrentTimestamp()).thenReturn(DT_INSERT);

            attachmentsCrudService.insert(in, USERNAME);

            verify(attachmentDAOMock).inTransaction(handleConsumerLambdaCaptor.capture());

            AttachmentDTO result = (AttachmentDTO) handleConsumerLambdaCaptor.getValue().inTransaction(attachmentDAOMock);

            assertEquals(attachmentDTO, result);
        } catch (Exception e) {
            fail(e.getMessage(), e);
        }
    }


    @SuppressWarnings({"rawtypes", "unchecked"})
    @Test
    void update_ok() {
        AttachmentDTO in = AttachmentDTO.builder()
                .typeId(TYPE_ID)
                .bucketId(BUCKET_ID)
                .fileName(FILE_NAME)
                .notes(NOTES)
                .build();

        try {
            ArgumentCaptor<TransactionalCallback> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(TransactionalCallback.class);

            when(attachmentDAOMock.getCurrentTimestamp()).thenReturn(DT_INSERT);
            when(attachmentDAOMock.inTransaction(handleConsumerLambdaCaptor.capture()))
                    .thenReturn(attachmentDTO);

            attachmentsCrudService.update(PKID, in, USERNAME);

            verify(attachmentDAOMock).inTransaction(handleConsumerLambdaCaptor.capture());

            AttachmentDTO result = (AttachmentDTO) handleConsumerLambdaCaptor.getValue().inTransaction(attachmentDAOMock);

            assertEquals(attachmentDTO, result);
        } catch (Exception e) {
            fail(e.getMessage(), e);
        }
    }


    @SuppressWarnings({"rawtypes", "unchecked"})
    @Test
    void delete_ok() {
        try {
            ArgumentCaptor<TransactionalConsumer> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(TransactionalConsumer.class);

            when(attachmentDAOMock.getCurrentTimestamp())
                    .thenReturn(DT_INSERT);

            attachmentsCrudService.delete(PKID, USERNAME);

            verify(attachmentDAOMock).useTransaction(handleConsumerLambdaCaptor.capture());

            handleConsumerLambdaCaptor.getValue().useTransaction(attachmentDAOMock);

            verify(attachmentDAOMock).logicallyDeleteById(PKID, USERNAME, DT_INSERT);
        } catch (Exception e) {
            fail(e.getMessage(), e);
        }
    }

//    @Test
//    void retrieveCustomKeyByResultSet_ok() {
//        assertThrows(NotImplementedException.class, () ->
//                attachmentsCrudService.retrieveCustomKeyByResultSet(attachmentNTT));
//    }
//
//    @Test
//    void adjustR_ok() {
//        try {
//            AttachmentNTT result = attachmentsCrudService.adjustR(attachmentNTT);
//
//            assertEquals(attachmentNTT, result);
//        } catch (Exception e) {
//            fail(e.getMessage(), e);
//        }
//    }
//
//    @Test
//    void findRsByCustomKey_ok() {
//        Optional<AttachmentNTT> result = attachmentsCrudService.findRsByCustomKey(null);
//
//        assertEquals(Optional.empty(), result);
//    }
}
