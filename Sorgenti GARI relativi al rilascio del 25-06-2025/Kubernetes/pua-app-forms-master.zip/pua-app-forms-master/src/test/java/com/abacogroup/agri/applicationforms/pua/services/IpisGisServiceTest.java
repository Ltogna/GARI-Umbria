package com.abacogroup.agri.applicationforms.pua.services;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.fail;

import java.io.IOException;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.util.Collections;
import java.util.List;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import com.abacogroup.agri.applicationforms.pua.ApplicationFormsModuleConfiguration;
import com.abacogroup.agri.applicationforms.pua.core.model.dto.LandUseCodesDTO;
import com.abacogroup.agri.applicationforms.pua.core.model.dto.LandUseCodesDTO.LandUseCode;
import com.abacogroup.agri.applicationforms.pua.core.model.dto.LandUseCodesRequest;
import com.abacogroup.agri.applicationforms.pua.core.model.dto.RecordResponse;
import com.abacogroup.agri.applicationforms.pua.core.model.dto.SectorDTO;
import com.abacogroup.agri.applicationforms.pua.core.model.dto.SectorRequest;
import com.abacogroup.agri.applicationforms.pua.util.GenericUtility;
import com.abacogroup.agri.applicationforms.pua.util.JsonUtils;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sun.net.httpserver.HttpServer;

import jakarta.ws.rs.client.Client;
import jakarta.ws.rs.client.ClientBuilder;

/**
 * 
 * @author Emanuele Crocilla
 *
 */
class IpisGisServiceTest extends AbstractServiceTest {

    private static final int SERVER_PORT = 8089;
    private static HttpServer httpServer;

    private static IpisGisService ipisGisService;

    @BeforeAll
    static void setUp() throws IOException {
    	
        // start local HTTP server
        httpServer = HttpServer.create(new InetSocketAddress(SERVER_PORT), 0);

        httpServer.start();

        //  configure service with local URL
        Client client = ClientBuilder.newClient();
        ApplicationFormsModuleConfiguration config = new ApplicationFormsModuleConfiguration();
        config.setLpisServerUrl("http://localhost:" + SERVER_PORT + "/mock-ipis-gis");

        ipisGisService = new IpisGisService(null, client, config, new ObjectMapper());
    }

    @AfterAll
    static void tearDown() {
        httpServer.stop(0);
    }
    
    @Test
    void testGetSectors_Success() throws Exception {

    	try {
    		httpServer.createContext("/mock-ipis-gis/" + TENANT + "/public/v1/lpis/sectors", 
    				exchange -> {
    					String json = GenericUtility.convertInputStreamToString( exchange.getRequestBody());
    					String code = ((List<String>) JsonUtils.extractField(json, "codes", null)).get(0);
    					SectorDTO dto = SectorDTO.builder().id(12345).description("test_description").sectorCode(code).build();
    					RecordResponse<SectorDTO> recordResponse = new RecordResponse<>();
    					recordResponse.setCount(1);
    					recordResponse.setRecords(Collections.singletonList(dto));
    					String response = JsonUtils.convertToJson(recordResponse);
    					exchange.getResponseHeaders().add("Content-Type", "application/json");
    					exchange.sendResponseHeaders(200, response.getBytes().length);
    					OutputStream os = exchange.getResponseBody();
    					os.write(response.getBytes());
    					os.close();
    				});

    		SectorRequest sectorRequest = SectorRequest.builder()
    				.codes(Collections.singletonList(SECTOR_CODE))
    				.filter("")
    				.nextKey("1")
    				.build();

    		RecordResponse<SectorDTO> result = ipisGisService.getSectors(USER, TENANT, sectorRequest);

    		// Asserts
    		assertNotNull(result);
    		//        assertEquals(1, result.getCount());  TODO capire perche' arriva zero anziche' uno
    		assertEquals(SECTOR_CODE, result.getRecords().get(0).getSectorCode());
    		assertEquals("test_description", result.getRecords().get(0).getDescription());
    		assertEquals(12345, result.getRecords().get(0).getId());

    	} catch (Exception e) {
    		fail("ERROR IN testGetLandusesCodesSuccess", e);
    	}
    }

    @Test
    void testGetLandusesCodesSuccess() {

    	try {
    		httpServer.createContext("/mock-ipis-gis/" + TENANT + "/public/v1/lpis/support/landuses-codes", 
    				exchange -> {
    					String json = GenericUtility.convertInputStreamToString( exchange.getRequestBody());
    					String code = ((List<String>) JsonUtils.extractField(json, "landuse_codes", null)).get(0);
    					LandUseCode landUseCode = LandUseCode.builder().description("test_description").landUsesCode(code).build();
    					LandUseCodesDTO dto = LandUseCodesDTO.builder().landUsesCodesList(Collections.singletonList(landUseCode)).build();
    					String response = JsonUtils.convertToJson(dto);
    					exchange.getResponseHeaders().add("Content-Type", "application/json");
    					exchange.sendResponseHeaders(200, response.getBytes().length);
    					OutputStream os = exchange.getResponseBody();
    					os.write(response.getBytes());
    					os.close();
    				});

    		LandUseCodesRequest request = LandUseCodesRequest.builder()
    				.landuseCodes(Collections.singletonList(LANDUSE_CODE))
    				.build();

    		LandUseCodesDTO result = ipisGisService.getLandusesCodes(USER, TENANT, request);

    		// Asserts
    		assertNotNull(result);
    		//	        assertEquals(1, result.getCount());  TODO capire perche' arriva zero anziche' uno
    		assertEquals(LANDUSE_CODE, result.getLandUsesCodesList().get(0).getLandUsesCode());
    		assertEquals("test_description", result.getLandUsesCodesList().get(0).getDescription());
    		
    	} catch (Exception e) {
    		fail("ERROR IN testGetLandusesCodesSuccess", e);
    	}
    }

    @Test
    void testValidateSectorsSuccess() {
    	
    	httpServer.createContext("/mock-ipis-gis/" + TENANT + "/public/v1/lpis/sectors", 
        		exchange -> {
        			String json = GenericUtility.convertInputStreamToString( exchange.getRequestBody());
        			String code = ((List<String>) JsonUtils.extractField(json, "codes", null)).get(0);
        			SectorDTO dto = SectorDTO.builder().id(12345).description("test_description").sectorCode(code).build();
        			RecordResponse<SectorDTO> recordResponse = new RecordResponse<>();
        			recordResponse.setCount(1);
        			recordResponse.setRecords(Collections.singletonList(dto));
                    String response = JsonUtils.convertToJson(recordResponse);
                    exchange.getResponseHeaders().add("Content-Type", "application/json");
                    exchange.sendResponseHeaders(200, response.getBytes().length);
                    OutputStream os = exchange.getResponseBody();
                    os.write(response.getBytes());
                    os.close();
        		});

            try {
				
            	ipisGisService.validateSectorCode(USER, TENANT, SECTOR_CODE);
            	
			} catch (Exception e) {
				
				fail("ERROR IN testValidateSectorCodeSuccess", e);
			}
    }

    @Test
    void testValidateLandUseCodeSuccess() {
    	
    	httpServer.createContext("/mock-ipis-gis/" + TENANT + "/public/v1/lpis/support/landuses-codes", 
        		exchange -> {
        			String json = GenericUtility.convertInputStreamToString( exchange.getRequestBody());
        			String code = ((List<String>) JsonUtils.extractField(json, "landuse_codes", null)).get(0);
        			LandUseCode landUseCode = LandUseCode.builder().description("test_description").landUsesCode(code).build();
        			LandUseCodesDTO dto = LandUseCodesDTO.builder().landUsesCodesList(Collections.singletonList(landUseCode)).build();
                    String response = JsonUtils.convertToJson(dto);
                    exchange.getResponseHeaders().add("Content-Type", "application/json");
                    exchange.sendResponseHeaders(200, response.getBytes().length);
                    OutputStream os = exchange.getResponseBody();
                    os.write(response.getBytes());
                    os.close();
        		});

            try {
				
            	ipisGisService.validateLandUseCode(USER, TENANT, LANDUSE_CODE);
            	
			} catch (Exception e) {
				
				fail("ERROR IN testValidateLandUseCodeSuccess", e);
			}

            
    }
}
