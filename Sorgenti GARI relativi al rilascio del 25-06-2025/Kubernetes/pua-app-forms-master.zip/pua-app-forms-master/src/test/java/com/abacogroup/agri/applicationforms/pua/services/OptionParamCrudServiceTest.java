package com.abacogroup.agri.applicationforms.pua.services;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.fail;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.List;
import java.util.Optional;

import org.jdbi.v3.sqlobject.transaction.TransactionalCallback;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.abacogroup.agri.applicationforms.pua.core.exceptions.ObjectNotFoundRuntimeException;
import com.abacogroup.agri.applicationforms.pua.core.mappers.OptionParamMapper;
import com.abacogroup.agri.applicationforms.pua.core.model.dto.OptionParamDTO;
import com.abacogroup.agri.applicationforms.pua.db.dao.OptionParamDAO;
import com.abacogroup.agri.applicationforms.pua.db.keys.OptionParamKey;
import com.abacogroup.agri.applicationforms.pua.db.ntt.OptionParamNTT;

import lombok.extern.slf4j.Slf4j;


@Slf4j
@ExtendWith(MockitoExtension.class)
class OptionParamCrudServiceTest extends AbstractServiceTest {

    @Mock
    private OptionParamDAO optionParamDAO;
    @Mock
    private OptionParamMapper optionParamMapper;

    @InjectMocks
    private OptionParamCrudService optionParamCrudService;

    private final OptionParamKey optionParamKey = OptionParamKey
            .builder()
            .optionConfigId(OPTION_CONFIG_ID_1)
            .attributeName(ATTRIBUTE_NAME_1)
            .build();

    private final OptionParamNTT optionParamNTT = OptionParamNTT.builder()
            .option_config_id(OPTION_CONFIG_ID_1)
            .attribute_name(ATTRIBUTE_NAME_1)
            .attribute_value(ATTRIBUTE_VALUE_1)
            .build();

    private final OptionParamDTO optionParamDTO = OptionParamDTO.builder()
            .optionConfigId(OPTION_CONFIG_ID_1)
            .attributeName(ATTRIBUTE_NAME_1)
            .attributeValue(ATTRIBUTE_VALUE_1)
            .build();

    @Test
    void findById_ok() {
        when(optionParamDAO.findByIdAndTenant(TENANT, optionParamKey))
                .thenReturn(List.of(optionParamNTT));

        when(optionParamMapper.entityToDto(optionParamNTT))
                .thenReturn(optionParamDTO);

        OptionParamDTO result = optionParamCrudService.findById(TENANT, optionParamKey);

        assertEquals(optionParamDTO, result);
    }

    @Test
    void findOptById_ok() {
        when(optionParamDAO.findByIdAndTenant(TENANT, optionParamKey))
                .thenReturn(List.of(optionParamNTT));

        when(optionParamMapper.entityToDto(optionParamNTT))
                .thenReturn(optionParamDTO);

        Optional<OptionParamDTO> result = optionParamCrudService.findOptById(TENANT, optionParamKey);

        assertEquals(Optional.of(optionParamDTO), result);
    }

    @Test
    void findByIdAndParamName_ok() {
        when(optionParamDAO.findByIdLike(optionParamKey))
                .thenReturn(List.of(optionParamNTT));

        when(optionParamMapper.entityToDto(optionParamNTT))
                .thenReturn(optionParamDTO);

        List<OptionParamDTO> result = optionParamCrudService.findByIdAndParamName(optionParamKey);

        assertEquals(List.of(optionParamDTO), result);
    }

    @Test
    void findByOptionConfigId_ok() {
        when(optionParamDAO.findByOptionConfigId(TENANT, OPTION_CONFIG_ID_1))
                .thenReturn(List.of(optionParamNTT));

        when(optionParamMapper.entityToDto(optionParamNTT))
                .thenReturn(optionParamDTO);

        OptionParamDTO result = optionParamCrudService.findByOptionConfigId(TENANT, OPTION_CONFIG_ID_1).get(0);

        assertEquals(optionParamDTO, result);
    }

    @Test
    void findByOptionConfigIds_ok() {
        when(optionParamDAO.findByOptionConfigIds(TENANT, List.of(OPTION_CONFIG_ID_1, OPTION_CONFIG_ID_2)))
                .thenReturn(List.of(optionParamNTT));
        when(optionParamMapper.entityToDto(optionParamNTT))
                .thenReturn(optionParamDTO);

        List<OptionParamDTO> result = optionParamCrudService.findByOptionConfigIds(TENANT, List.of(OPTION_CONFIG_ID_1, OPTION_CONFIG_ID_2));

        assertEquals(List.of(optionParamDTO), result);
    }

    @SuppressWarnings({"rawtypes", "unchecked"})
    @Test
    void insert_ok() {
        OptionParamDTO in = OptionParamDTO.builder()
                .optionConfigId(OPTION_CONFIG_ID_1)
                .attributeName(ATTRIBUTE_NAME_1)
                .attributeValue(ATTRIBUTE_VALUE_1)
                .build();

        try {
            ArgumentCaptor<TransactionalCallback> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(TransactionalCallback.class);

            when(optionParamDAO.findById(any()))
                    .thenReturn(List.of(optionParamNTT));
            when(optionParamMapper.dtoToEntity(in))
                    .thenReturn(optionParamNTT);
            when(optionParamMapper.entityToDto(optionParamNTT))
                    .thenReturn(optionParamDTO);

            optionParamCrudService.insert(in);

            verify(optionParamDAO).inTransaction(handleConsumerLambdaCaptor.capture());

            OptionParamDTO result = (OptionParamDTO) handleConsumerLambdaCaptor.getValue().inTransaction(optionParamDAO);

            assertEquals(optionParamDTO, result);
        } catch (Exception e) {
            fail(e.getMessage(), e);
        }
    }

    @SuppressWarnings({"unchecked", "rawtypes"})
    @Test
    void test_update() {
        try {
            ArgumentCaptor<TransactionalCallback> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(TransactionalCallback.class);

            when(optionParamDAO.findById(optionParamKey)).thenReturn(List.of(optionParamNTT));
            when(optionParamMapper.dtoToEntity(optionParamDTO))
                    .thenReturn(optionParamNTT);
            when(optionParamMapper.entityToDto(optionParamNTT))
                    .thenReturn(optionParamDTO);

            optionParamCrudService.update(optionParamKey, optionParamDTO);

            verify(optionParamDAO).inTransaction(handleConsumerLambdaCaptor.capture());

            handleConsumerLambdaCaptor.getValue().inTransaction(optionParamDAO);

            Optional<OptionParamNTT> actual = optionParamDAO.findById(optionParamKey).stream().findFirst();

            assertTrue(actual.isPresent());
            assertEquals(optionParamDTO.getOptionConfigId(), actual.get().getOption_config_id());
            assertEquals(optionParamDTO.getAttributeName(), actual.get().getAttribute_name());
            assertEquals(optionParamDTO.getAttributeValue(), actual.get().getAttribute_value());
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            fail(e.getMessage(), e);
        }
    }

    @Test
    void deleteByOptionConfigId_ok() {
        optionParamCrudService.deleteByOptionConfigId(optionParamKey);

        verify(optionParamDAO, times(1)).deleteByOptionConfigId(optionParamKey);
    }

    @Test
    void findRsByCustomKey_ok() {
        Optional<OptionParamNTT> result = optionParamCrudService.findRsByCustomKey(null);

        assertEquals(Optional.empty(), result);
    }

    @Test
    void deleteByCustomKey_ok() {
        optionParamCrudService.deleteByCustomKey(optionParamKey);

        verify(optionParamDAO, times(1)).deleteById(optionParamKey);
    }

    @Test
    void setCustomSearchKey_ok() {
        OptionParamNTT rs = OptionParamNTT.builder()
                .option_config_id(OPTION_CONFIG_ID_2)
                .attribute_name(ATTRIBUTE_NAME_2)
                .attribute_value(ATTRIBUTE_VALUE_2)
                .build();

        optionParamCrudService.setCustomSearchKey(rs, optionParamKey);

        assertEquals(rs.getOption_config_id(), optionParamKey.getOptionConfigId());
        assertEquals(rs.getAttribute_name(), optionParamKey.getAttributeName());
    }

    @Test
    void findById_ko() {
        when(optionParamDAO.findByIdAndTenant(TENANT, optionParamKey))
                .thenReturn(List.of());

        assertThrows(ObjectNotFoundRuntimeException.class, () -> optionParamCrudService.findById(TENANT, optionParamKey));
    }

}
