package com.abacogroup.agri.applicationforms.pua.services;

import com.abacogroup.agri.applicationforms.pua.core.mappers.DeclarationsOnSectorsMapper;
import com.abacogroup.agri.applicationforms.pua.core.model.dto.DeclarationsOnSectorsDTO;
import com.abacogroup.agri.applicationforms.pua.db.dao.DeclarationsOnSectorsDAO;
import com.abacogroup.agri.applicationforms.pua.db.ntt.DeclarationsOnSectorsNTT;
import com.abacogroup.agri.applicationforms.pua.services.common.ApplicationFacadeService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.OffsetDateTime;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

/**
 * @author Emanuele Crocilla
 */
@ExtendWith(MockitoExtension.class)
class DeclarationsOnSectorsServiceTest extends AbstractServiceTest {

	@Mock
	private DeclarationsOnSectorsDAO declarationsOnSectorsDAO;

	@Mock
	private DeclarationsOnSectorsMapper mapper;

	@InjectMocks
	private DeclarationsOnSectorsService declarationsOnSectorsService;

	@Mock
	private ApplicationFacadeService applicationFacadeService;

	// Test: Insert
	@Test
	void testInsertSuccess() {

		DeclarationsOnSectorsDTO dto = DeclarationsOnSectorsDTO.builder()
				.applicationId(APPLICATION_ID)
				.sectorCode(SECTOR_CODE)
				.landUseCode(LANDUSE_CODE)
				.areaSqm(500)
				.mas(100)
				.userIdInsert(LOGGED_USER_ID)
				.build();

		DeclarationsOnSectorsNTT ntt = DeclarationsOnSectorsNTT.builder()
				.applicationId(APPLICATION_ID)
				.sectorCode(SECTOR_CODE)
				.landUseCode(LANDUSE_CODE)
				.areaSqm(500)
				.mas(100)
				.dtInsert(OffsetDateTime.now())
				.flImported((short) 1)
				.userIdInsert(LOGGED_USER_ID)
				.build();

		when(mapper.entityToDto(ntt)).thenReturn(dto);

		when(declarationsOnSectorsDAO.getByApplicationIdSectorCodeLandUseCode(dto.getApplicationId(), dto.getSectorCode(), dto.getLandUseCode())).thenReturn(
				ntt);

		//        doNothing().when(applicationFacadeService).verifyAcceptDispositiveCalls(LOGGED_USER, TENANT, APPLICATION_ID, OPTION_CONFIG_ID);
		when(declarationsOnSectorsDAO.existsImport(APPLICATION_ID))
				.thenReturn(false);
		declarationsOnSectorsService.insert(LOGGED_USER, TENANT, APPLICATION_ID, FORM_CONFIG_ID, COMPILE_STATUS_IDENTIFIER, dto);

		ArgumentCaptor<DeclarationsOnSectorsNTT> captor = ArgumentCaptor.forClass(DeclarationsOnSectorsNTT.class);
		verify(declarationsOnSectorsDAO).insert(captor.capture());
		DeclarationsOnSectorsNTT capturedNtt = captor.getValue();

		assertNotNull(capturedNtt);
		assertEquals(APPLICATION_ID, capturedNtt.getApplicationId());
		assertEquals(SECTOR_CODE, capturedNtt.getSectorCode());
		assertEquals(LANDUSE_CODE, capturedNtt.getLandUseCode());
	}

	@Test
	void testInsertFailsWhenDAOThrowsException() {

		DeclarationsOnSectorsDTO dto = DeclarationsOnSectorsDTO.builder()
				.applicationId(APPLICATION_ID)
				.sectorCode(SECTOR_CODE)
				.landUseCode(LANDUSE_CODE)
				.areaSqm(500)
				.mas(100)
				.userIdInsert(LOGGED_USER_ID)
				.build();

		doThrow(RuntimeException.class).when(declarationsOnSectorsDAO).insert(any());

		//        doNothing().when(applicationFacadeService).verifyAcceptDispositiveCalls(LOGGED_USER, TENANT, APPLICATION_ID, OPTION_CONFIG_ID);

		assertThrows(RuntimeException.class, () ->
				declarationsOnSectorsService.insert(LOGGED_USER, TENANT, APPLICATION_ID, FORM_CONFIG_ID, COMPILE_STATUS_IDENTIFIER, dto));

		verify(declarationsOnSectorsDAO).insert(any());
	}

	// Test: Delete
	@Test
	void testDeleteSuccess() {
		// Arrange
		DeclarationsOnSectorsNTT ntt = DeclarationsOnSectorsNTT.builder()
				.pkid(PKID)
				.applicationId(APPLICATION_ID)
				.flImported((short) 0)
				.build();

		when(declarationsOnSectorsDAO.getByApplicationIdAndDeclatationId(APPLICATION_ID, PKID))
				.thenReturn(ntt);

		// Act
		boolean result = declarationsOnSectorsService.delete(LOGGED_USER, TENANT, APPLICATION_ID, FORM_CONFIG_ID, COMPILE_STATUS_IDENTIFIER, PKID);

		// Assert
		assertTrue(result);

		ArgumentCaptor<Long> applicationIdCaptor = ArgumentCaptor.forClass(Long.class);
		ArgumentCaptor<Long> declarationIdCaptor = ArgumentCaptor.forClass(Long.class);

		verify(declarationsOnSectorsDAO, times(1)).expire(
				applicationIdCaptor.capture(),
				declarationIdCaptor.capture(),
				any(),
				eq(LOGGED_USER_ID)
		);

		assertEquals(APPLICATION_ID, applicationIdCaptor.getValue());
		assertEquals(PKID, declarationIdCaptor.getValue());
	}

	@Test
	void testDeleteFailsWhenNotFound() {

		when(declarationsOnSectorsDAO.getByApplicationIdAndDeclatationId(APPLICATION_ID, PKID)).thenReturn(null);

		//        doNothing().when(applicationFacadeService).verifyAcceptDispositiveCalls(LOGGED_USER, TENANT, APPLICATION_ID, OPTION_CONFIG_ID);

		boolean result = declarationsOnSectorsService.delete(LOGGED_USER, TENANT, APPLICATION_ID, FORM_CONFIG_ID, COMPILE_STATUS_IDENTIFIER, PKID);

		assertFalse(result);
		verify(declarationsOnSectorsDAO, never()).expire(anyLong(), anyLong(), any(), any());
	}

	// Test: Get All
	@Test
	void testGetAllSuccess() {

		DeclarationsOnSectorsNTT ntt = DeclarationsOnSectorsNTT.builder()
				.pkid(1L)
				.applicationId(APPLICATION_ID)
				.sectorCode(SECTOR_CODE)
				.landUseCode(LANDUSE_CODE)
				.build();

		DeclarationsOnSectorsDTO dto = DeclarationsOnSectorsDTO.builder()
				.applicationId(APPLICATION_ID)
				.sectorCode(SECTOR_CODE)
				.landUseCode(LANDUSE_CODE)
				.build();

		when(declarationsOnSectorsDAO.getByApplicationId(APPLICATION_ID)).thenReturn(List.of(ntt));
		when(mapper.entityToDto(ntt)).thenReturn(dto);

		List<DeclarationsOnSectorsDTO> result = declarationsOnSectorsService.getAll(LOGGED_USER, TENANT, APPLICATION_ID);

		assertNotNull(result);
		assertEquals(1, result.size());
		assertEquals(dto, result.get(0));
		verify(declarationsOnSectorsDAO).getByApplicationId(APPLICATION_ID);
		verify(mapper).entityToDto(ntt);
	}

	@Test
	void testGetAllReturnsEmptyList() {

		when(declarationsOnSectorsDAO.getByApplicationId(APPLICATION_ID)).thenReturn(Collections.emptyList());

		List<DeclarationsOnSectorsDTO> result = declarationsOnSectorsService.getAll(LOGGED_USER, TENANT, APPLICATION_ID);

		assertNotNull(result);
		assertTrue(result.isEmpty());
		verify(declarationsOnSectorsDAO).getByApplicationId(APPLICATION_ID);
	}

	@Test
	void testUpdateSuccess() {

		DeclarationsOnSectorsDTO dto = DeclarationsOnSectorsDTO.builder()
				.applicationId(APPLICATION_ID)
				.sectorCode(SECTOR_CODE)
				.landUseCode(LANDUSE_CODE)
				.areaSqm(500)
				.mas(100)
				.userIdInsert(LOGGED_USER_ID)
				.build();

		DeclarationsOnSectorsNTT ntt = DeclarationsOnSectorsNTT.builder()
				.applicationId(APPLICATION_ID)
				.sectorCode(UPDT_SECTOR_CODE)
				.landUseCode(LANDUSE_CODE)
				.areaSqm(500)
				.mas(100)
				.dtInsert(OffsetDateTime.now())
				.userIdInsert(LOGGED_USER_ID)
				.flImported((short) 1)
				.build();

		DeclarationsOnSectorsDTO updatedDto = DeclarationsOnSectorsDTO.builder()
				.applicationId(APPLICATION_ID)
				.sectorCode(UPDT_SECTOR_CODE)
				.landUseCode(LANDUSE_CODE)
				.areaSqm(500)
				.mas(100)
				.userIdInsert(LOGGED_USER_ID)
				.build();

		when(declarationsOnSectorsDAO.getByApplicationIdSectorCodeLandUseCode(dto.getApplicationId(), dto.getSectorCode(), dto.getLandUseCode())).thenReturn(
				ntt);

		when(mapper.entityToDto(ntt)).thenReturn(updatedDto);

		DeclarationsOnSectorsDTO res =
				declarationsOnSectorsService.update(LOGGED_USER, TENANT, APPLICATION_ID, FORM_CONFIG_ID,
						COMPILE_STATUS_IDENTIFIER, dto, DECLARATION_ID);

		assertNotNull(res);
		assertEquals(UPDT_SECTOR_CODE, res.getSectorCode());
		assertNotEquals(dto.getSectorCode(), res.getSectorCode());
		assertEquals(APPLICATION_ID, res.getApplicationId());
	}
}
