package com.abacogroup.agri.applicationforms.pua.services;

import java.io.ByteArrayOutputStream;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.Month;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.util.Locale;

import com.abacogroup.agri.applicationforms.pua.core.model.CompileStatusEnum;
import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.filestore.client.auth.Sso2Authenticator;
import com.abacogroup.jdbi.paging.PagingParams;

/**
 * 
 * @author Emanuele Crocilla
 *
 */
public abstract class AbstractServiceTest {

	protected static final Long ID = 1L;
	protected static final int YEAR = 2024;
	protected static final String TENANT = "tenant";
	protected static final Long OPTION_CONFIG_ID = 140L;
	protected static final String LOGGED_USER_ID = "user1";
	protected static final User LOGGED_USER = new User(LOGGED_USER_ID, TENANT);
	protected static final String SECTOR_CODE = " A001";
	protected static final String UPDT_SECTOR_CODE = " A999";
	protected static final String LANDUSE_CODE = "L001";
	protected static final Long PKID = 456L;
	protected static final Long FORM_CONFIG_ID = 789L;
	protected static final String COMPILE_STATUS_IDENTIFIER = "compile status identifier";
	protected static final String FORM_CODE = "Form code";
	protected static final String OPTION_CODE_1 = "Option code 1";
	protected static final String FORM_NAME = "Form name";
	protected static final String GROUP_CODE_1 = "group code 1";
	protected static final String GROUP_NAME_1 = "Group name 1";
	protected static final String GROUP_CODE_2 = "group code 2";
	protected static final String GROUP_NAME_2 = "Group name 2";
	protected static final String KEY_1 = "Key 1";
	protected static final String VALUE_1 = "Value 1";
	protected static final String KEY_2 = "Key 2";
	protected static final String VALUE_2 = "Value 2";
	protected static final CompileStatusEnum COMPILE_STATUS_ENUM = CompileStatusEnum.IN_PROGRESS;
	protected static final Long PARTY_ID = 10L;
	protected static final String PARTY_CODE = "ASDRTT123";
	protected static final Long UPDT_PARTY_ID = 988L;
	protected static final String APPLICATION_CODE_1 = "10";
	protected static final String APPLICATION_CODE_2 = "20";
	protected static final CompileStatusEnum PROCESS_STATUS_1 = CompileStatusEnum.IN_PROGRESS;
	protected static final CompileStatusEnum PROCESS_STATUS_2 = CompileStatusEnum.COMPLETED;
	protected static final Long PROCESS_ID_1 = 119L;
	protected static final Long PROCESS_ID_2 = 200L;
	protected static final LocalDateTime DT_PRESENTATION = LocalDateTime.of(LocalDate.of(2022, Month.NOVEMBER, 17), LocalTime.now());
	protected static final String SECTOR_DESCRIPTION = "AGRICULTURAL FUEL ALLOCATION";
	protected static final String MODULE_DESCRIPTION = "UMA";
	protected static final Boolean IS_CLOSED = false;
	protected static final String MODULE_CODE = "module code";
	protected static final String APPLICATION_BASE_URL = "application base url";
	protected static final String REMOTE_URL = "remote url";
	protected static final String NEXT_KEY = "next key";
	protected static final String AUTH_TOKEN = "Auth Token";
	protected static final String USERNAME = "Username";
	protected static final User USER = new User(USERNAME, AUTH_TOKEN, TENANT, USERNAME);
	protected static final String LANGUAGE = Locale.ITALIAN.getLanguage();
	protected static final Long BUSINESS_ID = 10L;
	protected static final String CROP_DESCRIPTION = "MY_CROP";
	protected static final String CROP_PLAN_TYPE_CODE = "100";
	protected static final Integer CROP_PLAN_ID = 120;
	protected static final Integer CAMPAGNA = 2024;
	protected static final String VERSION = "VERSION";
    protected static final String BUCKET_ID = "000123";
    protected static final String TYPE_ATTACHMENT_GROUP_CODE = "Type attachment group code";
    protected static final Long TYPE = 123L;
    protected static final LocalDateTime DT_INSERT = LocalDateTime.now();
    protected static final Long ID_1 = 1L;
    protected static final Long OPERATION_ID = 3L;
    protected static final String DESCRIPTION = "description";
    protected static final String FIELD_NAME = "fieldName";
    protected static final String I18N_TEXT = "text";
    protected static final String I18N_VALUE = "value";
    protected static final String LANG = "it";
    protected static final String OPTION_CODE = "option_code";
    protected static final String PARAM_VALUE = "PARAM_VALUE";
    protected static final Double OPTION_MINIMUM_VALUE = 100D;
    protected static final Double OPTION_ROW_MINIMUM_ENGAGEABLE_VALUE = 200D;
    protected static final Integer FL_FULL_ENGAGEMENT = 0;
    protected static final String DT_VALIDITY_START = "20221201";
    protected static final Long OPTION_CONFIG_ID_1 = 1L;
    protected static final String ATTRIBUTE_NAME_1 = "attribute name 1";
    protected static final String ATTRIBUTE_VALUE_1 = "attribute value 1";
    protected static final Long OPTION_CONFIG_ID_2 = 2L;
    protected static final String ATTRIBUTE_NAME_2 = "attribute name 2";
    protected static final String ATTRIBUTE_VALUE_2 = "attribute value 2";
    protected static final String DT_VALIDITY_END = "20221205";
    protected static final Long OPTION_ID = 1L;
    protected static final String FATHER_OPTION_CODE = "Father Option Code";
    protected static final String OPTION_DESCRIPTION = "option_description";
    protected static final LocalDate NOW = LocalDate.now();
    protected static final String FILE_ID = "000001";
    protected static final Sso2Authenticator authenticator = new Sso2Authenticator(USER);
    protected static final ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
    protected static final String FILE_MIME_TYPE = "mime type";
    protected static final Long FILE_SIZE = 10L;
    protected static final Instant FILE_DATE = Instant.now();
    protected static final Boolean FILE_TEMPORARY = true;
    protected static final String CODE_1 = "code - 1";
    protected static final String DESCRIPTION_1 = "description - 1";
    protected static final String VERSION_1 = "1";
    protected static final String CODE_2 = "code - 2";
    protected static final String DESCRIPTION_2 = "description - 2";
    protected static final String VERSION_2 = "2";
    protected static final Long DOCUMENT_ID = 1L;
    protected static final String DOCUMENT_CODE = "DOCUMENT_CODE";
    protected static final Long CREATED_DOCUMENT_ID = 2L;
    protected static final OffsetDateTime VALID_FROM = OffsetDateTime.of(LocalDateTime.now(), ZoneOffset.UTC);
    protected static final OffsetDateTime VALID_TO = OffsetDateTime.of(LocalDateTime.MAX, ZoneOffset.UTC);
    protected static final Long APPLICATION_ID = 5L;
    protected static final Long DECLARATION_ID = 5L;
    protected static final String ATTACHMENT_GROUP = "attachment";
    protected static final String ATTACHMENT_ID = "1";
    protected static final String FILE_NAME = "file name.PDF";
    protected static final String NOTES = "notes";
    protected static final Long TYPE_ID = 1L;
    protected static final String TYPE_ATTACHMENT_CODE = "attachment type code";
    protected static final String CODE = "attachment type code";
    protected static final String GROUP_CODE = "attachment type group code";
    protected static final Long ATTACHMENT_TYPE_ID = 1L;
//    protected static final String BUCKET = "application-forms-attachment";
    protected static final String BUCKET = "declarations";
    protected static final String TYPE_CODE = "TYPE CODE";
    protected static final String FERTILIZER_TYPE = "FERTILIZER_TYPE";
    protected static final String FERTILIZER_CATEGORY = "FERTILIZER_CATEGORY";
    protected static final String CATEGORY_CODE = "CATEGORY_CODE";
    
    
	protected static final String MSG_EXC = "DON'T WORRY, THIS IS JUST A TEST TO VERIFY THAT AN EXCEPTION IS LAUNCHED";
	
	protected static class PagingParamsFactory {

		public static final int DEFAULT_OFFSET = 0;
		public static final int DEFAULT_LIMIT = 300;
		public static final int DEFAULT_PAGE_SIZE = 10;
		public static final int DEFAULT_PAGE_SIZE_FOR_OTHER_CASES = 5;

		public PagingParams getPagingParams(int offset, int limit) {
			return new PagingParams(offset, limit);
		}
	}

}
