package com.abacogroup.agri.applicationforms.pua.utils;

import static org.mockito.ArgumentMatchers.any;

import com.fasterxml.jackson.core.type.TypeReference;

public class MockitoUtils {
    public static <T> TypeReference<T> anyTypeReference() {
        return any(TypeReference.class);
    }
}
