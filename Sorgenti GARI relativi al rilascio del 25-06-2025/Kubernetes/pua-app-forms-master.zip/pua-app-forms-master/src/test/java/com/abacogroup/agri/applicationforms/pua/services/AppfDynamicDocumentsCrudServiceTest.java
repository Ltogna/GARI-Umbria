package com.abacogroup.agri.applicationforms.pua.services;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.fail;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.List;
import java.util.Optional;

import org.jdbi.v3.sqlobject.transaction.TransactionalCallback;
import org.jdbi.v3.sqlobject.transaction.TransactionalConsumer;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.abacogroup.agri.applicationforms.pua.core.mappers.AppfPuaDynamicDocumentsMapper;
import com.abacogroup.agri.applicationforms.pua.core.model.dto.AppfPuaDynamicDocumentsDTO;
import com.abacogroup.agri.applicationforms.pua.db.dao.AppfPuaDynamicDocumentsDAO;
import com.abacogroup.agri.applicationforms.pua.db.ntt.AppfPuaDynamicDocumentsNTT;
import com.abacogroup.agri.applicationforms.pua.services.common.AppfPuaDynamicDocumentsCrudService;

@ExtendWith(MockitoExtension.class)
class AppfPuaDynamicDocumentsCrudServiceTest {
    @Mock
    private AppfPuaDynamicDocumentsDAO appfPuaDynamicDocumentsDAOMock;
    @Mock
    private AppfPuaDynamicDocumentsMapper appfPuaDynamicDocumentsMapperMock;

    @InjectMocks
    private AppfPuaDynamicDocumentsCrudService appfPuaDynamicDocumentsCrudService;

    private static final Long APPLICATION_ID = 5L;
    private static final String DOCUMENT_CODE = "Document code";
    private static final Long DOCUMENT_ID = 1L;
    private static final Long ID = 1L;

    private final AppfPuaDynamicDocumentsNTT appfPuaDynamicDocumentsNTT = AppfPuaDynamicDocumentsNTT.builder()
            .id(ID)
            .document_id(DOCUMENT_ID)
            .document_code(DOCUMENT_CODE)
            .application_id(APPLICATION_ID)
            .build();
    private final AppfPuaDynamicDocumentsDTO appfPuaDynamicDocumentsDTO = AppfPuaDynamicDocumentsDTO.builder()
            .applicationId(APPLICATION_ID)
            .documentCode(DOCUMENT_CODE)
            .documentId(DOCUMENT_ID)
            .id(ID)
            .build();

    @Test
    void findById_ok() {
        when(appfPuaDynamicDocumentsDAOMock.findById(ID))
                .thenReturn(List.of(appfPuaDynamicDocumentsNTT));
        when(appfPuaDynamicDocumentsMapperMock.entityToDto(appfPuaDynamicDocumentsNTT))
                .thenReturn(appfPuaDynamicDocumentsDTO);

        Optional<AppfPuaDynamicDocumentsDTO> result = appfPuaDynamicDocumentsCrudService.findById(ID);

        assertEquals(Optional.of(appfPuaDynamicDocumentsDTO), result);
    }

    @Test
    void findByApplicationId_ok() {
        when(appfPuaDynamicDocumentsDAOMock.findByApplicationId(APPLICATION_ID))
                .thenReturn(List.of(appfPuaDynamicDocumentsNTT));
        when(appfPuaDynamicDocumentsMapperMock.entityToDto(appfPuaDynamicDocumentsNTT))
                .thenReturn(appfPuaDynamicDocumentsDTO);
        List<AppfPuaDynamicDocumentsDTO> result = appfPuaDynamicDocumentsCrudService.findByApplicationId(APPLICATION_ID);

        assertEquals(List.of(appfPuaDynamicDocumentsDTO), result);
    }

    @Test
    void findByApplicationIdAndDocumentCode_ok() {
        when(appfPuaDynamicDocumentsDAOMock.findByApplicationIdAndDocumentCode(APPLICATION_ID, DOCUMENT_CODE))
                .thenReturn(List.of(appfPuaDynamicDocumentsNTT));
        when(appfPuaDynamicDocumentsMapperMock.entityToDto(appfPuaDynamicDocumentsNTT))
                .thenReturn(appfPuaDynamicDocumentsDTO);

        AppfPuaDynamicDocumentsDTO result = appfPuaDynamicDocumentsCrudService.findByApplicationIdAndDocumentCode(APPLICATION_ID, DOCUMENT_CODE);

        assertEquals(appfPuaDynamicDocumentsDTO, result);
    }

    @SuppressWarnings({"rawtypes", "unchecked"})
    @Test
    void insert_ok() {
        AppfPuaDynamicDocumentsDTO in = AppfPuaDynamicDocumentsDTO.builder()
                .applicationId(APPLICATION_ID)
                .documentCode(DOCUMENT_CODE)
                .documentId(DOCUMENT_ID)
                .build();

        try {
            ArgumentCaptor<TransactionalCallback> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(TransactionalCallback.class);

            when(appfPuaDynamicDocumentsDAOMock.findById(any()))
                    .thenReturn(List.of(appfPuaDynamicDocumentsNTT));
            when(appfPuaDynamicDocumentsMapperMock.dtoToEntity(in))
                    .thenReturn(appfPuaDynamicDocumentsNTT);
            when(appfPuaDynamicDocumentsMapperMock.entityToDto(appfPuaDynamicDocumentsNTT))
                    .thenReturn(appfPuaDynamicDocumentsDTO);

            appfPuaDynamicDocumentsCrudService.insert(in);

            verify(appfPuaDynamicDocumentsDAOMock).inTransaction(handleConsumerLambdaCaptor.capture());

            AppfPuaDynamicDocumentsDTO result = (AppfPuaDynamicDocumentsDTO) handleConsumerLambdaCaptor.getValue().inTransaction(appfPuaDynamicDocumentsDAOMock);

            assertEquals(appfPuaDynamicDocumentsDTO, result);
        } catch (Exception e) {
            fail(e.getMessage(), e);
        }
    }

    @SuppressWarnings({"unchecked", "rawtypes"})
    @Test
    void test_update() {
        AppfPuaDynamicDocumentsDTO in = AppfPuaDynamicDocumentsDTO.builder()
                .applicationId(APPLICATION_ID)
                .documentCode(DOCUMENT_CODE)
                .documentId(DOCUMENT_ID)
                .build();

        try {
            ArgumentCaptor<TransactionalCallback> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(TransactionalCallback.class);

            when(appfPuaDynamicDocumentsDAOMock.findById(ID)).thenReturn(List.of(appfPuaDynamicDocumentsNTT));
            when(appfPuaDynamicDocumentsMapperMock.dtoToEntity(in))
                    .thenReturn(appfPuaDynamicDocumentsNTT);
            when(appfPuaDynamicDocumentsMapperMock.entityToDto(appfPuaDynamicDocumentsNTT))
                    .thenReturn(appfPuaDynamicDocumentsDTO);

            appfPuaDynamicDocumentsCrudService.update(ID, in);

            verify(appfPuaDynamicDocumentsDAOMock).inTransaction(handleConsumerLambdaCaptor.capture());
            AppfPuaDynamicDocumentsDTO result = (AppfPuaDynamicDocumentsDTO) handleConsumerLambdaCaptor.getValue().inTransaction(appfPuaDynamicDocumentsDAOMock);

            assertEquals(appfPuaDynamicDocumentsDTO, result);
        } catch (Exception e) {
            fail(e.getMessage(), e);
        }
    }

    @SuppressWarnings({"rawtypes", "unchecked"})
    @Test
    void delete_ok() {
        try {
            ArgumentCaptor<TransactionalConsumer> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(TransactionalConsumer.class);

            appfPuaDynamicDocumentsCrudService.delete(ID);

            verify(appfPuaDynamicDocumentsDAOMock).useTransaction(handleConsumerLambdaCaptor.capture());
            handleConsumerLambdaCaptor.getValue().useTransaction(appfPuaDynamicDocumentsDAOMock);

            verify(appfPuaDynamicDocumentsDAOMock).deleteById(ID);
        } catch (Exception e) {
            fail(e.getMessage(), e);
        }
    }

//    @Test
//    void findRsByCustomKey_ok() {
//        Optional<AppfPuaDynamicDocumentsNTT> result = appfPuaDynamicDocumentsCrudService.findRsByCustomKey(null);
//
//        assertEquals(Optional.empty(), result);
//    }
//
//    @Test
//    void deleteByCustomKey_ok() {
//        assertThrows(NotImplementedException.class, () ->
//                appfPuaDynamicDocumentsCrudService.deleteByCustomKey(null));
//    }
//
//    @Test
//    void setCustomSearchKey_ok() {
//        assertThrows(NotImplementedException.class, () ->
//                appfPuaDynamicDocumentsCrudService.setCustomSearchKey(appfPuaDynamicDocumentsNTT, null));
//    }
}
