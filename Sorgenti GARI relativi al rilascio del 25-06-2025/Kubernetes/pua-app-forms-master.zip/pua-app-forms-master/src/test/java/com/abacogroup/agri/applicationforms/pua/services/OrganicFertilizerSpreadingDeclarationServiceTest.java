package com.abacogroup.agri.applicationforms.pua.services;

import com.abacogroup.agri.applicationforms.pua.core.mappers.OrganicFertilizerSpreadingDeclarationMapper;
import com.abacogroup.agri.applicationforms.pua.core.model.dto.OrganicFertilizerSpreadingDeclarationDTO;
import com.abacogroup.agri.applicationforms.pua.core.model.dto.OrganicFertilizerSpreadingDeclarationLanduseDTO;
import com.abacogroup.agri.applicationforms.pua.core.model.dto.PartyResponse;
import com.abacogroup.agri.applicationforms.pua.db.dao.OrganicFertilizerSpreadingDeclarationDAO;
import com.abacogroup.agri.applicationforms.pua.db.ntt.OrganicFertilizerSpreadingDeclarationNTT;
import com.abacogroup.agri.applicationforms.pua.services.common.ApplicationFacadeService;
import com.abacogroup.applicationworkflowsdk.model.io.output.ApplicationDetailsPublicDTO;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

/**
 * @author Emanuele Crocilla
 */
@ExtendWith(MockitoExtension.class)
class OrganicFertilizerSpreadingDeclarationServiceTest extends AbstractServiceTest {

	@Mock
	private OrganicFertilizerSpreadingDeclarationDAO organicFertilizerSpreadingDeclarationDAO;

	@Mock
	private OrganicFertilizerSpreadingDeclarationMapper mapper;

	@Mock
	private PartyService partyService;

	@InjectMocks
	private OrganicFertilizerSpreadingDeclarationService organicFertilizerSpreadingDeclarationService;

	@Mock
	private ApplicationFacadeService applicationFacadeService;
	@Mock
	private NoSpreadingPeriodService noSpreadingPeriodService;

	private static OrganicFertilizerSpreadingDeclarationDTO in, modified, dbInserted;
	private static OrganicFertilizerSpreadingDeclarationNTT dbFetched;
	private static PartyResponse partyResponse;
	private static String expectedDate;

	@BeforeAll
	public static void init() {

		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
		var cal = Calendar.getInstance();
		cal.set(Calendar.DAY_OF_MONTH, cal.get(Calendar.DAY_OF_MONTH) + 3);

		expectedDate = sdf.format(cal.getTime());

		in = OrganicFertilizerSpreadingDeclarationDTO.builder()
				.applicationId(APPLICATION_ID)
				.pkid(PKID)
				.id(DECLARATION_ID)
				.partyId(PARTY_ID)
				.expectedDate(expectedDate)
				.userIdInsert(LOGGED_USER_ID)
				.landuses(Arrays.asList(OrganicFertilizerSpreadingDeclarationLanduseDTO.builder().plotId("F304").build()))
				.build();

		dbFetched = OrganicFertilizerSpreadingDeclarationNTT.builder()
				.applicationId(APPLICATION_ID)
				.pkid(PKID)
				.id(DECLARATION_ID)
				.partyId(UPDT_PARTY_ID)
				.expectedDate(expectedDate)
				.userIdInsert(LOGGED_USER_ID)
				.build();

		modified = OrganicFertilizerSpreadingDeclarationDTO.builder()
				.applicationId(APPLICATION_ID)
				.pkid(PKID)
				.id(DECLARATION_ID)
				.partyId(UPDT_PARTY_ID)
				.expectedDate(expectedDate)
				.userIdInsert(LOGGED_USER_ID)
				.build();

		dbInserted = OrganicFertilizerSpreadingDeclarationDTO.builder()
				.applicationId(APPLICATION_ID)
				.pkid(PKID)
				.id(DECLARATION_ID)
				.partyId(PARTY_ID)
				.expectedDate(expectedDate)
				.userIdInsert(LOGGED_USER_ID)
				.build();

		partyResponse = PartyResponse.builder()
				.id(PARTY_ID.intValue())
				.code(PARTY_CODE)
				.build();
	}

	// Test: Insert
	@Test
	void testInsertSuccess() {

		when(partyService.getPartyById(LOGGED_USER, TENANT, PARTY_ID)).thenReturn(partyResponse);

		when(organicFertilizerSpreadingDeclarationService.firstTimeInsertion(any())).thenReturn(dbInserted);
		when(noSpreadingPeriodService.isSpreadingDateAllowed(any(), anyInt(), any(), any()))
				.thenReturn(true);

		OrganicFertilizerSpreadingDeclarationDTO res =
				organicFertilizerSpreadingDeclarationService.insert(LOGGED_USER, TENANT, APPLICATION_ID, FORM_CONFIG_ID,
						COMPILE_STATUS_IDENTIFIER, in);

		assertNotNull(res);
		assertEquals(APPLICATION_ID, res.getApplicationId());
		assertEquals(DECLARATION_ID, res.getId());
		assertEquals(PARTY_ID, res.getPartyId());
		assertEquals(expectedDate, res.getExpectedDate());
	}

	@Test
	void testUpdateSuccess() {

		when(organicFertilizerSpreadingDeclarationDAO.findByDeclarationId(DECLARATION_ID)).thenReturn(dbFetched);

		when(mapper.entityToDto(dbFetched)).thenReturn(modified);

		when(partyService.getPartyById(LOGGED_USER, TENANT, PARTY_ID)).thenReturn(partyResponse);
		when(noSpreadingPeriodService.isSpreadingDateAllowed(any(), anyInt(), any(), any()))
				.thenReturn(true);
		OrganicFertilizerSpreadingDeclarationDTO res =
				organicFertilizerSpreadingDeclarationService.update(LOGGED_USER, TENANT, APPLICATION_ID, FORM_CONFIG_ID,
						COMPILE_STATUS_IDENTIFIER, in);

		assertNotNull(res);
		assertEquals(UPDT_PARTY_ID, res.getPartyId());
		assertNotEquals(in.getPartyId(), res.getPartyId());
		assertEquals(APPLICATION_ID, res.getApplicationId());
		assertEquals(DECLARATION_ID, res.getId());
		assertEquals(expectedDate, res.getExpectedDate());
	}

	// Test: Delete
	@Test
	void testDeleteSuccess() {

		OrganicFertilizerSpreadingDeclarationNTT ntt = OrganicFertilizerSpreadingDeclarationNTT.builder()
				.pkid(PKID)
				.applicationId(APPLICATION_ID)
				.build();

		when(organicFertilizerSpreadingDeclarationDAO.findByDeclarationId(DECLARATION_ID)).thenReturn(ntt);

		boolean result = organicFertilizerSpreadingDeclarationService.delete(LOGGED_USER, TENANT, APPLICATION_ID, FORM_CONFIG_ID, COMPILE_STATUS_IDENTIFIER,
				DECLARATION_ID);

		assertTrue(result);
		ArgumentCaptor<Long> idCaptor = ArgumentCaptor.forClass(Long.class);
		ArgumentCaptor<Long> declarationIdCaptor = ArgumentCaptor.forClass(Long.class);

		//        verify(organicFertilizerSpreadingDeclarationDAO).expireByPkId(idCaptor.capture(), declarationIdCaptor.capture(), any(), eq(LOGGED_USER_ID));
		verify(organicFertilizerSpreadingDeclarationDAO).expireHierarchyByPkId(idCaptor.capture(), declarationIdCaptor.capture(), eq(LOGGED_USER_ID));

		assertEquals(APPLICATION_ID, idCaptor.getValue());
		assertEquals(PKID, declarationIdCaptor.getValue());
	}

	@Test
	void testDeleteFailsWhenNotFound() {

		when(organicFertilizerSpreadingDeclarationDAO.findByDeclarationId(DECLARATION_ID)).thenReturn(null);

		boolean result = organicFertilizerSpreadingDeclarationService.delete(LOGGED_USER, TENANT, APPLICATION_ID, FORM_CONFIG_ID, COMPILE_STATUS_IDENTIFIER,
				DECLARATION_ID);

		assertFalse(result);
		verify(organicFertilizerSpreadingDeclarationDAO, never()).expireByDeclarationId(anyLong(), anyLong(), any(), any());
	}

	// Test: Get All
	@Test
	void testGetAllSuccess() {

		OrganicFertilizerSpreadingDeclarationNTT ntt = OrganicFertilizerSpreadingDeclarationNTT.builder()
				.pkid(1L)
				.applicationId(APPLICATION_ID)
				.expectedDate(expectedDate)
				.build();

		ApplicationDetailsPublicDTO mockApplicationDetailsPublicDTO = ApplicationDetailsPublicDTO.builder()
				.build();

		when(applicationFacadeService.callForApplicationDetails(TENANT, APPLICATION_ID, LOGGED_USER, LANGUAGE))
				.thenReturn(mockApplicationDetailsPublicDTO);

		when(organicFertilizerSpreadingDeclarationDAO.findByApplicationId(APPLICATION_ID)).thenReturn(Collections.singletonList(ntt));
		when(mapper.entityToDto(ntt)).thenReturn(dbInserted);

		when(partyService.getPartyById(LOGGED_USER, TENANT, PARTY_ID)).thenReturn(partyResponse);

		List<OrganicFertilizerSpreadingDeclarationDTO> result = organicFertilizerSpreadingDeclarationService.getAll(LOGGED_USER, TENANT, APPLICATION_ID);

		assertNotNull(result);
		assertEquals(1, result.size());
		assertEquals(dbInserted, result.get(0));
		verify(mapper).entityToDto(ntt);
	}

	@Test
	void testGetAllReturnsEmptyList() {

		ApplicationDetailsPublicDTO mockApplicationDetailsPublicDTO = ApplicationDetailsPublicDTO.builder()
				.build();

		when(applicationFacadeService.callForApplicationDetails(TENANT, APPLICATION_ID, LOGGED_USER, LANGUAGE))
				.thenReturn(mockApplicationDetailsPublicDTO);

		when(organicFertilizerSpreadingDeclarationDAO.findByApplicationId(APPLICATION_ID)).thenReturn(Collections.emptyList());

		List<OrganicFertilizerSpreadingDeclarationDTO> result = organicFertilizerSpreadingDeclarationService.getAll(LOGGED_USER, TENANT, APPLICATION_ID);

		assertNotNull(result);
		assertTrue(result.isEmpty());
		verify(organicFertilizerSpreadingDeclarationDAO).findByApplicationId(APPLICATION_ID);
	}
}
