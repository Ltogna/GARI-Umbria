package com.abacogroup.agri.applicationforms.pua.services;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.fail;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.List;
import java.util.Locale;
import java.util.Optional;

import org.apache.commons.lang3.NotImplementedException;
import org.jdbi.v3.sqlobject.transaction.TransactionalCallback;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.abacogroup.agri.applicationforms.pua.core.mappers.OptionCatalogMapper;
import com.abacogroup.agri.applicationforms.pua.core.model.OptionType;
import com.abacogroup.agri.applicationforms.pua.core.model.dto.OptionCatalogDTO;
import com.abacogroup.agri.applicationforms.pua.core.model.dto.enums.OptionTypeEnum;
import com.abacogroup.agri.applicationforms.pua.db.dao.OptionCatalogDAO;
import com.abacogroup.agri.applicationforms.pua.db.ntt.OptionCatalogNTT;
import com.abacogroup.agri.applicationforms.pua.db.ntt.OptionConfigsNTT;
import com.abacogroup.agri.applicationforms.pua.db.ntt.applications.RsI18N;
import com.abacogroup.agri.applicationforms.pua.services.common.I18NService;
import com.abacogroup.jdbi.datatype.AbsoluteDate;

import lombok.extern.slf4j.Slf4j;
 
@Slf4j
@ExtendWith(MockitoExtension.class)
class OptionCatalogsCrudServiceTest extends AbstractServiceTest {

    @Mock
    private OptionCatalogDAO optionCatalogDAO;
    @Mock
    private OptionCatalogMapper optionCatalogMapper;
    @Mock
    private I18NService i18NServiceMock;

    @InjectMocks
    private OptionCatalogsCrudService optionCatalogsCrudService;

    private static final String I18N_OPTION_CATALOG_TABLE = "appfpua_option_catalog";

    private final OptionCatalogNTT optionCatalogsNTT = OptionCatalogNTT.builder()
            .id(ID)
            .option_code(OPTION_CODE)
            .tenant_id(TENANT)
            .option_description(OPTION_DESCRIPTION)
            .build();

    private final OptionCatalogDTO optionCatalogsDTO = OptionCatalogDTO.builder()
            .id(ID)
            .optionCode(OPTION_CODE)
            .tenantId(TENANT)
            .optionDescription(OPTION_DESCRIPTION)
            .build();

    private final RsI18N rsI18N = RsI18N.builder()
            .tenant_id(TENANT)
            .field_name(FIELD_NAME)
            .i18n_text(I18N_TEXT)
            .lang(LANG)
            .i18n_value(I18N_VALUE)
            .table_name(I18N_OPTION_CATALOG_TABLE)
            .build();
    private final OptionConfigsNTT optionConfigsNTT = OptionConfigsNTT.builder()
            .option_id(OPTION_ID)
            .id(ID)
            .fl_full_engagement(1)
            .fl_auto_compile(0)
            .nr_of_years(5)
            .build();
    private final OptionType optionType = OptionType.builder()
            .code(OPTION_CODE)
            .type(OptionTypeEnum.SURFACE.name())
            .build();

    @Test
    void findOptById_ok() {
        when(optionCatalogDAO.findById(ID))
                .thenReturn(List.of(optionCatalogsNTT));
        when(optionCatalogMapper.entityToDto(optionCatalogsNTT))
                .thenReturn(optionCatalogsDTO);

        Optional<OptionCatalogDTO> result = optionCatalogsCrudService.findOptById(ID);

        assertEquals(Optional.of(optionCatalogsDTO), result);
    }

    @Test
    void findById_ok() {
        when(optionCatalogDAO.findById(ID))
                .thenReturn(List.of(optionCatalogsNTT));

        when(optionCatalogMapper.entityToDto(optionCatalogsNTT))
                .thenReturn(optionCatalogsDTO);

        OptionCatalogDTO result = optionCatalogsCrudService.findById(ID);

        assertEquals(optionCatalogsDTO, result);
    }

    @Test
    void findByOptionId_ok() {
        when(optionCatalogDAO.findByOptionId(TENANT, OPTION_ID, Locale.ITALIAN.getLanguage()))
                .thenReturn(List.of(optionCatalogsNTT));

        when(optionCatalogMapper.entityToDto(optionCatalogsNTT))
                .thenReturn(optionCatalogsDTO);

        OptionCatalogDTO result = optionCatalogsCrudService.findByOptionId(TENANT, OPTION_ID).get(0);

        assertEquals(optionCatalogsDTO, result);
    }

    @Test
    void findAllByTenant_ok() {
        when(optionCatalogDAO.findAllByTenant(TENANT, Locale.ITALIAN.getLanguage()))
                .thenReturn(List.of(optionCatalogsNTT));

        when(optionCatalogMapper.entityToDto(optionCatalogsNTT))
                .thenReturn(optionCatalogsDTO);

        List<OptionCatalogDTO> result = optionCatalogsCrudService.findAllByTenant(TENANT);

        assertEquals(List.of(optionCatalogsDTO), result);
    }

    @Test
    void findByOptionCode_ok() {
        when(optionCatalogDAO.findByOptionCode(TENANT, OPTION_CODE))
                .thenReturn(List.of(optionCatalogsNTT));

        when(optionCatalogMapper.entityToDto(optionCatalogsNTT))
                .thenReturn(optionCatalogsDTO);

        OptionCatalogDTO result = optionCatalogsCrudService.findByOptionCode(TENANT, OPTION_CODE);

        assertEquals(optionCatalogsDTO, result);
    }

    @Test
    void findOptByOptionCode_ok() {
        when(optionCatalogDAO.findByOptionCode(TENANT, OPTION_CODE, Locale.ITALIAN.getLanguage()))
                .thenReturn(List.of(optionCatalogsNTT));
        when(optionCatalogMapper.entityToDto(optionCatalogsNTT))
                .thenReturn(optionCatalogsDTO);

        Optional<OptionCatalogDTO> result = optionCatalogsCrudService.findOptByOptionCode(TENANT, OPTION_CODE);

        assertEquals(Optional.of(optionCatalogsDTO), result);
    }

    @Test
    void findOptByOptionCodesAndOptionCode_ok() {
        when(optionCatalogDAO.findByOptionCodesAndOptionCode(TENANT, List.of(OPTION_CODE), OPTION_CODE, Locale.ITALIAN.getLanguage()))
                .thenReturn(List.of(optionCatalogsNTT));
        when(optionCatalogMapper.entityToDto(optionCatalogsNTT))
                .thenReturn(optionCatalogsDTO);

        Optional<OptionCatalogDTO> result =
                optionCatalogsCrudService.findOptByOptionCodesAndOptionCode(TENANT, List.of(OPTION_CODE), OPTION_CODE);

        assertEquals(Optional.of(optionCatalogsDTO), result);
    }

    @Test
    void findByOptionIds_ok() {
        when(optionCatalogDAO.findByOptionIds(TENANT, List.of(OPTION_ID), Locale.ITALIAN.getLanguage()))
                .thenReturn(List.of(optionCatalogsNTT));
        when(optionCatalogMapper.entityToDto(optionCatalogsNTT))
                .thenReturn(optionCatalogsDTO);

        List<OptionCatalogDTO> result = optionCatalogsCrudService.findByOptionIds(TENANT, List.of(OPTION_ID));

        assertEquals(List.of(optionCatalogsDTO), result);
    }

    @Test
    void findByOptionCodes_ok() {
        when(optionCatalogDAO.findByOptionCodes(TENANT, List.of(OPTION_CODE), Locale.ITALIAN.getLanguage()))
                .thenReturn(List.of(optionCatalogsNTT));
        when(optionCatalogMapper.entityToDto(optionCatalogsNTT))
                .thenReturn(optionCatalogsDTO);

        List<OptionCatalogDTO> result = optionCatalogsCrudService.findByOptionCodes(TENANT, List.of(OPTION_CODE));

        assertEquals(List.of(optionCatalogsDTO), result);
    }

    @Test
    void findByOptionCodes_emptyList_ok() {
        assertEquals(List.of(), optionCatalogsCrudService.findByOptionCodes(TENANT, null));
        assertEquals(List.of(), optionCatalogsCrudService.findByOptionCodes(TENANT, List.of()));
    }

    @Test
    void findFatherOptionCodeByChildOptionCode_ok() {
        when(optionCatalogDAO.findFatherOptionCodeByChildOptionCode(TENANT, OPTION_CODE))
                .thenReturn(List.of(FATHER_OPTION_CODE));

        List<String> result = optionCatalogsCrudService.findFatherOptionCodeByChildOptionCode(TENANT, OPTION_CODE);

        assertEquals(List.of(FATHER_OPTION_CODE), result);
    }

    @Test
    void findChildrenConfigsByFatherOptionCode_ok() {
        when(optionCatalogDAO.findChildrenConfigsByFatherOptionCode(TENANT, OPTION_CODE))
                .thenReturn(List.of(optionConfigsNTT));

        List<OptionConfigsNTT> result = optionCatalogsCrudService.findChildrenConfigsByFatherOptionCode(TENANT, OPTION_CODE);

        assertEquals(List.of(optionConfigsNTT), result);
    }

    @Test
    void findOptionCodeByOptionConfigId_ok() {
        when(optionCatalogDAO.findOptionCodeByOptionConfigId(TENANT, OPTION_ID))
                .thenReturn(OPTION_CODE);

        String result = optionCatalogsCrudService.findOptionCodeByOptionConfigId(TENANT, OPTION_ID);

        assertEquals(OPTION_CODE, result);
    }

    @Test
    void retrieveOptionCatalogAndType_ok() {
        AbsoluteDate VALIDITY_DATE = mock(AbsoluteDate.class);

        when(VALIDITY_DATE.toString())
                .thenReturn(NOW.toString());
        when(optionCatalogDAO.retrieveOptionCatalogAndType(TENANT, NOW.toString()))
                .thenReturn(List.of(optionType));

        List<OptionType> result = optionCatalogsCrudService.retrieveOptionCatalogAndType(TENANT, VALIDITY_DATE);

        assertEquals(List.of(optionType), result);
    }

    @SuppressWarnings({"rawtypes", "unchecked"})
    @Test
    void insert_ok() {
        OptionCatalogDTO in = OptionCatalogDTO.builder()
                .optionCode(OPTION_CODE)
                .tenantId(TENANT)
                .optionDescription(OPTION_DESCRIPTION)
                .build();

        try {
            ArgumentCaptor<TransactionalCallback> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(TransactionalCallback.class);

            when(optionCatalogDAO.findById(any()))
                    .thenReturn(List.of(optionCatalogsNTT));
            when(optionCatalogMapper.dtoToEntity(in))
                    .thenReturn(optionCatalogsNTT);
            when(optionCatalogMapper.entityToDto(optionCatalogsNTT))
                    .thenReturn(optionCatalogsDTO);

            optionCatalogsCrudService.insert(in);

            verify(optionCatalogDAO).inTransaction(handleConsumerLambdaCaptor.capture());

            OptionCatalogDTO result = (OptionCatalogDTO) handleConsumerLambdaCaptor.getValue().inTransaction(optionCatalogDAO);

            assertEquals(optionCatalogsDTO, result);
        } catch (Exception e) {
            fail(e.getMessage(), e);
        }
    }

    @SuppressWarnings({"unchecked", "rawtypes"})
    @Test
    void test_update() {
        try {
            ArgumentCaptor<TransactionalCallback> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(TransactionalCallback.class);

            when(optionCatalogDAO.findById(ID)).thenReturn(List.of(optionCatalogsNTT));
            when(optionCatalogMapper.dtoToEntity(optionCatalogsDTO))
                    .thenReturn(optionCatalogsNTT);
            when(optionCatalogMapper.entityToDto(optionCatalogsNTT))
                    .thenReturn(optionCatalogsDTO);

            optionCatalogsCrudService.update(ID, optionCatalogsDTO);

            verify(optionCatalogDAO).inTransaction(handleConsumerLambdaCaptor.capture());

            handleConsumerLambdaCaptor.getValue().inTransaction(optionCatalogDAO);

            Optional<OptionCatalogNTT> actual = optionCatalogDAO.findById(ID).stream().findFirst();

            assertTrue(actual.isPresent());
            assertEquals(optionCatalogsDTO.getOptionCode(), actual.get().getOption_code());
            assertEquals(optionCatalogsDTO.getOptionDescription(), actual.get().getOption_description());
            assertEquals(optionCatalogsDTO.getTenantId(), actual.get().getTenant_id());
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            fail(e.getMessage(), e);
        }
    }

    @Test
    void insertOptionCatalogI18n_ok() {
        optionCatalogsCrudService.insertOptionCatalogI18n(TENANT, OPTION_CODE, LANG, OPTION_DESCRIPTION);

        verify(i18NServiceMock, times(1)).insertI18N(TENANT, I18N_OPTION_CATALOG_TABLE,
                OptionCatalogsCrudService.OPTION_CATALOG_I18N.CODE.getOptionCode(), LANG, OPTION_CODE, OPTION_DESCRIPTION);
    }

    @Test
    void deleteOptionCatalogI18N_ok() {
        optionCatalogsCrudService.deleteOptionCatalogI18N(TENANT, OPTION_CODE);

        verify(i18NServiceMock, times(1)).deleteAllI18NbyCode(TENANT, I18N_OPTION_CATALOG_TABLE, OPTION_CODE);
    }

    @Test
    void getAllOptionCatalogI18NByTenantAndCode_ok() {
    	
    	
    	List<RsI18N> listres = List.of(rsI18N);
    	
        when(i18NServiceMock.getAllI18NbyCode(TENANT, I18N_OPTION_CATALOG_TABLE, OPTION_CODE))
                .thenReturn(listres);

        List<RsI18N> result = optionCatalogsCrudService.getAllOptionCatalogI18NByTenantAndCode(TENANT, OPTION_CODE);

        assertEquals(listres, result);
    }

    @Test
    void findRsByCustomKey_empty_ok() {
        Optional<OptionCatalogNTT> result = optionCatalogsCrudService.findRsByCustomKey(null);

        assertEquals(Optional.empty(), result);
    }

    @Test
    void deleteByCustomKey_NotImplemented() {
        assertThrows(NotImplementedException.class, () ->
                optionCatalogsCrudService.deleteByCustomKey(null));
    }

    @Test
    void setCustomSearchKey_NotImplemented() {
        assertThrows(NotImplementedException.class, () ->
                optionCatalogsCrudService.setCustomSearchKey(optionCatalogsNTT, null));
    }
}
