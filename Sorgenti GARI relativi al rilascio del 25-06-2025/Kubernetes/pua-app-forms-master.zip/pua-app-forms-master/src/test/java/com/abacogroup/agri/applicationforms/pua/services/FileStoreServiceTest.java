package com.abacogroup.agri.applicationforms.pua.services;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.fail;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.net.URI;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.abacogroup.agri.applicationforms.pua.core.exceptions.FileStoreIORuntimeException;
import com.abacogroup.agri.applicationforms.pua.core.exceptions.FileStoreMetadataNotFoundException;
import com.abacogroup.agri.applicationforms.pua.core.model.dto.FileDTO;
import com.abacogroup.agri.applicationforms.pua.core.model.dto.SavedFileDTO;
import com.abacogroup.filestore.client.FileStoreClient;
import com.abacogroup.filestore.client.response.AddFileResponse;
import com.abacogroup.filestore.client.response.FileMetadata;

@ExtendWith(MockitoExtension.class)
class FileStoreServiceTest extends AbstractServiceTest {
    @Mock
    private FileStoreClient fileStoreClientMock;
    @InjectMocks
    private FileStoreService fileStoreService;

    @Test
    void getFile_ok() {
        try {
            FileMetadata fileMetadata = new FileMetadata();
            fileMetadata.setId(FILE_ID);
            fileMetadata.setName(FILE_NAME);
            fileMetadata.setMimeType(FILE_MIME_TYPE);
            fileMetadata.setSize(FILE_SIZE);
            fileMetadata.setDate(FILE_DATE);
            fileMetadata.setTemporary(Optional.of(FILE_TEMPORARY));


            byte[] content = outputStream.toByteArray();
            FileDTO expectedOutput = FileDTO.builder()
                    .name(fileMetadata.getName())
                    .id(FILE_ID)
                    .bucketId(BUCKET_ID)
                    .content(content)
                    .build();

            when(fileStoreClientMock.getFileMetadata(authenticator, TENANT, BUCKET_ID, FILE_ID))
                    .thenReturn(fileMetadata);

            FileDTO result = fileStoreService.getFile(TENANT, FILE_ID, BUCKET_ID, USER, authenticator);

            verify(fileStoreClientMock, times(1)).getFileContent(eq(authenticator), eq(TENANT), eq(BUCKET_ID), eq(FILE_ID), any());

            assertEquals(expectedOutput, result);
        } catch (Exception e) {
            fail(e.getMessage(), e);
        }
    }

    @Test
    void getFileForDownload_ok() {
        URI uri = URI.create("Invalid-Uri");

        try (FileStoreClient fileStoreClient = new FileStoreClient(uri, null)){
            when(fileStoreClientMock.jaxrs())
                    .thenReturn(fileStoreClient.jaxrs());

            assertThrows(FileStoreIORuntimeException.class, () ->
                    fileStoreService.getFileForDownload(TENANT, FILE_ID, BUCKET_ID, USER, authenticator));
        } catch (Exception e) {
            fail(e.getMessage(), e);
        }
    }

    @Test
    void getFileForHead_ok() {
        URI uri = URI.create("Invalid-Uri");

        try (FileStoreClient fileStoreClient = new FileStoreClient(uri, null)){
            when(fileStoreClientMock.jaxrs())
                    .thenReturn(fileStoreClient.jaxrs());

            assertThrows(FileStoreIORuntimeException.class, () ->
                    fileStoreService.getFileForHead(TENANT, FILE_ID, BUCKET_ID, USER, authenticator));
        } catch (Exception e) {
            fail(e.getMessage(), e);
        }
    }

    @Test
    void saveFile_ok() {
        try {
            InputStream inputStream = InputStream.nullInputStream();

            AddFileResponse addFileResponse = new AddFileResponse();
            addFileResponse.setId(FILE_ID);

            SavedFileDTO expectedOutput = SavedFileDTO.builder()
                    .fileId(FILE_ID)
                    .build();

            when(fileStoreClientMock.addFile(any(), eq(TENANT), eq(BUCKET_ID), any(), eq(inputStream)))
                    .thenReturn(addFileResponse);

            SavedFileDTO result = fileStoreService.saveFile(TENANT, BUCKET_ID, inputStream, FILE_NAME, USER, authenticator);

            assertEquals(expectedOutput, result);
        } catch (Exception e) {
            fail(e.getMessage(), e);
        }
    }

    @Test
    void saveFile_ko() {
        try {
            InputStream inputStream = InputStream.nullInputStream();

            AddFileResponse addFileResponse = new AddFileResponse();
            addFileResponse.setId(FILE_ID);

            when(fileStoreClientMock.addFile(any(), eq(TENANT), eq(BUCKET_ID), any(), eq(inputStream)))
                    .thenThrow(IOException.class);

            assertThrows(FileStoreIORuntimeException.class, () ->
                    fileStoreService.saveFile(TENANT, BUCKET_ID, inputStream, FILE_NAME, USER, authenticator));
        } catch (Exception e) {
            fail(e.getMessage(), e);
        }
    }

    @Test
    void getFile_FileNotFoundException_ko() {
        try {
            when(fileStoreClientMock.getFileMetadata(authenticator, TENANT, BUCKET_ID, FILE_ID))
                    .thenThrow(FileNotFoundException.class);

            assertThrows(FileStoreIORuntimeException.class, () -> fileStoreService.getFile(TENANT, FILE_ID, BUCKET_ID, USER, authenticator));
        } catch (Exception e) {
            fail(e.getMessage(), e);
        }
    }

    @Test
    void getFile_IOException_ko() {
        try {
            when(fileStoreClientMock.getFileMetadata(authenticator, TENANT, BUCKET_ID, FILE_ID))
                    .thenThrow(IOException.class);

            assertThrows(FileStoreIORuntimeException.class, () -> fileStoreService.getFile(TENANT, FILE_ID, BUCKET_ID, USER, authenticator));
        } catch (Exception e) {
            fail(e.getMessage(), e);
        }
    }

    @Test
    void getFile_FileStoreMetadataNotFoundException_ko() {
        try {
            when(fileStoreClientMock.getFileMetadata(authenticator, TENANT, BUCKET_ID, FILE_ID))
                    .thenReturn(null);

            assertThrows(FileStoreMetadataNotFoundException.class, () -> fileStoreService.getFile(TENANT, FILE_ID, BUCKET_ID, USER, authenticator));

            verify(fileStoreClientMock, times(1)).getFileContent(eq(authenticator), eq(TENANT), eq(BUCKET_ID), eq(FILE_ID), any());
        } catch (Exception e) {
            fail(e.getMessage(), e);
        }
    }

//    @Test
//    TODO: fix this test
//    void getFileForDownload_ko() {
//        URI uri = URI.create("http://invalid-uri");
//
//        try {
//            when(fileStoreClientMock.jaxrs())
//                    .thenReturn(new FileStoreClient(uri, null).jaxrs());
//
//            assertThrows(FileStoreIORuntimeException.class, () ->
//                    fileStoreService.getFileForDownload(TENANT, FILE_ID, BUCKET_ID, USER, authenticator));
//        } catch (Exception e) {
//            fail(e.getMessage(), e);
//        }
//    }

}
