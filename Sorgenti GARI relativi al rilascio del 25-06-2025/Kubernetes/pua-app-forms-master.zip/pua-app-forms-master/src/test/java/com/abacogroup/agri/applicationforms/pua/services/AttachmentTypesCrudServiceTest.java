package com.abacogroup.agri.applicationforms.pua.services;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.fail;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doAnswer;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.List;
import java.util.Optional;
import java.util.function.Supplier;

import org.apache.commons.lang3.NotImplementedException;
import org.jdbi.v3.sqlobject.transaction.TransactionalCallback;
import org.jdbi.v3.sqlobject.transaction.TransactionalConsumer;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.abacogroup.agri.applicationforms.pua.core.exceptions.ObjectNotFoundException;
import com.abacogroup.agri.applicationforms.pua.core.exceptions.ObjectNotFoundRuntimeException;
import com.abacogroup.agri.applicationforms.pua.core.mappers.AttachmentTypeMapper;
import com.abacogroup.agri.applicationforms.pua.core.model.dto.AttachmentTypeDTO;
import com.abacogroup.agri.applicationforms.pua.db.dao.AttachmentTypeDAO;
import com.abacogroup.agri.applicationforms.pua.db.ntt.AttachmentTypeNTT;
import com.abacogroup.agri.applicationforms.pua.db.ntt.applications.RsI18N;
import com.abacogroup.agri.applicationforms.pua.services.common.I18NService;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.jdbi.paging.impl.InfiniteListResultsImpl;

import lombok.extern.slf4j.Slf4j;
 
@Slf4j
@ExtendWith(MockitoExtension.class)
class AttachmentTypesCrudServiceTest extends AbstractServiceTest {
    @Mock
    private AttachmentTypeMapper mapper;

    @Mock
    private I18NService i18NService;

    @Mock
    private AttachmentTypeDAO dao;

    @InjectMocks
    private AttachmentTypesCrudService service;

    private static final String TENANT = "ADMIN";
    private static final Long PK_ID = 1L;
    private static final String GROUP_CODE = "group_1";
    private static final String CODE = "001";
    private static final String TYPE_CODE = "type";
    private static final String NEXT_KEY = "next key";
    private static final String I18N_ATTACHMENT_TYPES_TABLE = "appfpua_attachment_types";
    private static final String LANG = "Lang";
    private static final String DESCRIPTION = "description";
    private static final String TEXT = "text";
    private static final String VALUE = "value";
    private static final String FIELD_NAME = "code";
    private static final String TABLE_NAME = "table_name";

    private final AttachmentTypeDTO attachmentTypeDTOIn = AttachmentTypeDTO.builder()
            .tenantId(TENANT)
            .attachmentGroupCode(GROUP_CODE)
            .typeCode(TYPE_CODE)
            .code(CODE)
            .build();
    private final AttachmentTypeDTO attachmentTypeDTOOut = AttachmentTypeDTO.builder()
            .pkid(PK_ID)
            .tenantId(TENANT)
            .attachmentGroupCode(GROUP_CODE)
            .typeCode(TYPE_CODE)
            .code(CODE)
            .build();
    private final AttachmentTypeNTT attachmentTypeNTTMock = AttachmentTypeNTT.builder()
            .pkid(PK_ID)
            .tenant_id(TENANT)
            .attachment_group_code(GROUP_CODE)
            .type_code(TYPE_CODE)
            .code(CODE)
            .build();
    private final RsI18N rsI18N = RsI18N.builder()
            .tenant_id(TENANT)
            .i18n_text(TEXT)
            .i18n_value(VALUE)
            .field_name(FIELD_NAME)
            .table_name(TABLE_NAME)
            .lang(LANG)
            .build();

    @SuppressWarnings({"rawtypes", "unchecked"})
    @Test
    void test_insert() {
        try {
            ArgumentCaptor<TransactionalCallback> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(TransactionalCallback.class);
            when(dao.nextSequenceVal()).thenReturn(PK_ID);
            when(dao.findById(PK_ID)).thenReturn(List.of(attachmentTypeNTTMock));

            service.insert(attachmentTypeDTOIn);

            when(mapper.dtoToEntity(attachmentTypeDTOIn)).thenReturn(attachmentTypeNTTMock);
            when(mapper.entityToDto(attachmentTypeNTTMock)).thenReturn(attachmentTypeDTOOut);

            verify(dao).inTransaction(handleConsumerLambdaCaptor.capture());

            AttachmentTypeDTO actual = (AttachmentTypeDTO) handleConsumerLambdaCaptor.getValue().inTransaction(dao);

            assertEquals(attachmentTypeDTOOut, actual);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            fail(e.getMessage(), e);
        }
    }

    @SuppressWarnings({"rawtypes", "unchecked"})
    @Test
    void test_update() {
        try {
            ArgumentCaptor<TransactionalCallback> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(TransactionalCallback.class);
            when(dao.findById(PK_ID)).thenReturn(List.of(attachmentTypeNTTMock));

            service.update(PK_ID, attachmentTypeDTOIn);

            when(mapper.dtoToEntity(attachmentTypeDTOIn)).thenReturn(attachmentTypeNTTMock);
            when(mapper.entityToDto(attachmentTypeNTTMock)).thenReturn(attachmentTypeDTOOut);

            verify(dao).inTransaction(handleConsumerLambdaCaptor.capture());

            AttachmentTypeDTO actual = (AttachmentTypeDTO) handleConsumerLambdaCaptor.getValue().inTransaction(dao);

            assertEquals(attachmentTypeDTOOut, actual);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            fail(e.getMessage(), e);
        }
    }

    @SuppressWarnings({"rawtypes", "unchecked"})
    @Test
    void test_delete() {
        try {
            ArgumentCaptor<TransactionalConsumer> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(TransactionalConsumer.class);
            service.delete(PK_ID);

            verify(dao).useTransaction(handleConsumerLambdaCaptor.capture());

            handleConsumerLambdaCaptor.getValue().useTransaction(dao);

            verify(dao).deleteById(PK_ID);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            fail(e.getMessage(), e);
        }
    }

    @Test
    void test_findById() throws ObjectNotFoundException {
        when(dao.findById(PK_ID)).thenReturn(List.of(attachmentTypeNTTMock));
        when(mapper.entityToDto(attachmentTypeNTTMock)).thenReturn(attachmentTypeDTOOut);

        AttachmentTypeDTO result = service.findById(PK_ID);

        assertEquals(attachmentTypeDTOOut, result);
    }

    @Test
    void findByTenantId_infiniteList_ok() {
        doAnswer(ans -> {
            Supplier<InfiniteListResults<AttachmentTypeNTT>> supplier = ans.getArgument(0);
            supplier.get();

            return new InfiniteListResultsImpl<>(List.of(attachmentTypeNTTMock), NEXT_KEY);
        }).when(dao).infinite(any(), eq(NEXT_KEY), eq(PagingParamsFactory.DEFAULT_PAGE_SIZE));
        when(mapper.entityToDto(attachmentTypeNTTMock))
                .thenReturn(attachmentTypeDTOOut);

        InfiniteListResults<AttachmentTypeDTO> result = service.findByTenantId(TENANT, NEXT_KEY);

        assertEquals(List.of(attachmentTypeDTOOut), result.getRecords());
    }

    @Test
    void findByTenantAttachmentGroup_ok() {
        doAnswer(ans -> {
            Supplier<InfiniteListResults<AttachmentTypeNTT>> supplier = ans.getArgument(0);
            supplier.get();

            return new InfiniteListResultsImpl<>(List.of(attachmentTypeNTTMock), NEXT_KEY);
        }).when(dao).infinite(any(), eq(NEXT_KEY), eq(PagingParamsFactory.DEFAULT_PAGE_SIZE));
        when(mapper.entityToDto(attachmentTypeNTTMock))
                .thenReturn(attachmentTypeDTOOut);

        InfiniteListResults<AttachmentTypeDTO> result = service.findByTenantAttachmentGroup(TENANT, GROUP_CODE, NEXT_KEY);

        assertEquals(List.of(attachmentTypeDTOOut), result.getRecords());
    }

    @Test
    void findByTenantAttachmentGroupFullList_ok() {
        when(dao.findAllByTenantIdAttachmentGroup(TENANT, GROUP_CODE, LANGUAGE))
                .thenReturn(List.of(attachmentTypeNTTMock));
        when(mapper.entityToDto(attachmentTypeNTTMock))
                .thenReturn(attachmentTypeDTOOut);

        List<AttachmentTypeDTO> result = service.findByTenantAttachmentGroupFullList(TENANT, GROUP_CODE);

        assertEquals(List.of(attachmentTypeDTOOut), result);
    }

    @Test
    void findByTenantId_ok() {
        when(dao.findByTenantId(TENANT))
                .thenReturn(List.of(attachmentTypeNTTMock));
        when(mapper.entityToDto(attachmentTypeNTTMock))
                .thenReturn(attachmentTypeDTOOut);

        List<AttachmentTypeDTO> result = service.findByTenantId(TENANT);

        assertEquals(List.of(attachmentTypeDTOOut), result);
    }

    @Test
    void findByCode_ok() {
        when(dao.findByCodeAndAttachmentGroupCode(TENANT, TYPE_CODE, GROUP_CODE, LANGUAGE))
                .thenReturn(List.of(attachmentTypeNTTMock));
        when(mapper.entityToDto(attachmentTypeNTTMock))
                .thenReturn(attachmentTypeDTOOut);

        AttachmentTypeDTO result = service.findByCodeAndAttachmentGroupCode(TENANT, TYPE_CODE, GROUP_CODE);

        assertEquals(attachmentTypeDTOOut, result);
    }

    @Test
    void findByCodeAndAttachmentGroupCode_ko() {
        when(dao.findByCodeAndAttachmentGroupCode(TENANT, TYPE_CODE, GROUP_CODE, LANGUAGE))
                .thenReturn(List.of());

        assertThrows(ObjectNotFoundRuntimeException.class, () -> service.findByCodeAndAttachmentGroupCode(TENANT, TYPE_CODE, GROUP_CODE));
    }

    @Test
    void insertAttachmentTypeI18N_ok() {
        service.insertAttachmentTypeI18N(TENANT, TYPE_CODE, LANG, DESCRIPTION);

        verify(i18NService, times(1)).insertI18N(TENANT, I18N_ATTACHMENT_TYPES_TABLE,
                AttachmentTypesCrudService.ATTACHMENT_TYPE_I18N.CODE.getCode(), LANG, TYPE_CODE, DESCRIPTION);
    }

    @Test
    void deleteAttachmentTypesI18N_ok() {
        service.deleteAttachmentTypesI18N(TENANT, TYPE_CODE);

        verify(i18NService, times(1)).deleteAllI18NbyCode(TENANT, I18N_ATTACHMENT_TYPES_TABLE, TYPE_CODE);
    }

    @Test
    void getAllAttachmentTypesI18NByTenantAndCode_ok() {
        when(i18NService.getAllI18NbyCode(TENANT, I18N_ATTACHMENT_TYPES_TABLE, TYPE_CODE))
                .thenReturn(List.of(rsI18N));

        List<RsI18N> result = service.getAllAttachmentTypesI18NByTenantAndCode(TENANT, TYPE_CODE);

        assertEquals(List.of(rsI18N), result);
    }

    @Test
    void findRsByCustomKey_ok() {
        Optional<AttachmentTypeNTT> result = service.findRsByCustomKey(null);

        assertEquals(Optional.empty(), result);
    }

    @Test
    void deleteByCustomKey_ok() {
        assertThrows(NotImplementedException.class, () -> service.deleteByCustomKey(null));
    }

    @Test
    void setCustomSearchKey_ok() {
        assertThrows(NotImplementedException.class, () -> service.setCustomSearchKey(attachmentTypeNTTMock, null));
    }
}
