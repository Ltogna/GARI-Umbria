package com.abacogroup.agri.applicationforms.pua;

public class DbMigrate {
    public static void main(String[] args) throws Exception {
        ApplicationFormsModuleApplication.main(new String[] { "db", "migrate", "config.yml" });
    }
}
