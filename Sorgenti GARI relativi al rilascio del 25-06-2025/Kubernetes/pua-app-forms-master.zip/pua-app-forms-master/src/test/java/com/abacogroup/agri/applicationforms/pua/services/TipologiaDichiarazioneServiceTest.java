package com.abacogroup.agri.applicationforms.pua.services;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.time.OffsetDateTime;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.abacogroup.agri.applicationforms.pua.core.mappers.TipologiaDichiarazioneMapper;
import com.abacogroup.agri.applicationforms.pua.core.model.dto.TipologiaDichiarazioneDTO;
import com.abacogroup.agri.applicationforms.pua.db.dao.TipologiaDichiarazioneDAO;
import com.abacogroup.agri.applicationforms.pua.db.ntt.TipologiaDichiarazioneNTT;
import com.abacogroup.agri.applicationforms.pua.services.common.ApplicationFacadeService;
import com.abacogroup.applicationworkflowsdk.model.io.output.ApplicationDetailsPublicDTO;

/**
 * 
 * @author Emanuele Crocilla
 *
 */
@ExtendWith(MockitoExtension.class)
class TipologiaDichiarazioneServiceTest extends AbstractServiceTest {

	@Mock
    private TipologiaDichiarazioneDAO tipologiaDichiarazioneDAO;

    @Mock
    private TipologiaDichiarazioneMapper mapper;

    @InjectMocks
    private TipologiaDichiarazioneService tipologiaDichiarazioneService;

    @Mock
	private ApplicationFacadeService applicationFacadeService;

    @BeforeEach
	protected void init() {
		
//		tipologiaDichiarazioneService = new TipologiaDichiarazioneService(tipologiaDichiarazioneDAO, tipologiaDichiarazioneMock);
	}

    @Test
    void testGetSuccess() {
        
        TipologiaDichiarazioneNTT nttMock = TipologiaDichiarazioneNTT.builder()
                .pkid(1L)
                .applicationId(APPLICATION_ID)
                .year(YEAR)
                .dtInsert(OffsetDateTime.now())
                .dtDelete(OffsetDateTime.MAX)
                .build();
        
        ApplicationDetailsPublicDTO mockApplicationDetailsPublicDTO = ApplicationDetailsPublicDTO.builder()
        		.build();
        
        when(tipologiaDichiarazioneDAO.getByApplicationId(APPLICATION_ID)).thenReturn(nttMock);

        TipologiaDichiarazioneDTO expectedDTO = TipologiaDichiarazioneDTO.builder()
                .applicationId(APPLICATION_ID)
                .year(YEAR)
                .build();
        when(mapper.entityToDto(nttMock)).thenReturn(expectedDTO);
        
        when(applicationFacadeService.callForApplicationDetails(TENANT, APPLICATION_ID, LOGGED_USER, LANGUAGE))
        	.thenReturn(mockApplicationDetailsPublicDTO);
        
        TipologiaDichiarazioneDTO result = tipologiaDichiarazioneService.get(LOGGED_USER, TENANT, APPLICATION_ID);
        
        assertNotNull(result);
        assertEquals(expectedDTO, result);
        verify(tipologiaDichiarazioneDAO).getByApplicationId(APPLICATION_ID);
        verify(mapper).entityToDto(nttMock);
    }

    @Test
    void testGetThrowsExceptionWhenNotFound() {
    	
    	ApplicationDetailsPublicDTO mockApplicationDetailsPublicDTO = ApplicationDetailsPublicDTO.builder()
        		.build();

        when(applicationFacadeService.callForApplicationDetails(TENANT, APPLICATION_ID, LOGGED_USER, LANGUAGE))
        	.thenReturn(mockApplicationDetailsPublicDTO);
        
        when(tipologiaDichiarazioneDAO.getByApplicationId(APPLICATION_ID)).thenReturn(null);

        TipologiaDichiarazioneDTO result = tipologiaDichiarazioneService.get(LOGGED_USER, TENANT, APPLICATION_ID);

        // Act & Assert
        verify(tipologiaDichiarazioneDAO).getByApplicationId(APPLICATION_ID);
        assertNull(result);
    }

    @Test
    void testInsert() {
        
        TipologiaDichiarazioneDTO dto = TipologiaDichiarazioneDTO.builder()
                .applicationId(APPLICATION_ID)
                .year(YEAR)
                .flOrganicFert(true)
                .flLivestocks(false)
                .userIdInsert(LOGGED_USER_ID)
                .build();

        TipologiaDichiarazioneNTT ntt = TipologiaDichiarazioneNTT.builder()
                .applicationId(APPLICATION_ID)
                .year(YEAR)
                .flOrganicFert((short) 1)
                .flLivestocks((short) 0)
                .dtInsert(OffsetDateTime.now())
                .userIdInsert(LOGGED_USER_ID)
                .build();
        
		when(mapper.entityToDto(ntt)) .thenReturn(dto);
		
        when(tipologiaDichiarazioneDAO.getByApplicationId(APPLICATION_ID)).thenReturn(ntt);
        
        doNothing().when(applicationFacadeService).verifyAcceptDispositiveCalls(LOGGED_USER, TENANT, APPLICATION_ID, OPTION_CONFIG_ID);
        
        TipologiaDichiarazioneDTO result = 
        		tipologiaDichiarazioneService.insert(LOGGED_USER, TENANT, APPLICATION_ID, OPTION_CONFIG_ID, COMPILE_STATUS_IDENTIFIER, dto);
        
        assertNotNull(result);
        verify(tipologiaDichiarazioneDAO).insert(any(TipologiaDichiarazioneNTT.class));
//        verify(mapper).dtoToEntity(dto);
    }

    @Test
    void testDelete() {

        TipologiaDichiarazioneNTT ntt = TipologiaDichiarazioneNTT.builder()
                .applicationId(APPLICATION_ID)
                .build();
        
        doNothing().when(applicationFacadeService).verifyAcceptDispositiveCalls(LOGGED_USER, TENANT, APPLICATION_ID, OPTION_CONFIG_ID);

        when(tipologiaDichiarazioneDAO.getByApplicationId(APPLICATION_ID)).thenReturn(ntt);
        
        boolean result = tipologiaDichiarazioneService.delete(LOGGED_USER, TENANT, APPLICATION_ID, OPTION_CONFIG_ID, COMPILE_STATUS_IDENTIFIER);
        
        assertTrue(result);
        verify(tipologiaDichiarazioneDAO).expire(any(TipologiaDichiarazioneNTT.class));
    }

    @Test
    void testDeleteWhenNotFound() {

    	doNothing().when(applicationFacadeService).verifyAcceptDispositiveCalls(LOGGED_USER, TENANT, APPLICATION_ID, OPTION_CONFIG_ID);
    	
        when(tipologiaDichiarazioneDAO.getByApplicationId(APPLICATION_ID)).thenReturn(null);
        
        boolean result = tipologiaDichiarazioneService.delete(LOGGED_USER, TENANT, APPLICATION_ID, OPTION_CONFIG_ID, COMPILE_STATUS_IDENTIFIER);
        
        assertFalse(result);
        verify(tipologiaDichiarazioneDAO).getByApplicationId(APPLICATION_ID);
    }
    
    @Test
    void testInsertWithArgumentCaptor() {
        
        TipologiaDichiarazioneDTO dto = TipologiaDichiarazioneDTO.builder()
                .applicationId(APPLICATION_ID)
                .year(YEAR)
                .flOrganicFert(true)
                .flLivestocks(false)
                .userIdInsert(LOGGED_USER_ID)
                .build();

        TipologiaDichiarazioneNTT ntt = TipologiaDichiarazioneNTT.builder()
                .applicationId(APPLICATION_ID)
                .year(YEAR)
                .flOrganicFert((short) 1)
                .flLivestocks((short) 0)
                .dtInsert(OffsetDateTime.now())
                .userIdInsert(LOGGED_USER_ID)
                .build();
        
        doNothing().when(applicationFacadeService).verifyAcceptDispositiveCalls(LOGGED_USER, TENANT, APPLICATION_ID, OPTION_CONFIG_ID);
        
        when(tipologiaDichiarazioneDAO.getByApplicationId(APPLICATION_ID)).thenReturn(ntt);
        
        when(mapper.entityToDto(ntt)) .thenReturn(dto);
        
        tipologiaDichiarazioneService.insert(LOGGED_USER, TENANT, APPLICATION_ID, OPTION_CONFIG_ID, COMPILE_STATUS_IDENTIFIER, dto);
        
        ArgumentCaptor<TipologiaDichiarazioneNTT> captor = ArgumentCaptor.forClass(TipologiaDichiarazioneNTT.class);
        verify(tipologiaDichiarazioneDAO).insert(captor.capture());

        TipologiaDichiarazioneNTT capturedNtt = captor.getValue();
        assertNotNull(capturedNtt);
        assertEquals(APPLICATION_ID, capturedNtt.getApplicationId());
        assertEquals(YEAR, capturedNtt.getYear());
        assertEquals((short) 1, capturedNtt.getFlOrganicFert());
        assertEquals((short) 0, capturedNtt.getFlLivestocks());
        assertEquals(LOGGED_USER_ID, capturedNtt.getUserIdInsert());
    }

    @Test
    void testDeleteWithArgumentCaptor() {

        TipologiaDichiarazioneNTT ntt = TipologiaDichiarazioneNTT.builder()
                .applicationId(APPLICATION_ID)
                .build();
        
        doNothing().when(applicationFacadeService).verifyAcceptDispositiveCalls(LOGGED_USER, TENANT, APPLICATION_ID, OPTION_CONFIG_ID);

        when(tipologiaDichiarazioneDAO.getByApplicationId(APPLICATION_ID)).thenReturn(ntt);
        
        boolean result = tipologiaDichiarazioneService.delete(LOGGED_USER, TENANT, APPLICATION_ID, OPTION_CONFIG_ID, COMPILE_STATUS_IDENTIFIER);
        
        assertTrue(result);

        ArgumentCaptor<TipologiaDichiarazioneNTT> captor = ArgumentCaptor.forClass(TipologiaDichiarazioneNTT.class);
        verify(tipologiaDichiarazioneDAO).expire(captor.capture());

        TipologiaDichiarazioneNTT capturedNtt = captor.getValue();
        assertNotNull(capturedNtt);
        assertEquals(APPLICATION_ID, capturedNtt.getApplicationId());
        assertEquals(LOGGED_USER_ID, capturedNtt.getUserIdDelete());
    }
}
