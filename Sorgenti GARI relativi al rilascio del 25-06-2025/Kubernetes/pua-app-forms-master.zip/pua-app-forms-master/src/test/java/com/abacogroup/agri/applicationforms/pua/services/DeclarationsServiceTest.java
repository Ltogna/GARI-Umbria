package com.abacogroup.agri.applicationforms.pua.services;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Collections;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.abacogroup.agri.applicationforms.pua.common.dynamidocument.DynamicDocumentService;
import com.abacogroup.agri.applicationforms.pua.core.exceptions.DocDefNotFoundRuntimeException;
import com.abacogroup.agri.applicationforms.pua.core.model.dto.AppfPuaDynamicDocumentsDTO;
import com.abacogroup.agri.applicationforms.pua.core.model.dto.DeclarationsDTO;
import com.abacogroup.agri.applicationforms.pua.core.model.dto.DeclarationsWithDefinitionDTO;
import com.abacogroup.agri.applicationforms.pua.services.common.AppfPuaDynamicDocumentsCrudService;
import com.abacogroup.agri.applicationforms.pua.services.common.ApplicationFacadeService;
import com.abacogroup.dynamicdocuments.bean.Document;
import com.abacogroup.dynamicdocuments.bean.DocumentDefinition;
import com.abacogroup.dynamicdocuments.services.DocumentService;
import com.abacogroup.dynamicdocuments.services.DocumentTypeService;

@ExtendWith(MockitoExtension.class)
class DeclarationsServiceTest extends AbstractServiceTest {
    
	@Mock
	private DocumentService documentService;

	@Mock
	private DocumentTypeService documentTypeService;
	
	@Mock
    private AppfPuaDynamicDocumentsCrudService appfPuaDynamicDocumentsCrudServiceMock;
	
	@Mock
	private ApplicationFacadeService applicationFacadeService;
   
    @InjectMocks
    private DynamicDocumentService appfPuaDynamicDocumentServiceMock;

    private final AppfPuaDynamicDocumentsDTO dynamicDocumentsDTO = AppfPuaDynamicDocumentsDTO.builder()
            .applicationId(APPLICATION_ID)
            .documentCode(CODE_1)
            .documentId(DOCUMENT_ID)
            .id(ID)
            .build();

    @Test
    void getDeclarations_present_ok() {
        DocumentDefinition documentDefinition1 = new DocumentDefinition();
        documentDefinition1.setCode(CODE_1);
        documentDefinition1.setDescription(DESCRIPTION_1);
        documentDefinition1.setVersion(VERSION_1);
        DocumentDefinition documentDefinition2 = new DocumentDefinition();
        documentDefinition2.setCode(CODE_2);
        documentDefinition2.setDescription(DESCRIPTION_2);
        documentDefinition2.setVersion(VERSION_2);

        Document document = new Document();
        document.setValidFrom(VALID_FROM);
        document.setValidTo(VALID_TO);

        DeclarationsWithDefinitionDTO expectedOutput = DeclarationsWithDefinitionDTO.builder()
                .document(document)
                .documentDefinition(documentDefinition1)
                .build();

        when(appfPuaDynamicDocumentsCrudServiceMock.findByApplicationIdAndDocumentCode(APPLICATION_ID, CODE_1))
                .thenReturn(dynamicDocumentsDTO);
        when(documentService.getDocumentFromId(DOCUMENT_ID))
                .thenReturn(document);
        when(documentTypeService.getDocumentDefinition(TENANT, CODE_1))
                .thenReturn(Optional.of(documentDefinition1));
        
//        doNothing().when(applicationFacadeService).verifyAcceptDispositiveCalls(LOGGED_USER, TENANT, APPLICATION_ID, FORM_CONFIG_ID);

        DeclarationsWithDefinitionDTO result = appfPuaDynamicDocumentServiceMock.getDeclarations(LOGGED_USER, TENANT, APPLICATION_ID, FORM_CONFIG_ID, CODE_1);

        assertEquals(expectedOutput, result);
    }

    @Test
    void getDeclarations_notPresent_ok() {
        DocumentDefinition documentDefinition1 = new DocumentDefinition();
        documentDefinition1.setCode(CODE_1);
        documentDefinition1.setDescription(DESCRIPTION_1);
        documentDefinition1.setVersion(VERSION_1);
        DocumentDefinition documentDefinition2 = new DocumentDefinition();
        documentDefinition2.setCode(CODE_2);
        documentDefinition2.setDescription(DESCRIPTION_2);
        documentDefinition2.setVersion(VERSION_2);

        DeclarationsWithDefinitionDTO expectedOutput = DeclarationsWithDefinitionDTO.builder()
                .documentDefinition(documentDefinition1)
                .build();

        when(appfPuaDynamicDocumentsCrudServiceMock.findByApplicationIdAndDocumentCode(APPLICATION_ID, CODE_1))
                .thenReturn(null);
        when(documentTypeService.getDocumentDefinition(TENANT, CODE_1))
                .thenReturn(Optional.of(documentDefinition1));

        DeclarationsWithDefinitionDTO result = appfPuaDynamicDocumentServiceMock.getDeclarations(LOGGED_USER, TENANT, APPLICATION_ID, FORM_CONFIG_ID, CODE_1);

        assertEquals(expectedOutput, result);
    }

    @Test
    void insertOrUpdateDeclarations_present_ok() {
        DocumentDefinition documentDefinition1 = new DocumentDefinition();
        documentDefinition1.setCode(CODE_1);
        documentDefinition1.setDescription(DESCRIPTION_1);
        documentDefinition1.setVersion(VERSION_1);
        DocumentDefinition documentDefinition2 = new DocumentDefinition();
        documentDefinition2.setCode(CODE_2);
        documentDefinition2.setDescription(DESCRIPTION_2);
        documentDefinition2.setVersion(VERSION_2);

        Document document = new Document();
        document.setValidFrom(VALID_FROM);
        document.setValidTo(VALID_TO);
        document.setFields(Collections.emptyMap());

        DeclarationsDTO expectedOutput = DeclarationsDTO.builder()
                .document(document)
                .build();

        when(appfPuaDynamicDocumentsCrudServiceMock.findByApplicationIdAndDocumentCode(APPLICATION_ID, CODE_1))
                .thenReturn(dynamicDocumentsDTO);
        
        when(documentService.getDocumentFromId(DOCUMENT_ID))
                .thenReturn(document);
 
        DeclarationsDTO result =
                appfPuaDynamicDocumentServiceMock.insertOrUpdateDeclarations(TENANT, LOGGED_USER, APPLICATION_ID, document, CODE_1,
                		 true, COMPILE_STATUS_IDENTIFIER, COMPILE_STATUS_ENUM, FORM_CONFIG_ID);

        verify(documentService, times(1)).updateDocument(DOCUMENT_ID, document, LOGGED_USER.getUserId());

        assertEquals(expectedOutput, result);
    }

    @Test
    void insertOrUpdateDeclarations_notPresent_ok() {
        DocumentDefinition documentDefinition1 = new DocumentDefinition();
        documentDefinition1.setCode(CODE_1);
        documentDefinition1.setDescription(DESCRIPTION_1);
        documentDefinition1.setVersion(VERSION_1);
        DocumentDefinition documentDefinition2 = new DocumentDefinition();
        documentDefinition2.setCode(CODE_2);
        documentDefinition2.setDescription(DESCRIPTION_2);
        documentDefinition2.setVersion(VERSION_2);

        Document document = new Document();
        document.setValidFrom(VALID_FROM);
        document.setValidTo(VALID_TO);
        document.setFields(Collections.emptyMap());

        AppfPuaDynamicDocumentsDTO createdDynamicDocumentsDTO = AppfPuaDynamicDocumentsDTO.builder()
                .applicationId(APPLICATION_ID)
                .documentId(CREATED_DOCUMENT_ID)
                .documentCode(CODE_1)
                .build();

        DeclarationsDTO expectedOutput = DeclarationsDTO.builder()
                .document(document)
                .build();

        when(appfPuaDynamicDocumentsCrudServiceMock.findByApplicationIdAndDocumentCode(APPLICATION_ID, CODE_1))
                .thenReturn(null);
        when(documentService.insertDocument(TENANT, CODE_1, document, LOGGED_USER.getUserId(), null, null))
                .thenReturn(CREATED_DOCUMENT_ID);
        when(appfPuaDynamicDocumentsCrudServiceMock.insert(createdDynamicDocumentsDTO))
                .thenReturn(createdDynamicDocumentsDTO);
        when(documentService.getDocumentFromId(createdDynamicDocumentsDTO.getDocumentId()))
                .thenReturn(document);

        DeclarationsDTO result = appfPuaDynamicDocumentServiceMock.insertOrUpdateDeclarations(TENANT, LOGGED_USER, APPLICATION_ID, document, CODE_1,
        		true, COMPILE_STATUS_IDENTIFIER, COMPILE_STATUS_ENUM, FORM_CONFIG_ID);

        assertEquals(expectedOutput, result);
    }

    @Test
    void upsertDeclarations_ok() {
        DocumentDefinition documentDefinition1 = new DocumentDefinition();
        documentDefinition1.setCode(CODE_1);
        documentDefinition1.setDescription(DESCRIPTION_1);
        documentDefinition1.setVersion(VERSION_1);
        DocumentDefinition documentDefinition2 = new DocumentDefinition();
        documentDefinition2.setCode(CODE_2);
        documentDefinition2.setDescription(DESCRIPTION_2);
        documentDefinition2.setVersion(VERSION_2);

        Document document = new Document();
        document.setValidFrom(VALID_FROM);
        document.setValidTo(VALID_TO);
        document.setFields(Collections.emptyMap());

        DeclarationsDTO expectedOutput = DeclarationsDTO.builder()
                .document(document)
                .build();

        when(appfPuaDynamicDocumentsCrudServiceMock.findByApplicationIdAndDocumentCode(APPLICATION_ID, CODE_1))
                .thenReturn(dynamicDocumentsDTO);
        
        when(documentService.getDocumentFromId(DOCUMENT_ID))
                .thenReturn(document);

        DeclarationsDTO result =
                appfPuaDynamicDocumentServiceMock.upsertDeclarations(TENANT, LOGGED_USER, APPLICATION_ID, document, CODE_1,
                		true, COMPILE_STATUS_IDENTIFIER, COMPILE_STATUS_ENUM, FORM_CONFIG_ID);

        assertEquals(expectedOutput, result);
    }

    @Test
    void getDeclarations_ko() {
        DocumentDefinition documentDefinition1 = new DocumentDefinition();
        documentDefinition1.setCode(CODE_1);
        documentDefinition1.setDescription(DESCRIPTION_1);
        documentDefinition1.setVersion(VERSION_1);
        DocumentDefinition documentDefinition2 = new DocumentDefinition();
        documentDefinition2.setCode(CODE_2);
        documentDefinition2.setDescription(DESCRIPTION_2);
        documentDefinition2.setVersion(VERSION_2);

        Document document = new Document();
        document.setValidFrom(VALID_FROM);
        document.setValidTo(VALID_TO);

        when(appfPuaDynamicDocumentsCrudServiceMock.findByApplicationIdAndDocumentCode(APPLICATION_ID, CODE_1))
                .thenReturn(dynamicDocumentsDTO);
        when(documentService.getDocumentFromId(DOCUMENT_ID))
                .thenReturn(document);
        when(documentTypeService.getDocumentDefinition(TENANT, CODE_1))
                .thenReturn(Optional.empty());

        assertThrows(DocDefNotFoundRuntimeException.class, () ->
                appfPuaDynamicDocumentServiceMock.getDeclarations(LOGGED_USER, TENANT, APPLICATION_ID, FORM_CONFIG_ID, CODE_1));
    }

}
