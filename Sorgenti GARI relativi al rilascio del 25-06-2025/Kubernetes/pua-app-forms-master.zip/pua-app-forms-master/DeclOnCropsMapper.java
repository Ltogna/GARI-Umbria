package com.abacogroup.agri.applicationforms.pua.core.mappers;

import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;
import org.mapstruct.factory.Mappers;

import com.abacogroup.agri.applicationforms.pua.core.model.dto.DeclOnCropsDTO;
import com.abacogroup.agri.applicationforms.pua.core.model.dto.DeclOnCropsPrevEffluentsDTO;
import com.abacogroup.agri.applicationforms.pua.db.ntt.DeclOnCropsNTT;
import com.abacogroup.agri.applicationforms.pua.db.ntt.DeclOnCropsPrevEffluentsNTT;
import com.abacogroup.agri.applicationforms.pua.util.GenericUtility;
import com.abacogroup.jdbi.mapper.AbsoluteDateMapper;

/**
 * 
 * @author Emanuele Crocilla
 *
 */
@Mapper(uses = AbsoluteDateMapper.class)
public interface DeclOnCropsMapper extends EntityMapper<DeclOnCropsDTO, DeclOnCropsNTT> {

	DeclOnCropsMapper INSTANCE = Mappers.getMapper(DeclOnCropsMapper.class);

	@InheritInverseConfiguration()
	@Mapping(source = "flZvn", target = "flZvn", qualifiedByName = "shortToBoolean")
	@Mapping(source = "cycle", target = "cycle", qualifiedByName = "stringToInt")
	@Mapping(source = "previousEffluents", target = "previousEffluents", qualifiedByName = "mapPrevEffluentsFromNTTtoDTO")
	DeclOnCropsDTO entityToDto(DeclOnCropsNTT entity);

	@Mapping(source = "id", target = "pkid")
	@Mapping(source = "flZvn", target = "flZvn", qualifiedByName = "booleanToShort")
	@Mapping(source = "cycle", target = "cycle", qualifiedByName = "intToString")
	@Mapping(source = "previousEffluents", target = "previousEffluents", qualifiedByName = "mapPrevEffluentsFromDTOtoNTT")
	DeclOnCropsNTT dtoToEntity(DeclOnCropsDTO dto);

	@Named("mapPrevEffluentsFromDTOtoNTT")
	default List<DeclOnCropsPrevEffluentsNTT> mapPrevEffluentsFromDTOtoNTT(List<DeclOnCropsPrevEffluentsDTO> prevEffluents) {
		return prevEffluents == null ? Collections.emptyList() : prevEffluents.stream()
				.map(DeclOnCropsPrevEffluentsMapper.INSTANCE::dtoToEntity)
				.collect(Collectors.toList());

	}
	
	@Named("mapPrevEffluentsFromNTTtoDTO")
	default List<DeclOnCropsPrevEffluentsDTO> mapPrevEffluentsFromNTTtoDTO(List<DeclOnCropsPrevEffluentsNTT> prevEffluents) {
		return prevEffluents == null ? Collections.emptyList() : prevEffluents.stream()
				.map(DeclOnCropsPrevEffluentsMapper.INSTANCE::entityToDto)
				.collect(Collectors.toList());

	}
	
	@Named("shortToBoolean")
	default boolean shortToBoolean(short value) {
		return value != 0;
	}

	@Named("booleanToShort")
	default short booleanToShort(boolean value) {
		return value ? (short) 1 : (short) 0;
	}
	
	@Named("stringToInt")
	default Integer stringToInt(String s) {
		return GenericUtility.isDigit(s) ? Integer.parseInt(s) : null;
	}

	@Named("intToString")
	default String intToString(Integer i) {
		return String.valueOf(i);
	}
	
}
