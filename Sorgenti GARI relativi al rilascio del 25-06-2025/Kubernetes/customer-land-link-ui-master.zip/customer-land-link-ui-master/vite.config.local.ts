import vue from "@vitejs/plugin-vue";
import { execSync } from "child_process";
import { fileURLToPath, URL } from "url";
import { defineConfig } from "vite";
import { viteStaticCopy } from "vite-plugin-static-copy";
import VueDevTools from "vite-plugin-vue-devtools";
import nodePackage from "./package.json";
import { BASE } from "./src/constants";

process.env.VITE_APP_VERSION = nodePackage.version;
process.env.VITE_APP_GIT_COMMIT = execSync("git rev-parse --short=8 HEAD")
  .toString()
  .trim();

// https://vitejs.dev/config/
export default defineConfig({
  plugins: [
    viteStaticCopy({
      targets: [
        {
          src: "node_modules/bootstrap-italia/dist/**/*",
          dest: "bootstrap-italia/dist",
        },
      ],
    }),
    vue(),
    VueDevTools(),
  ],
  base: BASE,
  resolve: {
    alias: {
      "@": fileURLToPath(new URL("./src", import.meta.url)),
    },
  },
  build: {
    rollupOptions: {
      output: {
        entryFileNames: "[name].[hash].js",
      },
    },
  },
  server: {
    proxy: {
      "/lpis-server-api": {
        target: "http://localhost:8080/",
        changeOrigin: true,
      },
      "/map-upload": {
        target: "https://iacs-dev.fe.abacogroup.eu/",
        changeOrigin: true,
      },
      "/sso2": {
        target: "https://iacs-dev.fe.abacogroup.eu/",
        secure: false,
        changeOrigin: true,
      },
      "/geoproxy": {
        target: "https://iacs-dev.fe.abacogroup.eu/",
        secure: false,
        changeOrigin: true,
      },
      "/dev-proxy": {
        target: "https://iacs-dev.fe.abacogroup.eu/",
        secure: false,
        changeOrigin: true,
      },
    },
  },
});
