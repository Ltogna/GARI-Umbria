# Changelog

### [v2.0.7](https://gitlab.fe.abacogroup.eu/new-agri/customer-land-link-ui/compare/v2.0.6...v2.0.7) (2025-04-03)

#### Fixes

* :bug: #126955 resolve extra translations path, closes
[#126955](https://abacogroup.easyredmine.com/issues/126955)

### [v2.0.6](https://gitlab.fe.abacogroup.eu/new-agri/customer-land-link-ui/compare/v2.0.5...v2.0.6) (2024-11-07)

#### Features

* :sparkles: #156185 hide back button as param, closes
[#156185](https://abacogroup.easyredmine.com/issues/156185)
* :sparkles: added sonarqube-check script

### [v2.0.5](https://gitlab.fe.abacogroup.eu/new-agri/customer-land-link-ui/compare/v2.0.4...v2.0.5) (2024-09-02)

#### Fixes

* :sparkles: #148893 allow to add documents to group in future, closes
[#148893](https://abacogroup.easyredmine.com/issues/148893)

#### Other

* :memo: update changelog

### [v2.0.4](https://gitlab.fe.abacogroup.eu/new-agri/customer-land-link-ui/compare/v2.0.3...v2.0.4) (2024-07-16)

#### Features

* :sparkles: #143551 formatting list of conductors, closes
[#143551](https://abacogroup.easyredmine.com/issues/143551)
* :sparkles: #143551 improved error messages, closes
[#143551](https://abacogroup.easyredmine.com/issues/143551)
* :sparkles: #143551 added checkbox always, closes
[#143551](https://abacogroup.easyredmine.com/issues/143551)
* :sparkles: #141156 group modification until the night, closes
[#141156](https://abacogroup.easyredmine.com/issues/141156)

#### Fixes

* :bug: #141156 fixed form validation, closes
[#141156](https://abacogroup.easyredmine.com/issues/141156)

#### Other

* :green_heart: fixed CI
* :green_heart: fixed CI
* :memo: update changelog
* :memo: update documentation

### [v2.0.3](https://gitlab.fe.abacogroup.eu/new-agri/customer-land-link-ui/compare/v2.0.2...v2.0.3) (2024-05-30)

#### Fixes

* :bug: #141481 fixed double material error button, closes
[#141481](https://abacogroup.easyredmine.com/issues/141481)

#### Other

* :memo: update changelog

### [v2.0.2](https://gitlab.fe.abacogroup.eu/new-agri/customer-land-link-ui/compare/v2.0.1...v2.0.2) (2024-05-30)

#### Fixes

* :bug: #139066 - Reset Day From if Title Type Change Disallows Future Dates,
closes [#139066](https://abacogroup.easyredmine.com/issues/139066)

#### Other

* :memo: update changelog

### [v2.0.1](https://gitlab.fe.abacogroup.eu/new-agri/customer-land-link-ui/compare/v2.0.0...v2.0.1) (2024-05-29)

#### Fixes

* :globe_with_meridians: #141072 fixed modal title, closes
[#141072](https://abacogroup.easyredmine.com/issues/141072)
* :lipstick: #141071 fixed icon styles, closes
[#141071](https://abacogroup.easyredmine.com/issues/141071)

#### Other

* :memo: update changelog

## [v2.0.0](https://gitlab.fe.abacogroup.eu/new-agri/customer-land-link-ui/compare/v1.1.1...v2.0.0) (2024-05-27)

### Features

* :sparkles: #139110 improved dynamic document on land links, closes
[#139110](https://abacogroup.easyredmine.com/issues/139110)
* :sparkles: improved params for documentsInfo
* :sparkles: added icons to documentsInfo
* :sparkles: improved api's documents landlink
* :sparkles: #139110 get land links documents files, closes
[#139110](https://abacogroup.easyredmine.com/issues/139110)
* :sparkles: improved documents
* :sparkles: improved infoDocuments
* :sparkles: improved api's
* :sparkles: #139957  accepted zero percentage to conduction, closes
[#139957](https://abacogroup.easyredmine.com/issues/139957)
* :sparkles: improved implementation for Document info
* :sparkles: start implementing metadata

### Fixes

* :lipstick: fixed checkbox alignment
* :bug: fixed group document empty
* :bug: fixed back link

### Other

* :memo: update changelog
* :sparkles: #139110 back to land link, closes
[#139110](https://abacogroup.easyredmine.com/issues/139110)
* :sparkles: added route for backbutton
* :arrow_up: update dependencies

### [v1.1.1](https://gitlab.fe.abacogroup.eu/new-agri/customer-land-link-ui/compare/v1.1.0...v1.1.1) (2024-05-20)

#### Fixes

* :bug: #138997 ficed goBack on conducted parcels, closes
[#138997](https://abacogroup.easyredmine.com/issues/138997)
* :sparkles: #138997 fixed preserve filter on go back, closes
[#138997](https://abacogroup.easyredmine.com/issues/138997)
* :sparkles: #1000929 fixed preserve filter on go back, closes
[#1000929](https://abacogroup.easyredmine.com/issues/1000929)

#### Other

* :memo: update changelog

## [v1.1.0](https://gitlab.fe.abacogroup.eu/new-agri/customer-land-link-ui/compare/v1.0.28...v1.1.0) (2024-05-17)

### Features

* :sparkles: #139363 isEditable fixed dayFrom, closes
[#139363](https://abacogroup.easyredmine.com/issues/139363)
* :sparkles: #139363 delete only if a group is in the future, closes
[#139363](https://abacogroup.easyredmine.com/issues/139363)
* :sparkles: #139096 improved delete single land link, closes
[#139096](https://abacogroup.easyredmine.com/issues/139096)
* :sparkles: #139096 impoved delete group, closes
[#139096](https://abacogroup.easyredmine.com/issues/139096)
* :sparkles: #139363 added allowFutureDayFrom on clone group, closes
[#139363](https://abacogroup.easyredmine.com/issues/139363)
* :sparkles: #139363 added allowFutureDayFrom on edit group, closes
[#139363](https://abacogroup.easyredmine.com/issues/139363)
* :sparkles: #136342 improved form day_editable, closes
[#136342](https://abacogroup.easyredmine.com/issues/136342)
* :sparkles: #139363 added allowFutureDayFrom on group creation, closes
[#139363](https://abacogroup.easyredmine.com/issues/139363)
* :sparkles: #139112 added conductor links, closes
[#139112](https://abacogroup.easyredmine.com/issues/139112)
* :sparkles: #139096 start implementing api for delete, closes
[#139096](https://abacogroup.easyredmine.com/issues/139096)
* :sparkles: start implementing feature for delete

### Fixes

* :bug: #139363 fixed model, closes
[#139363](https://abacogroup.easyredmine.com/issues/139363)
* :bug: #139363 fixed model, closes
[#139363](https://abacogroup.easyredmine.com/issues/139363)

### Other

* :coffin: #139112 removed unsude code, closes
[#139112](https://abacogroup.easyredmine.com/issues/139112)
* :memo: update changelog

### [v1.0.28](https://gitlab.fe.abacogroup.eu/new-agri/customer-land-link-ui/compare/v1.0.27...v1.0.28) (2024-05-08)

#### Features

* :sparkles: #136342 edit group day_editable, closes
[#136342](https://abacogroup.easyredmine.com/issues/136342)
* :sparkles: improved model
* :sparkles: start implementing day_editable

#### Fixes

* :arrow_down: downgrade eslint

#### Other

* :memo: added changelog
* :coffin: removed unsued code
* :bulb: remove comment mocked code
* :arrow_up: update dependencies

### [v1.0.27](https://gitlab.fe.abacogroup.eu/new-agri/customer-land-link-ui/compare/v1.0.26...v1.0.27) (2024-04-26)

#### Fixes

* :bug: #137647 fixed labels, closes
[#137647](https://abacogroup.easyredmine.com/issues/137647)

#### Other

* :arrow_up: update dependencies

### [v1.0.26](https://gitlab.fe.abacogroup.eu/new-agri/customer-land-link-ui/compare/v1.0.25...v1.0.26) (2024-04-04)

### [v1.0.25](https://gitlab.fe.abacogroup.eu/new-agri/customer-land-link-ui/compare/v1.0.24...v1.0.25) (2024-03-15)

#### Fixes

* :bug: #134117 fixed date diplay, closes
[#134117](https://abacogroup.easyredmine.com/issues/134117)

#### Other

* :globe_with_meridians: update translations

### [v1.0.24](https://gitlab.fe.abacogroup.eu/new-agri/customer-land-link-ui/compare/v1.0.23...v1.0.24) (2024-03-15)

#### Fixes

* :bug: fixed conduction pencentage with not gis parcels
* :globe_with_meridians: fix locales

### [v1.0.23](https://gitlab.fe.abacogroup.eu/new-agri/customer-land-link-ui/compare/v1.0.22...v1.0.23) (2024-03-13)

#### Features

* :sparkles: improved sector search
* :rotating_light: make sorarqube happy
* :alien: update party model
* :sparkles: added validations to search form
* :sparkles: changed api blocks
* :sparkles: added search filter level param and fixed styles
* :sparkles: improved research and validation form
* :sparkles: hide link to view

#### Fixes

* :bug: fix tab
* :bug: fixed show link viewer

#### Other

* :lipstick: update multiselect styles
* :green_heart: update CI
* :arrow_up: update
* :sparkles: removed tabindex

### [v1.0.22](https://gitlab.fe.abacogroup.eu/new-agri/customer-land-link-ui/compare/v1.0.21...v1.0.22) (2024-03-07)

#### Fixes

* :bug: reselt filter on start app
* :bug: reset filter on reload

#### Other

* :recycle: cleaning code

### [v1.0.21](https://gitlab.fe.abacogroup.eu/new-agri/customer-land-link-ui/compare/v1.0.20...v1.0.21) (2024-03-05)

#### Features

* :globe_with_meridians: #126955 added extra translations, closes
[#126955](https://abacogroup.easyredmine.com/issues/126955)
* :arrow_up: update dependencies

#### Other

* :green_heart: fixed CI
* :green_heart: fixed CI
* :green_heart: fixed CI
* :green_heart: fixed CI
* :green_heart: fixed CI

### [v1.0.20](https://gitlab.fe.abacogroup.eu/new-agri/customer-land-link-ui/compare/v1.0.19...v1.0.20) (2024-03-01)

### [v1.0.19](https://gitlab.fe.abacogroup.eu/new-agri/customer-land-link-ui/compare/v1.0.18...v1.0.19) (2024-02-29)

#### Features

* :arrow_down: downgrade dependencies

### [v1.0.18](https://gitlab.fe.abacogroup.eu/new-agri/customer-land-link-ui/compare/v1.0.17...v1.0.18) (2024-02-28)

#### Other

* :arrow_up: update dependencies

### [v1.0.17](https://gitlab.fe.abacogroup.eu/new-agri/customer-land-link-ui/compare/v1.0.16...v1.0.17) (2024-02-16)

#### Fixes

* :bug: fixed general bugs and clean code

#### Other

* :globe_with_meridians: sort translation json files

### [v1.0.16](https://gitlab.fe.abacogroup.eu/new-agri/customer-land-link-ui/compare/v1.0.15...v1.0.16) (2024-02-06)

### [v1.0.15](https://gitlab.fe.abacogroup.eu/new-agri/customer-land-link-ui/compare/v1.0.14...v1.0.15) (2024-01-29)

#### Features

* :sparkles: #129209 keep filter in memory during navigation, closes
[#129209](https://abacogroup.easyredmine.com/issues/129209)

### [v1.0.14](https://gitlab.fe.abacogroup.eu/new-agri/customer-land-link-ui/compare/v1.0.13...v1.0.14) (2024-01-22)

#### Fixes

* :bug: #128689 fixed percentage formatting, closes
[#128689](https://abacogroup.easyredmine.com/issues/128689)

### [v1.0.13](https://gitlab.fe.abacogroup.eu/new-agri/customer-land-link-ui/compare/v1.0.12...v1.0.13) (2024-01-15)

#### Features

* :sparkles: added schedule missed in the accordion

#### Fixes

* :bug: #127094 open viewer in new tab, closes
[#127094](https://abacogroup.easyredmine.com/issues/127094)
* :bug: #127094 open viewer in new tab, closes
[#127094](https://abacogroup.easyredmine.com/issues/127094)

### [v1.0.12](https://gitlab.fe.abacogroup.eu/new-agri/customer-land-link-ui/compare/v1.0.11...v1.0.12) (2024-01-05)

#### Features

* :coffin: removed unnecessary code

### [v1.0.11](https://gitlab.fe.abacogroup.eu/new-agri/customer-land-link-ui/compare/v1.0.10...v1.0.11) (2023-12-06)

#### Features

* :sparkles: Added workaround for land link summary view

#### Other

* :arrow_up: update dependencies
* :arrow_up: update depencencies
* :sparkles: removed crypto.randomUUID

### [v1.0.10](https://gitlab.fe.abacogroup.eu/new-agri/customer-land-link-ui/compare/v1.0.9...v1.0.10) (2023-11-28)

#### Fixes

* :lipstick: fixed accordion styles

### [v1.0.9](https://gitlab.fe.abacogroup.eu/new-agri/customer-land-link-ui/compare/v1.0.8...v1.0.9) (2023-11-28)

#### Other

* :globe_with_meridians: fixed pluralization

### [v1.0.8](https://gitlab.fe.abacogroup.eu/new-agri/customer-land-link-ui/compare/v1.0.7...v1.0.8) (2023-11-27)

#### Features

* :sparkles: update dependencies and removed cypress

#### Other

* :globe_with_meridians: #123713 added missing translation labels, closes
[#123713](https://abacogroup.easyredmine.com/issues/123713)
* :mute: removed console log

### [v1.0.7](https://gitlab.fe.abacogroup.eu/new-agri/customer-land-link-ui/compare/v1.0.6...v1.0.7) (2023-11-27)

### [v1.0.6](https://gitlab.fe.abacogroup.eu/new-agri/customer-land-link-ui/compare/v1.0.5...v1.0.6) (2023-11-27)

### [v1.0.5](https://gitlab.fe.abacogroup.eu/new-agri/customer-land-link-ui/compare/v1.0.4...v1.0.5) (2023-11-13)

#### Fixes

* 🐛 Added missing backUrl btn for dossier on "sub views"

### [v1.0.4](https://gitlab.fe.abacogroup.eu/new-agri/customer-land-link-ui/compare/v1.0.3...v1.0.4) (2023-11-13)

### [v1.0.3](https://gitlab.fe.abacogroup.eu/new-agri/customer-land-link-ui/compare/v1.0.2...v1.0.3) (2023-11-13)

### [v1.0.2](https://gitlab.fe.abacogroup.eu/new-agri/customer-land-link-ui/compare/v1.0.1...v1.0.2) (2023-11-06)

#### Fixes

* :bug: added crypto.randomUUID polyfill for non https mode
* :alien: Fixed change API response

### [v1.0.1](https://gitlab.fe.abacogroup.eu/new-agri/customer-land-link-ui/compare/v1.0.0...v1.0.1) (2023-10-23)

## [v1.0.0](https://gitlab.fe.abacogroup.eu/new-agri/customer-land-link-ui/compare/v0.0.6...v1.0.0) (2023-10-23)

### [v0.0.6](https://gitlab.fe.abacogroup.eu/new-agri/customer-land-link-ui/compare/v0.0.5...v0.0.6) (2023-09-14)

#### Other

* :arrow_up: update dependencies

### [v0.0.5](https://gitlab.fe.abacogroup.eu/new-agri/customer-land-link-ui/compare/v0.0.4...v0.0.5) (2023-09-12)

#### Features

* :iphone: responsive tables & better accessibility

#### Fixes

* :iphone: minor fix on responsive tables
* :bug: fixed GroupFilterBackButton
* :adhesive_bandage: fixed translations
* :globe_with_meridians: fixed path translations
* :bug: fixed landlink route
* :bug: add missing route
* :wrench: fixed config, loadfonts & pinia
* :bug: fixed imports
* :wheelchair: better accessibility

#### Other

* :globe_with_meridians: update translations
* :lipstick: update styles
* :wrench: update configs
* :label: welcome back types
* :arrow_up: update dependencies
* :rotating_light: remove warning on build
* :art: format code
* :globe_with_meridians: added translation
* :adhesive_bandage: minor route clean
* :label: clean types d.ts
* :art: format code
* :globe_with_meridians: add locales

### [v0.0.4](https://gitlab.fe.abacogroup.eu/new-agri/customer-land-link-ui/compare/v0.0.2...v0.0.4) (2023-06-09)

#### Features

* :bug: fix route navigation from group to landlink edit
* :sparkles: update date check
* :sparkles: create landlink detail page
* :sparkles: update visibility for close button (group and landlinks) by
settings api response value

#### Fixes

* :bug: removed max end date on group/landLink close bulk
* :bug: fix anomaly button renderization in group page
* :bug: fix error message
* :bug: fix landlink close form datepicker range
* :bug: fix visibility close landlink button in landlink form
* :bug: edit landlink closed visibility button in list

### v0.0.2 (2023-05-04)

#### Features

* :sparkles: create index to export summary sub feature
* :construction: update landlinks query params filter feature
* :construction: add landlink search by url query params on page mount
* :sparkles: update landlink summary component
* :sparkles: create land link summary list component and test page
* :sparkles: fix group page titles
* :recycle: refactor landlink submodule navigation
* :bug: fix round number and change trigger for land link form input fields
* :sparkles: improved dd schemas
* :sparkles: add succes notification on create group & add parcels to group
* :sparkles: add notification on success edit group
* :sparkles: readonly mode
* :sparkles: add date formatting from user data
* :construction: fix date format for landlink submodule, fix reset filter
landlink form
* :construction: document list
* :sparkles: add missing number formatting
* :sparkles: add dirty modal on add-parcels-group
* :bug: fixed navigation on save document
* :safety_vest: better error validationa & management on clone group
* :sparkles: add beforeunload alert on leave page
* :sparkles: show warning modal before leave add group page if form is dirty
* :sparkles: add anomalies modal
* :sparkles: disabled links when has not document on groups
* :sparkles: added Open viewer button in LandLinkFormView
* :sparkles: stop navigation if form is dirty
* :construction: start implementing anomalies modal
* :sparkles: single dd implementation
* :sparkles: add custom leave modal on clone group
* :sparkles: add custom leave modal on add & add-parcels group
* :sparkles: add leave warning modal
* :construction: update/delete dynamic document
* :sparkles: implemented add parcels to existing group, format code
* :sparkles: added addLankList model & api
* :construction: start implementing add parcels to existing group
* :construction: save document
* :sparkles: fixed tooltip for anomalies
* :construction: show dd forms
* :sparkles: added BiTooltip for anomalies
* :sparkles: fixed anomaly icon show condictions
* :sparkles: add missing links to map
* :sparkles: add link to viewer
* :passport_control: add route guard
* :passport_control: hid bulk accordion based on permissions, minor
permissions change
* :passport_control: add permissions on edit group
* :construction: added route for dd
* :passport_control: add permissions on add group button
* :sparkles: add permissions on group list
* :sparkles: add permissions composable
* :sparkles: hide flush button on clone
* :goal_net: better erro management on create/clone group
* :sparkles: better clone management
* :sparkles: implemented clone group
* :sparkles: implement modal for dd
* :sparkles: add parcel table selected on clone
* :alien: add api to get group parcels
* :sparkles: fixed glitch buttons
* :sparkles: fixed page title
* :sparkles: read only groups
* :sparkles: dynamic document list
* :sparkles: add cloneGroupStore, set default conduction values
* :sparkles: added ParcelSearchAccordion (disabled) & ParcelSelectedAccordion
for clone-group
* :sparkles: implemented cloneGroup model & api
* :sparkles: create CloneGroupMainContent & ConductorForm (clone-group). Added
clone-group route
* :sparkles: disabled ConductorForm on submit
* :safety_vest: add validation on close group from edit group
* :sparkles: replaced conductors with leadings
* Placeholder added to other views
* Error messages added
* :safety_vest: add simple percentage validation on add group
* :sparkles: implemented conductor history table
* :sparkles: hide clone button if group is active
* :sparkles: Filter group active
* Remove unused button
* :sparkles: WIP add user functions
* :sparkles: better implementation of ConductorHistory on AddGroup
* :sparkles: create landlink count api, store, model update
* :sparkles: add close group
* :sparkles: groups bulk
* :sparkles: add notification message for landlink api in store
* :sparkles: create party registry info component
* :sparkles: add update group
* :sparkles: add back & load more buttons on edit group, minor changes
* :sparkles: Add close group modal
* :sparkles: filter bulk land links
* :sparkles: WIP create party info componente, api, store
* :sparkles: land links bulk submit form
* :construction_worker: first implementation parcels list bulk
* :sparkles: completed validation on duplicated description on new group
* :sparkles: updateGroup api
* :globe_with_meridians: add translations
* :sparkles: ConductorForm descr validation
* :sparkles: add routing to edit group on click
* :sparkles: add missing features on edit group
* :sparkles: update land link close form validation
* :sparkles: added models & api
* :construction: start implementing edit group
* :sparkles: update land link close feature
* :sparkles: WIP create landlink close form
* :sparkles: update land link form
* :sparkles: create land link form component, update store and api
* :safety_vest: add dayTo validation on ConductorForm
* :goal_net: better error management on create group
* :sparkles: create component for ParcelSelectedTable accordion buttons
* :alien: updated search parcel on createGroup, minor labels fix
* :safety_vest: add form validation on group creation
* :sparkles: add calc conducted area on blur input percentage
* :sparkles: update land link filter form and chips. create sector
autocomplete
* :sparkles: add routing on success crete group
* :sparkles: update landLink filter form, create filter chips
* :sparkles: fixed reset store without partyId, modal style, ParcelsSearch and
ParcelsSelected Accordion closing on reset
* :sparkles: reset parcel filter in create group on successful search
* :sparkles: add alerts with correct text, add translations
* :sparkles: update landlink filter form
* :sparkles: better alert group not found implementation
* :sparkles: update landlinks filter form
* :sparkles: better dayTo management on ConductorForm
* :alien: updated descr group models nullable
* :sparkles: add dayTo conditionally disabled on ConductorForm
* :goal_net: better error mangement on create group
* :sparkles: repeat search on back to list
* :alien: updated conductor model
* :sparkles: search groups
* :sparkles: added flushSelectedParcels method in addGroupStore, to empty the
TableParcelSelected
* :sparkles: add empty option select conduction title type
* :sparkles: added delete method on button in ParcelTableSlectedRow
* :sparkles: update land link filter form
* :sparkles: add autocomplete on search parcels
* :sparkles: new component GoupList and nextkey implementation
* :sparkles: add formatted conductor list on ParcelTableSelectable
* :sparkles: add submit create group
* :sparkles: added getSectorList api
* :alien: Change title types model
* :sparkles: removed call to load title types
* :sparkles: add title types api on ConductorForm
* :sparkles: create landLink filter form component
* :sparkles: WIP create landlink filter  form
* :alien: Update API groups all
* :sparkles: add conducted parcelsList selected on table
* :sparkles: added createGroup api and fixed conductor schemas
* :sparkles: add scroll on open accordion
* :sparkles: add conditional cascade accordion enabling
* :bug: better implementation of ParcelTableSelectable
* :sparkles: add real parcels on ParcelTableSelectable
* :construction_worker: first filter group implementation
* :sparkles: adding more locales
* :bug: fixed titleTypes name
* :sparkles: add load parcels api
* :sparkles: implemented addGroupStore & search parcels
* :sparkles: add route watcher on GroupFormView
* :globe_with_meridians: add translations
* :sparkles: landLinks implementation
* :sparkles: Group update model and store
* :sparkles: created ConductorHistoryTable, minor fixes
* :sparkles: implemented store on ConductorForm, minor changes
* :sparkles: add store & models for add group
* :sparkles: add TopHeader in GroupFormaView, minor refactor
* :construction: created ParcelTableSelected
* :sparkles: group list template
* :sparkles: TopHeader component
* :sparkles: add table with selectable rows with checkbox
* :construction: groups api started
* :construction: start implementing new group creation components
* :recycle: update boilerplate
* :construction: started api implementation
* :sparkles: landLinks model created
* :sparkles: groups model created
* :sparkles: docTypeRelations model created
* :sparkles: docTypeRelations model created
* :sparkles: WIP boilerplate

#### Fixes

* :bug: modal closure fixed and checkbox style fixed
* :bug: fix close group error message, fix conductor form, fix landlink form
area format
* :bug: fixed clone data
* :bug: fix group edit form, dayTo validation, fix error message
* Dynamic document types fixed
* :safety_vest: better validation on edit group
* :bug: fixed dayTo on edit group form
* :wheelchair: fixed hidden screen reader class css
* :adhesive_bandage: minor fix on btn modal close group
* :bug: minor fix on form edit-group
* document list delete bug fixed
* document list delete bug fixed
* :bug: fixed error date on create group
* :bug: fixed conduction percentage on add parcel group, add comments
* :bug: fixed leave page modal on confirm add parcels to group
* :bug: fixed duplicates on not active groups list
* :bug: fixed load more on GroupListBulk
* :bug: fixed conductione percentage & resest on add group
* :bug: fixed date handler on create group
* :adhesive_bandage: partyType nullable to avoid possible zod errors
* :bug: fixed loadmore on groups list
* :bug: some fixings
* :bug: some fixings
* :speech_balloon: changed conductors text shown
* :bug: fixed hover issues on table row
* :adhesive_bandage: fixed buttons layout on tables
* :adhesive_bandage: add missing translation
* :bug: comment error line
* :bug: fix percentage validator in landlink form
* :bug: fixed conductedAreaSqm format and rounding
* :bug: fixed before leave
* :adhesive_bandage: minor fix
* :adhesive_bandage: minor fix buttons responsiveness
* :lipstick: minor style change ParcelSelectedRow buttons
* :adhesive_bandage: minor fix on clone group form
* :adhesive_bandage: minor fix
* :adhesive_bandage: minor fix on confirm create group
* :adhesive_bandage: fixed min dayTo datepicker
* :bug: fixed link to viewer
* :bug: fixed checkAll on create group & add parcels to group
* :bug: fixed link
* :bug: fixed routing to edit landlink
* :bug: reset form on change url params
* :pencil2: fix typo
* :bug: fixed link to viewer
* :bug: fixed previous parcels selected remaining after add parcel to group
* :bug: fixed link to viewer
* :adhesive_bandage: minor fix on landLink api
* :bug: replace next_key with nextKey
* :bug: replace next_key with nextKey
* :bug: add missing color on anomaly icon
* :adhesive_bandage: ad missing prop on landlink models
* :adhesive_bandage: minor fix & clean on App.vue
* :bug: minor api fix
* :adhesive_bandage: minor fix
* :bug: minor fixes
* :bug: add missing link to edit parcel on edit group
* :adhesive_bandage: add missing leading format
* :adhesive_bandage: fixed format leadiings on tables
* :safety_vest: improved validation on search parcel on add group
* :bug: minor fix
* :bug: fixed path api getParcelsByGroup
* :bug: fixed group isEditable
* :bug: fixed insert group form
* :adhesive_bandage: removed conductor form default values from clone group
* :bug: fixed buttons & routing on GroupList
* :bug: fixed routing on closing landlink conduction
* :safety_vest: better validation on conductorForm on add group
* :adhesive_bandage: minor fixes on LandLinkCloseForm
* :bug: fixed selected parcels not resetting
* :bug: fixed collapse bug
* :adhesive_bandage: flush dayTo field when disabled
* :bulb: uncomment api
* :bug: fixed dayTo on close land link conduction
* :bug: hides checkboxes already selected on add group
* :bug: fixed dayFrom on parcelsList editGroup
* :bug: fixed header
* :bug: fixed check/uncheck selected parcels on add group
* :bug: minor fixes on parcel search & selection
* Filter button name fixed
* :alien: Fixed bulk operations
* :bug: fixed condutor model
* :bug: fixed reload group list on add, close, update group
* :bug: fixed set selected parcel on multiple parcel searches on add group
* :bug: fix label gis area landlink form
* :bug: minor fix
* :bug: parcel and subParcel validation bug fixed
* :bug: fixes post merge
* :bug: fix insert cuaa code in party reg info
* :bug: fixed type check and remove action column on land link bulk list
* :bug: fixed reload list
* :adhesive_bandage: minor fix
* :bug: fixed reset form parcel search
* :bug: fix update onBlur text input landlink edit form
* :adhesive_bandage: fixed date format on edit group table, minor fixes
* :bug: fixed dayTo formatting
* :bug: fix reset filter land link filter form, fix land link table col
width
* :bug: fix i18n labels
* :bug: land link list description order
* :adhesive_bandage: minor fixes
* :bug: better BiAlert rendering
* :bug: fixed ConductorForm reset on modal cancel, minor fixes
* :bug: remove unused import
* :bug: remove unused import
* :bug: fixed load more on addGroup store
* :bug: fixed dayTo on create group
* :goal_net: fixed error management & alerts on new group accordion
* :adhesive_bandage: minor fix
* :adhesive_bandage: minor fix
* :adhesive_bandage: fixed reset conduction percentage
* :bug: fixed event propagation on click delete parcel selected, minor
refactor
* :bug: fixed titleType model
* :bug: fixed getSectorsList api
* :bug: fixed titleType model
* :sparkles: fixed router
* :recycle: fix & refactor parcels models, removed models/parcel.ts
* :bug: fixed import
* :bug: minor model fixes
* :bug: minor fix
* :bug: fixed api empty net_key
* :bug: fixed url getDocTypList
* :bug: fixed mocked parcelId, minor changes
* :adhesive_bandage: minor fixes

#### Other

* :arrow_up: Update dependencies
* :coffin: clean unused import
* :pencil2: fixed typo
* :art: format code
* :wheelchair: improve accessibility
* :globe_with_meridians: add translations
* :wheelchair: improve accessibility
* :coffin: clean code
* :art: minor format change
* :art: format code
* :pencil2: fixed typo
* :coffin: minor clean
* minor changes on clone
* :arrow_up: update dependencies
* :globe_with_meridians: minor change
* :globe_with_meridians: clone-group title traduction added
* :fire: removed comment
* :arrow_up: update dependencies
* minor change
* :art: minor clean
* :bug: fixed GIS area label
* :lipstick: fixed style close group modal
* :globe_with_meridians: add translations
* :globe_with_meridians: add translations
* :lipstick: minor style fixes
* :lipstick: minor style fixes conducted parcels table
* :truck: renamed selected in checked
* :recycle: minor refactor
* :globe_with_meridians: minor change translations
* minor change on alerts
* :recycle: minor style change, minor refactor
* :recycle: minor changes
* :wheelchair: minor change
* minor change
* :bulb: add todo comment
* minor change on conductors, add todo
* minor change on main
* :globe_with_meridians: add translation
* :bulb: add max date on start conduction, add todo comment
* :art: format code
* :globe_with_meridians: add translations, todo & minor changes
* :bulb: add todo comment
* :bulb: add todo comment
* :fire: minor clean
* :recycle: minor model change
* :art: minor format
* :safety_vest: better validation on conductor form
* :art: format locales
* :adhesive_bandage: better create group route
* :fire: minor refactor, clean & style fixes
* :bug: better locales implementation
* :art: minor format & clean
* :adhesive_bandage: minor model update
* :truck: moved BaseLayout in folder layouts
* :wrench: added proxy
* :lipstick: fixed css
* :rotating_light: fixed warnings
* :lipstick: minor layout fix
* :lipstick: better layout ParcelSearchAccordion
* :lipstick: better layout ConductorForm
* :fire: minor clean
