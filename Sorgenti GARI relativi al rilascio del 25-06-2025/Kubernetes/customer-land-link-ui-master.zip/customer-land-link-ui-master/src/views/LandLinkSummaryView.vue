<script setup lang="ts">
import { inject, onMounted, ref, type Ref } from "vue";
import { useRoute } from "vue-router";
import LandLinkSummaryList from "@/components/land-link-summary/LandLinkSummaryList.vue";

const route = useRoute();
const moduleId = inject("moduleId");

const partyId: Ref<number | null> = ref(null);

const parentModuleDeployDir = "dossier",
  baseUrl =
    (location.href.indexOf(`/${parentModuleDeployDir}`) > -1
      ? location.href.split(`/${parentModuleDeployDir}`)[0]
      : location.origin) + `/${moduleId}`;

const targetUrl = window.location.href.replace(window.location.origin, "");
const locationQuery = {
  backUrl: encodeURIComponent(targetUrl),
};

onMounted(async () => {
  partyId.value = parseInt(route.query?.partyId as string) || null;
});
</script>

<template>
  <LandLinkSummaryList
    v-if="partyId"
    :party-id="partyId"
    :win-location-base="baseUrl"
    :win-location-query="locationQuery"
  />
</template>

<style>
.customer-land-link main.my-5 {
  margin-top: 0px !important; /* TODO: Remove workaround and find a standard way to define embedded modules */
}
</style>
