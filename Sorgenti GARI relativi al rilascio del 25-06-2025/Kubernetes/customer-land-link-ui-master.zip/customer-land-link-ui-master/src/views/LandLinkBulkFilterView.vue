<script setup lang="ts">
import LandLinkBulkFilterForm from "@/components/land-link/LandLinkBulkFilterForm.vue";
import LeftDetailsAccordion from "@/components/LeftDetailsAccordion.vue";
import PageHeader from "@/components/PageHeader.vue";
import PartyRegistryInfo from "@/components/party-registry/PartyRegistryInfo.vue";
import RootNotification from "@/components/RootNotification.vue";
import useModuleId from "@/composables/useModuleId";
import { useTitleTypesStore } from "@/stores/titleTypes";
import { onMounted, ref } from "vue";
import { useI18n } from "vue-i18n";

const titleTypesStore = useTitleTypesStore();
const moduleId = useModuleId();
const { t } = useI18n();

const sectionRef = ref();

onMounted(async () => {
  try {
    await titleTypesStore.loadTitleTypes();
  } catch (e) {
    throw new Error("Error loading title types");
  }
});
</script>

<template>
  <RootNotification />
  <article ref="sectionRef" class="card card-bg rounded">
    <PageHeader />
    <div class="px-3 pt-3 customer-land-link__card-body">
      <div class="row">
        <div class="col-md-3 col-sm-12">
          <div class="customer-land-link__parcel-details it-line-right-side">
            <LeftDetailsAccordion />
          </div>
        </div>
        <!-- land link form -->
        <div class="col-md-9 col-sm-12">
          <PartyRegistryInfo />

          <div class="p-4">
            <div
              class="customer-land-link__page-title d-flex justify-content-between align-items-center mb-3"
            >
              <h4 class="customer-land-link__page-title--text">
                {{ t(`${moduleId}.landLink_filter`) }}
              </h4>
            </div>
            <LandLinkBulkFilterForm />
          </div>
        </div>
      </div>
    </div>
  </article>
</template>
