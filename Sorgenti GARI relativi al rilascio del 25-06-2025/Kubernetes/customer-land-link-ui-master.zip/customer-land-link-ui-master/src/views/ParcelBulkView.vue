<script setup lang="ts">
import LeftDetailsAccordion from "@/components/LeftDetailsAccordion.vue";
import PageHeader from "@/components/PageHeader.vue";
import RootNotification from "@/components/RootNotification.vue";
import LandLinkBulkCloseForm from "@/components/land-link/LandLinkBulkCloseForm.vue";
import LandLinkBulkList from "@/components/land-link/LandLinkBulkList.vue";
import LandLinkFiterChips from "@/components/land-link/LandLinkFiterChips.vue";
import PartyRegistryInfo from "@/components/party-registry/PartyRegistryInfo.vue";
import useModuleId from "@/composables/useModuleId";
import useParty from "@/composables/useParty";
import { RouteName } from "@/models/routes";
import { useLandLinksBulkStore } from "@/stores/landLinksBulk";
import BiButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiButton.vue";
import { onMounted } from "vue";
import { useI18n } from "vue-i18n";
import { useRoute, useRouter } from "vue-router";

const route = useRoute();
const router = useRouter();
const moduleId = useModuleId();
const { partyId } = useParty();
const landLinksStore = useLandLinksBulkStore();
const { t } = useI18n();

onMounted(async () => {
  landLinksStore.setPartyId(+partyId.value);
  await landLinksStore.searchLandLinks();
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const { sessionId, ..._0 } = route.query;
});

function handleGoToFilter() {
  router.replace({
    name: RouteName.PARCEL_BULK_FILTER,
  });
}
</script>

<template>
  <RootNotification />
  <article class="card card-bg rounded">
    <PageHeader />
    <div className="px-3 pt-3 customer-land-link__card-body">
      <div class="row">
        <div className="col-md-3 col-sm-12 pl-0">
          <div
            className="customer-land-link__sidebar-menu-wrapper it-line-right-side"
          >
            <LeftDetailsAccordion />
          </div>
        </div>
        <div class="col-md-9 col-sm-12">
          <PartyRegistryInfo />
          <div class="p-4">
            <div
              class="customer-land-link__page-title d-flex justify-content-between align-items-center mb-3"
            >
              <h4 class="customer-land-link__page-title--text">
                <!-- #137647  fixed label-->
                {{ t(`${moduleId}.landLinkBulk`, 2) }}
              </h4>
              <div class="customer-land-link__page-title--actions">
                <BiButton
                  color="primary"
                  is-outlined
                  class="ms-auto"
                  @click="handleGoToFilter()"
                >
                  {{ t(`${moduleId}.parcel_filter`, 2) }}
                </BiButton>
              </div>
            </div>
            <div class="row mt-3 mb-3">
              <div class="col">
                <LandLinkFiterChips isBulk />
              </div>
              <LandLinkBulkCloseForm />
            </div>
            <LandLinkBulkList />
          </div>
        </div>
      </div>
    </div>
  </article>
</template>
