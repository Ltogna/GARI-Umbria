<script setup lang="ts">
import LeftDetailsAccordion from "@/components/LeftDetailsAccordion.vue";
import RootNotification from "@/components/RootNotification.vue";
import useModuleId from "@/composables/useModuleId";
import useParty from "@/composables/useParty";

import { useGroupsStore } from "@/stores/groups";
import { useTitleTypesStore } from "@/stores/titleTypes";

import PartyRegistryInfo from "@/components/party-registry/PartyRegistryInfo.vue";
import { onMounted, ref, watch, type Ref } from "vue";
import { useI18n } from "vue-i18n";
import { useRouter } from "vue-router";
import usePermissions from "@/composables/usePermissions";
import { RouteName } from "@/models/routes";
import BiBackButton from "@abaco/bootstrap-italia-components/src/components/BiBackButton/BiBackButton.vue";

const moduleId = useModuleId();
const { t } = useI18n();
const groupsStore = useGroupsStore();
const titleTypesStore = useTitleTypesStore();

const sectionRef = ref();
const { partyId } = useParty();

//TODO: better implementation
const { canWrite } = usePermissions();
const router = useRouter();

const backUrl: Ref<string | null> = ref(null);

watch(
  () => canWrite,
  (canEnter) => {
    if (!canEnter) {
      router.replace({ name: RouteName.GROUP });
    }
  },
  { immediate: true },
);

function goBack() {
  if (backUrl.value) location.assign(decodeURIComponent(backUrl.value));
}

onMounted(async () => {
  try {
    await groupsStore.resetFilter();
    await titleTypesStore.loadTitleTypes();
    await groupsStore.searchGroups(+partyId.value);
    // groupsStore.filters = { descr: null, nextKey: null, titleTypeId: null };
  } catch (e) {
    // do somethings;
  }
  backUrl.value = sessionStorage.getItem(`${moduleId}.backUrl`);
});
</script>

<template>
  <RootNotification />
  <article
    ref="sectionRef"
    class="customer-land-link__group-view card card-bg rounded"
  >
    <div
      class="scheda-icona-small border-bottom border-primary px-3 pt-1 d-flex justify-content-between align-items-center"
    >
      <h3 class="primary-color">
        <BiBackButton
          v-if="backUrl"
          @click="goBack"
          :visually-hidden-text="t(`${moduleId}.back`)"
          class="btn-me"
        />
        <RouterView v-else name="backButton" />
        {{ t(`${moduleId}.title`, 2) }}
      </h3>
      <div class="d-flex justify-content-end"></div>
    </div>
    <div class="px-3 pt-3 customer-land-link__card-body">
      <div class="row">
        <div class="col-md-3 col-sm-12 pl-0">
          <div
            class="customer-land-link__sidebar-menu-wrapper it-line-right-side"
          >
            <LeftDetailsAccordion />
          </div>
        </div>
        <div class="col-md-9 col-sm-12">
          <PartyRegistryInfo />
          <!-- #region MAIN CONTENT -->
          <div class="row mt-3">
            <div class="col">
              <RouterView />
            </div>
          </div>
          <!-- #endregion MAIN CONTENT -->
        </div>
      </div>
    </div>
  </article>
</template>
