<script setup lang="ts">
import LandLinkDetail from "@/components/land-link/LandLinkDetail.vue";
import useModuleId from "@/composables/useModuleId";
import useParty from "@/composables/useParty";
import { useAnomaliesStore } from "@/stores/anomalies";
import { useLandLinksStore } from "@/stores/landLinks";
import { getSheetReference } from "@/utils/getSheetReference";
import { computed, onMounted, onUnmounted } from "vue";
import { useI18n } from "vue-i18n";
import { useRoute } from "vue-router";

const route = useRoute();
const landLinkStore = useLandLinksStore();
const anomaliesStore = useAnomaliesStore();
const moduleId = useModuleId();
const { t } = useI18n();
const { partyId } = useParty();

const landLinkInfo = computed(() => {
  const infoLabelRoot = t(`${moduleId}.landLink_detail`);
  if (landLinkStore.landLinkDetail) {
    return [
      infoLabelRoot,
      getSheetReference(landLinkStore.landLinkDetail.parcel, true),
    ].join(" ");
  }

  return infoLabelRoot;
});

onMounted(async () => {
  const { landlinkId } = route.params;
  partyId.value && landLinkStore.setPartyId(+partyId.value);
  landlinkId && (await landLinkStore.fetchLandLinkById(+landlinkId));
  await anomaliesStore.loadAnomalies(
    +partyId.value,
    landLinkStore.reference_date,
    +landlinkId,
  );
});

onUnmounted(() => {
  landLinkStore.landLinkDetail = null;
});
</script>

<template>
  <div class="p-4">
    <div
      class="customer-land-link__page-title d-flex justify-content-between align-items-center mb-3"
    >
      <h4 class="customer-land-link__page-title--text">
        {{ landLinkInfo }}
      </h4>
    </div>
    <LandLinkDetail />
  </div>
</template>
