<script setup lang="ts">
import LandLinkFilterForm from "@/components/land-link/LandLinkFilterForm.vue";
import useModuleId from "@/composables/useModuleId";
import { useTitleTypesStore } from "@/stores/titleTypes";
import { onMounted } from "vue";
import { useI18n } from "vue-i18n";

const titleTypesStore = useTitleTypesStore();
const moduleId = useModuleId();
const { t } = useI18n();

onMounted(async () => {
  try {
    await titleTypesStore.loadTitleTypes();
  } catch (e) {
    throw new Error("Error loading title types");
  }
});
</script>

<template>
  <div class="p-4">
    <div
      class="customer-land-link__page-title d-flex justify-content-between align-items-center mb-3"
    >
      <h4 class="customer-land-link__page-title--text">
        {{ t(`${moduleId}.landLink_filter`) }}
      </h4>
    </div>
    <LandLinkFilterForm />
  </div>
</template>
