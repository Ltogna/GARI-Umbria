<script setup lang="ts">
import LandLinkFilterChips from "@/components/land-link/LandLinkFiterChips.vue";
import LandLinkList from "@/components/land-link/LandLinkList.vue";
import useModuleId from "@/composables/useModuleId";
import useParty from "@/composables/useParty";
import { RouteName } from "@/models/routes";
import { useLandLinksStore } from "@/stores/landLinks";
import BiButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiButton.vue";
import { onMounted } from "vue";
import { useI18n } from "vue-i18n";
import { useRoute, useRouter } from "vue-router";

const router = useRouter();
const route = useRoute();
const landLinksStore = useLandLinksStore();
const moduleId = useModuleId();
const { t } = useI18n();
const { partyId } = useParty();

onMounted(async () => {
  filterByQueryParams();
  landLinksStore.setPartyId(+partyId.value);
  await landLinksStore.searchLandLinks();
});

function goToFilterParcel() {
  router.replace({
    name: RouteName.LAND_LINK_FILTER,
    params: { partyId: partyId.value },
  });
}
function filterByQueryParams() {
  const { sectorCode } = route.query;
  if (sectorCode) {
    landLinksStore.searchFilter = {
      sectorCode: sectorCode ? (sectorCode as string) : null,
    };
  }
}
</script>
<template>
  <div class="p-4">
    <div
      class="customer-land-link__page-title d-flex justify-content-between align-items-center mb-3"
    >
      <h4 class="customer-land-link__page-title--text">
        {{ t(`${moduleId}.landLink`, 2) }}
      </h4>
      <div class="customer-land-link__page-title--actions">
        <BiButton
          color="primary"
          is-outlined
          class="ms-auto"
          @click="goToFilterParcel()"
        >
          {{ t(`${moduleId}.parcel_filter`, 2) }}
        </BiButton>
      </div>
    </div>
    <div class="row mt-3 mb-3">
      <div class="col">
        <LandLinkFilterChips />
      </div>
    </div>
    <LandLinkList />
  </div>
</template>
