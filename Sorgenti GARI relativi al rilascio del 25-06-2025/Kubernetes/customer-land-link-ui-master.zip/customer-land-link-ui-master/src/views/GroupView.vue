<script setup lang="ts">
import LeftDetailsAccordion from "@/components/LeftDetailsAccordion.vue";
import RootNotification from "@/components/RootNotification.vue";
import useModuleId from "@/composables/useModuleId";
import useParty from "@/composables/useParty";
import { MODULE_ID } from "@/constants";
import { useGroupsStore } from "@/stores/groups";
import { useTitleTypesStore } from "@/stores/titleTypes";
import BiButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiButton.vue";
import { computed, onMounted, ref, type Ref } from "vue";
import { useI18n } from "vue-i18n";
import { RouterView, useRoute, useRouter } from "vue-router";
import PartyRegistryInfo from "@/components/party-registry/PartyRegistryInfo.vue";
import usePermissions from "@/composables/usePermissions";
import { useSettingStore } from "@/stores/settings";
import { useLandLinksStore } from "@/stores/landLinks";
import AnomaliesModal from "@/components/AnomaliesModal.vue";
import { RouteName } from "@/models/routes";
import BiBackButton from "@abaco/bootstrap-italia-components/src/components/BiBackButton/BiBackButton.vue";
import ConductorLinkButtonViewer from "@/components/ConductorLinkButtonViewer.vue";

const router = useRouter();
const route = useRoute();
const moduleId = useModuleId();
const { t } = useI18n();
const groupsStore = useGroupsStore();
const titleTypesStore = useTitleTypesStore();
const settingStore = useSettingStore();
const { canWrite } = usePermissions();
const landLinkStore = useLandLinksStore();

const showAnomaliesModal = ref(false);
const backUrl: Ref<string | null> = ref(null);

const sectionRef = ref();
const { partyId } = useParty();

const anomaliesButtonLabel = computed(
  () => t(`${moduleId}.anomaly`, 2) + ` (${landLinkStore.anomalyCount})`,
);

onMounted(async () => {
  try {
    await groupsStore.resetFilter();
    await titleTypesStore.loadTitleTypes();
    await groupsStore.searchGroups(+partyId.value);
    await settingStore.fetchSettings();
    // groupsStore.filters = { descr: null, nextKey: null, titleTypeId: null };
  } catch (e) {
    // do somethings;
  }
  backUrl.value = sessionStorage.getItem(`${moduleId}.backUrl`);
});

function goToNewParcel() {
  if (route.name === RouteName.GROUP_EDIT) {
    router.push({ name: RouteName.GROUP_ADD_PARCELS });
  } else {
    router.replace({ name: RouteName.GROUP_NEW });
  }
}

function goBack() {
  if (backUrl.value) location.assign(decodeURIComponent(backUrl.value));
}

const titleAddParcelButton = computed(() =>
  route.name === RouteName.GROUP_EDIT
    ? t(`${MODULE_ID}.add_parcel`, 2)
    : t(`${MODULE_ID}.add_parcel`, 2),
);
</script>

<template>
  <RootNotification />
  <article
    ref="sectionRef"
    class="customer-land-link__group-view card card-bg rounded"
  >
    <div
      class="scheda-icona-small border-bottom border-primary px-3 pt-1 d-flex justify-content-between align-items-center"
    >
      <h3 class="primary-color">
        <BiBackButton
          v-if="backUrl"
          @click="goBack"
          :visually-hidden-text="t(`${moduleId}.back`)"
          class="btn-me"
        />
        <RouterView v-else name="backButton" />
        {{ t(`${moduleId}.title`, 2) }}
      </h3>
      <div class="d-flex justify-content-end">
        <ConductorLinkButtonViewer />
        <BiButton
          v-if="canWrite && landLinkStore.anomalyCount > 0"
          color="danger"
          class="btn-me"
          @click="showAnomaliesModal = true"
        >
          {{ anomaliesButtonLabel }}
        </BiButton>
        <BiButton
          v-if="
            route.name !== RouteName.GROUP_NEW &&
            route.name !== RouteName.GROUP_ADD_PARCELS &&
            canWrite
          "
          color="primary"
          is-outlined
          class="btn-me"
          @click="goToNewParcel()"
        >
          {{ titleAddParcelButton }}
        </BiButton>
      </div>
    </div>
    <div class="px-3 pt-3 customer-land-link__card-body">
      <div class="row">
        <div class="col-md-3 col-sm-12 pl-0">
          <div
            class="customer-land-link__sidebar-menu-wrapper it-line-right-side"
          >
            <LeftDetailsAccordion />
          </div>
        </div>
        <div class="col-md-9 col-sm-12">
          <PartyRegistryInfo />
          <!-- #region MAIN CONTENT -->
          <div class="row mt-3">
            <div class="col">
              <RouterView />
            </div>
          </div>
          <!-- #endregion MAIN CONTENT -->
        </div>
      </div>
    </div>
    <AnomaliesModal v-model="showAnomaliesModal"></AnomaliesModal>
  </article>
</template>
