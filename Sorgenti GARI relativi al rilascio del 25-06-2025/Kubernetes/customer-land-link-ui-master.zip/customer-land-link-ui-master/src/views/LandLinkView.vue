<script setup lang="ts">
import AnomaliesModal from "@/components/AnomaliesModal.vue";
import ConductorLinkButtonViewer from "@/components/ConductorLinkButtonViewer.vue";
import LeftDetailsAccordion from "@/components/LeftDetailsAccordion.vue";
import RootNotification from "@/components/RootNotification.vue";
import PartyRegistryInfo from "@/components/party-registry/PartyRegistryInfo.vue";
import useModuleId from "@/composables/useModuleId";
import useParty from "@/composables/useParty";
import usePermissions from "@/composables/usePermissions";
import { RouteName } from "@/models/routes";
import { useLandLinksStore } from "@/stores/landLinks";
import { useSettingStore } from "@/stores/settings";
import { gotoViewer } from "@/utils/gotoViewer";
import BiBackButton from "@abaco/bootstrap-italia-components/src/components/BiBackButton/BiBackButton.vue";
import BiButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiButton.vue";
import { computed, inject, onMounted, ref, type Ref } from "vue";
import { useI18n } from "vue-i18n";
import { useRoute, useRouter } from "vue-router";

const route = useRoute();
const router = useRouter();
const moduleId = useModuleId();
const basePath = inject<string>("basePath", import.meta.env.BASE_URL);
const { t } = useI18n();
const { partyId } = useParty();
const sectionRef = ref();
const { canWrite } = usePermissions();
const landLinkStore = useLandLinksStore();
const settingStore = useSettingStore();

const showAnomaliesModal = ref(false);
const backUrl: Ref<string | null> = ref(null);

const parcelId = computed(() => landLinkStore.landLinkDetail?.parcel.id);
const anomaliesButtonLabel = computed(
  () => t(`${moduleId}.anomaly`, 2) + ` (${landLinkStore.anomalyCount})`,
);

function goToNewGroup() {
  router.replace({
    name: RouteName.GROUP_NEW,
    params: { partyId: partyId.value },
  });
}

function goBack() {
  if (backUrl.value) location.assign(decodeURIComponent(backUrl.value));
}

onMounted(async () => {
  if (route.query.backUrl) {
    sessionStorage.setItem(
      `${moduleId}.backUrl`,
      route.query.backUrl as string,
    );
  }
  backUrl.value = sessionStorage.getItem(`${moduleId}.backUrl`);
  await settingStore.fetchSettings();
});

// const anomaliesButtonColor = computed(() => {
//   const maxAnomalyLevel = landLinkStore.landLinkDetail?.maxAnomalyLevel;
//   if (!maxAnomalyLevel) return;
//   let color =
//   switch (maxAnomalyLevel) {
//     case "DANGER":
//       break;
//     case "INFO":
//       break;
//     case "WARN":
//       break;
//   }
// });
</script>

<template>
  <RootNotification />
  <article ref="sectionRef" class="card card-bg rounded">
    <div
      class="scheda-icona-small border-bottom border-primary px-3 pt-1 d-flex justify-content-between align-items-center"
    >
      <h3 class="primary-color">
        <BiBackButton
          v-if="backUrl"
          @click="goBack"
          :visually-hidden-text="t(`${moduleId}.back`)"
          class="btn-me"
        />
        {{ t(`${moduleId}.title`, 2) }}
      </h3>
      <div class="d-flex justify-content-end">
        <ConductorLinkButtonViewer />
        <BiButton
          v-if="canWrite && !landLinkStore.landLinkDetail"
          color="primary"
          is-outlined
          class="btn-me"
          @click="goToNewGroup()"
        >
          {{ t(`${moduleId}.add_parcel`, 2) }}
        </BiButton>
        <BiButton
          v-if="canWrite && landLinkStore.anomalyCount > 0"
          color="danger"
          class="btn-me"
          @click="showAnomaliesModal = true"
        >
          {{ anomaliesButtonLabel }}
        </BiButton>
        <BiButton
          v-if="parcelId"
          color="secondary"
          is-outlined
          class="btn-me"
          @click="parcelId && gotoViewer(parcelId, basePath)"
        >
          {{ t(`${moduleId}.open_viewer`) }}
        </BiButton>
      </div>
    </div>
    <div class="px-3 pt-3 customer-land-link__card-body">
      <div class="row">
        <div class="col-md-3 col-sm-12">
          <div class="customer-land-link__parcel-details it-line-right-side">
            <LeftDetailsAccordion />
          </div>
        </div>
        <div class="col-md-9 col-sm-12">
          <PartyRegistryInfo />
          <div class="row mt-3">
            <div class="col">
              <RouterView />
            </div>
          </div>
          <AnomaliesModal v-model="showAnomaliesModal"></AnomaliesModal>
        </div>
      </div>
    </div>
  </article>
</template>
