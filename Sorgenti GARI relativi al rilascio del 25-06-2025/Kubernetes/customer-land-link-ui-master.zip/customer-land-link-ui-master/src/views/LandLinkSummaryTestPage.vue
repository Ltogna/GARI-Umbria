<script setup lang="ts">
import AnomaliesModal from "@/components/AnomaliesModal.vue";
import LeftDetailsAccordion from "@/components/LeftDetailsAccordion.vue";
import RootNotification from "@/components/RootNotification.vue";
import LandLinkSummaryList from "@/components/land-link-summary/LandLinkSummaryList.vue";
import PartyRegistryInfo from "@/components/party-registry/PartyRegistryInfo.vue";
import useModuleId from "@/composables/useModuleId";
import useParty from "@/composables/useParty";
import usePermissions from "@/composables/usePermissions";
import { RouteName } from "@/models/routes";
import { useLandLinksStore } from "@/stores/landLinks";
import { gotoViewer } from "@/utils/gotoViewer";
import BiButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiButton.vue";
import { computed, inject, ref } from "vue";
import { useI18n } from "vue-i18n";
import { useRouter } from "vue-router";

const router = useRouter();
const moduleId = useModuleId();
const basePath = inject<string>("basePath", import.meta.env.BASE_URL);
const { t } = useI18n();
const { partyId } = useParty();
const sectionRef = ref();
const { canWrite } = usePermissions();
const landLinkStore = useLandLinksStore();

const showAnomaliesModal = ref(false);

const parcelId = computed(() => landLinkStore.landLinkDetail?.parcel.id);
const anomaliesButtonLabel = computed(
  () => t(`${moduleId}.anomaly`, 2) + ` (${landLinkStore.anomalyCount})`,
);

function goToNewGroup() {
  router.replace({
    name: RouteName.GROUP_NEW,
    params: { partyId: partyId.value },
  });
}

// const anomaliesButtonColor = computed(() => {
//   const maxAnomalyLevel = landLinkStore.landLinkDetail?.maxAnomalyLevel;
//   if (!maxAnomalyLevel) return;
//   let color =
//   switch (maxAnomalyLevel) {
//     case "DANGER":
//       break;
//     case "INFO":
//       break;
//     case "WARN":
//       break;
//   }
// });
</script>

<template>
  <RootNotification />
  <article ref="sectionRef" class="card card-bg rounded">
    <div
      class="scheda-icona-small border-bottom border-primary px-3 pt-1 d-flex justify-content-between align-items-center"
    >
      <h3 class="primary-color">
        {{ t(`${moduleId}.title`, 2) }}
      </h3>
      <div class="d-flex justify-content-end">
        <BiButton
          v-if="canWrite && !landLinkStore.landLinkDetail"
          color="primary"
          is-outlined
          class="btn-me"
          @click="goToNewGroup()"
        >
          {{ t(`${moduleId}.add_parcel`, 2) }}
        </BiButton>
        <BiButton
          v-if="canWrite && landLinkStore.anomalyCount > 0"
          color="danger"
          class="btn-me"
          @click="showAnomaliesModal = true"
        >
          {{ anomaliesButtonLabel }}
        </BiButton>
        <BiButton
          v-if="parcelId"
          color="secondary"
          is-outlined
          class="btn-me"
          @click="parcelId && gotoViewer(parcelId, basePath)"
        >
          {{ t(`${moduleId}.open_viewer`) }}
        </BiButton>
      </div>
    </div>
    <div class="px-3 pt-3 customer-land-link__card-body">
      <div class="row">
        <div class="col-md-3 col-sm-12">
          <div class="customer-land-link__parcel-details it-line-right-side">
            <LeftDetailsAccordion />
          </div>
        </div>
        <!-- parcel list and filter -->
        <div class="col-md-9 col-sm-12">
          <PartyRegistryInfo />
          <div class="row mt-3">
            <div class="col">
              <div class="p-4">
                <LandLinkSummaryList :party-id="+partyId" />
              </div>
            </div>
          </div>
          <AnomaliesModal v-model="showAnomaliesModal"></AnomaliesModal>
        </div>
      </div>
    </div>
  </article>
</template>
