<script setup lang="ts">
import LandLinkForm from "@/components/land-link/LandLinkForm.vue";
import useModuleId from "@/composables/useModuleId";
import useParty from "@/composables/useParty";
import { RouteName } from "@/models/routes";
import { useAnomaliesStore } from "@/stores/anomalies";
import { useLandLinksStore } from "@/stores/landLinks";
import { getSheetReference } from "@/utils/getSheetReference";
import { computed, onMounted, onUnmounted, ref } from "vue";
import { useI18n } from "vue-i18n";
import { useRoute } from "vue-router";

const route = useRoute();
const landLinkStore = useLandLinksStore();
const anomaliesStore = useAnomaliesStore();
const moduleId = useModuleId();
const { t } = useI18n();
const { partyId } = useParty();
const today = ref<Date>(new Date());

const landLinkInfo = computed(() => {
  const infoLabelRoot = t(`${moduleId}.landLink_detail`);
  if (landLinkStore.landLinkDetail) {
    return [
      infoLabelRoot,
      getSheetReference(landLinkStore.landLinkDetail.parcel, true),
    ].join(" ");
  }

  return infoLabelRoot;
});

onMounted(async () => {
  const { landlinkId } = route.params;
  const isFromGroup = route.name === RouteName.GROUP_EDIT_LANDLINK;
  partyId.value && landLinkStore.setPartyId(+partyId.value);
  landlinkId &&
    (await landLinkStore.fetchLandLinkById(
      +landlinkId,
      isFromGroup ? today.value : landLinkStore.reference_date,
    ));
  await anomaliesStore.loadAnomalies(
    +partyId.value,
    isFromGroup ? today.value : landLinkStore.reference_date,
    +landlinkId,
  );
});

onUnmounted(() => {
  landLinkStore.landLinkDetail = null;
});
</script>

<template>
  <div class="p-4">
    <div
      class="customer-land-link__page-title d-flex justify-content-between align-items-center mb-3"
    >
      <h4 class="customer-land-link__page-title--text">
        {{ landLinkInfo }}
      </h4>
    </div>
    <LandLinkForm />
  </div>
</template>
