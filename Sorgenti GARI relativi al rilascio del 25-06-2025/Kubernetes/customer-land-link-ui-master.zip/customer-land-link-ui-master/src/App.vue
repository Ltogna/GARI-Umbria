<script setup lang="ts">
import useFullpage from "@/composables/useFullpage";
import BiCallout from "@abaco/bootstrap-italia-components/src/components/BiCallout/BiCallout.vue";
import { useAlertsStore } from "@abaco/bootstrap-italia-components/src/stores/alertsStore";
import { computed, onBeforeMount, onUnmounted } from "vue";
import { useI18n } from "vue-i18n";
import { RouterView } from "vue-router";
import usePermissions from "./composables/usePermissions";
import { useLandLinksStore } from "./stores/landLinks";
import { useLandLinksBulkStore } from "./stores/landLinksBulk";

const { t } = useI18n();

const fullpage = useFullpage();
const { canRead } = usePermissions();
const landLinkStore = useLandLinksStore();
const landLinksBulkStore = useLandLinksBulkStore();

const customerLandLinkAllowed = computed(() => canRead);

const alertStore = useAlertsStore();

onBeforeMount(() => {
  // #133045 reset filter on reload
  landLinkStore.reset();
  landLinksBulkStore.reset();
});

onUnmounted(async () => {
  alertStore.$reset();
  fullpage.unmount();
});
</script>

<template>
  <div v-if="customerLandLinkAllowed" class="customer-land-link">
    <!--
      WARNING: WORKAROUND ADDED IN LandLinkSummaryView.vue FOR my-5 CSS CLASS
    -->
    <main class="my-5">
      <Teleport :disabled="!fullpage.fullscreenActive.value" to="body">
        <section
          ref="sectionRef"
          class="customer-land-link__main-section-content"
          :class="{
            container: !fullpage.fullscreenActive.value,
            'customer-land-link__fullpage bg-white':
              fullpage.fullscreenActive.value,
          }"
        >
          <RouterView />
          <RouterView name="leaveConfirmationModal" />
        </section>
      </Teleport>
    </main>
  </div>
  <BiCallout
    v-else
    type="danger"
    :title="t('customer-land-link.alerts.user_not_allowed_title')"
    class="mx-auto"
  >
    <p>{{ t("customer-land-link.alerts.user_not_allowed_text") }}</p>
  </BiCallout>
</template>
