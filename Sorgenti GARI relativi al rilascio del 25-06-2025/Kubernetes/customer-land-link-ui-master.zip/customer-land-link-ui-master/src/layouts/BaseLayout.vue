<script setup lang="ts">
import LeftDetailsAccordion from "@/components/LeftDetailsAccordion.vue";
import RootNotification from "@/components/RootNotification.vue";
import useModuleId from "@/composables/useModuleId";
import { useI18n } from "vue-i18n";

const moduleId = useModuleId();
const { t } = useI18n();
</script>

<template>
  <main>
    <section>
      <div class="container">
        <RootNotification />
        <div class="row">
          <div class="col-md-12">
            <article class="card card-bg rounded">
              <div
                class="scheda-icona-small border-bottom border-primary px-3 pt-1"
              >
                <h3 class="primary-color">
                  {{ t(`${moduleId}.title`, 2) }}
                </h3>
              </div>
              <div class="px-3 pt-4 pb-1">
                <div class="it-list-wrapper">
                  <div class="row">
                    <div class="col-md-3 col-sm-12 mb-1">
                      <div
                        class="customer-land-link__parcel-details it-line-right-side"
                      >
                        <LeftDetailsAccordion />
                      </div>
                    </div>
                    <!-- Mappa -->
                    <div class="col-md-9 col-sm-12 mb-1">
                      <slot />
                    </div>
                  </div>
                </div>
              </div>
            </article>
          </div>
        </div>
      </div>
    </section>
  </main>
</template>
