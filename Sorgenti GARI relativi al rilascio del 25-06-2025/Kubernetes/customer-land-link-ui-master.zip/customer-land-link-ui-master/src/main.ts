import createBootstrapItaliaComponentPlugin from "@abaco/bootstrap-italia-components/src/components/BootstrapItaliaComponentPlugin";
import { onModuleLoaded } from "@abaco/micro-frontend/src/Application";
import {
  NOOP_STOP_LISTENER,
  type SetStopListenerFunction,
  type StopListener,
} from "@abaco/micro-frontend/src/StopPreventionSuport";
import { createAbcRouter } from "@abaco/micro-frontend/src/Utility";
import mitt from "mitt";
import { createPinia, type Pinia } from "pinia";
import { createApp, type App as VueApp } from "vue";
import { z } from "zod";
import App from "./App.vue";
import i18n, { loadLocaleMessages } from "./i18n";
import routes from "./routes";
import { isStandalone } from "./utils/isStandalone";

console.log(
  `customer-land-link: v${import.meta.env.VITE_APP_VERSION}-${
    import.meta.env.VITE_APP_GIT_COMMIT
  }`,
);

import "@/assets/customer-land-link.scss";
import { getUserData, userHasPermission } from "@abaco/safe-rest/src/sso2";
import { BASE, DEFAULT_DATE_FORMAT, MODULE_ID } from "./constants";

const envSchema = z.object({
  VITE_LPIS_VIEWER_MODULE_ID: z.string().min(1),
});
const env = envSchema.parse(import.meta.env);
export const LPIS_VIEWER_MODULE_ID = env.VITE_LPIS_VIEWER_MODULE_ID;

let pinia: Pinia | null = null;

if (isStandalone) {
  window.bootstrap.loadFonts(
    `${import.meta.env.BASE_URL}bootstrap-italia/dist/fonts`,
  );
  await import("@/assets/index.scss");
  const router = createAbcRouter(routes, import.meta.env.BASE_URL);
  const app = createApp(App);
  app.use(router);
  app.provide("setStopListener", undefined);
  await init(app, import.meta.env.BASE_URL);
  app.mount("#app");
} else {
  let appModule: VueApp<Element> | null;
  let stopListener: StopListener = NOOP_STOP_LISTENER;
  const fnc: SetStopListenerFunction = (l: StopListener | null) =>
    (stopListener = l || NOOP_STOP_LISTENER);

  onModuleLoaded(MODULE_ID, {
    async start(node, basePath?: string) {
      appModule = createApp(App);
      appModule.provide("setStopListener", fnc);
      const router = createAbcRouter(routes, basePath);
      appModule.use(router);

      await init(appModule, basePath);
      appModule.mount(node);
    },
    css() {
      return { index: `${BASE}assets/index.css.json` };
    },
    async canStop() {
      return stopListener();
    },
    async stop() {
      appModule?.unmount();
      pinia = null;
      appModule = null;
    },
  });
}

async function init(app: VueApp, basePath?: string) {
  const emitter = mitt();
  pinia ??= createPinia();
  app.use(pinia);
  const bootstrapItaliaComponentPlugin =
    await createBootstrapItaliaComponentPlugin({
      includeGlobalComponent: false,
      includeFontAwesome: isStandalone,
    });

  const user = getUserData();
  // TODO use right context functions
  const hasPermissionWrite = userHasPermission("CUSTOMER_LAND_LINK", "WRITE");
  const hasPermissionRead = userHasPermission("CUSTOMER_LAND_LINK", "READ");
  const lang = user?.locale ?? window.navigator.language;
  const userDateFormat = user?.dateFormat ?? DEFAULT_DATE_FORMAT;
  await loadLocaleMessages(lang);
  app.config.globalProperties.$emitter = emitter;

  try {
    app.use(i18n);
    app.use(bootstrapItaliaComponentPlugin);
    app.provide("hasPermissionWrite", isStandalone || hasPermissionWrite);
    app.provide("hasPermissionRead", isStandalone || hasPermissionRead);
    app.provide("userDateFormat", userDateFormat);
    app.provide("basePath", basePath);
    app.provide("moduleId", MODULE_ID);
    app.provide("emitter", emitter);
  } catch (err) {
    console.warn(err);
  }
}
