import { type HttpJsonResult } from "@abaco/safe-rest/src/HTTPClient";
import { httpClientCLLServer as http } from "./http";
import {
  LandLinkSectorSummaryListSchema,
  type LandLinkSectorSummaryListModel,
} from "../../models/landLinkSectorSummary";

export const getLandLinks = async (
  partyId: number,
): Promise<HttpJsonResult<LandLinkSectorSummaryListModel>> => {
  return http.getJson(
    LandLinkSectorSummaryListSchema,
    `/api-priv/v1/parties/${partyId}/land-links/summary`,
  );
};
