import { CLL_SERVER_API_PREFIX } from "@/constants";
import { isStandalone } from "@/utils/isStandalone";
import {
  ErrorType,
  HTTPClient,
  type HTTPClientOptions,
  type HttpResult,
  type RequestConfig,
} from "@abaco/safe-rest/src/HTTPClient";
import {
  getUserData,
  installSso2RequestConfigProvider,
} from "@abaco/safe-rest/src/sso2";
import { login } from "./loginStandalone";

class HTTPClientCLLServer extends HTTPClient {
  constructor(config: HTTPClientOptions = {}) {
    super(config);
  }

  public async provideConfig(config?: RequestConfig): Promise<RequestConfig> {
    const provide = await super.provideConfig(config);
    if (isStandalone && provide.params && provide.params._nc) {
      delete provide.params._nc;
    }
    return provide;
  }

  protected async performCall(
    method: string,
    url: string,
    config?: RequestConfig | undefined,
    body?: BodyInit | undefined,
  ): Promise<HttpResult> {
    const user = getUserData();
    if (!user) {
      return {
        errorType: ErrorType.OTHER,
        err: 401,
      };
    }
    return super.performCall(
      method,
      `${CLL_SERVER_API_PREFIX}/${user.tenant}${url}`,
      config,
      body,
    );
  }
}
export const http = new HTTPClient();
export const httpClientCLLServer = new HTTPClientCLLServer();

installSso2RequestConfigProvider(httpClientCLLServer, "/sso2");
installSso2RequestConfigProvider(http, "/sso2");

if (isStandalone) {
  login({
    tenant: import.meta.env.VITE_TENANT,
    username: import.meta.env.VITE_USERNAME,
    password: import.meta.env.VITE_PASSWORD,
  });
}
