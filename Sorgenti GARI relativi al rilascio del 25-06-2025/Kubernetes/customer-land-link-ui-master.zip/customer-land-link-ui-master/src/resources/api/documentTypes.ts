import {
  DocumentTypeListSchema,
  type DocumentTypeListModel,
} from "@/models/documentTypes";
import {
  DocumentSchema,
  type DocumentSchemaType,
} from "@abaco/dynamic-documents/src/resources/models/documentSchema";
import { type HttpJsonResult } from "@abaco/safe-rest/src/HTTPClient";
import { httpClientCLLServer as http } from "./http";
import { ScopeCode } from "@/models/groups";

type GroupParam = { scopeCode: ScopeCode.GROUPS; groupId: string | number };
type LandLinkParam = {
  scopeCode: ScopeCode.LANDLINK;
  landLinkId: number | string;
};

export type DocumentParams = GroupParam | LandLinkParam;

/**
 * @param groupId
 * @param scopeCode Default value: GROUPS
 */
export async function getDocumentTypes(
  params: DocumentParams,
): Promise<HttpJsonResult<DocumentTypeListModel>> {
  if (params.scopeCode === ScopeCode.GROUPS && params.groupId) {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    if ((params as any).landLinkId) {
      console.warn("landLinkId not valid here");
    }
  }
  if (params.scopeCode === ScopeCode.LANDLINK && params.landLinkId) {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    if ((params as any).groupId) {
      console.warn("groupId not valid here");
    }
  }

  return await http.getJson(DocumentTypeListSchema, `/api-priv/v1/doc-types`, {
    params,
  });
}

export async function getDocumentTypeByDefinitionCode(
  definitionCode: string,
  scopeCode: string = ScopeCode.GROUPS,
): Promise<HttpJsonResult<DocumentSchemaType>> {
  return await http.getJson(
    DocumentSchema,
    `/api-priv/v1/doc-types/${definitionCode}`,
    { params: { scopeCode } },
  );
}

//TODO aggiornare con il path esatto
// export async function getDocumentInfoByDefinitionCode(
//   definitionCode: string,
// ): Promise<HttpJsonResult<DocumentSchemaType>> {
//   return await http.getJson(
//     DocumentSchema,
//     `/api-priv/v1/doc-types/${definitionCode}`,
//   );
// }
