import {
  DynamiDocumentListSchema,
  DynamiDocumentSchema,
  type DynamiDocumentListModel,
  type DynamiDocumentModel,
} from "@/models/dynamicDocuments";
import {
  ErrorType,
  type HttpJsonResult,
  type HttpResult,
} from "@abaco/safe-rest/src/HTTPClient";
import { z } from "zod";
import { httpClientCLLServer as http } from "./http";
import { dateToString } from "@/models/utils";

export async function createLandLinkDocument(
  partyId: string,
  landLinkId: string,
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  doc: any,
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
): Promise<HttpJsonResult<any>> {
  return await http.postJson(
    z.any(),
    `/api-priv/v1/parties/${partyId}/land-links/${landLinkId}/documents`,
    doc,
  );
}

export async function updateLandLinkDocument(
  partyId: string,
  landLinkId: string,
  documentId: string,
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  doc: any,
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
): Promise<HttpJsonResult<any>> {
  return await http.putJson(
    z.any(),
    `/api-priv/v1/parties/${partyId}/land-links/${landLinkId}/documents/${documentId}`,
    doc,
  );
}

export async function getLandLinkDocuments(
  partyId: string,
  landLinkId: string,
  definitionCode?: string,
  nextKey?: string | null,
  // referenceDate?: string,
): Promise<HttpJsonResult<DynamiDocumentListModel>> {
  const params: Record<string, string> = {};
  // const parseDate = dateToString.safeParse(referenceDate);
  // if (!parseDate.success) {
  //   return {
  //     errorType: ErrorType.OTHER,
  //     err: "Not valid Format",
  //   };
  // }
  // const date = parseDate.data;

  if (definitionCode) {
    params["definitionCode"] = definitionCode;
  }
  if (nextKey) {
    params["nextKey"] = nextKey;
  }
  // if (referenceDate) {
  //   params["referenceDate"] = date as string;
  // }

  return await http.getJson(
    DynamiDocumentListSchema,
    `/api-priv/v1/parties/${partyId}/land-links/${landLinkId}/documents`,

    {
      params,
    },
  );
}

export async function getLandLinkDocument(
  partyId: string,
  landLinkId: number | string,
  documentId: string | number | undefined | null,
): Promise<HttpJsonResult<DynamiDocumentModel>> {
  return await http.getJson(
    DynamiDocumentSchema,
    `/api-priv/v1/parties/${partyId}/land-links/${landLinkId}/documents/${documentId}`,
  );
}

export async function deleteLandLinkDocument(
  partyId: string,
  landLinkId: string,
  documentId: string | number,
  referenceDate?: Date,
): Promise<HttpResult> {
  const parseDate = dateToString.safeParse(referenceDate);
  if (!parseDate.success) {
    return {
      errorType: ErrorType.OTHER,
      err: "Not valid Format",
    };
  }
  const date = parseDate.data;
  return await http.delete(
    `/api-priv/v1/parties/${partyId}/land-links/${landLinkId}/documents/${documentId}`,
    {
      params: { date },
    },
  );
}
