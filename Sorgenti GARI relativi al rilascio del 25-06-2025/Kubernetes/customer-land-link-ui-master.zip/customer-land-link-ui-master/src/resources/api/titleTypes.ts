import {
  TitleTypesListSchema,
  type TitleTypesListModel,
} from "@/models/titleTypes";
import { type HttpJsonResult } from "@abaco/safe-rest/src/HTTPClient";
import { httpClientCLLServer as http } from "./http";

export async function getTitleTypes(): Promise<
  HttpJsonResult<TitleTypesListModel>
> {
  return await http.getJson(TitleTypesListSchema, `/api-priv/v1/title-types`);
}
