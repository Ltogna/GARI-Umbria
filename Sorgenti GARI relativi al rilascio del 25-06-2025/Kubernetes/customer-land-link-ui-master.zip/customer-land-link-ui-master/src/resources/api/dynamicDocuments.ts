import {
  DynamiDocumentListSchema,
  DynamiDocumentSchema,
  type DynamiDocumentListModel,
  type DynamiDocumentModel,
} from "@/models/dynamicDocuments";
import {
  type HttpJsonResult,
  type HttpResult,
} from "@abaco/safe-rest/src/HTTPClient";
import { z } from "zod";
import { httpClientCLLServer as http } from "./http";

export async function createDocument(
  partyId: string,
  groupId: string,
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  doc: any,
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
): Promise<HttpJsonResult<any>> {
  return await http.postJson(
    z.any(),
    `/api-priv/v1/parties/${partyId}/groups/${groupId}/documents`,
    doc,
  );
}

export async function updateDocument(
  partyId: string,
  groupId: string,
  documentId: string,
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  doc: any,
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
): Promise<HttpJsonResult<any>> {
  return await http.putJson(
    z.any(),
    `/api-priv/v1/parties/${partyId}/groups/${groupId}/documents/${documentId}`,
    doc,
  );
}

export async function getDocuments(
  partyId: string,
  groupId: string,
  definitionCode?: string,
  nextKey?: string | null,
): Promise<HttpJsonResult<DynamiDocumentListModel>> {
  const params: Record<string, string> = {};

  if (definitionCode) {
    params["definitionCode"] = definitionCode;
  }
  if (nextKey) {
    params["nextKey"] = nextKey;
  }

  return await http.getJson(
    DynamiDocumentListSchema,
    `/api-priv/v1/parties/${partyId}/groups/${groupId}/documents`,
    {
      params,
    },
  );
}

export async function getDocument(
  partyId: string,
  groupId: string,
  documentId: string | number | undefined | null,
): Promise<HttpJsonResult<DynamiDocumentModel>> {
  return await http.getJson(
    DynamiDocumentSchema,
    `/api-priv/v1/parties/${partyId}/groups/${groupId}/documents/${documentId}`,
  );
}

export async function deleteDocument(
  partyId: string,
  groupId: string,
  documentId: string | number,
): Promise<HttpResult> {
  return await http.delete(
    `/api-priv/v1/parties/${partyId}/groups/${groupId}/documents/${documentId}`,
  );
}
