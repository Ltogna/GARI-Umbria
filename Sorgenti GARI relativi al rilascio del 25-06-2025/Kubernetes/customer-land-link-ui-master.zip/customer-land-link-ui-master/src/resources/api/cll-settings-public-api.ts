import { type CllSettingsModel, CllSettingsSchema } from "@/models/settings";
import { type HttpJsonResult } from "@abaco/safe-rest/src/HTTPClient";
import { httpClientCLLServer as http } from "./http";

export const getCllSettings = async (): Promise<
  HttpJsonResult<CllSettingsModel>
> => {
  return http.getJson(CllSettingsSchema, `/public/v1/settings`);
};
