import {
  GroupResSchema,
  GroupsBulkClosePayloadSchema,
  GroupSearchFilterSchema,
  InfiniteListResultsGroupResSchema,
  type GroupSearchFilterModel,
  type GroupUpdateReqModel,
  type GroupCreateReqModel,
  type GroupResModel,
  type GroupsBulkClosePayloadModel,
  type InfiniteListResultsGroupResModel,
  type GroupCloneModel,
} from "@/models/groups";
import { dateToString, type EmptyModel, EmptySchema } from "@/models/utils";
import {
  ErrorType,
  type HttpJsonResult,
} from "@abaco/safe-rest/src/HTTPClient";
import _, { isUndefined } from "lodash";
import { z } from "zod";
import { httpClientCLLServer as http } from "./http";

export async function getGroup(
  partyId: number,
  groupId: number,
): Promise<HttpJsonResult<GroupResModel>> {
  return http.getJson(
    GroupResSchema,
    `/api-priv/v1/parties/${partyId}/groups/${groupId}`,
  );
}

export async function createGroup(
  partyId: number,
  data: GroupCreateReqModel,
): Promise<HttpJsonResult<GroupResModel>> {
  return http.postJson(
    GroupResSchema,
    `/api-priv/v1/parties/${partyId}/groups`,
    data,
  );
}

export async function cloneGroupData(
  partyId: number,
  groupId: number,
  data: GroupCloneModel,
): Promise<HttpJsonResult<GroupResModel>> {
  return http.postJson(
    GroupResSchema,
    `/api-priv/v1/parties/${partyId}/groups/${groupId}`,
    data,
  );
}

export async function updateGroupData(
  partyId: number,
  groupId: number,
  data: GroupUpdateReqModel,
): Promise<HttpJsonResult<GroupResModel>> {
  return http.putJson(
    GroupResSchema,
    `/api-priv/v1/parties/${partyId}/groups/${groupId}`,
    data,
  );
}

/**
 * update an existing not closed group and close all land links
 * @param partyId
 * @param groupId
 * @param dayTo
 * @returns
 */
export async function closeGroup(
  partyId: number,
  groupId: number,
  dayTo: Date,
): Promise<HttpJsonResult<GroupResModel>> {
  const parsedDate = dateToString.safeParse(dayTo);
  if (!parsedDate.success) {
    return {
      errorType: ErrorType.OTHER,
      err: parsedDate.error,
    };
  }

  return http.putJson(
    GroupResSchema,
    `/api-priv/v1/parties/${partyId}/groups/${groupId}/day-to`,
    { dayTo: parsedDate.data },
  );
}

export async function getGroups(
  partyId: number,
  referenceDate: Date,
  filter: GroupSearchFilterModel,
): Promise<HttpJsonResult<InfiniteListResultsGroupResModel>> {
  const parsedFilter = GroupSearchFilterSchema.safeParse(filter);
  if (!parsedFilter.success) {
    return {
      errorType: ErrorType.OTHER,
      err: parsedFilter.error,
    };
  }
  const params = _(parsedFilter.data)
    .omitBy(_.isUndefined)
    .omitBy(_.isNull)
    .valueOf() as GroupSearchFilterModel;

  const date = dateToString.safeParse(referenceDate);
  if (!date.success) {
    return {
      errorType: ErrorType.OTHER,
      err: date.error,
    };
  }

  return await http.getJson(
    InfiniteListResultsGroupResSchema,
    `/api-priv/v1/parties/${partyId}/groups/all/${date.data}`,
    { params },
  );
}

export const getDuplicatedGroups = async (
  partyId: number,
  descr: string,
  groupId?: number,
): Promise<HttpJsonResult<number>> => {
  const params = _({ descr, groupId }).omitBy(isUndefined).value();

  return http.getJson(
    z.number(),
    `/api-priv/v1/parties/${partyId}/groups/descr/duplicate`,
    { params },
  );
};

export const getFilteredLandLinks = () => {
  return null;
};

export async function closeManyGroups(
  partyId: number,
  payload: GroupsBulkClosePayloadModel,
): Promise<HttpJsonResult<EmptyModel>> {
  const parsedPayload = GroupsBulkClosePayloadSchema.safeParse(payload);
  if (!parsedPayload.success) {
    return {
      errorType: ErrorType.OTHER,
      err: "Not valid Format",
    };
  }
  return http.putJson(
    EmptySchema,
    `/api-priv/v1/parties/${partyId}/groups/day-to`,
    parsedPayload.data,
  );
}
