import { type PartyModel, PartyResponseSchema } from "@/models/party";
import {
  ErrorType,
  type HttpJsonResult,
} from "@abaco/safe-rest/src/HTTPClient";
import { getUserData } from "@abaco/safe-rest/src/sso2";
import { http } from "./http";

export const getParty = async (
  partyId: number,
): Promise<HttpJsonResult<PartyModel>> => {
  const user = getUserData();
  if (!user) {
    return {
      errorType: ErrorType.OTHER,
      err: 401,
    };
  }

  return http.getJson(
    PartyResponseSchema,
    `/party-registry/${user.tenant}/public/v1/parties/${partyId}`,
  );
};
