import { type GroupResModel, GroupResSchema } from "@/models/groups";
import {
  LandLinkBulkClosePayloadSchema,
  LandLinkCloseResponseSchema,
  LandLinkListCountSchema,
  LandLinkListSchema,
  LandLinkSchema,
  LandLinkSearchFilterSchema,
  type LandLinkBulkClosePayloadModel,
  type LandLinkCloseResponseModel,
  type LandLinkListCountModel,
  type LandLinkListModel,
  type LandLinkModel,
  type LandLinkSearchFilterModel,
} from "@/models/landLink";
import type { SimpleLandLinkModel } from "@/models/landLinks";
import {
  SelectListSchema,
  dateToString,
  type SelectListModel,
} from "@/models/utils";
import {
  ErrorType,
  type HttpJsonResult,
} from "@abaco/safe-rest/src/HTTPClient";
import _, { isEmpty } from "lodash";
import { type EmptyModel, EmptySchema } from "@/models/utils";
import { httpClientCLLServer as http } from "./http";
import {
  type AnomalyResponseModel,
  AnomalyResponseSchema,
} from "@/models/anomalyLevel";
import { useNotificationStore } from "@/stores/notification";

export const getGroupLandLinks = async (
  partyId: number,
  groupId: number,
  nextKey: string | null,
): Promise<HttpJsonResult<LandLinkListModel>> => {
  const params = _({ nextKey }).omitBy(isEmpty).value();

  return http.getJson(
    LandLinkListSchema,
    `/api-priv/v1/parties/${partyId}/groups/${groupId}/land-links`,
    { params },
  );
};

export const addLandLinksToGroup = async (
  partyId: number,
  groupId: number,
  data: SimpleLandLinkModel[],
): Promise<HttpJsonResult<GroupResModel>> => {
  return http.postJson(
    GroupResSchema,
    `/api-priv/v1/parties/${partyId}/groups/${groupId}/land-links`,
    data,
  );
};

export const getFilteredLandLinks = async (
  referenceDate: Date,
  partyId: number,
  searchData?: Partial<LandLinkSearchFilterModel>,
): Promise<HttpJsonResult<LandLinkListModel>> => {
  const parseDate = dateToString.safeParse(referenceDate);
  if (!parseDate.success) {
    return {
      errorType: ErrorType.OTHER,
      err: "Not valid Format",
    };
  }
  const date = parseDate.data;

  const paramsParsed = LandLinkSearchFilterSchema.safeParse(searchData);
  if (!paramsParsed.success) {
    return {
      errorType: ErrorType.OTHER,
      err: paramsParsed.error,
    };
  }

  const params = _(paramsParsed.data)
    .omitBy(_.isUndefined)
    .omitBy(_.isNull)
    .omitBy(_.isEmpty)
    .value() as LandLinkSearchFilterModel;

  return http.getJson(
    LandLinkListSchema,
    `/api-priv/v1/parties/${partyId}/land-links/${date}`,
    { params },
  );
};

export const getFilteredLandLinksCount = async (
  referenceDate: Date,
  partyId: number,
  searchData?: Partial<LandLinkSearchFilterModel>,
): Promise<HttpJsonResult<LandLinkListCountModel>> => {
  const parseDate = dateToString.safeParse(referenceDate);
  if (!parseDate.success) {
    return {
      errorType: ErrorType.OTHER,
      err: "Not valid Format",
    };
  }
  const date = parseDate.data;

  const paramsParsed = LandLinkSearchFilterSchema.safeParse(searchData);
  if (!paramsParsed.success) {
    return {
      errorType: ErrorType.OTHER,
      err: paramsParsed.error,
    };
  }

  const params = _(paramsParsed.data)
    .omitBy(_.isUndefined)
    .omitBy(_.isNull)
    .omitBy(_.isEmpty)
    .value() as LandLinkSearchFilterModel;

  return http.getJson(
    LandLinkListCountSchema,
    `/api-priv/v1/parties/${partyId}/land-links/${date}/count`,
    { params },
  );
};

export const getLandLink = async (
  referenceDate: Date,
  partyId: number,
  landLinkId: number,
): Promise<HttpJsonResult<LandLinkModel>> => {
  const parseDate = dateToString.safeParse(referenceDate);
  if (!parseDate.success) {
    return {
      errorType: ErrorType.OTHER,
      err: "Not valid Format",
    };
  }
  const date = parseDate.data;

  return http.getJson(
    LandLinkSchema,
    `/api-priv/v1/parties/${partyId}/land-links/${date}/${landLinkId}`,
  );
};

export const updateLandLink = async (
  partyId: number,
  landLinkId: number,
  titleTypePerc: number,
): Promise<HttpJsonResult<LandLinkModel>> => {
  return http.putJson(
    LandLinkSchema,
    `/api-priv/v1/parties/${partyId}/land-links/${landLinkId}`,
    { titleTypePerc },
  );
};

export const closeLandLink = async (
  partyId: number,
  landLinkId: number,
  dayTo: Date,
): Promise<HttpJsonResult<LandLinkCloseResponseModel>> => {
  const parseDate = dateToString.safeParse(dayTo);
  if (!parseDate.success) {
    return {
      errorType: ErrorType.OTHER,
      err: "Not valid Format",
    };
  }
  const date = parseDate.data;

  return http.putJson(
    LandLinkCloseResponseSchema,
    `/api-priv/v1/parties/${partyId}/land-links/${landLinkId}/day-to`,
    { dayTo: date },
  );
};

export const closeLandLinkBulk = async (
  partyId: number,
  payload: LandLinkBulkClosePayloadModel,
): Promise<HttpJsonResult<EmptyModel>> => {
  const parsedPayload = LandLinkBulkClosePayloadSchema.safeParse(payload);
  if (!parsedPayload.success) {
    return {
      errorType: ErrorType.OTHER,
      err: "Not valid Format",
    };
  }

  return http.putJson(
    EmptySchema,
    `/api-priv/v1/parties/${partyId}/land-links/day-to`,
    parsedPayload.data,
  );
};

export const getLandLinkAnomalies = async (
  partyId: number,
  referenceDate: Date,
  landLinkId: number,
): Promise<HttpJsonResult<AnomalyResponseModel>> => {
  const parseDate = dateToString.safeParse(referenceDate);
  if (!parseDate.success) {
    return {
      errorType: ErrorType.OTHER,
      err: "Not valid Format",
    };
  }
  const date = parseDate.data;

  return http.getJson(
    AnomalyResponseSchema,
    `/api-priv/v1/parties/${partyId}/land-links/${date}/${landLinkId}/anomalies`,
  );
};

const mockIrrigationData = [
  { id: "Non rilevato", text: "NON RILEVATO" },
  { id: "Non irriguo", text: "NON IRRIGUO" },
  { id: "Irrigato (Impianto fisso)", text: "IRRIGATO (IMPIANTO FISSO)" },
  {
    id: "Di soccorso (No impianto fisso)",
    text: "DI SOCCORSO (NO IMPIANTO FISSO)",
  },
];
const mockCropData = [
  { id: "Non dichiarato", text: "NON DICHIARATO" },
  { id: "Nessuna rotazione", text: "NESSUNA ROTAZIONE" },
  { id: "Rotazione seminativi", text: "ROTAZIONE SEMINATIVI" },
  { id: "Rotazione ortive", text: "ROTAZIONE ORTIVE" },
];

export async function getIrrigationTypeList(): Promise<
  HttpJsonResult<SelectListModel>
> {
  try {
    const data = SelectListSchema.parse(mockIrrigationData);
    return {
      errorType: ErrorType.NONE,
      data,
      response: new Response(JSON.stringify(data)),
    };
  } catch (err) {
    return {
      errorType: ErrorType.OTHER,
      err,
    };
  }
}
export async function getCropRotationList(): Promise<
  HttpJsonResult<SelectListModel>
> {
  try {
    const data = SelectListSchema.parse(mockCropData);
    return {
      errorType: ErrorType.NONE,
      data,
      response: new Response(JSON.stringify(data)),
    };
  } catch (err) {
    return {
      errorType: ErrorType.OTHER,
      err,
    };
  }
}
export const deleteSingleParcel = async (
  partyId: number,
  groupId: number,
  parcelId: number,
): Promise<boolean> => {
  const resp = await http.delete(
    `/api-priv/v1/parties/${partyId}/groups/${groupId}/parcels/${parcelId}`,
  );
  if (resp.errorType === ErrorType.NONE) {
    return true;
  }
  console.warn(resp);
  useNotificationStore().setErrorMessage(resp);
  return false;
};

export const deleteGroupParcel = async (
  partyId: number,
  groupId: number,
): Promise<boolean> => {
  const resp = await http.delete(
    `/api-priv/v1/parties/${partyId}/groups/${groupId}/parcels`,
  );
  if (resp.errorType === ErrorType.NONE) {
    return true;
  }
  console.warn(resp);
  useNotificationStore().setErrorMessage(resp);
  return false;
};
