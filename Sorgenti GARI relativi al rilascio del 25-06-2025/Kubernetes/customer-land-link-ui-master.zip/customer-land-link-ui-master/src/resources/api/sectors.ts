import { type HttpJsonResult } from "@abaco/safe-rest/src/HTTPClient";
import { httpClientCLLServer as http } from "./http";
import { type SectorListModel, SectorListSchema } from "@/models/sector";

export const getSectorsByFilter = async (
  filter?: string,
): Promise<HttpJsonResult<SectorListModel>> => {
  let params;
  filter && (params = { filter });

  return http.getJson(SectorListSchema, `/api-priv/v1/sectors/`, { params });
};
