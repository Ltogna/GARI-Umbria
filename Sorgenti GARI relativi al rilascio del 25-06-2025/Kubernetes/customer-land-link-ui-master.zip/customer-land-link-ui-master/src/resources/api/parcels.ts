import {
  type ParcelConductedModel,
  ParcelConductedSchema,
  type SectorModel,
  SectorSchema,
} from "./../../models/parcel";
import {
  type ParcelSearchFieldsModel,
  ParcelSearchFieldsSchema,
} from "@/models/groupFilter";
import {
  type InfiniteListResultsParcelModel,
  InfiniteListResultsParcelSchema,
  type SearchFilterModel,
  SearchFilterSchema,
  type InfiniteListParcelConductedSchemaModel,
  InfiniteListParcelConductedSchema,
} from "@/models/parcel";
import { dateToString } from "@/models/utils";
import {
  ErrorType,
  type HttpJsonResult,
} from "@abaco/safe-rest/src/HTTPClient";
import _ from "lodash";
import { httpClientCLLServer as http } from "./http";
import z from "zod";
import { type BlockModel, BlockSchema } from "@/models/block";

/**
 * Get the list of filtered conducted parcels
 * @param partyId
 * @param referenceDate
 * @param filter
 * @returns
 */
export const getFilteredConductedParcelsList = async (
  partyId: number,
  referenceDate: Date,
  filter: ParcelSearchFieldsModel,
): Promise<HttpJsonResult<InfiniteListParcelConductedSchemaModel>> => {
  const parseDate = dateToString.safeParse(referenceDate);
  if (!parseDate.success) {
    return {
      errorType: ErrorType.OTHER,
      err: "Not valid Format",
    };
  }
  const dayFrom = parseDate.data;

  const paramsParsed = ParcelSearchFieldsSchema.safeParse(filter);
  if (!paramsParsed.success) {
    return {
      errorType: ErrorType.OTHER,
      err: paramsParsed.error,
    };
  }

  const params = _({
    dayFrom,
    ...paramsParsed.data,
  })
    .omitBy(_.isEmpty)
    .valueOf();

  return http.getJson(
    InfiniteListParcelConductedSchema,
    `/api-priv/v1/parties/${partyId}/parcels`,
    { params },
  );
};

export const getFilteredParcels = async (
  partyId: number,
  searchData?: SearchFilterModel,
): Promise<HttpJsonResult<InfiniteListResultsParcelModel>> => {
  const parseDate = dateToString.safeParse(searchData?.dayFrom);
  if (!parseDate.success) {
    return {
      errorType: ErrorType.OTHER,
      err: "Not valid Format",
    };
  }
  const date = parseDate.data;

  const paramsParsed = SearchFilterSchema.safeParse(searchData);
  if (!paramsParsed.success) {
    return {
      errorType: ErrorType.OTHER,
      err: paramsParsed.error,
    };
  }

  const params = _({ ...paramsParsed.data, dayFrom: date })
    .omitBy(_.isUndefined)
    .omitBy(_.isNull)
    .omitBy(_.isEmpty)
    .value();

  return http.getJson(
    InfiniteListResultsParcelSchema,
    `/api-priv/v1/parties/${partyId}/parcels`,
    { params },
  );
};

export const getSectorsList = async (
  filter?: string,
): Promise<HttpJsonResult<SectorModel[]>> => {
  const params = _({ filter }).omitBy(_.isUndefined).value();
  return http.getJson(z.array(SectorSchema), `/api-priv/v1/sectors`, {
    params,
  });
};
export const getBlocksList = async (
  sector_code: string,
  filter?: string,
): Promise<HttpJsonResult<BlockModel[]>> => {
  const params = _({ filter }).omitBy(_.isUndefined).value();
  return http.getJson(
    z.array(BlockSchema),
    `/api-priv/v1/sectors/${sector_code}/blocks`,
    {
      params,
    },
  );
};

export const getParcelsByGroup = async (
  partyId: number,
  groupId: number,
  date: Date,
): Promise<HttpJsonResult<ParcelConductedModel[]>> => {
  const parsedDate = dateToString.safeParse(date);
  if (!parsedDate.success) {
    return {
      errorType: ErrorType.OTHER,
      err: parsedDate.error,
    };
  }
  const params = { dayFrom: parsedDate.data.toString() };

  return http.getJson(
    z.array(ParcelConductedSchema),
    `/api-priv/v1/parties/${partyId}/group/${groupId}/parcels`,
    { params },
  );
};
