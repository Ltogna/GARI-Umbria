export {};

declare global {
  interface Document {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    webkitIsFullScreen?: any;
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    webkitRequestFullscreen?: any;
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    webkitExitFullscreen?: () => void;

    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    msFullscreenElement?: any;
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    msFullscreenEnabled?: any;
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    msRequestFullscreen?: any;
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    msExitFullscreen?: () => void;
  }
}
