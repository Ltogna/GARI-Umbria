import type { AnomalyResponseModel } from "@/models/anomalyLevel";
import { getLandLinkAnomalies } from "@/resources/api/landLink";
import { ErrorType } from "@abaco/safe-rest/src/HTTPClient";
import { defineStore } from "pinia";

interface State {
  anomalies: AnomalyResponseModel | null;
  hasError: boolean;
  isLoading: boolean;
}

export const useAnomaliesStore = defineStore({
  id: "anomalies",
  state: () =>
    ({
      anomalies: null,
      hasError: false,
      isLoading: false,
    }) as State,
  getters: {},
  actions: {
    async loadAnomalies(
      partyId: number,
      referenceDate: Date,
      landLinkId: number,
    ) {
      this.isLoading = true;
      const response = await getLandLinkAnomalies(
        partyId,
        referenceDate,
        landLinkId,
      );

      if (response.errorType !== ErrorType.NONE) {
        console.warn(response);
        this.hasError = true;
      } else {
        this.anomalies = response.data;
      }
      this.isLoading = false;
    },
  },
});
