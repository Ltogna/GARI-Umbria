import { ErrorType } from "@abaco/safe-rest/src/HTTPClient";
import { useSessionStorage, type RemovableRef } from "@vueuse/core";
import { defineStore } from "pinia";
import {
  closeLandLink,
  getFilteredLandLinks,
  getFilteredLandLinksCount,
  getLandLink,
  updateLandLink,
} from "@/resources/api/landLink";
import type {
  LandLinkListModel,
  LandLinkModel,
  LandLinkSearchFilterModel,
} from "@/models/landLink";
import { useNotificationStore } from "./notification";

interface State {
  partyId: number | null;
  selectedId: number | null;
  hasError: boolean;
  searchFilter: RemovableRef<Partial<LandLinkSearchFilterModel>>;
  infiniteLandLinks: LandLinkListModel | null;
  reference_date: RemovableRef<Date>;
  isLoading: boolean;
  landLinks: LandLinkModel[];
  landLinkDetail: LandLinkModel | null;
  landLinkCount: number | null;
}

export const REFERENCE_DATE_STORAGE_KEY = "cll_reference_date";
export const SEARCH_FILTER_STORAGE_KEY = "cll_search_filter";

const SEARCH_FILTER_DEFAULT_VALUES: Partial<LandLinkSearchFilterModel> = {
  groupId: null,
  partyId: null,
  targetPartyId: null,
  nextKey: null,
  sectorCode: null,
  anomalyLevel: null,
  blockCode: null,
  parcelCode: null,
  subParcelCode: null,
  titleTypeId: null,
};

export const useLandLinksStore = defineStore({
  id: "landLinks",
  state: () =>
    ({
      partyId: null,
      selectedId: null,
      searchFilter: useSessionStorage(SEARCH_FILTER_STORAGE_KEY, {
        ...SEARCH_FILTER_DEFAULT_VALUES,
      }),
      reference_date: useSessionStorage(REFERENCE_DATE_STORAGE_KEY, new Date()),
      infiniteLandLinks: null,
      isLoading: false,
      hasError: false,
      landLinks: [],
      landLinkDetail: null,
      landLinkCount: null,
    }) as State,
  getters: {
    nextKey(state) {
      return state.infiniteLandLinks?.nextKey;
    },
    count(state) {
      return state.landLinkCount;
    },
    hasLandLinks(state) {
      return state.landLinks.length > 0;
    },
    anomalyCount(state) {
      return state.landLinkDetail?.anomalyCount ?? 0;
    },
  },
  actions: {
    async searchLandLinks(loadNext?: boolean) {
      if (!loadNext) {
        this.infiniteLandLinks = null;
        this.searchFilter.nextKey = null;
        this.landLinks = [];
      }
      if (loadNext && this.nextKey) {
        this.searchFilter.nextKey = this.nextKey;
      }
      this.isLoading = true;

      if (this.partyId) {
        const response = await getFilteredLandLinks(
          this.reference_date,
          this.partyId,
          this.searchFilter,
        );

        const count = await getFilteredLandLinksCount(
          this.reference_date,
          this.partyId,
          this.searchFilter,
        );

        if (response.errorType !== ErrorType.NONE) {
          this.hasError = true;
          useNotificationStore().setErrorMessage(response);
          if (response.errorType === ErrorType.HTTP_STATUS) {
            console.warn(response.response);
          } else {
            console.warn(response.err);
          }
        } else if (count.errorType !== ErrorType.NONE) {
          this.hasError = true;
          useNotificationStore().setErrorMessage(count);
          if (count.errorType === ErrorType.HTTP_STATUS) {
            console.warn(count.response);
          } else {
            console.warn(count.err);
          }
        } else {
          this.hasError = false;
          this.landLinkCount = count.data;
          this.infiniteLandLinks = response.data;
          this.landLinks = [...this.landLinks, ...response.data.records];
        }
      }
      this.isLoading = false;
    },
    async fetchLandLinkById(landLinkId: number, date_reference?: Date) {
      if (this.partyId) {
        this.isLoading = true;

        const response = await getLandLink(
          date_reference ?? this.reference_date,
          this.partyId,
          landLinkId,
        );

        if (response.errorType !== ErrorType.NONE) {
          this.hasError = true;
          useNotificationStore().setErrorMessage(response);
          if (response.errorType === ErrorType.HTTP_STATUS) {
            console.warn(response.response);
          } else {
            console.warn(response.err);
          }
        } else {
          this.hasError = false;
          this.landLinkDetail = structuredClone(response.data);
        }

        this.isLoading = false;
      }
    },
    async updateLandLink(landLinkId: number, titleTypePerc: number) {
      if (this.partyId) {
        this.isLoading = true;

        const response = await updateLandLink(
          this.partyId,
          landLinkId,
          titleTypePerc,
        );

        if (response.errorType !== ErrorType.NONE) {
          this.hasError = true;
          useNotificationStore().setErrorMessage(response);
          if (response.errorType === ErrorType.HTTP_STATUS) {
            console.warn(response.response);
          } else {
            console.warn(response.err);
          }
        } else {
          this.hasError = false;
          this.landLinkDetail = structuredClone(response.data);
        }

        this.isLoading = false;
      }
    },
    async closeLandLinkConduction(landLinkId: number, dayTo: Date) {
      if (this.partyId) {
        this.isLoading = true;

        const response = await closeLandLink(this.partyId, landLinkId, dayTo);

        if (response.errorType !== ErrorType.NONE) {
          this.hasError = true;
          useNotificationStore().setErrorMessage(response);
          if (response.errorType === ErrorType.HTTP_STATUS) {
            console.warn(response.response);
          } else {
            console.warn(response.err);
          }
        } else {
          this.hasError = false;
        }

        this.isLoading = false;
      }
    },
    setPartyId(partyId: number) {
      this.partyId = partyId;
    },
    reset() {
      this.$reset();
      this.searchFilter = { ...SEARCH_FILTER_DEFAULT_VALUES };
      this.reference_date = new Date();
    },
  },
});
