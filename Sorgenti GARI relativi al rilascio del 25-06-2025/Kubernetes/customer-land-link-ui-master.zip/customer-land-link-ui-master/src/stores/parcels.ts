import type {
  InfiniteListResultsParcelModel,
  ParcelModel,
  SearchFilterModel,
} from "@/models/parcel";
import { ErrorType } from "@abaco/safe-rest/src/HTTPClient";
import { useSessionStorage, type RemovableRef } from "@vueuse/core";
import { defineStore } from "pinia";
import { getFilteredParcels } from "@/resources/api/parcels";

interface State {
  partyId: number | null;
  selectedId: number | null;
  hasError: boolean;
  searchFilter: RemovableRef<SearchFilterModel>;
  infiniteParcels: InfiniteListResultsParcelModel | null;
  reference_date: RemovableRef<Date>;
  isLoading: boolean;
  parcels: ParcelModel[];
}

export const REFERENCE_DATE_STORAGE_KEY = "cll_reference_date";
export const SEARCH_FILTER_STORAGE_KEY = "cll_search_filter";

const SEARCH_FILTER_DEFAULT_VALUES: SearchFilterModel = {
  cuaa: null,
  sectorCode: null,
  blockCode: null,
  parcelCode: null,
  subParcel: null,
  dayFrom: new Date(),
  nextKey: null,
};

export const useParcelsStore = defineStore({
  id: "parcels",
  state: () =>
    ({
      partyId: null,
      selectedId: null,
      searchFilter: useSessionStorage(SEARCH_FILTER_STORAGE_KEY, {
        ...SEARCH_FILTER_DEFAULT_VALUES,
      }),
      reference_date: useSessionStorage(REFERENCE_DATE_STORAGE_KEY, new Date()),
      infiniteParcels: null,
      isLoading: false,
      hasError: false,
      parcels: [],
    }) as State,
  getters: {
    nextKey(state) {
      return state.infiniteParcels?.nextKey;
    },
    count(state) {
      return state.infiniteParcels?.count;
    },
    hasParcels(state) {
      return state.parcels.length > 0;
    },
  },
  actions: {
    async searchParcels(loadNext?: boolean) {
      if (!loadNext) {
        this.infiniteParcels = null;
        this.searchFilter.nextKey = null;
        this.parcels = [];
      }
      if (loadNext && this.nextKey) {
        this.searchFilter.nextKey = this.nextKey;
      }
      this.isLoading = true;

      if (this.partyId) {
        const response = await getFilteredParcels(
          this.partyId,
          this.searchFilter,
        );

        if (response.errorType !== ErrorType.NONE) {
          this.hasError = true;
          if (response.errorType === ErrorType.HTTP_STATUS) {
            console.warn(response.response);
          } else {
            console.warn(response.err);
          }
        } else {
          this.hasError = false;
          this.infiniteParcels = response.data;
          this.parcels = [...this.parcels, ...response.data.records];
        }
      }
      this.isLoading = false;
    },
    setPartyId(partyId: number) {
      this.partyId = partyId;
    },
    reset() {
      this.$reset();
      this.searchFilter = { ...SEARCH_FILTER_DEFAULT_VALUES };
      this.reference_date = new Date();
    },
  },
});
