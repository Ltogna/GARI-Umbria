import type { GroupResModel, GroupUpdateReqModel } from "@/models/groups";
import type { LandLinkListModel, LandLinkModel } from "@/models/landLink";
import { getGroup, updateGroupData } from "@/resources/api/groups";
import { getGroupLandLinks } from "@/resources/api/landLink";
import { isEditable } from "@/utils/isGroupEditable";
import { ErrorType } from "@abaco/safe-rest/src/HTTPClient";
import { defineStore } from "pinia";
import { useNotificationStore } from "./notification";
import { isFuture as isFutureDateFns } from "date-fns";

interface State {
  group: GroupResModel | null;
  infiniteLandLinks: LandLinkListModel | null;
  landLinks: LandLinkModel[];
  groupId: number | null;
  partyId: number | null;
  isLoading: boolean;
  hasError: boolean;
  errorMessage: string | null;
  landLinksNextKey: string | null;
}

export const useEditGroupStore = defineStore({
  id: "editGroup",
  state: () =>
    ({
      group: null,
      infiniteLandLinks: null,
      partyId: null,
      groupId: null,
      isLoading: false,
      hasError: false,
      landLinksNextKey: null,
      landLinks: [],
      errorMessage: null,
    }) as State,
  getters: {
    nextKey(state) {
      return state.infiniteLandLinks?.nextKey ?? null;
    },
    isEditable(state) {
      if (state.group) {
        return isEditable(state.group);
      }

      return false;
    },
    isFuture(state) {
      if (!state.group?.dayFrom) return false;
      return isFutureDateFns(state.group.dayFrom);
    },
  },
  actions: {
    async fetchGroup() {
      if (!this.groupId) {
        console.warn("Group id not found");
        return;
      }
      if (!this.partyId) {
        console.warn("Party id not found");
        return;
      }
      this.isLoading = true;
      const response = await getGroup(this.partyId, this.groupId);
      if (response.errorType !== ErrorType.NONE) {
        this.hasError = true;
        await useNotificationStore().setErrorMessage(response);
        this.errorMessage = useNotificationStore().message;
        console.warn(response);
      } else {
        this.hasError = false;
        this.group = response.data;
      }
      this.isLoading = false;
    },

    async fetchGroupLandLinks(loadNext?: boolean) {
      if (!loadNext) {
        this.infiniteLandLinks = null;
        this.landLinks = [];
        this.landLinksNextKey = null;
      } else if (loadNext && this.nextKey) {
        this.landLinksNextKey = this.nextKey;
      }

      if (!this.groupId) {
        console.warn("Group id not found");
        return;
      }
      if (!this.partyId) {
        console.warn("Party id not found");
        return;
      }
      this.isLoading = true;
      const response = await getGroupLandLinks(
        this.partyId,
        this.groupId,
        this.landLinksNextKey,
      );

      if (response.errorType !== ErrorType.NONE) {
        this.hasError = true;
        await useNotificationStore().setErrorMessage(response);
        this.errorMessage = useNotificationStore().message;
        console.warn(response);
      } else {
        this.hasError = false;
        this.infiniteLandLinks = response.data;
        this.landLinks = [...this.landLinks, ...response.data.records];
      }
      this.isLoading = false;
    },

    async updateGroup(data: GroupUpdateReqModel) {
      if (!this.groupId) {
        console.warn("Group id not found");
        return;
      }
      if (!this.partyId) {
        console.warn("Party id not found");
        return;
      }

      this.isLoading = true;

      const response = await updateGroupData(this.partyId, this.groupId, data);

      if (response.errorType !== ErrorType.NONE) {
        this.hasError = true;
        await useNotificationStore().setErrorMessage(response);
        this.errorMessage = useNotificationStore().message;
        console.warn(response);
      } else {
        this.hasError = false;
        this.errorMessage = null;
        useNotificationStore().setMessage(response);
      }
      this.isLoading = false;
    },
  },
});
