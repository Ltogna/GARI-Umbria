import i18n from "@/i18n";
import { MODULE_ID } from "@/constants";
import {
  ErrorType,
  type GenericResponseError,
  type HttpJsonResult,
  type HttpResponseError,
  type HttpResult,
} from "@abaco/safe-rest/src/HTTPClient";
import { defineStore } from "pinia";

export interface State {
  message: string;
  isError: boolean;
}

const { t, te } = i18n.global;

export const useNotificationStore = defineStore({
  id: "notification",
  state: () =>
    ({
      message: "",
      isError: false,
    }) as State,
  getters: {},
  actions: {
    async setMessage(httpResponse: HttpJsonResult<unknown> | HttpResult) {
      if (httpResponse.errorType === ErrorType.NONE) {
        this.isError = false;
        this.message = t(`${MODULE_ID}.success.GENERIC_SAVE`);
      } else {
        await this.setErrorMessage(httpResponse);
      }
    },
    async setErrorMessage(
      httpResponse?: HttpResponseError | GenericResponseError | HttpResult,
    ) {
      this.isError = true;
      if (httpResponse && httpResponse.errorType === ErrorType.HTTP_STATUS) {
        if (httpResponse.response.status === 500) {
          this.message = t(`${MODULE_ID}.errors.GENERIC_ERROR`);
          return;
        }

        try {
          const { errorCode, message } = await httpResponse.response.json();

          if (te(`${MODULE_ID}.errors.${errorCode}`)) {
            this.message = t(`${MODULE_ID}.errors.${errorCode}`);
          } else {
            this.message = message || t(`${MODULE_ID}.errors.GENERIC_ERROR`);
          }
          !message && console.warn(errorCode);
        } catch (err) {
          console.warn(err);
          this.message = t(`${MODULE_ID}.errors.GENERIC_ERROR`);
        }
      } else this.message = t(`${MODULE_ID}.errors.GENERIC_ERROR`);
    },
    setRawMessge(state: State) {
      this.isError = state.isError;
      this.message = state.message;
    },
  },
});
