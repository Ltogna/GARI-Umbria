import { ZodError } from "zod";
import { type TitleTypesListModel } from "@/models/titleTypes";
import { ErrorType } from "@abaco/safe-rest/src/HTTPClient";
import { defineStore } from "pinia";
import { getTitleTypes } from "@/resources/api/titleTypes";

export interface State {
  titleTypes: TitleTypesListModel;
  loading: boolean;
  error: boolean;
}

export const useTitleTypesStore = defineStore({
  id: "titleType",
  state: () =>
    ({
      titleTypes: [],
      loading: false,
      error: false,
    }) as State,
  getters: {},
  actions: {
    async loadTitleTypes(force = false) {
      this.loading = true;
      this.error = false;
      if (this.titleTypes.length === 0 || force) {
        const resp = await getTitleTypes();
        if (resp.errorType === ErrorType.NONE) {
          this.titleTypes = resp.data;
        } else {
          if (
            resp.errorType === ErrorType.OTHER &&
            resp.err instanceof ZodError
          ) {
            console.warn(resp.err);
          }
          this.error = true;
        }
      }

      this.loading = false;
    },
  },
});
