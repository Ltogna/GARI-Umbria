import { ErrorType } from "@abaco/safe-rest/src/HTTPClient";
import { useSessionStorage, type RemovableRef } from "@vueuse/core";
import { defineStore } from "pinia";
import {
  closeLandLink,
  getFilteredLandLinks,
  getLandLink,
  updateLandLink,
} from "@/resources/api/landLink";
import { cloneDeep } from "lodash";
import type {
  LandLinkListModel,
  LandLinkModel,
  LandLinkSearchFilterModel,
} from "@/models/landLink";

interface State {
  partyId: number | null;
  selectedId: number | null;
  hasError: boolean;
  searchFilter: RemovableRef<Partial<LandLinkSearchFilterModel>>;
  infiniteLandLinks: LandLinkListModel | null;
  reference_date: RemovableRef<Date>;
  isLoading: boolean;
  landLinks: LandLinkModel[];
  landLinkDetail: LandLinkModel | null;
}

export const BULK_REFERENCE_DATE_STORAGE_KEY = "cll_bulk_reference_date";
export const SEARCH_BULK_FILTER_STORAGE_KEY = "cll_search_bulk_filter";

const SEARCH_FILTER_DEFAULT_VALUES: Partial<LandLinkSearchFilterModel> = {
  groupId: null,
  partyId: null,
  targetPartyId: null,
  nextKey: null,
};

export const useLandLinksBulkStore = defineStore({
  id: "landLinksBulk",
  state: () =>
    ({
      partyId: null,
      selectedId: null,
      searchFilter: useSessionStorage(SEARCH_BULK_FILTER_STORAGE_KEY, {
        ...SEARCH_FILTER_DEFAULT_VALUES,
      }),
      reference_date: useSessionStorage(
        BULK_REFERENCE_DATE_STORAGE_KEY,
        new Date(),
      ),
      infiniteLandLinks: null,
      isLoading: false,
      hasError: false,
      landLinks: [],
      landLinkDetail: null,
    }) as State,
  getters: {
    nextKey(state) {
      return state.infiniteLandLinks?.nextKey;
    },
    count(state) {
      return state.infiniteLandLinks?.count;
    },
    hasLandLinks(state) {
      return state.landLinks.length > 0;
    },
  },
  actions: {
    async searchLandLinks(loadNext?: boolean) {
      if (!loadNext) {
        this.infiniteLandLinks = null;
        this.searchFilter.nextKey = null;
        this.landLinks = [];
      }
      if (loadNext && this.nextKey) {
        this.searchFilter.nextKey = this.nextKey;
      }
      this.isLoading = true;

      if (this.partyId) {
        const response = await getFilteredLandLinks(
          this.reference_date,
          this.partyId,
          this.searchFilter,
        );

        if (response.errorType !== ErrorType.NONE) {
          this.hasError = true;
          if (response.errorType === ErrorType.HTTP_STATUS) {
            console.warn(response.response);
          } else {
            console.warn(response.err);
          }
        } else {
          this.hasError = false;
          this.infiniteLandLinks = response.data;
          this.landLinks = [...this.landLinks, ...response.data.records];
        }
      }
      this.isLoading = false;
    },
    async fetchLandLinkById(landLinkId: number) {
      if (this.partyId) {
        this.isLoading = true;

        const response = await getLandLink(
          this.reference_date,
          this.partyId,
          landLinkId,
        );

        if (response.errorType !== ErrorType.NONE) {
          this.hasError = true;
          if (response.errorType === ErrorType.HTTP_STATUS) {
            console.warn(response.response);
          } else {
            console.warn(response.err);
          }
        } else {
          this.hasError = false;
          this.landLinkDetail = cloneDeep(response.data);
        }

        this.isLoading = false;
      }
    },
    async updateLandLink(landLinkId: number, titleTypePerc: number) {
      if (this.partyId) {
        this.isLoading = true;

        const response = await updateLandLink(
          this.partyId,
          landLinkId,
          titleTypePerc,
        );

        if (response.errorType !== ErrorType.NONE) {
          this.hasError = true;
          if (response.errorType === ErrorType.HTTP_STATUS) {
            console.warn(response.response);
          } else {
            console.warn(response.err);
          }
        } else {
          this.hasError = false;
          this.landLinkDetail = cloneDeep(response.data);
        }

        this.isLoading = false;
      }
    },
    async closeLandLinkConduction(landLinkId: number, dayTo: Date) {
      if (this.partyId) {
        this.isLoading = true;

        const response = await closeLandLink(this.partyId, landLinkId, dayTo);

        if (response.errorType !== ErrorType.NONE) {
          this.hasError = true;
          if (response.errorType === ErrorType.HTTP_STATUS) {
            console.warn(response.response);
          } else {
            console.warn(response.err);
          }
        } else {
          this.hasError = false;
        }

        this.isLoading = false;
      }
    },
    setPartyId(partyId: number) {
      this.partyId = partyId;
    },
    reset() {
      this.$reset();
      this.searchFilter = { ...SEARCH_FILTER_DEFAULT_VALUES };
      this.reference_date = new Date();
    },
  },
});
