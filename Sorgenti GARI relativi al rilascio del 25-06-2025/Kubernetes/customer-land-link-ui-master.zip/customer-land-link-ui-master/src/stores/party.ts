import type { PartyModel } from "@/models/party";
import { getParty } from "@/resources/api/party-public-api";
import { ErrorType } from "@abaco/safe-rest/src/HTTPClient";
import { cloneDeep } from "lodash";
import { defineStore } from "pinia";

interface State {
  partyId: number | null;
  partyDetail: PartyModel | null;
  hasError: boolean;
  isLoading: boolean;
}

export const usePartyStore = defineStore({
  id: "parties",
  state: () =>
    ({
      partyId: null,
      partyDetail: null,
      hasError: false,
      isLoading: false,
    }) as State,
  getters: {
    partyBannerInfo(state) {
      const infos = [];
      const names = [];
      let prefix;

      state.partyDetail?.code && (prefix = state.partyDetail?.code);

      prefix && infos.push(prefix);
      state.partyDetail?.firstName && names.push(state.partyDetail?.firstName);
      state.partyDetail?.lastName && names.push(state.partyDetail?.lastName);

      return [...infos, names.join(" ")].join(" - ");
    },
  },
  actions: {
    async fetchPartyById(partyId: number) {
      if (partyId) {
        this.isLoading = true;

        const response = await getParty(partyId);

        if (response.errorType !== ErrorType.NONE) {
          this.hasError = true;
          if (response.errorType === ErrorType.HTTP_STATUS) {
            console.warn(response.response);
          } else {
            console.warn(response.err);
          }
        } else {
          this.hasError = false;
          this.partyDetail = cloneDeep(response.data);
        }

        this.isLoading = false;
      }
    },
    setPartyId(partyId: number) {
      this.partyId = partyId;
    },
  },
});
