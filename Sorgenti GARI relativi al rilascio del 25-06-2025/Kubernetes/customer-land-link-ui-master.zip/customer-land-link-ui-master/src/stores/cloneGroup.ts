import { INFINITE_DATE } from "@/constants";
import type { ConductorFieldsModel } from "@/models/groupFilter";
import type { GroupCloneModel, GroupResModel } from "@/models/groups";
import type { LandLinkModel } from "@/models/landLink";
import type { ParcelConductedModel } from "@/models/parcel";
import { dateToString } from "@/models/utils";
import { cloneGroupData, getGroup } from "@/resources/api/groups";
import { getParcelsByGroup } from "@/resources/api/parcels";
import { DEFAULT_CONDUCTOR_FORM } from "@/utils/defaultValues";
import { ErrorType } from "@abaco/safe-rest/src/HTTPClient";
import { defineStore } from "pinia";
import { useNotificationStore } from "./notification";

interface State {
  group: GroupResModel | null;
  conduction: ConductorFieldsModel;
  parcelsConducted: ParcelConductedModel[];
  landLinks: LandLinkModel[];
  groupId: number | null;
  partyId: number | null;
  isLoading: boolean;
  hasError: boolean;
  conductionPercentage: number;
}

export const useCloneGroupStore = defineStore({
  id: "cloneGroup",
  state: () =>
    ({
      group: null,
      partyId: null,
      groupId: null,
      isLoading: false,
      hasError: false,
      conduction: structuredClone(DEFAULT_CONDUCTOR_FORM),
      landLinks: [],
      parcelsConducted: [],
      conductionPercentage: 100,
    }) as State,
  getters: {
    referenceDate(state) {
      return state.group?.dayFrom ?? new Date();
    },
  },
  actions: {
    setConduction(fields: ConductorFieldsModel) {
      this.conduction = fields;
    },
    setPartyId(partyId: number) {
      this.partyId = partyId;
    },
    setGroupId(groupId: number) {
      this.groupId = groupId;
    },
    async fetchGroup() {
      if (!this.groupId) {
        console.warn("Group id not found");
        return;
      }
      if (!this.partyId) {
        console.warn("Party id not found");
        return;
      }
      this.isLoading = true;
      const response = await getGroup(this.partyId, this.groupId);
      if (response.errorType !== ErrorType.NONE) {
        this.hasError = true;
        console.warn(response);
      } else {
        this.hasError = false;
        this.group = response.data;
      }
      this.isLoading = false;
    },

    async fetchGroupParcels() {
      if (!this.groupId) {
        console.warn("Group id not found");
        return;
      }
      if (!this.partyId) {
        console.warn("Party id not found");
        return;
      }
      this.isLoading = true;
      const response = await getParcelsByGroup(
        this.partyId,
        this.groupId,
        this.referenceDate,
      );

      if (response.errorType !== ErrorType.NONE) {
        this.hasError = true;
        console.warn(response);
      } else {
        this.hasError = false;
        this.parcelsConducted = response.data;
      }
      this.isLoading = false;
    },

    async cloneGroup() {
      if (!this.groupId) {
        console.warn("Group id not found");
        return;
      }
      if (!this.partyId) {
        console.warn("Party id not found");
        return;
      }

      this.isLoading = true;

      const dayTo = this.conduction.dayTo
        ? dateToString.parse(new Date(this.conduction.dayTo)).toString()
        : INFINITE_DATE;
      const data: GroupCloneModel = {
        dayFrom: dateToString.parse(this.conduction.dayFrom).toString(),
        dayTo,
        descr: this.conduction.description,
        titleTypeId: +this.conduction.titleTypeId,
        titleTypePerc: this.conductionPercentage,
      };

      const response = await cloneGroupData(this.partyId, this.groupId, data);

      if (response.errorType !== ErrorType.NONE) {
        this.hasError = true;
        console.warn(response);
      } else {
        this.hasError = false;
      }

      useNotificationStore().setMessage(response);

      this.isLoading = false;
    },
  },
});
