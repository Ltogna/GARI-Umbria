import { ErrorType } from "@abaco/safe-rest/src/HTTPClient";
import { defineStore } from "pinia";
import { ZodError } from "zod";
// import { type RemovableRef, useSessionStorage } from "@vueuse/core";
import type { DocumentTypeListModel } from "@/models/documentTypes";
import { getDocumentTypes } from "@/resources/api/documentTypes";
import { ScopeCode } from "@/models/groups";
export interface State {
  documentTypes: DocumentTypeListModel;
  landLinkDocuments: DocumentTypeListModel;
  groupId: string | null;
  landLinkId: string | null;
  loading: boolean;
  error: boolean;
}

export const useDocumentTypeStore = defineStore({
  id: "documentTypes",
  state: () =>
    ({
      documentTypes: [],
      landLinkDocuments: [],
      loading: false,
      groupId: null,
      landLinkId: null,
      error: false,
    }) as State,
  getters: {},
  actions: {
    async getDocumentTypes(groupId: string, force = false) {
      if (this.groupId !== groupId || force) {
        this.groupId === groupId;
        this.loading = true;
        const resp = await getDocumentTypes({
          scopeCode: ScopeCode.GROUPS,
          groupId,
        });
        if (resp.errorType === ErrorType.NONE) {
          this.documentTypes = resp.data;
        } else {
          if (
            resp.errorType === ErrorType.OTHER &&
            resp.err instanceof ZodError
          ) {
            console.warn(resp.err);
          }
          this.error = true;
        }

        this.loading = false;
      }
    },
    async getDocumentLandlinkTypes(landLinkId: number | string, force = false) {
      if (landLinkId !== undefined || force) {
        this.landLinkId === landLinkId;
        this.loading = true;
        const resp = await getDocumentTypes({
          landLinkId,
          scopeCode: ScopeCode.LANDLINK,
        });
        if (resp.errorType === ErrorType.NONE) {
          this.landLinkDocuments = resp.data;
        } else {
          if (
            resp.errorType === ErrorType.OTHER &&
            resp.err instanceof ZodError
          ) {
            console.warn(resp.err);
          }
          this.error = true;
        }

        this.loading = false;
      }
    },
  },
});
