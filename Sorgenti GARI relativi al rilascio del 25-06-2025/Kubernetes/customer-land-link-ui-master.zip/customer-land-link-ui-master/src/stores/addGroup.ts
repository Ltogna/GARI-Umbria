import { INFINITE_DATE, MODULE_ID } from "@/constants";
import type {
  ConductorFieldsModel,
  ParcelCheckableModel,
  ParcelSearchFieldsModel,
} from "@/models/groupFilter";
import type { GroupCreateReqModel } from "@/models/groups";
import type { SimpleLandLinkModel } from "@/models/landLinks";
import type {
  InfiniteListParcelConductedSchemaModel,
  ParcelConductedModel,
} from "@/models/parcel";
import { dateToString } from "@/models/utils";
import { createGroup } from "@/resources/api/groups";
import { getFilteredConductedParcelsList } from "@/resources/api/parcels";
import { convertAreaSQMInHA } from "@/utils/area";
import {
  DEFAULT_ADD_GROUP_STATE_RESET,
  DEFAULT_CONDUCTOR_FORM,
  DEFAULT_PARCEL_FILTER,
} from "@/utils/defaultValues";
import { getSheetReference } from "@/utils/getSheetReference";
import { ErrorType } from "@abaco/safe-rest/src/HTTPClient";
import { defineStore } from "pinia";
import { useNotificationStore } from "./notification";
import { useSettingStore } from "./settings";
import i18n from "@/i18n";

export interface State {
  selectedParcelId: ParcelConductedModel | null;
  partyId: number | null;
  conduction: ConductorFieldsModel;
  parcelFilter: ParcelSearchFieldsModel;
  infiniteConductedParcels: InfiniteListParcelConductedSchemaModel | null;
  conductedParcelsList: ParcelConductedModel[];
  conductedParcelsListSelected: ParcelConductedModel[];
  mappedParcelsList: ParcelCheckableModel[];
  conductionPercentage: number;
  isLoading: boolean;
  hasError: boolean;
}

export const useAddGroupStore = defineStore({
  id: "addGroup",
  state: () =>
    ({
      selectedParcelId: null,
      partyId: null,
      conduction: structuredClone(DEFAULT_CONDUCTOR_FORM),
      parcelFilter: structuredClone(DEFAULT_PARCEL_FILTER),
      infiniteConductedParcels: null,
      conductedParcelsList: [],
      conductedParcelsListSelected: [],
      mappedParcelsList: [],
      isLoading: false,
      hasError: false,
      conductionPercentage: 100,
    }) as State,
  getters: {
    nextKey(state) {
      return state.infiniteConductedParcels?.nextKey ?? null;
    },
    count(state) {
      return state.infiniteConductedParcels?.count ?? 0;
    },
    hasConductedParcels(state) {
      return state.conductedParcelsList.length > 0;
    },
    hasConductedParcelsSelected(state) {
      return state.conductedParcelsListSelected.length > 0;
    },
    referenceDate(state) {
      return state.conduction.dayFrom;
    },
    // TODO controllare questo
    allParcelsChecked(state) {
      return state.mappedParcelsList.every((parcel) => parcel.checked);
    },
    hasSomeParcelsChecked(state) {
      return state.mappedParcelsList.some((parcel) => parcel.checked);
    },
    // hasCheckableParcels(state) {
    //   return state.mappedParcelsList.some((parcel) => parcel.showCheckbox);
    // },
    checkedParcelsList(state) {
      return state.mappedParcelsList.filter((parcel) => parcel.checked);
    },
  },
  actions: {
    setConduction(fields: ConductorFieldsModel) {
      this.conduction = fields;
    },
    setPartyId(partyId: string) {
      if (!isNaN(+partyId)) this.partyId = +partyId;
      else console.warn("Invalid partyId");
    },
    checkAllParcels() {
      const all_s = this.allParcelsChecked;
      this.mappedParcelsList.forEach((parcel) => {
        parcel.checked = !all_s;
      });
    },
    /**
     * Load on store parcels list
     * @param filter if true, load more option
     * @returns
     */
    async loadFilteredParcels(loadNext?: boolean) {
      const settings = useSettingStore().settings;
      if (!settings) {
        return;
      }
      if (!loadNext) {
        this.infiniteConductedParcels = null;
        this.parcelFilter.nextKey = null;
        this.parcelFilter.search_level = settings.parcelSearchLevel;
        this.conductedParcelsList = [];
        this.mappedParcelsList = [];
      } else if (loadNext && this.nextKey) {
        this.parcelFilter.nextKey = this.nextKey;
      }

      if (!this.partyId) {
        console.warn("partyId not valid");
        return;
      }

      this.isLoading = true;

      const response = await getFilteredConductedParcelsList(
        this.partyId,
        this.referenceDate,
        this.parcelFilter,
      );

      if (response.errorType !== ErrorType.NONE) {
        this.hasError = true;
        if (response.errorType === ErrorType.HTTP_STATUS) {
          console.warn(response.response);
        } else {
          console.warn(response.err);
        }
      } else {
        this.hasError = false;
        this.infiniteConductedParcels = response.data;
        this.conductedParcelsList = [
          ...this.conductedParcelsList,
          ...response.data.records,
        ];
        this.mappedParcelsList = [
          ...this.mappedParcelsList,
          ...parcelMapper(response.data.records),
        ];
      }
      this.isLoading = false;
    },
    setSelectedParcels() {
      this.checkedParcelsList.forEach((parcelChecked) => {
        const parcelConductedChecked = this.conductedParcelsList.find(
          (parcelConducted) => parcelConducted.parcel.id === +parcelChecked.id,
        );
        if (parcelConductedChecked) {
          this.conductedParcelsListSelected.push(parcelConductedChecked);
        }
      });
    },
    async createGroup() {
      if (!this.partyId) {
        console.warn("partyId not valid");
        return;
      }
      const landLinks: SimpleLandLinkModel[] =
        this.conductedParcelsListSelected.map((conductedParcel) => {
          return {
            parcelId: conductedParcel.parcel.id,
            titleTypePerc: this.conductionPercentage,
          };
        });

      const dayTo = this.conduction.dayTo
        ? dateToString.parse(new Date(this.conduction.dayTo))
        : INFINITE_DATE;

      const newGroupData: GroupCreateReqModel = {
        titleTypeId: +this.conduction.titleTypeId,
        dayFrom: dateToString.parse(this.conduction.dayFrom),
        dayTo,
        descr: this.conduction.description,
        landLinks,
      };

      this.isLoading = true;

      const resp = await createGroup(this.partyId, newGroupData);

      if (resp.errorType !== ErrorType.NONE) {
        console.warn(resp);
        if (resp.errorType === ErrorType.HTTP_STATUS) {
          /**
           * TODO: move logic to set conduction form
           *
           * handles specific errors (duplicated conduction description, ...)
           */
          try {
            const { errorCode, message } = await resp.response.json();

            const { te, t } = i18n.global;
            this.isLoading = false;

            let code =
              errorCode === "NO_AVAILABLE_DATE" ? message.match(/\d+/)[0] : "";

            if (code) {
              const parcel = this.conductedParcelsListSelected.find(
                (p) => p.parcel.id === +code,
              );

              if (parcel) {
                code = getSheetReference(parcel.parcel, true);
              }
            }
            return te(`${MODULE_ID}.errors.${errorCode}`)
              ? t(`${MODULE_ID}.errors.${errorCode}`, { code })
              : message;
          } catch (err) {
            console.warn(err);
          }
        }
        this.isLoading = false;
      } else {
        this.isLoading = false;
        useNotificationStore().setMessage(resp);
        return resp.data;
      }
    },
    deleteSelectedParcel(id: number) {
      this.conductedParcelsListSelected.splice(id, 1);
    },
    flushSelectedParcels() {
      this.conductedParcelsListSelected = [];
    },
    resetAllExceptParty() {
      Object.assign(this, DEFAULT_ADD_GROUP_STATE_RESET);
    },
    resetParcelFilter() {
      Object.assign(this.parcelFilter, structuredClone(DEFAULT_PARCEL_FILTER));
    },
  },
});

function parcelMapper(
  parcelsList: ParcelConductedModel[],
): ParcelCheckableModel[] {
  return parcelsList.map((conductedParcel) => {
    return {
      id: conductedParcel.parcel.id.toString(),
      sheetReferences: getSheetReference(conductedParcel.parcel, true),
      surface_in_ha: convertAreaSQMInHA(conductedParcel.parcel.areaSqm ?? 0),
      leadings: conductedParcel.leadings,
      checked: false,
    };
  });
}
