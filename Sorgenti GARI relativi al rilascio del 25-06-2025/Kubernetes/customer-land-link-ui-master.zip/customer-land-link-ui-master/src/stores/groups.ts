import { ZodError } from "zod";
import type {
  GroupSearchFilterModel,
  GroupResModel,
  InfiniteListResultsGroupResModel,
} from "@/models/groups";
import { getGroups } from "@/resources/api/groups";
import { ErrorType } from "@abaco/safe-rest/src/HTTPClient";
import { defineStore } from "pinia";
// import { type RemovableRef, useSessionStorage } from "@vueuse/core";
import { toRaw } from "vue";
import { isEqual, uniqWith } from "lodash";

export interface State {
  reference_date: Date;
  infiniteGroupsList: InfiniteListResultsGroupResModel | null;
  groups: GroupResModel[];
  // filters: RemovableRef<GroupSearchFilterModel>;
  filters: GroupSearchFilterModel;
  loading: boolean;
  error: boolean;
}

const SEARCH_FILTER_DEFAULT_VALUES: GroupSearchFilterModel = {
  titleTypeId: null,
  descr: null,
  showElapsed: false,
  nextKey: null,
};

const initialState: Readonly<State> = {
  infiniteGroupsList: null,
  reference_date: new Date(),
  groups: [],
  loading: false,
  error: false,
  filters: SEARCH_FILTER_DEFAULT_VALUES,
};

const state: State = structuredClone(initialState);

export const useGroupsStore = defineStore({
  id: "groups",
  state: (): State => state,
  getters: {
    count(state) {
      return state.infiniteGroupsList?.count ?? 0;
    },
    nextKey(state) {
      return state.infiniteGroupsList?.nextKey ?? null;
    },
  },
  actions: {
    async searchGroups(partyId: number, loadNext?: boolean) {
      if (!loadNext) {
        this.infiniteGroupsList = null;
        this.filters.nextKey = null;
        this.groups = [];
      } else if (loadNext && this.nextKey) {
        this.filters.nextKey = this.nextKey;
      }

      this.loading = true;
      const resp = await getGroups(
        partyId,
        this.reference_date,
        toRaw(this.filters),
      );

      if (resp.errorType !== ErrorType.NONE) {
        if (
          resp.errorType === ErrorType.OTHER &&
          resp.err instanceof ZodError
        ) {
          console.warn(resp.err);
        } else if (resp.errorType === ErrorType.HTTP_STATUS) {
          console.warn(resp.response);
        } else {
          console.warn(resp.err);
        }
        this.error = true;
      } else {
        this.error = false;
        this.infiniteGroupsList = resp.data;
        this.groups = [...this.groups, ...resp.data.records];

        /**
         * avoid duplicated values on not active groups
         * @see src\components\group\GroupFilterMainContent.vue line 88
         */
        this.groups = uniqWith(this.groups, isEqual);
      }

      this.loading = false;
    },
    async resetFilter() {
      // this.filters = structuredClone(SEARCH_FILTER_DEFAULT_VALUES);
    },
    $reset() {
      this.$state = structuredClone(initialState);
    },
  },
});
