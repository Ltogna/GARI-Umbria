import type { CllSettingsModel } from "@/models/settings";
import { getCllSettings } from "@/resources/api/cll-settings-public-api";
import { ErrorType } from "@abaco/safe-rest/src/HTTPClient";
import { cloneDeep } from "lodash";
import { defineStore } from "pinia";
import { useNotificationStore } from "./notification";

interface State {
  settings: CllSettingsModel | null;
  hasError: boolean;
  isLoading: boolean;
}

export const useSettingStore = defineStore({
  id: "settings",
  state: () =>
    ({
      settings: null,
      hasError: false,
      isLoading: false,
    }) as State,
  getters: {
    canUpdateClosedElements(state) {
      return !!state.settings?.allowEditDayToParcelInThePast;
    },
  },
  actions: {
    async fetchSettings() {
      this.isLoading = true;

      const response = await getCllSettings();

      if (response.errorType !== ErrorType.NONE) {
        this.hasError = true;
        if (response.errorType === ErrorType.HTTP_STATUS) {
          useNotificationStore().setErrorMessage(response);
          console.warn(response.response);
        } else {
          console.warn(response.err);
        }
      } else {
        this.hasError = false;
        this.settings = cloneDeep(response.data);
      }

      this.isLoading = false;
    },
  },
});
