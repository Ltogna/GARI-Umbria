import type {
  ParcelCheckableModel,
  ParcelSearchFieldsModel,
} from "@/models/groupFilter";
import type { GroupResModel } from "@/models/groups";
import type { SimpleLandLinkModel } from "@/models/landLinks";
import type {
  InfiniteListParcelConductedSchemaModel,
  ParcelConductedModel,
} from "@/models/parcel";
import { getGroup } from "@/resources/api/groups";
import { addLandLinksToGroup } from "@/resources/api/landLink";
import { getFilteredConductedParcelsList } from "@/resources/api/parcels";
import { convertAreaSQMInHA } from "@/utils/area";
import { DEFAULT_PARCEL_FILTER } from "@/utils/defaultValues";
import { getSheetReference } from "@/utils/getSheetReference";
import { isEditable } from "@/utils/isGroupEditable";
import { ErrorType } from "@abaco/safe-rest/src/HTTPClient";
import { defineStore } from "pinia";
import { useNotificationStore } from "./notification";
import { useSettingStore } from "./settings";
import i18n from "@/i18n";
import { MODULE_ID } from "@/constants";

interface State {
  group: GroupResModel | null;
  groupId: number | null;
  partyId: number | null;
  isLoading: boolean;
  hasError: boolean;
  infiniteConductedParcels: InfiniteListParcelConductedSchemaModel | null;
  mappedParcelsList: ParcelCheckableModel[];
  conductedParcelsList: ParcelConductedModel[];
  parcelFilter: ParcelSearchFieldsModel;
  conductedParcelsListSelected: ParcelConductedModel[];
  conductionPercentage: number;
}

export const useAddParcelsGroupStore = defineStore({
  id: "addParcelsGroup",
  state: () =>
    ({
      group: null,
      partyId: null,
      groupId: null,
      isLoading: false,
      hasError: false,
      mappedParcelsList: [],
      infiniteConductedParcels: null,
      parcelFilter: structuredClone(DEFAULT_PARCEL_FILTER),
      conductedParcelsList: [],
      conductedParcelsListSelected: [],
      conductionPercentage: 100,
    }) as State,
  getters: {
    referenceDate(state) {
      return state.group?.dayFrom ?? new Date();
    },
    isEditable(state) {
      if (state.group) {
        return isEditable(state.group);
      }

      return false;
    },
    // TODO  constrolalre questo!!
    allParcelsChecked(state) {
      return state.mappedParcelsList.every((parcel) => parcel.checked);
    },
    nextKey(state) {
      return state.infiniteConductedParcels?.nextKey ?? null;
    },
    hasSomeParcelsChecked(state) {
      return state.mappedParcelsList.some((parcel) => parcel.checked);
    },
    // hasCheckableParcels(state) {
    //   return state.mappedParcelsList.some((parcel) => parcel.showCheckbox);
    // },
    checkedParcelsList(state) {
      return state.mappedParcelsList.filter((parcel) => parcel.checked);
    },
    hasConductedParcels(state) {
      return state.conductedParcelsList.length > 0;
    },
    hasConductedParcelsSelected(state) {
      return state.conductedParcelsListSelected.length > 0;
    },
  },
  actions: {
    setPartyId(partyId: number) {
      this.partyId = partyId;
    },
    setGroupId(groupId: number) {
      this.groupId = groupId;
    },
    async fetchGroup() {
      if (!this.groupId) {
        console.warn("Group id not found");
        return;
      }
      if (!this.partyId) {
        console.warn("Party id not found");
        return;
      }
      this.isLoading = true;
      const response = await getGroup(this.partyId, this.groupId);
      if (response.errorType !== ErrorType.NONE) {
        this.hasError = true;
        console.warn(response);
      } else {
        this.hasError = false;
        this.group = response.data;
      }
      this.isLoading = false;
    },

    checkAllParcels() {
      const all_s = this.allParcelsChecked;
      this.mappedParcelsList.forEach((parcel) => {
        parcel.checked = !all_s;
      });
    },
    /**
     * Load on store parcels list
     * @param filter if true, load more option
     * @returns
     */
    async loadFilteredParcels(loadNext?: boolean) {
      const settings = useSettingStore().settings;
      if (!settings) {
        return;
      }
      if (!loadNext) {
        this.infiniteConductedParcels = null;
        this.parcelFilter.nextKey = null;
        this.parcelFilter.search_level = settings.parcelSearchLevel;
        this.conductedParcelsList = [];
        this.mappedParcelsList = [];
      } else if (loadNext && this.nextKey) {
        this.parcelFilter.nextKey = this.nextKey;
      }

      if (!this.partyId) {
        console.warn("partyId not valid");
        return;
      }

      this.isLoading = true;

      const response = await getFilteredConductedParcelsList(
        this.partyId,
        this.referenceDate,
        this.parcelFilter,
      );

      if (response.errorType !== ErrorType.NONE) {
        this.hasError = true;
        if (response.errorType === ErrorType.HTTP_STATUS) {
          console.warn(response.response);
        } else {
          console.warn(response.err);
        }
      } else {
        this.hasError = false;
        this.infiniteConductedParcels = response.data;
        this.conductedParcelsList = [
          ...this.conductedParcelsList,
          ...response.data.records,
        ];
        this.mappedParcelsList = [
          ...this.mappedParcelsList,
          ...parcelMapper(response.data.records),
        ];
      }
      this.isLoading = false;
    },
    setSelectedParcels() {
      this.checkedParcelsList.forEach((parcelChecked) => {
        const parcelConductedChecked = this.conductedParcelsList.find(
          (parcelConducted) => parcelConducted.parcel.id === +parcelChecked.id,
        );
        if (parcelConductedChecked) {
          this.conductedParcelsListSelected.push(parcelConductedChecked);
        }
      });
    },
    async updateGroupParcels() {
      if (!this.groupId) {
        console.warn("Group id not found");
        return;
      }
      if (!this.partyId) {
        console.warn("Party id not found");
        return;
      }

      this.isLoading = true;

      const data: SimpleLandLinkModel[] = this.conductedParcelsListSelected.map(
        ({ parcel }) => {
          return {
            parcelId: parcel.id,
            titleTypePerc: this.conductionPercentage,
          };
        },
      );

      const resp = await addLandLinksToGroup(this.partyId, this.groupId, data);

      if (resp.errorType !== ErrorType.NONE) {
        console.warn(resp);
        if (resp.errorType === ErrorType.HTTP_STATUS) {
          /**
           * TODO: move logic to set conduction form
           *
           * handles specific errors (duplicated conduction description, ...)
           */
          try {
            const { errorCode, message } = await resp.response.json();
            const { te, t } = i18n.global;
            this.isLoading = false;
            let code =
              errorCode === "NO_AVAILABLE_DATE" ? message.match(/\d+/)[0] : "";

            if (code) {
              const parcel = this.conductedParcelsListSelected.find(
                (p) => p.parcel.id === +code,
              );

              if (parcel) {
                code = getSheetReference(parcel.parcel, true);
              }
            }
            return te(`${MODULE_ID}.errors.${errorCode}`)
              ? t(`${MODULE_ID}.errors.${errorCode}`, { code })
              : message;
          } catch (err) {
            console.warn(err);
          }
        }
        this.isLoading = false;
      } else {
        this.isLoading = false;
        useNotificationStore().setMessage(resp);
        return resp.data;
      }
    },
    deleteSelectedParcel(id: number) {
      this.conductedParcelsListSelected.splice(id, 1);
    },
    resetParcelFilter() {
      Object.assign(this.parcelFilter, structuredClone(DEFAULT_PARCEL_FILTER));
    },
    flushSelectedParcels() {
      this.conductedParcelsListSelected = [];
    },
  },
});

function parcelMapper(
  parcelsList: ParcelConductedModel[],
): ParcelCheckableModel[] {
  return parcelsList.map((conductedParcel) => {
    return {
      id: conductedParcel.parcel.id.toString(),
      sheetReferences: getSheetReference(conductedParcel.parcel, true),
      surface_in_ha: convertAreaSQMInHA(conductedParcel.parcel.areaSqm ?? 0),
      leadings: conductedParcel.leadings,
      checked: false,
      // TODO RIMUOVERE!!!
      showCheckbox: true, // !conductedParcel.conduzioneByCurrentParty,
    };
  });
}
