import { inject } from "vue";

export default function () {
  const canWrite = (inject("hasPermissionWrite") as boolean) ?? false;
  //! TEST ONLY
  // const canWrite = false;

  const canRead = (inject("hasPermissionRead") as boolean) ?? false;

  return {
    /**
     * Embedded mode
     */
    canRead,
    /**
     * Fullscreen mode
     */
    canWrite,
  };
}
