import { computed } from "vue";
import { useRoute } from "vue-router";

export default () => {
  const route = useRoute();

  const landlinkId = computed<number | null>(() => {
    const param = route.params.landlinkId;
    if (Array.isArray(param) && param.length) {
      return +param[0];
    }
    if (param) {
      return +param;
    }
    return null;
  });

  return {
    landlinkId,
  };
};
