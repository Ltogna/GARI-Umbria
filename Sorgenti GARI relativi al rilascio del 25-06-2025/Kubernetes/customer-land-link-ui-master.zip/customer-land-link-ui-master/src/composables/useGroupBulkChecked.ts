import { computed } from "vue";
import { useGroupsStore } from "@/stores/groups";

export default function () {
  const groupsStore = useGroupsStore();
  const allChecked = computed(() => groupsStore.groups.every((e) => e.checked));
  const allNoChecked = computed(() =>
    groupsStore.groups.every((e) => !e.checked),
  );
  const hasSomeCheked = computed(() =>
    groupsStore.groups.some((e) => e.checked),
  );
  const isCheckboxIndeterminate = computed(() => {
    return !allNoChecked.value && !allChecked.value;
  });
  const getCheckedIds = computed(() => {
    return groupsStore.groups.filter((l) => l.checked).map((l) => l.id);
  });

  return {
    hasSomeCheked,
    allChecked,
    allNoChecked,
    isCheckboxIndeterminate,
    getCheckedIds,
  };
}
