import type { SectorModel } from "@/models/sector";
import { getSectorsByFilter } from "@/resources/api/sectors";
import { ErrorType } from "@abaco/safe-rest/src/HTTPClient";

export function useSector() {
  async function searchSector(searchToken: string): Promise<SectorModel[]> {
    const response = await getSectorsByFilter(searchToken);

    if (response.errorType !== ErrorType.NONE) {
      if (response.errorType === ErrorType.HTTP_STATUS) {
        console.warn(response.response);
      } else {
        console.warn(response.err);
      }

      return [];
    } else {
      return response.data;
    }
  }

  async function getSector(searchToken: string): Promise<SectorModel | null> {
    const response = await getSectorsByFilter(searchToken);

    if (response.errorType !== ErrorType.NONE) {
      if (response.errorType === ErrorType.HTTP_STATUS) {
        console.warn(response.response);
      } else {
        console.warn(response.err);
      }

      return null;
    } else {
      return (
        response.data.find((sec) => sec.sectorCode === searchToken) ?? null
      );
    }
  }

  return {
    searchSector,
    getSector,
  };
}
