import { ref } from "vue";
import { getFieldSelector } from "@/utils/formUtils";

export default function useForm<T extends { [s: string]: unknown }>(
  submitCallback: () => unknown,
  form: T,
  formId: string,
) {
  const validate = ref();
  const isSubmitted = ref(false);

  function onValidate(elemName: string): Promise<boolean> {
    const elemId = getFieldSelector(formId, elemName);
    if (validate.value.fields[elemId]) {
      return validate.value.revalidateField(elemId);
    }

    return Promise.resolve(true);
  }

  function onSubmit() {
    isSubmitted.value = true;
    if (validate.value) {
      validate.value.revalidate().then((isValid: boolean) => {
        if (isValid) {
          submitCallback();
        }
      });
    } else submitCallback();
  }

  function onReset(defaultForm?: T) {
    if (defaultForm) {
      form = defaultForm;
    } else {
      Object.keys(form).forEach((key) => {
        delete form[key];
      });
    }
    validate.value.refresh();
    isSubmitted.value = false;
  }

  return {
    validate,
    isSubmitted,
    onValidate,
    onSubmit,
    onReset,
  };
}
