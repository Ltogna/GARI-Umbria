import { computed } from "vue";
import { useRoute } from "vue-router";

export default () => {
  const route = useRoute();

  const groupId = computed(() => {
    return (route.params.groupId as string) ?? "";
  });

  return {
    groupId,
  };
};
