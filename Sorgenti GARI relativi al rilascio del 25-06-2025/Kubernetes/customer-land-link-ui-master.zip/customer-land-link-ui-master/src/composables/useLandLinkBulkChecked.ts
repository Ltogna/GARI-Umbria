import { computed } from "vue";
import { useLandLinksBulkStore } from "@/stores/landLinksBulk";

export default function () {
  const landLinkStore = useLandLinksBulkStore();
  const allChecked = computed(() =>
    landLinkStore.landLinks.every((e) => e.checked),
  );
  const allNoChecked = computed(() =>
    landLinkStore.landLinks.every((e) => !e.checked),
  );
  const hasSomeCheked = computed(() =>
    landLinkStore.landLinks.some((e) => e.checked),
  );
  const isCheckboxIndeterminate = computed(() => {
    return !allNoChecked.value && !allChecked.value;
  });
  const getCheckedIds = computed(() => {
    return landLinkStore.landLinks.filter((l) => l.checked).map((l) => l.id);
  });

  return {
    hasSomeCheked,
    allChecked,
    allNoChecked,
    isCheckboxIndeterminate,
    getCheckedIds,
  };
}
