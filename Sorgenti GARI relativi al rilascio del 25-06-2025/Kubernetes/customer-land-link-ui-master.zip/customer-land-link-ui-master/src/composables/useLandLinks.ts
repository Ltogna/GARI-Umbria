// import type { LandLinkModel } from "@/models/landLink";
import type { ParcelModel } from "@/models/parcel";

export default () => {
  function getSheetReference(
    parcel: ParcelModel,
    showParcelCode?: boolean,
    //, hideCity?: boolean
  ): string {
    const data: string[] = [];
    if (parcel.sector?.sectorCode) {
      parcel.sector?.sectorCode && data.push(parcel.sector?.sectorCode);
    }
    if (parcel.sector?.shortDescr) {
      parcel.sector?.shortDescr && data.push(parcel.sector?.shortDescr);
    }
    if (parcel.block?.blockCode) {
      parcel.block?.blockCode && data.push(parcel.block?.blockCode);
    }
    if (showParcelCode) {
      parcel.parcel && data.push(parcel.parcel);
    }

    return data.join(" - ");
  }

  return {
    getSheetReference,
  };
};
