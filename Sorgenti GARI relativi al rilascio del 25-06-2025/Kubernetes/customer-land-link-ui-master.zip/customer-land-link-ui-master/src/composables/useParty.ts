import { computed } from "vue";
import { useRoute } from "vue-router";

export default () => {
  const route = useRoute();

  const partyId = computed(() => {
    return (route.params.partyId as string) ?? "";
  });

  return {
    partyId,
  };
};
