import { ref, watch } from "vue";

const fullscreenActive = ref(false);

export default function () {
  function unmount() {
    window.document.body.style.overflow = "";
  }

  watch(
    fullscreenActive,
    (fullscreenActive) => {
      if (fullscreenActive) {
        window.document.body.style.overflow = "hidden";
      } else {
        window.document.body.style.overflow = "";
      }
    },
    { immediate: true },
  );

  return {
    fullscreenActive,
    unmount,
  };
}
