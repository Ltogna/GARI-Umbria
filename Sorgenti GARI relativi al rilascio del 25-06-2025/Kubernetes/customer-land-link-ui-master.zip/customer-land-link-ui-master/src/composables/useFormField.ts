import { computed, ref, type Ref } from "vue";

export interface FormFieldEmits {
  (e: "update:modelValue", value: string): void;
  (e: "validate", value: string): void;
}

export interface FormFieldProps {
  id: string;
  name: string;
  modelValue?: unknown;
  isDisabled?: boolean;
  isReadonly?: boolean;
  info?: string;
  label?: string;
  extraClasses?: string[];
  validatorFn?: (id: string, value?: string) => Promise<boolean | string[]>;
  formatFn?: (value: unknown) => string;
}

type ErrorType = Ref<string[]>;

export function useFormField<
  T extends FormFieldProps,
  S extends FormFieldEmits,
>(props: T, emit: S, errors?: ErrorType, isAutocomplete?: boolean) {
  const isBlurred = ref(false);

  const isValid = ref(true);

  const helpId = computed(() => {
    return `${props.id}-helpDescription`;
  });

  async function validate(evt: Event) {
    if (props.validatorFn) {
      try {
        const value = (evt.target as HTMLInputElement | HTMLSelectElement)
          .value;
        const e = await props.validatorFn(props.name, value);
        isValid.value = !!e;
        if (errors) {
          errors.value = Array.isArray(e) ? e : [];
        }
      } catch (e) {
        isValid.value = false;
        if (errors) {
          errors.value = [];
        }
      }
    }
  }

  const onBlur = (e: Event) => {
    isBlurred.value = true;
    validate(e);
  };

  const onInput = (e: Event) => {
    if (isBlurred.value) {
      validate(e);
    }
    emitUpdateModelValue(e);
  };

  const onChange = (e: Event) => {
    if (isBlurred.value) {
      validate(e);
    }
    emitUpdateModelValue(e);
  };

  function formatInputValue(value: unknown) {
    if (props.formatFn) {
      return props.formatFn(value);
    }

    return value;
  }

  function emitUpdateModelValue(e: Event) {
    const value = formatInputValue(
      (e.target as HTMLInputElement | HTMLSelectElement).value,
    );
    !isAutocomplete && emit("update:modelValue", value as string);
  }

  return {
    isValid,
    helpId,
    validate,
    onBlur,
    onInput,
    onChange,
  };
}
