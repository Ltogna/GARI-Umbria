import { DEFAULT_DATE_FORMAT } from "@/constants";
import { inject } from "vue";

export default function (): string {
  return inject("userDateFormat") ?? DEFAULT_DATE_FORMAT;
}
