import type { Emitter } from "mitt";
import { inject } from "vue";

type Events = {
  "saved:group": void;
  "set:conduction": void;
  "unset:conduction": void;
  "add:selected:parcels": void;
  "close:selected:parcels": void;
  "delete:parcel": number;
  "update:percentage": number;
  "is:dirty": boolean;
};

export default function (): Emitter<Events> {
  return inject("emitter") as Emitter<Events>;
}
