<script setup lang="ts">
import useLandLinks from "@/composables/useLandLinks";
import useModuleId from "@/composables/useModuleId";
import usePermissions from "@/composables/usePermissions";
import useUserDateFormat from "@/composables/useUserDateFormat";
import { INFINITE_DATE } from "@/constants";
import { useLandLinksStore } from "@/stores/landLinks";
import {
  convertAreaSQMInHA,
  intlNumberFormatOptions,
  percNumberFormatOption,
} from "@/utils/area";
import { gotoViewer } from "@/utils/gotoViewer";
import BiAlert from "@abaco/bootstrap-italia-components/src/components/BiAlert/BiAlert.vue";
import BiButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiButton.vue";
import BiIconButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiIconButton.vue";
import BiTable from "@abaco/bootstrap-italia-components/src/components/BiTable/BiTable.vue";
import { format } from "date-fns";
import { computed, inject } from "vue";
import { useI18n } from "vue-i18n";
import { useRouter } from "vue-router";
import AnomalyTooltipIcon from "../common/AnomalyTooltipIcon.vue";
import { RouteName } from "@/models/routes";
import BiHiddenContent from "@abaco/bootstrap-italia-components/src/components/BiHiddenContent/BiHiddenContent.vue";

const moduleId = useModuleId();
const basePath = inject<string>("basePath", import.meta.env.BASE_URL);
const { t, n } = useI18n();
const landLinkStore = useLandLinksStore();
const { getSheetReference } = useLandLinks();
const router = useRouter();

const { canWrite } = usePermissions();
const userDateFormat = useUserDateFormat();

const today = new Date();
const isReferenceDateToday = computed(
  () =>
    format(landLinkStore.reference_date, "yyyyMMdd") ===
    format(today, "yyyyMMdd"),
);

const goToEditLandLink = (landlinkId: number) => {
  router.push({ name: RouteName.LAND_LINK_EDIT, params: { landlinkId } });
};
const goToDetailLandLink = (landlinkId: number) => {
  router.push({ name: RouteName.LAND_LINK_DETAIL, params: { landlinkId } });
};

const loadMore = async () => {
  await landLinkStore.searchLandLinks(true);
};
</script>

<template>
  <div class="customer-land-link__pager-info fw-semibold small mb-1">
    {{ t(`${moduleId}.landLink_total`, 2) }}: {{ landLinkStore.count }}
  </div>
  <BiTable
    class="table-hover mb-0 table-responsive"
    extraTableClasses="table-head-bg"
    is-custom
    responsive-breakpoint="md"
    isRowHover
  >
    <template #head>
      <tr class="bg-light">
        <th scope="col">
          {{ t(`${moduleId}.sheet_references`) }}
        </th>
        <th scope="col">
          {{ t(`${moduleId}.landLink_list.surface_gis_ha`) }}
        </th>
        <th scope="col">
          {{ t(`${moduleId}.conduction`, 1) }}
        </th>
        <th scope="col">
          {{ t(`${moduleId}.landLink_list.surface_cond_ha`) }}
        </th>
        <th scope="col">
          {{ t(`${moduleId}.landLink_list.conduction_period`) }}
        </th>
        <th scope="col" class="text-center">
          {{ t(`${moduleId}.landLink_list.anomalies`) }}
        </th>
        <th scope="col">
          <BiHiddenContent :text="t(`${moduleId}.action`, 2)">
          </BiHiddenContent>
        </th>
      </tr>
    </template>
    <template #body>
      <tr v-for="landLink in landLinkStore.landLinks" :key="landLink.id">
        <td
          :data-label="t(`${moduleId}.sheet_references`)"
          class="text-break max-w-xs"
        >
          {{ getSheetReference(landLink.parcel, true) }}
        </td>
        <td :data-label="t(`${moduleId}.landLink_list.surface_gis_ha`)">
          {{
            n(
              convertAreaSQMInHA(landLink.parcel.areaSqm ?? 0),
              intlNumberFormatOptions,
            )
          }}
        </td>
        <td :data-label="t(`${moduleId}.conduction`, 1)">
          {{ landLink.titleType.i18nCode }}
          {{ n(landLink.titleTypePerc, percNumberFormatOption) }}%
        </td>
        <td :data-label="t(`${moduleId}.landLink_list.surface_cond_ha`)">
          {{
            n(
              convertAreaSQMInHA(landLink.titleTypeAreaSqm ?? 0),
              intlNumberFormatOptions,
            )
          }}
        </td>
        <td :data-label="t(`${moduleId}.landLink_list.conduction_period`)">
          <div>
            {{ format(landLink.dayFrom, userDateFormat) }}
          </div>
          <div v-if="format(landLink.dayTo, 'yyyyMMdd') !== INFINITE_DATE">
            {{ format(landLink.dayTo, userDateFormat) }}
          </div>
        </td>
        <td
          class="text-center"
          :data-label="t(`${moduleId}.landLink_list.anomalies`)"
        >
          <AnomalyTooltipIcon
            v-if="landLink.anomalyCount && landLink.maxAnomalyLevel"
            :max-anomaly-level="landLink.maxAnomalyLevel"
            :count-anomalies="landLink.anomalyCount"
          />
        </td>
        <td :data-label="t(`${moduleId}.action`, 2)">
          <div class="d-flex flex-nowrap">
            <BiIconButton
              v-if="canWrite && isReferenceDateToday"
              class="me-2"
              is-outlined
              :title="t(`${moduleId}.goto_edit_landlink`)"
              :icon="'pencil'"
              icon-style="fas"
              :color="'secondary'"
              :is-disabled="landLinkStore.isLoading"
              @click="goToEditLandLink(landLink.id)"
            />
            <BiIconButton
              v-if="!isReferenceDateToday"
              class="me-2"
              is-outlined
              :title="t(`${moduleId}.goto_detail_landlink`)"
              :icon="'arrow-right'"
              icon-style="fas"
              :color="'secondary'"
              :is-disabled="landLinkStore.isLoading"
              @click="goToDetailLandLink(landLink.id)"
            />
            <BiIconButton
              v-if="landLink.titleTypeAreaSqm && landLink.titleTypeAreaSqm > 0"
              class="me-2"
              is-outlined
              :title="t(`${moduleId}.open_viewer`)"
              :icon="'map-location-dot'"
              icon-style="fas"
              :color="'secondary'"
              :is-disabled="landLinkStore.isLoading || !landLink.parcel.id"
              @click="gotoViewer(landLink.parcel.id, basePath)"
            />
          </div>
        </td>
      </tr>
      <tr style="justify-content: center" v-if="landLinkStore.nextKey">
        <td colspan="9999" class="text-center">
          <BiButton
            color="primary"
            is-outlined
            class="py-1 px-2"
            :is-disabled="landLinkStore.isLoading"
            @click="loadMore"
          >
            {{ t(`${moduleId}.load_more`) }}
          </BiButton>
        </td>
      </tr>
    </template>
  </BiTable>

  <BiAlert
    v-if="!landLinkStore.isLoading && !landLinkStore.hasLandLinks"
    isInfo
    class="mt-3"
    :title="t(`${moduleId}.no_landLinks_found`)"
  />
</template>
<style lang="scss" scoped>
.max-w-xs {
  max-width: 20rem;
}
.w-max {
  width: max-content;
}
</style>
