<script setup lang="ts">
import BiButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiButton.vue";
import { computed, defineProps, defineEmits } from "vue";
import { useI18n } from "vue-i18n";
import BiModal from "@abaco/bootstrap-italia-components/src/components/BiModal/BiModal.vue";
import BiAlert from "@abaco/bootstrap-italia-components/src/components/BiAlert/BiAlert.vue";
import useModuleId from "@/composables/useModuleId";

const { t } = useI18n();
const moduleId = useModuleId();

// eslint-disable-next-line @typescript-eslint/no-unused-vars
const props = defineProps<{
  onDelete: () => Promise<void>;
  modelValue: boolean;
  parcelMessage?: boolean;
  groupMessage?: boolean;
}>();

const emits = defineEmits<{
  (e: "update:modelValue", value: boolean): void;
  (e: "hidden-modal"): void;
}>();

const closeModal = () => {
  emits("update:modelValue", false);
};

const deleteMessage = computed(() => {
  return props.parcelMessage
    ? t(`${moduleId}.landLink_form.delete_message_parcel`)
    : props.groupMessage
      ? t(`${moduleId}.landLink_form.delete_message_group`)
      : "";
});

function hiddenModalHandler() {
  emits("hidden-modal");
}
</script>

<template>
  <BiModal
    :model-value="modelValue"
    :title="t(`${moduleId}.landLink_form.delete`)"
    size="lg"
    extra-header-class="p-4"
    extra-footer-class="justify-content-center"
    @hiddenModal="hiddenModalHandler"
  >
    <template #body>
      <BiAlert :title="t(`${moduleId}.warning`)" is-warn>
        <template #body>
          <strong>{{ deleteMessage }}</strong>
        </template>
      </BiAlert>
    </template>
    <template #footer>
      <BiButton @click="closeModal" color="primary" is-outlined>
        {{ t(`${moduleId}.close`) }}
      </BiButton>
      <BiButton color="success" @click="onDelete">
        {{ t(`${moduleId}.landLink_form.confirm`) }}
      </BiButton>
    </template>
  </BiModal>
</template>
