<script lang="ts" setup>
import useModuleId from "@/composables/useModuleId";
import BiButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiButton.vue";
import { getUUID } from "@abaco/bootstrap-italia-components/src/utilities";
import { useI18n } from "vue-i18n";
import { ref, onMounted, watch } from "vue";
import BiSelect from "@abaco/bootstrap-italia-components/src/components/form/BiSelect.vue";
import {
  getCropRotationList,
  getIrrigationTypeList,
} from "@/resources/api/landLink";
import { ErrorType } from "@abaco/safe-rest/src/HTTPClient";
import type { SelectModel } from "@/models/utils";

const formId = getUUID();
const { t } = useI18n();
const moduleId = useModuleId();

const modelIrrigation = ref<string>("");
const modelCropRotation = ref<string>("");

const irrigationOptions = ref<SelectModel[]>([]);
const cropRotationOptions = ref<SelectModel[]>([]);

onMounted(async () => {
  const irrigationResp = await getIrrigationTypeList();
  if (irrigationResp.errorType !== ErrorType.NONE) {
    console.warn(irrigationResp);
  } else {
    irrigationOptions.value = irrigationResp.data;
  }

  const cropRotationResp = await getCropRotationList();
  if (cropRotationResp.errorType !== ErrorType.NONE) {
    console.warn(cropRotationResp);
  } else {
    cropRotationOptions.value = cropRotationResp.data;
  }
});

// async function onSubmit() {
//   console.log("submit");
// }

watch(cropRotationOptions, (value) => {
  if (value.length > 0) {
    modelCropRotation.value = value[0].id;
  }
});
</script>

<template>
  <form
    :id="formId"
    class="customer-land-link__landLink-form needs-validation mt-4"
    ref="formRef"
  >
    <div class="row">
      <div class="col-md-6">
        <BiSelect
          :label="t(`${moduleId}.additional_info.irrigation_type`)"
          :emptyOption="'nessun valore'"
          :items="irrigationOptions"
          v-model="modelIrrigation"
        ></BiSelect>
      </div>
      <div class="col-md-6">
        <BiSelect
          :label="t(`${moduleId}.additional_info.crop_rotation`)"
          :items="cropRotationOptions"
          v-model="modelCropRotation"
        ></BiSelect>
      </div>
    </div>

    <div class="d-flex justify-content-center mt-5">
      <div>
        <BiButton class="me-3" color="primary" is-outlined>
          {{ t(`${moduleId}.close`) }}
        </BiButton>
      </div>

      <div>
        <BiButton color="success" type="submit">
          {{ t(`${moduleId}.landLink_form.confirm`) }}
        </BiButton>
      </div>
    </div>
  </form>
</template>

<style lang="scss"></style>
