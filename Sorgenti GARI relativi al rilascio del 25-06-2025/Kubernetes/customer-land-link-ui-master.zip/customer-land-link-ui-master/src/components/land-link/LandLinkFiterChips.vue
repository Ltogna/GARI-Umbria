<script setup lang="ts">
import useModuleId from "@/composables/useModuleId";
import { useLandLinksStore } from "@/stores/landLinks";
import { useTitleTypesStore } from "@/stores/titleTypes";
import BiChip from "@abaco/bootstrap-italia-components/src/components/BiChip/BiChip.vue";
import { format } from "date-fns";
import { computed, ref, watch, defineProps } from "vue";
import { useI18n } from "vue-i18n";
import { type LandLinkSearchFilterModel } from "@/models/landLink";
import { AnomalyLevelSchema } from "@/models/anomalyLevel";
import { useSector } from "@/composables/useSector";
import type { SectorModel } from "@/models/sector";
import { useLandLinksBulkStore } from "@/stores/landLinksBulk";
import useUserDateFormat from "@/composables/useUserDateFormat";

type LandLinkFilterField = keyof LandLinkSearchFilterModel;

const selectedSector = ref<SectorModel | undefined>();

const landLinksBulkStore = useLandLinksBulkStore();
const props = defineProps<{
  isBulk?: boolean;
}>();

const landLinksStore = props.isBulk
  ? useLandLinksBulkStore()
  : useLandLinksStore();

const moduleId = useModuleId();
const { t } = useI18n();
const titleTypesStore = useTitleTypesStore();
const { getSector } = useSector();
const userDateFormat = useUserDateFormat();

const referenceDate = computed(() => {
  const reference_date = props.isBulk
    ? landLinksBulkStore.reference_date
    : landLinksStore.reference_date;
  return format(reference_date, userDateFormat);
});
const parcel = computed(() => {
  const label = t(`${moduleId}.landLink_filter_form.parcel`);
  const value = landLinksStore.searchFilter.parcelCode;

  return value ? `${label}: ${value}` : null;
});
const subParcel = computed(() => {
  const label = t(`${moduleId}.landLink_filter_form.subParcel`);
  const value = landLinksStore.searchFilter.subParcelCode;

  return value ? `${label}: ${value}` : null;
});
const blockCode = computed(() => {
  const label = t(`${moduleId}.landLink_filter_form.sheet`);
  const value = landLinksStore.searchFilter.blockCode;

  return value ? `${label}: ${value}` : null;
});
const sectorCode = computed(() => {
  const label = t(`${moduleId}.landLink_filter_form.municipality`);

  return selectedSector.value?.description
    ? `${label}: ${selectedSector.value.description}`
    : null;
});
const titleType = computed(() => {
  const label = t(`${moduleId}.landLink_filter_form.titleType`);
  const value =
    titleTypesStore.titleTypes.find(
      (tp) => `${tp.id}` === landLinksStore.searchFilter.titleTypeId,
    ) ?? "";

  return value ? `${label}: ${value.i18nCode}` : null;
});
const anomalyLevel = computed(() => {
  const label = t(`${moduleId}.landLink_filter_form.anomalyLevel`);
  const value =
    AnomalyLevelSchema.options.find(
      (a) => a === landLinksStore.searchFilter.anomalyLevel,
    ) ?? "";
  const i18nCode = value ? t(`${moduleId}.anomalyLevelEnum.${value}`) : null;

  return i18nCode ? `${label}: ${i18nCode}` : null;
});

watch(
  () => landLinksStore.searchFilter.sectorCode,
  async (sec: string | null | undefined) => {
    if (sec) {
      const res = await getSector(sec);
      res && (selectedSector.value = res);
    } else {
      selectedSector.value = undefined;
    }
  },
  { immediate: true },
);

async function removeFilter(filterCode: LandLinkFilterField) {
  if (props.isBulk) {
    landLinksBulkStore.searchFilter[filterCode] = undefined;
    await landLinksBulkStore.searchLandLinks();
  } else {
    landLinksStore.searchFilter[filterCode] = undefined;
    await landLinksStore.searchLandLinks();
  }
}
</script>
<template>
  <BiChip
    :label="
      t(`${moduleId}.landLink_conductions_at_date`, {
        date: referenceDate,
      })
    "
  ></BiChip>
  <BiChip
    v-if="sectorCode"
    isDelete
    :label="sectorCode"
    @click="removeFilter('sectorCode')"
  ></BiChip>
  <BiChip
    v-if="parcel"
    isDelete
    :label="parcel"
    @click="removeFilter('parcelCode')"
  ></BiChip>
  <BiChip
    v-if="subParcel"
    isDelete
    :label="subParcel"
    @click="removeFilter('subParcelCode')"
  ></BiChip>
  <BiChip
    v-if="blockCode"
    isDelete
    :label="blockCode"
    @click="removeFilter('blockCode')"
  ></BiChip>
  <BiChip
    v-if="titleType"
    isDelete
    :label="titleType"
    @click="removeFilter('titleTypeId')"
  ></BiChip>
  <BiChip
    v-if="anomalyLevel"
    isDelete
    :label="anomalyLevel"
    @click="removeFilter('anomalyLevel')"
  ></BiChip>
</template>
