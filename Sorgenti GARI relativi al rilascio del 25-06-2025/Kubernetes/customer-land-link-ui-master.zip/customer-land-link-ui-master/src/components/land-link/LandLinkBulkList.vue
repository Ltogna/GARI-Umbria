<script setup lang="ts">
import useLandLinkBulkChecked from "@/composables/useLandLinkBulkChecked";
import useLandLinks from "@/composables/useLandLinks";
import useModuleId from "@/composables/useModuleId";
import useUserDateFormat from "@/composables/useUserDateFormat";
import { INFINITE_DATE } from "@/constants";
import randomUUID from "@/randomUUID";
import { useLandLinksBulkStore } from "@/stores/landLinksBulk";
import {
  convertAreaSQMInHA,
  intlNumberFormatOptions,
  percNumberFormatOption,
} from "@/utils/area";
import BiAlert from "@abaco/bootstrap-italia-components/src/components/BiAlert/BiAlert.vue";
import BiButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiButton.vue";
import BiHiddenContent from "@abaco/bootstrap-italia-components/src/components/BiHiddenContent/BiHiddenContent.vue";
import BiTable from "@abaco/bootstrap-italia-components/src/components/BiTable/BiTable.vue";
import { format } from "date-fns";
import { computed } from "vue";
import { useI18n } from "vue-i18n";
import AnomalyTooltipIcon from "../common/AnomalyTooltipIcon.vue";

const idCheckAll = `check-all-${randomUUID()}`;

const moduleId = useModuleId();
const { t, n } = useI18n();
const landLinkStore = useLandLinksBulkStore();
const { getSheetReference } = useLandLinks();
const { allChecked, isCheckboxIndeterminate } = useLandLinkBulkChecked();
const userDateFormat = useUserDateFormat();

const loadMore = async () => {
  await landLinkStore.searchLandLinks(true);
};

function handleCheckAllParcels() {
  if (allChecked.value) {
    landLinkStore.landLinks.forEach((l) => (l.checked = false));
  } else {
    landLinkStore.landLinks.forEach((l) => (l.checked = true));
  }
}

let isLoaded = false;
const isLoadedOnce = computed(() => {
  if (!landLinkStore.isLoading) {
    isLoaded = true;
  }

  return isLoaded;
});
</script>
<template>
  <div class="customer-land-link__pager-info fw-semibold small mb-1">
    {{ t(`${moduleId}.landLink_total`, 2) }}: {{ landLinkStore.count }}
  </div>
  <BiTable
    v-if="isLoadedOnce && landLinkStore.hasLandLinks"
    is-custom
    responsive-breakpoint="md"
    class="table-hover mb-0 table-responsive"
    extraTableClasses="table-head-bg"
    isRowHover
  >
    <template #head>
      <tr class="bg-light">
        <th scope="col">
          <div class="form-check customer-land-link__table-selectable">
            <input
              type="checkbox"
              :id="idCheckAll"
              :checked="allChecked"
              :class="{
                'semi-checked': isCheckboxIndeterminate,
              }"
              :indeterminate="isCheckboxIndeterminate"
              :disabled="!landLinkStore.landLinks.length"
              @click="handleCheckAllParcels"
            />
            <label :for="idCheckAll">
              <BiHiddenContent :text="t(`${moduleId}.check`)"></BiHiddenContent
            ></label>
          </div>
        </th>
        <th scope="col">
          {{ t(`${moduleId}.sheet_references`) }}
        </th>
        <th scope="col">
          {{ t(`${moduleId}.landLink_list.surface_gis_ha`) }}
        </th>
        <th scope="col">
          {{ t(`${moduleId}.conduction`, 1) }}
        </th>
        <th scope="col">
          {{ t(`${moduleId}.landLink_list.surface_cond_ha`) }}
        </th>
        <th scope="col">
          {{ t(`${moduleId}.landLink_list.conduction_period`) }}
        </th>
        <th scope="col" class="text-center">
          {{ t(`${moduleId}.landLink_list.anomalies`) }}
        </th>
      </tr>
    </template>
    <template #body>
      <tr v-for="landLink in landLinkStore.landLinks" :key="landLink.id">
        <td :data-label="t(`${moduleId}.check`)">
          <div class="form-check customer-land-link__table-selectable">
            <input
              :id="`checkbox-${landLink.id}`"
              type="checkbox"
              name="landLink"
              v-model="landLink.checked"
            />
            <label :for="`checkbox-${landLink.id}`"
              ><BiHiddenContent :text="t(`${moduleId}.check`)"></BiHiddenContent
            ></label>
          </div>
        </td>
        <td :data-label="t(`${moduleId}.sheet_references`)">
          {{ getSheetReference(landLink.parcel, true) }}
        </td>
        <td :data-label="t(`${moduleId}.landLink_list.surface_gis_ha`)">
          {{
            n(
              convertAreaSQMInHA(landLink.parcel.areaSqm ?? 0),
              intlNumberFormatOptions,
            )
          }}
        </td>
        <td :data-label="t(`${moduleId}.conduction`, 1)">
          {{ landLink.titleType.i18nCode }}
          {{ n(landLink.titleTypePerc, percNumberFormatOption) }}%
        </td>
        <td :data-label="t(`${moduleId}.landLink_list.surface_cond_ha`)">
          {{
            n(
              convertAreaSQMInHA(landLink.titleTypeAreaSqm ?? 0),
              intlNumberFormatOptions,
            )
          }}
        </td>
        <td :data-label="t(`${moduleId}.landLink_list.conduction_period`)">
          <div>
            {{ format(landLink.dayFrom, userDateFormat) }}
          </div>
          <div v-if="format(landLink.dayTo, 'yyyyMMdd') !== INFINITE_DATE">
            {{ format(landLink.dayTo, userDateFormat) }}
          </div>
        </td>
        <td
          class="text-center"
          :data-label="t(`${moduleId}.landLink_list.anomalies`)"
        >
          <AnomalyTooltipIcon
            v-if="landLink.anomalyCount && landLink.maxAnomalyLevel"
            :max-anomaly-level="landLink.maxAnomalyLevel"
            :count-anomalies="landLink.anomalyCount"
          />
        </td>
      </tr>
      <tr style="justify-content: center" v-if="landLinkStore.nextKey">
        <td colspan="9999" class="text-center">
          <BiButton
            color="primary"
            is-outlined
            class="py-1 px-2"
            @click="loadMore"
            :is-disabled="landLinkStore.isLoading"
          >
            {{ t(`${moduleId}.load_more`) }}
          </BiButton>
        </td>
      </tr>
    </template>
  </BiTable>

  <BiAlert
    v-if="!landLinkStore.isLoading && !landLinkStore.hasLandLinks"
    isInfo
    class="mt-3"
    :title="t(`${moduleId}.no_landLinks_found`)"
  />
</template>
