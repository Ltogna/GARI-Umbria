import { getFieldSelector, justValidateConfig } from "@/utils/formUtils";
import JustValidate from "just-validate";
import type { FieldRuleInterface } from "just-validate/dist/modules/interfaces";

const createLandLinkFilterFormValidatorConfig = (
  t: (s: string) => string,
  moduleId: string,
  formRef: Element,
): JustValidate =>
  new JustValidate(formRef, justValidateConfig).addField(
    getFieldSelector(formRef.id, "referenceDate"),
    [
      {
        rule: "required",
        errorMessage: t(`${moduleId}.errors.fieldRequired`),
      } as FieldRuleInterface,
    ],
  );

export default createLandLinkFilterFormValidatorConfig;
