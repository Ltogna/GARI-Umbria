import { getFieldSelector, justValidateConfig } from "@/utils/formUtils";
import JustValidate from "just-validate";
import type { FieldRuleInterface } from "just-validate/dist/modules/interfaces";

const createLandLinkFormValidatorConfig = (
  t: (s: string, param?: { [k: string]: string }) => string,
  moduleId: string,
  formRef: Element,
): JustValidate =>
  new JustValidate(formRef, justValidateConfig)
    .addField(getFieldSelector(formRef.id, "titleTypePerc"), [
      {
        rule: "required",
        errorMessage: t(`${moduleId}.errors.fieldRequired`),
      } as FieldRuleInterface,
      {
        rule: "customRegexp",
        value: /(^[0-9]+[,.]{0,1}[0-9]{0,2}$)/i,
        errorMessage: t(`${moduleId}.errors.percFormatValidation`),
      } as FieldRuleInterface,
      // {
      //   validator: (value: string) => {
      //     const numericValue = +value.replace(",", ".");
      //     return numericValue >= 0.01;
      //   },
      //   errorMessage: t(`${moduleId}.errors.minValueValidator`, {
      //     minValue: "0,01",
      //   }),
      // } as FieldRuleInterface,
      {
        validator: (value: string) => {
          const numericValue = +value.replace(",", ".");
          return numericValue <= 100;
        },
        errorMessage: t(`${moduleId}.errors.maxValueValidator`, {
          maxValue: "100",
        }),
      } as FieldRuleInterface,
    ])
    .addField(getFieldSelector(formRef.id, "titleTypeAreaSqm"), [
      {
        rule: "required",
        errorMessage: t(`${moduleId}.errors.fieldRequired`),
      } as FieldRuleInterface,
    ]);

export default createLandLinkFormValidatorConfig;
