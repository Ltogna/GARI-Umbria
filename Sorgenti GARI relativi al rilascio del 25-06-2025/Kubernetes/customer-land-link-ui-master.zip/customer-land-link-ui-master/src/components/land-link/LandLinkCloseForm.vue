<script setup lang="ts">
import { computed, ref, onMounted, watch, defineProps, defineEmits } from "vue";
import BiModal from "@abaco/bootstrap-italia-components/src/components/BiModal/BiModal.vue";
import { getSheetReference } from "@/utils/getSheetReference";
import { useI18n } from "vue-i18n";
import useModuleId from "@/composables/useModuleId";
import { useLandLinksStore } from "@/stores/landLinks";
import { getUUID } from "@abaco/bootstrap-italia-components/src/utilities";
import useForm from "@/composables/useForm";
import BiDatepicker from "@abaco/bootstrap-italia-components/src/components/form/BiDatepicker.vue";
import createLandLinkCloseFormValidatorConfig from "./landLinkCloseFormValidatorConfig";
import BiButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiButton.vue";
import JustValidate, { type FieldRuleInterface } from "just-validate";
import { getFieldSelector } from "@/utils/formUtils";
import { addDays, format, isAfter, isBefore } from "date-fns";
import useUserDateFormat from "@/composables/useUserDateFormat";
import { isEqual } from "lodash";

export interface LandLinkCloseRequest {
  dayTo: Date;
}

const props = defineProps<{
  modelValue: boolean;
}>();

const emit = defineEmits<{
  (e: "update:modelValue", value: boolean): void;
  (e: "close:landLink"): void;
}>();

const { t } = useI18n();
const moduleId = useModuleId();
const landLinkStore = useLandLinksStore();
const formId = getUUID();

const landLinkCloseForm = ref<Partial<LandLinkCloseRequest>>({});
const formRef = ref<HTMLFormElement>();
const showModal = ref(false);
const submitted = ref(false);

const { validate, onValidate, onSubmit } = useForm(
  submitCallback,
  landLinkCloseForm.value,
  formId,
);

const userDateFormat = useUserDateFormat();

const landLinkReference = computed(() =>
  landLinkStore.landLinkDetail?.parcel
    ? getSheetReference(landLinkStore.landLinkDetail?.parcel, true)
    : "",
);

const minDate = computed(() =>
  landLinkStore.landLinkDetail?.dayFrom
    ? addDays(landLinkStore.landLinkDetail.dayFrom, 1)
    : undefined,
);
const maxDate = computed(
  () => landLinkStore.landLinkDetail?.dayTo ?? undefined,
);

onMounted(() => {
  if (formRef.value)
    validate.value = createLandLinkCloseFormValidatorConfig(
      t,
      moduleId,
      formRef.value,
    );
});

watch(
  () => props.modelValue,
  (isOpen) => {
    showModal.value = isOpen;
    landLinkCloseForm.value.dayTo = undefined;
  },
  { immediate: true },
);

watch(
  () => [
    landLinkStore.landLinkDetail?.dayFrom,
    landLinkStore.landLinkDetail?.dayTo,
  ],
  ([df, dt]) => {
    const today = new Date();
    if (df) {
      (validate.value as JustValidate).addField(
        getFieldSelector(formId, "dayTo"),
        [
          {
            rule: "required",
            errorMessage: t(`${moduleId}.errors.fieldRequired`),
          } as FieldRuleInterface,
          {
            validator: (value) => {
              if (!value || typeof value !== "string" || !df) return true;
              return isAfter(new Date(value), df);
            },
            errorMessage: t(`${moduleId}.errors.INVALID_DATE_AFTER`, {
              date: df ? format(df, userDateFormat) : "",
            }),
          } as FieldRuleInterface,
          {
            validator: (value) => {
              if (!value || typeof value !== "string" || !dt) return true;
              return (
                isEqual(new Date(value), dt) || isBefore(new Date(value), dt)
              );
            },
            errorMessage: t(`${moduleId}.errors.INVALID_DATE_BEFORE`, {
              date: dt ? format(today, userDateFormat) : "",
            }),
          } as FieldRuleInterface,
        ],
      );
    }
  },
);

watch(
  () => landLinkCloseForm.value.dayTo,
  async (form) => {
    if (form && submitted.value) {
      await (validate.value as JustValidate).revalidate();
    }
  },
);

function onCloseModal() {
  (validate.value as JustValidate).refresh();
  showModal.value = false;
  emit("update:modelValue", false);
}

async function submitCallback() {
  submitted.value = true;
  const landLinkId = landLinkStore.landLinkDetail?.id;
  if (landLinkId && landLinkCloseForm.value.dayTo) {
    await landLinkStore.closeLandLinkConduction(
      landLinkId,
      new Date(landLinkCloseForm.value.dayTo),
    );

    if (!landLinkStore.hasError) emit("close:landLink");

    onCloseModal();
  }
}
</script>
<template>
  <BiModal
    :title="t(`${moduleId}.landLink_form.conduction_close`)"
    v-model="showModal"
  >
    <template #body>
      <div class="text-break">
        <i18n-t
          :keypath="`${moduleId}.landLink_form.conduction_close_message`"
          scope="global"
        >
          <template #landLinkDescr>
            <strong>{{ landLinkReference }}</strong>
          </template>
        </i18n-t>
      </div>

      <form
        :id="formId"
        class="customer-land-link__landLink-form needs-validation mt-4"
        ref="formRef"
        @submit.prevent="onSubmit"
      >
        <div class="row">
          <div class="col-md-6">
            <BiDatepicker
              class="field-required"
              v-model="landLinkCloseForm.dayTo"
              :id="getUUID()"
              :name="'dayTo'"
              :label="t(`${moduleId}.landLink_form.conduction_close_date`)"
              :min="minDate"
              :max="maxDate"
              :on-validate="onValidate"
            />
          </div>
        </div>

        <div class="d-flex justify-content-center mt-5">
          <div>
            <BiButton
              class="me-3"
              color="primary"
              is-outlined
              @click="onCloseModal"
            >
              {{ t(`${moduleId}.close`) }}
            </BiButton>
          </div>

          <div>
            <BiButton color="success" type="submit">
              {{ t(`${moduleId}.landLink_form.confirm`) }}
            </BiButton>
          </div>
        </div>
      </form>
    </template>
  </BiModal>
</template>
