<script setup lang="ts">
import createLandLinkFormValidatorConfig from "@/components/land-link/landLinkFormValidatorConfig";
import useForm from "@/composables/useForm";
import useModuleId from "@/composables/useModuleId";
import useParty from "@/composables/useParty";
import usePermissions from "@/composables/usePermissions";
import useUserDateFormat from "@/composables/useUserDateFormat";
import { INFINITE_DATE } from "@/constants";
import { RouteName } from "@/models/routes";
import { deleteSingleParcel } from "@/resources/api/landLink";
import { useLandLinksStore } from "@/stores/landLinks";
import { useNotificationStore } from "@/stores/notification";
import { useSettingStore } from "@/stores/settings";
import {
  convertAreaSQMInHA,
  intlNumberFormatOptions,
  percNumberFormatOption,
} from "@/utils/area";
import BiButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiButton.vue";
import BiIcon from "@abaco/bootstrap-italia-components/src/components/BiIcon/BiIcon.vue";
import { getUUID } from "@abaco/bootstrap-italia-components/src/utilities";
import { format, isAfter } from "date-fns";
import { computed, onMounted, ref, watch } from "vue";
import { useI18n } from "vue-i18n";
import { useRoute, useRouter } from "vue-router";
import BiTextInput from "../BiTextInput.vue";
import LandLinkCloseForm from "./LandLinkCloseForm.vue";
import LandLinkModalDelete from "./LandLinkModalDelete.vue";
import { useGroupsStore } from "@/stores/groups";

interface LandLinkUpdateRequest {
  titleTypePerc: string;
  titleTypeAreaSqm: string;
  gisAreaSqm: string;
}

const { t, n } = useI18n();
const moduleId = useModuleId();
const landLinkStore = useLandLinksStore();
const settingStore = useSettingStore();
const { setRawMessge } = useNotificationStore();
const { canWrite } = usePermissions();

const formId = getUUID();
const router = useRouter();
const route = useRoute();
const { partyId } = useParty();
const userDateFormat = useUserDateFormat();
const grouspStore = useGroupsStore();

const landLinkForm = ref<Partial<LandLinkUpdateRequest>>({});
const landLinkFormRef = ref();
const showModal = ref(false);
const isAreaChanged = ref(false);
const today = new Date();
const isFromGroup = ref<boolean>(false);
const isModalDelete = ref(false);
let isDeleted = false;

const { validate, onValidate, onSubmit } = useForm(
  submitCallback,
  landLinkForm.value,
  formId,
);

const showConductionEnd = computed(
  () =>
    !!landLinkStore.landLinkDetail?.dayTo &&
    format(landLinkStore.landLinkDetail.dayTo, "yyyyMMdd") !== INFINITE_DATE,
);

const showCloseButton = computed(() => {
  return (
    canWrite &&
    (!landLinkStore.landLinkDetail?.dayTo ||
      (!!landLinkStore.landLinkDetail?.dayTo &&
        isAfter(landLinkStore.landLinkDetail.dayTo, today)) ||
      !!settingStore.canUpdateClosedElements)
  );
});

onMounted(() => {
  isDeleted = false;
  isFromGroup.value = route.name === RouteName.GROUP_EDIT_LANDLINK;
  validate.value = createLandLinkFormValidatorConfig(
    t,
    moduleId,
    landLinkFormRef.value,
  );
});

watch(
  () => landLinkStore.landLinkDetail,
  (landLink) => {
    landLinkForm.value = {
      titleTypeAreaSqm: landLink?.titleTypeAreaSqm
        ? n(
            convertAreaSQMInHA(landLink?.titleTypeAreaSqm ?? 0),
            intlNumberFormatOptions,
          )
        : "0",
      gisAreaSqm: landLink?.parcel.areaSqm
        ? n(
            convertAreaSQMInHA(landLink?.parcel.areaSqm ?? 0),
            intlNumberFormatOptions,
          )
        : "0",
      titleTypePerc: landLink?.titleTypePerc
        ? n(landLink?.titleTypePerc ?? 0, percNumberFormatOption)
        : "0",
    };
  },
);

async function submitCallback() {
  const parsedPerc = landLinkForm.value.titleTypePerc?.replace(",", ".");
  parsedPerc &&
    landLinkStore.landLinkDetail?.id &&
    (await landLinkStore.updateLandLink(
      landLinkStore.landLinkDetail?.id,
      +parsedPerc,
    ));
  // #138997 call goBack
  goBack();
}

/**
 * #138997 added go back function
 */
function goBack() {
  if (route.params.groupId) {
    router.replace({
      name: RouteName.GROUP_EDIT,
      params: { partyId: partyId.value, groupId: route.params.groupId },
    });
  } else {
    router.replace({
      name: RouteName.LAND_LINK_LIST,
      params: { partyId: partyId.value },
    });
  }
}

function backToList() {
  router.replace({
    name: RouteName.LAND_LINK_LIST,
    params: { partyId: partyId.value },
  });
}

function conductionClose() {
  showModal.value = !showModal.value;
}

function showModalDelete() {
  isModalDelete.value = true;
}

function goToGroup() {
  const groupId = landLinkStore.landLinkDetail?.group.id;
  groupId &&
    router.replace({
      name: RouteName.GROUP_EDIT,
      params: { partyId: partyId.value, groupId },
    });
}

function onPercChange() {
  const perc = landLinkForm.value.titleTypePerc ?? "0";
  const parsedPerc = +perc.replace(",", ".");
  const parsedArea = +(landLinkForm.value.gisAreaSqm ?? "0")?.replace(",", "");
  const updatedArea = (parsedPerc / 100) * parsedArea;
  isAreaChanged.value = false;

  if (updatedArea) {
    landLinkForm.value.titleTypeAreaSqm = updatedArea
      ? n(
          convertAreaSQMInHA(Number.parseFloat(updatedArea.toFixed(4)) ?? 0),
          intlNumberFormatOptions,
        )
      : "0";
  }
}

function onAreaInput() {
  isAreaChanged.value = true;
}

function onAreaChange() {
  const area = landLinkForm.value.titleTypeAreaSqm ?? "0";
  const parsedArea = +area.replace(",", ".");
  const parsedGisArea = +(landLinkForm.value.gisAreaSqm ?? "0")?.replace(
    ",",
    ".",
  );

  const updatedPerc =
    parsedArea && parsedGisArea ? (100 * parsedArea) / parsedGisArea : 0;

  if (updatedPerc && isAreaChanged.value) {
    landLinkForm.value.titleTypePerc = n(updatedPerc, percNumberFormatOption);
  }
}

function onCloseLandLink() {
  router.replace({
    name: RouteName.LAND_LINK_LIST,
    params: { partyId: partyId.value },
  });
}
const deleteOnParcel = async () => {
  const groupId = landLinkStore.landLinkDetail?.group.id;
  const parcelId = landLinkStore.landLinkDetail?.parcel.id;
  if (partyId.value && parcelId && groupId) {
    isDeleted = await deleteSingleParcel(
      Number(partyId.value),
      groupId,
      parcelId,
    );
    if (isDeleted) {
      setRawMessge({
        isError: false,
        message: t(`${moduleId}.success.GENERIC_SAVE`),
      });
      // #138997 reload groups
      await grouspStore.searchGroups(+partyId.value, false);
      isModalDelete.value = false;
    }
  }
};

function shouldLeavePage() {
  if (isDeleted) {
    // #138997 call goBack
    goBack();
    isDeleted = false;
  }
}
</script>
<template>
  <form
    :id="formId"
    class="customer-land-link__landLink-form needs-validation mt-4"
    ref="landLinkFormRef"
    @submit.prevent="onSubmit"
  >
    <div class="row" v-if="landLinkStore.reference_date">
      <div class="col-md-3">
        <p>
          {{ t(`${moduleId}.landLink_form.referenceDate`) }} <br />
          <strong>
            {{
              isFromGroup
                ? format(today, userDateFormat)
                : format(landLinkStore.reference_date, userDateFormat)
            }}
          </strong>
        </p>
      </div>
    </div>
    <div class="row">
      <div class="col-md-3">
        <p>
          {{ t(`${moduleId}.landLink_form.conduction_title`) }} <br />
          <strong v-if="landLinkStore.landLinkDetail?.titleType.i18nCode">
            {{ landLinkStore.landLinkDetail?.titleType.i18nCode }}
          </strong>
        </p>
      </div>
      <div class="col-md-3">
        <p>
          {{ t(`${moduleId}.landLink_form.conduction_start`) }} <br />
          <strong v-if="landLinkStore.landLinkDetail?.dayFrom">
            {{ format(landLinkStore.landLinkDetail?.dayFrom, userDateFormat) }}
          </strong>
        </p>
      </div>
      <div class="col-md-3">
        <p>
          {{ t(`${moduleId}.landLink_form.conduction_end`) }} <br />
          <strong
            v-if="showConductionEnd && !!landLinkStore.landLinkDetail?.dayTo"
          >
            {{ format(landLinkStore.landLinkDetail?.dayTo, userDateFormat) }}
          </strong>
        </p>
      </div>
    </div>
    <div class="row mt-4">
      <div class="col-md-3">
        <BiTextInput
          :id="getUUID()"
          is-readonly
          v-model="landLinkForm.gisAreaSqm"
          :label="t(`${moduleId}.landLink_form.gis_area`)"
          name="gisAreaSqm"
          :placeholder="t(`${moduleId}.landLink_form.gis_area`)"
        />
      </div>
      <div class="col-md-3">
        <div class="field-required">
          <BiTextInput
            :id="getUUID()"
            :is-disabled="!canWrite"
            :on-validate="onValidate"
            v-model="landLinkForm.titleTypePerc"
            :label="t(`${moduleId}.landLink_form.landLink_perc`)"
            name="titleTypePerc"
            :placeholder="t(`${moduleId}.landLink_form.landLink_perc`)"
            @input:blur="onPercChange"
          />
        </div>
      </div>
      <div class="col-md-3">
        <div class="field-required">
          <BiTextInput
            :id="getUUID()"
            :is-disabled="!canWrite"
            :on-validate="onValidate"
            v-model="landLinkForm.titleTypeAreaSqm"
            :label="t(`${moduleId}.landLink_form.landLink_area`)"
            name="titleTypeAreaSqm"
            :placeholder="t(`${moduleId}.landLink_form.landLink_area`)"
            @input:blur="onAreaChange"
            @input:input="onAreaInput"
            :is-readonly="landLinkStore.landLinkDetail?.parcel.areaSqm === 0"
          />
        </div>
      </div>
    </div>
    <div class="row mt-5">
      <div class="col-12 d-flex justify-content-center align-items-center">
        <BiButton
          v-if="canWrite"
          type="submit"
          color="success"
          is-icon
          class="btn-me"
        >
          {{ t(`${moduleId}.save`) }}
        </BiButton>
        <BiButton
          v-if="showCloseButton"
          class="btn-me"
          color="success"
          is-icon
          @click="conductionClose()"
        >
          {{ t(`${moduleId}.landLink_form.conduction_close`) }}
        </BiButton>
        <BiButton color="danger" is-icon @click="showModalDelete()">
          {{ t(`${moduleId}.landLink_form.delete`) }}
        </BiButton>
      </div>
    </div>
    <div class="row mt-3">
      <div class="col-12 d-flex justify-content-center align-items-center">
        <BiButton
          v-if="!isFromGroup"
          color="primary"
          is-icon
          is-outlined
          class="btn-me"
          @click="backToList()"
        >
          <BiIcon icon="arrow-left" class="me-2" />
          {{ t(`${moduleId}.back_to_list`) }}
        </BiButton>
        <BiButton
          color="primary"
          is-icon
          is-outlined
          class="btn-me"
          @click="goToGroup()"
        >
          <BiIcon icon="arrow-left" class="me-2" />
          {{ t(`${moduleId}.landLink_form.go_to_group`) }}
        </BiButton>
      </div>
    </div>
  </form>
  <LandLinkCloseForm v-model="showModal" @close:land-link="onCloseLandLink" />
  <LandLinkModalDelete
    v-model="isModalDelete"
    parcel-message
    :onDelete="deleteOnParcel"
    @hidden-modal="shouldLeavePage"
  />
</template>
