<script setup lang="ts">
import { ref, onMounted, computed, watch } from "vue";
import useModuleId from "@/composables/useModuleId";
import { getUUID } from "@abaco/bootstrap-italia-components/src/utilities";
import { useI18n } from "vue-i18n";

import BiTextInput from "@/components/BiTextInput.vue";
import BiDatepicker from "@abaco/bootstrap-italia-components/src/components/form/BiDatepicker.vue";
import useForm from "@/composables/useForm";
import BiSelect from "@abaco/bootstrap-italia-components/src/components/form/BiSelect.vue";
import BiButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiButton.vue";
import BiIcon from "@abaco/bootstrap-italia-components/src/components/BiIcon/BiIcon.vue";
import createLandLinkFilterFormValidatorConfig from "@/components/land-link/landLinkFilterFormValidatorConfig";
import { useLandLinksBulkStore } from "@/stores/landLinksBulk";
import { useRouter } from "vue-router";
import useParty from "@/composables/useParty";
import { useTitleTypesStore } from "@/stores/titleTypes";
import type { SelectItem } from "@abaco/bootstrap-italia-components/src/models";
import { AnomalyLevelSchema } from "@/models/anomalyLevel";
import type { SectorModel } from "@/models/sector";
import { useSector } from "@/composables/useSector";
import { RouteName } from "@/models/routes";

const { t } = useI18n();
const moduleId = useModuleId();
const formId = getUUID();
const landLinkStore = useLandLinksBulkStore();
const router = useRouter();
const { partyId } = useParty();
const titleTypesStore = useTitleTypesStore();

interface LandLinkSearchFilter {
  groupId: number;
  titleTypeId: string;
  partyId: number;
  targetPartyId: number;
  sectorCode: string;
  blockCode: string;
  parcelCode: string;
  subParcel: string;
  anomalyLevel: string;
  nextKey: string;
}

const filterForm = ref<Partial<LandLinkSearchFilter>>({});
const filterFormRef = ref();
const referenceDate = ref<Date | string | number | undefined>(
  landLinkStore.reference_date,
);
const searchSectorItems = ref<SectorModel[]>([]);
const searchSectorText = ref("");

const { getSector, searchSector } = useSector();
const { validate, onValidate, onSubmit } = useForm(
  submitCallback,
  filterForm.value,
  formId,
);
const titleTypes = computed<SelectItem[]>(() => {
  return titleTypesStore.titleTypes.map(({ id, i18nCode }) => ({
    id: id.toString(),
    text: i18nCode,
  }));
});
const anomalyLevels = computed<SelectItem[]>(() => {
  return AnomalyLevelSchema.options.map((item) => ({
    id: item,
    text: t(`${moduleId}.anomalyLevelEnum.${item}`),
  }));
});

watch(searchSectorText, async (text) => {
  searchSectorItems.value = await searchSector(text);
});

onMounted(async () => {
  validate.value = createLandLinkFilterFormValidatorConfig(
    t,
    moduleId,
    filterFormRef.value,
  );
  filterForm.value = {
    sectorCode: landLinkStore.searchFilter.sectorCode ?? undefined,
    blockCode: landLinkStore.searchFilter.blockCode ?? undefined,
    parcelCode: landLinkStore.searchFilter.parcelCode ?? undefined,
    subParcel: landLinkStore.searchFilter.subParcelCode ?? undefined,
    titleTypeId: landLinkStore.searchFilter.titleTypeId ?? undefined,
    anomalyLevel: landLinkStore.searchFilter.anomalyLevel ?? undefined,
  };

  if (filterForm.value.sectorCode) {
    const res = await getSector(filterForm.value.sectorCode);
    res && (searchSectorText.value = res.description ?? "");
  } else {
    searchSectorItems.value = await searchSector("");
  }
});

function submitCallback() {
  landLinkStore.searchFilter = { ...filterForm.value };
  referenceDate.value &&
    (landLinkStore.reference_date = new Date(referenceDate.value));
  router.replace({
    name: RouteName.PARCEL_BULK,
  });
}

function onReset() {
  referenceDate.value = undefined;
  searchSectorText.value = "";
  filterForm.value = {};
}

function backToList() {
  router.replace({
    name: RouteName.PARCEL_BULK,
    params: { partyId: partyId.value },
  });
}
</script>
<template>
  <form
    :id="formId"
    class="customer-land-link__landLink-search-form needs-validation pt-5"
    ref="filterFormRef"
    @submit.prevent="onSubmit"
  >
    <div class="row">
      <div class="col-md-5 mb-4">
        <BiTextInput
          :id="getUUID()"
          :label="t(`${moduleId}.landLink_filter_form.municipality`)"
          :placeholder="t(`${moduleId}.landLink_filter_form.municipality`)"
          name="municipality"
          item-title="description"
          item-value="sectorCode"
          :items="searchSectorItems"
          v-model="filterForm.sectorCode"
          v-model:text="searchSectorText"
          :seamless="true"
          :strict="true"
          list-height="400px"
        />
      </div>
      <div class="col-md-2 mb-5">
        <BiTextInput
          :id="getUUID()"
          v-model="filterForm.blockCode"
          :label="t(`${moduleId}.landLink_filter_form.sheet`)"
          name="sheet"
          :placeholder="t(`${moduleId}.landLink_filter_form.sheet`)"
        />
      </div>
      <div class="col-md-2 mb-5">
        <BiTextInput
          :id="getUUID()"
          v-model="filterForm.parcelCode"
          :label="t(`${moduleId}.landLink_filter_form.parcel`)"
          name="parcel"
          :placeholder="
            t(`${moduleId}.landLink_filter_form.parcel_placeholder`)
          "
        />
      </div>
      <div class="col-md-3 mb-5">
        <BiTextInput
          :id="getUUID()"
          v-model="filterForm.subParcel"
          :label="t(`${moduleId}.landLink_filter_form.subParcel`)"
          name="subParcel"
          :placeholder="t(`${moduleId}.landLink_filter_form.subParcel`)"
        />
      </div>
    </div>
    <div class="row">
      <div class="col-md-3 mb-5">
        <BiSelect
          :id="getUUID()"
          :label="t(`${moduleId}.landLink_filter_form.titleType`)"
          :items="titleTypes"
          :emptyOption="t(`${moduleId}.void_option`)"
          name="titleType"
          v-model="filterForm.titleTypeId"
        ></BiSelect>
      </div>
      <div class="col-md-3 mb-5">
        <BiDatepicker
          class="field-required"
          :id="getUUID()"
          :name="'referenceDate'"
          :label="t(`${moduleId}.landLink_filter_form.referenceDate`)"
          :on-validate="onValidate"
          v-model="referenceDate"
        />
      </div>
      <div class="col-md-3 mb-5">
        <BiSelect
          :id="getUUID()"
          :label="t(`${moduleId}.landLink_filter_form.anomalyLevel`)"
          :items="anomalyLevels"
          :emptyOption="t(`${moduleId}.void_option`)"
          name="anomalyLevel"
          v-model="filterForm.anomalyLevel"
        ></BiSelect>
      </div>
      <div
        class="form-group col-12 d-flex justify-content-center align-items-center"
      >
        <BiButton
          color="primary"
          is-icon
          is-outlined
          class="btn-me"
          @click="backToList()"
        >
          <BiIcon icon="arrow-left" class="me-2" />
          {{ t(`${moduleId}.back_to_list`) }}
        </BiButton>
        <BiButton
          color="primary"
          is-icon
          is-outlined
          class="btn-me"
          @click="onReset()"
        >
          {{ t(`${moduleId}.cancel`) }}
        </BiButton>
        <BiButton type="submit" color="primary" is-icon>
          {{ t(`${moduleId}.search`) }}
        </BiButton>
      </div>
    </div>
  </form>
</template>
