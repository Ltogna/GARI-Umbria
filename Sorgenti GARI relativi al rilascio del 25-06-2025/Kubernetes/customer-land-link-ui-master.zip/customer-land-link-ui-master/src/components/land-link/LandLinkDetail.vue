<script setup lang="ts">
import useModuleId from "@/composables/useModuleId";
import useParty from "@/composables/useParty";
import useUserDateFormat from "@/composables/useUserDateFormat";
import { INFINITE_DATE } from "@/constants";
import { RouteName } from "@/models/routes";
import { useLandLinksStore } from "@/stores/landLinks";
import {
  convertAreaSQMInHA,
  intlNumberFormatOptions,
  percNumberFormatOption,
} from "@/utils/area";
import BiButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiButton.vue";
import BiIcon from "@abaco/bootstrap-italia-components/src/components/BiIcon/BiIcon.vue";
import { format } from "date-fns";
import { computed } from "vue";
import { useI18n } from "vue-i18n";
import { useRouter } from "vue-router";

const { t, n } = useI18n();
const moduleId = useModuleId();
const landLinkStore = useLandLinksStore();

const router = useRouter();
const { partyId } = useParty();
const userDateFormat = useUserDateFormat();

const showConductionEnd = computed(
  () =>
    !!landLinkStore.landLinkDetail?.dayTo &&
    format(landLinkStore.landLinkDetail.dayTo, "yyyyMMdd") !== INFINITE_DATE,
);

function backToList() {
  router.replace({
    name: RouteName.LAND_LINK_LIST,
    params: { partyId: partyId.value },
  });
}

function goToGroup() {
  const groupId = landLinkStore.landLinkDetail?.group.id;
  groupId &&
    router.replace({
      name: RouteName.GROUP_EDIT,
      params: { partyId: partyId.value, groupId },
    });
}
</script>
<template>
  <div class="row" v-if="landLinkStore.reference_date">
    <div class="col-md-3">
      <p>
        {{ t(`${moduleId}.landLink_form.referenceDate`) }} <br />
        <strong>
          {{ format(landLinkStore.reference_date, userDateFormat) }}
        </strong>
      </p>
    </div>
  </div>
  <div class="row">
    <div class="col-md-3">
      <p>
        {{ t(`${moduleId}.landLink_form.conduction_title`) }} <br />
        <strong v-if="landLinkStore.landLinkDetail?.titleType.i18nCode">
          {{ landLinkStore.landLinkDetail?.titleType.i18nCode }}
        </strong>
      </p>
    </div>
    <div class="col-md-3">
      <p>
        {{ t(`${moduleId}.landLink_form.conduction_start`) }} <br />
        <strong v-if="landLinkStore.landLinkDetail?.dayFrom">
          {{ format(landLinkStore.landLinkDetail?.dayFrom, userDateFormat) }}
        </strong>
      </p>
    </div>
    <div class="col-md-3">
      <p>
        {{ t(`${moduleId}.landLink_form.conduction_end`) }} <br />
        <strong
          v-if="showConductionEnd && !!landLinkStore.landLinkDetail?.dayTo"
        >
          {{ format(landLinkStore.landLinkDetail?.dayTo, userDateFormat) }}
        </strong>
      </p>
    </div>
  </div>
  <div class="row mt-4">
    <div class="col-md-3">
      <p>
        {{ t(`${moduleId}.landLink_form.gis_area`) }} <br />
        <strong>
          {{
            n(
              convertAreaSQMInHA(
                landLinkStore.landLinkDetail?.parcel.areaSqm ?? 0,
              ),
              intlNumberFormatOptions,
            )
          }}
        </strong>
      </p>
    </div>
    <div class="col-md-3">
      <p>
        {{ t(`${moduleId}.landLink_form.landLink_perc`) }} <br />
        <strong>
          {{
            n(
              landLinkStore.landLinkDetail?.titleTypePerc ?? 0,
              percNumberFormatOption,
            )
          }}
        </strong>
      </p>
    </div>
    <div class="col-md-3">
      <p>
        {{ t(`${moduleId}.landLink_form.landLink_area`) }} <br />
        <strong>
          {{
            n(
              convertAreaSQMInHA(
                landLinkStore.landLinkDetail?.titleTypeAreaSqm ?? 0,
              ),
              intlNumberFormatOptions,
            )
          }}
        </strong>
      </p>
    </div>
  </div>
  <div class="row mt-3">
    <div class="col-12 d-flex justify-content-center align-items-center">
      <BiButton
        color="primary"
        is-icon
        is-outlined
        class="btn-me"
        @click="backToList()"
      >
        <BiIcon icon="arrow-left" class="me-2" />
        {{ t(`${moduleId}.back_to_list`) }}
      </BiButton>
      <BiButton
        color="primary"
        is-icon
        is-outlined
        class="btn-me"
        @click="goToGroup()"
      >
        <BiIcon icon="arrow-left" class="me-2" />
        {{ t(`${moduleId}.landLink_form.go_to_group`) }}
      </BiButton>
    </div>
  </div>
</template>
