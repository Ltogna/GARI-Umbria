import { getFieldSelector, justValidateConfig } from "@/utils/formUtils";
import JustValidate from "just-validate";
import type { FieldRuleInterface } from "just-validate/dist/modules/interfaces";

const createLandLinkCloseFormValidatorConfig = (
  t: (s: string, params?: { [k: string]: string }) => string,
  moduleId: string,
  formRef: Element,
): JustValidate =>
  new JustValidate(formRef, justValidateConfig).addField(
    getFieldSelector(formRef.id, "dayTo"),
    [
      {
        rule: "required",
        errorMessage: t(`${moduleId}.errors.fieldRequired`),
      } as FieldRuleInterface,
    ],
  );

export default createLandLinkCloseFormValidatorConfig;
