<script setup lang="ts">
import useModuleId from "@/composables/useModuleId";
import { useAnomaliesStore } from "@/stores/anomalies";
// import BiAlert from "@abaco/bootstrap-italia-components/src/components/BiAlert/BiAlert.vue";
import BiButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiButton.vue";
import BiModal from "@abaco/bootstrap-italia-components/src/components/BiModal/BiModal.vue";
// import { AlertType } from "@abaco/bootstrap-italia-components/src/models";
import { useVModel } from "@vueuse/core";
import { useI18n } from "vue-i18n";
import AnomalyAlert from "./AnomalyAlert.vue";
import { defineProps, defineEmits } from "vue";

/**
 * TODO: better implmentation
 */

const props = defineProps<{
  modelValue: boolean;
}>();

const emits = defineEmits<{
  (e: "update:modelValue"): void;
}>();

const moduleId = useModuleId();
const { t } = useI18n();

const showAnomaliesModal = useVModel(props, "modelValue", emits);

const anomaliesStore = useAnomaliesStore();
</script>

<template>
  <BiModal
    v-model="showAnomaliesModal"
    :title="t(`${moduleId}.anomaly`, 2)"
    size="xl"
  >
    <template #body>
      <AnomalyAlert
        v-if="anomaliesStore.anomalies?.DANGER"
        type="DANGER"
        :anomalies="anomaliesStore.anomalies.DANGER"
      />
      <AnomalyAlert
        v-if="anomaliesStore.anomalies?.WARN"
        type="WARN"
        :anomalies="anomaliesStore.anomalies.WARN"
      />
      <AnomalyAlert
        v-if="anomaliesStore.anomalies?.INFO"
        type="INFO"
        :anomalies="anomaliesStore.anomalies.INFO"
      />
    </template>
    <template #footer>
      <BiButton color="primary" is-outlined @click="showAnomaliesModal = false">
        {{ t(`${moduleId}.close`) }}
      </BiButton>
    </template>
  </BiModal>
</template>
