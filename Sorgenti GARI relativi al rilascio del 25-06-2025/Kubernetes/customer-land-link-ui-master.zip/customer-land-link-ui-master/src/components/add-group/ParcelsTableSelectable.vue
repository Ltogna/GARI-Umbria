<script setup lang="ts">
import useEmitter from "@/composables/useEmitter";
import useModuleId from "@/composables/useModuleId";
import { useAddGroupStore } from "@/stores/addGroup";
import { intlNumberFormatOptions } from "@/utils/area";
import { formattedLeadingsList } from "@/utils/formattedLeadingsList";
import BiAlert from "@abaco/bootstrap-italia-components/src/components/BiAlert/BiAlert.vue";
import BiButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiButton.vue";
import BiHiddenContent from "@abaco/bootstrap-italia-components/src/components/BiHiddenContent/BiHiddenContent.vue";
import BiTable from "@abaco/bootstrap-italia-components/src/components/BiTable/BiTable.vue";
import { getUUID } from "@abaco/bootstrap-italia-components/src/utilities";
import { computed } from "vue";
import { useI18n } from "vue-i18n";

const { t, n } = useI18n();
const moduleId = useModuleId();
const addGroupStore = useAddGroupStore();
const emitter = useEmitter();

const idCheckAll = `check-all-${getUUID()}`;

const onLoadMore = async () => {
  await addGroupStore.loadFilteredParcels(true);
};

const onAddSelected = () => {
  addGroupStore.setSelectedParcels();
  emitter.emit("add:selected:parcels");
};

const isCheckboxIndeterminate = computed(
  () => addGroupStore.hasSomeParcelsChecked && !addGroupStore.allParcelsChecked,
);
</script>

<template>
  <div class="row">
    <BiTable
      is-custom
      responsive-breakpoint="md"
      is-header-light
      v-if="addGroupStore.mappedParcelsList.length > 0"
    >
      <template #head>
        <tr>
          <td>
            <div class="form-check customer-land-link__table-selectable">
              <input
                type="checkbox"
                :id="idCheckAll"
                :checked="addGroupStore.allParcelsChecked"
                :class="{
                  'semi-checked': isCheckboxIndeterminate,
                }"
                :indeterminate="isCheckboxIndeterminate"
                @change="addGroupStore.checkAllParcels"
              />
              <label :for="idCheckAll">
                <BiHiddenContent>
                  {{ t(`${moduleId}.check_all`) }}
                </BiHiddenContent>
              </label>
            </div>
          </td>
          <th scope="col">
            {{ t(`${moduleId}.add_group.sheet_references`) }}
          </th>
          <th scope="col">
            {{ t(`${moduleId}.add_group.current_gis_area`) }}
          </th>
          <th scope="col">
            {{ t(`${moduleId}.add_group.period_conductors`) }}
          </th>
        </tr>
      </template>
      <template #body>
        <tr v-for="parcel in addGroupStore.mappedParcelsList" :key="parcel.id">
          <td>
            <div class="form-check customer-land-link__table-selectable">
              <input
                :id="`checkbox-${parcel.id}`"
                type="checkbox"
                v-model="parcel.checked"
              />
              <label :for="`checkbox-${parcel.id}`">
                <BiHiddenContent
                  :text="t(`${moduleId}.check`)"
                ></BiHiddenContent>
              </label>
            </div>
          </td>
          <td
            :data-label="t(`${moduleId}.add_group.sheet_references`)"
            class="text-break max-w-xs"
          >
            {{ parcel.sheetReferences }}
          </td>
          <td :data-label="t(`${moduleId}.add_group.current_gis_area`)">
            {{ n(parcel.surface_in_ha, intlNumberFormatOptions) }}
          </td>
          <td :data-label="t(`${moduleId}.add_group.period_conductors`)">
            {{ formattedLeadingsList(parcel.leadings) }}
          </td>
        </tr>
      </template>
    </BiTable>

    <BiAlert
      v-else-if="addGroupStore.mappedParcelsList.length === 0"
      :title="t(`${moduleId}.alerts.parcel_not_found`)"
    >
    </BiAlert>
  </div>
  <div class="row pt-4">
    <div class="col-md-12 text-center">
      <BiButton
        v-if="addGroupStore.nextKey"
        color="secondary"
        is-outlined
        class="me-2"
        @click="onLoadMore"
      >
        {{ t(`${moduleId}.add_group.load_more`) }}
      </BiButton>
      <BiButton color="success" @click="onAddSelected">
        {{ t(`${moduleId}.add_group.add_selected`) }}
      </BiButton>
    </div>
  </div>
</template>
