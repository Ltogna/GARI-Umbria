<script setup lang="ts">
import useEmitter from "@/composables/useEmitter";
import useModuleId from "@/composables/useModuleId";
import useParty from "@/composables/useParty";
import { useAddGroupStore } from "@/stores/addGroup";
import { useGroupsStore } from "@/stores/groups";
import scrollToElement from "@/utils/scrollToElement";
import BiAccordion from "@abaco/bootstrap-italia-components/src/components/BiAccordion/BiAccordion.vue";
import BiAlert from "@abaco/bootstrap-italia-components/src/components/BiAlert/BiAlert.vue";
import BiInput from "@abaco/bootstrap-italia-components/src/components/form/BiInput.vue";
import { getUUID } from "@abaco/bootstrap-italia-components/src/utilities";
import { onBeforeUnmount, onMounted, provide, reactive, ref } from "vue";
import { useI18n } from "vue-i18n";
import { useRouter } from "vue-router";
import ParcelTableSelected from "../common/ParcelTableSelected.vue";
import ParcelSelectedAccordionButtons from "../common/ParcelSelectedAccordionButtons.vue";
import { hideRemoveButtonKey } from "@/models/injectionSymbols";
import { RouteName } from "@/models/routes";

provide(hideRemoveButtonKey, false);

const { t } = useI18n();
const moduleId = useModuleId();
const emitter = useEmitter();
const addGroupStore = useAddGroupStore();
const router = useRouter();
const { partyId } = useParty();

const conductionPercentage = ref(100);

const isOpen = ref(false);
const isDisabled = ref(true);
const accordionId = `accordion-${getUUID()}`;

const onOpenAccordion = (showAccordion: boolean) => {
  isOpen.value = showAccordion;
  if (showAccordion) {
    scrollToElement(accordionId);
  }
};

onMounted(() => {
  emitter.on("unset:conduction", () => {
    addGroupStore.resetAllExceptParty();
    conductionPercentage.value = 100;
  });

  emitter.on("add:selected:parcels", () => {
    isDisabled.value = false;
    isOpen.value = true;
    if (addGroupStore.hasConductedParcelsSelected) {
      addGroupStore.mappedParcelsList = [];
      addGroupStore.conductedParcelsList = [];
      addGroupStore.resetParcelFilter();
      Object.assign(errorCreateGroup, { isError: false, message: "" });
      /**
       * ? mantain previous selected value ?
       * */
      conductionPercentage.value = 100;
      onConfirmPercentage();
    }
    scrollToElement(accordionId);
  });

  emitter.on("close:selected:parcels", () => {
    isDisabled.value = true;
    isOpen.value = false;
  });

  emitter.on("delete:parcel", (parcelId) => {
    addGroupStore.deleteSelectedParcel(parcelId);
  });
});

onBeforeUnmount(() => {
  emitter.off("add:selected:parcels");
  emitter.off("close:selected:parcels");
  emitter.off("delete:parcel");
});

const hasClickedFirstButton = ref(false);

const errorCreateGroup = reactive<{
  isError: boolean;
  message: string;
}>({ isError: false, message: "" });

const onRemoveParcels = () => {
  addGroupStore.flushSelectedParcels();
  Object.assign(errorCreateGroup, { isError: false, message: "" });
  conductionPercentage.value = 100;
  onConfirmPercentage();
};

//TODO: add better validation
const percentageErrors = ref<string[]>([]);
const checkPercentageErrors = () => {
  if (
    conductionPercentage.value === null ||
    conductionPercentage.value === undefined
  ) {
    return [t(`${moduleId}.errors.fieldRequired`)];
  } else if (conductionPercentage.value > 100) {
    return [t(`${moduleId}.errors.high_percentage`)];
  }
  return [];
};

const onConfirmPercentage = () => {
  percentageErrors.value = checkPercentageErrors();
  if (percentageErrors.value.length === 0) {
    addGroupStore.conductionPercentage = conductionPercentage.value;
    emitter.emit("update:percentage", conductionPercentage.value);
  }
};

const onCreateGroup = async (isFirst?: boolean) => {
  if (percentageErrors.value.length > 0) return;

  const response = await addGroupStore.createGroup();

  hasClickedFirstButton.value = !!isFirst;

  if (!response) {
    errorCreateGroup.isError = true;
  } else if (typeof response === "string") {
    errorCreateGroup.isError = true;
    errorCreateGroup.message = response;
  } else {
    errorCreateGroup.isError = false;
    errorCreateGroup.message = "";
  }

  if (!errorCreateGroup.isError) {
    useGroupsStore().searchGroups(+partyId.value);
    emitter.emit("is:dirty", false);
    router.replace({ name: RouteName.GROUP });
  }
};
</script>

<template>
  <div :id="accordionId">
    <BiAccordion
      :model-value="isOpen"
      @update:model-value="onOpenAccordion"
      :title="t(`${moduleId}.add_group.selected_parcels`, 2)"
      :is-disabled="isDisabled"
    >
      <div v-if="addGroupStore.hasConductedParcelsSelected">
        <div class="row">
          <BiInput
            v-model="conductionPercentage"
            type="number"
            class="w-25"
            is-percentage
            hide-arrows
            :max="100"
            :default-return-if-not-value="'undefined'"
            :label="t(`${moduleId}.add_group.conduction_percentage`)"
            :placeholder="t(`${moduleId}.add_group.conduction_percentage`)"
            :errors="percentageErrors"
            @blur="onConfirmPercentage"
          ></BiInput>
        </div>

        <ParcelSelectedAccordionButtons
          @create:group="onCreateGroup(true)"
          @flush:group="onRemoveParcels"
        />
        <BiAlert
          v-if="errorCreateGroup.isError && hasClickedFirstButton"
          is-error
          :title="t(`${moduleId}.error`)"
        >
          <template v-if="errorCreateGroup.message" #body>
            {{ errorCreateGroup.message }}
          </template>
        </BiAlert>

        <ParcelTableSelected
          :conducted-parcels-list="addGroupStore.conductedParcelsListSelected"
        />

        <ParcelSelectedAccordionButtons
          @create:group="onCreateGroup()"
          @flush:group="onRemoveParcels"
        />
        <BiAlert
          v-if="errorCreateGroup.isError && !hasClickedFirstButton"
          is-error
          :title="t(`${moduleId}.error`)"
        >
          <template v-if="errorCreateGroup.message" #body>
            {{ errorCreateGroup.message }}
          </template>
        </BiAlert>
      </div>

      <BiAlert v-else :title="t(`${moduleId}.add_group.alert.select_a_parcel`)">
      </BiAlert>
    </BiAccordion>
  </div>
</template>
