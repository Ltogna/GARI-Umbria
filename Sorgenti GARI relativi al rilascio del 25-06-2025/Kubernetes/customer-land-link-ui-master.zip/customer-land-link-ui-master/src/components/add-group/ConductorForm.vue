<script setup lang="ts">
import useEmitter from "@/composables/useEmitter";
import useForm from "@/composables/useForm";
import useModuleId from "@/composables/useModuleId";
import useUserDateFormat from "@/composables/useUserDateFormat";
import type { ConductorFieldsModel } from "@/models/groupFilter";
import { getDuplicatedGroups } from "@/resources/api/groups";
import { useAddGroupStore } from "@/stores/addGroup";
import { useTitleTypesStore } from "@/stores/titleTypes";
import { DEFAULT_CONDUCTOR_FORM } from "@/utils/defaultValues";
import { getFieldSelector } from "@/utils/formUtils";
import { removeTimezone } from "@/utils/removeTimezone";
import conductorFormValidatorConfig from "@/validators/conductorFormValidatorConfig";
import BiButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiButton.vue";
import BiModal from "@abaco/bootstrap-italia-components/src/components/BiModal/BiModal.vue";
import BiDatepicker from "@abaco/bootstrap-italia-components/src/components/form/BiDatepicker.vue";
import BiSelect from "@abaco/bootstrap-italia-components/src/components/form/BiSelect.vue";
import type { SelectItem } from "@abaco/bootstrap-italia-components/src/models";
import { getUUID } from "@abaco/bootstrap-italia-components/src/utilities";
import { ErrorType } from "@abaco/safe-rest/src/HTTPClient";
import { format, isAfter } from "date-fns";
import JustValidate, { type FieldRuleInterface } from "just-validate";
import { computed, onMounted, reactive, ref, watch } from "vue";
import { useI18n } from "vue-i18n";
import BiTextInput from "../BiTextInput.vue";

const { t } = useI18n();
const moduleId = useModuleId();
const addGroupStore = useAddGroupStore();
const titleTypesStore = useTitleTypesStore();
const emitter = useEmitter();
const userDateFormat = useUserDateFormat();

const disableForm = ref(false);

const formData = reactive<ConductorFieldsModel>(
  structuredClone(DEFAULT_CONDUCTOR_FORM),
);

const conductionTitleTypesItems = ref<SelectItem[]>([]);

const formId = `form-${getUUID()}`;
const formRef = ref<HTMLFormElement>();
const { validate, onValidate, onSubmit, onReset } = useForm(
  submitCallback,
  formData,
  formId,
);

const showModal = ref(false);

const onShowModal = () => {
  showModal.value = !showModal.value;
};

const onResetAll = () => {
  showModal.value = false;
  disableForm.value = false;
  addGroupStore.resetAllExceptParty();

  emitter.emit("unset:conduction");
  emitter.emit("close:selected:parcels");
  Object.assign(formData, DEFAULT_CONDUCTOR_FORM);

  onReset(DEFAULT_CONDUCTOR_FORM);
};

function submitCallback() {
  addGroupStore.setConduction(formData);
  emitter.emit("set:conduction");
  disableForm.value = true;
}

onMounted(async () => {
  await titleTypesStore.loadTitleTypes();
  conductionTitleTypesItems.value = titleTypesStore.titleTypes.map(
    ({ id, i18nCode }) => {
      return {
        id: id.toString(),
        text: i18nCode,
      } as SelectItem;
    },
  );

  if (formRef.value) {
    validate.value = conductorFormValidatorConfig(t, moduleId, formRef.value);
  }
});

const isLoading = ref(false);
const hasError = ref(false);
const checkDuplicated = async (partyId: number) => {
  isLoading.value = true;
  const response = await getDuplicatedGroups(partyId, formData.description);

  let isDuplicated = false;

  if (response.errorType !== ErrorType.NONE) {
    console.warn(response);
    hasError.value = true;
  } else {
    isDuplicated = response.data === 1;
    hasError.value = false;
  }
  isLoading.value = false;

  const descriptionSelector = getFieldSelector(formId, "description");
  if (isDuplicated) {
    (validate.value as JustValidate).addField(descriptionSelector, [
      {
        //TODO: problem with async validator
        validator: (value: string) => {
          if (!value || typeof value !== "string" || value === "") return true;
          return false;
        },
        errorMessage: t(`${moduleId}.errors.GROUP_DESCR_ERROR`),
      } as FieldRuleInterface,
    ]);
  } else if (
    (validate.value as JustValidate).getKeyByFieldSelector(descriptionSelector)
  ) {
    (validate.value as JustValidate).removeField(
      getFieldSelector(formId, "description"),
    );
  }
};

const onSubmitForm = async () => {
  if (!addGroupStore.partyId) {
    console.warn("Invalid partyId");
    return;
  }

  if (formData.description) {
    await checkDuplicated(addGroupStore.partyId);
  }

  onSubmit();
};

const isDayToRequired = computed(
  () =>
    !!titleTypesStore.titleTypes.find(
      (titleType) =>
        titleType.id === +formData.titleTypeId &&
        titleType.dayToReq &&
        titleType.dayToEditable,
    ),
);
const allowFutureDayFrom = computed(
  () =>
    !!titleTypesStore.titleTypes.find(
      (titleType) =>
        titleType.id === +formData.titleTypeId && titleType.allowFutureDayFrom,
    ),
);

const isEdible = computed(() => {
  const titleType = titleTypesStore.titleTypes.find(
    (titleType) =>
      titleType.id === +formData.titleTypeId &&
      ((titleType.dayToReq && titleType.dayToEditable) ||
        (!titleType.dayToReq && titleType.dayToEditable)),
  );

  return !!titleType;
});

const minDayTo = new Date();
minDayTo.setDate(new Date().getDate() + 1);

watch([isDayToRequired, isEdible], ([isRequired, isEdible]) => {
  if (isRequired) {
    (validate.value as JustValidate).addField(
      getFieldSelector(formId, "dayTo"),
      [
        {
          rule: "required",
          errorMessage: t(`${moduleId}.errors.fieldRequired`),
        } as FieldRuleInterface,
        {
          validator: (value: string | Date) => {
            if (!value || typeof value !== "string") return true;
            const dayFrom = removeTimezone(formData.dayFrom);
            const dayTo = removeTimezone(value);
            return dayFrom < dayTo;
          },
          errorMessage: () => {
            if (!formData.dayFrom) {
              return t(`${moduleId}.errors.INVALID_DAY_FROM`);
            }
            return t(`${moduleId}.errors.INVALID_DATE_AFTER`, {
              date: format(formData.dayFrom, userDateFormat),
            });
          },
        } as FieldRuleInterface,
      ],
    );
  } else if (isEdible) {
    (validate.value as JustValidate).addField(
      getFieldSelector(formId, "dayTo"),
      [
        {
          validator: (value: string | Date) => {
            if (!value || typeof value !== "string") return true;
            const dayFrom = removeTimezone(formData.dayFrom);
            const dayTo = removeTimezone(value);
            return dayFrom < dayTo;
          },
          errorMessage: () => {
            if (!formData.dayFrom) {
              return t(`${moduleId}.errors.INVALID_DAY_FROM`);
            }
            return t(`${moduleId}.errors.INVALID_DATE_AFTER`, {
              date: format(formData.dayFrom, userDateFormat),
            });
          },
        } as FieldRuleInterface,
      ],
    );
  } else {
    (validate.value as JustValidate).removeField(
      getFieldSelector(formId, "dayTo"),
    );
    delete formData.dayTo;
  }
});

const isDirty = ref(false);
//TODO: better implementation
watch(
  () => formData,
  (formData) => {
    if (!formData.dayTo) delete formData.dayTo;

    isDirty.value =
      JSON.stringify(formData) !==
      JSON.stringify(structuredClone(DEFAULT_CONDUCTOR_FORM));

    emitter.emit("is:dirty", isDirty.value);
  },
  { deep: true },
);

/**
 * #139066 - Reset Day From if Title Type Change Disallows Future Dates
 *
 * This watch function monitors changes to the `formData.titleTypeId` property.
 * When the title type ID changes:
 *
 * 1. Retrieve the new and old title type objects from the `titleTypesStore`.
 * 2. If the title types are valid and different:
 *   - Check if the old title type allows future dates (`allowFutureDayFrom`)
 *     and the new one doesn't.
 *   - Additionally, ensure `formData.dayFrom` is indeed a future date
 *     using `isAfter` (assuming it's a `Date` object).
 * 3. If both conditions are met, reset `formData.dayFrom` to the current date.
 *
 * This ensures that when the title type changes to one that disallows future
 * start dates, and the current `dayFrom` is in the future, it's automatically
 * reset to the present day, preventing invalid configurations.
 */
watch(
  () => formData.titleTypeId,
  (newTitleTypeId, oldTitleTypeId) => {
    const newTitleType = titleTypesStore.titleTypes.find(
      (title) => title.id.toString() === newTitleTypeId,
    );
    const oldTitleType = titleTypesStore.titleTypes.find(
      (title) => title.id.toString() === oldTitleTypeId,
    );

    if (newTitleType && oldTitleType && newTitleType.id !== oldTitleType.id) {
      if (
        oldTitleType.allowFutureDayFrom &&
        !newTitleType.allowFutureDayFrom &&
        isAfter(formData.dayFrom, new Date())
      ) {
        formData.dayFrom = new Date();
      }
    }
  },
);
</script>

<template>
  <form
    :id="formId"
    class="customer-land-link__landLink-search-form needs-validation pt-3"
    ref="formRef"
    autocomplete="off"
    @submit.prevent="onSubmitForm()"
  >
    <div class="row">
      <div class="col-md-3">
        <BiSelect
          :id="getUUID()"
          v-model="formData.titleTypeId"
          name="titleTypeId"
          class="field-required"
          :empty-option="t(`${moduleId}.add_group.select_title`)"
          :label="t(`${moduleId}.add_group.conduction_title`)"
          :items="conductionTitleTypesItems"
          :validator-fn="onValidate"
          :disabled="disableForm"
        >
        </BiSelect>
      </div>
      <div class="col-md-3">
        <BiDatepicker
          :id="getUUID()"
          v-model="formData.dayFrom"
          name="dayFrom"
          class="field-required"
          :label="t(`${moduleId}.add_group.conduction_start`)"
          :max="!allowFutureDayFrom ? new Date() : undefined"
          :validator-fn="onValidate"
          :is-disabled="disableForm"
        ></BiDatepicker>
      </div>
      <div class="col-md-3">
        <!-- TODO: props min not reactive -->
        <BiDatepicker
          v-model="formData.dayTo"
          name="dayTo"
          :id="getUUID()"
          :class="{
            'field-required': isDayToRequired,
          }"
          :label="t(`${moduleId}.add_group.conduction_end`)"
          :min="minDayTo"
          :is-disabled="!isEdible || disableForm"
          :validator-fn="onValidate"
        ></BiDatepicker>
      </div>
      <div class="col-md-3">
        <BiTextInput
          :id="getUUID()"
          name="description"
          type="search"
          v-model="formData.description"
          @validate="onValidate"
          :label="t(`${moduleId}.add_group.description`)"
          :placeholder="t(`${moduleId}.add_group.group_description`)"
          :disabled="disableForm"
        ></BiTextInput>
      </div>
    </div>
    <div class="row pt-4">
      <div class="col-md-12 text-center">
        <BiButton
          color="secondary"
          is-outlined
          class="me-2"
          @click="onShowModal"
        >
          {{ t(`${moduleId}.add_group.cancel`) }}
        </BiButton>
        <BiButton color="success" type="submit" :is-disabled="disableForm">
          {{ t(`${moduleId}.add_group.set_conduction`) }}
        </BiButton>
      </div>
    </div>
  </form>

  <BiModal :title="t(`${moduleId}.warning`)" v-model="showModal">
    <template #body>
      {{ t(`${moduleId}.add_group.remove_selected_parcels_confirm`, 2) }}
    </template>
    <template #footer>
      <div class="d-flex justify-content-center vw-100">
        <div>
          <BiButton
            class="me-3"
            color="primary"
            is-outlined
            @click="onShowModal"
          >
            {{ t(`${moduleId}.add_group.cancel`) }}
          </BiButton>
        </div>

        <div>
          <BiButton color="success" @click="onResetAll">
            {{ t(`${moduleId}.add_group.confirm`) }}
          </BiButton>
        </div>
      </div>
    </template>
  </BiModal>
</template>
: string: string | Date: string | Date
