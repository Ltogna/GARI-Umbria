// import type { FieldRuleInterface } from "just-validate/dist/modules/interfaces";
// import { getFieldSelector } from "@/utils/formUtils";
import { justValidateConfig } from "./../../utils/formUtils";
import JustValidate from "just-validate";

const parcelSearchFormValidatorConfig = (
  t: (s: string) => string,
  moduleId: string,
  formRef: HTMLFormElement,
): JustValidate => new JustValidate(formRef, justValidateConfig);

export default parcelSearchFormValidatorConfig;
