<script setup lang="ts">
import useModuleId from "@/composables/useModuleId";
import useParty from "@/composables/useParty";
import { useAddGroupStore } from "@/stores/addGroup";
import { useI18n } from "vue-i18n";
import ConductorForm from "./ConductorForm.vue";
import ParcelSearchAccordion from "./ParcelSearchAccordion.vue";
import ParcelSelectedAccordion from "./ParcelSelectedAccordion.vue";
import usePermissions from "@/composables/usePermissions";
import { useRouter } from "vue-router";
import { watch } from "vue";
import { RouteName } from "@/models/routes";

//TODO: better implementation
const { canWrite } = usePermissions();
const router = useRouter();
watch(
  () => canWrite,
  (canEnter) => {
    if (!canEnter) router.replace({ name: RouteName.GROUP });
  },
  { immediate: true },
);

const moduleId = useModuleId();
const { t } = useI18n();
const { partyId } = useParty();

useAddGroupStore().setPartyId(partyId.value);
</script>

<template>
  <div class="card-body">
    <div
      class="customer-land-link__page-title d-flex justify-content-between align-items-center mb-3"
    >
      <h4 class="customer-land-link__page-title--text">
        {{ t(`${moduleId}.add_group.create_new_group`) }}
      </h4>
    </div>
    <div class="mb-4">
      <ConductorForm />
    </div>
    <ParcelSearchAccordion />
    <ParcelSelectedAccordion />
  </div>
</template>
