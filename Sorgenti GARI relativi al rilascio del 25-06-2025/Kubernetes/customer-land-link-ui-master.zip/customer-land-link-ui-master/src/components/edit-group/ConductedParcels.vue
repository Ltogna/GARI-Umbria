<script setup lang="ts">
import useModuleId from "@/composables/useModuleId";
import useParty from "@/composables/useParty";
import usePermissions from "@/composables/usePermissions";
import useUserDateFormat from "@/composables/useUserDateFormat";
import { INFINITE_DATE } from "@/constants";
import type { LandLinkModel } from "@/models/landLink";
import { RouteName } from "@/models/routes";
import { dateToString } from "@/models/utils";
import { useEditGroupStore } from "@/stores/editGroup";
import {
  convertAreaSQMInHA,
  intlNumberFormatOptions,
  percNumberFormatOption,
} from "@/utils/area";
import { getSheetReference } from "@/utils/getSheetReference";
import { gotoViewer } from "@/utils/gotoViewer";
import { isEditable } from "@/utils/isGroupEditable";
import BiButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiButton.vue";
import BiIconButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiIconButton.vue";
import BiHiddenContent from "@abaco/bootstrap-italia-components/src/components/BiHiddenContent/BiHiddenContent.vue";
import BiIcon from "@abaco/bootstrap-italia-components/src/components/BiIcon/BiIcon.vue";
import BiTable from "@abaco/bootstrap-italia-components/src/components/BiTable/BiTable.vue";
import useColors from "@abaco/bootstrap-italia-components/src/composables/useColors";
import { format } from "date-fns";
import { inject, onMounted } from "vue";
import { useI18n } from "vue-i18n";
import { useRouter } from "vue-router";
import AnomalyTooltipIcon from "../common/AnomalyTooltipIcon.vue";

const { t, n } = useI18n();
const moduleId = useModuleId();
const basePath = inject<string>("basePath", import.meta.env.BASE_URL);
const editGroupStore = useEditGroupStore();
const { getColor } = useColors();
const router = useRouter();
const { canWrite } = usePermissions();
const userDateFormat = useUserDateFormat();
const { partyId } = useParty();

onMounted(async () => {
  await editGroupStore.fetchGroupLandLinks();
});

const getRealDayTo = (date: Date) => {
  const parsedDate = dateToString.safeParse(date);
  if (!parsedDate.success) {
    console.warn(parsedDate.error);
    return "";
  }
  return parsedDate.data === INFINITE_DATE ? "" : format(date, userDateFormat);
};

const goToEditLandLink = (landlinkId: number) => {
  router.push({ name: RouteName.GROUP_EDIT_LANDLINK, params: { landlinkId } });
};

function canEditLandLink(landLink: LandLinkModel): boolean {
  return isEditable(landLink);
}

/**
 * #138997 goBack
 */
function goBack() {
  router.push({
    name: RouteName.GROUP,
    params: {
      partyId: partyId.value,
    },
  });
}
</script>

<template>
  <div>
    <p class="fw-bold">{{ t(`${moduleId}.landLink`, 2) }}</p>
    <BiTable
      is-custom
      responsive-breakpoint="md"
      is-row-hover
      extraTableClasses="table-head-bg"
    >
      <template #head>
        <tr class="bg-light" :class="getColor('text', 'secondary')">
          <th scope="col">
            {{ t(`${moduleId}.add_group.sheet_references`) }}
          </th>
          <th scope="col">{{ t(`${moduleId}.add_group.gis_area`) }}</th>
          <th scope="col">{{ t(`${moduleId}.add_group.conduction`) }}</th>
          <th scope="col">{{ t(`${moduleId}.add_group.conducted_area`) }}</th>
          <th scope="col">
            {{ t(`${moduleId}.landLink_list.conduction_period`) }}
          </th>
          <th scope="col">
            {{ t(`${moduleId}.landLink_filter_form.anomalyLevel`) }}
          </th>
          <th scope="col">
            <BiHiddenContent :text="t(`${moduleId}.action`, 2)">
            </BiHiddenContent>
          </th>
        </tr>
      </template>
      <template #body>
        <tr v-for="landLink in editGroupStore.landLinks" :key="landLink.id">
          <td
            :data-label="t(`${moduleId}.add_group.sheet_references`)"
            class="text-break max-w-xs"
          >
            {{ getSheetReference(landLink.parcel, true) }}
          </td>
          <td :data-label="t(`${moduleId}.add_group.gis_area`)">
            {{ convertAreaSQMInHA(landLink.parcel.areaSqm ?? 0) }}
          </td>
          <td :data-label="t(`${moduleId}.add_group.conduction`)">
            <p class="mb-0">
              {{ landLink.titleType.i18nCode ?? landLink.titleType.code }}
            </p>
            <p class="mb-0">
              {{ n(landLink.titleTypePerc, percNumberFormatOption) }}%
            </p>
          </td>
          <td :data-label="t(`${moduleId}.add_group.conducted_area`)">
            {{
              n(
                convertAreaSQMInHA(landLink.titleTypeAreaSqm ?? 0),
                intlNumberFormatOptions,
              )
            }}
          </td>
          <td :data-label="t(`${moduleId}.landLink_list.conduction_period`)">
            <p class="mb-0">
              {{ format(landLink.dayFrom, userDateFormat) }}
            </p>
            <p class="mb-0" v-if="getRealDayTo(landLink.dayTo)">
              {{ getRealDayTo(landLink.dayTo) }}
            </p>
          </td>
          <td :data-label="t(`${moduleId}.landLink_filter_form.anomalyLevel`)">
            <AnomalyTooltipIcon
              v-if="landLink.anomalyCount && landLink.maxAnomalyLevel"
              :max-anomaly-level="landLink.maxAnomalyLevel"
              :count-anomalies="landLink.anomalyCount"
            />
          </td>
          <td>
            <div class="d-flex flex-nowrap">
              <BiIconButton
                v-if="canWrite && canEditLandLink(landLink)"
                class="me-1 p-3"
                is-icon
                :color="'secondary'"
                is-outlined
                icon="pencil"
                icon-style="fas"
                :title="t(`${moduleId}.goto_edit_landlink`)"
                @click="goToEditLandLink(landLink.id)"
              />
              <!-- #133247 don't show link Viewer if there is no area or is 0-->
              <BiIconButton
                v-if="landLink.parcel.areaSqm && landLink.parcel.areaSqm > 0"
                class="me-1 p-3"
                is-icon
                :color="'secondary'"
                is-outlined
                icon="map-marked-alt"
                icon-style="fas"
                :title="t(`${moduleId}.open_viewer`)"
                @click="gotoViewer(landLink.parcel.id, basePath)"
              />
            </div>
          </td>
        </tr>
      </template>
    </BiTable>
    <div class="row pt-4">
      <div class="col-md-12 text-center">
        <BiButton
          color="primary"
          is-outlined
          is-icon
          class="btn-me"
          @click="goBack"
        >
          <BiIcon icon="arrow-left" class="me-2" />
          {{ t(`${moduleId}.edit_group.back`) }}
        </BiButton>
        <BiButton
          v-if="editGroupStore.nextKey"
          color="secondary"
          is-outlined
          @click="editGroupStore.fetchGroupLandLinks(true)"
        >
          {{ t(`${moduleId}.load_more`) }}
        </BiButton>
      </div>
    </div>
  </div>
</template>
