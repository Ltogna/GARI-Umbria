<script setup lang="ts">
import useGroup from "@/composables/useGroup";
import useParty from "@/composables/useParty";
import { useEditGroupStore } from "@/stores/editGroup";

const { groupId } = useGroup();
const { partyId } = useParty();
const editGroupStore = useEditGroupStore();

editGroupStore.groupId = +groupId.value;
editGroupStore.partyId = +partyId.value;
</script>

<template>
  <RouterView />
</template>
