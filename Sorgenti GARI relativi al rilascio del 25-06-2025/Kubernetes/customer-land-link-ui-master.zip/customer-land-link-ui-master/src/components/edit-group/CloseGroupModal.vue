<script setup lang="ts">
import useForm from "@/composables/useForm";
import useModuleId from "@/composables/useModuleId";
import { closeGroup } from "@/resources/api/groups";
import { useGroupsStore } from "@/stores/groups";
// import { getFieldSelector } from "@/utils/formUtils";
import useUserDateFormat from "@/composables/useUserDateFormat";
import { getFieldSelector } from "@/utils/formUtils";
import BiAlert from "@abaco/bootstrap-italia-components/src/components/BiAlert/BiAlert.vue";
import BiButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiButton.vue";
import BiModal from "@abaco/bootstrap-italia-components/src/components/BiModal/BiModal.vue";
import BiDatepicker from "@abaco/bootstrap-italia-components/src/components/form/BiDatepicker.vue";
import { getUUID } from "@abaco/bootstrap-italia-components/src/utilities";
import { ErrorType } from "@abaco/safe-rest/src/HTTPClient";
import { format, isAfter, isBefore } from "date-fns";
import JustValidate, { type FieldRuleInterface } from "just-validate";
import { onMounted, reactive, ref, defineProps, defineEmits } from "vue";
import { useI18n } from "vue-i18n";
import { useRouter } from "vue-router";
import closeGroupFormValidatorConfig from "./closeGroupFormValidatorConfig";
import { RouteName } from "@/models/routes";

const props = defineProps<{
  modelValue: boolean;
  groupId: string;
  partyId: string;
  dayFrom: Date;
  dayTo?: Date | null;
}>();

const emits = defineEmits<{
  (e: "update:modelValue", value: boolean): void;
}>();

const moduleId = useModuleId();
const { t } = useI18n();
const router = useRouter();

const formData = reactive<{ dayTo: Date }>({} as { dayTo: Date });

const formId = `form-${getUUID()}`;
const formRef = ref<HTMLFormElement>();
const { validate, onValidate, onSubmit } = useForm(
  onCloseGroup,
  formData,
  formId,
);
const userDateFormat = useUserDateFormat();
let stayHere = true;

onMounted(() => {
  stayHere = true;
  if (formRef.value) {
    const today = props.dayTo ? props.dayTo : new Date();
    validate.value = closeGroupFormValidatorConfig(t, moduleId, formRef.value);
    (validate.value as JustValidate).addField(
      getFieldSelector(formId, "dayTo"),
      [
        {
          rule: "required",
          errorMessage: t(`${moduleId}.errors.fieldRequired`),
        } as FieldRuleInterface,
        {
          validator: (value) => {
            if (!value || typeof value !== "string" || !props.dayFrom)
              return true;
            return isAfter(new Date(value), props.dayFrom);
          },
          errorMessage: () =>
            t(`${moduleId}.errors.INVALID_DATE_AFTER`, {
              date: format(props.dayFrom, userDateFormat),
            }),
        } as FieldRuleInterface,
        {
          validator: (value) => {
            if (!value || typeof value !== "string" || !props.dayFrom)
              return true;
            return isBefore(new Date(value), today);
          },
          errorMessage: () =>
            t(`${moduleId}.errors.INVALID_DATE_BEFORE`, {
              date: format(today, userDateFormat),
            }),
        } as FieldRuleInterface,
      ],
    );
  }
});

const isLoading = ref(false);
const hasError = ref(false);

async function onCloseGroup() {
  stayHere = true;
  isLoading.value = true;
  if (formData.dayTo) {
    const endDate = new Date(formData.dayTo);
    const response = await closeGroup(+props.partyId, +props.groupId, endDate);

    if (response.errorType !== ErrorType.NONE) {
      console.warn(response);
      hasError.value = true;
    } else {
      hasError.value = false;
    }
    if (!hasError.value) {
      await useGroupsStore().searchGroups(+props.partyId);
      emits("update:modelValue", false);
      stayHere = false;
    }
  } else {
    console.warn("No dayTo setted");
  }
}

function closeModalHandler() {
  if (!stayHere) {
    router.replace({ name: RouteName.GROUP });
  }
}
</script>

<template>
  <BiModal
    :title="t(`${moduleId}.edit_group.conduction_closing`)"
    :model-value="modelValue"
    @update:model-value="(val: boolean) => emits('update:modelValue', val)"
    @hidden-modal="closeModalHandler"
  >
    <template #body>
      <i18n-t
        :keypath="`${moduleId}.edit_group.set_conduction_end_date`"
        scope="global"
      >
        <template #date>
          <strong>
            {{ t(`${moduleId}.edit_group.conduction_end_date`).toLowerCase() }}
          </strong>
        </template>
      </i18n-t>

      <BiAlert v-if="hasError" is-error :title="t(`${moduleId}.error`)" />

      <form
        :id="formId"
        ref="formRef"
        class="customer-land-link__landLink-search-form needs-validation pt-3"
        @submit.prevent="onSubmit"
      >
        <BiDatepicker
          :id="getUUID()"
          v-model="formData.dayTo"
          name="dayTo"
          :label="t(`${moduleId}.edit_group.conduction_end_date`)"
          class="field-required"
          :validator-fn="onValidate"
        >
        </BiDatepicker>
        <input type="submit" class="invisible" />
      </form>
    </template>
    <template #footer>
      <div class="d-flex justify-content-center vw-100">
        <div>
          <BiButton
            class="me-3"
            color="primary"
            is-outlined
            @click="emits('update:modelValue', false)"
          >
            {{ t(`${moduleId}.close`) }}
          </BiButton>
        </div>

        <div>
          <BiButton color="success" @click="onSubmit">
            {{ t(`${moduleId}.add_group.confirm`) }}
          </BiButton>
        </div>
      </div>
    </template>
  </BiModal>
</template>
