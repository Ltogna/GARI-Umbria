<script setup lang="ts">
import useForm from "@/composables/useForm";
import useGroup from "@/composables/useGroup";
import useModuleId from "@/composables/useModuleId";
import useParty from "@/composables/useParty";
import usePermissions from "@/composables/usePermissions";
import useUserDateFormat from "@/composables/useUserDateFormat";
import { INFINITE_DATE } from "@/constants";
import type { ConductorFieldsModel } from "@/models/groupFilter";
import type { GroupUpdateReqModel } from "@/models/groups";
import { dateToString } from "@/models/utils";
import { useEditGroupStore } from "@/stores/editGroup";
import { useGroupsStore } from "@/stores/groups";
import { getFieldSelector } from "@/utils/formUtils";
import { removeTimezone } from "@/utils/removeTimezone";
import conductorFormValidatorConfig from "@/validators/conductorFormValidatorConfig";
import BiAlert from "@abaco/bootstrap-italia-components/src/components/BiAlert/BiAlert.vue";
import BiButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiButton.vue";
import BiDatepicker from "@abaco/bootstrap-italia-components/src/components/form/BiDatepicker.vue";
import BiInput from "@abaco/bootstrap-italia-components/src/components/form/BiInput.vue";
import BiSelect from "@abaco/bootstrap-italia-components/src/components/form/BiSelect.vue";
import type { SelectItem } from "@abaco/bootstrap-italia-components/src/models";
import { getUUID } from "@abaco/bootstrap-italia-components/src/utilities";
import { format } from "date-fns";
import JustValidate, { type FieldRuleInterface } from "just-validate";
import { onMounted, reactive, ref } from "vue";
import { useI18n } from "vue-i18n";
import { useRouter } from "vue-router";
import CloseGroupModal from "./CloseGroupModal.vue";
import { useSettingStore } from "@/stores/settings";
import { RouteName } from "@/models/routes";
import LandLinkModalDelete from "../land-link/LandLinkModalDelete.vue";
import { deleteGroupParcel } from "@/resources/api/landLink";
import { useNotificationStore } from "@/stores/notification";

const { t } = useI18n();
const router = useRouter();

const moduleId = useModuleId();
const editGroupStore = useEditGroupStore();
const settingStore = useSettingStore();
const groupsStore = useGroupsStore();

const formData = reactive<ConductorFieldsModel>({} as ConductorFieldsModel);

const conductionTitleTypesItems = ref<SelectItem[]>([]);

const { partyId } = useParty();
const { groupId } = useGroup();
const { canWrite } = usePermissions();
const { setRawMessge } = useNotificationStore();
let isDeleted = false;

const formId = `form-${getUUID()}`;
const formRef = ref<HTMLFormElement>();
const { validate, onValidate, onSubmit } = useForm(
  submitCallback,
  formData,
  formId,
);

const showModal = ref(false);
const onShowModal = () => {
  showModal.value = !showModal.value;
};
const isModalDelete = ref(false);

async function submitCallback() {
  const dayTo = formData.dayTo
    ? dateToString.parse(formData.dayTo).toString()
    : INFINITE_DATE;

  const data: GroupUpdateReqModel = {
    dayFrom: dateToString.parse(formData.dayFrom).toString(),
    descr: formData.description,
    dayTo,
  };

  await editGroupStore.updateGroup(data);

  if (!editGroupStore.hasError) {
    groupsStore.searchGroups(+partyId.value);
    router.replace({ name: RouteName.GROUP });
  }
}

const isDayToEditable = ref<boolean>(false);
const isDayToRequired = ref<boolean>(false);
const allowFutureDayFrom = ref<boolean>(false);

onMounted(async () => {
  isDeleted = false;
  await editGroupStore.fetchGroup();
  if (!editGroupStore.hasError && editGroupStore.group) {
    const { dayFrom, dayTo, titleType, descr } = editGroupStore.group;

    Object.assign(formData, {
      dayFrom,
      dayTo: dateToString.parse(dayTo) !== INFINITE_DATE ? dayTo : undefined,
      titleTypeId: titleType.id.toString(),
      description: descr,
    } as ConductorFieldsModel);

    conductionTitleTypesItems.value.push({
      id: titleType.id.toString(),
      text: titleType.i18nCode,
      selected: true,
    });

    if (formRef.value)
      validate.value = conductorFormValidatorConfig(t, moduleId, formRef.value);

    isDayToEditable.value = !!titleType.dayToEditable;
    isDayToRequired.value = titleType.dayToReq;
    allowFutureDayFrom.value = titleType.allowFutureDayFrom;
    if (isDayToRequired.value) {
      addDayToValidation(true);
    } else if (isDayToEditable.value) {
      addDayToValidation(false);
    }
  }
});

const minDayTo = new Date();
minDayTo.setDate(new Date().getDate() + 1);
const userDateFormat = useUserDateFormat();

function addDayToValidation(isRequired: boolean) {
  const rules: FieldRuleInterface[] = [];
  if (isRequired) {
    rules.push({
      rule: "required",
      errorMessage: t(`${moduleId}.errors.fieldRequired`),
    } as FieldRuleInterface);
  }

  rules.push({
    validator: (value) => {
      if (!value || typeof value !== "string") return true;
      const dayFrom = removeTimezone(formData.dayFrom);
      const dayTo = removeTimezone(value);
      return dayFrom < dayTo;
    },
    errorMessage: () =>
      t(`${moduleId}.errors.INVALID_DATE_AFTER`, {
        date: format(formData.dayFrom, userDateFormat),
      }),
  } as FieldRuleInterface);

  (validate.value as JustValidate).addField(
    getFieldSelector(formId, "dayTo"),
    rules,
  );
}

function showModalDelete() {
  isModalDelete.value = true;
}

const deleteOnGroup = async () => {
  const groupId = editGroupStore.groupId;
  if (partyId.value && groupId) {
    isDeleted = await deleteGroupParcel(Number(partyId.value), groupId);
    if (isDeleted) {
      setRawMessge({
        isError: false,
        message: t(`${moduleId}.success.GENERIC_SAVE`),
      });
      await groupsStore.searchGroups(+partyId.value);
      isModalDelete.value = false;
    }
  }
};

function shouldLeavePage() {
  if (isDeleted) {
    router.replace({
      name: RouteName.GROUP,
    });
    isDeleted = false;
  }
}
</script>

<template>
  <BiAlert
    v-if="editGroupStore.hasError"
    is-error
    :title="t(`${moduleId}.error`)"
  >
    <template #body>
      {{ editGroupStore.errorMessage }}
    </template>
  </BiAlert>

  <form
    :id="formId"
    v-if="!editGroupStore.isLoading"
    class="customer-land-link__landLink-search-form needs-validation pt-3"
    ref="formRef"
    @submit.prevent="onSubmit"
  >
    <div class="row">
      <div class="col-md-3">
        <BiSelect
          :id="getUUID()"
          :model-value="formData.titleTypeId"
          :items="conductionTitleTypesItems"
          name="titleTypeId"
          class="field-required"
          :label="t(`${moduleId}.add_group.conduction_title`)"
          disabled
        ></BiSelect>
      </div>
      <div class="col-md-3">
        <BiDatepicker
          :id="getUUID()"
          v-model="formData.dayFrom"
          name="dayFrom"
          class="field-required"
          :label="t(`${moduleId}.add_group.conduction_start`)"
          :max="!allowFutureDayFrom ? new Date() : undefined"
          :validator-fn="onValidate"
          :is-disabled="!editGroupStore.isEditable || !canWrite"
        ></BiDatepicker>
      </div>
      <div class="col-md-3">
        <!-- TODO: props min not reactive -->
        <BiDatepicker
          v-model="formData.dayTo"
          name="dayTo"
          :id="getUUID()"
          :class="{
            'field-required': isDayToRequired,
          }"
          :label="t(`${moduleId}.add_group.conduction_end`)"
          :is-disabled="
            !isDayToEditable || !editGroupStore.isEditable || !canWrite
          "
          :validator-fn="onValidate"
        ></BiDatepicker>
      </div>
      <div class="col-md-3">
        <BiInput
          :id="getUUID()"
          type="search"
          v-model="formData.description"
          :label="t(`${moduleId}.add_group.description`)"
          :placeholder="t(`${moduleId}.add_group.group_description`)"
          :disabled="!editGroupStore.isEditable || !canWrite"
        ></BiInput>
      </div>
    </div>
    <div
      v-if="
        (editGroupStore.isEditable ||
          // #141481 fixed double material error button
          (!editGroupStore.isFuture && settingStore.canUpdateClosedElements)) &&
        canWrite
      "
      class="row pt-4"
    >
      <div class="col-md-12 text-center">
        <BiButton
          v-if="editGroupStore.isEditable"
          color="success"
          class="me-2"
          type="submit"
        >
          {{ t(`${moduleId}.edit_group.edit_group`) }}
        </BiButton>
        <BiButton
          v-if="
            editGroupStore.isEditable || settingStore.canUpdateClosedElements
          "
          color="success"
          class="me-2"
          @click="onShowModal"
        >
          {{ t(`${moduleId}.edit_group.close_group`) }}
        </BiButton>
        <BiButton color="danger" is-icon @click="showModalDelete()">
          {{ t(`${moduleId}.landLink_form.delete`) }}
        </BiButton>
      </div>
    </div>
    <div v-if="editGroupStore.isFuture" class="row pt-4">
      <div class="col-md-12 text-center">
        <BiButton color="danger" is-icon @click="showModalDelete()">
          {{ t(`${moduleId}.landLink_form.delete`) }}
        </BiButton>
      </div>
    </div>
  </form>

  <CloseGroupModal
    v-if="editGroupStore.group?.dayFrom && canWrite"
    v-model="showModal"
    :party-id="partyId"
    :group-id="groupId"
    :day-from="editGroupStore.group.dayFrom"
    :day-to="editGroupStore.group.dayTo"
  />
  <LandLinkModalDelete
    v-model="isModalDelete"
    group-message
    :onDelete="deleteOnGroup"
    @hidden-modal="shouldLeavePage"
  />
</template>
