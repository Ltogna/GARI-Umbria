import { getFieldSelector, justValidateConfig } from "@/utils/formUtils";
import JustValidate from "just-validate";
import type { FieldRuleInterface } from "just-validate/dist/modules/interfaces";

const closeGroupFormValidatorConfig = (
  t: (s: string) => string,
  moduleId: string,
  formRef: HTMLFormElement,
): JustValidate =>
  new JustValidate(formRef, justValidateConfig).addField(
    getFieldSelector(formRef.id, "dayTo"),
    [
      {
        rule: "required",
        errorMessage: t(`${moduleId}.errors.fieldRequired`),
      } as FieldRuleInterface,
    ],
  );

export default closeGroupFormValidatorConfig;
