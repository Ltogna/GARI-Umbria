<script setup lang="ts">
import useModuleId from "@/composables/useModuleId";
// import { useEditGroupStore } from "@/stores/editGroup";
import { useI18n } from "vue-i18n";
import ConductedParcels from "./ConductedParcels.vue";
import ConductorForm from "./ConductorForm.vue";

const moduleId = useModuleId();
const { t } = useI18n();

// const editGroupStore = useEditGroupStore();
</script>

<template>
  <div class="card-body">
    <div
      class="customer-land-link__page-title d-flex justify-content-between align-items-center mb-3"
    >
      <h4 class="customer-land-link__page-title--text">
        {{ t(`${moduleId}.edit_group.conductor_group_detail`) }}
      </h4>
    </div>
    <div class="mb-4">
      <ConductorForm />
    </div>
    <ConductedParcels />
  </div>
</template>
