<script lang="ts" setup>
import useParty from "@/composables/useParty";
import { usePartyStore } from "@/stores/party";
import { watch } from "vue";
import TopHeader from "../TopHeader.vue";

const partyStore = usePartyStore();
const partyId = useParty();

watch(
  () => partyId,
  async ({ partyId: pId }) => {
    if (!partyStore.partyDetail && !!pId.value) {
      await partyStore.fetchPartyById(+pId.value);
    }
  },
  { immediate: true },
);
</script>
<template>
  <TopHeader
    v-if="partyStore.partyDetail"
    :title="partyStore.partyBannerInfo"
  />
</template>
