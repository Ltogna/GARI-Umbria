<script setup lang="ts">
import useModuleId from "@/composables/useModuleId";
import useParty from "@/composables/useParty";
import usePermissions from "@/composables/usePermissions";
import { RouteName } from "@/models/routes";
import randomUUID from "@/utils/randomUUID";
import BiAccordion from "@abaco/bootstrap-italia-components/src/components/BiAccordion/BiAccordion.vue";
import BiCollapse from "@abaco/bootstrap-italia-components/src/components/BiCollapse/BiCollapse.vue";
import { ref } from "vue";
import { useI18n } from "vue-i18n";

const moduleId = useModuleId();
const { t } = useI18n();
const { partyId } = useParty();
const { canWrite } = usePermissions();
const randomId = randomUUID();

const accordionOpen = ref(true);
</script>

<template>
  <div class="customer-land-link__sidebar-menu">
    <BiAccordion
      :model-value="true"
      color-bg-header="primary"
      color-header="white"
      body-extra-class="p-0"
      header-extra-class="d-block text-truncate"
    >
      <template #header>
        <span class="text-truncate">
          {{ t(`${moduleId}.title`).toUpperCase() }}
        </span>
      </template>

      <div class="it-list-wrapper">
        <ul class="it-list border ps-3 pe-1 py-3" v-if="partyId">
          <li class="customer-land-link__item-list position-relative">
            <RouterLink
              :to="{
                name: RouteName.LAND_LINK_LIST,
                params: { partyId },
              }"
              :class="'text-decoration-none px-2 py-2 d-block lh-sm'"
              :active-class="'fw-semibold text-black'"
            >
              <span>{{ t(`${moduleId}.parcel_conducted`, 2) }}</span>
            </RouterLink>
          </li>
          <li>
            <RouterLink
              :to="{ name: RouteName.GROUP, params: { partyId } }"
              :class="'text-decoration-none px-2 py-2 d-block lh-sm'"
              :active-class="'fw-semibold text-black'"
            >
              <span>{{ t(`${moduleId}.group.management`, 2) }}</span>
            </RouterLink>
          </li>
        </ul>
      </div>
    </BiAccordion>

    <BiAccordion
      v-if="canWrite"
      :model-value="true"
      color-bg-header="primary"
      color-header="white"
      body-extra-class="p-0"
      header-extra-class="d-block text-truncate"
    >
      <template #header>
        <span class="text-truncate">
          {{ t(`${moduleId}.bulk_actions`).toUpperCase() }}
        </span>
      </template>
      <div class="it-list-wrapper">
        <ul class="it-list border ps-3 pe-1 py-3">
          <li
            class="customer-land-link__item-list position-relative"
            :class="{ 'border-bottom-item': accordionOpen }"
          >
            <BiCollapse
              tag="span"
              :targetSelector="`#collapseContainer${randomId}`"
              v-model="accordionOpen"
              role="button"
            >
              <span
                class="text-truncate"
                style="font-weight: 600; color: hsl(210, 17%, 44%)"
              >
                {{ t(`${moduleId}.conduits_closure`) }}
              </span>
            </BiCollapse>
          </li>
          <ul
            :id="`collapseContainer${randomId}`"
            class="it-list ps-3 pe-1 py-3"
          >
            <li class="customer-land-link__item-list position-relative">
              <RouterLink
                :to="{ name: RouteName.PARCEL_BULK }"
                :class="'text-decoration-none px-2 py-2 d-block lh-sm'"
                :active-class="'fw-semibold text-black'"
              >
                <span>{{ t(`${moduleId}.parcel_conducted`, 2) }}</span>
              </RouterLink>
            </li>
            <li>
              <RouterLink
                :to="{ name: RouteName.GROUP_BULK }"
                :class="'text-decoration-none px-2 py-2 d-block lh-sm'"
                :active-class="'fw-semibold text-black'"
              >
                <span>{{ t(`${moduleId}.group.management`, 2) }}</span>
              </RouterLink>
            </li>
          </ul>
        </ul>
      </div>
    </BiAccordion>
    <RouterView name="accordion"></RouterView>
    <RouterView name="accordionInfo"></RouterView>
  </div>
</template>

<style scoped lang="scss">
.collapse-icon {
  transform: rotate(-180deg);
}
</style>
