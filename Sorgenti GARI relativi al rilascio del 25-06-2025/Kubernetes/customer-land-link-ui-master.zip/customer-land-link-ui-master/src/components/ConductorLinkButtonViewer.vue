<script setup lang="ts">
import { RouteName } from "@/models/routes";
import BiButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiButton.vue";
import { useI18n } from "vue-i18n";
import { useRoute } from "vue-router";
import useModuleId from "@/composables/useModuleId";
import { computed } from "vue";
import { useLandLinksStore } from "@/stores/landLinks";
import { getPortalBaseLpisViewerURL } from "@/utils/urlUtils";

const route = useRoute();
const { t } = useI18n();
const moduleId = useModuleId();

const landLinkStore = useLandLinksStore();

const parcelId = computed(() => {
  return landLinkStore.landLinkDetail?.parcel.id ?? null;
});

function goToLpiViewerConductor() {
  if (parcelId.value) {
    window.location.assign(
      `${getPortalBaseLpisViewerURL()}/parcel/${parcelId.value}/historyConductor`,
    );
  } else {
    console.error("Missing parcel Id");
  }
}

const isLandLinkRoute = computed(() => {
  return (
    parcelId.value &&
    route.name &&
    [RouteName.GROUP_EDIT_LANDLINK, RouteName.LAND_LINK_EDIT].includes(
      route.name as RouteName,
    )
  );
});
</script>

<template>
  <BiButton
    v-if="isLandLinkRoute"
    color="primary"
    is-outlined
    class="btn-me"
    @click="goToLpiViewerConductor()"
  >
    {{ t(`${moduleId}.conductor_link`) }}
  </BiButton>
</template>
