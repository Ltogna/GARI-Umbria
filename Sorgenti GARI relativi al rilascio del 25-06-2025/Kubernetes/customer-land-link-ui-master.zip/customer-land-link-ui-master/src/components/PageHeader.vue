<script lang="ts" setup>
import useModuleId from "@/composables/useModuleId";
import { useI18n } from "vue-i18n";
import { onMounted, ref, type Ref } from "vue";
import BiBackButton from "@abaco/bootstrap-italia-components/src/components/BiBackButton/BiBackButton.vue";

const moduleId = useModuleId();
const { t } = useI18n();

const backUrl: Ref<string | null> = ref(null);

function goBack() {
  if (backUrl.value) location.assign(decodeURIComponent(backUrl.value));
}

onMounted(async () => {
  backUrl.value = sessionStorage.getItem(`${moduleId}.backUrl`);
});
</script>

<template>
  <div
    class="scheda-icona-small border-bottom border-primary px-3 pt-1 d-flex justify-content-between align-items-center"
  >
    <h3 class="primary-color">
      <BiBackButton
        v-if="backUrl"
        @click="goBack"
        :visually-hidden-text="t(`${moduleId}.back`)"
        class="btn-me"
      />
      {{ t(`${moduleId}.title`, 2) }}
    </h3>
    <div class="d-flex justify-content-end">
      <slot />
    </div>
  </div>
</template>
