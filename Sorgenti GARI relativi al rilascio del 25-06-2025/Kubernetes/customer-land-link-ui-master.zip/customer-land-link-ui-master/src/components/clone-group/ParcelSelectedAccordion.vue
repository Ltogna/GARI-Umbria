<script setup lang="ts">
import useEmitter from "@/composables/useEmitter";
import useModuleId from "@/composables/useModuleId";
import { useCloneGroupStore } from "@/stores/cloneGroup";
import { useGroupsStore } from "@/stores/groups";
import BiAccordion from "@abaco/bootstrap-italia-components/src/components/BiAccordion/BiAccordion.vue";
import BiAlert from "@abaco/bootstrap-italia-components/src/components/BiAlert/BiAlert.vue";
import BiInput from "@abaco/bootstrap-italia-components/src/components/form/BiInput.vue";
import { getUUID } from "@abaco/bootstrap-italia-components/src/utilities";
import { onBeforeMount, onMounted, provide, reactive, ref } from "vue";
import { useI18n } from "vue-i18n";
import { useRouter } from "vue-router";
import ParcelTableSelected from "../common/ParcelTableSelected.vue";
import ParcelSelectedAccordionButtons from "../common/ParcelSelectedAccordionButtons.vue";
import { hideRemoveButtonKey } from "@/models/injectionSymbols";
import { RouteName } from "@/models/routes";

provide(hideRemoveButtonKey, true);

const { t } = useI18n();
const moduleId = useModuleId();
const router = useRouter();

const conductionPercentage = ref(100);

const cloneGroupStore = useCloneGroupStore();

const isOpen = ref(false);
const accordionId = `accordion-${getUUID()}`;

const disableButtons = ref(true);

const hasClickedFirstButton = ref(false);
const emitter = useEmitter();

onMounted(async () => {
  isOpen.value = true;

  emitter.on("set:conduction", () => {
    disableButtons.value = false;
  });
});

onBeforeMount(() => {
  emitter.off("set:conduction");
});

const errorCreateGroup = reactive<{
  isError: boolean;
  message: string;
}>({ isError: false, message: "" });

//TODO: add better validation
const percentageErrors = ref<string[]>([]);
const checkPercentageErrors = () => {
  if (
    conductionPercentage.value === null ||
    conductionPercentage.value === undefined
  ) {
    return [t(`${moduleId}.errors.fieldRequired`)];
  } else if (conductionPercentage.value > 100) {
    return [t(`${moduleId}.errors.high_percentage`)];
  }
  return [];
};

const onConfirmPercentage = () => {
  percentageErrors.value = checkPercentageErrors();
  if (percentageErrors.value.length === 0) {
    cloneGroupStore.conductionPercentage = conductionPercentage.value;
    emitter.emit("update:percentage", conductionPercentage.value);
  }
};

const onCloneGroup = async () => {
  if (percentageErrors.value.length > 0) return;

  await cloneGroupStore.cloneGroup();

  if (!cloneGroupStore.hasError && cloneGroupStore.partyId) {
    await useGroupsStore().searchGroups(cloneGroupStore.partyId);
    emitter.emit("is:dirty", false);
    router.push({ name: RouteName.GROUP });
  }
};
</script>

<template>
  <div :id="accordionId">
    <BiAccordion
      v-model="isOpen"
      :title="t(`${moduleId}.add_group.selected_parcels`, 2)"
    >
      <div v-if="cloneGroupStore.parcelsConducted.length > 0">
        <div class="row">
          <BiInput
            v-model="conductionPercentage"
            type="number"
            class="w-25"
            is-percentage
            hide-arrows
            :max="100"
            :default-return-if-not-value="'undefined'"
            :label="t(`${moduleId}.add_group.conduction_percentage`)"
            :placeholder="t(`${moduleId}.add_group.conduction_percentage`)"
            :errors="percentageErrors"
            @blur="onConfirmPercentage"
          ></BiInput>
        </div>

        <ParcelSelectedAccordionButtons
          hide-flush
          :disable-buttons="disableButtons"
          @create:group="onCloneGroup()"
        />
        <BiAlert
          v-if="errorCreateGroup.isError && hasClickedFirstButton"
          is-error
          :title="t(`${moduleId}.error`)"
        >
          <template #body v-if="errorCreateGroup.message">
            {{ errorCreateGroup.message }}
          </template>
        </BiAlert>

        <ParcelTableSelected
          :conducted-parcels-list="cloneGroupStore.parcelsConducted"
        />

        <ParcelSelectedAccordionButtons
          hide-flush
          :disable-buttons="disableButtons"
          @create:group="onCloneGroup()"
        />
        <BiAlert
          v-if="errorCreateGroup.isError && !hasClickedFirstButton"
          is-error
          :title="t(`${moduleId}.error`)"
        >
          <template #body v-if="errorCreateGroup.message">
            {{ errorCreateGroup.message }}
          </template>
        </BiAlert>
      </div>

      <BiAlert
        v-else-if="!cloneGroupStore.isLoading"
        :title="t(`${moduleId}.add_group.alert.select_a_parcel`)"
      >
      </BiAlert>
    </BiAccordion>
  </div>
</template>
