<script setup lang="ts">
import useGroup from "@/composables/useGroup";
import useModuleId from "@/composables/useModuleId";
import useParty from "@/composables/useParty";
import { useCloneGroupStore } from "@/stores/cloneGroup";
import BiAccordion from "@abaco/bootstrap-italia-components/src/components/BiAccordion/BiAccordion.vue";
import { useI18n } from "vue-i18n";
import ConductorForm from "./ConductorForm.vue";
import ParcelSelectedAccordion from "./ParcelSelectedAccordion.vue";
import { onMounted, watch } from "vue";
import usePermissions from "@/composables/usePermissions";
import { useRouter } from "vue-router";
import { RouteName } from "@/models/routes";

//TODO: better implementation
const { canWrite } = usePermissions();
const router = useRouter();
watch(
  () => canWrite,
  (canEnter) => {
    if (!canEnter) router.replace({ name: RouteName.GROUP });
  },
  { immediate: true },
);

const moduleId = useModuleId();
const { t } = useI18n();
const { partyId } = useParty();
const { groupId } = useGroup();
const cloneGroupStore = useCloneGroupStore();

onMounted(async () => {
  cloneGroupStore.setPartyId(+partyId.value);
  cloneGroupStore.setGroupId(+groupId.value);

  await cloneGroupStore.fetchGroup();
  await cloneGroupStore.fetchGroupParcels();
});
</script>

<template>
  <div class="card-body">
    <h4>
      {{ t(`${moduleId}.clone_group.clone_group`) }}
    </h4>
    <div class="mb-4">
      <ConductorForm />
    </div>

    <BiAccordion
      :title="t(`${moduleId}.add_group.search_parcels`, 2)"
      is-disabled
    />

    <ParcelSelectedAccordion />
  </div>
</template>
