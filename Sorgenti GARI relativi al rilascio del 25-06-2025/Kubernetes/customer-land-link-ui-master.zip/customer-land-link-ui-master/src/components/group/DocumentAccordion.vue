<script lang="ts" setup>
import useModuleId from "@/composables/useModuleId";
import { RouteName } from "@/models/routes";
import { useDocumentTypeStore } from "@/stores/documentTypes";
import { useEditGroupStore } from "@/stores/editGroup";
import BiAccordion from "@abaco/bootstrap-italia-components/src/components/BiAccordion/BiAccordion.vue";
import BiIcon from "@abaco/bootstrap-italia-components/src/components/BiIcon/BiIcon.vue";
import { onMounted } from "vue";
import { useI18n } from "vue-i18n";
import { useRoute } from "vue-router";

const moduleId = useModuleId();
const { t } = useI18n();
const editGroupStore = useEditGroupStore();
const documentTypeStore = useDocumentTypeStore();
const route = useRoute();

onMounted(async () => {
  const groupId = route.params.groupId as string;
  await documentTypeStore.getDocumentTypes(groupId);
});
</script>

<template>
  <BiAccordion
    v-if="documentTypeStore.documentTypes.length > 0"
    :model-value="true"
    color-bg-header="primary"
    color-header="white"
    body-extra-class="p-0"
    header-extra-class="d-block text-truncate"
  >
    <template #header>
      {{ t(`${moduleId}.document`, 2) }}
    </template>

    <div class="it-list-wrapper">
      <ul class="it-list border ps-3 pe-1 py-3">
        <li
          v-for="docType in documentTypeStore.documentTypes"
          :key="docType.definitionCode"
          class="customer-land-link__item-list"
        >
          <RouterLink
            :to="{
              name: RouteName.GROUP_EDIT_DOC,
              params: { docType: docType.definitionCode },
            }"
            replace
            v-if="
              editGroupStore.isEditable ||
              editGroupStore.isFuture ||
              (!editGroupStore.isEditable && docType.flDocPresent)
            "
            :class="'text-decoration-none d-flex align-items-center px-2 py-2 lh-sm'"
            :active-class="'fw-semibold text-black'"
          >
            <span>{{ docType.definitionCodeI18n }}</span>
            <BiIcon
              v-if="!docType.flDocPresent"
              class="ms-auto underline"
              :icon="'pen-circle'"
              :icon-style="'regular'"
              :color="'info'"
              size="lg"
            />
            <BiIcon
              v-else
              class="ms-auto underline"
              :icon="'circle-check'"
              :icon-style="'regular'"
              :color="'success'"
              size="lg"
            />
          </RouterLink>
          <span
            v-else
            :class="'text-decoration-none d-flex align-items-center px-2 py-2 lh-sm'"
          >
            <span>{{ docType.definitionCodeI18n }}</span>
            <BiIcon
              v-if="!docType.flDocPresent"
              class="ms-auto underline"
              :icon="'circle-xmark'"
              :icon-style="'regular'"
              :color="'info'"
              size="lg"
            />
            <BiIcon
              v-else
              class="ms-auto underline"
              :icon="'circle-check'"
              :icon-style="'regular'"
              :color="'success'"
              size="lg"
            />
          </span>
        </li>
      </ul>
    </div>
  </BiAccordion>
</template>
<style lang="scss" scoped>
.customer-land-link {
  &__item-list {
    a {
      &:hover {
        text-decoration-line: none !important;
        span {
          text-decoration-line: underline !important;
        }
      }
    }
  }
}
</style>
