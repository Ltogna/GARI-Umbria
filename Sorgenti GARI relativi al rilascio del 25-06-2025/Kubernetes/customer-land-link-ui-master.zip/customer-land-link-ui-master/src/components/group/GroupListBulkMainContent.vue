<script setup lang="ts">
import GroupListBulk from "@/components/group/GroupListBulk.vue";
import useModuleId from "@/composables/useModuleId";
import { useGroupsStore } from "@/stores/groups";
import { useTitleTypesStore } from "@/stores/titleTypes";
import BiButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiButton.vue";
import BiChip from "@abaco/bootstrap-italia-components/src/components/BiChip/BiChip.vue";
import { useI18n } from "vue-i18n";
import { useRoute, useRouter } from "vue-router";
import GroupBulkCloseForm from "./GroupBulkCloseForm.vue";
import { RouteName } from "@/models/routes";

const router = useRouter();
const route = useRoute();
const moduleId = useModuleId();
const i18nNS = `${moduleId}.group`;
const { t } = useI18n();
const groupsStore = useGroupsStore();
const titleTypesStore = useTitleTypesStore();

function filterGroupHandler() {
  router.replace({
    name: RouteName.GROUP_BULK_FILTER,
  });
}

function getTitleTypeI18n(titleTypeId: number) {
  const titleType = titleTypesStore.titleTypes.find(
    ({ id }) => id === titleTypeId,
  );

  return titleType?.i18nCode
    ? `${t(
        `${i18nNS}.form_select_title_type_id_label`,
      )}: ${titleType?.i18nCode}`
    : "";
}

function getDescription(descr: string) {
  return `${t(`${i18nNS}.form_descr_label`)}: ${descr}`;
}
async function removeTitleType() {
  const partyId = route.params.partyId as string;
  groupsStore.filters.titleTypeId = null;
  await groupsStore.searchGroups(+partyId, true);
}
async function removeDescription() {
  const partyId = route.params.partyId as string;
  groupsStore.filters.descr = null;
  await groupsStore.searchGroups(+partyId, true);
}
</script>

<template>
  <div class="card-body">
    <div class="row">
      <div class="col d-flex align-items-center">
        <span class="customer-land-link__session-title fw-bold">
          {{ t(`${i18nNS}.management_close`, 2) }}
        </span>
        <BiButton
          isOutlined
          color="primary"
          class="ms-auto"
          @click="filterGroupHandler"
        >
          {{ t(`${i18nNS}.filter_group`, 2) }}
        </BiButton>
      </div>
    </div>
    <div class="row mt-3">
      <div class="col">
        <BiChip
          isDelete
          v-if="groupsStore.filters.titleTypeId"
          :label="`${getTitleTypeI18n(groupsStore.filters.titleTypeId)}`"
          @click="removeTitleType"
        ></BiChip>
        <BiChip
          isDelete
          v-if="groupsStore.filters.descr"
          :label="getDescription(groupsStore.filters.descr)"
          @click="removeDescription"
        ></BiChip>
      </div>
    </div>
    <GroupBulkCloseForm />
    <div class="row mt-3">
      <GroupListBulk />
    </div>
  </div>
</template>
<style scoped lang="scss">
.customer-land-link {
  &__session-title {
    color: var(--bs-primary);
    font-size: 20px;
  }
}
</style>
