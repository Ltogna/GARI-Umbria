<script lang="ts" setup>
/* impors */
import useGroupBulkChecked from "@/composables/useGroupBulkChecked";
import useModuleId from "@/composables/useModuleId";
import useParty from "@/composables/useParty";
import useUserDateFormat from "@/composables/useUserDateFormat";
import randomUUID from "@/randomUUID";
import { useGroupsStore } from "@/stores/groups";
import BiAlert from "@abaco/bootstrap-italia-components/src/components/BiAlert/BiAlert.vue";
import BiButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiButton.vue";
import BiHiddenContent from "@abaco/bootstrap-italia-components/src/components/BiHiddenContent/BiHiddenContent.vue";
import BiTable from "@abaco/bootstrap-italia-components/src/components/BiTable/BiTable.vue";
import { format } from "date-fns";
import { computed } from "vue";
import { useI18n } from "vue-i18n";

const moduleId = useModuleId();
const i18nNS = `${moduleId}.group`;
const { t, n } = useI18n();
const groupsStore = useGroupsStore();
const { partyId } = useParty();
const { allChecked, isCheckboxIndeterminate } = useGroupBulkChecked();
const userDateFormat = useUserDateFormat();

function handleCheckAllGroups() {
  if (allChecked.value) {
    groupsStore.groups.forEach((l) => (l.checked = false));
  } else {
    groupsStore.groups.forEach((l) => (l.checked = true));
  }
}

async function loadMore() {
  await groupsStore.searchGroups(+partyId.value, true);
}

const idCheckAll = `check-all-${randomUUID()}`;

let isLoaded = false;
const isLoadedOnce = computed(() => {
  if (!groupsStore.loading) {
    isLoaded = true;
  }

  return isLoaded;
});
</script>

<template>
  <div class="col">
    <BiTable
      v-if="isLoadedOnce && groupsStore.groups.length > 0"
      is-custom
      responsive-breakpoint="md"
      is-header-light
    >
      <template v-slot:head>
        <tr>
          <th scope="col">
            <div class="form-check customer-land-link__table-selectable">
              <input
                type="checkbox"
                :id="idCheckAll"
                :checked="allChecked"
                :class="{
                  'semi-checked': isCheckboxIndeterminate,
                }"
                :indeterminate="isCheckboxIndeterminate"
                :disabled="!groupsStore.groups.length"
                @click="handleCheckAllGroups"
              />
              <label :for="idCheckAll">
                <BiHiddenContent :text="t(`${moduleId}.check_all`)" />
              </label>
            </div>
          </th>
          <th scope="col">
            {{ t(`${i18nNS}.list_conductions_title`) }}
          </th>
          <th scope="col">
            {{ t(`${i18nNS}.list_conductions_start_date`) }}
          </th>
          <th scope="col">
            {{ t(`${i18nNS}.list_conductions_end_date`) }}
          </th>
          <th scope="col">
            {{ t(`${i18nNS}.list_conductions_description`) }}
          </th>
          <th scope="col">
            {{ t(`${i18nNS}.list_conductions_count_parcels`, 2) }}
          </th>
        </tr>
      </template>
      <template v-if="groupsStore.groups.length > 0" #body>
        <tr v-for="group in groupsStore.groups" :key="group.id">
          <td :data-label="t(`${moduleId}.add_group.gis_area`)">
            <div class="form-check customer-land-link__table-selectable">
              <input
                :id="`checkbox-${group.id}`"
                type="checkbox"
                name="landLink"
                v-model="group.checked"
              />
              <label :for="`checkbox-${group.id}`">
                <BiHiddenContent
                  :text="t(`${moduleId}.check_all`)"
                ></BiHiddenContent
              ></label>
            </div>
          </td>
          <td :data-label="t(`${i18nNS}.list_conductions_title`) + ':'">
            {{ group.titleType?.i18nCode ?? "-" }}
          </td>
          <td :data-label="t(`${i18nNS}.list_conductions_start_date`) + ':'">
            {{ format(group.dayFrom, userDateFormat) }}
          </td>
          <td :data-label="t(`${i18nNS}.list_conductions_end_date`) + ':'">
            {{
              group.dayTo.getFullYear() !== 9999
                ? format(group.dayTo, userDateFormat)
                : "-"
            }}
          </td>
          <td :data-label="t(`${i18nNS}.list_conductions_description`) + ':'">
            {{ group.descr }}
          </td>
          <td
            :data-label="t(`${i18nNS}.list_conductions_count_parcels`, 2) + ':'"
          >
            {{ n(group.linkCount) }}
          </td>
        </tr>
        <tr v-if="groupsStore.nextKey">
          <td colspan="9999" class="text-center">
            <BiButton
              color="primary"
              is-outlined
              class="py-1 px-2"
              :is-disabled="groupsStore.loading"
              @click="loadMore"
            >
              {{ t(`${moduleId}.load_more`) }}
            </BiButton>
          </td>
        </tr>
      </template>
    </BiTable>

    <BiAlert
      v-if="!groupsStore.loading && groupsStore.groups.length === 0"
      isInfo
      class="mt-3"
      :title="t(`${i18nNS}.no_groups_found`)"
    />
  </div>
</template>
