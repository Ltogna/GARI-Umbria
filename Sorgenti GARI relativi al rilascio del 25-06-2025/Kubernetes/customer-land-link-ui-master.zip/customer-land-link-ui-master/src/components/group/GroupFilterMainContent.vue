<script setup lang="ts">
import BiButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiButton.vue";
import BiInput from "@abaco/bootstrap-italia-components/src/components/form/BiInput.vue";
import BiIcon from "@abaco/bootstrap-italia-components/src/components/BiIcon/BiIcon.vue";
import BiSelect from "@abaco/bootstrap-italia-components/src/components/form/BiSelect.vue";
import useModuleId from "@/composables/useModuleId";
import useParty from "@/composables/useParty";
import type { GroupFilterModel } from "@/models/groups";
import { useGroupsStore } from "@/stores/groups";
import { useTitleTypesStore } from "@/stores/titleTypes";
import type { SelectItem } from "@abaco/bootstrap-italia-components/src/models";
import isEqual from "lodash/isEqual";
import { computed, onMounted, reactive } from "vue";
import { useI18n } from "vue-i18n";
import { useRoute, useRouter } from "vue-router";
import { RouteName } from "@/models/routes";

const router = useRouter();
const route = useRoute();
const moduleId = useModuleId();
const titleTypesStore = useTitleTypesStore();
const i18nNS = `${moduleId}.group`;
const { partyId } = useParty();
const { t } = useI18n();
const groupsStore = useGroupsStore();

const isBulk = computed(() => route.name === RouteName.GROUP_BULK_FILTER);

type GroupFilterReactiveModel = {
  descr: string;
  titleTypeId: string;
  showElapsed: "true" | "false";
};
const formData = reactive<GroupFilterReactiveModel>({
  descr: "",
  titleTypeId: "",
  showElapsed: "true",
});

onMounted(async () => {
  try {
    await titleTypesStore.loadTitleTypes();
    formData.descr = groupsStore.filters.descr ?? "";
    formData.titleTypeId = groupsStore.filters.titleTypeId?.toString() ?? "";
    formData.showElapsed =
      (groupsStore.filters.showElapsed.toString() as "false") ?? "false";
  } catch (e) {
    // do somethings;
  }
});

const titleTypes = computed<SelectItem[]>(() => {
  return [
    { id: "", text: t(`${i18nNS}.form_select_title_type_id_ph`) },
    ...titleTypesStore.titleTypes.map(({ id, i18nCode }) => ({
      id: id.toString(),
      text: i18nCode,
    })),
  ];
});

async function submitHandler() {
  const values: GroupFilterModel = {
    descr: formData.descr ? formData.descr : null,
    titleTypeId: formData.titleTypeId ? Number(formData.titleTypeId) : null,
    showElapsed: isBulk.value ? false : formData.showElapsed === "true",
  };

  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const { nextKey: _0, ...rest } = groupsStore.filters;
  if (!isEqual(rest, values)) {
    groupsStore.filters = { ...values, nextKey: null };
    await groupsStore.searchGroups(+partyId.value);
  }

  backToList();
}

function resetHandler() {
  formData.descr = "";
  formData.titleTypeId = "";
}

async function backToList() {
  /**
   * Repeat search on back.
   *
   * XXX remove this if it wants to preserve list
   */
  const partyId = route.params.partyId;
  await groupsStore.searchGroups(+partyId, true);

  if (route.name === RouteName.GROUP_BULK_FILTER) {
    router.replace({
      name: RouteName.GROUP_BULK,
    });
  }
  if (route.name === RouteName.GROUP_FILTER) {
    router.replace({
      name: RouteName.GROUP,
    });
  }
}
</script>

<template>
  <div class="card-body">
    <form
      v-if="!titleTypesStore.loading"
      @submit.prevent="submitHandler"
      @reset.prevent="resetHandler"
    >
      <div class="row">
        <div class="col d-flex align-items-center">
          <span class="customer-land-link__session-title fw-bold">
            {{ t(`${i18nNS}.management_filter`, 2) }}
          </span>
        </div>
      </div>
      <div class="row mt-3">
        <div class="col-3">
          <BiSelect
            :label="t(`${i18nNS}.form_select_title_type_id_label`)"
            v-model="formData.titleTypeId"
            :items="titleTypes"
          />
        </div>
        <div class="col">
          <BiInput
            :label="t(`${i18nNS}.form_descr_label`)"
            :placeholder="t(`${i18nNS}.form_descr_ph`)"
            v-model="formData.descr"
          />
        </div>
        <div class="col-3" v-if="!isBulk">
          <BiSelect
            :label="t(`${i18nNS}.show_groups_label`)"
            v-model="formData.showElapsed"
            :items="[
              { id: 'false', text: t(`${i18nNS}.active`) },
              { id: 'true', text: t(`${i18nNS}.no_active`) },
            ]"
          />
        </div>
      </div>
      <div class="row mt-3">
        <div class="col d-flex justify-content-center">
          <BiButton
            type="button"
            color="primary"
            is-outlined
            class="me-2"
            @click="backToList"
          >
            <BiIcon icon-style="solid" icon="arrow-left" class="me-1" />
            {{ t(`${i18nNS}.form_search_back_to_list`) }}
          </BiButton>
          <BiButton type="reset" color="primary" is-outlined class="me-2">
            {{ t(`${i18nNS}.reset`) }}
          </BiButton>
          <BiButton type="submit" color="success">
            {{ t(`${i18nNS}.form_search_button`) }}
          </BiButton>
        </div>
      </div>
    </form>
  </div>
</template>
<style scoped lang="scss">
.customer-land-link {
  &__session-title {
    color: var(--bs-primary);
    font-size: 20px;
  }
}
</style>
