<script setup lang="ts">
import GroupList from "@/components/group/GroupList.vue";
import useModuleId from "@/composables/useModuleId";
import { RouteName } from "@/models/routes";
import { useGroupsStore } from "@/stores/groups";
import { useTitleTypesStore } from "@/stores/titleTypes";
import BiButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiButton.vue";
import BiChip from "@abaco/bootstrap-italia-components/src/components/BiChip/BiChip.vue";
import { useI18n } from "vue-i18n";
import { useRoute, useRouter } from "vue-router";
import { onBeforeUnmount } from "vue";

const router = useRouter();
const route = useRoute();
const moduleId = useModuleId();
const i18nNS = `${moduleId}.group`;
const { t } = useI18n();
const groupsStore = useGroupsStore();
const titleTypesStore = useTitleTypesStore();

function filterGroupHandler() {
  router.replace({
    name: RouteName.GROUP_FILTER,
  });
}

function getTitleTypeI18n(titleTypeId: number) {
  const titleType = titleTypesStore.titleTypes.find(
    ({ id }) => id === titleTypeId,
  );

  return titleType?.i18nCode
    ? `${t(
        `${i18nNS}.form_select_title_type_id_label`,
      )}: ${titleType?.i18nCode}`
    : "";
}

function getDescription(descr: string) {
  return `${t(`${i18nNS}.form_descr_label`)}: ${descr}`;
}
async function removeTitleType() {
  const partyId = route.params.partyId as string;
  groupsStore.filters.titleTypeId = null;
  await groupsStore.searchGroups(+partyId, true);
}
async function removeDescription() {
  const partyId = route.params.partyId as string;
  groupsStore.filters.descr = null;
  await groupsStore.searchGroups(+partyId, true);
}

onBeforeUnmount(() => {
  groupsStore.resetFilter();
});
</script>

<template>
  <div class="card-body">
    <div class="row">
      <div class="col d-flex align-items-center">
        <span class="customer-land-link__session-title fw-bold">
          {{ t(`${i18nNS}.management`, 2) }}
        </span>
        <BiButton
          isOutlined
          color="primary"
          class="ms-auto"
          @click="filterGroupHandler"
        >
          {{ t(`${i18nNS}.filter_group`, 2) }}
        </BiButton>
      </div>
    </div>
    <div class="row mt-3">
      <div class="col">
        <BiChip
          :key="'no_active'"
          v-if="groupsStore.filters.showElapsed"
          :label="t(`${i18nNS}.no_active`)"
        />
        <BiChip :key="'active'" v-else :label="t(`${i18nNS}.active`)" />
        <BiChip
          :key="'title'"
          isDelete
          v-if="groupsStore.filters.titleTypeId"
          :label="`${getTitleTypeI18n(groupsStore.filters.titleTypeId)}`"
          @click="removeTitleType"
        />
        <BiChip
          isDelete
          :key="'desc'"
          v-if="groupsStore.filters.descr"
          :label="getDescription(groupsStore.filters.descr)"
          @click="removeDescription"
        />
      </div>
    </div>
    <div class="row mt-3">
      <GroupList />
    </div>
  </div>
</template>
<style scoped lang="scss">
.customer-land-link {
  &__session-title {
    color: var(--bs-primary);
    font-size: 20px;
  }
}
</style>
