<script lang="ts" setup>
import useGroupBulkChecked from "@/composables/useGroupBulkChecked";
import useModuleId from "@/composables/useModuleId";
import useParty from "@/composables/useParty";
import { closeManyGroups } from "@/resources/api/groups";
import { useGroupsStore } from "@/stores/groups";
import { useNotificationStore } from "@/stores/notification";
import BiButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiButton.vue";
import BiDatepicker from "@abaco/bootstrap-italia-components/src/components/form/BiDatepicker.vue";
import { ErrorType } from "@abaco/safe-rest/src/HTTPClient";
import { computed, ref } from "vue";
import { useI18n } from "vue-i18n";
import { ZodError } from "zod";

const { t } = useI18n();
const moduleId = useModuleId();
const { hasSomeCheked, getCheckedIds } = useGroupBulkChecked();
const groupsStore = useGroupsStore();
const referenceDate = ref<string>();
const loading = ref(false);
const { partyId } = useParty();

const isDisabled = computed(() => {
  return loading.value || !hasSomeCheked.value || !referenceDate.value;
});

async function handleFormSubmit() {
  const dayTo = referenceDate.value ? Date.parse(referenceDate.value) : NaN;
  if (!isNaN(dayTo) && getCheckedIds.value.length) {
    loading.value = true;
    const resp = await closeManyGroups(+partyId.value, {
      dayTo,
      groupIds: getCheckedIds.value,
    });
    useNotificationStore().setMessage(resp);
    if (resp.errorType !== ErrorType.NONE) {
      if (resp.errorType === ErrorType.HTTP_STATUS) {
        console.warn(resp.response);
      } else {
        if (resp.err instanceof ZodError) {
          // TODO mettere una notification
          console.warn("ZOD", resp.err);
        } else {
          // TODO mettere una notification
          console.warn(resp.err);
        }
      }
    } else {
      await groupsStore.searchGroups(+partyId.value);
      referenceDate.value = undefined;
    }
    loading.value = false;
  } else {
    // TODO mettere una notification se la data non é valida!
    console.warn("errore");
  }
}
</script>

<template>
  <form @submit.prevent="handleFormSubmit" class="mt-3">
    <div class="row">
      <div class="col-3">
        <BiDatepicker
          :label="t(`${moduleId}.condution_end_date`)"
          v-model="referenceDate"
        />
      </div>
      <div class="col d-flex align-items-end">
        <BiButton
          type="submit"
          color="primary"
          is-outlined
          :is-disabled="isDisabled"
        >
          {{ t(`${moduleId}.setting_up`) }}
        </BiButton>
      </div>
    </div>
  </form>
</template>
