<script setup lang="ts">
import useModuleId from "@/composables/useModuleId";
import useParty from "@/composables/useParty";
import { RouteName } from "@/models/routes";
import { useGroupsStore } from "@/stores/groups";
import BiBackButton from "@abaco/bootstrap-italia-components/src/components/BiBackButton/BiBackButton.vue";
import { useI18n } from "vue-i18n";
import { useRoute, useRouter } from "vue-router";

const router = useRouter();
const route = useRoute();
const groupsStore = useGroupsStore();

const moduleId = useModuleId();
const { t } = useI18n();

/**
 * Repeat search on back.
 *
 * XXX remove this if it wants to preserve list
 */
const { partyId } = useParty();

async function backToList() {
  if (route.name === RouteName.GROUP_BULK_FILTER) {
    await groupsStore.searchGroups(+partyId.value, true);
    router.replace({
      name: RouteName.GROUP_BULK,
    });
  }
  if (route.name === RouteName.GROUP_FILTER) {
    await groupsStore.searchGroups(+partyId.value, true);
    router.replace({
      name: RouteName.GROUP,
    });
  }

  if (route.name === RouteName.GROUP_EDIT_DOC) {
    router.replace({
      name: RouteName.GROUP_EDIT,
    });
  }

  if (route.name === RouteName.GROUP_EDIT) {
    router.replace({
      name: RouteName.GROUP,
    });
  }

  if (route.name === RouteName.GROUP_EDIT_LANDLINK) {
    router.replace({
      name: RouteName.GROUP_EDIT,
    });
  }

  if (
    route.name === RouteName.GROUP_NEW_MULTIPLE_DOC ||
    route.name === RouteName.GROUP_EDIT_MULTIPLE_DOC
  ) {
    router.replace({
      name: RouteName.GROUP_EDIT_DOC,
    });
  }
  if (
    route.name === RouteName.GROUP_NEW_MULTIPLE_LANDLINK_INFO ||
    route.name === RouteName.GROUP_EDIT_MULTIPLE_LANDLINK_INFO
  ) {
    router.replace({
      name: RouteName.GROUP_EDIT_LANDLINK_INFO,
    });
  }
  if (route.name === RouteName.GROUP_EDIT_LANDLINK_INFO) {
    router.replace({
      name: RouteName.GROUP_EDIT_LANDLINK,
    });
  }
}
</script>

<template>
  <BiBackButton
    :visually-hidden-text="t(`${moduleId}.back`)"
    @click="backToList"
  />
</template>
