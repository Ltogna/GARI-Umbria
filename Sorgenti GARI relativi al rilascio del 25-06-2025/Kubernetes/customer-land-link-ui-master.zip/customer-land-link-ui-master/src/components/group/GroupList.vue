<script lang="ts" setup>
import useUserDateFormat from "@/composables/useUserDateFormat";
import useModuleId from "@/composables/useModuleId";
import useParty from "@/composables/useParty";
import usePermissions from "@/composables/usePermissions";
import { useGroupsStore } from "@/stores/groups";
import { isEditable } from "@/utils/isGroupEditable";
import BiAlert from "@abaco/bootstrap-italia-components/src/components/BiAlert/BiAlert.vue";
import BiButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiButton.vue";
import BiIconButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiIconButton.vue";
import BiTable from "@abaco/bootstrap-italia-components/src/components/BiTable/BiTable.vue";
import { format } from "date-fns";
import { useI18n } from "vue-i18n";
import { useRouter } from "vue-router";
import { RouteName } from "@/models/routes";
import BiHiddenContent from "@abaco/bootstrap-italia-components/src/components/BiHiddenContent/BiHiddenContent.vue";

const moduleId = useModuleId();
const i18nNS = `${moduleId}.group`;
const { t, n } = useI18n();
const groupsStore = useGroupsStore();
const { partyId } = useParty();
const router = useRouter();

const { canWrite } = usePermissions();
const userDateFormat = useUserDateFormat();

async function loadMore() {
  await groupsStore.searchGroups(+partyId.value, true);
}

const gotoEdit = (groupId: number) =>
  router.push({ name: RouteName.GROUP_EDIT, params: { groupId } });

const gotoClone = (groupId: number) =>
  router.push({ name: RouteName.GROUP_CLONE, params: { groupId } });
</script>

<template>
  <div class="col">
    <BiTable is-custom responsive-breakpoint="md" is-header-light>
      <template #head>
        <tr>
          <th scope="col">
            {{ t(`${i18nNS}.list_conductions_title`) }}
          </th>
          <th scope="col">
            {{ t(`${i18nNS}.list_conductions_start_date`) }}
          </th>
          <th scope="col">
            {{ t(`${i18nNS}.list_conductions_end_date`) }}
          </th>
          <th scope="col">
            {{ t(`${i18nNS}.list_conductions_description`) }}
          </th>
          <th scope="col">
            {{ t(`${i18nNS}.list_conductions_count_parcels`, 2) }}
          </th>
          <th scope="col">
            <BiHiddenContent :text="t(`${moduleId}.action`, 2)">
            </BiHiddenContent>
          </th>
        </tr>
      </template>
      <template v-if="groupsStore.groups.length > 0" #body>
        <tr v-for="group in groupsStore.groups" :key="group.id">
          <td :data-label="t(`${i18nNS}.list_conductions_title`) + ':'">
            {{ group.titleType?.i18nCode ?? "-" }}
          </td>
          <td :data-label="t(`${i18nNS}.list_conductions_start_date`) + ':'">
            {{ format(group.dayFrom, userDateFormat) }}
          </td>
          <td :data-label="t(`${i18nNS}.list_conductions_end_date`) + ':'">
            {{
              group.dayTo.getFullYear() !== 9999
                ? format(group.dayTo, userDateFormat)
                : "-"
            }}
          </td>
          <td :data-label="t(`${i18nNS}.list_conductions_description`) + ':'">
            {{ group.descr }}
          </td>
          <td
            :data-label="t(`${i18nNS}.list_conductions_count_parcels`, 2) + ':'"
          >
            {{ n(group.linkCount) }}
          </td>
          <td>
            <div class="d-flex flex-nowrap">
              <BiIconButton
                v-if="isEditable(group) && canWrite"
                class="me-2"
                is-outlined
                :icon="'pencil'"
                icon-style="fas"
                :color="'secondary'"
                :title="t(`${moduleId}.landLink_form.go_to_group`)"
                @click="gotoEdit(group.id)"
              />
              <BiIconButton
                v-if="!isEditable(group) && canWrite"
                class="me-2"
                is-outlined
                :title="t(`${moduleId}.goto_clone_group`)"
                :icon="'copy'"
                :color="'secondary'"
                @click="gotoClone(group.id)"
              />
              <BiIconButton
                v-if="!isEditable(group) || !canWrite"
                :title="t(`${moduleId}.landLink_form.go_to_group`)"
                :icon="'arrow-right'"
                icon-style="fas"
                :color="'secondary'"
                is-outlined
                @click="gotoEdit(group.id)"
              />
            </div>
          </td>
        </tr>
        <tr v-if="groupsStore.nextKey">
          <td colspan="9999" class="text-center">
            <BiButton
              color="primary"
              is-outlined
              class="py-1 px-2"
              :is-disabled="groupsStore.loading"
              @click="loadMore"
            >
              {{ t(`${moduleId}.load_more`) }}
            </BiButton>
          </td>
        </tr>
      </template>
    </BiTable>

    <BiAlert
      v-if="!groupsStore.loading && groupsStore.groups.length === 0"
      isInfo
      class="mt-3"
      :title="t(`${i18nNS}.no_groups_found`)"
    />
  </div>
</template>
