<script lang="ts" setup>
import useLandLinkId from "@/composables/useLandLinkId";
import useModuleId from "@/composables/useModuleId";
import { RouteName } from "@/models/routes";
import { useDocumentTypeStore } from "@/stores/documentTypes";
import { useLandLinksStore } from "@/stores/landLinks";
import BiAccordion from "@abaco/bootstrap-italia-components/src/components/BiAccordion/BiAccordion.vue";
import BiIcon from "@abaco/bootstrap-italia-components/src/components/BiIcon/BiIcon.vue";
import { computed, watch } from "vue";
import { useI18n } from "vue-i18n";
import { useRoute, type RouteLocationRaw } from "vue-router";

const moduleId = useModuleId();
const { t } = useI18n();
const documentTypeStore = useDocumentTypeStore();
const landLinkStore = useLandLinksStore();
const route = useRoute();
const { landlinkId } = useLandLinkId();

const isLandLinkRoute = computed(() => {
  return typeof landlinkId.value === "number";
});

watch(
  [() => landLinkStore.landLinkDetail, landlinkId],
  async ([landLink, landlinkId]) => {
    documentTypeStore.landLinkDocuments = [];
    if (
      landLink &&
      typeof landlinkId === "number" &&
      landLink.id === landlinkId
    ) {
      await documentTypeStore.getDocumentLandlinkTypes(landlinkId, false);
    }
  },
);

const hasDocument = computed(() => {
  return documentTypeStore.landLinkDocuments.length > 0;
});

const toLandLinkDoc = computed<(infoType: string) => RouteLocationRaw>(() => {
  // XXX Watch some strange behavior
  return (infoType: string) => {
    switch (route.name) {
      case RouteName.GROUP_EDIT_LANDLINK: {
        return {
          name: RouteName.GROUP_EDIT_LANDLINK_INFO,
          params: { infoType },
        };
      }
      case RouteName.LAND_LINK_DETAIL: {
        return {
          name: RouteName.LAND_LINK_INFO,
          params: { infoType },
        };
      }
      case RouteName.LAND_LINK_EDIT: {
        return {
          name: RouteName.LAND_LINK_INFO,
          params: { infoType },
        };
      }
      default: {
        return {
          name: RouteName.LAND_LINK_INFO,
          params: { infoType },
        };
      }
    }
  };
});
</script>

<template>
  <BiAccordion
    v-if="isLandLinkRoute && hasDocument"
    :model-value="true"
    color-bg-header="primary"
    color-header="white"
    body-extra-class="p-0"
    header-extra-class="d-block text-truncate"
  >
    <template #header>
      <span class="text-truncate">
        {{ t(`${moduleId}.additional_operations`).toUpperCase() }}
      </span>
    </template>

    <div class="it-list-wrapper">
      <ul class="it-list border ps-3 pe-1 py-3">
        <li
          v-for="docType in documentTypeStore.landLinkDocuments"
          :key="docType.definitionCode"
          class="customer-land-link__item-list"
        >
          <RouterLink
            :to="toLandLinkDoc(docType.definitionCode)"
            :class="'text-decoration-none d-flex align-items-center px-2 py-2 lh-sm'"
            :active-class="'fw-semibold text-black'"
          >
            <span>{{ docType.definitionCodeI18n }}</span>
            <BiIcon
              v-if="!docType.flDocPresent"
              class="ms-auto underline"
              :icon="'pen-circle'"
              :icon-style="'regular'"
              :color="'info'"
              size="lg"
            />
            <BiIcon
              v-else
              class="ms-auto underline"
              :icon="'circle-check'"
              :icon-style="'regular'"
              :color="'success'"
              size="lg"
            />
          </RouterLink>
        </li>
      </ul>
    </div>
  </BiAccordion>
</template>
<style lang="scss" scoped>
.customer-land-link {
  &__item-list {
    a {
      &:hover {
        text-decoration-line: none !important;
        span {
          text-decoration-line: underline !important;
        }
      }
    }
  }
}
</style>
