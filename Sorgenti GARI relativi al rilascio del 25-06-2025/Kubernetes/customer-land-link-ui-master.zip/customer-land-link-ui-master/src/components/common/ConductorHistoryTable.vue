<script setup lang="ts">
import useUserDateFormat from "@/composables/useUserDateFormat";
import useModuleId from "@/composables/useModuleId";
import { INFINITE_DATE } from "@/constants";
import type { LeadingModel } from "@/models/leadings";
import { dateToString } from "@/models/utils";
import { percNumberFormatOption } from "@/utils/area";
import BiTable from "@abaco/bootstrap-italia-components/src/components/BiTable/BiTable.vue";
import { format } from "date-fns";
import { useI18n } from "vue-i18n";
import { defineProps } from "vue";

defineProps<{ leadings: LeadingModel[] }>();

const { t, n } = useI18n();
const moduleId = useModuleId();
const userDateFormat = useUserDateFormat();

const getRealDayTo = (date: Date) => {
  const parsedDate = dateToString.safeParse(date);
  if (!parsedDate.success) {
    console.warn(parsedDate.error);
    return "-";
  }
  return parsedDate.data === INFINITE_DATE ? "-" : format(date, userDateFormat);
};

// const leadingIdentifier = (leading: LeadingModel) => {
//   if (leading.party.partyType === "N" && leading.party.taxCode) {
//     return leading.party.taxCode;
//   } else if (leading.party.partyType === "L" && leading.party.vatNumber) {
//     return leading.party.vatNumber;
//   }
//   return "";
// };
</script>

<template>
  <h6 class="fw-bold">{{ t(`${moduleId}.add_group.period_conductors`) }}</h6>
  <BiTable
    is-custom
    responsive-breakpoint="md"
    is-compact
    extra-table-classes="mb-0"
    extra-table-css="py-5"
  >
    <template #head>
      <tr>
        <th scope="col">{{ t(`${moduleId}.add_group.conductor`) }}</th>
        <th scope="col">{{ t(`${moduleId}.add_group.conduction`) }}</th>
        <th scope="col">{{ t(`${moduleId}.add_group.period`) }}</th>
      </tr>
    </template>
    <template #body>
      <tr v-for="leading in leadings" :key="leading.id">
        <td :data-label="t(`${moduleId}.add_group.conductor`)">
          <span v-if="leading.party.code">{{ leading.party.code }} -</span>
          {{ leading.party.lastName }}
          {{ leading.party.firstName }}
        </td>
        <td :data-label="t(`${moduleId}.add_group.conduction`)">
          {{ leading.titleType.i18nCode }}
          {{ n(leading.titleTypePerc, percNumberFormatOption) }}
          %
        </td>
        <td :data-label="t(`${moduleId}.add_group.period`)">
          <p class="mb-0">
            {{ format(leading.dayFrom, userDateFormat) }}
          </p>
          <p class="mb-0">
            {{ getRealDayTo(leading.dayTo) }}
          </p>
        </td>
      </tr>
    </template>
  </BiTable>
</template>
