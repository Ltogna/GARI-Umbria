<script setup lang="ts">
import useModuleId from "@/composables/useModuleId";
import type { AnomalyLevelModel } from "@/models/anomalyLevel";
import BiIcon from "@abaco/bootstrap-italia-components/src/components/BiIcon/BiIcon.vue";
import BiTooltip from "@abaco/bootstrap-italia-components/src/components/BiTooltip/BiTooltip.vue";
import type { ColorNamesType } from "@abaco/bootstrap-italia-components/src/models";
import { computed } from "vue";
import { useI18n } from "vue-i18n";
import { defineProps } from "vue";

interface IconType {
  name: string;
  color: ColorNamesType;
}

const moduleId = useModuleId();
const { t } = useI18n();

const props = defineProps<{
  maxAnomalyLevel: AnomalyLevelModel;
  countAnomalies: number;
}>();

const title = computed(
  () =>
    t(`${moduleId}.landLink_filter_form.anomalyLevel`) +
    `: ${props.countAnomalies}`,
);

const anomalyIcon = computed(() => {
  let iconType: IconType;
  switch (props.maxAnomalyLevel) {
    case "DANGER":
      iconType = { name: "minus-circle", color: "danger" };
      break;
    case "WARN":
      iconType = { name: "exclamation-triangle", color: "warning" };
      break;
    default:
      iconType = { name: "info-circle", color: "info" };
  }
  return iconType;
});
</script>

<template>
  <BiTooltip v-if="countAnomalies > 0" :title="title">
    <BiIcon
      class="ms-1"
      :icon="anomalyIcon.name"
      :color="anomalyIcon.color"
      size="sm"
    />
  </BiTooltip>
</template>
