<script setup lang="ts">
import useModuleId from "@/composables/useModuleId";
import { useI18n } from "vue-i18n";
import BiButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiButton.vue";
import { defineProps, defineEmits, withDefaults } from "vue";

withDefaults(
  defineProps<{
    disableButtons?: boolean;
    hideFlush?: boolean;
  }>(),
  { disableButtons: false, hideFlush: false },
);

const emits = defineEmits<{
  (e: "create:group"): void;
  (e: "flush:group"): void;
}>();

const { t } = useI18n();
const moduleId = useModuleId();
</script>

<template>
  <div class="row py-4">
    <div class="col-md-12 text-center">
      <BiButton
        v-if="!hideFlush"
        color="secondary"
        is-outlined
        type="reset"
        class="me-2"
        :is-disabled="disableButtons"
        @click="emits('flush:group')"
      >
        {{ t(`${moduleId}.add_group.empty`) }}
      </BiButton>
      <BiButton
        color="success"
        type="submit"
        :is-disabled="disableButtons"
        @click="emits('create:group')"
      >
        {{ t(`${moduleId}.add_group.confirm`) }}
      </BiButton>
    </div>
  </div>
</template>
