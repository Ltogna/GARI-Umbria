<script setup lang="ts">
import BiTable from "@abaco/bootstrap-italia-components/src/components/BiTable/BiTable.vue";
import ParcelTableSelectedRow from "./ParcelTableSelectedRow.vue";
import { useI18n } from "vue-i18n";
import { defineProps } from "vue";
import useModuleId from "@/composables/useModuleId";
import type { ParcelConductedModel } from "@/models/parcel";
import BiHiddenContent from "@abaco/bootstrap-italia-components/src/components/BiHiddenContent/BiHiddenContent.vue";

defineProps<{
  conductedParcelsList: ParcelConductedModel[];
}>();

const { t } = useI18n();
const moduleId = useModuleId();
</script>

<template>
  <div>
    <h6 class="fw-bold">
      {{ t(`${moduleId}.add_group.displayed_rec`) }}:
      {{ conductedParcelsList.length }}
    </h6>
    <BiTable is-custom responsive-breakpoint="md">
      <template #head>
        <tr class="bg-light">
          <th scope="col">
            {{ t(`${moduleId}.add_group.sheet_references`) }}
          </th>
          <th scope="col">{{ t(`${moduleId}.add_group.gis_area`) }}</th>
          <th scope="col">{{ t(`${moduleId}.add_group.conducted_area`) }}</th>
          <th scope="col">
            {{ t(`${moduleId}.add_group.period_conductors`) }}
          </th>
          <th scope="col">
            <BiHiddenContent :text="t(`${moduleId}.conductor`, 2)">
            </BiHiddenContent>
          </th>
          <th scope="col">
            <BiHiddenContent :text="t(`${moduleId}.action`, 2)">
            </BiHiddenContent>
          </th>
        </tr>
      </template>
      <template #body>
        <ParcelTableSelectedRow
          v-for="(parcelConducted, index) in conductedParcelsList"
          :key="`parcelConducted-${index}`"
          :id="index"
          :conducted-parcel="parcelConducted"
        />
      </template>
    </BiTable>
  </div>
</template>
