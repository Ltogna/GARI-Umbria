<script setup lang="ts">
import useEmitter from "@/composables/useEmitter";
import useModuleId from "@/composables/useModuleId";
import { hideRemoveButtonKey } from "@/models/injectionSymbols";
import type { ParcelConductedModel } from "@/models/parcel";
import { convertAreaSQMInHA, intlNumberFormatOptions } from "@/utils/area";
import { formattedLeadingsList } from "@/utils/formattedLeadingsList";
import { getSheetReference } from "@/utils/getSheetReference";
import { gotoViewer } from "@/utils/gotoViewer";
import BiAlert from "@abaco/bootstrap-italia-components/src/components/BiAlert/BiAlert.vue";
import BiIconButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiIconButton.vue";
import BiCollapse from "@abaco/bootstrap-italia-components/src/components/BiCollapse/BiCollapse.vue";
import BiIcon from "@abaco/bootstrap-italia-components/src/components/BiIcon/BiIcon.vue";
import {
  computed,
  inject,
  onBeforeUnmount,
  onMounted,
  ref,
  watch,
  defineProps,
} from "vue";
import { useI18n } from "vue-i18n";
import ConductorHistoryTable from "../common/ConductorHistoryTable.vue";

const props = defineProps<{
  conductedParcel: ParcelConductedModel;
  id: number;
}>();

const hideRemoveButton = inject<boolean>(hideRemoveButtonKey);
const basePath = inject<string>("basePath", import.meta.env.BASE_URL);

const emitter = useEmitter();

const moduleId = useModuleId();
const { t, n } = useI18n();

const removeSelectedParcel = (id: number) => {
  emitter.emit("delete:parcel", id);
};

const isCollapsed = ref(false);
const hasDetails = ref(false);
const conductionPercentage = ref(100);

onMounted(() => {
  emitter.on("update:percentage", (percentage) => {
    conductionPercentage.value = percentage;
  });
});

onBeforeUnmount(() => {
  emitter.off("update:percentage");
});

watch(
  () => isCollapsed.value,
  (isCollapsed) => {
    if (isCollapsed) {
      hasDetails.value = true;
    }
  },
);

const conductedAreaSqm = computed(() => {
  const areaTot = props.conductedParcel.parcel.areaSqm ?? 0;

  return (conductionPercentage.value * areaTot) / 100;
});
</script>

<template>
  <tr>
    <td
      :data-label="t(`${moduleId}.add_group.sheet_references`)"
      class="text-break max-w-xs"
    >
      {{ getSheetReference(conductedParcel.parcel, true) }}
    </td>
    <td :data-label="t(`${moduleId}.add_group.gis_area`)">
      {{
        n(
          convertAreaSQMInHA(conductedParcel.parcel.areaSqm ?? 0),
          intlNumberFormatOptions,
        )
      }}
    </td>
    <td :data-label="t(`${moduleId}.add_group.conducted_area`)">
      {{ n(convertAreaSQMInHA(conductedAreaSqm), intlNumberFormatOptions) }}
    </td>
    <td :data-label="t(`${moduleId}.add_group.period_conductors`)">
      {{ formattedLeadingsList(conductedParcel.leadings) }}
    </td>
    <td>
      <BiCollapse
        tag="span"
        :target-selector="`#collapse-${id}`"
        v-model="isCollapsed"
      >
        <BiIcon
          icon="chevron-down"
          style="cursor: pointer"
          :class="isCollapsed ? 'collapse-icon' : undefined"
        />
      </BiCollapse>
    </td>
    <td>
      <div class="d-flex flex-nowrap">
        <BiIconButton
          :title="t(`${moduleId}.open_viewer`)"
          v-if="(conductedParcel.parcel.areaSqm ?? 0) > 0"
          icon="map-marked-alt"
          class="me-2"
          icon-style="fas"
          color="info"
          is-outlined
          @click="gotoViewer(conductedParcel.parcel.id, basePath)"
        />
        <BiIconButton
          v-if="!hideRemoveButton"
          :title="t(`${moduleId}.delete`)"
          icon="trash-can"
          color="danger"
          icon-style="fas"
          is-outlined
          is-icon
          @click="removeSelectedParcel(id)"
        />
      </div>
    </td>
  </tr>
  <tr>
    <td class="p-0" colspan="99999">
      <div :id="`collapse-${id}`">
        <div class="accordion-body px-5 py-5">
          <ConductorHistoryTable
            v-if="conductedParcel.leadings.length > 0"
            :leadings="conductedParcel.leadings"
          />

          <BiAlert
            v-else
            :title="t(`${moduleId}.add_group.alert.no_conductor_found`)"
          ></BiAlert>
        </div>
      </div>
    </td>
  </tr>
</template>

<style scoped lang="scss">
.collapse-icon {
  transform: rotate(-180deg);
}
</style>
