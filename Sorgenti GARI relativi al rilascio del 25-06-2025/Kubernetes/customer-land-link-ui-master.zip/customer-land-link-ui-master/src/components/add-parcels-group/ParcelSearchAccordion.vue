<script setup lang="ts">
import useEmitter from "@/composables/useEmitter";
import useForm from "@/composables/useForm";
import useModuleId from "@/composables/useModuleId";
import type { ParcelSearchFieldsModel } from "@/models/groupFilter";
import {
  getBlocksList,
  // getBlocksSector,
  getSectorsList,
} from "@/resources/api/parcels";
import { useAddParcelsGroupStore } from "@/stores/addParcelsGroup";
import { DEFAULT_PARCEL_FILTER } from "@/utils/defaultValues";
import { getFieldSelector } from "@/utils/formUtils";
import BiAccordion from "@abaco/bootstrap-italia-components/src/components/BiAccordion/BiAccordion.vue";
import BiAlert from "@abaco/bootstrap-italia-components/src/components/BiAlert/BiAlert.vue";
import BiButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiButton.vue";
import BiInput from "@abaco/bootstrap-italia-components/src/components/form/BiInput.vue";
import { getUUID } from "@abaco/bootstrap-italia-components/src/utilities";
import { ErrorType } from "@abaco/safe-rest/src/HTTPClient";
import JustValidate, { type FieldRuleInterface } from "just-validate";
import { debounce } from "lodash";
import {
  onBeforeUnmount,
  onMounted,
  reactive,
  ref,
  watch,
  computed,
} from "vue";
import { useI18n } from "vue-i18n";
import BiTextInput from "../BiTextInput.vue";
import parcelSearchFormValidatorConfig from "../add-group/parcelSearchFormValidatorConfig";
import ParcelsTableSelectable from "./ParcelsTableSelectable.vue";
import BiAutocompleteNext from "@abaco/bootstrap-italia-components/src/components/form/BiAutocompleteNext.vue";

const { t } = useI18n();
const moduleId = useModuleId();
const emitter = useEmitter();

const isOpen = ref(true);
const hasSearched = ref(false);

type BlockType = { id: number; description: string };
type SectorType = BlockType & { code: string };
const sectorFilter = ref<SectorType | null>(null);
const blockFilter = ref<BlockType | null>(null);
const blockItems = ref<BlockType[]>([]);
const sectorItems = ref<SectorType[]>([]);

const formData = reactive<ParcelSearchFieldsModel>(
  structuredClone(DEFAULT_PARCEL_FILTER),
);
const formId = `form-${getUUID()}`;
const formRef = ref<HTMLFormElement>();

const { validate, onValidate, onSubmit, onReset } = useForm(
  submitCallback,
  formData,
  formId,
);

onMounted(() => {
  if (formRef.value) {
    validate.value = parcelSearchFormValidatorConfig(
      t,
      moduleId,
      formRef.value,
    );
  }

  emitter.on("add:selected:parcels", () => {
    hasSearched.value = false;
    if (addParcelsGroupStore.hasConductedParcelsSelected) {
      isOpen.value = false;
    }
  });
});

onBeforeUnmount(() => {
  emitter.off("add:selected:parcels");
});

const addParcelsGroupStore = useAddParcelsGroupStore();

async function submitCallback() {
  /**
   * TODO: CUAA or sector code always present
   */

  addParcelsGroupStore.parcelFilter = formData;
  await addParcelsGroupStore.loadFilteredParcels();
  hasSearched.value = true;
}

const onResetForm = () => {
  Object.assign(formData, DEFAULT_PARCEL_FILTER);
  // formDataCityText.value = "";
  hasSearched.value = false;
  sectorFilter.value = null;
  blockFilter.value = null;
  onReset(DEFAULT_PARCEL_FILTER);
};

const onSubmitForm = () => {
  const clearField = (fieldId: string) => {
    (validate.value as JustValidate).removeField(
      getFieldSelector(formId, fieldId),
    );
  };

  const addRequiredField = (fieldId: string) => {
    (validate.value as JustValidate).addField(
      getFieldSelector(formId, fieldId),
      [
        {
          rule: "required",
          errorMessage: t(`${moduleId}.errors.fieldRequired`),
        } as FieldRuleInterface,
      ],
    );
  };

  formData.sectorCode = sectorFilter.value?.code;
  formData.blockCode = blockFilter.value?.description;

  (validate.value as JustValidate).clearErrors();

  // const parcelSectorCode = getFieldSelector(formId, "sectorCode");
  // const parcelBlockCode = getFieldSelector(formId, "blockCode");
  const parcelCodeDescriptor = getFieldSelector(formId, "parcelCode");
  const hasParcelDescriptor = (validate.value as JustValidate).fieldIds.has(
    parcelCodeDescriptor,
  );

  if (!formData.partyCode) {
    addRequiredField("sectorCode");
    addRequiredField("blockCode");
  } else {
    clearField("sectorCode");
    clearField("blockCode");
  }

  if (formData.sectorCode !== undefined || sectorFilter.value !== null) {
    clearField("sectorCode");
  }
  if (formData.blockCode !== undefined || blockFilter.value !== null) {
    clearField("blockCode");
  }

  if (formData.subParcelCode && !formData.parcelCode) {
    addRequiredField("parcelCode");
  } else if (hasParcelDescriptor) {
    clearField("parcelCode");
  } else {
    (validate.value as JustValidate).clearFieldLabel(parcelCodeDescriptor);
  }

  onSubmit();
};

async function fetchSectorList(filter?: string) {
  if (filter) {
    const response = await getSectorsList(filter);
    if (response.errorType !== ErrorType.NONE) {
      console.warn(response);
      // await setErrorMessage(response);
      return [];
    } else {
      const data = response.data.map((sector) => {
        return {
          id: sector.id as number,
          description: sector.shortDescr || "",
          code: sector.sectorCode as string,
        } as SectorType;
      });

      const current = sectorFilter.value;
      if (current) {
        if (!data.find((d) => d.id === current.id)) {
          data.splice(0, 0, current);
        }
      }
      sectorItems.value = data;

      const found = sectorItems.value.find(
        (e) => e.description.search(new RegExp(filter, "ig")) >= 0,
      );

      if (found) {
        sectorFilter.value = found;
        return;
      }
      if (data.length === 1) {
        sectorFilter.value = data[0];
        return;
      }

      return sectorItems.value;
    }
  }
}

const debouncedFetchSectorList = debounce(fetchSectorList, 350);

async function getBlockList(filter?: string) {
  const sectorCode = sectorFilter.value?.code;
  if (!sectorCode) return [];

  const response = await getBlocksList(sectorCode, filter);

  if (response.errorType !== ErrorType.NONE) {
    console.warn(response);
    // setErrorMessage(response);
    return [];
  } else {
    return response.data.map((block) => {
      return { id: block.id, description: block.description };
    });
  }
}
const debouncedLoadBlocks = debounce(async (val: string) => {
  const results = await getBlockList(val);
  blockItems.value = results;

  /// #121041 improved search form
  const found = results.find((e) => e.description === val);
  if (found) {
    blockFilter.value = found;
    return;
  }
  if (results.length === 1) {
    blockFilter.value = results[0];
    return;
  }
}, 350);

async function onLoadBlocks(val = "") {
  await debouncedLoadBlocks(val);
}

watch(
  () => sectorFilter.value,
  async (newSectorFilter, oldSectorFilter) => {
    if (newSectorFilter?.id !== oldSectorFilter?.id) {
      blockFilter.value = null;
      blockItems.value = [];
      await onLoadBlocks();
    }
  },
);

const isSearchButtonDisabled = computed(() => {
  return !(sectorFilter.value && blockFilter.value) && !formData.partyCode;
});
</script>

<template>
  <BiAccordion
    v-model="isOpen"
    :title="t(`${moduleId}.add_group.search_parcels`, 2)"
  >
    <form
      @submit.prevent="onSubmitForm"
      @reset.prevent="onResetForm"
      ref="formRef"
      :id="formId"
      class="needs-validation customer-land-link__landLink-search-form"
      autocomplete="off"
    >
      <div class="row">
        <div class="col-md-2">
          <BiInput
            type="search"
            v-model="formData.partyCode"
            :label="t(`${moduleId}.add_group.cuaa`)"
            :placeholder="t(`${moduleId}.add_group.cuaa`)"
          ></BiInput>
        </div>
        <div
          class="col-md-4"
          :class="{ 'field-required': !formData.partyCode }"
        >
          <!-- <BiInput
            v-model="formData.sectorCode"
            v-model:text="formDataCityText"
            :items="sectorList"
            :label="t(`${moduleId}.add_group.city`)"
            :placeholder="t(`${moduleId}.add_group.city`)"
            item-title="shortDescr"
            item-value="sectorCode"
            strict
            seamless
          /> -->
          <BiAutocompleteNext
            v-model="sectorFilter"
            name="sectorCode"
            :item-title="'description'"
            :item-value="'id'"
            :items="sectorItems"
            :label="t(`${moduleId}.city`)"
            :placeholder="`${t(`${moduleId}.add_group.city`)}`"
            @search-change="debouncedFetchSectorList"
            :internal-search="false"
            :label-no-result="`${t(`${moduleId}.errors.no_results`)}`"
            :show-no-options="false"
            :allow-empty="false"
            :min-search-lenght="1"
            :label-no-items="`${t(`${moduleId}.errors.list_empty`)}`"
            @validate="onValidate"
          />
        </div>
        <div
          class="col-md-2"
          :class="{ 'field-required': !formData.partyCode }"
        >
          <!-- <BiInput
            type="search"
            v-model="formData.blockCode"
            :label="t(`${moduleId}.add_group.sheet`)"
            :placeholder="t(`${moduleId}.add_group.sheet`)"
          ></BiInput> -->
          <BiAutocompleteNext
            v-model="blockFilter"
            :item-title="'description'"
            :item-value="'id'"
            name="blockCode"
            :items="blockItems"
            :label="t(`${moduleId}.add_group.sheet`)"
            :placeholder="`${t(`${moduleId}.add_group.sheet`)}`"
            :disabled="!sectorFilter"
            :label-no-result="`${t(`${moduleId}.errors.no_results`)}`"
            @search-change="onLoadBlocks"
            :min-search-lenght="1"
            :internal-search="false"
            :allow-empty="false"
            :label-no-items="`${t(`${moduleId}.errors.list_empty`)}`"
          />
        </div>
        <div class="col-md-2">
          <BiTextInput
            :id="getUUID()"
            name="parcelCode"
            type="search"
            v-model="formData.parcelCode"
            :label="t(`${moduleId}.add_group.parcel`)"
            :placeholder="t(`${moduleId}.add_group.parcel_code`, 2)"
            @validate="onValidate"
          ></BiTextInput>
        </div>
        <div class="col-md-2">
          <BiTextInput
            :id="getUUID()"
            name="subParcelCode"
            type="search"
            v-model="formData.subParcelCode"
            :label="t(`${moduleId}.add_group.subordinate`)"
            :placeholder="t(`${moduleId}.add_group.subordinate`)"
            @validate="onValidate"
          ></BiTextInput>
        </div>
      </div>
      <div class="row pt-4">
        <div class="col-md-12 text-center">
          <BiButton color="secondary" is-outlined type="reset" class="me-2">
            {{ t(`${moduleId}.add_group.cancel`) }}
          </BiButton>
          <BiButton
            color="success"
            type="submit"
            :is-disabled="
              addParcelsGroupStore.isLoading || isSearchButtonDisabled
            "
          >
            {{ t(`${moduleId}.add_group.search`) }}
          </BiButton>
        </div>
      </div>
    </form>

    <div
      v-if="hasSearched && addParcelsGroupStore.hasConductedParcels"
      class="mt-4"
    >
      <ParcelsTableSelectable />
    </div>

    <div
      v-else-if="
        hasSearched &&
        !addParcelsGroupStore.isLoading &&
        !addParcelsGroupStore.hasConductedParcels
      "
      class="mt-2"
    >
      <BiAlert>
        <template #body>
          {{ t(`${moduleId}.add_group.alert.no_parcel_found`) }}
        </template>
      </BiAlert>
    </div>
  </BiAccordion>
</template>

<style lang="scss">
.customer-land-link__landLink-search-form {
  .multiselect {
    padding: 0 !important;
    padding-left: 4px !important;
    padding-right: 4px !important;
    margin: 0 !important;
    &:not(&--active) {
      .multiselect__tags {
        padding-top: 8px;
      }
    }
    &__single {
      text-overflow: ellipsis;
      white-space: nowrap;
    }
    &__input {
      padding: 0 !important;
    }
    input[type="text"].just-validate-success-field {
      background: none;
    }
  }
}
</style>
