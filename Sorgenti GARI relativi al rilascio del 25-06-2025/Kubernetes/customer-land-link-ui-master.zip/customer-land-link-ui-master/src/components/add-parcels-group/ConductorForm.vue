<script setup lang="ts">
import useModuleId from "@/composables/useModuleId";
import { INFINITE_DATE } from "@/constants";
import type { ConductorFieldsModel } from "@/models/groupFilter";
import { dateToString } from "@/models/utils";
import { useAddParcelsGroupStore } from "@/stores/addParcelsGroup";
import BiAlert from "@abaco/bootstrap-italia-components/src/components/BiAlert/BiAlert.vue";
import BiDatepicker from "@abaco/bootstrap-italia-components/src/components/form/BiDatepicker.vue";
import BiInput from "@abaco/bootstrap-italia-components/src/components/form/BiInput.vue";
import BiSelect from "@abaco/bootstrap-italia-components/src/components/form/BiSelect.vue";
import type { SelectItem } from "@abaco/bootstrap-italia-components/src/models";
import { onMounted, reactive, ref } from "vue";
import { useI18n } from "vue-i18n";

const { t } = useI18n();
const moduleId = useModuleId();
const addParcelsGroupStore = useAddParcelsGroupStore();

const conductionTitleTypesItems = ref<SelectItem[]>([]);

const formData = reactive<ConductorFieldsModel>({} as ConductorFieldsModel);

onMounted(async () => {
  await addParcelsGroupStore.fetchGroup();
  if (!addParcelsGroupStore.hasError && addParcelsGroupStore.group) {
    const { dayFrom, dayTo, titleType, descr } = addParcelsGroupStore.group;

    conductionTitleTypesItems.value.push({
      id: titleType.id.toString(),
      text: titleType.i18nCode,
      selected: true,
    });

    Object.assign(formData, {
      dayFrom,
      dayTo: dateToString.parse(dayTo) !== INFINITE_DATE ? dayTo : undefined,
      titleTypeId: titleType.id.toString(),
      description: descr,
    } as ConductorFieldsModel);
  }
});
</script>

<template>
  <BiAlert
    v-if="addParcelsGroupStore.hasError"
    is-error
    :title="t(`${moduleId}.error`)"
  />

  <div
    class="row customer-land-link__landLink-search-form needs-validation pt-3"
  >
    <div class="col-md-3">
      <BiSelect
        :model-value="formData.titleTypeId"
        :items="conductionTitleTypesItems"
        name="titleTypeId"
        class="field-required"
        :label="t(`${moduleId}.add_group.conduction_title`)"
        disabled
      ></BiSelect>
    </div>
    <div class="col-md-3">
      <BiDatepicker
        :model-value="formData.dayFrom"
        class="field-required"
        :label="t(`${moduleId}.add_group.conduction_start`)"
        is-disabled
      ></BiDatepicker>
    </div>
    <div class="col-md-3">
      <!-- TODO: props min not reactive -->
      <BiDatepicker
        :model-value="formData.dayTo"
        :label="t(`${moduleId}.add_group.conduction_end`)"
        is-disabled
      ></BiDatepicker>
    </div>
    <div class="col-md-3">
      <BiInput
        :model-value="formData.description"
        :label="t(`${moduleId}.add_group.description`)"
        :placeholder="t(`${moduleId}.add_group.group_description`)"
        disabled
      ></BiInput>
    </div>
  </div>
</template>
