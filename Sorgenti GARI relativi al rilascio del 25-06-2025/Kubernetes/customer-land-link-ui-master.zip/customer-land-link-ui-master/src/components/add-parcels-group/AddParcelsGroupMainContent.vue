<script setup lang="ts">
import useGroup from "@/composables/useGroup";
import useModuleId from "@/composables/useModuleId";
import useParty from "@/composables/useParty";
import usePermissions from "@/composables/usePermissions";
import { useAddParcelsGroupStore } from "@/stores/addParcelsGroup";
import { watch } from "vue";
import { useI18n } from "vue-i18n";
import { useRouter } from "vue-router";
import ConductorForm from "./ConductorForm.vue";
import ParcelSearchAccordion from "./ParcelSearchAccordion.vue";
import ParcelSelectedAccordion from "./ParcelSelectedAccordion.vue";
import { RouteName } from "@/models/routes";

//TODO: better implementation
const { canWrite } = usePermissions();
const router = useRouter();
watch(
  () => canWrite,
  (canEnter) => {
    if (!canEnter) router.replace({ name: RouteName.GROUP });
  },
  { immediate: true },
);

const moduleId = useModuleId();
const { t } = useI18n();
const { partyId } = useParty();
const { groupId } = useGroup();

useAddParcelsGroupStore().setPartyId(+partyId.value);
useAddParcelsGroupStore().setGroupId(+groupId.value);
</script>

<template>
  <div class="card-body">
    <div
      class="customer-land-link__page-title d-flex justify-content-between align-items-center mb-3"
    >
      <h4 class="customer-land-link__page-title--text">
        {{ t(`${moduleId}.add_parcel`, 2) }}
      </h4>
    </div>
    <div class="mb-4">
      <ConductorForm />
    </div>
    <ParcelSearchAccordion />
    <ParcelSelectedAccordion />
  </div>
</template>
