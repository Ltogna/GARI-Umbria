<script setup lang="ts">
import useModuleId from "@/composables/useModuleId";
import { useNotificationStore } from "@/stores/notification";
import BiNotification from "@abaco/bootstrap-italia-components/src/components/BiNotification/BiNotification.vue";
import { computed } from "vue";
import { useI18n } from "vue-i18n";

const { t } = useI18n();
const moduleId = useModuleId();

const notificationStore = useNotificationStore();
const showNotification = computed(() => !!notificationStore.message);
const onCloseNotification = (value: boolean) => {
  if (!value) notificationStore.$reset();
};
</script>

<template>
  <BiNotification
    :model-value="showNotification"
    :title="
      notificationStore.isError
        ? t(`${moduleId}.error`)
        : notificationStore.message
    "
    @update:model-value="(value: boolean) => onCloseNotification(value)"
    :variant="notificationStore.isError ? 'error' : 'success'"
    :text="notificationStore.isError ? notificationStore.message : undefined"
    :icon="notificationStore.isError ? 'circle-xmark' : 'circle-check'"
    is-dismissible
    class="customer-land-link__root-notification"
  ></BiNotification>
</template>

<style lang="scss">
.customer-land-link {
  &__root-notification {
    z-index: calc(var(--bs-z-index-modal, 1020) + 1) !important;
  }
}
</style>
