<script setup lang="ts">
import { type FormFieldEmits, useFormField } from "@/composables/useFormField";
import BiInput from "@abaco/bootstrap-italia-components/src/components/form/BiInput.vue";
import { ref, watch, defineProps, defineEmits, withDefaults } from "vue";
import type { InputType } from "@abaco/bootstrap-italia-components/src/models";

export interface TextInputProps {
  id: string;
  name: string;
  modelValue?: string | number;
  isDisabled?: boolean;
  isReadonly?: boolean;
  info?: string;
  label?: string;
  extraClasses?: string[];
  required?: boolean;
  validatorFn?: (id: string, value?: string) => Promise<boolean | string[]>;
  formatFn?: (value: unknown) => string;
  placeholder?: string;

  /**
   * [UI] Help text that explain what to insert in the input
   */
  helpText?: string;

  /**
   * [NATIVE] If input is disabled (greyed out and readonly)
   */
  disabled?: boolean;

  /**
   * [NATIVE] Readonly, not editable
   */
  readonly?: boolean | "normalized";

  /**
   * [UI] Show reset value button
   */
  showReset?: boolean;

  /**
   * [NATIVE]
   */
  type?: InputType;

  /**
   * [type number ONLY]
   */
  isCurrency?: boolean;

  /**
   * [type number ONLY]
   */
  isPercentage?: boolean;

  /**
   * [type number ONLY]
   */
  isAdaptive?: boolean;

  /**
   * [type number ONLY]
   */
  dataDigits?: number;

  /**
   * Regex that require only these characters
   */
  regex?: string;

  /**
   * [autocomplete ONLY] search is case-sensitive
   */
  isSensitive?: boolean;

  /**
   * [NATIVE] [type number ONLY] max number in input (do NOT trust)
   */
  min?: number;

  /**
   * [NATIVE] [type number ONLY] max number in input (do NOT trust)
   */
  max?: number;

  /**
   * [NATIVE] [type number ONLY] step of number[type number ONLY] max number in input (do NOT trust)
   */
  step?: number;

  /**
   * Translation object
   */
  i18n?: Record<string, string>;

  /**
   *  Validation error list
   */
  errors?: string[];

  /**
   *  Validation valid list
   */
  valids?: string[];

  /**
   * Valid v-model for easy validation,
   * can be forced "valid" but it's not suggested
   */
  valid?: boolean;

  /**
   * Enable validation (is-valid only)
   */
  validationInvalidClassname?: string;

  /**
   * Enable validation (is-valid only)
   */
  validationValidClassname?: string;

  /**
   * Enable validation (is-valid only)
   */
  validationInvalidEnable?: boolean;

  /**
   * Enable validation (is-valid only)
   */
  validationValidEnable?: boolean;

  /**
   * Enable validation (is-valid only)
   */
  validation?: boolean;

  /**
   * [UI]
   * Hide the arrows needed to increase or decrease the number entered.
   * Although hidden, the functionality will be available from the keyboard
   */
  hideArrows?: boolean;

  /**
   * [UI] [Autocomplete] BiList light prop
   */
  light?: boolean;

  /**
   * Input text. If NOT autocomplete it will be the same as modelValue
   */
  text?: string;

  /**
   * Style that apply to autocomplete list
   * 100px, 50%, etc
   */
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  listStyle?: any;

  /**
   * Classes added to autocomplete list
   * 100px, 50%, etc
   */
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  listClass?: any;

  /**
   * SHORTCUT
   * Max height style of autocomplete list
   * 100px, 50%, etc
   */
  listHeight?: string;

  /**
   * [Autocomplete] Autocomplete list
   */
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  items?: Array<string | number> | any[];

  /**
   * [Autocomplete]
   *
   * Seamless mode.
   *
   * When writing, if text match a itemValue, it is automatically selected
   *
   * (Normally this happens only if it is the only element present after the filter)
   */
  seamless?: boolean;

  /**
   * [Autocomplete]
   *
   * if strict is enabled = value must be in the list,
   *
   * if not: free text and autocomplete is just a suggestion (even if items are objects)
   */
  strict?: boolean;

  /**
   * [Autocomplete]
   * If items are object
   *
   * this is the parameter containing the key/value of selection
   *
   */
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  itemValue?: string | ((val: any) => string);

  /**
   * [Autocomplete]
   * If items are object
   *
   * this is the parameter containing the description/label of selection
   */
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  itemTitle?: string | ((val: any) => string);
}

export interface TextInputEmits extends FormFieldEmits {
  (e: "update:modelValue", value: string): void;
  (e: "update:text", value: string): void;
  (e: "validate", value: string): void;
  (e: "input:blur"): void;
  (e: "input:input"): void;
}

const formErrors = ref<string[]>([]);

const props = withDefaults(defineProps<TextInputProps>(), {
  isDisabled: false,
  required: false,
});
const emit = defineEmits<TextInputEmits>();
const { onBlur, onInput } = useFormField(
  props,
  emit,
  formErrors,
  Array.isArray(props.items),
);

const valueRef = ref(props.modelValue);
const textRef = ref(props.text);

watch(
  () => props.modelValue,
  (val) => {
    valueRef.value = val;
  },
);
watch(
  () => props.text,
  (val) => {
    textRef.value = val;
  },
);

function updateModelValueHandler(text: string) {
  valueRef.value = text;
  emit("update:modelValue", text);
}

function updateTextHandler(text: string) {
  textRef.value = text;
  emit("update:text", text);
}

function onCustomBlur(event: Event) {
  emit("input:blur");
  onBlur(event);
}

function onCustomInput(event: Event) {
  emit("input:input");
  onInput(event);
}
</script>

<template>
  <BiInput
    v-bind="props"
    :placeholder="placeholder"
    :label="label"
    :model-value="valueRef"
    @update:model-value="updateModelValueHandler"
    :readonly="isReadonly"
    :help-text="info"
    @input="onCustomInput"
    @blur="onCustomBlur"
    :text="textRef"
    @update:text="updateTextHandler"
    :errors="errors ?? formErrors"
  />
</template>
