<script lang="ts" setup>
import useEmitter from "@/composables/useEmitter";
import useLandLinkId from "@/composables/useLandLinkId";
import useModuleId from "@/composables/useModuleId";
import useParty from "@/composables/useParty";
import { type DocumentTypeModel } from "@/models/documentTypes";
import type {
  DocumentDataRecordModel,
  DynamiDocumentDataModel,
  DynamiDocumentMapModel,
  DynamiDocumentModel,
} from "@/models/dynamicDocuments";
import { ScopeCode } from "@/models/groups";
import { RouteName } from "@/models/routes";
import { getDocumentTypeByDefinitionCode } from "@/resources/api/documentTypes";
import {
  createLandLinkDocument,
  deleteLandLinkDocument,
  getLandLinkDocument,
  getLandLinkDocuments,
  updateLandLinkDocument,
} from "@/resources/api/dynamicLandLinkDocuments";
import { useDocumentTypeStore } from "@/stores/documentTypes";
import { useLandLinksStore } from "@/stores/landLinks";
import { useNotificationStore } from "@/stores/notification";
import BiButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiButton.vue";
import BiModal from "@abaco/bootstrap-italia-components/src/components/BiModal/BiModal.vue";
import { getUUID } from "@abaco/bootstrap-italia-components/src/utilities";
import type { DocumentSchemaType } from "@abaco/dynamic-documents/src/resources/models";
import { ErrorType } from "@abaco/safe-rest/src/HTTPClient";
import { format } from "date-fns";
import isEqual from "lodash/isEqual";
import { computed, inject, ref, toRaw, watch } from "vue";
import { useI18n } from "vue-i18n";
import { useRoute, useRouter } from "vue-router";
import DynamicDocumentForm from "./DynamicDocumentForm.vue";
import DynamicDocumentList from "./DynamicDocumentList.vue";

enum ActionType {
  CREATE = "CREATE",
  EDIT = "EDIT",
  DELETE = "DELETE",
}

const hasPermissionWrite = inject<boolean>("hasPermissionWrite", false);

const moduleId = useModuleId();
const { t } = useI18n();
const landLinkStore = useLandLinksStore();
const { partyId } = useParty();
const route = useRoute();
const router = useRouter();
const documentTypeStore = useDocumentTypeStore();
const { landlinkId } = useLandLinkId();
const emitter = useEmitter();

const showModal = ref(false);
const docType = ref<DocumentTypeModel | null>(null);

const currentDefinition = ref<DocumentSchemaType | null>(null);
const currentDocument = ref<DynamiDocumentDataModel>({});
let currentDocumentPrevData: DynamiDocumentDataModel = {};

const documentList = ref<DynamiDocumentModel[]>([]);
const modalBodyText = ref("");
const action = ref<ActionType>(ActionType.CREATE);

const processingDocument = ref<DynamiDocumentMapModel>();
const loading = ref<boolean>(true);
const nextKey = ref<string | null>(null);
const totalCounts = ref<number>(0);

const confirmAction = ref<boolean>(false);

const hasGroupParam = computed(() => {
  return (
    typeof route.params.groupId === "string" && route.params.groupId.length
  );
});

const isReferenceDateToday = computed(() => {
  if (hasGroupParam.value) {
    return true;
  }
  return (
    format(landLinkStore.reference_date, "yyyyMMdd") ===
    format(new Date(), "yyyyMMdd")
  );
});

const canEdit = computed(() => {
  return hasPermissionWrite && isReferenceDateToday.value;
});

function goBack() {
  if (
    route.name === RouteName.GROUP_EDIT_LANDLINK_INFO ||
    route.name === RouteName.GROUP_NEW_MULTIPLE_LANDLINK_INFO ||
    route.name === RouteName.GROUP_EDIT_MULTIPLE_LANDLINK_INFO
  ) {
    router.replace({ name: RouteName.GROUP_EDIT_LANDLINK });
  } else if (route.name === RouteName.LAND_LINK_INFO) {
    router.replace({ name: RouteName.LAND_LINK_EDIT });
  } else {
    router.replace({ name: RouteName.GROUP_EDIT });
  }
}

function onDocumentChanged(changes: DocumentDataRecordModel) {
  if ("data" in currentDocumentPrevData && currentDocumentPrevData.data) {
    if (!isEqual(currentDocumentPrevData.data, changes)) {
      emitter.emit("is:dirty", true);
    } else {
      emitter.emit("is:dirty", false);
    }
  }
}

const isMultiple = computed(() => {
  if (route.name === RouteName.GROUP_NEW_MULTIPLE_LANDLINK_INFO) {
    return false;
  }
  if (route.name === RouteName.GROUP_EDIT_MULTIPLE_LANDLINK_INFO) {
    return false;
  }
  return docType.value?.multiple ?? false;
});

async function loadLandlinkDocuments(append = false) {
  if (docType.value) {
    const landLinkId = route.params.landlinkId as string;
    const defCode = docType.value.definitionCode as string;
    const resp = await getLandLinkDocuments(
      partyId.value,
      landLinkId,
      defCode,
      nextKey.value,
    );
    if (resp.errorType === ErrorType.NONE) {
      if (append) {
        documentList.value = [...documentList.value, ...resp.data.records];
      } else {
        documentList.value = resp.data.records;
      }
      nextKey.value = resp.data.nextKey;
      totalCounts.value = resp.data.count;
    } else {
      // TODO Mettere Notification error
    }
  }
}

watch(
  () => route.params,
  async (params) => {
    landLinkStore.setPartyId(+partyId.value);
    loading.value = true;
    currentDocument.value = {};

    // reset value
    documentList.value = [];
    nextKey.value = null;
    totalCounts.value = 0;

    const infoTypeParam = params.infoType as string | undefined;
    const landLinkId = landlinkId.value;

    if (landLinkId) {
      await landLinkStore.fetchLandLinkById(
        landLinkId,
        hasGroupParam.value ? new Date() : undefined,
      );

      if (partyId.value && infoTypeParam) {
        const docResp = await getDocumentTypeByDefinitionCode(
          infoTypeParam,
          ScopeCode.LANDLINK,
        );
        if (docResp.errorType === ErrorType.NONE) {
          currentDefinition.value = docResp.data;
        }

        await documentTypeStore.getDocumentLandlinkTypes(landLinkId, false);

        if (!documentTypeStore.error) {
          docType.value =
            documentTypeStore.landLinkDocuments.find(
              (v) => v.definitionCode === infoTypeParam,
            ) ?? null;
          if (docType.value && docType.value.flDocPresent) {
            await loadLandlinkDocuments();
            const docId = params.docId as string | undefined;

            if (
              documentList.value.length &&
              (!docType.value.multiple || docId)
            ) {
              const docResp = await getLandLinkDocument(
                partyId.value,
                landLinkId,
                docId ?? documentList.value[0].documentId,
              );
              if (docResp.errorType === ErrorType.NONE) {
                currentDocument.value = docResp.data;
              } else {
                // TODO Mettere Notification error
              }
            }
          }
        }
      }
    }

    currentDocumentPrevData = structuredClone(toRaw(currentDocument.value));
    emitter.emit("is:dirty", false);
    loading.value = false;
  },
  { immediate: true },
);

async function handleModalClose() {
  if (confirmAction.value) {
    switch (action.value) {
      case ActionType.CREATE:
        break;
      case ActionType.EDIT:
        goBack();
        break;
      case ActionType.DELETE:
        if (
          route.name === RouteName.GROUP_EDIT_DOC &&
          docType.value?.multiple
        ) {
          await loadLandlinkDocuments();
        } else {
          goBack();
        }
        break;
    }
  }

  confirmAction.value = false;
}

function handleDismissModal() {
  processingDocument.value = undefined;
  showModal.value = false;
}

async function handleConfirmAction() {
  const partyId = route.params.partyId as string;
  const landLinkId = route.params.landlinkId as string;
  if (processingDocument.value === undefined) {
    return;
  }
  const { documentId } = processingDocument.value;
  if (typeof documentId !== "number") {
    return;
  }
  switch (action.value) {
    case ActionType.CREATE:
      break;
    case ActionType.EDIT:
      {
        const resp = await updateLandLinkDocument(
          partyId,
          landLinkId,
          documentId.toString(),
          {
            fields: processingDocument.value.data,
          },
        );
        await documentTypeStore.getDocumentLandlinkTypes(landLinkId, true);
        currentDocumentPrevData = structuredClone(toRaw(currentDocument.value));
        emitter.emit("is:dirty", false);
        if (resp.errorType === ErrorType.NONE) {
          confirmAction.value = true;
        }
        useNotificationStore().setMessage(resp);
      }
      break;
    case ActionType.DELETE:
      {
        const resp = await deleteLandLinkDocument(
          partyId,
          landLinkId,
          documentId,
        );
        await documentTypeStore.getDocumentLandlinkTypes(landLinkId, true);
        if (resp.errorType === ErrorType.NONE) {
          confirmAction.value = true;
        }
        currentDocumentPrevData = structuredClone(toRaw(currentDocument.value));
        emitter.emit("is:dirty", false);
        useNotificationStore().setMessage(resp);
      }
      break;
  }
  showModal.value = false;
}

async function onCreateDocument(documentData: DynamiDocumentMapModel) {
  action.value = ActionType.CREATE;
  processingDocument.value = documentData;
  const landLinkId = route.params.landlinkId as string;
  const partyId = route.params.partyId as string;

  const resp = await createLandLinkDocument(partyId, landLinkId, documentData);

  await documentTypeStore.getDocumentLandlinkTypes(landLinkId, true);
  showModal.value = false;
  currentDocumentPrevData = structuredClone(toRaw(currentDocument.value));
  emitter.emit("is:dirty", false);
  useNotificationStore().setMessage(resp);
  goBack();
}

function onConfirmUpdate(documentData: DynamiDocumentMapModel) {
  action.value = ActionType.EDIT;
  processingDocument.value = documentData;
  modalBodyText.value = t(`${moduleId}.dynamic_docs.form.confirmMessage.EDIT`);
  const docName = docType.value?.definitionCodeI18n ?? "";
  // #141072 fixed modal title
  modalTitle.value = t(`${moduleId}.dynamic_docs.form.updateConfirm`, {
    docName,
  });
  showModal.value = true;
}

async function onConfirmDelete(documentData: DynamiDocumentMapModel) {
  action.value = ActionType.DELETE;
  processingDocument.value = documentData;
  modalBodyText.value = t(
    `${moduleId}.dynamic_docs.form.confirmMessage.DELETE`,
  );
  const docName = docType.value?.definitionCodeI18n ?? "";
  // #141072 fixed modal title
  modalTitle.value = t(`${moduleId}.dynamic_docs.form.deleteConfirm`, {
    docName,
  });
  showModal.value = true;
}

const modalTitle = ref<string>("");

async function onLoadMore() {
  await loadLandlinkDocuments(true);
}
</script>

<template>
  <template v-if="docType && currentDefinition">
    <DynamicDocumentForm
      v-if="!isMultiple && !loading"
      :docDefinition="currentDefinition"
      v-model="currentDocument"
      :readonly="!canEdit"
      @create-document="onCreateDocument"
      @update-document="onConfirmUpdate"
      @delete-document="onConfirmDelete"
      @change-document="onDocumentChanged"
    />
    <DynamicDocumentList
      v-if="isMultiple && !loading"
      :documentList="documentList"
      :docType="docType"
      :docDefinition="currentDefinition"
      :readonly="!canEdit"
      :showLoadMore="!!nextKey"
      @delete-document="onConfirmDelete"
      @load-more="onLoadMore"
    />
  </template>

  <BiModal
    size="lg"
    ariaLabelledby="confirm-modal-document"
    :id="getUUID()"
    v-model="showModal"
    :title="modalTitle"
    data-keyboard="true"
    data-backdrop="static"
    extra-body-class="pt-5"
    @hidden-modal="handleModalClose()"
  >
    <template #body> {{ modalBodyText }} </template>
    <template #footer>
      <div class="customer-land-link__modal-footer text-center pt-5 pb-5 w-100">
        <BiButton @click="handleDismissModal" is-outlined color="primary">
          {{ t(`${moduleId}.cancel`) }}
        </BiButton>

        <BiButton
          v-if="docType?.flDocPresent && action === ActionType.DELETE"
          @click="handleConfirmAction"
          color="danger"
        >
          {{ t(`${moduleId}.dynamic_docs.form.deleteConfirm`) }}
        </BiButton>
        <BiButton
          @click="handleConfirmAction"
          color="success"
          v-if="
            !docType?.flDocPresent ||
            (docType?.flDocPresent && action === ActionType.EDIT)
          "
        >
          {{ t(`${moduleId}.dynamic_docs.form.updateConfirm`) }}
        </BiButton>
      </div>
    </template>
  </BiModal>
</template>

<style lang="scss">
.customer-land-link {
  &__modal-footer {
    button {
      &:not(:last-child) {
        margin-right: 12px;
      }
    }
  }
}
</style>
