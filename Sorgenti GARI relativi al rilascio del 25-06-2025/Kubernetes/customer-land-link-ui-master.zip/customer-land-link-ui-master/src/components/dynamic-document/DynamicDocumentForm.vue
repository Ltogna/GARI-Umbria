<script setup lang="ts">
import useGroup from "@/composables/useGroup";
import useLandLinkId from "@/composables/useLandLinkId";
import useParty from "@/composables/useParty";
import { MODULE_ID } from "@/constants";
import type {
  DocumentDataRecordModel,
  DynamiDocumentDataModel,
  DynamiDocumentMapModel,
} from "@/models/dynamicDocuments";
import BiButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiButton.vue";
import BiIcon from "@abaco/bootstrap-italia-components/src/components/BiIcon/BiIcon.vue";
import DocumentBuilder from "@abaco/dynamic-documents/src/components/DocumentBuilder.vue";
import type { FileUploadConfig } from "@abaco/dynamic-documents/src/resources/composables/useFiles";
import type { DocumentSchemaType } from "@abaco/dynamic-documents/src/resources/models";
import type { DocumentDataDocSchemaType } from "@abaco/dynamic-documents/src/resources/models/document";
import { getUserData } from "@abaco/safe-rest/src/sso2";
import cloneDeep from "lodash/cloneDeep";
import { computed, ref, toRaw, watch, defineProps, defineEmits } from "vue";
import { useI18n } from "vue-i18n";
import { useRoute } from "vue-router";

const { t, locale } = useI18n();
const route = useRoute();

const props = defineProps<{
  documentId?: number;
  modelValue: DynamiDocumentDataModel;
  readonly: boolean;
  docDefinition: DocumentSchemaType;
}>();

const emit = defineEmits<{
  (e: "form-reset"): void;
  (e: "create-document", value: DynamiDocumentMapModel): void;
  (e: "update-document", value: DynamiDocumentMapModel): void;
  (e: "delete-document", value: DynamiDocumentMapModel): void;
  (e: "change-document", value: DocumentDataRecordModel): void;
}>();

const formValues = ref<DocumentDataDocSchemaType>();
const validationErrors = ref({});
const isValid = ref(false);
const language = ref(locale.value);
const showErrors = ref(false);

const { partyId } = useParty();
const { groupId } = useGroup();
const { landlinkId } = useLandLinkId();

const isEditDocument = computed(() => {
  return props.modelValue && typeof props.modelValue.documentId === "number";
});

watch(
  () => props.modelValue,
  (value) => {
    const fields =
      value && value.data
        ? (structuredClone(toRaw(value.data)) as DocumentDataRecordModel)
        : {};
    formValues.value = { ...formValues.value, fields };
  },
  { immediate: true },
);

watch(
  () => formValues.value,
  (fv) => {
    const fvCloned = cloneDeep(fv);
    if (fvCloned && fvCloned.fields) {
      const fvClonedData = fvCloned.fields;
      emit("change-document", fvClonedData);
    }
  },
  { deep: true },
);

function formConfirm() {
  if (isValid.value) {
    if (props.modelValue && typeof props.modelValue.documentId === "number") {
      emit("update-document", mapRequest());
    } else {
      emit("create-document", mapCreateRequest());
    }
  }

  showErrors.value = !isValid.value;
}
function mapCreateRequest() {
  return {
    defCode: props.docDefinition.code,
    label: "", // TODO: which value?
    businessId: Number(route.params.groupId as string),
    doc: {
      ...formValues.value,
    },
  } as DynamiDocumentMapModel;
}
function mapRequest(): DynamiDocumentMapModel {
  if (!formValues.value) {
    return {} as DynamiDocumentMapModel;
  }
  return {
    ...props.modelValue,
    data: {
      ...(formValues.value.fields as Record<string, unknown>),
    },
  } as DynamiDocumentMapModel;
}
function onDeleteDocument() {
  emit("delete-document", mapRequest());
}

const fileUploadConfig = computed<FileUploadConfig | null>(() => {
  const userData = getUserData();
  const { documentId } = props.modelValue;
  let { bucketName } = props.modelValue as { bucketName: string };
  bucketName ??= props.docDefinition.bucketName as string;
  if (userData && bucketName && partyId.value) {
    const { tenant: tenantId } = userData;
    const base = `/customer-land-link/${tenantId}/api-priv/v1/parties/${partyId.value}`;
    if (landlinkId.value) {
      return {
        bucketName,
        readUrl: `${base}/land-links/${landlinkId.value}/documents/${documentId}/attachments`,
        tenantId,
      };
    }
    if (groupId.value) {
      return {
        bucketName,
        readUrl: `${base}/groups/${groupId.value}/documents/${documentId}/attachments`,
        tenantId,
      };
    }
  }
  return null;
});
</script>
<template>
  <DocumentBuilder
    v-if="docDefinition?.fieldSets"
    v-model="formValues"
    v-model:lang="language"
    :schema="docDefinition"
    :show-errors="showErrors"
    :file-upload-config="fileUploadConfig ?? undefined"
    doc-title-hide
    :readonly="readonly"
    @update:errors="(value) => (validationErrors = value)"
    @update:valid="(value) => (isValid = value)"
  />
  <!-- TEST ONLY -->
  <!-- <hr />
    {{ docDefinition }}
    <hr />
    {{ formValues }}
    <hr />
    {{ validationErrors }}
    <hr />
    {{ isValid }} -->
  <div v-if="!readonly" class="dd-actions text-center mt-4 pb-5">
    <!-- <BiButton @click="formReset" is-outlined color="primary">
      {{ t(`${MODULE_ID}.dynamic_docs.form.resetButton`) }}
    </BiButton> -->
    <BiButton
      v-if="isEditDocument"
      @click="onDeleteDocument"
      color="danger"
      is-icon
    >
      <BiIcon icon="trash-can" class="me-1"></BiIcon>
      {{ t(`${MODULE_ID}.dynamic_docs.form.delete`) }}
    </BiButton>
    <BiButton @click="formConfirm" color="success" is-icon>
      <BiIcon icon="pencil" class="me-1"></BiIcon>
      {{ t(`${MODULE_ID}.dynamic_docs.form.updateSave`) }}
    </BiButton>
  </div>
</template>

<style lang="scss" scoped>
.dd-actions {
  & > *:not(:last-child) {
    margin-right: 12px;
  }
}
</style>
