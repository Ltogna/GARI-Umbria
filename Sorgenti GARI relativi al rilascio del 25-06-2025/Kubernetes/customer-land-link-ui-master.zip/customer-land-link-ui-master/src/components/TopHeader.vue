<template>
  <div class="customer-land-link__top-header row">
    <div
      class="col bg-primary text-white border border-primary fw-bolder text-break"
    >
      {{ title }}
    </div>
  </div>
</template>

<script lang="ts" setup>
import { defineProps } from "vue";
defineProps<{
  title: string;
}>();
</script>

<style lang="scss" scoped>
.customer-land-link {
  &__top-header {
    margin-top: 1px;
    & > div {
      padding-top: 10px !important;
      padding-bottom: 10px !important;
    }
  }
}
</style>
