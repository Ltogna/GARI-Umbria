<script setup lang="ts">
import useFullpage from "@/composables/useFullpage";
import useModuleId from "@/composables/useModuleId";
import BiButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiButton.vue";
import { useI18n } from "vue-i18n";

const fullpage = useFullpage();
const moduleId = useModuleId();
const { t } = useI18n();

function clickHandler() {
  fullpage.fullscreenActive.value = !fullpage.fullscreenActive.value;
}
</script>

<template>
  <BiButton color="success" is-outlined @click="clickHandler">
    {{
      fullpage.fullscreenActive.value
        ? t(`${moduleId}.fullpage-button-off`)
        : t(`${moduleId}.fullpage-button-on`)
    }}
  </BiButton>
</template>
