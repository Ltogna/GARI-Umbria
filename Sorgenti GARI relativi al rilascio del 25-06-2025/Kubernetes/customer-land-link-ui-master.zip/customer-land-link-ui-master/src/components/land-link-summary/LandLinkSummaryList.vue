<script setup lang="ts">
import { useI18n } from "vue-i18n";
import { onMounted, ref, defineProps } from "vue";
import { getLandLinks } from "../../resources/api/landlink-public-api";
import useModuleId from "../../composables/useModuleId";
import type { LandLinkSectorSummaryListModel } from "../../models/landLinkSectorSummary";
import { ErrorType } from "@abaco/safe-rest/src/HTTPClient";
import LandLinkSummaryTableRow from "../land-link-summary/LandLinkSummaryTableRow.vue";
import BiTable from "@abaco/bootstrap-italia-components/src/components/BiTable/BiTable.vue";
import BiButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiButton.vue";
import BiIcon from "@abaco/bootstrap-italia-components/src/components/BiIcon/BiIcon.vue";
import BiHiddenContent from "@abaco/bootstrap-italia-components/src/components/BiHiddenContent/BiHiddenContent.vue";
import useColors from "@abaco/bootstrap-italia-components/src/composables/useColors";
import { useLandLinksStore } from "@/stores/landLinks";
import { BASE } from "@/constants";

const { getColor } = useColors();

const props = defineProps<{
  partyId: number;
  winLocationBase?: string;
  winLocationQuery?: { [key: string]: string };
}>();

const { t } = useI18n();
const moduleId = useModuleId();
const isLoading = ref(false);
const hasError = ref(false);
const landLinks = useLandLinksStore();
const landLinkSummaryList = ref<LandLinkSectorSummaryListModel>([]);

onMounted(async () => {
  await fetchSummaryList(props.partyId);
});

async function fetchSummaryList(partyId: number) {
  isLoading.value = true;
  const response = await getLandLinks(partyId);

  if (response.errorType !== ErrorType.NONE) {
    console.warn(response);
    hasError.value = true;
  } else {
    landLinkSummaryList.value = response.data;
    hasError.value = false;
  }
  isLoading.value = false;
}

function goToDetails() {
  if (props.winLocationBase) {
    const queryParams =
      props.winLocationQuery && Object.entries(props.winLocationQuery).length
        ? Object.entries(props.winLocationQuery)
            .map(([k, v]) => `${k}=${v}`)
            .reduce((out, cur) => out + (out === "" ? "?" : "&") + cur, "")
        : "";
    location.assign(
      `${props.winLocationBase}/party/${props.partyId}/landLink${queryParams}${queryParams}`,
    );
  } else {
    landLinks.reset();
    location.assign(`${BASE}party/${props.partyId}/landLink`);
  }
}
</script>
<template>
  <div class="row my-3 justify-content-start">
    <div class="col-12 my-3">
      <h4 class="fw-bold" :class="getColor('text', 'primary')">
        <BiIcon class="mx-2" icon="file-lines" size="lg" />
        {{ t(`${moduleId}.title`, 2) }}
      </h4>
    </div>
  </div>
  <div>
    <BiTable
      class="table-hover mb-0 table-responsive"
      extraTableClasses="table-head-bg"
      isRowHover
    >
      <template #head>
        <tr class="bg-light text-secondary">
          <th scope="col">
            {{ t(`${moduleId}.landLink_summary.municipality`) }}
          </th>
          <th scope="col">
            {{ t(`${moduleId}.landLink_summary.parcels`, 2) }}
          </th>
          <th scope="col">
            {{ t(`${moduleId}.landLink_summary.surface_gis_ha`) }}
          </th>
          <th scope="col">
            {{ t(`${moduleId}.landLink_summary.surface_cond_ha`) }}
          </th>
          <th scope="col">
            <BiHiddenContent :text="t(`${moduleId}.conductor`, 2)">
            </BiHiddenContent>
          </th>
          <th scope="col">
            <BiHiddenContent :text="t(`${moduleId}.action`, 2)">
            </BiHiddenContent>
          </th>
        </tr>
      </template>
      <template #body>
        <LandLinkSummaryTableRow
          v-for="(landLinkSummary, index) in landLinkSummaryList"
          :party-id="partyId"
          :key="`landLinkSummary_${index}`"
          :id="`landLinkSummary_${index}`"
          :land-link-summary="landLinkSummary"
          :win-location-base="winLocationBase"
          :win-location-query="winLocationQuery"
        />
      </template>
    </BiTable>

    <div class="row mt-5">
      <div class="col-12 d-flex justify-content-center">
        <BiButton color="success" @click="goToDetails()">
          {{ t(`${moduleId}.detail`, 2) }}
        </BiButton>
      </div>
    </div>
  </div>
</template>
