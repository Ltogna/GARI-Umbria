<script setup lang="ts">
import { BASE } from "@/constants";
import useModuleId from "../../composables/useModuleId";
import type { LandLinkSectorSummaryModel } from "../../models/landLinkSectorSummary";
import { convertAreaSQMInHA, intlNumberFormatOptions } from "../../utils/area";
import BiIconButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiIconButton.vue";
import BiCollapse from "@abaco/bootstrap-italia-components/src/components/BiCollapse/BiCollapse.vue";
import BiIcon from "@abaco/bootstrap-italia-components/src/components/BiIcon/BiIcon.vue";
import { ref, watch, defineProps } from "vue";
import { useI18n } from "vue-i18n";

const props = defineProps<{
  partyId: number;
  landLinkSummary: LandLinkSectorSummaryModel;
  id: string;
  winLocationBase?: string;
  winLocationQuery?: { [key: string]: string };
}>();

const moduleId = useModuleId();
const { t, n } = useI18n();

const isCollapsed = ref(false);
const hasDetails = ref(false);

watch(
  () => isCollapsed.value,
  (isCollapsed) => {
    if (isCollapsed) {
      hasDetails.value = true;
    }
  },
);

function goToFilteredLandLink() {
  const sectorCode = props.landLinkSummary.sector.sectorCode;
  if (props.winLocationBase) {
    const queryParams =
      props.winLocationQuery && Object.entries(props.winLocationQuery).length
        ? Object.entries(props.winLocationQuery)
            .map(([k, v]) => `${k}=${v}`)
            .reduce((out, cur) => out + "&" + cur, "")
        : "";
    location.assign(
      `${props.winLocationBase}/party/${props.partyId}/landLink?sectorCode=${sectorCode}${queryParams}`,
    );
  } else {
    location.assign(
      `${BASE}party/${props.partyId}/landLink?sectorCode=${sectorCode}`,
    );
  }
}
function convertAreaValue(areaValue: number) {
  return areaValue !== 0
    ? n(convertAreaSQMInHA(areaValue), intlNumberFormatOptions)
    : 0;
}
</script>

<template>
  <tr>
    <td
      :data-label="t(`${moduleId}.landLink_summary.municipality`)"
      class="text-break max-w-xs"
    >
      {{ landLinkSummary.sector.description }}
    </td>
    <td :data-label="t(`${moduleId}.landLink_summary.parcels`, 2)">
      {{ landLinkSummary.linkCount }}
    </td>
    <td :data-label="t(`${moduleId}.landLink_summary.surface_gis_ha`)">
      {{ convertAreaValue(landLinkSummary.totParcelAreaSqm) }}
    </td>
    <td :data-label="t(`${moduleId}.landLink_summary.surface_cond_ha`)">
      {{ convertAreaValue(landLinkSummary.totTitleTypeAreaSqm) }}
    </td>
    <td>
      <BiCollapse
        tag="span"
        :target-selector="`#collapse-${id}`"
        v-model="isCollapsed"
      >
        <BiIcon
          icon="chevron-down"
          style="cursor: pointer"
          :class="isCollapsed ? 'collapse-icon' : undefined"
        />
      </BiCollapse>
    </td>
    <td>
      <div class="d-flex flex-nowrap">
        <BiIconButton
          :title="
            t(`${moduleId}.open_sector_details`, {
              council_descr: props.landLinkSummary.sector.shortDescr,
            })
          "
          icon="arrow-right"
          class="me-2"
          icon-style="fas"
          color="info"
          is-outlined
          @click="goToFilteredLandLink()"
        />
      </div>
    </td>
  </tr>
  <tr>
    <td class="p-0" colspan="99999">
      <div :id="`collapse-${id}`">
        <div class="accordion-body p-3">
          <div class="row">
            <div
              class="col-md-4"
              v-for="(titleSummary, index) in landLinkSummary.titleSummaryRes"
              :key="`titleSummary-${id}-${index}`"
            >
              <strong>
                {{ t(`${moduleId}.landLink_summary.surface_cond_ha`) }}
                {{ titleSummary.titleType?.i18nCode }}:
              </strong>
              {{ convertAreaValue(titleSummary.totTitleTypeAreaSqm) }} ha
            </div>
          </div>
        </div>
      </div>
    </td>
  </tr>
</template>

<style scoped lang="scss">
.collapse-icon {
  transform: rotate(-180deg);
}
</style>
