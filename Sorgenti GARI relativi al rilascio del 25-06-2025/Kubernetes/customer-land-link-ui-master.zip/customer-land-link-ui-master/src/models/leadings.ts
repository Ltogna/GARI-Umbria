import { z } from "zod";
// import { GroupBaseSchema } from "./landLink";
import { PartyResponseSchema } from "./party";
import { TitleTypeSchema } from "./titleTypes";
import { stringToDate } from "./utils";

export const LeadingSchema = z.object({
  id: z.number(),
  //group: GroupBaseSchema,
  partyId: z.number(),
  party: PartyResponseSchema,
  titleType: TitleTypeSchema,
  titleTypePerc: z.number(),
  dayFrom: stringToDate,
  dayTo: stringToDate,
});

export type LeadingModel = z.infer<typeof LeadingSchema>;
