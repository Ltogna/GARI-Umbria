import { getNextPagedResultsSchema } from "@abaco/safe-rest/src/pagination";
import { z } from "zod";
import { SimpleLandLinkSchema } from "./landLinks";
import { TitleTypeSchema } from "./titleTypes";
import { dateToString, stringToDate } from "./utils";

export enum ScopeCode {
  GROUPS = "GROUPS",
  LANDLINK = "LANDLINKS",
}

export const GroupResSchema = z.object({
  id: z.number(),
  descr: z.string().nullable(),
  partyId: z.number(),
  titleType: TitleTypeSchema,
  dayFrom: stringToDate,
  dayTo: stringToDate,
  linkCount: z.number(),
  checked: z.boolean().default(false),
});

// const GroupCloseReqSchema = z.object({
//   dayTo: z.string(),
// });

export const InfiniteListResultsGroupResSchema =
  getNextPagedResultsSchema(GroupResSchema);

export const GroupCreateReqSchema = z.object({
  descr: z.string().nullable(),
  dayFrom: dateToString,
  dayTo: dateToString,
  titleTypeId: z.number(),
  landLinks: z.array(SimpleLandLinkSchema),
});

export const GroupUpdateReqSchema = z.object({
  descr: z.string().nullable(),
  dayFrom: z.string(),
  dayTo: z.string(),
});

export const GroupCloneSchema = z.object({
  descr: z.string(),
  dayFrom: z.string(),
  dayTo: z.string(),
  titleTypeId: z.number(),
  titleTypePerc: z.number(),
});

export type GroupCloneModel = z.infer<typeof GroupCloneSchema>;

export type GroupUpdateReqModel = z.infer<typeof GroupUpdateReqSchema>;

export type GroupResModel = z.infer<typeof GroupResSchema>;

export type GroupCreateReqModel = z.infer<typeof GroupCreateReqSchema>;

export type InfiniteListResultsGroupResModel = z.infer<
  typeof InfiniteListResultsGroupResSchema
>;

export const GroupSearchFilterSchema = z.object({
  titleTypeId: z.number().nullable(),
  descr: z.string().nullable(),
  showElapsed: z.boolean().default(false),
  nextKey: z.string().nullable(),
});

export type GroupSearchFilterModel = z.infer<typeof GroupSearchFilterSchema>;

export type GroupFilterModel = Omit<GroupSearchFilterModel, "nextKey">;

export const GroupsBulkClosePayloadSchema = z.object({
  dayTo: dateToString,
  groupIds: z.array(z.number()),
});

export type GroupsBulkClosePayloadModel = z.infer<
  typeof GroupsBulkClosePayloadSchema
>;
