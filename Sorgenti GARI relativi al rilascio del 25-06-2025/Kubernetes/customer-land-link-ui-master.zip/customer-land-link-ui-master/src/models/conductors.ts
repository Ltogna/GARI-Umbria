import { z } from "zod";

export const CountryResponseSchema = z.object({
  code: z.string(),
  tenantId: z.string(),
  active: z.boolean(),
  i18nName: z.string(),
});

export const BaseResponseSchema = z.object({
  code: z.string(),
  tenantId: z.string(),
  shortDescr: z.string(),
  active: z.boolean(),
  i18nName: z.string(),
});

export const RegionResponseSchema = BaseResponseSchema.extend({
  countryCode: z.string(),
  country: CountryResponseSchema,
});

export const DistrictResponseSchema = BaseResponseSchema.extend({
  regionCode: z.string(),
  region: RegionResponseSchema,
});

export const MunicipalityResponseSchema = BaseResponseSchema.extend({
  districtCode: z.string(),
  district: DistrictResponseSchema,
});

export const AdressResponseSchema = z.object({
  id: z.number(),
  municipality: z.string(),
  locality: z.string().nullable(),
  street: z.string(),
  houseNumber: z.string(),
  postcode: z.string(),
  details: z.string().nullable(),
  note: z.string().nullable(),
  municipalityI18nCode: z.string(),
  municipalityDetail: MunicipalityResponseSchema,
});

export const TagResponseSchema = z.object({
  id: z.number(),
  code: z.string(),
  i18nCode: z.string(),
});

export const ConductorSchema = z.object({
  id: z.number(),
  // partyType: z.string(),
  // gender: z.string().nullable(),
  lastName: z.string(),
  firstName: z.string().nullable(),
  // taxCode: z.string().nullable(),
  // vatNumber: z.string().nullable(),
  code: z.string().nullable(),
  // birthDate: z.string().nullable(),
  // deathDate: z.string().nullable(),
  // birthMunicipality: z.string().nullable(),

  // birthMunicipalityDetail: MunicipalityResponseSchema.nullable(),

  // nationality: z.string().nullable(),

  // addressResidential: AdressResponseSchema,
  // addressHome: AdressResponseSchema.nullable(),
  // addressBilling: AdressResponseSchema.nullable(),
  // tags: z.array(TagResponseSchema).nullable(),

  // archived: z.boolean(),
});

export type ConductorModel = z.infer<typeof ConductorSchema>;
