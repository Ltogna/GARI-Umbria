import { z } from "zod";
import { stringToDate, wktToGeoJSONSchema } from "./utils";

export const LandCoverSchema = z.object({
  id: z.number(),
  code: z.string(),
  description: z.string().nullish(),
  parcel_id: z.number(),
  day_from: stringToDate,
  day_to: stringToDate,
  srs: z.string(),
  area_sqm: z.number().nullish(),
  geom: wktToGeoJSONSchema,
  world_geom: wktToGeoJSONSchema,
});

export const LandCoverListSchema = z.object({
  land_covers_list: z.array(LandCoverSchema),
});

export type LandCoverModel = z.infer<typeof LandCoverSchema>;
export type LandCoverListModel = z.infer<typeof LandCoverListSchema>;
