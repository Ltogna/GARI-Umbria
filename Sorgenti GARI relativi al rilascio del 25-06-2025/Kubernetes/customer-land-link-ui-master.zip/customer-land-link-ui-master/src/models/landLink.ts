import { z } from "zod";
import { dateToString, stringToDate } from "./utils";
import { getNextPagedResultsSchema } from "@abaco/safe-rest/src/pagination";
import { ParcelSchema } from "@/models/parcel";
import { AnomalyLevelSchema } from "./anomalyLevel";

export const LandLinkCloseResponseSchema = z.object({});
export const GroupBaseSchema = z.object({
  id: z.number(),
  descr: z.string().nullable().optional(),
});

export const TitleTypeSchema = z.object({
  id: z.number(),
  code: z.string(),
  flDayToReq: z.number().nullable().optional(),
  i18nCode: z.string().nullable().optional(),
});

export const LandLinkListCountSchema = z.number();

export const LandLinkSchema = z.object({
  id: z.number(),
  group: GroupBaseSchema,
  partyId: z.number().nullable().optional(),
  titleType: TitleTypeSchema,
  titleTypePerc: z.number(),
  parcel: ParcelSchema,
  parcelId: z.number().nullable().optional(),
  dayFrom: stringToDate,
  dayTo: stringToDate,
  maxAnomalyLevel: AnomalyLevelSchema.nullable(),
  anomalyCount: z.number().nullish(), //? remove nullish
  titleTypeAreaSqm: z.number().nullable(),
  checked: z.boolean().default(false),
});

export const LandLinkSearchFilterSchema = z.object({
  groupId: z.number().nullable().optional(),
  titleTypeId: z.string().nullable().optional(),
  partyId: z.number().nullable().optional(),
  targetPartyId: z.number().nullable().optional(),
  sectorCode: z.string().nullable().optional(),
  blockCode: z.string().nullable().optional(),
  parcelCode: z.string().nullable().optional(),
  subParcelCode: z.string().nullable().optional(),
  anomalyLevel: z.string().nullable().optional(),
  nextKey: z.string().nullable().optional(),
});

export const LandLinkListSchema = getNextPagedResultsSchema(LandLinkSchema);

export type LandLinkModel = z.infer<typeof LandLinkSchema>;
export type LandLinkSearchFilterModel = z.infer<
  typeof LandLinkSearchFilterSchema
>;
export type LandLinkListModel = z.infer<typeof LandLinkListSchema>;
export type LandLinkCloseResponseModel = z.infer<
  typeof LandLinkCloseResponseSchema
>;
export type LandLinkListCountModel = z.infer<typeof LandLinkListCountSchema>;

export const LandLinkBulkClosePayloadSchema = z.object({
  dayTo: dateToString,
  landLinkIds: z.array(z.number()),
});

export type LandLinkBulkClosePayloadModel = z.infer<
  typeof LandLinkBulkClosePayloadSchema
>;
