import { z } from "zod";

// export const BlockSchema = z.object({
//   id: z.number(),
//   sector_id: z.number().nullable(),
//   description: z.string(),
//   short_descr: z.string(),
//   block_code: z.string(),
//   srs: EPSGSchema.nullable(),
//   geom: z.string().nullable(),
//   world_geom: z.string().nullable(),
// });

export const BlockSchema = z.object({
  id: z.number(),
  description: z.string(),
  shortDescr: z.string(),
  blockCode: z.string(),
});

export type BlockModel = z.infer<typeof BlockSchema>;

// export const BlocksListSchema = z.object({
//   blocks_list: z.array(BlockSchema),
// });

// export type BlocksListModel = z.infer<typeof BlocksListSchema>;
