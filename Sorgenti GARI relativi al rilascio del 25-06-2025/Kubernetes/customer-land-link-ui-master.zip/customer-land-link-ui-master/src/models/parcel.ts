import { getNextPagedResultsSchema } from "@abaco/safe-rest/src/pagination";
import { z } from "zod";
import { ConductorSchema } from "./conductors";
import { PaginateListSchema, stringToDate } from "./utils";
import { LeadingSchema } from "./leadings";

export const SectorSchema = z.object({
  id: z.number().nullable(),
  description: z.string().nullable(),
  shortDescr: z.string().nullable().optional(),
  sectorCode: z.string().optional(),
});

export type SectorModel = z.infer<typeof SectorSchema>;

export const BlockSchema = z.object({
  id: z.number(),
  description: z.string(),
  shortDescr: z.string(),
  blockCode: z.string(),
});

export type BlockModel = z.infer<typeof BlockSchema>;

export const ParcelSchema = z.object({
  id: z.number(),
  parcel: z.string().nullable(),
  dayFrom: stringToDate.nullable(),
  dayTo: stringToDate.nullable(),
  srs: z.string().nullable().optional(),
  areaSqm: z.number().nullish(),
  block: BlockSchema.nullable(),
  sector: SectorSchema.nullable(),
});

export const SearchFilterSchema = z.object({
  cuaa: z.string().nullable().optional(),
  sectorCode: z.string().nullable().optional(),
  blockCode: z.string().nullable().optional(),
  parcelCode: z.string().nullable().optional(),
  subParcel: z.string().nullable().optional(),
  dayFrom: stringToDate,
  nextKey: z.string().nullable(),
});

export const InfiniteListResultsParcelSchema = PaginateListSchema.extend({
  records: z.array(ParcelSchema),
});

export const ParcelListSchema = z.object({
  parcel_list: z.array(ParcelSchema),
});

export type ParcelModel = z.infer<typeof ParcelSchema>;
export type ParcelListModel = z.infer<typeof ParcelListSchema>;
export type SearchFilterModel = z.infer<typeof SearchFilterSchema>;
export type InfiniteListResultsParcelModel = z.infer<
  typeof InfiniteListResultsParcelSchema
>;

export const ParcelConductedSchema = z.object({
  parcel: ParcelSchema,
  conduttori: z.array(ConductorSchema),
  leadings: z.array(LeadingSchema),
  conduzione: z.boolean(),
  conduzioneByCurrentParty: z.boolean(),
});

export type ParcelConductedModel = z.infer<typeof ParcelConductedSchema>;

export const InfiniteListParcelConductedSchema = getNextPagedResultsSchema(
  ParcelConductedSchema,
);

export type InfiniteListParcelConductedSchemaModel = z.infer<
  typeof InfiniteListParcelConductedSchema
>;
