import { z } from "zod";

export const SummaryFieldDefinitionSchema = z.object({
  code: z.string(),
  description: z.string(),
  fieldType: z.string(),
});

export const BaseDocumentTypeSchema = z.object({
  definitionCode: z.string(),
  definitionCodeI18n: z.string(),
  titleTypeId: z.number().nullable(),
  flRequired: z.number(),
  flReqOnAdd: z.number(),
  flReqOnClose: z.number(),
  flDocPresent: z.number(),
  summaryFieldDefinitions: z.array(SummaryFieldDefinitionSchema).nullish(),
});
export const MultipleDocumentTypeSchema = BaseDocumentTypeSchema.extend({
  multiple: z.literal(true),
});
export const SingleDocumentTypeSchema = MultipleDocumentTypeSchema.extend({
  multiple: z.literal(false),
  documentId: z.number().nullish(),
});

export const DocumentTypeSchema = z.discriminatedUnion("multiple", [
  MultipleDocumentTypeSchema,
  SingleDocumentTypeSchema,
]);

export const DocumentTypeListSchema = z.array(DocumentTypeSchema);

export type DocumentTypeModel = z.infer<typeof DocumentTypeSchema>;
export type DocumentTypeListModel = z.infer<typeof DocumentTypeListSchema>;
