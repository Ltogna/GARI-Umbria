import { z } from "zod";
import { LeadingSchema } from "./leadings";
import { ParcelSearchLevelSchema, ParcelSearchLevel } from "./settings";

export const ConductorFieldsSchema = z.object({
  titleTypeId: z.string(),
  dayFrom: z.date(),
  dayTo: z.date().optional(),
  description: z.string(),
});

export type ConductorFieldsModel = z.infer<typeof ConductorFieldsSchema>;

export const ParcelSearchFieldsSchema = z.object({
  partyCode: z.string().optional(),
  sectorCode: z.string().optional(),
  blockCode: z.string().optional(),
  parcelCode: z.string().optional(),
  subParcelCode: z.string().optional(),
  search_level: ParcelSearchLevelSchema.default(
    ParcelSearchLevel.SEARCH_ONLY_VALID,
  ),

  nextKey: z.string().nullable(),
});

export type ParcelSearchFieldsModel = z.infer<typeof ParcelSearchFieldsSchema>;

export const ParcelCheckableSchema = z.object({
  id: z.string().uuid(),
  sheetReferences: z.string(),
  surface_in_ha: z.number().min(0),
  leadings: z.array(LeadingSchema),
  checked: z.boolean().default(false),
});

export type ParcelCheckableModel = z.infer<typeof ParcelCheckableSchema>;
