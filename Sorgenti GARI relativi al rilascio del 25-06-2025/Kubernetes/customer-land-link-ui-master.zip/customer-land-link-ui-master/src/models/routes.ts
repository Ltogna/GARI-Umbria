const LAND_LINK = "cll:landLink";

export enum RouteName {
  LAND_LINK_LIST = `${LAND_LINK}:list`,
  LAND_LINK_DETAIL = `${LAND_LINK}:detail`,
  LAND_LINK_EDIT = `${LAND_LINK}:edit`,
  LAND_LINK_NEW = `${LAND_LINK}:new`,
  LAND_LINK_FILTER = `${LAND_LINK}:filter`,
  LAND_LINK_INFO = `${LAND_LINK}:info`,

  GROUP = "cll:group",
  GROUP_FILTER = `${GROUP}:filter`,
  GROUP_NEW = `${GROUP}:new`,
  GROUP_CLONE = `${GROUP}:clone`,
  GROUP_EDIT = `${GROUP}:edit`,
  GROUP_EDIT_BASE = `${GROUP_EDIT}:base`,
  GROUP_EDIT_DOC = `${GROUP_EDIT}:doc`,
  GROUP_EDIT_LANDLINK = `${GROUP_EDIT}:landLink`,
  GROUP_EDIT_LANDLINK_INFO = `${GROUP_EDIT}:landLink:info`,
  GROUP_NEW_MULTIPLE_DOC = `${GROUP_NEW}:multiple:doc`,
  GROUP_NEW_MULTIPLE_LANDLINK_INFO = `${GROUP_NEW}:multiple:info`,
  GROUP_EDIT_MULTIPLE_DOC = `${GROUP_EDIT}:multiple:doc`,
  GROUP_EDIT_MULTIPLE_LANDLINK_INFO = `${GROUP_EDIT}:multiple:info`,
  GROUP_ADD_PARCELS = `${GROUP}:add:parcels`,
  GROUP_BULK = `${GROUP}:bulk`,
  GROUP_BULK_FILTER = `${GROUP_BULK}:filter`,

  PARCEL_BULK = "cll:parcel:bulk",
  PARCEL_BULK_FILTER = `${PARCEL_BULK}:filter`,

  SUMMARY = "cll:summary",
}
