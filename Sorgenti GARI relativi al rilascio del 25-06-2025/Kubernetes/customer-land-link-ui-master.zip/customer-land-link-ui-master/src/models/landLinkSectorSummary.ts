import { z } from "zod";
import { SectorSchema } from "./parcel";
import { TitleTypeSchema } from "./titleTypes";

export const LandLinkTitleSummarySchema = z.object({
  titleType: TitleTypeSchema.nullable(),
  linkCount: z.number(),
  totParcelAreaSqm: z.number(),
  totTitleTypeAreaSqm: z.number(),
});

export const LandLinkSectorSummarySchema = z.object({
  sector: SectorSchema,
  linkCount: z.number(),
  totParcelAreaSqm: z.number(),
  totTitleTypeAreaSqm: z.number(),
  titleSummaryRes: z.array(LandLinkTitleSummarySchema).nullable(),
});

export const LandLinkSectorSummaryListSchema = z.array(
  LandLinkSectorSummarySchema,
);

export type LandLinkSectorSummaryModel = z.infer<
  typeof LandLinkSectorSummarySchema
>;
export type LandLinkSectorSummaryListModel = z.infer<
  typeof LandLinkSectorSummaryListSchema
>;
