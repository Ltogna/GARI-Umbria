import { z } from "zod";

export const TitleTypeSchema = z
  .object({
    id: z.number(),
    code: z.string(),
    dayToReq: z.boolean(),
    dayToEditable: z.boolean().nullish(),
    allowFutureDayFrom: z.boolean().default(false),
    i18nCode: z.string(),
  })
  .refine((data) => {
    if (data.dayToEditable === undefined) {
      data.dayToEditable = data.dayToReq;
    }
    return data;
  });
export const TitleTypesListSchema = z.array(TitleTypeSchema);

export type TitleTypeModel = z.infer<typeof TitleTypeSchema>;
export type TitleTypesListModel = z.infer<typeof TitleTypesListSchema>;
