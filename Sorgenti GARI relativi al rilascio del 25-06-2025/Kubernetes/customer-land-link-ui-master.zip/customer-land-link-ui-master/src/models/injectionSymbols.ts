import type { InjectionKey } from "vue";

export const hideRemoveButtonKey = Symbol(
  "hideRemoveButton",
) as InjectionKey<boolean>;
