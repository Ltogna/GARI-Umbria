import { z } from "zod";

export const AnomalyLevelSchema = z.enum(["DANGER", "WARN", "INFO"]);

export type AnomalyLevelModel = z.infer<typeof AnomalyLevelSchema>;

export const AnomalyTypeSchema = z.object({
  groupCode: z.string(),
  code: z.string(),
  i18nCode: z.string().nullable(),
});

export const AnomalySearchSchema = z.object({
  entityCode: z.string(),
  entityId: z.string(),
  type: AnomalyTypeSchema,
});

export type AnomalySearchModel = z.infer<typeof AnomalySearchSchema>;

// export const AnomalyResponseSchema = z.map(
//   AnomalyLevelSchema,
//   z.array(AnomalySearchSchema)
// );

//TODO: better implementation
export const AnomalyResponseSchema = z.object({
  INFO: z.array(AnomalySearchSchema).optional(),
  WARN: z.array(AnomalySearchSchema).optional(),
  DANGER: z.array(AnomalySearchSchema).optional(),
});

export type AnomalyResponseModel = z.infer<typeof AnomalyResponseSchema>;
