import { wktToGeoJSON } from "@terraformer/wkt";
import { format } from "date-fns";
import { z } from "zod";

export enum GeometryType {
  POLYGON = "Polygon",
  MULTI_POLYGON = "MultiPolygon",
  LINE_STRING = "LineString",
  POINT = "Point",
  LINEAR_RING = "LinearRing",
  MULTI_POINT = "MultiPoint",
  MULTI_LINE_STRING = "MultiLineString",
  GEOMETRY_COLLECTION = "GeometryCollection",
  CIRCLE = "Circle",
}

export const GeometryTypeKeySchema = z.nativeEnum(GeometryType);

const geoJsonPointSchema = z.object({
  type: z.literal(GeometryTypeKeySchema.enum.POINT),
  coordinates: z.tuple([z.number(), z.number()]),
});

const geoJsonLineStringSchema = z.object({
  type: z.literal(GeometryTypeKeySchema.enum.LINE_STRING),
  coordinates: z.array(z.tuple([z.number(), z.number()])),
});

const geoJsonPolygonSchema = z.object({
  type: z.literal(GeometryTypeKeySchema.enum.POLYGON),
  coordinates: z.array(z.array(z.tuple([z.number(), z.number()]))),
});

const geoJsonMultiPointSchema = z.object({
  type: z.literal(GeometryTypeKeySchema.enum.MULTI_POINT),
  coordinates: z.array(z.tuple([z.number(), z.number()])),
});

const geoJsonMultiLineStringSchema = z.object({
  type: z.literal(GeometryTypeKeySchema.enum.MULTI_LINE_STRING),
  coordinates: z.array(z.array(z.tuple([z.number(), z.number()]))),
});

const geoJsonMultiPolygonSchema = z.object({
  type: z.literal(GeometryTypeKeySchema.enum.MULTI_POLYGON),
  coordinates: z.array(z.array(z.array(z.tuple([z.number(), z.number()])))),
});

export const geoJsonSchema = z.discriminatedUnion("type", [
  geoJsonPointSchema,
  geoJsonLineStringSchema,
  geoJsonPolygonSchema,

  geoJsonMultiPointSchema,
  geoJsonMultiLineStringSchema,
  geoJsonMultiPolygonSchema,
]);

export type GeoJsonGeometryModel = z.infer<typeof geoJsonSchema>;

export const wktToGeoJSONSchema = z.preprocess((arg) => {
  if (typeof arg === "string") {
    try {
      return wktToGeoJSON(arg);
    } catch (err) {
      console.warn(err);
      return null;
    }
  }
  return null;
}, geoJsonSchema);

export type wktToGeoJSONSModel = z.infer<typeof wktToGeoJSONSchema>;

const DATE_PATTERN = /^(?<year>\d{4})(?<month>\d{2})(?<day>\d{2})$/;
/**
 * Acccept a format like _yyyyMMdd_ and return a `Date`
 */
export const stringToDate = z.preprocess((arg) => {
  if (typeof arg === "string") {
    const match = arg.match(DATE_PATTERN)?.groups;
    if (!match) {
      return new Date();
    }
    const date = new Date(+match.year, +match.month - 1, +match.day);
    if (isNaN(date.getTime())) {
      return new Date();
    }
    const timezone = date.getTimezoneOffset() * 60_000;
    return new Date(date.getTime() - timezone);
  }
}, z.date());

export const DATE_FORMAT = "yyyyMMdd";
/**
 * Accept a date or a number and return a string like _yyyyMMdd_
 *
 * if `arg` is a string and string has a format like _yyyyMMdd_ the return `arg`
 */
export const dateToString = z.preprocess((arg) => {
  if (arg instanceof Date || typeof arg === "number") {
    return format(arg, DATE_FORMAT);
  } else if (typeof arg === "string") {
    // eslint-disable-next-line @typescript-eslint/ban-ts-comment
    // @ts-ignore
    const match = arg.match(DATE_PATTERN)?.groups;
    if (!match) {
      const dateAsNumber = Date.parse(arg);
      return format(
        new Date(isNaN(dateAsNumber) ? "" : dateAsNumber),
        DATE_FORMAT,
      );
    }
    const date = new Date(+match.year, +match.month - 1, +match.day);
    if (isNaN(date.getTime())) {
      return format(new Date(), DATE_FORMAT);
    }
    return arg;
  }
  return format(new Date(), DATE_FORMAT);
}, z.string().or(z.number()));

export const PaginateListSchema = z.object({
  count: z.number(),
  records: z.array(z.any()),
  nextKey: z.string().nullable(),
});

export const EmptySchema = z.object({});
export type EmptyModel = z.infer<typeof EmptySchema>;

export const SelectSchema = z.object({
  id: z.string(),
  text: z.string(),
});

export type SelectModel = z.infer<typeof SelectSchema>;

export const SelectListSchema = z.array(SelectSchema);

export type SelectListModel = z.infer<typeof SelectListSchema>;
