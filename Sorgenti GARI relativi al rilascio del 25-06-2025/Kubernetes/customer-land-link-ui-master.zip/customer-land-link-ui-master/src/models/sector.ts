import { z } from "zod";

export const SectorSchema = z.object({
  id: z.number(),
  description: z.string(),
  shortDescr: z.string().nullable().optional(),
  sectorCode: z.string().nullable().optional(),
});

export const SectorListSchema = z.array(SectorSchema);

export type SectorModel = z.infer<typeof SectorSchema>;
export type SectorListModel = z.infer<typeof SectorListSchema>;
