import { z } from "zod";

/*
    public enum ParcelSearchLevel {
      SEARCH_ONLY_VALID, 
      SEARCH_OUTDATED,
      ADD_TEMP_PARCELS_IF_NOT_EXISTS
    }
  */

export enum ParcelSearchLevel {
  SEARCH_ONLY_VALID = "SEARCH_ONLY_VALID",
  SEARCH_OUTDATED = "SEARCH_OUTDATED",
  ADD_TEMP_PARCELS_IF_NOT_EXISTS = "ADD_TEMP_PARCELS_IF_NOT_EXISTS",
}

export const ParcelSearchLevelSchema = z.nativeEnum(ParcelSearchLevel);

export const CllSettingsSchema = z.object({
  lpisSubSeparator: z.string().nullable(),
  allowEditDayToParcelInThePast: z.boolean().nullable(),
  parcelSearchLevel: ParcelSearchLevelSchema.default(
    ParcelSearchLevel.SEARCH_ONLY_VALID,
  ),
});

export type CllSettingsModel = z.infer<typeof CllSettingsSchema>;
