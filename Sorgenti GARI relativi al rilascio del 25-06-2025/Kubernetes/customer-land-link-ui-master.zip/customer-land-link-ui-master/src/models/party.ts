import { z } from "zod";

/**
 * N = Natural
 * L = Legal
 */
const PartyTypeEnumSchema = z.enum(["N", "L"]);
export type PartyTypeEnum = z.infer<typeof PartyTypeEnumSchema>;

const GenderEnumSchema = z.enum(["M", "F"]);
export type GenderEnum = z.infer<typeof GenderEnumSchema>;

export const CountrySearchResponseSchema = z.object({
  code: z.string(),
  tenantId: z.string(),
  active: z.nullable(z.boolean()),
  i18nName: z.nullable(z.string()),
});

export const RegionSearchResponseSchema = CountrySearchResponseSchema.extend({
  countryCode: z.string(),
  shortDescr: z.string(),
  country: CountrySearchResponseSchema,
});

export const DistrictSearchResponseSchema = CountrySearchResponseSchema.extend({
  regionCode: z.string(),
  shortDescr: z.string(),
  region: RegionSearchResponseSchema,
});

export const MunicipalitySearchResponseSchema =
  CountrySearchResponseSchema.extend({
    districtCode: z.string(),
    shortDescr: z.string(),
    district: DistrictSearchResponseSchema,
  });

export const AddressSchema = z.object({
  id: z.number(),
  municipality: z.string().nullable(),
  locality: z.string().nullable(),
  street: z.string().nullable(),
  houseNumber: z.string().nullable(),
  postcode: z.string().nullable(),
  details: z.string().nullable(),
  note: z.string().nullable(),
  municipalityI18nCode: z.string().nullable(),
  districtShortDescr: z.string().nullable().optional(),
  municipalityDetail: MunicipalitySearchResponseSchema.nullable().optional(),
});

export const TagResponseSchema = z.object({
  id: z.number(),
  code: z.string(),
  i18nCode: z.nullable(z.string()),
});

export const PartyResponseSchema = z.object({
  id: z.number(),
  // partyType: PartyTypeEnumSchema.nullable(),
  // gender: z.nullable(GenderEnumSchema.or(z.undefined())),
  lastName: z.string(),
  firstName: z.nullable(z.string().or(z.undefined())),
  // taxCode: z.nullable(z.string().or(z.undefined())),
  code: z.string().nullable().optional(),
  // vatNumber: z.nullable(z.string().or(z.undefined())),
  // birthDate: z.nullable(z.string().or(z.undefined())),
  // deathDate: z.nullable(z.string().or(z.undefined())),
  // birthCountry: z.nullable(z.string().or(z.undefined())),
  // birthDistrict: z.nullable(z.string().or(z.undefined())),
  // birthCity: z.nullable(z.string().or(z.undefined())),
  // birthMunicipality: z.nullable(z.string().or(z.undefined())),
  // birthRegion: z.nullable(z.string().or(z.undefined())),
  // nationality: z.nullable(z.string().or(z.undefined())),
  // addressResidential: AddressSchema.nullable().optional(),
  // addressHome: AddressSchema.nullable().optional(),
  // addressBilling: AddressSchema.nullable().optional(),
  // archived: z.boolean(),
  // tags: z.array(TagResponseSchema).nullish(),
});
export type PartyModel = z.infer<typeof PartyResponseSchema>;
