import { z } from "zod";
import { getNextPagedResultsSchema } from "@abaco/safe-rest/src/pagination";
import { AnomalyLevelSchema } from "./anomalyLevel";

export const LandLinkResSchema = z.object({
  id: z.number(),
  groupId: z.number(),
  partyId: z.number(),
  titleTypeId: z.number(),
  titleTypePerc: z.number(),
  parcelId: z.number(),
  sectorCode: z.string(),
  blockCode: z.string(),
  parcelCode: z.string(),
  subParcelCode: z.string(),
  dayFrom: z.string(),
  dayTo: z.string(),
  maxAnomalyLevel: AnomalyLevelSchema,
  anomalyCount: z.number().nullish(), //? remove nullish
  areaSqm: z.number(),
});

export const ListResultsLandLinkResSchema =
  getNextPagedResultsSchema(LandLinkResSchema);

export type LandLinkResModel = z.infer<typeof LandLinkResSchema>;
export type ListResultsLandLinkResModel = z.infer<
  typeof ListResultsLandLinkResSchema
>;

export const LandLinkBatchCreateReqSchema = z.object({
  titleTypePerc: z.number(),
  parcelId: z.number(),
  sectorCode: z.string(),
  blockCode: z.string(),
  parcelCode: z.string(),
  subParcelCode: z.string(),
});

export const LandLinkListBatchCreateReqSchema = z.array(
  LandLinkBatchCreateReqSchema,
);

export type LandLinkBatchCreateReqModel = z.infer<
  typeof LandLinkBatchCreateReqSchema
>;

export type LandLinkListBatchCreateReqModel = z.infer<
  typeof LandLinkListBatchCreateReqSchema
>;

export const SimpleLandLinkSchema = z.object({
  titleTypePerc: z.number().min(0.01).max(100),
  parcelId: z.number(),
});

export type SimpleLandLinkModel = z.infer<typeof SimpleLandLinkSchema>;
