import { BASE, MODULE_ID } from "@/constants";
import { http } from "@/resources/api/http";
import { ErrorType } from "@abaco/safe-rest/src/HTTPClient";
import { nextTick } from "vue";
import { createI18n } from "vue-i18n";

export const DEFAULT_LANGUAGE = "en";

const i18n = createI18n({
  legacy: false,
  locale: DEFAULT_LANGUAGE,
  fallbackLocale: DEFAULT_LANGUAGE,
  // XXX WARNING
  // missingWarn: false,
  // fallbackWarn: false,
  datetimeFormats: {
    it: {
      short: {
        year: "numeric",
        month: "short",
        day: "numeric",
      },
      long: {
        year: "numeric",
        month: "long",
        day: "numeric",
        weekday: "long",
        hour: "numeric",
        minute: "numeric",
      },
    },
    en: {
      short: {
        year: "numeric",
        month: "short",
        day: "numeric",
      },
      long: {
        year: "numeric",
        month: "long",
        day: "numeric",
        weekday: "long",
        hour: "numeric",
        minute: "numeric",
      },
    },
  },
});

export function setI18nLanguage(locale: string) {
  // WARNING: datetimeFormats can't be loaded in lazyloading, but hardcoding it change the type of global.locale
  // eslint-disable-next-line @typescript-eslint/ban-ts-comment
  // @ts-ignore
  i18n.global.locale.value = locale;

  /**
   * NOTE:
   * If you need to specify the language setting for headers, such as the `fetch` API, set it here.
   * The following is an example for axios.
   *
   * axios.defaults.headers.common['Accept-Language'] = locale
   */
  document.querySelector("html")?.setAttribute("lang", locale);
}

function getAllLocales(locale: string): Set<string> {
  const ls = locale.replace("_", "-").split("-");
  const locales = new Set<string>([DEFAULT_LANGUAGE]);
  let loc = "";
  for (let i = 0; i < ls.length; i++) {
    loc += "-" + ls[i];
    locales.add(loc.slice(1));
  }
  return locales;
}

function getExtraTranslations(): Record<string, string> {
  try {
    if (import.meta.env.VITE_EXTRA_STRANSLATIONS) {
      return JSON.parse(atob(import.meta.env.VITE_EXTRA_STRANSLATIONS));
    }
  } catch (e) {
    // console.log(e);
  }

  try {
    if (import.meta.env.VITE_EXTRA_STRANSLATIONS) {
      return JSON.parse(import.meta.env.VITE_EXTRA_STRANSLATIONS);
    }
  } catch (e) {
    // console.log(e);
  }

  return {};
}

export async function loadLocaleMessages(locale: string) {
  const lcs = [...getAllLocales(locale)];
  for (let i = 0; i < lcs.length; i++) {
    const res = await http.get(`${BASE}locales/${lcs[i]}.json`);
    if (res.errorType == ErrorType.NONE) {
      try {
        const messages = await res.response.json();
        i18n.global.mergeLocaleMessage(lcs[lcs.length - 1], messages);
      } catch {
        console.warn(`Error parsing ${lcs[i]}.json`);
      }
    } else {
      console.error(res);
    }
  }

  const extraTranslations = getExtraTranslations();
  for (let i = 0; i < lcs.length; i++) {
    const messages = extraTranslations[lcs[i]];
    if (messages) {
      i18n.global.mergeLocaleMessage(lcs[lcs.length - 1], {
        [MODULE_ID]: messages,
      });
    }
  }

  const res = await http.get(`${BASE}extra-translations.json`);
  if (res.errorType == ErrorType.NONE) {
    try {
      const messages = await res.response.json();
      for (let i = 0; i < lcs.length; i++) {
        const message = messages[lcs[i]];
        if (message) {
          i18n.global.mergeLocaleMessage(lcs[lcs.length - 1], {
            [MODULE_ID]: message,
          });
        }
      }
    } catch (err) {
      console.warn(err);
    }
  } else {
    console.warn(res);
  }

  setI18nLanguage(lcs[lcs.length - 1]);
  return nextTick();
}

export default i18n;
