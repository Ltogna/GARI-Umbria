import type { GlobalConfigInterface } from "just-validate/dist/modules/interfaces";

export const justValidateConfig: Partial<GlobalConfigInterface> = {
  errorFieldCssClass: "is-invalid",
  errorLabelCssClass: "form-feedback",
  errorLabelStyle: "",
  focusInvalidField: true,
};

export function getFieldSelector(formId: string, fieldName: string): string {
  return `#${formId} [name='${fieldName}']`;
}
