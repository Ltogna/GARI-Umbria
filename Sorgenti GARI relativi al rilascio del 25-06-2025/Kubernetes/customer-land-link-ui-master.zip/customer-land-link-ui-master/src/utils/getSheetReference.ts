import type { ParcelModel } from "@/models/parcel";

export function getSheetReference(
  parcel: ParcelModel,
  showParcelId?: boolean,
  hideCity?: boolean,
): string {
  const data: string[] = [];
  if (parcel.sector) {
    // parcel.sector.sector_istat && data.push(parcel.sector.sector_istat); // esiste sul mockup ma per adesso non serve
    parcel.sector.sectorCode && data.push(parcel.sector.sectorCode);
    parcel.sector.shortDescr &&
      !hideCity &&
      data.push(parcel.sector.shortDescr);
  }
  if (parcel.block) {
    parcel.block.shortDescr && data.push(parcel.block.shortDescr);
  }
  if (showParcelId) {
    parcel.parcel && data.push(parcel.parcel);
  }

  return data.join(" - ");
}
