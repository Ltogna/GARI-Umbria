/**
 * @param  {number} x
 * @returns number
 *
 * ### Converts area from square meters to hectares
 *
 * ```javascript
 *  Utils.convertAreainHA(123456);
 * // 12.3556
 * ```
 * */
export const convertAreaSQMInHA = function (x: number): number {
  const area = x ? x / 10_000 : 0;
  return area;
};

export const intlNumberFormatOptions: Intl.NumberFormatOptions = {
  minimumFractionDigits: 4,
  maximumFractionDigits: 4,
};

export const percNumberFormatOption: Intl.NumberFormatOptions = {
  minimumFractionDigits: 0,
  maximumFractionDigits: 2,
};
