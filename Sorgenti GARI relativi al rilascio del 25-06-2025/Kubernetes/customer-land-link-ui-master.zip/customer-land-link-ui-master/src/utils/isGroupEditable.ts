import { type GroupResModel } from "@/models/groups";
import type { LandLinkModel } from "@/models/landLink";
import { isWithinInterval } from "date-fns";
import { removeTimezone } from "./removeTimezone";

export function isEditable(group: GroupResModel | LandLinkModel) {
  const start = removeTimezone(group.dayFrom);
  const now = removeTimezone(new Date());
  const end = removeTimezone(group.dayTo);

  // #141156 #148893 included end of the day
  return isWithinInterval(now, { start, end });
}
