export function removeTimezone(date: Date | string) {
  const _date = new Date(date);
  const timezone = _date.getTimezoneOffset() * 60_000;
  return new Date(_date.getTime() - timezone).setHours(0, 0, 0, 0);
}
