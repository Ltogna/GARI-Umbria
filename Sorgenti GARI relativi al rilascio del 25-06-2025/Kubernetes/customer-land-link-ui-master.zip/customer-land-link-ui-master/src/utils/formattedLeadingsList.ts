import type { LeadingModel } from "@/models/leadings";

export function formattedLeadingsList(leadingsList: LeadingModel[]): string {
  const data: Set<string> = new Set();

  leadingsList.forEach((leading) => {
    if (leading.party.code) data.add(leading.party.code);
    else {
      if (leading.party.firstName) data.add(leading.party.firstName);
      if (leading.party.lastName) data.add(leading.party.lastName);
    }
    // if (leading.party.partyType === "N" && leading.party.taxCode) {
    //   data.push(leading.party.taxCode);
    // } else if (leading.party.partyType === "L" && leading.party.vatNumber) {
    //   data.push(leading.party.vatNumber);
    // } else {
    //   data.push(leading.partyId.toString());
    // }
  });
  return data.size > 0 ? [...data].join(" - ") : "";
}
