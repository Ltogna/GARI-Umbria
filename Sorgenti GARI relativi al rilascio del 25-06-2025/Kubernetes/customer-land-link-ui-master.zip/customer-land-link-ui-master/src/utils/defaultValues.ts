import {
  type ConductorFieldsModel,
  type ParcelSearchFieldsModel,
} from "@/models/groupFilter";
import { ParcelSearchLevel } from "@/models/settings";

export const DEFAULT_PARCEL_FILTER: ParcelSearchFieldsModel = {
  partyCode: "",
  sectorCode: "",
  blockCode: "",
  parcelCode: "",
  subParcelCode: "",
  search_level: ParcelSearchLevel.SEARCH_ONLY_VALID,

  nextKey: null,
};

export const DEFAULT_CONDUCTOR_FORM: ConductorFieldsModel = {
  titleTypeId: "",
  dayFrom: new Date(),
  dayTo: undefined,
  description: "",
};

export const DEFAULT_ADD_GROUP_STATE_RESET = {
  selectedParcelId: null,
  conduction: structuredClone(DEFAULT_CONDUCTOR_FORM),
  parcelFilter: structuredClone(DEFAULT_PARCEL_FILTER),
  infiniteConductedParcels: null,
  conductedParcelsList: [],
  conductedParcelsListSelected: [],
  mappedParcelsList: [],
  conductionPercentage: 100,
  hasError: false,
};
