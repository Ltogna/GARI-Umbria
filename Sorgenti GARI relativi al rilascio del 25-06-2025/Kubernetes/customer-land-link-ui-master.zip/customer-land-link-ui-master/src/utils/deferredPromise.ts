export type DeferredPromise<T, K = unknown> = {
  promise: Promise<T>;
  pending: Promise<boolean>;
  resolve: (arg: T) => void;
  reject: (arg?: K) => void;
};

// eslint-disable-next-line @typescript-eslint/no-explicit-any
export default function deferred<T, K = unknown>(): DeferredPromise<T, K> {
  let resolver: ((pending: boolean) => void) | null = null;
  const ret: Partial<DeferredPromise<T, K>> = {
    pending: new Promise<boolean>((resolve) => (resolver = resolve)),
  };

  ret.promise = new Promise((resolve, reject) => {
    ret.resolve = resolve;
    ret.reject = reject;
  });

  ret.promise.finally(() => resolver && resolver(false));

  return ret as DeferredPromise<T, K>;
}
