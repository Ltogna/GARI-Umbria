import { MODULE_ID } from "@/constants";
import { LPIS_VIEWER_MODULE_ID } from "@/main";
import { isStandalone } from "./isStandalone";

/**
 * Gets the base URL of the portal application.
 *
 * This function attempts to determine the base URL of the portal application by
 * examining the current browser location and the value of the `MODULE_ID` constant.
 *
 * - If the current URL path contains the `MODULE_ID` value (e.g., `/customer-land-link`), the base URL is
 *   extracted by splitting the URL at the first occurrence of the `MODULE_ID` and returning the leading part.
 *   (Example: `https://app.example.com/portal/customer-land-link/application` would return `https://app.example.com/portal`)
 * - Otherwise, it falls back to using `window.location.origin`, which returns the
 *   protocol, hostname, and port of the current origin.
 *
 * @returns {string} The base URL of the portal application.
 *
 * @example
 * Assuming `MODULE_ID` is set to `"customer-land-link"`:
 *
 * ```typescript
 * console.log(getPortalBaseURL()); // Output: "[https://app.example.com/portal](https://app.example.com/portal)" (if the URL is [https://app.example.com/portal/customer-land-link/application](https://app.example.com/portal/customer-land-link/application))
 * console.log(getPortalBaseURL()); // Output: "[https://app.example.com](https://app.example.com)" (if the URL is [https://app.example.com/customer-land-link/application](https://app.example.com/customer-land-link/application))
 * console.log(getPortalBaseURL()); // Output: "[https://app.example.com](https://app.example.com)" (if the URL is [invalid URL removed])
 * ```
 */
export function getPortalBaseURL() {
  const parentModuleDeployDir = MODULE_ID;
  const basePath =
    window.location.href.indexOf(`/${parentModuleDeployDir}`) > -1
      ? window.location.href.split(`/${parentModuleDeployDir}`)[0]
      : window.location.origin;
  return basePath;
}

export function getPortalBaseLpisViewerURL() {
  if (isStandalone && import.meta.env.VITE_DEV_LPIS_VIEWER_MODULE_BASE_URL) {
    return import.meta.env.VITE_DEV_LPIS_VIEWER_MODULE_BASE_URL;
  }
  return `${getPortalBaseURL()}/${LPIS_VIEWER_MODULE_ID}`;
}
