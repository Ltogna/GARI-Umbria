export default function scrollToElement(idElement: string) {
  const element = document.getElementById(idElement);
  element && element.scrollIntoView();
}
