export const isStandalone = import.meta.env.MODE === "standalone";
