import { getPortalBaseLpisViewerURL } from "./urlUtils";

// eslint-disable-next-line @typescript-eslint/no-unused-vars
export function gotoViewer(parcelId: number, _basePath: string): void {
  window.open(
    `${getPortalBaseLpisViewerURL()}/parcel/${parcelId}?hideBackButton=true`,
    "_blank",
  );
}
