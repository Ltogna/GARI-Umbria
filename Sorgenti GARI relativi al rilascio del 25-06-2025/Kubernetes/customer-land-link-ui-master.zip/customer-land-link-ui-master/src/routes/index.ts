import { RouteName } from "@/models/routes";
import { isStandalone } from "@/utils/isStandalone";
import type { RouteRecordRaw } from "vue-router";

const routes: RouteRecordRaw[] = [];

routes.push({
  path: "/party/summary",
  name: RouteName.SUMMARY,
  component: () => import("../views/LandLinkSummaryView.vue"),
});

routes.push({
  path: "/party/:partyId/bulk/parcel",
  name: RouteName.PARCEL_BULK,
  component: () => import("../views/ParcelBulkView.vue"),
});

routes.push({
  path: "/party/:partyId/bulk/parcel/filter",
  name: RouteName.PARCEL_BULK_FILTER,
  component: () => import("../views/LandLinkBulkFilterView.vue"),
});

//#region LandLink section
routes.push({
  path: "/party/:partyId/landLink",
  component: () => import("../views/LandLinkView.vue"),
  children: [
    {
      path: "",
      name: RouteName.LAND_LINK_LIST,
      component: () => import("../views/LandLinkListView.vue"),
    },
    {
      path: "detail/:landlinkId",
      name: RouteName.LAND_LINK_DETAIL,
      components: {
        default: () => import("../views/LandLinkDetailView.vue"),
        accordionInfo: () =>
          import("../components/AdditionalInfoAccordion.vue"),
      },
    },
    {
      path: "edit/:landlinkId",
      name: RouteName.LAND_LINK_EDIT,
      components: {
        default: () => import("../views/LandLinkFormView.vue"),
        accordionInfo: () =>
          import("../components/AdditionalInfoAccordion.vue"),
      },
    },
    {
      path: "new",
      name: RouteName.LAND_LINK_NEW,
      component: () => import("../views/LandLinkFormView.vue"),
    },
    {
      path: "filter",
      name: RouteName.LAND_LINK_FILTER,
      component: () => import("../views/LandLinkFilterView.vue"),
    },
    {
      path: ":landlinkId/docInfo/:infoType",
      name: RouteName.LAND_LINK_INFO,
      components: {
        default: () =>
          import(
            "../components/dynamic-document/DynamicLandLinkDocumentWrapper.vue"
          ),
        accordionInfo: () =>
          import("../components/AdditionalInfoAccordion.vue"),
      },
    },
  ],
});
//#endregion

routes.push({
  path: "/party/:partyId/bulk/group",
  component: () => import("../views/GroupBulkView.vue"),
  children: [
    {
      path: "",
      name: RouteName.GROUP_BULK,
      component: () =>
        import("../components/group/GroupListBulkMainContent.vue"),
    },
    {
      path: "filter",
      name: RouteName.GROUP_BULK_FILTER,
      components: {
        default: () => import("../components/group/GroupFilterMainContent.vue"),
        backButton: () =>
          import("../components/group/GroupFilterBackButton.vue"),
      },
    },
  ],
});

//#region GROUP
routes.push({
  path: "/party/:partyId/group",
  components: {
    default: () => import("../views/GroupView.vue"),
    leaveConfirmationModal: () =>
      import("../components/LeaveDirtyPageModal.vue"),
  },
  children: [
    {
      path: "",
      name: RouteName.GROUP,
      component: () => import("../components/group/GroupListMainContent.vue"),
    },
    {
      path: "filter",
      name: RouteName.GROUP_FILTER,
      components: {
        default: () => import("../components/group/GroupFilterMainContent.vue"),
        backButton: () =>
          import("../components/group/GroupFilterBackButton.vue"),
      },
    },
    {
      path: "new",
      name: RouteName.GROUP_NEW,
      component: () =>
        import("../components/add-group/AddGroupMainContent.vue"),
    },
    {
      path: ":groupId",
      name: RouteName.GROUP_EDIT_BASE,
      components: {
        default: () =>
          import("../components/edit-group/EditGroupMainWrapper.vue"),
        accordion: () => import("../components/group/DocumentAccordion.vue"),
        accordionInfo: () =>
          import("../components/AdditionalInfoAccordion.vue"),
        backButton: () =>
          import("../components/group/GroupFilterBackButton.vue"),
      },
      children: [
        {
          path: "edit",
          name: RouteName.GROUP_EDIT,
          component: () =>
            import("../components/edit-group/EditGroupMainContent.vue"),
        },
        //#region groupDocument
        {
          path: "doc/:docType",
          name: RouteName.GROUP_EDIT_DOC,
          component: () =>
            import("../components/dynamic-document/DynamicDocumentWapper.vue"),
        },
        {
          path: "doc/:docType/new",
          name: RouteName.GROUP_NEW_MULTIPLE_DOC,
          component: () =>
            import("../components/dynamic-document/DynamicDocumentWapper.vue"),
        },
        {
          path: "doc/:docType/edit/:docId",
          name: RouteName.GROUP_EDIT_MULTIPLE_DOC,
          component: () =>
            import("../components/dynamic-document/DynamicDocumentWapper.vue"),
        },
        //#endregion
        {
          path: "landLink/edit/:landlinkId",
          name: RouteName.GROUP_EDIT_LANDLINK,
          component: () => import("../views/LandLinkFormView.vue"),
        },
        //#region LandLinkDocument
        {
          path: "landLink/:landlinkId/docInfo/:infoType",
          name: RouteName.GROUP_EDIT_LANDLINK_INFO,
          component: () =>
            import(
              "../components/dynamic-document/DynamicLandLinkDocumentWrapper.vue"
            ),
        },
        {
          path: "landLink/:landlinkId/docInfo/:infoType/new",
          name: RouteName.GROUP_NEW_MULTIPLE_LANDLINK_INFO,
          component: () =>
            import(
              "../components/dynamic-document/DynamicLandLinkDocumentWrapper.vue"
            ),
        },
        {
          path: "landLink/:landlinkId/docInfo/:infoType/edit/:docId",
          name: RouteName.GROUP_EDIT_MULTIPLE_LANDLINK_INFO,
          component: () =>
            import(
              "../components/dynamic-document/DynamicLandLinkDocumentWrapper.vue"
            ),
        },
        //#endregion LandLinkDocument
      ],
    },
    {
      path: ":groupId/clone",
      name: RouteName.GROUP_CLONE,
      component: () =>
        import("../components/clone-group/CloneGroupMainContent.vue"),
    },
    {
      path: ":groupId/add/parcels",
      name: RouteName.GROUP_ADD_PARCELS,
      component: () =>
        import(
          "../components/add-parcels-group/AddParcelsGroupMainContent.vue"
        ),
    },
  ],
});
//#endregion

if (isStandalone) {
  routes.push({
    redirect: { name: RouteName.GROUP, params: { partyId: "32" } },
    path: "/",
  });
}

export default routes;
