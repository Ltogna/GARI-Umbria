import { getFieldSelector, justValidateConfig } from "@/utils/formUtils";
import JustValidate from "just-validate";
import type { FieldRuleInterface } from "just-validate/dist/modules/interfaces";

const conductorFormValidatorConfig = (
  t: (s: string) => string,
  moduleId: string,
  formRef: HTMLFormElement,
): JustValidate =>
  new JustValidate(formRef, justValidateConfig)
    .addField(getFieldSelector(formRef.id, "titleTypeId"), [
      {
        rule: "required",
        errorMessage: t(`${moduleId}.errors.fieldRequired`),
      } as FieldRuleInterface,
    ])
    .addField(getFieldSelector(formRef.id, "dayFrom"), [
      {
        rule: "required",
        errorMessage: t(`${moduleId}.errors.fieldRequired`),
      } as FieldRuleInterface,
    ]);

export default conductorFormValidatorConfig;
