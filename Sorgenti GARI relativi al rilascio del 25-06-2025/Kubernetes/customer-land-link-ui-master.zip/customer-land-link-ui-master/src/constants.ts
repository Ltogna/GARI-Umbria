export const BASE = "/ui/customer-land-link/";
export const MODULE_ID = "customer-land-link";
export const INFINITE_DATE = "99991231";

export const DEFAULT_DATE_FORMAT = "dd/MM/yyyy";

export const CLL_SERVER_API_PREFIX = "/customer-land-link";
