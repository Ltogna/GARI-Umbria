import scanner from "sonarqube-scanner";
import { config } from "dotenv";

config({
  path: [".env.local", ".env"],
});

const options: Record<string, string> = {
  "sonar.projectName": "customer-land-link-ui",
  "sonar.projectDescription": "Description customer-land-link-ui",
  "sonar.sources": "src",
};

if (process.env.SONARQUBE_BASE_URL) {
  if (process.env.SONARQUBE_LOGIN) {
    options["sonar.login"] = process.env.SONARQUBE_LOGIN;
  }
  scanner(
    {
      serverUrl: process.env.SONARQUBE_BASE_URL,
      token: process.env.SONARQUBE_TOKEN,
      options,
    },
    (error) => {
      if (error) {
        console.error(error);
      }
      process.exit();
    },
  );
}
