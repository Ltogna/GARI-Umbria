# LPIS EDITOR UI

## [CHANGELOG](CHANGELOG.md)

## Project setup

1. If you are already logged in to ABACO private repository npm-group skip to step 4.

```
npm login --registry=https://nexus.fe.abacogroup.eu/repository/npm-group/
```

2. Insert the SSO Credential for the nexus repository when prompted.
3. Insert your email when prompted
4. Install the project dependecies.

```
npm ci
```

Done

## description

This template should help get you started developing with Vue 3 in Vite.

## Recommended IDE Setup

[VSCode](https://code.visualstudio.com/) + [Volar](https://marketplace.visualstudio.com/items?itemName=Vue.volar) (and disable Vetur) + [TypeScript Vue Plugin (Volar)](https://marketplace.visualstudio.com/items?itemName=Vue.vscode-typescript-vue-plugin).

## Type Support for `.vue` Imports in TS

TypeScript cannot handle type information for `.vue` imports by default, so we replace the `tsc` CLI with `vue-tsc` for type checking. In editors, we need [TypeScript Vue Plugin (Volar)](https://marketplace.visualstudio.com/items?itemName=Vue.vscode-typescript-vue-plugin) to make the TypeScript language service aware of `.vue` types.

If the standalone TypeScript plugin doesn't feel fast enough to you, Volar has also implemented a [Take Over Mode](https://github.com/johnsoncodehk/volar/discussions/471#discussioncomment-1361669) that is more performant. You can enable it by the following steps:

1. Disable the built-in TypeScript Extension
   1. Run `Extensions: Show Built-in Extensions` from VSCode's command palette
   2. Find `TypeScript and JavaScript Language Features`, right click and select `Disable (Workspace)`
2. Reload the VSCode window by running `Developer: Reload Window` from the command palette.

## Customize configuration

See [Vite Configuration Reference](https://vitejs.dev/config/).

## Project Setup

```sh
npm install
```

### Compile and Hot-Reload for Development

```sh
npm run dev
```

### Type-Check, Compile and Minify for Production

```sh
npm run build
```

### Run Unit Tests with [Vitest](https://vitest.dev/)

```sh
npm run test:unit
```

### Lint with [ESLint](https://eslint.org/)

```sh
npm run lint
```

## Customer-land-link forms

This project includes three forms named "ConductorForm", each of which serves a specific role in the group management process:

- **[src/components/add-group/ConductorForm.vue](src/components/add-group/ConductorForm.vue)**: This module is used to add a new group.
- **[src/components/edit-group/ConductorForm.vue](src/components/edit-group/ConductorForm.vue)**: This module allows you to edit the information of an existing group.
- **[src/components/clone-group/ConductorForm.vue](src/components/clone-group/ConductorForm.vue)**: This module allows you to clone an existing group.
- **[src/components/add-parcels-group/ConductorForm.vue](src/components/add-parcels-group/ConductorForm.vue)**: This module is readonly when a parcel is added on group.
