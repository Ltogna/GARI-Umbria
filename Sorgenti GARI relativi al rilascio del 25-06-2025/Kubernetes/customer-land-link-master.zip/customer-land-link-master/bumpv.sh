#!/bin/bash

# Funzione per dividere la versione
function split_version() {
  version=$1
  major=$(echo $version | cut -d. -f1)
  minor=$(echo $version | cut -d. -f2)
  patch=$(echo $version | cut -d. -f3)
}

# Funzione per incrementare la versione di una major
function increase_major() {
  major=$((major + 1))
  minor=0
  patch=0
}

# Funzione per incrementare la versione di una minor
function increase_minor() {
  minor=$((minor + 1))
  patch=0
}

# Funzione per incrementare la versione di una patch
function increase_patch() {
  patch=$((patch + 1))
}

# Leggi la versione attuale dal file pom.xml
current_version=$(mvn help:evaluate -Dexpression=project.version -q -DforceStdout)
#current_version=$(grep -oP "<version>\K[^<]+" pom.xml)

# Dividi la versione in major, minor e patch
split_version $current_version

# Leggi l'opzione di incremento dalla riga di comando (major, minor o patch)
increment_option=$1

# Incrementa la versione corrispondente all'opzione specificata
case $increment_option in
  major)
    increase_major
    ;;
  minor)
    increase_minor
    ;;
  patch)
    increase_patch
    ;;
  *)
    echo "Opzione di incremento non valida. Utilizzo: script.sh [major|minor|patch]"
    exit 1
    ;;
esac

# Componi la nuova versione
new_version="$major.$minor.$patch"

# Aggiorna la versione nel file pom.xml
#sed -i "s/<version>$current_version<\/version>/<version>$new_version<\/version>/" pom.xml

mvn versions:set -DnewVersion=$new_version
mvn versions:commit


echo "Versione aggiornata: $new_version"


readmeFile="README.md"
line=$(grep -m 1 -n "_version: v" $readmeFile | cut -d : -f 1)

# Sovrascrivere la linea con la versione solo se la grep ha trovato una corrispondenza e la variabile line non è vuota
if [ $? -eq 0 ] && [ -n "$line" ]; then
  sed -i "${line}s/.*/_version: v${new_version}_/" $readmeFile
  echo "aggiornato $readmeFile"
fi


