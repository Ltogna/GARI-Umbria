#!/bin/bash

set -e
set -u

# Perform all actions as $POSTGRES_USER
export PGUSER="$POSTGRES_USER"


function create_user_and_database() {
#    params=$(echo $1 | tr ':' '\n')
    IFS=':' read -r -a params <<< "$1"
    username=${params[0]}
    password=${params[1]}
    database=${params[2]}
	echo "  Creating database '$database' "
  echo "  Creating user '$username' "
  echo "  Creating psw '$password' "

  psql --username "$POSTGRES_USER" -c "CREATE ROLE $username LOGIN PASSWORD '$password' CREATEDB VALID UNTIL 'infinity';" || true

  psql -v ON_ERROR_STOP=1 --username "$POSTGRES_USER" <<-EOSQL
      CREATE DATABASE $database;
      GRANT ALL PRIVILEGES ON DATABASE $database TO $username;
EOSQL

  psql -v ON_ERROR_STOP=1 --username "$POSTGRES_USER" -d $database <<-EOSQL
      GRANT ALL ON SCHEMA public TO $username;
EOSQL

}

function add_postgis_extension() {
#    params=$(echo $1 | tr ':' '\n')
    IFS=':' read -r -a params <<< "$1"
    username=${params[0]}
    password=${params[1]}
    database=${params[2]}
  echo "Loading PostGIS extensions into $database"
  psql --dbname="$database" <<-EOSQL
          CREATE EXTENSION IF NOT EXISTS postgis;
          CREATE EXTENSION IF NOT EXISTS postgis_topology;
          -- Reconnect to update pg_setting.resetval
          -- See https://github.com/postgis/docker-postgis/issues/288
          \c
          CREATE EXTENSION IF NOT EXISTS fuzzystrmatch;
          CREATE EXTENSION IF NOT EXISTS postgis_tiger_geocoder;
EOSQL
}


if [ -n "$POSTGRES_MULTIPLE_DATABASES" ]; then
    echo "Multiple database creation requested: $POSTGRES_MULTIPLE_DATABASES"
    for DB in $(echo $POSTGRES_MULTIPLE_DATABASES | tr ',' ' '); do
        create_user_and_database $DB
        add_postgis_extension $DB
    done
    echo "Multiple databases created"
fi

