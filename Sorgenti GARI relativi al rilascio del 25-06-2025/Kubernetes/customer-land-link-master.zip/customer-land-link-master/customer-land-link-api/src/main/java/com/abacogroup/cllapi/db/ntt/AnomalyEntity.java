package com.abacogroup.cllapi.db.ntt;

import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.jdbi.model.AuditEntity;
import java.time.LocalDateTime;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder(setterPrefix = "set")
@NoArgsConstructor
@AllArgsConstructor
public class AnomalyEntity implements AuditEntity {

  private Long id;

  private String tenantId;

  private String typeGroupCode;

  private String typeCode;

  private String entityCode;

  private String entityId;

  private AbsoluteDate validFrom;

  private AbsoluteDate validTo;

  private LocalDateTime dtInsert;

  private String userIdInsert;

  private LocalDateTime dtDelete;

  private String userIdDelete;

}
