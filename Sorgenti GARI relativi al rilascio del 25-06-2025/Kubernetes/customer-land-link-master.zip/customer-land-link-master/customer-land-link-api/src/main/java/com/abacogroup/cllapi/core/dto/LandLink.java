package com.abacogroup.cllapi.core.dto;

public interface LandLink {

	Long getId();
	Long getPartyId();
	Long getGroupId();
	Long getParcelId();
}
