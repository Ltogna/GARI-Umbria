package com.abacogroup.common.service;

import com.abacogroup.jdbi.EnhancedSqlObject;
import com.abacogroup.jdbi.model.AuditEntity;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.Objects;
import java.util.function.Consumer;
import java.util.function.Function;

public class AuditHelper {

	public static <E extends AuditEntity> void setAuditForInsert(E audit, String currentUser, EnhancedSqlObject dao) {
		audit.setUserIdInsert(currentUser);
		audit.setDtInsert(dao.getCurrentTimestamp());
		audit.setDtDelete(AuditEntity.dateActive);
		audit.setUserIdDelete(null);
	}

	public static <E extends AuditEntity> void setAuditForInsert(String currentUser, EnhancedSqlObject dao, E... list) {
		LocalDateTime now = dao.getCurrentTimestamp();
		Arrays.stream(list)
				.filter(Objects::nonNull)
				.forEach(audit -> {

					audit.setUserIdInsert(currentUser);
					audit.setDtInsert(now);
					audit.setDtDelete(AuditEntity.dateActive);
					audit.setUserIdDelete(null);
				});

	}

	public static <E extends AuditEntity> void setAuditForExpire(String currentUser, EnhancedSqlObject dao, E... list) {
		LocalDateTime now = dao.getCurrentTimestamp();
		Arrays.stream(list)
				.filter(Objects::nonNull)
				.forEach(audit -> {
					audit.setDtDelete(now);
					audit.setUserIdDelete(currentUser);
				});
	}

	public static <E extends AuditEntity> Long update(E audit, String currentUser,
			Consumer<E> expireConsumer,
			Function<E, Long> insertFunction,
			LocalDateTime currentTimestamp) {

		LocalDateTime expireTime = currentTimestamp;

		audit.setDtDelete(expireTime.minusSeconds(1));
		audit.setUserIdDelete(currentUser);

		expireConsumer.accept(audit);

		audit.setDtInsert(expireTime);
		audit.setDtDelete(AuditEntity.dateActive);
		audit.setUserIdInsert(currentUser);
		audit.setUserIdDelete(null);

		return insertFunction.apply(audit);
	}

	public static <E extends AuditEntity> void expire(E audit, String currentUser,
			Consumer<E> expireConsumer,
			LocalDateTime currentTimestamp) {

		LocalDateTime expireTime = currentTimestamp;

		audit.setDtDelete(expireTime.minusSeconds(1));
		audit.setUserIdDelete(currentUser);

		expireConsumer.accept(audit);

	}
}
