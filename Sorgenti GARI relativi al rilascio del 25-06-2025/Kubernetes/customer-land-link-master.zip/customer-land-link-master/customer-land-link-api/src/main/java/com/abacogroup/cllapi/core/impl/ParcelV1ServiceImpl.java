package com.abacogroup.cllapi.core.impl;

import static java.util.stream.Collectors.toList;

import java.util.List;

import com.abacogroup.cllapi.api.LandLinkLeadingRes;
import com.abacogroup.cllapi.api.LandLinkLeadingResWithHolder;
import com.abacogroup.cllapi.api.ParcelSearchRes;
import com.abacogroup.cllapi.api.req.ParcelSearchReq;
import com.abacogroup.cllapi.core.ParcelService;
import com.abacogroup.cllapi.core.ParcelV1Service;
import com.abacogroup.cllapi.resources.pub.mapper.ParcelResponseMapper;
import com.abacogroup.cllcli.api.v1.LandLinkLeadingResV1;
import com.abacogroup.cllcli.api.v1.LandLinkLeadingResWithHolderResV1;
import com.abacogroup.cllcli.api.v1.ParcelSearchResponseV1;
import com.abacogroup.common.resources.ReqContext;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.jdbi.paging.impl.InfiniteListResultsImpl;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class ParcelV1ServiceImpl implements ParcelV1Service {

    private final ParcelService parcelService;

    public ParcelV1ServiceImpl(ParcelService parcelService) {
        this.parcelService = parcelService;
    }

    @Override
    public InfiniteListResults<ParcelSearchResponseV1> search(ReqContext context, Long partyId, ParcelSearchReq searchReq,
                                                              Boolean includeGeometries, Boolean includeLandCovers, Boolean includeLpisData, String nextKey, Integer pageSize) {
        InfiniteListResults<ParcelSearchRes> infiniteListResults = parcelService.search(context, partyId, searchReq, includeGeometries, includeLandCovers, includeLpisData, null, nextKey, pageSize);
        List<ParcelSearchResponseV1> parcelList = infiniteListResults.getRecords().stream().map(ParcelResponseMapper.INSTANCE::toResponseV1List).collect(toList());

        return new InfiniteListResultsImpl<>(parcelList, infiniteListResults.getNextKey());
    }

    @Override
    public List<LandLinkLeadingResV1> getParcelLeadingList(ReqContext context, Long parcelId, AbsoluteDate referenceDate) {
        List<LandLinkLeadingRes> result = parcelService.getParcelLeadingList(context, parcelId, referenceDate);

        return ParcelResponseMapper.INSTANCE.landLinkLeadingResListToLandLinkLeadingResV1List(result);

    }
    
    @Override
	public List<LandLinkLeadingResWithHolderResV1> getParcelLeadingHistory(ReqContext context, Long parcelId, Boolean loadMandatesHolders) {
		List<LandLinkLeadingResWithHolder> result = parcelService.getParcelLeadingHistory(context, parcelId, loadMandatesHolders);

		return ParcelResponseMapper.INSTANCE.landLinkLeadingResListWithHolderToLandLinkLeadingResV1List(result);
	}
}
