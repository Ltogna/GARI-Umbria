package com.abacogroup.cllapi.resources.pub;

import com.abacogroup.cllapi.core.GroupService;
import com.abacogroup.cllapi.exceptions.GroupException;
import com.abacogroup.cllapi.exceptions.LandLinkException;
import com.abacogroup.cllapi.exceptions.TitleTypeException;
import com.abacogroup.cllapi.resources.pub.mapper.GroupPublicMapper;
import com.abacogroup.cllcli.api.v1.GroupResponseV1;
import com.abacogroup.cllcli.api.v1.req.GroupCreateRequestV1;
import com.abacogroup.cllcli.resources.PublicResourceConstants;
import com.abacogroup.common.resources.ReqContext;
import com.abacogroup.dropwizard.auth.sso2.User;
import io.dropwizard.auth.Auth;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import jakarta.ws.rs.DefaultValue;
import jakarta.ws.rs.HeaderParam;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;

@Path(PublicResourceConstants.API_V1_PUB + "/parties/{partyId}/groups")
@Produces(MediaType.APPLICATION_JSON)
@Tag(name = "Groups", description = "Operations on land link groups")
@Tag(name = "Public APIs", description = "All public APIs")
public class GroupPublicResource {

	private final GroupService groupService;

	public GroupPublicResource(GroupService groupService) {
		this.groupService = groupService;
	}

	@POST
//	@RolesAllowed("CUSTOMER_LAND_LINK|WRITE")
	@Operation(description = "create a group with its land links", summary = "create group")
	@ApiResponse(responseCode = "200", description = "newly created group", useReturnTypeSchema = true)
	@ApiResponse(responseCode = "400", description = "error creating group", content = @Content(mediaType = MediaType.APPLICATION_JSON,
			schema = @Schema(oneOf = { GroupException.ErrorBody.class, TitleTypeException.ErrorBody.class, LandLinkException.ErrorBody.class })))
	public GroupResponseV1 createGroup(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "tenant id") @PathParam("tenant") String tenantId,
			@Parameter(description = "party id") @PathParam("partyId") Long partyId,
			@NotNull @Valid GroupCreateRequestV1 createReq) {

		ReqContext reqContext = new ReqContext(user, lang);
		return GroupPublicMapper.INSTANCE.toResponseV1(
				groupService.insert(reqContext, partyId, GroupPublicMapper.INSTANCE.fromCreateRequestV1(createReq)));
	}
}
