package com.abacogroup.cllapi.api;

import java.util.ArrayList;
import java.util.List;

import org.jdbi.v3.core.mapper.Nested;
import org.locationtech.jts.geom.Geometry;

import com.abacogroup.jdbi.datatype.AbsoluteDate;

import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Builder;
import lombok.Builder.Default;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@NoArgsConstructor
@SuperBuilder(setterPrefix = "set")
public class ParcelRes {
	private Long id;

	private String parcel;

	private AbsoluteDate dayFrom;

	private AbsoluteDate dayTo;

	private String srs;

	@Default
	private Long areaSqm = 0L;

	@Nested("block")
	private BlockRes block;

	@Nested("sector")
	private SectorRes sector;
	
	@Schema(description = "The parcel detail's original shape", type = "string", format = "WKT geometry")
	private Geometry geom;

	@Schema(description = "The parcel detail's world shape", type = "string", format = "WKT geometry")
	private Geometry worldGeom;

	@ArraySchema(schema = @Schema(description = "List of parcel land covers", implementation = LandCoverRes.class))
	@Builder.Default()
	private List<LandCoverRes> landcoversList = new ArrayList<>();

}
