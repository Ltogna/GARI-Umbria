package com.abacogroup.cllapi.resources;

import java.util.List;

import org.apache.commons.lang3.StringUtils;

import com.abacogroup.cllapi.api.DocTypeRelationRes;
import com.abacogroup.cllapi.api.GroupDocumentDefinition;
import com.abacogroup.cllapi.api.enums.DocTypeRelationScope;
import com.abacogroup.cllapi.core.DocTypeService;
import com.abacogroup.cllapi.exceptions.InvalidPayloadException;
import com.abacogroup.cllapi.exceptions.InvalidPayloadException.ErrEnum;
import com.abacogroup.common.resources.ReqContext;
import com.abacogroup.common.resources.ResourceConstants;
import com.abacogroup.dropwizard.auth.sso2.User;

import io.dropwizard.auth.Auth;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.annotation.security.RolesAllowed;
import jakarta.validation.constraints.NotNull;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DefaultValue;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.HeaderParam;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.MediaType;

@Path(ResourceConstants.API_PRIV + "/doc-types")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
@Tag(name = "Document types", description = "Operations on Dynamic documents definitions")
public class DocTypeResource {

	private final DocTypeService docTypeService;

	public DocTypeResource(DocTypeService docTypeService) {
		this.docTypeService = docTypeService;
	}

	@Operation(description = "Get the list of dynamic document types filtered by groupId")
	@ApiResponse(responseCode = "200", description = "Get the list of dynamic document types filtered by groupId", useReturnTypeSchema = true)
	@GET
	@RolesAllowed({ "CUSTOMER_LAND_LINK|READ", "CUSTOMER_LAND_LINK|WRITE" })
	@Path("")
	public List<DocTypeRelationRes> search(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "tenant id") @PathParam("tenant") String tenantId,
			@Parameter(description = "group id", required = true) @QueryParam("groupId") Long groupId,
			@Parameter(description = "landLink id", required = true) @QueryParam("landLinkId") Long landLinkId,
			@Parameter(description = "scope code of document") @QueryParam("scopeCode") @DefaultValue("GROUPS") DocTypeRelationScope scopeCode) {

		ReqContext reqContext = new ReqContext(user, lang);
		
		if (groupId == null && landLinkId == null) {
			throw new InvalidPayloadException(ErrEnum.INVALID_PAYLOAD, "Group id or Land link id required");
		}
		
		return docTypeService.getByGroupIdOrLandLinkId(reqContext, groupId, landLinkId, scopeCode);
	}

	@Operation(summary = "document definition", description = "Get document definition by its code")
	@ApiResponses({
			@ApiResponse(responseCode = "200", description = "Successfully, returns a document definition", useReturnTypeSchema = true),
	})
	@GET
	@RolesAllowed({ "CUSTOMER_LAND_LINK|READ", "CUSTOMER_LAND_LINK|WRITE" })
	@Path("/{definitionCode}")
	public GroupDocumentDefinition getDefinition(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@PathParam("tenant") String tenantId,
			@PathParam("definitionCode") String definitionCode) {

		ReqContext reqContext = new ReqContext(user, lang);
		return docTypeService.getDefinition(reqContext, definitionCode);
	}
}
