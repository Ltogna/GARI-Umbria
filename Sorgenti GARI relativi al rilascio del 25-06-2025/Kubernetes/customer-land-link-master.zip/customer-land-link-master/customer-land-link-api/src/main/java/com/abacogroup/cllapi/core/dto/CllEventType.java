package com.abacogroup.cllapi.core.dto;

public enum CllEventType {

	NEW_GROUP("new-group"),
	UPDATE_GROUP("update-group"),
	UPDATE_GROUP_DOCS("update-group-documents"),
//	UPDATE_LAND_LINK_DOCS("update-land-link-documents"),
	@Deprecated
	CLOSE_GROUP("close-group"),
	UPDATE_LAND_LINKS("update-land-links"),
	CLOSE_LAND_LINKS("close-land-links");

	public static final String TOPIC_PREFIX = "cll";

	private final String topic;

	CllEventType(String topicName) {
		this.topic = topicName;
	}

	public String getTopic() {
		return String.format("%s.%s", TOPIC_PREFIX, topic);
	}
}
