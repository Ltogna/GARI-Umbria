package com.abacogroup.cllapi.exceptions;

import com.abacogroup.common.exceptions.AbstractAppException;
import io.swagger.v3.oas.annotations.media.Schema;

public class GroupException extends AbstractAppException {

	public GroupException(ErrEnum code, String message) {
		super(new ErrorBody(code.name(), message));
	}

	public enum ErrEnum {
		NOT_FOUND,
		EMPTY_GROUP,
		INVALID_PARTY,
		DUPLICATE_DESCR,
		CLOSED_GROUP,
		OPEN_GROUP,
		INVALID_DAY_TO,
	}

	@Schema(name = "GroupExceptionErrorBody")
	public static class ErrorBody implements ExceptionErrorBody {
		private final String code;
		private final String message;

		public ErrorBody(String code, String message) {
			this.code = code;
			this.message = message;
		}

		@Override
		@Schema(allowableValues = {
				"NOT_FOUND",
				"EMPTY_GROUP",
				"INVALID_PARTY",
				"DUPLICATE_DESCR",
				"CLOSED_GROUP",
				"OPEN_GROUP",
				"INVALID_DAY_TO",
		})
		public String getErrorCode() {
			return code;
		}

		@Override
		@Schema
		public String getMessage() {
			return message;
		}
	}
}
