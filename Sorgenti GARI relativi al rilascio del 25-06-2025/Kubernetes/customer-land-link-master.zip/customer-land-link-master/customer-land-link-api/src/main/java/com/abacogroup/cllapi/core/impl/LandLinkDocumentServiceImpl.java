package com.abacogroup.cllapi.core.impl;

import static com.abacogroup.cllapi.exceptions.InvalidDocumentException.ErrEnum.DYNAMIC_DOCUMENT_FILE_NOT_FOUND;
import static com.abacogroup.cllapi.exceptions.InvalidDocumentException.ErrEnum.DYNAMIC_DOCUMENT_NOT_FOUND;

import java.time.Clock;
import java.time.OffsetDateTime;
import java.util.Collection;
import java.util.Objects;
import java.util.Optional;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.stream.Stream;

import org.apache.commons.lang3.StringUtils;

import com.abacogroup.cllapi.api.LandLinkDocumentRes;
import com.abacogroup.cllapi.api.req.LandLinkDocumentSearchReq;
import com.abacogroup.cllapi.core.LandLinkDocumentService;
import com.abacogroup.cllapi.core.LandLinkEventProducer;
import com.abacogroup.cllapi.core.LandLinkService;
import com.abacogroup.cllapi.core.embededqueue.EventPublisher;
import com.abacogroup.cllapi.db.dao.LandLinkDocumentDAO;
import com.abacogroup.cllapi.db.ntt.LandLinkDocumentEntity;
import com.abacogroup.cllapi.db.ntt.LandLinkEntity;
import com.abacogroup.cllapi.exceptions.InvalidDocumentException;
import com.abacogroup.cllapi.exceptions.LandLinkException;
import com.abacogroup.cllapi.resources.mapper.DocumentMapper;
import com.abacogroup.common.resources.ReqContext;
import com.abacogroup.common.service.AuditHelper;
import com.abacogroup.dynamicdocuments.bean.Document;
import com.abacogroup.dynamicdocuments.bean.DocumentDefinition;
import com.abacogroup.dynamicdocuments.bean.InsertDocument;
import com.abacogroup.dynamicdocuments.bean.documentdefinition.fieldset.field.FieldType;
import com.abacogroup.dynamicdocuments.exceptions.UnknownDocumentException;
import com.abacogroup.dynamicdocuments.services.DocumentService;
import com.abacogroup.dynamicdocuments.services.DocumentTypeService;
import com.abacogroup.jdbi.criteria.Criteria;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.jdbi.model.AuditEntity;
import com.abacogroup.jdbi.orderby.OrderBy;
import com.abacogroup.jdbi.paging.InfiniteListResults;

import jakarta.ws.rs.core.Response;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class LandLinkDocumentServiceImpl implements LandLinkDocumentService {

	private final LandLinkService landLinkService;
	private final DocumentService documentService;
	private final DocumentTypeService documentTypeService;
	private final String dynamicDocumentsBucket;
	private final FileStoreProxyClient fileStoreProxyClient;
	private final LandLinkEventProducer landLinkEventProducer;
	private final EventPublisher anomalyQueue;

	private final LandLinkDocumentDAO dao;

	private final Clock appClock;

	public LandLinkDocumentServiceImpl(LandLinkService landLinkService, LandLinkDocumentDAO dao, DocumentService documentService, 
			DocumentTypeService documentTypeService, FileStoreProxyClient fileStoreProxyClient,
			String dynamicDocumentsBucket, LandLinkEventProducer landLinkEventProducer, EventPublisher anomalyQueue,
			Clock appClock) {
		this.landLinkService = landLinkService;
		this.dao = dao;
		this.documentService = documentService;
		this.documentTypeService = documentTypeService;
		this.dynamicDocumentsBucket = dynamicDocumentsBucket;
		this.fileStoreProxyClient = fileStoreProxyClient;
		this.landLinkEventProducer = landLinkEventProducer;
		this.anomalyQueue = anomalyQueue;
		this.appClock = appClock;
	}

	@Override
	public LandLinkDocumentRes insert(ReqContext reqContext, Long partyId, Long landLinkId, AbsoluteDate referenceDate, InsertDocument document) {

		if (StringUtils.isBlank(document.getDefCode())) {
			throw new InvalidDocumentException(InvalidDocumentException.ErrEnum.DYNAMIC_DOCUMENT_ERR, "missing defCode");
		}

		LandLinkEntity landLink = loadLandLink(reqContext, partyId, landLinkId, referenceDate);
		document.setBusinessId(landLink.getId());

		String definitionCode = document.getDefCode();
		DocumentDefinition definition = this.documentTypeService.getDocumentDefinition(reqContext.getTenantId(), definitionCode)
				.orElseThrow(() -> new InvalidDocumentException(InvalidDocumentException.ErrEnum.DYNAMIC_DOCUMENT_ERR, "invalid defCode"));

		int maxOccurs = 0;
		if (null != definition.getMetadata()) {
			maxOccurs = Optional.ofNullable(definition.getMetadata().getMaxOccurs()).orElse(0);
		}
		if (maxOccurs <= this.countDocumentsByLandLinkIdAndDefinitionCode(reqContext, landLinkId, definitionCode)) {
			throw new InvalidDocumentException(InvalidDocumentException.ErrEnum.DYNAMIC_DOCUMENT_ERR, "over maxOccurs");
		}

		Long documentId = dao.inTransaction(handle -> {
			Long id = store(reqContext, document.getDoc(), document.getDefCode(), reqContext.getUser().getUserId(),
					document.getBusinessId(), document.getLabel());

			LandLinkDocumentEntity entity = new LandLinkDocumentEntity();
			entity.setLandLinkId(landLink.getId());
			entity.setDefinitionCode(document.getDefCode());
			entity.setDocumentId(id);
			AuditHelper.setAuditForInsert(entity, reqContext.getUsername(), dao);
			this.dao.insert(entity);

//			landLinkEventProducer.pushLandLinkEvent(List.of(landLink.getId()), partyId,
//					reqContext.getTenantId(), reqContext.getUsername(), reqContext.getLang(), CllEventType.UPDATE_LAND_LINK_DOCS);
//
//			anomalyQueue.pushLandLinkEvent(List.of(landLink.getId()), landLink.getDayFrom(), partyId,
//					reqContext.getTenantId(), reqContext.getUsername(), reqContext.getLang(),
//					CllEventType.UPDATE_LAND_LINK_DOCS);
			return id;
		});

		return getLandLinkDocument(reqContext, landLink, documentId);
	}
	
	private Long store(ReqContext reqContext, Document document, String definitionCode, String userID, Long groupId,
			String label) {
		document.setValidFrom(Optional.ofNullable(document.getValidFrom()).orElse(OffsetDateTime.now()));
		document.setValidTo(Optional.ofNullable(document.getValidTo())
				.orElse(AuditEntity.dateActive.atOffset(appClock.getZone().getRules().getOffset(appClock.instant()))));

		return documentService.insertDocument(reqContext.getTenantId(), definitionCode, document, userID, groupId, label);
	}
	
	public LandLinkDocumentRes getLandLinkDocument(ReqContext reqContext, LandLinkEntity landLink, Long documentId) {
		return dao.getByDocumentIdAndLandLinkId(documentId, landLink.getId(), reqContext)
				.map(groupDocument -> DocumentMapper.addData(groupDocument, documentService, dynamicDocumentsBucket))
				.orElseThrow(() -> new InvalidDocumentException(DYNAMIC_DOCUMENT_NOT_FOUND, "Document not found"));
	}

	@Override
	public Long countDocumentsByLandLinkIdAndDefinitionCode(ReqContext reqContext, Long landLinkId, String code) {
		return dao.countByDefinitionCodeAndLandLinkId(reqContext.getTenantId(), code, landLinkId);
	}

	@Override
	public void expire(ReqContext reqContext, Long partyId, Long landLinkId, AbsoluteDate referenceDate, Long documentId) {
		LandLinkEntity landLink = loadLandLink(reqContext, partyId, landLinkId, referenceDate);
		LandLinkDocumentEntity entity = dao.findByDocumentIdAndLandLinkId(reqContext.getTenantId(), documentId, landLink.getId())
				.orElseThrow(() -> new InvalidDocumentException(DYNAMIC_DOCUMENT_NOT_FOUND, "Land link Document not found"));

		Document doc = Optional.of(documentService.getDocumentFromId(documentId))
				.orElseThrow(() -> new InvalidDocumentException(DYNAMIC_DOCUMENT_NOT_FOUND, "Document not found"));

		doc.setValidTo(OffsetDateTime.now(appClock));
		dao.useTransaction(handle -> {
			documentService.updateDocument(documentId, doc, reqContext.getUser().getUserId());
			Consumer<LandLinkDocumentEntity> expire = handle::expireRow;
			AuditHelper.expire(entity, reqContext.getUsername(), expire, handle.getCurrentTimestamp());

//			landLinkEventProducer.pushLandLinkEvent(List.of(landLink.getId()), partyId,
//					reqContext.getTenantId(), reqContext.getUsername(), reqContext.getLang(), CllEventType.UPDATE_GROUP_DOCS);
//
//			anomalyQueue.pushLandLinkEvent(List.of(landLink.getId()), landLink.getDayFrom(), partyId,
//					reqContext.getTenantId(), reqContext.getUsername(), reqContext.getLang(),
//					CllEventType.UPDATE_LAND_LINK_DOCS);
		});
	}

	@Override
	public LandLinkDocumentRes update(ReqContext reqContext, Long partyId, Long landLinkId, AbsoluteDate referenceDate,
			Long documentId, Document updateReq) {
		LandLinkEntity landLink = loadLandLink(reqContext, partyId, landLinkId, referenceDate);
		LandLinkDocumentEntity entity = dao.findByDocumentIdAndLandLinkId(reqContext.getTenantId(), documentId, landLink.getId())
				.orElseThrow(() -> new InvalidDocumentException(DYNAMIC_DOCUMENT_NOT_FOUND, "Land link Document not found"));

		Document doc = Optional.of(documentService.getDocumentFromId(documentId))
				.orElseThrow(() -> new InvalidDocumentException(DYNAMIC_DOCUMENT_NOT_FOUND, "Document not found"));
		doc.setValidFrom(Optional.ofNullable(updateReq.getValidFrom()).orElse(doc.getValidFrom()));
		doc.setValidTo(Optional.ofNullable(updateReq.getValidTo()).orElse(doc.getValidTo()));
		doc.setFields(Optional.ofNullable(updateReq.getFields()).orElse(doc.getFields()));
		entity.setLandLinkId(landLink.getId());
		entity.setDocumentId(documentId);

		updateDocument(reqContext, documentId, partyId, entity, doc, landLink);

		return getLandLinkDocument(reqContext, landLink, documentId);
	}
	
	private Long updateDocument(ReqContext reqContext, Long documentId, Long partyId, LandLinkDocumentEntity entity, Document doc, 
			LandLinkEntity landLink) {
		return dao.inTransaction(handle -> {
			documentService.updateDocument(documentId, doc, reqContext.getUser().getUserId());
			Consumer<LandLinkDocumentEntity> expire = handle::expireRow;
			Function<LandLinkDocumentEntity, Long> insert = handle::insert;

			Long updatedLandLinkDocId = AuditHelper.update(entity, reqContext.getUsername(), expire, insert, handle.getCurrentTimestamp());
//			landLinkEventProducer.pushLandLinkEvent(List.of(landLink.getId()), partyId,
//					reqContext.getTenantId(), reqContext.getUsername(), reqContext.getLang(), CllEventType.UPDATE_LAND_LINK_DOCS);
//
//			anomalyQueue.pushLandLinkEvent(List.of(landLink.getId()), landLink.getDayFrom(), partyId,
//					reqContext.getTenantId(), reqContext.getUsername(), reqContext.getLang(),
//					CllEventType.UPDATE_LAND_LINK_DOCS);

			return updatedLandLinkDocId;
		});
	}

	@Override
	public LandLinkDocumentRes getLandLinkDocument(ReqContext reqContext, Long partyId, Long landLinkId, 
			AbsoluteDate referenceDate, Long documentId) {
		LandLinkEntity landLink = loadLandLink(reqContext, partyId, landLinkId, referenceDate);

		return getLandLinkDocument(reqContext, landLink, documentId);
	}

	@Override
	public InfiniteListResults<LandLinkDocumentRes> search(ReqContext reqContext, Long partyId, Long landLinkId, 
			AbsoluteDate referenceDate, LandLinkDocumentSearchReq searchReq, String nextKey) {
		LandLinkEntity landLink = loadLandLink(reqContext, partyId, landLinkId, referenceDate);

		Criteria criteria = searchReq.getCriteria(reqContext);
		OrderBy orderBy = searchReq.getSort();

		return dao.infinite(() -> dao.search(landLink.getId(), criteria, orderBy, reqContext), nextKey, searchReq.getPageSize())
				.map(pd -> DocumentMapper.addSummaryFields(reqContext, pd, documentTypeService, documentService, dynamicDocumentsBucket));
	}

	@Override
	public Response getDocumentFileContent(ReqContext reqContext, Long partyId, Long landLinkId,
			AbsoluteDate referenceDate, Long documentId, String fileId) {
		this.validateCanReadFile(reqContext, partyId, landLinkId, referenceDate, documentId, fileId);

		return fileStoreProxyClient.getFileContent(reqContext.getLang(), reqContext.getUser(), dynamicDocumentsBucket, fileId);
	}

	@Override
	public Response getDocumentFileMetadata(ReqContext reqContext, Long partyId, Long landLinkId,
			AbsoluteDate referenceDate, Long documentId, String fileId) {
		this.validateCanReadFile(reqContext, partyId, landLinkId, referenceDate, documentId, fileId);

		return fileStoreProxyClient.getFileMetadata(reqContext.getLang(), reqContext.getUser(), dynamicDocumentsBucket, fileId);
	}
	
	private void validateCanReadFile(ReqContext reqContext, Long partyId, Long landLinkId, AbsoluteDate referenceDate, Long documentId, String fileId) {
		LandLinkEntity landLink = loadLandLink(reqContext, partyId, landLinkId, referenceDate);

		LandLinkDocumentEntity landLinkDocumentEntity = dao.findByDocumentIdAndLandLinkId(reqContext.getTenantId(), documentId, landLink.getId())
				.orElseThrow(() -> new InvalidDocumentException(DYNAMIC_DOCUMENT_NOT_FOUND,
						String.format("Document  %s not found", documentId)));

		Document document;
		try {
			document = documentService.getDocumentFromId(landLinkDocumentEntity.getDocumentId());
		} catch (UnknownDocumentException ude) {
			throw new InvalidDocumentException(DYNAMIC_DOCUMENT_NOT_FOUND, ude.getMessage());
		}
		DocumentDefinition definition = documentTypeService.getDocumentDefinition(reqContext.getTenantId(), landLinkDocumentEntity.getDefinitionCode())
				.orElseThrow(() -> new InvalidDocumentException(InvalidDocumentException.ErrEnum.DYNAMIC_DOCUMENT_ERR,
						String.format("error loading definition for %s", landLinkDocumentEntity.getDefinitionCode())));

		boolean containsFileId = definition.getFieldSets().stream()
				.flatMap(fieldSet -> fieldSet.getFields().stream())
				.filter(field -> FieldType.FILE.equals(field.getType()))
				.map(field -> document.getFields().get(field.getCode()))
				.filter(Objects::nonNull)
				.flatMap(fieldValue -> fieldValue instanceof Collection ? ((Collection<?>) fieldValue).stream() : Stream.of(fieldValue))
				.anyMatch(fileId::equals);

		if (!containsFileId) {
			throw new InvalidDocumentException(DYNAMIC_DOCUMENT_FILE_NOT_FOUND,
					String.format("document '%s' of land link '%s' does not contain file with id '%s'",
							documentId, landLink.getId(), fileId));
		}
	}
	
	private LandLinkEntity loadLandLink(ReqContext reqContext, Long partyId, Long landLinkId, AbsoluteDate referenceDate) {
		
		LandLinkEntity landLink = landLinkService.loadEntity(reqContext.getTenantId(), landLinkId, referenceDate)
				.orElseThrow(() ->new LandLinkException(LandLinkException.ErrEnum.NOT_FOUND, String.format("Land link %s not found", landLinkId)));
		
		if(!landLink.getPartyId().equals(partyId)) {
			throw new LandLinkException(LandLinkException.ErrEnum.NOT_FOUND, String.format("Land link %s not found", landLinkId));
		}
		
		return landLink;
	}

}

