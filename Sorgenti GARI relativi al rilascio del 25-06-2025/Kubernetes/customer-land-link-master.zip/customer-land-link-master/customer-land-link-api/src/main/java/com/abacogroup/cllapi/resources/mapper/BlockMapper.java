package com.abacogroup.cllapi.resources.mapper;

import com.abacogroup.cllapi.api.BlockRes;
import com.abacogroup.lpisgisserver.api.v1.PublicParcelBlock;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper
public interface BlockMapper {

	BlockMapper INSTANCE = Mappers.getMapper(BlockMapper.class);
	BlockRes toBlockRes(PublicParcelBlock block);

}
