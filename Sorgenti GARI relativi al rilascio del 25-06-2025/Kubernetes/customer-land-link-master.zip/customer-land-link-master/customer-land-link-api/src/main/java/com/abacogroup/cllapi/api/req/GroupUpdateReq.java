package com.abacogroup.cllapi.api.req;

import com.abacogroup.jdbi.datatype.AbsoluteDate;
import jakarta.validation.constraints.NotNull;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder(setterPrefix = "set", toBuilder = true)
@NoArgsConstructor
public class GroupUpdateReq {

	private String descr;

	@NotNull
	private AbsoluteDate dayFrom;
	private AbsoluteDate dayTo;
}
