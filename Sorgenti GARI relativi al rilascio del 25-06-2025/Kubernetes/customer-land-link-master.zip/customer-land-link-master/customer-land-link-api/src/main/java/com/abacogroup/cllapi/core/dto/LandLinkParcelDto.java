package com.abacogroup.cllapi.core.dto;

import java.math.BigDecimal;
import java.math.RoundingMode;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Accessors(chain = true)
public class LandLinkParcelDto {
	private Long parcelId;
	private BigDecimal titleTypePerc;
	private Long areaSqm;

	public LandLinkParcelDto(Long parcelId, BigDecimal titleTypePerc) {
		this.parcelId = parcelId;
		this.titleTypePerc = titleTypePerc;
	}

	public Long getTitleTypeAreaSqm() {
		return titleTypePerc.multiply(BigDecimal.valueOf(areaSqm))
				.divide(BigDecimal.valueOf(100), 0, RoundingMode.HALF_UP).longValue();
	}
}
