package com.abacogroup.cllapi.bundle.config;

import com.abacogroup.bundles.initializer.impl.exceptions.BundleException;
import com.abacogroup.bundles.listener.configdata.ConfigDataMessage;
import com.abacogroup.bundles.listener.configdata.ConfigMessageProcessor;
import com.abacogroup.cllapi.bundle.BundleConstants;
import com.abacogroup.cllapi.db.dao.AnomalyCategoriesDAO;
import com.abacogroup.cllapi.db.ntt.AnomalyCategoriesEntity;
import com.abacogroup.cllcli.api.v1.AnomalyLevelEnum;
import com.fasterxml.jackson.annotation.JsonAlias;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import lombok.AllArgsConstructor;
import lombok.Builder.Default;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang3.StringUtils;

@Slf4j
public class AnomalyCategoriesConfigMessageProcessor implements ConfigMessageProcessor {

	private final AnomalyCategoriesDAO anomalyCategoriesDAO;
	private final ObjectMapper objectMapper;

	public AnomalyCategoriesConfigMessageProcessor(AnomalyCategoriesDAO anomalyCategoriesDAO, ObjectMapper objectMapper) {
		this.anomalyCategoriesDAO = anomalyCategoriesDAO;
		this.objectMapper = objectMapper;
	}

	@Override
	public String getDomainName() {
		return "anomaly-categories";
	}

	@Override
	public void onMessage(ConfigDataMessage message) {

		String tenantId = message.getTenantId();
		Map<AnomalyCategoryOperationEnum, ArrayList<Path>> map = collectFilesByOperation(message);

		map.getOrDefault(AnomalyCategoryOperationEnum.DELETE, new ArrayList<>()).forEach(path -> removeContent(tenantId, path));
		map.getOrDefault(AnomalyCategoryOperationEnum.DEFAULT, new ArrayList<>()).forEach(path -> addContent(tenantId, path));

	}

	private void removeContent(String tenantId, Path path) {

		try (Stream<String> input = Files.lines(path, StandardCharsets.UTF_8)) {
			input.map(String::strip)
					.filter(StringUtils::isNotBlank)
					.filter(s -> !s.startsWith(BundleConstants.JSONL_COMMENT))
					.map(this::mapEntity)
					.distinct()
					.peek(ac -> log.info("deleting anomaly category by group '{}', code '{}' and tenant '{}'",
							ac.getGroupCode(), ac.getCode(), tenantId))
					.forEach(ac -> anomalyCategoriesDAO.deleteByTenantGroupCodeAndCode(
							tenantId,
							StringUtils.trimToNull(ac.getGroupCode()),
							StringUtils.trimToNull(ac.getCode())));
		} catch (Exception e) {
			throw new BundleException(String.format("error applying changes from file %s", path), e);
		}
	}

	private void addContent(String tenantId, Path path) {

		try (Stream<String> input = Files.lines(path, StandardCharsets.UTF_8)) {
			input.map(String::strip)
					.filter(StringUtils::isNotBlank)
					.filter(s -> !s.startsWith(BundleConstants.JSONL_COMMENT))
					.map(this::mapEntity)
					.distinct()
					.peek(ac -> log.info("saving anomaly category with group '{}', code '{}' and tenant '{}'",
							ac.getGroupCode(), ac.getCode(), tenantId))
					.forEach(ac -> {

						AnomalyCategoriesEntity actual = anomalyCategoriesDAO.findByTenantGroupCodeAndCode(tenantId, ac.getGroupCode(), ac.getCode());

						AnomalyCategoriesEntity anomalyCategory = AnomalyCategoriesEntity.builder()
								.setCode(StringUtils.trimToNull(ac.getCode()))
								.setFlExclude(ac.getFlExclude() != null && ac.getFlExclude() ? 1 : 0)
								.setGroupCode(StringUtils.trimToNull(ac.getGroupCode()))
								.setLevel(ac.getLevel())
								.build();

						if (actual == null) {
							anomalyCategoriesDAO.insert(tenantId, anomalyCategory);
						} else if (!anomalyCategory.equals(actual)) {
							anomalyCategoriesDAO.update(tenantId, anomalyCategory);
						}

					});
		} catch (Exception e) {
			throw new BundleException(String.format("error applying changes from file %s", path), e);
		}
	}

	private static Map<AnomalyCategoryOperationEnum, ArrayList<Path>> collectFilesByOperation(ConfigDataMessage message) {
		Function<String, AnomalyCategoryOperationEnum> groupingPredicate = x -> {
			if (StringUtils.containsIgnoreCase(x, "delete")) {
				return AnomalyCategoryOperationEnum.DELETE;
			} else {
				return AnomalyCategoryOperationEnum.DEFAULT;
			}
		};

		List<Path> paths = message.getConfigFiles();
		return paths.stream()
				.filter(p -> FilenameUtils.isExtension(FilenameUtils.getName(p.getFileName().toString()).toLowerCase(), "jsonl"))
				.collect(Collectors.groupingBy(x -> groupingPredicate.apply(x.toString()),
						Collectors.toCollection(ArrayList::new)));
	}

	private AnomalyCategoriesMessage mapEntity(String jsonLine) {
		try {
			AnomalyCategoriesMessage entry = objectMapper.readValue(jsonLine, AnomalyCategoriesMessage.class);
			return entry;
		} catch (Exception e) {
			throw new BundleException("error in deserialization json " + jsonLine, e);
		}
	}

	private enum AnomalyCategoryOperationEnum {
		DELETE,
		DEFAULT,
	}

	@Data
	@SuperBuilder(setterPrefix = "set")
	@NoArgsConstructor
	@AllArgsConstructor
	static class AnomalyCategoriesMessage {
		private String groupCode;
		private String code;
		private AnomalyLevelEnum level;
		@JsonAlias("exclude")
		@Default
		private Boolean flExclude = false;
	}

}
