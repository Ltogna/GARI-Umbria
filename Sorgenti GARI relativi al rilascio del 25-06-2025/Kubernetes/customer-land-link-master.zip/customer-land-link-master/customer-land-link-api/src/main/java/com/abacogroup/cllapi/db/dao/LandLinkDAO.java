package com.abacogroup.cllapi.db.dao;

import com.abacogroup.cllapi.api.LandLinkLeadingRes;
import com.abacogroup.cllapi.api.LandLinkRes;
import com.abacogroup.cllapi.core.dto.LandLinkPayload;
import com.abacogroup.cllapi.db.ntt.LandLinkEntity;
import com.abacogroup.cllapi.db.ntt.PartyEntity;
import com.abacogroup.common.resources.ReqContext;
import com.abacogroup.jdbi.EnhancedSqlObject;
import com.abacogroup.jdbi.argument.AbsoluteDateArgumentFactory;
import com.abacogroup.jdbi.criteria.BindCriteria;
import com.abacogroup.jdbi.criteria.Criteria;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.jdbi.mapper.AbsoluteDateMapper;
import com.abacogroup.jdbi.model.AuditEntity;
import com.abacogroup.jdbi.orderby.DefineOrder;
import com.abacogroup.jdbi.orderby.OrderBy;
import java.util.Collection;
import java.util.List;
import java.util.Optional;
import java.util.function.Consumer;
import org.jdbi.v3.core.result.ResultIterator;
import org.jdbi.v3.sqlobject.config.RegisterArgumentFactory;
import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.config.RegisterColumnMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.customizer.BindBean;
import org.jdbi.v3.sqlobject.customizer.BindList;
import org.jdbi.v3.sqlobject.customizer.BindList.EmptyHandling;
import org.jdbi.v3.sqlobject.customizer.MaxRows;
import org.jdbi.v3.sqlobject.statement.GetGeneratedKeys;
import org.jdbi.v3.sqlobject.statement.SqlBatch;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;
import org.jdbi.v3.sqlobject.transaction.Transactional;

@RegisterArgumentFactory(AbsoluteDateArgumentFactory.class)
@RegisterColumnMapper(AbsoluteDateMapper.class)
public interface LandLinkDAO extends Transactional<LandLinkDAO>, EnhancedSqlObject {

    @SqlQuery("§select_nextval(cll_land_link_detail_pkid_seq)§")
    Long issuePk();

    @SqlUpdate("insert into cll_land_link_detail("
            + "id, pkid, group_id, tenant_id, party_id, "
            + "title_type_id, title_type_perc, "
            + "parcel_id, sector_code, block_code, parcel_code, sub_parcel_code, "
            + "day_from, day_to, "
            + "dt_insert, user_id_insert, dt_delete, user_id_delete"
            + ") values ("
            + ":id, :pkid, :groupId, :tenantId, :partyId,"
            + ":titleTypeId, :titleTypePerc, "
            + ":parcelId, :sectorCode, :blockCode, :parcelCode, :subParcelCode, "
            + ":dayFrom, :dayTo,"
            + ":dtInsert, :userIdInsert, :dtDelete, :userIdDelete)"
    )
    void insertNew(@BindBean LandLinkEntity entity);

    @SqlBatch("insert into cll_land_link_detail("
            + "id, pkid, group_id, tenant_id, party_id, "
            + "title_type_id, title_type_perc, "
            + "parcel_id, sector_code, block_code, parcel_code, sub_parcel_code,"
            + "day_from, day_to, "
            + "dt_insert, user_id_insert, dt_delete, user_id_delete"
            + ") values ("
            + ":id, :pkid, :groupId, :tenantId, :partyId,"
            + ":titleTypeId, :titleTypePerc, "
            + ":parcelId, :sectorCode, :blockCode, :parcelCode, :subParcelCode,"
            + ":dayFrom, :dayTo,"
            + ":dtInsert, :userIdInsert, :dtDelete, :userIdDelete)"
    )
    void insertNew(@BindBean LandLinkEntity... entities);

    @SqlUpdate("insert into cll_land_link_detail("
            + "id, group_id, tenant_id, party_id, "
            + "title_type_id, title_type_perc, "
            + "parcel_id, sector_code, block_code, parcel_code, sub_parcel_code,"
            + "day_from, day_to, "
            + "dt_insert, user_id_insert, dt_delete, user_id_delete"
            + ") values ("
            + ":id, :groupId, :tenantId, :partyId,"
            + ":titleTypeId, :titleTypePerc, "
            + ":parcelId, :sectorCode, :blockCode, :parcelCode, :subParcelCode,"
            + ":dayFrom, :dayTo,"
            + ":dtInsert, :userIdInsert, :dtDelete, :userIdDelete)"
    )
    @GetGeneratedKeys("pkid")
    Long insertVersion(@BindBean LandLinkEntity entity);

    @SqlUpdate("update cll_land_link_detail "
            + "set dt_delete = :dtDelete, user_id_delete= :userIdDelete "
            + "where id = :id and §current_timestamp§ between dt_insert and dt_delete")
    void expireRow(@BindBean LandLinkEntity entity);

    @SqlUpdate("update cll_land_link_detail "
            + "set dt_delete = :dtDelete, user_id_delete= :userIdDelete "
            + "where id in (<ids>) and tenant_id = :tenantId " +
            " and §current_timestamp§ between dt_insert and dt_delete ")
    void expireByIdIn(@BindBean AuditEntity auditEntity, @Bind("tenantId") String tenantId, @BindList("ids") Collection<Long> ids);

    @SqlUpdate("update cll_land_link_detail "
            + "set dt_delete = :dtDelete, user_id_delete= :userIdDelete "
            + "where group_id = :groupId and tenant_id = :tenantId " +
            " and §current_timestamp§ between dt_insert and dt_delete ")
    void expireByGroupId(@BindBean AuditEntity auditEntity, @Bind("tenantId") String tenantId, @Bind("groupId") Long groupId);

    @SqlQuery("select * "
            + " FROM cll_land_link_detail "
            + " WHERE tenant_id = :tenantId and id = :id "
            + " AND :referenceDate between day_from and day_to "
            + " AND (§current_timestamp§ between dt_insert and dt_delete)")
    @RegisterBeanMapper(LandLinkEntity.class)
    Optional<LandLinkEntity> findByIdAndTenantAndReferenceDate(
            @Bind("id") Long id,
            @Bind("tenantId") String tenantId,
            @Bind("referenceDate") String referenceDate);

    @SqlQuery("select * "
            + " FROM cll_land_link_detail "
            + " WHERE tenant_id = :tenantId "
            + " AND id = :id "
            + " AND (§current_timestamp§ between dt_insert and dt_delete)")
    @RegisterBeanMapper(LandLinkEntity.class)
    Optional<LandLinkEntity> findByIdAndTenant(
            @Bind("id") Long id,
            @Bind("tenantId") String tenantId);

    @SqlQuery("select * "
            + " FROM cll_land_link_detail "
            + " WHERE tenant_id = :tenantId "
            + " AND id = :id "
            + " order by dt_insert desc ")
    @RegisterBeanMapper(LandLinkEntity.class)
    List<LandLinkEntity> findAllVersionsByIdAndTenant(
            @Bind("id") Long id,
            @Bind("tenantId") String tenantId,
            @MaxRows int maxRows);

    @SqlQuery("select * "
            + " FROM cll_land_link_detail "
            + " WHERE tenant_id = :tenantId and id = :id and party_Id = :partyId "
            + " AND :referenceDate between day_from and day_to "
            + " AND (§current_timestamp§ between dt_insert and dt_delete)")
    @RegisterBeanMapper(LandLinkEntity.class)
    Optional<LandLinkEntity> findByIdAndPartyIdAndReferenceDate(
            @Bind("tenantId") String tenantId,
            @Bind("id") Long id,
            @Bind("partyId") Long partyId,
            @Bind("referenceDate") String referenceDate);

    @SqlQuery("select * "
            + " FROM cll_land_link_detail "
            + " WHERE tenant_id = :tenantId and id = :id and party_Id = :partyId "
            + " AND (§current_timestamp§ between dt_insert and dt_delete)")
    @RegisterBeanMapper(LandLinkEntity.class)
    Optional<LandLinkEntity> findByIdAndPartyId(
            @Bind("tenantId") String tenantId,
            @Bind("id") Long id,
            @Bind("partyId") Long partyId);

    @SqlQuery("select * "
            + " FROM cll_land_link_detail "
            + " WHERE tenant_id = :tenantId and group_id = :groupId "
            + " AND :referenceDate between day_from and day_to "
            + " AND (§current_timestamp§ between dt_insert and dt_delete)")
    @RegisterBeanMapper(LandLinkEntity.class)
    ResultIterator<LandLinkEntity> findByGroupIdAndTenantAndReferenceDate(
            @Bind("groupId") Long groupId,
            @Bind("tenantId") String tenantId,
            @Bind("referenceDate") String referenceDate);

    @SqlQuery("select * "
            + " FROM cll_land_link_detail "
            + " WHERE tenant_id = :tenantId and group_id in (<groupIds>) and party_id = :partyId "
            + " AND :referenceDate between day_from and day_to "
            + " AND (§current_timestamp§ between dt_insert and dt_delete)")
    @RegisterBeanMapper(LandLinkEntity.class)
    ResultIterator<LandLinkEntity> findByGroupIdInAndPartyIdAndReferenceDate(
            @BindList("groupIds") Collection<Long> groupIds,
            @Bind("partyId") Long partyId,
            @Bind("referenceDate") String referenceDate,
            @Bind("tenantId") String tenantId);

    @SqlQuery("select count(*) "
            + " FROM cll_land_link_detail "
            + " WHERE tenant_id = :tenantId and group_id in (<groupIds>) and party_id = :partyId "
            + " AND :referenceDate < day_from "
            + " AND (§current_timestamp§ between dt_insert and dt_delete)")
    Integer countByGroupIdInAndPartyIdAndDayFromBefore(
            @BindList("groupIds") Collection<Long> groupIds,
            @Bind("partyId") Long partyId,
            @Bind("referenceDate") String referenceDate,
            @Bind("tenantId") String tenantId);

    @SqlQuery("select count(*) "
            + " FROM cll_land_link_detail "
            + " WHERE tenant_id = :tenantId and parcel_id = :parcelId and group_id = :groupId and party_id = :partyId "
            + " AND :referenceDate < day_from "
            + " AND (§current_timestamp§ between dt_insert and dt_delete)")
    Integer countByParcelIdAndGroupIdAndPartyIdAndDayFromBefore(
            @Bind("parcelId") Long parcelId,
            @Bind("groupId") Long groupId,
            @Bind("partyId") Long partyId,
            @Bind("referenceDate") String referenceDate,
            @Bind("tenantId") String tenantId);

    @SqlQuery("select count(*) "
            + " FROM cll_land_link_detail ll1 "
            + " join cll_land_link_detail ll2 on ll1.tenant_id = ll2.tenant_id and ll1.parcel_id = ll2.parcel_id and ll1.group_id = ll2.group_id and ll1.id <> ll2.id "
            + " WHERE ll1.tenant_id = :tenantId and ll1.id in (<landLinkIds>) and ll1.party_id = :partyId "
            + " AND :referenceDate < ll2.day_from "
            + " AND (§current_timestamp§ between ll1.dt_insert and ll1.dt_delete) "
            + " AND (§current_timestamp§ between ll2.dt_insert and ll2.dt_delete) ")
    Integer countByLandLinkIdInAndPartyIdAndDayFromBeforeUsingParcelIds(
            @BindList("landLinkIds") Collection<Long> lanLinkIds,
            @Bind("partyId") Long partyId,
            @Bind("referenceDate") String referenceDate,
            @Bind("tenantId") String tenantId);

    @SqlQuery("select * "
            + " FROM cll_land_link_detail "
            + " WHERE tenant_id = :tenantId and group_id in (<groupIds>) and party_id = :partyId "
            + " AND (§current_timestamp§ between dt_insert and dt_delete) "
            + " order by parcel_id, id desc ")
    @RegisterBeanMapper(LandLinkEntity.class)
    ResultIterator<LandLinkEntity> findByGroupIdInAndPartyId(
            @BindList("groupIds") Collection<Long> groupIds,
            @Bind("partyId") Long partyId,
            @Bind("tenantId") String tenantId);

    @SqlQuery("select * "
            + " FROM cll_land_link_detail "
            + " WHERE tenant_id = :tenantId and group_id = :groupId and party_id = :partyId "
            + " AND (§current_timestamp§ between dt_insert and dt_delete)")
    @RegisterBeanMapper(LandLinkEntity.class)
    List<LandLinkEntity> findByGroupIdAndPartyId(
            @Bind("groupId") Long groupId,
            @Bind("partyId") Long partyId,
            @Bind("tenantId") String tenantId);

    @SqlQuery("select distinct parcel_id "
            + " FROM cll_land_link_detail "
            + " WHERE tenant_id = :tenantId "
            + " and party_id = :partyId "
            + " order by parcel_id ")
    List<Long> findParcelIdsByPartyIdIncludeExpired(
            @Bind("tenantId") String tenantId,
            @Bind("partyId") Long partyId
    );

    @SqlQuery("select distinct parcel_id "
            + " FROM cll_land_link_detail "
            + " WHERE tenant_id = :tenantId "
            + " and party_id = :partyId "
            + " and group_id in (<groupIds>) "
            + " order by parcel_id ")
    List<Long> findParcelIdsByPartyIdAndGroupIdInIncludeExpired(
            @Bind("tenantId") String tenantId,
            @Bind("partyId") Long partyId,
            @BindList(value = "groupIds", onEmpty = EmptyHandling.NULL_STRING) Collection<Long> groupIds
    );

    @SqlQuery("select distinct parcel_id "
            + " FROM cll_land_link_detail "
            + " WHERE tenant_id = :tenantId "
            + " and party_id = :partyId "
            + " and id in (<ids>) "
            + " order by parcel_id ")
    List<Long> findParcelIdsByPartyIdInAndLandLinkIdInIncludeExpired(
            @Bind("tenantId") String tenantId,
            @Bind("partyId") Long partyId,
            @BindList(value = "ids", onEmpty = EmptyHandling.NULL_STRING) Collection<Long> landLinkIds
    );

    @SqlQuery("select * "
            + " FROM cll_land_link_detail "
            + " WHERE tenant_id = :tenantId and group_id = :groupId and party_id = :partyId "
            + " AND (§current_timestamp§ between dt_insert and dt_delete)")
    @RegisterBeanMapper(LandLinkEntity.class)
    void consumeByGroupIdAndPartyId(
            @Bind("groupId") Long groupId,
            @Bind("partyId") Long partyId,
            @Bind("tenantId") String tenantId,
            Consumer<LandLinkEntity> consumer
    );


    @SqlQuery("select * "
            + " FROM cll_land_link_detail "
            + " WHERE tenant_id = :tenantId and group_id = :groupId "
            + " AND (§current_timestamp§ between dt_insert and dt_delete)")
    @RegisterBeanMapper(LandLinkEntity.class)
    ResultIterator<LandLinkEntity> findByGroupIdAndTenant(
            @Bind("groupId") Long groupId,
            @Bind("tenantId") String tenantId);

    @SqlQuery("select * "
            + " FROM cll_land_link_detail "
            + " WHERE tenant_id = :tenantId and id in (<ids>) and party_id = :partyId "
            + " AND :referenceDate between day_from and day_to "
            + " AND (§current_timestamp§ between dt_insert and dt_delete)")
    @RegisterBeanMapper(LandLinkEntity.class)
    ResultIterator<LandLinkEntity> findByIdInAndPartyIdAndReferenceDate(
            @BindList("ids") Collection<Long> ids,
            @Bind("partyId") Long partyId,
            @Bind("referenceDate") String referenceDate,
            @Bind("tenantId") String tenantId);

    @SqlQuery("select * "
            + " FROM cll_land_link_detail "
            + " WHERE tenant_id = :tenantId and id in (<ids>) and party_id = :partyId "
            + " AND (§current_timestamp§ between dt_insert and dt_delete)")
    @RegisterBeanMapper(LandLinkEntity.class)
    ResultIterator<LandLinkEntity> findByIdInAndPartyId(
            @BindList("ids") Collection<Long> ids,
            @Bind("partyId") Long partyId,
            @Bind("tenantId") String tenantId);

    @SqlQuery("select * "
            + " FROM cll_land_link_detail "
            + " WHERE tenant_id = :tenantId and id in (<ids>) and party_id = :partyId "
            + " AND (§current_timestamp§ between dt_insert and dt_delete)")
    @RegisterBeanMapper(LandLinkEntity.class)
    void consumeByIdInAndPartyId(
            @BindList("ids") Collection<Long> ids,
            @Bind("partyId") Long partyId,
            @Bind("tenantId") String tenantId,
            Consumer<LandLinkEntity> consumer
    );

    /**
     * @param partyId
     * @param tenantId
     * @param referenceDate
     * @return *minimal data*
     */
    @SqlQuery("select id, title_type_id, title_type_perc, parcel_id, sector_code "
            + " FROM cll_land_link_detail "
            + " WHERE tenant_id = :tenantId "
            + " and party_id = :partyId "
            + " AND :referenceDate between day_from and day_to "
            + " AND (§current_timestamp§ between dt_insert and dt_delete) "
            + " order by sector_code, title_type_id, id ")
    @RegisterBeanMapper(LandLinkEntity.class)
    ResultIterator<LandLinkEntity> findMinimalByPartyIdAndReferenceDate(
            @Bind("partyId") Long partyId,
            @Bind("tenantId") String tenantId,
            @Bind("referenceDate") String referenceDate);

    @SqlQuery("select lld.id, \n"
            + "       lld.party_id, \n"
            + "       lld.title_type_id, \n"
            + "       lld.title_type_perc, \n"
            + "       lld.parcel_id as parcel_detail_id, \n"
            + "       lld.sector_code as parcel_sector_sector_code, \n"
            + "       lld.block_code as parcel_block_block_code, \n"
            + "       lld.parcel_code, \n"
            + "       lld.sub_parcel_code, \n"
            //+ "       trim(lld.parcel_code) "
            //+ "           || case when (lld.sub_parcel_code is null or trim(lld.sub_parcel_code) is null or trim(lld.sub_parcel_code) = '') "
            //+ "                then '' "
            //+ "                else :separator||lld.sub_parcel_code "
            //+ "              end as parcel_detail_parcel, \n"
            + "       lld.day_from, \n"
            + "       lld.day_to, \n"
            + "       tt.id as title_id, \n"
            + "       tt.code as title_code, \n"
            + "       tt.fl_day_to_req as title_fl_day_to_req, \n"
            + "       tt.fl_day_to_editable as title_fl_day_to_editable, \n"
            + "       tt.fl_allow_future_day_from as title_fl_allow_future_day_from, \n"
            + "       coalesce (§i18n(:tenantId, 'cll_title_type', 'code', tt.code, :lang)§, tt.code) as title_i18n_code, \n"
            + "       g.id as group_detail_id, \n"
            + "       gd.descr as group_detail_descr \n" +
            " FROM cll_land_link_detail lld " +
            " inner join cll_title_type tt on tt.id = lld.title_type_id and tt.tenant_id = lld.tenant_id" +
            " 	and (§current_timestamp§ between tt.dt_insert and tt.dt_delete) " +
            " left join cll_group g on g.id = lld.group_id and g.tenant_id = lld.tenant_id" +
            " left join cll_group_detail gd on g.id = gd.group_id " +
            " 	and (§current_timestamp§ between gd.dt_insert and gd.dt_delete) " +
            " WHERE lld.id = :id " +
            " and lld.party_id = :partyId " +
            " and lld.tenant_id = :tenantId " +
            " AND :referenceDate between lld.day_from and lld.day_to " +
            " AND (§current_timestamp§ between lld.dt_insert and lld.dt_delete)")
    @RegisterBeanMapper(LandLinkRes.class)
    Optional<LandLinkRes> getByIdAndPartyIdAndReferenceDate(
            @BindBean ReqContext reqContext,
            @Bind("id") Long id,
            @Bind("partyId") Long partyId,
            @Bind("referenceDate") String referenceDate);

    @SqlQuery("select lld.id as land_link_id, lld.group_id, lld.party_id, lld.title_type_id, lld.title_type_perc, " +
            " lld.parcel_id, lld.sector_code, lld.block_code, lld.parcel_code, lld.sub_parcel_code," +
            " lld.day_from, lld.day_to, " +
            " tt.code as title_type_code, " +
            " gd.descr as group_descr " +
            " FROM cll_land_link_detail lld " +
            " inner join cll_title_type tt on tt.id = lld.title_type_id and tt.tenant_id = lld.tenant_id" +
            " 	and (§current_timestamp§ between tt.dt_insert and tt.dt_delete) " +
            " left join cll_group g on g.id = lld.group_id and g.tenant_id = lld.tenant_id" +
            " left join cll_group_detail gd on g.id = gd.group_id " +
            " 	and (§current_timestamp§ between gd.dt_insert and gd.dt_delete) " +
            " WHERE lld.id in (<ids>) " +
            " and lld.party_id = :partyId " +
            " and lld.tenant_id = :tenantId " +
            " AND (§current_timestamp§ between lld.dt_insert and lld.dt_delete) " +
            " order by lld.id asc ")
    @RegisterBeanMapper(LandLinkPayload.class)
    List<LandLinkPayload> getPayloadByPartyIdAndIdIn(
            @Bind("tenantId") String tenantId,
            @Bind("partyId") Long partyId,
            @BindList("ids") Collection<Long> ids);
    
    @SqlQuery("select lld.id as land_link_id, lld.group_id, lld.party_id, lld.title_type_id, lld.title_type_perc, " +
            " lld.parcel_id, lld.sector_code, lld.block_code, lld.parcel_code, lld.sub_parcel_code," +
            " lld.day_from, lld.day_to, " +
            " tt.code as title_type_code, " +
            " '' as group_descr " +
            " FROM cll_land_link_detail lld " +
            " inner join cll_title_type tt on tt.id = lld.title_type_id and tt.tenant_id = lld.tenant_id" +
            " 	and (§current_timestamp§ between tt.dt_insert and tt.dt_delete) " +
            " WHERE lld.pkid in (<pkids>) " +
            " order by lld.id asc ")
    @RegisterBeanMapper(LandLinkPayload.class)
    List<LandLinkPayload> getPayloadByPkidIn(
            @BindList("pkids") Collection<Long> pkids);

    @SqlQuery("select lld.id as land_link_id, lld.group_id, lld.party_id, lld.title_type_id, lld.title_type_perc, " +
            " lld.parcel_id, lld.sector_code, lld.block_code, lld.parcel_code, lld.sub_parcel_code," +
            " lld.day_from, lld.day_to, " +
            " tt.code as title_type_code, " +
            " gd.descr as group_descr " +
            " FROM cll_land_link_detail lld " +
            " inner join cll_title_type tt on tt.id = lld.title_type_id and tt.tenant_id = lld.tenant_id" +
            " 	and (§current_timestamp§ between tt.dt_insert and tt.dt_delete) " +
            " left join cll_group g on g.id = lld.group_id and g.tenant_id = lld.tenant_id" +
            " left join cll_group_detail gd on g.id = gd.group_id " +
            " 	and (§current_timestamp§ between gd.dt_insert and gd.dt_delete) " +
            " WHERE g.id in (<groupIds>) " +
            " and lld.party_id = :partyId " +
            " and lld.tenant_id = :tenantId " +
            " AND (§current_timestamp§ between lld.dt_insert and lld.dt_delete) " +
            " order by lld.id asc ")
    @RegisterBeanMapper(LandLinkPayload.class)
    List<LandLinkPayload> getPayloadByPartyIdAndGroupIdIn(
            @Bind("tenantId") String tenantId,
            @Bind("partyId") Long partyId,
            @BindList("groupIds") Collection<Long> groupIds);

    @SqlQuery("select lld.id, \n"
            + "       lld.party_id, \n"
            + "       lld.title_type_id, \n"
            + "       lld.title_type_perc, \n"
            + "       lld.parcel_id as parcel_detail_id, \n"
            + "       lld.sector_code as parcel_sector_sector_code, \n"
            + "       lld.block_code as parcel_block_block_code, \n"
            + "       lld.parcel_code, \n"
            + "       lld.sub_parcel_code, \n"
            + "       trim(lld.parcel_code) "
            + "           || case when (lld.sub_parcel_code is null or trim(lld.sub_parcel_code) is null or trim(lld.sub_parcel_code) = '') "
            + "                then '' "
            + "                else :separator||lld.sub_parcel_code "
            + "              end as parcel_detail_parcel, \n"
            + "       lld.day_from, \n"
            + "       lld.day_to, \n"
            + "       tt.id as title_id, \n"
            + "       tt.code as title_code, \n"
            + "       tt.fl_day_to_req as title_fl_day_to_req, \n"
            + "       tt.fl_day_to_editable as title_fl_day_to_editable, \n"
            + "       tt.fl_allow_future_day_from as title_fl_allow_future_day_from, \n"
            + "       coalesce (§i18n(:tenantId, 'cll_title_type', 'code', tt.code, :lang)§, tt.code) as title_i18n_code, \n"
            + "       g.id as group_detail_id, \n"
            + "       gd.descr as group_detail_descr \n"
            + "  FROM cll_land_link_detail lld \n"
            + " inner join cll_title_type tt on tt.id = lld.title_type_id and tt.tenant_id = lld.tenant_id \n"
            + "        and (§current_timestamp§ between tt.dt_insert and tt.dt_delete) \n"
            + "  left join cll_group g on g.id = lld.group_id and g.tenant_id = lld.tenant_id \n"
            + "  left join cll_group_detail gd on g.id = gd.group_id \n"
            + "        and (§current_timestamp§ between gd.dt_insert and gd.dt_delete) \n"
            + " WHERE <criteria> \n"
            + "   and lld.tenant_id = :tenantId \n"
            + "   AND :referenceDate between lld.day_from and lld.day_to \n"
            + "   AND (§current_timestamp§ between lld.dt_insert and lld.dt_delete) \n"
            + " ORDER BY <orderBy> \n"
            + " ")
    @RegisterBeanMapper(LandLinkRes.class)
    ResultIterator<LandLinkRes> search(
            @Bind("referenceDate") String referenceDate,
            @Bind("separator") String separator,
            @BindCriteria Criteria criteria,
            @DefineOrder OrderBy orderBy,
            @BindBean ReqContext ctx);

    @SqlQuery("select count(lld.id) " +
            " FROM cll_land_link_detail lld " +
            " inner join cll_title_type tt on tt.id = lld.title_type_id and tt.tenant_id = lld.tenant_id" +
            " 	and (§current_timestamp§ between tt.dt_insert and tt.dt_delete) " +
            " left join cll_group g on g.id = lld.group_id and g.tenant_id = lld.tenant_id" +
            " left join cll_group_detail gd on g.id = gd.group_id " +
            " 	and (§current_timestamp§ between gd.dt_insert and gd.dt_delete) " +
            " WHERE <criteria> " +
            " and lld.tenant_id = :tenantId " +
            " AND :referenceDate between lld.day_from and lld.day_to " +
            " AND (§current_timestamp§ between lld.dt_insert and lld.dt_delete)")
    int countAllForSearch(
            @Bind("referenceDate") String referenceDate,
            @BindCriteria Criteria criteria,
            @BindBean ReqContext ctx);

    @SqlQuery("SELECT lld.id, \n"
            + "       lld.party_id, \n"
            + "       lld.title_type_id, \n"
            + "       lld.title_type_perc, \n"
            + "       lld.parcel_id as parcel_detail_id, \n"
            + "       lld.sector_code as parcel_sector_sector_code, \n"
            + "       lld.block_code as parcel_block_block_code, \n"
            + "       lld.parcel_code, \n"
            + "       lld.sub_parcel_code, \n"
            + "       trim(lld.parcel_code) "
            + "           || case when (lld.sub_parcel_code is null or trim(lld.sub_parcel_code) is null or trim(lld.sub_parcel_code) = '') "
            + "                then '' "
            + "                else :separator||lld.sub_parcel_code "
            + "              end as parcel_detail_parcel, \n"
            + "       lld.day_from, \n"
            + "       lld.day_to, \n"
            + "       tt.id as title_id, \n"
            + "       tt.code as title_code, \n"
            + "       tt.fl_day_to_req as title_fl_day_to_req, \n"
            + "       tt.fl_day_to_editable as title_fl_day_to_editable, \n"
            + "       tt.fl_allow_future_day_from as title_fl_allow_future_day_from, \n"
            + "       coalesce (§i18n(:tenantId, 'cll_title_type', 'code', tt.code, :lang)§, tt.code) as title_i18n_code, \n"
            + "       g.id as group_detail_id, \n"
            + "       gd.descr as group_detail_descr "
            + "  FROM cll_land_link_detail lld "
            + " inner join cll_title_type tt on tt.id = lld.title_type_id and tt.tenant_id = lld.tenant_id"
            + "        and (§current_timestamp§ between tt.dt_insert and tt.dt_delete) "
            + " left join cll_group g on g.id = lld.group_id and g.tenant_id = lld.tenant_id"
            + " left join cll_group_detail gd on g.id = gd.group_id "
            + "       and (§current_timestamp§ between gd.dt_insert and gd.dt_delete) "
            + " WHERE lld.group_id = :groupId "
            + "   and lld.party_id = :partyId "
            + "   and lld.tenant_id = :tenantId "
            + "   and (§current_timestamp§ between lld.dt_insert and lld.dt_delete)"
            + " ORDER BY <orderBy> \n"
            + " ")
    @RegisterBeanMapper(LandLinkRes.class)
    ResultIterator<LandLinkRes> searchByGroup(
            @Bind("partyId") Long partyId,
            @Bind("groupId") Long groupId,
            @Bind("separator") String separator,
            @DefineOrder OrderBy orderBy,
            @BindBean ReqContext ctx);

    @SqlQuery("select lld.id, lld.group_id , lld.party_id , lld.title_type_id, lld.title_type_perc, " +

            " lld.day_from, lld.day_to, " +
            " tt.id as title_id, tt.code as title_code, tt.fl_day_to_req as title_fl_day_to_req, tt.fl_day_to_editable as title_fl_day_to_editable, " +
            " tt.fl_allow_future_day_from as title_fl_allow_future_day_from, coalesce (§i18n(:tenantId, 'cll_title_type', 'code', tt.code, :lang)§, tt.code) as title_i18n_code, " +
            " g.id as group_detail_id, gd.descr as group_detail_descr " +
            " FROM cll_land_link_detail lld " +
            " inner join cll_title_type tt on tt.id = lld.title_type_id and tt.tenant_id = lld.tenant_id" +
            " 	and (§current_timestamp§ between tt.dt_insert and tt.dt_delete) " +
            " left join cll_group g on g.id = lld.group_id and g.tenant_id = lld.tenant_id" +
            " left join cll_group_detail gd on g.id = gd.group_id " +
            " 	and (§current_timestamp§ between gd.dt_insert and gd.dt_delete) "
            + " WHERE lld.parcel_id = :parcelId "
            + " and ( :dayFrom < lld.day_to ) "
            + " and lld.tenant_id = :tenantId "
            + " AND (§current_timestamp§ between lld.dt_insert and lld.dt_delete) "
            + "order by lld.id ")
    @RegisterBeanMapper(LandLinkLeadingRes.class)
    List<LandLinkLeadingRes> searchByParcelIdAndRange(
            @Bind("parcelId") Long parcelId,
            @Bind("dayFrom") String dayFrom,
            @BindBean ReqContext ctx);

    @SqlQuery("select lld.id, lld.group_id , lld.party_id , lld.title_type_id, lld.title_type_perc, " +

            " lld.day_from, lld.day_to, " +
            " tt.id as title_id, tt.code as title_code, tt.fl_day_to_req as title_fl_day_to_req, tt.fl_day_to_editable as title_fl_day_to_editable, " +
            " tt.fl_allow_future_day_from as title_fl_allow_future_day_from, coalesce (§i18n(:tenantId, 'cll_title_type', 'code', tt.code, :lang)§, tt.code) as title_i18n_code, " +
            " g.id as group_detail_id, gd.descr as group_detail_descr " +
            " FROM cll_land_link_detail lld " +
            " inner join cll_title_type tt on tt.id = lld.title_type_id and tt.tenant_id = lld.tenant_id" +
            " 	and (§current_timestamp§ between tt.dt_insert and tt.dt_delete) " +
            " left join cll_group g on g.id = lld.group_id and g.tenant_id = lld.tenant_id" +
            " left join cll_group_detail gd on g.id = gd.group_id " +
            " 	and (§current_timestamp§ between gd.dt_insert and gd.dt_delete) "
            + " WHERE lld.parcel_id = :parcelId "
            + " and ( :dayFrom <= lld.day_to ) "
            + " and ( :dayTo >= lld.day_from ) "
            + " and lld.tenant_id = :tenantId "
            + " AND (§current_timestamp§ between lld.dt_insert and lld.dt_delete) "
            + "order by lld.id ")
    @RegisterBeanMapper(LandLinkLeadingRes.class)
    List<LandLinkLeadingRes> searchByParcelIdAndRange(
            @Bind("parcelId") Long parcelId,
            @Bind("dayFrom") String dayFrom,
            @Bind("dayTo") String dayTo,
            @BindBean ReqContext ctx);


    /**
     * cerca duplicati in altri gruppi
     */
    @SqlQuery("select lld.id, lld.group_id, lld.party_id, lld.title_type_id,"
            + " lld.title_type_perc, lld.parcel_id, lld.sector_code, lld.block_code, lld.parcel_code, lld.sub_parcel_code,"
            + " lld.day_from, lld.day_to "
            + " FROM cll_land_link_detail lld "
            + " WHERE (lld.day_from <= :dayTo and lld.day_to > :dayFrom) "
            + " and lld.tenant_id = :tenantId and lld.party_id = :partyId "
            + " and lld.parcel_id in (<parcelIds>) "
            + " and lld.group_id not in (:groupId) "
            + " AND (§current_timestamp§ between lld.dt_insert and lld.dt_delete)")
    @RegisterBeanMapper(LandLinkEntity.class)
    List<LandLinkEntity> findByPartyIdAndParcelIdInAndGroupNotInRange(
            @BindBean ReqContext ctx,
            @Bind("groupId") Long groupId,
            @Bind("partyId") Long partyId,
            @Bind("dayFrom") String dayFrom,
            @Bind("dayTo") String dayTo,
            @BindList(value = "parcelIds", onEmpty = EmptyHandling.NULL_STRING) Collection<Long> parcelIds
    );

    @SqlQuery("select lld.pkid, lld.id, lld.group_id, lld.party_id, lld.title_type_id,"
            + " lld.title_type_perc, lld.parcel_id, lld.sector_code, lld.block_code, lld.parcel_code, lld.sub_parcel_code,"
            + " lld.day_from, lld.day_to "
            + " FROM cll_land_link_detail lld "
            + " WHERE lld.tenant_id = :tenantId "
            + " and (:partyId is null or lld.party_id = :partyId) "
            + " and (:groupId is null or lld.group_id = :groupId) "
            + " and lld.parcel_id in (<parcelIds>) "
            + " AND (§current_timestamp§ between lld.dt_insert and lld.dt_delete)")
    @RegisterBeanMapper(LandLinkEntity.class)
    List<LandLinkEntity> findByPartyIdAndGroupIdAndParcelIdIn(
            @BindBean ReqContext ctx,
            @Bind("partyId") Long partyId,
            @Bind("groupId") Long groupId,
            @BindList(value = "parcelIds", onEmpty = EmptyHandling.NULL_STRING) Collection<Long> parcelIds
    );


    @SqlQuery("select distinct ld.party_id as partyId \n"
    		+ "  from cll_group g \n"
    		+ " inner join cll_group_detail gd on g.id = gd.group_id \n"
    		+ " inner join cll_land_link_detail ld on g.id = ld.group_id and g.tenant_id = ld.tenant_id \n"
    		+ " where g.tenant_id = :tenantId \n"
    		+ "    and §current_timestamp§ between gd.dt_insert and gd.dt_delete \n"
    		+ "    and §current_timestamp§ between ld.dt_insert and ld.dt_delete \n"
    		+ "    and :referenceDate between ld.day_from and ld.day_to \n"
    		+ "    and ld.sector_code in (<sectorCodes>)")
    @RegisterBeanMapper(PartyEntity.class)
    ResultIterator<PartyEntity> findByTenantAndSectorCode(
    		@Bind("tenantId") String tenantId,
    		@Bind("referenceDate") AbsoluteDate referenceDate,
    		@BindList(value = "sectorCodes", onEmpty = EmptyHandling.NULL_STRING) Collection<String> sectorCodes);
    
}
