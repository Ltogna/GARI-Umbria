package com.abacogroup.cllapi.resources;

import java.time.Clock;
import java.time.LocalDateTime;
import java.util.Map;

import com.abacogroup.cllapi.api.LandLinkDocumentRes;
import com.abacogroup.cllapi.api.req.LandLinkDocumentSearchReq;
import com.abacogroup.cllapi.core.LandLinkDocumentService;
import com.abacogroup.cllapi.exceptions.InvalidDocumentException;
import com.abacogroup.cllapi.exceptions.LandLinkException;
import com.abacogroup.common.resources.ReqContext;
import com.abacogroup.common.resources.ResourceConstants;
import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.dynamicdocuments.bean.Document;
import com.abacogroup.dynamicdocuments.bean.InsertDocument;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.jdbi.paging.InfiniteListResults;

import io.dropwizard.auth.Auth;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.annotation.security.RolesAllowed;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import jakarta.ws.rs.BeanParam;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.DefaultValue;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.HEAD;
import jakarta.ws.rs.HeaderParam;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Path(ResourceConstants.API_PRIV + "/parties/{partyId}/land-links/{landLinkId}/documents")
@Produces(MediaType.APPLICATION_JSON)
@Tag(name = "Land Link documents", description = "Operations on land link documents")
public class LandLinkDocumentResource {

	private final LandLinkDocumentService landLinkDocumentService;
	private final Clock appClock;

	public LandLinkDocumentResource(LandLinkDocumentService landLinkDocumentService, Clock appClock) {
		this.landLinkDocumentService = landLinkDocumentService;
		this.appClock = appClock;
	}

	@Operation(summary = "List of documents of a specific type", description = "Get list of documents filtered with criteria")
	@ApiResponse(responseCode = "200", description = "Successfully, returns a list of documents (sorted/filtered)", useReturnTypeSchema = true)
	@ApiResponse(responseCode = "400", description = "Land link not found", content = @Content(mediaType = MediaType.APPLICATION_JSON,
	schema = @Schema(implementation = LandLinkException.ErrorBody.class)))
	@GET
	@Path("")
	@RolesAllowed({ "CUSTOMER_LAND_LINK|READ", "CUSTOMER_LAND_LINK|WRITE" })
	public InfiniteListResults<LandLinkDocumentRes> search(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@PathParam("tenant") String tenantId,
			@Parameter(description = "party ID") @PathParam("partyId") Long partyId,
			@Parameter(description = "land link ID") @PathParam("landLinkId") Long landLinkId,
			@Parameter(description = "reference date", schema = @Schema(format = AbsoluteDate.DATE_PATTERN))
			@QueryParam("referenceDate") @Size(min = 8, max = 8) String referenceDate,
			@Parameter(description = "Next key used for infinite pagination") @QueryParam("nextKey") String nextKey,
			@BeanParam LandLinkDocumentSearchReq searchReq) {

		ReqContext reqContext = new ReqContext(user, lang);

		AbsoluteDate refDate = AbsoluteDate.of(LocalDateTime.now(appClock));
		if(referenceDate != null) {
			refDate = AbsoluteDate.of(referenceDate);
		}

		return landLinkDocumentService.search(reqContext, partyId, landLinkId, refDate, searchReq, nextKey);
	}

	@Operation(summary = "Find document by code and id", description = "Returns document based on its definition code and document id")
	@ApiResponses({
		@ApiResponse(responseCode = "200", description = "Document successfully found", useReturnTypeSchema = true),
		@ApiResponse(responseCode = "400", description = "The document does not exist", content = @Content(mediaType = MediaType.APPLICATION_JSON,
		schema = @Schema(anyOf = {
				LandLinkException.ErrorBody.class,
				InvalidDocumentException.ErrorBody.class
		})))
	})
	@GET
	@RolesAllowed({ "CUSTOMER_LAND_LINK|READ", "CUSTOMER_LAND_LINK|WRITE" })
	@Path("/{documentId}")
	public LandLinkDocumentRes getByDocumentId(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@PathParam("tenant") String tenantId,
			@Parameter(description = "party ID") @PathParam("partyId") Long partyId,
			@Parameter(description = "land link ID") @PathParam("landLinkId") Long landLinkId,
			@Parameter(description = "document ID") @PathParam("documentId") Long documentId,
			@Parameter(description = "reference date", schema = @Schema(format = AbsoluteDate.DATE_PATTERN))
			@QueryParam("referenceDate") @Size(min = 8, max = 8) String referenceDate) {

		ReqContext reqContext = new ReqContext(user, lang);

		AbsoluteDate refDate = AbsoluteDate.of(LocalDateTime.now(appClock));
		if(referenceDate != null) {
			refDate = AbsoluteDate.of(referenceDate);
		}

		return this.landLinkDocumentService.getLandLinkDocument(reqContext, partyId, landLinkId, refDate, 
				documentId);
	}

	@Operation(summary = "Create document", description = "Insert a new document")
	@ApiResponses({
		@ApiResponse(responseCode = "200", description = "Successfully, the document has been correctly created",
				useReturnTypeSchema = true),
		@ApiResponse(responseCode = "400", description = "The group does not exist", content = @Content(
				schema = @Schema(implementation = LandLinkException.ErrorBody.class)))
	})
	@POST
	@RolesAllowed("CUSTOMER_LAND_LINK|WRITE")
	@Path("")
	public LandLinkDocumentRes insert(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@PathParam("tenant") String tenantId,
			@Parameter(description = "party ID") @PathParam("partyId") Long partyId,
			@Parameter(description = "land link ID") @PathParam("landLinkId") Long landLinkId,
			@Parameter(description = "reference date", schema = @Schema(format = AbsoluteDate.DATE_PATTERN))
			@QueryParam("referenceDate") @Size(min = 8, max = 8) String referenceDate,
			@NotNull @Valid InsertDocument document) {

		ReqContext reqContext = new ReqContext(user, lang);

		AbsoluteDate refDate = AbsoluteDate.of(LocalDateTime.now(appClock));
		if(referenceDate != null) {
			refDate = AbsoluteDate.of(referenceDate);
		}

		return landLinkDocumentService.insert(reqContext, partyId, landLinkId, refDate, document);
	}

	@Operation(summary = "update document", description = "update an existing document")
	@ApiResponses({
		@ApiResponse(responseCode = "200", description = "document updated", useReturnTypeSchema = true),
		@ApiResponse(responseCode = "400", description = "document update error",
		content = @Content(mediaType = "application/json", schema = @Schema(anyOf = {
				InvalidDocumentException.ErrorBody.class,
				LandLinkException.ErrorBody.class }))) })
	@PUT
	@RolesAllowed("CUSTOMER_LAND_LINK|WRITE")
	@Path("/{documentId}")
	public LandLinkDocumentRes update(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@PathParam("tenant") String tenantId,
			@Parameter(description = "party ID") @PathParam("partyId") Long partyId,
			@Parameter(description = "land link ID") @PathParam("landLinkId") Long landLinkId,
			@PathParam("documentId") Long documentId,
			@Parameter(description = "reference date", schema = @Schema(format = AbsoluteDate.DATE_PATTERN))
			@QueryParam("referenceDate") @Size(min = 8, max = 8) String referenceDate,
			@NotNull @Valid Document updateReq) {
		ReqContext reqContext = new ReqContext(user, lang);

		AbsoluteDate refDate = AbsoluteDate.of(LocalDateTime.now(appClock));
		if(referenceDate != null) {
			refDate = AbsoluteDate.of(referenceDate);
		}

		return landLinkDocumentService.update(reqContext, partyId, landLinkId, refDate, 
				documentId, updateReq);
	}

	@Operation(summary = "delete document", description = "delete an existing document by expiring it")
	@ApiResponses({
		@ApiResponse(responseCode = "200", description = "document expired"),
		@ApiResponse(responseCode = "400", description = "document delete error",
		content = @Content(mediaType = "application/json", schema = @Schema(anyOf = {
				InvalidDocumentException.ErrorBody.class,
				LandLinkException.ErrorBody.class
		})))
	})
	@DELETE
	@RolesAllowed("CUSTOMER_LAND_LINK|WRITE")
	@Path("/{documentId}")
	public Response delete(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@PathParam("tenant") String tenantId,
			@Parameter(description = "party ID") @PathParam("partyId") Long partyId,
			@Parameter(description = "land link ID") @PathParam("landLinkId") Long landLinkId,
			@PathParam("documentId") Long documentId,
			@Parameter(description = "reference date", schema = @Schema(format = AbsoluteDate.DATE_PATTERN))
			@QueryParam("referenceDate") @Size(min = 8, max = 8) String referenceDate) {

		ReqContext reqContext = new ReqContext(user, lang);

		AbsoluteDate refDate = AbsoluteDate.of(LocalDateTime.now(appClock));
		if(referenceDate != null) {
			refDate = AbsoluteDate.of(referenceDate);
		}

		landLinkDocumentService.expire(reqContext, partyId, landLinkId, refDate, documentId);

		return Response.ok(Map.of()).build();
	}

	@Operation(summary = "get document attachment content", description = "Returns document attachment content")
	@ApiResponses({
		@ApiResponse(responseCode = "200", description = "The file bytes",
				content = @Content(mediaType = MediaType.APPLICATION_OCTET_STREAM, schema = @Schema(type = "string", format = "binary"))),
		@ApiResponse(responseCode = "400", description = "The document does not exist", content = @Content(mediaType = MediaType.APPLICATION_JSON,
		schema = @Schema(anyOf = {
				LandLinkException.ErrorBody.class,
				InvalidDocumentException.ErrorBody.class
		})))
	})
	@GET
	@RolesAllowed({ "CUSTOMER_LAND_LINK|READ", "CUSTOMER_LAND_LINK|WRITE" })
	@Path("/{documentId}/attachments/{bucket}/{fileId}")
	public Response getDocumentFileContent(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@PathParam("tenant") String tenantId,
			@Parameter(description = "party ID") @PathParam("partyId") Long partyId,
			@Parameter(description = "land link ID") @PathParam("landLinkId") Long landLinkId,
			@Parameter(description = "document ID") @PathParam("documentId") Long documentId,
			@PathParam("bucket") String bucket,
			@PathParam("fileId") String fileId,
			@Parameter(description = "reference date", schema = @Schema(format = AbsoluteDate.DATE_PATTERN))
			@QueryParam("referenceDate") @Size(min = 8, max = 8) String referenceDate) {

		ReqContext reqContext = new ReqContext(user, lang);

		AbsoluteDate refDate = AbsoluteDate.of(LocalDateTime.now(appClock));
		if(referenceDate != null) {
			refDate = AbsoluteDate.of(referenceDate);
		}

		return landLinkDocumentService.getDocumentFileContent(reqContext, partyId, landLinkId, refDate, documentId, fileId);
	}

	@Operation(summary = "get document attachment metadata", description = "Returns document attachment metadata in header")
	@ApiResponses({
		@ApiResponse(responseCode = "200", description = "The file metadata in header"),
		@ApiResponse(responseCode = "400", description = "The document does not exist", content = @Content(mediaType = MediaType.APPLICATION_JSON,
		schema = @Schema(anyOf = {
				LandLinkException.ErrorBody.class,
				InvalidDocumentException.ErrorBody.class
		})))
	})
	@HEAD
	@RolesAllowed({ "CUSTOMER_LAND_LINK|READ", "CUSTOMER_LAND_LINK|WRITE" })
	@Path("/{documentId}/attachments/{bucket}/{fileId}")
	public Response getDocumentFileMetadata(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@PathParam("tenant") String tenantId,
			@Parameter(description = "party ID") @PathParam("partyId") Long partyId,
			@Parameter(description = "land link ID") @PathParam("landLinkId") Long landLinkId,
			@Parameter(description = "document ID") @PathParam("documentId") Long documentId,
			@PathParam("bucket") String bucket,
			@PathParam("fileId") String fileId,
			@Parameter(description = "reference date", schema = @Schema(format = AbsoluteDate.DATE_PATTERN))
			@QueryParam("referenceDate") @Size(min = 8, max = 8) String referenceDate) {
		
		ReqContext reqContext = new ReqContext(user, lang);
		
		AbsoluteDate refDate = AbsoluteDate.of(LocalDateTime.now(appClock));
		if(referenceDate != null) {
			refDate = AbsoluteDate.of(referenceDate);
		}

		return landLinkDocumentService.getDocumentFileMetadata(reqContext, partyId, landLinkId, refDate, documentId, fileId);
	}

}
