package com.abacogroup.cllapi.core;

import com.abacogroup.cllapi.core.dto.CllEventType;
import java.util.Collection;

public interface LandLinkEventProducer {

	void pushGroupEvent(Collection<Long> groupIds, Long partyId, String tenant, String username, String lang, CllEventType eventType);

	void pushGroupEvent(Collection<Long> groupIds, Long partyId, String tenant, String username, String lang, CllEventType eventType, Collection<Long> landLinkPkids);
	
	void pushLandLinkEvent(Collection<Long> landLinkIds, Long partyId, String tenant, String username, String lang, CllEventType eventType);

	void pushLandLinkEvent(Collection<Long> landLinkIds, Long partyId, String tenant, String username, String lang, CllEventType eventType, Collection<Long> landLinkPkids);
}
