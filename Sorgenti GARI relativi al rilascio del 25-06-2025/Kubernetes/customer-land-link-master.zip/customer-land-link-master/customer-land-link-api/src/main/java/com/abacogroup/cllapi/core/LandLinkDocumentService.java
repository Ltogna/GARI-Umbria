package com.abacogroup.cllapi.core;

import com.abacogroup.cllapi.api.LandLinkDocumentRes;
import com.abacogroup.cllapi.api.req.LandLinkDocumentSearchReq;
import com.abacogroup.common.resources.ReqContext;
import com.abacogroup.dynamicdocuments.bean.Document;
import com.abacogroup.dynamicdocuments.bean.InsertDocument;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.jdbi.paging.InfiniteListResults;

import jakarta.ws.rs.core.Response;

public interface LandLinkDocumentService {

	LandLinkDocumentRes insert(ReqContext reqContext, Long partyId, Long landLinkId, AbsoluteDate referenceDate, InsertDocument document);

	void expire(ReqContext reqContext, Long partyId, Long landLinkId, AbsoluteDate referenceDate, Long documentId);

	LandLinkDocumentRes update(ReqContext reqContext, Long partyId, Long landLinkId, AbsoluteDate referenceDate, Long documentId, Document updateReq);

	LandLinkDocumentRes getLandLinkDocument(ReqContext reqContext, Long partyId, Long landLinkId, AbsoluteDate referenceDate, Long documentId);

	InfiniteListResults<LandLinkDocumentRes> search(ReqContext reqContext, Long partyId, Long landLinkId, AbsoluteDate referenceDate,
			LandLinkDocumentSearchReq searchReq, String nextKey);

	Long countDocumentsByLandLinkIdAndDefinitionCode(ReqContext reqContext, Long landLinkId, String code);
	
	Response getDocumentFileContent(ReqContext reqContext, Long partyId, Long landLinkId, AbsoluteDate referenceDate, Long documentId, String fileId);

	Response getDocumentFileMetadata(ReqContext reqContext, Long partyId, Long landLinkId, AbsoluteDate referenceDate, Long documentId, String fileId);
	
}
