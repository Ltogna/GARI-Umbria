package com.abacogroup.cllapi.core.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.abacogroup.cllapi.api.MandateHolder;
import com.abacogroup.cllapi.api.acl.PartyWithEntityV1;
import com.abacogroup.cllapi.api.acl.PartyWithEntityV1Infinite;
import com.abacogroup.cllapi.core.PartiesAclClientService;
import com.abacogroup.cllapi.core.client.ClientHelper;
import com.abacogroup.cllapi.resources.mapper.MandateHolderMapper;
import com.abacogroup.common.resources.ReqContext;
import com.abacogroup.jdbi.datatype.AbsoluteDate;

import jakarta.ws.rs.client.WebTarget;
import jakarta.ws.rs.core.GenericType;
import jakarta.ws.rs.core.MultivaluedHashMap;
import jakarta.ws.rs.core.MultivaluedMap;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class PartiesAclClientServiceImpl implements PartiesAclClientService {

	private static final String PATH_PARAM_TENANT = "tenant";

	private static final String GET_MANADATE_URL = "/{tenant}/public/v1/parties-acl/parties/{partyId}/entities";

	private static final boolean ONLY_EXCLUSIVE = true;

	private final ClientHelper clientHelper;

	public PartiesAclClientServiceImpl(WebTarget target) {
		this.clientHelper = new ClientHelper(target);
	}

	@Override
	public PartyWithEntityV1Infinite getMandatesByPartyId(ReqContext context, Long partyId, AbsoluteDate minDate,
			AbsoluteDate maxDate, boolean onlyExclusive, String nextKey) {

		Map<String, Object> pathVariables = new HashMap<>();
		pathVariables.put(PATH_PARAM_TENANT, context.getTenantId());
		pathVariables.put("partyId", partyId);

		MultivaluedMap<String, Object> queryParams = new MultivaluedHashMap<>();
		queryParams.add("next_key", nextKey);
		queryParams.add("minDate", minDate);
		queryParams.add("maxDate", AbsoluteDate.of(maxDate.toLocalDate().minusDays(1)));
		
		// TODO to avoid user permission hack the api adding query param "withManage" set to "-1" so all users can see everything!!! to be fixed in some way... (2024-05-17 redmine #138998)
		queryParams.add("withManage", -1); // #138998 avoid user permission!!!!

		if(onlyExclusive) {
			queryParams.add("onlyExclusive", true);
		}

		log.info("Loading mandates data for party '{}' between {} and {}, exclusive: '{}'", partyId, minDate, maxDate, onlyExclusive);

		return clientHelper.get(GET_MANADATE_URL, context, pathVariables, queryParams, new GenericType<>() { });
	}

	@Override
	public List<PartyWithEntityV1> getAllMandatesByPartyId(ReqContext context, Long partyId, AbsoluteDate minDate,
			AbsoluteDate maxDate, boolean onlyExclusive) {

		List<PartyWithEntityV1> mandateList = new ArrayList<>();
		String nextKey = null;

		do {
			PartyWithEntityV1Infinite infiniteRes = getMandatesByPartyId(context, partyId, minDate, maxDate, onlyExclusive, nextKey);
			mandateList.addAll(infiniteRes.getRecords());
			nextKey = infiniteRes.getNextKey();
		} while(nextKey != null); 

		return mandateList;
	}

	@Override
	public MandateHolder getHolderByPartyId(ReqContext context, Long partyId, AbsoluteDate minDate,
			AbsoluteDate maxDate) {
		return getAllMandatesByPartyId(context, partyId, minDate, maxDate, ONLY_EXCLUSIVE)
				.stream()
				.sorted((a,b) -> b.getDayTo().toLocalDate().compareTo(a.getDayTo().toLocalDate()))
				.findFirst()
				.map(m -> MandateHolderMapper.INSTANCE.toMandateHolder(m.getEntity()))
				.orElse(null);
	}
}
