package com.abacogroup.cllapi.db.ntt;

import java.time.LocalDateTime;

import com.abacogroup.cllapi.api.enums.DocTypeRelationScope;
import com.abacogroup.jdbi.model.AuditEntity;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder(setterPrefix = "set", toBuilder = true)
@NoArgsConstructor
public class DocTypeRelationEntity implements AuditEntity {

	private Long pkid;
	private String tenantId;
	private String definitionCode;

	private Long titleTypeId;  // FK

	private int flRequired = 0;
	private int flReqOnAdd = 0;
	private int flReqOnClose = 0;

	private LocalDateTime dtInsert;
	private String userIdInsert;
	private LocalDateTime dtDelete;
	private String userIdDelete;
	
	private DocTypeRelationScope scopeCode;
}
