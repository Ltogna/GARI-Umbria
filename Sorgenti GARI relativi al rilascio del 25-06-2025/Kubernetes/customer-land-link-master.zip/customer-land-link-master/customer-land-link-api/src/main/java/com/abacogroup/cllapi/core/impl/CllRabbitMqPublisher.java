package com.abacogroup.cllapi.core.impl;

import java.io.IOException;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import com.abacogroup.cllapi.core.dto.CllEventMessage;
import com.abacogroup.cllapi.core.dto.CllEventPayload;
import com.abacogroup.cllapi.core.dto.LandLinkPayload;
import com.abacogroup.cllapi.db.dao.LandLinkDAO;
import com.abacogroup.embeddedqueue.rabbitmq.RabbitMqPublisher;
import com.rabbitmq.client.Connection;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class CllRabbitMqPublisher extends RabbitMqPublisher<CllEventMessage> {

	public static final String DEFAULT_EXCHANGE = "cll-exchange";
	private final LandLinkDAO landLinkDAO;
	private static String exchange;

	// must be set before the call of super constructor
	public static void setExchange(String exchange) {
		CllRabbitMqPublisher.exchange = exchange;
	}

	public CllRabbitMqPublisher(Connection connection, LandLinkDAO landLinkDAO) throws IOException {
		super(Objects.requireNonNull(connection));
		this.landLinkDAO = landLinkDAO;
	}

	@Override
	protected String getExchangeName() {
		return exchange;
	}

	@Override
	protected String getRoutingKey(CllEventMessage element) {
		return element.getRoutingKey();
	}

	@Override
	protected Map<String, Object> getMessageHeaders(CllEventMessage element) {
		return Map.of("tenant", element.getTenant());
	}

	@Override
	protected byte[] getPayload(CllEventMessage element) throws Exception {

		List<LandLinkPayload> payloadList = Stream.concat(
				Stream.concat(
						Optional.ofNullable(element.getGroupIds())
						.filter(ids -> !ids.isEmpty())
						.map(ids -> landLinkDAO.getPayloadByPartyIdAndGroupIdIn(element.getTenant(), element.getPartyId(), ids))
						.stream().flatMap(Collection::stream),
						Optional.ofNullable(element.getLandLinkIds())
						.filter(ids -> !ids.isEmpty())
						.map(ids -> landLinkDAO.getPayloadByPartyIdAndIdIn(element.getTenant(), element.getPartyId(), ids))
						.stream().flatMap(Collection::stream)),
				Optional.ofNullable(element.getLandLinkPkids())
				.filter(ids -> !ids.isEmpty())
				.map(landLinkDAO::getPayloadByPkidIn)
				.stream().flatMap(Collection::stream)
				)
				.distinct()
				.collect(Collectors.toList());

		CllEventPayload payload = CllEventPayload.builder()
					.setTenant(element.getTenant())
					.setUsername(element.getUsername())
					.setLang(element.getLang())
					.setEventType(element.getEventType())
					.setPartyId(element.getPartyId())
					.setDate(element.getDate())
					.setLandLinks(payloadList)		
				.build();
		
		return getObjectMapper().writeValueAsBytes(payload);
	}



}
