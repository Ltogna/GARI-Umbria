package com.abacogroup.cllapi.core.impl;

import java.util.Collection;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.function.Consumer;
import java.util.stream.Collectors;

import org.apache.commons.collections4.ListUtils;

import com.abacogroup.cllapi.core.LpisClientService;
import com.abacogroup.cllapi.core.client.ClientHelper;
import com.abacogroup.cllcli.api.v1.enums.ParcelSearchLevel;
import com.abacogroup.common.resources.ReqContext;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.lpisgisserver.api.v1.PublicParcel;
import com.abacogroup.lpisgisserver.api.v1.PublicParcelBlockList;
import com.abacogroup.lpisgisserver.api.v1.PublicParcelsList;
import com.abacogroup.lpisgisserver.api.v1.PublicSector;

import jakarta.ws.rs.client.WebTarget;
import jakarta.ws.rs.core.GenericType;
import jakarta.ws.rs.core.MultivaluedHashMap;
import jakarta.ws.rs.core.MultivaluedMap;

public class LpisClientServiceImpl implements LpisClientService {

	private static final String PATH_PARAM_TENANT = "tenant";
	private static final String PATH_PARAM_REFERENCE_DATE = "reference_date";
	private static final String PATH_PARAM_PARCEL_ID = "parcelId";
	
	private static final String QUERY_PARAM_FILTER = "filter";
	private static final String QUERY_PARAM_SEARCH_LEVEL = "search_level";
	private static final String QUERY_PARAM_SECTOR_DESCR_FILTER = "sector_descr_filter";
	private static final String QUERY_PARAM_BLOCK_DESCR_FILTER = "block_descr_filter";
	private static final String QUERY_PARAM_PARCEL_FILTER = "parcel_filter";
	private static final String QUERY_PARAM_INCLUDE_LANDCOVERS = "include_landcovers";
	private static final String QUERY_PARAM_INCLUDE_GEOMETRIES = "include_geometries";
	private static final String QUERY_PARAM_PAGE_SIZE = "page_size";
	private static final String QUERY_PARAM_NEXT_KEY = "next_key";

	private final ClientHelper clientHelper;

	public LpisClientServiceImpl(WebTarget target) {
		this.clientHelper = new ClientHelper(target);
	}

	@Override
	public List<PublicParcel> searchParcels(ReqContext context, AbsoluteDate referenceDate, String sectorDescrFilter, String blockDescrFilter,
			String parcelFilter, Boolean includeGeometries, Boolean includeLandCovers, Integer pageSize) {

		String publicPath = "{tenant}/public/v1/lpis/parcels/{reference_date}";

		Map<String, Object> pathVariables = Map.of(
				PATH_PARAM_TENANT, context.getTenantId(),
				PATH_PARAM_REFERENCE_DATE, referenceDate
		);

		MultivaluedMap<String, Object> queryParams = new MultivaluedHashMap<>();
		queryParams.add(QUERY_PARAM_SECTOR_DESCR_FILTER, sectorDescrFilter);
		queryParams.add(QUERY_PARAM_BLOCK_DESCR_FILTER, blockDescrFilter);
		queryParams.add(QUERY_PARAM_PARCEL_FILTER, parcelFilter);
		queryParams.add(QUERY_PARAM_INCLUDE_LANDCOVERS, includeLandCovers);
		queryParams.add(QUERY_PARAM_INCLUDE_GEOMETRIES, includeGeometries);
		queryParams.add(QUERY_PARAM_PAGE_SIZE, pageSize);

		return clientHelper.getAllFromInfiniteResult(publicPath, context, pathVariables, queryParams, new GenericType<>() {
		});
	}

	@Override
	public Optional<PublicParcel> getParcelById(ReqContext context, AbsoluteDate referenceDate, Long parcelId) {
		String publicPath = "{tenant}/public/v1/lpis/parcels/{reference_date}/{parcelId}";

		Map<String, Object> pathVariables = Map.of(
				PATH_PARAM_TENANT, context.getTenantId(),
				PATH_PARAM_REFERENCE_DATE, referenceDate,
				PATH_PARAM_PARCEL_ID, parcelId
		);

		MultivaluedMap<String, Object> queryParams = new MultivaluedHashMap<>();
		
		// allow to find the outdated parcels
		queryParams.add(QUERY_PARAM_SEARCH_LEVEL, ParcelSearchLevel.SEARCH_OUTDATED);
		
		return clientHelper.get(publicPath, context, pathVariables, queryParams, new GenericType<>() {
		});

	}

	@Override
	public List<PublicParcel> getParcelsByIdIn(ReqContext context, AbsoluteDate referenceDate, List<Long> parcelIds, ParcelSearchLevel parcelSearchLevel) {
		String publicPath = "{tenant}/public/v1/lpis/parcels/{reference_date}";

		Map<String, Object> pathVariables = Map.of(
				PATH_PARAM_TENANT, context.getTenantId(),
				PATH_PARAM_REFERENCE_DATE, referenceDate
		);
		
		if(parcelSearchLevel == null) {
			parcelSearchLevel = ParcelSearchLevel.SEARCH_OUTDATED;
		}

		MultivaluedMap<String, Object> queryParams = new MultivaluedHashMap<>();
		queryParams.add(QUERY_PARAM_SEARCH_LEVEL, parcelSearchLevel);

		return ListUtils.partition(parcelIds, 100).stream()
				.map(parcelIdsChunk -> Map.of("parcel_id_list", parcelIdsChunk))
				.map(requestBody -> clientHelper.<PublicParcelsList>post(publicPath, context,
						pathVariables, queryParams, requestBody, new GenericType<>() {}))
				.map(PublicParcelsList::getParcelsList)
				.flatMap(Collection::stream)
				.sorted(Comparator.comparing(x -> parcelIds.indexOf(x.getId())))
				.collect(Collectors.toList());
	}

	@Override
	public void consumeParcelsByIdIn(ReqContext context, Boolean inclueGeometries, AbsoluteDate referenceDate, List<Long> parcelIds, Consumer<PublicParcel> consumer) {
		String publicPath = "{tenant}/public/v1/lpis/parcels/{reference_date}";

		Map<String, Object> pathVariables = Map.of(
				PATH_PARAM_TENANT, context.getTenantId(),
				PATH_PARAM_REFERENCE_DATE, referenceDate
		);

		MultivaluedMap<String, Object> queryParams = new MultivaluedHashMap<>();
		queryParams.add(QUERY_PARAM_SEARCH_LEVEL, ParcelSearchLevel.SEARCH_OUTDATED);
		queryParams.add(QUERY_PARAM_INCLUDE_GEOMETRIES, Boolean.TRUE.equals(inclueGeometries));
		
		ListUtils.partition(parcelIds, 100).stream()
				.map(parcelIdsChunk -> Map.of("parcel_id_list", parcelIdsChunk))
				.map(requestBody -> clientHelper.<PublicParcelsList>post(publicPath, context,
						pathVariables, queryParams, requestBody, new GenericType<>() {}))
				.map(PublicParcelsList::getParcelsList)
//				.peek(l -> log.warn("{} response size: {}", publicPath, l.size()))
				.flatMap(Collection::stream)
				.forEach(consumer);
//				.forEach(parcels -> parcels.forEach(consumer));
	}

	@Override
	public InfiniteListResults<PublicParcel> searchParcels(ReqContext context, AbsoluteDate referenceDate, String sectorDescrFilter,
			String blockDescrFilter, String parcelFilter, Boolean includeGeometries, Boolean includeLandCovers,
			ParcelSearchLevel parcelSearchLevel, String nextKey, Integer pageSize) {

		String publicPath = "{tenant}/public/v1/lpis/parcels/{reference_date}";

		Map<String, Object> pathVariables = Map.of(
				PATH_PARAM_TENANT, context.getTenantId(),
				PATH_PARAM_REFERENCE_DATE, referenceDate
		);
		
		if(parcelSearchLevel == null) {
			parcelSearchLevel = ParcelSearchLevel.SEARCH_OUTDATED;
		}

		MultivaluedMap<String, Object> queryParams = new MultivaluedHashMap<>();
		queryParams.add(QUERY_PARAM_SECTOR_DESCR_FILTER, sectorDescrFilter);
		queryParams.add(QUERY_PARAM_BLOCK_DESCR_FILTER, blockDescrFilter);
		queryParams.add(QUERY_PARAM_PARCEL_FILTER, parcelFilter);
		queryParams.add(QUERY_PARAM_NEXT_KEY, nextKey);
		queryParams.add(QUERY_PARAM_INCLUDE_LANDCOVERS, includeLandCovers);
		queryParams.add(QUERY_PARAM_INCLUDE_GEOMETRIES, includeGeometries);
		queryParams.add(QUERY_PARAM_SEARCH_LEVEL, parcelSearchLevel);
		queryParams.add(QUERY_PARAM_PAGE_SIZE, pageSize);

		return clientHelper.getInfiniteResult(publicPath, context, pathVariables, queryParams, new GenericType<>() {
		});
	}
	
	@Override
	public PublicParcel persistTemporaryParcels(ReqContext context, Long parcelId) {

		String publicPath = "{tenant}/public/v1/lpis/parcels/temporary/{parcelId}/persist";

		Map<String, Object> pathVariables = Map.of(
				PATH_PARAM_TENANT, context.getTenantId(),
				PATH_PARAM_PARCEL_ID, parcelId
		);

		MultivaluedMap<String, Object> queryParams = new MultivaluedHashMap<>();
		
		return clientHelper.put(publicPath, context, pathVariables, queryParams, null, new GenericType<>() {
		});
	}

	@Override
	public List<PublicParcel> getParcelsBySectorCode(ReqContext context, AbsoluteDate referenceDate, String sectorCode) {
		String publicPath = "{tenant}/public/v1/lpis/sectors/{sector_code}/parcels/{reference_date}";

		Map<String, Object> pathVariables = Map.of(
				PATH_PARAM_TENANT, context.getTenantId(),
				PATH_PARAM_REFERENCE_DATE, referenceDate,
				"sector_code", sectorCode

		);

		MultivaluedMap<String, Object> queryParams = new MultivaluedHashMap<>();
		queryParams.add(QUERY_PARAM_INCLUDE_GEOMETRIES, false);
		queryParams.add(QUERY_PARAM_INCLUDE_LANDCOVERS, false);

		return clientHelper.getAllFromInfiniteResult(publicPath, context, pathVariables, queryParams, new GenericType<>() {
		});
	}

	@Override
	public List<PublicSector> getSectors(ReqContext context, String filter) {

		String publicPath = "{tenant}/public/v1/lpis/sectors";

		Map<String, Object> pathVariables = Map.of(PATH_PARAM_TENANT, context.getTenantId());

		MultivaluedMap<String, Object> queryParams = new MultivaluedHashMap<>();
		queryParams.add(QUERY_PARAM_INCLUDE_GEOMETRIES, false);
		queryParams.add(QUERY_PARAM_FILTER, filter);

		return clientHelper.getAllFromInfiniteResult(publicPath, context, pathVariables, queryParams, new GenericType<>() {
		});
	}
	
	@Override
	public PublicParcelBlockList getBlocks(ReqContext context, String sectorCode, String filter) {
		
		String publicPath = "{tenant}/public/v1/lpis/sectors/{sector_code}/blocks";
		
		Map<String, Object> pathVariables = Map.of(
				PATH_PARAM_TENANT, context.getTenantId(),
				"sector_code", sectorCode

		);
		
		MultivaluedMap<String, Object> queryParams = new MultivaluedHashMap<>();
		queryParams.add(QUERY_PARAM_INCLUDE_GEOMETRIES, false);
		queryParams.add(QUERY_PARAM_FILTER, filter);
		
		return clientHelper.get(publicPath, context, pathVariables, queryParams, new GenericType<>() {
		});
	}

	@Override
	public PublicSector getSectorDetails(ReqContext context, String sectorCode) {

		String publicPath = "{tenant}/public/v1/lpis/sectors/{sector_code}";

		Map<String, Object> pathVariables = Map.of(
				PATH_PARAM_TENANT, context.getTenantId(),
				"sector_code", sectorCode);

		MultivaluedMap<String, Object> queryParams = new MultivaluedHashMap<>();
		queryParams.add(QUERY_PARAM_INCLUDE_GEOMETRIES, false);
		return clientHelper.get(publicPath, context, pathVariables, queryParams, new GenericType<>() {
		});
	}
}
