package com.abacogroup.cllapi.resources;

import com.abacogroup.cllapi.core.impl.SupportService;
import com.abacogroup.common.resources.ReqContext;
import com.abacogroup.common.resources.ResourceConstants;
import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.jdbi.datatype.AbsoluteDate;

import io.dropwizard.auth.Auth;
import io.swagger.v3.oas.annotations.Hidden;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.annotation.security.PermitAll;
import jakarta.validation.constraints.Size;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DefaultValue;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.HeaderParam;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

@Path(ResourceConstants.API_PRIV + "/support")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
@Tag(name = "Support", description = "support operations")
public class SupportResource {

	private final SupportService supportService;

	public SupportResource(SupportService supportService) {
		this.supportService = supportService;
	}

	@GET
//	@RolesAllowed({ "CUSTOMER_LAND_LINK|READ", "CUSTOMER_LAND_LINK|WRITE" })
	@PermitAll
	@Hidden
	@Path("/fix/landlinks")
	public Response landLinkBatchFix(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "tenant id") @PathParam("tenant") String tenantId,
			@QueryParam("startKey") String startKey,
			@QueryParam("partyId") Long partyId,
			@QueryParam("referenceDate") @Size(min = 8, max = 8) String referenceDate) {
		
		if(!"ADMIN".equals(user.getName()) || !"028jqiy42gv89qijkaj458".equals(startKey)) {
			return Response.noContent().build();
		}

		supportService.fixLandLinkBatch(new ReqContext(user, lang), partyId, AbsoluteDate.of(referenceDate));
		return Response.ok().build();
	}

}
