package com.abacogroup.cllapi.core;

import java.util.List;

import com.abacogroup.cllapi.api.MandateHolder;
import com.abacogroup.cllapi.api.acl.PartyWithEntityV1;
import com.abacogroup.cllapi.api.acl.PartyWithEntityV1Infinite;
import com.abacogroup.common.resources.ReqContext;
import com.abacogroup.jdbi.datatype.AbsoluteDate;

public interface PartiesAclClientService {

	PartyWithEntityV1Infinite getMandatesByPartyId(ReqContext context, Long partyId, AbsoluteDate minDate, AbsoluteDate maxDate,
			boolean onlyExclusive, String nextKey);
	
	List<PartyWithEntityV1> getAllMandatesByPartyId(ReqContext context, Long partyId, AbsoluteDate minDate, AbsoluteDate maxDate,
			boolean onlyExclusive);
	
	MandateHolder getHolderByPartyId(ReqContext context, Long partyId, AbsoluteDate minDate, AbsoluteDate maxDate);

}
