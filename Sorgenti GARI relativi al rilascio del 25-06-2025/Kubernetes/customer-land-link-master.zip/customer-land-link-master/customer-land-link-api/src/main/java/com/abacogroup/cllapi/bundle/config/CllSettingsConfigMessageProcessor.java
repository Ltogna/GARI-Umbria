package com.abacogroup.cllapi.bundle.config;

import com.abacogroup.bundles.initializer.impl.exceptions.BundleException;
import com.abacogroup.bundles.listener.configdata.ConfigDataMessage;
import com.abacogroup.bundles.listener.configdata.ConfigMessageProcessor;
import com.abacogroup.cllapi.bundle.BundleConstants;
import com.abacogroup.cllapi.db.dao.CllSettingsDAO;
import com.abacogroup.cllapi.db.ntt.CllSettingsEntity;
import com.abacogroup.common.service.AuditHelper;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.nio.file.Path;
import java.util.Optional;
import java.util.function.Consumer;
import java.util.function.Function;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.FilenameUtils;

@Slf4j
public class CllSettingsConfigMessageProcessor implements ConfigMessageProcessor {

	private final ObjectMapper mapper;
	private final CllSettingsDAO cllSettingsDAO;

	public CllSettingsConfigMessageProcessor(ObjectMapper mapper, CllSettingsDAO cllSettingsDAO) {
		this.mapper = mapper;
		this.cllSettingsDAO = cllSettingsDAO;
	}

	@Override
	public void onMessage(ConfigDataMessage message) {
		String tenantId = message.getTenantId();
		message.getConfigFiles()
				.stream().filter(p -> FilenameUtils.isExtension(p.toString().toLowerCase(), "json"))
				.sorted()
				.forEach(path -> {
					addContent(tenantId, path);
				});
	}

	private void addContent(String tenantId, Path path) {
		try {

			CllSettingEntry settingToAdd = mapEntity(path);
			persistCllSetting(settingToAdd, tenantId);

		} catch (Exception e) {
			throw new BundleException(String.format("error saving file %s", path), e);
		}
	}

	private void persistCllSetting(CllSettingEntry settingToAdd, String tenant) {

		cllSettingsDAO.useTransaction(handle -> {
			handle.loadOne(tenant)
					.ifPresentOrElse(existing -> {
								//update
								existing.setLpisSubSeparator(Optional.ofNullable(settingToAdd.getLpisSubSeparator())
										.orElse(existing.getLpisSubSeparator()));
								existing.setAllowEditDayToParcelInThePast(Optional.ofNullable(settingToAdd.getAllowEditDayToParcelInThePast())
										.map(x -> x ? 1 : 0)
										.orElse(existing.getAllowEditDayToParcelInThePast()));
								Consumer<CllSettingsEntity> expire = handle::expire;
								Function<CllSettingsEntity, Long> insert = handle::insert;
								Long pkid = AuditHelper.update(existing, BundleConstants.SYSTEM_USER, expire, insert, handle.getCurrentTimestamp());
								log.trace("settings updated! new id {}", pkid);
							},
							() -> {
								//insert new
								CllSettingsEntity entity = CllSettingsEntity.builder()
										.setTenantId(tenant)
										.setLpisSubSeparator(settingToAdd.getLpisSubSeparator())
										.setAllowEditDayToParcelInThePast(Optional.ofNullable(settingToAdd.getAllowEditDayToParcelInThePast())
												.map(x -> x ? 1 : 0)
												.orElse(0))
										.build();

								AuditHelper.setAuditForInsert(BundleConstants.SYSTEM_USER, cllSettingsDAO, entity);
								cllSettingsDAO.insert(entity);
							});
		});
	}

	private CllSettingEntry mapEntity(Path path) {
		try {
			return mapper.readValue(path.toFile(), CllSettingEntry.class);
		} catch (Exception e) {
			throw new BundleException("error in json deserialization " + path, e);
		}
	}

	@Override
	public String getDomainName() {
		return BundleConstants.CLL_SETTINGS;
	}

	@Data
	protected static class CllSettingEntry {
		@JsonProperty("lpis_sub_separator")
		private String lpisSubSeparator;

		@JsonProperty("allow_edit_dayTo_parcelInThePast")
		private Boolean allowEditDayToParcelInThePast;
	}
}
