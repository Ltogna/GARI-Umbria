package com.abacogroup.cllapi.db.dao;

import java.util.List;

import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.transaction.Transactional;

import com.abacogroup.cllapi.api.LandLinkFixRes;
import com.abacogroup.jdbi.EnhancedSqlObject;

public interface SupportDAO extends Transactional<SupportDAO>, EnhancedSqlObject {

	@SqlQuery("select \n"
			+ "       clld.id as propLandLinkId, \n"
			+ "       clld1.id as landLinkId \n"
			+ "  from cll_land_link_detail clld, cll_land_link_detail clld1 \n"
			+ " where clld.tenant_id = :tenantId \n"
			+ "   and clld1.tenant_id = :tenantId \n"
			+ "   and clld.dt_delete > §current_timestamp§ \n"
			+ "   and clld.title_type_id = :titletypeId \n"
			+ "   and clld.title_type_perc = 100 \n"
			+ "   and clld.parcel_id  = clld1.parcel_id \n"
			+ "   and clld1.dt_delete > §current_timestamp§ \n"
			+ "   and clld1.title_type_id != :titletypeId \n"
			+ "   and clld1.title_type_perc = 100 \n"
			+ "   and to_date(clld1.day_from,'yyyymmdd') between to_date(clld.day_from,'yyyymmdd') and to_date(clld.day_to,'yyyymmdd') \n"
			+ "   and to_date(clld1.day_to,'yyyymmdd') between to_date(clld.day_from,'yyyymmdd') and to_date(clld.day_to,'yyyymmdd') \n"
			+ "   and clld1.party_id != clld.party_id \n"
			+ "   and to_date(clld.day_to,'yyyymmdd') > §current_timestamp§ \n"
			+ "   and to_date(clld1.day_to,'yyyymmdd') > §current_timestamp§ \n"
			+ "   and (:partyId is null OR clld.party_id = :partyId )\n"
			+ " order by clld.party_id \n")
	@RegisterBeanMapper(LandLinkFixRes.class)
	List<LandLinkFixRes> getLandLinkBatch(@Bind("tenantId") String tenantId, @Bind("titletypeId") Long titletypeId, @Bind("partyId") Long partyId);
}
